###############################################################
A=1;B=2;C=3;D=4;E=5;F=6;G=7;H=8;I=9;J=10;
P=4;Q=9;R=16;S=25;T=36;U=49;V=64;W=81;X=100;Y=121;Z=144;
###############################################################
count = 0;
####### simple 1
if not A == 2:
   count = count+1;
iend
####### simple 2
if not A == B:
   count = count + 1; 
iend
####### simple 3
if not C < A:
   count = count +1;
iend
####### simple 4
if not C > D:
   count = count+1; 
iend
####### simple 5
if not A >= (A+B):
   count = count+1;
iend
####### simple 6
if not D <= (A+B):
   count = count+1;
iend

publish("Operation test count for 'simple - if not' is 6 - passed file  :", count)
###############################################################
############################################################### 
#### Logical operations:
lcount = 0;
####### logic 1
if not (A == 2 && (C == A+B)):
   lcount = lcount +1;
iend
####### logic 2
if not (A == D || (C != A+B)):
   lcount = lcount +1;
iend
####### logic 3
if not (A == 1 !| D == 4):
   lcount = lcount +1;
iend
####### logic 4
if not (A == 1 !& C == (A+B)):
   lcount = lcount +1;
iend
####### logic 5
if not (D is_in [11:20]):
   lcount = lcount +1;
iend
####### logic 6
if not (D is_not_in [1:10]):
   lcount = lcount +1;
iend
####### logic 7
if not (is_empty([1, 2])):
   lcount = lcount +1;
iend
####### logic 8
if not (is_nan(1)):
   lcount = lcount +1;
iend
publish("Operation test count for 'logical - if not' is 8 - passed file :", lcount)
###############################################################
###############################################################
##### data conversion operator
count = 0;

####### simple 1
if not ((int(A) == 2) && (float(A) == 2.0) && (str(A) == str(2)) && (round(A, 3) == round(2, 3))~~
   && (rad2dec(A) == rad2dec(2)) && (dec2rad(A) == dec2rad(2)))&& (|A| == |2|):
   count = count+1;
iend

####### simple 2
if not ((int(A) == int(B)) && (float(A) == float(B)) && (str(A) == str(B)) && (round(A, 3) == round(B, 3))~~
   && (rad2dec(A) == rad2dec(B)) && (dec2rad(A) == dec2rad(B)))&& (|A| == |B|):
   count = count + 1;
iend

####### simple 3
if not ((int(C) < int(A)) && (float(C) < float(A)) && (str(C) < str(A)) && (round(C, 3) < round(A, 3))~~
   && (rad2dec(C) < rad2dec(A)) && (dec2rad(C) < dec2rad(A)))&& (|C| < |A|):
   count = count +1;
iend

####### simple 4
if not ((int(C) > int(D)) && (float(C) > float(D)) && (str(C) > str(D)) && (round(C, 3) > round(D, 3))~~
   && (rad2dec(C) > rad2dec(D)) && (dec2rad(C) > dec2rad(D)))  && (|C| > |D|):
   count = count+1;
iend

####### simple 5
if not ((int(A) >= int(A+B)) && (float(A) >= float(A+B)) && (str(A) >= str(A+B)) && (round(A, 3) >= round(A+B, 3))~~
   && (rad2dec(A) >= rad2dec(A+B)) && (dec2rad(A) >= dec2rad(A+B))) && (|A| >= |A+B|):
   count = count+1;
iend

####### simple 6
if not ((int(D) <= int(A+B)) && (float(D) <= float(A+B)) && (str(D) <= str(A+B)) && (round(D, 3) <= round(A+B, 3))~~
   && (rad2dec(D) <= rad2dec(A+B)) && (dec2rad(D) <= dec2rad(A+B)))&& (|D|<=|A+B|):
   count = count+1;
iend


publish("Operation test count for 'if not - integer' is 6 - passed file  :", count)
###############################################################
###############################################################