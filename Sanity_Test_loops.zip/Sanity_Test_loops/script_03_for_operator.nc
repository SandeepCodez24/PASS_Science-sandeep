###############################################################
A=1;B=2;C=3;D=4;E=5;F=6;G=7;H=8;I=9;J=10;
P=4;Q=9;R=16;S=25;T=36;U=49;V=64;W=81;X=100;Y=121;Z=144;
###############################################################
#### Binary operator
ecount   = 0;  ## equal to
necount  = 0;  ## not equal to
gcount   = 0;  ## greater than
gecount  = 0;  ## greater than or equal to
lcount   = 0;  ## less than
lecount  = 0;  ## less than or equal 

for i = [1:0.2:100]:
   ecount   = ecount  + (A==1);
   necount  = necount + (A != B);
   gcount   = gcount  + (D>C);
   gecount  = gecount + (C >= (A+B));
   lcount   = lcount  + (A<C);
   lecount  = lecount + (C <= (A+B));
fend

publish("Operation test count for 'simple - for' with [==,!=,>,<,<=,>=] is 496 - passed items  :",~~
         ecount,necount,gcount,gecount,lcount,lecount);
###############################################################
###############################################################
#### logical operators
acount        =0;  ### and
ocount        =0;  ### or
nacount       =0; ### nand
nocount       =0; ### nor
isin_count    =0; ### is in
isnotin_count =0; ### is not in
isempty_count =0; ### is empty
isnancount    =0;    ### is NaN 

for i2=[1:0.1:100]:
   acount        = acount        +(A==1 && (C==A+B));
   ocount        = ocount        +(A==D || (C==A+B));
   nacount       = nacount       +(A==D !& (E==A+B));
   nocount       = nocount       +(A==D !| (D==A+B));
   isin_count    = isin_count    +(D is_in [1:10]);
   isnotin_count = isnotin_count +(D is_not_in [11:20]);
   isempty_count = isempty_count +(is_empty([]));
   isnancount    = isnancount    +(is_nan(0/0));
fend

publish("Operation test count for 'simple - for' with [&&,||,!&,!|,is_in,is_not_in,is_empty,is_nan] is 991 - passed items  :",~~
         acount,ocount,nacount,nocount,isin_count,isnotin_count,isempty_count,isnancount);

###############################################################
###############################################################
### data conversion operator
icount   = 0;  ## integer
fcount   = 0;  ## float
scount   = 0;  ## str 
rcount   = 0;  ## round
r2dcount = 0; ## rad2degree
d2rcount = 0; ## deg2rad

for i3=[1:0.1:100]:
   icount = icount      +(int(D)==int(D));  ## integer
   fcount = fcount      +(float(D)==float(D));  ## float
   scount = scount      +(str(D)==str(D));  ## str 
   rcount = rcount      +(round(D,4)==round(D,4));  ## round
   r2dcount = r2dcount  +(rad2dec(D)==rad2dec(D)); ## rad2degree
   d2rcount = d2rcount  +(dec2rad(D)==dec2rad(D)); ## deg2rad
fend
publish("Operation test count for 'simple - for' with [int, float, str, round,rad2dec, dec2rad] is 991 - passed items  :",~~
         icount,fcount,scount,rcount,r2dcount,d2rcount);

###############################################################
###############################################################