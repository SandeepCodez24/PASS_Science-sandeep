###############################################################
A=1;B=2;C=3;D=4;E=5;F=6;G=7;H=8;I=9;J=10;
P=4;Q=9;R=16;S=25;T=36;U=49;V=64;W=81;X=100;Y=121;Z=144;
###############################################################
count = 0;
####### simple 1
if A ==1:
   count = count+1;
iend
####### simple 2
if A != B:
   count = count + 1; 
iend
####### simple 3
if A<C:
   count = count +1;
iend
####### simple 4
if D>C:
   count = count+1; 
iend
####### simple 5
if C <= (A+B):
   count = count+1;
iend
####### simple 6
if C >= (A+B):
   count = count+1;
iend

publish("Operation test count for 'simple - if' is 6 - passed file  :", count)
###############################################################
############################################################### 
#### Logical operations:
lcount = 0;
####### logic 1 - and
if A==1 && (C==A+B):
   lcount = lcount +1;
iend
####### logic 2 - or
if A==D || (C==A+B):
   lcount = lcount +1;
iend
####### logic 3 - nand
if A==D !| (D==A+B):
   lcount = lcount +1;
iend
####### logic 4 - nor
if A==D !& (E==A+B):
   lcount = lcount +1;
iend
####### logic 5 - is in
if D is_in [1:10]:
   lcount = lcount +1;
iend
####### logic 6 - is not in
if D is_not_in [11:20]:
   lcount = lcount +1;
iend
####### logic 7 - is empty
if is_empty([]):
   lcount = lcount +1;
iend
####### logic 8 - is nan
if is_nan(0/0):
   lcount = lcount +1;
iend
publish("Operation test count for 'logical - if' is 8 - passed file :", lcount)
###############################################################
############################################################### 
#### Data Conversion operations
count = 0;
if (int(A) ==1) && (float(A) ==1.0) && (str(A) ==str(1)) && (round(A, 3) ==round(1, 3))~~
   && (rad2dec(A) ==rad2dec(1)) && (dec2rad(A) ==dec2rad(1)) && (|A| ==|1|):
   count = count+1;
iend
####### simple 2
if (int(A) != int(B)) && (float(A) != float(B)) && (str(A) != str(B)) && (round(A, 3) != round(B, 3))~~
   && (rad2dec(A) != rad2dec(B)) && (dec2rad(A) != dec2rad(B))&& (|A| != |B|) :
   count = count + 1; 
iend
####### simple 3
if (int(A)<int(C)) && (float(A)<float(C)) && (str(A)<str(C)) && (round(A, 3)<round(C, 3))~~
   && (rad2dec(A)<rad2dec(C)) && (dec2rad(A)<dec2rad(C))&& (|A|<|C|):
   count = count +1;
iend
####### simple 4
if (int(D)>int(C)) && (float(D)>float(C))&&(str(D)>str(C)) && (round(D, 3)>round(C, 3))~~
   && (rad2dec(D)>rad2dec(C))&& (dec2rad(D)>dec2rad(C))&& (|D|>|C|):
   count = count+1; 
iend
####### simple 5
if (int(C) <= int(A+B)) && (float(C) <= float(A+B))&&(str(C) <= str(A+B)) && (round(C, 3) <= round(A+B, 3))~~
   &&(rad2dec(C) <= rad2dec(A+B)) && (dec2rad(C) <= dec2rad(A+B))&& (|C| <= |A+B|):
   count = count+1;
iend
####### simple 6
if (int(C) >= int(A+B)) && (float(C) >= float(A+B))&&(str(C) >= str(A+B)) && (round(C, 3) >= round(A+B, 3))~~
   &&(rad2dec(C) >= rad2dec(A+B)) && (dec2rad(C) >= dec2rad(A+B))&& (|C| >= |A+B|):
   count = count+1;
iend

publish("Operation test count for 'if - integer' is 6 - passed file  :", count)
###############################################################
###############################################################
