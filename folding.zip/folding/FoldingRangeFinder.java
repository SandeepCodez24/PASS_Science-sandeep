package language.folding;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Finds foldable line ranges in NC source text based on the language's own
 * block keywords: {@code if...iend}, {@code for...fend}, {@code while...wend},
 * {@code function...fnend}, {@code class...csend} — plus the interpreter's
 * legacy terminator synonyms ({@code end}/{@code endif}/{@code endfor}/
 * {@code endwhile}/{@code loop}/{@code loop end}, see {@link #closesTop}).
 *
 * <p>
 * Mirrors (independently — there is no shared code across the Java UI /
 * C++ interpreter boundary) the same-type nesting rules the C++ interpreter
 * itself uses for these terminators: a block keyword is recognized as the
 * leading word of a trimmed, lower-cased line, exactly like the interpreter's
 * own raw-line terminator matching. {@code elseif}/{@code else} are
 * continuations of an {@code if} block, not separate openers.
 */
public final class FoldingRangeFinder {

    public static final class FoldRange {
        public final int startLine;
        public final int endLine;

        public FoldRange(int startLine, int endLine) {
            this.startLine = startLine;
            this.endLine = endLine;
        }
    }

    private static final class Frame {
        final String type;
        final int startLine;

        Frame(String type, int startLine) {
            this.type = type;
            this.startLine = startLine;
        }
    }

    private FoldingRangeFinder() {
        // Utility class
    }

    public static List<FoldRange> find(String text) {
        List<FoldRange> ranges = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return ranges;
        }

        String[] lines = text.split("\\R", -1);
        Deque<Frame> stack = new ArrayDeque<>();

        for (int i = 0; i < lines.length; i++) {
            String lower = lines[i].trim().toLowerCase(Locale.ROOT);

            String opener = matchOpener(lower);
            if (opener != null) {
                stack.push(new Frame(opener, i));
                continue;
            }

            if (closesTop(lower, stack)) {
                Frame frame = stack.pop();
                if (i > frame.startLine) {
                    ranges.add(new FoldRange(frame.startLine, i));
                }
            }
            // A closer with no matching open frame (malformed/mismatched code), or an
            // opener frame with no closer before EOF (leftover on the stack), simply
            // produces no fold range for that block — degrade gracefully.
        }

        return ranges;
    }

    private static String matchOpener(String lower) {
        if (startsWithWord(lower, "if")) {
            return "if";
        }
        if (startsWithWord(lower, "for")) {
            return "for";
        }
        if (startsWithWord(lower, "while")) {
            return "while";
        }
        if (startsWithWord(lower, "function")) {
            return "function";
        }
        if (startsWithWord(lower, "class")) {
            return "class";
        }
        return null;
    }

    private static final Set<String> IF_FOR_WHILE = Set.of("if", "for", "while");
    private static final Set<String> FOR_WHILE = Set.of("for", "while");

    /**
     * Whether {@code lower} is a terminator that closes the block currently
     * on top of {@code stack}, mirroring the C++ interpreter's own
     * terminator rules ({@code Parser::isIfTerm}/{@code isForTerm}/
     * {@code isWhileTerm}/{@code isFunctionTerm}/{@code isClassTerm} in
     * {@code parser.cpp}/{@code parser_function.cpp}/{@code parser_class.cpp}
     * — confirmed by reading those directly, not guessed). {@code fnend}/
     * {@code csend} are unambiguous; {@code iend}/{@code endif},
     * {@code fend}/{@code endfor}/{@code loop}, {@code wend}/
     * {@code endwhile} are each specific to one block type. Bare
     * {@code end} and {@code loop end} are genuinely ambiguous on the C++
     * side too — it accepts them for whichever of if/for/while
     * ({@code end}) or for/while ({@code loop end}) is currently open — so
     * here they close whatever type is actually on top of the stack rather
     * than a fixed keyword-to-type table.
     */
    private static boolean closesTop(String lower, Deque<Frame> stack) {
        if (stack.isEmpty()) {
            return false;
        }
        String top = stack.peek().type;
        switch (lower) {
            case "fnend":
                return "function".equals(top);
            case "csend":
                return "class".equals(top);
            case "iend":
            case "endif":
                return "if".equals(top);
            case "fend":
            case "endfor":
            case "loop":
                return "for".equals(top);
            case "wend":
            case "endwhile":
                return "while".equals(top);
            case "end":
                return IF_FOR_WHILE.contains(top);
            case "loop end":
                return FOR_WHILE.contains(top);
            default:
                return false;
        }
    }

    private static boolean startsWithWord(String lower, String word) {
        if (!lower.startsWith(word)) {
            return false;
        }
        if (lower.length() == word.length()) {
            return true;
        }
        char next = lower.charAt(word.length());
        return !(Character.isLetterOrDigit(next) || next == '_');
    }
}
