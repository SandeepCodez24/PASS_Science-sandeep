#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2;C=3;D=4;E=5; F = 36;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = B!+D!;  
A2 = D!-A!;  
A3 = B!*D!;  
A4 = D!/B!;  
A5 = sqrt(F!);  
A6 = cbrt(F!);  
A7 = sqr(C!);   
A8 = cube(B!);  
A9 = B^(B!);   
A10 = (P!)!;   
A11 = (F!)//(B!);  
A12 = (F!)%(B!);   
A13 = log(D!); 
A14 = e^(C!);   
A15 = logb4(F!);   
\\ A16 = |P!|;  ## UI and CPP Error
#########################################################
#########################################################
publish("Addition             :", B!+D!==A1);
publish("Subtraction          :", D!-A!==A2);
publish("Multiplication       :", B!*D!==A3);
publish("Division             :", D!/B!==A4);
publish("Square Root          :", sqrt(F!)==A5);
publish("Cube Root            :", cbrt(F!)==A6);
publish("Square               :", sqr(C!)==A7);
publish("Cube                 :", cube(B!)==A8);
publish("Power                :",  B^(B!)==A9);    
publish("Factorial            :", (P!)!==A10); 
publish("Quotient             :", (F!)//(B!)==A11);
publish("Remainder            :", (F!)%(B!)==A12);
publish("Natural Logarithm    :", log(D!)==A13);
publish("Exponential          :", e^(C!)==A14);     
publish("Logarithm Base       :", logb4(F!)==A15);
\\ publish("Modulus              :", |P!|==A16);  ## UI and CPP Error
#########################################################
#########################################################