# Expected: extend error (;=): A is 2x3, value is 2x1 - column count mismatch (3 vs 1) + transpose hint
A = [1, 2, 3; 4, 5, 6]
A ;= [1; 2]
