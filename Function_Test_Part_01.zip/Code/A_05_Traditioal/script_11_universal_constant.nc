##############################################################################
# script_11 - Universal constants
#
# Every constant is a plain name: uc_<name>, in lower case, with no brackets.
#    energy = uc_planck * uc_speedoflight / 500e-9;
#
# Values are in SI units, CODATA 2022 (the values in scipy.constants).
# A variable you assign with the same name replaces the constant in that script.
#
# Every check prints PASS or FAIL, comparing to about 9 significant digits.
##############################################################################

# Relative comparison, because these constants range from 1e-34 to 1e23.
function r = check(name, got, want):
   r = abs(got - want) <= 1e-9 * abs(want);
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name, " got ", got, " want ", want);
   iend
fnend

##################################################
############## Universal Constants ###############
### pi
x = check("uc_pi", uc_pi, 3.141592653589793);
### Standard gravity, m/s^2
x = check("uc_gravity", uc_gravity, 9.80665);
### Gas constant, J/(mol K)
x = check("uc_gasconst", uc_gasconst, 8.31446261815324);
### Avogadro number, 1/mol
x = check("uc_avogadro", uc_avogadro, 6.02214076e+23);
### Planck constant h, J s
x = check("uc_planck", uc_planck, 6.62607015e-34);
### Reduced Planck constant h/(2 pi), J s
x = check("uc_hbar", uc_hbar, 1.0545718176461565e-34);
### Gravitational constant G, m^3/(kg s^2)
x = check("uc_gravitational", uc_gravitational, 6.6743e-11);
### Stefan-Boltzmann constant, W/(m^2 K^4)
x = check("uc_stefanboltzmann", uc_stefanboltzmann, 5.6703744191844314e-08);
### Coulomb constant, N m^2/C^2
x = check("uc_coulomb", uc_coulomb, 8987551786.170797);
### Electron mass, kg
x = check("uc_electronmass", uc_electronmass, 9.1093837139e-31);
### Proton mass, kg
x = check("uc_protonmass", uc_protonmass, 1.67262192595e-27);
### Neutron mass, kg
x = check("uc_neutronmass", uc_neutronmass, 1.67492750056e-27);
### Molar mass constant, kg/mol
x = check("uc_molarmass", uc_molarmass, 0.00100000000105);
### Elementary (electron) charge, C
x = check("uc_elementarycharge", uc_elementarycharge, 1.602176634e-19);
### Faraday constant, C/mol
x = check("uc_faraday", uc_faraday, 96485.33212331001);
### Speed of light, m/s
x = check("uc_speedoflight", uc_speedoflight, 299792458);
### Boltzmann constant, J/K
x = check("uc_boltzmann", uc_boltzmann, 1.380649e-23);
### Vacuum permittivity, F/m
x = check("uc_vacuumpermittivity", uc_vacuumpermittivity, 8.8541878188e-12);
### Vacuum permeability, N/A^2
x = check("uc_vacuumpermeability", uc_vacuumpermeability, 1.25663706127e-06);
### Fine-structure constant, no unit
x = check("uc_finestructure", uc_finestructure, 0.0072973525643);
### Rydberg constant, 1/m
x = check("uc_rydberg", uc_rydberg, 10973731.568157);
### Bohr radius, m
x = check("uc_bohrradius", uc_bohrradius, 5.29177210544e-11);
### Hartree energy, J
x = check("uc_hartreeenergy", uc_hartreeenergy, 4.359744722206e-18);
### Magnetic flux quantum, Wb
x = check("uc_magneticfluxquantum", uc_magneticfluxquantum, 2.0678338484619295e-15);

##################################################
### The constants agree with one another, through the laws of physics
x = check("R = N_A * k", uc_gasconst, uc_avogadro * uc_boltzmann);
x = check("F = N_A * e", uc_faraday, uc_avogadro * uc_elementarycharge);
x = check("h = 2 pi hbar", uc_planck, 2 * uc_pi * uc_hbar);
x = check("k_e = 1/(4 pi eps0)", uc_coulomb, 1 / (4 * uc_pi * uc_vacuumpermittivity));
##############################################################################
