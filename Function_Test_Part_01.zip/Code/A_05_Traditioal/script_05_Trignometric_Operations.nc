##############################################################################
# script_05 - Trigonometric operations
#
# Every function works on a number, a vector or a matrix (element by element).
# Angles are in radians; sin_deg, cos_deg ... take degrees.
#
#   Reciprocal functions        Inverse functions (two spellings of each)
#   cosec(x) = 1/sin(x)         arcsin(x)   = inv_sin(x)
#   sec(x)   = 1/cos(x)         arccos(x)   = inv_cos(x)
#   cot(x)   = cos(x)/sin(x)    arctan(x)   = inv_tan(x)
#                               arccosec(x) = inv_cosec(x) = arcsin(1/x)
#                               arcsec(x)   = inv_sec(x)   = arccos(1/x)
#                               arccot(x)   = inv_cot(x)   = arctan(1/x)
#
# NOTE: cosec and arcsin are NOT the same function, so they give different
# answers: cosec(0.5) = 2.0858 and arcsin(0.5) = 0.5236. The checks below
# confirm that cosec is 1/sin and arcsin undoes sin.
#
# An inverse outside its real range gives the complex answer, as in NumPy and
# MATLAB: arcsin(2) = 1.570796+1.316958i.
#
# Expected numbers come from Python's math module. Every check prints PASS or
# FAIL.
##############################################################################

# PASS when got and want agree to about 9 significant digits.
function r = check(name, got, want):
   r = abs(got - want) <= 1e-9 * (1 + abs(want));
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name, " got ", got, " want ", want);
   iend
fnend

# PASS when two vectors/matrices agree element by element.
function r = check_all(name, got, want):
   r = matrix_norm(got - want) <= 1e-9;
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name);
   iend
fnend

##############################################
### sine, cosine, tangent
A1 = sin(3.143);
A1a = sin(nexus_normal(4));
B1 = cos(0);
B1b = cos(nexus_normal(4));
C1 = tan(0.785398);
C1c = tan(nexus_uniform(4));
x = check("cos(0) = 1", B1, 1);
x = check("sin^2 + cos^2 = 1", sin(0.5)^2 + cos(0.5)^2, 1);
x = check("tan = sin/cos", tan(0.5), sin(0.5)/cos(0.5));

### cosecant, secant, cotangent (the reciprocals)
D1 = cosec(0.785398);
D1d = cosec(nexus_normal(4));
E1 = sec(1.44);
E1e = sec(nexus_normal(4));
F1 = cot(0.78);
F1f = cot(nexus_normal(4));
x = check("cosec(0.5) = 2.085829643", cosec(0.5), 2.085829642933488);
x = check("sec(0.5) = 1.139493927", sec(0.5), 1.139493927324549);
x = check("cot(0.5) = 1.830487722", cot(0.5), 1.830487721712452);
x = check("cosec(x) = 1/sin(x)", cosec(0.7), 1/sin(0.7));
x = check("sec(x) = 1/cos(x)", sec(0.7), 1/cos(0.7));
x = check("cot(x) = 1/tan(x)", cot(0.7), 1/tan(0.7));

### inverse sine, cosine, tangent
G1 = inv_sin(0.1);
G1g = inv_sin(nexus_normal(4));
H1 = inv_cos(0.324);
H1h = inv_cos(nexus_normal(4));
I1 = inv_tan(0.785398);
I1i = inv_tan(nexus_normal(4));
x = check("arcsin(0.5) = 0.523598776", arcsin(0.5), 0.5235987755982989);
x = check("arccos(0.5) = 1.047197551", arccos(0.5), 1.0471975511965979);
x = check("arctan(0.5) = 0.463647609", arctan(0.5), 0.4636476090008061);
x = check("arcsin undoes sin", arcsin(sin(0.7)), 0.7);
x = check("arccos undoes cos", arccos(cos(0.7)), 0.7);
x = check("arctan undoes tan", arctan(tan(0.7)), 0.7);

### inverse cosecant, secant, cotangent
J1 = inv_cosec(1.44);
J1j = inv_cosec(nexus_normal(4));
K1 = inv_sec(0.785398);
K1k = inv_sec(nexus_normal(4));
L1 = inv_cot(0.24587);
L1l = inv_cot(nexus_normal(4));
x = check("arccosec(2) = arcsin(1/2)", arccosec(2), arcsin(1/2));
x = check("arcsec(2) = arccos(1/2)", arcsec(2), arccos(1/2));
x = check("arccot(2) = arctan(1/2)", arccot(2), arctan(1/2));
x = check("arccosec undoes cosec", arccosec(cosec(0.7)), 0.7);
x = check("arcsec undoes sec", arcsec(sec(0.7)), 0.7);
x = check("arccot undoes cot", arccot(cot(0.7)), 0.7);

### arc- and inv_ are one function under two names
x = check("arcsin = inv_sin", arcsin(0.3), inv_sin(0.3));
x = check("arccos = inv_cos", arccos(0.3), inv_cos(0.3));
x = check("arctan = inv_tan", arctan(0.3), inv_tan(0.3));
x = check("arccosec = inv_cosec", arccosec(3), inv_cosec(3));
x = check("arcsec = inv_sec", arcsec(3), inv_sec(3));
x = check("arccot = inv_cot", arccot(3), inv_cot(3));
x = check_all("arcsin works on a vector", arcsin([0,0.5]), [0,0.5235987755982989]);
x = check("arcsin(2) real part is pi/2", real(arcsin(2)), pi/2);

### hyperbolic functions
M1 = sinh(3.14245);
M1m = sinh(nexus_normal(4));
N1 = cosh(1.552);
N1n = cosh(nexus_normal(4));
O1 = tanh(1.000);
O1o = tanh(nexus_normal(4));
P1 = cosech(3.14245);
P1p = cosech(nexus_normal(4));
Q1 = sech(3.14245);
Q1q = sech(nexus_normal(4));
R1 = coth(0.78);
R1r = coth(nexus_normal(4));
x = check("cosh^2 - sinh^2 = 1", cosh(0.5)^2 - sinh(0.5)^2, 1);
x = check("cosech = 1/sinh", cosech(0.5), 1/sinh(0.5));
x = check("sech = 1/cosh", sech(0.5), 1/cosh(0.5));
x = check("coth = 1/tanh", coth(0.5), 1/tanh(0.5));

### degrees
x = check("sin_deg(30) = 0.5", sin_deg(30), 0.5);
x = check("cos_deg(60) = 0.5", cos_deg(60), 0.5);

### products of results
S1 = A1*B1*C1;
S2 = sin(0.785398)*cos(0.785398);
S3 = A1*B1*C1*D1*E1*F1*G1*H1;
x = check("sin(x)*cos(x) = sin(2x)/2", S2, sin(2*0.785398)/2);
##############################################################################
