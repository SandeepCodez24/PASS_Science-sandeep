##############################################################################
# script_04 - Logical operations
#
# Control flow (if, for, while), comparisons, the is_empty / is_nan tests and
# the membership operators in / not in.
#
# How to read the output: every check prints PASS or FAIL with what it tested.
# Run it with:  nc.exe script_04_Logical_Operations.nc
# Comments: both # and \\ start a comment that runs to the end of the line.
##############################################################################

# Prints PASS when the condition holds, FAIL when it does not.
function r = check(name, condition):
   r = condition;
   if condition:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name);
   iend
fnend

A = 1;
B = 1;
C = 2.3;
F = 2;

##############################
### Print and publish
publish("You can mention whatever you want..!");

##############################
### if - the body runs when the condition is true
ran = false;
if (A==B):
   ran = true;
iend
x = check("if runs its body", ran);

##############################
### for - [1:10] counts 1,2,...,10 (inclusive)
α = 0;
for j1 = [1:10]:
   α = α + 1;
fend
x = check("for runs 10 times", α == 10);

##############################
### if not - the body runs when the condition is false
ran = false;
if not (A==C):
   ran = true;
iend
x = check("if not runs its body", ran);

##############################
### && (and), || (or)
x = check("&& needs both true", (A==B) && (A!=C));
x = check("|| needs one true", (A==C) || (A==B));

##############################
### while / while not
λ = 0;
while λ <= 99:
   λ = λ + 1;
wend
x = check("while stops at 100", λ == 100);

τ = 0;
while not (τ==100):
   τ = τ + 1;
wend
x = check("while not stops at 100", τ == 100);

##############################
### == (equal to), != (not equal to)
x = check("== on equal numbers", A == B);
x = check("!= on different numbers", A != F);

##############################
### is_empty
γ = [];
x = check("is_empty([]) is true", is_empty(γ));
x = check("is_empty([1,2]) is false", not(is_empty([1,2])));

##############################
### is_nan
# 0/0 has no value (NaN). 4/0 is NOT NaN: it is infinity.
φ = 0/0;
x = check("is_nan(0/0) is true", is_nan(φ));
x = check("is_nan(4/0) is false", not(is_nan(4/0)));

##############################
### in - is the value one of the elements?
#   x in A       A may be a vector, a matrix of any shape, a dict or text.
#   is_in is the older spelling of the same operator; both work.
ξ = 51;
GL = [1,2,3,4,5,6,51];
found = false;
if ξ in GL:
   found = true;
iend
x = check("in: 51 is in the vector", found);
x = check("in: 5 is in a 2x2 matrix", 5 in [1,5;7,8]);
x = check("in: a vector matches a whole row", [3,4] in [1,2;3,4]);
x = check("in: a dict is searched by key", "a" in dict(["a","b"], [1,2]));
x = check("in: text is searched for the piece", "ell" in "hello");
x = check("in: a number is never inside text", not(5 in "a5"));
x = check("in: nothing is in an empty matrix", not(5 in []));
x = check("is_in is the same operator", 51 is_in GL);

##############################
### not in - the exact opposite of in
ψ = 10;
GL2 = [1,2,3,4,5,6,7,8];
missing = false;
if ψ not in GL2:
   missing = true;
iend
x = check("not in: 10 is not in the vector", missing);
x = check("not in: false for a value that is there", not(3 not in GL2));
x = check("is_not_in is the same operator", ψ is_not_in GL2);

### in / not in inside a bigger condition, an assignment and a function
x = check("in combines with &&", (3 in GL2) && (10 not in GL2));
b = 3 + 1 in GL2;              # + is done first: (3+1) in GL2
x = check("in binds looser than +", b);

function r = absent(v, list):
   r = v not in list;
fnend
x = check("not in inside a function", absent(10, GL2));

# 'for x in A' still loops over A - the word 'in' keeps that meaning there.
total = 0;
for k in [1,2,3]:
   total = total + k;
fend
x = check("for ... in loops over a vector", total == 6);

# A plain number has no elements to search, so this one is an error and
# would stop the script:
\\ y = 5 in 5;      Error: 'in' needs a matrix, a dict or text on its right, not a number
##############################################################################
