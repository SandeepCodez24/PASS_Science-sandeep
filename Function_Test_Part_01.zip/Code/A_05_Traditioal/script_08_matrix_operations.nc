##############################################################################
# script_08 - Matrix operations
#
# Matrix syntax: ',' between values, ';' between rows.
#    A 3x3 matrix is written   [1,2,3; 4,5,6; 7,8,9]
#    [1,2,3] is one row, [1;2;3] is one column.
#    The old nested form [[1,2],[3,4]] is no longer accepted.
#
# Tests such as pd_matrix answer 1 (true) or 0 (false).
#
# Expected numbers come from NumPy. Every check prints PASS or FAIL.
##############################################################################

# PASS when got and want agree to about 9 significant digits.
function r = check(name, got, want):
   r = abs(got - want) <= 1e-9 * (1 + abs(want));
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name, " got ", got, " want ", want);
   iend
fnend

# PASS when two matrices agree element by element (to 1e-8, because some
# expected values below are written with 10 decimals).
function r = check_all(name, got, want):
   r = matrix_norm(got - want) <= 1e-8;
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name);
   iend
fnend

#############################################
A = [2,4,9; 8,6,7; 9,5,9];
B = [8,98,625; 18,85,76; 19,35,39];
C = [2,4,9,6; 8,6,7,9; 9,5,9,57; 1,2,3,8];
D = [2,4,9,6; 8,6,7,9; 9,5,9,57];           # 3x4, not square

### Rank
A1 = rank(A);
x = check("rank(A)", A1, 3);
x = check("rank of a singular matrix", rank([1,2,3;4,5,6;7,8,9]), 2);

### Transpose
B1 = transpose(C);
x = check_all("transpose(C)", B1, [2,8,9,1; 4,6,5,2; 9,7,9,3; 6,9,57,8]);
x = check_all("C' is transpose(C)", C', B1);

### Conjugate - conjugate(C) and conj(C) are one function.
# A real matrix is its own conjugate; the imaginary parts change sign.
C1 = conjugate(C);
x = check_all("conjugate of a real matrix", C1, C);
x = check_all("conjugate = conj", conjugate(C), conj(C));
x = check("conjugate of a complex matrix", matrix_norm(real(conjugate([1+2i,3;4,5-6i]) - [1-2i,3;4,5+6i])) + matrix_norm(imag(conjugate([1+2i,3;4,5-6i]) - [1-2i,3;4,5+6i])), 0);

### Pseudo inverse - pseudo_inverse(D) and pinv(D) are one function.
# It also works for a matrix that is not square.
D1 = pseudo_inverse(D);
x = check_all("pseudo_inverse(D)", D1, [-0.1166421088,0.1447428119,-0.0102920880; -0.0037419874,0.0546740871,-0.0088311917; 0.1410445317,-0.0425055293,-0.0079169908; -0.0035247696,-0.0209387014,0.0211936433]);
x = check_all("pseudo_inverse = pinv", pseudo_inverse(D), pinv(D));
x = check_all("D * pinv(D) * D gives D back", D * D1 * D, D);
x = check_all("pinv of a square matrix is its inverse", pinv(C), inv(C));

### Determinant
E1 = det(C);
x = check("det(C)", E1, -2105);

### Adjoint
F1 = adj(C);
x = check_all("adj(C)", F1, [-103,-252,-130,1287; 735,-225,335,-2685; -565,130,-100,990; 41,39,-30,-124]);

### Hadamard product, and the element-wise operator *. which is the same thing
G1 = had_prod(A,B);
J1 = A*.B;
x = check_all("had_prod(A,B)", G1, [16,392,5625; 144,510,532; 171,175,351]);
x = check_all("A*.B = had_prod(A,B)", J1, G1);

### Inverse
H1 = inv(C);
x = check_all("inv(C)", H1, [0.0489311164,0.1197149644,0.0617577197,-0.6114014252; -0.3491686461,0.1068883610,-0.1591448931,1.2755344418; 0.2684085511,-0.0617577197,0.0475059382,-0.4703087886; -0.0194774347,-0.0185273159,0.0142517815,0.0589073634]);
x = check_all("C * inv(C) = unit matrix", C * H1, unit_matrix(4));

### Matrix norm - norm(C) is the Frobenius norm, same as matrix_norm(C).
I1 = norm(C);
x = check("norm(C)", I1, 62.297672508690084);
x = check("norm = matrix_norm", I1, matrix_norm(C));

### Diagonal matrix: diag(n) is n x n with n on the diagonal
K1 = diag(5);
x = check_all("diag(5)", K1, 5 * unit_matrix(5));
x = check_all("diag of a vector", diag([1,2]), [1,0;0,2]);
x = check_all("diag of a matrix is its diagonal", diag([1,2;3,4]), [1;4]);

### Upper triangular, lower triangular
L1 = upper_triangular(3);
x = check_all("upper_triangular(3)", L1, [1,1,1; 0,1,1; 0,0,1]);
x = check_all("upper_triangular of a matrix", upper_triangular([1,2;3,4]), [1,2;0,4]);
x = check_all("lower_triangular(3)", lower_triangular(3), [1,0,0; 1,1,0; 1,1,1]);

### Zero matrix
M1 = zero_matrix(4);
x = check_all("zero_matrix(4)", M1, zeros(4));
x = check_all("zero_matrix(2,3)", zero_matrix(2,3), [0,0,0;0,0,0]);

### Full rank? Singular? (1 = yes, 0 = no)
N1 = full_rank_matrix(C);
O1 = singular_matrix(C);
x = check("full_rank_matrix(C)", N1, 1);
x = check("singular_matrix(C)", O1, 0);
x = check("a singular matrix is not full rank", full_rank_matrix([1,2,3;4,5,6;7,8,9]), 0);
x = check("singular_matrix finds it", singular_matrix([1,2,3;4,5,6;7,8,9]), 1);

### Positive definite, negative definite (1 = yes, 0 = no)
# Only symmetric matrices can be definite, so a non-symmetric one such as C
# answers 0. A matrix that is not square is an error.
PD = [2,-1,0; -1,2,-1; 0,-1,2];             # eigenvalues 0.586, 2, 3.414
ND = -1 * PD;
ID = [1,0; 0,-1];                           # indefinite: one of each sign
P1 = pd_matrix(C);
Q1 = nd_matrix(C);
x = check("pd_matrix(C): not symmetric", P1, 0);
x = check("nd_matrix(C): not symmetric", Q1, 0);
x = check("pd_matrix of a positive definite", pd_matrix(PD), 1);
x = check("nd_matrix of a positive definite", nd_matrix(PD), 0);
x = check("pd_matrix of a negative definite", pd_matrix(ND), 0);
x = check("nd_matrix of a negative definite", nd_matrix(ND), 1);
x = check("pd_matrix of an indefinite", pd_matrix(ID), 0);
x = check("nd_matrix of an indefinite", nd_matrix(ID), 0);
x = check("pd_matrix of a very small matrix", pd_matrix(1e-13 * unit_matrix(2)), 1);
x = check("pd_matrix of the zero matrix", pd_matrix(zeros(2)), 0);

### Unit matrix
R1 = unit_matrix(4);
x = check_all("unit_matrix(4)", R1, [1,0,0,0; 0,1,0,0; 0,0,1,0; 0,0,0,1]);

### Trace
x = check("trace", trace([1,2;3,4]), 5);
##############################################################################
