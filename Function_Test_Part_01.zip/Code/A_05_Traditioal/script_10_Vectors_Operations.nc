##############################################################################
# script_10 - Vector operations
#
# Input size each function needs (anything else is an error, or for vector_tp
# and curl a message as the result):
#   unit_vector, norm, dircos, proj, proj_vec, divergence   any length
#   vector_tp, curl                                         exactly 3 values
#   orthogonal, orthonormal                                 exactly 2 values
#   eigen_value, eigen_vector                               a square matrix
#
# Two names do not mean what a textbook means (documented in vector.cpp):
#   divergence(A)  is the sum of A's elements, and curl(A) a cyclic difference
#   of A's elements - neither differentiates a field. proj_vec(A) is the same
#   as unit_vector(A).
#
# Expected numbers come from NumPy. Every check prints PASS or FAIL.
##############################################################################

# PASS when got and want agree to about 9 significant digits.
function r = check(name, got, want):
   r = abs(got - want) <= 1e-9 * (1 + abs(want));
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name, " got ", got, " want ", want);
   iend
fnend

# PASS when two vectors/matrices agree element by element.
function r = check_all(name, got, want):
   r = matrix_norm(got - want) <= 1e-9;
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name);
   iend
fnend

######################################################
A = [1,2,3,4,5,6,7,8,9,10];
B = [0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1];

### Unit vector - the same direction, length 1
A1 = unit_vector(A);
x = check("unit_vector(A) has length 1", norm(A1), 1);
x = check("unit_vector(A), first value", A1[0], 0.050964719143762556);

### Norm of a vector
B1 = norm(A);
x = check("norm(A)", B1, 19.621416870348583);

### Direction cosines
C1 = dircos(A);
x = check_all("dircos(A) = unit_vector(A)", C1, A1);

### Vector triple product: (a x b) . c, for vectors of 3 values
D1 = vector_tp([1,2,3], [4,5,7], [7,8,10]);
x = check("vector_tp", D1, 3);

### Projection of A on B
E1 = proj(A,B);
x = check_all("proj of A on a constant vector", E1, 5.5 * [1,1,1,1,1,1,1,1,1,1]);

### Projection vector
F1 = proj_vec(A);
x = check_all("proj_vec(A) = unit_vector(A)", F1, A1);

### Orthogonal vector: A turned by 90 degrees, for a vector of 2 values
G1 = orthogonal([3,4]);
x = check_all("orthogonal([3,4])", G1, [-4,3]);

### Orthonormal vector: the same, with length 1
H1 = orthonormal([3,4]);
x = check_all("orthonormal([3,4])", H1, [-0.8,0.6]);

### Eigenvalues and eigenvectors of a square matrix.
# Column k of eigen_vector(M) belongs to value k of eigen_value(M).
M = [2,1; 1,2];
I1 = eigen_vector(M);
J1 = eigen_value(M);
x = check("eigenvalues add up to the trace", sum(J1), 4);
x = check("largest eigenvalue", max(J1), 3);
x = check_all("M*v = value*v", M * I1, I1 * diag(J1));

# A rotation has complex eigenvalues, i and -i.
W = eigen_value([0,-1; 1,0]);
x = check("rotation: real part", abs(real(W[0])), 0);
x = check("rotation: imaginary part", abs(imag(W[0])), 1);

### Divergence: the sum of the elements (see the note at the top)
k1 = divergence(A);
x = check("divergence(A)", k1, 55);

### Curl: a cyclic difference, for a vector of 3 values (see the note at the top)
L1 = curl([1,2,3]);
x = check_all("curl([1,2,3])", L1, [-1,2,-1]);

# A vector is one row of values, never a matrix in disguise. Write the 2x2
# matrix as [1,2;3,4]; this is an error:
\\ y = eigen_value([1,2,3,4]);   Error: expected a square matrix such as [1,2;3,4], got a vector
##############################################################################
