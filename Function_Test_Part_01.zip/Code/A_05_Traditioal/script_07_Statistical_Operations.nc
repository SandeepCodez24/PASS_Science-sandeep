##############################################################################
# script_07 - Statistical operations
#
# Input: any vector, row [1,2,3] or column [1;2;3]. A 2-D matrix [1,2;3,4]
# counts as the list of all its elements (like NumPy's np.mean(A)).
#
# What each function computes:
#   mean, median, mode    mode gives every most-frequent value, or the text
#                         "No mode" when all values occur once
#   geo_mean, harmo_mean  positive values only (anything else is an error)
#   trim_mean             mean after dropping 10% from each end
#   var, sd               SAMPLE variance and deviation (divide by n-1)
#   pvar, psd             POPULATION variance and deviation (divide by n)
#   coeff_var             sd / mean * 100, as a percentage
#   skew, kurtosis        population skewness and excess kurtosis (bias=True)
#   std_error             sd / sqrt(n)
#   corr_coeff, co_var    Pearson correlation, sample covariance
#   lsm(y)                least-squares line through y against 0,1,2,... (text)
#   lsm(x, y)             least-squares line of y on x (text)
#   p_val_cal(z)          one-tailed p-value of a z-score
#   p_val_cal(data)       two-tailed p-value of the one-sample t-test, H0: mean = 0
#   null_hypo(p)          "Reject H0" when p < 0.05, else "Fail to Reject H0"
#   null_hypo(data)       the same decision, on the t-test of the data
#   chi_test(O, E)        the chi-square STATISTIC, sum((O-E)^2/E). It is not a
#                         p-value, so do not pass it to null_hypo().
#   norm(A)               Euclidean length (L2 norm), same as l2norm(A)
#   lnorm(A)              min-max normalization: every value scaled into 0..1
#   Q1, Q2, Q3, IQR       quartiles by the median-of-halves method (capitals)
#   percentile(A, p)      linear interpolation, as NumPy's default
#
# Expected numbers come from NumPy / SciPy. Every check prints PASS or FAIL.
##############################################################################

# PASS when got and want agree to about 9 significant digits.
function r = check(name, got, want):
   r = abs(got - want) <= 1e-9 * (1 + abs(want));
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name, " got ", got, " want ", want);
   iend
fnend

# PASS when got is exactly the expected text.
function r = check_text(name, got, want):
   r = got == want;
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name, " got ", got, " want ", want);
   iend
fnend

# PASS when two vectors/matrices agree element by element.
function r = check_all(name, got, want):
   r = matrix_norm(got - want) <= 1e-9;
   if r:
      publish("PASS  ", name);
   else:
      publish("FAIL  ", name);
   iend
fnend

################################################
### Data 1 - the numbers 1 to 15, and the same numbers plus 10
A = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
B = [11,12,13,14,15,16,17,18,19,20,21,22,23,24,25];

A1 = mean(A);                 x = check("mean(A)", A1, 8);
B1 = median(A);               x = check("median(A)", B1, 8);
C1 = mode(A);                 x = check_text("mode(A): all values differ", C1, "No mode");
D1 = geo_mean(A);             x = check("geo_mean(A)", D1, 6.4234247497797625);
E1 = harmo_mean(A);           x = check("harmo_mean(A)", E1, 4.520483676867457);
F1 = trim_mean(A);            x = check("trim_mean(A)", F1, 8);
G1 = var(A);                  x = check("var(A)", G1, 20);
H1 = sd(A);                   x = check("sd(A)", H1, 4.47213595499958);
I1 = coeff_var(A);            x = check("coeff_var(A)", I1, 55.90169943749474);
J1 = skew(A);                 x = check("skew(A): symmetric data", J1, 0);
K1 = corr_coeff(A,B);         x = check("corr_coeff(A,B)", K1, 1);
L1 = co_var(A,B);             x = check("co_var(A,B)", L1, 20);
M1 = lsm(A);                  x = check_text("lsm(A)", M1, "y = 1 + 1x");
N1 = null_hypo(A);            x = check_text("null_hypo(A)", N1, "Reject H0");
O1 = p_val_cal(A);            x = check("p_val_cal(A)", O1, 7.002171827322289e-06);
P1 = chi_test(A,B);           x = check("chi_test(A,B)", P1, 88.69899237852529);
Q1 = norm(A);                 x = check("norm(A)", Q1, 35.21363372331802);

x = check("pvar(A)", pvar(A), 18.666666666666668);
x = check("psd(A)", psd(A), 4.320493798938574);
x = check("kurtosis(A)", kurtosis(A), -1.210714285714286);
x = check("std_error(A)", std_error(A), 1.1547005383792515);
x = check("Q1(A)", Q1(A), 4);
x = check("Q3(A)", Q3(A), 12);
x = check("IQR(A)", IQR(A), 8);
x = check("range(A)", range(A), 14);
x = check("percentile(A,90)", percentile(A,90), 13.6);

################################################
### Data 2 - uneven data, so the answers do not all land on round numbers
X = [2.5,3.1,4.7,4.7,5.0,6.2,8.8,9.4,12.1,15.6];
Y = [1.2,2.4,2.2,3.9,4.1,6.5,7.7,9.9,10.1,16.0];

x = check("mean(X)", mean(X), 7.21);
x = check("median(X)", median(X), 5.6);
x = check("mode(X): 4.7 occurs twice", mode(X), 4.7);
x = check("geo_mean(X)", geo_mean(X), 6.192099989239703);
x = check("harmo_mean(X)", harmo_mean(X), 5.330009064394465);
x = check("trim_mean(X)", trim_mean(X), 6.75);
x = check("var(X)", var(X), 17.689888888888888);
x = check("sd(X)", sd(X), 4.205934960135367);
x = check("pvar(X)", pvar(X), 15.9209);
x = check("psd(X)", psd(X), 3.9901002493671758);
x = check("coeff_var(X)", coeff_var(X), 58.33474285902034);
x = check("skew(X)", skew(X), 0.7944445153164518);
x = check("kurtosis(X)", kurtosis(X), -0.46011102365555967);
x = check("std_error(X)", std_error(X), 1.3300334164557253);
x = check("corr_coeff(X,Y)", corr_coeff(X,Y), 0.9785724157613831);
x = check("co_var(X,Y)", co_var(X,Y), 19.01111111111111);
x = check("chi_test(X,Y)", chi_test(X,Y), 5.417353770823345);
x = check("p_val_cal(X)", p_val_cal(X), 0.00042133425136996156);
x = check("norm(X)", norm(X), 26.05858783587476);
x = check("Q1(X)", Q1(X), 4.7);
x = check("Q3(X)", Q3(X), 9.4);
x = check("percentile(X,25)", percentile(X,25), 4.7);
x = check_text("lsm(X,Y)", lsm(X,Y), "y = -1.3485 + 1.07469x");
x = check_all("lnorm(X), first three", lnorm(X)[0:2], [0,0.04580152671755,0.16793893129771]);

################################################
### The p-value and the decision
x = check("p_val_cal(1.96): one tail of a z-score", p_val_cal(1.96), 0.024997895148220435);
x = check_text("null_hypo(0.01): below 5%", null_hypo(0.01), "Reject H0");
x = check_text("null_hypo(0.5): above 5%", null_hypo(0.5), "Fail to Reject H0");
x = check_text("null_hypo: data around 0", null_hypo([-1,1,-2,2,0.5,-0.5]), "Fail to Reject H0");
x = check_text("lsm: a falling line", lsm([1,2,3],[6,4,2]), "y = 8 - 2x");

################################################
### Vector and matrix input: the matrix syntax is [row ; row]
x = check("mean of a column", mean([1;2;3]), 2);
x = check("mean of a 2x2 matrix", mean([1,2;3,4]), 2.5);
x = check("median of a 2x2 matrix", median([1,2;3,4]), 2.5);
x = check("var of a 2x2 matrix", var([1,2;3,4]), 1.6666666666666667);
x = check("trim_mean of a 2x2 matrix", trim_mean([1,2;3,4]), 2.5);
x = check("percentile of a 2x2 matrix", percentile([1,2;3,4],50), 2.5);
x = check("corr_coeff of two matrices", corr_coeff([1,2;3,4],[2,4;6,8]), 1);
x = check("norm of a 2x2 matrix", norm([1,2;3,4]), 5.477225575051661);
x = check("p_val_cal of a 2x2 matrix", p_val_cal([1,2;3,4]), p_val_cal([1,2,3,4]));
x = check_all("lnorm keeps the matrix shape", lnorm([1,2;3,5]), [0,0.25;0.5,1]);
x = check_all("mode gives every most-frequent value", mode([1,1,2,2,3]), [1,2]);

# Input the functions cannot answer stops the script with an error, e.g.
\\ y = geo_mean([-1,2]);        Error: geo_mean requires positive values
\\ y = chi_test([1,2],[1,0]);   Error: chi_test: an expected value cannot be zero
\\ y = mean(5);                 Error: mean expects a vector or a matrix, got a number
##############################################################################
