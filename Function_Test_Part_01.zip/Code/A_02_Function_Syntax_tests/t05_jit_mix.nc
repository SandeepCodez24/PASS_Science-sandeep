function y = sq(x):
   y = x * x;
fnend
a = sq(5);
function y = G(a, b=100):
   y = a + b;
fnend
b = G(1);
c = G(a=1, b=2);
d = sq(x=3);
for i = [1:3]:
   e = G(i);
fend
print(a, b, c, d, e)
function y = sq(x, k=1):
   y = x * x * k;
fnend
f = sq(4, 10);
print("sq redefined with a default:", f)
