# R6: poly1d is a value - P(x), P[k], fields, NumPy functions take it
PDD = poly1d([2, 3, 1])
PDD(2)
PDD([0, 1, 2])
PDD([0, 1; 2, 3])
PDD[2]
PDD[0]
PDD[5]
PDD.coeffs
PDD.order
PDD.roots
polyval(PDD, 2)
roots(PDD)
polyder(PDD)
Q = poly1d([1, 2], r=true)
Q(1)
T = poly1d([1, 0, -1], variable="t")
Z = poly1d([0, 0, 5])
PDD(1+2i)
function y = twice(P, x):
    y = 2 * P(x)
fnend
twice(PDD, 3)
function y = local_poly(x):
    L = poly1d([1, 1])
    y = L(x) + L[1]
fnend
local_poly(4)
PDD(PDD)
PDD("a")
PDD[1.5]
PDD(1, 2)
