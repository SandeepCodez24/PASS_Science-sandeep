# R10: the acceptance tests of java_side_prompt_v2.md, section 6 (nc.exe side)
function y = f(a=1, ~~
b=2, ~~
                       c=3):
    y = a + b + c
fnend
z = f(1, ~~
  c=10)
A = [1, 1; 1, 1]; B = [0.95, 1; 1, 1.2];
r1 = allclose(A, B)
r2 = allclose(A, B, atol=0.25)
r3 = isclose(A, B, rtol=0.2)
r4 = round([1.234, 5.678], decimals=1)
r5 = max([1, 5; 7, 2], axis=0)
r6 = angle([1i, -1], deg=true)
r7 = tensorinv([4, 7; 2, 6], ind=1)
r8 = allclose(A, B, 0.2, atol=0.1)
allclose(A, B, tol=0.1)
allclose(A, atol=0.1)
allclose(A, B, atol=0.1, atol=0.2)
sqrt(x=4)
max(A, B, axis=0)
P = poly1d([2, 3, 1])
v = P(2)
c = P[2]
o = P.order
w = polyval(P, [0, 1])
P(x=2)
P(1, 2)
g = euler_gamma
euler_gamma = 5
h = euler_gamma
