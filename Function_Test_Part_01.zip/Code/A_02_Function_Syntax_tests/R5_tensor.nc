# R5: tensorinv / tensorsolve on N-D matrices, as NumPy
A = [11,2,3,4;2,11,0,1;0,3,11,2;1,1,1,15]
Ai = tensorinv(A, ind=1)
B = reshape([4,1,0,0,1,0,0,0, 1,5,1,0,0,1,0,0, 0,1,6,1,0,0,1,0, 0,0,1,7,0,0,0,1, 1,0,0,0,8,1,0,0, 0,1,0,0,1,9,1,0, 0,0,1,0,0,1,3,1, 0,0,0,1,0,0,1,4], [2,4,2,4]);
Bi = tensorinv(B, ind=2);
shape(Bi)
Bi
b = [1,2,3,4,5,6,7,8];
x = tensorsolve(reshape(B,[8,2,4]), b)
x2 = tensorsolve(A, [1,2,3,4])
x3 = tensorsolve(reshape(B,[2,4,2,4]), reshape(b,[2,4]), axes=[0])
tensorinv([1,2;3,4])
