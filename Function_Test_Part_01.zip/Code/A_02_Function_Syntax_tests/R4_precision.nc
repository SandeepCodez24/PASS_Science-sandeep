# R4: full precision where the short display would hide a difference
a = nextafter(1, 2)
b = nextafter(1, 0)
c = nextafter(1, 2) - 1
d = spacing(1.0)
X = ones([2,2]);
E = nextafter(X, X*2)
F = nextafter(X, X*-2)
g = 1/3
h = [0.5, 1, 2.25]
k = 1.0000001
l = 2.5
m = -0.99999999999
e00 = E[0, 0]
