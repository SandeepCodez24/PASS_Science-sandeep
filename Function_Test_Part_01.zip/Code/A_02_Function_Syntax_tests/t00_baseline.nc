function y = Add(a, b):
   y = a + b;
fnend
C = Add(10, 15)
class Shape():
   function base(w, h):
      base.w = w;
      base.h = h;
   fnend
   function A = area():
      A = base.w * base.h;
   fnend
csend
s = Shape(2, 3);
print(s.area())
s
