function y = f(a=1, ~~
               b=2, ~~
               c="car"):
   y = a + b;
fnend
publish("f() =", f())
publish("f(b=10) =", f(b=10, ~~
                       a=5))
class Shape( ~~
           ):
   function base(w, ~~
                 h=1, ~~
                 label="shape"):
      base.w = w;
      base.h = h;
   fnend
csend
s = Shape(h=3, ~~
          2);
publish(s.w, s.h)
class Square(Shape ~~
            ):
   function base(side=2):
      parent(side, ~~
             h=side);
   fnend
csend
q = Square(side=7);
publish(q.w, q.h)
function [q, r] = divide(a, ~~
                         b=3):
   q = a // b;
   r = a % b;
fnend
[q, r] = divide(b=5, ~~
                17);
publish(q, r)
r = f(a=);
