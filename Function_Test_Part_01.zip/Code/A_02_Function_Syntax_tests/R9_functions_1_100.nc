########################################################################
# Functions_1_100.nc - one working example for every Vector Math and
# Scalar Math function (NumPy sections 9 and 8).
#
# How to read each block
#   ##### Function NN - the call, with the names of its inputs
#   # NumPy:   the NumPy function it matches
#   # Does:    what it gives back, in one line
#   # Inputs:  what each input means; "name=value" is the default used when
#   #          the input is left out, "[...]" means it may be left out
#   then the example. Lines without ';' print their result.
#
# Inputs can be given in order or by name, e.g.
#   allclose(A, B, 0.2)  is the same as  allclose(A, B, atol=0.2)
# Named values go to their input first; plain values then fill the inputs
# still open, left to right (the same rule as functions you write).
########################################################################

########################## Function 01 - max(A[, B], axis=k)
# NumPy:   np.max / np.maximum
# Does:    the largest element of A; with axis, the largest along that axis;
#          max(A, B) is the larger of each pair of elements
# Inputs:  A - number, vector, matrix or N-D matrix
#          B - [optional] second value of the same size (or one number)
#          axis - [optional, by name only] 0 = down each column, 1 = along each row
A1 = [1, 2, 3, 4, 5];
A1o  = max(A1)
M1   = [1, 5, 2; 7, 0, 4];
A1o1 = max(M1)
A1o2 = max(M1, axis=0)
A1o3 = max(M1, axis=1)
A1o4 = max(M1, [3, 3, 3; 3, 3, 3])
N1   = reshape([1, 9, 2, 8, 3, 7, 4, 6], [2, 2, 2]);
A1o5 = max(N1)
A1o6 = max(N1, axis=2)

########################## Function 02 - min(A[, B], axis=k)
# NumPy:   np.min / np.minimum
# Does:    the smallest element of A; with axis, the smallest along that axis
# Inputs:  as max
A2o  = min(A1)
A2o1 = min(M1)
A2o2 = min(M1, axis=0)
A2o3 = min(N1, axis=0)

########################## Function 03 - fmin(A, B)
# NumPy:   np.fmin
# Does:    the smaller of each pair; a nan loses to a number
# Inputs:  A, B - numbers, vectors or matrices of the same size (or one number)
A3o  = fmin([1, 8, nan], [4, 2, 3])
A3o1 = fmin(1, 3)

########################## Function 04 - fmax(A, B)
# NumPy:   np.fmax
# Does:    the larger of each pair; a nan loses to a number
# Inputs:  A, B - as fmin
A4o  = fmax([1, 8, nan], [4, 2, 3])
A4o1 = fmax(1, 3)

########################## Function 05 - equal(A, B)
# NumPy:   np.array_equal
# Does:    true when A and B have the same size and the same elements
# Inputs:  A, B - any two values
A = unit_matrix(3);
B = A;
A5o  = equal(A, B)
A5o1 = equal(A, A * 2)

########################## Function 06 - equiv(A, B)
# NumPy:   np.array_equiv
# Does:    true when A and B are equal after a row (or one number) is
#          repeated to the other's size
# Inputs:  A, B - any two values
A = [1, 2, 3]; B = [1, 2, 3; 1, 2, 3];
A6o  = equiv(A, B)
A6o1 = equiv(1, 1)

########################## Function 07 - allclose(A, B, atol=0.1, rtol=0)
# NumPy:   np.allclose
# Does:    true when EVERY |A - B| <= atol + rtol*|B|
# Inputs:  A, B - values of the same size (or one number)
#          atol - absolute tolerance, default 0.1 (a third plain value is atol)
#          rtol - relative tolerance, default 0
A = [1, 1, 1; 1, 1, 1; 1, 1, 1];
B = [0.99999999, 0.91, 0.999; 1.000001, 1.0000, 1.00001; 0.999999, 0.999999, 0.99999];
A7o  = allclose(A, B)
A7o1 = allclose(A, B, 0.05)
A7o2 = allclose(A, B, atol=0.05, rtol=0.1)

########################## Function 08 - isclose(A, B, atol=0.1, rtol=0)
# NumPy:   np.isclose
# Does:    true / false for EACH element: |A - B| <= atol + rtol*|B|
# Inputs:  as allclose
A8o  = isclose(A, B)
A8o1 = isclose(A, B, atol=0.01)

########################## Function 09 - exp(x)
# NumPy:   np.exp
# Does:    e^x for every element (exp(-inf) is 0)
# Inputs:  x - number, vector or matrix
A = ones([3, 3]);
A[0, 0] = -inf; A[1, 1] = -inf; A[2, 2] = -inf;
A9o = exp(A)

########################## Function 10 - exp2(x)
# NumPy:   np.exp2
# Does:    2^x for every element
# Inputs:  x - number, vector or matrix
B = ones([2, 2]) * 3;
A10o = exp2(B)

########################## Function 11 - expN(x), any whole base N
# NumPy:   np.power(N, x)
# Does:    N^x for every element: exp4(x) = 4^x, exp10(x) = 10^x
# Inputs:  x - number, vector or matrix
A11o  = exp4(B)
A11o1 = exp10(2)

########################## Function 12 - log1p(x)
# NumPy:   np.log1p
# Does:    log(1 + x), exact even when x is tiny
# Inputs:  x - number, vector or matrix
x = 1e-10;
A = ones([2, 2]) * x;
A12o  = log1p(x)
A12o1 = log1p(A)

########################## Function 13 - logaddexp(A, B)
# NumPy:   np.logaddexp
# Does:    log(e^A + e^B) without overflow
# Inputs:  A, B - numbers, vectors or matrices of the same size
x1 = 1000.0; x2 = 1000.0;
A = ones([2, 2]) * x1;
A13o  = logaddexp(x1, x2)
A13o1 = logaddexp(A, A)

########################## Function 14 - logaddexp2(A, B)
# NumPy:   np.logaddexp2
# Does:    log2(2^A + 2^B)
# Inputs:  A, B - as logaddexp
x1 = 3.0; x2 = 3.0;
A = ones([2, 2]) * x1;
A14o  = logaddexp2(x1, x2)
A14o1 = logaddexp2(A, A)

########################## Function 15 - logaddexpN(A, B), any whole base N
# NumPy:   (log base N of N^A + N^B)
# Does:    logaddexp4(A, B) = log4(4^A + 4^B)
# Inputs:  A, B - as logaddexp
x1 = 0.5; x2 = 0.5;
A15o = logaddexp4(x1, x2)

########################## Function 16 - inv_tan2(Y, X)
# NumPy:   np.arctan2
# Does:    the angle of the point (X, Y) in radians, -pi to pi
# Inputs:  Y - the y values; X - the x values (same size, or one number)
Y = [1.0, -1.0, -1.0, 1.0];
X = [1.0, 1.0, -1.0, -1.0];
A16o  = rad2dec(inv_tan2(Y, X))
A16o1 = rad2dec(inv_tan2(1, 0))

########################## Function 17 - hypot(A, B)
# NumPy:   np.hypot
# Does:    sqrt(A^2 + B^2) for every pair
# Inputs:  A, B - the two sides (same size, or one number)
A17o  = hypot(4, 3)
A17o1 = hypot([3, 5], [4, 12])

########################## Function 18 - anglewrap(theta, discont=pi)
# NumPy:   np.unwrap
# Does:    removes jumps bigger than discont between neighbours by adding
#          or taking away 2*pi, so a phase is continuous
# Inputs:  theta - vector of angles in radians
#          discont - largest jump left alone, default pi
Theta = [0.0, 1.5, 3.14, -3.14, -1.5];
A18o  = anglewrap(Theta)
A18o1 = anglewrap([0, 4, -4], discont=pi)

########################## Function 19 - sinc(x)
# NumPy:   np.sinc
# Does:    sin(pi*x)/(pi*x), and 1 at x = 0
# Inputs:  x - number, vector or matrix
X = [-1.0, -0.5, 0.0; 0.25, 0.5, 1.0];
A19o  = sinc(0.5)
A19o1 = sinc(X)

########################## Function 20 - fabs(x)
# NumPy:   np.fabs
# Does:    the absolute value of every element, always as decimals
# Inputs:  x - number, vector or matrix (real)
A20o  = fabs(-3.14)
A20o1 = fabs([-1.5, 2.0, -3.8])

########################## Function 21 - sign(x)
# NumPy:   np.sign
# Does:    -1, 0 or 1 for every element
# Inputs:  x - number, vector or matrix
A = diag([-5, 5, 3]);
A[2] = [-10.5, 0.0, 4.2];
A21o  = sign(A)
A21o1 = sign(A[0, 0])

########################## Function 22 - ceil(x)
# NumPy:   np.ceil
# Does:    rounds every element UP to a whole number
# Inputs:  x - number, vector or matrix
X = [1.2, -1.2, 2.5; -2.5, 3.0, 0.1];
A22o  = ceil(3.254)
A22o1 = ceil(X)

########################## Function 23 - floor(x)
# NumPy:   np.floor
# Does:    rounds every element DOWN to a whole number
# Inputs:  x - number, vector or matrix
A23o  = floor(3.254)
A23o1 = floor(X)

########################## Function 24 - round(x, decimals=0)
# NumPy:   np.round
# Does:    rounds to `decimals` places; a half goes away from zero
#          (2.5 -> 3, -2.5 -> -3). NumPy's np.round sends halves to the even
#          neighbour - in NC that is rint (Function 25).
# Inputs:  x - number, vector or matrix
#          decimals - places after the point, default 0 (can be named)
X = [1.234, 5.678, 2.5, 3.5; -1.234, -5.678, -2.5, -3.5];
A24o  = round(X, 2)
A24o1 = round(X)
A24o2 = round(3.21121, decimals=3)

########################## Function 25 - rint(x)
# NumPy:   np.rint
# Does:    the nearest whole number; halves go to the even neighbour
# Inputs:  x - number, vector or matrix
X = [-1.7, -1.2, 1.5, 2.5, 3.8];
A25o  = rint(-23.3)
A25o1 = rint(X)

########################## Function 26 - fix(x)
# NumPy:   np.fix
# Does:    rounds every element towards zero
# Inputs:  x - number, vector or matrix
X = [-2.7, -1.2, 1.2, 2.7];
A26o  = fix(pi)
A26o1 = fix(X)

########################## Function 27 - trunc(x)
# NumPy:   np.trunc
# Does:    drops the part after the point (same as fix)
# Inputs:  x - number, vector or matrix
A27o  = trunc(-23.3)
A27o1 = trunc([-1.7, -1.2, 1.5, 2.5, 3.8])

########################## Function 28 - gcd(A[, B])
# NumPy:   np.gcd / np.gcd.reduce
# Does:    greatest common divisor of each pair; gcd(A) of all elements of A
# Inputs:  A - whole numbers; B - [optional] whole numbers of the same size
X = [12, 24, 30; 12, 24, 30];
Y = [8, 16, 45; 8, 16, 45];
A28o  = gcd(X, Y)
A28o1 = gcd([12, 18, 24])

########################## Function 29 - lcm(A[, B])
# NumPy:   np.lcm / np.lcm.reduce
# Does:    least common multiple of each pair; lcm(A) of all elements of A
# Inputs:  as gcd
A29o  = lcm(X, Y)
A29o1 = lcm([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

########################## Function 30 - heaviside(x, h0)
# NumPy:   np.heaviside
# Does:    0 where x < 0, 1 where x > 0, h0 where x == 0
# Inputs:  x - number, vector or matrix; h0 - the value used at 0
X = [-2.0, 0.0, 3.0];
A30o  = heaviside(X, 0.5)
A30o1 = heaviside(0, h0=1)

########################## Function 31 - copysign(x, s)
# NumPy:   np.copysign
# Does:    |x| with the sign of s, element by element
# Inputs:  x - the sizes; s - the signs (same size, or one number)
X1 = [1.0, -2.0, 3.0, -4.0];
X2 = [-1.0, 1.0, -5.0, 5.0];
A31o  = copysign(5, -1)
A31o1 = copysign(X1, X2)

########################## Function 32 - signbit(x)
# NumPy:   np.signbit
# Does:    true where the sign bit is set (negative numbers, and -0.0)
# Inputs:  x - number, vector or matrix
A32o  = signbit([1.5, -1.5, 0.0, -0.0])
A32o1 = signbit(-0.0001)

########################## Function 33 - nextafter(x, y)
# NumPy:   np.nextafter
# Does:    the next double after x in the direction of y. Shown with full
#          precision, because the difference is in the last digit.
# Inputs:  x - start values; y - direction (same size, or one number)
A33o  = nextafter(1.0, 2.0)
A33o1 = nextafter(1.0, 0.0)
A33o2 = nextafter([1, 2], [2, 0])          # a grid keeps its short form
A33o3 = nextafter([1, 2], [2, 0]) - [1, 2]  # so look at the step itself

########################## Function 34 - spacing(x)
# NumPy:   np.spacing
# Does:    the gap from x to the next double up (machine epsilon at 1)
# Inputs:  x - number, vector or matrix
A34o  = spacing(1.0)
A34o1 = spacing(1000.0)

########################## Function 35 - [m, e] = frexp(x)
# NumPy:   np.frexp
# Does:    splits x into m * 2^e with 0.5 <= |m| < 1 (m = 0, e = 0 for 0)
# Inputs:  x - number, vector or matrix
X = [8.0, 3.0, 0.0];
[A35om, A35oe] = frexp(X)
[A35o1m, A35o1e] = frexp(2)

########################## Function 36 - ldexp(m, e)
# NumPy:   np.ldexp
# Does:    m * 2^e - the reverse of frexp
# Inputs:  m - mantissas; e - whole-number exponents (same size, or one number)
[M, E] = frexp(X);
[m1, e1] = frexp(2);
A36o  = ldexp(M, E)
A36o1 = ldexp(m1, e1)

########################## Function 37 - [f, i] = modf(x)
# NumPy:   np.modf
# Does:    the part after the point (f) and the whole part (i), same sign as x
# Inputs:  x - number, vector or matrix
X = [3.14159, -2.718, 5.0];
[F, I] = modf(X)

########################## Function 38 - conj(z)
# NumPy:   np.conj
# Does:    the complex conjugate of every element (a - bi)
# Inputs:  z - number, vector or matrix (real or complex)
Z = [1 + 2i, 3 - 4i, 5.0];
A38o = conj(Z)

########################## Function 39 - real(z)
# NumPy:   np.real
# Does:    the real part of every element
# Inputs:  z - number, vector or matrix
A39o = real(Z)

########################## Function 40 - img(z)
# NumPy:   np.imag
# Does:    the imaginary part of every element
# Inputs:  z - number, vector or matrix
A40o = img(Z)

########################## Function 41 - angle(z, deg=false)
# NumPy:   np.angle
# Does:    the angle of every complex element, in radians (degrees with deg=true)
# Inputs:  z - number, vector or matrix
#          deg - [by name only] true for degrees, default false
X = [1 + 0i, 0 + 1i, -1 + 0i];
A41o  = angle(X)
A41o1 = angle(X, deg=true)

########################## Function 42 - dot(A, B[, axis])
# NumPy:   np.vdot (two values) / np.vecdot (with axis)
# Does:    sum of conj(A).*B as one number
# Inputs:  A, B - the same number of elements; complex A is conjugated
A = [1 + 2i, 3 + 4i];
B = [5 + 6i, 7 + 8i];
A42o = dot(A, B)

########################## Function 43 - dot(A, B, axis=k) on matrices
# NumPy:   np.vecdot(A, B, axis=k)
# Does:    one dot product per column (axis 0) or per row (axis 1, also -1)
# Inputs:  A, B - matrices of the same size; axis - 0 or 1
X = [1, 2, 3; 4, 5, 6];
A43o  = dot(X, X)
A43o1 = dot(X, X, axis=0)
A43o2 = dot(X, X, axis=1)

########################## Function 44 - inner(A, B)
# NumPy:   np.inner
# Does:    a number for two vectors; A*B' for matrices
# Inputs:  A, B - vectors of the same length, or matrices with equal columns
A44o = inner([1, 2, 3], [0, 1, 0])

########################## Function 45 - outer(a, b)
# NumPy:   np.outer
# Does:    the matrix a(i)*b(j)
# Inputs:  a, b - vectors (any lengths)
A45o = outer([1, 2], [3, 4, 5])

########################## Function 46 - cross(a, b[, axis])
# NumPy:   np.cross
# Does:    cross product of 3-element vectors; for matrices, row by row
#          (axis 1) or column by column (axis 0)
# Inputs:  a, b - 3-element vectors, or matrices of the same size
#          axis - [optional] 0 or 1; left out: rows when they hold 3 values
A46o  = cross([1, 0, 0], [0, 1, 0])
A46o1 = cross([1, 2, 3; 4, 5, 6], [7, 8, 9; 1, 2, 3], axis=1)

########################## Function 47 - tensordot(A, B, axes=2)
# NumPy:   np.tensordot
# Does:    axes=2: sum(A.*B); axes=1: the matrix product A*B
# Inputs:  A, B - matrices; axes - 1 or 2 (default 2)
x1 = [0, 1, 2; 3, 4, 5];
x2 = [0, 1; 2, 3; 4, 5];
A47o  = tensordot(x1, x2, axes=1)
A47o1 = tensordot(x1, x1)

########################## Function 48 - einsum(subscripts, A, B, ...)
# NumPy:   np.einsum
# Does:    sums of products described by index letters, e.g. "i,i->" is
#          the dot product and "ij->ji" the transpose
# Inputs:  subscripts - text; then one value per letter group (given in order)
A48o  = einsum("i,i->", [1, 2, 3], [4, 5, 6])
A48o1 = einsum("ij->ji", [1, 2; 3, 4])

########################## Function 49 - kron(A, B)
# NumPy:   np.kron
# Does:    the Kronecker product: every A(i,j) times all of B
# Inputs:  A, B - matrices (any sizes)
A49o = kron([1, 2; 3, 4], [0, 5; 6, 7])

########################## Function 50 - trace(A)
# NumPy:   np.trace
# Does:    the sum of the main diagonal
# Inputs:  A - matrix
A50o = trace([1, 2, 3; 4, 5, 6; 7, 8, 9])

########################## Function 51 - vector_norm(x, ord=2)
# NumPy:   np.linalg.vector_norm
# Does:    the length of x: ord=2 Euclidean, 1 sum of |x|, inf the largest |x|
# Inputs:  x - vector (or all elements of a matrix); ord - default 2
A51o  = vector_norm([40.0, 30.0])
A51o1 = vector_norm([3, -4], ord=1)
A51o2 = vector_norm([3, -4], ord=inf)
A51o3 = norm([40.0, 30.0])

########################## Function 52 - matrix_norm(A[, ord])
# NumPy:   np.linalg.matrix_norm
# Does:    the Frobenius norm (default), or ord = 1, 2, inf, "fro", "nuc"
# Inputs:  A - matrix; ord - [optional]
A = [1, 2; 3, 4];
A52o  = matrix_norm(A)
A52o1 = matrix_norm(A, ord=1)

########################## Function 53 - [sign, logdet] = slogdet(A)
# NumPy:   np.linalg.slogdet
# Does:    the sign of det(A) and log|det(A)|, safe for very large determinants
# Inputs:  A - square matrix
[A53os, A53ol] = slogdet([4, 1; 2, 3])

########################## Function 54 - pinv(A)
# NumPy:   np.linalg.pinv
# Does:    the Moore-Penrose pseudo-inverse (works for any shape)
# Inputs:  A - matrix
A54o = pinv([1, 2; 3, 4; 5, 6])

########################## Function 55 - solve(A, b)
# NumPy:   np.linalg.solve
# Does:    x with A*x = b
# Inputs:  A - square, invertible matrix; b - column (or matrix of columns)
A = [3, 1; 1, 2];
b = [9; 8];
A55o = solve(A, b)

########################## Function 56 - [x, residuals, rank, s] = lstsq(A, b[, rcond])
# NumPy:   np.linalg.lstsq
# Does:    the least-squares x minimising |A*x - b|, the residual sums, the
#          rank of A and its singular values
# Inputs:  A - matrix; b - column(s) with as many rows as A
#          rcond - [optional] singular values below rcond*max(s) count as
#          zero; left out: machine epsilon * max(rows, columns), as NumPy
Xa = [0, 1; 1, 1; 2, 1; 3, 1];
Y  = [-1; 0.2; 0.9; 2.1];
[A56x, A56r, A56k, A56s] = lstsq(Xa, Y)
A56o1 = lstsq(Xa, Y, rcond=0.5)

########################## Function 57 - [V, D] = eig(A)
# NumPy:   np.linalg.eig
# Does:    eigenvalues of A as a column; with two outputs the eigenvectors V
#          and the diagonal D with A*V = V*D
# Inputs:  A - square matrix
A = [1, -2; 2, 1];
A57o = eig(A)
[A57oV, A57oD] = eig(A)

########################## Function 58 - eigvr(A) / eigvl(A)
# NumPy:   scipy-style right / left eigenvectors (np.linalg.eig gives the right)
# Does:    right eigenvectors (A*v = lambda*v) or left (w'*A = lambda*w') as columns
# Inputs:  A - square matrix
B = [1, 2, 0; 0, 3, 1; 0, 0, 4];
A58o  = eigvr(B)
A58o1 = eigvl(B)

########################## Function 59 - eig_ascend(A)
# NumPy:   np.linalg.eigvalsh
# Does:    the eigenvalues of a symmetric matrix, smallest first
# Inputs:  A - real symmetric (or complex Hermitian) matrix
A59o = eig_ascend([1, 2; 2, 1])

########################## Function 60 - [U, S, Vh] = svd(A)
# NumPy:   np.linalg.svd
# Does:    A = U * diag(S) * Vh; one output gives the singular values only
# Inputs:  A - matrix
A = [1, 0, -1; 0, 1, 0; 1, 1, 1];
[A60oU, S, Vh] = svd(A)

########################## Function 61 - svdvals(A)
# NumPy:   np.linalg.svdvals
# Does:    the singular values, largest first
# Inputs:  A - matrix
A61o = svdvals(A)

########################## Function 62 - [Q, R] = qr(A)
# NumPy:   np.linalg.qr
# Does:    A = Q*R with Q orthonormal and R upper triangular
# Inputs:  A - matrix
[Q, R] = qr([1, 2; 3, 4])

########################## Function 63 - cholesky(A)
# NumPy:   np.linalg.cholesky
# Does:    the lower-triangular L with A = L*L'
# Inputs:  A - symmetric positive-definite matrix
A63o = cholesky([4, 12, -16; 12, 37, -43; -16, -43, 98])

########################## Function 64 - cond(A, p=2)
# NumPy:   np.linalg.cond
# Does:    the condition number: how much A can magnify errors
# Inputs:  A - matrix; p - 2 (default), 1, inf, "fro"
A64o  = cond([1, 2; 3, 4])
A64o1 = cond([2, 0; 0, 1], p=1)

########################## Function 65 - tensorinv(A, ind=2)
# NumPy:   np.linalg.tensorinv
# Does:    the inverse of an N-D A with respect to its first ind axes; the
#          result has A's other axes first, then its first ind axes
# Inputs:  A - matrix or N-D matrix; ind - how many leading axes, default 2
#          (for an ordinary square matrix use ind=1)
A65o = tensorinv([4, 7; 2, 6], ind=1)
T  = reshape([2, 0, 0, 0, 0, 3, 0, 0, 0, 0, 4, 0, 0, 0, 0, 5], [2, 2, 2, 2]);
Ti = tensorinv(T)
A65o1 = shape(Ti)

########################## Function 66 - tensorsolve(A, b[, axes])
# NumPy:   np.linalg.tensorsolve
# Does:    x with tensordot(A, x, x.ndim) = b; x takes A's last axes
# Inputs:  A - matrix or N-D matrix; b - its first axes' worth of values
#          axes - [optional] axes of A moved to the end first
A66o  = tensorsolve([3, 1; 1, 2], [9, 8])
A66o1 = tensorsolve(T, [2, 3; 4, 5])

########################## Function 67 - diagonal(A, k=0)
# NumPy:   np.diagonal
# Does:    the k-th diagonal of A (k > 0 above the main one, k < 0 below)
# Inputs:  A - matrix; k - default 0
A = [1, 2, 3; 4, 5, 6; 7, 8, 9];
A67o  = diagonal(A)
A67o1 = diagonal(A, k=1)

########################## Function 68 - convolve(a, v, mode="full")
# NumPy:   np.convolve
# Does:    the discrete convolution of two vectors
# Inputs:  a, v - vectors; mode - "full" (default), "same" or "valid"
A68o  = convolve([1, 2, 3], [0, 1, 0.5])
A68o1 = convolve([1, 2, 3], [0, 1, 0.5], mode="same")

########################## Function 69 - polyfit(x, y, deg)
# NumPy:   np.polyfit
# Does:    least-squares polynomial of degree deg, highest power first
# Inputs:  x, y - vectors of the same length; deg - whole number
X = [0, 1, 2, 3];
Y = [-1, 0.2, 0.9, 2.1];
A69o = polyfit(X, Y, 1)

########################## Function 70 - polyval(p, x)
# NumPy:   np.polyval
# Does:    the polynomial p at every element of x
# Inputs:  p - coefficients, highest power first (or a poly1d); x - values
A70o = polyval([2, 3, 1], [0, 1, 2])

########################## Function 71 - P = poly1d(c, r=false, variable="x")
# NumPy:   np.poly1d
# Does:    a polynomial VALUE. P(x) is its value at x, P[k] the coefficient
#          of x^k, P.coeffs / P.order / P.roots its parts
# Inputs:  c - coefficients, highest power first (roots when r=true)
#          r - true: c are the roots; variable - the letter used to print it
PDD = poly1d([2, 3, 1])
A71o  = PDD(2)
A71o1 = PDD([0, 1, 2])
A71o2 = PDD[2]
A71o3 = PDD.order
A71o4 = PDD.roots
Q71   = poly1d([1, 2], r=true)
T71   = poly1d([1, 0, -1], variable="t")

########################## Function 72 - roots(p)
# NumPy:   np.roots
# Does:    the roots of the polynomial p, as a column (complex where needed)
# Inputs:  p - coefficients, highest power first (or a poly1d)
A72o  = roots([1, -3, 2])
A72o1 = roots([1, 0, 1])

########################## Function 73 - poly(r)
# NumPy:   np.poly
# Does:    the polynomial with roots r, or the characteristic polynomial of
#          a square matrix
# Inputs:  r - vector of roots, or a square matrix
r73  = [1, 2];
A73o = poly(r73)

########################## Function 74 - polyadd(p1, p2)
# NumPy:   np.polyadd
# Does:    p1 + p2 (coefficients lined up at the constant term)
# Inputs:  p1, p2 - coefficient vectors (or poly1d values)
A74o = polyadd([1, 2, 3], [4, 5])

########################## Function 75 - polysub(p1, p2)
# NumPy:   np.polysub
# Does:    p1 - p2
# Inputs:  p1, p2 - coefficient vectors (or poly1d values)
A75o = polysub([1, 2, 3], [1, 1])

########################## Function 76 - polymul(p1, p2)
# NumPy:   np.polymul
# Does:    p1 * p2
# Inputs:  p1, p2 - coefficient vectors (or poly1d values)
A76o = polymul([1, 2], [1, 3])

########################## Function 77 - [q, r] = polydiv(p1, p2)
# NumPy:   np.polydiv
# Does:    quotient q and remainder r of p1 / p2
# Inputs:  p1, p2 - coefficient vectors (or poly1d values)
[quotient, remainder] = polydiv([1, 3, 2], [1, 1])

########################## Function 78 - polyder(p, m=1)
# NumPy:   np.polyder
# Does:    the m-th derivative of p
# Inputs:  p - coefficients (or a poly1d); m - how many times, default 1
A78o  = polyder([1, 3, 2])
A78o1 = polyder([1, 3, 2], m=2)
A78o2 = polyder(PDD)

########################################################################
# Scalar Math (NumPy section 8). Every function works element by element
# on a number, a vector or a matrix.
########################################################################

########################## Function S01 - floor_divide(A, n)
# NumPy:   np.floor_divide
# Does:    A / n rounded DOWN (-7 / 2 gives -4); the // operator truncates
# Inputs:  A - values; n - divisors (same size, or one number)
S01o = floor_divide([7, -7, 9], 2)

########################## Function S02 - power(A, n)
# NumPy:   np.power
# Does:    every element to the power n (A^n on a matrix is the matrix power)
# Inputs:  A - values; n - powers (same size, or one number)
S02o = power([1, 2; 3, 4], 2)

########################## Function S03 - reciprocal(A)
# NumPy:   np.reciprocal
# Does:    1/x for every element (1/A on a matrix is the inverse)
# Inputs:  A - values
S03o = reciprocal([1, 2; 4, 8])

########################## Function S04 - clip(A, lo, hi)
# NumPy:   np.clip
# Does:    every element limited to the range lo..hi
# Inputs:  A - values; lo - lower limit; hi - upper limit
S04o  = clip([1, 5, 9], 2, 6)
S04o1 = clip([1, 5, 9], lo=0, hi=4)

########################## Function S05 - bitwise_and(A, B)
# NumPy:   np.bitwise_and
# Does:    bit-by-bit AND of whole numbers (or true/false)
# Inputs:  A, B - whole numbers (same size, or one number)
S05o = bitwise_and([12, 10], 6)

########################## Function S06 - bitwise_or(A, B)
# NumPy:   np.bitwise_or
# Does:    bit-by-bit OR
# Inputs:  A, B - whole numbers
S06o = bitwise_or([12, 10], 6)

########################## Function S07 - bitwise_xor(A, B)
# NumPy:   np.bitwise_xor
# Does:    bit-by-bit exclusive OR
# Inputs:  A, B - whole numbers
S07o = bitwise_xor([12, 10], 6)

########################## Function S08 - left_shift(A, n)
# NumPy:   np.left_shift
# Does:    A * 2^n by moving the bits left (an overflow is an error)
# Inputs:  A - whole numbers; n - how many places
S08o = left_shift([1, 3, 5], 2)

########################## Function S09 - right_shift(A, n)
# NumPy:   np.right_shift
# Does:    A / 2^n rounded down, by moving the bits right
# Inputs:  A - whole numbers; n - how many places
S09o = right_shift([16, 7, -7], 1)

########################## Function S10 - bitwise_count(A)
# NumPy:   np.bitwise_count
# Does:    how many bits are 1 in |x|
# Inputs:  A - whole numbers
S10o = bitwise_count([0, 7, 255])

########################## Function S11 - invert(A)
# NumPy:   np.invert (on booleans)
# Does:    true becomes false and false becomes true
# Inputs:  A - true/false values
S11o = invert([true, false])

########################## Function S12 - euler_gamma
# NumPy:   np.euler_gamma
# Does:    the Euler-Mascheroni constant 0.5772156649015329. A variable
#          you name euler_gamma yourself is used instead of it.
# Inputs:  none (a constant)
S12o = euler_gamma
S12o1 = 2 * euler_gamma
####################################################################
####################################################################
