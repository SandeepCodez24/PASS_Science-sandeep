# Rule 1: defaults in the header
function f(a=1, b=2, c="car"):
   publish("a =", a, " b =", b, " c =", c)
fnend
f()
f(10)
f(10, 20, "bus")

# Rule 2: plain or named
function C = Add(x1, x2):
   C = x1 + x2;
fnend
C = Add(x1=10, x2=15);
publish("Add(x1=10, x2=15) =", C)
C = Add(x2=15, x1=10);
publish("Add(x2=15, x1=10) =", C)

# Rules 3/4: a mixture; plain values fill the open inputs left to right
function F(A1, A2, A3, A4, A5):
   publish("A1 =", A1, " A2 =", A2, " A3 =", A3, " A4 =", A4, " A5 =", A5)
fnend
F(A2=10, A4=15, 1, 2, 3)
F(1, A3=5, 2, 3, 4)
F(10, 20, A1=5, 30, 40)
F(A5=5, A4=4, A3=3, A2=2, A1=1)

# Rule 5: defaults skipped at the call
function y = G(a, b=100, c=1000):
   y = a + b + c;
fnend
publish("G(1) =", G(1))
publish("G(1, c=0) =", G(1, c=0))
publish("G(c=0, a=5) =", G(c=0, a=5))

# Defaults may use another input, and come before a required one (plan a)
function H(a, b=a*2):
   publish("a =", a, " b =", b)
fnend
H(4)
H(4, 1)
function K(a=1, b):
   publish("a =", a, " b =", b)
fnend
K(b=7)
K(5, 6)
