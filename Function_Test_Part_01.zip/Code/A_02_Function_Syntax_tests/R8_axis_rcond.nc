# R8: axis for dot / cross, rcond for lstsq
A = [1,2,3;4,5,6]
B = [7,8,9;1,2,3]
dot(A, B)
dot(A, B, axis=0)
dot(A, B, axis=1)
dot(A, B, axis=-1)
cross(A, B)
cross(A, B, axis=1)
cross([1,2;3,4;5,6], [6,5;4,3;2,1], axis=0)
M = [1,1;1,1.0000001;1,1]
y = [1;2;3]
x2 = lstsq(M, y, rcond=1e-3)
[x, res, rk, s] = lstsq([1,0;0,1;1,1], [1;2;4])
[x, res, rk, s] = lstsq(M, y, rcond=1e-3)
dot(A, B, axis=2)
