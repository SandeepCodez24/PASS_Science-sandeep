# R2: allclose / isclose - atol 0.1 by default, third plain value = atol
A = [1,1,1;1,1,1;1,1,1];
B = [0.99999999,0.91,0.999; 1.000001, 1.0000, 1.00001; 0.999999,0.999999,0.99999];
publish("allclose(A,B)          ", allclose(A, B))
publish("allclose(A,B,0.05)     ", allclose(A, B, 0.05))
publish("allclose(A,B,atol=0.2) ", allclose(A, B, atol=0.2))
publish("allclose(A,B,atol=0,rtol=0.1)", allclose(A, B, atol=0, rtol=0.1))
I = isclose(A, B, atol=0.05)
J = isclose(1, 1.05)
K = isclose(1, 1.2)
