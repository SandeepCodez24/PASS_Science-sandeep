# R7: euler_gamma constant; a variable of the same name wins
a = euler_gamma
b = 2 * euler_gamma;
b
function y = useg():
    y = euler_gamma
fnend
useg()
euler_gamma = 5
c = euler_gamma + 1
function y = useg2():
    euler_gamma = 7
    y = euler_gamma
fnend
useg2()
useg()
