# Language changes made for the loaded objects (parser_factor.cpp):
#  - postfix chains of .field / [index] / .method() to any depth
#  - D.method(...) on a runtime-built object calls the builtin <Class>.<method>
# and the forms that must keep working exactly as before.
class Inner():
    function base(v):
        base.v = v;
        base.m = [1, 2; 3, 4];
    fnend
    function out = twice():
        out = base.v * 2;
    fnend
    function base = bump():
        base.v = base.v + 1;
    fnend
csend
class Outer():
    function base(v):
        base.inn = Inner(v);
        base.list = [10, 20, 30];
    fnend
csend
o = Outer(5);
publish(o.inn.v)
publish(o.inn.m[1, 0])
publish(o.inn.m[0][1])
publish(o.inn.twice())
publish(o.list[2])
i = Inner(1);
i.bump();
publish(i.v)
i = i.bump();
publish(i.v)
d = dict();
d["a"] = [7, 8, 9];
publish(d["a"][1])
publish(keys(d)[0])
publish(d.keys())
A = [1, 2; 3, 4];
publish(A[1, 1])
publish(A[0][1])
publish(A*.A)
x = [1, 2, 3];
publish(x[2])
J = load_json("data/weather.json");
publish(J.store.book[1].title)
publish(J.sensor.keys())
publish(load_json("data/weather.json").sensor.name)
publish(J.query("$.store.book[0].price"))
