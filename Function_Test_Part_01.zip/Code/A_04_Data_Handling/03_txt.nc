# CATEGORY 2 - read_txt / load_txt / save_txt (runs of blanks, "\s+", by default).
T = read_txt("data/spectrum.txt")
[T, info] = read_txt("data/spectrum.txt", cols=["wavelength", "flag"]);
publish(T)
publish(info.boxes)
publish(info.dlm)
W = load_txt("data/spectrum.txt");
publish(W.intensity)
publish(W.schema)
n = save_txt("out/x1.txt", W.default, boxes=["Spectrometer: OSA-7"])
publish(read_txt("out/x1.txt"))
n2 = save_txt("out/x2.txt", [1, 22.5; 333, 4], dlm="\t", hdr=true)
publish(read_txt("out/x2.txt", dlm="\t"))
