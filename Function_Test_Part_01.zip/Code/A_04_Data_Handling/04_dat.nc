# CATEGORY 2 - read_dat / load_dat / save_dat ("auto" sniffs the delimiter).
T = read_dat("data/probe.dat", cmt="%")
[T, info] = read_dat("data/probe.dat", cmt="%");
publish(info.dlm)
publish(info.comments)
D = load_dat("data/probe.dat", cmt="%");
publish(D.Col_2)
publish(D.comments)
n = save_dat("out/d1.dat", T, boxes=["probe export v3"])
publish(read_dat("out/d1.dat"))
n2 = save_dat("out/d2.dat", T, dlm=",", float_fmt="%.2f")
publish(read_dat("out/d2.dat"))
