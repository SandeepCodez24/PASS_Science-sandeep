# CATEGORY 15 - read_/load_/save_ wav, flac (ogg / mp3: tags and length only).
t = [0:44099] / 44100;
L = sin(2 * pi * 440 * t);
R = 0.5 * sin(2 * pi * 660 * t);
st = transpose([L; R]);
n1 = save_wav("out/s.wav", st, fs=44100, boxes=dict(["title", "comment"], ["TestTone", "Mic1"]))
n2 = save_flac("out/s.flac", st, fs=44100, bits=24)
n3 = save_wav("out/s32.wav", L, bits=32, norm=true)
n4 = save_flac("out/small.flac", st, max_size="40kb")
[a, afs, ai] = read_wav("out/s.wav");
publish(afs)
publish(ai.boxes)
publish(max(abs(flatten(a) - flatten(st))) < 0.0001)
[b, bfs, bi] = read_flac("out/s.flac");
publish(max(abs(flatten(b) - flatten(st))) < 0.00001)
publish(size(read_wav("out/s.wav", start=0.5, dur=0.1, mono=true, fs=8000)))
D = load_flac("out/s.flac");
publish(D.duration)
S = D.slice(0.25, 0.5);
publish(S.duration)
publish(size(S.left))
