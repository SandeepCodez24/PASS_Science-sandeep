# CATEGORY 10 - read_/load_/save_ h5, hdf, he5.
publish("== save_h5: one tensor to /data, then a dict (one dataset per key) with attrs and boxes")
A = [1, 2, 3; 4, 5, 6];
n1 = save_h5("out/a.h5", A)
publish(read_h5("out/a.h5"))
d = dict();
d["temp"] = [10.5, 11.5, 12.5, 13.5];
d["name"] = "run 7";
d["grid"] = reshape([1:24], [2, 3, 4]);
n2 = save_h5("out/b.h5", d, attrs=dict(["units"], ["K"]), boxes="Run notes", chunks=[1, 2], level=6, shuffle=false)
[T, info] = read_h5("out/b.h5");
publish(info.datasets)
publish(info.boxes)
publish("== read_h5: path=, slice= (1-based; a single index drops that dimension), attr=, box=")
publish(read_h5("out/b.h5", path="/grid", slice="1:2, 2, 3:4"))
[g, gi] = read_h5("out/b.h5", path="/temp", attr=false, box=false);
publish(gi.shape)
publish("== load_h5: dot access, shapes, lazy reads")
D = load_h5("out/b.h5");
publish(D.datasets)
publish(D.temp.shape)
publish(D.temp.data)
publish(D.grid.chunks)
publish(D.grid.read("1, :, 1"))
publish(D.read("temp", "2:3"))
publish(D.attrs)
publish("== mode=a adds a dataset (LZF compression); compress=none / chunks=none")
n3 = save_h5("out/b.h5", [7, 8, 9], path="/extra/v", mode="a", compress="lzf")
E = load_h5("out/b.h5");
publish(E.datasets)
publish(E.extra.v.data)
publish(E.extra.v.compression)
n4 = save_hdf("out/c.hdf", A, compress="none", chunks="none")
publish(load_hdf("out/c.hdf").data.compression)
publish("== HDF-EOS5: data goes to a swath")
n5 = save_he5("out/e.he5", d)
publish(read_he5("out/e.he5", swath="Swath1", path="temp"))
publish(load_he5("out/e.he5").swaths.Swath1.groups)
publish("== files written by MATLAB (old format; newest format with dense groups and v4 chunk indexes)")
M = load_h5("data/foreign/ml_old.h5");
publish(M.sim.velocity.shape)
publish(M.sim.velocity.attrs)
publish(read_h5("data/foreign/ml_old.h5", path="/sim/velocity", slice="1, 1:3, 1:4"))
N = load_h5("data/foreign/ml_new.h5");
publish(N.format)
publish(N.grp.v20.data)
publish(N.fixed.data)
publish(N.single.data)
