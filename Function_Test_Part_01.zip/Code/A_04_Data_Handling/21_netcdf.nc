# CATEGORY 11 - read_/load_/save_ nc, cdf (NetCDF-4 and classic).
lat = [10, 12.5, 15, 17.5, 20];
lon = [75, 80, 85];
temp = reshape([1:30], [2, 5, 3]) + 270;
cs = dict();
cs["lat"] = lat;
cs["lon"] = lon;
publish("== save_nc: NetCDF-4 (zlib), classic, 64-bit offset")
n1 = save_nc("out/w4.nc", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, units="K", fill_val=-9999, unlimited="time", level=4, boxes=dict(["title"], ["Ocean Model"]))
n2 = save_nc("out/wc.nc", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, units="K", format="classic", unlimited="time")
n3 = save_cdf("out/w64.cdf", temp, var="temp", dims=["time", "lat", "lon"], coords=cs, format="64bit", compress="none")
for f in ["out/w4.nc", "out/wc.nc", "out/w64.cdf"]:
   D = load_nc(f);
   publish(D.format)
   publish(D.vars)
   publish(D.dims)
   publish(D.temp.sel(lat=13, lon=80))
fend
publish("== read_nc: main variable, coords= by value, slice=, scale=")
[T, info] = read_nc("out/w4.nc");
publish(info.dims)
publish(info.units)
publish(info.coords)
cc = dict();
cc["lat"] = [12, 18];
cc["lon"] = 85;
publish(read_nc("out/w4.nc", coords=cc, slice="2"))
publish(read_cdf("out/w64.cdf", var="lat", scale=false, box=false))
D = load_nc("out/w4.nc");
publish(D.coords.lat)
publish(D.temp.fill_val)
publish(D.attrs.title)
publish(D.read("temp", "1, 1, :"))
publish("== files written by MATLAB (scale_factor / add_offset / _FillValue, char variable)")
for f in ["data/foreign/ml_classic.nc", "data/foreign/ml_netcdf4.nc"]:
   [s, si] = read_nc(f, var="sst");
   publish(si.format)
   publish(s)
   M = load_nc(f);
   publish(M.name.data)
   publish(M.sst.sel(lat=20, lon=[75, 80]))
fend
