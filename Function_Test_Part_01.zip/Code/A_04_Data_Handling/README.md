# I/O examples and tests (read_ / load_ / save_)

Example NC scripts for the 168 functions of `Functions_Importing_Data.pdf`
(56 formats x read / load / save), with the options of each function used,
plus one script per failure condition.

```
src/test/io/
├── data/                sample inputs (csv, tsv, txt, dat, json, ndjson, xml, xsd, html, yaml, yml, ini, ...)
├── data/foreign/        files written by other software (see below) - the readers are tested on them too
├── scripts/             01_csv.nc ... 26_gps.nc     (run in this order; 12 uses files 10/11 write)
├── scripts/errors/      e01_missing_file.nc ... e38_sqlite_mode.nc (each stops with one clear error)
├── scripts/optional/    url_sources.nc (needs network), databases_server.nc (needs PostgreSQL / MySQL) - not compared
├── expected/            the reviewed output of each script
├── out/                 files the scripts write (emptied on every run)
├── run_io_tests.ps1     Windows runner
└── run_io_tests.sh      bash runner
```

| Script | Formats |
|---|---|
| 01-11 | csv tsv txt dat, json, xml, html htm, yaml yml ini, bin, custom (phase 1) |
| 12, 13 | ImportSession functions (io_formats, io_detect, io_options, io_preview, io_code); chained dot access |
| 14 | xlsx xls xlsm xlsb |
| 15 | png jpg jpeg tiff bmp gif dicom |
| 16 | wav flac (ogg / mp3: tags and length) |
| 17 | mat (v5, v7, v7.3) and fig |
| 18 | fits fit |
| 19 | sqlite (postgresql / mysql: optional/databases_server.nc) |
| 20 | h5 hdf he5 |
| 21 | nc cdf |
| 22 | parquet feather orc |
| 23 | mp4 avi m4v mov |
| 24 | shp shx dbf |
| 25 | tif geotiff |
| 26 | gpx kml (kmz) |

