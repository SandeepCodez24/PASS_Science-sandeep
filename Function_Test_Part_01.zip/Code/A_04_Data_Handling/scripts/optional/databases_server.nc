# Needs running servers (not compared by run_io_tests): PostgreSQL 12+ and MySQL 8 on localhost.
# Change the URIs to your servers. PostgreSQL: password / md5 / SCRAM-SHA-256 logins; MySQL: native or
# cached caching_sha2 logins (plain TCP, no TLS).
T = ["id", "name", "score"; 1, "ann", 9.5; 2, "bob", 7.25]
n = save_postgresql("postgresql://postgres:postgres@localhost:5432/postgres", T, table="nc_demo", mode="replace", pk="id", index="score", boxes="NC demo table")
publish(read_postgresql("postgresql://postgres:postgres@localhost:5432/postgres", table="nc_demo", where="score > 8"))
P = load_postgresql("postgresql://postgres:postgres@localhost:5432/postgres");
publish(P.nc_demo.cols)
publish(P.query("SELECT COUNT(*) AS n FROM nc_demo").data)
m = save_mysql("mysql://root:root@localhost:3306/test", T, table="nc_demo", mode="replace", pk="id")
publish(read_mysql("mysql://root:root@localhost:3306/test", query="SELECT name FROM nc_demo WHERE score > ?", params=[8]))
