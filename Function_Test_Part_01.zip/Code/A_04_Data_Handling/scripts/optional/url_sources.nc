# Reading straight from the web (needs network; run with  run_io_tests.ps1 -Online).
# All sources are openly licensed data sets:
#   plotly/datasets (MIT)          https://github.com/plotly/datasets
#   vega/vega-datasets (BSD-3)     https://github.com/vega/vega-datasets
#   Wikipedia (CC BY-SA 4.0)       https://en.wikipedia.org
# Only shapes are published, since the live content can change.
[S, si] = read_csv("https://raw.githubusercontent.com/plotly/datasets/master/2014_usa_states.csv");
publish(si.cols)
publish(size(S))
C = read_json("https://raw.githubusercontent.com/vega/vega-datasets/main/data/cars.json");
publish(size(C))
W = load_html("https://en.wikipedia.org/wiki/Comma-separated_values");
publish(W.title)
publish(size(W.links))
T = read_html("https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population", table=0);
publish(size(T))
P = io_preview("https://raw.githubusercontent.com/plotly/datasets/master/2014_usa_states.csv", 3, "csv");
publish(P.rows)
