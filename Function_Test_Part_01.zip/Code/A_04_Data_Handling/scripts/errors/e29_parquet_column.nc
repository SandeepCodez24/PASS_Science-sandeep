# Requested cols must exist in the footer schema.
n = save_parquet("out/e.parquet", ["a", "b"; 1, 2]);
x = read_parquet("out/e.parquet", cols=["zz"]);
