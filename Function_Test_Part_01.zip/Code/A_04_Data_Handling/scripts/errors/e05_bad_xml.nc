# Sufficient condition: properly nested / closed tags.
X = read_xml("data/bad.xml");
