# Sufficient condition: the requested columns exist.
T = read_csv("data/sensors.csv", cols=["ID", "Nope"]);
