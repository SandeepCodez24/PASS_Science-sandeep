# max_size budget: refuse output larger than the limit.
n = save_csv("out/e09.csv", [1, 2; 3, 4], max_size="4b");
