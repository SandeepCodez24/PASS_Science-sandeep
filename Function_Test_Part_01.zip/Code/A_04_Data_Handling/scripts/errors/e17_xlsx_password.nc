# Encrypted workbooks are not built in: pass= is refused clearly.
T = read_xlsx("data/foreign/office.xlsx", pass="secret");
