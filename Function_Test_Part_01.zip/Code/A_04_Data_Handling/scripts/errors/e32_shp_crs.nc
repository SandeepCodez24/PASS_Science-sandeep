# Reprojection is built in for WGS84 / Web Mercator / UTM only.
n = save_shp("out/e.shp", ["geometry"; "POINT (1 2)"]);
x = read_shp("out/e.shp", crs="EPSG:27700");
