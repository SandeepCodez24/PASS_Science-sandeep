# Only h264 (I_PCM) and mjpeg are written.
n = save_mp4("out/e.mp4", zeros([2, 16, 16, 3]), codec="hevc");
