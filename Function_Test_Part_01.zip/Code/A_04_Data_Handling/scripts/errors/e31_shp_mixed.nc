# Sufficient condition: all geometries of one shapefile share a type.
n = save_shp("out/e.shp", ["geometry"; "POINT (1 2)"; "LINESTRING (0 0, 1 1)"]);
