# Sufficient condition: INI holds section -> key -> value only.
d = dict();
inner = dict();
inner["deep"] = dict(["x"], [1]);
d["S"] = inner;
n = save_ini("out/e12.ini", d);
