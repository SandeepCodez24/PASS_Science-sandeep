# save_<db> mode must be append, replace, upsert or fail.
n = save_sqlite("out/e.sqlite", ["a"; 1], mode="merge");
