# Sufficient condition: the data part is a whole number of items.
n = save_bin("out/e10.bin", [1, 2, 3], dtype="int8");
x = read_bin("out/e10.bin", dtype="int16");
