# Sufficient condition: each axis length matches its coordinate vector.
c = dict();
c["lat"] = [1, 2];
x = save_nc("out/e.nc", zeros([2, 3]), dims=["time", "lat"], coords=c);
