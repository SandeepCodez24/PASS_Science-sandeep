# Minimum condition: a .mp3 must hold MPEG audio frames (here: a WAV renamed).
n = save_wav("out/e.wav", [0, 0.5, -0.5]);
y = read_mp3("out/e.wav");
