# Sufficient condition: XML tag names are valid QNames.
T = ["Max Temp", "ok"; 1, 2];
n = save_xml("out/e11.xml", T);
