# Audio in .mp4 needs AAC (not built in): .mov / .avi take PCM.
n = save_mp4("out/e.mp4", zeros([2, 16, 16, 3]), codec="mjpeg", audio=[0, 0.1, 0.2]);
