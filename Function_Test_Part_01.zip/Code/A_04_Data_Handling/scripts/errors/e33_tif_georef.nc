# Minimum condition: a GeoTIFF needs transform= or bbox=.
n = save_tif("out/e.tif", [1, 2; 3, 4]);
