# Valid band indices (1-based).
n = save_tif("out/e.tif", [1, 2; 3, 4], bbox=[0, 0, 1, 1]);
x = read_tif("out/e.tif", bands=[2]);
