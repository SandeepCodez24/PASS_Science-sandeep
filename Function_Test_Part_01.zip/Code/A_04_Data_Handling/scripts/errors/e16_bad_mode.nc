# mode must be "w" or "a".
n = save_csv("out/e16.csv", [1, 2], mode="x");
