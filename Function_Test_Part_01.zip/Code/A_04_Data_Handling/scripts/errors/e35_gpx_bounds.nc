# Sufficient condition: lat in [-90, 90], lon in [-180, 180].
n = save_gpx("out/e.gpx", lat=[95, 30], lon=[79, 79]);
