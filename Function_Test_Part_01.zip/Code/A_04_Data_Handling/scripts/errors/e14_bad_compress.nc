# compress= names a codec that is not built in.
n = save_csv("out/e14.csv", [1, 2], compress="zstd");
