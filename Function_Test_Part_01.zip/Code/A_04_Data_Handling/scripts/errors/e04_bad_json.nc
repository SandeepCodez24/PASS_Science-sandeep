# Sufficient condition: well-formed JSON (balanced brackets).
J = read_json("data/bad.json");
