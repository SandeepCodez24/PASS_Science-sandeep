# .xlsb is read-only.
n = save_xlsb("out/x.xlsb", [1, 2]);
