# A database server that is not running is reported as such.
T = read_postgresql("postgresql://u:p@127.0.0.1:1/db", table="x");
