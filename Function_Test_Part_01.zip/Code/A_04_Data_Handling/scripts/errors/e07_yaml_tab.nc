# Sufficient condition: no raw tabs in YAML indentation.
Y = read_yaml("data/tab.yaml");
