# Sufficient condition: the requested sheet exists.
T = read_csv("data/multi.csv", sheet="Nope");
