# Minimum condition: a readable file path.
T = read_csv("data/nope.csv");
