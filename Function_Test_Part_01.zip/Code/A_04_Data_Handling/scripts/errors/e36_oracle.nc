# Oracle / SQL Server need their own client protocols, which are not built in.
T = read_oracle("oracle://user:pw@localhost:1521/XE", table="t");
