# Sufficient condition: matches the XSD when validation is asked for.
X = read_xml("data/bad_catalog.xml", validate_xsd="data/catalog.xsd");
