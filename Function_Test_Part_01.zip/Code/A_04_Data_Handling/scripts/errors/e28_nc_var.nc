# Requested var must exist.
n = save_nc("out/e.nc", [1, 2, 3], var="temp");
x = read_nc("out/e.nc", var="pressure");
