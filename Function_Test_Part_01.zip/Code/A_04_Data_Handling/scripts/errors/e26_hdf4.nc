# HDF4 files are recognised and refused with a pointer to h4toh5.
n = save_bin("out/e.hdf", [14, 3, 19, 1, 0, 0, 0, 0], dtype="uint8");
x = read_hdf("out/e.hdf");
