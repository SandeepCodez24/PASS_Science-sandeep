# Sufficient condition: slice bounds inside the dataset.
n = save_h5("out/e.h5", [1, 2, 3]);
x = read_h5("out/e.h5", path="/data", slice="1:5");
