# A method a loaded object does not have.
D = load_csv("data/sensors.csv");
x = D.nosuch(1);
