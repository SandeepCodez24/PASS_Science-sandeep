# read_html needs at least one <table> unless css/xpath/links is used.
T = read_html("data/notable.html");
