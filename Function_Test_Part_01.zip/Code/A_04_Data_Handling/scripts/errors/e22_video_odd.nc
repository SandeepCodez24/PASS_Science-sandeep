# Sufficient condition: yuv420p H.264 needs an even height and width.
n = save_mp4("out/e.mp4", zeros([2, 15, 16, 3]));
