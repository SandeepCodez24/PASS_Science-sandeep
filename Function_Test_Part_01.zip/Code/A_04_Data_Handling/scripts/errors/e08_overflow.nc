# Sufficient condition: values fit the target dtype (no silent overflow).
n = save_bin("out/e08.bin", [12, 300], dtype="uint8");
