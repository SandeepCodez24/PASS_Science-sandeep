# Arrow IPC (feather) supports lz4 / zstd only.
n = save_feather("out/e.feather", ["a"; 1; 2], compress="snappy");
