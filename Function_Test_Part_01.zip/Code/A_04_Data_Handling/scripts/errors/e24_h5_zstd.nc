# HDF5 compress="zstd" is not built in (gzip, lzf are).
n = save_h5("out/e.h5", [1, 2, 3], compress="zstd");
