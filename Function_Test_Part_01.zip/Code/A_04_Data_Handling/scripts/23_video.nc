# CATEGORY 16 - read_/load_/save_ mp4, avi, m4v, mov. Frames are numbered from 0.
F = zeros([6, 48, 64, 3]);
for t in [0:5]:
  F[t, :, :, 0] = 40 * t;
  F[t, 0:23, :, 1] = 200;
  F[t, :, 0:31, 2] = 120;
fend
publish("== save: H.264 (exact I_PCM), MJPEG (crf / bitrate / max_size), PCM audio, subtitles")
n1 = save_mp4("out/v.mp4", F, fps=10, boxes=["hello", "world"])
n2 = save_avi("out/v.avi", F, fps=10, codec="mjpeg", crf=18)
n3 = save_mov("out/v.mov", F, fps=10, codec="mjpeg", audio=[0:4409] / 4410, bitrate="2M")
n4 = save_m4v("out/v.m4v", F, fps=12.5, codec="mjpeg", max_size="200kb")
publish("== read_*: frames=, time=, stride=, roi=, scale=, gray=, audio=")
[V, info] = read_mp4("out/v.mp4");
publish(size(V))
publish(V[3, 10, 50, :])
publish(info.subtitles)
publish(size(read_avi("out/v.avi", frames=[0, 2, 4], roi=[10, 10, 20, 16])))
publish(size(read_mov("out/v.mov", time=[0.1, 0.4], stride=2, scale=[32, 24], gray=true)))
[W, wi] = read_mov("out/v.mov", frames=[0], audio=true, box=false);
publish(wi.audio.fs)
publish(wi.audio.frames)
publish("== load_*: video objects")
D = load_avi("out/v.avi");
publish(D.codec)
publish(D.count)
publish(D.fps)
publish(D.frame(5)[40, 10, :])
publish(D.at_time(0.25)[40, 10, 0])
publish(size(D.read(frames=[1, 2])))
M = load_m4v("out/v.m4v");
publish(M.fps)
publish("== files written by MATLAB (Motion JPEG AVI; compressed H.264 is detected, not decoded)")
X = load_avi("data/foreign/ml_mjpeg.avi");
publish(X.codec)
publish(X.count)
publish(read_avi("data/foreign/ml_mjpeg.avi", frames=[4])[0, 10, 40, :])
H = load_mp4("data/foreign/ml_h264.mp4");
publish(H.codec)
publish(H.decodable)
