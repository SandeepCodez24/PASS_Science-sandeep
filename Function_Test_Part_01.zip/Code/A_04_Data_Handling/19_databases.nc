# CATEGORY 20 - read_/load_/save_ sqlite (in-process). postgresql / mysql speak
# their wire protocols (scripts/optional/databases_server.nc needs a server);
# oracle / sqlserver report what they need (scripts/errors).
T = ["id", "name", "age"; 1, "ann", 31; 2, "bob", 22; 3, "cy", 45; 4, "dee", 28]
n = save_sqlite("out/t.sqlite", T, table="users", pk="id", index="age", batch=2)
publish(read_sqlite("out/t.sqlite", table="users"))
publish(read_sqlite("out/t.sqlite", query="SELECT name, age FROM users WHERE age > ? ORDER BY age DESC", params=[25]))
publish(read_sqlite("out/t.sqlite", table="users", where="age >= 28", cols=["name"], limit=2))
D = load_sqlite("out/t.sqlite");
publish(D.tables)
publish(D.users.cols)
publish(D.users.pk)
publish(D.users.types)
Q = D.users.filter("age > 25").limit(2);
publish(Q.rows)
publish(Q.name)
publish(D.query("SELECT COUNT(*) AS n, AVG(age) AS a FROM users").data)
u = save_sqlite("out/t.sqlite", ["id", "name", "age"; 2, "BOB", 23; 5, "eve", 50], table="users", mode="upsert", pk="id")
publish(read_sqlite("out/t.sqlite", table="users"))
r = save_sqlite("out/t.sqlite", ["k"; 1; 2], table="small", mode="replace", boxes="lookup table")
publish(load_sqlite("out/t.sqlite").small.comment)
