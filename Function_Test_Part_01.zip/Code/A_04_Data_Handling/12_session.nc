# The Import-window API from NC: formats, detection, options, preview, code.
# Runs after 10_bin.nc and 11_custom.nc (it detects their output files).
publish(io_formats("structured"))
publish(size(io_formats()))
d = io_detect("data/catalog.xml");
publish(d.format)
publish(d.category)
publish(d.confidence)
publish(d.read)
publish(io_detect("data/sensors.csv").format)
publish(io_detect("data/laps.tsv").format)
publish(io_detect("data/config.yaml").format)
publish(io_detect("data/config.ini").format)
publish(io_detect("data/weather.json").format)
publish(io_detect("data/launches.html").format)
publish(io_detect("data/small.csv.gz").reason)
publish(io_detect("out/b3.bin").format)
publish(io_detect("out/s1.custom").format)
publish(io_detect("not_there.parquet").reason)
o = io_options("json", "read")
s = io_options("csv", "save");
publish(s[:, 0])
p = io_preview("data/sensors.csv", 2);
publish(p.kind)
publish(p.cols)
publish(p.rows)
publish(p.boxes)
publish(p.total_rows)
publish(p.code)
q = io_preview("data/config.yaml", 3);
publish(q.kind)
publish(q.rows)
r = io_preview("data/probe.dat", 5, "csv");
publish(r.rows)
publish(io_code("data/sensors.csv"))
publish(io_code("data/weather.json", "load", "W"))
publish(io_code("out/report.html", "save", "T"))
publish(io_code("D:/runs/x.anything", "read", "X", "dat"))
