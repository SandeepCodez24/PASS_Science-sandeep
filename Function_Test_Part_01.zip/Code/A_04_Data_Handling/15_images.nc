# CATEGORY 14 - read_/load_/save_ png, jpg, jpeg, tiff, bmp, gif, dicom.
publish("== a synthetic 48 x 64 RGB image, saved in every format")
I = zeros([48, 64, 3]);
I[:, :, 0] = 200;
I[0:23, :, 1] = 120;
I[:, 0:31, 2] = 60;
n1 = save_png("out/t.png", I, dpi=300, boxes=dict(["Title"], ["Fig1"]), level=9)
n2 = save_jpg("out/t.jpg", I, quality=90)
n3 = save_jpeg("out/tp.jpeg", I, progressive=true, subsampling="4:4:4")
n4 = save_tiff("out/t.tiff", I, codec="deflate")
n5 = save_bmp("out/t.bmp", I)
n6 = save_gif("out/t.gif", I)
n7 = save_dicom("out/t.dicom", read_png("out/t.png", channels="gray"), patient=dict(["Name"], ["Doe^J"]), anonymize=false)
publish("== lossless formats round-trip exactly; JPEG and GIF stay close")
publish(max(abs(flatten(read_png("out/t.png")) - flatten(I))))
publish(max(abs(flatten(read_tiff("out/t.tiff")) - flatten(I))))
publish(max(abs(flatten(read_bmp("out/t.bmp")) - flatten(I))))
publish(mean(abs(flatten(read_jpg("out/t.jpg")) - flatten(I))) < 3)
publish(mean(abs(flatten(read_jpeg("out/tp.jpeg")) - flatten(I))) < 3)
publish(mean(abs(flatten(read_gif("out/t.gif")) - flatten(I))) < 3)
publish("== read options: roi, channels, dtype, scale")
[P, pi] = read_png("out/t.png", roi=[30, 20, 4, 6], channels="gray", dtype="float32");
publish(size(P))
publish(pi.dpi)
publish(pi.boxes)
publish(size(read_png("out/t.png", scale=[32, 24])))
publish("== load_*: image objects")
L = load_png("out/t.png");
publish(L.width)
publish(L.channels)
D = load_dicom("out/t.dicom");
publish(D.patient)
publish(D.modality)
publish("== files made by other software")
publish(size(read_png("data/foreign/real.png")))
publish(size(read_bmp("data/foreign/real.bmp")))
