# CATEGORY 7 - read_xml / load_xml / save_xml.
publish("== read_xml: repeating records become a table, comments/headers are boxes")
[T, info] = read_xml("data/catalog.xml");
publish(T)
publish(info.cols)
publish(info.root)
publish(info.boxes)
publish(info.namespaces)
publish("== xpath / ns / attr_prefix / box / validate_xsd")
titles = read_xml("data/catalog.xml", xpath="//book[@active='1']/title")
ids = read_xml("data/catalog.xml", xpath="//book/@id")
pricey = read_xml("data/catalog.xml", xpath="//book[price>20]")
last = read_xml("data/catalog.xml", xpath="//book[last()]/title")
pt = read_xml("data/catalog.xml", xpath="//geo:point", ns=dict(["geo"], ["http://example.org/geo"]))
plain = read_xml("data/catalog.xml", attr_prefix="");
publish(plain)
[v, vi] = read_xml("data/catalog.xml", validate_xsd="data/catalog.xsd", box=false);
publish(vi.boxes)
publish("== load_xml: element tree with dot access")
D = load_xml("data/catalog.xml");
publish(D.catalog.book[1].title.text)
publish(D.catalog.book[0].attrs)
publish(D.catalog.book[2].id)
publish(D.catalog.header.text)
publish(D.root.tag)
publish(D.comments)
publish(D.namespaces)
publish(D.xpath("//book[price>20]/title/text()"))
publish(D.catalog.book[0].xpath("price/text()"))
publish("== save_xml")
named = load_csv("data/sensors.csv");
n1 = save_xml("out/x1.xml", named.default)
n2 = save_xml("out/x2.xml", named.default, root="Sensors", row_tag="Sensor", indent=4, cdata=["Name"], boxes=["Calibration Info Box"])
n3 = save_xml("out/x3.xml", D)
cfg = dict();
cfg["@version"] = "2";
cfg["name"] = "rig";
cfg["gain"] = 1.5;
n4 = save_xml("out/x4.xml", cfg, root="Config", compress="gz")
n5 = save_xml("out/x5.xml", named.default, enc="latin-1")
publish(read_xml("out/x2.xml"))
publish(read_xml("out/x3.xml", xpath="//book/@id"))
publish(read_xml("out/x4.xml"))
