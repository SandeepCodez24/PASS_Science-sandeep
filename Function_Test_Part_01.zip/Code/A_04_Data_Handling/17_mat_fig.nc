# CATEGORIES 4 and 5 - read_/load_/save_ mat (v5, v7, v7.3) and fig.
cfg = dict();
cfg["gain"] = 1.25;
cfg["name"] = "rig";
cfg["flags"] = [true, false, true];
v = dict();
v["x"] = [1, 2, 3; 4, 5, 6];
v["y"] = [10:15];
v["cfg"] = cfg;
v["note"] = "hello";
v["cells"] = ["a", "b"];
n1 = save_mat("out/m1.mat", v, boxes="Experiment_Run_42")
n2 = save_mat("out/m2.mat", vars=v, ver="v5")
n2b = save_mat("out/m3.mat", v, ver="v7.3")
w = dict();
w["z"] = 99;
n3 = save_mat("out/m1.mat", w, mode="a")
M = read_mat("out/m1.mat")
publish(read_mat("out/m3.mat"))
x = read_mat("out/m1.mat", vars=["x"])
s = read_mat("out/m2.mat", vars=["x"], slice=dict(["x"], ["1:2, 2:3"]))
[r, info] = read_mat("out/m1.mat", vars=["cfg"], struct_as="object");
publish(r.gain)
publish(info)
D = load_mat("out/m1.mat");
publish(D.vars)
publish(D.cfg.name)
publish(D.info("x"))
publish(D.version)
publish(load_mat("out/m3.mat").version)
publish("== a MATLAB-written v7.3 file")
publish(read_mat("data/foreign/ml73.mat"))
f = dict();
f["x"] = [0:10];
f["y"] = [0:10] * 2;
f["title"] = "Ramp";
f["xlabel"] = "t";
f["ylabel"] = "v";
n4 = save_fig("out/f1.fig", f, boxes=["Peak"])
[F, fi] = read_fig("out/f1.fig");
publish(F)
publish(fi)
G = load_fig("out/f1.fig");
publish(G.axes[0].title)
publish(G.axes[0].lines[0].y)
publish(G.boxes)

n5 = save_fig("out/f2.fig", G);
publish(read_fig("out/f2.fig", series=1, props=["YData"]))
