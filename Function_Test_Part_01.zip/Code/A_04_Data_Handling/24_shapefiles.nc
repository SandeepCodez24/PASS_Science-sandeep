# CATEGORY 17 - read_/load_/save_ shp, shx, dbf.
T = ["NAME", "POP", "geometry"; "Chennai", 7088000, "POINT (80.27 13.08)"; "Pune", 3124000, "POINT (73.86 18.52)"; "Leh", 30870, "POINT (77.58 34.16)"]
n = save_shp("out/cities.shp", T, boxes="Source: Survey 2026")
publish("== read_shp: where=, bbox=, cols=, rows=, crs= (reproject to UTM 44N)")
[S, info] = read_shp("out/cities.shp", where="POP > 100000");
publish(S)
publish(info.crs)
publish(read_shp("out/cities.shp", bbox=[70, 10, 81, 20], cols=["NAME"]))
publish(read_shp("out/cities.shp", crs="EPSG:32644", rows=[1:1], box=false))
publish("== load_shp")
D = load_shp("out/cities.shp");
publish(D.NAME)
publish(D.features[0].geom.x)
publish(D.features[1].attrs)
publish(D.bbox)
publish(D.index_offsets)
publish("== the companions on their own")
publish(read_shx("out/cities.shx"))
publish(read_dbf("out/cities.dbf"))
publish(load_dbf("out/cities.dbf").count)
publish("== polygons with holes, multipolygons, Web Mercator; x / y tables; dbf only")
P = ["id", "geometry"; 1, "POLYGON ((0 0, 10 0, 10 10, 0 10, 0 0), (2 2, 4 2, 4 4, 2 4, 2 2))"; 2, "MULTIPOLYGON (((20 20, 30 20, 30 30, 20 20)), ((40 40, 50 40, 50 50, 40 40)))"]
e = save_shp("out/poly.shp", P, crs="EPSG:3857", geom_type="polygon")
publish(read_shp("out/poly.shp"))
publish(load_shp("out/poly.shp").geom[0].rings)
X = ["x", "y", "label"; 1.5, 2.5, "a"; 3.5, 4.5, "b"]
k = save_shx("out/pts.shx", X, enc="latin-1")
publish(read_shp("out/pts.shp"))
q = save_dbf("out/only.dbf", ["code", "flag"; "A1", true; "B2", false], bundle=false)
publish(read_dbf("out/only.dbf"))
