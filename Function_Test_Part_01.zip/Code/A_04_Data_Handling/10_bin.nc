# CATEGORY 13 - read_bin / load_bin / save_bin.
A = [1.5, 2, 3; 4, 5, 6.25];
publish("== save_bin dtype / boxes, then read_bin with every option")
n1 = save_bin("out/b1.bin", A, dtype="float32", boxes="MAGIC_HDR_v1")
B = read_bin("out/b1.bin", dtype="float32", shape=[2, 3], box_bytes=12)
[raw, info] = read_bin("out/b1.bin", box_bytes=12, count=4);
publish(raw)
publish(info.boxes)
publish(info.records)
mid = read_bin("out/b1.bin", dtype="float32", offset=12, count=2)
odd = read_bin("out/b1.bin", dtype="float32", box_bytes=12, stride=8)
n2 = save_bin("out/b2.bin", [1, 256, 65535], dtype="uint16", endian="big")
be = read_bin("out/b2.bin", dtype="uint16", endian="big")
le = read_bin("out/b2.bin", dtype="uint16")
publish("== record dtypes (C-struct layout), align, pad_byte")
recs = ["id", "val", "name"; 1, 2.5, "alpha"; 2, -7.25, "beta"];
n3 = save_bin("out/b3.bin", recs, dtype="id:i4,val:f8,name:8s")
R = read_bin("out/b3.bin", dtype="id:i4,val:f8,name:8s")
n4 = save_bin("out/b4.bin", recs, dtype="id:i4,val:f8,name:8s", align=8, pad_byte=255)
R4 = read_bin("out/b4.bin", dtype="id:i4,val:f8,name:8s", align=8)
[R5, r5i] = read_bin("out/b3.bin", dtype="i4,f8,8s");
publish(r5i.cols)
publish("== compress / mode")
n5 = save_bin("out/b5.bin", [1, 2, 3], dtype="int8");
n5 = save_bin("out/b5.bin", [4, 5], dtype="int8", mode="a")
publish(read_bin("out/b5.bin", dtype="int8"))
n6 = save_bin("out/b6.bin.gz", A, compress="gz")
publish("== load_bin")
D = load_bin("out/b3.bin", dtype="id:i4,val:f8,name:8s");
publish(D.size)
publish(D.endian)
publish(D.name)
publish(D.val)
publish(D.records.rows)
publish(D.slice_bytes(0, 4))
publish(D.slice_bytes(-4))
publish(D.view("int32", count=1))
publish(D.view("uint8", shape=[2, 2]))
H = load_bin("out/b1.bin", box_bytes=12, dtype="float32");
publish(H.boxes)
publish(H.header)
publish(H.records)
