# CATEGORY 1 - read_/load_/save_ xlsx, xls, xlsm, xlsb.
publish("== save_xlsx: formulas, boxes, frozen header; then more sheets with mode=a")
T = load_csv("data/sensors.csv");
f = dict();
f["F2"] = "=C2*2";
f["F5"] = "=SUM(C2:C4)";
b = dict();
b["H2"] = "Note: calibrated";
n = save_xlsx("out/w1.xlsx", T.default, sheet="ABC", fml=f, boxes=b, freeze="A2", start="A1", fit_cols=true)
sh = dict();
sh["S1"] = [1, 2; 3, 4];
sh["S2"] = ["k", "v"; "a", 1];
n2 = save_xlsx("out/w1.xlsx", sheets=sh, mode="a")
publish("== read_xlsx: default sheet, by name, by number + range, no formula evaluation, columns")
[R, info] = read_xlsx("out/w1.xlsx");
publish(R)
publish(info.cols)
publish(info.boxes)
publish(read_xlsx("out/w1.xlsx", sheet="S2"))
publish(read_xlsx("out/w1.xlsx", sheet=2, range="A1:B2", hdr=0))
publish(read_xlsx("out/w1.xlsx", eval_fml=false, cols=["Temp"]))
publish("== load_xlsx: sheets, columns, cells, formulas, styles")
D = load_xlsx("out/w1.xlsx");
publish(D.sheets)
publish(D.ABC.Temp)
publish(D.ABC.cell("F5").val)
publish(D.ABC.cell("F2").fml)
publish(D.ABC.cell("B1").style)
publish(D.ABC.boxes)
publish(D.sheet("S1").data)
publish("== xls (BIFF8) and xlsm (macro-enabled)")
x = save_xls("out/w2.xls", T.default, fml=f, boxes=b);
[X, xi] = read_xls("out/w2.xls");
publish(X)
publish(xi.boxes)
L = load_xls("out/w2.xls");
publish(L.default.cell("F5").val)
m = save_xlsm("out/w3.xlsm", [1, 2; 3, 4], level=9);
publish(read_xlsm("out/w3.xlsm", hdr=0))
publish("== an Excel-authored .xls and an Office template")
E = read_xls("data/foreign/ex.xls");
publish(E)
F = load_xls("data/foreign/ex.xls");
publish(F.sheets)
publish(F.Data.cell("B4"))
publish(F.Data.merged)
O = load_xlsx("data/foreign/office.xlsx");
publish(O.sheets)
