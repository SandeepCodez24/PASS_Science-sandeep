# CATEGORY 2 - read_tsv / load_tsv / save_tsv (tab is the default delimiter).
T = read_tsv("data/laps.tsv")
[T, info] = read_tsv("data/laps.tsv", cols=["name", "time"], rows=[1:2]);
publish(T)
publish(info.boxes)
publish(info.dlm)
L = load_tsv("data/laps.tsv");
publish(L.name)
publish(L.time)
publish(L.boxes)
n = save_tsv("out/t1.tsv", L.default, boxes=["Run log 42"])
back = read_tsv("out/t1.tsv")
n2 = save_tsv("out/t2.tsv", [1, 2; 3, 4], hdr=true, compress="gz")
publish(read_tsv("out/t2.tsv"))
