# CATEGORY 12 - read_/load_/save_ fits, fit.
img = [1, 2, 3; 4, 5, 6] * 1000;
h = dict();
h["TELESCOP"] = "HST";
h["EXPTIME"] = 120.0;
h["CRPIX1"] = 1;
h["CRPIX2"] = 1;
h["CRVAL1"] = 150.0;
h["CRVAL2"] = 2.0;
h["CD1_1"] = -0.0001;
h["CD2_2"] = 0.0001;
h["CTYPE1"] = "RA---TAN";
h["CTYPE2"] = "DEC--TAN";
n1 = save_fits("out/a.fits", img, header=h, bitpix=16, boxes=["COMMENT Calibrated dark frame", "HISTORY made by NC"])
cat = ["RA", "DEC", "FLUX"; 150.1, 2.2, 31.5; 150.2, 2.3, 12.25];
n2 = save_fits("out/a.fits", cat, hdu_name="CAT", mode="a")
n3 = save_fits("out/a.fits", img, hdu_name="SCI", bitpix=32, compress="rice", mode="a")
n4 = save_fits("out/b.fit", img / 7, compress="gzip", hdu_name="SCI")
[A, ai] = read_fits("out/a.fits");
publish(A)
publish(ai.boxes)
publish(ai.hdus)
publish(read_fits("out/a.fits", hdu="CAT", cols=["FLUX"]))
publish(read_fits("out/a.fits", hdu="SCI"))
publish(read_fits("out/a.fits", hdu=0, slice="1:2, 2:3"))
publish(read_fit("out/b.fit", hdu="SCI"))
D = load_fits("out/a.fits");
publish(D.hdu_names)
publish(D.primary.header.TELESCOP)
publish(D.CAT.FLUX)
publish(D.SCI.data)
publish(D.primary.pix2world(1, 1))
publish(D.primary.pix2world(101, 1))
