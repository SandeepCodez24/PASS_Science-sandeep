# CATEGORY 18 - read_/load_/save_ tif, geotiff.
publish("== a 3 x 4 UTM raster placed by bbox, with NoData")
R = reshape([1:12], [3, 4]);
g = save_tif("out/g.tif", R, crs="EPSG:32644", bbox=[400000, 1400000, 400400, 1400300], nodata=12)
[A, gi] = read_tif("out/g.tif");
publish(A)
publish(gi.transform)
publish(gi.bounds)
publish(gi.res)
G = load_tif("out/g.tif");
publish(G.crs)
publish(G.nodata)
publish(G.sample(400150, 1400250))
publish(read_tif("out/g.tif", window=[1, 1, 2, 2], mask_nodata=false))
publish("== a 3-band float raster in lon / lat: COG overviews, zstd, tiles, metadata boxes")
RGB = reshape([0:(40*30*3 - 1)], [30, 40, 3]) / 4000;
c = save_geotiff("out/rgb.tiff", RGB, bbox=[77.5, 12.9, 77.7, 13.05], cog=true, compress="zstd", tile=[16, 16], bigtiff="auto", boxes=dict(["Sensor"], ["Sentinel-2"]))
H = load_geotiff("out/rgb.tiff");
publish(H.count)
publish(H.dtype)
publish(H.overviews)
publish(H.sample(77.6, 13.0))
publish(H.boxes)
publish(size(read_geotiff("out/rgb.tiff", bands=[3, 1], bbox=[77.55, 12.95, 77.6, 13.0])))
publish(size(read_geotiff("out/rgb.tiff", overview=1, box=false)))
publish("== an explicit 6-number transform (GDAL order)")
t = save_tif("out/t.tif", R, crs="EPSG:4326", transform=[70, 0.5, 0, 30, 0, -0.5], compress="lzw", tile=0)
publish(load_tif("out/t.tif").bounds)
