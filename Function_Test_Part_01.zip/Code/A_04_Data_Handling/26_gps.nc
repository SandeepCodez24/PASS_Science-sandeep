# CATEGORY 19 - read_/load_/save_ gpx, kml (and .kmz).
la = [30.9, 30.92, 30.95, 30.98];
lo = [79.0, 79.02, 79.05, 79.08];
el = [3000, 3400, 3800, 4000];
publish("== save: track / waypoints / route as GPX; line / points / polygon as KML / KMZ")
n1 = save_gpx("out/trek.gpx", lat=la, lon=lo, ele=el, name="Gaumukh_Trek", color="#003366", boxes=["Basecamp Note: 4000m"])
n2 = save_gpx("out/wpt.gpx", lat=la, lon=lo, mode_type="waypoint")
n3 = save_gpx("out/rte.gpx", lat=la, lon=lo, mode_type="route", name="Plan")
n4 = save_kml("out/trek.kml", lat=la, lon=lo, ele=el, name="Gaumukh_Trek", color="#003366", boxes=["Basecamp Note: 4000m"])
n5 = save_kml("out/pts.kmz", lat=la, lon=lo, mode_type="point", kmz=true)
n6 = save_kml("out/area.kml", lat=la, lon=lo, mode_type="polygon")
publish("== read_gpx / read_kml: layer=, bbox=, box=")
[T, info] = read_gpx("out/trek.gpx");
publish(T)
publish(info.boxes)
publish(read_gpx("out/wpt.gpx", layer="waypoints", bbox=[79.01, 30.91, 79.06, 30.96]))
publish(read_gpx("out/rte.gpx", layer="routes", box=false))
publish(read_kml("out/pts.kmz", layer="placemarks"))
publish(read_kml("out/area.kml", layer="polygons"))
publish("== load_gpx / load_kml")
G = load_gpx("out/trek.gpx");
publish(G.tracks[0].name)
publish(G.tracks[0].distance_km)
publish(G.tracks[0].ele)
publish(load_gpx("out/wpt.gpx").waypoints.rows)
K = load_kml("out/trek.kml");
publish(K.placemarks[0].type)
publish(K.placemarks[0].coords)
publish(K.boxes)
publish("== a GPX made by a device: time stamps, heart rate / cadence extensions, time_range=")
d = ["lat", "lon", "ele", "time"; 30.9, 79.0, 3000, "2026-05-01T06:00:00Z"; 30.91, 79.01, 3100, "2026-05-01T06:10:00Z"; 30.92, 79.02, 3200, "2026-05-01T06:20:00Z"]
n7 = save_gpx("out/timed.gpx", d)
publish(read_gpx("out/timed.gpx", time_range=["2026-05-01T06:05:00Z", "2026-05-01T06:30:00Z"]))
n8 = save_kml("out/timed.kml", d, mode_type="point")
publish(load_kml("out/timed.kml").table.time)
