# CATEGORY 3 - read_/load_/save_ parquet, feather, orc.
T = ["time", "sensor_1", "site", "ok"; 1, 0.25, "north", true; 2, 0.75, "south", false; 3, 0.5, "north", true; 4, 0.9, "east", true]
publish("== parquet: every codec, row groups, footer metadata, Hive partitions, size split")
n = save_parquet("out/a.parquet", T, boxes=dict(["author", "note"], ["PASS", "v1"]))
for c in ["snappy", "gzip", "lz4", "none"]:
   m = save_parquet("out/a_" + c + ".parquet", T, compress=c, group_rows=2, dict_enc=false, level=3);
   publish(read_parquet("out/a_" + c + ".parquet", groups=[2]))
fend
[d, info] = read_parquet("out/a.parquet");
publish(info.cols)
publish(info.types)
publish(info.codec)
publish(info.boxes)
publish(read_parquet("out/a.parquet", cols=["sensor_1", "time"], where="sensor_1 > 0.5", rows=[1:1], mmap=false, threads=2))
D = load_parquet("out/a.parquet");
publish(D.site)
publish(D.stats.sensor_1)
publish(D.kv_meta)
publish(D.groups[0].rows)
p = save_parquet("out/ds", T, part_by="site")
publish(read_parquet("out/ds"))
s = save_parquet("out/split.parquet", T, max_size="400", compress="none")
publish(read_parquet("out/split_part001.parquet"))
publish("== feather (Arrow IPC) and orc")
for c in ["zstd", "lz4", "none"]:
   m = save_feather("out/f_" + c + ".feather", T, compress=c, group_rows=3);
   publish(read_feather("out/f_" + c + ".feather", groups=[1]))
fend
for c in ["zstd", "snappy", "lz4", "zlib", "none"]:
   m = save_orc("out/o_" + c + ".orc", T, compress=c, group_rows=3);
   publish(read_orc("out/o_" + c + ".orc", where="time >= 3"))
fend
publish(load_orc("out/o_zstd.orc").stats.time)
publish("== files written by pyarrow: delta / byte-stream-split encodings, v2 pages, nested structs, dictionaries")
[q, qi] = read_parquet("data/foreign/py_delta.parquet", cols=["id", "name", "cat", "f32"], rows=[9:13]);
publish(q)
V = load_parquet("data/foreign/py_v2.parquet");
publish(V.user.address.city[0:2])
publish(V.ts[0:1])
publish(V.dec[0:2])
F = load_feather("data/foreign/py_zstd.feather");
publish(F.cat[0:4])
publish(F.pt.y[0:2])
publish(F.skipped)
publish(read_feather("data/foreign/py.arrows", cols=["id"], where="id > 497"))
O = load_orc("data/foreign/py_zstd.orc");
publish(O.ts[0:1])
publish(O.pt.b[1:2])
publish(O.groups[0].rows)

