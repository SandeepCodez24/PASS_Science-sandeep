# CATEGORY 9 - read_ini / load_ini / save_ini.
I = read_ini("data/config.ini")
db = read_ini("data/config.ini", sec="Database")
p = read_ini("data/config.ini", sec="Database", key="path")
raw = read_ini("data/config.ini", sec="Database", key="path", interp=false)
t = read_ini("data/config.ini", key="timeout")
[x, info] = read_ini("data/config.ini");
publish(info.sections)
publish(info.boxes)
publish(info.comments)
[y, yi] = read_ini("data/config.ini", box=false);
publish(yi.boxes)
D = load_ini("data/config.ini");
publish(D.Database.port)
publish(D.Database.enabled)
publish(D.Paths.desc)
publish(D.defaults)
publish(D.sections)
publish(D.boxes)
n1 = save_ini("out/i1.ini", D)
flat = dict(["user", "retries"], ["admin", 3]);
n2 = save_ini("out/i2.ini", flat, sec="Login", delim=": ", boxes=["# Auto-generated INI config"])
more = dict();
more["Login"] = dict(["timeout"], [15]);
more["Extra"] = dict(["mode"], ["fast"]);
n3 = save_ini("out/i2.ini", more, mode="a")
publish(read_ini("out/i1.ini", sec="Database"))
publish(read_ini("out/i2.ini"))
