# CATEGORY 13 - read_custom / load_custom / save_custom: the layout travels in
# a companion <file>.schema.json, so reading needs no arguments.
T = ["t", "v"; 0.1, 10; 0.2, 20; 0.3, 30];
n = save_custom("out/s1.custom", T, dtype="t:f8,v:i2", boxes="SENSOR01")
C = read_custom("out/s1.custom")
[C, info] = read_custom("out/s1.custom");
publish(info.cols)
publish(info.boxes)
publish(info.schema)
L = load_custom("out/s1.custom");
publish(L.t)
publish(L.v)
publish(L.boxes)
publish(L.records.cols)
M = [1, 2; 3, 4; 5, 6];
n2 = save_custom("out/s2.custom", M, dtype="float32", endian="big")
publish(read_custom("out/s2.custom"))
publish(read_custom("out/s2.custom", count=6))
