###############################################################
#### N-D matrices, the matrix type rules and lists of variables
###############################################################

###############################################################
#### 1. N-D matrices
###############################################################
B = [1,2,3; 4,5,6; 7,8,9 ;; ~~
     10,11,12; 13,14,15; 16,17,18 ;; ~~
     19,20,21; 22,23,24; 25,26,27];
B
sB = shape(B);                      ## 3 3 3
nB = ndims(B);                      ## 3
publish("shape of B :", sB, " ndims :", nB);

Q = [1,2;3,4 ;; 5,6;7,8 ;;; 9,10;11,12 ;; 13,14;15,16];
publish("shape of Q :", shape(Q));  ## 2 2 2 2

T1 = [1,2;3,4;;];                   ## a trailing separator raises the rank
publish("shape of T1 :", shape(T1)); ## 1 2 2

slab = B[1]                         ## the 2-D slab 1 (3x3)
one  = B[2,0,1];                    ## one element
publish("B[2,0,1] is 20 :", one);

K = [B[0] ;; B[1]];                 ## ';;' also joins 2-D matrices
publish("shape of K :", shape(K));  ## 2 3 3

C = B *. 2 + 1;                     ## element-wise arithmetic
C[0]

total = 0;
for s = B:
   total = total + s[0,0];          ## one pass per slab: 1 + 10 + 19
fend
publish("sum of the first element of every slab is 30 :", total);

Z = zeros([2,3,4]);
Z[1,2,3] = 7;
publish("Z[1,2,3] is 7 :", Z[1,2,3]);

R = reshape([1:24], [2,3,4]);       ## row-major, as in NumPy
R[1,2,:]

###############################################################
#### 2. Type rules - a matrix holds one type
###############################################################
S = [1, 2; 3, "car"]                ## any text -> a text matrix
F = [true, 2.5]                     ## bool and float64 -> float64
I = [int8(1), int16(300)]           ## two integer types -> int16

A = [1,2;3,4];
A[0,0] = true;                      ## stored as 1
A[1,1] = 2.5i                       ## widens A to complex
# A[0,1] = "no"                     ## error: A holds numbers

###############################################################
#### 3. Lists of variables
###############################################################
[a, b, c] = [1, 2, "car"]           ## a = 1, b = 2, c = "car"

v = [10, 20, 30];
[x, y, z] = v;                      ## the elements of a vector
publish("x, y, z :", x, y, z);

M = [1,2;3,4];
[r0, r1] = M                        ## the rows
[m11, m12; m21, m22] = M;           ## element by element
publish("m11 m12 m21 m22 :", m11, m12, m21, m22);

[a, b] = [b, a];                    ## swap
publish("after the swap a = 2, b = 1 :", a, b);

[d1, d2] = deal(0);                 ## one value for every name
[u, ~] = [7, 8];                    ## '~' skips a value
publish("d1 d2 u :", d1, d2, u);

function [s1, d1] = sumdiff(p, q):
   s1 = p + q;
   d1 = p - q;
fnend

[s1, d1] = sumdiff(5, 3);
publish("sumdiff(5, 3) is 8 and 2 :", s1, d1);

# [k1, k2] = 5                      ## error: write [k1, k2] = deal(5)
# (k1, k2) = sumdiff(5, 3)          ## error: outputs go in square brackets

###############################################################
#### 4. Wide matrices: shown in column groups
####    (width: @cmd width N from the IDE, NC_DISPLAY_WIDTH, or 80)
###############################################################
W = unit_matrix(40)
###############################################################
