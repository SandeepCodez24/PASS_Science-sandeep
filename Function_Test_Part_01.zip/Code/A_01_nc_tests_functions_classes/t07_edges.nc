class Rect():
   function base(w, h=w):
      base.w = w;
      base.h = h;
   fnend
   function A = area(scale=base.w):
      A = base.w * base.h * scale;
   fnend
csend
r = Rect(3);
publish("Rect(3): h defaults to w ->", r.h, "  area(scale=base.w) ->", r.area())

function y = fact(n, acc=1):
   if n <= 1:
      y = acc;
   else:
      y = fact(n - 1, acc=acc * n);
   iend
fnend
publish("fact(5) =", fact(5))

function y = sub(A_$1, A_$2=10):
   y = A_$1 - A_$2;
fnend
publish("sub(A_$2=1, 5) =", sub(A_$2=1, 5))

function y = inner(b=1):
   y = b * 100;
fnend
function y = outer(a, c=0):
   y = a + c;
fnend
publish("outer(c=inner(b=2), 1) =", outer(c=inner(b=2), 1))

x1 = 3;
function C = Add(x1, x2):
   C = x1 + x2;
fnend
publish("Add(x2=x1, x1=10) =", Add(x2=x1, x1=10))
publish("x1 is still", x1)

function y = M(v=[1, 2, 3], s="a=b"):
   y = s;
fnend
publish("M() =", M())

counter = 0;
function y = Fresh(t=sqrt(16)):
   y = t;
fnend
publish("Fresh() =", Fresh(), " Fresh(1) =", Fresh(1))
publish("1 == 1 still a comparison:", outer(1 == 1))
