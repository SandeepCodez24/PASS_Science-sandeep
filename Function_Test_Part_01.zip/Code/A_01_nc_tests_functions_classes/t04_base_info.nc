class Shape():
   private secret;
   function base(w, h=1, label="shape"):
      base.w = w;
      base.h = h;
      base.label = label;
      base.ok = true;
      base.tags = [1, 2, 3];
      base.n = int32(5);
      base.meta = dict();
      base.secret = 42;
      tmp = 2.5;
      base.half = tmp;
   fnend
   function A = area(scale=1):
      A = base.w * base.h * scale;
   fnend
   function grow(dw=1, dh=1):
      base.w = base.w + dw;
   fnend
   function [p, q] = dims():
      p = base.w;
      q = base.h;
   fnend
   function seeAll():
      publish("inside, base.base sees the private field:", base.base)
   fnend
csend

class Circle(Shape):
   function base(r=1, color="red"):
      parent(r, r, label="circle");
      base.r = r;
      base.color = color;
   fnend
   function A = area(scale=1):
      A = 3.14159 * base.r * base.r * scale;
   fnend
   function A = area(scale, offset):
      A = 0;
   fnend
csend

CC = Shape.base
Shape.info
FF = Shape(2, 3);
FF.base
FF.seeAll();
Circle.base
Circle.info
c = Circle(color="blue");
c.base
I = Circle.info;
publish("count =", I["count"], " parent =", I["parent"])
Shape.info()
FF.info;
\\ FF.base = 3;
\\ z = 5;
\\ z.base
\\ Nope.base
\\ Shape.info(1)
