# Overloads + defaults: fewest defaults wins; a tie is an error
function y = P(a):
   y = 1;
fnend

function y = P(a, b=2):
   y = 2;
fnend

publish("P(9) ->", P(9), "  P(9, 9) ->", P(9, 9), "  P(a=9, b=1) ->", P(a=9, b=1))
function y = Q(a=1):
   y = 1;
fnend
function y = Q(a, b=2, c=3):
   y = 3;
fnend
publish("Q() ->", Q(), "  Q(5) ->", Q(5), "  Q(5, 6) ->", Q(5, 6))
function y = Z(p=1):
   y = 1;
fnend
function y = Z(q=1, r=2):
   y = 2;
fnend
r = Z();
r = Z(p=4);

# Multi-output with names and defaults
function [q, r] = divmod(a, b=3):
   q = a // b;
   r = a % b;
fnend
[q, r] = divmod(b=5, 17);
publish("divmod(b=5, 17) ->", q, r)
[q, r] = divmod(17);
publish("divmod(17) ->", q, r)

# Constructor and methods with defaults and names
class Shape():
   function base(w, h=1, label="shape"):
      base.w = w;
      base.h = h;
      base.label = label;
   fnend
   function A = area(scale=1):
      A = base.w * base.h * scale;
   fnend
   function grow(dw=1, dh=1):
      base.w = base.w + dw;
      base.h = base.h + dh;
   fnend
csend
s = Shape(h=3, 2);
publish("Shape(h=3, 2): w =", s.w, " h =", s.h, " label =", s.label)
publish("area() =", s.area(), "  area(scale=10) =", s.area(scale=10))
s.grow(dh=5);
publish("after grow(dh=5): w =", s.w, " h =", s.h)
t = Shape(4);
publish("Shape(4): w =", t.w, " h =", t.h, " label =", t.label)
publish("lineage:", s.lineage())
\\ u = Shape(label="x");

# Inheritance + parent(...) with names
class Square(Shape):
   function base(side=2):
      parent(side, label="square", h=side);
   fnend
csend
q1 = Square();
publish("Square(): w =", q1.w, " h =", q1.h, " label =", q1.label, " area =", q1.area(scale=2))
q2 = Square(side=7);
publish("Square(side=7): area =", q2.area())
\\ q2.nosuch(a=1);
x = 5;
\\ x.area(scale=1);
