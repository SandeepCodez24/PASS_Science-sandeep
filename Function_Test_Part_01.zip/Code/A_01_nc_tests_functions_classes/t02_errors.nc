function y = G(a, b=100, c=1000):
   y = a + b + c;
fnend
r = G();
r = G(1, 2, 3, 4);
r = G(d=1);
r = G(1, a=2);
r = G(a=1, a=2);
r = G(b=1, c=2, 3, 4);
r = sqrt(x=4);
function y = Twice(x, x):
   y = x;
fnend
function y = Bad(a, b=):
   y = a;
fnend
r = G(a=);
function y = DefaultFails(a, b=nosuch+1):
   y = a + b;
fnend
r = DefaultFails(1);
publish("still running, DefaultFails(1, 2) =", DefaultFails(1, 2))
publish("a comparison inside a call still works:", G(1 == 1))
