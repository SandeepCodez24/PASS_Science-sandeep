class D():
   function base(a=-1, b=a*2+1, c=sqrt(16), d=true, e="say \"hi\"", f=[1, 2; 3, 4], g=3i, h=-(a+1), k=!d):
      base.a = a;
      base.b = b;
      base.c = c;
      base.d = d;
      base.e = e;
      base.g = g;
      base.k = k;
   fnend
csend
D.info
D.base
I = D.info;
fns = I["functions"];
