function y = combine(a):
   y = a;
fnend
function y = combine(a, b):
   y = a + b;
fnend
publish(combine(1), combine(1, 2))
\\ r = combine(1, 2, 3);
\\ function hello:
\\    publish("hello")
\\ fnend
\\ hello;
function y = seven():
   y = 7;
fnend
z = seven;
publish(z, feval(@combine, 4, 5))
function [q, r] = divmod(a, b):
   q = a // b;
   r = a % b;
fnend
[q, r] = divmod(17, 5);
publish(q, r)
\\ [q, r] = divmod(17);
\\ abstract class Animal():
\\    function s = speak():
\\    fnend
\\ csend
class Dog(Animal):
   function base(name):
      base.name = name;
   fnend
   function s = speak():
      s = "woof";
   fnend
csend
d = Dog("rex");
publish(d.speak(), d.name)
a = Animal();
\\ reversible class Counter():
\\   function base():
\\     base.n = 0;
\\   fnend
\\   function inc(k):
\\     base.n = base.n + k;
\\   fnend
\\ csend
c = Counter();
c.inc(2);
c.inc(3);
publish(c.n, c.lineage())
c = c.rewind(1);
publish(c.n)
c.inc();
c.inc(1, 2);
class Kid(Dog):
   function base(name, age):
      parent(name);
      base.age = age;
   fnend
csend
k = Kid("tom", 3);
publish(k.name, k.age, k.speak())
k2 = Kid("x");
k.nothing();
w = Dog();
