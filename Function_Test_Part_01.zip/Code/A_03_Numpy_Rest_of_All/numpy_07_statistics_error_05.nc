# Expected: nan_percentile: q must be between 0 and 100
A = [1, 2, 3; 4, 5, 6];
x = nan_percentile([1, 2], 150)
