# Expected: take: indices must be whole numbers
A = [10, 20, 30; 40, 50, 60];
x = take(A, 1.5)
