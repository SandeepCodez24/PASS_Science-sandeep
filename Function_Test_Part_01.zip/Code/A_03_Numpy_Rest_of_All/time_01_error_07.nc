# Expected: time error: result is out of the supported range (about years 1678-2261)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = timestamp(2300, 1, 1)
