# Date and time - phase 2: operators
#
#   t = timestamp, d = duration, k = number
#
#   t2 - t1          duration    real elapsed time (daylight saving included)
#   t + d, d + t     timestamp
#   t - d            timestamp
#   d1 + d2, d1 - d2 duration
#   -d, |d|, abs(d)  duration
#   d * k, k * d     duration    rounded to the nearest nanosecond
#   d / k            duration    k = 0 is an error
#   d1 / d2          number      the ratio (how many d2 fit in d1)
#   == != < <= > >=  bool        two timestamps, or two durations only
#
# Not allowed (each is an error - see time_02_error_*.nc):
#   t1 + t2           adding two points in time means nothing (t2 - t1 is the gap)
#   t + 5, d - 3      a plain number has no unit: write t + seconds(5)
#   t * 2, d1 * d2    no meaning
#   t < d, t == 5     different kinds cannot be compared
#
# Matrices follow the numeric rules: equal shapes element by element, or a
# single value against every element. '*' and '/' between TWO matrices
# would be the matrix product, which has no meaning for time - write *. and
# /. for element by element. Comparing two matrices gives ONE true/false
# (every pair holds); comparing with a single value gives one per element.
#
# The UTC timestamps make every result the same on any computer.
# Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC")
t2 = timestamp(2026, 10, 28, 16, 0, 15, "UTC")

# --- timestamp and duration arithmetic --------------------------------------
d = t2 - t1
check("t2 - t1 is 01:30:15", d == hours(1) + minutes(30) + seconds(15));
check("t1 - t2 is negative", t1 - t2 == -d);
check("t + d", t1 + d == t2);
check("d + t", d + t1 == t2);
check("t - d", t2 - d == t1);
check("chain t + hours + minutes", t1 + hours(2) + minutes(30) == timestamp(2026, 10, 28, 17, 0, 0, "UTC"));
check("days(1) is exactly 24 hours", t1 + days(1) - t1 == hours(24));

# --- duration arithmetic ----------------------------------------------------
check("d1 + d2", minutes(90) + minutes(30) == hours(2));
check("d1 - d2", hours(1) - minutes(45) == minutes(15));
check("d * k", minutes(90) * 2 == hours(3));
check("k * d", 2 * minutes(90) == hours(3));
check("fractional factor", seconds(3) * 0.1 == seconds(0.3));
check("d / k", hours(1) / 4 == minutes(15));
check("d1 / d2 is a number", minutes(90) / minutes(15) == 6);
check("ratio with a fraction", minutes(1) / seconds(40) == 1.5);
check("unary minus", -minutes(5) == minutes(-5));
check("abs()", abs(minutes(-5)) == minutes(5));
check("|d|", |minutes(-5)| == minutes(5));
check("rounding to the nanosecond", seconds(1) / 3 == seconds(0.333333333));

# --- comparisons ------------------------------------------------------------
check("t1 < t2", t1 < t2);
check("t2 >= t1", t2 >= t1);
check("t1 != t2", t1 != t2);
check("durations compare", minutes(59) < hours(1));
check("same instant, different zones", timestamp(2026, 10, 28, 20, 0, 0, "Asia/Kolkata") == t1);

# --- daylight saving: t2 - t1 is real elapsed time ---------------------------
# Berlin moves its clocks from 02:00 to 03:00 on 2026-03-29, so noon to noon
# across that night is 23 hours.
a = timestamp(2026, 3, 28, 12, 0, 0, "Europe/Berlin")
b = timestamp(2026, 3, 29, 12, 0, 0, "Europe/Berlin")
check("DST spring: noon to noon is 23 h", b - a == hours(23));
c = timestamp(2026, 10, 24, 12, 0, 0, "Europe/Berlin")
e = timestamp(2026, 10, 25, 12, 0, 0, "Europe/Berlin")
check("DST autumn: noon to noon is 25 h", e - c == hours(25));

# --- matrices ---------------------------------------------------------------
T = [t1; t2]
D = T - t1
check("matrix - single value", D == [seconds(0); d]);
check("matrix + duration", T + hours(1) == [t1 + hours(1); t2 + hours(1)]);
M = minutes([1, 2; 3, 4])
check("matrix * number", M * 2 == minutes([2, 4; 6, 8]));
check("element-wise *. with numbers", M *. [1, 2; 3, 4] == minutes([1, 4; 9, 16]));
check("element-wise /. of durations", M /. minutes([1, 1; 1, 2]) == [1, 2; 3, 2]);
check("matrix - matrix", M - M == minutes([0, 0; 0, 0]));
check("-matrix", -M == minutes([-1, -2; -3, -4]));
check("compare with a single value gives one per element", (M > minutes(2)) == [false, false; true, true]);
check("compare two matrices gives one answer", M < minutes([2, 3; 4, 5]));

# --- extending matrices of time values --------------------------------------
laps = []
laps ,= t2 - t1
laps ,= (t2 - t1) * 2
check("build a duration row with ,=", laps == [d, d * 2]);
