# Expected: time error: cannot parse "2026-13-40" as timestamp
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = to_timestamp("2026-13-40")
