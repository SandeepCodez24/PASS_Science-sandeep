# Operations between different types (rules from 2026-10-28)
#
# Numbers follow IEEE 754, with the usual promotion
#     bool  <  int8 ... uint64  <  float8 ... float64  <  complex
# so a bool takes part as 1 or 0 (as in C, NumPy and MATLAB).
#
# Text never stands in for a number:
#     "5" + 1     ERROR  - the left value is text, so '+' would join text;
#                          write "5" + str(1) -> "51"  or  float("5") + 1 -> 6
#     1 + "5"     ERROR  - the left value is a number; write 1 + float("5")
#     "5" * 2     ERROR  - write float("5") * 2
#     -"5", "5"!  ERROR
#     "5" == 5    false  (a text is never equal to a number)
#     "5" < 5     ERROR  (text and numbers cannot be ordered)
# Text with text:
#     "5" + "1"   "51"   ('+' joins text)
#     "a" < "b"   true   (dictionary order)
#     "a" - "b"   ERROR  (only '+' is defined for text)
#
# The error cases are in 00_type_rules_error_*.nc (an error stops a script).
# Every check below prints PASS or FAIL.

function check(label, got, want):
   
   if shape(got) == shape(want):
      if got == want:
         print("PASS  " + label)
      else:
         print("FAIL  " + label + "  (values differ)")
      iend
   else:
      print("FAIL  " + label + "  (shapes differ)")
   iend
fnend

# --- bool takes part as 1 / 0 --------------------------------------------
check("1 + (1 == 1)", 1 + (1 == 1), 2);
check("true + true", true + true, 2);
check("5 * false", 5 * false, 0);
check("bool mask times matrix", [1, 2; 3, 4] *. [true, false; false, true], [1, 0; 0, 4]);
check("matrix + bool", [1, 2, 3] + true, [2, 3, 4]);
check("count trues with sum", sum([1, 5, 7, 2] > 3), 2);

# --- numbers of different types (unchanged) ------------------------------
check("int8 + float", int8(3) + 2.5, 5.5);
check("int + bool", int32(4) + true, 5);
z = (1 + 2i) + 3;
check("complex + real (real part)", real(z), 4);
check("complex + real (imag part)", imag(z), 2);

# --- text with text ------------------------------------------------------
check("text + text joins", "5" + "1", "51");
check("join words", "Neural" + " " + "Code", "Neural Code");
check("text order", "apple" < "banana", true);
check("text equality", "abc" == "abc", true);

# --- text and numbers: conversions are explicit ---------------------------
check("join after str()", "5" + str(1), "51");
check("add after float()", float("5") + 1, 6);
check("float() of a fraction", float("1/2") + 1, 1.5);
check("dec2frac back to a number", frac2deci(dec2frac(0.5)) + 1, 1.5);
check("text is never equal to a number", "5" == 5, false);
check("... and != is true", "5" != 5, true);
