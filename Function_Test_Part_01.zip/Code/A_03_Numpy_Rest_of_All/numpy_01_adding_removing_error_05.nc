# Expected: repeat: repeats must not be negative
A = [1, 2; 3, 4];
x = repeat(A, -1)
