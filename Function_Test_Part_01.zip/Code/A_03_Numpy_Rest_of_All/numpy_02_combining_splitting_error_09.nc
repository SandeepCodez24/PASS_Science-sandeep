# Expected: matrix_split: the split gives 3 pieces, but 2 names were given
[a, b] = matrix_split([1, 2, 3, 4, 5, 6], 3, axis=1)
