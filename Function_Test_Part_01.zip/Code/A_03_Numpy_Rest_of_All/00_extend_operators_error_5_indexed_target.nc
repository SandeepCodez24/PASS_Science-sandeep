# Expected: syntax error - ',=' needs a plain name on the left
A = [1, 2; 3, 4]
A[0] ,= 5
