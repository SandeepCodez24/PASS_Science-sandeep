# Expected: repeat: give one repeat count, or one per element (2), not 3
A = [1, 2; 3, 4];
x = repeat([1, 2], [1, 2, 3])
