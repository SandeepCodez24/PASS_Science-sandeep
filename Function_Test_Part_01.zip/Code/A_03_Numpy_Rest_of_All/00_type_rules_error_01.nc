# Expected error: text + number - left value is text, hint "5" + str(1) or float("5") + 1
x = "5" + 1
