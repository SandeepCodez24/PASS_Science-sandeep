# Expected error: factorial of text
x = "5"!
