# Expected: str_concat: the second argument must be text in quotes - turn a number into text with str(x)
x = str_concat("a", 5)
