# Expected: rand_poisson: size must hold whole numbers >= 0
A = [1, 2; 3, 4];
x = rand_poisson(3, size=[2, -1])
