# Expected: fill_diagonal: wrap must be true or false
A = [1, 2; 3, 4];
x = fill_diagonal(A, 1, wrap=1)
