# Expected: time error: toc() called before tic()
x = toc()
