# Expected: flip: axis must be a whole number
M = [3, 1, 2; 9, 7, 8];
x = flip(M, axis=0.5)
