# Expected: column_stack: time error: cannot concatenate timestamp with float64
x = column_stack([1; 2], [timestamp(2026, 1, 1, "UTC"); timestamp(2026, 1, 2, "UTC")])
