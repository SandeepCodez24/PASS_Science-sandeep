# Expected: str_len: every element must be text in quotes
x = str_len(5)
