# Expected: is_complex_each: it works on numbers
x = is_complex_each(["a", "b"])
