# Expected: put: position 4 is outside A (it has 4 elements: 0..3)
A = [1, 2; 3, 4];
x = put(A, 4, 0)
