# Expected: column_stack: ... except along axis -1 - got 2x2 and 1x3
A = [1, 2; 3, 4]; C = [1, 2, 3; 4, 5, 6];
x = column_stack(A, [1, 2, 3])
