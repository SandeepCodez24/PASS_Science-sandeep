# Expected: sort_asc: axis 2 does not exist for a 2-D input
M = [3, 1, 2; 9, 7, 8];
x = sort_asc(M, axis=2)
