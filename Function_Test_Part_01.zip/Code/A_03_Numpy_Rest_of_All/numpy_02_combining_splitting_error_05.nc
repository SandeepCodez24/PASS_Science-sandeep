# Expected: stack: every input must have the same size - got 2x2 and 2x3
A = [1, 2; 3, 4]; C = [1, 2, 3; 4, 5, 6];
x = stack(A, C)
