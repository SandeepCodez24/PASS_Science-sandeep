# Expected: fill_nan: method must be "value", "ffill", "bfill", "mean" or "linear"
x = fill_nan([1, nan], method="nearest")
