# Expected: interp: xp must increase from left to right
A = [1, 2, 3; 4, 5, 6];
x = interp([1], [3, 2, 1], [1, 2, 3])
