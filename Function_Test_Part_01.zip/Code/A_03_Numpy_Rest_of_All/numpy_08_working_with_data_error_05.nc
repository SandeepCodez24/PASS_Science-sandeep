# Expected: center: fill must be exactly one character
x = center("ab", 6, fill="**")
