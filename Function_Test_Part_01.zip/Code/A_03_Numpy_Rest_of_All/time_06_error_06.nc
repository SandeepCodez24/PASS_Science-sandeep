# Expected: time error: n must be a whole number of business days
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = busday_offset(mon, 1.5)
