# Expected: time error: operator '-' (negation) is not defined for timestamp
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = -t1
