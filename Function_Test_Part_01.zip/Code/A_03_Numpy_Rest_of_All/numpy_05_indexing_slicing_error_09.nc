# Expected: mask_indices: mask must be "triu" (upper part) or "tril" (lower part)
A = [10, 20, 30; 40, 50, 60];
x = mask_indices(3, mask="diag")
