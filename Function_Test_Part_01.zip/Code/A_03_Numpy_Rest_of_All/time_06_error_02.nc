# Expected: time error: invalid weekmask "1111" - it needs exactly 7 digits, Monday to Sunday
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = is_busday(mon, weekmask="1111")
