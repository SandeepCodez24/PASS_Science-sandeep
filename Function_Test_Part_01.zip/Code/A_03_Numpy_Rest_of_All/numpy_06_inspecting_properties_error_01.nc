# Expected: is_type: unknown type "integr" - use bool, int8, ... or a group: integer, float, number, complex, time
x = is_type(5, "integr")
