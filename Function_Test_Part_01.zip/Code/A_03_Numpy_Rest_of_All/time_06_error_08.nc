# Expected: time error: date_range: step must not be zero
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = date_range(mon, sat, days(0))
