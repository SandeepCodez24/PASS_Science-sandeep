# Expected: time error: result is out of the supported range (about years 1678-2261)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = days(100000) * 2
