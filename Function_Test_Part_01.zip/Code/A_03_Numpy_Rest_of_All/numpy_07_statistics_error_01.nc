# Expected: prod: axis must be a whole number or "all" (every element)
A = [1, 2, 3; 4, 5, 6];
x = prod(A, axis="rows")
