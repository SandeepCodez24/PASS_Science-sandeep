# Expected: time error: sqrt expects a number, got timestamp
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = sqrt(t1)
