# Expected: is_nan_each: it works on numbers
x = is_nan_each(["a"])
