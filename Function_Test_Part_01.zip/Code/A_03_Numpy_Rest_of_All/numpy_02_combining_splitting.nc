# NumPy section 2 - Combining & Splitting
#
# ---------------------------------------------------------------------------
# AXES - which direction a function works in
# ---------------------------------------------------------------------------
# Every NC value is a matrix. Its axes are numbered from the FIRST one:
#
#     2-D matrix   shape [rows, cols]          axis 0 = rows      axis 1 = cols
#     N-D matrix   shape [d0, ..., rows, cols] axis 0 = d0 (pages) ...
#
# A negative axis counts from the END, so it means the same thing for any
# number of dimensions:
#     axis -1 = the columns (the last axis)     axis -2 = the rows
#
# Joining "along axis k" means the result grows in direction k:
#
#     A = [1, 2;      B = [5, 6;
#          3, 4]           7, 8]
#
#     concat(A, B, axis=0)  ->  [1, 2;          concat(A, B, axis=1)  ->  [1, 2, 5, 6;
#       (more rows)              3, 4;             (more columns)          3, 4, 7, 8]
#                                5, 6;
#                                7, 8]
#
# axis is given by name: concat(A, B, C, axis=1). Without it, axis=0.
#
# ---------------------------------------------------------------------------
# THE FUNCTIONS
# ---------------------------------------------------------------------------
#   concat(A, B, ..., axis=0)    join along an existing axis          (np.concatenate)
#   stack(A, B, ..., axis=0)     same-size inputs, joined along a NEW axis: two
#                                2x2 matrices become one 2x2x2 matrix  (np.stack)
#   row_stack(A, B, ...)         rows below rows - the same as [A; B]
#   vstack(A, B, ...)            the same as row_stack                (np.vstack)
#   column_stack(A, B, ...)      columns beside columns - the same as [A, B]
#   hstack(A, B, ...)            the same as column_stack             (np.hstack)
#   matrix_split(A, n, axis=0)   cut into n equal pieces along an axis (np.split)
#   matrix_split(A, [i, j, ...], axis=0)
#                                cut BEFORE positions i, j, ... (0-based)
#   vsplit(A, n_or_positions)    cut between rows    (axis -2)        (np.vsplit)
#   hsplit(A, n_or_positions)    cut between columns (axis -1)        (np.hsplit)
#
# Matrix-centred rules:
#   - [1, 2, 3] is a 1x3 matrix (a row), so column_stack([1,2,3], [4,5,6]) is
#     the 1x6 row [1,2,3,4,5,6] and row_stack([1,2,3], [4,5,6]) is 2x3.
#   - row_stack / column_stack always work on the ROWS and COLUMNS, also for an
#     N-D matrix (on every page), exactly like NC's [A; B] and [A, B].
#   - The element types follow the matrix rules: [1, 2] joined with [2.5] gives
#     float64, any text makes text, a timestamp never joins a number.
#   - An empty input [] is left out.
#   - A split returns matrices. One name gets them all as a list
#     (P = matrix_split(A, 3), then P[0], P[1], ...); several names get one
#     piece each ([L, R] = hsplit(A, 2)).
#
# The error cases are in numpy_02_combining_splitting_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, got, want):
   if shape(got) == shape(want):
      if got == want:
         print("PASS  " + label)
      else:
         print("FAIL  " + label + "  (values differ)")
      iend
   else:
      print("FAIL  " + label + "  (shapes differ)")
   iend
fnend

a = [1, 2, 3]
b = [4, 5, 6]
A = [1, 2; 3, 4]
B = [5, 6; 7, 8]

# --- row vectors ---------------------------------------------------------------
check("column_stack of two rows is 1x6", column_stack(a, b), [1, 2, 3, 4, 5, 6]);
check("hstack is the same", hstack(a, b), column_stack(a, b));
check("row_stack of two rows is 2x3", row_stack(a, b), [1, 2, 3; 4, 5, 6]);
check("vstack is the same", vstack(a, b), row_stack(a, b));
check("three inputs at once", row_stack(a, b, a), [1, 2, 3; 4, 5, 6; 1, 2, 3]);

# --- column vectors ---------------------------------------------------------------
c = [1; 2; 3]
check("column_stack of columns makes a matrix", column_stack(c, c), [1, 1; 2, 2; 3, 3]);
check("row_stack of columns makes a longer column", row_stack(c, c), [1; 2; 3; 1; 2; 3]);

# --- matrices -----------------------------------------------------------------------
check("concat default axis=0 (more rows)", concat(A, B), [1, 2; 3, 4; 5, 6; 7, 8]);
check("concat axis=1 (more columns)", concat(A, B, axis=1), [1, 2, 5, 6; 3, 4, 7, 8]);
check("axis=-1 is the columns", concat(A, B, axis=-1), concat(A, B, axis=1));
check("axis=-2 is the rows", concat(A, B, axis=-2), concat(A, B, axis=0));
check("row_stack equals [A; B]", row_stack(A, B), [A; B]);
check("column_stack equals [A, B]", column_stack(A, B), [A, B]);
check("different widths join as rows", concat(A, [9, 9]), [1, 2; 3, 4; 9, 9]);
check("different heights join as columns", concat(A, [9; 9], axis=1), [1, 2, 9; 3, 4, 9]);

# --- stack: a new axis ---------------------------------------------------------------
S0 = stack(A, B)
check("stack(A, B) is 2x2x2", shape(S0), [2, 2, 2]);
check("stack page 0 is A", S0[0], A);
check("stack page 1 is B", S0[1], B);
S2 = stack(A, B, axis=2)
check("stack(axis=2) pairs elements", S2[0], [1, 5; 2, 6]);
check("stack(axis=-1) is the same", stack(A, B, axis=-1), S2);

# --- N-D matrices -----------------------------------------------------------------
N = [1, 2; 3, 4 ;; 5, 6; 7, 8]
check("column_stack on N-D joins columns of every page", column_stack(N, N), [N, N]);
check("... shape 2x2x4", shape(column_stack(N, N)), [2, 2, 4]);
check("row_stack on N-D joins rows of every page", shape(row_stack(N, N)), [2, 4, 2]);
check("row_stack N-D page 1", row_stack(N, N)[1], [5, 6; 7, 8; 5, 6; 7, 8]);
check("concat axis=0 on N-D adds pages", shape(concat(N, N)), [4, 2, 2]);
check("a 2-D matrix next to N-D gets a leading 1", shape(concat(N, A)), [3, 2, 2]);

# --- types follow the matrix rules ------------------------------------------------
check("int and float give float64", concat([1, 2], [2.5], axis=1), [1, 2, 2.5]);
check("[] is left out", concat([], A, []), A);
check("text joins text", column_stack(["a", "b"], ["c"]), ["a", "b", "c"]);
t1 = timestamp(2026, 1, 1, "UTC")
check("timestamps join", column_stack(t1, t1 + days(1)), [t1, t1 + days(1)]);

# --- splitting ---------------------------------------------------------------------
M = [1, 2, 3, 4, 5, 6; 7, 8, 9, 10, 11, 12]
[L, R] = hsplit(M, 2)
check("hsplit into 2: left", L, [1, 2, 3; 7, 8, 9]);
check("hsplit into 2: right", R, [4, 5, 6; 10, 11, 12]);
[U, D] = vsplit(M, 2)
check("vsplit into 2: top", U, [1, 2, 3, 4, 5, 6]);
check("vsplit into 2: bottom", D, [7, 8, 9, 10, 11, 12]);
[P1, P2, P3] = matrix_split(M, [1, 4], axis=1)
check("cut before columns 1 and 4: first", P1, [1; 7]);
check("... second", P2, [2, 3, 4; 8, 9, 10]);
check("... third", P3, [5, 6; 11, 12]);
P = matrix_split(M, 3, axis=1)
check("one name gets a list: 3 pieces", numel(P), 3);
check("list piece P[1]", P[1], [3, 4; 9, 10]);
[F1, F2] = matrix_split(N, 2)
check("split an N-D matrix into pages", F2[0], [5, 6; 7, 8]);
check("split then join gives the matrix back", column_stack(L, R), M);
