# Expected: choose: choice number 3 does not exist - there are 2 choices
A = [10, 20, 30; 40, 50, 60];
x = choose([0, 3], [1, 2], [3, 4])
