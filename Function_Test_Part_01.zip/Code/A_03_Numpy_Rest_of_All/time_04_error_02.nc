# Expected: time error: toc takes no arguments - there is one stopwatch
tic();
x = toc(5)
