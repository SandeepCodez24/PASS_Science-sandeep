# Expected: time error: invalid day 30 for 2026-02 (expected 1-28)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = set_date(t1, 2026, 2, 30, "UTC")
