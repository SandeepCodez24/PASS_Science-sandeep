# Expected: time error: 02:30:00 on 2026-03-29 does not exist in time zone "Europe/Berlin"
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = set_time(set_date(t1, 2026, 3, 29, "Europe/Berlin"), 2, 30, 0, "Europe/Berlin")
