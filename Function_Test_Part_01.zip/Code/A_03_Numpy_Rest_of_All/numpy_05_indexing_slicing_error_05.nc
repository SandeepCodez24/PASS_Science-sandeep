# Expected: where: cond, x and y must have the same size
A = [10, 20, 30; 40, 50, 60];
x = where([true, false], [1, 2, 3], 0)
