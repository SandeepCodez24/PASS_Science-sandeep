# Expected: time error: invalid hour 25 (expected 0-23)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = set_time(t1, 25, 0, 0, "UTC")
