# Expected: correlate: mode must be "valid", "same" or "full"
A = [1, 2, 3; 4, 5, 6];
x = correlate([1, 2], [1], mode="middle")
