# Expected: matrix_split: 3 columns cannot be cut into 2 equal parts - give the cut positions instead, e.g. [2]
A = [1, 2; 3, 4]; C = [1, 2, 3; 4, 5, 6];
x = matrix_split(C, 2, axis=1)
