# Expected: unique: axis 2 does not exist for a 2-D input
A = [1, 2; 3, 4];
x = unique(A, axis=2)
