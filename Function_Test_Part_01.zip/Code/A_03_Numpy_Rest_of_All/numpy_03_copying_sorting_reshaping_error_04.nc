# Expected: rot90: the second argument must be a whole number
M = [3, 1, 2; 9, 7, 8];
x = rot90(M, 1.5)
