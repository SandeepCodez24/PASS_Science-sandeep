# Expected: histogram: the data holds NaN or infinity - give range=[lo, hi] or remove them first
A = [1, 2, 3; 4, 5, 6];
x = histogram([1, nan, 3])
