# Expected: ravel_index: index 5 is outside axis 1 (0..3)
A = [10, 20, 30; 40, 50, 60];
x = ravel_index([0, 5], [3, 4])
