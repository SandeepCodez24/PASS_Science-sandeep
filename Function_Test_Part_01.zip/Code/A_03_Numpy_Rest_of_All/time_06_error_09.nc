# Expected: time error: date_range: step must be a duration, e.g. days(1)
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = date_range(mon, sat, 5)
