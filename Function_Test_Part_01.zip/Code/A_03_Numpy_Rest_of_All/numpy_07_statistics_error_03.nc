# Expected: average: weights must be one number, one per element (6)
A = [1, 2, 3; 4, 5, 6];
x = average(A, weights=[1, 2])
