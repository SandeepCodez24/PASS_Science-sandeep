# Expected: time error: cannot concatenate timestamp with float64
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = [t1, 5]
