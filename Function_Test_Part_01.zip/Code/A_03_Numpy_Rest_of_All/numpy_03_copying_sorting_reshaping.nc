# NumPy section 3 - Copying, Sorting & Reshaping
#
#   sort_asc(A[, axis])      sorted ascending along an axis
#   sort_desc(A[, axis])     sorted descending along an axis
#   sort_complex(A[, axis])  sorted by real part, then imaginary part (gives complex)
#   flatten(A, order="C")    every element in one row: "C" row by row, "F" column by column
#   flip(A[, axis])          reversed along one axis (without axis: along every axis)
#   fliplr(A)                columns reversed (left <-> right)
#   flipud(A)                rows reversed (up <-> down)
#   rot90(A, k=1)            turned 90 degrees counter-clockwise k times (k < 0: clockwise)
#   roll(A, shift[, axis])   elements moved `shift` places around a cycle
#
# The existing sort(v) (vectors) and reshape(A, [r, c]) stay as they are.
#
# Which way does sorting go?
#   - a vector (one row or one column) is sorted along its length;
#   - any other matrix row by row (axis -1);  axis=0 sorts every column;
#   - NaN always goes last (in sort_desc too); text sorts alphabetically;
#     equal elements keep their order.
#
#     M = [3, 1, 2;      sort_asc(M) = [1, 2, 3;     sort_asc(M, axis=0) = [3, 1, 2;
#          9, 7, 8]                     7, 8, 9]                            9, 7, 8]
#
# fliplr / flipud / rot90 work on the columns and rows - on every page of an
# N-D matrix. roll without an axis moves the elements in row-by-row order and
# keeps the shape. Every function returns a new value; A never changes.
#
# The error cases are in numpy_03_copying_sorting_reshaping_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, got, want):
   if shape(got) == shape(want):
      if got == want:
         print("PASS  " + label)
      else:
         print("FAIL  " + label + "  (values differ)")
      iend
   else:
      print("FAIL  " + label + "  (shapes differ)")
   iend
fnend

M = [3, 1, 2; 9, 7, 8]

# --- sorting --------------------------------------------------------------------
check("sort a row", sort_asc([3, 1, 2]), [1, 2, 3]);
check("sort a column along its length", sort_asc([3; 1; 2]), [1; 2; 3]);
check("a matrix row by row", sort_asc([3, 1, 2; 9, 7, 8]), [1, 2, 3; 7, 8, 9]);
check("axis=0 sorts every column", sort_asc([3, 8; 1, 9; 2, 7], axis=0), [1, 7; 2, 8; 3, 9]);
check("descending", sort_desc([3, 1, 2]), [3, 2, 1]);
check("descending columns", sort_desc(M, axis=0), [9, 7, 8; 3, 1, 2]);
s = sort_asc([3, nan, 1])
check("NaN goes last (ascending)", s[0, 0] == 1 && s[0, 1] == 3 && is_nan(s[0, 2]), true);
d = sort_desc([3, nan, 1])
check("NaN goes last (descending)", d[0, 0] == 3 && d[0, 1] == 1 && is_nan(d[0, 2]), true);
check("text alphabetically", sort_asc(["pear", "apple", "fig"]), ["apple", "fig", "pear"]);
check("negative numbers", sort_asc([0, -5, 2, -1]), [-5, -1, 0, 2]);
check("M itself is unchanged", M, [3, 1, 2; 9, 7, 8]);
c = sort_complex([3, 1+2i, 1-1i, 2])
check("sort_complex: real part first", real(c), [1, 1, 2, 3]);
check("sort_complex: then imaginary part", imag(c), [-1, 2, 0, 0]);
N = [4, 3; 2, 1 ;; 8, 7; 6, 5]
check("sorting an N-D matrix sorts every row of every page", sort_asc(N)[1], [7, 8; 5, 6]);

# --- flatten --------------------------------------------------------------------
check("flatten row by row", flatten(M), [3, 1, 2, 9, 7, 8]);
check("flatten column by column", flatten(M, order="F"), [3, 9, 1, 7, 2, 8]);
check("flatten an N-D matrix", flatten([1, 2; 3, 4 ;; 5, 6; 7, 8]), [1, 2, 3, 4, 5, 6, 7, 8]);

# --- flipping -------------------------------------------------------------------
check("fliplr", fliplr(M), [2, 1, 3; 8, 7, 9]);
check("flipud", flipud(M), [9, 7, 8; 3, 1, 2]);
check("flip axis=0 is flipud", flip(M, axis=0), flipud(M));
check("flip axis=1 is fliplr", flip(M, axis=1), fliplr(M));
check("flip without axis reverses everything", flip(M), [8, 7, 9; 2, 1, 3]);
check("reverse a row", flip([1, 2, 3, 4]), [4, 3, 2, 1]);

# --- rot90 ----------------------------------------------------------------------
check("rot90 once (counter-clockwise)", rot90(M), [2, 8; 1, 7; 3, 9]);
check("rot90 twice", rot90(M, 2), [8, 7, 9; 2, 1, 3]);
check("rot90 -1 is clockwise", rot90(M, -1), [9, 3; 7, 1; 8, 2]);
check("four turns give M back", rot90(M, 4), M);
check("rot90 turns every page of an N-D matrix", rot90([1, 2; 3, 4 ;; 5, 6; 7, 8])[1], [6, 8; 5, 7]);

# --- roll -----------------------------------------------------------------------
check("roll right by 2", roll([1, 2, 3, 4, 5], 2), [4, 5, 1, 2, 3]);
check("roll left by 1", roll([1, 2, 3, 4, 5], -1), [2, 3, 4, 5, 1]);
check("roll a matrix row by row, shape kept", roll(M, 1), [8, 3, 1; 2, 9, 7]);
check("roll columns", roll(M, -1, axis=1), [1, 2, 3; 7, 8, 9]);
check("roll rows", roll(M, 1, axis=0), [9, 7, 8; 3, 1, 2]);
