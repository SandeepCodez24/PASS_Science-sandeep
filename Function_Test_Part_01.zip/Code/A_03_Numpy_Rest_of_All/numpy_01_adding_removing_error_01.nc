# Expected: insert: index 5 is outside 0..3
A = [1, 2; 3, 4];
x = insert([1, 2, 3], 5, 9)
