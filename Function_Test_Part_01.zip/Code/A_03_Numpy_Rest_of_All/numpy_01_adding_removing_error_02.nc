# Expected: insert: values must be a single value, one slice of 2 values, or a block whose other sizes match A
A = [1, 2; 3, 4];
x = insert(A, 1, [1, 2, 3], axis=0)
