# Expected: time error: is_busday expects a timestamp, got text - convert it first with to_timestamp(...)
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = is_busday("2026-10-26")
