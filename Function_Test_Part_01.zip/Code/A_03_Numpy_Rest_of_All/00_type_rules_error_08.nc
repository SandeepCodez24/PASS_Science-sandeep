# Expected error: matrix + text
x = [1, 2] + "5"
