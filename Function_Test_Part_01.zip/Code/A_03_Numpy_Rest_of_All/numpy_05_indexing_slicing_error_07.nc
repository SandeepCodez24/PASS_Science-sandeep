# Expected: compress: cond has 4 entries but A has only 3 along axis 1
A = [10, 20, 30; 40, 50, 60];
x = compress([true, false, true, true], A, axis=1)
