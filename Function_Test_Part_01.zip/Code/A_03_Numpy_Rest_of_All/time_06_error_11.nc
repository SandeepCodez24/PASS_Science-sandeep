# Expected: time error: unknown time zone "Mars/Olympus"
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = is_busday(mon, zone="Mars/Olympus")
