# Expected: extend error (,=): M is 3x2, value is 1x3 - row count mismatch (3 vs 1) + column hint
M = [1, 2; 3, 4; 5, 6]
M ,= [7, 8, 9]
