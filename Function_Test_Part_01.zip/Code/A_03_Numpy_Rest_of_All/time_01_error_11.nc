# Expected: time error: seconds expects a number, got text
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = seconds("5")
