# Expected: ravel_index: the index needs one row per axis of dims (2 rows)
A = [10, 20, 30; 40, 50, 60];
x = ravel_index([0, 1, 2], [3, 4])
