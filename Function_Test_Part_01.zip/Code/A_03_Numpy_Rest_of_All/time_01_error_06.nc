# Expected: time error: 02:30:00 on 2026-03-29 does not exist in time zone "Europe/Berlin" (clocks jump 02:00 -> 03:00)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = timestamp(2026, 3, 29, 2, 30, 0, "Europe/Berlin")
