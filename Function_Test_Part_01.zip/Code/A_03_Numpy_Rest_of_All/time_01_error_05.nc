# Expected: time error: unknown time zone "Asia/Kolkatta"
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = timestamp(2026, 1, 1, "Asia/Kolkatta")
