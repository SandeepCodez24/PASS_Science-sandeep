# Expected error: dec2frac gives text - convert with float() or frac2deci()
x = dec2frac(0.5) + 1
