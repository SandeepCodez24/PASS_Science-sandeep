# Expected: time error: unknown roll "sideways"
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = busday_offset(mon, 1, roll="sideways")
