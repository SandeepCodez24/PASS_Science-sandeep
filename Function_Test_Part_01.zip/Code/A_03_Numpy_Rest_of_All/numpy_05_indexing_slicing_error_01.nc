# Expected: take: position 6 is outside A's 6 elements (0..5)
A = [10, 20, 30; 40, 50, 60];
x = take(A, 6)
