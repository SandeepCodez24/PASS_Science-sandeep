# Expected: time error: tic takes no arguments
x = tic(1)
