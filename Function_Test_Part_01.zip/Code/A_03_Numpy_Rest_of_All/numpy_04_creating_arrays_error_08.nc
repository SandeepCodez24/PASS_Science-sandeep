# Expected: rand_mvnormal: cov must be symmetric
A = [1, 2; 3, 4];
x = rand_mvnormal([0, 0], [1, 2; 0, 1])
