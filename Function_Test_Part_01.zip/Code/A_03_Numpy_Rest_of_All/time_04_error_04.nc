# Expected: time error: cannot combine duration and number (toc() is a duration)
tic();
x = toc() + 5
