# Expected: where: a condition must hold true/false (or numbers, 0 = false)
A = [10, 20, 30; 40, 50, 60];
x = where(["a", "b"], 1, 2)
