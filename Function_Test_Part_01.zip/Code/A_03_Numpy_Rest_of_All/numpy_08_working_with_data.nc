# NumPy section 8 - Working with Data
#
# Checking values (true / false per element, the shape kept)
#   is_nan_each(A)  is_inf(A)  is_finite(A)  is_posinf(A)  is_neginf(A)
#   (the existing is_nan(x) stays for one number)
#
# Distinct values with their bookkeeping
#   [values, indices, inverse, counts] = unique_all(A)
#     values   the distinct elements, sorted
#     indices  where each one first occurs (flat position, row by row)
#     inverse  for every element of A, its place in values - values[inverse] is A
#     counts   how often each one occurs
#
# Filling missing data (NaN)
#   fill_nan(A, value=0, method="value", axis=-1)
#     "value"   NaN -> value
#     "ffill"   NaN -> the last number before it    (forward fill)
#     "bfill"   NaN -> the next number after it     (backward fill)
#     "mean"    NaN -> the mean of the numbers of its line
#     "linear"  NaN -> on the straight line between its neighbours
#   Lines run along axis (-1: every row; 0: every column); a vector along its
#   length. Where a neighbour is missing (a NaN at the very start for "ffill"),
#   value is used.
#
# Text - one text, or element by element on a matrix of text. Lengths and
# positions count characters ("日本語" has 3), positions start at 0.
#   str_concat(a, b)               a and b joined
#   split_str(s, sep="", maxsplit=-1)   the parts, as a row of text; sep=""
#                                  splits at runs of spaces and drops empty parts
#   join(sep, texts)               the texts joined with sep between them
#   strip(T, chars="")             T without leading / trailing spaces (or chars)
#   find_str(T, sub)               first position of sub, -1 when absent
#   count_str(T, sub)              how often sub occurs (not overlapping)
#   starts_with(T, prefix) / ends_with(T, suffix)
#   center(T, width, fill=" ")     T in the middle of `width` characters
#   zfill(T, width)                zeros on the left, after a sign: "-0042"
#   is_digit(T)                    not empty and only the digits 0-9
#   str_len(T)                     number of characters
# The existing upper(), lower(), replace() and substr() stay as they are.
#
# Dates (date_range, is_busday, busday_count, busday_offset) are in the time
# module - see time_06_calendar.nc.
#
# The error cases are in numpy_08_working_with_data_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

# --- checking values ------------------------------------------------------------
check("is_nan_each per element", is_nan_each([1, nan; inf, 2]) == [false, true; false, false]);
check("is_inf", is_inf([1, -inf, inf]) == [false, true, true]);
check("is_finite", is_finite([1, nan, inf]) == [true, false, false]);
check("is_posinf", is_posinf([1, -inf, inf]) == [false, false, true]);
check("is_neginf", is_neginf([1, -inf, inf]) == [false, true, false]);
check("one value gives one answer", is_finite(5) == true);
check("count the NaN in data", sum(is_nan_each([1, nan, 3, nan])) == 2);

# --- unique_all -----------------------------------------------------------------
data = [3, 1, 3, 2, 1, 3]
[v, i, inv, c] = unique_all(data)
check("distinct values", v == [1, 2, 3]);
check("first positions", i == [1, 3, 0]);
check("inverse: the place of every element", inv == [2, 0, 2, 1, 0, 2]);
check("counts", c == [2, 1, 3]);
check("values[inverse] rebuilds the data", take(v, inv) == data);

# --- fill_nan -------------------------------------------------------------------
check("fill with 0", fill_nan([1, nan, 3]) == [1, 0, 3]);
check("fill with a value", fill_nan([1, nan, 3], value=-1) == [1, -1, 3]);
check("linear", fill_nan([1, nan, nan, 4], method="linear") == [1, 2, 3, 4]);
check("forward fill", fill_nan([5, nan, nan, 7, nan], method="ffill") == [5, 5, 5, 7, 7]);
check("backward fill", fill_nan([nan, 2, nan, 4], method="bfill") == [2, 2, 4, 4]);
check("nothing before: value is used", fill_nan([nan, 2], method="ffill", value=-1) == [-1, 2]);
check("mean of every row", fill_nan([1, nan, 3; nan, 4, 6], method="mean") == [1, 2, 3; 5, 4, 6]);
check("mean of every column", fill_nan([1, nan; 3, 5], method="mean", axis=0) == [1, 5; 3, 5]);
check("a column vector along its length", fill_nan([1; nan; 3], method="linear") == [1; 2; 3]);

# --- text -----------------------------------------------------------------------
check("str_concat", str_concat("Neural", " Code") == "Neural Code");
check("str_concat element by element", str_concat(["a", "b"], "!") == ["a!", "b!"]);
check("split at spaces", split_str("  the quick  brown fox ") == ["the", "quick", "brown", "fox"]);
check("split at a separator keeps empty parts", split_str("a,b,,c", sep=",") == ["a", "b", "", "c"]);
check("split at most twice", split_str("a b c d", maxsplit=2) == ["a", "b", "c d"]);
check("join", join("-", ["2026", "10", "28"]) == "2026-10-28");
check("split then join gives the text back", join(",", split_str("x,y,z", sep=",")) == "x,y,z");
check("strip spaces", strip("  hi  ") == "hi");
check("strip chosen characters", strip("xxhixx", chars="x") == "hi");
check("find_str", find_str(["hello", "world"], "o") == [4, 1]);
check("find_str not found", find_str("abc", "z") == -1);
check("count_str", count_str("banana", "an") == 2);
check("starts_with", starts_with(["apple", "banana"], "ap") == [true, false]);
check("ends_with", ends_with("report.nc", ".nc"));
check("center", center("ab", 5, fill="*") == "**ab*");
check("center with spaces", center("NC", 6) == "  NC  ");
check("zfill keeps the sign first", zfill(["-42", "7"], 5) == ["-0042", "00007"]);
check("is_digit", is_digit(["123", "12a", ""]) == [true, false, false]);
check("str_len counts characters", str_len(["héllo", "日本語", ""]) == [5, 3, 0]);
check("find_str counts characters too", find_str("日本語テキスト", "テ") == 3);
