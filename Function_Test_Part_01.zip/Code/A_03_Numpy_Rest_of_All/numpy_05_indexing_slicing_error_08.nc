# Expected: extract: cond must have as many elements as A
A = [10, 20, 30; 40, 50, 60];
x = extract([true, false], A)
