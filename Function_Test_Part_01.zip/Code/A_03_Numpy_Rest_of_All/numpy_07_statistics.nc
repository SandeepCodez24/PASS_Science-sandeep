# NumPy section 7 - Statistics
#
# AXIS in this section: every reduction takes axis="all" (the default - all
# elements together, one result) or an axis number - one result per column
# (axis=0) or per row (axis=1), the axis disappearing as in max(A, axis=k):
#
#     A = [1, 2, 3;       prod(A) = 720       prod(A, axis=0) = [4, 10, 18]
#          4, 5, 6]                           prod(A, axis=1) = [6, 120]
#
# Reductions
#   average(A, axis="all", weights=1)   weighted mean - weights=1 is the plain mean
#   prod(A, axis="all")                  product
#   argmin(A, axis="all") / argmax       position of the smallest / largest element
#                                        (axis="all": flat position, row by row)
#   count_nonzero(A, axis="all")         how many elements are not 0
#   all(A, axis="all") / any             is every / some element true (not 0)?
# Running totals (axis="all": the elements row by row, as one row)
#   cumsum(A, axis="all") / cumprod
#   cumulative_sum(A, axis="all", include_initial=false) / cumulative_prod
#                                        include_initial=true starts with 0 / 1
# Leaving NaN out (missing data)
#   nan_mean nan_median nan_sum nan_prod nan_min nan_max nan_argmin nan_argmax
#   nan_var / nan_sd (A, axis="all", ddof=0)   population (ddof=0, like pvar / psd);
#                                              ddof=1 for the sample estimate
#   nan_percentile(A, q) (q in 0..100)   nan_quantile(A, q) (q in 0..1)
#                                        linear interpolation, like percentile()
#   nan_cumsum (NaN counts as 0)  nan_cumprod (NaN counts as 1)
# Bins
#   [counts, edges] = histogram(a, bins=10, density=false, range?)
#   bin_edges(a, bins=10, range?)        the edges histogram would use
#   [H, xedges, yedges] = histogram2d(x, y, bins=10, range?)
#   [H, edges] = histogramdd(sample, bins=10, range?)   sample: one row per point
#   bincount(x, weights=1, minlength=0)  how often each whole number 0, 1, 2 ... occurs
#   digitize(x, bins, right=false)       the bin number of each value
#       (every bin holds lo <= x < hi; the last one also its right edge)
# Sequences
#   correlate(a, v, mode="valid")        cross-correlation ("valid", "same", "full")
#   gradient(f, spacing=1, axis="all")   rate of change; a matrix gives [g_rows, g_cols]
#   trapz(y, dx=1, axis=-1, x?)          area under the curve (trapezoid rule)
#   interp(x, xp, fp, left="end", right="end")   straight-line interpolation
#
# The error cases are in numpy_07_statistics_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, got, want):
   if shape(got) == shape(want):
      if abs(got - want) < 1e-9:
         print("PASS  " + label)
      else:
         print("FAIL  " + label + "  (values differ)")
      iend
   else:
      print("FAIL  " + label + "  (shapes differ)")
   iend
fnend

function check_true(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

A = [1, 2, 3; 4, 5, 6]

# --- reductions -------------------------------------------------------------------
check("average of all", average(A), 3.5);
check("average of every column", average(A, axis=0), [2.5, 3.5, 4.5]);
check("weighted average", average([1, 2, 3], weights=[3, 1, 0]), 1.25);
check("weighted average of every row", average(A, axis=1, weights=[1, 0, 1]), [2, 5]);
check("prod of all", prod(A), 720);
check("prod of every column", prod(A, axis=0), [4, 10, 18]);
check("prod of every row", prod(A, axis=1), [6, 120]);
check("argmax: flat position", argmax(A), 5);
check("argmin of every column", argmin([3, 1, 2; 0, 9, 9], axis=0), [1, 0, 0]);
check("argmax: the first of equal ones", argmax([1, 7, 7]), 1);
check("count_nonzero per column", count_nonzero([0, 1, 2; 0, 0, 3], axis=0), [0, 1, 2]);
check_true("all per column", all([1, 1; 0, 1], axis=0) == [false, true]);
check_true("any", any([0, 0, 1]));
check_true("all is false with one 0", all([1, 2, 0]) == false);

# --- running totals -------------------------------------------------------------------
check("cumsum row by row", cumsum(A), [1, 3, 6, 10, 15, 21]);
check("cumsum along every row", cumsum(A, axis=1), [1, 3, 6; 4, 9, 15]);
check("cumsum down every column", cumsum(A, axis=0), [1, 2, 3; 5, 7, 9]);
check("cumprod", cumprod([1, 2, 3, 4]), [1, 2, 6, 24]);
check("cumulative_sum with a starting 0", cumulative_sum([1, 2, 3], include_initial=true), [0, 1, 3, 6]);
check("cumulative_sum down columns, starting row", cumulative_sum(A, axis=0, include_initial=true), [0, 0, 0; 1, 2, 3; 5, 7, 9]);
check("cumulative_prod", cumulative_prod([2, 3, 4]), [2, 6, 24]);

# --- missing data: nan_ functions ------------------------------------------------------
check("nan_mean", nan_mean([1, nan, 3]), 2);
check("nan_median", nan_median([1, nan, 3, 10]), 3);
check("nan_sum", nan_sum([1, nan, 2]), 3);
check("nan_sum of nothing but NaN is 0", nan_sum([nan, nan]), 0);
check("nan_prod", nan_prod([2, nan, 4]), 8);
check("nan_min", nan_min([nan, 2, 1]), 1);
check("nan_max of every column", nan_max([1, nan; 3, 0], axis=0), [3, 0]);
check("nan_argmin", nan_argmin([nan, 2, 1, nan]), 2);
check("nan_argmax", nan_argmax([nan, 2, 5, nan]), 2);
check("nan_var is the population variance (like pvar)", nan_var([1, 2, 3, 4, nan]), pvar([1, 2, 3, 4]));
check("nan_sd with ddof=1 is the sample deviation", nan_sd([1, 2, 3, 4], ddof=1), sd([1, 2, 3, 4]));
check("nan_percentile agrees with percentile", nan_percentile([1, 2, 3, 4, nan], 25), percentile([1, 2, 3, 4], 25));
check("several percentiles of every row", nan_percentile(A, [0, 50, 100], axis=1), [1, 4; 2, 5; 3, 6]);
check("nan_quantile 0.5 is the median", nan_quantile([1, 2, 3, 4], 0.5), 2.5);
check("nan_cumsum counts NaN as 0", nan_cumsum([1, nan, 2]), [1, 1, 3]);
check("nan_cumprod counts NaN as 1", nan_cumprod([2, nan, 3]), [2, 2, 6]);
check_true("nan_mean of nothing but NaN is NaN", is_nan(nan_mean([nan, nan])));

# --- bins -------------------------------------------------------------------------
[h, e] = histogram([1, 2, 2, 3, 3, 3], bins=3)
check("histogram counts", h, [1, 2, 3]);
check("histogram edges", e, [1, 5 / 3, 7 / 3, 3]);
[hd, ed] = histogram([1, 2, 2, 3, 3, 3], bins=3, density=true)
check("density: the bars have area 1", hd * (ed[0, 1] - ed[0, 0]) * ones(3, 1), 1);
[hr, er] = histogram([0, 5, 15], bins=2, range=[0, 10])
check("range leaves 15 out", hr, [1, 1]);
check("bin_edges", bin_edges([0, 10], bins=5), [0, 2, 4, 6, 8, 10]);
[hb, eb] = histogram([1, 4, 6], bins=[0, 5, 10])
check("bins given as edges", hb, [2, 1]);
[H2, xe, ye] = histogram2d([0, 1, 1], [0, 0, 1], bins=2)
check("histogram2d counts", H2, [1, 0; 1, 1]);
[Hd, E] = histogramdd([0, 0; 1, 1; 1, 0], bins=2)
check("histogramdd counts", Hd, [1, 0; 1, 1]);
check("bincount", bincount([0, 1, 1, 3]), [1, 2, 0, 1]);
check("bincount with weights and minlength", bincount([0, 1, 1], weights=[0.5, 1, 2], minlength=4), [0.5, 3, 0, 0]);
check("digitize", digitize([0.2, 6.4, 3.0, 1.6], [0, 1, 2.5, 4, 10]), [1, 4, 3, 2]);
check("digitize right=true", digitize([1, 2.5], [0, 1, 2.5, 4], right=true), [1, 2]);
check("digitize with decreasing bins", digitize([0.2, 6.4], [10, 4, 2.5, 1, 0]), [4, 1]);

# --- sequences ----------------------------------------------------------------------
check("correlate valid", correlate([1, 2, 3], [0, 1, 0.5]), 3.5);
check("correlate same", correlate([1, 2, 3], [0, 1, 0.5], mode="same"), [2, 3.5, 3]);
check("correlate full", correlate([1, 2, 3], [0, 1, 0.5], mode="full"), [0.5, 2, 3.5, 3, 0]);
check("gradient, step 1", gradient([1, 2, 4, 7, 11]), [1, 1.5, 2.5, 3.5, 4]);
check("gradient, step 2", gradient([1, 2, 4, 7, 11], spacing=2), [0.5, 0.75, 1.25, 1.75, 2]);
check("gradient, uneven coordinates", gradient([1, 2, 4, 7, 11], spacing=[0, 1, 1.5, 3.5, 4]), [1, 3, 3.5, 6.7, 8]);
[gr, gc] = gradient([1, 2, 6; 3, 4, 5])
check("gradient of a matrix down the rows", gr, [2, 2, -1; 2, 2, -1]);
check("gradient of a matrix across the columns", gc, [1, 2.5, 4; 1, 1, 1]);
check("gradient of a column vector along its length", gradient([1; 4; 9]), [3; 4; 5]);
check("trapz with step 1", trapz([1, 2, 3]), 4);
check("trapz with coordinates", trapz([1, 2, 3], x=[4, 6, 8]), 8);
check("trapz: a vector second is x", trapz([1, 2, 3], [4, 6, 8]), 8);
check("trapz of every row", trapz(A), [4, 10]);
check("trapz of a column vector", trapz([1; 2; 3]), 4);
check("interp inside and outside", interp([2.5, 0, 9], [1, 2, 3], [3, 2, 0]), [1, 3, 0]);
check("interp with left / right", interp([0, 9], [1, 2, 3], [3, 2, 0], left=-1, right=99), [-1, 99]);
check("interp of one value", interp(1.5, [1, 2], [10, 20]), 15);
