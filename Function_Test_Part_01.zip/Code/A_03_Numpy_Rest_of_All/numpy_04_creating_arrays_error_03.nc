# Expected: rand_choice: cannot take 5 different elements from 3 without replace=true
A = [1, 2; 3, 4];
x = rand_choice([1, 2, 3], size=5, replace=false)
