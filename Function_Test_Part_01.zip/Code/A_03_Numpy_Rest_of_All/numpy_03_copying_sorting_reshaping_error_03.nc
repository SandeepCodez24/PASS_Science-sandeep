# Expected: flatten: order must be "C" (row by row) or "F" (column by column)
M = [3, 1, 2; 9, 7, 8];
x = flatten(M, order="K")
