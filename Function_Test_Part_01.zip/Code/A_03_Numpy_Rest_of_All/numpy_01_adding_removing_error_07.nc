# Expected: pad: width must be n, [before, after], or 2 rows of [before, after]
A = [1, 2; 3, 4];
x = pad(A, [1, 2, 3])
