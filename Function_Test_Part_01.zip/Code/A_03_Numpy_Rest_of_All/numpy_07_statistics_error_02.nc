# Expected: average: the weights add up to 0
A = [1, 2, 3; 4, 5, 6];
x = average([1, 2], weights=[1, -1])
