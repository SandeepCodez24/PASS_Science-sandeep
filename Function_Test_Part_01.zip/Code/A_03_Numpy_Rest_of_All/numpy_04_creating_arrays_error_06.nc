# Expected: rand_gamma: shape must be a positive number
A = [1, 2; 3, 4];
x = rand_gamma(-1)
