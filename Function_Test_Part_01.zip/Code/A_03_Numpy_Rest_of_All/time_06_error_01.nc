# Expected: time error: 2026-10-31 is not a business day (Saturday) - give roll="forward" or roll="backward"
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = busday_offset(sat, 1)
