# Expected error: number + text - left value is numeric, hint 1 + float("5")
x = 1 + "5"
