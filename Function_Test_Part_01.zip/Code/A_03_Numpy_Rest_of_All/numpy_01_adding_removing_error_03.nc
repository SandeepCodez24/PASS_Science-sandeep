# Expected: insert: index must be a whole number
A = [1, 2; 3, 4];
x = insert(A, 1.5, 0)
