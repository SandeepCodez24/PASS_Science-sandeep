# NumPy section 1 - Adding & Removing Elements
#
# Every function returns a NEW value - A itself never changes.
#
#   insert(A, index, values[, axis])     values put in BEFORE position `index`
#   repeat(A, repeats[, axis])           each element (or slice) repeated
#   pad(A, width, mode="constant", value=0)
#                                        a border around A
#   trim_zeros(v, trim="fb")             zeros taken off the front ("f"),
#                                        back ("b") or both ("fb") of a vector
#   unique(A[, axis])                    the distinct elements, sorted
#                                        (with axis: distinct rows / columns)
#   put(A, indices, values)              A with flat positions replaced
#   replace_if(A, mask, value)           A with the elements where mask is
#                                        true replaced
#   fill_diagonal(A, value, wrap=false)  A with its main diagonal set
#   nan_to_num(A, nan=0, posinf?, neginf?)
#                                        NaN and +-Inf replaced by numbers
#                                        (default: 0 and the largest finite numbers)
#
# Without an axis, insert / repeat / unique use the elements of A row by row
# (A = [1, 2; 3, 4] is taken as 1, 2, 3, 4) and give a 1xN row. With
# axis=0 they work on whole rows, with axis=1 on whole columns (axis -1 is
# always the columns, -2 the rows - see numpy_02_combining_splitting.nc).
# Positions are 0-based; a negative one counts from the end.
#
# pad: `width` is n (every side), [before, after] (every axis), or one
# [before, after] row per axis - so to pad only the ends of a row vector
# write [0, 0; 2, 2] (rows: nothing, columns: 2 and 2). Modes:
#   "constant"   the value (0 unless value= is given)     [0 0 | 1 2 3 | 0 0]
#   "edge"       the edge element repeated                [1 1 | 1 2 3 | 3 3]
#   "reflect"    mirrored, edge not repeated              [3 2 | 1 2 3 | 2 1]
#   "symmetric"  mirrored, edge repeated                  [2 1 | 1 2 3 | 3 2]
#   "wrap"       continued from the other end             [2 3 | 1 2 3 | 1 2]
#
# The error cases are in numpy_01_adding_removing_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, got, want):
   if shape(got) == shape(want):
      if got == want:
         print("PASS  " + label)
      else:
         print("FAIL  " + label + "  (values differ)")
      iend
   else:
      print("FAIL  " + label + "  (shapes differ)")
   iend
fnend

A = [1, 2; 3, 4]
v = [1, 2, 3]

# --- insert -----------------------------------------------------------------------
check("insert one value", insert(v, 1, 9), [1, 9, 2, 3]);
check("insert at the end", insert(v, 3, 9), [1, 2, 3, 9]);
check("negative index counts from the end", insert(v, -1, 9), [1, 2, 9, 3]);
check("several values at one place", insert(v, 1, [7, 8]), [1, 7, 8, 2, 3]);
check("one value at several places", insert(v, [0, 3], [7, 8]), [7, 1, 2, 3, 8]);
check("a matrix without axis is taken row by row", insert(A, 2, 0), [1, 2, 0, 3, 4]);
check("insert a row (axis=0)", insert(A, 1, [9, 9], axis=0), [1, 2; 9, 9; 3, 4]);
check("insert a column (axis=1) from one value", insert(A, 1, 0, axis=1), [1, 0, 2; 3, 0, 4]);
check("insert a column from a vector", insert(A, 1, [7, 8], axis=1), [1, 7, 2; 3, 8, 4]);
check("insert a block of 2 columns", insert(A, 2, [5, 6; 7, 8], axis=1), [1, 2, 5, 6; 3, 4, 7, 8]);
check("types follow the matrix rules", insert(A, 1, 2.5), [1, 2.5, 2, 3, 4]);
N = [1, 2; 3, 4 ;; 5, 6; 7, 8]
check("insert a page into an N-D matrix", shape(insert(N, 1, 0, axis=0)), [3, 2, 2]);

# --- repeat -----------------------------------------------------------------------
check("repeat every element", repeat([1, 2], 3), [1, 1, 1, 2, 2, 2]);
check("repeat with one count per element", repeat([1, 2, 3], [0, 1, 2]), [2, 3, 3]);
check("repeat rows", repeat(A, 2, axis=0), [1, 2; 1, 2; 3, 4; 3, 4]);
check("repeat columns, different counts", repeat(A, [1, 3], axis=1), [1, 2, 2, 2; 3, 4, 4, 4]);

# --- pad --------------------------------------------------------------------------
check("pad a matrix by 1", pad(A, 1), [0, 0, 0, 0; 0, 1, 2, 0; 0, 3, 4, 0; 0, 0, 0, 0]);
check("pad with another value", pad(A, 1, value=-1)[0, 0], -1);
check("pad only the ends of a row", pad(v, [0, 0; 2, 2]), [0, 0, 1, 2, 3, 0, 0]);
check("mode edge", pad(v, [0, 0; 2, 2], mode="edge"), [1, 1, 1, 2, 3, 3, 3]);
check("mode reflect", pad(v, [0, 0; 2, 2], mode="reflect"), [3, 2, 1, 2, 3, 2, 1]);
check("mode symmetric", pad(v, [0, 0; 2, 2], mode="symmetric"), [2, 1, 1, 2, 3, 3, 2]);
check("mode wrap", pad(v, [0, 0; 2, 2], mode="wrap"), [2, 3, 1, 2, 3, 1, 2]);
check("before and after differ", pad(A, [0, 1; 1, 0]), [0, 1, 2; 0, 3, 4; 0, 0, 0]);

# --- trim_zeros -------------------------------------------------------------------
check("trim both ends", trim_zeros([0, 0, 1, 2, 0, 3, 0]), [1, 2, 0, 3]);
check("trim the front only", trim_zeros([0, 1, 0], trim="f"), [1, 0]);
check("trim the back only", trim_zeros([0, 1, 0], trim="b"), [0, 1]);
check("a column stays a column", trim_zeros([0; 5; 6; 0]), [5; 6]);

# --- unique -----------------------------------------------------------------------
check("distinct elements, sorted", unique([3, 1, 2, 3, 1]), [1, 2, 3]);
check("a matrix row by row", unique([4, 1; 1, 4]), [1, 4]);
check("NaN goes last, once", shape(unique([1, nan, 2, nan])), [1, 3]);
check("text sorts alphabetically", unique(["pear", "apple", "pear"]), ["apple", "pear"]);
check("distinct rows (axis=0)", unique([1, 2; 1, 2; 0, 9], axis=0), [0, 9; 1, 2]);
check("distinct columns (axis=1)", unique([1, 1, 0; 2, 2, 9], axis=1), [0, 1; 9, 2]);

# --- put / replace_if / fill_diagonal ----------------------------------------------
check("put at flat positions", put(A, [0, 3], [10, 40]), [10, 2; 3, 40]);
check("put with a negative position", put(A, -1, 0), [1, 2; 3, 0]);
check("put repeats the values", put([0, 0, 0, 0], [0, 1, 2, 3], [5, 6]), [5, 6, 5, 6]);
check("A is unchanged", A, [1, 2; 3, 4]);
check("replace where a condition holds", replace_if(A, A > 2, 0), [1, 2; 0, 0]);
check("replace element by element", replace_if(A, [true, false; false, true], [10, 20; 30, 40]), [10, 2; 3, 40]);
check("fill_diagonal of a square", fill_diagonal(zeros(3, 3), 7), [7, 0, 0; 0, 7, 0; 0, 0, 7]);
check("fill_diagonal with several values", fill_diagonal(zeros(3, 3), [1, 2, 3]), [1, 0, 0; 0, 2, 0; 0, 0, 3]);
check("a tall matrix stops at its square part", fill_diagonal(zeros(4, 2), 1), [1, 0; 0, 1; 0, 0; 0, 0]);
check("... unless wrap=true", fill_diagonal(zeros(5, 2), 1, wrap=true), [1, 0; 0, 1; 0, 0; 1, 0; 0, 1]);

# --- nan_to_num -------------------------------------------------------------------
check("NaN becomes 0", nan_to_num([nan, 1]), [0, 1]);
check("chosen replacements", nan_to_num([nan, inf, -inf], nan=-1, posinf=99, neginf=-99), [-1, 99, -99]);
check("infinity becomes the largest finite number", nan_to_num(inf) > 1e308, true);
