# Expected: join: every element of texts must be text in quotes
x = join("-", [1, 2])
