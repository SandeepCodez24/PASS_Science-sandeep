# Expected: time error: unknown time zone "Asia/Kolkatta"
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = get_time(t1, "Asia/Kolkatta")
