# Expected: rand_choice: the probabilities p must add up to 1
A = [1, 2; 3, 4];
x = rand_choice([1, 2], p=[0.5, 0.6])
