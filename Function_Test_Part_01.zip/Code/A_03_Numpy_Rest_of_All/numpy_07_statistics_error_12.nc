# Expected: trapz: x needs one coordinate per point along the axis (3), got 2
A = [1, 2, 3; 4, 5, 6];
x = trapz([1, 2, 3], x=[1, 2])
