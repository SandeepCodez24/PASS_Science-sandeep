# NumPy section 6 - Inspecting Properties
#
#   ndim(A)              number of dimensions: 0 for a single value, 1 for a
#                        1-D array (e.g. from space()), 2 for a matrix -
#                        [1, 2, 3] is a 1x3 matrix, so 2 - N for an N-D matrix
#   is_scalar(x)         true for ONE value (number, bool, text, timestamp ...),
#                        false for any matrix, even a 1x1 one like [5]
#   is_complex_each(A)   per element: true where the imaginary part is not 0
#   is_real_each(A)      per element: true where the imaginary part is 0
#   type(x)              the element type, as text
#   is_type(x, name)     whether type(x) is `name`, or belongs to the group
#                        "integer", "float", "number", "complex" or "time"
#   can_cast(from, to, casting="safe")
#                        whether values of type `from` (a value, or a type name)
#                        can be turned into type `to`:
#                          "safe"       every value fits exactly (int8 -> int16 yes,
#                                       int16 -> int8 no, int32 -> float64 yes)
#                          "same_kind"  allowed within numbers going down in size too
#                                       (float64 -> float32 yes, float -> int no)
#                          "unsafe"     any number to any number (or to text)
#                          "no"         only the very same type
#
# The existing shape(A), numel(A), is_complex(A) and is_real(A) stay as they are.
#
# Type names: bool, int8, int16, int32, int64, uint8, uint16, uint32, uint64,
#             float8, float16, float32, float64, complex128, text,
#             timestamp, duration
#
# The error cases are in numpy_06_inspecting_properties_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

# --- ndim / is_scalar -------------------------------------------------------------
check("ndim of a single value is 0", ndim(5) == 0);
check("ndim of a row vector is 2", ndim([1, 2, 3]) == 2);
check("ndim of a 1-D array is 1", ndim(space(0, 1, 5)) == 1);
check("ndim of a matrix is 2", ndim([1, 2; 3, 4]) == 2);
check("ndim of a 2x2x2 matrix is 3", ndim([1, 2; 3, 4 ;; 5, 6; 7, 8]) == 3);
check("is_scalar of a number", is_scalar(3.5));
check("is_scalar of text", is_scalar("abc"));
check("is_scalar of a timestamp", is_scalar(timestamp(2026, 1, 1, "UTC")));
check("a 1x1 matrix is not a scalar", is_scalar([5]) == false);
check("a vector is not a scalar", is_scalar([1, 2]) == false);

# --- is_complex_each / is_real_each -----------------------------------------------
z = [1 + 2i, 3, 4i]
check("is_complex_each per element", is_complex_each(z) == [true, false, true]);
check("is_real_each per element", is_real_each(z) == [false, true, false]);
check("real numbers are all real", is_real_each([1, 2; 3, 4]) == [true, true; true, true]);
check("one value gives one answer", is_complex_each(2i) == true);

# --- type -------------------------------------------------------------------------
check("type of a number", type(2.5) == "float64");
check("type of a matrix is its element type", type([1, 2; 3, 4]) == "float64");
check("type of int8 values", type(int8([1, 2])) == "int8");
check("type of a bool", type(true) == "bool");
check("type of text", type("hello") == "text");
check("type of a complex number", type(1 + 2i) == "complex128");
check("type of a timestamp", type(timestamp(2026, 1, 1, "UTC")) == "timestamp");
check("type of a duration", type(minutes(5)) == "duration");
check("type of float32", type(float32(1.5)) == "float32");

# --- is_type ----------------------------------------------------------------------
check("is_type exact", is_type(int32(7), "int32"));
check("is_type group integer", is_type(uint8(7), "integer"));
check("is_type group float", is_type([1.5, 2], "float"));
check("is_type group number (int)", is_type(int16(1), "number"));
check("a bool is not a number group member", is_type(true, "number") == false);
check("is_type group time", is_type(hours(1), "time"));
check("is_type is false for another type", is_type(2.5, "int64") == false);

# --- can_cast ---------------------------------------------------------------------
check("int8 -> int16 is safe", can_cast("int8", "int16"));
check("int16 -> int8 is not safe", can_cast("int16", "int8") == false);
check("int32 -> float64 is safe", can_cast("int32", "float64"));
check("int32 -> float32 is not safe", can_cast("int32", "float32") == false);
check("uint8 -> int16 is safe", can_cast("uint8", "int16"));
check("uint8 -> int8 is not safe", can_cast("uint8", "int8") == false);
check("bool -> anything numeric is safe", can_cast("bool", "float16"));
check("float64 -> complex128 is safe", can_cast("float64", "complex128"));
check("complex -> float is never safe", can_cast("complex128", "float64") == false);
check("float64 -> float32 within the kind", can_cast("float64", "float32", casting="same_kind"));
check("float -> int is not the same kind", can_cast("float64", "int64", casting="same_kind") == false);
check("float -> int is allowed unsafely", can_cast("float64", "int8", casting="unsafe"));
check("from a value: its type counts", can_cast(int8(5), "int32"));
check("no: only the same type", can_cast("int8", "int16", casting="no") == false);
check("time types never become numbers", can_cast("timestamp", "int64", casting="unsafe") == false);
