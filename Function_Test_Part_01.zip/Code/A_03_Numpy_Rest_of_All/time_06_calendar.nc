# Date and time - calendar functions: date ranges and business days
#
# ---------------------------------------------------------------------------
# date_range(start, stop[, step])
# ---------------------------------------------------------------------------
#   Timestamps from start, every step, up to (NOT including) stop - a 1xN row.
#   step is a duration, days(1) when left out; a negative step counts down.
#     date_range(timestamp(2026, 1, 1), timestamp(2026, 1, 4))
#         -> 2026-01-01, 2026-01-02, 2026-01-03
#     date_range(t0, t1, hours(6))      every 6 hours
#     date_range(t1, t0, days(-1))      backwards
#
# ---------------------------------------------------------------------------
# Business days
# ---------------------------------------------------------------------------
#   is_busday(t)                 true when t falls on a business day
#   busday_count(begin, end)     business days from begin up to (NOT including)
#                                end; negative when end is before begin
#   busday_offset(t, n)          the business day n business days after t
#                                (n < 0: before t), as the start of that day
#
#   Options - give them by name, in any order:
#     weekmask="1111100"   which weekdays work, Monday first (1 = business day).
#                          Day names work too: "Sun Mon Tue Wed Thu".
#                          Every country's week can be written: a Sunday-to-
#                          Thursday week is "1111001" or "Sun Mon Tue Wed Thu".
#     holidays=[...]       days that never count: timestamps, or dates as text
#                          ["2026-12-25", "2026-12-26"]
#     zone="UTC"           the time zone whose calendar decides the day
#                          (the computer's own when left out)
#     roll="raise"         busday_offset only - when t itself is NOT a business day:
#                          "raise" (error, the default), "forward", "backward",
#                          "modifiedfollowing" (forward unless that leaves the
#                          month, then backward), "modifiedpreceding"
#
# Every function works element by element on a matrix of timestamps.
# The dates below are built and read in the same zone, so the file gives the
# same result on any computer. Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

# The week of Monday 2026-10-26.
mon = timestamp(2026, 10, 26)
tue = timestamp(2026, 10, 27)
fri = timestamp(2026, 10, 30)
sat = timestamp(2026, 10, 31)
sun = timestamp(2026, 11, 1)
next_mon = timestamp(2026, 11, 2)

# --- date_range ----------------------------------------------------------------
week = date_range(mon, next_mon)
check("a week of days: 7 timestamps", numel(week) == 7);
check("starts at start", week[0, 0] == mon);
check("stop is not included", week[0, 6] == sun);
check("every 36 hours", date_range(mon, fri, hours(36)) == [mon, mon + hours(36), mon + hours(72)]);
check("counting down", date_range(fri, mon, days(-2)) == [fri, fri - days(2)]);
check("stop before start gives []", numel(date_range(fri, mon)) == 0);

# --- is_busday --------------------------------------------------------------------
check("Monday-Friday are business days", is_busday(week) == [true, true, true, true, true, false, false]);
check("Saturday is not", is_busday(sat) == false);
check("a holiday is not", is_busday(fri, holidays=["2026-10-30"]) == false);
check("holidays as timestamps", is_busday(tue, holidays=[tue, fri]) == false);
check("Sunday-Thursday week: Sunday works", is_busday(sun, weekmask="Sun Mon Tue Wed Thu"));
check("Sunday-Thursday week: Friday is off", is_busday(fri, weekmask="1111001") == false);
check("six-day week", is_busday(sat, weekmask="1111110"));
# 23:00 UTC on Friday is already Saturday morning in Tokyo:
late = timestamp(2026, 10, 30, 23, 0, 0, "UTC")
check("the zone decides the day: Friday in UTC", is_busday(late, zone="UTC"));
check("... but Saturday in Tokyo", is_busday(late, zone="Asia/Tokyo") == false);

# --- busday_count ------------------------------------------------------------------
check("two weeks have 10 business days", busday_count(mon, timestamp(2026, 11, 9)) == 10);
check("end before begin is negative", busday_count(timestamp(2026, 11, 9), mon) == -10);
check("a holiday is not counted", busday_count(mon, timestamp(2026, 11, 9), holidays=[fri]) == 9);
check("end is not included", busday_count(mon, fri) == 4);
check("same day counts 0", busday_count(mon, mon) == 0);
check("element by element", busday_count(mon, [tue, fri, next_mon]) == [1, 4, 5]);
check("Sunday-Thursday week", busday_count(mon, next_mon, weekmask="Sun Mon Tue Wed Thu") == 5);

# --- busday_offset ----------------------------------------------------------------
check("Friday + 1 business day is Monday", busday_offset(fri, 1) == next_mon);
check("Monday - 1 business day is Friday", busday_offset(mon, -1) == timestamp(2026, 10, 23));
check("several offsets at once", busday_offset(mon, [1, 5, 10]) == [tue, next_mon, timestamp(2026, 11, 9)]);
check("skips a holiday", busday_offset(tue, 1, holidays=["2026-10-28"]) == timestamp(2026, 10, 29));
check("roll forward from Saturday", busday_offset(sat, 0, roll="forward") == next_mon);
check("roll backward from Saturday", busday_offset(sat, 0, roll="backward") == fri);
# Saturday 31 October: forward would leave October, so modifiedfollowing goes back.
check("modifiedfollowing stays in the month", busday_offset(sat, 0, roll="modifiedfollowing") == fri);
check("gives the start of the day", get_time(busday_offset(timestamp(2026, 10, 26, 15, 45, 0), 1)) == [0, 0, 0]);

# --- an everyday example: delivery 3 business days after an order -----------------
order = timestamp(2026, 12, 23, 16, 0, 0)
delivery = busday_offset(order, 3, holidays=["2026-12-25", "2026-12-26"])
check("order 23 Dec + 3 business days (25 Dec off) = 29 Dec", get_date(delivery) == [2026, 12, 29]);
