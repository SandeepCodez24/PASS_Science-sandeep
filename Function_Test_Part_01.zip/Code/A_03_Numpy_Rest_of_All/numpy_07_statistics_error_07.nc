# Expected: histogram: bin edges must increase from left to right
A = [1, 2, 3; 4, 5, 6];
x = histogram([1, 2], bins=[0, 5, 3])
