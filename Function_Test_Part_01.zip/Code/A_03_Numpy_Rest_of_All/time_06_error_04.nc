# Expected: time error: the weekmask has no business days
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = is_busday(mon, weekmask="0000000")
