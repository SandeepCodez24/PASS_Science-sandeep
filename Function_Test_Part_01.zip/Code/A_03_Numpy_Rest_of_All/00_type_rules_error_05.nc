# Expected error: negation of text
x = -"5"
