# Expected: time error: cannot combine timestamp and number - use seconds(5), minutes(5), hours(5) or days(5)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = t1 + 5
