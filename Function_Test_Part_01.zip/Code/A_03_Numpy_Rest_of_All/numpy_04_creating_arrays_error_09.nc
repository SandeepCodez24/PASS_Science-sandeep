# Expected: rand_mvnormal: cov must be positive semi-definite
A = [1, 2; 3, 4];
x = rand_mvnormal([0, 0], [1, 2; 2, 1])
