# Date and time - phase 4: measuring elapsed time (the stopwatch)
#
#   tic()     starts the stopwatch (again from zero if it was running)
#             and gives back the date and time it started, as a timestamp
#   toc()     the time since the last tic(), as a duration - the stopwatch
#             keeps running, so toc() can be read as often as you like
#
# There is ONE stopwatch for the whole session. It runs on the computer's
# monotonic clock, which never jumps: setting the clock, a time-server sync,
# daylight saving or a change of time zone cannot disturb a measurement, so
# it works the same in every country. toc() before any tic() is an error
# (time_04_error_01.nc).
#
# toc() is an ordinary duration: in_seconds(toc()), format_duration(toc()),
# toc() > seconds(2), laps ,= toc() ... all work.
#
# Elapsed times differ from run to run, so the checks below only test what
# is always true: the type, the order of readings, and plausible sizes.
# Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

# Some work to measure.
function s = busy(n):
   s = 0;
   for i = [1:n]:
      s = s + i;
   fend
fnend

# --- tic() / toc() --------------------------------------------------------
started = tic();
check("tic() gives the start as a timestamp", started <= get_timestamp());
e1 = toc();
check("toc() is a duration (in_seconds works)", in_seconds(e1) >= 0);
check("toc() is never negative", e1 >= seconds(0));

busy(20000);
e2 = toc();
check("the stopwatch keeps running", e2 >= e1);
check("a reading is plausible (under a minute)", e2 < minutes(1));
check("toc() formats like any duration", format_duration(e2) != "");

# --- tic() again starts from zero -------------------------------------------
busy(20000);
before = toc();
tic();
after = toc();
check("tic() restarts the stopwatch", after <= before);

# --- lap times ------------------------------------------------------------
tic();
laps = []
for k = [1:10]:
   busy(5000);
   laps ,= toc();
fend
check("three laps recorded", numel(laps) == 3);
check("laps grow", laps[0, 0] <= laps[0, 1] && laps[0, 1] <= laps[0, 2]);
check("laps as seconds", in_seconds(laps)[0, 2] >= in_seconds(laps)[0, 0]);
