# Expected: time error: cannot concatenate timestamp with duration
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = [t1, minutes(5)]
