# Expected: pad: mode must be "constant", "edge", "reflect", "symmetric" or "wrap"
A = [1, 2; 3, 4];
x = pad(A, 1, mode="mirror")
