# Date and time - phase 3: parts of a timestamp, text, and converting durations
#
# Parts (a time zone name at the end is optional - the computer's zone otherwise)
#   get_date(t[, zone])              [year, month, day]
#   get_time(t[, zone])              [hour, minute, second]   (second keeps its fraction)
#   set_date(t, y, mo, d[, zone])    a NEW timestamp: same time of day, new date
#   set_time(t, h, m, s[, zone])     a NEW timestamp: same date, new time of day
#   today([zone])                    the start (00:00:00) of today
#   A single t gives one row (1x3); a matrix of N timestamps gives N rows
#   (N x 3), taken row by row. set_date / set_time never change t itself,
#   and nothing in NC changes the computer's clock.
#
# Text
#   format_time(t[, pattern[, zone]])   default pattern "YYYY-MM-DD hh:mm:ss"
#       YYYY year  MM month  DD day  hh hour (00-23)  mm minute  ss second
#       fff milliseconds - any other character is copied as it is
#   format_duration(d)                  "01:30:15", "-01:30:00", "123:00:00", "00:00:01.250"
#
# Converting a duration to numbers (element by element, shape kept)
#   in_seconds(d)  in_minutes(d)  in_hours(d)  in_days(d)
#   in_hms(d)  (same as in_hrs_min_sec(d))   [h, m, s]
#       h and m whole, s keeps its fraction, hours not wrapped at 24, and all
#       three parts carry the sign of d:  in_hms(-minutes(90)) is [-1, -30, 0]
#       h*3600 + m*60 + s == in_seconds(d)
#
# Every check uses UTC (or builds and reads in the same zone), so the file
# gives the same result on any computer. Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC")
t2 = timestamp(2026, 10, 28, 16, 0, 15, "UTC")
d = t2 - t1

# --- reading parts ------------------------------------------------------------
check("get_date in UTC", get_date(t1, "UTC") == [2026, 10, 28]);
check("get_time in UTC", get_time(t1, "UTC") == [14, 30, 0]);
check("get_time in another zone", get_time(t1, "Asia/Kolkata") == [20, 0, 0]);
check("get_date crosses midnight in Tokyo", get_date(timestamp(2026, 10, 28, 20, 0, 0, "UTC"), "Asia/Tokyo") == [2026, 10, 29]);
check("seconds keep their fraction", get_time(timestamp(2026, 1, 1, 8, 15, 30.5, "UTC"), "UTC") == [8, 15, 30.5]);
check("local zone: what you build is what you read", get_time(timestamp(2026, 5, 1, 9, 45, 0)) == [9, 45, 0]);

# --- a matrix of timestamps gives one row per element ----------------------------
T = [t1; t2]
check("get_time of 2 timestamps is 2x3", get_time(T, "UTC") == [14, 30, 0; 16, 0, 15]);
check("get_date of 2 timestamps is 2x3", get_date(T, "UTC") == [2026, 10, 28; 2026, 10, 28]);

# --- set_time / set_date give NEW values ----------------------------------------
t3 = set_time(t1, 9, 0, 0, "UTC")
check("set_time changes the time of day", get_time(t3, "UTC") == [9, 0, 0]);
check("set_time keeps the date", get_date(t3, "UTC") == [2026, 10, 28]);
check("t1 itself is unchanged", get_time(t1, "UTC") == [14, 30, 0]);
t4 = set_date(t1, 2024, 2, 29, "UTC")
check("set_date to a leap day", get_date(t4, "UTC") == [2024, 2, 29]);
check("set_date keeps the time of day", get_time(t4, "UTC") == [14, 30, 0]);
check("set_time on a matrix", get_time(set_time(T, 8, 0, 0, "UTC"), "UTC") == [8, 0, 0; 8, 0, 0]);

# --- today ------------------------------------------------------------------------
check("today() starts at 00:00:00 (UTC)", get_time(today("UTC"), "UTC") == [0, 0, 0]);
check("today() is not in the future", today("UTC") <= get_timestamp());
check("today() is less than a day ago", get_timestamp() - today("UTC") < days(1));

# --- text -------------------------------------------------------------------------
check("format_time default pattern", format_time(t1, "YYYY-MM-DD hh:mm:ss", "UTC") == "2026-10-28 14:30:00");
check("format_time day.month.year", format_time(t1, "DD.MM.YYYY", "UTC") == "28.10.2026");
check("format_time with milliseconds", format_time(t1 + seconds(0.25), "hh:mm:ss.fff", "UTC") == "14:30:00.250");
check("format_time other characters copied", format_time(t1, "YYYY/MM/DD at hh h", "UTC") == "2026/10/28 at 14 h");
check("format_time on a matrix gives text per element", format_time(T, "hh:mm", "UTC") == ["14:30"; "16:00"]);
check("format_duration", format_duration(d) == "01:30:15");
check("format_duration negative", format_duration(-minutes(90)) == "-01:30:00");
check("format_duration past 99 hours", format_duration(hours(123)) == "123:00:00");
check("format_duration with fraction", format_duration(seconds(1.25)) == "00:00:01.250");

# --- converting durations -----------------------------------------------------------
check("in_seconds", in_seconds(d) == 5415);
check("in_minutes", in_minutes(d) == 90.25);
check("in_hours", abs(in_hours(d) - 1.5041666666666667) < 1e-12);
check("in_days", abs(in_days(d) - 0.0626736111111111) < 1e-12);
check("in_hms", in_hms(d) == [1, 30, 15]);
check("in_hrs_min_sec is the same", in_hrs_min_sec(d) == [1, 30, 15]);
check("in_hms negative: every part signed", in_hms(t1 - t2) == [-1, -30, -15]);
check("in_hms(-minutes(90))", in_hms(-minutes(90)) == [-1, -30, 0]);
check("in_hms hours not wrapped", in_hms(hours(30)) == [30, 0, 0]);
check("in_hms keeps fractions", in_hms(seconds(1.25)) == [0, 0, 1.25]);
h = in_hms(d)
check("h*3600 + m*60 + s == in_seconds", h[0, 0] * 3600 + h[0, 1] * 60 + h[0, 2] == in_seconds(d));

# --- matrices of durations ------------------------------------------------------------
D = T - t1
check("in_minutes keeps the shape", in_minutes(D) == [0; 90.25]);
check("in_hms of 2 durations is 2x3", in_hms(D) == [0, 0, 0; 1, 30, 15]);
check("in_seconds of a 2x2", in_seconds(minutes([1, 2; 3, 4])) == [60, 120; 180, 240]);

# --- the numbers can be extended like any matrix ------------------------------------
laps = []
laps ,= in_seconds(d)
laps ,= in_seconds(d * 2)
check("lap times as numbers", laps == [5415, 10830]);
