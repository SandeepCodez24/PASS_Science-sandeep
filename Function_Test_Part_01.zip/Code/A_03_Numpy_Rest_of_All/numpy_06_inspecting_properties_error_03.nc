# Expected: can_cast: casting must be "no", "equiv", "safe", "same_kind" or "unsafe"
x = can_cast("int8", "int16", casting="maybe")
