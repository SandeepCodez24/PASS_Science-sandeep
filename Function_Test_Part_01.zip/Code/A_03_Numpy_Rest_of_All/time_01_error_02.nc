# Expected: time error: invalid day 29 for 2026-02 (2026 is not a leap year)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = timestamp(2026, 2, 29, "UTC")
