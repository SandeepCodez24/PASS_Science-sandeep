# Date and time - phase 5: saving and loading timestamps and durations (.ndat)
#
# save_workspace(path) writes every variable to a .ndat file; load_workspace(path)
# reads them back. Since .ndat 1.2 a timestamp and a duration are stored with
# their own type tags (0x60 / 0x61) as exact int64 nanoseconds - a timestamp
# always in UTC - so they come back exactly, to the nanosecond, with their
# type, on any computer in any time zone. The IDE's session autosave uses the
# same format.
#
# This script writes time_05_roundtrip.ndat next to itself (overwritten on
# every run). Every check prints PASS or FAIL.

t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
d = minutes(90) + seconds(15.123456789);
T = [t1; t1 + hours(1)];
D = minutes([1, -2; 3, 4]);
far = timestamp(1700, 1, 1, "UTC");
mixed = [1, 2, 3];
save_workspace("time_05_roundtrip.ndat");

clear
load_workspace("time_05_roundtrip.ndat");

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

check("timestamp comes back", t1 == timestamp(2026, 10, 28, 14, 30, 0, "UTC"));
check("duration comes back to the nanosecond", d == minutes(90) + seconds(15.123456789));
check("duration keeps its type", in_seconds(d) > 5415);
check("timestamp matrix comes back", T == [t1; t1 + hours(1)]);
check("duration matrix (with a negative) comes back", D == minutes([1, -2; 3, 4]));
check("a date far from 1970 comes back", get_date(far, "UTC") == [1700, 1, 1]);
check("numbers still come back", mixed == [1, 2, 3]);
