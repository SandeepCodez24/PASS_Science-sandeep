# Expected: time error: format_time expects a timestamp, got duration
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = format_time(minutes(1))
