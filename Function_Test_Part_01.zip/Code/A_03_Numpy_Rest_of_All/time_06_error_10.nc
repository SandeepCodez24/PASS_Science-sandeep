# Expected: time error: holidays must be timestamps or dates as text
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = is_busday(mon, holidays=[1, 2])
