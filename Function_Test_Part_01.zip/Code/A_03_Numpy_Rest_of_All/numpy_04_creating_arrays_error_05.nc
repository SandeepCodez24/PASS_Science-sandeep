# Expected: rand_binomial: p must be a probability between 0 and 1
A = [1, 2; 3, 4];
x = rand_binomial(10, 1.5)
