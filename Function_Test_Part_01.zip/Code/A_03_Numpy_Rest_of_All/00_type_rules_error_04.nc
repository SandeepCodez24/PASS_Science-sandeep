# Expected error: only '+' joins text
x = "a" - "b"
