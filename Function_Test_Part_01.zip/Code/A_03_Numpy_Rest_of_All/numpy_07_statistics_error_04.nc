# Expected: nan_argmin: every element is NaN - there is no smallest or largest one
A = [1, 2, 3; 4, 5, 6];
x = nan_argmin([nan, nan])
