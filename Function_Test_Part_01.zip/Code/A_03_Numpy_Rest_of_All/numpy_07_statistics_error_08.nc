# Expected: bincount: x must hold whole numbers >= 0
A = [1, 2, 3; 4, 5, 6];
x = bincount([1, -1])
