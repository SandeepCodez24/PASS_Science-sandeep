# Expected: syntax error inside a call
y = max([1, 2] ,= 3)
