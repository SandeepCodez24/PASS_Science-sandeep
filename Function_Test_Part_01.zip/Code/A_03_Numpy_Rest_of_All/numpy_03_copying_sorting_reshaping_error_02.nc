# Expected: sort_complex: it works on numbers
M = [3, 1, 2; 9, 7, 8];
x = sort_complex(["a", "b"])
