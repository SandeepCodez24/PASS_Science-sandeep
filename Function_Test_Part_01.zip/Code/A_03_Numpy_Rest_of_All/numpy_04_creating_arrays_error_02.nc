# Expected: check_finite: the element at flat position 1 is infinite
A = [1, 2; 3, 4];
x = check_finite([1; inf])
