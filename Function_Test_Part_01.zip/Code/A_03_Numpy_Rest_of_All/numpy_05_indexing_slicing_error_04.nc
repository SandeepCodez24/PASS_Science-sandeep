# Expected: where: give both x and y
A = [10, 20, 30; 40, 50, 60];
x = where(A > 25, A)
