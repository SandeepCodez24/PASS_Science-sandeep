# Expected: concat: axis 2 does not exist for a 2-D input - use 0 to 1 (or -1 to -2)
A = [1, 2; 3, 4]; C = [1, 2, 3; 4, 5, 6];
x = concat(A, A, axis=2)
