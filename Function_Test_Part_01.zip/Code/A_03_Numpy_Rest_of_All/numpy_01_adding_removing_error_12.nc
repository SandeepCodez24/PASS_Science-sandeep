# Expected: nan_to_num: it works on numbers, not text or time values
A = [1, 2; 3, 4];
x = nan_to_num(["a"])
