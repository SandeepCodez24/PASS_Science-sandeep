# Date and time - phase 1: the two types and how they print
#
#   timestamp   a point in time     2026-10-28 14:30:00
#   duration    a length of time    01:30:15
#
# Every timestamp is stored in UTC (nanoseconds since 1970-01-01 00:00:00 UTC)
# and prints in the computer's local time. A time zone can be named wherever
# a timestamp is built from parts or text: "UTC", "Asia/Kolkata",
# "Europe/Berlin", "America/New_York", ... (the IANA names).
#
# Functions in this phase
#   get_timestamp()                          now
#   timestamp(y, mo, d)                      midnight of that date, local time
#   timestamp(y, mo, d, h, mi, s)            s may have a fraction
#   timestamp(..., zone)                     the same in a named zone
#   to_timestamp(text) / to_timestamp(text, zone)
#       ISO 8601: "2026-10-28", "2026-10-28 14:30:00", "2026-10-28T14:30:00",
#       optional ".250" fraction, optional "Z" or "+05:30" (an offset in the
#       text wins over the zone)
#   seconds(n)  minutes(n)  hours(n)  days(n)    durations (days = 24 h)
#
# Every function works element by element on a matrix and keeps its shape.
# The local-time checks below build and print in the same zone, and the UTC
# ones compare two UTC timestamps, so the file gives the same result on any
# computer. Every check prints PASS or FAIL.

function check(label, got, want):
   if got == want:
      print("PASS  " + label)
   else:
      print("FAIL  " + label + "  (got " + got + ")")
   iend
fnend

# --- building timestamps ---------------------------------------------------
t1 = timestamp(2026, 10, 28, 14, 30, 0)
check("timestamp from parts", str(t1), "2026-10-28 14:30:00");
check("date only is midnight", str(timestamp(2026, 10, 28)), "2026-10-28 00:00:00");
check("leap day 2024-02-29", str(timestamp(2024, 2, 29)), "2024-02-29 00:00:00");
check("fractional seconds", str(timestamp(2026, 10, 28, 14, 30, 1.25)), "2026-10-28 14:30:01.250");

# --- parsing ISO 8601 text -------------------------------------------------
check("to_timestamp date and time", str(to_timestamp("2026-10-28 14:30:00")), "2026-10-28 14:30:00");
check("to_timestamp with T", str(to_timestamp("2026-10-28T14:30:00")), "2026-10-28 14:30:00");
check("to_timestamp date only", str(to_timestamp("2026-10-28")), "2026-10-28 00:00:00");
check("to_timestamp fraction", str(to_timestamp("2026-10-28 14:30:00.25")), "2026-10-28 14:30:00.250");

# --- time zones: the same instant written three ways ------------------------
u = timestamp(2026, 10, 28, 14, 30, 0, "UTC")
check("Z means UTC", str(to_timestamp("2026-10-28T14:30:00Z")), str(u));
check("+05:30 offset", str(to_timestamp("2026-10-28 20:00:00+05:30")), str(u));
check("named zone Asia/Kolkata", str(timestamp(2026, 10, 28, 20, 0, 0, "Asia/Kolkata")), str(u));
check("text zone argument", str(to_timestamp("2026-10-28 14:30:00", "UTC")), str(u));
check("offset in text wins over zone", str(to_timestamp("2026-10-28T14:30:00Z", "Asia/Tokyo")), str(u));

# --- daylight saving: an ambiguous local time is the EARLIER instant -------
# Berlin, 2026-10-25: clocks go back from 03:00 to 02:00, so 02:30 happens
# twice. The first one is 00:30 UTC.
amb = timestamp(2026, 10, 25, 2, 30, 0, "Europe/Berlin")
check("DST overlap -> earlier instant", str(amb), str(timestamp(2026, 10, 25, 0, 30, 0, "UTC")));

# --- durations ---------------------------------------------------------------
check("seconds(1.25)", str(seconds(1.25)), "00:00:01.250");
check("minutes(90)", str(minutes(90)), "01:30:00");
check("hours are not wrapped at 24", str(hours(30)), "30:00:00");
check("hours may grow past 2 digits", str(hours(123)), "123:00:00");
check("days(1) is 24 hours", str(days(1)), "24:00:00");
check("negative duration", str(minutes(-90)), "-01:30:00");
check("days(-1.5)", str(days(-1.5)), "-36:00:00");
check("abs of a duration", str(abs(minutes(-5))), "00:05:00");

# --- matrices: element by element, shape kept -------------------------------
D = minutes([1, 2; 3, 4])
check("minutes(matrix) is 2x2", str(size(D)), str([2, 2]));
check("minutes(matrix) element", str(D[1, 1]), "00:04:00");
T = [t1; timestamp(2026, 10, 28, 16, 0, 15)]
check("timestamp column is 2x1", str(size(T)), str([2, 1]));
check("timestamp column element", str(T[1, 0]), "2026-10-28 16:00:15");
Y = timestamp([2024, 2025, 2026], 1, 1)
check("parts as vectors broadcast", str(Y[0, 2]), "2026-01-01 00:00:00");
P = to_timestamp(["2026-01-01", "2026-06-30 12:00:00"])
check("to_timestamp on a text matrix", str(P[0, 1]), "2026-06-30 12:00:00");
L = []
L ,= t1
L ,= t1
check("extend with ,= keeps timestamps", str(size(L)), str([1, 2]));

# --- the clock ---------------------------------------------------------------
now = get_timestamp();
check("get_timestamp gives one timestamp", str(size(now)), str([1, 1]));
