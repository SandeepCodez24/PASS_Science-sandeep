# Expected error: '*' is not defined for text
x = "5" * 2
