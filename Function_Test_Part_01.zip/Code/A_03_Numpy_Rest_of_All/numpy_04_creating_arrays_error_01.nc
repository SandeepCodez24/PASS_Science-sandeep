# Expected: check_finite: the element at flat position 1 is NaN - only finite numbers are allowed
A = [1, 2; 3, 4];
x = check_finite([1, nan, 3])
