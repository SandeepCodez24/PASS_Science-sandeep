# Expected: gradient: a gradient needs at least 2 points along axis 1
A = [1, 2, 3; 4, 5, 6];
x = gradient([5])
