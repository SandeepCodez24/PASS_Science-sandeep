# Expected: rand_triangular: needs left <= mode <= right with left < right
A = [1, 2; 3, 4];
x = rand_triangular(2, 1, 3)
