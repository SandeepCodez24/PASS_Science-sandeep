# Expected error: text and number cannot be ordered
x = "5" < 5
