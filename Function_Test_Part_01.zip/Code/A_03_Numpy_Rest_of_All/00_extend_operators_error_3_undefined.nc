# Expected: extend error (,=): variable 'U' is not defined
U ,= 1
