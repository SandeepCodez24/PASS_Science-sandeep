# NumPy section 4 - Creating Arrays
#
#   check_finite(A)               A itself - or an error if A holds NaN or Inf
#   zeros_like(A) / ones_like(A)  zeros / ones with A's shape and element type
#   vander(x, N=0, increasing=false)
#                                 Vandermonde matrix: columns x^(N-1), ..., x^1, x^0
#                                 (N=0: one column per element of x)
#   [X, Y] = meshgrid(x, y, indexing="xy")
#                                 coordinate grids: X repeats x down the rows,
#                                 Y repeats y across the columns ("ij": the other way)
#   [R, C] = indices([r, c])      R[i, j] = i and C[i, j] = j
#
# Random numbers - one engine for everything: nexus_seed(n) first makes every
# result below repeatable (the same numbers on every run).
#   rand_choice(a, size=1, replace=true, p?)
#                                 random elements of a (a whole number a: of 0..a-1);
#                                 replace=false: each element at most once;
#                                 p: one probability per element
#   shuffle(A[, axis])            a shuffled copy - a vector along its length,
#                                 a matrix by whole rows (axis=1: by columns)
#   permutation(x)                0..x-1 in random order (or a shuffled copy of x)
#   rand_binomial(n, p, size=1)        successes in n trials of probability p
#   rand_poisson(lam, size=1)          counts with mean lam
#   rand_exponential(scale=1, size=1)  waiting times with mean scale
#   rand_beta(a, b, size=1)            numbers in [0, 1], mean a/(a+b)
#   rand_gamma(shape, scale=1, size=1) mean shape*scale
#   rand_lognormal(mean=0, sigma=1, size=1)   exp of a normal number
#   rand_chisquare(df, size=1)         mean df
#   rand_triangular(left, mode, right, size=1)
#   rand_geometric(p, size=1)          trials until the first success: 1, 2, 3, ...
#   rand_multinomial(n, pvals, size=1) counts per category, one row per draw
#   rand_mvnormal(mean, cov, size=1)   points of a multivariate normal, one row each
#
# size: 1 (the default) gives one value, n a 1xn row, [r, c] an r x c matrix.
#
# Random results cannot be compared with fixed numbers, so the checks test
# what is always true: repeatability with a seed, ranges, shapes, and the
# mean of many samples. Every check prints PASS or FAIL.

function check(label, ok):
   if ok:
      print("PASS  " + label)
   else:
      print("FAIL  " + label)
   iend
fnend

# --- zeros_like / ones_like / check_finite ----------------------------------------
check("zeros_like keeps the shape", zeros_like([1, 2; 3, 4]) == [0, 0; 0, 0]);
check("ones_like keeps the shape", ones_like([5, 6, 7]) == [1, 1, 1]);
check("check_finite gives A back", check_finite([1, 2.5; -3, 4]) == [1, 2.5; -3, 4]);

# --- vander ---------------------------------------------------------------------
check("vander, decreasing powers", vander([1, 2, 3]) == [1, 1, 1; 4, 2, 1; 9, 3, 1]);
check("vander, 2 columns, increasing", vander([1, 2, 3], N=2, increasing=true) == [1, 1; 1, 2; 1, 3]);
check("vander, 4 columns", vander([2, 3], N=4) == [8, 4, 2, 1; 27, 9, 3, 1]);

# --- meshgrid / indices ---------------------------------------------------------
[X, Y] = meshgrid([1, 2, 3], [10, 20])
check("meshgrid X", X == [1, 2, 3; 1, 2, 3]);
check("meshgrid Y", Y == [10, 10, 10; 20, 20, 20]);
check("a function on the grid", X + Y == [11, 12, 13; 21, 22, 23]);
[I, J] = meshgrid([1, 2, 3], [10, 20], indexing="ij")
check("meshgrid ij: X down the rows", I == [1, 1; 2, 2; 3, 3]);
check("meshgrid ij: Y across", J == [10, 20; 10, 20; 10, 20]);
[R, C] = indices([2, 3])
check("indices: row numbers", R == [0, 0, 0; 1, 1, 1]);
check("indices: column numbers", C == [0, 1, 2; 0, 1, 2]);

# --- the seed makes random results repeatable -------------------------------------
nexus_seed(7);
first = rand_choice(100, size=10);
nexus_seed(7);
again = rand_choice(100, size=10);
check("same seed, same numbers", first == again);

# --- rand_choice ------------------------------------------------------------------
nexus_seed(1);
c = rand_choice(5, size=1000)
check("choices of 5 are 0..4", min(c) >= 0 && max(c) <= 4);
check("size=[2, 3] gives a 2x3 matrix", shape(rand_choice(5, size=[2, 3])) == [2, 3]);
d = rand_choice([10, 20, 30, 40], size=4, replace=false)
check("replace=false: every element once", sort_asc(d) == [10, 20, 30, 40]);
check("p decides: probability 1", rand_choice([1, 2, 3], size=5, p=[0, 0, 1]) == [3, 3, 3, 3, 3]);
w = rand_choice(["heads", "tails"], size=2000)
check("text elements can be chosen", numel(unique(w)) == 2);

# --- shuffle / permutation --------------------------------------------------------
s = shuffle([1, 2, 3, 4, 5, 6])
check("shuffle keeps every element", sort_asc(s) == [1, 2, 3, 4, 5, 6]);
M = [1, 2; 3, 4; 5, 6]
S = shuffle(M)
check("shuffle a matrix by rows: rows stay whole", unique(S, axis=0) == M);
p = permutation(8)
check("permutation(8) holds 0..7 once each", sort_asc(p) == [0, 1, 2, 3, 4, 5, 6, 7]);

# --- distributions: range and mean of many samples ---------------------------------
nexus_seed(2026);
b = rand_binomial(10, 0.5, size=20000)
check("binomial between 0 and n", min(b) >= 0 && max(b) <= 10);
check("binomial mean n*p = 5", abs(mean(b) - 5) < 0.1);
check("poisson mean lam = 3", abs(mean(rand_poisson(3, size=20000)) - 3) < 0.1);
check("exponential mean scale = 2", abs(mean(rand_exponential(2, size=20000)) - 2) < 0.1);
be = rand_beta(2, 3, size=20000)
check("beta in [0, 1]", min(be) >= 0 && max(be) <= 1);
check("beta mean a/(a+b) = 0.4", abs(mean(be) - 0.4) < 0.02);
check("gamma mean shape*scale = 6", abs(mean(rand_gamma(2, 3, size=20000)) - 6) < 0.2);
check("lognormal is positive", min(rand_lognormal(size=1000)) > 0);
check("chisquare mean df = 4", abs(mean(rand_chisquare(4, size=20000)) - 4) < 0.15);
t = rand_triangular(0, 1, 4, size=20000)
check("triangular within [left, right]", min(t) >= 0 && max(t) <= 4);
check("triangular mean (l+m+r)/3", abs(mean(t) - 5 / 3) < 0.05);
g = rand_geometric(0.25, size=20000)
check("geometric counts trials from 1", min(g) >= 1);
check("geometric mean 1/p = 4", abs(mean(g) - 4) < 0.15);
m = rand_multinomial(10, [0.2, 0.3, 0.5], size=500)
check("multinomial: one row per draw, 3 counts", shape(m) == [500, 3]);
check("multinomial: every row adds up to n", m * ones(3, 1) == 10 * ones(500, 1));
v = rand_mvnormal([0, 10], [1, 0; 0, 0], size=200)
check("mvnormal: one row per point", shape(v) == [200, 2]);
check("mvnormal: zero variance keeps the mean exactly", v[:, 1] == 10 * ones(200, 1));
check("one value by default", shape(rand_poisson(5)) == [1, 1]);
