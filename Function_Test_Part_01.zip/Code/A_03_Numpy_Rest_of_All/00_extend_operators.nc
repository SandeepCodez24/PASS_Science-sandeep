# Extend operators ,=  and  ;=
#
#   M ,= X   appends X to the RIGHT of M (adds columns)   same as  M = [M, X]
#   M ;= X   appends X BELOW M          (adds rows)       same as  M = [M; X]
#
# Rules
#   - X is worked out first, then M is read, so  M ,= M  doubles M.
#   - [] on either side:  M ,= []  leaves M unchanged,  [] ,= X  gives X.
#   - A single value is repeated along M:  M ,= 0  adds a column of zeros,
#     M ;= 9  adds a row of nines.
#   - Shapes are never transposed to fit - a mismatch is an error
#     (see the 00_extend_operators_error_*.nc files).
#   - M must exist first - start an empty one with  M = [].
#   - Only a plain variable name may stand on the left.
#
# Every check prints PASS or FAIL.

function check(label, got, want):
   if shape(got) == shape(want):
      if got == want:
         print("PASS  " + label)
      else:
         print("FAIL  " + label + "  (values differ)")
      iend
   else:
      print("FAIL  " + label + "  (shapes differ)")
   iend
fnend

# --- columns -------------------------------------------------------------
M = [1, 2; 3, 4]
M ,= [5; 6]
check("M ,= column", M, [1, 2, 5; 3, 4, 6]);
M ,= [7, 8; 9, 10]
check("M ,= 2x2 block", M, [1, 2, 5, 7, 8; 3, 4, 6, 9, 10]);

# --- rows ----------------------------------------------------------------
A = [1, 2, 3; 4, 5, 6]
A ;= [7, 8, 9]
check("A ;= row", A, [1, 2, 3; 4, 5, 6; 7, 8, 9]);
A ;= [0, 0, 0; 1, 1, 1]
check("A ;= 2x3 block", A, [1, 2, 3; 4, 5, 6; 7, 8, 9; 0, 0, 0; 1, 1, 1]);

# --- building a matrix in a loop ----------------------------------------
R = []
for i = [1:3]:
   R ;= [i, i^2, i^3];
fend
check("loop build", R, [1, 1, 1; 2, 4, 8; 3, 9, 27]);

# --- vectors (same rule, no special case) --------------------------------
v = [1, 2, 3]
v ,= 4
check("row vector ,= scalar", v, [1, 2, 3, 4]);
v ,= [5, 6]
check("row vector ,= row", v, [1, 2, 3, 4, 5, 6]);
c = [1; 2]
c ;= 3
check("column vector ;= scalar", c, [1; 2; 3]);
w = [1, 2]
w ;= [3, 4]
check("row vector ;= row adds a row", w, [1, 2; 3, 4]);

# --- scalars and empties -------------------------------------------------
s = 5
s ,= 6
check("scalar ,= scalar", s, [5, 6]);
Z = [1, 2; 3, 4]
Z ,= 0
check("scalar broadcast as column", Z, [1, 2, 0; 3, 4, 0]);
Z ;= 9
check("scalar broadcast as row", Z, [1, 2, 0; 3, 4, 0; 9, 9, 9]);
E = []
E ,= 7
check("[] ,= scalar", E, [7]);
F = [1, 2]
F ,= []
check("M ,= [] is a no-op", F, [1, 2]);
G = []
G ,= []
check("[] ,= []", G, []);
K = []
K ;= [1, 2; 3, 4]
check("[] ;= matrix", K, [1, 2; 3, 4]);

# --- self-extend (value worked out before M is read) ---------------------
H = [1; 2]
H ,= H
check("H ,= H", H, [1, 1; 2, 2]);

# --- value semantics: other variables are not touched --------------------
P = [1, 2]
Q = P
P ,= 3
check("P extended", P, [1, 2, 3]);
check("Q unchanged", Q, [1, 2]);

# --- type promotion: same result as the literal [T, 2.5] -----------------
T = [1, 2]
T ,= 2.5
check("float promotion", T, [1, 2, 2.5]);
B = [true, false]
B ,= 3
check("bool + number like [B, 3]", B, [true, false, 3]);

# --- inside a function (local variables) ---------------------------------
function R = squares_table(n):
   R = [];
   for i = [1:n]:
      R ;= [i, i^2];
   fend
fnend
check("inside a function", squares_table(3), [1, 1; 2, 4; 3, 9]);

# --- matrix-literal and other syntax unchanged (regression) --------------
L = [1, 2; 3, 4]
check("literal still works", L, [1, 2; 3, 4]);
x = 5;
check("statement-ending ';' still works", x, 5);
check("call arguments still work", max(3, 7), 7);
