# Expected: replace_if: mask must have the same size as A
A = [1, 2; 3, 4];
x = replace_if(A, [true, false], 0)
