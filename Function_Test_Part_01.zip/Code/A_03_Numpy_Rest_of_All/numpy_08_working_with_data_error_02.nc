# Expected: is_posinf: it works on real numbers - a complex number has no sign of infinity
x = is_posinf(1 + 2i)
