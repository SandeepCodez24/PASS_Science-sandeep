# Expected: time error: matrix multiplication is not defined for duration - use *. for element by element
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = D * D
