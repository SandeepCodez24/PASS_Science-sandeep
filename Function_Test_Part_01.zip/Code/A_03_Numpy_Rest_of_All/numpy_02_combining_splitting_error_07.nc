# Expected: concat: there is no input named 'axs'
A = [1, 2; 3, 4]; C = [1, 2, 3; 4, 5, 6];
x = concat(A, A, axs=1)
