# Expected: meshgrid: indexing must be "xy" ... or "ij"
A = [1, 2; 3, 4];
x = meshgrid([1, 2], [3, 4], indexing="xyz")
