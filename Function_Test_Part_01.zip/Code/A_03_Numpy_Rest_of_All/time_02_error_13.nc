# Expected: time error: cannot subtract a timestamp from a duration - did you mean t - d?
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC"); t2 = t1 + hours(1); D = minutes([1, 2; 3, 4]);
x = minutes(1) - t1
