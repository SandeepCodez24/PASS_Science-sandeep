# Expected: time error: is_real_each expects a number, got timestamp
x = is_real_each(timestamp(2026, 1, 1, "UTC"))
