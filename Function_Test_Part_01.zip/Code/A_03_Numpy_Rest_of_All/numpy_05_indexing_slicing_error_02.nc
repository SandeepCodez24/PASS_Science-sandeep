# Expected: take: position 3 is outside axis 1 (0..2)
A = [10, 20, 30; 40, 50, 60];
x = take(A, [0, 3], axis=1)
