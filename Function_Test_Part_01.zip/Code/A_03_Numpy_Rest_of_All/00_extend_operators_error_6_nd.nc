# Expected: extend error (,=): only 2-D matrices are supported, got 2x2x2
B = [1,2;3,4 ;; 5,6;7,8]
B ,= 1
