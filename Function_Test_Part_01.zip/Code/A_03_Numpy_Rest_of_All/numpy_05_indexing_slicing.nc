# NumPy section 5 - Indexing & Slicing
#
#   take(A, indices[, axis])         the elements at flat positions (row by row from 0);
#                                    with axis: whole rows (axis=0) / columns (axis=1)
#   where(cond, x, y)                element by element: x where cond is true, else y
#   where(cond)                      the positions where cond is true (same as nonzero)
#   [r, c] = nonzero(A)              row and column of every non-zero element
#   choose(idx, c0, c1, ...)         element k taken from choice number idx[k]
#   compress(cond, A[, axis])        the elements (or rows / columns) where cond is true
#   extract(cond, A)                 the elements of A where cond is true, as one row
#   [r, c] = diag_indices(n)         positions of the main diagonal of an n x n matrix
#   [r, c] = tril_indices(n, k=0, m?)   positions of the lower triangle
#   [r, c] = triu_indices(n, k=0, m?)   positions of the upper triangle
#                                    (k shifts the diagonal: k=1 above it, k=-1 below;
#                                     m: number of columns, n when left out)
#   [r, c] = mask_indices(n, mask="triu", k=0)    the same for mask "triu" / "tril"
#   ravel_index(index, dims)         flat positions of multi-indices: index has one row
#                                    per axis ([rows; cols]), or is one point [r, c]
#
# Positions are 0-based; a negative position counts from the end. Functions
# that give positions per axis return one row of indices per axis; one name
# receives them all as a list (P = nonzero(A), then P[0], P[1]).
#
#     A = [10, 20, 30;      take(A, [0, 4]) = [10, 50]   (flat positions 0 and 4)
#          40, 50, 60]      [r, c] = nonzero(A > 35)  ->  r = [1, 1, 1], c = [0, 1, 2]
#
# The error cases are in numpy_05_indexing_slicing_error_*.nc.
# Every check prints PASS or FAIL.

function check(label, got, want):
    if shape(got) == shape(want):
        if got == want:
            print("PASS  " + label)
        else:
            print("FAIL  " + label + "  (values differ)")
        iend
    else:
        print("FAIL  " + label + "  (shapes differ)")
    iend
fnend

A = [10, 20, 30; 40, 50, 60]

# --- take -----------------------------------------------------------------------
check("take flat positions", take(A, [0, 4]), [10, 50]);
check("the result has the shape of indices", take(A, [0, 4; 5, 1]), [10, 50; 60, 20]);
check("one position gives one value", take(A, 1), 20);
check("a negative position counts from the end", take(A, -1), 60);
check("take columns (axis=1)", take(A, [2, 0], axis=1), [30, 10; 60, 40]);
check("take rows (axis=0)", take(A, [1, 1], axis=0), [40, 50, 60; 40, 50, 60]);

# --- where / nonzero ------------------------------------------------------------
check("where with a condition", where(A > 25, A, 0), [0, 0, 30; 40, 50, 60]);
check("where with single values", where([true, false, true], 1, -1), [1, -1, 1]);
check("where can pick text", where([true, false], "yes", "no"), ["yes", "no"]);
check("where with two matrices", where(A > 25, A, -A), [-10, -20, 30; 40, 50, 60]);
[r, c] = where(A > 35)
check("where(cond): rows", r, [1, 1, 1]);
check("where(cond): columns", c, [0, 1, 2]);
[r2, c2] = nonzero([0, 1; 2, 0])
check("nonzero rows", r2, [0, 1]);
check("nonzero columns", c2, [1, 0]);
P = nonzero([0, 3, 0, 5])
check("one name gets a list: P[1] is the columns", P[1], [1, 3]);
check("the positions read the elements back", A[r[0, 0], c[0, 0]], 40);

# --- choose / compress / extract ------------------------------------------------
check("choose element by element", choose([0, 1, 2, 1], [1, 2, 3, 4], 0, [10, 20, 30, 40]), [1, 0, 30, 0]);
check("choose: label numbers to names", choose([2, 0, 1], "low", "mid", "high"), ["high", "low", "mid"]);
check("compress elements", compress([true, false, true], [1, 2, 3, 4]), [1, 3]);
check("compress rows", compress([false, true], A, axis=0), [40, 50, 60]);
check("compress columns", compress([1, 0, 1], A, axis=1), [10, 30; 40, 60]);
check("extract where a condition holds", extract(A > 25, A), [30, 40, 50, 60]);
check("extract even numbers", extract([1, 2, 3, 4, 5, 6] % 2 == 0, [1, 2, 3, 4, 5, 6]), [2, 4, 6]);

# --- index sets -----------------------------------------------------------------
[dr, dc] = diag_indices(3)
check("diag_indices rows", dr, [0, 1, 2]);
check("diag_indices columns", dc, [0, 1, 2]);
[lr, lc] = tril_indices(3)
check("tril_indices rows", lr, [0, 1, 1, 2, 2, 2]);
check("tril_indices columns", lc, [0, 0, 1, 0, 1, 2]);
[ur, uc] = triu_indices(3, k=1)
check("triu_indices above the diagonal: rows", ur, [0, 0, 1]);
check("... columns", uc, [1, 2, 2]);
[wr, wc] = triu_indices(2, m=3)
check("triu of a 2x3 matrix", wc, [0, 1, 2, 1, 2]);
[mr, mc] = mask_indices(3, mask="tril", k=-1)
check("mask_indices strictly below the diagonal", mr, [1, 2, 2]);
check("... columns", mc, [0, 0, 1]);

# --- ravel_index ----------------------------------------------------------------
check("two points of a 3x4 matrix", ravel_index([0, 1; 2, 3], [3, 4]), [2, 7]);
check("one point [1, 2] of a 3x4 matrix", ravel_index([1, 2], [3, 4]), 6);
check("ravel_index agrees with take", take(A, ravel_index([1, 2], [2, 3])), A[1, 2]);
