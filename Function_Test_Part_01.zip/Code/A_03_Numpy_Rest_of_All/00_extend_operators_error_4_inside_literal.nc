# Expected: syntax error - ',=' is only allowed as an assignment operator
x = [1, 2]
y = [x ,= 3]
