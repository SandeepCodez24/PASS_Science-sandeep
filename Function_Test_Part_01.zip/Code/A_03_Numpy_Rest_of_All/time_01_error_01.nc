# Expected: time error: invalid month 13 (expected 1-12)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = timestamp(2026, 13, 1, "UTC")
