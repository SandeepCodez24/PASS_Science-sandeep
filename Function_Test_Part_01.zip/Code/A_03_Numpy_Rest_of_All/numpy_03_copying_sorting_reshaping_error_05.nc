# Expected: roll: axis -3 does not exist for a 2-D input
M = [3, 1, 2; 9, 7, 8];
x = roll(M, 1, axis=-3)
