# Expected: prod: it works on real numbers (not complex numbers, text or time values)
A = [1, 2, 3; 4, 5, 6];
x = prod(["a", "b"])
