# Expected: time error: invalid hour 24 (expected 0-23)
t1 = timestamp(2026, 10, 28, 14, 30, 0, "UTC");
x = timestamp(2026, 1, 1, 24, 0, 0)
