# Expected: trim_zeros: it works on a vector (one row or one column), not a 2x2 matrix
A = [1, 2; 3, 4];
x = trim_zeros(A)
