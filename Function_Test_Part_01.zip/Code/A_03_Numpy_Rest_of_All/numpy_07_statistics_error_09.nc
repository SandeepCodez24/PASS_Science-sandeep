# Expected: digitize: bins must be sorted, increasing or decreasing
A = [1, 2, 3; 4, 5, 6];
x = digitize([1], [0, 5, 3])
