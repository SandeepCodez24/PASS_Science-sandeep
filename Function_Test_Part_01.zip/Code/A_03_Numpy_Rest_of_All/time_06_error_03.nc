# Expected: time error: invalid weekmask ('Fry' is not a day)
mon = timestamp(2026, 10, 26); sat = timestamp(2026, 10, 31);
x = is_busday(mon, weekmask="Mon Fry")
