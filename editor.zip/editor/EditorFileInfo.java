package ui.editor;

import java.nio.file.Path;

/**
 * Data class representing information about an open editor file.
 * Stores the file path and its extension for quick identification.
 */
public class EditorFileInfo {
    public Path path;
    public String ext;
    // Compatibility alias used by alternate EditorManager implementations.
    public String defaultExtension;

    // ---- Step-execution session state (ui.editor.step.StepController) ----
    // Lives here, not on a closure-local object like FoldingManager, because
    // this IS the tab's getUserData() payload — reachable from anywhere a
    // Tab is (a ribbon click handler included), which a factory-method-local
    // object is not.
    public boolean stepSessionActive = false;
    public String stepSourceSnapshot = null;
    public java.util.List<ui.editor.step.StepUnit> stepUnits = null;
    public int stepIndex = 0;
    /** Line range (0-indexed, inclusive) of the most recently executed step unit; -1/-1 = none. */
    public int stepCurrentUnitStart = -1;
    public int stepCurrentUnitEnd = -1;
    public boolean stepEndMessageShown = false;

    public EditorFileInfo(Path path, String ext) {
        this.path = path;
        this.ext = ext;
        this.defaultExtension = ext;
    }

    /**
     * Checks if this represents an unsaved file.
     * @return true if the file path is null
     */
    public boolean isUnsaved() {
        return path == null;
    }

    /**
     * Gets the file name from the path.
     * @return file name or empty string if path is null
     */
    public String getFileName() {
        return path != null ? path.getFileName().toString() : "";
    }
}
