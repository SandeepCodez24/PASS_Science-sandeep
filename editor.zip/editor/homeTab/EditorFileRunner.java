package ui.editor.homeTab;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.scene.control.Tab;
import language.language_engine.UPIEngine;
import language.language_engine.VariableFileWriter;
import language.semantic.SemanticEncoder;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;
import ui.editor.EditorUIHelper;
import ui.managers.EditorManager;
import ui.managers.LanguageDesignManager;
import ui.managers.ProjectManager;
import ui.ui_functions.UI_MainProgramControl;

/**
 * Handles execution of files.
 * Supports Python, C, C++, Java, and UPI files with appropriate
 * compilers/interpreters.
 */
public class EditorFileRunner {

    /**
     * Runs the current file.
     * Saves file first, then executes based on file type.
     * 
     * @param ide the IDE controller
     */
    public static void runCurrentFile(UI_Main ide) {

        Tab tab = ide.editorTabs
                .getSelectionModel()
                .getSelectedItem();

        if (tab == null)
            return;

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();

        if (info == null || info.path == null) {

            ide.console.appendText(
                    "Cannot run unsaved file. Please save first.\n");

            return;
        }

        // Run mutates the same shared interpreter workspace a Step session may be
        // mid-way through — invalidate it so the next Step click starts fresh
        // rather than continuing a now-desynced cursor.
        ui.editor.step.StepController.onRunStarted(info);

        // Before saving, check editor-detected errors and abort run if present.
        String editorText = EditorTextOperations.getEditorText(tab);
        var report = ErrorChecker.analyzeErrors(editorText);
        if (report.getErrorCount() > 0) {
            String[] lines = editorText.split("\\R", -1);
            int lastErrorLine = -1;
            String errorKind = null;

            var undefLines = ErrorChecker.findUndefinedVariableErrorLines(editorText);
            for (int ln : undefLines) {
                if (ln >= lastErrorLine) {
                    lastErrorLine = ln;
                    errorKind = "Undefined variable error";
                }
            }

            var syntaxLines = ErrorChecker.findIncompleteLineSyntaxErrorLines(editorText);
            for (int ln : syntaxLines) {
                if (ln >= lastErrorLine) {
                    lastErrorLine = ln;
                    errorKind = "Incomplete syntax error";
                }
            }

            var expLines = ErrorChecker.findInvalidExponentErrorLines(editorText);
            for (int ln : expLines) {
                if (ln >= lastErrorLine) {
                    lastErrorLine = ln;
                    errorKind = "Invalid exponent error";
                }
            }

            var ssLines = ErrorChecker.findSubscriptSuperscriptErrorLines(editorText);
            for (int ln : ssLines) {
                if (ln >= lastErrorLine) {
                    lastErrorLine = ln;
                    errorKind = "Invalid subscript/superscript usage";
                }
            }

            if (lastErrorLine >= 0) {
                String src = lastErrorLine < lines.length ? lines[lastErrorLine] : "";
                UI_MainProgramControl.appendErrorText(ide,
                        "✖ " + errorKind + " at line " + (lastErrorLine + 1) + ": " + src.trim() + "\n");
            } else {
                UI_MainProgramControl.appendErrorText(ide, "✖ Run aborted: editor contains errors.\n");
            }

            UI_MainProgramControl.appendNextPrompt(ide);

            return;
        }

        EditorManager.saveCurrentFile(ide);

        String file = info.path
                .toAbsolutePath()
                .toString();

        // ide.console.appendText(
        // "Running "
        // + info.path.getFileName()
        // + "...\n");

        try {

            /*
             * =====================================================
             * NC FILE
             * =====================================================
             */

            if (file.endsWith(".nc")) {

                // MATLAB-like current folder/workspace
                if (info.path.getParent() != null) {
                    EditorManager.sendCommandToTerminal(
                            ide,
                            "@cmd setpwd \"" + info.path.getParent().toString() + "\"");
                }

                /* Start terminal once */

                if (!ide.isProgramRunning()) {

                    EditorManager.startUPITerminal(ide);

                    try {

                        Thread.sleep(500);

                    } catch (InterruptedException ignored) {
                    }
                }

                // Create cleaned_Runfile.nc first
                Path cleanedFile = LanguageDesignManager.buildSemanticPath(info);

                LanguageDesignManager.writeSemanticFileFromUiCode(
                        EditorTextOperations.getEditorText(tab),
                        cleanedFile);

                // Generate variable files and refresh variable explorer
                String cleaned = LanguageDesignManager.preprocess(editorText);
                Path variablePath = LanguageDesignManager.buildVariablePath(info);
                Path javaDictionaryPath = LanguageDesignManager.buildJavaDictionaryPath(info);
                String javaDictionarySource = LanguageDesignManager.normalizeMarkersForVariables(cleaned);
                VariableFileWriter.writeVariablesFile(cleaned, variablePath);
                VariableFileWriter.writeJavaDictionaryFile(javaDictionarySource, javaDictionaryPath);
                ide.refreshVariablesForOpenTabs(tab);

                // Verify cleaned file was created
                if (!Files.exists(cleanedFile)) {
                    ide.console.appendText("Failed to create cleaned_Runfile.nc\n");
                    return;
                }

                // Refresh project tree to show the newly created cleaned file
                ProjectManager.refreshProjectTree(ide);

                // Run cleaned_Runfile.nc
                EditorManager.sendCommandToTerminal(
                        ide,
                        cleanedFile.toAbsolutePath().toString());

                return;

            }

            else {

                ide.console.appendText(
                        "Unsupported file type.\n");
            }

        } catch (

        Exception e) {

            ide.console.appendText(
                    "Run failed: "
                            + e.getMessage()
                            + "\n");
        }
    }

    public static void integrateDemoCpp(UI_Main ide) {

        Path mainCpp = Path.of(
                System.getProperty("user.dir"),
                "src",
                "main",
                "cpp",
                "nc.exe");

        try {

            if (!Files.exists(mainCpp)) {

                ide.console.appendText("nc.cpp not found.\n");
                return;
            }

            EditorManager.openFileDirectly(ide, mainCpp);

            ide.console.appendText("Opened nc.cpp\n");

        } catch (Exception e) {

            EditorUIHelper.showError("nc.cpp integration failed", e);
        }
    }

    /**
     * Builds ProcessBuilder command for C++ files.
     * Compiles with g++ and executes the resulting executable.
     * 
     * @param file the file path
     * @param info the file info
     * @return a ProcessBuilder for the command
     */
    private static ProcessBuilder buildCppCommand(String file, EditorFileInfo info) {
        String exe = info.path.getFileName().toString().replace(".cpp", ".exe");
        return new ProcessBuilder("cmd", "/c",
                "g++ \"" + file + "\" -o \"" + exe + "\" && \"" + exe + "\"");
    }

    /**
     * Builds ProcessBuilder command for C files.
     * Compiles with gcc and executes the resulting executable.
     * 
     * @param file the file path
     * @param info the file info
     * @return a ProcessBuilder for the command
     */
    private static ProcessBuilder buildCCommand(String file, EditorFileInfo info) {
        String exe = info.path.getFileName().toString().replace(".c", ".exe");
        return new ProcessBuilder("cmd", "/c",
                "gcc \"" + file + "\" -o \"" + exe + "\" && \"" + exe + "\"");
    }

    /**
     * Builds ProcessBuilder command for Java files.
     * Compiles with javac and executes with java.
     * 
     * @param file the file path
     * @param info the file info
     * @return a ProcessBuilder for the command
     */
    private static ProcessBuilder buildJavaCommand(String file, EditorFileInfo info) {
        String className = info.path.getFileName().toString().replace(".java", "");
        return new ProcessBuilder("cmd", "/c", "javac \"" + file + "\" && java " + className);
    }

    /**
     * Executes a UPI file directly using the UPI engine.
     * 
     * @param ide the IDE controller
     * @param tab the tab containing the UPI file
     */
    private static void executeUpiFile(UI_Main ide, Tab tab) {
        try {
            EditorFileInfo info = (EditorFileInfo) tab.getUserData();
            String text = java.nio.file.Files.readString(info.path);
            // Prepare semantic code in-memory without writing files yet
            String cleaned = LanguageDesignManager.preprocess(text);
            String semanticCode = SemanticEncoder.encode(cleaned);

            // Execute and capture output
            String output = UPIEngine.execute(semanticCode);

            // If output contains any error markers, show errors only and do not update
            // semantic/variable files
            boolean hasError = false;
            for (String line : output.split("\\R")) {
                if (line.startsWith("✖") || line.toLowerCase().contains("syntax error")
                        || line.toLowerCase().contains("error")) {
                    hasError = true;
                    break;
                }
            }

            if (hasError) {
                UI_MainProgramControl.appendErrorText(ide, output);
                UI_MainProgramControl.appendNextPrompt(ide);
                return;
            }

            // No errors: write semantic and variable files and refresh variable explorer
            String writtenSemantic = LanguageDesignManager.writeSemanticFileFromUiCode(text,
                    LanguageDesignManager.buildSemanticPath(info));
            // Keep the variable file aligned with the editor text so the explorer
            // renders the same styled variable names that the user sees in the editor.
            Path variablePath = LanguageDesignManager.buildVariablePath(info);
            Path javaDictionaryPath = LanguageDesignManager.buildJavaDictionaryPath(info);
            String variableSource = cleaned;
            String javaDictionarySource = LanguageDesignManager.normalizeMarkersForVariables(cleaned);
            VariableFileWriter.writeVariablesFile(variableSource, variablePath);
            VariableFileWriter.writeJavaDictionaryFile(javaDictionarySource, javaDictionaryPath);
            // Refresh variable explorer using only the executed UPI tab
            ide.refreshVariablesForOpenTabs(tab);

            // Finally, execute and show output
            ide.console.appendText(output);
            UI_MainProgramControl.appendNextPrompt(ide);
        } catch (Exception e) {
            UI_MainProgramControl.appendErrorText(ide,
                    "UPI execution failed: " + e.getMessage() + "\n");
            UI_MainProgramControl.appendNextPrompt(ide);
        }
    }

    /**
     * Executes a process and handles output/input streams.
     * 
     * @param ide  the IDE controller
     * @param pb   the ProcessBuilder
     * @param info the file info
     * @throws IOException if process start fails
     */
    private static void executeProcess(UI_Main ide, ProcessBuilder pb, EditorFileInfo info) throws IOException {
        pb.directory(info.path.getParent().toFile());
        pb.redirectErrorStream(true);

        Process process = pb.start();
        ide.setRunningProcess(process);
        ide.setProgramRunning(true);

        // Read process output in background thread
        new Thread(() -> {
            try (var input = process.getInputStream()) {
                byte[] buffer = new byte[1024];
                int len;
                while ((len = input.read(buffer)) != -1) {
                    String chunk = new String(buffer, 0, len, StandardCharsets.UTF_8);
                    javafx.application.Platform.runLater(() -> ide.appendProcessOutput(chunk));
                }
            } catch (Exception ignored) {
            }
        }).start();

        // Monitor process completion in background thread
        new Thread(() -> {
            try {
                process.waitFor();
            } catch (InterruptedException ignored) {
            }
            ide.onProgramFinished();
            javafx.application.Platform.runLater(() -> {
                ide.console.appendText("Program finished.");
                UI_MainProgramControl.appendNextPrompt(ide);
            });
        }).start();
    }
}
