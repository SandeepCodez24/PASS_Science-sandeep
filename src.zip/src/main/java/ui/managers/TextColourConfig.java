package ui.managers;

import java.util.EnumMap;
import java.util.Map;

import language.syntax.textcolours.TextCategory;
import language.syntax.textcolours.TextColourFactory;
import language.syntax.textcolours.TextColourMath;

/**
 * What the user chose in the Text Colours window: per category, one colour
 * and whether it is bold or italic.
 *
 * <h3>One colour, both themes</h3>
 * <p>
 * The user picks a single colour, the one for a light editor. The dark
 * editor's colour is derived from it ({@link TextColourMath#darkVariant}),
 * so the two always belong together. A category the user has not touched
 * follows the standard stylesheets exactly, including their hand-tuned dark
 * value.
 * </p>
 *
 * <h3>"Not chosen" is stored as empty</h3>
 * <p>
 * A value equal to the standard one is stored as "not chosen". So when a
 * standard colour is later changed in {@code text_light.css}, every user who
 * never touched that category gets the new colour.
 * </p>
 */
public final class TextColourConfig {

    /** Where the choices are kept; the IDE's Preferences in practice. */
    public interface Store {
        String get(String key, String fallback);

        void put(String key, String value);
    }

    private static final String KEY = "textcolours.";

    /** Chosen light colour, or null for the standard one. */
    private final Map<TextCategory, String> colour = new EnumMap<>(TextCategory.class);
    /** Chosen weight / style, or null for the standard one. */
    private final Map<TextCategory, Boolean> bold = new EnumMap<>(TextCategory.class);
    private final Map<TextCategory, Boolean> italic = new EnumMap<>(TextCategory.class);

    private TextColourConfig() {
    }

    /** @return a copy with nothing chosen: the standard stylesheets */
    public static TextColourConfig factory() {
        return new TextColourConfig();
    }

    /** @return an independent copy */
    public TextColourConfig copy() {
        TextColourConfig c = new TextColourConfig();
        c.colour.putAll(colour);
        c.bold.putAll(bold);
        c.italic.putAll(italic);
        return c;
    }

    // =====================================================================
    // Values
    // =====================================================================

    /** @return the colour for a light editor, {@code #RRGGBB} */
    public String lightHex(TextCategory c) {
        String chosen = colour.get(c);
        return chosen != null ? chosen : TextColourFactory.style(c).lightHex();
    }

    /** @return the colour for a dark editor, {@code #RRGGBB} */
    public String darkHex(TextCategory c) {
        String chosen = colour.get(c);
        return chosen != null ? TextColourMath.darkVariant(chosen) : TextColourFactory.style(c).darkHex();
    }

    /** @return {@link #darkHex} or {@link #lightHex} */
    public String hex(TextCategory c, boolean darkEditor) {
        return darkEditor ? darkHex(c) : lightHex(c);
    }

    public boolean bold(TextCategory c) {
        Boolean b = bold.get(c);
        return b != null ? b : TextColourFactory.style(c).bold();
    }

    public boolean italic(TextCategory c) {
        Boolean b = italic.get(c);
        return b != null ? b : TextColourFactory.style(c).italic();
    }

    /** @param hex the light-editor colour; the standard one clears the choice */
    public void setColour(TextCategory c, String hex) {
        String norm = hex == null ? null : TextColourMath.normalise(hex);
        if (norm == null || norm.equals(TextColourFactory.style(c).lightHex())) {
            colour.remove(c);
        } else {
            colour.put(c, norm);
        }
    }

    public void setBold(TextCategory c, boolean value) {
        if (value == TextColourFactory.style(c).bold()) {
            bold.remove(c);
        } else {
            bold.put(c, value);
        }
    }

    public void setItalic(TextCategory c, boolean value) {
        if (value == TextColourFactory.style(c).italic()) {
            italic.remove(c);
        } else {
            italic.put(c, value);
        }
    }

    /** Puts one category back to the standard look. */
    public void reset(TextCategory c) {
        colour.remove(c);
        bold.remove(c);
        italic.remove(c);
    }

    /** @return true when this category differs from the standard look */
    public boolean isChanged(TextCategory c) {
        return colour.containsKey(c) || bold.containsKey(c) || italic.containsKey(c);
    }

    /** @return true when nothing differs from the standard stylesheets */
    public boolean isFactory() {
        return colour.isEmpty() && bold.isEmpty() && italic.isEmpty();
    }

    // =====================================================================
    // Storage
    // =====================================================================

    /** @return the choices kept in {@code store} */
    public static TextColourConfig load(Store store) {
        TextColourConfig c = new TextColourConfig();
        if (store == null) {
            return c;
        }
        for (TextCategory cat : TextCategory.values()) {
            String hex = store.get(KEY + cat.name() + ".colour", "");
            if (hex != null && !hex.isBlank()) {
                c.setColour(cat, hex);
            }
            String b = store.get(KEY + cat.name() + ".bold", "");
            if (b != null && !b.isBlank()) {
                c.setBold(cat, Boolean.parseBoolean(b));
            }
            String i = store.get(KEY + cat.name() + ".italic", "");
            if (i != null && !i.isBlank()) {
                c.setItalic(cat, Boolean.parseBoolean(i));
            }
        }
        return c;
    }

    /** Writes every category; an unchosen value is written as empty. */
    public void save(Store store) {
        if (store == null) {
            return;
        }
        for (TextCategory cat : TextCategory.values()) {
            store.put(KEY + cat.name() + ".colour", colour.getOrDefault(cat, ""));
            store.put(KEY + cat.name() + ".bold", bold.containsKey(cat) ? bold.get(cat).toString() : "");
            store.put(KEY + cat.name() + ".italic", italic.containsKey(cat) ? italic.get(cat).toString() : "");
        }
    }
}
