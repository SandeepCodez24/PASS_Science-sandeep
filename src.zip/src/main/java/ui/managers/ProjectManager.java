package ui.managers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import javafx.scene.control.TreeItem;
import javafx.stage.DirectoryChooser;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.directory.DirectoryTreeBuilder;
import ui.directory.DirectoryTreeItem;
import ui.directory.NcMetrics;
import ui.directory.repo.RepoStatusRegistry;
import ui.editor.EditorFileStatus;
import ui.editor.homeTab.StepFileRunner;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.SearchPath;

/**
 * Loads and refreshes the directory explorer's contents.
 *
 * <h3>The current folder</h3>
 * <p>
 * The tree's root is the IDE's <b>current folder</b>: the folder scripts run
 * in, as MATLAB's Current Folder is. {@link #loadProjectFromPath} is the one
 * place it moves, and every move -- Home, Back, Forward, Up, Cloud, Root, the
 * breadcrumb, a double-click on a folder, Open Folder, and the "Change Folder"
 * answer when a file outside it is run -- comes through here. So a move does
 * all of this at once:
 * </p>
 * <ul>
 * <li>installs the new tree root and redraws the breadcrumb;</li>
 * <li>sends {@code @cmd setpwd} to {@code nc.exe}, so the Command Window
 * resolves script names against the folder the user can see;</li>
 * <li>tells {@link SearchPath}, so the editor's checker knows which scripts can
 * be called by bare name;</li>
 * <li>ends every step session, when the folder actually changes: a half-run
 * script does not carry on in another folder.</li>
 * </ul>
 * <p>
 * The current folder is not the root folder. The root is a bookmark the user
 * declares with the Root button; the two may be the same folder, but nothing
 * here touches the root.
 * </p>
 *
 * <h3>Refresh keeps the tree open</h3>
 * <p>
 * {@link #refreshProjectTree} used to install a brand-new root on every call.
 * It runs after every save -- including the save Run does before running -- so
 * every run collapsed the tree, and a subfolder whose script was just run
 * showed nothing. It now re-reads the existing tree in place
 * ({@link DirectoryTreeBuilder#refresh()}): opened folders stay open and new or
 * deleted files appear or go. A new root is installed only if there is no tree
 * to reconcile.
 * </p>
 */
public class ProjectManager {

    /**
     * Load a project folder chosen from a dialog.
     *
     * <p>
     * Kept for any older call sites. New code should go through
     * {@code EditorFileOpener.openProjectFolder}, which additionally records
     * the folder as the last project so the Open menu can return to it.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void loadProject(UI_Main ide) {
        if (ide == null) {
            return;
        }
        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Select Project Folder");
        File dir = dc.showDialog(ide.stage);
        if (dir == null) {
            return;
        }
        loadProjectFromPath(ide, dir.toPath());
    }

    /**
     * Makes a folder the current folder.
     *
     * <p>
     * Sets {@code ide.currentFolder}, pushes the path to the breadcrumb bar,
     * installs a fresh tree root, points the backend at the folder and, if the
     * folder changed, ends every step session. See the class comment.
     * </p>
     *
     * @param ide  the IDE controller
     * @param path the folder to show
     */
    public static void loadProjectFromPath(UI_Main ide, Path path) {
        if (ide == null || path == null || !Files.isDirectory(path)) {
            return;
        }

        Path normalised = path.toAbsolutePath().normalize();

        Path previous = null;
        if (ide.projectTree != null && ide.projectTree.getRoot() != null) {
            previous = ide.projectTree.getRoot().getValue();
        }
        boolean moved = previous == null || !FolderPaths.same(previous, normalised);

        ide.currentFolder = normalised;
        ToolbarManager.updateQuickPath(normalised);

        // Asked once per root, not once per row.
        RepoStatusRegistry.rootChanged(normalised);

        // The backend resolves script names here from now on. Before the
        // interpreter has started this only records the folder; the launch
        // sends it.
        CLI_Main.setWorkspaceDirectory(normalised);
        SearchPath.setCurrentFolder(normalised);

        if (moved) {
            // A step run belongs to the folder it was started in.
            StepFileRunner.reset(ide);
        }

        if (ide.projectTree == null) {
            return;
        }

        ide.projectTree.setRoot(DirectoryTreeItem.rootFor(normalised));
        if (ide.projectTree.getSelectionModel() != null) {
            ide.projectTree.getSelectionModel().clearSelection();
        }
    }

    /**
     * Re-reads the tree from disk, keeping the same root and everything the
     * user has opened under it.
     *
     * <p>
     * Use this after files change on disk. It deliberately does not read
     * {@code ide.currentFolder}, because opening a file moves that field to the
     * file's parent and the tree should not follow. When the tree has no root
     * at all, {@code currentFolder} is used as a starting point.
     * </p>
     *
     * <p>
     * The cached line, function and class counts are dropped at the same time,
     * and the open tabs are re-checked against the disk: a save writes a
     * struck-out (deleted) file back, and this is where its tab loses the
     * strike-through.
     * </p>
     *
     * @param ide the IDE controller
     */
    public static void refreshProjectTree(UI_Main ide) {
        if (ide == null) {
            return;
        }
        EditorFileStatus.refresh(ide);
        if (ide.projectTree == null) {
            return;
        }

        TreeItem<Path> existing = ide.projectTree.getRoot();
        NcMetrics.invalidateAll();

        if (existing instanceof DirectoryTreeItem && existing.getValue() != null
                && Files.isDirectory(existing.getValue())) {
            // In place: opened folders stay open, selection and scroll stay.
            DirectoryTreeBuilder.refresh();
            return;
        }

        Path rootPath = (existing != null) ? existing.getValue() : ide.currentFolder;
        if (rootPath == null || !Files.isDirectory(rootPath)) {
            return;
        }
        ide.projectTree.setRoot(DirectoryTreeItem.rootFor(rootPath));
    }
}
