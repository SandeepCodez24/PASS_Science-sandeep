package ui.managers;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.function.Function;

import javafx.scene.Scene;
import language.syntax.textcolours.TextCategory;
import language.syntax.textcolours.TextColourFactory;
import ui.UI_Main;

/**
 * Keeps the text colours on the scene, for the editor and the Command Window.
 *
 * <h3>What is on the scene</h3>
 *
 * <pre>
 *   ... light.css / dark.css ... editor_*.css   text_*.css   [custom]   [console]
 *                                               ^ standard   ^ user's   ^ Command
 *                                                 colours      choices    Window
 * </pre>
 *
 * <p>
 * {@code ThemeManager} calls {@link #apply} each time it puts the editor
 * sheet on, so these sheets always come straight after it. Same selectors,
 * later sheet: the custom colours win over the standard ones without
 * {@code !important}.
 * </p>
 *
 * <h3>Light or dark: the background decides</h3>
 * <ul>
 * <li><b>Editor</b>: {@code ThemeManager} passes "is the editor dark", not
 * "is the theme dark". A dark editor in the Custom layout's light theme gets
 * {@code text_dark.css}.</li>
 * <li><b>Command Window</b>: its own generated sheet ({@code .console-area}
 * rules) carries the full palette for <i>its</i> background, so a dark
 * Command Window beside a light editor still gets readable commands. Normally
 * it follows the theme; the Custom layout sets
 * {@link #setConsoleInkSelector} from the CLI's chosen colour.</li>
 * </ul>
 *
 * <h3>Three copies, as in the Custom layout</h3>
 * <ul>
 * <li><b>Factory</b>: the two stylesheets on their own.</li>
 * <li><b>Saved</b>: what Apply stored in the IDE's Preferences.</li>
 * <li><b>Preview</b>: what the window's Preview button is showing; never
 * stored, cleared by Apply and Cancel.</li>
 * </ul>
 */
public final class TextColourManager {

    private static final String DARK = "dark";

    private static UI_Main ide;
    private static String theme = "light";
    private static boolean darkEditor;
    private static boolean darkConsole;
    private static TextColourConfig saved;
    private static boolean savedFromStore;
    private static TextColourConfig preview;
    private static String customSheet;
    private static String consoleSheet;

    /** Theme name to "is the Command Window dark?"; null follows the theme. */
    private static Function<String, Boolean> consoleInkSelector;

    private TextColourManager() {
    }

    // =====================================================================
    // On the scene
    // =====================================================================

    /**
     * Puts the matching text sheet, the custom sheet if any, and the Command
     * Window sheet on the scene, after everything already there. Called by
     * {@code ThemeManager} right after it adds the editor sheet.
     *
     * @param ideRef     the IDE controller
     * @param themeName  the theme being applied, "light" or "dark"
     * @param darkEditor true when the editor background is dark
     */
    public static void apply(UI_Main ideRef, String themeName, boolean darkEditor) {
        ide = ideRef;
        theme = themeName == null ? theme : themeName;
        TextColourManager.darkEditor = darkEditor;
        Boolean consoleChoice = consoleInkSelector == null ? null : consoleInkSelector.apply(theme);
        darkConsole = consoleChoice != null ? consoleChoice : DARK.equals(theme);
        if (ide == null || ide.scene == null) {
            return;
        }
        Scene scene = ide.scene;
        String light = external(TextColourFactory.LIGHT_CSS);
        String dark = external(TextColourFactory.DARK_CSS);
        List<String> sheets = scene.getStylesheets();

        if (light != null) {
            sheets.remove(light);
        }
        if (dark != null) {
            sheets.remove(dark);
        }
        if (customSheet != null) {
            sheets.remove(customSheet);
            customSheet = null;
        }
        if (consoleSheet != null) {
            sheets.remove(consoleSheet);
            consoleSheet = null;
        }

        String wanted = darkEditor ? dark : light;
        if (wanted != null) {
            sheets.add(wanted);
        } else {
            System.err.println("Text colours: stylesheet missing: "
                    + (darkEditor ? TextColourFactory.DARK_CSS : TextColourFactory.LIGHT_CSS));
        }

        TextColourConfig config = effective();
        if (!config.isFactory()) {
            customSheet = dataUri(customCss(config, darkEditor));
            sheets.add(customSheet);
        }
        consoleSheet = dataUri(consoleCss(config, darkConsole));
        sheets.add(consoleSheet);
    }

    /** Re-applies with the last theme and backgrounds; after Preview, Apply, Cancel. */
    public static void refresh() {
        if (ide != null) {
            apply(ide, theme, darkEditor);
        }
    }

    /**
     * Chooses the Command Window's text palette independently of the theme.
     * The Custom layout sets it from the CLI's chosen background.
     *
     * @param selector theme name to "is the Command Window dark?", or null to
     *                 follow the theme again
     */
    public static void setConsoleInkSelector(Function<String, Boolean> selector) {
        consoleInkSelector = selector;
        refresh();
    }

    /** @return true when the editor in use has a dark background */
    public static boolean isDarkEditor() {
        return darkEditor;
    }

    /** @return true when the Command Window has a dark background */
    public static boolean isDarkConsole() {
        return darkConsole;
    }

    // =====================================================================
    // The three copies
    // =====================================================================

    /** @return what Apply last stored (nothing chosen if never applied) */
    public static TextColourConfig saved() {
        // Read again once Preferences are reachable, in case something asked
        // before ThemeManager first called apply().
        if (saved == null || (!savedFromStore && store() != null)) {
            TextColourConfig.Store store = store();
            saved = TextColourConfig.load(store);
            savedFromStore = store != null;
        }
        return saved;
    }

    /** @return the preview while there is one, otherwise the saved copy */
    public static TextColourConfig effective() {
        return preview != null ? preview : saved();
    }

    /** @param config what Preview shows, or null to drop the preview */
    public static void setPreview(TextColourConfig config) {
        preview = config == null ? null : config.copy();
    }

    /** Stores a copy, in memory and in Preferences. */
    public static void save(TextColourConfig config) {
        saved = config.copy();
        TextColourConfig.Store store = store();
        saved.save(store);
        savedFromStore = store != null;
    }

    // =====================================================================
    // Generated sheets
    // =====================================================================

    /**
     * Rules for the categories the user changed, in the same shape as the
     * standard sheets.
     *
     * @param config     the choices
     * @param darkEditor which partner to write
     * @return the CSS text
     */
    public static String customCss(TextColourConfig config, boolean darkEditor) {
        StringBuilder css = new StringBuilder(1024);
        css.append("/* Text Colours window: user choices (generated) */\n");
        for (TextCategory c : TextCategory.values()) {
            if (config.isChanged(c)) {
                rule(css, ".code-area .text." + c.styleClass() + ",\n.styled-text-area .text." + c.styleClass(),
                        config.hex(c, darkEditor), config.bold(c), config.italic(c));
            }
        }
        return css.toString();
    }

    /**
     * The Command Window's whole palette for its own background: every
     * category (with the user's choices) for the typed commands, plus output
     * and prompt from blocks 13 and 14 of the text stylesheets.
     *
     * @param config      the choices
     * @param darkConsole true for a dark Command Window
     * @return the CSS text
     */
    public static String consoleCss(TextColourConfig config, boolean darkConsole) {
        StringBuilder css = new StringBuilder(2048);
        css.append("/* Command Window text colours (generated) */\n");
        for (TextCategory c : TextCategory.values()) {
            rule(css, ".console-area .text." + c.styleClass(),
                    config.hex(c, darkConsole), config.bold(c), config.italic(c));
        }
        for (String cls : new String[] { TextColourFactory.CONSOLE_OUTPUT, TextColourFactory.CONSOLE_PROMPT }) {
            TextColourFactory.Style s = TextColourFactory.style(cls);
            rule(css, ".console-area .text." + cls,
                    darkConsole ? s.darkHex() : s.lightHex(), s.bold(), s.italic());
        }
        return css.toString();
    }

    private static void rule(StringBuilder css, String selector, String hex, boolean bold, boolean italic) {
        css.append(selector).append(" {\n")
                .append("    -fx-fill: ").append(hex).append(";\n")
                .append("    -fx-font-weight: ").append(bold ? "bold" : "normal").append(";\n")
                .append("    -fx-font-style: ").append(italic ? "italic" : "normal").append(";\n")
                .append("}\n");
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static TextColourConfig.Store store() {
        if (ide == null || ide.prefs == null) {
            return null;
        }
        return new TextColourConfig.Store() {
            @Override
            public String get(String key, String fallback) {
                return ide.prefs.get(key, fallback);
            }

            @Override
            public void put(String key, String value) {
                ide.prefs.put(key, value);
            }
        };
    }

    private static String external(String resource) {
        URL url = TextColourManager.class.getResource(resource);
        return url == null ? null : url.toExternalForm();
    }

    private static String dataUri(String css) {
        return "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
    }
}
