package ui.editor.navigation;

import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javafx.application.Platform;

/**
 * The folders scripts were run in, newest first: the list the breadcrumb's
 * history drop-down shows, MATLAB-style.
 *
 * <h3>What goes in</h3>
 * <ul>
 * <li>The current folder at the moment a script runs, whichever way it runs:
 * the Run button ({@code EditorFileRunner}), the Step button when a step run
 * arms ({@code StepFileRunner}), or a script typed in the Command Window
 * ({@code CLI_Main}). All three come through
 * {@link NavigationActions#recordRecentFolder}.</li>
 * <li>Each folder appears once. Running in a folder that is already listed
 * moves it back to the top.</li>
 * <li>At most {@link #MAX_ENTRIES}; the oldest drop off the bottom.</li>
 * <li>Folders deleted since they were recorded are dropped silently whenever
 * the list is read.</li>
 * <li>Kept across restarts in {@link Preferences}.</li>
 * </ul>
 *
 * <h3>Why this is not {@link FolderHistory}</h3>
 * <p>
 * {@code FolderHistory} drives Back / Forward. It keeps a cursor and, like a
 * browser, throws away everything ahead of the cursor when a run happens while
 * stepped back. That is right for Back / Forward and wrong for a chronological
 * list, where entries would vanish for no reason the user can see. The two
 * lists are fed at the same moments but kept apart.
 * </p>
 *
 * <p>
 * Call from the FX thread; listeners are always notified on it.
 * </p>
 */
public final class RunFolderHistory {

    /** Longest list kept. */
    public static final int MAX_ENTRIES = 20;

    private static final Preferences PREFS = Preferences.userRoot().node("astra/run_folder_history");
    private static final String KEY_ENTRIES = "entries";

    /** A character Windows forbids in paths, so it can never appear inside an entry. */
    private static final String SEP = "|";

    /** Newest first. */
    private static final List<Path> ENTRIES = new ArrayList<>();
    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();
    private static boolean loaded;

    private RunFolderHistory() {
    }

    // =================================================================
    // Write
    // =================================================================

    /**
     * Puts a folder at the top of the list.
     *
     * @param folder the folder a script ran in; ignored if null or missing
     */
    public static void record(Path folder) {
        ensureLoaded();
        if (!FolderPaths.isFolder(folder)) {
            return;
        }
        Path entry = FolderPaths.canonical(folder);
        if (!ENTRIES.isEmpty() && FolderPaths.sameCanonical(ENTRIES.get(0), entry)) {
            return; // already on top; nothing moves
        }
        ENTRIES.removeIf(p -> FolderPaths.sameCanonical(p, entry));
        ENTRIES.add(0, entry);
        while (ENTRIES.size() > MAX_ENTRIES) {
            ENTRIES.remove(ENTRIES.size() - 1);
        }
        save();
        fire();
    }

    /**
     * Forgets the whole list, in memory and on disk.
     */
    public static void clear() {
        ensureLoaded();
        if (ENTRIES.isEmpty()) {
            return;
        }
        ENTRIES.clear();
        save();
        fire();
    }

    // =================================================================
    // Read
    // =================================================================

    /**
     * @return the run folders, newest first, without any that no longer exist
     */
    public static List<Path> entries() {
        ensureLoaded();
        if (ENTRIES.removeIf(p -> !FolderPaths.isFolder(p))) {
            save();
        }
        return List.copyOf(ENTRIES);
    }

    /**
     * @return true if no folder has been recorded
     */
    public static boolean isEmpty() {
        return entries().isEmpty();
    }

    /**
     * @param listener run whenever the list changes
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    // =================================================================
    // Storage
    // =================================================================

    private static void ensureLoaded() {
        if (loaded) {
            return;
        }
        loaded = true;
        String stored = PREFS.get(KEY_ENTRIES, "");
        if (stored.isBlank()) {
            return;
        }
        for (String raw : stored.split("\\" + SEP)) {
            if (raw.isBlank()) {
                continue;
            }
            try {
                // Canonicalised again in case a drive alias changed since.
                Path p = FolderPaths.canonical(Path.of(raw));
                boolean dup = false;
                for (Path existing : ENTRIES) {
                    if (FolderPaths.sameCanonical(existing, p)) {
                        dup = true;
                        break;
                    }
                }
                if (!dup) {
                    ENTRIES.add(p);
                }
            } catch (InvalidPathException ignored) {
                // A malformed stored entry is skipped rather than fatal.
            }
        }
        while (ENTRIES.size() > MAX_ENTRIES) {
            ENTRIES.remove(ENTRIES.size() - 1);
        }
    }

    private static void save() {
        StringBuilder joined = new StringBuilder();
        for (Path p : ENTRIES) {
            if (joined.length() > 0) {
                joined.append(SEP);
            }
            joined.append(p);
        }
        // Preferences caps a value at 8192 characters; drop the oldest
        // (rightmost) entries if twenty long paths ever exceed it.
        String value = joined.toString();
        while (value.length() > Preferences.MAX_VALUE_LENGTH && value.contains(SEP)) {
            value = value.substring(0, value.lastIndexOf(SEP));
        }
        PREFS.put(KEY_ENTRIES, value);
        try {
            PREFS.flush();
        } catch (BackingStoreException ignored) {
            // The list still holds for this session.
        }
    }

    private static void fire() {
        Runnable notify = () -> {
            for (Runnable listener : LISTENERS) {
                try {
                    listener.run();
                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
            }
        };
        if (Platform.isFxApplicationThread()) {
            notify.run();
        } else {
            Platform.runLater(notify);
        }
    }
}
