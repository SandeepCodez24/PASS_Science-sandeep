package ui.editor.navigation;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javafx.application.Platform;
import language.syntax.syntax_checker.core.CheckContext;
import ui.cli.CLI_Main;

/**
 * The folders added to the path for this session, MATLAB's {@code addpath}.
 *
 * <h3>The current folder model</h3>
 * <p>
 * The <b>current folder</b> is the folder the File Explorer and the breadcrumb
 * are showing (the tree's root). It is what {@code nc.exe} resolves script
 * names against, and only a {@code .nc} file sitting directly in it -- or in a
 * folder listed here -- may run through Run, Step or the Command Window.
 * </p>
 * <p>
 * The <b>root folder</b> ({@link RootFolderStore}) is a different thing: a
 * bookmark the user keeps so the Root button can bring them back to it. The
 * current folder can be the root folder, but nothing requires it.
 * </p>
 *
 * <h3>What this class holds</h3>
 * <ul>
 * <li>Session only, as {@code addpath} is in MATLAB. Nothing is stored; a
 * restart starts with an empty path.</li>
 * <li>Folders are kept canonical ({@link FolderPaths#canonical}) and in the
 * order they were added, which is also the order the Command Window searches
 * them after the current folder.</li>
 * <li>The current folder is never added: it is always searched first
 * anyway.</li>
 * </ul>
 *
 * <h3>Who is told about a change</h3>
 * <ul>
 * <li>The backend: an added folder is sent as {@code addpath} at once; a
 * removed one needs a quiet restart of {@code nc.exe}, which has no
 * {@code rmpath} ({@link CLI_Main#rebuildSearchPath()}).</li>
 * <li>The editor's checker ({@link CheckContext#setSearchFolders}), so a bare
 * {@code ABC;} is accepted when {@code ABC.nc} lives in the current folder or
 * in an added one.</li>
 * <li>Listeners -- the Root menu and its tooltip, and the File Explorer,
 * which dims every row that is not on the path
 * ({@code ui.directory.DirectoryPathShading}).</li>
 * </ul>
 *
 * <p>
 * Call from the FX thread.
 * </p>
 */
public final class SearchPath {

    private static final List<Path> FOLDERS = new ArrayList<>();
    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    /** The current folder as last reported by the project loader; checker only. */
    private static Path currentFolder;

    private SearchPath() {
    }

    // =================================================================
    // Read
    // =================================================================

    /**
     * @return the added folders, oldest first (a snapshot)
     */
    public static List<Path> folders() {
        return List.copyOf(FOLDERS);
    }

    /**
     * @return true if no folder has been added this session
     */
    public static boolean isEmpty() {
        return FOLDERS.isEmpty();
    }

    /**
     * @param folder any folder; may be null
     * @return true if it has been added to the path
     */
    public static boolean contains(Path folder) {
        if (folder == null) {
            return false;
        }
        Path canonical = FolderPaths.canonical(folder);
        for (Path added : FOLDERS) {
            if (FolderPaths.sameCanonical(added, canonical)) {
                return true;
            }
        }
        return false;
    }

    // =================================================================
    // Write
    // =================================================================

    /**
     * Adds a folder to the path and tells the backend.
     *
     * @param folder the folder; ignored if null, missing, already added, or
     *               the current folder
     * @return true if it was added
     */
    public static boolean add(Path folder) {
        if (!FolderPaths.isFolder(folder) || contains(folder)) {
            return false;
        }
        Path canonical = FolderPaths.canonical(folder);
        if (currentFolder != null && FolderPaths.sameCanonical(canonical, currentFolder)) {
            return false;
        }
        FOLDERS.add(canonical);
        publish();
        CLI_Main.addSearchPath(canonical);
        fire();
        return true;
    }

    /**
     * Adds several folders in one step: one checker update and one listener
     * round for the lot, so the File Explorer repaints once. Folders that are
     * missing, already added or the current folder are skipped.
     *
     * @param folders the folders, in the order they should be searched
     * @return how many were added
     */
    public static int addAll(Collection<Path> folders) {
        if (folders == null || folders.isEmpty()) {
            return 0;
        }
        List<Path> fresh = new ArrayList<>();
        for (Path folder : folders) {
            if (!FolderPaths.isFolder(folder)) {
                continue;
            }
            Path canonical = FolderPaths.canonical(folder);
            if (canonical == null || contains(canonical) || fresh.contains(canonical)
                    || (currentFolder != null && FolderPaths.sameCanonical(canonical, currentFolder))) {
                continue;
            }
            fresh.add(canonical);
        }
        if (fresh.isEmpty()) {
            return 0;
        }
        FOLDERS.addAll(fresh);
        publish();
        for (Path canonical : fresh) {
            CLI_Main.addSearchPath(canonical);
        }
        fire();
        return fresh.size();
    }

    /**
     * Removes several folders in one step: one quiet backend restart, one
     * checker update and one listener round for the lot.
     *
     * @param folders the folders to take off the path
     * @return how many were on the path and are now removed
     */
    public static int removeAll(Collection<Path> folders) {
        if (folders == null || folders.isEmpty()) {
            return 0;
        }
        List<Path> targets = new ArrayList<>();
        for (Path folder : folders) {
            if (folder != null) {
                targets.add(FolderPaths.canonical(folder));
            }
        }
        int before = FOLDERS.size();
        FOLDERS.removeIf(added -> {
            for (Path target : targets) {
                if (FolderPaths.sameCanonical(added, target)) {
                    return true;
                }
            }
            return false;
        });
        int removed = before - FOLDERS.size();
        if (removed > 0) {
            publish();
            CLI_Main.rebuildSearchPath();
            fire();
        }
        return removed;
    }

    /**
     * Removes a folder from the path. The backend has no {@code rmpath}, so it
     * is restarted quietly on the same workspace; if a command is running, that
     * happens as soon as it finishes.
     *
     * @param folder the folder
     * @return true if it was on the path
     */
    public static boolean remove(Path folder) {
        if (folder == null) {
            return false;
        }
        Path canonical = FolderPaths.canonical(folder);
        boolean removed = FOLDERS.removeIf(added -> FolderPaths.sameCanonical(added, canonical));
        if (removed) {
            publish();
            CLI_Main.rebuildSearchPath();
            fire();
        }
        return removed;
    }

    /**
     * Removes every added folder.
     *
     * @return true if anything was removed
     */
    public static boolean clear() {
        if (FOLDERS.isEmpty()) {
            return false;
        }
        FOLDERS.clear();
        publish();
        CLI_Main.rebuildSearchPath();
        fire();
        return true;
    }

    /**
     * Records the current folder, so the editor's checker can accept script
     * calls into it from a file that lives in an added folder. Called by
     * {@code ProjectManager.loadProjectFromPath} on every move.
     *
     * @param folder the new current folder; may be null
     */
    public static void setCurrentFolder(Path folder) {
        currentFolder = folder == null ? null : FolderPaths.canonical(folder);
        publish();
        fire();
    }

    /**
     * Registers a callback run whenever the path or the current folder
     * changes.
     *
     * @param listener the callback
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    // =================================================================
    // Internals
    // =================================================================

    /** Hands the checker the folders a bare script name can be found in. */
    private static void publish() {
        List<Path> searched = new ArrayList<>();
        if (currentFolder != null) {
            searched.add(currentFolder);
        }
        searched.addAll(FOLDERS);
        CheckContext.setSearchFolders(searched);
    }

    private static void fire() {
        Runnable notify = () -> {
            for (Runnable listener : LISTENERS) {
                try {
                    listener.run();
                } catch (RuntimeException e) {
                    e.printStackTrace();
                }
            }
        };
        if (Platform.isFxApplicationThread()) {
            notify.run();
        } else {
            Platform.runLater(notify);
        }
    }
}
