package ui.editor.navigation;

import java.nio.file.Path;
import java.util.List;

import ui.UI_Main;
import ui.directory.DirectoryTreeBuilder;
import ui.explorer.navigation.ChoiceDialog;
import ui.explorer.navigation.ChoiceDialog.Choice;
import ui.explorer.navigation.ChoiceDialog.Side;

/**
 * Decides whether a {@code .nc} file may run, and asks the user what to do
 * when it may not -- MATLAB's "file is not in the current folder" question,
 * with one more answer.
 *
 * <h3>The rule</h3>
 * <p>
 * A file may run through Run, Step or the Command Window only if it sits
 * <b>directly</b> in the current folder (the folder the File Explorer and the
 * breadcrumb show), or directly in a folder added to the path this session
 * ({@link SearchPath}). A file in a subfolder of the current folder does not
 * qualify on its own; that is MATLAB's strict rule. Opening a file is never
 * restricted.
 * </p>
 *
 * <h3>The four answers</h3>
 * <table>
 * <caption>What each button does before the run goes ahead</caption>
 * <tr><td>Add Path</td><td>The current folder stays; the file's folder is
 * added to the path for this session. If that folder is inside the current
 * folder, it is opened in the File Explorer and the file selected, so its
 * contents are in view.</td></tr>
 * <tr><td>Change folder &amp; Set as Root</td><td>The file's folder becomes
 * the current folder and is also declared as the root folder.</td></tr>
 * <tr><td>Change Folder</td><td>The default (Enter). The file's folder becomes
 * the current folder; the root folder is left alone.</td></tr>
 * <tr><td>Cancel</td><td>Esc. Nothing changes and nothing runs.</td></tr>
 * </table>
 *
 * <p>
 * Changing folder goes through {@link NavigationActions#goTo}, the same path
 * every navigation button uses, so the tree, the breadcrumb, the backend's
 * working folder and the step sessions all follow in one move.
 * </p>
 */
public final class RunScope {

    private static final String ADD_PATH = "addPath";
    private static final String CHANGE_AND_ROOT = "changeAndRoot";
    private static final String CHANGE = "change";
    private static final String CANCEL = "cancel";

    private RunScope() {
    }

    /**
     * @param ide  the IDE controller
     * @param file a saved file; may be null
     * @return true if the file sits directly in the current folder or in a
     *         folder on the path
     */
    public static boolean isRunnableHere(UI_Main ide, Path file) {
        Path folder = folderOf(file);
        if (folder == null) {
            return false;
        }
        Path current = NavigationActions.projectFolder(ide);
        return FolderPaths.sameCanonical(folder, current) || SearchPath.contains(folder);
    }

    /**
     * Lets a run go ahead, asking first when the file is outside the current
     * folder and the path. Call on the FX thread; the dialog is modal.
     *
     * @param ide  the IDE controller
     * @param file the saved file about to run
     * @return true to run, false if the user cancelled or the folder could not
     *         be reached
     */
    public static boolean confirm(UI_Main ide, Path file) {
        if (ide == null || file == null) {
            return false;
        }
        if (isRunnableHere(ide, file)) {
            return true;
        }
        Path folder = folderOf(file);
        if (folder == null) {
            return false;
        }
        Path current = NavigationActions.projectFolder(ide);

        String answer = ChoiceDialog.show(ide.stage,
                "The file \u201C" + ChoiceDialog.breakable(file.toAbsolutePath().toString())
                        + "\u201D is not in the current folder.",
                "To run this file, change the current folder to the file's folder, "
                        + "or add that folder to the path for this session.",
                current != null
                        ? "Current folder: " + ChoiceDialog.breakable(current.toString())
                        : "No current folder is open.",
                List.of(
                        new Choice(ADD_PATH, "Add Path",
                                "Keep the current folder and add " + folder
                                        + " to the path for this session",
                                Side.LEFT, false, false),
                        new Choice(CHANGE_AND_ROOT, "Change folder &\nSet as Root",
                                "Make " + folder + " the current folder and remember it as the root folder",
                                Side.LEFT, false, false),
                        new Choice(CHANGE, "Change Folder",
                                "Make " + folder + " the current folder",
                                Side.RIGHT, true, false),
                        new Choice(CANCEL, "Cancel", "Do not run the file",
                                Side.RIGHT, false, true)));

        if (answer == null) {
            return false;
        }
        switch (answer) {
            case CHANGE:
                return changeTo(ide, folder);
            case CHANGE_AND_ROOT:
                if (!changeTo(ide, folder)) {
                    return false;
                }
                if (RootFolderStore.declare(folder)) {
                    NavigationActions.say("Root folder set: " + folder);
                }
                return true;
            case ADD_PATH:
                if (!SearchPath.add(folder) && !SearchPath.contains(folder)) {
                    NavigationActions.say("Could not add to path: " + folder);
                    return false;
                }
                NavigationActions.say("Added to path for this session: " + folder);
                revealIfInside(file, current);
                return true;
            default:
                return false;
        }
    }

    // -----------------------------------------------------------------
    // internals
    // -----------------------------------------------------------------

    private static boolean changeTo(UI_Main ide, Path folder) {
        if (!NavigationActions.goTo(ide, folder)) {
            NavigationActions.say("Cannot change the current folder to " + folder);
            return false;
        }
        return true;
    }

    /**
     * Opens the folders between the current folder and the file in the File
     * Explorer and selects the file, when the file is inside the current
     * folder's tree. A file elsewhere is left alone; the tree does not move.
     */
    private static void revealIfInside(Path file, Path current) {
        if (current == null) {
            return;
        }
        Path canonicalFile = FolderPaths.canonical(file);
        if (canonicalFile != null && canonicalFile.startsWith(current)) {
            DirectoryTreeBuilder.reveal(canonicalFile);
        }
    }

    private static Path folderOf(Path file) {
        if (file == null) {
            return null;
        }
        Path parent = file.toAbsolutePath().getParent();
        return parent == null ? null : FolderPaths.canonical(parent);
    }
}
