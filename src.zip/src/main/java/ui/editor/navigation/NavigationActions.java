package ui.editor.navigation;

import java.io.File;
import java.nio.file.Path;

import javafx.scene.control.TreeItem;
import javafx.stage.DirectoryChooser;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.homeTab.EditorFileOpener;
import ui.editor.homeTab.HomeFilesProject;

/**
 * What the navigation bar and the breadcrumb actually do. No JavaFX controls
 * live here -- {@code ui.explorer.navigation.NavigationBar} and
 * {@code BreadcrumbBar} build the buttons and call in.
 *
 * <h3>"The folder being shown"</h3>
 * <p>
 * Every action measures from the project tree's root, not from
 * {@code ide.currentFolder}. Opening a file moves {@code currentFolder} to that
 * file's parent (it is the file chooser's start directory), but the tree and
 * the breadcrumb stay put, and Up / Set Root / Back have to agree with what the
 * user can see.
 * </p>
 *
 * <h3>Moving the tree</h3>
 * <p>
 * Every move goes through {@link EditorFileOpener#loadFolderAsProject}, the
 * same path Open Folder uses. That installs the new tree root, redraws the
 * breadcrumb and remembers the folder as the last project, so "Open Last
 * Project" follows browsing as well.
 * </p>
 *
 * <h3>Current folder, root folder, path</h3>
 * <p>
 * Three different things, kept apart on purpose:
 * </p>
 * <ul>
 * <li>the <b>current folder</b> is the tree's root ({@link #projectFolder}):
 * where scripts run, and the only folder whose files Run, Step and the Command
 * Window accept;</li>
 * <li>the <b>root folder</b> ({@link RootFolderStore}) is a bookmark the Root
 * button returns to;</li>
 * <li>the <b>path</b> ({@link SearchPath}) is the list of extra folders whose
 * scripts may also run this session.</li>
 * </ul>
 *
 * <h3>Messages</h3>
 * <p>
 * When a button has nowhere to go it says so in the Command Window rather than
 * doing nothing silently, and repaints the prompt afterwards.
 * </p>
 */
public final class NavigationActions {

    private NavigationActions() {
    }

    // =================================================================
    // Where are we
    // =================================================================

    /**
     * @param ide the IDE controller
     * @return the project tree's root folder, canonicalised, or null if the
     *         tree is empty
     */
    public static Path projectFolder(UI_Main ide) {
        if (ide == null || ide.projectTree == null) {
            return null;
        }
        TreeItem<Path> root = ide.projectTree.getRoot();
        if (root == null || root.getValue() == null) {
            return null;
        }
        return FolderPaths.canonical(root.getValue());
    }

    /**
     * The folder the breadcrumb is showing: the tree root, or failing that the
     * editor's current folder.
     *
     * @param ide the IDE controller
     * @return the folder, canonicalised, or null if there is none
     */
    public static Path shownFolder(UI_Main ide) {
        Path project = projectFolder(ide);
        if (project != null) {
            return project;
        }
        return (ide != null) ? FolderPaths.canonical(ide.currentFolder) : null;
    }

    // =================================================================
    // Moving
    // =================================================================

    /**
     * Shows a folder in the tree and the breadcrumb.
     *
     * @param ide    the IDE controller
     * @param folder the folder to show
     * @return true if the folder exists and was loaded
     */
    public static boolean goTo(UI_Main ide, Path folder) {
        if (ide == null || !FolderPaths.isFolder(folder)) {
            return false;
        }
        EditorFileOpener.loadFolderAsProject(ide, FolderPaths.canonical(folder));
        return true;
    }

    /**
     * Home: always {@code Documents\NeuralCode}, created if missing.
     *
     * @param ide the IDE controller
     */
    public static void goHome(UI_Main ide) {
        Path home = DefaultFolders.neuralCodeHome();
        if (!goTo(ide, home)) {
            say("Home folder is not available: " + home);
        }
    }

    /**
     * Back: the previous folder a file was run in.
     *
     * @param ide the IDE controller
     */
    public static void goBack(UI_Main ide) {
        Path target = FolderHistory.back(shownFolder(ide));
        if (target == null) {
            say("No earlier run folder to go back to.");
            return;
        }
        goTo(ide, target);
    }

    /**
     * Forward: the next folder a file was run in, after stepping back.
     *
     * @param ide the IDE controller
     */
    public static void goForward(UI_Main ide) {
        Path target = FolderHistory.forward();
        if (target == null) {
            say("No later run folder to go forward to.");
            return;
        }
        goTo(ide, target);
    }

    /**
     * Up: one level above the folder being shown.
     *
     * @param ide the IDE controller
     */
    public static void goUp(UI_Main ide) {
        Path shown = shownFolder(ide);
        Path parent = (shown != null) ? shown.getParent() : null;
        if (parent == null) {
            say(shown == null ? "No folder is open." : "Already at the top of " + FolderPaths.label(shown) + ".");
            return;
        }
        goTo(ide, parent);
    }

    /**
     * Root button click: the declared root, falling back to the last run root.
     * Shares its logic with Open &gt; Open Root Folder.
     *
     * @param ide the IDE controller
     */
    public static void goToRoot(UI_Main ide) {
        EditorFileOpener.openRootFolder(ide);
    }

    /**
     * Declares the folder being shown as the root.
     *
     * @param ide the IDE controller
     */
    public static void declareShownAsRoot(UI_Main ide) {
        Path shown = shownFolder(ide);
        if (shown == null || !RootFolderStore.declare(shown)) {
            say("No folder to set as root.");
            return;
        }
        say("Root folder set: " + shown);
    }

    /**
     * Forgets the declared root.
     *
     * @param ide the IDE controller
     */
    public static void clearRoot(UI_Main ide) {
        if (!RootFolderStore.isDeclared()) {
            say("No root folder is set.");
            return;
        }
        RootFolderStore.clear();
        Path fallback = HomeFilesProject.runRoot();
        say(fallback != null
                ? "Root folder cleared. Open Root Folder now uses the last run folder: " + fallback
                : "Root folder cleared.");
    }

    // =================================================================
    // Path (session addpath)
    // =================================================================

    /**
     * Adds a folder to the path for this session, saying what happened.
     *
     * @param ide    the IDE controller
     * @param folder the folder
     * @return true if it is on the path afterwards
     */
    public static boolean addToPath(UI_Main ide, Path folder) {
        if (!FolderPaths.isFolder(folder)) {
            say("Not a folder: " + folder);
            return false;
        }
        Path canonical = FolderPaths.canonical(folder);
        if (FolderPaths.sameCanonical(canonical, projectFolder(ide))) {
            say("That is the current folder; it is always searched.");
            return false;
        }
        if (SearchPath.contains(canonical)) {
            say("Already on the path: " + canonical);
            return true;
        }
        if (!SearchPath.add(canonical)) {
            say("Could not add to path: " + canonical);
            return false;
        }
        say("Added to path for this session: " + canonical);
        return true;
    }

    /**
     * Asks for a folder and adds it to the path. The chooser starts in the
     * current folder.
     *
     * @param ide the IDE controller
     */
    public static void chooseFolderForPath(UI_Main ide) {
        if (ide == null) {
            return;
        }
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("Add Folder to Path");
        Path start = shownFolder(ide);
        if (FolderPaths.isFolder(start)) {
            chooser.setInitialDirectory(start.toFile());
        }
        File chosen = chooser.showDialog(ide.stage);
        if (chosen != null) {
            addToPath(ide, chosen.toPath());
        }
    }

    /**
     * Removes one folder from the path.
     *
     * @param ide    the IDE controller
     * @param folder the folder
     */
    public static void removeFromPath(UI_Main ide, Path folder) {
        if (SearchPath.remove(folder)) {
            say("Removed from path: " + FolderPaths.canonical(folder));
        } else {
            say("Not on the path: " + folder);
        }
    }

    /**
     * Removes every folder added to the path this session.
     *
     * @param ide the IDE controller
     */
    public static void clearAddedPaths(UI_Main ide) {
        if (SearchPath.clear()) {
            say("Path cleared. Only the current folder is searched now.");
        } else {
            say("No folders have been added to the path.");
        }
    }

    // =================================================================
    // State for the buttons
    // =================================================================

    /**
     * @param ide the IDE controller
     * @return true if Back has somewhere to go
     */
    public static boolean canGoBack(UI_Main ide) {
        return FolderHistory.canGoBack(shownFolder(ide));
    }

    /**
     * @return true if Forward has somewhere to go
     */
    public static boolean canGoForward() {
        return FolderHistory.canGoForward();
    }

    /**
     * @param ide the IDE controller
     * @return true if the folder being shown has a parent
     */
    public static boolean canGoUp(UI_Main ide) {
        Path shown = shownFolder(ide);
        return shown != null && shown.getParent() != null;
    }

    // =================================================================
    // Runs
    // =================================================================

    /**
     * Records a run: adds the project folder to the Back/Forward history,
     * stores it as the fallback root, and puts it at the top of the
     * breadcrumb's run-folder history. Called by {@code EditorFileRunner} once
     * a run is actually going ahead, so a file that fails its error check
     * moves none of them.
     *
     * @param ide        the IDE controller
     * @param fileFolder the running file's own folder, used only when the tree
     *                   has no root
     */
    public static void recordRun(UI_Main ide, Path fileFolder) {
        Path folder = runFolder(ide, fileFolder);
        if (folder == null) {
            return;
        }
        HomeFilesProject.rememberRunRoot(folder);
        FolderHistory.recordRun(folder);
        RunFolderHistory.record(folder);
    }

    /**
     * Records a script run for the breadcrumb's history drop-down only. Used
     * by the Step button (when a step run arms) and by a script typed in the
     * Command Window. Back / Forward and the fallback root are left to the Run
     * button, as before.
     *
     * @param ide        the IDE controller
     * @param fileFolder the script's own folder, used only when the tree has
     *                   no root; may be null
     */
    public static void recordRecentFolder(UI_Main ide, Path fileFolder) {
        Path folder = runFolder(ide, fileFolder);
        if (folder != null) {
            RunFolderHistory.record(folder);
        }
    }

    /** The current folder, else the script's own folder; null if neither exists. */
    private static Path runFolder(UI_Main ide, Path fileFolder) {
        Path folder = projectFolder(ide);
        if (folder == null) {
            folder = FolderPaths.canonical(fileFolder);
        }
        return FolderPaths.isFolder(folder) ? folder : null;
    }

    // =================================================================
    // Messages
    // =================================================================

    /**
     * Prints a one-line note to the Command Window and repaints the prompt.
     *
     * @param message the note, without a trailing newline
     */
    public static void say(String message) {
        CLI_Main.appendOutput(message + "\n");
        CLI_Main.appendPrompt();
    }
}
