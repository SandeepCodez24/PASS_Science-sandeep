package ui.editor.signalTab;

import java.io.InputStream;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import ui.UI_Main;
import ui.explorer.signal.SignalExplorerHost;

/**
 * Set window, opened from the Signals ribbon "Environment" group.
 *
 * <p>
 * Placeholder shell. Will hold the environment settings the rest of the Signals tab runs against.
 * </p>
 *
 * <h3>Apply</h3>
 * <p>
 * The footer's <b>Apply</b> button opens the Signal Explorer at the bottom of
 * the Variable Explorer ({@link SignalExplorerHost#show()}) and closes this
 * window. This is the hook the finished Set window will use once a signal
 * variable has been set up; for now it has nothing to apply, so it only
 * opens the explorer.
 * </p>
 *
 * <p>
 * Self-contained on purpose: the chrome is repeated in each Signals window
 * rather than shared through a factory, because these windows are expected to
 * grow apart rather than together.
 * </p>
 */
public final class UI_Signal_Set_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String FOOTER_GREY = "#d9dcdf";
    private static final String FOOTER_RULE = "#c2c7cc";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";
    private static final String WINDOW_TITLE = "Set";

    private static Stage window;

    private UI_Signal_Set_Main() {
    }

    /**
     * Opens the Set window. If it is already open, the existing window is
     * brought to the front instead of creating a duplicate.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }

        window = new Stage();
        window.setTitle(WINDOW_TITLE);
        window.setResizable(false);
        window.initModality(Modality.NONE);

        applyWindowIcon(window);

        if (ide != null && ide.stage != null) {
            window.initOwner(ide.stage);
        }

        Label title = new Label(WINDOW_TITLE);
        title.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");

        HBox titleBar = new HBox(title);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(9, 14, 9, 14));
        titleBar.setStyle("-fx-background-color: " + NAVY_BLUE + ";");

        Label message = new Label(WINDOW_TITLE + " under development");
        message.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");

        StackPane content = new StackPane(message);
        content.setPadding(new Insets(34, 30, 34, 30));
        content.setMinSize(390, 120);

        // Apply: opens the Signal Explorer under the Variable Explorer.
        Button apply = new Button("Apply");
        apply.setDefaultButton(true);
        apply.setStyle("-fx-font-size: 11.5px; -fx-padding: 2 16 2 16;");
        apply.setOnAction(event -> {
            SignalExplorerHost.show();
            window.close();
        });

        Region footerSpacer = new Region();
        HBox.setHgrow(footerSpacer, Priority.ALWAYS);

        // Light grey footer with a hairline along its top edge, so the strip
        // reads as a footer rather than as unused space below the message.
        HBox footerBar = new HBox(footerSpacer, apply);
        footerBar.setAlignment(Pos.CENTER_RIGHT);
        footerBar.setPadding(new Insets(4, 10, 4, 10));
        footerBar.setMinHeight(36);
        footerBar.setPrefHeight(36);
        footerBar.setStyle(
                "-fx-background-color: " + FOOTER_GREY + ";"
                        + "-fx-border-color: " + FOOTER_RULE + " transparent transparent transparent;"
                        + "-fx-border-width: 1 0 0 0;");

        BorderPane root = new BorderPane();
        root.setTop(titleBar);
        root.setCenter(content);
        root.setBottom(footerBar);

        Scene scene = new Scene(root, 450, 214);
        if (ide != null && ide.stage != null && ide.stage.getScene() != null) {
            scene.getStylesheets().addAll(ide.stage.getScene().getStylesheets());
        }

        window.setScene(scene);
        window.setOnHidden(event -> window = null);
        window.show();
        window.centerOnScreen();
    }

    /**
     * Loads the Neural Code icon from the classpath and applies it to the
     * stage. Failure to load is non-fatal: the window keeps the default icon.
     *
     * @param stage stage to decorate
     */
    private static void applyWindowIcon(Stage stage) {
        try (InputStream in = UI_Signal_Set_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return;
            }
            Image icon = new Image(in);
            if (!icon.isError()) {
                stage.getIcons().add(icon);
            }
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
        }
    }
}
