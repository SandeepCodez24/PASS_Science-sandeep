package ui.editor.folding;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns editor text into the list of foldable regions.
 *
 * <h3>The block table (as specified)</h3>
 *
 * <pre>
 *   if        -&gt; iend        if not     -&gt; iend
 *   while     -&gt; wend        while not  -&gt; wend
 *   for       -&gt; fend
 *   function  -&gt; fend
 *   class     -&gt; cend
 * </pre>
 *
 * The {@code not} variant changes nothing: detection keys off the FIRST word of
 * the line, so {@code if not D == 51:} is still an {@code if} and still closes
 * on {@code iend}.
 *
 * <p>Note that {@code fend} legitimately closes either a {@code for} or a
 * {@code function}. Matching is therefore done with a stack keyed on the
 * EXPECTED TERMINATOR rather than on the opener word, which is what makes the
 * shared {@code fend} unambiguous.
 *
 * <h3>Comment blocks</h3>
 * A run of two or more consecutive lines whose first non-blank characters are
 * {@code \\} folds as one region, starting at the first comment line.
 *
 * <h3>Unclosed blocks</h3>
 * A block with no matching terminator produces NO region, so a half-typed
 * {@code for} never shows a fold marker.
 *
 * <p>This class is pure and side-effect free -- it never touches the editor,
 * which makes it trivially unit-testable.
 */
public final class FoldParser {

    /** Line comment token. In UPI source this is a pair of backslashes. */
    public static final String COMMENT_TOKEN = "\\\\";

    /** Shortest run of comment lines that becomes foldable. */
    private static final int MIN_COMMENT_RUN = 2;

    /** First word of a line, ignoring leading whitespace. */
    private static final Pattern FIRST_WORD = Pattern.compile("^([A-Za-z_][A-Za-z0-9_]*)");

    /** opener keyword -&gt; kind */
    private static final Map<String, FoldRegion.Kind> OPENERS = new HashMap<>();

    /** terminator keyword -&gt; true (fast membership test) */
    private static final Map<String, Boolean> TERMINATORS = new HashMap<>();

    static {
        OPENERS.put("if", FoldRegion.Kind.IF);
        OPENERS.put("for", FoldRegion.Kind.FOR);
        OPENERS.put("while", FoldRegion.Kind.WHILE);
        OPENERS.put("function", FoldRegion.Kind.FUNCTION);
        OPENERS.put("class", FoldRegion.Kind.CLASS);

        TERMINATORS.put("iend", Boolean.TRUE);
        TERMINATORS.put("fend", Boolean.TRUE);
        TERMINATORS.put("wend", Boolean.TRUE);
        TERMINATORS.put("cend", Boolean.TRUE);
    }

    private FoldParser() {
        // Utility class.
    }

    /** One entry of the open-block stack. */
    private static final class Open {
        final int line;
        final FoldRegion.Kind kind;

        Open(int line, FoldRegion.Kind kind) {
            this.line = line;
            this.kind = kind;
        }
    }

    /**
     * Parses the whole document.
     *
     * @param text the editor text (may be null)
     * @return regions sorted by start line, each guaranteed foldable
     */
    public static List<FoldRegion> parse(String text) {
        List<FoldRegion> regions = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return regions;
        }

        String[] lines = text.split("\n", -1);
        Deque<Open> stack = new ArrayDeque<>();

        int commentRunStart = -1;

        for (int i = 0; i < lines.length; i++) {
            String trimmed = stripLine(lines[i]);

            // ---- comment runs -------------------------------------------------
            if (isCommentLine(trimmed)) {
                if (commentRunStart < 0) {
                    commentRunStart = i;
                }
                // A commented-out keyword must never open or close a block.
                continue;
            }
            if (commentRunStart >= 0) {
                addCommentRun(regions, commentRunStart, i - 1);
                commentRunStart = -1;
            }

            // ---- keywords -----------------------------------------------------
            String word = firstWord(trimmed);
            if (word == null) {
                continue;
            }

            if (TERMINATORS.containsKey(word)) {
                closeBlock(regions, stack, word, i);
            } else {
                FoldRegion.Kind kind = OPENERS.get(word);
                if (kind != null) {
                    stack.push(new Open(i, kind));
                }
            }
        }

        // A comment run that reaches the end of the file.
        if (commentRunStart >= 0) {
            addCommentRun(regions, commentRunStart, lines.length - 1);
        }

        // Anything still on the stack is unclosed -> deliberately dropped.
        regions.sort((a, b) -> Integer.compare(a.getStartLine(), b.getStartLine()));
        return regions;
    }

    /**
     * Convenience index for the gutter factory, which asks "does a region start
     * on line N?" once per rendered line.
     *
     * @param regions parsed regions
     * @return map of start line -&gt; region
     */
    public static Map<Integer, FoldRegion> indexByStartLine(List<FoldRegion> regions) {
        Map<Integer, FoldRegion> byStart = new HashMap<>();
        for (FoldRegion region : regions) {
            // If two regions somehow start on the same line, the outer (longer)
            // one wins, because that is the one the marker should toggle.
            FoldRegion existing = byStart.get(region.getStartLine());
            if (existing == null || region.getEndLine() > existing.getEndLine()) {
                byStart.put(region.getStartLine(), region);
            }
        }
        return byStart;
    }

    /* =====================================================================
     * INTERNALS
     * ===================================================================== */

    /**
     * Pops the stack down to the newest block expecting {@code terminator} and
     * emits its region. Blocks skipped over on the way down were never closed,
     * so they are discarded rather than guessed at.
     */
    private static void closeBlock(List<FoldRegion> regions, Deque<Open> stack,
            String terminator, int line) {
        List<Open> skipped = new ArrayList<>();
        while (!stack.isEmpty()) {
            Open open = stack.pop();
            if (open.kind.terminator().equals(terminator)) {
                if (line > open.line) {
                    regions.add(new FoldRegion(open.line, line, open.kind));
                }
                return;
            }
            skipped.add(open);
        }
        // No match at all: the terminator is orphaned. Put back what we popped
        // so a later, correct terminator can still close those blocks.
        for (int i = skipped.size() - 1; i >= 0; i--) {
            stack.push(skipped.get(i));
        }
    }

    private static void addCommentRun(List<FoldRegion> regions, int start, int end) {
        if (end - start + 1 >= MIN_COMMENT_RUN) {
            regions.add(new FoldRegion(start, end, FoldRegion.Kind.COMMENT));
        }
    }

    private static boolean isCommentLine(String trimmed) {
        return trimmed.startsWith(COMMENT_TOKEN);
    }

    private static String stripLine(String raw) {
        String line = raw;
        if (line.endsWith("\r")) {
            line = line.substring(0, line.length() - 1);
        }
        return line.strip();
    }

    private static String firstWord(String trimmed) {
        if (trimmed.isEmpty()) {
            return null;
        }
        Matcher matcher = FIRST_WORD.matcher(trimmed);
        if (!matcher.find()) {
            return null;
        }
        return matcher.group(1).toLowerCase(Locale.ROOT);
    }
}
