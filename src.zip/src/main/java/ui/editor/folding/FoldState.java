package ui.editor.folding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.function.IntFunction;

import javafx.scene.Node;

/**
 * Per-editor folding state. One instance lives in the CodeArea's property map,
 * so nothing is static and multiple tabs never interfere with each other.
 *
 * <h3>Hidden lines are computed once, not per region</h3>
 * {@link #hiddenLines} is the single source of truth for "is this paragraph on
 * screen". It is the UNION of the hidden spans of every collapsed region, which
 * is what makes nesting behave: a block sitting inside a collapsed outer block
 * contributes nothing new, its header is in the union like any other line, and
 * so its marker, its guide and its {@code ...} badge all disappear with the
 * body around it. Nothing anywhere else in the package walks the region list to
 * decide visibility -- they all ask this set.
 *
 * <p>State is intentionally NOT persisted across a save or a tab reopen -- a
 * freshly opened file always starts fully expanded.
 *
 * <p>Package-private: only {@link FoldingManager} touches it.
 */
final class FoldState {

    /**
     * Header lines (zero-based) the user has collapsed. A TreeSet keeps them in
     * document order, which matters when nested folds are re-applied.
     */
    final TreeSet<Integer> collapsedStarts = new TreeSet<>();

    /**
     * Every paragraph currently hidden, derived from {@link #collapsedStarts}
     * by {@link #recomputeHiddenLines()}. Sorted, so
     * {@code FoldingManager.maximalRuns} can walk it straight through.
     */
    final TreeSet<Integer> hiddenLines = new TreeSet<>();

    /**
     * The anchors handed to RichTextFX, as {first, last} pairs where
     * {@code first} is the VISIBLE anchor line and {@code last} is the final
     * hidden paragraph.
     *
     * <p>This is what lets folds be undone precisely. We deliberately do not
     * ask the library which paragraphs it considers folded -- that would mean
     * depending on an internal style class name. Instead we remember exactly
     * what we folded and unfold exactly that.
     */
    final List<int[]> appliedRuns = new ArrayList<>();

    /** Last parse result, cached so the gutter factory does not re-parse per line. */
    List<FoldRegion> regions = Collections.emptyList();

    /** Start line -&gt; region, rebuilt alongside {@link #regions}. */
    Map<Integer, FoldRegion> regionsByStart = new LinkedHashMap<>();

    /** Text the cached parse belongs to. */
    String parsedText = null;

    /** Paragraph count at the last apply, used to detect structural edits. */
    int lastParagraphCount = -1;

    /** The gutter factory, kept so folding can force a re-render of the markers. */
    IntFunction<Node> gutterFactory = null;

    /** Guards against re-entrancy while folds are being applied. */
    boolean applying = false;

    /**
     * Refreshes the cached parse if the text has changed.
     *
     * @param text current editor text
     */
    void reparseIfNeeded(String text) {
        String safe = text == null ? "" : text;
        if (parsedText != null && parsedText.equals(safe)) {
            return;
        }
        parsedText = safe;
        regions = FoldParser.parse(safe);
        regionsByStart = FoldParser.indexByStartLine(regions);
    }

    /**
     * @param line zero-based paragraph index
     * @return the region that starts on this line, or null
     */
    FoldRegion regionStartingAt(int line) {
        return regionsByStart.get(line);
    }

    /**
     * Rebuilds {@link #hiddenLines} from {@link #collapsedStarts}. Call this
     * before anything reads the hidden set.
     */
    void recomputeHiddenLines() {
        hiddenLines.clear();
        for (Integer start : collapsedStarts) {
            FoldRegion region = regionsByStart.get(start);
            if (region == null || !region.isFoldable()) {
                continue;
            }
            for (int line = region.getFirstHiddenLine(); line <= region.getLastHiddenLine(); line++) {
                hiddenLines.add(line);
            }
        }
    }

    /**
     * @param line zero-based paragraph index
     * @return true when this paragraph is inside some collapsed region
     */
    boolean isHidden(int line) {
        return hiddenLines.contains(line);
    }

    /**
     * The collapsed headers that are themselves on screen.
     *
     * <p>An inner block collapsed before its parent was collapsed is still in
     * {@link #collapsedStarts} -- so its state survives and comes back when the
     * parent reopens -- but it must not draw a badge while it is buried. This
     * is the filter that keeps that from happening.
     *
     * @return visible collapsed header lines, in document order
     */
    List<Integer> visibleCollapsedStarts() {
        List<Integer> visible = new ArrayList<>();
        for (Integer start : collapsedStarts) {
            if (!isHidden(start)) {
                visible.add(start);
            }
        }
        return visible;
    }

    /**
     * Walks up from {@code line} to the first paragraph that is on screen. Used
     * to park the caret somewhere the user can see after a collapse.
     *
     * @param line zero-based paragraph index
     * @return the nearest visible line at or above {@code line}
     */
    int nearestVisibleAtOrAbove(int line) {
        int candidate = line;
        while (candidate > 0 && isHidden(candidate)) {
            candidate--;
        }
        return candidate;
    }

    /**
     * Finds the innermost EXPANDED region that spans {@code line}, for drawing
     * the vertical guide. Collapsed regions are skipped, since their body is
     * not on screen to draw a guide beside.
     *
     * @param line zero-based paragraph index
     * @return the tightest enclosing expanded region, or null
     */
    FoldRegion innermostExpandedSpanning(int line) {
        FoldRegion best = null;
        for (FoldRegion region : regions) {
            if (!region.isFoldable() || collapsedStarts.contains(region.getStartLine())) {
                continue;
            }
            if (!region.spans(line)) {
                continue;
            }
            // "Innermost" = the shortest span containing the line.
            if (best == null || region.getHiddenLineCount() < best.getHiddenLineCount()) {
                best = region;
            }
        }
        return best;
    }

    /**
     * Drops collapsed marks that no longer point at a real region -- which is
     * what happens after a structural edit shifts or removes a block.
     *
     * @return true when something was dropped
     */
    boolean pruneStaleCollapsedStarts() {
        return collapsedStarts.removeIf(start -> regionsByStart.get(start) == null);
    }
}
