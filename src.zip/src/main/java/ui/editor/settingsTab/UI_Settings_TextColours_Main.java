package ui.editor.settingsTab;

import java.io.InputStream;
import java.util.Collection;
import java.util.EnumMap;
import java.util.Map;

import org.fxmisc.richtext.model.StyleSpan;
import org.fxmisc.richtext.model.StyleSpans;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Modality;
import javafx.stage.Stage;
import language.syntax.UPITokenMaker;
import language.syntax.textcolours.TextCategory;
import language.syntax.textcolours.TextColourMath;
import ui.UI_Main;
import ui.design.section_dims.TextColours_dim;
import ui.managers.TextColourConfig;
import ui.managers.TextColourManager;
import ui.managers.ThemeManager;

/**
 * Text Colours window, opened from Settings &gt; Visuals &gt; Text Colours
 * (the button that used to be "Theme").
 *
 * <pre>
 *   Text colours - Set Default
 *   +---------------------------------------------------------------------+
 *   | Category        Colour  Light editor   Dark editor   B  I  |  Light  |
 *   | Variables       [###]   count = ;      count = ;     [] [] |  code   |
 *   | Integers ...    [###]   42  3.14       42  3.14      [] [] |         |
 *   | ...one row per category (TextCategory)...                  |  Dark   |
 *   |                                                            |  code   |
 *   |  Reset to factory                  [Preview] [Apply] [Cancel]        |
 *   +---------------------------------------------------------------------+
 * </pre>
 *
 * <h3>One colour per category</h3>
 * <p>
 * The swatch is the only colour the user picks: the colour for a light
 * editor. The Dark column shows the partner the dark editor will use,
 * derived from it ({@link TextColourMath#darkVariant}), so the user sees
 * both before choosing. A category never touched keeps the standard light
 * and dark values from {@code themes/texts/text_light.css} and
 * {@code text_dark.css}.
 * </p>
 *
 * <h3>Bold and italic</h3>
 * <p>
 * Per category, for both editors.
 * </p>
 *
 * <h3>Previews</h3>
 * <p>
 * The two code panes on the right are coloured by the editor's own
 * tokenizer, so they show exactly what the editor will.
 * </p>
 *
 * <h3>Buttons (as in the Custom Layout window)</h3>
 * <ul>
 * <li><b>Preview</b>: shows the choices in the editor; this window stays
 * open; nothing is saved.</li>
 * <li><b>Apply</b>: saves, shows and closes.</li>
 * <li><b>Cancel</b>, Esc or the close button: drops anything previewed.</li>
 * <li><b>Reset to factory</b>: every category back to the standard
 * stylesheets, in this window; saved only by Apply. The {@code ↺} at the end
 * of a row does the same for that row alone.</li>
 * </ul>
 */
public final class UI_Settings_TextColours_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String STRIP_SUBTITLE_INK = "#B9CCE0";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";
    private static final String WINDOW_TITLE = "Text Colours";
    private static final String STRIP_TITLE = "Text colours – Set Default";
    private static final String STRIP_SUBTITLE = "Pick one colour; the dark editor's partner follows";

    private static final String LIGHT_EDITOR = TextColourMath.LIGHT_BACKGROUND;
    private static final String DARK_EDITOR = TextColourMath.DARK_BACKGROUND;

    /** The code shown in the two preview panes. */
    private static final String PREVIEW_CODE = String.join("\n",
            "# area of a circle",
            "function y = area(r):",
            "   y = 3.14 * r^2;",
            "fnend",
            "x = int(logb2(8)) + sqrt(16) + |-2|;",
            "while x <= 10 && is_nan(x) == false:",
            "   publish(\"x = \", area(x));",
            "   if not x != 0:",
            "      break",
            "   iend",
            "   x = x + det(M) + 1e-3;",
            "wend");

    private static Stage window;

    private final Stage stage;
    private final boolean darkTheme;

    /** The values on screen in this window. */
    private TextColourConfig working;

    private boolean previewed;
    private boolean applied;
    /** True while controls are being set from {@link #working}. */
    private boolean syncing;

    private final Map<TextCategory, Button> swatches = new EnumMap<>(TextCategory.class);
    private final Map<TextCategory, StackPane> lightSamples = new EnumMap<>(TextCategory.class);
    private final Map<TextCategory, StackPane> darkSamples = new EnumMap<>(TextCategory.class);
    private final Map<TextCategory, CheckBox> boldBoxes = new EnumMap<>(TextCategory.class);
    private final Map<TextCategory, CheckBox> italicBoxes = new EnumMap<>(TextCategory.class);
    private final Map<TextCategory, Button> resetButtons = new EnumMap<>(TextCategory.class);
    private TextFlow lightPreview;
    private TextFlow darkPreview;

    private UI_Settings_TextColours_Main(Stage stage) {
        this.stage = stage;
        this.working = TextColourManager.saved().copy();
        this.darkTheme = "dark".equalsIgnoreCase(ThemeManager.getActiveTheme());
    }

    /**
     * Opens the window, or brings the open one to the front.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }

        Stage stage = new Stage();
        stage.setTitle(WINDOW_TITLE);
        stage.setResizable(false);
        stage.initModality(Modality.NONE);
        applyWindowIcon(stage);
        if (ide != null && ide.stage != null) {
            stage.initOwner(ide.stage);
        }

        UI_Settings_TextColours_Main view = new UI_Settings_TextColours_Main(stage);
        Scene scene = new Scene(view.build());
        if (ide != null && ide.stage != null && ide.stage.getScene() != null) {
            scene.getStylesheets().setAll(ide.stage.getScene().getStylesheets());
        }
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                view.revert();
                stage.close();
            }
        });
        stage.setScene(scene);

        // The close button behaves like Cancel.
        stage.setOnCloseRequest(e -> view.revert());
        stage.setOnHidden(e -> window = null);

        window = stage;
        stage.sizeToScene();
        stage.show();
        stage.centerOnScreen();
    }

    // =====================================================================
    // Layout
    // =====================================================================

    private BorderPane build() {
        Label title = new Label(STRIP_TITLE);
        title.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label subtitle = new Label(STRIP_SUBTITLE);
        subtitle.setStyle("-fx-text-fill: " + STRIP_SUBTITLE_INK + "; -fx-font-size: 11px;");
        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox strip = new HBox(10, title, gap, subtitle);
        strip.setAlignment(Pos.CENTER_LEFT);
        strip.setPadding(new Insets(TextColours_dim.TITLE_PAD_V, TextColours_dim.TITLE_PAD_H,
                TextColours_dim.TITLE_PAD_V, TextColours_dim.TITLE_PAD_H));
        strip.setStyle("-fx-background-color: " + NAVY_BLUE + ";");

        VBox left = new VBox(14, grid(), buttonRow());
        HBox columns = new HBox(TextColours_dim.COLUMN_GAP, left, previews());
        columns.setPadding(new Insets(TextColours_dim.BODY_PADDING));

        Label hint = new Label("Standard colours: themes/texts/text_light.css and text_dark.css");
        hint.setStyle("-fx-font-size: 11px; -fx-text-fill: " + (darkTheme ? "#A4ACB5" : "#5B6672") + ";");
        HBox footer = new HBox(hint);
        footer.setAlignment(Pos.CENTER_LEFT);
        footer.setPadding(new Insets(0, TextColours_dim.FOOTER_PAD_H, 0, TextColours_dim.FOOTER_PAD_H));
        footer.setMinHeight(TextColours_dim.FOOTER_HEIGHT);
        footer.setPrefHeight(TextColours_dim.FOOTER_HEIGHT);
        footer.setStyle("-fx-background-color: " + (darkTheme ? "#232427" : "#D9DCDF") + ";"
                + "-fx-border-color: " + (darkTheme ? "#3A3D41" : "#C2C7CC")
                + " transparent transparent transparent; -fx-border-width: 1 0 0 0;");

        BorderPane root = new BorderPane();
        root.setTop(strip);
        root.setCenter(columns);
        root.setBottom(footer);
        root.setStyle("-fx-background-color: " + (darkTheme ? "#2B2D30" : "#FFFFFF") + ";");

        refreshControls();
        return root;
    }

    /** One row per category. */
    private GridPane grid() {
        GridPane grid = new GridPane();
        grid.setHgap(TextColours_dim.GRID_HGAP);
        grid.setVgap(TextColours_dim.GRID_VGAP);

        grid.add(header("Category", Pos.CENTER_LEFT), 0, 0);
        grid.add(header("Colour", Pos.CENTER), 1, 0);
        grid.add(header("Light editor", Pos.CENTER), 2, 0);
        grid.add(header("Dark editor", Pos.CENTER), 3, 0);
        grid.add(header("B", Pos.CENTER), 4, 0);
        grid.add(header("I", Pos.CENTER), 5, 0);

        int row = 1;
        for (TextCategory c : TextCategory.values()) {
            Label name = new Label(c.label());
            name.setMinWidth(TextColours_dim.LABEL_WIDTH);
            name.setPrefWidth(TextColours_dim.LABEL_WIDTH);
            name.setMinHeight(TextColours_dim.ROW_HEIGHT);
            name.setTooltip(new Tooltip(c.description()));
            name.setStyle("-fx-text-fill: " + ink() + ";");

            Button swatch = new Button();
            swatch.setMinSize(TextColours_dim.SWATCH_WIDTH, TextColours_dim.ROW_HEIGHT);
            swatch.setPrefSize(TextColours_dim.SWATCH_WIDTH, TextColours_dim.ROW_HEIGHT);
            swatch.setMaxSize(TextColours_dim.SWATCH_WIDTH, TextColours_dim.ROW_HEIGHT);
            swatch.setFocusTraversable(false);
            swatch.setOnAction(e -> pick(c));
            swatches.put(c, swatch);

            StackPane light = sampleCell(LIGHT_EDITOR);
            StackPane dark = sampleCell(DARK_EDITOR);
            lightSamples.put(c, light);
            darkSamples.put(c, dark);

            CheckBox bold = new CheckBox();
            bold.setTooltip(new Tooltip(c.label() + ": bold"));
            bold.selectedProperty().addListener((obs, was, isNow) -> {
                if (!syncing) {
                    working.setBold(c, isNow);
                    refreshControls();
                }
            });
            boldBoxes.put(c, bold);

            CheckBox italic = new CheckBox();
            italic.setTooltip(new Tooltip(c.label() + ": italic"));
            italic.selectedProperty().addListener((obs, was, isNow) -> {
                if (!syncing) {
                    working.setItalic(c, isNow);
                    refreshControls();
                }
            });
            italicBoxes.put(c, italic);

            Button reset = new Button("↺");
            reset.setMinSize(TextColours_dim.RESET_SIZE, TextColours_dim.RESET_SIZE);
            reset.setPrefSize(TextColours_dim.RESET_SIZE, TextColours_dim.RESET_SIZE);
            reset.setPadding(Insets.EMPTY);
            reset.setFocusTraversable(false);
            reset.setTooltip(new Tooltip("Back to the standard " + c.label().toLowerCase() + " colour"));
            reset.setOnAction(e -> {
                working.reset(c);
                refreshControls();
            });
            resetButtons.put(c, reset);

            grid.add(name, 0, row);
            grid.add(swatch, 1, row);
            grid.add(light, 2, row);
            grid.add(dark, 3, row);
            grid.add(centred(bold), 4, row);
            grid.add(centred(italic), 5, row);
            grid.add(reset, 6, row);
            row++;
        }
        return grid;
    }

    /** Reset to factory on the left, Preview / Apply / Cancel on the right. */
    private HBox buttonRow() {
        Button factory = new Button("Reset to factory");
        factory.setTooltip(new Tooltip("""
                Every category back to the standard colours.
                Saved only when you press Apply."""));
        factory.setOnAction(e -> {
            working = TextColourConfig.factory();
            refreshControls();
        });

        Button preview = action("Preview", "Show these colours in the editor; keep this window open");
        preview.setOnAction(e -> preview());
        Button apply = action("Apply", "Save these colours and close");
        apply.setDefaultButton(true);
        apply.setOnAction(e -> apply());
        Button cancel = action("Cancel", "Undo anything previewed and close");
        cancel.setOnAction(e -> {
            revert();
            stage.close();
        });

        Region gap = new Region();
        HBox.setHgrow(gap, Priority.ALWAYS);
        HBox row = new HBox(TextColours_dim.BUTTON_GAP, factory, gap, preview, apply, cancel);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    /** The two code panes, light editor over dark editor. */
    private VBox previews() {
        lightPreview = new TextFlow();
        darkPreview = new TextFlow();
        VBox box = new VBox(TextColours_dim.PREVIEW_GAP,
                header("Preview", Pos.CENTER_LEFT),
                previewPane("Light editor", LIGHT_EDITOR, lightPreview),
                previewPane("Dark editor", DARK_EDITOR, darkPreview));
        box.setPrefWidth(TextColours_dim.PREVIEW_WIDTH);
        box.setMinWidth(TextColours_dim.PREVIEW_WIDTH);
        return box;
    }

    private VBox previewPane(String caption, String background, TextFlow flow) {
        Label label = new Label(caption);
        label.setStyle("-fx-font-size: 11px; -fx-text-fill: " + muted() + ";");
        StackPane pane = new StackPane(flow);
        pane.setAlignment(Pos.TOP_LEFT);
        pane.setPadding(new Insets(TextColours_dim.PREVIEW_PAD));
        pane.setStyle("-fx-background-color: " + background + ";"
                + " -fx-background-radius: " + TextColours_dim.PREVIEW_RADIUS + ";"
                + " -fx-border-color: " + (darkTheme ? "#3E4247" : "#C9CED4") + ";"
                + " -fx-border-radius: " + TextColours_dim.PREVIEW_RADIUS + ";");
        VBox.setVgrow(pane, Priority.ALWAYS);
        VBox box = new VBox(3, label, pane);
        VBox.setVgrow(box, Priority.ALWAYS);
        return box;
    }

    private StackPane sampleCell(String background) {
        StackPane cell = new StackPane();
        cell.setAlignment(Pos.CENTER_LEFT);
        cell.setPadding(new Insets(0, TextColours_dim.SAMPLE_PAD_H, 0, TextColours_dim.SAMPLE_PAD_H));
        cell.setMinSize(TextColours_dim.SAMPLE_WIDTH, TextColours_dim.ROW_HEIGHT);
        cell.setPrefSize(TextColours_dim.SAMPLE_WIDTH, TextColours_dim.ROW_HEIGHT);
        cell.setMaxSize(TextColours_dim.SAMPLE_WIDTH, TextColours_dim.ROW_HEIGHT);
        cell.setStyle("-fx-background-color: " + background + ";"
                + " -fx-border-color: " + (darkTheme ? "#3E4247" : "#C9CED4") + ";");
        // A sample wider than the cell is cut at the cell's edge instead of
        // spilling over the next column (a StackPane does not clip by itself).
        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(cell.widthProperty());
        clip.heightProperty().bind(cell.heightProperty());
        cell.setClip(clip);
        return cell;
    }

    private Label header(String text, Pos alignment) {
        Label label = new Label(text);
        label.setMaxWidth(Double.MAX_VALUE);
        label.setAlignment(alignment);
        label.setStyle("-fx-font-weight: bold; -fx-text-fill: " + (darkTheme ? "#8CB8E8" : "#1A4F8B") + ";");
        return label;
    }

    private static HBox centred(CheckBox box) {
        HBox wrap = new HBox(box);
        wrap.setAlignment(Pos.CENTER);
        return wrap;
    }

    private static Button action(String text, String tip) {
        Button b = new Button(text);
        b.setMinWidth(TextColours_dim.BUTTON_WIDTH);
        b.setPrefWidth(TextColours_dim.BUTTON_WIDTH);
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    // =====================================================================
    // Values <-> controls
    // =====================================================================

    /** Shows {@link #working} in every control and both previews. */
    private void refreshControls() {
        syncing = true;
        try {
            for (TextCategory c : TextCategory.values()) {
                String light = working.lightHex(c);
                String dark = working.darkHex(c);
                Button swatch = swatches.get(c);
                if (swatch != null) {
                    swatch.setStyle("-fx-background-color: " + light + ";"
                            + " -fx-background-radius: 0; -fx-border-color: #2B2B2B; -fx-border-width: 1;"
                            + " -fx-cursor: hand;");
                    swatch.setTooltip(new Tooltip(c.label() + "\nLight " + light + "   Dark " + dark
                            + (working.isChanged(c) ? "   (your choice)" : "   (standard)")
                            + "\nClick to change"));
                }
                fillSample(lightSamples.get(c), c, false);
                fillSample(darkSamples.get(c), c, true);
                if (boldBoxes.get(c) != null) {
                    boldBoxes.get(c).setSelected(working.bold(c));
                    italicBoxes.get(c).setSelected(working.italic(c));
                    resetButtons.get(c).setDisable(!working.isChanged(c));
                }
            }
            paintPreview(lightPreview, false);
            paintPreview(darkPreview, true);
        } finally {
            syncing = false;
        }
    }

    private void fillSample(StackPane cell, TextCategory c, boolean dark) {
        if (cell == null) {
            return;
        }
        Text text = new Text(c.sample());
        text.setFill(Color.web(working.hex(c, dark)));
        text.setFont(codeFont(c));
        cell.getChildren().setAll(text);
    }

    /** Colours the preview code with the editor's own tokenizer. */
    private void paintPreview(TextFlow flow, boolean dark) {
        if (flow == null) {
            return;
        }
        flow.getChildren().clear();
        StyleSpans<Collection<String>> spans = UPITokenMaker.computeHighlighting(PREVIEW_CODE);
        int at = 0;
        for (StyleSpan<Collection<String>> span : spans) {
            int end = Math.min(PREVIEW_CODE.length(), at + span.getLength());
            if (end <= at) {
                continue;
            }
            TextCategory c = categoryOf(span.getStyle());
            Text piece = new Text(PREVIEW_CODE.substring(at, end));
            piece.setFill(Color.web(working.hex(c, dark)));
            piece.setFont(codeFont(c));
            flow.getChildren().add(piece);
            at = end;
        }
    }

    private Font codeFont(TextCategory c) {
        return Font.font(TextColours_dim.CODE_FAMILY,
                working.bold(c) ? FontWeight.BOLD : FontWeight.NORMAL,
                working.italic(c) ? FontPosture.ITALIC : FontPosture.REGULAR,
                TextColours_dim.CODE_FONT);
    }

    private static TextCategory categoryOf(Collection<String> classes) {
        for (String cls : classes) {
            TextCategory c = TextCategory.fromStyleClass(cls);
            if (c != null) {
                return c;
            }
        }
        return TextCategory.VARIABLE;
    }

    private void pick(TextCategory c) {
        Color picked = CustomColorDialog.pick(stage, c.label(), Color.web(working.lightHex(c)));
        if (picked != null) {
            working.setColour(c, CustomColorDialog.hex(picked));
            refreshControls();
        }
    }

    private String ink() {
        return darkTheme ? "#E4E7EB" : "#1E2A36";
    }

    private String muted() {
        return darkTheme ? "#A4ACB5" : "#5B6672";
    }

    // =====================================================================
    // Preview / Apply / Cancel
    // =====================================================================

    private void preview() {
        previewed = true;
        TextColourManager.setPreview(working);
        TextColourManager.refresh();
    }

    private void apply() {
        applied = true;
        TextColourManager.save(working);
        TextColourManager.setPreview(null);
        TextColourManager.refresh();
        stage.close();
    }

    /** Drops the preview. Nothing to do after Apply or if nothing was previewed. */
    private void revert() {
        if (applied || !previewed) {
            return;
        }
        previewed = false;
        TextColourManager.setPreview(null);
        TextColourManager.refresh();
    }

    private static void applyWindowIcon(Stage stage) {
        try (InputStream in = UI_Settings_TextColours_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return;
            }
            Image icon = new Image(in);
            if (!icon.isError()) {
                stage.getIcons().add(icon);
            }
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
        }
    }
}
