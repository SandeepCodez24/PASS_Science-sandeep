package ui.editor.settingsTab;

import java.util.Locale;

import javafx.beans.binding.Bindings;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import ui.design.Dim;

/**
 * The colour picker of the Custom Layout window: the standard palette, then
 * HSB / RGB / Web tabs, then the Current and New previews with the hex code,
 * and OK / Cancel. Modelled on the plot window's Colors dialog
 * ({@code plot.PlotColorEditor}).
 *
 * <h3>Differences from the plot dialog</h3>
 * <ul>
 * <li><b>Cancel cancels.</b> {@link #pick} returns null on Cancel or on the
 * window's close button; the plot dialog returned the colour clicked
 * last.</li>
 * <li><b>Current is the colour the dialog opened with</b>, and New is the
 * one being chosen, so the two can be compared.</li>
 * <li><b>The tabs stay in step.</b> Clicking a swatch, moving an HSB slider,
 * an RGB slider or typing a hex code moves all the other controls with it.
 * </li>
 * <li><b>No opacity.</b> These are panel backgrounds, which are always
 * opaque.</li>
 * <li>Only the standard palette (no Custom or UPI pages).</li>
 * </ul>
 * <p>
 * Self-contained on purpose, like the other Settings windows: it shares no
 * code with the plot package, so the two can grow apart.
 * </p>
 */
public final class CustomColorDialog {

    private static final Color[] PALETTE = {
            Color.web("#1f77b4"), Color.web("#2ca02c"), Color.web("#d62728"), Color.web("#ff7f0e"),
            Color.web("#9467bd"), Color.web("#17becf"), Color.web("#8c564b"), Color.web("#7f7f7f"),
            Color.web("#bcbd22"), Color.web("#e377c2"), Color.web("#0aa6a6"), Color.web("#264653"),
            Color.web("#FF6B6B"), Color.web("#F06595"), Color.web("#CC5DE8"), Color.web("#845EF7"),
            Color.web("#5C7CFA"), Color.web("#339AF0"), Color.web("#22B8CF"), Color.web("#20C997"),
            Color.web("#51CF66"), Color.web("#94D82D"), Color.web("#FCC419"), Color.web("#FF922B"),
            Color.web("#E8590C"), Color.web("#CED4DA"), Color.web("#ADB5BD"), Color.web("#868E96"),
            Color.web("#495057"), Color.web("#343A40"), Color.web("#212529"), Color.web("#000000"),
            Color.web("#ffffff")
    };

    private CustomColorDialog() {
    }

    /**
     * Shows the dialog and waits for the user.
     *
     * @param owner   the window it belongs to
     * @param what    what is being coloured, for the title ("Editor Tab - Dark")
     * @param initial the colour it opens with
     * @return the chosen colour, or null if the user cancelled
     */
    public static Color pick(Window owner, String what, Color initial) {
        Color start = initial == null ? Color.WHITE : initial;
        ObjectProperty<Color> chosen = new SimpleObjectProperty<>(start);
        Object[] source = { null };

        // ---- palette + tabs, scrolling --------------------------------------
        FlowPane swatches = new FlowPane(Dim.CustomLayout.PALETTE_GAP, Dim.CustomLayout.PALETTE_GAP);
        swatches.setPrefWrapLength(Dim.CustomLayout.PALETTE_WRAP);
        swatches.setPadding(new Insets(Dim.CustomLayout.PALETTE_GAP));
        for (Color color : PALETTE) {
            swatches.getChildren().add(swatch(color, chosen));
        }

        TabPane tabs = new TabPane(
                new Tab("HSB", hsbTab(chosen, source)),
                new Tab("RGB", rgbTab(chosen, source)),
                new Tab("Web", webTab(chosen)));
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        VBox scrolled = new VBox(8, new Label("Standard palette"), swatches, tabs);
        scrolled.setPadding(new Insets(8));
        scrolled.getStyleClass().add("color-panel-content");

        ScrollPane scroll = new ScrollPane(scrolled);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scroll.setPrefViewportHeight(Dim.CustomLayout.DIALOG_SCROLL_HEIGHT);
        scroll.getStyleClass().add("color-palette-scroll");
        VBox.setVgrow(scroll, Priority.ALWAYS);

        // ---- Current / New ---------------------------------------------------
        Rectangle current = preview(start);
        Rectangle next = preview(start);
        next.fillProperty().bind(chosen);

        VBox currentBox = new VBox(4, new Label("Current"), current);
        currentBox.setAlignment(Pos.CENTER);
        VBox nextBox = new VBox(4, new Label("New"), next);
        nextBox.setAlignment(Pos.CENTER);
        HBox previews = new HBox(10, currentBox, nextBox);
        previews.setAlignment(Pos.CENTER);

        Label hex = new Label();
        hex.textProperty().bind(Bindings.createStringBinding(() -> hex(chosen.get()), chosen));
        VBox previewArea = new VBox(4, previews, hex);
        previewArea.setAlignment(Pos.CENTER);

        // ---- OK / Cancel ---------------------------------------------------
        Color[] result = { null };
        Button ok = new Button("OK");
        Button cancel = new Button("Cancel");
        ok.setDefaultButton(true);
        cancel.setCancelButton(true);
        HBox actions = new HBox(8, ok, cancel);
        actions.setAlignment(Pos.CENTER_RIGHT);

        VBox root = new VBox(8, scroll, previewArea, actions);
        root.setPadding(new Insets(10));
        root.getStyleClass().add("color-dialog-box");

        Stage dialog = new Stage();
        dialog.setTitle(what == null || what.isBlank() ? "Colors" : "Colors - " + what);
        dialog.initModality(Modality.APPLICATION_MODAL);
        if (owner != null) {
            dialog.initOwner(owner);
        }
        Scene scene = new Scene(root, Dim.CustomLayout.DIALOG_WIDTH, Dim.CustomLayout.DIALOG_HEIGHT);
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().addAll(owner.getScene().getStylesheets());
        }
        dialog.setScene(scene);
        if (owner instanceof Stage stage && !stage.getIcons().isEmpty()) {
            dialog.getIcons().addAll(stage.getIcons());
        }

        ok.setOnAction(e -> {
            result[0] = chosen.get();
            dialog.close();
        });
        cancel.setOnAction(e -> dialog.close());

        dialog.showAndWait();
        return result[0];
    }

    // =====================================================================
    // Palette
    // =====================================================================

    private static Button swatch(Color color, ObjectProperty<Color> chosen) {
        double s = Dim.CustomLayout.PALETTE_SWATCH;
        Button b = new Button();
        b.setMinSize(s, s);
        b.setPrefSize(s, s);
        b.setMaxSize(s, s);
        b.setFocusTraversable(false);
        b.setStyle("-fx-background-color: " + hex(color) + ";"
                + " -fx-background-radius: 6; -fx-border-radius: 6;"
                + " -fx-border-color: rgba(0,0,0,0.18);");
        b.getStyleClass().add("palette-swatch");
        b.setOnAction(e -> chosen.set(color));
        return b;
    }

    private static Rectangle preview(Color fill) {
        Rectangle r = new Rectangle(Dim.CustomLayout.PREVIEW_WIDTH, Dim.CustomLayout.PREVIEW_HEIGHT, fill);
        r.setArcWidth(Dim.CustomLayout.PREVIEW_RADIUS);
        r.setArcHeight(Dim.CustomLayout.PREVIEW_RADIUS);
        r.setStroke(Color.rgb(0, 0, 0, 0.25));
        r.getStyleClass().add("color-preview-rect");
        return r;
    }

    // =====================================================================
    // HSB / RGB / Web
    // =====================================================================

    /**
     * HSB sliders. A tab that changed the colour is the "source" and ignores
     * the echo, so a grey's hue (undefined) is not snapped back to 0 while
     * the user drags saturation.
     */
    private static VBox hsbTab(ObjectProperty<Color> chosen, Object[] source) {
        Color c = chosen.get();
        Channel hue = new Channel(0, 360, c.getHue());
        Channel sat = new Channel(0, 100, c.getSaturation() * 100);
        Channel bri = new Channel(0, 100, c.getBrightness() * 100);
        Object me = new Object();
        boolean[] syncing = { false };

        Runnable push = () -> {
            if (syncing[0]) {
                return;
            }
            source[0] = me;
            chosen.set(Color.hsb(hue.value(), sat.value() / 100.0, bri.value() / 100.0));
            source[0] = null;
        };
        hue.onChange(push);
        sat.onChange(push);
        bri.onChange(push);

        chosen.addListener((obs, was, isNow) -> {
            if (source[0] == me || isNow == null) {
                return;
            }
            syncing[0] = true;
            hue.set(isNow.getHue());
            sat.set(isNow.getSaturation() * 100);
            bri.set(isNow.getBrightness() * 100);
            syncing[0] = false;
        });

        return tab("Standard HSB",
                hue.row("Hue:", "deg"),
                sat.row("Saturation:", "%"),
                bri.row("Brightness:", "%"));
    }

    private static VBox rgbTab(ObjectProperty<Color> chosen, Object[] source) {
        Color c = chosen.get();
        Channel red = new Channel(0, 255, c.getRed() * 255);
        Channel green = new Channel(0, 255, c.getGreen() * 255);
        Channel blue = new Channel(0, 255, c.getBlue() * 255);
        Object me = new Object();
        boolean[] syncing = { false };

        Runnable push = () -> {
            if (syncing[0]) {
                return;
            }
            source[0] = me;
            chosen.set(Color.rgb((int) Math.round(red.value()), (int) Math.round(green.value()),
                    (int) Math.round(blue.value())));
            source[0] = null;
        };
        red.onChange(push);
        green.onChange(push);
        blue.onChange(push);

        chosen.addListener((obs, was, isNow) -> {
            if (source[0] == me || isNow == null) {
                return;
            }
            syncing[0] = true;
            red.set(isNow.getRed() * 255);
            green.set(isNow.getGreen() * 255);
            blue.set(isNow.getBlue() * 255);
            syncing[0] = false;
        });

        return tab("Standard RGB",
                red.row("Red:", ""),
                green.row("Green:", ""),
                blue.row("Blue:", ""));
    }

    private static VBox webTab(ObjectProperty<Color> chosen) {
        TextField field = new TextField(hex(chosen.get()));
        field.setPrefWidth(Dim.CustomLayout.HEX_FIELD_WIDTH);
        Label helper = new Label("Use #RRGGBB, then Enter.");
        helper.getStyleClass().add("color-helper");

        Runnable applyWeb = () -> {
            String text = field.getText() == null ? "" : field.getText().trim();
            if (!text.startsWith("#")) {
                text = "#" + text;
            }
            try {
                chosen.set(Color.web(text));
            } catch (IllegalArgumentException ex) {
                field.setText(hex(chosen.get()));
            }
        };
        field.setOnAction(e -> applyWeb.run());
        Button apply = new Button("Apply Web Color");
        apply.setOnAction(e -> applyWeb.run());

        chosen.addListener((obs, was, isNow) -> {
            if (isNow != null && !field.isFocused()) {
                field.setText(hex(isNow));
            }
        });

        HBox row = new HBox(8, new Label("Web:"), field);
        row.setAlignment(Pos.CENTER_LEFT);
        return tab("Standard Web", row, apply, helper);
    }

    private static VBox tab(String title, Region... rows) {
        VBox box = new VBox(4);
        box.getChildren().add(new Label(title));
        box.getChildren().addAll(rows);
        box.setPadding(new Insets(6, 4, 4, 4));
        return box;
    }

    /** A slider with a number field beside it, kept in step. */
    private static final class Channel {

        private final Slider slider;
        private final TextField field;
        private final double min;
        private final double max;

        Channel(double min, double max, double value) {
            this.min = min;
            this.max = max;
            slider = new Slider(min, max, clamp(value));
            field = new TextField(text(slider.getValue()));
            slider.valueProperty().addListener((obs, was, isNow) -> field.setText(text(isNow.doubleValue())));
            field.setOnAction(e -> commitField());
            field.focusedProperty().addListener((obs, had, has) -> {
                if (!has) {
                    commitField();
                }
            });
        }

        double value() {
            return slider.getValue();
        }

        void set(double value) {
            slider.setValue(clamp(value));
        }

        void onChange(Runnable action) {
            slider.valueProperty().addListener((obs, was, isNow) -> action.run());
        }

        HBox row(String label, String unit) {
            Label name = new Label(label);
            name.setMinWidth(Dim.CustomLayout.CHANNEL_LABEL_WIDTH);
            slider.setPrefWidth(Dim.CustomLayout.CHANNEL_SLIDER_WIDTH);
            slider.setMinWidth(Dim.CustomLayout.CHANNEL_SLIDER_WIDTH);
            field.setPrefWidth(Dim.CustomLayout.CHANNEL_FIELD_WIDTH);
            field.setMaxWidth(Dim.CustomLayout.CHANNEL_FIELD_WIDTH);
            Label units = new Label(unit);
            units.setMinWidth(Dim.CustomLayout.CHANNEL_UNIT_WIDTH);
            HBox row = new HBox(5, name, slider, field, units);
            row.setAlignment(Pos.CENTER_LEFT);
            return row;
        }

        private void commitField() {
            try {
                slider.setValue(clamp(Double.parseDouble(field.getText().trim())));
            } catch (NumberFormatException | NullPointerException ex) {
                field.setText(text(slider.getValue()));
            }
        }

        private double clamp(double v) {
            return Math.max(min, Math.min(max, v));
        }

        private static String text(double v) {
            return String.valueOf((int) Math.round(v));
        }
    }

    static String hex(Color c) {
        return String.format(Locale.ROOT, "#%02X%02X%02X",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255));
    }
}
