package ui.editor.settingsTab;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import ui.UI_Main;
import ui.design.Dim;
import ui.design.Typography;
import ui.layout.LayoutManager;
import ui.layout.WindowLayout;
import ui.layout.custom.CustomLayoutConfig;
import ui.layout.custom.CustomLayoutConfig.Panel;
import ui.managers.ThemeManager;
import ui.ribbon_interface.tool_bar.LayoutRibbon;

/**
 * Custom Layout window, opened from the Custom tile on the Settings &gt;
 * Layout band.
 *
 * <pre>
 *   [NC] Custom Layout                                                  [x]
 *   Custom layout - Set Default
 *   +------------------------------------------------------------------------+
 *   | Layout               Panels          Light  Dark   Base Color [##]      |
 *   | (o) Custom           [x] Editor Tab  [##]   [##]                         |
 *   | ( ) Default          [x] Directory   [##]   [##]   Default Theme         |
 *   | ( ) Bot Centered     [x] CLI         [##]   [##]    (o) Light            |
 *   | ( ) Editor-CLI       [x] Variables   [##]   [##]    ( ) Dark             |
 *   | ( ) Directory Cent.  [x] Chat Bot    [##]   [##]   Panel Order           |
 *   | ( ) Editor-Bot-CLI                                 [<-> Swap sides]     |
 *   |                                                    Font Size [ 12 ^v]  |
 *   |                                     Reset to factory                   |
 *   |                                     [Preview] [Apply] [Cancel]          |
 *   +------------------------------------------------------------------------+
 * </pre>
 *
 * <h3>The window</h3>
 * <p>
 * Square corners: the window draws its own title bar (icon, title, close)
 * instead of the operating system's, which Windows 11 rounds. It is dragged
 * by its title bar or the coloured strip under it.
 * </p>
 *
 * <h3>Layout list</h3>
 * <p>
 * Picks which layout's colours the grid and the Base Color box edit. A
 * standard layout shows its colours once any of them differs from factory;
 * untouched, it keeps the theme's own look. Custom always uses its own.
 * </p>
 *
 * <h3>Panel grid</h3>
 * <ul>
 * <li><b>Tick</b> (Custom only) -- the panel is part of the Custom layout.
 * 1 ticked fills the window, 2 sit side by side 50 / 50, 3 to 5 keep
 * Default's columns. While a standard layout is being edited the ticks are
 * greyed and show which panels that layout has.</li>
 * <li><b>Light / Dark box</b> -- the panel's body colour in that theme.</li>
 * </ul>
 * <p>
 * The Signal Explorer has no row: it is part of the Variable Explorer and
 * takes its colours.
 * </p>
 *
 * <h3>Right column</h3>
 * <ul>
 * <li><b>Base Color</b> -- the active title strip of the layout edited.</li>
 * <li><b>Default Theme</b> (Custom only) -- the theme Custom uses.</li>
 * <li><b>Swap sides</b> (Custom only, 2 to 4 panels) -- mirrors the Custom
 * layout left to right.</li>
 * <li><b>Font Size</b> (all layouts) -- the one UI font size: every panel,
 * the ribbon, the footer, menus and dialogs, from
 * {@link Typography#UI_FONT_SIZE_MIN} to {@link Typography#UI_FONT_SIZE_MAX}.
 * The editor and the Command Window keep their own code size. Preview shows
 * it at once, Apply keeps it, Cancel puts back the size the window opened
 * with -- no restart either way.</li>
 * </ul>
 *
 * <h3>Buttons</h3>
 * <ul>
 * <li><b>Preview</b> -- shows the layout being edited with these choices,
 * and keeps this window open. Nothing is saved.</li>
 * <li><b>Apply</b> -- saves, shows the layout being edited, closes.</li>
 * <li><b>Cancel</b> (or the close mark, or Esc) -- drops anything previewed
 * and puts back the layout and theme that were on screen when the window
 * opened.</li>
 * <li><b>Reset to factory</b> -- factory values into this window; saved only
 * by Apply.</li>
 * </ul>
 * <p>
 * Preview and Apply are greyed while no Custom panel is ticked.
 * </p>
 */
public final class UI_Settings_CustomLayout_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String HEADER_BLUE = "#1a4f8b";
    private static final String HEADER_BLUE_DARK = "#8fb5de";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";
    private static final String WINDOW_TITLE = "Custom Layout";
    private static final String STRIP_TITLE = "Custom layout \u2013 Set Default";

    /** The panels each standard layout has, shown greyed while it is edited. */
    private static final Map<WindowLayout, Set<Panel>> LAYOUT_PANELS = new EnumMap<>(WindowLayout.class);

    static {
        LAYOUT_PANELS.put(WindowLayout.DEFAULT, EnumSet.allOf(Panel.class));
        LAYOUT_PANELS.put(WindowLayout.BOT_CENTERED, EnumSet.of(Panel.EDITOR, Panel.VARIABLES, Panel.CHAT_BOT));
        LAYOUT_PANELS.put(WindowLayout.EDITOR_CLI, EnumSet.of(Panel.EDITOR, Panel.CLI));
        LAYOUT_PANELS.put(WindowLayout.DIRECTORY_CENTERED, EnumSet.of(Panel.DIRECTORY, Panel.EDITOR, Panel.CLI));
        LAYOUT_PANELS.put(WindowLayout.EDITOR_BOT_CLI, EnumSet.of(Panel.EDITOR, Panel.CHAT_BOT, Panel.CLI));
    }

    private static Stage window;

    private final UI_Main ide;
    private final Stage stage;
    private final Image icon;

    /** The values on screen in this window. */
    private CustomLayoutConfig working;

    /** The layout whose colours the grid edits. */
    private WindowLayout editing = WindowLayout.CUSTOM;

    /** The theme, layout and font size in force when the window opened, for Cancel. */
    private final String themeAtOpen;
    private final WindowLayout layoutAtOpen;
    private final double fontSizeAtOpen;
    private final boolean plainStandardAtOpen;

    private boolean previewed;
    private boolean applied;

    /** True while controls are being filled from {@link #working}. */
    private boolean updating;

    private final Map<Panel, CheckBox> ticks = new EnumMap<>(Panel.class);
    private final Map<Panel, Button> lightBoxes = new EnumMap<>(Panel.class);
    private final Map<Panel, Button> darkBoxes = new EnumMap<>(Panel.class);
    private final Map<WindowLayout, RadioButton> editRadios = new EnumMap<>(WindowLayout.class);
    private final List<Label> headers = new ArrayList<>();

    /** Reset to factory, Preview, Apply, Cancel: outlined like Swap sides. */
    private final List<Button> outlined = new ArrayList<>();

    private Button baseBox;
    private HBox titleBar;
    private Label titleLabel;
    private RadioButton lightTheme;
    private RadioButton darkTheme;
    private ToggleButton swap;
    private Spinner<Integer> fontSize;
    private Label panelsHeader;
    private Label hint;
    private Button previewButton;
    private Button applyButton;

    private BorderPane frame;
    private HBox chromeBar;
    private Label chromeTitle;
    private Button chromeClose;
    private HBox footerBar;

    private UI_Settings_CustomLayout_Main(UI_Main ide, Stage stage, Image icon) {
        this.ide = ide;
        this.stage = stage;
        this.icon = icon;
        this.working = CustomLayoutConfig.saved().copy();
        this.themeAtOpen = ThemeManager.getActiveTheme();
        WindowLayout current = LayoutManager.current();
        this.layoutAtOpen = current == null ? WindowLayout.CUSTOM : current;
        this.fontSizeAtOpen = Typography.uiFontSize();
        this.plainStandardAtOpen = CustomLayoutConfig.isPlainStandard();
    }

    /**
     * Opens the Custom Layout window. If it is already open, the existing
     * window is brought to the front instead.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }

        // Undecorated (transparent) so the corners are square: Windows 11
        // rounds every window that has a system title bar.
        Stage stage = new Stage(StageStyle.TRANSPARENT);
        stage.setTitle(WINDOW_TITLE);
        stage.setResizable(false);
        stage.initModality(Modality.NONE);
        Image icon = loadIcon();
        if (icon != null) {
            stage.getIcons().add(icon);
        }
        if (ide != null && ide.stage != null) {
            stage.initOwner(ide.stage);
        }

        UI_Settings_CustomLayout_Main view = new UI_Settings_CustomLayout_Main(ide, stage, icon);
        Scene scene = new Scene(view.build());
        scene.setFill(Color.TRANSPARENT);
        view.copyStylesheets(scene);
        stage.setScene(scene);

        // Alt+F4 behaves like Cancel.
        stage.setOnCloseRequest(e -> view.revert());
        stage.setOnHidden(e -> window = null);

        window = stage;
        stage.show();
        stage.centerOnScreen();
    }

    // =====================================================================
    // Layout of the window
    // =====================================================================

    private StackPane build() {
        titleLabel = new Label(STRIP_TITLE);
        titleBar = new HBox(titleLabel);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(Dim.CustomLayout.TITLE_PAD_V, Dim.CustomLayout.TITLE_PAD_H,
                Dim.CustomLayout.TITLE_PAD_V, Dim.CustomLayout.TITLE_PAD_H));
        makeDraggable(titleBar, null);
        paintTitleBar(Color.web(NAVY_BLUE));

        HBox columns = new HBox(Dim.CustomLayout.COLUMN_GAP, layoutList(), panelGrid(), rightColumn());
        columns.setPadding(new Insets(Dim.CustomLayout.BODY_PADDING));
        columns.setStyle("-fx-background-color: transparent;");

        footerBar = new HBox();
        footerBar.setMinHeight(Dim.CustomLayout.FOOTER_HEIGHT);
        footerBar.setPrefHeight(Dim.CustomLayout.FOOTER_HEIGHT);

        frame = new BorderPane();
        frame.setTop(new VBox(buildChrome(), titleBar));
        frame.setCenter(columns);
        frame.setBottom(footerBar);
        frame.setEffect(new DropShadow(BlurType.GAUSSIAN, Color.rgb(0, 0, 0, 0.30),
                Dim.CustomLayout.WINDOW_SHADOW - 2, 0, 0, 2));

        StackPane root = new StackPane(frame);
        root.setPadding(new Insets(Dim.CustomLayout.WINDOW_SHADOW));
        // Inline, so no theme rule (.root, .stack-pane) paints the shadow area.
        root.setStyle("-fx-background-color: transparent;");

        paintFrame();
        refreshControls();
        return root;
    }

    /** The window's own title bar: icon, title, close. */
    private HBox buildChrome() {
        chromeTitle = new Label(WINDOW_TITLE);

        Region spacer = new Region();
        spacer.setStyle("-fx-background-color: transparent;");
        HBox.setHgrow(spacer, Priority.ALWAYS);

        chromeClose = new Button("\u2715");
        chromeClose.setFocusTraversable(false);
        double w = Dim.CustomLayout.CHROME_CLOSE_WIDTH;
        double h = Dim.CustomLayout.CHROME_HEIGHT;
        chromeClose.setMinSize(w, h);
        chromeClose.setPrefSize(w, h);
        chromeClose.setMaxSize(w, h);
        chromeClose.setOnAction(e -> {
            revert();
            stage.close();
        });
        chromeClose.setOnMouseEntered(e -> paintClose(true));
        chromeClose.setOnMouseExited(e -> paintClose(false));

        chromeBar = new HBox(8);
        if (icon != null) {
            ImageView view = new ImageView(icon);
            view.setFitWidth(Dim.CustomLayout.CHROME_ICON_SIZE);
            view.setFitHeight(Dim.CustomLayout.CHROME_ICON_SIZE);
            view.setPreserveRatio(true);
            view.setSmooth(true);
            chromeBar.getChildren().add(view);
        }
        chromeBar.getChildren().addAll(chromeTitle, spacer, chromeClose);
        chromeBar.setAlignment(Pos.CENTER_LEFT);
        chromeBar.setPadding(new Insets(0, 0, 0, Dim.CustomLayout.CHROME_PAD_H));
        chromeBar.setMinHeight(h);
        chromeBar.setPrefHeight(h);
        chromeBar.setMaxHeight(h);
        makeDraggable(chromeBar, chromeClose);
        return chromeBar;
    }

    /** One radio per layout, Custom first: which layout's colours to edit. */
    private GridPane layoutList() {
        GridPane grid = new GridPane();
        grid.setHgap(Dim.CustomLayout.GRID_HGAP);
        grid.setVgap(Dim.CustomLayout.GRID_VGAP);

        grid.add(columnHeader("Layout", Pos.CENTER_LEFT), 0, 0);

        List<WindowLayout> order = new ArrayList<>();
        order.add(WindowLayout.CUSTOM);
        for (WindowLayout l : WindowLayout.values()) {
            if (!l.isCustom()) {
                order.add(l);
            }
        }

        ToggleGroup edit = new ToggleGroup();
        int row = 1;
        for (WindowLayout layout : order) {
            RadioButton pick = new RadioButton(layout.label());
            pick.setToggleGroup(edit);
            pick.setUserData(layout);
            pick.setTooltip(new Tooltip("Edit the colours of the " + layout.label() + " layout"));
            editRadios.put(layout, pick);

            setMinRowHeight(pick);
            grid.add(pick, 0, row);
            row++;
        }
        edit.selectedToggleProperty().addListener((obs, was, isNow) -> {
            if (isNow != null && isNow.getUserData() instanceof WindowLayout layout) {
                editing = layout;
                refreshControls();
            }
        });
        editRadios.get(WindowLayout.CUSTOM).setSelected(true);
        return grid;
    }

    /** Tick + label, then the Light and Dark boxes, one row per panel. */
    private GridPane panelGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(Dim.CustomLayout.GRID_HGAP);
        grid.setVgap(Dim.CustomLayout.GRID_VGAP);

        panelsHeader = columnHeader("Panels", Pos.CENTER_LEFT);
        grid.add(panelsHeader, 0, 0);
        grid.add(columnHeader("Light", Pos.CENTER), 1, 0);
        grid.add(columnHeader("Dark", Pos.CENTER), 2, 0);

        int row = 1;
        for (Panel panel : Panel.values()) {
            CheckBox tick = new CheckBox(panel.label());
            tick.setTooltip(new Tooltip("Ticked: " + panel.label() + " is part of the Custom layout.\n"
                    + "Unticked: it is left out."));
            tick.selectedProperty().addListener((obs, was, isNow) -> {
                if (!updating && editing.isCustom()) {
                    working.setShown(panel, isNow);
                    refreshButtons();
                }
            });
            setMinRowHeight(tick);
            ticks.put(panel, tick);

            Button light = colourBox(Dim.CustomLayout.SWATCH_WIDTH);
            light.setOnAction(e -> pickPanel(panel, false));
            lightBoxes.put(panel, light);

            Button dark = colourBox(Dim.CustomLayout.SWATCH_WIDTH);
            dark.setOnAction(e -> pickPanel(panel, true));
            darkBoxes.put(panel, dark);

            grid.add(tick, 0, row);
            grid.add(light, 1, row);
            grid.add(dark, 2, row);
            row++;
        }

        hint = new Label("Tick at least one panel.");
        hint.setStyle("-fx-text-fill: #c62828;");
        hint.setManaged(false);
        hint.setVisible(false);
        grid.add(hint, 0, row, 3, 1);
        return grid;
    }

    /** Base Color, Default Theme, Swap, then the buttons at the bottom. */
    private VBox rightColumn() {
        baseBox = colourBox(Dim.CustomLayout.BASE_SWATCH_WIDTH);
        baseBox.setOnAction(e -> {
            Color picked = CustomColorDialog.pick(stage, editing.label() + " - Base Color", working.base(editing));
            if (picked != null) {
                working.setBase(editing, picked);
                refreshControls();
            }
        });
        HBox baseRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Base Color"), baseBox);
        baseRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup themes = new ToggleGroup();
        lightTheme = new RadioButton("Light Theme");
        darkTheme = new RadioButton("Dark Theme");
        lightTheme.setToggleGroup(themes);
        darkTheme.setToggleGroup(themes);
        themes.selectedToggleProperty().addListener((obs, was, isNow) -> {
            if (!updating && isNow != null) {
                working.setTheme(isNow == darkTheme ? CustomLayoutConfig.DARK : CustomLayoutConfig.LIGHT);
            }
        });
        VBox themeChoices = new VBox(4, lightTheme, darkTheme);
        HBox themeRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Default Theme"), themeChoices);
        themeRow.setAlignment(Pos.CENTER_LEFT);

        swap = new ToggleButton("\u21C4  Swap sides");
        swap.setFocusTraversable(false);
        swap.setTooltip(new Tooltip("Two panels: left and right change places.\n"
                + "Three or four panels: the columns are mirrored.\n"
                + "Not used with one panel or all five."));
        swap.selectedProperty().addListener((obs, was, isNow) -> {
            if (!updating) {
                working.setSwapped(isNow);
            }
        });
        HBox swapRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Panel Order"), swap);
        swapRow.setAlignment(Pos.CENTER_LEFT);

        fontSize = new Spinner<>(new SpinnerValueFactory.IntegerSpinnerValueFactory(
                (int) Typography.UI_FONT_SIZE_MIN, (int) Typography.UI_FONT_SIZE_MAX,
                (int) working.fontSize(), 1));
        fontSize.setEditable(false);
        fontSize.setFocusTraversable(false);
        fontSize.setPrefWidth(Dim.CustomLayout.BUTTON_WIDTH);
        fontSize.setTooltip(new Tooltip("Text size of every panel, the ribbon, the footer and the menus,\n"
                + (int) Typography.UI_FONT_SIZE_MIN + " to " + (int) Typography.UI_FONT_SIZE_MAX
                + " (factory " + (int) Typography.DEFAULT_UI_FONT_SIZE + "). The editor and the Command Window\n"
                + "keep their own code size. Preview shows it; Apply keeps it."));
        fontSize.valueProperty().addListener((obs, was, isNow) -> {
            if (!updating && isNow != null) {
                working.setFontSize(isNow);
            }
        });
        HBox fontRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Font Size"), fontSize);
        fontRow.setAlignment(Pos.CENTER_LEFT);

        Button reset = new Button("Reset to factory");
        reset.setTooltip(new Tooltip("All panels, the theme's own colours, navy strips, light theme,\n"
                + "standard layouts in their own colours, font size "
                + (int) Typography.DEFAULT_UI_FONT_SIZE + ". Saved only when you press Apply."));
        reset.setOnAction(e -> {
            working = CustomLayoutConfig.factory();
            refreshControls();
        });
        outlined.add(reset);
        HBox resetRow = new HBox(reset);
        resetRow.setAlignment(Pos.CENTER_LEFT);

        previewButton = actionButton("Preview", "Show the layout being edited with these choices; keep this window open");
        previewButton.setOnAction(e -> preview());
        applyButton = actionButton("Apply", "Save these choices, show the layout being edited and close");
        applyButton.setDefaultButton(true);
        applyButton.setOnAction(e -> apply());
        Button cancel = actionButton("Cancel", "Undo anything previewed and close");
        cancel.setCancelButton(true);
        cancel.setOnAction(e -> {
            revert();
            stage.close();
        });
        outlined.add(previewButton);
        outlined.add(applyButton);
        outlined.add(cancel);
        HBox buttons = new HBox(Dim.CustomLayout.BUTTON_GAP, previewButton, applyButton, cancel);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        Region spacer = new Region();
        spacer.setStyle("-fx-background-color: transparent;");
        VBox.setVgrow(spacer, Priority.ALWAYS);

        VBox column = new VBox(Dim.CustomLayout.RIGHT_ROW_GAP, baseRow, themeRow, swapRow, fontRow,
                spacer, resetRow, buttons);
        column.setFillWidth(true);
        column.setStyle("-fx-background-color: transparent;");
        return column;
    }

    private Label columnHeader(String text, Pos alignment) {
        Label label = new Label(text);
        label.setMaxWidth(Double.MAX_VALUE);
        label.setAlignment(alignment);
        headers.add(label);
        return label;
    }

    private static void setMinRowHeight(Region node) {
        node.setMinHeight(Dim.CustomLayout.SWATCH_HEIGHT);
    }

    /** A label in a 1 px box, exactly as tall as a colour box. */
    private static Label boxedLabel(String text) {
        Label label = new Label(text);
        double h = Dim.CustomLayout.SWATCH_HEIGHT;
        label.setMinWidth(Dim.CustomLayout.RIGHT_LABEL_WIDTH);
        label.setPrefWidth(Dim.CustomLayout.RIGHT_LABEL_WIDTH);
        label.setMinHeight(h);
        label.setPrefHeight(h);
        label.setMaxHeight(h);
        label.setPadding(new Insets(0, 8, 0, 8));
        label.setStyle("-fx-border-color: #3a3a3a; -fx-border-width: 1; -fx-border-insets: 0;");
        return label;
    }

    private static Button colourBox(double width) {
        Button box = new Button();
        double h = Dim.CustomLayout.SWATCH_HEIGHT;
        box.setMinSize(width, h);
        box.setPrefSize(width, h);
        box.setMaxSize(width, h);
        box.setFocusTraversable(false);
        return box;
    }

    private static Button actionButton(String text, String tip) {
        Button b = new Button(text);
        b.setMinWidth(Dim.CustomLayout.BUTTON_WIDTH);
        b.setPrefWidth(Dim.CustomLayout.BUTTON_WIDTH);
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    /** Drag the window by this node; presses on {@code except} do not drag. */
    private void makeDraggable(Node handle, Node except) {
        double[] grab = new double[2];
        boolean[] dragging = { false };
        handle.setOnMousePressed(e -> {
            dragging[0] = except == null || !isInside(e.getTarget(), except);
            grab[0] = e.getScreenX() - stage.getX();
            grab[1] = e.getScreenY() - stage.getY();
        });
        handle.setOnMouseDragged(e -> {
            if (dragging[0]) {
                stage.setX(e.getScreenX() - grab[0]);
                stage.setY(e.getScreenY() - grab[1]);
            }
        });
    }

    private static boolean isInside(Object target, Node container) {
        Node n = target instanceof Node node ? node : null;
        while (n != null) {
            if (n == container) {
                return true;
            }
            n = n.getParent();
        }
        return false;
    }

    // =====================================================================
    // Values <-> controls
    // =====================================================================

    /** Shows {@link #working} for the layout being edited in every control. */
    private void refreshControls() {
        updating = true;
        try {
            boolean custom = editing.isCustom();
            Set<Panel> fixed = custom ? null : LAYOUT_PANELS.getOrDefault(editing, EnumSet.noneOf(Panel.class));

            for (Panel panel : Panel.values()) {
                CheckBox tick = ticks.get(panel);
                if (tick != null) {
                    tick.setDisable(!custom);
                    tick.setSelected(custom ? working.isShown(panel) : fixed.contains(panel));
                }
                paint(lightBoxes.get(panel), working.color(editing, panel, false),
                        editing.label() + " \u2013 " + panel.label() + " - Light");
                paint(darkBoxes.get(panel), working.color(editing, panel, true),
                        editing.label() + " \u2013 " + panel.label() + " - Dark");
            }
            if (panelsHeader != null) {
                panelsHeader.setText(custom ? "Panels" : "Panels of " + editing.label());
            }

            paint(baseBox, working.base(editing), editing.label() + " \u2013 title strips and ribbon tab bar");
            paintTitleBar(working.base(editing));
            if (titleLabel != null) {
                titleLabel.setText(custom ? STRIP_TITLE : "Custom layout \u2013 Colours of " + editing.label());
            }

            if (lightTheme != null) {
                boolean dark = CustomLayoutConfig.DARK.equals(working.theme());
                darkTheme.setSelected(dark);
                lightTheme.setSelected(!dark);
                lightTheme.setDisable(!custom);
                darkTheme.setDisable(!custom);
            }
            if (swap != null) {
                swap.setSelected(working.isSwapped());
            }
            if (fontSize != null) {
                fontSize.getValueFactory().setValue((int) working.fontSize());
            }
        } finally {
            updating = false;
        }
        refreshButtons();
    }

    /** Swap and Preview / Apply follow the Custom tick count. */
    private void refreshButtons() {
        int count = working.shownCount();
        if (swap != null) {
            swap.setDisable(!editing.isCustom() || !working.canSwap());
        }
        boolean none = count == 0;
        if (previewButton != null) {
            previewButton.setDisable(none);
            applyButton.setDisable(none);
        }
        if (hint != null) {
            hint.setVisible(none);
            hint.setManaged(none);
        }
    }

    /** The strip under the window's title bar follows the Base Color. */
    private void paintTitleBar(Color base) {
        if (titleBar == null || titleLabel == null || base == null) {
            return;
        }
        titleBar.setStyle("-fx-background-color: " + CustomLayoutConfig.hex(base) + ";");
        titleLabel.setStyle("-fx-text-fill: " + CustomLayoutConfig.hex(CustomLayoutConfig.ink(base)) + ";"
                + " -fx-font-size: 14px; -fx-font-weight: bold;");
    }

    /** Frame, own title bar, headers and footer follow the main window's theme. */
    private void paintFrame() {
        boolean dark = CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());
        if (frame != null) {
            frame.setStyle("-fx-background-color: " + (dark ? "#1e1e1e" : "#ffffff") + ";"
                    + " -fx-border-color: " + (dark ? "#5a5f66" : "#8c96a0") + ";"
                    + " -fx-border-width: 1; -fx-background-radius: 0; -fx-border-radius: 0;");
        }
        if (chromeBar != null) {
            chromeBar.setStyle("-fx-background-color: " + (dark ? "#2b2b2b" : "#ffffff") + ";");
            chromeTitle.setStyle("-fx-text-fill: " + (dark ? "#e6e6e6" : "#1f1f1f") + "; -fx-font-size: 12px;");
            paintClose(false);
        }
        if (footerBar != null) {
            footerBar.setStyle("-fx-background-color: " + (dark ? "#2d2d2d" : "#d9dcdf") + ";"
                    + "-fx-border-color: " + (dark ? "#444444" : "#c2c7cc")
                    + " transparent transparent transparent;"
                    + "-fx-border-width: 1 0 0 0;");
        }
        for (Label header : headers) {
            header.setStyle("-fx-font-weight: bold; -fx-text-fill: " + (dark ? HEADER_BLUE_DARK : HEADER_BLUE) + ";");
        }
        // A 1 px outline on the four buttons, as Swap sides has. Only the
        // border is set inline, so the theme's fill and its hover / pressed
        // colours still show.
        String edge = dark ? "#6a6a6a" : "#a0a0a0";
        for (Button b : outlined) {
            b.setStyle("-fx-border-color: " + edge + "; -fx-border-width: 1;"
                    + " -fx-border-insets: 0; -fx-background-insets: 0;"
                    + " -fx-border-radius: 3; -fx-background-radius: 3;");
        }
    }

    private void paintClose(boolean hover) {
        if (chromeClose == null) {
            return;
        }
        boolean dark = CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());
        String bg = hover ? "#c42b1c" : "transparent";
        String ink = hover ? "#ffffff" : (dark ? "#e6e6e6" : "#1f1f1f");
        chromeClose.setStyle("-fx-background-color: " + bg + "; -fx-background-radius: 0;"
                + " -fx-background-insets: 0; -fx-border-width: 0; -fx-padding: 0;"
                + " -fx-text-fill: " + ink + "; -fx-font-size: 13px;");
    }

    /**
     * Paints a colour box. Every inset is zeroed: Modena's button background
     * reaches one pixel below the button ({@code 0 0 -1 0}), which is what
     * pushed the colour out of its box.
     */
    private static void paint(Button box, Color color, String what) {
        if (box == null || color == null) {
            return;
        }
        box.setStyle("-fx-background-color: " + CustomLayoutConfig.hex(color) + ";"
                + " -fx-background-insets: 0; -fx-background-radius: 0;"
                + " -fx-border-color: #2b2b2b; -fx-border-width: 1;"
                + " -fx-border-insets: 0; -fx-border-radius: 0;"
                + " -fx-padding: 0; -fx-effect: null; -fx-cursor: hand;");
        box.setTooltip(new Tooltip(what + ": " + CustomLayoutConfig.hex(color) + "\nClick to change"));
    }

    private void pickPanel(Panel panel, boolean dark) {
        String what = editing.label() + " \u2013 " + panel.label() + (dark ? " - Dark" : " - Light");
        Color picked = CustomColorDialog.pick(stage, what, working.color(editing, panel, dark));
        if (picked != null) {
            working.setColor(editing, panel, dark, picked);
            refreshControls();
        }
    }

    // =====================================================================
    // Preview / Apply / Cancel
    // =====================================================================

    private void preview() {
        previewed = true;
        CustomLayoutConfig.setPreview(working);
        Typography.setUiFontSize(working.fontSize());
        show(editing);
    }

    private void apply() {
        applied = true;
        CustomLayoutConfig.save(working);
        CustomLayoutConfig.setPreview(null);
        Typography.setUiFontSize(working.fontSize());
        show(editing);
        stage.close();
    }

    /**
     * Drops the preview and puts back the layout and theme the window opened
     * with. Does nothing after Apply, or if nothing was previewed.
     */
    private void revert() {
        if (applied || !previewed) {
            return;
        }
        previewed = false;
        CustomLayoutConfig.setPreview(null);
        Typography.setUiFontSize(fontSizeAtOpen);
        CustomLayoutConfig.setPlainStandard(plainStandardAtOpen);
        if (ide != null && themeAtOpen != null && !themeAtOpen.equals(ThemeManager.getActiveTheme())) {
            ThemeManager.applyTheme(ide, themeAtOpen);
        }
        LayoutManager.rebuild(layoutAtOpen);
        LayoutRibbon.refreshSelection();
    }

    /**
     * Puts a layout on screen with {@link CustomLayoutConfig#effective()}.
     * Custom also brings its theme.
     */
    private void show(WindowLayout layout) {
        if (layout.isCustom() && ide != null && !working.theme().equals(ThemeManager.getActiveTheme())) {
            ThemeManager.applyTheme(ide, working.theme());
        }
        // From this window a layout shows the colours chosen for it; the
        // gallery's standard tiles show the factory look again.
        CustomLayoutConfig.setPlainStandard(false);
        LayoutManager.rebuild(layout);
        // A standard layout in changed colours is marked as Custom in the
        // Settings > Layout gallery; factory colours mark the layout itself.
        LayoutRibbon.refreshSelection();
        if (stage.getScene() != null) {
            copyStylesheets(stage.getScene());
        }
        paintFrame();
        // This window carries the main window's sheets, so a new font size
        // resizes its own text too; let the window follow its content.
        if (stage.isShowing()) {
            stage.sizeToScene();
        }
    }

    /** This window follows the main window's theme. */
    private void copyStylesheets(Scene scene) {
        if (ide != null && ide.stage != null && ide.stage.getScene() != null) {
            scene.getStylesheets().setAll(ide.stage.getScene().getStylesheets());
        }
    }

    /**
     * Loads the Neural Code icon from the classpath. Failure is non-fatal.
     *
     * @return the icon, or null
     */
    private static Image loadIcon() {
        try (InputStream in = UI_Settings_CustomLayout_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return null;
            }
            Image image = new Image(in);
            return image.isError() ? null : image;
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
            return null;
        }
    }
}
