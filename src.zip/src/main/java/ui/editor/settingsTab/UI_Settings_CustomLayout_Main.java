package ui.editor.settingsTab;

import java.io.InputStream;
import java.util.EnumMap;
import java.util.Map;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import ui.UI_Main;
import ui.design.Dim;
import ui.layout.LayoutManager;
import ui.layout.WindowLayout;
import ui.layout.custom.CustomLayoutConfig;
import ui.layout.custom.CustomLayoutConfig.Panel;
import ui.managers.ThemeManager;

/**
 * Custom Layout window, opened from the Custom tile on the Settings &gt;
 * Layout band.
 *
 * <pre>
 *   Custom layout - Set Default
 *   +-----------------------------------------------------------------+
 *   |                     Light   Dark      Base Color      [####]    |
 *   |  [x] Editor Tab     [###]   [###]                                |
 *   |  [x] Directory Exp. [###]   [###]     Default Theme  (o) Light   |
 *   |  [x] CLI            [###]   [###]                    ( ) Dark    |
 *   |  [x] Variable Exp.  [###]   [###]                                |
 *   |  [x] Chat Bot       [###]   [###]                                |
 *   |  [-] Signal Exp.    [###]   [###]   (tick follows Variable Exp.) |
 *   |  Reset to factory              [Preview] [Apply] [Cancel]        |
 *   +-----------------------------------------------------------------+
 * </pre>
 *
 * <h3>What each control means</h3>
 * <ul>
 * <li><b>Tick</b> -- the panel starts open in the Custom layout. Unticked,
 * it starts minimised and comes back by itself when needed (see
 * {@code LayoutManager}); nothing is ever removed.</li>
 * <li><b>Signal Explorer tick</b> -- greyed out. The Signal Explorer is part
 * of the Variable Explorer and opens on demand (Signals &gt; Set &gt;
 * Apply), so its box only mirrors the Variable Explorer's tick. Its Light /
 * Dark colours are still its own.</li>
 * <li><b>Light / Dark box</b> -- the panel's body colour in that theme.
 * Text on it turns light or dark automatically to stay readable.</li>
 * <li><b>Base Color</b> -- the colour of the active panel's title strip.</li>
 * <li><b>Default Theme</b> -- the theme the Custom layout uses.</li>
 * </ul>
 *
 * <h3>Title strip</h3>
 * <p>
 * The strip under the window's own title bar is painted in the Base Color
 * being edited, and its text turns dark on a light colour, so the window
 * previews the choice as soon as it is picked -- before Preview or Apply.
 * The operating system's title bar above it (icon, "Custom Layout", close
 * button) belongs to Windows and keeps the system colours.
 * </p>
 *
 * <h3>Buttons</h3>
 * <ul>
 * <li><b>Preview</b> -- shows the choices in the main window and keeps this
 * window open. Nothing is saved.</li>
 * <li><b>Apply</b> -- saves the choices, shows them and closes.</li>
 * <li><b>Cancel</b> (or the window's close button) -- drops anything
 * previewed and puts the saved Custom layout and the previous theme back.</li>
 * <li><b>Reset to factory</b> -- puts the factory values (all ticked, the
 * theme's own colours, navy strips, light theme) into this window. Like any
 * other change, they are saved only by Apply.</li>
 * </ul>
 * <p>
 * Self-contained on purpose: the chrome is repeated in each Settings window
 * rather than shared through a factory, because these windows are expected to
 * grow apart rather than together.
 * </p>
 */
public final class UI_Settings_CustomLayout_Main {

    private static final String NAVY_BLUE = "#004073";
    private static final String FOOTER_GREY = "#d9dcdf";
    private static final String FOOTER_RULE = "#c2c7cc";
    private static final String HEADER_BLUE = "#1a4f8b";
    private static final String ICON_PATH = "/icons/ic_18_nc.PNG";
    private static final String WINDOW_TITLE = "Custom Layout";
    private static final String STRIP_TITLE = "Custom layout \u2013 Set Default";

    private static Stage window;

    private final UI_Main ide;
    private final Stage stage;

    /** The values on screen in this window. */
    private CustomLayoutConfig working;

    /** The theme in force when the window opened, for Cancel. */
    private final String themeAtOpen;

    private boolean previewed;
    private boolean applied;

    private final Map<Panel, CheckBox> ticks = new EnumMap<>(Panel.class);
    private final Map<Panel, Button> lightBoxes = new EnumMap<>(Panel.class);
    private final Map<Panel, Button> darkBoxes = new EnumMap<>(Panel.class);
    private Button baseBox;
    private HBox titleBar;
    private Label titleLabel;
    private RadioButton lightTheme;
    private RadioButton darkTheme;

    private UI_Settings_CustomLayout_Main(UI_Main ide, Stage stage) {
        this.ide = ide;
        this.stage = stage;
        this.working = CustomLayoutConfig.saved().copy();
        this.themeAtOpen = ThemeManager.getActiveTheme();
    }

    /**
     * Opens the Custom Layout window. If it is already open, the existing window
     * is brought to the front instead of creating a duplicate.
     *
     * @param ide the IDE controller
     */
    public static void open(UI_Main ide) {
        if (window != null && window.isShowing()) {
            window.toFront();
            window.requestFocus();
            return;
        }

        Stage stage = new Stage();
        stage.setTitle(WINDOW_TITLE);
        stage.setResizable(false);
        stage.initModality(Modality.NONE);
        applyWindowIcon(stage);
        if (ide != null && ide.stage != null) {
            stage.initOwner(ide.stage);
        }

        UI_Settings_CustomLayout_Main view = new UI_Settings_CustomLayout_Main(ide, stage);
        Scene scene = new Scene(view.build());
        view.copyStylesheets(scene);
        stage.setScene(scene);

        // The close button behaves like Cancel.
        stage.setOnCloseRequest(e -> view.revert());
        stage.setOnHidden(e -> window = null);

        window = stage;
        stage.show();
        stage.centerOnScreen();
    }

    // =====================================================================
    // Layout of the window
    // =====================================================================

    private BorderPane build() {
        titleLabel = new Label(STRIP_TITLE);
        titleBar = new HBox(titleLabel);
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(Dim.CustomLayout.TITLE_PAD_V, Dim.CustomLayout.TITLE_PAD_H,
                Dim.CustomLayout.TITLE_PAD_V, Dim.CustomLayout.TITLE_PAD_H));
        paintTitleBar(Color.web(NAVY_BLUE));

        HBox columns = new HBox(Dim.CustomLayout.COLUMN_GAP, panelGrid(), rightColumn());
        columns.setPadding(new Insets(Dim.CustomLayout.BODY_PADDING));

        HBox footerBar = new HBox();
        footerBar.setMinHeight(Dim.CustomLayout.FOOTER_HEIGHT);
        footerBar.setPrefHeight(Dim.CustomLayout.FOOTER_HEIGHT);
        footerBar.setStyle("-fx-background-color: " + FOOTER_GREY + ";"
                + "-fx-border-color: " + FOOTER_RULE + " transparent transparent transparent;"
                + "-fx-border-width: 1 0 0 0;");

        BorderPane root = new BorderPane();
        root.setTop(titleBar);
        root.setCenter(columns);
        root.setBottom(footerBar);

        refreshControls();
        return root;
    }

    /** Tick + label, then the Light and Dark boxes, one row per panel. */
    private GridPane panelGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(Dim.CustomLayout.GRID_HGAP);
        grid.setVgap(Dim.CustomLayout.GRID_VGAP);

        grid.add(columnHeader("Light"), 1, 0);
        grid.add(columnHeader("Dark"), 2, 0);

        int row = 1;
        for (Panel panel : Panel.values()) {
            CheckBox tick = new CheckBox(panel.label());
            if (panel.hasOwnTick()) {
                tick.setTooltip(new Tooltip("Ticked: " + panel.label() + " starts open.\n"
                        + "Unticked: it starts minimised and opens when needed."));
                tick.selectedProperty().addListener((obs, was, isNow) -> working.setShown(panel, isNow));
            } else {
                // No tick of its own: greyed, and mirrors its owner's box.
                tick.setDisable(true);
                tick.setTooltip(new Tooltip(panel.label() + " is part of the "
                        + panel.tickOwner().label() + " and follows its tick.\n"
                        + "It opens from Signals > Set > Apply and closes with its own x."));
            }
            ticks.put(panel, tick);

            Button light = colourBox(Dim.CustomLayout.SWATCH_WIDTH);
            light.setOnAction(e -> pickPanel(panel, false));
            lightBoxes.put(panel, light);

            Button dark = colourBox(Dim.CustomLayout.SWATCH_WIDTH);
            dark.setOnAction(e -> pickPanel(panel, true));
            darkBoxes.put(panel, dark);

            grid.add(tick, 0, row);
            grid.add(light, 1, row);
            grid.add(dark, 2, row);
            row++;
        }
        for (Panel panel : Panel.values()) {
            if (!panel.hasOwnTick()) {
                ticks.get(panel).selectedProperty().bind(
                        ticks.get(panel.tickOwner()).selectedProperty());
            }
        }
        return grid;
    }

    /** Base Color, Default Theme, then the buttons at the bottom. */
    private VBox rightColumn() {
        baseBox = colourBox(Dim.CustomLayout.BASE_SWATCH_WIDTH);
        baseBox.setOnAction(e -> {
            Color picked = CustomColorDialog.pick(stage, "Base Color", working.base());
            if (picked != null) {
                working.setBase(picked);
                refreshControls();
            }
        });
        HBox baseRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Base Color"), baseBox);
        baseRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup themes = new ToggleGroup();
        lightTheme = new RadioButton("Light Theme");
        darkTheme = new RadioButton("Dark Theme");
        lightTheme.setToggleGroup(themes);
        darkTheme.setToggleGroup(themes);
        themes.selectedToggleProperty().addListener((obs, was, isNow) -> {
            if (isNow != null) {
                working.setTheme(isNow == darkTheme ? CustomLayoutConfig.DARK : CustomLayoutConfig.LIGHT);
            }
        });
        VBox themeChoices = new VBox(4, lightTheme, darkTheme);
        HBox themeRow = new HBox(Dim.CustomLayout.GRID_HGAP, boxedLabel("Default Theme"), themeChoices);
        themeRow.setAlignment(Pos.CENTER_LEFT);

        Button reset = new Button("Reset to factory");
        reset.setTooltip(new Tooltip("All panels open, the theme's own colours, navy strips, light theme.\n"
                + "Saved only when you press Apply."));
        reset.setOnAction(e -> {
            working = CustomLayoutConfig.factory();
            refreshControls();
        });
        HBox resetRow = new HBox(reset);
        resetRow.setAlignment(Pos.CENTER_LEFT);

        Button preview = actionButton("Preview", "Show these choices in the main window; keep this window open");
        preview.setOnAction(e -> preview());
        Button apply = actionButton("Apply", "Save these choices and close");
        apply.setDefaultButton(true);
        apply.setOnAction(e -> apply());
        Button cancel = actionButton("Cancel", "Undo anything previewed and close");
        cancel.setCancelButton(true);
        cancel.setOnAction(e -> {
            revert();
            stage.close();
        });
        HBox buttons = new HBox(Dim.CustomLayout.BUTTON_GAP, preview, apply, cancel);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        VBox column = new VBox(Dim.CustomLayout.RIGHT_ROW_GAP, baseRow, themeRow, spacer, resetRow, buttons);
        column.setFillWidth(true);
        return column;
    }

    private static Label columnHeader(String text) {
        Label label = new Label(text);
        label.setMaxWidth(Double.MAX_VALUE);
        label.setAlignment(Pos.CENTER);
        label.setStyle("-fx-font-weight: bold; -fx-text-fill: " + HEADER_BLUE + ";");
        return label;
    }

    private static Label boxedLabel(String text) {
        Label label = new Label(text);
        label.setMinWidth(Dim.CustomLayout.RIGHT_LABEL_WIDTH);
        label.setPrefWidth(Dim.CustomLayout.RIGHT_LABEL_WIDTH);
        label.setMinHeight(Dim.CustomLayout.SWATCH_HEIGHT);
        label.setPadding(new Insets(0, 8, 0, 8));
        label.setStyle("-fx-border-color: #3a3a3a; -fx-border-width: 1;");
        return label;
    }

    private static Button colourBox(double width) {
        Button box = new Button();
        box.setMinSize(width, Dim.CustomLayout.SWATCH_HEIGHT);
        box.setPrefSize(width, Dim.CustomLayout.SWATCH_HEIGHT);
        box.setMaxSize(width, Dim.CustomLayout.SWATCH_HEIGHT);
        box.setFocusTraversable(false);
        return box;
    }

    private static Button actionButton(String text, String tip) {
        Button b = new Button(text);
        b.setMinWidth(Dim.CustomLayout.BUTTON_WIDTH);
        b.setPrefWidth(Dim.CustomLayout.BUTTON_WIDTH);
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    // =====================================================================
    // Values <-> controls
    // =====================================================================

    /** Shows {@link #working} in every control. */
    private void refreshControls() {
        for (Panel panel : Panel.values()) {
            CheckBox tick = ticks.get(panel);
            // A mirrored tick is bound to its owner's and follows it.
            if (tick != null && !tick.selectedProperty().isBound()) {
                tick.setSelected(working.isShown(panel));
            }
            paint(lightBoxes.get(panel), working.color(panel, false), panel.label() + " - Light");
            paint(darkBoxes.get(panel), working.color(panel, true), panel.label() + " - Dark");
        }
        paint(baseBox, working.base(), "Title strips, ribbon tab bar and this window's strip");
        paintTitleBar(working.base());
        if (lightTheme != null) {
            boolean dark = CustomLayoutConfig.DARK.equals(working.theme());
            darkTheme.setSelected(dark);
            lightTheme.setSelected(!dark);
        }
    }

    /** The strip under the window's title bar follows the Base Color. */
    private void paintTitleBar(Color base) {
        if (titleBar == null || titleLabel == null || base == null) {
            return;
        }
        titleBar.setStyle("-fx-background-color: " + CustomLayoutConfig.hex(base) + ";");
        titleLabel.setStyle("-fx-text-fill: " + CustomLayoutConfig.hex(CustomLayoutConfig.ink(base)) + ";"
                + " -fx-font-size: 14px; -fx-font-weight: bold;");
    }

    private static void paint(Button box, Color color, String what) {
        if (box == null || color == null) {
            return;
        }
        box.setStyle("-fx-background-color: " + CustomLayoutConfig.hex(color) + ";"
                + " -fx-background-radius: 0; -fx-border-color: #2b2b2b; -fx-border-width: 1;"
                + " -fx-cursor: hand;");
        box.setTooltip(new Tooltip(what + ": " + CustomLayoutConfig.hex(color) + "\nClick to change"));
    }

    private void pickPanel(Panel panel, boolean dark) {
        String what = panel.label() + (dark ? " - Dark" : " - Light");
        Color picked = CustomColorDialog.pick(stage, what, working.color(panel, dark));
        if (picked != null) {
            working.setColor(panel, dark, picked);
            refreshControls();
        }
    }

    // =====================================================================
    // Preview / Apply / Cancel
    // =====================================================================

    private void preview() {
        previewed = true;
        CustomLayoutConfig.setPreview(working);
        show();
    }

    private void apply() {
        applied = true;
        CustomLayoutConfig.save(working);
        CustomLayoutConfig.setPreview(null);
        show();
        stage.close();
    }

    /**
     * Drops the preview and puts back the saved Custom layout and the theme
     * the window opened with. Does nothing after Apply, or if nothing was
     * previewed.
     */
    private void revert() {
        if (applied || !previewed) {
            return;
        }
        previewed = false;
        CustomLayoutConfig.setPreview(null);
        if (ide != null && themeAtOpen != null && !themeAtOpen.equals(ThemeManager.getActiveTheme())) {
            ThemeManager.applyTheme(ide, themeAtOpen);
        }
        LayoutManager.rebuild(WindowLayout.CUSTOM);
    }

    /** Puts {@link CustomLayoutConfig#effective()} on screen. */
    private void show() {
        if (ide != null && !working.theme().equals(ThemeManager.getActiveTheme())) {
            ThemeManager.applyTheme(ide, working.theme());
        }
        LayoutManager.rebuild(WindowLayout.CUSTOM);
        if (stage.getScene() != null) {
            copyStylesheets(stage.getScene());
        }
    }

    /** This window follows the main window's theme. */
    private void copyStylesheets(Scene scene) {
        if (ide != null && ide.stage != null && ide.stage.getScene() != null) {
            scene.getStylesheets().setAll(ide.stage.getScene().getStylesheets());
        }
    }

    /**
     * Loads the Neural Code icon from the classpath and applies it to the
     * stage. Failure to load is non-fatal: the window keeps the default icon.
     *
     * @param stage stage to decorate
     */
    private static void applyWindowIcon(Stage stage) {
        try (InputStream in = UI_Settings_CustomLayout_Main.class.getResourceAsStream(ICON_PATH)) {
            if (in == null) {
                System.err.println("Window icon not found on classpath: " + ICON_PATH);
                return;
            }
            Image icon = new Image(in);
            if (!icon.isError()) {
                stage.getIcons().add(icon);
            }
        } catch (Exception ex) {
            System.err.println("Failed to load window icon: " + ex.getMessage());
        }
    }
}
