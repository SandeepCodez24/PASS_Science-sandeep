package ui.editor;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.control.Tooltip;
import ui.UI_Main;
import ui.explorer.navigation.ChoiceDialog;
import ui.explorer.navigation.ChoiceDialog.Choice;
import ui.explorer.navigation.ChoiceDialog.Side;

/**
 * Keeps editor tabs honest about the file on disk.
 *
 * <h2>1. Deleted files</h2>
 * <p>
 * A tab whose file no longer exists is struck out, and its tooltip says where
 * the file was and how to get it back.
 * </p>
 * <p>
 * A tab is deleted when it belongs to a saved file ({@link EditorFileInfo#path}
 * is set) and that path does not exist now. An untitled tab that was never
 * saved is never marked. The text in the editor is untouched either way: it is
 * the only copy left, and Ctrl+S writes it back. The tab gets the style class
 * {@link #DELETED_CLASS}; the strike-through itself is a rule in the generated
 * sheet ({@code DesignStylesheet.editorTabs}).
 * </p>
 *
 * <h2>2. Files changed outside the editor</h2>
 * <p>
 * Each tab remembers the last version of its file it agreed with -- the
 * file's modified time and a fingerprint of its text -- taken when the file is
 * opened ({@code EditorFileOpener}), saved ({@code EditorFileSaver}) or
 * reloaded here. When the file's time moves on:
 * </p>
 * <ul>
 * <li>if the new disk text equals the editor's text, nothing happens;</li>
 * <li>if the tab has no unsaved edits, the new text is loaded silently, caret
 * kept where it was (as VS Code does);</li>
 * <li>if the tab has unsaved edits, the user is asked: <b>Reload</b> (take the
 * disk version) or <b>Keep Mine</b> (the default; the tab stays as it is and
 * now counts as changed against the disk). The question is asked once per
 * outside change.</li>
 * </ul>
 *
 * <h2>When the checks run</h2>
 * <ul>
 * <li>After every change made from the File Explorer, through
 * {@code DirectoryFileOps.afterChange} (deletions only).</li>
 * <li>After every save, through {@code ProjectManager.refreshProjectTree}
 * (deletions only).</li>
 * <li>Whenever {@code DirectoryWatcher} sees the disk change under the current
 * folder (both checks).</li>
 * <li>Whenever the Astra window regains focus (both checks), which covers
 * files open from outside the current folder.</li>
 * </ul>
 */
public final class EditorFileStatus {

    /** Style class carried by the tab of a file that no longer exists. */
    public static final String DELETED_CLASS = "file-deleted";

    /** Where a tab's own tooltip is parked while the deleted note replaces it. */
    private static final String SAVED_TOOLTIP_KEY = "astra.fileStatus.savedTooltip";

    /** Marks a tab whose tooltip is the deleted note, so it is not parked twice. */
    private static final String NOTE_KEY = "astra.fileStatus.note";

    /** Modified time (Long, ms) of the disk version the tab last agreed with. */
    private static final String DISK_TIME_KEY = "astra.fileStatus.diskTime";

    /** Fingerprint (Long) of the text of that version. */
    private static final String DISK_PRINT_KEY = "astra.fileStatus.diskPrint";

    /** Files larger than this are never reloaded automatically. */
    private static final long RELOAD_CEILING_BYTES = 20L * 1024 * 1024;

    private static final String RELOAD = "reload";
    private static final String KEEP = "keep";

    private static boolean installed = false;

    /** True while the external-change check runs, so its dialog cannot re-enter it. */
    private static boolean checking = false;

    private EditorFileStatus() {
    }

    /**
     * Re-checks the open tabs every time the main window regains focus. Call
     * once, after the main window is built.
     *
     * @param ide the IDE controller
     */
    public static void install(UI_Main ide) {
        if (installed || ide == null || ide.stage == null) {
            return;
        }
        installed = true;
        ide.stage.focusedProperty().addListener((obs, was, now) -> {
            if (Boolean.TRUE.equals(now)) {
                refresh(ide);
                checkExternalChanges(ide);
            }
        });
        refresh(ide);
    }

    // =====================================================================
    // 1. Deleted files
    // =====================================================================

    /**
     * Checks every open tab against the disk and strikes out, or un-strikes,
     * its title. Cheap: one existence check per open tab.
     *
     * @param ide the IDE controller
     */
    public static void refresh(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        for (Tab tab : ide.editorTabs.getTabs()) {
            mark(tab, isMissing(tab));
        }
    }

    /**
     * @param tab an editor tab
     * @return true if the tab is currently struck out
     */
    public static boolean isDeleted(Tab tab) {
        return tab != null && tab.getStyleClass().contains(DELETED_CLASS);
    }

    // =====================================================================
    // 2. Files changed outside the editor
    // =====================================================================

    /**
     * Records that a tab and its file now agree: the text just opened, saved
     * or reloaded is what is on disk. Call after the tab's
     * {@link EditorFileInfo} points at the file.
     *
     * @param tab  the editor tab
     * @param text the text that was read from or written to the file
     */
    public static void remember(Tab tab, String text) {
        Path path = pathOf(tab);
        if (path == null || text == null) {
            return;
        }
        try {
            tab.getProperties().put(DISK_TIME_KEY, Files.getLastModifiedTime(path).toMillis());
            tab.getProperties().put(DISK_PRINT_KEY, fingerprint(text));
        } catch (IOException | RuntimeException e) {
            tab.getProperties().remove(DISK_TIME_KEY);
            tab.getProperties().remove(DISK_PRINT_KEY);
        }
    }

    /**
     * Looks for open files that were changed outside the editor and reloads or
     * asks, as described in the class comment. Call on the FX thread.
     *
     * @param ide the IDE controller
     */
    public static void checkExternalChanges(UI_Main ide) {
        if (checking || ide == null || ide.editorTabs == null) {
            return;
        }
        checking = true;
        try {
            List<Tab> tabs = new ArrayList<>(ide.editorTabs.getTabs());
            for (Tab tab : tabs) {
                if (ide.editorTabs.getTabs().contains(tab)) {
                    checkOne(ide, tab);
                }
            }
        } finally {
            checking = false;
        }
    }

    private static void checkOne(UI_Main ide, Tab tab) {
        Path path = pathOf(tab);
        if (path == null || !Files.isRegularFile(path)) {
            return;
        }

        long diskTime;
        long size;
        try {
            diskTime = Files.getLastModifiedTime(path).toMillis();
            size = Files.size(path);
        } catch (IOException | RuntimeException e) {
            return;
        }

        Object knownTime = tab.getProperties().get(DISK_TIME_KEY);
        Object knownPrint = tab.getProperties().get(DISK_PRINT_KEY);
        if (!(knownTime instanceof Long time) || !(knownPrint instanceof Long print)) {
            // A tab from before this check existed: take today's disk as the
            // baseline rather than guess what it used to be.
            String disk = read(path, size);
            if (disk != null) {
                remember(tab, disk);
            }
            return;
        }
        if (time == diskTime) {
            return;
        }

        String disk = read(path, size);
        if (disk == null) {
            return;
        }
        String editor = EditorTextOperations.getEditorText(tab);
        if (disk.equals(editor)) {
            remember(tab, disk);
            return;
        }

        boolean unsavedEdits = fingerprint(editor) != print;
        if (!unsavedEdits) {
            reload(tab, disk);
            return;
        }

        if (ide.editorTabs.getSelectionModel().getSelectedItem() != tab) {
            ide.editorTabs.getSelectionModel().select(tab);
        }
        String answer = ChoiceDialog.show(ide.stage,
                "The file \u201C" + ChoiceDialog.breakable(path.toString())
                        + "\u201D has been changed outside the editor.",
                "This tab has unsaved changes. Reload the file from disk and lose them, "
                        + "or keep your version?",
                null,
                List.of(
                        new Choice(RELOAD, "Reload", "Replace the tab's text with the file on disk",
                                Side.LEFT, false, false),
                        new Choice(KEEP, "Keep Mine", "Keep the tab's text; Save will overwrite the file",
                                Side.RIGHT, true, true)));

        if (RELOAD.equals(answer)) {
            reload(tab, disk);
        } else {
            // Agree with the new disk version, so the tab now reads as changed
            // against it and this change is not asked about again.
            remember(tab, disk);
        }
    }

    /** Puts the disk text into the tab, keeping the caret where it was. */
    private static void reload(Tab tab, String disk) {
        CodeArea area = codeAreaOf(tab);
        int caret = area == null ? 0 : area.getCaretPosition();

        EditorTextOperations.setEditorText(tab, disk);

        if (area != null) {
            area.moveTo(Math.min(caret, area.getLength()));
            area.requestFollowCaret();
        }
        Path path = pathOf(tab);
        if (path != null && path.getFileName() != null) {
            // The text matches the file again, so the unsaved-changes star goes.
            tab.setText(path.getFileName().toString());
        }
        remember(tab, disk);
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static Path pathOf(Tab tab) {
        if (tab == null || !(tab.getUserData() instanceof EditorFileInfo info)) {
            return null;
        }
        return info.path;
    }

    private static CodeArea codeAreaOf(Tab tab) {
        Node content = tab.getContent();
        if (content instanceof VirtualizedScrollPane<?> scroll && scroll.getContent() instanceof CodeArea code) {
            return code;
        }
        return content instanceof CodeArea code ? code : null;
    }

    private static String read(Path path, long size) {
        if (size > RELOAD_CEILING_BYTES) {
            return null;
        }
        try {
            return Files.readString(path, StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException e) {
            // Mid-write by the other program, or not UTF-8: try again next time.
            return null;
        }
    }

    /** Length and hash in one value; a cheap stand-in for "same text". */
    private static long fingerprint(String text) {
        if (text == null) {
            return 0L;
        }
        return ((long) text.length() << 32) ^ (text.hashCode() & 0xffffffffL);
    }

    private static boolean isMissing(Tab tab) {
        Path path = pathOf(tab);
        if (path == null) {
            return false;
        }
        try {
            return !Files.exists(path);
        } catch (SecurityException e) {
            return false;
        }
    }

    private static void mark(Tab tab, boolean deleted) {
        if (tab == null) {
            return;
        }
        boolean marked = tab.getStyleClass().contains(DELETED_CLASS);

        if (deleted) {
            if (!marked) {
                tab.getStyleClass().add(DELETED_CLASS);
            }
            if (!tab.getProperties().containsKey(NOTE_KEY)) {
                // Park whatever tooltip the tab had, so it can come back.
                tab.getProperties().put(SAVED_TOOLTIP_KEY, tab.getTooltip());
                tab.getProperties().put(NOTE_KEY, Boolean.TRUE);
            }
            tab.setTooltip(new Tooltip(note(tab)));
            return;
        }

        if (marked) {
            tab.getStyleClass().remove(DELETED_CLASS);
        }
        if (tab.getProperties().containsKey(NOTE_KEY)) {
            Object saved = tab.getProperties().remove(SAVED_TOOLTIP_KEY);
            tab.getProperties().remove(NOTE_KEY);
            tab.setTooltip(saved instanceof Tooltip t ? t : null);
        }
    }

    private static String note(Tab tab) {
        Path path = pathOf(tab);
        String where = path == null ? "" : "\n" + path;
        return "This file has been deleted from disk." + where
                + "\nSave (Ctrl+S) to write it back.";
    }
}
