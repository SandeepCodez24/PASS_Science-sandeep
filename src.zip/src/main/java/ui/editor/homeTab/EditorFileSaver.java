package ui.editor.homeTab;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javafx.scene.control.Tab;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import ui.UI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorFileStatus;
import ui.editor.EditorTextOperations;
import ui.editor.EditorUIHelper;
import ui.editor.navigation.NavigationActions;
import ui.managers.LanguageDesignManager;
import ui.managers.ProjectManager;
import ui.ui_functions.UI_MainProgramControl; 

/**
 * Handles file saving operations.
 * Supports both regular save and save-as with semantic file generation for UPI
 * files.
 *
 * <h3>Saving a deleted file</h3>
 * <p>
 * A tab whose file was deleted keeps its path and is shown struck out
 * ({@code EditorFileStatus}). Save and the run workflow's save write it back
 * to that path, recreating its folder too if the folder was deleted with it.
 * The strike-out is cleared by the tree refresh every save already does
 * ({@code ProjectManager.refreshProjectTree}).
 * </p>
 *
 * <h3>Telling our saves from someone else's</h3>
 * <p>
 * Every save records the text it wrote with
 * {@link EditorFileStatus#remember}, so the file watcher that fires a moment
 * later recognises the change as Astra's own and does not offer to reload
 * it.
 * </p>
 *
 * <h3>Where the Save dialog opens</h3>
 * <p>
 * Always in the <b>current folder</b> -- the folder the File Explorer and the
 * breadcrumb show ({@link NavigationActions#projectFolder}). It used to open
 * in {@code ide.currentFolder}, which opening a file moves to that file's own
 * folder; so after opening a file from another folder, saving a new file
 * offered that other folder instead of the current one. The current folder is
 * where scripts run, so it is where a new file belongs.
 * </p>
 */
public class EditorFileSaver {

    /**
     * Saves the current file.
     * If file is unsaved, prompts for save location.
     * 
     * @param ide the IDE controller
     */
    public static void saveCurrentFile(UI_Main ide) {
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null)
            return;

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();

        if (info == null || info.path == null) {
            saveAsFile(ide);
            return;
        }

        try {
            String text = EditorTextOperations.getEditorText(tab);
            writeRecreating(info.path, text);
            EditorFileStatus.remember(tab, text);

            // Generate semantic files for UPI files (normal save)
            if (LanguageDesignManager.isUpiFile(info.path)) {
                generateSemanticFiles(ide, info);
            }

            // Update tab and UI
            tab.setText(info.path.getFileName().toString());
            EditorUIHelper.updateFooter(ide, info.path, info.path.getFileName().toString());
            ProjectManager.refreshProjectTree(ide);
        } catch (IOException e) {
            EditorUIHelper.showError("Save failed", e);
        }
    }

    /**
     * Save current file but skip generating semantic/variable files.
     * Used by the run workflow so files are only generated after a successful run.
     * 
     * @param ide the IDE controller
     */
    public static void saveCurrentFileSkipSemantic(UI_Main ide) {
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null)
            return;

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();

        if (info == null || info.path == null) {
            saveAsFile(ide);
            return;
        }

        try {
            String text = EditorTextOperations.getEditorText(tab);
            writeRecreating(info.path, text);
            EditorFileStatus.remember(tab, text);

            // Do NOT generate semantic files here; caller will generate them if run
            // succeeds

            // Update tab and UI
            tab.setText(info.path.getFileName().toString());
            EditorUIHelper.updateFooter(ide, info.path, info.path.getFileName().toString());
            ProjectManager.refreshProjectTree(ide);
        } catch (IOException e) {
            EditorUIHelper.showError("Save failed", e);
        }
    }

    /**
     * Writes a file, first recreating its folder if that no longer exists --
     * the case of a file whose folder was deleted while it was open.
     *
     * @param path the file
     * @param text its content
     * @throws IOException if the folder or the file cannot be written
     */
    private static void writeRecreating(Path path, String text) throws IOException {
        Path parent = path.getParent();
        if (parent != null && !Files.isDirectory(parent)) {
            Files.createDirectories(parent);
        }
        Files.writeString(path, text);
    }

    /**
     * Saves the file with a new location or name.
     * Shows file chooser dialog for save location.
     * 
     * @param ide the IDE controller
     */
    public static void saveAsFile(UI_Main ide) {
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null)
            return;

        FileChooser fc = new FileChooser();
        fc.setTitle("Save File");

        // Setup file extension filters
        FileChooser.ExtensionFilter txtFilter = new FileChooser.ExtensionFilter("text files (*.txt)", "*.txt");
        FileChooser.ExtensionFilter upiFilter = new FileChooser.ExtensionFilter("neural code(*.nc)", "*.nc");

        fc.getExtensionFilters().addAll(upiFilter, txtFilter);
        Path start = dialogFolder(ide);
        if (start != null) {
            fc.setInitialDirectory(start.toFile());
        }

        var file = fc.showSaveDialog(ide.stage);
        if (file == null)
            return;

        try {
            String text = EditorTextOperations.getEditorText(tab);
            Files.writeString(file.toPath(), text);

            // Determine extension
            String ext = file.getName().contains(".")
                    ? file.getName().substring(file.getName().lastIndexOf('.'))
                    : ".txt";

            // Update tab with file info
            EditorFileInfo fileInfo = new EditorFileInfo(file.toPath(), ext);
            tab.setUserData(fileInfo);
            EditorFileStatus.remember(tab, text);

            // Generate semantic files for UPI files
            if (LanguageDesignManager.isUpiFile(file.toPath())) {
                generateSemanticFiles(ide, fileInfo);
            }

            // Update UI
            tab.setText(file.getName());
            ide.currentFolder = file.toPath().getParent();
            EditorUIHelper.updateFooter(ide, file.toPath(), file.getName());
            ProjectManager.refreshProjectTree(ide);

        } catch (IOException e) {
            EditorUIHelper.showError("Save failed", e);
        }
    }

    /**
     * Saves the current file into the project root folder, keeping its name.
     * A file that has never been saved gets its tab title as its file name.
     *
     * @param ide the IDE controller
     */
    public static void saveToProjectRoot(UI_Main ide) {
        saveIntoFolder(ide, HomeFilesProject.root(ide));
    }

    /**
     * Asks for a folder and saves the current file into it, keeping its name.
     *
     * @param ide the IDE controller
     */
    public static void saveInFolder(UI_Main ide) {
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null)
            return;

        DirectoryChooser dc = new DirectoryChooser();
        dc.setTitle("Save In Folder");

        Path start = HomeFilesProject.root(ide);
        if (Files.isDirectory(start)) {
            dc.setInitialDirectory(start.toFile());
        }

        var folder = dc.showDialog(ide.stage);
        if (folder == null)
            return;

        saveIntoFolder(ide, folder.toPath());
    }

    /**
     * Writes the current tab into {@code folder} under its existing name and
     * re-points the tab at the new location, so subsequent plain saves go to
     * the same place. Semantic files are regenerated for .nc files exactly as
     * a normal save would.
     *
     * @param ide    the IDE controller
     * @param folder destination folder
     */
    public static void saveIntoFolder(UI_Main ide, Path folder) {
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null)
            return;

        if (folder == null || !Files.isDirectory(folder)) {
            EditorUIHelper.showError("Save failed",
                    new IOException("Not a folder: " + folder));
            return;
        }

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();
        String fileName = (info != null && info.path != null)
                ? info.path.getFileName().toString()
                : tab.getText().replace("*", "").trim();

        if (fileName.isEmpty()) {
            saveAsFile(ide);
            return;
        }

        Path target = folder.resolve(fileName);

        try {
            String text = EditorTextOperations.getEditorText(tab);
            Files.writeString(target, text);

            String ext = fileName.contains(".")
                    ? fileName.substring(fileName.lastIndexOf('.'))
                    : ".txt";

            EditorFileInfo saved = new EditorFileInfo(target, ext);
            tab.setUserData(saved);
            EditorFileStatus.remember(tab, text);

            if (LanguageDesignManager.isUpiFile(target)) {
                generateSemanticFiles(ide, saved);
            }

            tab.setText(fileName);
            ide.currentFolder = target.getParent();
            EditorUIHelper.updateFooter(ide, target, fileName);
            ProjectManager.refreshProjectTree(ide);
            ide.console.appendText("Saved: " + target + "\n");

        } catch (IOException e) {
            EditorUIHelper.showError("Save failed", e);
        }
    }

    /**
     * The folder the Save dialog opens in: the current folder (the File
     * Explorer's root), never the folder of a file that was merely opened.
     * Falls back to {@code ide.currentFolder} only when the explorer has no
     * folder, e.g. before the first folder has loaded.
     *
     * @param ide the IDE controller
     * @return an existing folder, or null to let the dialog choose
     */
    private static Path dialogFolder(UI_Main ide) {
        Path current = NavigationActions.projectFolder(ide);
        if (current != null && Files.isDirectory(current)) {
            return current;
        }
        if (ide.currentFolder != null && Files.isDirectory(ide.currentFolder)) {
            return ide.currentFolder;
        }
        return null;
    }

    /**
     * Applies symbol replacements to the current editor text.
     * 
     * @param ide the IDE controller
     */
    public static void applySymbolReplacements(UI_Main ide) {
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return;
        }

        String original = EditorTextOperations.getEditorText(tab);
        String replaced = LanguageDesignManager.applySymbolReplacements(original);
        EditorTextOperations.setEditorText(tab, replaced);
        ide.console.appendText("✔ Symbol replacements applied\n");
    }

    /**
     * Generates semantic and variable files for UPI files.
     * Creates cleaned code file and variables file.
     * 
     * @param ide  the IDE controller
     * @param info the file info
     * @param text the file content
     */
    private static void generateSemanticFiles(UI_Main ide, EditorFileInfo info) {
        try {
            String savedText = Files.readString(info.path);
            Path semanticPath = LanguageDesignManager.buildSemanticPath(info);
            // Preprocess saved text to preserve original variable identifiers (symbols)
            String preprocessed = LanguageDesignManager.preprocess(savedText);
            // Keep the variable file aligned with the editor text so the explorer
            // can render the same subscript/superscript markers that appear in the editor.
            LanguageDesignManager.normalizeMarkersForVariables(preprocessed);
            // Write semantic file (encoded) from saved text
            LanguageDesignManager.writeSemanticFileFromUiCode(savedText, semanticPath);
        } catch (Exception e) {
            UI_MainProgramControl.appendErrorText(ide,
                    "⚠ Error generating semantic files: " + e.getMessage() + "\n");
        }
    }
}
