package ui.editor.homeTab;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.WeakHashMap;
import java.util.regex.Pattern;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.WeakChangeListener;
import javafx.scene.Node;
import javafx.scene.control.Tab;
import javafx.scene.layout.Region;
import javafx.util.Duration;
import language.syntax.syntax_checker.ErrorChecker;
import language.syntax.syntax_checker.ErrorClassifier;
import language.syntax.syntax_checker.core.CheckContext;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorGutter;
import ui.editor.EditorTextOperations;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.RunScope;
import ui.managers.EditorManager;

/**
 * The <b>Step Runner</b>: block-aware stepping of the active {@code .nc}
 * script. Simple statements are stepped one per click; compound blocks are
 * stepped <em>into</em>, one statement per click, using the interpreter's
 * stepping protocol on the shared {@code nc.exe}.
 *
 * <h3>What changed (step-into)</h3>
 * <ul>
 *   <li><b>Blocks are stepped into.</b> When the next unit is a block
 *       ({@code for}, {@code while}, {@code if}, {@code function},
 *       {@code class}), {@link #dispatch} sends {@code @cmd stepinto}, then the
 *       block's lines. The interpreter pauses before each statement it runs
 *       and reports {@code @STEPAT <n>}, the n-th line of the block as sent;
 *       {@link #onStepAt} maps that back to the editor line, recorded at send
 *       time, and moves the arrow there. Each further Step click sends
 *       {@code @cmd stepnext} until the block is over, then the next click
 *       moves on to the next unit as before.</li>
 *   <li><b>One click, one statement.</b> A click while the interpreter is
 *       still running towards its next pause is ignored, so a quick double
 *       click can never queue a {@code stepnext} the interpreter has not asked
 *       for (which it would read at the following pause and skip a
 *       statement).</li>
 *   <li><b>Ending a block.</b> The block is over when the console settles at
 *       a prompt after the interpreter was told to continue from a pause. A
 *       block that never pauses at all -- a loop that runs zero times, a
 *       function or class definition, an {@code if} whose taken branch is
 *       empty -- is closed once the console has sat at a prompt for
 *       {@link #NO_PAUSE_SETTLE} with no pause reported. Without this, such a
 *       block left the runner sending {@code stepnext} into nothing forever.</li>
 *   <li><b>One paused block at a time.</b> There is one interpreter, so while
 *       a block is paused in one tab, Step in another tab says so instead of
 *       writing that tab's lines into the paused interpreter. The Command
 *       Window, Run and other IDE sends are held off by {@code CLI_Main} for
 *       the same reason.</li>
 *   <li><b>Self-healing.</b> {@link #dispatch} relaunches the interpreter if
 *       it has died (through {@code CLI_Main.ensureRunning}) rather than
 *       warning and skipping the step.</li>
 *   <li><b>Encoded lines.</b> Lines are sent through
 *       {@code CLI_Main.sendStepLine}, which encodes visual names
 *       ({@code \var(\mu)}, Tamil, Greek...) the way typed commands are.</li>
 *   <li><b>Stop.</b> A paused block counts as running: Stop kills and
 *       relaunches the interpreter as it does for a running command.
 *       {@link #reset} drops the paused block along with the arrows.</li>
 * </ul>
 *
 * <h3>Earlier change (classified errors)</h3>
 * When the step runner refuses to arm, or a unit fails its check, the Command
 * Window lists each error with its category and line --
 * "✖ Syntax Error (line 5): ..." -- using {@code ErrorClassifier}, the same
 * report the Run button prints.
 *
 * <h3>Block awareness</h3>
 * A header that ends with {@code :} ({@code for}, {@code while}, {@code if},
 * {@code function}, {@code class}) is grouped with everything up to and
 * including its closer ({@code fend}, {@code wend}, {@code iend},
 * {@code fnend}, {@code csend}) into a single execution <em>unit</em>.
 * {@code else:} and {@code elseif ...:} are branches inside an {@code if},
 * not new blocks. The header is never fed to the checker or backend on its
 * own. The runner does not echo lines: a {@code ;}-terminated statement stays
 * silent, a statement without {@code ;} prints its value (MATLAB-style).
 *
 * <h3>The current folder</h3>
 * A step run starts only for a saved file directly in the current folder (the
 * folder the File Explorer shows) or in a folder added to the path; any other
 * file brings up the same Neural Code Editor question as Run
 * ({@code RunScope.confirm}). Moving to another folder ends every step run
 * ({@code ProjectManager.loadProjectFromPath} calls {@link #reset}), so the
 * next Step starts from the top and asks again if it has to. When the first
 * unit of a run passes its check, the current folder is put at the top of
 * the breadcrumb's run-folder history
 * ({@code NavigationActions.recordRecentFolder}).
 *
 * <h3>Stop</h3>
 * {@link #reset} rewinds <b>every</b> step session, not only the selected
 * tab's, because there is one backend and Stop stops all of it. It is called by
 * {@code CLI_Main.stopExecution}, which every Stop control goes through.
 * {@link #activeProperty()} is true while any session has taken a step and
 * not yet finished or been reset; the ribbon's Stop stays enabled for that
 * time so the arrow can always be cleared, even between clicks.
 *
 * <h3>Gutter and highlight</h3>
 * The runner does NOT install a paragraph graphic factory of its own. The
 * arrow is an overlay in the gutter's error column, registered through
 * {@link EditorGutter#setErrorColumnOverlay}, so the gutter keeps its exact
 * geometry and the arrow survives fold / unfold. The line highlight adds and
 * removes its one style class and leaves every other class on the paragraph
 * alone (fold style, {@code error-line}). While a block is stepped into, the
 * whole block stays highlighted and the arrow walks its statements.
 */
public final class StepFileRunner {

    // =====================================================================
    // Neural Code grammar, as the step runner needs it
    // =====================================================================
    /** A logical line ending with this is a block header or a branch header. */
    private static final String BLOCK_OPENER_SUFFIX = ":";

    /**
     * Block closers. Each stands alone on its line; only a {@code #} comment
     * may follow it.
     */
    private static final Pattern BLOCK_CLOSER =
            Pattern.compile("^(?:iend|fend|wend|fnend|csend)\\b");

    /**
     * Branch headers inside an {@code if}. They end with {@code :} but continue
     * the current block rather than opening a new one.
     */
    private static final Pattern BRANCH_HEADER = Pattern.compile("^(?:elseif|else)\\b");

    /** Line-continuation marker: folds the next physical line into this one. */
    private static final String CONTINUATION = "~~";

    /**
     * Comment prefixes that make a line non-executable: {@code #}, and the
     * {@code \\ } prefix the Ctrl+? toggle writes. A single backslash is NOT a
     * comment -- {@code \var(...)} and {@code \con(...)} lines start with one.
     */
    private static final String[] COMMENT_PREFIXES = {"#", "\\\\"};

    /** Shown once per session when the interpreter cannot be started for a step. */
    private static final String BACKEND_DOWN_MESSAGE =
            "NC backend is not running; line not executed. Variables will not update until it starts.\n";

    /** Paragraph style class for the lines of the current unit. */
    private static final String STEP_LINE_CLASS = "step-current-line";

    /**
     * Arrow property holding its state listener. The session only keeps a weak
     * reference, so the arrow has to hold the strong one -- and when RichTextFX
     * discards the arrow, the listener goes with it.
     */
    private static final String ARROW_LISTENER_KEY = "step.arrow.stateListener";

    /**
     * How long the console must sit at a prompt, with no pause reported, before
     * a stepped-into block is taken to have finished without pausing.
     */
    private static final Duration NO_PAUSE_SETTLE = Duration.millis(500);

    /** Per-tab stepping state. Weak so closed tabs are collected. */
    private static final WeakHashMap<Tab, StepSession> SESSIONS = new WeakHashMap<>();

    /** True while any session is mid-run (has stepped, not finished or reset). */
    private static final ReadOnlyBooleanWrapper ACTIVE = new ReadOnlyBooleanWrapper(false);

    /** The session whose block is being stepped into, or null. One backend, so at most one. */
    private static StepSession activeSteppingSession;

    /** Closes a block that finished without ever pausing. */
    private static PauseTransition noPauseTimer;

    /** The session {@link #noPauseTimer} was armed for. */
    private static StepSession noPauseTarget;

    static {
        CLI_Main.setStepAtListener(StepFileRunner::onStepAt);
        CLI_Main.setStepIdleListener(StepFileRunner::onBackendIdle);
    }

    private StepFileRunner() {
    }

    // =====================================================================
    // Public entry points (wired from HomeRibbon)
    // =====================================================================

    /**
     * Executes the next unit of the active editor tab, or the next statement
     * of the block being stepped into.
     *
     * @param ide the IDE controller
     */
    public static void step(UI_Main ide) {
        try {
            stepOnce(ide);
        } finally {
            refreshActive();
        }
    }

    /**
     * True while a step run is in progress in any tab. Drives the ribbon
     * Stop's enabled state together with the Command Window's busy flag.
     *
     * @return read-only active property
     */
    public static ReadOnlyBooleanProperty activeProperty() {
        return ACTIVE.getReadOnlyProperty();
    }

    /**
     * True while a block has been sent with step-into and is not over yet: the
     * interpreter is paused, or running towards its next pause. Nothing but the
     * Step runner may write to the interpreter during that time.
     *
     * @return whether a stepped-into block is in progress
     */
    public static boolean isBlockInProgress() {
        return activeSteppingSession != null;
    }

    private static void refreshActive() {
        boolean any = false;
        for (StepSession session : new ArrayList<>(SESSIONS.values())) {
            if (session != null && session.pointer >= 0) {
                any = true;
                break;
            }
        }
        ACTIVE.set(any);
    }

    private static void stepOnce(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            CLI_Main.appendOutput("Step: no editor tab is open.\n");
            CLI_Main.appendPrompt();
            return;
        }
        CodeArea editor = codeAreaOf(tab);
        if (editor == null) {
            CLI_Main.appendOutput("Step runner works on Neural Code (.nc) tabs only.\n");
            CLI_Main.appendPrompt();
            return;
        }

        StepSession existing = SESSIONS.get(tab);

        // A block is being stepped into in another tab: its interpreter is
        // waiting for "stepnext", and must not be fed this tab's lines.
        StepSession stepping = activeSteppingSession;
        if (stepping != null && stepping != existing) {
            CLI_Main.appendOutput("Step: a block in " + stepping.fileName
                    + " is still being stepped. Switch back to it to continue, or press Stop.\n");
            CLI_Main.appendPrompt();
            return;
        }

        // Inside a block: run one more statement of it, not the next unit.
        if (existing != null && existing.blockInProgress) {
            if (existing.pauseOutstanding) {
                existing.pauseOutstanding = false;
                CLI_Main.sendStepControl(ide, CLI_Main.STEP_NEXT_COMMAND);
            }
            // Otherwise the interpreter is still running towards its next pause
            // (or the end of the block); the click is ignored so it never
            // receives a stepnext it has not asked for.
            return;
        }

        String text = EditorTextOperations.getEditorText(tab);
        StepSession session = existing;

        // Starting a step run (first click, edited text, or after a reset --
        // which a change of folder causes): the same rule as Run. Only a saved
        // file directly in the current folder, or on the path, may step; any
        // other file gets the Neural Code Editor question first.
        boolean starting = session == null || !text.equals(session.sourceSnapshot) || session.pointer < 0;
        if (starting) {
            Path file = filePathOf(tab);
            if (file == null) {
                CLI_Main.appendOutput("Cannot step: the active tab has no saved file yet.\n");
                CLI_Main.appendPrompt();
                return;
            }
            if (!RunScope.confirm(ide, file)) {
                return;
            }
            // The dialog may have changed folder, which resets every session.
            session = SESSIONS.get(tab);
            pointWorkspaceAtCurrentFolder(ide, file);
        }

        // (Re)build when there is no session yet, or the text changed under us.
        if (session == null || !text.equals(session.sourceSnapshot)) {
            // A whole-script syntax gate, exactly like Run does before it hands
            // the file to the interpreter. If the script is broken, refuse to
            // arm and say why, rather than stepping into a guaranteed error.
            var whole = ErrorChecker.analyzeErrors(text, checkContextOf(tab));
            if (whole.getErrorCount() > 0) {
                CLI_Main.appendOutput(ErrorClassifier.consoleReport(
                        whole.getClassification(), tabFileName(tab), "Step"));
                CLI_Main.appendOutput("Fix them, then step.\n");
                CLI_Main.appendPrompt();
                return;
            }
            session = new StepSession(text, tabFileName(tab));
            SESSIONS.put(tab, session);
            installGutter(editor, session);
            clearHighlight(editor, session);
            // Idempotent: never starts a second interpreter, but guarantees the
            // one backend is up before the first line is dispatched.
            EditorManager.startUPITerminal(ide);
            CLI_Main.appendOutput("Step runner armed: " + session.units.size()
                    + " unit(s).\n");
        }

        session.pointer++;

        // Ran off the end -> finish and rewind so a further click restarts.
        if (session.pointer >= session.units.size()) {
            CLI_Main.appendOutput("Step run complete.\n");
            CLI_Main.appendPrompt();
            clearHighlight(editor, session);
            session.currentPara.set(-1);
            session.state.set("none");
            session.pointer = -1;
            return;
        }

        Unit unit = session.units.get(session.pointer);
        showAt(editor, session, unit);

        // Cumulative check THROUGH the current unit. Because compound blocks are
        // grouped, the cumulative text is always syntactically complete (no
        // half-open "if:").
        String cumulative = session.cumulativeThrough(session.pointer);
        var report = ErrorChecker.analyzeErrors(cumulative, checkContextOf(tab));
        if (report.getErrorCount() > 0) {
            session.state.set("error");
            String where = unit.block ? "in the block starting at line " : "at line ";
            CLI_Main.appendOutput("\u2716 Step error " + where + unit.humanLine()
                    + ": " + unit.firstLine() + "\n");
            // The cumulative text starts at line 1 of the file, so the line
            // numbers in this report match the editor's.
            CLI_Main.appendOutput(ErrorClassifier.consoleReport(
                    report.getClassification(), tabFileName(tab), "Step"));
            CLI_Main.appendPrompt();
            return;
        }

        // Clean unit: forward it to the backend. No manual echo -- the backend
        // prints a value only when the statement omits ';'.
        session.state.set("ok");
        // The first clean unit of a step run is the moment the run really
        // goes ahead: the current folder joins the breadcrumb's run-folder
        // history, as it does for Run. Back / Forward are left to Run.
        if (session.pointer == 0) {
            try {
                Path file = filePathOf(tab);
                NavigationActions.recordRecentFolder(ide,
                        file != null ? file.toAbsolutePath().getParent() : null);
            } catch (RuntimeException bookkeeping) {
                bookkeeping.printStackTrace();
            }
        }
        dispatch(ide, session, unit);
    }

    /**
     * The syntax checker's view of the tab's file, so script calls
     * ({@code ABC;}) are checked against the file's own folder.
     */
    private static CheckContext checkContextOf(Tab tab) {
        if (tab != null && tab.getUserData() instanceof EditorFileInfo info) {
            return CheckContext.forFile(info.path);
        }
        return CheckContext.NONE;
    }

    /**
     * The file name to show in a Command Window report: the saved file's name,
     * else the tab's title without its unsaved-changes star.
     */
    private static String tabFileName(Tab tab) {
        if (tab.getUserData() instanceof EditorFileInfo info && info.path != null
                && info.path.getFileName() != null) {
            return info.path.getFileName().toString();
        }
        String title = tab.getText() == null ? "" : tab.getText();
        return title.endsWith("*") ? title.substring(0, title.length() - 1) : title;
    }

    /**
     * Stops every step run: clears each highlight and gutter arrow, drops any
     * block being stepped into and rewinds each program counter, so the next
     * Step starts from the top. Called by {@code CLI_Main.stopExecution}, which
     * every Stop control goes through, and when the interpreter dies with a
     * block paused.
     *
     * @param ide the IDE controller (unused beyond the null check; kept so
     *            existing callers compile)
     */
    public static void reset(UI_Main ide) {
        if (ide == null) {
            return;
        }
        try {
            for (var entry : new ArrayList<>(SESSIONS.entrySet())) {
                Tab tab = entry.getKey();
                StepSession session = entry.getValue();
                if (tab == null || session == null) {
                    continue;
                }
                CodeArea editor = codeAreaOf(tab);
                if (editor != null) {
                    clearHighlight(editor, session);
                } else {
                    session.highlighted.clear();
                }
                session.currentPara.set(-1);
                session.state.set("none");
                session.pointer = -1;
                session.clearBlockState();
            }
            activeSteppingSession = null;
            stopNoPauseTimer();
        } finally {
            refreshActive();
        }
    }

    // =====================================================================
    // Execution
    // =====================================================================

    /**
     * Sends one unit to the shared {@code nc.exe}.
     *
     * <p>A simple statement is sent as its line and runs at once (step-over).
     * A compound block is preceded by {@code @cmd stepinto}, so the
     * interpreter pauses before each statement it runs; the editor line of
     * every line sent is recorded so {@link #onStepAt} can put the arrow on it.
     * Blank and comment lines are not sent and so are not counted. The
     * backend's prompt-return refreshes the Variable Explorer on its own,
     * exactly as typing at the console does.
     */
    private static void dispatch(UI_Main ide, StepSession session, Unit unit) {
        if (!CLI_Main.ensureRunning(ide)) {
            if (!session.backendWarned) {
                CLI_Main.appendOutput(BACKEND_DOWN_MESSAGE);
                CLI_Main.appendPrompt();
                session.backendWarned = true;
            }
            return;
        }
        String[] physicalLines = unit.code.split("\n", -1);
        if (unit.block) {
            // Arm the pause hook before the block's first line leaves.
            CLI_Main.sendStepControl(ide, CLI_Main.STEP_INTO_COMMAND);
            session.clearBlockState();
            session.blockInProgress = true;
            activeSteppingSession = session;
        }
        for (int k = 0; k < physicalLines.length; k++) {
            // Blank and comment lines inside a block are for the reader only;
            // the interpreter never needs to see them.
            if (Program.isSkippable(physicalLines[k])) {
                continue;
            }
            if (unit.block) {
                session.sentParagraphs.add(unit.startPara + k);
            }
            CLI_Main.sendStepLine(ide, physicalLines[k]);
        }
    }

    /**
     * A pause report from the interpreter: move the arrow to that statement.
     * The pause counts even if the number cannot be mapped to a line, so the
     * next Step click still resumes it.
     */
    private static void onStepAt(int line) {
        StepSession session = activeSteppingSession;
        if (session == null || !session.blockInProgress) {
            return;
        }
        stopNoPauseTimer();
        session.sawPause = true;
        session.pauseOutstanding = true;
        if (line >= 1 && line <= session.sentParagraphs.size()) {
            session.currentPara.set(session.sentParagraphs.get(line - 1));
        }
    }

    /**
     * The console settled at a prompt. A block that has paused is over once
     * the interpreter, told to continue, comes back to a prompt instead of
     * pausing again. A block that has not paused yet may still be being read
     * in, so it is only closed after {@link #NO_PAUSE_SETTLE} at a prompt with
     * no pause reported.
     */
    private static void onBackendIdle() {
        StepSession session = activeSteppingSession;
        if (session == null || !session.blockInProgress || session.pauseOutstanding) {
            return;
        }
        if (session.sawPause) {
            finishBlock(session);
        } else {
            armNoPauseTimer(session);
        }
    }

    private static void armNoPauseTimer(StepSession session) {
        if (noPauseTimer == null) {
            noPauseTimer = new PauseTransition(NO_PAUSE_SETTLE);
            noPauseTimer.setOnFinished(e -> {
                StepSession target = noPauseTarget;
                noPauseTarget = null;
                if (target != null && target == activeSteppingSession && target.blockInProgress
                        && !target.sawPause && !target.pauseOutstanding && CLI_Main.isAtPrompt()) {
                    finishBlock(target);
                }
            });
        }
        noPauseTarget = session;
        noPauseTimer.playFromStart();
    }

    private static void stopNoPauseTimer() {
        if (noPauseTimer != null) {
            noPauseTimer.stop();
        }
        noPauseTarget = null;
    }

    /** The block is over: the next click moves on to the next unit. */
    private static void finishBlock(StepSession session) {
        session.clearBlockState();
        if (activeSteppingSession == session) {
            activeSteppingSession = null;
        }
        stopNoPauseTimer();
        CLI_Main.stepBlockFinished();
    }

    // =====================================================================
    // View: highlight + gutter arrow
    // =====================================================================

    private static void showAt(CodeArea editor, StepSession session, Unit unit) {
        clearHighlight(editor, session);
        for (int p = unit.startPara; p <= unit.endPara && p < editor.getParagraphs().size(); p++) {
            setStepLineStyle(editor, p, true);
            session.highlighted.add(p);
        }
        session.currentPara.set(unit.startPara);   // arrow rides the header row
        Platform.runLater(() -> {
            try {
                editor.showParagraphInViewport(unit.startPara);
                editor.moveTo(unit.startPara, 0);
            } catch (RuntimeException ignored) {
                // Paragraph index can race an edit; the next click recovers.
            }
        });
    }

    private static void clearHighlight(CodeArea editor, StepSession session) {
        for (int p : session.highlighted) {
            if (p < editor.getParagraphs().size()) {
                setStepLineStyle(editor, p, false);
            }
        }
        session.highlighted.clear();
    }

    /**
     * Adds or removes {@link #STEP_LINE_CLASS} on one paragraph, keeping every
     * other class it carries -- RichTextFX's fold style and ErrorStatusManager's
     * {@code error-line} in particular. No-op when nothing would change.
     */
    private static void setStepLineStyle(CodeArea editor, int paragraph, boolean on) {
        Collection<String> current;
        try {
            current = editor.getParagraph(paragraph).getParagraphStyle();
        } catch (RuntimeException e) {
            return;
        }
        boolean has = current != null && current.contains(STEP_LINE_CLASS);
        if (has == on) {
            return;
        }
        List<String> updated = new ArrayList<>();
        if (current != null) {
            for (String styleClass : current) {
                if (!STEP_LINE_CLASS.equals(styleClass)) {
                    updated.add(styleClass);
                }
            }
        }
        if (on) {
            updated.add(STEP_LINE_CLASS);
        }
        editor.setParagraphStyle(paragraph, updated);
    }

    /**
     * Puts this session's arrow into the editor gutter's error column.
     *
     * <p>The gutter itself is left exactly as {@code EditorGutter} built it, so
     * the band, the number slot, the fold column and the blank strip before the
     * code keep their widths and nothing moves. On the arrow's line the error
     * dot is hidden while the arrow shows (the column holds one or the other);
     * the line's error tooltip stays on the number.
     */
    private static void installGutter(CodeArea editor, StepSession session) {
        if (!EditorGutter.setErrorColumnOverlay(editor, index -> createArrow(session, index))) {
            // Not an editor built by EditorTabFactory: step without an arrow
            // rather than replace a gutter we know nothing about.
            System.err.println("Step runner: editor has no standard gutter; arrow not shown.");
        }
    }

    /**
     * The arrow for one line. Its size comes from {@code .step-arrow} in the
     * editor CSS (10px), which fits the 12px error column.
     */
    private static Node createArrow(StepSession session, int index) {
        Region arrow = new Region();
        arrow.getStyleClass().add("step-arrow");
        arrow.setMouseTransparent(true);
        arrow.setFocusTraversable(false);
        // Bindings.equal observes currentPara weakly, so discarded arrows are
        // collected normally.
        arrow.visibleProperty().bind(session.currentPara.isEqualTo(index));

        applyArrowState(arrow, session.state.get());
        ChangeListener<String> onState = (obs, was, now) -> applyArrowState(arrow, now);
        // Strong reference on the arrow, weak one on the session: rows are
        // rebuilt on every scroll and fold, and a strong listener per row used
        // to accumulate on the session for as long as the tab stayed open.
        arrow.getProperties().put(ARROW_LISTENER_KEY, onState);
        session.state.addListener(new WeakChangeListener<>(onState));
        return arrow;
    }

    private static void applyArrowState(Region arrow, String state) {
        arrow.getStyleClass().removeAll("step-arrow-ok", "step-arrow-error",
                "step-arrow-active", "step-arrow-none");
        arrow.getStyleClass().add("step-arrow-" + (state == null || state.isBlank() ? "none" : state));
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    /**
     * Points the backend at the current folder (the folder the File Explorer
     * shows), where script calls inside the stepped file are resolved. Since
     * only files in the current folder or on the path may step, the file's own
     * folder and the current folder agree, or the path covers the rest.
     */
    private static void pointWorkspaceAtCurrentFolder(UI_Main ide, Path file) {
        Path current = NavigationActions.projectFolder(ide);
        if (current == null && file != null) {
            current = file.toAbsolutePath().getParent();
        }
        if (current != null) {
            CLI_Main.setWorkspaceDirectory(current);
        }
    }

    /** @return the tab's saved file, or null for an untitled tab */
    private static Path filePathOf(Tab tab) {
        if (tab != null && tab.getUserData() instanceof EditorFileInfo info) {
            return info.path;
        }
        return null;
    }

    private static CodeArea codeAreaOf(Tab tab) {
        Node content = tab.getContent();
        if (content instanceof VirtualizedScrollPane<?> scroll
                && scroll.getContent() instanceof CodeArea code) {
            return code;
        }
        if (content instanceof CodeArea code) {
            return code;
        }
        return null;
    }

    // =====================================================================
    // Model
    // =====================================================================

    /**
     * One execution unit: a simple statement (one logical line) or a compound
     * block (header + indented body). {@code code} preserves the raw source
     * lines so a block is dispatched exactly as written.
     */
    private static final class Unit {
        final int startPara;
        final int endPara;
        final String code;
        final boolean block;

        Unit(int startPara, int endPara, String code, boolean block) {
            this.startPara = startPara;
            this.endPara = endPara;
            this.code = code;
            this.block = block;
        }

        int humanLine() {
            return startPara + 1;
        }

        /** The header line, for messages. */
        String firstLine() {
            int nl = code.indexOf('\n');
            return (nl < 0 ? code : code.substring(0, nl)).strip();
        }
    }

    /** Per-tab stepping state: the parsed program plus its live view bindings. */
    private static final class StepSession {
        final String sourceSnapshot;
        final String fileName;
        final List<Unit> units;
        final List<Integer> highlighted = new ArrayList<>();
        final IntegerProperty currentPara = new SimpleIntegerProperty(-1);
        final StringProperty state = new SimpleStringProperty("none");
        int pointer = -1;
        boolean backendWarned = false;

        // Step-into state for the block currently running (see dispatch()).
        /** A block was sent with step-into and is not over yet. */
        boolean blockInProgress = false;
        /** The interpreter has paused at least once in this block. */
        boolean sawPause = false;
        /** The interpreter is paused now, waiting for stepnext. */
        boolean pauseOutstanding = false;
        /** Editor paragraph of each line sent, in order; @STEPAT n is entry n-1. */
        final List<Integer> sentParagraphs = new ArrayList<>();

        StepSession(String source, String fileName) {
            this.sourceSnapshot = source;
            this.fileName = fileName == null || fileName.isBlank() ? "another tab" : fileName;
            this.units = new Program(source).parse();
        }

        void clearBlockState() {
            blockInProgress = false;
            sawPause = false;
            pauseOutstanding = false;
            sentParagraphs.clear();
        }

        /** Joins units 0..index, for a cumulative, syntactically complete check. */
        String cumulativeThrough(int index) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i <= index && i < units.size(); i++) {
                sb.append(units.get(i).code).append('\n');
            }
            return sb.toString();
        }
    }

    /**
     * Splits raw source into {@link Unit}s: skips blanks and comments, folds
     * {@code ~~} continuations, and groups each block header with everything up
     * to its matching closer.
     *
     * <p>Grouping is by keyword, not by indentation. Neural Code closes every
     * block with a word ({@code fend}, {@code wend}, {@code iend},
     * {@code fnend}, {@code csend}) that sits at the header's own indentation,
     * so an indentation rule would cut the closer off into a unit of its own
     * and treat {@code else:} as a fresh block.
     */
    private static final class Program {
        private final String[] lines;

        Program(String source) {
            this.lines = source.split("\n", -1);
        }

        List<Unit> parse() {
            List<Unit> out = new ArrayList<>();
            int i = 0;
            while (i < lines.length) {
                if (isSkippable(lines[i])) {
                    i++;
                    continue;
                }
                int headerEnd = logicalEnd(i);
                String headerText = logicalText(i, headerEnd);

                if (opensBlock(headerText)) {
                    int blockEnd = matchingCloser(headerEnd + 1);
                    out.add(new Unit(i, blockEnd, rawSpan(i, blockEnd), true));
                    i = blockEnd + 1;
                } else {
                    out.add(new Unit(i, headerEnd, headerText, false));
                    i = headerEnd + 1;
                }
            }
            return out;
        }

        /**
         * Walks forward from the first body line, counting nested openers and
         * closers, and returns the line index of the closer that ends the
         * block. An unterminated block runs to the end of the file; the
         * whole-script syntax gate in {@link StepFileRunner#step} rejects such
         * a file before it ever gets here.
         */
        private int matchingCloser(int from) {
            int depth = 1;
            int j = from;
            int last = from - 1;
            while (j < lines.length) {
                if (isSkippable(lines[j])) {
                    last = j;
                    j++;
                    continue;
                }
                int end = logicalEnd(j);
                String text = logicalText(j, end);
                if (BLOCK_CLOSER.matcher(text).find()) {
                    depth--;
                } else if (opensBlock(text)) {
                    depth++;
                }
                last = end;
                if (depth == 0) {
                    return end;
                }
                j = end + 1;
            }
            return Math.max(from - 1, Math.min(last, lines.length - 1));
        }

        /** Last physical line of the logical line starting at {@code start}. */
        private int logicalEnd(int start) {
            int end = start;
            while (endsWithContinuation(lines[end]) && end + 1 < lines.length) {
                end++;
            }
            return end;
        }

        /** The logical line {@code start..end} with continuations folded. */
        private String logicalText(int start, int end) {
            StringBuilder text = new StringBuilder(dropContinuation(strip(lines[start])));
            for (int k = start + 1; k <= end; k++) {
                text.append(' ').append(dropContinuation(strip(lines[k])));
            }
            return text.toString().strip();
        }

        /** Raw source lines a..b inclusive, indentation preserved. */
        private String rawSpan(int a, int b) {
            StringBuilder sb = new StringBuilder();
            for (int k = a; k <= b && k < lines.length; k++) {
                sb.append(lines[k]);
                if (k < b) {
                    sb.append('\n');
                }
            }
            return sb.toString();
        }

        /** A header ending in {@code :} that is not an {@code else}/{@code elseif} branch. */
        private static boolean opensBlock(String logicalLine) {
            return logicalLine.endsWith(BLOCK_OPENER_SUFFIX)
                    && !BRANCH_HEADER.matcher(logicalLine).find();
        }

        static boolean isSkippable(String line) {
            String t = strip(line);
            if (t.isEmpty()) {
                return true;
            }
            for (String c : COMMENT_PREFIXES) {
                if (t.startsWith(c)) {
                    return true;
                }
            }
            return false;
        }

        private static boolean endsWithContinuation(String line) {
            return strip(line).endsWith(CONTINUATION);
        }

        private static String dropContinuation(String s) {
            String t = s.strip();
            return t.endsWith(CONTINUATION) ? t.substring(0, t.length() - CONTINUATION.length()).strip() : t;
        }

        private static String strip(String s) {
            return s == null ? "" : s.strip();
        }
    }
}
