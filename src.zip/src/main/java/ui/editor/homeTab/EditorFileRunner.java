package ui.editor.homeTab;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

import javafx.scene.control.Tab;
import language.syntax.syntax_checker.ErrorChecker;
import language.syntax.syntax_checker.ErrorClassifier;
import language.syntax.syntax_checker.core.CheckContext;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.RunScope;
import ui.managers.EditorManager;
import ui.managers.LanguageDesignManager;

/**
 * Executes the file in the <b>currently selected</b> editor tab.
 *
 * <h3>What changed (the current folder decides)</h3>
 * <ul>
 *   <li><b>Only a file in the current folder runs.</b> The current folder is
 *       the folder the File Explorer and the breadcrumb show. A file sitting
 *       directly in it, or in a folder added to the path, runs at once. Any
 *       other file brings up the Neural Code Editor question --
 *       Add Path / Change folder &amp; Set as Root / Change Folder / Cancel --
 *       through {@link RunScope#confirm}; Cancel runs nothing.</li>
 *   <li><b>The interpreter's working folder is the current folder</b>, no
 *       longer the file's own folder. Run used to move {@code nc.exe} to
 *       wherever the file happened to be, which is why the explorer had no
 *       bearing on what ran where. Siblings of a file run from an added path
 *       are found through that path, as in MATLAB.</li>
 *   <li>The question comes before the error check, as MATLAB asks before it
 *       parses, and only for files Run can execute ({@code .nc}).</li>
 * </ul>
 *
 * <h3>Classified errors</h3>
 * A refused run now tells the user why. The script name is echoed at the
 * prompt as for a real run, then every error the editor found is listed with
 * its category and line, in the backend's own style:
 *
 * <pre>
 * &gt;&gt; t9_isolate3.nc
 * ✖ Unassigned Variable Error (line 9): 'DD' is declared but never given a value ...
 * ✖ Syntax Error (line 11): ';' is not allowed inside publish(...) ...
 * Run aborted: 2 error(s) in t9_isolate3.nc (1 Syntax, 1 Unassigned Variable).
 * &gt;&gt;
 * </pre>
 *
 * The rows come from {@code ErrorClassifier}, the same classification that
 * draws the gutter bars, so the Command Window and the editor always agree.
 * Nothing reaches {@code nc.exe} while an error remains.
 *
 * <h3>Earlier changes</h3>
 * <ul>
 *   <li><b>The cleaned file is what runs.</b> The previous version generated
 *       {@code cleaned_Runfile.nc} and then handed the interpreter the
 *       <em>original</em> source file name, so the cleaned file was written and
 *       thrown away.</li>
 *   <li><b>The full pipeline is used.</b> It also called
 *       {@code SemanticEncoder.encode} directly, skipping
 *       {@code applySymbolReplacements}, so it encoded a different string than
 *       {@code LanguageDesignManager} does. Both now go through
 *       {@link LanguageDesignManager#writeSemanticFileFromUiCode}.</li>
 *   <li><b>Only the active tab runs.</b> The tab is resolved once, up front,
 *       and nothing here iterates over open tabs.</li>
 *   <li><b>A run is recorded.</b> The project folder in force goes into the
 *       navigation bar's Back / Forward history and becomes the fallback root
 *       for Open Root Folder. {@code HomeFilesProject}'s comments always said
 *       the runner did this; until now it did not, so the fallback root was
 *       never set.</li>
 * </ul>
 */
public final class EditorFileRunner {

    private EditorFileRunner() {
    }

    /**
     * Saves and runs the file in the currently selected editor tab.
     *
     * @param ide the IDE controller
     */
    public static void runCurrentFile(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return;
        }

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();
        if (info == null || info.path == null) {
            CLI_Main.appendOutput("Cannot run: the active tab has no saved file yet.\n");
            CLI_Main.appendPrompt();
            return;
        }

        String extension = getExtension(info);
        if (!".nc".equals(extension) && !".upi".equals(extension)) {
            CLI_Main.appendOutput("Run is not configured for file type '"
                    + (extension.isEmpty() ? "unknown" : extension) + "'.\n");
            CLI_Main.appendPrompt();
            return;
        }

        // Only a file in the current folder (or on the path) runs. Anything
        // else asks first; Cancel ends the run here, with nothing printed.
        if (!RunScope.confirm(ide, info.path)) {
            return;
        }

        String editorText = EditorTextOperations.getEditorText(tab);
        // The folder is part of the check: a bare `ABC;` is valid only when
        // ABC.nc sits beside this file, in the current folder or on the path.
        var report = ErrorChecker.analyzeErrors(editorText, CheckContext.forFile(info.path));
        if (report.getErrorCount() > 0) {
            String name = info.path.getFileName().toString();
            CLI_Main.reportBlockedRun(ide, name,
                    ErrorClassifier.consoleReport(report.getClassification(), name, "Run"));
            return;
        }

        EditorManager.saveCurrentFile(ide);
        executeUpiFile(ide, info);
    }

    /**
     * Compatibility entry point retained for existing callers.
     *
     * @param ide the IDE controller
     */
    public static void integrateDemoCpp(UI_Main ide) {
        // The old demo integration is intentionally no longer required.
    }

    // -----------------------------------------------------------------
    // Internals
    // -----------------------------------------------------------------

    private static void executeUpiFile(UI_Main ide, EditorFileInfo info) {
        try {
            String text = Files.readString(info.path, StandardCharsets.UTF_8);
            Path cleaned = LanguageDesignManager.buildSemanticPath(info);
            LanguageDesignManager.writeSemanticFileFromUiCode(text, cleaned);

            // Script names are resolved against the current folder (then the
            // path), never against the temp folder the cleaned file lives in
            // and no longer against the file's own folder. Re-sent here only
            // as a safeguard; it is already set whenever the folder moves.
            Path parent = info.path.toAbsolutePath().getParent();
            Path current = NavigationActions.projectFolder(ide);
            CLI_Main.setWorkspaceDirectory(current != null ? current : parent);

            // The run is going ahead: record the project folder for Back /
            // Forward and as the fallback root. Guarded so a bookkeeping
            // failure can never stop the script from running.
            try {
                NavigationActions.recordRun(ide, parent);
            } catch (RuntimeException bookkeeping) {
                bookkeeping.printStackTrace();
            }

            // Echo the friendly name, execute the cleaned file.
            CLI_Main.runScript(ide, info.path.getFileName().toString(), cleaned);
        } catch (Exception e) {
            CLI_Main.appendOutput("NC execution failed: " + safeMessage(e) + "\n");
            CLI_Main.appendPrompt();
        }
    }

    private static String getExtension(EditorFileInfo info) {
        if (info.ext != null && !info.ext.isBlank()) {
            String extension = info.ext.toLowerCase(Locale.ROOT);
            return extension.startsWith(".") ? extension : "." + extension;
        }
        String name = info.path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : "";
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank()
                ? exception.getClass().getSimpleName()
                : message;
    }
}
