package ui.editor.homeTab;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

import javafx.application.Platform;
import javafx.scene.control.Tab;
import language.semantic.SemanticEncoder;
import language.syntax.syntax_checker.ErrorChecker;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;
import ui.managers.EditorManager;
import ui.managers.LanguageDesignManager;
import ui.ui_functions.UI_MainProgramControl;

/**
 * Handles execution of files opened in the editor.
 *
 * <p>NC files are preprocessed and semantically encoded, then executed by name
 * through the shared persistent CLI backend. C, C++, Java, and Python files
 * retain their process-based execution support.</p>
 */
public final class EditorFileRunner {

    private EditorFileRunner() {
        // Utility class.
    }

    /**
     * Saves and runs the file in the currently selected editor tab.
     *
     * @param ide the IDE controller
     */
    public static void runCurrentFile(UI_Main ide) {
        if (ide == null || ide.editorTabs == null) {
            return;
        }

        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            return;
        }

        EditorFileInfo info = (EditorFileInfo) tab.getUserData();
        if (info == null || info.path == null) {
            appendConsole(ide, "Cannot run: the active tab has no saved file yet.\n");
            return;
        }

        String editorText = EditorTextOperations.getEditorText(tab);
        var report = ErrorChecker.analyzeErrors(editorText);
        if (report.getErrorCount() > 0) {
            appendConsole(ide,
                    "Run aborted: " + report.getErrorCount() + " error(s) in "
                            + info.path.getFileName() + ".\n");
            return;
        }

        EditorManager.saveCurrentFile(ide);

        String file = info.path.toAbsolutePath().toString();
        String extension = getExtension(info);

        try {
            switch (extension) {
                case ".nc":
                case ".upi":
                    executeUpiFile(ide, tab);
                    break;


                default:
                    appendConsole(ide,
                            "Run is not configured for file type '"
                                    + (extension.isEmpty() ? "unknown" : extension) + "'.\n");
                    break;
            }
        } catch (Exception e) {
            UI_MainProgramControl.appendErrorText(
                    ide, "Execution failed: " + safeMessage(e) + "\n");
            UI_MainProgramControl.appendNextPrompt(ide);
        }
    }

    /**
     * Compatibility entry point retained for existing callers.
     *
     * @param ide the IDE controller
     */
    public static void integrateDemoCpp(UI_Main ide) {
        // The old demo integration is intentionally no longer required.
    }

    

    

    /**
     * Preprocesses an NC/UPI file, writes its semantic representation, and asks
     * the one persistent CLI backend to run the saved source file by name.
     */
    private static void executeUpiFile(UI_Main ide, Tab tab) {
        try {
            EditorFileInfo info = (EditorFileInfo) tab.getUserData();
            if (info == null || info.path == null) {
                throw new IllegalStateException("The active editor tab has no file path.");
            }

            String text = Files.readString(info.path, StandardCharsets.UTF_8);
            String cleaned = LanguageDesignManager.preprocess(text);
            String semanticCode = SemanticEncoder.encode(cleaned);

            // This path and semantic output are required by the language design flow.
            Path semanticPath = LanguageDesignManager.buildSemanticPath(info);
            Path parent = semanticPath.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(semanticPath, semanticCode, StandardCharsets.UTF_8);

            // Variable/dictionary generation is intentionally omitted because the
            // project now generates a different dictionary elsewhere.
            CLI_Main.runScriptByName(ide, info.path.getFileName().toString());
        } catch (Exception e) {
            UI_MainProgramControl.appendErrorText(
                    ide, "NC execution failed: " + safeMessage(e) + "\n");
            UI_MainProgramControl.appendNextPrompt(ide);
        }
    }

    private static void executeProcess(UI_Main ide, ProcessBuilder pb, EditorFileInfo info)
            throws IOException {
        Path parent = info.path.getParent();
        if (parent != null) {
            pb.directory(parent.toFile());
        }
        pb.redirectErrorStream(true);

        Process process = pb.start();
        ide.setRunningProcess(process);
        ide.setProgramRunning(true);

        Thread outputThread = new Thread(() -> {
            try (var input = process.getInputStream()) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = input.read(buffer)) != -1) {
                    String chunk = new String(buffer, 0, length, StandardCharsets.UTF_8);
                    Platform.runLater(() -> ide.appendProcessOutput(chunk));
                }
            } catch (IOException e) {
                Platform.runLater(() -> UI_MainProgramControl.appendErrorText(
                        ide, "Unable to read process output: " + safeMessage(e) + "\n"));
            }
        }, "editor-process-output");
        outputThread.setDaemon(true);
        outputThread.start();

        Thread completionThread = new Thread(() -> {
            try {
                int exitCode = process.waitFor();
                Platform.runLater(() -> {
                    ide.onProgramFinished();
                    ide.console.appendText("Program finished with exit code " + exitCode + ".\n");
                    UI_MainProgramControl.appendNextPrompt(ide);
                });
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                Platform.runLater(() -> {
                    ide.onProgramFinished();
                    UI_MainProgramControl.appendErrorText(ide, "Program execution was interrupted.\n");
                    UI_MainProgramControl.appendNextPrompt(ide);
                });
            }
        }, "editor-process-monitor");
        completionThread.setDaemon(true);
        completionThread.start();
    }

    private static String getExtension(EditorFileInfo info) {
        if (info.ext != null && !info.ext.isBlank()) {
            String extension = info.ext.toLowerCase(Locale.ROOT);
            return extension.startsWith(".") ? extension : "." + extension;
        }

        String name = info.path.getFileName().toString();
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : "";
    }

    private static String replaceExtension(String fileName, String replacement) {
        int dot = fileName.lastIndexOf('.');
        String base = dot > 0 ? fileName.substring(0, dot) : fileName;
        return base + replacement;
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank()
                ? exception.getClass().getSimpleName()
                : message;
    }

    private static void appendConsole(UI_Main ide, String message) {
        if (ide == null || ide.console == null || message == null) {
            return;
        }

        Platform.runLater(() -> {
            ide.console.appendText(message);
            ide.inputStart = ide.console.getLength();
            ide.console.positionCaret(ide.console.getLength());
        });
    }
}
