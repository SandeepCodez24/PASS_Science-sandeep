package ui.explorer;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import ui.design.Dim;

/**
 * The title strip along the top edge of a panel (File Explorer, Variable
 * Explorer, Command Window).
 *
 * <p>
 * A strip can carry a leading collapse triangle, a trailing options button, a
 * trailing close mark ({@link #withClose}), or none of them. Its colour is driven by the active state rather than being fixed:
 * the selected panel gets the navy strip, every other panel gets grey. Both
 * palettes live in the theme CSS via {@code .panel-active} and
 * {@code .panel-inactive}, so nothing here sets a colour.
 * </p>
 *
 * <h3>Where the numbers come from</h3>
 * <p>
 * Every dimension is read from {@code ui.design.Dim.TitleBar}. Padding, spacing
 * and the glyph-button box are applied through generated CSS
 * ({@code .panel-title-bar}, {@code .panel-title-button}); the strip
 * <em>height</em> is still set from Java because a collapsed panel's rail has to
 * match it exactly and must not depend on a stylesheet having loaded.
 * </p>
 */
public final class PanelTitleBar {

    /**
     * Height of the strip. Matches the collapsed height of a panel.
     *
     * <p>
     * Retained as a public constant because other panels size their rails
     * against it. It is now an alias for {@link Dim.TitleBar#HEIGHT} -- change
     * the value there, not here.
     * </p>
     */
    public static final double HEIGHT = Dim.TitleBar.HEIGHT;

    /** The close mark: the same glyph the Code Bot's strip uses. */
    private static final String CLOSE_GLYPH = "\u2715";

    /** Opacity of the close mark at rest; 1 under the pointer. */
    private static final double CLOSE_REST_OPACITY = 0.8;

    private final String title;
    private final HBox bar = new HBox();
    private final Label titleLabel;

    private TitleBarIcon toggleIcon;
    private Button toggleButton;
    private final List<TitleBarIcon> icons = new ArrayList<>();

    /**
     * Extra nodes that must follow this strip's active state, e.g. the vertical
     * rail a collapsed panel shows instead of the strip.
     */
    private final List<Node> companions = new ArrayList<>();

    private boolean active = false;

    private PanelTitleBar(String title) {
        this.title = title;

        titleLabel = new Label(title);
        titleLabel.getStyleClass().add("panel-title-label");

        bar.getStyleClass().add("panel-title-bar");
        bar.setAlignment(Pos.CENTER_LEFT);
        // Height is pinned from Java: the collapsed rail is sized against
        // HEIGHT, so the two must agree even before any stylesheet is applied.
        // Padding and spacing come from the generated .panel-title-bar rule.
        bar.setMinHeight(Dim.TitleBar.HEIGHT);
        bar.setPrefHeight(Dim.TitleBar.HEIGHT);
        bar.setMaxHeight(Dim.TitleBar.HEIGHT);
        bar.setMaxWidth(Double.MAX_VALUE);

        applyStateClasses(bar, false);
    }

    /**
     * A plain strip: title only.
     *
     * @param title text shown at the left
     * @return the strip
     */
    public static PanelTitleBar create(String title) {
        PanelTitleBar h = new PanelTitleBar(title);
        h.bar.getChildren().addAll(h.titleLabel, spacer());
        return h;
    }

    /**
     * A strip with a MATLAB-style collapse triangle immediately before the
     * title: pointing down when expanded, right when collapsed.
     *
     * @param title    text shown after the triangle
     * @param onToggle run when the triangle is clicked
     * @return the strip
     */
    public static PanelTitleBar withToggle(String title, Runnable onToggle) {
        PanelTitleBar h = new PanelTitleBar(title);
        h.toggleIcon = new TitleBarIcon(TitleBarIcon.CARET_DOWN, Dim.TitleBar.CARET_ICON_SIZE);
        h.icons.add(h.toggleIcon);

        Button t = glyphButton(h.toggleIcon, "Collapse / expand " + title);
        t.setOnAction(e -> onToggle.run());
        h.toggleButton = t;

        h.bar.getChildren().addAll(t, h.titleLabel, spacer());
        return h;
    }

    /**
     * Adds a three-dot options button at the right end of the strip.
     *
     * @param menuSupplier builds the menu fresh on each click, so item labels
     *                     can reflect current state (Minimize vs Restore)
     * @return this strip, for chaining
     */
    public PanelTitleBar withMenu(Supplier<ContextMenu> menuSupplier) {
        TitleBarIcon dotsIcon = new TitleBarIcon(TitleBarIcon.DOTS, Dim.TitleBar.DOTS_ICON_SIZE);
        icons.add(dotsIcon);

        Button m = glyphButton(dotsIcon, title + " options");
        m.setOnAction(e -> {
            ContextMenu menu = menuSupplier.get();
            Bounds b = m.localToScreen(m.getBoundsInLocal());
            if (b != null) {
                menu.show(m, b.getMinX(), b.getMaxY());
            } else {
                menu.show(m, javafx.geometry.Side.BOTTOM, 0, 0);
            }
        });

        bar.getChildren().add(m);
        setActive(active);
        return this;
    }

    /**
     * Adds a close mark ({@code \u2715}) at the right end of the strip, as on
     * the Code Bot.
     *
     * <p>
     * The mark is a label, not a button, so it brings no background of its
     * own. It carries {@code panel-title-label} as well as
     * {@code panel-title-close}, so it takes the title's font and the title's
     * colour from the theme: white on the navy (active) strip, dark on the
     * grey one, in both themes. It brightens from {@value #CLOSE_REST_OPACITY}
     * to full opacity under the pointer, the hover the navigation bar's
     * path-row cross already uses.
     * </p>
     *
     * @param onClose run when the mark is clicked
     * @return this strip, for chaining
     */
    public PanelTitleBar withClose(Runnable onClose) {
        Label close = new Label(CLOSE_GLYPH);
        close.getStyleClass().addAll("panel-title-label", "panel-title-close");
        close.setPadding(new Insets(0, Dim.TitleBar.GLYPH_BUTTON_PADDING,
                0, Dim.TitleBar.GLYPH_BUTTON_PADDING));
        close.setCursor(Cursor.HAND);
        close.setFocusTraversable(false);
        close.setOpacity(CLOSE_REST_OPACITY);
        close.setOnMouseEntered(e -> close.setOpacity(1.0));
        close.setOnMouseExited(e -> close.setOpacity(CLOSE_REST_OPACITY));
        Tooltip.install(close, new Tooltip("Close " + title));
        close.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.PRIMARY && onClose != null) {
                e.consume();
                onClose.run();
            }
        });
        // After the strip's spacer, so it sits at the right end.
        bar.getChildren().add(close);
        return this;
    }

    /**
     * @return the strip node
     */
    public HBox getNode() {
        return bar;
    }

    /**
     * @return the panel title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Registers a node that should share this strip's active colouring.
     *
     * @param node a node carrying the {@code .panel-title-bar} class
     * @param icon an icon on that node, or null
     */
    public void addCompanion(Node node, TitleBarIcon icon) {
        if (node != null) {
            companions.add(node);
            applyStateClasses(node, active);
        }
        if (icon != null) {
            icons.add(icon);
            icon.setActive(active);
        }
    }

    /**
     * Navy when active, grey when not.
     *
     * @param active true if this panel is the selected one
     */
    public void setActive(boolean active) {
        this.active = active;
        applyStateClasses(bar, active);
        for (Node n : companions) {
            applyStateClasses(n, active);
        }
        for (TitleBarIcon icon : icons) {
            icon.setActive(active);
        }
    }

    /**
     * @return true if this panel is the selected one
     */
    public boolean isActive() {
        return active;
    }

    /**
     * Points the collapse triangle down (expanded) or right (collapsed).
     * No-op on strips built without a triangle.
     *
     * @param expanded true for the down-pointing triangle
     */
    public void setExpandedState(boolean expanded) {
        if (toggleIcon != null) {
            toggleIcon.setBase(expanded ? TitleBarIcon.CARET_DOWN : TitleBarIcon.CARET_RIGHT);
        }
    }

    /**
     * Enables or disables the collapse triangle. A layout that stacks the
     * panel vertically (Bot Centered puts the Variable Explorer under the
     * editor) disables it, because the panel collapses to a vertical rail,
     * which only makes sense in a side-by-side split. No-op on strips built
     * without a triangle.
     *
     * @param enabled true to allow collapsing
     */
    public void setToggleEnabled(boolean enabled) {
        if (toggleButton == null) {
            return;
        }
        toggleButton.setDisable(!enabled);
        toggleButton.setTooltip(new Tooltip(enabled
                ? "Collapse / expand " + title
                : title + " cannot collapse in this layout"));
    }

    /**
     * A flat, transparent button sized for a title-strip glyph.
     *
     * <p>
     * The box is set from Java as well as CSS so that a strip laid out before
     * its stylesheet resolves does not jump. Both read
     * {@link Dim.TitleBar#GLYPH_BUTTON_SIZE}.
     * </p>
     *
     * @param icon the glyph
     * @param tip  tooltip text
     * @return the button
     */
    public static Button glyphButton(TitleBarIcon icon, String tip) {
        double box = Dim.TitleBar.GLYPH_BUTTON_SIZE;
        Button b = new Button("", icon.getView());
        b.getStyleClass().add("panel-title-button");
        b.setFocusTraversable(false);
        b.setMinSize(box, box);
        b.setPrefSize(box, box);
        b.setMaxSize(box, box);
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    private static void applyStateClasses(Node node, boolean active) {
        node.getStyleClass().removeAll("panel-active", "panel-inactive");
        node.getStyleClass().add(active ? "panel-active" : "panel-inactive");
    }

    private static Region spacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }
}
