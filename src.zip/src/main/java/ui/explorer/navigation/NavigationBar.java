package ui.explorer.navigation;

import java.nio.file.Path;
import java.util.List;

import javafx.application.Platform;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Cursor;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.CustomMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.homeTab.HomeFilesProject;
import ui.editor.navigation.CloudFolders;
import ui.editor.navigation.DefaultFolders;
import ui.editor.navigation.FolderHistory;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.RootFolderStore;
import ui.editor.navigation.SearchPath;
import ui.ui_functions.tools.ToolbarButtons;

/**
 * The left half of the quick-access row: six icon buttons in this order.
 *
 * <pre>
 *  [Home] [&lt;-] [-&gt;] [Up] | [Cloud] [Root|v] |
 * </pre>
 *
 * <table>
 * <caption>What each one does</caption>
 * <tr><td>Home</td><td>{@code Documents\NeuralCode}, created if missing.</td></tr>
 * <tr><td>Back / Forward</td><td>Step through the folders a file was run in
 * ({@code FolderHistory}). Greyed out when there is nowhere to go.</td></tr>
 * <tr><td>Up</td><td>One level above the folder shown. Greyed out at a drive
 * root.</td></tr>
 * <tr><td>Cloud</td><td>OneDrive. One folder: go straight there. Several
 * (personal and work): a small menu. None: a note in the Command
 * Window.</td></tr>
 * <tr><td>Root</td><td>Split control. The icon opens the root folder (declared,
 * else last run folder); the narrow chevron zone opens a menu with "Set current
 * folder as root" and "Clear root", and below them the path section: the
 * current folder and every folder added to the path this session.</td></tr>
 * </table>
 *
 * <h3>The Root menu's path section</h3>
 * <pre>
 *  Root: D:\Projects                       (status)
 *  ----------------------------------------
 *  Open Root Folder
 *  Set current folder as root  (Proj)
 *  Clear root
 *  ----------------------------------------
 *  Current folder: D:\Projects\Proj        (status)
 *  Added to path (this session)            (heading, only when not empty)
 *    D:\Projects\Proj\QWQ             [x]  click: open it; [x]: remove it
 *    E:\Shared\lib                    [x]
 *  Add Folder to Path...
 *  Clear Added Paths
 * </pre>
 * <p>
 * The root folder and the current folder are different things: the root is a
 * bookmark, the current folder is where scripts run. The first block of the
 * menu is about the bookmark and is unchanged; the second is about running.
 * </p>
 *
 * <h3>Menus</h3>
 * <p>
 * The Cloud and Root menus are built with {@link BreadcrumbBar#newMenu()} and
 * {@link BreadcrumbBar#menuEntry}, so every drop-down in the quick-access row
 * has the directory explorer's font size and item padding, and a path or
 * OneDrive name containing an underscore is shown with it rather than having
 * it swallowed as a mnemonic.
 * </p>
 *
 * <p>
 * All behaviour lives in {@code ui.editor.navigation.NavigationActions}; this
 * class builds controls and keeps their enabled state and tooltips current.
 * </p>
 */
public final class NavigationBar {

    private static final String SPLIT_CLASS = "quick-nav-split";
    private static final String SPLIT_ICON_CLASS = "quick-nav-split-icon";
    private static final String SPLIT_ARROW_CLASS = "quick-nav-split-arrow";
    private static final String MENU_SHOWING_CLASS = "menu-showing";

    private static Button backButton;
    private static Button forwardButton;
    private static Button upButton;
    private static Button rootIconZone;
    private static Tooltip rootTip;
    private static UI_Main owner;

    private NavigationBar() {
    }

    /**
     * Builds the buttons, in bar order, with their separators.
     *
     * @param ide the IDE controller
     * @return the nodes to add to the quick-access ToolBar, left to right
     */
    public static List<Node> build(UI_Main ide) {
        owner = ide;

        Button home = button(NaviBreadIcons.HOME, "Home - Documents\\" + DefaultFolders.NEURAL_CODE_FOLDER,
                () -> NavigationActions.goHome(ide));

        backButton = button(NaviBreadIcons.BACK, "Back - previous run folder",
                () -> NavigationActions.goBack(ide));

        forwardButton = button(NaviBreadIcons.FORWARD, "Forward - next run folder",
                () -> NavigationActions.goForward(ide));

        upButton = button(NaviBreadIcons.UP, "Up one level",
                () -> NavigationActions.goUp(ide));

        Button cloud = button(NaviBreadIcons.CLOUD, "Cloud - OneDrive", null);
        cloud.setOnAction(e -> openCloud(ide, cloud));

        HBox root = buildRootControl(ide);

        FolderHistory.addListener(NavigationBar::refreshStateLater);
        RootFolderStore.addListener(NavigationBar::refreshStateLater);
        SearchPath.addListener(NavigationBar::refreshStateLater);
        refreshState();

        return List.of(
                home, backButton, forwardButton, upButton,
                new Separator(Orientation.VERTICAL),
                cloud, root,
                new Separator(Orientation.VERTICAL));
    }

    /**
     * Re-evaluates which buttons are enabled and what the Root tooltip says.
     * The breadcrumb calls this after every redraw, since the folder shown
     * decides whether Back and Up have anywhere to go.
     */
    public static void refreshState() {
        UI_Main ide = owner;
        if (ide == null) {
            return;
        }
        if (backButton != null) {
            backButton.setDisable(!NavigationActions.canGoBack(ide));
        }
        if (forwardButton != null) {
            forwardButton.setDisable(!NavigationActions.canGoForward());
        }
        if (upButton != null) {
            upButton.setDisable(!NavigationActions.canGoUp(ide));
        }
        if (rootTip != null) {
            rootTip.setText(rootTooltipText());
        }
    }

    private static void refreshStateLater() {
        if (Platform.isFxApplicationThread()) {
            refreshState();
        } else {
            Platform.runLater(NavigationBar::refreshState);
        }
    }

    // =================================================================
    // Cloud
    // =================================================================

    private static void openCloud(UI_Main ide, Button anchor) {
        List<Path> folders = CloudFolders.folders();
        if (folders.isEmpty()) {
            NavigationActions.say("No OneDrive folder was found on this PC.");
            return;
        }
        if (folders.size() == 1) {
            NavigationActions.goTo(ide, folders.get(0));
            return;
        }
        PopupMenuToggle.toggle(anchor, () -> {
            ContextMenu menu = BreadcrumbBar.newMenu();
            for (Path folder : CloudFolders.folders()) {
                MenuItem item = BreadcrumbBar.menuEntry(CloudFolders.label(folder), menuIcon(NaviBreadIcons.CLOUD));
                item.setOnAction(ev -> NavigationActions.goTo(ide, folder));
                menu.getItems().add(item);
            }
            return menu;
        });
    }

    // =================================================================
    // Root split control
    // =================================================================

    /**
     * {@code [icon | v]} inside one outline, like the ribbon's split buttons
     * turned on their side: the icon runs the default action, the chevron
     * zone opens the menu.
     */
    private static HBox buildRootControl(UI_Main ide) {
        rootIconZone = new Button("", NaviBreadIcons.icon(NaviBreadIcons.ROOT, Dim.NavigationBar.ICON_SIZE));
        rootIconZone.getStyleClass().add(SPLIT_ICON_CLASS);
        rootIconZone.setFocusTraversable(false);
        rootTip = new Tooltip(rootTooltipText());
        rootIconZone.setTooltip(rootTip);
        rootIconZone.setOnAction(e -> NavigationActions.goToRoot(ide));

        ImageView chevron = NaviBreadIcons.icon(NaviBreadIcons.CHEVRON_DOWN,
                Dim.NavigationBar.SPLIT_ARROW_ICON_SIZE);
        Button arrowZone = new Button("", chevron);
        arrowZone.getStyleClass().add(SPLIT_ARROW_CLASS);
        arrowZone.setFocusTraversable(false);
        arrowZone.setTooltip(new Tooltip("Root folder options"));

        HBox split = new HBox(rootIconZone, arrowZone);
        split.getStyleClass().add(SPLIT_CLASS);
        split.setAlignment(Pos.CENTER_LEFT);
        split.setFillHeight(true);

        arrowZone.setOnAction(e -> PopupMenuToggle.toggle(split,
                () -> buildRootMenu(ide),
                () -> arrowZone.getStyleClass().add(MENU_SHOWING_CLASS),
                () -> arrowZone.getStyleClass().remove(MENU_SHOWING_CLASS)));

        // A right-click anywhere on the control opens the same menu, which is
        // what most people try first on an icon-only button. The context-menu
        // request bubbles up from both zones, so one handler covers them.
        split.setOnContextMenuRequested(e -> {
            e.consume();
            arrowZone.fire();
        });

        return split;
    }

    private static ContextMenu buildRootMenu(UI_Main ide) {
        ContextMenu menu = BreadcrumbBar.newMenu();

        Path declared = RootFolderStore.stored();
        MenuItem status = BreadcrumbBar.menuEntry(declared != null
                ? "Root: " + declared + (FolderPaths.isFolder(declared) ? "" : "  (not reachable)")
                : "No root set" + fallbackSuffix(), null);
        status.setDisable(true);

        MenuItem open = BreadcrumbBar.menuEntry("Open Root Folder", menuIcon(NaviBreadIcons.ROOT));
        open.setOnAction(e -> NavigationActions.goToRoot(ide));

        Path shown = NavigationActions.shownFolder(ide);
        MenuItem set = BreadcrumbBar.menuEntry(shown != null
                ? "Set current folder as root  (" + FolderPaths.label(shown) + ")"
                : "Set current folder as root",
                menuIcon(NaviBreadIcons.ROOT_SET));
        set.setDisable(shown == null || FolderPaths.same(shown, declared));
        set.setOnAction(e -> NavigationActions.declareShownAsRoot(ide));

        MenuItem clear = BreadcrumbBar.menuEntry("Clear root", menuIcon(NaviBreadIcons.ROOT_CLEAR));
        clear.setDisable(declared == null);
        clear.setOnAction(e -> NavigationActions.clearRoot(ide));

        menu.getItems().addAll(status, new SeparatorMenuItem(), open, set, clear);
        addPathSection(ide, menu, shown);
        return menu;
    }

    /**
     * The current folder and the folders on the path, below the root entries.
     * See the class comment for the layout.
     */
    private static void addPathSection(UI_Main ide, ContextMenu menu, Path shown) {
        menu.getItems().add(new SeparatorMenuItem());

        MenuItem current = BreadcrumbBar.menuEntry(shown != null
                ? "Current folder: " + shown
                : "No current folder", pathIcon(PathIcons.CURRENT_FOLDER));
        current.setDisable(true);
        menu.getItems().add(current);

        List<Path> added = SearchPath.folders();
        if (!added.isEmpty()) {
            MenuItem heading = BreadcrumbBar.menuEntry("Added to path (this session)", null);
            heading.setDisable(true);
            menu.getItems().add(heading);
            for (Path folder : added) {
                menu.getItems().add(pathRow(ide, menu, folder));
            }
        }

        MenuItem add = BreadcrumbBar.menuEntry("Add Folder to Path...", pathIcon(PathIcons.PATH_ADD));
        add.setOnAction(e -> NavigationActions.chooseFolderForPath(ide));

        MenuItem clearAll = BreadcrumbBar.menuEntry("Clear Added Paths", pathIcon(PathIcons.PATH_CLEAR));
        clearAll.setDisable(added.isEmpty());
        clearAll.setOnAction(e -> NavigationActions.clearAddedPaths(ide));

        menu.getItems().addAll(add, clearAll);
    }

    /**
     * One folder on the path: clicking the row opens it as the current folder,
     * clicking the cross at its right end removes it from the path.
     */
    private static MenuItem pathRow(UI_Main ide, ContextMenu menu, Path folder) {
        Label text = new Label(folder.toString(), pathIcon(PathIcons.PATH_FOLDER));
        text.setMnemonicParsing(false);
        text.setGraphicTextGap(Dim.NavigationBar.ITEM_SPACING * 3);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        StackPane remove = new StackPane(pathIcon(PathIcons.PATH_REMOVE));
        remove.setCursor(Cursor.HAND);
        remove.setOpacity(0.55);
        remove.setOnMouseEntered(e -> remove.setOpacity(1.0));
        remove.setOnMouseExited(e -> remove.setOpacity(0.55));
        Tooltip.install(remove, new Tooltip("Remove from path"));

        HBox row = new HBox(text, spacer, remove);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setSpacing(Dim.NavigationBar.ITEM_SPACING * 6);

        CustomMenuItem item = new CustomMenuItem(row, true);
        item.setMnemonicParsing(false);
        item.setOnAction(e -> NavigationActions.goTo(ide, folder));

        // The menu fires its item on mouse release; take the release on the
        // cross first, so it removes the folder instead of opening it.
        remove.addEventFilter(MouseEvent.MOUSE_RELEASED, e -> {
            e.consume();
            menu.hide();
            NavigationActions.removeFromPath(ide, folder);
        });
        return item;
    }

    /** A path-section icon at the breadcrumb menus' icon size, in the current theme. */
    private static ImageView pathIcon(String name) {
        UI_Main ide = owner;
        return PathIcons.icon(name, Dim.BreadcrumbBar.MENU_ICON_SIZE,
                ide == null ? null : ide.stage);
    }

    private static String rootTooltipText() {
        Path declared = RootFolderStore.stored();
        if (declared != null) {
            return "Root folder: " + declared;
        }
        return "Root folder: not set" + fallbackSuffix();
    }

    private static String fallbackSuffix() {
        Path runRoot = HomeFilesProject.runRoot();
        return runRoot != null ? " - opens last run folder " + runRoot : "";
    }

    // =================================================================
    // Plumbing
    // =================================================================

    /**
     * An icon for the Cloud and Root menus, the same size as the breadcrumb
     * menu icons so the two sets of menus line up.
     */
    private static ImageView menuIcon(String name) {
        return NaviBreadIcons.icon(name, Dim.BreadcrumbBar.MENU_ICON_SIZE);
    }

    private static Button button(String iconName, String tooltip, Runnable action) {
        Button b = new Button("", NaviBreadIcons.icon(iconName, Dim.NavigationBar.ICON_SIZE));
        b.setFocusTraversable(false);
        b.setStyle("");
        if (!b.getStyleClass().contains(ToolbarButtons.NAV_BUTTON_CLASS)) {
            b.getStyleClass().add(ToolbarButtons.NAV_BUTTON_CLASS);
        }
        b.setTooltip(new Tooltip(tooltip));
        if (action != null) {
            b.setOnAction(e -> action.run());
        }
        return b;
    }
}
