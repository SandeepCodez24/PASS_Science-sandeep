package ui.explorer.navigation;

import java.io.InputStream;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Window;

/**
 * The icons of the current-folder / search-path feature: the information mark
 * of the choice dialog and the entries of the Root menu's path section.
 *
 * <p>
 * One 48 x 48 master per icon per theme, under
 * {@code src/main/resources/icons/path_icons/light} and {@code .../dark},
 * scaled down by the {@link ImageView} with smoothing. The theme is read from
 * the IDE scene's stylesheets each time an icon is asked for, and menus and
 * dialogs are built fresh every time they open, so a theme switch is picked
 * up without any listener.
 * </p>
 */
public final class PathIcons {

    /** Blue "i" in a ring; the choice dialog's mark. */
    public static final String INFO = "info";

    /** A plain folder; an entry on the path. */
    public static final String PATH_FOLDER = "path_folder";

    /** A folder with a blue dot; the current folder. */
    public static final String CURRENT_FOLDER = "current_folder";

    /** A folder with a green plus; Add Folder to Path. */
    public static final String PATH_ADD = "path_add";

    /** A red cross; removes one entry from the path. */
    public static final String PATH_REMOVE = "path_remove";

    /** Two folders with a red minus; Clear Added Paths. */
    public static final String PATH_CLEAR = "path_clear";

    private static final String BASE = "/icons/path_icons/";

    private static final Map<String, Image> CACHE = new ConcurrentHashMap<>();

    private PathIcons() {
    }

    /**
     * @param name  one of the constants above
     * @param size  edge length in pixels
     * @param owner a window of the IDE, used to tell the theme; may be null
     * @return the icon, or an empty view if the file is missing
     */
    public static ImageView icon(String name, double size, Window owner) {
        return icon(name, size, isDark(owner == null ? null : owner.getScene()));
    }

    /**
     * @param name one of the constants above
     * @param size edge length in pixels
     * @param dark true for the dark-theme variant
     * @return the icon, or an empty view if the file is missing
     */
    public static ImageView icon(String name, double size, boolean dark) {
        ImageView view = new ImageView();
        Image image = load(name, dark);
        if (image != null) {
            view.setImage(image);
        }
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        return view;
    }

    /**
     * @param scene the IDE scene; may be null
     * @return true when its theme sheet is a dark one
     */
    public static boolean isDark(Scene scene) {
        if (scene == null) {
            return false;
        }
        for (String sheet : scene.getStylesheets()) {
            String lower = sheet == null ? "" : sheet.toLowerCase(Locale.ROOT);
            if (lower.endsWith("dark.css")) {
                return true;
            }
        }
        return false;
    }

    private static Image load(String name, boolean dark) {
        String path = BASE + (dark ? "dark/" : "light/") + name + ".png";
        return CACHE.computeIfAbsent(path, key -> {
            try (InputStream in = PathIcons.class.getResourceAsStream(key)) {
                return in == null ? null : new Image(in);
            } catch (Exception e) {
                return null;
            }
        });
    }
}
