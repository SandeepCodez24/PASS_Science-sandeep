package ui.explorer.navigation;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import ui.design.Dim;

/**
 * A modal question in the Neural Code Editor style: a grey title strip, a
 * blue information mark beside the message, and a row of buttons.
 *
 * <pre>
 *  +----------------------------------------------------------------+
 *  | Neural Code Editor                                         [x] |
 *  +----------------------------------------------------------------+
 *  |  (i)  headline                                                 |
 *  |       message                                                  |
 *  |       detail (muted)                                           |
 *  +----------------------------------------------------------------+
 *  | [left] [left]                       | [default] [cancel] |     |
 *  +----------------------------------------------------------------+
 * </pre>
 *
 * <p>
 * Left-hand choices are drawn as raised buttons; right-hand ones sit on a
 * light panel, the way the mockup shows Change Folder and Cancel. One choice
 * may be the default (Enter, heavier blue outline, focused on open) and one
 * the cancel (Esc, the close glyph). Closing the window any other way also
 * answers with the cancel choice.
 * </p>
 *
 * <p>
 * Geometry and fonts come from the generated sheet ({@code .choice-dialog-*},
 * {@code Dim.ChoiceDialog}); colours from
 * {@code themes/choice_dialog/choice_dialog_light.css} or {@code _dark.css},
 * picked from the IDE window's theme when the dialog opens.
 * </p>
 */
public final class ChoiceDialog {

    /** Title of every dialog of this kind. */
    public static final String TITLE = "Neural Code Editor";

    private static final String LIGHT_SHEET = "/themes/choice_dialog/choice_dialog_light.css";
    private static final String DARK_SHEET = "/themes/choice_dialog/choice_dialog_dark.css";

    /** Which side of the footer a choice sits on. */
    public enum Side {
        /** Raised buttons at the left. */
        LEFT,
        /** Flat buttons on the light panel at the right. */
        RIGHT
    }

    /**
     * One button.
     *
     * @param id        returned by {@link #show} when this button is chosen
     * @param label     button text; may contain a newline for two lines
     * @param tooltip   hover text; may be null
     * @param side      where the button sits
     * @param isDefault true for the Enter button (at most one)
     * @param isCancel  true for the Esc button (at most one)
     */
    public record Choice(String id, String label, String tooltip, Side side, boolean isDefault, boolean isCancel) {
    }

    private ChoiceDialog() {
    }

    /**
     * Shows the dialog and waits for an answer.
     *
     * @param owner    the IDE window; may be null
     * @param headline first line, e.g. what happened
     * @param message  the paragraph under it; may be null
     * @param detail   a muted line under that; may be null
     * @param choices  the buttons, in footer order (left ones first)
     * @return the chosen id; the cancel choice's id if the window was closed
     *         otherwise; null if there is no cancel choice and none was chosen
     */
    public static String show(Window owner, String headline, String message, String detail, List<Choice> choices) {
        String cancelId = null;
        for (Choice choice : choices) {
            if (choice.isCancel()) {
                cancelId = choice.id();
            }
        }
        final String[] answer = {cancelId};

        Stage stage = new Stage(StageStyle.UNDECORATED);
        stage.setTitle(TITLE);
        stage.initModality(Modality.APPLICATION_MODAL);
        if (owner != null) {
            stage.initOwner(owner);
        }
        stage.setResizable(false);

        // ---- title strip ---------------------------------------------------
        Label title = new Label(TITLE);
        title.getStyleClass().add("choice-dialog-title");

        Region titleSpacer = new Region();
        HBox.setHgrow(titleSpacer, Priority.ALWAYS);

        Button close = new Button("\u2715");
        close.getStyleClass().add("choice-dialog-close");
        close.setFocusTraversable(false);
        close.setOnAction(e -> stage.close());

        HBox titleBar = new HBox(title, titleSpacer, close);
        titleBar.getStyleClass().add("choice-dialog-title-bar");
        titleBar.setAlignment(Pos.CENTER_LEFT);
        makeDraggable(titleBar, stage);

        // ---- body ----------------------------------------------------------
        double textWidth = Dim.ChoiceDialog.WIDTH
                - (Dim.ChoiceDialog.BODY_PAD_H * 2)
                - Dim.ChoiceDialog.ICON_SIZE
                - Dim.ChoiceDialog.ICON_GAP
                - (Dim.ChoiceDialog.BORDER * 2);

        VBox text = new VBox();
        text.getChildren().add(textLabel(headline, "choice-dialog-headline", textWidth));
        if (message != null && !message.isBlank()) {
            Label paragraph = textLabel(message, "choice-dialog-message", textWidth);
            VBox.setMargin(paragraph, new Insets(Dim.ChoiceDialog.PARAGRAPH_GAP, 0, 0, 0));
            text.getChildren().add(paragraph);
        }
        if (detail != null && !detail.isBlank()) {
            Label extra = textLabel(detail, "choice-dialog-detail", textWidth);
            VBox.setMargin(extra, new Insets(Dim.ChoiceDialog.DETAIL_GAP, 0, 0, 0));
            text.getChildren().add(extra);
        }
        HBox.setHgrow(text, Priority.ALWAYS);

        HBox body = new HBox(PathIcons.icon(PathIcons.INFO, Dim.ChoiceDialog.ICON_SIZE, owner), text);
        body.getStyleClass().add("choice-dialog-body");

        // ---- footer --------------------------------------------------------
        List<Button> left = new ArrayList<>();
        List<Button> right = new ArrayList<>();
        Button focusFirst = null;
        for (Choice choice : choices) {
            Button button = new Button(choice.label());
            button.setMnemonicParsing(false);
            button.setTextAlignment(TextAlignment.CENTER);
            button.setWrapText(false);
            button.getStyleClass().addAll("choice-dialog-button",
                    choice.side() == Side.LEFT ? "choice-left" : "choice-right");
            if (choice.tooltip() != null && !choice.tooltip().isBlank()) {
                button.setTooltip(new Tooltip(choice.tooltip()));
            }
            if (choice.isDefault()) {
                button.getStyleClass().add("choice-default");
                button.setDefaultButton(true);
                focusFirst = button;
            }
            if (choice.isCancel()) {
                button.setCancelButton(true);
            }
            button.setOnAction(e -> {
                answer[0] = choice.id();
                stage.close();
            });
            (choice.side() == Side.LEFT ? left : right).add(button);
        }

        HBox footer = new HBox();
        footer.getStyleClass().add("choice-dialog-footer");
        footer.setAlignment(Pos.CENTER_LEFT);
        footer.getChildren().addAll(left);
        Region footerSpacer = new Region();
        HBox.setHgrow(footerSpacer, Priority.ALWAYS);
        footer.getChildren().add(footerSpacer);
        if (!right.isEmpty()) {
            HBox panel = new HBox();
            panel.getStyleClass().add("choice-dialog-panel");
            panel.setAlignment(Pos.CENTER_RIGHT);
            panel.getChildren().addAll(right);
            footer.getChildren().add(panel);
        }

        VBox root = new VBox(titleBar, body, footer);
        root.getStyleClass().add("choice-dialog");

        Scene scene = new Scene(root);
        if (owner != null && owner.getScene() != null) {
            scene.getStylesheets().setAll(owner.getScene().getStylesheets());
        }
        boolean dark = PathIcons.isDark(owner == null ? null : owner.getScene());
        URL colours = ChoiceDialog.class.getResource(dark ? DARK_SHEET : LIGHT_SHEET);
        if (colours != null) {
            scene.getStylesheets().add(colours.toExternalForm());
        }
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                e.consume();
                stage.close();
            }
        });
        stage.setScene(scene);

        Button target = focusFirst;
        stage.setOnShown(e -> {
            if (owner != null) {
                stage.setX(owner.getX() + (owner.getWidth() - stage.getWidth()) / 2);
                stage.setY(owner.getY() + (owner.getHeight() - stage.getHeight()) / 3);
            }
            if (target != null) {
                target.requestFocus();
            }
        });
        stage.showAndWait();
        return answer[0];
    }

    /**
     * Lets a long path wrap at its separators: Label breaks lines only at
     * spaces, and a folder path often has none.
     *
     * @param path the path text
     * @return the same text with a zero-width space after each separator
     */
    public static String breakable(String path) {
        if (path == null) {
            return "";
        }
        return path.replace("\\", "\\\u200B").replace("/", "/\u200B");
    }

    private static Label textLabel(String value, String styleClass, double width) {
        Label label = new Label(value == null ? "" : value);
        label.getStyleClass().add(styleClass);
        label.setWrapText(true);
        label.setMnemonicParsing(false);
        label.setMinHeight(Region.USE_PREF_SIZE);
        label.setMaxWidth(width);
        label.setPrefWidth(width);
        return label;
    }

    private static void makeDraggable(HBox handle, Stage stage) {
        final double[] offset = new double[2];
        handle.setOnMousePressed(e -> {
            offset[0] = stage.getX() - e.getScreenX();
            offset[1] = stage.getY() - e.getScreenY();
        });
        handle.setOnMouseDragged(e -> {
            stage.setX(e.getScreenX() + offset[0]);
            stage.setY(e.getScreenY() + offset[1]);
        });
    }
}
