package ui.explorer.signal;

import javafx.application.Platform;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.design.Dim;
import ui.explorer.PanelActivation;
import ui.explorer.PanelTitleBar;

/**
 * Builds the Variable Explorer's body and docks the Signal Explorer at its
 * bottom -- the same arrangement {@code CodeBotHost} uses for the Code Bot
 * under the File Explorer.
 *
 * <pre>
 *   Variable Explorer panel body (Signal Explorer open)
 *   +-------------------------------+
 *   |  Name | Value | Size | Type   |
 *   |  ...                          |   80%
 *   |===============================|   <- draggable divider
 *   |  v Signal Explorer        [x] |
 *   |  (under development)          |   20%
 *   +-------------------------------+
 * </pre>
 *
 * <h3>Part of the Variable Explorer, in every layout</h3>
 * <p>
 * The Signal Explorer no longer belongs to the Custom layout. It lives inside
 * the Variable Explorer's own body, so it goes wherever the Variable Explorer
 * goes and is shown in every layout that shows the Variable Explorer. The
 * Variable Explorer tick in the Custom Layout window covers both.
 * </p>
 *
 * <h3>Opening and closing</h3>
 * <ul>
 * <li><b>Closed at launch.</b> It stays closed until something asks for it.</li>
 * <li><b>{@link #show()}</b> opens it under the table, expanding a collapsed
 * Variable Explorer first. The Signals ribbon's Set window calls this from
 * its Apply button, once a signal variable has been set up.</li>
 * <li><b>The {@code x} in its title strip</b> closes it ({@link #close()}),
 * the same as the Code Bot's: the panel disappears and the table takes the
 * whole column back.</li>
 * <li><b>Layout switches keep the choice.</b> A layout switch empties the
 * splits; {@link #redock()} puts the Signal Explorer back if it was open.</li>
 * </ul>
 *
 * <h3>Status</h3>
 * <p>
 * The Signal Explorer is a placeholder: a title strip and a message. It is
 * already a full region -- it has its own collapse triangle and close button
 * and takes part in {@link PanelActivation} -- so the real explorer only has
 * to replace {@link #buildPanel()}'s body.
 * </p>
 *
 * <h3>Minimising</h3>
 * <p>
 * The Signal Explorer's triangle shrinks it to its title strip (the table
 * takes the space); {@link #setTableMinimized(boolean)} shrinks the table to
 * its column-header row instead (the Signal Explorer takes the space). The
 * two never happen together: minimising one restores the other, so the
 * column is never left empty.
 * </p>
 */
public final class SignalExplorerHost {

    private static final String TITLE = "Signal Explorer";

    private static SplitPane split;
    private static Region table;
    private static VBox panel;
    private static PanelTitleBar header;
    private static StackPane body;

    /** The user's intent: open or closed, independent of layout switches. */
    private static boolean open;

    /** Expands the Variable Explorer column when the Signal Explorer opens. */
    private static Runnable revealColumn;

    private static boolean minimized;
    private static boolean tableMinimized;
    private static double savedDivider = Dim.CustomLayout.TABLE_SHARE;

    private SignalExplorerHost() {
    }

    // =====================================================================
    // Construction
    // =====================================================================

    /**
     * Builds the Variable Explorer's body: a vertical split holding the
     * table (and, when open, the Signal Explorer).
     *
     * @param tableNode the variable table
     * @return the body to hand to the Variable Explorer's panel
     */
    public static Node buildBody(Region tableNode) {
        table = tableNode;
        table.setMinHeight(Dim.CustomLayout.TABLE_MIN_HEIGHT);
        split = new SplitPane(tableNode);
        split.setOrientation(Orientation.VERTICAL);
        split.getStyleClass().add("signal-host-split");
        return split;
    }

    /** @return the Signal Explorer panel, built on first use */
    public static VBox panel() {
        if (panel == null) {
            buildPanel();
        }
        return panel;
    }

    /** @return the panel if it was ever built, otherwise null */
    public static VBox panelIfBuilt() {
        return panel;
    }

    /** @return the split that holds the table, for divider handling */
    public static SplitPane split() {
        return split;
    }

    /**
     * Registers what to run so the Signal Explorer can be seen when it opens:
     * {@code LayoutManager} passes "expand the Variable Explorer if it is a
     * rail".
     *
     * @param action the action; may be null
     */
    public static void setRevealColumn(Runnable action) {
        revealColumn = action;
    }

    private static void buildPanel() {
        // Triangle to minimise, x to close -- the x is the strip's own
        // close mark (PanelTitleBar.withClose), coloured like the title.
        header = PanelTitleBar.withToggle(TITLE, () -> setMinimized(!minimized))
                .withClose(SignalExplorerHost::close);

        Label message = new Label(TITLE + " under development");
        message.getStyleClass().add("signal-explorer-message");
        body = new StackPane(message);
        body.getStyleClass().add("signal-explorer-body");

        panel = new VBox(header.getNode(), body);
        panel.getStyleClass().addAll("titled-panel", "signal-explorer-panel");
        panel.setFillWidth(true);
        VBox.setVgrow(body, Priority.ALWAYS);

        PanelActivation.register(PanelActivation.Panel.SIGNAL_EXPLORER, header, panel);
    }

    // =====================================================================
    // Open / close
    // =====================================================================

    /** @return true while the Signal Explorer is open (wanted on screen) */
    public static boolean isOpen() {
        return open;
    }

    /**
     * Opens the Signal Explorer under the table, expanding a collapsed
     * Variable Explorer first, and makes it the active region. Called from the
     * Signals ribbon's Set window when Apply is pressed.
     */
    public static void show() {
        if (split == null) {
            return;
        }
        open = true;
        if (revealColumn != null) {
            revealColumn.run();
        }
        setMinimized(false);
        placeInVariables(Dim.CustomLayout.TABLE_SHARE);
        PanelActivation.setActive(PanelActivation.Panel.SIGNAL_EXPLORER);
    }

    /**
     * Closes the Signal Explorer: it disappears and the table takes the whole
     * column back. The {@code x} in its title strip calls this.
     */
    public static void close() {
        if (!open) {
            return;
        }
        open = false;
        removeFromVariables();
        if (PanelActivation.getActive() == PanelActivation.Panel.SIGNAL_EXPLORER) {
            PanelActivation.setActive(PanelActivation.Panel.VARIABLE_EXPLORER);
        }
    }

    /**
     * Puts the Signal Explorer back under the table after a layout switch, if
     * it was open. Called by {@code LayoutManager} once a layout is built.
     */
    public static void redock() {
        if (open) {
            placeInVariables(Dim.CustomLayout.TABLE_SHARE);
        }
    }

    // =====================================================================
    // Docking
    // =====================================================================

    /**
     * Puts the Signal Explorer under the table.
     *
     * @param tableShare the table's share of the column's height, e.g. 0.80
     */
    public static void placeInVariables(double tableShare) {
        if (split == null) {
            return;
        }
        VBox p = panel();
        SplitPane.setResizableWithParent(p, Boolean.FALSE);
        if (!split.getItems().contains(p)) {
            split.getItems().add(p);
        }
        savedDivider = tableShare;
        split.setDividerPositions(tableShare);
        Platform.runLater(() -> split.setDividerPositions(tableShare));
    }

    /**
     * Takes the Signal Explorer out; the table gets the full height. Does not
     * change whether it is open -- a layout teardown uses this, and
     * {@link #redock()} puts it back.
     */
    public static void removeFromVariables() {
        setMinimized(false);
        setTableMinimized(false);
        if (split != null && panel != null) {
            split.getItems().remove(panel);
        }
    }

    /** @return true while the Signal Explorer is docked under the table */
    public static boolean isPlaced() {
        return split != null && panel != null && split.getItems().contains(panel);
    }

    // =====================================================================
    // Minimise / restore
    // =====================================================================

    /** @return true while the Signal Explorer shows only its title strip */
    public static boolean isMinimized() {
        return minimized;
    }

    /**
     * @param minimize true to shrink the Signal Explorer to its title strip
     */
    public static void setMinimized(boolean minimize) {
        if (panel == null || minimize == minimized) {
            return;
        }
        if (minimize && tableMinimized) {
            setTableMinimized(false);
        }
        minimized = minimize;
        if (minimize) {
            rememberDivider();
            body.setVisible(false);
            body.setManaged(false);
            pin(panel, PanelTitleBar.HEIGHT);
        } else {
            body.setVisible(true);
            body.setManaged(true);
            unpin(panel);
            restoreDivider();
        }
        header.setExpandedState(!minimize);
    }

    /** @return true while the table shows only its column headers */
    public static boolean isTableMinimized() {
        return tableMinimized;
    }

    /**
     * @param minimize true to shrink the table to its column-header row,
     *                 giving the Signal Explorer the column. Ignored while
     *                 the Signal Explorer is not docked, so the column is
     *                 never left with nothing in it.
     */
    public static void setTableMinimized(boolean minimize) {
        if (table == null || minimize == tableMinimized) {
            return;
        }
        if (minimize && !isPlaced()) {
            return;
        }
        if (minimize && minimized) {
            setMinimized(false);
        }
        tableMinimized = minimize;
        if (minimize) {
            rememberDivider();
            pin(table, Dim.CustomLayout.TABLE_MINIMIZED_HEIGHT);
        } else {
            unpin(table);
            table.setMinHeight(Dim.CustomLayout.TABLE_MIN_HEIGHT);
            restoreDivider();
        }
    }

    private static void rememberDivider() {
        if (split != null && split.getDividerPositions().length > 0) {
            double at = split.getDividerPositions()[0];
            // A divider squeezed against an edge is not a position to restore.
            if (at > 0.05 && at < 0.95) {
                savedDivider = at;
            }
        }
    }

    private static void restoreDivider() {
        if (split != null && split.getItems().size() > 1) {
            final double restore = savedDivider;
            final SplitPane owner = split;
            Platform.runLater(() -> owner.setDividerPositions(restore));
        }
    }

    private static void pin(Region node, double height) {
        node.setMinHeight(height);
        node.setPrefHeight(height);
        node.setMaxHeight(height);
    }

    private static void unpin(Region node) {
        node.setMinHeight(Region.USE_COMPUTED_SIZE);
        node.setPrefHeight(Region.USE_COMPUTED_SIZE);
        node.setMaxHeight(Double.MAX_VALUE);
    }
}
