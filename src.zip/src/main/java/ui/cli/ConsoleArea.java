package ui.cli;

import java.util.Collection;
import java.util.function.BiPredicate;

import org.fxmisc.richtext.StyleClassedTextArea;
import org.fxmisc.richtext.model.StyledDocument;
import org.fxmisc.richtext.util.UndoUtils;

/**
 * The Command Window's text control: a RichTextFX area, so typed commands
 * can be syntax coloured like the editor, with the {@code TextArea} methods
 * the rest of the CLI already calls.
 *
 * <h3>Why not TextArea any more</h3>
 * <p>
 * A {@code TextArea} draws all its text in one colour. Colouring commands
 * needs a rich-text control; {@link StyleClassedTextArea} is the one the
 * editor's family already uses ({@code CodeArea} extends it).
 * </p>
 *
 * <h3>Kept TextArea names</h3>
 * <p>
 * {@link #positionCaret(int)} is added here; {@code getLength},
 * {@code getText(int, int)}, {@code appendText}, {@code deleteText},
 * {@code replaceText}, {@code selectRange}, {@code getSelection},
 * {@code getSelectedText}, {@code getCaretPosition}, {@code getAnchor},
 * {@code clear}, {@code paste} and {@code textProperty} already exist on
 * RichTextFX areas with the same meaning. So {@code CLI_Main} and every
 * other caller that only uses these compiles unchanged.
 * </p>
 *
 * <h3>The freeze: an edit veto</h3>
 * <p>
 * {@code TextArea} had {@code TextFormatter} to refuse an edit. RichTextFX
 * has no formatter, but every edit -- typing, paste, cut, delete, a
 * programmatic append -- ends in {@link #replace(int, int, StyledDocument)}.
 * Overriding it gives the same single checkpoint: when the veto says no, the
 * text does not change. {@link ConsoleInputGuard} installs the veto.
 * </p>
 * <p>
 * Two other ways RichTextFX can change text are switched off here: undo
 * (a no-op undo manager, so Ctrl+Z can never restore the history) and
 * dragging a selection to move it (a drop now does nothing).
 * </p>
 *
 * <p>
 * The area must sit in a {@code VirtualizedScrollPane} to scroll; see
 * {@code EditorCommandWindow}.
 * </p>
 */
public class ConsoleArea extends StyleClassedTextArea {

    /** Style class the theme and the generated sheets key on. */
    public static final String STYLE_CLASS = "console-area";

    /** (start, end) of a proposed edit; true refuses it. */
    private BiPredicate<Integer, Integer> editVeto = (start, end) -> false;

    public ConsoleArea() {
        super(false);
        getStyleClass().add(STYLE_CLASS);
        setUndoManager(UndoUtils.noOpUndoManager());
        setOnSelectionDropped(event -> { });
        setWrapText(true);
        setEditable(true);
    }

    /**
     * @param veto receives the start and end of every proposed edit; returning
     *             true refuses it. Null allows every edit.
     */
    public void setEditVeto(BiPredicate<Integer, Integer> veto) {
        this.editVeto = veto == null ? (start, end) -> false : veto;
    }

    /** The one place every edit passes through; see the class notes. */
    @Override
    public void replace(int start, int end,
            StyledDocument<Collection<String>, String, Collection<String>> replacement) {
        if (editVeto.test(start, end)) {
            return;
        }
        super.replace(start, end, replacement);
    }

    /**
     * {@code TextArea.positionCaret}: moves the caret, clears the selection
     * and scrolls the caret into view.
     *
     * @param position the new caret offset; clamped to the text
     */
    public void positionCaret(int position) {
        moveTo(Math.max(0, Math.min(position, getLength())));
        requestFollowCaret();
    }
}
