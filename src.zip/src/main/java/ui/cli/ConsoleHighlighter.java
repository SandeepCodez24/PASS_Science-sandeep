package ui.cli;

import java.util.Collection;
import java.util.List;

import org.fxmisc.richtext.model.StyleSpan;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;
import org.fxmisc.richtext.model.TwoDimensional.Bias;

import language.syntax.UPITokenMaker;

/**
 * Colours the Command Window.
 *
 * <pre>
 *   &gt;&gt; x = sqrt(16) + 2;      prompt in .console-prompt, the command in the
 *                              editor's text colours (UPITokenMaker)
 *   x = 6                     interpreter output in .console-output
 * </pre>
 *
 * <p>
 * A line that starts with the prompt is a command -- a past one in the
 * history or the one being typed -- and is coloured exactly as the editor
 * would colour it. Every other line is output and stays one plain colour,
 * so results never look like code. The colours themselves come from the
 * same text stylesheets as the editor; see {@code TextColourManager}.
 * </p>
 *
 * <h3>Only changed lines are restyled</h3>
 * <p>
 * The transcript can be long, and a script printing every iteration appends
 * constantly. Each text change restyles only the lines it touched, so the
 * cost of a keystroke or an append does not grow with the transcript.
 * </p>
 */
public final class ConsoleHighlighter {

    /** The prompt's mark, without its trailing space. */
    private static final String PROMPT_MARK = ">>";

    public static final String PROMPT_CLASS = "console-prompt";
    public static final String OUTPUT_CLASS = "console-output";

    private static final Collection<String> PROMPT_STYLE = List.of(PROMPT_CLASS);
    private static final Collection<String> OUTPUT_STYLE = List.of(OUTPUT_CLASS);

    private ConsoleHighlighter() {
    }

    /**
     * Starts colouring the console.
     *
     * @param area the console
     */
    public static void attach(ConsoleArea area) {
        area.plainTextChanges().subscribe(change -> {
            int length = area.getLength();
            int from = Math.min(change.getPosition(), length);
            int to = Math.min(change.getInsertionEnd(), length);
            int first = area.offsetToPosition(from, Bias.Backward).getMajor();
            int last = area.offsetToPosition(to, Bias.Forward).getMajor();
            restyle(area, first, last);
        });
    }

    /**
     * Restyles paragraphs {@code first..last}, inclusive.
     *
     * @param area  the console
     * @param first first paragraph
     * @param last  last paragraph
     */
    public static void restyle(ConsoleArea area, int first, int last) {
        int count = area.getParagraphs().size();
        for (int i = Math.max(0, first); i <= Math.min(last, count - 1); i++) {
            area.setStyleSpans(i, 0, spansFor(area.getParagraph(i).getText()));
        }
    }

    /**
     * @param line one line of the transcript
     * @return its spans: prompt plus coloured command, or plain output
     */
    public static StyleSpans<Collection<String>> spansFor(String line) {
        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        if (line.startsWith(PROMPT_MARK)) {
            spans.add(PROMPT_STYLE, PROMPT_MARK.length());
            String command = line.substring(PROMPT_MARK.length());
            if (!command.isEmpty()) {
                for (StyleSpan<Collection<String>> span : UPITokenMaker.computeHighlighting(command)) {
                    spans.add(span);
                }
            }
        } else {
            spans.add(OUTPUT_STYLE, line.length());
        }
        return spans.create();
    }
}
