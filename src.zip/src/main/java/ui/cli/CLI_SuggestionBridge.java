package ui.cli;

import javafx.application.Platform;
import javafx.scene.input.KeyEvent;
import ui.UI_Main;
import ui.ui_functions.FunctionProvider;
import ui.ui_functions.SuggestionPopup;
import ui.ui_functions.SuggestionProvider;
import ui.ui_functions.suggestion_functions.NcFileIndex;
import ui.ui_functions.suggestion_functions.SuggestionScope;
import ui.ui_functions.suggestion_functions.SuggestionSettings;

/**
 * Brings the Editor's autocomplete to the Command Window using the <b>same</b>
 * shared suggestion stack -- no duplicate dictionaries.
 *
 * <h3>When it runs</h3>
 * <p>
 * On the console's plain-text changes made by the user, one pulse later so
 * the caret has landed (typing {@code sq} must ask about {@code sq}, not
 * {@code s}). It no longer listens to {@code textProperty}, which made
 * RichTextFX rebuild the whole transcript string on every keystroke and on
 * every output append; only the current input line is read now.
 * </p>
 *
 * <h3>Which line</h3>
 * <p>
 * Suggestions come from the input line the caret is on -- in a block typed
 * at the prompt, that line only -- so committed output never pollutes the
 * pattern, and a string or comment on an earlier line of the block does not
 * switch suggestions off for the line being typed.
 * </p>
 *
 * <h3>Inserting</h3>
 * <p>
 * Only the typed pattern is replaced, inside the input region, which the
 * freeze allows. Rebuilding the console to insert a word would be refused by
 * the freeze, and would discard the scrollback.
 * </p>
 *
 * <p>
 * The same two rules as the editor apply: nothing is suggested inside a
 * string literal or after a {@code #} / {@code \\} comment marker
 * ({@link SuggestionScope}), and the user's suggestion settings decide which
 * groups appear ({@link SuggestionSettings}). {@code .nc} scripts in the
 * working folder are offered by name.
 * </p>
 */
public final class CLI_SuggestionBridge {

    private UI_Main ide;
    private ConsoleArea console;
    private ConsoleInputGuard guard;
    private final SuggestionPopup popup = new SuggestionPopup();

    /** True while the accepted row is being written: that edit is not typing. */
    private boolean inserting;

    /** A refresh is already queued for the next pulse. */
    private boolean queued;

    /**
     * Wires the bridge onto {@code ide.console}. Call once after the console
     * and its guard exist.
     *
     * @param ideRef   the IDE controller
     * @param guardRef the console's guard
     */
    public void attach(UI_Main ideRef, ConsoleInputGuard guardRef) {
        this.ide = ideRef;
        this.console = ide.console;
        this.guard = guardRef;
        popup.setTheme(ide.currentTheme);
        popup.setOnInsertSuggestion(this::insertSelected);
        NcFileIndex.setWorkingFolderSupplier(ide::getCurrentFolder);
        popup.setExcludedFileSupplier(() -> null);

        console.plainTextChanges().subscribe(change -> {
            if (ide.stage == null || ide.stage.getScene() == null) {
                return;
            }
            if (guard != null && guard.isSystemWriting()) {
                return; // the CLI writing, not the user typing
            }
            if (inserting || queued) {
                return;
            }
            queued = true;
            // Deferred: the caret has not moved yet at this point.
            Platform.runLater(() -> {
                queued = false;
                refreshSuggestions();
            });
        });

        // Capturing filter: navigation/commit keys while the popup is open.
        // The guard's own filter is registered first and defers to
        // isSuggestionShowing(), so ENTER submits only when no suggestion is open.
        console.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (!popup.isSuggestionShowing()) {
                return;
            }
            switch (e.getCode()) {
                case UP -> { popup.selectPrevious(); e.consume(); }
                case DOWN -> { popup.selectNext(); e.consume(); }
                case ENTER, TAB -> { insertSelected(); e.consume(); }
                case ESCAPE -> { popup.hide(); e.consume(); }
                default -> { }
            }
        });
    }

    /**
     * Backwards-compatible entry point.
     *
     * @param ideRef the IDE controller
     */
    public void attach(UI_Main ideRef) {
        attach(ideRef, null);
    }

    /** @return true while the popup is visible. */
    public boolean isShowing() {
        return popup.isSuggestionShowing();
    }

    private void refreshSuggestions() {
        if (ide.stage == null || ide.stage.getScene() == null) {
            return;
        }
        if (guard != null && guard.isSystemWriting()) {
            return;
        }
        String line = currentLine();
        if (line.isEmpty()) {
            popup.hide();
            return;
        }
        SuggestionProvider.updateVariablesFromText(line);
        if (!SuggestionSettings.anyPopupGroupEnabled()
                || SuggestionScope.isSuppressedInLine(line)) {
            popup.hide();
            return;
        }
        String pattern = extractPattern(line, line.length());
        if (pattern != null && !pattern.trim().isEmpty()) {
            popup.setTheme(ide.currentTheme);
            popup.showSuggestions(console, pattern, line, ide.stage);
        } else {
            popup.hide();
        }
    }

    // ---------------------------------------------------------------------
    // Insert
    // ---------------------------------------------------------------------

    private void insertSelected() {
        SuggestionProvider.Suggestion suggestion = popup.getSelected();
        if (suggestion == null) {
            return;
        }
        int caret = console.getCaretPosition();
        if (caret < inputStart()) {
            caret = console.getLength();
        }
        int lineStart = lineStart(caret);
        String line = console.getText(lineStart, caret);
        int caretInLine = line.length();
        String pattern = extractPattern(line, caretInLine);
        if (pattern == null) {
            popup.hide();
            return;
        }

        int patternStartInLine = caretInLine - pattern.length();
        int replaceFromInLine = patternStartInLine;
        String category = suggestion.getCategory();
        String code = suggestion.getCode();
        String closing = "";

        if ("Function".equals(category)) {
            String fn = FunctionProvider.extractFunctionName(code);
            if (FunctionProvider.isNotation(fn)) {
                code = fn;
            } else {
                code = fn + "(";
                closing = ")";
            }
        } else if ("Variable".equals(category) || "StyledVariable".equals(category)) {
            // Inserted exactly as the provider gave it (a styled name must not be unwrapped).
            closing = "";
        } else if (isSymbolCode(code)) {
            // The half-typed wrapper is swallowed with the token, whatever its depth.
            int wrapperStart = openWrapperStart(line, patternStartInLine, caretInLine);
            if (wrapperStart >= 0) {
                replaceFromInLine = wrapperStart;
            }
            String glyph = resolveGlyph(suggestion);
            code = glyph != null ? glyph : suggestion.getCode();
            closing = "";
        }

        int patternStartAbs = lineStart + replaceFromInLine;
        if (code.startsWith("\\") && patternStartAbs > lineStart
                && console.getText(patternStartAbs - 1, patternStartAbs).equals("\\")) {
            patternStartAbs--;
        }

        // Replace ONLY the typed pattern, inside the input region (the edit
        // veto would silently refuse one starting before it).
        patternStartAbs = Math.max(patternStartAbs, inputStart());
        String insertion = code + closing;
        inserting = true;
        try {
            console.replaceText(patternStartAbs, caret, insertion);
            console.positionCaret("Function".equals(suggestion.getCategory())
                    ? patternStartAbs + code.length()
                    : patternStartAbs + insertion.length());
        } finally {
            inserting = false;
        }

        SuggestionProvider.addRecentlyUsedSymbol(suggestion.getCode());
        popup.hide();
        console.requestFocus();
    }

    private static boolean isSymbolCode(String code) {
        return code != null && (code.startsWith("\\var(") || code.startsWith("\\con("));
    }

    private static int openWrapperStart(String line, int patternStart, int caret) {
        return Math.max(openerIndex(line, patternStart, caret, "\\var("),
                openerIndex(line, patternStart, caret, "\\con("));
    }

    private static int openerIndex(String line, int patternStart, int caret, String opener) {
        int index = line.lastIndexOf(opener, patternStart);
        if (index == -1) {
            return -1;
        }
        int close = line.indexOf(")", index);
        return close == -1 || close > caret ? index : -1;
    }

    private static String resolveGlyph(SuggestionProvider.Suggestion suggestion) {
        String display = suggestion.getDisplay();
        if (isGlyph(display)) {
            return display;
        }
        String simple = simpleSymbolName(suggestion.getCode());
        String converted = SuggestionProvider.getSymbolCharacter(simple);
        return isGlyph(converted) && !converted.equals(simple) ? converted : null;
    }

    private static boolean isGlyph(String candidate) {
        if (candidate == null || candidate.isEmpty() || candidate.length() > 4) {
            return false;
        }
        for (int i = 0; i < candidate.length(); i++) {
            if (candidate.charAt(i) > 0x7F) {
                return true;
            }
        }
        return false;
    }

    private static String simpleSymbolName(String code) {
        if (code == null || code.isEmpty()) {
            return "";
        }
        String[] scripted = {
                "\\var(\\tamil(", "\\var(\\sanskrit(", "\\var(\\hindi(",
                "\\var(\\telugu(", "\\var(\\malayalam("
        };
        for (String prefix : scripted) {
            if (code.startsWith(prefix)) {
                return stripTrailing(code.substring(prefix.length()));
            }
        }
        if (code.startsWith("\\var(\\") || code.startsWith("\\con(\\")) {
            return stripTrailing(code.substring(5));
        }
        return code;
    }

    private static String stripTrailing(String text) {
        String trimmed = text;
        while (trimmed.endsWith(")")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed.startsWith("\\") ? trimmed.substring(1) : trimmed;
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private int inputStart() {
        return Math.max(0, Math.min(ide.inputStart, console.getLength()));
    }

    /** Start of the input line holding {@code caret}: the input start, or just after a line break. */
    private int lineStart(int caret) {
        int start = inputStart();
        int end = Math.max(start, Math.min(caret, console.getLength()));
        String upToCaret = console.getText(start, end);
        int newline = upToCaret.lastIndexOf('\n');
        return newline >= 0 ? start + newline + 1 : start;
    }

    /** The current input line, from its start to the caret. Reads nothing else. */
    private String currentLine() {
        int length = console.getLength();
        int caret = Math.min(Math.max(console.getCaretPosition(), inputStart()), length);
        return console.getText(lineStart(caret), caret);
    }

    /**
     * Extracts the token being typed: a {@code \var(} / {@code \con(} fragment,
     * a {@code \word} escape, or a plain identifier.
     */
    private static String extractPattern(String line, int caret) {
        if (line == null || line.isEmpty() || caret <= 0) {
            return null;
        }
        int safe = Math.min(caret, line.length());

        String wrapped = wrapperFragment(line, safe, "\\var(");
        if (wrapped != null) {
            return wrapped;
        }
        wrapped = wrapperFragment(line, safe, "\\con(");
        if (wrapped != null) {
            return wrapped;
        }

        int lastBackslash = line.lastIndexOf("\\", safe - 1);
        if (lastBackslash != -1) {
            String token = line.substring(lastBackslash, safe);
            if (token.matches("\\\\[a-zA-Z0-9_]*")) {
                return token;
            }
        }
        int wordStart = safe;
        while (wordStart > 0 && (Character.isLetterOrDigit(line.charAt(wordStart - 1))
                || line.charAt(wordStart - 1) == '_')) {
            wordStart--;
        }
        String word = line.substring(wordStart, safe);
        if (!word.isEmpty() && word.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
            return word;
        }
        return null;
    }

    private static String wrapperFragment(String line, int safe, String opener) {
        int index = line.lastIndexOf(opener, safe);
        if (index == -1) {
            return null;
        }
        int close = line.indexOf(")", index);
        if (close != -1 && close <= safe) {
            return null;
        }
        String fragment = line.substring(index + opener.length(), safe);
        return fragment.matches("[a-zA-Z0-9\\\\()_]*") ? fragment : null;
    }
}
