package ui.cli;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.function.IntConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.util.Duration;
import language.syntax.syntax_checker.ErrorClassifier;
import language.syntax.syntax_checker.core.CheckContext;
import ui.UI_Main;
import ui.editor.homeTab.StepFileRunner;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.SearchPath;
import ui.ui_functions.Variable;
import ui.ui_functions.WorkspaceStore;

/**
 * <h2>CLI_Main — the Command Window controller</h2>
 *
 * Single Java owner of the Command Window.
 *
 * <h3>Design contract</h3>
 * <ul>
 *   <li><b>C++ owns evaluation.</b> One persistent {@code nc.exe} is the live
 *       backend for the whole session, so the workspace persists between
 *       commands, script runs and step runs. Run, the Command Window and Step
 *       all share it.</li>
 *   <li><b>Java owns the prompt.</b> {@link ConsoleInputGuard} owns the
 *       editable region; this class owns command dispatch.</li>
 *   <li><b>{@code variables.txt} is the workspace.</b> {@link WorkspaceStore}
 *       is refreshed from it whenever the {@code >> } prompt returns, which is
 *       the only race-free moment: the interpreter has finished writing.</li>
 * </ul>
 *
 * <h3>Command semantics</h3>
 * <table>
 *   <tr><td>{@code cls}</td><td>clear the screen only; workspace untouched</td></tr>
 *   <tr><td>{@code clear}</td><td>reset the workspace only; screen untouched</td></tr>
 *   <tr><td>{@code clear A}</td><td>remove one variable; screen untouched</td></tr>
 * </table>
 *
 * <p><b>These work against your current nc.exe with no recompile.</b>
 * {@code cls} never reaches the backend. {@code clear} maps onto the existing
 * {@code clear} builtin. {@code clear <name>} is done by rewriting
 * {@code variables.txt} from Java and sending {@code @cmd syncws} — see
 * {@link #clearOne} for the one caveat.
 *
 * <h3>What changed (step-into)</h3>
 * <p>The Step runner can now step <i>into</i> a block on the same
 * {@code nc.exe}, using the interpreter's stepping protocol:
 * <ul>
 *   <li>{@code @cmd stepinto} arms the pause hook. Its prompt is swallowed
 *       like every other {@code @cmd}.</li>
 *   <li>While running the block the interpreter prints
 *       {@code @STEPAT <n>} before each statement and waits on stdin.
 *       The marker is taken off the console and handed to the Step runner
 *       ({@link #setStepAtListener}). A marker split across two reads is
 *       held back until it is complete.</li>
 *   <li>{@code @cmd stepnext} resumes. The paused interpreter reads it itself
 *       and answers without a prompt, so it is written without counting a
 *       reply ({@link #sendStepControl}).</li>
 *   <li>Every settled prompt is reported to the Step runner
 *       ({@link #setStepIdleListener}), which decides whether its block is
 *       over.</li>
 *   <li><b>While a block is paused, nothing else may reach stdin</b>, or the
 *       interpreter would read it as the answer to the pause. Typed commands,
 *       Run and other IDE sends are refused with a short note until Step
 *       finishes the block or Stop ends it. {@code cls} and {@code exit} still
 *       work. Path rebuilds wait as they do for a running command.</li>
 *   <li>Stop kills and relaunches the interpreter when a block is paused,
 *       even if no reply is owed, because a paused interpreter is running.
 *       Between Step clicks with nothing paused, Stop only rewinds the arrow,
 *       as before.</li>
 *   <li>Lines the Step runner sends go through
 *       {@link CliSymbolCodec#encodeLine} ({@link #sendStepLine}), exactly like
 *       typed lines. Greek/Tamil/Sanskrit names in a stepped file now reach the
 *       interpreter in cleaned form. Pure-ASCII lines are unchanged.</li>
 * </ul>
 *
 * <h3>Earlier change (the current folder and the path)</h3>
 * <ul>
 *   <li><b>The working folder is the current folder.</b> {@code @cmd setpwd}
 *       follows the folder the File Explorer shows, sent on every move by
 *       {@code ProjectManager.loadProjectFromPath}, and a launch or relaunch
 *       starts there. A folder set before the interpreter is up is only
 *       recorded, then sent by the launch.</li>
 *   <li><b>The path.</b> Folders added for the session ({@link SearchPath})
 *       are sent as {@code addpath} when added and again after every launch,
 *       so a Stop or a crash does not lose them. {@code nc.exe} has no
 *       {@code rmpath}, so removing one restarts the interpreter quietly on
 *       the same workspace ({@link #rebuildSearchPath()}); if a command is
 *       running, that waits until it finishes.</li>
 *   <li><b>{@code addpath}, {@code rmpath} and {@code path} typed at the
 *       prompt</b> are handled here, so the Root menu, Run and the editor's
 *       checker all know about the change. {@code addpath} accepts
 *       {@code addpath D:\x}, {@code addpath "D:\x"} and
 *       {@code addpath('D:\x')}; a relative folder is taken from the current
 *       folder.</li>
 *   <li><b>Scripts are found where they will run.</b> A typed script name is
 *       looked up in the current folder, then in each added folder, before
 *       its pre-run check. {@code name.nc} found in neither is reported here
 *       rather than sent. A typed full path to a {@code .nc} file outside the
 *       current folder and the path is refused, as Run would refuse it.</li>
 *   <li><b>Run-folder history.</b> A script that passes those checks and is
 *       sent puts the current folder at the top of the breadcrumb's history
 *       drop-down, as Run and Step do ({@link #recordTypedScript}).</li>
 * </ul>
 *
 * <h3>Earlier change (a broken script never reaches the backend)</h3>
 * <ul>
 *   <li><b>Typed script names are checked first.</b> When the line typed at
 *       the prompt is a bare script name ({@code sct_01}, {@code sct_01.nc},
 *       optionally ending in {@code ;}) and that {@code .nc} file exists in the
 *       backend's working folder, the saved file is run through the editor's
 *       checks before anything is sent. If it has errors, each one is listed
 *       with its category and line -- exactly as the Run button lists them --
 *       and the command is not forwarded. See {@link #blockedScriptReport}.</li>
 *   <li><b>Safe by construction.</b> The check only ever <i>adds</i> a
 *       refusal: anything it cannot decide (the line is not a bare name, no
 *       such file, the file cannot be read, a workspace variable has that name,
 *       any unexpected failure) falls through to the backend unchanged, so no
 *       command that worked before can stop working because of it. A bare name
 *       that is also a workspace variable is left to the backend, since the
 *       user may mean the variable; typing it with {@code .nc} makes it
 *       unambiguous.</li>
 *   <li><b>{@link #reportBlockedRun}</b> prints a refused run the way a real
 *       one starts -- the script name echoed at the prompt -- followed by the
 *       report and a fresh prompt. The Run button uses it.</li>
 * </ul>
 *
 * <h3>Stop (Ctrl+C, the ribbon Stop, F6, the three-dot menu)</h3>
 * <p>All four call {@link #stopExecution(UI_Main)}. A Windows child process
 * on pipes cannot be sent a real Ctrl+C, so a running command is stopped by
 * <b>killing and relaunching</b> {@code nc.exe}:
 * <ol>
 *   <li>The old process is orphaned first (its reader and exit watcher check
 *       a generation number), then killed, so none of its trailing output or
 *       its death notice can land on the new session.</li>
 *   <li>"Execution stopped by user." is printed with a fresh prompt.</li>
 *   <li>A new {@code nc.exe} is started on the <b>same workspace</b>:
 *       {@code variables.lastgood.txt}, copied every time a prompt returns
 *       (the only moment {@code variables.txt} is known to be complete), is
 *       restored first, and the interpreter loads it at startup. The working
 *       folder is re-sent with {@code @cmd setpwd}.</li>
 * </ol>
 * The workspace therefore comes back exactly as it was after the last
 * <i>completed</i> command; whatever the interrupted command changed is
 * discarded. A cooperative interrupt in the backend would keep that partial
 * state -- {@link #restartBackend(String)} is the one place to swap it in.
 *
 * <h3>Busy</h3>
 * <p>Java knows whether a command is executing. Every line the user (or
 * the Step runner, or Run) sends is counted; every {@code >> } the
 * interpreter answers with pays one back. {@link #busyProperty()} is true
 * while replies are owed, and drives the enabled state of both Stop controls.
 * Ctrl+C stops when {@link #isExecuting()} (busy, or a step block paused) and
 * copies otherwise. If the interpreter answers a multi-line block with fewer
 * prompts than lines, a short settle timer clears the debt once the console
 * has sat at a prompt with no further output.
 *
 * <h3>Self-healing backend</h3>
 * <p>If {@code nc.exe} is not running when a command, a Run or a Step needs
 * it, it is relaunched on the saved workspace instead of answering "UPI
 * terminal is not running." The workspace is only ever wiped on the first
 * launch of a session.
 */
public final class CLI_Main {

    /** The interactive prompt printed by nc.exe. */
    static final String PROMPT = ">> ";

    /** Optional override: -Dupi.nc.exe=C:\\path\\to\\nc.exe */
    private static final String NC_EXE_PROPERTY = "upi.nc.exe";

    private static final String[] NC_EXE_CANDIDATES = {
            "cpp/nc",
            "src/main/cpp/nc",
            "nc"
    };

    private static UI_Main ide;
    private static Process process;
    private static BufferedWriter processWriter;
    private static ConsoleInputGuard guard;

    /** Directory nc.exe runs in; also where the shared variables.txt lives. */
    private static Path workingDirectory;
    private static Path variablesTxt;

    private static CLI_SuggestionBridge suggestionBridge;

    /**
     * Prompts the interpreter will emit for commands the USER never typed.
     * Every {@code @cmd ...} the IDE sends is answered with a ">> " that must
     * not reach the screen, or the console grows a spurious ">> >> ".
     */
    private static int silentPrompts;

    /** Last directory sent with {@code @cmd setpwd}; avoids resending it. */
    private static Path lastWorkspaceDirectory;

    /**
     * A line that names a script and nothing else: an identifier (any script,
     * as variable names are), an optional {@code .nc}, an optional {@code ;}.
     */
    private static final Pattern SCRIPT_CALL = Pattern.compile(
            "^([\\p{L}_][\\p{L}\\p{M}\\p{N}_]*)(\\.nc)?\\s*;?$",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS);

    /**
     * A line that is a full path to a {@code .nc} file, optionally quoted and
     * ending in {@code ;}: {@code "D:\x\a.nc"}, {@code /home/u/a.nc}.
     */
    private static final Pattern PATH_CALL = Pattern.compile(
            "^[\"']?((?:[A-Za-z]:[\\\\/]|\\\\\\\\|/)[^\"']*?\\.nc)[\"']?\\s*;?$",
            Pattern.CASE_INSENSITIVE);

    /** {@code addpath X}, {@code addpath "X"}, {@code addpath('X')}, and the same for rmpath. */
    private static final Pattern PATH_COMMAND = Pattern.compile(
            "^(addpath|rmpath)(?:\\s+|\\s*\\(\\s*)(.+?)(?:\\s*\\))?\\s*;?$",
            Pattern.CASE_INSENSITIVE);

    /** {@code addpath} or {@code rmpath} with nothing to act on. */
    private static final Pattern PATH_COMMAND_BARE = Pattern.compile(
            "^(addpath|rmpath)\\s*(?:\\(\\s*\\))?\\s*;?$",
            Pattern.CASE_INSENSITIVE);

    /**
     * How a folder is put on the interpreter's path. One place, so it can be
     * changed if {@code nc.exe}'s syntax differs.
     */
    private static final String ADDPATH_COMMAND = "addpath \"%s\"";

    /** A path removal that is waiting for the running command to finish. */
    private static boolean pathRebuildPending;

    /** Scripts larger than this are not pre-checked; the backend handles them as before. */
    private static final long SCRIPT_CHECK_MAX_BYTES = 8L * 1024 * 1024;

    /** {@code -Dastra.workspace.persist=true} keeps the previous session's variables. */
    private static final String PERSIST_PROPERTY = "astra.workspace.persist";

    /** Copy of variables.txt taken whenever a prompt returns; restored on a restart. */
    private static final String SNAPSHOT_FILE = "variables.lastgood.txt";

    /** Printed when a running command is stopped. */
    private static final String STOP_MESSAGE = "Execution stopped by user.\n";

    /** Printed when the interpreter dies on its own. */
    private static final String CRASH_MESSAGE =
            "UPI backend stopped unexpectedly. It restarts with your next command.\n";

    /** How long the console must sit at a prompt before an unpaid reply debt is cleared. */
    private static final Duration SETTLE_DELAY = Duration.millis(400);

    /** Upper bound on waiting for a killed interpreter to exit. */
    private static final long KILL_WAIT_MS = 3000;

    private static Path snapshotTxt;

    /** Bumped on every launch and kill; output from an older process is dropped. */
    private static int generation;

    /** True once the first interpreter of this session has been launched. */
    private static boolean launchedOnce;

    /** True while the app is closing, so the exit watcher stays quiet. */
    private static boolean shuttingDown;

    /** Prompts still owed for lines the user, Run or Step sent. */
    private static int pendingReplies;

    private static final ReadOnlyBooleanWrapper BUSY = new ReadOnlyBooleanWrapper(false);

    private static PauseTransition settleTimer;

    /** Minimum gap between two output drains on the FX thread (about 30 per second). */
    private static final long DRAIN_INTERVAL_MS = 33;

    /** Most output held between two drains; older text is dropped beyond this. */
    private static final int PENDING_CAP = 256 * 1024;

    /** The console transcript is trimmed from the top once it passes this. */
    private static final int CONSOLE_MAX_CHARS = 200_000;

    /** What a trim leaves behind, so trimming happens in batches, not every drain. */
    private static final int CONSOLE_KEEP_CHARS = 150_000;

    // ---- step-into protocol ---------------------------------------------

    /** The step-into control lines understood by nc.exe. */
    public static final String STEP_INTO_COMMAND = "@cmd stepinto";
    public static final String STEP_NEXT_COMMAND = "@cmd stepnext";

    /** Start of a pause marker; used for a cheap contains() test. */
    private static final String STEPAT_TAG = "@STEPAT ";

    /** One complete pause marker. Group 2 is null when no line break followed yet. */
    private static final Pattern STEPAT_LINE = Pattern.compile("@STEPAT (\\d+)[ \\t]*(\\r?\\n)?");

    /** Any proper prefix of a marker: "@", "@ST", "@STEPAT ", "@STEPAT 1" ... */
    private static final Pattern STEPAT_PREFIX =
            Pattern.compile("@(?:S(?:T(?:E(?:P(?:A(?:T(?: \\d*)?)?)?)?)?)?)?");

    /** Printed when a command arrives while a step block is paused. */
    private static final String STEP_PAUSED_MESSAGE =
            "A step run is paused inside a block. Press Step to continue, or Stop to end it.\n";

    /**
     * Notified with the 1-based statement number, relative to the block that
     * was sent, whenever the interpreter reports "@STEPAT &lt;n&gt;".
     */
    private static IntConsumer stepAtListener;

    /**
     * Notified every time the console returns to a settled prompt. The Step
     * runner decides whether that means its block has finished.
     */
    private static Runnable stepIdleListener;

    /** The start of a pause marker cut off at the end of a read; finished by the next one. */
    private static String stepCarry = "";

    private CLI_Main() {
    }

    // =====================================================================
    // 1. Console construction (called from Main_Window.setupConsole)
    // =====================================================================

    /**
     * Builds the console, installs the freeze, and attaches the shared
     * suggestion popup.
     *
     * @param ideRef the IDE controller
     */
    public static void initConsole(UI_Main ideRef) {
        ide = ideRef;
        guard = ConsoleController.initialize(ide);
        // Live symbol replacement first, so the suggestion bridge sees text
        // that has already been folded into its visual form.
        ConsoleSymbolInput.attach(ide, guard);
        suggestionBridge = new CLI_SuggestionBridge();
        suggestionBridge.attach(ide, guard);
        guard.setSuppressEnter(CLI_Main::isSuggestionShowing);
        guard.setOnSubmit(() -> handleEnter(ide));
        // Ctrl+C: stop while a command runs or a step block is paused, copy otherwise.
        guard.setBusy(CLI_Main::isExecuting);
        guard.setOnInterrupt(() -> stopExecution(ide));
    }

    // =====================================================================
    // 2. Backend lifecycle
    // =====================================================================

    /**
     * Locates and launches the persistent {@code nc.exe} backend. Idempotent:
     * calling it twice never starts a second interpreter.
     *
     * <p>Only the first launch of a session starts from an empty workspace.
     * Any later call (the Step runner arming after a crash, say) relaunches on
     * the saved workspace, so it can never wipe the user's variables.
     *
     * @param ideRef the IDE controller
     */
    public static void start(UI_Main ideRef) {
        ide = ideRef;
        if (isBackendAlive()) {
            return;
        }
        boolean fresh = !launchedOnce && !Boolean.getBoolean(PERSIST_PROPERTY);
        launch(fresh, launchedOnce, false);
    }

    /**
     * Starts one interpreter.
     *
     * @param freshWorkspace  empty variables.txt before the process starts
     * @param restoreSnapshot put the last complete workspace back first
     * @param silentStartup   swallow the startup prompt too (the caller has
     *                        painted its own, or is about to send a command)
     * @return true when an interpreter is now running
     */
    private static boolean launch(boolean freshWorkspace, boolean restoreSnapshot, boolean silentStartup) {
        Path exe = resolveNcExe();
        if (exe == null) {
            appendOutput("UPI backend not found. Set -D" + NC_EXE_PROPERTY
                    + "=<path to nc.exe> or place nc.exe under one of: "
                    + String.join(", ", NC_EXE_CANDIDATES) + "\n");
            appendPrompt();
            return false;
        }
        workingDirectory = exe.toAbsolutePath().getParent();
        variablesTxt = workingDirectory.resolve("variables.txt");
        snapshotTxt = workingDirectory.resolve(SNAPSHOT_FILE);

        // A new window means a new workspace. Parser's constructor calls
        // loadFromFile(), so variables.txt must be emptied BEFORE the process
        // starts — otherwise the interpreter inherits the previous session and
        // the Explorer fills with variables the user never declared here.
        if (freshWorkspace) {
            WorkspaceVariableParser.writeEmpty(variablesTxt);
            WorkspaceStore.get().clearAll();
            snapshotWorkspace();
        } else if (restoreSnapshot) {
            restoreWorkspaceSnapshot();
        }

        try {
            ProcessBuilder pb = new ProcessBuilder(exe.toAbsolutePath().toString());
            pb.directory(workingDirectory.toFile());
            pb.redirectErrorStream(true);
            Process started = pb.start();

            generation++;
            int gen = generation;
            process = started;
            launchedOnce = true;
            shuttingDown = false;
            silentPrompts = silentStartup ? 1 : 0;
            stepCarry = "";

            ide.runningProcess = started;
            ide.programRunning = true;
            processWriter = new BufferedWriter(
                    new OutputStreamWriter(started.getOutputStream(), StandardCharsets.UTF_8));
            ide.processWriter = processWriter;

            startReader(started, gen);
            startExitWatcher(started, gen);

            // Start in the current folder -- the folder the File Explorer shows
            // -- falling back to the last folder sent, then to the editor's.
            Path folder = NavigationActions.projectFolder(ide);
            if (folder == null) {
                folder = lastWorkspaceDirectory != null ? lastWorkspaceDirectory : ide.getCurrentFolder();
            }
            lastWorkspaceDirectory = null;
            if (folder != null) {
                setWorkspaceDirectory(folder);
            }
            // A new interpreter knows nothing of the session's path.
            for (Path added : SearchPath.folders()) {
                sendInternal(String.format(ADDPATH_COMMAND, added.toAbsolutePath()));
            }
            pathRebuildPending = false;
            reloadWorkspace();
            return true;
        } catch (IOException ex) {
            appendOutput("Failed to start UPI terminal: " + ex.getMessage() + "\n");
            appendPrompt();
            return false;
        }
    }

    /**
     * Makes sure an interpreter is running, relaunching one on the saved
     * workspace if it is not. Used by every path that is about to send a
     * command, which is what retires "UPI terminal is not running."
     *
     * @return true when an interpreter is running
     */
    private static boolean ensureBackend() {
        if (isBackendAlive()) {
            return true;
        }
        if (ide == null) {
            return false;
        }
        boolean fresh = !launchedOnce && !Boolean.getBoolean(PERSIST_PROPERTY);
        return launch(fresh, launchedOnce, true);
    }

    /**
     * Public form of {@link #ensureBackend()} for the Step runner, which must
     * know the interpreter is up before it arms step-into. Call on the FX
     * thread.
     *
     * @param ideRef the IDE controller
     * @return true when an interpreter is running
     */
    public static boolean ensureRunning(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        return ensureBackend();
    }

    /** @return true while an interpreter process is alive */
    public static boolean isBackendAlive() {
        return process != null && process.isAlive();
    }

    /**
     * Tells the backend which folder to resolve script names against: the
     * current folder. Before the interpreter is running the folder is only
     * recorded, and the launch sends it.
     *
     * @param folder the current folder
     */
    public static void setWorkspaceDirectory(Path folder) {
        if (folder == null) {
            return;
        }
        Path absolute = folder.toAbsolutePath();
        if (absolute.equals(lastWorkspaceDirectory)) {
            return; // already there; resending only costs a spurious prompt
        }
        lastWorkspaceDirectory = absolute;
        if (!isBackendAlive() || processWriter == null) {
            return; // launch() sends it
        }
        sendInternal("@cmd setpwd \"" + absolute + "\"");
    }

    /**
     * Puts a folder on the interpreter's path. A no-op while no interpreter
     * runs: every launch sends the whole path.
     *
     * @param folder the folder, already added to {@link SearchPath}
     */
    public static void addSearchPath(Path folder) {
        if (folder == null) {
            return;
        }
        Runnable action = () -> {
            if (isBackendAlive() && processWriter != null) {
                sendInternal(String.format(ADDPATH_COMMAND, folder.toAbsolutePath()));
            }
        };
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /**
     * Brings the interpreter's path back into line with {@link SearchPath}
     * after a folder was removed. {@code nc.exe} has no {@code rmpath}, so the
     * interpreter is restarted quietly on the same workspace -- no message, no
     * second prompt -- and the launch re-sends the folders that remain. If a
     * command is running or a step block is paused, the restart waits until
     * it finishes.
     */
    public static void rebuildSearchPath() {
        Runnable action = () -> {
            if (!isBackendAlive() || guard == null) {
                return; // the next launch sends the path as it is now
            }
            if (isExecuting()) {
                pathRebuildPending = true;
                return;
            }
            restartQuietly();
        };
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /** Runs a path rebuild that was waiting for a command or a step block to finish. */
    private static void runPendingRebuild() {
        if (pathRebuildPending && !isExecuting()) {
            pathRebuildPending = false;
            Platform.runLater(() -> {
                if (!isExecuting()) {
                    restartQuietly();
                } else {
                    pathRebuildPending = true;
                }
            });
        }
    }

    // =====================================================================
    // 2b. Step-into protocol (used by StepFileRunner)
    // =====================================================================

    /**
     * Registers (or clears, with null) the callback for "@STEPAT &lt;n&gt;".
     *
     * @param listener callback receiving the 1-based statement number, or null
     */
    public static void setStepAtListener(IntConsumer listener) {
        stepAtListener = listener;
    }

    /**
     * Registers (or clears, with null) the callback run when the console
     * settles at a prompt.
     *
     * @param listener callback, or null
     */
    public static void setStepIdleListener(Runnable listener) {
        stepIdleListener = listener;
    }

    /**
     * Sends one step-into control line. {@code @cmd stepinto} is answered by a
     * prompt that must stay hidden, so it is sent silently. {@code @cmd stepnext}
     * is read by the paused interpreter itself and answered with no prompt, so
     * it is written without counting a reply owed.
     *
     * @param ideRef the IDE controller
     * @param line   {@link #STEP_INTO_COMMAND} or {@link #STEP_NEXT_COMMAND}
     */
    public static void sendStepControl(UI_Main ideRef, String line) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (line == null) {
            return;
        }
        Runnable action = () -> {
            if (!isBackendAlive()) {
                return;
            }
            if (line.equals(STEP_NEXT_COMMAND)) {
                sendRaw(line);
            } else {
                sendInternal(line);
            }
        };
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /**
     * Sends one source line of a step unit. It counts towards the busy state
     * like a typed command and is encoded like one, so visual names reach the
     * interpreter in cleaned form; leading indentation is kept as written.
     * Not subject to the paused-block refusal: the Step runner is the one
     * party allowed to feed the interpreter while it steps.
     *
     * @param ideRef the IDE controller
     * @param line   the physical source line
     */
    public static void sendStepLine(UI_Main ideRef, String line) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (line == null) {
            return;
        }
        Runnable action = () -> {
            if (!ensureBackend()) {
                appendOutput("UPI terminal is not running.\n");
                appendPrompt();
                return;
            }
            sendUser(encodeKeepingIndent(line));
        };
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /**
     * Called by the Step runner when it has decided a block is over, so work
     * that waited for it (a path rebuild) can go ahead.
     */
    public static void stepBlockFinished() {
        runPendingRebuild();
    }

    /** @return true when the console currently ends with the prompt */
    public static boolean isAtPrompt() {
        return ide != null && ide.console != null && guard != null && endsWithPrompt();
    }

    private static String encodeKeepingIndent(String line) {
        int i = 0;
        while (i < line.length() && (line.charAt(i) == ' ' || line.charAt(i) == '\t')) {
            i++;
        }
        String body = line.substring(i);
        String encoded;
        try {
            encoded = CliSymbolCodec.encodeLine(body);
        } catch (RuntimeException e) {
            encoded = null;
        }
        return line.substring(0, i) + (encoded == null ? body : encoded);
    }

    /**
     * Refuses an action that would write to the interpreter while a step block
     * is paused. Prints the note and a prompt.
     *
     * @return true when the caller must not send anything
     */
    private static boolean refuseWhilePaused() {
        if (!StepFileRunner.isBlockInProgress()) {
            return false;
        }
        appendOutput(STEP_PAUSED_MESSAGE);
        appendPrompt();
        return true;
    }

    // =====================================================================
    // 3. Input handling
    // =====================================================================

    /**
     * Called by {@link ConsoleInputGuard} when ENTER is pressed on the prompt
     * line and the suggestion popup is not open.
     *
     * @param ideRef the IDE controller
     */
    public static void handleEnter(UI_Main ideRef) {
        ide = ideRef;
        String line = guard == null ? "" : guard.currentInput().strip();

        if (isExit(line)) {
            guard.appendRaw("\n");
            shutdown();
            if (ide.stage != null) {
                ide.stage.close();
            }
            Platform.exit();
            return;
        }

        guard.rememberCommand(line);

        // ---- cls: screen only. Never reaches the backend, so the workspace
        // ---- cannot be touched by it. ------------------------------------
        if (isClearScreen(line)) {
            guard.clearScreen();
            appendPrompt();
            return;
        }

        // ---- a paused step block owns stdin: nothing else may be sent ------
        if (StepFileRunner.isBlockInProgress()) {
            guard.appendRaw("\n");
            guard.lockToEnd();
            refuseWhilePaused();
            return;
        }

        // ---- clear / clear <name>: workspace only, screen untouched -------
        String target = clearTarget(line);
        if (target != null) {
            guard.appendRaw("\n");
            guard.lockToEnd();
            if (target.isEmpty()) {
                clearAll();
            } else {
                clearOne(target);
            }
            return;
        }

        // ---- everything else: one line advance, forward to backend --------
        guard.appendRaw("\n");
        guard.lockToEnd();

        // ---- addpath / rmpath / path: the session path lives in Java ------
        if (handlePathCommand(line)) {
            return;
        }

        // ---- a full path to a .nc file outside the current folder ---------
        String outside = outsidePathReport(line);
        if (outside != null) {
            appendOutput(outside);
            appendPrompt();
            return;
        }

        // ---- a script name: refuse it here if the editor's checks fail ----
        String blocked = blockedScriptReport(line);
        if (blocked != null) {
            appendOutput(blocked);
            appendPrompt();
            return;
        }

        if (!ensureBackend()) {
            appendOutput("UPI terminal is not running.\n");
            appendPrompt();
            return;
        }

        // The screen keeps the visual line the user typed; the interpreter is
        // handed the cleaned one, exactly as Run hands it cleaned_Runfile.nc.
        // Sending the raw line was why a Greek/Tamil/Sanskrit declaration made
        // in the Command Window silently did nothing. Pure-ASCII lines are
        // returned unchanged by the codec, so every command that worked before
        // still travels byte for byte.
        recordTypedScript(line);
        sendUser(CliSymbolCodec.encodeLine(line));
    }

    /**
     * Puts the current folder at the top of the breadcrumb's run-folder
     * history when the line about to be sent runs a script: a bare script name
     * that resolves to a {@code .nc} file in the current folder or on the
     * path, or a full path to a {@code .nc} file. Anything else -- an
     * assignment, a builtin, a variable that shares a script's name -- records
     * nothing. Bookkeeping only: it can never stop the line from being sent.
     *
     * @param typed the line as typed
     */
    private static void recordTypedScript(String typed) {
        try {
            if (typed == null) {
                return;
            }
            String line = typed.strip();
            Path script = null;
            Matcher call = SCRIPT_CALL.matcher(line);
            if (call.matches()) {
                boolean explicitExtension = call.group(2) != null;
                if (!explicitExtension && isWorkspaceVariable(call.group(1))) {
                    return;
                }
                script = findScript(call.group(1) + ".nc");
            } else {
                Matcher path = PATH_CALL.matcher(line);
                if (path.matches()) {
                    Path file = Path.of(path.group(1));
                    script = Files.isRegularFile(file) ? file : null;
                }
            }
            if (script != null) {
                Path folder = script.toAbsolutePath().getParent();
                NavigationActions.recordRecentFolder(ide, folder);
            }
        } catch (RuntimeException ignored) {
            // History is a convenience; a failure here must not reach the user.
        }
    }

    /**
     * Runs a script on the shared persistent backend.
     *
     * <p>The <b>displayed</b> name and the <b>executed</b> file are deliberately
     * different: the console shows {@code >> ssss.nc} (requirement 3) while the
     * backend is handed the absolute path of {@code cleaned_Runfile.nc}, which
     * is the only file {@code nc.exe} should ever execute (requirement 4).
     *
     * @param ideRef      the IDE controller
     * @param displayName what to echo at the prompt, e.g. {@code ssss.nc}
     * @param fileToRun   the cleaned file actually handed to the interpreter
     */
    public static void runScript(UI_Main ideRef, String displayName, Path fileToRun) {
        ide = ideRef;
        if (fileToRun == null) {
            return;
        }
        Platform.runLater(() -> {
            if (refuseWhilePaused()) {
                return;
            }
            if (!ensureBackend()) {
                appendOutput("UPI terminal is not running.\n");
                appendPrompt();
                return;
            }
            guard.appendRaw(displayName == null ? fileToRun.getFileName().toString() : displayName);
            guard.appendRaw("\n");
            guard.lockToEnd();
            sendUser("\"" + fileToRun.toAbsolutePath() + "\"");
        });
    }

    /**
     * Kept so existing callers compile. Prefer
     * {@link #runScript(UI_Main, String, Path)}, which runs the cleaned file.
     *
     * @param ideRef     the IDE controller
     * @param scriptName the script's name or path
     */
    public static void runScriptByName(UI_Main ideRef, String scriptName) {
        ide = ideRef;
        if (scriptName == null || scriptName.isBlank()) {
            return;
        }
        String blocked = blockedScriptReport(scriptName);
        if (blocked != null) {
            reportBlockedRun(ideRef, scriptName, blocked);
            return;
        }
        Platform.runLater(() -> {
            if (refuseWhilePaused()) {
                return;
            }
            if (!ensureBackend()) {
                appendOutput("UPI terminal is not running.\n");
                appendPrompt();
                return;
            }
            guard.appendRaw(scriptName);
            guard.appendRaw("\n");
            guard.lockToEnd();
            sendUser(scriptName);
        });
    }

    /**
     * Prints a refused run: the script name echoed at the prompt, as a real run
     * would show it, then the report, then a fresh prompt.
     *
     * @param ideRef      the IDE controller
     * @param displayName the name to echo, e.g. {@code t9_isolate3.nc}
     * @param report      the lines to print, each ending in a newline
     */
    public static void reportBlockedRun(UI_Main ideRef, String displayName, String report) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (guard == null || ide == null) {
            return;
        }
        Runnable paint = () -> {
            if (!endsWithPrompt()) {
                if (ide.console.getLength() > 0 && !endsWith("\n")) {
                    guard.appendRaw("\n");
                }
                guard.append(PROMPT);
            }
            if (displayName != null && !displayName.isBlank()) {
                guard.appendRaw(displayName);
            }
            guard.appendRaw("\n");
            guard.lockToEnd();
            guard.append(report == null || report.isEmpty() ? "Run aborted.\n" : report);
            appendPrompt();
        };
        if (Platform.isFxApplicationThread()) {
            paint.run();
        } else {
            Platform.runLater(paint);
        }
    }

    /**
     * Decides whether a command is a script call that must be refused.
     *
     * <p>
     * Returns the report to print when {@code typed} is a bare script name,
     * the matching {@code .nc} file exists in the backend's working folder, and
     * the editor's checks find errors in it. Returns null -- meaning "forward
     * the command as usual" -- in every other case, including every case this
     * method cannot decide. It checks the file as saved on disk, because that
     * is what the backend would run.
     *
     * @param typed the command as the user typed it
     * @return the report, or null to let the command through
     */
    static String blockedScriptReport(String typed) {
        try {
            if (typed == null) {
                return null;
            }
            Matcher call = SCRIPT_CALL.matcher(typed.strip());
            if (!call.matches()) {
                return null;
            }
            String base = call.group(1);
            boolean explicitExtension = call.group(2) != null;

            // `A` may mean the variable A rather than A.nc; let the backend decide.
            if (!explicitExtension && isWorkspaceVariable(base)) {
                return null;
            }

            Path script = findScript(base + ".nc");
            if (script == null) {
                // A bare name may be a builtin or a variable: the backend
                // answers. A name typed with .nc can only be a script.
                return explicitExtension
                        ? "'" + base + ".nc' was not found in the current folder or on the path.\n"
                        : null;
            }
            if (Files.size(script) > SCRIPT_CHECK_MAX_BYTES) {
                return null;
            }

            String text = Files.readString(script, StandardCharsets.UTF_8);
            ErrorClassifier.Classification found = ErrorClassifier.classify(text, CheckContext.forFile(script));
            if (!found.hasErrors()) {
                return null;
            }
            return ErrorClassifier.consoleReport(found, script.getFileName().toString(), "Run");
        } catch (IOException | RuntimeException e) {
            // The check may only ever add a refusal, never break a command.
            return null;
        }
    }

    /**
     * Where a typed script name will be found: the current folder first, then
     * each added folder in the order they were added.
     *
     * @param fileName e.g. {@code sct_01.nc}
     * @return the file, or null if no searched folder has it
     */
    private static Path findScript(String fileName) {
        List<Path> folders = new ArrayList<>();
        Path current = lastWorkspaceDirectory != null ? lastWorkspaceDirectory : workingDirectory;
        if (current != null) {
            folders.add(current);
        }
        folders.addAll(SearchPath.folders());
        for (Path folder : folders) {
            Path candidate = folder.resolve(fileName);
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    /**
     * Refuses a typed full path to a {@code .nc} file whose folder is neither
     * the current folder nor on the path -- the Command Window keeps the same
     * rule as Run and Step.
     *
     * @param typed the line as typed
     * @return the message to print, or null to let the line through
     */
    static String outsidePathReport(String typed) {
        try {
            if (typed == null) {
                return null;
            }
            Matcher m = PATH_CALL.matcher(typed.strip());
            if (!m.matches()) {
                return null;
            }
            Path file = Path.of(m.group(1));
            Path folder = file.toAbsolutePath().getParent();
            if (folder == null) {
                return null;
            }
            Path current = lastWorkspaceDirectory;
            if (current != null && FolderPaths.same(folder, current)) {
                return null;
            }
            if (SearchPath.contains(folder)) {
                return null;
            }
            return "'" + file + "' is not in the current folder or on the path.\n"
                    + "Change the current folder to " + folder + ", or add it with: addpath \"" + folder + "\"\n";
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Handles {@code addpath}, {@code rmpath} and {@code path} typed at the
     * prompt. The line has already been advanced and locked.
     *
     * @param line the line as typed
     * @return true if the line was one of them and has been answered
     */
    private static boolean handlePathCommand(String line) {
        String trimmed = line == null ? "" : line.strip();
        String lower = trimmed.toLowerCase(Locale.ROOT);

        if ((lower.equals("path") || lower.equals("path;")) && !isWorkspaceVariable("path")) {
            appendOutput(describePath());
            appendPrompt();
            return true;
        }

        if (PATH_COMMAND_BARE.matcher(trimmed).matches()) {
            appendOutput("Usage: " + lower.replaceAll("[^a-z].*$", "") + " \"<folder>\"\n");
            appendPrompt();
            return true;
        }

        Matcher m = PATH_COMMAND.matcher(trimmed);
        if (!m.matches()) {
            return false;
        }
        boolean add = m.group(1).equalsIgnoreCase("addpath");
        String argument = unquote(m.group(2));
        Path base = NavigationActions.projectFolder(ide);
        Path folder = FolderPaths.parseTyped(argument, base != null ? base : lastWorkspaceDirectory);
        if (folder == null || (add && !FolderPaths.isFolder(folder))) {
            NavigationActions.say((add ? "addpath" : "rmpath") + ": folder not found: " + argument);
            return true;
        }
        if (add) {
            NavigationActions.addToPath(ide, folder);
        } else {
            NavigationActions.removeFromPath(ide, folder);
        }
        return true;
    }

    /** The answer to {@code path}: the current folder, then the added folders. */
    private static String describePath() {
        StringBuilder out = new StringBuilder();
        Path current = NavigationActions.projectFolder(ide);
        out.append("Current folder:\n    ")
                .append(current != null ? current : "(none)").append('\n');
        List<Path> added = SearchPath.folders();
        out.append("Added to path (this session):\n");
        if (added.isEmpty()) {
            out.append("    (none)\n");
        } else {
            for (Path folder : added) {
                out.append("    ").append(folder).append('\n');
            }
        }
        return out.toString();
    }

    private static String unquote(String text) {
        String value = text == null ? "" : text.strip();
        while (value.length() >= 2
                && ((value.startsWith("\"") && value.endsWith("\""))
                        || (value.startsWith("'") && value.endsWith("'")))) {
            value = value.substring(1, value.length() - 1).strip();
        }
        return value;
    }

    /** @return true when the workspace holds a variable typed as {@code visualName} */
    private static boolean isWorkspaceVariable(String visualName) {
        try {
            String cleaned = CliSymbolCodec.encodeName(visualName);
            return cleaned != null && !cleaned.isBlank() && WorkspaceStore.get().contains(cleaned);
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** @return true while the shared suggestion popup is visible. */
    public static boolean isSuggestionShowing() {
        return suggestionBridge != null && suggestionBridge.isShowing();
    }

    // =====================================================================
    // 4. clear / clear <name>
    // =====================================================================

    /**
     * Resets the whole workspace. Uses the interpreter's existing {@code clear}
     * builtin, so no rebuild is needed; the screen is left alone because Java
     * never clears it here.
     */
    private static void clearAll() {
        WorkspaceStore.get().clearAll();
        if (variablesTxt != null) {
            WorkspaceVariableParser.writeEmpty(variablesTxt);
        }
        // Keep the restart copy in step, or a later Stop would bring the
        // cleared variables back.
        snapshotWorkspace();
        if (isBackendAlive()) {
            sendUser("clear");
        } else {
            appendPrompt();
        }
    }

    /**
     * Removes one variable from the workspace.
     *
     * <p>The interpreter has no {@code unset} builtin, so this rewrites
     * {@code variables.txt} without that record and asks the REPL to reload it
     * with {@code @cmd syncws}.
     *
     * <p><b>Caveat with the current binary.</b> If your compiled {@code nc.exe}
     * predates the {@code syncws} hook in {@code main.cpp}, the unknown
     * {@code @cmd} is silently ignored: the file and the Explorer are correct,
     * but the REPL's in-memory copy still holds the variable and will write it
     * back on its next save. The rebuild notes in NOTES.md close this gap.
     *
     * @param visualName the name the user typed, in editor form
     */
    private static void clearOne(String visualName) {
        String cleaned = CliSymbolCodec.encodeName(visualName);
        if (cleaned == null || cleaned.isBlank()) {
            appendOutput("clear: no variable name given.\n");
            appendPrompt();
            return;
        }
        boolean known = WorkspaceStore.get().contains(cleaned);
        boolean removed = variablesTxt != null
                && WorkspaceVariableParser.removeVariable(variablesTxt, cleaned);

        if (!known && !removed) {
            appendOutput("clear: '" + visualName + "' is not in the workspace.\n");
            appendPrompt();
            return;
        }

        WorkspaceStore.get().remove(cleaned);
        snapshotWorkspace();
        if (isBackendAlive()) {
            sendInternal("@cmd syncws");
        } else {
            appendPrompt();
        }
    }

    // =====================================================================
    // 4b. Stop and busy state
    // =====================================================================

    /**
     * Stops whatever is running and returns the Command Window to a working
     * prompt. The single entry point for Ctrl+C, the ribbon Stop, F6 and the
     * three-dot menu's Stop.
     *
     * <p>Always rewinds every Step session. If a command is executing, or a
     * step block is paused inside the interpreter, the interpreter is killed
     * and relaunched on the saved workspace. If the interpreter is already
     * dead, it is relaunched so the console works again. If it is alive and
     * idle, nothing else happens.
     *
     * @param ideRef the IDE controller
     */
    public static void stopExecution(UI_Main ideRef) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (ide == null) {
            return;
        }
        Runnable action = () -> {
            // A step-into pause leaves the interpreter blocked on stdin even when
            // nothing is owed a reply, so it counts as running. Read it before
            // reset() clears it.
            boolean paused = StepFileRunner.isBlockInProgress();
            StepFileRunner.reset(ide);
            if (guard == null) {
                return;
            }
            boolean alive = isBackendAlive();
            if (alive && !isBusy() && !paused) {
                return; // nothing is running
            }
            restartBackend(alive ? STOP_MESSAGE : null);
        };
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /**
     * Kills the current interpreter and starts a new one on the saved
     * workspace. The seam for a future cooperative interrupt: if the backend
     * ever learns to abort a command on request, signal it here instead of
     * killing, and keep the rest of this method's console handling.
     *
     * @param message printed before the fresh prompt, or null for none
     */
    private static void restartBackend(String message) {
        // Orphan the old process before it dies, so neither its last chunks of
        // output nor its exit watcher can touch the new session.
        generation++;
        Process old = process;
        process = null;
        processWriter = null;
        ide.processWriter = null;
        ide.runningProcess = null;
        ide.programRunning = false;
        killQuietly(old);

        clearBusy();
        silentPrompts = 0;
        stepCarry = "";

        if (message != null) {
            startNewLine();
            guard.append(message);
        }
        appendPrompt();

        // Our prompt is already painted, so the new interpreter's startup
        // prompt is swallowed; any leftover ">> >> " is folded anyway.
        launch(false, true, true);
    }

    /**
     * Restarts the interpreter on the same workspace without a word: no
     * message, and its startup prompt is swallowed because the console is
     * already sitting at one. Used when the path loses a folder. Call only
     * while idle, on the FX thread.
     */
    private static void restartQuietly() {
        if (ide == null || guard == null) {
            return;
        }
        generation++;
        Process old = process;
        process = null;
        processWriter = null;
        ide.processWriter = null;
        ide.runningProcess = null;
        ide.programRunning = false;
        killQuietly(old);

        clearBusy();
        silentPrompts = 0;
        stepCarry = "";
        launch(false, true, true);
    }

    private static void killQuietly(Process old) {
        if (old == null) {
            return;
        }
        try {
            old.getOutputStream().close();
        } catch (IOException ignored) {
            // the process is being killed anyway
        }
        old.destroyForcibly();
        try {
            old.waitFor(KILL_WAIT_MS, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * True while a command sent by the user, Run or Step is still executing.
     *
     * @return the busy flag
     */
    public static boolean isBusy() {
        return BUSY.get();
    }

    /**
     * True while the interpreter is doing something Stop should end: a command
     * is owed a reply, or a step block is paused inside it.
     *
     * @return busy, or a paused step block
     */
    public static boolean isExecuting() {
        return isBusy() || StepFileRunner.isBlockInProgress();
    }

    /**
     * Observable busy flag, for enabling the Stop controls.
     *
     * @return read-only busy property (changes on the FX thread only)
     */
    public static ReadOnlyBooleanProperty busyProperty() {
        return BUSY.getReadOnlyProperty();
    }

    /**
     * Sends a line on behalf of another part of the IDE (via
     * {@code EditorManager.sendCommandToTerminal}) so that it counts towards
     * the busy state exactly like a typed command. Refused while a step block
     * is paused; the Step runner itself uses {@link #sendStepLine}.
     *
     * @param ideRef  the IDE controller
     * @param command the line to send
     */
    public static void sendFromIde(UI_Main ideRef, String command) {
        if (ideRef != null) {
            ide = ideRef;
        }
        if (command == null) {
            return;
        }
        Runnable action = () -> {
            if (refuseWhilePaused()) {
                return;
            }
            if (!ensureBackend()) {
                appendOutput("UPI terminal is not running.\n");
                appendPrompt();
                return;
            }
            sendUser(command);
        };
        if (Platform.isFxApplicationThread()) {
            action.run();
        } else {
            Platform.runLater(action);
        }
    }

    /** Records one more reply owed and raises the busy flag. */
    private static void markSent() {
        pendingReplies++;
        stopSettleTimer();
        setBusy(true);
    }

    private static void clearBusy() {
        pendingReplies = 0;
        stopSettleTimer();
        setBusy(false);
    }

    private static void setBusy(boolean busy) {
        if (Platform.isFxApplicationThread()) {
            BUSY.set(busy);
        } else {
            Platform.runLater(() -> BUSY.set(busy));
        }
    }

    /**
     * Clears an unpaid reply debt once the console has sat at a prompt with no
     * new output for {@link #SETTLE_DELAY}. Covers an interpreter that answers
     * a multi-line block with a single prompt.
     */
    private static void armSettleTimer() {
        if (settleTimer == null) {
            settleTimer = new PauseTransition(SETTLE_DELAY);
            settleTimer.setOnFinished(e -> {
                if (ide != null && ide.console != null && endsWithPrompt()) {
                    clearBusy();
                    notifyStepIdle();
                    runPendingRebuild();
                }
            });
        }
        settleTimer.playFromStart();
    }

    private static void stopSettleTimer() {
        if (settleTimer != null) {
            settleTimer.stop();
        }
    }

    // =====================================================================
    // 4c. Workspace snapshot (what a restart comes back to)
    // =====================================================================

    /** Copies variables.txt aside. Called only when the file is known complete. */
    private static void snapshotWorkspace() {
        if (variablesTxt == null || snapshotTxt == null || !Files.exists(variablesTxt)) {
            return;
        }
        try {
            Files.copy(variablesTxt, snapshotTxt, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException | RuntimeException ignored) {
            // A missed snapshot only means a restart falls back to variables.txt.
        }
    }

    /** Puts the last complete workspace back before a relaunch. */
    private static void restoreWorkspaceSnapshot() {
        if (variablesTxt == null || snapshotTxt == null || !Files.exists(snapshotTxt)) {
            return;
        }
        try {
            Files.copy(snapshotTxt, variablesTxt, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException | RuntimeException ignored) {
            // Fall back to whatever variables.txt holds.
        }
    }

    // =====================================================================
    // 5. Output streaming + Explorer refresh
    // =====================================================================

    private static void startReader(Process source, int gen) {
        OutputPump pump = new OutputPump(gen);
        Thread readerThread = new Thread(() -> {
            // A Reader keeps one decoder across reads. Constructing a String
            // per raw byte-chunk (the previous approach) corrupts any
            // multi-byte character that straddles a chunk boundary — which is
            // exactly what Greek and Tamil output is made of.
            try (Reader in = new InputStreamReader(source.getInputStream(), StandardCharsets.UTF_8)) {
                char[] buffer = new char[8192];
                int length;
                while ((length = in.read(buffer)) != -1) {
                    pump.offer(buffer, length);
                }
            } catch (IOException ignored) {
                // Stream closed on shutdown or kill — nothing to do.
            }
        }, "cli-nc-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    /**
     * Moves interpreter output onto the FX thread in <b>batches</b>.
     *
     * <h3>Why this exists (the frozen screen)</h3>
     * The reader used to post one {@code Platform.runLater} per 2 KB chunk. A
     * loop such as {@code while 1: publish("running....!")} produces chunks far
     * faster than the FX thread can append them, and every append costs time
     * proportional to the <i>whole</i> transcript: the console re-wraps its
     * text, and two text listeners (symbol input, suggestions) each rebuild
     * the full transcript string on every change. The FX event queue filled
     * with output faster than it drained, so clicks -- the Stop button, the
     * menus, the editor -- waited behind thousands of appends and the window
     * looked frozen.
     *
     * <h3>What it does now</h3>
     * <ul>
     *   <li>The reader thread only appends to a buffer. At most one drain is
     *       queued at a time, and drains are spaced at least
     *       {@link #DRAIN_INTERVAL_MS} apart, so the FX thread always has time
     *       left for input.</li>
     *   <li>Output arriving faster than that is coalesced into one append per
     *       drain. If more than {@link #PENDING_CAP} characters pile up between
     *       drains, the oldest are dropped -- nobody can read them scrolling
     *       past at that rate anyway, and the newest output (including the
     *       final prompt) is always kept.</li>
     *   <li>The console itself is capped at {@link #CONSOLE_MAX_CHARS}; see
     *       {@code ConsoleInputGuard.trimHistory}.</li>
     * </ul>
     * One pump belongs to one interpreter; after a Stop its leftovers are
     * discarded by the generation check.
     */
    private static final class OutputPump {
        private final int gen;
        private final StringBuilder pending = new StringBuilder();
        private boolean scheduled;
        private long lastDrainNanos;

        OutputPump(int gen) {
            this.gen = gen;
        }

        /** Reader thread: buffer the chunk, queue one drain if none is queued. */
        void offer(char[] buffer, int length) {
            synchronized (this) {
                pending.append(buffer, 0, length);
                if (pending.length() > PENDING_CAP) {
                    int cut = pending.length() - PENDING_CAP;
                    // Never split a surrogate pair.
                    if (Character.isLowSurrogate(pending.charAt(cut))) {
                        cut++;
                    }
                    pending.delete(0, cut);
                }
                if (scheduled) {
                    return;
                }
                scheduled = true;
            }
            Platform.runLater(this::scheduleDrain);
        }

        /** FX thread: drain now, or after the rest of the minimum interval. */
        private void scheduleDrain() {
            long sinceMs = (System.nanoTime() - lastDrainNanos) / 1_000_000L;
            long waitMs = DRAIN_INTERVAL_MS - sinceMs;
            if (waitMs <= 0) {
                drain();
            } else {
                PauseTransition delay = new PauseTransition(Duration.millis(waitMs));
                delay.setOnFinished(e -> drain());
                delay.play();
            }
        }

        private void drain() {
            String text;
            synchronized (this) {
                text = pending.toString();
                pending.setLength(0);
                scheduled = false;
            }
            lastDrainNanos = System.nanoTime();
            if (gen == generation && !text.isEmpty()) {
                onOutput(text);
            }
        }
    }

    private static void startExitWatcher(Process watched, int gen) {
        Thread watcher = new Thread(() -> {
            try {
                watched.waitFor();
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            Platform.runLater(() -> {
                if (gen != generation) {
                    return; // stopped on purpose and already replaced
                }
                process = null;
                processWriter = null;
                ide.programRunning = false;
                ide.runningProcess = null;
                ide.processWriter = null;
                clearBusy();
                stepCarry = "";
                // A block paused in the dead interpreter can never be resumed.
                if (StepFileRunner.isBlockInProgress()) {
                    StepFileRunner.reset(ide);
                }
                if (!shuttingDown) {
                    startNewLine();
                    appendOutput(CRASH_MESSAGE);
                    appendPrompt();
                }
            });
        }, "cli-nc-exit-watcher");
        watcher.setDaemon(true);
        watcher.start();
    }

    private static void onOutput(String text) {
        if (ide == null || ide.console == null || text == null || text.isEmpty() || guard == null) {
            return;
        }
        stopSettleTimer();

        // Prompts owed to IDE-internal commands are consumed here rather than
        // printed. The interpreter answers every line it reads with a prompt,
        // including the "@cmd" lines the user never typed.
        String remaining = text;
        while (silentPrompts > 0 && remaining.startsWith(PROMPT)) {
            remaining = remaining.substring(PROMPT.length());
            silentPrompts--;
        }
        if (!remaining.isEmpty() && !remaining.startsWith(PROMPT)) {
            // Real output arrived, so any prompt we were still waiting to
            // swallow is never coming; drop the debt rather than let it eat a
            // legitimate prompt later.
            silentPrompts = 0;
        }

        // "@STEPAT <n>" is a step-into pause marker, not script output: hand it
        // to the Step runner and keep it off the console. A marker cut off at
        // the end of the previous read was held back; finish it now.
        if (!stepCarry.isEmpty()) {
            remaining = stepCarry + remaining;
            stepCarry = "";
        }
        if (StepFileRunner.isBlockInProgress() || remaining.contains(STEPAT_TAG)) {
            remaining = extractStepMarkers(remaining);
        }

        // Every prompt left after the internal ones pays back one reply owed.
        if (pendingReplies > 0) {
            pendingReplies = Math.max(0, pendingReplies - countPrompts(remaining));
        }

        if (!remaining.isEmpty()) {
            // nc.exe answers in cleaned names ("var_mu = 25"). The console is
            // the user's side of the boundary, so names are turned back into
            // their visual form here and the echo reads "μ = 25". Ordinary
            // names and all other output are untouched.
            guard.appendRaw(CliSymbolCodec.decodeOutput(remaining));
        }
        collapseTrailingPrompts();

        // Bound the transcript: the cost of every append and every text
        // listener grows with its length.
        guard.trimHistory(CONSOLE_MAX_CHARS, CONSOLE_KEEP_CHARS);

        // The prompt marks the end of a command: the interpreter has finished
        // and variables.txt is fully written, so this is the correct moment to
        // refresh the workspace.
        if (endsWithPrompt()) {
            guard.lockToEnd();
            snapshotWorkspace();
            reloadWorkspace();
            // The Step runner hears first, so a block it closes here no longer
            // holds back a waiting path rebuild below.
            notifyStepIdle();
            if (pendingReplies == 0) {
                setBusy(false);
                runPendingRebuild();
            } else {
                armSettleTimer();
            }
        }
    }

    /**
     * Removes every complete pause marker from {@code text}, reporting each to
     * the Step runner, and holds back an incomplete one at the very end (only
     * while a block is in progress, so ordinary output is never delayed).
     *
     * @param text output, with any held-back carry already in front
     * @return the text to show on the console
     */
    private static String extractStepMarkers(String text) {
        boolean live = StepFileRunner.isBlockInProgress();
        StringBuilder kept = new StringBuilder(text.length());
        Matcher m = STEPAT_LINE.matcher(text);
        int last = 0;
        while (m.find()) {
            kept.append(text, last, m.start());
            if (live && m.group(2) == null && m.end() == text.length()) {
                // "@STEPAT 1" at the end of a read may still be "@STEPAT 12".
                stepCarry = text.substring(m.start());
                return kept.toString();
            }
            last = m.end();
            notifyStepAt(m.group(1));
        }
        String rest = text.substring(last);
        if (live) {
            int at = rest.lastIndexOf('@');
            if (at >= 0 && STEPAT_PREFIX.matcher(rest.substring(at)).matches()) {
                stepCarry = rest.substring(at);
                rest = rest.substring(0, at);
            }
        }
        kept.append(rest);
        return kept.toString();
    }

    private static void notifyStepAt(String digits) {
        if (stepAtListener == null) {
            return;
        }
        try {
            stepAtListener.accept(Integer.parseInt(digits));
        } catch (NumberFormatException ignored) {
            // A marker too large to be a line number is not one of ours.
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }

    private static void notifyStepIdle() {
        if (stepIdleListener == null) {
            return;
        }
        try {
            stepIdleListener.run();
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }

    private static int countPrompts(String text) {
        int count = 0;
        int from = 0;
        while ((from = text.indexOf(PROMPT, from)) >= 0) {
            count++;
            from += PROMPT.length();
        }
        return count;
    }

    /**
     * Collapses ">> >> " down to a single prompt.
     *
     * <p>Safety net for the suppression above: output can be delivered in
     * chunks that split a prompt across two reads, in which case the
     * {@code startsWith} test misses. Two prompts with nothing between them are
     * always noise, whatever produced them, so they are folded here.
     */
    private static void collapseTrailingPrompts() {
        guard.systemWrite(() -> {
            while (endsWith(PROMPT + PROMPT)) {
                int length = ide.console.getLength();
                ide.console.deleteText(length - PROMPT.length(), length);
            }
            ide.console.positionCaret(ide.console.getLength());
        });
    }

    /**
     * Reloads {@code variables.txt} into the Explorer. Rows are merged in
     * place by {@link WorkspaceStore}, so nothing is duplicated and nothing is
     * dropped that the interpreter still holds.
     */
    public static void reloadWorkspace() {
        if (variablesTxt == null || !Files.exists(variablesTxt)) {
            return;
        }
        List<Variable> globals = WorkspaceVariableParser.parse(variablesTxt);
        WorkspaceStore.get().sync(globals);
    }

    /** @return the shared workspace file, or null before the backend starts */
    public static Path getVariablesFile() {
        return variablesTxt;
    }

    // =====================================================================
    // 6. Low-level plumbing
    // =====================================================================

    /**
     * Sends a command the user did not type, and records that its prompt must
     * be swallowed rather than displayed.
     *
     * @param line the internal command
     */
    private static void sendInternal(String line) {
        silentPrompts++;
        sendRaw(line);
    }

    /**
     * Sends a line whose prompt the user is waiting for, and counts it towards
     * the busy state.
     *
     * @param line the command
     */
    private static void sendUser(String line) {
        markSent();
        if (!sendRaw(line)) {
            // No reply is coming for a line that never left.
            clearBusy();
            appendPrompt();
        }
    }

    /**
     * Writes one line to the interpreter's stdin.
     *
     * @param line the line
     * @return true when the line was written
     */
    private static boolean sendRaw(String line) {
        if (processWriter == null) {
            appendOutput("Input error: backend not connected.\n");
            return false;
        }
        try {
            processWriter.write(line);
            processWriter.newLine();
            processWriter.flush();
            return true;
        } catch (IOException ex) {
            appendOutput("Input error: " + ex.getMessage() + "\n");
            return false;
        }
    }

    /** Cleanly stops the backend (used on Exit / app close). */
    public static void shutdown() {
        shuttingDown = true;
        try {
            if (processWriter != null) {
                processWriter.write("exit");
                processWriter.newLine();
                processWriter.flush();
            }
        } catch (IOException ignored) {
            // fall through to destroy
        }
        if (process != null && process.isAlive()) {
            process.destroy();
        }
    }

    /**
     * Appends IDE-generated text to the console, respecting the freeze.
     *
     * @param text the text to append
     */
    public static void appendOutput(String text) {
        if (guard == null) {
            return;
        }
        if (Platform.isFxApplicationThread()) {
            guard.append(text);
        } else {
            Platform.runLater(() -> guard.append(text));
        }
    }

    /** Ends a half-written output line ("running....!" cut off by a kill). */
    private static void startNewLine() {
        if (guard != null && ide != null && ide.console != null
                && ide.console.getLength() > 0 && !endsWith("\n")) {
            guard.appendRaw("\n");
        }
    }

    /** Paints a prompt locally (only when the backend cannot provide one). */
    public static void appendPrompt() {
        if (guard == null) {
            return;
        }
        Runnable paint = () -> {
            if (!endsWithPrompt()) {
                if (ide.console.getLength() > 0 && !endsWith("\n")) {
                    guard.appendRaw("\n");
                }
                guard.append(PROMPT);
            }
        };
        if (Platform.isFxApplicationThread()) {
            paint.run();
        } else {
            Platform.runLater(paint);
        }
    }

    private static Path resolveNcExe() {
        String override = System.getProperty(NC_EXE_PROPERTY);
        if (override != null && !override.isBlank()) {
            Path p = Path.of(override);
            if (Files.exists(p)) {
                return p;
            }
        }
        Path base = Path.of(System.getProperty("user.dir"));
        for (String candidate : NC_EXE_CANDIDATES) {
            Path p = base.resolve(candidate);
            if (Files.exists(p)) {
                return p;
            }
        }
        return null;
    }

    private static boolean endsWithPrompt() {
        return endsWith(PROMPT);
    }

    private static boolean endsWith(String suffix) {
        int length = ide.console.getLength();
        if (length < suffix.length()) {
            return false;
        }
        return suffix.equals(ide.console.getText(length - suffix.length(), length));
    }

    private static boolean isExit(String s) {
        String n = norm(s);
        return n.equals("exit") || n.equals("exit()") || n.equals("quit") || n.equals("quit()");
    }

    /** cls = clear screen only (keep workspace). */
    private static boolean isClearScreen(String s) {
        String n = norm(s);
        return n.equals("cls") || n.equals("clc");
    }

    /**
     * Recognises {@code clear} and {@code clear <name>}.
     *
     * @param s the submitted line
     * @return null when this is not a clear command, "" for a full clear, or
     *         the variable name for a targeted clear
     */
    private static String clearTarget(String s) {
        String raw = s == null ? "" : s.strip();
        String lower = raw.toLowerCase(Locale.ROOT);
        if (lower.equals("clear")) {
            return "";
        }
        if (lower.startsWith("clear ")) {
            return raw.substring(6).strip();
        }
        return null;
    }

    private static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase(Locale.ROOT);
    }
}
