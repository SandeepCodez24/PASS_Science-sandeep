package ui.cli;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import ui.UI_Main;

/**
 * Makes the Command Window behave like MATLAB's: everything above the current
 * {@code >> } prompt is frozen history, and the prompt itself is a hard stop
 * that BACKSPACE cannot cross.
 *
 * <h3>Why this is its own class</h3>
 * The old approach put a couple of checks in {@code setOnKeyPressed}. That
 * blocks the obvious case and misses every other way a JavaFX
 * {@code TextArea} can be mutated: a selection dragged across the boundary and
 * then overtyped, DELETE, Ctrl+X, a paste over a spanning selection,
 * drag-and-drop text, and Ctrl+Z (undo can wipe the entire transcript in one
 * keystroke). It also fought the control's own behaviour, because
 * {@code setOnKeyPressed} installs a handler, not a filter.
 *
 * <h3>Now on a RichTextFX area</h3>
 * The console became a {@link ConsoleArea} so commands can be syntax
 * coloured. RichTextFX has no {@code TextFormatter}; layer 2 is now an
 * <i>edit veto</i> on the area, which every edit passes through, so the
 * freeze is exactly as airtight as before. Undo and drag-to-move are switched
 * off in the area itself.
 *
 * <h3>The four layers</h3>
 * <ol>
 *   <li><b>Anchor.</b> {@code ide.inputStart} is the offset just past the
 *       prompt. Everything below it is committed.</li>
 *   <li><b>Edit veto.</b> {@link ConsoleArea#setEditVeto} rejects <em>any</em>
 *       edit whose range starts before the anchor. Every mutation path in the
 *       area funnels through it, so this one layer covers typing, paste, cut
 *       and delete at once — that is what makes the freeze airtight rather
 *       than merely usually right.</li>
 *   <li><b>Caret after edits.</b> An accepted edit starts at or after the
 *       prompt, and the area leaves the caret at its end, so the caret can
 *       never be left in the history by an edit. Selection-only changes are
 *       left alone so the history can be selected and copied (see below).</li>
 *   <li><b>Key filter.</b> Handles what the formatter cannot see: ENTER
 *       submission, HOME / Ctrl+A scoped to the input line, UP/DOWN history
 *       recall, and suppressing undo/redo.</li>
 * </ol>
 *
 * <h3>Select and copy the history</h3>
 * The history is frozen against <em>editing</em>, not against
 * <em>selection</em>. Layer 3 used to pull the caret and the selection anchor
 * forward to the prompt on every change, so a mouse drag over earlier commands
 * or output collapsed the instant it started, and nothing could be copied.
 * Now only content changes are clamped; a selection may lie anywhere, and
 * Ctrl+C (or the console's right-click menu) copies it.
 * <ul>
 *   <li>A plain click in the history still returns the caret to the prompt, as
 *       before; a drag or a double-click keeps its selection.</li>
 *   <li>Shift+arrows extend a selection into the history.</li>
 *   <li>Ctrl+X over the history copies instead of cutting.</li>
 *   <li>Typing, Backspace, Delete, paste or a plain arrow while the selection is
 *       in the history first returns the caret to the end of the prompt line,
 *       so the keystroke goes to the input and never to the history.</li>
 * </ul>
 * Layer 2 is untouched, so no change can ever reach committed text.
 *
 * <h3>Ctrl+C: stop or copy</h3>
 * While a command is executing ({@link #setBusy}), Ctrl+C stops it through
 * {@link #setOnInterrupt}, whatever is selected -- the MATLAB rule, "busy
 * always means stop". While idle it copies, exactly as before. The check runs
 * first in the key filter, so a selection in the history cannot turn a stop
 * into a copy. The right-click menu's Copy is unaffected: it always copies.
 *
 * <h3>System writes</h3>
 * Output from {@code nc.exe} is appended by the IDE itself and must bypass the
 * filter, otherwise the console would reject its own output. All such writes go
 * through {@link #systemWrite(Runnable)}, which is the only way to move the
 * anchor forward.
 */
public final class ConsoleInputGuard {

    private static final int HISTORY_LIMIT = 200;

    private final UI_Main ide;
    private final ConsoleArea area;

    private boolean systemWriting;
    private Runnable onSubmit = () -> { };
    private BooleanSupplier suppressEnter = () -> false;
    private BooleanSupplier busy = () -> false;
    private Runnable onInterrupt = () -> { };

    private final List<String> history = new ArrayList<>();
    private int historyCursor = 0;
    private String draft = "";

    /**
     * @param ide  the IDE controller (owns {@code inputStart})
     * @param area the console
     */
    public ConsoleInputGuard(UI_Main ide, ConsoleArea area) {
        this.ide = ide;
        this.area = area;
        installContentFilter();
        installKeyFilter();
        installPointerClamp();
    }

    // -----------------------------------------------------------------
    // Wiring
    // -----------------------------------------------------------------

    /**
     * @param action invoked when ENTER is pressed on an unfrozen line
     */
    public void setOnSubmit(Runnable action) {
        this.onSubmit = action == null ? () -> { } : action;
    }

    /**
     * @param condition when true, ENTER is left alone (the suggestion popup is
     *                  open and wants to consume it)
     */
    public void setSuppressEnter(BooleanSupplier condition) {
        this.suppressEnter = condition == null ? () -> false : condition;
    }

    /**
     * @param condition true while a command is executing; Ctrl+C then stops
     *                  instead of copying
     */
    public void setBusy(BooleanSupplier condition) {
        this.busy = condition == null ? () -> false : condition;
    }

    /**
     * @param action invoked by Ctrl+C while {@link #setBusy busy}
     */
    public void setOnInterrupt(Runnable action) {
        this.onInterrupt = action == null ? () -> { } : action;
    }

    // -----------------------------------------------------------------
    // System writes
    // -----------------------------------------------------------------

    /**
     * Runs a privileged console mutation (printing output, painting a prompt,
     * clearing the screen) with the freeze temporarily lifted.
     *
     * @param action the mutation to perform
     */
    public void systemWrite(Runnable action) {
        boolean previous = systemWriting;
        systemWriting = true;
        try {
            action.run();
        } finally {
            systemWriting = previous;
        }
    }

    /**
     * Appends text as output and moves the freeze boundary past it.
     *
     * @param text the text to append
     */
    public void append(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        systemWrite(() -> {
            area.appendText(text);
            ide.inputStart = area.getLength();
            area.positionCaret(area.getLength());
        });
    }

    /**
     * Appends text without moving the boundary — used for the newline that
     * follows a submitted command, where the boundary is set by the caller.
     *
     * @param text the text to append
     */
    public void appendRaw(String text) {
        if (text == null || text.isEmpty()) {
            return;
        }
        systemWrite(() -> {
            area.appendText(text);
            area.positionCaret(area.getLength());
        });
    }

    /** Wipes the transcript (the {@code cls} command) and resets the anchor. */
    public void clearScreen() {
        systemWrite(() -> {
            area.clear();
            ide.inputStart = 0;
            area.positionCaret(0);
        });
    }

    /**
     * Drops the oldest part of the transcript once it grows past
     * {@code maxChars}, keeping roughly the last {@code keepChars}. The cut is
     * moved forward to a line start so no half line is left at the top.
     *
     * <p>A long-running loop that prints every iteration would otherwise grow
     * the transcript without limit, and every append, re-wrap and text listener
     * costs time proportional to its length -- which is what froze the window.
     * MATLAB's Command Window caps its buffer for the same reason.
     *
     * @param maxChars  trim only above this length
     * @param keepChars approximate length left after a trim
     */
    public void trimHistory(int maxChars, int keepChars) {
        int length = area.getLength();
        if (length <= maxChars || keepChars >= length) {
            return;
        }
        int cut = length - Math.max(0, keepChars);
        String head = area.getText(cut, Math.min(length, cut + 4096));
        int newline = head.indexOf('\n');
        if (newline >= 0) {
            cut += newline + 1;
        }
        final int removed = cut;
        systemWrite(() -> {
            area.deleteText(0, removed);
            ide.inputStart = Math.max(0, ide.inputStart - removed);
            area.positionCaret(area.getLength());
        });
    }

    /** Moves the freeze boundary to the end of the current text. */
    public void lockToEnd() {
        systemWrite(() -> {
            ide.inputStart = area.getLength();
            area.positionCaret(area.getLength());
        });
    }

    /** @return the text the user has typed after the prompt */
    public String currentInput() {
        int end = area.getLength();
        int start = Math.max(0, Math.min(ide.inputStart, end));
        return area.getText(start, end);
    }

    /**
     * @return true while the IDE is writing to the console itself, so
     *         listeners can tell an append of interpreter output apart from
     *         the user typing
     */
    public boolean isSystemWriting() {
        return systemWriting;
    }

    /**
     * Replaces the text after the prompt. Used by history recall and by live
     * symbol replacement, both of which rewrite the input line wholesale.
     *
     * @param replacement the new input line
     */
    public void setInput(String replacement) {
        replaceInput(replacement);
    }

    /** Replaces the current input line (history recall). */
    private void replaceInput(String replacement) {
        int end = area.getLength();
        int start = Math.max(0, Math.min(ide.inputStart, end));
        systemWrite(() -> {
            area.replaceText(start, end, replacement == null ? "" : replacement);
            area.positionCaret(area.getLength());
        });
    }

    /**
     * Records a submitted command for UP/DOWN recall.
     *
     * @param command the submitted line
     */
    public void rememberCommand(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        if (history.isEmpty() || !history.get(history.size() - 1).equals(command)) {
            history.add(command);
        }
        while (history.size() > HISTORY_LIMIT) {
            history.remove(0);
        }
        historyCursor = history.size();
        draft = "";
    }

    // -----------------------------------------------------------------
    // Copy
    // -----------------------------------------------------------------

    /** Copies the current selection, wherever it lies. Does nothing when empty. */
    public void copySelection() {
        String selected = area.getSelectedText();
        if (selected != null && !selected.isEmpty()) {
            copyToClipboard(selected);
        }
    }

    /** Copies the whole transcript: every command, output and the prompt line. */
    public void copyAll() {
        copyAll(area);
    }

    /**
     * Copies a console's whole transcript. Static so the Command Window's
     * three-dot menu can use it without holding the guard.
     *
     * @param console the console
     */
    public static void copyAll(ConsoleArea console) {
        if (console != null) {
            copyToClipboard(console.getText());
        }
    }

    private static void copyToClipboard(String text) {
        ClipboardContent content = new ClipboardContent();
        content.putString(text == null ? "" : text);
        Clipboard.getSystemClipboard().setContent(content);
    }

    /** True when the caret or the selection anchor sits in committed history. */
    private boolean selectionInHistory() {
        int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
        return area.getCaretPosition() < anchor || area.getAnchor() < anchor;
    }

    /** Leaves the history: caret to the end of the prompt line, selection cleared. */
    private void returnToPrompt() {
        area.positionCaret(area.getLength());
    }

    // -----------------------------------------------------------------
    // Layer 2 + 3: edit veto
    // -----------------------------------------------------------------

    private void installContentFilter() {
        area.setEditVeto((start, end) -> {
            if (systemWriting) {
                return false;
            }
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            // Layer 2: the edit reaches into committed history. Refuse the
            // whole edit rather than trimming it, so a spanning paste cannot
            // partially apply. An accepted edit leaves the caret at its own
            // end, which is at or after the prompt (layer 3). Selection-only
            // changes never come here, so the history can still be selected
            // and copied.
            return start < anchor;
        });
    }

    private void installPointerClamp() {
        // A click lands the caret before the formatter sees a selection change
        // in some skins; clamping on release covers that.
        area.addEventFilter(MouseEvent.MOUSE_RELEASED, event -> {
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            if (area.getCaretPosition() < anchor && area.getSelection().getLength() == 0) {
                area.positionCaret(anchor);
            }
        });
    }

    // -----------------------------------------------------------------
    // Layer 4: key filter
    // -----------------------------------------------------------------

    private void installKeyFilter() {
        area.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            int anchor = Math.max(0, Math.min(ide.inputStart, area.getLength()));
            KeyCode code = event.getCode();

            // ── Ctrl+C while a command runs: stop it (busy always means stop) ──
            if (code == KeyCode.C && event.isShortcutDown()
                    && !event.isAltDown() && !event.isShiftDown()
                    && busy.getAsBoolean()) {
                event.consume();
                onInterrupt.run();
                return;
            }

            // ── Selection in the history: copy is allowed, editing is not ──
            if (selectionInHistory()) {
                if (code.isModifierKey()) {
                    return; // Ctrl / Shift alone: keep the selection
                }
                if (event.isShortcutDown() && (code == KeyCode.C || code == KeyCode.INSERT)) {
                    copySelection();
                    event.consume();
                    return;
                }
                if (event.isShortcutDown() && code == KeyCode.X) {
                    copySelection(); // copy, never cut, from the history
                    event.consume();
                    return;
                }
                if (event.isShiftDown() && isNavigation(code)) {
                    return; // extending the selection
                }
                // Any other key belongs to the prompt line.
                returnToPrompt();
                if (code == KeyCode.BACK_SPACE || code == KeyCode.DELETE
                        || code == KeyCode.LEFT || code == KeyCode.RIGHT
                        || code == KeyCode.HOME || code == KeyCode.END
                        || code == KeyCode.ESCAPE) {
                    event.consume(); // that key only meant "leave the history"
                    return;
                }
                // Letters, ENTER, paste, UP/DOWN recall: fall through and run
                // normally, now at the prompt.
            }

            // Undo/redo would restore text from before the boundary.
            if (event.isShortcutDown() && (code == KeyCode.Z || code == KeyCode.Y)) {
                event.consume();
                return;
            }

            // Select-all takes the whole transcript, matching the right-click
            // Select All (Ctrl+A). Checked first so an existing selection in
            // the history doesn't bounce it back to the prompt line.
            if (event.isShortcutDown() && code == KeyCode.A) {
                area.selectRange(0, area.getLength());
                event.consume();
                return;
            }

            if (code == KeyCode.HOME) {
                if (event.isShiftDown()) {
                    area.selectRange(area.getCaretPosition(), anchor);
                } else {
                    area.positionCaret(anchor);
                }
                event.consume();
                return;
            }

            // ">>" is the hard stop: no backspace, no left-arrow past it.
            if ((code == KeyCode.BACK_SPACE || code == KeyCode.LEFT)
                    && area.getSelection().getLength() == 0
                    && area.getCaretPosition() <= anchor) {
                event.consume();
                return;
            }

            if (suppressEnter.getAsBoolean()) {
                // The suggestion popup owns ENTER/UP/DOWN while it is visible.
                return;
            }

            if (code == KeyCode.UP) {
                recallHistory(-1);
                event.consume();
                return;
            }
            if (code == KeyCode.DOWN) {
                recallHistory(1);
                event.consume();
                return;
            }

            if (code == KeyCode.ENTER) {
                // The TextArea would insert its own newline on KEY_TYPED;
                // consuming here plus the KEY_TYPED filter below means Java is
                // the sole author of newlines, so one ENTER advances one line.
                event.consume();
                onSubmit.run();
            }
        });

        area.addEventFilter(KeyEvent.KEY_TYPED, event -> {
            String character = event.getCharacter();
            if (character != null && (character.equals("\r") || character.equals("\n"))) {
                event.consume();
                return;
            }
            // Safety net: a printable character never lands in the history.
            if (character != null && !character.isEmpty() && character.charAt(0) >= 0x20
                    && character.charAt(0) != 0x7F && !event.isShortcutDown() && selectionInHistory()) {
                returnToPrompt();
            }
        });
    }

    private static boolean isNavigation(KeyCode code) {
        return code == KeyCode.LEFT || code == KeyCode.RIGHT || code == KeyCode.UP
                || code == KeyCode.DOWN || code == KeyCode.HOME || code == KeyCode.END
                || code == KeyCode.PAGE_UP || code == KeyCode.PAGE_DOWN;
    }

    private void recallHistory(int direction) {
        if (history.isEmpty()) {
            return;
        }
        if (historyCursor == history.size()) {
            draft = currentInput();
        }
        int next = historyCursor + direction;
        if (next < 0) {
            next = 0;
        }
        if (next > history.size()) {
            next = history.size();
        }
        historyCursor = next;
        replaceInput(historyCursor == history.size() ? draft : history.get(historyCursor));
    }
}
