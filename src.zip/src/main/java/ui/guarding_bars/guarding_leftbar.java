package ui.guarding_bars;

/**
 * The guarding bar at the far left of the main window.
 *
 * <p>
 * It replaces the thin edge strip that used to sit inside the File Explorer
 * ({@code CodeBotHost}), and now belongs to the window rather than to a
 * panel: it stays put in every layout, and when the File Explorer collapses
 * or is not shown at all. Its inner line is on its right edge, facing the
 * panels.
 * </p>
 *
 * <p>
 * Tools for this bar go in with {@link #addTool}. None are defined yet.
 * </p>
 */
public final class guarding_leftbar extends GuardingBar {

    /** Marks the left bar. */
    public static final String SIDE_CLASS = "guarding-left";

    public guarding_leftbar() {
        super(SIDE_CLASS);
    }
}
