package ui.guarding_bars;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;
import ui.design.ThemeSheetSync;

/**
 * Puts the two guarding bars into the main window.
 *
 * <h3>Placement</h3>
 * <p>
 * The bars are the {@code left} and {@code right} of the window's
 * {@link BorderPane}. A BorderPane gives its top (ribbon and quick-access
 * row) and bottom (footer) the full width and puts left / centre / right
 * between them, so the bars run exactly from below the breadcrumb down to the
 * footer, outside every layout {@code LayoutManager} builds.
 * </p>
 *
 * <h3>Colour</h3>
 * <p>
 * The bars used to copy the live colour of the split dividers. The dividers
 * are now a thin mid-grey line in a background-coloured drag area, so copying
 * them would turn the 6 mm bars into solid dark-grey slabs. The bars therefore
 * take their fill from their own stylesheet
 * ({@code themes/guarding_bars/guarding_light.css} / {@code guarding_dark.css}),
 * and their inner-edge line uses the same grey as the dividers and the line
 * under the quick-access row, so every boundary in the window matches.
 * </p>
 */
public final class GuardingBars {

    private static final String LIGHT_CSS = "/themes/guarding_bars/guarding_light.css";
    private static final String DARK_CSS = "/themes/guarding_bars/guarding_dark.css";

    private static guarding_leftbar left;
    private static guarding_rightbar right;

    private GuardingBars() {
    }

    /**
     * Builds both bars and places them either side of the layout host.
     *
     * @param root   the window's root pane
     * @param center the layout host returned by {@code LayoutManager.install};
     *               kept in the signature so the call site stays as it is
     */
    public static void install(BorderPane root, Region center) {
        if (root == null) {
            return;
        }
        left = new guarding_leftbar();
        right = new guarding_rightbar();
        root.setLeft(left);
        root.setRight(right);
        ThemeSheetSync.attach(left, LIGHT_CSS, DARK_CSS);
    }

    /** @return the left bar, or null before {@link #install} */
    public static guarding_leftbar left() {
        return left;
    }

    /** @return the right bar, or null before {@link #install} */
    public static guarding_rightbar right() {
        return right;
    }
}
