package ui.guarding_bars;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.VBox;
import ui.design.section_dims.GuardingBars_dim;

/**
 * What the left and right guarding bars share: a fixed-width vertical strip
 * that runs from the quick-access row down to the footer, holds a stack of
 * small tools (none yet), and has a thin mid-grey line on its inner edge --
 * the same grey as the split dividers and the line under the quick-access
 * row.
 *
 * <p>
 * Width and padding come from {@link GuardingBars_dim} and are set here in
 * Java; the stylesheet ({@code themes/guarding_bars/guarding_*.css}) holds
 * only colours, in a light and a dark variant kept on the scene by
 * {@link GuardingBars}.
 * </p>
 */
public abstract class GuardingBar extends VBox {

    /** Every guarding bar. */
    public static final String BAR_CLASS = "guarding-bar";

    /** A tool placed in a bar. */
    public static final String TOOL_CLASS = "guarding-bar-tool";

    /**
     * @param sideClass {@code guarding-left} or {@code guarding-right}, which
     *                  decides the edge the inner line is drawn on
     */
    protected GuardingBar(String sideClass) {
        getStyleClass().addAll(BAR_CLASS, sideClass);
        double w = GuardingBars_dim.WIDTH;
        setMinWidth(w);
        setPrefWidth(w);
        setMaxWidth(w);
        setMaxHeight(Double.MAX_VALUE);
        setAlignment(Pos.TOP_CENTER);
        setSpacing(GuardingBars_dim.TOOL_SPACING);
        setPadding(new Insets(GuardingBars_dim.PAD_V, 0, GuardingBars_dim.PAD_V, 0));
        setFillWidth(false);
    }

    /**
     * Adds a tool (a small icon button) at the bottom of the bar's stack.
     *
     * @param tool the node to add; it gets {@link #TOOL_CLASS}
     */
    public void addTool(Node tool) {
        if (tool == null) {
            return;
        }
        if (!tool.getStyleClass().contains(TOOL_CLASS)) {
            tool.getStyleClass().add(TOOL_CLASS);
        }
        getChildren().add(tool);
    }

    /**
     * @param tool a tool added earlier
     */
    public void removeTool(Node tool) {
        getChildren().remove(tool);
    }
}
