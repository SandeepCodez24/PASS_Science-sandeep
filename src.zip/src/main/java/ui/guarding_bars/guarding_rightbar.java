package ui.guarding_bars;

/**
 * The guarding bar at the far right of the main window, the twin of
 * {@link guarding_leftbar}: same width, same colour, with its inner line on
 * its left edge, facing the Variable Explorer. It gives the window a defined
 * right boundary in every layout.
 *
 * <p>
 * Tools for this bar go in with {@link #addTool}. None are defined yet.
 * </p>
 */
public final class guarding_rightbar extends GuardingBar {

    /** Marks the right bar. */
    public static final String SIDE_CLASS = "guarding-right";

    public guarding_rightbar() {
        super(SIDE_CLASS);
    }
}
