package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The two guarding bars: the vertical strips at the far left and far right of
 * the main window, between the quick-access row and the footer. They frame
 * the panels in every layout and will carry small tool icons later.
 *
 * <pre>
 *   +---+------------------------------------------------------+---+
 *   | L |  File Explorer | editor / Command Window | Variables | R |
 *   +---+------------------------------------------------------+---+
 * </pre>
 *
 * <h3>Width</h3>
 * <p>
 * About 6 mm, as asked. At 96 dpi 6 mm is 22.7 px; {@link #WIDTH} rounds up to
 * a whole 24 px (6.35 mm) so the bar lands on the pixel grid and a 16 px icon
 * sits in it with exactly 4 px either side. Windows display scaling multiplies
 * logical pixels, so the physical width stays about 6 mm at 125 % and 150 %.
 * </p>
 */
public class GuardingBars_dim {

    /** Width of each bar. About 6 mm; see the class notes. */
    public static final double WIDTH = pxi(24);

    /**
     * The darker line along the bar's inner edge (the side facing the
     * panels). Hairline, unscaled. Its colour is in the guarding sheets.
     */
    public static final double INNER_LINE = 1;

    /** Space above the first tool and below the last. */
    public static final double PAD_V = px(6);

    /** Gap between two tools stacked in a bar. */
    public static final double TOOL_SPACING = px(6);

    /** Edge length of a tool button in a bar (for the icons to come). */
    public static final double TOOL_SIZE = pxi(20);

    /** Edge length of the glyph inside a tool button. */
    public static final double TOOL_ICON_SIZE = pxi(16);

    protected GuardingBars_dim() {
    }
}
