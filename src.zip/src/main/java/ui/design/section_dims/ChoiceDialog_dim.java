package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Neural Code Editor choice dialog: a grey title strip, an information
 * mark beside the message, and a row of buttons. Used for "this file is not in
 * the current folder" and for "this file was changed outside the editor".
 *
 * <pre>
 *  +----------------------------------------------------------------+
 *  | Neural Code Editor                                         [x] |  grey strip
 *  +----------------------------------------------------------------+
 *  |  (i)  The file "D:\...\xxx.nc" is not in the current folder.   |
 *  |                                                                |
 *  |       To run this file, change the current folder or ...       |
 *  |       Current folder: D:\...                                   |
 *  +----------------------------------------------------------------+
 *  | [Add Path] [Change folder &]       +---------------------------+|
 *  |            [ Set as Root   ]       | [Change Folder] [Cancel]  ||
 *  +----------------------------------------------------------------+
 * </pre>
 *
 * <p>
 * Colours live in {@code themes/choice_dialog/choice_dialog_light.css} and
 * {@code choice_dialog_dark.css}; everything here reaches the dialog through
 * {@code DesignStylesheet} or the dialog's own layout code.
 * </p>
 */
public class ChoiceDialog_dim {

    // =====================================================================
    // Window
    // =====================================================================

    /** Width of the whole dialog. */
    public static final double WIDTH = pxi(600);

    /** Outline of the window and of the buttons. Hairline, unscaled. */
    public static final double BORDER = 1;

    // =====================================================================
    // Title strip
    // =====================================================================

    /** Height of the grey title strip. */
    public static final double TITLE_HEIGHT = pxi(32);

    /** Leading padding of the title text. */
    public static final double TITLE_PAD_H = px(12);

    /** Square hit area of the close glyph. */
    public static final double CLOSE_SIZE = pxi(24);

    // =====================================================================
    // Body
    // =====================================================================

    /** Body padding, top. */
    public static final double BODY_PAD_TOP = px(18);

    /** Body padding, left and right. */
    public static final double BODY_PAD_H = px(18);

    /** Body padding, bottom. */
    public static final double BODY_PAD_BOTTOM = px(14);

    /** Edge length of the information mark. */
    public static final double ICON_SIZE = pxi(32);

    /** Gap between the mark and the message column. */
    public static final double ICON_GAP = px(14);

    /** Gap between the headline and the paragraph below it. */
    public static final double PARAGRAPH_GAP = px(14);

    /** Gap between the paragraph and the muted detail line. */
    public static final double DETAIL_GAP = px(6);

    // =====================================================================
    // Footer and buttons
    // =====================================================================

    /** Footer padding, top and bottom. */
    public static final double FOOTER_PAD_V = px(12);

    /** Footer padding, left and right. */
    public static final double FOOTER_PAD_H = px(14);

    /** Gap between two buttons. */
    public static final double BUTTON_GAP = px(10);

    /** Height of every button; tall enough for a two-line label. */
    public static final double BUTTON_HEIGHT = pxi(40);

    /** Narrowest a button may be. */
    public static final double BUTTON_MIN_WIDTH = pxi(104);

    /** Padding inside a button, left and right. */
    public static final double BUTTON_PAD_H = px(12);

    /** Corner rounding of the buttons. */
    public static final double BUTTON_RADIUS = px(4);

    /** Outline of the default button, drawn heavier than the others. */
    public static final double DEFAULT_BORDER = 2;

    /** Padding of the light panel behind the right-hand buttons. */
    public static final double PANEL_PAD = px(6);

    /** Corner rounding of that panel. */
    public static final double PANEL_RADIUS = px(4);

    protected ChoiceDialog_dim() {
    }
}
