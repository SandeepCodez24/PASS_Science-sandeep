package ui.design.section_dims;

import static ui.design.UIScale.pxi;

/**
 * Split-pane divider positions, and the divider itself.
 *
 * <p>
 * The positions are fractions between 0 and 1, not lengths, so they are not
 * scaled: scaling a fraction would move the dividers off the panels they
 * belong to. The divider's own size (bottom of this file) is in pixels.
 * </p>
 *
 * <h3>The divider: a 1 px line in a 3 px drag area</h3>
 * <pre>
 *    | side | line | side |      side = DIVIDER_SIDE, line = DIVIDER_LINE
 *    |  bg  | grey |  bg  |      only the middle pixel is painted
 * </pre>
 * <p>
 * MATLAB-style: the panels are separated by a single thin line, but the mouse
 * still has a target wider than one pixel. The side pixels are painted in
 * the split's own background, so they blend into the panels and only the line
 * shows. Colours (line, background) are in {@code light.css} / {@code dark.css};
 * {@code DesignStylesheet} emits the padding and insets from these values.
 * </p>
 *
 * <h3>The 2 : 8 : 2 main split</h3>
 * <p>
 * The window's width is counted as {@link #UNITS_TOTAL} units: the File
 * Explorer gets {@link #UNITS_EXPLORER}, the editor column
 * {@link #UNITS_EDITOR} and the Variable Explorer {@link #UNITS_VARIABLES}.
 * The two divider positions are derived from those units, so changing the
 * ratio means changing the units, nothing else.
 * </p>
 * <p>
 * {@code ui.layout.SplitRatio} holds this ratio while the window settles
 * (first show, maximise, any resize) until the user drags a divider; from
 * then on the user's widths are kept.
 * </p>
 */
public class Split_dim {

    /** The whole width of the main split, in units. */
    public static final double UNITS_TOTAL = 12;

    /** File Explorer share, in units. */
    public static final double UNITS_EXPLORER = 2;

    /** Editor column share, in units. */
    public static final double UNITS_EDITOR = 8;

    /** Variable Explorer share, in units. */
    public static final double UNITS_VARIABLES = 2;

    /** Boundary between the File Explorer and the editor column (2 / 12). */
    public static final double MAIN_LEFT = UNITS_EXPLORER / UNITS_TOTAL;

    /** Boundary between the editor column and the Variable Explorer (10 / 12). */
    public static final double MAIN_RIGHT = (UNITS_EXPLORER + UNITS_EDITOR) / UNITS_TOTAL;

    /** Boundary between the editor tabs and the Command Window below them. */
    public static final double EDITOR_OVER_CONSOLE = 0.75;

    /**
     * @return both main-split divider positions, ready for
     *         {@code SplitPane.setDividerPositions}
     */
    public static double[] mainPositions() {
        return new double[] { MAIN_LEFT, MAIN_RIGHT };
    }

    // =====================================================================
    // The divider
    // =====================================================================

    /** The visible line between two panels. Hairline, unscaled. */
    public static final double DIVIDER_LINE = 1;

    /**
     * The invisible margin either side of the line, part of the drag area.
     * A whole pixel at every scale, so the line never lands between pixels.
     */
    public static final double DIVIDER_SIDE = Math.max(1, pxi(1));

    /** Whole width of a side-by-side divider: the drag area, 3 px at 100%. */
    public static final double DIVIDER_GRAB = DIVIDER_LINE + 2 * DIVIDER_SIDE;

    /**
     * The invisible margin above and below the line of a divider between
     * STACKED panels (tree over Code Bot, editor over Command Window, table
     * over Signal Explorer).
     *
     * <p>
     * Wider than {@link #DIVIDER_SIDE}: a 3 px horizontal divider was too hard
     * to catch, because it sits between two title-strip-height targets the
     * pointer keeps landing on instead. 3 px either side gives a 7 px drag
     * area at 100% while the visible line stays 1 px. Raise it to 4 for a
     * 9 px area if it is still tight.
     * </p>
     */
    public static final double DIVIDER_SIDE_STACKED = Math.max(1, pxi(3));

    /** Whole height of a divider between stacked panels: 7 px at 100%. */
    public static final double DIVIDER_GRAB_STACKED = DIVIDER_LINE + 2 * DIVIDER_SIDE_STACKED;

    protected Split_dim() {
    }
}
