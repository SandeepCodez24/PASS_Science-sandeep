package ui.design.section_dims;

/**
 * Geometry of the Settings &gt; Text Colours window.
 *
 * <pre>
 *  | strip (navy)                                                        |
 *  | Category      Colour  Light sample   Dark sample   B  I  ↺ | Preview |
 *  | Variables     [###]   count = ;      count = ;     [] [] ↺ | light   |
 *  | ...  (one row per TextCategory)                            | dark    |
 *  |                                    Reset  Preview Apply Cancel        |
 *  | footer                                                               |
 * </pre>
 */
public class TextColours_dim {

    // ---- strip and frame ------------------------------------------------
    public static final double TITLE_PAD_V = 9;
    public static final double TITLE_PAD_H = 14;
    public static final double BODY_PADDING = 16;
    public static final double COLUMN_GAP = 22;
    public static final double FOOTER_HEIGHT = 27;
    public static final double FOOTER_PAD_H = 12;

    // ---- the category grid ----------------------------------------------
    public static final double GRID_HGAP = 8;
    public static final double GRID_VGAP = 5;
    public static final double LABEL_WIDTH = 140;
    public static final double SWATCH_WIDTH = 52;
    public static final double ROW_HEIGHT = 24;
    public static final double SAMPLE_WIDTH = 176;
    public static final double SAMPLE_PAD_H = 8;
    public static final double RESET_SIZE = 24;

    // ---- previews ---------------------------------------------------------
    public static final double PREVIEW_WIDTH = 372;
    public static final double PREVIEW_PAD = 10;
    public static final double PREVIEW_GAP = 10;
    public static final double PREVIEW_RADIUS = 4;

    // ---- text -------------------------------------------------------------
    /** Code font size in the samples and previews, px. */
    public static final double CODE_FONT = 13;
    /** Code font family; the platform's monospace stands in if missing. */
    public static final String CODE_FAMILY = "Consolas";

    // ---- buttons ----------------------------------------------------------
    public static final double BUTTON_WIDTH = 92;
    public static final double BUTTON_GAP = 8;

    protected TextColours_dim() {
    }
}
