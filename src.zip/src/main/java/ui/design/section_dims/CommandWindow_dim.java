package ui.design.section_dims;

import static ui.design.UIScale.px;

/**
 * The Command Window: for now, the three-dot options menu on its title strip
 * (New Window / Minimize / Copy / Stop).
 *
 * <pre>
 *   Command Window                                   [:]
 *                                       +---------------------+
 *                                       | New Window          |
 *                                       | Minimize            |
 *                                       |---------------------|
 *                                       | Copy                |
 *                                       | Stop                |
 *                                       +---------------------+
 * </pre>
 *
 * <h3>Width</h3>
 * <p>
 * The menu used to size itself to its longest entry at the inherited
 * {@code BASE} font with Modena's default insets. It is now
 * {@link #OPTIONS_MENU_WIDTH_SCALE} times that width -- 30% longer than it
 * was -- while its text drops to the breadcrumb bar's size
 * ({@code Typography.Role.BREADCRUMB_SEGMENT}). The baseline is measured from
 * the entry labels at run time, so adding an entry keeps the ratio.
 * </p>
 *
 * <p>
 * Only the Command Window's menu uses these values. The File Explorer and
 * Variable Explorer menus built by {@code PanelTitleBar} keep their defaults.
 * </p>
 *
 * <p>
 * The console's own right-click menu still keeps its numbers in
 * {@code ConsoleController}; they can move here later.
 * </p>
 */
public class CommandWindow_dim {

    // =====================================================================
    // Three-dot options menu
    // =====================================================================

    /** Width of the menu relative to its old natural width. A ratio, unscaled. */
    public static final double OPTIONS_MENU_WIDTH_SCALE = 1.30;

    /**
     * Modena's {@code .context-menu} padding, in em of the old font. Part of
     * the baseline only; the menu's real padding is not changed.
     */
    public static final double OPTIONS_MENU_BASE_PAD_EM = 0.333333;

    /**
     * Modena's horizontal {@code .menu-item} padding, in em of the old font.
     * Part of the baseline only.
     */
    public static final double OPTIONS_MENU_BASE_ITEM_PAD_H_EM = 0.41777;

    /** Outline of the menu frame. Hairline, unscaled. */
    public static final double OPTIONS_MENU_BORDER = 1;

    /** Lower bound on the menu width, so a very short label set still reads as a menu. */
    public static final double OPTIONS_MENU_MIN_WIDTH = px(120);

    protected CommandWindow_dim() {
    }
}
