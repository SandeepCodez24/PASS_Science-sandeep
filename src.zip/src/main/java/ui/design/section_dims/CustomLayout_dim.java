package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Custom layout: its in-window sizes (the minimised editor, the Signal
 * Explorer under the Variable Explorer) and the geometry of the Custom
 * Layout window and its colour dialog.
 *
 * <p>
 * Colours are not here. The factory colours of the six panels live in
 * {@code ui.layout.custom.CustomLayoutConfig}, because they are the starting
 * values of a user setting rather than theme rules.
 * </p>
 */
public class CustomLayout_dim {

    // =====================================================================
    // In the main window
    // =====================================================================

    /** Signal Explorer's share of the Variable Explorer column's height. A ratio. */
    public static final double SIGNAL_SHARE = 0.20;

    /** Variable table's share of that column: the divider position. A ratio. */
    public static final double TABLE_SHARE = 1.0 - SIGNAL_SHARE;

    /** The variable table never shrinks below this while expanded. */
    public static final double TABLE_MIN_HEIGHT = px(60);

    /**
     * Height of the variable table while minimised: its column-header row
     * stays visible, the rows do not.
     */
    public static final double TABLE_MINIMIZED_HEIGHT = pxi(28);

    /**
     * Height of the editor while minimised: its tab strip stays visible, the
     * code does not.
     */
    public static final double EDITOR_MINIMIZED_HEIGHT = pxi(30);

    // =====================================================================
    // Custom Layout window
    // =====================================================================

    /** Padding of the title strip, vertical / horizontal. */
    public static final double TITLE_PAD_V = px(9);
    public static final double TITLE_PAD_H = px(14);

    /** Padding around the window body. */
    public static final double BODY_PADDING = px(18);

    /** Gap between the panel grid and the right-hand column. */
    public static final double COLUMN_GAP = px(36);

    /** Gaps inside the panel grid. */
    public static final double GRID_HGAP = px(10);
    public static final double GRID_VGAP = px(6);

    /** One Light / Dark colour box in the grid. */
    public static final double SWATCH_WIDTH = px(72);
    public static final double SWATCH_HEIGHT = px(28);

    /** The Base Color box. */
    public static final double BASE_SWATCH_WIDTH = px(64);

    /** Width of the label boxes on the right (Base Color, Default Theme). */
    public static final double RIGHT_LABEL_WIDTH = px(120);

    /** Gap between rows of the right-hand column. */
    public static final double RIGHT_ROW_GAP = px(18);

    /** The four buttons at the bottom right. */
    public static final double BUTTON_WIDTH = px(96);
    public static final double BUTTON_GAP = px(8);

    /** Grey footer strip. */
    public static final double FOOTER_HEIGHT = px(27);

    // =====================================================================
    // Colour dialog
    // =====================================================================

    /** Initial size of the colour dialog. */
    public static final double DIALOG_WIDTH = px(380);
    public static final double DIALOG_HEIGHT = px(440);

    /** Height of the scrolling palette + tabs area. */
    public static final double DIALOG_SCROLL_HEIGHT = px(230);

    /** One palette swatch, and the gap between swatches. */
    public static final double PALETTE_SWATCH = px(20);
    public static final double PALETTE_GAP = px(8);
    public static final double PALETTE_WRAP = px(280);

    /** The Current / New preview boxes. */
    public static final double PREVIEW_WIDTH = px(68);
    public static final double PREVIEW_HEIGHT = px(34);
    public static final double PREVIEW_RADIUS = px(10);

    /** Slider rows in the HSB / RGB tabs. */
    public static final double CHANNEL_LABEL_WIDTH = px(70);
    public static final double CHANNEL_SLIDER_WIDTH = px(130);
    public static final double CHANNEL_FIELD_WIDTH = px(46);
    public static final double CHANNEL_UNIT_WIDTH = px(28);

    /** Hex field in the Web tab. */
    public static final double HEX_FIELD_WIDTH = px(104);

    protected CustomLayout_dim() {
    }
}
