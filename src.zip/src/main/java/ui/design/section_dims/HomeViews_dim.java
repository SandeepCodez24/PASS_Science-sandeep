package ui.design.section_dims;

import static ui.design.UIScale.px;
import static ui.design.UIScale.pxi;

/**
 * The Home band's Views compartment: Full Screen and Search Code as two
 * toggle rows, with a third row kept free for later. A row shows its rounded
 * outline only on hover; "on" is a small green dot at its right end.
 *
 * <pre>
 *  +------------------------+
 *  | [ic] Full Screen     o |   row 1  -- toggle (o = on)
 *  | [ic] Search Code       |   row 2  -- toggle
 *  |                        |   row 3  -- reserved, empty
 *  +------------------------+
 *           Views
 * </pre>
 *
 * <p>
 * The three rows and their two gaps fill exactly the item row every other
 * compartment uses ({@link ToolBand_dim#ITEM_HEIGHT}), so the caption stays
 * level with its neighbours. Colours are not here: they live in
 * {@code themes/ribbon/views_light.css} and {@code views_dark.css}.
 * </p>
 */
public class HomeViews_dim {

    /** Rows the compartment is divided into, the empty one included. */
    public static final int ROWS = 3;

    /** Rows occupied by a toggle today. The rest stay empty. */
    public static final int USED_ROWS = 2;

    /** Gap between neighbouring rows. */
    public static final double ROW_SPACING = px(2);

    /**
     * Height of one row. Derived: three rows and two gaps are exactly one item
     * row high.
     */
    public static final double ROW_HEIGHT =
            Math.floor((ToolBand_dim.ITEM_HEIGHT - (ROWS - 1) * ROW_SPACING) / ROWS);

    /** Padding of the whole stack, leading and trailing. */
    public static final double STACK_PAD_H = px(2);

    /** Icon inside a row. The row is about 23 px tall, so 18 leaves room. */
    public static final double ICON_SIZE = pxi(18);

    /** Gap between the icon and the label. */
    public static final double GRAPHIC_GAP = px(6);

    /** Padding inside a row, leading and trailing. */
    public static final double PAD_H = px(6);

    /** Padding inside a row, top and bottom. */
    public static final double PAD_V = px(0);

    /** Corner rounding of a row. */
    public static final double RADIUS = px(3);

    /** Outline of a row. A hairline, so not scaled. */
    public static final double BORDER = 1;

    /** Diameter of the green "on" dot at the right end of a row. */
    public static final double DOT_SIZE = px(6);

    /** Minimum gap between the end of the label and the dot. */
    public static final double DOT_GAP = px(6);

    /** Gap between the dot and the row's right edge. Matches {@link #PAD_H}. */
    public static final double DOT_INSET_RIGHT = PAD_H;

    /**
     * Extra width reserved beyond the widest label a row can show. A guard
     * against fractional measurement; a label a fraction too narrow would be
     * cut to "...". Unscaled.
     */
    public static final double WIDTH_SLACK = 2;

    protected HomeViews_dim() {
    }
}
