package ui.design;

import java.net.URL;
import java.util.List;

import javafx.application.Platform;
import javafx.collections.ListChangeListener;
import javafx.scene.Scene;

/**
 * A light / dark pair of colour stylesheets that keeps itself attached to a
 * scene and in step with the active theme.
 *
 * <p>
 * The same mechanism {@link RibbonTheme} uses for the ribbon sheets, made
 * reusable: no caller has to tell it which theme is active and
 * {@code ThemeManager} does not need to know the pair exists. It watches the
 * scene's stylesheet list; whenever the base {@code dark.css} is in it, the
 * dark sheet is attached and the light one removed, and the other way round.
 * The base theme is matched on its exact file name, so {@code editor_dark.css},
 * {@code fold_dark.css} and {@code ribbon_dark.css} are never mistaken for it.
 * </p>
 *
 * <h3>Order</h3>
 * <p>
 * The sheet is placed after the base theme and then left alone. It carries
 * colours only, so it never competes with {@link DesignStylesheet} for the
 * last slot; that is what keeps the listeners from fighting.
 * </p>
 *
 * <p>
 * Used by the Home band's Views compartment
 * ({@code themes/ribbon/views_light.css}, {@code views_dark.css}).
 * </p>
 */
public final class ThemedSheetPair {

    private static final String LIGHT_BASE = "light.css";
    private static final String DARK_BASE = "dark.css";

    /** Scene property key, so one pair is never installed twice on a scene. */
    private final String installedKey;

    private final String lightUri;
    private final String darkUri;
    private boolean syncing;

    /**
     * @param lightResource classpath location of the light sheet
     * @param darkResource  classpath location of the dark sheet
     */
    public ThemedSheetPair(String lightResource, String darkResource) {
        this.lightUri = toUri(lightResource);
        this.darkUri = toUri(darkResource);
        this.installedKey = ThemedSheetPair.class.getName() + ":" + lightResource;
    }

    /**
     * Attaches the matching sheet and keeps it right for the life of the
     * scene. Safe to call more than once.
     *
     * @param scene the application scene
     */
    public void install(Scene scene) {
        if (scene == null || (lightUri == null && darkUri == null)) {
            return;
        }
        if (scene.getProperties().containsKey(installedKey)) {
            return;
        }
        scene.getProperties().put(installedKey, Boolean.TRUE);

        sync(scene);
        scene.getStylesheets().addListener((ListChangeListener<String>) change -> {
            if (syncing) {
                return;
            }
            Platform.runLater(() -> sync(scene));
        });
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static String toUri(String resource) {
        URL url = ThemedSheetPair.class.getResource(resource);
        if (url == null) {
            System.err.println("Stylesheet not on the classpath: " + resource
                    + " -- expected at src/main/resources" + resource);
            return null;
        }
        return url.toExternalForm();
    }

    /**
     * Ensures exactly one sheet of the pair is present and that it sits after
     * the base theme. Does nothing when that already holds, so it settles
     * after one round.
     */
    private void sync(Scene scene) {
        List<String> sheets = scene.getStylesheets();

        boolean dark = isDark(sheets);
        String wanted = dark ? darkUri : lightUri;
        String unwanted = dark ? lightUri : darkUri;
        if (wanted == null) {
            return;
        }

        int baseAt = baseIndex(sheets);
        int wantedAt = sheets.indexOf(wanted);
        boolean unwantedPresent = unwanted != null && sheets.contains(unwanted);
        boolean ordered = wantedAt >= 0 && (baseAt < 0 || wantedAt > baseAt);
        if (ordered && !unwantedPresent) {
            return;
        }

        syncing = true;
        try {
            if (unwantedPresent) {
                sheets.remove(unwanted);
            }
            if (wantedAt >= 0) {
                sheets.remove(wanted);
            }
            sheets.add(wanted);
        } finally {
            syncing = false;
        }
    }

    private static boolean isDark(List<String> sheets) {
        for (String sheet : sheets) {
            if (DARK_BASE.equalsIgnoreCase(fileName(sheet))) {
                return true;
            }
        }
        return false;
    }

    private static int baseIndex(List<String> sheets) {
        for (int i = 0; i < sheets.size(); i++) {
            String name = fileName(sheets.get(i));
            if (LIGHT_BASE.equalsIgnoreCase(name) || DARK_BASE.equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    private static String fileName(String uri) {
        if (uri == null) {
            return "";
        }
        int slash = uri.lastIndexOf('/');
        return (slash >= 0) ? uri.substring(slash + 1) : uri;
    }
}
