package ui.design;

import java.net.URL;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Scene;
import ui.managers.ThemeManager;

/**
 * Keeps one light / dark stylesheet pair on the scene of a node, in the
 * variant that matches the theme.
 *
 * <p>
 * For small feature sheets that hold colours only (the breadcrumb's history
 * zone, the guarding bars), so they do not have to be added to
 * {@code light.css} / {@code dark.css}, which are already very long.
 * </p>
 *
 * <ul>
 * <li>Attaches as soon as the node is in a scene, and again a pulse later,
 * after {@code ThemeManager.applySavedTheme} has put the theme sheet on.</li>
 * <li>On every theme switch ({@link ThemeManager#themeProperty()}) both
 * variants are removed and the matching one is added at the end of the list,
 * so it follows the theme sheet. {@link DesignStylesheet} then moves itself
 * back to the very end, as it always does.</li>
 * <li>A missing file is reported once on {@code System.err} and otherwise
 * ignored.</li>
 * </ul>
 */
public final class ThemeSheetSync {

    private final Node anchor;
    private final String light;
    private final String dark;
    private boolean warned;

    private ThemeSheetSync(Node anchor, String lightPath, String darkPath) {
        this.anchor = anchor;
        this.light = external(lightPath);
        this.dark = external(darkPath);
        if (light == null || dark == null) {
            System.err.println("Feature stylesheet missing: "
                    + (light == null ? lightPath : darkPath));
            warned = true;
        }
    }

    /**
     * Starts keeping a pair on the anchor's scene.
     *
     * @param anchor    any node that will live in the main scene
     * @param lightPath classpath resource of the light variant
     * @param darkPath  classpath resource of the dark variant
     */
    public static void attach(Node anchor, String lightPath, String darkPath) {
        if (anchor == null) {
            return;
        }
        ThemeSheetSync sync = new ThemeSheetSync(anchor, lightPath, darkPath);
        anchor.sceneProperty().addListener((obs, was, now) -> {
            if (now != null) {
                sync.apply();
                Platform.runLater(sync::apply);
            }
        });
        ThemeManager.themeProperty().addListener((obs, was, now) -> sync.apply());
        if (anchor.getScene() != null) {
            sync.apply();
        }
    }

    private void apply() {
        Scene scene = anchor.getScene();
        if (scene == null) {
            return;
        }
        boolean useDark = "dark".equals(ThemeManager.getActiveTheme());
        String wanted = useDark ? dark : light;
        if (light != null) {
            scene.getStylesheets().remove(light);
        }
        if (dark != null) {
            scene.getStylesheets().remove(dark);
        }
        if (wanted != null) {
            scene.getStylesheets().add(wanted);
        } else if (!warned) {
            warned = true;
            System.err.println("Feature stylesheet missing for theme " + ThemeManager.getActiveTheme());
        }
    }

    private static String external(String path) {
        URL url = ThemeSheetSync.class.getResource(path);
        return url == null ? null : url.toExternalForm();
    }
}
