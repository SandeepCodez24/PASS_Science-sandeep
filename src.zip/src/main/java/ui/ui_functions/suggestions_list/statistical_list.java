package ui.ui_functions.suggestions_list;

import ui.ui_functions.FunctionProvider;

/**
 * statistical_list - Registers all STATISTICAL functions
 * into the FunctionProvider suggestion system.
 */
public class statistical_list {

    // ========== STATISTICAL FUNCTIONS ==========
    public static void register() {
        FunctionProvider.addFunction("mean(A)", "Mean/Average");
        FunctionProvider.addFunction("median(A)", "Median");
        FunctionProvider.addFunction("mode(A)", "Mode");
        FunctionProvider.addFunction("geo_mean(A)", "Geometric mean");
        FunctionProvider.addFunction("harmo_mean(A)", "Harmonic mean");
        FunctionProvider.addFunction("trim_mean(A)", "Trimmed mean");
        FunctionProvider.addFunction("VAR(A)", "Variance");
        FunctionProvider.addFunction("SD(A)", "Standard deviation");
        FunctionProvider.addFunction("coeff_var(A)", "Coefficient of variation");
        FunctionProvider.addFunction("skew(A)", "Skewness");
        FunctionProvider.addFunction("corr_coeff(A)", "Correlation coefficient");
        FunctionProvider.addFunction("co_var(A)", "Covariance");
        FunctionProvider.addFunction("LSM(A)", "Least squares method");
        FunctionProvider.addFunction("null_hypo(A)", "Null hypothesis test");
        FunctionProvider.addFunction("p_val_cal(A)", "P-value");
        FunctionProvider.addFunction("chi_square_test(A)", "Chi-square test");
        FunctionProvider.addFunction("norm(A)", "Normalize data");
    }
}
