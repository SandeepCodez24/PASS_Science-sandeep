package ui.ui_functions.tools.print;

import java.awt.Color;
import java.util.Collection;

import language.syntax.textcolours.TextCategory;
import ui.managers.TextColourManager;

/**
 * The span to ink table for printing and PDF export.
 *
 * <h3>Text colours come from the text stylesheets</h3>
 * <p>
 * Token colours are no longer restated here. A span carries a {@code tc-*}
 * class ({@link TextCategory}), and its ink, weight and style are read from
 * {@link TextColourManager#effective()}: the standard colours in
 * {@code themes/texts/text_light.css} / {@code text_dark.css}, plus anything
 * the user chose in Settings &gt; Text Colours. So a printout always matches
 * the screen, and there is nothing in this file to keep in step when a text
 * colour changes. The light print theme uses the light-editor colours, the
 * dark print theme the dark-editor ones.
 * </p>
 * <p>
 * The page, gutter, line-number, header and rule colours below are the
 * printout's own and are still set here.
 * </p>
 *
 * <h3>Departures from the screen</h3>
 * <ul>
 * <li><b>Sub- and superscript runs keep the full character cell.</b> They are
 * drawn smaller and shifted off the baseline, but the layout still advances a
 * whole cell, so the monospace grid -- and therefore the wrap column and every
 * page boundary -- stays exact. See {@code PrintPaginator}.</li>
 * </ul>
 */
public final class PrintPalette {

    /* ---- page furniture, light print theme ---- */
    private static final Color L_PAGE = new Color(0xFF, 0xFF, 0xFF);
    private static final Color L_GUTTER = new Color(0xE8, 0xE8, 0xE8);
    private static final Color L_LINENO = new Color(0x85, 0x85, 0x85);
    private static final Color L_FURNITURE = new Color(0x60, 0x60, 0x60);
    private static final Color L_RULE = new Color(0xC0, 0xC0, 0xC0);

    /* ---- page furniture, dark print theme ---- */
    private static final Color D_PAGE = new Color(0x1E, 0x1E, 0x1E);
    private static final Color D_GUTTER = new Color(0x51, 0x58, 0x61);
    private static final Color D_LINENO = new Color(0x85, 0x85, 0x85);
    private static final Color D_FURNITURE = new Color(0xA9, 0xB4, 0xBF);
    private static final Color D_RULE = new Color(0x4D, 0x54, 0x5B);

    private PrintPalette() {
    }

    /**
     * Ink for a run.
     *
     * @param styleClasses the classes RichTextFX carries on the span; may be
     *                     empty, in which case the variable colour is used
     * @param theme        the palette
     * @return the colour to draw the run in
     */
    public static Color ink(Collection<String> styleClasses, PrintSettings.Theme theme) {
        boolean dark = theme == PrintSettings.Theme.DARK;
        return Color.decode(TextColourManager.effective().hex(category(styleClasses), dark));
    }

    /**
     * @param styleClasses the classes on the span
     * @return true if this token is drawn bold
     */
    public static boolean bold(Collection<String> styleClasses) {
        return TextColourManager.effective().bold(category(styleClasses));
    }

    /**
     * @param styleClasses the classes on the span
     * @return true if this token is drawn italic
     */
    public static boolean italic(Collection<String> styleClasses) {
        return TextColourManager.effective().italic(category(styleClasses));
    }

    /**
     * The span's category. Sub/superscript classes carry no colour of their
     * own; they ride on the {@code tc-*} class beside them.
     */
    private static TextCategory category(Collection<String> styleClasses) {
        if (styleClasses != null) {
            for (String c : styleClasses) {
                TextCategory category = TextCategory.fromStyleClass(c);
                if (category != null) {
                    return category;
                }
            }
        }
        return TextCategory.VARIABLE;
    }

    /**
     * @param styleClasses the classes on the span
     * @return the vertical shift as a fraction of the font size -- negative
     *         raises (superscript), positive lowers (subscript), zero for
     *         ordinary text
     */
    public static double baselineShift(Collection<String> styleClasses) {
        if (styleClasses == null) {
            return 0;
        }
        for (String c : styleClasses) {
            if (c.startsWith("superscript")) {
                return -0.33;
            }
            if (c.startsWith("subscript")) {
                return 0.20;
            }
        }
        return 0;
    }

    /**
     * @param styleClasses the classes on the span
     * @return the size multiplier for the run, matching the editor's 55% and
     *         65%
     */
    public static double sizeScale(Collection<String> styleClasses) {
        if (styleClasses == null) {
            return 1.0;
        }
        for (String c : styleClasses) {
            if (c.startsWith("superscript")) {
                return 0.55;
            }
            if (c.startsWith("subscript")) {
                return 0.65;
            }
        }
        return 1.0;
    }

    /** @param theme the palette @return the page background */
    public static Color page(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_PAGE : L_PAGE;
    }

    /** @param theme the palette @return the line-number gutter band */
    public static Color gutter(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_GUTTER : L_GUTTER;
    }

    /** @param theme the palette @return the line-number ink */
    public static Color lineNumber(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_LINENO : L_LINENO;
    }

    /** @param theme the palette @return the header and footer ink */
    public static Color furniture(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_FURNITURE : L_FURNITURE;
    }

    /** @param theme the palette @return the hairline under the header */
    public static Color rule(PrintSettings.Theme theme) {
        return theme == PrintSettings.Theme.DARK ? D_RULE : L_RULE;
    }

}
