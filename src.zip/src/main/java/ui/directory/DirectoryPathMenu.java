package ui.directory;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.image.ImageView;
import ui.UI_Main;
import ui.design.Dim;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.NavigationActions;
import ui.editor.navigation.SearchPath;
import ui.explorer.navigation.PathIcons;

/**
 * The path entries of the File Explorer's right-click menu, MATLAB-style:
 *
 * <pre>
 *  Add to Path            &gt;  Selected Folder
 *                             Selected Folder and Subfolders
 *  Remove from Path       &gt;  Selected Folder
 *                             Selected Folder and Subfolders
 *  [x] Indicate Files Not on Path
 * </pre>
 *
 * <ul>
 * <li>The two submenus appear on folders only. On the current folder (the
 * tree's root row, or empty space) "Selected Folder" is greyed out -- it is
 * always on the path -- and "and Subfolders" adds the folders below it.</li>
 * <li>"Remove from Path" appears only when the folder, or something below it,
 * is on the path.</li>
 * <li>"and Subfolders" skips hidden folders (a name starting with {@code .},
 * or the hidden attribute) and everything under them, follows no shortcuts or
 * links, and stops at {@link #MAX_FOLDERS}. The folders are listed on a
 * background thread, so a large tree does not freeze the window.</li>
 * <li>Every change goes through {@link SearchPath}, so the backend, the
 * editor's checker, the Root menu, the run rule and the dimming all follow
 * together; a multi-folder change is applied in one step (one backend
 * restart on removal, one repaint).</li>
 * </ul>
 */
public final class DirectoryPathMenu {

    /** Most folders "and Subfolders" will add in one go. */
    public static final int MAX_FOLDERS = 2000;

    private DirectoryPathMenu() {
    }

    /**
     * Appends the path entries to a File Explorer menu.
     *
     * @param menu   the menu built for a row or for empty space; ignored if null
     * @param target the row's path, or the folder empty space acts on
     * @param ide    the IDE controller
     */
    public static void extend(ContextMenu menu, Path target, UI_Main ide) {
        if (menu == null) {
            return;
        }
        List<MenuItem> extra = new ArrayList<>();

        if (target != null && FolderPaths.isFolder(target)) {
            Path folder = FolderPaths.canonical(target);
            Path current = NavigationActions.projectFolder(ide);
            boolean isCurrent = FolderPaths.sameCanonical(folder, current);
            boolean added = SearchPath.contains(folder);

            // ---- Add to Path -------------------------------------------------
            Menu add = new Menu("Add to Path", icon(PathIcons.PATH_ADD, ide));
            add.setMnemonicParsing(false);

            MenuItem addOne = entry("Selected Folder");
            addOne.setDisable(isCurrent || added);
            addOne.setOnAction(e -> NavigationActions.addToPath(ide, folder));

            MenuItem addTree = entry("Selected Folder and Subfolders");
            addTree.setOnAction(e -> addWithSubfolders(ide, folder, isCurrent));

            add.getItems().addAll(addOne, addTree);
            extra.add(add);

            // ---- Remove from Path (only when there is something to remove) ---
            List<Path> addedBelow = addedAtOrBelow(folder);
            if (!addedBelow.isEmpty()) {
                Menu remove = new Menu("Remove from Path", icon(PathIcons.PATH_REMOVE, ide));
                remove.setMnemonicParsing(false);

                MenuItem removeOne = entry("Selected Folder");
                removeOne.setDisable(!added);
                removeOne.setOnAction(e -> NavigationActions.removeFromPath(ide, folder));

                MenuItem removeTree = entry("Selected Folder and Subfolders");
                removeTree.setOnAction(e -> removeWithSubfolders(folder));

                remove.getItems().addAll(removeOne, removeTree);
                extra.add(remove);
            }
        }

        // ---- the dimming switch ----------------------------------------------
        CheckMenuItem indicate = new CheckMenuItem("Indicate Files Not on Path");
        indicate.setMnemonicParsing(false);
        indicate.setSelected(DirectoryPathShading.isEnabled());
        indicate.setOnAction(e -> DirectoryPathShading.setEnabled(indicate.isSelected()));
        extra.add(indicate);

        if (!menu.getItems().isEmpty()) {
            menu.getItems().add(new SeparatorMenuItem());
        }
        menu.getItems().addAll(extra);
    }

    // =====================================================================
    // Actions
    // =====================================================================

    /**
     * Adds a folder and every visible folder below it. The listing runs on a
     * background thread; the path is changed back on the FX thread, in one
     * step.
     */
    private static void addWithSubfolders(UI_Main ide, Path folder, boolean isCurrent) {
        Thread worker = new Thread(() -> {
            List<Path> found = new ArrayList<>();
            boolean[] truncated = {false};
            try {
                Files.walkFileTree(folder, new SimpleFileVisitor<>() {
                    @Override
                    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                        if (!dir.equals(folder) && isHidden(dir)) {
                            return FileVisitResult.SKIP_SUBTREE;
                        }
                        if (found.size() >= MAX_FOLDERS) {
                            truncated[0] = true;
                            return FileVisitResult.TERMINATE;
                        }
                        found.add(dir);
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult visitFileFailed(Path file, IOException exc) {
                        return FileVisitResult.CONTINUE; // no access: leave it out
                    }
                });
            } catch (IOException | RuntimeException e) {
                // Whatever was listed before the failure is still added.
            }
            List<Path> canonical = new ArrayList<>(found.size());
            for (Path dir : found) {
                Path c = FolderPaths.canonical(dir);
                if (c != null) {
                    canonical.add(c);
                }
            }
            Platform.runLater(() -> {
                int count = SearchPath.addAll(canonical);
                String where = FolderPaths.label(folder);
                String what = isCurrent ? "the subfolders of " + where : where + " and its subfolders";
                if (count == 0) {
                    NavigationActions.say("Nothing new to add: " + what + " already on the path.");
                } else {
                    NavigationActions.say("Added " + count + (count == 1 ? " folder" : " folders")
                            + " to the path for this session (" + what + ")."
                            + (truncated[0] ? " Stopped at " + MAX_FOLDERS + " folders." : ""));
                }
            });
        }, "add-path-subfolders");
        worker.setDaemon(true);
        worker.start();
    }

    /** Removes a folder and every added folder below it, in one step. */
    private static void removeWithSubfolders(Path folder) {
        List<Path> targets = addedAtOrBelow(folder);
        int count = SearchPath.removeAll(targets);
        NavigationActions.say(count == 0
                ? "Nothing to remove: no folder at or below " + FolderPaths.label(folder) + " is on the path."
                : "Removed " + count + (count == 1 ? " folder" : " folders") + " from the path ("
                        + FolderPaths.label(folder) + " and its subfolders).");
    }

    // =====================================================================
    // Internals
    // =====================================================================

    /** The added folders that are this folder or inside it. */
    private static List<Path> addedAtOrBelow(Path folder) {
        List<Path> result = new ArrayList<>();
        if (folder == null) {
            return result;
        }
        for (Path added : SearchPath.folders()) {
            if (added.startsWith(folder)) {
                result.add(added);
            }
        }
        return result;
    }

    private static boolean isHidden(Path dir) {
        Path name = dir.getFileName();
        if (name != null && name.toString().startsWith(".")) {
            return true;
        }
        try {
            return Files.isHidden(dir);
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }

    private static MenuItem entry(String text) {
        MenuItem item = new MenuItem(text);
        item.setMnemonicParsing(false);
        return item;
    }

    private static ImageView icon(String name, UI_Main ide) {
        return PathIcons.icon(name, Dim.BreadcrumbBar.MENU_ICON_SIZE, ide == null ? null : ide.stage);
    }
}
