package ui.directory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.prefs.Preferences;

import javafx.css.PseudoClass;
import javafx.scene.control.TreeItem;
import ui.editor.navigation.FolderPaths;
import ui.editor.navigation.SearchPath;

/**
 * Decides which File Explorer rows are drawn dimmed because they are not on
 * the path, MATLAB's "Indicate Files Not on Path".
 *
 * <h3>The rule</h3>
 * <p>
 * The path is the current folder (the tree's root) plus every folder added
 * this session ({@link SearchPath}). Then, row by row:
 * </p>
 * <ul>
 * <li>a <b>folder</b> is bright if it is itself on the path, and dim
 * otherwise;</li>
 * <li>a <b>file</b> is bright if the folder it sits in is on the path, and dim
 * otherwise.</li>
 * </ul>
 * <p>
 * So a subfolder of the current folder is dim until it is added, and so is
 * everything in it; inside an added folder the files are bright but its own
 * subfolders stay dim unless they were added too ("Selected Folder and
 * Subfolders" adds them all). The root row, the current folder, is always
 * bright. Group titles (Group by) are never dimmed. This is exactly the set of
 * files Run, Step and the Command Window accept ({@code RunScope}), so what
 * looks runnable is runnable.
 * </p>
 *
 * <h3>How a row is dimmed</h3>
 * <p>
 * The row gets the {@code :off-path} pseudo-class ({@link #OFF_PATH}); the
 * theme files grey its text and fade its icon. Only the icon gets opacity: an
 * opacity below 1 on the row or the cell would turn off LCD text smoothing
 * and blur the names.
 * </p>
 *
 * <h3>The switch</h3>
 * <p>
 * "Indicate Files Not on Path" in the File Explorer's right-click menu turns
 * the dimming on and off. On by default; remembered across restarts.
 * </p>
 *
 * <h3>Cost</h3>
 * <p>
 * Rows are redrawn often (scrolling, selection), so the answers that touch the
 * disk -- is this a folder, what is its canonical form -- are cached and
 * dropped by {@link #invalidate()} whenever the tree is re-read or the path
 * changes. FX thread only.
 * </p>
 */
public final class DirectoryPathShading {

    /** Carried by a row that is not on the path while dimming is on. */
    public static final PseudoClass OFF_PATH = PseudoClass.getPseudoClass("off-path");

    private static final String PREF_KEY = "indicateFilesNotOnPath";
    private static final Preferences PREFS = Preferences.userNodeForPackage(DirectoryPathShading.class);

    private static boolean enabled = PREFS.getBoolean(PREF_KEY, true);

    private static final List<Runnable> LISTENERS = new CopyOnWriteArrayList<>();

    /** Tree path to its canonical form. */
    private static final Map<Path, Path> CANONICAL = new HashMap<>();

    /** Tree path to "is a folder". */
    private static final Map<Path, Boolean> IS_FOLDER = new HashMap<>();

    /** Canonical folders on the path: the current folder plus the added ones. */
    private static Set<Path> onPath;

    /** The tree root {@link #onPath} was built for. */
    private static Path builtForRoot;

    private DirectoryPathShading() {
    }

    // =====================================================================
    // The switch
    // =====================================================================

    /** @return true if rows not on the path are drawn dimmed */
    public static boolean isEnabled() {
        return enabled;
    }

    /**
     * Turns the dimming on or off and remembers the choice.
     *
     * @param on true to dim rows not on the path
     */
    public static void setEnabled(boolean on) {
        if (enabled == on) {
            return;
        }
        enabled = on;
        try {
            PREFS.putBoolean(PREF_KEY, on);
        } catch (RuntimeException ignored) {
            // A read-only preference store only loses the memory of the choice.
        }
        fire();
    }

    /**
     * @param listener run when the switch changes
     */
    public static void addListener(Runnable listener) {
        if (listener != null) {
            LISTENERS.add(listener);
        }
    }

    // =====================================================================
    // The rule
    // =====================================================================

    /**
     * @param item a row's tree item
     * @param root the tree's root item
     * @return true if the row should be drawn dimmed
     */
    public static boolean isOffPath(TreeItem<Path> item, TreeItem<Path> root) {
        if (!enabled || item == null || item == root || item.getValue() == null
                || DirectoryGroupItem.isGroup(item) || root == null || root.getValue() == null) {
            return false;
        }
        Path value = item.getValue();
        Path folder = isFolder(value) ? value : value.getParent();
        if (folder == null) {
            return false;
        }
        Path canonical = canonical(folder);
        return canonical != null && !onPath(root.getValue()).contains(canonical);
    }

    /** Drops every cached answer; the next redraw asks again. */
    public static void invalidate() {
        CANONICAL.clear();
        IS_FOLDER.clear();
        onPath = null;
        builtForRoot = null;
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static Set<Path> onPath(Path root) {
        if (onPath == null || builtForRoot == null || !builtForRoot.equals(root)) {
            Set<Path> set = new HashSet<>(SearchPath.folders());
            Path current = canonical(root);
            if (current != null) {
                set.add(current);
            }
            onPath = set;
            builtForRoot = root;
        }
        return onPath;
    }

    private static boolean isFolder(Path path) {
        Boolean known = IS_FOLDER.get(path);
        if (known == null) {
            boolean folder;
            try {
                folder = Files.isDirectory(path);
            } catch (RuntimeException e) {
                folder = false;
            }
            IS_FOLDER.put(path, folder);
            return folder;
        }
        return known;
    }

    private static Path canonical(Path path) {
        if (path == null) {
            return null;
        }
        Path known = CANONICAL.get(path);
        if (known == null) {
            known = FolderPaths.canonical(path);
            if (known == null) {
                known = path.toAbsolutePath().normalize();
            }
            CANONICAL.put(path, known);
        }
        return known;
    }

    private static void fire() {
        for (Runnable listener : LISTENERS) {
            try {
                listener.run();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
    }
}
