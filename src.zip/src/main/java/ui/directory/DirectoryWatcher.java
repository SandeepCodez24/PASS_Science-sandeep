package ui.directory;

import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_DELETE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;
import static java.nio.file.StandardWatchEventKinds.OVERFLOW;

import java.io.IOException;
import java.nio.file.ClosedWatchServiceException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.scene.control.TreeItem;
import javafx.util.Duration;
import ui.UI_Main;
import ui.editor.EditorFileStatus;
import ui.editor.navigation.NavigationActions;

/**
 * Keeps the File Explorer and the editor tabs in step with the disk, so a file
 * created, renamed, deleted or edited in Windows Explorer (or any other
 * program) shows up without pressing Refresh.
 *
 * <h3>What is watched</h3>
 * <ul>
 * <li><b>On Windows</b>, the current folder is watched once, recursively (the
 * JDK's {@code FILE_TREE} modifier). One handle covers every subfolder, and
 * renaming a subfolder in Explorer is not blocked by the watch.</li>
 * <li><b>Elsewhere</b>, or if that modifier is not available, each folder the
 * user has opened in the tree is watched on its own, and the set follows the
 * tree as folders are opened, collapsed and refreshed.</li>
 * </ul>
 *
 * <h3>What a change does</h3>
 * <ul>
 * <li>A change inside a folder that is open in the tree re-reads the tree in
 * place ({@link DirectoryTreeBuilder#refresh()}): opened folders stay open,
 * the selection and the scroll position stay where they were. Changes deep in
 * folders nobody has opened (a build writing into {@code node_modules}, say)
 * are ignored.</li>
 * <li>Every change re-checks the open editor tabs
 * ({@link EditorFileStatus#refresh} for deletions,
 * {@link EditorFileStatus#checkExternalChanges} for edits).</li>
 * <li>Changes are gathered for {@link #SETTLE} after the last one, so a burst
 * (a git checkout, an unzip) causes one refresh, not hundreds.</li>
 * <li>While a name field is open for rename, the refresh waits for it to
 * close.</li>
 * <li>If the current folder itself disappears, the tree moves to the nearest
 * folder above it that still exists and says so in the Command Window.</li>
 * </ul>
 *
 * <p>
 * Files open in tabs that live outside the current folder are not watched;
 * they are re-checked whenever the Astra window regains focus, which is when
 * someone comes back from editing them elsewhere.
 * </p>
 */
public final class DirectoryWatcher {

    /** Quiet time after the last change before the tree is refreshed. */
    public static final Duration SETTLE = Duration.millis(350);

    private static final WatchEvent.Kind<?>[] KINDS = {ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY};

    /** Recursive watching on Windows, or null where the JDK does not offer it. */
    private static final WatchEvent.Modifier FILE_TREE = fileTreeModifier();

    private static UI_Main ide;
    private static WatchService service;

    /** Key to the folder it watches. Read by the watch thread. */
    private static final Map<WatchKey, Path> KEYS = new ConcurrentHashMap<>();

    /** Folder to its key. FX thread only. */
    private static final Map<Path, WatchKey> BY_FOLDER = new HashMap<>();

    /** Folders read into the tree, normalised; the filter for tree refreshes. */
    private static volatile Set<Path> openFolders = Set.of();

    /** The tree root being watched; FX thread only. */
    private static Path root;
    private static boolean recursive;

    private static final AtomicBoolean TREE_DIRTY = new AtomicBoolean();
    private static final AtomicBoolean FILES_DIRTY = new AtomicBoolean();

    private static PauseTransition settle;
    private static boolean syncQueued;

    private DirectoryWatcher() {
    }

    /**
     * Starts watching. Call once, after the File Explorer has been built.
     *
     * @param ideRef the IDE controller
     */
    public static void install(UI_Main ideRef) {
        if (ide != null || ideRef == null) {
            return;
        }
        ide = ideRef;
        try {
            service = FileSystems.getDefault().newWatchService();
        } catch (IOException | UnsupportedOperationException e) {
            System.err.println("File watching is not available: " + e.getMessage());
            return;
        }

        settle = new PauseTransition(SETTLE);
        settle.setOnFinished(e -> apply());

        DirectoryTreeItem.setLoadListener(DirectoryWatcher::requestSync);
        if (ide.projectTree != null) {
            ide.projectTree.rootProperty().addListener((observable, was, now) -> requestSync());
        }

        Thread thread = new Thread(DirectoryWatcher::loop, "directory-watcher");
        thread.setDaemon(true);
        thread.start();

        requestSync();
    }

    // =====================================================================
    // Which folders are watched (FX thread)
    // =====================================================================

    /** Queues one {@link #sync()}, however many times it is asked for. */
    private static void requestSync() {
        if (syncQueued || service == null) {
            return;
        }
        syncQueued = true;
        Platform.runLater(() -> {
            syncQueued = false;
            sync();
        });
    }

    /** Brings the registered folders into line with the tree. */
    private static void sync() {
        if (ide == null || service == null) {
            return;
        }
        TreeItem<Path> rootItem = ide.projectTree == null ? null : ide.projectTree.getRoot();
        Path newRoot = rootItem == null ? null : normal(rootItem.getValue());

        Set<Path> open = new HashSet<>();
        if (rootItem instanceof DirectoryTreeItem folder) {
            collect(folder, open);
        }
        openFolders = Set.copyOf(open);

        if (!Objects.equals(newRoot, root)) {
            cancelAll();
            root = newRoot;
            recursive = false;
            if (root != null && FILE_TREE != null && Files.isDirectory(root)) {
                recursive = register(root, FILE_TREE);
            }
        }
        if (recursive) {
            return;
        }

        // Per-folder mode: watch exactly the folders read into the tree.
        Iterator<Map.Entry<Path, WatchKey>> it = BY_FOLDER.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Path, WatchKey> entry = it.next();
            if (!open.contains(entry.getKey()) || !entry.getValue().isValid()) {
                entry.getValue().cancel();
                KEYS.remove(entry.getValue());
                it.remove();
            }
        }
        if (root != null && Files.isDirectory(root)) {
            open.add(root);
        }
        for (Path folder : open) {
            if (!BY_FOLDER.containsKey(folder) && Files.isDirectory(folder)) {
                register(folder, null);
            }
        }
    }

    private static void collect(DirectoryTreeItem folder, Set<Path> into) {
        if (!folder.isLoaded() || folder.getValue() == null) {
            return;
        }
        into.add(normal(folder.getValue()));
        for (DirectoryTreeItem entry : folder.entries()) {
            if (entry.isLoaded()) {
                collect(entry, into);
            }
        }
    }

    private static boolean register(Path folder, WatchEvent.Modifier modifier) {
        try {
            WatchKey key = modifier == null
                    ? folder.register(service, KINDS)
                    : folder.register(service, KINDS, modifier);
            KEYS.put(key, folder);
            BY_FOLDER.put(folder, key);
            return true;
        } catch (IOException | RuntimeException e) {
            // Unsupported modifier, a folder without access rights, a folder
            // that went away: it simply is not watched.
            return false;
        }
    }

    private static void cancelAll() {
        for (WatchKey key : BY_FOLDER.values()) {
            key.cancel();
            KEYS.remove(key);
        }
        BY_FOLDER.clear();
    }

    // =====================================================================
    // The watch thread
    // =====================================================================

    private static void loop() {
        while (true) {
            WatchKey key;
            try {
                key = service.take();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (ClosedWatchServiceException e) {
                return;
            }

            Path folder = KEYS.get(key);
            boolean tree = false;
            boolean files = false;
            Set<Path> open = openFolders;

            for (WatchEvent<?> event : key.pollEvents()) {
                if (folder == null) {
                    continue;
                }
                files = true;
                if (event.kind() == OVERFLOW) {
                    tree = true;
                    continue;
                }
                if (!(event.context() instanceof Path relative)) {
                    continue;
                }
                Path parent = folder.resolve(relative).getParent();
                if (parent != null && open.contains(parent)) {
                    tree = true;
                }
            }

            if (!key.reset()) {
                // The folder itself went away (deleted, renamed, drive gone).
                KEYS.remove(key);
                tree = true;
                files = true;
            }

            if (tree) {
                TREE_DIRTY.set(true);
            }
            if (files) {
                FILES_DIRTY.set(true);
            }
            if (tree || files) {
                Platform.runLater(() -> settle.playFromStart());
            }
        }
    }

    // =====================================================================
    // Applying a settled burst (FX thread)
    // =====================================================================

    private static void apply() {
        if (ide == null) {
            return;
        }
        boolean tree = TREE_DIRTY.getAndSet(false);
        boolean files = FILES_DIRTY.getAndSet(false);

        if (tree) {
            if (DirectoryTreeBuilder.isRenaming()) {
                // Re-reading now would close the name field under the user.
                TREE_DIRTY.set(true);
                settle.playFromStart();
            } else if (root != null && !Files.isDirectory(root)) {
                recoverMissingRoot(root);
            } else {
                DirectoryTreeBuilder.refresh();
            }
        }
        if (tree || files) {
            EditorFileStatus.refresh(ide);
            EditorFileStatus.checkExternalChanges(ide);
        }
        requestSync();
    }

    /** Moves the tree to the nearest folder above a vanished current folder. */
    private static void recoverMissingRoot(Path gone) {
        Path up = gone.getParent();
        while (up != null && !Files.isDirectory(up)) {
            up = up.getParent();
        }
        if (up == null) {
            NavigationActions.say("The current folder no longer exists: " + gone);
            return;
        }
        NavigationActions.say("The current folder no longer exists: " + gone + ". Showing " + up + ".");
        NavigationActions.goTo(ide, up);
    }

    // =====================================================================
    // Plumbing
    // =====================================================================

    private static Path normal(Path path) {
        if (path == null) {
            return null;
        }
        try {
            return path.toAbsolutePath().normalize();
        } catch (RuntimeException e) {
            return path;
        }
    }

    /**
     * {@code com.sun.nio.file.ExtendedWatchEventModifier.FILE_TREE}, looked up
     * by name so the project needs no compile-time dependency on
     * {@code jdk.unsupported}. Null when the class or the constant is absent;
     * {@link #register} also falls back if the platform rejects it.
     */
    private static WatchEvent.Modifier fileTreeModifier() {
        try {
            Class<?> type = Class.forName("com.sun.nio.file.ExtendedWatchEventModifier");
            for (Object constant : type.getEnumConstants()) {
                if (constant instanceof Enum<?> e && "FILE_TREE".equals(e.name())
                        && constant instanceof WatchEvent.Modifier modifier) {
                    return modifier;
                }
            }
        } catch (Throwable ignored) {
            // Not available on this JDK or platform.
        }
        return null;
    }
}
