package ui.layout;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javafx.application.Platform;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import ui.UI_Main;
import ui.cli.CLI_Main;
import ui.cli.EditorCommandWindow;
import ui.codebot.CodeBotHost;
import ui.codebot.CodeBotPanel;
import ui.design.Dim;
import ui.design.section_dims.CodeBot_dim;
import ui.editor.settingsTab.UI_Settings_CustomLayout_Main;
import ui.explorer.CollapsiblePanel;
import ui.explorer.PanelActivation;
import ui.explorer.signal.SignalExplorerHost;
import ui.layout.custom.CustomLayoutConfig;
import ui.layout.custom.CustomLayoutTheme;
import ui.ui_functions.Variable;

/**
 * Arranges the main window's regions -- File Explorer, editor, Command
 * Window, Variable Explorer, Code Bot and (in Custom) Signal Explorer -- into
 * the layout chosen on the Settings &gt; Layout band.
 *
 * <h3>How a switch works</h3>
 * <p>
 * The region nodes are built once, by {@code Main_Window}, and never
 * rebuilt: the editor keeps its tabs, the console its history, the bot its
 * conversation. A switch tears down the splits of the old layout (emptying
 * them, so every region is free to join a new parent), builds fresh splits
 * for the new one, and puts the top split into a {@link StackPane} host that
 * sits in the window's centre. Divider positions always come from
 * {@code Dim.Layout}, {@code Dim.Split} or {@code Dim.CustomLayout}, so
 * choosing a layout resets any dragging done before.
 * </p>
 *
 * <pre>
 *   DEFAULT             H[ Explorer(tree / bot) | V[Editor / CLI] | Variables ]      2 : 8 : 2
 *   BOT_CENTERED        H[ V[Editor / Variables] | Bot ]
 *   EDITOR_CLI          V[ Editor / CLI ]          bot open: V[ Editor / H[CLI | Bot] ]
 *   DIRECTORY_CENTERED  H[ Explorer(tree / bot) | V[Editor / CLI] ]
 *   EDITOR_BOT_CLI      H[ Editor | CLI ]          bot open: H[ Editor | Bot | CLI ]
 *   CUSTOM              H[ Explorer(tree / bot) | V[Editor / CLI] | Variables ]
 * </pre>
 *
 * <h3>The Signal Explorer</h3>
 * <p>
 * The Signal Explorer is part of the Variable Explorer now, not of the Custom
 * layout. It sits in the bottom 20% of the Variable Explorer's own body
 * whenever it is open, in every layout that shows the Variable Explorer. It
 * opens from the Signals ribbon's Set window (Apply) and closes from the
 * {@code x} in its title strip ({@link SignalExplorerHost}). A layout switch
 * keeps that choice: teardown takes it out of the body and
 * {@link SignalExplorerHost#redock()} puts it back once the new layout is
 * built.
 * </p>
 *
 * <h3>The 2 : 8 : 2 ratio</h3>
 * <p>
 * Default and Custom open the File Explorer, the editor column and the
 * Variable Explorer at 2 : 8 : 2 of the width ({@code Dim.Split}).
 * {@link SplitRatio} holds that ratio through the first show, maximise and
 * any resize, until the user drags a divider.
 * </p>
 *
 * <h3>The Custom layout</h3>
 * <p>
 * Built like Default, with the panels and colours chosen in the Custom
 * Layout window ({@link CustomLayoutConfig}, painted by
 * {@link CustomLayoutTheme}). Nothing is ever removed: an unticked panel
 * only <em>starts</em> minimised, and comes back by itself when needed --
 * </p>
 * <ul>
 * <li>Command Window: shrunk to its strip; restored whenever a command or a
 * script starts running.</li>
 * <li>Editor: shrunk to its tab strip; restored when a file opens or when it
 * is clicked. (Only when the Command Window is ticked -- the editor column
 * is never left with nothing open.)</li>
 * <li>Directory Explorer: its rail. The Code Bot lives inside it, so a
 * ticked Chat Bot opens it.</li>
 * <li>Variable Explorer: the whole column -- the Signal Explorer inside it
 * included -- becomes its rail. Restored when a run produces variables, or
 * when the Signal Explorer is opened. The Variable Explorer tick stands for
 * both; the Signal Explorer has no tick of its own any more.</li>
 * <li>Chat Bot: ticked opens it under the File Explorer.</li>
 * </ul>
 * <p>
 * These reveals only act in the Custom layout; in the others a minimised
 * panel stays the way the user left it.
 * </p>
 * <p>
 * {@link #apply} -- the Layout band's tiles -- opens the Custom Layout
 * window when Custom is chosen. {@link #rebuild} does not; the window's own
 * Preview / Apply / Cancel use it, and so does the launch.
 * </p>
 *
 * <h3>The Code Bot</h3>
 * <p>
 * Every layout registers two small actions: where the bot goes when it opens
 * and how the space is handed back when it closes. {@code CodeBotHost}
 * calls {@link #dockBot(boolean)}, so the Home ribbon's Code Bot button and
 * the bot's own close button behave correctly in every layout. Bot Centered
 * and Editor-Bot-CLI open the bot when chosen; Custom opens it if its Chat
 * Bot tick says so; the others keep it open if it already was.
 * </p>
 *
 * <h3>Panels that change behaviour with the layout</h3>
 * <ul>
 * <li>The Variable Explorer cannot collapse to its rail in Bot Centered,
 * where it sits under the editor rather than beside it.</li>
 * <li>The Command Window can minimise only where it sits directly under the
 * editor (Default, Directory Centered, Custom, Editor-CLI with the bot
 * closed).</li>
 * </ul>
 *
 * <h3>Bot Centered and errors</h3>
 * <p>
 * Bot Centered has no Command Window. When a run prints an error to the
 * console, the Variable Explorer's place is given to the Command Window so
 * the error is seen. It stays there until a layout is chosen again (clicking
 * the Bot Centered tile brings the Variable Explorer back). A console line
 * counts as an error when it contains the word "error", "errors" or
 * "error(s)" -- not "0 errors", and not a name such as {@code error_test.nc}.
 * </p>
 *
 * <h3>Persistence</h3>
 * <p>
 * The chosen layout is saved in the IDE's {@code Preferences} and restored at
 * the next launch, Custom included.
 * </p>
 */
public final class LayoutManager {

    private static final String KEY_LAYOUT = "layout.window";

    /** "error", "errors", "Error:", "error(s)" -- not "0 errors", not error_x. */
    private static final Pattern ERROR_MARK =
            Pattern.compile("(?i)(?<!\\b0 )\\berror(?:s\\b|\\(s\\)|\\b)");

    private static final StackPane HOST = new StackPane();
    private static final ObjectProperty<WindowLayout> CURRENT = new SimpleObjectProperty<>(null);

    /** Every split built for the current layout, so teardown can empty them. */
    private static final List<SplitPane> BUILT = new ArrayList<>();

    private static UI_Main ide;
    private static CollapsiblePanel explorer;
    private static CollapsiblePanel variables;
    private static Node editor;
    private static VBox cli;

    private static Runnable dockShow;
    private static Runnable dockHide;

    /** Bot Centered only: the Editor / Variables column, for the error swap. */
    private static SplitPane workColumn;
    private static boolean cliRevealed;

    /** Custom only: the editor is shrunk to its tab strip. */
    private static boolean editorMinimized;

    /** Custom only: the Editor / CLI split, to restore the editor's height. */
    private static SplitPane customCenter;

    /**
     * Custom only: something has run since the layout was built, so new
     * variables are the user's and should bring the Variable Explorer back.
     * Variables loaded at launch do not count.
     */
    private static boolean variablesArmed;

    private static ObservableList<Variable> watchedVariables;

    private static final ListChangeListener<Variable> VARIABLES_CHANGED = change -> {
        boolean added = false;
        while (change.next()) {
            if (change.wasAdded()) {
                added = true;
            }
        }
        if (added) {
            Platform.runLater(LayoutManager::revealVariables);
        }
    };

    private LayoutManager() {
    }

    // =====================================================================
    // Installation
    // =====================================================================

    /**
     * Takes charge of the regions and applies the saved layout.
     *
     * @param ideRef        the IDE controller (its editor tabs and console
     *                      must already exist)
     * @param explorerPanel the File Explorer panel
     * @param variablePanel the Variable Explorer panel
     * @param commandWindow the Command Window panel
     * @return the node to place in the window's centre
     */
    public static Region install(UI_Main ideRef, CollapsiblePanel explorerPanel,
            CollapsiblePanel variablePanel, VBox commandWindow) {
        ide = ideRef;
        explorer = explorerPanel;
        variables = variablePanel;
        editor = ideRef.editorTabs;
        cli = commandWindow;

        HOST.getStyleClass().add("layout-host");
        if (ide.console != null) {
            ide.console.textProperty().addListener(LayoutManager::onConsoleText);
        }

        // Opening the Signal Explorer must make it visible: expand the
        // Variable Explorer first if it is a rail.
        SignalExplorerHost.setRevealColumn(() -> {
            if (variables.isCollapsed()) {
                variables.setCollapsed(false);
            }
        });

        CustomLayoutConfig.init(ide);
        CustomLayoutTheme.attach(ide, HOST);
        installRevealHooks();

        WindowLayout saved = WindowLayout.fromName(
                ide.prefs == null ? null : ide.prefs.get(KEY_LAYOUT, WindowLayout.DEFAULT.name()));
        rebuild(saved);
        return HOST;
    }

    /** @return true once {@link #install} has run */
    public static boolean isInstalled() {
        return ide != null;
    }

    /** @return the layout on screen, observable, for the band's tiles */
    public static ReadOnlyObjectProperty<WindowLayout> currentProperty() {
        return CURRENT;
    }

    /** @return the layout on screen */
    public static WindowLayout current() {
        return CURRENT.get();
    }

    // =====================================================================
    // Switching
    // =====================================================================

    /**
     * Rearranges the window -- the Layout band's tiles. Choosing
     * {@link WindowLayout#CUSTOM} also opens the Custom Layout window.
     * Choosing the layout already on screen re-applies it, which resets its
     * dividers.
     *
     * @param layout the layout to show
     */
    public static void apply(WindowLayout layout) {
        arrange(layout, true);
    }

    /**
     * Rearranges the window without opening any window. Used at launch and
     * by the Custom Layout window's Preview, Apply and Cancel.
     *
     * @param layout the layout to show
     */
    public static void rebuild(WindowLayout layout) {
        arrange(layout, false);
    }

    private static void arrange(WindowLayout layout, boolean openCustomWindow) {
        if (!isInstalled() || layout == null) {
            return;
        }

        boolean botWasOpen = CodeBotHost.isShowing();
        teardown();

        switch (layout) {
            case BOT_CENTERED -> buildBotCentered();
            case EDITOR_CLI -> buildEditorCli();
            case DIRECTORY_CENTERED -> buildDirectoryCentered();
            case EDITOR_BOT_CLI -> buildEditorBotCli();
            case CUSTOM -> buildCustom();
            default -> buildDefault();
        }

        // The Signal Explorer lives in the Variable Explorer's body; put it
        // back if it was open before the switch.
        SignalExplorerHost.redock();

        CURRENT.set(layout);
        if (ide.prefs != null) {
            ide.prefs.put(KEY_LAYOUT, layout.name());
        }
        CustomLayoutTheme.setEnabled(layout.isCustom());

        boolean openBot = layout.isCustom()
                ? CustomLayoutConfig.effective().isShown(CustomLayoutConfig.Panel.CHAT_BOT)
                : layout.opensBot() || botWasOpen;
        if (openBot) {
            CodeBotHost.show();
        } else {
            keepActiveRegionOnScreen();
        }

        if (layout.isCustom() && openCustomWindow) {
            Platform.runLater(() -> UI_Settings_CustomLayout_Main.open(ide));
        }
    }

    /**
     * Docks or undocks the Code Bot in the current layout. Called by
     * {@code CodeBotHost}.
     *
     * @param open true to dock it, false to hand its space back
     * @return false if no layout is installed, so the caller should fall back
     *         to the explorer
     */
    public static boolean dockBot(boolean open) {
        Runnable action = open ? dockShow : dockHide;
        if (!isInstalled() || action == null) {
            return false;
        }
        action.run();
        return true;
    }

    // =====================================================================
    // Teardown
    // =====================================================================

    /**
     * Empties the old layout so every region can join a new parent. A node in
     * a SplitPane's item list sits inside the split's own wrapper, so emptying
     * the list is the only reliable way to release it.
     */
    private static void teardown() {
        EditorCommandWindow.setMinimizeAllowed(true);
        EditorCommandWindow.setMinimized(false);
        EditorCommandWindow.attachTo(null);

        explorer.setCollapseEnabled(true);
        explorer.setCollapsed(false);
        explorer.attachTo(null);
        variables.setCollapseEnabled(true);
        variables.setCollapsed(false);
        variables.attachTo(null);

        CodeBotHost.markClosed();
        CodeBotHost.removeFromExplorer();
        SignalExplorerHost.removeFromVariables();
        setEditorMinimized(false);

        for (SplitPane split : BUILT) {
            split.getItems().clear();
        }
        BUILT.clear();
        HOST.getChildren().clear();

        dockShow = null;
        dockHide = null;
        workColumn = null;
        cliRevealed = false;
        customCenter = null;
        variablesArmed = false;
    }

    // =====================================================================
    // The arrangements
    // =====================================================================

    /** H[ Explorer | V[Editor / CLI] | Variables ] at 2 : 8 : 2; bot under the tree. */
    private static void buildDefault() {
        SplitPane center = editorOverConsole();
        SplitPane main = threeColumns(center);
        HOST.getChildren().setAll(main);
    }

    /**
     * Default's arrangement, with each panel starting open or minimised as
     * the Custom Layout window says. The Signal Explorer is not placed here:
     * it opens on demand and is re-docked by {@link #arrange}, like in every
     * other layout.
     */
    private static void buildCustom() {
        CustomLayoutConfig config = CustomLayoutConfig.effective();

        SplitPane center = editorOverConsole();
        customCenter = center;
        SplitPane main = threeColumns(center);

        HOST.getChildren().setAll(main);

        // Starting states. The dividers are set above, so a panel collapsed
        // here remembers the 2 : 8 : 2 positions and restores them on expand.
        // The Variable Explorer tick covers the Signal Explorer too.
        boolean showVariables = config.isShown(CustomLayoutConfig.Panel.VARIABLES);
        boolean showCli = config.isShown(CustomLayoutConfig.Panel.CLI);

        if (!config.isShown(CustomLayoutConfig.Panel.DIRECTORY)) {
            explorer.setCollapsed(true);
        }
        if (!showVariables) {
            variables.setCollapsed(true);
        }
        if (!showCli) {
            EditorCommandWindow.setMinimized(true);
        }
        // Never minimise both halves of the editor column.
        if (!config.isShown(CustomLayoutConfig.Panel.EDITOR) && showCli) {
            setEditorMinimized(true);
        }
    }

    /** The vertical Editor / Command Window split shared by three layouts. */
    private static SplitPane editorOverConsole() {
        SplitPane center = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.FALSE);
        dividers(center, Dim.Split.EDITOR_OVER_CONSOLE);
        SplitRatio.hold(center, Dim.Split.EDITOR_OVER_CONSOLE);
        EditorCommandWindow.attachTo(center);
        return center;
    }

    /**
     * H[ Explorer | center | Variables ] at 2 : 8 : 2, held until the user
     * drags; the bot docks under the tree.
     */
    private static SplitPane threeColumns(SplitPane center) {
        SplitPane main = split(Orientation.HORIZONTAL, explorer, center, variables);
        double[] positions = Dim.Split.mainPositions();
        dividers(main, positions);
        SplitRatio.hold(main, positions);
        explorer.attachTo(main);
        variables.attachTo(main);
        CodeBotHost.attach(explorer, main);

        dockShow = () -> CodeBotHost.placeInExplorer(CodeBot_dim.OPEN_DIVIDER_POSITION);
        dockHide = CodeBotHost::removeFromExplorer;
        return main;
    }

    /** H[ V[Editor / Variables] | Bot ]; no Command Window until an error. */
    private static void buildBotCentered() {
        SplitPane left = split(Orientation.VERTICAL, editor, variables);
        SplitPane.setResizableWithParent(variables, Boolean.TRUE);
        dividers(left, Dim.Layout.BOT_CENTERED_EDITOR_OVER_VARIABLES);
        variables.setCollapseEnabled(false);
        workColumn = left;

        EditorCommandWindow.setMinimizeAllowed(false);

        SplitPane main = split(Orientation.HORIZONTAL, left);

        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(bot);
            }
            dividers(main, Dim.Layout.BOT_CENTERED_WORK_SHARE);
        };
        dockHide = () -> main.getItems().remove(CodeBotHost.panel());

        HOST.getChildren().setAll(main);
    }

    /** V[ Editor / CLI ], 50 / 50; the bot shares the bottom row with the CLI. */
    private static void buildEditorCli() {
        SplitPane main = split(Orientation.VERTICAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        dividers(main, Dim.Layout.EDITOR_CLI_EDITOR_OVER_CONSOLE);
        EditorCommandWindow.attachTo(main);

        SplitPane[] bottom = new SplitPane[1];

        dockShow = () -> {
            if (bottom[0] != null && main.getItems().contains(bottom[0])) {
                return;
            }
            // Beside the bot the CLI no longer sits directly under the
            // editor, so it cannot minimise there.
            EditorCommandWindow.setMinimizeAllowed(false);
            EditorCommandWindow.attachTo(null);
            double[] keep = main.getDividerPositions();

            SplitPane row = split(Orientation.HORIZONTAL);
            int at = main.getItems().indexOf(cli);
            main.getItems().set(at < 0 ? 1 : at, row);
            row.getItems().addAll(cli, CodeBotHost.prepareForColumn());
            dividers(row, Dim.Layout.EDITOR_CLI_CONSOLE_BESIDE_BOT);
            dividers(main, keep);
            bottom[0] = row;
        };
        dockHide = () -> {
            SplitPane row = bottom[0];
            if (row == null) {
                return;
            }
            double[] keep = main.getDividerPositions();
            row.getItems().clear();
            int at = main.getItems().indexOf(row);
            main.getItems().set(at < 0 ? 1 : at, cli);
            dividers(main, keep);
            EditorCommandWindow.attachTo(main);
            EditorCommandWindow.setMinimizeAllowed(true);
            bottom[0] = null;
        };

        HOST.getChildren().setAll(main);
    }

    /** H[ Explorer | V[Editor / CLI] ]; bot under the tree at 50 / 50. */
    private static void buildDirectoryCentered() {
        SplitPane center = editorOverConsole();

        SplitPane main = split(Orientation.HORIZONTAL, explorer, center);
        dividers(main, Dim.Layout.DIRECTORY_SHARE);
        explorer.attachTo(main);
        CodeBotHost.attach(explorer, main);

        dockShow = () -> CodeBotHost.placeInExplorer(Dim.Layout.DIRECTORY_TREE_OVER_BOT);
        dockHide = CodeBotHost::removeFromExplorer;

        HOST.getChildren().setAll(main);
    }

    /** H[ Editor | CLI ], three equal columns once the bot opens. */
    private static void buildEditorBotCli() {
        SplitPane main = split(Orientation.HORIZONTAL, editor, cli);
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);
        EditorCommandWindow.setMinimizeAllowed(false);

        dockShow = () -> {
            CodeBotPanel bot = CodeBotHost.prepareForColumn();
            if (!main.getItems().contains(bot)) {
                main.getItems().add(1, bot);
            }
            dividers(main, Dim.Layout.THREE_COLUMN_FIRST, Dim.Layout.THREE_COLUMN_SECOND);
        };
        dockHide = () -> {
            main.getItems().remove(CodeBotHost.panel());
            dividers(main, Dim.Layout.TWO_COLUMN_SPLIT);
        };

        HOST.getChildren().setAll(main);
    }

    // =====================================================================
    // Custom: bringing minimised panels back when they are needed
    // =====================================================================

    /**
     * Connected once. Each hook checks that Custom is on screen, so the other
     * layouts are not affected.
     */
    private static void installRevealHooks() {
        // A command or a script starts: the Command Window must be seen.
        CLI_Main.busyProperty().addListener((obs, was, busy) -> {
            if (!Boolean.TRUE.equals(busy) || !isCustom()) {
                return;
            }
            variablesArmed = true;
            Platform.runLater(() -> EditorCommandWindow.setMinimized(false));
        });

        // A file opens: the editor must be seen.
        if (ide.editorTabs != null) {
            ide.editorTabs.getTabs().addListener((ListChangeListener<Tab>) change -> {
                while (change.next()) {
                    if (change.wasAdded() && editorMinimized) {
                        Platform.runLater(() -> setEditorMinimized(false));
                        return;
                    }
                }
            });
        }
        // Clicking the shrunken editor opens it too.
        if (editor != null) {
            editor.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
                if (editorMinimized) {
                    setEditorMinimized(false);
                }
            });
        }

        // A run produces variables: the Variable Explorer must be seen.
        if (ide.varTable != null) {
            watchVariables(ide.varTable.getItems());
            ide.varTable.itemsProperty().addListener((obs, was, isNow) -> watchVariables(isNow));
        }
    }

    private static void watchVariables(ObservableList<Variable> list) {
        if (watchedVariables != null) {
            watchedVariables.removeListener(VARIABLES_CHANGED);
        }
        watchedVariables = list;
        if (list != null) {
            list.addListener(VARIABLES_CHANGED);
        }
    }

    private static void revealVariables() {
        if (!isCustom() || !variablesArmed) {
            return;
        }
        if (variables.isCollapsed()) {
            variables.setCollapsed(false);
        }
        SignalExplorerHost.setTableMinimized(false);
    }

    /**
     * Shrinks the editor to its tab strip (the Command Window takes the
     * column), or restores it.
     */
    private static void setEditorMinimized(boolean minimize) {
        if (!(editor instanceof Region region) || minimize == editorMinimized) {
            return;
        }
        editorMinimized = minimize;
        if (minimize) {
            double h = Dim.CustomLayout.EDITOR_MINIMIZED_HEIGHT;
            region.setMinHeight(h);
            region.setPrefHeight(h);
            region.setMaxHeight(h);
        } else {
            region.setMinHeight(Region.USE_COMPUTED_SIZE);
            region.setPrefHeight(Region.USE_COMPUTED_SIZE);
            region.setMaxHeight(Double.MAX_VALUE);
            if (customCenter != null) {
                dividers(customCenter, Dim.Split.EDITOR_OVER_CONSOLE);
            }
        }
    }

    private static boolean isCustom() {
        return CURRENT.get() == WindowLayout.CUSTOM;
    }

    // =====================================================================
    // Bot Centered: show the Command Window when a run reports an error
    // =====================================================================

    private static void onConsoleText(ObservableValue<? extends String> obs, String was, String now) {
        if (CURRENT.get() != WindowLayout.BOT_CENTERED || cliRevealed || workColumn == null) {
            return;
        }
        if (now == null || was == null || now.length() <= was.length()) {
            return;
        }
        // Console output only ever grows at the end, so the new part is the
        // tail; nothing before it needs to be scanned again.
        String appended = now.substring(was.length());
        if (ERROR_MARK.matcher(appended).find()) {
            // Outside the text-change notification, which is still running.
            Platform.runLater(LayoutManager::revealCommandWindow);
        }
    }

    private static void revealCommandWindow() {
        if (cliRevealed || workColumn == null) {
            return;
        }
        int at = workColumn.getItems().indexOf(variables);
        if (at < 0) {
            return;
        }
        cliRevealed = true;
        double[] keep = workColumn.getDividerPositions();
        SplitPane.setResizableWithParent(cli, Boolean.TRUE);
        workColumn.getItems().set(at, cli);
        dividers(workColumn, keep);
        PanelActivation.setActive(PanelActivation.Panel.COMMAND_WINDOW);
        if (ide.console != null) {
            ide.console.positionCaret(ide.console.getLength());
        }
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static SplitPane split(Orientation orientation, Node... items) {
        SplitPane split = new SplitPane(items);
        split.setOrientation(orientation);
        BUILT.add(split);
        return split;
    }

    /**
     * Sets divider positions now and again on the next pulse: a split that is
     * already on screen honours new positions only once it has laid out with
     * its new items.
     */
    private static void dividers(SplitPane split, double... positions) {
        if (positions == null || positions.length == 0) {
            return;
        }
        split.setDividerPositions(positions);
        Platform.runLater(() -> split.setDividerPositions(positions));
    }

    /**
     * After a switch, a region that is no longer on screen must not keep the
     * navy highlight. Falls back to the editor.
     */
    private static void keepActiveRegionOnScreen() {
        PanelActivation.Panel active = PanelActivation.getActive();
        Node node = null;
        if (active != null) {
            node = switch (active) {
                case FILE_EXPLORER -> explorer;
                case VARIABLE_EXPLORER -> variables;
                case COMMAND_WINDOW -> cli;
                case CODE_BOT -> CodeBotHost.isShowing() ? CodeBotHost.panel() : null;
                case SIGNAL_EXPLORER -> SignalExplorerHost.isPlaced() ? SignalExplorerHost.panelIfBuilt() : null;
                case EDITOR -> editor;
            };
        }
        if (node == null || !isInLayout(node)) {
            PanelActivation.setActive(PanelActivation.Panel.EDITOR);
        }
    }

    private static boolean isInLayout(Node node) {
        for (Node n = node; n != null; n = n.getParent()) {
            if (n == HOST) {
                return true;
            }
        }
        return false;
    }
}
