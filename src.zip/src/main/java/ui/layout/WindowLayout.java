package ui.layout;

import ui.ui_functions.tools.LayoutIcons;

/**
 * The window arrangements offered on the Settings &gt; Layout band.
 *
 * <pre>
 *   DEFAULT             [Dir / Bot] | [Editor / CLI] | [Variables]
 *   BOT_CENTERED        [Editor / Variables] | [Code Bot, full height]
 *   EDITOR_CLI          [Editor] over [CLI (| Bot)]
 *   DIRECTORY_CENTERED  [Dir (/ Bot)] | [Editor / CLI]
 *   EDITOR_BOT_CLI      [Editor] | [Code Bot] | [CLI]
 *   CUSTOM              [Dir (/ Bot)] | [Editor / CLI] | [Variables / Signals]
 *                       with the panels, colours and theme chosen in the
 *                       Custom Layout window
 * </pre>
 *
 * <p>
 * Custom is a real arrangement: it is saved and restored like the others.
 * Choosing its tile shows it and opens the Custom Layout window, where it is
 * edited. Whether it opens the Code Bot depends on the window's Chat Bot
 * tick, so {@link #opensBot()} is false for it and {@code LayoutManager}
 * asks the configuration instead.
 * </p>
 *
 * <p>
 * The name is what the preference stores, so renaming a constant resets that
 * preference to {@link #DEFAULT} on the next launch rather than failing.
 * </p>
 */
public enum WindowLayout {

    DEFAULT("Default", "Default layout: explorer, editor, Command Window and Variable Explorer",
            LayoutIcons.LAYOUT_DEFAULT, false),

    BOT_CENTERED("Bot Centered", "Code Bot in the full right column; editor over Variable Explorer",
            LayoutIcons.LAYOUT_BOT_CENTERED, true),

    EDITOR_CLI("Editor-CLI", "Editor over Command Window only, 50 / 50",
            LayoutIcons.LAYOUT_EDITOR_CLI, false),

    DIRECTORY_CENTERED("Directory Centered", "File Explorer beside the editor and Command Window",
            LayoutIcons.LAYOUT_DIRECTORY_CENTERED, false),

    EDITOR_BOT_CLI("Editor-Bot-CLI", "Editor, Code Bot and Command Window in three equal columns",
            LayoutIcons.LAYOUT_EDITOR_BOT_CLI, true),

    CUSTOM("Custom", "Your own layout: choose which panels start open, their colours and the theme",
            LayoutIcons.LAYOUT_CUSTOM, false);

    private final String label;
    private final String tooltip;
    private final String iconName;
    private final boolean opensBot;

    WindowLayout(String label, String tooltip, String iconName, boolean opensBot) {
        this.label = label;
        this.tooltip = tooltip;
        this.iconName = iconName;
        this.opensBot = opensBot;
    }

    /** @return the text under the tile */
    public String label() {
        return label;
    }

    /** @return the tile's tooltip */
    public String tooltip() {
        return tooltip;
    }

    /** @return the icon's base name under {@code /icons/layout} */
    public String iconName() {
        return iconName;
    }

    /**
     * @return true for the arrangements built around the Code Bot, which open
     *         it automatically when chosen
     */
    public boolean opensBot() {
        return opensBot;
    }

    /**
     * @return true for an arrangement that changes the window. Every layout
     *         is one now, {@link #CUSTOM} included; kept so callers written
     *         when Custom was only a placeholder keep compiling
     */
    public boolean isArrangement() {
        return true;
    }

    /**
     * @return true for the layout edited in the Custom Layout window
     */
    public boolean isCustom() {
        return this == CUSTOM;
    }

    /**
     * @param name a stored preference value
     * @return the matching layout, or {@link #DEFAULT} for anything unknown
     */
    public static WindowLayout fromName(String name) {
        if (name != null) {
            for (WindowLayout layout : values()) {
                if (layout.name().equals(name)) {
                    return layout;
                }
            }
        }
        return DEFAULT;
    }
}
