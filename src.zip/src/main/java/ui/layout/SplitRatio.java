package ui.layout;

import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.SplitPane;
import javafx.scene.input.MouseEvent;

/**
 * Holds a split's divider positions while the window settles, and lets go
 * the moment the user drags one of its dividers.
 *
 * <h3>Why this exists</h3>
 * <p>
 * A divider position is a fraction of the split's width, and a SplitPane
 * resolves it against whatever width it has when it lays out. At launch the
 * layout is built before the window is shown, then the window is shown, then
 * maximised -- several widths in a row, with the panels' own preferred and
 * minimum widths competing at each step. Setting the positions once (even
 * once more on the next pulse) hit whichever width happened to be current,
 * which is why the File Explorer : editor : Variable Explorer ratio came out
 * different on every launch.
 * </p>
 *
 * <h3>What it does</h3>
 * <p>
 * Every time the split's width (height, for a vertical split) changes, the
 * positions are set again -- first show, maximise, restore, any resize --
 * so the ratio is exactly the configured one at every size. As soon as the
 * user presses on one of <em>this</em> split's dividers (not a nested
 * split's), the hold is released for good and the split behaves like any
 * other: the user's widths are kept.
 * </p>
 * <p>
 * Building a new layout builds new splits, so choosing a layout on the
 * Layout band starts a fresh hold.
 * </p>
 */
public final class SplitRatio {

    private static final String DIVIDER_CLASS = "split-pane-divider";

    private SplitRatio() {
    }

    /**
     * @param split     the split; its orientation must already be set
     * @param positions the divider positions to hold
     * @return an action that releases the hold early. Only needed for a
     *         split that outlives its layout (the Variable Explorer's own
     *         split); a split built per layout is simply dropped.
     */
    public static Runnable hold(SplitPane split, double... positions) {
        if (split == null || positions == null || positions.length == 0) {
            return () -> {
            };
        }
        final double[] keep = positions.clone();
        final ReadOnlyDoubleProperty size = split.getOrientation() == Orientation.HORIZONTAL
                ? split.widthProperty()
                : split.heightProperty();

        final ChangeListener<Number> follow = (obs, was, isNow) -> {
            if (isNow.doubleValue() > 0) {
                split.setDividerPositions(keep);
            }
        };
        size.addListener(follow);

        final boolean[] released = { false };
        @SuppressWarnings("unchecked")
        final EventHandler<MouseEvent>[] filter = new EventHandler[1];
        final Runnable release = () -> {
            if (!released[0]) {
                released[0] = true;
                size.removeListener(follow);
                split.removeEventFilter(MouseEvent.MOUSE_PRESSED, filter[0]);
            }
        };
        filter[0] = e -> {
            if (onOwnDivider(split, e.getTarget())) {
                release.run();
            }
        };
        split.addEventFilter(MouseEvent.MOUSE_PRESSED, filter[0]);
        return release;
    }

    /**
     * True if the press landed on one of this split's own dividers. A
     * SplitPane's skin adds its dividers straight to the split's children,
     * so a nested split's divider has a different parent.
     */
    private static boolean onOwnDivider(SplitPane split, Object target) {
        Node node = target instanceof Node n ? n : null;
        while (node != null && node != split) {
            if (node.getStyleClass().contains(DIVIDER_CLASS) && node.getParent() == split) {
                return true;
            }
            node = node.getParent();
        }
        return false;
    }
}
