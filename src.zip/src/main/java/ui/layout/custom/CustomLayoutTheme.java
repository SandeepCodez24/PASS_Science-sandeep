package ui.layout.custom;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import ui.UI_Main;
import ui.design.Dim;
import ui.explorer.TitleBarIcon;
import ui.layout.custom.CustomLayoutConfig.Panel;
import ui.managers.TextColourManager;
import ui.managers.ThemeManager;
import ui.managers.ToolbarManager;

/**
 * Paints the Custom layout's colours: each panel's body, its text, and the
 * active title strip.
 *
 * <h3>How it stays out of the other layouts</h3>
 * <p>
 * The colours are a generated stylesheet attached to the layout host -- the
 * node every panel sits in -- not to the scene, and every rule starts with
 * {@code .custom-layout-on}, a class the host carries only while Custom is
 * on screen. Switching to any other layout removes the class and the sheet,
 * and the theme's own colours are back. The ribbon, the breadcrumb bar and
 * the footer are outside the host and never touched.
 * </p>
 *
 * <h3>Why the rules always win</h3>
 * <p>
 * The {@code .custom-layout-on} prefix gives every rule one more class than
 * the theme rule it replaces, and a parent's stylesheet is consulted after
 * the scene's. So the order of the scene's sheets (theme, editor, design)
 * does not matter, and nothing here fights {@code DesignStylesheet} for the
 * last place in the list.
 * </p>
 *
 * <h3>Readable text</h3>
 * <p>
 * Text colour follows the background, not the theme: a dark background gets
 * light text and the other way round ({@link CustomLayoutConfig#ink}). The
 * editor is the exception -- its text is syntax-coloured -- so instead the
 * whole editor palette is switched: a dark editor background loads
 * {@code editor_dark.css} even in the light theme, and the other way round,
 * through {@link ThemeManager#setEditorInkSelector}. The Command Window does
 * the same with its own background: its typed commands take the dark or the
 * light text palette through {@link TextColourManager#setConsoleInkSelector}.
 * The active title-strip
 * glyphs follow the base colour the same way, through
 * {@link TitleBarIcon#setActiveInkOnDark}.
 * </p>
 *
 * <h3>!important</h3>
 * <p>
 * Every body rule is {@code !important}. Some feature sheets (the editor
 * palette, the Code Bot sheet) style the same nodes with long selectors of
 * their own; an important declaration beats a normal one whatever its
 * specificity, so the user's colour shows on every panel, not only on the
 * ones whose theme rules happen to be short.
 * </p>
 *
 * <h3>The window chrome</h3>
 * <p>
 * The Base Color also paints the navy chrome around the ribbon: the Row-1
 * tab strip and the window background behind the ribbon. Those are coloured
 * by inline styles ({@code ToolbarSetup}, {@code Main_Window}), which no
 * stylesheet can beat, so their inline style is extended while Custom is on
 * screen and put back exactly as it was when Custom goes. On a light base
 * colour the tab labels turn dark so they stay readable. The chrome exists
 * only after {@code Main_Window} has built the ribbon, which is after the
 * layout is installed, so it is painted once the layout host joins the
 * scene.
 * </p>
 */
public final class CustomLayoutTheme {

    /** The class the layout host carries while Custom is on screen. */
    public static final String ON_CLASS = "custom-layout-on";

    /** The class the Row-1 tab strip carries while Custom is on screen. */
    public static final String CHROME_CLASS = "custom-chrome-on";

    private static final String P = "." + ON_CLASS + " ";

    /** Every chrome node's inline style before Custom changed it. */
    private static final Map<Node, String> ORIGINAL_STYLE = new IdentityHashMap<>();

    private static String chromeSheet;
    private static Parent chromeSheetOwner;

    private static UI_Main ide;
    private static Region host;
    private static boolean enabled;
    private static String sheet;

    private CustomLayoutTheme() {
    }

    /**
     * Connects the painter to the layout host and to theme changes. Called
     * once by {@code LayoutManager.install}.
     *
     * @param ideRef  the IDE controller
     * @param hostRef the node every panel sits in
     */
    public static void attach(UI_Main ideRef, Region hostRef) {
        ide = ideRef;
        host = hostRef;
        ThemeManager.themeProperty().addListener((obs, was, isNow) -> refresh());
        // The ribbon is built after the layout; paint it once both are in
        // the scene.
        host.sceneProperty().addListener((obs, was, isNow) -> {
            if (isNow != null) {
                Platform.runLater(CustomLayoutTheme::refreshChrome);
            }
        });
    }

    /**
     * @param on true while the Custom layout is on screen
     */
    public static void setEnabled(boolean on) {
        enabled = on;
        refresh();
    }

    /** Rebuilds the sheet from {@link CustomLayoutConfig#effective()}. */
    public static void refresh() {
        if (host == null) {
            return;
        }
        if (sheet != null) {
            host.getStylesheets().remove(sheet);
            sheet = null;
        }
        host.getStyleClass().remove(ON_CLASS);

        if (!enabled) {
            TitleBarIcon.setActiveInkOnDark(true);
            ThemeManager.setEditorInkSelector(ide, null);
            TextColourManager.setConsoleInkSelector(null);
            refreshChrome();
            return;
        }

        CustomLayoutConfig config = CustomLayoutConfig.effective();
        boolean dark = CustomLayoutConfig.DARK.equals(ThemeManager.getActiveTheme());

        sheet = dataUri(css(config, dark));
        host.getStylesheets().add(sheet);
        host.getStyleClass().add(ON_CLASS);

        TitleBarIcon.setActiveInkOnDark(!CustomLayoutConfig.isLight(config.base()));
        // Captured per refresh: every change to the config calls refresh again.
        Color lightEditor = config.color(Panel.EDITOR, false);
        Color darkEditor = config.color(Panel.EDITOR, true);
        ThemeManager.setEditorInkSelector(ide, theme -> !CustomLayoutConfig.isLight(
                CustomLayoutConfig.DARK.equals(theme) ? darkEditor : lightEditor));
        Color lightCli = config.color(Panel.CLI, false);
        Color darkCli = config.color(Panel.CLI, true);
        TextColourManager.setConsoleInkSelector(theme -> !CustomLayoutConfig.isLight(
                CustomLayoutConfig.DARK.equals(theme) ? darkCli : lightCli));
        refreshChrome();
    }

    // =====================================================================
    // The chrome: Row-1 tab strip and the background behind the ribbon
    // =====================================================================

    /**
     * Paints the chrome in the base colour while Custom is on screen, or puts
     * the original inline styles back. Safe to call before the ribbon exists:
     * it does nothing then, and runs again when the host joins the scene.
     */
    public static void refreshChrome() {
        List<Node> chrome = chromeNodes();
        Node tabStrip = ToolbarManager.ribbonBar;

        if (chromeSheet != null && chromeSheetOwner != null) {
            chromeSheetOwner.getStylesheets().remove(chromeSheet);
        }
        chromeSheet = null;
        chromeSheetOwner = null;
        if (tabStrip != null) {
            tabStrip.getStyleClass().remove(CHROME_CLASS);
        }

        if (!enabled) {
            for (Node node : chrome) {
                String original = ORIGINAL_STYLE.remove(node);
                if (original != null) {
                    node.setStyle(original);
                }
            }
            return;
        }

        Color base = CustomLayoutConfig.effective().base();
        String fill = "-fx-background-color: " + hex(base) + ";";
        for (Node node : chrome) {
            String original = ORIGINAL_STYLE.computeIfAbsent(node,
                    n -> n.getStyle() == null ? "" : n.getStyle());
            String sep = original.isBlank() || original.trim().endsWith(";") ? " " : "; ";
            // A later declaration in the same inline style wins.
            node.setStyle(original + sep + fill);
        }

        // Tab labels are white on navy. On a light base colour they turn
        // dark; on a dark one the theme's white already reads.
        if (tabStrip instanceof Parent strip && CustomLayoutConfig.isLight(base)) {
            String ink = hex(CustomLayoutConfig.ink(base));
            StringBuilder css = new StringBuilder();
            String c = "." + CHROME_CLASS;
            rule(css, c + " .ribbon-tab, " + c + " .ribbon-tab .label, " + c + " .ribbon-tab .text",
                    "-fx-text-fill: " + ink + " !important; -fx-fill: " + ink + " !important;");
            chromeSheet = dataUri(css.toString());
            chromeSheetOwner = strip;
            strip.getStylesheets().add(chromeSheet);
            strip.getStyleClass().add(CHROME_CLASS);
        }
    }

    /**
     * The nodes whose inline style carries the navy: the Row-1 tab strip,
     * the box holding the three ribbon rows, and the window's root.
     */
    private static List<Node> chromeNodes() {
        List<Node> nodes = new ArrayList<>();
        if (ToolbarManager.ribbonBar != null) {
            nodes.add(ToolbarManager.ribbonBar);
        }
        if (ide != null && ide.rootNode instanceof BorderPane root) {
            if (root.getTop() != null) {
                nodes.add(root.getTop());
            }
            nodes.add(root);
        }
        return nodes;
    }

    // =====================================================================
    // The sheet
    // =====================================================================

    private static String css(CustomLayoutConfig c, boolean dark) {
        StringBuilder css = new StringBuilder(4096);
        base(css, c.base());
        editor(css, c.color(Panel.EDITOR, dark));
        directory(css, c.color(Panel.DIRECTORY, dark));
        console(css, c.color(Panel.CLI, dark));
        variables(css, c.color(Panel.VARIABLES, dark), c.base());
        bot(css, c.color(Panel.CHAT_BOT, dark));
        signals(css, c.color(Panel.SIGNALS, dark));
        return css.toString();
    }

    /** The active title strip, its collapsed rail, label and button hover. */
    private static void base(StringBuilder css, Color base) {
        String bg = hex(base);
        String edge = hex(CustomLayoutConfig.mix(base, Color.BLACK, 0.25));
        String ink = hex(CustomLayoutConfig.ink(base));
        String hover = CustomLayoutConfig.isLight(base) ? "rgba(0, 0, 0, 0.12)" : "rgba(255, 255, 255, 0.20)";

        rule(css, P + ".panel-title-bar.panel-active",
                "-fx-background-color: " + bg + ";"
                        + " -fx-border-color: transparent transparent " + edge + " transparent;");
        rule(css, P + ".panel-rail.panel-title-bar.panel-active",
                "-fx-background-color: " + bg + ";"
                        + " -fx-border-color: transparent " + edge + " transparent transparent;");
        rule(css, P + ".panel-active .panel-title-label, " + P + ".panel-active .panel-rail-label",
                "-fx-text-fill: " + ink + ";");
        rule(css, P + ".panel-active .panel-title-button:hover",
                "-fx-background-color: " + hover + ";");
    }

    private static void editor(StringBuilder css, Color c) {
        String bg = hex(c);
        String tabs = "." + Dim.Editor.TAB_PANE_CLASS;
        rule(css, P + ".tab-pane" + tabs + ", "
                + P + tabs + " .tab-content-area, "
                + P + tabs + " .code-area",
                "-fx-background-color: " + bg + ";");
        // A plain-text tab (TextArea) has no syntax colours: flip its text.
        rule(css, P + tabs + " .text-area",
                "-fx-control-inner-background: " + bg + ";"
                        + " -fx-text-fill: " + hex(CustomLayoutConfig.ink(c)) + ";");
    }

    private static void directory(StringBuilder css, Color c) {
        String bg = hex(c);
        String ink = hex(CustomLayoutConfig.ink(c));
        // Modena derives the rows from these looked-up colours, so the
        // selection bar and hover keep working.
        rule(css, P + ".file-explorer-body, "
                + P + ".file-explorer-body .tree-view, "
                + P + ".file-explorer-body .tree-table-view, "
                + P + ".file-explorer-body .directory-tree",
                "-fx-background-color: " + bg + ";"
                        + " -fx-control-inner-background: " + bg + ";"
                        + " -fx-control-inner-background-alt: " + bg + ";");
        rule(css, P + ".file-explorer-body .tree-view .virtual-flow, "
                + P + ".file-explorer-body .tree-table-view .virtual-flow, "
                + P + ".file-explorer-body .tree-table-view .placeholder",
                "-fx-background-color: " + bg + ";");
        rule(css, P + ".file-explorer-body .tree-cell, "
                + P + ".file-explorer-body .tree-table-row-cell > .tree-table-cell",
                "-fx-text-fill: " + ink + ";");
    }

    /**
     * The Command Window is a RichTextFX area: its background is the area's
     * own, and its text colours come from TextColourManager (see the class
     * notes), so only the surface, the caret and the error colour are here.
     */
    private static void console(StringBuilder css, Color c) {
        String bg = hex(c);
        boolean light = CustomLayoutConfig.isLight(c);
        rule(css, P + ".console-area, " + P + ".console-scroll",
                "-fx-background-color: " + bg + ";");
        rule(css, P + ".console-area .caret",
                "-fx-stroke: " + hex(CustomLayoutConfig.ink(c)) + ";");
        // The error colour is kept, in the shade that reads on this background.
        rule(css, P + ".console-area.console-error .text.console-output",
                "-fx-fill: " + (light ? "#c62828" : "#ef9a9a") + ";");
    }

    private static void variables(StringBuilder css, Color c, Color base) {
        Color ink = CustomLayoutConfig.ink(c);
        String bg = hex(c);
        String alt = hex(CustomLayoutConfig.mix(c, ink, 0.04));
        String hover = hex(CustomLayoutConfig.mix(c, ink, 0.09));
        String selected = hex(CustomLayoutConfig.mix(c, base, 0.40));
        String table = P + ".variable-explorer-table";

        rule(css, table + ", " + table + " .virtual-flow, " + table + " .corner, " + table + " .placeholder",
                "-fx-background-color: " + bg + ";"
                        + " -fx-control-inner-background: " + bg + ";"
                        + " -fx-control-inner-background-alt: " + alt + ";");
        rule(css, table + " .table-row-cell:even", "-fx-background-color: " + bg + ";");
        rule(css, table + " .table-row-cell:odd", "-fx-background-color: " + alt + ";");
        rule(css, table + " .table-row-cell:hover", "-fx-background-color: " + hover + ";");
        rule(css, table + " .table-row-cell:selected", "-fx-background-color: " + selected + ";");
        rule(css, table + " .table-cell, " + table + " .placeholder .label",
                "-fx-text-fill: " + hex(ink) + ";");
        rule(css, table + " .table-row-cell:selected .table-cell",
                "-fx-text-fill: " + hex(CustomLayoutConfig.ink(CustomLayoutConfig.mix(c, base, 0.40))) + ";");
    }

    private static void bot(StringBuilder css, Color c) {
        String bg = hex(c);
        Color ink = CustomLayoutConfig.ink(c);
        rule(css, P + ".code-bot-panel, "
                + P + ".code-bot-panel .code-bot-scroll, "
                + P + ".code-bot-panel .code-bot-scroll > .viewport, "
                + P + ".code-bot-panel .code-bot-messages, "
                + P + ".code-bot-panel .code-bot-input-area",
                "-fx-background-color: " + bg + ";");
        rule(css, P + ".code-bot-panel .code-bot-hint",
                "-fx-text-fill: " + hex(CustomLayoutConfig.mix(ink, c, 0.35)) + ";");
    }

    private static void signals(StringBuilder css, Color c) {
        rule(css, P + ".signal-explorer-body",
                "-fx-background-color: " + hex(c) + ";");
        rule(css, P + ".signal-explorer-body .label",
                "-fx-text-fill: " + hex(CustomLayoutConfig.ink(c)) + ";");
    }

    /**
     * Writes one rule, making every declaration {@code !important} unless it
     * already is. See the class notes.
     */
    private static void rule(StringBuilder css, String selector, String body) {
        StringBuilder important = new StringBuilder();
        for (String declaration : body.split(";")) {
            String d = declaration.trim();
            if (d.isEmpty()) {
                continue;
            }
            important.append(d);
            if (!d.endsWith("!important")) {
                important.append(" !important");
            }
            important.append("; ");
        }
        css.append(selector).append(" { ").append(important).append("}\n");
    }

    private static String dataUri(String css) {
        return "data:text/css;base64,"
                + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
    }

    private static String hex(Color c) {
        return CustomLayoutConfig.hex(c);
    }
}
