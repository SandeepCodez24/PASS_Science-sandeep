package ui.layout.custom;

import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

import javafx.scene.paint.Color;
import ui.UI_Main;

/**
 * What the user chose in the Custom Layout window: which panels start
 * open, each panel's body colour in the light and the dark theme, the base
 * (title-strip) colour, and the theme Custom starts in.
 *
 * <h3>Three copies</h3>
 * <ul>
 * <li><b>Factory</b> -- {@link #factory()}: everything ticked, the theme's
 * own colours, navy strips, light theme. "Reset to factory" loads it.</li>
 * <li><b>Saved</b> -- {@link #saved()}: what Apply last stored in the IDE's
 * Preferences; restored at every launch.</li>
 * <li><b>Preview</b> -- {@link #setPreview}: what the window's Preview
 * button is showing. Never stored; Apply and Cancel clear it.</li>
 * </ul>
 * <p>
 * {@link #effective()} is the one the window draws from: the preview while
 * there is one, otherwise the saved copy.
 * </p>
 *
 * <h3>Ticks mean "starts open"</h3>
 * <p>
 * An unticked panel is never removed. It starts minimised (a rail, a title
 * strip, or the editor's tab strip) and comes back by itself when it is
 * needed: the Command Window when something runs, the editor when a file
 * opens, the Variable Explorer when a run produces variables.
 * </p>
 *
 * <h3>The Signal Explorer has no tick of its own</h3>
 * <p>
 * The Signal Explorer lives inside the Variable Explorer and opens on demand
 * (Signals &gt; Set &gt; Apply). It keeps its own Light / Dark body colours
 * here, but whether it can be seen is decided by the Variable Explorer's tick:
 * {@link #isShown(Panel)} answers for {@link Panel#SIGNALS} with the
 * Variable Explorer's value, and {@link #setShown} ignores it. See
 * {@link Panel#tickOwner()}.
 * </p>
 */
public final class CustomLayoutConfig {

    /**
     * The six panels in the Custom Layout window, in its row order. Five
     * have a tick; the Signal Explorer follows the Variable Explorer's.
     */
    public enum Panel {
        EDITOR("Editor Tab", "#ffffff", "#1e1e1e", null),
        DIRECTORY("Directory Explorer", "#ffffff", "#252526", null),
        CLI("CLI", "#ffffff", "#1e1e1e", null),
        VARIABLES("Variable Explorer", "#ffffff", "#1e1e1e", null),
        CHAT_BOT("Chat Bot", "#ffffff", "#252526", null),
        SIGNALS("Signal Explorer", "#ffffff", "#252526", "VARIABLES");

        private final String label;
        private final Color factoryLight;
        private final Color factoryDark;
        /** Name of the panel whose tick this one follows; null for its own. */
        private final String tickOwnerName;

        Panel(String label, String factoryLight, String factoryDark, String tickOwnerName) {
            this.label = label;
            this.factoryLight = Color.web(factoryLight);
            this.factoryDark = Color.web(factoryDark);
            this.tickOwnerName = tickOwnerName;
        }

        /**
         * @return the panel whose tick decides this one: itself, except for
         *         the Signal Explorer, which follows the Variable Explorer
         */
        public Panel tickOwner() {
            return tickOwnerName == null ? this : Panel.valueOf(tickOwnerName);
        }

        /** @return true if this panel has a tick of its own */
        public boolean hasOwnTick() {
            return tickOwnerName == null;
        }

        /** @return the text beside the tick box */
        public String label() {
            return label;
        }

        /**
         * @param dark true for the dark theme
         * @return the theme's own body colour for this panel
         */
        public Color factoryColor(boolean dark) {
            return dark ? factoryDark : factoryLight;
        }
    }

    /** The navy every title strip uses outside Custom. */
    public static final Color FACTORY_BASE = Color.web("#004073");

    public static final String LIGHT = "light";
    public static final String DARK = "dark";

    private static final String KEY = "layout.custom.";

    private static UI_Main ide;
    private static CustomLayoutConfig saved;
    private static CustomLayoutConfig preview;

    private final Map<Panel, Boolean> shown = new EnumMap<>(Panel.class);
    private final Map<Panel, Color> light = new EnumMap<>(Panel.class);
    private final Map<Panel, Color> dark = new EnumMap<>(Panel.class);
    private Color base = FACTORY_BASE;
    private String theme = LIGHT;

    private CustomLayoutConfig() {
        for (Panel p : Panel.values()) {
            shown.put(p, Boolean.TRUE);
            light.put(p, p.factoryLight);
            dark.put(p, p.factoryDark);
        }
    }

    // =====================================================================
    // The three copies
    // =====================================================================

    /**
     * Reads the saved copy from the IDE's Preferences. Called once by
     * {@code LayoutManager.install}.
     *
     * @param ideRef the IDE controller
     */
    public static void init(UI_Main ideRef) {
        ide = ideRef;
        saved = load();
    }

    /** @return a fresh factory copy */
    public static CustomLayoutConfig factory() {
        return new CustomLayoutConfig();
    }

    /** @return the copy Apply last stored (factory if nothing was stored) */
    public static CustomLayoutConfig saved() {
        if (saved == null) {
            saved = load();
        }
        return saved;
    }

    /** @return the preview while there is one, otherwise the saved copy */
    public static CustomLayoutConfig effective() {
        return preview != null ? preview : saved();
    }

    /**
     * @param config what Preview shows, or null to drop the preview
     */
    public static void setPreview(CustomLayoutConfig config) {
        preview = config == null ? null : config.copy();
    }

    /** @return true while a preview is on screen */
    public static boolean isPreviewing() {
        return preview != null;
    }

    /**
     * Stores a copy as the saved one, in memory and in Preferences.
     *
     * @param config the values to keep
     */
    public static void save(CustomLayoutConfig config) {
        saved = config.copy();
        if (ide == null || ide.prefs == null) {
            return;
        }
        for (Panel p : Panel.values()) {
            ide.prefs.put(KEY + "show." + p.name(), String.valueOf(saved.shown.get(p)));
            ide.prefs.put(KEY + "light." + p.name(), hex(saved.light.get(p)));
            ide.prefs.put(KEY + "dark." + p.name(), hex(saved.dark.get(p)));
        }
        ide.prefs.put(KEY + "base", hex(saved.base));
        ide.prefs.put(KEY + "theme", saved.theme);
    }

    private static CustomLayoutConfig load() {
        CustomLayoutConfig c = new CustomLayoutConfig();
        if (ide == null || ide.prefs == null) {
            return c;
        }
        for (Panel p : Panel.values()) {
            c.shown.put(p, Boolean.parseBoolean(ide.prefs.get(KEY + "show." + p.name(), "true")));
            c.light.put(p, parse(ide.prefs.get(KEY + "light." + p.name(), null), p.factoryLight));
            c.dark.put(p, parse(ide.prefs.get(KEY + "dark." + p.name(), null), p.factoryDark));
        }
        c.base = parse(ide.prefs.get(KEY + "base", null), FACTORY_BASE);
        c.theme = DARK.equals(ide.prefs.get(KEY + "theme", LIGHT)) ? DARK : LIGHT;
        return c;
    }

    /** @return an independent copy */
    public CustomLayoutConfig copy() {
        CustomLayoutConfig c = new CustomLayoutConfig();
        c.shown.putAll(shown);
        c.light.putAll(light);
        c.dark.putAll(dark);
        c.base = base;
        c.theme = theme;
        return c;
    }

    // =====================================================================
    // Values
    // =====================================================================

    /**
     * @param panel a panel
     * @return true if it starts open; for the Signal Explorer, the Variable
     *         Explorer's value
     */
    public boolean isShown(Panel panel) {
        return shown.get(panel.tickOwner());
    }

    /**
     * @param panel a panel with a tick of its own; ignored for the Signal
     *              Explorer, which follows the Variable Explorer
     * @param show  true for "starts open"
     */
    public void setShown(Panel panel, boolean show) {
        if (panel.hasOwnTick()) {
            shown.put(panel, show);
        }
    }

    /**
     * @param panel a panel
     * @param darkTheme true for the dark theme's colour
     * @return the panel's body colour in that theme
     */
    public Color color(Panel panel, boolean darkTheme) {
        return darkTheme ? dark.get(panel) : light.get(panel);
    }

    public void setColor(Panel panel, boolean darkTheme, Color color) {
        if (color != null) {
            (darkTheme ? dark : light).put(panel, opaque(color));
        }
    }

    /** @return the colour of the active title strip */
    public Color base() {
        return base;
    }

    public void setBase(Color color) {
        if (color != null) {
            base = opaque(color);
        }
    }

    /** @return {@link #LIGHT} or {@link #DARK} */
    public String theme() {
        return theme;
    }

    public void setTheme(String value) {
        theme = DARK.equals(value) ? DARK : LIGHT;
    }

    // =====================================================================
    // Colour helpers
    // =====================================================================

    /**
     * @param c a colour
     * @return {@code #RRGGBB}
     */
    public static String hex(Color c) {
        return String.format(Locale.ROOT, "#%02X%02X%02X",
                (int) Math.round(c.getRed() * 255),
                (int) Math.round(c.getGreen() * 255),
                (int) Math.round(c.getBlue() * 255));
    }

    /**
     * True when dark text reads better on this colour than light text, by
     * the WCAG contrast ratio.
     *
     * @param c a background colour
     * @return true for a light background
     */
    public static boolean isLight(Color c) {
        double l = luminance(c);
        double onBlack = (l + 0.05) / 0.05;
        double onWhite = 1.05 / (l + 0.05);
        return onBlack >= onWhite;
    }

    /**
     * @param background a background colour
     * @return the readable text colour for it
     */
    public static Color ink(Color background) {
        return isLight(background) ? Color.web("#1f1f1f") : Color.web("#f0f0f0");
    }

    /**
     * @param a     first colour
     * @param b     second colour
     * @param share how much of {@code b}, 0..1
     * @return the blend
     */
    public static Color mix(Color a, Color b, double share) {
        double s = Math.max(0, Math.min(1, share));
        return new Color(
                a.getRed() + (b.getRed() - a.getRed()) * s,
                a.getGreen() + (b.getGreen() - a.getGreen()) * s,
                a.getBlue() + (b.getBlue() - a.getBlue()) * s,
                1.0);
    }

    private static double luminance(Color c) {
        return 0.2126 * channel(c.getRed()) + 0.7152 * channel(c.getGreen()) + 0.0722 * channel(c.getBlue());
    }

    private static double channel(double v) {
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    }

    private static Color opaque(Color c) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), 1.0);
    }

    private static Color parse(String web, Color fallback) {
        if (web == null || web.isBlank()) {
            return fallback;
        }
        try {
            return opaque(Color.web(web));
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }
}
