package ui.ribbon_interface.tool_groups;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import ui.design.Dim;

/**
 * One compartment of a ribbon band: a row of items with the compartment name
 * captioned along the bottom edge.
 *
 * <h3>How wide a compartment is</h3>
 * <p>
 * A compartment now has a real natural width -- the width at which every label
 * in it, and its caption, is shown in full. {@code RibbonBand} gives it
 * </p>
 *
 * <pre>
 *   max(units x unitWidth, naturalWidth)
 * </pre>
 *
 * <p>
 * so the unit ratios still decide the look on a wide window, but can never
 * squeeze a label into an ellipsis. When even the natural widths do not fit,
 * the band collapses whole compartments, right to left, into a single drop-down
 * button -- the way MATLAB's toolstrip does -- rather than shrinking text.
 * </p>
 *
 * <p>
 * The old {@code bindWidthTo(unit)} is gone: it pinned min, pref and max to the
 * unit share, which is precisely what forced "Proce..." and "Visualisati...".
 * </p>
 *
 * <h3>Items</h3>
 * <p>
 * Two row layouts are available:
 * </p>
 * <ul>
 * <li>{@link #withItems(Node...)} -- an {@link EqualColumns} row: every item
 * gets the same width, and that width is at least what the widest item needs.
 * Right for a row of similar buttons (every Home compartment).</li>
 * <li>{@link #withFittedItems(Node...)} -- a {@link FittedColumns} row: equal
 * shares while there is room, but one wide item (the Signals compare control)
 * keeps its width without dragging every other cell up to it. Used by the
 * Signals Sensors and Actuators compartments.</li>
 * </ul>
 */
public final class RibbonGroup extends VBox {

    private final String title;
    private final double units;
    private final EqualColumns itemRow = new EqualColumns(Dim.ToolBand.ITEM_SPACING);
    private final Label caption;
    private boolean faceIcon = true;

    /**
     * @param title compartment name shown in the bottom caption
     * @param units this compartment's whole-unit share of the band
     */
    public RibbonGroup(String title, int units) {
        this(title, (double) units);
    }

    /**
     * @param title compartment name shown in the bottom caption
     * @param units this compartment's share of the band; fractions are allowed
     *              so a compartment can sit on a half unit. Zero means "exactly
     *              as wide as the content", which is what a collapsed
     *              compartment's button uses.
     */
    public RibbonGroup(String title, double units) {
        this.title = title;
        this.units = Math.max(0, units);

        getStyleClass().add("ribbon-group");
        setAlignment(Pos.CENTER);
        setFillWidth(true);
        setSpacing(Dim.ToolBand.GROUP_SPACING);

        itemRow.getStyleClass().add("ribbon-group-items");
        itemRow.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        itemRow.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
        VBox.setVgrow(itemRow, Priority.ALWAYS);

        caption = new Label(title);
        caption.getStyleClass().add("ribbon-group-caption");
        caption.setMaxWidth(Double.MAX_VALUE);
        caption.setAlignment(Pos.CENTER);
        // The caption counts towards the natural width, so "Visualisation" is
        // shown in full even when its compartment holds one small button.
        caption.setMinWidth(Region.USE_PREF_SIZE);
        caption.setMinHeight(Dim.ToolBand.CAPTION_HEIGHT);
        caption.setPrefHeight(Dim.ToolBand.CAPTION_HEIGHT);

        getChildren().addAll(itemRow, caption);
    }

    /**
     * Adds items that share the compartment width equally.
     *
     * @param items the item nodes, left to right
     * @return this group, for chaining
     */
    public RibbonGroup withItems(Node... items) {
        for (Node node : items) {
            prepare(node);
            itemRow.getChildren().add(node);
        }
        return this;
    }

    /**
     * Adds items in a {@link FittedColumns} row: equal shares on a wide band,
     * but an item wider than its share (the compare control) keeps exactly
     * the width it needs while the others share the rest. The compartment's
     * natural width is the sum of its items' needs rather than
     * {@code items x widest}, so one wide control cannot triple it.
     *
     * <p>
     * Replaces any items added earlier; call it once per compartment.
     * </p>
     *
     * @param items the item nodes, left to right
     * @return this group, for chaining
     */
    public RibbonGroup withFittedItems(Node... items) {
        FittedColumns row = new FittedColumns(Dim.ToolBand.ITEM_SPACING);
        row.getStyleClass().add("ribbon-group-fitted-items");
        row.setMinHeight(Dim.ToolBand.ITEM_HEIGHT);
        row.setPrefHeight(Dim.ToolBand.ITEM_HEIGHT);
        for (Node node : items) {
            prepare(node);
            row.getChildren().add(node);
        }
        return withContent(row);
    }

    /**
     * Replaces the item row with a single custom node that fills the
     * compartment. Used by Analysis, whose content is a stack of readouts
     * rather than a row of buttons.
     *
     * @param node the node to fill the compartment
     * @return this group, for chaining
     */
    public RibbonGroup withContent(Node node) {
        prepare(node);
        itemRow.getChildren().setAll(node);
        return this;
    }

    /**
     * Makes this compartment's collapsed button show only the drop-down
     * triangle (over the caption), with no icon. Used by Views, whose icons
     * are small row glyphs that look wrong blown up to ribbon-icon size.
     *
     * @return this group, for chaining
     */
    public RibbonGroup withoutFaceIcon() {
        faceIcon = false;
        return this;
    }

    /**
     * @return false if the collapsed button should show only the triangle
     */
    public boolean showsFaceIcon() {
        return faceIcon;
    }

    /**
     * Lets an item stretch to its slot, and stops it from ever being laid out
     * narrower than its label.
     */
    private static void prepare(Node node) {
        if (node instanceof Region region) {
            region.setMaxWidth(Double.MAX_VALUE);
            region.setMinWidth(Region.USE_PREF_SIZE);
        }
        if (node instanceof Labeled labeled) {
            labeled.setMinWidth(Region.USE_PREF_SIZE);
        }
    }

    /**
     * @return the compartment name shown in the caption
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return this compartment's share of the band
     */
    public double getUnits() {
        return units;
    }

    /**
     * The width at which every label and the caption are shown in full.
     *
     * @return the natural width, snapped to the pixel grid
     */
    public double naturalWidth() {
        return snapSizeX(prefWidth(-1));
    }

    /**
     * The first icon in this compartment, used as the face of its collapsed
     * button. Walks the whole subtree, so the icon inside a split button is
     * found as readily as a plain button's graphic.
     *
     * @return the first {@link ImageView} found, or null for a compartment
     *         with no icons (Analysis)
     */
    public ImageView findIcon() {
        return findIcon(itemRow);
    }

    private static ImageView findIcon(Node node) {
        if (node instanceof ImageView view) {
            return view;
        }
        if (node instanceof Labeled labeled && labeled.getGraphic() != null) {
            ImageView found = findIcon(labeled.getGraphic());
            if (found != null) {
                return found;
            }
        }
        if (node instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                ImageView found = findIcon(child);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }
}
