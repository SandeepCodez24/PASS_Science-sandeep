package ui.ribbon_interface.tool_groups;

import java.util.List;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.layout.Pane;

/**
 * A row of ribbon items that share the width equally, but where no item is
 * ever made narrower than it needs to be, and one wide item does not widen
 * the others.
 *
 * <h3>Why not {@link EqualColumns}</h3>
 * <p>
 * {@code EqualColumns} gives every cell the width of the widest item. That is
 * right for a row of similar buttons (Home), but wrong for a row that mixes
 * plain buttons with the compare control: the compare control is far wider
 * than "Feed Real", so every cell became compare-wide and the compartment's
 * natural width tripled. That is the Sensors blow-up seen once a signal was
 * selected.
 * </p>
 *
 * <h3>The rule</h3>
 * <ol>
 * <li>Start with an equal share for every cell.</li>
 * <li>Any item that needs more than that share gets exactly what it needs.</li>
 * <li>The rest share what is left equally, repeated until stable.</li>
 * </ol>
 * <p>
 * On a wide band this is identical to equal columns. When space runs short,
 * only the wide item keeps its extra width; the plain buttons give up their
 * slack first and never shrink below their labels.
 * </p>
 *
 * <p>
 * The natural width is the sum of what the items need, not
 * {@code n x widest}, so a compartment holding a compare control stays inside
 * its unit share.
 * </p>
 */
public final class FittedColumns extends Pane {

    private final double spacing;

    /**
     * @param spacing gap between neighbouring cells
     */
    public FittedColumns(double spacing) {
        this.spacing = Math.max(0, spacing);
    }

    private double gaps(int n) {
        return (n > 1) ? spacing * (n - 1) : 0;
    }

    /** What one item needs: never less than its preferred (full-label) width. */
    private double need(Node child) {
        return snapSizeX(Math.max(child.minWidth(-1), child.prefWidth(-1)));
    }

    @Override
    protected double computePrefWidth(double height) {
        List<Node> kids = getManagedChildren();
        Insets in = getInsets();
        double total = in.getLeft() + in.getRight() + gaps(kids.size());
        for (Node child : kids) {
            total += need(child);
        }
        return total;
    }

    @Override
    protected double computeMinWidth(double height) {
        return computePrefWidth(height);
    }

    @Override
    protected double computePrefHeight(double width) {
        Insets in = getInsets();
        double tallest = 0;
        for (Node child : getManagedChildren()) {
            tallest = Math.max(tallest, child.prefHeight(-1));
        }
        return in.getTop() + in.getBottom() + tallest;
    }

    @Override
    protected void layoutChildren() {
        List<Node> kids = getManagedChildren();
        int n = kids.size();
        if (n == 0) {
            return;
        }

        Insets in = getInsets();
        double x = in.getLeft();
        double y = in.getTop();
        double height = Math.max(0, getHeight() - in.getTop() - in.getBottom());
        double available = Math.max(0,
                getWidth() - in.getLeft() - in.getRight() - gaps(n));

        double[] needs = new double[n];
        double[] widths = new double[n];
        boolean[] pinned = new boolean[n];
        for (int i = 0; i < n; i++) {
            needs[i] = need(kids.get(i));
        }

        // Water-fill: pin every item whose need exceeds the current equal
        // share, then re-share what is left among the rest until nothing
        // changes. Each pin lowers the share, so the loop re-checks.
        double rest = available;
        int open = n;
        boolean changed = true;
        while (changed && open > 0) {
            changed = false;
            double share = rest / open;
            for (int i = 0; i < n; i++) {
                if (!pinned[i] && needs[i] > share) {
                    pinned[i] = true;
                    widths[i] = needs[i];
                    rest -= needs[i];
                    open--;
                    changed = true;
                }
            }
        }
        double share = (open > 0) ? Math.max(0, rest / open) : 0;
        for (int i = 0; i < n; i++) {
            if (!pinned[i]) {
                widths[i] = share;
            }
        }

        for (int i = 0; i < n; i++) {
            double left = snapPositionX(x);
            double right = snapPositionX(x + widths[i]);
            layoutInArea(kids.get(i), left, y, right - left, height, 0,
                    HPos.CENTER, VPos.CENTER);
            x += widths[i] + spacing;
        }
    }
}
