package ui.ribbon_interface.tool_groups;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import ui.design.Dim;
import ui.design.ThemedSheetPair;
import ui.design.Typography;
import ui.design.UIScale;
import ui.editor.search.EditorSearch;
import ui.layout.FullScreenToggle;
import ui.ui_functions.tools.HomeRibbonIcons;

/**
 * Content of the Home band's Views compartment: two rectangular toggle rows
 * and one row kept free for later.
 *
 * <pre>
 *  +--------------------------+
 *  | [ic] Full Screen         |   on: "Exit Full Screen", inward-arrow icon
 *  | [ic] Search Code         |   on: the editor's find bar is showing
 *  |                          |   reserved
 *  +--------------------------+
 *             Views
 * </pre>
 *
 * <h3>The toggles follow the state, not their own clicks</h3>
 * <p>
 * Full Screen is bound to {@link FullScreenToggle#fullScreenProperty()}, so it
 * also turns off when full screen is left with Esc or F11. Search Code is bound
 * to {@link EditorSearch#openProperty()}, so it lights up when the bar is
 * opened with Ctrl+F or the right-click menu, and goes off when the bar is
 * closed with its &#x2715; or Esc. Clicking a toggle only asks for the change;
 * the selected look is then set from the real state.
 * </p>
 *
 * <h3>Width</h3>
 * <p>
 * Full Screen's label grows to "Exit Full Screen" when it is on. The row
 * reserves the width of its longest label up front, so switching never
 * changes the compartment's width and the band never shifts sideways.
 * </p>
 *
 * <h3>Look</h3>
 * <p>
 * Geometry and font are set here from {@code Dim.ToolBand.Views} and
 * {@link Typography}; colours come from
 * {@code themes/ribbon/views_light.css} and {@code views_dark.css}, attached by
 * {@link #installStylesheets(Node)}.
 * </p>
 * <ul>
 * <li><b>At rest</b> a row is just its icon and label, with no outline and no
 * fill, so it sits in the band like every other ribbon item.</li>
 * <li><b>On hover</b> the rounded rectangle appears: a hairline outline over a
 * faint fill. The same happens when the row is on.</li>
 * <li><b>On</b> is marked by a small green dot at the right end of the row,
 * shown whether or not the pointer is over it. The row reserves room for the
 * dot, so the label never runs under it.</li>
 * </ul>
 *
 * <p>
 * On a narrow window the compartment collapses like any other, but its button
 * shows only the drop-down triangle over the "Views" caption -- a row icon
 * blown up to ribbon size would look out of place there (see
 * {@link RibbonGroup#withoutFaceIcon()}). The drop-down shows both rows with
 * their icons and live state.
 * </p>
 */
public final class RibbonViews {

    // ---- Icon base names under /icons/home_icons (light; "_dark" is added) --
    public static final String IC_FULL_SCREEN = "ic_h_07_full_screen";
    public static final String IC_EXIT_FULL_SCREEN = "ic_h_08_exit_full_screen";
    public static final String IC_SEARCH_CODE = "ic_h_09_search_code";

    // ---- Style hooks (colours in views_{light,dark}.css) -------------------
    public static final String STACK_CLASS = "ribbon-views-stack";
    public static final String TOGGLE_CLASS = "ribbon-views-toggle";
    public static final String SPARE_CLASS = "ribbon-views-spare";
    public static final String ROW_CLASS = "ribbon-views-row";
    public static final String DOT_CLASS = "ribbon-views-dot";

    private static final String LABEL_FULL_SCREEN = "Full Screen";
    private static final String LABEL_EXIT_FULL_SCREEN = "Exit Full Screen";
    private static final String LABEL_SEARCH_CODE = "Search Code";

    private static final String TIP_FULL_SCREEN = "Full screen (F11)";
    private static final String TIP_EXIT_FULL_SCREEN = "Exit full screen (Esc / F11)";
    private static final String TIP_SEARCH_OPEN = "Search the code (Ctrl+F)";
    private static final String TIP_SEARCH_CLOSE = "Close the search bar (Esc)";

    private static final ThemedSheetPair COLOURS = new ThemedSheetPair(
            "/themes/ribbon/views_light.css",
            "/themes/ribbon/views_dark.css");

    private RibbonViews() {
    }

    /**
     * Builds the three rows. Called once while the Home ribbon is assembled.
     *
     * @return the node to place inside the Views compartment
     */
    public static Node buildContent() {
        Node fullScreen = withDot(fullScreenRow());
        Node searchCode = withDot(searchCodeRow());

        // The third row: kept empty for later additions, but the same height
        // as the other two so they keep their place when it is filled.
        Region spare = new Region();
        spare.getStyleClass().add(SPARE_CLASS);
        spare.setMouseTransparent(true);
        pinHeight(spare);

        VBox stack = new VBox(Dim.ToolBand.Views.ROW_SPACING, fullScreen, searchCode, spare);
        stack.getStyleClass().add(STACK_CLASS);
        stack.setAlignment(Pos.TOP_LEFT);
        stack.setFillWidth(true);
        stack.setPadding(new Insets(0, Dim.ToolBand.Views.STACK_PAD_H, 0, Dim.ToolBand.Views.STACK_PAD_H));
        return stack;
    }

    /**
     * Attaches the Views colour sheets to the main scene, once. Pass any node
     * of the main window -- the Home band's bar is the natural one. If it is
     * not in a scene yet, this waits for its first one.
     *
     * <p>
     * Deliberately not tied to the compartment itself: a collapsed
     * compartment is lent to a pop-up window, and that window's scene must
     * not receive the sheets.
     * </p>
     *
     * @param anchor a node that will live in the main scene
     */
    public static void installStylesheets(Node anchor) {
        if (anchor == null) {
            return;
        }
        if (anchor.getScene() != null) {
            COLOURS.install(anchor.getScene());
            return;
        }
        anchor.sceneProperty().addListener(new ChangeListener<Scene>() {
            @Override
            public void changed(ObservableValue<? extends Scene> obs, Scene was, Scene isNow) {
                if (isNow != null) {
                    obs.removeListener(this);
                    COLOURS.install(isNow);
                }
            }
        });
    }

    // =====================================================================
    // The two toggles
    // =====================================================================

    private static ToggleButton fullScreenRow() {
        ImageView icon = HomeRibbonIcons.icon(IC_FULL_SCREEN, Dim.ToolBand.Views.ICON_SIZE);
        ToggleButton row = row(LABEL_FULL_SCREEN, icon, LABEL_FULL_SCREEN, LABEL_EXIT_FULL_SCREEN);
        Tooltip tip = new Tooltip(TIP_FULL_SCREEN);
        row.setTooltip(tip);

        Runnable sync = () -> {
            boolean on = FullScreenToggle.isFullScreen();
            row.setSelected(on);
            row.setText(on ? LABEL_EXIT_FULL_SCREEN : LABEL_FULL_SCREEN);
            HomeRibbonIcons.setName(icon, on ? IC_EXIT_FULL_SCREEN : IC_FULL_SCREEN);
            tip.setText(on ? TIP_EXIT_FULL_SCREEN : TIP_FULL_SCREEN);
        };
        row.setOnAction(e -> {
            FullScreenToggle.toggle();
            // The stage's listener normally repaints the row; this covers the
            // case where the stage refused the change.
            sync.run();
        });
        FullScreenToggle.fullScreenProperty().addListener((obs, was, isNow) -> sync.run());
        sync.run();
        return row;
    }

    private static ToggleButton searchCodeRow() {
        ImageView icon = HomeRibbonIcons.icon(IC_SEARCH_CODE, Dim.ToolBand.Views.ICON_SIZE);
        ToggleButton row = row(LABEL_SEARCH_CODE, icon, LABEL_SEARCH_CODE);
        Tooltip tip = new Tooltip(TIP_SEARCH_OPEN);
        row.setTooltip(tip);

        Runnable sync = () -> {
            boolean on = EditorSearch.isOpen();
            row.setSelected(on);
            tip.setText(on ? TIP_SEARCH_CLOSE : TIP_SEARCH_OPEN);
        };
        row.setOnAction(e -> {
            if (EditorSearch.isOpen()) {
                EditorSearch.close();
            } else {
                // Same as Ctrl+F: searches the open file, or the root folder
                // when no file is open.
                EditorSearch.open(false);
            }
            sync.run();
        });
        EditorSearch.openProperty().addListener((obs, was, isNow) -> sync.run());
        sync.run();
        return row;
    }

    // =====================================================================
    // Shared row geometry
    // =====================================================================

    /**
     * One rectangular toggle row: icon on the left, label beside it.
     *
     * @param text      the label shown now
     * @param icon      the theme-aware icon view
     * @param allLabels every label this row can ever show; the row reserves
     *                  the width of the longest
     * @return the configured toggle
     */
    private static ToggleButton row(String text, ImageView icon, String... allLabels) {
        ToggleButton b = new ToggleButton(text, icon);
        b.getStyleClass().add(TOGGLE_CLASS);
        b.setContentDisplay(ContentDisplay.LEFT);
        b.setGraphicTextGap(Dim.ToolBand.Views.GRAPHIC_GAP);
        b.setAlignment(Pos.CENTER_LEFT);
        b.setTextAlignment(TextAlignment.LEFT);
        b.setWrapText(false);
        b.setMnemonicParsing(false);
        b.setFocusTraversable(false);
        pinHeight(b);
        b.setMaxWidth(Double.MAX_VALUE);

        // Geometry and font inline, from the design layer, so no colour sheet
        // and no Modena rule can change the row's size. Colours stay in CSS.
        // -fx-padding takes one value or four, never two.
        String v = UIScale.fmt(Dim.ToolBand.Views.PAD_V);
        String h = UIScale.fmt(Dim.ToolBand.Views.PAD_H);
        String pad = v + " " + h + " " + v + " " + h;
        String radius = UIScale.fmt(Dim.ToolBand.Views.RADIUS);
        b.setStyle("-fx-padding: " + pad + ";"
                + " -fx-background-radius: " + radius + ";"
                + " -fx-border-radius: " + radius + ";"
                + " -fx-border-width: " + UIScale.fmt(Dim.ToolBand.Views.BORDER) + ";"
                + " -fx-background-insets: 0;"
                + " " + Typography.css(Typography.Role.RIBBON_ITEM));

        reserveWidth(b, allLabels);
        return b;
    }

    /**
     * Puts the row in a holder with the green "on" dot at its right end. The
     * dot ignores the mouse, so hovering over it still hovers the row, and it
     * is shown only while the row is selected.
     */
    private static Node withDot(ToggleButton row) {
        Circle dot = new Circle(Dim.ToolBand.Views.DOT_SIZE / 2.0);
        dot.getStyleClass().add(DOT_CLASS);
        dot.setMouseTransparent(true);
        dot.visibleProperty().bind(row.selectedProperty());

        StackPane holder = new StackPane(row, dot);
        holder.getStyleClass().add(ROW_CLASS);
        holder.setMaxWidth(Double.MAX_VALUE);
        StackPane.setAlignment(row, Pos.CENTER_LEFT);
        StackPane.setAlignment(dot, Pos.CENTER_RIGHT);
        StackPane.setMargin(dot, new Insets(0, Dim.ToolBand.Views.DOT_INSET_RIGHT, 0, 0));
        pinHeight(holder);
        return holder;
    }

    private static void pinHeight(Region r) {
        r.setMinHeight(Dim.ToolBand.Views.ROW_HEIGHT);
        r.setPrefHeight(Dim.ToolBand.Views.ROW_HEIGHT);
        r.setMaxHeight(Dim.ToolBand.Views.ROW_HEIGHT);
    }

    /**
     * Sizes the row for the longest label it can show, measured in the font
     * the row actually has once CSS is applied, plus room for the "on" dot.
     * Re-measured if the font or the insets change (theme switch, scale
     * change).
     */
    private static void reserveWidth(ToggleButton b, String... labels) {
        Runnable fit = () -> {
            Text probe = new Text();
            probe.setFont(b.getFont());
            double widest = 0;
            for (String label : labels) {
                probe.setText(label);
                widest = Math.max(widest, probe.getLayoutBounds().getWidth());
            }
            Insets in = b.getInsets();
            double w = Math.ceil(in.getLeft() + in.getRight()
                    + Dim.ToolBand.Views.ICON_SIZE + Dim.ToolBand.Views.GRAPHIC_GAP
                    + widest + Dim.ToolBand.Views.WIDTH_SLACK
                    // room for the green dot, so the label never runs under it
                    + Dim.ToolBand.Views.DOT_GAP + Dim.ToolBand.Views.DOT_SIZE);
            b.setMinWidth(w);
            b.setPrefWidth(w);
        };
        b.fontProperty().addListener(obs -> fit.run());
        b.insetsProperty().addListener(obs -> fit.run());
        fit.run();
    }
}
