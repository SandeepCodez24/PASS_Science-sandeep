package language.syntax.syntax_checker;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.expression.AbsoluteValueAnalyzer;
import language.syntax.syntax_checker.expression.BracketAnalyzer;
import language.syntax.syntax_checker.expression.ExponentAnalyzer;
import language.syntax.syntax_checker.expression.OperandAdjacencyAnalyzer;
import language.syntax.syntax_checker.expression.OperatorSequenceAnalyzer;
import language.syntax.syntax_checker.statement.AssignmentAnalyzer;
import language.syntax.syntax_checker.statement.StatementTerminatorAnalyzer;
import language.syntax.syntax_checker.statement.StringLiteralAnalyzer;
import language.syntax.syntax_checker.structure.BlockHeaderAnalyzer;
import language.syntax.syntax_checker.structure.ContinuationAlignmentAnalyzer;
import language.syntax.syntax_checker.structure.IndentationAnalyzer;
import language.syntax.syntax_checker.symbols.ScriptCallAnalyzer;
import language.syntax.syntax_checker.symbols.SubscriptSuperscriptAnalyzer;
import language.syntax.syntax_checker.symbols.UndefinedVariableAnalyzer;

/**
 * The single entry point the editor, the gutter, the status bar, the runners
 * and the CLI all use.
 *
 * <h3>Layout of the checker</h3>
 *
 * <pre>
 *   syntax_checker/
 *     ErrorChecker          this facade: runs the pipeline, caches the result
 *     ErrorClassifier       findings &rarr; the four user-facing categories, Command Window text
 *     core/                 SourceModel, AbsoluteBars, Lexis, CheckContext, Rule, Findings
 *     expression/           brackets, absolute values, operators, powers, missing separators
 *     statement/            string literals, ';' rules, assignments
 *     structure/            block headers, block structure, indentation, '~~' alignment
 *     symbols/              undefined names, script calls, subscript/superscript
 * </pre>
 *
 * Every rule is an {@link Analyzer} that writes into one {@link Findings}. A
 * new rule is a new class plus one line in {@link #PIPELINE}; the facade, the
 * classifier and the UI need no change.
 *
 * <h3>Context</h3>
 * Most rules need only the text. Script calls need the file's folder, so every
 * entry point has an overload taking a {@link CheckContext}. The text-only
 * overloads check with {@link CheckContext#NONE}.
 *
 * <h3>Cost</h3>
 * The gutter asks once per visible line, the status box and the line styling
 * once per keystroke each. The whole result is cached against the text and
 * the context, so all of them share one run.
 *
 * <h3>Robustness</h3>
 * Each analyzer runs guarded. A bug in one rule is printed to the console and
 * that rule is skipped; it can never stop the others or take the editor down.
 */
public final class ErrorChecker {

    /** Every check, in the order it runs. Order does not affect results. */
    private static final List<Analyzer> PIPELINE = List.of(
            // statement
            new StringLiteralAnalyzer(),
            new StatementTerminatorAnalyzer(),
            new AssignmentAnalyzer(),
            // expression
            new BracketAnalyzer(),
            new AbsoluteValueAnalyzer(),
            new OperatorSequenceAnalyzer(),
            new OperandAdjacencyAnalyzer(),
            new ExponentAnalyzer(),
            // structure
            new BlockHeaderAnalyzer(),
            new IndentationAnalyzer(),
            new ContinuationAlignmentAnalyzer(),
            // symbols
            new UndefinedVariableAnalyzer(),
            new ScriptCallAnalyzer(),
            new SubscriptSuperscriptAnalyzer());

    private ErrorChecker() {
    }

    // =====================================================================
    // Result types
    // =====================================================================

    /** Counts and texts for the footer, the status box and the runners. */
    public static final class ErrorReport {
        private final ErrorClassifier.Classification classification;

        private ErrorReport(ErrorClassifier.Classification classification) {
            this.classification = classification;
        }

        /** @return the classified issues this report counts */
        public ErrorClassifier.Classification getClassification() {
            return classification;
        }

        /** Classified errors: one per line per category. Any error blocks a run. */
        public int getErrorCount() {
            return classification.errorCount();
        }

        /** Classified warnings. The editor currently raises none. */
        public int getWarningCount() {
            return classification.warningCount();
        }

        public int getTotalErrors() {
            return getErrorCount() + getWarningCount();
        }

        /**
         * @param category one of the four user-facing categories
         * @return how many issues of that category the file has
         */
        public int getCategoryCount(ErrorClassifier.Category category) {
            return classification.count(category);
        }

        public String toDisplayText() {
            return " Errors: " + getErrorCount() + "  Warnings: " + getWarningCount() + " ";
        }

        /** "Errors: n", "Warnings: n", a blank line, then one line per category. */
        public String toTooltipText() {
            return "Errors: " + getErrorCount() + "\nWarnings: " + getWarningCount() + "\n\n" + toCategoryText();
        }

        /** @return one "Category: count" line per category, in the classifier's order */
        public String toCategoryText() {
            StringBuilder text = new StringBuilder();
            for (ErrorClassifier.Category category : ErrorClassifier.Category.values()) {
                if (text.length() > 0) {
                    text.append('\n');
                }
                text.append(category.plural()).append(": ").append(classification.count(category));
            }
            return text.toString();
        }
    }

    /** Per-line queries for paragraph styling. */
    public static final class LineIssues {
        private final ErrorClassifier.Classification classification;
        private final Findings findings;

        private LineIssues(ErrorClassifier.Classification classification, Findings findings) {
            this.classification = classification;
            this.findings = findings;
        }

        /** True when the line should carry a red bar and the error style. */
        public boolean isErrorLine(int line) {
            return classification.isErrorLine(line);
        }

        /** True when the line should carry an amber bar and no red one. */
        public boolean isWarningLine(int line) {
            return classification.isWarningLine(line);
        }

        /** Every line carrying at least one error, for paragraph styling. */
        public Set<Integer> allErrorLines() {
            Set<Integer> lines = new HashSet<>();
            for (ErrorClassifier.Issue issue : classification.issues()) {
                if (issue.isError()) {
                    lines.add(issue.line());
                }
            }
            return Collections.unmodifiableSet(lines);
        }

        /**
         * @param line zero-based line index
         * @return the raw findings on that line, by rule
         */
        public Map<Rule, String> findings(int line) {
            return findings.on(line);
        }
    }

    /** One complete check of one text in one context. */
    record Result(SourceModel model, Findings findings, ErrorClassifier.Classification classification) {
    }

    // =====================================================================
    // Entry points
    // =====================================================================

    /** @return the full report, checked without a file context */
    public static ErrorReport analyzeErrors(String code) {
        return analyzeErrors(code, CheckContext.NONE);
    }

    /**
     * @param code    raw editor text
     * @param context the file the text belongs to
     * @return the full report
     */
    public static ErrorReport analyzeErrors(String code, CheckContext context) {
        return new ErrorReport(check(code, context).classification());
    }

    /** @return per-line queries, checked without a file context */
    public static LineIssues lineIssues(String code) {
        return lineIssues(code, CheckContext.NONE);
    }

    /**
     * @param code    raw editor text
     * @param context the file the text belongs to
     * @return per-line queries
     */
    public static LineIssues lineIssues(String code, CheckContext context) {
        Result result = check(code, context);
        return new LineIssues(result.classification(), result.findings());
    }

    /** @return errors plus warnings, checked without a file context */
    public static int countErrors(String code) {
        return countErrors(code, CheckContext.NONE);
    }

    /**
     * @param code    raw editor text
     * @param context the file the text belongs to
     * @return errors plus warnings
     */
    public static int countErrors(String code, CheckContext context) {
        return analyzeErrors(code, context).getTotalErrors();
    }

    // =====================================================================
    // Pipeline and cache
    // =====================================================================

    private static final Object CACHE_LOCK = new Object();
    private static String cachedText;
    private static String cachedContextKey;
    private static Result cachedResult;

    /**
     * Runs every analyzer once, or returns the cached result for the same
     * text and context.
     */
    static Result check(String code, CheckContext context) {
        String text = code == null ? "" : code;
        CheckContext ctx = context == null ? CheckContext.NONE : context;
        String contextKey = ctx.cacheKey();

        synchronized (CACHE_LOCK) {
            if (cachedResult != null && text.equals(cachedText) && contextKey.equals(cachedContextKey)) {
                return cachedResult;
            }
        }

        SourceModel model = SourceModel.of(text);
        Findings findings = new Findings();
        for (Analyzer analyzer : PIPELINE) {
            try {
                analyzer.analyze(model, ctx, findings);
            } catch (RuntimeException e) {
                System.err.println("[syntax-checker] " + analyzer.getClass().getSimpleName()
                        + " failed and was skipped: " + e);
                e.printStackTrace();
            }
        }
        Result result = new Result(model, findings, ErrorClassifier.fromFindings(findings));

        synchronized (CACHE_LOCK) {
            cachedText = text;
            cachedContextKey = contextKey;
            cachedResult = result;
        }
        return result;
    }
}
