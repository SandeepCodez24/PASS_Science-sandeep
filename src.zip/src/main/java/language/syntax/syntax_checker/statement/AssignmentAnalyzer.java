package language.syntax.syntax_checker.statement;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * Checks every assignment {@code =} in a file.
 *
 * <h3>Why this class exists</h3>
 * {@code OperatorSequenceAnalyzer} treats {@code =} as one more binary
 * operator, so {@code A1 = ((B+C=E)&&(A+B==C));} read as a perfectly good
 * chain of operand, operator, operand ... and passed, while the interpreter
 * rejected it. No pass enforced what an assignment actually is: <b>one</b>
 * {@code =}, at bracket depth zero, with a variable on its left and a value on
 * its right. This class owns that rule and nothing else.
 *
 * <h3>The rules</h3>
 * Each statement is checked on its own ({@code ;} at depth zero separates
 * statements, so {@code A = 1; B = 2;} is two assignments, not a chain).
 *
 * <pre>
 *   A = 5                     ok
 *   f(x = 2)                  ok      keyword argument: a name directly inside a call
 *   f(a, y = 3)               ok
 *   A1 = ((B+C=E) &amp;&amp; ...)    Syntax Error      '=' inside '(...)' that is not a call
 *   (A = 5)                   Syntax Error      same
 *   A[i = 1] = 5              Syntax Error      same, inside '[...]'
 *   f(x+1 = 2)                Syntax Error      only a bare name may take a keyword value
 *   A = B = 5                 Syntax Error      no chained assignment
 *   A+B = C                   Syntax Error      the left side is an expression
 *   5 = A                     Syntax Error      the left side is a number
 *   = 5                       Syntax Error      nothing to assign to
 *   if A = 5:                 Syntax Error      a condition compares with '=='
 *   DD = ;    DD =            Unassigned Variable Error
 * </pre>
 *
 * <h3>What this class leaves to others</h3>
 * <ul>
 * <li>{@code A^2 = 5} -- {@code ExponentAnalyzer} already reports it.</li>
 * <li>{@code f(x) = 3} -- the "assigns to a call" rule in {@code SubscriptSuperscriptAnalyzer}.</li>
 * <li>{@code function ...} and {@code class ...} headers -- their whole shape,
 * default values included, belongs to {@link BlockHeaderGrammar}.</li>
 * <li>{@code ==}, {@code !=}, {@code <=}, {@code >=} and the factorial form
 * {@code !==} are comparisons, never assignments.</li>
 * </ul>
 *
 * <p>
 * Input is {@link SourceModel}'s masked text, so an {@code =} inside a string
 * literal ({@code publish("t = 0")}) or a comment is invisible here, and a line
 * split with {@code ~~} is checked as the one statement it is. At most one
 * fault is reported per line: the first one found.
 */
public final class AssignmentAnalyzer implements Analyzer {

    /** Which of the two user-facing categories a fault belongs to. */
    private enum Kind {
        /** A malformed assignment. */
        SYNTAX,
        /** A name given an {@code =} and then no value. */
        UNASSIGNED
    }

    /** One fault on one line. Immutable. */
    private static final class Fault {
        final Kind kind;
        final String message;

        Fault(Kind kind, String message) {
            this.kind = kind;
            this.message = message;
        }
    }

    // ---- messages ----------------------------------------------------------

    static final String CHAINED =
            "Only one '=' is allowed in a statement; chained assignment (A = B = 5) is not supported";
    static final String INSIDE_BRACKETS =
            "'=' cannot be used inside %s; it assigns a value. Use '==' to compare";
    static final String BAD_KEYWORD_ARGUMENT =
            "Only a plain name may take a value inside a call, as in f(x = 2); '%s' is not a name";
    static final String IN_CONDITION =
            "'=' in the condition of '%s' assigns a value; use '==' to compare";
    static final String NO_TARGET = "'=' has nothing on its left to assign to";
    static final String NUMBER_TARGET = "Cannot assign to the number '%s'; the left of '=' must be a variable name";
    static final String STRING_TARGET = "Cannot assign to a string; the left of '=' must be a variable name";
    static final String EXPRESSION_TARGET =
            "Cannot assign to the expression '%s'; the left of '=' must be a variable name";
    static final String BRACKET_TARGET =
            "Cannot assign to '%s'; write a single name, or list several outputs as [a, b] = f(...)";
    static final String FOR_TARGET = "'for' needs a single loop variable before '=', e.g. 'for i = [1:10]:'";
    static final String UNASSIGNED = "'%s' is declared but never given a value (nothing after '=')";

    /** Longest left side quoted in a message before it is shortened. */
    private static final int QUOTE_LIMIT = 24;

    // ---- shapes ------------------------------------------------------------

    private static final Pattern NAME = Pattern.compile(BlockHeaderGrammar.IDENT);

    private static final Pattern NUMBER = Pattern.compile("\\d+(?:\\.\\d*)?(?:[eE][+-]?\\d+)?|\\.\\d+(?:[eE][+-]?\\d+)?");

    private static final String NAME_LIST =
            BlockHeaderGrammar.IDENT + "(?:\\s*,\\s*" + BlockHeaderGrammar.IDENT + ")*";

    /** {@code [a]}, {@code [a, b]}: several outputs of a call. */
    private static final Pattern SQUARE_OUTPUTS = Pattern.compile("\\[\\s*" + NAME_LIST + "\\s*\\]");

    /** {@code (a, b)}: the older multi-output form, two names or more. */
    private static final Pattern ROUND_OUTPUTS = Pattern.compile(
            "\\(\\s*" + BlockHeaderGrammar.IDENT + "(?:\\s*,\\s*" + BlockHeaderGrammar.IDENT + ")+\\s*\\)");

    /** Access modifiers that may precede a class field's name. */
    private static final Pattern FIELD_MODIFIERS = Pattern.compile("^(?:(?:private|protected)\\s+)+");

    /** Characters that make a left side an expression when they sit at depth zero. */
    private static final String EXPRESSION_CHARS = "+-*/%!&|<>";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            Fault fault = checkLine(line.masked());
            if (fault != null) {
                out.add(line.index(), fault.kind == Kind.UNASSIGNED ? Rule.UNASSIGNED : Rule.ASSIGNMENT,
                        fault.message);
            }
        }
    }

    /**
     * @param masked one masked logical line
     * @return the first fault on the line, or null
     */
    private static Fault checkLine(String masked) {
        if (masked == null || masked.indexOf('=') < 0) {
            return null;
        }
        String text = masked.trim();
        if (text.isEmpty()) {
            return null;
        }

        // ---- block headers and closers ----------------------------------
        String firstWord = BlockHeaderGrammar.firstWord(text);
        if (BlockHeaderGrammar.isCloser(firstWord)) {
            return null; // BlockHeaderAnalyzer owns everything after a closer
        }
        BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(text);
        if (header != null) {
            return checkHeader(header, text, firstWord);
        }

        // ---- ordinary statements ----------------------------------------
        for (String statement : Lexis.splitStatements(text)) {
            Fault fault = checkStatement(statement);
            if (fault != null) {
                return fault;
            }
        }
        return null;
    }

    // =====================================================================
    // Headers
    // =====================================================================

    private static Fault checkHeader(BlockHeaderGrammar.Header header, String text, String firstWord) {
        switch (header.kind()) {
            case FUNCTION, CLASS, ELSE:
                // Their shape (defaults and outputs included) is BlockHeaderGrammar's.
                return null;
            default:
                break;
        }

        String rest = stripColon(text.substring(firstWord.length()));
        Scan scan = scan(rest);
        if (scan.fault != null) {
            return scan.fault;
        }

        if (header.kind() == BlockHeaderGrammar.Kind.FOR) {
            if (scan.topLevel.isEmpty()) {
                return null; // a missing '=' is a header-shape question, not this one
            }
            if (scan.topLevel.size() > 1) {
                return syntax(CHAINED);
            }
            String variable = rest.substring(0, scan.topLevel.get(0)).trim();
            return NAME.matcher(variable).matches() ? null : syntax(FOR_TARGET);
        }

        // if / elseif / while: a condition never assigns.
        if (!scan.topLevel.isEmpty()) {
            return syntax(String.format(IN_CONDITION, header.kind().keyword()));
        }
        return null;
    }

    private static String stripColon(String text) {
        String trimmed = text.trim();
        return trimmed.endsWith(":") ? trimmed.substring(0, trimmed.length() - 1) : trimmed;
    }

    // =====================================================================
    // Statements
    // =====================================================================

    private static Fault checkStatement(String statement) {
        String text = statement.trim();
        if (text.isEmpty() || text.indexOf('=') < 0) {
            return null;
        }

        Scan scan = scan(text);
        if (scan.fault != null) {
            return scan.fault;
        }
        if (scan.topLevel.isEmpty()) {
            return null;
        }
        if (scan.topLevel.size() > 1) {
            return syntax(CHAINED);
        }

        int equals = scan.topLevel.get(0);
        String target = text.substring(0, equals).trim();
        String value = text.substring(equals + 1).trim();

        if (target.isEmpty()) {
            return syntax(NO_TARGET);
        }

        Fault targetFault = checkTarget(target);
        if (targetFault != null) {
            return targetFault;
        }

        if (value.isEmpty()) {
            return new Fault(Kind.UNASSIGNED, String.format(UNASSIGNED, quote(target)));
        }
        return null;
    }

    /**
     * @param target the trimmed text left of the statement's {@code =}
     * @return a fault when it cannot receive a value, otherwise null
     */
    private static Fault checkTarget(String target) {
        String name = FIELD_MODIFIERS.matcher(target).replaceFirst("").trim();
        if (name.isEmpty()) {
            return syntax(NO_TARGET);
        }

        char first = name.charAt(0);
        if (first == '"' || first == '\'') {
            return syntax(STRING_TARGET);
        }
        if (NUMBER.matcher(name).matches()) {
            return syntax(String.format(NUMBER_TARGET, quote(name)));
        }
        if (first == '[') {
            return SQUARE_OUTPUTS.matcher(name).matches()
                    ? null
                    : syntax(String.format(BRACKET_TARGET, quote(name)));
        }
        if (first == '(') {
            return ROUND_OUTPUTS.matcher(name).matches()
                    ? null
                    : syntax(String.format(BRACKET_TARGET, quote(name)));
        }

        // A '^' on the left is ExponentAnalyzer's "assign to a power".
        if (hasTopLevel(name, "^")) {
            return null;
        }
        if (hasTopLevel(name, EXPRESSION_CHARS)) {
            return syntax(String.format(EXPRESSION_TARGET, quote(name)));
        }
        return null;
    }

    // =====================================================================
    // Scanning
    // =====================================================================

    /** One open bracket during a scan. */
    private static final class Open {
        final char bracket;
        final boolean call;
        /** Where the current argument began: just after '(' or the last ','. */
        int argumentStart;

        Open(char bracket, boolean call, int argumentStart) {
            this.bracket = bracket;
            this.call = call;
            this.argumentStart = argumentStart;
        }
    }

    /** What one scan of a statement found. */
    private static final class Scan {
        final List<Integer> topLevel = new ArrayList<>();
        Fault fault;
    }

    /**
     * Walks a statement once, collecting every assignment {@code =} at depth
     * zero and stopping at the first {@code =} that sits inside brackets and is
     * not a keyword argument.
     */
    private static Scan scan(String s) {
        Scan result = new Scan();
        ArrayDeque<Open> stack = new ArrayDeque<>();
        int n = s.length();

        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);

            if (c == '(' || c == '[' || c == '{') {
                boolean call = c == '(' && isCallBracket(s, i);
                stack.push(new Open(c, call, i + 1));
                continue;
            }
            if (c == ')' || c == ']' || c == '}') {
                if (!stack.isEmpty()) {
                    stack.pop(); // mismatches are BracketAnalyzer's to report
                }
                continue;
            }
            if (c == ',' && !stack.isEmpty()) {
                stack.peek().argumentStart = i + 1;
                continue;
            }
            if (c != '=') {
                continue;
            }

            // ---- is this '=' part of a comparison? ------------------------
            if (i + 1 < n && s.charAt(i + 1) == '=') {
                i++; // '==' (and the tail of '!==' factorial-then-equals)
                continue;
            }
            char before = i > 0 ? s.charAt(i - 1) : ' ';
            if (before == '!' || before == '<' || before == '>' || before == '=') {
                continue; // '!=', '<=', '>='
            }

            // ---- an assignment '=' ----------------------------------------
            if (stack.isEmpty()) {
                result.topLevel.add(i);
                continue;
            }

            Open open = stack.peek();
            if (open.call) {
                String argument = s.substring(open.argumentStart, i).trim();
                if (NAME.matcher(argument).matches()) {
                    continue; // f(x = 2): a keyword argument
                }
                result.fault = syntax(String.format(BAD_KEYWORD_ARGUMENT, quote(argument)));
                return result;
            }
            result.fault = syntax(String.format(INSIDE_BRACKETS, describe(open.bracket)));
            return result;
        }
        return result;
    }

    /**
     * True when the {@code (} at {@code open} belongs to a call: a name sits
     * directly before it ({@code f(}, {@code publish (}). A keyword such as
     * {@code if (} is not a call; header keywords are removed before the scan.
     */
    private static boolean isCallBracket(String s, int open) {
        int p = open - 1;
        while (p >= 0 && Character.isWhitespace(s.charAt(p))) {
            p--;
        }
        if (p < 0) {
            return false;
        }
        if (!Lexis.isIdentPart(s.charAt(p))) {
            return false;
        }
        int start = p;
        while (start >= 0 && Lexis.isIdentPart(s.charAt(start))) {
            start--;
        }
        start++;
        // "2(" is a number before a bracket, not a call.
        return start <= p && Lexis.isIdentStart(s.charAt(start));
    }

    /** True when any of {@code chars} occurs in {@code s} at bracket depth zero. */
    private static boolean hasTopLevel(String s, String chars) {
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (depth == 0 && chars.indexOf(c) >= 0) {
                return true;
            }
        }
        return false;
    }

    private static String describe(char bracket) {
        return switch (bracket) {
            case '[' -> "'[...]'";
            case '{' -> "'{...}'";
            default -> "'(...)'";
        };
    }

    /** Shortens long source text for a message and removes the hidden styling markers. */
    private static String quote(String text) {
        String clean = text.replace("\u200C", "").replace("\u200D", "").trim();
        if (clean.length() > QUOTE_LIMIT) {
            return clean.substring(0, QUOTE_LIMIT - 3) + "...";
        }
        return clean;
    }

    private static Fault syntax(String message) {
        return new Fault(Kind.SYNTAX, message);
    }
}
