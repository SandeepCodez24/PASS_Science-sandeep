package language.syntax.syntax_checker.statement;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Reports a subscript or superscript written inside a string literal.
 *
 * <p>
 * A string holds text exactly as typed; nothing in it is converted for the
 * interpreter. A subscript or superscript is a property of a <b>name</b>, so
 * one inside quotes is a mistake:
 *
 * <pre>
 *   M = "x&#8322;";            subscript in a string    (error)
 *   M = "E = mc&#178;";        superscript in a string  (error)
 *   x&#8322; = 5;              subscript on a name      (fine)
 *   கி = "சோழ நாடு";       Tamil text in a string   (fine)
 * </pre>
 *
 * <p>
 * What counts as a subscript or superscript:
 * <ul>
 * <li>the editor's styled groups: a run of three hidden markers around the
 * text, or one marker either side of a single character (U+200D subscript,
 * U+200C superscript);</li>
 * <li>Unicode subscript and superscript characters ({@code &#8322;},
 * {@code &#178;}, {@code &#7491;} ...), while
 * {@link #FLAG_UNICODE_SCRIPT_GLYPHS} is true.</li>
 * </ul>
 * A lone U+200D or U+200C is <b>not</b> reported: Malayalam and Sanskrit text
 * uses them inside ordinary words (chillu letters, half forms).
 *
 * <p>
 * The editor no longer creates these inside quotes ({@code __}, {@code ^^},
 * {@code __{...}}, {@code ^{...}} are typed as plain text there), so this
 * catches pasted or older text. The check reads {@link SourceModel.Line#code()},
 * where literals are intact.
 */
public final class StringScriptAnalyzer implements Analyzer {

    static final String MESSAGE =
            "A subscript or superscript cannot be written inside a string (%s); "
                    + "strings hold plain text only";

    /**
     * When true, Unicode subscript / superscript characters typed or pasted
     * into a string ({@code "m²"}) are reported too. Set to false to allow
     * them as ordinary text and report only the editor's styled groups.
     */
    public static final boolean FLAG_UNICODE_SCRIPT_GLYPHS = true;

    /** Longest literal quoted in the message before it is shortened. */
    private static final int MAX_QUOTED = 24;

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            String literal = firstOffendingLiteral(line.code());
            if (literal != null) {
                out.add(line.index(), Rule.STRING_SCRIPT, String.format(MESSAGE, quote(literal)));
            }
        }
    }

    /**
     * @param code one logical line, comment removed, literals intact
     * @return the first string literal holding a sub/superscript, or null
     */
    static String firstOffendingLiteral(String code) {
        if (code == null || code.isEmpty()) {
            return null;
        }
        int n = code.length();
        int i = 0;
        while (i < n) {
            char c = code.charAt(i);
            if ((c == '"' || c == '\'') && !Lexis.isEscaped(code, i)) {
                int end = i + 1;
                while (end < n && !(code.charAt(end) == c && !Lexis.isEscaped(code, end))) {
                    end++;
                }
                int bodyEnd = Math.min(end, n);
                if (holdsScript(code, i + 1, bodyEnd)) {
                    return code.substring(i, Math.min(bodyEnd + 1, n));
                }
                i = bodyEnd + 1;
                continue;
            }
            i++;
        }
        return null;
    }

    /** True when {@code text[from, to)} holds a styled group or a script glyph. */
    static boolean holdsScript(String text, int from, int to) {
        for (int k = from; k < to; k++) {
            char c = text.charAt(k);
            if (Lexis.isMarker(c)) {
                // Three markers in a row open a multi-character group.
                if (k + 2 < to && text.charAt(k + 1) == c && text.charAt(k + 2) == c) {
                    return true;
                }
                // Marker, one ordinary character, the same marker.
                if (k + 2 < to && text.charAt(k + 2) == c && !isMark(text.charAt(k + 1))
                        && !Lexis.isMarker(text.charAt(k + 1))) {
                    return true;
                }
                continue;
            }
            if (FLAG_UNICODE_SCRIPT_GLYPHS && isScriptGlyph(c)) {
                return true;
            }
        }
        return false;
    }

    /** Unicode subscript / superscript digits and letters. */
    static boolean isScriptGlyph(char c) {
        return Lexis.isScriptPostfix(c)
                || (c >= 'ᴬ' && c <= 'ᵪ')   // modifier letters a, b, d, e ...
                || (c >= 'ᶛ' && c <= 'ᶿ')   // modifier letters c, f, z ...
                || c == 'ʰ' || c == 'ʲ' || c == 'ʳ' || c == 'ʷ' || c == 'ʸ'
                || c == 'ˡ' || c == 'ˢ' || c == 'ˣ'
                || c == 'ⱼ';                      // subscript j
    }

    /** A combining mark: the vowel signs and virama of Indic scripts. */
    private static boolean isMark(char c) {
        int type = Character.getType(c);
        return type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK;
    }

    private static String quote(String literal) {
        String visible = Lexis.visible(literal);
        if (visible.length() > MAX_QUOTED) {
            visible = visible.substring(0, MAX_QUOTED - 1) + "…";
        }
        return visible;
    }
}
