package language.syntax.syntax_checker.statement;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * What may follow a {@code ;}.
 *
 * <p>
 * {@code ;} ends a statement. Several statements may share a line
 * ({@code A = 1; B = 2;}), but a {@code ;} may never be followed directly by
 * another {@code ;} or by {@code :}, with or without spaces between:
 *
 * <pre>
 *   valid                  error
 *   A = 1;                 A = 1;;          an empty statement
 *   A = 1; B = 2;          A = 1; ;
 *   [1 2; 3 4]             if x;:           ';' before a header's ':'
 * </pre>
 *
 * A statement that ends without {@code ;} is <b>not</b> an error: its value is
 * echoed in the Command Window, which is sometimes exactly what is wanted.
 *
 * <p>
 * Runs on the masked text, so a {@code ;;} inside a string literal is text.
 */
public final class StatementTerminatorAnalyzer implements Analyzer {

    static final String DOUBLE = "';;' is an empty statement: remove the extra ';'";
    static final String BEFORE_COLON = "';' cannot be followed by ':'; remove the ';'";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = checkLine(line.masked());
            if (message != null) {
                out.add(line.index(), Rule.STATEMENT_TERMINATOR, message);
            }
        }
    }

    /**
     * @param s one masked logical line
     * @return the first fault, or null
     */
    static String checkLine(String s) {
        int n = s.length();
        for (int i = s.indexOf(';'); i >= 0 && i < n; i = s.indexOf(';', i + 1)) {
            int next = Lexis.nextNonSpace(s, i + 1);
            if (next >= n) {
                return null;
            }
            char c = s.charAt(next);
            if (c == ';') {
                return DOUBLE;
            }
            if (c == ':') {
                return BEFORE_COLON;
            }
        }
        return null;
    }
}
