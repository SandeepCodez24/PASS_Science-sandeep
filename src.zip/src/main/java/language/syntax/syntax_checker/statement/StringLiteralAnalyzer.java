package language.syntax.syntax_checker.statement;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Reports string literals that open and never close.
 *
 * <p>
 * {@code "} and {@code '} both delimit strings and each may sit inside the
 * other ({@code publish("the country 'india'")}); only the quote that opened a
 * literal closes it. A literal lives on one logical line -- one line after
 * {@code ~~} continuations are folded in -- so an unterminated quote is
 * reported on its own line and can never leak into the rest of the file.
 *
 * <p>
 * (Formerly {@code DocstringErrorAnalyzer}. Neural Code has no triple-quote
 * docstring; the old name described a rule that no longer exists.)
 */
public final class StringLiteralAnalyzer implements Analyzer {

    static final String UNTERMINATED = "String literal is never closed: add the matching quote";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (!line.isAbsorbed() && line.hasUnterminatedString()) {
                out.add(line.index(), Rule.STRING_LITERAL, UNTERMINATED);
            }
        }
    }
}
