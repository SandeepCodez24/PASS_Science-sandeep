package language.syntax.syntax_checker.core;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.function.Supplier;

/**
 * Where the text being checked lives.
 *
 * <p>
 * Almost every rule needs only the text. Script calls do not: {@code ABC;} is
 * a valid statement exactly when {@code ABC.nc} sits in the same folder as the
 * file being edited, so the checker has to know that folder. A context carries
 * it.
 *
 * <h3>Getting a context</h3>
 * <ul>
 * <li>{@link #forFile(Path)} when the caller holds the file's path (the Run
 * button, the CLI's script check, Replace in root folder).</li>
 * <li>{@link #of(Object)} when the caller holds only the editor (the gutter,
 * the status box). The editor is linked to its tab's path once, with
 * {@link #bind(Object, Supplier)}, when the tab is set up.</li>
 * <li>{@link #NONE} when nothing is known (an unsaved tab). Script calls are
 * then not recognised, so {@code ABC;} reads as an undefined name -- which is
 * also what Run would say, since an unsaved file cannot run.</li>
 * </ul>
 *
 * <h3>The search folders</h3>
 * <p>
 * A bare {@code ABC;} is also valid when {@code ABC.nc} sits in the IDE's
 * current folder or in a folder added to the path for this session, because
 * that is where the interpreter looks. The UI hands those folders over with
 * {@link #setSearchFolders(Collection)}; this package never reaches into the
 * UI for them. The file's own folder is always searched first.
 * </p>
 */
public final class CheckContext {

    /** No file: the folder and its scripts are unknown. */
    public static final CheckContext NONE = new CheckContext(null);

    /**
     * Editor (or any owner object) to the supplier of its file's path. Weak
     * keys, so a closed editor is dropped. The supplier must not hold the
     * owner strongly, or the entry can never be collected.
     */
    private static final Map<Object, Supplier<Path>> OWNERS = Collections.synchronizedMap(new WeakHashMap<>());

    /** Current folder, then the added folders, as last published by the UI. */
    private static volatile List<Path> searchFolders = List.of();

    private final Path file;

    private CheckContext(Path file) {
        this.file = file;
    }

    /**
     * @param file the file being checked, or null
     * @return its context; {@link #NONE} for null
     */
    public static CheckContext forFile(Path file) {
        if (file == null) {
            return NONE;
        }
        try {
            return new CheckContext(file.toAbsolutePath().normalize());
        } catch (RuntimeException e) {
            return NONE;
        }
    }

    /**
     * Links an editor to its file, so {@link #of(Object)} can find the
     * folder. The supplier is asked each time, so Save As is followed.
     *
     * @param owner the editor (usually the CodeArea)
     * @param file  supplies the current path; may return null while unsaved
     */
    public static void bind(Object owner, Supplier<Path> file) {
        if (owner != null && file != null) {
            OWNERS.put(owner, file);
        }
    }

    /**
     * @param owner an editor previously passed to {@link #bind}
     * @return its context; {@link #NONE} when it was never bound or is unsaved
     */
    public static CheckContext of(Object owner) {
        if (owner == null) {
            return NONE;
        }
        Supplier<Path> supplier = OWNERS.get(owner);
        if (supplier == null) {
            return NONE;
        }
        try {
            return forFile(supplier.get());
        } catch (RuntimeException e) {
            return NONE;
        }
    }

    /**
     * Sets the folders, besides the file's own, in which a bare script name is
     * found: the IDE's current folder and the folders added to the path.
     * Called by the UI whenever either changes.
     *
     * @param folders the folders, in search order; null clears them
     */
    public static void setSearchFolders(Collection<Path> folders) {
        if (folders == null || folders.isEmpty()) {
            searchFolders = List.of();
            return;
        }
        List<Path> copy = new ArrayList<>();
        for (Path folder : folders) {
            if (folder != null) {
                copy.add(folder);
            }
        }
        searchFolders = List.copyOf(copy);
    }

    /** @return the folders set by {@link #setSearchFolders}, in search order */
    public static List<Path> searchFolders() {
        return searchFolders;
    }

    /** @return the file, or null */
    public Path file() {
        return file;
    }

    /** @return the file's folder, or null */
    public Path folder() {
        return file == null ? null : file.getParent();
    }

    /** @return true when the folder is known, so script calls can be checked */
    public boolean knowsFolder() {
        return folder() != null;
    }

    /**
     * @return this file's own script name ({@code mm} for {@code mm.nc}), or
     *         null when unknown or not a {@code .nc} file
     */
    public String ownScriptName() {
        if (file == null) {
            return null;
        }
        String name = file.getFileName().toString();
        if (!name.toLowerCase(Locale.ROOT).endsWith(".nc")) {
            return null;
        }
        return name.substring(0, name.length() - ".nc".length());
    }

    /**
     * @return the scripts that can be called by bare name from this file --
     *         those in its own folder, the current folder and the added
     *         folders; empty when the file's folder is unknown
     */
    public Set<String> scripts() {
        Path own = folder();
        if (own == null) {
            return ScriptFolder.scripts(null);
        }
        List<Path> extra = searchFolders;
        if (extra.isEmpty()) {
            return ScriptFolder.scripts(own);
        }
        Set<String> all = new LinkedHashSet<>(ScriptFolder.scripts(own));
        for (Path folder : extra) {
            if (!folder.equals(own)) {
                all.addAll(ScriptFolder.scripts(folder));
            }
        }
        return Collections.unmodifiableSet(all);
    }

    /**
     * A key that changes whenever a check could give a different answer for
     * the same text: another file, or a script added to or removed from the
     * folder.
     *
     * @return the cache key
     */
    public String cacheKey() {
        if (file == null) {
            return "";
        }
        return file + "|" + scripts().hashCode();
    }
}
