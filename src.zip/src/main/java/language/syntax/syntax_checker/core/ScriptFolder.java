package language.syntax.syntax_checker.core;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@code .nc} scripts in a folder, by name, without the extension.
 *
 * <p>
 * The checker runs on every keystroke and the gutter asks once per visible
 * line, so the folder must not be read from disk each time. A listing is
 * reused for {@link #RECHECK_MS}; after that only the folder's modification
 * time is read, and the folder is listed again only when it changed (a file
 * was added, removed or renamed). On NTFS and ext4 both update the folder's
 * time.
 *
 * <p>
 * Only names that are valid Neural Code names are kept, since nothing else can
 * be called by bare name. The generated {@code cleaned_Runfile.nc} is never a
 * script.
 */
final class ScriptFolder {

    /** How long a listing is trusted before the folder's time is checked again. */
    static final long RECHECK_MS = 1000;

    private static final String GENERATED = "cleaned_runfile.nc";

    private record Entry(Set<String> names, long folderTime, long checkedAt) {
    }

    private static final Map<Path, Entry> CACHE = new ConcurrentHashMap<>();

    private ScriptFolder() {
    }

    /**
     * @param folder a folder, or null
     * @return the script names in it; empty when null or unreadable
     */
    static Set<String> scripts(Path folder) {
        if (folder == null) {
            return Set.of();
        }
        long now = System.currentTimeMillis();
        Entry entry = CACHE.get(folder);
        if (entry != null && now - entry.checkedAt() < RECHECK_MS) {
            return entry.names();
        }

        long folderTime = folderTime(folder);
        if (entry != null && folderTime == entry.folderTime()) {
            CACHE.put(folder, new Entry(entry.names(), folderTime, now));
            return entry.names();
        }

        Set<String> names = list(folder);
        CACHE.put(folder, new Entry(names, folderTime, now));
        return names;
    }

    private static long folderTime(Path folder) {
        try {
            return Files.getLastModifiedTime(folder).toMillis();
        } catch (IOException | RuntimeException e) {
            return -1;
        }
    }

    private static Set<String> list(Path folder) {
        Set<String> names = new TreeSet<>();
        if (!Files.isDirectory(folder)) {
            return Set.of();
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder, "*.nc")) {
            for (Path file : stream) {
                String fileName = file.getFileName().toString();
                if (fileName.toLowerCase(Locale.ROOT).equals(GENERATED) || !Files.isRegularFile(file)) {
                    continue;
                }
                String name = fileName.substring(0, fileName.length() - ".nc".length());
                if (Lexis.isIdentifier(name)) {
                    names.add(name);
                }
            }
        } catch (IOException | RuntimeException e) {
            // An unreadable folder simply has no scripts.
        }
        return Set.copyOf(names);
    }
}
