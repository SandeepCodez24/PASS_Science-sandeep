package language.syntax.syntax_checker.core;

/**
 * One check in the pipeline.
 *
 * <p>
 * An analyzer reads the cleaned document, may consult the file's context (its
 * folder, the scripts beside it), and records what it finds. It never throws
 * on bad input -- a half-written file is the normal case -- and it never
 * depends on another analyzer having run first. {@code ErrorChecker} guards
 * each call anyway, so a bug in one rule cannot silence the others.
 */
@FunctionalInterface
public interface Analyzer {

    /**
     * @param model   the cleaned document
     * @param context the file being checked; {@link CheckContext#NONE} when unknown
     * @param out     where faults are recorded
     */
    void analyze(SourceModel model, CheckContext context, Findings out);
}
