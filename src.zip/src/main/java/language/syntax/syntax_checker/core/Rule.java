package language.syntax.syntax_checker.core;

/**
 * Every rule the syntax checker enforces, each tied to the user-facing group
 * it is reported under.
 *
 * <p>
 * The declaration order is the order in which messages for one line are listed
 * in the gutter tooltip and the Command Window, so the most fundamental fault
 * (an unknown name, an open string) is read first.
 *
 * <p>
 * Adding a rule is three steps: a constant here, an {@link Analyzer} that
 * reports it, and one line in {@code ErrorChecker}'s pipeline. Nothing else
 * needs to know about it.
 */
public enum Rule {

    // ── Undefined Variable ───────────────────────────────────────────────
    /** A name used before anything defines it. */
    UNDEFINED_NAME(Group.UNDEFINED_VARIABLE),

    // ── Unassigned Variable ──────────────────────────────────────────────
    /** {@code DD = ;}: a name given an {@code =} and then no value. */
    UNASSIGNED(Group.UNASSIGNED_VARIABLE),

    // ── Syntax ───────────────────────────────────────────────────────────
    /** A string literal that opens and never closes. */
    STRING_LITERAL(Group.SYNTAX),
    /** {@code ;;} and {@code ;:}. */
    STATEMENT_TERMINATOR(Group.SYNTAX),
    /** Unbalanced brackets, a trailing {@code ,}, an empty statement. */
    INCOMPLETE_LINE(Group.SYNTAX),
    /** An absolute value {@code |x|} that is never closed or crosses a bracket. */
    ABSOLUTE_VALUE(Group.SYNTAX),
    /** A malformed assignment: {@code (A = 5)}, {@code A = B = 5}, {@code A+B = C}. */
    ASSIGNMENT(Group.SYNTAX),
    /** A {@code ^} with no base or no power, or a power on the left of {@code =}. */
    EXPONENT(Group.SYNTAX),
    /** Two values side by side with no operator or comma: {@code 2A}, {@code f(A B)}. */
    MISSING_SEPARATOR(Group.SYNTAX),
    /** Meaningless or invalid operators: {@code a*&#47;b}, {@code a &amp; b}, {@code a ==}. */
    OPERATOR_SEQUENCE(Group.SYNTAX),
    /** A function call on the left of {@code =}. */
    ASSIGN_TO_CALL(Group.SYNTAX),
    /** Invalid subscript/superscript usage. */
    STYLING(Group.SYNTAX),
    /** A script called the wrong way: {@code ABC()}, {@code ABC.nc}, {@code X = ABC}. */
    SCRIPT_CALL(Group.SYNTAX),
    /** A block header that is incomplete or malformed, or text after a closer. */
    BLOCK_HEADER(Group.SYNTAX),
    /** An unclosed block, an orphaned closer, a misplaced {@code else}. */
    BLOCK_STRUCTURE(Group.SYNTAX),

    // ── Indentation ──────────────────────────────────────────────────────
    /** Leading spaces of an ordinary line. */
    INDENTATION(Group.INDENTATION),
    /** Leading spaces of a {@code ~~} continuation line. */
    CONTINUATION(Group.INDENTATION);

    /** The four categories the user sees. */
    public enum Group {
        UNDEFINED_VARIABLE,
        SYNTAX,
        UNASSIGNED_VARIABLE,
        INDENTATION
    }

    private final Group group;

    Rule(Group group) {
        this.group = group;
    }

    /** @return the user-facing group this rule reports under */
    public Group group() {
        return group;
    }
}
