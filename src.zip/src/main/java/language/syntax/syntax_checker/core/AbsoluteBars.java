package language.syntax.syntax_checker.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Decides what every {@code |} on a line is.
 *
 * <h3>The language</h3>
 * A single {@code |} is <b>only</b> an absolute-value bar: {@code |x|},
 * {@code |A-B|}, and {@code ||v||} (a double absolute value). OR is written
 * {@code ||} between two values. A single {@code |} used as an operator, and
 * the made-up forms {@code &|} / {@code |&}, are errors (reported by the
 * operator check).
 *
 * <h3>How a bar is told apart</h3>
 * By position, left to right, exactly like a sign:
 * <ul>
 * <li>Where a <b>value</b> is expected -- the start of a line, after an
 * operator, {@code =}, {@code (}, {@code [}, {@code {}, {@code ,}, {@code ;},
 * {@code :}, <b>or a keyword</b> such as {@code if}, {@code while},
 * {@code return}, {@code not} -- a bar <b>opens</b> an absolute value.
 * {@code ||} there opens two.</li>
 * <li>Where an <b>operator</b> is expected, a bar <b>closes</b> the innermost
 * absolute value if it is open directly around it. Otherwise {@code ||} is
 * OR, and a lone {@code |} is left in place for the operator check to
 * reject.</li>
 * </ul>
 *
 * <h3>Absolute values nest like brackets</h3>
 * An absolute value opened inside a bracket must close inside it.
 * {@code (|x|)} is fine; {@code (|x)|} and {@code (|D/B)==B)} are errors,
 * reported here.
 *
 * <h3>What the other checks see</h3>
 * A matched pair is rewritten, in place, as {@code (} and {@code )}, so the
 * operator, power, separator and bracket checks treat {@code |x|^2} exactly
 * like {@code (x)^2}. An <b>unmatched</b> opening bar is blanked to a space
 * rather than turned into a bracket.
 *
 * <p>
 * That last point is the fix for {@code (|D/B)==B)}. The previous version
 * turned every opening bar into {@code (}, so a bar that was never closed
 * became an extra opening bracket that happened to balance the line's extra
 * closing one -- and the line passed. Blanking it leaves the line's real
 * bracket count intact, so the imbalance is reported as well.
 *
 * <p>
 * Offsets never change: every rewrite is one character for one character.
 */
public final class AbsoluteBars {

    /** One problem with an absolute value. */
    public record Fault(int column, String message) {
    }

    /** The rewritten line and what was wrong with its bars. */
    public record Resolution(String masked, List<Fault> faults) {
    }

    static final String CROSSES_BRACKET =
            "Absolute value '|' is not closed before '%c': close it inside the same bracket, as in (|x|)";
    static final String NEVER_CLOSED = "Absolute value '|' is never closed: add the matching '|'";

    private static final char ABS = 'A';

    private AbsoluteBars() {
    }

    /**
     * @param masked one masked logical line (string bodies blank, quotes kept)
     * @return the line with matched bars as {@code (} {@code )}, plus faults
     */
    public static Resolution resolve(String masked) {
        if (masked == null || masked.indexOf('|') < 0) {
            return new Resolution(masked, List.of());
        }
        char[] out = masked.toCharArray();
        int n = out.length;
        // Open groups, innermost on top: {kind, offset}, kind is ( [ { or ABS.
        Deque<int[]> stack = new ArrayDeque<>();
        List<Fault> faults = new ArrayList<>();
        boolean expectValue = true;

        int i = 0;
        while (i < n) {
            char c = out[i];

            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }

            // A string literal (its body is blank) is one value.
            if (c == '"' || c == '\'') {
                int close = i + 1;
                while (close < n && out[close] != c) {
                    close++;
                }
                i = close + 1;
                expectValue = false;
                continue;
            }

            // \var( \con( \mu ... : the wrapped name that follows is the value.
            if (c == '\\') {
                i++;
                expectValue = true;
                continue;
            }

            // Names, numbers and keywords.
            if (Lexis.isIdentStart(c) || Character.isDigit(c) || c == '.') {
                int j = i;
                while (j < n && (Lexis.isIdentPart(out[j]) || out[j] == '.')) {
                    j++;
                }
                expectValue = Lexis.KEYWORDS.contains(new String(out, i, j - i));
                i = j;
                continue;
            }

            if (c == '(' || c == '[' || c == '{') {
                stack.push(new int[] { c, i });
                expectValue = true;
                i++;
                continue;
            }

            if (c == ')' || c == ']' || c == '}') {
                if (hasRealBracket(stack)) {
                    // Every absolute value still open inside this bracket crossed it.
                    while (stack.peek()[0] == ABS) {
                        int[] bar = stack.pop();
                        out[bar[1]] = ' ';
                        faults.add(new Fault(bar[1], String.format(CROSSES_BRACKET, c)));
                    }
                    stack.pop();
                }
                // With no bracket open at all, the stray closer is the bracket
                // check's to report; open bars are left alone.
                expectValue = false;
                i++;
                continue;
            }

            if (c == '|') {
                if (expectValue) {
                    out[i] = '(';
                    stack.push(new int[] { ABS, i });
                    i++;
                    continue; // still expecting the value inside
                }
                if (!stack.isEmpty() && stack.peek()[0] == ABS) {
                    out[i] = ')';
                    stack.pop();
                    i++;
                    continue; // a closed value: an operator comes next
                }
                if (i + 1 < n && out[i + 1] == '|') {
                    i += 2; // '||' between two values is OR
                    expectValue = true;
                    continue;
                }
                // A lone '|' where an operator goes: kept for the operator check.
                i++;
                expectValue = true;
                continue;
            }

            if (c == '!') {
                char next = i + 1 < n ? out[i + 1] : ' ';
                char after = i + 2 < n ? out[i + 2] : ' ';
                boolean compound = next == '&' || next == '|' || (next == '=' && after != '=');
                if (compound) {
                    i += 2; // !& !| !=
                    expectValue = true;
                } else {
                    i++; // postfix factorial: still just after a value
                }
                continue;
            }

            // Every other operator or separator: + - * / ^ % < > = & , ; : ~
            expectValue = true;
            i++;
        }

        // Bars still open at the end of the line.
        while (!stack.isEmpty()) {
            int[] open = stack.pop();
            if (open[0] == ABS) {
                out[open[1]] = ' ';
                faults.add(new Fault(open[1], NEVER_CLOSED));
            }
        }
        faults.sort((a, b) -> Integer.compare(a.column(), b.column()));
        return new Resolution(new String(out), List.copyOf(faults));
    }

    private static boolean hasRealBracket(Deque<int[]> stack) {
        for (int[] entry : stack) {
            if (entry[0] != ABS) {
                return true;
            }
        }
        return false;
    }
}
