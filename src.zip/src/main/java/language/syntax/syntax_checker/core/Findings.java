package language.syntax.syntax_checker.core;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * What the analyzers found in one document: at most one message per line per
 * {@link Rule}.
 *
 * <p>
 * Every analyzer writes into the same instance, so there is exactly one shape
 * of result in the whole checker. Before this class each analyzer returned its
 * own type (a set of lines, a map of messages, a map of counts, a result
 * object), and the facade carried thirteen collections to hold them.
 *
 * <p>
 * The first message recorded for a line and rule wins; an analyzer that finds
 * several faults on one line reports the first, which is the one the user
 * should fix first. Messages for a line come back in {@link Rule} order.
 */
public final class Findings {

    private final Map<Integer, EnumMap<Rule, String>> byLine = new TreeMap<>();

    /**
     * Records a fault. Blank messages are ignored.
     *
     * @param line    zero-based line index
     * @param rule    the rule that was broken
     * @param message what is wrong, in words the user can act on
     */
    public void add(int line, Rule rule, String message) {
        if (line < 0 || rule == null || message == null || message.isBlank()) {
            return;
        }
        byLine.computeIfAbsent(line, k -> new EnumMap<>(Rule.class)).putIfAbsent(rule, message);
    }

    /**
     * @param line zero-based line index
     * @param rule a rule
     * @return true when that rule reported that line
     */
    public boolean has(int line, Rule rule) {
        EnumMap<Rule, String> onLine = byLine.get(line);
        return onLine != null && onLine.containsKey(rule);
    }

    /**
     * @param line zero-based line index
     * @return the line's messages by rule, in rule order; empty when clean
     */
    public Map<Rule, String> on(int line) {
        EnumMap<Rule, String> onLine = byLine.get(line);
        return onLine == null ? Map.of() : Collections.unmodifiableMap(onLine);
    }

    /** @return every line with at least one finding, ascending */
    public Set<Integer> lines() {
        return Collections.unmodifiableSet(byLine.keySet());
    }

    /** @return true when nothing was found */
    public boolean isEmpty() {
        return byLine.isEmpty();
    }
}
