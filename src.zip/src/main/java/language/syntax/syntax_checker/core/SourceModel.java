package language.syntax.syntax_checker.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The one shared view of a source file that every analyzer reads from.
 *
 * <h3>Order of operations (this order matters)</h3>
 * <ol>
 * <li><b>Continuations first.</b> A physical line whose last token is
 * {@code ~~} is folded into the following line. This happens on raw text,
 * because {@code ~~} is legal inside an open string literal -- that is how a
 * long message is split. A {@code ~~} in the middle of a line is ordinary
 * text, and so is a {@code ~~} inside a comment: a commented-out split line
 * ({@code \\ while A < B && ~~}) stays a comment and never swallows the line
 * after it.
 *
 * <p>
 * A continuation line is indented so it starts under the first character of
 * the value it continues (see {@code ContinuationAlignmentAnalyzer}). When
 * the join happens <b>inside</b> a string literal, those aligning spaces are
 * layout, not text, so they are dropped from the joined line:
 *
 * <pre>
 *   X = "I am a long ~~
 *        message";          &rarr; X = "I am a long message";
 * </pre>
 *
 * The run file needs no change for this: {@code LanguageDesignManager} already
 * trims every physical line before it writes the cleaned file.</li>
 *
 * <li><b>Strings next.</b> {@code "} and {@code '} are both delimiters and
 * each may appear inside the other; only the quote that opened a literal
 * closes it.</li>
 *
 * <li><b>Comments next.</b> {@code #} and {@code \\} begin a comment only
 * outside a literal.</li>
 *
 * <li><b>Absolute values last.</b> {@link AbsoluteBars} rewrites matched
 * {@code |...|} pairs as {@code (...)} in the masked view and records any bar
 * that is never closed or crosses a bracket.</li>
 * </ol>
 *
 * <h3>Views per line</h3>
 * {@link Line#code()} has the comment removed and literals intact.
 * {@link Line#masked()} is the same text with every string <i>body</i> blanked
 * to spaces, character for character, and absolute values resolved.
 * {@link Line#head()} is the masked view of the <b>first physical line
 * alone</b>, whose offsets match the editor's columns; it is what
 * continuation alignment is measured against.
 *
 * <h3>Line numbering</h3>
 * Indices are zero-based and match CodeArea paragraphs. A continuation group
 * is reported on the line that started it; the lines it swallowed are marked
 * {@link Line#isAbsorbed()} and carry empty text but keep their
 * {@link Line#raw()} text, so their indentation can still be checked.
 */
public final class SourceModel {

    /** The long-line continuation token, valid only as the last token on a line. */
    public static final String CONTINUATION = "~~";

    /** One editor paragraph, cleaned. */
    public static final class Line {

        private final int index;
        private final int endIndex;
        private final int ownerIndex;
        private final String raw;
        private final String code;
        private final String masked;
        private final String head;
        private final boolean unterminatedString;
        private final List<AbsoluteBars.Fault> absoluteFaults;

        private Line(int index, int endIndex, int ownerIndex, String raw, String code, String masked,
                String head, boolean unterminatedString, List<AbsoluteBars.Fault> absoluteFaults) {
            this.index = index;
            this.endIndex = endIndex;
            this.ownerIndex = ownerIndex;
            this.raw = raw;
            this.code = code;
            this.masked = masked;
            this.head = head;
            this.unterminatedString = unterminatedString;
            this.absoluteFaults = absoluteFaults;
        }

        private static Line absorbed(int index, int owner, String raw) {
            return new Line(index, index, owner, raw, "", "", "", false, List.of());
        }

        /** Zero-based index of this line, matching the CodeArea paragraph. */
        public int index() {
            return index;
        }

        /** Index of the last physical line folded into this one. */
        public int endIndex() {
            return endIndex;
        }

        /** True when this physical line was folded into an earlier one. */
        public boolean isAbsorbed() {
            return ownerIndex >= 0;
        }

        /** The line that swallowed this one, or -1. */
        public int ownerIndex() {
            return ownerIndex;
        }

        /** True when this line continues onto at least one following line. */
        public boolean isContinued() {
            return endIndex > index;
        }

        /** The untouched physical line. */
        public String raw() {
            return raw;
        }

        /** Continuations joined and comment removed; string literals intact. */
        public String code() {
            return code;
        }

        /** As {@link #code()}, string bodies blanked and absolute values resolved. */
        public String masked() {
            return masked;
        }

        /**
         * The masked first physical line on its own (the {@code ~~} removed),
         * with offsets equal to editor columns. Equal to {@link #masked()} for
         * a line that does not continue.
         */
        public String head() {
            return head;
        }

        /** True when a quote opened on this line and never closed. */
        public boolean hasUnterminatedString() {
            return unterminatedString;
        }

        /** Absolute values on this line that are never closed or cross a bracket. */
        public List<AbsoluteBars.Fault> absoluteFaults() {
            return absoluteFaults;
        }

        /** True when nothing but whitespace survives cleaning. */
        public boolean isBlank() {
            return masked.trim().isEmpty();
        }
    }

    private final List<Line> lines;

    private SourceModel(List<Line> lines) {
        this.lines = Collections.unmodifiableList(lines);
    }

    private static final Object CACHE_LOCK = new Object();
    private static String cachedSource;
    private static SourceModel cachedModel;

    /**
     * Cleans a whole document. The most recent result is cached; the model is
     * immutable, so sharing it is safe.
     *
     * @param code raw editor text (may be null)
     * @return the cleaned model; never null
     */
    public static SourceModel of(String code) {
        String key = code == null ? "" : code;
        synchronized (CACHE_LOCK) {
            if (cachedModel != null && key.equals(cachedSource)) {
                return cachedModel;
            }
        }
        SourceModel model = build(key);
        synchronized (CACHE_LOCK) {
            cachedSource = key;
            cachedModel = model;
        }
        return model;
    }

    /** Every line, in order, including absorbed continuation lines. */
    public List<Line> lines() {
        return lines;
    }

    /** Number of physical lines, always equal to the editor's paragraph count. */
    public int size() {
        return lines.size();
    }

    /**
     * @param index zero-based line index
     * @return that line, or null when out of range
     */
    public Line line(int index) {
        return index >= 0 && index < lines.size() ? lines.get(index) : null;
    }

    /** The whole document in masked form, newlines preserved. */
    public String maskedDocument() {
        StringBuilder document = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) {
                document.append('\n');
            }
            document.append(lines.get(i).masked());
        }
        return document.toString();
    }

    // ─────────────────────────────────────────────────────────────────────
    // Building
    // ─────────────────────────────────────────────────────────────────────

    private static SourceModel build(String code) {
        List<Line> built = new ArrayList<>();
        if (code.isEmpty()) {
            return new SourceModel(built);
        }

        String[] raw = code.split("\\R", -1);
        Line[] result = new Line[raw.length];

        int i = 0;
        while (i < raw.length) {
            int start = i;
            int end = i;
            StringBuilder joined = new StringBuilder();
            String firstSegment = null;

            while (true) {
                String current = raw[end];
                String trimmed = stripTrailingWhitespace(current);
                // Inside an open literal the next line's leading spaces are
                // alignment, not text.
                String piece = end > start && isInsideString(joined) ? current.stripLeading() : current;

                // A '~~' inside a comment is part of the comment, not a
                // continuation: a commented-out split line ('\\ while ... ~~')
                // must not swallow the next line.
                boolean continues = trimmed.endsWith(CONTINUATION) && end + 1 < raw.length
                        && !endsInComment(joined + stripTrailingWhitespace(piece));

                if (!continues) {
                    joined.append(piece);
                    break;
                }
                String withoutMarker = piece.substring(0, piece.length()
                        - (current.length() - trimmed.length()) - CONTINUATION.length());
                if (firstSegment == null) {
                    firstSegment = withoutMarker;
                }
                joined.append(withoutMarker);
                end++;
            }

            Cleaned cleaned = clean(joined.toString());
            String head = firstSegment == null ? cleaned.masked : clean(firstSegment).masked;
            result[start] = new Line(start, end, -1, raw[start], cleaned.code, cleaned.masked,
                    head, cleaned.unterminatedString, cleaned.absoluteFaults);
            for (int absorbed = start + 1; absorbed <= end; absorbed++) {
                result[absorbed] = Line.absorbed(absorbed, start, raw[absorbed]);
            }
            i = end + 1;
        }

        Collections.addAll(built, result);
        return new SourceModel(built);
    }

    private record Cleaned(String code, String masked, boolean unterminatedString,
            List<AbsoluteBars.Fault> absoluteFaults) {
    }

    /**
     * One left-to-right pass producing both views at once, so they cannot
     * disagree about where a string starts.
     */
    private static Cleaned clean(String text) {
        StringBuilder masked = new StringBuilder(text.length());
        char openQuote = 0;
        int commentAt = -1;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            if (openQuote != 0) {
                if (ch == openQuote && !Lexis.isEscaped(text, i)) {
                    openQuote = 0;
                    masked.append(ch);
                } else {
                    masked.append(' ');
                }
                continue;
            }
            if ((ch == '"' || ch == '\'') && !Lexis.isEscaped(text, i)) {
                openQuote = ch;
                masked.append(ch);
                continue;
            }
            if (ch == '#' || (ch == '\\' && i + 1 < text.length() && text.charAt(i + 1) == '\\')) {
                commentAt = i;
                break;
            }
            masked.append(ch);
        }

        String code = commentAt >= 0 ? text.substring(0, commentAt) : text;
        AbsoluteBars.Resolution bars = AbsoluteBars.resolve(masked.toString());
        return new Cleaned(code, bars.masked(), openQuote != 0, bars.faults());
    }

    /** True when a string literal is still open at the end of {@code text}. */
    private static boolean isInsideString(CharSequence text) {
        return scanEnd(text.toString()) == END_IN_STRING;
    }

    /** True when the end of {@code text} lies inside a {@code #} or {@code \\} comment. */
    private static boolean endsInComment(String text) {
        return scanEnd(text) == END_IN_COMMENT;
    }

    private static final int END_IN_CODE = 0;
    private static final int END_IN_STRING = 1;
    private static final int END_IN_COMMENT = 2;

    /**
     * Where the end of {@code text} lies: in code, inside a string literal, or
     * inside a comment. A comment runs to the end of the text, and its markers
     * count only outside a literal.
     */
    private static int scanEnd(String s) {
        char openQuote = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (openQuote != 0) {
                if (ch == openQuote && !Lexis.isEscaped(s, i)) {
                    openQuote = 0;
                }
                continue;
            }
            if ((ch == '"' || ch == '\'') && !Lexis.isEscaped(s, i)) {
                openQuote = ch;
                continue;
            }
            if (ch == '#' || (ch == '\\' && i + 1 < s.length() && s.charAt(i + 1) == '\\')) {
                return END_IN_COMMENT;
            }
        }
        return openQuote != 0 ? END_IN_STRING : END_IN_CODE;
    }

    private static String stripTrailingWhitespace(String text) {
        int end = text.length();
        while (end > 0 && Character.isWhitespace(text.charAt(end - 1))) {
            end--;
        }
        return text.substring(0, end);
    }
}
