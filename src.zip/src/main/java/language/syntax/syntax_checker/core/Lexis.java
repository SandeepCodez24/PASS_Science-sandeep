package language.syntax.syntax_checker.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * The lexical facts every check agrees on: what a name is made of, which words
 * are keywords, where a statement's assignment is.
 *
 * <p>
 * These used to be scattered: the identifier rules lived in
 * {@code OperandAdjacencyAnalyzer} and were borrowed by three other classes,
 * {@code assignmentIndex} lived in {@code ExponentSyntaxAnalyzer}, three
 * analyzers each had their own keyword list, and four had their own
 * statement splitter. A difference between any two copies was a bug the user
 * could see, so there is now one copy, here.
 */
public final class Lexis {

    private Lexis() {
    }

    /**
     * Words after which a <b>value</b> is expected: an operator straight after
     * one has nothing on its left, a {@code |} straight after one opens an
     * absolute value, and a value next to one is not "two values side by
     * side". {@code true}, {@code false} and {@code null} are values, not
     * keywords, and {@code publish} is a call, so none of them is here.
     */
    public static final Set<String> KEYWORDS = Set.of(
            "if", "elseif", "elif", "else", "for", "while", "return", "break", "continue",
            "and", "or", "not", "is_in", "is_not_in", "in", "new", "clear", "let",
            "function", "class", "private", "protected", "abstract", "reversible",
            "require", "ensure", "loop",
            "iend", "wend", "fend", "fnend", "csend", "end", "endif", "endfor", "endwhile");

    // ─────────────────────────────────────────────────────────────────────
    // Character classes
    // ─────────────────────────────────────────────────────────────────────

    /** Hidden subscript (U+200D) / superscript (U+200C) styling markers. */
    public static boolean isMarker(char c) {
        return c == '\u200D' || c == '\u200C';
    }

    /** Unicode superscript / subscript digits and letters that attach to a value. */
    public static boolean isScriptPostfix(char c) {
        return c == '\u00B2' || c == '\u00B3' || c == '\u00B9' || (c >= '\u2070' && c <= '\u209F');
    }

    /** First character of a name: any letter (any script), {@code _}, or a styling marker. */
    public static boolean isIdentStart(char c) {
        return Character.isLetter(c) || c == '_' || isMarker(c);
    }

    /**
     * Any later character of a name. Combining marks are needed for Tamil,
     * Malayalam and Telugu consonant-vowel forms.
     */
    public static boolean isIdentPart(char c) {
        if (Character.isLetterOrDigit(c) || c == '_' || isMarker(c) || isScriptPostfix(c)) {
            return true;
        }
        int type = Character.getType(c);
        return type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK;
    }

    /**
     * @param text a candidate name
     * @return true when the whole text is one name
     */
    public static boolean isIdentifier(String text) {
        if (text == null || text.isEmpty() || !isIdentStart(text.charAt(0))) {
            return false;
        }
        for (int i = 1; i < text.length(); i++) {
            if (!isIdentPart(text.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param text  the text to inspect
     * @param index position of the character in question
     * @return true when an odd number of backslashes immediately precede it
     */
    public static boolean isEscaped(String text, int index) {
        int count = 0;
        for (int i = index - 1; i >= 0 && text.charAt(i) == '\\'; i--) {
            count++;
        }
        return count % 2 != 0;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Small scanners
    // ─────────────────────────────────────────────────────────────────────

    /** @return the end offset of the name starting at {@code i} */
    public static int scanIdent(String s, int i) {
        int j = i;
        while (j < s.length() && isIdentPart(s.charAt(j))) {
            j++;
        }
        return j;
    }

    /** @return the first non-whitespace offset at or after {@code from}, or {@code s.length()} */
    public static int nextNonSpace(String s, int from) {
        int i = Math.max(0, from);
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }

    /** @return the last non-whitespace offset at or before {@code from}, or -1 */
    public static int prevNonSpace(String s, int from) {
        int i = Math.min(from, s.length() - 1);
        while (i >= 0 && Character.isWhitespace(s.charAt(i))) {
            i--;
        }
        return i;
    }

    /** @return the run of leading spaces (tabs are not counted) */
    public static int leadingSpaces(String line) {
        int count = 0;
        while (line != null && count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    /** @return true when the leading whitespace contains a tab */
    public static boolean hasLeadingTab(String line) {
        if (line == null) {
            return false;
        }
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '\t') {
                return true;
            }
            if (ch != ' ') {
                return false;
            }
        }
        return false;
    }

    /** @return the text with the hidden styling markers removed, for messages */
    public static String visible(String text) {
        return text == null ? "" : text.replace("\u200C", "").replace("\u200D", "");
    }

    /**
     * Offset of the statement's assignment {@code =} at bracket depth zero, or
     * -1. {@code ==}, {@code !=}, {@code <=} and {@code >=} are comparisons,
     * and an {@code =} inside brackets (a keyword argument) is not the
     * statement's assignment.
     *
     * @param s one masked statement or line
     * @return the offset, or -1
     */
    public static int assignmentIndex(String s) {
        int depth = 0;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == '=' && depth == 0) {
                char before = i > 0 ? s.charAt(i - 1) : ' ';
                char after = i + 1 < n ? s.charAt(i + 1) : ' ';
                if (after == '=' || before == '=' || before == '!' || before == '<' || before == '>') {
                    if (after == '=') {
                        i++;
                    }
                    continue;
                }
                return i;
            }
        }
        return -1;
    }

    /**
     * Splits a masked line on {@code ;} at bracket depth zero. The text is
     * masked, so no quote tracking is needed.
     *
     * @param line one masked logical line
     * @return the statements, untrimmed; always at least one entry
     */
    public static List<String> splitStatements(String line) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == ';' && depth == 0) {
                parts.add(line.substring(start, i));
                start = i + 1;
            }
        }
        parts.add(line.substring(start));
        return parts;
    }
}
