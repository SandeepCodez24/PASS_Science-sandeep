package language.syntax.syntax_checker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Rule;

/**
 * Regression cases for the syntax checker. Run it as a plain Java program
 * (VS Code: "Run" above {@code main}); it needs no test library.
 *
 * <p>
 * Every case is a small Neural Code snippet and what the checker must say
 * about it: nothing at all, or a fault of one particular {@link Rule} on one
 * particular line. Add a case here whenever a bug is fixed, so it can never
 * come back unnoticed.
 */
public final class SyntaxCheckSelfTest {

    private static final List<String> FAILURES = new ArrayList<>();
    private static int passed;

    private SyntaxCheckSelfTest() {
    }

    public static void main(String[] args) throws IOException {
        Path folder = Files.createTempDirectory("nc-selftest");
        Files.writeString(folder.resolve("ABC.nc"), "publish(\"abc\");\n", StandardCharsets.UTF_8);
        Path mm = folder.resolve("mm.nc");
        Files.writeString(mm, "", StandardCharsets.UTF_8);
        CheckContext inFolder = CheckContext.forFile(mm);

        absoluteValues();
        operators();
        semicolons();
        scripts(inFolder);
        continuations();
        blocks();

        System.out.println();
        System.out.println(passed + " passed, " + FAILURES.size() + " failed");
        FAILURES.forEach(f -> System.out.println("  FAIL " + f));
        if (!FAILURES.isEmpty()) {
            System.exit(1);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Cases
    // ─────────────────────────────────────────────────────────────────────

    private static final String VARS = "A = 1; B = 2; D = 3; H = 4; U = 5; count = 0; p1count = 1; p2count = 1;\n";

    private static void absoluteValues() {
        clean("abs simple", VARS + "X = |-5|;");
        clean("abs expression and power", VARS + "X = |A-B|^2;");
        clean("double abs", VARS + "X = ||A||;");
        clean("abs OR abs", VARS + "X = |A| || |B|;");
        clean("abs in call", VARS + "publish(|A|, ||B||);");
        clean("abs after if (screenshot line 67)", VARS + "if |U| == |U|:\n   count = count +1;\niend");
        clean("abs after if (screenshot line 75)", VARS + "if |A-B| == |B-A|:\n   count = count +1;\niend");
        clean("abs after return", "function y = f(x):\n   return |x|;\nfnend");

        fault("bar crosses ')' (item 1)", VARS + "A16 = (|D/B)==B)!&(D==|H/D));", Rule.ABSOLUTE_VALUE, 1);
        fault("bar crosses ')' (item 2)", VARS + "A16 = (|D/B)<=B+1)!&(D<=|H/D));", Rule.ABSOLUTE_VALUE, 1);
        fault("item 1 brackets are also unbalanced", VARS + "A16 = (|D/B)==B)!&(D==|H/D));", Rule.INCOMPLETE_LINE, 1);
        fault("(|x)|", VARS + "X = (|A)|;", Rule.ABSOLUTE_VALUE, 1);
        fault("never closed", VARS + "X = |A;", Rule.ABSOLUTE_VALUE, 1);
    }

    private static void operators() {
        fault("single & (item 3)", VARS + "while (1==1)&& (A==A) & p1count && p2count:\n   A = A + 1;\nwend",
                Rule.OPERATOR_SEQUENCE, 1);
        fault("single |", VARS + "X = A | B;", Rule.OPERATOR_SEQUENCE, 1);
        fault("&|", VARS + "X = A &| B;", Rule.OPERATOR_SEQUENCE, 1);
        fault("|&", VARS + "X = A |& B;", Rule.OPERATOR_SEQUENCE, 1);
        fault("dangling && in header", VARS + "while A &&:\n   A = A + 1;\nwend", Rule.OPERATOR_SEQUENCE, 1);
        clean("full logical header", VARS + "while (1==1) && (A==A) && p1count && p2count:\n   A = A + 1;\nwend");
        clean("logical operands of any kind", VARS + "X = p1count && not (A == B) || true;");
        clean("!& and !|", VARS + "X = (A==B) !& (B==D); Y = (A==B) !| (B==D);");
    }

    private static void semicolons() {
        fault(";;", VARS + "X = 1;;", Rule.STATEMENT_TERMINATOR, 1);
        fault("; ;", VARS + "X = 1; ;", Rule.STATEMENT_TERMINATOR, 1);
        fault(";:", VARS + "if A == 1;:\n   X = 1;\niend", Rule.STATEMENT_TERMINATOR, 1);
        clean("two statements on a line", VARS + "X = 1; Y = 2;");
        clean("no trailing ';' echoes, not an error", VARS + "X = 1");
        clean("';;' inside a string", VARS + "publish(\"a;;b\");");
        clean("matrix rows", VARS + "M = [1 2; 3 4];");
    }

    private static void scripts(CheckContext inFolder) {
        clean("bare script call", "ABC;", inFolder);
        clean("bare script call, no ';'", "ABC", inFolder);
        clean("function inside a script", "Y = ABC.f(2);", inFolder);
        fault("script with brackets", "ABC();", Rule.SCRIPT_CALL, 0, inFolder);
        fault("script with extension", "ABC.nc;", Rule.SCRIPT_CALL, 0, inFolder);
        fault("script as a value", "X = ABC;", Rule.SCRIPT_CALL, 0, inFolder);
        fault("script calls itself", "mm;", Rule.SCRIPT_CALL, 0, inFolder);
        fault("variable reuses a script name", "ABC = 5;\nABC;", Rule.SCRIPT_CALL, 1, inFolder);
        fault("unknown script", "XYZ;", Rule.UNDEFINED_NAME, 0, inFolder);
        fault("no folder: bare name is undefined", "ABC;", Rule.UNDEFINED_NAME, 0, CheckContext.NONE);
        clean("function of the same name defined here", "function ABC():\n   publish(1);\nfnend\nABC();",
                inFolder);
    }

    private static void continuations() {
        clean("while split under its condition",
                VARS + "while A<0 && ~~\n      B>5:\n   A = A + 1;\nwend");
        fault("while split 3 spaces in",
                VARS + "while A<0 && ~~\n   B>5:\n   A = A + 1;\nwend", Rule.CONTINUATION, 2);
        clean("string split under its first character", "M = \"I am a ~~\n     message\";");
        fault("string split misaligned", "M = \"I am a ~~\n   message\";", Rule.CONTINUATION, 1);
        clean("assignment split under its value", VARS + "T = A + B ~~\n    + D;");
        clean("call split under its first argument", VARS + "publish(\"sum:\", ~~\n        A);");
        clean("for split after '='", "for i = [1, 2, ~~\n        3]:\n   publish(i);\nfend");
        clean("commented-out split while (screenshot)",
                VARS + "\\\\ while (A+B)<D && (A-B)<D && sqrt(A)<B && ~~\n"
                        + "\\\\       A!<D && |-A|<B:\n"
                        + "\\\\    A = 100;\n"
                        + "\\\\    publish(\"passed while primitives\")\n"
                        + "\\\\ wend");
        clean("'#' comment ending in ~~", VARS + "# a note ~~\nA = 2;");
        clean("~~ inside a string still continues", "M = \"a # b ~~\n     c\";");
        clean("if split, three lines", VARS + "if A == 1 ~~\n   || B == 2 ~~\n   || D == 3:\n   A = 2;\niend");
    }

    private static void blocks() {
        String t17 = "i1 = 1;\nwhile i1 <= 2:\n   for i2 = [1:2]:\n      if i2 == 1:\n"
                + "         publish(\"while->for->if:\", i1, i2);\n      else:\n"
                + "         publish(\"while->for->else:\", i1, i2);\n      iend\n   fend\n"
                + "   i1 = i1 + 1;\nwend\n";
        clean("t17 nested loops", t17);
        fault("missing iend", VARS + "if A == 1:\n   A = 2;\n", Rule.BLOCK_STRUCTURE, 1);
        fault("missing colon", VARS + "if A == 1\n   A = 2;\niend", Rule.BLOCK_HEADER, 1);
        fault("text after closer", VARS + "if A == 1:\n   A = 2;\niend;", Rule.BLOCK_HEADER, 3);
        fault("bad indentation", VARS + "if A == 1:\n    A = 2;\niend", Rule.INDENTATION, 2);
    }

    // ─────────────────────────────────────────────────────────────────────
    // Assertions
    // ─────────────────────────────────────────────────────────────────────

    private static void clean(String name, String code) {
        clean(name, code, CheckContext.NONE);
    }

    private static void clean(String name, String code, CheckContext context) {
        ErrorChecker.LineIssues issues = ErrorChecker.lineIssues(code, context);
        if (issues.allErrorLines().isEmpty()) {
            pass(name);
        } else {
            fail(name, "expected no errors, got " + describe(code, context));
        }
    }

    private static void fault(String name, String code, Rule rule, int line) {
        fault(name, code, rule, line, CheckContext.NONE);
    }

    private static void fault(String name, String code, Rule rule, int line, CheckContext context) {
        Map<Rule, String> onLine = ErrorChecker.lineIssues(code, context).findings(line);
        if (onLine.containsKey(rule)) {
            pass(name + "  ->  " + onLine.get(rule));
        } else {
            fail(name, "expected " + rule + " on line " + line + ", got " + describe(code, context));
        }
    }

    private static String describe(String code, CheckContext context) {
        StringBuilder text = new StringBuilder();
        for (ErrorClassifier.Issue issue : ErrorClassifier.classify(code, context).issues()) {
            text.append("\n      line ").append(issue.line()).append(' ')
                    .append(issue.category().title()).append(": ").append(issue.message());
        }
        return text.length() == 0 ? "nothing" : text.toString();
    }

    private static void pass(String name) {
        passed++;
        System.out.println("  ok   " + name);
    }

    private static void fail(String name, String why) {
        FAILURES.add(name + ": " + why);
    }
}
