package language.syntax.syntax_checker;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Validates the three-space block indentation used by NC source files.
 * Line numbers returned by this class are zero-based, matching CodeArea paragraphs.
 *
 * <h3>Branch lines</h3>
 * {@code else:} and {@code elseif <condition>:} are branch continuations of the
 * enclosing {@code if} block. They do NOT open a block of their own, and they sit
 * at the SAME indentation as the {@code if} that owns them -- not one level in.
 * The body that follows a branch line is indented one level from the branch, which
 * falls out automatically because the {@code if} block stays on the stack.
 */
final class IndentationSyntaxAnalyzer {
    static final int INDENT_SIZE = 3;

    static final class Result {
        final int errorCount;
        final Set<Integer> errorLines;

        private Result(int errorCount, Set<Integer> errorLines) {
            this.errorCount = errorCount;
            this.errorLines = Collections.unmodifiableSet(errorLines);
        }
    }

    private static final class Block {
        final String opener;
        final String closer;
        final int indentation;
        final int line;
        /** Set once an {@code else:} branch has been seen for this if block. */
        boolean sawElse;

        Block(String opener, String closer, int indentation, int line) {
            this.opener = opener;
            this.closer = closer;
            this.indentation = indentation;
            this.line = line;
        }
    }

    private IndentationSyntaxAnalyzer() {
    }

    static Result analyze(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return new Result(0, errorLines);
        }

        String[] lines = code.split("\\R", -1);
        Set<Integer> docstringLines = DocstringErrorAnalyzer.findDocstringBlockLines(code);
        ArrayDeque<Block> blocks = new ArrayDeque<>();

        for (int i = 0; i < lines.length; i++) {
            if (docstringLines.contains(i)) {
                continue;
            }

            String raw = lines[i];
            String logical = SyntaxTextUtils.stripTrailingComment(raw).trim();
            if (logical.isEmpty()) {
                continue;
            }

            int indentation = countLeadingSpaces(raw);
            boolean hasLeadingTab = containsLeadingTab(raw);
            if (hasLeadingTab || indentation % INDENT_SIZE != 0) {
                errorLines.add(i);
            }

            String lowered = logical.toLowerCase();
            String firstWord = firstWord(logical);

            // ---------- branch continuation: else / elseif ----------
            if (isBranch(firstWord)) {
                Block owner = blocks.peek();

                if (owner == null || !"if".equals(owner.opener)) {
                    // A branch with no open if block above it.
                    errorLines.add(i);
                    continue;
                }

                // Branch sits level with its if, not indented past it.
                if (indentation != owner.indentation) {
                    errorLines.add(i);
                }

                // Branch headers must terminate with ':' like every other header.
                if (!lowered.endsWith(":")) {
                    errorLines.add(i);
                }

                // Nothing may follow a bare else in the same if block.
                if (owner.sawElse) {
                    errorLines.add(i);
                }

                if ("else".equals(firstWord)) {
                    // 'else' carries no condition. 'else if x:' is not NC syntax;
                    // the language spells it 'elseif x:'.
                    if (!"else:".equals(lowered)) {
                        errorLines.add(i);
                    }
                    owner.sawElse = true;
                } else {
                    // 'elseif' must carry a condition between the keyword and ':'.
                    String condition = lowered.substring(firstWord.length());
                    if (condition.endsWith(":")) {
                        condition = condition.substring(0, condition.length() - 1);
                    }
                    if (condition.trim().isEmpty()) {
                        errorLines.add(i);
                    }
                }

                // The branch does not push a block; the if block it belongs to
                // stays on the stack and keeps owning the closing 'iend'.
                continue;
            }

            // ---------- block closers ----------
            if (isCloser(firstWord)) {
                if (blocks.isEmpty()) {
                    errorLines.add(i);
                    continue;
                }

                Block block = blocks.peek();
                if (!block.closer.equals(firstWord)) {
                    errorLines.add(i);
                    continue;
                }

                if (indentation != block.indentation) {
                    errorLines.add(i);
                }
                blocks.pop();
                continue;
            }

            // ---------- ordinary statements and block openers ----------
            int expectedIndentation = blocks.isEmpty()
                    ? 0
                    : blocks.peek().indentation + INDENT_SIZE;
            if (indentation != expectedIndentation) {
                errorLines.add(i);
            }

            String closerWord = closerForOpener(firstWord, logical);
            if (closerWord != null) {
                blocks.push(new Block(firstWord, closerWord, indentation, i));
            }
        }

        // An unclosed block is reported on its opening line.
        while (!blocks.isEmpty()) {
            errorLines.add(blocks.pop().line);
        }

        return new Result(errorLines.size(), errorLines);
    }

    private static int countLeadingSpaces(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    private static boolean containsLeadingTab(String line) {
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '\t') {
                return true;
            }
            if (ch != ' ') {
                return false;
            }
        }
        return false;
    }

    private static String firstWord(String logicalLine) {
        int end = 0;
        while (end < logicalLine.length()) {
            char ch = logicalLine.charAt(end);
            if (!Character.isLetter(ch) && ch != '_') {
                break;
            }
            end++;
        }
        return logicalLine.substring(0, end).toLowerCase();
    }

    /**
     * Branch continuations of an if block. To also accept the Python spelling
     * {@code elif}, add {@code || "elif".equals(word)} here -- nothing else
     * needs to change.
     */
    private static boolean isBranch(String word) {
        return "else".equals(word) || "elseif".equals(word);
    }

    private static boolean isCloser(String word) {
        return "iend".equals(word)
                || "fend".equals(word)
                || "wend".equals(word)
                || "fnend".equals(word)
                || "csend".equals(word);
    }

    private static String closerForOpener(String word, String logicalLine) {
        if (!logicalLine.endsWith(":")) {
            return null;
        }
        return switch (word) {
            case "if" -> "iend";
            case "for" -> "fend";
            case "while" -> "wend";
            case "function" -> "fnend";
            case "class" -> "csend";
            default -> null;
        };
    }
}
