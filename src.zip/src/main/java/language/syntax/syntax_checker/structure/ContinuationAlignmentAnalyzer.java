package language.syntax.syntax_checker.structure;

import java.util.Set;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Checks where each {@code ~~} continuation line starts.
 *
 * <h3>The rule</h3>
 * A continuation line starts exactly under the first character of the value
 * its first line began, and every further continuation line of the same
 * statement starts at the same column:
 *
 * <pre>
 *   while X &lt; 0 &amp;&amp; Y &gt; 2 ~~         if A == 1 ~~
 *         &amp;&amp; Z == 3:                  || B == 2:
 *
 *   X = "I am a long ~~                Total = A + B ~~
 *        message";                             + C;
 *
 *   for i = [1, 2, ~~                  publish("sum:", ~~
 *            3, 4]:                            total);
 * </pre>
 *
 * <table>
 * <caption>Where the value begins</caption>
 * <tr><th>First line</th><th>Column</th></tr>
 * <tr><td>{@code if / elseif / while} (also {@code if not}, {@code while not})</td>
 * <td>first character after the keyword</td></tr>
 * <tr><td>{@code for i = ...}</td><td>first character after {@code =}</td></tr>
 * <tr><td>{@code return ...}</td><td>first character after the keyword</td></tr>
 * <tr><td>{@code function ...(} / {@code class ...(}</td>
 * <td>first character after the open {@code (}</td></tr>
 * <tr><td>an assignment {@code X = ...}</td><td>first character after {@code =}</td></tr>
 * <tr><td>a call {@code name(...}</td><td>first character after its {@code (}</td></tr>
 * <tr><td>anything else</td><td>one level (three spaces) in</td></tr>
 * </table>
 *
 * When the split falls <b>inside</b> a string literal, the column is the
 * first character inside the string, so a split message lines up with its own
 * text. A value that merely starts with a complete string
 * ({@code publish("sum:", ~~}) lines up with that string's opening quote.
 *
 * <p>
 * Measured on {@link SourceModel.Line#head()}, whose offsets are the
 * editor's columns. Reported as an Indentation Error on the continuation line
 * itself.
 */
public final class ContinuationAlignmentAnalyzer implements Analyzer {

    private static final Set<String> CONDITION_KEYWORDS = Set.of("if", "elseif", "while", "return");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || !line.isContinued()) {
                continue;
            }
            int anchor = anchorColumn(line.head(), Lexis.leadingSpaces(line.raw()));

            for (int k = line.index() + 1; k <= line.endIndex(); k++) {
                SourceModel.Line next = model.line(k);
                if (next == null || next.raw().isBlank()) {
                    continue;
                }
                String raw = next.raw();
                if (Lexis.hasLeadingTab(raw)) {
                    out.add(k, Rule.CONTINUATION, "Indent continuation lines with spaces, not tabs");
                    continue;
                }
                int found = Lexis.leadingSpaces(raw);
                if (found != anchor) {
                    out.add(k, Rule.CONTINUATION, "Continuation line must start under the value it continues: expected "
                            + anchor + " space(s), found " + found);
                }
            }
        }
    }

    /**
     * @param head   the masked first physical line (offsets are columns)
     * @param indent its leading spaces
     * @return the column the continuation lines must start at
     */
    static int anchorColumn(String head, int indent) {
        int fallback = indent + IndentationAnalyzer.INDENT_SIZE;
        int start = Lexis.nextNonSpace(head, 0);
        if (start >= head.length()) {
            return fallback;
        }

        // Access modifiers on a method header are not the value.
        String text = head.substring(start);
        String word = BlockHeaderGrammar.firstWord(text);
        while (word.equals("private") || word.equals("protected") || word.equals("abstract")) {
            start = Lexis.nextNonSpace(head, start + word.length());
            word = BlockHeaderGrammar.firstWord(head.substring(start));
        }

        int column;
        if (CONDITION_KEYWORDS.contains(word)) {
            column = Lexis.nextNonSpace(head, start + word.length());
        } else if (word.equals("for")) {
            int equals = Lexis.assignmentIndex(head.substring(start));
            column = equals < 0
                    ? Lexis.nextNonSpace(head, start + word.length())
                    : Lexis.nextNonSpace(head, start + equals + 1);
        } else if (word.equals("function") || word.equals("class")) {
            int open = outermostOpenRound(head, start);
            column = open < 0 ? Lexis.nextNonSpace(head, start + word.length()) : Lexis.nextNonSpace(head, open + 1);
        } else {
            int equals = Lexis.assignmentIndex(head.substring(start));
            if (equals >= 0) {
                column = Lexis.nextNonSpace(head, start + equals + 1);
            } else if (Lexis.isIdentStart(head.charAt(start)) && !Lexis.KEYWORDS.contains(word)) {
                int nameEnd = Lexis.scanIdent(head, start);
                int open = Lexis.nextNonSpace(head, nameEnd);
                column = open < head.length() && head.charAt(open) == '('
                        ? Lexis.nextNonSpace(head, open + 1)
                        : -1;
            } else {
                column = -1;
            }
        }

        if (column < 0 || column >= head.length()) {
            return fallback; // nothing on the first line to line up with
        }
        // A string split across the lines lines up with its own text, so the
        // column moves inside the opening quote. A value that merely starts
        // with a complete string ('publish("sum:", ~~') does not.
        char first = head.charAt(column);
        boolean quote = first == '"' || first == '\'';
        return quote && endsInsideString(head) ? column + 1 : column;
    }

    /**
     * True when a string literal is still open at the end of the masked head.
     * String bodies are blank in the masked text, so only delimiters remain.
     */
    private static boolean endsInsideString(String head) {
        char open = 0;
        for (int i = 0; i < head.length(); i++) {
            char c = head.charAt(i);
            if (open == 0 && (c == '"' || c == '\'')) {
                open = c;
            } else if (c == open) {
                open = 0;
            }
        }
        return open != 0;
    }

    /** The outermost {@code (} still open at the end of {@code head}, or -1. */
    private static int outermostOpenRound(String head, int from) {
        int depth = 0;
        int outermost = -1;
        for (int i = from; i < head.length(); i++) {
            char c = head.charAt(i);
            if (c == '(') {
                if (depth == 0) {
                    outermost = i;
                }
                depth++;
            } else if (c == ')') {
                depth = Math.max(0, depth - 1);
                if (depth == 0) {
                    outermost = -1;
                }
            }
        }
        return depth > 0 ? outermost : -1;
    }
}
