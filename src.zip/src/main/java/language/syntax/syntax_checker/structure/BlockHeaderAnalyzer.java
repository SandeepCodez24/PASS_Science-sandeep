package language.syntax.syntax_checker.structure;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Reports block headers that are incomplete or malformed, on the header line
 * and nowhere else.
 *
 * <p>
 * Owns every header-shape rule, so no header fault is counted twice:
 * <ul>
 * <li>the trailing {@code :} on {@code if / elseif / else / for / while /
 * function / class};</li>
 * <li>{@code if}, {@code elseif} and {@code while} carrying a condition, and
 * {@code else} carrying none;</li>
 * <li>the three accepted function shapes and the one class shape
 * ({@link BlockHeaderGrammar}).</li>
 * </ul>
 * {@link IndentationAnalyzer} opens the block even when the header is wrong,
 * so one missing colon is one error on its own line, not a cascade.
 *
 * <h3>Closing lines</h3>
 * A closer -- {@code iend}, {@code fend}, {@code wend}, {@code fnend},
 * {@code csend} -- stands alone on its line. Nothing may follow it: not a
 * statement, not a {@code ;}, not a {@code \\} comment. Only a {@code #}
 * comment is allowed.
 */
public final class BlockHeaderAnalyzer implements Analyzer {

    /** The only comment marker allowed after a closer. */
    private static final char CLOSER_COMMENT = '#';

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            // An unterminated literal makes the masked tail meaningless; the
            // string check reports that line.
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String closerFault = closerFault(line);
            if (closerFault != null) {
                out.add(line.index(), Rule.BLOCK_HEADER, closerFault);
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(line.masked());
            if (header != null && !header.isValid()) {
                out.add(line.index(), Rule.BLOCK_HEADER, header.error());
            }
        }
    }

    /**
     * @param line one logical line
     * @return a message when the line is a closer with something after it, otherwise null
     */
    private static String closerFault(SourceModel.Line line) {
        String masked = line.masked().trim();
        String word = BlockHeaderGrammar.firstWord(masked);
        if (!BlockHeaderGrammar.isCloser(word)) {
            return null;
        }

        // Code after the closer (the masked view has comments removed).
        String afterInCode = masked.substring(word.length()).trim();

        // A comment after the closer: the masked view cannot tell '#' from
        // '\\' (both are removed), so the raw line is read for that.
        String raw = line.raw().stripLeading();
        String afterInRaw = raw.length() >= word.length() ? raw.substring(word.length()).trim() : "";

        boolean clean = afterInCode.isEmpty()
                && (afterInRaw.isEmpty() || afterInRaw.charAt(0) == CLOSER_COMMENT);
        return clean ? null : "Nothing may follow '" + word + "' on its line (only a '#' comment is allowed)";
    }
}
