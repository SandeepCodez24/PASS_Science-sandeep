package language.syntax.syntax_checker.structure;

import java.util.ArrayDeque;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Block structure and the three-space indentation of every ordinary line.
 *
 * <p>
 * Two kinds of fault come out of here, under two rules:
 * <ul>
 * <li>{@link Rule#BLOCK_STRUCTURE} (a Syntax Error): an unclosed block, a
 * closer with nothing to close, an {@code else} / {@code elseif} outside an
 * {@code if}, a branch after {@code else}.</li>
 * <li>{@link Rule#INDENTATION} (an Indentation Error): the leading spaces only
 * -- a tab, a count that is not a multiple of three, or not the depth the
 * open blocks require.</li>
 * </ul>
 *
 * <h3>Branch lines</h3>
 * {@code else:} and {@code elseif <condition>:} sit level with the {@code if}
 * that owns them and open no block of their own; the {@code if} stays open and
 * keeps owning its {@code iend}.
 *
 * <h3>Recovery</h3>
 * A header opens its block even when it is malformed or missing its colon --
 * {@link BlockHeaderAnalyzer} reports that once, on the header. A closer finds
 * its own block: when inner blocks were left open, they are reported on their
 * opening lines and the matching block is closed normally, so one forgotten
 * closer is one error.
 *
 * <p>
 * Structure is read from the masked text, so a keyword or a colon inside a
 * string cannot open or close a block. {@code ~~} continuation lines are
 * {@link ContinuationAlignmentAnalyzer}'s.
 */
public final class IndentationAnalyzer implements Analyzer {

    /** Spaces per indentation level. */
    public static final int INDENT_SIZE = 3;

    private static final class Block {
        final BlockHeaderGrammar.Kind kind;
        final String closer;
        final int indentation;
        final int line;
        /** Set once an {@code else:} branch has been seen for this if block. */
        boolean sawElse;

        Block(BlockHeaderGrammar.Kind kind, int indentation, int line) {
            this.kind = kind;
            this.closer = kind.closer();
            this.indentation = indentation;
            this.line = line;
        }
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        ArrayDeque<Block> blocks = new ArrayDeque<>();

        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed()) {
                continue;
            }
            String logical = sourceLine.masked().trim();
            if (logical.isEmpty()) {
                continue;
            }

            int i = sourceLine.index();
            String raw = sourceLine.raw();
            int indentation = Lexis.leadingSpaces(raw);
            boolean tab = Lexis.hasLeadingTab(raw);
            if (tab) {
                out.add(i, Rule.INDENTATION, "Indent with spaces, not tabs (" + INDENT_SIZE + " spaces per level)");
            }

            String firstWord = BlockHeaderGrammar.firstWord(logical);
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(logical);

            // ---------- branch: else / elseif ----------
            if (header != null && header.kind().isBranch()) {
                Block owner = blocks.peek();
                if (owner == null || owner.kind != BlockHeaderGrammar.Kind.IF) {
                    out.add(i, Rule.BLOCK_STRUCTURE,
                            "'" + header.kind().keyword() + "' has no open 'if' block above it");
                    continue;
                }
                if (indentation != owner.indentation) {
                    out.add(i, Rule.INDENTATION, "'" + header.kind().keyword()
                            + "' must line up with its 'if': expected " + owner.indentation
                            + " space(s), found " + indentation);
                }
                if (owner.sawElse) {
                    out.add(i, Rule.BLOCK_STRUCTURE, "Nothing may follow 'else' in the same 'if' block");
                }
                if (header.kind() == BlockHeaderGrammar.Kind.ELSE) {
                    owner.sawElse = true;
                }
                continue;
            }

            // ---------- closers ----------
            if (BlockHeaderGrammar.isCloser(firstWord)) {
                Block match = findOpenBlock(blocks, firstWord);
                if (match == null) {
                    out.add(i, Rule.BLOCK_STRUCTURE, "'" + firstWord + "' has no open block to close");
                    continue;
                }
                while (blocks.peek() != match) {
                    reportUnclosed(blocks.pop(), out);
                }
                if (indentation != match.indentation) {
                    out.add(i, Rule.INDENTATION, "'" + firstWord + "' must line up with its '"
                            + match.kind.keyword() + "': expected " + match.indentation
                            + " space(s), found " + indentation);
                }
                blocks.pop();
                continue;
            }

            // ---------- statements and block openers ----------
            int expected = blocks.isEmpty() ? 0 : blocks.peek().indentation + INDENT_SIZE;
            if (indentation != expected) {
                out.add(i, Rule.INDENTATION, "Expected " + expected
                        + " space(s) of indentation, found " + indentation);
            }
            if (header != null && header.kind().opensBlock()) {
                blocks.push(new Block(header.kind(), indentation, i));
            }
        }

        while (!blocks.isEmpty()) {
            reportUnclosed(blocks.pop(), out);
        }
    }

    private static void reportUnclosed(Block block, Findings out) {
        out.add(block.line, Rule.BLOCK_STRUCTURE,
                "'" + block.kind.keyword() + "' block has no closing '" + block.closer + "'");
    }

    /** The innermost open block expecting {@code closer}, or null. */
    private static Block findOpenBlock(ArrayDeque<Block> blocks, String closer) {
        for (Block block : blocks) {
            if (block.closer.equals(closer)) {
                return block;
            }
        }
        return null;
    }
}
