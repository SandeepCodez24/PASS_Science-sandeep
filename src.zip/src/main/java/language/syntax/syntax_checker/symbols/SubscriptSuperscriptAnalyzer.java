package language.syntax.syntax_checker.symbols;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Subscript/superscript styling, and a call on the left of an assignment.
 *
 * <p>
 * Moved out of {@code ErrorChecker}, where it was the only check living inside
 * the facade. Two rules:
 * <ul>
 * <li>{@link Rule#ASSIGN_TO_CALL}: {@code f(x) = 3}. Only the statement's own
 * top-level {@code =} counts, so {@code sqrt(x) == 2}, {@code f(a) != b} and
 * the keyword argument in {@code f(x = 2)} are never mistaken for one, and
 * every built-in or user function behaves inside {@code publish(...)} exactly
 * as on a line of its own. {@code \var(\mu) = 2} assigns to a wrapped
 * variable, not a call.</li>
 * <li>{@link Rule#STYLING}: a function name used as the base of a styled group
 * ({@code sin_{1}}), a call carrying a styled suffix ({@code f(x)_{1}}), a
 * call inside styled content ({@code a_{sin(x)}}), an empty group
 * ({@code a_{}}).</li>
 * </ul>
 * Runs on masked text, so nothing inside a string literal or a comment can
 * trigger either rule.
 */
public final class SubscriptSuperscriptAnalyzer implements Analyzer {

    static final String ASSIGNS_TO_CALL =
            "Cannot assign to a function call; the left of '=' must be a variable name";
    static final String STYLING = "Invalid subscript/superscript usage";

    /** Identifier shape that tolerates the hidden styling markers inside a name. */
    private static final String STYLED_IDENTIFIER = "[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*";

    private static final Pattern BRACE_SUB =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*_\\{([^}]*)\\}");
    private static final Pattern BRACE_SUP =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\^\\{([^}]*)\\}");
    private static final Pattern CALL_BRACE_SUB =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)\\s*_\\{([^}]*)\\}");
    private static final Pattern CALL_BRACE_SUP =
            Pattern.compile("\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)\\s*\\^\\{([^}]*)\\}");

    /** A live styled suffix at the very end of a left-hand side, removed before the call test. */
    private static final Pattern TRAILING_STYLED_SUFFIX = Pattern.compile(
            "\\s*(?:\\u200D{1,3}[^\\u200D\\n\\r=]+\\u200D{1,3}"
                    + "|\\u200C{3}[^\\u200C\\n\\r=]+\\u200C{3})\\s*$");

    // Live marker patterns (U+200D subscript, U+200C superscript).
    private static final Pattern LIVE_SUB = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
    private static final Pattern LIVE_SUP = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");
    private static final Pattern CALL_LIVE_SUB = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)(?:\\u200D{1,3}([^\\u200D\\n\\r=]+)\\u200D{1,3})");
    private static final Pattern CALL_LIVE_SUP = Pattern.compile(
            "\\b(" + STYLED_IDENTIFIER + ")\\s*\\([^)]*\\)(?:\\u200C{3}([^\\u200C\\n\\r=]+)\\u200C{3})");

    private static final Pattern FUNCTION_CALL_SHAPE =
            Pattern.compile("\\b[A-Za-z_\\u200C\\u200D][A-Za-z0-9_\\u200C\\u200D]*\\s*\\(");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        String document = model.maskedDocument();
        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }
            String line = sourceLine.masked();
            if (assignsToCall(line)) {
                out.add(sourceLine.index(), Rule.ASSIGN_TO_CALL, ASSIGNS_TO_CALL);
            }
            if (hasStylingFault(line, document)) {
                out.add(sourceLine.index(), Rule.STYLING, STYLING);
            }
        }
    }

    private static boolean hasStylingFault(String line, String document) {
        return CALL_BRACE_SUB.matcher(line).find()
                || CALL_BRACE_SUP.matcher(line).find()
                || CALL_LIVE_SUB.matcher(line).find()
                || CALL_LIVE_SUP.matcher(line).find()
                || hasGroupFault(BRACE_SUB, line, document)
                || hasGroupFault(BRACE_SUP, line, document)
                || hasGroupFault(LIVE_SUB, line, document)
                || hasGroupFault(LIVE_SUP, line, document);
    }

    /**
     * @param masked one masked logical line
     * @return true when some statement on the line assigns to a function call
     */
    static boolean assignsToCall(String masked) {
        if (masked == null || masked.indexOf('=') < 0) {
            return false;
        }
        for (String statement : Lexis.splitStatements(masked)) {
            int assignment = Lexis.assignmentIndex(statement);
            if (assignment < 0) {
                continue;
            }
            String left = TRAILING_STYLED_SUFFIX.matcher(statement.substring(0, assignment)).replaceFirst("");
            if (endsWithCall(left)) {
                return true;
            }
        }
        return false;
    }

    /** True when {@code text} ends in {@code name(...)}, matched by depth. */
    private static boolean endsWithCall(String text) {
        int end = Lexis.prevNonSpace(text, text.length() - 1);
        if (end < 0 || text.charAt(end) != ')') {
            return false;
        }
        int depth = 0;
        int open = -1;
        for (int i = end; i >= 0; i--) {
            char c = text.charAt(i);
            if (c == ')' || c == ']' || c == '}') {
                depth++;
            } else if (c == '(' || c == '[' || c == '{') {
                depth--;
                if (depth == 0) {
                    open = i;
                    break;
                }
            }
        }
        if (open < 0 || text.charAt(open) != '(') {
            return false;
        }
        int nameEnd = Lexis.prevNonSpace(text, open - 1);
        int nameStart = nameEnd;
        while (nameStart >= 0 && Lexis.isIdentPart(text.charAt(nameStart))) {
            nameStart--;
        }
        nameStart++;
        if (nameStart > nameEnd || !Lexis.isIdentStart(text.charAt(nameStart))) {
            return false; // (a, b) = ..., 2(x) = ... : no name before the bracket
        }
        return nameStart == 0 || text.charAt(nameStart - 1) != '\\';
    }

    private static boolean hasGroupFault(Pattern pattern, String line, String document) {
        Matcher matcher = pattern.matcher(line);
        while (matcher.find()) {
            String base = matcher.group(1);
            String content = matcher.group(2);
            if (isCalledInDocument(document, base)
                    || content == null || content.trim().isEmpty()
                    || FUNCTION_CALL_SHAPE.matcher(content).find()) {
                return true;
            }
        }
        return false;
    }

    /** True when {@code name} is called anywhere in the (masked) document. */
    private static boolean isCalledInDocument(String document, String name) {
        if (document == null || name == null || name.isEmpty()) {
            return false;
        }
        return Pattern.compile("\\b" + Pattern.quote(name) + "\\s*\\(").matcher(document).find();
    }
}
