package language.syntax.syntax_checker.symbols;

import java.util.Map;

import language.replace.Uniconstant;
import language.semantic.ScriptedName;
import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Names, subscripts and superscripts; and a call on the left of an
 * assignment.
 *
 * <h3>{@link Rule#STYLING}: every name is checked the way nc.exe checks it</h3>
 * <p>
 * A subscript is written {@code A_$1}, a superscript {@code A_@2}, both
 * {@code μ_$i_@2} (see {@link ScriptedName}). Each name on the line is passed
 * to {@link ScriptedName#parse}, the Java twin of {@code nc.exe}'s
 * {@code identifier_rules.cpp}, so the editor marks exactly the names the
 * interpreter would refuse, with the same reason:
 * </p>
 * <pre>
 *   A_$ = 5;          the subscript (_$) is empty
 *   A_$1_$2 = 5;      a name can have only one subscript (_$)
 *   A_@2_$1 = 5;      write the subscript (_$) before the superscript (_@)
 *   _$1 = 5;          a subscript needs a name in front of it
 *   A₁ = 5;  x² = 4;  '₁' cannot be part of a name; write A_$1 / A_@2
 *   Α = 1;            Greek capital alpha looks like Latin A
 *   A$b = 1;          '$' can only appear in a name as _$ or _@
 *   con_x = 1;        names starting with 'con_' are reserved
 * </pre>
 * <p>
 * Outside names: a look-alike or invisible character ({@code (a+b)²}, a
 * stray zero-width joiner), a live-signal literal ({@code $Sensor1$},
 * {@code @Actuator1@} -- reserved, not available yet), a {@code $} on its own,
 * and the old styling forms ({@code A_{1}}, {@code x^{2}}, {@code x^^2}).
 * </p>
 * <p>
 * Runs on masked text, so nothing inside a string literal or a comment is
 * checked: {@code "A_$1 costs $5"} is just text. Physical constants typed as
 * symbols ({@code 𝝅}, {@code 𝑵ₐ}) are not names and are skipped.
 * </p>
 *
 * <h3>{@link Rule#ASSIGN_TO_CALL}</h3>
 * <p>
 * {@code f(x) = 3}. Only the statement's own top-level {@code =} counts, so
 * {@code sqrt(x) == 2}, {@code f(a) != b} and the keyword argument in
 * {@code f(x = 2)} are never mistaken for one.
 * </p>
 */
public final class SubscriptSuperscriptAnalyzer implements Analyzer {

    static final String ASSIGNS_TO_CALL =
            "Cannot assign to a function call; the left of '=' must be a variable name";

    static final String BAD_NAME = "'%s' is not a valid name: %s";

    static final String SENSOR_RESERVED =
            "Live sensor signals ($%s$) are reserved and not available yet";

    static final String ACTUATOR_RESERVED =
            "Live actuator signals (@%s@) are reserved and not available yet";

    static final String LONE_DOLLAR =
            "'$' can only be used as _$ after a name (A_$1 is A with subscript 1), "
                    + "or around a sensor signal name ($Sensor1$)";

    static final String OLD_FORM =
            "'%s' is the old subscript/superscript form; write A_$1 for a subscript and A_@2 for a superscript";

    static final String LOOK_ALIKE = "%s; a power is written A^2";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line sourceLine : model.lines()) {
            if (sourceLine.isAbsorbed() || sourceLine.isBlank()) {
                continue;
            }
            String line = sourceLine.masked();
            if (assignsToCall(line)) {
                out.add(sourceLine.index(), Rule.ASSIGN_TO_CALL, ASSIGNS_TO_CALL);
            }
            String fault = firstNameFault(line);
            if (fault != null) {
                out.add(sourceLine.index(), Rule.STYLING, fault);
            }
        }
    }

    // =====================================================================
    // Names
    // =====================================================================

    /**
     * @param masked one masked logical line
     * @return the first naming problem on the line, or null
     */
    static String firstNameFault(String masked) {
        if (masked == null || masked.isEmpty()) {
            return null;
        }
        String s = blankConstants(masked);
        int n = s.length();
        int i = 0;
        while (i < n) {
            char c = s.charAt(i);

            if (Character.isWhitespace(c)) {
                i++;
                continue;
            }

            // \var(\mu) typed but not yet turned into μ: not a name here.
            if (c == '\\' && i + 1 < n && Lexis.isIdentStart(s.charAt(i + 1))) {
                i = Lexis.scanIdent(s, i + 1);
                continue;
            }

            // A number and whatever is glued to it (5i, 1e5, 2A): other rules.
            if (Character.isDigit(c) || (c == '.' && i + 1 < n && Character.isDigit(s.charAt(i + 1)))) {
                i = Lexis.scanIdent(s, i + 1);
                continue;
            }

            if (c == '$') {
                int end = signalEnd(s, i + 1);
                if (end > i + 1 && end < n && s.charAt(end) == '$') {
                    return String.format(SENSOR_RESERVED, s.substring(i + 1, end));
                }
                return LONE_DOLLAR;
            }

            if (c == '@') {
                int end = signalEnd(s, i + 1);
                if (end > i + 1 && end < n && s.charAt(end) == '@') {
                    return String.format(ACTUATOR_RESERVED, s.substring(i + 1, end));
                }
                // @sin (a function reference) or @rate(10Hz): fine.
                i = end;
                continue;
            }

            if (c == '^' && i + 1 < n && (s.charAt(i + 1) == '^' || s.charAt(i + 1) == '{')) {
                return String.format(OLD_FORM, s.substring(i, i + 2));
            }

            if (Lexis.isIdentStart(c)) {
                int end = Lexis.scanIdent(s, i);
                String name = s.substring(i, end);
                if (name.endsWith("_") && end < n && s.charAt(end) == '{') {
                    return String.format(OLD_FORM, name.substring(name.length() - 1) + "{");
                }
                String problem = ScriptedName.problem(name);
                if (problem != null) {
                    return String.format(BAD_NAME, shown(name), problem);
                }
                i = end;
                continue;
            }

            int cp = s.codePointAt(i);
            if (ScriptedName.isLookAlikeOrInvisible(cp)) {
                return String.format(LOOK_ALIKE, ScriptedName.describeRefusal(cp));
            }
            i += Character.charCount(cp);
        }
        return null;
    }

    /**
     * The name for a message, with each run of an invisible character shown
     * once as its code: {@code S<U+200D x3>j<U+200D x3>}.
     */
    static String shown(String name) {
        StringBuilder out = new StringBuilder(name.length() + 8);
        int i = 0;
        while (i < name.length()) {
            int cp = name.codePointAt(i);
            int len = Character.charCount(cp);
            if (Character.getType(cp) != Character.FORMAT) {
                out.appendCodePoint(cp);
                i += len;
                continue;
            }
            int run = 0;
            while (i < name.length() && name.codePointAt(i) == cp) {
                run++;
                i += len;
            }
            out.append(String.format("<U+%04X%s>", cp, run > 1 ? " x" + run : ""));
        }
        return out.toString();
    }

    /** End of a live-signal name starting at {@code from} (letters, digits, '_'). */
    private static int signalEnd(String s, int from) {
        int j = from;
        while (j < s.length()) {
            char c = s.charAt(j);
            if (Character.isLetterOrDigit(c) || c == '_' || Character.getType(c) == Character.NON_SPACING_MARK
                    || Character.getType(c) == Character.COMBINING_SPACING_MARK) {
                j++;
            } else {
                break;
            }
        }
        return j;
    }

    /**
     * Blanks every physical-constant symbol ({@code 𝝅}, {@code 𝑵ₐ}, ...),
     * offsets kept: a constant is not a name, and its {@code ₐ} must not be
     * reported as a subscript look-alike.
     */
    private static String blankConstants(String s) {
        String out = s;
        for (Map.Entry<String, String> e : Uniconstant.SYMBOL_MAP.entrySet()) {
            String symbol = e.getValue();
            if (!symbol.isEmpty() && out.contains(symbol)) {
                out = out.replace(symbol, " ".repeat(symbol.length()));
            }
        }
        return out;
    }

    // =====================================================================
    // Assignment to a call
    // =====================================================================

    /**
     * @param masked one masked logical line
     * @return true when some statement on the line assigns to a function call
     */
    static boolean assignsToCall(String masked) {
        if (masked == null || masked.indexOf('=') < 0) {
            return false;
        }
        for (String statement : Lexis.splitStatements(masked)) {
            int assignment = Lexis.assignmentIndex(statement);
            if (assignment < 0) {
                continue;
            }
            if (endsWithCall(statement.substring(0, assignment))) {
                return true;
            }
        }
        return false;
    }

    /** True when {@code text} ends in {@code name(...)}, matched by depth. */
    private static boolean endsWithCall(String text) {
        int end = Lexis.prevNonSpace(text, text.length() - 1);
        if (end < 0 || text.charAt(end) != ')') {
            return false;
        }
        int depth = 0;
        int open = -1;
        for (int i = end; i >= 0; i--) {
            char c = text.charAt(i);
            if (c == ')' || c == ']' || c == '}') {
                depth++;
            } else if (c == '(' || c == '[' || c == '{') {
                depth--;
                if (depth == 0) {
                    open = i;
                    break;
                }
            }
        }
        if (open < 0 || text.charAt(open) != '(') {
            return false;
        }
        int nameEnd = Lexis.prevNonSpace(text, open - 1);
        int nameStart = nameEnd;
        while (nameStart >= 0 && Lexis.isIdentPart(text.charAt(nameStart))) {
            nameStart--;
        }
        nameStart++;
        if (nameStart > nameEnd || !Lexis.isIdentStart(text.charAt(nameStart))) {
            return false; // (a, b) = ..., 2(x) = ... : no name before the bracket
        }
        return nameStart == 0 || text.charAt(nameStart - 1) != '\\';
    }
}
