package language.syntax.syntax_checker.symbols;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import language.syntax.SyntaxPalette;
import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;
import language.syntax.syntax_checker.structure.BlockHeaderGrammar;

/**
 * How another script is called.
 *
 * <h3>The language</h3>
 * A script in the <b>same folder</b> as the file being edited is run by its
 * bare name, as a statement of its own. Brackets mean a function, so a script
 * never takes them, and a function inside another script is reached through
 * the script's name:
 *
 * <pre>
 *   valid                    error
 *   ABC;                     ABC.nc;          the extension is not written
 *   ABC                      ABC();           brackets make it a function call
 *   ABC.f(x);                X = ABC;         a script is not a value
 *   Y = ABC.f(2);            mm;              inside mm.nc: a script cannot call itself
 * </pre>
 *
 * A name that is both a variable in this file and a script beside it is
 * ambiguous on its own line, so {@code ABC;} is then reported and the
 * variable has to be renamed. (In the Command Window both {@code ABC} and
 * {@code ABC.nc} work; that is the CLI's business, not this check's.)
 *
 * <h3>What counts as defined here</h3>
 * Function and class names, their parameters and outputs, {@code for} loop
 * variables, class fields, and every name on the left of an assignment. A
 * function defined in this file, or a registered built-in, with the same name
 * as a script is a function, and {@code name(...)} calls it.
 *
 * <p>
 * Without a known folder ({@link CheckContext#NONE}) only the {@code .nc}
 * rule applies; everything else needs to know which scripts exist.
 */
public final class ScriptCallAnalyzer implements Analyzer {

    static final String WITH_EXTENSION =
            "Call a script by its name alone: write '%s;' (the '.nc' is not written)";
    static final String SELF_CALL = "A script cannot call itself: '%s' is this file";
    static final String WITH_BRACKETS = "'%s' is the script %s.nc: call it as '%s;' without brackets "
            + "(a function inside it is called as '%s.function(...)')";
    static final String AS_VALUE = "'%s' is the script %s.nc, not a value: run it on its own as '%s;'";
    static final String NAME_CLASH = "'%s' is both a variable in this file and the script %s.nc; "
            + "rename the variable";

    private static final Pattern BARE_NAME = Pattern.compile("^(" + BlockHeaderGrammar.IDENT + ")$");
    private static final Pattern NAME_WITH_EXTENSION =
            Pattern.compile("^(" + BlockHeaderGrammar.IDENT + ")\\s*\\.\\s*nc$");

    private static volatile Set<String> builtins;

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        Set<String> scripts = context.scripts();
        Defined defined = scripts.isEmpty() ? new Defined() : collectDefined(model);
        String self = context.ownScriptName();

        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String trimmed = line.masked().trim();
            if (trimmed.startsWith("@") || isHeaderOrCloser(trimmed)) {
                continue;
            }
            for (String part : Lexis.splitStatements(line.masked())) {
                String statement = part.trim();
                if (statement.isEmpty() || statement.equals("clear") || statement.startsWith("clear ")) {
                    continue;
                }
                String fault = checkStatement(statement, scripts, defined, self);
                if (fault != null) {
                    out.add(line.index(), Rule.SCRIPT_CALL, fault);
                    break;
                }
            }
        }
    }

    private static String checkStatement(String statement, Set<String> scripts, Defined defined, String self) {
        Matcher extension = NAME_WITH_EXTENSION.matcher(statement);
        if (extension.matches()) {
            return String.format(WITH_EXTENSION, Lexis.visible(extension.group(1)));
        }
        if (scripts.isEmpty()) {
            return null;
        }

        Matcher bare = BARE_NAME.matcher(statement);
        if (bare.matches()) {
            String name = bare.group(1);
            if (!scripts.contains(name) || defined.functions.contains(name)) {
                return null; // a variable echo or a call of something else
            }
            if (defined.variables.contains(name)) {
                return String.format(NAME_CLASH, name, name);
            }
            return name.equals(self) ? String.format(SELF_CALL, name) : null;
        }

        return checkUses(statement, scripts, defined);
    }

    /** Every other appearance of a script name in a statement. */
    private static String checkUses(String s, Set<String> scripts, Defined defined) {
        int n = s.length();
        int i = 0;
        while (i < n) {
            char c = s.charAt(i);
            if (Character.isDigit(c)) {
                i = Lexis.scanIdent(s, i); // a number, including 1e5
                continue;
            }
            if (!Lexis.isIdentStart(c)) {
                i++;
                continue;
            }
            int end = Lexis.scanIdent(s, i);
            String name = s.substring(i, end);
            int before = Lexis.prevNonSpace(s, i - 1);
            char prev = before < 0 ? ' ' : s.charAt(before);
            int after = Lexis.nextNonSpace(s, end);
            char next = after < n ? s.charAt(after) : ' ';
            i = end;

            if (prev == '.' || prev == '\\' || !scripts.contains(name)
                    || defined.functions.contains(name) || Lexis.KEYWORDS.contains(name)) {
                continue;
            }
            if (next == '.') {
                continue; // ABC.f(x): a function inside the script
            }
            if (next == '(') {
                if (!builtins().contains(name)) {
                    return String.format(WITH_BRACKETS, name, name, name, name);
                }
                continue;
            }
            if (!defined.variables.contains(name)) {
                return String.format(AS_VALUE, name, name, name);
            }
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Names this file defines
    // ─────────────────────────────────────────────────────────────────────

    private static final class Defined {
        final Set<String> functions = new HashSet<>();
        final Set<String> variables = new HashSet<>();
    }

    private static Defined collectDefined(SourceModel model) {
        Defined defined = new Defined();
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank()) {
                continue;
            }
            BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(line.masked());
            if (header != null) {
                collectHeader(header, line.masked(), defined);
                continue;
            }
            String trimmed = line.masked().trim();
            if (trimmed.startsWith("private ") || trimmed.startsWith("protected ")) {
                addNames(trimmed.replaceFirst("^(?:(?:private|protected)\\s+)+", ""), defined.variables);
                continue;
            }
            for (String statement : Lexis.splitStatements(line.masked())) {
                int equals = Lexis.assignmentIndex(statement);
                if (equals > 0) {
                    addNames(statement.substring(0, equals), defined.variables);
                }
            }
        }
        return defined;
    }

    private static void collectHeader(BlockHeaderGrammar.Header header, String masked, Defined defined) {
        switch (header.kind()) {
            case FUNCTION, CLASS -> {
                if (header.name() != null) {
                    defined.functions.add(header.name());
                }
                defined.variables.addAll(header.parameters());
                defined.variables.addAll(header.outputs());
            }
            case FOR -> {
                String rest = masked.trim().substring("for".length());
                int equals = Lexis.assignmentIndex(rest);
                if (equals > 0) {
                    addNames(rest.substring(0, equals), defined.variables);
                }
            }
            default -> {
                // if / while / else / elseif define nothing
            }
        }
    }

    /** Adds every name in {@code text} (the left side of an assignment, a field list). */
    private static void addNames(String text, Set<String> target) {
        int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (Lexis.isIdentStart(c) || Character.isDigit(c)) {
                int end = Lexis.scanIdent(text, i);
                boolean field = Lexis.prevNonSpace(text, i - 1) >= 0
                        && text.charAt(Lexis.prevNonSpace(text, i - 1)) == '.';
                if (Lexis.isIdentStart(c) && !field) {
                    target.add(text.substring(i, end));
                }
                i = end;
            } else {
                i++;
            }
        }
    }

    private static boolean isHeaderOrCloser(String trimmed) {
        String word = BlockHeaderGrammar.firstWord(trimmed);
        if (BlockHeaderGrammar.isCloser(word)) {
            return true;
        }
        BlockHeaderGrammar.Header header = BlockHeaderGrammar.parse(trimmed);
        return header != null && (header.kind() == BlockHeaderGrammar.Kind.FUNCTION
                || header.kind() == BlockHeaderGrammar.Kind.CLASS);
    }

    /**
     * The registered built-in function names. Read once; a failure to load
     * them (for example outside the full application) leaves the set empty.
     */
    private static Set<String> builtins() {
        Set<String> names = builtins;
        if (names == null) {
            try {
                names = Set.copyOf(SyntaxPalette.builtinFunctionNames());
            } catch (RuntimeException | LinkageError e) {
                names = Set.of();
            }
            builtins = names;
        }
        return names;
    }
}
