package language.syntax.syntax_checker.expression;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Matrix declarations and matrix indexing (slicing).
 *
 * <h3>Declaring a matrix</h3>
 * Elements are separated by {@code ,} and rows by {@code ;}, and every row
 * has the same number of elements:
 *
 * <pre>
 *   valid                         error
 *   A = [a, a, a; b, b, b];       A = [[1,2],[3,4]];   the old nested form
 *   A = [1, 2, 3];                A = [1 2 3];         spaces are not separators
 *   A = [];                       A = [1, 2; 3];       rows of different length
 *   v = [1:2:100];                A = [1, 2;];         an empty row
 *                                 A = [1, , 2];        an empty element
 * </pre>
 *
 * A space-separated row ({@code [1 2 3]}) is reported by
 * {@link OperandAdjacencyAnalyzer} ("missing ',' or operator"), which now
 * treats square brackets like every other bracket. A declaration holding a
 * range ({@code [1:3; 4:6]}, {@code [1:2:100]}) is not row-counted, because
 * the length of a range is only known when it runs.
 *
 * <h3>Indexing a matrix</h3>
 * A {@code [} written straight after a name, a {@code )} or a {@code ]} --
 * no space -- is an index, not a declaration:
 *
 * <pre>
 *   A[r, c]        one element
 *   A[::]          a copy of the whole matrix
 *   A[m], A[m,]    row m
 *   A[:,n], A[,n]  column n
 *   A[m:,]         rows m onwards
 *   A[,n:]         columns n onwards
 *   A[1:3, 1:3]    rows 1..3, columns 1..3
 *   A[m1:m2, n1:n2]
 * </pre>
 *
 * Reported here: an empty index ({@code A[]}, {@code A[,]}), more than a row
 * and a column ({@code A[1,2,3]}), {@code ;} inside an index, a slice with
 * more than one {@code :} other than {@code A[::]}, and a slice whose start
 * is not below its end when both are written as numbers ({@code A[3:1, 2]}).
 *
 * <p>
 * Bounds against the matrix's size ({@code m2 < N}) need its size, which is
 * only known at run time; that check belongs to the interpreter.
 *
 * <p>
 * Runs on the masked text, so brackets, commas and semicolons inside a string
 * literal are invisible. A line whose brackets do not balance is left to
 * {@link BracketAnalyzer}.
 */
public final class MatrixAnalyzer implements Analyzer {

    /**
     * Most index positions accepted in {@code A[...]}: a row and a column.
     * Raise this when N-dimensional arrays arrive.
     */
    static final int MAX_INDEX_PARTS = 2;

    private static final Pattern INTEGER = Pattern.compile("[+-]?\\d+");

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = check(line.masked());
            if (message != null) {
                out.add(line.index(), Rule.MATRIX, message);
            }
        }
    }

    /**
     * @param s one masked logical line
     * @return the first fault, or null
     */
    static String check(String s) {
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != '[') {
                continue;
            }
            int close = matchingClose(s, i);
            if (close < 0) {
                return null; // unbalanced: BracketAnalyzer's
            }
            String message = isIndex(s, i)
                    ? checkIndex(nameBefore(s, i), s.substring(i + 1, close))
                    : checkDeclaration(s.substring(i + 1, close));
            if (message != null) {
                return message;
            }
            // Keep scanning from i + 1: brackets nested inside are checked too.
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Declarations
    // ─────────────────────────────────────────────────────────────────────

    private static String checkDeclaration(String inner) {
        if (inner.isBlank()) {
            return null; // [] is the empty matrix
        }
        List<String> rows = splitTopLevel(inner, ';');
        boolean range = hasTopLevel(inner, ':');
        int firstWidth = -1;

        for (int r = 0; r < rows.size(); r++) {
            String row = rows.get(r);
            if (row.isBlank()) {
                return rows.size() == 1
                        ? null
                        : "Empty row in matrix: remove the extra ';' (rows are written [a, b; c, d])";
            }
            List<String> elements = splitTopLevel(row, ',');
            for (String element : elements) {
                String value = element.trim();
                if (value.isEmpty()) {
                    return "Empty element in matrix row " + (r + 1) + ": a value is missing next to ','";
                }
                if (value.charAt(0) == '[') {
                    return "Nested rows like [[1, 2], [3, 4]] are not valid: write the matrix as [1, 2; 3, 4]";
                }
            }
            if (range) {
                continue;
            }
            if (firstWidth < 0) {
                firstWidth = elements.size();
            } else if (elements.size() != firstWidth) {
                return "Every row must have the same number of elements: row 1 has " + firstWidth
                        + ", row " + (r + 1) + " has " + elements.size();
            }
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Indexing
    // ─────────────────────────────────────────────────────────────────────

    private static String checkIndex(String name, String inner) {
        String shown = name.isEmpty() ? "A" : name;
        if (inner.isBlank()) {
            return "Empty index '" + shown + "[]': give a row, a column, or both, e.g. "
                    + shown + "[1, 2], " + shown + "[1,], " + shown + "[,2]";
        }
        if (hasTopLevel(inner, ';')) {
            return "';' is not allowed inside an index: separate the row and the column with ',', e.g. "
                    + shown + "[1, 2]";
        }
        List<String> parts = splitTopLevel(inner, ',');
        if (parts.size() > MAX_INDEX_PARTS) {
            return "An index takes at most a row and a column: " + shown + "[row, column]";
        }
        if (parts.size() == 2 && parts.get(0).isBlank() && parts.get(1).isBlank()) {
            return "'" + shown + "[,]' selects nothing: give a row, a column, or both";
        }
        boolean single = parts.size() == 1;
        for (String part : parts) {
            String message = checkSlice(shown, part.trim(), single);
            if (message != null) {
                return message;
            }
        }
        return null;
    }

    /**
     * One position of an index: empty, a value, or a slice {@code a:b},
     * {@code a:}, {@code :b}, {@code :}. {@code ::} is accepted only as the
     * whole index ({@code A[::]}, a copy).
     */
    private static String checkSlice(String name, String part, boolean wholeIndex) {
        List<String> pieces = splitTopLevel(part, ':');
        int colons = pieces.size() - 1;
        if (colons == 0) {
            return null;
        }
        if (colons == 2 && wholeIndex && part.replace(" ", "").equals("::")) {
            return null;
        }
        if (colons > 1) {
            return "'" + part + "' is not a valid slice: use start:end (e.g. " + name
                    + "[1:3, 1:3]), start: , :end, or " + name + "[::] for a copy";
        }
        String start = pieces.get(0).trim();
        String end = pieces.get(1).trim();
        if (INTEGER.matcher(start).matches() && INTEGER.matcher(end).matches()) {
            long from = parse(start);
            long to = parse(end);
            if (from >= to) {
                return "Slice '" + start + ":" + end + "' is empty: its start must be smaller than its end";
            }
        }
        return null;
    }

    private static long parse(String integer) {
        try {
            return Long.parseLong(integer.startsWith("+") ? integer.substring(1) : integer);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Scanning helpers
    // ─────────────────────────────────────────────────────────────────────

    /**
     * True when the {@code [} at {@code open} indexes what touches it on the
     * left: a name, a {@code )} or a {@code ]}. A space before it, an operator,
     * {@code =}, {@code ,} or the start of the line makes it a declaration.
     */
    private static boolean isIndex(String s, int open) {
        if (open == 0) {
            return false;
        }
        char before = s.charAt(open - 1);
        return Lexis.isIdentPart(before) || before == ')' || before == ']';
    }

    /** The name written straight before an index, for messages; may be empty. */
    private static String nameBefore(String s, int open) {
        int start = open;
        while (start > 0 && Lexis.isIdentPart(s.charAt(start - 1))) {
            start--;
        }
        return Lexis.visible(s.substring(start, open));
    }

    /**
     * The offset of the bracket closing the {@code [} at {@code open}, or -1.
     * Round and square closers both count (NC's interval forms).
     */
    private static int matchingClose(String s, int open) {
        int depth = 0;
        for (int i = open; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth--;
                if (depth == 0) {
                    return i;
                }
                if (depth < 0) {
                    return -1;
                }
            }
        }
        return -1;
    }

    /** Splits on {@code separator} where no bracket is open. Always at least one entry. */
    private static List<String> splitTopLevel(String s, char separator) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(' || c == '[' || c == '{') {
                depth++;
            } else if (c == ')' || c == ']' || c == '}') {
                depth = Math.max(0, depth - 1);
            } else if (c == separator && depth == 0) {
                parts.add(s.substring(start, i));
                start = i + 1;
            }
        }
        parts.add(s.substring(start));
        return parts;
    }

    private static boolean hasTopLevel(String s, char wanted) {
        return splitTopLevel(s, wanted).size() > 1;
    }
}
