package language.syntax.syntax_checker.expression;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Checks every power operator {@code ^}.
 *
 * <p>
 * {@code ^} is binary and needs an operand on each side:
 * <ul>
 * <li><b>Base</b>: a number, a name, a closing {@code )} {@code ]} {@code }}
 * (an absolute value {@code |x|} counts, since it reaches here as
 * {@code (x)}), or a postfix {@code !}.</li>
 * <li><b>Power</b>: a number, a name, a call, {@code (}, {@code [}, a
 * {@code \var(} form, or any of those behind an unlimited run of {@code +} /
 * {@code -} signs ({@code 5^----6}).</li>
 * <li>Never on the left of an assignment: {@code A^2 = 5}.</li>
 * </ul>
 * {@code ^^} (superscript mode) and {@code ^{...}} (brace superscript) are
 * styling, left to {@code SubscriptSuperscriptAnalyzer}. {@code **} is not a
 * power operator; {@link OperatorSequenceAnalyzer} rejects it.
 */
public final class ExponentAnalyzer implements Analyzer {

    static final String NO_BASE = "Exponent '^' has no base before it";
    static final String NO_POWER = "Exponent '^' has no power after it";
    static final String ASSIGN_TO_POWER = "Cannot assign to a power: '^' is on the left of '='";

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = checkLine(line.masked());
            if (message != null) {
                out.add(line.index(), Rule.EXPONENT, message);
            }
        }
    }

    /**
     * @param s one masked logical line
     * @return the first fault, or null when every {@code ^} is sound
     */
    static String checkLine(String s) {
        if (s == null || s.indexOf('^') < 0) {
            return null;
        }
        int n = s.length();
        int assignment = Lexis.assignmentIndex(s);

        for (int i = 0; i < n; i++) {
            if (s.charAt(i) != '^') {
                continue;
            }
            if (i + 1 < n && s.charAt(i + 1) == '^') {
                i++; // '^^' superscript mode
                continue;
            }
            int right = Lexis.nextNonSpace(s, i + 1);
            if (right < n && s.charAt(right) == '{') {
                continue; // '^{...}' brace superscript
            }
            if (!hasBase(s, i)) {
                return NO_BASE;
            }
            if (!hasPower(s, right)) {
                return NO_POWER;
            }
            if (assignment >= 0 && i < assignment) {
                return ASSIGN_TO_POWER;
            }
        }
        return null;
    }

    private static boolean hasBase(String s, int caret) {
        int p = Lexis.prevNonSpace(s, caret - 1);
        if (p < 0) {
            return false;
        }
        char c = s.charAt(p);
        return Lexis.isIdentPart(c) || c == ')' || c == ']' || c == '}' || c == '!';
    }

    private static boolean hasPower(String s, int at) {
        int n = s.length();
        if (at >= n) {
            return false;
        }
        char c = s.charAt(at);
        while (c == '+' || c == '-') {
            at = Lexis.nextNonSpace(s, at + 1);
            if (at >= n) {
                return false;
            }
            c = s.charAt(at);
        }
        if (c == '.') {
            return at + 1 < n && Character.isDigit(s.charAt(at + 1));
        }
        return Character.isDigit(c) || Lexis.isIdentStart(c) || c == '(' || c == '[' || c == '\\';
    }
}
