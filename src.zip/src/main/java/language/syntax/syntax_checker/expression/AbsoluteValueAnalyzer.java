package language.syntax.syntax_checker.expression;

import language.syntax.syntax_checker.core.AbsoluteBars;
import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Reports absolute values that are never closed or that cross a bracket.
 *
 * <pre>
 *   valid                         error
 *   A = |-5|;                     A = |-5;              never closed
 *   if |U| == |U|:                (|x)|                 crosses ')'
 *   d = ||v|| + |A-B|^2;          (|D/B)==B)            crosses ')'
 *   publish(|x|, ||y||);          [|a]|                 crosses ']'
 * </pre>
 *
 * The bars are resolved once, by {@link AbsoluteBars} while the document is
 * cleaned; this analyzer only reports what it found, so the decision about
 * what a bar is lives in one place.
 */
public final class AbsoluteValueAnalyzer implements Analyzer {

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.hasUnterminatedString() || line.absoluteFaults().isEmpty()) {
                continue;
            }
            out.add(line.index(), Rule.ABSOLUTE_VALUE, line.absoluteFaults().get(0).message());
        }
    }
}
