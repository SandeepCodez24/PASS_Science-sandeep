package language.syntax.syntax_checker.expression;

import java.util.ArrayDeque;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Lines that do not stand on their own: unbalanced brackets, a trailing
 * {@code ,}, a line ending in an open bracket, or {@code ;} with nothing
 * before it.
 *
 * <h3>Interval brackets</h3>
 * {@code [a:b]}, {@code (a:b)}, {@code (a:b]} and {@code [a:b)} are four legal
 * range forms. A round opener may be closed by a square closer and vice
 * versa, but only when the span holds a range colon at its own depth, so
 * {@code f(x]} is still an error. Curly braces never mix.
 *
 * <h3>Absolute values</h3>
 * A matched {@code |x|} reaches this check as {@code (x)}. A bar that is never
 * closed, or that crosses a bracket, is blanked by
 * {@code AbsoluteBars} instead, so the line's real bracket count is what is
 * checked here and {@code (|D/B)==B)} is reported as unbalanced.
 *
 * <p>
 * A trailing operator ({@code +}, {@code ==}, {@code &&} ...) is
 * {@link OperatorSequenceAnalyzer}'s, which names the operator. A line with an
 * unterminated string is the string check's.
 */
public final class BracketAnalyzer implements Analyzer {

    /** One open bracket on the scan stack. */
    private static final class Bracket {
        final char open;
        /** A ':' seen directly inside this bracket, marking it as a range. */
        boolean sawRangeColon;

        Bracket(char open) {
            this.open = open;
        }
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.hasUnterminatedString() || line.isBlank()) {
                continue;
            }
            String reason = reason(line.masked().trim());
            if (reason != null) {
                out.add(line.index(), Rule.INCOMPLETE_LINE, reason);
            }
        }
    }

    /**
     * @param logical one trimmed masked line
     * @return why the line is incomplete, or null when it is fine
     */
    static String reason(String logical) {
        String normalized = logical;
        if (normalized.endsWith(";")) {
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        if (normalized.isEmpty()) {
            return "Empty statement: ';' with nothing before it";
        }
        if (normalized.endsWith(",")) {
            return "Line ends with ',': a value is missing after it";
        }
        char last = normalized.charAt(normalized.length() - 1);
        if (last == '(' || last == '[' || last == '{') {
            return "Line ends with an open '" + last + "' that is never closed";
        }
        if (!bracketsBalanced(normalized)) {
            return "Brackets on this line do not match: every '(', '[' and '{' needs its closing partner";
        }
        return null;
    }

    private static boolean bracketsBalanced(String line) {
        ArrayDeque<Bracket> stack = new ArrayDeque<>();
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == ':') {
                if (!stack.isEmpty()) {
                    stack.peek().sawRangeColon = true;
                }
            } else if (ch == '(' || ch == '[' || ch == '{') {
                stack.push(new Bracket(ch));
            } else if (ch == ')' || ch == ']' || ch == '}') {
                if (stack.isEmpty() || !closes(stack.pop(), ch)) {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    /** True when {@code close} legally terminates {@code opened}. */
    private static boolean closes(Bracket opened, char close) {
        char expected = switch (close) {
            case ')' -> '(';
            case ']' -> '[';
            default -> '{';
        };
        if (opened.open == expected) {
            return true;
        }
        boolean roundOrSquare = (opened.open == '(' || opened.open == '[') && (close == ')' || close == ']');
        return roundOrSquare && opened.sawRangeColon;
    }
}
