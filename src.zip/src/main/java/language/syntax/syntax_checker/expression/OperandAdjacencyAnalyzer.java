package language.syntax.syntax_checker.expression;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import language.syntax.syntax_checker.core.Analyzer;
import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Lexis;
import language.syntax.syntax_checker.core.Rule;
import language.syntax.syntax_checker.core.SourceModel;

/**
 * Reports two values written side by side with nothing between them.
 *
 * <p>
 * Neural Code has no implicit operation of any kind. Two operands must always
 * be joined by an operator ({@code 2*A}) or separated by a comma
 * ({@code publish(A, 0)}). Every one of these is therefore an error:
 *
 * <pre>
 *   publish("comma error is here"0, sin(1.24));   string, then number
 *   publish(A, B, "one more error example"12455);  string, then number
 *   x = 2A;                                        number, then name
 *   y = 2(A+B);                                    number, then bracket
 *   z = (A+B)(C+D);                                bracket, then bracket
 *   w = f(A B);                                    name, then name
 * </pre>
 *
 * <h3>A {@code ;} inside brackets</h3>
 * {@code ;} ends a statement, and a statement can only end outside every
 * bracket. Inside {@code publish(...)}, any other call, or plain grouping
 * brackets it is therefore always an error, wherever it stands:
 *
 * <pre>
 *   publish("Addition :", log(B)+log(D);,"=",A1);   ';' inside publish(...)
 *   x = sqrt(4;);                                    ';' inside sqrt(...)
 *   y = (A+B;)*2;                                    ';' inside (...)
 *   m = {a: 1; b: 2};                                ';' inside {...}
 * </pre>
 *
 * Nothing else on the line hid it before: the brackets balance, and a
 * {@code ;} followed by {@code ,} leaves no operator waiting for a value, so
 * every other check passed the line. A {@code ;} after the closing bracket
 * ({@code publish(A); B = 2;}) is untouched. The one exception is a matrix
 * row break inside square brackets, {@code [1, 2; 3, 4]}, accepted while
 * {@link #ALLOW_SEMICOLON_ROWS} is true -- including inside a call, so
 * {@code publish([1, 2; 3, 4])} is legal. This check runs before the adjacency
 * check, so the {@code ;} is reported rather than whatever follows it.
 *
 * <h3>What is still legal</h3>
 * <ul>
 * <li>A call, {@code f(x)} or {@code f (x)}, and indexing, {@code A[1]},
 * {@code f(x)[2]}, {@code A[1][2]}.</li>
 * <li>A number in scientific notation, {@code 1.5e-3}, and an imaginary
 * number, {@code 5i}, {@code 2.5i}, {@code 1e-3i}: an {@code i} touching a
 * number, with nothing name-like after it, belongs to the number. {@code 5i2}
 * and {@code 5 i} are still reported.</li>
 * <li>Anything next to a keyword: {@code if x:}, {@code for i = ...},
 * {@code return x}, {@code not x}, {@code a and b}, {@code x is_in S},
 * {@code new A(3)}, {@code function [a, b] = f(x):}.</li>
 * <li>{@code clear A B} (the whole line), CLI-style {@code @cmd} lines, and
 * {@code @name(...)} annotations such as {@code @rate(10Hz)}.</li>
 * <li>Styled names and their groups (subscript/superscript markers are part of
 * the name), Unicode super/subscript digits after a value ({@code A²}),
 * {@code \var(...)} / {@code \con(...)} and a {@code _j} suffix after one.</li>
 * </ul>
 *
 * <h3>Matrices</h3>
 * Elements of a matrix are separated by {@code ,} and rows by {@code ;}
 * ({@code [a, a, a; b, b, b]}), so space-separated elements ({@code [1 2 3]})
 * are reported here like any other missing separator. The row rules are in
 * {@link MatrixAnalyzer}. (The old switch that accepted {@code [1 2 3]} is
 * gone: with it permanently off, its branch was dead code.)
 *
 * <p>
 * The check runs on {@link SourceModel}'s masked text. The masked form keeps
 * the quote characters and blanks only the string body, so a literal still
 * reads as one value and nothing inside it can be mistaken for code. The token
 * text shown in the message is taken from {@link SourceModel.Line#code()} at the
 * same offsets, so the user sees the real literal.
 */
public final class OperandAdjacencyAnalyzer implements Analyzer {

    /**
     * When true, {@code ;} is accepted as a row break directly inside square
     * brackets, {@code [1 2; 3 4]}. Set to false to reject {@code ;} inside
     * every kind of bracket.
     */
    static final boolean ALLOW_SEMICOLON_ROWS = true;

    /** Longest token text quoted in a message before it is shortened. */
    private static final int MAX_QUOTED = 18;

    private enum Kind {
        NUMBER, WORD, STRING, OPEN, CLOSE, OTHER
    }

    private static final class Token {
        final Kind kind;
        final int start;
        final int end;
        final boolean keyword;
        final boolean spaceBefore;
        final char bracket;

        Token(Kind kind, int start, int end, boolean keyword, boolean spaceBefore, char bracket) {
            this.kind = kind;
            this.start = start;
            this.end = end;
            this.keyword = keyword;
            this.spaceBefore = spaceBefore;
            this.bracket = bracket;
        }

        boolean endsOperand() {
            return !keyword && (kind == Kind.NUMBER || kind == Kind.WORD || kind == Kind.STRING
                    || (kind == Kind.CLOSE && bracket != '}'));
        }

        boolean startsOperand() {
            return !keyword && (kind == Kind.NUMBER || kind == Kind.WORD || kind == Kind.STRING
                    || (kind == Kind.OPEN && bracket != '{'));
        }
    }

    @Override
    public void analyze(SourceModel model, CheckContext context, Findings out) {
        for (SourceModel.Line line : model.lines()) {
            if (line.isAbsorbed() || line.isBlank() || line.hasUnterminatedString()) {
                continue;
            }
            String message = checkLine(line.masked(), line.code());
            if (message != null) {
                out.add(line.index(), Rule.MISSING_SEPARATOR, message);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Line check
    // ─────────────────────────────────────────────────────────────────────

    /**
     * @param masked the masked logical line
     * @param code   the same line with literals intact (for the message)
     * @return the first fault, or null
     */
    static String checkLine(String masked, String code) {
        String trimmed = masked.trim();
        if (trimmed.isEmpty() || trimmed.startsWith("@")) {
            return null; // CLI-style command line
        }

        List<Token> tokens = tokenize(masked);
        if (tokens.isEmpty()) {
            return null;
        }
        Token first = tokens.get(0);
        if (first.kind == Kind.WORD && "clear".equals(masked.substring(first.start, first.end))) {
            return null; // clear A B
        }

        String semicolon = semicolonInsideBrackets(tokens, masked, code);
        if (semicolon != null) {
            return semicolon;
        }

        for (int k = 1; k < tokens.size(); k++) {
            Token prev = tokens.get(k - 1);
            Token cur = tokens.get(k);
            if (!prev.endsOperand() || !cur.startsOperand()) {
                continue;
            }
            if (isAllowedPair(prev, cur, masked)) {
                continue;
            }
            return message(prev, cur, code);
        }
        return null;
    }

    /**
     * The first {@code ;} that sits inside an open bracket, reported with the
     * call it breaks ({@code publish(...)}) when the bracket belongs to one.
     *
     * @return the message, or null when every {@code ;} is at top level
     */
    private static String semicolonInsideBrackets(List<Token> tokens, String masked, String code) {
        Deque<Integer> open = new ArrayDeque<>();
        for (int k = 0; k < tokens.size(); k++) {
            Token token = tokens.get(k);
            if (token.kind == Kind.OPEN) {
                open.push(k);
                continue;
            }
            if (token.kind == Kind.CLOSE) {
                if (!open.isEmpty()) {
                    open.pop();
                }
                continue;
            }
            if (token.kind != Kind.OTHER || masked.charAt(token.start) != ';' || open.isEmpty()) {
                continue;
            }

            int openIndex = open.peek();
            Token bracket = tokens.get(openIndex);
            if (bracket.bracket == '[' && ALLOW_SEMICOLON_ROWS) {
                continue; // [1, 2; 3, 4] -- a matrix row break
            }
            return semicolonMessage(tokens, openIndex, bracket.bracket, code);
        }
        return null;
    }

    private static String semicolonMessage(List<Token> tokens, int openIndex, char bracket, String code) {
        char close = bracket == '(' ? ')' : bracket == '[' ? ']' : '}';
        String where = String.valueOf(bracket) + "..." + close;
        if (bracket == '(' && openIndex > 0) {
            Token before = tokens.get(openIndex - 1);
            if (before.kind == Kind.WORD && !before.keyword && code != null && before.end <= code.length()) {
                String name = code.substring(before.start, before.end).replace("\u200C", "").replace("\u200D", "");
                where = name + where;
            }
        }
        return "';' is not allowed inside " + where
                + ": a statement ends only after its closing '" + close + "'; separate values with ','";
    }

    private static boolean isAllowedPair(Token prev, Token cur, String masked) {
        boolean prevValue = prev.kind == Kind.WORD || prev.kind == Kind.CLOSE;

        // f(x), f (x) -- a call.
        if (prev.kind == Kind.WORD && cur.kind == Kind.OPEN && cur.bracket == '(') {
            return true;
        }
        // A[1], f(x)[2], A[1][2] -- indexing, only when touching.
        if (prevValue && cur.kind == Kind.OPEN && cur.bracket == '[' && !cur.spaceBefore) {
            return true;
        }
        // \var(\mu)_j -- a subscript suffix on a wrapped name.
        if (prev.kind == Kind.CLOSE && cur.kind == Kind.WORD && !cur.spaceBefore
                && masked.charAt(cur.start) == '_') {
            return true;
        }
        return false;
    }

    private static String message(Token prev, Token cur, String code) {
        String left = quote(code, prev);
        String right = quote(code, cur);
        if (prev.kind == Kind.NUMBER && !cur.spaceBefore
                && (cur.kind == Kind.WORD || cur.kind == Kind.OPEN)) {
            String hint = cur.kind == Kind.WORD ? "; write " + left + "*" + right : "";
            return "Missing operator between '" + left + "' and '" + right
                    + "' (implicit multiplication is not allowed" + hint + ")";
        }
        return "Missing ',' or operator between '" + left + "' and '" + right + "'";
    }

    private static String quote(String code, Token token) {
        String text;
        if (code != null && token.end <= code.length()) {
            text = code.substring(token.start, token.end);
        } else {
            text = String.valueOf(token.bracket);
        }
        // Styling markers are invisible; do not show them in a tooltip.
        text = text.replace("\u200C", "").replace("\u200D", "");
        if (text.length() > MAX_QUOTED) {
            text = text.substring(0, MAX_QUOTED - 1) + "\u2026";
        }
        return text;
    }

    // ─────────────────────────────────────────────────────────────────────
    // Tokenizer
    // ─────────────────────────────────────────────────────────────────────

    private static List<Token> tokenize(String s) {
        List<Token> tokens = new ArrayList<>();
        int n = s.length();
        int i = 0;
        boolean space = false;

        while (i < n) {
            char c = s.charAt(i);

            if (Character.isWhitespace(c)) {
                space = true;
                i++;
                continue;
            }

            // @name(...) annotation: skipped whole, and stands as a separator.
            if (c == '@') {
                int j = i + 1;
                while (j < n && Lexis.isIdentPart(s.charAt(j))) {
                    j++;
                }
                int k = j;
                while (k < n && Character.isWhitespace(s.charAt(k))) {
                    k++;
                }
                if (k < n && s.charAt(k) == '(') {
                    j = skipBalanced(s, k);
                }
                tokens.add(new Token(Kind.OTHER, i, j, false, space, (char) 0));
                i = j;
                space = false;
                continue;
            }

            // String literal: the masked body is blank, so the next matching
            // quote is the closing one.
            if (c == '"' || c == '\'') {
                int close = s.indexOf(c, i + 1);
                int j = close < 0 ? n : close + 1;
                tokens.add(new Token(Kind.STRING, i, j, false, space, (char) 0));
                i = j;
                space = false;
                continue;
            }

            // Number: digits, a fraction, an exponent, then anything attached
            // to it (super/subscript digits, a styled group).
            if (Character.isDigit(c) || (c == '.' && i + 1 < n && Character.isDigit(s.charAt(i + 1))
                    && !endsValueTouching(tokens, space))) {
                int j = scanNumber(s, i);
                tokens.add(new Token(Kind.NUMBER, i, j, false, space, (char) 0));
                i = j;
                space = false;
                continue;
            }

            // \var, \con, \mu ... : a backslash word, never a keyword.
            if (c == '\\' && i + 1 < n && Lexis.isIdentStart(s.charAt(i + 1))) {
                int j = i + 1;
                while (j < n && Lexis.isIdentPart(s.charAt(j))) {
                    j++;
                }
                tokens.add(new Token(Kind.WORD, i, j, false, space, (char) 0));
                i = j;
                space = false;
                continue;
            }

            if (Lexis.isIdentStart(c)) {
                int j = i;
                while (j < n && Lexis.isIdentPart(s.charAt(j))) {
                    j++;
                }
                boolean keyword = Lexis.KEYWORDS.contains(s.substring(i, j));
                tokens.add(new Token(Kind.WORD, i, j, keyword, space, (char) 0));
                i = j;
                space = false;
                continue;
            }

            if (c == '(' || c == '[' || c == '{') {
                tokens.add(new Token(Kind.OPEN, i, i + 1, false, space, c));
                i++;
                space = false;
                continue;
            }

            if (c == ')' || c == ']' || c == '}') {
                int j = i + 1;
                // (a+b)² -- a super/subscript digit belongs to the bracket.
                while (j < n && Lexis.isScriptPostfix(s.charAt(j))) {
                    j++;
                }
                tokens.add(new Token(Kind.CLOSE, i, j, false, space, c));
                i = j;
                space = false;
                continue;
            }

            tokens.add(new Token(Kind.OTHER, i, i + 1, false, space, (char) 0));
            i++;
            space = false;
        }
        return tokens;
    }

    /** True when the last token is a value touching the current position. */
    private static boolean endsValueTouching(List<Token> tokens, boolean space) {
        if (tokens.isEmpty() || space) {
            return false;
        }
        Token last = tokens.get(tokens.size() - 1);
        return last.kind == Kind.WORD || last.kind == Kind.CLOSE || last.kind == Kind.NUMBER;
    }

    private static int scanNumber(String s, int i) {
        int n = s.length();
        int j = i;
        while (j < n && Character.isDigit(s.charAt(j))) {
            j++;
        }
        if (j + 1 < n && s.charAt(j) == '.' && Character.isDigit(s.charAt(j + 1))) {
            j++;
            while (j < n && Character.isDigit(s.charAt(j))) {
                j++;
            }
        } else if (j < n && s.charAt(j) == '.' && (j + 1 >= n || !Lexis.isIdentStart(s.charAt(j + 1)))) {
            j++; // "3." followed by an operator or the end
        }
        if (j < n && (s.charAt(j) == 'e' || s.charAt(j) == 'E')) {
            int k = j + 1;
            if (k < n && (s.charAt(k) == '+' || s.charAt(k) == '-')) {
                k++;
            }
            if (k < n && Character.isDigit(s.charAt(k))) {
                j = k;
                while (j < n && Character.isDigit(s.charAt(j))) {
                    j++;
                }
            }
        }
        // 5i, 2.5i, 1e-3i: an imaginary literal is one number.
        if (Lexis.isImaginaryUnit(s, j)) {
            j++;
        }
        while (j < n && Lexis.isScriptPostfix(s.charAt(j))) {
            j++;
        }
        // A styled group written on a number (2 + markers + 10 + markers).
        if (j < n && Lexis.isMarker(s.charAt(j))) {
            while (j < n && Lexis.isIdentPart(s.charAt(j))) {
                j++;
            }
        }
        return j;
    }

    private static int skipBalanced(String s, int open) {
        int depth = 0;
        for (int j = open; j < s.length(); j++) {
            char c = s.charAt(j);
            if (c == '(') {
                depth++;
            } else if (c == ')') {
                depth--;
                if (depth == 0) {
                    return j + 1;
                }
            }
        }
        return s.length();
    }
}
