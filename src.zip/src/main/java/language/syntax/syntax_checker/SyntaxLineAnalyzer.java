package language.syntax.syntax_checker;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/**
 * Line-level bracket and completeness checks.
 *
 * <h3>Interval brackets</h3>
 * NC treats {@code [a:b]}, {@code (a:b)}, {@code (a:b]} and {@code [a:b)} as four
 * distinct, legal range forms -- closed, open, half-open-left, half-open-right.
 * A round opener may therefore be closed by a square closer and vice versa, but
 * ONLY when the span between them contains a range colon at its own depth. That
 * keeps {@code f(x]} an error while letting {@code (1:2]} through, so genuine
 * typos are still caught. Curly braces never mix: they belong to the
 * subscript/superscript groups and stay strictly paired.
 */
final class SyntaxLineAnalyzer {

    private SyntaxLineAnalyzer() {
    }

    /** One open bracket on the scan stack. */
    private static final class Bracket {
        final char open;
        final int line;
        /** A ':' seen directly inside this bracket, marking it as a range. */
        boolean sawRangeColon;

        Bracket(char open, int line) {
            this.open = open;
            this.line = line;
        }
    }

    static Set<Integer> findIncompleteLineSyntaxErrorLines(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }
        String[] lines = code.split("\\R", -1);
        Set<Integer> docstringLines = DocstringErrorAnalyzer.findDocstringBlockLines(code);
        for (int i = 0; i < lines.length; i++) {
            String line = SyntaxTextUtils.stripTrailingComment(lines[i]).trim();
            if (line.isEmpty() || docstringLines.contains(i)) {
                continue;
            }
            if (looksIncomplete(line)) {
                errorLines.add(i);
            }
        }
        return errorLines;
    }

    static Set<Integer> findErrorLines(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }
        ArrayDeque<Bracket> stack = new ArrayDeque<>();
        int line = 0;
        int openQuoteLine = -1;

        for (int i = 0; i < code.length(); i++) {
            char ch = code.charAt(i);
            if (ch == '\n') {
                line++;
                continue;
            }
            if (ch == '"' && !SyntaxTextUtils.isEscaped(code, i)) {
                openQuoteLine = openQuoteLine == -1 ? line : -1;
                continue;
            }
            if (openQuoteLine != -1) {
                // Brackets and colons inside a string literal are just text.
                continue;
            }

            if (ch == ':') {
                if (!stack.isEmpty()) {
                    stack.peek().sawRangeColon = true;
                }
                continue;
            }
            if (isOpenBracket(ch)) {
                stack.push(new Bracket(ch, line));
                continue;
            }
            if (isCloseBracket(ch)) {
                if (stack.isEmpty()) {
                    errorLines.add(line);
                    continue;
                }
                Bracket opened = stack.pop();
                if (!closes(opened, ch)) {
                    errorLines.add(line);
                }
            }
        }

        if (openQuoteLine != -1) {
            errorLines.add(openQuoteLine);
        }
        for (Bracket unclosed : stack) {
            errorLines.add(unclosed.line);
        }
        return errorLines;
    }

    static Set<Integer> findErrorLinesAfterSemicolon(String code) {
        Set<Integer> errorLines = new HashSet<>();
        if (code == null || code.isEmpty()) {
            return errorLines;
        }
        String[] lines = code.split("\\R", -1);
        for (int i = 0; i < lines.length; i++) {
            String logicalLine = SyntaxTextUtils.stripTrailingComment(lines[i]).trim();
            if (logicalLine.endsWith(";") && !bracketsBalanced(logicalLine)) {
                errorLines.add(i);
            }
        }
        return errorLines;
    }

    private static boolean looksIncomplete(String line) {
        String normalized = line;
        if (normalized.endsWith(";")) {
            normalized = normalized.substring(0, normalized.length() - 1).trim();
        }
        if (normalized.isEmpty()) {
            return true;
        }
        if (normalized.endsWith("+") || normalized.endsWith("-") || normalized.endsWith("*") || normalized.endsWith("/")
                || normalized.endsWith("=") || normalized.endsWith(",") || normalized.endsWith("(") || normalized.endsWith("[")
                || normalized.endsWith("{")) {
            return true;
        }
        return !bracketsBalanced(normalized);
    }

    /**
     * Scans one logical line and reports whether its quotes and brackets close
     * cleanly, allowing the four interval forms described in the class comment.
     */
    private static boolean bracketsBalanced(String line) {
        ArrayDeque<Bracket> stack = new ArrayDeque<>();
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);

            if (ch == '"' && !SyntaxTextUtils.isEscaped(line, i) && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
                continue;
            }
            if (ch == '\'' && !SyntaxTextUtils.isEscaped(line, i) && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
                continue;
            }
            if (inSingleQuote || inDoubleQuote) {
                continue;
            }

            if (ch == ':') {
                if (!stack.isEmpty()) {
                    stack.peek().sawRangeColon = true;
                }
                continue;
            }
            if (isOpenBracket(ch)) {
                stack.push(new Bracket(ch, 0));
                continue;
            }
            if (isCloseBracket(ch)) {
                if (stack.isEmpty()) {
                    return false;
                }
                Bracket opened = stack.pop();
                if (!closes(opened, ch)) {
                    return false;
                }
            }
        }

        return !inSingleQuote && !inDoubleQuote && stack.isEmpty();
    }

    /** True when {@code close} legally terminates {@code opened}. */
    private static boolean closes(Bracket opened, char close) {
        if (opened.open == matchingOpen(close)) {
            return true;
        }
        // Mixed round/square is an interval form, valid only over a range span.
        boolean roundOrSquare = (opened.open == '(' || opened.open == '[')
                && (close == ')' || close == ']');
        return roundOrSquare && opened.sawRangeColon;
    }

    private static boolean isOpenBracket(char ch) {
        return ch == '(' || ch == '[' || ch == '{';
    }

    private static boolean isCloseBracket(char ch) {
        return ch == ')' || ch == ']' || ch == '}';
    }

    private static char matchingOpen(char close) {
        return switch (close) {
            case ')' -> '(';
            case ']' -> '[';
            case '}' -> '{';
            default -> '\0';
        };
    }
}
