package language.syntax.syntax_checker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import language.syntax.syntax_checker.core.CheckContext;
import language.syntax.syntax_checker.core.Findings;
import language.syntax.syntax_checker.core.Rule;

/**
 * Sorts every finding into the four categories the user sees, and words them
 * for the gutter tooltip and the Command Window.
 *
 * <table>
 * <caption>The four categories</caption>
 * <tr><th>Category</th><th>What lands in it</th></tr>
 * <tr><td>Undefined Variable Error</td><td>a name used before anything defines it</td></tr>
 * <tr><td>Syntax Error</td><td>everything about the shape of the code: strings, ';', brackets,
 * absolute values, operators, powers, separators, assignments, sub/superscripts, script calls,
 * block headers and block structure</td></tr>
 * <tr><td>Unassigned Variable Error</td><td>{@code DD = ;}</td></tr>
 * <tr><td>Indentation Error</td><td>leading spaces only, including where a {@code ~~}
 * continuation line starts</td></tr>
 * </table>
 *
 * <h3>One issue per line per category</h3>
 * All findings of one category on one line become one {@link Issue} carrying
 * every message, in {@link Rule} order. The Command Window prints one row per
 * issue, and the number in "Run aborted: 3 error(s)" is always the number of
 * rows above it.
 *
 * <h3>Duplicates removed</h3>
 * {@code DD = ;} is also "an operator with no value after it" to the operator
 * check; when the assignment check has explained a line's {@code =}, the
 * operator check's note about that {@code =} is dropped.
 *
 * <p>
 * Line numbers are zero-based; {@link Issue#displayLine()} is one-based.
 */
public final class ErrorClassifier {

    /** The user-facing error categories, in the order they are listed. */
    public enum Category {
        UNDEFINED_VARIABLE("Undefined Variable Error", "Undefined Variable Errors"),
        SYNTAX("Syntax Error", "Syntax Errors"),
        UNASSIGNED_VARIABLE("Unassigned Variable Error", "Unassigned Variable Errors"),
        INDENTATION("Indentation Error", "Indentation Errors");

        private final String title;
        private final String plural;

        Category(String title, String plural) {
            this.title = title;
            this.plural = plural;
        }

        /** @return the heading shown to the user, e.g. "Syntax Error" */
        public String title() {
            return title;
        }

        /** @return the plural form for counters, e.g. "Syntax Errors" */
        public String plural() {
            return plural;
        }

        static Category of(Rule.Group group) {
            return switch (group) {
                case UNDEFINED_VARIABLE -> UNDEFINED_VARIABLE;
                case SYNTAX -> SYNTAX;
                case UNASSIGNED_VARIABLE -> UNASSIGNED_VARIABLE;
                case INDENTATION -> INDENTATION;
            };
        }
    }

    /** Whether an issue blocks a run. */
    public enum Severity {
        /** Blocks Run and Step; crimson bar. */
        ERROR,
        /** Reported but does not block; amber bar. No check raises one yet. */
        WARNING
    }

    /** One category of fault on one line. Immutable. */
    public static final class Issue {
        private final int line;
        private final Category category;
        private final Severity severity;
        private final List<String> messages;

        private Issue(int line, Category category, Severity severity, List<String> messages) {
            this.line = line;
            this.category = category;
            this.severity = severity;
            this.messages = Collections.unmodifiableList(messages);
        }

        /** @return the zero-based line index */
        public int line() {
            return line;
        }

        /** @return the one-based line number shown in the editor */
        public int displayLine() {
            return line + 1;
        }

        public Category category() {
            return category;
        }

        public Severity severity() {
            return severity;
        }

        public boolean isError() {
            return severity == Severity.ERROR;
        }

        /** @return every message for this line and category, at least one */
        public List<String> messages() {
            return messages;
        }

        /** @return the messages joined into one sentence list */
        public String message() {
            return String.join("; ", messages);
        }
    }

    /** Every issue in one document. Immutable. */
    public static final class Classification {
        private final List<Issue> issues;
        private final Map<Integer, List<Issue>> byLine;
        private final Map<Category, Integer> counts;
        private final int errorCount;
        private final int warningCount;

        private Classification(List<Issue> issues) {
            this.issues = Collections.unmodifiableList(issues);
            Map<Integer, List<Issue>> lines = new TreeMap<>();
            Map<Category, Integer> perCategory = new EnumMap<>(Category.class);
            for (Category category : Category.values()) {
                perCategory.put(category, 0);
            }
            int errors = 0;
            int warnings = 0;
            for (Issue issue : issues) {
                lines.computeIfAbsent(issue.line(), k -> new ArrayList<>()).add(issue);
                perCategory.merge(issue.category(), 1, Integer::sum);
                if (issue.isError()) {
                    errors++;
                } else {
                    warnings++;
                }
            }
            lines.replaceAll((k, v) -> Collections.unmodifiableList(v));
            this.byLine = Collections.unmodifiableMap(lines);
            this.counts = Collections.unmodifiableMap(perCategory);
            this.errorCount = errors;
            this.warningCount = warnings;
        }

        /** @return every issue, by line and then by category order */
        public List<Issue> issues() {
            return issues;
        }

        /**
         * @param line zero-based line index
         * @return that line's issues; empty when it is clean
         */
        public List<Issue> issuesOn(int line) {
            List<Issue> onLine = byLine.get(line);
            return onLine == null ? List.of() : onLine;
        }

        /** True when the line carries at least one blocking issue. */
        public boolean isErrorLine(int line) {
            for (Issue issue : issuesOn(line)) {
                if (issue.isError()) {
                    return true;
                }
            }
            return false;
        }

        /** True when the line carries issues but none of them blocks. */
        public boolean isWarningLine(int line) {
            return !issuesOn(line).isEmpty() && !isErrorLine(line);
        }

        /** @return how many issues fall in {@code category} */
        public int count(Category category) {
            return counts.getOrDefault(category, 0);
        }

        public int errorCount() {
            return errorCount;
        }

        public int warningCount() {
            return warningCount;
        }

        /** True when a run must be refused. */
        public boolean hasErrors() {
            return errorCount > 0;
        }
    }

    /** At most this many rows are printed in the Command Window; the rest are summarised. */
    public static final int CONSOLE_LIMIT = 50;

    /** The mark the backend prints before its own errors, used for ours too. */
    private static final String CROSS = "\u2716 ";

    private ErrorClassifier() {
    }

    // =====================================================================
    // Classification
    // =====================================================================

    /**
     * Classifies a document checked without a file context.
     *
     * @param code raw editor text (may be null)
     * @return the classification; never null
     */
    public static Classification classify(String code) {
        return classify(code, CheckContext.NONE);
    }

    /**
     * Classifies a document. Shares {@link ErrorChecker}'s cached run, so the
     * gutter asking once per line costs one analysis in total.
     *
     * @param code    raw editor text (may be null)
     * @param context the file the text belongs to
     * @return the classification; never null
     */
    public static Classification classify(String code, CheckContext context) {
        return ErrorChecker.check(code, context).classification();
    }

    /** Builds the classification from one run's findings. */
    static Classification fromFindings(Findings findings) {
        List<Issue> issues = new ArrayList<>();
        for (int line : findings.lines()) {
            Map<Rule, String> onLine = findings.on(line);
            boolean assignmentExplained = onLine.containsKey(Rule.ASSIGNMENT) || onLine.containsKey(Rule.UNASSIGNED);

            Map<Category, List<String>> grouped = new EnumMap<>(Category.class);
            for (Map.Entry<Rule, String> entry : onLine.entrySet()) {
                Rule rule = entry.getKey();
                String message = entry.getValue();
                if (rule == Rule.OPERATOR_SEQUENCE && assignmentExplained && message.contains("'='")) {
                    continue; // the assignment check already explained this '='
                }
                List<String> messages = grouped.computeIfAbsent(Category.of(rule.group()), k -> new ArrayList<>());
                if (!messages.contains(message)) {
                    messages.add(message);
                }
            }
            for (Map.Entry<Category, List<String>> entry : grouped.entrySet()) {
                issues.add(new Issue(line, entry.getKey(), Severity.ERROR, entry.getValue()));
            }
        }
        return new Classification(issues);
    }

    // =====================================================================
    // Command Window report
    // =====================================================================

    /**
     * The block printed in the Command Window when a run is refused:
     *
     * <pre>
     * ✖ Unassigned Variable Error (line 9): 'DD' is declared but never given a value
     * ✖ Syntax Error (line 11): ';' is not allowed inside publish(...)
     * Run aborted: 2 error(s) in t9_isolate3.nc (1 Syntax, 1 Unassigned Variable).
     * </pre>
     *
     * @param classification the file's issues
     * @param fileName       the name to show, e.g. {@code t9_isolate3.nc}
     * @param action         what was refused, e.g. {@code "Run"} or {@code "Step"}
     * @return the report, every line ending in a newline; empty when there are no errors
     */
    public static String consoleReport(Classification classification, String fileName, String action) {
        if (classification == null || !classification.hasErrors()) {
            return "";
        }

        StringBuilder out = new StringBuilder();
        int printed = 0;
        for (Issue issue : classification.issues()) {
            if (!issue.isError()) {
                continue;
            }
            if (printed == CONSOLE_LIMIT) {
                int rest = classification.errorCount() - printed;
                out.append("  ... and ").append(rest).append(" more error(s); see the crimson markers in the editor.\n");
                break;
            }
            out.append(CROSS).append(issue.category().title())
                    .append(" (line ").append(issue.displayLine()).append("): ")
                    .append(issue.message()).append('\n');
            printed++;
        }

        out.append(action == null || action.isBlank() ? "Run" : action).append(" aborted: ")
                .append(classification.errorCount()).append(" error(s)");
        if (fileName != null && !fileName.isBlank()) {
            out.append(" in ").append(fileName);
        }
        out.append(" (").append(tally(classification)).append(").\n");
        return out.toString();
    }

    /** "2 Syntax, 1 Undefined Variable" -- the categories that occur, in enum order. */
    private static String tally(Classification classification) {
        StringBuilder text = new StringBuilder();
        for (Category category : Category.values()) {
            int count = classification.count(category);
            if (count == 0) {
                continue;
            }
            if (text.length() > 0) {
                text.append(", ");
            }
            String title = category.title();
            text.append(count).append(' ').append(title, 0, title.length() - " Error".length());
        }
        return text.toString();
    }
}
