package language.syntax.textcolours;

/**
 * FUNCTION AND CLASS KEYWORDS -- class {@code tc-function-class}.
 *
 * <p>
 * The declaration words and their closers. The function and class
 * <i>names</i> are not here: a name takes the function-call colour where it
 * is called (see {@code SyntaxPalette.userFunctionNames}). Colour: the
 * {@code .tc-function-class} block in {@code themes/texts/text_light.css}
 * and {@code text_dark.css}.
 * </p>
 */
public final class FunctionClassKeywords {

    private FunctionClassKeywords() {
    }

    /** Whole words. */
    public static final String[] WORDS = {
            "function", "class", "fnend", "csend"
    };

    /** Method modifiers, same colour as {@code function}. */
    public static final String[] MODIFIERS = {
            "private", "protected", "abstract"
    };
}
