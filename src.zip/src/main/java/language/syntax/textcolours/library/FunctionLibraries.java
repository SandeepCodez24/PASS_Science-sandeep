package language.syntax.textcolours.library;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * The list of library files in this folder. The one place that knows them.
 *
 * <h3>Adding a library (say Fourier)</h3>
 * <ol>
 * <li>Copy {@link NumpyFunctions} to {@code FourierFunctions.java} and fill in
 * its {@code ENTRIES}.</li>
 * <li>Add {@code FourierFunctions.ENTRIES} to {@link #ALL} below.</li>
 * </ol>
 * That is all: {@code FunctionProvider} registers every entry for the
 * suggestion box, and {@code SyntaxPalette} colours every name.
 */
public final class FunctionLibraries {

    private FunctionLibraries() {
    }

    /** Every library, in the order the suggestion box receives them. */
    public static final List<String[][]> ALL = List.of(
            NumpyFunctions.ENTRIES,
            ScipyFunctions.ENTRIES);

    /** @return every {signature, description} pair from every library */
    public static List<String[]> entries() {
        List<String[]> out = new ArrayList<>();
        for (String[][] library : ALL) {
            for (String[] entry : library) {
                if (entry != null && entry.length >= 1 && entry[0] != null && !entry[0].isBlank()) {
                    out.add(entry);
                }
            }
        }
        return out;
    }

    /** @return the bare names, {@code "det(A)"} becoming {@code "det"} */
    public static Set<String> names() {
        Set<String> names = new LinkedHashSet<>();
        for (String[] entry : entries()) {
            String signature = entry[0].trim();
            int paren = signature.indexOf('(');
            names.add(paren < 0 ? signature : signature.substring(0, paren).trim());
        }
        return names;
    }
}
