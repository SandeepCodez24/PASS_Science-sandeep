package language.syntax.textcolours.library;

/**
 * SciPy-style function names.
 *
 * <p>
 * Same shape as {@link NumpyFunctions}: one {signature, description} line
 * per function, offered by the suggestion box and painted in the
 * function-call colour ({@code .tc-function-call}) where it is called.
 * </p>
 */
public final class ScipyFunctions {

    private ScipyFunctions() {
    }

    /** {signature, description} */
    public static final String[][] ENTRIES = {
            { "erf(x)", "SciPy: error function" },
            { "gamma(x)", "SciPy: gamma function" },
    };
}
