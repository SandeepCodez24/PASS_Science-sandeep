package language.syntax.textcolours.library;

/**
 * NumPy-style function names.
 *
 * <p>
 * One line per function: the signature the suggestion box inserts and the
 * description it shows. Every name here is offered by the suggestion box
 * and painted in the function-call colour ({@code .tc-function-call}) where
 * it is called. Adding a line is the whole job.
 * </p>
 *
 * <p>
 * A name that another list already registers (for example {@code sin} in
 * {@code trigonometric_list}) is shown once; {@code FunctionProvider} skips
 * duplicates.
 * </p>
 */
public final class NumpyFunctions {

    private NumpyFunctions() {
    }

    /** {signature, description} */
    public static final String[][] ENTRIES = {
            { "sin(x)", "NumPy: sine of x (radians)" },
            { "cos(x)", "NumPy: cosine of x (radians)" },
            { "det(A)", "NumPy: determinant of a square matrix" },
            { "transpose(A)", "NumPy: transpose of a matrix" },
    };
}
