package language.syntax.textcolours;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The standard ("factory") text colours, read from the two text
 * stylesheets so the CSS stays the one place they are written.
 *
 * <pre>
 *   /themes/texts/text_light.css   colour, bold, italic for a light editor
 *   /themes/texts/text_dark.css    colour for a dark editor
 * </pre>
 *
 * <p>
 * The Text Colours window shows these as the starting values and puts them
 * back on "Reset to factory". Change a colour in the CSS and the window
 * follows on the next launch; nothing in Java needs editing.
 * </p>
 *
 * <p>
 * The same files also hold the Command Window's output and prompt colours
 * ({@code .console-output}, {@code .console-prompt}); read them with
 * {@link #style(String)}.
 * </p>
 *
 * <p>
 * If a file or a block is missing, the category falls back to a neutral
 * grey and the problem is reported once on {@code System.err}, so a typo in
 * the CSS can never stop the editor from opening.
 * </p>
 */
public final class TextColourFactory {

    public static final String LIGHT_CSS = "/themes/texts/text_light.css";
    public static final String DARK_CSS = "/themes/texts/text_dark.css";

    /** One category's standard look. */
    public record Style(String lightHex, String darkHex, boolean bold, boolean italic) {
    }

    private static final String FALLBACK_LIGHT = "#333333";
    private static final String FALLBACK_DARK = "#D4D4D4";

    /** Command Window output text. */
    public static final String CONSOLE_OUTPUT = "console-output";
    /** Command Window prompt, {@code >>}. */
    public static final String CONSOLE_PROMPT = "console-prompt";

    private static final Map<String, Style> CACHE = new HashMap<>();
    private static String lightCss;
    private static String darkCss;

    private TextColourFactory() {
    }

    /**
     * @param category a category
     * @return its standard look; never null
     */
    public static Style style(TextCategory category) {
        return style(category.styleClass());
    }

    /**
     * @param cssClass a class with a block in both text stylesheets, e.g.
     *                 {@code tc-loop} or {@link #CONSOLE_OUTPUT}
     * @return its standard look; never null
     */
    public static synchronized Style style(String cssClass) {
        if (lightCss == null) {
            lightCss = stripComments(read(LIGHT_CSS));
            darkCss = stripComments(read(DARK_CSS));
        }
        return CACHE.computeIfAbsent(cssClass, TextColourFactory::load);
    }

    /** Forgets the cached values; the next call reads the files again. */
    public static synchronized void reload() {
        CACHE.clear();
        lightCss = null;
        darkCss = null;
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static Style load(String cssClass) {
        String lightBlock = block(lightCss, cssClass);
        String darkBlock = block(darkCss, cssClass);
        if (lightBlock == null || darkBlock == null) {
            System.err.println("Text colours: no ." + cssClass + " block in "
                    + (lightBlock == null ? LIGHT_CSS : DARK_CSS) + "; using grey.");
        }
        String lightHex = fill(lightBlock, FALLBACK_LIGHT);
        String darkHex = darkBlock == null ? TextColourMath.darkVariant(lightHex)
                : fill(darkBlock, FALLBACK_DARK);
        boolean bold = lightBlock != null && value(lightBlock, "-fx-font-weight").equals("bold");
        boolean italic = lightBlock != null && value(lightBlock, "-fx-font-style").equals("italic");
        return new Style(lightHex, darkHex, bold, italic);
    }

    private static String stripComments(String css) {
        return css.replaceAll("(?s)/\\*.*?\\*/", "");
    }

    private static String read(String resource) {
        try (InputStream in = TextColourFactory.class.getResourceAsStream(resource)) {
            if (in == null) {
                System.err.println("Text colours: stylesheet not on the classpath: " + resource);
                return "";
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            System.err.println("Text colours: could not read " + resource + ": " + ex.getMessage());
            return "";
        }
    }

    /** The body of the rule whose selector ends in {@code .text.<class>}. */
    private static String block(String css, String cssClass) {
        Matcher m = Pattern.compile("\\.text\\." + Pattern.quote(cssClass) + "\\s*\\{([^}]*)\\}")
                .matcher(css);
        return m.find() ? m.group(1) : null;
    }

    private static String fill(String block, String fallback) {
        if (block == null) {
            return fallback;
        }
        String hex = TextColourMath.normalise(value(block, "-fx-fill"));
        return hex == null ? fallback : hex;
    }

    private static String value(String block, String property) {
        Matcher m = Pattern.compile(Pattern.quote(property) + "\\s*:\\s*([^;]+);").matcher(block);
        return m.find() ? m.group(1).trim().toLowerCase() : "";
    }
}
