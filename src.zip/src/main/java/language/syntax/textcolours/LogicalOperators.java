package language.syntax.textcolours;

/**
 * LOGICAL OPERATORS -- class {@code tc-logical}.
 *
 * <p>
 * Colour: the {@code .tc-logical} block in {@code themes/texts/text_light.css}
 * and {@code text_dark.css}.
 * </p>
 *
 * <p>
 * {@code ||} is shared with the double absolute value {@code ||v||}. The
 * tokenizer reads it as OR only when a value stands on both sides of it
 * ({@code a || b}); otherwise it is an absolute-value bar and takes the
 * primitive colour.
 * </p>
 */
public final class LogicalOperators {

    private LogicalOperators() {
    }

    /** Matched literally, longest first. */
    public static final String[] SYMBOLS = {
            "&&", "||", "!&", "!|"
    };

    /**
     * Whole words. {@code not} on its own (as in {@code not(x)}); the phrases
     * {@code if not} and {@code while not} are loop words, see
     * {@link LoopKeywords#PHRASES}.
     */
    public static final String[] WORDS = {
            "is_in", "is_not_in", "is_nan", "is_empty", "not"
    };
}
