package language.syntax.textcolours;

/**
 * OTHER KEYWORDS -- class {@code tc-other}.
 *
 * <p>
 * Flow words that are neither a block nor an operator. Colour: the
 * {@code .tc-other} block in {@code themes/texts/text_light.css} and
 * {@code text_dark.css}.
 * </p>
 */
public final class OtherKeywords {

    private OtherKeywords() {
    }

    /** Whole words. */
    public static final String[] WORDS = {
            "break", "continue", "pass", "return"
    };
}
