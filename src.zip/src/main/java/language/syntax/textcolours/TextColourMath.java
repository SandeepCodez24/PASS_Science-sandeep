package language.syntax.textcolours;

import java.util.Locale;

/**
 * Turns one text colour into its dark-theme partner.
 *
 * <h3>The rule</h3>
 * <p>
 * A colour chosen for a white page is usually too dark for the dark editor
 * ({@code #1F4063} navy is all but invisible on {@code #1E1E1E}). The dark
 * partner keeps the colour's <b>hue</b> -- so navy stays a blue, olive stays
 * a green -- and raises its lightness until it stands out from the dark
 * background about as clearly as the original stands out from white:
 * </p>
 *
 * <pre>
 *   light contrast = contrast(colour, #FFFFFF)                (WCAG ratio)
 *   dark target    = clamp(light contrast x 0.85, 5.5, 12.5)   normal colours
 *                  = max(3.0, light contrast x 1.6)            soft colours
 *                                                  (light contrast below 3.5)
 *   dark partner   = same hue, saturation x 0.9, and the lowest lightness
 *                    whose contrast with #1E1E1E reaches the target
 * </pre>
 *
 * <p>
 * So a strong colour stays strong (near-black variables become near-white),
 * every normal colour is at least comfortably readable, a deliberately soft
 * colour (mild grey comments) stays soft, and every category keeps its
 * place relative to the others.
 * </p>
 *
 * <p>
 * Used two ways: the Text Colours window derives the dark colour from the
 * user's single choice, and the standard {@code text_dark.css} values were
 * produced by the same rule (they can be hand-tuned there afterwards).
 * Plain Java, no JavaFX, so it can be tested on its own.
 * </p>
 */
public final class TextColourMath {

    /** The dark editor's background the partner is measured against. */
    public static final String DARK_BACKGROUND = "#1E1E1E";
    /** The light editor's background. */
    public static final String LIGHT_BACKGROUND = "#FFFFFF";

    private static final double CONTRAST_SCALE = 0.85;
    private static final double MIN_TARGET = 5.5;
    private static final double MAX_TARGET = 12.5;
    /** Below this contrast on white a colour is treated as deliberately soft. */
    private static final double SOFT_LIMIT = 3.5;
    private static final double SOFT_SCALE = 1.6;
    private static final double SOFT_MIN_TARGET = 3.0;
    private static final double SATURATION_SCALE = 0.9;
    private static final double MAX_LIGHTNESS = 0.93;

    private TextColourMath() {
    }

    /**
     * @param lightHex a colour for the light theme, {@code #RRGGBB}
     * @return its dark-theme partner, {@code #RRGGBB}
     */
    public static String darkVariant(String lightHex) {
        double[] rgb = parse(lightHex);
        double[] bg = parse(DARK_BACKGROUND);
        double lightContrast = contrast(rgb, parse(LIGHT_BACKGROUND));
        double target = lightContrast < SOFT_LIMIT
                ? Math.max(SOFT_MIN_TARGET, lightContrast * SOFT_SCALE)
                : Math.max(MIN_TARGET, Math.min(MAX_TARGET, lightContrast * CONTRAST_SCALE));

        double[] hsl = toHsl(rgb);
        double h = hsl[0];
        double s = hsl[1] * SATURATION_SCALE;

        // Climb from the background's own lightness: the first lightness that
        // reaches the target is the partner, so it is never brighter than it
        // needs to be.
        double l = toHsl(bg)[2];
        double[] candidate = fromHsl(h, s, l);
        while (contrast(candidate, bg) < target && l < MAX_LIGHTNESS) {
            l = Math.min(MAX_LIGHTNESS, l + 0.004);
            candidate = fromHsl(h, s, l);
        }
        return hex(candidate);
    }

    /**
     * @param a {@code #RRGGBB}
     * @param b {@code #RRGGBB}
     * @return the WCAG contrast ratio, 1 to 21
     */
    public static double contrast(String a, String b) {
        return contrast(parse(a), parse(b));
    }

    /**
     * @param hex any {@code #RGB} or {@code #RRGGBB}, with or without {@code #}
     * @return the same colour as upper-case {@code #RRGGBB}, or null if it is
     *         not a colour
     */
    public static String normalise(String hex) {
        try {
            return hex(parse(hex));
        } catch (RuntimeException ex) {
            return null;
        }
    }

    // =====================================================================
    // Internals
    // =====================================================================

    static double[] parse(String hex) {
        String h = hex.trim();
        if (h.startsWith("#")) {
            h = h.substring(1);
        }
        if (h.length() == 3) {
            h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
        }
        if (h.length() != 6) {
            throw new IllegalArgumentException("Not a colour: " + hex);
        }
        int v = Integer.parseInt(h, 16);
        return new double[] { ((v >> 16) & 0xFF) / 255.0, ((v >> 8) & 0xFF) / 255.0, (v & 0xFF) / 255.0 };
    }

    static String hex(double[] rgb) {
        return String.format(Locale.ROOT, "#%02X%02X%02X",
                (int) Math.round(clamp(rgb[0]) * 255),
                (int) Math.round(clamp(rgb[1]) * 255),
                (int) Math.round(clamp(rgb[2]) * 255));
    }

    private static double contrast(double[] a, double[] b) {
        double la = luminance(a);
        double lb = luminance(b);
        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
    }

    private static double luminance(double[] rgb) {
        return 0.2126 * channel(rgb[0]) + 0.7152 * channel(rgb[1]) + 0.0722 * channel(rgb[2]);
    }

    private static double channel(double v) {
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    }

    private static double[] toHsl(double[] rgb) {
        double r = rgb[0], g = rgb[1], b = rgb[2];
        double max = Math.max(r, Math.max(g, b));
        double min = Math.min(r, Math.min(g, b));
        double l = (max + min) / 2;
        double h = 0;
        double s = 0;
        if (max != min) {
            double d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            if (max == r) {
                h = (g - b) / d + (g < b ? 6 : 0);
            } else if (max == g) {
                h = (b - r) / d + 2;
            } else {
                h = (r - g) / d + 4;
            }
            h /= 6;
        }
        return new double[] { h, s, l };
    }

    private static double[] fromHsl(double h, double s, double l) {
        if (s == 0) {
            return new double[] { l, l, l };
        }
        double q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        double p = 2 * l - q;
        return new double[] { hue(p, q, h + 1.0 / 3), hue(p, q, h), hue(p, q, h - 1.0 / 3) };
    }

    private static double hue(double p, double q, double t) {
        if (t < 0) {
            t += 1;
        }
        if (t > 1) {
            t -= 1;
        }
        if (t < 1.0 / 6) {
            return p + (q - p) * 6 * t;
        }
        if (t < 1.0 / 2) {
            return q;
        }
        if (t < 2.0 / 3) {
            return p + (q - p) * (2.0 / 3 - t) * 6;
        }
        return p;
    }

    private static double clamp(double v) {
        return Math.max(0, Math.min(1, v));
    }
}
