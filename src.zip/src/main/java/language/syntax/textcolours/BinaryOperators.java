package language.syntax.textcolours;

/**
 * BINARY OPERATORS -- class {@code tc-binary}.
 *
 * <p>
 * Comparison symbols, plus the three command words that share this colour.
 * Colour: the {@code .tc-binary} block in {@code themes/texts/text_light.css}
 * and {@code text_dark.css}.
 * </p>
 */
public final class BinaryOperators {

    private BinaryOperators() {
    }

    /** Matched literally, longest first ({@code <=} before {@code <}). */
    public static final String[] SYMBOLS = {
            "==", "!=", "<", ">", "<=", ">="
    };

    /** Whole words. {@code publish(...)}, {@code clear}, {@code cls}. */
    public static final String[] WORDS = {
            "publish", "clear", "cls"
    };
}
