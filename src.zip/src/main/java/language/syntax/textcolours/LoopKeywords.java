package language.syntax.textcolours;

/**
 * LOOPS AND CONDITIONS -- class {@code tc-loop}.
 *
 * <p>
 * Every opener, branch and closer, so a {@code for ... fend} block colours
 * both ends. Colour: the {@code .tc-loop} block in
 * {@code themes/texts/text_light.css} and {@code text_dark.css}.
 * </p>
 */
public final class LoopKeywords {

    private LoopKeywords() {
    }

    /**
     * Two-word openers, coloured as one phrase. Tried before the single words,
     * so {@code if not} never splits into a loop {@code if} and a logical
     * {@code not}. Any amount of space between the two words is accepted.
     */
    public static final String[] PHRASES = {
            "if not", "while not"
    };

    /** Single words. */
    public static final String[] WORDS = {
            "if", "elseif", "else", "for", "while",
            "iend", "fend", "wend"
    };
}
