package language.syntax.textcolours;

/**
 * DATA CONVERSION OPERATORS -- class {@code tc-conversion}.
 *
 * <p>
 * Coloured only where called, {@code int(x)}, so a variable that happens to
 * be named {@code string} keeps the variable colour. Colour: the
 * {@code .tc-conversion} block in {@code themes/texts/text_light.css} and
 * {@code text_dark.css}.
 * </p>
 */
public final class ConversionOperators {

    private ConversionOperators() {
    }

    /** Called words. */
    public static final String[] WORDS = {
            "int", "float", "string", "dec2rad", "rad2dec", "abs"
    };
}
