package language.syntax.textcolours;

/**
 * The colour categories of Neural Code text, one per row of the Settings &gt;
 * Text Colours window and one per block in the text stylesheets.
 *
 * <pre>
 *   category          CSS class            words / symbols live in
 *   ----------------  -------------------  ------------------------------
 *   VARIABLE          tc-variable          (everything not claimed below,
 *                                           including = , ; : ~~ ( ) [ ])
 *   NUMBER            tc-number            (pattern in SyntaxPalette)
 *   STRING            tc-string            (pattern in SyntaxPalette)
 *   PRIMITIVE         tc-primitive         PrimitiveOperators.java
 *   BINARY            tc-binary            BinaryOperators.java
 *   LOGICAL           tc-logical           LogicalOperators.java
 *   CONVERSION        tc-conversion        ConversionOperators.java
 *   LOOP              tc-loop              LoopKeywords.java
 *   FUNCTION_CLASS    tc-function-class    FunctionClassKeywords.java
 *   OTHER             tc-other             OtherKeywords.java
 *   FUNCTION_CALL     tc-function-call     FunctionProvider lists +
 *                                           library/*.java + user functions
 *   COMMENT           tc-comment           (# and \\ lines)
 * </pre>
 *
 * <h3>Where the colours are</h3>
 * <p>
 * Not here. The standard colours are in
 * {@code src/main/resources/themes/texts/text_light.css} and its twin
 * {@code text_dark.css}, one block per category, found by the class name
 * in the second column above. This enum only names the categories.
 * </p>
 *
 * <h3>Adding a category</h3>
 * <ol>
 * <li>Add a constant here (its row appears in the Text Colours window by
 * itself).</li>
 * <li>Add its word file next to this one and its pattern in
 * {@code SyntaxPalette} / its group in {@code UPITokenMaker}.</li>
 * <li>Add one block for its class to each of the two text stylesheets.</li>
 * </ol>
 *
 * <h3>Legacy class</h3>
 * <p>
 * Every span also carries the class the tokenizer used before this
 * scheme ({@code identifier}, {@code conditional}, {@code primitive},
 * {@code builtin-function}, ...). Nothing colours those any more; they are
 * kept so code that still looks for them (printing, for one) keeps working.
 * </p>
 */
public enum TextCategory {

    VARIABLE("tc-variable", "identifier", "Variables",
            "count  =  ;  :  ~~",
            "Names, plus = , ; : ~~ and brackets"),
    NUMBER("tc-number", "number", "Integers & Floats",
            "42  3.14  6.02e23",
            "Integer, decimal and scientific numbers"),
    STRING("tc-string", "string", "Strings",
            "\"text\"  'text'",
            "Text inside \" \" or ' '"),
    PRIMITIVE("tc-primitive", "primitive", "Primitives",
            "+ ^ ! |x| sqrt logb2",
            "+ - * / ^ // % !  |x|  sqr sqrt cube cbrt e^ log logbX  true false null"),
    BINARY("tc-binary", "operator", "Binary Operators",
            "==  <=  publish  cls",
            "== != < > <= >=  and publish clear cls"),
    LOGICAL("tc-logical", "operator", "Logical Operators",
            "&&  ||  !&  is_in",
            "&& || !& !|  is_in is_not_in is_nan is_empty not"),
    CONVERSION("tc-conversion", "builtin-function", "Data Conversion",
            "int  float  abs",
            "int float string dec2rad rad2dec abs (when called)"),
    LOOP("tc-loop", "conditional", "Loops & Conditions",
            "if not  while  fend",
            "if, if not, elseif, else, for, while, while not and iend fend wend"),
    FUNCTION_CLASS("tc-function-class", "conditional", "Function & Class",
            "function  class  fnend",
            "function class fnend csend  (and private protected abstract)"),
    OTHER("tc-other", "conditional", "Others",
            "break  continue  pass",
            "break continue pass return"),
    FUNCTION_CALL("tc-function-call", "builtin-function", "Function Calls",
            "sin()  det()  area()",
            "Built-in, NumPy / SciPy and your own functions where they are called"),
    COMMENT("tc-comment", "comment", "Comments",
            "# note  \\\\ off",
            "Lines and line ends after # or \\\\");

    private final String styleClass;
    private final String legacyClass;
    private final String label;
    private final String sample;
    private final String description;

    TextCategory(String styleClass, String legacyClass, String label, String sample, String description) {
        this.styleClass = styleClass;
        this.legacyClass = legacyClass;
        this.label = label;
        this.sample = sample;
        this.description = description;
    }

    /** @return the CSS class the tokenizer gives this category, e.g. {@code tc-loop} */
    public String styleClass() {
        return styleClass;
    }

    /** @return the class the tokenizer used before; see the class notes */
    public String legacyClass() {
        return legacyClass;
    }

    /** @return the row label in the Text Colours window */
    public String label() {
        return label;
    }

    /** @return a short sample drawn in the category's colour */
    public String sample() {
        return sample;
    }

    /** @return what the category covers, for the tooltip */
    public String description() {
        return description;
    }

    /**
     * @param styleClass a CSS class
     * @return the category that owns it, or null
     */
    public static TextCategory fromStyleClass(String styleClass) {
        for (TextCategory c : values()) {
            if (c.styleClass.equals(styleClass)) {
                return c;
            }
        }
        return null;
    }
}
