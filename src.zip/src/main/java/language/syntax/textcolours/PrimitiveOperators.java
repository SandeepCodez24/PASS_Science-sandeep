package language.syntax.textcolours;

/**
 * PRIMITIVES -- class {@code tc-primitive}.
 *
 * <p>
 * Add or remove entries in the arrays below; nothing else needs editing.
 * The colour is the {@code .tc-primitive} block in
 * {@code themes/texts/text_light.css} and {@code text_dark.css}.
 * </p>
 *
 * <pre>
 *   symbols      +  -  *  /  ^  //  %  !
 *   abs bars     |x|   (a single | ; || is decided in the tokenizer)
 *   called       sqr( sqrt( cube( cbrt( log(
 *   exponent     e^         coloured as one token
 *   any-base log logbX(     logb2(8), logb10(x), logbE(x) ... X is anything
 *                           written between "logb" and "("
 *   values       true  false  null
 * </pre>
 */
public final class PrimitiveOperators {

    private PrimitiveOperators() {
    }

    /**
     * Symbol primitives, matched literally. Order does not matter: they are
     * sorted longest first when the pattern is built, so {@code //} always
     * wins over {@code /}. {@code !} here is factorial; {@code !=},
     * {@code !&} and {@code !|} belong to other categories and are tried
     * first.
     */
    public static final String[] SYMBOLS = {
            "+", "-", "*", "/", "^", "//", "%", "!"
    };

    /** The absolute-value bar, {@code |x|}. */
    public static final String ABSOLUTE_BAR = "|";

    /** Word primitives, coloured only where called: {@code sqrt(R)}. */
    public static final String[] CALLED_WORDS = {
            "sqr", "sqrt", "cube", "cbrt", "log"
    };

    /** Coloured as one token, {@code e^}, so {@code e^(x)} reads as one primitive. */
    public static final String EXPONENT_PREFIX = "e^";

    /**
     * The any-base logarithm: {@code logb} followed by any base and then
     * {@code (}. {@code logb4(4)}, {@code logb2.5(x)}, {@code logbE(x)}.
     */
    public static final String LOG_BASE_PREFIX = "logb";

    /** Constant values. */
    public static final String[] VALUES = {
            "true", "false", "null"
    };
}
