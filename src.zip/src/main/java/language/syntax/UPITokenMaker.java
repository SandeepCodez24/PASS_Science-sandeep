package language.syntax;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

import language.syntax.textcolours.TextCategory;

/**
 * Splits Neural Code text into coloured spans.
 *
 * <p>
 * Nothing to configure here. Which words go in which category is in
 * {@code language/syntax/textcolours/}; the patterns are built by
 * {@link SyntaxPalette}; the colours are in
 * {@code themes/texts/text_light.css} and {@code text_dark.css}.
 * </p>
 *
 * <h3>Every character gets a category</h3>
 * <p>
 * Text no pattern claims ({@code =}, {@code ,}, {@code ;}, {@code :},
 * {@code ~~}, brackets, spaces) is given the variable class, so the variable
 * colour is the only "plain text" colour there is and changing it moves all
 * of them together.
 * </p>
 *
 * <h3>Order of the groups</h3>
 * <p>
 * At any position the first group that matches wins, so the order below is
 * the precedence: comments and strings first (nothing inside them is code),
 * then the word categories, then function names, numbers, the hidden
 * sub/superscript runs, and the symbol categories longest-meaning first --
 * {@code !=} (binary) and {@code !&} (logical) before {@code !} (factorial),
 * {@code ||} before {@code |}. A plain name is last.
 * </p>
 *
 * <h3>{@code ||}: OR or a double absolute value?</h3>
 * <p>
 * {@code ||v||} is a double absolute value; {@code a || b} is OR. A
 * {@code ||} with no value before it opens a double absolute value; the next
 * {@code ||} on the same line after a value closes it; any other {@code ||}
 * is OR. Absolute-value bars take the primitive colour.
 * </p>
 */
public class UPITokenMaker {

    // ── Hidden sub/superscript runs (unchanged) ────────────────────────────
    private static final String SUBSCRIPT_SINGLE_PATTERN = "‍[^‍\n]‍";
    private static final String SUBSCRIPT_SINGLE_GREEK_PATTERN = "‍[Ͱ-Ͽ஀-௿]‍";
    private static final String SUBSCRIPT_MULTI_PATTERN = "‍‍‍[^‍\n]+‍‍‍";
    private static final String SUBSCRIPT_MULTI_GREEK_PATTERN = "‍‍‍(?=[^‍]*[Ͱ-Ͽ஀-௿])"
            + "[a-zA-Z஀-௿₀₁₂₃₄₅₆₇₈₉Ͱ-Ͽ]+‍‍‍";
    private static final String SUPERSCRIPT_SINGLE_PATTERN = "‌[^‌\n]‌";
    private static final String SUPERSCRIPT_SINGLE_GREEK_PATTERN = "‌[Ͱ-Ͽ஀-௿]‌";
    private static final String SUPERSCRIPT_MULTI_PATTERN = "‌‌‌[^‌\n]+‌‌‌";
    private static final String SUPERSCRIPT_MULTI_GREEK_PATTERN = "‌‌‌(?=[^‌]*[Ͱ-Ͽ஀-௿])"
            + "[a-zA-Z஀-௿¹²³⁴⁵⁶⁷⁸⁹⁰"
            + "ᵃᵇᶜᵈᵉᶠᶢʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻᵝᵞᵟᵋᶿᶲᵡᵠͰ-Ͽ]+‌‌‌";

    private static final String SUB_SUPER_GROUPS =
            "(?<SUBSCRIPTMULTIGREEK>" + SUBSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTMULTI>" + SUBSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLEGREEK>" + SUBSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUBSCRIPTSINGLE>" + SUBSCRIPT_SINGLE_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTIGREEK>" + SUPERSCRIPT_MULTI_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTMULTI>" + SUPERSCRIPT_MULTI_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLEGREEK>" + SUPERSCRIPT_SINGLE_GREEK_PATTERN + ")"
                    + "|(?<SUPERSCRIPTSINGLE>" + SUPERSCRIPT_SINGLE_PATTERN + ")";

    private static final Pattern SUB_SUPER_PATTERN = Pattern.compile(SUB_SUPER_GROUPS);

    private static final String[] SUB_SUPER_NAMES = {
            "SUBSCRIPTMULTIGREEK", "SUBSCRIPTMULTI", "SUBSCRIPTSINGLEGREEK", "SUBSCRIPTSINGLE",
            "SUPERSCRIPTMULTIGREEK", "SUPERSCRIPTMULTI", "SUPERSCRIPTSINGLEGREEK", "SUPERSCRIPTSINGLE"
    };

    private static final String[] SUB_SUPER_CLASSES = {
            "subscript-greek-multi", "subscript-multi", "subscript-greek-single", "subscript-single",
            "superscript-greek-multi", "superscript-multi", "superscript-greek-single", "superscript-single"
    };

    // ── The one pattern. Built once; touching SyntaxPalette loads every
    //    category file and the FunctionProvider registry first. ────────────
    private static final Pattern PATTERN = Pattern.compile(
            "(?<COMMENT>" + SyntaxPalette.commentPattern() + ")"
                    + "|(?<STRING>" + SyntaxPalette.stringPattern() + ")"
                    + "|(?<LOOP>" + SyntaxPalette.loopPattern() + ")"
                    + "|(?<FNCLASS>" + SyntaxPalette.functionClassPattern() + ")"
                    + "|(?<OTHER>" + SyntaxPalette.otherPattern() + ")"
                    + "|(?<LOGICALWORD>" + SyntaxPalette.logicalWordPattern() + ")"
                    + "|(?<BINARYWORD>" + SyntaxPalette.binaryWordPattern() + ")"
                    + "|(?<CONVERSION>" + SyntaxPalette.conversionPattern() + ")"
                    + "|(?<LOGBASE>" + SyntaxPalette.logBasePattern() + ")"
                    + "|(?<EXPONENT>" + SyntaxPalette.exponentPattern() + ")"
                    + "|(?<PRIMWORD>" + SyntaxPalette.primitiveWordPattern() + ")"
                    + "|(?<PRIMVALUE>" + SyntaxPalette.primitiveValuePattern() + ")"
                    + "|(?<BUILTIN>" + SyntaxPalette.builtinFunctionPattern() + ")"
                    + "|(?<NUMBER>" + SyntaxPalette.numberPattern() + ")"
                    + "|" + SUB_SUPER_GROUPS
                    + "|(?<BINARYSYM>" + SyntaxPalette.binarySymbolPattern() + ")"
                    + "|(?<LOGICALSYM>" + SyntaxPalette.logicalSymbolPattern() + ")"
                    + "|(?<ABSBAR>" + SyntaxPalette.absoluteBarPattern() + ")"
                    + "|(?<PRIMSYM>" + SyntaxPalette.primitiveSymbolPattern() + ")"
                    + "|(?<IDENTIFIER>" + SyntaxPalette.identifierPattern() + ")");

    /** Group name to category, for the groups that map one to one. */
    private static final Object[][] SIMPLE_GROUPS = {
            { "STRING", TextCategory.STRING },
            { "LOOP", TextCategory.LOOP },
            { "FNCLASS", TextCategory.FUNCTION_CLASS },
            { "OTHER", TextCategory.OTHER },
            { "LOGICALWORD", TextCategory.LOGICAL },
            { "BINARYWORD", TextCategory.BINARY },
            { "CONVERSION", TextCategory.CONVERSION },
            { "LOGBASE", TextCategory.PRIMITIVE },
            { "EXPONENT", TextCategory.PRIMITIVE },
            { "PRIMWORD", TextCategory.PRIMITIVE },
            { "PRIMVALUE", TextCategory.PRIMITIVE },
            { "BUILTIN", TextCategory.FUNCTION_CALL },
            { "NUMBER", TextCategory.NUMBER },
            { "BINARYSYM", TextCategory.BINARY },
            { "ABSBAR", TextCategory.PRIMITIVE },
            { "PRIMSYM", TextCategory.PRIMITIVE },
    };

    private static final String DOUBLE_BAR = "||";

    /**
     * Styles the whole document. Works for any RichTextFX area (the editor's
     * {@code CodeArea}, or a {@code StyleClassedTextArea} in the Command
     * Window).
     *
     * @param text the whole document
     * @return the style spans; every span carries a {@code tc-*} class
     */
    public static StyleSpans<Collection<String>> computeHighlighting(String text) {
        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        if (text == null || text.isEmpty()) {
            spans.add(classes(TextCategory.VARIABLE), 0);
            return spans.create();
        }

        Matcher matcher = PATTERN.matcher(text);
        Set<String> userFunctions = SyntaxPalette.userFunctionNames(text);
        int lastEnd = 0;
        int openDoubleBars = 0;
        int barLine = -2;

        while (matcher.find()) {
            int start = matcher.start();
            int length = matcher.end() - start;
            if (start > lastEnd) {
                spans.add(classes(TextCategory.VARIABLE), start - lastEnd);
            }

            if (matcher.group("COMMENT") != null) {
                addCommentSpans(spans, matcher.group("COMMENT"));
            } else if (matcher.group("LOGICALSYM") != null) {
                // ||: OR, or the opening / closing of a double absolute value.
                TextCategory category = TextCategory.LOGICAL;
                if (DOUBLE_BAR.equals(matcher.group("LOGICALSYM"))) {
                    int line = text.lastIndexOf('\n', start - 1);
                    if (line != barLine) {
                        barLine = line;
                        openDoubleBars = 0;
                    }
                    if (!valueBefore(text, start)) {
                        openDoubleBars++;
                        category = TextCategory.PRIMITIVE;
                    } else if (openDoubleBars > 0) {
                        openDoubleBars--;
                        category = TextCategory.PRIMITIVE;
                    }
                }
                spans.add(classes(category), length);
            } else if (matcher.group("IDENTIFIER") != null) {
                boolean called = matcher.end() < text.length() && text.charAt(matcher.end()) == '('
                        && userFunctions.contains(matcher.group("IDENTIFIER"));
                spans.add(classes(called ? TextCategory.FUNCTION_CALL : TextCategory.VARIABLE), length);
            } else {
                String subSuper = subSuperClass(matcher);
                if (subSuper != null) {
                    spans.add(List.of(TextCategory.VARIABLE.styleClass(),
                            TextCategory.VARIABLE.legacyClass(), subSuper), length);
                } else {
                    spans.add(classes(simpleCategory(matcher)), length);
                }
            }
            lastEnd = matcher.end();
        }

        if (text.length() > lastEnd) {
            spans.add(classes(TextCategory.VARIABLE), text.length() - lastEnd);
        }
        return spans.create();
    }

    /**
     * @param category a category
     * @return the classes a span of it carries: its own and the legacy one
     */
    public static Collection<String> classes(TextCategory category) {
        return List.of(category.styleClass(), category.legacyClass());
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private static TextCategory simpleCategory(Matcher matcher) {
        for (Object[] g : SIMPLE_GROUPS) {
            if (matcher.group((String) g[0]) != null) {
                return (TextCategory) g[1];
            }
        }
        return TextCategory.VARIABLE;
    }

    private static String subSuperClass(Matcher matcher) {
        for (int i = 0; i < SUB_SUPER_NAMES.length; i++) {
            if (matcher.group(SUB_SUPER_NAMES[i]) != null) {
                return SUB_SUPER_CLASSES[i];
            }
        }
        return null;
    }

    /** True when the last non-space character before {@code index} ends a value. */
    private static boolean valueBefore(String text, int index) {
        int i = index - 1;
        while (i >= 0 && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) {
            i--;
        }
        if (i < 0 || text.charAt(i) == '\n') {
            return false;
        }
        char c = text.charAt(i);
        return Character.isLetterOrDigit(c) || c == '_' || c == ')' || c == ']'
                || c == '"' || c == '\'' || c == '!' || c == '|'
                || c == '‌' || c == '‍'
                || Character.getType(c) == Character.OTHER_NUMBER;
    }

    private static void addCommentSpans(StyleSpansBuilder<Collection<String>> spans, String commentText) {
        Matcher matcher = SUB_SUPER_PATTERN.matcher(commentText);
        int lastEnd = 0;
        while (matcher.find()) {
            if (matcher.start() > lastEnd) {
                spans.add(classes(TextCategory.COMMENT), matcher.start() - lastEnd);
            }
            spans.add(List.of(TextCategory.COMMENT.styleClass(), TextCategory.COMMENT.legacyClass(),
                    subSuperClass(matcher)), matcher.end() - matcher.start());
            lastEnd = matcher.end();
        }
        if (lastEnd < commentText.length()) {
            spans.add(classes(TextCategory.COMMENT), commentText.length() - lastEnd);
        }
    }
}
