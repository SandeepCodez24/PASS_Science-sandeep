package language.semantic;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;

/**
 * Splits Neural Code text into code, string-literal and comment segments, so
 * a rewrite meant for code never touches the inside of a string.
 *
 * <h3>Why this exists</h3>
 * The preprocessor used to encode the whole script, so
 * {@code கி = "சோழ நாடு";} reached the interpreter as
 * {@code var_tamil_ki = "var_tamil_choavar_tamil_zha var_tamil_Nhaavar_tamil_du";}.
 * Every rewrite that turns the visual form into the machine form
 * ({@link SemanticEncoder}, {@link ComplexLiteral}) now runs on
 * {@link Kind#CODE} segments only; strings and comments pass through
 * character for character.
 *
 * <h3>Rules (the same as the syntax checker's {@code SourceModel})</h3>
 * <ul>
 * <li>{@code "} and {@code '} both open a literal; only the quote that opened
 * it closes it, and a quote preceded by an odd number of backslashes is
 * escaped.</li>
 * <li>A literal ends at the end of its line, unless that line ends with the
 * {@code ~~} continuation, which carries the literal onto the next line.</li>
 * <li>{@code #} and {@code \\} start a comment only outside a literal; the
 * comment runs to the end of the line.</li>
 * </ul>
 * The quote characters belong to the string segment. Concatenating every
 * segment's text always gives back the input exactly.
 */
public final class CodeSegments {

    /** What a segment holds. */
    public enum Kind {
        /** Ordinary code: names, numbers, operators, newlines. */
        CODE,
        /** A string literal, quotes included. */
        STRING,
        /** A {@code #} or {@code \\} comment, up to (not including) the newline. */
        COMMENT
    }

    /**
     * One segment: {@code [start, end)} of the text it was cut from.
     *
     * @param kind  what it holds
     * @param start first offset
     * @param end   offset after the last character
     */
    public record Segment(Kind kind, int start, int end) {
        /**
         * @param source the text the segment was cut from
         * @return the segment's characters
         */
        public String text(String source) {
            return source.substring(start, end);
        }
    }

    private static final String CONTINUATION = "~~";

    private CodeSegments() {
    }

    /**
     * @param text any Neural Code text (a whole file or one line)
     * @return its segments in order; empty for null or empty text
     */
    public static List<Segment> split(String text) {
        List<Segment> out = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return out;
        }
        int n = text.length();
        int segStart = 0;
        Kind kind = Kind.CODE;
        char quote = 0;
        int i = 0;

        while (i < n) {
            char c = text.charAt(i);

            if (kind == Kind.STRING) {
                if (c == quote && !isEscaped(text, i)) {
                    i++;
                    add(out, Kind.STRING, segStart, i);
                    segStart = i;
                    kind = Kind.CODE;
                    continue;
                }
                if (c == '\n' && !lineContinues(text, i)) {
                    // Unterminated literal: it ends with its line.
                    add(out, Kind.STRING, segStart, i);
                    segStart = i;
                    kind = Kind.CODE;
                    continue; // the newline itself is code
                }
                i++;
                continue;
            }

            if (kind == Kind.COMMENT) {
                if (c == '\n') {
                    add(out, Kind.COMMENT, segStart, i);
                    segStart = i;
                    kind = Kind.CODE;
                    continue;
                }
                i++;
                continue;
            }

            // CODE
            if ((c == '"' || c == '\'') && !isEscaped(text, i)) {
                add(out, Kind.CODE, segStart, i);
                segStart = i;
                kind = Kind.STRING;
                quote = c;
                i++;
                continue;
            }
            if (c == '#' || (c == '\\' && i + 1 < n && text.charAt(i + 1) == '\\')) {
                add(out, Kind.CODE, segStart, i);
                segStart = i;
                kind = Kind.COMMENT;
                i++;
                continue;
            }
            i++;
        }
        add(out, kind, segStart, n);
        return out;
    }

    /**
     * Applies {@code rewrite} to every code segment and copies strings and
     * comments unchanged.
     *
     * @param text    the text
     * @param rewrite what to do with code
     * @return the rewritten text
     */
    public static String mapCode(String text, UnaryOperator<String> rewrite) {
        if (text == null || text.isEmpty()) {
            return text == null ? "" : text;
        }
        StringBuilder out = new StringBuilder(text.length() + 16);
        for (Segment segment : split(text)) {
            String piece = segment.text(text);
            out.append(segment.kind() == Kind.CODE ? rewrite.apply(piece) : piece);
        }
        return out.toString();
    }

    /**
     * @param text any text
     * @return true when the end of {@code text} lies inside a string literal
     */
    public static boolean endsInsideString(String text) {
        List<Segment> segments = split(text);
        if (segments.isEmpty()) {
            return false;
        }
        Segment last = segments.get(segments.size() - 1);
        if (last.kind() != Kind.STRING) {
            return false;
        }
        String literal = last.text(text);
        if (literal.length() < 2) {
            return true; // just the opening quote
        }
        char open = literal.charAt(0);
        int close = literal.length() - 1;
        return literal.charAt(close) != open || isEscaped(text, last.end() - 1);
    }

    // ─────────────────────────────────────────────────────────────────────

    private static void add(List<Segment> out, Kind kind, int start, int end) {
        if (end > start) {
            out.add(new Segment(kind, start, end));
        }
    }

    private static boolean isEscaped(String text, int index) {
        int count = 0;
        for (int i = index - 1; i >= 0 && text.charAt(i) == '\\'; i--) {
            count++;
        }
        return count % 2 != 0;
    }

    /** True when the line ending at {@code newline} ends with {@code ~~}. */
    private static boolean lineContinues(String text, int newline) {
        int end = newline;
        while (end > 0 && (text.charAt(end - 1) == ' ' || text.charAt(end - 1) == '\t'
                || text.charAt(end - 1) == '\r')) {
            end--;
        }
        return end >= CONTINUATION.length() && text.startsWith(CONTINUATION, end - CONTINUATION.length());
    }
}
