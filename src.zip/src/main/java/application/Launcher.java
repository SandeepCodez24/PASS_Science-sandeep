package application;

public class Launcher {
        public static void main(String[] args) {
        ui.design.Typography.configureTextRendering();
        Main.main(args);
    }
}

