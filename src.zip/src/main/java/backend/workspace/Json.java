package backend.workspace;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A small, strict JSON reader for the interpreter's protocol lines
 * ({@code WS_PROTOCOL.md}). It has no dependencies, so the backend package
 * needs no extra library.
 *
 * <p>The result uses plain Java types:
 * <ul>
 *   <li>object: {@code Map<String, Object>}, in document order, unmodifiable;</li>
 *   <li>array: {@code List<Object>}, unmodifiable;</li>
 *   <li>string: {@code String};</li>
 *   <li>number: {@code Long} when the text is an integer that fits, otherwise
 *       {@code Double};</li>
 *   <li>{@code true} or {@code false}: {@code Boolean};</li>
 *   <li>{@code null}: {@link #NULL}.</li>
 * </ul>
 * Malformed input throws {@link JsonException}. The protocol never sends
 * malformed JSON, so a failure means a corrupted line, and that line is
 * dropped.
 */
public final class Json {

    /** Stands for a JSON {@code null} (maps and lists cannot hold Java null here). */
    public static final Object NULL = new Object() {
        @Override
        public String toString() {
            return "null";
        }
    };

    /** Thrown for text that is not valid JSON. */
    public static final class JsonException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        JsonException(String message, int at) {
            super(message + " at offset " + at);
        }
    }

    /** Deepest nesting accepted, a guard against pathological input. */
    private static final int MAX_DEPTH = 512;

    private final String text;
    private int pos;

    private Json(String text) {
        this.text = text;
    }

    /**
     * Parses one JSON document.
     *
     * @param text the JSON text
     * @return the value, using the types listed in the class comment
     * @throws JsonException if the text is not exactly one valid JSON value
     */
    public static Object parse(String text) {
        if (text == null) {
            throw new JsonException("no input", 0);
        }
        Json p = new Json(text);
        p.skipSpace();
        Object value = p.readValue(0);
        p.skipSpace();
        if (p.pos != text.length()) {
            throw new JsonException("unexpected trailing text", p.pos);
        }
        return value;
    }

    /**
     * Parses a document that must be an object.
     *
     * @param text the JSON text
     * @return the object's members
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String text) {
        Object value = parse(text);
        if (!(value instanceof Map)) {
            throw new JsonException("expected an object", 0);
        }
        return (Map<String, Object>) value;
    }

    // ---- typed access helpers --------------------------------------------

    /** @return member {@code key} as a String, or {@code fallback} if missing or not a string */
    public static String str(Map<String, Object> obj, String key, String fallback) {
        Object v = obj == null ? null : obj.get(key);
        return v instanceof String ? (String) v : fallback;
    }

    /** @return member {@code key} as a long, or {@code fallback} */
    public static long num(Map<String, Object> obj, String key, long fallback) {
        Object v = obj == null ? null : obj.get(key);
        return v instanceof Number ? ((Number) v).longValue() : fallback;
    }

    /** @return member {@code key} as a boolean, or {@code fallback} */
    public static boolean bool(Map<String, Object> obj, String key, boolean fallback) {
        Object v = obj == null ? null : obj.get(key);
        return v instanceof Boolean ? (Boolean) v : fallback;
    }

    /** @return member {@code key} as an object, or null */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Map<String, Object> obj, String key) {
        Object v = obj == null ? null : obj.get(key);
        return v instanceof Map ? (Map<String, Object>) v : null;
    }

    /** @return member {@code key} as an array, or an empty list */
    @SuppressWarnings("unchecked")
    public static List<Object> arr(Map<String, Object> obj, String key) {
        Object v = obj == null ? null : obj.get(key);
        return v instanceof List ? (List<Object>) v : Collections.emptyList();
    }

    /**
     * A protocol number, which may also be one of the strings the interpreter
     * uses for values JSON cannot express: "NaN", "Infinity", "-Infinity".
     *
     * @param v a parsed value
     * @return the double, or NaN if {@code v} is not a number
     */
    public static double toDouble(Object v) {
        if (v instanceof Number n) {
            return n.doubleValue();
        }
        if ("Infinity".equals(v)) {
            return Double.POSITIVE_INFINITY;
        }
        if ("-Infinity".equals(v)) {
            return Double.NEGATIVE_INFINITY;
        }
        return Double.NaN;
    }

    // ---- reader --------------------------------------------------------------

    private Object readValue(int depth) {
        if (depth > MAX_DEPTH) {
            throw new JsonException("nested too deeply", pos);
        }
        if (pos >= text.length()) {
            throw new JsonException("unexpected end", pos);
        }
        char c = text.charAt(pos);
        return switch (c) {
            case '{' -> readObject(depth);
            case '[' -> readArray(depth);
            case '"' -> readString();
            case 't' -> {
                expectWord("true");
                yield Boolean.TRUE;
            }
            case 'f' -> {
                expectWord("false");
                yield Boolean.FALSE;
            }
            case 'n' -> {
                expectWord("null");
                yield NULL;
            }
            default -> {
                if (c == '-' || (c >= '0' && c <= '9')) {
                    yield readNumber();
                }
                throw new JsonException("unexpected character '" + c + "'", pos);
            }
        };
    }

    private Map<String, Object> readObject(int depth) {
        pos++; // {
        Map<String, Object> out = new LinkedHashMap<>();
        skipSpace();
        if (peek() == '}') {
            pos++;
            return Collections.unmodifiableMap(out);
        }
        while (true) {
            skipSpace();
            if (peek() != '"') {
                throw new JsonException("expected a member name", pos);
            }
            String key = readString();
            skipSpace();
            expect(':');
            skipSpace();
            out.put(key, readValue(depth + 1));
            skipSpace();
            char c = next();
            if (c == '}') {
                return Collections.unmodifiableMap(out);
            }
            if (c != ',') {
                throw new JsonException("expected ',' or '}'", pos - 1);
            }
        }
    }

    private List<Object> readArray(int depth) {
        pos++; // [
        List<Object> out = new ArrayList<>();
        skipSpace();
        if (peek() == ']') {
            pos++;
            return Collections.unmodifiableList(out);
        }
        while (true) {
            skipSpace();
            out.add(readValue(depth + 1));
            skipSpace();
            char c = next();
            if (c == ']') {
                return Collections.unmodifiableList(out);
            }
            if (c != ',') {
                throw new JsonException("expected ',' or ']'", pos - 1);
            }
        }
    }

    private String readString() {
        pos++; // opening quote
        StringBuilder sb = null;
        int start = pos;
        while (true) {
            if (pos >= text.length()) {
                throw new JsonException("unterminated string", start);
            }
            char c = text.charAt(pos);
            if (c == '"') {
                String s = sb == null ? text.substring(start, pos) : sb.append(text, start, pos).toString();
                pos++;
                return s;
            }
            if (c == '\\') {
                if (sb == null) {
                    sb = new StringBuilder();
                }
                sb.append(text, start, pos);
                pos++;
                sb.append(readEscape());
                start = pos;
                continue;
            }
            if (c < 0x20) {
                throw new JsonException("control character in string", pos);
            }
            pos++;
        }
    }

    private char readEscape() {
        char c = next();
        return switch (c) {
            case '"' -> '"';
            case '\\' -> '\\';
            case '/' -> '/';
            case 'b' -> '\b';
            case 'f' -> '\f';
            case 'n' -> '\n';
            case 'r' -> '\r';
            case 't' -> '\t';
            case 'u' -> readUnicodeEscape();
            default -> throw new JsonException("bad escape '\\" + c + "'", pos - 1);
        };
    }

    /** The four hex digits of a backslash-u escape; {@link #pos} is on the first. */
    private char readUnicodeEscape() {
        if (pos + 4 > text.length()) {
            throw new JsonException("bad \\u escape", pos);
        }
        try {
            char u = (char) Integer.parseInt(text.substring(pos, pos + 4), 16);
            pos += 4;
            return u;
        } catch (NumberFormatException e) {
            throw new JsonException("bad \\u escape", pos);
        }
    }

    private Object readNumber() {
        int start = pos;
        if (peek() == '-') {
            pos++;
        }
        boolean integral = true;
        while (pos < text.length()) {
            char c = text.charAt(pos);
            if (c >= '0' && c <= '9') {
                pos++;
            } else if (c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') {
                integral = false;
                pos++;
            } else {
                break;
            }
        }
        String s = text.substring(start, pos);
        try {
            if (integral && s.length() <= 18) {
                return Long.valueOf(s);
            }
            return Double.valueOf(s);
        } catch (NumberFormatException e) {
            throw new JsonException("bad number '" + s + "'", start);
        }
    }

    private void expectWord(String word) {
        if (!text.startsWith(word, pos)) {
            throw new JsonException("expected '" + word + "'", pos);
        }
        pos += word.length();
    }

    private void expect(char c) {
        if (next() != c) {
            throw new JsonException("expected '" + c + "'", pos - 1);
        }
    }

    private char peek() {
        return pos < text.length() ? text.charAt(pos) : '\0';
    }

    private char next() {
        if (pos >= text.length()) {
            throw new JsonException("unexpected end", pos);
        }
        return text.charAt(pos++);
    }

    private void skipSpace() {
        while (pos < text.length()) {
            char c = text.charAt(pos);
            if (c != ' ' && c != '\t' && c != '\n' && c != '\r') {
                return;
            }
            pos++;
        }
    }
}
