package backend.analysis;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import backend.workspace.Json;

/**
 * The Computational / Execution History, kept on disk so it outlives the IDE:
 * {@code ~/.neuralcode/analysis_history.jsonl}, one finished run per line,
 * oldest first.
 *
 * <pre>
 *   {"v":1,"title":"grow.nc","started":"2026-11-05T14:32:10",
 *    "analysis":{...the @ANALYSIS summary...},"parmon":{...the @PARMON summary...}|null}
 * </pre>
 *
 * The documents are stored exactly as nc.exe sent them, so a later IDE reads
 * them with the same parsers. Only the newest {@code limit} runs are kept.
 * Not thread-safe: the hub calls it from its one background thread.
 */
final class AnalysisHistoryStore {

    private static final String FILE = "analysis_history.jsonl";

    private final Path file;
    private final int limit;

    /** Lines in the file as far as this store knows; the file is trimmed past twice the limit. */
    private int lines;

    /**
     * @param folder the IDE's data folder ({@code ~/.neuralcode})
     * @param limit  runs to keep
     */
    AnalysisHistoryStore(Path folder, int limit) {
        this.file = folder.resolve(FILE);
        this.limit = limit;
    }

    /**
     * @return the saved runs, newest first; empty when there are none or the file cannot be read
     */
    List<AnalysisRun> load() {
        List<String> all;
        try {
            all = Files.exists(file) ? Files.readAllLines(file, StandardCharsets.UTF_8) : List.of();
        } catch (IOException e) {
            return List.of();
        }
        lines = all.size();
        List<AnalysisRun> runs = new ArrayList<>();
        for (int i = all.size() - 1; i >= 0 && runs.size() < limit; i--) {
            AnalysisRun run = parse(all.get(i));
            if (run != null) {
                runs.add(run);
            }
        }
        if (lines > limit * 2) {
            rewrite(all.subList(all.size() - limit, all.size()));
        }
        return runs;
    }

    /**
     * Adds one finished run.
     *
     * @param title        what ran
     * @param started      when it started
     * @param analysisJson the {@code @ANALYSIS} document as sent
     * @param parmonJson   the {@code @PARMON} summary as sent, or null
     */
    void append(String title, LocalDateTime started, String analysisJson, String parmonJson) {
        String line = "{\"v\":1,\"title\":" + quote(title) + ",\"started\":" + quote(String.valueOf(started))
                + ",\"analysis\":" + analysisJson + ",\"parmon\":" + (parmonJson == null ? "null" : parmonJson) + "}";
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, line + "\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.APPEND);
            lines++;
            if (lines > limit * 2) {
                List<String> all = Files.readAllLines(file, StandardCharsets.UTF_8);
                rewrite(all.subList(Math.max(0, all.size() - limit), all.size()));
            }
        } catch (IOException e) {
            // History only: the run is still shown for this session.
        }
    }

    /** Forgets every saved run (Reset History). */
    void clear() {
        try {
            Files.deleteIfExists(file);
            lines = 0;
        } catch (IOException e) {
            // Nothing else depends on it.
        }
    }

    private void rewrite(List<String> keep) {
        try {
            Files.write(file, keep, StandardCharsets.UTF_8);
            lines = keep.size();
        } catch (IOException e) {
            // Trimming is housekeeping only.
        }
    }

    private static AnalysisRun parse(String line) {
        try {
            Map<String, Object> o = Json.parseObject(line);
            AnalysisReport report = AnalysisReport.fromMap(Json.obj(o, "analysis"));
            if (report == null) {
                return null;
            }
            ParmonReport parmon = ParmonReport.fromMap(Json.obj(o, "parmon"));
            LocalDateTime started;
            try {
                started = LocalDateTime.parse(Json.str(o, "started", ""));
            } catch (DateTimeParseException e) {
                started = null;
            }
            return new AnalysisRun(Json.str(o, "title", "command"), started, 0, report, List.of(), true,
                    parmon instanceof ParmonReport.Summary s ? s : null);
        } catch (Json.JsonException e) {
            return null;
        }
    }

    /** @return {@code text} as a JSON string */
    static String quote(String text) {
        String t = text == null ? "" : text;
        StringBuilder sb = new StringBuilder(t.length() + 2).append('"');
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.append('"').toString();
    }
}
