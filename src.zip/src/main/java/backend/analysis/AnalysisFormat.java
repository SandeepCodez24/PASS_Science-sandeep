package backend.analysis;

import java.util.Locale;

/**
 * Display rules shared by the Analysis box and its live windows.
 *
 * <h3>Time</h3>
 * <p>
 * What the user sees ({@link #duration}): whole seconds at least, rounded UP,
 * never milliseconds -- {@code 1 s}, {@code 47 s}, {@code 3 min 07 s},
 * {@code 1 h 04 min 09 s}. A command of 0.114 s shows {@code 1 s}.
 * Descriptions (tooltips, detail lines, tables) give the exact value in
 * seconds ({@link #seconds}): {@code 0.114 s}. Chart axes count in seconds
 * with as many decimals as the tick step needs ({@link #axisSeconds}).
 * </p>
 * Numbers always use a plain decimal point and a comma for thousands,
 * whatever the locale, like nc.exe.
 */
public final class AnalysisFormat {

    /** Shown where a value is not known. */
    public static final String NONE = "—";

    private static final String[] COMPACT_UNITS = { "", " k", " M", " B", " T", " P" };

    private AnalysisFormat() {
    }

    /**
     * The shown form of a duration: whole seconds, rounded up.
     *
     * @param seconds a duration in seconds
     * @return {@code 1 s}, {@code 47 s}, {@code 3 min 07 s}, {@code 1 h 04 min 09 s};
     *         {@link #NONE} when it is not a number
     */
    public static String duration(double seconds) {
        if (Double.isNaN(seconds) || Double.isInfinite(seconds) || seconds < 0) {
            return NONE;
        }
        long whole = (long) Math.ceil(seconds - 1e-9);
        if (whole < 60) {
            return whole + " s";
        }
        if (whole < 3600) {
            return String.format(Locale.ROOT, "%d min %02d s", whole / 60, whole % 60);
        }
        return String.format(Locale.ROOT, "%d h %02d min %02d s", whole / 3600, (whole % 3600) / 60, whole % 60);
    }

    /**
     * @param millis a duration in milliseconds
     * @return the shown form: whole seconds, rounded up
     */
    public static String durationMillis(double millis) {
        return duration(millis / 1000.0);
    }

    /**
     * The exact form of a duration, for descriptions.
     *
     * @param seconds a duration in seconds
     * @return {@code 0.114 s}, {@code 46.507 s}, {@code 187.4 s}
     */
    public static String seconds(double seconds) {
        if (Double.isNaN(seconds) || Double.isInfinite(seconds) || seconds < 0) {
            return NONE;
        }
        return String.format(Locale.ROOT, seconds < 100 ? "%.3f s" : "%.1f s", seconds);
    }

    /**
     * @param millis a duration in milliseconds
     * @return the exact form, in seconds
     */
    public static String secondsMillis(double millis) {
        return seconds(millis / 1000.0);
    }

    /**
     * A chart tick in seconds, with the decimals its step needs.
     *
     * @param seconds the tick's value
     * @param step    the distance between ticks
     * @return {@code 0.05 s}, {@code 2 s}, {@code 1:30} (minutes from 2 minutes on)
     */
    public static String axisSeconds(double seconds, double step) {
        if (seconds >= 120 && step >= 1) {
            long s = Math.round(seconds);
            return s >= 3600
                    ? String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                    : String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
        }
        int decimals = step >= 1 ? 0 : (int) Math.min(4, Math.ceil(-Math.log10(step) - 1e-9));
        return String.format(Locale.ROOT, "%." + decimals + "f s", seconds);
    }

    /**
     * @param value a count
     * @return the count with thousands separators: {@code 720,132,000}
     */
    public static String grouped(long value) {
        return String.format(Locale.ROOT, "%,d", value);
    }

    /**
     * @param value a count or rate
     * @return a short form: {@code 950}, {@code 12.4 k}, {@code 720.1 M}, {@code 1.25 B}
     */
    public static String compact(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            return NONE;
        }
        double abs = Math.abs(value);
        if (abs < 1000) {
            return abs == Math.rint(abs)
                    ? String.format(Locale.ROOT, "%.0f", value)
                    : String.format(Locale.ROOT, "%.1f", value);
        }
        int unit = 0;
        while (abs >= 1000 && unit < COMPACT_UNITS.length - 1) {
            abs /= 1000;
            value /= 1000;
            unit++;
        }
        String pattern = abs >= 10 ? "%.1f" : "%.2f";
        return String.format(Locale.ROOT, pattern, value) + COMPACT_UNITS[unit];
    }

    /**
     * The Analysis row's count: grouped while it stays short, compact after.
     *
     * @param value a count
     * @return {@code 9,876,543} or {@code 720.1 M}
     */
    public static String count(long value) {
        return Math.abs(value) < 10_000_000L ? grouped(value) : compact(value);
    }

    /**
     * @param share a share from 0 to 1
     * @return {@code 86 %}, or {@code 4.2 %} below ten percent
     */
    public static String percentOfShare(double share) {
        return percent(share * 100.0);
    }

    /**
     * @param percent a percentage from 0 to 100
     * @return {@code 86 %}, or {@code 4.2 %} below ten percent
     */
    public static String percent(double percent) {
        if (Double.isNaN(percent)) {
            return NONE;
        }
        return percent < 10.0 && percent > 0.0
                ? String.format(Locale.ROOT, "%.1f %%", percent)
                : String.format(Locale.ROOT, "%.0f %%", percent);
    }

    /**
     * @param value a number of cores (process load)
     * @return {@code 18.6}
     */
    public static String cores(double value) {
        return Double.isNaN(value) ? NONE : String.format(Locale.ROOT, "%.1f", value);
    }

    /**
     * @param value a plain number
     * @param decimals how many decimals
     * @return the number with a decimal point
     */
    public static String decimal(double value, int decimals) {
        return Double.isNaN(value) ? NONE : String.format(Locale.ROOT, "%." + decimals + "f", value);
    }
}
