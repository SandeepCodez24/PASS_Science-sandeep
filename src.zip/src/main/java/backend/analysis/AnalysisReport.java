package backend.analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import backend.workspace.Json;

/**
 * One Analysis document: the live file ({@code "type":"analysis"}) or the
 * per-command summary ({@code "type":"analysis_summary"}). Field meanings are
 * in {@code docs/Analysis_Section_Java_Handover.md}, section 4.
 *
 * <p>Unknown fields are ignored, and every section may be missing (it appears
 * only while its toggle is on), so each section is null when absent.
 *
 * @param type        {@code analysis} or {@code analysis_summary}
 * @param seq         increases with every document
 * @param command     number of the command since nc.exe started
 * @param state       {@code running}, {@code idle} or {@code done}
 * @param elapsedS    seconds since the command started
 * @param elapsedText the same in the agreed format
 * @param computationsFeature the computations toggle was on when the command started
 * @param timeFeature the time toggle was on when the command started
 * @param stopped     the user pressed Stop (summary and final file)
 * @param computations computations section, or null
 * @param growth      order-of-growth section, or null
 * @param progress    progress section (live file only), or null
 * @param operations  time per operation, or null
 * @param history     top-level statement history, or null
 * @param build       how nc.exe was built: {@code release} or {@code debug}; null when not sent
 */
public record AnalysisReport(String type, long seq, long command, String state, double elapsedS,
        String elapsedText, boolean computationsFeature, boolean timeFeature, boolean stopped,
        Computations computations, Growth growth, Progress progress, Operations operations,
        History history, String build) {

    /** {@code type} of the live file. */
    public static final String TYPE_LIVE = "analysis";

    /** {@code type} of the summary line. */
    public static final String TYPE_SUMMARY = "analysis_summary";

    /**
     * @param total      elementary operations so far
     * @param statements statements executed so far
     * @param ratePerS   operations per second
     * @param seriesT    chart x: seconds
     * @param seriesV    chart y: computations (same length as {@code seriesT})
     */
    public record Computations(long total, long statements, double ratePerS, double[] seriesT, double[] seriesV) {
    }

    /**
     * A fitted order of growth.
     *
     * @param ok         false when there is no answer yet ({@code reason} says why)
     * @param reason     why there is no answer, or null
     * @param order      ASCII form: {@code O(n^2)}
     * @param display    UI form with superscripts: {@code O(n²)}
     * @param key        stable id: {@code n}, {@code nlogn}, {@code n2}, {@code n2logn}, {@code n3}, {@code 2n}
     * @param exponent   measured log-log slope
     * @param error      relative RMS error of the chosen model
     * @param confidence {@code high}, {@code medium} or {@code low}
     */
    public record Fit(boolean ok, String reason, String order, String display, String key, double exponent,
            double error, String confidence) {

        /** @return true for a low-confidence answer, shown greyed with a "?" */
        public boolean isLow() {
            return "low".equals(confidence);
        }
    }

    /**
     * One outermost loop, running or finished.
     *
     * @param line         script line of the {@code for} / {@code while}
     * @param kind         {@code for} or {@code while}
     * @param total        iterations a for loop will make; -1 for while
     * @param iterations   iterations done (live) or made (finished)
     * @param computations finished loops: work of the whole loop; else -1
     * @param seconds      finished loops: time of the whole loop; else NaN
     * @param growth       order of growth of the work, or null
     * @param timeGrowth   the same fit on time, or null
     */
    public record Loop(int line, String kind, long total, long iterations, long computations, double seconds,
            Fit growth, Fit timeGrowth) {

        /** @return true once the loop has an order of growth to show */
        public boolean hasOrder() {
            return growth != null && growth.ok();
        }
    }

    /**
     * @param loop  the outermost loop running now, or null
     * @param loops outermost loops that finished in this command, in order
     */
    public record Growth(Loop loop, List<Loop> loops) {
    }

    /**
     * @param basis      {@code loop}, {@code statements} or {@code none}
     * @param percent    0-100, or NaN when the basis is {@code none}
     * @param etaS       estimated seconds left, or NaN
     * @param etaText    the same in the agreed format, or null
     * @param statement  running top-level statement, 1-based
     * @param statements how many top-level statements there are
     * @param line       line of the running statement
     * @param loopLine   line of the loop being measured, or 0
     * @param iteration  iteration of that loop
     * @param iterations iterations it will make
     */
    public record Progress(String basis, double percent, double etaS, String etaText, int statement,
            int statements, int line, int loopLine, long iteration, long iterations) {

        /** @return true when there is a percentage to show */
        public boolean hasPercent() {
            return !Double.isNaN(percent);
        }
    }

    /**
     * @param name         builtin or operator; {@code (interpreter)} for the rest
     * @param calls        exact number of calls
     * @param computations exact computations of those calls
     * @param share        share of the samples, 0-1: the time consumed
     * @param timeS        {@code share × elapsed}
     */
    public record Operation(String name, long calls, long computations, double share, double timeS) {
    }

    /**
     * @param samples profiler samples taken; under about 50 the shares are rough
     * @param list    up to 25 operations, most time first
     */
    public record Operations(long samples, List<Operation> list) {

        /** Fewer samples than this and the shares are shown as approximate. */
        public static final long ROUGH_BELOW = 50;

        /** @return true when the shares should be shown with "≈" */
        public boolean isRough() {
            return samples < ROUGH_BELOW;
        }
    }

    /**
     * @param index        0-based position
     * @param line         script line
     * @param kind         {@code assignment}, {@code for}, {@code if}, ...
     * @param startS       seconds from the command's start
     * @param timeS        duration
     * @param computations computations of the statement
     */
    public record Statement(int index, int line, String kind, double startS, double timeS, long computations) {
    }

    /**
     * @param dropped statements beyond the 1,000 kept
     * @param list    the statements, in order
     */
    public record History(long dropped, List<Statement> list) {
    }

    // =====================================================================
    // Queries
    // =====================================================================

    /** @return true when the document came from a Debug nc.exe (timings 3-40x slower) */
    public boolean isDebugBuild() {
        return AnalysisProtocol.BUILD_DEBUG.equals(build);
    }

    /** @return true for the per-command summary line */
    public boolean isSummary() {
        return TYPE_SUMMARY.equals(type);
    }

    /** @return true while the command is still running */
    public boolean isRunning() {
        return "running".equals(state);
    }

    /**
     * The loop whose order the Analysis row shows: the one running now, else
     * the finished loop that did the most work.
     *
     * @return that loop, or null when no loop has an order
     */
    public Loop headlineLoop() {
        if (growth == null) {
            return null;
        }
        if (growth.loop() != null && growth.loop().hasOrder()) {
            return growth.loop();
        }
        Loop best = null;
        for (Loop l : growth.loops()) {
            if (l.hasOrder() && (best == null || l.computations() > best.computations())) {
                best = l;
            }
        }
        return best;
    }

    /** @return true when a loop ran (running or finished) */
    public boolean hasLoops() {
        return growth != null && (growth.loop() != null || !growth.loops().isEmpty());
    }

    // =====================================================================
    // Parsing
    // =====================================================================

    /**
     * Parses one document.
     *
     * @param json the JSON text (the live file, or the protocol line without its keyword)
     * @return the report, or null for malformed JSON, another type or a newer version
     */
    public static AnalysisReport parse(String json) {
        try {
            return fromMap(Json.parseObject(json));
        } catch (Json.JsonException e) {
            return null;
        }
    }

    /**
     * Builds a report from an already parsed document (a saved history entry).
     *
     * @param o the document's members, or null
     * @return the report, or null for another type or a newer version
     */
    public static AnalysisReport fromMap(Map<String, Object> o) {
        if (o == null || Json.num(o, "v", -1) != AnalysisProtocol.VERSION) {
            return null;
        }
        String type = Json.str(o, "type", "");
        if (!TYPE_LIVE.equals(type) && !TYPE_SUMMARY.equals(type)) {
            return null;
        }
        Map<String, Object> features = Json.obj(o, "features");
        return new AnalysisReport(type,
                Json.num(o, "seq", 0),
                Json.num(o, "command", 0),
                Json.str(o, "state", ""),
                dbl(o, "elapsed_s"),
                Json.str(o, "elapsed_text", null),
                Json.bool(features, "computations", false),
                Json.bool(features, "time", false),
                Json.bool(o, "stopped", false),
                computations(Json.obj(o, "computations")),
                growth(Json.obj(o, "growth")),
                progress(Json.obj(o, "progress")),
                operations(Json.obj(o, "operations")),
                history(Json.obj(o, "history")),
                Json.str(o, "build", null));
    }

    private static Computations computations(Map<String, Object> o) {
        if (o == null) {
            return null;
        }
        List<Object> series = Json.arr(o, "series");
        double[] t = new double[series.size()];
        double[] v = new double[series.size()];
        int n = 0;
        for (Object point : series) {
            if (point instanceof List<?> pair && pair.size() >= 2) {
                t[n] = Json.toDouble(pair.get(0));
                v[n] = Json.toDouble(pair.get(1));
                n++;
            }
        }
        if (n < t.length) {
            double[] tt = new double[n];
            double[] vv = new double[n];
            System.arraycopy(t, 0, tt, 0, n);
            System.arraycopy(v, 0, vv, 0, n);
            t = tt;
            v = vv;
        }
        return new Computations(Json.num(o, "total", 0), Json.num(o, "statements", 0), dbl(o, "rate_per_s"), t, v);
    }

    private static Growth growth(Map<String, Object> o) {
        if (o == null) {
            return null;
        }
        List<Loop> loops = new ArrayList<>();
        for (Map<String, Object> item : objects(Json.arr(o, "loops"))) {
            loops.add(loop(item));
        }
        Map<String, Object> current = Json.obj(o, "loop");
        return new Growth(current == null ? null : loop(current), Collections.unmodifiableList(loops));
    }

    private static Loop loop(Map<String, Object> o) {
        return new Loop((int) Json.num(o, "line", 0),
                Json.str(o, "kind", ""),
                Json.num(o, "total", -1),
                Json.num(o, "iterations", 0),
                Json.num(o, "computations", -1),
                dbl(o, "seconds"),
                fit(Json.obj(o, "growth")),
                fit(Json.obj(o, "time_growth")));
    }

    private static Fit fit(Map<String, Object> o) {
        if (o == null) {
            return null;
        }
        return new Fit(Json.bool(o, "ok", false),
                Json.str(o, "reason", null),
                Json.str(o, "order", null),
                Json.str(o, "display", Json.str(o, "order", null)),
                Json.str(o, "key", null),
                dbl(o, "exponent"),
                dbl(o, "error"),
                Json.str(o, "confidence", "low"));
    }

    private static Progress progress(Map<String, Object> o) {
        if (o == null) {
            return null;
        }
        return new Progress(Json.str(o, "basis", "none"),
                dbl(o, "percent"),
                dbl(o, "eta_s"),
                Json.str(o, "eta_text", null),
                (int) Json.num(o, "statement", 0),
                (int) Json.num(o, "statements", 0),
                (int) Json.num(o, "line", 0),
                (int) Json.num(o, "loop_line", 0),
                Json.num(o, "iteration", 0),
                Json.num(o, "iterations", 0));
    }

    private static Operations operations(Map<String, Object> o) {
        if (o == null) {
            return null;
        }
        List<Operation> list = new ArrayList<>();
        for (Map<String, Object> item : objects(Json.arr(o, "list"))) {
            list.add(new Operation(Json.str(item, "name", "?"),
                    Json.num(item, "calls", 0),
                    Json.num(item, "computations", 0),
                    zeroIfNaN(dbl(item, "share")),
                    zeroIfNaN(dbl(item, "time_s"))));
        }
        return new Operations(Json.num(o, "samples", 0), Collections.unmodifiableList(list));
    }

    private static History history(Map<String, Object> o) {
        if (o == null) {
            return null;
        }
        List<Statement> list = new ArrayList<>();
        for (Map<String, Object> item : objects(Json.arr(o, "list"))) {
            list.add(new Statement((int) Json.num(item, "index", 0),
                    (int) Json.num(item, "line", 0),
                    Json.str(item, "kind", ""),
                    zeroIfNaN(dbl(item, "start_s")),
                    zeroIfNaN(dbl(item, "time_s")),
                    Json.num(item, "computations", 0)));
        }
        return new History(Json.num(o, "dropped", 0), Collections.unmodifiableList(list));
    }

    // ---- helpers shared with ParmonReport ---------------------------------

    /** @return member {@code key} as a double; NaN when missing or null */
    static double dbl(Map<String, Object> o, String key) {
        return o == null ? Double.NaN : Json.toDouble(o.get(key));
    }

    /** @return the members of an array that are objects */
    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> objects(List<Object> array) {
        List<Map<String, Object>> out = new ArrayList<>(array.size());
        for (Object item : array) {
            if (item instanceof Map) {
                out.add((Map<String, Object>) item);
            }
        }
        return out;
    }

    private static double zeroIfNaN(double v) {
        return Double.isNaN(v) ? 0.0 : v;
    }
}
