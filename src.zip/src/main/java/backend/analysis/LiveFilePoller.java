package backend.analysis;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.ToLongFunction;

import javafx.application.Platform;

/**
 * Reads one of nc.exe's live JSON files on a timer, off the FX thread, and
 * hands each new document to the FX thread.
 *
 * <p>Follows the rules of both handovers: the file is opened, read and closed
 * at once (a file held open on Windows blocks nc.exe's rename), read errors
 * are ignored (the next tick retries), and a document is delivered only when
 * its {@code seq} differs from the last one delivered. Parsing happens on the
 * poll thread, so the FX thread only applies a finished document.
 *
 * @param <T> the parsed document type
 */
final class LiveFilePoller<T> {

    private final ScheduledExecutorService executor;
    private final Supplier<Path> file;
    private final Function<String, T> parser;
    private final ToLongFunction<T> seqOf;
    private final Consumer<T> onFx;

    /** Seq of the last document delivered; poll thread only. */
    private long lastSeq = Long.MIN_VALUE;

    /** The running timer, or null; FX thread only. */
    private ScheduledFuture<?> task;
    private long periodMs;

    /**
     * @param executor the shared poll thread
     * @param file     where the file is (resolved on each read: the session may start later)
     * @param parser   text to document; null for text that is not one
     * @param seqOf    the document's {@code seq}
     * @param onFx     receives each new document on the FX thread
     */
    LiveFilePoller(ScheduledExecutorService executor, Supplier<Path> file, Function<String, T> parser,
            ToLongFunction<T> seqOf, Consumer<T> onFx) {
        this.executor = executor;
        this.file = file;
        this.parser = parser;
        this.seqOf = seqOf;
        this.onFx = onFx;
    }

    /**
     * Starts reading every {@code period} ms, or changes the period. FX thread.
     *
     * @param period the period in ms
     */
    void start(long period) {
        if (task != null && periodMs == period) {
            return;
        }
        stopTimer();
        periodMs = period;
        task = executor.scheduleWithFixedDelay(this::readNow, period, period, TimeUnit.MILLISECONDS);
    }

    /** Stops the timer and reads once more, for the last document of a command. FX thread. */
    void stopAndReadOnce() {
        stopTimer();
        executor.execute(this::readNow);
    }

    /** @return true while the timer runs */
    boolean isRunning() {
        return task != null;
    }

    private void stopTimer() {
        if (task != null) {
            task.cancel(false);
            task = null;
        }
    }

    /** Poll thread. */
    private void readNow() {
        Path path = file.get();
        if (path == null) {
            return;
        }
        String text;
        try {
            text = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
        } catch (IOException | SecurityException e) {
            return; // missing, or being replaced: the next tick retries
        }
        T doc = parser.apply(text);
        if (doc == null) {
            return;
        }
        long seq = seqOf.applyAsLong(doc);
        if (seq == lastSeq) {
            return;
        }
        lastSeq = seq;
        Platform.runLater(() -> onFx.accept(doc));
    }
}
