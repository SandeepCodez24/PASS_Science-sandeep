package backend.analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import backend.workspace.Json;

/**
 * A CPU core and thread monitor document: a live snapshot
 * ({@code "type":"parmon"}) from {@code parmon.json} or a {@code @PARMON}
 * snapshot line, or the per-command summary ({@code "type":"parmon_summary"}).
 * Field meanings are in {@code docs/Parallel_Monitor_Java_Handover.md},
 * section 4. Unknown fields are ignored; a missing optional field keeps
 * today's meaning (a region without {@code device} ran on the CPU).
 */
public sealed interface ParmonReport permits ParmonReport.Snapshot, ParmonReport.Summary {

    /** @return the fields every document carries */
    Common common();

    /**
     * Fields shared by both types.
     *
     * @param os                {@code windows}, {@code linux}, {@code macos}, ...
     * @param backend           {@code openmp}, {@code stdpool} or {@code serial}
     * @param logicalProcessors logical processors NC may use
     * @param threadSetting     current thread limit
     * @param intervalMs        snapshot period
     * @param build             how nc.exe was built: {@code release} or {@code debug}; null when not sent
     */
    record Common(String os, String backend, int logicalProcessors, int threadSetting, int intervalMs,
            String build) {

        /** @return true when the document came from a Debug nc.exe */
        public boolean isDebugBuild() {
            return AnalysisProtocol.BUILD_DEBUG.equals(build);
        }
    }

    /**
     * One compute device. Today a single {@code cpu}; a GPU backend will add more.
     *
     * @param kind              {@code cpu} (or {@code gpu} later)
     * @param index             device number of its kind
     * @param name              display name, or null
     * @param coreLoadAvailable false where the OS gives no per-core numbers
     * @param cores             load of each logical processor, 0-1
     */
    record Device(String kind, int index, String name, boolean coreLoadAvailable, double[] cores) {

        /** @return mean load over the cores, or NaN without per-core numbers */
        public double meanLoad() {
            if (cores.length == 0) {
                return Double.NaN;
            }
            double sum = 0;
            for (double c : cores) {
                sum += c;
            }
            return sum / cores.length;
        }
    }

    /**
     * One of NC's worker threads that ran blocks in the interval.
     *
     * @param slot      0 is the interpreter thread
     * @param busy      share of the interval spent in blocks, 0-1
     * @param blocks    blocks it ran
     * @param processor logical processor it last ran on; -1 when unknown (macOS)
     */
    record ThreadStat(int slot, double busy, long blocks, int processor) {
    }

    /**
     * The kernel running right now.
     *
     * @param label     NC function or operator: {@code sin}, {@code sum}, {@code +}
     * @param kind      {@code stream}, {@code reduce}, {@code compute} or {@code task}
     * @param items     elements
     * @param blocks    blocks
     * @param threads   threads it uses
     * @param elapsedMs time so far
     */
    record Region(String label, String kind, long items, long blocks, int threads, double elapsedMs) {
    }

    /**
     * The running command (or the one that just finished, when idle).
     *
     * @param elapsedMs  time so far
     * @param regions    parallel regions run
     * @param parallelMs time spent in them
     */
    record CommandStat(double elapsedMs, long regions, double parallelMs) {
    }

    /**
     * Live snapshot.
     *
     * @param seq          increases with every snapshot
     * @param state        {@code running}, or {@code idle} for the last one of a command
     * @param common       shared fields
     * @param devices      compute devices
     * @param cpuCoresBusy CPU time of nc.exe over the interval ÷ the interval
     * @param threads      NC's worker threads
     * @param region       the kernel running now, or null between kernels
     * @param command      the running command, or null
     */
    record Snapshot(long seq, String state, Common common, List<Device> devices, double cpuCoresBusy,
            List<ThreadStat> threads, Region region, CommandStat command) implements ParmonReport {

        /** @return true for the last snapshot of a finished command */
        public boolean isIdle() {
            return !"running".equals(state);
        }

        /** @return the first CPU device, or null */
        public Device cpu() {
            for (Device d : devices) {
                if ("cpu".equals(d.kind())) {
                    return d;
                }
            }
            return devices.isEmpty() ? null : devices.get(0);
        }

        /** @return true when no thread knows its processor (macOS): hide the "core" column */
        public boolean processorsUnknown() {
            for (ThreadStat t : threads) {
                if (t.processor() >= 0) {
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * One kernel of the per-command summary.
     *
     * @param label      NC function or operator
     * @param kind       {@code stream}, {@code reduce}, {@code compute} or {@code task}
     * @param count      runs
     * @param items      elements over all runs
     * @param ms         time over all runs
     * @param maxThreads largest thread count used
     */
    record Kernel(String label, String kind, long count, long items, double ms, int maxThreads) {
    }

    /**
     * Per-command summary, sent just before {@code @PROMPT}.
     *
     * @param common      shared fields
     * @param wallMs      how long the command took
     * @param cpuMs       CPU time used by nc.exe
     * @param cpuCoresAvg {@code cpuMs ÷ wallMs}: average cores busy
     * @param regions     parallel kernel runs
     * @param parallelMs  time spent in them
     * @param maxThreads  largest thread count used by any kernel
     * @param stopped     Stop ended a kernel early
     * @param kernels     per kernel name, in order of first use
     */
    record Summary(Common common, double wallMs, double cpuMs, double cpuCoresAvg, long regions,
            double parallelMs, int maxThreads, boolean stopped, List<Kernel> kernels) implements ParmonReport {
    }

    // =====================================================================
    // Parsing
    // =====================================================================

    /**
     * @param json the JSON text (the live file, or the protocol line without its keyword)
     * @return the document, or null for malformed JSON, another type or a newer version
     */
    static ParmonReport parse(String json) {
        try {
            return fromMap(Json.parseObject(json));
        } catch (Json.JsonException e) {
            return null;
        }
    }

    /**
     * @param o an already parsed document (a saved history entry), or null
     * @return the document, or null for another type or a newer version
     */
    static ParmonReport fromMap(Map<String, Object> o) {
        if (o == null || Json.num(o, "v", -1) != AnalysisProtocol.VERSION) {
            return null;
        }
        Common common = new Common(Json.str(o, "os", "unknown"),
                Json.str(o, "backend", ""),
                (int) Json.num(o, "logical_processors", 0),
                (int) Json.num(o, "thread_setting", 0),
                (int) Json.num(o, "interval_ms", (int) AnalysisProtocol.PARMON_INTERVAL_MS),
                Json.str(o, "build", null));
        return switch (Json.str(o, "type", "")) {
            case "parmon" -> snapshot(o, common);
            case "parmon_summary" -> summary(o, common);
            default -> null;
        };
    }

    /**
     * @param json the live file's text
     * @return the snapshot, or null when the text is not one
     */
    static Snapshot parseSnapshot(String json) {
        return parse(json) instanceof Snapshot s ? s : null;
    }

    private static Snapshot snapshot(Map<String, Object> o, Common common) {
        List<Device> devices = new ArrayList<>();
        for (Map<String, Object> d : AnalysisReport.objects(Json.arr(o, "devices"))) {
            List<Object> raw = Json.arr(d, "cores");
            double[] cores = new double[raw.size()];
            for (int i = 0; i < cores.length; i++) {
                double v = Json.toDouble(raw.get(i));
                cores[i] = Double.isNaN(v) ? 0.0 : Math.max(0.0, Math.min(1.0, v));
            }
            devices.add(new Device(Json.str(d, "kind", "cpu"), (int) Json.num(d, "index", 0),
                    Json.str(d, "name", null), Json.bool(d, "core_load_available", cores.length > 0), cores));
        }
        List<ThreadStat> threads = new ArrayList<>();
        for (Map<String, Object> t : AnalysisReport.objects(Json.arr(o, "threads"))) {
            double busy = AnalysisReport.dbl(t, "busy");
            threads.add(new ThreadStat((int) Json.num(t, "slot", 0),
                    Double.isNaN(busy) ? 0.0 : Math.max(0.0, Math.min(1.0, busy)),
                    Json.num(t, "blocks", 0),
                    (int) Json.num(t, "processor", -1)));
        }
        Map<String, Object> r = Json.obj(o, "region");
        Region region = r == null ? null
                : new Region(Json.str(r, "label", "?"), Json.str(r, "kind", ""), Json.num(r, "items", 0),
                        Json.num(r, "blocks", 0), (int) Json.num(r, "threads", 0), AnalysisReport.dbl(r, "elapsed_ms"));
        Map<String, Object> c = Json.obj(o, "command");
        CommandStat command = c == null ? null
                : new CommandStat(AnalysisReport.dbl(c, "elapsed_ms"), Json.num(c, "regions", 0),
                        AnalysisReport.dbl(c, "parallel_ms"));
        return new Snapshot(Json.num(o, "seq", 0), Json.str(o, "state", "idle"), common,
                Collections.unmodifiableList(devices),
                AnalysisReport.dbl(Json.obj(o, "process"), "cpu_cores_busy"),
                Collections.unmodifiableList(threads), region, command);
    }

    private static Summary summary(Map<String, Object> o, Common common) {
        List<Kernel> kernels = new ArrayList<>();
        for (Map<String, Object> k : AnalysisReport.objects(Json.arr(o, "kernels"))) {
            kernels.add(new Kernel(Json.str(k, "label", "?"), Json.str(k, "kind", ""), Json.num(k, "count", 0),
                    Json.num(k, "items", 0), AnalysisReport.dbl(k, "ms"), (int) Json.num(k, "max_threads", 0)));
        }
        return new Summary(common, AnalysisReport.dbl(o, "wall_ms"), AnalysisReport.dbl(o, "cpu_ms"),
                AnalysisReport.dbl(o, "cpu_cores_avg"), Json.num(o, "regions", 0),
                AnalysisReport.dbl(o, "parallel_ms"), (int) Json.num(o, "max_threads", 0),
                Json.bool(o, "stopped", false), Collections.unmodifiableList(kernels));
    }
}
