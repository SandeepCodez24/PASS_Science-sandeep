package backend.analysis;

import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Predicate;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.SimpleBooleanProperty;

/**
 * The three switches of the Analysis box and what nc.exe has been told.
 *
 * <pre>
 *   No. of Computation   [●]  ->  @cmd analysis computations on|off
 *   Execution Time       [●]  ->  @cmd analysis time on|off
 *   Cores &amp; threads      [●]  ->  @cmd parmon on|off   (+ @cmd parmon snapshot)
 * </pre>
 *
 * <h3>When a line is written</h3>
 * <p>
 * nc.exe reads stdin only between commands, and a line written while a
 * script runs could be read as the script's input, so the Command Window
 * controller writes them the way it writes {@code @cmd width}: at once when
 * nothing runs, otherwise just before the next command's lines
 * ({@link #sendIfChanged}). A switch changed while a command runs is
 * therefore <i>pending</i> -- "on from the next run" -- until it is written
 * ({@link #pendingProperty}).
 * </p>
 *
 * <h3>Restarts</h3>
 * <p>
 * nc.exe starts with every feature off, also after the IDE restarts it.
 * {@link #forgetSent()} records that, so the next {@link #sendIfChanged}
 * writes every switch that is on. The switches themselves start off with the
 * IDE, as both handovers ask.
 * </p>
 */
public final class AnalysisToggles {

    /** One switch and the stdin command that carries it. */
    public enum Feature {
        /** "No. of Computation": computations and order of growth. */
        COMPUTATIONS("@cmd analysis computations "),
        /** "Execution Time": progress, time per operation, history. */
        TIME("@cmd analysis time "),
        /** "Cores & threads": the CPU core and thread monitor. */
        CORES("@cmd parmon ");

        private final String command;

        Feature(String command) {
            this.command = command;
        }

        /**
         * @param on the state to send
         * @return the stdin line
         */
        public String command(boolean on) {
            return command + (on ? "on" : "off");
        }
    }

    private final Map<Feature, BooleanProperty> wanted = new EnumMap<>(Feature.class);
    private final Map<Feature, ReadOnlyBooleanWrapper> pending = new EnumMap<>(Feature.class);
    private final Map<Feature, Boolean> sent = new EnumMap<>(Feature.class);

    /** Run after a switch changes, so the controller can write it if idle. */
    private Runnable onChange;

    AnalysisToggles() {
        for (Feature f : Feature.values()) {
            String name = f.name().toLowerCase(Locale.ROOT);
            BooleanProperty p = new SimpleBooleanProperty(this, name, false);
            ReadOnlyBooleanWrapper w = new ReadOnlyBooleanWrapper(this, name + "Pending", false);
            wanted.put(f, p);
            pending.put(f, w);
            sent.put(f, Boolean.FALSE);
            p.addListener((obs, was, now) -> {
                refreshPending(f);
                if (onChange != null) {
                    onChange.run();
                }
            });
        }
    }

    /**
     * @param feature the switch
     * @return its state as the user set it; FX thread
     */
    public BooleanProperty property(Feature feature) {
        return wanted.get(feature);
    }

    /**
     * @param feature the switch
     * @return true while the switch is on
     */
    public boolean isOn(Feature feature) {
        return wanted.get(feature).get();
    }

    /**
     * @param feature the switch
     * @param on      the new state
     */
    public void set(Feature feature, boolean on) {
        wanted.get(feature).set(on);
    }

    /**
     * @param feature the switch
     * @return true while the switch differs from what nc.exe has been told:
     *         it applies from the next command
     */
    public ReadOnlyBooleanProperty pendingProperty(Feature feature) {
        return pending.get(feature).getReadOnlyProperty();
    }

    /** @return true when the computations or the time switch is on */
    public boolean anyAnalysisOn() {
        return isOn(Feature.COMPUTATIONS) || isOn(Feature.TIME);
    }

    /**
     * @param action run on the FX thread after any switch changes; the
     *               controller writes the change if nothing runs
     */
    public void setOnChange(Runnable action) {
        onChange = action;
    }

    /** A fresh nc.exe knows nothing: every feature is off there. */
    public void forgetSent() {
        for (Feature f : Feature.values()) {
            sent.put(f, Boolean.FALSE);
            refreshPending(f);
        }
    }

    /**
     * Writes every switch that differs from what nc.exe was last told.
     * Call only where a line may be written: at launch, while idle, or just
     * before a command's own lines.
     *
     * @param sender writes one stdin line; false when it could not
     */
    public void sendIfChanged(Predicate<String> sender) {
        for (Feature f : Feature.values()) {
            boolean want = isOn(f);
            if (sent.get(f) == want) {
                continue;
            }
            if (!sender.test(f.command(want))) {
                return; // the pipe is gone; a restart calls forgetSent()
            }
            sent.put(f, want);
            refreshPending(f);
            if (f == Feature.CORES && want) {
                // Fill the panel at once instead of waiting for a command.
                sender.test(AnalysisProtocol.PARMON_SNAPSHOT);
            }
        }
    }

    private void refreshPending(Feature f) {
        pending.get(f).set(sent.get(f) != isOn(f));
    }
}
