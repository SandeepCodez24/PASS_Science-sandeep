package backend.analysis;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * One command as the Analysis windows show it: what ran and when, the newest
 * document about it, and what the IDE gathered while it ran.
 *
 * @param title    what ran: the script's file name ({@code grow.nc}) or the typed command
 * @param started  when it started, on this computer's clock
 * @param command  number of the command since nc.exe started (0 for a saved run)
 * @param report   the newest document (live, or the summary once finished)
 * @param marks    order of growth seen at each live update, oldest first;
 *                 draws the chart's "order of growth" steps
 * @param finished true once the summary has arrived
 * @param parmon   the CPU monitor's summary of the same command, or null
 */
public record AnalysisRun(String title, LocalDateTime started, long command, AnalysisReport report,
        List<GrowthMark> marks, boolean finished, ParmonReport.Summary parmon) {

    private static final DateTimeFormatter WHEN = DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm:ss", Locale.ENGLISH);

    /**
     * The order of growth of the running loop at one moment.
     *
     * @param seconds seconds from the command's start
     * @param line    the loop's line
     * @param key     stable order id ({@code n}, {@code n2}, ...)
     * @param display order with superscripts
     */
    public record GrowthMark(double seconds, int line, String key, String display) {
    }

    /** @return the start time as the history pickers show it: {@code 05 Nov 2026, 14:32:10} */
    public String when() {
        return started == null ? AnalysisFormat.NONE : WHEN.format(started);
    }

    /**
     * The history pickers' entry.
     *
     * @return {@code grow.nc  ·  05 Nov 2026, 14:32:10  ·  47 s  ·  512.1 M  ·  O(n²)}
     */
    public String label() {
        StringBuilder sb = new StringBuilder(title == null || title.isBlank() ? "command" : title);
        sb.append("  ·  ").append(when());
        sb.append("  ·  ").append(AnalysisFormat.duration(report.elapsedS()));
        if (report.computations() != null) {
            sb.append("  ·  ").append(AnalysisFormat.compact(report.computations().total()));
        }
        AnalysisReport.Loop loop = report.headlineLoop();
        if (loop != null) {
            sb.append("  ·  ").append(loop.growth().display());
        }
        if (report.stopped()) {
            sb.append("  ·  stopped");
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return label();
    }
}
