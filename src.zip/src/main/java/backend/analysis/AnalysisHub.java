package backend.analysis;

import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import backend.workspace.NcSession;
import javafx.application.Platform;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.beans.property.ReadOnlyBooleanWrapper;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * The IDE's single source of truth for the Analysis box, its live windows
 * and the CPU core and thread monitor. FX thread only, unless a method says
 * otherwise.
 *
 * <pre>
 *  nc.exe ── @ANALYSIS / @PARMON lines ──► CLI_Main.onControl ──► {@link #acceptProtocolLine}
 *         ── analysis.json (1 s)  ─────────► poll thread ─────────► {@link #currentProperty}
 *         ── parmon.json (250 ms) ─────────► poll thread ─────────► {@link #snapshotProperty}
 *                                                                   │
 *            Analysis rows, Computational / Time / Cores windows ◄──┘ (listeners)
 * </pre>
 *
 * <h3>The three rules, IDE side</h3>
 * <ul>
 * <li>Both live files are read only while a command runs <i>and</i> their
 * switch is on, then once more when it ends (the {@code idle} document);
 * nothing is read between commands.</li>
 * <li>The switches start off ({@link AnalysisToggles}).</li>
 * <li>A redraw happens only when a document's {@code seq} changes.</li>
 * </ul>
 *
 * <h3>History</h3>
 * <p>
 * Every finished command is named by what ran (the script's file name, or
 * the typed command) and when it started ({@link #commandStarting}), and is
 * saved to {@code ~/.neuralcode/analysis_history.jsonl}
 * ({@link AnalysisHistoryStore}), so the history pickers still list it after
 * the IDE restarts.
 * </p>
 */
public final class AnalysisHub {

    /** Finished commands kept for the history pickers (C++ keeps none). */
    public static final int HISTORY_LIMIT = 50;

    /** Longest title kept for a typed command. */
    private static final int TITLE_MAX = 48;

    /** Growth marks kept per command; older ones are thinned out beyond this. */
    private static final int MARK_LIMIT = 1200;

    private static AnalysisHub instance;

    private final AnalysisToggles toggles = new AnalysisToggles();
    private final ReadOnlyObjectWrapper<AnalysisRun> current = new ReadOnlyObjectWrapper<>(this, "current");
    private final ObservableList<AnalysisRun> history = FXCollections.observableArrayList();
    private final ObservableList<AnalysisRun> historyView = FXCollections.unmodifiableObservableList(history);
    private final ReadOnlyObjectWrapper<ParmonReport.Snapshot> snapshot =
            new ReadOnlyObjectWrapper<>(this, "snapshot");
    private final ReadOnlyObjectWrapper<ParmonReport.Summary> parmonSummary =
            new ReadOnlyObjectWrapper<>(this, "parmonSummary");
    private final ReadOnlyBooleanWrapper running = new ReadOnlyBooleanWrapper(this, "running", false);
    private final ReadOnlyBooleanWrapper debugBuild = new ReadOnlyBooleanWrapper(this, "debugBuild", false);

    private final ScheduledExecutorService background;
    private final AnalysisHistoryStore store;
    private final LiveFilePoller<AnalysisReport> analysisFile;
    private final LiveFilePoller<ParmonReport.Snapshot> parmonFile;

    /** Marks of the command {@link #marksCommand}. */
    private final List<AnalysisRun.GrowthMark> marks = new ArrayList<>();
    private long marksCommand = -1;

    /** Last command whose summary arrived; its later live documents are stale. */
    private long lastFinishedCommand = -1;

    /** The monitor summary arrives just before the Analysis one; held for it (parsed and as sent). */
    private ParmonReport.Summary heldParmonSummary;
    private String heldParmonJson;

    /** What the command in flight is and when it started ({@link #commandStarting}). */
    private String runTitle = "command";
    private LocalDateTime runStarted = LocalDateTime.now();

    private boolean attached;

    private AnalysisHub() {
        background = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "nc-analysis-poll");
            t.setDaemon(true);
            return t;
        });
        ScheduledExecutorService poll = background;
        store = new AnalysisHistoryStore(Path.of(System.getProperty("user.home"), ".neuralcode"), HISTORY_LIMIT);
        analysisFile = new LiveFilePoller<>(poll, () -> sessionFile(AnalysisProtocol.ANALYSIS_FILE),
                AnalysisHub::parseLive, AnalysisReport::seq, this::onLiveAnalysis);
        parmonFile = new LiveFilePoller<>(poll, () -> sessionFile(AnalysisProtocol.PARMON_FILE),
                ParmonReport::parseSnapshot, ParmonReport.Snapshot::seq, this::onLiveSnapshot);
        // Earlier sessions' runs, read off the FX thread, listed after any run of this one.
        background.execute(() -> {
            List<AnalysisRun> saved = store.load();
            if (!saved.isEmpty()) {
                Platform.runLater(() -> addSaved(saved));
            }
        });
    }

    /** @return the hub, created on first use; FX thread */
    public static AnalysisHub get() {
        if (instance == null) {
            instance = new AnalysisHub();
        }
        return instance;
    }

    // =====================================================================
    // Wiring (CLI_Main)
    // =====================================================================

    /**
     * Follows the Command Window's running state: live files are read only
     * while a command runs. Call once.
     *
     * @param busy true while a command runs
     */
    public void attach(ReadOnlyBooleanProperty busy) {
        if (attached) {
            return;
        }
        attached = true;
        busy.addListener((obs, was, now) -> {
            running.set(now);
            updatePolling();
        });
        running.set(busy.get());
        toggles.property(AnalysisToggles.Feature.COMPUTATIONS).addListener((obs, was, now) -> updatePolling());
        toggles.property(AnalysisToggles.Feature.TIME).addListener((obs, was, now) -> updatePolling());
        toggles.property(AnalysisToggles.Feature.CORES).addListener((obs, was, now) -> updatePolling());
    }

    /** A new nc.exe numbers its commands from 1 again and knows no switch. */
    public void interpreterStarted() {
        lastFinishedCommand = -1;
        marksCommand = -1;
        marks.clear();
        heldParmonSummary = null;
        heldParmonJson = null;
        toggles.forgetSent();
    }

    /**
     * A command is about to be sent: names the run that its documents will
     * belong to.
     *
     * @param text the command as the Command Window echoes it -- a script's
     *             file name ({@code grow.nc}), a quoted path, or typed text
     */
    public void commandStarting(String text) {
        runTitle = titleOf(text);
        runStarted = LocalDateTime.now();
    }

    /**
     * An {@code @ANALYSIS} or {@code @PARMON} protocol line, in order with
     * the output around it.
     *
     * @param line the line without its Record Separator
     */
    public void acceptProtocolLine(String line) {
        int space = line.indexOf(' ');
        if (space <= 0) {
            return;
        }
        String keyword = line.substring(0, space);
        String json = line.substring(space + 1);
        if (AnalysisProtocol.PARMON.equals(keyword)) {
            switch (ParmonReport.parse(json)) {
                case ParmonReport.Snapshot s -> {
                    noteBuild(s.common().build());
                    snapshot.set(s);
                }
                case ParmonReport.Summary s -> {
                    noteBuild(s.common().build());
                    heldParmonSummary = s;
                    heldParmonJson = json;
                    parmonSummary.set(s);
                }
                case null -> {
                    // malformed line, another type or a newer version: ignored
                }
            }
        } else if (AnalysisProtocol.ANALYSIS.equals(keyword)) {
            AnalysisReport report = AnalysisReport.parse(json);
            if (report != null && report.isSummary()) {
                noteBuild(report.build());
                finishRun(report, json);
            }
        }
    }

    // =====================================================================
    // What the UI reads
    // =====================================================================

    /** @return the three switches */
    public AnalysisToggles toggles() {
        return toggles;
    }

    /** @return the running command, or the last one that finished; null before any */
    public ReadOnlyObjectProperty<AnalysisRun> currentProperty() {
        return current.getReadOnlyProperty();
    }

    /** @return finished commands, newest first, at most {@link #HISTORY_LIMIT} */
    public ObservableList<AnalysisRun> history() {
        return historyView;
    }

    /** @return the newest CPU monitor snapshot, or null */
    public ReadOnlyObjectProperty<ParmonReport.Snapshot> snapshotProperty() {
        return snapshot.getReadOnlyProperty();
    }

    /** @return the CPU monitor's summary of the last command that sent one, or null */
    public ReadOnlyObjectProperty<ParmonReport.Summary> parmonSummaryProperty() {
        return parmonSummary.getReadOnlyProperty();
    }

    /** @return true while a command runs */
    public ReadOnlyBooleanProperty runningProperty() {
        return running.getReadOnlyProperty();
    }

    /**
     * @return true once nc.exe has reported that it is a Debug build: its
     *         timings are 3-40x slower than Release, and the UI says so
     */
    public ReadOnlyBooleanProperty debugBuildProperty() {
        return debugBuild.getReadOnlyProperty();
    }

    /** Forgets the finished commands, saved ones too (the windows' Reset History). The running one stays. */
    public void clearHistory() {
        history.clear();
        background.execute(store::clear);
        if (!running.get()) {
            current.set(null);
        }
    }

    /** Forgets the monitor's last summary and snapshot (the Cores window's Reset). */
    public void clearMonitor() {
        parmonSummary.set(null);
        if (!running.get()) {
            snapshot.set(null);
        }
    }

    // =====================================================================
    // Internals
    // =====================================================================

    private void updatePolling() {
        boolean run = running.get();
        if (run && toggles.anyAnalysisOn()) {
            analysisFile.start(AnalysisProtocol.ANALYSIS_INTERVAL_MS);
        } else if (analysisFile.isRunning()) {
            analysisFile.stopAndReadOnce();
        }
        if (run && toggles.isOn(AnalysisToggles.Feature.CORES)) {
            ParmonReport.Snapshot last = snapshot.get();
            long period = last != null && last.common().intervalMs() > 0
                    ? last.common().intervalMs() : AnalysisProtocol.PARMON_INTERVAL_MS;
            parmonFile.start(period);
        } else if (parmonFile.isRunning()) {
            parmonFile.stopAndReadOnce();
        }
    }

    private static AnalysisReport parseLive(String text) {
        AnalysisReport r = AnalysisReport.parse(text);
        return r != null && !r.isSummary() ? r : null;
    }

    private static Path sessionFile(String name) {
        NcSession session = NcSession.current();
        return session == null ? null : session.directory().resolve(name);
    }

    private void onLiveSnapshot(ParmonReport.Snapshot s) {
        noteBuild(s.common().build());
        snapshot.set(s);
    }

    /** Follows the build type of the running nc.exe; an older nc.exe sends none and changes nothing. */
    private void noteBuild(String build) {
        if (build != null) {
            debugBuild.set(AnalysisProtocol.BUILD_DEBUG.equals(build));
        }
    }

    private void onLiveAnalysis(AnalysisReport report) {
        noteBuild(report.build());
        if (report.command() <= lastFinishedCommand) {
            return; // the idle document of a command whose summary is already in
        }
        recordMark(report);
        current.set(new AnalysisRun(runTitle, runStarted, report.command(), report, List.copyOf(marks), false, null));
    }

    private void finishRun(AnalysisReport summary, String json) {
        if (summary.command() != marksCommand) {
            marks.clear();
            marksCommand = summary.command();
        }
        AnalysisRun run = new AnalysisRun(runTitle, runStarted, summary.command(), summary, List.copyOf(marks), true,
                heldParmonSummary);
        String title = runTitle;
        LocalDateTime started = runStarted;
        String parmonJson = heldParmonJson;
        background.execute(() -> store.append(title, started, json, parmonJson));
        heldParmonSummary = null;
        heldParmonJson = null;
        lastFinishedCommand = summary.command();
        current.set(run);
        history.add(0, run);
        if (history.size() > HISTORY_LIMIT) {
            history.remove(HISTORY_LIMIT, history.size());
        }
    }

    /** Saved runs go after this session's (newest first), up to the limit. */
    private void addSaved(List<AnalysisRun> saved) {
        for (AnalysisRun run : saved) {
            if (history.size() >= HISTORY_LIMIT) {
                break;
            }
            history.add(run);
        }
    }

    /**
     * @param text the echoed command
     * @return the run's title: the file name of a script, else the first line of the command
     */
    static String titleOf(String text) {
        if (text == null || text.isBlank()) {
            return "command";
        }
        String t = text.strip();
        int newline = t.indexOf('\n');
        if (newline >= 0) {
            t = t.substring(0, newline).strip() + " \u2026";
        }
        String bare = t;
        while (!bare.isEmpty() && "\"';".indexOf(bare.charAt(bare.length() - 1)) >= 0) {
            bare = bare.substring(0, bare.length() - 1);
        }
        while (!bare.isEmpty() && "\"'".indexOf(bare.charAt(0)) >= 0) {
            bare = bare.substring(1);
        }
        if (bare.toLowerCase(Locale.ROOT).endsWith(".nc")) {
            int slash = Math.max(bare.lastIndexOf('/'), bare.lastIndexOf('\\'));
            return bare.substring(slash + 1);
        }
        return t.length() > TITLE_MAX ? t.substring(0, TITLE_MAX - 1) + "\u2026" : t;
    }

    private void recordMark(AnalysisReport report) {
        if (report.command() != marksCommand) {
            marks.clear();
            marksCommand = report.command();
        }
        AnalysisReport.Growth g = report.growth();
        if (g == null || g.loop() == null || !g.loop().hasOrder()) {
            return;
        }
        AnalysisReport.Fit fit = g.loop().growth();
        marks.add(new AnalysisRun.GrowthMark(report.elapsedS(), g.loop().line(), fit.key(), fit.display()));
        if (marks.size() > MARK_LIMIT) {
            // Keep every other mark: the steps change rarely, so nothing visible is lost.
            for (int i = marks.size() - 2; i > 0; i -= 2) {
                marks.remove(i);
            }
        }
    }
}
