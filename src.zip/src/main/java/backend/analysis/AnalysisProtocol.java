package backend.analysis;

/**
 * The IDE side of nc.exe's Analysis box and CPU monitor protocol, version 1.
 * The contracts are {@code docs/Analysis_Section_Java_Handover.md} and
 * {@code docs/Parallel_Monitor_Java_Handover.md}; the C++ side is
 * {@code runtime/execution/analysis/analysis.cpp},
 * {@code runtime/execution/parallel/par_monitor.cpp} and {@code main.cpp}.
 *
 * <h3>Two channels per feature</h3>
 * <ul>
 * <li>A live file in the session folder, rewritten every interval while a
 * command runs: {@value #ANALYSIS_FILE} (1 s) and {@value #PARMON_FILE}
 * (250 ms). Each is replaced atomically by a rename.</li>
 * <li>A protocol line on stdout once per command, just before
 * {@code @PROMPT}: {@value #ANALYSIS} and {@value #PARMON}. The parmon line
 * also answers {@link #PARMON_SNAPSHOT}.</li>
 * </ul>
 */
public final class AnalysisProtocol {

    /** Protocol line keyword: the Analysis box's per-command summary. */
    public static final String ANALYSIS = "@ANALYSIS";

    /** Protocol line keyword: the CPU monitor's summary, or a snapshot on request. */
    public static final String PARMON = "@PARMON";

    /** Live Analysis document in the session folder. */
    public static final String ANALYSIS_FILE = "analysis.json";

    /** Live CPU monitor snapshot in the session folder. */
    public static final String PARMON_FILE = "parmon.json";

    /** The protocol version this IDE understands. */
    public static final int VERSION = 1;

    /** Asks nc.exe for one {@code @PARMON} snapshot line now (about 100 ms). */
    public static final String PARMON_SNAPSHOT = "@cmd parmon snapshot";

    /** The {@code build} field of a Debug nc.exe: unoptimised, timings 3-40x slower. */
    public static final String BUILD_DEBUG = "debug";

    /** The warning shown wherever timings appear while nc.exe is a Debug build. */
    public static final String DEBUG_WARNING = "Debug build of nc: timings are 3\u201340\u00d7 slower";

    /** Live period of the Analysis file, agreed with the C++ side: one update a second. */
    public static final long ANALYSIS_INTERVAL_MS = 1000;

    /** Live period of the monitor file when no snapshot has said otherwise. */
    public static final long PARMON_INTERVAL_MS = 250;

    private AnalysisProtocol() {
    }

    /**
     * @param line a protocol line without its Record Separator
     * @return true for an {@code @ANALYSIS} or {@code @PARMON} line
     */
    public static boolean isAnalysisLine(String line) {
        return line != null && (line.startsWith(ANALYSIS + " ") || line.startsWith(PARMON + " "));
    }

    /**
     * @param backend the {@code backend} field: {@code openmp}, {@code stdpool} or {@code serial}
     * @return the word the UI shows (no library names in the UI)
     */
    public static String backendLabel(String backend) {
        if (backend == null) {
            return AnalysisFormat.NONE;
        }
        return switch (backend) {
            case "openmp" -> "multicore";
            case "stdpool" -> "portable threads";
            case "serial" -> "single thread";
            default -> backend;
        };
    }

    /**
     * @param os the {@code os} field
     * @return the operating system's display name
     */
    public static String osLabel(String os) {
        if (os == null) {
            return AnalysisFormat.NONE;
        }
        return switch (os) {
            case "windows" -> "Windows";
            case "linux" -> "Linux";
            case "macos" -> "macOS";
            case "freebsd" -> "FreeBSD";
            case "openbsd" -> "OpenBSD";
            case "netbsd" -> "NetBSD";
            case "unix" -> "Unix";
            default -> "Unknown OS";
        };
    }
}
