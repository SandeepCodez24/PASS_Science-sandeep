// Stack limits per operating system - see stack_guard.h.
#include "stack_guard.h"

#include <algorithm>

#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#elif defined(__APPLE__)
#include <pthread.h>
#elif defined(__linux__) || defined(__FreeBSD__)
#include <pthread.h>
#if defined(__FreeBSD__)
#include <pthread_np.h>
#endif
#endif

namespace nc {
namespace stackguard {

namespace {

constexpr std::size_t kMinReserve = 256 * 1024;
// Without a way to ask the system, assume a 1 MB stack measured from the
// first frame that asks - small enough to be safe on every system.
constexpr std::size_t kFallbackSize = 1024 * 1024;

struct Bounds {
  std::uintptr_t low = 0, high = 0;
};

bool queryBounds(Bounds &b) {
#if defined(_WIN32)
  ULONG_PTR low = 0, high = 0;
  GetCurrentThreadStackLimits(&low, &high);
  b.low = static_cast<std::uintptr_t>(low);
  b.high = static_cast<std::uintptr_t>(high);
  // The last pages are the guard page and the space Windows keeps for
  // handling a stack overflow: never usable.
  b.low += 64 * 1024;
  return b.high > b.low;
#elif defined(__APPLE__)
  pthread_t self = pthread_self();
  const std::uintptr_t top = reinterpret_cast<std::uintptr_t>(pthread_get_stackaddr_np(self));
  const std::size_t size = pthread_get_stacksize_np(self);
  b.high = top;
  b.low = top - size + 64 * 1024;
  return size > 128 * 1024;
#elif defined(__linux__) || defined(__FreeBSD__)
  pthread_attr_t attr;
#if defined(__FreeBSD__)
  pthread_attr_init(&attr);
  if (pthread_attr_get_np(pthread_self(), &attr) != 0)
    return false;
#else
  if (pthread_getattr_np(pthread_self(), &attr) != 0)
    return false;
#endif
  void *addr = nullptr;
  std::size_t size = 0;
  const bool ok = pthread_attr_getstack(&attr, &addr, &size) == 0 && addr && size > 128 * 1024;
  pthread_attr_destroy(&attr);
  if (!ok)
    return false;
  // The main thread's stack grows on demand up to its rlimit; glibc reports
  // that limit as the size, so this is the real end.
  b.low = reinterpret_cast<std::uintptr_t>(addr) + 64 * 1024;
  b.high = reinterpret_cast<std::uintptr_t>(addr) + size;
  return true;
#else
  (void)b;
  return false;
#endif
}

} // namespace

Limits makeLimits() {
  Limits l;
  Bounds b;
  if (!queryBounds(b)) {
    const std::uintptr_t now = here();
    if (now <= kFallbackSize)
      return l; // nothing sensible to compare against
    b.high = now;
    b.low = now - kFallbackSize;
  }
  const std::size_t size = static_cast<std::size_t>(b.high - b.low);
  l.low = b.low;
  l.reserve = std::max(kMinReserve, size / 8);
  if (l.reserve >= size)
    l.reserve = size / 2;
  l.known = true;
  return l;
}

std::size_t stackSize() {
  Bounds b;
  return queryBounds(b) ? static_cast<std::size_t>(b.high - b.low) : 0;
}

} // namespace stackguard
} // namespace nc
