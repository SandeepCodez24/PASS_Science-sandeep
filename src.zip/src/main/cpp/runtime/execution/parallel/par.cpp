// nc::par - planning, the region runner and the three backends.
// See par.h for the contract and docs/Multicore_Multithread_Architecture.md
// for the measurements behind the constants.

#include "par.h"

#include "Interrupt.h"
#include "par_monitor.h"
#include "sys_cpu.h"

#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <mutex>
#include <random>
#include <string>
#include <thread>
#include <vector>

// Exactly one backend is compiled in; CMake defines it (NC_PAR_BACKEND).
#if defined(NC_PAR_BACKEND_OPENMP)
#if !defined(_OPENMP)
#error "NC_PAR_BACKEND_OPENMP needs the compiler's OpenMP support (-fopenmp)"
#endif
#include <omp.h>
#elif !defined(NC_PAR_BACKEND_STDPOOL) && !defined(NC_PAR_BACKEND_SERIAL)
// A build that does not say: OpenMP when the compiler has it, else the pool.
#if defined(_OPENMP)
#define NC_PAR_BACKEND_OPENMP 1
#include <omp.h>
#else
#define NC_PAR_BACKEND_STDPOOL 1
#endif
#endif

namespace nc::par {

namespace {

/* ------------------------------------------------------------ constants */

// Section 4.1 of the design. Measured on a 20-core / 28-thread hybrid CPU;
// they only steer speed, never results.
constexpr double kSerialBelowNs = 200000.0; // ~5x the 16-thread fork/join cost
constexpr double kBlockNs = 50000.0;        // work per block; Stop granularity
constexpr double kNsPerThread = 25000.0;    // at least this much work per thread
constexpr size_t kMinBlock = 1024;
constexpr int kStreamCap = 8;  // memory bandwidth: no gain past ~8 threads
constexpr int kReduceCap = 16;
constexpr int kMaxThreads = 1024;

/* ------------------------------------------------------------- settings */

std::atomic<int> g_threads{0}; // 0 until initialize()
int g_defaultThreads = 1;
std::atomic<bool> g_initialized{false};

thread_local bool t_inRegion = false;
thread_local bool t_isInterpreter = false;

// NC_PAR_CHECK: run blocks in another order to expose blocks that depend on
// each other. Results must be bit-identical in every mode.
enum class CheckMode { None, Reverse, Shuffle };
CheckMode g_check = CheckMode::None;
uint64_t g_checkSeed = 0;

int parsePositive(const char *text) {
  if (!text || !*text)
    return 0;
  char *end = nullptr;
  const long v = std::strtol(text, &end, 10);
  if (end == text || v <= 0)
    return 0;
  return v > kMaxThreads ? kMaxThreads : static_cast<int>(v);
}

std::string envText(const char *name) {
#if defined(_WIN32)
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, name) != 0 || buffer == nullptr)
    return "";
  std::string value(buffer);
  std::free(buffer);
  return value;
#else
  const char *value = std::getenv(name);
  return value ? std::string(value) : std::string();
#endif
}

void applyBackendThreads(int n) {
#if defined(NC_PAR_BACKEND_OPENMP)
  // Eigen reads omp_get_max_threads(), so its products follow set_threads().
  omp_set_num_threads(n);
#else
  (void)n;
#endif
}

int capOf(Kind k) {
  switch (k) {
  case Kind::Stream:
    return kStreamCap;
  case Kind::Reduce:
    return kReduceCap;
  default:
    return kMaxThreads;
  }
}

int threadsFor(Kind kind, double workNs, size_t blocks) {
  if (t_inRegion)
    return 1; // one level of parallelism only
  double byWork = workNs / kNsPerThread;
  int t = threadCount();
  t = std::min(t, capOf(kind));
  if (byWork < t)
    t = byWork < 1.0 ? 1 : static_cast<int>(byWork);
  if (blocks < static_cast<size_t>(t))
    t = static_cast<int>(blocks);
  return t < 1 ? 1 : t;
}

/* -------------------------------------------------------------- stdpool */

#if defined(NC_PAR_BACKEND_STDPOOL)
// A pool of std::thread workers for builds without OpenMP. Workers sleep on
// a condition variable between regions (0% CPU when idle). The calling
// thread always takes part, so a region with T threads wakes T - 1 workers.
class Pool {
public:
  using Work = void (*)(void *ctx, int slot);

  void run(int threads, Work work, void *ctx) {
    const int helpers = threads - 1;
    grow(helpers);
    {
      std::lock_guard<std::mutex> lk(mutex_);
      work_ = work;
      ctx_ = ctx;
      helpers_ = helpers;
      finished_ = 0;
      generation_++;
    }
    wake_.notify_all();
    work(ctx, 0);
    std::unique_lock<std::mutex> lk(mutex_);
    done_.wait(lk, [&] { return finished_ == helpers_; });
  }

private:
  void grow(int helpers) {
    std::lock_guard<std::mutex> lk(mutex_);
    while (static_cast<int>(workers_) < helpers) {
      const int index = static_cast<int>(workers_++);
      // The generation BEFORE the region being started: run() bumps it right
      // after grow(), so the new worker joins that region however late its
      // thread actually starts.
      const uint64_t seen = generation_;
      // Detached: the pool lives until the process ends, and a sleeping
      // worker holds nothing that needs releasing.
      std::thread([this, index, seen] { loop(index, seen); }).detach();
    }
  }

  void loop(int index, uint64_t seen) {
    for (;;) {
      Work work;
      void *ctx;
      {
        std::unique_lock<std::mutex> lk(mutex_);
        wake_.wait(lk, [&] { return generation_ != seen; });
        seen = generation_;
        if (index >= helpers_)
          continue; // not needed this time
        work = work_;
        ctx = ctx_;
      }
      work(ctx, index + 1);
      std::lock_guard<std::mutex> lk(mutex_);
      if (++finished_ == helpers_)
        done_.notify_one();
    }
  }

  std::mutex mutex_;
  std::condition_variable wake_, done_;
  size_t workers_ = 0;
  uint64_t generation_ = 0;
  Work work_ = nullptr;
  void *ctx_ = nullptr;
  int helpers_ = 0;
  int finished_ = 0;
};

Pool &pool() {
  static Pool *p = new Pool; // never destroyed: see grow()
  return *p;
}
#endif

/* ----------------------------------------------------------- the region */

struct Region {
  const Plan *plan;
  BlockFn fn;
  void *ctx;
  BlockError *error;
  bool monitored;
  bool interpreterCalled; // the caller is the interpreter thread
  std::vector<size_t> order; // NC_PAR_CHECK only
  std::atomic<size_t> next{0};
  std::atomic<bool> stop{false};
  std::atomic<bool> stopped{false};
  std::mutex exceptionMutex;
  std::exception_ptr exception;
  std::atomic<size_t> exceptionBlock{SIZE_MAX};
};

// One participating thread: claims blocks until none are left.
void participate(Region &r, int slot, bool isCaller) {
  const bool wasInRegion = t_inRegion;
  t_inRegion = true;
  const size_t blocks = r.plan->blocks;
  for (;;) {
    if (r.stop.load(std::memory_order_relaxed))
      break;
    // Stop: the interpreter thread looks at the IDE's flag file (poll() is
    // interpreter-only); every other thread reads the shared atomic.
    const bool stopRequested = !r.plan->stoppable ? false
                               : (isCaller && r.interpreterCalled) ? nc::Interrupt::poll()
                                                                   : nc::Interrupt::requested();
    if (stopRequested) {
      r.stopped.store(true);
      r.stop.store(true);
      break;
    }
    const size_t ticket = r.next.fetch_add(1, std::memory_order_relaxed);
    if (ticket >= blocks)
      break;
    const size_t block = r.order.empty() ? ticket : r.order[ticket];
    // Past an error: the result will be discarded, skip the work. Blocks
    // before it still run, so the lowest-index error is the one kept.
    if (r.error && r.error->any() && block * r.plan->blockSize > r.error->item())
      continue;
    if (block > r.exceptionBlock.load(std::memory_order_relaxed))
      continue;

    std::chrono::steady_clock::time_point t0;
    if (r.monitored)
      t0 = std::chrono::steady_clock::now();
    try {
      r.fn(r.ctx, block);
    } catch (...) {
      std::lock_guard<std::mutex> lk(r.exceptionMutex);
      if (block < r.exceptionBlock.load()) {
        r.exceptionBlock.store(block);
        r.exception = std::current_exception();
      }
    }
    if (r.monitored) {
      const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                          std::chrono::steady_clock::now() - t0)
                          .count();
      monitor::blockDone(slot, static_cast<uint64_t>(ns), sys::currentProcessor());
    }
  }
  t_inRegion = wasInRegion;
}

#if defined(NC_PAR_BACKEND_STDPOOL)
void poolWork(void *ctx, int slot) { participate(*static_cast<Region *>(ctx), slot, slot == 0); }
#endif

} // namespace

/* ================================================================ public */

const char *kindName(Kind k) {
  switch (k) {
  case Kind::Stream:
    return "Stream";
  case Kind::Reduce:
    return "Reduce";
  case Kind::Compute:
    return "Compute";
  case Kind::Task:
    return "Task";
  }
  return "?";
}

Plan plan(size_t n, Cost cost) {
  Plan p;
  p.n = n;
  if (n == 0)
    return p;
  const double ns = cost.nsPerItem > 0 ? cost.nsPerItem : 1.0;
  const double work = static_cast<double>(n) * ns;
  if (work < kSerialBelowNs || n <= kMinBlock) {
    p.blockSize = n;
    p.blocks = 1;
    return p;
  }
  // 50 us of work, to the nearest power of two, never below kMinBlock.
  const double ideal = kBlockNs / ns;
  size_t block = kMinBlock;
  while (static_cast<double>(block) * 2.0 <= ideal)
    block *= 2;
  if (static_cast<double>(block) * 2.0 - ideal < ideal - static_cast<double>(block))
    block *= 2; // nearer to the next power up
  p.blockSize = block;
  p.blocks = (n + block - 1) / block;
  p.threads = threadsFor(cost.kind, work, p.blocks);
  return p;
}

Plan taskPlan(size_t jobs, double nsPerJob) {
  Plan p;
  p.n = jobs;
  if (jobs == 0)
    return p;
  p.blockSize = 1;
  p.blocks = jobs;
  const double work = static_cast<double>(jobs) * (nsPerJob > 0 ? nsPerJob : 1.0);
  p.threads = (work < kSerialBelowNs || jobs < 2) ? 1 : threadsFor(Kind::Task, work, jobs);
  return p;
}

Plan planWithBlockSize(size_t n, Cost cost, size_t blockSize) {
  Plan p;
  p.n = n;
  if (n == 0)
    return p;
  p.blockSize = blockSize > 0 ? blockSize : n;
  p.blocks = (n + p.blockSize - 1) / p.blockSize;
  const double work = static_cast<double>(n) * cost.nsPerItem;
  p.threads = (cost.nsPerItem <= 0 || work < kSerialBelowNs || p.blocks < 2)
                  ? 1
                  : threadsFor(cost.kind, work, p.blocks);
  return p;
}

int threadCount() {
  const int t = g_threads.load(std::memory_order_relaxed);
  return t > 0 ? t : 1;
}

int defaultThreadCount() { return g_defaultThreads; }

int setThreadCount(int n) {
  const int previous = threadCount();
  const int t = n <= 0 ? g_defaultThreads : std::min(n, kMaxThreads);
  g_threads.store(t);
  applyBackendThreads(t);
  return previous;
}

int logicalProcessors() {
  static const int n = sys::logicalProcessors();
  return n;
}

const char *backendName() {
#if defined(NC_PAR_BACKEND_OPENMP)
  return "openmp";
#elif defined(NC_PAR_BACKEND_STDPOOL)
  return "stdpool";
#else
  return "serial";
#endif
}

const char *buildType() {
#ifdef NDEBUG
  return "release";
#else
  return "debug";
#endif
}

bool inRegion() { return t_inRegion; }

bool isInterpreterThread() { return t_isInterpreter || !g_initialized.load(); }

void assertInterpreterThreadImpl(const char *where) {
  if (isInterpreterThread() && !t_inRegion)
    return;
  std::fprintf(stderr,
               "nc internal error: %s ran on a worker thread. Interpreter-only code must not be "
               "called from inside nc::par blocks.\n",
               where ? where : "interpreter code");
  std::abort();
}

void initialize() {
  t_isInterpreter = true;
#if defined(NC_PAR_BACKEND_SERIAL)
  g_defaultThreads = 1;
#else
  g_defaultThreads = logicalProcessors();
  int requested = parsePositive(envText("NC_THREADS").c_str());
  if (requested == 0)
    requested = parsePositive(envText("OMP_NUM_THREADS").c_str()); // first number of a list
  if (requested > 0)
    g_defaultThreads = requested;
#endif
  g_threads.store(g_defaultThreads);
  applyBackendThreads(g_defaultThreads);

#if defined(NC_PAR_BACKEND_OPENMP) && defined(KMP_VERSION_MAJOR)
  // libomp keeps idle workers spinning for 200 ms after every region, which
  // burns CPU and battery in an interactive session. 20 ms keeps tight
  // sequences of regions fast and lets an idle REPL drop to 0% CPU. The
  // user's own KMP_BLOCKTIME wins.
  if (envText("KMP_BLOCKTIME").empty())
    kmp_set_blocktime(20);
#endif

  const std::string check = envText("NC_PAR_CHECK");
  if (check == "reverse") {
    g_check = CheckMode::Reverse;
  } else if (check.rfind("shuffle", 0) == 0) {
    g_check = CheckMode::Shuffle;
    const size_t colon = check.find(':');
    g_checkSeed = colon != std::string::npos
                      ? std::strtoull(check.c_str() + colon + 1, nullptr, 10)
                      : static_cast<uint64_t>(std::random_device{}());
    std::fprintf(stderr, "nc: NC_PAR_CHECK=shuffle:%llu\n",
                 static_cast<unsigned long long>(g_checkSeed));
  }
  g_initialized.store(true);
}

namespace {
thread_local const char *t_callLabel = nullptr;
}

const char *currentCallLabel() { return t_callLabel; }

CallLabel::CallLabel(const char *name) : previous_(t_callLabel) { t_callLabel = name; }

CallLabel::~CallLabel() { t_callLabel = previous_; }

void setBlockOrder(BlockOrder order, uint64_t seed) {
  g_check = order == BlockOrder::Reverse   ? CheckMode::Reverse
            : order == BlockOrder::Shuffle ? CheckMode::Shuffle
                                           : CheckMode::None;
  g_checkSeed = seed;
}

void BlockError::report(size_t item, std::string message) {
  std::lock_guard<std::mutex> lk(mutex_);
  if (item < first_.load(std::memory_order_relaxed)) {
    message_ = std::move(message);
    first_.store(item, std::memory_order_release);
  }
}

Outcome runRegion(const Plan &p, Kind kind, const char *label, BlockFn fn, void *ctx,
                  BlockError *error) {
  Region r;
  r.plan = &p;
  r.fn = fn;
  r.ctx = ctx;
  r.error = error;
  r.interpreterCalled = isInterpreterThread() && !t_inRegion;
  const bool nested = t_inRegion;
  int threads = nested ? 1 : p.threads;
#if defined(NC_PAR_BACKEND_SERIAL)
  threads = 1;
#endif
  if (threads > static_cast<int>(p.blocks))
    threads = static_cast<int>(p.blocks);

  if (g_check != CheckMode::None) {
    r.order.resize(p.blocks);
    for (size_t i = 0; i < p.blocks; i++)
      r.order[i] = g_check == CheckMode::Reverse ? p.blocks - 1 - i : i;
    if (g_check == CheckMode::Shuffle) {
      std::mt19937_64 rng(g_checkSeed ^ (p.n * 0x9E3779B97F4A7C15ull));
      std::shuffle(r.order.begin(), r.order.end(), rng);
    }
  }

  // Only top-level regions on the interpreter thread are shown; a nested
  // one runs inside a block that is already counted.
  r.monitored = !nested && monitor::enabled();
  if (r.monitored)
    monitor::regionBegin(kind, label, p.n, p.blocks, threads);

  if (threads <= 1) {
    participate(r, 0, true);
  } else {
#if defined(NC_PAR_BACKEND_OPENMP)
#pragma omp parallel num_threads(threads)
    {
      const int slot = omp_get_thread_num();
      participate(r, slot, slot == 0);
    }
#elif defined(NC_PAR_BACKEND_STDPOOL)
    pool().run(threads, &poolWork, &r);
#else
    participate(r, 0, true);
#endif
  }

  if (r.monitored)
    monitor::regionEnd(r.stopped.load());

  if (r.exception)
    std::rethrow_exception(r.exception);
  if (r.stopped.load())
    return Outcome::Stopped;
  if (error && error->any())
    return Outcome::Failed;
  return Outcome::Done;
}

} // namespace nc::par
