// CPU core and thread monitor - see par_monitor.h and
// docs/Parallel_Monitor_Java_Handover.md for the JSON formats.

#include "par_monitor.h"

#include "sys_cpu.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <system_error>
#include <thread>
#include <vector>

namespace nc::par::monitor {

namespace {

using Clock = std::chrono::steady_clock;

/* ---- per-thread counters (written per block, only while enabled) ---- */

struct alignas(64) Slot {
  std::atomic<uint64_t> blocks{0};
  std::atomic<uint64_t> busyNs{0};
  std::atomic<int> processor{-1};
};
Slot g_slots[kSlots];

// NC's block time per logical processor (Phase 5): the "NC" part of each
// core tile. Processors past the table are not split (machines with more
// than 1024 logical processors show the whole load only).
constexpr int kCoreSlots = 1024;
std::atomic<uint64_t> g_coreNs[kCoreSlots];
std::atomic<bool> g_coreKnown{false}; // some block knew its processor (not macOS)

std::atomic<bool (*)(MemoryReading &)> g_memorySource{nullptr};

/* ---- switches ---- */

std::atomic<bool> g_available{false}; // IDE mode (a session folder)
std::atomic<bool> g_enabled{false};   // panel open
std::atomic<int> g_intervalMs{250};
std::filesystem::path g_file, g_tmpFile;

/* ---- command state ---- */

std::atomic<bool> g_busy{false};        // a command is running
std::atomic<uint64_t> g_commandSeq{0};  // bumped by commandStarted()

// Everything below is guarded by g_mutex.
std::mutex g_mutex;
std::condition_variable g_cv;
bool g_threadStarted = false;

struct RegionState {
  bool active = false;
  std::string label;
  Kind kind = Kind::Compute;
  size_t items = 0, blocks = 0;
  int threads = 0;
  Clock::time_point start;
  uint64_t faults = 0; // machine hard faults at the start
  bool faultsOk = false;
};
RegionState g_region;

struct KernelStats {
  std::string label;
  Kind kind = Kind::Compute;
  uint64_t count = 0;
  uint64_t items = 0;
  double ms = 0;
  int maxThreads = 0;
  uint64_t faults = 0; // hard faults while it ran (whole machine)
  bool faultsOk = true;
};
std::vector<KernelStats> g_kernels; // this command, in first-use order
uint64_t g_regions = 0;
double g_parallelMs = 0;
int g_maxThreads = 0;
bool g_anyStopped = false;
Clock::time_point g_commandStart;
uint64_t g_commandCpuStart = 0;
Clock::time_point g_commandEnd;
uint64_t g_commandCpuEnd = 0;
uint64_t g_commandFaultsStart = 0, g_commandFaultsEnd = 0;
bool g_commandFaultsOk = false;
uint64_t g_snapshotSeq = 0;
bool g_summaryPending = false; // commandFinished() ran, takeCommandSummary() not yet

/* ---- the sampler's view of the previous sample (sampler thread only,
        or under g_mutex for snapshotNow) ---- */

struct Sample {
  Clock::time_point time;
  std::vector<sys::CoreTimes> cores;
  bool coresOk = false;
  uint64_t processCpu = 0;
  uint64_t slotBusy[kSlots] = {};
  uint64_t slotBlocks[kSlots] = {};
  std::vector<uint64_t> coreNs; // g_coreNs, one per entry of `cores`
  uint64_t faults = 0;
  bool faultsOk = false;
};

void takeSample(Sample &s) {
  s.time = Clock::now();
  s.coresOk = sys::coreTimes(s.cores);
  s.processCpu = sys::processCpuNs();
  for (int i = 0; i < kSlots; i++) {
    s.slotBusy[i] = g_slots[i].busyNs.load(std::memory_order_relaxed);
    s.slotBlocks[i] = g_slots[i].blocks.load(std::memory_order_relaxed);
  }
  const size_t n = std::min<size_t>(s.cores.size(), kCoreSlots);
  s.coreNs.resize(n);
  for (size_t i = 0; i < n; i++)
    s.coreNs[i] = g_coreNs[i].load(std::memory_order_relaxed);
  s.faultsOk = sys::hardFaults(s.faults);
}

double ms(Clock::duration d) {
  return std::chrono::duration<double, std::milli>(d).count();
}

// Fixed-point text with up to `digits` decimals, no locale, no exponent.
std::string num(double x, int digits = 3) {
  if (!(x == x) || x < -1e15 || x > 1e15)
    return "0";
  char buf[64];
  std::snprintf(buf, sizeof buf, "%.*f", digits, x);
  std::string s = buf;
  if (s.find('.') != std::string::npos) {
    while (!s.empty() && s.back() == '0')
      s.pop_back();
    if (!s.empty() && s.back() == '.')
      s.pop_back();
  }
  return s == "-0" ? "0" : s;
}

std::string jsonText(const std::string &text) {
  std::string out = "\"";
  for (char c : text) {
    const unsigned char u = static_cast<unsigned char>(c);
    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if (u < 0x20) {
      char buf[8];
      std::snprintf(buf, sizeof buf, "\\u%04x", u);
      out += buf;
    } else {
      out += c;
    }
  }
  return out + "\"";
}

const char *kindKey(Kind k) {
  switch (k) {
  case Kind::Stream:
    return "stream";
  case Kind::Reduce:
    return "reduce";
  case Kind::Compute:
    return "compute";
  case Kind::Task:
    return "task";
  }
  return "compute";
}

// The parts every snapshot shares: who we are and what the machine is.
std::string headerFields() {
  return std::string("\"os\":") + jsonText(sys::osName()) + ",\"backend\":" + jsonText(backendName()) +
         ",\"build\":" + jsonText(buildType()) +
         ",\"logical_processors\":" + std::to_string(logicalProcessors()) +
         ",\"thread_setting\":" + std::to_string(threadCount()) +
         ",\"stream_threads\":" + std::to_string(streamThreadCap()) +
         ",\"reduce_threads\":" + std::to_string(reduceThreadCap()) +
         ",\"interval_ms\":" + std::to_string(g_intervalMs.load());
}

// Hard faults per second at or above which, with free RAM short, the
// machine counts as paging (the red flag). 100 page-read I/Os a second
// keep an ordinary SSD visibly busy; RAM is "short" below 10 % of it.
constexpr double kPagingRate = 100.0;

// The "memory" object: the governor's numbers (or the OS's), the disk tier,
// and the hard fault rate over the interval.
std::string memoryFields(const Sample &prev, const Sample &now, double wallNs) {
  MemoryReading m;
  bool (*reader)(MemoryReading &) = g_memorySource.load();
  if (!reader || !reader(m)) {
    sys::MemoryInfo info;
    if (sys::memoryInfo(info)) {
      m.used = info.used;
      m.peak = info.peak;
      m.available = info.available;
      m.total = info.limit && info.limit < info.total ? info.limit : info.total;
    }
  }
  std::string j = ",\"memory\":{\"used\":" + std::to_string(m.used) + ",\"peak\":" + std::to_string(m.peak) +
                  ",\"available\":" + std::to_string(m.available) + ",\"total\":" + std::to_string(m.total) +
                  ",\"budget\":" + std::to_string(m.budget) + ",\"percent\":" + std::to_string(m.percent) +
                  ",\"enforced\":" + (m.enforced ? "true" : "false") +
                  ",\"disk_used\":" + std::to_string(m.diskUsed) + ",\"disk_room\":" + std::to_string(m.diskRoom);
  double rate = -1;
  if (prev.faultsOk && now.faultsOk && wallNs > 0 && now.faults >= prev.faults)
    rate = static_cast<double>(now.faults - prev.faults) / (wallNs / 1e9);
  j += ",\"hard_faults_per_s\":" + (rate < 0 ? std::string("null") : num(rate, 0));
  const bool ramShort = m.total > 0 && m.available < m.total / 10;
  j += std::string(",\"paging\":") + (rate >= kPagingRate && ramShort ? "true" : "false") + "}";
  return j;
}

// A snapshot from the change between `prev` and `now`.
std::string buildSnapshot(const Sample &prev, const Sample &now, bool running) {
  const double wallNs = std::chrono::duration<double, std::nano>(now.time - prev.time).count();
  std::string j = "{\"v\":1,\"type\":\"parmon\"";
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    j += ",\"seq\":" + std::to_string(++g_snapshotSeq);
  }
  j += std::string(",\"state\":") + (running ? "\"running\"" : "\"idle\"");
  j += "," + headerFields();

  // Devices. Only "cpu" today; a GPU backend adds {"kind":"gpu",...} entries
  // to this array without changing anything around it.
  j += ",\"devices\":[{\"kind\":\"cpu\",\"index\":0";
  const bool coresOk = prev.coresOk && now.coresOk && prev.cores.size() == now.cores.size();
  j += std::string(",\"core_load_available\":") + (coresOk ? "true" : "false");
  j += ",\"cores\":[";
  if (coresOk) {
    for (size_t i = 0; i < now.cores.size(); i++) {
      const double dt = static_cast<double>(now.cores[i].total - prev.cores[i].total);
      const double db = static_cast<double>(now.cores[i].busy - prev.cores[i].busy);
      double load = dt > 0 ? db / dt : 0.0;
      load = std::clamp(load, 0.0, 1.0);
      j += (i ? "," : "") + num(load);
    }
  }
  j += "]";
  // NC's part of each core's load (Phase 5): the time NC's blocks ran there
  // over the interval, never more than the core's load. Left out where no
  // block knows its processor (macOS) - the panel then shows the load only.
  if (coresOk && g_coreKnown.load(std::memory_order_relaxed) && prev.coreNs.size() == now.coreNs.size()) {
    j += ",\"nc\":[";
    for (size_t i = 0; i < now.cores.size(); i++) {
      double share = 0;
      if (i < now.coreNs.size() && wallNs > 0 && now.coreNs[i] >= prev.coreNs[i]) {
        const double dt = static_cast<double>(now.cores[i].total - prev.cores[i].total);
        const double db = static_cast<double>(now.cores[i].busy - prev.cores[i].busy);
        const double load = dt > 0 ? std::clamp(db / dt, 0.0, 1.0) : 0.0;
        share = std::min(load, static_cast<double>(now.coreNs[i] - prev.coreNs[i]) / wallNs);
      }
      j += (i ? "," : "") + num(share);
    }
    j += "]";
  }
  j += "}]";

  // This process (all its threads, Eigen's and OpenMP's included).
  const double cpuNs = static_cast<double>(now.processCpu - prev.processCpu);
  j += ",\"process\":{\"cpu_cores_busy\":" + num(wallNs > 0 ? cpuNs / wallNs : 0.0, 2) + "}";
  j += memoryFields(prev, now, wallNs);

  // NC's own threads: share of the interval each slot spent in blocks.
  j += ",\"threads\":[";
  bool first = true;
  for (int i = 0; i < kSlots; i++) {
    const uint64_t blocks = now.slotBlocks[i] - prev.slotBlocks[i];
    if (blocks == 0)
      continue;
    const double busy = wallNs > 0 ? static_cast<double>(now.slotBusy[i] - prev.slotBusy[i]) / wallNs : 0;
    j += first ? "" : ",";
    first = false;
    j += "{\"slot\":" + std::to_string(i) + ",\"busy\":" + num(std::clamp(busy, 0.0, 1.0)) +
         ",\"blocks\":" + std::to_string(blocks) +
         ",\"processor\":" + std::to_string(g_slots[i].processor.load(std::memory_order_relaxed)) + "}";
  }
  j += "]";

  std::lock_guard<std::mutex> lk(g_mutex);
  if (g_region.active) {
    j += ",\"region\":{\"label\":" + jsonText(g_region.label) + ",\"kind\":" + jsonText(kindKey(g_region.kind)) +
         ",\"items\":" + std::to_string(g_region.items) + ",\"blocks\":" + std::to_string(g_region.blocks) +
         ",\"threads\":" + std::to_string(g_region.threads) +
         ",\"elapsed_ms\":" + num(ms(now.time - g_region.start), 1) + "}";
  } else {
    j += ",\"region\":null";
  }
  // The running command, or (state "idle") the one that just finished.
  j += ",\"command\":{\"elapsed_ms\":" + num(ms(now.time - g_commandStart), 1) +
       ",\"regions\":" + std::to_string(g_regions) + ",\"parallel_ms\":" + num(g_parallelMs, 1) + "}";
  j += "}";
  return j;
}

void writeSnapshot(const std::string &json) {
  {
    std::ofstream out(g_tmpFile, std::ios::binary | std::ios::trunc);
    if (!out)
      return;
    out << json << '\n';
    if (!out)
      return;
  }
  std::error_code ec;
  std::filesystem::rename(g_tmpFile, g_file, ec); // replaces; a reader holding it open = skip
}

bool stillRunning(uint64_t command) {
  return g_busy.load() && g_enabled.load() && g_commandSeq.load() == command;
}

void samplerLoop() {
  Sample prev, now;
  std::unique_lock<std::mutex> lk(g_mutex);
  for (;;) {
    g_cv.wait(lk, [] { return g_busy.load() && g_enabled.load(); });
    const uint64_t command = g_commandSeq.load();

    lk.unlock();
    takeSample(prev); // baseline at the start of the command
    lk.lock();

    // Grace interval: a command that ends within it leaves no trace.
    const auto interval = [] { return std::chrono::milliseconds(g_intervalMs.load()); };
    g_cv.wait_for(lk, interval(), [&] { return !stillRunning(command); });
    bool wrote = false;
    while (stillRunning(command)) {
      lk.unlock();
      takeSample(now);
      writeSnapshot(buildSnapshot(prev, now, true));
      std::swap(prev, now);
      wrote = true;
      lk.lock();
      g_cv.wait_for(lk, interval(), [&] { return !stillRunning(command); });
    }
    if (wrote) {
      // One last snapshot so the panel shows the command has ended.
      lk.unlock();
      takeSample(now);
      writeSnapshot(buildSnapshot(prev, now, false));
      lk.lock();
    }
    // Wait for the next command - or for the panel to reopen while this
    // command is still running, which resumes sampling it.
    g_cv.wait(lk, [&] {
      return g_commandSeq.load() != command || !g_busy.load() || g_enabled.load();
    });
  }
}

void startSamplerLocked() {
  if (g_threadStarted)
    return;
  g_threadStarted = true;
  // Detached on purpose: it sleeps between commands and owns nothing that
  // needs cleaning up, so the process may end at any moment.
  std::thread(samplerLoop).detach();
}

} // namespace

void configure(const std::string &sessionDirectory) {
  if (sessionDirectory.empty())
    return;
  g_file = std::filesystem::path(sessionDirectory) / "parmon.json";
  g_tmpFile = std::filesystem::path(sessionDirectory) / "parmon.json.tmp";
  g_available.store(true);
}

void setEnabled(bool on) {
  if (!g_available.load())
    return;
  std::lock_guard<std::mutex> lk(g_mutex);
  g_enabled.store(on);
  if (on)
    startSamplerLocked();
  g_cv.notify_all();
}

bool enabled() { return g_enabled.load(std::memory_order_relaxed); }

void setIntervalMs(int msValue) {
  g_intervalMs.store(std::clamp(msValue, 100, 5000));
}

void commandStarted() {
  if (!g_available.load(std::memory_order_relaxed))
    return;
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    g_kernels.clear();
    g_regions = 0;
    g_parallelMs = 0;
    g_maxThreads = 0;
    g_anyStopped = false;
    g_commandStart = Clock::now();
  }
  g_commandCpuStart = enabled() ? sys::processCpuNs() : 0;
  g_commandFaultsOk = enabled() && sys::hardFaults(g_commandFaultsStart);
  g_commandSeq.fetch_add(1);
  g_busy.store(true);
  if (enabled())
    g_cv.notify_all();
}

void commandFinished() {
  if (!g_available.load(std::memory_order_relaxed))
    return;
  g_commandEnd = Clock::now();
  g_commandCpuEnd = enabled() ? sys::processCpuNs() : 0;
  g_commandFaultsOk = g_commandFaultsOk && sys::hardFaults(g_commandFaultsEnd) &&
                      g_commandFaultsEnd >= g_commandFaultsStart;
  g_busy.store(false);
  std::lock_guard<std::mutex> lk(g_mutex);
  g_summaryPending = true;
  if (enabled())
    g_cv.notify_all();
}

std::string takeCommandSummary() {
  if (!enabled())
    return "";
  std::lock_guard<std::mutex> lk(g_mutex);
  if (!g_summaryPending)
    return ""; // one summary per command, and only after it has finished
  g_summaryPending = false;
  const double wallMs = ms(g_commandEnd - g_commandStart);
  if (g_regions == 0 && wallMs < g_intervalMs.load())
    return ""; // short and serial: nothing worth a line
  const double cpuMs =
      g_commandCpuEnd > g_commandCpuStart ? static_cast<double>(g_commandCpuEnd - g_commandCpuStart) / 1e6 : 0.0;
  std::string j = "{\"v\":1,\"type\":\"parmon_summary\"," + headerFields();
  j += ",\"wall_ms\":" + num(wallMs, 1) + ",\"cpu_ms\":" + num(cpuMs, 1) +
       ",\"cpu_cores_avg\":" + num(wallMs > 0 ? cpuMs / wallMs : 0.0, 2) +
       ",\"regions\":" + std::to_string(g_regions) + ",\"parallel_ms\":" + num(g_parallelMs, 1) +
       ",\"max_threads\":" + std::to_string(g_maxThreads) +
       ",\"stopped\":" + (g_anyStopped ? "true" : "false") + ",\"hard_faults\":" +
       (g_commandFaultsOk ? std::to_string(g_commandFaultsEnd - g_commandFaultsStart) : std::string("null")) +
       ",\"kernels\":[";
  for (size_t i = 0; i < g_kernels.size(); i++) {
    const KernelStats &k = g_kernels[i];
    j += (i ? "," : "") + std::string("{\"label\":") + jsonText(k.label) + ",\"kind\":" + jsonText(kindKey(k.kind)) +
         ",\"count\":" + std::to_string(k.count) + ",\"items\":" + std::to_string(k.items) +
         ",\"ms\":" + num(k.ms, 2) + ",\"max_threads\":" + std::to_string(k.maxThreads) +
         ",\"hard_faults\":" + (k.faultsOk ? std::to_string(k.faults) : std::string("null")) + "}";
  }
  j += "]}";
  g_kernels.clear();
  g_regions = 0;
  return j;
}

std::string snapshotNow() {
  Sample a, b;
  takeSample(a);
  std::this_thread::sleep_for(std::chrono::milliseconds(100)); // a load needs an interval
  takeSample(b);
  return buildSnapshot(a, b, g_busy.load());
}

/* ---- region hooks ---- */

void regionBegin(Kind kind, const char *label, size_t items, size_t blocks, int threads) {
  uint64_t faults = 0;
  const bool faultsOk = sys::hardFaults(faults); // outside the lock: the sampler waits on it
  std::lock_guard<std::mutex> lk(g_mutex);
  g_region.faults = faults;
  g_region.faultsOk = faultsOk;
  g_region.active = true;
  // A kernel without a name of its own takes the name of the builtin that
  // called it (sin, sum, ...), set by callBuiltin() through CallLabel.
  g_region.label = (label && *label) ? label : (currentCallLabel() ? currentCallLabel() : "kernel");
  g_region.kind = kind;
  g_region.items = items;
  g_region.blocks = blocks;
  g_region.threads = threads;
  g_region.start = Clock::now();
}

void regionEnd(bool stopped) {
  uint64_t faults = 0;
  const bool faultsOk = sys::hardFaults(faults);
  std::lock_guard<std::mutex> lk(g_mutex);
  const double took = ms(Clock::now() - g_region.start);
  g_region.active = false;
  g_regions++;
  g_parallelMs += took;
  g_maxThreads = std::max(g_maxThreads, g_region.threads);
  g_anyStopped = g_anyStopped || stopped;
  KernelStats *k = nullptr;
  for (KernelStats &s : g_kernels)
    if (s.label == g_region.label)
      k = &s;
  if (!k) {
    if (g_kernels.size() >= 32)
      return; // a summary line stays short
    g_kernels.push_back({g_region.label, g_region.kind});
    k = &g_kernels.back();
  }
  k->count++;
  k->items += g_region.items;
  k->ms += took;
  k->maxThreads = std::max(k->maxThreads, g_region.threads);
  if (faultsOk && g_region.faultsOk && faults >= g_region.faults)
    k->faults += faults - g_region.faults;
  else
    k->faultsOk = false;
}

void blockDone(int slot, uint64_t ns, int processor) {
  Slot &s = g_slots[std::min(slot, kSlots - 1)];
  s.blocks.fetch_add(1, std::memory_order_relaxed);
  s.busyNs.fetch_add(ns, std::memory_order_relaxed);
  s.processor.store(processor, std::memory_order_relaxed);
  if (processor >= 0 && processor < kCoreSlots) {
    g_coreNs[processor].fetch_add(ns, std::memory_order_relaxed);
    if (!g_coreKnown.load(std::memory_order_relaxed))
      g_coreKnown.store(true, std::memory_order_relaxed);
  }
}

void setMemorySource(bool (*reader)(MemoryReading &out)) { g_memorySource.store(reader); }

} // namespace nc::par::monitor
