#pragma once

// The operating-system layer of nc::par: everything that differs between
// Windows, Linux, macOS, the BSDs and any other OS lives in sys_cpu.cpp and
// nowhere else. Every function has a portable fallback, so nc builds and
// runs on an OS this file has never heard of; only the CPU monitor then
// shows less (no per-core load).
//
// Nothing here is called per element. The monitor calls the sampling
// functions a few times a second, and only while a command runs in the IDE.

#include <cstdint>
#include <vector>

namespace nc::par::sys {

// Logical processors this process may run on (>= 1). Windows: all processor
// groups. POSIX: the scheduler affinity mask where the OS has one (Linux),
// otherwise the online processor count.
int logicalProcessors();

// Logical processor the calling thread is running on right now, or -1
// where the OS cannot say (macOS). A few nanoseconds; only the monitor uses
// it, once per block.
int currentProcessor();

// Cumulative busy and total time of one logical processor, in the OS's own
// tick unit. Load over an interval = d(busy) / d(total).
struct CoreTimes {
  uint64_t busy = 0;
  uint64_t total = 0;
};

// One entry per logical processor. False (and `out` empty) where the OS
// gives no per-core numbers; the monitor then reports the per-core load as
// unavailable instead of guessing.
bool coreTimes(std::vector<CoreTimes> &out);

// CPU time used by this whole process (all its threads, user + system), in
// nanoseconds. Includes OpenMP and Eigen threads. 0 when unavailable.
uint64_t processCpuNs();

// Sleeps about `us` microseconds. Windows' ordinary sleeps wake only every
// ~15.6 ms; this uses a high-resolution waitable timer there (Windows 10
// 1803+), falling back to Sleep(). Elsewhere, std::this_thread::sleep_for.
// Used by the analysis profiler (2 ms period).
void preciseSleepUs(long us);

// Short OS name for the monitor: "windows", "linux", "macos", "freebsd",
// "openbsd", "netbsd", "unix" or "unknown".
const char *osName();

} // namespace nc::par::sys
