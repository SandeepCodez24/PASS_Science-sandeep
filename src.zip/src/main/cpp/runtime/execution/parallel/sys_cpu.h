#pragma once

// The operating-system layer of nc::par: everything that differs between
// Windows, Linux, macOS, the BSDs and any other OS lives in sys_cpu.cpp and
// nowhere else. Every function has a portable fallback, so nc builds and
// runs on an OS this file has never heard of; only the CPU monitor then
// shows less (no per-core load).
//
// Nothing here is called per element. The monitor calls the sampling
// functions a few times a second, and only while a command runs in the IDE.

#include <cstdint>
#include <string>
#include <vector>

namespace nc::par::sys {

// Logical processors this process may run on (>= 1). Windows: all processor
// groups. POSIX: the scheduler affinity mask where the OS has one (Linux),
// otherwise the online processor count.
int logicalProcessors();

// Logical processor the calling thread is running on right now, or -1
// where the OS cannot say (macOS). A few nanoseconds; only the monitor uses
// it, once per block.
int currentProcessor();

// Cumulative busy and total time of one logical processor, in the OS's own
// tick unit. Load over an interval = d(busy) / d(total).
struct CoreTimes {
  uint64_t busy = 0;
  uint64_t total = 0;
};

// One entry per logical processor. False (and `out` empty) where the OS
// gives no per-core numbers; the monitor then reports the per-core load as
// unavailable instead of guessing.
bool coreTimes(std::vector<CoreTimes> &out);

// CPU time used by this whole process (all its threads, user + system), in
// nanoseconds. Includes OpenMP and Eigen threads. 0 when unavailable.
uint64_t processCpuNs();

// Sleeps about `us` microseconds. Windows' ordinary sleeps wake only every
// ~15.6 ms; this uses a high-resolution waitable timer there (Windows 10
// 1803+), falling back to Sleep(). Elsewhere, std::this_thread::sleep_for.
// Used by the analysis profiler (2 ms period).
void preciseSleepUs(long us);

// Short OS name for the monitor: "windows", "linux", "macos", "freebsd",
// "openbsd", "netbsd", "unix" or "unknown".
const char *osName();

/* ------------------------------------------- memory and disk (2026-11-23) */

// The memory governor's view of the machine (runtime/memory/governor.h,
// docs/Large_Data_Design.md section 2). Bytes; 0 = the OS gave no number.
//   total      physical RAM
//   available  RAM that can be handed out now without paging (Windows:
//              free + standby list; Linux: MemAvailable; macOS: free +
//              inactive + purgeable + speculative pages)
//   limit      a cap on THIS process from outside, smaller than RAM: a
//              Windows job object, a Linux cgroup (containers, systemd)
//   used       what this process holds privately now (Windows: private
//              commit; Linux: RssAnon + VmSwap; macOS: phys_footprint)
// A few microseconds; called before each allocation of 64 MB or more and
// by memory_info(), never per element.
struct MemoryInfo {
  uint64_t total = 0;
  uint64_t available = 0;
  uint64_t limit = 0;
  uint64_t used = 0;
  uint64_t peak = 0; // the most `used` has been since start (Phase 4 measurements)
};
// False when the OS gave not even the total (then nothing is checked).
bool memoryInfo(MemoryInfo &out);

// Hard page faults of the WHOLE MACHINE since boot: page reads that had to
// wait for the disk (the page file, swap, or a memory-mapped file such as
// the disk tier). The monitor turns two readings into a rate, and the
// difference over a kernel into that kernel's disk waits (Phase 5,
// docs/Large_Data_Design.md section 20). Machine-wide on every OS so the
// number means the same everywhere:
//   Windows  SYSTEM_PERFORMANCE_INFORMATION.PageReadIoCount (paging read
//            I/Os; 32-bit in the OS, widened here)
//   Linux    /proc/vmstat pgmajfault
//   macOS    vm_statistics64.pageins
//   FreeBSD  vm.stats.vm.v_io_faults
// False where the OS gives no such counter. A few microseconds (Linux:
// reads a small /proc file).
bool hardFaults(uint64_t &count);

// Free bytes on the volume that holds `path` (UTF-8) for this user; 0 when
// unknown.
uint64_t diskFreeBytes(const char *path);

// File-backed memory (2026-11-23, docs/Large_Data_Design.md Phase 3): `bytes`
// of memory backed by a new temporary file in the folder `dir` (UTF-8)
// instead of RAM and the page file. The OS moves its pages to and from that
// file. The file is deleted when the mapping is released - and also when
// the process dies (Windows: delete-on-close; POSIX: unlinked at once), so
// nothing is left behind. Sparse where the file system allows: nothing is
// written until used. Returns the address, or nullptr (and the OS error in
// `why`); `handle` is what unmapFile() needs.
void *mapNewFile(const char *dir, uint64_t bytes, uint64_t &handle, std::string &why);
void unmapFile(void *address, uint64_t bytes, uint64_t handle);

} // namespace nc::par::sys
