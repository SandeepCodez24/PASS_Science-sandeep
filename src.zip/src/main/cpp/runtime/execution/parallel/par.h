#pragma once

// nc::par - the one place NC runs work on several CPU cores.
//
// Design: docs/Multicore_Multithread_Architecture.md. Kernel authors never
// write `#pragma omp` or create a std::thread; they call forBlocks() or
// reduceBlocks() below over raw buffers, and this library decides whether to
// use threads, how many, and on which backend:
//
//   openmp   Windows, Linux, macOS with libomp. Shares its threads with Eigen.
//   stdpool  Any OS with a C++20 standard library: a small pool of
//            std::thread workers. Used where OpenMP is not available (Apple's
//            compiler, a minimal toolchain) or when chosen with
//            -DNC_PAR_BACKEND=stdpool.
//   serial   No threads at all (-DNC_PAR_BACKEND=serial). NC_THREADS=1 gives
//            the same behaviour at run time on every backend.
//
// The guarantees every kernel relies on:
//
//  1. Results never depend on the thread count. Blocks are cut from the
//     item count and the Cost alone, and reduceBlocks() combines the block
//     results in index order on the calling thread, so 1 thread and 28
//     threads produce the same bits.
//  2. Small work runs serially, with no thread overhead at all (below about
//     200 microseconds of work, see plan()).
//  3. Only one level of parallelism: a forBlocks() inside a block runs
//     serially on the thread that called it.
//  4. Errors: an exception in a block is caught and rethrown on the calling
//     thread after the region; BlockError keeps the error with the lowest
//     item index, so the message matches what a serial loop would report.
//  5. Stop: the IDE's Stop button ends a region between blocks (50 us of
//     work each). The kernel learns it from the Outcome and gives up its
//     result; the statement does not complete.
//
// Inside a block: no Value copies, no cout/cerr, no callBuiltin, no Parser,
// no random numbers, no statics that change. Raw pointers only.

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace nc::par {

/* ------------------------------------------------------------- the cost */

// What limits a kernel. Decides the thread cap (memory-bound work stops
// gaining long before compute-bound work does).
enum class Kind : uint8_t {
  Stream,  // reads and writes large arrays: A + B, copy, transpose  (cap 8)
  Reduce,  // reads large arrays, one result: sum, dot, norm         (cap 16)
  Compute, // CPU-heavy per element: sin, lgamma, format_time        (no cap)
  Task     // uneven pieces: file decode, per-column FFT              (no cap)
};

const char *kindName(Kind k);

// Kind + measured nanoseconds per item on one core. The constant only steers
// speed (when to go parallel, how big a block is); it never changes a result.
struct Cost {
  Kind kind;
  double nsPerItem;
};

constexpr Cost stream(double ns) { return {Kind::Stream, ns}; }
constexpr Cost reduce(double ns) { return {Kind::Reduce, ns}; }
constexpr Cost compute(double ns) { return {Kind::Compute, ns}; }
constexpr Cost task(double ns) { return {Kind::Task, ns}; }

/* -------------------------------------------------------------- the plan */

struct Plan {
  size_t n = 0;         // items
  size_t blockSize = 0; // items per block (the last block may be shorter)
  size_t blocks = 0;    // number of blocks; 0 when n == 0, 1 for small work
  int threads = 1;      // threads that take part; 1 = serial
  // false: Stop does not end the region early. For callers that cannot
  // give up a half-computed result (the SciPy seam); the statement then
  // stops right after the kernel instead.
  bool stoppable = true;
};

// blocks and blockSize depend on n and cost ONLY (guarantee 1). threads also
// depends on threadCount(), the kind's cap and the nesting level.
//
//   work    = n * nsPerItem
//   1 block if work < 200 us
//   block   = 50 us of work, rounded to the nearest power of two, >= 1024 items
//   threads = min(threadCount(), cap(kind), work / 25 us, blocks)
Plan plan(size_t n, Cost cost);

// tasks(): one block per job; threads as above, serial below 200 us in all.
Plan taskPlan(size_t jobs, double nsPerJob);

// A caller that already has its own block size (the SciPy seam, whose
// results were fixed with it): blocks of exactly `blockSize` items, threads
// chosen as plan() would. A cost of 0 or less means "not measured yet" and
// always runs serially.
Plan planWithBlockSize(size_t n, Cost cost, size_t blockSize);

/* --------------------------------------------------------------- settings */

// Threads a region may use, >= 1. Set by NC_THREADS, else OMP_NUM_THREADS,
// else every logical processor; changed at run time by set_threads(n).
int threadCount();
// n >= 1 sets the count (clamped to 1024); n == 0 goes back to the default.
// Returns the previous count. Also sets OpenMP's count, so Eigen follows.
int setThreadCount(int n);
int defaultThreadCount();
int logicalProcessors();
// "openmp", "stdpool" or "serial" - fixed when nc is built.
const char *backendName();
// "release" or "debug". A Debug nc.exe has no optimisation: matrix products
// and other library code run 10-50x slower. The IDE shows it as a warning.
const char *buildType();

// True on every thread while it takes part in a region, including the
// interpreter thread itself. A forBlocks() call then runs serially.
bool inRegion();

// The interpreter thread is the one that ran initialize(). Debug builds
// abort when interpreter-only code runs anywhere else; Release builds do
// nothing (the check costs one thread-local read).
bool isInterpreterThread();
void assertInterpreterThreadImpl(const char *where);
#ifdef NDEBUG
inline void assertInterpreterThread(const char *) {}
#else
inline void assertInterpreterThread(const char *where) { assertInterpreterThreadImpl(where); }
#endif

// The name of the builtin running on this thread, for the monitor: a region
// started without a label of its own is shown under it ("sin", "sum").
// callBuiltin() sets it with a CallLabel for the length of each call.
const char *currentCallLabel();
class CallLabel {
public:
  explicit CallLabel(const char *name);
  ~CallLabel();
  CallLabel(const CallLabel &) = delete;
  CallLabel &operator=(const CallLabel &) = delete;

private:
  const char *previous_;
};

// Order in which blocks are handed out (NC_PAR_CHECK=reverse|shuffle[:seed]).
// Results must be identical in every order; the other orders exist only to
// expose a kernel whose blocks wrongly depend on each other.
enum class BlockOrder { Normal, Reverse, Shuffle };
void setBlockOrder(BlockOrder order, uint64_t seed = 0);

// Once, at the start of main(): reads NC_THREADS / NC_PAR_CHECK, marks the
// calling thread as the interpreter thread, and tunes the OpenMP runtime
// (idle workers sleep after ~20 ms instead of spinning for 200 ms).
void initialize();

/* ---------------------------------------------------------------- errors */

// Collects the error with the LOWEST item index from any block. Blocks past
// a reported error are skipped (their results would be thrown away), blocks
// before it still run, so the error kept is the one a serial loop would hit
// first. The kernel prints it after the region, on the interpreter thread.
class BlockError {
public:
  void report(size_t item, std::string message);
  bool any() const { return first_.load(std::memory_order_acquire) != kNone; }
  size_t item() const { return first_.load(std::memory_order_acquire); }
  const std::string &message() const { return message_; }

  static constexpr size_t kNone = SIZE_MAX;

private:
  std::mutex mutex_;
  std::atomic<size_t> first_{kNone};
  std::string message_;
};

/* ---------------------------------------------------------------- regions */

enum class Outcome {
  Done,    // every block ran
  Stopped, // Stop was pressed; the result is incomplete - discard it
  Failed   // a BlockError was reported; the kernel prints it
};

// The low-level runner forBlocks()/reduceBlocks() are built on. Calls
// fn(ctx, block) for every block in [0, plan.blocks). Rethrows the first
// exception a block threw.
using BlockFn = void (*)(void *ctx, size_t block);
Outcome runRegion(const Plan &plan, Kind kind, const char *label, BlockFn fn, void *ctx,
                  BlockError *error);

namespace detail {
template <class Body> struct ForCtx {
  Body *body;
  const Plan *plan;
  static void call(void *vc, size_t block) {
    auto &c = *static_cast<ForCtx *>(vc);
    const size_t begin = block * c.plan->blockSize;
    const size_t end = std::min(c.plan->n, begin + c.plan->blockSize);
    (*c.body)(begin, end);
  }
};
} // namespace detail

// Runs body(begin, end) over [0, n) in blocks and returns when all are done.
// `label` names the kernel in the IDE's monitor ("sin", "A + B", ...).
// Small work, NC_THREADS=1 and calls from inside a block run serially,
// through exactly the same block boundaries.
template <class Body>
Outcome forBlocks(size_t n, Cost cost, const char *label, Body &&body,
                  BlockError *error = nullptr) {
  const Plan p = plan(n, cost);
  if (p.blocks == 0)
    return Outcome::Done;
  if (p.blocks == 1) {
    body(size_t(0), n);
    return (error && error->any()) ? Outcome::Failed : Outcome::Done;
  }
  using B = std::remove_reference_t<Body>;
  detail::ForCtx<B> ctx{&body, &p};
  return runRegion(p, cost.kind, label, &detail::ForCtx<B>::call, &ctx, error);
}

// forBlocks() with a ready-made plan (planWithBlockSize()).
template <class Body>
Outcome forPlan(const Plan &p, Kind kind, const char *label, Body &&body,
                BlockError *error = nullptr) {
  if (p.blocks == 0)
    return Outcome::Done;
  using B = std::remove_reference_t<Body>;
  detail::ForCtx<B> ctx{&body, &p};
  return runRegion(p, kind, label, &detail::ForCtx<B>::call, &ctx, error);
}

// A reduction: part = fn(begin, end) per block, then
// out = combine(...combine(combine(init, part0), part1)..., partLast)
// IN BLOCK ORDER on the calling thread. With one block (small n) this is
// combine(init, fn(0, n)) - for a sum, exactly the plain left-to-right loop.
template <class T, class Fn, class Combine>
Outcome reduceBlocks(size_t n, Cost cost, const char *label, T init, Fn &&fn,
                     Combine &&combine, T &out, BlockError *error = nullptr) {
  const Plan p = plan(n, cost);
  if (p.blocks == 0) {
    out = init;
    return Outcome::Done;
  }
  if (p.blocks == 1) {
    out = combine(init, fn(size_t(0), n));
    return (error && error->any()) ? Outcome::Failed : Outcome::Done;
  }
  std::vector<T> parts(p.blocks, init);
  auto body = [&](size_t begin, size_t end) { parts[begin / p.blockSize] = fn(begin, end); };
  using B = decltype(body);
  detail::ForCtx<B> ctx{&body, &p};
  const Outcome r = runRegion(p, cost.kind, label, &detail::ForCtx<B>::call, &ctx, error);
  if (r != Outcome::Done)
    return r;
  T acc = init;
  for (const T &part : parts)
    acc = combine(acc, part);
  out = acc;
  return Outcome::Done;
}

// Coarse independent jobs (decode one file chunk each, one FFT line each).
// Each job is one block; jobs run in any order and must not depend on each
// other. Returns as forBlocks() does.
template <class Job>
Outcome tasks(size_t count, double nsPerJob, const char *label, Job &&job,
              BlockError *error = nullptr) {
  // One job per block, so a slow job never holds up a whole block of others.
  const Plan p = taskPlan(count, nsPerJob);
  if (p.blocks == 0)
    return Outcome::Done;
  if (p.threads <= 1) {
    for (size_t i = 0; i < count; i++)
      job(i);
    return (error && error->any()) ? Outcome::Failed : Outcome::Done;
  }
  auto body = [&](size_t begin, size_t end) {
    for (size_t i = begin; i < end; i++)
      job(i);
  };
  using B = decltype(body);
  detail::ForCtx<B> ctx{&body, &p};
  return runRegion(p, Kind::Task, label, &detail::ForCtx<B>::call, &ctx, error);
}

} // namespace nc::par
