#pragma once

// CPU core and thread monitor for the IDE (docs/Parallel_Monitor_Java_Handover.md).
//
// The IDE shows how busy each core is and how many threads NC is using
// while a command runs. The three rules that keep it free of cost:
//
//  1. Off outside the IDE. configure() is only given a session folder in IDE
//     mode (NC_SESSION_DIR); in a plain terminal nothing here ever runs.
//  2. Off while the IDE's panel is closed. The IDE sends "@cmd parmon on"
//     when it opens the panel and "@cmd parmon off" when it closes it. Off,
//     a parallel region pays one relaxed atomic load, nothing per block.
//  3. Silent while idle. The sampler thread sleeps on a condition variable
//     between commands. It wakes when a command starts, and writes nothing
//     unless the command is still running one interval later.
//
// Two channels, so the sampler thread never writes to stdout (where it could
// land in the middle of a line of script output):
//
//  - <session>/parmon.json : a live snapshot rewritten every interval while
//    a command runs (atomically: written to parmon.json.tmp, then renamed).
//    The IDE reads it on its own timer.
//  - "@PARMON {json}" protocol line : a summary of the command that just
//    finished, sent by the interpreter thread just before the prompt, so it
//    is ordered with all other output.
//
// The formats are in the handover document. Thread safety: every function
// may be called from any thread unless stated otherwise.

#include <cstddef>
#include <cstdint>
#include <string>

#include "par.h"

namespace nc::par::monitor {

// IDE mode only: where parmon.json goes. An empty folder disables the
// monitor for good (plain terminal). Interpreter thread, once, at startup.
void configure(const std::string &sessionDirectory);

// "@cmd parmon on|off". Starting it the first time creates the sampler
// thread; turning it off stops sampling and leaves the thread asleep.
void setEnabled(bool on);
bool enabled();

// "@cmd parmon interval <ms>": 100 .. 5000 ms, default 250.
void setIntervalMs(int ms);

// The REPL brackets every command with these (interpreter thread).
void commandStarted();
void commandFinished();

// After commandFinished(): the JSON of the "@PARMON" summary line for the
// command that just ended, or "" when there is nothing to report (monitor
// off, or the command was short and used no threads). Interpreter thread.
std::string takeCommandSummary();

// A one-off snapshot as JSON, whatever the state ("@cmd parmon snapshot"):
// lets the IDE fill the panel the moment it opens.
std::string snapshotNow();

/* ---- called by runRegion() only ---- */

// Number of per-thread counter slots; a region's thread k uses slot
// min(k, kSlots - 1).
constexpr int kSlots = 256;

void regionBegin(Kind kind, const char *label, size_t items, size_t blocks, int threads);
void regionEnd(bool stopped);
// One finished block: thread slot, its duration, the processor it ran on.
void blockDone(int slot, uint64_t ns, int processor);

} // namespace nc::par::monitor
