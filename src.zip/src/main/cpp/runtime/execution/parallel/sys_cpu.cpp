// OS layer of nc::par - see sys_cpu.h. One #if branch per OS family, and a
// portable fallback at the end of every function.

#include "sys_cpu.h"

#include <chrono>
#include <thread>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#elif defined(__APPLE__)
#include <mach/mach.h>
#include <mach/processor_info.h>
#include <sys/resource.h>
#include <sys/sysctl.h>
#include <unistd.h>
#elif defined(__linux__)
#include <fstream>
#include <sched.h>
#include <sstream>
#include <string>
#include <sys/resource.h>
#include <unistd.h>
#elif defined(__FreeBSD__) || defined(__DragonFly__)
#include <pthread_np.h>
#include <sys/resource.h>
#include <sys/sysctl.h>
#include <sys/types.h>
#include <unistd.h>
#elif defined(__unix__)
#include <sys/resource.h>
#include <unistd.h>
#endif

#if !defined(_WIN32)
#include <ctime>
#endif

namespace nc::par::sys {

/* ---------------------------------------------------------------- names */

const char *osName() {
#if defined(_WIN32)
  return "windows";
#elif defined(__APPLE__)
  return "macos";
#elif defined(__linux__)
  return "linux";
#elif defined(__FreeBSD__) || defined(__DragonFly__)
  return "freebsd";
#elif defined(__OpenBSD__)
  return "openbsd";
#elif defined(__NetBSD__)
  return "netbsd";
#elif defined(__unix__)
  return "unix";
#else
  return "unknown";
#endif
}

/* ------------------------------------------------------ processor count */

int logicalProcessors() {
  int n = 0;
#if defined(_WIN32)
  // All processor groups (a PC with more than 64 logical processors has
  // several). ALL_PROCESSOR_GROUPS = 0xffff.
  const DWORD count = GetActiveProcessorCount(0xffff);
  n = static_cast<int>(count);
#elif defined(__linux__)
  cpu_set_t set;
  CPU_ZERO(&set);
  if (sched_getaffinity(0, sizeof(set), &set) == 0)
    n = CPU_COUNT(&set); // respects taskset / container CPU limits
  if (n <= 0)
    n = static_cast<int>(sysconf(_SC_NPROCESSORS_ONLN));
#elif defined(__unix__) || defined(__APPLE__)
  n = static_cast<int>(sysconf(_SC_NPROCESSORS_ONLN));
#endif
  if (n <= 0)
    n = static_cast<int>(std::thread::hardware_concurrency());
  return n > 0 ? n : 1;
}

/* ----------------------------------------------------- current processor */

int currentProcessor() {
#if defined(_WIN32)
  PROCESSOR_NUMBER pn;
  GetCurrentProcessorNumberEx(&pn);
  return static_cast<int>(pn.Group) * 64 + static_cast<int>(pn.Number);
#elif defined(__linux__)
  return sched_getcpu();
#elif defined(__FreeBSD__) || defined(__DragonFly__)
#if defined(__FreeBSD_version) && __FreeBSD_version >= 1300000
  return sched_getcpu();
#else
  return -1;
#endif
#else
  return -1; // macOS and others: no public API
#endif
}

/* ------------------------------------------------------------ core times */

#if defined(_WIN32)
namespace {
// SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION from the Windows DDK. Read
// through NtQuerySystemInformation, looked up at run time so nc.exe keeps
// importing nothing beyond KERNEL32 for this (no ntdll.lib, no pdh.lib).
struct ProcessorPerformance {
  LARGE_INTEGER idle;   // 100 ns units
  LARGE_INTEGER kernel; // includes idle
  LARGE_INTEGER user;
  LARGE_INTEGER dpc;
  LARGE_INTEGER interrupt;
  ULONG interruptCount;
};
using NtQuerySystemInformationFn = LONG(WINAPI *)(int, void *, ULONG, ULONG *);

NtQuerySystemInformationFn ntQuery() {
  static NtQuerySystemInformationFn fn = []() -> NtQuerySystemInformationFn {
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll)
      return nullptr;
    return reinterpret_cast<NtQuerySystemInformationFn>(
        reinterpret_cast<void *>(GetProcAddress(ntdll, "NtQuerySystemInformation")));
  }();
  return fn;
}
} // namespace
#endif

bool coreTimes(std::vector<CoreTimes> &out) {
  out.clear();
#if defined(_WIN32)
  // SystemProcessorPerformanceInformation (class 8) covers the processor
  // group of the calling thread: every processor on a PC with up to 64.
  NtQuerySystemInformationFn query = ntQuery();
  if (!query)
    return false;
  const int n = static_cast<int>(GetActiveProcessorCount(ALL_PROCESSOR_GROUPS));
  std::vector<ProcessorPerformance> info(n > 0 ? n : 1);
  ULONG got = 0;
  if (query(8, info.data(), static_cast<ULONG>(info.size() * sizeof(ProcessorPerformance)),
            &got) != 0)
    return false;
  const size_t count = got / sizeof(ProcessorPerformance);
  out.resize(count);
  for (size_t i = 0; i < count; i++) {
    const uint64_t idle = static_cast<uint64_t>(info[i].idle.QuadPart);
    const uint64_t total = static_cast<uint64_t>(info[i].kernel.QuadPart) +
                           static_cast<uint64_t>(info[i].user.QuadPart);
    out[i].total = total;
    out[i].busy = total > idle ? total - idle : 0;
  }
  return !out.empty();
#elif defined(__linux__)
  // /proc/stat: "cpuN user nice system idle iowait irq softirq steal ..."
  std::ifstream stat("/proc/stat");
  if (!stat)
    return false;
  std::string line;
  while (std::getline(stat, line)) {
    if (line.compare(0, 3, "cpu") != 0)
      break; // the cpu lines come first
    if (line.size() < 4 || line[3] < '0' || line[3] > '9')
      continue; // the "cpu " total line
    std::istringstream in(line);
    std::string label;
    uint64_t v[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    in >> label;
    for (uint64_t &x : v)
      if (!(in >> x))
        break;
    const uint64_t idle = v[3] + v[4]; // idle + iowait
    uint64_t total = 0;
    for (uint64_t x : v)
      total += x;
    out.push_back({total - idle, total});
  }
  return !out.empty();
#elif defined(__APPLE__)
  natural_t count = 0;
  processor_info_array_t info = nullptr;
  mach_msg_type_number_t infoCount = 0;
  if (host_processor_info(mach_host_self(), PROCESSOR_CPU_LOAD_INFO, &count, &info,
                          &infoCount) != KERN_SUCCESS)
    return false;
  out.resize(count);
  for (natural_t i = 0; i < count; i++) {
    const integer_t *t = info + CPU_STATE_MAX * i;
    const uint64_t user = static_cast<uint32_t>(t[CPU_STATE_USER]);
    const uint64_t sys = static_cast<uint32_t>(t[CPU_STATE_SYSTEM]);
    const uint64_t nice = static_cast<uint32_t>(t[CPU_STATE_NICE]);
    const uint64_t idle = static_cast<uint32_t>(t[CPU_STATE_IDLE]);
    out[i].busy = user + sys + nice;
    out[i].total = user + sys + nice + idle;
  }
  vm_deallocate(mach_task_self(), reinterpret_cast<vm_address_t>(info),
                infoCount * sizeof(integer_t));
  return !out.empty();
#elif defined(__FreeBSD__) || defined(__DragonFly__)
  // kern.cp_times: CPUSTATES (5) longs per CPU - user nice sys intr idle.
  size_t len = 0;
  if (sysctlbyname("kern.cp_times", nullptr, &len, nullptr, 0) != 0 || len == 0)
    return false;
  std::vector<long> v(len / sizeof(long));
  if (sysctlbyname("kern.cp_times", v.data(), &len, nullptr, 0) != 0)
    return false;
  for (size_t i = 0; i + 5 <= v.size(); i += 5) {
    const uint64_t busy = static_cast<uint64_t>(v[i] + v[i + 1] + v[i + 2] + v[i + 3]);
    out.push_back({busy, busy + static_cast<uint64_t>(v[i + 4])});
  }
  return !out.empty();
#else
  return false; // no per-core numbers on this OS
#endif
}

/* ------------------------------------------------------------- sleeping */

void preciseSleepUs(long us) {
  if (us <= 0)
    return;
#if defined(_WIN32)
  // CREATE_WAITABLE_TIMER_HIGH_RESOLUTION = 0x2 (not in every SDK header).
  thread_local HANDLE timer = CreateWaitableTimerExW(nullptr, nullptr, 0x00000002, TIMER_ALL_ACCESS);
  if (timer) {
    LARGE_INTEGER due;
    due.QuadPart = -static_cast<LONGLONG>(us) * 10; // relative, 100 ns units
    if (SetWaitableTimer(timer, &due, 0, nullptr, nullptr, FALSE)) {
      WaitForSingleObject(timer, INFINITE);
      return;
    }
  }
  Sleep(static_cast<DWORD>(us >= 1000 ? us / 1000 : 1));
#else
  std::this_thread::sleep_for(std::chrono::microseconds(us));
#endif
}

/* ------------------------------------------------------ process CPU time */

uint64_t processCpuNs() {
#if defined(_WIN32)
  FILETIME created, exited, kernel, user;
  if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user))
    return 0;
  auto ticks = [](const FILETIME &f) {
    return (static_cast<uint64_t>(f.dwHighDateTime) << 32) | f.dwLowDateTime;
  };
  return (ticks(kernel) + ticks(user)) * 100; // 100 ns units
#elif defined(CLOCK_PROCESS_CPUTIME_ID)
  timespec ts;
  if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts) != 0)
    return 0;
  return static_cast<uint64_t>(ts.tv_sec) * 1000000000ull + static_cast<uint64_t>(ts.tv_nsec);
#elif defined(__unix__) || defined(__APPLE__)
  rusage ru;
  if (getrusage(RUSAGE_SELF, &ru) != 0)
    return 0;
  auto ns = [](const timeval &t) {
    return static_cast<uint64_t>(t.tv_sec) * 1000000000ull + static_cast<uint64_t>(t.tv_usec) * 1000ull;
  };
  return ns(ru.ru_utime) + ns(ru.ru_stime);
#else
  return static_cast<uint64_t>(std::clock()) * (1000000000ull / CLOCKS_PER_SEC);
#endif
}

} // namespace nc::par::sys
