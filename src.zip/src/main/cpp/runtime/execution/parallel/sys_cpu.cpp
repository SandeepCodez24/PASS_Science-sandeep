// OS layer of nc::par - see sys_cpu.h. One #if branch per OS family, and a
// portable fallback at the end of every function.

#include "sys_cpu.h"

#include <chrono>
#include <thread>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <psapi.h> // K32GetProcessMemoryInfo (exported by KERNEL32; no psapi.lib)
#elif defined(__APPLE__)
#include <mach/mach.h>
#include <mach/processor_info.h>
#include <sys/resource.h>
#include <sys/sysctl.h>
#include <unistd.h>
#elif defined(__linux__)
#include <fstream>
#include <sched.h>
#include <sstream>
#include <string>
#include <sys/resource.h>
#include <unistd.h>
#elif defined(__FreeBSD__) || defined(__DragonFly__)
#include <pthread_np.h>
#include <sys/resource.h>
#include <sys/sysctl.h>
#include <sys/types.h>
#include <unistd.h>
#elif defined(__unix__)
#include <sys/resource.h>
#include <unistd.h>
#endif

#if !defined(_WIN32)
#include <ctime>
#include <sys/statvfs.h>
#endif
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__DragonFly__)
#include <sys/sysctl.h>
#endif
#include <atomic>
#include <cstdio>
#include <cstring>
#include <string>
#if defined(_WIN32)
#include <winioctl.h> // FSCTL_SET_SPARSE
#elif defined(__unix__) || defined(__APPLE__)
#include <fcntl.h>
#include <sys/mman.h>
#endif

namespace nc::par::sys {

/* ---------------------------------------------------------------- names */

const char *osName() {
#if defined(_WIN32)
  return "windows";
#elif defined(__APPLE__)
  return "macos";
#elif defined(__linux__)
  return "linux";
#elif defined(__FreeBSD__) || defined(__DragonFly__)
  return "freebsd";
#elif defined(__OpenBSD__)
  return "openbsd";
#elif defined(__NetBSD__)
  return "netbsd";
#elif defined(__unix__)
  return "unix";
#else
  return "unknown";
#endif
}

/* ------------------------------------------------------ processor count */

int logicalProcessors() {
  int n = 0;
#if defined(_WIN32)
  // All processor groups (a PC with more than 64 logical processors has
  // several). ALL_PROCESSOR_GROUPS = 0xffff.
  const DWORD count = GetActiveProcessorCount(0xffff);
  n = static_cast<int>(count);
#elif defined(__linux__)
  cpu_set_t set;
  CPU_ZERO(&set);
  if (sched_getaffinity(0, sizeof(set), &set) == 0)
    n = CPU_COUNT(&set); // respects taskset / container CPU limits
  if (n <= 0)
    n = static_cast<int>(sysconf(_SC_NPROCESSORS_ONLN));
#elif defined(__unix__) || defined(__APPLE__)
  n = static_cast<int>(sysconf(_SC_NPROCESSORS_ONLN));
#endif
  if (n <= 0)
    n = static_cast<int>(std::thread::hardware_concurrency());
  return n > 0 ? n : 1;
}

/* ----------------------------------------------------- current processor */

int currentProcessor() {
#if defined(_WIN32)
  PROCESSOR_NUMBER pn;
  GetCurrentProcessorNumberEx(&pn);
  return static_cast<int>(pn.Group) * 64 + static_cast<int>(pn.Number);
#elif defined(__linux__)
  return sched_getcpu();
#elif defined(__FreeBSD__) || defined(__DragonFly__)
#if defined(__FreeBSD_version) && __FreeBSD_version >= 1300000
  return sched_getcpu();
#else
  return -1;
#endif
#else
  return -1; // macOS and others: no public API
#endif
}

/* ------------------------------------------------------------ core times */

#if defined(_WIN32)
namespace {
// SYSTEM_PROCESSOR_PERFORMANCE_INFORMATION from the Windows DDK. Read
// through NtQuerySystemInformation, looked up at run time so nc.exe keeps
// importing nothing beyond KERNEL32 for this (no ntdll.lib, no pdh.lib).
struct ProcessorPerformance {
  LARGE_INTEGER idle;   // 100 ns units
  LARGE_INTEGER kernel; // includes idle
  LARGE_INTEGER user;
  LARGE_INTEGER dpc;
  LARGE_INTEGER interrupt;
  ULONG interruptCount;
};
using NtQuerySystemInformationFn = LONG(WINAPI *)(int, void *, ULONG, ULONG *);

NtQuerySystemInformationFn ntQuery() {
  static NtQuerySystemInformationFn fn = []() -> NtQuerySystemInformationFn {
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll)
      return nullptr;
    return reinterpret_cast<NtQuerySystemInformationFn>(
        reinterpret_cast<void *>(GetProcAddress(ntdll, "NtQuerySystemInformation")));
  }();
  return fn;
}
} // namespace
#endif

bool coreTimes(std::vector<CoreTimes> &out) {
  out.clear();
#if defined(_WIN32)
  // SystemProcessorPerformanceInformation (class 8) covers the processor
  // group of the calling thread: every processor on a PC with up to 64.
  NtQuerySystemInformationFn query = ntQuery();
  if (!query)
    return false;
  const int n = static_cast<int>(GetActiveProcessorCount(ALL_PROCESSOR_GROUPS));
  std::vector<ProcessorPerformance> info(n > 0 ? n : 1);
  ULONG got = 0;
  if (query(8, info.data(), static_cast<ULONG>(info.size() * sizeof(ProcessorPerformance)),
            &got) != 0)
    return false;
  const size_t count = got / sizeof(ProcessorPerformance);
  out.resize(count);
  for (size_t i = 0; i < count; i++) {
    const uint64_t idle = static_cast<uint64_t>(info[i].idle.QuadPart);
    const uint64_t total = static_cast<uint64_t>(info[i].kernel.QuadPart) +
                           static_cast<uint64_t>(info[i].user.QuadPart);
    out[i].total = total;
    out[i].busy = total > idle ? total - idle : 0;
  }
  return !out.empty();
#elif defined(__linux__)
  // /proc/stat: "cpuN user nice system idle iowait irq softirq steal ..."
  std::ifstream stat("/proc/stat");
  if (!stat)
    return false;
  std::string line;
  while (std::getline(stat, line)) {
    if (line.compare(0, 3, "cpu") != 0)
      break; // the cpu lines come first
    if (line.size() < 4 || line[3] < '0' || line[3] > '9')
      continue; // the "cpu " total line
    std::istringstream in(line);
    std::string label;
    uint64_t v[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    in >> label;
    for (uint64_t &x : v)
      if (!(in >> x))
        break;
    const uint64_t idle = v[3] + v[4]; // idle + iowait
    uint64_t total = 0;
    for (uint64_t x : v)
      total += x;
    out.push_back({total - idle, total});
  }
  return !out.empty();
#elif defined(__APPLE__)
  natural_t count = 0;
  processor_info_array_t info = nullptr;
  mach_msg_type_number_t infoCount = 0;
  if (host_processor_info(mach_host_self(), PROCESSOR_CPU_LOAD_INFO, &count, &info,
                          &infoCount) != KERN_SUCCESS)
    return false;
  out.resize(count);
  for (natural_t i = 0; i < count; i++) {
    const integer_t *t = info + CPU_STATE_MAX * i;
    const uint64_t user = static_cast<uint32_t>(t[CPU_STATE_USER]);
    const uint64_t sys = static_cast<uint32_t>(t[CPU_STATE_SYSTEM]);
    const uint64_t nice = static_cast<uint32_t>(t[CPU_STATE_NICE]);
    const uint64_t idle = static_cast<uint32_t>(t[CPU_STATE_IDLE]);
    out[i].busy = user + sys + nice;
    out[i].total = user + sys + nice + idle;
  }
  vm_deallocate(mach_task_self(), reinterpret_cast<vm_address_t>(info),
                infoCount * sizeof(integer_t));
  return !out.empty();
#elif defined(__FreeBSD__) || defined(__DragonFly__)
  // kern.cp_times: CPUSTATES (5) longs per CPU - user nice sys intr idle.
  size_t len = 0;
  if (sysctlbyname("kern.cp_times", nullptr, &len, nullptr, 0) != 0 || len == 0)
    return false;
  std::vector<long> v(len / sizeof(long));
  if (sysctlbyname("kern.cp_times", v.data(), &len, nullptr, 0) != 0)
    return false;
  for (size_t i = 0; i + 5 <= v.size(); i += 5) {
    const uint64_t busy = static_cast<uint64_t>(v[i] + v[i + 1] + v[i + 2] + v[i + 3]);
    out.push_back({busy, busy + static_cast<uint64_t>(v[i + 4])});
  }
  return !out.empty();
#else
  return false; // no per-core numbers on this OS
#endif
}

/* ------------------------------------------------------------- sleeping */

void preciseSleepUs(long us) {
  if (us <= 0)
    return;
#if defined(_WIN32)
  // CREATE_WAITABLE_TIMER_HIGH_RESOLUTION = 0x2 (not in every SDK header).
  thread_local HANDLE timer = CreateWaitableTimerExW(nullptr, nullptr, 0x00000002, TIMER_ALL_ACCESS);
  if (timer) {
    LARGE_INTEGER due;
    due.QuadPart = -static_cast<LONGLONG>(us) * 10; // relative, 100 ns units
    if (SetWaitableTimer(timer, &due, 0, nullptr, nullptr, FALSE)) {
      WaitForSingleObject(timer, INFINITE);
      return;
    }
  }
  Sleep(static_cast<DWORD>(us >= 1000 ? us / 1000 : 1));
#else
  std::this_thread::sleep_for(std::chrono::microseconds(us));
#endif
}

/* ------------------------------------------------------ process CPU time */

uint64_t processCpuNs() {
#if defined(_WIN32)
  FILETIME created, exited, kernel, user;
  if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user))
    return 0;
  auto ticks = [](const FILETIME &f) {
    return (static_cast<uint64_t>(f.dwHighDateTime) << 32) | f.dwLowDateTime;
  };
  return (ticks(kernel) + ticks(user)) * 100; // 100 ns units
#elif defined(CLOCK_PROCESS_CPUTIME_ID)
  timespec ts;
  if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts) != 0)
    return 0;
  return static_cast<uint64_t>(ts.tv_sec) * 1000000000ull + static_cast<uint64_t>(ts.tv_nsec);
#elif defined(__unix__) || defined(__APPLE__)
  rusage ru;
  if (getrusage(RUSAGE_SELF, &ru) != 0)
    return 0;
  auto ns = [](const timeval &t) {
    return static_cast<uint64_t>(t.tv_sec) * 1000000000ull + static_cast<uint64_t>(t.tv_usec) * 1000ull;
  };
  return ns(ru.ru_utime) + ns(ru.ru_stime);
#else
  return static_cast<uint64_t>(std::clock()) * (1000000000ull / CLOCKS_PER_SEC);
#endif
}

/* ------------------------------------------- memory and disk (2026-11-23) */

#if defined(__linux__)
namespace {
// "Key:   12345 kB" from a /proc file, in bytes; 0 when absent.
uint64_t procKb(const char *file, const char *key) {
  FILE *f = std::fopen(file, "r");
  if (!f)
    return 0;
  char line[256];
  const size_t keyLen = std::strlen(key);
  uint64_t out = 0;
  while (std::fgets(line, sizeof line, f)) {
    if (std::strncmp(line, key, keyLen) == 0 && line[keyLen] == ':') {
      unsigned long long kb = 0;
      if (std::sscanf(line + keyLen + 1, "%llu", &kb) == 1)
        out = static_cast<uint64_t>(kb) * 1024ull;
      break;
    }
  }
  std::fclose(f);
  return out;
}
// A cgroup memory cap: v2 memory.max, else v1 memory.limit_in_bytes. 0 when
// "max" / absent / absurdly large (v1 writes ~2^63 for "no limit").
uint64_t cgroupLimit() {
  const char *files[] = {"/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"};
  for (const char *file : files) {
    FILE *f = std::fopen(file, "r");
    if (!f)
      continue;
    char text[64] = {0};
    const bool got = std::fgets(text, sizeof text, f) != nullptr;
    std::fclose(f);
    if (!got || std::strncmp(text, "max", 3) == 0)
      continue;
    unsigned long long v = 0;
    if (std::sscanf(text, "%llu", &v) == 1 && v > 0 && v < (1ull << 60))
      return static_cast<uint64_t>(v);
  }
  return 0;
}
} // namespace
#endif

bool memoryInfo(MemoryInfo &out) {
  out = MemoryInfo{};
#if defined(_WIN32)
  MEMORYSTATUSEX ms;
  ms.dwLength = sizeof ms;
  if (GlobalMemoryStatusEx(&ms)) {
    out.total = ms.ullTotalPhys;
    out.available = ms.ullAvailPhys;
  }
  // A job object's memory cap (IDE launchers, CI runners, test harnesses).
  JOBOBJECT_EXTENDED_LIMIT_INFORMATION job;
  std::memset(&job, 0, sizeof job);
  if (QueryInformationJobObject(nullptr, JobObjectExtendedLimitInformation, &job, sizeof job, nullptr)) {
    const DWORD flags = job.BasicLimitInformation.LimitFlags;
    uint64_t cap = 0;
    if (flags & JOB_OBJECT_LIMIT_PROCESS_MEMORY)
      cap = job.ProcessMemoryLimit;
    if ((flags & JOB_OBJECT_LIMIT_JOB_MEMORY) && (cap == 0 || job.JobMemoryLimit < cap))
      cap = job.JobMemoryLimit;
    out.limit = cap;
  }
  // K32GetProcessMemoryInfo lives in KERNEL32 (no psapi.lib).
  PROCESS_MEMORY_COUNTERS_EX pmc;
  std::memset(&pmc, 0, sizeof pmc);
  pmc.cb = sizeof pmc;
  if (K32GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS *>(&pmc),
                              sizeof pmc)) {
    out.used = pmc.PrivateUsage;
    out.peak = pmc.PeakPagefileUsage;
  }
#elif defined(__linux__)
  out.total = procKb("/proc/meminfo", "MemTotal");
  out.available = procKb("/proc/meminfo", "MemAvailable");
  if (out.available == 0) // kernels before 3.14
    out.available = procKb("/proc/meminfo", "MemFree") + procKb("/proc/meminfo", "Cached");
  out.limit = cgroupLimit();
  out.used = procKb("/proc/self/status", "RssAnon") + procKb("/proc/self/status", "VmSwap");
  out.peak = procKb("/proc/self/status", "VmHWM");
#elif defined(__APPLE__)
  uint64_t mem = 0;
  size_t len = sizeof mem;
  if (sysctlbyname("hw.memsize", &mem, &len, nullptr, 0) == 0)
    out.total = mem;
  vm_statistics64_data_t vm;
  mach_msg_type_number_t count = HOST_VM_INFO64_COUNT;
  vm_size_t page = 0;
  if (host_page_size(mach_host_self(), &page) == KERN_SUCCESS &&
      host_statistics64(mach_host_self(), HOST_VM_INFO64, reinterpret_cast<host_info64_t>(&vm), &count) ==
          KERN_SUCCESS)
    out.available = (static_cast<uint64_t>(vm.free_count) + vm.inactive_count + vm.purgeable_count +
                     vm.speculative_count) *
                    static_cast<uint64_t>(page);
  task_vm_info_data_t info;
  mach_msg_type_number_t infoCount = TASK_VM_INFO_COUNT;
  if (task_info(mach_task_self(), TASK_VM_INFO, reinterpret_cast<task_info_t>(&info), &infoCount) ==
      KERN_SUCCESS)
    out.used = info.phys_footprint;
  {
    struct rusage ru;
    if (getrusage(RUSAGE_SELF, &ru) == 0)
      out.peak = static_cast<uint64_t>(ru.ru_maxrss); // bytes on macOS
  }
#elif defined(__FreeBSD__) || defined(__DragonFly__)
  unsigned long physmem = 0;
  size_t len = sizeof physmem;
  if (sysctlbyname("hw.physmem", &physmem, &len, nullptr, 0) == 0)
    out.total = physmem;
  unsigned int freeCount = 0, inactiveCount = 0;
  size_t ulen = sizeof freeCount;
  sysctlbyname("vm.stats.vm.v_free_count", &freeCount, &ulen, nullptr, 0);
  ulen = sizeof inactiveCount;
  sysctlbyname("vm.stats.vm.v_inactive_count", &inactiveCount, &ulen, nullptr, 0);
  const long page = sysconf(_SC_PAGESIZE);
  if (page > 0)
    out.available = (static_cast<uint64_t>(freeCount) + inactiveCount) * static_cast<uint64_t>(page);
#endif
#if !defined(_WIN32) && defined(_SC_PHYS_PAGES) && defined(_SC_PAGESIZE)
  if (out.total == 0) { // any other POSIX system
    const long pages = sysconf(_SC_PHYS_PAGES), page = sysconf(_SC_PAGESIZE);
    if (pages > 0 && page > 0)
      out.total = static_cast<uint64_t>(pages) * static_cast<uint64_t>(page);
  }
#endif
#if !defined(_WIN32) && defined(_SC_AVPHYS_PAGES) && defined(_SC_PAGESIZE)
  if (out.available == 0) {
    const long pages = sysconf(_SC_AVPHYS_PAGES), page = sysconf(_SC_PAGESIZE);
    if (pages > 0 && page > 0)
      out.available = static_cast<uint64_t>(pages) * static_cast<uint64_t>(page);
  }
#endif
  return out.total > 0;
}

void *mapNewFile(const char *dir, uint64_t bytes, uint64_t &handle, std::string &why) {
  handle = 0;
  if (!dir || !*dir || bytes == 0) {
    why = "no folder for the file";
    return nullptr;
  }
  static std::atomic<uint64_t> counter{0};
#if defined(_WIN32)
  char name[96];
  std::snprintf(name, sizeof name, "\\nc_spill_%lu_%llu.bin", static_cast<unsigned long>(GetCurrentProcessId()),
                static_cast<unsigned long long>(counter.fetch_add(1)));
  const std::string path = std::string(dir) + name;
  const int n = MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, nullptr, 0);
  std::wstring wide(n > 0 ? static_cast<size_t>(n) : 1, L'\0');
  MultiByteToWideChar(CP_UTF8, 0, path.c_str(), -1, &wide[0], n);
  HANDLE file = CreateFileW(wide.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr, CREATE_NEW,
                            FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE, nullptr);
  if (file == INVALID_HANDLE_VALUE) {
    why = "cannot create a file in " + std::string(dir) + " (error " + std::to_string(GetLastError()) + ")";
    return nullptr;
  }
  DWORD unused = 0;
  DeviceIoControl(file, FSCTL_SET_SPARSE, nullptr, 0, nullptr, 0, &unused, nullptr); // best effort
  LARGE_INTEGER size;
  size.QuadPart = static_cast<LONGLONG>(bytes);
  if (!SetFilePointerEx(file, size, nullptr, FILE_BEGIN) || !SetEndOfFile(file)) {
    why = "the disk has no room for " + std::to_string(bytes) + " bytes (error " + std::to_string(GetLastError()) + ")";
    CloseHandle(file);
    return nullptr;
  }
  HANDLE mapping = CreateFileMappingW(file, nullptr, PAGE_READWRITE, static_cast<DWORD>(bytes >> 32),
                                      static_cast<DWORD>(bytes & 0xFFFFFFFFull), nullptr);
  if (!mapping) {
    why = "cannot map the file (error " + std::to_string(GetLastError()) + ")";
    CloseHandle(file);
    return nullptr;
  }
  void *address = MapViewOfFile(mapping, FILE_MAP_ALL_ACCESS, 0, 0, static_cast<SIZE_T>(bytes));
  if (!address) {
    why = "cannot map the file (error " + std::to_string(GetLastError()) + ")";
    CloseHandle(mapping);
    CloseHandle(file);
    return nullptr;
  }
  // The FILE handle stays open as long as the mapping (2026-11-23 fix):
  // delete-on-close acts when the last HANDLE closes - a mapping does not
  // count - so closing it here deleted the file under the mapping, and
  // pages the OS paged out came back as zeros. Closed in unmapFile(); a
  // crash closes it too, and the file goes.
  handle = reinterpret_cast<uint64_t>(new HANDLE[2]{file, mapping});
  return address;
#elif defined(__unix__) || defined(__APPLE__)
  char name[96];
  std::snprintf(name, sizeof name, "/nc_spill_%ld_%llu.bin", static_cast<long>(getpid()),
                static_cast<unsigned long long>(counter.fetch_add(1)));
  const std::string path = std::string(dir) + name;
  const int fd = open(path.c_str(), O_RDWR | O_CREAT | O_EXCL, 0600);
  if (fd < 0) {
    why = "cannot create a file in " + std::string(dir);
    return nullptr;
  }
  unlink(path.c_str()); // gone from the folder now; freed when unmapped or when the process ends
  if (ftruncate(fd, static_cast<off_t>(bytes)) != 0) {
    why = "the disk has no room";
    close(fd);
    return nullptr;
  }
  void *address = mmap(nullptr, static_cast<size_t>(bytes), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
  close(fd); // the mapping keeps the file
  if (address == MAP_FAILED) {
    why = "cannot map the file";
    return nullptr;
  }
  return address;
#else
  (void)counter;
  why = "file-backed memory is not available on this OS";
  return nullptr;
#endif
}

void unmapFile(void *address, uint64_t bytes, uint64_t handle) {
  if (!address)
    return;
#if defined(_WIN32)
  (void)bytes;
  UnmapViewOfFile(address);
  if (handle) {
    HANDLE *h = reinterpret_cast<HANDLE *>(handle);
    CloseHandle(h[1]); // the mapping
    CloseHandle(h[0]); // the file: deleted now (delete-on-close)
    delete[] h;
  }
#elif defined(__unix__) || defined(__APPLE__)
  (void)handle;
  munmap(address, static_cast<size_t>(bytes));
#endif
}

uint64_t diskFreeBytes(const char *path) {
  if (!path || !*path)
    return 0;
#if defined(_WIN32)
  const int n = MultiByteToWideChar(CP_UTF8, 0, path, -1, nullptr, 0);
  if (n <= 0)
    return 0;
  std::wstring wide(static_cast<size_t>(n), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, path, -1, &wide[0], n);
  ULARGE_INTEGER freeToCaller;
  if (!GetDiskFreeSpaceExW(wide.c_str(), &freeToCaller, nullptr, nullptr))
    return 0;
  return freeToCaller.QuadPart;
#else
  struct statvfs s;
  if (statvfs(path, &s) != 0)
    return 0;
  return static_cast<uint64_t>(s.f_bavail) * static_cast<uint64_t>(s.f_frsize);
#endif
}

/* ------------------------------------------- hard faults (2026-11-23) */

bool hardFaults(uint64_t &count) {
  count = 0;
#if defined(_WIN32)
  // SystemPerformanceInformation (class 2). PageReadIoCount is the 22nd
  // field: 4 LARGE_INTEGERs (32 bytes), then ULONGs - IoRead/Write/Other
  // OperationCount, AvailablePages, CommittedPages, CommitLimit,
  // PeakCommitment, PageFaultCount, CopyOnWriteCount, TransitionCount,
  // CacheTransitionCount, DemandZeroCount, PageReadCount (offset 80),
  // PageReadIoCount (offset 84). The layout has been fixed since NT 4.
  NtQuerySystemInformationFn query = ntQuery();
  if (!query)
    return false;
  alignas(8) unsigned char info[1024] = {};
  ULONG got = 0;
  if (query(2, info, sizeof info, &got) < 0 || got < 88)
    return false;
  uint32_t reads = 0;
  std::memcpy(&reads, info + 84, sizeof reads);
  // The OS counter is 32-bit: widen it across wrap-arounds.
  static std::atomic<uint64_t> widened{0};
  uint64_t old = widened.load();
  for (;;) {
    uint64_t next = (old & ~uint64_t(0xFFFFFFFF)) | reads;
    if (next < old)
      next += uint64_t(1) << 32;
    if (widened.compare_exchange_weak(old, next)) {
      count = next;
      return true;
    }
  }
#elif defined(__linux__)
  std::ifstream in("/proc/vmstat");
  std::string key;
  unsigned long long v = 0;
  while (in >> key >> v) {
    if (key == "pgmajfault") {
      count = v;
      return true;
    }
  }
  return false;
#elif defined(__APPLE__)
  vm_statistics64_data_t vm;
  mach_msg_type_number_t n = HOST_VM_INFO64_COUNT;
  if (host_statistics64(mach_host_self(), HOST_VM_INFO64, reinterpret_cast<host_info64_t>(&vm), &n) !=
      KERN_SUCCESS)
    return false;
  count = vm.pageins;
  return true;
#elif defined(__FreeBSD__) || defined(__DragonFly__)
  unsigned int v = 0;
  size_t len = sizeof v;
  if (sysctlbyname("vm.stats.vm.v_io_faults", &v, &len, nullptr, 0) != 0)
    return false;
  count = v;
  return true;
#else
  return false;
#endif
}

} // namespace nc::par::sys
