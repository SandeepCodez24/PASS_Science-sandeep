// Stack guard (2026-11-18): deep recursion becomes an NC error instead of
// a crash.
//
// Every NC function call (and every expression evaluation) takes some of
// the thread's stack. Before this guard, a recursion a few hundred levels
// deep - or a few dozen in a Debug build - ran off the end of the 1 MB
// Windows stack and the operating system killed nc.exe with no message;
// even `try` could not catch it.
//
// Now each thread looks up where its stack ends once (stack_guard.cpp:
// Windows, Linux, macOS, with a safe fallback elsewhere), and nearlyFull()
// - one compare - tells the interpreter when less than a reserve is left.
// The interpreter then reports "maximum recursion depth reached" as an
// ordinary error and unwinds. The reserve (an eighth of the stack, at least
// 256 KB) leaves room for the built-in function that may run at the deepest
// level and for the error report itself.
//
// The main thread's stack is also made larger at link time (CMakeLists.txt:
// 256 MB reserved on Windows and macOS; only the pages used are committed),
// so legitimate deep recursion goes much further before the guard trips.
#ifndef NC_STACK_GUARD_H
#define NC_STACK_GUARD_H

#include <cstddef>
#include <cstdint>

namespace nc {
namespace stackguard {

struct Limits {
  std::uintptr_t low = 0;  // lowest usable address (the stack grows down to it)
  std::size_t reserve = 0; // bytes kept free below the guard line
  bool known = false;
};

// Asks the operating system (stack_guard.cpp).
Limits makeLimits();

// This thread's limits, looked up on first use.
inline const Limits &limits() {
  thread_local const Limits l = makeLimits();
  return l;
}

// An address in the current stack frame.
inline std::uintptr_t here() {
#if defined(__GNUC__) || defined(__clang__)
  return reinterpret_cast<std::uintptr_t>(__builtin_frame_address(0));
#else
  volatile char probe = 0;
  const void *p = const_cast<const char *>(&probe);
  return reinterpret_cast<std::uintptr_t>(p);
#endif
}

// True when less than the reserve is left on this thread's stack.
inline bool nearlyFull() {
  const Limits &l = limits();
  return l.known && here() < l.low + l.reserve;
}

// The usable stack size of this thread in bytes (0 if unknown) - for messages.
std::size_t stackSize();

// NC function calls currently active on this thread (for the message).
inline int &callDepth() {
  thread_local int depth = 0;
  return depth;
}

// Whether the "maximum recursion depth" error was already printed for the
// recursion now unwinding (cleared when a new top-level call starts).
inline bool &reported() {
  thread_local bool done = false;
  return done;
}

// Counts one NC function call for as long as it runs.
struct CallScope {
  CallScope() { ++callDepth(); }
  ~CallScope() { --callDepth(); }
  CallScope(const CallScope &) = delete;
  CallScope &operator=(const CallScope &) = delete;
};

} // namespace stackguard
} // namespace nc

#endif // NC_STACK_GUARD_H
