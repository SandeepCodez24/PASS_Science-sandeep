// Script analysis for the IDE's "Analysis" box - see analysis.h and
// docs/Analysis_Section_Java_Handover.md for the JSON formats.

#include "analysis.h"

#include "../parallel/par.h"
#include "../parallel/sys_cpu.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <string>
#include <system_error>
#include <thread>
#include <unordered_map>
#include <vector>

namespace nc::analysis {

using Clock = std::chrono::steady_clock;

namespace detail {

bool g_active = false;
bool g_profile = false;
std::atomic<uint64_t> g_computations{0};
std::atomic<uint64_t> g_statements{0};

struct OpStat {
  std::string name;
  std::atomic<uint64_t> calls{0};
  std::atomic<uint64_t> computations{0};
  std::atomic<uint64_t> ticks{0}; // profiler samples taken while it ran
};
std::atomic<OpStat *> g_currentOp{nullptr};

} // namespace detail

namespace {

using detail::OpStat;

/* ---- switches ---- */

std::atomic<bool> g_available{false};
std::atomic<bool> g_computationsOn{false};
std::atomic<bool> g_timingOn{false};
std::atomic<int> g_intervalMs{1000};
std::filesystem::path g_file, g_tmpFile;

/* ---- command state ---- */

std::atomic<bool> g_busy{false};
std::atomic<uint64_t> g_commandSeq{0};
std::atomic<bool> g_commandProfile{false}; // the time toggle, as it was at command start
std::atomic<bool> g_commandCounts{false};  // the computations toggle, same
Clock::time_point g_commandStart;          // written before g_busy is set
double g_commandSeconds = 0;               // interpreter thread
bool g_stopped = false;
bool g_summaryPending = false;
uint64_t g_snapshotSeq = 0; // sampler + summary, under g_mutex

std::mutex g_mutex; // guards everything below that both threads touch
std::condition_variable g_cv;
bool g_samplerStarted = false;

/* ---- operations (interned names; never freed) ---- */

std::unordered_map<std::string, std::unique_ptr<OpStat>> g_ops; // under g_mutex
OpStat g_statementsOp;                                          // "(statements)"
std::atomic<uint64_t> g_totalTicks{0};

struct CacheEntry {
  const char *ptr = nullptr;
  size_t length = 0;
  OpStat *op = nullptr;
};
std::array<CacheEntry, 256> g_opCache; // interpreter thread only

/* ---- loops ---- */

struct Frame {
  int line;
  bool isFor;
  int64_t total;
  uint64_t completed = 0;
  bool tracked = false; // the outermost loop: growth + progress
};
std::vector<Frame> g_loops; // interpreter thread only

// Published for the sampler: completed iterations and totals of the
// first kMaxDepth loop levels.
constexpr int kMaxDepth = 4;
std::atomic<int> g_depth{0};
std::array<std::atomic<int64_t>, kMaxDepth> g_levelDone{};
std::array<std::atomic<int64_t>, kMaxDepth> g_levelTotal{};

struct Tracked {
  int line = 0;
  bool isFor = true;
  int64_t total = -1;
  uint64_t startWork = 0, startComputations = 0;
  Clock::time_point start;
  std::vector<double> k, work, seconds; // geometric samples, under g_mutex
  double nextK = 1;
};
Tracked g_tracked;          // valid while g_trackedActive
bool g_trackedActive = false;

struct LoopRecord {
  int line;
  bool isFor;
  int64_t total;
  uint64_t iterations;
  uint64_t computations;
  double seconds;
  GrowthFit work, time;
};
std::vector<LoopRecord> g_loopRecords; // under g_mutex
constexpr size_t kMaxLoopRecords = 50;

/* ---- top-level statements ---- */

struct StatementRecord {
  size_t index;
  int line;
  const char *kind;
  double start, seconds;
  uint64_t computations;
};
struct Level {
  std::atomic<int64_t> index{-1};
  std::atomic<int64_t> count{0};
  std::atomic<int> line{0};
  Clock::time_point start;
  uint64_t startComputations = 0;
  const char *kind = "";
  std::vector<StatementRecord> history; // under g_mutex
  uint64_t dropped = 0;
};
std::array<Level, 2> g_levels; // 0 = typed at the prompt, 1 = a script it runs
constexpr size_t kMaxHistory = 1000;

/* ---- computations-over-time series (sampler writes, under g_mutex) ---- */

std::vector<std::array<double, 2>> g_series;
double g_seriesStep = 0.05; // seconds between points; doubles when full
constexpr size_t kMaxSeries = 600;

/* ================================================================ JSON */

std::string num(double x, int digits = 3) {
  if (!(x == x) || x < -1e300 || x > 1e300)
    return "0";
  char buf[64];
  if (std::fabs(x) >= 1e15)
    std::snprintf(buf, sizeof buf, "%.0f", x);
  else
    std::snprintf(buf, sizeof buf, "%.*f", digits, x);
  std::string s = buf;
  if (s.find('.') != std::string::npos) {
    while (!s.empty() && s.back() == '0')
      s.pop_back();
    if (!s.empty() && s.back() == '.')
      s.pop_back();
  }
  return s == "-0" ? "0" : s;
}

std::string jsonText(const std::string &text) {
  std::string out = "\"";
  for (char c : text) {
    const unsigned char u = static_cast<unsigned char>(c);
    if (c == '"' || c == '\\') {
      out += '\\';
      out += c;
    } else if (u < 0x20) {
      char buf[8];
      std::snprintf(buf, sizeof buf, "\\u%04x", u);
      out += buf;
    } else {
      out += c;
    }
  }
  return out + "\"";
}

double secondsSince(Clock::time_point t, Clock::time_point now) {
  return std::chrono::duration<double>(now - t).count();
}

std::string fitJson(const GrowthFit &f) {
  if (!f.ok)
    return "{\"ok\":false,\"reason\":" + jsonText(f.reason) + "}";
  return "{\"ok\":true,\"order\":" + jsonText(f.order) + ",\"display\":" + jsonText(f.display) +
         ",\"key\":" + jsonText(f.key) + ",\"exponent\":" + num(f.exponent, 2) +
         ",\"error\":" + num(f.error, 4) + ",\"confidence\":" + jsonText(f.confidence) + "}";
}

GrowthFit fitTracked(const std::vector<double> &k, const std::vector<double> &y) {
  return fitGrowth(k.data(), y.data(), k.size());
}

/* ---- the sections ---- */

std::string computationsJson(Clock::time_point now, bool live) {
  const uint64_t total = detail::g_computations.load(std::memory_order_relaxed);
  const double elapsed = secondsSince(g_commandStart, now);
  std::string j = "\"computations\":{\"total\":" + std::to_string(total) +
                  ",\"statements\":" + std::to_string(detail::g_statements.load(std::memory_order_relaxed)) +
                  ",\"rate_per_s\":" + num(elapsed > 0 ? static_cast<double>(total) / elapsed : 0.0, 0) +
                  ",\"series\":[";
  for (size_t i = 0; i < g_series.size(); i++)
    j += (i ? ",[" : "[") + num(g_series[i][0], 3) + "," + num(g_series[i][1], 0) + "]";
  if (!live || g_series.empty() || g_series.back()[0] < elapsed - 1e-9)
    j += std::string(g_series.empty() ? "[" : ",[") + num(elapsed, 3) + "," + std::to_string(total) + "]";
  j += "]}";
  return j;
}

std::string loopRecordJson(const LoopRecord &r) {
  return "{\"line\":" + std::to_string(r.line) + ",\"kind\":" + (r.isFor ? "\"for\"" : "\"while\"") +
         ",\"total\":" + std::to_string(r.total) + ",\"iterations\":" + std::to_string(r.iterations) +
         ",\"computations\":" + std::to_string(r.computations) + ",\"seconds\":" + num(r.seconds, 4) +
         ",\"growth\":" + fitJson(r.work) + ",\"time_growth\":" + fitJson(r.time) + "}";
}

// The loop running now: growth so far. Under g_mutex.
std::string currentLoopJson() {
  if (!g_trackedActive)
    return "null";
  const GrowthFit w = fitTracked(g_tracked.k, g_tracked.work);
  const GrowthFit t = fitTracked(g_tracked.k, g_tracked.seconds);
  const int64_t done = g_levelDone[0].load(std::memory_order_relaxed);
  return "{\"line\":" + std::to_string(g_tracked.line) + ",\"kind\":" +
         (g_tracked.isFor ? "\"for\"" : "\"while\"") + ",\"total\":" + std::to_string(g_tracked.total) +
         ",\"iterations\":" + std::to_string(done) + ",\"growth\":" + fitJson(w) +
         ",\"time_growth\":" + fitJson(t) + "}";
}

std::string growthJson() {
  std::string j = "\"growth\":{\"loop\":" + currentLoopJson() + ",\"loops\":[";
  for (size_t i = 0; i < g_loopRecords.size(); i++)
    j += (i ? "," : "") + loopRecordJson(g_loopRecords[i]);
  return j + "]}";
}

// Progress of the running command. Under g_mutex.
std::string progressJson(Clock::time_point now) {
  const int level = g_levels[1].count.load() > 0 ? 1 : 0;
  const int64_t index = g_levels[level].index.load(), count = g_levels[level].count.load();
  std::string basis = "none";
  double percent = -1, eta = -1;
  if (g_trackedActive && g_tracked.total > 0) {
    // The outermost loop: completed iterations, plus the share of the
    // current one its inner loop has done.
    double k = static_cast<double>(g_levelDone[0].load());
    if (g_depth.load() >= 2) {
      const double inner = static_cast<double>(g_levelTotal[1].load());
      if (inner > 0)
        k += std::min(1.0, static_cast<double>(g_levelDone[1].load()) / inner);
    }
    const double n = static_cast<double>(g_tracked.total);
    double frac = k / n;
    // Weight by the fitted time (or work) model when there is one: in an
    // O(n^2) loop the second half of the iterations takes 3/4 of the time.
    GrowthFit model = fitTracked(g_tracked.k, g_tracked.seconds);
    if (!model.ok || model.confidence == "low")
      model = fitTracked(g_tracked.k, g_tracked.work);
    if (model.ok && model.confidence != "low") {
      const double at = model.predict(k), end = model.predict(n);
      if (end > 0 && at >= 0)
        frac = std::clamp(at / end, 0.0, 1.0);
    }
    percent = 100.0 * std::clamp(frac, 0.0, 1.0);
    basis = "loop";
    const double inLoop = secondsSince(g_tracked.start, now);
    if (frac > 0.005)
      eta = inLoop * (1.0 - frac) / frac;
  } else if (count > 1 && index >= 0) {
    percent = 100.0 * static_cast<double>(index) / static_cast<double>(count);
    basis = "statements";
  }
  std::string j = "\"progress\":{\"basis\":\"" + basis + "\"";
  j += ",\"percent\":" + (percent >= 0 ? num(percent, 1) : std::string("null"));
  j += ",\"eta_s\":" + (eta >= 0 ? num(eta, 1) : std::string("null"));
  j += ",\"eta_text\":" + (eta >= 0 ? jsonText(formatDuration(eta)) : std::string("null"));
  j += ",\"statement\":" + std::to_string(index + 1) + ",\"statements\":" + std::to_string(count);
  j += ",\"line\":" + std::to_string(g_levels[level].line.load());
  if (g_trackedActive)
    j += ",\"loop_line\":" + std::to_string(g_tracked.line) +
         ",\"iteration\":" + std::to_string(g_levelDone[0].load()) +
         ",\"iterations\":" + std::to_string(g_tracked.total);
  return j + "}";
}

// Operations sorted by sampled time, top 25. Under g_mutex.
std::string operationsJson(double elapsed) {
  struct Row {
    const OpStat *op;
    uint64_t ticks;
  };
  std::vector<Row> rows;
  for (const auto &kv : g_ops) {
    const OpStat &op = *kv.second;
    if (op.calls.load(std::memory_order_relaxed) > 0 || op.ticks.load(std::memory_order_relaxed) > 0)
      rows.push_back({&op, op.ticks.load(std::memory_order_relaxed)});
  }
  if (g_statementsOp.ticks.load() > 0)
    rows.push_back({&g_statementsOp, g_statementsOp.ticks.load()});
  std::sort(rows.begin(), rows.end(), [](const Row &a, const Row &b) {
    if (a.ticks != b.ticks)
      return a.ticks > b.ticks;
    return a.op->calls.load() > b.op->calls.load();
  });
  const double total = static_cast<double>(g_totalTicks.load());
  std::string j = "\"operations\":{\"samples\":" + std::to_string(g_totalTicks.load()) + ",\"list\":[";
  for (size_t i = 0; i < rows.size() && i < 25; i++) {
    const double share = total > 0 ? static_cast<double>(rows[i].ticks) / total : 0.0;
    j += (i ? "," : "") + std::string("{\"name\":") + jsonText(rows[i].op->name) +
         ",\"calls\":" + std::to_string(rows[i].op->calls.load()) +
         ",\"computations\":" + std::to_string(rows[i].op->computations.load()) +
         ",\"share\":" + num(share, 4) + ",\"time_s\":" + num(share * elapsed, 4) + "}";
  }
  return j + "]}";
}

// Statement history: the script's statements if one ran, else the
// command's. Under g_mutex.
std::string historyJson() {
  const Level &lv = g_levels[1].history.empty() ? g_levels[0] : g_levels[1];
  std::string j = "\"history\":{\"dropped\":" + std::to_string(lv.dropped) + ",\"list\":[";
  for (size_t i = 0; i < lv.history.size(); i++) {
    const StatementRecord &r = lv.history[i];
    j += (i ? "," : "") + std::string("{\"index\":") + std::to_string(r.index) +
         ",\"line\":" + std::to_string(r.line) + ",\"kind\":" + jsonText(r.kind) +
         ",\"start_s\":" + num(r.start, 4) + ",\"time_s\":" + num(r.seconds, 4) +
         ",\"computations\":" + std::to_string(r.computations) + "}";
  }
  return j + "]}";
}

// One whole document. Under g_mutex.
std::string documentJson(const char *type, const char *state, Clock::time_point now, double elapsed,
                         bool live) {
  std::string j = std::string("{\"v\":1,\"type\":\"") + type + "\",\"seq\":" + std::to_string(++g_snapshotSeq) +
                  ",\"command\":" + std::to_string(g_commandSeq.load()) + ",\"state\":\"" + state + "\"" +
                  ",\"elapsed_s\":" + num(elapsed, 4) + ",\"elapsed_text\":" + jsonText(formatDuration(elapsed)) +
                  ",\"interval_ms\":" + std::to_string(g_intervalMs.load()) +
                  ",\"build\":\"" + par::buildType() + "\"";
  const bool counts = g_commandCounts.load(), timing = g_commandProfile.load();
  j += std::string(",\"features\":{\"computations\":") + (counts ? "true" : "false") +
       ",\"time\":" + (timing ? "true" : "false") + "}";
  if (counts)
    j += "," + computationsJson(now, live) + "," + growthJson();
  if (timing) {
    if (live)
      j += "," + progressJson(now);
    j += "," + operationsJson(elapsed) + "," + historyJson();
  }
  if (!live)
    j += std::string(",\"stopped\":") + (g_stopped ? "true" : "false");
  return j + "}";
}

void writeSnapshot(const std::string &json) {
  {
    std::ofstream out(g_tmpFile, std::ios::binary | std::ios::trunc);
    if (!out)
      return;
    out << json << '\n';
    if (!out)
      return;
  }
  std::error_code ec;
  std::filesystem::rename(g_tmpFile, g_file, ec);
}

/* ============================================================ sampler */

bool running(uint64_t command) { return g_busy.load() && g_commandSeq.load() == command; }

void addSeriesPoint(double t) {
  // Under g_mutex.
  if (!g_series.empty() && t - g_series.back()[0] < g_seriesStep * 0.999)
    return;
  g_series.push_back({t, static_cast<double>(detail::g_computations.load(std::memory_order_relaxed))});
  if (g_series.size() >= kMaxSeries) {
    std::vector<std::array<double, 2>> half;
    for (size_t i = 0; i < g_series.size(); i += 2)
      half.push_back(g_series[i]);
    g_series.swap(half);
    g_seriesStep *= 2;
  }
}

void samplerLoop() {
  std::unique_lock<std::mutex> lk(g_mutex);
  for (;;) {
    g_cv.wait(lk, [] { return g_busy.load(); });
    const uint64_t command = g_commandSeq.load();
    const Clock::time_point start = g_commandStart;
    lk.unlock();
    auto nextWrite = start + std::chrono::milliseconds(g_intervalMs.load());
    bool wrote = false;
    while (running(command)) {
      // 2 ms for the profiler, else 50 ms for the series.
      const bool profile = g_commandProfile.load();
      par::sys::preciseSleepUs(profile ? 2000 : 50000);
      if (!running(command))
        break;
      if (profile) {
        OpStat *op = detail::g_currentOp.load(std::memory_order_relaxed);
        (op ? op : &g_statementsOp)->ticks.fetch_add(1, std::memory_order_relaxed);
        g_totalTicks.fetch_add(1, std::memory_order_relaxed);
      }
      const Clock::time_point now = Clock::now();
      lk.lock();
      addSeriesPoint(secondsSince(start, now));
      std::string json;
      if (now >= nextWrite && running(command)) {
        json = documentJson("analysis", "running", now, secondsSince(start, now), true);
        nextWrite += std::chrono::milliseconds(g_intervalMs.load());
      }
      lk.unlock();
      if (!json.empty()) {
        writeSnapshot(json);
        wrote = true;
      }
    }
    lk.lock();
    if (wrote) {
      // One last snapshot so the panel shows the command has ended. Its
      // numbers are final once commandFinished() has run.
      g_cv.wait_for(lk, std::chrono::milliseconds(200), [&] { return g_summaryPending || g_commandSeq.load() != command; });
      const std::string json =
          documentJson("analysis", "idle", Clock::now(), g_commandSeconds, false);
      lk.unlock();
      writeSnapshot(json);
      lk.lock();
    }
    g_cv.wait(lk, [&] { return g_commandSeq.load() != command || !g_busy.load(); });
  }
}

void startSamplerLocked() {
  if (g_samplerStarted)
    return;
  g_samplerStarted = true;
  std::thread(samplerLoop).detach(); // sleeps between commands; nothing to clean up
}

/* ============================================================ fitting */

// The candidate shapes of cumulative work after k iterations.
enum Model { Linear, NLogN, Quadratic, QuadLog, Cubic, Exponential, kModels };
const char *kOrder[] = {"O(n)", "O(n log n)", "O(n^2)", "O(n^2 log n)", "O(n^3)", "O(2^n)"};
const char *kDisplay[] = {"O(n)", "O(n log n)", "O(n²)", "O(n² log n)", "O(n³)", "O(2ⁿ)"};
const char *kKey[] = {"n", "nlogn", "n2", "n2logn", "n3", "2n"};

double shape(int m, double k) {
  const double l = std::log(std::max(k, 1.0));
  switch (m) {
  case Linear:
    return k;
  case NLogN:
    return k * l;
  case Quadratic:
    return k * k;
  case QuadLog:
    return k * k * l;
  case Cubic:
    return k * k * k;
  default:
    return 0;
  }
}

} // namespace

double GrowthFit::predict(double k) const {
  if (model == Exponential)
    return std::exp(a + b * k);
  if (model < 0)
    return k;
  return a * shape(model, k) + b;
}

GrowthFit fitGrowth(const double *k, const double *c, size_t n) {
  GrowthFit f;
  // Points with k >= 2 and positive work.
  std::vector<double> K, C;
  for (size_t i = 0; i < n; i++)
    if (k[i] >= 2 && c[i] > 0) {
      K.push_back(k[i]);
      C.push_back(c[i]);
    }
  const double kMax = K.empty() ? 0 : *std::max_element(K.begin(), K.end());
  const double kMin = K.empty() ? 0 : *std::min_element(K.begin(), K.end());
  if (K.size() < 6 || kMax < 16 || kMax < 8 * kMin) {
    f.reason = "needs more iterations (at least 16, over a range of 8x)";
    return f;
  }
  const size_t m = K.size();
  double err[kModels], A[kModels], B[kModels];
  // Polynomial-type models: C ~ a*g(k) + b, weighted by 1/C^2 (relative
  // error, so the small-k points count as much as the large ones).
  for (int model = Linear; model <= Cubic; model++) {
    double sw = 0, sg = 0, sc = 0, sgg = 0, sgc = 0;
    for (size_t i = 0; i < m; i++) {
      const double w = 1.0 / (C[i] * C[i]), g = shape(model, K[i]);
      sw += w;
      sg += w * g;
      sc += w * C[i];
      sgg += w * g * g;
      sgc += w * g * C[i];
    }
    const double det = sw * sgg - sg * sg;
    err[model] = 1e9;
    if (std::fabs(det) < 1e-300)
      continue;
    const double a = (sw * sgc - sg * sc) / det, b = (sgg * sc - sg * sgc) / det;
    A[model] = a;
    B[model] = b;
    // A negative slope, or an intercept that cancels most of the work,
    // means the shape does not fit.
    if (!(a > 0) || b < -0.5 * C[0])
      continue;
    double e = 0;
    for (size_t i = 0; i < m; i++) {
      const double r = (C[i] - a * shape(model, K[i]) - b) / C[i];
      e += r * r;
    }
    err[model] = std::sqrt(e / static_cast<double>(m));
  }
  // Exponential: ln C = alpha + beta*k.
  {
    double sk = 0, sl = 0, skk = 0, skl = 0;
    for (size_t i = 0; i < m; i++) {
      const double l = std::log(C[i]);
      sk += K[i];
      sl += l;
      skk += K[i] * K[i];
      skl += K[i] * l;
    }
    const double dm = static_cast<double>(m), det = dm * skk - sk * sk;
    err[Exponential] = 1e9;
    if (std::fabs(det) > 1e-300) {
      const double beta = (dm * skl - sk * sl) / det, alpha = (sl - beta * sk) / dm;
      A[Exponential] = alpha;
      B[Exponential] = beta;
      if (beta > 0) {
        double e = 0;
        for (size_t i = 0; i < m; i++) {
          const double r = std::exp(std::min(700.0, alpha + beta * K[i] - std::log(C[i]))) - 1.0;
          e += r * r;
        }
        err[Exponential] = std::sqrt(e / dm);
      }
    }
  }
  int best = 0;
  for (int model = 1; model < kModels; model++)
    if (err[model] < err[best])
      best = model;
  if (err[best] >= 1e9) {
    f.reason = "the work does not grow with the iterations";
    return f;
  }
  // Prefer the simpler shape when it fits about as well.
  int chosen = best;
  for (int model = 0; model < best; model++)
    if (err[model] <= err[best] * 1.10 + 0.002) {
      chosen = model;
      break;
    }
  double second = 1e9;
  for (int model = 0; model < kModels; model++)
    if (model != chosen)
      second = std::min(second, err[model]);
  // Empirical exponent: slope of ln C over ln k on the upper half (in ln k).
  {
    const double mid = std::sqrt(kMin * kMax);
    double sx = 0, sy = 0, sxx = 0, sxy = 0, cnt = 0;
    for (size_t i = 0; i < m; i++)
      if (K[i] >= mid) {
        const double x = std::log(K[i]), y = std::log(C[i]);
        sx += x;
        sy += y;
        sxx += x * x;
        sxy += x * y;
        cnt += 1;
      }
    const double det = cnt * sxx - sx * sx;
    f.exponent = (cnt >= 2 && std::fabs(det) > 1e-12) ? (cnt * sxy - sx * sy) / det : 0;
  }
  f.ok = true;
  f.model = chosen;
  f.a = A[chosen];
  f.b = B[chosen];
  f.error = err[chosen];
  f.order = kOrder[chosen];
  f.display = kDisplay[chosen];
  f.key = kKey[chosen];
  const double span = kMax / kMin;
  if (f.error < 0.03 && (second >= 2.5 * f.error || second >= 0.05) && span >= 64)
    f.confidence = "high";
  else if (f.error < 0.10)
    f.confidence = "medium";
  else
    f.confidence = "low";
  return f;
}

std::string formatDuration(double s) {
  if (!(s >= 0))
    s = 0;
  char buf[64];
  if (s < 1.0) {
    std::snprintf(buf, sizeof buf, "%.0f ms", s * 1000.0);
  } else if (s < 60.0) {
    std::snprintf(buf, sizeof buf, "%.1f s", s);
  } else if (s < 3600.0) {
    const long long t = static_cast<long long>(s);
    std::snprintf(buf, sizeof buf, "%lld min %02lld s", t / 60, t % 60);
  } else {
    const long long t = static_cast<long long>(s);
    std::snprintf(buf, sizeof buf, "%lld h %02lld min %02lld s", t / 3600, (t / 60) % 60, t % 60);
  }
  return buf;
}

/* ================================================================ hooks */

namespace detail {

OpStat *internOp(const char *name, size_t length) {
  // Call sites repeat (a loop calls the same builtin from the same AST
  // string), so a small cache keyed by the name's address nearly always
  // hits; the content check makes a reused address harmless.
  const size_t slot = (reinterpret_cast<uintptr_t>(name) >> 3) & (g_opCache.size() - 1);
  CacheEntry &e = g_opCache[slot];
  OpStat *op;
  if (e.ptr == name && e.length == length && e.op->name.size() == length &&
      std::memcmp(e.op->name.data(), name, length) == 0) {
    op = e.op;
  } else {
    std::lock_guard<std::mutex> lk(g_mutex);
    std::unique_ptr<OpStat> &p = g_ops[std::string(name, length)];
    if (!p) {
      p = std::make_unique<OpStat>();
      p->name.assign(name, length);
    }
    op = p.get();
    e = {name, length, op};
  }
  add(op->calls, 1);
  return op;
}

void opComputations(OpStat *op, uint64_t n) { add(op->computations, n); }

uint64_t workNow() {
  return g_computations.load(std::memory_order_relaxed) + g_statements.load(std::memory_order_relaxed);
}

void sampleTracked(uint64_t completed) {
  // Geometric spacing: dense for small k (where the shape shows), sparse
  // later; ~50 samples per decade.
  if (static_cast<double>(completed) < g_tracked.nextK)
    return;
  std::lock_guard<std::mutex> lk(g_mutex);
  g_tracked.k.push_back(static_cast<double>(completed));
  g_tracked.work.push_back(static_cast<double>(workNow() - g_tracked.startWork));
  g_tracked.seconds.push_back(secondsSince(g_tracked.start, Clock::now()));
  g_tracked.nextK = std::max(static_cast<double>(completed) + 1.0, std::ceil(completed * 1.05));
}

void loopBegin(int line, bool isFor, int64_t total) {
  Frame f{line, isFor, total};
  f.tracked = g_loops.empty();
  const int depth = static_cast<int>(g_loops.size());
  if (depth < kMaxDepth) {
    g_levelDone[depth].store(0);
    g_levelTotal[depth].store(total);
  }
  g_loops.push_back(f);
  g_depth.store(static_cast<int>(g_loops.size()));
  if (f.tracked) {
    std::lock_guard<std::mutex> lk(g_mutex);
    g_tracked = Tracked();
    g_tracked.line = line;
    g_tracked.isFor = isFor;
    g_tracked.total = total;
    g_tracked.startWork = workNow();
    g_tracked.startComputations = g_computations.load(std::memory_order_relaxed);
    g_tracked.start = Clock::now();
    g_trackedActive = true;
  }
}

void loopIteration() {
  if (g_loops.empty())
    return;
  Frame &f = g_loops.back();
  // Called at the start of each iteration: the one before has completed.
  if (f.tracked && f.completed > 0)
    sampleTracked(f.completed);
  f.completed++;
  const int depth = static_cast<int>(g_loops.size()) - 1;
  if (depth < kMaxDepth)
    g_levelDone[depth].store(static_cast<int64_t>(f.completed - 1));
}

void loopEnd() {
  if (g_loops.empty())
    return;
  const Frame f = g_loops.back();
  g_loops.pop_back();
  g_depth.store(static_cast<int>(g_loops.size()));
  if (!f.tracked)
    return;
  if (f.completed > 0) {
    g_tracked.nextK = 0; // always keep the final point
    sampleTracked(f.completed);
  }
  std::lock_guard<std::mutex> lk(g_mutex);
  if (g_loopRecords.size() < kMaxLoopRecords) {
    LoopRecord r;
    r.line = f.line;
    r.isFor = f.isFor;
    r.total = f.total;
    r.iterations = f.completed;
    r.computations = g_computations.load(std::memory_order_relaxed) - g_tracked.startComputations;
    r.seconds = secondsSince(g_tracked.start, Clock::now());
    r.work = fitTracked(g_tracked.k, g_tracked.work);
    r.time = fitTracked(g_tracked.k, g_tracked.seconds);
    g_loopRecords.push_back(r);
  }
  g_trackedActive = false;
}

void topLevelBegin(int level, int line, const char *kind, size_t index, size_t count) {
  if (level < 0 || level > 1)
    return;
  Level &lv = g_levels[level];
  lv.count.store(static_cast<int64_t>(count));
  lv.index.store(static_cast<int64_t>(index));
  lv.line.store(line);
  lv.kind = kind;
  lv.start = Clock::now();
  lv.startComputations = g_computations.load(std::memory_order_relaxed);
}

void topLevelEnd(int level) {
  if (level < 0 || level > 1)
    return;
  Level &lv = g_levels[level];
  const Clock::time_point now = Clock::now();
  std::lock_guard<std::mutex> lk(g_mutex);
  if (lv.history.size() >= kMaxHistory) {
    lv.dropped++;
    return;
  }
  lv.history.push_back({static_cast<size_t>(lv.index.load()), lv.line.load(), lv.kind,
                        secondsSince(g_commandStart, lv.start), secondsSince(lv.start, now),
                        g_computations.load(std::memory_order_relaxed) - lv.startComputations});
}

} // namespace detail

/* ========================================================== IDE control */

void configure(const std::string &sessionDirectory) {
  if (sessionDirectory.empty())
    return;
  // Time outside every operator and builtin: loop control, assignments,
  // variable lookups, user-function calls - the interpreter itself.
  g_statementsOp.name = "(interpreter)";
  g_file = std::filesystem::path(sessionDirectory) / "analysis.json";
  g_tmpFile = std::filesystem::path(sessionDirectory) / "analysis.json.tmp";
  g_available.store(true);
}

namespace {
void switchChanged() {
  std::lock_guard<std::mutex> lk(g_mutex);
  if (g_computationsOn.load() || g_timingOn.load())
    startSamplerLocked();
}
} // namespace

void setComputationsEnabled(bool on) {
  if (!g_available.load())
    return;
  g_computationsOn.store(on);
  switchChanged();
}

void setTimingEnabled(bool on) {
  if (!g_available.load())
    return;
  g_timingOn.store(on);
  switchChanged();
}

void setIntervalMs(int ms) { g_intervalMs.store(std::clamp(ms, 250, 5000)); }
bool computationsEnabled() { return g_computationsOn.load(); }
bool timingEnabled() { return g_timingOn.load(); }

void commandStarted() {
  const bool counts = g_computationsOn.load(), timing = g_timingOn.load();
  if (!g_available.load() || (!counts && !timing)) {
    detail::g_active = false;
    detail::g_profile = false;
    return;
  }
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    detail::g_computations.store(0);
    detail::g_statements.store(0);
    for (auto &kv : g_ops) {
      kv.second->calls.store(0);
      kv.second->computations.store(0);
      kv.second->ticks.store(0);
    }
    g_statementsOp.ticks.store(0);
    g_totalTicks.store(0);
    g_loopRecords.clear();
    g_trackedActive = false;
    for (Level &lv : g_levels) {
      lv.history.clear();
      lv.dropped = 0;
      lv.index.store(-1);
      lv.count.store(0);
      lv.line.store(0);
    }
    g_series.clear();
    g_series.push_back({0.0, 0.0});
    g_seriesStep = 0.05;
    g_stopped = false;
    g_summaryPending = false;
    g_commandCounts.store(counts);
    g_commandProfile.store(timing);
    g_commandStart = Clock::now();
    g_commandSeq.fetch_add(1);
    g_busy.store(true);
  }
  g_loops.clear();
  g_depth.store(0);
  detail::g_currentOp.store(nullptr);
  detail::g_active = true;
  detail::g_profile = timing;
  g_cv.notify_all();
}

void commandFinished(bool stopped) {
  if (!detail::g_active)
    return;
  detail::g_active = false;
  detail::g_profile = false;
  // Loops cut short (Stop, an error) still get their record.
  while (!g_loops.empty())
    detail::loopEnd();
  std::lock_guard<std::mutex> lk(g_mutex);
  g_commandSeconds = secondsSince(g_commandStart, Clock::now());
  g_stopped = stopped;
  g_busy.store(false);
  g_summaryPending = true;
  g_cv.notify_all();
}

std::string takeCommandSummary() {
  std::lock_guard<std::mutex> lk(g_mutex);
  if (!g_summaryPending)
    return "";
  g_summaryPending = false;
  return documentJson("analysis_summary", "done", g_commandStart + std::chrono::duration_cast<Clock::duration>(
                                                                       std::chrono::duration<double>(g_commandSeconds)),
                      g_commandSeconds, false);
}

} // namespace nc::analysis
