#pragma once

// Script analysis for the IDE's "Analysis" box (docs/Analysis_Section_Java_Handover.md).
//
// Two features, each switched on and off by its own toggle in the IDE:
//
//  1. Number of Computation  ("@cmd analysis computations on|off")
//     How many elementary operations the command performs, live, as a
//     time-vs-computations series, and the ORDER OF GROWTH of every loop
//     (O(n), O(n log n), O(n^2), ...), fitted while the loop runs.
//  2. Execution Time          ("@cmd analysis time on|off")
//     Elapsed time, progress in percent with an estimated time left, the
//     time taken by each operation (a sampling profiler), and the history of
//     the command's top-level statements.
//
// The same three rules as the CPU monitor (par_monitor.h):
//  1. Off outside the IDE (needs a session folder).
//  2. Off while both toggles are off: every hook below is one test of a
//     plain bool, inlined, and nothing else.
//  3. Silent while idle: the sampler thread sleeps between commands, and the
//     live file is written only for a command that runs at least one
//     interval (1 s by default).
//
// Output: the live file <session>/analysis.json (rewritten every interval
// while a command runs) and one "@ANALYSIS {json}" summary line per command,
// sent by the interpreter thread before the prompt.
//
// What "a computation" is: an estimate of elementary arithmetic operations,
// counted per ELEMENT - A + B on 9 million elements is 9,000,000, sin(x) of
// one number is 1, a matrix product A(m x k) * B(k x n) is m*k*n, and a
// decomposition (inv, det, svd, ...) of an n x n matrix is n^3. Counting
// elements, not statements, is what makes the order of growth meaningful
// for vectorised code as well as for scalar loops. See computation_cost.h.
//
// Every function here is for the interpreter thread unless it says otherwise.

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <string>

namespace nc::analysis {

namespace detail {
// True while a command runs and at least one toggle is on. Written by the
// interpreter thread only (commandStarted/commandFinished).
extern bool g_active;
extern bool g_profile; // the time toggle: publish the running operation
// Single writer (the interpreter thread), read by the sampler thread.
extern std::atomic<uint64_t> g_computations;
extern std::atomic<uint64_t> g_statements;
struct OpStat;
extern std::atomic<OpStat *> g_currentOp;
OpStat *internOp(const char *name, size_t length);
void opComputations(OpStat *op, uint64_t n);
void loopBegin(int line, bool isFor, int64_t total);
void loopIteration();
void loopEnd();
void topLevelBegin(int level, int line, const char *kind, size_t index, size_t count);
void topLevelEnd(int level);

inline void add(std::atomic<uint64_t> &counter, uint64_t n) {
  counter.store(counter.load(std::memory_order_relaxed) + n, std::memory_order_relaxed);
}
} // namespace detail

/* ---------------------------------------------------------- IDE control */

// IDE mode only: where analysis.json goes. Empty = disabled for good.
void configure(const std::string &sessionDirectory);
void setComputationsEnabled(bool on); // "@cmd analysis computations on|off"
void setTimingEnabled(bool on);       // "@cmd analysis time on|off"
void setIntervalMs(int ms);           // "@cmd analysis interval <ms>", 250..5000 (1000)
bool computationsEnabled();
bool timingEnabled();

// The REPL brackets every command with these.
void commandStarted();
void commandFinished(bool stopped);
// JSON of the "@ANALYSIS" line for the command that just ended, or "" when
// both toggles are off. One per command.
std::string takeCommandSummary();

/* ------------------------------------------------- hot-path hooks (inline) */

inline bool active() { return detail::g_active; }

// One statement executed (any level).
inline void statement() {
  if (detail::g_active)
    detail::add(detail::g_statements, 1);
}

// Elementary operations done by an operator (the parser) or a builtin.
inline void addComputations(uint64_t n) {
  if (detail::g_active)
    detail::add(detail::g_computations, n);
}

// The operation running now, for the time profile ("which operation takes
// the time"). Nested scopes attribute time to the innermost one. `name`
// only needs to live during the constructor (it is interned).
class OpScope {
public:
  OpScope(const char *name, size_t length) {
    if (detail::g_active) {
      op_ = detail::internOp(name, length);
      previous_ = detail::g_currentOp.exchange(op_, std::memory_order_relaxed);
    }
  }
  explicit OpScope(const std::string &name) : OpScope(name.data(), name.size()) {}
  ~OpScope() {
    if (op_)
      detail::g_currentOp.store(previous_, std::memory_order_relaxed);
  }
  // Computations of this operation (counted in the total too).
  void computations(uint64_t n) {
    if (op_) {
      detail::add(detail::g_computations, n);
      detail::opComputations(op_, n);
    }
  }
  bool on() const { return op_ != nullptr; }
  OpScope(const OpScope &) = delete;
  OpScope &operator=(const OpScope &) = delete;

private:
  detail::OpStat *op_ = nullptr;
  detail::OpStat *previous_ = nullptr;
};

// A for / while loop: progress, and the order of growth of the outermost
// loop. `total` is the number of iterations a for loop will make, -1 when
// unknown (while).
class LoopScope {
public:
  LoopScope(int line, bool isFor, int64_t total) : on_(detail::g_active) {
    if (on_)
      detail::loopBegin(line, isFor, total);
  }
  void iteration() {
    if (on_)
      detail::loopIteration();
  }
  ~LoopScope() {
    if (on_)
      detail::loopEnd();
  }
  LoopScope(const LoopScope &) = delete;
  LoopScope &operator=(const LoopScope &) = delete;

private:
  bool on_;
};

// A top-level statement of the command (level 0, typed at the prompt) or of
// a script it runs (level 1): the statement history and the progress in
// statements. `kind` must be a string literal.
class TopLevelScope {
public:
  TopLevelScope(int level, int line, const char *kind, size_t index, size_t count)
      : on_(detail::g_active), level_(level) {
    if (on_)
      detail::topLevelBegin(level, line, kind, index, count);
  }
  ~TopLevelScope() {
    if (on_)
      detail::topLevelEnd(level_);
  }
  TopLevelScope(const TopLevelScope &) = delete;
  TopLevelScope &operator=(const TopLevelScope &) = delete;

private:
  bool on_;
  int level_;
};

/* ------------------------------------------------- order of growth (pure) */

// Fits cumulative work C(k) after k iterations to O(n), O(n log n),
// O(n^2), O(n^2 log n), O(n^3) and O(2^n). Exposed for the unit tests.
struct GrowthFit {
  bool ok = false;           // false: not enough data (see `reason`)
  std::string order;         // "O(n^2)" - ASCII
  std::string display;       // "O(n²)"  - for the UI
  std::string key;           // "n2" - stable identifier
  double exponent = 0;       // empirical log-log slope over the upper half
  double error = 0;          // relative RMS error of the chosen model
  std::string confidence;    // "high", "medium" or "low"
  std::string reason;        // why ok is false
  // The chosen model C(k) ~ a * g(k) + b, for progress / ETA.
  double a = 0, b = 0;
  int model = -1;
  double predict(double k) const;
};
GrowthFit fitGrowth(const double *k, const double *c, size_t n);

// Elapsed-time text, as the IDE shows it: "350 ms", "12.4 s",
// "3 min 07 s", "1 h 04 min 09 s".
std::string formatDuration(double seconds);

} // namespace nc::analysis
