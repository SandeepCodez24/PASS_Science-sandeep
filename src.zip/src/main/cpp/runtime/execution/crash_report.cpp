// runtime/execution/crash_report.cpp - see crash_report.h.

#include "crash_report.h"

#include "parallel/sys_cpu.h"

#include <atomic>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <new>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace nc::crash {

namespace {

char g_session[1024] = {0};
bool g_ide = false;
char g_command[304] = {0};
std::atomic<bool> g_reported{false};

// JSON string body: quotes, backslashes and control characters escaped.
void jsonEscape(const char *in, char *out, size_t size) {
  size_t o = 0;
  for (const char *p = in; *p && o + 7 < size; p++) {
    const unsigned char c = static_cast<unsigned char>(*p);
    if (c == '"' || c == '\\') {
      out[o++] = '\\';
      out[o++] = static_cast<char>(c);
    } else if (c < 0x20) {
      o += static_cast<size_t>(std::snprintf(out + o, size - o, "\\u%04x", c));
    } else {
      out[o++] = static_cast<char>(c);
    }
  }
  out[o] = '\0';
}

void report(const char *reason) {
  if (g_reported.exchange(true))
    return; // a second fault while reporting the first
  nc::par::sys::MemoryInfo m;
  nc::par::sys::memoryInfo(m);
  std::fprintf(stderr, "Error: nc stopped unexpectedly: %s%s%s%s\n", reason,
               g_command[0] ? " (while running: " : "", g_command, g_command[0] ? ")" : "");
  std::fflush(stderr);

  char why[512], cmd[640];
  jsonEscape(reason, why, sizeof why);
  jsonEscape(g_command, cmd, sizeof cmd);
  char json[1400];
  std::snprintf(json, sizeof json,
                "{\"reason\":\"%s\",\"command\":\"%s\",\"memory_used\":%llu,\"memory_free\":%llu,"
                "\"memory_total\":%llu}",
                why, cmd, static_cast<unsigned long long>(m.used),
                static_cast<unsigned long long>(m.available), static_cast<unsigned long long>(m.total));
  if (g_ide) {
    std::fprintf(stdout, "\x1E@FATAL %s\n", json);
    std::fflush(stdout);
  }
  if (g_session[0]) {
    char path[1100];
    std::snprintf(path, sizeof path, "%s/fatal.json", g_session);
#if defined(_WIN32)
    wchar_t wide[1100];
    if (MultiByteToWideChar(CP_UTF8, 0, path, -1, wide, 1100) > 0) {
      FILE *f = nullptr;
      if (_wfopen_s(&f, wide, L"wb") != 0)
        f = nullptr;
#else
    {
      FILE *f = std::fopen(path, "wb");
#endif
      if (f) {
        std::fputs(json, f);
        std::fclose(f);
      }
    }
  }
}

void onTerminate() {
  const char *reason = "an internal error (uncaught exception)";
  char buf[400];
  if (std::exception_ptr e = std::current_exception()) {
    try {
      std::rethrow_exception(e);
    } catch (const std::bad_alloc &x) {
      std::snprintf(buf, sizeof buf, "out of memory: %s", x.what());
      reason = buf;
    } catch (const std::exception &x) {
      std::snprintf(buf, sizeof buf, "an internal error: %s", x.what());
      reason = buf;
    } catch (...) {
    }
  }
  report(reason);
  std::_Exit(3);
}

void onSignal(int sig) {
  const char *reason = "a fatal signal";
  switch (sig) {
  case SIGSEGV:
    reason = "an invalid memory access (segmentation fault)";
    break;
  case SIGFPE:
    reason = "an arithmetic fault";
    break;
  case SIGILL:
    reason = "an illegal instruction";
    break;
  case SIGABRT:
    reason = "abort";
    break;
  default:
    break;
  }
  report(reason);
  std::_Exit(3);
}

#if defined(_WIN32)
LONG WINAPI onUnhandled(EXCEPTION_POINTERS *info) {
  const DWORD code = info && info->ExceptionRecord ? info->ExceptionRecord->ExceptionCode : 0;
  const char *reason = "a fatal Windows exception";
  char buf[96];
  switch (code) {
  case EXCEPTION_ACCESS_VIOLATION:
    reason = "an invalid memory access (access violation)";
    break;
  case EXCEPTION_STACK_OVERFLOW:
    reason = "a stack overflow (recursion too deep)";
    break;
  case EXCEPTION_INT_DIVIDE_BY_ZERO:
    reason = "an integer division by zero";
    break;
  case EXCEPTION_ILLEGAL_INSTRUCTION:
    reason = "an illegal instruction (this CPU lacks an instruction the build uses)";
    break;
  case EXCEPTION_IN_PAGE_ERROR:
    reason = "a page could not be read from disk (paging or a mapped file failed)";
    break;
  default:
    std::snprintf(buf, sizeof buf, "a fatal Windows exception 0x%08lx", static_cast<unsigned long>(code));
    reason = buf;
    break;
  }
  report(reason);
  return EXCEPTION_EXECUTE_HANDLER; // end the process (no error dialog)
}
#endif

} // namespace

void install(const std::string &sessionDir, bool ideProtocol) {
  std::snprintf(g_session, sizeof g_session, "%s", sessionDir.c_str());
  g_ide = ideProtocol;
  std::set_terminate(&onTerminate);
  std::signal(SIGSEGV, &onSignal);
  std::signal(SIGFPE, &onSignal);
  std::signal(SIGILL, &onSignal);
  std::signal(SIGABRT, &onSignal);
#if defined(_WIN32)
  SetUnhandledExceptionFilter(&onUnhandled);
#endif
}

void noteCommand(const std::string &text) {
  const size_t n = text.size() < sizeof g_command - 1 ? text.size() : sizeof g_command - 1;
  std::memcpy(g_command, text.data(), n);
  g_command[n] = '\0';
}

} // namespace nc::crash
