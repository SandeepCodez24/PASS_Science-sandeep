#pragma once
// runtime/execution/crash_report.h - nc.exe never dies without a word
// (2026-11-23, docs/Large_Data_Design.md section 2.4).
//
// Out-of-memory is an ordinary error now (memory/governor.h). What is left -
// an uncaught C++ exception (std::terminate), an access violation, a stack
// overflow the stack guard missed, abort() - ends the process, but first:
//   - "Error: nc stopped unexpectedly: <reason> (while running: <command>)"
//     on stderr,
//   - in IDE mode, one protocol line on stdout:
//       \x1E@FATAL {"reason":"...","command":"...","memory_used":...,"memory_free":...}
//   - with a session folder, the same JSON in <session>/fatal.json, which the
//     IDE reads when it sees the process gone (stdout may not get through).
// Best effort: the handlers run in a broken process; they write with plain
// C stdio, take no locks of their own, and never return into the fault.

#include <string>

namespace nc::crash {

// Installs the handlers (std::set_terminate, SIGABRT/SIGSEGV/SIGFPE/SIGILL,
// and on Windows the unhandled-exception filter). Call once, early in main.
// `sessionDir` may be empty; `ideProtocol` adds the @FATAL line.
void install(const std::string &sessionDir, bool ideProtocol);

// The command about to run (the first 300 bytes are kept), for the report.
void noteCommand(const std::string &text);

} // namespace nc::crash
