#pragma once

// Placeholder for tracking GC roots (active SymbolTable scopes, VM stack, JIT-pinned values).
