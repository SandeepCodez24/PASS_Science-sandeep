#pragma once

// Placeholder for the garbage collector.
