#pragma once

// Placeholder for a bump/arena allocator for short-lived expression temporaries.
