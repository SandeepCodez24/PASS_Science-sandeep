#include "symbol_table.h"

SymbolTable::SymbolTable()
{
    // Global scope always exists at index 0.
    variableScopes_.emplace_back();
    functionScopes_.emplace_back();
}

void SymbolTable::pushScope()
{
    variableScopes_.emplace_back();
    functionScopes_.emplace_back();
}

void SymbolTable::popScope()
{
    // Never pop the global scope.
    if (variableScopes_.size() > 1)
        variableScopes_.pop_back();

    if (functionScopes_.size() > 1)
        functionScopes_.pop_back();
}

void SymbolTable::defineVariable(const std::string &name, const Value &value)
{
    variableScopes_.back()[name] = value;
}

bool SymbolTable::lookupVariable(const std::string &name, Value &outValue) const
{
    for (auto it = variableScopes_.rbegin(); it != variableScopes_.rend(); ++it)
    {
        auto found = it->find(name);
        if (found != it->end())
        {
            outValue = found->second;
            return true;
        }
    }
    return false;
}

void SymbolTable::defineFunction(const std::string &name, const FunctionSymbol &fn)
{
    functionScopes_.back()[name] = fn;
}

bool SymbolTable::lookupFunction(const std::string &name, FunctionSymbol &outFn) const
{
    for (auto it = functionScopes_.rbegin(); it != functionScopes_.rend(); ++it)
    {
        auto found = it->find(name);
        if (found != it->end())
        {
            outFn = found->second;
            return true;
        }
    }
    return false;
}
