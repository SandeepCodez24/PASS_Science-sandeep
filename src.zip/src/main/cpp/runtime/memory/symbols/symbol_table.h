#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "../store/value.h"

// Minimal placeholder for a callable/function symbol.
// Expand once the interpreter has real function definitions (params, body, closure, etc).
struct FunctionSymbol
{
    std::string name;
    int arity = 0;
};

// Scoped dictionary of variables and functions.
// Scopes are pushed/popped as execution enters/leaves blocks, function calls, etc.
// Lookups search from the innermost scope outward.
class SymbolTable
{
public:
    SymbolTable();

    void pushScope();
    void popScope();

    void defineVariable(const std::string &name, const Value &value);
    bool lookupVariable(const std::string &name, Value &outValue) const;

    void defineFunction(const std::string &name, const FunctionSymbol &fn);
    bool lookupFunction(const std::string &name, FunctionSymbol &outFn) const;

private:
    std::vector<std::unordered_map<std::string, Value>> variableScopes_;
    std::vector<std::unordered_map<std::string, FunctionSymbol>> functionScopes_;
};
