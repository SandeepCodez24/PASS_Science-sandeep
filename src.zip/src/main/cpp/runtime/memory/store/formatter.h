#pragma once
#include <string>
#include <unordered_map>

/* SUPERSCRIPT NUMBERS */

static std::unordered_map<char,std::string> superscript =
{
    {'0',"⁰"},
    {'1',"¹"},
    {'2',"²"},
    {'3',"³"},
    {'4',"⁴"},
    {'5',"⁵"},
    {'6',"⁶"},
    {'7',"⁷"},
    {'8',"⁸"},
    {'9',"⁹"}
};

/* SYMBOL REPLACEMENTS */

static std::unordered_map<std::string,std::string> mathSymbols =
{
    {"sqrt","√"},
    {"pi","π"},
    {"sigma","σ"},
    {"alpha","α"},
    {"beta","β"},
    {"gamma","γ"},
    {"theta","θ"},
    {"lambda","λ"},
    {"mu","μ"},
    {"omega","ω"}
};

inline std::string applySymbols(std::string expr)
{
    for(auto &s : mathSymbols)
    {
        size_t pos = 0;

        while((pos = expr.find(s.first,pos)) != std::string::npos)
        {
            expr.replace(pos,s.first.length(),s.second);
            pos += s.second.length();
        }
    }

    return expr;
}

inline std::string applySuperscript(std::string expr)
{
    for(size_t i=0;i<expr.size();i++)
    {
        if(expr[i]=='^' && i+1<expr.size())
        {
            char n = expr[i+1];

            if(superscript.count(n))
            {
                expr.replace(i,2,superscript[n]);
            }
        }
    }

    return expr;
}

inline std::string formatMath(std::string expr)
{
    expr = applySymbols(expr);
    expr = applySuperscript(expr);
    return expr;
}