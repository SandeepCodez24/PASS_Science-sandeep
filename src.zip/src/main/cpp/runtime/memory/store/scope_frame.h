#pragma once

// Placeholder for a VM call-stack frame abstraction, distinct from SymbolTable's logical scoping.
