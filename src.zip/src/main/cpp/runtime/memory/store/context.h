#pragma once

#include <unordered_map>
#include <string>
#include "value.h"

class Context
{
private:

    std::unordered_map<std::string, Value> variables;

public:

    void set(const std::string& name, const Value& value);

    Value get(const std::string& name) const;
};