#pragma once

// Placeholder for a string interning table for identifiers and string literals.
