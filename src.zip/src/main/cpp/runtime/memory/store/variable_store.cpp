/* ================= VARIABLES FILE ================= */

#include "parser.h"
#include <cctype>
#include <fstream>
#include <sstream>
#include <string>

// variables.txt is an on-disk cache that can be hand-edited or left over
// from an older format; a malformed numeric field must not crash the
// interpreter (loadFromFile() runs uncaught in the Parser constructor).
static double safeStod(const std::string &s) {
  try {
    return std::stod(s);
  } catch (...) {
    return 0.0;
  }
}

// "<real> <imaginary>" -> a complex Value (see the CPLX/CARR/CMAT lines).
static Value parseComplexPair(const std::string &text) {
  std::stringstream parts(text);
  std::string re, im;
  parts >> re >> im;
  return Value::complexNumber(safeStod(re), safeStod(im));
}

void Parser::loadFromFile() {
  memory.clear();
  insertionOrder.clear();

  std::ifstream file("variables.txt");

  if (!file.is_open())
    return;

  std::string line, name, type, value;

  // Do not assume a fixed number of header lines.
  // Parse only lines that match: <name> <type> ...

  while (std::getline(file, line)) {
    if (line.empty())
      continue;
    std::stringstream ss(line);
    if (!(ss >> name >> type))
      continue;

    std::getline(ss, value);

    if (!value.empty() && value[0] == ' ')
      value = value.substr(1);
    if (type == "NUM") {
      memory[name] = Value(safeStod(value));
      insertionOrder.push_back(name);
    } else if (type == "CPLX") {
      // "<real> <imaginary>"
      std::stringstream parts(value);
      std::string re, im;
      parts >> re >> im;
      memory[name] = Value::complexNumber(safeStod(re), safeStod(im));
      insertionOrder.push_back(name);
    } else if (type == "CARR") {
      // "[re im,re im,...]" - see saveToFile().
      std::vector<Value> arr;
      if (value.size() >= 2) {
        std::stringstream items(value.substr(1, value.size() - 2));
        std::string item;
        while (std::getline(items, item, ','))
          arr.push_back(parseComplexPair(item));
      }
      memory[name] = Value(arr);
      insertionOrder.push_back(name);
    } else if (type == "CMAT") {
      // "[[re im,re im],[...]]"
      std::vector<std::vector<Value>> mat;
      size_t start = 1;
      while (value.size() >= 4 && (start = value.find('[', start)) != std::string::npos) {
        size_t end = value.find(']', start);
        if (end == std::string::npos)
          break;
        std::vector<Value> row;
        std::stringstream items(value.substr(start + 1, end - start - 1));
        std::string item;
        while (std::getline(items, item, ','))
          row.push_back(parseComplexPair(item));
        if (!row.empty())
          mat.push_back(row);
        start = end + 1;
      }
      memory[name] = Value(mat);
      insertionOrder.push_back(name);
    } else if (type == "ARR") {
      std::vector<Value> arr;

      if (value.size() < 2)
        continue;
      value = value.substr(1, value.size() - 2);

      // Elements are either a plain number or a "-quoted string (see
      // saveToFile()); split on top-level commas, respecting quotes.
      size_t idx = 0;
      while (idx < value.size()) {
        while (idx < value.size() && std::isspace((unsigned char)value[idx]))
          ++idx;
        if (idx >= value.size())
          break;

        if (value[idx] == '"') {
          size_t end = value.find('"', idx + 1);
          if (end == std::string::npos)
            break;
          arr.push_back(Value(value.substr(idx + 1, end - idx - 1)));
          idx = value.find(',', end + 1);
          idx = (idx == std::string::npos) ? value.size() : idx + 1;
          continue;
        }

        size_t comma = value.find(',', idx);
        size_t tokEnd = (comma == std::string::npos) ? value.size() : comma;
        std::string tok = value.substr(idx, tokEnd - idx);

        size_t s = 0, e = tok.size();
        while (s < e && std::isspace((unsigned char)tok[s]))
          ++s;
        while (e > s && std::isspace((unsigned char)tok[e - 1]))
          --e;
        if (e > s)
          arr.push_back(Value(safeStod(tok.substr(s, e - s))));

        idx = (comma == std::string::npos) ? value.size() : comma + 1;
      }

      memory[name] = Value(arr);
      insertionOrder.push_back(name);
    } else if (type == "MAT") {
      std::vector<std::vector<Value>> mat;

      if (value.size() < 4)
        continue;

      value = value.substr(1, value.size() - 2);

      size_t start = 0;

      while ((start = value.find('[', start)) != std::string::npos) {
        size_t end = value.find(']', start);

        if (end == std::string::npos)
          break;

        std::string rowText = value.substr(start + 1, end - start - 1);

        std::vector<Value> row;

        std::stringstream rowStream(rowText);

        std::string num;

        while (std::getline(rowStream, num, ',')) {
          if (!num.empty())
            row.push_back(Value(safeStod(num)));
        }

        if (!row.empty())
          mat.push_back(row);

        start = end + 1;
      }

      memory[name] = Value(mat);
      insertionOrder.push_back(name);
    } else if (type == "STR") {
      memory[name] = Value(value);
      insertionOrder.push_back(name);
    } else if (type == "DICT") {
      std::unordered_map<std::string, Value> dict;

      if (value.size() >= 2) {
        value = value.substr(1, value.size() - 2); // strip surrounding { }

        size_t start = 0;
        while ((start = value.find('[', start)) != std::string::npos) {
          size_t end = value.find(']', start);
          if (end == std::string::npos)
            break;

          std::string entry = value.substr(start + 1, end - start - 1);
          size_t c1 = entry.find(',');
          size_t c2 = (c1 == std::string::npos) ? std::string::npos
                                                  : entry.find(',', c1 + 1);

          if (c1 != std::string::npos && c2 != std::string::npos) {
            std::string key = entry.substr(0, c1);
            std::string vtype = entry.substr(c1 + 1, c2 - c1 - 1);
            std::string rawVal = entry.substr(c2 + 1);

            if (vtype == "S")
              dict[key] = Value(rawVal);
            else if (vtype == "C")
              dict[key] = parseComplexPair(rawVal);
            else
              dict[key] = Value(safeStod(rawVal));
          }

          start = end + 1;
        }
      }

      memory[name] = Value(dict);
      insertionOrder.push_back(name);
    }
  }
}

void Parser::saveToFile() {
  // Suppressed while executing inside a function call's local scope — its
  // locals must never be written to the persistent global variables.txt.
  if (suppressPersistence_ > 0) return;
  std::ofstream file("variables.txt");
  // Default stream precision (6 significant digits) silently truncated any
  // more-precise value on save - e.g. `p = 3.14159265358979;` round-tripped
  // back as 3.14159 after a reload, with no warning. 17 significant digits
  // is the standard "always exactly round-trips any IEEE-754 double back to
  // itself" figure - std::stod() (safeStod() above) reads it back exactly.
  file.precision(17);

  file << "NAME TYPE VALUE\n";
  file << "------------------------------\n";

  for (auto &name : insertionOrder) {
    Value v = memory[name];

    /* ================= OBJECT ================= */

    // Class instances aren't persisted in this pass — round-tripping an
    // object (className + fields, re-linked to its class's method table on
    // load) is real added complexity not needed for the class skeleton.
    // Skipping it here is deliberate, not a bug: without this, isObject
    // would fall through to the NUMBER branch below (none of
    // isArray/isMatrix/isText/isDict are true for it) and get silently
    // corrupted into "NUM 0" on the next load.
    if (v.isObject)
      continue;

    /* ================= DICT ================= */

    if (v.isDict) {
      file << name << " DICT {";

      size_t i = 0;
      for (auto &kv : v.dict()) {
        // std::to_string(double) always formats to a fixed 6 decimal
        // places, ignoring the file stream's own precision(17) above - the
        // same truncation bug as the plain NUM case, just via a different
        // code path. A small stringstream with the same precision keeps
        // this consistent with every other numeric value written here.
        std::ostringstream numStr;
        numStr.precision(17);
        numStr << kv.second.number;
        // A complex number is "C" with both parts ("re im"); everything
        // else is written exactly as before.
        const bool complexEntry = kv.second.isComplex && !kv.second.isText &&
                                  !kv.second.isArray && !kv.second.isMatrix;
        if (complexEntry)
          numStr << " " << kv.second.imag;
        file << "[" << kv.first << "," << (kv.second.isText ? "S" : complexEntry ? "C" : "N") << ","
             << (kv.second.isText ? kv.second.text() : numStr.str())
             << "]";
        if (++i < v.dict().size())
          file << ",";
      }

      file << "}\n";
      continue;
    }

    /* ================= NUMBER ================= */

    if (v.isComplex && !v.isArray && !v.isMatrix && !v.isText) {
      file << name << " CPLX " << v.number << " " << v.imag << "\n";
    } else if (!v.isArray && !v.isMatrix && !v.isText) {
      file << name << " NUM " << v.number << "\n";
    } else if (v.isArray && v.isPackedComplex()) {
      // Complex array: "re im" per element. A complex array that is not in
      // packed form (it also holds text or nested arrays) has no saved form.
      file << name << " CARR [";
      for (size_t i = 0; i < v.length(); i++) {
        std::complex<double> z = v.cnumAt(i);
        file << z.real() << " " << z.imag();
        if (i + 1 < v.length())
          file << ",";
      }
      file << "]\n";
    } else if (v.isMatrix && v.isPackedComplex()) {
      file << name << " CMAT [";
      for (size_t r = 0; r < v.rows(); r++) {
        file << "[";
        for (size_t c = 0; c < v.cols(); c++) {
          std::complex<double> z = v.cnumAt(r, c);
          file << z.real() << " " << z.imag();
          if (c + 1 < v.cols())
            file << ",";
        }
        file << "]";
        if (r + 1 < v.rows())
          file << ",";
      }
      file << "]\n";
    } else if ((v.isArray || v.isMatrix) && v.hasComplex()) {
      continue;
    } else if (v.isArray) {
      file << name << " ARR [";

      for (size_t i = 0; i < v.length(); i++) {
        if (v.at(i).isText)
          file << "\"" << v.at(i).text() << "\"";
        else
          file << v.numAt(i);

        if (i < v.length() - 1)
          file << ",";
      }

      file << "]\n";
    } else if (v.isMatrix) {
      file << name << " MAT [";

      for (size_t r = 0; r < v.rows(); r++) {
        file << "[";

        for (size_t c = 0; c < v.rowLength(r); c++) {
          file << v.numAt(r, c);

          if (c + 1 < v.rowLength(r))
            file << ",";
        }

        file << "]";

        if (r + 1 < v.rows())
          file << ",";
      }

      file << "]\n";
    } else if (v.isText) {
      file << name << " STR " << v.text() << "\n";
    }
  }
}
