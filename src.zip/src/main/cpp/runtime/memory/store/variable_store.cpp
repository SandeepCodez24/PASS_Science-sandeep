/* ================= VARIABLES FILE ================= */

#include "parser.h"
#include <cctype>
#include <fstream>
#include <sstream>
#include <string>

// variables.txt is an on-disk cache that can be hand-edited or left over
// from an older format; a malformed numeric field must not crash the
// interpreter (loadFromFile() runs uncaught in the Parser constructor).
static double safeStod(const std::string &s) {
  try {
    return std::stod(s);
  } catch (...) {
    return 0.0;
  }
}

void Parser::loadFromFile() {
  memory.clear();
  insertionOrder.clear();

  std::ifstream file("variables.txt");

  if (!file.is_open())
    return;

  std::string line, name, type, value;

  // Do not assume a fixed number of header lines.
  // Parse only lines that match: <name> <type> ...

  while (std::getline(file, line)) {
    if (line.empty())
      continue;
    std::stringstream ss(line);
    if (!(ss >> name >> type))
      continue;

    std::getline(ss, value);

    if (!value.empty() && value[0] == ' ')
      value = value.substr(1);
    if (type == "NUM") {
      memory[name] = Value(safeStod(value));
      insertionOrder.push_back(name);
    } else if (type == "ARR") {
      std::vector<Value> arr;

      if (value.size() < 2)
        continue;
      value = value.substr(1, value.size() - 2);

      // Elements are either a plain number or a "-quoted string (see
      // saveToFile()); split on top-level commas, respecting quotes.
      size_t idx = 0;
      while (idx < value.size()) {
        while (idx < value.size() && std::isspace((unsigned char)value[idx]))
          ++idx;
        if (idx >= value.size())
          break;

        if (value[idx] == '"') {
          size_t end = value.find('"', idx + 1);
          if (end == std::string::npos)
            break;
          arr.push_back(Value(value.substr(idx + 1, end - idx - 1)));
          idx = value.find(',', end + 1);
          idx = (idx == std::string::npos) ? value.size() : idx + 1;
          continue;
        }

        size_t comma = value.find(',', idx);
        size_t tokEnd = (comma == std::string::npos) ? value.size() : comma;
        std::string tok = value.substr(idx, tokEnd - idx);

        size_t s = 0, e = tok.size();
        while (s < e && std::isspace((unsigned char)tok[s]))
          ++s;
        while (e > s && std::isspace((unsigned char)tok[e - 1]))
          --e;
        if (e > s)
          arr.push_back(Value(safeStod(tok.substr(s, e - s))));

        idx = (comma == std::string::npos) ? value.size() : comma + 1;
      }

      memory[name] = Value(arr);
      insertionOrder.push_back(name);
    } else if (type == "MAT") {
      std::vector<std::vector<Value>> mat;

      if (value.size() < 4)
        continue;

      value = value.substr(1, value.size() - 2);

      size_t start = 0;

      while ((start = value.find('[', start)) != std::string::npos) {
        size_t end = value.find(']', start);

        if (end == std::string::npos)
          break;

        std::string rowText = value.substr(start + 1, end - start - 1);

        std::vector<Value> row;

        std::stringstream rowStream(rowText);

        std::string num;

        while (std::getline(rowStream, num, ',')) {
          if (!num.empty())
            row.push_back(Value(safeStod(num)));
        }

        if (!row.empty())
          mat.push_back(row);

        start = end + 1;
      }

      memory[name] = Value(mat);
      insertionOrder.push_back(name);
    } else if (type == "STR") {
      memory[name] = Value(value);
      insertionOrder.push_back(name);
    } else if (type == "DICT") {
      std::unordered_map<std::string, Value> dict;

      if (value.size() >= 2) {
        value = value.substr(1, value.size() - 2); // strip surrounding { }

        size_t start = 0;
        while ((start = value.find('[', start)) != std::string::npos) {
          size_t end = value.find(']', start);
          if (end == std::string::npos)
            break;

          std::string entry = value.substr(start + 1, end - start - 1);
          size_t c1 = entry.find(',');
          size_t c2 = (c1 == std::string::npos) ? std::string::npos
                                                  : entry.find(',', c1 + 1);

          if (c1 != std::string::npos && c2 != std::string::npos) {
            std::string key = entry.substr(0, c1);
            std::string vtype = entry.substr(c1 + 1, c2 - c1 - 1);
            std::string rawVal = entry.substr(c2 + 1);

            if (vtype == "S")
              dict[key] = Value(rawVal);
            else
              dict[key] = Value(safeStod(rawVal));
          }

          start = end + 1;
        }
      }

      memory[name] = Value(dict);
      insertionOrder.push_back(name);
    }
  }
}

void Parser::saveToFile() {
  if (inForBlock_ || inWhileBlock_) return;
  // Suppressed while executing inside a function call's local scope — its
  // locals must never be written to the persistent global variables.txt.
  if (suppressPersistence_ > 0) return;
  std::ofstream file("variables.txt");

  file << "NAME TYPE VALUE\n";
  file << "------------------------------\n";

  for (auto &name : insertionOrder) {
    Value v = memory[name];

    /* ================= OBJECT ================= */

    // Class instances aren't persisted in this pass — round-tripping an
    // object (className + fields, re-linked to its class's method table on
    // load) is real added complexity not needed for the class skeleton.
    // Skipping it here is deliberate, not a bug: without this, isObject
    // would fall through to the NUMBER branch below (none of
    // isArray/isMatrix/isText/isDict are true for it) and get silently
    // corrupted into "NUM 0" on the next load.
    if (v.isObject)
      continue;

    /* ================= DICT ================= */

    if (v.isDict) {
      file << name << " DICT {";

      size_t i = 0;
      for (auto &kv : v.dictMap) {
        file << "[" << kv.first << "," << (kv.second.isText ? "S" : "N") << ","
             << (kv.second.isText ? kv.second.text : std::to_string(kv.second.number))
             << "]";
        if (++i < v.dictMap.size())
          file << ",";
      }

      file << "}\n";
      continue;
    }

    /* ================= NUMBER ================= */

    if (!v.isArray && !v.isMatrix && !v.isText) {
      file << name << " NUM " << v.number << "\n";
    } else if (v.isArray) {
      file << name << " ARR [";

      for (size_t i = 0; i < v.array.size(); i++) {
        if (v.array[i].isText)
          file << "\"" << v.array[i].text << "\"";
        else
          file << v.array[i].number;

        if (i < v.array.size() - 1)
          file << ",";
      }

      file << "]\n";
    } else if (v.isMatrix) {
      file << name << " MAT [";

      for (size_t r = 0; r < v.matrix.size(); r++) {
        file << "[";

        for (size_t c = 0; c < v.matrix[r].size(); c++) {
          file << v.matrix[r][c].number;

          if (c + 1 < v.matrix[r].size())
            file << ",";
        }

        file << "]";

        if (r + 1 < v.matrix.size())
          file << ",";
      }

      file << "]\n";
    } else if (v.isText) {
      file << name << " STR " << v.text << "\n";
    }
  }
}
