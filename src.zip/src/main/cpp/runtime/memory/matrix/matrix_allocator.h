#pragma once

// Placeholder for a dedicated flat-buffer allocator for matrix data.
