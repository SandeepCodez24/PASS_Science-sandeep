# `.ndat` — Neural Code workspace file, version 1.1

`.ndat` is the binary file that `save_workspace()` writes and `load_workspace()`
reads. It stores the global workspace: every variable's name and its value. Values
are stored exactly. Nothing is converted to text, and nothing is rounded.

The code that writes the format is `runtime/data/DataSupport/NdatWriter.cpp`, and the
code that reads it is `NdatReader.cpp`. The constants are in `NdatTypes.h`, which is
the source of truth if it ever disagrees with this page.

## Language side

```
save_workspace()                  % -> <current folder>/workspace.ndat
save_workspace("run1")            % -> <current folder>/run1.ndat  (.ndat added)
save_workspace("D:/data/run1.ndat")
load_workspace()                  % <- <current folder>/workspace.ndat
load_workspace("run1")
```

- The current folder is the IDE's current folder (`@cmd setpwd`).
- A relative path is resolved against the current folder. If the name has no
  extension, `.ndat` is added. Paths are UTF-8.
- Both calls act on the **global** workspace, even when they are called inside a
  function.
- `load_workspace` **merges**. Variables in the file replace variables with the same
  name. Variables that are only in the workspace are kept.
- Each call prints one line, such as `Saved 3 variables to D:\proj\workspace.ndat`,
  and evaluates to `true`.
- On failure, each call prints `Error: ...`, the statement fails, and nothing is
  changed. For `load_workspace`, the whole file is checked before any variable is
  touched.

## Layout

All integers are little-endian. `f64` is an IEEE-754 binary64 value, stored as its
8 bytes in little-endian order.

```
file    := header record* footer
header  := "NDAT"              4 bytes
           u16 major = 1       a reader rejects any other major version
           u16 minor = 1       a reader accepts any minor version of its major
                               (1.1 added N-dimensional matrices)
           u8  endian = 1      1 = little-endian (the only value defined)
           u8  flags = 0       none defined in 1.0
           u16 reserved = 0
           u32 varCount
           u64 createdUnixMs
           8 bytes reserved = 0                        (32 bytes in total)
record  := u32 nameLen, nameLen bytes of UTF-8 name, node
footer  := "NEND", u32 crc32
```

`crc32` is the CRC-32 (IEEE 802.3 / zlib) of every byte in the file before it,
including `NEND`. The reader checks it before it decodes anything.

To write a file, the writer first writes a temporary file (`<name>.ndat.tmp`) next
to the target, then renames it into place. A failed save never leaves a
half-written workspace file.

### Value node

```
node := u8 tag, u8 flags, [i16 L, i16 T, i16 M if flags & 0x01], payload
```

Flag `0x01` (HAS_UNITS) means the value has a physical unit. `L`, `T` and `M` are
the exponents of length, time and mass. For example, m/s² is `1, -2, 0`. Any other
flag bit means the file came from a newer version, and the reader rejects it.

| tag | type | payload |
|---|---|---|
| `0x01` | bool | `u8` 0 or 1 |
| `0x10`–`0x13` | int8, int16, int32, int64 | 1, 2, 4 or 8 bytes, two's complement |
| `0x14`, `0x15` | int128, int256 | *reserved, not yet written* |
| `0x18`–`0x1B` | uint8, uint16, uint32, uint64 | 1, 2, 4 or 8 bytes |
| `0x1C`, `0x1D` | uint128, uint256 | *reserved* |
| `0x20` | float8 (OCP FP8 E4M3: 1 sign, 4 exponent bits with bias 7, 3 mantissa bits; no infinity; `S.1111.111` is NaN; max 448) | 1 byte |
| `0x21` | float16 (IEEE 754 binary16) | `u16` bit pattern |
| `0x22` | float32 (IEEE 754 binary32) | `u32` bit pattern |
| `0x23` | float64 (the default number) | `f64` |
| `0x24`, `0x25` | float128, float256 | *reserved* |
| `0x28` | complex128 | `f64` real, `f64` imaginary |
| `0x30` | UTF-8 text | `u64` byte length, bytes |
| `0x40` | numeric tensor (packed vector, matrix or N-D matrix) | see below |
| `0x41` | cell array (vector of any values) | `u64 n`, n nodes |
| `0x42` | cell matrix (rows of any values) | `u64 rows`, then per row: `u64 len`, len nodes (rows may differ in length) |
| `0x43` | N-D cell matrix (since 1.1) | `u8 rank` (3..32), `u64 dim[rank]`, then one node per element in N-D storage order (see below) |
| `0x50` | dict | `u64 n`, n × (`u32` keyLen, key bytes, node), keys in byte order |
| `0x51` | object (class instance) | see below |
| `0x52` | function reference `@name` | `u32` len, name bytes |
| `0x60` | timestamp (since 1.2) | `i64` nanoseconds since 1970-01-01 00:00:00 UTC (never carries units) |
| `0x61` | duration (since 1.2) | `i64` nanoseconds, may be negative (never carries units) |

**Timestamps and durations (`0x60`, `0x61`).** Stored exactly as the runtime
holds them (runtime/interpreter/ops/time/time.h), so they round-trip to the
nanosecond with their type. A timestamp is always UTC - the time zone is only a
question of display. A matrix of them is a cell array / cell matrix of these
nodes. A 1.0 or 1.1 reader refuses such a file and names the unknown tag.

**Numeric tensor (`0x40`).** This tag is used for vectors and matrices whose
elements are all plain float64 or complex numbers with one shared unit. Bools,
integers, float8/16/32 numbers, text and mixed units go in a cell array or cell
matrix instead.

```
u8  elemTag          0x23 float64 or 0x28 complex128
i16 L, T, M          the unit every element shares (all 0 = unitless)
u8  rank             1 = vector, 2 = matrix, 3..32 = N-D matrix (since 1.1)
u64 dim[rank]        length; rows then cols; or d0, ..., rows, cols
data                 column-major; one f64 per element, or re,im per complex element
```

**N-D storage order (rank 3 and up).** An N-D matrix of shape
`[d0, ..., d(n-3), rows, cols]` is a run of 2-D pages. Each page is one
`rows x cols` matrix, column-major like a rank-2 tensor. The pages follow each
other in row-major order of the leading indices (the last leading index varies
fastest), so the page `B[i,j,:,:]` of a 4-D matrix is page number
`i*d1 + j`. This is the interpreter's own memory layout, so the data is still
one bulk copy, and every page can be handed to Eigen and LAPACK as it is.
A 1.0 reader refuses rank 3 and above with "unsupported tensor rank".

An N-D matrix whose elements are not all plain float64/complex numbers with one
unit (text, bools, integers, float8/16/32) is stored as an N-D cell matrix
(`0x43`), with its elements in the same storage order.

The data is the interpreter's own memory layout. It is written and read as one block
of bytes, and the layout matches Eigen and LAPACK. An empty vector or matrix is
stored as an empty cell array or cell matrix.

**Object (`0x51`).**

```
u32 len, class name
u64 n, n × (u32 keyLen, key, node)       fields, sorted by name
u64 n, n × (u32 len, text)               lineage (.lineage() history)
u64 n, n × field map (same shape as fields)   reversible snapshots (.rewind())
f64 lastTickTime                          -1 = never ticked (@rate classes)
```

The class definition is not stored, only the instance. A loaded object works fully
once its class is defined again, for example after running the script that
declares it.

## Determinism

Equal values always encode to the same bytes, because dict keys and object fields
are written sorted. The IDE channel relies on this. It detects changed variables by
the FNV-1a hash of each variable's node bytes, which it computes without building
the bytes.

## Versioning rules

- A new type gets a new tag. Existing tags never change their meaning.
- A change that an older 1.x reader can safely ignore bumps `minor`. Readers accept
  any minor version of their major.
- Anything else bumps `major`. A reader refuses a major version it does not know,
  and says why.
- A reader that meets a tag it cannot hold refuses the whole file and names the
  tag. For example, an int128 value is refused until the runtime supports it. It
  never loads a partial workspace.

## Reading untrusted files

Every length is checked against the bytes actually left in the file before
anything is allocated. Nesting depth is capped at 256, and the CRC is verified
first. A corrupt or truncated file produces a clear error, and the workspace is not
changed.

## Session autosave

When the IDE launches `nc.exe` with `NC_SESSION_DIR`, the interpreter also writes
`<NC_SESSION_DIR>/autosave.ndat` whenever the workspace has changed by the time a
prompt is printed. It uses the same format. If the IDE ever has to restart the
interpreter, it starts the new one with `NC_RESTORE=1`, which loads that file
before the first prompt. See `WS_PROTOCOL.md`.

# Version 2 — the NC data bundle (`save` / `load` / `read`)

`save(file, data)` and `save(file)` (the whole workspace) write version 2. Version 1
stays what `save_workspace()` and the session autosave write; every reader of this
build (`read`, `load`, `load_workspace`, `ndat_info`) takes both versions.

A version 2 file is a set of named **entries**. Each entry is a **section** of
bytes in the encoding that suits its data, chosen when the file is written
(`interpreter/Numpy/importing_data/io_ndat.cpp`):

| encoding | used for (policy `auto`) | section bytes |
|---|---|---|
| `0` native | everything not below: small data, text, dicts, objects, units, integer types, complex, timestamps, noise-like tensors | one value node (as in version 1) |
| `1` hdf5 | real float64 matrix / N-D matrix of 32768 values or more that gzip at least halves (a 128 KiB sample is compressed first) | a complete HDF5 file, dataset `/data`, chunked, byte-shuffled, gzip 4 |
| `2` parquet | table of 4096 cells or more with text or bool columns | a complete Parquet file, dictionary encoding + zstd |
| `3` arrow | table of 4096 cells or more, all columns numeric | a complete Arrow IPC (Feather v2) file, uncompressed |

A *table* is a table object (`NcTable`, `load_csv`'s object - any object with
`cols` and `data`), a dict of equal-length columns that are each all numbers, all
text or all bools, or a cell matrix with such columns (what `read_csv` gives),
optionally under a row of text headers.

Before the file is written, every hdf5 / parquet / arrow section is checked to give
back exactly the original value (compared by the value-node fingerprint of
"Determinism" above); an entry that would not is stored native, with the reason in
its meta `note`. A tensor qualifies for hdf5 only in packed real float64 form
without a unit, which is exact by construction.

Policies (`save(file, data, policy="auto")`): `auto` (above), `compact` (tensors of 4096
values that gzip shrinks at all, gzip 9; tables of 256 cells, all Parquet zstd 9),
`fast` (tensors native, tables Arrow), `native` (everything native), and `hdf5` /
`parquet` / `arrow` (that encoding for every entry that can hold it).

## Layout

```
file     := header section* toc footer
header   := "NDAT"            4 bytes
            u16 major = 2
            u16 minor = 0
            u8  endian = 1
            u8  flags = 0
            u16 reserved = 0
            u32 entryCount
            u64 createdUnixMs
            u8  root          0 = one value (entry "data"), 1 = dict (an entry per key),
                              2 = workspace (an entry per variable, in order)
            7 bytes reserved = 0                       (32 bytes in total)
section  := the entry's bytes, in table-of-contents order
toc      := "NTOC", then per entry:
            u32 nameLen, name (UTF-8)
            u8  encoding      0 native, 1 hdf5, 2 parquet, 3 arrow
            u64 offset        from the start of the file
            u64 length
            u32 crc32         of the section's bytes
            node meta         a dict: kind ("value", "tensor", "nctable", "columns",
                              "cells"), shape / rows / cols, codec, how to rebuild the
                              value (column orientation, header row, the object's class
                              and its extra fields), note
footer   := u64 tocOffset, u64 tocLength, "NEND",
            u32 crc32 of the header and the table of contents
```

A reader reads the 32-byte header and the 24-byte footer, then the table of
contents, and checks their CRC. It reads a section only when that entry is asked
for, and checks the section's own CRC first. So `read(file, "A")` never reads the
other entries, and `read(file, "A", "1:10, :")` reads only the HDF5 chunks needed.
A hdf5 / parquet / arrow section is a complete file of its format:
`ndat_export(file, name, "x.h5")` copies it out unchanged.

The writer writes `<name>.ndat.tmp` and renames it into place, as in version 1.

## Language side

```
save("run1", D)                 % run1.ndat; a dict: one entry per key (unless it is one table)
save("run1", D, "compact")      % a storage policy
save("run1")                    % the whole workspace
x = read("run1")                % the value back (a dict of the entries for dict / workspace files)
A = read("run1", "A")           % one entry
P = read("run1", "A", "1:10, :")  % part: a slice (1-based, inclusive) ...
C = read("run1", "T", ["x"])    % ... or columns of a table
D = load("run1")                % an NcData object: D.A, D.T, ... and D.ndat (ndat_info)
i = ndat_info("run1")           % version, root, and per entry encoding, kind, shape, bytes
ndat_export("run1", "A", "A.h5")
load_workspace("run1")          % merges the entries into the workspace
```

`save`, `load` and `read` take `.ndat` files only (a name without an extension
means `.ndat`). Every other format has its own functions - `save_csv`, `read_h5`,
`load_parquet`, ... - and `save("t.csv", T)` is refused with "for a .csv file use
save_csv(...)". The options can be named: `save("run1", D, policy="compact")`,
`read("run1", name="A", part="1:10, :")`.
