#include "DataEngine.h"

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <system_error>

#include "DataSupport/BinaryIO.h"
#include "../interpreter/Numpy/importing_data/io_ndat.h"
#include "DataSupport/JsonWriter.h"
#include "DataSupport/NdatBundle.h"
#include "DataSupport/NdatReader.h"
#include "DataSupport/NdatWriter.h"
#include "DataSupport/ValueJson.h"
#include "identifier_rules.h"

namespace ncdata {

namespace {

// Starts every protocol line (ASCII Record Separator). Scripts do not
// print it, so the IDE can split protocol lines from program output
// without guessing.
constexpr char kProtocolMark = '\x1E';

constexpr int kProtocolVersion = 1;

// Most elements one @VAR line carries before the data is left out.
constexpr std::size_t kVarElementBudget = 2000000;

const char *kAutosaveName = "autosave.ndat";

std::string plural(std::size_t n, const char *word) {
  return std::to_string(n) + " " + word + (n == 1 ? "" : "s");
}

void sendProtocolLine(const char *kind, const std::string &json) {
  std::cout << kProtocolMark << kind << ' ' << json << '\n' << std::flush;
}

// An environment variable, or "" when it is not set. _dupenv_s where the
// C runtime is Microsoft's (clang targeting *-windows-msvc defines _MSC_VER
// too): there std::getenv is flagged as deprecated/unsafe.
std::string environmentVariable(const char *name) {
#ifdef _MSC_VER
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, name) != 0 || buffer == nullptr)
    return std::string();
  std::string value(buffer);
  std::free(buffer);
  return value;
#else
  const char *value = std::getenv(name);
  return value ? std::string(value) : std::string();
#endif
}

// Every name in a .ndat file must be a name the lexer would accept. The
// file is outside the language's control (hand-edited, from another
// machine, damaged), and a name the lexer could never produce -- "A₁", a
// zero-width joiner, a Greek capital A -- would let one variable look like
// another in the Variable Explorer. Returns false and fills `message` on the
// first bad name.
bool namesAreValid(const NamedValues &loaded, const char *what, std::string &message) {
  for (const auto &nv : loaded) {
    std::string why;
    if (!ncident::validateName(nv.first, why)) {
      message = std::string(what) + ": the file holds the variable name '" + nv.first +
                "', which is not a valid name (" + why + "); nothing was loaded";
      return false;
    }
  }
  return true;
}

std::filesystem::path pathFromUtf8(const std::string &s) {
  // u8path: the file name is UTF-8 on every platform (Windows included).
  return std::filesystem::u8path(s);
}

} // namespace

DataEngine &DataEngine::instance() {
  static DataEngine engine;
  return engine;
}

DataEngine::DataEngine() {
  std::error_code ec;
  currentFolder_ = std::filesystem::current_path(ec);
}

bool DataEngine::isWorkspaceCommand(const std::string &name) {
  return name == "save_workspace" || name == "load_workspace";
}

/* ================= configuration ================= */

void DataEngine::configureFromEnvironment() {
  const std::string dir = environmentVariable("NC_SESSION_DIR");
  if (dir.empty())
    return;
  sessionDir_ = pathFromUtf8(dir);
  std::error_code ec;
  std::filesystem::create_directories(sessionDir_, ec);
}

void DataEngine::setCurrentFolder(const std::filesystem::path &folder) {
  if (!folder.empty())
    currentFolder_ = folder;
}

std::filesystem::path DataEngine::resolveUserPath(const std::string &userPath) const {
  std::filesystem::path p = userPath.empty() ? std::filesystem::path("workspace.ndat")
                                             : pathFromUtf8(userPath);
  if (!p.has_extension())
    p += ".ndat";
  if (p.is_relative())
    p = currentFolder_ / p;
  return p.lexically_normal();
}

/* ================= persistent storage ================= */

WorkspaceIoResult DataEngine::saveWorkspace(const Workspace &vars, const WorkspaceOrder &order,
                                            const std::string &userPath) {
  WorkspaceIoResult result;
  result.path = resolveUserPath(userPath);

  std::vector<NamedValueRef> refs;
  for (const Entry &e : snapshot(vars, order))
    refs.push_back({e.name, e.value});

  std::string err;
  if (!writeNdatFile(result.path, refs, err)) {
    result.message = "save_workspace: " + err;
    return result;
  }
  result.ok = true;
  result.count = refs.size();
  result.message = "Saved " + plural(refs.size(), "variable") + " to " + result.path.u8string();
  return result;
}

WorkspaceIoResult DataEngine::loadWorkspace(const std::string &userPath, Workspace &vars,
                                            WorkspaceOrder &order) {
  WorkspaceIoResult result;
  result.path = resolveUserPath(userPath);

  NamedValues loaded;
  std::string err;
  // Version 2 files (bundles written by save()) hold their entries in
  // sections of different encodings: io_ndat.cpp decodes them.
  const bool ok = bundle::ndatMajorVersion(result.path) == bundle::kMajor
                      ? nc::io::readNdatEntries(result.path, loaded, err)
                      : readNdatFile(result.path, loaded, err);
  if (!ok) {
    result.message = "load_workspace: " + err;
    return result;
  }
  // All or nothing: a file with one bad name loads no variable at all.
  if (!namesAreValid(loaded, "load_workspace", result.message))
    return result;
  for (auto &nv : loaded) {
    if (!vars.count(nv.first))
      order.push_back(nv.first);
    vars[nv.first] = std::move(nv.second);
  }
  result.ok = true;
  result.count = loaded.size();
  result.message = "Loaded " + plural(loaded.size(), "variable") + " from " + result.path.u8string();
  return result;
}

std::size_t DataEngine::restoreSessionIfRequested(Workspace &vars, WorkspaceOrder &order) {
  if (!ideMode() || environmentVariable("NC_RESTORE") != "1")
    return 0;
  const std::filesystem::path file = sessionDir_ / kAutosaveName;
  std::error_code ec;
  if (!std::filesystem::is_regular_file(file, ec))
    return 0;
  NamedValues loaded;
  std::string err;
  if (!readNdatFile(file, loaded, err)) {
    std::cerr << "Warning: could not restore the previous workspace: " << err << "\n";
    return 0;
  }
  std::string bad;
  if (!namesAreValid(loaded, "restore", bad)) {
    std::cerr << "Warning: could not restore the previous workspace: " << bad << "\n";
    return 0;
  }
  for (auto &nv : loaded) {
    if (!vars.count(nv.first))
      order.push_back(nv.first);
    vars[nv.first] = std::move(nv.second);
  }
  return loaded.size();
}

/* ================= runtime channel ================= */

std::vector<DataEngine::Entry> DataEngine::snapshot(const Workspace &vars,
                                                    const WorkspaceOrder &order) const {
  std::vector<Entry> entries;
  entries.reserve(vars.size());
  std::unordered_map<std::string, bool> seen;
  seen.reserve(vars.size());
  for (const std::string &name : order) {
    auto it = vars.find(name);
    if (it == vars.end() || seen.count(name))
      continue;
    seen[name] = true;
    entries.push_back({&it->first, &it->second, 0});
  }
  // Defensive: a variable `order` does not list still belongs on screen.
  std::vector<const std::string *> stray;
  for (const auto &kv : vars)
    if (!seen.count(kv.first))
      stray.push_back(&kv.first);
  std::sort(stray.begin(), stray.end(), [](const auto *a, const auto *b) { return *a < *b; });
  for (const std::string *name : stray)
    entries.push_back({name, &vars.at(*name), 0});

  for (Entry &e : entries)
    e.hash = valueFingerprint(*e.value);
  return entries;
}

uint64_t DataEngine::signatureOf(const std::vector<Entry> &entries) {
  HashSink sink;
  sink.u64(entries.size());
  for (const Entry &e : entries) {
    sink.u32(static_cast<uint32_t>(e.name->size()));
    sink.bytes(*e.name);
    sink.u64(e.hash);
  }
  return sink.hash.value();
}

void DataEngine::writeAutosave(const std::vector<Entry> &entries) {
  std::vector<NamedValueRef> refs;
  refs.reserve(entries.size());
  for (const Entry &e : entries)
    refs.push_back({e.name, e.value});
  std::string err;
  // A failed autosave only weakens crash recovery; it must never disturb
  // the user's session, so it is silent.
  writeNdatFile(sessionDir_ / kAutosaveName, refs, err);
}

void DataEngine::emitWorkspaceIfChanged(const Workspace &vars, const WorkspaceOrder &order,
                                        bool force) {
  if (!ideMode() && !force)
    return;

  const std::vector<Entry> entries = snapshot(vars, order);
  const uint64_t signature = signatureOf(entries);

  if (force || !haveSentWorkspace_ || signature != lastSentSignature_) {
    JsonWriter json;
    json.beginObject();
    json.key("v").integer(kProtocolVersion);
    json.key("type").string("ws");
    json.key("vars").beginArray();
    for (const Entry &e : entries)
      writeSummaryJson(json, summarizeVariable(*e.name, *e.value, e.hash));
    json.endArray();
    json.endObject();
    sendProtocolLine("@WS", json.str());
    haveSentWorkspace_ = true;
    lastSentSignature_ = signature;
  }

  if (ideMode() && (!haveAutosaved_ || signature != lastAutosaveSignature_)) {
    writeAutosave(entries);
    haveAutosaved_ = true;
    lastAutosaveSignature_ = signature;
  }
}

void DataEngine::emitVariable(const std::string &name, const Workspace &vars) {
  JsonWriter json;
  json.beginObject();
  json.key("v").integer(kProtocolVersion);
  json.key("type").string("var");
  json.key("name").string(name);
  auto it = vars.find(name);
  json.key("found").boolean(it != vars.end());
  if (it != vars.end()) {
    VariableSummary s = summarizeVariable(name, it->second, valueFingerprint(it->second));
    json.key("class").string(s.cls);
    json.key("size").string(s.size);
    std::size_t budget = kVarElementBudget;
    json.key("value");
    writeValueJson(json, it->second, budget);
  }
  json.endObject();
  sendProtocolLine("@VAR", json.str());
}

} // namespace ncdata
