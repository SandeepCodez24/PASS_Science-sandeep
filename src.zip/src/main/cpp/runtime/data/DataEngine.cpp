#include "DataEngine.h"

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <system_error>

#include "DataSupport/BinaryIO.h"
#include "../interpreter/Numpy/importing_data/io_ndat.h"
#include "DataSupport/JsonWriter.h"
#include "DataSupport/NdatBundle.h"
#include "DataSupport/NdatReader.h"
#include "DataSupport/NdatWriter.h"
#include "DataSupport/ValueJson.h"
#include "identifier_rules.h"
#include "../interpreter/ops/collections/nullset_builtin.h"
#include "../memory/governor.h"

#include <cstdio>
#include <fstream>
#include <stdexcept>

namespace ncdata {

namespace {

// Starts every protocol line (ASCII Record Separator). Scripts do not
// print it, so the IDE can split protocol lines from program output
// without guessing.
constexpr char kProtocolMark = '\x1E';

constexpr int kProtocolVersion = 1;

// Most elements one @VAR line carries before the data is left out.
constexpr std::size_t kVarElementBudget = 2000000;

const char *kAutosaveName = "autosave.ndat";
// Names and sizes of the variables left out of the autosave (decision D6).
const char *kAutosaveSkippedName = "autosave_skipped.txt";

// The bytes a value's data takes when stored (2026-11-23): a lazy rule
// costs nothing, a packed / typed buffer its size, a matrix of general
// values about 32 bytes per element. 0 for anything small or unknown.
uint64_t storedBytes(const Value &v) {
  if (const NumTensor *lazy = v.lazyTensor()) // a portable rule is written as the rule
    return lazy->portableRule() ? 64 : static_cast<uint64_t>(v.packedSize()) * 8u;
  if (v.isTypedPacked())
    return static_cast<uint64_t>(v.tensorCount()) * elemTypeBytes(v.elemType());
  if (v.isPacked() || v.isPackedComplex())
    return static_cast<uint64_t>(v.packedSize()) * 8u;
  if (v.isArray)
    return static_cast<uint64_t>(v.length()) * 32u;
  if (v.isMatrix && v.rows() > 0)
    return static_cast<uint64_t>(v.rows()) * v.cols() * 32u;
  return 0;
}

std::string plural(std::size_t n, const char *word) {
  return std::to_string(n) + " " + word + (n == 1 ? "" : "s");
}

void sendProtocolLine(const char *kind, const std::string &json) {
  std::cout << kProtocolMark << kind << ' ' << json << '\n' << std::flush;
}

// An environment variable, or "" when it is not set. _dupenv_s where the
// C runtime is Microsoft's (clang targeting *-windows-msvc defines _MSC_VER
// too): there std::getenv is flagged as deprecated/unsafe.
std::string environmentVariable(const char *name) {
#ifdef _MSC_VER
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, name) != 0 || buffer == nullptr)
    return std::string();
  std::string value(buffer);
  std::free(buffer);
  return value;
#else
  const char *value = std::getenv(name);
  return value ? std::string(value) : std::string();
#endif
}

// Every name in a .ndat file must be a name the lexer would accept. The
// file is outside the language's control (hand-edited, from another
// machine, damaged), and a name the lexer could never produce -- "A₁", a
// zero-width joiner, a Greek capital A -- would let one variable look like
// another in the Variable Explorer. Returns false and fills `message` on the
// first bad name.
bool namesAreValid(const NamedValues &loaded, const char *what, std::string &message) {
  for (const auto &nv : loaded) {
    std::string why;
    if (!ncident::validateName(nv.first, why)) {
      message = std::string(what) + ": the file holds the variable name '" + nv.first +
                "', which is not a valid name (" + why + "); nothing was loaded";
      return false;
    }
  }
  return true;
}

std::filesystem::path pathFromUtf8(const std::string &s) {
  // u8path: the file name is UTF-8 on every platform (Windows included).
  return std::filesystem::u8path(s);
}

} // namespace

DataEngine &DataEngine::instance() {
  static DataEngine engine;
  return engine;
}

DataEngine::DataEngine() {
  std::error_code ec;
  currentFolder_ = std::filesystem::current_path(ec);
}

// Writes what is still queued, then ends the autosave thread: a normal exit
// always leaves the autosave of the last prompt behind.
DataEngine::~DataEngine() {
  {
    std::lock_guard<std::mutex> lock(autosaveMutex_);
    autosaveStop_ = true;
  }
  autosaveWake_.notify_all();
  if (autosaveThread_.joinable())
    autosaveThread_.join();
}

void DataEngine::finishAutosave() {
  std::unique_lock<std::mutex> lock(autosaveMutex_);
  autosaveIdle_.wait(lock, [&] { return !autosaveQueued_ && !autosaveWriting_; });
}

void DataEngine::autosaveLoop() {
  std::unique_lock<std::mutex> lock(autosaveMutex_);
  for (;;) {
    autosaveWake_.wait(lock, [&] { return autosaveQueued_ || autosaveStop_; });
    if (!autosaveQueued_)
      return; // stop, nothing left to write
    std::unique_ptr<AutosaveJob> job = std::move(autosaveQueued_);
    autosaveWriting_ = true;
    lock.unlock();

    std::vector<NamedValueRef> refs;
    refs.reserve(job->vars.size());
    for (const auto &var : job->vars)
      refs.push_back({&var.first, &var.second});
    std::string err;
    // A failed autosave only weakens crash recovery; it must never disturb
    // the user's session, so it is silent - a failed allocation included
    // (an exception leaving this thread would end nc.exe).
    // Lazy ranges as their rule: the autosave is this interpreter's own file
    // (TAG_NUM_RANGE, 2026-11-21) - [-pi:1e-8:pi] is 40 bytes, not 5 GB.
    try {
      writeNdatFile(sessionDir_ / kAutosaveName, refs, err, /*sessionNodes=*/true);
      std::error_code ec;
      const std::filesystem::path skippedFile = sessionDir_ / kAutosaveSkippedName;
      if (job->skipped.empty()) {
        std::filesystem::remove(skippedFile, ec);
      } else {
        std::ofstream out(skippedFile, std::ios::binary | std::ios::trunc);
        for (const auto &s : job->skipped)
          out << s.first << '\t' << s.second << '\n';
      }
    } catch (const std::exception &) {
    }
    job.reset(); // drop the snapshot (and its share of the buffers) here

    lock.lock();
    autosaveWriting_ = false;
    if (!autosaveQueued_)
      autosaveIdle_.notify_all();
  }
}

bool DataEngine::isWorkspaceCommand(const std::string &name) {
  return name == "save_workspace" || name == "load_workspace";
}

/* ================= configuration ================= */

void DataEngine::configureFromEnvironment() {
  const std::string dir = environmentVariable("NC_SESSION_DIR");
  if (dir.empty())
    return;
  sessionDir_ = pathFromUtf8(dir);
  std::error_code ec;
  std::filesystem::create_directories(sessionDir_, ec);
}

void DataEngine::setCurrentFolder(const std::filesystem::path &folder) {
  if (!folder.empty())
    currentFolder_ = folder;
}

std::filesystem::path DataEngine::resolveUserPath(const std::string &userPath) const {
  std::filesystem::path p = userPath.empty() ? std::filesystem::path("workspace.ndat")
                                             : pathFromUtf8(userPath);
  if (!p.has_extension())
    p += ".ndat";
  if (p.is_relative())
    p = currentFolder_ / p;
  return p.lexically_normal();
}

/* ================= persistent storage ================= */

WorkspaceIoResult DataEngine::saveWorkspace(const Workspace &vars, const WorkspaceOrder &order,
                                            const std::string &userPath) {
  WorkspaceIoResult result;
  result.path = resolveUserPath(userPath);

  std::vector<NamedValueRef> refs;
  for (const Entry &e : snapshot(vars, order))
    refs.push_back({e.name, e.value});

  std::string err;
  if (!writeNdatFile(result.path, refs, err)) {
    result.message = "save_workspace: " + err;
    return result;
  }
  result.ok = true;
  result.count = refs.size();
  result.message = "Saved " + plural(refs.size(), "variable") + " to " + result.path.u8string();
  return result;
}

WorkspaceIoResult DataEngine::loadWorkspace(const std::string &userPath, Workspace &vars,
                                            WorkspaceOrder &order) {
  WorkspaceIoResult result;
  result.path = resolveUserPath(userPath);

  NamedValues loaded;
  std::string err;
  // Version 2 files (bundles written by save()) hold their entries in
  // sections of different encodings: io_ndat.cpp decodes them.
  const bool ok = bundle::ndatMajorVersion(result.path) == bundle::kMajor
                      ? nc::io::readNdatEntries(result.path, loaded, err)
                      : readNdatFile(result.path, loaded, err);
  if (!ok) {
    result.message = "load_workspace: " + err;
    return result;
  }
  // All or nothing: a file with one bad name loads no variable at all.
  if (!namesAreValid(loaded, "load_workspace", result.message))
    return result;
  for (auto &nv : loaded) {
    if (!vars.count(nv.first))
      order.push_back(nv.first);
    vars[nv.first] = std::move(nv.second);
  }
  result.ok = true;
  result.count = loaded.size();
  result.message = "Loaded " + plural(loaded.size(), "variable") + " from " + result.path.u8string();
  return result;
}

std::size_t DataEngine::restoreSessionIfRequested(Workspace &vars, WorkspaceOrder &order) {
  if (!ideMode() || environmentVariable("NC_RESTORE") != "1")
    return 0;
  const std::filesystem::path file = sessionDir_ / kAutosaveName;
  std::error_code ec;
  if (!std::filesystem::is_regular_file(file, ec))
    return 0;
  NamedValues loaded;
  std::string err;
  if (!readNdatFile(file, loaded, err)) {
    std::cerr << "Warning: could not restore the previous workspace: " << err << "\n";
    return 0;
  }
  std::string bad;
  if (!namesAreValid(loaded, "restore", bad)) {
    std::cerr << "Warning: could not restore the previous workspace: " << bad << "\n";
    return 0;
  }
  const bool emptyBefore = vars.empty();
  for (auto &nv : loaded) {
    if (!vars.count(nv.first))
      order.push_back(nv.first);
    vars[nv.first] = std::move(nv.second);
  }
  // The file holds exactly this workspace (nothing else was in it).
  restoredFromAutosave_ = emptyBefore && !loaded.empty();
  // Variables the autosave left out (decision D6): say so, once.
  {
    std::ifstream skipped(sessionDir_ / kAutosaveSkippedName, std::ios::binary);
    std::string line;
    const uint64_t limit = nc::mem::autosaveLimitBytes(sessionDir_.u8string().c_str());
    while (std::getline(skipped, line)) {
      const size_t tab = line.find('\t');
      if (tab == std::string::npos)
        continue;
      const uint64_t bytes = std::strtoull(line.c_str() + tab + 1, nullptr, 10);
      std::cout << "Note: " << line.substr(0, tab) << " (" << nc::mem::bytesText(bytes)
                << ") was not restored - it was larger than the autosave limit ("
                << nc::mem::bytesText(limit) << "); compute it again" << std::endl;
    }
  }
  return loaded.size();
}

/* ================= runtime channel ================= */

std::vector<DataEngine::Entry> DataEngine::snapshot(const Workspace &vars,
                                                    const WorkspaceOrder &order) const {
  std::vector<Entry> entries;
  entries.reserve(vars.size());
  std::unordered_map<std::string, bool> seen;
  seen.reserve(vars.size());
  for (const std::string &name : order) {
    auto it = vars.find(name);
    if (it == vars.end() || seen.count(name))
      continue;
    seen[name] = true;
    entries.push_back({&it->first, &it->second, 0});
  }
  // Defensive: a variable `order` does not list still belongs on screen.
  std::vector<const std::string *> stray;
  for (const auto &kv : vars)
    if (!seen.count(kv.first))
      stray.push_back(&kv.first);
  std::sort(stray.begin(), stray.end(), [](const auto *a, const auto *b) { return *a < *b; });
  for (const std::string *name : stray)
    entries.push_back({name, &vars.at(*name), 0});

  for (Entry &e : entries)
    e.hash = valueFingerprint(*e.value);
  return entries;
}

uint64_t DataEngine::signatureOf(const std::vector<Entry> &entries) {
  HashSink sink;
  sink.u64(entries.size());
  for (const Entry &e : entries) {
    sink.u32(static_cast<uint32_t>(e.name->size()));
    sink.bytes(*e.name);
    sink.u64(e.hash);
  }
  return sink.hash.value();
}

// Queues the autosave for the background thread (2026-11-20). Until then it
// was written here, before the prompt came back: a 479 MB workspace held
// every command - even `x = 1;` - for about 3 s.
void DataEngine::writeAutosave(const std::vector<Entry> &entries) {
  auto job = std::make_unique<AutosaveJob>();
  job->vars.reserve(entries.size());
  // Decision D6 (2026-11-23): a variable bigger than the autosave limit -
  // RAM / 8 and free disk / 20, at least 256 MB (governor.h) - is not
  // written; a 50 GB result would otherwise keep the disk and several cores
  // busy after every change. Its name and size are, for the restore's note.
  const uint64_t limit = nc::mem::autosaveLimitBytes(sessionDir_.u8string().c_str());
  for (const Entry &e : entries) {
    const uint64_t bytes = storedBytes(*e.value);
    if (bytes > limit)
      job->skipped.emplace_back(*e.name, bytes);
    else
      job->vars.emplace_back(*e.name, *e.value); // shares packed buffers
  }
  {
    std::lock_guard<std::mutex> lock(autosaveMutex_);
    autosaveQueued_ = std::move(job); // replaces a snapshot not yet started
    if (!autosaveThread_.joinable())
      autosaveThread_ = std::thread([this] { autosaveLoop(); });
  }
  autosaveWake_.notify_one();
}

void DataEngine::emitWorkspaceIfChanged(const Workspace &vars, const WorkspaceOrder &order,
                                        bool force) {
  if (!ideMode() && !force)
    return;

  const std::vector<Entry> entries = snapshot(vars, order);
  const uint64_t signature = signatureOf(entries);

  // Null sets (ops/collections/nullset_builtin.h): sets whose letters were
  // made by nullset_*(). Only when one is active does the @WS line change
  // (an extra "nullsets" section); otherwise it is exactly as before.
  ncnullset::refresh(vars);
  const std::vector<const ncnullset::Set *> nullsets = ncnullset::activeSets();
  uint64_t wsSignature = signature;
  if (!nullsets.empty()) {
    HashSink sink;
    sink.u64(signature);
    for (const ncnullset::Set *s : nullsets)
      sink.bytes(std::string(s->id) + ";");
    wsSignature = sink.hash.value();
  }

  if (force || !haveSentWorkspace_ || wsSignature != lastSentSignature_) {
    JsonWriter json;
    json.beginObject();
    json.key("v").integer(kProtocolVersion);
    json.key("type").string("ws");
    json.key("vars").beginArray();
    for (const Entry &e : entries)
      writeSummaryJson(json, summarizeVariable(*e.name, *e.value, e.hash));
    json.endArray();
    if (!nullsets.empty()) {
      json.key("nullsets").beginArray();
      for (const ncnullset::Set *s : nullsets) {
        json.beginObject();
        json.key("set").string(s->id);
        json.key("function").string(s->function);
        json.key("script").string(s->script);
        json.key("letters").beginArray();
        for (const ncnullset::Letter &l : s->letters) {
          auto it = vars.find(l.name);
          const Value *v = it == vars.end() ? nullptr : &it->second;
          json.beginObject();
          json.key("name").string(l.name);
          json.key("token").string(l.token);
          json.key("state").string(ncnullset::stateOf(v));
          double number = 0;
          json.key("value");
          if (v && ncnullset::scalarNumber(*v, number))
            json.number(number);
          else
            json.null();
          json.endObject();
        }
        json.endArray();
        json.endObject();
      }
      json.endArray();
    }
    json.endObject();
    sendProtocolLine("@WS", json.str());
    haveSentWorkspace_ = true;
    lastSentSignature_ = wsSignature;
  }

  if (restoredFromAutosave_) {
    restoredFromAutosave_ = false;
    haveAutosaved_ = true;
    lastAutosaveSignature_ = signature;
  }
  if (ideMode() && (!haveAutosaved_ || signature != lastAutosaveSignature_)) {
    writeAutosave(entries);
    haveAutosaved_ = true;
    lastAutosaveSignature_ = signature;
  }
}

void DataEngine::emitVariable(const std::string &name, const Workspace &vars) {
  JsonWriter json;
  json.beginObject();
  json.key("v").integer(kProtocolVersion);
  json.key("type").string("var");
  json.key("name").string(name);
  auto it = vars.find(name);
  json.key("found").boolean(it != vars.end());
  if (it != vars.end()) {
    // class and size only: the fingerprint a summary carries is not needed
    // here (it hashed the whole value for nothing until 2026-11-20).
    json.key("class").string(classOf(it->second));
    json.key("size").string(sizeOf(it->second));
    std::size_t budget = kVarElementBudget;
    json.key("value");
    writeValueJson(json, it->second, budget);
    // The budget ran out: the data was left out somewhere. A value the IDE
    // can fetch in blocks says so (V1), and the IDE switches to windows.
    if (budget == 0 && isWindowable(it->second))
      json.key("windowable").boolean(true);
  }
  json.endObject();
  sendProtocolLine("@VAR", json.str());
}

void DataEngine::emitVariableWindow(const std::string &name, const Workspace &vars, std::size_t r0,
                                    std::size_t r1, std::size_t c0, std::size_t c1,
                                    const std::vector<std::size_t> &page) {
  JsonWriter json;
  json.beginObject();
  json.key("v").integer(kProtocolVersion);
  json.key("type").string("var");
  json.key("name").string(name);
  auto it = vars.find(name);
  json.key("found").boolean(it != vars.end());
  if (it != vars.end()) {
    json.key("class").string(classOf(it->second));
    json.key("size").string(sizeOf(it->second));
    if (isWindowable(it->second)) {
      json.key("windowable").boolean(true);
      writeWindowFields(json, it->second, r0, r1, c0, c1, page);
    } else {
      // Not a grid (a number, text, a dict ...): the whole value, as a plain
      // getvar sends it.
      std::size_t budget = kVarElementBudget;
      json.key("value");
      writeValueJson(json, it->second, budget);
    }
  }
  json.endObject();
  sendProtocolLine("@VAR", json.str());
}

void DataEngine::emitHello(const std::string &build) {
  JsonWriter json;
  json.beginObject();
  json.key("v").integer(kProtocolVersion);
  json.key("build").string(build);
  json.key("caps").beginArray();
  json.string("getvar-window");
  json.string("process-progress");
  json.string("command-progress"); // "@cmd progress on" -> @PROGRESS lines (2026-11-21)
  json.string("lazy-arithmetic");  // A*c, A+c, -A on a range stay lazy (2026-11-21)
  json.endArray();
  json.endObject();
  sendProtocolLine("@HELLO", json.str());
}

} // namespace ncdata
