#pragma once

// DataEngine - the interpreter's data layer.
//
// It owns the two ways the global workspace (Parser::globalMemory(), a
// std::unordered_map<std::string, Value> plus its insertion order) leaves
// the interpreter:
//
//  1. RUNTIME, to the IDE: a JSON channel on stdout (WS_PROTOCOL.md).
//     Before each prompt the REPL calls emitWorkspaceIfChanged(); when the
//     workspace differs from what the IDE last saw, one line
//         \x1E@WS {"v":1,"type":"ws","vars":[...]}
//     goes out with a summary of every variable. The full value of one
//     variable is sent on request (@cmd getvar <name>) as \x1E@VAR {...}.
//     The ASCII Record Separator in front keeps these lines apart from
//     anything a script prints.
//
//  2. PERSISTENT, on disk: the .ndat binary format (NDAT_FORMAT.md),
//     written by save_workspace([path]) and read by load_workspace([path]),
//     plus a session autosave the IDE uses to restore the workspace if it
//     ever has to restart nc.exe.
//
// Everything specific to bytes and text lives in DataSupport/; this class
// only decides what to send or store and when.
//
// Environment (set by the IDE when it launches nc.exe):
//   NC_SESSION_DIR  folder for this IDE session's files (autosave.ndat,
//                   interrupt.flag). Also switches the @WS channel on - a
//                   plain terminal user never sees protocol lines.
//   NC_RESTORE=1    load the session autosave at startup.

#include <condition_variable>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

#include "../interpreter/core/value.h"

namespace ncdata {

using Workspace = std::unordered_map<std::string, Value>;
using WorkspaceOrder = std::vector<std::string>;

// Outcome of save_workspace / load_workspace. `message` is the line to
// print: the success report, or the error text (without "Error: ").
struct WorkspaceIoResult {
  bool ok = false;
  std::string message;
  std::filesystem::path path;
  std::size_t count = 0;
};

class DataEngine {
public:
  static DataEngine &instance();

  // True for the NC call names DataEngine implements (save_workspace,
  // load_workspace).
  static bool isWorkspaceCommand(const std::string &name);

  /* ---- configuration ---- */

  // Reads NC_SESSION_DIR (and creates the folder). Call once at startup.
  void configureFromEnvironment();

  // True when the IDE launched this process (NC_SESSION_DIR set).
  bool ideMode() const { return !sessionDir_.empty(); }
  const std::filesystem::path &sessionDir() const { return sessionDir_; }

  // The folder relative file names are resolved against - the IDE's
  // current folder, updated by "@cmd setpwd".
  void setCurrentFolder(const std::filesystem::path &folder);
  const std::filesystem::path &currentFolder() const { return currentFolder_; }

  // "" -> <current folder>/workspace.ndat; a relative path is taken from
  // the current folder; ".ndat" is added when the name has no extension.
  std::filesystem::path resolveUserPath(const std::string &userPath) const;

  /* ---- persistent storage (.ndat) ---- */

  WorkspaceIoResult saveWorkspace(const Workspace &vars, const WorkspaceOrder &order,
                                  const std::string &userPath);

  // Merges the file's variables into `vars` (a variable already present is
  // replaced; new ones are added at the end of `order`).
  WorkspaceIoResult loadWorkspace(const std::string &userPath, Workspace &vars,
                                  WorkspaceOrder &order);

  // NC_RESTORE=1 at startup: loads the session autosave, if there is one.
  // Returns the number of variables restored.
  std::size_t restoreSessionIfRequested(Workspace &vars, WorkspaceOrder &order);

  /* ---- runtime channel to the IDE ---- */

  // Sends @WS when the workspace changed since the last one sent (or
  // always, with force), and refreshes the session autosave when the
  // workspace changed since it was last written. No-op outside IDE mode
  // unless forced.
  void emitWorkspaceIfChanged(const Workspace &vars, const WorkspaceOrder &order,
                              bool force = false);

  // Sends @VAR with the full value of one variable ("found": false when
  // there is no such variable). A value too big to send whole that the IDE
  // can fetch block by block carries "windowable": true.
  void emitVariable(const std::string &name, const Workspace &vars);

  // "@cmd getvar <name> <r0> <r1> <c0> <c1> [<p0> <p1> ...]" (2026-11-20,
  // docs/Java_Speed_CPP_Asks.md V1): @VAR with one block of the value
  // (ValueJson.h, writeWindowFields). No fingerprint, no copy.
  void emitVariableWindow(const std::string &name, const Workspace &vars, std::size_t r0,
                          std::size_t r1, std::size_t c0, std::size_t c1,
                          const std::vector<std::size_t> &page);

  // "@HELLO" (2026-11-20, V2): once, in IDE mode, before the first prompt -
  // the build ("release" / "debug") and the capabilities the IDE may use.
  void emitHello(const std::string &build);

  // Blocks until every autosave asked for so far is on disk. The autosave
  // is written on a background thread (2026-11-20, docs/design_fix_1_4.md
  // section 3) so the prompt never waits for it; call this where the file
  // must be complete (process exit does it too, in the destructor).
  void finishAutosave();

  ~DataEngine();
  DataEngine(const DataEngine &) = delete;
  DataEngine &operator=(const DataEngine &) = delete;

private:
  DataEngine();

  struct Entry {
    const std::string *name;
    const Value *value;
    uint64_t hash;
  };

  // The variables in display order: insertion order first, then any name
  // `order` is missing (sorted), skipping names no longer present.
  std::vector<Entry> snapshot(const Workspace &vars, const WorkspaceOrder &order) const;
  static uint64_t signatureOf(const std::vector<Entry> &entries);
  void writeAutosave(const std::vector<Entry> &entries);

  std::filesystem::path sessionDir_;
  std::filesystem::path currentFolder_;

  bool haveSentWorkspace_ = false;
  uint64_t lastSentSignature_ = 0;
  bool haveAutosaved_ = false;
  uint64_t lastAutosaveSignature_ = 0;
  // The workspace was just restored from the autosave, which therefore
  // already holds it: the first prompt takes its signature as saved instead
  // of writing the same file again (2026-11-21: 1.26 GB rewritten for nothing).
  bool restoredFromAutosave_ = false;

  // Background autosave. A job is a snapshot of the workspace: copies of
  // the Values, which share their packed buffers with the live ones (a
  // later write to a variable copies its buffer first - Value::ownTensor()),
  // so taking it costs next to nothing for numeric data. At most one job
  // waits: a newer snapshot replaces one not yet started.
  struct AutosaveJob {
    std::vector<std::pair<std::string, Value>> vars;
    // Variables above the autosave limit (2026-11-23, decision D6): name and
    // size only, written to autosave_skipped.txt for the restore's note.
    std::vector<std::pair<std::string, uint64_t>> skipped;
  };
  void autosaveLoop();
  std::mutex autosaveMutex_;
  std::condition_variable autosaveWake_; // a job was queued, or stop
  std::condition_variable autosaveIdle_; // nothing queued, nothing being written
  std::unique_ptr<AutosaveJob> autosaveQueued_;
  bool autosaveWriting_ = false;
  bool autosaveStop_ = false;
  std::thread autosaveThread_; // started by the first autosave
};

} // namespace ncdata
