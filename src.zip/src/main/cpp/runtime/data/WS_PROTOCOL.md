# IDE ⇄ nc.exe workspace protocol, version 1

This protocol replaces `variables.txt`. The interpreter no longer writes a file
for the IDE to read. It sends the workspace as JSON over the pipe it already
shares with the IDE.

- C++ side: `runtime/data/DataEngine.cpp`. The JSON comes from
  `DataSupport/JsonWriter.cpp` and `ValueJson.cpp`. Commands are handled in
  `compiler_src/main.cpp`.
- Java side: package `backend.workspace` (`WorkspaceChannel`,
  `ProtocolLineSplitter`, `WorkspaceProtocol`, `Json`, `NcInterrupt`), wired in by
  `ui.cli.CLI_Main`.

The two sides are compiled separately. This document is the contract between them.

## Launch

The IDE starts `nc.exe` with these environment variables:

| variable | meaning |
|---|---|
| `NC_SESSION_DIR` | Folder for this IDE session (`~/.neuralcode/session-<pid>`). Setting it turns on IDE mode: `@WS` lines are sent, the session autosave is written to `autosave.ndat`, and Stop requests are read from `interrupt.flag`. In a plain terminal, without this variable, none of this happens. |
| `NC_RESTORE=1` | Load `autosave.ndat` before the first prompt. Used when the IDE has to restart the interpreter. |
| `NC_IDE_PROMPT=1` | Prompt protocol (below): the interpreter never prints `>> `; it sends `@PROMPT` and `@READY` protocol lines instead. Without it the `>> ` prompt is printed as in a terminal. |

## Interpreter → IDE

Protocol lines start with the ASCII Record Separator **`0x1E`**, followed by a
keyword, one space, one line of JSON, and `\n`. A script never prints `0x1E`, so
the IDE can take these lines out of the output stream without guessing. The IDE
splits them off in its reader thread, before the console's output buffer, so a
large line is never truncated or interleaved.

### `@WS` — workspace summary

The interpreter sends this just before a prompt, but only when the workspace has
changed since the last `@WS`. It also sends one before each `@STEPAT` pause, and on
request.

```json
{"v":1,"type":"ws","vars":[
  {"name":"x","class":"float64","size":"1x1","unit":"","preview":"3.14","hash":"4e8f26cfb2d0310d"},
  {"name":"g","class":"float64","size":"1x1","unit":"m/s^2","preview":"9.81 m/s^2","hash":"..."},
  {"name":"k","class":"int64","size":"1x1","unit":"","preview":"9223372036854775807","hash":"..."},
  {"name":"M","class":"float64","size":"2x2","unit":"","preview":"[[1,2],[3,4]]","hash":"..."}
]}
```

- `vars` is the **complete** global workspace, in the order the variables were
  first assigned. A variable that is missing from the list is gone. Replace the
  whole list; do not merge.
- `class` is one of: `float64`, `float32`, `float16`, `float8`, `complex`, `bool`,
  `int8` … `int64`, `uint8` … `uint64`, `string`, `cell`, `dict`,
  `function_handle`, or, for an object, its class name. An array whose elements all share one class reports that class, so
  an int64 array has class `int64`.
- `size` is `RxC`. Text is `1xN`, where N is the number of characters. A dict is
  `Nx1`, where N is the number of keys.
- `preview` is display text of at most about 400 characters. Vectors and matrices
  with up to 1000 elements are listed in full, as `[1,2,3]` and `[[1,2],[3,4]]`.
  Larger ones read `<300x400 double>`.
- `hash` is the FNV-1a 64 hash of the value's `.ndat` bytes, as 16 hex digits.
  It is equal for equal values, so it is a cheap way to tell whether a row changed.

### `@VAR` — one variable in full

The interpreter sends this in answer to `@cmd getvar <name>`.

```json
{"v":1,"type":"var","name":"M","found":true,"class":"float64","size":"2x2",
 "value":{"k":"tensor","elem":"float64","shape":[2,2],"data":[1,2,3,4]}}
```

`value` kinds:

| `k` | fields |
|---|---|
| `num` | `t` (`float64`, `float32`, `float16` or `float8`), `v` (a number, or the string `"NaN"`, `"Infinity"` or `"-Infinity"`) |
| `int` | `t` (type name), `v` (**decimal string**, so int64 and uint64 stay exact) |
| `bool` | `v` |
| `complex` | `re`, `im` |
| `str` | `v` |
| `tensor` | `elem` (`float64` or `complex128`), `shape` (`[n]` or `[rows,cols]`), and `data` (float64) or `re`/`im` (complex). All data is **row-major**. |
| `cell` | `shape`, `items` (values) |
| `cellmatrix` | `shape`, `rows` (arrays of values) |
| `dict` | `entries`: `[{"key":…,"value":…}]`, sorted by key |
| `object` | `class`, `fields` (same shape as `entries`), `lineage` (strings), `snapshots` (count) |
| `func` | `name` |

Any value can also carry `unit` (`{"L":1,"T":-2,"M":0}`) and `unitText` (`"m/s^2"`).
For a tensor, the unit is the one all elements share.

One `@VAR` carries at most 2,000,000 elements. Past that, a container comes without
its data and with `"truncated": true`. `"found": false` means there is no such
variable.

### Prompt protocol — `@PROMPT` and `@READY`

With `NC_IDE_PROMPT=1` the IDE owns the `>> ` prompt; the interpreter never prints
it, so nothing a script prints can be taken for a prompt. Two protocol lines take
its place (Record Separator, keyword, `\n` — no JSON):

| line | meaning |
|---|---|
| `@PROMPT` | The REPL is back at the top of its loop and about to read a line. Sent once for every line read from stdin, internal `@cmd` lines included, but not for `@cmd stepnext` (a paused block reads that itself). It follows any `@WS` for the same moment. |
| `@READY <id>` | The answer to `@cmd ready <id>`. stdin is one ordered stream, so it is written only after everything sent before it has run. |

The IDE sends `@cmd ready <id>` after the lines of every command (a typed line,
a typed block, Run, a Step statement) and shows the next prompt when the matching
`@READY` arrives. One command is in flight at a time; type-ahead waits in the IDE.
Lines of a block sent with `@cmd stepinto` are **not** followed by `@cmd ready`,
because a paused block reads stdin itself; the end of such a block is seen from
`@PROMPT`.

If `@cmd ready` arrives while a multi-line construct is still open (a header whose
terminator never came), the construct is discarded with an error before `@READY` is
sent, so the REPL can never be left waiting for ever.

`@STEPAT <n>` (step-into pauses) is still plain output text, not a protocol line.

### `@PARMON` — CPU core and thread monitor

Sent only after the IDE has turned the monitor on with `@cmd parmon on`. Two
`type`s share the keyword:

- `"type":"parmon_summary"` — just before `@PROMPT`, after a command that used
  NC's multicore kernels or ran longer than one monitor interval. One line per
  command at most; nothing after short serial commands.
- `"type":"parmon"` — the answer to `@cmd parmon snapshot`.

While a command runs, live snapshots (also `"type":"parmon"`) go to the file
`<NC_SESSION_DIR>/parmon.json`, never to stdout, because a background thread
writing to stdout could split a line of script output. Every field of both types,
and how the panel should use them, is in
`docs/Parallel_Monitor_Java_Handover.md`.

### `@ANALYSIS` — the Analysis box (No. of Computation / Execution Time)

`"type":"analysis_summary"`, one line per command, sent just before `@PROMPT` (after any
`@PARMON` line) while at least one Analysis toggle is on: total computations, the
computations-vs-seconds series, the order of growth of each loop, the time per
operation and the statement history. Live documents of the same kind go to the file
`<NC_SESSION_DIR>/analysis.json` once a second while a command runs. Full reference:
`docs/Analysis_Section_Java_Handover.md`.

## IDE → interpreter

Commands are ordinary lines on stdin. `@cmd` lines are handled before anything
else, even while a multi-line construct is being read, and are never part of one.

| line | effect |
|---|---|
| `@cmd wsnow` | Send `@WS` now, even if nothing changed. `@cmd syncws` is the old name and still works. |
| `@cmd getvar <name>` | Send `@VAR` for one variable. |
| `@cmd clearvar <name>` | Remove one global variable. This is the IDE's `clear name`. |
| `clear` | Empty the global workspace. |
| `@cmd setpwd "<folder>"` | Set the current folder. Relative paths in `save_workspace` and `load_workspace` follow it. |
| `@cmd ready <id>` | Answered with `@READY <id>` (prompt protocol). |
| `@cmd parmon on` / `@cmd parmon off` | Turn the CPU core/thread monitor on when its panel opens and off when it closes. It is off at startup. |
| `@cmd parmon interval <ms>` | Live snapshot period, 100–5000 ms (default 250). |
| `@cmd analysis computations on` / `off` | The "No. of Computation" toggle of the Analysis box. Off at startup. |
| `@cmd analysis time on` / `off` | The "Execution Time" toggle. Off at startup. |
| `@cmd analysis interval <ms>` | Live `analysis.json` period, 250–5000 ms (default 1000). |
| `@cmd parmon snapshot` | Send one `@PARMON` snapshot line now. It takes about 100 ms, because a load is measured over an interval. |

## Stop

A Windows process on pipes cannot be sent Ctrl+C, so Stop is cooperative:

1. The IDE creates an empty file, `<NC_SESSION_DIR>/interrupt.flag`.
2. The interpreter checks for that file before every statement, between the
   statements of a script, and on every iteration of a JIT-compiled loop. Checks
   are cheap: a counter, plus a file check at most every ~30 ms. When it sees the
   file, it deletes it and unwinds to the prompt. Variables assigned before the
   stop are kept. Then it prints `Execution interrupted by user.` and the prompt.
3. If the command does not come back (its `@READY`, or `@PROMPT` for a paused step block) within 2.5 s, the IDE kills `nc.exe` and starts a new one
   with `NC_RESTORE=1`. This happens with a long-running builtin, for example. The
   workspace comes back as it was at the last prompt.

The IDE deletes any leftover flag before it sends a new command, so an old Stop can
never interrupt the next command. The interpreter also clears the flag just before
each prompt. While a step-into block is paused, the IDE creates the flag and then
releases the pause with `@cmd stepnext`.

## Shutdown

When the IDE closes, it copies `autosave.ndat` to `~/.neuralcode/last_session.ndat`.
A launch with `-Dastra.workspace.persist=true` restores that file into the first
interpreter of the next session.
