#include "NdatBundle.h"

#include <chrono>
#include <cstring>

#include "BinaryIO.h"
#include "NdatReader.h"
#include "NdatTypes.h"
#include "NdatWriter.h"

namespace ncdata {
namespace bundle {

namespace {

constexpr char kTocMagic[4] = {'N', 'T', 'O', 'C'};
constexpr std::size_t kFooter = 24; // u64 tocOffset, u64 tocLength, "NEND", u32 crc

uint32_t crcOf(const uint8_t *p, std::size_t n) {
  Crc32 c;
  c.update(p, n);
  return c.value();
}

} // namespace

const char *encodingName(Encoding e) {
  switch (e) {
  case Encoding::Native:
    return "native";
  case Encoding::Hdf5:
    return "hdf5";
  case Encoding::Parquet:
    return "parquet";
  case Encoding::Arrow:
    return "arrow";
  }
  return "?";
}

const char *rootName(Root r) {
  switch (r) {
  case Root::Value:
    return "value";
  case Root::Dict:
    return "dict";
  case Root::Workspace:
    return "workspace";
  }
  return "?";
}

bool writeBundle(const std::filesystem::path &path, Root root, const std::vector<Section> &sections,
                 std::string &err) {
  std::error_code ec;
  const std::filesystem::path folder = path.parent_path();
  if (!folder.empty() && !std::filesystem::is_directory(folder, ec)) {
    err = "folder does not exist: " + folder.u8string();
    return false;
  }

  // Header (32 bytes).
  VectorSink head;
  head.write(reinterpret_cast<const uint8_t *>(ndat::kMagic), 4);
  head.u16(kMajor);
  head.u16(kMinor);
  head.u8(ndat::kEndianLittle);
  head.u8(0); // flags
  head.u16(0);
  head.u32(static_cast<uint32_t>(sections.size()));
  const auto now = std::chrono::system_clock::now().time_since_epoch();
  head.u64(static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(now).count()));
  head.u8(static_cast<uint8_t>(root));
  for (int i = 0; i < 7; i++)
    head.u8(0);

  // Table of contents (sections follow the header in this order).
  VectorSink toc;
  toc.write(reinterpret_cast<const uint8_t *>(kTocMagic), 4);
  uint64_t offset = head.buffer.size();
  for (const Section &s : sections) {
    toc.u32(static_cast<uint32_t>(s.name.size()));
    toc.bytes(s.name);
    toc.u8(static_cast<uint8_t>(s.encoding));
    toc.u64(offset);
    toc.u64(s.bytes.size());
    toc.u32(crcOf(reinterpret_cast<const uint8_t *>(s.bytes.data()), s.bytes.size()));
    writeValueNode(toc, s.meta.isDict ? s.meta : Value(std::unordered_map<std::string, Value>{}));
    offset += s.bytes.size();
  }
  const uint64_t tocOffset = offset;

  Crc32 crc;
  crc.update(head.buffer.data(), head.buffer.size());
  crc.update(toc.buffer.data(), toc.buffer.size());

  std::filesystem::path temp = path;
  temp += ".tmp";
  {
    std::ofstream file(temp, std::ios::binary | std::ios::trunc);
    if (!file) {
      err = "cannot write " + path.u8string();
      return false;
    }
    file.write(reinterpret_cast<const char *>(head.buffer.data()),
               static_cast<std::streamsize>(head.buffer.size()));
    for (const Section &s : sections)
      file.write(s.bytes.data(), static_cast<std::streamsize>(s.bytes.size()));
    file.write(reinterpret_cast<const char *>(toc.buffer.data()),
               static_cast<std::streamsize>(toc.buffer.size()));
    VectorSink foot;
    foot.u64(tocOffset);
    foot.u64(toc.buffer.size());
    foot.write(reinterpret_cast<const uint8_t *>(ndat::kEndMagic), 4);
    foot.u32(crc.value());
    file.write(reinterpret_cast<const char *>(foot.buffer.data()),
               static_cast<std::streamsize>(foot.buffer.size()));
    file.flush();
    if (!file) {
      file.close();
      std::filesystem::remove(temp, ec);
      err = "write failed for " + path.u8string() + " (disk full?)";
      return false;
    }
  }
  std::filesystem::rename(temp, path, ec);
  if (ec) {
    std::error_code ec2;
    std::filesystem::remove(path, ec2);
    std::filesystem::rename(temp, path, ec2);
    if (ec2) {
      std::filesystem::remove(temp, ec2);
      err = "cannot replace " + path.u8string() + ": " + ec.message();
      return false;
    }
  }
  return true;
}

int ndatMajorVersion(const std::filesystem::path &path) {
  std::ifstream in(path, std::ios::binary);
  char h[8] = {0};
  if (!in.read(h, 8))
    return 0;
  if (std::memcmp(h, ndat::kMagic, 4) != 0)
    return 0;
  return static_cast<uint8_t>(h[4]) | (static_cast<uint8_t>(h[5]) << 8);
}

bool BundleReader::open(const std::filesystem::path &path, std::string &err) {
  path_ = path;
  entries_.clear();
  std::error_code ec;
  size_ = std::filesystem::file_size(path, ec);
  if (ec) {
    err = "cannot open " + path.u8string();
    return false;
  }
  in_.open(path, std::ios::binary);
  if (!in_ || size_ < 32 + kFooter) {
    err = path.u8string() + " is not an .ndat file (too short)";
    return false;
  }
  std::string head(32, '\0'), foot(kFooter, '\0');
  in_.read(&head[0], 32);
  in_.seekg(static_cast<std::streamoff>(size_ - kFooter));
  in_.read(&foot[0], kFooter);
  if (!in_ || std::memcmp(head.data(), ndat::kMagic, 4) != 0) {
    err = path.u8string() + " is not an .ndat file";
    return false;
  }
  ByteReader h(reinterpret_cast<const uint8_t *>(head.data()), head.size());
  h.skip(4);
  const uint16_t major = h.u16();
  minor_ = h.u16();
  if (major != kMajor) {
    err = path.u8string() + " is .ndat version " + std::to_string(major) +
          " - this reader takes version 2 bundles";
    return false;
  }
  h.skip(4); // endian, flags, reserved
  const uint32_t count = h.u32();
  created_ = h.u64();
  const uint8_t root = h.u8();
  if (root > 2) {
    err = path.u8string() + ": unknown root kind " + std::to_string(root);
    return false;
  }
  root_ = static_cast<Root>(root);

  ByteReader f(reinterpret_cast<const uint8_t *>(foot.data()), foot.size());
  const uint64_t tocOffset = f.u64(), tocLength = f.u64();
  const std::string endMagic = f.bytes(4);
  const uint32_t crc = f.u32();
  if (endMagic != std::string(ndat::kEndMagic, 4) || tocOffset < 32 ||
      tocOffset + tocLength + kFooter != size_) {
    err = path.u8string() + " is damaged (its end marker or table of contents is missing)";
    return false;
  }
  std::string toc(static_cast<size_t>(tocLength), '\0');
  in_.seekg(static_cast<std::streamoff>(tocOffset));
  in_.read(&toc[0], static_cast<std::streamsize>(tocLength));
  Crc32 c;
  c.update(reinterpret_cast<const uint8_t *>(head.data()), head.size());
  c.update(reinterpret_cast<const uint8_t *>(toc.data()), toc.size());
  if (!in_ || c.value() != crc) {
    err = path.u8string() + " is damaged (checksum of its table of contents does not match)";
    return false;
  }
  ByteReader t(reinterpret_cast<const uint8_t *>(toc.data()), toc.size());
  if (t.bytes(4) != std::string(kTocMagic, 4)) {
    err = path.u8string() + " is damaged (table of contents)";
    return false;
  }
  for (uint32_t i = 0; i < count && t.ok(); i++) {
    EntryInfo e;
    const uint32_t n = t.u32();
    e.name = t.bytes(n);
    const uint8_t enc = t.u8();
    e.offset = t.u64();
    e.length = t.u64();
    e.crc = t.u32();
    if (enc > 3) {
      err = path.u8string() + ": entry '" + e.name + "' uses encoding " + std::to_string(enc) +
            " from a newer version";
      return false;
    }
    e.encoding = static_cast<Encoding>(enc);
    if (!readValueNode(t, e.meta, err))
      return false;
    if (e.offset < 32 || e.offset + e.length > tocOffset) {
      err = path.u8string() + " is damaged (entry '" + e.name + "' points outside the file)";
      return false;
    }
    entries_.push_back(std::move(e));
  }
  if (!t.ok()) {
    err = path.u8string() + " is damaged (table of contents ends early)";
    return false;
  }
  return true;
}

const EntryInfo *BundleReader::find(const std::string &name) const {
  for (const EntryInfo &e : entries_)
    if (e.name == name)
      return &e;
  return nullptr;
}

bool BundleReader::section(const EntryInfo &e, std::string &bytes, std::string &err) {
  bytes.assign(static_cast<size_t>(e.length), '\0');
  in_.clear();
  in_.seekg(static_cast<std::streamoff>(e.offset));
  if (e.length)
    in_.read(&bytes[0], static_cast<std::streamsize>(e.length));
  if (!in_) {
    err = path_.u8string() + ": cannot read entry '" + e.name + "'";
    return false;
  }
  if (crcOf(reinterpret_cast<const uint8_t *>(bytes.data()), bytes.size()) != e.crc) {
    err = path_.u8string() + " is damaged (entry '" + e.name + "' fails its checksum)";
    return false;
  }
  return true;
}

} // namespace bundle
} // namespace ncdata
