#include "NdatReader.h"

#include <cstring>
#include <fstream>
#include <system_error>

#include "../../interpreter/ops/floating/floating.h"
#include "NdatTypes.h"

namespace ncdata {

namespace {

// "0x24" - a type tag as written in NDAT_FORMAT.md.
std::string hexTag(unsigned tag) {
  static const char *digits = "0123456789ABCDEF";
  return std::string("0x") + digits[(tag >> 4) & 0xF] + digits[tag & 0xF];
}

bool fail(std::string &err, const std::string &why) {
  if (err.empty())
    err = why;
  return false;
}

bool truncated(ByteReader &in, std::string &err) {
  in.fail();
  return fail(err, "file is truncated or corrupt");
}

void applyUnits(Value &v, int16_t l, int16_t t, int16_t m) {
  v.dimL = l;
  v.dimT = t;
  v.dimM = m;
}

bool readShortString(ByteReader &in, std::string &out, std::string &err) {
  const uint32_t len = in.u32();
  if (!in.ok() || len > in.remaining())
    return truncated(in, err);
  out = in.bytes(len);
  return in.ok() || truncated(in, err);
}

// A count of items that each take at least `minBytes` must fit in what is
// left of the file - rejects absurd counts before anything is allocated.
bool plausibleCount(ByteReader &in, uint64_t count, std::size_t minBytes) {
  return minBytes == 0 || count <= in.remaining() / minBytes;
}

bool readEntries(ByteReader &in, std::unordered_map<std::string, Value> &out, std::string &err,
                 int depth) {
  const uint64_t count = in.u64();
  if (!in.ok() || !plausibleCount(in, count, 4 + 2))
    return truncated(in, err);
  out.reserve(static_cast<std::size_t>(count));
  for (uint64_t i = 0; i < count; i++) {
    std::string key;
    if (!readShortString(in, key, err))
      return false;
    Value v;
    if (!readValueNode(in, v, err, depth + 1))
      return false;
    out[key] = std::move(v);
  }
  return true;
}

bool readTensor(ByteReader &in, Value &out, std::string &err) {
  const uint8_t elemTag = in.u8();
  const int16_t l = in.i16(), t = in.i16(), m = in.i16();
  const uint8_t rank = in.u8();
  if (!in.ok())
    return truncated(in, err);
  if (elemTag != ndat::TAG_FLOAT64 && elemTag != ndat::TAG_COMPLEX128)
    return fail(err, "unsupported tensor element type " + hexTag(elemTag));
  if (rank != 1 && rank != 2)
    return fail(err, "unsupported tensor rank " + std::to_string(rank));

  uint64_t rows = in.u64();
  uint64_t cols = rank == 2 ? in.u64() : 1;
  if (!in.ok())
    return truncated(in, err);
  const std::size_t stride = elemTag == ndat::TAG_COMPLEX128 ? 2 : 1;
  if (rows != 0 && cols > in.remaining() / sizeof(double) / rows / stride)
    return truncated(in, err);
  const std::size_t count = static_cast<std::size_t>(rows * cols);
  if (count == 0)
    return fail(err, "empty tensor (empty arrays are stored as cells)");

  std::vector<double> buf(count * stride);
  if (!in.f64Array(buf.data(), buf.size()))
    return truncated(in, err);

  const bool unitless = l == 0 && t == 0 && m == 0;
  if (unitless) {
    if (stride == 2) {
      const auto *data = reinterpret_cast<const std::complex<double> *>(buf.data());
      out = rank == 2 ? Value::packedComplexMatrix(data, rows, cols)
                      : Value::packedComplexArray(data, count);
    } else {
      out = rank == 2 ? Value::packedMatrix(buf.data(), rows, cols)
                      : Value::packedArray(buf.data(), count);
    }
    return true;
  }

  // With a unit: build the elements and let the Value constructors pack
  // them (the packed-buffer factories above are unitless only).
  auto element = [&](std::size_t k) {
    Value e = stride == 2 && buf[2 * k + 1] != 0.0 ? Value::complexNumber(buf[2 * k], buf[2 * k + 1])
                                                   : Value(buf[k * stride]);
    applyUnits(e, l, t, m);
    return e;
  };
  if (rank == 1) {
    std::vector<Value> elems;
    elems.reserve(count);
    for (std::size_t k = 0; k < count; k++)
      elems.push_back(element(k));
    out = Value(std::move(elems));
  } else {
    std::vector<std::vector<Value>> matrix(rows, std::vector<Value>(cols));
    for (std::size_t c = 0; c < cols; c++)
      for (std::size_t r = 0; r < rows; r++)
        matrix[r][c] = element(c * rows + r); // column-major on disk
    out = Value(std::move(matrix));
  }
  return true;
}

bool readInt(ByteReader &in, uint8_t tag, Value &out, std::string &err) {
  switch (tag) {
  case ndat::TAG_INT8:
    out = Value::integerSigned(IntType::Int8, static_cast<int8_t>(in.u8()));
    break;
  case ndat::TAG_INT16:
    out = Value::integerSigned(IntType::Int16, static_cast<int16_t>(in.u16()));
    break;
  case ndat::TAG_INT32:
    out = Value::integerSigned(IntType::Int32, static_cast<int32_t>(in.u32()));
    break;
  case ndat::TAG_INT64:
    out = Value::integerSigned(IntType::Int64, static_cast<int64_t>(in.u64()));
    break;
  case ndat::TAG_UINT8:
    out = Value::integerUnsigned(IntType::UInt8, in.u8());
    break;
  case ndat::TAG_UINT16:
    out = Value::integerUnsigned(IntType::UInt16, in.u16());
    break;
  case ndat::TAG_UINT32:
    out = Value::integerUnsigned(IntType::UInt32, in.u32());
    break;
  case ndat::TAG_UINT64:
    out = Value::integerUnsigned(IntType::UInt64, in.u64());
    break;
  default:
    return fail(err, "this version of NC cannot hold a value of type tag " + hexTag(tag) +
                         " (int128/int256 and float128/float256 are reserved for later)");
  }
  return in.ok() || truncated(in, err);
}

} // namespace

bool readValueNode(ByteReader &in, Value &out, std::string &err, int depth) {
  if (depth > ndat::kMaxNestingDepth)
    return fail(err, "values nested too deeply");

  const uint8_t tag = in.u8();
  const uint8_t flags = in.u8();
  if (!in.ok())
    return truncated(in, err);
  if (flags & ~ndat::kKnownFlags)
    return fail(err, "file uses features newer than this version of NC (node flags)");
  int16_t l = 0, t = 0, m = 0;
  if (flags & ndat::FLAG_HAS_UNITS) {
    l = in.i16();
    t = in.i16();
    m = in.i16();
    if (!in.ok())
      return truncated(in, err);
  }

  switch (tag) {
  case ndat::TAG_BOOL: {
    const uint8_t b = in.u8();
    if (!in.ok())
      return truncated(in, err);
    out = Value::boolean(b != 0);
    break;
  }

  case ndat::TAG_FLOAT64:
    out = Value(in.f64());
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_FLOAT8:
    out = Value::floating(FloatType::Float8, decodeFloatBits(FloatType::Float8, in.u8()));
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_FLOAT16:
    out = Value::floating(FloatType::Float16, decodeFloatBits(FloatType::Float16, in.u16()));
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_FLOAT32:
    out = Value::floating(FloatType::Float32, decodeFloatBits(FloatType::Float32, in.u32()));
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_COMPLEX128: {
    const double re = in.f64();
    const double im = in.f64();
    if (!in.ok())
      return truncated(in, err);
    out = Value::complexNumber(re, im);
    break;
  }

  case ndat::TAG_UTF8: {
    const uint64_t len = in.u64();
    if (!in.ok() || len > in.remaining())
      return truncated(in, err);
    out = Value(in.bytes(static_cast<std::size_t>(len)));
    break;
  }

  case ndat::TAG_NUM_TENSOR:
    if (!readTensor(in, out, err))
      return false;
    break;

  case ndat::TAG_CELL_ARRAY: {
    const uint64_t n = in.u64();
    if (!in.ok() || !plausibleCount(in, n, 2))
      return truncated(in, err);
    std::vector<Value> elems;
    elems.reserve(static_cast<std::size_t>(n));
    for (uint64_t i = 0; i < n; i++) {
      Value e;
      if (!readValueNode(in, e, err, depth + 1))
        return false;
      elems.push_back(std::move(e));
    }
    out = Value(std::move(elems));
    break;
  }

  case ndat::TAG_CELL_MATRIX: {
    const uint64_t rows = in.u64();
    if (!in.ok() || !plausibleCount(in, rows, 8))
      return truncated(in, err);
    std::vector<std::vector<Value>> matrix;
    matrix.reserve(static_cast<std::size_t>(rows));
    for (uint64_t r = 0; r < rows; r++) {
      const uint64_t len = in.u64();
      if (!in.ok() || !plausibleCount(in, len, 2))
        return truncated(in, err);
      std::vector<Value> row;
      row.reserve(static_cast<std::size_t>(len));
      for (uint64_t c = 0; c < len; c++) {
        Value e;
        if (!readValueNode(in, e, err, depth + 1))
          return false;
        row.push_back(std::move(e));
      }
      matrix.push_back(std::move(row));
    }
    out = Value(std::move(matrix));
    break;
  }

  case ndat::TAG_DICT: {
    std::unordered_map<std::string, Value> entries;
    if (!readEntries(in, entries, err, depth))
      return false;
    out = Value(entries);
    break;
  }

  case ndat::TAG_OBJECT: {
    Value obj;
    obj.isObject = true;
    if (!readShortString(in, obj.classNameMut(), err))
      return false;
    if (!readEntries(in, obj.dictMut(), err, depth))
      return false;
    const uint64_t lineageCount = in.u64();
    if (!in.ok() || !plausibleCount(in, lineageCount, 4))
      return truncated(in, err);
    for (uint64_t i = 0; i < lineageCount; i++) {
      std::string entry;
      if (!readShortString(in, entry, err))
        return false;
      obj.lineageMut().push_back(std::move(entry));
    }
    const uint64_t snapshotCount = in.u64();
    if (!in.ok() || !plausibleCount(in, snapshotCount, 8))
      return truncated(in, err);
    for (uint64_t i = 0; i < snapshotCount; i++) {
      std::unordered_map<std::string, Value> snapshot;
      if (!readEntries(in, snapshot, err, depth))
        return false;
      obj.snapshotsMut().push_back(std::move(snapshot));
    }
    const double lastTick = in.f64();
    if (!in.ok())
      return truncated(in, err);
    if (lastTick != -1.0)
      obj.lastTickTimeMut() = lastTick;
    out = std::move(obj);
    break;
  }

  case ndat::TAG_FUNC_REF: {
    Value ref;
    ref.isFunctionRef = true;
    if (!readShortString(in, ref.funcRefNameMut(), err))
      return false;
    out = std::move(ref);
    break;
  }

  default:
    if (tag >= ndat::TAG_INT8 && tag <= ndat::TAG_UINT256) {
      if (!readInt(in, tag, out, err))
        return false;
      break;
    }
    if (tag == ndat::TAG_FLOAT128 || tag == ndat::TAG_FLOAT256)
      return fail(err, "this version of NC cannot hold a value of type tag " + hexTag(tag) +
                           " (float128/float256 are reserved for later)");
    return fail(err, "unknown value type tag " + hexTag(tag) +
                         " (written by a newer version of NC?)");
  }

  applyUnits(out, l, t, m);
  return true;
}

bool readNdatImage(const std::vector<uint8_t> &image, NamedValues &out, std::string &err) {
  if (image.size() < ndat::kHeaderSize + ndat::kFooterSize ||
      std::memcmp(image.data(), ndat::kMagic, 4) != 0)
    return fail(err, "not an .ndat file");

  ByteReader header(image.data(), ndat::kHeaderSize);
  header.skip(4);
  const uint16_t major = header.u16();
  const uint16_t minor = header.u16();
  const uint8_t endian = header.u8();
  if (major != ndat::kVersionMajor)
    return fail(err, ".ndat version " + std::to_string(major) + "." + std::to_string(minor) +
                         " is not supported by this version of NC (expects " +
                         std::to_string(ndat::kVersionMajor) + ".x)");
  if (endian != ndat::kEndianLittle)
    return fail(err, "unsupported byte order in .ndat header");
  header.skip(1 + 2); // header flags, reserved
  const uint32_t varCount = header.u32();

  // Footer: "NEND" + CRC-32 over everything before the CRC itself.
  const std::size_t footerAt = image.size() - ndat::kFooterSize;
  if (std::memcmp(image.data() + footerAt, ndat::kEndMagic, 4) != 0)
    return fail(err, "file is truncated (no end marker)");
  ByteReader crcReader(image.data() + footerAt + 4, 4);
  const uint32_t storedCrc = crcReader.u32();
  Crc32 crc;
  crc.update(image.data(), footerAt + 4);
  if (crc.value() != storedCrc)
    return fail(err, "file is corrupt (checksum mismatch)");

  ByteReader in(image.data() + ndat::kHeaderSize, footerAt - ndat::kHeaderSize);
  NamedValues vars;
  vars.reserve(varCount);
  for (uint32_t i = 0; i < varCount; i++) {
    const uint32_t nameLen = in.u32();
    if (!in.ok() || nameLen == 0 || nameLen > ndat::kMaxNameBytes || nameLen > in.remaining())
      return truncated(in, err);
    std::string name = in.bytes(nameLen);
    Value v;
    if (!readValueNode(in, v, err))
      return false;
    vars.emplace_back(std::move(name), std::move(v));
  }
  if (in.remaining() != 0)
    return fail(err, "file is corrupt (unexpected data after the last variable)");

  out = std::move(vars);
  return true;
}

bool readNdatFile(const std::filesystem::path &path, NamedValues &out, std::string &err) {
  std::error_code ec;
  if (!std::filesystem::is_regular_file(path, ec))
    return fail(err, "file not found: " + path.u8string());
  std::ifstream file(path, std::ios::binary);
  if (!file)
    return fail(err, "cannot open " + path.u8string());
  std::vector<uint8_t> image((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
  if (file.bad())
    return fail(err, "cannot read " + path.u8string());
  if (!readNdatImage(image, out, err)) {
    err = path.filename().u8string() + ": " + err;
    return false;
  }
  return true;
}

} // namespace ncdata
