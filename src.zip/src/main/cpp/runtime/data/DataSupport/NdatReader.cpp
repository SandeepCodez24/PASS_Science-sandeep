#include "NdatReader.h"

#include <cstring>
#include <fstream>
#include <system_error>

#include "../../interpreter/core/packed_read.h"
#include "../../interpreter/ops/floating/floating.h"
#include "../../interpreter/ops/matrix/nd_array.h"
#include "NdatTypes.h"

namespace ncdata {

namespace {

// "0x24" - a type tag as written in NDAT_FORMAT.md.
std::string hexTag(unsigned tag) {
  static const char *digits = "0123456789ABCDEF";
  return std::string("0x") + digits[(tag >> 4) & 0xF] + digits[tag & 0xF];
}

bool fail(std::string &err, const std::string &why) {
  if (err.empty())
    err = why;
  return false;
}

bool truncated(ByteReader &in, std::string &err) {
  in.fail();
  return fail(err, "file is truncated or corrupt");
}

void applyUnits(Value &v, int16_t l, int16_t t, int16_t m) {
  v.dimL = l;
  v.dimT = t;
  v.dimM = m;
}

bool readShortString(ByteReader &in, std::string &out, std::string &err) {
  const uint32_t len = in.u32();
  if (!in.ok() || len > in.remaining())
    return truncated(in, err);
  out = in.bytes(len);
  return in.ok() || truncated(in, err);
}

// A count of items that each take at least `minBytes` must fit in what is
// left of the file - rejects absurd counts before anything is allocated.
bool plausibleCount(ByteReader &in, uint64_t count, std::size_t minBytes) {
  return minBytes == 0 || count <= in.remaining() / minBytes;
}

bool readEntries(ByteReader &in, std::unordered_map<std::string, Value> &out, std::string &err,
                 int depth) {
  const uint64_t count = in.u64();
  if (!in.ok() || !plausibleCount(in, count, 4 + 2))
    return truncated(in, err);
  out.reserve(static_cast<std::size_t>(count));
  for (uint64_t i = 0; i < count; i++) {
    std::string key;
    if (!readShortString(in, key, err))
      return false;
    Value v;
    if (!readValueNode(in, v, err, depth + 1))
      return false;
    out[key] = std::move(v);
  }
  return true;
}

// The dims of an N-D node (rank >= 3, every dim > 0), checked against what
// is left of the file: each element takes at least `minBytes`.
bool readNDShape(ByteReader &in, uint8_t rank, std::size_t minBytes, std::vector<std::size_t> &shape,
                 std::size_t &count, std::string &err) {
  if (rank < 3 || rank > ndat::kMaxRank)
    return fail(err, "unsupported N-D matrix rank " + std::to_string(rank));
  shape.clear();
  count = 1;
  for (uint8_t i = 0; i < rank; i++) {
    const uint64_t d = in.u64();
    if (!in.ok())
      return truncated(in, err);
    if (d == 0)
      return fail(err, "empty N-D matrix in file");
    if (count > in.remaining() / minBytes / d)
      return truncated(in, err);
    count *= static_cast<std::size_t>(d);
    shape.push_back(static_cast<std::size_t>(d));
  }
  return true;
}

bool readTensor(ByteReader &in, Value &out, std::string &err) {
  const uint8_t elemTag = in.u8();
  const int16_t l = in.i16(), t = in.i16(), m = in.i16();
  const uint8_t rank = in.u8();
  if (!in.ok())
    return truncated(in, err);
  if (elemTag != ndat::TAG_FLOAT64 && elemTag != ndat::TAG_COMPLEX128)
    return fail(err, "unsupported tensor element type " + hexTag(elemTag));
  if (rank >= 3) {
    // N-D: the in-memory storage order, read as one block.
    const std::size_t ndStride = elemTag == ndat::TAG_COMPLEX128 ? 2 : 1;
    std::vector<std::size_t> shape;
    std::size_t count = 0;
    if (!readNDShape(in, rank, sizeof(double) * ndStride, shape, count, err))
      return false;
    nc::F64Buf buf(count * ndStride); // read in full, or the read fails
    if (!in.f64Array(buf.data(), buf.size()))
      return truncated(in, err);
    out = Value::ndPacked(std::move(shape), std::move(buf), ndStride == 2, l, t, m);
    return true;
  }
  if (rank != 1 && rank != 2)
    return fail(err, "unsupported tensor rank " + std::to_string(rank));

  uint64_t rows = in.u64();
  uint64_t cols = rank == 2 ? in.u64() : 1;
  if (!in.ok())
    return truncated(in, err);
  const std::size_t stride = elemTag == ndat::TAG_COMPLEX128 ? 2 : 1;
  if (rows != 0 && cols > in.remaining() / sizeof(double) / rows / stride)
    return truncated(in, err);
  const std::size_t count = static_cast<std::size_t>(rows * cols);
  if (count == 0)
    return fail(err, "empty tensor (empty arrays are stored as cells)");

  std::vector<double> buf(count * stride);
  if (!in.f64Array(buf.data(), buf.size()))
    return truncated(in, err);

  const bool unitless = l == 0 && t == 0 && m == 0;
  if (unitless) {
    if (stride == 2) {
      const auto *data = reinterpret_cast<const std::complex<double> *>(buf.data());
      out = rank == 2 ? Value::packedComplexMatrix(data, rows, cols)
                      : Value::packedComplexArray(data, count);
    } else {
      out = rank == 2 ? Value::packedMatrix(buf.data(), rows, cols)
                      : Value::packedArray(buf.data(), count);
    }
    return true;
  }

  // With a unit: build the elements and let the Value constructors pack
  // them (the packed-buffer factories above are unitless only).
  auto element = [&](std::size_t k) {
    Value e = stride == 2 && buf[2 * k + 1] != 0.0 ? Value::complexNumber(buf[2 * k], buf[2 * k + 1])
                                                   : Value(buf[k * stride]);
    applyUnits(e, l, t, m);
    return e;
  };
  if (rank == 1) {
    std::vector<Value> elems;
    elems.reserve(count);
    for (std::size_t k = 0; k < count; k++)
      elems.push_back(element(k));
    out = Value(std::move(elems));
  } else {
    std::vector<std::vector<Value>> matrix(rows, std::vector<Value>(cols));
    for (std::size_t c = 0; c < cols; c++)
      for (std::size_t r = 0; r < rows; r++)
        matrix[r][c] = element(c * rows + r); // column-major on disk
    out = Value(std::move(matrix));
  }
  return true;
}

bool readInt(ByteReader &in, uint8_t tag, Value &out, std::string &err) {
  switch (tag) {
  case ndat::TAG_INT8:
    out = Value::integerSigned(IntType::Int8, static_cast<int8_t>(in.u8()));
    break;
  case ndat::TAG_INT16:
    out = Value::integerSigned(IntType::Int16, static_cast<int16_t>(in.u16()));
    break;
  case ndat::TAG_INT32:
    out = Value::integerSigned(IntType::Int32, static_cast<int32_t>(in.u32()));
    break;
  case ndat::TAG_INT64:
    out = Value::integerSigned(IntType::Int64, static_cast<int64_t>(in.u64()));
    break;
  case ndat::TAG_UINT8:
    out = Value::integerUnsigned(IntType::UInt8, in.u8());
    break;
  case ndat::TAG_UINT16:
    out = Value::integerUnsigned(IntType::UInt16, in.u16());
    break;
  case ndat::TAG_UINT32:
    out = Value::integerUnsigned(IntType::UInt32, in.u32());
    break;
  case ndat::TAG_UINT64:
    out = Value::integerUnsigned(IntType::UInt64, in.u64());
    break;
  default:
    return fail(err, "this version of NC cannot hold a value of type tag " + hexTag(tag) +
                         " (int128/int256 and float128/float256 are reserved for later)");
  }
  return in.ok() || truncated(in, err);
}

// A run of typed scalar nodes - one tag, one flags byte, one unit - as a
// typed tensor's cells are written (NdatWriter, writeTypedCells). Reading
// them straight into the tensor's raw buffer gives the value packing the
// per-node Values made, without a 32-byte Value per element (2026-11-20:
// restoring a 628-million-element float16 needed ~20 GB). The first node
// that differs ends the run; the caller reads on node by node from there.
struct TypedRun {
  uint8_t tag = 0, flags = 0;
  uint8_t unitBytes[6] = {};
  int16_t l = 0, t = 0, m = 0;
  ElemType et = ElemType::F64;
  std::size_t payload = 0, header = 2;

  // The node at the cursor starts a run: false when it is not a typed scalar.
  bool start(const ByteReader &in) {
    if (in.remaining() < 2)
      return false;
    const uint8_t *p = in.cursor();
    tag = p[0];
    flags = p[1];
    if (flags & ~ndat::kKnownFlags)
      return false;
    switch (tag) {
    case ndat::TAG_INT8: et = ElemType::I8; payload = 1; break;
    case ndat::TAG_INT16: et = ElemType::I16; payload = 2; break;
    case ndat::TAG_INT32: et = ElemType::I32; payload = 4; break;
    case ndat::TAG_INT64: et = ElemType::I64; payload = 8; break;
    case ndat::TAG_UINT8: et = ElemType::U8; payload = 1; break;
    case ndat::TAG_UINT16: et = ElemType::U16; payload = 2; break;
    case ndat::TAG_UINT32: et = ElemType::U32; payload = 4; break;
    case ndat::TAG_UINT64: et = ElemType::U64; payload = 8; break;
    case ndat::TAG_BOOL: et = ElemType::Bool; payload = 1; break;
    case ndat::TAG_FLOAT8: et = ElemType::F8; payload = 1; break;
    case ndat::TAG_FLOAT16: et = ElemType::F16; payload = 2; break;
    case ndat::TAG_FLOAT32: et = ElemType::F32; payload = 4; break;
    default: return false;
    }
    header = 2;
    if (flags & ndat::FLAG_HAS_UNITS) {
      if (in.remaining() < 8)
        return false;
      std::memcpy(unitBytes, p + 2, 6);
      l = static_cast<int16_t>(p[2] | (p[3] << 8));
      t = static_cast<int16_t>(p[4] | (p[5] << 8));
      m = static_cast<int16_t>(p[6] | (p[7] << 8));
      header = 8;
    }
    return true;
  }

  // The node at the cursor belongs to the run: its element goes to `dst`
  // (elemTypeBytes(et) bytes) and the node is read. False: left unread.
  bool next(ByteReader &in, uint8_t *dst) const {
    const std::size_t node = header + payload;
    if (in.remaining() < node)
      return false;
    const uint8_t *p = in.cursor();
    if (p[0] != tag || p[1] != flags || (header == 8 && std::memcmp(p + 2, unitBytes, 6) != 0))
      return false;
    const uint8_t *q = p + header;
    uint64_t bits = 0;
    for (std::size_t i = 0; i < payload; i++)
      bits |= static_cast<uint64_t>(q[i]) << (8 * i);
    float f;
    switch (et) {
    case ElemType::Bool: *dst = bits != 0 ? 1 : 0; break;
    // float16 / float8: stored in their own bits (2 / 1 bytes), decoded and
    // encoded again so a NaN is the one canonical NaN, as per-node reading
    // and packing gives.
    case ElemType::F8: ncfloat::storeF8(dst, decodeFloatBits(FloatType::Float8, static_cast<uint32_t>(bits))); break;
    case ElemType::F16: ncfloat::storeF16(dst, decodeFloatBits(FloatType::Float16, static_cast<uint32_t>(bits))); break;
    case ElemType::F32: f = static_cast<float>(decodeFloatBits(FloatType::Float32, static_cast<uint32_t>(bits))); std::memcpy(dst, &f, 4); break;
    default: std::memcpy(dst, q, payload); break; // an integer: its little-endian bytes as they are
    }
    in.skip(node);
    return true;
  }

  // The Value readValueNode() makes of one element of the run.
  Value scalar(const uint8_t *src) const {
    int64_t bits;
    double x;
    ncpacked::typedElement(et, src, 0, bits, x);
    Value v = Value::typedScalar(et, bits, x);
    applyUnits(v, l, t, m);
    return v;
  }
};

} // namespace

bool readValueNode(ByteReader &in, Value &out, std::string &err, int depth) {
  if (depth > ndat::kMaxNestingDepth)
    return fail(err, "values nested too deeply");

  const uint8_t tag = in.u8();
  const uint8_t flags = in.u8();
  if (!in.ok())
    return truncated(in, err);
  if (flags & ~ndat::kKnownFlags)
    return fail(err, "file uses features newer than this version of NC (node flags)");
  int16_t l = 0, t = 0, m = 0;
  if (flags & ndat::FLAG_HAS_UNITS) {
    l = in.i16();
    t = in.i16();
    m = in.i16();
    if (!in.ok())
      return truncated(in, err);
  }

  switch (tag) {
  case ndat::TAG_BOOL: {
    const uint8_t b = in.u8();
    if (!in.ok())
      return truncated(in, err);
    out = Value::boolean(b != 0);
    break;
  }

  case ndat::TAG_FLOAT64:
    out = Value(in.f64());
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_FLOAT8:
    out = Value::floating(FloatType::Float8, decodeFloatBits(FloatType::Float8, in.u8()));
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_FLOAT16:
    out = Value::floating(FloatType::Float16, decodeFloatBits(FloatType::Float16, in.u16()));
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_FLOAT32:
    out = Value::floating(FloatType::Float32, decodeFloatBits(FloatType::Float32, in.u32()));
    if (!in.ok())
      return truncated(in, err);
    break;

  case ndat::TAG_TIMESTAMP:
  case ndat::TAG_DURATION: {
    const int64_t ns = static_cast<int64_t>(in.u64());
    if (!in.ok())
      return truncated(in, err);
    if (flags & ndat::FLAG_HAS_UNITS)
      return fail(err, "a timestamp or duration cannot carry a physical unit");
    out = tag == ndat::TAG_TIMESTAMP ? Value::timestamp(ns) : Value::duration(ns);
    return true;
  }

  case ndat::TAG_COMPLEX128: {
    const double re = in.f64();
    const double im = in.f64();
    if (!in.ok())
      return truncated(in, err);
    out = Value::complexNumber(re, im);
    break;
  }

  case ndat::TAG_UTF8: {
    const uint64_t len = in.u64();
    if (!in.ok() || len > in.remaining())
      return truncated(in, err);
    out = Value(in.bytes(static_cast<std::size_t>(len)));
    break;
  }

  case ndat::TAG_NUM_TENSOR:
    if (!readTensor(in, out, err))
      return false;
    break;

  case ndat::TAG_TYPED_RAW: {
    // A typed tensor as its raw buffer (session autosave, NdatTypes.h): one
    // block copy.
    const int16_t ul = in.i16(), ut = in.i16(), um = in.i16();
    const uint8_t elemTag = in.u8();
    const uint8_t rank = in.u8();
    if (!in.ok() || rank < 1 || rank > 32)
      return truncated(in, err);
    ElemType et;
    switch (elemTag) {
    case ndat::TAG_INT8: et = ElemType::I8; break;
    case ndat::TAG_INT16: et = ElemType::I16; break;
    case ndat::TAG_INT32: et = ElemType::I32; break;
    case ndat::TAG_INT64: et = ElemType::I64; break;
    case ndat::TAG_UINT8: et = ElemType::U8; break;
    case ndat::TAG_UINT16: et = ElemType::U16; break;
    case ndat::TAG_UINT32: et = ElemType::U32; break;
    case ndat::TAG_UINT64: et = ElemType::U64; break;
    case ndat::TAG_BOOL: et = ElemType::Bool; break;
    case ndat::TAG_FLOAT8: et = ElemType::F8; break;
    case ndat::TAG_FLOAT16: et = ElemType::F16; break;
    case ndat::TAG_FLOAT32: et = ElemType::F32; break;
    default: return fail(err, "unknown element tag " + hexTag(elemTag) + " in a typed tensor");
    }
    std::vector<std::size_t> shape(rank);
    std::size_t count = 1;
    const std::size_t w = elemTypeBytes(et);
    for (auto &d : shape) {
      d = static_cast<std::size_t>(in.u64());
      if (!in.ok() || (d != 0 && count > in.remaining() / w / d))
        return truncated(in, err);
      count *= d;
    }
    if (count == 0 || !ByteSink::hostIsLittleEndian() || !in.need(count * w))
      return truncated(in, err);
    std::vector<uint8_t> raw(in.cursor(), in.cursor() + count * w);
    in.skip(count * w);
    out = Value::typedTensor(et, std::move(shape), std::move(raw), ul, ut, um);
    break;
  }

  case ndat::TAG_NUM_RANGE: {
    // A lazy range kept as its rule (session autosave, NdatTypes.h): back
    // as the same lazy value - nothing is built.
    const int16_t ul = in.i16(), ut = in.i16(), um = in.i16();
    const uint8_t rank = in.u8();
    if (!in.ok() || (rank != 1 && rank != 2))
      return truncated(in, err);
    std::vector<std::size_t> shape(rank);
    for (auto &d : shape)
      d = static_cast<std::size_t>(in.u64());
    ncrange::Spec spec;
    spec.first = in.f64();
    spec.step = in.f64();
    spec.end = in.f64();
    spec.closed = in.u8() != 0;
    spec.count = static_cast<int64_t>(in.u64());
    spec.snapLast = in.u8() != 0;
    // The arithmetic chain (2026-11-21): u8 count, then (u8 kind, f64 c) each.
    const uint8_t nOps = in.u8();
    std::vector<NumTensor::LazyOp> ops;
    for (uint8_t i = 0; i < nOps && in.ok(); i++) {
      const uint8_t kind = in.u8();
      const double c = in.f64();
      if (kind > static_cast<uint8_t>(NumTensor::LazyOpKind::Neg))
        return fail(err, "file is truncated or corrupt (range)");
      ops.push_back({static_cast<NumTensor::LazyOpKind>(kind), c});
    }
    if (nOps > NumTensor::kMaxLazyOps)
      return fail(err, "file is truncated or corrupt (range)");
    std::size_t n = 1;
    for (std::size_t d : shape)
      n *= d;
    if (!in.ok() || spec.count < 1 || static_cast<std::size_t>(spec.count) != n || spec.step == 0.0)
      return fail(err, "file is truncated or corrupt (range)");
    Value row = Value::lazyRow(spec); // 1 x count
    if (rank == 1)
      out = row.packedVectorAsArray();
    else if (shape[0] == 1)
      out = row;
    else
      out = row.packedVectorAsArray().packedArrayAsVector(/*column=*/true);
    for (const NumTensor::LazyOp &op : ops) {
      Value next;
      if (!out.withLazyOp(op.kind, op.c, next))
        return fail(err, "file is truncated or corrupt (range)");
      out = std::move(next);
    }
    out.setUnitDims(ul, ut, um);
    break;
  }

  case ndat::TAG_CELL_ARRAY: {
    const uint64_t n = in.u64();
    if (!in.ok() || !plausibleCount(in, n, 2))
      return truncated(in, err);
    std::vector<Value> elems;
    uint64_t first = 0; // elements read by the typed run below
    TypedRun run;
    if (n > 0 && depth + 1 <= ndat::kMaxNestingDepth && run.start(in)) {
      const std::size_t w = elemTypeBytes(run.et);
      std::vector<uint8_t> raw(static_cast<std::size_t>(n) * w);
      while (first < n && run.next(in, raw.data() + first * w))
        first++;
      if (first == n) {
        out = Value::typedTensor(run.et, {static_cast<std::size_t>(n)}, std::move(raw), run.l, run.t,
                                 run.m);
        break;
      }
      elems.reserve(static_cast<std::size_t>(n));
      for (uint64_t k = 0; k < first; k++)
        elems.push_back(run.scalar(raw.data() + k * w));
    }
    elems.reserve(static_cast<std::size_t>(n));
    for (uint64_t i = first; i < n; i++) {
      Value e;
      if (!readValueNode(in, e, err, depth + 1))
        return false;
      elems.push_back(std::move(e));
    }
    out = Value(std::move(elems));
    break;
  }

  case ndat::TAG_CELL_MATRIX: {
    const uint64_t rows = in.u64();
    if (!in.ok() || !plausibleCount(in, rows, 8))
      return truncated(in, err);
    std::vector<std::vector<Value>> matrix;
    matrix.reserve(static_cast<std::size_t>(rows));
    uint64_t r = 0;
    std::vector<Value> row;      // the row being read (cells so far)
    bool havePending = false;    // row r's length was read already
    uint64_t pendingLen = 0;
    if (rows > 0 && depth + 1 <= ndat::kMaxNestingDepth) {
      // A typed tensor's cells (TypedRun): every row the same length, every
      // node one typed scalar - straight into the column-major raw buffer.
      const uint64_t len0 = in.u64();
      if (!in.ok() || !plausibleCount(in, len0, 2))
        return truncated(in, err);
      havePending = true;
      pendingLen = len0;
      TypedRun run;
      if (len0 > 0 && rows <= in.remaining() / 2 / len0 && run.start(in)) {
        const std::size_t R = static_cast<std::size_t>(rows), C = static_cast<std::size_t>(len0);
        const std::size_t w = elemTypeBytes(run.et);
        std::vector<uint8_t> raw(R * C * w);
        std::size_t rr = 0, cc = 0;
        bool broke = false;
        for (rr = 0; rr < R; rr++) {
          if (rr > 0) {
            const uint64_t len = in.u64();
            if (!in.ok() || !plausibleCount(in, len, 2))
              return truncated(in, err);
            if (len != len0) {
              pendingLen = len;
              cc = 0;
              broke = true;
              break;
            }
          }
          for (cc = 0; cc < C; cc++)
            if (!run.next(in, raw.data() + (cc * R + rr) * w))
              break;
          if (cc < C) {
            pendingLen = len0;
            broke = true;
            break;
          }
        }
        if (!broke) {
          out = Value::typedTensor(run.et, {R, C}, std::move(raw), run.l, run.t, run.m);
          break;
        }
        // Rows 0..rr-1 complete, row rr has cc cells: on node by node.
        for (std::size_t k = 0; k < rr; k++) {
          std::vector<Value> full;
          full.reserve(C);
          for (std::size_t c = 0; c < C; c++)
            full.push_back(run.scalar(raw.data() + (c * R + k) * w));
          matrix.push_back(std::move(full));
        }
        for (std::size_t c = 0; c < cc; c++)
          row.push_back(run.scalar(raw.data() + (c * R + rr) * w));
        r = rr;
      }
    }
    for (; r < rows; r++) {
      uint64_t len = pendingLen;
      if (!havePending) {
        len = in.u64();
        if (!in.ok() || !plausibleCount(in, len, 2))
          return truncated(in, err);
      }
      havePending = false;
      row.reserve(static_cast<std::size_t>(len));
      for (uint64_t c = row.size(); c < len; c++) {
        Value e;
        if (!readValueNode(in, e, err, depth + 1))
          return false;
        row.push_back(std::move(e));
      }
      matrix.push_back(std::move(row));
      row = std::vector<Value>();
    }
    out = Value(std::move(matrix));
    break;
  }

  case ndat::TAG_CELL_ND: {
    const uint8_t rank = in.u8();
    if (!in.ok())
      return truncated(in, err);
    std::vector<std::size_t> shape;
    std::size_t count = 0;
    if (!readNDShape(in, rank, 2, shape, count, err))
      return false;
    std::vector<Value> cells;
    cells.reserve(count);
    for (std::size_t k = 0; k < count; k++) {
      Value e;
      if (!readValueNode(in, e, err, depth + 1))
        return false;
      cells.push_back(std::move(e));
    }
    out = nd::build(std::move(shape), std::move(cells));
    break;
  }

  case ndat::TAG_DICT: {
    std::unordered_map<std::string, Value> entries;
    if (!readEntries(in, entries, err, depth))
      return false;
    out = Value(entries);
    break;
  }

  case ndat::TAG_OBJECT: {
    Value obj;
    obj.isObject = true;
    if (!readShortString(in, obj.classNameMut(), err))
      return false;
    if (!readEntries(in, obj.dictMut(), err, depth))
      return false;
    const uint64_t lineageCount = in.u64();
    if (!in.ok() || !plausibleCount(in, lineageCount, 4))
      return truncated(in, err);
    for (uint64_t i = 0; i < lineageCount; i++) {
      std::string entry;
      if (!readShortString(in, entry, err))
        return false;
      obj.lineageMut().push_back(std::move(entry));
    }
    const uint64_t snapshotCount = in.u64();
    if (!in.ok() || !plausibleCount(in, snapshotCount, 8))
      return truncated(in, err);
    for (uint64_t i = 0; i < snapshotCount; i++) {
      std::unordered_map<std::string, Value> snapshot;
      if (!readEntries(in, snapshot, err, depth))
        return false;
      obj.snapshotsMut().push_back(std::move(snapshot));
    }
    const double lastTick = in.f64();
    if (!in.ok())
      return truncated(in, err);
    if (lastTick != -1.0)
      obj.lastTickTimeMut() = lastTick;
    out = std::move(obj);
    break;
  }

  case ndat::TAG_FUNC_REF: {
    Value ref;
    ref.isFunctionRef = true;
    if (!readShortString(in, ref.funcRefNameMut(), err))
      return false;
    out = std::move(ref);
    break;
  }

  default:
    if (tag >= ndat::TAG_INT8 && tag <= ndat::TAG_UINT256) {
      if (!readInt(in, tag, out, err))
        return false;
      break;
    }
    if (tag == ndat::TAG_FLOAT128 || tag == ndat::TAG_FLOAT256)
      return fail(err, "this version of NC cannot hold a value of type tag " + hexTag(tag) +
                           " (float128/float256 are reserved for later)");
    return fail(err, "unknown value type tag " + hexTag(tag) +
                         " (written by a newer version of NC?)");
  }

  applyUnits(out, l, t, m);
  return true;
}

bool readNdatImage(const std::vector<uint8_t> &image, NamedValues &out, std::string &err) {
  if (image.size() < ndat::kHeaderSize + ndat::kFooterSize ||
      std::memcmp(image.data(), ndat::kMagic, 4) != 0)
    return fail(err, "not an .ndat file");

  ByteReader header(image.data(), ndat::kHeaderSize);
  header.skip(4);
  const uint16_t major = header.u16();
  const uint16_t minor = header.u16();
  const uint8_t endian = header.u8();
  if (major != ndat::kVersionMajor)
    return fail(err, ".ndat version " + std::to_string(major) + "." + std::to_string(minor) +
                         " is not supported by this version of NC (expects " +
                         std::to_string(ndat::kVersionMajor) + ".x)");
  if (endian != ndat::kEndianLittle)
    return fail(err, "unsupported byte order in .ndat header");
  header.skip(1 + 2); // header flags, reserved
  const uint32_t varCount = header.u32();

  // Footer: "NEND" + CRC-32 over everything before the CRC itself.
  const std::size_t footerAt = image.size() - ndat::kFooterSize;
  if (std::memcmp(image.data() + footerAt, ndat::kEndMagic, 4) != 0)
    return fail(err, "file is truncated (no end marker)");
  ByteReader crcReader(image.data() + footerAt + 4, 4);
  const uint32_t storedCrc = crcReader.u32();
  Crc32 crc;
  crc.update(image.data(), footerAt + 4);
  if (crc.value() != storedCrc)
    return fail(err, "file is corrupt (checksum mismatch)");

  ByteReader in(image.data() + ndat::kHeaderSize, footerAt - ndat::kHeaderSize);
  NamedValues vars;
  vars.reserve(varCount);
  for (uint32_t i = 0; i < varCount; i++) {
    const uint32_t nameLen = in.u32();
    if (!in.ok() || nameLen == 0 || nameLen > ndat::kMaxNameBytes || nameLen > in.remaining())
      return truncated(in, err);
    std::string name = in.bytes(nameLen);
    Value v;
    if (!readValueNode(in, v, err))
      return false;
    vars.emplace_back(std::move(name), std::move(v));
  }
  if (in.remaining() != 0)
    return fail(err, "file is corrupt (unexpected data after the last variable)");

  out = std::move(vars);
  return true;
}

bool readNdatFile(const std::filesystem::path &path, NamedValues &out, std::string &err) {
  std::error_code ec;
  if (!std::filesystem::is_regular_file(path, ec))
    return fail(err, "file not found: " + path.u8string());
  std::ifstream file(path, std::ios::binary);
  if (!file)
    return fail(err, "cannot open " + path.u8string());
  // One read of the known size (2026-11-21): the byte-by-byte stream
  // iterator it replaces took ~10 s per GB on an autosave restore.
  const auto size = std::filesystem::file_size(path, ec);
  if (ec)
    return fail(err, "cannot read " + path.u8string());
  std::vector<uint8_t> image(static_cast<std::size_t>(size));
  if (size > 0 && !file.read(reinterpret_cast<char *>(image.data()), static_cast<std::streamsize>(size)))
    return fail(err, "cannot read " + path.u8string());
  if (!readNdatImage(image, out, err)) {
    err = path.filename().u8string() + ": " + err;
    return false;
  }
  return true;
}

} // namespace ncdata
