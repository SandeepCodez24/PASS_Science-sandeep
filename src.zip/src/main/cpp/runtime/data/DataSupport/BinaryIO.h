#pragma once

// Little-endian byte encoding shared by the .ndat writer and reader, plus
// the two checksums the data layer uses:
//   - CRC-32 (IEEE 802.3, the zlib/PNG one) - the .ndat file footer.
//   - a 64-bit hash (XXH64 since 2026-11-20, FNV-1a before) - per-variable
//     change detection for the IDE channel.
//
// Everything is written byte by byte in little-endian order regardless of
// the machine, so a file written on one platform reads on any other. Bulk
// float64 data takes a memcpy fast path on little-endian hosts.

#include <cstdint>
#include <cstring>
#include <algorithm>
#include <fstream>
#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace ncdata {

/* ================= checksums ================= */

// The standard CRC-32 (same values as zlib's crc32()). Since 2026-11-20 it
// takes 8 bytes per step ("slicing-by-8") on little-endian hosts - about
// 2-3 GB/s instead of ~0.4 GB/s byte by byte - with identical results; a
// 479 MB autosave or .ndat load no longer spends a second on its checksum.
class Crc32 {
public:
  void update(const uint8_t *data, std::size_t n) {
    static const Tables tables;
    const uint32_t(*t)[256] = tables.t;
    uint32_t c = state_;
    if (littleEndian()) {
      for (; n >= 8; n -= 8, data += 8) {
        uint32_t lo, hi;
        std::memcpy(&lo, data, 4);
        std::memcpy(&hi, data + 4, 4);
        lo ^= c;
        c = t[7][lo & 0xFFu] ^ t[6][(lo >> 8) & 0xFFu] ^ t[5][(lo >> 16) & 0xFFu] ^ t[4][lo >> 24] ^
            t[3][hi & 0xFFu] ^ t[2][(hi >> 8) & 0xFFu] ^ t[1][(hi >> 16) & 0xFFu] ^ t[0][hi >> 24];
      }
    }
    for (std::size_t i = 0; i < n; i++)
      c = t[0][(c ^ data[i]) & 0xFFu] ^ (c >> 8);
    state_ = c;
  }
  uint32_t value() const { return state_ ^ 0xFFFFFFFFu; }

private:
  struct Tables {
    uint32_t t[8][256];
    Tables() {
      for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++)
          c = (c & 1u) ? 0xEDB88320u ^ (c >> 1) : (c >> 1);
        t[0][i] = c;
      }
      for (uint32_t i = 0; i < 256; i++)
        for (int k = 1; k < 8; k++)
          t[k][i] = (t[k - 1][i] >> 8) ^ t[0][t[k - 1][i] & 0xFFu];
    }
  };
  static bool littleEndian() {
    const uint16_t probe = 1;
    uint8_t first;
    std::memcpy(&first, &probe, 1);
    return first == 1;
  }
  uint32_t state_ = 0xFFFFFFFFu;
};

// XXH64 (Yann Collet's xxHash, 64-bit), chained across update() calls: each
// call hashes its bytes with the running state as the seed. Used for change
// detection only (valueFingerprint(), the IDE's workspace signature) - the
// numbers never leave the session, so the exact function is free to change.
// Since 2026-11-20 it replaces FNV-1a, which took one multiply per byte
// (~0.6 GB/s); this takes 8 bytes per step in four lanes (~10 GB/s): a
// 479 MB variable is fingerprinted in ~50 ms instead of ~1 s at every prompt.
class FastHash64 {
public:
  void update(const uint8_t *data, std::size_t n) { state_ = xxh64(data, n, state_); }
  uint64_t value() const { return state_; }

  static uint64_t xxh64(const uint8_t *p, std::size_t len, uint64_t seed) {
    const uint8_t *const end = p + len;
    uint64_t h;
    if (len >= 32) {
      const uint8_t *const limit = end - 32;
      uint64_t v1 = seed + P1 + P2, v2 = seed + P2, v3 = seed, v4 = seed - P1;
      do {
        v1 = round(v1, read64(p));
        v2 = round(v2, read64(p + 8));
        v3 = round(v3, read64(p + 16));
        v4 = round(v4, read64(p + 24));
        p += 32;
      } while (p <= limit);
      h = rotl(v1, 1) + rotl(v2, 7) + rotl(v3, 12) + rotl(v4, 18);
      h = merge(h, v1);
      h = merge(h, v2);
      h = merge(h, v3);
      h = merge(h, v4);
    } else {
      h = seed + P5;
    }
    h += static_cast<uint64_t>(len);
    return finish(h, p, end);
  }

  // XXH64 fed piece by piece: digest() equals xxh64(all bytes, seed) of the
  // pieces joined (2026-11-20; for a lazy range, whose bytes are generated
  // in chunks and never held whole).
  class Stream {
  public:
    explicit Stream(uint64_t seed = 0)
        : seed_(seed), v1_(seed + P1 + P2), v2_(seed + P2), v3_(seed), v4_(seed - P1) {}
    void update(const uint8_t *p, std::size_t len) {
      total_ += len;
      if (memSize_ + len < 32) {
        std::memcpy(mem_ + memSize_, p, len);
        memSize_ += len;
        return;
      }
      if (memSize_) {
        const std::size_t fill = 32 - memSize_;
        std::memcpy(mem_ + memSize_, p, fill);
        stripe(mem_);
        p += fill;
        len -= fill;
        memSize_ = 0;
      }
      for (; len >= 32; p += 32, len -= 32)
        stripe(p);
      if (len) {
        std::memcpy(mem_, p, len);
        memSize_ = len;
      }
    }
    uint64_t digest() const {
      uint64_t h;
      if (total_ >= 32) {
        h = rotl(v1_, 1) + rotl(v2_, 7) + rotl(v3_, 12) + rotl(v4_, 18);
        h = merge(h, v1_);
        h = merge(h, v2_);
        h = merge(h, v3_);
        h = merge(h, v4_);
      } else {
        h = seed_ + P5;
      }
      h += total_;
      return finish(h, mem_, mem_ + memSize_);
    }

  private:
    void stripe(const uint8_t *p) {
      v1_ = round(v1_, read64(p));
      v2_ = round(v2_, read64(p + 8));
      v3_ = round(v3_, read64(p + 16));
      v4_ = round(v4_, read64(p + 24));
    }
    uint64_t seed_, v1_, v2_, v3_, v4_;
    uint64_t total_ = 0;
    uint8_t mem_[32] = {};
    std::size_t memSize_ = 0;
  };

private:
  // The tail (fewer than 32 bytes) and the final mix, shared by xxh64()
  // and Stream.
  static uint64_t finish(uint64_t h, const uint8_t *p, const uint8_t *end) {
    for (; p + 8 <= end; p += 8) {
      h ^= round(0, read64(p));
      h = rotl(h, 27) * P1 + P4;
    }
    if (p + 4 <= end) {
      uint32_t k;
      std::memcpy(&k, p, 4);
      h ^= static_cast<uint64_t>(k) * P1;
      h = rotl(h, 23) * P2 + P3;
      p += 4;
    }
    for (; p < end; p++) {
      h ^= static_cast<uint64_t>(*p) * P5;
      h = rotl(h, 11) * P1;
    }
    h ^= h >> 33;
    h *= P2;
    h ^= h >> 29;
    h *= P3;
    h ^= h >> 32;
    return h;
  }
  static constexpr uint64_t P1 = 0x9E3779B185EBCA87ull;
  static constexpr uint64_t P2 = 0xC2B2AE3D27D4EB4Full;
  static constexpr uint64_t P3 = 0x165667B19E3779F9ull;
  static constexpr uint64_t P4 = 0x85EBCA77C2B2AE63ull;
  static constexpr uint64_t P5 = 0x27D4EB2F165667C5ull;
  static uint64_t rotl(uint64_t x, int r) { return (x << r) | (x >> (64 - r)); }
  static uint64_t read64(const uint8_t *p) {
    uint64_t v;
    std::memcpy(&v, p, 8);
    return v;
  }
  static uint64_t round(uint64_t acc, uint64_t input) {
    acc += input * P2;
    acc = rotl(acc, 31);
    return acc * P1;
  }
  static uint64_t merge(uint64_t acc, uint64_t val) {
    acc ^= round(0, val);
    return acc * P1 + P4;
  }
  uint64_t state_ = 0;
};

class Fnv1a64 {
public:
  void update(const uint8_t *data, std::size_t n) {
    uint64_t h = state_;
    for (std::size_t i = 0; i < n; i++) {
      h ^= data[i];
      h *= 0x100000001B3ull;
    }
    state_ = h;
  }
  uint64_t value() const { return state_; }

private:
  uint64_t state_ = 0xCBF29CE484222325ull;
};

/* ================= output ================= */

// Where encoded bytes go. The writer encodes a value once and the sink
// decides what happens to the bytes: a file, a memory buffer, or only a
// running hash (change detection never builds the bytes at all).
class ByteSink {
public:
  virtual ~ByteSink() = default;
  virtual void write(const uint8_t *data, std::size_t n) = 0;

  void u8(uint8_t v) { write(&v, 1); }
  void u16(uint16_t v) {
    uint8_t b[2] = {static_cast<uint8_t>(v), static_cast<uint8_t>(v >> 8)};
    write(b, 2);
  }
  void u32(uint32_t v) {
    uint8_t b[4];
    for (int i = 0; i < 4; i++)
      b[i] = static_cast<uint8_t>(v >> (8 * i));
    write(b, 4);
  }
  void u64(uint64_t v) {
    uint8_t b[8];
    for (int i = 0; i < 8; i++)
      b[i] = static_cast<uint8_t>(v >> (8 * i));
    write(b, 8);
  }
  void i16(int16_t v) { u16(static_cast<uint16_t>(v)); }
  void f64(double v) {
    uint64_t bits;
    std::memcpy(&bits, &v, sizeof bits);
    u64(bits);
  }
  // `n` consecutive float64 values.
  void f64Array(const double *data, std::size_t n) {
    if (hostIsLittleEndian()) {
      write(reinterpret_cast<const uint8_t *>(data), n * sizeof(double));
      return;
    }
    for (std::size_t i = 0; i < n; i++)
      f64(data[i]);
  }
  void bytes(const std::string &s) {
    write(reinterpret_cast<const uint8_t *>(s.data()), s.size());
  }
  // A whole packed buffer, with its NumTensor stamp (equal stamps mean
  // equal bytes; 0 = unknown). A file or memory sink writes the doubles
  // exactly as f64Array() does; HashSink may use the stamp to skip
  // re-hashing a big buffer it has seen before.
  virtual void f64Bulk(const double *data, std::size_t n, uint64_t stamp) {
    (void)stamp;
    f64Array(data, n);
  }

  // n doubles that gen(first, count, out) produces in order, chunk by chunk
  // (a lazy range, 2026-11-20): exactly the bytes f64Bulk() writes for the
  // same doubles, without ever holding them all.
  using Generator = std::function<void(std::size_t, std::size_t, double *)>;
  static constexpr std::size_t kGenChunk = 1u << 16;
  virtual void f64Generated(std::size_t n, uint64_t stamp, const Generator &gen) {
    if (n * sizeof(double) < (1u << 20)) { // small: as one f64Bulk(), like a real buffer
      std::vector<double> all(n);
      if (n)
        gen(0, n, all.data());
      f64Bulk(all.data(), n, stamp);
      return;
    }
    std::vector<double> chunk(kGenChunk);
    for (std::size_t k = 0; k < n; k += kGenChunk) {
      const std::size_t m = std::min(kGenChunk, n - k);
      gen(k, m, chunk.data());
      f64Array(chunk.data(), m);
    }
  }

  // True for a sink that may use the session-only nodes - a lazy range as
  // its rule (TAG_NUM_RANGE), a typed tensor as its raw buffer
  // (TAG_TYPED_RAW): only the session autosave's file sink (2026-11-21).
  virtual bool sessionNodes() const { return false; }
  // True for a sink that only hashes (HashSink): it may take a lazy tensor's
  // rule as it is - function steps included - instead of its values
  // (2026-11-23). Never true for a sink that writes a file.
  virtual bool hashOnly() const { return false; }

  // `nBytes` bytes that enc() hands to its writer piece by piece, in order
  // (2026-11-20: the per-element nodes of a typed tensor, built in chunks
  // without a Value per element). A file or memory sink writes them as
  // they come; HashSink may use the stamp - the tensor's, equal stamps mean
  // equal bytes - to skip re-hashing a big encoding it has seen before.
  using ChunkWriter = std::function<void(const uint8_t *, std::size_t)>;
  using Encoder = std::function<void(const ChunkWriter &)>;
  virtual void encoded(std::size_t nBytes, uint64_t stamp, const Encoder &enc) {
    (void)nBytes;
    (void)stamp;
    enc([this](const uint8_t *p, std::size_t n) { write(p, n); });
  }

  static bool hostIsLittleEndian() {
    const uint16_t probe = 1;
    uint8_t first;
    std::memcpy(&first, &probe, 1);
    return first == 1;
  }
};

class VectorSink : public ByteSink {
public:
  void write(const uint8_t *data, std::size_t n) override {
    buffer.insert(buffer.end(), data, data + n);
  }
  std::vector<uint8_t> buffer;
};

class HashSink : public ByteSink {
public:
  void write(const uint8_t *data, std::size_t n) override { hash.update(data, n); }
  // The fingerprint only has to change when the value does: the compact
  // session nodes (a range's rule, a typed tensor's raw block, cached by
  // stamp) say that at a fraction of the cost (2026-11-21).
  bool sessionNodes() const override { return true; }
  bool hashOnly() const override { return true; }

  // A big buffer goes into the hash as (count, XXH64 of its bytes), and that
  // XXH64 is remembered by stamp: a 479 MB variable is hashed once, not at
  // every prompt (2026-11-20). Equal bytes still give an equal fingerprint
  // whatever the stamp, since the remembered value is a hash of the bytes.
  void f64Bulk(const double *data, std::size_t n, uint64_t stamp) override {
    const std::size_t bytes = n * sizeof(double);
    if (bytes < kCacheFrom || stamp == 0 || !hostIsLittleEndian()) {
      f64Array(data, n);
      return;
    }
    uint64_t bufferHash = 0;
    if (!cached(stamp, n, bufferHash)) {
      bufferHash = FastHash64::xxh64(reinterpret_cast<const uint8_t *>(data), bytes, 0);
      remember(stamp, n, bufferHash);
    }
    u64(n);
    u64(bufferHash);
  }
  // A lazy range: the same (count, XXH64 of the bytes) as f64Bulk() gives
  // the built buffer, the XXH64 streamed over generated chunks.
  void f64Generated(std::size_t n, uint64_t stamp, const Generator &gen) override {
    const std::size_t bytes = n * sizeof(double);
    if (bytes < kCacheFrom || stamp == 0 || !hostIsLittleEndian()) {
      ByteSink::f64Generated(n, stamp, gen);
      return;
    }
    uint64_t bufferHash = 0;
    if (!cached(stamp, n, bufferHash)) {
      FastHash64::Stream stream(0);
      std::vector<double> chunk(kGenChunk);
      for (std::size_t k = 0; k < n; k += kGenChunk) {
        const std::size_t m = std::min(kGenChunk, n - k);
        gen(k, m, chunk.data());
        stream.update(reinterpret_cast<const uint8_t *>(chunk.data()), m * sizeof(double));
      }
      bufferHash = stream.digest();
      remember(stamp, n, bufferHash);
    }
    u64(n);
    u64(bufferHash);
  }
  // A big typed tensor's nodes: (byte count, XXH64 of the bytes), the XXH64
  // remembered by stamp like a float64 buffer's.
  void encoded(std::size_t nBytes, uint64_t stamp, const Encoder &enc) override {
    if (nBytes < kCacheFrom || stamp == 0) {
      ByteSink::encoded(nBytes, stamp, enc);
      return;
    }
    uint64_t bufferHash = 0;
    if (!cached(stamp, nBytes, bufferHash)) {
      FastHash64::Stream stream(0);
      enc([&stream](const uint8_t *p, std::size_t n) { stream.update(p, n); });
      bufferHash = stream.digest();
      remember(stamp, nBytes, bufferHash);
    }
    u64(nBytes);
    u64(bufferHash);
  }
  FastHash64 hash; // FNV-1a until 2026-11-20

private:
  static constexpr std::size_t kCacheFrom = 1u << 20; // 1 MiB
  struct Entry {
    std::size_t n;
    uint64_t hash;
  };
  static std::mutex &cacheMutex() {
    static std::mutex m;
    return m;
  }
  static std::unordered_map<uint64_t, Entry> &cache() {
    static std::unordered_map<uint64_t, Entry> c;
    return c;
  }
  static bool cached(uint64_t stamp, std::size_t n, uint64_t &out) {
    std::lock_guard<std::mutex> lock(cacheMutex());
    auto it = cache().find(stamp);
    if (it == cache().end() || it->second.n != n)
      return false;
    out = it->second.hash;
    return true;
  }
  static void remember(uint64_t stamp, std::size_t n, uint64_t h) {
    std::lock_guard<std::mutex> lock(cacheMutex());
    if (cache().size() >= 4096) // stamps of freed buffers pile up: start over
      cache().clear();
    cache()[stamp] = {n, h};
  }
};

// A file, with the CRC-32 of everything written so far kept alongside.
class FileSink : public ByteSink {
public:
  explicit FileSink(std::ofstream &out, bool sessionNodes = false) : out_(out), sessionNodes_(sessionNodes) {}
  void write(const uint8_t *data, std::size_t n) override {
    crc.update(data, n);
    out_.write(reinterpret_cast<const char *>(data), static_cast<std::streamsize>(n));
  }
  bool sessionNodes() const override { return sessionNodes_; }
  Crc32 crc;

private:
  std::ofstream &out_;
  bool sessionNodes_;
};

/* ================= input ================= */

// Bounds-checked little-endian reader over a byte buffer. A read past the
// end never touches memory outside the buffer: it marks the reader failed
// and returns zero, and the caller checks ok() at its own pace.
class ByteReader {
public:
  ByteReader(const uint8_t *data, std::size_t size) : data_(data), size_(size) {}

  bool ok() const { return ok_; }
  std::size_t offset() const { return pos_; }
  std::size_t remaining() const { return size_ - pos_; }
  // The unread bytes (remaining() of them), to look ahead without reading.
  const uint8_t *cursor() const { return data_ + pos_; }

  // Marks the reader failed (a structural error found by the caller).
  void fail() { ok_ = false; }

  bool need(std::size_t n) {
    if (!ok_ || n > size_ - pos_) {
      ok_ = false;
      return false;
    }
    return true;
  }

  uint8_t u8() { return need(1) ? data_[pos_++] : 0; }
  uint16_t u16() {
    if (!need(2))
      return 0;
    uint16_t v = static_cast<uint16_t>(data_[pos_] | (data_[pos_ + 1] << 8));
    pos_ += 2;
    return v;
  }
  uint32_t u32() {
    if (!need(4))
      return 0;
    uint32_t v = 0;
    for (int i = 0; i < 4; i++)
      v |= static_cast<uint32_t>(data_[pos_ + i]) << (8 * i);
    pos_ += 4;
    return v;
  }
  uint64_t u64() {
    if (!need(8))
      return 0;
    uint64_t v = 0;
    for (int i = 0; i < 8; i++)
      v |= static_cast<uint64_t>(data_[pos_ + i]) << (8 * i);
    pos_ += 8;
    return v;
  }
  int16_t i16() { return static_cast<int16_t>(u16()); }
  double f64() {
    uint64_t bits = u64();
    double v;
    std::memcpy(&v, &bits, sizeof v);
    return v;
  }
  bool f64Array(double *out, std::size_t n) {
    if (n > remaining() / sizeof(double)) {
      ok_ = false;
      return false;
    }
    if (ByteSink::hostIsLittleEndian()) {
      std::memcpy(out, data_ + pos_, n * sizeof(double));
      pos_ += n * sizeof(double);
      return true;
    }
    for (std::size_t i = 0; i < n; i++)
      out[i] = f64();
    return ok_;
  }
  std::string bytes(std::size_t n) {
    if (!need(n))
      return std::string();
    std::string s(reinterpret_cast<const char *>(data_ + pos_), n);
    pos_ += n;
    return s;
  }
  bool skip(std::size_t n) {
    if (!need(n))
      return false;
    pos_ += n;
    return true;
  }

private:
  const uint8_t *data_;
  std::size_t size_;
  std::size_t pos_ = 0;
  bool ok_ = true;
};

} // namespace ncdata
