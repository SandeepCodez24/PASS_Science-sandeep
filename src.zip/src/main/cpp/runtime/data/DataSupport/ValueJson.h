#pragma once

// Runtime Values as JSON for the IDE (WS_PROTOCOL.md).
//
// Two shapes:
//   - a SUMMARY per variable (name, class, size, unit, short preview,
//     fingerprint) - small, sent for the whole workspace whenever it
//     changes, drives the Variable Explorer;
//   - the FULL value, sent for one variable on request (@cmd getvar) -
//     for viewers, plots and editors that need the actual data.

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "../../interpreter/core/value.h"
#include "JsonWriter.h"

namespace ncdata {

struct VariableSummary {
  std::string name;
  std::string cls;     // "float64", "float32", "int64", "bool", "string", "complex", "cell", "dict", class name, ...
  std::string size;    // "1x1", "1x5", "3x4"
  std::string unit;    // "m/s", or empty
  std::string preview; // display text, length-capped
  uint64_t hash = 0;   // valueFingerprint()
};

VariableSummary summarizeVariable(const std::string &name, const Value &v, uint64_t hash);

void writeSummaryJson(JsonWriter &out, const VariableSummary &s);

// The full value. At most `elementBudget` numeric/cell elements are written
// in total; past that a container is written without its data and with
// "truncated": true. The budget is decremented as elements are written.
void writeValueJson(JsonWriter &out, const Value &v, std::size_t &elementBudget, int depth = 0);

// Windows (2026-11-20, docs/Java_Speed_CPP_Asks.md V1): one block of a big
// value for the Variable Explorer, read in place - a lazy range is computed
// from its rule, nothing is copied or fingerprinted.
//
// The value's GRID: a 1-D value of n elements is 1 x n, a 2-D one rows x
// cols, an N-D one its last two axes on the page `page` (one key per leading
// axis; missing keys are 0, keys past an axis are clamped).
//
// True for what can be windowed: an array / matrix / N-D matrix of any
// element kind (numbers, complex, typed, text, cells).
bool isWindowable(const Value &v);

// Writes, into the open @VAR object, "window" ([r0, r1, c0, c1] clamped to
// the grid), "full" (the value's own shape), "page" (N-D only) and "value":
// the block rows r0..r1-1, columns c0..c1-1 as a 2-D value - "tensor" for
// float64 / complex numbers, "cellmatrix" for anything else (typed numbers,
// text, cells), each element written exactly as a full getvar writes it.
// A block of more than kMaxWindowElements: "error" instead of "value".
constexpr std::size_t kMaxWindowElements = 1000000;
void writeWindowFields(JsonWriter &out, const Value &v, std::size_t r0, std::size_t r1, std::size_t c0,
                       std::size_t c1, const std::vector<std::size_t> &page);

// Pieces of the summary, exposed for tests and other callers.
std::string classOf(const Value &v);
std::string sizeOf(const Value &v);
std::string previewOf(const Value &v);

} // namespace ncdata
