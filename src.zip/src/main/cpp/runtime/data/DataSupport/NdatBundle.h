#pragma once

// .ndat 2.0 - the NC data bundle (see NDAT_FORMAT.md, "Version 2").
//
// One file holding named entries. Each entry is a SECTION of bytes in the
// encoding that suits its data best, chosen when the file is written
// (Numpy/importing_data/io_ndat.cpp decides and encodes):
//
//   native   an NDAT value node (exact: any NC value, units, types, objects)
//   hdf5     a complete HDF5 file image (large numeric tensors: chunked,
//            shuffled, compressed, read back by slices)
//   parquet  a complete Apache Parquet file (tables with text / bool columns:
//            dictionary encoding + zstd, read back by columns)
//   arrow    a complete Arrow IPC (Feather v2) file (numeric tables: no
//            decoding work, read back by columns)
//
// The table of contents sits at the end, so a reader seeks straight to the
// entry it wants and never reads the others. Each section carries its own
// CRC-32; the header and table of contents share one more. A section can be
// copied out unchanged as a standalone .h5 / .parquet / .arrow file.
//
// This file only frames sections; it does not know what is inside them.

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

#include "../../interpreter/core/value.h"

namespace ncdata {
namespace bundle {

enum class Encoding : uint8_t { Native = 0, Hdf5 = 1, Parquet = 2, Arrow = 3 };
const char *encodingName(Encoding e); // "native" "hdf5" "parquet" "arrow"

// What the entries make up when the whole file is read back.
enum class Root : uint8_t {
  Value = 0,     // one value, entry "data"
  Dict = 1,      // a dict: one entry per key
  Workspace = 2  // variables of the workspace, in their order
};
const char *rootName(Root r);

constexpr uint16_t kMajor = 2;
constexpr uint16_t kMinor = 0;

struct Section {
  std::string name;
  Encoding encoding = Encoding::Native;
  std::string bytes;  // the encoded data
  Value meta;         // a dict describing the entry (kind, shape, columns ...)
};

struct EntryInfo {
  std::string name;
  Encoding encoding = Encoding::Native;
  uint64_t offset = 0, length = 0;
  uint32_t crc = 0;
  Value meta;
};

// Writes the file through a temporary file next to it, then renames it into
// place (a failure never leaves a broken file). False with `err` set.
bool writeBundle(const std::filesystem::path &path, Root root, const std::vector<Section> &sections,
                 std::string &err);

// 0 = not an .ndat file (or unreadable), otherwise the major version.
int ndatMajorVersion(const std::filesystem::path &path);

// Reads the table of contents; sections are read on request.
class BundleReader {
public:
  bool open(const std::filesystem::path &path, std::string &err);
  Root root() const { return root_; }
  uint16_t minor() const { return minor_; }
  uint64_t createdUnixMs() const { return created_; }
  uint64_t fileBytes() const { return size_; }
  const std::vector<EntryInfo> &entries() const { return entries_; }
  const EntryInfo *find(const std::string &name) const;
  // The section's bytes, CRC checked.
  bool section(const EntryInfo &e, std::string &bytes, std::string &err);

private:
  std::filesystem::path path_;
  std::ifstream in_;
  Root root_ = Root::Value;
  uint16_t minor_ = 0;
  uint64_t created_ = 0, size_ = 0;
  std::vector<EntryInfo> entries_;
};

} // namespace bundle
} // namespace ncdata
