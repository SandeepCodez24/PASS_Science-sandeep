#pragma once

// One classification of a runtime Value, shared by the .ndat writer and the
// JSON layer so both always agree on what a value is.

#include <string>
#include <vector>

#include "../../interpreter/core/value.h"
#include "NdatTypes.h"

namespace ncdata {

enum class DataKind {
  Float64,    // plain number (possibly with a unit)
  Complex,    // complex number
  Bool,       // true / false
  Int,        // int8 ... uint64
  Text,       // UTF-8 string
  Tensor,     // packed numeric array/matrix (float64 or complex)
  CellArray,  // array of arbitrary values
  CellMatrix, // matrix of arbitrary values
  Dict,
  Object,
  FuncRef
};

inline DataKind dataKindOf(const Value &v) {
  if (v.isObject)
    return DataKind::Object;
  if (v.isDict)
    return DataKind::Dict;
  if (v.isFunctionRef)
    return DataKind::FuncRef;
  if (v.isText)
    return DataKind::Text;
  if (v.isMatrix)
    return (v.isPacked() || v.isPackedComplex()) ? DataKind::Tensor : DataKind::CellMatrix;
  if (v.isArray)
    return (v.isPacked() || v.isPackedComplex()) ? DataKind::Tensor : DataKind::CellArray;
  if (v.isBool())
    return DataKind::Bool;
  if (v.isInt())
    return DataKind::Int;
  if (v.isComplex)
    return DataKind::Complex;
  return DataKind::Float64;
}

inline bool hasUnits(int16_t l, int16_t t, int16_t m) { return l != 0 || t != 0 || m != 0; }

// The unit the way the interpreter prints it ("m/s", "kg*m/s^2"); empty for
// a unitless value. Same construction as output.cpp's valueToString().
inline std::string unitText(int16_t l, int16_t t, int16_t m) {
  if (!hasUnits(l, t, m))
    return std::string();
  std::vector<std::string> num, den;
  auto add = [&](const char *symbol, int exp) {
    if (exp == 0)
      return;
    std::string part = (exp == 1 || exp == -1) ? std::string(symbol)
                                               : std::string(symbol) + "^" + std::to_string(exp < 0 ? -exp : exp);
    (exp > 0 ? num : den).push_back(part);
  };
  add("m", l);
  add("s", t);
  add("kg", m);
  std::string out;
  for (std::size_t i = 0; i < num.size(); i++)
    out += (i ? "*" : "") + num[i];
  if (num.empty())
    out = "1";
  if (!den.empty()) {
    out += "/";
    for (std::size_t i = 0; i < den.size(); i++)
      out += (i ? "*" : "") + den[i];
  }
  return out;
}

// .ndat tag for an integer type.
inline ndat::Tag ndatTagOf(IntType t) {
  switch (t) {
  case IntType::Int8:
    return ndat::TAG_INT8;
  case IntType::Int16:
    return ndat::TAG_INT16;
  case IntType::Int32:
    return ndat::TAG_INT32;
  case IntType::Int64:
    return ndat::TAG_INT64;
  case IntType::UInt8:
    return ndat::TAG_UINT8;
  case IntType::UInt16:
    return ndat::TAG_UINT16;
  case IntType::UInt32:
    return ndat::TAG_UINT32;
  case IntType::UInt64:
    return ndat::TAG_UINT64;
  case IntType::None:
    break;
  }
  return ndat::TAG_INT64;
}

// Byte width of an integer type's .ndat payload.
inline int intByteWidth(IntType t) {
  switch (t) {
  case IntType::Int8:
  case IntType::UInt8:
    return 1;
  case IntType::Int16:
  case IntType::UInt16:
    return 2;
  case IntType::Int32:
  case IntType::UInt32:
    return 4;
  default:
    return 8;
  }
}

// The element unit of a packed tensor (every element shares it).
inline void tensorUnit(const Value &v, int16_t &l, int16_t &t, int16_t &m) {
  std::size_t n = v.isMatrix ? v.rows() : v.length();
  if (n == 0) {
    l = t = m = 0;
    return;
  }
  Value first = v.isMatrix ? v.at(0, 0) : v.at(0);
  l = first.dimL;
  t = first.dimT;
  m = first.dimM;
}

} // namespace ncdata
