#include "NdatWriter.h"

#include <algorithm>
#include <chrono>
#include <fstream>
#include <system_error>

#include "../../interpreter/core/packed_read.h"
#include "../../interpreter/ops/floating/floating.h"
#include "../../interpreter/ops/matrix/nd_array.h"
#include "NdatTypes.h"
#include "ValueInspect.h"

namespace ncdata {

namespace {

void writeUnits(ByteSink &out, int16_t l, int16_t t, int16_t m) {
  out.i16(l);
  out.i16(t);
  out.i16(m);
}

// Tag byte, flags byte, and the optional unit block that every node starts
// with. The unit here is the Value's own (for a packed tensor the shared
// element unit is part of the tensor payload instead).
void writeHeader(ByteSink &out, ndat::Tag tag, const Value &v) {
  const bool units = hasUnits(v.dimL, v.dimT, v.dimM);
  out.u8(tag);
  out.u8(units ? ndat::FLAG_HAS_UNITS : 0);
  if (units)
    writeUnits(out, v.dimL, v.dimT, v.dimM);
}

void writeShortString(ByteSink &out, const std::string &s) {
  out.u32(static_cast<uint32_t>(s.size()));
  out.bytes(s);
}

// Map entries in sorted key order, so equal maps encode identically
// whatever order unordered_map happens to iterate in.
void writeEntries(ByteSink &out, const std::unordered_map<std::string, Value> &map) {
  std::vector<const std::pair<const std::string, Value> *> entries;
  entries.reserve(map.size());
  for (const auto &kv : map)
    entries.push_back(&kv);
  std::sort(entries.begin(), entries.end(),
            [](const auto *a, const auto *b) { return a->first < b->first; });
  out.u64(entries.size());
  for (const auto *kv : entries) {
    writeShortString(out, kv->first);
    writeValueNode(out, kv->second);
  }
}

// The doubles of a packed real value (2026-11-20): a lazy range (a range
// literal whose buffer was never built) is written from its rule, chunk by
// chunk, without building it - the same bytes. Safe on the autosave thread:
// the rule never changes, and a buffer built meanwhile is only read once
// lazyRange() says it is there.
void writeRealBuffer(ByteSink &out, const Value &v, std::size_t count) {
  // Any lazy tensor - a range, or one with an arithmetic chain (2026-11-21).
  // The tensor stays alive in `v`, and its rule never changes.
  if (const NumTensor *lazy = v.lazyTensor()) {
    out.f64Generated(count, v.tensorStamp(), [lazy](std::size_t first, std::size_t m, double *dst) {
      lazy->lazyBlock(first, m, dst); // = lazyValue() of each element
    });
    return;
  }
  out.f64Bulk(v.packedData(), count, v.tensorStamp());
}

void writeTensor(ByteSink &out, const Value &v) {
  writeHeader(out, ndat::TAG_NUM_TENSOR, v);
  const bool complex = v.isPackedComplex();
  out.u8(complex ? ndat::TAG_COMPLEX128 : ndat::TAG_FLOAT64);
  int16_t l, t, m;
  tensorUnit(v, l, t, m);
  writeUnits(out, l, t, m);
  std::size_t count;
  if (v.isMatrix) {
    out.u8(2);
    out.u64(v.rows());
    out.u64(v.cols());
    count = v.rows() * v.cols();
  } else {
    out.u8(1);
    out.u64(v.length());
    count = v.length();
  }
  // Column-major, exactly the in-memory layout: one bulk copy.
  if (complex)
    out.f64Bulk(reinterpret_cast<const double *>(v.packedComplexData()), 2 * count, v.tensorStamp());
  else
    writeRealBuffer(out, v, count);
}

// An N-D matrix (rank >= 3). All plain numbers: TAG_NUM_TENSOR with its
// rank and dims, the data in the in-memory storage order (2-D column-major
// pages, pages in row-major order of the leading axes - one bulk copy).
// Anything else (text, bools, integers, float32 ...): TAG_CELL_ND, one node
// per element in the same order.
void writeND(ByteSink &out, const Value &v) {
  const nd::Shape &shape = v.ndShape();
  const std::size_t count = v.ndCount();
  if (v.isPacked() || v.isPackedComplex()) {
    writeHeader(out, ndat::TAG_NUM_TENSOR, v);
    const bool complex = v.isPackedComplex();
    out.u8(complex ? ndat::TAG_COMPLEX128 : ndat::TAG_FLOAT64);
    const Value first = v.ndAt(0); // every element shares the unit
    writeUnits(out, first.dimL, first.dimT, first.dimM);
    out.u8(static_cast<uint8_t>(shape.size()));
    for (std::size_t d : shape)
      out.u64(d);
    if (complex)
      out.f64Bulk(reinterpret_cast<const double *>(v.packedComplexData()), 2 * count, v.tensorStamp());
    else
      writeRealBuffer(out, v, count);
    return;
  }
  writeHeader(out, ndat::TAG_CELL_ND, v);
  out.u8(static_cast<uint8_t>(shape.size()));
  for (std::size_t d : shape)
    out.u64(d);
  for (std::size_t k = 0; k < count; k++)
    writeValueNode(out, v.ndAt(k));
}

void writeInt(ByteSink &out, const Value &v) {
  const IntType type = v.intType();
  writeHeader(out, ndatTagOf(type), v);
  const uint64_t bits = static_cast<uint64_t>(v.intBits());
  switch (intByteWidth(type)) {
  case 1:
    out.u8(static_cast<uint8_t>(bits));
    break;
  case 2:
    out.u16(static_cast<uint16_t>(bits));
    break;
  case 4:
    out.u32(static_cast<uint32_t>(bits));
    break;
  default:
    out.u64(bits);
    break;
  }
}

// The node tag of a typed tensor's elements, and their payload bytes.
ndat::Tag typedElemTag(ElemType et, std::size_t &payload) {
  switch (et) {
  case ElemType::I8: payload = 1; return ndat::TAG_INT8;
  case ElemType::I16: payload = 2; return ndat::TAG_INT16;
  case ElemType::I32: payload = 4; return ndat::TAG_INT32;
  case ElemType::I64: payload = 8; return ndat::TAG_INT64;
  case ElemType::U8: payload = 1; return ndat::TAG_UINT8;
  case ElemType::U16: payload = 2; return ndat::TAG_UINT16;
  case ElemType::U32: payload = 4; return ndat::TAG_UINT32;
  case ElemType::U64: payload = 8; return ndat::TAG_UINT64;
  case ElemType::Bool: payload = 1; return ndat::TAG_BOOL;
  case ElemType::F8: payload = 1; return ndat::TAG_FLOAT8;
  case ElemType::F16: payload = 2; return ndat::TAG_FLOAT16;
  case ElemType::F32: payload = 4; return ndat::TAG_FLOAT32;
  case ElemType::F64: break;
  }
  payload = 8;
  return ndat::TAG_FLOAT64;
}

// A 1-D / 2-D typed tensor (int8 ... uint64, bool, float32/16/8) is written
// as the cell array / cell matrix of its typed scalars - exactly the bytes
// the per-cell path below gives (header + payload per element, row by row
// for a matrix), but encoded straight from the raw buffer in chunks, without
// a 32-byte Value per element (2026-11-20). float16 of 628 million elements
// made the per-cell path take minutes at every fingerprint.
void writeTypedCells(ByteSink &out, const Value &v) {
  const ElemType et = v.elemType();
  const std::vector<size_t> &shape = v.tensorShape();
  const bool matrix = shape.size() == 2;
  const std::size_t rows = matrix ? shape[0] : 1;
  const std::size_t cols = matrix ? shape[1] : shape[0];
  const int16_t l = v.tensorDimL(), t = v.tensorDimT(), m = v.tensorDimM();
  const bool units = hasUnits(l, t, m);

  std::size_t payload = 0;
  const ndat::Tag tag = typedElemTag(et, payload);
  const std::size_t node = 2 + (units ? 6 : 0) + payload;
  const uint8_t *raw = v.typedData();

  writeHeader(out, matrix ? ndat::TAG_CELL_MATRIX : ndat::TAG_CELL_ARRAY, v);
  out.u64(matrix ? rows : cols);
  const std::size_t total = (matrix ? rows * 8 : 0) + rows * cols * node;

  out.encoded(total, v.tensorStamp(), [&](const ByteSink::ChunkWriter &emit) {
    std::vector<uint8_t> chunk;
    chunk.reserve(std::size_t(1) << 16);
    auto put = [&chunk](uint64_t value, std::size_t bytes) {
      for (std::size_t i = 0; i < bytes; i++)
        chunk.push_back(static_cast<uint8_t>(value >> (8 * i)));
    };
    for (std::size_t r = 0; r < rows; r++) {
      if (matrix)
        put(cols, 8); // the row's length
      for (std::size_t c = 0; c < cols; c++) {
        const std::size_t k = matrix ? c * rows + r : c;
        put(tag, 1);
        put(units ? ndat::FLAG_HAS_UNITS : 0, 1);
        if (units) {
          put(static_cast<uint16_t>(l), 2);
          put(static_cast<uint16_t>(t), 2);
          put(static_cast<uint16_t>(m), 2);
        }
        int64_t bits;
        double x;
        ncpacked::typedElement(et, raw, k, bits, x);
        switch (et) {
        case ElemType::Bool: put(bits != 0 ? 1 : 0, 1); break;
        case ElemType::F8: put(encodeFloatBits(FloatType::Float8, x), 1); break;
        case ElemType::F16: put(encodeFloatBits(FloatType::Float16, x), 2); break;
        case ElemType::F32: put(encodeFloatBits(FloatType::Float32, x), 4); break;
        default: put(static_cast<uint64_t>(bits), payload); break;
        }
        if (chunk.size() >= (std::size_t(1) << 16) - 64) {
          emit(chunk.data(), chunk.size());
          chunk.clear();
        }
      }
    }
    if (!chunk.empty())
      emit(chunk.data(), chunk.size());
  });
}

} // namespace

// The fingerprint of a lazy tensor whose rule has function steps
// (2026-11-23): the rule itself - range, every step with its constant and
// its function's address, and each operand's own rule (or, for a stored
// operand, its stamp: equal stamps, equal bytes). Evaluating sin(A) of 6 G
// elements at every prompt just to see whether it changed would take
// longer than the command. Addresses are stable for the life of the
// process, which is all a change check needs; this never goes into a file.
void hashLazyRule(ByteSink &out, const NumTensor &t) {
  out.u8(0xF7);
  out.f64(t.range.first);
  out.f64(t.range.step);
  out.f64(t.range.end);
  out.u8(t.range.closed ? 1 : 0);
  out.u64(static_cast<uint64_t>(t.range.count));
  out.u8(t.range.snapLast ? 1 : 0);
  out.u64(t.shape.size());
  for (size_t d : t.shape)
    out.u64(d);
  // A view's base: its stamp (equal stamps, equal bytes; never written while shared).
  out.u64(t.base ? t.base->stamp : 0);
  out.u64(t.ops.size());
  for (const NumTensor::LazyOp &op : t.ops) {
    out.u8(static_cast<uint8_t>(op.kind));
    out.f64(op.c);
    out.u64(static_cast<uint64_t>(reinterpret_cast<uintptr_t>(op.fn1)));
    out.u64(static_cast<uint64_t>(reinterpret_cast<uintptr_t>(op.fn2)));
    if (!op.other) {
      out.u8(0);
    } else if (op.other->range.count > 0) { // made lazy: its rule, built or not
      out.u8(1);
      hashLazyRule(out, *op.other);
    } else {
      out.u8(2);
      out.u64(op.other->stamp);
    }
  }
}

void writeValueNode(ByteSink &out, const Value &v) {
  // A lazy range in the session autosave: its rule (TAG_NUM_RANGE, see
  // NdatTypes.h). Everywhere else it is written as the data it stands for.
  // Shapes the reader rebuilds: [n], [1, n], [n, 1]. With its arithmetic
  // chain, if any (2026-11-21).
  const NumTensor *lazy = (v.isArray || v.isMatrix) && v.isPacked() ? v.lazyTensor() : nullptr;
  if (out.hashOnly() && lazy && !lazy->portableRule()) {
    writeHeader(out, ndat::TAG_NUM_RANGE, v);
    int16_t l, t, m;
    v.unitDims(l, t, m);
    writeUnits(out, l, t, m);
    hashLazyRule(out, *lazy);
    return;
  }
  // Function steps cannot go into a file: such a rule is written as the
  // values it stands for (below), like any stored tensor.
  if (out.sessionNodes() && lazy && lazy->portableRule() &&
      (v.tensorShape().size() == 1 ||
       (v.tensorShape().size() == 2 && (v.tensorShape()[0] == 1 || v.tensorShape()[1] == 1)))) {
    const ncrange::Spec &spec = lazy->range;
    writeHeader(out, ndat::TAG_NUM_RANGE, v);
    int16_t l, t, m;
    v.unitDims(l, t, m);
    writeUnits(out, l, t, m);
    const std::vector<size_t> &shape = v.tensorShape();
    out.u8(static_cast<uint8_t>(shape.size()));
    for (size_t d : shape)
      out.u64(d);
    out.f64(spec.first);
    out.f64(spec.step);
    out.f64(spec.end);
    out.u8(spec.closed ? 1 : 0);
    out.u64(static_cast<uint64_t>(spec.count));
    out.u8(spec.snapLast ? 1 : 0);
    out.u8(static_cast<uint8_t>(lazy->ops.size()));
    for (const NumTensor::LazyOp &op : lazy->ops) {
      out.u8(static_cast<uint8_t>(op.kind));
      out.f64(op.c);
    }
    return;
  }
  // A typed tensor in the session autosave: its raw buffer in one block
  // (TAG_TYPED_RAW, NdatTypes.h). Elsewhere: cells of typed scalars, below.
  if (out.sessionNodes() && (v.isArray || v.isMatrix) && v.isTypedPacked() && v.tensorCount() > 0 &&
      v.tensorShape().size() <= 32 && ByteSink::hostIsLittleEndian()) {
    writeHeader(out, ndat::TAG_TYPED_RAW, v);
    writeUnits(out, v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
    std::size_t payload = 0;
    out.u8(typedElemTag(v.elemType(), payload));
    const std::vector<size_t> &shape = v.tensorShape();
    out.u8(static_cast<uint8_t>(shape.size()));
    for (size_t d : shape)
      out.u64(d);
    // Through encoded(): a file writes the block; the fingerprint's hash sink
    // remembers its XXH64 by the tensor's stamp.
    const std::size_t bytes = v.tensorCount() * elemTypeBytes(v.elemType());
    const uint8_t *raw = v.typedData();
    out.encoded(bytes, v.tensorStamp(), [raw, bytes](const ByteSink::ChunkWriter &emit) { emit(raw, bytes); });
    return;
  }
  if (v.isND()) {
    writeND(out, v);
    return;
  }
  if ((v.isArray || v.isMatrix) && v.isTypedPacked() && v.tensorCount() > 0 &&
      (v.tensorShape().size() == 1 || v.tensorShape().size() == 2)) {
    writeTypedCells(out, v);
    return;
  }
  switch (dataKindOf(v)) {
  case DataKind::Bool:
    writeHeader(out, ndat::TAG_BOOL, v);
    out.u8(v.number != 0.0 ? 1 : 0);
    return;

  case DataKind::Int:
    writeInt(out, v);
    return;

  case DataKind::Timestamp:
  case DataKind::Duration:
    writeHeader(out, v.isTimestamp() ? ndat::TAG_TIMESTAMP : ndat::TAG_DURATION, v);
    out.u64(static_cast<uint64_t>(v.timeNs()));
    return;

  case DataKind::Float64:
    switch (v.floatType()) {
    case FloatType::Float8:
      writeHeader(out, ndat::TAG_FLOAT8, v);
      out.u8(static_cast<uint8_t>(encodeFloatBits(FloatType::Float8, v.number)));
      return;
    case FloatType::Float16:
      writeHeader(out, ndat::TAG_FLOAT16, v);
      out.u16(static_cast<uint16_t>(encodeFloatBits(FloatType::Float16, v.number)));
      return;
    case FloatType::Float32:
      writeHeader(out, ndat::TAG_FLOAT32, v);
      out.u32(encodeFloatBits(FloatType::Float32, v.number));
      return;
    case FloatType::Float64:
      break;
    }
    writeHeader(out, ndat::TAG_FLOAT64, v);
    out.f64(v.number);
    return;

  case DataKind::Complex:
    writeHeader(out, ndat::TAG_COMPLEX128, v);
    out.f64(v.number);
    out.f64(v.imag);
    return;

  case DataKind::Text:
    writeHeader(out, ndat::TAG_UTF8, v);
    out.u64(v.text().size());
    out.bytes(v.text());
    return;

  case DataKind::Tensor:
    writeTensor(out, v);
    return;

  case DataKind::CellArray: {
    writeHeader(out, ndat::TAG_CELL_ARRAY, v);
    const std::size_t n = v.length();
    out.u64(n);
    for (std::size_t i = 0; i < n; i++)
      writeValueNode(out, v.at(i));
    return;
  }

  case DataKind::CellMatrix: {
    writeHeader(out, ndat::TAG_CELL_MATRIX, v);
    const std::size_t rows = v.rows();
    out.u64(rows);
    for (std::size_t r = 0; r < rows; r++) {
      const std::size_t len = v.rowLength(r);
      out.u64(len);
      for (std::size_t c = 0; c < len; c++)
        writeValueNode(out, v.at(r, c));
    }
    return;
  }

  case DataKind::Dict:
    writeHeader(out, ndat::TAG_DICT, v);
    writeEntries(out, v.dict());
    return;

  case DataKind::Object: {
    writeHeader(out, ndat::TAG_OBJECT, v);
    writeShortString(out, v.className());
    writeEntries(out, v.dict());
    out.u64(v.lineage().size());
    for (const std::string &entry : v.lineage())
      writeShortString(out, entry);
    out.u64(v.snapshots().size());
    for (const auto &snapshot : v.snapshots())
      writeEntries(out, snapshot);
    out.f64(v.lastTickTime());
    return;
  }

  case DataKind::FuncRef:
    writeHeader(out, ndat::TAG_FUNC_REF, v);
    writeShortString(out, v.funcRefName());
    return;
  }
}

uint64_t valueFingerprint(const Value &v) {
  HashSink sink;
  writeValueNode(sink, v);
  return sink.hash.value();
}

bool writeNdatFile(const std::filesystem::path &path, const std::vector<NamedValueRef> &vars,
                   std::string &err, bool sessionNodes) {
  std::error_code ec;
  const std::filesystem::path folder = path.parent_path();
  if (!folder.empty() && !std::filesystem::is_directory(folder, ec)) {
    err = "folder does not exist: " + folder.u8string();
    return false;
  }

  std::filesystem::path temp = path;
  temp += ".tmp";

  {
    std::ofstream file(temp, std::ios::binary | std::ios::trunc);
    if (!file) {
      err = "cannot write " + path.u8string();
      return false;
    }
    FileSink out(file, sessionNodes);

    // Header (32 bytes).
    out.write(reinterpret_cast<const uint8_t *>(ndat::kMagic), 4);
    out.u16(ndat::kVersionMajor);
    out.u16(ndat::kVersionMinor);
    out.u8(ndat::kEndianLittle);
    out.u8(0); // header flags: none defined in 1.0
    out.u16(0);
    out.u32(static_cast<uint32_t>(vars.size()));
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    out.u64(static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(now).count()));
    out.u64(0);

    // Records.
    for (const NamedValueRef &var : vars) {
      out.u32(static_cast<uint32_t>(var.name->size()));
      out.bytes(*var.name);
      writeValueNode(out, *var.value);
    }

    // Footer: end marker, then the CRC-32 of every byte before the CRC.
    out.write(reinterpret_cast<const uint8_t *>(ndat::kEndMagic), 4);
    const uint32_t crc = out.crc.value();
    out.u32(crc);

    file.flush();
    if (!file) {
      file.close();
      std::filesystem::remove(temp, ec);
      err = "write failed for " + path.u8string() + " (disk full?)";
      return false;
    }
  }

  // Replace the target. Some platforms refuse to rename onto an existing
  // file, so on failure remove the old one and try once more.
  std::filesystem::rename(temp, path, ec);
  if (ec) {
    std::error_code ec2;
    std::filesystem::remove(path, ec2);
    std::filesystem::rename(temp, path, ec2);
    if (ec2) {
      std::filesystem::remove(temp, ec2);
      err = "cannot replace " + path.u8string() + ": " + ec.message();
      return false;
    }
  }
  return true;
}

} // namespace ncdata
