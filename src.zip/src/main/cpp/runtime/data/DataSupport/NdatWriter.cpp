#include "NdatWriter.h"

#include <algorithm>
#include <chrono>
#include <fstream>
#include <system_error>

#include "../../interpreter/ops/floating/floating.h"
#include "NdatTypes.h"
#include "ValueInspect.h"

namespace ncdata {

namespace {

void writeUnits(ByteSink &out, int16_t l, int16_t t, int16_t m) {
  out.i16(l);
  out.i16(t);
  out.i16(m);
}

// Tag byte, flags byte, and the optional unit block that every node starts
// with. The unit here is the Value's own (for a packed tensor the shared
// element unit is part of the tensor payload instead).
void writeHeader(ByteSink &out, ndat::Tag tag, const Value &v) {
  const bool units = hasUnits(v.dimL, v.dimT, v.dimM);
  out.u8(tag);
  out.u8(units ? ndat::FLAG_HAS_UNITS : 0);
  if (units)
    writeUnits(out, v.dimL, v.dimT, v.dimM);
}

void writeShortString(ByteSink &out, const std::string &s) {
  out.u32(static_cast<uint32_t>(s.size()));
  out.bytes(s);
}

// Map entries in sorted key order, so equal maps encode identically
// whatever order unordered_map happens to iterate in.
void writeEntries(ByteSink &out, const std::unordered_map<std::string, Value> &map) {
  std::vector<const std::pair<const std::string, Value> *> entries;
  entries.reserve(map.size());
  for (const auto &kv : map)
    entries.push_back(&kv);
  std::sort(entries.begin(), entries.end(),
            [](const auto *a, const auto *b) { return a->first < b->first; });
  out.u64(entries.size());
  for (const auto *kv : entries) {
    writeShortString(out, kv->first);
    writeValueNode(out, kv->second);
  }
}

void writeTensor(ByteSink &out, const Value &v) {
  writeHeader(out, ndat::TAG_NUM_TENSOR, v);
  const bool complex = v.isPackedComplex();
  out.u8(complex ? ndat::TAG_COMPLEX128 : ndat::TAG_FLOAT64);
  int16_t l, t, m;
  tensorUnit(v, l, t, m);
  writeUnits(out, l, t, m);
  std::size_t count;
  if (v.isMatrix) {
    out.u8(2);
    out.u64(v.rows());
    out.u64(v.cols());
    count = v.rows() * v.cols();
  } else {
    out.u8(1);
    out.u64(v.length());
    count = v.length();
  }
  // Column-major, exactly the in-memory layout: one bulk copy.
  if (complex)
    out.f64Array(reinterpret_cast<const double *>(v.packedComplexData()), 2 * count);
  else
    out.f64Array(v.packedData(), count);
}

void writeInt(ByteSink &out, const Value &v) {
  const IntType type = v.intType();
  writeHeader(out, ndatTagOf(type), v);
  const uint64_t bits = static_cast<uint64_t>(v.intBits());
  switch (intByteWidth(type)) {
  case 1:
    out.u8(static_cast<uint8_t>(bits));
    break;
  case 2:
    out.u16(static_cast<uint16_t>(bits));
    break;
  case 4:
    out.u32(static_cast<uint32_t>(bits));
    break;
  default:
    out.u64(bits);
    break;
  }
}

} // namespace

void writeValueNode(ByteSink &out, const Value &v) {
  switch (dataKindOf(v)) {
  case DataKind::Bool:
    writeHeader(out, ndat::TAG_BOOL, v);
    out.u8(v.number != 0.0 ? 1 : 0);
    return;

  case DataKind::Int:
    writeInt(out, v);
    return;

  case DataKind::Float64:
    switch (v.floatType()) {
    case FloatType::Float8:
      writeHeader(out, ndat::TAG_FLOAT8, v);
      out.u8(static_cast<uint8_t>(encodeFloatBits(FloatType::Float8, v.number)));
      return;
    case FloatType::Float16:
      writeHeader(out, ndat::TAG_FLOAT16, v);
      out.u16(static_cast<uint16_t>(encodeFloatBits(FloatType::Float16, v.number)));
      return;
    case FloatType::Float32:
      writeHeader(out, ndat::TAG_FLOAT32, v);
      out.u32(encodeFloatBits(FloatType::Float32, v.number));
      return;
    case FloatType::Float64:
      break;
    }
    writeHeader(out, ndat::TAG_FLOAT64, v);
    out.f64(v.number);
    return;

  case DataKind::Complex:
    writeHeader(out, ndat::TAG_COMPLEX128, v);
    out.f64(v.number);
    out.f64(v.imag);
    return;

  case DataKind::Text:
    writeHeader(out, ndat::TAG_UTF8, v);
    out.u64(v.text().size());
    out.bytes(v.text());
    return;

  case DataKind::Tensor:
    writeTensor(out, v);
    return;

  case DataKind::CellArray: {
    writeHeader(out, ndat::TAG_CELL_ARRAY, v);
    const std::size_t n = v.length();
    out.u64(n);
    for (std::size_t i = 0; i < n; i++)
      writeValueNode(out, v.at(i));
    return;
  }

  case DataKind::CellMatrix: {
    writeHeader(out, ndat::TAG_CELL_MATRIX, v);
    const std::size_t rows = v.rows();
    out.u64(rows);
    for (std::size_t r = 0; r < rows; r++) {
      const std::size_t len = v.rowLength(r);
      out.u64(len);
      for (std::size_t c = 0; c < len; c++)
        writeValueNode(out, v.at(r, c));
    }
    return;
  }

  case DataKind::Dict:
    writeHeader(out, ndat::TAG_DICT, v);
    writeEntries(out, v.dict());
    return;

  case DataKind::Object: {
    writeHeader(out, ndat::TAG_OBJECT, v);
    writeShortString(out, v.className());
    writeEntries(out, v.dict());
    out.u64(v.lineage().size());
    for (const std::string &entry : v.lineage())
      writeShortString(out, entry);
    out.u64(v.snapshots().size());
    for (const auto &snapshot : v.snapshots())
      writeEntries(out, snapshot);
    out.f64(v.lastTickTime());
    return;
  }

  case DataKind::FuncRef:
    writeHeader(out, ndat::TAG_FUNC_REF, v);
    writeShortString(out, v.funcRefName());
    return;
  }
}

uint64_t valueFingerprint(const Value &v) {
  HashSink sink;
  writeValueNode(sink, v);
  return sink.hash.value();
}

bool writeNdatFile(const std::filesystem::path &path, const std::vector<NamedValueRef> &vars,
                   std::string &err) {
  std::error_code ec;
  const std::filesystem::path folder = path.parent_path();
  if (!folder.empty() && !std::filesystem::is_directory(folder, ec)) {
    err = "folder does not exist: " + folder.u8string();
    return false;
  }

  std::filesystem::path temp = path;
  temp += ".tmp";

  {
    std::ofstream file(temp, std::ios::binary | std::ios::trunc);
    if (!file) {
      err = "cannot write " + path.u8string();
      return false;
    }
    FileSink out(file);

    // Header (32 bytes).
    out.write(reinterpret_cast<const uint8_t *>(ndat::kMagic), 4);
    out.u16(ndat::kVersionMajor);
    out.u16(ndat::kVersionMinor);
    out.u8(ndat::kEndianLittle);
    out.u8(0); // header flags: none defined in 1.0
    out.u16(0);
    out.u32(static_cast<uint32_t>(vars.size()));
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    out.u64(static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(now).count()));
    out.u64(0);

    // Records.
    for (const NamedValueRef &var : vars) {
      out.u32(static_cast<uint32_t>(var.name->size()));
      out.bytes(*var.name);
      writeValueNode(out, *var.value);
    }

    // Footer: end marker, then the CRC-32 of every byte before the CRC.
    out.write(reinterpret_cast<const uint8_t *>(ndat::kEndMagic), 4);
    const uint32_t crc = out.crc.value();
    out.u32(crc);

    file.flush();
    if (!file) {
      file.close();
      std::filesystem::remove(temp, ec);
      err = "write failed for " + path.u8string() + " (disk full?)";
      return false;
    }
  }

  // Replace the target. Some platforms refuse to rename onto an existing
  // file, so on failure remove the old one and try once more.
  std::filesystem::rename(temp, path, ec);
  if (ec) {
    std::error_code ec2;
    std::filesystem::remove(path, ec2);
    std::filesystem::rename(temp, path, ec2);
    if (ec2) {
      std::filesystem::remove(temp, ec2);
      err = "cannot replace " + path.u8string() + ": " + ec.message();
      return false;
    }
  }
  return true;
}

} // namespace ncdata
