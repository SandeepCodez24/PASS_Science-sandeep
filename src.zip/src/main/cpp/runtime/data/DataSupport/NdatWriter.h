#pragma once

// Encoding runtime Values into the .ndat format (see NDAT_FORMAT.md).

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

#include "../../interpreter/core/value.h"
#include "BinaryIO.h"

namespace ncdata {

// A variable to be written: borrowed name and value.
struct NamedValueRef {
  const std::string *name;
  const Value *value;
};

// Appends one value node to `out`. Deterministic: equal values always
// produce identical bytes (dict keys and object fields are written sorted),
// which is what makes valueFingerprint() usable for change detection.
void writeValueNode(ByteSink &out, const Value &v);

// FNV-1a 64 of the value's node bytes, computed without building them.
uint64_t valueFingerprint(const Value &v);

// Writes a complete .ndat file. The bytes go to a temporary file next to
// `path` that then replaces `path`, so a failure part-way never leaves a
// truncated workspace file behind. False with `err` set on failure.
// `sessionNodes`: lazy ranges as their rule (TAG_NUM_RANGE) and typed
// tensors as their raw buffer (TAG_TYPED_RAW) - the session autosave only;
// every file a user or another program may read keeps the portable nodes
// (2026-11-21).
bool writeNdatFile(const std::filesystem::path &path, const std::vector<NamedValueRef> &vars,
                   std::string &err, bool sessionNodes = false);

} // namespace ncdata
