#include "ValueJson.h"

#include <algorithm>
#include <cstdio>
#include <vector>

#include "../../interpreter/core/output.h"
#include "../../interpreter/core/packed_read.h"
#include "../../interpreter/ops/floating/floating.h"
#include "../../interpreter/ops/integer/integer.h"
#include "../../interpreter/ops/matrix/nd_array.h"
#include "../../interpreter/Numpy/numpy_poly1d.h"
#include "../../interpreter/ops/time/time.h"
#include "ValueInspect.h"

namespace ncdata {

namespace {

// Previews longer than this end in "...".
constexpr std::size_t kPreviewChars = 400;
// Arrays/matrices with more elements than this are previewed as
// "<3x400 float64>" instead of listing their elements.
constexpr std::size_t kPreviewElements = 1000;
// Nesting deeper than this is written as a placeholder in full-value JSON.
constexpr int kMaxJsonDepth = 64;

std::size_t utf8Length(const std::string &s) {
  std::size_t n = 0;
  for (unsigned char c : s)
    if ((c & 0xC0) != 0x80)
      n++;
  return n;
}

// Cuts `s` to at most `maxBytes` bytes without splitting a UTF-8 sequence.
void truncateUtf8(std::string &s, std::size_t maxBytes) {
  if (s.size() <= maxBytes)
    return;
  std::size_t cut = maxBytes;
  while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80)
    cut--;
  s.resize(cut);
  s += "...";
}

std::size_t elementCount(const Value &v) {
  if (v.isArray)
    return v.length();
  if (v.isMatrix) {
    std::size_t n = 0;
    for (std::size_t r = 0; r < v.rows(); r++)
      n += v.rowLength(r);
    return n;
  }
  return 1;
}

std::size_t maxRowLength(const Value &v) {
  std::size_t widest = 0;
  for (std::size_t r = 0; r < v.rows(); r++)
    widest = std::max(widest, v.rowLength(r));
  return widest;
}

std::string scalarText(const Value &v) {
  switch (dataKindOf(v)) {
  case DataKind::Timestamp:
  case DataKind::Duration:
    return nctime::displayText(v);
  case DataKind::Bool:
    return v.number != 0.0 ? "true" : "false";
  case DataKind::Int:
    return v.intText();
  case DataKind::Complex:
    return formatComplex(v.number, v.imag);
  default:
    return formatNumber(v.number);
  }
}

// Appends a compact one-line rendering of `v`, stopping once `out` is past
// kPreviewChars.
void appendPreview(std::string &out, const Value &v, bool quoteText) {
  if (out.size() > kPreviewChars)
    return;
  // An N-D matrix is always previewed by its size and class: the IDE's
  // value column parses nested [[..],[..]] previews as 2-D matrices.
  if (v.isND()) {
    out += "<" + sizeOf(v) + " " + classOf(v) + ">";
    return;
  }
  // A timestamp / duration shows as it prints: "2026-10-28 14:30:00", "01:30:15".
  if (v.isTime()) {
    out += nctime::displayText(v);
    return;
  }
  switch (dataKindOf(v)) {
  case DataKind::Text:
    out += quoteText ? "\"" + v.text() + "\"" : v.text();
    return;
  case DataKind::FuncRef:
    // "@square", or an anonymous function as written: "@(x) x * 2".
    out += functionRefText(v.funcRefName());
    return;
  case DataKind::Object:
    // A poly1d shows as the polynomial (the Variable Explorer's value
    // column): "2x^2 + 3x + 1".
    if (nc::numpy::isPoly1d(v)) {
      out += nc::numpy::poly1dText(v);
      return;
    }
    out += v.className() + " object";
    return;
  case DataKind::Dict: {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    out += "{";
    for (std::size_t i = 0; i < keys.size() && out.size() <= kPreviewChars; i++) {
      if (i)
        out += ", ";
      out += keys[i] + ": ";
      appendPreview(out, v.dict().at(keys[i]), true);
    }
    out += "}";
    return;
  }
  case DataKind::Tensor:
  case DataKind::CellArray:
  case DataKind::CellMatrix: {
    if (elementCount(v) > kPreviewElements) {
      // A lazy value says so (2026-11-23, D5): it is a rule, computed when
      // used - the Workspace shows why it costs no memory.
      const bool lazy = (v.isArray || v.isMatrix) && v.isPacked() && v.lazyTensor();
      out += "<" + sizeOf(v) + " " + classOf(v) + (lazy ? " - lazy rule" : "") + ">";
      return;
    }
    if (v.isArray) {
      out += "[";
      for (std::size_t i = 0; i < v.length() && out.size() <= kPreviewChars; i++) {
        if (i)
          out += ",";
        appendPreview(out, v.at(i), true);
      }
      out += "]";
    } else {
      // Same nesting as the interpreter's old workspace format, which the
      // IDE's numeric parsing of the value column already understands.
      out += "[";
      for (std::size_t r = 0; r < v.rows() && out.size() <= kPreviewChars; r++) {
        out += r ? ",[" : "[";
        for (std::size_t c = 0; c < v.rowLength(r) && out.size() <= kPreviewChars; c++) {
          if (c)
            out += ",";
          appendPreview(out, v.at(r, c), true);
        }
        out += "]";
      }
      out += "]";
    }
    return;
  }
  default: {
    out += scalarText(v);
    std::string unit = unitText(v.dimL, v.dimT, v.dimM);
    if (!unit.empty())
      out += " " + unit;
  }
  }
}

void writeUnitField(JsonWriter &out, int16_t l, int16_t t, int16_t m) {
  if (!hasUnits(l, t, m))
    return;
  out.key("unit").beginObject();
  out.key("L").integer(l);
  out.key("T").integer(t);
  out.key("M").integer(m);
  out.endObject();
  out.key("unitText").string(unitText(l, t, m));
}

void writeEntriesJson(JsonWriter &out, const std::unordered_map<std::string, Value> &map,
                      std::size_t &budget, int depth) {
  std::vector<const std::pair<const std::string, Value> *> entries;
  for (const auto &kv : map)
    entries.push_back(&kv);
  std::sort(entries.begin(), entries.end(),
            [](const auto *a, const auto *b) { return a->first < b->first; });
  out.beginArray();
  for (const auto *kv : entries) {
    out.beginObject();
    out.key("key").string(kv->first);
    out.key("value");
    writeValueJson(out, kv->second, budget, depth + 1);
    out.endObject();
  }
  out.endArray();
}

// The unit an N-D matrix's elements share (none for text).
void ndUnit(const Value &v, int16_t &l, int16_t &t, int16_t &m) {
  l = t = m = 0;
  if (v.ndCount() == 0)
    return;
  const Value first = v.ndAt(0);
  if (first.isText)
    return;
  l = first.dimL;
  t = first.dimT;
  m = first.dimM;
}

// An N-D matrix as JSON: its shape, and its elements in ROW-MAJOR order
// (the last index fastest), so a reader can index data[i][j][k] by plain
// nesting arithmetic:
//   {"k":"ndarray", "elem":"float64", "shape":[2,3,4], "order":"row-major",
//    "data":[...]}                  plain numbers
//    "re":[...], "im":[...]         complex
//    "items":[{...}, ...]           anything else (text, bool, int ...)
void writeNDJson(JsonWriter &out, const Value &v, std::size_t &budget, int depth) {
  out.key("k").string("ndarray");
  out.key("elem").string(classOf(v));
  out.key("shape").beginArray();
  for (std::size_t d : v.ndShape())
    out.unsignedInteger(d);
  out.endArray();
  out.key("order").string("row-major");
  int16_t l, t, m;
  ndUnit(v, l, t, m);
  writeUnitField(out, l, t, m);
  const std::size_t count = v.ndCount();
  if (count > budget) {
    out.key("truncated").boolean(true);
    budget = 0;
    return;
  }
  budget -= count;
  const std::vector<Value> cells = nd::rowMajorCells(v);
  if (v.isPackedComplex()) {
    out.key("re").beginArray();
    for (const Value &c : cells)
      out.number(c.number);
    out.endArray();
    out.key("im").beginArray();
    for (const Value &c : cells)
      out.number(c.isComplex ? c.imag : 0.0);
    out.endArray();
  } else if (v.isPacked()) {
    out.key("data").beginArray();
    for (const Value &c : cells)
      out.number(c.number);
    out.endArray();
  } else {
    out.key("items").beginArray();
    for (const Value &c : cells)
      writeValueJson(out, c, budget, depth + 1);
    out.endArray();
  }
}

void writeTensorJson(JsonWriter &out, const Value &v, std::size_t &budget) {
  const bool complex = v.isPackedComplex();
  const std::size_t rows = v.isMatrix ? v.rows() : 1;
  const std::size_t cols = v.isMatrix ? v.cols() : v.length();
  const std::size_t count = rows * cols;
  out.key("k").string("tensor");
  out.key("elem").string(complex ? "complex128" : "float64");
  out.key("shape").beginArray();
  if (v.isMatrix)
    out.unsignedInteger(rows);
  out.unsignedInteger(cols);
  out.endArray();
  int16_t l, t, m;
  tensorUnit(v, l, t, m);
  writeUnitField(out, l, t, m);
  if (count > budget) {
    out.key("truncated").boolean(true);
    budget = 0;
    return;
  }
  budget -= count;
  // Row-major in JSON (what a reader indexing [r][c] expects); the packed
  // buffer itself is column-major.
  auto emit = [&](const char *name, bool imagPart) {
    out.key(name).beginArray();
    for (std::size_t r = 0; r < rows; r++)
      for (std::size_t c = 0; c < cols; c++) {
        std::complex<double> z = v.isMatrix ? v.cnumAt(r, c) : v.cnumAt(c);
        out.number(imagPart ? z.imag() : z.real());
      }
    out.endArray();
  };
  if (complex) {
    emit("re", false);
    emit("im", true);
  } else {
    out.key("data").beginArray();
    if (v.isMatrix) {
      for (std::size_t r = 0; r < rows; r++)
        for (std::size_t c = 0; c < cols; c++)
          out.number(v.numAt(r, c));
    } else {
      const double *data = v.packedData();
      for (std::size_t i = 0; i < count; i++)
        out.number(data[i]);
    }
    out.endArray();
  }
}

} // namespace

std::string classOf(const Value &v) {
  if (v.isTimestamp())
    return "timestamp";
  if (v.isDuration())
    return "duration";
  // A typed tensor: every element has its one type (2026-11-20; the cell
  // walk below made a Value per element - minutes for 628 million).
  if ((v.isArray || v.isMatrix) && v.isTypedPacked() && v.tensorCount() > 0)
    return elemTypeName(v.elemType());
  if (v.isND()) {
    // One class for the whole matrix, as for 2-D ones.
    if (v.isPackedComplex())
      return "complex";
    if (v.isPacked())
      return "float64";
    std::string common;
    for (std::size_t k = 0; k < v.ndCount(); k++) {
      const std::string cls = classOf(v.ndAt(k));
      if (common.empty())
        common = cls;
      else if (common != cls)
        return "cell";
    }
    return common.empty() ? "float64" : common;
  }
  switch (dataKindOf(v)) {
  case DataKind::Timestamp:
    return "timestamp";
  case DataKind::Duration:
    return "duration";
  case DataKind::Float64:
    return floatTypeName(v.floatType()); // "float64" unless float8/16/32
  case DataKind::Complex:
    return "complex";
  case DataKind::Bool:
    return "bool";
  case DataKind::Int:
    return intTypeName(v.intType());
  case DataKind::Text:
    return "string";
  case DataKind::Tensor:
    return v.isPackedComplex() ? "complex" : "float64";
  case DataKind::CellArray:
  case DataKind::CellMatrix: {
    // A container whose elements all share one scalar class reports that
    // class (an int64 array is "int64", not "cell").
    std::string common;
    const std::size_t rows = v.isMatrix ? v.rows() : 1;
    for (std::size_t r = 0; r < rows; r++) {
      const std::size_t len = v.isMatrix ? v.rowLength(r) : v.length();
      for (std::size_t c = 0; c < len; c++) {
        Value e = v.isMatrix ? v.at(r, c) : v.at(c);
        DataKind k = dataKindOf(e);
        if (k != DataKind::Float64 && k != DataKind::Complex && k != DataKind::Bool &&
            k != DataKind::Int && k != DataKind::Text && k != DataKind::Timestamp &&
            k != DataKind::Duration)
          return "cell";
        std::string cls = classOf(e);
        if (common.empty())
          common = cls;
        else if (common != cls)
          return "cell";
      }
    }
    return common.empty() ? "float64" : common;
  }
  case DataKind::Dict:
    return "dict";
  case DataKind::Object:
    return v.className().empty() ? "object" : v.className();
  case DataKind::FuncRef:
    return "function_handle";
  }
  return "float64";
}

std::string sizeOf(const Value &v) {
  if (v.isND())
    return nd::shapeText(v.ndShape());
  switch (dataKindOf(v)) {
  case DataKind::Text:
    return "1x" + std::to_string(utf8Length(v.text()));
  case DataKind::Tensor:
  case DataKind::CellArray:
  case DataKind::CellMatrix:
    if (v.isMatrix)
      return std::to_string(v.rows()) + "x" + std::to_string(maxRowLength(v));
    return "1x" + std::to_string(v.length());
  case DataKind::Dict:
    return std::to_string(v.dict().size()) + "x1";
  default:
    return "1x1";
  }
}

std::string previewOf(const Value &v) {
  std::string out;
  appendPreview(out, v, false);
  truncateUtf8(out, kPreviewChars);
  return out;
}

VariableSummary summarizeVariable(const std::string &name, const Value &v, uint64_t hash) {
  VariableSummary s;
  s.name = name;
  s.cls = classOf(v);
  s.size = sizeOf(v);
  int16_t l = v.dimL, t = v.dimT, m = v.dimM;
  if (v.isND())
    ndUnit(v, l, t, m);
  else if (dataKindOf(v) == DataKind::Tensor)
    tensorUnit(v, l, t, m);
  s.unit = unitText(l, t, m);
  s.preview = previewOf(v);
  s.hash = hash;
  return s;
}

void writeSummaryJson(JsonWriter &out, const VariableSummary &s) {
  char hex[17];
  std::snprintf(hex, sizeof hex, "%016llx", static_cast<unsigned long long>(s.hash));
  out.beginObject();
  out.key("name").string(s.name);
  out.key("class").string(s.cls);
  out.key("size").string(s.size);
  out.key("unit").string(s.unit);
  out.key("preview").string(s.preview);
  out.key("hash").string(hex);
  out.endObject();
}

void writeValueJson(JsonWriter &out, const Value &v, std::size_t &budget, int depth) {
  out.beginObject();
  if (depth > kMaxJsonDepth) {
    out.key("k").string("deep");
    out.key("truncated").boolean(true);
    out.endObject();
    return;
  }
  if (v.isND()) {
    writeNDJson(out, v, budget, depth);
    out.endObject();
    return;
  }
  // {"k":"time", "t":"timestamp"|"duration", "ns":"<int64>", "v":"<display>"}
  // - nanoseconds as a string, like an int64 (a JSON reader's double cannot
  // hold them); a timestamp counts from 1970-01-01 00:00:00 UTC.
  if (v.isTime()) {
    out.key("k").string("time");
    out.key("t").string(nctime::typeName(v));
    out.key("ns").string(std::to_string(v.timeNs()));
    out.key("v").string(nctime::displayText(v));
    out.endObject();
    return;
  }
  const DataKind kind = dataKindOf(v);
  switch (kind) {
  case DataKind::Timestamp:
  case DataKind::Duration:
    break; // written above
  case DataKind::Float64:
    out.key("k").string("num");
    out.key("t").string(floatTypeName(v.floatType()));
    out.key("v").number(v.number);
    break;
  case DataKind::Complex:
    out.key("k").string("complex");
    out.key("re").number(v.number);
    out.key("im").number(v.imag);
    break;
  case DataKind::Bool:
    out.key("k").string("bool");
    out.key("v").boolean(v.number != 0.0);
    break;
  case DataKind::Int:
    // As a string: an int64/uint64 does not survive a trip through a
    // JSON reader's double.
    out.key("k").string("int");
    out.key("t").string(intTypeName(v.intType()));
    out.key("v").string(v.intText());
    break;
  case DataKind::Text:
    out.key("k").string("str");
    out.key("v").string(v.text());
    break;
  case DataKind::Tensor:
    writeTensorJson(out, v, budget);
    break;
  case DataKind::CellArray: {
    out.key("k").string("cell");
    out.key("shape").beginArray();
    out.unsignedInteger(v.length());
    out.endArray();
    if (v.length() > budget) {
      out.key("truncated").boolean(true);
      budget = 0;
      break;
    }
    budget -= v.length();
    out.key("items").beginArray();
    for (std::size_t i = 0; i < v.length(); i++)
      writeValueJson(out, v.at(i), budget, depth + 1);
    out.endArray();
    break;
  }
  case DataKind::CellMatrix: {
    out.key("k").string("cellmatrix");
    const std::size_t total = elementCount(v);
    out.key("shape").beginArray();
    out.unsignedInteger(v.rows());
    out.unsignedInteger(maxRowLength(v));
    out.endArray();
    if (total > budget) {
      out.key("truncated").boolean(true);
      budget = 0;
      break;
    }
    budget -= total;
    out.key("rows").beginArray();
    for (std::size_t r = 0; r < v.rows(); r++) {
      out.beginArray();
      for (std::size_t c = 0; c < v.rowLength(r); c++)
        writeValueJson(out, v.at(r, c), budget, depth + 1);
      out.endArray();
    }
    out.endArray();
    break;
  }
  case DataKind::Dict:
    out.key("k").string("dict");
    out.key("entries");
    writeEntriesJson(out, v.dict(), budget, depth);
    break;
  case DataKind::Object:
    out.key("k").string("object");
    out.key("class").string(v.className());
    out.key("fields");
    writeEntriesJson(out, v.dict(), budget, depth);
    out.key("lineage").beginArray();
    for (const std::string &entry : v.lineage())
      out.string(entry);
    out.endArray();
    out.key("snapshots").unsignedInteger(v.snapshots().size());
    break;
  case DataKind::FuncRef:
    out.key("k").string("func");
    // The name after '@' as the user wrote it - for an anonymous function
    // its text, "(x) x * 2", without the internal numbering.
    out.key("name").string(functionRefText(v.funcRefName()).substr(1));
    break;
  }
  if (kind != DataKind::Tensor)
    writeUnitField(out, v.dimL, v.dimT, v.dimM);
  out.endObject();
}

/* ---- windows (2026-11-20, docs/Java_Speed_CPP_Asks.md V1) ---- */

bool isWindowable(const Value &v) { return (v.isArray || v.isMatrix) && !v.isText; }

void writeWindowFields(JsonWriter &out, const Value &v, std::size_t r0, std::size_t r1, std::size_t c0,
                       std::size_t c1, const std::vector<std::size_t> &page) {
  const bool tensorBacked = v.isPacked() || v.isPackedComplex() || v.isTypedPacked();
  const bool nd = v.isND();

  // The value's own shape and its grid (the last two axes).
  std::vector<std::size_t> full;
  if (nd)
    full = v.ndShape();
  else if (v.isMatrix)
    full = {v.rows(), tensorBacked ? v.cols() : maxRowLength(v)};
  else
    full = {v.length()};
  const std::size_t rank = full.size();
  const std::size_t rows = rank >= 2 ? full[rank - 2] : 1;
  const std::size_t cols = rank >= 1 ? full[rank - 1] : 1;

  // N-D: the page's first storage index (pages in row-major order of the
  // leading axes, each page rows x cols column-major).
  std::vector<std::size_t> keys;
  std::size_t base = 0;
  if (nd) {
    std::size_t pageIndex = 0;
    for (std::size_t axis = 0; axis + 2 < rank; axis++) {
      std::size_t key = axis < page.size() ? page[axis] : 0;
      key = full[axis] == 0 ? 0 : std::min(key, full[axis] - 1);
      keys.push_back(key);
      pageIndex = pageIndex * full[axis] + key;
    }
    base = pageIndex * rows * cols;
  }

  r1 = std::min(r1, rows);
  r0 = std::min(r0, r1);
  c1 = std::min(c1, cols);
  c0 = std::min(c0, c1);
  const std::size_t br = r1 - r0, bc = c1 - c0;

  out.key("window").beginArray();
  out.unsignedInteger(r0);
  out.unsignedInteger(r1);
  out.unsignedInteger(c0);
  out.unsignedInteger(c1);
  out.endArray();
  out.key("full").beginArray();
  for (std::size_t d : full)
    out.unsignedInteger(d);
  out.endArray();
  if (nd) {
    out.key("page").beginArray();
    for (std::size_t k : keys)
      out.unsignedInteger(k);
    out.endArray();
  }
  if (br * bc > kMaxWindowElements) {
    out.key("error").string("a window holds at most " + std::to_string(kMaxWindowElements) + " elements");
    return;
  }

  // Storage index of grid cell (r, c) of a tensor-backed value.
  auto storage = [&](std::size_t r, std::size_t c) { return rank == 1 ? c : base + c * rows + r; };

  out.key("value").beginObject();
  if (v.isPacked() || v.isPackedComplex()) {
    // float64 / complex: a "tensor" block, row-major, as writeTensorJson().
    const bool complex = v.isPackedComplex();
    out.key("k").string("tensor");
    out.key("elem").string(complex ? "complex128" : "float64");
    out.key("shape").beginArray();
    out.unsignedInteger(br);
    out.unsignedInteger(bc);
    out.endArray();
    int16_t l, t, m;
    v.unitDims(l, t, m);
    writeUnitField(out, l, t, m);
    if (complex) {
      auto emit = [&](const char *name, bool imagPart) {
        out.key(name).beginArray();
        for (std::size_t r = r0; r < r1; r++)
          for (std::size_t c = c0; c < c1; c++) {
            const std::complex<double> z = nd ? v.ndCnumAt(storage(r, c))
                                         : rank == 1 ? v.cnumAt(c)
                                                     : v.cnumAt(r, c);
            out.number(imagPart ? z.imag() : z.real());
          }
        out.endArray();
      };
      emit("re", false);
      emit("im", true);
    } else {
      // A lazy range is read from its rule (RealReader): nothing is built.
      ncpacked::RealReader in;
      in.open(v);
      out.key("data").beginArray();
      for (std::size_t r = r0; r < r1; r++)
        for (std::size_t c = c0; c < c1; c++)
          out.number(in.at(storage(r, c)));
      out.endArray();
    }
  } else {
    // Typed numbers, text, cells: a "cellmatrix" block, each element as a
    // full getvar writes it.
    out.key("k").string("cellmatrix");
    out.key("shape").beginArray();
    out.unsignedInteger(br);
    out.unsignedInteger(bc);
    out.endArray();
    std::size_t budget = kMaxWindowElements; // nested cells: as a full getvar's budget would allow
    out.key("rows").beginArray();
    for (std::size_t r = r0; r < r1; r++) {
      out.beginArray();
      for (std::size_t c = c0; c < c1; c++) {
        if (nd) {
          writeValueJson(out, v.ndAt(storage(r, c)), budget, 1);
        } else if (rank == 1) {
          writeValueJson(out, v.at(c), budget, 1);
        } else {
          if (c >= v.rowLength(r))
            break; // a ragged cell matrix: this row ends here
          writeValueJson(out, v.at(r, c), budget, 1);
        }
      }
      out.endArray();
    }
    out.endArray();
  }
  out.endObject();
}

} // namespace ncdata
