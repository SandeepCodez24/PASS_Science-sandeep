#include "ValueJson.h"

#include <algorithm>
#include <cstdio>
#include <vector>

#include "../../interpreter/core/output.h"
#include "../../interpreter/ops/floating/floating.h"
#include "../../interpreter/ops/integer/integer.h"
#include "ValueInspect.h"

namespace ncdata {

namespace {

// Previews longer than this end in "...".
constexpr std::size_t kPreviewChars = 400;
// Arrays/matrices with more elements than this are previewed as
// "<3x400 float64>" instead of listing their elements.
constexpr std::size_t kPreviewElements = 1000;
// Nesting deeper than this is written as a placeholder in full-value JSON.
constexpr int kMaxJsonDepth = 64;

std::size_t utf8Length(const std::string &s) {
  std::size_t n = 0;
  for (unsigned char c : s)
    if ((c & 0xC0) != 0x80)
      n++;
  return n;
}

// Cuts `s` to at most `maxBytes` bytes without splitting a UTF-8 sequence.
void truncateUtf8(std::string &s, std::size_t maxBytes) {
  if (s.size() <= maxBytes)
    return;
  std::size_t cut = maxBytes;
  while (cut > 0 && (static_cast<unsigned char>(s[cut]) & 0xC0) == 0x80)
    cut--;
  s.resize(cut);
  s += "...";
}

std::size_t elementCount(const Value &v) {
  if (v.isArray)
    return v.length();
  if (v.isMatrix) {
    std::size_t n = 0;
    for (std::size_t r = 0; r < v.rows(); r++)
      n += v.rowLength(r);
    return n;
  }
  return 1;
}

std::size_t maxRowLength(const Value &v) {
  std::size_t widest = 0;
  for (std::size_t r = 0; r < v.rows(); r++)
    widest = std::max(widest, v.rowLength(r));
  return widest;
}

std::string scalarText(const Value &v) {
  switch (dataKindOf(v)) {
  case DataKind::Bool:
    return v.number != 0.0 ? "true" : "false";
  case DataKind::Int:
    return v.intText();
  case DataKind::Complex:
    return formatComplex(v.number, v.imag);
  default:
    return formatNumber(v.number);
  }
}

// Appends a compact one-line rendering of `v`, stopping once `out` is past
// kPreviewChars.
void appendPreview(std::string &out, const Value &v, bool quoteText) {
  if (out.size() > kPreviewChars)
    return;
  switch (dataKindOf(v)) {
  case DataKind::Text:
    out += quoteText ? "\"" + v.text() + "\"" : v.text();
    return;
  case DataKind::FuncRef:
    out += "@" + v.funcRefName();
    return;
  case DataKind::Object:
    out += v.className() + " object";
    return;
  case DataKind::Dict: {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    out += "{";
    for (std::size_t i = 0; i < keys.size() && out.size() <= kPreviewChars; i++) {
      if (i)
        out += ", ";
      out += keys[i] + ": ";
      appendPreview(out, v.dict().at(keys[i]), true);
    }
    out += "}";
    return;
  }
  case DataKind::Tensor:
  case DataKind::CellArray:
  case DataKind::CellMatrix: {
    if (elementCount(v) > kPreviewElements) {
      out += "<" + sizeOf(v) + " " + classOf(v) + ">";
      return;
    }
    if (v.isArray) {
      out += "[";
      for (std::size_t i = 0; i < v.length() && out.size() <= kPreviewChars; i++) {
        if (i)
          out += ",";
        appendPreview(out, v.at(i), true);
      }
      out += "]";
    } else {
      // Same nesting as the interpreter's old workspace format, which the
      // IDE's numeric parsing of the value column already understands.
      out += "[";
      for (std::size_t r = 0; r < v.rows() && out.size() <= kPreviewChars; r++) {
        out += r ? ",[" : "[";
        for (std::size_t c = 0; c < v.rowLength(r) && out.size() <= kPreviewChars; c++) {
          if (c)
            out += ",";
          appendPreview(out, v.at(r, c), true);
        }
        out += "]";
      }
      out += "]";
    }
    return;
  }
  default: {
    out += scalarText(v);
    std::string unit = unitText(v.dimL, v.dimT, v.dimM);
    if (!unit.empty())
      out += " " + unit;
  }
  }
}

void writeUnitField(JsonWriter &out, int16_t l, int16_t t, int16_t m) {
  if (!hasUnits(l, t, m))
    return;
  out.key("unit").beginObject();
  out.key("L").integer(l);
  out.key("T").integer(t);
  out.key("M").integer(m);
  out.endObject();
  out.key("unitText").string(unitText(l, t, m));
}

void writeEntriesJson(JsonWriter &out, const std::unordered_map<std::string, Value> &map,
                      std::size_t &budget, int depth) {
  std::vector<const std::pair<const std::string, Value> *> entries;
  for (const auto &kv : map)
    entries.push_back(&kv);
  std::sort(entries.begin(), entries.end(),
            [](const auto *a, const auto *b) { return a->first < b->first; });
  out.beginArray();
  for (const auto *kv : entries) {
    out.beginObject();
    out.key("key").string(kv->first);
    out.key("value");
    writeValueJson(out, kv->second, budget, depth + 1);
    out.endObject();
  }
  out.endArray();
}

void writeTensorJson(JsonWriter &out, const Value &v, std::size_t &budget) {
  const bool complex = v.isPackedComplex();
  const std::size_t rows = v.isMatrix ? v.rows() : 1;
  const std::size_t cols = v.isMatrix ? v.cols() : v.length();
  const std::size_t count = rows * cols;
  out.key("k").string("tensor");
  out.key("elem").string(complex ? "complex128" : "float64");
  out.key("shape").beginArray();
  if (v.isMatrix)
    out.unsignedInteger(rows);
  out.unsignedInteger(cols);
  out.endArray();
  int16_t l, t, m;
  tensorUnit(v, l, t, m);
  writeUnitField(out, l, t, m);
  if (count > budget) {
    out.key("truncated").boolean(true);
    budget = 0;
    return;
  }
  budget -= count;
  // Row-major in JSON (what a reader indexing [r][c] expects); the packed
  // buffer itself is column-major.
  auto emit = [&](const char *name, bool imagPart) {
    out.key(name).beginArray();
    for (std::size_t r = 0; r < rows; r++)
      for (std::size_t c = 0; c < cols; c++) {
        std::complex<double> z = v.isMatrix ? v.cnumAt(r, c) : v.cnumAt(c);
        out.number(imagPart ? z.imag() : z.real());
      }
    out.endArray();
  };
  if (complex) {
    emit("re", false);
    emit("im", true);
  } else {
    out.key("data").beginArray();
    if (v.isMatrix) {
      for (std::size_t r = 0; r < rows; r++)
        for (std::size_t c = 0; c < cols; c++)
          out.number(v.numAt(r, c));
    } else {
      const double *data = v.packedData();
      for (std::size_t i = 0; i < count; i++)
        out.number(data[i]);
    }
    out.endArray();
  }
}

} // namespace

std::string classOf(const Value &v) {
  switch (dataKindOf(v)) {
  case DataKind::Float64:
    return floatTypeName(v.floatType()); // "float64" unless float8/16/32
  case DataKind::Complex:
    return "complex";
  case DataKind::Bool:
    return "bool";
  case DataKind::Int:
    return intTypeName(v.intType());
  case DataKind::Text:
    return "string";
  case DataKind::Tensor:
    return v.isPackedComplex() ? "complex" : "float64";
  case DataKind::CellArray:
  case DataKind::CellMatrix: {
    // A container whose elements all share one scalar class reports that
    // class (an int64 array is "int64", not "cell").
    std::string common;
    const std::size_t rows = v.isMatrix ? v.rows() : 1;
    for (std::size_t r = 0; r < rows; r++) {
      const std::size_t len = v.isMatrix ? v.rowLength(r) : v.length();
      for (std::size_t c = 0; c < len; c++) {
        Value e = v.isMatrix ? v.at(r, c) : v.at(c);
        DataKind k = dataKindOf(e);
        if (k != DataKind::Float64 && k != DataKind::Complex && k != DataKind::Bool &&
            k != DataKind::Int && k != DataKind::Text)
          return "cell";
        std::string cls = classOf(e);
        if (common.empty())
          common = cls;
        else if (common != cls)
          return "cell";
      }
    }
    return common.empty() ? "float64" : common;
  }
  case DataKind::Dict:
    return "dict";
  case DataKind::Object:
    return v.className().empty() ? "object" : v.className();
  case DataKind::FuncRef:
    return "function_handle";
  }
  return "float64";
}

std::string sizeOf(const Value &v) {
  switch (dataKindOf(v)) {
  case DataKind::Text:
    return "1x" + std::to_string(utf8Length(v.text()));
  case DataKind::Tensor:
  case DataKind::CellArray:
  case DataKind::CellMatrix:
    if (v.isMatrix)
      return std::to_string(v.rows()) + "x" + std::to_string(maxRowLength(v));
    return "1x" + std::to_string(v.length());
  case DataKind::Dict:
    return std::to_string(v.dict().size()) + "x1";
  default:
    return "1x1";
  }
}

std::string previewOf(const Value &v) {
  std::string out;
  appendPreview(out, v, false);
  truncateUtf8(out, kPreviewChars);
  return out;
}

VariableSummary summarizeVariable(const std::string &name, const Value &v, uint64_t hash) {
  VariableSummary s;
  s.name = name;
  s.cls = classOf(v);
  s.size = sizeOf(v);
  int16_t l = v.dimL, t = v.dimT, m = v.dimM;
  if (dataKindOf(v) == DataKind::Tensor)
    tensorUnit(v, l, t, m);
  s.unit = unitText(l, t, m);
  s.preview = previewOf(v);
  s.hash = hash;
  return s;
}

void writeSummaryJson(JsonWriter &out, const VariableSummary &s) {
  char hex[17];
  std::snprintf(hex, sizeof hex, "%016llx", static_cast<unsigned long long>(s.hash));
  out.beginObject();
  out.key("name").string(s.name);
  out.key("class").string(s.cls);
  out.key("size").string(s.size);
  out.key("unit").string(s.unit);
  out.key("preview").string(s.preview);
  out.key("hash").string(hex);
  out.endObject();
}

void writeValueJson(JsonWriter &out, const Value &v, std::size_t &budget, int depth) {
  out.beginObject();
  if (depth > kMaxJsonDepth) {
    out.key("k").string("deep");
    out.key("truncated").boolean(true);
    out.endObject();
    return;
  }
  const DataKind kind = dataKindOf(v);
  switch (kind) {
  case DataKind::Float64:
    out.key("k").string("num");
    out.key("t").string(floatTypeName(v.floatType()));
    out.key("v").number(v.number);
    break;
  case DataKind::Complex:
    out.key("k").string("complex");
    out.key("re").number(v.number);
    out.key("im").number(v.imag);
    break;
  case DataKind::Bool:
    out.key("k").string("bool");
    out.key("v").boolean(v.number != 0.0);
    break;
  case DataKind::Int:
    // As a string: an int64/uint64 does not survive a trip through a
    // JSON reader's double.
    out.key("k").string("int");
    out.key("t").string(intTypeName(v.intType()));
    out.key("v").string(v.intText());
    break;
  case DataKind::Text:
    out.key("k").string("str");
    out.key("v").string(v.text());
    break;
  case DataKind::Tensor:
    writeTensorJson(out, v, budget);
    break;
  case DataKind::CellArray: {
    out.key("k").string("cell");
    out.key("shape").beginArray();
    out.unsignedInteger(v.length());
    out.endArray();
    if (v.length() > budget) {
      out.key("truncated").boolean(true);
      budget = 0;
      break;
    }
    budget -= v.length();
    out.key("items").beginArray();
    for (std::size_t i = 0; i < v.length(); i++)
      writeValueJson(out, v.at(i), budget, depth + 1);
    out.endArray();
    break;
  }
  case DataKind::CellMatrix: {
    out.key("k").string("cellmatrix");
    const std::size_t total = elementCount(v);
    out.key("shape").beginArray();
    out.unsignedInteger(v.rows());
    out.unsignedInteger(maxRowLength(v));
    out.endArray();
    if (total > budget) {
      out.key("truncated").boolean(true);
      budget = 0;
      break;
    }
    budget -= total;
    out.key("rows").beginArray();
    for (std::size_t r = 0; r < v.rows(); r++) {
      out.beginArray();
      for (std::size_t c = 0; c < v.rowLength(r); c++)
        writeValueJson(out, v.at(r, c), budget, depth + 1);
      out.endArray();
    }
    out.endArray();
    break;
  }
  case DataKind::Dict:
    out.key("k").string("dict");
    out.key("entries");
    writeEntriesJson(out, v.dict(), budget, depth);
    break;
  case DataKind::Object:
    out.key("k").string("object");
    out.key("class").string(v.className());
    out.key("fields");
    writeEntriesJson(out, v.dict(), budget, depth);
    out.key("lineage").beginArray();
    for (const std::string &entry : v.lineage())
      out.string(entry);
    out.endArray();
    out.key("snapshots").unsignedInteger(v.snapshots().size());
    break;
  case DataKind::FuncRef:
    out.key("k").string("func");
    out.key("name").string(v.funcRefName());
    break;
  }
  if (kind != DataKind::Tensor)
    writeUnitField(out, v.dimL, v.dimT, v.dimM);
  out.endObject();
}

} // namespace ncdata
