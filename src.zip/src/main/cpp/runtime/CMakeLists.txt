# NC runtime (interpreter core, builtin ops, symbol storage, data layer).
# Exposes its sources/includes to the top-level ../CMakeLists.txt, which
# links them into the single `nc` executable together with compiler/CMakeLists.txt.

# NumPy-equivalent library: every .cpp under interpreter/Numpy/ (all 11
# section folders) lands in NC_NUMPY_SOURCES. It is a glob with
# CONFIGURE_DEPENDS, so section developers add files without editing this.
include(${CMAKE_CURRENT_SOURCE_DIR}/interpreter/Numpy/numpy_sources.cmake)
# SciPy-equivalent library: same mechanism, all 25 section folders under
# interpreter/Scipy/ land in NC_SCIPY_SOURCES.
include(${CMAKE_CURRENT_SOURCE_DIR}/interpreter/Scipy/scipy_sources.cmake)

set(RUNTIME_SOURCES
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/ScriptManager/SM_main.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/ScriptManager/SM_stage_01.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/ScriptManager/SM_stage_02.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/builtins/builtins.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/output.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/elementwise.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/function_files.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core/units.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/builtins/constants_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/arithmetic/arithmetic.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/arithmetic/arithmetic_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/complex/complex_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/calculus/calculus.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/calculus/calculus_builtin.cpp
    # Engineering-mathematics functions (Kreyszig ch. 1-25), served by the
    # ops registry (interpreter/ops/support/ops_registry.h).
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/support/ops_registry.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/support/ops_math.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/calculus/calculus_fields.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/ode/ode_qualitative.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/ode/ode_series_laplace.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/fourier/fourier_core.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/fourier/fourier_series.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/pde/pde_solvers.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/complex/complex_analysis.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/complex/complex_residue.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/complex/complex_mapping.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/statistics/statistics_probability.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/statistics/statistics_inference.cpp
    # Data processing (Process Data window, docs/Process_Window_CPP.md P5).
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/process/process_common.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/process/process_text.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/process/process_stats.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/process/process_encode.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/process/process_table.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/collections/collections_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/collections/nullset_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/dc/dc.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/dc/dc_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/geometric/geometric.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/geometric/geometric_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/matrix/matrix.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/matrix/matrix_arithmetic.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/matrix/matrix_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/plot/plot_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/statistics/statistics.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/statistics/statistics_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/time/time.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/time/time_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/time/time_calendar.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/time/time_ops.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/time/time_zone.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/time/time_zone_data.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/trigonometric/trigonometric.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/trigonometric/trigonometric_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/vector/vector.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/vector/vector_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/integer/integer.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/ops/floating/floating.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/codegen_bridge/value_bridge.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/memory/symbols/symbol_table.cpp
    # The memory governor: budget, refusal instead of paging, the 12 G
    # element limit (docs/Large_Data_Design.md section 2).
    ${CMAKE_CURRENT_SOURCE_DIR}/memory/governor.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/memory/governor_new.cpp
    # Data layer: .ndat persistence + the JSON workspace channel to the IDE
    # (replaces memory/store/variable_store.cpp and variables.txt).
    ${CMAKE_CURRENT_SOURCE_DIR}/data/DataEngine.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/data/DataSupport/NdatWriter.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/data/DataSupport/NdatReader.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/data/DataSupport/NdatBundle.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/data/DataSupport/JsonWriter.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/data/DataSupport/ValueJson.cpp
    # Cooperative Stop for a running command.
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/Interrupt.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/stack_guard.cpp
    # A crash says why (stderr, @FATAL, <session>/fatal.json).
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/crash_report.cpp
    # nc::par - multicore kernels, the OS layer and the IDE's CPU monitor
    # (docs/Multicore_Multithread_Architecture.md).
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/parallel/par.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/parallel/par_monitor.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/parallel/sys_cpu.cpp
    # The IDE's Analysis box: computations, order of growth, time profile.
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/analysis/analysis.cpp
    # NumPy- and SciPy-equivalent libraries (see the include()s at the top).
    ${NC_NUMPY_SOURCES}
    ${NC_SCIPY_SOURCES}
    PARENT_SCOPE
)

set(RUNTIME_INCLUDE_DIRS
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter
    ${CMAKE_CURRENT_SOURCE_DIR}/interpreter/core
    ${CMAKE_CURRENT_SOURCE_DIR}/memory/store
    ${CMAKE_CURRENT_SOURCE_DIR}/memory/symbols
    ${CMAKE_CURRENT_SOURCE_DIR}/memory
    ${CMAKE_CURRENT_SOURCE_DIR}/data
    ${CMAKE_CURRENT_SOURCE_DIR}/execution
    ${CMAKE_CURRENT_SOURCE_DIR}/execution/parallel
    PARENT_SCOPE
)
