#include "builtins.h"

#include <algorithm>
#include <cmath>
#include <cctype>
#include <iostream>
#include <unordered_map>

#include "../ops/arithmetic/arithmetic.h"
#include "../ops/arithmetic/arithmetic_builtin.h"
#include "../ops/calculus/calculus_builtin.h" // the ops registry (support/ops_registry.h)
#include "../ops/collections/collections_builtin.h"
#include "../ops/complex/complex_builtin.h"
#include "../../compiler/compiler_src/conditional_opr/conditional_builtin.h"
#include "../../compiler/compiler_src/conditional_opr/logical_builtin.h"
#include "../ops/dc/dc_builtin.h"
#include "../ops/geometric/geometric_builtin.h"
#include "../ops/matrix/matrix_builtin.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/time/time.h"
#include "../ops/time/time_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/statistics/statistics_builtin.h"
#include "../ops/trigonometric/trigonometric_builtin.h"
#include "../ops/vector/vector_builtin.h"
// NumPy- and SciPy-equivalent libraries (runtime/interpreter/Numpy/ and
// Scipy/) - consulted only after builtinTable, in that order, so an existing
// ops/ builtin always keeps its name, and NumPy wins over SciPy.
#include "../Numpy/numpy_main.h"
#include "../Scipy/scipy_main.h"
// Inputs by name for builtins (core/param_list.h, core/arg_binding.h).
#include "../core/elementwise.h"
#include "parallel/par.h"
#include "parallel/sys_cpu.h"
#include "analysis/analysis.h"
#include "../core/computation_cost.h"
#include "../core/param_list.h"
#include "../Numpy/numpy_registry.h"

bool g_lastBuiltinFound = true;

using BuiltinHandler = Value (*)(const std::string &,
                                 const std::vector<Value> &);

static std::string normalizeIdentifier(std::string s) {
  // Requirement: builtins (functions) are not the constants system.
  // However, to avoid case/whitespace surprises for identifiers,
  // we normalize similarly.
  s.erase(std::remove_if(s.begin(), s.end(), ::isspace), s.end());
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return std::tolower(c); });
  return s;
}

// Multicore settings: set_threads / get_threads / thread_info (below).
static Value parallelBuiltin(const std::string &name, const std::vector<Value> &args);

static const std::unordered_map<std::string, BuiltinHandler> builtinTable = {

    // Multicore settings
    {"set_threads", parallelBuiltin},
    {"get_threads", parallelBuiltin},
    {"thread_info", parallelBuiltin},

    // Statistics
    {"mean", statisticsBuiltin},
    {"median", statisticsBuiltin},
    {"mode", statisticsBuiltin},
    {"geo_mean", statisticsBuiltin},
    {"harmo_mean", statisticsBuiltin},
    {"trim_mean", statisticsBuiltin},
    {"var", statisticsBuiltin},
    {"pvar", statisticsBuiltin},
    {"sd", statisticsBuiltin},
    {"psd", statisticsBuiltin},
    {"coeff_var", statisticsBuiltin},
    {"cv", statisticsBuiltin},
    {"skew", statisticsBuiltin},
    {"kurtosis", statisticsBuiltin},
    {"std_error", statisticsBuiltin},
    {"corr_coeff", statisticsBuiltin},
    {"co_var", statisticsBuiltin},
    {"lsm", statisticsBuiltin},
    {"null_hypo", statisticsBuiltin},
    {"p_val_cal", statisticsBuiltin},
    {"chi_test", statisticsBuiltin},
    // Q1/Q2/Q3/IQR intentionally kept capitalized — exception to the
    // lowercase-only convention for the rest of this table, per explicit
    // request (these are conventional statistics notation).
    {"Q1", statisticsBuiltin},
    {"Q2", statisticsBuiltin},
    {"Q3", statisticsBuiltin},
    {"IQR", statisticsBuiltin},
    {"range", statisticsBuiltin},
    {"sum", statisticsBuiltin},
    {"count", statisticsBuiltin},
    {"min", statisticsBuiltin},
    {"max", statisticsBuiltin},
    {"percentile", statisticsBuiltin},
    {"z_score", statisticsBuiltin},
    {"lnorm", statisticsBuiltin},
    // Orphaned before this fix: fully implemented but never registered
    // here or in the inner statistics_builtin.cpp dispatch table (same
    // pattern as quotient/matrix_pow/norm_vector found earlier this pass).
    {"l2norm", statisticsBuiltin},

    // Arithmetic
    {"sqrt", arithmeticBuiltin},
    {"cbrt", arithmeticBuiltin},
    {"log", arithmeticBuiltin},
    {"sqr", arithmeticBuiltin},
    {"cube", arithmeticBuiltin},
    {"exp", arithmeticBuiltin},
    {"dec2frac", arithmeticBuiltin},
    {"abs", arithmeticBuiltin},
    {"frac2deci", arithmeticBuiltin},
    {"deci2frac", arithmeticBuiltin},
    {"quotient", arithmeticBuiltin},

    // Matrix
    {"rank", matrixBuiltin},
    {"det", matrixBuiltin},
    {"transpose", matrixBuiltin},
    // "matrix_norm" (not "norm" — that name is already owned by the Vector
    // category's lowercase "norm" below; giving the matrix norm a distinct
    // name avoids the two colliding in this same table).
    {"matrix_norm", matrixBuiltin},
    // pseudo_inverse is the long name of pinv, as conjugate is of conj
    // (Complex, below): removed in 2026-10, both back on 2026-10-30.
    {"pinv", matrixBuiltin},
    {"pseudo_inverse", matrixBuiltin},
    {"adj", matrixBuiltin},
    {"had_prod", matrixBuiltin},
    {"inv", matrixBuiltin},
    // "element_wise" removed 2026-10 - the operator A*.B replaces it.
    {"diag", matrixBuiltin},
    {"upper_triangular", matrixBuiltin},
    {"lower_triangular", matrixBuiltin},
    {"zero_matrix", matrixBuiltin},
    {"full_rank_matrix", matrixBuiltin},
    {"singular_matrix", matrixBuiltin},
    {"pd_matrix", matrixBuiltin},
    {"nd_matrix", matrixBuiltin},
    {"unit_matrix", matrixBuiltin},
    {"zeros", matrixBuiltin},
    {"ones", matrixBuiltin},
    // Random matrices (ops/matrix/matrix.cpp, nexus()).
    {"nexus", matrixBuiltin},
    {"nexus_float", matrixBuiltin},
    {"nexus_normal", matrixBuiltin},
    {"nexus_uniform", matrixBuiltin},
    {"nexus_utm", matrixBuiltin},
    {"nexus_ltm", matrixBuiltin},
    {"nexus_utm_float", matrixBuiltin},
    {"nexus_ltm_float", matrixBuiltin},
    {"nexus_utm_normal", matrixBuiltin},
    {"nexus_ltm_normal", matrixBuiltin},
    {"nexus_utm_uniform", matrixBuiltin},
    {"nexus_ltm_uniform", matrixBuiltin},
    {"nexus_seed", matrixBuiltin},
    {"trace", matrixBuiltin},
    // "onlyrows"/"onlycols" are exact duplicates of the old "Rows"/"Cols"
    // (same underlying OnlyRows/OnlyCols functions) — no separate
    // "rows"/"cols" needed. Registered lowercase (fixed 2026-09-16, was
    // "onlyRows"/"onlyCols"): callBuiltin's primary lookup always
    // lowercases the requested name before checking this table, so a
    // mixed-case-only key here was only ever reachable if a caller typed
    // that exact casing verbatim - "onlyrows"/"ONLYROWS"/etc. all failed
    // with "Unknown function", breaking the case-insensitive dispatch
    // documented for every other builtin. The inner dispatch table in
    // matrix_builtin.cpp does its own exact-string lookup against the
    // original (non-lowercased) name, so its keys had to be fixed to
    // lowercase too - see that file.
    {"onlyrows", matrixBuiltin},
    {"onlycols", matrixBuiltin},
    // Shapes, N-D matrices included (ops/matrix/matrix.cpp: ndReshape(),
    // ndShapeValue()).
    {"reshape", matrixBuiltin},
    {"shape", matrixBuiltin},
    {"ndims", matrixBuiltin},

    // Calculus: ddt, pddt, continuity, grad (grid form), curl, curl_calc,
    // div, laplace, green_integral (grid form), stokes_integral and
    // rad_of_con moved to the ops registry on 2026-11-04 together with the
    // engineering-mathematics functions (ops/support/ops_registry.h). Their
    // old forms still work there; callBuiltin() asks that registry first.

    // Trigonometric
    {"sin", trigonometricBuiltin},
    {"cos", trigonometricBuiltin},
    {"tan", trigonometricBuiltin},
    {"cosec", trigonometricBuiltin},
    {"sec", trigonometricBuiltin},
    {"cot", trigonometricBuiltin},
    {"inv_sin", trigonometricBuiltin},
    {"inv_cos", trigonometricBuiltin},
    {"inv_tan", trigonometricBuiltin},
    {"inv_cosec", trigonometricBuiltin},
    {"inv_sec", trigonometricBuiltin},
    {"inv_cot", trigonometricBuiltin},
    {"arcsin", trigonometricBuiltin},
    {"arccos", trigonometricBuiltin},
    {"arctan", trigonometricBuiltin},
    {"arccosec", trigonometricBuiltin},
    {"arcsec", trigonometricBuiltin},
    {"arccot", trigonometricBuiltin},
    {"atan2", trigonometricBuiltin},
    {"sinh", trigonometricBuiltin},
    {"cosh", trigonometricBuiltin},
    {"tanh", trigonometricBuiltin},
    {"cosech", trigonometricBuiltin},
    {"sech", trigonometricBuiltin},
    {"coth", trigonometricBuiltin},
    {"sin_deg", trigonometricBuiltin},
    {"cos_deg", trigonometricBuiltin},
    {"tan_deg", trigonometricBuiltin},
    {"cosec_deg", trigonometricBuiltin},
    {"sec_deg", trigonometricBuiltin},
    {"cot_deg", trigonometricBuiltin},

    // Geometry
    {"char_circle", geometricBuiltin},
    {"char_square", geometricBuiltin},
    {"char_triangle", geometricBuiltin},
    {"char_rectangle", geometricBuiltin},
    {"char_ellipse", geometricBuiltin},
    {"char_pentagon", geometricBuiltin},
    {"char_hexagon", geometricBuiltin},
    {"char_heptagon", geometricBuiltin},
    {"char_nonagon", geometricBuiltin},
    {"char_semicircle", geometricBuiltin},
    {"char_rhombus", geometricBuiltin},
    {"char_rtriangle", geometricBuiltin},
    {"char_polygon", geometricBuiltin},
    {"char_trapezoid", geometricBuiltin},
    {"char_sphere", geometricBuiltin},
    {"char_cylinder", geometricBuiltin},
    {"char_cone", geometricBuiltin},
    {"char_cube", geometricBuiltin},

    // Conditional

    {"isempty", conditionalBuiltin},
    {"is_empty", conditionalBuiltin},
    {"isnan", conditionalBuiltin},
    {"is_nan", conditionalBuiltin},

    // Logical
    {"eq", logicalBuiltin},
    {"ne", logicalBuiltin},
    {"lt", logicalBuiltin},
    {"gt", logicalBuiltin},
    {"le", logicalBuiltin},
    {"ge", logicalBuiltin},
    {"and", logicalBuiltin},
    {"or", logicalBuiltin},
    {"not", logicalBuiltin},
    {"bool", logicalBuiltin},
    {"is_true", logicalBuiltin},
    {"is_false", logicalBuiltin},
    {"is_zero", logicalBuiltin},
    {"is_positive", logicalBuiltin},
    {"is_negative", logicalBuiltin},

    // Vector
    // "dot" and "cross" moved to the NumPy Vector Math section in 2026-10
    // (Numpy/vector_math/vm_products.cpp): the new versions also take
    // matrices and a dim argument - dot(A, B, dim), cross(A, B, dim).
    {"unit_vector", vectorBuiltin},
    {"norm", vectorBuiltin},
    // "norm_vector" was registered in vector_builtin.cpp's own dispatch
    // table (an exact alias of "norm") but never routed here - unreachable
    // dead code, same pattern as "quotient" (arithmetic) and "matrix_pow"
    // (matrix) found the same way.
    {"norm_vector", vectorBuiltin},
    {"dircos", vectorBuiltin},
    {"angle", vectorBuiltin},
    {"proj", vectorBuiltin},
    {"proj_vec", vectorBuiltin},
    {"orthogonal", vectorBuiltin},
    {"orthonormal", vectorBuiltin},
    {"eigen_value", vectorBuiltin},
    {"eigen_vector", vectorBuiltin},
    // "divergence" and "curl" are in the ops registry (calculus/
    // calculus_fields.cpp): divergence(F) / curl(F) of a 3-vector as before,
    // plus the function and grid forms (the function forms used to be parser
    // calls, parser_factor.cpp).
    {"vector_tp", vectorBuiltin},
    // "vector_TP" removed 2026-09-16: it was dead/unreachable code -
    // callBuiltin's primary lookup lowercases the requested name before
    // checking this table, so any casing of "vector_TP" (which only
    // differs from "vector_tp" by letter case) already matched the
    // "vector_tp" entry above first; the exact-match fallback that would
    // have reached "vector_TP" specifically could never run. "vectortp"
    // below (was "vectorTP") is a genuinely different identifier (no
    // underscore) so it isn't shadowed the same way, just needed the
    // same lowercase fix "onlyrows"/"onlycols" got above, for the same
    // reason.
    {"vectortp", vectorBuiltin},
    // Plot
    {"plot", plotBuiltin},
    {"bar", barBuiltin},

    // Data Conversion / Space Generators
    {"int", dcBuiltin},
    {"int8", dcBuiltin},
    {"int16", dcBuiltin},
    {"int32", dcBuiltin},
    {"int64", dcBuiltin},
    {"int128", dcBuiltin},
    {"int256", dcBuiltin},
    {"uint8", dcBuiltin},
    {"uint16", dcBuiltin},
    {"uint32", dcBuiltin},
    {"uint64", dcBuiltin},
    {"uint128", dcBuiltin},
    {"uint256", dcBuiltin},
    {"float8", dcBuiltin},
    {"float16", dcBuiltin},
    {"float32", dcBuiltin},
    {"float64", dcBuiltin},
    {"float128", dcBuiltin},
    {"float256", dcBuiltin},
    {"string", dcBuiltin},
    {"float", dcBuiltin},
    {"str", dcBuiltin},
    {"round", dcBuiltin},
    {"rad2dec", dcBuiltin},
    {"dec2rad", dcBuiltin},
    {"space", dcBuiltin},
    {"nlspace", dcBuiltin},
    {"ndspace", dcBuiltin},
    {"dict", dcBuiltin},
    {"keys", dcBuiltin},
    {"values", dcBuiltin},
    // size() of any value (a dict's entry count, a matrix's [rows, cols]),
    // and the text / vector helpers - collections_builtin.h.
    {"size", collectionsBuiltin},
    {"numel", collectionsBuiltin},
    {"length", collectionsBuiltin},
    {"sort", collectionsBuiltin},
    {"append", collectionsBuiltin},
    {"remove", collectionsBuiltin},
    {"upper", collectionsBuiltin},
    {"lower", collectionsBuiltin},
    {"strcat", collectionsBuiltin},
    {"substr", collectionsBuiltin},
    {"contains", collectionsBuiltin},
    {"replace", collectionsBuiltin},
    {"split", collectionsBuiltin},
    {"precision", collectionsBuiltin},
    {"match_key", dcBuiltin},

    // Complex numbers
    {"complex", complexBuiltin},
    {"real", complexBuiltin},
    {"imag", complexBuiltin},
    {"conj", complexBuiltin},
    {"conjugate", complexBuiltin},
    {"is_complex", complexBuiltin},
    {"is_real", complexBuiltin},

    // Date and time (ops/time/) - timestamp / duration values
    {"get_timestamp", timeBuiltin},
    {"timestamp", timeBuiltin},
    {"to_timestamp", timeBuiltin},
    {"seconds", timeBuiltin},
    {"minutes", timeBuiltin},
    {"hours", timeBuiltin},
    {"days", timeBuiltin},
    {"today", timeBuiltin},
    {"get_time", timeBuiltin},
    {"get_date", timeBuiltin},
    {"set_time", timeBuiltin},
    {"set_date", timeBuiltin},
    {"format_time", timeBuiltin},
    {"in_seconds", timeBuiltin},
    {"in_minutes", timeBuiltin},
    {"in_hours", timeBuiltin},
    {"in_days", timeBuiltin},
    {"in_hms", timeBuiltin},
    {"in_hrs_min_sec", timeBuiltin},
    {"format_duration", timeBuiltin},
    {"tic", timeBuiltin},
    {"toc", timeBuiltin},
    {"date_range", timeBuiltin},
    {"is_busday", timeBuiltin},
    {"busday_count", timeBuiltin},
    {"busday_offset", timeBuiltin}};

/* ---- multicore settings (runtime/execution/parallel/par.h) ----

   set_threads(n)  how many threads NC's kernels (and matrix products) may
                   use from now on; n = 0 goes back to the default (every
                   logical processor, or NC_THREADS). Returns the previous
                   count. Results never depend on it - only speed does.
   get_threads()   the current count.
   thread_info()   a dict: threads, default_threads, logical_processors,
                   backend ("openmp", "stdpool" or "serial") and os.        */
static Value parallelBuiltin(const std::string &name, const std::vector<Value> &args) {
  auto fail = [&](const std::string &message) {
    std::cerr << "Error: " << message << "\n";
    g_lastBuiltinFound = false;
    return Value(0);
  };
  if (name == "set_threads") {
    if (args.size() != 1)
      return fail("set_threads(n) takes one argument, got " + std::to_string(args.size()));
    const Value &n = args[0];
    const bool number = !n.isText && !n.isArray && !n.isMatrix && !n.isDict && !n.isObject &&
                        !n.isFunctionRef && !n.isComplex && !n.isTime();
    if (!number || n.number != std::floor(n.number) || n.number < 0 || n.number > 1024)
      return fail("set_threads(n): n must be a whole number from 0 to 1024 (0 = the default)");
    return Value(static_cast<double>(nc::par::setThreadCount(static_cast<int>(n.number))));
  }
  if (!args.empty())
    return fail(name + "() takes no arguments");
  if (name == "get_threads")
    return Value(static_cast<double>(nc::par::threadCount()));
  std::unordered_map<std::string, Value> info;
  info["threads"] = Value(static_cast<double>(nc::par::threadCount()));
  info["default_threads"] = Value(static_cast<double>(nc::par::defaultThreadCount()));
  info["logical_processors"] = Value(static_cast<double>(nc::par::logicalProcessors()));
  info["backend"] = Value(std::string(nc::par::backendName()));
  info["os"] = Value(std::string(nc::par::sys::osName()));
  info["build"] = Value(std::string(nc::par::buildType()));
  return Value(info);
}

bool isBuiltinConstant(const std::string & /*name*/) { return false; }

// Whether callBuiltin() knows `name` - for @sqrt, a reference to a built-in
// function (the parser's FunctionRef case). Same order as callBuiltin().
bool builtinExists(const std::string &name) {
  const std::string key = normalizeIdentifier(name);
  if (builtinTable.count(key) || builtinTable.count(name) || nc::ops::isOpsFunction(name))
    return true;
  nc::numpy::initialize();
  if (nc::numpy::Registry::instance().find(name))
    return true;
  if (nc::scipy::isScipyFunction(name))
    return true;
  if (key.rfind("logb", 0) == 0 && key.size() > 4)
    return std::all_of(key.begin() + 4, key.end(),
                       [](unsigned char c) { return std::isdigit(c) != 0; });
  return false;
}

/* ---- vectors written as matrices ----
   Since 2026-10 `[1,2,3]` is a 1x3 matrix and `[1;2;3]` a 3x1 matrix. The
   function families below were written for 1-D arrays, so a row or column
   vector is handed to them as the 1-D array of its elements, and a 1-D
   array they return is turned back into a vector of the same orientation as
   the first vector argument (a row unless that was a column). Matrices of
   any other shape pass through unchanged. */
namespace {

bool takesVectorsAsArrays(BuiltinHandler h, const std::string &key) {
  return h == statisticsBuiltin || h == vectorBuiltin || h == plotBuiltin || h == barBuiltin ||
         h == geometricBuiltin || (h == dcBuiltin && key == "dict");
}

// Returns the adapted argument list; `column` says whether the first vector
// argument was a column, `converted` whether any argument changed.
std::vector<Value> vectorsAsArrays(const std::vector<Value> &args, bool &converted, bool &column) {
  converted = false;
  column = false;
  std::vector<Value> out;
  out.reserve(args.size());
  for (const Value &a : args) {
    if (matIsVectorShape(a)) {
      if (!converted)
        column = a.rows() > 1;
      converted = true;
      out.push_back(matVectorAsArray(a));
    } else {
      out.push_back(a);
    }
  }
  return out;
}

Value arrayBackToVector(const Value &result, bool column) {
  if (!result.isArray || result.length() == 0)
    return result;
  // An array of arrays (e.g. onlyrows()) is not a vector - leave it.
  for (size_t i = 0; i < result.length(); i++) {
    const Value e = result.at(i);
    if (e.isArray || e.isMatrix || e.isDict || e.isObject)
      return result;
  }
  return matArrayAsMatrix(result, column);
}

} // namespace

/* ---- inputs by name for the core builtins ----

   The core (ops/) builtins that take options get a parameter line here, in
   the same form as the NumPy tables (core/param_list.h). `keywordOnly` lists
   inputs that can ONLY be given by name: they change how the function works
   instead of being one more value - max(A, B) pairs A and B element by
   element, so max's axis can never be the second plain value.
   Add a row here to let a core builtin take named values. */
namespace {

struct CoreParams {
  const char *name;        // lowercase, as in builtinTable
  const char *line;        // the plain-or-named inputs, in order
  const char *keywordOnly; // inputs that must be named ("" = none)
};

const CoreParams kCoreParams[] = {
    {"max", "A, B?", "axis?"}, // max(A, axis=0): one value per column (R3)
    {"min", "A, B?", "axis?"},
    {"round", "x, decimals=0", ""},
    {"angle", "z, B?", "deg=false"},
    {"matrix_norm", "A, ord?", ""},
    {"exp", "x", ""},
    {"trace", "A", ""},
    {"pinv", "A", ""},
    {"pseudo_inverse", "A", ""},
    {"conj", "z", ""},
    {"conjugate", "z", ""},
    {"real", "z", ""},
    // Business days and date ranges (ops/time/time_calendar.cpp): the
    // options can be named - is_busday(t, zone="UTC", holidays=H).
    {"is_busday", "t, weekmask=\"1111100\", zone=\"\", holidays?", ""},
    {"busday_count", "begin, end, weekmask=\"1111100\", zone=\"\", holidays?", ""},
    {"busday_offset", "t, n, roll=\"raise\", weekmask=\"1111100\", zone=\"\", holidays?", ""},
    {"date_range", "start, stop, step?", ""},
};

const CoreParams *coreParamsOf(const std::string &key) {
  for (const CoreParams &c : kCoreParams)
    if (key == c.name)
      return &c;
  return nullptr;
}

// Parsed once; a malformed row is a programming error, reported once.
struct ParsedCore {
  std::vector<ncargs::ParamSpec> params, keywordOnly;
  bool ok = false;
};

const ParsedCore &parsedCore(const CoreParams &c) {
  static std::unordered_map<std::string, ParsedCore> cache;
  auto it = cache.find(c.name);
  if (it != cache.end())
    return it->second;
  ParsedCore p;
  std::string err;
  p.ok = ncargs::parseParamList(c.line, p.params, err) &&
         ncargs::parseParamList(c.keywordOnly, p.keywordOnly, err);
  if (!p.ok)
    std::cerr << "builtins: parameter line of '" << c.name << "': " << err << "\n";
  return cache.emplace(c.name, std::move(p)).first->second;
}

std::string coreSignature(const CoreParams &c) {
  const ParsedCore &p = parsedCore(c);
  std::string sig = ncargs::paramSignature(c.name, p.params);
  // Keyword-only inputs: "max(A[, B][, axis=])" - given by name only.
  for (const auto &k : p.keywordOnly) {
    if (k.kind == ncargs::ParamKind::Defaulted)
      sig.insert(sig.size() - 1, ", " + k.name + "=" + k.defaultText);
    else
      sig.insert(sig.size() - 1, "[, " + k.name + "=]");
  }
  return sig;
}

} // namespace

// Used by the Numpy registry (Numpy/numpy_registry.cpp) to skip any NumPy
// entry whose name an existing ops/ builtin already owns. Same matching as
// callBuiltin(): normalized (lowercase, no spaces) first, then exact.
bool isCoreBuiltinName(const std::string &name) {
  return builtinTable.count(normalizeIdentifier(name)) > 0 || builtinTable.count(name) > 0 ||
         nc::ops::ownsName(name);
}

static Value callBuiltinImpl(const std::string &name, const std::vector<Value> &args);

// Every builtin call. With the IDE's Analysis box on, it also counts the
// call's computations and marks it as "running now" for the time profile
// (runtime/execution/analysis/analysis.h); off, that is one bool test.
Value callBuiltin(const std::string &name, const std::vector<Value> &args) {
  if (!nc::analysis::active())
    return callBuiltinImpl(name, args);
  nc::analysis::OpScope op(name);
  Value result = callBuiltinImpl(name, args);
  op.computations(nc::analysis::builtinCost(name, args, result));
  return result;
}

static Value callBuiltinImpl(const std::string &name, const std::vector<Value> &args) {
  // Builtins run on the interpreter thread only - never from inside an
  // nc::par block (Debug builds stop here if one tries).
  nc::par::assertInterpreterThread("callBuiltin");
  // The CPU monitor shows a kernel without a label of its own under this
  // name. One thread-local pointer store; `name` outlives the call.
  const nc::par::CallLabel callLabel(name.c_str());
  g_lastBuiltinFound = true;

  std::string key = name;
  // Normalize for lookup consistency.
  key = normalizeIdentifier(key);

  // builtinTable keys are currently a mix of cases; to keep behavior stable,
  // we try both raw and normalized forms.
  auto it = builtinTable.find(key);
  if (it == builtinTable.end()) {
    // Fallback: original name.
    it = builtinTable.find(name);
  }

  // Timestamps and durations (ops/time/). Every function that is not a
  // time function would read their `number` (NaN) - only shape functions
  // (size, numel, ...) take them as they are, abs() and str() have a time
  // meaning, and anything else refuses them with an error. Covers the
  // NumPy and SciPy functions too, which are looked up further down.
  if (!nctime::isTimeFunction(key)) {
    bool anyTime = false;
    for (const Value &arg : args)
      anyTime = anyTime || nctime::containsTime(arg);
    if (anyTime) {
      Value timeResult;
      switch (nctime::timeArgsCall(key, args, timeResult)) {
      case nctime::TimeArgs::Done:
        return timeResult;
      case nctime::TimeArgs::Refused:
        g_lastBuiltinFound = false;
        return Value(0);
      case nctime::TimeArgs::PassThrough:
        break;
      }
    }
  }

  // The engineering-mathematics functions (ops/support/ops_registry.h) -
  // asked before builtinTable, since the calculus names live there now.
  // Same error contract as the NumPy/SciPy steps below.
  {
    Value opsResult;
    bool opsOk = true;
    if (nc::ops::tryCall(name, args, opsResult, opsOk)) {
      g_lastBuiltinFound = opsOk;
      return opsResult;
    }
  }

  // Complex arguments. Most builtins read only a value's real part, so
  // handing them a complex number would return a wrong answer with no
  // warning - refuse instead, unless the builtin is known to handle it.
  bool anyComplex = false;
  for (const Value &arg : args)
    anyComplex = anyComplex || arg.hasComplex();
  auto rejectComplex = [&]() {
    std::cerr << "Error: '" << name << "' does not support complex numbers yet\n";
    g_lastBuiltinFound = false;
    return Value(0);
  };

  if (it != builtinTable.end()) {
    // A core builtin with a parameter line (kCoreParams): inputs left out at
    // the end take their defaults - round(X) is round(X, 0). Calls that do
    // not fit the line are left to the builtin, which reports them as before.
    if (const CoreParams *cp = coreParamsOf(key)) {
      const ParsedCore &pc = parsedCore(*cp);
      std::vector<Value> filled;
      std::string why;
      if (pc.ok && ncargs::normalizeCall(pc.params, args, {}, filled, why) &&
          filled.size() != args.size())
        return callBuiltinImpl(name, filled);
    }

    if (anyComplex && !builtinAcceptsComplex(key))
      return rejectComplex();

    // abs() of a complex value, and angle() with ONE argument (the phase
    // of a number - the two-argument angle() between vectors is
    // untouched), belong to the complex module.
    if ((key == "abs" && anyComplex) || (key == "angle" && args.size() == 1))
      return complexBuiltin(key, args);

    // sum(A), mean(A), count(A) ... of a whole matrix work over every
    // element, the way max(A) and min(A) already did; they used to reject
    // any matrix that was not one row or one column.
    static const std::unordered_map<std::string, bool> kWholeMatrixReductions = {
        {"sum", true},   {"count", true},  {"mean", true},     {"median", true},
        {"mode", true},  {"range", true},  {"var", true},      {"pvar", true},
        {"sd", true},    {"psd", true},    {"geo_mean", true}, {"harmo_mean", true},
        {"skew", true},  {"kurtosis", true}, {"std_error", true}, {"cv", true},
        {"coeff_var", true}, {"q1", true}, {"q2", true},       {"q3", true},
        {"iqr", true}};
    // A packed row or column vector takes the same direct route as a packed
    // matrix: each of these reads a matrix as its elements in row order,
    // which for a vector is its element order, so the answer is the one the
    // array conversion below gives - without copying 4 million elements
    // first. Not mode(): its list of modes comes back as a vector of the
    // input's orientation through the conversion, and must keep doing so.
    if (it->second == statisticsBuiltin && args.size() == 1 && args[0].isMatrix &&
        !args[0].isND() && args[0].rows() > 0 && args[0].isPacked() &&
        matIsVectorShape(args[0]) && key != "mode" && kWholeMatrixReductions.count(key))
      return it->second(name, args);
    if (it->second == statisticsBuiltin && args.size() == 1 && args[0].isMatrix &&
        !args[0].isND() && args[0].rows() > 0 && !matIsVectorShape(args[0]) &&
        kWholeMatrixReductions.count(key)) {
      // Packed (all-numeric) matrix: every one of these reads a matrix as
      // its elements row by row already (statistics.cpp, toVec), straight
      // from the buffer - no need to copy each element into a Value first,
      // which used to take ~100x the time of the sum itself.
      if (args[0].isPacked())
        return it->second(name, args);
      std::vector<Value> all;
      for (size_t r = 0; r < args[0].rows(); r++)
        for (size_t c = 0; c < args[0].rowLength(r); c++)
          all.push_back(args[0].at(r, c));
      return it->second(name, {Value(std::move(all))});
    }

    if (takesVectorsAsArrays(it->second, key)) {
      bool converted = false, column = false;
      std::vector<Value> adapted = vectorsAsArrays(args, converted, column);
      if (converted) {
        Value result = it->second(name, adapted);
        return it->second == dcBuiltin ? result : arrayBackToVector(result, column);
      }
    }

    // complexBuiltin's own table is keyed by the lowercased name.
    return it->second(it->second == complexBuiltin ? key : name, args);
  }

  // NumPy-equivalent functions (runtime/interpreter/Numpy/). Reached only
  // when builtinTable has no entry for this name. A NumPy error is reported
  // the same way as rejectComplex() above - g_lastBuiltinFound = false - so
  // both the tree-walker (evaluateExpr) and the JIT (nc_bridge_call_dynamic)
  // stop the statement with no further changes in either.
  {
    Value numpyResult;
    bool numpyOk = true;
    if (nc::numpy::tryCall(name, args, numpyResult, numpyOk)) {
      g_lastBuiltinFound = numpyOk;
      return numpyResult;
    }
  }

  // SciPy-equivalent functions (runtime/interpreter/Scipy/) - same contract
  // as the NumPy step above, reached only when neither builtinTable nor
  // NumPy knows the name.
  {
    Value scipyResult;
    bool scipyOk = true;
    if (nc::scipy::tryCall(name, args, scipyResult, scipyOk)) {
      g_lastBuiltinFound = scipyOk;
      return scipyResult;
    }
  }

  // Dynamic "logbN" family: logb2(x), logb6(x), logb10(x), ... — any
  // "logb" followed by a run of digits is treated as log base N of a
  // single argument. This is the ONLY log-base entry point exposed to NC
  // scripts — there is no separate "log_base(base, val)" or dedicated
  // "logb2" keyword; both were removed in favor of this single baked-
  // into-the-name form. log_base() (arithmetic.cpp) still exists as a
  // plain C++ helper, called only from here, not registered as its own
  // callable name.
  if (key.rfind("logb", 0) == 0 && key.size() > 4) {
    std::string baseDigits = key.substr(4);
    bool allDigits = !baseDigits.empty();
    for (char c : baseDigits) {
      if (!std::isdigit(static_cast<unsigned char>(c))) {
        allDigits = false;
        break;
      }
    }

    if (allDigits) {
      if (args.size() != 1) {
        std::cerr << "Error: Function '" << name << "' expects 1 arg, got "
                  << args.size() << "\n";
        return Value();
      }
      // log_base() itself already gives the IEEE-754-correct numeric
      // result for base<=0/base==1/val<=0 (see arithmetic.cpp) - no
      // separate guard needed here.
      double base = std::stod(baseDigits);
      return log_base(Value(base), args[0]);
    }
  }

  g_lastBuiltinFound = false;
  std::cerr << "Error: Unknown function '" << name << "'\n";
  return Value(0);
}

bool callBuiltinMulti(const std::string &name, const std::vector<Value> &args, size_t nout,
                      std::vector<Value> &out, bool &ok, const std::vector<std::string> &argNames) {
  g_lastBuiltinFound = true;
  return nc::numpy::tryCallMulti(name, args, nout, out, ok, argNames);
}

/* ---- calls that name their values ---- */

namespace {

// The extra work a keyword-only input asks for, after the builtin has run
// with its plain inputs. Returns false (error printed) when it cannot.
bool applyKeywordOnly(const std::string &key, const std::string &name,
                      const std::vector<ncargs::ParamSpec> &keywordOnly,
                      const std::vector<Value> &kwValues, Value &result) {
  for (size_t i = 0; i < keywordOnly.size(); i++) {
    const std::string &kw = keywordOnly[i].name;
    const Value &v = kwValues[i];
    if (key == "angle" && kw == "deg") {
      if (!v.isBool()) {
        std::cerr << "Error: " << name << ": deg must be true or false\n";
        return false;
      }
      if (v.number != 0.0) { // radians -> degrees, element by element
        const double k = 180.0 / 3.14159265358979323846;
        result = mapElementwise(result, [k](double x) { return x * k; });
      }
    }
  }
  return true;
}

} // namespace

std::string builtinSignature(const std::string &name) {
  const std::string key = normalizeIdentifier(name);
  if (nc::ops::ownsName(name))
    return nc::ops::usageOf(name);
  if (builtinTable.count(key) || builtinTable.count(name)) {
    const CoreParams *cp = coreParamsOf(key);
    return cp ? coreSignature(*cp) : std::string();
  }
  nc::numpy::initialize();
  const nc::numpy::FunctionSpec *spec = nc::numpy::Registry::instance().find(name);
  return (spec && !spec->params.empty()) ? spec->signature : std::string();
}

Value callBuiltinNamed(const std::string &name, const std::vector<Value> &args,
                       const std::vector<std::string> &argNames) {
  if (argNames.empty())
    return callBuiltin(name, args);
  g_lastBuiltinFound = true;
  const std::string key = normalizeIdentifier(name);

  // 0. The engineering-mathematics functions (ops registry) take their
  //    values in order.
  if (nc::ops::isOpsFunction(name)) {
    std::cerr << "Error: " << name << ": its values cannot be named yet - give them in order\n";
    g_lastBuiltinFound = false;
    return Value(0);
  }

  // 1. A core (ops/) builtin: only those with a kCoreParams row.
  if (builtinTable.count(key) || builtinTable.count(name)) {
    const CoreParams *cp = coreParamsOf(key);
    if (!cp || !parsedCore(*cp).ok) {
      std::cerr << "Error: " << name
                << ": its values cannot be named yet - give them in order\n";
      g_lastBuiltinFound = false;
      return Value(0);
    }
    const ParsedCore &pc = parsedCore(*cp);
    // Keyword-only inputs are taken out first; the rest are matched to the
    // parameter line like any call.
    std::vector<Value> rest, kwValues;
    std::vector<std::string> restNames;
    std::vector<bool> kwGiven(pc.keywordOnly.size(), false);
    for (const auto &k : pc.keywordOnly)
      kwValues.push_back(k.defaultValue);
    for (size_t i = 0; i < args.size(); i++) {
      bool isKw = false;
      for (size_t k = 0; k < pc.keywordOnly.size(); k++) {
        if (argNames[i] == pc.keywordOnly[k].name) {
          if (kwGiven[k]) {
            std::cerr << "Error: " << name << ": input '" << argNames[i]
                      << "' is given more than once (usage: " << coreSignature(*cp) << ")\n";
            g_lastBuiltinFound = false;
            return Value(0);
          }
          kwGiven[k] = true;
          kwValues[k] = args[i];
          isKw = true;
        }
      }
      if (!isKw) {
        rest.push_back(args[i]);
        restNames.push_back(argNames[i]);
      }
    }
    std::vector<Value> prepared;
    std::string why;
    bool anyNamed = false;
    for (const auto &n : restNames)
      anyNamed = anyNamed || !n.empty();
    if (!ncargs::normalizeCall(pc.params, rest, anyNamed ? restNames : std::vector<std::string>{},
                               prepared, why)) {
      std::cerr << "Error: " << name << ": " << why << " (usage: " << coreSignature(*cp)
                << ")\n";
      g_lastBuiltinFound = false;
      return Value(0);
    }
    // max(A, axis=k) / min(A, axis=k): a reduction along one axis
    // (statistics.cpp ExtremeOf) instead of the builtin's own call.
    if ((key == "max" || key == "min") && kwGiven[0]) {
      if (prepared.size() > 1) {
        std::cerr << "Error: " << name << ": axis works with one value - " << key
                  << "(A, axis=0) - not with " << key << "(A, B)\n";
        g_lastBuiltinFound = false;
        return Value(0);
      }
      const Value &ax = kwValues[0];
      if (ax.isText || ax.isArray || ax.isMatrix || ax.isDict || ax.isObject || ax.isComplex ||
          !std::isfinite(ax.number) || ax.number != std::floor(ax.number)) {
        std::cerr << "Error: " << name << ": axis must be a whole number (0, 1, ..., or -1 for "
                  << "the last axis)\n";
        g_lastBuiltinFound = false;
        return Value(0);
      }
      g_lastStatsOk = true;
      Value r = ExtremeOf(prepared[0], key == "max", true, static_cast<long long>(ax.number));
      g_lastBuiltinFound = g_lastStatsOk;
      return r;
    }

    Value result = callBuiltin(name, prepared);
    if (!g_lastBuiltinFound)
      return result;
    if (!applyKeywordOnly(key, name, pc.keywordOnly, kwValues, result)) {
      g_lastBuiltinFound = false;
      return Value(0);
    }
    return result;
  }

  // 2. A NumPy function (its section's parameter line decides).
  {
    Value out;
    bool ok = true;
    if (nc::numpy::tryCall(name, args, out, ok, argNames)) {
      g_lastBuiltinFound = ok;
      return out;
    }
  }

  // 3. SciPy functions take their values in order (no parameter lines yet).
  if (nc::scipy::isScipyFunction(name)) {
    std::cerr << "Error: " << name << ": its values cannot be named yet - give them in order\n";
    g_lastBuiltinFound = false;
    return Value(0);
  }

  g_lastBuiltinFound = false;
  std::cerr << "Error: Unknown function '" << name << "'\n";
  return Value(0);
}
