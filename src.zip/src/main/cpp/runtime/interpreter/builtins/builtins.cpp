#include "builtins.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <unordered_map>

#include "../ops/arithmetic/arithmetic_builtin.h"
#include "../ops/calculus/calculus_builtin.h"
#include "../../compiler/compiler_src/conditional_opr/conditional_builtin.h"
#include "../../compiler/compiler_src/conditional_opr/logical_builtin.h"
#include "../ops/dc/dc_builtin.h"
#include "../ops/geometric/geometric_builtin.h"
#include "../ops/matrix/matrix_builtin.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics_builtin.h"
#include "../ops/trigonometric/trigonometric_builtin.h"
#include "../ops/vector/vector_builtin.h"

bool g_lastBuiltinFound = true;

using BuiltinHandler = Value (*)(const std::string &,
                                 const std::vector<Value> &);

static std::string normalizeIdentifier(std::string s) {
  // Requirement: builtins (functions) are not the constants system.
  // However, to avoid case/whitespace surprises for identifiers,
  // we normalize similarly.
  s.erase(std::remove_if(s.begin(), s.end(), ::isspace), s.end());
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return std::tolower(c); });
  return s;
}

static const std::unordered_map<std::string, BuiltinHandler> builtinTable = {

    // Statistics
    {"mean", statisticsBuiltin},
    {"median", statisticsBuiltin},
    {"mode", statisticsBuiltin},
    {"geo_mean", statisticsBuiltin},
    {"harmo_mean", statisticsBuiltin},
    {"trim_mean", statisticsBuiltin},
    {"var", statisticsBuiltin},
    {"PVAR", statisticsBuiltin},
    {"sd", statisticsBuiltin},
    {"PSD", statisticsBuiltin},
    {"coeff_var", statisticsBuiltin},
    {"CV", statisticsBuiltin},
    {"skew", statisticsBuiltin},
    {"Kurtosis", statisticsBuiltin},
    {"Std_Error", statisticsBuiltin},
    {"corr_coeff", statisticsBuiltin},
    {"co_var", statisticsBuiltin},
    {"lsm", statisticsBuiltin},
    {"null_hypo", statisticsBuiltin},
    {"p_val_cal", statisticsBuiltin},
    {"chi_test", statisticsBuiltin},
    {"Q1", statisticsBuiltin},
    {"Q2", statisticsBuiltin},
    {"Q3", statisticsBuiltin},
    {"IQR", statisticsBuiltin},
    {"Range", statisticsBuiltin},
    {"Sum", statisticsBuiltin},
    {"Count", statisticsBuiltin},
    {"Min", statisticsBuiltin},
    {"Max", statisticsBuiltin},
    {"Percentile", statisticsBuiltin},
    {"ZScore", statisticsBuiltin},
    {"LNorm", statisticsBuiltin},
    {"Lnorm", statisticsBuiltin},
    {"lnorm", statisticsBuiltin},

    // Arithmetic
    {"sqrt", arithmeticBuiltin},
    {"cbrt", arithmeticBuiltin},
    {"log", arithmeticBuiltin},
    {"log_base", arithmeticBuiltin},
    {"sqr", arithmeticBuiltin},
    {"cube", arithmeticBuiltin},
    {"exp", arithmeticBuiltin},
    {"dec2frac", arithmeticBuiltin},
    {"frac2dec", arithmeticBuiltin},
    {"logb2", arithmeticBuiltin},
    {"abs", arithmeticBuiltin},
    {"frac2deci", arithmeticBuiltin},
    {"deci2frac", arithmeticBuiltin},

    // Matrix
    {"rank", matrixBuiltin},
    {"det", matrixBuiltin},
    {"transpose", matrixBuiltin},
    {"Norm", matrixBuiltin},
    {"conjugate", matrixBuiltin},
    {"pseudo_inverse", matrixBuiltin},
    {"adj", matrixBuiltin},
    {"had_prod", matrixBuiltin},
    {"inv", matrixBuiltin},
    {"ElementWise", matrixBuiltin},
    {"diag", matrixBuiltin},
    {"upper_triangular", matrixBuiltin},
    {"Lower_Triangular", matrixBuiltin},
    {"zero_matrix", matrixBuiltin},
    {"full_rank_matrix", matrixBuiltin},
    {"singular_matrix", matrixBuiltin},
    {"pd_matrix", matrixBuiltin},
    {"nd_matrix", matrixBuiltin},
    {"unit_matrix", matrixBuiltin},
    {"Trace", matrixBuiltin},
    {"onlyRows", matrixBuiltin},
    {"onlyCols", matrixBuiltin},
    {"Rows", matrixBuiltin},
    {"Cols", matrixBuiltin},

    // Calculus
    {"ddt", calculusBuiltin},
    {"pddt", calculusBuiltin},
    {"continuity", calculusBuiltin},
    {"grad", calculusBuiltin},
    // NOTE: "Curl" intentionally left capitalized — lowercasing it here
    // would collide with the pre-existing "curl" key already registered
    // below by the Vector category, silently dropping one working route.
    // See rename report.
    {"Curl", calculusBuiltin},
    {"laplace", calculusBuiltin},
    {"green_integral", calculusBuiltin},
    {"stokes_integral", calculusBuiltin},
    {"taylor_series", calculusBuiltin},
    {"rad_of_con", calculusBuiltin},
    {"Div", calculusBuiltin},

    // Trigonometric
    {"sin", trigonometricBuiltin},
    {"cos", trigonometricBuiltin},
    {"tan", trigonometricBuiltin},
    {"cosec", trigonometricBuiltin},
    {"sec", trigonometricBuiltin},
    {"cot", trigonometricBuiltin},
    {"inv_sin", trigonometricBuiltin},
    {"inv_cos", trigonometricBuiltin},
    {"inv_tan", trigonometricBuiltin},
    {"inv_cosec", trigonometricBuiltin},
    {"inv_sec", trigonometricBuiltin},
    {"inv_cot", trigonometricBuiltin},
    {"sinh", trigonometricBuiltin},
    {"cosh", trigonometricBuiltin},
    {"tanh", trigonometricBuiltin},
    {"cosech", trigonometricBuiltin},
    {"sech", trigonometricBuiltin},
    {"coth", trigonometricBuiltin},
    {"sin_deg", trigonometricBuiltin},
    {"cos_deg", trigonometricBuiltin},
    {"tan_deg", trigonometricBuiltin},
    {"cosec_deg", trigonometricBuiltin},
    {"sec_deg", trigonometricBuiltin},
    {"cot_deg", trigonometricBuiltin},

    // Geometry
    {"char_circle", geometricBuiltin},
    {"char_square", geometricBuiltin},
    {"char_triangle", geometricBuiltin},
    {"char_rectangle", geometricBuiltin},
    {"char_ellipse", geometricBuiltin},
    {"char_pentagon", geometricBuiltin},
    {"char_hexagon", geometricBuiltin},
    {"char_heptagon", geometricBuiltin},
    {"char_nonagon", geometricBuiltin},
    {"char_semicircle", geometricBuiltin},
    {"char_rhombus", geometricBuiltin},
    {"char_rtriangle", geometricBuiltin},
    {"char_polygon", geometricBuiltin},
    {"char_trapezoid", geometricBuiltin},
    {"char_sphere", geometricBuiltin},
    {"char_cylinder", geometricBuiltin},
    {"char_cone", geometricBuiltin},
    {"char_cube", geometricBuiltin},

    // Conditional

    {"Isempty", conditionalBuiltin},
    {"isempty", conditionalBuiltin},
    {"is_empty", conditionalBuiltin},
    {"Isnan", conditionalBuiltin},
    {"isnan", conditionalBuiltin},
    {"is_nan", conditionalBuiltin},

    // Logical
    {"eq", logicalBuiltin},
    {"ne", logicalBuiltin},
    {"lt", logicalBuiltin},
    {"gt", logicalBuiltin},
    {"le", logicalBuiltin},
    {"ge", logicalBuiltin},
    {"and", logicalBuiltin},
    {"or", logicalBuiltin},
    {"not", logicalBuiltin},
    {"bool", logicalBuiltin},
    {"is_true", logicalBuiltin},
    {"is_false", logicalBuiltin},
    {"is_zero", logicalBuiltin},
    {"is_positive", logicalBuiltin},
    {"is_negative", logicalBuiltin},

    // Vector
    {"Dot", vectorBuiltin},
    {"VectorCross", vectorBuiltin},
    {"Cross", vectorBuiltin},
    {"unit_vector", vectorBuiltin},
    {"norm", vectorBuiltin},
    {"dircos", vectorBuiltin},
    {"Angle", vectorBuiltin},
    {"angle", vectorBuiltin},
    {"Projection", vectorBuiltin},
    {"ProjectionVec", vectorBuiltin},
    {"proj", vectorBuiltin},
    {"proj_vec", vectorBuiltin},
    {"orthogonal", vectorBuiltin},
    {"orthonormal", vectorBuiltin},
    {"eigen_value", vectorBuiltin},
    {"eigen_vector", vectorBuiltin},
    {"divergence", vectorBuiltin},
    {"curl", vectorBuiltin},
    {"vector_tp", vectorBuiltin},
    {"vector_TP", vectorBuiltin},
    {"VectorTP", vectorBuiltin},
    {"vectorTP", vectorBuiltin},
    // Plot
    {"plot", plotBuiltin},
    {"bar", barBuiltin},

    // Data Conversion / Space Generators
    {"int", dcBuiltin},
    {"float", dcBuiltin},
    {"str", dcBuiltin},
    {"round", dcBuiltin},
    {"rad2dec", dcBuiltin},
    {"dec2rad", dcBuiltin},
    {"space", dcBuiltin},
    {"nlspace", dcBuiltin},
    {"ndspace", dcBuiltin},
    {"dict", dcBuiltin},
    {"keys", dcBuiltin},
    {"values", dcBuiltin},
    {"size", dcBuiltin},
    {"match_key", dcBuiltin}};

bool isBuiltinConstant(const std::string & /*name*/) { return false; }

Value callBuiltin(const std::string &name, const std::vector<Value> &args) {
  g_lastBuiltinFound = true;

  std::string key = name;
  // Normalize for lookup consistency.
  key = normalizeIdentifier(key);

  // builtinTable keys are currently a mix of cases; to keep behavior stable,
  // we try both raw and normalized forms.
  auto it = builtinTable.find(key);
  if (it == builtinTable.end()) {
    // Fallback: original name.
    it = builtinTable.find(name);
  }

  if (it != builtinTable.end())
    return it->second(name, args);

  g_lastBuiltinFound = false;
  std::cerr << "Error: Unknown function '" << name << "'\n";
  return Value(0);
}
