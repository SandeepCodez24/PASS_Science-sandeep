#include "builtins.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <unordered_map>

#include "../ops/arithmetic/arithmetic.h"
#include "../ops/arithmetic/arithmetic_builtin.h"
#include "../ops/calculus/calculus_builtin.h"
#include "../ops/complex/complex_builtin.h"
#include "../../compiler/compiler_src/conditional_opr/conditional_builtin.h"
#include "../../compiler/compiler_src/conditional_opr/logical_builtin.h"
#include "../ops/dc/dc_builtin.h"
#include "../ops/geometric/geometric_builtin.h"
#include "../ops/matrix/matrix_builtin.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics_builtin.h"
#include "../ops/trigonometric/trigonometric_builtin.h"
#include "../ops/vector/vector_builtin.h"

bool g_lastBuiltinFound = true;

using BuiltinHandler = Value (*)(const std::string &,
                                 const std::vector<Value> &);

static std::string normalizeIdentifier(std::string s) {
  // Requirement: builtins (functions) are not the constants system.
  // However, to avoid case/whitespace surprises for identifiers,
  // we normalize similarly.
  s.erase(std::remove_if(s.begin(), s.end(), ::isspace), s.end());
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return std::tolower(c); });
  return s;
}

static const std::unordered_map<std::string, BuiltinHandler> builtinTable = {

    // Statistics
    {"mean", statisticsBuiltin},
    {"median", statisticsBuiltin},
    {"mode", statisticsBuiltin},
    {"geo_mean", statisticsBuiltin},
    {"harmo_mean", statisticsBuiltin},
    {"trim_mean", statisticsBuiltin},
    {"var", statisticsBuiltin},
    {"pvar", statisticsBuiltin},
    {"sd", statisticsBuiltin},
    {"psd", statisticsBuiltin},
    {"coeff_var", statisticsBuiltin},
    {"cv", statisticsBuiltin},
    {"skew", statisticsBuiltin},
    {"kurtosis", statisticsBuiltin},
    {"std_error", statisticsBuiltin},
    {"corr_coeff", statisticsBuiltin},
    {"co_var", statisticsBuiltin},
    {"lsm", statisticsBuiltin},
    {"null_hypo", statisticsBuiltin},
    {"p_val_cal", statisticsBuiltin},
    {"chi_test", statisticsBuiltin},
    // Q1/Q2/Q3/IQR intentionally kept capitalized — exception to the
    // lowercase-only convention for the rest of this table, per explicit
    // request (these are conventional statistics notation).
    {"Q1", statisticsBuiltin},
    {"Q2", statisticsBuiltin},
    {"Q3", statisticsBuiltin},
    {"IQR", statisticsBuiltin},
    {"range", statisticsBuiltin},
    {"sum", statisticsBuiltin},
    {"count", statisticsBuiltin},
    {"min", statisticsBuiltin},
    {"max", statisticsBuiltin},
    {"percentile", statisticsBuiltin},
    {"z_score", statisticsBuiltin},
    {"lnorm", statisticsBuiltin},
    // Orphaned before this fix: fully implemented but never registered
    // here or in the inner statistics_builtin.cpp dispatch table (same
    // pattern as quotient/matrix_pow/norm_vector found earlier this pass).
    {"l2norm", statisticsBuiltin},

    // Arithmetic
    {"sqrt", arithmeticBuiltin},
    {"cbrt", arithmeticBuiltin},
    {"log", arithmeticBuiltin},
    {"sqr", arithmeticBuiltin},
    {"cube", arithmeticBuiltin},
    {"exp", arithmeticBuiltin},
    {"dec2frac", arithmeticBuiltin},
    {"abs", arithmeticBuiltin},
    {"frac2deci", arithmeticBuiltin},
    {"deci2frac", arithmeticBuiltin},
    {"quotient", arithmeticBuiltin},

    // Matrix
    {"rank", matrixBuiltin},
    {"det", matrixBuiltin},
    {"transpose", matrixBuiltin},
    // "matrix_norm" (not "norm" — that name is already owned by the Vector
    // category's lowercase "norm" below; giving the matrix norm a distinct
    // name avoids the two colliding in this same table).
    {"matrix_norm", matrixBuiltin},
    {"conjugate", matrixBuiltin},
    {"pseudo_inverse", matrixBuiltin},
    {"adj", matrixBuiltin},
    {"had_prod", matrixBuiltin},
    {"inv", matrixBuiltin},
    {"element_wise", matrixBuiltin},
    {"diag", matrixBuiltin},
    {"upper_triangular", matrixBuiltin},
    {"lower_triangular", matrixBuiltin},
    {"zero_matrix", matrixBuiltin},
    {"full_rank_matrix", matrixBuiltin},
    {"singular_matrix", matrixBuiltin},
    {"pd_matrix", matrixBuiltin},
    {"nd_matrix", matrixBuiltin},
    {"unit_matrix", matrixBuiltin},
    {"trace", matrixBuiltin},
    // "onlyrows"/"onlycols" are exact duplicates of the old "Rows"/"Cols"
    // (same underlying OnlyRows/OnlyCols functions) — no separate
    // "rows"/"cols" needed. Registered lowercase (fixed 2026-09-16, was
    // "onlyRows"/"onlyCols"): callBuiltin's primary lookup always
    // lowercases the requested name before checking this table, so a
    // mixed-case-only key here was only ever reachable if a caller typed
    // that exact casing verbatim - "onlyrows"/"ONLYROWS"/etc. all failed
    // with "Unknown function", breaking the case-insensitive dispatch
    // documented for every other builtin. The inner dispatch table in
    // matrix_builtin.cpp does its own exact-string lookup against the
    // original (non-lowercased) name, so its keys had to be fixed to
    // lowercase too - see that file.
    {"onlyrows", matrixBuiltin},
    {"onlycols", matrixBuiltin},

    // Calculus
    {"ddt", calculusBuiltin},
    {"pddt", calculusBuiltin},
    {"continuity", calculusBuiltin},
    // "grad" is now a reserved Call-time interception (parser_factor.cpp),
    // not a regular builtin - see calculus.h's comment. Not registered
    // here any more; left unlisted rather than dead-routed to
    // calculusBuiltin (which no longer has a "grad" entry either).
    // "curl_calc" (not "curl" — that name is already owned by the Vector
    // category's "curl" below). Corrected 2026-09-16: curl_calc and div
    // are NOT different underlying functions from vector's curl/
    // divergence, despite what this comment used to claim -
    // Curl_Calc(a)/Div(a) (calculus.cpp) just call the identical
    // Curl(a)/divergence(a) from vector.cpp. They're registered under
    // these second names purely so the calculus domain can expose the
    // same operations under calculus-appropriate names without colliding
    // with the vector domain's own registrations of them in this table.
    {"curl_calc", calculusBuiltin},
    {"laplace", calculusBuiltin},
    // "green_integral"/"taylor_series" are also now reserved Call-time
    // interceptions (parser_factor.cpp) - same reasoning as "grad" above.
    {"stokes_integral", calculusBuiltin},
    {"rad_of_con", calculusBuiltin},
    {"div", calculusBuiltin},

    // Trigonometric
    {"sin", trigonometricBuiltin},
    {"cos", trigonometricBuiltin},
    {"tan", trigonometricBuiltin},
    {"cosec", trigonometricBuiltin},
    {"sec", trigonometricBuiltin},
    {"cot", trigonometricBuiltin},
    {"inv_sin", trigonometricBuiltin},
    {"inv_cos", trigonometricBuiltin},
    {"inv_tan", trigonometricBuiltin},
    {"inv_cosec", trigonometricBuiltin},
    {"inv_sec", trigonometricBuiltin},
    {"inv_cot", trigonometricBuiltin},
    {"atan2", trigonometricBuiltin},
    {"sinh", trigonometricBuiltin},
    {"cosh", trigonometricBuiltin},
    {"tanh", trigonometricBuiltin},
    {"cosech", trigonometricBuiltin},
    {"sech", trigonometricBuiltin},
    {"coth", trigonometricBuiltin},
    {"sin_deg", trigonometricBuiltin},
    {"cos_deg", trigonometricBuiltin},
    {"tan_deg", trigonometricBuiltin},
    {"cosec_deg", trigonometricBuiltin},
    {"sec_deg", trigonometricBuiltin},
    {"cot_deg", trigonometricBuiltin},

    // Geometry
    {"char_circle", geometricBuiltin},
    {"char_square", geometricBuiltin},
    {"char_triangle", geometricBuiltin},
    {"char_rectangle", geometricBuiltin},
    {"char_ellipse", geometricBuiltin},
    {"char_pentagon", geometricBuiltin},
    {"char_hexagon", geometricBuiltin},
    {"char_heptagon", geometricBuiltin},
    {"char_nonagon", geometricBuiltin},
    {"char_semicircle", geometricBuiltin},
    {"char_rhombus", geometricBuiltin},
    {"char_rtriangle", geometricBuiltin},
    {"char_polygon", geometricBuiltin},
    {"char_trapezoid", geometricBuiltin},
    {"char_sphere", geometricBuiltin},
    {"char_cylinder", geometricBuiltin},
    {"char_cone", geometricBuiltin},
    {"char_cube", geometricBuiltin},

    // Conditional

    {"isempty", conditionalBuiltin},
    {"is_empty", conditionalBuiltin},
    {"isnan", conditionalBuiltin},
    {"is_nan", conditionalBuiltin},

    // Logical
    {"eq", logicalBuiltin},
    {"ne", logicalBuiltin},
    {"lt", logicalBuiltin},
    {"gt", logicalBuiltin},
    {"le", logicalBuiltin},
    {"ge", logicalBuiltin},
    {"and", logicalBuiltin},
    {"or", logicalBuiltin},
    {"not", logicalBuiltin},
    {"bool", logicalBuiltin},
    {"is_true", logicalBuiltin},
    {"is_false", logicalBuiltin},
    {"is_zero", logicalBuiltin},
    {"is_positive", logicalBuiltin},
    {"is_negative", logicalBuiltin},

    // Vector
    {"dot", vectorBuiltin},
    {"cross", vectorBuiltin},
    {"unit_vector", vectorBuiltin},
    {"norm", vectorBuiltin},
    // "norm_vector" was registered in vector_builtin.cpp's own dispatch
    // table (an exact alias of "norm") but never routed here - unreachable
    // dead code, same pattern as "quotient" (arithmetic) and "matrix_pow"
    // (matrix) found the same way.
    {"norm_vector", vectorBuiltin},
    {"dircos", vectorBuiltin},
    {"angle", vectorBuiltin},
    {"proj", vectorBuiltin},
    {"proj_vec", vectorBuiltin},
    {"orthogonal", vectorBuiltin},
    {"orthonormal", vectorBuiltin},
    {"eigen_value", vectorBuiltin},
    {"eigen_vector", vectorBuiltin},
    {"divergence", vectorBuiltin},
    {"curl", vectorBuiltin},
    {"vector_tp", vectorBuiltin},
    // "vector_TP" removed 2026-09-16: it was dead/unreachable code -
    // callBuiltin's primary lookup lowercases the requested name before
    // checking this table, so any casing of "vector_TP" (which only
    // differs from "vector_tp" by letter case) already matched the
    // "vector_tp" entry above first; the exact-match fallback that would
    // have reached "vector_TP" specifically could never run. "vectortp"
    // below (was "vectorTP") is a genuinely different identifier (no
    // underscore) so it isn't shadowed the same way, just needed the
    // same lowercase fix "onlyrows"/"onlycols" got above, for the same
    // reason.
    {"vectortp", vectorBuiltin},
    // Plot
    {"plot", plotBuiltin},
    {"bar", barBuiltin},

    // Data Conversion / Space Generators
    {"int", dcBuiltin},
    {"float", dcBuiltin},
    {"str", dcBuiltin},
    {"round", dcBuiltin},
    {"rad2dec", dcBuiltin},
    {"dec2rad", dcBuiltin},
    {"space", dcBuiltin},
    {"nlspace", dcBuiltin},
    {"ndspace", dcBuiltin},
    {"dict", dcBuiltin},
    {"keys", dcBuiltin},
    {"values", dcBuiltin},
    {"size", dcBuiltin},
    {"match_key", dcBuiltin},

    // Complex numbers
    {"complex", complexBuiltin},
    {"real", complexBuiltin},
    {"imag", complexBuiltin},
    {"conj", complexBuiltin},
    {"is_complex", complexBuiltin},
    {"is_real", complexBuiltin}};

bool isBuiltinConstant(const std::string & /*name*/) { return false; }

Value callBuiltin(const std::string &name, const std::vector<Value> &args) {
  g_lastBuiltinFound = true;

  std::string key = name;
  // Normalize for lookup consistency.
  key = normalizeIdentifier(key);

  // builtinTable keys are currently a mix of cases; to keep behavior stable,
  // we try both raw and normalized forms.
  auto it = builtinTable.find(key);
  if (it == builtinTable.end()) {
    // Fallback: original name.
    it = builtinTable.find(name);
  }

  // Complex arguments. Most builtins read only a value's real part, so
  // handing them a complex number would return a wrong answer with no
  // warning - refuse instead, unless the builtin is known to handle it.
  bool anyComplex = false;
  for (const Value &arg : args)
    anyComplex = anyComplex || arg.hasComplex();
  auto rejectComplex = [&]() {
    std::cerr << "Error: '" << name << "' does not support complex numbers yet\n";
    g_lastBuiltinFound = false;
    return Value(0);
  };

  if (it != builtinTable.end()) {
    if (anyComplex && !builtinAcceptsComplex(key))
      return rejectComplex();

    // abs() of a complex value, and angle() with ONE argument (the phase
    // of a number - the two-argument angle() between vectors is
    // untouched), belong to the complex module.
    if ((key == "abs" && anyComplex) || (key == "angle" && args.size() == 1))
      return complexBuiltin(key, args);

    // complexBuiltin's own table is keyed by the lowercased name.
    return it->second(it->second == complexBuiltin ? key : name, args);
  }

  // Dynamic "logbN" family: logb2(x), logb6(x), logb10(x), ... — any
  // "logb" followed by a run of digits is treated as log base N of a
  // single argument. This is the ONLY log-base entry point exposed to NC
  // scripts — there is no separate "log_base(base, val)" or dedicated
  // "logb2" keyword; both were removed in favor of this single baked-
  // into-the-name form. log_base() (arithmetic.cpp) still exists as a
  // plain C++ helper, called only from here, not registered as its own
  // callable name.
  if (key.rfind("logb", 0) == 0 && key.size() > 4) {
    std::string baseDigits = key.substr(4);
    bool allDigits = !baseDigits.empty();
    for (char c : baseDigits) {
      if (!std::isdigit(static_cast<unsigned char>(c))) {
        allDigits = false;
        break;
      }
    }

    if (allDigits) {
      if (args.size() != 1) {
        std::cerr << "Error: Function '" << name << "' expects 1 arg, got "
                  << args.size() << "\n";
        return Value();
      }
      // log_base() itself already gives the IEEE-754-correct numeric
      // result for base<=0/base==1/val<=0 (see arithmetic.cpp) - no
      // separate guard needed here.
      double base = std::stod(baseDigits);
      return log_base(Value(base), args[0]);
    }
  }

  g_lastBuiltinFound = false;
  std::cerr << "Error: Unknown function '" << name << "'\n";
  return Value(0);
}
