#include "constants_builtin.h"

#include <algorithm>
#include <cctype>
#include <string>
#include <unordered_map>

static std::string normalizeIdentifier(std::string s) {
  s.erase(std::remove_if(s.begin(), s.end(), ::isspace), s.end());
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return std::tolower(c); });
  return s;
}

static const std::unordered_map<std::string, double> constants = {
    {"pi", 3.14159265358979323846},
    {"e", 2.718281828459045},

    // gravity
    {"g", 9.80665},

    // gas constant
    {"r", 8.314462618},

    // avogadro
    {"avogadro", 6.02214076e23},

    // planck constant
    {"h", 6.62607015e-34},

    // stefan boltzmann
    {"sigma", 5.670374419e-8},

    // coulomb constant
    {"k_e", 8.9875517923e9},

    // masses
    {"m_e", 9.1093837015e-31},
    {"m_p", 1.67262192369e-27},

    // charge
    {"e_charge", 1.602176634e-19},

    // gravitational constant
    {"grav_const", 6.67430e-11}};

static const std::unordered_map<std::string, std::string> alias = {

    // pi
    {"π", "pi"},

    // gravity
    {"gravity", "g"},

    // gas constant
    {"gas_constant", "r"},

    // planck
    {"planck", "h"},
    {"planck_constant", "h"},

    {"gravitational_constant", "grav_const"},

    // sigma
    {"σ", "sigma"},
    {"stefan_boltzmann", "sigma"},

    // coulomb
    {"ke", "k_e"},
    {"coulomb_const", "k_e"},

    // electron
    {"me", "m_e"},
    {"electron_mass", "m_e"},

    // proton
    {"mp", "m_p"},
    {"proton_mass", "m_p"},

    // charge
    {"echarge", "e_charge"},
    {"elementary_charge", "e_charge"},

    // gravity constant
    // {"grav_const", "grav_const"},
    // {"g_const", "grav_const"},

};

bool tryResolveConstantValue(const std::string &rawName, double &outValue) {
  std::string key = normalizeIdentifier(rawName);

  auto itAlias = alias.find(key);
  if (itAlias != alias.end())
    key = itAlias->second;

  auto it = constants.find(key);
  if (it == constants.end())
    return false;

  outValue = it->second;
  return true;
}

/* ================= BUILTIN HANDLER ================= */
// Kept for backward compatibility; constants MUST be resolved by parser
// directly. This handler never prints.
Value constantsBuiltin(const std::string &name, const std::vector<Value> &) {
  double v = 0.0;
  if (!tryResolveConstantValue(name, v))
    return Value();
  return Value(v);
}
