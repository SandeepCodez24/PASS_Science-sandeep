#include "constants_builtin.h"

#include <algorithm>
#include <cctype>
#include <limits>
#include <string>
#include <unordered_map>

static std::string normalizeIdentifier(std::string s) {
  // Was passing a bare `char` straight into the global ::isspace(int) -
  // undefined behavior for any byte >= 128 when char is signed (true on
  // this platform), which is exactly what every continuation byte of a
  // multi-byte UTF-8 character is - including "π"/"σ", the very aliases
  // this file registers below. The lambda already used for ::tolower right
  // after this line already guards against the identical hazard by
  // casting to unsigned char first; this did not.
  s.erase(std::remove_if(s.begin(), s.end(),
                          [](unsigned char c) { return std::isspace(c); }),
          s.end());
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return std::tolower(c); });
  return s;
}

static const std::unordered_map<std::string, double> constants = {
    {"pi", 3.14159265358979323846},
    {"e", 2.718281828459045},

    // gravity
    {"g", 9.80665},

    // gas constant
    {"r", 8.314462618},

    // avogadro
    {"avogadro", 6.02214076e23},

    // planck constant
    {"h", 6.62607015e-34},

    // stefan boltzmann
    {"sigma", 5.670374419e-8},

    // coulomb constant
    {"k_e", 8.9875517923e9},

    // masses
    {"m_e", 9.1093837015e-31},
    {"m_p", 1.67262192369e-27},

    // charge
    {"e_charge", 1.602176634e-19},

    // gravitational constant
    {"grav_const", 6.67430e-11},

    // IEEE-754 special values (NumPy np.nan / np.inf). `-inf` needs no entry
    // of its own: it is unary minus applied to `inf`.
    {"nan", std::numeric_limits<double>::quiet_NaN()},
    {"inf", std::numeric_limits<double>::infinity()}};

static const std::unordered_map<std::string, std::string> alias = {

    // pi
    // "Case-insensitive" per this file's own header doc - true for every
    // ASCII-named alias via normalizeIdentifier()'s std::tolower pass, but
    // std::tolower operates byte-by-byte and cannot case-fold a
    // multi-byte UTF-8 sequence, so the uppercase Greek letters needed
    // their own explicit entries or they'd silently fail to resolve at
    // all (confirmed: "π" worked, "Π" did not, despite being "the same
    // constant, different case" by the same standard every ASCII name
    // gets).
    {"π", "pi"},
    {"Π", "pi"},

    // gravity
    {"gravity", "g"},

    // gas constant
    {"gas_constant", "r"},

    // planck
    {"planck", "h"},
    {"planck_constant", "h"},

    {"gravitational_constant", "grav_const"},

    // sigma
    // Same uppercase-Greek gap as "Π" above.
    {"σ", "sigma"},
    {"Σ", "sigma"},
    {"stefan_boltzmann", "sigma"},

    // coulomb
    {"ke", "k_e"},
    {"coulomb_const", "k_e"},

    // electron
    {"me", "m_e"},
    {"electron_mass", "m_e"},

    // proton
    {"mp", "m_p"},
    {"proton_mass", "m_p"},

    // charge
    {"echarge", "e_charge"},
    {"elementary_charge", "e_charge"},

    // gravity constant
    // {"grav_const", "grav_const"},
    // {"g_const", "grav_const"},

};

bool tryResolveConstantValue(const std::string &rawName, double &outValue) {
  std::string key = normalizeIdentifier(rawName);

  auto itAlias = alias.find(key);
  if (itAlias != alias.end())
    key = itAlias->second;

  auto it = constants.find(key);
  if (it == constants.end())
    return false;

  outValue = it->second;
  return true;
}

/* ================= BUILTIN HANDLER ================= */
// Kept for backward compatibility; constants MUST be resolved by parser
// directly. This handler never prints.
Value constantsBuiltin(const std::string &name, const std::vector<Value> &) {
  double v = 0.0;
  if (!tryResolveConstantValue(name, v))
    return Value();
  return Value(v);
}
