#pragma once

#include "value.h"
#include <string>
#include <vector>

// Global flag: set by callBuiltin to indicate success (true) or unknown
// function (false)
extern bool g_lastBuiltinFound;

Value callBuiltin(const std::string &name, const std::vector<Value> &args);

// Returns true if the given identifier is registered as one of the built-in
// constants. (e.g. pi, e, g, gas_constant, ...)
bool isBuiltinConstant(const std::string &name);
