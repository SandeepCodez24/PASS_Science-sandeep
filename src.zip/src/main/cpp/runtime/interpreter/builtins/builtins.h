#pragma once

#include "value.h"
#include <string>
#include <vector>

// Global flag: set by callBuiltin to indicate success (true) or unknown
// function (false)
extern bool g_lastBuiltinFound;

Value callBuiltin(const std::string &name, const std::vector<Value> &args);

// A builtin with several results, called as [U, S, V] = svd(A): if `name`
// is one that can return `nout` values, runs it, fills `out` (nout values),
// sets `ok` (false = an error was printed) and returns true. Returns false
// if `name` has no multi-output form.
bool callBuiltinMulti(const std::string &name, const std::vector<Value> &args, size_t nout,
                      std::vector<Value> &out, bool &ok);

// Returns true if the given identifier is registered as one of the built-in
// constants. (e.g. pi, e, g, gas_constant, ...)
bool isBuiltinConstant(const std::string &name);
