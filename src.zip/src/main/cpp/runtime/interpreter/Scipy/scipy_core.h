// What every SciPy section shares: dense real/complex matrices, reading NC
// values into them, building NC results, Dict results, and calling an NC
// function given by name or @reference. Standard C++ only, on purpose: the
// whole Scipy tree builds on any OS with no third-party library.
//
// An NC "Array" is 1-D data in any of its forms (1xN, Nx1, a real array).
// Results that the mapping tables call Array are 1xN matrices, the shape of
// the literal [1,2,3] and of space().
#ifndef NC_SCIPY_CORE_H
#define NC_SCIPY_CORE_H

#include <algorithm>
#include <cmath>
#include <complex>
#include <limits>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "scipy_common.h"
#include "scipy_main.h"
#include "scipy_parallel.h"

namespace nc {
namespace scipy {

using cd = std::complex<double>;
using Vec = std::vector<double>;
using CVec = std::vector<cd>;
using IVec = std::vector<long long>;
using Args = std::vector<Value>;

constexpr double kPi = 3.14159265358979323846;
constexpr double kNaN = std::numeric_limits<double>::quiet_NaN();
constexpr double kInf = std::numeric_limits<double>::infinity();
constexpr double kEps = std::numeric_limits<double>::epsilon();

// Row-major dense matrix.
template <class T> struct MatT {
  size_t r = 0, c = 0;
  std::vector<T> a;
  MatT() = default;
  MatT(size_t rows, size_t cols, T fill = T(0)) : r(rows), c(cols), a(rows * cols, fill) {}
  T &operator()(size_t i, size_t j) { return a[i * c + j]; }
  const T &operator()(size_t i, size_t j) const { return a[i * c + j]; }
  T *row(size_t i) { return a.data() + i * c; }
  const T *row(size_t i) const { return a.data() + i * c; }
  static MatT eye(size_t n, size_t m = 0) {
    MatT e(n, m ? m : n);
    for (size_t i = 0; i < std::min(e.r, e.c); i++)
      e(i, i) = T(1);
    return e;
  }
};
using Mat = MatT<double>;
using CMat = MatT<cd>;

template <class T> MatT<T> transposeOf(const MatT<T> &m) {
  MatT<T> t(m.c, m.r);
  for (size_t i = 0; i < m.r; i++)
    for (size_t j = 0; j < m.c; j++)
      t(j, i) = m(i, j);
  return t;
}
inline double conjOf(double x) { return x; }
inline cd conjOf(const cd &x) { return std::conj(x); }
template <class T> MatT<T> adjointOf(const MatT<T> &m) {
  MatT<T> t(m.c, m.r);
  for (size_t i = 0; i < m.r; i++)
    for (size_t j = 0; j < m.c; j++)
      t(j, i) = conjOf(m(i, j));
  return t;
}
template <class T> MatT<T> mul(const MatT<T> &x, const MatT<T> &y) {
  MatT<T> o(x.r, y.c);
  for (size_t i = 0; i < x.r; i++)
    for (size_t k = 0; k < x.c; k++) {
      const T v = x(i, k);
      if (v == T(0))
        continue;
      const T *yr = y.row(k);
      T *orow = o.row(i);
      for (size_t j = 0; j < y.c; j++)
        orow[j] += v * yr[j];
    }
  return o;
}
template <class T> std::vector<T> mulVec(const MatT<T> &x, const std::vector<T> &v) {
  std::vector<T> o(x.r, T(0));
  for (size_t i = 0; i < x.r; i++)
    for (size_t j = 0; j < x.c; j++)
      o[i] += x(i, j) * v[j];
  return o;
}
inline CMat toComplex(const Mat &m) {
  CMat o(m.r, m.c);
  for (size_t i = 0; i < m.a.size(); i++)
    o.a[i] = m.a[i];
  return o;
}
inline CVec toComplex(const Vec &v) { return CVec(v.begin(), v.end()); }

// ---- reading ----

// A value left out, or the 0 that the mapping tables write for "not given"
// when a later input is needed: minimize("f", x0, "SLSQP", 0, c).
inline bool isOmitted(const Args &a, size_t i) {
  return i >= a.size() || (isPlainNumber(a[i]) && !a[i].isComplex && a[i].number == 0.0);
}
inline bool isMatrixLike(const Value &v) { return v.isArray || v.isMatrix; }

// True when v holds only numbers (real or complex).
inline bool numericCells(const Value &v) {
  if (isPlainNumber(v))
    return true;
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++) {
      Value e = v.at(i);
      if (!isPlainNumber(e))
        return false;
    }
    return true;
  }
  if (v.isMatrix && !v.isND()) {
    for (size_t r = 0; r < v.rows(); r++) {
      if (v.rowLength(r) != v.cols())
        return false;
      for (size_t c = 0; c < v.cols(); c++) {
        Value e = v.at(r, c);
        if (!isPlainNumber(e))
          return false;
      }
    }
    return true;
  }
  return false;
}

// Any 1-D form, or a whole matrix read row by row.
inline bool readVec(const Value &v, Vec &out) { return numericCells(v) && flattenNumbers(v, out); }
inline bool readCVec(const Value &v, CVec &out) {
  if (!numericCells(v))
    return false;
  out.clear();
  if (isPlainNumber(v))
    out.push_back(cd(v.number, v.isComplex ? v.imag : 0.0));
  else if (v.isArray)
    for (size_t i = 0; i < v.length(); i++)
      out.push_back(v.cnumAt(i));
  else
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.cols(); c++)
        out.push_back(v.cnumAt(r, c));
  return true;
}
inline bool readMat(const Value &v, Mat &out) {
  if (!numericCells(v))
    return false;
  if (v.isMatrix) {
    out = Mat(v.rows(), v.cols());
    for (size_t r = 0; r < out.r; r++)
      for (size_t c = 0; c < out.c; c++)
        out(r, c) = v.numAt(r, c);
    return true;
  }
  Vec f;
  if (!flattenNumbers(v, f))
    return false;
  out = Mat(f.empty() ? 0 : 1, f.size());
  out.a = f;
  return true;
}
inline bool readCMat(const Value &v, CMat &out) {
  if (!numericCells(v))
    return false;
  if (v.isMatrix) {
    out = CMat(v.rows(), v.cols());
    for (size_t r = 0; r < out.r; r++)
      for (size_t c = 0; c < out.c; c++)
        out(r, c) = v.cnumAt(r, c);
    return true;
  }
  CVec f;
  readCVec(v, f);
  out = CMat(f.empty() ? 0 : 1, f.size());
  out.a = f;
  return true;
}

inline bool getVec(const Args &a, size_t i, CallContext &ctx, Vec &out) {
  if (i >= a.size() || !readVec(a[i], out)) {
    ctx.fail("the " + ordinal(i) + " argument must be an array of numbers");
    return false;
  }
  return true;
}
inline bool getCVec(const Args &a, size_t i, CallContext &ctx, CVec &out) {
  if (i >= a.size() || !readCVec(a[i], out)) {
    ctx.fail("the " + ordinal(i) + " argument must be an array of numbers");
    return false;
  }
  return true;
}
inline bool getMat(const Args &a, size_t i, CallContext &ctx, Mat &out) {
  if (i >= a.size() || !readMat(a[i], out)) {
    ctx.fail("the " + ordinal(i) + " argument must be a matrix of numbers");
    return false;
  }
  return true;
}
inline bool getCMat(const Args &a, size_t i, CallContext &ctx, CMat &out) {
  if (i >= a.size() || !readCMat(a[i], out)) {
    ctx.fail("the " + ordinal(i) + " argument must be a matrix of numbers");
    return false;
  }
  return true;
}
inline bool getSquare(const Args &a, size_t i, CallContext &ctx, Mat &out) {
  if (!getMat(a, i, ctx, out))
    return false;
  if (out.r != out.c) {
    ctx.fail("the " + ordinal(i) + " argument must be a square matrix");
    return false;
  }
  return true;
}
inline bool getCSquare(const Args &a, size_t i, CallContext &ctx, CMat &out) {
  if (!getCMat(a, i, ctx, out))
    return false;
  if (out.r != out.c) {
    ctx.fail("the " + ordinal(i) + " argument must be a square matrix");
    return false;
  }
  return true;
}

// Optional scalars and text: `def` when left out.
inline double optNum(const Args &a, size_t i, double def) {
  return (i < a.size() && isPlainNumber(a[i])) ? a[i].number : def;
}
inline long long optInt(const Args &a, size_t i, long long def) {
  return (i < a.size() && isPlainNumber(a[i])) ? static_cast<long long>(a[i].number) : def;
}
inline bool optBool(const Args &a, size_t i, bool def) {
  return (i < a.size() && isPlainNumber(a[i])) ? a[i].number != 0.0 : def;
}
inline std::string optText(const Args &a, size_t i, const std::string &def) {
  return (i < a.size() && a[i].isText) ? a[i].text() : def;
}
inline bool isNumberArg(const Args &a, size_t i) { return i < a.size() && isPlainNumber(a[i]); }

// ---- building results ----

inline Value toValue(const Vec &v) {
  std::vector<Value> row;
  row.reserve(v.size());
  for (double d : v)
    row.push_back(Value(d));
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}
inline Value toValue(const IVec &v) {
  std::vector<Value> row;
  row.reserve(v.size());
  for (long long d : v)
    row.push_back(Value(static_cast<double>(d)));
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}
inline Value cellOf(const cd &z) { return Value::complexNumber(z.real(), z.imag()); }
inline Value toValue(const CVec &v) {
  std::vector<Value> row;
  row.reserve(v.size());
  for (const cd &d : v)
    row.push_back(cellOf(d));
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}
inline Value toValue(const Mat &m) {
  std::vector<std::vector<Value>> rows(m.r);
  for (size_t i = 0; i < m.r; i++) {
    rows[i].reserve(m.c);
    for (size_t j = 0; j < m.c; j++)
      rows[i].push_back(Value(m(i, j)));
  }
  return Value(std::move(rows));
}
inline Value toValue(const CMat &m) {
  std::vector<std::vector<Value>> rows(m.r);
  for (size_t i = 0; i < m.r; i++) {
    rows[i].reserve(m.c);
    for (size_t j = 0; j < m.c; j++)
      rows[i].push_back(cellOf(m(i, j)));
  }
  return Value(std::move(rows));
}
// Same value, as real numbers when every imaginary part is exactly zero.
inline Value realIfPossible(const CVec &v) {
  for (const cd &z : v)
    if (z.imag() != 0.0)
      return toValue(v);
  Vec r(v.size());
  for (size_t i = 0; i < v.size(); i++)
    r[i] = v[i].real();
  return toValue(r);
}
inline Value realIfPossible(const CMat &m) {
  for (const cd &z : m.a)
    if (z.imag() != 0.0)
      return toValue(m);
  Mat o(m.r, m.c);
  for (size_t i = 0; i < m.a.size(); i++)
    o.a[i] = m.a[i].real();
  return toValue(o);
}
inline Value scalarOf(const cd &z) { return z.imag() == 0.0 ? Value(z.real()) : cellOf(z); }

using DictInit = std::vector<std::pair<std::string, Value>>;
inline Value makeDict(const DictInit &fields) {
  std::unordered_map<std::string, Value> d;
  for (const auto &f : fields)
    d.emplace(f.first, f.second);
  return Value(d);
}
inline const Value *dictGet(const Value &d, const std::string &key) {
  if (!d.isDict && !d.isObject)
    return nullptr;
  auto it = d.dict().find(key);
  return it == d.dict().end() ? nullptr : &it->second;
}
inline Value namesValue(const std::vector<std::string> &names) {
  std::vector<Value> row;
  for (const auto &n : names)
    row.push_back(Value(n));
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}

// ---- calling NC functions ----

// Calls the NC function given by `fn`: its name in text, or a @reference.
// False means it failed; its own error has been printed. Never from a worker
// thread: callbacks run in the Parser, on the interpreter thread.
bool callNC(const Value &fn, const Args &args, Value &out);
inline bool isCallable(const Value &v) { return v.isText || v.isFunctionRef; }
// How many inputs an NC function takes, or -1 when that cannot be told (a builtin).
int functionInputCount(const Value &fn);

// An NC function seen as a numeric one. After a failure the calls return NaN
// and `failed` is set; a solver loop checks it and stops.
struct NcFn {
  Value fn;
  bool failed = false;
  long calls = 0;
  explicit NcFn(const Value &f) : fn(f) {}
  Value raw(const Args &in) {
    Value out;
    calls++;
    if (failed || !callNC(fn, in, out)) {
      failed = true;
      return Value(kNaN);
    }
    return out;
  }
  // f(x, ...) -> number
  double number(const Args &in) {
    Value out = raw(in);
    Vec v;
    if (failed || !readVec(out, v) || v.empty()) {
      failed = true;
      return kNaN;
    }
    return v[0];
  }
  double scalar(double x) { return number({Value(x)}); }
  double ofVec(const Vec &x) { return number({toValue(x)}); }
  // f(v) -> array
  Vec vecOfVec(const Vec &x) {
    Value out = raw({toValue(x)});
    Vec v;
    if (failed || !readVec(out, v))
      failed = true;
    return v;
  }
  std::string failText() const {
    return "the function " + (fn.isText ? "'" + fn.text() + "' " : std::string()) +
           "could not be evaluated";
  }
};

// ---- registration ----

// Fills in the summary and the SciPy original from the generated table
// (scipy_doc_table.cpp), so a section writes only name, counts and inputs.
FunctionSpec makeSpec(const char *name, Section s, int minArgs, int maxArgs, const char *params,
                      Impl impl, bool acceptsComplex);

} // namespace scipy
} // namespace nc

// SP_ADD("name", min, max, "a, b[, c]") { ...body using a (args) and ctx... } SP_END
// A section defines SP_SEC first. SP_ENDC is the same, accepting complex input.
#define SP_ADD(NAME, MINA, MAXA, PARAMS)                                                           \
  reg.add(makeSpec(NAME, SP_SEC, MINA, MAXA, PARAMS, [](const Args &a, CallContext &ctx) -> Value
#define SP_END , false));
#define SP_ENDC , true));

#endif // NC_SCIPY_CORE_H
