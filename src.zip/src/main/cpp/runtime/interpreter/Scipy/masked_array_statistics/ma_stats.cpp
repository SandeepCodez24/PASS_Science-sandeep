// Section 23: statistics on masked data (scipy.stats.mstats). NC has no
// masked arrays: a NaN element is a masked one. Functions that return data
// give NaN where SciPy gives a masked element.
#include "masked_array_statistics_main.h"

#include <map>

#include "../statistics/st_common.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::MaskedArrayStatistics

namespace {
using namespace st;

Vec valid(const Vec &x) {
  Vec v;
  for (double d : x)
    if (!std::isnan(d))
      v.push_back(d);
  return v;
}
// indices of the non-NaN elements, in increasing order of value
std::vector<size_t> argsortValid(const Vec &x) {
  std::vector<size_t> idx;
  for (size_t i = 0; i < x.size(); i++)
    if (!std::isnan(x[i]))
      idx.push_back(i);
  std::stable_sort(idx.begin(), idx.end(), [&](size_t a, size_t b) { return x[a] < x[b]; });
  return idx;
}

// data with its shape, so a result can keep it
struct Shaped {
  Mat m;
  bool matrix = false;
  Value out(const Vec &v) const {
    if (!matrix)
      return toValue(v);
    Mat r(m.r, m.c);
    r.a = v;
    return toValue(r);
  }
};
bool readShaped(const Args &a, size_t i, CallContext &ctx, Shaped &s) {
  if (!getMat(a, i, ctx, s.m))
    return false;
  s.matrix = a[i].isMatrix && s.m.r > 1;
  return true;
}

bool limitsArg(const Args &a, size_t i, CallContext &ctx, double &lo, double &hi, double defLo, double defHi) {
  lo = defLo;
  hi = defHi;
  if (i >= a.size())
    return true;
  if (isPlainNumber(a[i])) {
    lo = hi = a[i].number;
    return true;
  }
  Vec l;
  if (!getVec(a, i, ctx, l))
    return false;
  if (l.size() != 2) {
    ctx.fail("limits must be [low, high] (NaN for no limit)");
    return false;
  }
  lo = l[0];
  hi = l[1];
  return true;
}
bool fractionsOk(double lo, double hi, CallContext &ctx) {
  if ((!std::isnan(lo) && (lo < 0 || lo > 1)) || (!std::isnan(hi) && (hi < 0 || hi > 1))) {
    ctx.fail("the proportions to cut must be between 0 and 1");
    return false;
  }
  return true;
}

// mstats.trimr: masks (NaN) the lowest / highest fractions
Vec trimr(Vec x, double lo, double hi, bool loInc, bool hiInc) {
  std::vector<size_t> idx = argsortValid(x);
  double n = idx.size();
  if (!std::isnan(lo) && lo != 0) {
    size_t li = static_cast<size_t>(loInc ? std::floor(lo * n) : std::nearbyint(lo * n));
    for (size_t k = 0; k < std::min(li, idx.size()); k++)
      x[idx[k]] = kNaN;
  }
  if (!std::isnan(hi)) {
    size_t ui = static_cast<size_t>(n - (hiInc ? std::floor(n * hi) : std::nearbyint(n * hi)));
    for (size_t k = ui; k < idx.size(); k++)
      x[idx[k]] = kNaN;
  }
  return x;
}
// mstats.trima: masks the values outside absolute limits
Vec trima(Vec x, double lo, double hi, bool loInc, bool hiInc) {
  for (double &v : x) {
    bool cut = (!std::isnan(lo) && (loInc ? v < lo : v <= lo)) || (!std::isnan(hi) && (hiInc ? v > hi : v >= hi));
    if (cut)
      v = kNaN;
  }
  return x;
}

// mstats.trimmed_stde for one sample (NaN removed first)
double trimmedStde(const Vec &x, double lo, double hi) {
  Vec a = valid(x);
  std::sort(a.begin(), a.end());
  size_t n = a.size();
  size_t li = static_cast<size_t>(std::floor(lo * n)), ui = static_cast<size_t>(n - std::floor(n * hi));
  if (n == 0 || ui == 0 || li >= n)
    return kNaN;
  for (size_t k = 0; k < li; k++)
    a[k] = a[li];
  for (size_t k = ui; k < n; k++)
    a[k] = a[ui - 1];
  return std::sqrt(var(a)) / ((1 - lo - hi) * std::sqrt(double(n)));
}

double betaCdf(double x, double a, double b) {
  if (x <= 0)
    return 0;
  if (x >= 1)
    return 1;
  return sf::betainc(a, b, x);
}

Vec mquantiles(const Vec &data, const Vec &p, double ap, double bp) {
  Vec x = valid(data);
  std::sort(x.begin(), x.end());
  double n = x.size();
  Vec out(p.size(), kNaN);
  if (x.empty())
    return out;
  for (size_t i = 0; i < p.size(); i++) {
    if (x.size() == 1) {
      out[i] = x[0];
      continue;
    }
    double m = ap + p[i] * (1 - ap - bp), aleph = n * p[i] + m;
    double k = std::floor(std::min(n - 1, std::max(1.0, aleph)));
    double g = std::min(1.0, std::max(0.0, aleph - k));
    out[i] = (1 - g) * x[size_t(k) - 1] + g * x[size_t(k)];
  }
  return out;
}

Vec mjci(const Vec &data, const Vec &p) {
  Vec x = valid(data);
  std::sort(x.begin(), x.end());
  double n = x.size();
  Vec out(p.size());
  for (size_t i = 0; i < p.size(); i++) {
    double m = std::floor(p[i] * n + 0.5), c1 = 0, c2 = 0;
    for (size_t k = 0; k < x.size(); k++) {
      double hi = (k + 1) / n, lo = hi - 1 / n;
      double w = betaCdf(hi, m - 1, n - m) - betaCdf(lo, m - 1, n - m);
      c1 += w * x[k];
      c2 += w * x[k] * x[k];
    }
    out[i] = std::sqrt(c2 - c1 * c1);
  }
  return out;
}

bool idealFourths(const Vec &data, double &q1, double &q3) {
  Vec x = valid(data);
  std::sort(x.begin(), x.end());
  size_t n = x.size();
  if (n < 3) {
    q1 = q3 = kNaN;
    return false;
  }
  double t = n / 4.0 + 5 / 12.0, j = std::floor(t), h = t - j;
  size_t ji = size_t(j), k = n - ji;
  q1 = (1 - h) * x[ji - 1] + h * x[ji];
  q3 = (1 - h) * x[k] + h * x[k - 1];
  return true;
}

double stdeMedian(const Vec &data) {
  Vec x = valid(data);
  std::sort(x.begin(), x.end());
  double n = x.size(), z = 2.5758293035489004;
  size_t k = static_cast<size_t>(std::nearbyint((n + 1) / 2.0 - z * std::sqrt(n / 4.0)));
  if (k < 1 || k > x.size())
    return kNaN;
  return (x[size_t(n) - k] - x[k - 1]) / (2 * z);
}

double msign(double v) { return v > 0 ? 1.0 : v < 0 ? -1.0 : 0.0; }

// tie size -> number of groups of that size
std::map<long long, long long> tiedGroups(const Vec &x) {
  std::map<long long, long long> out;
  for (double t : tieCounts(valid(x)))
    if (t > 1)
      out[static_cast<long long>(t)]++;
  return out;
}
double tieCorr(const Vec &x) {
  double s = 0;
  for (const auto &kv : tiedGroups(x))
    s += double(kv.second) * kv.first * (kv.first - 1);
  return s;
}

bool callAfterDrop(const char *name, Args in, Value &out, CallContext &ctx) {
  if (!callNC(Value(std::string(name)), in, out)) {
    ctx.fail(std::string("the ") + name + " step failed");
    return false;
  }
  return true;
}
} // namespace

void registerMaStats(Registry &reg) {
  SP_ADD("pad_to_matrix", 1, kVariadic, "arrays...") {
    std::vector<Vec> rows;
    if (a.size() == 1 && a[0].isMatrix) {
      Mat m;
      if (!getMat(a, 0, ctx, m))
        return Value(0.0);
      for (size_t i = 0; i < m.r; i++)
        rows.push_back(Vec(m.row(i), m.row(i) + m.c));
    } else {
      for (size_t i = 0; i < a.size(); i++) {
        Vec v;
        if (!getVec(a, i, ctx, v))
          return Value(0.0);
        rows.push_back(v);
      }
    }
    size_t w = 0;
    for (const Vec &r : rows)
      w = std::max(w, r.size());
    Mat out(rows.size(), w, kNaN);
    for (size_t i = 0; i < rows.size(); i++)
      for (size_t j = 0; j < rows[i].size(); j++)
        out(i, j) = std::isfinite(rows[i][j]) ? rows[i][j] : kNaN;
    return toValue(out);
  } SP_END

  SP_ADD("count_tied_groups", 1, 2, "data, use_missing") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    std::map<long long, long long> g = tiedGroups(x);
    if (optBool(a, 1, false)) {
      long long nm = 0;
      for (double v : x)
        nm += std::isnan(v);
      if (nm)
        g[nm]++;
    }
    DictInit d;
    for (const auto &kv : g)
      d.push_back({std::to_string(kv.first), Value(double(kv.second))});
    return makeDict(d);
  } SP_END

  SP_ADD("find_repeats", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    Vec s = valid(x), vals, cnts;
    std::sort(s.begin(), s.end());
    for (size_t i = 0; i < s.size();) {
      size_t j = i;
      while (j + 1 < s.size() && s[j + 1] == s[i])
        j++;
      if (j > i) {
        vals.push_back(s[i]);
        cnts.push_back(double(j - i + 1));
      }
      i = j + 1;
    }
    return makeDict({{"values", toValue(vals)}, {"counts", toValue(cnts)}});
  } SP_END

  SP_ADD("trim_mask", 2, 4, "data, limits, relative, inclusive") {
    Shaped s;
    double lo, hi;
    if (!readShaped(a, 0, ctx, s) || !limitsArg(a, 1, ctx, lo, hi, kNaN, kNaN))
      return Value(0.0);
    bool rel = optBool(a, 2, false);
    Vec inc = {1, 1};
    if (a.size() > 3 && (!getVec(a, 3, ctx, inc) || inc.size() != 2)) {
      if (ctx.ok())
        ctx.fail("inclusive must be [low, high] of true/false");
      return Value(0.0);
    }
    if (rel && !fractionsOk(lo, hi, ctx))
      return Value(0.0);
    return s.out(rel ? trimr(s.m.a, lo, hi, inc[0] != 0, inc[1] != 0) : trima(s.m.a, lo, hi, inc[0] != 0, inc[1] != 0));
  } SP_END

  SP_ADD("trim_mask_tail", 1, 3, "data, cut, tail") {
    Shaped s;
    if (!readShaped(a, 0, ctx, s))
      return Value(0.0);
    double cut = optNum(a, 1, 0.2);
    std::string tail = optText(a, 2, "left");
    if (tail != "left" && tail != "right") {
      ctx.fail("tail must be \"left\" or \"right\"");
      return Value(0.0);
    }
    if (!fractionsOk(cut, cut, ctx))
      return Value(0.0);
    return s.out(tail == "left" ? trimr(s.m.a, cut, kNaN, true, true) : trimr(s.m.a, kNaN, cut, true, true));
  } SP_END

  auto trimStat = [](int which) { // 0 var, 1 sd, 2 sem
    return [which](const Args &a, CallContext &ctx) -> Value {
      Vec x;
      double lo, hi;
      if (!getVec(a, 0, ctx, x) || !limitsArg(a, 1, ctx, lo, hi, 0.1, 0.1) || !fractionsOk(lo, hi, ctx))
        return Value(0.0);
      if (which == 2)
        return Value(trimmedStde(x, std::isnan(lo) ? 0 : lo, std::isnan(hi) ? 0 : hi));
      double ddof = optNum(a, 2, 0);
      Vec t = valid(trimr(x, lo, hi, true, true));
      if (double(t.size()) <= ddof)
        return Value(kNaN);
      double v = var(t, ddof);
      return Value(which == 0 ? v : std::sqrt(v));
    };
  };
  reg.add(makeSpec("nan_trim_var", SP_SEC, 1, 3, "data, limits, ddof", trimStat(0), false));
  reg.add(makeSpec("nan_trim_sd", SP_SEC, 1, 3, "data, limits, ddof", trimStat(1), false));
  reg.add(makeSpec("nan_trim_sem", SP_SEC, 1, 2, "data, limits", trimStat(2), false));

  SP_ADD("trim_mean_ci", 1, 3, "data, limits, alpha") {
    Vec x;
    double lo, hi;
    if (!getVec(a, 0, ctx, x) || !limitsArg(a, 1, ctx, lo, hi, 0.2, 0.2) || !fractionsOk(lo, hi, ctx))
      return Value(0.0);
    double al = optNum(a, 2, 0.05);
    if (!(al > 0 && al < 1)) {
      ctx.fail("alpha must be between 0 and 1");
      return Value(0.0);
    }
    Vec t = valid(trimr(x, lo, hi, true, true));
    double m = mean(t), se = trimmedStde(x, lo, hi), tp = -sf::stdtrit(double(t.size()) - 1, al / 2);
    return toValue(Vec{m - tp * se, m + tp * se});
  } SP_END

  SP_ADD("winsorize", 2, 3, "data, limits, inclusive") {
    Shaped s;
    double lo, hi;
    if (!readShaped(a, 0, ctx, s) || !limitsArg(a, 1, ctx, lo, hi, kNaN, kNaN) || !fractionsOk(lo, hi, ctx))
      return Value(0.0);
    Vec inc = {1, 1};
    if (a.size() > 2 && (!getVec(a, 2, ctx, inc) || inc.size() != 2)) {
      if (ctx.ok())
        ctx.fail("inclusive must be [low, high] of true/false");
      return Value(0.0);
    }
    Vec x = s.m.a;
    std::vector<size_t> idx = argsortValid(x);
    double n = idx.size();
    if (idx.empty())
      return s.out(x);
    Vec orig = x;
    if (!std::isnan(lo) && lo != 0) {
      size_t li = static_cast<size_t>(inc[0] != 0 ? std::floor(lo * n) : std::nearbyint(lo * n));
      li = std::min(li, idx.size() - 1);
      for (size_t k = 0; k < li; k++)
        x[idx[k]] = orig[idx[li]];
    }
    if (!std::isnan(hi)) {
      size_t ui = static_cast<size_t>(n - (inc[1] != 0 ? std::floor(n * hi) : std::nearbyint(n * hi)));
      if (ui >= 1)
        for (size_t k = ui; k < idx.size(); k++)
          x[idx[k]] = x[idx[ui - 1]];
    }
    return s.out(x);
  } SP_END

  SP_ADD("mquantiles", 1, 4, "data, prob, alphap, betap") {
    Vec x, p = {0.25, 0.5, 0.75};
    if (!getVec(a, 0, ctx, x) || (a.size() > 1 && !getVec(a, 1, ctx, p)))
      return Value(0.0);
    for (double q : p)
      if (!(q >= 0 && q <= 1)) {
        ctx.fail("the probabilities must be between 0 and 1");
        return Value(0.0);
      }
    return toValue(mquantiles(x, p, optNum(a, 2, 0.4), optNum(a, 3, 0.4)));
  } SP_END

  SP_ADD("mquantiles_ci", 1, 3, "data, prob, alpha") {
    Vec x, p = {0.25, 0.5, 0.75};
    if (!getVec(a, 0, ctx, x) || (a.size() > 1 && !getVec(a, 1, ctx, p)))
      return Value(0.0);
    double al = optNum(a, 2, 0.05);
    al = std::min(al, 1 - al);
    double z = -sf::ndtri(al / 2);
    Vec q = mquantiles(x, p, 0, 0), s = mjci(x, p), lo(p.size()), hi(p.size());
    for (size_t i = 0; i < p.size(); i++) {
      lo[i] = q[i] - z * s[i];
      hi[i] = q[i] + z * s[i];
    }
    return makeDict({{"low", toValue(lo)}, {"high", toValue(hi)}});
  } SP_END

  SP_ADD("mj_ci", 1, 2, "data, prob") {
    Vec x, p = {0.25, 0.5, 0.75};
    if (!getVec(a, 0, ctx, x) || (a.size() > 1 && !getVec(a, 1, ctx, p)))
      return Value(0.0);
    return toValue(mjci(x, p));
  } SP_END

  auto hdq = [](bool sd) {
    return [sd](const Args &a, CallContext &ctx) -> Value {
      Vec d, p = {0.25, 0.5, 0.75};
      if (!getVec(a, 0, ctx, d) || (a.size() > 1 && !getVec(a, 1, ctx, p)))
        return Value(0.0);
      Vec x = valid(d);
      std::sort(x.begin(), x.end());
      double n = x.size();
      Vec out(p.size(), kNaN);
      if (x.size() < 2)
        return toValue(out);
      for (size_t i = 0; i < p.size(); i++) {
        if (!sd) {
          double s = 0;
          for (size_t k = 0; k < x.size(); k++)
            s += (betaCdf((k + 1) / n, (n + 1) * p[i], (n + 1) * (1 - p[i])) - betaCdf(k / n, (n + 1) * p[i], (n + 1) * (1 - p[i]))) * x[k];
          out[i] = p[i] == 0 ? x.front() : p[i] == 1 ? x.back() : s;
        } else {
          size_t m = x.size();
          Vec w(m - 1), mx(m, 0.0);
          for (size_t k = 0; k + 1 < m; k++)
            w[k] = betaCdf((k + 1) / (n - 1), n * p[i], n * (1 - p[i])) - betaCdf(k / (n - 1), n * p[i], n * (1 - p[i]));
          double c = 0;
          for (size_t k = 1; k < m; k++) {
            c += w[k - 1] * x[k - 1];
            mx[k] = c;
          }
          c = 0;
          for (size_t k = m - 1; k-- > 0;) {
            c += w[k] * x[k + 1];
            mx[k] += c;
          }
          out[i] = std::sqrt(var(mx, 0) * (n - 1));
        }
      }
      return toValue(out);
    };
  };
  reg.add(makeSpec("hd_quantiles", SP_SEC, 1, 2, "data, prob", hdq(false), false));
  reg.add(makeSpec("hd_quantiles_sd", SP_SEC, 1, 2, "data, prob", hdq(true), false));

  SP_ADD("hd_median", 1, 1, "data") {
    Vec d;
    if (!getVec(a, 0, ctx, d))
      return Value(0.0);
    Vec x = valid(d);
    std::sort(x.begin(), x.end());
    double n = x.size(), s = 0;
    if (x.size() < 2)
      return Value(kNaN);
    for (size_t k = 0; k < x.size(); k++)
      s += (betaCdf((k + 1) / n, (n + 1) / 2, (n + 1) / 2) - betaCdf(k / n, (n + 1) / 2, (n + 1) / 2)) * x[k];
    return Value(s);
  } SP_END

  SP_ADD("ideal_fourths", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    double q1, q3;
    idealFourths(x, q1, q3);
    return toValue(Vec{q1, q3});
  } SP_END

  SP_ADD("median_ci", 1, 2, "data, alpha") {
    Vec d;
    if (!getVec(a, 0, ctx, d))
      return Value(0.0);
    Vec x = valid(d);
    std::sort(x.begin(), x.end());
    double al = optNum(a, 1, 0.05);
    al = std::min(al, 1 - al);
    double n = x.size();
    if (x.size() < 3) {
      ctx.fail("needs at least 3 values");
      return Value(0.0);
    }
    const pd::Family *bn = pd::findFamily("binom");
    double pr[2] = {n, 0.5};
    auto F = [&](double k) { return pd::cdf(*bn, k, pr); };
    double k = std::floor(pd::ppf(*bn, al / 2, pr));
    double gk = F(n - k) - F(k - 1);
    if (gk < 1 - al) {
      k -= 1;
      gk = F(n - k) - F(k - 1);
    }
    double gkk = F(n - k - 1) - F(k);
    double I = (gk - 1 + al) / (gk - gkk), lam = (n - k) * I / (k + (n - 2 * k) * I);
    size_t ki = size_t(k), ni = x.size();
    if (ki < 1 || ki >= ni) {
      ctx.fail("too few values for this alpha");
      return Value(0.0);
    }
    return makeDict({{"low", Value(lam * x[ki] + (1 - lam) * x[ki - 1])}, {"high", Value(lam * x[ni - ki - 1] + (1 - lam) * x[ni - ki])}});
  } SP_END

  SP_ADD("rsh", 1, 2, "data, points") {
    Vec x, p;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (a.size() > 1) {
      if (!getVec(a, 1, ctx, p))
        return Value(0.0);
    } else
      p = x;
    double q1, q3;
    if (!idealFourths(x, q1, q3)) {
      ctx.fail("needs at least 3 values");
      return Value(0.0);
    }
    double n = valid(x).size(), h = 1.2 * (q3 - q1) / std::pow(n, 0.2);
    Vec out(p.size());
    for (size_t i = 0; i < p.size(); i++) {
      double hi = 0, lo = 0;
      for (double v : x) {
        hi += v <= p[i] + h;
        lo += v < p[i] - h;
      }
      out[i] = (hi - lo) / (2 * n * h);
    }
    return toValue(out);
  } SP_END

  SP_ADD("plotting_positions", 1, 3, "data, alpha, beta") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    double al = optNum(a, 1, 0.4), be = optNum(a, 2, 0.4);
    std::vector<size_t> idx = argsortValid(x);
    double n = idx.size();
    Vec out(x.size(), kNaN);
    for (size_t k = 0; k < idx.size(); k++)
      out[idx[k]] = (k + 1 - al) / (n + 1 - al - be);
    return toValue(out);
  } SP_END

  SP_ADD("compare_medians", 2, 2, "a, b") {
    Vec x, y;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y))
      return Value(0.0);
    double s1 = stdeMedian(x), s2 = stdeMedian(y);
    double W = std::fabs(median(valid(x)) - median(valid(y))) / std::sqrt(s1 * s1 + s2 * s2);
    return Value(1 - sf::ndtr(W));
  } SP_END

  SP_ADD("kendalltau_seasonal", 1, 1, "data") {
    Mat x;
    if (!getMat(a, 0, ctx, x))
      return Value(0.0);
    if (!a[0].isMatrix) { // one season
      Vec v = x.a;
      x = Mat(v.size(), 1);
      x.a = v;
    }
    size_t n = x.r, m = x.c;
    Vec np(m, 0.0), S(m, 0.0), all;
    std::vector<Vec> cols(m);
    for (size_t j = 0; j < m; j++) {
      for (size_t i = 0; i < n; i++) {
        cols[j].push_back(x(i, j));
        if (!std::isnan(x(i, j))) {
          np[j]++;
          all.push_back(x(i, j));
        }
      }
      for (size_t i = 0; i < n; i++)
        for (size_t r = i; r < n; r++)
          if (!std::isnan(x(r, j)) && !std::isnan(x(i, j)))
            S[j] += msign(x(r, j) - x(i, j));
    }
    double Stot = 0;
    for (double s : S)
      Stot += s;
    double nt = all.size();
    double denomTot = std::sqrt(nt * (nt - 1) * (nt * (nt - 1) - tieCorr(all))) / 2;
    // ranks per column; a missing value gets the middle rank
    Mat R(n, m);
    for (size_t j = 0; j < m; j++) {
      Vec v = valid(cols[j]), rv = rankdata(v);
      size_t k = 0;
      for (size_t i = 0; i < n; i++)
        R(i, j) = std::isnan(x(i, j)) ? (np[j] + 1) / 2 : rv[k++];
    }
    Mat cov(m, m);
    Vec den(m);
    for (size_t j = 0; j < m; j++) {
      double cmb = np[j] * (np[j] - 1);
      for (size_t k = j; k < m; k++) {
        double K = 0, rr = 0;
        for (size_t i = 0; i < n; i++) {
          for (size_t r = i; r < n; r++) {
            double d = (x(r, j) - x(i, j)) * (x(r, k) - x(i, k));
            if (!std::isnan(d))
              K += msign(d);
          }
          rr += R(i, j) * R(i, k);
        }
        cov(j, k) = cov(k, j) = (K + 4 * rr - n * (np[j] + 1) * (np[k] + 1)) / 3.0;
      }
      den[j] = std::sqrt(cmb * (cmb - tieCorr(cols[j]))) / 2;
    }
    Vec z(m), tau(m), pz(m);
    double vsum = 0, csum = 0, dsum = 0, chi = 0, zs = 0;
    for (size_t j = 0; j < m; j++) {
      z[j] = msign(S[j]) * (std::fabs(S[j]) - 1) / std::sqrt(cov(j, j));
      tau[j] = S[j] / den[j];
      pz[j] = std::erfc(std::fabs(z[j]) / std::sqrt(2.0));
      vsum += cov(j, j);
      dsum += den[j];
      chi += z[j] * z[j];
      zs += z[j];
      for (size_t k = 0; k < m; k++)
        csum += cov(j, k);
    }
    double zi = msign(Stot) * (std::fabs(Stot) - 1) / std::sqrt(vsum), zd = msign(Stot) * (std::fabs(Stot) - 1) / std::sqrt(csum);
    return makeDict({{"seasonal_tau", toValue(tau)},
                     {"global_tau", Value(Stot / denomTot)},
                     {"global_tau_alt", Value(Stot / dsum)},
                     {"seasonal_pvalue", toValue(pz)},
                     {"global_pvalue_indep", Value(std::erfc(std::fabs(zi) / std::sqrt(2.0)))},
                     {"global_pvalue_dep", Value(std::erfc(std::fabs(zd) / std::sqrt(2.0)))},
                     {"chi2_total", Value(chi)},
                     {"chi2_trend", Value(m * std::pow(zs / m, 2))}});
  } SP_END

  SP_ADD("sen_seasonal_slopes", 1, 1, "data") {
    Mat x;
    if (!getMat(a, 0, ctx, x))
      return Value(0.0);
    if (!a[0].isMatrix) {
      Vec v = x.a;
      x = Mat(v.size(), 1);
      x.a = v;
    }
    std::vector<Vec> sl(x.c);
    Vec all;
    for (size_t j = 0; j < x.c; j++)
      for (size_t i = 0; i < x.r; i++)
        for (size_t r = i + 1; r < x.r; r++) {
          double s = (x(r, j) - x(i, j)) / double(r - i);
          if (!std::isnan(s)) {
            sl[j].push_back(s);
            all.push_back(s);
          }
        }
    Vec intra(x.c);
    for (size_t j = 0; j < x.c; j++)
      intra[j] = median(sl[j]);
    return makeDict({{"intra_slope", toValue(intra)}, {"inter_slope", Value(median(all))}});
  } SP_END

  SP_ADD("nan_ttest_1samp", 2, 3, "data, popmean, alternative") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    Args in = {toValue(valid(x)), a[1]};
    if (a.size() > 2)
      in.push_back(a[2]);
    Value r;
    if (!callAfterDrop("ttest_1samp", in, r, ctx))
      return Value(0.0);
    return r;
  } SP_END

  SP_ADD("nan_ks_2samp", 2, 3, "a, b, alternative") {
    Vec x, y;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y))
      return Value(0.0);
    Args in = {toValue(valid(x)), toValue(valid(y))};
    if (a.size() > 2)
      in.push_back(a[2]);
    Value r;
    if (!callAfterDrop("ks_2samp", in, r, ctx))
      return Value(0.0);
    return r;
  } SP_END

  SP_ADD("nan_kruskal", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g)) // drops the NaN values
      return Value(0.0);
    Args in;
    for (const Vec &v : g)
      in.push_back(toValue(v));
    Value r;
    if (!callAfterDrop("kruskal", in, r, ctx))
      return Value(0.0);
    return r;
  } SP_END
}

} // namespace scipy
} // namespace nc
