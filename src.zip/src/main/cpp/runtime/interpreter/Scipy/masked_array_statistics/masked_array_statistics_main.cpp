// Section 23 of 25 - Masked-Array Statistics
// SciPy module: scipy.stats.mstats
// Planned entries: 73
//
// This file is the ONE place where this section's entries are mapped to NC
// names. Nothing outside this folder needs to change when you add one.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        masked_array_statistics/mas_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerMaskedArrayStatistics() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Scipy/scipy_sources.cmake globs the whole Scipy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 25 sections.
//   - A name already used by an NC builtin (ops/), by a NumPy function
//     (Numpy/), by an NC keyword or a parser-reserved call is skipped: the
//     existing one stays. The reason is printed at startup.
#include "masked_array_statistics_main.h"

#include "../scipy_core.h"

namespace nc {
namespace scipy {

void registerMaStats(Registry &reg);

void registerMaskedArrayStatistics(Registry &reg) {
  registerMaStats(reg);
  reg.setParallel({"nan_ttest_1samp", "nan_ks_2samp", "nan_kruskal"}, ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
