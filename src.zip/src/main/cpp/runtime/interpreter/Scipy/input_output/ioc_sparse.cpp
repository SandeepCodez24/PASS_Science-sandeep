// Sparse matrix text formats: Matrix Market (mm_*) and Harwell-Boeing (hb_*).
#include <cstdio>
#include <functional>
#include <sstream>

#include "../../Numpy/importing_data/io_common.h"
#include "../scipy_core.h"
#include "../sparse_matrices/sp_core.h"
#include "input_output_main.h"

#define SP_SEC Section::InputOutput

namespace nc {
namespace scipy {

namespace {

std::string lowerOf(std::string s) {
  for (char &c : s)
    c = (char)std::tolower((unsigned char)c);
  return s;
}

std::string withMtx(const std::string &p) {
  const size_t slash = p.find_last_of("/\\"), dot = p.find_last_of('.');
  if (dot == std::string::npos || (slash != std::string::npos && dot < slash))
    return p + ".mtx";
  return p;
}

struct MmHead {
  std::string format, field, symmetry;
  size_t rows = 0, cols = 0, entries = 0;
};

// Leaves `in` at the first data line.
bool readMmHead(std::istringstream &in, MmHead &h, std::string &err) {
  std::string line;
  if (!std::getline(in, line) || lowerOf(line).rfind("%%matrixmarket", 0) != 0) {
    err = "this is not a Matrix Market file";
    return false;
  }
  std::istringstream hs(line);
  std::string a, obj;
  hs >> a >> obj >> h.format >> h.field >> h.symmetry;
  h.format = lowerOf(h.format);
  h.field = lowerOf(h.field);
  h.symmetry = lowerOf(h.symmetry);
  if (lowerOf(obj) != "matrix" || (h.format != "coordinate" && h.format != "array")) {
    err = "only matrices in coordinate or array form are supported";
    return false;
  }
  if (h.field != "real" && h.field != "double" && h.field != "integer" && h.field != "unsigned-integer" && h.field != "complex" && h.field != "pattern") {
    err = "this Matrix Market field is not known: " + h.field;
    return false;
  }
  if (h.symmetry != "general" && h.symmetry != "symmetric" && h.symmetry != "skew-symmetric" && h.symmetry != "hermitian") {
    err = "this Matrix Market symmetry is not known: " + h.symmetry;
    return false;
  }
  while (std::getline(in, line)) {
    size_t i = 0;
    while (i < line.size() && std::isspace((unsigned char)line[i]))
      i++;
    if (i == line.size() || line[i] == '%')
      continue;
    std::istringstream ss(line);
    if (h.format == "coordinate") {
      if (!(ss >> h.rows >> h.cols >> h.entries)) {
        err = "the size line of this file is damaged";
        return false;
      }
    } else {
      if (!(ss >> h.rows >> h.cols)) {
        err = "the size line of this file is damaged";
        return false;
      }
      const bool full = h.symmetry == "general";
      h.entries = full ? h.rows * h.cols : (h.symmetry == "skew-symmetric" ? h.rows * (h.rows - 1) / 2 : h.rows * (h.rows + 1) / 2);
    }
    return true;
  }
  err = "this file has no size line";
  return false;
}

bool readMmFile(const Args &a, CallContext &ctx, std::string &s, std::istringstream &in, MmHead &h) {
  if (a.empty() || !a[0].isText) {
    ctx.fail("the first argument must be a file path");
    return false;
  }
  std::string err;
  const std::string path = a[0].text();
  if (!io::readFile(io::fileExists(path) ? path : withMtx(path), s, err)) {
    ctx.fail(err);
    return false;
  }
  in.str(s);
  if (!readMmHead(in, h, err)) {
    ctx.fail(err);
    return false;
  }
  return true;
}

// ---- Harwell-Boeing ----
struct FortranFormat {
  size_t repeat = 1, width = 0;
};

// "(10I8)", "(3E25.16)", "(1P,3E25.16)", "(1P3E25.16)".
bool parseFormat(std::string f, FortranFormat &o) {
  f = lowerOf(f);
  std::string clean;
  for (char c : f)
    if (!std::isspace((unsigned char)c) && c != '(' && c != ')')
      clean.push_back(c);
  const size_t pp = clean.find('p');
  if (pp != std::string::npos) {
    clean = clean.substr(pp + 1);
    if (!clean.empty() && clean[0] == ',')
      clean = clean.substr(1);
  }
  size_t i = 0, rep = 0;
  while (i < clean.size() && std::isdigit((unsigned char)clean[i]))
    rep = rep * 10 + (size_t)(clean[i++] - '0');
  if (i >= clean.size() || std::string("iefdg").find(clean[i]) == std::string::npos)
    return false;
  i++;
  size_t w = 0;
  while (i < clean.size() && std::isdigit((unsigned char)clean[i]))
    w = w * 10 + (size_t)(clean[i++] - '0');
  if (!w)
    return false;
  o.repeat = rep ? rep : 1;
  o.width = w;
  return true;
}

bool readFields(std::istringstream &in, const FortranFormat &f, size_t count, Vec &out) {
  out.clear();
  std::string line;
  while (out.size() < count) {
    if (!std::getline(in, line))
      return false;
    while (!line.empty() && (line.back() == '\r' || line.back() == '\n'))
      line.pop_back();
    for (size_t k = 0; k < f.repeat && out.size() < count; k++) {
      const size_t at = k * f.width;
      if (at >= line.size())
        break;
      std::string cell = line.substr(at, f.width);
      for (char &c : cell)
        if (c == 'D' || c == 'd')
          c = 'E';
      out.push_back(std::strtod(cell.c_str(), nullptr));
    }
  }
  return true;
}

template <class T> void writeFields(std::string &o, const std::vector<T> &v, size_t perLine, const std::function<std::string(const T &)> &cell) {
  for (size_t i = 0; i < v.size(); i++) {
    o += cell(v[i]);
    if ((i + 1) % perLine == 0 || i + 1 == v.size())
      o += "\n";
  }
}

size_t linesFor(size_t n, size_t perLine) { return n ? (n + perLine - 1) / perLine : 0; }

} // namespace

void registerIoSparse(Registry &reg) {
  SP_ADD("mm_info", 1, 1, "file") {
    std::string s;
    std::istringstream in;
    MmHead h;
    if (!readMmFile(a, ctx, s, in, h))
      return Value(0.0);
    return makeDict({{"rows", Value((double)h.rows)}, {"cols", Value((double)h.cols)}, {"entries", Value((double)h.entries)},
                     {"format", Value(h.format)}, {"field", Value(h.field)}, {"symmetry", Value(h.symmetry)}});
  } SP_END
  SP_ADD("mm_read", 1, 1, "file") {
    std::string s;
    std::istringstream in;
    MmHead h;
    if (!readMmFile(a, ctx, s, in, h))
      return Value(0.0);
    const bool cplx = h.field == "complex", pattern = h.field == "pattern";
    const double sign = h.symmetry == "skew-symmetric" ? -1.0 : 1.0;
    const bool mirror = h.symmetry != "general", herm = h.symmetry == "hermitian";
    if (h.format == "array") {
      CMat M(h.rows, h.cols);
      for (size_t j = 0; j < h.cols; j++)
        for (size_t i = mirror ? j + (h.symmetry == "skew-symmetric" ? 1 : 0) : 0; i < h.rows; i++) {
          double re, im = 0.0;
          if (!(in >> re) || (cplx && !(in >> im))) {
            ctx.fail("this Matrix Market file has too few values");
            return Value(0.0);
          }
          M(i, j) = cd(re, im);
          if (mirror && i != j)
            M(j, i) = herm ? cd(re, -im) : cd(sign * re, sign * im);
        }
      return realIfPossible(M);
    }
    std::vector<sp::Triplet> t;
    CMat dense;
    if (cplx)
      dense = CMat(h.rows, h.cols);
    for (size_t e = 0; e < h.entries; e++) {
      size_t i, j;
      double re = 1.0, im = 0.0;
      if (!(in >> i >> j) || (!pattern && !(in >> re)) || (cplx && !(in >> im))) {
        ctx.fail("this Matrix Market file has too few entries");
        return Value(0.0);
      }
      if (i < 1 || j < 1 || i > h.rows || j > h.cols) {
        ctx.fail("an entry of this file lies outside the matrix");
        return Value(0.0);
      }
      i--;
      j--;
      if (cplx) {
        dense(i, j) += cd(re, im);
        if (mirror && i != j)
          dense(j, i) += herm ? cd(re, -im) : cd(sign * re, sign * im);
      } else {
        t.push_back({i, j, re});
        if (mirror && i != j)
          t.push_back({j, i, sign * re});
      }
    }
    if (cplx)
      return toValue(dense); // Sparse holds real numbers only
    return sp::toValue(sp::fromTriplets(h.rows, h.cols, std::move(t), "coo", true));
  } SP_END
  SP_ADD("mm_write", 2, 4, "file, A, comment, precision=17") {
    if (!a[0].isText) {
      ctx.fail("the first argument must be a file path");
      return Value(0.0);
    }
    const std::string path = withMtx(a[0].text());
    std::ostringstream o;
    const std::string comment = optText(a, 2, "");
    const int prec = isOmitted(a, 3) ? 17 : (int)optInt(a, 3, 17);
    auto fmt = [&](double v) {
      char buf[64];
      std::snprintf(buf, sizeof buf, "%.*g", prec, v);
      return std::string(buf);
    };
    auto header = [&](const char *form, const char *field, const char *sym) {
      o << "%%MatrixMarket matrix " << form << " " << field << " " << sym << "\n";
      if (!comment.empty()) {
        std::istringstream cs(comment);
        std::string l;
        while (std::getline(cs, l))
          o << "%" << l << "\n";
      }
    };
    std::string err;
    if (sp::isSparse(a[1])) {
      sp::Sparse S;
      if (!sp::fromValue(a[1], S)) {
        ctx.fail("this sparse matrix could not be read");
        return Value(0.0);
      }
      bool sym = S.r == S.c, skew = S.r == S.c;
      const sp::Sparse T = sp::transpose(S);
      if (sym || skew) {
        const Mat D = S.nnz() * 4 < 4000000 ? sp::toDense(S) : Mat();
        if (D.a.empty() && S.r) {
          sym = skew = false;
        } else {
          const Mat Dt = sp::toDense(T);
          for (size_t i = 0; i < D.a.size(); i++) {
            sym = sym && D.a[i] == Dt.a[i];
            skew = skew && D.a[i] == -Dt.a[i];
          }
        }
      }
      if (S.nnz() == 0)
        skew = false;
      header("coordinate", "real", sym ? "symmetric" : (skew ? "skew-symmetric" : "general"));
      size_t count = 0;
      for (size_t i = 0; i < S.r; i++)
        for (size_t k = S.ptr[i]; k < S.ptr[i + 1]; k++)
          if (!(sym || skew) || S.idx[k] < i || (sym && S.idx[k] == i))
            count++;
      o << S.r << " " << S.c << " " << count << "\n";
      for (size_t i = 0; i < S.r; i++)
        for (size_t k = S.ptr[i]; k < S.ptr[i + 1]; k++)
          if (!(sym || skew) || S.idx[k] < i || (sym && S.idx[k] == i))
            o << i + 1 << " " << S.idx[k] + 1 << " " << fmt(S.val[k]) << "\n";
    } else {
      CMat M;
      if (!getCMat(a, 1, ctx, M))
        return Value(0.0);
      bool real = true;
      for (const cd &z : M.a)
        real = real && z.imag() == 0.0;
      bool sym = M.r == M.c, skew = M.r == M.c, herm = M.r == M.c && !real;
      for (size_t i = 0; i < M.r; i++)
        for (size_t j = 0; j < M.c && (sym || skew || herm); j++) {
          sym = sym && M(i, j) == M(j, i);
          skew = skew && M(i, j) == -M(j, i);
          herm = herm && M(i, j) == std::conj(M(j, i));
        }
      const char *symName = sym ? "symmetric" : (skew ? "skew-symmetric" : (herm ? "hermitian" : "general"));
      header("array", real ? "real" : "complex", symName);
      o << M.r << " " << M.c << "\n";
      for (size_t j = 0; j < M.c; j++)
        for (size_t i = (sym || herm) ? j : (skew ? j + 1 : 0); i < M.r; i++) {
          o << fmt(M(i, j).real());
          if (!real)
            o << " " << fmt(M(i, j).imag());
          o << "\n";
        }
    }
    if (!io::writeFile(path, o.str(), false, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return Value();
  } SP_ENDC
  SP_ADD("hb_write", 2, 3, "file, A, title") {
    if (!a[0].isText) {
      ctx.fail("the first argument must be a file path");
      return Value(0.0);
    }
    sp::Sparse S;
    if (!sp::getAny(a, 1, ctx, S))
      return Value(0.0);
    // Column storage: the transpose's compressed rows.
    const sp::Sparse T = sp::transpose(S);
    const size_t nnz = T.nnz();
    std::vector<size_t> ptr(T.ptr), idx(T.idx);
    auto digits = [](size_t v) {
      size_t d = 1;
      while (v >= 10) {
        v /= 10;
        d++;
      }
      return d;
    };
    const size_t wp = digits(nnz + 1) + 1, wi = digits(S.r + 1) + 1;
    const size_t np = std::max<size_t>(1, 80 / wp), ni = std::max<size_t>(1, 80 / wi), nv = 3;
    const size_t lp = linesFor(ptr.size(), np), li = linesFor(idx.size(), ni), lv = linesFor(T.val.size(), nv);
    char buf[256];
    std::string o;
    std::string title = optText(a, 2, "Default title");
    std::snprintf(buf, sizeof buf, "%-72.72s%-8.8s\n", title.c_str(), "0");
    o += buf;
    std::snprintf(buf, sizeof buf, "%14zu%14zu%14zu%14zu%14d\n", lp + li + lv, lp, li, lv, 0);
    o += buf;
    std::snprintf(buf, sizeof buf, "%-3s%11s%14zu%14zu%14zu%14d\n", "RUA", "", S.r, S.c, nnz, 0);
    o += buf;
    const std::string fp = "(" + std::to_string(np) + "I" + std::to_string(wp) + ")", fi = "(" + std::to_string(ni) + "I" + std::to_string(wi) + ")";
    std::snprintf(buf, sizeof buf, "%-16s%-16s%-20s\n", fp.c_str(), fi.c_str(), "(3E25.16)");
    o += buf;
    const std::function<std::string(const size_t &)> ip = [&](const size_t &v) {
      char b[32];
      std::snprintf(b, sizeof b, "%*zu", (int)wp, v + 1);
      return std::string(b);
    };
    const std::function<std::string(const size_t &)> ii = [&](const size_t &v) {
      char b[32];
      std::snprintf(b, sizeof b, "%*zu", (int)wi, v + 1);
      return std::string(b);
    };
    const std::function<std::string(const double &)> iv = [](const double &v) {
      char b[48];
      std::snprintf(b, sizeof b, "%25.16E", v);
      return std::string(b);
    };
    writeFields<size_t>(o, ptr, np, ip);
    writeFields<size_t>(o, idx, ni, ii);
    writeFields<double>(o, T.val, nv, iv);
    std::string err;
    if (!io::writeFile(a[0].text(), o, false, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return Value();
  } SP_END
  SP_ADD("hb_read", 1, 1, "file") {
    if (!a[0].isText) {
      ctx.fail("the first argument must be a file path");
      return Value(0.0);
    }
    std::string s, err;
    if (!io::readFile(a[0].text(), s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    std::istringstream in(s);
    std::string l1, l2, l3, l4;
    if (!std::getline(in, l1) || !std::getline(in, l2) || !std::getline(in, l3) || !std::getline(in, l4)) {
      ctx.fail("this Harwell-Boeing header is cut short");
      return Value(0.0);
    }
    std::istringstream h2(l2);
    size_t tot, ptrc, indc, valc, rhsc = 0;
    if (!(h2 >> tot >> ptrc >> indc >> valc)) {
      ctx.fail("this Harwell-Boeing header is damaged");
      return Value(0.0);
    }
    h2 >> rhsc;
    const std::string mx = lowerOf(l3.substr(0, 3));
    if (mx.size() != 3 || mx[0] != 'r' || (mx[1] != 'u' && mx[1] != 's') || mx[2] != 'a') {
      ctx.fail("only real assembled matrices (RUA, RSA) can be read, not " + mx);
      return Value(0.0);
    }
    std::istringstream h3(l3.substr(3));
    size_t rows, cols, nnz;
    if (!(h3 >> rows >> cols >> nnz)) {
      ctx.fail("this Harwell-Boeing header is damaged");
      return Value(0.0);
    }
    FortranFormat fp, fi, fv;
    if (l4.size() < 32 || !parseFormat(l4.substr(0, 16), fp) || !parseFormat(l4.substr(16, 16), fi) || !parseFormat(l4.substr(32, 20), fv)) {
      ctx.fail("the Fortran formats of this file could not be read");
      return Value(0.0);
    }
    if (rhsc > 0) {
      std::string skip;
      std::getline(in, skip);
    }
    Vec ptr, idx, val;
    if (!readFields(in, fp, cols + 1, ptr) || !readFields(in, fi, nnz, idx) || !readFields(in, fv, nnz, val)) {
      ctx.fail("this Harwell-Boeing file is cut short");
      return Value(0.0);
    }
    std::vector<sp::Triplet> t;
    for (size_t c = 0; c < cols; c++)
      for (size_t k = (size_t)ptr[c] - 1; k + 1 < (size_t)ptr[c + 1]; k++) {
        const size_t r = (size_t)idx[k] - 1;
        if (r >= rows) {
          ctx.fail("an entry of this file lies outside the matrix");
          return Value(0.0);
        }
        t.push_back({r, c, val[k]});
        if (mx[1] == 's' && r != c)
          t.push_back({c, r, val[k]});
      }
    return sp::toValue(sp::fromTriplets(rows, cols, std::move(t), "csc", true));
  } SP_END
}

} // namespace scipy
} // namespace nc
