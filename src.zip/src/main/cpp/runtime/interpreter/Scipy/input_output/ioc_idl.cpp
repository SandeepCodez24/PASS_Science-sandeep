// IDL SAVE files (read_idl). Numbers are big-endian XDR. Pointers are followed through
// the heap records; a structure becomes a Dict of its tags.
#include <cstdint>
#include <cstring>
#include <map>
#include <memory>

#include "../../Numpy/importing_data/io_common.h"
#include "../../Numpy/importing_data/io_deflate.h"
#include "../scipy_core.h"
#include "input_output_main.h"

#define SP_SEC Section::InputOutput

namespace nc {
namespace scipy {

namespace {

struct IdlError {
  std::string text;
};

struct ArrayDesc {
  uint64_t nbytes = 0, nelements = 0;
  int ndims = 0;
  std::vector<long> dims;
};
struct StructDesc;
struct Tag {
  std::string name;
  int type = 0;
  bool array = false, structure = false;
};
struct StructDesc {
  std::string name;
  std::vector<Tag> tags;
  std::map<std::string, ArrayDesc> arrays;
  std::map<std::string, std::shared_ptr<StructDesc>> structs;
};
struct TypeDesc {
  int type = 0;
  bool array = false, structure = false;
  ArrayDesc arr;
  std::shared_ptr<StructDesc> st;
};

struct Reader {
  std::string s;
  size_t p = 0;
  std::map<std::string, std::shared_ptr<StructDesc>> known;
  std::map<int, size_t> heapAt;
  int depth = 0;

  void need(size_t n) {
    if (p + n > s.size())
      throw IdlError{"this IDL file is cut short"};
  }
  template <class T> T big() {
    need(sizeof(T));
    unsigned char b[sizeof(T)];
    for (size_t i = 0; i < sizeof(T); i++)
      b[sizeof(T) - 1 - i] = (unsigned char)s[p + i];
    const uint16_t probe = 1;
    if (*reinterpret_cast<const unsigned char *>(&probe) != 1)
      std::reverse(b, b + sizeof(T));
    p += sizeof(T);
    T v;
    std::memcpy(&v, b, sizeof(T));
    return v;
  }
  int32_t i32() { return big<int32_t>(); }
  void align() {
    if (p % 4)
      p += 4 - p % 4;
  }
  std::string text() {
    const int32_t n = i32();
    if (n <= 0)
      return "";
    need((size_t)n);
    std::string t = s.substr(p, (size_t)n);
    p += (size_t)n;
    align();
    return t;
  }
  std::string stringData() {
    const int32_t n = i32();
    if (n <= 0)
      return "";
    const int32_t m = i32();
    need((size_t)m);
    std::string t = s.substr(p, (size_t)m);
    p += (size_t)m;
    align();
    return t;
  }
  ArrayDesc arrayDesc() {
    ArrayDesc d;
    const int32_t start = i32();
    if (start == 8) {
      p += 4;
      d.nbytes = (uint64_t)i32();
      d.nelements = (uint64_t)i32();
      d.ndims = i32();
      p += 8;
      const int32_t nmax = i32();
      for (int32_t i = 0; i < nmax; i++)
        d.dims.push_back(i32());
    } else if (start == 18) {
      p += 8;
      d.nbytes = big<uint64_t>();
      d.nelements = big<uint64_t>();
      d.ndims = i32();
      p += 8;
      for (int i = 0; i < 8; i++) {
        i32();
        d.dims.push_back(i32());
      }
    } else {
      throw IdlError{"this IDL array description is not known"};
    }
    return d;
  }
  std::shared_ptr<StructDesc> structDesc() {
    if (i32() != 9)
      throw IdlError{"this IDL structure description is damaged"};
    auto d = std::make_shared<StructDesc>();
    d->name = text();
    const int32_t predef = i32();
    const int32_t ntags = i32();
    i32();
    if (predef & 1) {
      auto it = known.find(d->name);
      if (it == known.end())
        throw IdlError{"this file refers to an undefined IDL structure"};
      return it->second;
    }
    for (int32_t i = 0; i < ntags; i++) {
      Tag t;
      const int32_t off = i32();
      if (off == -1)
        p += 8;
      t.type = i32();
      const int32_t fl = i32();
      t.array = (fl & 4) != 0;
      t.structure = (fl & 32) != 0;
      d->tags.push_back(t);
    }
    for (Tag &t : d->tags)
      t.name = text();
    for (const Tag &t : d->tags)
      if (t.array)
        d->arrays[t.name] = arrayDesc();
    for (const Tag &t : d->tags)
      if (t.structure)
        d->structs[t.name] = structDesc();
    if (predef & 6) {
      text();
      const int32_t ns = i32();
      for (int32_t i = 0; i < ns; i++)
        text();
      for (int32_t i = 0; i < ns; i++)
        structDesc();
    }
    known[d->name] = d;
    return d;
  }
  TypeDesc typeDesc() {
    TypeDesc t;
    t.type = i32();
    const int32_t fl = i32();
    if (fl & 2)
      throw IdlError{"system variables are not supported"};
    t.array = (fl & 4) != 0;
    t.structure = (fl & 32) != 0;
    if (t.structure) {
      t.arr = arrayDesc();
      t.st = structDesc();
    } else if (t.array) {
      t.arr = arrayDesc();
    }
    return t;
  }
  // Reads one cell; pointers come back resolved.
  Value cell(int type) {
    switch (type) {
    case 1: {
      if (i32() != 1)
        throw IdlError{"a byte variable is damaged"};
      need(4);
      const double v = (unsigned char)s[p];
      p += 4;
      return Value(v);
    }
    case 2: {
      need(4);
      p += 2;
      const int16_t v = big<int16_t>();
      return Value((double)v);
    }
    case 3:
      return Value((double)i32());
    case 4:
      return Value((double)big<float>());
    case 5:
      return Value(big<double>());
    case 6: {
      const float re = big<float>(), im = big<float>();
      return Value::complexNumber(re, im);
    }
    case 7:
      return Value(stringData());
    case 9: {
      const double re = big<double>(), im = big<double>();
      return Value::complexNumber(re, im);
    }
    case 10:
    case 11:
      return heapValue(i32());
    case 12: {
      need(4);
      p += 2;
      const uint16_t v = big<uint16_t>();
      return Value((double)v);
    }
    case 13:
      return Value((double)big<uint32_t>());
    case 14:
      return Value((double)big<int64_t>());
    case 15:
      return Value((double)big<uint64_t>());
    default:
      throw IdlError{"unknown IDL type " + std::to_string(type)};
    }
  }
  Value shaped(std::vector<Value> cells, const ArrayDesc &d) {
    bool numeric = true, cplx = false;
    for (const Value &c : cells) {
      numeric = numeric && isPlainNumber(c);
      cplx = cplx || c.isComplex;
    }
    std::vector<size_t> shape;
    if (d.ndims > 1)
      for (int i = d.ndims - 1; i >= 0; i--)
        shape.push_back((size_t)d.dims[(size_t)i]);
    if (shape.size() == 2 || (shape.empty() && !numeric)) {
      const size_t R = shape.empty() ? 1 : shape[0], C = shape.empty() ? cells.size() : shape[1];
      std::vector<std::vector<Value>> rows(R, std::vector<Value>(C));
      for (size_t i = 0; i < R; i++)
        for (size_t j = 0; j < C; j++)
          rows[i][j] = cells[i * C + j];
      if (!numeric) {
        // Text and dicts: a Dict by index when a matrix cannot hold them.
        bool text = true;
        for (const Value &c : cells)
          text = text && c.isText;
        if (!text) {
          DictInit e;
          for (size_t i = 0; i < cells.size(); i++)
            e.push_back({std::to_string(i), cells[i]});
          return makeDict(e);
        }
      }
      return Value(std::move(rows));
    }
    if (shape.size() > 2) {
      if (!numeric || cplx)
        throw IdlError{"arrays of more than two dimensions must hold real numbers"};
      Vec f;
      for (const Value &c : cells)
        f.push_back(c.number);
      return io::ndFromRowMajor(shape, f);
    }
    std::vector<Value> row(std::move(cells));
    return Value(std::vector<std::vector<Value>>{std::move(row)});
  }
  Value array(int type, const ArrayDesc &d) {
    std::vector<Value> cells;
    cells.reserve((size_t)d.nelements);
    if (type == 1) {
      i32();
      need((size_t)d.nbytes);
      for (uint64_t i = 0; i < d.nbytes; i++)
        cells.push_back(Value((double)(unsigned char)s[p + (size_t)i]));
      p += (size_t)d.nbytes;
    } else if (type == 2 || type == 12) {
      for (uint64_t i = 0; i < d.nelements; i++) {
        need(4);
        p += 2;
        cells.push_back(Value(type == 2 ? (double)big<int16_t>() : (double)big<uint16_t>()));
      }
    } else if (type == 3 || type == 4 || type == 5 || type == 6 || type == 9 || type == 13 || type == 14 || type == 15 || type == 7 || type == 10 || type == 11) {
      for (uint64_t i = 0; i < d.nelements; i++)
        cells.push_back(cell(type));
    } else {
      throw IdlError{"unknown IDL array type " + std::to_string(type)};
    }
    align();
    return shaped(std::move(cells), d);
  }
  Value structure(const ArrayDesc &d, const StructDesc &st) {
    std::vector<std::vector<Value>> cols(st.tags.size());
    for (uint64_t i = 0; i < d.nelements; i++)
      for (size_t t = 0; t < st.tags.size(); t++) {
        const Tag &tag = st.tags[t];
        if (tag.structure)
          cols[t].push_back(structure(st.arrays.at(tag.name), *st.structs.at(tag.name)));
        else if (tag.array)
          cols[t].push_back(array(tag.type, st.arrays.at(tag.name)));
        else
          cols[t].push_back(cell(tag.type));
      }
    DictInit out;
    for (size_t t = 0; t < st.tags.size(); t++) {
      std::string lower = st.tags[t].name;
      for (char &c : lower)
        c = (char)std::tolower((unsigned char)c);
      if (cols[t].size() == 1) {
        out.push_back({lower, cols[t][0]});
      } else {
        bool plain = true;
        for (const Value &v : cols[t])
          plain = plain && (isPlainNumber(v) || v.isText);
        if (plain) {
          ArrayDesc flat;
          flat.ndims = 1;
          flat.nelements = cols[t].size();
          out.push_back({lower, shaped(cols[t], flat)});
        } else {
          DictInit e;
          for (size_t i = 0; i < cols[t].size(); i++)
            e.push_back({std::to_string(i), cols[t][i]});
          out.push_back({lower, makeDict(e)});
        }
      }
    }
    return makeDict(out);
  }
  Value payload() {
    const TypeDesc t = typeDesc();
    if (t.type == 0)
      return Value(kNaN);
    if (i32() != 7)
      throw IdlError{"this IDL variable is damaged"};
    if (t.structure)
      return structure(t.arr, *t.st);
    if (t.array)
      return array(t.type, t.arr);
    return cell(t.type);
  }
  // A pointer: 0 is null; the target sits in a heap record read on demand.
  Value heapValue(int index) {
    if (index == 0)
      return Value(kNaN);
    auto it = heapAt.find(index);
    if (it == heapAt.end() || depth > 64)
      return Value(kNaN);
    const size_t back = p;
    p = it->second;
    depth++;
    Value v = payload();
    depth--;
    p = back;
    return v;
  }
};

// Compressed files: each record body is zlib data.
std::string expandRecords(const std::string &s) {
  std::string o = std::string("SR\x00\x04", 4);
  size_t p = 4;
  auto be32 = [&](size_t at) {
    return ((uint32_t)(unsigned char)s[at] << 24) | ((uint32_t)(unsigned char)s[at + 1] << 16) | ((uint32_t)(unsigned char)s[at + 2] << 8) | (unsigned char)s[at + 3];
  };
  auto put32 = [&](uint32_t v) {
    for (int i = 24; i >= 0; i -= 8)
      o.push_back((char)((v >> i) & 0xff));
  };
  while (true) {
    if (p + 16 > s.size())
      throw IdlError{"this compressed IDL file is cut short"};
    const uint32_t type = be32(p);
    const uint64_t next = (uint64_t)be32(p + 4) + ((uint64_t)be32(p + 8) << 32);
    put32(type);
    if (type == 6) {
      put32((uint32_t)(o.size() + 12));
      put32(0);
      o.append(s, p + 12, 4);
      return o;
    }
    if (next < p + 16 || next > s.size())
      throw IdlError{"this compressed IDL file is damaged"};
    std::string body, err;
    if (!io::zlibDecompress(s.substr(p + 16, (size_t)next - p - 16), body, err))
      throw IdlError{"this compressed IDL file is damaged: " + err};
    const uint64_t newNext = o.size() + 12 + body.size();
    put32((uint32_t)(newNext & 0xffffffffULL));
    put32((uint32_t)(newNext >> 32));
    o.append(s, p + 12, 4);
    o += body;
    p = (size_t)next;
  }
}

} // namespace

void registerIoIdl(Registry &reg) {
  SP_ADD("read_idl", 1, 1, "file") {
    if (!a[0].isText) {
      ctx.fail("the first argument must be a file path");
      return Value(0.0);
    }
    std::string bytes, err;
    if (!io::readFile(a[0].text(), bytes, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (bytes.size() < 4 || bytes.compare(0, 2, "SR") != 0) {
      ctx.fail("this is not an IDL SAVE file");
      return Value(0.0);
    }
    try {
      Reader r;
      if (bytes[3] == 6)
        r.s = expandRecords(bytes);
      else if (bytes[3] == 4)
        r.s = std::move(bytes);
      else
        throw IdlError{"this IDL record format is not known"};
      // First pass: where each record starts, and the heap entries.
      std::vector<std::pair<int, size_t>> records;
      r.p = 4;
      while (true) {
        const int type = r.i32();
        const uint32_t lo = r.big<uint32_t>(), hi = r.big<uint32_t>();
        const uint64_t next = (uint64_t)lo + ((uint64_t)hi << 32);
        r.p += 4;
        records.push_back({type, r.p});
        if (type == 6)
          break;
        if (type == 16) {
          const int idx = r.i32();
          r.p += 4;
          r.heapAt[idx] = r.p;
        }
        if (next <= r.p - 16 || next > r.s.size())
          throw IdlError{"this IDL file is damaged"};
        r.p = (size_t)next;
      }
      // Structure definitions may first appear in heap records: read those once too.
      for (const auto &e : records)
        if (e.first == 16) {
          r.p = e.second + 8;
          r.depth = 65; // pointers inside are resolved later, when a variable needs them
          r.payload();
          r.depth = 0;
        }
      DictInit out;
      for (const auto &e : records)
        if (e.first == 2) {
          r.p = e.second;
          std::string name = r.text();
          for (char &c : name)
            c = (char)std::tolower((unsigned char)c);
          out.push_back({name, r.payload()});
        }
      return makeDict(out);
    } catch (const IdlError &e) {
      ctx.fail(e.text);
      return Value(0.0);
    }
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
