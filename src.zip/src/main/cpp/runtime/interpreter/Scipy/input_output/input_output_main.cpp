// Section 9 of 25 - Input / Output (scipy.io). save_mat and load_mat exist in Numpy and
// stay there. MAT helpers, WAV, ARFF, NetCDF and Fortran files are here; IDL is in
// ioc_idl.cpp, Matrix Market and Harwell-Boeing in ioc_sparse.cpp.
#include "input_output_main.h"

#include <cstdint>
#include <cstring>
#include <map>
#include <sstream>

#include "../../Numpy/importing_data/io_common.h"
#include "../../Numpy/importing_data/io_mat.h"
#include "../scipy_core.h"

#define SP_SEC Section::InputOutput

namespace nc {
namespace scipy {

void registerIoIdl(Registry &reg);
void registerIoSparse(Registry &reg);

namespace {

bool getPath(const Args &a, size_t i, CallContext &ctx, std::string &p) {
  if (i >= a.size() || !a[i].isText) {
    ctx.fail("the " + ordinal(i) + " argument must be a file path");
    return false;
  }
  p = a[i].text();
  return true;
}

// ---- bytes ----
template <class T> void putLE(std::string &s, T v) {
  unsigned char b[sizeof(T)];
  std::memcpy(b, &v, sizeof(T));
  const uint16_t probe = 1;
  const bool little = *reinterpret_cast<const unsigned char *>(&probe) == 1;
  if (!little)
    std::reverse(b, b + sizeof(T));
  s.append(reinterpret_cast<const char *>(b), sizeof(T));
}
template <class T> T getBytes(const std::string &s, size_t at, bool bigEndian) {
  unsigned char b[sizeof(T)];
  std::memcpy(b, s.data() + at, sizeof(T));
  const uint16_t probe = 1;
  const bool little = *reinterpret_cast<const unsigned char *>(&probe) == 1;
  if (little == bigEndian)
    std::reverse(b, b + sizeof(T));
  T v;
  std::memcpy(&v, b, sizeof(T));
  return v;
}
template <class T> void putBE(std::string &s, T v) {
  std::string t;
  putLE(t, v);
  const uint16_t probe = 1;
  (void)probe;
  std::reverse(t.begin(), t.end());
  s += t;
}

// One channel per column; a line is one channel.
bool getChannels(const Value &v, Mat &m, CallContext &ctx) {
  if (!readMat(v, m)) {
    ctx.fail("the data must be an array or a matrix of numbers");
    return false;
  }
  if (m.r == 1 && m.c >= 1)
    m = transposeOf(m);
  return true;
}

// ---- WAV ----
struct WavFormat {
  int tag = 1, bits = 16;
};

bool chooseWav(const Mat &m, const std::string &name, WavFormat &f, CallContext &ctx) {
  if (name.empty()) {
    bool whole = true, in16 = true, in32 = true;
    for (double v : m.a) {
      whole = whole && v == std::floor(v);
      in16 = in16 && v >= -32768.0 && v <= 32767.0;
      in32 = in32 && v >= -2147483648.0 && v <= 2147483647.0;
    }
    if (whole && in16)
      f = {1, 16};
    else if (whole && in32)
      f = {1, 32};
    else
      f = {3, 64};
    return true;
  }
  if (name == "uint8")
    f = {1, 8};
  else if (name == "int16")
    f = {1, 16};
  else if (name == "int32")
    f = {1, 32};
  else if (name == "float32")
    f = {3, 32};
  else if (name == "float64")
    f = {3, 64};
  else {
    ctx.fail("format must be \"uint8\", \"int16\", \"int32\", \"float32\" or \"float64\"");
    return false;
  }
  return true;
}

// ---- NetCDF classic ----
struct CdfReader {
  const std::string &s;
  size_t p = 0;
  bool bad = false;
  explicit CdfReader(const std::string &in) : s(in) {}
  bool need(size_t n) {
    if (p + n > s.size()) {
      bad = true;
      return false;
    }
    return true;
  }
  int32_t i32() {
    if (!need(4))
      return 0;
    const int32_t v = getBytes<int32_t>(s, p, true);
    p += 4;
    return v;
  }
  std::string name() {
    const int32_t n = i32();
    if (n < 0 || !need((size_t)n)) {
      bad = true;
      return "";
    }
    std::string t = s.substr(p, (size_t)n);
    p += ((size_t)n + 3) / 4 * 4;
    return t;
  }
};

size_t cdfTypeSize(int t) { return t == 1 || t == 2 ? 1 : (t == 3 ? 2 : (t == 4 || t == 5 ? 4 : (t == 6 ? 8 : 0))); }

bool cdfSkipAtts(CdfReader &r) {
  const int32_t tag = r.i32(), n = r.i32();
  if (tag == 0)
    return !r.bad;
  if (tag != 12)
    return false;
  for (int32_t i = 0; i < n && !r.bad; i++) {
    r.name();
    const int t = r.i32();
    const int32_t cnt = r.i32();
    const size_t sz = cdfTypeSize(t);
    if (!sz || cnt < 0)
      return false;
    r.p += ((size_t)cnt * sz + 3) / 4 * 4;
  }
  return !r.bad;
}

double cdfValue(const std::string &s, size_t at, int t) {
  switch (t) {
  case 1:
    return (double)(signed char)s[at];
  case 3:
    return (double)getBytes<int16_t>(s, at, true);
  case 4:
    return (double)getBytes<int32_t>(s, at, true);
  case 5:
    return (double)getBytes<float>(s, at, true);
  default:
    return getBytes<double>(s, at, true);
  }
}

void putName(std::string &o, const std::string &n) {
  putBE<int32_t>(o, (int32_t)n.size());
  o += n;
  o.append((4 - n.size() % 4) % 4, '\0');
}

// ---- ARFF ----
std::string trimmed(const std::string &s) {
  size_t b = 0, e = s.size();
  while (b < e && std::isspace((unsigned char)s[b]))
    b++;
  while (e > b && std::isspace((unsigned char)s[e - 1]))
    e--;
  return s.substr(b, e - b);
}
std::string lowered(std::string s) {
  for (char &c : s)
    c = (char)std::tolower((unsigned char)c);
  return s;
}
std::string unquoted(const std::string &s) {
  if (s.size() >= 2 && (s[0] == '\'' || s[0] == '"') && s.back() == s[0])
    return s.substr(1, s.size() - 2);
  return s;
}
std::vector<std::string> splitCsv(const std::string &line) {
  std::vector<std::string> out;
  std::string cur;
  char q = 0;
  for (size_t i = 0; i < line.size(); i++) {
    const char c = line[i];
    if (q) {
      cur.push_back(c);
      if (c == q && (i == 0 || line[i - 1] != '\\'))
        q = 0;
    } else if (c == '\'' || c == '"') {
      q = c;
      cur.push_back(c);
    } else if (c == ',') {
      out.push_back(unquoted(trimmed(cur)));
      cur.clear();
    } else if (c == '%') {
      break;
    } else {
      cur.push_back(c);
    }
  }
  out.push_back(unquoted(trimmed(cur)));
  return out;
}

} // namespace

void registerInputOutput(Registry &reg) {
  // ---- MAT-file helpers ----
  SP_ADD("who_mat", 1, 1, "file") {
    std::string path, bytes, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    io::MatFile mf;
    if (!io::readFile(path, bytes, err) || !io::readMatV5(bytes, mf, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    std::vector<std::vector<Value>> rows;
    for (const io::MatNode &n : mf.vars) {
      std::string shape;
      for (size_t i = 0; i < n.dims.size(); i++)
        shape += (i ? "x" : "") + std::to_string(n.dims[i]);
      rows.push_back({Value(n.name), Value(shape), Value(io::matClassName(n))});
    }
    return Value(std::move(rows));
  } SP_END
  SP_ADD("mat_version", 1, 1, "file") {
    std::string path, bytes, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    if (!io::readFile(path, bytes, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (bytes.size() < 4) {
      ctx.fail("this file is too short to be a MAT file");
      return Value(0.0);
    }
    for (int i = 0; i < 4; i++)
      if (bytes[(size_t)i] == '\0')
        return toValue(Vec{0.0, 0.0});
    if (bytes.size() < 128) {
      ctx.fail("this file is too short to be a MAT file");
      return Value(0.0);
    }
    const int majInd = bytes[126] == 'I' ? 1 : 0;
    const int maj = (unsigned char)bytes[124 + (size_t)majInd], mn = (unsigned char)bytes[124 + (size_t)(1 - majInd)];
    if (maj != 1 && maj != 2) {
      ctx.fail("this is not a MAT file of a known version");
      return Value(0.0);
    }
    return toValue(Vec{(double)maj, (double)mn});
  } SP_END
  SP_ADD("mat_split_vars", 1, 1, "file") {
    std::string path, bytes, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    io::MatFile mf;
    if (!io::readFile(path, bytes, err) || !io::readMatV5(bytes, mf, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    DictInit d;
    for (const io::MatNode &n : mf.vars) {
      io::MatFile one;
      one.header = mf.header;
      one.vars = {n};
      d.push_back({n.name, Value(io::writeMatV5(one, false, 0))});
    }
    return makeDict(d);
  } SP_END
  // ---- WAV ----
  SP_ADD("wav_write", 3, 4, "file, rate, data, format") {
    std::string path, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    const long long rate = optInt(a, 1, 0);
    if (rate < 1 || rate > 4294967295LL) {
      ctx.fail("rate must be a positive whole number");
      return Value(0.0);
    }
    Mat m;
    if (!getChannels(a[2], m, ctx))
      return Value(0.0);
    WavFormat f;
    if (!chooseWav(m, optText(a, 3, ""), f, ctx))
      return Value(0.0);
    const size_t channels = m.c, frames = m.r, bytesPer = (size_t)f.bits / 8, dataLen = frames * channels * bytesPer;
    std::string o;
    o += "RIFF";
    const bool isFloat = f.tag == 3;
    const size_t fmtLen = isFloat ? 18 : 16, factLen = isFloat ? 12 : 0;
    putLE<uint32_t>(o, (uint32_t)(4 + 8 + fmtLen + factLen + 8 + dataLen + (dataLen & 1)));
    o += "WAVEfmt ";
    putLE<uint32_t>(o, (uint32_t)fmtLen);
    putLE<uint16_t>(o, (uint16_t)f.tag);
    putLE<uint16_t>(o, (uint16_t)channels);
    putLE<uint32_t>(o, (uint32_t)rate);
    putLE<uint32_t>(o, (uint32_t)((size_t)rate * channels * bytesPer));
    putLE<uint16_t>(o, (uint16_t)(channels * bytesPer));
    putLE<uint16_t>(o, (uint16_t)f.bits);
    if (isFloat) {
      putLE<uint16_t>(o, 0);
      o += "fact";
      putLE<uint32_t>(o, 4);
      putLE<uint32_t>(o, (uint32_t)frames);
    }
    o += "data";
    putLE<uint32_t>(o, (uint32_t)dataLen);
    for (size_t i = 0; i < frames; i++)
      for (size_t c = 0; c < channels; c++) {
        const double v = m(i, c);
        if (f.tag == 3 && f.bits == 64)
          putLE<double>(o, v);
        else if (f.tag == 3)
          putLE<float>(o, (float)v);
        else if (f.bits == 8)
          o.push_back((char)(unsigned char)std::lround(std::min(255.0, std::max(0.0, v))));
        else if (f.bits == 16)
          putLE<int16_t>(o, (int16_t)std::lround(std::min(32767.0, std::max(-32768.0, v))));
        else
          putLE<int32_t>(o, (int32_t)std::llround(std::min(2147483647.0, std::max(-2147483648.0, v))));
      }
    if (dataLen & 1)
      o.push_back('\0');
    if (!io::writeFile(path, o, false, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return Value();
  } SP_END
  SP_ADD("wav_read", 1, 1, "file") {
    std::string path, s, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    if (!io::readFile(path, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (s.size() < 12 || (s.compare(0, 4, "RIFF") != 0 && s.compare(0, 4, "RIFX") != 0) || s.compare(8, 4, "WAVE") != 0) {
      ctx.fail("this is not a WAV file");
      return Value(0.0);
    }
    const bool be = s[3] == 'X';
    size_t p = 12;
    int tag = 0, channels = 0, bits = 0;
    uint32_t rate = 0;
    bool haveData = false;
    Mat out;
    while (p + 8 <= s.size()) {
      const std::string id = s.substr(p, 4);
      uint32_t len = getBytes<uint32_t>(s, p + 4, be);
      const size_t body = p + 8;
      if (body + len > s.size())
        len = (uint32_t)(s.size() - body);
      if (id == "fmt " && len >= 16) {
        tag = getBytes<uint16_t>(s, body, be);
        channels = getBytes<uint16_t>(s, body + 2, be);
        rate = getBytes<uint32_t>(s, body + 4, be);
        bits = getBytes<uint16_t>(s, body + 14, be);
        if (tag == 0xFFFE && len >= 26)
          tag = getBytes<uint16_t>(s, body + 24, be);
      } else if (id == "data") {
        if (!channels || !bits) {
          ctx.fail("this WAV file has its data before its format");
          return Value(0.0);
        }
        if (tag != 1 && tag != 3) {
          ctx.fail("only PCM and floating point WAV data can be read");
          return Value(0.0);
        }
        const size_t bp = (size_t)bits / 8;
        if (!bp || bits % 8 || (tag == 3 && bits != 32 && bits != 64) || (tag == 1 && bits > 64)) {
          ctx.fail("this WAV sample size is not supported");
          return Value(0.0);
        }
        const size_t frames = len / (bp * (size_t)channels);
        out = Mat(frames, (size_t)channels);
        for (size_t i = 0; i < out.a.size(); i++) {
          const size_t at = body + i * bp;
          double v;
          if (tag == 3)
            v = bits == 32 ? (double)getBytes<float>(s, at, be) : getBytes<double>(s, at, be);
          else if (bits == 8)
            v = (double)(unsigned char)s[at];
          else if (bits == 16)
            v = (double)getBytes<int16_t>(s, at, be);
          else if (bits == 32)
            v = (double)getBytes<int32_t>(s, at, be);
          else if (bits == 64)
            v = (double)getBytes<int64_t>(s, at, be);
          else {
            // Other widths come back left-justified in the next larger integer, as in scipy.
            uint64_t acc = 0;
            for (size_t b = 0; b < bp; b++) {
              const unsigned char c = (unsigned char)s[at + (be ? b : bp - 1 - b)];
              acc = (acc << 8) | c;
            }
            const int width = bits <= 32 ? 32 : 64;
            acc <<= (width - bits);
            v = width == 32 ? (double)(int32_t)(uint32_t)acc : (double)(int64_t)acc;
          }
          out.a[i] = v;
        }
        haveData = true;
        break;
      }
      p = body + len + (len & 1);
    }
    if (!haveData) {
      ctx.fail("this WAV file has no data");
      return Value(0.0);
    }
    return makeDict({{"rate", Value((double)rate)}, {"data", channels == 1 ? toValue(out.a) : toValue(out)}});
  } SP_END
  // ---- ARFF ----
  SP_ADD("load_arff", 1, 1, "file") {
    std::string path, s, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    if (!io::readFile(path, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    std::istringstream in(s);
    std::string line, relation;
    std::vector<std::string> names, types;
    std::vector<Vec> nums;
    std::vector<std::vector<std::string>> texts;
    bool inData = false;
    while (std::getline(in, line)) {
      const std::string t = trimmed(line);
      if (t.empty() || t[0] == '%')
        continue;
      if (!inData) {
        const std::string low = lowered(t);
        if (low.rfind("@relation", 0) == 0) {
          relation = unquoted(trimmed(t.substr(9)));
        } else if (low.rfind("@attribute", 0) == 0) {
          std::string rest = trimmed(t.substr(10));
          std::string nm, ty;
          if (!rest.empty() && (rest[0] == '\'' || rest[0] == '"')) {
            const size_t e = rest.find(rest[0], 1);
            if (e == std::string::npos) {
              ctx.fail("a quoted attribute name is not closed: " + t);
              return Value(0.0);
            }
            nm = rest.substr(1, e - 1);
            ty = trimmed(rest.substr(e + 1));
          } else {
            size_t e = 0;
            while (e < rest.size() && !std::isspace((unsigned char)rest[e]))
              e++;
            nm = rest.substr(0, e);
            ty = trimmed(rest.substr(e));
          }
          const std::string lt = lowered(ty);
          std::string kind;
          if (lt == "numeric" || lt == "real" || lt == "integer")
            kind = "numeric";
          else if (!lt.empty() && lt[0] == '{')
            kind = "nominal";
          else if (lt.rfind("date", 0) == 0)
            kind = "date";
          else if (lt == "string")
            kind = "string";
          else {
            ctx.fail("unknown attribute type: " + ty);
            return Value(0.0);
          }
          names.push_back(nm);
          types.push_back(kind);
          nums.emplace_back();
          texts.emplace_back();
        } else if (low.rfind("@data", 0) == 0) {
          inData = true;
        }
        continue;
      }
      if (t[0] == '{') {
        ctx.fail("sparse ARFF data is not supported");
        return Value(0.0);
      }
      const std::vector<std::string> cells = splitCsv(t);
      if (cells.size() != names.size()) {
        ctx.fail("a data row has " + std::to_string(cells.size()) + " values, expected " + std::to_string(names.size()));
        return Value(0.0);
      }
      for (size_t c = 0; c < cells.size(); c++) {
        if (types[c] == "numeric") {
          if (cells[c] == "?") {
            nums[c].push_back(kNaN);
          } else {
            char *end = nullptr;
            const double v = std::strtod(cells[c].c_str(), &end);
            if (end == cells[c].c_str()) {
              ctx.fail("not a number: " + cells[c]);
              return Value(0.0);
            }
            nums[c].push_back(v);
          }
        } else {
          texts[c].push_back(cells[c]);
        }
      }
    }
    if (names.empty()) {
      ctx.fail("this file has no attributes: not ARFF");
      return Value(0.0);
    }
    DictInit cols;
    for (size_t c = 0; c < names.size(); c++)
      cols.push_back({names[c], types[c] == "numeric" ? toValue(nums[c]) : namesValue(texts[c])});
    return makeDict({{"data", makeDict(cols)}, {"meta", makeDict({{"name", Value(relation)}, {"names", namesValue(names)}, {"types", namesValue(types)}})}});
  } SP_END
  // ---- NetCDF classic ----
  SP_ADD("netcdf_write", 2, 3, "file, data, dims") {
    std::string path, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    if (!a[1].isDict) {
      ctx.fail("the data must be a Dict: name -> Array or Matrix");
      return Value(0.0);
    }
    const bool hasDims = a.size() > 2 && a[2].isDict;
    std::map<std::string, Value> vars;
    for (const auto &kv : a[1].dict())
      vars[kv.first] = kv.second;
    struct Var {
      std::string name;
      std::vector<size_t> dimIds;
      int type;
      std::string data;
    };
    std::vector<std::pair<std::string, size_t>> dims;
    auto dimId = [&](const std::string &n, size_t len, size_t &id) {
      for (size_t i = 0; i < dims.size(); i++)
        if (dims[i].first == n) {
          id = i;
          return dims[i].second == len;
        }
      dims.push_back({n, len});
      id = dims.size() - 1;
      return true;
    };
    std::vector<Var> list;
    for (const auto &kv : vars) {
      Var v;
      v.name = kv.first;
      std::vector<size_t> shape;
      if (kv.second.isText) {
        v.type = 2;
        v.data = kv.second.text();
        shape = {v.data.size()};
      } else {
        v.type = 6;
        Mat m;
        Vec f;
        if (isPlainNumber(kv.second)) {
          f = {kv.second.number};
        } else if (!readMat(kv.second, m)) {
          ctx.fail("\"" + kv.first + "\" must hold numbers or text");
          return Value(0.0);
        } else {
          f = m.a;
          shape = kv.second.isMatrix && m.r > 1 && m.c > 1 ? std::vector<size_t>{m.r, m.c} : std::vector<size_t>{f.size()};
        }
        for (double d : f)
          putBE<double>(v.data, d);
      }
      std::vector<std::string> dn;
      if (hasDims) {
        if (const Value *dv = dictGet(a[2], kv.first)) {
          if (dv->isText)
            dn.push_back(dv->text());
          else if (dv->isArray)
            for (size_t i = 0; i < dv->length(); i++)
              dn.push_back(dv->at(i).isText ? dv->at(i).text() : "");
          else if (dv->isMatrix)
            for (size_t i = 0; i < dv->cols(); i++)
              dn.push_back(dv->at(0, i).isText ? dv->at(0, i).text() : "");
        }
      }
      if (!dn.empty() && dn.size() != shape.size()) {
        ctx.fail("\"" + kv.first + "\" needs " + std::to_string(shape.size()) + " dimension names");
        return Value(0.0);
      }
      for (size_t i = 0; i < shape.size(); i++) {
        const std::string n = dn.empty() ? kv.first + "_dim" + std::to_string(i) : dn[i];
        size_t id;
        if (n.empty() || !dimId(n, shape[i], id)) {
          ctx.fail("the dimension \"" + n + "\" is used with two different lengths");
          return Value(0.0);
        }
        v.dimIds.push_back(id);
      }
      list.push_back(v);
    }
    std::string o = std::string("CDF\x01", 4);
    putBE<int32_t>(o, 0);
    if (dims.empty()) {
      putBE<int32_t>(o, 0);
      putBE<int32_t>(o, 0);
    } else {
      putBE<int32_t>(o, 10);
      putBE<int32_t>(o, (int32_t)dims.size());
      for (const auto &d : dims) {
        putName(o, d.first);
        putBE<int32_t>(o, (int32_t)d.second);
      }
    }
    putBE<int32_t>(o, 0); // no global attributes
    putBE<int32_t>(o, 0);
    // The header's size is needed for the data offsets, so measure it first.
    size_t head = o.size() + 8;
    for (const Var &v : list)
      head += 4 + (v.name.size() + 3) / 4 * 4 + 4 + 4 * v.dimIds.size() + 8 + 4 + 4 + 4;
    if (list.empty()) {
      putBE<int32_t>(o, 0);
      putBE<int32_t>(o, 0);
    } else {
      putBE<int32_t>(o, 11);
      putBE<int32_t>(o, (int32_t)list.size());
      size_t off = head;
      for (const Var &v : list) {
        putName(o, v.name);
        putBE<int32_t>(o, (int32_t)v.dimIds.size());
        for (size_t d : v.dimIds)
          putBE<int32_t>(o, (int32_t)d);
        putBE<int32_t>(o, 0);
        putBE<int32_t>(o, 0);
        putBE<int32_t>(o, v.type);
        const size_t padded = (v.data.size() + 3) / 4 * 4;
        putBE<int32_t>(o, (int32_t)padded);
        putBE<int32_t>(o, (int32_t)off);
        off += padded;
      }
    }
    for (const Var &v : list) {
      o += v.data;
      o.append((4 - v.data.size() % 4) % 4, '\0');
    }
    if (!io::writeFile(path, o, false, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return Value();
  } SP_END
  SP_ADD("netcdf_read", 1, 1, "file") {
    std::string path, s, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    if (!io::readFile(path, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (s.size() < 8 || s.compare(0, 3, "CDF") != 0 || (s[3] != 1 && s[3] != 2)) {
      ctx.fail("this is not a NetCDF classic file (HDF5-based NetCDF-4 goes through load_hdf5)");
      return Value(0.0);
    }
    const bool offset64 = s[3] == 2;
    CdfReader r(s);
    r.p = 4;
    const int32_t numrecs = r.i32();
    std::vector<size_t> dimLen;
    int32_t tag = r.i32(), n = r.i32();
    if (tag == 10)
      for (int32_t i = 0; i < n && !r.bad; i++) {
        r.name();
        dimLen.push_back((size_t)r.i32());
      }
    if (!cdfSkipAtts(r)) {
      ctx.fail("this NetCDF header is damaged");
      return Value(0.0);
    }
    struct V {
      std::string name;
      std::vector<size_t> shape;
      bool record = false;
      int type = 0;
      size_t vsize = 0, begin = 0;
    };
    std::vector<V> vars;
    tag = r.i32();
    n = r.i32();
    if (tag == 11)
      for (int32_t i = 0; i < n && !r.bad; i++) {
        V v;
        v.name = r.name();
        const int32_t rank = r.i32();
        for (int32_t d = 0; d < rank; d++) {
          const size_t id = (size_t)r.i32();
          if (id >= dimLen.size()) {
            ctx.fail("this NetCDF header is damaged");
            return Value(0.0);
          }
          if (d == 0 && dimLen[id] == 0) {
            v.record = true;
            v.shape.push_back((size_t)numrecs);
          } else {
            v.shape.push_back(dimLen[id]);
          }
        }
        if (!cdfSkipAtts(r)) {
          ctx.fail("this NetCDF header is damaged");
          return Value(0.0);
        }
        v.type = r.i32();
        v.vsize = (size_t)(uint32_t)r.i32();
        if (offset64) {
          if (r.need(8))
            v.begin = (size_t)getBytes<int64_t>(s, r.p, true);
          r.p += 8;
        } else {
          v.begin = (size_t)(uint32_t)r.i32();
        }
        vars.push_back(v);
      }
    if (r.bad) {
      ctx.fail("this NetCDF header is damaged");
      return Value(0.0);
    }
    size_t recSize = 0, recVars = 0;
    for (const V &v : vars)
      if (v.record) {
        recSize += v.vsize;
        recVars++;
      }
    DictInit d;
    for (const V &v : vars) {
      const size_t sz = cdfTypeSize(v.type);
      if (!sz) {
        ctx.fail("this NetCDF type is not supported");
        return Value(0.0);
      }
      size_t count = 1;
      for (size_t e : v.shape)
        count *= e;
      const size_t perRec = v.record ? (numrecs ? count / (size_t)numrecs : 0) : count;
      std::string raw;
      if (v.record) {
        // One record variable is packed with no padding.
        const size_t stride = recVars == 1 ? perRec * sz : recSize;
        for (int32_t q = 0; q < numrecs; q++) {
          if (v.begin + (size_t)q * stride + perRec * sz > s.size()) {
            ctx.fail("this NetCDF file is cut short");
            return Value(0.0);
          }
          raw.append(s, v.begin + (size_t)q * stride, perRec * sz);
        }
      } else {
        if (v.begin + count * sz > s.size()) {
          ctx.fail("this NetCDF file is cut short");
          return Value(0.0);
        }
        raw = s.substr(v.begin, count * sz);
      }
      if (v.type == 2) {
        d.push_back({v.name, Value(raw)});
        continue;
      }
      Vec f(count);
      for (size_t i = 0; i < count; i++)
        f[i] = cdfValue(raw, i * sz, v.type);
      Value val;
      if (v.shape.empty())
        val = Value(f[0]);
      else if (v.shape.size() == 1)
        val = toValue(f);
      else if (v.shape.size() == 2) {
        Mat m(v.shape[0], v.shape[1]);
        m.a = f;
        val = toValue(m);
      } else {
        val = io::ndFromRowMajor(v.shape, f);
      }
      d.push_back({v.name, val});
    }
    return makeDict(d);
  } SP_END
  // ---- Fortran unformatted ----
  SP_ADD("fortran_write", 2, 4, "file, data, dtype=\"float64\", append=0") {
    std::string path, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    Vec v;
    if (!getVec(a, 1, ctx, v))
      return Value(0.0);
    const std::string t = optText(a, 2, "float64");
    std::string body;
    for (double d : v) {
      if (t == "float64")
        putLE<double>(body, d);
      else if (t == "float32")
        putLE<float>(body, (float)d);
      else if (t == "int32")
        putLE<int32_t>(body, (int32_t)d);
      else if (t == "int64")
        putLE<int64_t>(body, (int64_t)d);
      else if (t == "int16")
        putLE<int16_t>(body, (int16_t)d);
      else if (t == "uint8")
        body.push_back((char)(unsigned char)d);
      else {
        ctx.fail("dtype must be \"float64\", \"float32\", \"int64\", \"int32\", \"int16\" or \"uint8\"");
        return Value(0.0);
      }
    }
    std::string o;
    putLE<uint32_t>(o, (uint32_t)body.size());
    o += body;
    putLE<uint32_t>(o, (uint32_t)body.size());
    if (!io::writeFile(path, o, optBool(a, 3, false), err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return Value();
  } SP_END
  SP_ADD("fortran_read", 1, 3, "file, dtype=\"float64\", record=0") {
    std::string path, s, err;
    if (!getPath(a, 0, ctx, path))
      return Value(0.0);
    if (!io::readFile(path, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const std::string t = optText(a, 1, "float64");
    const size_t sz = t == "float64" || t == "int64" ? 8 : (t == "float32" || t == "int32" ? 4 : (t == "int16" ? 2 : (t == "uint8" ? 1 : 0)));
    if (!sz) {
      ctx.fail("dtype must be \"float64\", \"float32\", \"int64\", \"int32\", \"int16\" or \"uint8\"");
      return Value(0.0);
    }
    long long want = optInt(a, 2, 0);
    size_t p = 0;
    while (p + 4 <= s.size()) {
      const uint32_t len = getBytes<uint32_t>(s, p, false);
      if (p + 8 + (size_t)len > s.size() || getBytes<uint32_t>(s, p + 4 + len, false) != len) {
        ctx.fail("the record markers of this file do not match");
        return Value(0.0);
      }
      if (want-- == 0) {
        if (len % sz) {
          ctx.fail("the record size is not a multiple of this dtype");
          return Value(0.0);
        }
        Vec v(len / sz);
        for (size_t i = 0; i < v.size(); i++) {
          const size_t at = p + 4 + i * sz;
          if (t == "float64")
            v[i] = getBytes<double>(s, at, false);
          else if (t == "float32")
            v[i] = (double)getBytes<float>(s, at, false);
          else if (t == "int64")
            v[i] = (double)getBytes<int64_t>(s, at, false);
          else if (t == "int32")
            v[i] = (double)getBytes<int32_t>(s, at, false);
          else if (t == "int16")
            v[i] = (double)getBytes<int16_t>(s, at, false);
          else
            v[i] = (double)(unsigned char)s[at];
        }
        return toValue(v);
      }
      p += 8 + (size_t)len;
    }
    ctx.fail("this file has no such record");
    return Value(0.0);
  } SP_END
  registerIoIdl(reg);
  registerIoSparse(reg);
}

} // namespace scipy
} // namespace nc
