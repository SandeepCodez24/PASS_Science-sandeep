// Positive definite matrices: Cholesky in full (po), band (pb), packed (pp),
// rectangular full packed (pf, tf, sfrk/hfrk) and tridiagonal (pt) storage,
// the pivoted Cholesky (pstrf, pstf2), and the conversions between packed,
// RFP and full triangles (tpttf, tfttr, ...).
//
// RFP layout (LAPACK's TRANSR = 'N'): an (n + s) x ceil(n/2) column-major
// array, s = 1 for even n. Lower: column j holds A(j.., j) shifted down by s,
// with the trailing triangle mirrored (conjugated) above it. Upper: column j
// holds A(0..m+j, m+j), m = floor(n/2), with the leading triangle mirrored
// below. TRANSR = 'T'/'C' stores the conjugate transpose of that array.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

// Cholesky of one triangle in place: A = U^H U (upper) or L L^H (lower).
// The other triangle is left alone. Returns info (k+1 for a non-positive pivot).
template <class T> long long potrf(MatT<T> &A, bool lower) {
  const size_t n = A.r;
  for (size_t j = 0; j < n; j++) {
    double s = realOf(A(j, j));
    for (size_t k = 0; k < j; k++) {
      const T v = lower ? A(j, k) : A(k, j);
      s -= absOf(v) * absOf(v);
    }
    if (!(s > 0.0)) {
      A(j, j) = T(s);
      return static_cast<long long>(j) + 1;
    }
    const double d = std::sqrt(s);
    A(j, j) = T(d);
    for (size_t i = j + 1; i < n; i++) {
      if (lower) {
        T v = A(i, j);
        for (size_t k = 0; k < j; k++)
          v -= A(i, k) * conjOf(A(j, k));
        A(i, j) = v / T(d);
      } else {
        T v = A(j, i);
        for (size_t k = 0; k < j; k++)
          v -= conjOf(A(k, j)) * A(k, i);
        A(j, i) = v / T(d);
      }
    }
  }
  return 0;
}
// Solves A X = B from the factor (triangle of C).
template <class T> void potrs(const MatT<T> &C, MatT<T> &B, bool lower) {
  if (lower) {
    triSolve(C, B, true, 'N', false);
    triSolve(C, B, true, 'C', false);
  } else {
    triSolve(C, B, false, 'C', false);
    triSolve(C, B, false, 'N', false);
  }
}
// The inverse of A = factor product, as a full Hermitian matrix.
template <class T> MatT<T> potriFull(const MatT<T> &C, bool lower) {
  MatT<T> X = MatT<T>::eye(C.r);
  potrs(C, X, lower);
  for (size_t i = 0; i < X.r; i++)
    X(i, i) = T(realOf(X(i, i)));
  return X;
}
template <class T> double norm1Herm(const MatT<T> &F) {
  double r = 0.0;
  for (size_t j = 0; j < F.c; j++) {
    double s = 0.0;
    for (size_t i = 0; i < F.r; i++)
      s += absOf(F(i, j));
    r = std::max(r, s);
  }
  return r;
}
template <class T> double rcondFromInv(double anorm, const MatT<T> &X) {
  if (anorm == 0.0)
    return 0.0;
  const double in = norm1Herm(X);
  return in > 0.0 && std::isfinite(in) ? (1.0 / in) / anorm : 0.0;
}

// ---- RFP index map ----
struct RfpCell {
  size_t i, j;
  bool conj;
};
// Cell k of the 'N' array (column-major (n+s) x ceil(n/2)).
inline std::vector<RfpCell> rfpMap(size_t n, bool lower) {
  const size_t s = n % 2 == 0 ? 1 : 0, ld = n + s, c = (n + 1) / 2, m = n / 2, p = n / 2;
  std::vector<RfpCell> map;
  map.reserve(n * (n + 1) / 2);
  for (size_t j = 0; j < c; j++)
    for (size_t i = 0; i < ld; i++) {
      if (lower) {
        if (i >= s && i - s >= j)
          map.push_back({i - s, j, false});
        else
          map.push_back({p + j, p + i + 1 - s, true});
      } else {
        if (i <= m + j)
          map.push_back({i, m + j, false});
        else
          map.push_back({j, i - m - 1, true});
      }
    }
  return map;
}
// Order of the cells in the stored vector: 'N' column-major, 'T'/'C' row-major (conjugated).
inline std::vector<std::pair<size_t, bool>> rfpOrder(size_t n, bool trans) {
  const size_t s = n % 2 == 0 ? 1 : 0, ld = n + s, c = (n + 1) / 2;
  std::vector<std::pair<size_t, bool>> ord;
  for (size_t k = 0; k < ld * c; k++) {
    if (!trans)
      ord.push_back({k, false});
    else
      ord.push_back({(k % c) * ld + k / c, true});
  }
  return ord;
}
template <class T> std::vector<T> toRfp(const MatT<T> &A, bool lower, bool trans) {
  const size_t n = A.r;
  auto map = rfpMap(n, lower);
  auto ord = rfpOrder(n, trans);
  std::vector<T> arf(map.size());
  for (size_t k = 0; k < ord.size(); k++) {
    const RfpCell &cl = map[ord[k].first];
    T v = A(cl.i, cl.j);
    if (cl.conj != ord[k].second)
      v = conjOf(v);
    arf[k] = v;
  }
  return arf;
}
// RFP -> dense matrix holding the triangle only.
template <class T> MatT<T> fromRfp(const std::vector<T> &arf, size_t n, bool lower, bool trans) {
  auto map = rfpMap(n, lower);
  auto ord = rfpOrder(n, trans);
  MatT<T> A(n, n);
  for (size_t k = 0; k < ord.size() && k < arf.size(); k++) {
    const RfpCell &cl = map[ord[k].first];
    T v = arf[k];
    if (cl.conj != ord[k].second)
      v = conjOf(v);
    A(cl.i, cl.j) = v;
  }
  return A;
}
inline bool rfpTrans(const Args &a, size_t i) { return copt(a, i, 'N') != 'N'; }
template <class T> bool getRfp(const Args &a, size_t ni, size_t ai, CallContext &ctx, long long &n, std::vector<T> &arf) {
  if (!getI(a, ni, ctx, n) || !getV(a, ai, ctx, arf))
    return false;
  if (n < 0 || static_cast<size_t>(n) * static_cast<size_t>(n + 1) / 2 != arf.size()) {
    ctx.fail("the RFP array must hold n*(n+1)/2 values");
    return false;
  }
  return true;
}

// ---- pivoted Cholesky (xPSTF2), upper form; the lower one runs on A^H ----
template <class T> Value pstf2(MatT<T> A, double tol, bool lower) {
  if (lower)
    A = adjointOf(A);
  const size_t n = A.r;
  std::vector<long long> piv(n);
  for (size_t i = 0; i < n; i++)
    piv[i] = static_cast<long long>(i) + 1;
  long long rank = static_cast<long long>(n), info = 0;
  if (n > 0) {
    size_t pvt = 0;
    double ajj = realOf(A(0, 0));
    for (size_t i = 1; i < n; i++)
      if (realOf(A(i, i)) > ajj) {
        ajj = realOf(A(i, i));
        pvt = i;
      }
    if (!(ajj > 0.0)) {
      rank = 0;
      info = 1;
    } else {
      const double dstop = tol < 0 ? static_cast<double>(n) * lamch('E') * ajj : tol;
      Vec work(2 * n, 0.0);
      for (size_t j = 0; j < n; j++) {
        for (size_t i = j; i < n; i++) {
          if (j > 0)
            work[i] += absOf(A(j - 1, i)) * absOf(A(j - 1, i));
          work[n + i] = realOf(A(i, i)) - work[i];
        }
        if (j > 0) {
          pvt = j;
          for (size_t i = j + 1; i < n; i++)
            if (work[n + i] > work[n + pvt])
              pvt = i;
          ajj = work[n + pvt];
          if (!(ajj > dstop)) {
            A(j, j) = T(ajj);
            rank = static_cast<long long>(j);
            info = 1;
            break;
          }
        }
        if (j != pvt) {
          A(pvt, pvt) = A(j, j);
          for (size_t r = 0; r < j; r++)
            std::swap(A(r, j), A(r, pvt));
          for (size_t c = pvt + 1; c < n; c++)
            std::swap(A(j, c), A(pvt, c));
          for (size_t i = j + 1; i < pvt; i++) {
            T t = conjOf(A(j, i));
            A(j, i) = conjOf(A(i, pvt));
            A(i, pvt) = t;
          }
          A(j, pvt) = conjOf(A(j, pvt));
          std::swap(work[j], work[pvt]);
          std::swap(piv[j], piv[pvt]);
        }
        ajj = std::sqrt(ajj);
        A(j, j) = T(ajj);
        for (size_t c = j + 1; c < n; c++) {
          T s(0);
          for (size_t k = 0; k < j; k++)
            s += conjOf(A(k, j)) * A(k, c);
          A(j, c) = (A(j, c) - s) / T(ajj);
        }
      }
    }
  }
  if (lower)
    A = adjointOf(A);
  return makeDict({{"c", outM(A)}, {"piv", ivec(piv)}, {"rank_c", inum(rank)}, {"info", inum(info)}});
}

// ---- tridiagonal L D L^H (xPTTRF): d real, e the off-diagonal ----
template <class T> long long pttrf(Vec &d, std::vector<T> &e) {
  const size_t n = d.size();
  for (size_t i = 0; i + 1 < n; i++) {
    if (!(d[i] > 0.0))
      return static_cast<long long>(i) + 1;
    const T ei = e[i];
    e[i] = ei / T(d[i]);
    d[i + 1] -= realOf(e[i] * conjOf(ei));
  }
  if (n && !(d[n - 1] > 0.0))
    return static_cast<long long>(n);
  return 0;
}
// Solves with the factors; lower: L(i+1,i) = e(i), else U(i,i+1) = e(i) (A = U^H D U).
template <class T> void pttrs(const Vec &d, const std::vector<T> &e, MatT<T> &B, bool lower) {
  const size_t n = d.size();
  for (size_t c = 0; c < B.c; c++) {
    for (size_t i = 1; i < n; i++)
      B(i, c) -= B(i - 1, c) * (lower ? e[i - 1] : conjOf(e[i - 1]));
    for (size_t i = 0; i < n; i++)
      B(i, c) /= T(d[i]);
    for (size_t i = n - 1; i-- > 0;)
      B(i, c) -= B(i + 1, c) * (lower ? conjOf(e[i]) : e[i]);
  }
}
template <class T> bool getPt(const Args &a, size_t i0, CallContext &ctx, Vec &d, std::vector<T> &e) {
  std::vector<T> dv;
  if (!getV(a, i0, ctx, dv) || !getV(a, i0 + 1, ctx, e))
    return false;
  if (dv.empty() || e.size() + 1 < dv.size()) {
    ctx.fail("e must hold n-1 values for a d of n values");
    return false;
  }
  e.resize(dv.size() - 1);
  d.resize(dv.size());
  for (size_t i = 0; i < dv.size(); i++)
    d[i] = realOf(dv[i]);
  return true;
}
template <class T> MatT<T> ptFull(const Vec &d, const std::vector<T> &e, bool lower) {
  const size_t n = d.size();
  MatT<T> A(n, n);
  for (size_t i = 0; i < n; i++) {
    A(i, i) = T(d[i]);
    if (i + 1 < n) {
      A(i + 1, i) = lower ? e[i] : conjOf(e[i]);
      A(i, i + 1) = conjOf(A(i + 1, i));
    }
  }
  return A;
}

// Copies the triangle of a full Hermitian matrix from a factor solve result.
template <class T> MatT<T> keepTri(const MatT<T> &orig, const MatT<T> &tri, bool lower) {
  MatT<T> out = orig;
  putTri(out, tri, lower);
  return out;
}

} // namespace

void registerBlwChol(Registry &reg) {
  // ---- full storage ----
  SP_ADD("lapack_potrf", 1, 4, "a, lower, clean") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      const bool lower = iopt(a, 1, 0) != 0, clean = given(a, 2) ? iopt(a, 2, 1) != 0 : true;
      long long info = potrf(A, lower);
      if (clean && info == 0)
        A = triOf(A, lower, false);
      return makeDict({{"c", outM(A)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_potrs", 2, 4, "c, b, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> C, B;
      bool wv;
      if (!getSq(a, 0, ctx, C) || !getB(a, 1, ctx, C.r, B, wv))
        return Value(0.0);
      potrs(C, B, iopt(a, 2, 0) != 0);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_potri", 1, 3, "c, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> C;
      if (!getSq(a, 0, ctx, C))
        return Value(0.0);
      const bool lower = iopt(a, 1, 0) != 0;
      for (size_t i = 0; i < C.r; i++)
        if (C(i, i) == T(0))
          return makeDict({{"inv_a", outM(C)}, {"info", inum(static_cast<long long>(i) + 1)}});
      return makeDict({{"inv_a", outM(keepTri(C, potriFull(C, lower), lower))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_posv", 2, 5, "a, b, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
        return Value(0.0);
      const bool lower = iopt(a, 2, 0) != 0;
      long long info = potrf(A, lower);
      if (info == 0)
        potrs(A, B, lower);
      return makeDict({{"c", outM(A)}, {"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pocon", 2, 3, "a, anorm, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> C;
      double anorm;
      if (!getSq(a, 0, ctx, C) || !argNumber(a, 1, ctx, anorm))
        return Value(0.0);
      const bool lower = copt(a, 2, 'U') == 'L';
      for (size_t i = 0; i < C.r; i++)
        if (C(i, i) == T(0))
          return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
      return makeDict({{"rcond", Value(rcondFromInv(anorm, potriFull(C, lower)))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_posvx", 2, 9, "a, b, fact, af, equed, s, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
        return Value(0.0);
      const size_t n = A.r;
      const char fact = copt(a, 2, 'E');
      const bool lower = iopt(a, 6, 0) != 0;
      char equed = 'N';
      Vec s(n, 1.0);
      MatT<T> F(n, n);
      long long info = 0;
      if (fact == 'F') {
        if (!getSq(a, 3, ctx, F))
          return Value(0.0);
        if (F.r != n) {
          ctx.fail("af must match the size of a");
          return Value(0.0);
        }
        equed = copt(a, 4, 'N');
        if (equed == 'Y' && (!getVec(a, 5, ctx, s) || s.size() != n))
          return Value(0.0);
      } else if (fact == 'E' && n > 0) {
        double smin = realOf(A(0, 0)), smax = smin, amax = 0.0;
        bool bad = false;
        for (size_t i = 0; i < n; i++) {
          const double d = realOf(A(i, i));
          s[i] = d;
          smin = std::min(smin, d);
          smax = std::max(smax, d);
          amax = std::max(amax, d);
          if (d <= 0.0)
            bad = true;
        }
        if (!bad) {
          for (size_t i = 0; i < n; i++)
            s[i] = 1.0 / std::sqrt(s[i]);
          const double scond = std::sqrt(smin) / std::sqrt(smax);
          const double small = lamch('S') / lamch('P'), large = 1.0 / small;
          if (scond >= 0.1 && amax >= small && amax <= large) {
            s.assign(n, 1.0);
          } else {
            equed = 'Y';
            for (size_t i = 0; i < n; i++)
              for (size_t j = 0; j < n; j++)
                A(i, j) *= T(s[i] * s[j]);
          }
        } else {
          s.assign(n, 1.0);
        }
      }
      if (equed == 'Y')
        for (size_t i = 0; i < n; i++)
          for (size_t k = 0; k < B.c; k++)
            B(i, k) *= T(s[i]);
      if (fact != 'F') {
        F = triOf(A, lower, false);
        info = potrf(F, lower);
      }
      MatT<T> X(B.r, B.c);
      double rcond = 0.0;
      Vec ferr(B.c, 0.0), berr(B.c, 0.0);
      if (info == 0) {
        MatT<T> Full = fullSym(A, lower, true);
        MatT<T> Ainv = potriFull(F, lower);
        rcond = rcondFromInv(norm1Herm(Full), Ainv);
        X = B;
        potrs(F, X, lower);
        // Backward and forward errors as the LU expert drivers compute them.
        const double eps = lamch('E'), safe1 = (static_cast<double>(n) + 1) * lamch('S');
        for (size_t c = 0; c < B.c; c++) {
          Vec w(n), rr(n);
          for (size_t i = 0; i < n; i++) {
            T r = B(i, c);
            double sm = cabs1(B(i, c));
            for (size_t k = 0; k < n; k++) {
              r -= Full(i, k) * X(k, c);
              sm += cabs1(Full(i, k)) * cabs1(X(k, c));
            }
            rr[i] = cabs1(r);
            w[i] = sm;
          }
          double be = 0.0, num = 0.0, xn = 0.0;
          for (size_t i = 0; i < n; i++)
            be = std::max(be, w[i] > safe1 ? rr[i] / w[i] : (rr[i] + safe1) / (w[i] + safe1));
          for (size_t i = 0; i < n; i++) {
            double sm = 0.0;
            for (size_t k = 0; k < n; k++)
              sm += absOf(Ainv(i, k)) * (rr[k] + (static_cast<double>(n) + 1) * eps * w[k]);
            num = std::max(num, sm);
            xn = std::max(xn, absOf(X(i, c)));
          }
          berr[c] = be;
          ferr[c] = xn > 0.0 ? num / xn : 0.0;
        }
        if (equed == 'Y')
          for (size_t i = 0; i < n; i++)
            for (size_t k = 0; k < X.c; k++)
              X(i, k) *= T(s[i]);
        if (rcond < lamch('E'))
          info = static_cast<long long>(n) + 1;
      }
      return makeDict({{"a_s", outM(A)}, {"lu", outM(F)}, {"equed", Value(std::string(1, equed))},
                       {"s", toValue(s)}, {"b_s", outB(B, wv)}, {"x", outB(X, wv)}, {"rcond", Value(rcond)},
                       {"ferr", toValue(ferr)}, {"berr", toValue(berr)}, {"info", inum(info)}});
    });
  } SP_ENDC

  // ---- band ----
  static const auto pbFactor = [](auto &ab, bool lower, long long &info) {
    using M = std::decay_t<decltype(ab)>;
    const long long kd = static_cast<long long>(ab.r) - 1;
    M A = sbToDense(ab, kd, lower);
    info = potrf(A, lower);
    return denseToSb(A, ab.r, kd, lower, &ab);
  };
  SP_ADD("lapack_pbtrf", 1, 3, "ab, lower, ldab") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab;
      if (!getM(a, 0, ctx, ab))
        return Value(0.0);
      long long info;
      MatT<T> c = pbFactor(ab, iopt(a, 1, 0) != 0, info);
      return makeDict({{"c", outM(c)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pbtrs", 2, 4, "ab, b, lower, ldab") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab, B;
      bool wv;
      if (!getM(a, 0, ctx, ab) || !getB(a, 1, ctx, ab.c, B, wv))
        return Value(0.0);
      const bool lower = iopt(a, 2, 0) != 0;
      potrs(sbToDense(ab, static_cast<long long>(ab.r) - 1, lower), B, lower);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pbsv", 2, 6, "ab, b, lower, ldab") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab, B;
      bool wv;
      if (!getM(a, 0, ctx, ab) || !getB(a, 1, ctx, ab.c, B, wv))
        return Value(0.0);
      const bool lower = iopt(a, 2, 0) != 0;
      long long info;
      MatT<T> c = pbFactor(ab, lower, info);
      if (info == 0)
        potrs(sbToDense(c, static_cast<long long>(c.r) - 1, lower), B, lower);
      return makeDict({{"c", outM(c)}, {"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC

  // ---- packed ----
  SP_ADD("lapack_pptrf", 2, 4, "n, ap, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      if (!getI(a, 0, ctx, n) || !getV(a, 1, ctx, ap) || !packedOk(ctx, ap.size(), n))
        return Value(0.0);
      const bool lower = iopt(a, 2, 0) != 0;
      MatT<T> A = packedToTri(ap, static_cast<size_t>(n), lower);
      long long info = potrf(A, lower);
      std::vector<T> out = triToPacked(A, lower);
      for (size_t k = out.size(); k < ap.size(); k++)
        out.push_back(ap[k]);
      return makeDict({{"ul", outV(out)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pptrs", 3, 5, "n, ap, b, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      MatT<T> B;
      bool wv;
      if (!getI(a, 0, ctx, n) || !getV(a, 1, ctx, ap) || !packedOk(ctx, ap.size(), n) ||
          !getB(a, 2, ctx, static_cast<size_t>(n), B, wv))
        return Value(0.0);
      const bool lower = iopt(a, 3, 0) != 0;
      potrs(packedToTri(ap, static_cast<size_t>(n), lower), B, lower);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pptri", 2, 4, "n, ap, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      if (!getI(a, 0, ctx, n) || !getV(a, 1, ctx, ap) || !packedOk(ctx, ap.size(), n))
        return Value(0.0);
      const bool lower = iopt(a, 2, 0) != 0;
      MatT<T> C = packedToTri(ap, static_cast<size_t>(n), lower);
      for (size_t i = 0; i < C.r; i++)
        if (C(i, i) == T(0))
          return makeDict({{"uli", outV(ap)}, {"info", inum(static_cast<long long>(i) + 1)}});
      std::vector<T> out = triToPacked(potriFull(C, lower), lower);
      for (size_t k = out.size(); k < ap.size(); k++)
        out.push_back(ap[k]);
      return makeDict({{"uli", outV(out)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_ppsv", 3, 5, "n, ap, b, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      MatT<T> B;
      bool wv;
      if (!getI(a, 0, ctx, n) || !getV(a, 1, ctx, ap) || !packedOk(ctx, ap.size(), n) ||
          !getB(a, 2, ctx, static_cast<size_t>(n), B, wv))
        return Value(0.0);
      const bool lower = iopt(a, 3, 0) != 0;
      MatT<T> A = packedToTri(ap, static_cast<size_t>(n), lower);
      long long info = potrf(A, lower);
      if (info == 0)
        potrs(A, B, lower);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_ppcon", 3, 4, "n, ap, anorm, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      double anorm;
      if (!getI(a, 0, ctx, n) || !getV(a, 1, ctx, ap) || !packedOk(ctx, ap.size(), n) ||
          !argNumber(a, 2, ctx, anorm))
        return Value(0.0);
      const bool lower = iopt(a, 3, 0) != 0;
      MatT<T> C = packedToTri(ap, static_cast<size_t>(n), lower);
      for (size_t i = 0; i < C.r; i++)
        if (C(i, i) == T(0))
          return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
      return makeDict({{"rcond", Value(rcondFromInv(anorm, potriFull(C, lower)))}, {"info", inum(0)}});
    });
  } SP_ENDC

  // ---- pivoted ----
  SP_ADD("lapack_pstrf", 1, 4, "a, tol, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return pstf2(A, given(a, 1) && isPlainNumber(a[1]) ? a[1].number : -1.0, iopt(a, 2, 0) != 0);
    });
  } SP_ENDC
  SP_ADD("lapack_pstf2", 1, 4, "a, tol, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return pstf2(A, given(a, 1) && isPlainNumber(a[1]) ? a[1].number : -1.0, iopt(a, 2, 0) != 0);
    });
  } SP_ENDC

  // ---- tridiagonal ----
  SP_ADD("lapack_pttrf", 2, 4, "d, e") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      Vec d;
      std::vector<T> e;
      if (!getPt(a, 0, ctx, d, e))
        return Value(0.0);
      long long info = pttrf(d, e);
      return makeDict({{"d", toValue(d)}, {"e", outV(e)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pttrs", 3, 5, "d, e, b, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      Vec d;
      std::vector<T> e;
      MatT<T> B;
      bool wv;
      if (!getPt(a, 0, ctx, d, e) || !getB(a, 2, ctx, d.size(), B, wv))
        return Value(0.0);
      // The real routine has no uplo: its factor is always L D L^T.
      const bool lower = isCx<T>() ? iopt(a, 3, 0) != 0 : true;
      pttrs(d, e, B, lower);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_ptsv", 3, 6, "d, e, b") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      Vec d;
      std::vector<T> e;
      MatT<T> B;
      bool wv;
      if (!getPt(a, 0, ctx, d, e) || !getB(a, 2, ctx, d.size(), B, wv))
        return Value(0.0);
      long long info = pttrf(d, e);
      if (info == 0)
        pttrs(d, e, B, true);
      return makeDict({{"d", toValue(d)}, {"du", outV(e)}, {"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_ptsvx", 3, 6, "d, e, b, fact, df, ef") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      Vec d, df;
      std::vector<T> e, ef;
      MatT<T> B;
      bool wv;
      if (!getPt(a, 0, ctx, d, e) || !getB(a, 2, ctx, d.size(), B, wv))
        return Value(0.0);
      const size_t n = d.size();
      long long info = 0;
      if (copt(a, 3, 'N') == 'F') {
        if (!getPt(a, 4, ctx, df, ef))
          return Value(0.0);
        if (df.size() != n) {
          ctx.fail("df must match the size of d");
          return Value(0.0);
        }
      } else {
        df = d;
        ef = e;
        info = pttrf(df, ef);
      }
      MatT<T> X(B.r, B.c);
      double rcond = 0.0;
      Vec ferr(B.c, 0.0), berr(B.c, 0.0);
      if (info == 0) {
        MatT<T> Full = ptFull(d, e, true);
        MatT<T> Ainv = MatT<T>::eye(n);
        pttrs(df, ef, Ainv, true);
        rcond = rcondFromInv(norm1Herm(Full), Ainv);
        X = B;
        pttrs(df, ef, X, true);
        const double eps = lamch('E'), safe1 = (static_cast<double>(n) + 1) * lamch('S');
        for (size_t c = 0; c < B.c; c++) {
          Vec w(n), rr(n);
          for (size_t i = 0; i < n; i++) {
            T r = B(i, c);
            double sm = cabs1(B(i, c));
            for (size_t k = 0; k < n; k++) {
              r -= Full(i, k) * X(k, c);
              sm += cabs1(Full(i, k)) * cabs1(X(k, c));
            }
            rr[i] = cabs1(r);
            w[i] = sm;
          }
          double be = 0.0, num = 0.0, xn = 0.0;
          for (size_t i = 0; i < n; i++)
            be = std::max(be, w[i] > safe1 ? rr[i] / w[i] : (rr[i] + safe1) / (w[i] + safe1));
          for (size_t i = 0; i < n; i++) {
            double sm = 0.0;
            for (size_t k = 0; k < n; k++)
              sm += absOf(Ainv(i, k)) * (rr[k] + (static_cast<double>(n) + 1) * eps * w[k]);
            num = std::max(num, sm);
            xn = std::max(xn, absOf(X(i, c)));
          }
          berr[c] = be;
          ferr[c] = xn > 0.0 ? num / xn : 0.0;
        }
        if (rcond < lamch('E'))
          info = static_cast<long long>(n) + 1;
      }
      return makeDict({{"df", toValue(df)}, {"ef", outV(ef)}, {"x", outB(X, wv)}, {"rcond", Value(rcond)},
                       {"ferr", toValue(ferr)}, {"berr", toValue(berr)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pteqr", 3, 7, "d, e, z, compute_z") {
    return both(a, [&](auto zz) -> Value {
      using T = decltype(zz);
      Vec d, ev;
      if (!getVec(a, 0, ctx, d) || !getVec(a, 1, ctx, ev))
        return Value(0.0);
      const size_t n = d.size();
      if (ev.size() + 1 < n) {
        ctx.fail("e must hold n-1 values");
        return Value(0.0);
      }
      ev.resize(n ? n - 1 : 0);
      MatT<T> Zin;
      if (!getM(a, 2, ctx, Zin))
        return Value(0.0);
      const long long cz = iopt(a, 3, 0);
      if (cz == 1 && (Zin.c != n)) {
        ctx.fail("z must have n columns");
        return Value(0.0);
      }
      // Positive definite check, as xPTTRF inside xPTEQR.
      Vec dd = d;
      std::vector<double> ee = ev;
      const long long pinfo = pttrf(dd, ee);
      if (pinfo != 0)
        return makeDict({{"d", toValue(d)}, {"e", toValue(ev)}, {"z", outM(Zin)},
                         {"info", inum(static_cast<long long>(n) + pinfo)}});
      Mat Tm(n, n);
      for (size_t i = 0; i < n; i++) {
        Tm(i, i) = d[i];
        if (i + 1 < n)
          Tm(i, i + 1) = Tm(i + 1, i) = ev[i];
      }
      Vec w;
      Mat V;
      la::eigHermitian(Tm, w, V);
      // Descending order, as xPTEQR returns them.
      Vec wd(n);
      Mat Vd(n, n);
      for (size_t k = 0; k < n; k++) {
        wd[k] = w[n - 1 - k];
        for (size_t i = 0; i < n; i++)
          Vd(i, k) = V(i, n - 1 - k);
      }
      MatT<T> Zout = Zin;
      if (cz == 2) {
        Zout = MatT<T>(n, n);
        for (size_t k = 0; k < Vd.a.size(); k++)
          Zout.a[k] = T(Vd.a[k]);
      } else if (cz == 1) {
        MatT<T> Vt(n, n);
        for (size_t k = 0; k < Vd.a.size(); k++)
          Vt.a[k] = T(Vd.a[k]);
        Zout = mul(Zin, Vt);
      }
      return makeDict({{"d", toValue(wd)}, {"e", toValue(Vec(ev.size(), 0.0))}, {"z", outM(Zout)},
                       {"info", inum(0)}});
    });
  } SP_ENDC

  // ---- rectangular full packed ----
  SP_ADD("lapack_trttf", 1, 3, "a, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return makeDict({{"arf", outV(toRfp(A, copt(a, 2, 'U') == 'L', rfpTrans(a, 1)))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tfttr", 2, 4, "n, arf, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> arf;
      if (!getRfp(a, 0, 1, ctx, n, arf))
        return Value(0.0);
      return makeDict({{"a", outM(fromRfp(arf, static_cast<size_t>(n), copt(a, 3, 'U') == 'L', rfpTrans(a, 2)))},
                       {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_trttp", 1, 2, "a, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return makeDict({{"ap", outV(triToPacked(A, copt(a, 1, 'U') == 'L'))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tpttr", 2, 3, "n, ap, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      if (!getRfp(a, 0, 1, ctx, n, ap))
        return Value(0.0);
      return makeDict({{"a", outM(packedToTri(ap, static_cast<size_t>(n), copt(a, 2, 'U') == 'L'))},
                       {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tpttf", 2, 4, "n, ap, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap;
      if (!getRfp(a, 0, 1, ctx, n, ap))
        return Value(0.0);
      const bool lower = copt(a, 3, 'U') == 'L';
      return makeDict({{"arf", outV(toRfp(packedToTri(ap, static_cast<size_t>(n), lower), lower, rfpTrans(a, 2)))},
                       {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tfttp", 2, 4, "n, arf, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> arf;
      if (!getRfp(a, 0, 1, ctx, n, arf))
        return Value(0.0);
      const bool lower = copt(a, 3, 'U') == 'L';
      return makeDict({{"ap", outV(triToPacked(fromRfp(arf, static_cast<size_t>(n), lower, rfpTrans(a, 2)), lower))},
                       {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pftrf", 2, 5, "n, a, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> arf;
      if (!getRfp(a, 0, 1, ctx, n, arf))
        return Value(0.0);
      const bool lower = copt(a, 3, 'U') == 'L', tr = rfpTrans(a, 2);
      MatT<T> A = fromRfp(arf, static_cast<size_t>(n), lower, tr);
      long long info = potrf(A, lower);
      return makeDict({{"achol", outV(info == 0 ? toRfp(A, lower, tr) : arf)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pftri", 2, 5, "n, a, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> arf;
      if (!getRfp(a, 0, 1, ctx, n, arf))
        return Value(0.0);
      const bool lower = copt(a, 3, 'U') == 'L', tr = rfpTrans(a, 2);
      MatT<T> C = fromRfp(arf, static_cast<size_t>(n), lower, tr);
      for (size_t i = 0; i < C.r; i++)
        if (C(i, i) == T(0))
          return makeDict({{"ainv", outV(arf)}, {"info", inum(static_cast<long long>(i) + 1)}});
      return makeDict({{"ainv", outV(toRfp(potriFull(C, lower), lower, tr))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_pftrs", 3, 6, "n, a, b, transr, uplo") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> arf;
      MatT<T> B;
      bool wv;
      if (!getRfp(a, 0, 1, ctx, n, arf) || !getB(a, 2, ctx, static_cast<size_t>(n), B, wv))
        return Value(0.0);
      const bool lower = copt(a, 4, 'U') == 'L';
      potrs(fromRfp(arf, static_cast<size_t>(n), lower, rfpTrans(a, 3)), B, lower);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tfsm", 3, 9, "alpha, a, b, transr, side, uplo, trans, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      T alpha;
      std::vector<T> arf;
      MatT<T> B;
      if (!getScal(a, 0, ctx, alpha) || !getV(a, 1, ctx, arf) || !getM(a, 2, ctx, B))
        return Value(0.0);
      const bool right = copt(a, 4, 'L') == 'R', lower = copt(a, 5, 'U') == 'L', unit = copt(a, 7, 'N') == 'U';
      const char t = copt(a, 6, 'N');
      const size_t n = right ? B.c : B.r;
      if (arf.size() != n * (n + 1) / 2) {
        ctx.fail("the RFP array must hold n*(n+1)/2 values for the side of b");
        return Value(0.0);
      }
      MatT<T> A = fromRfp(arf, n, lower, rfpTrans(a, 3));
      for (auto &e : B.a)
        e *= alpha;
      if (alpha == T(0))
        return outM(B);
      if (!right) {
        triSolve(A, B, lower, t, unit);
        return outM(B);
      }
      MatT<T> Bt = transposeOf(B), Use = A;
      char t2 = t == 'N' ? 'T' : 'N';
      if (t == 'C') {
        for (auto &e : Use.a)
          e = conjOf(e);
        t2 = 'N';
      }
      triSolve(Use, Bt, lower, t2, unit);
      return outM(transposeOf(Bt));
    });
  } SP_ENDC
  // C := alpha A A^H + beta C (trans N) or alpha A^H A + beta C, C in RFP.
  static const auto rfpRk = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      long long n, k;
      double alpha, beta;
      MatT<T> A;
      std::vector<T> cf;
      if (!getI(a, 0, ctx, n) || !getI(a, 1, ctx, k) || !argNumber(a, 2, ctx, alpha) || !getM(a, 3, ctx, A) ||
          !argNumber(a, 4, ctx, beta) || !getV(a, 5, ctx, cf))
        return Value(0.0);
      if (n < 0 || cf.size() != static_cast<size_t>(n * (n + 1) / 2)) {
        ctx.fail("c must hold n*(n+1)/2 values");
        return Value(0.0);
      }
      const bool tr = rfpTrans(a, 6), lower = copt(a, 7, 'U') == 'L', transA = copt(a, 8, 'N') != 'N';
      MatT<T> X = transA ? (herm ? adjointOf(A) : transposeOf(A)) : A;
      if (X.r != static_cast<size_t>(n) || X.c < static_cast<size_t>(k)) {
        ctx.fail("a must be n x k (or k x n when transposed)");
        return Value(0.0);
      }
      MatT<T> Xk(static_cast<size_t>(n), static_cast<size_t>(k));
      for (size_t i = 0; i < Xk.r; i++)
        for (size_t j = 0; j < Xk.c; j++)
          Xk(i, j) = X(i, j);
      MatT<T> P = mul(Xk, herm ? adjointOf(Xk) : transposeOf(Xk));
      MatT<T> C = fromRfp(cf, static_cast<size_t>(n), lower, tr);
      for (size_t i = 0; i < C.r; i++)
        for (size_t j = 0; j < C.c; j++)
          if (lower ? i >= j : i <= j) {
            C(i, j) = (beta == 0.0 ? T(0) : T(beta) * C(i, j)) + T(alpha) * P(i, j);
            if (herm && i == j)
              C(i, j) = T(realOf(C(i, j)));
          }
      return outV(toRfp(C, lower, tr));
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_sfrk", 6, 10, "n, k, alpha, a, beta, c, transr, uplo, trans") {
    return rfpRk(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_hfrk", 6, 10, "n, k, alpha, a, beta, c, transr, uplo, trans") {
    return rfpRk(a, ctx, true);
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
