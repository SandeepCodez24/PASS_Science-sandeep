// BLAS levels 1, 2 and 3 (scipy.linalg.blas). One NC name per routine family:
// blas_gemm covers sgemm, dgemm, cgemm and zgemm. Inputs and defaults follow
// SciPy's wrappers, in the same positional order.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

// n, offx, incx, offy, incy of a level-1 call, read from position `p`
// (n first) with SciPy's defaults.
struct L1 {
  long long n, offx, incx, offy, incy;
};
L1 readL1(const Args &a, size_t p, size_t lenx, bool hasY, bool nPlusOne = false) {
  L1 s{};
  s.offx = iopt(a, p + 1, 0);
  s.incx = iopt(a, p + 2, 1);
  s.offy = hasY ? iopt(a, p + 3, 0) : 0;
  s.incy = hasY ? iopt(a, p + 4, 1) : 1;
  const long long dn = nPlusOne ? defaultN1(lenx, s.offx, s.incx) : defaultN(lenx, s.offx, s.incx);
  s.n = isOmitted(a, p) ? dn : iopt(a, p, dn);
  return s;
}

// y for a level-2 result: the given one, or zeros long enough for len values.
template <class T>
bool yFor(const Args &a, size_t i, CallContext &ctx, long long len, long long off, long long inc,
          std::vector<T> &y) {
  if (given(a, i) && !isOmitted(a, i)) {
    if (!getV(a, i, ctx, y))
      return false;
  } else {
    y.assign(static_cast<size_t>(off + (len > 0 ? (len - 1) * (inc > 0 ? inc : -inc) + 1 : 0)), T(0));
  }
  return strideOk(ctx, y.size(), len, off, inc, "y");
}

// y_out = beta * y + alpha * M x, on the strided parts of x and y.
template <class T>
Value mv(const Args &a, CallContext &ctx, const MatT<T> &M, T alpha, const std::vector<T> &x,
         long long offx, long long incx, T beta, size_t yArg, long long offy, long long incy) {
  if (!strideOk(ctx, x.size(), static_cast<long long>(M.c), offx, incx, "x"))
    return Value(0.0);
  std::vector<T> y;
  if (!yFor(a, yArg, ctx, static_cast<long long>(M.r), offy, incy, y))
    return Value(0.0);
  std::vector<T> xs = gather(x, static_cast<long long>(M.c), offx, incx);
  std::vector<T> ys = gather(y, static_cast<long long>(M.r), offy, incy);
  std::vector<T> p = mulVec(M, xs);
  for (size_t i = 0; i < ys.size(); i++)
    ys[i] = (beta == T(0) ? T(0) : beta * ys[i]) + alpha * p[i];
  scatter(y, ys, offy, incy);
  return outV(y);
}

// x_out = op(M) x, or op(M)^-1 x when `solve`, on the strided part of x.
template <class T>
Value trv(CallContext &ctx, const MatT<T> &M, bool lower, char trans, bool unit, std::vector<T> x,
          long long offx, long long incx, bool solve) {
  const long long n = static_cast<long long>(M.r);
  if (!strideOk(ctx, x.size(), n, offx, incx, "x"))
    return Value(0.0);
  std::vector<T> xs = gather(x, n, offx, incx);
  if (solve) {
    MatT<T> B(xs.size(), 1);
    B.a = xs;
    if (!triSolve(M, B, lower, trans, unit)) {
      // BLAS does not check for singularity: dividing by zero gives inf/nan.
      MatT<T> Mt = opOf(triOf(M, lower, unit), trans);
      const bool low = trans == 'N' ? lower : !lower;
      for (long long ii = 0; ii < n; ii++) {
        size_t i = static_cast<size_t>(low ? ii : n - 1 - ii);
        T s = B(i, 0);
        for (size_t k = 0; k < static_cast<size_t>(n); k++)
          if (k != i && (low ? k < i : k > i))
            s -= Mt(i, k) * B(k, 0);
        B(i, 0) = s / Mt(i, i);
      }
    }
    xs = B.a;
  } else {
    xs = mulVec(opOf(triOf(M, lower, unit), trans), xs);
  }
  scatter(x, xs, offx, incx);
  return outV(x);
}

// The update A + alpha x y^T (conj: y^H) over a whole m x n matrix.
template <class T>
Value ger(const Args &a, CallContext &ctx, bool conj) {
  T alpha;
  std::vector<T> x, y;
  if (!getScal(a, 0, ctx, alpha) || !getV(a, 1, ctx, x) || !getV(a, 2, ctx, y))
    return Value(0.0);
  const long long incx = iopt(a, 3, 1), incy = iopt(a, 4, 1);
  const long long m = defaultN1(x.size(), 0, incx), n = defaultN1(y.size(), 0, incy);
  if (incx == 0 || incy == 0) {
    ctx.fail("increments must not be 0");
    return Value(0.0);
  }
  MatT<T> A(static_cast<size_t>(m), static_cast<size_t>(n));
  if (given(a, 5) && isMatrixLike(a[5])) {
    if (!getM(a, 5, ctx, A))
      return Value(0.0);
    if (A.r != static_cast<size_t>(m) || A.c != static_cast<size_t>(n)) {
      ctx.fail("a must be " + std::to_string(m) + " x " + std::to_string(n));
      return Value(0.0);
    }
  }
  std::vector<T> xs = gather(x, m, 0, incx), ys = gather(y, n, 0, incy);
  for (size_t i = 0; i < A.r; i++)
    for (size_t j = 0; j < A.c; j++)
      A(i, j) += alpha * xs[i] * (conj ? conjOf(ys[j]) : ys[j]);
  return outM(A);
}

// Rank-1/2 updates of one triangle: her, her2, syr, syr2.
template <class T>
Value r12(const Args &a, CallContext &ctx, bool two, bool herm) {
  T alpha;
  std::vector<T> x, y;
  if (!getScal(a, 0, ctx, alpha) || !getV(a, 1, ctx, x))
    return Value(0.0);
  size_t p = 2;
  if (two) {
    if (!getV(a, 2, ctx, y))
      return Value(0.0);
    p = 3;
  }
  const bool lower = iopt(a, p, 0) != 0;
  const long long incx = iopt(a, p + 1, 1), offx = iopt(a, p + 2, 0);
  const long long incy = two ? iopt(a, p + 3, 1) : 1, offy = two ? iopt(a, p + 4, 0) : 0;
  const size_t pn = two ? p + 5 : p + 3;
  long long dn = defaultN1(x.size(), offx, incx);
  if (two)
    dn = std::min(dn, defaultN1(y.size(), offy, incy));
  const long long n = isOmitted(a, pn) ? dn : iopt(a, pn, dn);
  if (!strideOk(ctx, x.size(), n, offx, incx, "x") ||
      (two && !strideOk(ctx, y.size(), n, offy, incy, "y")))
    return Value(0.0);
  MatT<T> A(static_cast<size_t>(n), static_cast<size_t>(n));
  if (given(a, pn + 1) && isMatrixLike(a[pn + 1])) {
    if (!getM(a, pn + 1, ctx, A))
      return Value(0.0);
    if (A.r != static_cast<size_t>(n) || A.c != static_cast<size_t>(n)) {
      ctx.fail("a must be " + std::to_string(n) + " x " + std::to_string(n));
      return Value(0.0);
    }
  }
  std::vector<T> xs = gather(x, n, offx, incx), ys = two ? gather(y, n, offy, incy) : xs;
  if (herm && !two)
    alpha = T(realOf(alpha));
  for (size_t i = 0; i < A.r; i++)
    for (size_t j = 0; j < A.c; j++) {
      if (lower ? i < j : i > j)
        continue;
      T u;
      if (herm)
        u = two ? alpha * xs[i] * conjOf(ys[j]) + conjOf(alpha) * ys[i] * conjOf(xs[j])
                : alpha * xs[i] * conjOf(xs[j]);
      else
        u = two ? alpha * (xs[i] * ys[j] + ys[i] * xs[j]) : alpha * xs[i] * xs[j];
      A(i, j) += u;
      if (herm && i == j)
        A(i, j) = T(realOf(A(i, j)));
    }
  return outM(A);
}

// Packed rank-1/2 updates: hpr, hpr2, spr, spr2 (n, alpha, x, [y,] ap, ...).
template <class T>
Value pr12(const Args &a, CallContext &ctx, bool two, bool herm) {
  long long n;
  T alpha;
  std::vector<T> x, y, ap;
  if (!getI(a, 0, ctx, n) || !getScal(a, 1, ctx, alpha) || !getV(a, 2, ctx, x))
    return Value(0.0);
  size_t p = 3;
  if (two) {
    if (!getV(a, 3, ctx, y))
      return Value(0.0);
    p = 4;
  }
  if (!getV(a, p, ctx, ap) || !packedOk(ctx, ap.size(), n))
    return Value(0.0);
  const long long incx = iopt(a, p + 1, 1), offx = iopt(a, p + 2, 0);
  const long long incy = two ? iopt(a, p + 3, 1) : 1, offy = two ? iopt(a, p + 4, 0) : 0;
  const bool lower = iopt(a, two ? p + 5 : p + 3, 0) != 0;
  if (!strideOk(ctx, x.size(), n, offx, incx, "x") ||
      (two && !strideOk(ctx, y.size(), n, offy, incy, "y")))
    return Value(0.0);
  std::vector<T> xs = gather(x, n, offx, incx), ys = two ? gather(y, n, offy, incy) : xs;
  if (herm && !two)
    alpha = T(realOf(alpha));
  const size_t N = static_cast<size_t>(n);
  for (size_t j = 0; j < N; j++)
    for (size_t i = 0; i < N; i++) {
      if (lower ? i < j : i > j)
        continue;
      T u;
      if (herm)
        u = two ? alpha * xs[i] * conjOf(ys[j]) + conjOf(alpha) * ys[i] * conjOf(xs[j])
                : alpha * xs[i] * conjOf(xs[j]);
      else
        u = two ? alpha * (xs[i] * ys[j] + ys[i] * xs[j]) : alpha * xs[i] * xs[j];
      T &e = ap[packIdx(i, j, N, lower)];
      e += u;
      if (herm && i == j)
        e = T(realOf(e));
    }
  return outV(ap);
}

// Symmetric/Hermitian matrix-vector products from a band, packed or full form.
// Inputs from `p`: incx, offx, beta, y, incy, offy, lower (band and packed layout).
template <class T>
Value bandPackedMv(const Args &a, CallContext &ctx, const MatT<T> &Full, T alpha,
                   const std::vector<T> &x, size_t p) {
  const long long incx = iopt(a, p, 1), offx = iopt(a, p + 1, 0);
  const T beta = scal<T>(a, p + 2, T(0));
  const long long incy = iopt(a, p + 4, 1), offy = iopt(a, p + 5, 0);
  return mv(a, ctx, Full, alpha, x, offx, incx, beta, p + 3, offy, incy);
}

// The level-3 symmetric/Hermitian rank-k updates: herk, her2k, syrk, syr2k.
template <class T>
Value rk(const Args &a, CallContext &ctx, bool two, bool herm) {
  T alpha;
  MatT<T> A, B;
  if (!getScal(a, 0, ctx, alpha) || !getM(a, 1, ctx, A))
    return Value(0.0);
  size_t p = 2;
  if (two) {
    if (!getM(a, 2, ctx, B))
      return Value(0.0);
    if (B.r != A.r || B.c != A.c) {
      ctx.fail("a and b must have the same shape");
      return Value(0.0);
    }
    p = 3;
  }
  T beta = scal<T>(a, p, T(0));
  if (herm) {
    beta = T(realOf(beta));
    if (!two)
      alpha = T(realOf(alpha));
  }
  const long long tr = iopt(a, p + 2, 0);
  const bool lower = iopt(a, p + 3, 0) != 0;
  const char t = tr == 0 ? 'N' : (herm ? 'C' : 'T');
  // C = alpha op(A) op(A)^* with op(A) = A (n x k) or A^T / A^H.
  MatT<T> X = t == 'N' ? A : opOf(A, t);
  MatT<T> Y = two ? (t == 'N' ? B : opOf(B, t)) : X;
  const size_t n = X.r;
  MatT<T> C(n, n);
  if (given(a, p + 1) && isMatrixLike(a[p + 1])) {
    if (!getM(a, p + 1, ctx, C))
      return Value(0.0);
    if (C.r != n || C.c != n) {
      ctx.fail("c must be " + std::to_string(n) + " x " + std::to_string(n));
      return Value(0.0);
    }
  }
  MatT<T> XH = herm ? adjointOf(X) : transposeOf(X);
  MatT<T> YH = herm ? adjointOf(Y) : transposeOf(Y);
  MatT<T> U = mul(X, two ? YH : XH);
  if (two) {
    MatT<T> V = mul(Y, XH);
    for (size_t k = 0; k < U.a.size(); k++)
      U.a[k] = alpha * U.a[k] + (herm ? conjOf(alpha) : alpha) * V.a[k];
  } else {
    for (auto &e : U.a)
      e *= alpha;
  }
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      if (lower ? i < j : i > j)
        continue;
      C(i, j) = (beta == T(0) ? T(0) : beta * C(i, j)) + U(i, j);
      if (herm && i == j)
        C(i, j) = T(realOf(C(i, j)));
    }
  return outM(C);
}

// hemm / symm: C = alpha A B + beta C (side 0) or alpha B A + beta C.
template <class T> Value smm(const Args &a, CallContext &ctx, bool herm) {
  T alpha;
  MatT<T> A, B;
  if (!getScal(a, 0, ctx, alpha) || !getSq(a, 1, ctx, A) || !getM(a, 2, ctx, B))
    return Value(0.0);
  const T beta = scal<T>(a, 3, T(0));
  const bool right = iopt(a, 5, 0) != 0, lower = iopt(a, 6, 0) != 0;
  MatT<T> F = fullSym(A, lower, herm);
  if ((!right && F.r != B.r) || (right && F.r != B.c)) {
    ctx.fail("the sizes of a and b do not match");
    return Value(0.0);
  }
  MatT<T> P = right ? mul(B, F) : mul(F, B);
  MatT<T> C(P.r, P.c);
  if (given(a, 4) && isMatrixLike(a[4])) {
    if (!getM(a, 4, ctx, C))
      return Value(0.0);
    if (C.r != P.r || C.c != P.c) {
      ctx.fail("c has the wrong shape");
      return Value(0.0);
    }
  }
  for (size_t k = 0; k < C.a.size(); k++)
    C.a[k] = (beta == T(0) ? T(0) : beta * C.a[k]) + alpha * P.a[k];
  return outM(C);
}

// trmm / trsm: B = alpha op(A) B, alpha B op(A), or the solves.
template <class T> Value trmmsm(const Args &a, CallContext &ctx, bool solve) {
  T alpha;
  MatT<T> A, B;
  if (!getScal(a, 0, ctx, alpha) || !getM(a, 1, ctx, A) || !getM(a, 2, ctx, B))
    return Value(0.0);
  const bool right = iopt(a, 3, 0) != 0, lower = iopt(a, 4, 0) != 0;
  const char t = copt(a, 5, 'N');
  const bool unit = iopt(a, 6, 0) != 0;
  const size_t k = right ? B.c : B.r;
  if (A.r < k || A.c < k) {
    ctx.fail("a must be at least " + std::to_string(k) + " x " + std::to_string(k));
    return Value(0.0);
  }
  MatT<T> Ak(k, k);
  for (size_t i = 0; i < k; i++)
    for (size_t j = 0; j < k; j++)
      Ak(i, j) = A(i, j);
  for (auto &e : B.a)
    e *= alpha;
  if (!solve) {
    MatT<T> M = opOf(triOf(Ak, lower, unit), t);
    return outM(right ? mul(B, M) : mul(M, B));
  }
  if (!right) {
    triSolve(Ak, B, lower, t, unit);
    return outM(B);
  }
  // X op(A) = B  <=>  op(A)^T X^T = B^T.
  MatT<T> Bt = transposeOf(B);
  char t2 = t == 'N' ? 'T' : 'N';
  MatT<T> Use = Ak;
  if (t == 'C') {
    // X A^H = B  <=>  conj(A) X^T = B^T
    for (auto &e : Use.a)
      e = conjOf(e);
    t2 = 'N';
  }
  triSolve(Use, Bt, lower, t2, unit);
  return outM(transposeOf(Bt));
}

} // namespace

void registerBlwBlas(Registry &reg) {
  // ---- level 1 ----
  SP_ADD("blas_asum", 1, 4, "x, n, offx, incx") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x;
      if (!getV(a, 0, ctx, x))
        return Value(0.0);
      L1 s = readL1(a, 1, x.size(), false);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x"))
        return Value(0.0);
      double r = 0.0;
      for (const T &e : gather(x, s.n, s.offx, s.incx))
        r += cabs1(e);
      return Value(r);
    });
  } SP_ENDC
  SP_ADD("blas_axpy", 2, 8, "x, y, n, a, offx, incx, offy, incy") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x, y;
      if (!getV(a, 0, ctx, x) || !getV(a, 1, ctx, y))
        return Value(0.0);
      const T al = given(a, 3) ? scal<T>(a, 3, T(1)) : T(1);
      L1 s{};
      s.offx = iopt(a, 4, 0);
      s.incx = iopt(a, 5, 1);
      s.offy = iopt(a, 6, 0);
      s.incy = iopt(a, 7, 1);
      const long long dn = defaultN(x.size(), s.offx, s.incx);
      s.n = isOmitted(a, 2) ? dn : iopt(a, 2, dn);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x") ||
          !strideOk(ctx, y.size(), s.n, s.offy, s.incy, "y"))
        return Value(0.0);
      std::vector<T> xs = gather(x, s.n, s.offx, s.incx), ys = gather(y, s.n, s.offy, s.incy);
      for (size_t i = 0; i < ys.size(); i++)
        ys[i] += al * xs[i];
      scatter(y, ys, s.offy, s.incy);
      return outV(y);
    });
  } SP_ENDC
  SP_ADD("blas_copy", 2, 7, "x, y, n, offx, incx, offy, incy") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x, y;
      if (!getV(a, 0, ctx, x) || !getV(a, 1, ctx, y))
        return Value(0.0);
      L1 s = readL1(a, 2, x.size(), true);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x") ||
          !strideOk(ctx, y.size(), s.n, s.offy, s.incy, "y"))
        return Value(0.0);
      scatter(y, gather(x, s.n, s.offx, s.incx), s.offy, s.incy);
      return outV(y);
    });
  } SP_ENDC
  // dot, dotu and dotc share one body; conj marks dotc.
  static const auto dotBody = [](const Args &a, CallContext &ctx, bool conj, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x, y;
      if (!getV(a, 0, ctx, x) || !getV(a, 1, ctx, y))
        return Value(0.0);
      L1 s = readL1(a, 2, x.size(), true);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x") ||
          !strideOk(ctx, y.size(), s.n, s.offy, s.incy, "y"))
        return Value(0.0);
      std::vector<T> xs = gather(x, s.n, s.offx, s.incx), ys = gather(y, s.n, s.offy, s.incy);
      T r(0);
      for (size_t i = 0; i < xs.size(); i++)
        r += (conj ? conjOf(xs[i]) : xs[i]) * ys[i];
      return num(r);
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("blas_dot", 2, 7, "x, y, n, offx, incx, offy, incy") {
    return dotBody(a, ctx, false, false);
  } SP_ENDC
  SP_ADD("blas_dotu", 2, 7, "x, y, n, offx, incx, offy, incy") {
    return dotBody(a, ctx, false, true);
  } SP_ENDC
  SP_ADD("blas_dotc", 2, 7, "x, y, n, offx, incx, offy, incy") {
    return dotBody(a, ctx, true, true);
  } SP_ENDC
  SP_ADD("blas_iamax", 1, 4, "x, n, offx, incx") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x;
      if (!getV(a, 0, ctx, x))
        return Value(0.0);
      L1 s = readL1(a, 1, x.size(), false);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x"))
        return Value(0.0);
      std::vector<T> xs = gather(x, s.n, s.offx, s.incx);
      long long k = 0;
      double best = -1.0;
      for (size_t i = 0; i < xs.size(); i++)
        if (cabs1(xs[i]) > best) {
          best = cabs1(xs[i]);
          k = static_cast<long long>(i);
        }
      if (xs.empty())
        k = -1;
      return inum(k);
    });
  } SP_ENDC
  SP_ADD("blas_nrm2", 1, 4, "x, n, offx, incx") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x;
      if (!getV(a, 0, ctx, x))
        return Value(0.0);
      L1 s = readL1(a, 1, x.size(), false);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x"))
        return Value(0.0);
      double scale = 0.0, ssq = 1.0;
      for (const T &e : gather(x, s.n, s.offx, s.incx))
        for (double part : {realOf(e), imagOf(e)}) {
          if (part == 0.0)
            continue;
          double v = std::fabs(part);
          if (scale < v) {
            ssq = 1.0 + ssq * (scale / v) * (scale / v);
            scale = v;
          } else {
            ssq += (v / scale) * (v / scale);
          }
        }
      return Value(scale * std::sqrt(ssq));
    });
  } SP_ENDC
  SP_ADD("blas_rot", 4, 9, "x, y, c, s, n, offx, incx, offy, incy") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x, y;
      double c;
      if (!getV(a, 0, ctx, x) || !getV(a, 1, ctx, y) || !argNumber(a, 2, ctx, c))
        return Value(0.0);
      if (!given(a, 3) || !isPlainNumber(a[3])) {
        ctx.fail("the fourth argument must be a number");
        return Value(0.0);
      }
      const T sn = scal<T>(a, 3, T(0));
      L1 s = readL1(a, 4, x.size(), true, true);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x") ||
          !strideOk(ctx, y.size(), s.n, s.offy, s.incy, "y"))
        return Value(0.0);
      std::vector<T> xs = gather(x, s.n, s.offx, s.incx), ys = gather(y, s.n, s.offy, s.incy);
      for (size_t i = 0; i < xs.size(); i++) {
        T xi = xs[i], yi = ys[i];
        xs[i] = T(c) * xi + sn * yi;
        ys[i] = T(c) * yi - conjOf(sn) * xi;
      }
      scatter(x, xs, s.offx, s.incx);
      scatter(y, ys, s.offy, s.incy);
      return makeDict({{"x", outV(x)}, {"y", outV(y)}});
    });
  } SP_ENDC
  SP_ADD("blas_rotg", 2, 2, "a, b") {
    if (!isNumberArg(a, 0) || !isNumberArg(a, 1)) {
      ctx.fail("a and b must be numbers");
      return Value(0.0);
    }
    if (anyComplex(a)) {
      const cd ca = scal<cd>(a, 0, 0.0), cb = scal<cd>(a, 1, 0.0);
      cd c, s;
      if (std::abs(ca) == 0.0) {
        c = 0.0;
        s = 1.0;
      } else {
        const double scale = std::abs(ca) + std::abs(cb);
        const double nrm = scale * std::sqrt(std::norm(ca / scale) + std::norm(cb / scale));
        const cd alpha = ca / std::abs(ca);
        c = std::abs(ca) / nrm;
        s = alpha * std::conj(cb) / nrm;
      }
      return makeDict({{"c", cellOf(c)}, {"s", cellOf(s)}});
    }
    const double x = a[0].number, y = a[1].number;
    double c = 1.0, s = 0.0;
    if (y != 0.0) {
      if (x == 0.0) {
        c = 0.0;
        s = 1.0;
      } else {
        const double roe = std::fabs(x) > std::fabs(y) ? x : y;
        double r = std::hypot(x, y);
        if (roe < 0)
          r = -r;
        c = x / r;
        s = y / r;
      }
    }
    return makeDict({{"c", Value(c)}, {"s", Value(s)}});
  } SP_ENDC
  SP_ADD("blas_rotm", 3, 8, "x, y, param, n, offx, incx, offy, incy") {
    Vec x, y, p;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y) || !getVec(a, 2, ctx, p))
      return Value(0.0);
    if (p.size() < 5) {
      ctx.fail("param must hold 5 values");
      return Value(0.0);
    }
    L1 s = readL1(a, 3, x.size(), true);
    if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x") ||
        !strideOk(ctx, y.size(), s.n, s.offy, s.incy, "y"))
      return Value(0.0);
    const double flag = p[0];
    double h11 = p[1], h21 = p[2], h12 = p[3], h22 = p[4];
    if (flag == 0.0) {
      h11 = 1.0;
      h22 = 1.0;
    } else if (flag == 1.0) {
      h12 = 1.0;
      h21 = -1.0;
    }
    if (flag != -2.0) {
      Vec xs = gather(x, s.n, s.offx, s.incx), ys = gather(y, s.n, s.offy, s.incy);
      for (size_t i = 0; i < xs.size(); i++) {
        const double w = xs[i], zz = ys[i];
        xs[i] = h11 * w + h12 * zz;
        ys[i] = h21 * w + h22 * zz;
      }
      scatter(x, xs, s.offx, s.incx);
      scatter(y, ys, s.offy, s.incy);
    }
    return makeDict({{"x", toValue(x)}, {"y", toValue(y)}});
  } SP_END
  SP_ADD("blas_rotmg", 4, 4, "d1, d2, x1, y1") {
    double d1, d2, x1, y1;
    if (!argNumber(a, 0, ctx, d1) || !argNumber(a, 1, ctx, d2) || !argNumber(a, 2, ctx, x1) ||
        !argNumber(a, 3, ctx, y1))
      return Value(0.0);
    const double gam = 4096.0, gamsq = gam * gam, rgamsq = 1.0 / gamsq;
    double flag = 0.0, h11 = 0.0, h12 = 0.0, h21 = 0.0, h22 = 0.0;
    Vec param(5, 0.0);
    if (d1 < 0.0) {
      flag = -1.0;
      d1 = d2 = x1 = 0.0;
    } else {
      const double p2 = d2 * y1;
      if (p2 == 0.0) {
        param[0] = -2.0;
        return toValue(param);
      }
      const double p1 = d1 * x1, q2 = p2 * y1, q1 = p1 * x1;
      if (std::fabs(q1) > std::fabs(q2)) {
        h21 = -y1 / x1;
        h12 = p2 / p1;
        const double u = 1.0 - h12 * h21;
        if (u > 0.0) {
          flag = 0.0;
          d1 /= u;
          d2 /= u;
          x1 *= u;
        } else {
          flag = -1.0;
          h11 = h12 = h21 = h22 = 0.0;
          d1 = d2 = x1 = 0.0;
        }
      } else if (q2 < 0.0) {
        flag = -1.0;
        h11 = h12 = h21 = h22 = 0.0;
        d1 = d2 = x1 = 0.0;
      } else {
        flag = 1.0;
        h11 = p1 / p2;
        h22 = x1 / y1;
        const double u = 1.0 + h11 * h22, t = d2 / u;
        d2 = d1 / u;
        d1 = t;
        x1 = y1 * u;
      }
      auto fix = [&]() {
        if (flag == 0.0) {
          h11 = 1.0;
          h22 = 1.0;
        } else {
          h21 = -1.0;
          h12 = 1.0;
        }
        flag = -1.0;
      };
      // Rescaling cannot help an infinite or NaN d1 / d2; the count bounds the loops.
      int guard = 0;
      if (d1 != 0.0 && std::isfinite(d1))
        while ((d1 <= rgamsq || d1 >= gamsq) && guard++ < 4000) {
          fix();
          if (d1 <= rgamsq) {
            d1 *= gam * gam;
            x1 /= gam;
            h11 /= gam;
            h12 /= gam;
          } else {
            d1 /= gam * gam;
            x1 *= gam;
            h11 *= gam;
            h12 *= gam;
          }
        }
      guard = 0;
      if (d2 != 0.0 && std::isfinite(d2))
        while ((std::fabs(d2) <= rgamsq || std::fabs(d2) >= gamsq) && guard++ < 4000) {
          fix();
          if (std::fabs(d2) <= rgamsq) {
            d2 *= gam * gam;
            h21 /= gam;
            h22 /= gam;
          } else {
            d2 /= gam * gam;
            h21 *= gam;
            h22 *= gam;
          }
        }
    }
    if (flag < 0.0) {
      param[1] = h11;
      param[2] = h21;
      param[3] = h12;
      param[4] = h22;
    } else if (flag == 0.0) {
      param[2] = h21;
      param[3] = h12;
    } else {
      param[1] = h11;
      param[4] = h22;
    }
    param[0] = flag;
    return toValue(param);
  } SP_END
  SP_ADD("blas_scal", 2, 5, "a, x, n, offx, incx") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      T al;
      std::vector<T> x;
      if (!getScal(a, 0, ctx, al) || !getV(a, 1, ctx, x))
        return Value(0.0);
      L1 s = readL1(a, 2, x.size(), false);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x"))
        return Value(0.0);
      std::vector<T> xs = gather(x, s.n, s.offx, s.incx);
      for (auto &e : xs)
        e *= al;
      scatter(x, xs, s.offx, s.incx);
      return outV(x);
    });
  } SP_ENDC
  SP_ADD("blas_swap", 2, 7, "x, y, n, offx, incx, offy, incy") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x, y;
      if (!getV(a, 0, ctx, x) || !getV(a, 1, ctx, y))
        return Value(0.0);
      L1 s = readL1(a, 2, x.size(), true);
      if (!strideOk(ctx, x.size(), s.n, s.offx, s.incx, "x") ||
          !strideOk(ctx, y.size(), s.n, s.offy, s.incy, "y"))
        return Value(0.0);
      std::vector<T> xs = gather(x, s.n, s.offx, s.incx), ys = gather(y, s.n, s.offy, s.incy);
      scatter(x, ys, s.offx, s.incx);
      scatter(y, xs, s.offy, s.incy);
      return makeDict({{"x", outV(x)}, {"y", outV(y)}});
    });
  } SP_ENDC

  // ---- level 2 ----
  SP_ADD("blas_gemv", 3, 10, "alpha, a, x, beta, y, offx, incx, offy, incy, trans") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      T alpha;
      MatT<T> A;
      std::vector<T> x;
      if (!getScal(a, 0, ctx, alpha) || !getM(a, 1, ctx, A) || !getV(a, 2, ctx, x))
        return Value(0.0);
      const T beta = scal<T>(a, 3, T(0));
      return mv(a, ctx, opOf(A, copt(a, 9, 'N')), alpha, x, iopt(a, 5, 0), iopt(a, 6, 1), beta, 4,
                iopt(a, 7, 0), iopt(a, 8, 1));
    });
  } SP_ENDC
  SP_ADD("blas_gbmv", 7, 14, "m, n, kl, ku, alpha, a, x, incx, offx, beta, y, incy, offy, trans") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long m, n, kl, ku;
      T alpha;
      MatT<T> ab;
      std::vector<T> x;
      if (!getI(a, 0, ctx, m) || !getI(a, 1, ctx, n) || !getI(a, 2, ctx, kl) || !getI(a, 3, ctx, ku) ||
          !getScal(a, 4, ctx, alpha) || !getM(a, 5, ctx, ab) || !getV(a, 6, ctx, x))
        return Value(0.0);
      if (m < 0 || n < 0 || kl < 0 || ku < 0 || ab.r < static_cast<size_t>(kl + ku + 1) ||
          ab.c < static_cast<size_t>(n)) {
        ctx.fail("the band array must be at least (kl+ku+1) x n");
        return Value(0.0);
      }
      MatT<T> A = gbToDense(ab, static_cast<size_t>(m), static_cast<size_t>(n), kl, ku);
      const T beta = scal<T>(a, 9, T(0));
      return mv(a, ctx, opOf(A, copt(a, 13, 'N')), alpha, x, iopt(a, 8, 0), iopt(a, 7, 1), beta, 10,
                iopt(a, 12, 0), iopt(a, 11, 1));
    });
  } SP_ENDC
  SP_ADD("blas_ger", 3, 6, "alpha, x, y, incx, incy, a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return ger<T>(a, ctx, false);
    });
  } SP_ENDC
  SP_ADD("blas_geru", 3, 6, "alpha, x, y, incx, incy, a") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return ger<T>(a, ctx, false);
    });
  } SP_ENDC
  SP_ADD("blas_gerc", 3, 6, "alpha, x, y, incx, incy, a") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return ger<T>(a, ctx, true);
    });
  } SP_ENDC
  // Band and packed symmetric/Hermitian products.
  static const auto sbmvBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      long long k;
      T alpha;
      MatT<T> ab;
      std::vector<T> x;
      if (!getI(a, 0, ctx, k) || !getScal(a, 1, ctx, alpha) || !getM(a, 2, ctx, ab) ||
          !getV(a, 3, ctx, x))
        return Value(0.0);
      if (k < 0 || ab.r < static_cast<size_t>(k + 1)) {
        ctx.fail("the band array must have at least k+1 rows");
        return Value(0.0);
      }
      const bool lower = iopt(a, 10, 0) != 0;
      MatT<T> F = fullSym(sbToDense(ab, k, lower), lower, herm);
      return bandPackedMv(a, ctx, F, alpha, x, 4);
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("blas_sbmv", 4, 11, "k, alpha, a, x, incx, offx, beta, y, incy, offy, lower") {
    return sbmvBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("blas_hbmv", 4, 11, "k, alpha, a, x, incx, offx, beta, y, incy, offy, lower") {
    return sbmvBody(a, ctx, true);
  } SP_ENDC
  static const auto spmvBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      T alpha;
      std::vector<T> ap, x;
      if (!getI(a, 0, ctx, n) || !getScal(a, 1, ctx, alpha) || !getV(a, 2, ctx, ap) ||
          !getV(a, 3, ctx, x) || !packedOk(ctx, ap.size(), n))
        return Value(0.0);
      const bool lower = iopt(a, 10, 0) != 0;
      MatT<T> F = fullSym(packedToTri(ap, static_cast<size_t>(n), lower), lower, herm);
      return bandPackedMv(a, ctx, F, alpha, x, 4);
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("blas_spmv", 4, 11, "n, alpha, ap, x, incx, offx, beta, y, incy, offy, lower") {
    return spmvBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("blas_hpmv", 4, 11, "n, alpha, ap, x, incx, offx, beta, y, incy, offy, lower") {
    return spmvBody(a, ctx, true);
  } SP_ENDC
  static const auto symvBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      T alpha;
      MatT<T> A;
      std::vector<T> x;
      if (!getScal(a, 0, ctx, alpha) || !getSq(a, 1, ctx, A) || !getV(a, 2, ctx, x))
        return Value(0.0);
      const T beta = scal<T>(a, 3, T(0));
      const bool lower = iopt(a, 9, 0) != 0;
      return mv(a, ctx, fullSym(A, lower, herm), alpha, x, iopt(a, 5, 0), iopt(a, 6, 1), beta, 4,
                iopt(a, 7, 0), iopt(a, 8, 1));
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("blas_symv", 3, 10, "alpha, a, x, beta, y, offx, incx, offy, incy, lower") {
    return symvBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("blas_hemv", 3, 10, "alpha, a, x, beta, y, offx, incx, offy, incy, lower") {
    return symvBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("blas_syr", 2, 7, "alpha, x, lower, incx, offx, n, a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return r12<T>(a, ctx, false, false);
    });
  } SP_ENDC
  SP_ADD("blas_her", 2, 7, "alpha, x, lower, incx, offx, n, a") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return r12<T>(a, ctx, false, true);
    });
  } SP_ENDC
  SP_ADD("blas_syr2", 3, 10, "alpha, x, y, lower, incx, offx, incy, offy, n, a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return r12<T>(a, ctx, true, false);
    });
  } SP_ENDC
  SP_ADD("blas_her2", 3, 10, "alpha, x, y, lower, incx, offx, incy, offy, n, a") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return r12<T>(a, ctx, true, true);
    });
  } SP_ENDC
  SP_ADD("blas_spr", 4, 7, "n, alpha, x, ap, incx, offx, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return pr12<T>(a, ctx, false, false);
    });
  } SP_ENDC
  SP_ADD("blas_hpr", 4, 7, "n, alpha, x, ap, incx, offx, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return pr12<T>(a, ctx, false, true);
    });
  } SP_ENDC
  SP_ADD("blas_spr2", 5, 10, "n, alpha, x, y, ap, incx, offx, incy, offy, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return pr12<T>(a, ctx, true, false);
    });
  } SP_ENDC
  SP_ADD("blas_hpr2", 5, 10, "n, alpha, x, y, ap, incx, offx, incy, offy, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return pr12<T>(a, ctx, true, true);
    });
  } SP_ENDC
  // Triangular products and solves: band, packed and full storage.
  static const auto tbBody = [](const Args &a, CallContext &ctx, bool solve) -> Value {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long k;
      MatT<T> ab;
      std::vector<T> x;
      if (!getI(a, 0, ctx, k) || !getM(a, 1, ctx, ab) || !getV(a, 2, ctx, x))
        return Value(0.0);
      if (k < 0 || ab.r < static_cast<size_t>(k + 1)) {
        ctx.fail("the band array must have at least k+1 rows");
        return Value(0.0);
      }
      const bool lower = iopt(a, 5, 0) != 0;
      return trv(ctx, sbToDense(ab, k, lower), lower, copt(a, 6, 'N'), iopt(a, 7, 0) != 0, x,
                 iopt(a, 4, 0), iopt(a, 3, 1), solve);
    });
  };
  SP_ADD("blas_tbmv", 3, 8, "k, a, x, incx, offx, lower, trans, diag") {
    return tbBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("blas_tbsv", 3, 8, "k, a, x, incx, offx, lower, trans, diag") {
    return tbBody(a, ctx, true);
  } SP_ENDC
  static const auto tpBody = [](const Args &a, CallContext &ctx, bool solve) -> Value {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      std::vector<T> ap, x;
      if (!getI(a, 0, ctx, n) || !getV(a, 1, ctx, ap) || !getV(a, 2, ctx, x) ||
          !packedOk(ctx, ap.size(), n))
        return Value(0.0);
      const bool lower = iopt(a, 5, 0) != 0;
      return trv(ctx, packedToTri(ap, static_cast<size_t>(n), lower), lower, copt(a, 6, 'N'),
                 iopt(a, 7, 0) != 0, x, iopt(a, 4, 0), iopt(a, 3, 1), solve);
    });
  };
  SP_ADD("blas_tpmv", 3, 8, "n, ap, x, incx, offx, lower, trans, diag") {
    return tpBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("blas_tpsv", 3, 8, "n, ap, x, incx, offx, lower, trans, diag") {
    return tpBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("blas_trmv", 2, 7, "a, x, offx, incx, lower, trans, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      std::vector<T> x;
      if (!getSq(a, 0, ctx, A) || !getV(a, 1, ctx, x))
        return Value(0.0);
      return trv(ctx, A, iopt(a, 4, 0) != 0, copt(a, 5, 'N'), iopt(a, 6, 0) != 0, x, iopt(a, 2, 0),
                 iopt(a, 3, 1), false);
    });
  } SP_ENDC
  SP_ADD("blas_trsv", 2, 7, "a, x, incx, offx, lower, trans, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      std::vector<T> x;
      if (!getSq(a, 0, ctx, A) || !getV(a, 1, ctx, x))
        return Value(0.0);
      return trv(ctx, A, iopt(a, 4, 0) != 0, copt(a, 5, 'N'), iopt(a, 6, 0) != 0, x, iopt(a, 3, 0),
                 iopt(a, 2, 1), true);
    });
  } SP_ENDC

  // ---- level 3 ----
  SP_ADD("blas_gemm", 3, 7, "alpha, a, b, beta, c, trans_a, trans_b") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      T alpha;
      MatT<T> A, B;
      if (!getScal(a, 0, ctx, alpha) || !getM(a, 1, ctx, A) || !getM(a, 2, ctx, B))
        return Value(0.0);
      MatT<T> X = opOf(A, copt(a, 5, 'N')), Y = opOf(B, copt(a, 6, 'N'));
      if (X.c != Y.r) {
        ctx.fail("the inner sizes of op(a) and op(b) do not match");
        return Value(0.0);
      }
      const T beta = scal<T>(a, 3, T(0));
      MatT<T> P = mul(X, Y), C(P.r, P.c);
      if (given(a, 4) && isMatrixLike(a[4])) {
        if (!getM(a, 4, ctx, C))
          return Value(0.0);
        if (C.r != P.r || C.c != P.c) {
          ctx.fail("c has the wrong shape");
          return Value(0.0);
        }
      }
      for (size_t k = 0; k < C.a.size(); k++)
        C.a[k] = (beta == T(0) ? T(0) : beta * C.a[k]) + alpha * P.a[k];
      return outM(C);
    });
  } SP_ENDC
  SP_ADD("blas_symm", 3, 7, "alpha, a, b, beta, c, side, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return smm<T>(a, ctx, false);
    });
  } SP_ENDC
  SP_ADD("blas_hemm", 3, 7, "alpha, a, b, beta, c, side, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return smm<T>(a, ctx, true);
    });
  } SP_ENDC
  SP_ADD("blas_syrk", 2, 6, "alpha, a, beta, c, trans, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return rk<T>(a, ctx, false, false);
    });
  } SP_ENDC
  SP_ADD("blas_herk", 2, 6, "alpha, a, beta, c, trans, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return rk<T>(a, ctx, false, true);
    });
  } SP_ENDC
  SP_ADD("blas_syr2k", 3, 7, "alpha, a, b, beta, c, trans, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return rk<T>(a, ctx, true, false);
    });
  } SP_ENDC
  SP_ADD("blas_her2k", 3, 7, "alpha, a, b, beta, c, trans, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return rk<T>(a, ctx, true, true);
    });
  } SP_ENDC
  SP_ADD("blas_trmm", 3, 7, "alpha, a, b, side, lower, trans_a, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return trmmsm<T>(a, ctx, false);
    });
  } SP_ENDC
  SP_ADD("blas_trsm", 3, 7, "alpha, a, b, side, lower, trans_a, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return trmmsm<T>(a, ctx, true);
    });
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
