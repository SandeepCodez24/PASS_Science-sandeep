// Eigenproblems and Schur forms.
//   Symmetric / Hermitian: syev*, heev*, band sbev* / hbev*, generalized
//   sygv* / hegv*, reductions sygst / hegst and sytrd / hetrd.
//   Tridiagonal: stev, stevd, sterf, stebz, stein, stemr.
//   General: geev, gees, gehrd, orghr / unghr, gebal, gges, and the Schur
//   reorderings and Sylvester solvers trexc, trsen, tgexc, tgsen, trsyl, tgsyl.
//
// Reductions (sytrd, hetrd, gehrd, gebal) follow LAPACK step by step, so the
// stored reflectors match SciPy. Eigenvalues come from the dense kernels in
// linear_algebra/la_core; eigenvector signs and phases are arbitrary in LAPACK
// too. Real Schur reordering swaps 1x1 blocks with LAPACK's rotation and 2x2
// blocks through a small Sylvester solve. For real input, gges and the real
// generalized reorderings with 2x2 blocks work in complex arithmetic.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

// 'A', 'V' or 'I' from text, or from SciPy's integer codes 0 / 1 / 2.
char ropt(const Args &a, size_t i, char def) {
  if (i >= a.size())
    return def;
  if (a[i].isText) {
    std::string s = a[i].text();
    return s.empty() ? def : static_cast<char>(std::toupper(static_cast<unsigned char>(s[0])));
  }
  if (isPlainNumber(a[i])) {
    const int k = static_cast<int>(a[i].number);
    return k == 1 ? 'V' : (k == 2 ? 'I' : 'A');
  }
  return def;
}
// jobz / compute_v: "V"/"N" text or 1/0.
bool vopt(const Args &a, size_t i, bool def) {
  if (i >= a.size())
    return def;
  if (a[i].isText)
    return copt(a, i, def ? 'V' : 'N') == 'V';
  return iopt(a, i, def ? 1 : 0) != 0;
}
// uplo: "L"/"U" text or lower = 1/0.
bool lopt(const Args &a, size_t i, bool def) {
  if (i >= a.size())
    return def;
  if (a[i].isText)
    return copt(a, i, def ? 'L' : 'U') == 'L';
  return iopt(a, i, def ? 1 : 0) != 0;
}

// Indices (into ascending w) chosen by range A / V (vl < w <= vu) / I (il..iu, 1-based).
std::vector<size_t> pick(const Vec &w, char range, double vl, double vu, long long il, long long iu) {
  std::vector<size_t> k;
  for (size_t i = 0; i < w.size(); i++) {
    if (range == 'V' && !(w[i] > vl && w[i] <= vu))
      continue;
    if (range == 'I' && (static_cast<long long>(i) + 1 < il || static_cast<long long>(i) + 1 > iu))
      continue;
    k.push_back(i);
  }
  return k;
}
// The Hermitian eigenproblem of a full matrix, ascending.
template <class T> void heig(const MatT<T> &F, Vec &w, MatT<T> &V) { la::eigHermitian(F, w, V); }

// Result of a selected-eigenvalue routine: w (n values, first m used), z (n x cols).
template <class T>
Value selected(const Vec &w, const MatT<T> &V, const std::vector<size_t> &k, size_t cols, bool vecs,
               const char *zname, bool withIfail, bool withIsuppz) {
  const size_t n = w.size();
  Vec wo(n, 0.0);
  MatT<T> Z(vecs ? n : 0, vecs ? cols : 0);
  for (size_t j = 0; j < k.size(); j++) {
    wo[j] = w[k[j]];
    if (vecs && j < cols)
      for (size_t i = 0; i < n; i++)
        Z(i, j) = V(i, k[j]);
  }
  DictInit d{{"w", toValue(wo)}, {zname, outM(Z)}, {"m", inum(static_cast<long long>(k.size()))}};
  if (withIfail)
    d.push_back({"ifail", toValue(IVec(vecs ? n : 0, 0))});
  if (withIsuppz) {
    IVec s;
    for (size_t j = 0; j < k.size() && vecs; j++) {
      s.push_back(1);
      s.push_back(static_cast<long long>(n));
    }
    d.push_back({"isuppz", toValue(s)});
  }
  d.push_back({"info", inum(0)});
  return makeDict(d);
}

// ---- generalized symmetric-definite: reduce with the Cholesky factor ----

// C from A and the triangle factor F of B (xSYGST / xHEGST), as a full matrix.
template <class T> MatT<T> reduceGen(const MatT<T> &Afull, const MatT<T> &F, long long itype, bool lower) {
  const size_t n = Afull.r;
  MatT<T> Fac = triOf(F, lower, false); // U (B = U^H U) or L (B = L L^H)
  if (itype == 1) {
    // inv(U^H) A inv(U)  or  inv(L) A inv(L^H)
    MatT<T> X = Afull;
    if (lower) {
      triSolve(Fac, X, true, 'N', false); // inv(L) A
      MatT<T> Y = adjointOf(X);
      triSolve(Fac, Y, true, 'N', false); // inv(L) (inv(L) A)^H
      return adjointOf(Y);
    }
    triSolve(Fac, X, false, 'C', false); // inv(U^H) A
    MatT<T> Y = adjointOf(X);
    triSolve(Fac, Y, false, 'C', false);
    return adjointOf(Y);
  }
  (void)n;
  return lower ? mul(mul(adjointOf(Fac), Afull), Fac) : mul(mul(Fac, Afull), adjointOf(Fac));
}
template <class T> long long cholTri(MatT<T> &B, bool lower) {
  const size_t n = B.r;
  MatT<T> F = fullSym(B, lower, true), L;
  if (!la::cholLower(F, L)) {
    // Find the failing order as xPOTRF reports it.
    for (size_t k = 1; k <= n; k++) {
      MatT<T> Sub(k, k), Lk;
      for (size_t i = 0; i < k; i++)
        for (size_t j = 0; j < k; j++)
          Sub(i, j) = F(i, j);
      if (!la::cholLower(Sub, Lk))
        return static_cast<long long>(k);
    }
    return static_cast<long long>(n);
  }
  B = lower ? L : adjointOf(L);
  return 0;
}
// sygv / hegv family: eigenvalues ascending and B-normalized vectors.
template <class T>
long long genEig(MatT<T> A, MatT<T> B, long long itype, bool lower, Vec &w, MatT<T> &Z) {
  const size_t n = A.r;
  MatT<T> Bf = B;
  const long long info = cholTri(Bf, lower);
  if (info)
    return static_cast<long long>(n) + info;
  MatT<T> C = reduceGen(fullSym(A, lower, true), Bf, itype, lower);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < i; j++) {
      T avg = (C(i, j) + conjOf(C(j, i))) * T(0.5);
      C(i, j) = avg;
      C(j, i) = conjOf(avg);
    }
  MatT<T> Y;
  heig(C, w, Y);
  MatT<T> Fac = triOf(Bf, lower, false);
  if (itype == 3) {
    Z = lower ? mul(Fac, Y) : mul(adjointOf(Fac), Y);
  } else {
    Z = Y;
    if (lower)
      triSolve(Fac, Z, true, 'C', false);
    else
      triSolve(Fac, Z, false, 'N', false);
  }
  return 0;
}

// ---- tridiagonal reduction (xSYTD2 / xHETD2) ----
template <class T> Value sytd2(MatT<T> A, bool lower) {
  const size_t n = A.r;
  Vec d(n, 0.0), e(n ? n - 1 : 0, 0.0);
  std::vector<T> tau(n ? n - 1 : 0, T(0));
  // y = taui * herm(A(rows r0.., cols r0..)) * v on the stored triangle.
  auto hemv = [&](size_t r0, size_t len, T alpha, const std::vector<T> &v) {
    std::vector<T> y(len, T(0));
    for (size_t i = 0; i < len; i++)
      for (size_t j = 0; j < len; j++) {
        const size_t gi = r0 + i, gj = r0 + j;
        T aij;
        if (i == j)
          aij = T(realOf(A(gi, gi)));
        else if (lower ? gi > gj : gi < gj)
          aij = A(gi, gj);
        else
          aij = conjOf(A(gj, gi));
        y[i] += aij * v[j];
      }
    for (auto &x : y)
      x *= alpha;
    return y;
  };
  auto her2 = [&](size_t r0, size_t len, const std::vector<T> &x, const std::vector<T> &y) {
    for (size_t i = 0; i < len; i++)
      for (size_t j = 0; j < len; j++) {
        if (lower ? i < j : i > j)
          continue;
        A(r0 + i, r0 + j) -= x[i] * conjOf(y[j]) + y[i] * conjOf(x[j]);
        if (i == j)
          A(r0 + i, r0 + i) = T(realOf(A(r0 + i, r0 + i)));
      }
  };
  auto dotc = [](const std::vector<T> &x, const std::vector<T> &y) {
    T s(0);
    for (size_t i = 0; i < x.size(); i++)
      s += conjOf(x[i]) * y[i];
    return s;
  };
  if (n == 0)
    return makeDict({{"c", outM(A)}, {"d", toValue(d)}, {"e", toValue(e)}, {"tau", outV(tau)}, {"info", inum(0)}});
  if (!lower) {
    A(n - 1, n - 1) = T(realOf(A(n - 1, n - 1)));
    for (size_t i = n - 1; i-- > 0;) {
      // Reflector on A(0..i, i+1): alpha = A(i, i+1), x = A(0..i-1, i+1).
      T alpha = A(i, i + 1);
      std::vector<T> x(i);
      for (size_t r = 0; r < i; r++)
        x[r] = A(r, i + 1);
      const T taui = larfg(alpha, i ? x.data() : nullptr, i, 1);
      for (size_t r = 0; r < i; r++)
        A(r, i + 1) = x[r];
      e[i] = realOf(alpha);
      if (taui != T(0)) {
        A(i, i + 1) = T(1);
        std::vector<T> v(i + 1);
        for (size_t r = 0; r <= i; r++)
          v[r] = A(r, i + 1);
        std::vector<T> w = hemv(0, i + 1, taui, v);
        const T al = T(-0.5) * taui * dotc(w, v);
        for (size_t r = 0; r <= i; r++)
          w[r] += al * v[r];
        her2(0, i + 1, v, w);
      } else {
        A(i, i) = T(realOf(A(i, i)));
      }
      A(i, i + 1) = T(e[i]);
      d[i + 1] = realOf(A(i + 1, i + 1));
      tau[i] = taui;
    }
    d[0] = realOf(A(0, 0));
  } else {
    A(0, 0) = T(realOf(A(0, 0)));
    for (size_t i = 0; i + 1 < n; i++) {
      T alpha = A(i + 1, i);
      const size_t len = n - i - 1;
      std::vector<T> x(len - 1);
      for (size_t r = 0; r + 1 < len; r++)
        x[r] = A(i + 2 + r, i);
      const T taui = larfg(alpha, len > 1 ? x.data() : nullptr, len - 1, 1);
      for (size_t r = 0; r + 1 < len; r++)
        A(i + 2 + r, i) = x[r];
      e[i] = realOf(alpha);
      if (taui != T(0)) {
        A(i + 1, i) = T(1);
        std::vector<T> v(len);
        for (size_t r = 0; r < len; r++)
          v[r] = A(i + 1 + r, i);
        std::vector<T> w = hemv(i + 1, len, taui, v);
        const T al = T(-0.5) * taui * dotc(w, v);
        for (size_t r = 0; r < len; r++)
          w[r] += al * v[r];
        her2(i + 1, len, v, w);
      } else {
        A(i + 1, i + 1) = T(realOf(A(i + 1, i + 1)));
      }
      A(i + 1, i) = T(e[i]);
      d[i] = realOf(A(i, i));
      tau[i] = taui;
    }
    d[n - 1] = realOf(A(n - 1, n - 1));
  }
  return makeDict({{"c", outM(A)}, {"d", toValue(d)}, {"e", toValue(e)}, {"tau", outV(tau)}, {"info", inum(0)}});
}

// ---- Hessenberg reduction (xGEHD2), lo and hi 0-based ----
template <class T> std::vector<T> gehd2(MatT<T> &A, size_t lo, size_t hi) {
  const size_t n = A.r;
  std::vector<T> tau(n ? n - 1 : 0, T(0));
  for (size_t i = lo; i < hi; i++) {
    T alpha = A(i + 1, i);
    const size_t len = hi - i; // rows i+1 .. hi
    tau[i] = larfg(alpha, len > 1 ? &A(i + 2, i) : nullptr, len - 1, A.c);
    A(i + 1, i) = T(1);
    std::vector<T> v(len);
    for (size_t r = 0; r < len; r++)
      v[r] = A(i + 1 + r, i);
    // From the right on A(0..hi, i+1..hi).
    for (size_t r = 0; r <= hi; r++) {
      T s(0);
      for (size_t j = 0; j < len; j++)
        s += A(r, i + 1 + j) * v[j];
      s *= tau[i];
      for (size_t j = 0; j < len; j++)
        A(r, i + 1 + j) -= s * conjOf(v[j]);
    }
    // H^H from the left on A(i+1..hi, i+1..n-1).
    for (size_t c = i + 1; c < n; c++) {
      T s(0);
      for (size_t j = 0; j < len; j++)
        s += conjOf(v[j]) * A(i + 1 + j, c);
      s *= conjOf(tau[i]);
      for (size_t j = 0; j < len; j++)
        A(i + 1 + j, c) -= v[j] * s;
    }
    A(i + 1, i) = alpha;
  }
  return tau;
}
template <class T> MatT<T> qOfHess(const MatT<T> &A, const std::vector<T> &tau, size_t lo, size_t hi) {
  const size_t n = A.r;
  MatT<T> Q = MatT<T>::eye(n);
  for (size_t i = hi; i-- > lo;) {
    if (i >= tau.size())
      continue;
    std::vector<T> v(hi - i);
    v[0] = T(1);
    for (size_t r = i + 2; r <= hi; r++)
      v[r - i - 1] = A(r, i);
    applyH(Q, v, tau[i], true, i + 1, 0);
  }
  return Q;
}

// ---- balancing (xGEBAL, LAPACK 3.12) ----
template <class T> Value gebal(MatT<T> A, bool doScale, bool doPerm) {
  const size_t n = A.r;
  Vec scale(n, 1.0);
  long long k = 0, l = static_cast<long long>(n) - 1;
  auto nz = [&](size_t i, size_t j) { return A(i, j) != T(0); };
  if (n == 0)
    return makeDict({{"ba", outM(A)}, {"lo", inum(0)}, {"hi", inum(-1)}, {"pivscale", toValue(scale)}, {"info", inum(0)}});
  if (!doScale && !doPerm)
    return makeDict({{"ba", outM(A)}, {"lo", inum(0)}, {"hi", inum(static_cast<long long>(n) - 1)},
                     {"pivscale", toValue(scale)}, {"info", inum(0)}});
  if (doPerm) {
    bool noconv = true;
    while (noconv) {
      noconv = false;
      for (long long i = l; i >= 0; i--) {
        bool can = true;
        for (long long j = 0; j <= l; j++)
          if (i != j && nz(static_cast<size_t>(i), static_cast<size_t>(j))) {
            can = false;
            break;
          }
        if (can) {
          scale[static_cast<size_t>(l)] = static_cast<double>(i + 1);
          if (i != l) {
            for (long long r = 0; r <= l; r++)
              std::swap(A(static_cast<size_t>(r), static_cast<size_t>(i)), A(static_cast<size_t>(r), static_cast<size_t>(l)));
            for (size_t c = static_cast<size_t>(k); c < n; c++)
              std::swap(A(static_cast<size_t>(i), c), A(static_cast<size_t>(l), c));
          }
          noconv = true;
          if (l == 0)
            return makeDict({{"ba", outM(A)}, {"lo", inum(0)}, {"hi", inum(0)}, {"pivscale", toValue(scale)}, {"info", inum(0)}});
          l--;
        }
      }
    }
    noconv = true;
    while (noconv) {
      noconv = false;
      for (long long j = k; j <= l; j++) {
        bool can = true;
        for (long long i = k; i <= l; i++)
          if (i != j && nz(static_cast<size_t>(i), static_cast<size_t>(j))) {
            can = false;
            break;
          }
        if (can) {
          scale[static_cast<size_t>(k)] = static_cast<double>(j + 1);
          if (j != k) {
            for (long long r = 0; r <= l; r++)
              std::swap(A(static_cast<size_t>(r), static_cast<size_t>(j)), A(static_cast<size_t>(r), static_cast<size_t>(k)));
            for (size_t c = static_cast<size_t>(k); c < n; c++)
              std::swap(A(static_cast<size_t>(j), c), A(static_cast<size_t>(k), c));
          }
          noconv = true;
          k++;
        }
      }
    }
  }
  for (long long i = k; i <= l; i++)
    scale[static_cast<size_t>(i)] = 1.0;
  if (doScale) {
    const double sfmin1 = lamch('S') / lamch('P'), sfmax1 = 1.0 / sfmin1, sclfac = 2.0;
    const double sfmin2 = sfmin1 * sclfac, sfmax2 = 1.0 / sfmin2;
    bool noconv = true;
    int sweeps = 0;
    while (noconv && sweeps++ < 1000) {
      noconv = false;
      for (long long i = k; i <= l; i++) {
        const size_t I = static_cast<size_t>(i);
        double c = 0.0, r = 0.0, ca = 0.0, ra = 0.0;
        for (long long q = k; q <= l; q++) {
          c += absOf(A(static_cast<size_t>(q), I)) * absOf(A(static_cast<size_t>(q), I));
          r += absOf(A(I, static_cast<size_t>(q))) * absOf(A(I, static_cast<size_t>(q)));
        }
        c = std::sqrt(c);
        r = std::sqrt(r);
        size_t ica = 0;
        for (size_t q = 1; q <= static_cast<size_t>(l); q++)
          if (cabs1(A(q, I)) > cabs1(A(ica, I)))
            ica = q;
        ca = absOf(A(ica, I));
        size_t ira = static_cast<size_t>(k);
        for (size_t q = static_cast<size_t>(k) + 1; q < n; q++)
          if (cabs1(A(I, q)) > cabs1(A(I, ira)))
            ira = q;
        ra = absOf(A(I, ira));
        if (c == 0.0 || r == 0.0)
          continue;
        if (std::isnan(c + ca + r + ra))
          return makeDict({{"ba", outM(A)}, {"lo", inum(k)}, {"hi", inum(l)}, {"pivscale", toValue(scale)}, {"info", inum(-3)}});
        double g = r / sclfac, f = 1.0;
        const double s = c + r;
        while (c < g && std::max(f, std::max(c, ca)) < sfmax2 && std::min(r, std::min(g, ra)) > sfmin2) {
          f *= sclfac;
          c *= sclfac;
          ca *= sclfac;
          r /= sclfac;
          g /= sclfac;
          ra /= sclfac;
        }
        g = c / sclfac;
        while (g >= r && std::max(r, ra) < sfmax2 && std::min(std::min(f, c), std::min(g, ca)) > sfmin2) {
          f /= sclfac;
          c /= sclfac;
          g /= sclfac;
          ca /= sclfac;
          r *= sclfac;
          ra *= sclfac;
        }
        if (c + r >= 0.95 * s)
          continue;
        if (f < 1.0 && scale[I] < 1.0 && f * scale[I] <= sfmin1)
          continue;
        if (f > 1.0 && scale[I] > 1.0 && scale[I] >= sfmax1 / f)
          continue;
        g = 1.0 / f;
        scale[I] *= f;
        noconv = true;
        for (size_t q = static_cast<size_t>(k); q < n; q++)
          A(I, q) *= T(g);
        for (size_t q = 0; q <= static_cast<size_t>(l); q++)
          A(q, I) *= T(f);
      }
    }
  }
  return makeDict({{"ba", outM(A)}, {"lo", inum(k)}, {"hi", inum(l)}, {"pivscale", toValue(scale)}, {"info", inum(0)}});
}

// ---- Schur reordering ----

// Swaps the 1x1 diagonal entries k, k+1 of a triangular T (xTREXC / xLAEXC rotation).
template <class T> void swap1(MatT<T> &Tm, MatT<T> *Q, size_t k) {
  const size_t n = Tm.r;
  const T t11 = Tm(k, k), t22 = Tm(k + 1, k + 1);
  double cs;
  T sn, r;
  // xLARTG(T12, T22 - T11)
  {
    T f = Tm(k, k + 1), g = t22 - t11;
    if constexpr (isCx<T>()) {
      if (g == T(0)) {
        cs = 1.0;
        sn = T(0);
      } else if (f == T(0)) {
        cs = 0.0;
        sn = std::conj(g) / std::abs(g);
      } else {
        const double f2 = std::norm(f), g2 = std::norm(g), h2 = f2 + g2;
        cs = std::sqrt(f2 / h2);
        sn = std::conj(g) * (f / std::sqrt(f2 * h2));
      }
    } else {
      if (g == 0.0) {
        cs = 1.0;
        sn = 0.0;
      } else if (f == 0.0) {
        cs = 0.0;
        sn = g > 0 ? 1.0 : -1.0;
      } else {
        const double d = std::sqrt(f * f + g * g);
        cs = std::fabs(f) / d;
        sn = g / (f >= 0 ? d : -d);
      }
    }
    (void)r;
  }
  // Rows k, k+1 from column k+2; columns k, k+1 above row k.
  for (size_t j = k + 2; j < n; j++) {
    const T x = Tm(k, j), y = Tm(k + 1, j);
    Tm(k, j) = T(cs) * x + sn * y;
    Tm(k + 1, j) = T(cs) * y - conjOf(sn) * x;
  }
  for (size_t i = 0; i < k; i++) {
    const T x = Tm(i, k), y = Tm(i, k + 1);
    Tm(i, k) = T(cs) * x + conjOf(sn) * y;
    Tm(i, k + 1) = T(cs) * y - sn * x;
  }
  Tm(k, k) = t22;
  Tm(k + 1, k + 1) = t11;
  if (Q)
    for (size_t i = 0; i < Q->r; i++) {
      const T x = (*Q)(i, k), y = (*Q)(i, k + 1);
      (*Q)(i, k) = T(cs) * x + conjOf(sn) * y;
      (*Q)(i, k + 1) = T(cs) * y - sn * x;
    }
}

// xLANV2: standardizes the real 2x2 block at k of T (and Q).
void standardize2(Mat &Tm, Mat *Q, size_t k) {
  const size_t n = Tm.r;
  double a = Tm(k, k), b = Tm(k, k + 1), c = Tm(k + 1, k), d = Tm(k + 1, k + 1);
  double cs = 1.0, sn = 0.0;
  const double eps = lamch('P');
  auto sgn = [](double x, double y) { return y >= 0 ? std::fabs(x) : -std::fabs(x); };
  if (c == 0.0) {
  } else if (b == 0.0) {
    cs = 0.0;
    sn = 1.0;
    std::swap(a, d);
    b = -c;
    c = 0.0;
  } else if (a - d == 0.0 && (b > 0) != (c > 0)) {
  } else {
    const double temp = a - d;
    double p = 0.5 * temp;
    const double bcmax = std::max(std::fabs(b), std::fabs(c));
    const double bcmis = std::min(std::fabs(b), std::fabs(c)) * sgn(1.0, b) * sgn(1.0, c);
    const double scale = std::max(std::fabs(p), bcmax);
    double z = p / scale * p + bcmax / scale * bcmis;
    if (z >= 4.0 * eps) {
      z = p + sgn(std::sqrt(scale) * std::sqrt(z), p);
      a = d + z;
      d = d - bcmax / z * bcmis;
      const double tau = std::hypot(c, z);
      cs = z / tau;
      sn = c / tau;
      b = b - c;
      c = 0.0;
    } else {
      const double sigma = b + c;
      const double tau = std::hypot(sigma, temp);
      cs = std::sqrt(0.5 * (1.0 + std::fabs(sigma) / tau));
      sn = -(p / (tau * cs)) * sgn(1.0, sigma);
      const double aa = a * cs + b * sn, bb = -a * sn + b * cs, cc = c * cs + d * sn, dd = -c * sn + d * cs;
      a = aa * cs + cc * sn;
      b = bb * cs + dd * sn;
      c = -aa * sn + cc * cs;
      d = -bb * sn + dd * cs;
      const double t2 = 0.5 * (a + d);
      a = t2;
      d = t2;
      if (c != 0.0) {
        if (b != 0.0) {
          if ((b > 0) == (c > 0)) {
            const double sab = std::sqrt(std::fabs(b)), sac = std::sqrt(std::fabs(c));
            p = sgn(sab * sac, c);
            const double tau2 = 1.0 / std::sqrt(std::fabs(b + c));
            a = t2 + p;
            d = t2 - p;
            b = b - c;
            c = 0.0;
            const double cs1 = sab * tau2, sn1 = sac * tau2;
            const double t3 = cs * cs1 - sn * sn1;
            sn = cs * sn1 + sn * cs1;
            cs = t3;
          }
        } else {
          b = -c;
          c = 0.0;
          const double t3 = cs;
          cs = -sn;
          sn = t3;
        }
      }
    }
  }
  Tm(k, k) = a;
  Tm(k, k + 1) = b;
  Tm(k + 1, k) = c;
  Tm(k + 1, k + 1) = d;
  for (size_t j = k + 2; j < n; j++) {
    const double x = Tm(k, j), y = Tm(k + 1, j);
    Tm(k, j) = cs * x + sn * y;
    Tm(k + 1, j) = cs * y - sn * x;
  }
  for (size_t i = 0; i < k; i++) {
    const double x = Tm(i, k), y = Tm(i, k + 1);
    Tm(i, k) = cs * x + sn * y;
    Tm(i, k + 1) = cs * y - sn * x;
  }
  if (Q)
    for (size_t i = 0; i < Q->r; i++) {
      const double x = (*Q)(i, k), y = (*Q)(i, k + 1);
      (*Q)(i, k) = cs * x + sn * y;
      (*Q)(i, k + 1) = cs * y - sn * x;
    }
}
inline size_t blockAt(const Mat &Tm, size_t i) { return (i + 1 < Tm.r && Tm(i + 1, i) != 0.0) ? 2 : 1; }

// Swaps adjacent blocks of sizes n1, n2 at j1 of a real quasi-triangular T.
void swapReal(Mat &Tm, Mat *Q, size_t j1, size_t n1, size_t n2) {
  if (n1 == 1 && n2 == 1) {
    swap1(Tm, Q, j1);
    return;
  }
  const size_t n = Tm.r, p = n1 + n2;
  // T11 X - X T22 = T12, by the Kronecker system.
  Mat K(n1 * n2, n1 * n2);
  Vec rhs(n1 * n2);
  for (size_t c = 0; c < n2; c++)
    for (size_t r = 0; r < n1; r++) {
      const size_t row = c * n1 + r;
      rhs[row] = Tm(j1 + r, j1 + n1 + c);
      for (size_t q = 0; q < n1; q++)
        K(row, c * n1 + q) += Tm(j1 + r, j1 + q);
      for (size_t q = 0; q < n2; q++)
        K(row, q * n1 + r) -= Tm(j1 + n1 + q, j1 + n1 + c);
    }
  la::solveVec(K, rhs);
  Mat M(p, n2);
  for (size_t c = 0; c < n2; c++) {
    for (size_t r = 0; r < n1; r++)
      M(r, c) = -rhs[c * n1 + r];
    M(n1 + c, c) = 1.0;
  }
  Mat Qs, Rs;
  la::qrFactor(M, Qs, Rs);
  // Apply Qs^T T Qs on the block rows/columns, and Q Qs.
  for (size_t j = j1; j < n; j++) {
    Vec col(p);
    for (size_t i = 0; i < p; i++) {
      double s = 0.0;
      for (size_t q = 0; q < p; q++)
        s += Qs(q, i) * Tm(j1 + q, j);
      col[i] = s;
    }
    for (size_t i = 0; i < p; i++)
      Tm(j1 + i, j) = col[i];
  }
  for (size_t i = 0; i < std::min(n, j1 + p); i++) {
    Vec row(p);
    for (size_t j = 0; j < p; j++) {
      double s = 0.0;
      for (size_t q = 0; q < p; q++)
        s += Tm(i, j1 + q) * Qs(q, j);
      row[j] = s;
    }
    for (size_t j = 0; j < p; j++)
      Tm(i, j1 + j) = row[j];
  }
  if (Q)
    for (size_t i = 0; i < Q->r; i++) {
      Vec row(p);
      for (size_t j = 0; j < p; j++) {
        double s = 0.0;
        for (size_t q = 0; q < p; q++)
          s += (*Q)(i, j1 + q) * Qs(q, j);
        row[j] = s;
      }
      for (size_t j = 0; j < p; j++)
        (*Q)(i, j1 + j) = row[j];
    }
  for (size_t r = j1 + n2; r < j1 + p; r++)
    for (size_t c = j1; c < j1 + n2; c++)
      Tm(r, c) = 0.0;
  if (n2 == 2)
    standardize2(Tm, Q, j1);
  if (n1 == 2)
    standardize2(Tm, Q, j1 + n2);
  for (size_t i = j1 + 2; i < std::min(n, j1 + p + 1); i++)
    for (size_t j = j1; j + 1 < i; j++)
      Tm(i, j) = 0.0;
}
// Moves the block starting at ifst to start at ilst (0-based), as xTREXC.
void moveReal(Mat &Tm, Mat *Q, size_t ifst, size_t ilst) {
  const size_t n = Tm.r;
  if (ifst > 0 && Tm(ifst, ifst - 1) != 0.0)
    ifst--;
  if (ilst > 0 && Tm(ilst, ilst - 1) != 0.0)
    ilst--;
  size_t here = ifst;
  if (ifst < ilst) {
    const size_t nbf = blockAt(Tm, ifst);
    if (nbf == 2 && ilst + 1 < n && Tm(ilst + 1, ilst) != 0.0)
      ilst++;
    while (here < ilst) {
      const size_t nb = blockAt(Tm, here);
      if (here + nb >= n)
        break;
      const size_t nbn = blockAt(Tm, here + nb);
      swapReal(Tm, Q, here, nb, nbn);
      here += nbn;
    }
  } else {
    while (here > ilst) {
      size_t nbp = 1;
      if (here >= 2 && Tm(here - 1, here - 2) != 0.0)
        nbp = 2;
      const size_t nb = blockAt(Tm, here);
      swapReal(Tm, Q, here - nbp, nbp, nb);
      here -= nbp;
    }
  }
}

// Swaps entries k, k+1 of an upper triangular pencil (A, B), updating Q and Z.
template <class T> void swapPencil(MatT<T> &A, MatT<T> &B, MatT<T> *Q, MatT<T> *Z, size_t k) {
  const size_t n = A.r, p = k, q = k + 1;
  const T f = B(q, q) * A(p, p) - A(q, q) * B(p, p);
  const T h = B(q, q) * A(p, q) - A(q, q) * B(p, q);
  // Right rotation with first column along (h, -f).
  T x0 = h, x1 = -f;
  double nx = std::sqrt(absOf(x0) * absOf(x0) + absOf(x1) * absOf(x1));
  if (nx == 0.0) {
    x0 = T(1);
    x1 = T(0);
    nx = 1.0;
  }
  x0 /= T(nx);
  x1 /= T(nx);
  auto rotCols = [&](MatT<T> &M, size_t rows) {
    for (size_t i = 0; i < rows; i++) {
      const T u = M(i, p), v = M(i, q);
      M(i, p) = u * x0 + v * x1;
      M(i, q) = -u * conjOf(x1) + v * conjOf(x0);
    }
  };
  rotCols(A, std::min(n, q + 1));
  rotCols(B, std::min(n, q + 1));
  if (Z)
    rotCols(*Z, Z->r);
  const bool useA = absOf(A(p, p)) + absOf(A(q, p)) >= absOf(B(p, p)) + absOf(B(q, p));
  T y0 = useA ? A(p, p) : B(p, p), y1 = useA ? A(q, p) : B(q, p);
  const double ny = std::sqrt(absOf(y0) * absOf(y0) + absOf(y1) * absOf(y1));
  if (ny > 0.0) {
    y0 /= T(ny);
    y1 /= T(ny);
    auto rotRows = [&](MatT<T> &M) {
      for (size_t j = p; j < n; j++) {
        const T u = M(p, j), v = M(q, j);
        M(p, j) = conjOf(y0) * u + conjOf(y1) * v;
        M(q, j) = -y1 * u + y0 * v;
      }
    };
    rotRows(A);
    rotRows(B);
    if (Q)
      for (size_t i = 0; i < Q->r; i++) {
        const T u = (*Q)(i, p), v = (*Q)(i, q);
        (*Q)(i, p) = u * y0 + v * y1;
        (*Q)(i, q) = -u * conjOf(y1) + v * conjOf(y0);
      }
  }
  A(q, p) = T(0);
  B(q, p) = T(0);
}
template <class T> bool hasBlocks(const MatT<T> &A) {
  for (size_t i = 1; i < A.r; i++)
    if (A(i, i - 1) != T(0))
      return true;
  return false;
}

// Exact sep(T11, T22) = 1 / || inv(I (x) T11 - T22^T (x) I) ||_1, and the
// solution X of T11 X - X T22 = T12.
template <class T>
void sylvesterInfo(const MatT<T> &Tm, size_t m, double &s, double &sep, MatT<T> *Xout = nullptr) {
  const size_t n = Tm.r, n2 = n - m;
  if (m == 0 || m == n) {
    s = 1.0;
    double nr = 0.0;
    for (size_t j = 0; j < n; j++) {
      double c = 0.0;
      for (size_t i = 0; i < n; i++)
        c += absOf(Tm(i, j));
      nr = std::max(nr, c);
    }
    sep = nr;
    return;
  }
  const size_t N = m * n2;
  MatT<T> K(N, N);
  std::vector<T> rhs(N);
  for (size_t c = 0; c < n2; c++)
    for (size_t r = 0; r < m; r++) {
      const size_t row = c * m + r;
      rhs[row] = Tm(r, m + c);
      for (size_t q = 0; q < m; q++)
        K(row, c * m + q) += Tm(r, q);
      for (size_t q = 0; q < n2; q++)
        K(row, q * m + r) -= Tm(m + q, m + c);
    }
  MatT<T> Kinv;
  if (!la::inverse(K, Kinv)) {
    s = 0.0;
    sep = 0.0;
    return;
  }
  std::vector<T> x = mulVec(Kinv, rhs);
  double fr = 0.0;
  for (const T &v : x)
    fr += absOf(v) * absOf(v);
  s = 1.0 / std::sqrt(1.0 + fr);
  double nrm = 0.0;
  for (size_t j = 0; j < N; j++) {
    double c = 0.0;
    for (size_t i = 0; i < N; i++)
      c += absOf(Kinv(i, j));
    nrm = std::max(nrm, c);
  }
  sep = nrm > 0.0 ? 1.0 / nrm : 0.0;
  if (Xout) {
    *Xout = MatT<T>(m, n2);
    for (size_t c = 0; c < n2; c++)
      for (size_t r = 0; r < m; r++)
        (*Xout)(r, c) = x[c * m + r];
  }
}

// Eigenvalues of a real quasi-triangular T: wr, wi.
void realEigs(const Mat &Tm, Vec &wr, Vec &wi) {
  const size_t n = Tm.r;
  wr.assign(n, 0.0);
  wi.assign(n, 0.0);
  for (size_t i = 0; i < n;) {
    if (blockAt(Tm, i) == 2) {
      const double a = Tm(i, i), b = Tm(i, i + 1), c = Tm(i + 1, i);
      const double im = std::sqrt(std::fabs(b)) * std::sqrt(std::fabs(c));
      wr[i] = wr[i + 1] = a;
      wi[i] = im;
      wi[i + 1] = -im;
      i += 2;
    } else {
      wr[i] = Tm(i, i);
      i++;
    }
  }
}

// Unit vector with its largest-modulus component real and positive.
void normalizeVec(CVec &v) {
  double nr = 0.0;
  size_t im = 0;
  for (size_t i = 0; i < v.size(); i++) {
    nr += std::norm(v[i]);
    if (std::abs(v[i]) > std::abs(v[im]))
      im = i;
  }
  nr = std::sqrt(nr);
  if (nr == 0.0)
    return;
  const cd ph = v.empty() ? cd(1.0) : std::conj(v[im]) / std::abs(v[im]);
  for (auto &x : v)
    x = x * ph / nr;
}
// Eigenvectors of A for the given eigenvalues (matched to la::eigGeneral's).
CMat vectorsFor(const CMat &A, const CVec &lam) {
  CVec w;
  CMat V;
  la::eigGeneral(A, w, &V);
  const size_t n = A.r;
  CMat out(n, lam.size());
  std::vector<bool> used(w.size(), false);
  for (size_t j = 0; j < lam.size(); j++) {
    size_t best = 0;
    double bd = kInf;
    for (size_t k = 0; k < w.size(); k++)
      if (!used[k] && std::abs(w[k] - lam[j]) < bd) {
        bd = std::abs(w[k] - lam[j]);
        best = k;
      }
    if (!w.empty())
      used[best] = true;
    CVec v(n);
    for (size_t i = 0; i < n; i++)
      v[i] = V(i, best);
    normalizeVec(v);
    for (size_t i = 0; i < n; i++)
      out(i, j) = v[i];
  }
  return out;
}
// LAPACK's real eigenvector layout: pairs as (Re, Im) columns.
Mat realLayout(const CMat &V, const Vec &wi) {
  Mat R(V.r, V.c);
  for (size_t j = 0; j < V.c; j++) {
    if (wi[j] > 0.0 && j + 1 < V.c) {
      for (size_t i = 0; i < V.r; i++) {
        R(i, j) = V(i, j).real();
        R(i, j + 1) = V(i, j).imag();
      }
      j++;
    } else {
      for (size_t i = 0; i < V.r; i++)
        R(i, j) = V(i, j).real();
    }
  }
  return R;
}

// The generalized complex Schur form with beta real and non-negative (xHGEQZ).
void gschur(const CMat &A, const CMat &B, CMat &S, CMat &Tm, CMat &Q, CMat &Z) {
  la::complexQZ(A, B, S, Tm, Q, Z);
  const size_t n = A.r;
  for (size_t j = 0; j < n; j++) {
    const double ab = std::abs(Tm(j, j));
    if (ab == 0.0)
      continue;
    const cd ph = std::conj(Tm(j, j)) / ab;
    for (size_t i = 0; i < n; i++) {
      S(i, j) *= ph;
      Tm(i, j) *= ph;
      Z(i, j) *= ph;
    }
    Tm(j, j) = ab;
  }
}

// Kronecker solve of A R - L B = C, D R - L E = F (trans: the transposed system).
template <class T>
bool genSylvester(const MatT<T> &A, const MatT<T> &B, const MatT<T> &C, const MatT<T> &D, const MatT<T> &E,
                  const MatT<T> &F, bool trans, MatT<T> &R, MatT<T> &L, double &dif) {
  const size_t m = A.r, n = B.r, N = m * n;
  MatT<T> K(2 * N, 2 * N);
  std::vector<T> rhs(2 * N);
  auto idx = [&](size_t r, size_t c) { return c * m + r; };
  for (size_t c = 0; c < n; c++)
    for (size_t r = 0; r < m; r++) {
      const size_t row = idx(r, c);
      rhs[row] = C(r, c);
      rhs[N + row] = F(r, c);
      for (size_t q = 0; q < m; q++) {
        K(row, idx(q, c)) += A(r, q);
        K(N + row, idx(q, c)) += D(r, q);
      }
      for (size_t q = 0; q < n; q++) {
        K(row, N + idx(r, q)) -= B(q, c);
        K(N + row, N + idx(r, q)) -= E(q, c);
      }
    }
  MatT<T> Kop = trans ? adjointOf(K) : K;
  if (trans)
    for (size_t i = N; i < 2 * N; i++)
      rhs[i] = -rhs[i];
  MatT<T> U, V;
  Vec sv;
  la::svdThin(K, U, sv, V);
  dif = sv.empty() ? 0.0 : sv.back();
  if (!la::solveVec(Kop, rhs))
    return false;
  R = MatT<T>(m, n);
  L = MatT<T>(m, n);
  for (size_t c = 0; c < n; c++)
    for (size_t r = 0; r < m; r++) {
      R(r, c) = rhs[idx(r, c)];
      L(r, c) = rhs[N + idx(r, c)];
    }
  return true;
}

} // namespace

void registerBlwEig(Registry &reg) {
  // ---- symmetric / Hermitian, full storage ----
  static const auto syevBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      const bool vecs = vopt(a, 1, true), lower = iopt(a, 2, 0) != 0;
      Vec w;
      MatT<T> V;
      heig(fullSym(A, lower, true), w, V);
      return makeDict({{"w", toValue(w)}, {"v", outM(vecs ? V : A)}, {"info", inum(0)}});
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_syev", 1, 5, "a, compute_v, lower, lwork") {
    return syevBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_syevd", 1, 6, "a, compute_v, lower, lwork, liwork") {
    return syevBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_heev", 1, 5, "a, compute_v, lower, lwork") {
    return syevBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("lapack_heevd", 1, 7, "a, compute_v, lower, lwork, liwork, lrwork") {
    return syevBody(a, ctx, true);
  } SP_ENDC
  // syevr / syevx / heevr / heevx: a, compute_v, range, lower, vl, vu, il, iu, abstol, ...
  static const auto syevxBody = [](const Args &a, CallContext &ctx, bool herm, bool isR) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      const size_t n = A.r;
      const bool vecs = vopt(a, 1, true), lower = iopt(a, 3, 0) != 0;
      const char range = ropt(a, 2, 'A');
      const double vl = given(a, 4) && isPlainNumber(a[4]) ? a[4].number : 0.0;
      const double vu = given(a, 5) && isPlainNumber(a[5]) ? a[5].number : 1.0;
      const long long il = iopt(a, 6, 1), iu = given(a, 7) ? iopt(a, 7, static_cast<long long>(n)) : static_cast<long long>(n);
      if (range == 'I' && (il < 1 || iu < il || iu > static_cast<long long>(n))) {
        ctx.fail("il and iu must satisfy 1 <= il <= iu <= n");
        return Value(0.0);
      }
      if (range == 'V' && !(vl < vu)) {
        ctx.fail("vl must be less than vu");
        return Value(0.0);
      }
      Vec w;
      MatT<T> V;
      heig(fullSym(A, lower, true), w, V);
      const size_t cols = range == 'I' ? static_cast<size_t>(iu - il + 1) : std::max<size_t>(1, n);
      return selected(w, V, pick(w, range, vl, vu, il, iu), cols, vecs, "z", !isR, isR);
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_syevr", 1, 12, "a, compute_v, range, lower, vl, vu, il, iu, abstol, lwork, liwork") {
    return syevxBody(a, ctx, false, true);
  } SP_ENDC
  SP_ADD("lapack_syevx", 1, 11, "a, compute_v, range, lower, vl, vu, il, iu, abstol, lwork") {
    return syevxBody(a, ctx, false, false);
  } SP_ENDC
  SP_ADD("lapack_heevr", 1, 13, "a, compute_v, range, lower, vl, vu, il, iu, abstol, lwork, lrwork, liwork") {
    return syevxBody(a, ctx, true, true);
  } SP_ENDC
  SP_ADD("lapack_heevx", 1, 11, "a, compute_v, range, lower, vl, vu, il, iu, abstol, lwork") {
    return syevxBody(a, ctx, true, false);
  } SP_ENDC

  // ---- generalized symmetric-definite ----
  static const auto sygstBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      if (!getSq(a, 0, ctx, A) || !getSq(a, 1, ctx, B))
        return Value(0.0);
      if (A.r != B.r) {
        ctx.fail("a and b must have the same size");
        return Value(0.0);
      }
      const long long itype = iopt(a, 2, 1);
      const bool lower = iopt(a, 3, 0) != 0;
      if (itype < 1 || itype > 3) {
        ctx.fail("itype must be 1, 2 or 3");
        return Value(0.0);
      }
      for (size_t i = 0; i < B.r; i++)
        if (B(i, i) == T(0)) {
          ctx.fail("b must be a Cholesky factor with a nonzero diagonal");
          return Value(0.0);
        }
      MatT<T> C = reduceGen(fullSym(A, lower, true), B, itype, lower);
      MatT<T> out = A;
      putTri(out, C, lower);
      for (size_t i = 0; i < out.r; i++)
        out(i, i) = T(realOf(out(i, i)));
      return makeDict({{"c", outM(out)}, {"info", inum(0)}});
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_sygst", 2, 5, "a, b, itype, lower") {
    return sygstBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_hegst", 2, 5, "a, b, itype, lower") {
    return sygstBody(a, ctx, true);
  } SP_ENDC
  // sygv / sygvd / hegv / hegvd: a, b, itype, jobz, uplo, ...
  static const auto sygvBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      if (!getSq(a, 0, ctx, A) || !getSq(a, 1, ctx, B))
        return Value(0.0);
      if (A.r != B.r) {
        ctx.fail("a and b must have the same size");
        return Value(0.0);
      }
      const long long itype = iopt(a, 2, 1);
      if (itype < 1 || itype > 3) {
        ctx.fail("itype must be 1, 2 or 3");
        return Value(0.0);
      }
      const bool vecs = vopt(a, 3, true), lower = lopt(a, 4, true);
      Vec w;
      MatT<T> Z;
      const long long info = genEig(A, B, itype, lower, w, Z);
      if (info)
        return makeDict({{"w", toValue(Vec(A.r, 0.0))}, {"v", outM(A)}, {"info", inum(info)}});
      return makeDict({{"w", toValue(w)}, {"v", outM(vecs ? Z : A)}, {"info", inum(0)}});
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_sygv", 2, 8, "a, b, itype, jobz, uplo, lwork") {
    return sygvBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_sygvd", 2, 9, "a, b, itype, jobz, uplo, lwork, liwork") {
    return sygvBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_hegv", 2, 8, "a, b, itype, jobz, uplo, lwork") {
    return sygvBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("lapack_hegvd", 2, 10, "a, b, itype, jobz, uplo, lwork, lrwork, liwork") {
    return sygvBody(a, ctx, true);
  } SP_ENDC
  // sygvx / hegvx: a, b, itype, jobz, range, uplo, vl, vu, il, iu, abstol, lwork
  static const auto sygvxBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      if (!getSq(a, 0, ctx, A) || !getSq(a, 1, ctx, B))
        return Value(0.0);
      if (A.r != B.r) {
        ctx.fail("a and b must have the same size");
        return Value(0.0);
      }
      const size_t n = A.r;
      const long long itype = iopt(a, 2, 1);
      const bool vecs = vopt(a, 3, true), lower = lopt(a, 5, true);
      const char range = ropt(a, 4, 'A');
      const double vl = given(a, 6) && isPlainNumber(a[6]) ? a[6].number : 0.0;
      const double vu = given(a, 7) && isPlainNumber(a[7]) ? a[7].number : 1.0;
      const long long il = iopt(a, 8, 1), iu = given(a, 9) ? iopt(a, 9, static_cast<long long>(n)) : static_cast<long long>(n);
      if (itype < 1 || itype > 3 || (range == 'I' && (il < 1 || iu < il || iu > static_cast<long long>(n)))) {
        ctx.fail("itype must be 1..3 and 1 <= il <= iu <= n");
        return Value(0.0);
      }
      Vec w;
      MatT<T> Z;
      const long long info = genEig(A, B, itype, lower, w, Z);
      if (info)
        return makeDict({{"w", toValue(Vec(n, 0.0))}, {"z", outM(MatT<T>(n, n))}, {"m", inum(0)},
                         {"ifail", toValue(IVec(n, 0))}, {"info", inum(info)}});
      const size_t cols = range == 'I' ? static_cast<size_t>(iu - il + 1) : std::max<size_t>(1, n);
      return selected(w, Z, pick(w, range, vl, vu, il, iu), cols, vecs, "z", true, false);
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_sygvx", 2, 14, "a, b, itype, jobz, range, uplo, vl, vu, il, iu, abstol, lwork") {
    return sygvxBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_hegvx", 2, 14, "a, b, itype, jobz, range, uplo, vl, vu, il, iu, abstol, lwork") {
    return sygvxBody(a, ctx, true);
  } SP_ENDC

  // ---- tridiagonal reduction ----
  SP_ADD("lapack_sytrd", 1, 4, "a, lower, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return sytd2(A, iopt(a, 1, 0) != 0);
    });
  } SP_ENDC
  SP_ADD("lapack_hetrd", 1, 4, "a, lower, lwork") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return sytd2(A, iopt(a, 1, 0) != 0);
    });
  } SP_ENDC

  // ---- band ----
  // sbev / sbevd / hbevd: ab, compute_v, lower, ...
  static const auto sbevBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab;
      if (!getM(a, 0, ctx, ab))
        return Value(0.0);
      if (ab.r == 0) {
        ctx.fail("ab must have at least one row");
        return Value(0.0);
      }
      const bool vecs = vopt(a, 1, true), lower = iopt(a, 2, 0) != 0;
      const long long kd = static_cast<long long>(ab.r) - 1;
      Vec w;
      MatT<T> V;
      heig(fullSym(sbToDense(ab, kd, lower), lower, true), w, V);
      return makeDict({{"w", toValue(w)}, {"z", outM(vecs ? V : MatT<T>(1, 1))}, {"info", inum(0)}});
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_sbev", 1, 5, "ab, compute_v, lower, ldab") {
    return sbevBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_sbevd", 1, 6, "ab, compute_v, lower, ldab, liwork") {
    return sbevBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_hbevd", 1, 7, "ab, compute_v, lower, ldab, lrwork, liwork") {
    return sbevBody(a, ctx, true);
  } SP_ENDC
  // sbevx / hbevx: ab, vl, vu, il, iu, ldab, compute_v, range, lower, abstol, mmax
  static const auto sbevxBody = [](const Args &a, CallContext &ctx, bool herm) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab;
      double vl, vu;
      long long il, iu;
      if (!getM(a, 0, ctx, ab) || !argNumber(a, 1, ctx, vl) || !argNumber(a, 2, ctx, vu) || !getI(a, 3, ctx, il) ||
          !getI(a, 4, ctx, iu))
        return Value(0.0);
      if (ab.r == 0) {
        ctx.fail("ab must have at least one row");
        return Value(0.0);
      }
      const size_t n = ab.c;
      const bool vecs = vopt(a, 6, true), lower = iopt(a, 8, 0) != 0;
      const char range = ropt(a, 7, 'A');
      if (range == 'I' && (il < 1 || iu < il || iu > static_cast<long long>(n))) {
        ctx.fail("il and iu must satisfy 1 <= il <= iu <= n");
        return Value(0.0);
      }
      const long long kd = static_cast<long long>(ab.r) - 1;
      Vec w;
      MatT<T> V;
      heig(fullSym(sbToDense(ab, kd, lower), lower, true), w, V);
      const size_t mmax = given(a, 10) ? std::min<size_t>(n, static_cast<size_t>(std::max<long long>(iopt(a, 10, 1), 1)))
                                       : (vecs ? (range == 'I' ? static_cast<size_t>(iu - il + 1) : n) : 1);
      return selected(w, V, pick(w, range, vl, vu, il, iu), mmax, vecs, "z", true, false);
    };
    return herm ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_sbevx", 5, 12, "ab, vl, vu, il, iu, ldab, compute_v, range, lower, abstol, mmax") {
    return sbevxBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_hbevx", 5, 12, "ab, vl, vu, il, iu, ldab, compute_v, range, lower, abstol, mmax") {
    return sbevxBody(a, ctx, true);
  } SP_ENDC

  // ---- symmetric tridiagonal ----
  static const auto tridiagEig = [](const Vec &d, const Vec &e, Vec &w, Mat &V) {
    const size_t n = d.size();
    Mat Tm(n, n);
    for (size_t i = 0; i < n; i++) {
      Tm(i, i) = d[i];
      if (i + 1 < n && i < e.size())
        Tm(i, i + 1) = Tm(i + 1, i) = e[i];
    }
    la::eigHermitian(Tm, w, V);
  };
  static const auto getDE = [](const Args &a, CallContext &ctx, Vec &d, Vec &e) -> bool {
    if (!getVec(a, 0, ctx, d) || !getVec(a, 1, ctx, e))
      return false;
    if (e.size() + 1 < d.size()) {
      ctx.fail("e must hold n-1 values");
      return false;
    }
    e.resize(d.empty() ? 0 : d.size() - 1);
    return true;
  };
  SP_ADD("lapack_sterf", 2, 4, "d, e") {
    Vec d, e, w;
    Mat V;
    if (!getDE(a, ctx, d, e))
      return Value(0.0);
    tridiagEig(d, e, w, V);
    return makeDict({{"vals", toValue(w)}, {"info", inum(0)}});
  } SP_END
  static const auto stevBody = [](const Args &a, CallContext &ctx) -> Value {
    Vec d, e, w;
    Mat V;
    if (!getDE(a, ctx, d, e))
      return Value(0.0);
    tridiagEig(d, e, w, V);
    const bool vecs = vopt(a, 2, true);
    return makeDict({{"vals", toValue(w)}, {"z", toValue(vecs ? V : Mat(1, 1))}, {"info", inum(0)}});
  };
  SP_ADD("lapack_stev", 2, 5, "d, e, compute_v") {
    return stevBody(a, ctx);
  } SP_END
  SP_ADD("lapack_stevd", 2, 7, "d, e, compute_v, lwork, liwork") {
    return stevBody(a, ctx);
  } SP_END
  SP_ADD("lapack_stebz", 9, 9, "d, e, range, vl, vu, il, iu, tol, order") {
    Vec d, e;
    double vl, vu;
    long long il, iu;
    if (!getDE(a, ctx, d, e) || !argNumber(a, 3, ctx, vl) || !argNumber(a, 4, ctx, vu) || !getI(a, 5, ctx, il) ||
        !getI(a, 6, ctx, iu))
      return Value(0.0);
    const size_t n = d.size();
    const char range = ropt(a, 2, 'A'), order = copt(a, 8, 'E');
    if (range == 'I' && (il < 1 || iu < il || iu > static_cast<long long>(n))) {
      ctx.fail("il and iu must satisfy 1 <= il <= iu <= n");
      return Value(0.0);
    }
    // Split into blocks where an off-diagonal is negligible.
    const double eps = lamch('P'), safmin = lamch('S');
    IVec isplit;
    for (size_t j = 0; j + 1 < n; j++)
      if (e[j] * e[j] <= eps * eps * std::fabs(d[j] * d[j + 1]) + safmin)
        isplit.push_back(static_cast<long long>(j) + 1);
    isplit.push_back(static_cast<long long>(n));
    // Eigenvalues of each block, with the block number.
    std::vector<std::pair<double, long long>> all;
    size_t start = 0;
    for (size_t b = 0; b < isplit.size(); b++) {
      const size_t end = static_cast<size_t>(isplit[b]);
      Vec db(d.begin() + static_cast<long>(start), d.begin() + static_cast<long>(end)), eb, w;
      for (size_t j = start; j + 1 < end; j++)
        eb.push_back(e[j]);
      Mat V;
      tridiagEig(db, eb, w, V);
      for (double x : w)
        all.push_back({x, static_cast<long long>(b) + 1});
      start = end;
    }
    std::vector<std::pair<double, long long>> sorted = all;
    std::stable_sort(sorted.begin(), sorted.end(), [](const auto &x, const auto &y) { return x.first < y.first; });
    std::vector<bool> keep(all.size(), true);
    if (range != 'A') {
      for (size_t i = 0; i < sorted.size(); i++) {
        bool k = range == 'V' ? (sorted[i].first > vl && sorted[i].first <= vu)
                              : (static_cast<long long>(i) + 1 >= il && static_cast<long long>(i) + 1 <= iu);
        // mark the matching entry in `all`
        for (size_t j = 0; j < all.size(); j++)
          if (all[j] == sorted[i] && keep[j] && !k) {
            keep[j] = false;
            break;
          }
      }
    }
    std::vector<std::pair<double, long long>> out;
    const auto &src = order == 'B' ? all : sorted;
    std::vector<bool> keepS(src.size(), true);
    if (range != 'A') {
      std::vector<double> allowed;
      for (size_t i = 0; i < sorted.size(); i++) {
        bool k = range == 'V' ? (sorted[i].first > vl && sorted[i].first <= vu)
                              : (static_cast<long long>(i) + 1 >= il && static_cast<long long>(i) + 1 <= iu);
        if (k)
          allowed.push_back(sorted[i].first);
      }
      std::vector<bool> usedA(allowed.size(), false);
      for (size_t j = 0; j < src.size(); j++) {
        keepS[j] = false;
        for (size_t q = 0; q < allowed.size(); q++)
          if (!usedA[q] && allowed[q] == src[j].first) {
            usedA[q] = true;
            keepS[j] = true;
            break;
          }
      }
    }
    for (size_t j = 0; j < src.size(); j++)
      if (keepS[j])
        out.push_back(src[j]);
    Vec w(n, 0.0);
    IVec ib(n, 0), is(n, 0);
    for (size_t j = 0; j < out.size(); j++) {
      w[j] = out[j].first;
      ib[j] = out[j].second;
    }
    for (size_t j = 0; j < isplit.size(); j++)
      is[j] = isplit[j];
    return makeDict({{"m", inum(static_cast<long long>(out.size()))}, {"w", toValue(w)}, {"iblock", toValue(ib)},
                     {"isplit", toValue(is)}, {"info", inum(0)}});
  } SP_END
  SP_ADD("lapack_stein", 5, 5, "d, e, w, iblock, isplit") {
    Vec d, e, w;
    IVec ib, is;
    if (!getDE(a, ctx, d, e) || !getVec(a, 2, ctx, w) || !getIdx(a, 3, ctx, ib) || !getIdx(a, 4, ctx, is))
      return Value(0.0);
    const size_t n = d.size(), m = w.size();
    if (ib.size() < m) {
      ctx.fail("iblock must hold a block number for every eigenvalue");
      return Value(0.0);
    }
    Mat Z(n, m);
    for (size_t j = 0; j < m; j++) {
      const long long b = ib[j];
      if (b < 1 || static_cast<size_t>(b) > is.size()) {
        ctx.fail("iblock and isplit do not match");
        return Value(0.0);
      }
      const size_t end = static_cast<size_t>(is[static_cast<size_t>(b - 1)]);
      const size_t start = b == 1 ? 0 : static_cast<size_t>(is[static_cast<size_t>(b - 2)]);
      if (end > n || start >= end) {
        ctx.fail("isplit does not describe the blocks of d");
        return Value(0.0);
      }
      Vec db(d.begin() + static_cast<long>(start), d.begin() + static_cast<long>(end)), eb, ww;
      for (size_t q = start; q + 1 < end; q++)
        eb.push_back(e[q]);
      Mat V;
      tridiagEig(db, eb, ww, V);
      size_t best = 0;
      for (size_t q = 1; q < ww.size(); q++)
        if (std::fabs(ww[q] - w[j]) < std::fabs(ww[best] - w[j]))
          best = q;
      // xSTEIN: unit norm, the largest component positive.
      size_t jm = 0;
      for (size_t q = 0; q < db.size(); q++)
        if (std::fabs(V(q, best)) > std::fabs(V(jm, best)))
          jm = q;
      const double sg = V(jm, best) < 0 ? -1.0 : 1.0;
      for (size_t q = 0; q < db.size(); q++)
        Z(start + q, j) = sg * V(q, best);
    }
    return makeDict({{"z", toValue(Z)}, {"info", inum(0)}});
  } SP_END
  static const auto stemrBody = [](const Args &a, CallContext &ctx, bool work) -> Value {
    Vec d, e;
    double vl, vu;
    long long il, iu;
    if (!getVec(a, 0, ctx, d) || !getVec(a, 1, ctx, e) || !argNumber(a, 3, ctx, vl) || !argNumber(a, 4, ctx, vu) ||
        !getI(a, 5, ctx, il) || !getI(a, 6, ctx, iu))
      return Value(0.0);
    const size_t n = d.size();
    if (e.size() + 1 < n) {
      ctx.fail("e must hold at least n-1 values");
      return Value(0.0);
    }
    const char range = ropt(a, 2, 'A');
    const bool vecs = vopt(a, 7, true);
    if (work) {
      const double lw = vecs ? 18.0 * n : 12.0 * n;
      return makeDict({{"work", Value(std::max(lw, 1.0))}, {"iwork", inum(static_cast<long long>(vecs ? 10 * n : 8 * n))},
                       {"info", inum(0)}});
    }
    if (range == 'I' && (il < 1 || iu < il || iu > static_cast<long long>(n))) {
      ctx.fail("il and iu must satisfy 1 <= il <= iu <= n");
      return Value(0.0);
    }
    Vec ee(e.begin(), e.begin() + static_cast<long>(n ? n - 1 : 0)), w;
    Mat V, Tm(n, n);
    for (size_t i = 0; i < n; i++) {
      Tm(i, i) = d[i];
      if (i + 1 < n)
        Tm(i, i + 1) = Tm(i + 1, i) = ee[i];
    }
    la::eigHermitian(Tm, w, V);
    std::vector<size_t> k = pick(w, range, vl, vu, il, iu);
    Vec wo(n, 0.0);
    Mat Z(n, n);
    for (size_t j = 0; j < k.size(); j++) {
      wo[j] = w[k[j]];
      if (vecs)
        for (size_t i = 0; i < n; i++)
          Z(i, j) = V(i, k[j]);
    }
    return makeDict({{"m", inum(static_cast<long long>(k.size()))}, {"w", toValue(wo)}, {"z", toValue(Z)}, {"info", inum(0)}});
  };
  SP_ADD("lapack_stemr", 7, 11, "d, e, range, vl, vu, il, iu, compute_v, lwork, liwork") {
    return stemrBody(a, ctx, false);
  } SP_END
  SP_ADD("lapack_stemr_lwork", 7, 10, "d, e, range, vl, vu, il, iu, compute_v") {
    return stemrBody(a, ctx, true);
  } SP_END

  // ---- general matrices ----
  SP_ADD("lapack_gebal", 1, 4, "a, scale, permute") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return gebal(A, iopt(a, 1, 0) != 0, iopt(a, 2, 0) != 0);
    });
  } SP_ENDC
  SP_ADD("lapack_gehrd", 1, 5, "a, lo, hi, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      const long long n = static_cast<long long>(A.r);
      const long long lo = iopt(a, 1, 0), hi = given(a, 2) ? iopt(a, 2, n - 1) : n - 1;
      if (n > 0 && (lo < 0 || hi < lo || hi >= n)) {
        ctx.fail("lo and hi must satisfy 0 <= lo <= hi < n");
        return Value(0.0);
      }
      std::vector<T> tau = n > 0 ? gehd2(A, static_cast<size_t>(lo), static_cast<size_t>(hi)) : std::vector<T>();
      return makeDict({{"ht", outM(A)}, {"tau", outV(tau)}, {"info", inum(0)}});
    });
  } SP_ENDC
  static const auto orghrBody = [](const Args &a, CallContext &ctx, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      std::vector<T> tau;
      if (!getSq(a, 0, ctx, A) || !getV(a, 1, ctx, tau))
        return Value(0.0);
      const long long n = static_cast<long long>(A.r);
      const long long lo = iopt(a, 2, 0), hi = given(a, 3) ? iopt(a, 3, n - 1) : n - 1;
      if (n > 0 && (lo < 0 || hi < lo || hi >= n || static_cast<long long>(tau.size()) < hi)) {
        ctx.fail("lo, hi and tau do not match a");
        return Value(0.0);
      }
      MatT<T> Q = n > 0 ? qOfHess(A, tau, static_cast<size_t>(lo), static_cast<size_t>(hi)) : A;
      return makeDict({{"ht", outM(Q)}, {"info", inum(0)}});
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_orghr", 2, 6, "a, tau, lo, hi, lwork") {
    return orghrBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_unghr", 2, 6, "a, tau, lo, hi, lwork") {
    return orghrBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("lapack_geev", 1, 5, "a, compute_vl, compute_vr, lwork") {
    const bool cl = iopt(a, 1, 1) != 0, cr = iopt(a, 2, 1) != 0;
    if (anyComplex(a)) {
      CMat A;
      if (!getCSquare(a, 0, ctx, A))
        return Value(0.0);
      const size_t n = A.r;
      CVec w;
      la::eigGeneral(A, w, nullptr);
      CVec wc(n);
      for (size_t i = 0; i < n; i++)
        wc[i] = std::conj(w[i]);
      CMat vr = cr ? vectorsFor(A, w) : CMat(1, n), vl = cl ? vectorsFor(adjointOf(A), wc) : CMat(1, n);
      return makeDict({{"w", toValue(w)}, {"vl", toValue(vl)}, {"vr", toValue(vr)}, {"info", inum(0)}});
    }
    Mat A;
    if (!getSquare(a, 0, ctx, A))
      return Value(0.0);
    const size_t n = A.r;
    Mat Tm, Z;
    la::realSchur(A, Tm, Z);
    Vec wr, wi;
    realEigs(Tm, wr, wi);
    CVec lam(n), lamc(n);
    for (size_t i = 0; i < n; i++) {
      lam[i] = cd(wr[i], wi[i]);
      lamc[i] = std::conj(lam[i]);
    }
    CMat Ac = toComplex(A);
    Mat vr = cr ? realLayout(vectorsFor(Ac, lam), wi) : Mat(1, n);
    Mat vl = cl ? realLayout(vectorsFor(adjointOf(Ac), lamc), wi) : Mat(1, n);
    return makeDict({{"wr", toValue(wr)}, {"wi", toValue(wi)}, {"vl", toValue(vl)}, {"vr", toValue(vr)}, {"info", inum(0)}});
  } SP_ENDC
  SP_ADD("lapack_gees", 2, 7, "select, a, compute_v, sort_t, lwork, select_extra_args") {
    const bool vecs = iopt(a, 2, 1) != 0, sort = iopt(a, 3, 0) != 0;
    if (sort && (a.empty() || !isCallable(a[0]))) {
      ctx.fail("select must name an NC function when sort_t is 1");
      return Value(0.0);
    }
    const size_t lw = workLen(iopt(a, 4, 1));
    if (anyComplex(Args(a.begin() + 1, a.end()))) {
      CMat A;
      if (!getCSquare(a, 1, ctx, A))
        return Value(0.0);
      const size_t n = A.r;
      CMat Tm, Z;
      la::complexSchur(A, Tm, Z);
      long long sdim = 0;
      if (sort) {
        NcFn f(a[0]);
        std::vector<bool> keep(n);
        for (size_t i = 0; i < n; i++) {
          keep[i] = f.number({cellOf(Tm(i, i))}) != 0.0;
          if (f.failed) {
            ctx.fail(f.failText());
            return Value(0.0);
          }
          sdim += keep[i] ? 1 : 0;
        }
        la::reorderSchur(Tm, Z, keep);
      }
      CVec w(n);
      for (size_t i = 0; i < n; i++)
        w[i] = Tm(i, i);
      return makeDict({{"t", toValue(Tm)}, {"sdim", inum(sdim)}, {"w", toValue(w)}, {"vs", toValue(vecs ? Z : CMat(1, 1))},
                       {"work", toValue(CVec(lw, cd(0.0)))}, {"info", inum(0)}});
    }
    Mat A;
    if (!getSquare(a, 1, ctx, A))
      return Value(0.0);
    const size_t n = A.r;
    Mat Tm, Z;
    la::realSchur(A, Tm, Z);
    long long sdim = 0;
    if (sort) {
      NcFn f(a[0]);
      size_t top = 0;
      for (size_t i = 0; i < n;) {
        const size_t nb = blockAt(Tm, i);
        Vec wr, wi;
        realEigs(Tm, wr, wi);
        bool k = f.number({Value(wr[i]), Value(wi[i])}) != 0.0;
        if (nb == 2 && !k)
          k = f.number({Value(wr[i + 1]), Value(wi[i + 1])}) != 0.0;
        if (f.failed) {
          ctx.fail(f.failText());
          return Value(0.0);
        }
        if (k) {
          if (i != top)
            moveReal(Tm, &Z, i, top);
          top += nb;
          sdim += static_cast<long long>(nb);
        }
        i += nb;
      }
    }
    Vec wr, wi;
    realEigs(Tm, wr, wi);
    return makeDict({{"t", toValue(Tm)}, {"sdim", inum(sdim)}, {"wr", toValue(wr)}, {"wi", toValue(wi)},
                     {"vs", toValue(vecs ? Z : Mat(1, 1))}, {"work", toValue(Vec(lw, 0.0))}, {"info", inum(0)}});
  } SP_ENDC
  SP_ADD("lapack_gges", 3, 11, "select, a, b, jobvsl, jobvsr, sort_t, ldvsl, ldvsr, lwork, select_extra_args") {
    const bool sort = iopt(a, 5, 0) != 0, wl = iopt(a, 3, 1) != 0, wr = iopt(a, 4, 1) != 0;
    if (sort && (a.empty() || !isCallable(a[0]))) {
      ctx.fail("select must name an NC function when sort_t is 1");
      return Value(0.0);
    }
    CMat A, B;
    if (!getCSquare(a, 1, ctx, A) || !getCSquare(a, 2, ctx, B))
      return Value(0.0);
    if (A.r != B.r) {
      ctx.fail("a and b must have the same size");
      return Value(0.0);
    }
    const bool realIn = !anyComplex(Args(a.begin() + 1, a.begin() + 3));
    const size_t n = A.r;
    CMat S, Tm, Q, Z;
    gschur(A, B, S, Tm, Q, Z);
    long long sdim = 0;
    if (sort) {
      NcFn f(a[0]);
      std::vector<bool> keep(n);
      for (size_t i = 0; i < n; i++) {
        Args in = realIn ? Args{Value(S(i, i).real()), Value(S(i, i).imag()), Value(Tm(i, i).real())}
                         : Args{cellOf(S(i, i)), cellOf(Tm(i, i))};
        keep[i] = f.number(in) != 0.0;
        if (f.failed) {
          ctx.fail(f.failText());
          return Value(0.0);
        }
        sdim += keep[i] ? 1 : 0;
      }
      size_t top = 0;
      for (size_t i = 0; i < n; i++) {
        if (!keep[i])
          continue;
        for (size_t k = i; k > top; k--)
          swapPencil(S, Tm, &Q, &Z, k - 1);
        top++;
      }
      // Keep beta real and non-negative after the swaps.
      for (size_t j = 0; j < n; j++) {
        const double ab = std::abs(Tm(j, j));
        if (ab == 0.0)
          continue;
        const cd ph = std::conj(Tm(j, j)) / ab;
        for (size_t i = 0; i < n; i++) {
          S(i, j) *= ph;
          Tm(i, j) *= ph;
          Z(i, j) *= ph;
        }
        Tm(j, j) = ab;
      }
    }
    CVec al(n), be(n);
    for (size_t i = 0; i < n; i++) {
      al[i] = S(i, i);
      be[i] = Tm(i, i);
    }
    const size_t lw = workLen(iopt(a, 8, 1));
    DictInit d{{"a", toValue(S)}, {"b", toValue(Tm)}, {"sdim", inum(sdim)}};
    if (realIn) {
      Vec ar(n), ai(n), br(n);
      for (size_t i = 0; i < n; i++) {
        ar[i] = al[i].real();
        ai[i] = al[i].imag();
        br[i] = be[i].real();
      }
      d.push_back({"alphar", toValue(ar)});
      d.push_back({"alphai", toValue(ai)});
      d.push_back({"beta", toValue(br)});
    } else {
      d.push_back({"alpha", toValue(al)});
      d.push_back({"beta", toValue(be)});
    }
    d.push_back({"vsl", toValue(wl ? Q : CMat(1, n))});
    d.push_back({"vsr", toValue(wr ? Z : CMat(1, n))});
    d.push_back({"work", toValue(Vec(lw, 0.0))});
    d.push_back({"info", inum(0)});
    return makeDict(d);
  } SP_ENDC
  reg.setParallel({"lapack_gees", "lapack_gges"}, ParallelClass::Interpreter);

  // ---- Schur reordering ----
  SP_ADD("lapack_trexc", 4, 7, "a, q, ifst, ilst, wantq") {
    long long ifst, ilst;
    if (!getI(a, 2, ctx, ifst) || !getI(a, 3, ctx, ilst))
      return Value(0.0);
    const bool wq = iopt(a, 4, 1) != 0;
    if (anyComplex(Args(a.begin(), a.begin() + 2))) {
      CMat Tm, Q;
      if (!getCSquare(a, 0, ctx, Tm) || !getCSquare(a, 1, ctx, Q))
        return Value(0.0);
      const long long n = static_cast<long long>(Tm.r);
      if (Q.r != Tm.r || ifst < 1 || ifst > n || ilst < 1 || ilst > n) {
        ctx.fail("q must match a and 1 <= ifst, ilst <= n");
        return Value(0.0);
      }
      size_t k = static_cast<size_t>(ifst - 1);
      const size_t t = static_cast<size_t>(ilst - 1);
      while (k < t) {
        swap1(Tm, wq ? &Q : nullptr, k);
        k++;
      }
      while (k > t) {
        swap1(Tm, wq ? &Q : nullptr, k - 1);
        k--;
      }
      return makeDict({{"a", toValue(Tm)}, {"q", toValue(Q)}, {"info", inum(0)}});
    }
    Mat Tm, Q;
    if (!getSquare(a, 0, ctx, Tm) || !getSquare(a, 1, ctx, Q))
      return Value(0.0);
    const long long n = static_cast<long long>(Tm.r);
    if (Q.r != Tm.r || ifst < 1 || ifst > n || ilst < 1 || ilst > n) {
      ctx.fail("q must match a and 1 <= ifst, ilst <= n");
      return Value(0.0);
    }
    moveReal(Tm, wq ? &Q : nullptr, static_cast<size_t>(ifst - 1), static_cast<size_t>(ilst - 1));
    return makeDict({{"a", toValue(Tm)}, {"q", toValue(Q)}, {"info", inum(0)}});
  } SP_ENDC
  static const auto trsenBody = [](const Args &a, CallContext &ctx, bool work) -> Value {
    IVec sel;
    if (!getIdx(a, 0, ctx, sel))
      return Value(0.0);
    const char job = copt(a, work ? 2 : 3, 'B');
    const bool wq = work ? true : iopt(a, 4, 1) != 0;
    if (anyComplex(Args(a.begin() + 1, a.begin() + (work ? 2 : 3)))) {
      CMat Tm, Q;
      if (!getCSquare(a, 1, ctx, Tm))
        return Value(0.0);
      const size_t n = Tm.r;
      if (sel.size() < n) {
        ctx.fail("select must hold n flags");
        return Value(0.0);
      }
      std::vector<bool> keep(n);
      size_t m = 0;
      for (size_t i = 0; i < n; i++) {
        keep[i] = sel[i] != 0;
        m += keep[i] ? 1 : 0;
      }
      if (work) {
        const double lw = job == 'N' ? 1.0 : std::max<double>(1.0, (job == 'E' || job == 'B') ? 2.0 * m * (n - m) : 1.0);
        return makeDict({{"work", cellOf(cd(lw, 0.0))}, {"info", inum(0)}});
      }
      if (!getCSquare(a, 2, ctx, Q) || Q.r != n) {
        if (ctx.ok())
          ctx.fail("q must match t");
        return Value(0.0);
      }
      CMat Qw = Q;
      la::reorderSchur(Tm, Qw, keep);
      if (wq)
        Q = Qw;
      double s = 1.0, sep = 0.0;
      sylvesterInfo(Tm, m, s, sep);
      CVec w(n);
      for (size_t i = 0; i < n; i++)
        w[i] = Tm(i, i);
      return makeDict({{"ts", toValue(Tm)}, {"qs", toValue(Q)}, {"w", toValue(w)}, {"m", inum(static_cast<long long>(m))},
                       {"s", Value(job == 'E' || job == 'B' ? s : 0.0)}, {"sep", Value(job == 'V' || job == 'B' ? sep : 0.0)},
                       {"info", inum(0)}});
    }
    Mat Tm, Q;
    if (!getSquare(a, 1, ctx, Tm))
      return Value(0.0);
    const size_t n = Tm.r;
    if (sel.size() < n) {
      ctx.fail("select must hold n flags");
      return Value(0.0);
    }
    size_t m = 0;
    std::vector<bool> keep(n, false);
    for (size_t i = 0; i < n;) {
      const size_t nb = blockAt(Tm, i);
      const bool k = sel[i] != 0 || (nb == 2 && sel[i + 1] != 0);
      for (size_t q = 0; q < nb; q++)
        keep[i + q] = k;
      m += k ? nb : 0;
      i += nb;
    }
    if (work) {
      const double lw = job == 'N' ? std::max<double>(1.0, n) : (job == 'E' ? std::max<double>(1.0, 2.0 * m * (n - m)) : std::max<double>(1.0, 2.0 * m * (n - m)));
      const long long liw = (job == 'V' || job == 'B') ? std::max<long long>(1, static_cast<long long>(m * (n - m))) : 1;
      return makeDict({{"work", Value(lw)}, {"iwork", inum(liw)}, {"info", inum(0)}});
    }
    if (!getSquare(a, 2, ctx, Q) || Q.r != n) {
      if (ctx.ok())
        ctx.fail("q must match t");
      return Value(0.0);
    }
    Mat Qw = Q;
    size_t top = 0;
    for (size_t i = 0; i < n;) {
      const size_t nb = blockAt(Tm, i);
      if (keep[i]) {
        if (i != top)
          moveReal(Tm, &Qw, i, top);
        top += nb;
      }
      i += nb;
    }
    if (wq)
      Q = Qw;
    double s = 1.0, sep = 0.0;
    sylvesterInfo(Tm, m, s, sep);
    Vec wr, wi;
    realEigs(Tm, wr, wi);
    return makeDict({{"ts", toValue(Tm)}, {"qs", toValue(Q)}, {"wr", toValue(wr)}, {"wi", toValue(wi)},
                     {"m", inum(static_cast<long long>(m))}, {"s", Value(job == 'E' || job == 'B' ? s : 0.0)},
                     {"sep", Value(job == 'V' || job == 'B' ? sep : 0.0)}, {"info", inum(0)}});
  };
  SP_ADD("lapack_trsen", 3, 9, "select, t, q, job, wantq, lwork, liwork") {
    return trsenBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_trsen_lwork", 2, 3, "select, t, job") {
    return trsenBody(a, ctx, true);
  } SP_ENDC
  // tgexc / tgsen on a generalized Schur pair; real pairs must have only 1x1 blocks.
  SP_ADD("lapack_tgexc", 6, 13, "a, b, q, z, ifst, ilst, wantq, wantz, lwork") {
    return both(a, [&](auto zz) -> Value {
      using T = decltype(zz);
      MatT<T> A, B, Q, Z;
      long long ifst, ilst;
      if (!getSq(a, 0, ctx, A) || !getSq(a, 1, ctx, B) || !getSq(a, 2, ctx, Q) || !getSq(a, 3, ctx, Z) ||
          !getI(a, 4, ctx, ifst) || !getI(a, 5, ctx, ilst))
        return Value(0.0);
      const long long n = static_cast<long long>(A.r);
      if (B.r != A.r || Q.r != A.r || Z.r != A.r || ifst < 1 || ifst > n || ilst < 1 || ilst > n) {
        ctx.fail("a, b, q, z must be n x n and 1 <= ifst, ilst <= n");
        return Value(0.0);
      }
      if (hasBlocks(A)) {
        ctx.fail("a has 2x2 blocks: give the pair as complex numbers to reorder it");
        return Value(0.0);
      }
      const bool wq = iopt(a, 6, 1) != 0, wz = iopt(a, 7, 1) != 0;
      size_t k = static_cast<size_t>(ifst - 1);
      const size_t t = static_cast<size_t>(ilst - 1);
      while (k < t) {
        swapPencil(A, B, wq ? &Q : nullptr, wz ? &Z : nullptr, k);
        k++;
      }
      while (k > t) {
        swapPencil(A, B, wq ? &Q : nullptr, wz ? &Z : nullptr, k - 1);
        k--;
      }
      DictInit d{{"a", outM(A)}, {"b", outM(B)}, {"q", outM(Q)}, {"z", outM(Z)}};
      if constexpr (!isCx<T>())
        d.push_back({"work", toValue(Vec(workLen(iopt(a, 8, 4 * n + 16)), 0.0))});
      d.push_back({"info", inum(0)});
      return makeDict(d);
    });
  } SP_ENDC
  static const auto tgsenBody = [](const Args &a, CallContext &ctx, bool work) -> Value {
    return both(a, [&](auto zz) -> Value {
      using T = decltype(zz);
      IVec sel;
      MatT<T> A, B, Q, Z;
      if (!getIdx(a, 0, ctx, sel) || !getSq(a, 1, ctx, A))
        return Value(0.0);
      const size_t n = A.r;
      if (sel.size() < n) {
        ctx.fail("select must hold n flags");
        return Value(0.0);
      }
      size_t m = 0;
      for (size_t i = 0; i < n; i++)
        m += sel[i] != 0 ? 1 : 0;
      const long long ijob = iopt(a, work ? (isCx<T>() ? 3 : 2) : 5, 4);
      if (work) {
        const double lw = isCx<T>() ? (ijob == 0 ? 1.0 : std::max<double>(1.0, 2.0 * m * (n - m)))
                                    : std::max<double>(4.0 * n + 16, ijob == 0 ? 1.0 : 2.0 * m * (n - m));
        const long long liw = ijob == 0 ? 1 : std::max<long long>(static_cast<long long>(n) + 6, static_cast<long long>(2 * m * (n - m)));
        if constexpr (isCx<T>())
          return makeDict({{"work", cellOf(cd(lw, 0.0))}, {"iwork", inum(liw)}, {"info", inum(0)}});
        else
          return makeDict({{"work", Value(lw)}, {"iwork", inum(liw)}, {"info", inum(0)}});
      }
      if (!getSq(a, 2, ctx, B) || !getSq(a, 3, ctx, Q) || !getSq(a, 4, ctx, Z))
        return Value(0.0);
      if (B.r != n || Q.r != n || Z.r != n) {
        ctx.fail("a, b, q, z must be n x n");
        return Value(0.0);
      }
      if (hasBlocks(A)) {
        ctx.fail("a has 2x2 blocks: give the pair as complex numbers to reorder it");
        return Value(0.0);
      }
      const bool wq = iopt(a, 6, 1) != 0, wz = iopt(a, 7, 1) != 0;
      MatT<T> Qw = Q, Zw = Z;
      size_t top = 0;
      for (size_t i = 0; i < n; i++) {
        if (sel[i] == 0)
          continue;
        for (size_t k = i; k > top; k--)
          swapPencil(A, B, &Qw, &Zw, k - 1);
        top++;
      }
      if (wq)
        Q = Qw;
      if (wz)
        Z = Zw;
      // pl, pr from the generalized Sylvester equation of the split; dif from its smallest singular value.
      double pl = 1.0, pr = 1.0;
      Vec dif(2, 0.0);
      if (m > 0 && m < n && ijob > 0) {
        auto sub = [&](const MatT<T> &M, size_t r0, size_t r1, size_t c0, size_t c1) {
          MatT<T> S(r1 - r0, c1 - c0);
          for (size_t i = r0; i < r1; i++)
            for (size_t j = c0; j < c1; j++)
              S(i - r0, j - c0) = M(i, j);
          return S;
        };
        MatT<T> A11 = sub(A, 0, m, 0, m), A12 = sub(A, 0, m, m, n), A22 = sub(A, m, n, m, n);
        MatT<T> B11 = sub(B, 0, m, 0, m), B12 = sub(B, 0, m, m, n), B22 = sub(B, m, n, m, n);
        MatT<T> R, L, R2, L2;
        double d1 = 0.0, d2 = 0.0;
        if (genSylvester(A11, A22, A12, B11, B22, B12, false, R, L, d1)) {
          double fr = 0.0, fl = 0.0;
          for (const T &v : R.a)
            fr += absOf(v) * absOf(v);
          for (const T &v : L.a)
            fl += absOf(v) * absOf(v);
          pl = 1.0 / std::sqrt(1.0 + fr);
          pr = 1.0 / std::sqrt(1.0 + fl);
        }
        genSylvester(A22, A11, sub(A, m, n, 0, m), B22, B11, sub(B, m, n, 0, m), false, R2, L2, d2);
        dif[0] = d1;
        dif[1] = d2;
      }
      DictInit d{{"as", outM(A)}, {"bs", outM(B)}};
      if constexpr (isCx<T>()) {
        CVec al(n), be(n);
        for (size_t i = 0; i < n; i++) {
          al[i] = A(i, i);
          be[i] = B(i, i);
        }
        d.push_back({"alpha", toValue(al)});
        d.push_back({"beta", toValue(be)});
      } else {
        Vec ar(n), ai(n, 0.0), br(n);
        for (size_t i = 0; i < n; i++) {
          ar[i] = A(i, i);
          br[i] = B(i, i);
        }
        d.push_back({"alphar", toValue(ar)});
        d.push_back({"alphai", toValue(ai)});
        d.push_back({"beta", toValue(br)});
      }
      d.push_back({"qs", outM(Q)});
      d.push_back({"zs", outM(Z)});
      d.push_back({"m", inum(static_cast<long long>(m))});
      d.push_back({"pl", Value(pl)});
      d.push_back({"pr", Value(pr)});
      d.push_back({"dif", toValue(dif)});
      d.push_back({"info", inum(0)});
      return makeDict(d);
    });
  };
  SP_ADD("lapack_tgsen", 5, 14, "select, a, b, q, z, ijob, wantq, wantz, lwork, liwork") {
    return tgsenBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_tgsen_lwork", 2, 4, "select, a, b, ijob") {
    return tgsenBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("lapack_trsyl", 3, 7, "a, b, c, trana, tranb, isgn") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B, C;
      if (!getSq(a, 0, ctx, A) || !getSq(a, 1, ctx, B) || !getM(a, 2, ctx, C))
        return Value(0.0);
      if (C.r != A.r || C.c != B.r) {
        ctx.fail("c must be m x n for a (m x m) and b (n x n)");
        return Value(0.0);
      }
      const char ta = copt(a, 3, 'N'), tb = copt(a, 4, 'N');
      const long long isgn = iopt(a, 5, 1);
      CMat Ac = toComplexAny(opOf(A, ta)), Bc = toComplexAny(opOf(B, tb)), Cc = toComplexAny(C), X;
      if (isgn < 0)
        for (auto &e : Bc.a)
          e = -e;
      if (!la::sylvester(Ac, Bc, Cc, X))
        return makeDict({{"x", outM(C)}, {"scale", Value(1.0)}, {"info", inum(1)}});
      MatT<T> Xo(C.r, C.c);
      for (size_t k = 0; k < Xo.a.size(); k++)
        Xo.a[k] = fromComplex<T>(X.a[k]);
      return makeDict({{"x", outM(Xo)}, {"scale", Value(1.0)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tgsyl", 6, 11, "a, b, c, d, e, f, trans, ijob, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B, C, D, E, F;
      if (!getSq(a, 0, ctx, A) || !getSq(a, 1, ctx, B) || !getM(a, 2, ctx, C) || !getSq(a, 3, ctx, D) ||
          !getSq(a, 4, ctx, E) || !getM(a, 5, ctx, F))
        return Value(0.0);
      const size_t m = A.r, n = B.r;
      if (C.r != m || C.c != n || D.r != m || E.r != n || F.r != m || F.c != n) {
        ctx.fail("a, d must be m x m, b, e n x n and c, f m x n");
        return Value(0.0);
      }
      const bool tr = copt(a, 6, 'N') != 'N';
      const long long ijob = iopt(a, 7, 0);
      MatT<T> R, L;
      double dif = 0.0;
      if (!genSylvester(A, B, C, D, E, F, tr, R, L, dif))
        return makeDict({{"r", outM(C)}, {"l", outM(F)}, {"scale", Value(1.0)}, {"dif", Value(0.0)}, {"info", inum(1)}});
      return makeDict({{"r", outM(R)}, {"l", outM(L)}, {"scale", Value(1.0)},
                       {"dif", Value(ijob >= 1 && !tr ? (dif > 0 ? dif : 0.0) : 0.0)}, {"info", inum(0)}});
    });
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
