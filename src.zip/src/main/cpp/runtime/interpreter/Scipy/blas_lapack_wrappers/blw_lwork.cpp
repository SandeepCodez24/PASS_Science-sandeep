// Workspace queries (*_lwork) and lapack_routine.
//
// NC's routines need no workspace, but these report what LAPACK would ask for,
// so code that sizes work arrays the SciPy way keeps working. The formulas are
// reference LAPACK's optimal sizes with ILAENV's block sizes (32, or 64 for
// xSYTRF/xGETRI) and the 4160-entry T block of the blocked Hessenberg/RZ code.
// A query shared by the real and complex routines gives the real (d) size;
// a last argument "complex" (or "z", "c") gives the complex (z) size.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

constexpr long long kNb = 32, kNb64 = 64, kTsize = 4160;

// True when a text argument at or after `from` asks for the complex sizes.
bool wantComplex(const Args &a, size_t from) {
  for (size_t i = from; i < a.size(); i++)
    if (a[i].isText) {
      std::string s = a[i].text();
      if (!s.empty() && (s[0] == 'c' || s[0] == 'C' || s[0] == 'z' || s[0] == 'Z'))
        return true;
    }
  return false;
}
// Reads the first `count` whole-number inputs (sizes), which must not be negative.
bool sizes(const Args &a, CallContext &ctx, size_t count, std::vector<long long> &out) {
  out.resize(count);
  for (size_t i = 0; i < count; i++) {
    if (!argNonNegativeInt(a, i, ctx, out[i]))
      return false;
  }
  return true;
}
Value w1(double work) { return makeDict({{"work", Value(std::max(work, 1.0))}, {"info", inum(0)}}); }
inline long long mx1(long long x) { return std::max<long long>(x, 1); }
// int(log2(mn / 26)) + 1, at least 0 (xGELSD's NLVL with SMLSIZ = 25).
long long nlvlOf(long long mn) {
  if (mn <= 0)
    return 0;
  const long long v = static_cast<long long>(std::log(static_cast<double>(mn) / 26.0) / std::log(2.0)) + 1;
  return std::max<long long>(v, 0);
}

// Optimal xGESVD / xGESDD workspace for m >= n (callers swap for m < n).
long long svdWork(long long m, long long n, bool cuv, bool full, bool cx, bool dd) {
  if (n == 0)
    return 1;
  const long long c3 = cx ? 2 : 3; // 3n for the real routines, 2n for the complex ones
  const long long bd = dd && !cx ? (cuv ? 3 * n * n + 4 * n : 7 * n) : (cx ? 0 : 5 * n);
  const long long mnthr = dd && !cx ? static_cast<long long>(n * 11.0 / 6.0) : static_cast<long long>(n * 1.6);
  if (m >= mnthr) {
    if (!cuv)
      return std::max({n + n * kNb, c3 * n + 2 * n * kNb, (dd && !cx) ? n + bd : bd});
    long long wrk = std::max({n + n * kNb, n + (full ? m : n) * kNb, c3 * n + 2 * n * kNb, c3 * n + n * kNb,
                              c3 * n + (n - 1) * kNb, c3 * n + bd});
    return wrk + n * n;
  }
  long long w = c3 * n + (m + n) * kNb;
  if (cuv)
    w = std::max({w, c3 * n + (full ? m : n) * kNb, c3 * n + (n - 1) * kNb});
  return std::max(w, c3 * n + bd);
}

} // namespace

void registerBlwLwork(Registry &reg) {
  // ---- general ----
  SP_ADD("lapack_geev_lwork", 1, 4, "n, compute_vl, compute_vr") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const bool vec = iopt(a, 1, 1) != 0 || iopt(a, 2, 1) != 0;
    const long long n = s[0];
    return w1(static_cast<double>(vec ? 130 * n : (wantComplex(a, 1) ? 33 : 34) * n));
  } SP_ENDC
  SP_ADD("lapack_gehrd_lwork", 1, 4, "n, lo, hi") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const long long n = s[0], lo = iopt(a, 1, 0), hi = given(a, 2) ? iopt(a, 2, n - 1) : n - 1;
    return w1(hi - lo + 1 <= 1 ? 1.0 : static_cast<double>(n * kNb + kTsize));
  } SP_ENDC
  SP_ADD("lapack_getri_lwork", 1, 2, "n") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    return w1(static_cast<double>(s[0] * kNb64));
  } SP_ENDC
  SP_ADD("lapack_geqrf_lwork", 2, 3, "m, n") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 2, s))
      return Value(0.0);
    return w1(std::min(s[0], s[1]) == 0 ? 1.0 : static_cast<double>(s[1] * kNb));
  } SP_ENDC
  SP_ADD("lapack_geqrfp_lwork", 2, 3, "m, n") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 2, s))
      return Value(0.0);
    return w1(std::min(s[0], s[1]) == 0 ? 1.0 : static_cast<double>(s[1] * kNb));
  } SP_ENDC
  static const auto svdLwork = [](const Args &a, CallContext &ctx, bool dd) -> Value {
    std::vector<long long> s;
    if (!sizes(a, ctx, 2, s))
      return Value(0.0);
    const long long m = std::max(s[0], s[1]), n = std::min(s[0], s[1]);
    return w1(static_cast<double>(svdWork(m, n, iopt(a, 2, 1) != 0, iopt(a, 3, 1) != 0, wantComplex(a, 2), dd)));
  };
  SP_ADD("lapack_gesvd_lwork", 2, 5, "m, n, compute_uv, full_matrices") {
    return svdLwork(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_gesdd_lwork", 2, 5, "m, n, compute_uv, full_matrices") {
    return svdLwork(a, ctx, true);
  } SP_ENDC

  // ---- least squares ----
  SP_ADD("lapack_gels_lwork", 3, 5, "m, n, nrhs, trans") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    const long long mn = std::min(s[0], s[1]);
    return w1(static_cast<double>(mn + std::max(mn, s[2]) * kNb));
  } SP_ENDC
  SP_ADD("lapack_gelss_lwork", 3, 6, "m, n, nrhs, cond, lwork") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    // QR (or LQ) first when one side is at least 1.6 times the other, as xGELSS.
    const long long m = s[0], n = s[1], nrhs = s[2], mn = std::min(m, n), mx = std::max(m, n);
    const bool cx = wantComplex(a, 3);
    const long long c3 = cx ? 2 : 3;
    const bool first = mx >= static_cast<long long>(1.6 * mn);
    long long w;
    if (!first)
      w = c3 * mn + (m + n) * kNb;
    else if (m >= n && cx)
      w = std::max({mn + mn * kNb, c3 * mn + 2 * mn * kNb, mn + nrhs * kNb});
    else
      w = std::max(mn + nrhs * kNb + kTsize, c3 * mn + 2 * mn * kNb);
    return w1(static_cast<double>(w));
  } SP_ENDC
  SP_ADD("lapack_gelsd_lwork", 3, 6, "m, n, nrhs, cond, lwork") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    const long long m = s[0], n = s[1], nrhs = s[2], mn = std::min(m, n), nl = nlvlOf(mn);
    const long long iwork = mx1(3 * mn * nl + 11 * mn);
    if (wantComplex(a, 3)) {
      const long long rwork = 10 * mn + 2 * mn * 25 + 8 * mn * nl + 3 * 25 * nrhs +
                              std::max<long long>(26 * 26, mn * (1 + nrhs) + 2 * nrhs);
      const bool first = std::max(m, n) >= static_cast<long long>(1.6 * mn);
      long long work = !first ? 2 * mn + (m + n) * kNb : (m >= n ? 66 * mn : 66 * m + m * m + 2 * m);
      return makeDict({{"work", Value(static_cast<double>(mx1(work)))}, {"rwork", Value(static_cast<double>(rwork))},
                       {"iwork", inum(iwork)}, {"info", inum(0)}});
    }
    auto wlalsd = [&](long long k) { return 9 * k + 2 * k * 25 + 8 * k * nl + k * nrhs + 26 * 26; };
    long long work;
    if (m >= n)
      work = std::max(3 * n + wlalsd(n), 3 * n + (m + n) * kNb);
    else if (n >= static_cast<long long>(1.6 * m))
      work = m * m + 4 * m + wlalsd(m);
    else
      work = std::max(3 * m + wlalsd(m), 3 * m + (m + n) * kNb);
    return makeDict({{"work", Value(static_cast<double>(mx1(work)))}, {"iwork", inum(iwork)}, {"info", inum(0)}});
  } SP_ENDC
  SP_ADD("lapack_gelsy_lwork", 4, 6, "m, n, nrhs, cond, lwork") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    const long long m = s[0], n = s[1], nrhs = s[2], mn = std::min(m, n);
    return w1(static_cast<double>(std::max({1LL, mn + 2 * n + kNb * (n + 1), 2 * mn + kNb * nrhs})));
  } SP_ENDC
  SP_ADD("lapack_gglse_lwork", 3, 4, "m, n, p") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    const long long m = s[0], n = s[1], p = s[2];
    return w1(static_cast<double>(p + std::min(m, n) + std::max(m, n) * kNb));
  } SP_ENDC

  // ---- symmetric / Hermitian ----
  static const auto perN = [](const Args &a, CallContext &ctx, long long f) -> Value {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    return w1(static_cast<double>(f * s[0]));
  };
  SP_ADD("lapack_syev_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb + 2); } SP_END
  SP_ADD("lapack_heev_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb + 1); } SP_END
  SP_ADD("lapack_sygv_lwork", 1, 2, "n, uplo") { return perN(a, ctx, kNb + 2); } SP_END
  SP_ADD("lapack_hegv_lwork", 1, 2, "n, uplo") { return perN(a, ctx, kNb + 1); } SP_END
  SP_ADD("lapack_sygvx_lwork", 1, 2, "n, uplo") { return perN(a, ctx, kNb + 3); } SP_END
  SP_ADD("lapack_hegvx_lwork", 1, 2, "n, uplo") { return perN(a, ctx, kNb + 1); } SP_END
  SP_ADD("lapack_sytrd_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb); } SP_END
  SP_ADD("lapack_hetrd_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb); } SP_END
  SP_ADD("lapack_sytrf_lwork", 1, 3, "n, lower") { return perN(a, ctx, kNb64); } SP_ENDC
  SP_ADD("lapack_hetrf_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb64); } SP_END
  SP_ADD("lapack_sysv_lwork", 1, 3, "n, lower") { return perN(a, ctx, kNb64); } SP_ENDC
  SP_ADD("lapack_hesv_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb64); } SP_END
  SP_ADD("lapack_sysvx_lwork", 1, 3, "n, lower") { return perN(a, ctx, kNb64); } SP_ENDC
  SP_ADD("lapack_hesvx_lwork", 1, 2, "n, lower") { return perN(a, ctx, kNb64); } SP_END
  static const auto evx = [](const Args &a, CallContext &ctx, long long f) -> Value {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    return w1(s[0] <= 1 ? 1.0 : static_cast<double>(f * s[0]));
  };
  SP_ADD("lapack_syevx_lwork", 1, 2, "n, lower") { return evx(a, ctx, kNb + 3); } SP_END
  SP_ADD("lapack_heevx_lwork", 1, 2, "n, lower") { return evx(a, ctx, kNb + 1); } SP_END
  SP_ADD("lapack_syevd_lwork", 1, 3, "n, compute_v, lower") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const long long n = s[0];
    const bool v = iopt(a, 1, 1) != 0;
    if (n <= 1)
      return makeDict({{"work", Value(1.0)}, {"iwork", inum(1)}, {"info", inum(0)}});
    const long long lw = std::max(v ? 1 + 6 * n + 2 * n * n : 2 * n + 1, (kNb + 2) * n);
    return makeDict({{"work", Value(static_cast<double>(lw))}, {"iwork", inum(v ? 3 + 5 * n : 1)}, {"info", inum(0)}});
  } SP_END
  SP_ADD("lapack_heevd_lwork", 1, 3, "n, compute_v, lower") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const long long n = s[0];
    const bool v = iopt(a, 1, 1) != 0;
    if (n <= 1)
      return makeDict({{"work", Value(1.0)}, {"iwork", inum(1)}, {"rwork", Value(1.0)}, {"info", inum(0)}});
    const long long lw = std::max(v ? 2 * n + n * n : n + 1, (kNb + 1) * n);
    return makeDict({{"work", Value(static_cast<double>(lw))}, {"iwork", inum(v ? 3 + 5 * n : 1)},
                     {"rwork", Value(static_cast<double>(v ? 1 + 5 * n + 2 * n * n : n))}, {"info", inum(0)}});
  } SP_END
  SP_ADD("lapack_syevr_lwork", 1, 2, "n, lower") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const long long n = s[0];
    return makeDict({{"work", Value(static_cast<double>(mx1((kNb + 1) * n)))}, {"iwork", inum(n <= 1 ? 1 : 10 * n)},
                     {"info", inum(0)}});
  } SP_END
  SP_ADD("lapack_heevr_lwork", 1, 2, "n, lower") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const long long n = s[0];
    return makeDict({{"work", Value(static_cast<double>(mx1((kNb + 1) * n)))},
                     {"rwork", Value(n <= 1 ? 1.0 : static_cast<double>(24 * n))}, {"iwork", inum(n <= 1 ? 1 : 10 * n)},
                     {"info", inum(0)}});
  } SP_END

  // ---- orthogonal factors ----
  static const auto orghrLw = [](const Args &a, CallContext &ctx) -> Value {
    std::vector<long long> s;
    if (!sizes(a, ctx, 1, s))
      return Value(0.0);
    const long long n = s[0], lo = iopt(a, 1, 0), hi = given(a, 2) ? iopt(a, 2, n - 1) : n - 1;
    return w1(static_cast<double>(mx1(hi - lo) * kNb));
  };
  SP_ADD("lapack_orghr_lwork", 1, 3, "n, lo, hi") { return orghrLw(a, ctx); } SP_END
  SP_ADD("lapack_unghr_lwork", 1, 3, "n, lo, hi") { return orghrLw(a, ctx); } SP_END
  static const auto ormrzLw = [](const Args &a, CallContext &ctx) -> Value {
    std::vector<long long> s;
    if (!sizes(a, ctx, 2, s))
      return Value(0.0);
    const long long nw = copt(a, 2, 'L') == 'L' ? s[1] : s[0];
    return w1(static_cast<double>(mx1(nw) * kNb + kTsize));
  };
  SP_ADD("lapack_ormrz_lwork", 2, 4, "m, n, side, trans") { return ormrzLw(a, ctx); } SP_END
  SP_ADD("lapack_unmrz_lwork", 2, 4, "m, n, side, trans") { return ormrzLw(a, ctx); } SP_END
  SP_ADD("lapack_tzrzf_lwork", 2, 3, "m, n") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 2, s))
      return Value(0.0);
    const long long m = s[0], n = s[1];
    if (m > n)
      return makeDict({{"work", Value(0.0)}, {"info", inum(-2)}});
    return w1(m == 0 || m == n ? 1.0 : static_cast<double>(m * kNb));
  } SP_ENDC
  SP_ADD("lapack_orcsd_lwork", 3, 3, "m, p, q") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    const long long m = s[0], p = s[1], q = s[2];
    if (p > m || q > m) {
      ctx.fail("p and q must not exceed m");
      return Value(0.0);
    }
    const long long r = std::min({p, m - p, q, m - q}), x = std::max({p, m - p, q, m - q});
    return w1(static_cast<double>(4 + 34 * x + std::max<long long>(0, 3 * r - 4)));
  } SP_END
  SP_ADD("lapack_uncsd_lwork", 3, 3, "m, p, q") {
    std::vector<long long> s;
    if (!sizes(a, ctx, 3, s))
      return Value(0.0);
    const long long m = s[0], p = s[1], q = s[2];
    if (p > m || q > m) {
      ctx.fail("p and q must not exceed m");
      return Value(0.0);
    }
    const long long r = std::min({p, m - p, q, m - q}), x = std::max({p, m - p, q, m - q});
    const long long rw = 5 * mx1(r - 1) + 4 * mx1(r) + 8 * r + 1;
    return makeDict({{"work", Value(static_cast<double>(3 + 34 * x + std::max<long long>(0, 2 * r - 2)))},
                     {"rwork", Value(static_cast<double>(rw))}, {"info", inum(0)}});
  } SP_END

  // ---- any routine by name ----
  SP_ADD("lapack_routine", 1, kVariadic, "name or a, ...") {
    if (!a.empty() && a[0].isText) {
      std::string nm = a[0].text();
      for (auto &ch : nm)
        ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
      if (nm.rfind("lapack_", 0) == 0)
        nm = nm.substr(7);
      const Registry &r = Registry::instance();
      const FunctionSpec *spec = r.find("lapack_" + nm);
      // A SciPy name with its precision letter (dgesv, zheev, ...) also works.
      if (!spec && nm.size() > 1 && std::string("sdcz").find(nm[0]) != std::string::npos)
        spec = r.find("lapack_" + nm.substr(1));
      if (!spec || nm == "routine") {
        ctx.fail("no LAPACK routine named '" + a[0].text() + "'");
        return Value(0.0);
      }
      Args rest(a.begin() + 1, a.end());
      const int cnt = static_cast<int>(rest.size());
      if (cnt < spec->minArgs || (spec->maxArgs != kVariadic && cnt > spec->maxArgs)) {
        ctx.fail("wrong number of inputs for " + spec->name + ": " + spec->signature);
        return Value(0.0);
      }
      return spec->impl(rest, ctx);
    }
    // Without a name: the generalized symmetric-definite eigenproblem (sygv / hegv).
    const FunctionSpec *spec = Registry::instance().find(anyComplex(a) ? "lapack_hegv" : "lapack_sygv");
    if (!spec || a.size() < 2 || static_cast<int>(a.size()) > spec->maxArgs) {
      ctx.fail("lapack_routine(a, b, ...) solves A v = w B v; give a and b");
      return Value(0.0);
    }
    return spec->impl(a, ctx);
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
