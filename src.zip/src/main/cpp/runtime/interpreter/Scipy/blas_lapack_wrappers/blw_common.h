// Shared helpers of section 25 (low-level BLAS and LAPACK wrappers).
//
// One NC function covers the s/d/c/z variants of a routine: real input runs in
// double precision, complex input in double complex. Every routine body is a
// generic lambda over the element type T (double or std::complex<double>),
// started by `both` (real or complex by the inputs) or `cplx` (always complex).
//
// Storage conventions follow SciPy's wrappers: band matrices are LAPACK's
// (ldab, n) arrays written row by row in NC, packed matrices are LAPACK's
// column-major packed vectors, and pivots are 0-based or 1-based exactly where
// SciPy's are.
#ifndef NC_SCIPY_BLW_COMMON_H
#define NC_SCIPY_BLW_COMMON_H

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace blw {

using la::absOf;
using la::realOf;

inline double imagOf(double) { return 0.0; }
inline double imagOf(const cd &z) { return z.imag(); }
// |re| + |im|: the size BLAS uses to choose pivots (izamax, dzasum).
inline double cabs1(double x) { return std::fabs(x); }
inline double cabs1(const cd &z) { return std::fabs(z.real()) + std::fabs(z.imag()); }
template <class T> constexpr bool isCx() { return !std::is_same<T, double>::value; }
template <class T> T mk(double re, double im) {
  if constexpr (isCx<T>())
    return T(re, im);
  else
    return re;
}

inline bool anyComplex(const Args &a) {
  for (const Value &v : a)
    if (v.hasComplex())
      return true;
  return false;
}
// Runs f(T{}) with T = double, or std::complex<double> when any input is complex.
template <class F> Value both(const Args &a, F &&f) {
  if (anyComplex(a))
    return f(cd{});
  return f(0.0);
}
template <class F> Value cplx(F &&f) { return f(cd{}); }

// Complex copies and back, for kernels that work in complex arithmetic.
inline CMat toComplexAny(const Mat &m) { return toComplex(m); }
inline CMat toComplexAny(const CMat &m) { return m; }
template <class T> T fromComplex(const cd &z) {
  if constexpr (isCx<T>())
    return z;
  else
    return z.real();
}

// ---- reading inputs ----

template <class T> bool readM(const Value &v, MatT<T> &m) {
  if constexpr (isCx<T>())
    return readCMat(v, m);
  else
    return readMat(v, m);
}
template <class T> bool readV(const Value &v, std::vector<T> &x) {
  if constexpr (isCx<T>())
    return readCVec(v, x);
  else
    return readVec(v, x);
}
template <class T> bool getM(const Args &a, size_t i, CallContext &ctx, MatT<T> &m) {
  if (i >= a.size() || !readM(a[i], m)) {
    ctx.fail("the " + ordinal(i) + " argument must be a matrix of numbers");
    return false;
  }
  return true;
}
template <class T> bool getSq(const Args &a, size_t i, CallContext &ctx, MatT<T> &m) {
  if (!getM(a, i, ctx, m))
    return false;
  if (m.r != m.c) {
    ctx.fail("the " + ordinal(i) + " argument must be a square matrix");
    return false;
  }
  return true;
}
template <class T> bool getV(const Args &a, size_t i, CallContext &ctx, std::vector<T> &x) {
  if (i >= a.size() || !readV(a[i], x)) {
    ctx.fail("the " + ordinal(i) + " argument must be an array of numbers");
    return false;
  }
  return true;
}
// True when input i was given (any value, 0 included).
inline bool given(const Args &a, size_t i) { return i < a.size(); }
// A scalar input; complex when T is.
template <class T> T scal(const Args &a, size_t i, T def) {
  if (i >= a.size() || !isPlainNumber(a[i]))
    return def;
  return mk<T>(a[i].number, a[i].isComplex ? a[i].imag : 0.0);
}
template <class T> bool getScal(const Args &a, size_t i, CallContext &ctx, T &out) {
  if (i >= a.size() || !isPlainNumber(a[i])) {
    ctx.fail("the " + ordinal(i) + " argument must be a number");
    return false;
  }
  out = scal<T>(a, i, T(0));
  return true;
}
// A whole-number option, `def` when left out.
inline long long iopt(const Args &a, size_t i, long long def) {
  return (i < a.size() && isPlainNumber(a[i])) ? static_cast<long long>(a[i].number) : def;
}
// A text option such as "N", "T" or "U" (its first letter, upper case). Numbers
// are accepted as the codes 0/1/2 -> N/T/C where a flag is expected.
inline char copt(const Args &a, size_t i, char def) {
  if (i >= a.size())
    return def;
  if (a[i].isText) {
    std::string s = a[i].text();
    return s.empty() ? def : static_cast<char>(std::toupper(static_cast<unsigned char>(s[0])));
  }
  if (isPlainNumber(a[i])) {
    int k = static_cast<int>(a[i].number);
    return k == 0 ? 'N' : (k == 1 ? 'T' : 'C');
  }
  return def;
}
inline bool getI(const Args &a, size_t i, CallContext &ctx, long long &out) {
  return argInt(a, i, ctx, out);
}
inline bool getIdx(const Args &a, size_t i, CallContext &ctx, IVec &out) {
  Vec v;
  if (i >= a.size() || !readVec(a[i], v)) {
    ctx.fail("the " + ordinal(i) + " argument must be an array of whole numbers");
    return false;
  }
  out.resize(v.size());
  for (size_t k = 0; k < v.size(); k++) {
    if (!std::isfinite(v[k]) || v[k] != std::floor(v[k])) {
      ctx.fail("the " + ordinal(i) + " argument must be an array of whole numbers");
      return false;
    }
    out[k] = static_cast<long long>(v[k]);
  }
  return true;
}

// A right-hand side with n rows. A 1-D input is one column, and the result is
// given back 1-D, as SciPy does.
template <class T>
bool getB(const Args &a, size_t i, CallContext &ctx, size_t n, MatT<T> &B, bool &wasVec) {
  if (!getM(a, i, ctx, B))
    return false;
  wasVec = false;
  if (B.r == 1 && n != 1) {
    MatT<T> c(B.c, 1);
    c.a = B.a;
    B = c;
    wasVec = true;
  }
  if (B.r != n) {
    ctx.fail("the " + ordinal(i) + " argument must have " + std::to_string(n) + " rows");
    return false;
  }
  return true;
}
template <class T> Value outB(const MatT<T> &B, bool wasVec) {
  if (wasVec && B.c == 1)
    return toValue(B.a);
  return toValue(B);
}

// ---- results ----

inline Value num(double x) { return Value(x); }
inline Value num(const cd &z) { return cellOf(z); }
inline Value inum(long long k) { return Value(static_cast<double>(k)); }
// Pivots as an NC array, shifted by `base` (0 for SciPy's 0-based, 1 for raw LAPACK).
inline Value ivec(const std::vector<long long> &p, long long base = 0) {
  IVec q(p);
  for (auto &x : q)
    x += base;
  return toValue(q);
}
template <class T> Value outV(const std::vector<T> &v) { return toValue(v); }
template <class T> Value outM(const MatT<T> &m) { return toValue(m); }
inline Value realV(const Vec &v) { return toValue(v); }

// Length of a returned work array: the requested lwork, capped so that a huge
// request cannot exhaust memory (NC's routines do not use the array).
inline size_t workLen(long long requested) {
  return static_cast<size_t>(std::min<long long>(std::max<long long>(requested, 1), 1LL << 20));
}

// ---- strided vectors (BLAS n, off, inc) ----

// Element i of the n elements a strided BLAS vector visits.
inline long long sidx(long long off, long long inc, long long n, long long i) {
  return inc > 0 ? off + i * inc : off + (n - 1 - i) * (-inc);
}
// Checks that n elements with this offset and step lie inside a vector of `len`.
inline bool strideOk(CallContext &ctx, size_t len, long long n, long long off, long long inc,
                     const char *name) {
  if (n < 0 || off < 0 || inc == 0) {
    ctx.fail(std::string("invalid n, offset or increment for ") + name);
    return false;
  }
  if (n == 0)
    return true;
  const long long last = off + (n - 1) * (inc > 0 ? inc : -inc);
  if (last >= static_cast<long long>(len)) {
    ctx.fail(std::string(name) + " is too short for n, offset and increment");
    return false;
  }
  return true;
}
// SciPy's default n = (len(x) - off) / |inc|.
inline long long defaultN(size_t len, long long off, long long inc) {
  if (inc == 0)
    return 0;
  long long r = (static_cast<long long>(len) - off) / (inc > 0 ? inc : -inc);
  return r < 0 ? 0 : r;
}
// SciPy's default n = (len(x) - 1 - off) / |inc| + 1 (rot, syr, her).
inline long long defaultN1(size_t len, long long off, long long inc) {
  if (inc == 0 || static_cast<long long>(len) <= off)
    return 0;
  return (static_cast<long long>(len) - 1 - off) / (inc > 0 ? inc : -inc) + 1;
}
template <class T> std::vector<T> gather(const std::vector<T> &x, long long n, long long off, long long inc) {
  std::vector<T> g(static_cast<size_t>(n));
  for (long long i = 0; i < n; i++)
    g[static_cast<size_t>(i)] = x[static_cast<size_t>(sidx(off, inc, n, i))];
  return g;
}
template <class T>
void scatter(std::vector<T> &x, const std::vector<T> &g, long long off, long long inc) {
  const long long n = static_cast<long long>(g.size());
  for (long long i = 0; i < n; i++)
    x[static_cast<size_t>(sidx(off, inc, n, i))] = g[static_cast<size_t>(i)];
}

// ---- dense helpers ----

// op(A): 'N' as is, 'T' transposed, 'C' conjugate transposed.
template <class T> MatT<T> opOf(const MatT<T> &A, char t) {
  if (t == 'N')
    return A;
  return t == 'C' ? adjointOf(A) : transposeOf(A);
}
// The full symmetric (herm = false) or Hermitian matrix from one triangle.
template <class T> MatT<T> fullSym(const MatT<T> &A, bool lower, bool herm) {
  const size_t n = A.r;
  MatT<T> F(n, n);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      const bool inTri = lower ? i >= j : i <= j;
      if (inTri)
        F(i, j) = A(i, j);
      else
        F(i, j) = herm ? conjOf(A(j, i)) : A(j, i);
    }
  if (herm)
    for (size_t i = 0; i < n; i++)
      F(i, i) = T(realOf(F(i, i)));
  return F;
}
// The triangle of A, with a unit diagonal when `unit`.
template <class T> MatT<T> triOf(const MatT<T> &A, bool lower, bool unit) {
  MatT<T> F(A.r, A.c);
  for (size_t i = 0; i < A.r; i++)
    for (size_t j = 0; j < A.c; j++)
      if (lower ? i >= j : i <= j)
        F(i, j) = A(i, j);
  if (unit)
    for (size_t i = 0; i < std::min(A.r, A.c); i++)
      F(i, i) = T(1);
  return F;
}
// Copies the triangle of src into dst, leaving the other triangle of dst.
template <class T> void putTri(MatT<T> &dst, const MatT<T> &src, bool lower) {
  for (size_t i = 0; i < dst.r; i++)
    for (size_t j = 0; j < dst.c; j++)
      if (lower ? i >= j : i <= j)
        dst(i, j) = src(i, j);
}
template <class T> MatT<T> addM(const MatT<T> &x, const MatT<T> &y, T a = T(1), T b = T(1)) {
  MatT<T> z(x.r, x.c);
  for (size_t k = 0; k < x.a.size(); k++)
    z.a[k] = a * x.a[k] + b * y.a[k];
  return z;
}
// Solves op(T) X = B for a triangular T (no pivoting); false if singular.
template <class T>
bool triSolve(const MatT<T> &A, MatT<T> &B, bool lower, char trans, bool unit) {
  MatT<T> M = opOf(triOf(A, lower, unit), trans);
  const bool low = (trans == 'N') ? lower : !lower;
  const size_t n = M.r;
  for (size_t i = 0; i < n; i++)
    if (M(i, i) == T(0))
      return false;
  for (size_t c = 0; c < B.c; c++) {
    if (low) {
      for (size_t i = 0; i < n; i++) {
        T s = B(i, c);
        for (size_t k = 0; k < i; k++)
          s -= M(i, k) * B(k, c);
        B(i, c) = s / M(i, i);
      }
    } else {
      for (size_t i = n; i-- > 0;) {
        T s = B(i, c);
        for (size_t k = i + 1; k < n; k++)
          s -= M(i, k) * B(k, c);
        B(i, c) = s / M(i, i);
      }
    }
  }
  return true;
}

// ---- band and packed storage ----

// General band (gbmv layout): A(i,j) = ab(ku + i - j, j).
template <class T> MatT<T> gbToDense(const MatT<T> &ab, size_t m, size_t n, long long kl, long long ku,
                                     long long rowOff = 0) {
  MatT<T> A(m, n);
  for (size_t j = 0; j < n && j < ab.c; j++)
    for (size_t i = 0; i < m; i++) {
      long long r = rowOff + ku + static_cast<long long>(i) - static_cast<long long>(j);
      if (static_cast<long long>(i) - static_cast<long long>(j) > kl ||
          static_cast<long long>(j) - static_cast<long long>(i) > ku)
        continue;
      if (r >= 0 && r < static_cast<long long>(ab.r))
        A(i, j) = ab(static_cast<size_t>(r), j);
    }
  return A;
}
// Symmetric / Hermitian / triangular band with k off-diagonals: upper stores
// A(i,j) at ab(k + i - j, j), lower at ab(i - j, j).
template <class T> MatT<T> sbToDense(const MatT<T> &ab, long long k, bool lower) {
  const size_t n = ab.c;
  MatT<T> A(n, n);
  for (size_t j = 0; j < n; j++)
    for (size_t i = 0; i < n; i++) {
      long long d = static_cast<long long>(i) - static_cast<long long>(j);
      long long r = lower ? d : k + d;
      if ((lower && (d < 0 || d > k)) || (!lower && (d > 0 || -d > k)))
        continue;
      if (r >= 0 && r < static_cast<long long>(ab.r))
        A(i, j) = ab(static_cast<size_t>(r), j);
    }
  return A;
}
template <class T> MatT<T> denseToSb(const MatT<T> &A, size_t ldab, long long k, bool lower,
                                     const MatT<T> *keep = nullptr) {
  const size_t n = A.c;
  MatT<T> ab = keep ? *keep : MatT<T>(ldab, n);
  for (size_t j = 0; j < n; j++)
    for (size_t i = 0; i < n; i++) {
      long long d = static_cast<long long>(i) - static_cast<long long>(j);
      if ((lower && (d < 0 || d > k)) || (!lower && (d > 0 || -d > k)))
        continue;
      long long r = lower ? d : k + d;
      if (r >= 0 && r < static_cast<long long>(ab.r))
        ab(static_cast<size_t>(r), j) = A(i, j);
    }
  return ab;
}
inline size_t packIdx(size_t i, size_t j, size_t n, bool lower) {
  return lower ? i + (2 * n - j - 1) * j / 2 : i + j * (j + 1) / 2;
}
// Packed triangle -> dense matrix holding only that triangle.
template <class T> MatT<T> packedToTri(const std::vector<T> &ap, size_t n, bool lower) {
  MatT<T> A(n, n);
  for (size_t j = 0; j < n; j++)
    for (size_t i = 0; i < n; i++)
      if (lower ? i >= j : i <= j)
        A(i, j) = ap[packIdx(i, j, n, lower)];
  return A;
}
template <class T> std::vector<T> triToPacked(const MatT<T> &A, bool lower) {
  const size_t n = A.c;
  std::vector<T> ap(n * (n + 1) / 2);
  for (size_t j = 0; j < n; j++)
    for (size_t i = 0; i < n; i++)
      if (lower ? i >= j : i <= j)
        ap[packIdx(i, j, n, lower)] = A(i, j);
  return ap;
}
inline bool packedOk(CallContext &ctx, size_t len, long long n) {
  if (n < 0 || static_cast<size_t>(n) * (static_cast<size_t>(n) + 1) / 2 > len) {
    ctx.fail("the packed array must hold n*(n+1)/2 values");
    return false;
  }
  return true;
}

// LAPACK's dlamch values.
inline double lamch(char c) {
  const double eps = kEps * 0.5; // relative machine precision (rounding)
  switch (c) {
  case 'E': return eps;
  case 'S': return std::numeric_limits<double>::min();
  case 'B': return 2.0;
  case 'P': return eps * 2.0;
  case 'N': return 53.0;
  case 'R': return 1.0;
  case 'M': return -1021.0;
  case 'U': return std::numeric_limits<double>::min();
  case 'L': return 1024.0;
  case 'O': return std::numeric_limits<double>::max();
  default: return 0.0;
  }
}

// ---- Householder reflectors, as LAPACK's xLARFG ----
// Given alpha and x (n-1 entries, stride step), finds beta and tau so that
// H^H (alpha; x) = (beta; 0) with H = I - tau v v^H, v = (1; x_out).
template <class T> T larfg(T &alpha, T *x, size_t n1, size_t step) {
  double xn = 0.0;
  for (size_t i = 0; i < n1; i++)
    xn += absOf(x[i * step]) * absOf(x[i * step]);
  xn = std::sqrt(xn);
  const double ar = realOf(alpha), ai = imagOf(alpha);
  if (xn == 0.0 && ai == 0.0)
    return T(0);
  double beta = std::sqrt(ar * ar + ai * ai + xn * xn);
  if (ar >= 0)
    beta = -beta;
  T tau = mk<T>((beta - ar) / beta, -ai / beta);
  T scale = T(1) / (alpha - T(beta));
  for (size_t i = 0; i < n1; i++)
    x[i * step] *= scale;
  alpha = T(beta);
  return tau;
}
// Like larfg with beta >= 0 (xLARFGP).
template <class T> T larfgp(T &alpha, T *x, size_t n1, size_t step) {
  double xn = 0.0;
  for (size_t i = 0; i < n1; i++)
    xn += absOf(x[i * step]) * absOf(x[i * step]);
  xn = std::sqrt(xn);
  const double ar = realOf(alpha), ai = imagOf(alpha);
  if (xn == 0.0) {
    if (ai == 0.0) {
      if (ar >= 0)
        return T(0);
      alpha = T(-ar);
      return T(2);
    }
    const double b = std::sqrt(ar * ar + ai * ai);
    alpha = T(b);
    return mk<T>(1 - ar / b, -ai / b);
  }
  double beta = std::sqrt(ar * ar + ai * ai + xn * xn);
  if (ar < 0)
    beta = -beta;
  T al = alpha + T(beta);
  T tau;
  if (beta < 0) {
    beta = -beta;
    tau = -al / T(beta);
  } else {
    double r = ai * (ai / realOf(al)) + xn * (xn / realOf(al));
    tau = mk<T>(r / beta, -ai / beta);
    al = mk<T>(-r, ai);
  }
  T sc = T(1) / al;
  for (size_t i = 0; i < n1; i++)
    x[i * step] *= sc;
  alpha = T(beta);
  return tau;
}
// C := H C (left) or C H (right) with H = I - tau v v^H; v has length m (left) or n (right).
template <class T> void applyH(MatT<T> &C, const std::vector<T> &v, T tau, bool left, size_t r0 = 0,
                               size_t c0 = 0) {
  if (tau == T(0))
    return;
  const size_t len = v.size();
  if (left) {
    for (size_t j = c0; j < C.c; j++) {
      T s(0);
      for (size_t i = 0; i < len; i++)
        s += conjOf(v[i]) * C(r0 + i, j);
      s *= tau;
      for (size_t i = 0; i < len; i++)
        C(r0 + i, j) -= v[i] * s;
    }
  } else {
    for (size_t i = r0; i < C.r; i++) {
      T s(0);
      for (size_t j = 0; j < len; j++)
        s += C(i, c0 + j) * v[j];
      s *= tau;
      for (size_t j = 0; j < len; j++)
        C(i, c0 + j) -= s * conjOf(v[j]);
    }
  }
}

} // namespace blw
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_BLW_COMMON_H
