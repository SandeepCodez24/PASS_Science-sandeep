// The routine groups of section 25. Each .cpp file registers one group.
#ifndef NC_SCIPY_BLW_GROUPS_H
#define NC_SCIPY_BLW_GROUPS_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

void registerBlwBlas(Registry &reg);      // blw_blas.cpp: BLAS levels 1, 2 and 3
void registerBlwLu(Registry &reg);        // blw_lu.cpp: LU, band, tridiagonal, triangular, norms
void registerBlwChol(Registry &reg);      // blw_chol.cpp: Cholesky, packed and RFP formats
void registerBlwSym(Registry &reg);       // blw_sym.cpp: Bunch-Kaufman (sy*, he*)
void registerBlwQr(Registry &reg);        // blw_qr.cpp: QR, RQ, RZ, least squares, reflectors
void registerBlwEig(Registry &reg);       // blw_eig.cpp: eigenproblems and Schur forms
void registerBlwSvd(Registry &reg);       // blw_svd.cpp: SVD and cosine-sine decomposition
void registerBlwLwork(Registry &reg);     // blw_lwork.cpp: workspace queries, lapack_routine

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_BLW_GROUPS_H
