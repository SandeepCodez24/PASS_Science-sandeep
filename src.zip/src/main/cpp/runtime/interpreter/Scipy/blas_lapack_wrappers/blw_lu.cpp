// LU factorisations and solvers: general (ge), band (gb), tridiagonal (gt) and
// triangular (tr, tb) matrices, with condition numbers, equilibration and
// norms. The factor layouts and pivots are LAPACK's, so they match SciPy.
// Condition numbers use the exact norm of the inverse where LAPACK estimates
// it; for small matrices the two agree.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

// A norm letter: "1"/"O" -> '1', "I", "F"/"E" -> 'F', "M". A number 1 is '1'.
char nopt(const Args &a, size_t i, char def) {
  if (i >= a.size())
    return def;
  char c = def;
  if (a[i].isText) {
    std::string s = a[i].text();
    if (!s.empty())
      c = static_cast<char>(std::toupper(static_cast<unsigned char>(s[0])));
  } else if (isPlainNumber(a[i])) {
    c = a[i].number == 1.0 ? '1' : def;
  }
  if (c == 'O')
    c = '1';
  if (c == 'E')
    c = 'F';
  return c;
}

template <class T> double normOf(const MatT<T> &A, char nm) {
  double r = 0.0;
  if (nm == 'M') {
    for (const T &e : A.a)
      r = std::max(r, absOf(e));
  } else if (nm == '1') {
    for (size_t j = 0; j < A.c; j++) {
      double s = 0.0;
      for (size_t i = 0; i < A.r; i++)
        s += absOf(A(i, j));
      r = std::max(r, s);
    }
  } else if (nm == 'I') {
    for (size_t i = 0; i < A.r; i++) {
      double s = 0.0;
      for (size_t j = 0; j < A.c; j++)
        s += absOf(A(i, j));
      r = std::max(r, s);
    }
  } else {
    r = la::frobenius(A);
  }
  return r;
}

// LU with partial pivoting as xGETRF: pivots 0-based, info = first zero pivot + 1.
template <class T> long long getrf(MatT<T> &A, std::vector<long long> &piv) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  piv.assign(k, 0);
  long long info = 0;
  for (size_t j = 0; j < k; j++) {
    size_t p = j;
    double best = cabs1(A(j, j));
    for (size_t i = j + 1; i < m; i++)
      if (cabs1(A(i, j)) > best) {
        best = cabs1(A(i, j));
        p = i;
      }
    piv[j] = static_cast<long long>(p);
    if (A(p, j) == T(0)) {
      if (info == 0)
        info = static_cast<long long>(j) + 1;
      continue;
    }
    if (p != j)
      for (size_t c = 0; c < n; c++)
        std::swap(A(j, c), A(p, c));
    const T inv = T(1) / A(j, j);
    for (size_t i = j + 1; i < m; i++)
      A(i, j) *= inv;
    for (size_t i = j + 1; i < m; i++) {
      const T f = A(i, j);
      if (f != T(0))
        for (size_t c = j + 1; c < n; c++)
          A(i, c) -= f * A(j, c);
    }
  }
  return info;
}

// Solves op(A) X = B with the getrf factors (n x n).
template <class T>
void getrs(const MatT<T> &LU, const std::vector<long long> &piv, MatT<T> &B, char trans) {
  const size_t n = LU.r;
  if (trans == 'N') {
    for (size_t k = 0; k < piv.size(); k++)
      if (static_cast<size_t>(piv[k]) != k)
        for (size_t c = 0; c < B.c; c++)
          std::swap(B(k, c), B(static_cast<size_t>(piv[k]), c));
    triSolve(LU, B, true, 'N', true);
    triSolve(LU, B, false, 'N', false);
  } else {
    triSolve(LU, B, false, trans, false);
    triSolve(LU, B, true, trans, true);
    for (size_t k = piv.size(); k-- > 0;)
      if (static_cast<size_t>(piv[k]) != k)
        for (size_t c = 0; c < B.c; c++)
          std::swap(B(k, c), B(static_cast<size_t>(piv[k]), c));
  }
  (void)n;
}

// Inverse of the matrix factored by a solver: solve(B) solves A X = B in place.
template <class T, class S> MatT<T> inverseBy(size_t n, S solve) {
  MatT<T> X = MatT<T>::eye(n);
  solve(X);
  return X;
}
// rcond = 1 / (anorm * ||A^-1||), with ||A^-1|| in the 1-norm or the inf-norm.
template <class T> double rcondOf(double anorm, const MatT<T> &Ainv, char nm) {
  if (anorm == 0.0 || Ainv.r == 0)
    return Ainv.r == 0 ? 1.0 : 0.0;
  const double in = normOf(Ainv, nm == 'I' ? 'I' : '1');
  if (!std::isfinite(in) || in == 0.0)
    return 0.0;
  return (1.0 / in) / anorm;
}
template <class T> bool hasZeroDiag(const MatT<T> &U, size_t n) {
  for (size_t i = 0; i < n; i++)
    if (U(i, i) == T(0))
      return true;
  return false;
}

// Row and column scalings as xGEEQU (pow2 = false) or xGEEQUB.
template <class T> Value geequ(const MatT<T> &A, bool pow2) {
  const size_t m = A.r, n = A.c;
  const double smlnum = lamch('S'), bignum = 1.0 / smlnum;
  const double logr = std::log(2.0);
  auto p2 = [&](double v) { return std::pow(2.0, static_cast<double>(static_cast<long long>(std::log(v) / logr))); };
  Vec r(m, 0.0), c(n, 0.0);
  long long info = 0;
  double amax = 0.0;
  for (size_t i = 0; i < m; i++)
    for (size_t j = 0; j < n; j++)
      r[i] = std::max(r[i], cabs1(A(i, j)));
  if (pow2)
    for (size_t i = 0; i < m; i++)
      if (r[i] > 0.0)
        r[i] = p2(r[i]);
  double rcmin = bignum, rcmax = 0.0;
  for (size_t i = 0; i < m; i++) {
    rcmax = std::max(rcmax, r[i]);
    rcmin = std::min(rcmin, r[i]);
  }
  amax = rcmax;
  double rowcnd = 0.0, colcnd = 0.0;
  if (rcmin == 0.0) {
    for (size_t i = 0; i < m; i++)
      if (r[i] == 0.0) {
        info = static_cast<long long>(i) + 1;
        break;
      }
  } else {
    for (size_t i = 0; i < m; i++)
      r[i] = 1.0 / std::min(std::max(r[i], smlnum), bignum);
    rowcnd = std::max(rcmin, smlnum) / std::min(rcmax, bignum);
    for (size_t j = 0; j < n; j++)
      for (size_t i = 0; i < m; i++)
        c[j] = std::max(c[j], cabs1(A(i, j)) * r[i]);
    if (pow2)
      for (size_t j = 0; j < n; j++)
        if (c[j] > 0.0)
          c[j] = p2(c[j]);
    rcmin = bignum;
    rcmax = 0.0;
    for (size_t j = 0; j < n; j++) {
      rcmin = std::min(rcmin, c[j]);
      rcmax = std::max(rcmax, c[j]);
    }
    if (rcmin == 0.0) {
      for (size_t j = 0; j < n; j++)
        if (c[j] == 0.0) {
          info = static_cast<long long>(m + j) + 1;
          break;
        }
    } else {
      for (size_t j = 0; j < n; j++)
        c[j] = 1.0 / std::min(std::max(c[j], smlnum), bignum);
      colcnd = std::max(rcmin, smlnum) / std::min(rcmax, bignum);
    }
  }
  return makeDict({{"r", toValue(r)},
                   {"c", toValue(c)},
                   {"rowcnd", Value(rowcnd)},
                   {"colcnd", Value(colcnd)},
                   {"amax", Value(amax)},
                   {"info", inum(info)}});
}

// |op(A)| |x| + |b| based backward error, and LAPACK's forward error bound with
// the exact norm of |A^-1| in place of the estimate.
template <class T>
void refineErrors(const MatT<T> &A, const MatT<T> &Ainv, const MatT<T> &B, const MatT<T> &X, char trans,
                  Vec &ferr, Vec &berr) {
  MatT<T> M = opOf(A, trans), Mi = opOf(Ainv, trans);
  const size_t n = M.r;
  const double eps = lamch('E'), safe1 = (static_cast<double>(n) + 1) * lamch('S');
  ferr.assign(B.c, 0.0);
  berr.assign(B.c, 0.0);
  for (size_t c = 0; c < B.c; c++) {
    Vec w(n), rr(n);
    for (size_t i = 0; i < n; i++) {
      T r = B(i, c);
      double s = cabs1(B(i, c));
      for (size_t k = 0; k < n; k++) {
        r -= M(i, k) * X(k, c);
        s += cabs1(M(i, k)) * cabs1(X(k, c));
      }
      rr[i] = cabs1(r);
      w[i] = s;
    }
    double be = 0.0;
    for (size_t i = 0; i < n; i++)
      be = std::max(be, w[i] > safe1 ? rr[i] / w[i] : (rr[i] + safe1) / (w[i] + safe1));
    berr[c] = be;
    double num = 0.0, xn = 0.0;
    for (size_t i = 0; i < n; i++) {
      double s = 0.0;
      for (size_t k = 0; k < n; k++)
        s += absOf(Mi(i, k)) * (rr[k] + (static_cast<double>(n) + 1) * eps * w[k]);
      num = std::max(num, s);
      xn = std::max(xn, absOf(X(i, c)));
    }
    ferr[c] = xn > 0.0 ? num / xn : 0.0;
  }
}

// ---- band LU (xGBTRF): ab has 2*kl+ku+1 rows, A(i,j) at ab(kl+ku+i-j, j) ----

template <class T>
long long gbtrf(MatT<T> &ab, size_t m, size_t n, long long kl, long long ku, std::vector<long long> &piv) {
  const long long kv = kl + ku;
  MatT<T> W = gbToDense(ab, m, n, kl, ku, kl);
  const size_t k = std::min(m, n);
  piv.assign(k, 0);
  long long info = 0;
  size_t ju = 0;
  for (size_t j = 0; j < k; j++) {
    const size_t km = static_cast<size_t>(std::min<long long>(kl, static_cast<long long>(m - 1 - j)));
    size_t p = j;
    double best = cabs1(W(j, j));
    for (size_t i = j + 1; i <= j + km; i++)
      if (cabs1(W(i, j)) > best) {
        best = cabs1(W(i, j));
        p = i;
      }
    piv[j] = static_cast<long long>(p);
    if (W(p, j) != T(0)) {
      ju = std::max(ju, std::min<size_t>(j + static_cast<size_t>(ku) + (p - j), n - 1));
      if (p != j)
        for (size_t c = j; c <= ju; c++)
          std::swap(W(j, c), W(p, c));
      const T inv = T(1) / W(j, j);
      for (size_t i = j + 1; i <= j + km; i++)
        W(i, j) *= inv;
      if (ju > j)
        for (size_t i = j + 1; i <= j + km; i++)
          for (size_t c = j + 1; c <= ju; c++)
            W(i, c) -= W(i, j) * W(j, c);
    } else if (info == 0) {
      info = static_cast<long long>(j) + 1;
    }
  }
  for (size_t j = 0; j < n; j++)
    for (size_t i = 0; i < m; i++) {
      long long d = static_cast<long long>(i) - static_cast<long long>(j);
      if (d < -kv || d > kl)
        continue;
      long long r = kv + d;
      if (r >= 0 && r < static_cast<long long>(ab.r))
        ab(static_cast<size_t>(r), j) = W(i, j);
    }
  return info;
}
template <class T>
void gbtrs(const MatT<T> &ab, long long kl, long long ku, const std::vector<long long> &piv, MatT<T> &B,
           char trans) {
  const size_t n = ab.c;
  const long long kv = kl + ku;
  auto L = [&](size_t i, size_t j) { return ab(static_cast<size_t>(kv + static_cast<long long>(i - j)), j); };
  MatT<T> U(n, n);
  for (size_t j = 0; j < n; j++)
    for (size_t i = (j > static_cast<size_t>(kv) ? j - static_cast<size_t>(kv) : 0); i <= j; i++)
      U(i, j) = ab(static_cast<size_t>(kv + static_cast<long long>(i) - static_cast<long long>(j)), j);
  if (trans == 'N') {
    for (size_t j = 0; j + 1 < n; j++) {
      const size_t lm = std::min<size_t>(static_cast<size_t>(kl), n - 1 - j);
      const size_t l = static_cast<size_t>(piv[j]);
      for (size_t c = 0; c < B.c; c++) {
        if (l != j)
          std::swap(B(l, c), B(j, c));
        for (size_t i = 1; i <= lm; i++)
          B(j + i, c) -= L(j + i, j) * B(j, c);
      }
    }
    triSolve(U, B, false, 'N', false);
  } else {
    triSolve(U, B, false, trans, false);
    for (size_t j = n - 1; j-- > 0;) {
      const size_t lm = std::min<size_t>(static_cast<size_t>(kl), n - 1 - j);
      const size_t l = static_cast<size_t>(piv[j]);
      for (size_t c = 0; c < B.c; c++) {
        for (size_t i = 1; i <= lm; i++) {
          T lv = L(j + i, j);
          B(j, c) -= (trans == 'C' ? conjOf(lv) : lv) * B(j + i, c);
        }
        if (l != j)
          std::swap(B(l, c), B(j, c));
      }
    }
  }
}

// ---- tridiagonal LU (xGTTRF), pivots 1-based as SciPy returns them ----

template <class T>
long long gttrf(std::vector<T> &dl, std::vector<T> &d, std::vector<T> &du, std::vector<T> &du2,
                std::vector<long long> &ipiv) {
  const size_t n = d.size();
  ipiv.resize(n);
  for (size_t i = 0; i < n; i++)
    ipiv[i] = static_cast<long long>(i) + 1;
  du2.assign(n > 2 ? n - 2 : 0, T(0));
  for (size_t i = 0; i + 2 < n; i++) {
    if (cabs1(d[i]) >= cabs1(dl[i])) {
      if (d[i] != T(0)) {
        T f = dl[i] / d[i];
        dl[i] = f;
        d[i + 1] -= f * du[i];
      }
    } else {
      T f = d[i] / dl[i];
      d[i] = dl[i];
      dl[i] = f;
      T t = du[i];
      du[i] = d[i + 1];
      d[i + 1] = t - f * d[i + 1];
      du2[i] = du[i + 1];
      du[i + 1] = -f * du[i + 1];
      ipiv[i] = static_cast<long long>(i) + 2;
    }
  }
  if (n > 1) {
    size_t i = n - 2;
    if (cabs1(d[i]) >= cabs1(dl[i])) {
      if (d[i] != T(0)) {
        T f = dl[i] / d[i];
        dl[i] = f;
        d[i + 1] -= f * du[i];
      }
    } else {
      T f = d[i] / dl[i];
      d[i] = dl[i];
      dl[i] = f;
      T t = du[i];
      du[i] = d[i + 1];
      d[i + 1] = t - f * d[i + 1];
      ipiv[i] = static_cast<long long>(i) + 2;
    }
  }
  for (size_t i = 0; i < n; i++)
    if (d[i] == T(0))
      return static_cast<long long>(i) + 1;
  return 0;
}
template <class T>
void gttrs(const std::vector<T> &dl, const std::vector<T> &d, const std::vector<T> &du,
           const std::vector<T> &du2, const std::vector<long long> &ipiv, MatT<T> &B, char trans) {
  const size_t n = d.size();
  if (n == 0)
    return;
  auto cj = [&](T v) { return trans == 'C' ? conjOf(v) : v; };
  for (size_t c = 0; c < B.c; c++) {
    if (trans == 'N') {
      for (size_t i = 0; i + 1 < n; i++) {
        const size_t ip = static_cast<size_t>(ipiv[i] - 1);
        T t = B(i + 1 - ip + i, c) - dl[i] * B(ip, c);
        B(i, c) = B(ip, c);
        B(i + 1, c) = t;
      }
      B(n - 1, c) /= d[n - 1];
      if (n > 1)
        B(n - 2, c) = (B(n - 2, c) - du[n - 2] * B(n - 1, c)) / d[n - 2];
      for (size_t i = n >= 2 ? n - 2 : 0; i-- > 0;)
        B(i, c) = (B(i, c) - du[i] * B(i + 1, c) - du2[i] * B(i + 2, c)) / d[i];
    } else {
      B(0, c) /= cj(d[0]);
      if (n > 1)
        B(1, c) = (B(1, c) - cj(du[0]) * B(0, c)) / cj(d[1]);
      for (size_t i = 2; i < n; i++)
        B(i, c) = (B(i, c) - cj(du[i - 1]) * B(i - 1, c) - cj(du2[i - 2]) * B(i - 2, c)) / cj(d[i]);
      for (size_t i = n - 1; i-- > 0;) {
        const size_t ip = static_cast<size_t>(ipiv[i] - 1);
        T t = B(i, c) - cj(dl[i]) * B(i + 1, c);
        B(i, c) = B(ip, c);
        B(ip, c) = t;
      }
    }
  }
}
template <class T>
MatT<T> tridiag(const std::vector<T> &dl, const std::vector<T> &d, const std::vector<T> &du) {
  const size_t n = d.size();
  MatT<T> A(n, n);
  for (size_t i = 0; i < n; i++) {
    A(i, i) = d[i];
    if (i + 1 < n) {
      A(i + 1, i) = dl[i];
      A(i, i + 1) = du[i];
    }
  }
  return A;
}
template <class T>
bool getTri(const Args &a, size_t i0, CallContext &ctx, std::vector<T> &dl, std::vector<T> &d,
            std::vector<T> &du) {
  if (!getV(a, i0, ctx, dl) || !getV(a, i0 + 1, ctx, d) || !getV(a, i0 + 2, ctx, du))
    return false;
  const size_t n = d.size();
  if (n == 0 || dl.size() + 1 < n || du.size() + 1 < n) {
    ctx.fail("dl and du must hold n-1 values for a d of n values");
    return false;
  }
  dl.resize(n - 1);
  du.resize(n - 1);
  return true;
}

} // namespace

void registerBlwLu(Registry &reg) {
  // ---- general matrices ----
  SP_ADD("lapack_getrf", 1, 2, "a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      std::vector<long long> piv;
      long long info = getrf(A, piv);
      return makeDict({{"lu", outM(A)}, {"piv", ivec(piv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gesv", 2, 4, "a, b") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
        return Value(0.0);
      std::vector<long long> piv;
      long long info = getrf(A, piv);
      if (info == 0)
        getrs(A, piv, B, 'N');
      return makeDict({{"lu", outM(A)}, {"piv", ivec(piv)}, {"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_getrs", 3, 5, "lu, piv, b, trans") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> LU, B;
      IVec piv;
      bool wv;
      if (!getSq(a, 0, ctx, LU) || !getIdx(a, 1, ctx, piv) || !getB(a, 2, ctx, LU.r, B, wv))
        return Value(0.0);
      if (piv.size() != LU.r) {
        ctx.fail("piv must hold n pivots");
        return Value(0.0);
      }
      for (auto p : piv)
        if (p < 0 || p >= static_cast<long long>(LU.r)) {
          ctx.fail("pivots must lie between 0 and n-1");
          return Value(0.0);
        }
      getrs(LU, std::vector<long long>(piv.begin(), piv.end()), B, copt(a, 3, 'N'));
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_getri", 2, 4, "lu, piv, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> LU;
      IVec piv;
      if (!getSq(a, 0, ctx, LU) || !getIdx(a, 1, ctx, piv))
        return Value(0.0);
      if (piv.size() != LU.r) {
        ctx.fail("piv must hold n pivots");
        return Value(0.0);
      }
      for (auto p : piv)
        if (p < 0 || p >= static_cast<long long>(LU.r)) {
          ctx.fail("pivots must lie between 0 and n-1");
          return Value(0.0);
        }
      for (size_t i = 0; i < LU.r; i++)
        if (LU(i, i) == T(0))
          return makeDict({{"inv_a", outM(LU)}, {"info", inum(static_cast<long long>(i) + 1)}});
      std::vector<long long> p(piv.begin(), piv.end());
      MatT<T> X = inverseBy<T>(LU.r, [&](MatT<T> &B) { getrs(LU, p, B, 'N'); });
      return makeDict({{"inv_a", outM(X)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_getc2", 1, 2, "a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      const size_t n = A.r;
      const double eps = lamch('P'), smlnum = lamch('S') / eps;
      std::vector<long long> ip(n), jp(n);
      long long info = 0;
      double smin = 0.0;
      if (n == 1) {
        ip[0] = jp[0] = 0;
        if (absOf(A(0, 0)) < smlnum) {
          info = 1;
          A(0, 0) = T(smlnum);
        }
        return makeDict({{"lu", outM(A)}, {"ipiv", ivec(ip)}, {"jpiv", ivec(jp)}, {"info", inum(info)}});
      }
      for (size_t i = 0; i + 1 < n; i++) {
        double xmax = 0.0;
        size_t ipv = i, jpv = i;
        for (size_t r = i; r < n; r++)
          for (size_t c = i; c < n; c++)
            if (absOf(A(r, c)) >= xmax) {
              xmax = absOf(A(r, c));
              ipv = r;
              jpv = c;
            }
        if (i == 0)
          smin = std::max(eps * xmax, smlnum);
        if (ipv != i)
          for (size_t c = 0; c < n; c++)
            std::swap(A(ipv, c), A(i, c));
        ip[i] = static_cast<long long>(ipv);
        if (jpv != i)
          for (size_t r = 0; r < n; r++)
            std::swap(A(r, jpv), A(r, i));
        jp[i] = static_cast<long long>(jpv);
        if (absOf(A(i, i)) < smin) {
          info = static_cast<long long>(i) + 1;
          A(i, i) = T(smin);
        }
        for (size_t r = i + 1; r < n; r++)
          A(r, i) /= A(i, i);
        for (size_t r = i + 1; r < n; r++)
          for (size_t c = i + 1; c < n; c++)
            A(r, c) -= A(r, i) * A(i, c);
      }
      if (absOf(A(n - 1, n - 1)) < smin) {
        info = static_cast<long long>(n);
        A(n - 1, n - 1) = T(smin);
      }
      ip[n - 1] = jp[n - 1] = static_cast<long long>(n - 1);
      return makeDict({{"lu", outM(A)}, {"ipiv", ivec(ip)}, {"jpiv", ivec(jp)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gesc2", 4, 5, "lu, rhs, ipiv, jpiv") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> LU;
      std::vector<T> rhs;
      IVec ip, jp;
      if (!getSq(a, 0, ctx, LU) || !getV(a, 1, ctx, rhs) || !getIdx(a, 2, ctx, ip) || !getIdx(a, 3, ctx, jp))
        return Value(0.0);
      const size_t n = LU.r;
      if (rhs.size() != n || ip.size() < n || jp.size() < n) {
        ctx.fail("rhs, ipiv and jpiv must hold n values");
        return Value(0.0);
      }
      for (size_t i = 0; i < n; i++)
        if (ip[i] < 0 || ip[i] >= static_cast<long long>(n) || jp[i] < 0 || jp[i] >= static_cast<long long>(n)) {
          ctx.fail("pivots must lie between 0 and n-1");
          return Value(0.0);
        }
      const double eps = lamch('P'), smlnum = lamch('S') / eps;
      for (size_t i = 0; i + 1 < n; i++)
        std::swap(rhs[i], rhs[static_cast<size_t>(ip[i])]);
      for (size_t i = 0; i + 1 < n; i++)
        for (size_t j = i + 1; j < n; j++)
          rhs[j] -= LU(j, i) * rhs[i];
      double scale = 1.0;
      size_t im = 0;
      for (size_t i = 1; i < n; i++)
        if (cabs1(rhs[i]) > cabs1(rhs[im]))
          im = i;
      if (n && 2.0 * smlnum * absOf(rhs[im]) > absOf(LU(n - 1, n - 1))) {
        const double t = 0.5 / absOf(rhs[im]);
        for (auto &e : rhs)
          e *= t;
        scale *= t;
      }
      for (size_t i = n; i-- > 0;) {
        const T t = T(1) / LU(i, i);
        rhs[i] *= t;
        for (size_t j = i + 1; j < n; j++)
          rhs[i] -= rhs[j] * (LU(i, j) * t);
      }
      for (size_t i = n - 1; i-- > 0;)
        std::swap(rhs[i], rhs[static_cast<size_t>(jp[i])]);
      return makeDict({{"x", outV(rhs)}, {"scale", Value(scale)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gecon", 2, 3, "a, anorm, norm") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> LU;
      double anorm;
      if (!getSq(a, 0, ctx, LU) || !argNumber(a, 1, ctx, anorm))
        return Value(0.0);
      const char nm = nopt(a, 2, '1');
      if (hasZeroDiag(LU, LU.r))
        return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
      std::vector<long long> id(LU.r);
      for (size_t i = 0; i < LU.r; i++)
        id[i] = static_cast<long long>(i);
      MatT<T> X = inverseBy<T>(LU.r, [&](MatT<T> &B) { getrs(LU, id, B, 'N'); });
      return makeDict({{"rcond", Value(rcondOf(anorm, X, nm))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_geequ", 1, 1, "a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      return geequ(A, false);
    });
  } SP_ENDC
  SP_ADD("lapack_geequb", 1, 1, "a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      return geequ(A, true);
    });
  } SP_ENDC
  SP_ADD("lapack_gesvx", 2, 9, "a, b, fact, trans, af, ipiv, equed, r, c") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
        return Value(0.0);
      const size_t n = A.r;
      const char fact = copt(a, 2, 'E'), trans = copt(a, 3, 'N');
      char equed = 'N';
      Vec r(n, 1.0), c(n, 1.0);
      MatT<T> LU;
      std::vector<long long> piv;
      long long info = 0;
      if (fact == 'F') {
        IVec p;
        if (!getSq(a, 4, ctx, LU) || !getIdx(a, 5, ctx, p))
          return Value(0.0);
        if (LU.r != n || p.size() != n) {
          ctx.fail("af and ipiv must match the size of a");
          return Value(0.0);
        }
        piv.assign(p.begin(), p.end());
        for (auto q : piv)
          if (q < 0 || q >= static_cast<long long>(n)) {
            ctx.fail("pivots must lie between 0 and n-1");
            return Value(0.0);
          }
        equed = copt(a, 6, 'N');
        if (equed == 'R' || equed == 'B')
          if (!getVec(a, 7, ctx, r) || r.size() != n)
            return Value(0.0);
        if (equed == 'C' || equed == 'B')
          if (!getVec(a, 8, ctx, c) || c.size() != n)
            return Value(0.0);
      } else {
        if (fact == 'E') {
          Value q = geequ(A, false);
          const long long qi = static_cast<long long>(dictGet(q, "info")->number);
          if (qi == 0) {
            readVec(*dictGet(q, "r"), r);
            readVec(*dictGet(q, "c"), c);
            const double rowcnd = dictGet(q, "rowcnd")->number, colcnd = dictGet(q, "colcnd")->number;
            const double amax = dictGet(q, "amax")->number;
            const double small = lamch('S') / lamch('P'), large = 1.0 / small, thresh = 0.1;
            bool rs = !(rowcnd >= thresh && amax >= small && amax <= large);
            bool cs = !(colcnd >= thresh);
            equed = rs ? (cs ? 'B' : 'R') : (cs ? 'C' : 'N');
            if (!rs)
              r.assign(n, 1.0);
            if (!cs)
              c.assign(n, 1.0);
            for (size_t i = 0; i < n; i++)
              for (size_t j = 0; j < n; j++)
                A(i, j) *= T(r[i] * c[j]);
          }
        }
      }
      // b is scaled by r (trans N) or c.
      const bool rowS = equed == 'R' || equed == 'B', colS = equed == 'C' || equed == 'B';
      for (size_t i = 0; i < n; i++)
        for (size_t k = 0; k < B.c; k++)
          B(i, k) *= T(trans == 'N' ? (rowS ? r[i] : 1.0) : (colS ? c[i] : 1.0));
      if (fact != 'F') {
        LU = A;
        info = getrf(LU, piv);
        if (info > 0) {
          // rcond is the reciprocal pivot growth in this case.
          return makeDict({{"as", outM(A)}, {"lu", outM(LU)}, {"ipiv", ivec(piv)},
                           {"equed", Value(std::string(1, equed))}, {"rs", toValue(r)}, {"cs", toValue(c)},
                           {"bs", outB(B, wv)}, {"x", outB(MatT<T>(B.r, B.c), wv)}, {"rcond", Value(0.0)},
                           {"ferr", toValue(Vec(B.c, 0.0))}, {"berr", toValue(Vec(B.c, 0.0))},
                           {"info", inum(info)}});
        }
      }
      const double anorm = normOf(A, trans == 'N' ? '1' : 'I');
      MatT<T> Ainv = inverseBy<T>(n, [&](MatT<T> &X) { getrs(LU, piv, X, 'N'); });
      const double rcond = rcondOf(anorm, Ainv, '1');
      MatT<T> X = B;
      getrs(LU, piv, X, trans);
      Vec ferr, berr;
      refineErrors(A, Ainv, B, X, trans, ferr, berr);
      for (size_t i = 0; i < n; i++)
        for (size_t k = 0; k < X.c; k++)
          X(i, k) *= T(trans == 'N' ? (colS ? c[i] : 1.0) : (rowS ? r[i] : 1.0));
      if (rcond < lamch('E'))
        info = static_cast<long long>(n) + 1;
      return makeDict({{"as", outM(A)}, {"lu", outM(LU)}, {"ipiv", ivec(piv)},
                       {"equed", Value(std::string(1, equed))}, {"rs", toValue(r)}, {"cs", toValue(c)},
                       {"bs", outB(B, wv)}, {"x", outB(X, wv)}, {"rcond", Value(rcond)},
                       {"ferr", toValue(ferr)}, {"berr", toValue(berr)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_laswp", 2, 6, "a, piv, k1, k2, off, inc") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      IVec piv;
      if (!getM(a, 0, ctx, A) || !getIdx(a, 1, ctx, piv))
        return Value(0.0);
      const long long k1 = iopt(a, 2, 0), k2 = given(a, 3) ? iopt(a, 3, 0) : static_cast<long long>(piv.size()) - 1;
      const long long off = iopt(a, 4, 0), inc = iopt(a, 5, 1);
      if (k1 < 0 || k2 < k1 || inc == 0) {
        ctx.fail("invalid k1, k2 or inc");
        return Value(0.0);
      }
      auto swapRows = [&](long long i, long long ixp) -> bool {
        if (ixp < 0 || ixp >= static_cast<long long>(piv.size())) {
          ctx.fail("piv is too short for k1, k2, off and inc");
          return false;
        }
        const long long p = piv[static_cast<size_t>(ixp)];
        if (i >= static_cast<long long>(A.r) || p < 0 || p >= static_cast<long long>(A.r)) {
          ctx.fail("a row index is outside the matrix");
          return false;
        }
        if (p != i)
          for (size_t c = 0; c < A.c; c++)
            std::swap(A(static_cast<size_t>(i), c), A(static_cast<size_t>(p), c));
        return true;
      };
      if (inc > 0) {
        long long ix = k1;
        for (long long i = k1; i <= k2; i++, ix += inc)
          if (!swapRows(i, off + ix))
            return Value(0.0);
      } else {
        for (long long i = k2; i >= k1; i--)
          if (!swapRows(i, off + i * (-inc)))
            return Value(0.0);
      }
      return outM(A);
    });
  } SP_ENDC
  SP_ADD("lapack_lange", 2, 2, "norm, a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 1, ctx, A))
        return Value(0.0);
      return Value(normOf(A, nopt(a, 0, 'M')));
    });
  } SP_ENDC
  SP_ADD("lapack_lantr", 2, 4, "norm, a, uplo, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 1, ctx, A))
        return Value(0.0);
      const bool lower = copt(a, 2, 'U') == 'L', unit = copt(a, 3, 'N') == 'U';
      MatT<T> Tr = triOf(A, lower, unit);
      const char nm = nopt(a, 0, 'M');
      double r = normOf(Tr, nm);
      if (nm == 'M' && unit && std::min(A.r, A.c) > 0)
        r = std::max(r, 1.0);
      return Value(r);
    });
  } SP_ENDC
  SP_ADD("lapack_langb", 4, 5, "norm, kl, ku, ab, ldab") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long kl, ku;
      MatT<T> ab;
      if (!getI(a, 1, ctx, kl) || !getI(a, 2, ctx, ku) || !getM(a, 3, ctx, ab))
        return Value(0.0);
      if (kl < 0 || ku < 0 || ab.r < static_cast<size_t>(kl + ku + 1)) {
        ctx.fail("ab must have at least kl+ku+1 rows");
        return Value(0.0);
      }
      return Value(normOf(gbToDense(ab, ab.c, ab.c, kl, ku), nopt(a, 0, 'M')));
    });
  } SP_ENDC

  // ---- band ----
  SP_ADD("lapack_gbtrf", 3, 7, "ab, kl, ku, m, n, ldab") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab;
      long long kl, ku;
      if (!getM(a, 0, ctx, ab) || !getI(a, 1, ctx, kl) || !getI(a, 2, ctx, ku))
        return Value(0.0);
      const long long n = given(a, 4) ? iopt(a, 4, 0) : static_cast<long long>(ab.c);
      const long long m = given(a, 3) ? iopt(a, 3, 0) : n;
      if (kl < 0 || ku < 0 || m < 0 || n < 0 || n > static_cast<long long>(ab.c) ||
          ab.r < static_cast<size_t>(2 * kl + ku + 1)) {
        ctx.fail("ab must be at least (2*kl+ku+1) x n");
        return Value(0.0);
      }
      std::vector<long long> piv;
      long long info = gbtrf(ab, static_cast<size_t>(m), static_cast<size_t>(n), kl, ku, piv);
      return makeDict({{"lu", outM(ab)}, {"ipiv", ivec(piv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gbtrs", 5, 9, "ab, kl, ku, b, ipiv, trans, n, ldab, ldb") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab, B;
      long long kl, ku;
      IVec piv;
      bool wv;
      if (!getM(a, 0, ctx, ab) || !getI(a, 1, ctx, kl) || !getI(a, 2, ctx, ku) ||
          !getB(a, 3, ctx, ab.c, B, wv) || !getIdx(a, 4, ctx, piv))
        return Value(0.0);
      if (kl < 0 || ku < 0 || ab.r < static_cast<size_t>(2 * kl + ku + 1) || piv.size() < ab.c) {
        ctx.fail("ab must be (2*kl+ku+1) x n and ipiv must hold n pivots");
        return Value(0.0);
      }
      for (auto p : piv)
        if (p < 0 || p >= static_cast<long long>(ab.c)) {
          ctx.fail("pivots must lie between 0 and n-1");
          return Value(0.0);
        }
      gbtrs(ab, kl, ku, std::vector<long long>(piv.begin(), piv.end()), B, copt(a, 5, 'N'));
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gbsv", 4, 6, "kl, ku, ab, b") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab, B;
      long long kl, ku;
      bool wv;
      if (!getI(a, 0, ctx, kl) || !getI(a, 1, ctx, ku) || !getM(a, 2, ctx, ab) || !getB(a, 3, ctx, ab.c, B, wv))
        return Value(0.0);
      if (kl < 0 || ku < 0 || ab.r != static_cast<size_t>(2 * kl + ku + 1)) {
        ctx.fail("ab must have 2*kl+ku+1 rows");
        return Value(0.0);
      }
      std::vector<long long> piv;
      long long info = gbtrf(ab, ab.c, ab.c, kl, ku, piv);
      if (info == 0)
        gbtrs(ab, kl, ku, piv, B, 'N');
      return makeDict({{"lub", outM(ab)}, {"piv", ivec(piv)}, {"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gbcon", 5, 7, "kl, ku, ab, ipiv, anorm, norm, ldab") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab;
      long long kl, ku;
      IVec piv;
      double anorm;
      if (!getI(a, 0, ctx, kl) || !getI(a, 1, ctx, ku) || !getM(a, 2, ctx, ab) || !getIdx(a, 3, ctx, piv) ||
          !argNumber(a, 4, ctx, anorm))
        return Value(0.0);
      if (kl < 0 || ku < 0 || ab.r < static_cast<size_t>(2 * kl + ku + 1) || piv.size() < ab.c) {
        ctx.fail("ab must be (2*kl+ku+1) x n and ipiv must hold n pivots");
        return Value(0.0);
      }
      for (auto p : piv)
        if (p < 0 || p >= static_cast<long long>(ab.c)) {
          ctx.fail("pivots must lie between 0 and n-1");
          return Value(0.0);
        }
      for (size_t j = 0; j < ab.c; j++)
        if (ab(static_cast<size_t>(kl + ku), j) == T(0))
          return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
      std::vector<long long> p(piv.begin(), piv.end());
      MatT<T> X = inverseBy<T>(ab.c, [&](MatT<T> &B) { gbtrs(ab, kl, ku, p, B, 'N'); });
      return makeDict({{"rcond", Value(rcondOf(anorm, X, nopt(a, 5, '1')))}, {"info", inum(0)}});
    });
  } SP_ENDC

  // ---- tridiagonal ----
  SP_ADD("lapack_gtsv", 4, 8, "dl, d, du, b") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> dl, d, du;
      MatT<T> B;
      bool wv;
      if (!getTri(a, 0, ctx, dl, d, du) || !getB(a, 3, ctx, d.size(), B, wv))
        return Value(0.0);
      const size_t n = d.size();
      long long info = 0;
      for (size_t i = 0; i + 1 < n && info == 0; i++) {
        if (cabs1(d[i]) >= cabs1(dl[i])) {
          if (d[i] == T(0)) {
            info = static_cast<long long>(i) + 1;
            break;
          }
          T f = dl[i] / d[i];
          d[i + 1] -= f * du[i];
          for (size_t c = 0; c < B.c; c++)
            B(i + 1, c) -= f * B(i, c);
          if (i + 2 < n)
            dl[i] = T(0);
        } else {
          T f = d[i] / dl[i];
          d[i] = dl[i];
          T t = d[i + 1];
          d[i + 1] = du[i] - f * t;
          if (i + 2 < n) {
            dl[i] = du[i + 1];
            du[i + 1] = -f * dl[i];
          }
          du[i] = t;
          for (size_t c = 0; c < B.c; c++) {
            T tb = B(i, c);
            B(i, c) = B(i + 1, c);
            B(i + 1, c) = tb - f * B(i + 1, c);
          }
        }
      }
      if (info == 0 && d[n - 1] == T(0))
        info = static_cast<long long>(n);
      if (info == 0)
        for (size_t c = 0; c < B.c; c++) {
          B(n - 1, c) /= d[n - 1];
          if (n > 1)
            B(n - 2, c) = (B(n - 2, c) - du[n - 2] * B(n - 1, c)) / d[n - 2];
          for (size_t i = n >= 2 ? n - 2 : 0; i-- > 0;)
            B(i, c) = (B(i, c) - du[i] * B(i + 1, c) - dl[i] * B(i + 2, c)) / d[i];
        }
      return makeDict({{"du2", outV(dl)}, {"d", outV(d)}, {"du", outV(du)}, {"x", outB(B, wv)},
                       {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gttrf", 3, 6, "dl, d, du") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> dl, d, du, du2;
      if (!getTri(a, 0, ctx, dl, d, du))
        return Value(0.0);
      std::vector<long long> ip;
      long long info = gttrf(dl, d, du, du2, ip);
      return makeDict({{"dl", outV(dl)}, {"d", outV(d)}, {"du", outV(du)}, {"du2", outV(du2)},
                       {"ipiv", ivec(ip)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gttrs", 6, 8, "dl, d, du, du2, ipiv, b, trans") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> dl, d, du, du2;
      IVec ip;
      MatT<T> B;
      bool wv;
      if (!getTri(a, 0, ctx, dl, d, du) || !getV(a, 3, ctx, du2) || !getIdx(a, 4, ctx, ip) ||
          !getB(a, 5, ctx, d.size(), B, wv))
        return Value(0.0);
      const size_t n = d.size();
      if (du2.size() + 2 < n || ip.size() < n) {
        ctx.fail("du2 must hold n-2 values and ipiv n pivots");
        return Value(0.0);
      }
      du2.resize(n > 2 ? n - 2 : 0);
      for (size_t i = 0; i < n; i++)
        if (ip[i] < static_cast<long long>(i) + 1 || ip[i] > std::min<long long>(static_cast<long long>(i) + 2, static_cast<long long>(n))) {
          ctx.fail("ipiv must be the 1-based pivots of lapack_gttrf");
          return Value(0.0);
        }
      gttrs(dl, d, du, du2, std::vector<long long>(ip.begin(), ip.end()), B, copt(a, 6, 'N'));
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gtcon", 6, 7, "dl, d, du, du2, ipiv, anorm, norm") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> dl, d, du, du2;
      IVec ip;
      double anorm;
      if (!getTri(a, 0, ctx, dl, d, du) || !getV(a, 3, ctx, du2) || !getIdx(a, 4, ctx, ip) ||
          !argNumber(a, 5, ctx, anorm))
        return Value(0.0);
      const size_t n = d.size();
      if (du2.size() + 2 < n || ip.size() < n) {
        ctx.fail("du2 must hold n-2 values and ipiv n pivots");
        return Value(0.0);
      }
      du2.resize(n > 2 ? n - 2 : 0);
      for (size_t i = 0; i < n; i++)
        if (ip[i] < static_cast<long long>(i) + 1 || ip[i] > std::min<long long>(static_cast<long long>(i) + 2, static_cast<long long>(n))) {
          ctx.fail("ipiv must be the 1-based pivots of lapack_gttrf");
          return Value(0.0);
        }
      for (const T &e : d)
        if (e == T(0))
          return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
      std::vector<long long> p(ip.begin(), ip.end());
      MatT<T> X = inverseBy<T>(n, [&](MatT<T> &B) { gttrs(dl, d, du, du2, p, B, 'N'); });
      return makeDict({{"rcond", Value(rcondOf(anorm, X, nopt(a, 6, '1')))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gtsvx", 4, 11, "dl, d, du, b, fact, trans, dlf, df, duf, du2, ipiv") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> dl, d, du, dlf, df, duf, du2;
      MatT<T> B;
      bool wv;
      if (!getTri(a, 0, ctx, dl, d, du) || !getB(a, 3, ctx, d.size(), B, wv))
        return Value(0.0);
      const size_t n = d.size();
      const char fact = copt(a, 4, 'N'), trans = copt(a, 5, 'N');
      std::vector<long long> ip;
      long long info = 0;
      if (fact == 'F') {
        IVec q;
        if (!getTri(a, 6, ctx, dlf, df, duf) || !getV(a, 9, ctx, du2) || !getIdx(a, 10, ctx, q))
          return Value(0.0);
        if (df.size() != n || du2.size() + 2 < n || q.size() < n) {
          ctx.fail("the factors do not match the size of d");
          return Value(0.0);
        }
        du2.resize(n > 2 ? n - 2 : 0);
        ip.assign(q.begin(), q.begin() + static_cast<long>(n));
        for (size_t i = 0; i < n; i++)
          if (ip[i] < static_cast<long long>(i) + 1 || ip[i] > std::min<long long>(static_cast<long long>(i) + 2, static_cast<long long>(n))) {
            ctx.fail("ipiv must be the 1-based pivots of lapack_gttrf");
            return Value(0.0);
          }
      } else {
        dlf = dl;
        df = d;
        duf = du;
        info = gttrf(dlf, df, duf, du2, ip);
      }
      MatT<T> X(B.r, B.c);
      double rcond = 0.0;
      Vec ferr(B.c, 0.0), berr(B.c, 0.0);
      if (info == 0) {
        MatT<T> A = tridiag(dl, d, du);
        const double anorm = normOf(A, trans == 'N' ? '1' : 'I');
        MatT<T> Ainv = inverseBy<T>(n, [&](MatT<T> &Y) { gttrs(dlf, df, duf, du2, ip, Y, 'N'); });
        rcond = rcondOf(anorm, Ainv, '1');
        X = B;
        gttrs(dlf, df, duf, du2, ip, X, trans);
        refineErrors(A, Ainv, B, X, trans, ferr, berr);
        if (rcond < lamch('E'))
          info = static_cast<long long>(n) + 1;
      }
      return makeDict({{"dlf", outV(dlf)}, {"df", outV(df)}, {"duf", outV(duf)}, {"du2", outV(du2)},
                       {"ipiv", ivec(ip)}, {"x", outB(X, wv)}, {"rcond", Value(rcond)},
                       {"ferr", toValue(ferr)}, {"berr", toValue(berr)}, {"info", inum(info)}});
    });
  } SP_ENDC

  // ---- triangular ----
  SP_ADD("lapack_trtri", 1, 3, "c, lower, unitdiag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> C;
      if (!getSq(a, 0, ctx, C))
        return Value(0.0);
      const bool lower = iopt(a, 1, 0) != 0, unit = iopt(a, 2, 0) != 0;
      if (!unit)
        for (size_t i = 0; i < C.r; i++)
          if (C(i, i) == T(0))
            return makeDict({{"inv_c", outM(C)}, {"info", inum(static_cast<long long>(i) + 1)}});
      MatT<T> X = MatT<T>::eye(C.r);
      triSolve(C, X, lower, 'N', unit);
      MatT<T> out = C;
      putTri(out, X, lower);
      if (unit)
        for (size_t i = 0; i < C.r; i++)
          out(i, i) = C(i, i);
      return makeDict({{"inv_c", outM(out)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_trtrs", 2, 6, "a, b, lower, trans, unitdiag, lda") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
        return Value(0.0);
      const bool lower = iopt(a, 2, 0) != 0, unit = iopt(a, 4, 0) != 0;
      if (!unit)
        for (size_t i = 0; i < A.r; i++)
          if (A(i, i) == T(0))
            return makeDict({{"x", outB(B, wv)}, {"info", inum(static_cast<long long>(i) + 1)}});
      triSolve(A, B, lower, copt(a, 3, 'N'), unit);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_trcon", 1, 4, "a, norm, uplo, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      const char nm = nopt(a, 1, '1');
      const bool lower = copt(a, 2, 'U') == 'L', unit = copt(a, 3, 'N') == 'U';
      MatT<T> Tr = triOf(A, lower, unit);
      if (hasZeroDiag(Tr, Tr.r))
        return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
      MatT<T> X = MatT<T>::eye(A.r);
      triSolve(A, X, lower, 'N', unit);
      return makeDict({{"rcond", Value(rcondOf(normOf(Tr, nm == 'I' ? 'I' : '1'), X, nm))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_tbtrs", 2, 6, "ab, b, uplo, trans, diag") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> ab, B;
      bool wv;
      if (!getM(a, 0, ctx, ab) || !getB(a, 1, ctx, ab.c, B, wv))
        return Value(0.0);
      const bool lower = copt(a, 2, 'U') == 'L', unit = copt(a, 4, 'N') == 'U';
      const long long kd = static_cast<long long>(ab.r) - 1;
      if (kd < 0) {
        ctx.fail("ab must have at least one row");
        return Value(0.0);
      }
      MatT<T> A = sbToDense(ab, kd, lower);
      if (!unit)
        for (size_t i = 0; i < A.r; i++)
          if (A(i, i) == T(0))
            return makeDict({{"x", outB(B, wv)}, {"info", inum(static_cast<long long>(i) + 1)}});
      triSolve(A, B, lower, copt(a, 3, 'N'), unit);
      return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_lauum", 1, 3, "c, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> C;
      if (!getSq(a, 0, ctx, C))
        return Value(0.0);
      const bool lower = iopt(a, 1, 0) != 0;
      MatT<T> Tr = triOf(C, lower, false);
      for (size_t i = 0; i < Tr.r; i++) // xLAUUM reads the diagonal as real
        Tr(i, i) = T(realOf(Tr(i, i)));
      MatT<T> P = lower ? mul(adjointOf(Tr), Tr) : mul(Tr, adjointOf(Tr));
      MatT<T> out = C;
      putTri(out, P, lower);
      return makeDict({{"a", outM(out)}, {"info", inum(0)}});
    });
  } SP_ENDC

  // ---- machine values and version ----
  SP_ADD("lapack_lamch", 1, 1, "cmach") {
    std::string s;
    if (!argText(a, 0, ctx, s))
      return Value(0.0);
    const char c = s.empty() ? ' ' : static_cast<char>(std::toupper(static_cast<unsigned char>(s[0])));
    if (std::string("ESBPNRMULO").find(c) == std::string::npos) {
      ctx.fail("cmach must be one of E, S, B, P, N, R, M, U, L, O");
      return Value(0.0);
    }
    return Value(lamch(c));
  } SP_END
  SP_ADD("lapack_ilaver", 0, 0, "") {
    (void)a;
    (void)ctx;
    return makeDict({{"major", inum(3)}, {"minor", inum(12)}, {"patch", inum(0)}});
  } SP_END
}

} // namespace scipy
} // namespace nc
