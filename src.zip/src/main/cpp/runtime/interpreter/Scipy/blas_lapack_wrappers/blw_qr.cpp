// Orthogonal factorisations: QR (plain, non-negative diagonal, column pivoted,
// blocked compact-WY, triangular-pentagonal), RQ, LQ (inside gels) and RZ,
// the routines that form or apply their Q, Householder and Givens helpers,
// and the least-squares drivers gels, gelss, gelsd, gelsy and gglse.
//
// Reflector conventions are LAPACK's: H = I - tau v v^H with v(i) = 1.
//   QR:  A = Q R,   Q = H1 H2 ... Hk,      v below the diagonal of column i
//   RQ:  A = R Q,   Q = H1^H H2^H ... Hk^H, v to the left of the diagonal (stored conjugated)
//   RZ:  A = R Z,   Z = H1 H2 ... Hm,      v in the trailing l columns of row i
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

template <class T> MatT<T> householder(const std::vector<T> &v, T tau) {
  const size_t n = v.size();
  MatT<T> H = MatT<T>::eye(n);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++)
      H(i, j) -= tau * v[i] * conjOf(v[j]);
  return H;
}

// xGEQR2 (or xGEQR2P with nonneg = true): R and the reflectors in A.
template <class T> std::vector<T> geqr2(MatT<T> &A, bool nonneg = false) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  std::vector<T> tau(k);
  for (size_t i = 0; i < k; i++) {
    T alpha = A(i, i);
    tau[i] = nonneg ? larfgp(alpha, m > i + 1 ? &A(i + 1, i) : nullptr, m - i - 1, A.c)
                    : larfg(alpha, m > i + 1 ? &A(i + 1, i) : nullptr, m - i - 1, A.c);
    A(i, i) = T(1);
    if (i + 1 < n) {
      std::vector<T> v(m - i);
      for (size_t r = i; r < m; r++)
        v[r - i] = A(r, i);
      applyH(A, v, conjOf(tau[i]), true, i, i + 1);
    }
    A(i, i) = alpha;
  }
  return tau;
}
// Q = H1 ... Hk from xGEQRF reflectors (rows m), first `cols` columns.
template <class T> MatT<T> qOfQr(const MatT<T> &V, const std::vector<T> &tau, size_t m, size_t cols) {
  MatT<T> Q(m, cols);
  for (size_t i = 0; i < std::min(m, cols); i++)
    Q(i, i) = T(1);
  for (size_t i = tau.size(); i-- > 0;) {
    std::vector<T> v(m - i);
    v[0] = T(1);
    for (size_t r = i + 1; r < m; r++)
      v[r - i] = V(r, i);
    applyH(Q, v, tau[i], true, i, 0);
  }
  return Q;
}
// xGERQ2: R in the last columns, reflectors (conjugated) to the left of it.
template <class T> std::vector<T> gerq2(MatT<T> &A) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  std::vector<T> tau(k);
  for (size_t ii = k; ii-- > 0;) {
    const size_t row = m - k + ii, len = n - k + ii; // len = columns 0..len-1 left of alpha
    for (size_t j = 0; j <= len; j++)
      A(row, j) = conjOf(A(row, j));
    T alpha = A(row, len);
    tau[ii] = larfg(alpha, len ? &A(row, 0) : nullptr, len, 1);
    A(row, len) = T(1);
    std::vector<T> v(len + 1);
    for (size_t j = 0; j <= len; j++)
      v[j] = A(row, j);
    MatT<T> Sub(row, len + 1);
    for (size_t r = 0; r < row; r++)
      for (size_t j = 0; j <= len; j++)
        Sub(r, j) = A(r, j);
    applyH(Sub, v, tau[ii], false, 0, 0);
    for (size_t r = 0; r < row; r++)
      for (size_t j = 0; j <= len; j++)
        A(r, j) = Sub(r, j);
    A(row, len) = alpha;
    for (size_t j = 0; j < len; j++)
      A(row, j) = conjOf(A(row, j));
  }
  return tau;
}
// xGELQ2: L and the reflectors (conjugated) right of the diagonal.
template <class T> std::vector<T> gelq2(MatT<T> &A) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  std::vector<T> tau(k);
  for (size_t i = 0; i < k; i++) {
    for (size_t j = i; j < n; j++)
      A(i, j) = conjOf(A(i, j));
    T alpha = A(i, i);
    tau[i] = larfg(alpha, i + 1 < n ? &A(i, i + 1) : nullptr, n - i - 1, 1);
    if (i + 1 < m) {
      A(i, i) = T(1);
      std::vector<T> v(n - i);
      for (size_t j = i; j < n; j++)
        v[j - i] = A(i, j);
      MatT<T> Sub(m - i - 1, n - i);
      for (size_t r = i + 1; r < m; r++)
        for (size_t j = i; j < n; j++)
          Sub(r - i - 1, j - i) = A(r, j);
      applyH(Sub, v, tau[i], false, 0, 0);
      for (size_t r = i + 1; r < m; r++)
        for (size_t j = i; j < n; j++)
          A(r, j) = Sub(r - i - 1, j - i);
    }
    A(i, i) = alpha;
    for (size_t j = i; j < n; j++)
      A(i, j) = conjOf(A(i, j));
  }
  return tau;
}
// Q (n x n) of the LQ factorisation A = L Q.
template <class T> MatT<T> qOfLq(const MatT<T> &A, const std::vector<T> &tau) {
  const size_t n = A.c;
  MatT<T> P = MatT<T>::eye(n); // P = H1 H2 ... Hk, A P = L
  for (size_t i = 0; i < tau.size(); i++) {
    std::vector<T> v(n, T(0));
    v[i] = T(1);
    for (size_t j = i + 1; j < n; j++)
      v[j] = conjOf(A(i, j));
    P = mul(P, householder(v, tau[i]));
  }
  return adjointOf(P);
}
// Q (n x n) of the RQ factorisation A = R Q, from xGERQF reflectors.
template <class T> MatT<T> qOfRq(const MatT<T> &A, const std::vector<T> &tau) {
  const size_t m = A.r, n = A.c, k = tau.size();
  MatT<T> Q = MatT<T>::eye(n);
  for (size_t ii = 0; ii < k; ii++) {
    const size_t row = m - k + ii, len = n - k + ii;
    std::vector<T> v(n, T(0));
    for (size_t j = 0; j < len; j++)
      v[j] = conjOf(A(row, j));
    v[len] = T(1);
    Q = mul(Q, adjointOf(householder(v, tau[ii])));
  }
  return Q;
}

// The upper triangular T of a compact WY block reflector (xLARFT, forward,
// columnwise) for the columns V(:, c0 .. c0+ib-1) and their tau.
template <class T> MatT<T> larft(const MatT<T> &V, const std::vector<T> &tau, size_t c0, size_t ib) {
  MatT<T> Tm(ib, ib);
  for (size_t i = 0; i < ib; i++) {
    Tm(i, i) = tau[c0 + i];
    for (size_t j = 0; j < i; j++) {
      T s(0);
      for (size_t r = 0; r < V.r; r++)
        s += conjOf(V(r, c0 + j)) * V(r, c0 + i);
      Tm(j, i) = -tau[c0 + i] * s;
    }
    std::vector<T> w(i);
    for (size_t j = 0; j < i; j++) {
      T s(0);
      for (size_t q = j; q < i; q++)
        s += Tm(j, q) * Tm(q, i);
      w[j] = s;
    }
    for (size_t j = 0; j < i; j++)
      Tm(j, i) = w[j];
  }
  return Tm;
}

// xLARTG (LAPACK 3.10 and later).
template <class T> void lartg(T f, T g, double &c, T &s, T &r) {
  const double safmin = lamch('S');
  if constexpr (isCx<T>()) {
    if (g == T(0)) {
      c = 1.0;
      s = T(0);
      r = f;
    } else if (f == T(0)) {
      c = 0.0;
      const double d = std::abs(g);
      s = std::conj(g) / d;
      r = d;
    } else {
      const double f2 = std::norm(f), g2 = std::norm(g), h2 = f2 + g2;
      if (f2 >= h2 * safmin) {
        c = std::sqrt(f2 / h2);
        r = f / c;
        s = std::conj(g) * (f / std::sqrt(f2 * h2));
      } else {
        const double d = std::sqrt(f2 * h2);
        c = f2 / d;
        r = c >= safmin ? f / c : f * (h2 / d);
        s = std::conj(g) * (f / d);
      }
    }
  } else {
    if (g == 0.0) {
      c = 1.0;
      s = 0.0;
      r = f;
    } else if (f == 0.0) {
      c = 0.0;
      s = g > 0 ? 1.0 : -1.0;
      r = std::fabs(g);
    } else {
      const double d = std::sqrt(f * f + g * g);
      c = std::fabs(f) / d;
      r = f >= 0 ? d : -d;
      s = g / r;
    }
  }
}

// Least squares through the SVD: x (n x nrhs), singular values, rank.
template <class T>
MatT<T> svdSolve(const MatT<T> &A, const MatT<T> &B, double cond, Vec &s, long long &rank) {
  MatT<T> U, V;
  la::svdThin(A, U, s, V);
  s.resize(std::min(A.r, A.c));
  const double rc = cond < 0 ? lamch('E') : cond;
  const double cut = s.empty() ? 0.0 : rc * s[0];
  MatT<T> X(A.c, B.c);
  rank = 0;
  for (size_t k = 0; k < s.size(); k++) {
    if (!(s[k] > cut))
      continue;
    rank++;
    for (size_t c = 0; c < B.c; c++) {
      T d(0);
      for (size_t i = 0; i < A.r; i++)
        d += conjOf(U(i, k)) * B(i, c);
      d /= T(s[k]);
      for (size_t i = 0; i < A.c; i++)
        X(i, c) += d * V(i, k);
    }
  }
  return X;
}
template <class T> MatT<T> topRows(const MatT<T> &B, size_t r) {
  MatT<T> X(r, B.c);
  for (size_t i = 0; i < r && i < B.r; i++)
    for (size_t c = 0; c < B.c; c++)
      X(i, c) = B(i, c);
  return X;
}
template <class T> void putTop(MatT<T> &B, const MatT<T> &X) {
  for (size_t i = 0; i < X.r && i < B.r; i++)
    for (size_t c = 0; c < B.c; c++)
      B(i, c) = X(i, c);
}

// Column pivoted QR (xGEQP3 through xLAQP2): jpvt 1-based; nonzero input
// entries mark columns moved to the front first.
template <class T> std::vector<T> geqp3(MatT<T> &A, std::vector<long long> &jpvt) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  if (jpvt.size() != n)
    jpvt.assign(n, 0);
  size_t nfxd = 0;
  for (size_t j = 0; j < n; j++) {
    if (jpvt[j] != 0) {
      if (j != nfxd) {
        for (size_t r = 0; r < m; r++)
          std::swap(A(r, j), A(r, nfxd));
        jpvt[j] = jpvt[nfxd];
        jpvt[nfxd] = static_cast<long long>(j) + 1;
      } else {
        jpvt[j] = static_cast<long long>(j) + 1;
      }
      nfxd++;
    } else {
      jpvt[j] = static_cast<long long>(j) + 1;
    }
  }
  std::vector<T> tau(k);
  // Fixed columns: plain QR first.
  if (nfxd > 0) {
    const size_t na = std::min(m, nfxd);
    MatT<T> F(m, na);
    for (size_t r = 0; r < m; r++)
      for (size_t c = 0; c < na; c++)
        F(r, c) = A(r, c);
    std::vector<T> t = geqr2(F);
    for (size_t r = 0; r < m; r++)
      for (size_t c = 0; c < na; c++)
        A(r, c) = F(r, c);
    for (size_t i = 0; i < na; i++) {
      tau[i] = t[i];
      std::vector<T> v(m - i);
      v[0] = T(1);
      for (size_t r = i + 1; r < m; r++)
        v[r - i] = A(r, i);
      applyH(A, v, conjOf(t[i]), true, i, na);
    }
  }
  const size_t offset = std::min(m, nfxd);
  Vec vn1(n, 0.0), vn2(n, 0.0);
  for (size_t j = offset; j < n; j++) {
    double s = 0.0;
    for (size_t r = offset; r < m; r++)
      s += absOf(A(r, j)) * absOf(A(r, j));
    vn1[j] = vn2[j] = std::sqrt(s);
  }
  const double tol3z = std::sqrt(lamch('E'));
  for (size_t i = offset; i < k; i++) {
    size_t pvt = i;
    for (size_t j = i + 1; j < n; j++)
      if (vn1[j] > vn1[pvt])
        pvt = j;
    if (pvt != i) {
      for (size_t r = 0; r < m; r++)
        std::swap(A(r, pvt), A(r, i));
      std::swap(jpvt[pvt], jpvt[i]);
      vn1[pvt] = vn1[i];
      vn2[pvt] = vn2[i];
    }
    T alpha = A(i, i);
    tau[i] = larfg(alpha, i + 1 < m ? &A(i + 1, i) : nullptr, m - i - 1, A.c);
    A(i, i) = T(1);
    if (i + 1 < n) {
      std::vector<T> v(m - i);
      for (size_t r = i; r < m; r++)
        v[r - i] = A(r, i);
      applyH(A, v, conjOf(tau[i]), true, i, i + 1);
    }
    A(i, i) = alpha;
    for (size_t j = i + 1; j < n; j++) {
      if (vn1[j] == 0.0)
        continue;
      double t = absOf(A(i, j)) / vn1[j];
      t = std::max(0.0, 1.0 - t * t);
      const double t2 = t * (vn1[j] / vn2[j]) * (vn1[j] / vn2[j]);
      if (t2 <= tol3z) {
        double s = 0.0;
        for (size_t r = i + 1; r < m; r++)
          s += absOf(A(r, j)) * absOf(A(r, j));
        vn1[j] = vn2[j] = std::sqrt(s);
      } else {
        vn1[j] *= std::sqrt(t);
      }
    }
  }
  return tau;
}

// Triangular-pentagonal reflectors: column i acts on A(i, :) and the first p_i
// rows of B, p_i = m - l + min(l, i + 1). Rows of B outside are not referenced.
inline size_t pentRows(size_t m, size_t l, size_t i) { return m - l + std::min(l, i + 1); }

template <class T> Value tpqrt(long long l, long long nb, MatT<T> A, MatT<T> B, CallContext &ctx) {
  const size_t n = A.c, m = B.r;
  if (A.r != n || B.c != n || l < 0 || static_cast<size_t>(l) > std::min(m, n) || nb < 1 ||
      (n > 0 && static_cast<size_t>(nb) > n)) {
    ctx.fail("a must be n x n, b m x n, 0 <= l <= min(m, n) and 1 <= nb <= n");
    return Value(0.0);
  }
  std::vector<T> tau(n);
  for (size_t i = 0; i < n; i++) {
    const size_t p = pentRows(m, static_cast<size_t>(l), i);
    T alpha = A(i, i);
    std::vector<T> x(p);
    for (size_t r = 0; r < p; r++)
      x[r] = B(r, i);
    tau[i] = larfg(alpha, p ? x.data() : nullptr, p, 1);
    A(i, i) = alpha;
    for (size_t r = 0; r < p; r++)
      B(r, i) = x[r];
    for (size_t j = i + 1; j < n; j++) {
      T w = A(i, j);
      for (size_t r = 0; r < p; r++)
        w += conjOf(B(r, i)) * B(r, j);
      w *= conjOf(tau[i]);
      A(i, j) -= w;
      for (size_t r = 0; r < p; r++)
        B(r, j) -= B(r, i) * w;
    }
  }
  // T in blocks of nb columns, from the full reflector vectors [e_i; B(:, i)].
  MatT<T> V(n + m, n);
  for (size_t i = 0; i < n; i++) {
    V(i, i) = T(1);
    const size_t p = pentRows(m, static_cast<size_t>(l), i);
    for (size_t r = 0; r < p; r++)
      V(n + r, i) = B(r, i);
  }
  MatT<T> Tm(static_cast<size_t>(nb), n);
  for (size_t c0 = 0; c0 < n; c0 += static_cast<size_t>(nb)) {
    const size_t ib = std::min<size_t>(static_cast<size_t>(nb), n - c0);
    MatT<T> Tb = larft(V, tau, c0, ib);
    for (size_t i = 0; i < ib; i++)
      for (size_t j = 0; j < ib; j++)
        Tm(i, c0 + j) = Tb(i, j);
  }
  return makeDict({{"a", outM(A)}, {"b", outM(B)}, {"t", outM(Tm)}, {"info", inum(0)}});
}

} // namespace

void registerBlwQr(Registry &reg) {
  // ---- QR and its variants ----
  static const auto geqrfBody = [](const Args &a, CallContext &ctx, bool nonneg) -> Value {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      std::vector<T> tau = geqr2(A, nonneg);
      if (nonneg)
        return makeDict({{"qr", outM(A)}, {"tau", outV(tau)}, {"info", inum(0)}});
      const size_t lw = workLen(iopt(a, 1, std::max<long long>(3 * static_cast<long long>(A.c), 1)));
      std::vector<T> work(lw, T(0));
      work[0] = T(static_cast<double>(std::max<size_t>(1, A.c * 32)));
      return makeDict({{"qr", outM(A)}, {"tau", outV(tau)}, {"work", outV(work)}, {"info", inum(0)}});
    });
  };
  SP_ADD("lapack_geqrf", 1, 3, "a, lwork") {
    return geqrfBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_geqrfp", 1, 3, "a, lwork") {
    return geqrfBody(a, ctx, true);
  } SP_ENDC
  SP_ADD("lapack_geqp3", 1, 3, "a, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      std::vector<long long> jpvt(A.c, 0);
      std::vector<T> tau = geqp3(A, jpvt);
      const size_t lw = workLen(iopt(a, 1, 3 * (static_cast<long long>(A.c) + 1)));
      std::vector<T> work(lw, T(0));
      work[0] = T(static_cast<double>(2 * A.c + (A.c + 1) * 32));
      return makeDict({{"qr", outM(A)}, {"jpvt", ivec(jpvt)}, {"tau", outV(tau)}, {"work", outV(work)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_geqrt", 2, 3, "nb, a") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long nb;
      MatT<T> A;
      if (!getI(a, 0, ctx, nb) || !getM(a, 1, ctx, A))
        return Value(0.0);
      const size_t k = std::min(A.r, A.c);
      if (nb < 1 || (k > 0 && static_cast<size_t>(nb) > k)) {
        ctx.fail("nb must be between 1 and min(m, n)");
        return Value(0.0);
      }
      std::vector<T> tau = geqr2(A);
      MatT<T> V(A.r, k);
      for (size_t i = 0; i < k; i++) {
        V(i, i) = T(1);
        for (size_t r = i + 1; r < A.r; r++)
          V(r, i) = A(r, i);
      }
      MatT<T> Tm(static_cast<size_t>(nb), k);
      for (size_t c0 = 0; c0 < k; c0 += static_cast<size_t>(nb)) {
        const size_t ib = std::min<size_t>(static_cast<size_t>(nb), k - c0);
        MatT<T> Tb = larft(V, tau, c0, ib);
        for (size_t i = 0; i < ib; i++)
          for (size_t j = 0; j < ib; j++)
            Tm(i, c0 + j) = Tb(i, j);
      }
      return makeDict({{"a", outM(A)}, {"t", outM(Tm)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gemqrt", 3, 6, "v, t, c, side, trans") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> V, Tm, C;
      if (!getM(a, 0, ctx, V) || !getM(a, 1, ctx, Tm) || !getM(a, 2, ctx, C))
        return Value(0.0);
      const bool left = copt(a, 3, 'L') == 'L';
      const char t = copt(a, 4, 'N');
      const size_t k = V.c, nq = left ? C.r : C.c, nb = Tm.r;
      if (V.r != nq || Tm.c != k || nb < 1 || k > nq) {
        ctx.fail("v must be " + std::to_string(nq) + " x k and t nb x k");
        return Value(0.0);
      }
      std::vector<T> tau(k);
      for (size_t i = 0; i < k; i++)
        tau[i] = Tm(i % nb, i);
      MatT<T> Q = qOfQr(V, tau, nq, nq);
      MatT<T> Op = t == 'N' ? Q : adjointOf(Q);
      return makeDict({{"c", outM(left ? mul(Op, C) : mul(C, Op))}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gerqf", 1, 3, "a, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      std::vector<T> tau = gerq2(A);
      const size_t lw = workLen(iopt(a, 1, 3 * static_cast<long long>(A.r)));
      std::vector<T> work(lw, T(0));
      work[0] = T(static_cast<double>(std::max<size_t>(1, A.r * 32)));
      return makeDict({{"qr", outM(A)}, {"tau", outV(tau)}, {"work", outV(work)}, {"info", inum(0)}});
    });
  } SP_ENDC
  // Q from QR reflectors: orgqr (real) and ungqr (complex) share the body.
  static const auto orgqrBody = [](const Args &a, CallContext &ctx, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      std::vector<T> tau;
      if (!getM(a, 0, ctx, A) || !getV(a, 1, ctx, tau))
        return Value(0.0);
      if (A.r < A.c || tau.size() > A.c) {
        ctx.fail("a must have m >= n and tau at most n values");
        return Value(0.0);
      }
      MatT<T> Q = qOfQr(A, tau, A.r, A.c);
      const size_t lw = workLen(iopt(a, 2, 3 * static_cast<long long>(A.c)));
      std::vector<T> work(lw, T(0));
      work[0] = T(static_cast<double>(std::max<size_t>(1, A.c * 32)));
      return makeDict({{"q", outM(Q)}, {"work", outV(work)}, {"info", inum(0)}});
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_orgqr", 2, 4, "a, tau, lwork") {
    return orgqrBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_ungqr", 2, 4, "a, tau, lwork") {
    return orgqrBody(a, ctx, true);
  } SP_ENDC
  // Q (last rows) from RQ reflectors, ported from xUNGR2.
  static const auto orgrqBody = [](const Args &a, CallContext &ctx, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      std::vector<T> tau;
      if (!getM(a, 0, ctx, A) || !getV(a, 1, ctx, tau))
        return Value(0.0);
      const size_t m = A.r, n = A.c, k = tau.size();
      if (m > n || k > m) {
        ctx.fail("a must have m <= n and tau at most m values");
        return Value(0.0);
      }
      if (k < m) {
        for (size_t j = 0; j < n; j++) {
          for (size_t l = 0; l < m - k; l++)
            A(l, j) = T(0);
          if (j + m >= n + 0 && j >= n - m && j < n - k)
            A(m - n + j, j) = T(1);
        }
      }
      for (size_t i = 0; i < k; i++) {
        const size_t ii = m - k + i, len = n - m + ii; // pivot column
        for (size_t j = 0; j < len; j++)
          A(ii, j) = conjOf(A(ii, j));
        A(ii, len) = T(1);
        std::vector<T> v(len + 1);
        for (size_t j = 0; j <= len; j++)
          v[j] = A(ii, j);
        MatT<T> Sub(ii, len + 1);
        for (size_t r = 0; r < ii; r++)
          for (size_t j = 0; j <= len; j++)
            Sub(r, j) = A(r, j);
        applyH(Sub, v, conjOf(tau[i]), false, 0, 0);
        for (size_t r = 0; r < ii; r++)
          for (size_t j = 0; j <= len; j++)
            A(r, j) = Sub(r, j);
        for (size_t j = 0; j < len; j++)
          A(ii, j) *= -tau[i];
        for (size_t j = 0; j < len; j++)
          A(ii, j) = conjOf(A(ii, j));
        A(ii, len) = T(1) - conjOf(tau[i]);
        for (size_t j = len + 1; j < n; j++)
          A(ii, j) = T(0);
      }
      const size_t lw = workLen(iopt(a, 2, 3 * static_cast<long long>(m)));
      std::vector<T> work(lw, T(0));
      work[0] = T(static_cast<double>(std::max<size_t>(1, m * 32)));
      return makeDict({{"q", outM(A)}, {"work", outV(work)}, {"info", inum(0)}});
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_orgrq", 2, 4, "a, tau, lwork") {
    return orgrqBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_ungrq", 2, 4, "a, tau, lwork") {
    return orgrqBody(a, ctx, true);
  } SP_ENDC
  // C := op(Q) C or C op(Q), Q from QR reflectors (ormqr / unmqr).
  static const auto ormqrBody = [](const Args &a, CallContext &ctx, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, C;
      std::vector<T> tau;
      if (!getM(a, 2, ctx, A) || !getV(a, 3, ctx, tau) || !getM(a, 4, ctx, C))
        return Value(0.0);
      const bool left = copt(a, 0, 'L') == 'L';
      const char t = copt(a, 1, 'N');
      const size_t nq = left ? C.r : C.c, k = tau.size();
      if (A.r != nq || k > A.c || k > nq) {
        ctx.fail("a must have as many rows as the side of c it multiplies");
        return Value(0.0);
      }
      MatT<T> Q = qOfQr(A, tau, nq, nq);
      MatT<T> Op = t == 'N' ? Q : adjointOf(Q);
      const size_t lw = workLen(iopt(a, 5, 1));
      std::vector<T> work(lw, T(0));
      work[0] = T(static_cast<double>(std::max<size_t>(1, (left ? C.c : C.r) * 32)));
      return makeDict({{"cq", outM(left ? mul(Op, C) : mul(C, Op))}, {"work", outV(work)}, {"info", inum(0)}});
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_ormqr", 6, 7, "side, trans, a, tau, c, lwork") {
    return ormqrBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_unmqr", 6, 7, "side, trans, a, tau, c, lwork") {
    return ormqrBody(a, ctx, true);
  } SP_ENDC

  // ---- RZ ----
  SP_ADD("lapack_tzrzf", 1, 3, "a, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      const size_t m = A.r, n = A.c;
      if (m > n) {
        ctx.fail("a must have m <= n");
        return Value(0.0);
      }
      std::vector<T> tau(m, T(0));
      const size_t l = n - m;
      if (l > 0) {
        for (size_t i = m; i-- > 0;) {
          for (size_t j = n - l; j < n; j++)
            A(i, j) = conjOf(A(i, j));
          T alpha = conjOf(A(i, i));
          T tl = larfg(alpha, &A(i, n - l), l, 1);
          tau[i] = conjOf(tl);
          // C := C (I - tl w w^H), w = [1 at column i; 0; A(i, n-l..n-1)], rows 0..i-1.
          for (size_t r = 0; r < i; r++) {
            T w = A(r, i);
            for (size_t j = 0; j < l; j++)
              w += A(r, n - l + j) * A(i, n - l + j);
            A(r, i) -= tl * w;
            for (size_t j = 0; j < l; j++)
              A(r, n - l + j) -= tl * w * conjOf(A(i, n - l + j));
          }
          A(i, i) = conjOf(alpha);
        }
      }
      return makeDict({{"rz", outM(A)}, {"tau", outV(tau)}, {"info", inum(0)}});
    });
  } SP_ENDC
  static const auto ormrzBody = [](const Args &a, CallContext &ctx, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, C;
      std::vector<T> tau;
      if (!getM(a, 0, ctx, A) || !getV(a, 1, ctx, tau) || !getM(a, 2, ctx, C))
        return Value(0.0);
      const bool left = copt(a, 3, 'L') == 'L';
      const char t = copt(a, 4, 'N');
      const size_t k = A.r, nt = A.c, nq = left ? C.r : C.c;
      if (tau.size() < k || nt != nq || k > nq) {
        ctx.fail("a must be k x n with n the side of c it multiplies, and tau k values");
        return Value(0.0);
      }
      const size_t l = nq - k;
      MatT<T> Zm = MatT<T>::eye(nq);
      for (size_t i = 0; i < k; i++) {
        std::vector<T> w(nq, T(0));
        w[i] = T(1);
        for (size_t j = 0; j < l; j++)
          w[nq - l + j] = A(i, nt - l + j);
        Zm = mul(Zm, householder(w, tau[i]));
      }
      MatT<T> Op = t == 'N' ? Zm : adjointOf(Zm);
      return makeDict({{"cq", outM(left ? mul(Op, C) : mul(C, Op))}, {"info", inum(0)}});
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_ormrz", 3, 7, "a, tau, c, side, trans, lwork") {
    return ormrzBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_unmrz", 3, 7, "a, tau, c, side, trans, lwork") {
    return ormrzBody(a, ctx, true);
  } SP_ENDC

  // ---- triangular-pentagonal ----
  SP_ADD("lapack_tpqrt", 4, 6, "l, nb, a, b") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long l, nb;
      MatT<T> A, B;
      if (!getI(a, 0, ctx, l) || !getI(a, 1, ctx, nb) || !getM(a, 2, ctx, A) || !getM(a, 3, ctx, B))
        return Value(0.0);
      return tpqrt(l, nb, A, B, ctx);
    });
  } SP_ENDC
  SP_ADD("lapack_tpmqrt", 5, 9, "l, v, t, a, b, side, trans") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long l;
      MatT<T> V, Tm, A, B;
      if (!getI(a, 0, ctx, l) || !getM(a, 1, ctx, V) || !getM(a, 2, ctx, Tm) || !getM(a, 3, ctx, A) ||
          !getM(a, 4, ctx, B))
        return Value(0.0);
      const bool left = copt(a, 5, 'L') == 'L';
      const char t = copt(a, 6, 'N');
      const size_t k = V.c, nb = Tm.r, mv = V.r; // V is m x k (left) or n x k (right)
      if (Tm.c != k || nb < 1 || l < 0 || static_cast<size_t>(l) > std::min(mv, k) ||
          (left && (A.r != k || B.r != mv || A.c != B.c)) || (!left && (A.c != k || B.c != mv || A.r != B.r))) {
        ctx.fail("the shapes of v, t, a and b do not match");
        return Value(0.0);
      }
      const size_t N = k + mv;
      MatT<T> Q = MatT<T>::eye(N);
      for (size_t i = 0; i < k; i++) {
        std::vector<T> w(N, T(0));
        w[i] = T(1);
        const size_t p = pentRows(mv, static_cast<size_t>(l), i);
        for (size_t r = 0; r < p; r++)
          w[k + r] = V(r, i);
        Q = mul(Q, householder(w, Tm(i % nb, i)));
      }
      MatT<T> Op = t == 'N' ? Q : adjointOf(Q);
      if (left) {
        MatT<T> S(N, A.c);
        for (size_t c = 0; c < A.c; c++) {
          for (size_t r = 0; r < k; r++)
            S(r, c) = A(r, c);
          for (size_t r = 0; r < mv; r++)
            S(k + r, c) = B(r, c);
        }
        S = mul(Op, S);
        for (size_t c = 0; c < A.c; c++) {
          for (size_t r = 0; r < k; r++)
            A(r, c) = S(r, c);
          for (size_t r = 0; r < mv; r++)
            B(r, c) = S(k + r, c);
        }
      } else {
        MatT<T> S(A.r, N);
        for (size_t r = 0; r < A.r; r++) {
          for (size_t c = 0; c < k; c++)
            S(r, c) = A(r, c);
          for (size_t c = 0; c < mv; c++)
            S(r, k + c) = B(r, c);
        }
        S = mul(S, Op);
        for (size_t r = 0; r < A.r; r++) {
          for (size_t c = 0; c < k; c++)
            A(r, c) = S(r, c);
          for (size_t c = 0; c < mv; c++)
            B(r, c) = S(r, k + c);
        }
      }
      return makeDict({{"a", outM(A)}, {"b", outM(B)}, {"info", inum(0)}});
    });
  } SP_ENDC

  // ---- reflectors and rotations ----
  SP_ADD("lapack_larf", 4, 6, "v, tau, c, work, side, incv") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> v;
      T tau;
      MatT<T> C;
      if (!getV(a, 0, ctx, v) || !getScal(a, 1, ctx, tau) || !getM(a, 2, ctx, C))
        return Value(0.0);
      const bool left = copt(a, 4, 'L') == 'L';
      const long long inc = iopt(a, 5, 1);
      const long long len = static_cast<long long>(left ? C.r : C.c);
      if (!strideOk(ctx, v.size(), len, 0, inc, "v"))
        return Value(0.0);
      applyH(C, gather(v, len, 0, inc), tau, left, 0, 0);
      return outM(C);
    });
  } SP_ENDC
  SP_ADD("lapack_larfg", 3, 5, "n, alpha, x, incx") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      long long n;
      T alpha;
      std::vector<T> x;
      if (!getI(a, 0, ctx, n) || !getScal(a, 1, ctx, alpha) || !getV(a, 2, ctx, x))
        return Value(0.0);
      const long long inc = iopt(a, 3, 1);
      if (n < 1 || inc < 1 || !strideOk(ctx, x.size(), n - 1, 0, inc, "x"))
        return n < 1 ? (ctx.fail("n must be at least 1"), Value(0.0)) : Value(0.0);
      T tau = larfg(alpha, x.data(), static_cast<size_t>(n - 1), static_cast<size_t>(inc));
      return makeDict({{"alpha", num(alpha)}, {"x", outV(x)}, {"tau", num(tau)}});
    });
  } SP_ENDC
  SP_ADD("lapack_lartg", 2, 2, "f, g") {
    if (!isNumberArg(a, 0) || !isNumberArg(a, 1)) {
      ctx.fail("f and g must be numbers");
      return Value(0.0);
    }
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      double c;
      T s, r;
      lartg(scal<T>(a, 0, T(0)), scal<T>(a, 1, T(0)), c, s, r);
      return makeDict({{"cs", Value(c)}, {"sn", num(s)}, {"r", num(r)}});
    });
  } SP_ENDC
  SP_ADD("lapack_rot", 4, 9, "x, y, c, s, n, offx, incx, offy, incy") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      std::vector<T> x, y;
      double c;
      if (!getV(a, 0, ctx, x) || !getV(a, 1, ctx, y) || !argNumber(a, 2, ctx, c) || !isNumberArg(a, 3)) {
        if (ctx.ok())
          ctx.fail("s must be a number");
        return Value(0.0);
      }
      const T s = scal<T>(a, 3, T(0));
      const long long offx = iopt(a, 5, 0), incx = iopt(a, 6, 1), offy = iopt(a, 7, 0), incy = iopt(a, 8, 1);
      const long long dn = defaultN1(x.size(), offx, incx);
      const long long n = isOmitted(a, 4) ? dn : iopt(a, 4, dn);
      if (!strideOk(ctx, x.size(), n, offx, incx, "x") || !strideOk(ctx, y.size(), n, offy, incy, "y"))
        return Value(0.0);
      std::vector<T> xs = gather(x, n, offx, incx), ys = gather(y, n, offy, incy);
      for (size_t i = 0; i < xs.size(); i++) {
        const T xi = xs[i], yi = ys[i];
        xs[i] = T(c) * xi + s * yi;
        ys[i] = T(c) * yi - conjOf(s) * xi;
      }
      scatter(x, xs, offx, incx);
      scatter(y, ys, offy, incy);
      return makeDict({{"x", outV(x)}, {"y", outV(y)}});
    });
  } SP_ENDC

  // ---- least squares ----
  SP_ADD("lapack_gels", 2, 6, "a, b, trans, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      const size_t m = A.r, n = A.c, mn = std::max(m, n);
      if (!getB(a, 1, ctx, mn, B, wv))
        return Value(0.0);
      const bool tr = copt(a, 2, 'N') != 'N';
      long long info = 0;
      if (m >= n) {
        std::vector<T> tau = geqr2(A);
        MatT<T> Q = qOfQr(A, tau, m, m);
        for (size_t i = 0; i < std::min(m, n); i++)
          if (A(i, i) == T(0))
            info = static_cast<long long>(i) + 1;
        if (info == 0) {
          MatT<T> R = topRows(triOf(A, false, false), n);
          if (!tr) {
            MatT<T> Y = mul(adjointOf(Q), topRows(B, m));
            MatT<T> Top = topRows(Y, n);
            triSolve(R, Top, false, 'N', false);
            putTop(Y, Top);
            putTop(B, Y);
          } else {
            MatT<T> Top = topRows(B, n);
            triSolve(R, Top, false, 'C', false);
            MatT<T> Y(m, B.c);
            putTop(Y, Top);
            putTop(B, mul(Q, Y));
          }
        }
      } else {
        std::vector<T> tau = gelq2(A);
        MatT<T> Q = qOfLq(A, tau);
        for (size_t i = 0; i < m; i++)
          if (A(i, i) == T(0))
            info = static_cast<long long>(i) + 1;
        if (info == 0) {
          MatT<T> Lm(m, m);
          for (size_t i = 0; i < m; i++)
            for (size_t j = 0; j <= i; j++)
              Lm(i, j) = A(i, j);
          if (!tr) {
            MatT<T> Top = topRows(B, m);
            triSolve(Lm, Top, true, 'N', false);
            MatT<T> Y(n, B.c);
            putTop(Y, Top);
            putTop(B, mul(adjointOf(Q), Y));
          } else {
            MatT<T> Y = mul(Q, topRows(B, n));
            MatT<T> Top = topRows(Y, m);
            triSolve(Lm, Top, true, 'C', false);
            putTop(Y, Top);
            putTop(B, Y);
          }
        }
      }
      return makeDict({{"lqr", outM(A)}, {"x", outB(B, wv)}, {"info", inum(info)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gelss", 2, 6, "a, b, cond, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getM(a, 0, ctx, A) || !getB(a, 1, ctx, std::max(A.r, A.c), B, wv))
        return Value(0.0);
      const double cond = given(a, 2) && isPlainNumber(a[2]) ? a[2].number : -1.0;
      Vec s;
      long long rank;
      MatT<T> X = svdSolve(A, topRows(B, A.r), cond, s, rank);
      putTop(B, X);
      MatT<T> U, V;
      Vec s2;
      la::svdThin(A, U, s2, V);
      MatT<T> Vt = adjointOf(V), Vo = A;
      for (size_t i = 0; i < std::min(Vt.r, A.r); i++)
        for (size_t j = 0; j < A.c; j++)
          Vo(i, j) = Vt(i, j);
      const size_t mn = std::min(A.r, A.c), mx = std::max(A.r, A.c);
      const size_t lw = workLen(iopt(a, 3, static_cast<long long>(std::max<size_t>(3 * mn + std::max(2 * mn, std::max(mx, B.c)), 1))));
      std::vector<T> work(lw, T(0));
      return makeDict({{"v", outM(Vo)}, {"x", outB(B, wv)}, {"s", toValue(s)}, {"rank", inum(rank)},
                       {"work", outV(work)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gelsd", 3, 8, "a, b, lwork, size_rwork, size_iwork, cond") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      if (!getM(a, 0, ctx, A) || !getB(a, 1, ctx, std::max(A.r, A.c), B, wv))
        return Value(0.0);
      const size_t ci = isCx<T>() ? 5 : 4; // the complex routine has size_rwork before size_iwork
      const double cond = given(a, ci) && isPlainNumber(a[ci]) ? a[ci].number : -1.0;
      Vec s;
      long long rank;
      putTop(B, svdSolve(A, topRows(B, A.r), cond, s, rank));
      return makeDict({{"x", outB(B, wv)}, {"s", toValue(s)}, {"rank", inum(rank)}, {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gelsy", 5, 7, "a, b, jptv, cond, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      bool wv;
      IVec jp;
      double cond;
      if (!getM(a, 0, ctx, A) || !getB(a, 1, ctx, std::max(A.r, A.c), B, wv) || !getIdx(a, 2, ctx, jp) ||
          !argNumber(a, 3, ctx, cond))
        return Value(0.0);
      const size_t m = A.r, n = A.c, mn = std::min(m, n);
      if (jp.size() != n) {
        ctx.fail("jptv must hold n values");
        return Value(0.0);
      }
      std::vector<long long> jpvt(jp.begin(), jp.end());
      MatT<T> F = A;
      std::vector<T> tau = geqp3(F, jpvt);
      // Rank: the largest r with smin(R11) > cond * smax(R11).
      size_t rank = 0;
      if (mn > 0 && F(0, 0) != T(0)) {
        rank = 1;
        for (size_t r = 2; r <= mn; r++) {
          MatT<T> R11(r, r), U, V;
          for (size_t i = 0; i < r; i++)
            for (size_t j = i; j < r; j++)
              R11(i, j) = F(i, j);
          Vec sv;
          la::svdThin(R11, U, sv, V);
          if (sv.back() > cond * sv.front())
            rank = r;
          else
            break;
        }
      }
      // x = P [R11 R12]^+ (Q^H b)(1:rank)
      MatT<T> Q = qOfQr(F, tau, m, m);
      MatT<T> Y = mul(adjointOf(Q), topRows(B, m));
      MatT<T> Rr(rank, n);
      for (size_t i = 0; i < rank; i++)
        for (size_t j = i; j < n; j++)
          Rr(i, j) = F(i, j);
      Vec sv;
      long long rk;
      MatT<T> Xp = rank ? svdSolve(Rr, topRows(Y, rank), -1.0, sv, rk) : MatT<T>(n, B.c);
      MatT<T> X(n, B.c);
      for (size_t j = 0; j < n; j++)
        for (size_t c = 0; c < B.c; c++)
          X(static_cast<size_t>(jpvt[j] - 1), c) = Xp(j, c);
      putTop(B, X);
      return makeDict({{"v", outM(F)}, {"x", outB(B, wv)}, {"j", ivec(jpvt)}, {"rank", inum(static_cast<long long>(rank))},
                       {"info", inum(0)}});
    });
  } SP_ENDC
  SP_ADD("lapack_gglse", 4, 9, "a, b, c, d, lwork") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A, B;
      std::vector<T> c, d;
      if (!getM(a, 0, ctx, A) || !getM(a, 1, ctx, B) || !getV(a, 2, ctx, c) || !getV(a, 3, ctx, d))
        return Value(0.0);
      const size_t m = A.r, n = A.c, p = B.r;
      if (B.c != n || c.size() != m || d.size() != p || p > n || n > m + p) {
        ctx.fail("need a (m x n), b (p x n), c (m), d (p) with p <= n <= m + p");
        return Value(0.0);
      }
      // GRQ: B = (0 T12) Q, then A Q^H = Z T (xGGRQF), as xGGLSE does.
      std::vector<T> taub = gerq2(B);
      MatT<T> Qb = qOfRq(B, taub);
      MatT<T> AQ = mul(A, adjointOf(Qb));
      std::vector<T> taua = geqr2(AQ);
      MatT<T> Zq = qOfQr(AQ, taua, m, m);
      std::vector<T> cz = mulVec(adjointOf(Zq), c);
      long long info = 0;
      std::vector<T> x(n, T(0)), dd = d;
      // T12 x2 = d, T12 = B(0:p, n-p:n) upper triangular.
      MatT<T> T12(p, p);
      for (size_t i = 0; i < p; i++)
        for (size_t j = i; j < p; j++)
          T12(i, j) = B(i, n - p + j);
      for (size_t i = 0; i < p; i++)
        if (T12(i, i) == T(0))
          info = 1;
      MatT<T> Dm(p, 1);
      Dm.a = dd;
      if (info == 0 && p > 0)
        triSolve(T12, Dm, false, 'N', false);
      dd = Dm.a;
      if (info == 0) {
        for (size_t i = 0; i < p; i++)
          x[n - p + i] = dd[i];
        const size_t q = n - p;
        for (size_t i = 0; i < q; i++)
          for (size_t j = 0; j < p; j++)
            cz[i] -= AQ(i, q + j) * dd[j];
        MatT<T> R11(q, q), Cq(q, 1);
        for (size_t i = 0; i < q; i++) {
          Cq(i, 0) = cz[i];
          for (size_t j = i; j < q; j++)
            R11(i, j) = AQ(i, j);
        }
        for (size_t i = 0; i < q; i++)
          if (R11(i, i) == T(0))
            info = 2;
        if (info == 0) {
          triSolve(R11, Cq, false, 'N', false);
          for (size_t i = 0; i < q; i++) {
            x[i] = Cq(i, 0);
            cz[i] = Cq(i, 0);
          }
          // Remaining rows: the residual components.
          size_t nr = p;
          if (m < n) {
            nr = m + p - n;
            for (size_t i = 0; i < nr; i++)
              for (size_t j = 0; j < n - m; j++)
                cz[q + i] -= AQ(q + i, m + j) * dd[nr + j];
          }
          std::vector<T> tv(nr, T(0));
          for (size_t i = 0; i < nr; i++)
            for (size_t j = i; j < nr; j++)
              tv[i] += AQ(q + i, q + j) * dd[j];
          for (size_t i = 0; i < nr; i++)
            cz[q + i] -= tv[i];
          x = mulVec(adjointOf(Qb), x);
        }
      }
      return makeDict({{"t", outM(AQ)}, {"r", outM(B)}, {"res", outV(cz)}, {"x", outV(x)}, {"info", inum(info)}});
    });
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
