// Singular value decompositions (gesvd, gesdd, gejsv), the secular equation
// root of a rank-one update (lasd4), and the cosine-sine decomposition of a
// partitioned orthogonal or unitary matrix (orcsd, uncsd). The singular values
// and angles are unique; the signs of singular vectors are arbitrary in LAPACK too.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

// Full or thin SVD: U (m x m or m x k), s (k), V^H (n x n or k x n).
template <class T> void svdFull(const MatT<T> &A, bool full, MatT<T> &U, Vec &s, MatT<T> &Vt) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  MatT<T> Ut, V;
  la::svdThin(A, Ut, s, V);
  s.resize(k);
  MatT<T> Uk(m, k), Vk(n, k);
  for (size_t i = 0; i < m; i++)
    for (size_t j = 0; j < k && j < Ut.c; j++)
      Uk(i, j) = Ut(i, j);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < k && j < V.c; j++)
      Vk(i, j) = V(i, j);
  if (full) {
    U = la::completeBasis(Uk);
    Vt = adjointOf(la::completeBasis(Vk));
  } else {
    U = Uk;
    Vt = adjointOf(Vk);
  }
}

// Columns `want[j]` (empty = free) normalized, the free ones completed to an
// orthonormal basis of the whole space, in the order given.
template <class T> MatT<T> basisFrom(size_t n, const std::vector<std::vector<T>> &want) {
  MatT<T> Q(n, want.size());
  std::vector<bool> done(want.size(), false);
  auto orth = [&](std::vector<T> v, size_t upto, const std::vector<bool> &use) {
    for (int pass = 0; pass < 2; pass++)
      for (size_t c = 0; c < upto; c++) {
        if (!use[c])
          continue;
        T d(0);
        for (size_t i = 0; i < n; i++)
          d += conjOf(Q(i, c)) * v[i];
        for (size_t i = 0; i < n; i++)
          v[i] -= d * Q(i, c);
      }
    return v;
  };
  // Determined columns first (in order), Gram-Schmidt among themselves.
  for (size_t j = 0; j < want.size(); j++) {
    if (want[j].empty())
      continue;
    std::vector<T> v = orth(want[j], want.size(), done);
    double nv = 0.0;
    for (const T &x : v)
      nv += absOf(x) * absOf(x);
    nv = std::sqrt(nv);
    if (nv < 1e-12)
      continue;
    for (size_t i = 0; i < n; i++)
      Q(i, j) = v[i] / T(nv);
    done[j] = true;
  }
  size_t e = 0;
  for (size_t j = 0; j < want.size(); j++) {
    if (done[j])
      continue;
    while (e < n) {
      std::vector<T> v(n, T(0));
      v[e++] = T(1);
      v = orth(v, want.size(), done);
      double nv = 0.0;
      for (const T &x : v)
        nv += absOf(x) * absOf(x);
      nv = std::sqrt(nv);
      if (nv > 1e-8) {
        for (size_t i = 0; i < n; i++)
          Q(i, j) = v[i] / T(nv);
        done[j] = true;
        break;
      }
    }
  }
  return Q;
}

// The CS decomposition X = diag(U1, U2) D diag(V1, V2)^H with LAPACK's layout
// of D (identity, C/S and zero blocks), for X = [X11 X12; X21 X22].
template <class T>
Value csd(const MatT<T> &X11, const MatT<T> &X12, const MatT<T> &X21, const MatT<T> &X22, bool c1, bool c2, bool c3,
          bool c4) {
  const size_t p = X11.r, q = X11.c, m = p + X21.r;
  const size_t mp = m - p, mq = m - q;
  const size_t r = std::min(std::min(p, mp), std::min(q, mq));
  const size_t k11 = std::min(p, q) - r, k12 = std::min(p, mq) - r, k21 = std::min(mp, q) - r, k22 = std::min(mp, mq) - r;
  (void)k12;
  (void)k22;
  // U1, V1 from the SVD of X11 (singular values descending: ones, cosines, zeros).
  MatT<T> U1, V1t;
  Vec sv;
  svdFull(X11, true, U1, sv, V1t);
  MatT<T> V1 = adjointOf(V1t);
  Vec theta(r);
  for (size_t t = 0; t < r; t++) {
    const double c = k11 + t < sv.size() ? std::min(1.0, std::max(0.0, sv[k11 + t])) : 0.0;
    theta[t] = std::acos(c);
  }
  auto col = [](const MatT<T> &M, size_t j) {
    std::vector<T> v(M.r);
    for (size_t i = 0; i < M.r; i++)
      v[i] = M(i, j);
    return v;
  };
  auto scaled = [](std::vector<T> v, double f) {
    for (auto &x : v)
      x *= T(f);
    return v;
  };
  // U2 columns: rows of D21 are [k22 | r (S) | k21 (I)].
  std::vector<std::vector<T>> w2(mp);
  for (size_t t = 0; t < r; t++) {
    const double s = std::sin(theta[t]);
    if (s > 1e-10)
      w2[k22 + t] = scaled(mulVec(X21, col(V1, k11 + t)), 1.0 / s);
  }
  for (size_t t = 0; t < k21; t++)
    w2[k22 + r + t] = mulVec(X21, col(V1, k11 + r + t));
  MatT<T> U2 = basisFrom<T>(mp, w2);
  // V2 columns: [k22 (from X22) | r (-S) | k12 (-I)].
  MatT<T> X12h = adjointOf(X12), X22h = adjointOf(X22);
  std::vector<std::vector<T>> v2(mq);
  for (size_t t = 0; t < k22; t++)
    v2[t] = mulVec(X22h, col(U2, t));
  for (size_t t = 0; t < r; t++) {
    const double s = std::sin(theta[t]);
    if (s > 1e-10)
      v2[k22 + t] = scaled(mulVec(X12h, col(U1, k11 + t)), -1.0 / s);
    else
      v2[k22 + t] = scaled(mulVec(X22h, col(U2, k22 + t)), 1.0 / std::max(std::cos(theta[t]), 1e-300));
  }
  for (size_t t = 0; t + k22 + r < mq; t++)
    v2[k22 + r + t] = scaled(mulVec(X12h, col(U1, k11 + r + t)), -1.0);
  MatT<T> V2 = basisFrom<T>(mq, v2);
  auto opt = [](bool on, const MatT<T> &M) { return on ? M : MatT<T>(0, 0); };
  return makeDict({{"cs11", outM(X11)}, {"cs12", outM(X12)}, {"cs21", outM(X21)}, {"cs22", outM(X22)},
                   {"theta", toValue(theta)}, {"u1", outM(opt(c1, U1))}, {"u2", outM(opt(c2, U2))},
                   {"v1t", outM(opt(c3, V1t))}, {"v2t", outM(opt(c4, adjointOf(V2)))}, {"info", inum(0)}});
}

} // namespace

void registerBlwSvd(Registry &reg) {
  static const auto svdBody = [](const Args &a, CallContext &ctx) -> Value {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getM(a, 0, ctx, A))
        return Value(0.0);
      const bool uv = iopt(a, 1, 1) != 0, full = iopt(a, 2, 1) != 0;
      MatT<T> U, Vt;
      Vec s;
      svdFull(A, full, U, s, Vt);
      if (!uv) {
        U = MatT<T>(1, 1);
        Vt = MatT<T>(1, 1);
      }
      return makeDict({{"u", outM(U)}, {"s", toValue(s)}, {"vt", outM(Vt)}, {"info", inum(0)}});
    });
  };
  SP_ADD("lapack_gesvd", 1, 5, "a, compute_uv, full_matrices, lwork") {
    return svdBody(a, ctx);
  } SP_ENDC
  SP_ADD("lapack_gesdd", 1, 5, "a, compute_uv, full_matrices, lwork") {
    return svdBody(a, ctx);
  } SP_ENDC
  SP_ADD("lapack_gejsv", 1, 9, "a, joba, jobu, jobv, jobr, jobt, jobp, lwork") {
    Mat A;
    if (!getMat(a, 0, ctx, A))
      return Value(0.0);
    const size_t m = A.r, n = A.c;
    if (m < n) {
      ctx.fail("a must have at least as many rows as columns (m >= n)");
      return Value(0.0);
    }
    const long long jobu = iopt(a, 2, 0), jobv = iopt(a, 3, 0), jobt = iopt(a, 5, 0);
    Mat U, Vt;
    Vec s;
    svdFull(A, jobu == 1, U, s, Vt);
    size_t rank = 0;
    for (double x : s)
      rank += x > kEps * static_cast<double>(m) * (s.empty() ? 0.0 : s[0]) ? 1 : 0;
    const bool noU = jobt == 0 && jobu == 3, noV = jobt == 0 && jobv == 3;
    Mat Uo = (jobu == 0 || jobu == 1) ? U : Mat(noU ? 0 : m, noU ? 0 : (jobu == 1 ? m : n));
    Mat Vo = (jobv == 0 || jobv == 1) ? adjointOf(Vt) : Mat(noV ? 0 : n, noV ? 0 : n);
    Vec wo(7, 0.0);
    wo[0] = wo[1] = 1.0;
    return makeDict({{"sva", toValue(s)}, {"u", toValue(Uo)}, {"v", toValue(Vo)}, {"workout", toValue(wo)},
                     {"iworkout", toValue(IVec{static_cast<long long>(rank), static_cast<long long>(rank), 0})},
                     {"info", inum(0)}});
  } SP_END
  SP_ADD("lapack_lasd4", 3, 4, "i, d, z, rho") {
    long long i;
    Vec d, zv;
    if (!getI(a, 0, ctx, i) || !getVec(a, 1, ctx, d) || !getVec(a, 2, ctx, zv))
      return Value(0.0);
    const size_t n = d.size();
    if (zv.size() != n || i < 0 || i >= static_cast<long long>(n)) {
      ctx.fail("z must match d and i must lie between 0 and n-1");
      return Value(0.0);
    }
    for (size_t k = 1; k < n; k++)
      if (!(d[k] > d[k - 1])) {
        ctx.fail("d must be strictly increasing");
        return Value(0.0);
      }
    const double rho = given(a, 3) && isPlainNumber(a[3]) ? a[3].number : 1.0;
    if (!(rho > 0.0)) {
      ctx.fail("rho must be positive");
      return Value(0.0);
    }
    // Eigenvalues of D^2 + rho z z^T (ascending); the square root of eigenvalue i (0-based) is sigma.
    Mat M(n, n);
    for (size_t r = 0; r < n; r++)
      for (size_t c = 0; c < n; c++)
        M(r, c) = rho * zv[r] * zv[c] + (r == c ? d[r] * d[r] : 0.0);
    Vec w;
    Mat V;
    la::eigHermitian(M, w, V);
    const double sigma = std::sqrt(std::max(0.0, w[static_cast<size_t>(i)]));
    Vec delta(n), work(n);
    for (size_t k = 0; k < n; k++) {
      delta[k] = d[k] - sigma;
      work[k] = d[k] + sigma;
    }
    return makeDict({{"delta", toValue(delta)}, {"sigma", Value(sigma)}, {"work", toValue(work)}, {"info", inum(0)}});
  } SP_END
  static const auto csdBody = [](const Args &a, CallContext &ctx, bool forceC) -> Value {
    auto f = [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> X11, X12, X21, X22;
      if (!getM(a, 0, ctx, X11) || !getM(a, 1, ctx, X12) || !getM(a, 2, ctx, X21) || !getM(a, 3, ctx, X22))
        return Value(0.0);
      if (X12.r != X11.r || X21.c != X11.c || X22.r != X21.r || X22.c != X12.c || X11.r + X21.r != X11.c + X12.c) {
        ctx.fail("the four blocks must form a square matrix [x11 x12; x21 x22]");
        return Value(0.0);
      }
      return csd(X11, X12, X21, X22, iopt(a, 4, 1) != 0, iopt(a, 5, 1) != 0, iopt(a, 6, 1) != 0, iopt(a, 7, 1) != 0);
    };
    return forceC ? cplx(f) : both(a, f);
  };
  SP_ADD("lapack_orcsd", 4, 15, "x11, x12, x21, x22, compute_u1, compute_u2, compute_v1t, compute_v2t, trans, signs, lwork") {
    return csdBody(a, ctx, false);
  } SP_ENDC
  SP_ADD("lapack_uncsd", 4, 16, "x11, x12, x21, x22, compute_u1, compute_u2, compute_v1t, compute_v2t, trans, signs, lwork, lrwork") {
    return csdBody(a, ctx, true);
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
