// Section 25 of 25 - Low-level BLAS & LAPACK Wrappers - Appendix B
// SciPy module: scipy.linalg.blas / lapack
// Planned entries: 774
//
// This file is the ONE place where this section's entries are mapped to NC
// names. Nothing outside this folder needs to change when you add one.//
// Appendix B note: low-level BLAS/LAPACK wrappers (774). Prefer one generic
// implementation per routine family (e.g. ?gemm for s/d/c/z) in a group file,
// registered under each precision's name, rather than 774 separate bodies.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        blas_lapack_wrappers/blw_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerBlasLapackWrappers() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Scipy/scipy_sources.cmake globs the whole Scipy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 25 sections.
//   - A name already used by an NC builtin (ops/), by a NumPy function
//     (Numpy/), by an NC keyword or a parser-reserved call is skipped: the
//     existing one stays. The reason is printed at startup.
#include "blas_lapack_wrappers_main.h"

#include "blw_groups.h"

namespace nc {
namespace scipy {

// Each group lives in its own file (blw_groups.h lists them).
void registerBlasLapackWrappers(Registry &reg) {
  registerBlwBlas(reg);
  registerBlwLu(reg);
  registerBlwChol(reg);
  registerBlwSym(reg);
  registerBlwQr(reg);
  registerBlwEig(reg);
  registerBlwSvd(reg);
  registerBlwLwork(reg);
}

} // namespace scipy
} // namespace nc
