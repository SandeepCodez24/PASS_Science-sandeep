// Symmetric and Hermitian indefinite matrices: the Bunch-Kaufman factorisation
// A = U D U^T / L D L^T (xSYTF2 and xHETF2, ported step by step so the factor
// and the 1-based pivots match SciPy), with solves, inverses, condition
// numbers, the storage conversion xSYCONV and the scalings xSYEQUB.
// sy* names cover s/d/c/z (complex symmetric); he* names are the Hermitian ones.
#include "blw_common.h"
#include "blw_groups.h"

#define SP_SEC Section::BlasLapackWrappers

namespace nc {
namespace scipy {

using namespace blw;

namespace {

template <class T> T cj(const T &x, bool herm) { return herm ? conjOf(x) : x; }

// xSYTF2 / xHETF2. ipiv is 1-based, negative for the two rows of a 2x2 block.
template <class T> long long sytf2(MatT<T> &A, bool lower, bool herm, std::vector<long long> &ipiv) {
  const long long n = static_cast<long long>(A.r);
  const double alpha = (1.0 + std::sqrt(17.0)) / 8.0;
  ipiv.assign(static_cast<size_t>(n), 0);
  long long info = 0;
  auto at = [&](long long i, long long j) -> T & { return A(static_cast<size_t>(i - 1), static_cast<size_t>(j - 1)); };
  auto dabs = [&](long long i) { return herm ? std::fabs(realOf(at(i, i))) : cabs1(at(i, i)); };
  auto mkReal = [&](long long i) {
    if (herm)
      at(i, i) = T(realOf(at(i, i)));
  };
  if (!lower) {
    long long k = n;
    while (k >= 1) {
      long long kstep = 1, kp = k, imax = 0;
      const double absakk = dabs(k);
      double colmax = 0.0;
      for (long long i = 1; i < k; i++)
        if (cabs1(at(i, k)) > colmax || imax == 0) {
          if (imax == 0 || cabs1(at(i, k)) > colmax) {
            colmax = cabs1(at(i, k));
            imax = i;
          }
        }
      if (std::max(absakk, colmax) == 0.0 || std::isnan(absakk)) {
        if (info == 0)
          info = k;
        kp = k;
        mkReal(k);
      } else {
        if (absakk >= alpha * colmax) {
          kp = k;
        } else {
          double rowmax = 0.0;
          long long jmax = 0;
          for (long long j = imax + 1; j <= k; j++)
            if (jmax == 0 || cabs1(at(imax, j)) > rowmax) {
              rowmax = cabs1(at(imax, j));
              jmax = j;
            }
          if (imax > 1) {
            double r2 = -1.0;
            for (long long j = 1; j < imax; j++)
              if (cabs1(at(j, imax)) > r2)
                r2 = cabs1(at(j, imax));
            rowmax = std::max(rowmax, r2);
          }
          if (absakk >= alpha * colmax * (colmax / rowmax))
            kp = k;
          else if (dabs(imax) >= alpha * rowmax)
            kp = imax;
          else {
            kp = imax;
            kstep = 2;
          }
        }
        const long long kk = k - kstep + 1;
        if (kp != kk) {
          for (long long i = 1; i < kp; i++)
            std::swap(at(i, kk), at(i, kp));
          for (long long j = kp + 1; j < kk; j++) {
            T t = cj(at(j, kk), herm);
            at(j, kk) = cj(at(kp, j), herm);
            at(kp, j) = t;
          }
          if (herm)
            at(kp, kk) = conjOf(at(kp, kk));
          std::swap(at(kk, kk), at(kp, kp));
          mkReal(kk);
          mkReal(kp);
          if (kstep == 2) {
            mkReal(k);
            std::swap(at(k - 1, k), at(kp, k));
          }
        } else {
          mkReal(k);
          if (kstep == 2)
            mkReal(k - 1);
        }
        if (kstep == 1) {
          const T r1 = herm ? T(1.0 / realOf(at(k, k))) : T(1) / at(k, k);
          for (long long j = 1; j < k; j++)
            for (long long i = 1; i <= j; i++)
              at(i, j) -= r1 * at(i, k) * cj(at(j, k), herm);
          for (long long i = 1; i < k; i++) {
            at(i, k) *= r1;
            if (herm)
              mkReal(i);
          }
        } else if (k > 2) {
          if (herm) {
            double d = std::abs(cd(at(k - 1, k)));
            const double d22 = realOf(at(k - 1, k - 1)) / d, d11 = realOf(at(k, k)) / d;
            const double tt = 1.0 / (d11 * d22 - 1.0);
            const T d12 = at(k - 1, k) / T(d);
            d = tt / d;
            for (long long j = k - 2; j >= 1; j--) {
              const T wkm1 = T(d) * (T(d11) * at(j, k - 1) - conjOf(d12) * at(j, k));
              const T wk = T(d) * (T(d22) * at(j, k) - d12 * at(j, k - 1));
              for (long long i = j; i >= 1; i--)
                at(i, j) -= at(i, k) * conjOf(wk) + at(i, k - 1) * conjOf(wkm1);
              at(j, k) = wk;
              at(j, k - 1) = wkm1;
              mkReal(j);
            }
          } else {
            T d12 = at(k - 1, k);
            const T d22 = at(k - 1, k - 1) / d12, d11 = at(k, k) / d12;
            const T t = T(1) / (d11 * d22 - T(1));
            d12 = t / d12;
            for (long long j = k - 2; j >= 1; j--) {
              const T wkm1 = d12 * (d11 * at(j, k - 1) - at(j, k));
              const T wk = d12 * (d22 * at(j, k) - at(j, k - 1));
              for (long long i = j; i >= 1; i--)
                at(i, j) -= at(i, k) * wk + at(i, k - 1) * wkm1;
              at(j, k) = wk;
              at(j, k - 1) = wkm1;
            }
          }
        }
      }
      if (kstep == 1) {
        ipiv[static_cast<size_t>(k - 1)] = kp;
      } else {
        ipiv[static_cast<size_t>(k - 1)] = -kp;
        ipiv[static_cast<size_t>(k - 2)] = -kp;
      }
      k -= kstep;
    }
  } else {
    long long k = 1;
    while (k <= n) {
      long long kstep = 1, kp = k, imax = 0;
      const double absakk = dabs(k);
      double colmax = 0.0;
      for (long long i = k + 1; i <= n; i++)
        if (imax == 0 || cabs1(at(i, k)) > colmax) {
          colmax = cabs1(at(i, k));
          imax = i;
        }
      if (std::max(absakk, colmax) == 0.0 || std::isnan(absakk)) {
        if (info == 0)
          info = k;
        kp = k;
        mkReal(k);
      } else {
        if (absakk >= alpha * colmax) {
          kp = k;
        } else {
          double rowmax = 0.0;
          long long jmax = 0;
          for (long long j = k; j < imax; j++)
            if (jmax == 0 || cabs1(at(imax, j)) > rowmax) {
              rowmax = cabs1(at(imax, j));
              jmax = j;
            }
          if (imax < n) {
            double r2 = -1.0;
            for (long long j = imax + 1; j <= n; j++)
              if (cabs1(at(j, imax)) > r2)
                r2 = cabs1(at(j, imax));
            rowmax = std::max(rowmax, r2);
          }
          if (absakk >= alpha * colmax * (colmax / rowmax))
            kp = k;
          else if (dabs(imax) >= alpha * rowmax)
            kp = imax;
          else {
            kp = imax;
            kstep = 2;
          }
        }
        const long long kk = k + kstep - 1;
        if (kp != kk) {
          for (long long i = kp + 1; i <= n; i++)
            std::swap(at(i, kk), at(i, kp));
          for (long long j = kk + 1; j < kp; j++) {
            T t = cj(at(j, kk), herm);
            at(j, kk) = cj(at(kp, j), herm);
            at(kp, j) = t;
          }
          if (herm)
            at(kp, kk) = conjOf(at(kp, kk));
          std::swap(at(kk, kk), at(kp, kp));
          mkReal(kk);
          mkReal(kp);
          if (kstep == 2) {
            mkReal(k);
            std::swap(at(k + 1, k), at(kp, k));
          }
        } else {
          mkReal(k);
          if (kstep == 2)
            mkReal(k + 1);
        }
        if (kstep == 1) {
          if (k < n) {
            const T d11 = herm ? T(1.0 / realOf(at(k, k))) : T(1) / at(k, k);
            for (long long j = k + 1; j <= n; j++)
              for (long long i = j; i <= n; i++)
                at(i, j) -= d11 * at(i, k) * cj(at(j, k), herm);
            for (long long i = k + 1; i <= n; i++) {
              at(i, k) *= d11;
              if (herm)
                mkReal(i);
            }
          }
        } else if (k < n - 1) {
          if (herm) {
            double d = std::abs(cd(at(k + 1, k)));
            const double d11 = realOf(at(k + 1, k + 1)) / d, d22 = realOf(at(k, k)) / d;
            const double tt = 1.0 / (d11 * d22 - 1.0);
            const T d21 = at(k + 1, k) / T(d);
            d = tt / d;
            for (long long j = k + 2; j <= n; j++) {
              const T wk = T(d) * (T(d11) * at(j, k) - d21 * at(j, k + 1));
              const T wkp1 = T(d) * (T(d22) * at(j, k + 1) - conjOf(d21) * at(j, k));
              for (long long i = j; i <= n; i++)
                at(i, j) -= at(i, k) * conjOf(wk) + at(i, k + 1) * conjOf(wkp1);
              at(j, k) = wk;
              at(j, k + 1) = wkp1;
              mkReal(j);
            }
          } else {
            T d21 = at(k + 1, k);
            const T d11 = at(k + 1, k + 1) / d21, d22 = at(k, k) / d21;
            const T t = T(1) / (d11 * d22 - T(1));
            d21 = t / d21;
            for (long long j = k + 2; j <= n; j++) {
              const T wk = d21 * (d11 * at(j, k) - at(j, k + 1));
              const T wkp1 = d21 * (d22 * at(j, k + 1) - at(j, k));
              for (long long i = j; i <= n; i++)
                at(i, j) -= at(i, k) * wk + at(i, k + 1) * wkp1;
              at(j, k) = wk;
              at(j, k + 1) = wkp1;
            }
          }
        }
      }
      if (kstep == 1) {
        ipiv[static_cast<size_t>(k - 1)] = kp;
      } else {
        ipiv[static_cast<size_t>(k - 1)] = -kp;
        ipiv[static_cast<size_t>(k)] = -kp;
      }
      k += kstep;
    }
  }
  return info;
}

// xSYTRS / xHETRS on every column of B.
template <class T>
void sytrs(const MatT<T> &A, const std::vector<long long> &ipiv, MatT<T> &B, bool lower, bool herm) {
  const long long n = static_cast<long long>(A.r);
  auto at = [&](long long i, long long j) { return A(static_cast<size_t>(i - 1), static_cast<size_t>(j - 1)); };
  auto piv = [&](long long k) { return ipiv[static_cast<size_t>(k - 1)]; };
  for (size_t c = 0; c < B.c; c++) {
    auto b = [&](long long i) -> T & { return B(static_cast<size_t>(i - 1), c); };
    auto sw = [&](long long i, long long j) {
      if (i != j)
        std::swap(b(i), b(j));
    };
    if (!lower) {
      long long k = n;
      while (k >= 1) {
        if (piv(k) > 0) {
          sw(k, piv(k));
          for (long long i = 1; i < k; i++)
            b(i) -= at(i, k) * b(k);
          b(k) = herm ? b(k) * T(1.0 / realOf(at(k, k))) : b(k) / at(k, k);
          k--;
        } else {
          sw(k - 1, -piv(k));
          for (long long i = 1; i < k - 1; i++)
            b(i) -= at(i, k) * b(k) + at(i, k - 1) * b(k - 1);
          const T akm1k = at(k - 1, k);
          const T akm1 = at(k - 1, k - 1) / akm1k, ak = at(k, k) / cj(akm1k, herm);
          const T denom = akm1 * ak - T(1);
          const T bkm1 = b(k - 1) / akm1k, bk = b(k) / cj(akm1k, herm);
          b(k - 1) = (ak * bkm1 - bk) / denom;
          b(k) = (akm1 * bk - bkm1) / denom;
          k -= 2;
        }
      }
      k = 1;
      while (k <= n) {
        if (piv(k) > 0) {
          for (long long i = 1; i < k; i++)
            b(k) -= cj(at(i, k), herm) * b(i);
          sw(k, piv(k));
          k++;
        } else {
          for (long long i = 1; i < k; i++) {
            b(k) -= cj(at(i, k), herm) * b(i);
            b(k + 1) -= cj(at(i, k + 1), herm) * b(i);
          }
          sw(k, -piv(k));
          k += 2;
        }
      }
    } else {
      long long k = 1;
      while (k <= n) {
        if (piv(k) > 0) {
          sw(k, piv(k));
          for (long long i = k + 1; i <= n; i++)
            b(i) -= at(i, k) * b(k);
          b(k) = herm ? b(k) * T(1.0 / realOf(at(k, k))) : b(k) / at(k, k);
          k++;
        } else {
          sw(k + 1, -piv(k));
          for (long long i = k + 2; i <= n; i++)
            b(i) -= at(i, k) * b(k) + at(i, k + 1) * b(k + 1);
          const T akm1k = at(k + 1, k);
          const T akm1 = at(k, k) / cj(akm1k, herm), ak = at(k + 1, k + 1) / akm1k;
          const T denom = akm1 * ak - T(1);
          const T bkm1 = b(k) / cj(akm1k, herm), bk = b(k + 1) / akm1k;
          b(k) = (ak * bkm1 - bk) / denom;
          b(k + 1) = (akm1 * bk - bkm1) / denom;
          k += 2;
        }
      }
      k = n;
      while (k >= 1) {
        if (piv(k) > 0) {
          for (long long i = k + 1; i <= n; i++)
            b(k) -= cj(at(i, k), herm) * b(i);
          sw(k, piv(k));
          k--;
        } else {
          for (long long i = k + 1; i <= n; i++) {
            b(k) -= cj(at(i, k), herm) * b(i);
            b(k - 1) -= cj(at(i, k - 1), herm) * b(i);
          }
          sw(k, -piv(k));
          k -= 2;
        }
      }
    }
  }
}

// Checks 1-based Bunch-Kaufman pivots.
inline bool pivOk(const IVec &p, size_t n, CallContext &ctx) {
  if (p.size() < n) {
    ctx.fail("ipiv must hold n pivots");
    return false;
  }
  for (size_t i = 0; i < n; i++) {
    const long long q = p[i] < 0 ? -p[i] : p[i];
    if (q < 1 || q > static_cast<long long>(n)) {
      ctx.fail("ipiv must be the 1-based pivots of the factorisation");
      return false;
    }
  }
  return true;
}
// A zero 1x1 block or singular 2x2 block of D: info as LAPACK's xSYTRI/xSYCON.
template <class T> long long dSingular(const MatT<T> &A, const std::vector<long long> &ipiv, bool lower) {
  const size_t n = A.r;
  if (!lower) {
    for (size_t i = n; i-- > 0;)
      if (ipiv[i] > 0 && A(i, i) == T(0))
        return static_cast<long long>(i) + 1;
  } else {
    for (size_t i = 0; i < n; i++)
      if (ipiv[i] > 0 && A(i, i) == T(0))
        return static_cast<long long>(i) + 1;
  }
  return 0;
}
template <class T> double norm1(const MatT<T> &F) {
  double r = 0.0;
  for (size_t j = 0; j < F.c; j++) {
    double s = 0.0;
    for (size_t i = 0; i < F.r; i++)
      s += absOf(F(i, j));
    r = std::max(r, s);
  }
  return r;
}

// Expert driver: factor, rcond, solve, error bounds.
template <class T> Value sysvx(const Args &a, CallContext &ctx, bool herm) {
  MatT<T> A, B;
  bool wv;
  if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
    return Value(0.0);
  const size_t n = A.r;
  const bool factored = iopt(a, 5, 0) != 0, lower = iopt(a, 6, 0) != 0;
  MatT<T> F;
  std::vector<long long> ip;
  long long info = 0;
  if (factored) {
    IVec q;
    if (!getSq(a, 2, ctx, F) || !getIdx(a, 3, ctx, q) || !pivOk(q, n, ctx))
      return Value(0.0);
    if (F.r != n) {
      ctx.fail("af must match the size of a");
      return Value(0.0);
    }
    ip.assign(q.begin(), q.begin() + static_cast<long>(n));
  } else {
    F = A;
    info = sytf2(F, lower, herm, ip);
  }
  MatT<T> X(B.r, B.c);
  double rcond = 0.0;
  Vec ferr(B.c, 0.0), berr(B.c, 0.0);
  if (info == 0) {
    MatT<T> Full = fullSym(A, lower, herm);
    MatT<T> Ainv = MatT<T>::eye(n);
    sytrs(F, ip, Ainv, lower, herm);
    const double in = norm1(Ainv), an = norm1(Full);
    rcond = (an > 0.0 && in > 0.0 && std::isfinite(in)) ? (1.0 / in) / an : 0.0;
    X = B;
    sytrs(F, ip, X, lower, herm);
    const double eps = lamch('E'), safe1 = (static_cast<double>(n) + 1) * lamch('S');
    for (size_t c = 0; c < B.c; c++) {
      Vec w(n), rr(n);
      for (size_t i = 0; i < n; i++) {
        T r = B(i, c);
        double sm = cabs1(B(i, c));
        for (size_t k = 0; k < n; k++) {
          r -= Full(i, k) * X(k, c);
          sm += cabs1(Full(i, k)) * cabs1(X(k, c));
        }
        rr[i] = cabs1(r);
        w[i] = sm;
      }
      double be = 0.0, num = 0.0, xn = 0.0;
      for (size_t i = 0; i < n; i++)
        be = std::max(be, w[i] > safe1 ? rr[i] / w[i] : (rr[i] + safe1) / (w[i] + safe1));
      for (size_t i = 0; i < n; i++) {
        double sm = 0.0;
        for (size_t k = 0; k < n; k++)
          sm += absOf(Ainv(i, k)) * (rr[k] + (static_cast<double>(n) + 1) * eps * w[k]);
        num = std::max(num, sm);
        xn = std::max(xn, absOf(X(i, c)));
      }
      berr[c] = be;
      ferr[c] = xn > 0.0 ? num / xn : 0.0;
    }
    if (rcond < lamch('E'))
      info = static_cast<long long>(n) + 1;
  }
  if (herm)
    return makeDict({{"uduh", outM(F)}, {"ipiv", ivec(ip)}, {"x", outB(X, wv)}, {"rcond", Value(rcond)},
                     {"ferr", toValue(ferr)}, {"berr", toValue(berr)}, {"info", inum(info)}});
  return makeDict({{"a_s", outM(A)}, {"udut", outM(F)}, {"ipiv", ivec(ip)}, {"b_s", outB(B, wv)},
                   {"x", outB(X, wv)}, {"rcond", Value(rcond)}, {"ferr", toValue(ferr)},
                   {"berr", toValue(berr)}, {"info", inum(info)}});
}

// xSYEQUB / xHEEQUB: scalings that make the scaled matrix's rows near unit size.
template <class T> Value syequb(const MatT<T> &A, bool lower) {
  const size_t n = A.r;
  auto el = [&](size_t i, size_t j) { return cabs1((lower ? (i >= j) : (i <= j)) ? A(i, j) : A(j, i)); };
  Vec s(n, 0.0), work(2 * n, 0.0);
  double amax = 0.0;
  long long info = 0;
  for (size_t j = 0; j < n; j++)
    for (size_t i = 0; i < n; i++) {
      const double v = el(i, j);
      s[i] = std::max(s[i], v);
      amax = std::max(amax, v);
    }
  for (size_t j = 0; j < n; j++)
    if (s[j] == 0.0) {
      info = static_cast<long long>(j) + 1;
      return makeDict({{"s", toValue(Vec(n, 0.0))}, {"scond", Value(0.0)}, {"amax", Value(amax)},
                       {"info", inum(info)}});
    }
  if (n == 0)
    return makeDict({{"s", toValue(s)}, {"scond", Value(1.0)}, {"amax", Value(0.0)}, {"info", inum(0)}});
  for (double &v : s)
    v = 1.0 / v;
  const double tol = 1.0 / std::sqrt(2.0 * static_cast<double>(n)), N = static_cast<double>(n);
  double avg = 0.0;
  for (int iter = 0; iter < 100; iter++) {
    for (size_t i = 0; i < n; i++)
      work[i] = 0.0;
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        work[i] += el(i, j) * s[j];
    avg = 0.0;
    for (size_t i = 0; i < n; i++)
      avg += s[i] * work[i];
    avg /= N;
    double ssq = 0.0;
    for (size_t i = 0; i < n; i++) {
      const double d = s[i] * work[i] - avg;
      ssq += d * d;
    }
    const double stdv = std::sqrt(ssq / N);
    if (stdv < tol * avg)
      break;
    for (size_t i = 0; i < n; i++) {
      const double t = el(i, i), si0 = s[i];
      const double c2 = (N - 1) * t, c1 = (N - 2) * (work[i] - t * si0);
      const double c0 = -(t * si0) * si0 + 2 * work[i] * si0 - N * avg;
      const double d = c1 * c1 - 4 * c0 * c2;
      if (d <= 0) {
        info = -1;
        return makeDict({{"s", toValue(s)}, {"scond", Value(0.0)}, {"amax", Value(amax)}, {"info", inum(info)}});
      }
      const double si = -2 * c0 / (c1 + std::sqrt(d));
      const double dd = si - s[i];
      double u = 0.0;
      for (size_t j = 0; j < n; j++) {
        const double t2 = el(j, i);
        u += s[j] * t2;
        work[j] += dd * t2;
      }
      avg += (u + work[i]) * dd / N;
      s[i] = si;
    }
  }
  const double smlnum = lamch('S'), bignum = 1.0 / smlnum, t = 1.0 / std::sqrt(avg), u = 1.0 / std::log(2.0);
  double smin = bignum, smax = 0.0;
  for (size_t i = 0; i < n; i++) {
    s[i] = std::pow(2.0, static_cast<double>(static_cast<long long>(u * std::log(s[i] * t))));
    smin = std::min(smin, s[i]);
    smax = std::max(smax, s[i]);
  }
  return makeDict({{"s", toValue(s)},
                   {"scond", Value(std::max(smin, smlnum) / std::min(smax, bignum))},
                   {"amax", Value(amax)},
                   {"info", inum(info)}});
}

// xSYCONV: way 0 moves the 2x2 off-diagonals of D into e and applies the
// row interchanges to the triangular factor; way 1 reverts it.
template <class T> Value syconv(MatT<T> A, const std::vector<long long> &ipiv, bool lower, bool revert, CallContext &ctx) {
  const long long n = static_cast<long long>(A.r);
  std::vector<T> e(static_cast<size_t>(n), T(0));
  auto at = [&](long long i, long long j) -> T & { return A(static_cast<size_t>(i - 1), static_cast<size_t>(j - 1)); };
  auto ev = [&](long long i) -> T & { return e[static_cast<size_t>(i - 1)]; };
  auto piv = [&](long long i) { return ipiv[static_cast<size_t>(i - 1)]; };
  auto swapRows = [&](long long r1, long long r2, long long j0, long long j1) {
    for (long long j = j0; j <= j1; j++)
      std::swap(at(r1, j), at(r2, j));
  };
  (void)ctx;
  if (n == 0)
    return makeDict({{"a", outM(A)}, {"e", outV(e)}, {"info", inum(0)}});
  if (!lower) {
    if (!revert) {
      long long i = n;
      ev(1) = T(0);
      while (i > 1) {
        if (piv(i) < 0) {
          ev(i) = at(i - 1, i);
          ev(i - 1) = T(0);
          at(i - 1, i) = T(0);
          i--;
        } else {
          ev(i) = T(0);
        }
        i--;
      }
      i = n;
      while (i >= 1) {
        if (piv(i) > 0) {
          if (i < n)
            swapRows(piv(i), i, i + 1, n);
        } else {
          if (i < n)
            swapRows(-piv(i), i - 1, i + 1, n);
          i--;
        }
        i--;
      }
    } else {
      long long i = 1;
      while (i <= n) {
        if (piv(i) > 0) {
          if (i < n)
            swapRows(piv(i), i, i + 1, n);
        } else {
          i++;
          if (i < n)
            swapRows(-piv(i), i - 1, i + 1, n);
        }
        i++;
      }
      i = n;
      while (i > 1) {
        if (piv(i) < 0) {
          at(i - 1, i) = ev(i);
          i--;
        }
        i--;
      }
    }
  } else {
    if (!revert) {
      long long i = 1;
      ev(n) = T(0);
      while (i <= n) {
        if (i < n && piv(i) < 0) {
          ev(i) = at(i + 1, i);
          ev(i + 1) = T(0);
          at(i + 1, i) = T(0);
          i++;
        } else {
          ev(i) = T(0);
        }
        i++;
      }
      i = 1;
      while (i <= n) {
        if (piv(i) > 0) {
          if (i > 1)
            swapRows(piv(i), i, 1, i - 1);
        } else {
          if (i > 1)
            swapRows(-piv(i), i + 1, 1, i - 1);
          i++;
        }
        i++;
      }
    } else {
      long long i = n;
      while (i >= 1) {
        if (piv(i) > 0) {
          if (i > 1)
            swapRows(piv(i), i, 1, i - 1);
        } else {
          i--;
          if (i > 1)
            swapRows(-piv(i), i + 1, 1, i - 1);
        }
        i--;
      }
      i = 1;
      while (i <= n - 1) {
        if (piv(i) < 0) {
          at(i + 1, i) = ev(i);
          i++;
        }
        i++;
      }
    }
  }
  return makeDict({{"a", outM(A)}, {"e", outV(e)}, {"info", inum(0)}});
}

// The bodies shared by the sy* and he* names.
template <class T> Value trfBody(const Args &a, CallContext &ctx, bool herm) {
  MatT<T> A;
  if (!getSq(a, 0, ctx, A))
    return Value(0.0);
  std::vector<long long> ip;
  long long info = sytf2(A, iopt(a, 1, 0) != 0, herm, ip);
  return makeDict({{"ldu", outM(A)}, {"ipiv", ivec(ip)}, {"info", inum(info)}});
}
template <class T> Value trsBody(const Args &a, CallContext &ctx, bool herm) {
  MatT<T> A, B;
  IVec q;
  bool wv;
  if (!getSq(a, 0, ctx, A) || !getIdx(a, 1, ctx, q) || !pivOk(q, A.r, ctx) || !getB(a, 2, ctx, A.r, B, wv))
    return Value(0.0);
  sytrs(A, std::vector<long long>(q.begin(), q.begin() + static_cast<long>(A.r)), B, iopt(a, 3, 0) != 0, herm);
  return makeDict({{"x", outB(B, wv)}, {"info", inum(0)}});
}
template <class T> Value triBody(const Args &a, CallContext &ctx, bool herm) {
  MatT<T> A;
  IVec q;
  if (!getSq(a, 0, ctx, A) || !getIdx(a, 1, ctx, q) || !pivOk(q, A.r, ctx))
    return Value(0.0);
  const bool lower = iopt(a, 2, 0) != 0;
  std::vector<long long> ip(q.begin(), q.begin() + static_cast<long>(A.r));
  const long long info = dSingular(A, ip, lower);
  if (info)
    return makeDict({{"inv_a", outM(A)}, {"info", inum(info)}});
  MatT<T> X = MatT<T>::eye(A.r);
  sytrs(A, ip, X, lower, herm);
  if (herm)
    for (size_t i = 0; i < X.r; i++)
      X(i, i) = T(realOf(X(i, i)));
  MatT<T> out = A;
  putTri(out, X, lower);
  return makeDict({{"inv_a", outM(out)}, {"info", inum(0)}});
}
template <class T> Value svBody(const Args &a, CallContext &ctx, bool herm) {
  MatT<T> A, B;
  bool wv;
  if (!getSq(a, 0, ctx, A) || !getB(a, 1, ctx, A.r, B, wv))
    return Value(0.0);
  const bool lower = iopt(a, 3, 0) != 0;
  std::vector<long long> ip;
  long long info = sytf2(A, lower, herm, ip);
  if (info == 0)
    sytrs(A, ip, B, lower, herm);
  return makeDict({{herm ? "uduh" : "udut", outM(A)}, {"ipiv", ivec(ip)}, {"x", outB(B, wv)}, {"info", inum(info)}});
}
template <class T> Value conBody(const Args &a, CallContext &ctx, bool herm) {
  MatT<T> A;
  IVec q;
  double anorm;
  if (!getSq(a, 0, ctx, A) || !getIdx(a, 1, ctx, q) || !pivOk(q, A.r, ctx) || !argNumber(a, 2, ctx, anorm))
    return Value(0.0);
  const bool lower = iopt(a, 3, 0) != 0;
  std::vector<long long> ip(q.begin(), q.begin() + static_cast<long>(A.r));
  if (anorm == 0.0 || dSingular(A, ip, lower))
    return makeDict({{"rcond", Value(0.0)}, {"info", inum(0)}});
  MatT<T> X = MatT<T>::eye(A.r);
  sytrs(A, ip, X, lower, herm);
  const double in = norm1(X);
  return makeDict({{"rcond", Value(in > 0.0 && std::isfinite(in) ? (1.0 / in) / anorm : 0.0)}, {"info", inum(0)}});
}

} // namespace

void registerBlwSym(Registry &reg) {
#define BLW_SY(NAME, MINA, MAXA, PARAMS, BODY, HERM)                                               \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                               \
    auto f = [&](auto z) -> Value {                                                                \
      using T = decltype(z);                                                                       \
      return BODY<T>(a, ctx, HERM);                                                                \
    };                                                                                             \
    return HERM ? cplx(f) : both(a, f);                                                            \
  } SP_ENDC

  BLW_SY("lapack_sytrf", 1, 4, "a, lower, lwork", trfBody, false)
  BLW_SY("lapack_sytf2", 1, 3, "a, lower", trfBody, false)
  BLW_SY("lapack_hetrf", 1, 4, "a, lower, lwork", trfBody, true)
  BLW_SY("lapack_sytrs", 3, 5, "a, ipiv, b, lower", trsBody, false)
  BLW_SY("lapack_hetrs", 3, 5, "a, ipiv, b, lower", trsBody, true)
  BLW_SY("lapack_sytri", 2, 4, "a, ipiv, lower", triBody, false)
  BLW_SY("lapack_hetri", 2, 4, "a, ipiv, lower", triBody, true)
  BLW_SY("lapack_sycon", 3, 4, "a, ipiv, anorm, lower", conBody, false)
  BLW_SY("lapack_hecon", 3, 4, "a, ipiv, anorm, lower", conBody, true)
  BLW_SY("lapack_sysvx", 2, 9, "a, b, af, ipiv, lwork, factored, lower", sysvx, false)
  BLW_SY("lapack_hesvx", 2, 9, "a, b, af, ipiv, lwork, factored, lower", sysvx, true)
#undef BLW_SY
  SP_ADD("lapack_sysv", 2, 6, "a, b, lwork, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      return svBody<T>(a, ctx, false);
    });
  } SP_ENDC
  SP_ADD("lapack_hesv", 2, 6, "a, b, lwork, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      return svBody<T>(a, ctx, true);
    });
  } SP_ENDC
  SP_ADD("lapack_syconv", 2, 5, "a, ipiv, lower, way") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      IVec q;
      if (!getSq(a, 0, ctx, A) || !getIdx(a, 1, ctx, q) || !pivOk(q, A.r, ctx))
        return Value(0.0);
      return syconv(A, std::vector<long long>(q.begin(), q.begin() + static_cast<long>(A.r)), iopt(a, 2, 0) != 0,
                    iopt(a, 3, 0) != 0, ctx);
    });
  } SP_ENDC
  SP_ADD("lapack_syequb", 1, 2, "a, lower") {
    return both(a, [&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return syequb(A, iopt(a, 1, 0) != 0);
    });
  } SP_ENDC
  SP_ADD("lapack_heequb", 1, 2, "a, lower") {
    return cplx([&](auto z) -> Value {
      using T = decltype(z);
      MatT<T> A;
      if (!getSq(a, 0, ctx, A))
        return Value(0.0);
      return syequb(A, iopt(a, 1, 0) != 0);
    });
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
