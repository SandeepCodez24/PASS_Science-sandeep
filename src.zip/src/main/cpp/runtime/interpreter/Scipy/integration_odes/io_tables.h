// Data tables of the integration section (generated into io_tables.cpp).
#ifndef NC_SCIPY_IO_TABLES_H
#define NC_SCIPY_IO_TABLES_H

namespace nc {
namespace scipy {

extern const double kDopC[13];
extern const double kDopB[12];
extern const double kDopE3[13];
extern const double kDopE5[13];
extern const double kDopA[12][12];

struct LebedevIndex {
  int order, start, count;
};
extern const LebedevIndex kLebedevIndex[];
extern const int kLebedevCount;
extern const double kLebedevPoints[][4];

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_IO_TABLES_H
