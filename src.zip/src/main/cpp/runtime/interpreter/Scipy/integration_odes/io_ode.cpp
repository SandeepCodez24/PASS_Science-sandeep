// ODE solvers of the integration section. Each step calls the NC function, so
// these stay on the interpreter thread; the linear solves inside the implicit
// methods are kernels and can thread without touching this file.
#include "integration_odes_main.h"

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "io_tables.h"

#define SP_SEC Section::IntegrationOdes

namespace nc {
namespace scipy {

namespace {

// f(t, u) as complex numbers; `cplx` chooses what the NC function receives.
struct OdeFn {
  NcFn fn;
  bool cplx;
  bool swapArgs; // odeint: f(u, t)
  size_t n;
  OdeFn(const Value &f, bool c, bool sw, size_t size) : fn(f), cplx(c), swapArgs(sw), n(size) {}
  CVec operator()(double t, const CVec &u) {
    Value uv;
    if (cplx) {
      uv = n == 1 ? cellOf(u[0]) : toValue(u);
    } else {
      Vec r(n);
      for (size_t i = 0; i < n; i++)
        r[i] = u[i].real();
      uv = n == 1 ? Value(r[0]) : toValue(r);
    }
    Value out = swapArgs ? fn.raw({uv, Value(t)}) : fn.raw({Value(t), uv});
    CVec o;
    if (fn.failed)
      return CVec(n, kNaN);
    if (!readCVec(out, o) || o.size() != n) {
      fn.failed = true;
      return CVec(n, kNaN);
    }
    cplx = cplx || out.hasComplex();
    return o;
  }
};

struct Trajectory {
  Vec t;
  std::vector<CVec> u, f;
  void add(double tt, const CVec &uu, const CVec &ff) {
    t.push_back(tt);
    u.push_back(uu);
    f.push_back(ff);
  }
};

double errNorm(const CVec &e, const CVec &y0, const CVec &y1, double rtol, double atol) {
  double s = 0.0;
  for (size_t i = 0; i < e.size(); i++) {
    const double sc = atol + rtol * std::max(std::abs(y0[i]), std::abs(y1[i]));
    s += std::norm(e[i] / sc);
  }
  return std::sqrt(s / static_cast<double>(e.size()));
}

double firstStep(OdeFn &fn, double t0, const CVec &y0, const CVec &f0, double dir, int order, double rtol, double atol) {
  CVec sc(y0.size());
  double d0 = 0.0, d1 = 0.0;
  for (size_t i = 0; i < y0.size(); i++) {
    const double s = atol + std::abs(y0[i]) * rtol;
    d0 += std::norm(y0[i] / s);
    d1 += std::norm(f0[i] / s);
  }
  d0 = std::sqrt(d0 / y0.size());
  d1 = std::sqrt(d1 / y0.size());
  double h0 = (d0 < 1e-5 || d1 < 1e-5) ? 1e-6 : 0.01 * d0 / d1;
  CVec y1(y0.size());
  for (size_t i = 0; i < y0.size(); i++)
    y1[i] = y0[i] + h0 * dir * f0[i];
  CVec f1 = fn(t0 + h0 * dir, y1);
  double d2 = 0.0;
  for (size_t i = 0; i < y0.size(); i++)
    d2 += std::norm((f1[i] - f0[i]) / (atol + std::abs(y0[i]) * rtol));
  d2 = std::sqrt(d2 / y0.size()) / h0;
  double h1 = (d1 <= 1e-15 && d2 <= 1e-15) ? std::max(1e-6, h0 * 1e-3)
                                           : std::pow(0.01 / std::max(d1, d2), 1.0 / (order + 1.0));
  return std::min(100.0 * h0, h1);
}

// The explicit embedded Runge-Kutta pairs.
struct Tableau {
  std::vector<Vec> A;
  Vec B, C, E;
  int order;
  bool fsal;
};
const Tableau &rk23() {
  static const Tableau t{{{}, {0.5}, {0.0, 0.75}},
                         {2.0 / 9.0, 1.0 / 3.0, 4.0 / 9.0},
                         {0.0, 0.5, 0.75},
                         {5.0 / 72.0, -1.0 / 12.0, -1.0 / 9.0, 1.0 / 8.0},
                         3,
                         true};
  return t;
}
const Tableau &rk45() {
  static const Tableau t{{{},
                          {1.0 / 5.0},
                          {3.0 / 40.0, 9.0 / 40.0},
                          {44.0 / 45.0, -56.0 / 15.0, 32.0 / 9.0},
                          {19372.0 / 6561.0, -25360.0 / 2187.0, 64448.0 / 6561.0, -212.0 / 729.0},
                          {9017.0 / 3168.0, -355.0 / 33.0, 46732.0 / 5247.0, 49.0 / 176.0, -5103.0 / 18656.0}},
                         {35.0 / 384.0, 0.0, 500.0 / 1113.0, 125.0 / 192.0, -2187.0 / 6784.0, 11.0 / 84.0},
                         {0.0, 1.0 / 5.0, 3.0 / 10.0, 4.0 / 5.0, 8.0 / 9.0, 1.0},
                         {-71.0 / 57600.0, 0.0, 71.0 / 16695.0, -71.0 / 1920.0, 17253.0 / 339200.0, -22.0 / 525.0, 1.0 / 40.0},
                         5,
                         true};
  return t;
}

// Advances from t to tEnd; stops early (returns false) when stiff is detected and allowed.
bool explicitRK(OdeFn &fn, const Tableau &tb, double &t, double tEnd, CVec &y, CVec &f, double rtol, double atol, Trajectory *tr, bool watchStiff, double &h) {
  const size_t n = y.size();
  const double dir = tEnd >= t ? 1.0 : -1.0;
  const size_t stages = tb.B.size();
  if (h <= 0.0)
    h = firstStep(fn, t, y, f, dir, tb.order, rtol, atol);
  std::vector<CVec> K(stages + 1, CVec(n));
  K[0] = f;
  int stiffCount = 0;
  long steps = 0;
  while (dir * (tEnd - t) > 0.0) {
    if (fn.fn.failed || ++steps > 2000000)
      return !fn.fn.failed;
    double hs = std::min(h, std::fabs(tEnd - t));
    CVec ynew(n), z(n);
    for (size_t s = 1; s < stages; s++) {
      for (size_t i = 0; i < n; i++) {
        cd acc = 0.0;
        for (size_t j = 0; j < s; j++)
          acc += tb.A[s][j] * K[j][i];
        z[i] = y[i] + dir * hs * acc;
      }
      K[s] = fn(t + dir * tb.C[s] * hs, z);
    }
    for (size_t i = 0; i < n; i++) {
      cd acc = 0.0;
      for (size_t j = 0; j < stages; j++)
        acc += tb.B[j] * K[j][i];
      ynew[i] = y[i] + dir * hs * acc;
    }
    K[stages] = fn(t + dir * hs, ynew);
    CVec e(n);
    for (size_t i = 0; i < n; i++) {
      cd acc = 0.0;
      for (size_t j = 0; j <= stages; j++)
        acc += tb.E[j] * K[j][i];
      e[i] = dir * hs * acc;
    }
    double en = errNorm(e, y, ynew, rtol, atol);
    if (!(en == en)) {
      fn.fn.failed = true;
      return false;
    }
    if (en < 1.0) {
      if (watchStiff) {
        double a = 0.0, b = 0.0;
        for (size_t i = 0; i < n; i++) {
          a += std::norm(K[stages][i] - K[stages - 1][i]);
          b += std::norm(ynew[i] - z[i]);
        }
        const double lam = b > 0.0 ? std::sqrt(a / b) : 0.0;
        stiffCount = hs * lam > 3.25 ? stiffCount + 1 : std::max(0, stiffCount - 1);
      }
      t += dir * hs;
      y = ynew;
      K[0] = K[stages];
      f = K[0];
      if (tr)
        tr->add(t, y, f);
      h = hs * std::min(10.0, en == 0.0 ? 10.0 : std::max(0.2, 0.9 * std::pow(en, -1.0 / (tb.order < 5 ? 3.0 : 5.0))));
      if (stiffCount >= 15)
        return false;
    } else {
      h = hs * std::max(0.2, 0.9 * std::pow(en, -1.0 / (tb.order < 5 ? 3.0 : 5.0)));
    }
    if (h < 1e-14 * std::max(1.0, std::fabs(t))) {
      fn.fn.failed = true;
      return false;
    }
  }
  return true;
}

void dop853(OdeFn &fn, double &t, double tEnd, CVec &y, CVec &f, double rtol, double atol, Trajectory *tr) {
  const size_t n = y.size();
  const double dir = tEnd >= t ? 1.0 : -1.0;
  double h = firstStep(fn, t, y, f, dir, 7, rtol, atol);
  std::vector<CVec> K(13, CVec(n));
  K[0] = f;
  long steps = 0;
  while (dir * (tEnd - t) > 0.0 && !fn.fn.failed && ++steps < 2000000) {
    const double hs = std::min(h, std::fabs(tEnd - t));
    CVec z(n), ynew(n);
    for (int s = 1; s < 12; s++) {
      for (size_t i = 0; i < n; i++) {
        cd acc = 0.0;
        for (int j = 0; j < s; j++)
          acc += kDopA[s][j] * K[j][i];
        z[i] = y[i] + dir * hs * acc;
      }
      K[s] = fn(t + dir * kDopC[s] * hs, z);
    }
    for (size_t i = 0; i < n; i++) {
      cd acc = 0.0;
      for (int j = 0; j < 12; j++)
        acc += kDopB[j] * K[j][i];
      ynew[i] = y[i] + dir * hs * acc;
    }
    K[12] = fn(t + dir * hs, ynew);
    double err5 = 0.0, err3 = 0.0;
    for (size_t i = 0; i < n; i++) {
      cd e5 = 0.0, e3 = 0.0;
      for (int j = 0; j < 13; j++) {
        e5 += kDopE5[j] * K[j][i];
        e3 += kDopE3[j] * K[j][i];
      }
      const double sc = atol + rtol * std::max(std::abs(y[i]), std::abs(ynew[i]));
      err5 += std::norm(e5 / sc);
      err3 += std::norm(e3 / sc);
    }
    if (err5 == 0.0 && err3 == 0.0)
      err5 = 0.0;
    double denom = err5 + 0.01 * err3;
    const double en = denom > 0.0 ? hs * err5 / std::sqrt(denom * static_cast<double>(n)) : 0.0;
    if (en < 1.0) {
      t += dir * hs;
      y = ynew;
      K[0] = K[12];
      f = K[0];
      if (tr)
        tr->add(t, y, f);
      h = hs * (en == 0.0 ? 10.0 : std::min(10.0, 0.9 * std::pow(en, -1.0 / 8.0)));
    } else {
      h = hs * std::max(0.2, 0.9 * std::pow(en, -1.0 / 8.0));
    }
  }
}

Mat numJac(OdeFn &fn, double t, const CVec &y, const CVec &f0) {
  const size_t n = y.size();
  Mat J(n, n);
  CVec u = y;
  for (size_t j = 0; j < n; j++) {
    const double h = std::sqrt(kEps) * std::max(1e-6, std::abs(y[j]));
    u[j] = y[j] + h;
    CVec f1 = fn(t, u);
    for (size_t i = 0; i < n; i++)
      J(i, j) = (f1[i] - f0[i]).real() / h;
    u[j] = y[j];
  }
  return J;
}

// Radau IIA order 5, with Newton on the full 3n system.
void radau(OdeFn &fn, double &t, double tEnd, CVec &yc, CVec &fc, double rtol, double atol, Trajectory *tr, double h0) {
  const size_t n = yc.size();
  const double s6 = std::sqrt(6.0);
  const double C[3] = {(4.0 - s6) / 10.0, (4.0 + s6) / 10.0, 1.0};
  const double A[3][3] = {{(88.0 - 7.0 * s6) / 360.0, (296.0 - 169.0 * s6) / 1800.0, (-2.0 + 3.0 * s6) / 225.0},
                          {(296.0 + 169.0 * s6) / 1800.0, (88.0 + 7.0 * s6) / 360.0, (-2.0 - 3.0 * s6) / 225.0},
                          {(16.0 - s6) / 36.0, (16.0 + s6) / 36.0, 1.0 / 9.0}};
  const double dir = tEnd >= t ? 1.0 : -1.0;
  double h = h0 > 0.0 ? h0 : firstStep(fn, t, yc, fc, dir, 5, rtol, atol);
  Mat J = numJac(fn, t, yc, fc);
  long steps = 0;
  while (dir * (tEnd - t) > 0.0 && !fn.fn.failed && ++steps < 500000) {
    const double hs = std::min(h, std::fabs(tEnd - t)) * dir;
    // Stage increments Z; Newton with the matrix I - h A kron J.
    Mat M(3 * n, 3 * n);
    for (size_t i = 0; i < 3 * n; i++)
      M(i, i) = 1.0;
    for (int p = 0; p < 3; p++)
      for (int q = 0; q < 3; q++)
        for (size_t i = 0; i < n; i++)
          for (size_t j = 0; j < n; j++)
            M(p * n + i, q * n + j) -= hs * A[p][q] * J(i, j);
    std::vector<size_t> piv;
    la::luFactor(M, piv);
    Vec Z(3 * n, 0.0);
    bool ok = false;
    double prev = kInf;
    for (int it = 0; it < 12; it++) {
      Vec F(3 * n);
      std::vector<CVec> stage(3, CVec(n));
      for (int p = 0; p < 3; p++) {
        CVec u(n);
        for (size_t i = 0; i < n; i++)
          u[i] = yc[i] + Z[p * n + i];
        stage[p] = fn(t + C[p] * hs, u);
      }
      for (int p = 0; p < 3; p++)
        for (size_t i = 0; i < n; i++) {
          double s = Z[p * n + i];
          for (int q = 0; q < 3; q++)
            s -= hs * A[p][q] * stage[q][i].real();
          F[p * n + i] = -s;
        }
      Mat R(3 * n, 1);
      R.a = F;
      la::luSolveInPlace(M, piv, R);
      double nrm = 0.0;
      for (size_t i = 0; i < 3 * n; i++) {
        Z[i] += R.a[i];
        const double sc = atol + rtol * std::abs(yc[i % n]);
        nrm += (R.a[i] / sc) * (R.a[i] / sc);
      }
      nrm = std::sqrt(nrm / (3.0 * n));
      if (nrm == 0.0 || nrm < 1e-3) {
        ok = true;
        break;
      }
      if (it > 1 && nrm > 2.0 * prev)
        break;
      prev = nrm;
    }
    if (!ok) {
      h = std::fabs(hs) * 0.5;
      J = numJac(fn, t, yc, fc);
      if (h < 1e-14 * std::max(1.0, std::fabs(t))) {
        fn.fn.failed = true;
        return;
      }
      continue;
    }
    CVec ynew(n);
    for (size_t i = 0; i < n; i++)
      ynew[i] = yc[i] + Z[2 * n + i];
    // Error estimate of Hairer & Wanner.
    const double e0 = (-13.0 - 7.0 * s6) / 3.0, e1 = (-13.0 + 7.0 * s6) / 3.0, e2 = -1.0 / 3.0;
    Mat E(n, n);
    const double gamma = 3.0 + std::cbrt(9.0) - std::cbrt(3.0);
    for (size_t i = 0; i < n; i++) {
      E(i, i) = gamma / hs;
      for (size_t j = 0; j < n; j++)
        E(i, j) -= J(i, j);
    }
    Mat rhs(n, 1);
    for (size_t i = 0; i < n; i++)
      rhs(i, 0) = fc[i].real() + (e0 * Z[i] + e1 * Z[n + i] + e2 * Z[2 * n + i]) / hs * 1.0;
    Mat err = rhs;
    la::solve(E, err);
    CVec ec(n);
    for (size_t i = 0; i < n; i++)
      ec[i] = err.a[i];
    const double en = errNorm(ec, yc, ynew, rtol, atol);
    if (en < 1.0) {
      t += hs;
      yc = ynew;
      fc = fn(t, yc);
      if (tr)
        tr->add(t, yc, fc);
      J = numJac(fn, t, yc, fc);
      h = std::fabs(hs) * std::min(5.0, en == 0.0 ? 5.0 : std::max(0.2, 0.9 * std::pow(en, -0.25)));
    } else {
      h = std::fabs(hs) * std::max(0.2, 0.9 * std::pow(en, -0.25));
    }
  }
}

// Variable-step BDF with the fixed-leading-coefficient difference table (orders 1 to 5).
void bdf(OdeFn &fn, double &t, double tEnd, CVec &yc, CVec &fc, double rtol, double atol, Trajectory *tr) {
  const size_t n = yc.size();
  const double dir = tEnd >= t ? 1.0 : -1.0;
  const double kappa[6] = {0, -0.1850, -1.0 / 9.0, -0.0823, -0.0415, 0};
  double gam[7];
  double alpha[6], errc[6];
  gam[0] = 0.0;
  double hs = 0.0;
  for (int i = 1; i <= 5; i++) {
    hs += 1.0 / i;
    gam[i] = hs;
  }
  for (int i = 0; i < 6; i++) {
    alpha[i] = (1.0 - kappa[i]) * gam[i];
    errc[i] = kappa[i] * gam[i] + 1.0 / (i + 1.0);
  }
  double h = firstStep(fn, t, yc, fc, dir, 1, rtol, atol);
  std::vector<Vec> D(8, Vec(n, 0.0));
  for (size_t i = 0; i < n; i++) {
    D[0][i] = yc[i].real();
    D[1][i] = fc[i].real() * h * dir;
  }
  int order = 1, equal = 0;
  Mat J = numJac(fn, t, yc, fc);
  auto changeStep = [&](double factor) {
    // Re-scales the differences to a new step (the R and U matrices of SciPy's BDF).
    auto mat = [&](double f) {
      Mat M(order + 1, order + 1);
      for (int j = 0; j <= order; j++)
        M(0, j) = 1.0;
      for (int i = 1; i <= order; i++)
        for (int j = 1; j <= order; j++)
          M(i, j) = M(i - 1, j) * (i - 1 - f * j) / i;
      return M;
    };
    Mat RU = mul(mat(factor), mat(1.0));
    std::vector<Vec> nd(order + 1, Vec(n, 0.0));
    for (int i = 0; i <= order; i++)
      for (int j = 0; j <= order; j++)
        for (size_t k = 0; k < n; k++)
          nd[i][k] += RU(j, i) * D[j][k];
    for (int i = 0; i <= order; i++)
      D[i] = nd[i];
  };
  long steps = 0;
  while (dir * (tEnd - t) > 0.0 && !fn.fn.failed && ++steps < 1000000) {
    if (h > std::fabs(tEnd - t)) {
      changeStep(std::fabs(tEnd - t) / h);
      h = std::fabs(tEnd - t);
      equal = 0;
    }
    const double hd = h * dir, tn = t + hd;
    Vec pred(n, 0.0), psi(n, 0.0);
    for (int i = 0; i <= order; i++)
      for (size_t k = 0; k < n; k++)
        pred[k] += D[i][k];
    for (int i = 1; i <= order; i++)
      for (size_t k = 0; k < n; k++)
        psi[k] += D[i][k] * gam[i] / alpha[order];
    const double c = hd / alpha[order];
    Mat M(n, n);
    for (size_t i = 0; i < n; i++) {
      M(i, i) = 1.0;
      for (size_t j = 0; j < n; j++)
        M(i, j) -= c * J(i, j);
    }
    std::vector<size_t> piv;
    la::luFactor(M, piv);
    Vec dvec(n, 0.0), y = pred;
    bool conv = false;
    double dprev = kInf;
    for (int it = 0; it < 6; it++) {
      CVec u = toComplex(y);
      CVec fy = fn(tn, u);
      Mat R(n, 1);
      for (size_t k = 0; k < n; k++)
        R(k, 0) = c * fy[k].real() - psi[k] - dvec[k];
      la::luSolveInPlace(M, piv, R);
      double nrm = 0.0;
      for (size_t k = 0; k < n; k++) {
        dvec[k] += R.a[k];
        y[k] += R.a[k];
        const double sc = atol + rtol * std::fabs(pred[k]);
        nrm += (R.a[k] / sc) * (R.a[k] / sc);
      }
      nrm = std::sqrt(nrm / n);
      if (nrm == 0.0 || nrm < 0.01) {
        conv = true;
        break;
      }
      if (it > 0 && nrm > dprev)
        break;
      dprev = nrm;
    }
    if (!conv) {
      changeStep(0.5);
      h *= 0.5;
      equal = 0;
      J = numJac(fn, t, yc, fc);
      if (h < 1e-14 * std::max(1.0, std::fabs(t))) {
        fn.fn.failed = true;
        return;
      }
      continue;
    }
    double en = 0.0;
    Vec scale(n);
    for (size_t k = 0; k < n; k++) {
      scale[k] = atol + rtol * std::max(std::fabs(D[0][k]), std::fabs(y[k]));
      const double e = errc[order] * dvec[k] / scale[k];
      en += e * e;
    }
    en = std::sqrt(en / n);
    if (en >= 1.0) {
      const double f = std::max(0.2, 0.9 * std::pow(en, -1.0 / (order + 1.0)));
      changeStep(f);
      h *= f;
      equal = 0;
      continue;
    }
    t = tn;
    for (size_t k = 0; k < n; k++)
      D[order + 2][k] = dvec[k] - D[order + 1][k];
    D[order + 1] = dvec;
    for (int i = order; i >= 0; i--)
      for (size_t k = 0; k < n; k++)
        D[i][k] += D[i + 1][k];
    yc = toComplex(D[0]);
    fc = fn(t, yc);
    if (tr)
      tr->add(t, yc, fc);
    J = numJac(fn, t, yc, fc);
    equal++;
    if (equal < order + 1)
      continue;
    // Choose the order with the largest possible step.
    double em = kInf, ep = kInf;
    if (order > 1) {
      em = 0.0;
      for (size_t k = 0; k < n; k++) {
        const double e = errc[order - 1] * D[order][k] / scale[k];
        em += e * e;
      }
      em = std::sqrt(em / n);
    }
    if (order < 5) {
      ep = 0.0;
      for (size_t k = 0; k < n; k++) {
        const double e = errc[order + 1] * D[order + 2][k] / scale[k];
        ep += e * e;
      }
      ep = std::sqrt(ep / n);
    }
    double fm = em == kInf ? 0.0 : (em == 0.0 ? 10.0 : std::pow(em, -1.0 / order));
    double fs = en == 0.0 ? 10.0 : std::pow(en, -1.0 / (order + 1.0));
    double fp = ep == kInf ? 0.0 : (ep == 0.0 ? 10.0 : std::pow(ep, -1.0 / (order + 2.0)));
    double best = std::max(fs, std::max(fm, fp));
    if (fm == best)
      order--;
    else if (fp == best)
      order++;
    double factor = std::min(10.0, 0.9 * best);
    changeStep(factor);
    h *= factor;
    equal = 0;
  }
}

// Non-stiff first, implicit from the point where stiffness shows.
void lsoda(OdeFn &fn, double &t, double tEnd, CVec &y, CVec &f, double rtol, double atol, Trajectory *tr) {
  double h = 0.0;
  if (explicitRK(fn, rk45(), t, tEnd, y, f, rtol, atol, tr, true, h) || fn.fn.failed)
    return;
  radau(fn, t, tEnd, y, f, rtol, atol, tr, h);
}

bool dispatch(const std::string &method, OdeFn &fn, double &t, double tEnd, CVec &y, CVec &f, double rtol, double atol, Trajectory *tr) {
  double h = 0.0;
  if (method == "RK45")
    explicitRK(fn, rk45(), t, tEnd, y, f, rtol, atol, tr, false, h);
  else if (method == "RK23")
    explicitRK(fn, rk23(), t, tEnd, y, f, rtol, atol, tr, false, h);
  else if (method == "DOP853")
    dop853(fn, t, tEnd, y, f, rtol, atol, tr);
  else if (method == "Radau")
    radau(fn, t, tEnd, y, f, rtol, atol, tr, 0.0);
  else if (method == "BDF")
    bdf(fn, t, tEnd, y, f, rtol, atol, tr);
  else if (method == "LSODA")
    lsoda(fn, t, tEnd, y, f, rtol, atol, tr);
  else
    return false;
  return true;
}

Value trajU(const Trajectory &tr, bool cplx) {
  const size_t n = tr.u.empty() ? 0 : tr.u[0].size();
  CMat U(n, tr.t.size());
  for (size_t j = 0; j < tr.t.size(); j++)
    for (size_t i = 0; i < n; i++)
      U(i, j) = cplx ? tr.u[j][i] : cd(tr.u[j][i].real(), 0.0);
  return cplx ? toValue(U) : realIfPossible(U);
}

} // namespace

void registerOdeSolvers(Registry &reg) {
  SP_ADD("ode_solve", 3, 7, "fn, t_span, u0, method=\"RK45\", dense=0, rtol=1e-6, atol=1e-9") {
    Vec span;
    CVec u0;
    if (!isCallable(a[0]) || !getVec(a, 1, ctx, span) || !getCVec(a, 2, ctx, u0)) {
      if (ctx.ok())
        ctx.fail("the first argument must name a function f(t, u)");
      return Value(0.0);
    }
    if (span.size() != 2 || u0.empty()) {
      ctx.fail("t_span must be [t0, t1] and u0 must not be empty");
      return Value(0.0);
    }
    const std::string method = optText(a, 3, "RK45");
    const bool dense = optBool(a, 4, false);
    const double rtol = optNum(a, 5, 1e-6), atol = optNum(a, 6, 1e-9);
    const bool cplx = a[2].hasComplex();
    if (cplx && (method == "Radau" || method == "BDF" || method == "LSODA")) {
      ctx.fail("complex values need an explicit method (\"RK45\", \"RK23\" or \"DOP853\")");
      return Value(0.0);
    }
    OdeFn fn(a[0], cplx, false, u0.size());
    Trajectory tr;
    double t = span[0];
    CVec y = u0, f = fn(t, y);
    tr.add(t, y, f);
    if (!dispatch(method, fn, t, span[1], y, f, rtol, atol, &tr)) {
      ctx.fail("method must be \"RK45\", \"RK23\", \"DOP853\", \"Radau\", \"BDF\" or \"LSODA\"");
      return Value(0.0);
    }
    if (fn.fn.failed) {
      ctx.fail(fn.fn.failText());
      return Value(0.0);
    }
    DictInit out{{"t", toValue(tr.t)}, {"u", trajU(tr, fn.cplx)}, {"success", Value::boolean(std::fabs(t - span[1]) <= 1e-12 * std::max(1.0, std::fabs(span[1])))}};
    if (dense) {
      const size_t n = u0.size();
      CMat F(n, tr.t.size());
      for (size_t j = 0; j < tr.t.size(); j++)
        for (size_t i = 0; i < n; i++)
          F(i, j) = tr.f[j][i];
      out.push_back({"f", fn.cplx ? toValue(F) : realIfPossible(F)});
    }
    return makeDict(out);
  } SP_ENDC
  SP_ADD("ode_eval", 2, 2, "sol, t") {
    const Value *tv = dictGet(a[0], "t"), *uv = dictGet(a[0], "u"), *fv = dictGet(a[0], "f");
    Vec ts, q;
    CMat U, F;
    if (!tv || !uv || !fv || !readVec(*tv, ts) || !readCMat(*uv, U) || !readCMat(*fv, F)) {
      ctx.fail("the first argument must come from ode_solve() with dense = 1");
      return Value(0.0);
    }
    if (!getVec(a, 1, ctx, q))
      return Value(0.0);
    const size_t n = U.r;
    CMat out(n, q.size());
    const bool up = ts.size() < 2 || ts.back() >= ts.front();
    for (size_t k = 0; k < q.size(); k++) {
      // Cubic Hermite on the step holding q[k].
      size_t j = 0;
      for (size_t lo = 0, hi = ts.size() - 1; hi - lo > 1;) {
        const size_t mid = (lo + hi) / 2;
        if (up ? ts[mid] <= q[k] : ts[mid] >= q[k])
          lo = mid;
        else
          hi = mid;
        j = lo;
      }
      if (ts.size() < 2) {
        for (size_t i = 0; i < n; i++)
          out(i, k) = U(i, 0);
        continue;
      }
      const double h = ts[j + 1] - ts[j], s = (q[k] - ts[j]) / h;
      const double h00 = (1 + 2 * s) * (1 - s) * (1 - s), h10 = s * (1 - s) * (1 - s), h01 = s * s * (3 - 2 * s), h11 = s * s * (s - 1);
      for (size_t i = 0; i < n; i++)
        out(i, k) = h00 * U(i, j) + h10 * h * F(i, j) + h01 * U(i, j + 1) + h11 * h * F(i, j + 1);
    }
    if (n == 1) {
      CVec v(out.a);
      return v.size() == 1 ? scalarOf(v[0]) : realIfPossible(v);
    }
    if (q.size() == 1) {
      CVec v(out.a);
      return realIfPossible(v);
    }
    return realIfPossible(out);
  } SP_ENDC
  SP_ADD("odeint", 3, 5, "fn, u0, t, rtol=1.5e-8, atol=1.5e-8") {
    CVec u0;
    Vec ts;
    if (!isCallable(a[0]) || !getCVec(a, 1, ctx, u0) || !getVec(a, 2, ctx, ts)) {
      if (ctx.ok())
        ctx.fail("the first argument must name a function f(u, t)");
      return Value(0.0);
    }
    const double rtol = optNum(a, 3, 1.49012e-8), atol = optNum(a, 4, 1.49012e-8);
    OdeFn fn(a[0], false, true, u0.size());
    Mat out(ts.size(), u0.size());
    CVec y = u0;
    double t = ts.empty() ? 0.0 : ts[0];
    CVec f = fn(t, y);
    for (size_t k = 0; k < ts.size(); k++) {
      if (k > 0)
        lsoda(fn, t, ts[k], y, f, rtol, atol, nullptr);
      if (fn.fn.failed) {
        ctx.fail(fn.fn.failText());
        return Value(0.0);
      }
      for (size_t i = 0; i < y.size(); i++)
        out(k, i) = y[i].real();
    }
    return toValue(out);
  } SP_END
  SP_ADD("bvp_solve", 4, 5, "fn, bc, t, u_guess, tol=1e-6") {
    // Simpson-Lobatto collocation on the mesh, Newton with a finite-difference
    // Jacobian, and midpoints added where the residual stays large.
    Vec mesh;
    Mat guess;
    if (!isCallable(a[0]) || !isCallable(a[1]) || !getVec(a, 2, ctx, mesh) || !getMat(a, 3, ctx, guess)) {
      if (ctx.ok())
        ctx.fail("fn and bc must name NC functions");
      return Value(0.0);
    }
    if (guess.c != mesh.size() || mesh.size() < 2) {
      ctx.fail("u_guess must have one column per mesh point");
      return Value(0.0);
    }
    const double tol = optNum(a, 4, 1e-6);
    const size_t n = guess.r;
    NcFn fnF(a[0]), fnB(a[1]);
    auto F = [&](double t, const Vec &u) {
      Value out = fnF.raw({Value(t), toValue(u)});
      Vec v;
      if (fnF.failed || !readVec(out, v) || v.size() != n) {
        fnF.failed = true;
        return Vec(n, kNaN);
      }
      return v;
    };
    Vec U = transposeOf(guess).a; // point by point
    bool success = false;
    double rmsMax = 0.0;
    for (int refine = 0; refine < 8 && !fnF.failed && !fnB.failed; refine++) {
      const size_t m = mesh.size();
      auto resid = [&](const Vec &Y) {
        Vec R(n * m);
        std::vector<Vec> f(m);
        for (size_t j = 0; j < m; j++)
          f[j] = F(mesh[j], Vec(Y.begin() + j * n, Y.begin() + (j + 1) * n));
        for (size_t j = 0; j + 1 < m; j++) {
          const double h = mesh[j + 1] - mesh[j];
          Vec um(n);
          for (size_t i = 0; i < n; i++)
            um[i] = 0.5 * (Y[j * n + i] + Y[(j + 1) * n + i]) - h / 8.0 * (f[j + 1][i] - f[j][i]);
          Vec fm = F(0.5 * (mesh[j] + mesh[j + 1]), um);
          for (size_t i = 0; i < n; i++)
            R[j * n + i] = Y[(j + 1) * n + i] - Y[j * n + i] - h / 6.0 * (f[j][i] + 4.0 * fm[i] + f[j + 1][i]);
        }
        Value bv = fnB.raw({toValue(Vec(Y.begin(), Y.begin() + n)), toValue(Vec(Y.end() - n, Y.end()))});
        Vec b;
        if (fnB.failed || !readVec(bv, b) || b.size() != n) {
          fnB.failed = true;
          b.assign(n, kNaN);
        }
        for (size_t i = 0; i < n; i++)
          R[(m - 1) * n + i] = b[i];
        return R;
      };
      for (int it = 0; it < 12 && !fnF.failed && !fnB.failed; it++) {
        Vec R = resid(U);
        double rn = 0.0;
        for (double v : R)
          rn = std::max(rn, std::fabs(v));
        if (rn < 1e-12)
          break;
        Mat J(R.size(), R.size());
        for (size_t c = 0; c < U.size(); c++) {
          Vec P = U;
          const double step = std::sqrt(kEps) * std::max(1e-3, std::fabs(U[c]));
          P[c] += step;
          Vec R2 = resid(P);
          for (size_t i = 0; i < R.size(); i++)
            J(i, c) = (R2[i] - R[i]) / step;
        }
        if (!la::solveVec(J, R))
          break;
        double dn = 0.0;
        for (size_t i = 0; i < U.size(); i++) {
          U[i] -= R[i];
          dn = std::max(dn, std::fabs(R[i]));
        }
        if (dn < 1e-13 * (1.0 + rn))
          break;
      }
      // Residual of the Hermite interpolant at the 2/3-style points of each interval.
      Vec nm;
      Vec nu;
      rmsMax = 0.0;
      bool refined = false;
      std::vector<Vec> f(m);
      for (size_t j = 0; j < m; j++)
        f[j] = F(mesh[j], Vec(U.begin() + j * n, U.begin() + (j + 1) * n));
      for (size_t j = 0; j < m; j++) {
        nm.push_back(mesh[j]);
        nu.insert(nu.end(), U.begin() + j * n, U.begin() + (j + 1) * n);
        if (j + 1 == m)
          break;
        const double h = mesh[j + 1] - mesh[j];
        Vec um(n), dum(n);
        for (size_t i = 0; i < n; i++) {
          um[i] = 0.5 * (U[j * n + i] + U[(j + 1) * n + i]) + h / 8.0 * (f[j][i] - f[j + 1][i]);
          dum[i] = 1.5 * (U[(j + 1) * n + i] - U[j * n + i]) / h - 0.25 * (f[j][i] + f[j + 1][i]);
        }
        Vec fm = F(mesh[j] + h / 2.0, um);
        double r = 0.0;
        for (size_t i = 0; i < n; i++) {
          const double e = (dum[i] - fm[i]) / (1.0 + std::fabs(fm[i]));
          r = std::max(r, std::fabs(e));
        }
        rmsMax = std::max(rmsMax, r);
        if (r > tol && mesh.size() < 2000) {
          refined = true;
          nm.push_back(mesh[j] + h / 2.0);
          nu.insert(nu.end(), um.begin(), um.end());
        }
      }
      if (!refined) {
        success = true;
        break;
      }
      mesh = nm;
      U = nu;
    }
    if (fnF.failed || fnB.failed) {
      ctx.fail((fnF.failed ? fnF : fnB).failText());
      return Value(0.0);
    }
    Mat Uo(n, mesh.size());
    for (size_t j = 0; j < mesh.size(); j++)
      for (size_t i = 0; i < n; i++)
        Uo(i, j) = U[j * n + i];
    return makeDict({{"t", toValue(mesh)}, {"u", toValue(Uo)}, {"success", Value::boolean(success)}, {"rms_residual", Value(rmsMax)}});
  } SP_END
}

} // namespace scipy
} // namespace nc
