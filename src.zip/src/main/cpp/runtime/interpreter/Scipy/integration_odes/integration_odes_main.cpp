// Section 7 of 25 - Integration & ODEs (scipy.integrate). trapz already exists in Numpy/.
#include "integration_odes_main.h"

#include <array>
#include <functional>

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "io_tables.h"

#define SP_SEC Section::IntegrationOdes

namespace nc {
namespace scipy {

void registerOdeSolvers(Registry &reg);

namespace {

// Gauss-Kronrod 7-15 nodes and weights.
const double kXgk[8] = {0.991455371120812639206854697526329, 0.949107912342758524526189684047851,
                        0.864864423359769072789712788640926, 0.741531185599394439863864773280788,
                        0.586087235467691130294144838258730, 0.405845151377397166906606412076961,
                        0.207784955007898467600689403773245, 0.0};
const double kWgk[8] = {0.022935322010529224963732008058970, 0.063092092629978553290700663189204,
                        0.104790010322250183839876322541518, 0.140653259715525918998541745705333,
                        0.169004726639267902826583426073666, 0.190350578064785409913256402275915,
                        0.204432940075298892414161999234649, 0.209482141084727828012999174351913};
const double kWg[4] = {0.129484966168869693270611432679082, 0.279705391489276667901467771423780,
                       0.381830050505118944950369775488975, 0.417959183673469387755102040816327};

using ScalarFn = std::function<double(double)>;

// Adaptive G7-K15 over one finite interval, splitting the worst part (like QUADPACK).
void adaptive(const ScalarFn &f, double a, double b, double epsabs, double epsrel, int limit, double &value, double &error, const std::function<bool()> &stop) {
  struct Part {
    double a, b, v, e;
  };
  auto rule = [&](double lo, double hi) {
    const double c = 0.5 * (lo + hi), h = 0.5 * (hi - lo);
    const double fc = f(c);
    double rk = kWgk[7] * fc, rg = kWg[3] * fc;
    for (int i = 0; i < 7; i++) {
      const double dx = h * kXgk[i];
      const double s = f(c - dx) + f(c + dx);
      rk += kWgk[i] * s;
      if (i % 2 == 1)
        rg += kWg[i / 2] * s;
    }
    Part p{lo, hi, rk * h, std::fabs((rk - rg) * h)};
    return p;
  };
  std::vector<Part> parts{rule(a, b)};
  for (int it = 0; it < limit && !stop(); it++) {
    double v = 0.0, e = 0.0;
    size_t worst = 0;
    for (size_t i = 0; i < parts.size(); i++) {
      v += parts[i].v;
      e += parts[i].e;
      if (parts[i].e > parts[worst].e)
        worst = i;
    }
    value = v;
    error = e;
    if (e <= std::max(epsabs, epsrel * std::fabs(v)))
      return;
    Part w = parts[worst];
    const double m = 0.5 * (w.a + w.b);
    parts[worst] = rule(w.a, m);
    parts.push_back(rule(m, w.b));
  }
  value = 0.0;
  error = 0.0;
  for (const Part &p : parts) {
    value += p.v;
    error += p.e;
  }
}

// Maps infinite limits onto a finite range: x = t / (1 - t^2) style.
void quad(const ScalarFn &f, double a, double b, double epsabs, double epsrel, double &value, double &error, const std::function<bool()> &stop, int limit = 200) {
  if (a == b) {
    value = error = 0.0;
    return;
  }
  double sign = 1.0;
  if (a > b) {
    std::swap(a, b);
    sign = -1.0;
  }
  if (std::isinf(a) && std::isinf(b)) {
    adaptive([&](double t) {
      if (std::fabs(t) >= 1.0) return 0.0;
      const double d = 1.0 - t * t, x = t / d;
      const double v = f(x) * (1.0 + t * t) / (d * d);
      return std::isfinite(v) ? v : 0.0;
    }, -1.0, 1.0, epsabs, epsrel, limit, value, error, stop);
  } else if (std::isinf(b)) {
    adaptive([&](double t) {
      if (t >= 1.0) return 0.0;
      const double v = f(a + t / (1.0 - t)) / ((1.0 - t) * (1.0 - t));
      return std::isfinite(v) ? v : 0.0;
    }, 0.0, 1.0, epsabs, epsrel, limit, value, error, stop);
  } else if (std::isinf(a)) {
    adaptive([&](double t) {
      if (t >= 1.0) return 0.0;
      const double v = f(b - t / (1.0 - t)) / ((1.0 - t) * (1.0 - t));
      return std::isfinite(v) ? v : 0.0;
    }, 0.0, 1.0, epsabs, epsrel, limit, value, error, stop);
  } else {
    adaptive(f, a, b, epsabs, epsrel, limit, value, error, stop);
  }
  value *= sign;
}

// Gauss-Legendre nodes by Newton on the Legendre recurrence.
void gaussLegendre(int n, Vec &x, Vec &w) {
  x.resize(n);
  w.resize(n);
  for (int i = 0; i < n; i++) {
    double z = std::cos(kPi * (i + 0.75) / (n + 0.5)), pp = 1.0;
    for (int it = 0; it < 100; it++) {
      double p1 = 1.0, p2 = 0.0;
      for (int j = 0; j < n; j++) {
        const double p3 = p2;
        p2 = p1;
        p1 = ((2.0 * j + 1.0) * z * p2 - j * p3) / (j + 1.0);
      }
      pp = n * (z * p1 - p2) / (z * z - 1.0);
      const double dz = p1 / pp;
      z -= dz;
      if (std::fabs(dz) < 1e-15)
        break;
    }
    x[i] = -z;
    w[i] = 2.0 / ((1.0 - z * z) * pp * pp);
  }
}

// Tanh-sinh with doubling levels until two levels agree.
void tanhSinh(const ScalarFn &f, double a, double b, double tol, double &value, double &error, const std::function<bool()> &stop) {
  const double c = 0.5 * (b - a), d = 0.5 * (b + a);
  double h = 1.0, prev = 0.0;
  auto term = [&](double t) {
    const double u = 0.5 * kPi * std::sinh(t), ch = std::cosh(u);
    const double xc = std::tanh(u); // abscissa
    const double wgt = 0.5 * kPi * std::cosh(t) / (ch * ch);
    // Distance to the end point, kept accurate near the singular ends.
    const double comp = 1.0 / (std::exp(2.0 * std::fabs(u)) + 1.0) * 2.0; // 1 - |x|
    const double x = xc >= 0 ? b - c * comp : a + c * comp;
    if (!(x > a && x < b) || wgt == 0.0)
      return 0.0;
    const double v = f(x);
    return std::isfinite(v) ? wgt * v : 0.0;
  };
  double sum = term(0.0);
  for (double t = h; t < 6.5; t += h)
    sum += term(t) + term(-t);
  prev = c * h * sum;
  value = prev;
  error = kInf;
  for (int lev = 1; lev < 12 && !stop(); lev++) {
    h *= 0.5;
    for (double t = h; t < 6.5; t += 2.0 * h)
      sum += term(t) + term(-t);
    value = c * h * sum;
    error = std::fabs(value - prev);
    if (error <= tol * std::max(1.0, std::fabs(value)))
      break;
    prev = value;
  }
  (void)d;
}

// Newton-Cotes weights on n+1 equally spaced points, by solving the moment system
// exactly in long double; the error constant follows SciPy's formula.
void newtonCotes(int n, Vec &w, double &err) {
  using Ld = long double;
  std::vector<std::vector<Ld>> M(n + 1, std::vector<Ld>(n + 2));
  for (int i = 0; i <= n; i++) {
    // Row i: sum w_j j^i = n^(i+1) / (i+1)
    for (int j = 0; j <= n; j++)
      M[i][j] = (i == 0) ? 1.0L : std::pow(static_cast<Ld>(j), static_cast<Ld>(i));
    M[i][n + 1] = std::pow(static_cast<Ld>(n), static_cast<Ld>(i + 1)) / static_cast<Ld>(i + 1);
  }
  for (int k = 0; k <= n; k++) {
    int p = k;
    for (int i = k + 1; i <= n; i++)
      if (std::fabs(M[i][k]) > std::fabs(M[p][k]))
        p = i;
    std::swap(M[k], M[p]);
    for (int i = 0; i <= n; i++) {
      if (i == k)
        continue;
      const Ld f = M[i][k] / M[k][k];
      for (int j = k; j <= n + 1; j++)
        M[i][j] -= f * M[k][j];
    }
  }
  w.resize(n + 1);
  for (int i = 0; i <= n; i++)
    w[i] = static_cast<double>(M[i][n + 1] / M[i][i]);
  // E = integral of the next moment minus the rule, in the normalised variable.
  const int p1 = (n % 2 == 0) ? n + 3 : n + 2;
  Ld mom = std::pow(static_cast<Ld>(n), static_cast<Ld>(p1)) / static_cast<Ld>(p1), rule = 0.0L;
  for (int j = 0; j <= n; j++)
    rule += static_cast<Ld>(w[j]) * std::pow(static_cast<Ld>(j), static_cast<Ld>(p1 - 1));
  Ld fact = 1.0L;
  for (int i = 2; i <= p1 - 1; i++)
    fact *= i;
  err = static_cast<double>((mom - rule) / fact);
}

// Halton sequence for the quasi-Monte Carlo rule.
double radicalInverse(unsigned long i, int base) {
  double f = 1.0, r = 0.0;
  while (i > 0) {
    f /= base;
    r += f * static_cast<double>(i % base);
    i /= base;
  }
  return r;
}

// Recursive tensor Gauss-Kronrod over a box: one level of the quad per variable.
struct BoxInt {
  const std::function<double(const Vec &)> &f;
  const std::function<bool()> &stop;
  double epsabs, epsrel;
  Vec lo, hi, x;
  double run(size_t dim, double &err) {
    if (dim == x.size())
      return f(x);
    double v = 0.0, e = 0.0, innerErr = 0.0;
    quad([&](double t) {
      x[dim] = t;
      double ie = 0.0;
      double r = run(dim + 1, ie);
      innerErr = std::max(innerErr, ie);
      return r;
    }, lo[dim], hi[dim], epsabs, epsrel, v, e, stop, 40);
    err = e + innerErr;
    return v;
  }
};

bool getFn(const Args &a, size_t i, CallContext &ctx) {
  if (i >= a.size() || !isCallable(a[i])) {
    ctx.fail("the " + ordinal(i) + " argument must name an NC function, e.g. \"f\" or @f");
    return false;
  }
  return true;
}

Vec cumTrap(const Vec &y, const Vec &x, double dx) {
  Vec c;
  double s = 0.0;
  for (size_t i = 1; i < y.size(); i++) {
    const double h = x.empty() ? dx : x[i] - x[i - 1];
    s += 0.5 * h * (y[i] + y[i - 1]);
    c.push_back(s);
  }
  return c;
}

// Simpson over any spacing; an even number of points takes the last-interval
// correction of Cartwright, as SciPy does.
double simpsonEven(const double *y, const double *h, size_t intervals) {
  double s = 0.0;
  for (size_t i = 0; i + 1 < intervals; i += 2) {
    const double h0 = h[i], h1 = h[i + 1], hs = h0 + h1;
    s += hs / 6.0 * ((2.0 - h1 / h0) * y[i] + hs * hs / (h0 * h1) * y[i + 1] + (2.0 - h0 / h1) * y[i + 2]);
  }
  return s;
}
double simpson(const Vec &y, const Vec &x, double dx) {
  const size_t n = y.size();
  if (n < 2)
    return 0.0;
  Vec h(n - 1);
  for (size_t i = 0; i + 1 < n; i++)
    h[i] = x.empty() ? dx : x[i + 1] - x[i];
  if (n == 2)
    return 0.5 * h[0] * (y[0] + y[1]);
  if (n % 2 == 1)
    return simpsonEven(y.data(), h.data(), n - 1);
  double s = simpsonEven(y.data(), h.data(), n - 2);
  const double h0 = h[n - 3], h1 = h[n - 2];
  const double al = (2.0 * h1 * h1 + 3.0 * h0 * h1) / (6.0 * (h0 + h1));
  const double be = (h1 * h1 + 3.0 * h1 * h0) / (6.0 * h0);
  const double et = h1 * h1 * h1 / (6.0 * h0 * (h0 + h1));
  return s + al * y[n - 1] + be * y[n - 2] - et * y[n - 3];
}

// Running Simpson, one parabola per pair of intervals as scipy's cumulative_simpson.
Vec cumSimpson(const Vec &y, const Vec &x, double dx) {
  const size_t n = y.size();
  Vec out;
  if (n < 2)
    return out;
  Vec h(n - 1);
  for (size_t i = 0; i + 1 < n; i++)
    h[i] = x.empty() ? dx : x[i + 1] - x[i];
  if (n == 2)
    return {0.5 * h[0] * (y[0] + y[1])};
  // Integral of the parabola through i-1, i, i+1 over each sub-interval.
  Vec sub(n - 1);
  for (size_t i = 0; i + 2 < n; i += 2) {
    const double a0 = h[i], a1 = h[i + 1], s = a0 + a1;
    double w0 = a0 * (2.0 * a0 + 3.0 * a1) / (6.0 * s);
    double w1 = a0 * (a0 + 3.0 * a1) / (6.0 * a1);
    double w2 = -a0 * a0 * a0 / (6.0 * a1 * s);
    sub[i] = w0 * y[i] + w1 * y[i + 1] + w2 * y[i + 2];
    // over [i+1, i+2]
    w0 = -a1 * a1 * a1 / (6.0 * a0 * s);
    w1 = a1 * (a1 + 3.0 * a0) / (6.0 * a0);
    w2 = a1 * (2.0 * a1 + 3.0 * a0) / (6.0 * s);
    sub[i + 1] = w0 * y[i] + w1 * y[i + 1] + w2 * y[i + 2];
  }
  if (n % 2 == 0) {
    const size_t i = n - 3;
    const double a0 = h[i], a1 = h[i + 1], s = a0 + a1;
    sub[i + 1] = -a1 * a1 * a1 / (6.0 * a0 * s) * y[i] + a1 * (a1 + 3.0 * a0) / (6.0 * a0) * y[i + 1] + a1 * (2.0 * a1 + 3.0 * a0) / (6.0 * s) * y[i + 2];
  }
  double t = 0.0;
  for (double v : sub) {
    t += v;
    out.push_back(t);
  }
  return out;
}

bool sampleArgs(const Args &a, CallContext &ctx, Vec &y, Vec &x) {
  if (!getVec(a, 0, ctx, y))
    return false;
  if (a.size() > 1 && !isPlainNumber(a[1])) {
    if (!getVec(a, 1, ctx, x))
      return false;
    if (x.size() != y.size()) {
      ctx.fail("y and x must have the same length");
      return false;
    }
  }
  return true;
}
double sampleDx(const Args &a) { return (a.size() > 1 && isPlainNumber(a[1]) && a[1].number != 0.0) ? a[1].number : 1.0; }

} // namespace

void registerIntegrationOdes(Registry &reg) {
  SP_ADD("integrate", 3, 5, "fn, a, b, epsabs=1.49e-8, epsrel=1.49e-8") {
    double lo, hi;
    if (!getFn(a, 0, ctx) || !argNumber(a, 1, ctx, lo) || !argNumber(a, 2, ctx, hi))
      return Value(0.0);
    NcFn f(a[0]);
    double v = 0.0, e = 0.0;
    quad([&](double t) { return f.scalar(t); }, lo, hi, optNum(a, 3, 1.49e-8), optNum(a, 4, 1.49e-8), v, e, [&] { return f.failed; });
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"value", Value(v)}, {"error", Value(e)}});
  } SP_END
  SP_ADD("integrate_vec", 3, 5, "fn, a, b, epsabs=1e-8, epsrel=1e-8") {
    double lo, hi;
    if (!getFn(a, 0, ctx) || !argNumber(a, 1, ctx, lo) || !argNumber(a, 2, ctx, hi))
      return Value(0.0);
    NcFn f(a[0]);
    Value probe = f.raw({Value(0.5 * (lo + hi))});
    Vec p;
    if (f.failed || !readVec(probe, p) || p.empty()) {
      ctx.fail("the function must return an array of numbers");
      return Value(0.0);
    }
    Vec val(p.size()), err(p.size());
    for (size_t k = 0; k < p.size(); k++) {
      double v = 0.0, e = 0.0;
      quad([&](double t) {
        Value o = f.raw({Value(t)});
        Vec q;
        if (f.failed || !readVec(o, q) || q.size() != p.size()) {
          f.failed = true;
          return kNaN;
        }
        return q[k];
      }, lo, hi, optNum(a, 3, 1e-8), optNum(a, 4, 1e-8), v, e, [&] { return f.failed; });
      val[k] = v;
      err[k] = e;
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    double en = 0.0;
    for (double e : err)
      en = std::max(en, e);
    return makeDict({{"value", toValue(val)}, {"error", Value(en)}});
  } SP_END
#define NC_BOX_FN(NAME, DIMS, ORDER)                                                               \
  SP_ADD(NAME, 1 + 2 * DIMS, 1 + 2 * DIMS, "fn, limits...") {                                      \
    if (!getFn(a, 0, ctx))                                                                         \
      return Value(0.0);                                                                           \
    Vec lo(DIMS), hi(DIMS);                                                                        \
    for (size_t d = 0; d < DIMS; d++)                                                              \
      if (!argNumber(a, 1 + 2 * d, ctx, lo[d]) || !argNumber(a, 2 + 2 * d, ctx, hi[d]))            \
        return Value(0.0);                                                                         \
    NcFn f(a[0]);                                                                                  \
    std::function<double(const Vec &)> g = [&](const Vec &p) {                                     \
      Args in;                                                                                     \
      for (size_t i = DIMS; i-- > 0;)                                                              \
        in.push_back(Value(p[i]));                                                                 \
      return f.number(in);                                                                         \
    };                                                                                             \
    std::function<bool()> stop = [&] { return f.failed; };                                         \
    BoxInt box{g, stop, 1.49e-8, 1.49e-8, lo, hi, Vec(DIMS)};                                      \
    double e = 0.0;                                                                                \
    const double v = box.run(0, e);                                                                \
    if (f.failed) {                                                                                \
      ctx.fail(f.failText());                                                                      \
      return Value(0.0);                                                                           \
    }                                                                                              \
    return makeDict({{"value", Value(v)}, {"error", Value(e)}});                                   \
  } SP_END
  NC_BOX_FN("integrate2", 2, 0)
  NC_BOX_FN("integrate3", 3, 0)
  SP_ADD("integrate_n", 2, 2, "fn, ranges") {
    Mat r;
    if (!getFn(a, 0, ctx) || !getMat(a, 1, ctx, r))
      return Value(0.0);
    if (r.c != 2) {
      ctx.fail("ranges must have one [low, high] row per variable");
      return Value(0.0);
    }
    Vec lo(r.r), hi(r.r);
    for (size_t i = 0; i < r.r; i++) {
      lo[i] = r(i, 0);
      hi[i] = r(i, 1);
    }
    NcFn f(a[0]);
    std::function<double(const Vec &)> g = [&](const Vec &p) {
      Args in;
      for (double v : p)
        in.push_back(Value(v));
      return f.number(in);
    };
    std::function<bool()> stop = [&] { return f.failed; };
    BoxInt box{g, stop, 1.49e-8, 1.49e-8, lo, hi, Vec(r.r)};
    double e = 0.0;
    const double v = box.run(0, e);
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"value", Value(v)}, {"error", Value(e)}});
  } SP_END
  SP_ADD("integrate_fixed", 3, 4, "fn, a, b, n=5") {
    double lo, hi;
    if (!getFn(a, 0, ctx) || !argNumber(a, 1, ctx, lo) || !argNumber(a, 2, ctx, hi))
      return Value(0.0);
    const int n = static_cast<int>(optInt(a, 3, 5));
    if (n < 1) {
      ctx.fail("n must be at least 1");
      return Value(0.0);
    }
    Vec x, w;
    gaussLegendre(n, x, w);
    NcFn f(a[0]);
    double s = 0.0;
    for (int i = 0; i < n; i++)
      s += w[i] * f.scalar(0.5 * (hi - lo) * x[i] + 0.5 * (hi + lo));
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return Value(0.5 * (hi - lo) * s);
  } SP_END
  SP_ADD("newton_cotes", 1, 2, "n, equal=1") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    if (n < 1 || n > 30) {
      ctx.fail("n must be between 1 and 30");
      return Value(0.0);
    }
    Vec w;
    double err;
    newtonCotes((int)n, w, err);
    return makeDict({{"weights", toValue(w)}, {"error", Value(err)}});
  } SP_END
  SP_ADD("integrate_qmc", 3, 5, "fn, a, b, n=4096, seed=0") {
    Vec lo, hi;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, lo) || !getVec(a, 2, ctx, hi))
      return Value(0.0);
    if (lo.size() != hi.size() || lo.empty()) {
      ctx.fail("a and b must be corners of the same length");
      return Value(0.0);
    }
    const long long total = optInt(a, 3, 4096);
    const unsigned long start = static_cast<unsigned long>(optInt(a, 4, 0)) + 20;
    static const int primes[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53};
    if (lo.size() > 16) {
      ctx.fail("at most 16 variables");
      return Value(0.0);
    }
    double vol = 1.0;
    for (size_t d = 0; d < lo.size(); d++)
      vol *= hi[d] - lo[d];
    NcFn f(a[0]);
    const int batches = 8;
    Vec est(batches, 0.0);
    Vec p(lo.size());
    for (long long i = 0; i < total; i++) {
      for (size_t d = 0; d < lo.size(); d++)
        p[d] = lo[d] + (hi[d] - lo[d]) * radicalInverse(start + (unsigned long)i, primes[d]);
      est[i % batches] += f.ofVec(p);
      if (f.failed) {
        ctx.fail(f.failText());
        return Value(0.0);
      }
    }
    double m = 0.0;
    for (double &e : est) {
      e *= vol / static_cast<double>(total / batches);
      m += e / batches;
    }
    double s = 0.0;
    for (double e : est)
      s += (e - m) * (e - m);
    return makeDict({{"integral", Value(m)}, {"standard_error", Value(std::sqrt(s / (batches * (batches - 1.0))))}});
  } SP_END
  SP_ADD("integrate_tanhsinh", 3, 4, "fn, a, b, tol=1e-12") {
    double lo, hi;
    if (!getFn(a, 0, ctx) || !argNumber(a, 1, ctx, lo) || !argNumber(a, 2, ctx, hi))
      return Value(0.0);
    NcFn f(a[0]);
    double v = 0.0, e = 0.0, sign = 1.0;
    if (lo > hi) {
      std::swap(lo, hi);
      sign = -1.0;
    }
    const double tol = optNum(a, 3, 1e-12);
    std::function<bool()> stop = [&] { return f.failed; };
    if (std::isinf(lo) || std::isinf(hi)) {
      quad([&](double t) { return f.scalar(t); }, lo, hi, tol, tol, v, e, stop);
    } else {
      tanhSinh([&](double t) { return f.scalar(t); }, lo, hi, tol, v, e, stop);
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"integral", Value(sign * v)}, {"error", Value(e)}, {"success", Value::boolean(e <= 1e-6 * std::max(1.0, std::fabs(v)))}});
  } SP_END
  SP_ADD("cubature", 3, 5, "fn, a, b, atol=1e-8, rtol=1e-8") {
    Vec lo, hi;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, lo) || !getVec(a, 2, ctx, hi))
      return Value(0.0);
    if (lo.size() != hi.size() || lo.empty()) {
      ctx.fail("a and b must be corners of the same length");
      return Value(0.0);
    }
    // Adaptive subdivision with a tensor Gauss rule (7 points) against 3 points.
    NcFn f(a[0]);
    const double atol = optNum(a, 3, 1e-8), rtol = optNum(a, 4, 1e-8);
    const size_t d = lo.size();
    Vec x7, w7, x3, w3;
    gaussLegendre(d <= 2 ? 7 : 5, x7, w7);
    gaussLegendre(d <= 2 ? 3 : 2, x3, w3);
    auto tensor = [&](const Vec &L, const Vec &H, const Vec &x, const Vec &w) {
      double s = 0.0;
      std::vector<size_t> idx(d, 0);
      Vec p(d);
      while (true) {
        double wt = 1.0;
        for (size_t i = 0; i < d; i++) {
          p[i] = 0.5 * (H[i] - L[i]) * x[idx[i]] + 0.5 * (H[i] + L[i]);
          wt *= w[idx[i]] * 0.5 * (H[i] - L[i]);
        }
        s += wt * f.ofVec(p);
        size_t k = 0;
        while (k < d && ++idx[k] == x.size())
          idx[k++] = 0;
        if (k == d || f.failed)
          break;
      }
      return s;
    };
    struct Reg {
      Vec L, H;
      double v, e;
    };
    auto eval = [&](const Vec &L, const Vec &H) {
      const double hiV = tensor(L, H, x7, w7), loV = tensor(L, H, x3, w3);
      return Reg{L, H, hiV, std::fabs(hiV - loV)};
    };
    std::vector<Reg> regs{eval(lo, hi)};
    double total = 0.0, err = 0.0;
    int status = 1;
    for (int it = 0; it < 300 && !f.failed; it++) {
      total = err = 0.0;
      size_t worst = 0;
      for (size_t i = 0; i < regs.size(); i++) {
        total += regs[i].v;
        err += regs[i].e;
        if (regs[i].e > regs[worst].e)
          worst = i;
      }
      if (err <= std::max(atol, rtol * std::fabs(total))) {
        status = 0;
        break;
      }
      Reg w = regs[worst];
      size_t dim = 0;
      for (size_t i = 1; i < d; i++)
        if (w.H[i] - w.L[i] > w.H[dim] - w.L[dim])
          dim = i;
      Vec m1 = w.H, m2 = w.L;
      m1[dim] = m2[dim] = 0.5 * (w.L[dim] + w.H[dim]);
      regs[worst] = eval(w.L, m1);
      regs.push_back(eval(m2, w.H));
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"estimate", Value(total)}, {"error", Value(err)}, {"status", Value(status == 0 ? std::string("converged") : std::string("not_converged"))}});
  } SP_END
  SP_ADD("lebedev_rule", 1, 1, "order") {
    long long order;
    if (!argNonNegativeInt(a, 0, ctx, order))
      return Value(0.0);
    for (int i = 0; i < kLebedevCount; i++)
      if (kLebedevIndex[i].order == order) {
        const LebedevIndex &ix = kLebedevIndex[i];
        Mat P(3, ix.count);
        Vec w(ix.count);
        for (int j = 0; j < ix.count; j++) {
          for (int c = 0; c < 3; c++)
            P(c, j) = kLebedevPoints[ix.start + j][c];
          w[j] = kLebedevPoints[ix.start + j][3];
        }
        return makeDict({{"points", toValue(P)}, {"weights", toValue(w)}});
      }
    ctx.fail("order must be one of 3, 5, 7, ..., 31, 35 or 41");
    return Value(0.0);
  } SP_END
  SP_ADD("nsum", 3, 4, "fn, a, b, step=1") {
    double lo, hi;
    if (!getFn(a, 0, ctx) || !argNumber(a, 1, ctx, lo) || !argNumber(a, 2, ctx, hi))
      return Value(0.0);
    const double step = optNum(a, 3, 1.0);
    NcFn f(a[0]);
    double s = 0.0, err = 0.0;
    const long long direct = 1000;
    const double terms = std::isinf(hi) ? kInf : std::floor((hi - lo) / step) + 1.0;
    if (terms <= static_cast<double>(2 * direct)) {
      for (long long k = 0; k < static_cast<long long>(terms); k++)
        s += f.scalar(lo + step * static_cast<double>(k));
    } else {
      // Direct sum, then Euler-Maclaurin for the tail: integral + f/2 - h f'/12 + h^3 f'''/720.
      for (long long k = 0; k < direct; k++)
        s += f.scalar(lo + step * static_cast<double>(k));
      const double start = lo + step * static_cast<double>(direct);
      double v = 0.0, e = 0.0;
      quad([&](double t) { return f.scalar(t); }, start, hi, 1e-13, 1e-13, v, e, [&] { return f.failed; });
      const double h = 1e-2 * start;
      const double fs = f.scalar(start);
      const double d1 = (f.scalar(start + h) - f.scalar(start - h)) / (2.0 * h);
      s += v / step + 0.5 * fs - step * d1 / 12.0;
      err = e + std::fabs(step * d1 / 12.0) * 1e-3;
      if (!std::isinf(hi))
        s += 0.5 * f.scalar(hi);
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"sum", Value(s)}, {"error", Value(err)}, {"success", Value::boolean(std::isfinite(s))}});
  } SP_END
  SP_ADD("cumtrapz", 1, 3, "y, x, initial") {
    Vec y, x;
    if (!sampleArgs(a, ctx, y, x))
      return Value(0.0);
    Vec c = cumTrap(y, x, sampleDx(a));
    if (a.size() > 2 && isPlainNumber(a[2]))
      c.insert(c.begin(), a[2].number);
    return toValue(c);
  } SP_END
  SP_ADD("simpson", 1, 2, "y, x") {
    Vec y, x;
    if (!sampleArgs(a, ctx, y, x))
      return Value(0.0);
    return Value(simpson(y, x, sampleDx(a)));
  } SP_END
  SP_ADD("cumsimpson", 1, 3, "y, x, initial") {
    Vec y, x;
    if (!sampleArgs(a, ctx, y, x))
      return Value(0.0);
    Vec c = cumSimpson(y, x, sampleDx(a));
    if (a.size() > 2 && isPlainNumber(a[2]))
      c.insert(c.begin(), a[2].number);
    return toValue(c);
  } SP_END
  SP_ADD("romb", 1, 2, "y, dx=1") {
    Vec y;
    if (!getVec(a, 0, ctx, y))
      return Value(0.0);
    const size_t n = y.size() ? y.size() - 1 : 0;
    if (n == 0 || (n & (n - 1)) != 0) {
      ctx.fail("y must have 2^k + 1 samples");
      return Value(0.0);
    }
    const double dx = optNum(a, 1, 1.0);
    int k = 0;
    while ((size_t(1) << k) < n)
      k++;
    std::vector<Vec> R(k + 1, Vec(k + 1, 0.0));
    double h = dx * static_cast<double>(n);
    R[0][0] = 0.5 * h * (y[0] + y[n]);
    size_t start = n, stop_ = n, step = n;
    for (int i = 1; i <= k; i++) {
      start >>= 1;
      double s = 0.0;
      for (size_t j = start; j < stop_; j += step)
        s += y[j];
      step >>= 1;
      R[i][0] = 0.5 * (R[i - 1][0] + h * s);
      for (int j = 1; j <= i; j++) {
        const double prev = R[i][j - 1];
        R[i][j] = prev + (prev - R[i - 1][j - 1]) / (std::pow(4.0, j) - 1.0);
      }
      h *= 0.5;
    }
    return Value(R[k][k]);
  } SP_END
  registerOdeSolvers(reg);
  reg.setParallel({"integrate", "integrate_vec", "integrate2", "integrate3", "integrate_n", "integrate_fixed",
                   "integrate_qmc", "integrate_tanhsinh", "cubature", "nsum", "ode_solve", "ode_eval", "odeint", "bvp_solve"},
                  ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
