// Continuous families, halfcauchy to wrapcauchy, with the laws that need
// their own numerical methods: Kolmogorov-Smirnov (Durbin's matrix), Levy
// stable (Nolan's integrals), Landau, studentized range (nested quadrature).
#include "pd_common.h"

#include <algorithm>
#include <complex>

namespace nc {
namespace scipy {
namespace pd {

namespace {
using cd = std::complex<double>;

// ---- Kolmogorov-Smirnov ----

// P(D_n < d) by Marsaglia, Tsang and Wang (2003): the (k,k) entry of H^n.
double durbin(int n, double d) {
  double nd = n * d;
  int k = static_cast<int>(nd) + 1, m = 2 * k - 1;
  double h = k - nd;
  std::vector<double> H(m * m, 0.0);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < m; j++)
      H[i * m + j] = (i - j + 1 < 0) ? 0.0 : 1.0;
  for (int i = 0; i < m; i++) {
    H[i * m] -= std::pow(h, i + 1);
    H[(m - 1) * m + i] -= std::pow(h, m - i);
  }
  H[(m - 1) * m] += (2 * h - 1 > 0 ? std::pow(2 * h - 1, m) : 0.0);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < m; j++)
      if (i - j + 1 > 0)
        for (int g = 1; g <= i - j + 1; g++)
          H[i * m + j] /= g;
  auto mul = [m](const std::vector<double> &A, const std::vector<double> &B) {
    std::vector<double> C(m * m, 0.0);
    for (int i = 0; i < m; i++)
      for (int l = 0; l < m; l++) {
        double a = A[i * m + l];
        if (a == 0)
          continue;
        for (int j = 0; j < m; j++)
          C[i * m + j] += a * B[l * m + j];
      }
    return C;
  };
  std::function<void(int, std::vector<double> &, int &)> power = [&](int e, std::vector<double> &V, int &eV) {
    if (e == 1) {
      V = H;
      eV = 0;
      return;
    }
    power(e / 2, V, eV);
    std::vector<double> B = mul(V, V);
    int eB = 2 * eV;
    if (e % 2 == 0) {
      V = B;
      eV = eB;
    } else {
      V = mul(H, B);
      eV = eB;
    }
    if (V[(m / 2) * m + m / 2] > 1e140) {
      for (double &x : V)
        x *= 1e-140;
      eV += 140;
    }
  };
  std::vector<double> V;
  int eQ = 0;
  power(n, V, eQ);
  double s = V[(k - 1) * m + k - 1];
  for (int i = 1; i <= n; i++) {
    s = s * i / n;
    if (s < 1e-140) {
      s *= 1e140;
      eQ -= 140;
    }
  }
  return s * std::pow(10.0, eQ);
}

double smirnovPdf(int n, double d) {
  if (d <= 0 || d >= 1)
    return 0.0;
  int jmax = static_cast<int>(std::floor(n * (1 - d)));
  double lgn = std::lgamma(n + 1.0), sum = 0.0;
  for (int j = 0; j <= jmax; j++) {
    double a = 1 - d - double(j) / n, b = d + double(j) / n;
    if (a <= 0)
      break;
    double lt = lgn - std::lgamma(j + 1.0) - std::lgamma(n - j + 1.0) + (n - j) * std::log(a) + (j - 1) * std::log(b);
    sum += std::exp(lt) * (1 + d * (-(n - j) / a + (j - 1) / b));
  }
  return -sum;
}

double kstwoCdf(int n, double d) {
  if (d <= 0.5 / n)
    return 0.0;
  if (d >= 1)
    return 1.0;
  if (d >= 0.5)
    return 1.0 - 2 * sf::smirnov(n, d);
  if (2 * static_cast<int>(n * d) + 1 > 400) // matrix too large: Kolmogorov's limit with the Stephens correction
    return sf::kolmogorov_cdf((std::sqrt(double(n)) + 0.12 + 0.11 / std::sqrt(double(n))) * d);
  return durbin(n, d);
}

double kstwoSf(int n, double d) {
  if (d >= 0.5 && d < 1)
    return 2 * sf::smirnov(n, d);
  return 1.0 - kstwoCdf(n, d);
}

double kstwoPdf(int n, double d) {
  if (d <= 0.5 / n || d >= 1)
    return 0.0;
  if (d >= 0.5)
    return 2 * smirnovPdf(n, d);
  // P(D_n < d) is a polynomial in d between the points k/n: central differences inside one piece
  double lo = std::floor(n * d) / n, hi = (std::floor(n * d) + 1) / n;
  double h = std::min({1e-5, (d - lo) / 4, (hi - d) / 4});
  if (h <= 0)
    h = 1e-9;
  double f1 = kstwoCdf(n, d + h), f2 = kstwoCdf(n, d - h), f3 = kstwoCdf(n, d + 2 * h), f4 = kstwoCdf(n, d - 2 * h);
  return (8 * (f1 - f2) - (f3 - f4)) / (12 * h);
}

double kolmogorovPdf(double x) {
  if (x <= 0)
    return 0.0;
  if (x < 0.6) {
    double s = 0.0;
    for (int k = 1; k < 100; k++) {
      double c = (2.0 * k - 1) * (2.0 * k - 1) * PI * PI / 8;
      double t = std::exp(-c / (x * x)) * (-1 / (x * x) + 2 * c / (x * x * x * x));
      s += t;
      if (std::fabs(t) < 1e-20)
        break;
    }
    return std::sqrt(2 * PI) * s;
  }
  double s = 0.0;
  for (int k = 1; k < 100; k++) {
    double t = k * k * std::exp(-2.0 * k * k * x * x);
    s += (k % 2 ? 1.0 : -1.0) * t;
    if (t < 1e-20)
      break;
  }
  return 8 * x * s;
}

// ---- Landau ----

// Standard form used by SciPy (Boost): f(x) = 1/pi int_0^inf e^-t cos(x t + 2/pi t log t) dt
double landauPdf(double x) {
  auto f = [x](double t) { return t == 0 ? 1.0 : std::exp(-t) * std::cos(x * t + 2 / PI * t * std::log(t)); };
  return (sf::quad(f, 0.0, 1.0, 0.0, 1e-14, 2000) + sf::quad(f, 1.0, 60.0, 0.0, 1e-14, 4000)) / PI;
}
// F(x) = 1/2 + 1/pi int_0^inf e^-t sin(x t + 2/pi t log t) / t dt; t = s^2 near 0 softens the log
double landauSf(double x) {
  auto g = [x](double s) {
    if (s == 0)
      return 0.0;
    double t = s * s;
    return 2 * s * std::exp(-t) * std::sin(x * t + 2 / PI * t * std::log(t)) / t;
  };
  auto f = [x](double t) { return std::exp(-t) * std::sin(x * t + 2 / PI * t * std::log(t)) / t; };
  double I = sf::quad(g, 0.0, 1.0, 0.0, 1e-14, 2000) + sf::quad(f, 1.0, 60.0, 0.0, 1e-14, 4000);
  return 0.5 - I / PI;
}

// ---- Levy stable (S1 parameterization), Nolan's integral forms ----

double stableV(double th, double al, double be, double th0) {
  if (al == 1) {
    double c = PI / 2 + be * th;
    return 2 / PI * (c / std::cos(th)) * std::exp(c * std::tan(th) / be);
  }
  double r = std::pow(std::cos(al * th0), 1 / (al - 1)) *
             std::pow(std::cos(th) / std::sin(al * (th0 + th)), al / (al - 1)) * std::cos(al * th0 + (al - 1) * th) /
             std::cos(th);
  return r;
}

// integral over (lo, hi) of h(u V(theta)) with a split where u V = 1
double stableIntegral(double u, double al, double be, double th0, double lo, double hi,
                      const std::function<double(double)> &h, bool times) {
  auto g = [&](double th) {
    double V = stableV(th, al, be, th0);
    if (!std::isfinite(V) || V < 0)
      return 0.0;
    double w = u * V;
    double r = h(w);
    return times ? r * V : r;
  };
  // locate the peak where u V(theta) = 1 (V is monotone in theta)
  auto lv = [&](double th) { return std::log(u) + std::log(stableV(th, al, be, th0)); };
  double a = lo + 1e-12 * (hi - lo), b = hi - 1e-12 * (hi - lo);
  double fa = lv(a), fb = lv(b), mid = 0.5 * (lo + hi);
  if (std::isfinite(fa) && std::isfinite(fb) && (fa > 0) != (fb > 0))
    mid = sf::brent(lv, a, b, 1e-14, 200);
  return sf::quad(g, lo, mid, 0.0, 1e-12, 2000) + sf::quad(g, mid, hi, 0.0, 1e-12, 2000);
}

double stablePdf(double x, double al, double be) {
  if (al == 2)
    return std::exp(-x * x / 4) / (2 * std::sqrt(PI));
  if (al == 1) {
    if (be == 0)
      return 1 / (PI * (1 + x * x));
    if (be < 0)
      return stablePdf(-x, al, -be);
    double c = std::exp(-PI * x / (2 * be));
    double I = stableIntegral(c, 1, be, PI / 2, -PI / 2, PI / 2, [](double w) { return std::exp(-w); }, true);
    return c / (2 * be) * I;
  }
  double zeta = -be * std::tan(PI * al / 2);
  double th0 = std::atan(be * std::tan(PI * al / 2)) / al;
  if (x == 0)
    return std::tgamma(1 + 1 / al) * std::cos(th0) / (PI * std::pow(1 + zeta * zeta, 1 / (2 * al)));
  if (x < 0)
    return stablePdf(-x, al, -be);
  if (-th0 >= PI / 2)
    return 0.0;
  double u = std::pow(x, al / (al - 1));
  double I = stableIntegral(u, al, be, th0, -th0, PI / 2, [](double w) { return w * std::exp(-w); }, false);
  // al x^(1/(al-1)) / (pi |al-1|) * int V exp(-u V) = al / (pi |al-1| x) * int (uV) exp(-uV)
  return al / (PI * std::fabs(al - 1) * x) * I;
}

double stableCdf(double x, double al, double be) {
  if (al == 2)
    return sf::ndtr(x / std::sqrt(2.0));
  if (al == 1) {
    if (be == 0)
      return 0.5 + std::atan(x) / PI;
    if (be < 0)
      return 1 - stableCdf(-x, al, -be);
    double c = std::exp(-PI * x / (2 * be));
    return stableIntegral(c, 1, be, PI / 2, -PI / 2, PI / 2, [](double w) { return std::exp(-w); }, false) / PI;
  }
  double th0 = std::atan(be * std::tan(PI * al / 2)) / al;
  if (x == 0)
    return (PI / 2 - th0) / PI;
  if (x < 0)
    return 1 - stableCdf(-x, al, -be);
  double c1 = al < 1 ? (PI / 2 - th0) / PI : 1.0;
  if (-th0 >= PI / 2)
    return c1;
  double u = std::pow(x, al / (al - 1));
  double I = stableIntegral(u, al, be, th0, -th0, PI / 2, [](double w) { return std::exp(-w); }, false);
  return c1 + (al < 1 ? 1.0 : -1.0) / PI * I;
}

// ---- studentized range ----

double rangeG(double w, double k) { // P(range of k normals <= w)
  if (w <= 0)
    return 0.0;
  auto f = [&](double z) {
    double d = sf::ndtr(z) - sf::ndtr(z - w);
    return d <= 0 ? 0.0 : phi(z) * std::pow(d, k - 1);
  };
  return k * sf::quad(f, -9.0, 9.0 + w, 0.0, 1e-12, 400);
}
double rangeg(double w, double k) { // its density
  if (w <= 0)
    return 0.0;
  auto f = [&](double z) {
    double d = sf::ndtr(z) - sf::ndtr(z - w);
    return d <= 0 ? 0.0 : phi(z) * phi(z - w) * std::pow(d, k - 2);
  };
  return k * (k - 1) * sf::quad(f, -9.0, 9.0 + w, 0.0, 1e-12, 400);
}
double chiScaledPdf(double s, double nu) { // density of sqrt(chi2_nu / nu)
  if (s <= 0)
    return 0.0;
  return std::exp(nu / 2 * std::log(nu) - std::lgamma(nu / 2) - (nu / 2 - 1) * std::log(2.0) + (nu - 1) * std::log(s) -
                  nu * s * s / 2);
}
double srangeCdf(double q, double k, double nu) {
  if (q <= 0)
    return 0.0;
  if (std::isinf(nu))
    return rangeG(q, k);
  double sd = 1 / std::sqrt(nu);
  return sf::quad([&](double s) { return rangeG(q * s, k) * chiScaledPdf(s, nu); }, std::max(0.0, 1 - 12 * sd), 1 + 12 * sd,
                  0.0, 1e-10, 400);
}
double srangePdf(double q, double k, double nu) {
  if (q <= 0)
    return 0.0;
  if (std::isinf(nu))
    return rangeg(q, k);
  double sd = 1 / std::sqrt(nu);
  return sf::quad([&](double s) { return s * rangeg(q * s, k) * chiScaledPdf(s, nu); }, std::max(0.0, 1 - 12 * sd),
                  1 + 12 * sd, 0.0, 1e-10, 400);
}

// ---- other helpers ----

double invgaussCdf(double x, double mu) {
  if (x <= 0)
    return 0.0;
  double f = 1 / std::sqrt(x);
  return sf::ndtr(f * (x / mu - 1)) + std::exp(2 / mu + sf::log_ndtr(-f * (x / mu + 1)));
}
double invgaussSf(double x, double mu) {
  if (x <= 0)
    return 1.0;
  double f = 1 / std::sqrt(x);
  return sf::ndtr(-f * (x / mu - 1)) - std::exp(2 / mu + sf::log_ndtr(-f * (x / mu + 1)));
}
double invgaussPdf(double x, double mu) {
  if (x <= 0)
    return 0.0;
  return std::exp(-(x - mu) * (x - mu) / (2 * x * mu * mu)) / std::sqrt(2 * PI * x * x * x);
}

void kappa4Supp(const double *p, double &a, double &b) {
  double h = p[0], k = p[1];
  if (h > 0)
    a = (k == 0) ? std::log(h) : (1 - std::pow(h, -k)) / k;
  else
    a = (k < 0) ? 1 / k : -Inf;
  b = (k > 0) ? 1 / k : Inf;
}
double kappa4Cdf(double x, const double *p) {
  double h = p[0], k = p[1];
  double u = (k == 0) ? std::exp(-x) : std::pow(1 - k * x, 1 / k);
  if (h == 0)
    return std::exp(-u);
  return std::exp(std::log1p(-h * u) / h);
}
double kappa4Pdf(double x, const double *p) {
  double h = p[0], k = p[1];
  double lu = (k == 0) ? -x : std::log(1 - k * x) / k;
  double u = std::exp(lu);
  double l = (k == 0) ? -x : (1 / k - 1) * std::log(1 - k * x);
  l += (h == 0) ? -u : (1 / h - 1) * std::log1p(-h * u);
  return std::exp(l);
}
double kappa4Ppf(double q, const double *p) {
  double h = p[0], k = p[1];
  double u = (h == 0) ? -std::log(q) : (1 - std::pow(q, h)) / h;
  return (k == 0) ? -std::log(u) : (1 - std::pow(u, k)) / k;
}

double irwinCdf(double x, double n) {
  if (x <= 0)
    return 0.0;
  if (x >= n)
    return 1.0;
  if (x > n / 2)
    return 1 - irwinCdf(n - x, n);
  double s = 0.0;
  for (int k = 0; k <= static_cast<int>(std::floor(x)); k++)
    s += (k % 2 ? -1.0 : 1.0) * std::exp(std::lgamma(n + 1) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1) + n * std::log(x - k) - std::lgamma(n + 1));
  return s;
}
double irwinPdf(double x, double n) {
  if (x < 0 || x > n)
    return 0.0;
  if (x > n / 2)
    x = n - x;
  double s = 0.0;
  for (int k = 0; k <= static_cast<int>(std::floor(x)); k++) {
    double t = x - k;
    if (t <= 0 && n > 1)
      continue;
    s += (k % 2 ? -1.0 : 1.0) * std::exp(std::lgamma(n + 1) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1) + (n - 1) * std::log(t) - std::lgamma(n));
  }
  return s;
}

double jfLogPdf(double x, double a, double b) {
  double r = std::sqrt(a + b + x * x);
  double onePlus = x >= 0 ? 1 + x / r : (a + b) / (r * (r - x));
  double oneMinus = x <= 0 ? 1 - x / r : (a + b) / (r * (r + x));
  return (a + 0.5) * std::log(onePlus) + (b + 0.5) * std::log(oneMinus) - (a + b - 1) * std::log(2.0) - sf::lbeta(a, b) -
         0.5 * std::log(a + b);
}

double breitI(double rho) { // integral of 1/((x^2 - rho^2)^2 + rho^2) over (0, inf)
  cd w = std::sqrt(cd(-rho * rho, -rho));
  return PI / (2 * rho) * (1.0 / w).imag();
}
double breitCdf(double x, double rho) {
  cd w = std::sqrt(cd(-rho * rho, -rho));
  cd v = std::atan(x / w) / w;
  return v.imag() / rho / breitI(rho);
}

double truncnormLogZ(double a, double b) {
  if (a > 0)
    return sf::log_ndtr(-a) + std::log1p(-std::exp(sf::log_ndtr(-b) - sf::log_ndtr(-a)));
  return sf::log_ndtr(b) + std::log1p(-std::exp(sf::log_ndtr(a) - sf::log_ndtr(b)));
}
double truncnormCdf(double x, double a, double b) {
  double lz = truncnormLogZ(a, b);
  if (a > 0)
    return std::exp(sf::log_ndtr(-a) - lz) * -std::expm1(sf::log_ndtr(-x) - sf::log_ndtr(-a));
  return std::exp(sf::log_ndtr(x) - lz) * -std::expm1(sf::log_ndtr(a) - sf::log_ndtr(x));
}
double truncnormSf(double x, double a, double b) { return truncnormCdf(-x, -b, -a); }
double truncnormPpf(double q, double a, double b) {
  if (a > 0)
    return -sf::ndtri((1 - q) * sf::ndtr(-a) + q * sf::ndtr(-b));
  return sf::ndtri((1 - q) * sf::ndtr(a) + q * sf::ndtr(b));
}

double vonmisesPdf(double x, double kap) { return std::exp(kap * (std::cos(x) - 1)) / (2 * PI * sf::besseli(0, kap, true)); }
double vonmisesCdf(double x, double kap) {
  if (x <= -PI)
    return 0.0;
  if (x >= PI)
    return 1.0;
  auto f = [kap](double t) { return vonmisesPdf(t, kap); };
  if (x <= 0)
    return sf::quad(f, -PI, x, 0.0, 1e-14, 400);
  return 1 - sf::quad(f, x, PI, 0.0, 1e-14, 400);
}

double skewcauchyCdf(double x, double a) {
  if (x <= 0)
    return (1 - a) / 2 + (1 - a) / PI * std::atan(x / (1 - a));
  return (1 - a) / 2 + (1 + a) / PI * std::atan(x / (1 + a));
}
double skewcauchyPpf(double q, double a) {
  double c = (1 - a) / 2;
  if (q <= c)
    return (1 - a) * std::tan(PI * (q - c) / (1 - a));
  return (1 + a) * std::tan(PI * (q - c) / (1 + a));
}

double trapU(const double *p) { return 2 / (1 + p[1] - p[0]); }

double stableRvs(std::mt19937_64 &g, const double *p) {
  double al = p[0], be = p[1];
  double V = PI * (uniform01(g) - 0.5), W = -std::log(uniform01(g));
  if (al == 1) {
    double c = PI / 2 + be * V;
    return 2 / PI * (c * std::tan(V) - be * std::log((PI / 2 * W * std::cos(V)) / c));
  }
  double t = be * std::tan(PI * al / 2);
  double B = std::atan(t) / al, S = std::pow(1 + t * t, 1 / (2 * al));
  return S * std::sin(al * (V + B)) / std::pow(std::cos(V), 1 / al) *
         std::pow(std::cos(V - al * (V + B)) / W, (1 - al) / al);
}

double srangeRvs(std::mt19937_64 &g, const double *p) {
  int k = static_cast<int>(p[0]);
  double lo = Inf, hi = -Inf;
  for (int i = 0; i < k; i++) {
    double z = stdNormal(g);
    lo = std::min(lo, z);
    hi = std::max(hi, z);
  }
  if (std::isinf(p[1]))
    return hi - lo;
  return (hi - lo) / std::sqrt(2 * stdGamma(g, p[1] / 2) / p[1]);
}
} // namespace

void addContB(std::vector<Family> &v) {
  add(v, "halfcauchy", {}, nullptr, POS, PDF(2 / (PI * (1 + x * x))), PDF(2 / PI * std::atan(x)),
      PDF(x == 0 ? 1.0 : 2 / PI * std::atan(1 / x)), PDF(std::tan(PI * x / 2)), PDF(1 / std::tan(PI * x / 2)));

  add(v, "halfgennorm", {"beta"}, OK(p[0] > 0), POS, PDF(p[0] / std::tgamma(1 / p[0]) * std::exp(-std::pow(x, p[0]))),
      PDF(sf::gammainc(1 / p[0], std::pow(x, p[0]))), PDF(sf::gammaincc(1 / p[0], std::pow(x, p[0]))),
      PDF(std::pow(sf::gammaincinv(1 / p[0], x), 1 / p[0])), PDF(std::pow(sf::gammainccinv(1 / p[0], x), 1 / p[0])));

  add(v, "halflogistic", {}, nullptr, POS, PDF(2 * std::exp(-x) / ((1 + std::exp(-x)) * (1 + std::exp(-x)))),
      PDF(std::tanh(x / 2)), PDF(2 * std::exp(-x) / (1 + std::exp(-x))), PDF(2 * std::atanh(x)),
      PDF(std::log((2 - x) / x)));

  add(v, "halfnorm", {}, nullptr, POS, PDF(std::sqrt(2 / PI) * std::exp(-x * x / 2)), PDF(std::erf(x / std::sqrt(2.0))),
      PDF(std::erfc(x / std::sqrt(2.0))), PDF(std::sqrt(2.0) * sf::erfinv(x)), PDF(std::sqrt(2.0) * sf::erfcinv(x)));

  add(v, "hypsecant", {}, nullptr, nullptr, PDF(1 / (PI * std::cosh(x))), PDF(2 / PI * std::atan(std::exp(x))),
      PDF(2 / PI * std::atan(std::exp(-x))), PDF(std::log(std::tan(PI * x / 2))), PDF(-std::log(std::tan(PI * x / 2))));

  add(v, "invgamma", {"a"}, OK(p[0] > 0), POS,
      PDF(x <= 0 ? 0.0 : std::exp(-(p[0] + 1) * std::log(x) - 1 / x - std::lgamma(p[0]))),
      PDF(x <= 0 ? 0.0 : sf::gammaincc(p[0], 1 / x)), PDF(x <= 0 ? 1.0 : sf::gammainc(p[0], 1 / x)),
      PDF(1 / sf::gammainccinv(p[0], x)), PDF(1 / sf::gammaincinv(p[0], x)));

  add(v, "invgauss", {"mu"}, OK(p[0] > 0), POS, PDF(invgaussPdf(x, p[0])), PDF(invgaussCdf(x, p[0])),
      PDF(invgaussSf(x, p[0])), nullptr);

  add(v, "invweibull", {"c"}, OK(p[0] > 0), POS,
      PDF(x <= 0 ? 0.0 : p[0] * std::pow(x, -p[0] - 1) * std::exp(-std::pow(x, -p[0]))),
      PDF(x <= 0 ? 0.0 : std::exp(-std::pow(x, -p[0]))), PDF(x <= 0 ? 1.0 : -std::expm1(-std::pow(x, -p[0]))),
      PDF(std::pow(-std::log(x), -1 / p[0])), PDF(std::pow(-std::log1p(-x), -1 / p[0])));

  add(v, "irwinhall", {"n"}, OK(p[0] >= 1 && p[0] == std::floor(p[0]) && p[0] < 1000), SUPP(a = 0; b = p[0]),
      PDF(irwinPdf(x, p[0])), PDF(irwinCdf(x, p[0])), PDF(irwinCdf(p[0] - x, p[0])), nullptr);

  add(v, "jf_skew_t", {"a", "b"}, OK(p[0] > 0 && p[1] > 0), nullptr, PDF(std::exp(jfLogPdf(x, p[0], p[1]))),
      PDF(sf::betainc(p[0], p[1], (1 + x / std::sqrt(p[0] + p[1] + x * x)) / 2)),
      PDF(sf::betaincc(p[0], p[1], (1 + x / std::sqrt(p[0] + p[1] + x * x)) / 2)),
      PDF((2 * sf::betaincinv(p[0], p[1], x) - 1) * std::sqrt(p[0] + p[1]) /
          std::sqrt(1 - (2 * sf::betaincinv(p[0], p[1], x) - 1) * (2 * sf::betaincinv(p[0], p[1], x) - 1))));

  add(v, "johnsonsb", {"a", "b"}, OK(p[1] > 0), UNIT,
      PDF(x <= 0 || x >= 1 ? 0.0 : p[1] / (x * (1 - x)) * phi(p[0] + p[1] * std::log(x / (1 - x)))),
      PDF(sf::ndtr(p[0] + p[1] * std::log(x / (1 - x)))), PDF(sf::ndtr(-(p[0] + p[1] * std::log(x / (1 - x))))),
      PDF(1 / (1 + std::exp(-(sf::ndtri(x) - p[0]) / p[1]))));

  add(v, "johnsonsu", {"a", "b"}, OK(p[1] > 0), nullptr,
      PDF(p[1] / std::sqrt(x * x + 1) * phi(p[0] + p[1] * std::asinh(x))), PDF(sf::ndtr(p[0] + p[1] * std::asinh(x))),
      PDF(sf::ndtr(-(p[0] + p[1] * std::asinh(x)))), PDF(std::sinh((sf::ndtri(x) - p[0]) / p[1])));

  add(v, "kappa3", {"a"}, OK(p[0] > 0), POS, PDF(p[0] * std::pow(p[0] + std::pow(x, p[0]), -(p[0] + 1) / p[0])),
      PDF(x * std::pow(p[0] + std::pow(x, p[0]), -1 / p[0])), nullptr,
      PDF(std::pow(p[0] / (std::pow(x, -p[0]) - 1), 1 / p[0])));

  add(v, "kappa4", {"h", "k"}, nullptr, kappa4Supp, kappa4Pdf, kappa4Cdf, nullptr, kappa4Ppf);

  add(v, "ksone", {"n"}, OK(p[0] >= 1 && p[0] == std::floor(p[0])), UNIT, PDF(smirnovPdf((int)p[0], x)),
      PDF(1 - sf::smirnov((int)p[0], x)), PDF(sf::smirnov((int)p[0], x)), PDF(sf::smirnovi((int)p[0], 1 - x)),
      PDF(sf::smirnovi((int)p[0], x)));

  add(v, "kstwo", {"n"}, OK(p[0] >= 1 && p[0] == std::floor(p[0])), UNIT, PDF(kstwoPdf((int)p[0], x)),
      PDF(kstwoCdf((int)p[0], x)), PDF(kstwoSf((int)p[0], x)), nullptr);

  add(v, "kstwobign", {}, nullptr, POS, PDF(kolmogorovPdf(x)), PDF(sf::kolmogorov_cdf(x)), PDF(sf::kolmogorov(x)),
      PDF(sf::kolmogi(1 - x)), PDF(sf::kolmogi(x)));

  add(v, "landau", {}, nullptr, nullptr, PDF(landauPdf(x)), PDF(1 - landauSf(x)), PDF(landauSf(x)), nullptr);

  add(v, "laplace", {}, nullptr, nullptr, PDF(0.5 * std::exp(-std::fabs(x))),
      PDF(x < 0 ? 0.5 * std::exp(x) : 1 - 0.5 * std::exp(-x)), PDF(x > 0 ? 0.5 * std::exp(-x) : 1 - 0.5 * std::exp(x)),
      PDF(x < 0.5 ? std::log(2 * x) : -std::log(2 * (1 - x))), PDF(x < 0.5 ? -std::log(2 * x) : std::log(2 * (1 - x))));

  add(v, "laplace_asymmetric", {"kappa"}, OK(p[0] > 0), nullptr,
      PDF(1 / (p[0] + 1 / p[0]) * (x >= 0 ? std::exp(-x * p[0]) : std::exp(x / p[0]))),
      PDF(x < 0 ? p[0] * p[0] / (1 + p[0] * p[0]) * std::exp(x / p[0]) : 1 - std::exp(-p[0] * x) / (1 + p[0] * p[0])),
      PDF(x >= 0 ? std::exp(-p[0] * x) / (1 + p[0] * p[0]) : 1 - p[0] * p[0] / (1 + p[0] * p[0]) * std::exp(x / p[0])),
      PDF(x < p[0] * p[0] / (1 + p[0] * p[0]) ? p[0] * std::log(x * (1 + p[0] * p[0]) / (p[0] * p[0]))
                                             : -std::log((1 - x) * (1 + p[0] * p[0])) / p[0]));

  add(v, "levy", {}, nullptr, POS, PDF(x <= 0 ? 0.0 : std::exp(-1 / (2 * x)) / std::sqrt(2 * PI * x * x * x)),
      PDF(x <= 0 ? 0.0 : std::erfc(1 / std::sqrt(2 * x))), PDF(x <= 0 ? 1.0 : std::erf(1 / std::sqrt(2 * x))),
      PDF(1 / (2 * sf::erfcinv(x) * sf::erfcinv(x))), PDF(1 / (2 * sf::erfinv(x) * sf::erfinv(x))));

  add(v, "levy_l", {}, nullptr, SUPP(a = -Inf; b = 0),
      PDF(x >= 0 ? 0.0 : std::exp(1 / (2 * x)) / std::sqrt(-2 * PI * x * x * x)),
      PDF(x >= 0 ? 1.0 : std::erf(1 / std::sqrt(-2 * x))), PDF(x >= 0 ? 0.0 : std::erfc(1 / std::sqrt(-2 * x))),
      PDF(-1 / (2 * sf::erfinv(x) * sf::erfinv(x))), PDF(-1 / (2 * sf::erfcinv(x) * sf::erfcinv(x))));

  add(v, "levy_stable", {"alpha", "beta"}, OK(p[0] > 0 && p[0] <= 2 && p[1] >= -1 && p[1] <= 1), nullptr,
      PDF(stablePdf(x, p[0], p[1])), PDF(stableCdf(x, p[0], p[1])), nullptr, nullptr);
  v.back().rvs = stableRvs;

  add(v, "loggamma", {"c"}, OK(p[0] > 0), nullptr, PDF(std::exp(p[0] * x - std::exp(x) - std::lgamma(p[0]))),
      PDF(sf::gammainc(p[0], std::exp(x))), PDF(sf::gammaincc(p[0], std::exp(x))),
      PDF(std::log(sf::gammaincinv(p[0], x))), PDF(std::log(sf::gammainccinv(p[0], x))));

  add(v, "logistic", {}, nullptr, nullptr,
      PDF(std::exp(-std::fabs(x)) / ((1 + std::exp(-std::fabs(x))) * (1 + std::exp(-std::fabs(x))))),
      PDF(x >= 0 ? 1 / (1 + std::exp(-x)) : std::exp(x) / (1 + std::exp(x))),
      PDF(x >= 0 ? std::exp(-x) / (1 + std::exp(-x)) : 1 / (1 + std::exp(x))), PDF(std::log(x / (1 - x))),
      PDF(std::log((1 - x) / x)));

  add(v, "loglaplace", {"c"}, OK(p[0] > 0), POS,
      PDF(x <= 0 ? 0.0 : (x < 1 ? p[0] / 2 * std::pow(x, p[0] - 1) : p[0] / 2 * std::pow(x, -p[0] - 1))),
      PDF(x < 1 ? 0.5 * std::pow(x, p[0]) : 1 - 0.5 * std::pow(x, -p[0])),
      PDF(x < 1 ? 1 - 0.5 * std::pow(x, p[0]) : 0.5 * std::pow(x, -p[0])),
      PDF(x < 0.5 ? std::pow(2 * x, 1 / p[0]) : std::pow(2 * (1 - x), -1 / p[0])));

  add(v, "lognorm", {"s"}, OK(p[0] > 0), POS, PDF(x <= 0 ? 0.0 : phi(std::log(x) / p[0]) / (p[0] * x)),
      PDF(x <= 0 ? 0.0 : sf::ndtr(std::log(x) / p[0])), PDF(x <= 0 ? 1.0 : sf::ndtr(-std::log(x) / p[0])),
      PDF(std::exp(p[0] * sf::ndtri(x))), PDF(std::exp(-p[0] * sf::ndtri(x))));

  for (const char *nm : {"loguniform", "reciprocal"})
    add(v, nm, {"a", "b"}, OK(p[0] > 0 && p[1] > p[0]), SUPP(a = p[0]; b = p[1]),
        PDF(1 / (x * std::log(p[1] / p[0]))), PDF(std::log(x / p[0]) / std::log(p[1] / p[0])),
        PDF(std::log(p[1] / x) / std::log(p[1] / p[0])), PDF(std::exp(std::log(p[0]) + x * std::log(p[1] / p[0]))));

  add(v, "lomax", {"c"}, OK(p[0] > 0), POS, PDF(p[0] * std::exp(-(p[0] + 1) * std::log1p(x))),
      PDF(-std::expm1(-p[0] * std::log1p(x))), PDF(std::exp(-p[0] * std::log1p(x))),
      PDF(std::expm1(-std::log1p(-x) / p[0])), PDF(std::expm1(-std::log(x) / p[0])));

  add(v, "maxwell", {}, nullptr, POS, PDF(std::sqrt(2 / PI) * x * x * std::exp(-x * x / 2)),
      PDF(sf::gammainc(1.5, x * x / 2)), PDF(sf::gammaincc(1.5, x * x / 2)), PDF(std::sqrt(2 * sf::gammaincinv(1.5, x))),
      PDF(std::sqrt(2 * sf::gammainccinv(1.5, x))));

  add(v, "mielke", {"k", "s"}, OK(p[0] > 0 && p[1] > 0), POS,
      PDF(p[0] * std::pow(x, p[0] - 1) * std::pow(1 + std::pow(x, p[1]), -1 - p[0] / p[1])),
      PDF(std::pow(x, p[0]) * std::pow(1 + std::pow(x, p[1]), -p[0] / p[1])), nullptr,
      PDF(std::pow(std::pow(x, p[1] / p[0]) / (1 - std::pow(x, p[1] / p[0])), 1 / p[1])));

  add(v, "moyal", {}, nullptr, nullptr, PDF(std::exp(-(x + std::exp(-x)) / 2) / std::sqrt(2 * PI)),
      PDF(std::erfc(std::exp(-x / 2) / std::sqrt(2.0))), PDF(std::erf(std::exp(-x / 2) / std::sqrt(2.0))),
      PDF(-std::log(2 * sf::erfcinv(x) * sf::erfcinv(x))), PDF(-std::log(2 * sf::erfinv(x) * sf::erfinv(x))));

  add(v, "nakagami", {"nu"}, OK(p[0] > 0), POS,
      PDF(x <= 0 ? 0.0 : 2 * std::exp(p[0] * std::log(p[0]) - std::lgamma(p[0]) + (2 * p[0] - 1) * std::log(x) - p[0] * x * x)),
      PDF(sf::gammainc(p[0], p[0] * x * x)), PDF(sf::gammaincc(p[0], p[0] * x * x)),
      PDF(std::sqrt(sf::gammaincinv(p[0], x) / p[0])), PDF(std::sqrt(sf::gammainccinv(p[0], x) / p[0])));

  add(v, "ncf", {"dfn", "dfd", "nc"}, OK(p[0] > 0 && p[1] > 0 && p[2] >= 0), POS, PDF(sf::ncf_pdf(x, p[0], p[1], p[2])),
      PDF(sf::ncfdtr(p[0], p[1], p[2], x)), nullptr, PDF(sf::ncfdtri(p[0], p[1], p[2], x)));

  add(v, "nct", {"df", "nc"}, OK(p[0] > 0), nullptr, PDF(sf::nct_pdf(x, p[0], p[1])), PDF(sf::nctdtr(p[0], p[1], x)),
      nullptr, PDF(sf::nctdtrit(p[0], p[1], x)));

  add(v, "ncx2", {"df", "nc"}, OK(p[0] > 0 && p[1] >= 0), POS, PDF(sf::ncx2_pdf(x, p[0], p[1])),
      PDF(sf::chndtr(x, p[0], p[1])), nullptr, PDF(sf::chndtrix(x, p[0], p[1])));

  add(v, "norm", {}, nullptr, nullptr, PDF(phi(x)), PDF(sf::ndtr(x)), PDF(sf::ndtr(-x)), PDF(sf::ndtri(x)),
      PDF(-sf::ndtri(x)));

  add(v, "norminvgauss", {"a", "b"}, OK(p[0] > 0 && std::fabs(p[1]) < p[0]), nullptr,
      PDF(p[0] / (PI * std::sqrt(1 + x * x)) * sf::besselk(1, p[0] * std::sqrt(1 + x * x), true) *
          std::exp(std::sqrt(p[0] * p[0] - p[1] * p[1]) + p[1] * x - p[0] * std::sqrt(1 + x * x))),
      nullptr, nullptr, nullptr);

  add(v, "pareto", {"b"}, OK(p[0] > 0), SUPP(a = 1; b = Inf), PDF(p[0] * std::pow(x, -p[0] - 1)),
      PDF(-std::expm1(-p[0] * std::log(x))), PDF(std::pow(x, -p[0])), PDF(std::exp(-std::log1p(-x) / p[0])),
      PDF(std::pow(x, -1 / p[0])));

  add(v, "pearson3", {"skew"}, nullptr,
      SUPP(if (std::fabs(p[0]) < 1.6e-5) {
        a = -Inf;
        b = Inf;
      } else if (p[0] > 0) {
        a = -2 / p[0];
        b = Inf;
      } else {
        a = -Inf;
        b = -2 / p[0];
      }),
      PDF(std::fabs(p[0]) < 1.6e-5 ? phi(x) : std::fabs(2 / p[0]) * gammaPdf(2 / p[0] * (x + 2 / p[0]), 4 / (p[0] * p[0]))),
      PDF(std::fabs(p[0]) < 1.6e-5 ? sf::ndtr(x)
                                   : (p[0] > 0 ? sf::gammainc(4 / (p[0] * p[0]), 2 / p[0] * (x + 2 / p[0]))
                                               : sf::gammaincc(4 / (p[0] * p[0]), 2 / p[0] * (x + 2 / p[0])))),
      PDF(std::fabs(p[0]) < 1.6e-5 ? sf::ndtr(-x)
                                   : (p[0] > 0 ? sf::gammaincc(4 / (p[0] * p[0]), 2 / p[0] * (x + 2 / p[0]))
                                               : sf::gammainc(4 / (p[0] * p[0]), 2 / p[0] * (x + 2 / p[0])))),
      PDF(std::fabs(p[0]) < 1.6e-5 ? sf::ndtri(x)
                                   : -2 / p[0] + (p[0] > 0 ? sf::gammaincinv(4 / (p[0] * p[0]), x)
                                                           : sf::gammainccinv(4 / (p[0] * p[0]), x)) /
                                                     (2 / p[0])));

  add(v, "powerlaw", {"a"}, OK(p[0] > 0), UNIT,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 1.0 : 0.0)) : p[0] * std::pow(x, p[0] - 1)), PDF(std::pow(x, p[0])),
      PDF(-std::expm1(p[0] * std::log(x))), PDF(std::pow(x, 1 / p[0])));

  add(v, "powerlognorm", {"c", "s"}, OK(p[0] > 0 && p[1] > 0), POS,
      PDF(x <= 0 ? 0.0 : p[0] / (x * p[1]) * phi(std::log(x) / p[1]) * std::exp((p[0] - 1) * sf::log_ndtr(-std::log(x) / p[1]))),
      PDF(x <= 0 ? 0.0 : -std::expm1(p[0] * sf::log_ndtr(-std::log(x) / p[1]))),
      PDF(x <= 0 ? 1.0 : std::exp(p[0] * sf::log_ndtr(-std::log(x) / p[1]))),
      PDF(std::exp(-p[1] * sf::ndtri(std::pow(1 - x, 1 / p[0])))), PDF(std::exp(-p[1] * sf::ndtri(std::pow(x, 1 / p[0])))));

  add(v, "powernorm", {"c"}, OK(p[0] > 0), nullptr, PDF(p[0] * phi(x) * std::exp((p[0] - 1) * sf::log_ndtr(-x))),
      PDF(-std::expm1(p[0] * sf::log_ndtr(-x))), PDF(std::exp(p[0] * sf::log_ndtr(-x))),
      PDF(-sf::ndtri(std::pow(1 - x, 1 / p[0]))), PDF(-sf::ndtri(std::pow(x, 1 / p[0]))));

  add(v, "rayleigh", {}, nullptr, POS, PDF(x * std::exp(-x * x / 2)), PDF(-std::expm1(-x * x / 2)),
      PDF(std::exp(-x * x / 2)), PDF(std::sqrt(-2 * std::log1p(-x))), PDF(std::sqrt(-2 * std::log(x))));

  add(v, "rdist", {"c"}, OK(p[0] > 0), SUPP(a = -1; b = 1),
      PDF(std::exp((p[0] / 2 - 1) * std::log1p(-x * x) - sf::lbeta(0.5, p[0] / 2))),
      PDF(sf::betainc(p[0] / 2, p[0] / 2, (x + 1) / 2)), PDF(sf::betainc(p[0] / 2, p[0] / 2, (1 - x) / 2)),
      PDF(2 * sf::betaincinv(p[0] / 2, p[0] / 2, x) - 1));

  add(v, "recipinvgauss", {"mu"}, OK(p[0] > 0), POS, PDF(x <= 0 ? 0.0 : invgaussPdf(1 / x, p[0]) / (x * x)),
      PDF(x <= 0 ? 0.0 : invgaussSf(1 / x, p[0])), PDF(x <= 0 ? 1.0 : invgaussCdf(1 / x, p[0])), nullptr);

  add(v, "rel_breitwigner", {"rho"}, OK(p[0] > 0), POS,
      PDF(1 / breitI(p[0]) / ((x * x - p[0] * p[0]) * (x * x - p[0] * p[0]) + p[0] * p[0])), PDF(breitCdf(x, p[0])),
      nullptr, nullptr);

  add(v, "rice", {"b"}, OK(p[0] >= 0), POS,
      PDF(x <= 0 ? 0.0 : x * std::exp(-(x - p[0]) * (x - p[0]) / 2) * sf::besseli(0, x * p[0], true)),
      PDF(sf::chndtr(x * x, 2, p[0] * p[0])), nullptr, PDF(std::sqrt(sf::chndtrix(x, 2, p[0] * p[0]))));

  add(v, "semicircular", {}, nullptr, SUPP(a = -1; b = 1), PDF(2 / PI * std::sqrt(1 - x * x)),
      PDF(0.5 + (x * std::sqrt(1 - x * x) + std::asin(x)) / PI), PDF(0.5 - (x * std::sqrt(1 - x * x) + std::asin(x)) / PI),
      nullptr);

  add(v, "skewcauchy", {"a"}, OK(std::fabs(p[0]) < 1), nullptr,
      PDF(1 / (PI * (x * x / ((p[0] * (x < 0 ? -1.0 : 1.0) + 1) * (p[0] * (x < 0 ? -1.0 : 1.0) + 1)) + 1))),
      PDF(skewcauchyCdf(x, p[0])), PDF(1 - skewcauchyCdf(x, p[0])), PDF(skewcauchyPpf(x, p[0])));

  add(v, "skewnorm", {"a"}, nullptr, nullptr, PDF(2 * phi(x) * sf::ndtr(p[0] * x)),
      PDF(std::min(1.0, std::max(0.0, sf::ndtr(x) - 2 * sf::owens_t(x, p[0])))),
      PDF(std::min(1.0, std::max(0.0, sf::ndtr(-x) - 2 * sf::owens_t(-x, -p[0])))), nullptr);

  add(v, "studentized_range", {"k", "df"}, OK(p[0] > 1 && p[1] > 0), POS, PDF(srangePdf(x, p[0], p[1])),
      PDF(srangeCdf(x, p[0], p[1])), nullptr, nullptr);
  v.back().rvs = srangeRvs;

  add(v, "t", {"df"}, OK(p[0] > 0), nullptr,
      PDF(std::isinf(p[0]) ? phi(x)
                           : std::exp(std::lgamma((p[0] + 1) / 2) - std::lgamma(p[0] / 2) - 0.5 * std::log(p[0] * PI) -
                                      (p[0] + 1) / 2 * std::log1p(x * x / p[0]))),
      PDF(sf::stdtr(p[0], x)), PDF(sf::stdtr(p[0], -x)), PDF(sf::stdtrit(p[0], x)), PDF(-sf::stdtrit(p[0], x)));

  add(v, "trapezoid", {"c", "d"}, OK(p[0] >= 0 && p[1] <= 1 && p[0] <= p[1]), UNIT,
      PDF(x < p[0] ? trapU(p) * x / p[0] : (x <= p[1] ? trapU(p) : trapU(p) * (1 - x) / (1 - p[1]))),
      PDF(x < p[0] ? trapU(p) * x * x / (2 * p[0])
                   : (x <= p[1] ? trapU(p) * (x - p[0] / 2) : 1 - trapU(p) * (1 - x) * (1 - x) / (2 * (1 - p[1])))),
      nullptr,
      PDF(x < trapU(p) * p[0] / 2 ? std::sqrt(2 * x * p[0] / trapU(p))
                                  : (x <= 1 - trapU(p) * (1 - p[1]) / 2 ? x / trapU(p) + p[0] / 2
                                                                        : 1 - std::sqrt(2 * (1 - x) * (1 - p[1]) / trapU(p)))));

  add(v, "triang", {"c"}, OK(p[0] >= 0 && p[0] <= 1), UNIT,
      PDF(x < p[0] ? 2 * x / p[0] : 2 * (1 - x) / (1 - p[0])),
      PDF(x < p[0] ? x * x / p[0] : 1 - (1 - x) * (1 - x) / (1 - p[0])),
      PDF(x < p[0] ? 1 - x * x / p[0] : (1 - x) * (1 - x) / (1 - p[0])),
      PDF(x < p[0] ? std::sqrt(p[0] * x) : 1 - std::sqrt((1 - p[0]) * (1 - x))));

  add(v, "truncexpon", {"b"}, OK(p[0] > 0), SUPP(a = 0; b = p[0]), PDF(std::exp(-x) / -std::expm1(-p[0])),
      PDF(std::expm1(-x) / std::expm1(-p[0])), PDF((std::exp(-x) - std::exp(-p[0])) / -std::expm1(-p[0])),
      PDF(-std::log1p(x * std::expm1(-p[0]))));

  add(v, "truncnorm", {"a", "b"}, OK(p[0] < p[1]), SUPP(a = p[0]; b = p[1]),
      PDF(std::exp(-x * x / 2 - truncnormLogZ(p[0], p[1])) / std::sqrt(2 * PI)), PDF(truncnormCdf(x, p[0], p[1])),
      PDF(truncnormSf(x, p[0], p[1])), PDF(truncnormPpf(x, p[0], p[1])));

  add(v, "truncpareto", {"b", "c"}, OK(p[0] != 0 && p[1] > 1), SUPP(a = 1; b = p[1]),
      PDF(p[0] * std::pow(x, -p[0] - 1) / -std::expm1(-p[0] * std::log(p[1]))),
      PDF(-std::expm1(-p[0] * std::log(x)) / -std::expm1(-p[0] * std::log(p[1]))), nullptr,
      PDF(std::pow(1 - x * -std::expm1(-p[0] * std::log(p[1])), -1 / p[0])));

  add(v, "truncweibull_min", {"c", "a", "b"}, OK(p[0] > 0 && p[1] >= 0 && p[2] > p[1]), SUPP(a = p[1]; b = p[2]),
      PDF(p[0] * std::pow(x, p[0] - 1) * std::exp(-std::pow(x, p[0])) /
          (std::exp(-std::pow(p[1], p[0])) - std::exp(-std::pow(p[2], p[0])))),
      PDF((std::exp(-std::pow(p[1], p[0])) - std::exp(-std::pow(x, p[0]))) /
          (std::exp(-std::pow(p[1], p[0])) - std::exp(-std::pow(p[2], p[0])))),
      PDF((std::exp(-std::pow(x, p[0])) - std::exp(-std::pow(p[2], p[0]))) /
          (std::exp(-std::pow(p[1], p[0])) - std::exp(-std::pow(p[2], p[0])))),
      PDF(std::pow(-std::log(std::exp(-std::pow(p[1], p[0])) -
                             x * (std::exp(-std::pow(p[1], p[0])) - std::exp(-std::pow(p[2], p[0])))),
                   1 / p[0])));

  add(v, "tukeylambda", {"lam"}, nullptr, SUPP(if (p[0] > 0) {
        a = -1 / p[0];
        b = 1 / p[0];
      } else {
        a = -Inf;
        b = Inf;
      }),
      PDF(1 / (std::pow(sf::tklmbda(x, p[0]), p[0] - 1) + std::pow(1 - sf::tklmbda(x, p[0]), p[0] - 1))),
      PDF(sf::tklmbda(x, p[0])), PDF(sf::tklmbda(-x, p[0])),
      PDF(p[0] == 0 ? std::log(x / (1 - x)) : (std::pow(x, p[0]) - std::pow(1 - x, p[0])) / p[0]));

  add(v, "uniform", {}, nullptr, UNIT, PDF(1.0), PDF(x), PDF(1 - x), PDF(x), PDF(1 - x));

  for (const char *nm : {"vonmises", "vonmises_line"})
    add(v, nm, {"kappa"}, OK(p[0] > 0), SUPP(a = -PI; b = PI), PDF(vonmisesPdf(x, p[0])), PDF(vonmisesCdf(x, p[0])),
        PDF(vonmisesCdf(-x, p[0])), nullptr);

  add(v, "wald", {}, nullptr, POS, PDF(invgaussPdf(x, 1.0)), PDF(invgaussCdf(x, 1.0)), PDF(invgaussSf(x, 1.0)), nullptr);

  add(v, "weibull_max", {"c"}, OK(p[0] > 0), SUPP(a = -Inf; b = 0),
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 1.0 : 0.0)) : p[0] * std::pow(-x, p[0] - 1) * std::exp(-std::pow(-x, p[0]))),
      PDF(std::exp(-std::pow(-x, p[0]))), PDF(-std::expm1(-std::pow(-x, p[0]))), PDF(-std::pow(-std::log(x), 1 / p[0])),
      PDF(-std::pow(-std::log1p(-x), 1 / p[0])));

  add(v, "weibull_min", {"c"}, OK(p[0] > 0), POS,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 1.0 : 0.0)) : p[0] * std::pow(x, p[0] - 1) * std::exp(-std::pow(x, p[0]))),
      PDF(-std::expm1(-std::pow(x, p[0]))), PDF(std::exp(-std::pow(x, p[0]))), PDF(std::pow(-std::log1p(-x), 1 / p[0])),
      PDF(std::pow(-std::log(x), 1 / p[0])));

  add(v, "wrapcauchy", {"c"}, OK(p[0] > 0 && p[0] < 1), SUPP(a = 0; b = 2 * PI),
      PDF((1 - p[0] * p[0]) / (2 * PI * (1 + p[0] * p[0] - 2 * p[0] * std::cos(x)))),
      PDF(x < PI ? std::atan((1 + p[0]) / (1 - p[0]) * std::tan(x / 2)) / PI
                 : 1 - std::atan((1 + p[0]) / (1 - p[0]) * std::tan((2 * PI - x) / 2)) / PI),
      nullptr,
      PDF(x < 0.5 ? 2 * std::atan(std::tan(PI * x) * (1 - p[0]) / (1 + p[0]))
                  : 2 * PI - 2 * std::atan(std::tan(PI * (1 - x)) * (1 - p[0]) / (1 + p[0]))));
}

void addContA(std::vector<Family> &v);

void addContinuous(std::vector<Family> &v) {
  addContA(v);
  addContB(v);
}

} // namespace pd
} // namespace scipy
} // namespace nc
