// The distribution engine behind the name_pdf / _cdf / _sf / _ppf / _rvs
// families of section 22 and the distribution objects of section 21.
//
// A family gives its standardized functions (loc 0, scale 1) where a closed
// form exists; the engine fills the rest: cdf by quadrature of the pdf, sf as
// 1 - cdf, ppf by root finding on the cdf, rvs by inverting uniforms. Kernels
// are pure numbers, so the element-wise loops may run on worker threads.
#ifndef NC_SCIPY_PD_ENGINE_H
#define NC_SCIPY_PD_ENGINE_H

#include <random>
#include <string>
#include <vector>

#include "../special_functions/sf_poly.h"

namespace nc {
namespace scipy {
namespace pd {

using sf::Inf;
using sf::NaN;
using sf::PI;

using Fn = double (*)(double x, const double *p);
using Ok = bool (*)(const double *p);
using Supp = void (*)(const double *p, double &a, double &b);

struct Family {
  std::string name;
  bool discrete = false;
  int nshape = 0;
  std::vector<std::string> shapeNames;
  Ok ok = nullptr;     // shape check; null = always valid
  Supp supp = nullptr; // support of the standardized law; null = (-inf, inf) / integers >= 0
  Fn pdf = nullptr;    // pmf for discrete families
  Fn cdf = nullptr;
  Fn sf = nullptr;
  Fn ppf = nullptr;
  Fn isf = nullptr;
  // Array-valued shape (poisson_binom): the whole array is passed through p.
  bool arrayShape = false;
  // Direct sampler of the standardized law, when inversion would be slow.
  double (*rvs)(std::mt19937_64 &g, const double *p) = nullptr;
};

// All families, in the order of the mapping table.
const std::vector<Family> &families();
const Family *findFamily(const std::string &name);

// Standardized evaluation with the engine's fallbacks.
bool shapesOk(const Family &f, const double *p);
void support(const Family &f, const double *p, double &a, double &b);
double pdf(const Family &f, double x, const double *p);
double cdf(const Family &f, double x, const double *p);
double sf(const Family &f, double x, const double *p);
double ppf(const Family &f, double q, const double *p);
double isf(const Family &f, double q, const double *p);

// With loc and scale (scale ignored for discrete families).
double pdfLS(const Family &f, double x, const double *p, double loc, double scale);
double cdfLS(const Family &f, double x, const double *p, double loc, double scale);
double sfLS(const Family &f, double x, const double *p, double loc, double scale);
double ppfLS(const Family &f, double q, const double *p, double loc, double scale);
double rvsLS(const Family &f, std::mt19937_64 &g, const double *p, double loc, double scale);

// Moments by quadrature (or summation): NaN when they do not exist.
double mean(const Family &f, const double *p);
double variance(const Family &f, const double *p);

// A uniform number strictly inside (0, 1) from 53 random bits.
double uniform01(std::mt19937_64 &g);
double stdNormal(std::mt19937_64 &g);
double stdGamma(std::mt19937_64 &g, double a);

} // namespace pd
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_PD_ENGINE_H
