// Helpers for writing distribution families (pd_cont_*.cpp, pd_discrete.cpp):
// short lambdas as function pointers, and formulas shared by several laws.
#ifndef NC_SCIPY_PD_COMMON_H
#define NC_SCIPY_PD_COMMON_H

#include <cmath>
#include <initializer_list>

#include "pd_engine.h"

namespace nc {
namespace scipy {
namespace pd {

// x is the value (or the probability for ppf / isf), p the shape parameters.
#define PDF(expr) (+[](double x, const double *p) -> double { (void)p; (void)x; return (expr); })
#define OK(cond) (+[](const double *p) -> bool { return (cond); })
#define SUPP(body) (+[](const double *p, double &a, double &b) { (void)p; body; })
#define POS SUPP(a = 0; b = Inf)
#define UNIT SUPP(a = 0; b = 1)

inline void add(std::vector<Family> &v, const char *name, std::initializer_list<const char *> shapes, Ok ok, Supp supp,
                Fn pdf, Fn cdf, Fn sf, Fn ppf, Fn isf = nullptr, bool discrete = false) {
  Family f;
  f.name = name;
  f.discrete = discrete;
  for (const char *s : shapes)
    f.shapeNames.push_back(s);
  f.nshape = static_cast<int>(f.shapeNames.size());
  f.ok = ok;
  f.supp = supp;
  f.pdf = pdf;
  f.cdf = cdf;
  f.sf = sf;
  f.ppf = ppf;
  f.isf = isf;
  v.push_back(f);
}

inline double phi(double x) { return std::exp(-x * x / 2) / std::sqrt(2 * PI); }
inline double softplus(double x) { return x > 0 ? x + std::log1p(std::exp(-x)) : std::log1p(std::exp(x)); }
inline double ratioOdds(double y) { return y / (1 - y); }

inline double gammaPdf(double x, double a) {
  if (x < 0)
    return 0.0;
  if (x == 0)
    return a < 1 ? Inf : (a == 1 ? 1.0 : 0.0);
  return std::exp((a - 1) * std::log(x) - x - std::lgamma(a));
}

inline double chi2Pdf(double x, double df) {
  if (x < 0)
    return 0.0;
  if (x == 0)
    return df < 2 ? Inf : (df == 2 ? 0.5 : 0.0);
  return std::exp((df / 2 - 1) * std::log(x) - x / 2 - df / 2 * std::log(2.0) - std::lgamma(df / 2));
}

inline double betaPdf(double x, double a, double b) {
  if (x < 0 || x > 1)
    return 0.0;
  if (x == 0)
    return a < 1 ? Inf : (a == 1 ? b : 0.0);
  if (x == 1)
    return b < 1 ? Inf : (b == 1 ? a : 0.0);
  return std::exp((a - 1) * std::log(x) + (b - 1) * std::log1p(-x) - sf::lbeta(a, b));
}

inline double fPdf(double x, double m, double n) {
  if (x < 0)
    return 0.0;
  if (x == 0)
    return m < 2 ? Inf : (m == 2 ? 1.0 : 0.0);
  return std::exp(m / 2 * std::log(m / n) + (m / 2 - 1) * std::log(x) - (m + n) / 2 * std::log1p(m * x / n) -
                  sf::lbeta(m / 2, n / 2));
}

inline double fatigueInv(double t) { return 0.25 * (t + std::sqrt(t * t + 4)) * (t + std::sqrt(t * t + 4)); }

inline double crystalN(double be, double m) {
  return 1.0 / (m / be / (m - 1) * std::exp(-be * be / 2) + std::sqrt(PI / 2) * (1 + std::erf(be / std::sqrt(2.0))));
}
inline double crystalPdf(double x, double be, double m) {
  double N = crystalN(be, m);
  if (x > -be)
    return N * std::exp(-x * x / 2);
  double A = std::pow(m / be, m) * std::exp(-be * be / 2), B = m / be - be;
  return N * A * std::pow(B - x, -m);
}
inline double crystalCdf(double x, double be, double m) {
  double N = crystalN(be, m);
  if (x <= -be) {
    double A = std::pow(m / be, m) * std::exp(-be * be / 2), B = m / be - be;
    return N * A * std::pow(B - x, 1 - m) / (m - 1);
  }
  return N * (m / be / (m - 1) * std::exp(-be * be / 2) + std::sqrt(2 * PI) * (sf::ndtr(x) - sf::ndtr(-be)));
}

// Double Pareto lognormal (Reed & Jorgensen), u = nu, s = tau, a = alpha, b = beta.
inline void dplnTerms(double x, const double *p, double &z, double &t1, double &t2) {
  double u = p[0], s = p[1], a = p[2], b = p[3];
  double y = std::log(x) - u;
  z = y / s;
  t1 = std::exp(-a * y + a * a * s * s / 2 + sf::log_ndtr(z - a * s));
  t2 = std::exp(b * y + b * b * s * s / 2 + sf::log_ndtr(-(z + b * s)));
}
inline double dplnPdf(double x, const double *p) {
  if (x <= 0)
    return 0.0;
  double z, t1, t2;
  dplnTerms(x, p, z, t1, t2);
  return p[2] * p[3] / (p[2] + p[3]) / x * (t1 + t2);
}
inline double dplnCdf(double x, const double *p) {
  if (x <= 0)
    return 0.0;
  double z, t1, t2;
  dplnTerms(x, p, z, t1, t2);
  return sf::ndtr(z) - (p[3] * t1 - p[2] * t2) / (p[2] + p[3]);
}

inline double exponnormPdf(double x, double K) {
  double t = (1 / K - x) / std::sqrt(2.0);
  if (t >= 0)
    return sf::erfcx(t) * std::exp(-x * x / 2) / (2 * K);
  return std::exp(1 / (2 * K * K) - x / K) * std::erfc(t) / (2 * K);
}
inline double exponnormCdf(double x, double K) {
  return sf::ndtr(x) - std::exp(1 / (2 * K * K) - x / K + sf::log_ndtr(x - 1 / K));
}

inline double genextT(double x, double c) {
  if (c == 0)
    return std::exp(-x);
  double t = 1 - c * x;
  if (t <= 0)
    return c > 0 ? 0.0 : Inf;
  return std::pow(t, 1 / c);
}
inline double genextPdf(double x, double c) {
  if (c == 0)
    return std::exp(-x - std::exp(-x));
  double t = 1 - c * x;
  if (t <= 0)
    return 0.0;
  return std::exp((1 / c - 1) * std::log(t) - std::pow(t, 1 / c));
}

inline double genhypPdf(double x, const double *p) {
  double pp = p[0], a = p[1], b = p[2];
  double g = std::sqrt(a * a - b * b), r = std::sqrt(1 + x * x), z = a * r;
  double l = pp * std::log(g) - 0.5 * std::log(2 * PI) - (pp - 0.5) * std::log(a) + (pp - 0.5) / 2 * std::log(1 + x * x);
  return std::exp(l + b * x - z + g) * sf::besselk(pp - 0.5, z, true) / sf::besselk(pp, g, true);
}

} // namespace pd
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_PD_COMMON_H
