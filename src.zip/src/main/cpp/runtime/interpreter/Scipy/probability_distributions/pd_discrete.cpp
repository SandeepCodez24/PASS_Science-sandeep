// Discrete families: standardized pmf / cdf / sf / ppf (loc 0) in the forms
// SciPy uses. Values off the integers or outside the support are handled by
// the engine.
#include "pd_common.h"

#include <algorithm>

namespace nc {
namespace scipy {
namespace pd {

namespace {
double lchoose(double n, double k) { return std::lgamma(n + 1) - std::lgamma(k + 1) - std::lgamma(n - k + 1); }
bool whole(double v) { return v == std::floor(v); }

void hyperSupp(const double *p, double &a, double &b) {
  a = std::max(0.0, p[2] - (p[0] - p[1]));
  b = std::min(p[1], p[2]);
}
bool hyperOk(const double *p) {
  return whole(p[0]) && whole(p[1]) && whole(p[2]) && p[0] >= 0 && p[1] >= 0 && p[2] >= 0 && p[1] <= p[0] && p[2] <= p[0];
}

double fisherPmf(double k, const double *p) {
  double a, b;
  hyperSupp(p, a, b);
  double lw = std::log(p[3]);
  auto term = [&](double j) { return lchoose(p[1], j) + lchoose(p[0] - p[1], p[2] - j) + j * lw; };
  double mx = -Inf;
  for (double j = a; j <= b; j++)
    mx = std::max(mx, term(j));
  double s = 0.0;
  for (double j = a; j <= b; j++)
    s += std::exp(term(j) - mx);
  return std::exp(term(k) - mx) / s;
}

double walleniusPmf(double k, const double *p) {
  double M = p[0], n = p[1], N = p[2], w = p[3];
  double D = w * (n - k) + ((M - n) - (N - k));
  double lc = lchoose(n, k) + lchoose(M - n, N - k);
  if (D <= 0) // every remaining item is drawn
    return k == std::min(n, N) ? 1.0 : 0.0;
  auto f = [&](double t) {
    if (t <= 0)
      return 0.0;
    double a1 = -std::expm1(w / D * std::log(t)), a2 = -std::expm1(std::log(t) / D);
    double l = (k > 0 ? k * std::log(a1) : 0.0) + (N - k > 0 ? (N - k) * std::log(a2) : 0.0);
    return std::exp(lc + l);
  };
  return sf::quad(f, 0.0, 1.0, 0.0, 1e-13, 2000);
}

double zipfianH(double k, double a) {
  if (k <= 1e6) {
    double s = 0.0;
    for (double j = k; j >= 1; j--) // small terms first
      s += std::pow(j, -a);
    return s;
  }
  if (a > 1)
    return sf::zeta(a, 1.0) - sf::zeta(a, k + 1);
  double s = 0.0;
  for (double j = 1; j <= k; j++)
    s += std::pow(j, -a);
  return s;
}
} // namespace

void addDiscrete(std::vector<Family> &v) {
  auto D = [&](const char *name, std::initializer_list<const char *> s, Ok ok, Supp supp, Fn pmf, Fn cdf, Fn sfn,
               Fn ppf) { add(v, name, s, ok, supp, pmf, cdf, sfn, ppf, nullptr, true); };

  D("bernoulli", {"p"}, OK(p[0] >= 0 && p[0] <= 1), UNIT, PDF(x == 0 ? 1 - p[0] : p[0]), PDF(x < 1 ? 1 - p[0] : 1.0),
    PDF(x < 1 ? p[0] : 0.0), nullptr);

  D("betabinom", {"n", "a", "b"}, OK(p[0] >= 0 && whole(p[0]) && p[1] > 0 && p[2] > 0), SUPP(a = 0; b = p[0]),
    PDF(std::exp(lchoose(p[0], x) + sf::lbeta(x + p[1], p[0] - x + p[2]) - sf::lbeta(p[1], p[2]))), nullptr, nullptr,
    nullptr);

  D("betanbinom", {"n", "a", "b"}, OK(p[0] > 0 && p[1] > 0 && p[2] > 0), nullptr,
    PDF(std::exp(std::lgamma(p[0] + x) - std::lgamma(x + 1) - std::lgamma(p[0]) + sf::lbeta(p[1] + p[0], p[2] + x) -
                 sf::lbeta(p[1], p[2]))),
    nullptr, nullptr, nullptr);

  D("binom", {"n", "p"}, OK(p[0] >= 0 && whole(p[0]) && p[1] >= 0 && p[1] <= 1), SUPP(a = 0; b = p[0]),
    PDF(p[1] == 0 ? (x == 0 ? 1.0 : 0.0)
                  : (p[1] == 1 ? (x == p[0] ? 1.0 : 0.0)
                               : std::exp(lchoose(p[0], x) + x * std::log(p[1]) + (p[0] - x) * std::log1p(-p[1])))),
    PDF(sf::bdtr(x, p[0], p[1])), PDF(sf::bdtrc(x, p[0], p[1])), nullptr);

  D("boltzmann", {"lambda", "N"}, OK(p[0] > 0 && p[1] >= 1 && whole(p[1])), SUPP(a = 0; b = p[1] - 1),
    PDF(-std::expm1(-p[0]) * std::exp(-p[0] * x) / -std::expm1(-p[0] * p[1])),
    PDF(-std::expm1(-p[0] * (x + 1)) / -std::expm1(-p[0] * p[1])),
    PDF((std::exp(-p[0] * (x + 1)) - std::exp(-p[0] * p[1])) / -std::expm1(-p[0] * p[1])), nullptr);

  D("dlaplace", {"a"}, OK(p[0] > 0), SUPP(a = -Inf; b = Inf), PDF(std::tanh(p[0] / 2) * std::exp(-p[0] * std::fabs(x))),
    PDF(x >= 0 ? 1 - std::exp(-p[0] * x) / (std::exp(p[0]) + 1) : std::exp(p[0] * (x + 1)) / (std::exp(p[0]) + 1)),
    PDF(x >= 0 ? std::exp(-p[0] * x) / (std::exp(p[0]) + 1) : 1 - std::exp(p[0] * (x + 1)) / (std::exp(p[0]) + 1)),
    nullptr);

  D("geom", {"p"}, OK(p[0] > 0 && p[0] <= 1), SUPP(a = 1; b = Inf), PDF(std::exp((x - 1) * std::log1p(-p[0])) * p[0]),
    PDF(-std::expm1(x * std::log1p(-p[0]))), PDF(std::exp(x * std::log1p(-p[0]))), nullptr);

  D("hypergeom", {"M", "n", "N"}, hyperOk, hyperSupp,
    PDF(std::exp(lchoose(p[1], x) + lchoose(p[0] - p[1], p[2] - x) - lchoose(p[0], p[2]))), nullptr, nullptr, nullptr);

  D("logser", {"p"}, OK(p[0] > 0 && p[0] < 1), SUPP(a = 1; b = Inf),
    PDF(-std::exp(x * std::log(p[0])) / (x * std::log1p(-p[0]))), nullptr, nullptr, nullptr);

  D("nbinom", {"n", "p"}, OK(p[0] > 0 && p[1] > 0 && p[1] <= 1), nullptr,
    PDF(p[1] == 1 ? (x == 0 ? 1.0 : 0.0)
                  : std::exp(std::lgamma(p[0] + x) - std::lgamma(x + 1) - std::lgamma(p[0]) + p[0] * std::log(p[1]) +
                             x * std::log1p(-p[1]))),
    PDF(sf::betainc(p[0], x + 1, p[1])), PDF(sf::betaincc(p[0], x + 1, p[1])), nullptr);

  D("nchypergeom_fisher", {"M", "n", "N", "odds"}, OK(hyperOk(p) && p[3] > 0), hyperSupp, fisherPmf, nullptr, nullptr,
    nullptr);

  D("nchypergeom_wallenius", {"M", "n", "N", "odds"}, OK(hyperOk(p) && p[3] > 0), hyperSupp, walleniusPmf, nullptr,
    nullptr, nullptr);

  D("nhypergeom", {"M", "n", "r"},
    OK(whole(p[0]) && whole(p[1]) && whole(p[2]) && p[0] >= 0 && p[1] >= 0 && p[2] >= 0 && p[1] <= p[0] && p[2] <= p[0] - p[1]),
    SUPP(a = 0; b = p[1]),
    PDF(std::exp(lchoose(x + p[2] - 1, x) + lchoose(p[0] - p[2] - x, p[1] - x) - lchoose(p[0], p[1]))), nullptr, nullptr,
    nullptr);

  D("planck", {"lambda"}, OK(p[0] > 0), nullptr, PDF(-std::expm1(-p[0]) * std::exp(-p[0] * x)),
    PDF(-std::expm1(-p[0] * (x + 1))), PDF(std::exp(-p[0] * (x + 1))), nullptr);

  D("poisson", {"mu"}, OK(p[0] >= 0), nullptr,
    PDF(p[0] == 0 ? (x == 0 ? 1.0 : 0.0) : std::exp(x * std::log(p[0]) - p[0] - std::lgamma(x + 1))),
    PDF(sf::pdtr(x, p[0])), PDF(sf::pdtrc(x, p[0])), nullptr);

  D("randint", {"low", "high"}, OK(whole(p[0]) && whole(p[1]) && p[1] > p[0]), SUPP(a = p[0]; b = p[1] - 1),
    PDF(1 / (p[1] - p[0])), PDF((x - p[0] + 1) / (p[1] - p[0])), PDF((p[1] - 1 - x) / (p[1] - p[0])),
    PDF(std::ceil(x * (p[1] - p[0]) + p[0]) - 1));

  D("skellam", {"mu1", "mu2"}, OK(p[0] >= 0 && p[1] >= 0), SUPP(a = -Inf; b = Inf),
    PDF(std::exp(-(p[0] + p[1]) + 2 * std::sqrt(p[0] * p[1]) + x / 2 * std::log(p[0] / p[1])) *
        sf::besseli(std::fabs(x), 2 * std::sqrt(p[0] * p[1]), true)),
    PDF(x < 0 ? sf::chndtr(2 * p[1], -2 * x, 2 * p[0]) : 1 - sf::chndtr(2 * p[0], 2 * (x + 1), 2 * p[1])),
    PDF(x < 0 ? 1 - sf::chndtr(2 * p[1], -2 * x, 2 * p[0]) : sf::chndtr(2 * p[0], 2 * (x + 1), 2 * p[1])), nullptr);
  v.back().rvs = +[](std::mt19937_64 &g, const double *p) -> double { // difference of two Poisson counts
    auto pois = [&g](double mu) {
      double u = uniform01(g), k = 0, pk = std::exp(-mu), c = pk;
      if (mu > 500)
        return std::floor(mu + std::sqrt(mu) * stdNormal(g) + 0.5);
      while (u > c && k < 1e7) {
        k++;
        pk *= mu / k;
        c += pk;
      }
      return k;
    };
    return pois(p[0]) - pois(p[1]);
  };

  D("yulesimon", {"alpha"}, OK(p[0] > 0), SUPP(a = 1; b = Inf), PDF(p[0] * sf::beta(x, p[0] + 1)),
    PDF(1 - x * sf::beta(x, p[0] + 1)), PDF(x * sf::beta(x, p[0] + 1)), nullptr);

  D("zipf", {"a"}, OK(p[0] > 1), SUPP(a = 1; b = Inf), PDF(std::pow(x, -p[0]) / sf::riemann_zeta(p[0])),
    PDF(1 - sf::zeta(p[0], x + 1) / sf::riemann_zeta(p[0])), PDF(sf::zeta(p[0], x + 1) / sf::riemann_zeta(p[0])), nullptr);

  D("zipfian", {"a", "n"}, OK(p[0] >= 0 && p[1] >= 1 && whole(p[1])), SUPP(a = 1; b = p[1]),
    PDF(std::pow(x, -p[0]) / zipfianH(p[1], p[0])), PDF(zipfianH(x, p[0]) / zipfianH(p[1], p[0])), nullptr, nullptr);
}

} // namespace pd
} // namespace scipy
} // namespace nc
