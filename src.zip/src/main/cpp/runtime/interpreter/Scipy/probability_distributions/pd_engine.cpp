// Generic parts of the distribution engine: fallbacks from the pdf, loc and
// scale, moments, and the random number primitives.
#include "pd_engine.h"

#include <algorithm>
#include <cmath>
#include <unordered_map>

namespace nc {
namespace scipy {
namespace pd {

void addContinuous(std::vector<Family> &out);
void addDiscrete(std::vector<Family> &out);

const std::vector<Family> &families() {
  static const std::vector<Family> all = [] {
    std::vector<Family> v;
    addContinuous(v);
    addDiscrete(v);
    return v;
  }();
  return all;
}

const Family *findFamily(const std::string &name) {
  static const std::unordered_map<std::string, const Family *> idx = [] {
    std::unordered_map<std::string, const Family *> m;
    for (const Family &f : families())
      m.emplace(f.name, &f);
    return m;
  }();
  auto it = idx.find(name);
  return it == idx.end() ? nullptr : it->second;
}

bool shapesOk(const Family &f, const double *p) {
  for (int i = 0; i < f.nshape && !f.arrayShape; i++)
    if (std::isnan(p[i]))
      return false;
  return !f.ok || f.ok(p);
}

void support(const Family &f, const double *p, double &a, double &b) {
  if (f.supp) {
    f.supp(p, a, b);
    return;
  }
  if (f.discrete) {
    a = 0;
    b = Inf;
  } else {
    a = -Inf;
    b = Inf;
  }
}

namespace {
// A point near the middle of the law, to split integrals and start searches.
double centre(const Family &f, const double *p) {
  double a, b;
  support(f, p, a, b);
  if (std::isfinite(a) && std::isfinite(b))
    return 0.5 * (a + b);
  if (f.ppf) {
    double m = f.ppf(0.5, p);
    if (std::isfinite(m))
      return m;
  }
  if (std::isfinite(a))
    return a + 1.0;
  if (std::isfinite(b))
    return b - 1.0;
  return 0.0;
}

double integratePdf(const Family &f, const double *p, double lo, double hi) {
  if (!(hi > lo))
    return 0.0;
  auto g = [&](double t) {
    double v = f.pdf(t, p);
    return std::isfinite(v) ? v : 0.0;
  };
  double c = centre(f, p);
  // split at the centre so that infinite pieces are mapped around the mass
  if (std::isinf(lo) && std::isinf(hi))
    return sf::quad(g, -Inf, c, 0.0, 1e-13, 400) + sf::quad(g, c, Inf, 0.0, 1e-13, 400);
  if (std::isinf(lo) && c < hi)
    return sf::quad(g, -Inf, c, 0.0, 1e-13, 400) + sf::quad(g, c, hi, 0.0, 1e-13, 400);
  if (std::isinf(hi) && c > lo)
    return sf::quad(g, lo, c, 0.0, 1e-13, 400) + sf::quad(g, c, Inf, 0.0, 1e-13, 400);
  return sf::quad(g, lo, hi, 0.0, 1e-13, 400);
}

double sumPmf(const Family &f, const double *p, double from, double to) {
  // inclusive integer range; stops when terms vanish past the bulk
  double s = 0.0;
  if (to < from)
    return 0.0;
  long long cnt = 0;
  for (double k = from; k <= to; k += 1.0) {
    double v = f.pdf(k, p);
    if (std::isfinite(v))
      s += v;
    if (++cnt > 5000000)
      break;
    if (std::isinf(to) && cnt > 50 && v < 1e-18 * s)
      break;
  }
  return s;
}
} // namespace

double pdf(const Family &f, double x, const double *p) {
  if (std::isnan(x) || !shapesOk(f, p))
    return NaN;
  double a, b;
  support(f, p, a, b);
  if (f.discrete) {
    if (x != std::floor(x) || x < a || x > b)
      return 0.0;
  } else if (x < a || x > b) {
    return 0.0;
  }
  return f.pdf(x, p);
}

double cdf(const Family &f, double x, const double *p) {
  if (std::isnan(x) || !shapesOk(f, p))
    return NaN;
  double a, b;
  support(f, p, a, b);
  if (f.discrete) {
    x = std::floor(x);
    if (x < a)
      return 0.0;
    if (x >= b)
      return 1.0;
    if (f.cdf)
      return f.cdf(x, p);
    if (f.sf)
      return 1.0 - f.sf(x, p);
    return std::min(1.0, sumPmf(f, p, a, x));
  }
  if (x <= a)
    return 0.0;
  if (x >= b)
    return 1.0;
  if (f.cdf)
    return f.cdf(x, p);
  if (f.sf)
    return 1.0 - f.sf(x, p);
  double c = centre(f, p);
  if (x <= c)
    return std::min(1.0, integratePdf(f, p, a, x));
  return std::max(0.0, 1.0 - integratePdf(f, p, x, b));
}

double sf(const Family &f, double x, const double *p) {
  if (std::isnan(x) || !shapesOk(f, p))
    return NaN;
  double a, b;
  support(f, p, a, b);
  if (f.discrete) {
    x = std::floor(x);
    if (x < a)
      return 1.0;
    if (x >= b)
      return 0.0;
    if (f.sf)
      return f.sf(x, p);
    if (f.cdf)
      return 1.0 - f.cdf(x, p);
    if (std::isfinite(b))
      return std::max(0.0, sumPmf(f, p, x + 1, b));
    return std::max(0.0, 1.0 - sumPmf(f, p, a, x));
  }
  if (x <= a)
    return 1.0;
  if (x >= b)
    return 0.0;
  if (f.sf)
    return f.sf(x, p);
  if (f.cdf) // stay consistent with the closed-form cdf
    return 1.0 - f.cdf(x, p);
  double c = centre(f, p);
  if (x >= c)
    return std::min(1.0, integratePdf(f, p, x, b));
  return std::max(0.0, 1.0 - integratePdf(f, p, a, x));
}

double ppf(const Family &f, double q, const double *p) {
  if (std::isnan(q) || q < 0 || q > 1 || !shapesOk(f, p))
    return NaN;
  double a, b;
  support(f, p, a, b);
  if (f.discrete) {
    if (q == 0)
      return a - 1;
    if (q == 1)
      return b;
    if (f.ppf) {
      double r = f.ppf(q, p);
      if (!std::isnan(r))
        return r;
    }
    // smallest integer k with cdf(k) >= q
    double lo = std::isfinite(a) ? a - 1 : -1, hi = std::isfinite(b) ? b : std::max(std::isfinite(a) ? a : 0.0, 0.0) + 1;
    while (std::isinf(a) && cdf(f, lo, p) >= q && lo > -1e18)
      lo = 2 * lo - 1;
    while (std::isinf(b) && cdf(f, hi, p) < q && hi < 1e18)
      hi = 2 * hi + 1;
    while (hi - lo > 1) {
      double mid = std::floor(0.5 * (lo + hi));
      if (cdf(f, mid, p) >= q)
        hi = mid;
      else
        lo = mid;
    }
    return hi;
  }
  if (q == 0)
    return a;
  if (q == 1)
    return b;
  if (f.ppf)
    return f.ppf(q, p);
  bool upper = q > 0.5;
  auto g = [&](double x) { return upper ? (1.0 - q) - sf(f, x, p) : cdf(f, x, p) - q; };
  // bracket inside the support
  double c = centre(f, p);
  double lo = std::isfinite(a) ? a : c - 1, hi = std::isfinite(b) ? b : c + 1;
  if (!std::isfinite(a)) {
    double step = 1;
    while (g(lo) > 0 && step < 1e300) {
      step *= 2;
      lo = c - step;
    }
  }
  if (!std::isfinite(b)) {
    double step = 1;
    while (g(hi) < 0 && step < 1e300) {
      step *= 2;
      hi = c + step;
    }
  }
  return sf::brent(g, lo, hi, 1e-14 * std::max(1.0, std::fabs(hi)), 500);
}

double isf(const Family &f, double q, const double *p) {
  if (f.isf && !f.discrete && q > 0 && q < 1 && shapesOk(f, p))
    return f.isf(q, p);
  if (!f.discrete && q > 0 && q < 0.5 && !f.ppf && shapesOk(f, p)) {
    double a, b;
    support(f, p, a, b);
    double c = centre(f, p);
    double lo = std::isfinite(a) ? a : c - 1, hi = std::isfinite(b) ? b : c + 1;
    auto g = [&](double x) { return q - sf(f, x, p); };
    double step = 1;
    while (!std::isfinite(b) && g(hi) < 0 && step < 1e300) {
      step *= 2;
      hi = c + step;
    }
    return sf::brent(g, lo, hi, 1e-14 * std::max(1.0, std::fabs(hi)), 500);
  }
  return ppf(f, 1.0 - q, p);
}

double pdfLS(const Family &f, double x, const double *p, double loc, double scale) {
  if (f.discrete)
    return pdf(f, x - loc, p);
  if (!(scale > 0))
    return NaN;
  return pdf(f, (x - loc) / scale, p) / scale;
}
double cdfLS(const Family &f, double x, const double *p, double loc, double scale) {
  if (f.discrete)
    return cdf(f, x - loc, p);
  if (!(scale > 0))
    return NaN;
  return cdf(f, (x - loc) / scale, p);
}
double sfLS(const Family &f, double x, const double *p, double loc, double scale) {
  if (f.discrete)
    return sf(f, x - loc, p);
  if (!(scale > 0))
    return NaN;
  return sf(f, (x - loc) / scale, p);
}
double ppfLS(const Family &f, double q, const double *p, double loc, double scale) {
  if (f.discrete)
    return ppf(f, q, p) + loc;
  if (!(scale > 0))
    return NaN;
  return loc + scale * ppf(f, q, p);
}

double uniform01(std::mt19937_64 &g) { return ((g() >> 11) + 0.5) * (1.0 / 9007199254740992.0); }

double stdNormal(std::mt19937_64 &g) {
  // Marsaglia's polar method, one value per call
  for (;;) {
    double u = 2 * uniform01(g) - 1, v = 2 * uniform01(g) - 1, s = u * u + v * v;
    if (s > 0 && s < 1)
      return u * std::sqrt(-2 * std::log(s) / s);
  }
}

double stdGamma(std::mt19937_64 &g, double a) {
  // Marsaglia and Tsang
  if (a < 1)
    return stdGamma(g, a + 1) * std::pow(uniform01(g), 1.0 / a);
  double d = a - 1.0 / 3, c = 1.0 / std::sqrt(9 * d);
  for (;;) {
    double x, v;
    do {
      x = stdNormal(g);
      v = 1 + c * x;
    } while (v <= 0);
    v = v * v * v;
    double u = uniform01(g);
    if (u < 1 - 0.0331 * x * x * x * x || std::log(u) < 0.5 * x * x + d * (1 - v + std::log(v)))
      return d * v;
  }
}

double rvsLS(const Family &f, std::mt19937_64 &g, const double *p, double loc, double scale) {
  if (!shapesOk(f, p))
    return NaN;
  if (f.rvs)
    return f.discrete ? f.rvs(g, p) + loc : loc + scale * f.rvs(g, p);
  double u = uniform01(g);
  if (f.discrete)
    return ppf(f, u, p) + loc;
  if (!(scale > 0))
    return NaN;
  return loc + scale * (u > 0.5 ? isf(f, 1 - u, p) : ppf(f, u, p));
}

double mean(const Family &f, const double *p) {
  if (!shapesOk(f, p))
    return NaN;
  double a, b;
  support(f, p, a, b);
  if (f.discrete) {
    double s = 0.0, tot = 0.0;
    double hi = std::isfinite(b) ? b : 1e15;
    for (double k = a; k <= hi; k += 1.0) {
      double v = f.pdf(k, p);
      if (!std::isfinite(v))
        continue;
      s += k * v;
      tot += v;
      if (std::isinf(b) && k > a + 50 && v * std::fabs(k) < 1e-17 * std::fabs(s) && tot > 1 - 1e-14)
        break;
    }
    return s;
  }
  auto g = [&](double t) {
    double v = f.pdf(t, p);
    return std::isfinite(v) ? t * v : 0.0;
  };
  double c = centre(f, p), e1 = 0, e2 = 0;
  double r = (std::isinf(a) ? sf::quad(g, -Inf, c, 0.0, 1e-13, 400, &e1) : sf::quad(g, a, c, 0.0, 1e-13, 400, &e1)) +
             (std::isinf(b) ? sf::quad(g, c, Inf, 0.0, 1e-13, 400, &e2) : sf::quad(g, c, b, 0.0, 1e-13, 400, &e2));
  if (e1 + e2 > 1e-6 * std::max(1.0, std::fabs(r)))
    return NaN; // the integral does not settle: no mean
  return r;
}

double variance(const Family &f, const double *p) {
  double m = mean(f, p);
  if (std::isnan(m))
    return NaN;
  double a, b;
  support(f, p, a, b);
  if (f.discrete) {
    double s = 0.0, tot = 0.0;
    double hi = std::isfinite(b) ? b : 1e15;
    for (double k = a; k <= hi; k += 1.0) {
      double v = f.pdf(k, p);
      if (!std::isfinite(v))
        continue;
      s += (k - m) * (k - m) * v;
      tot += v;
      if (std::isinf(b) && k > a + 50 && v * (k - m) * (k - m) < 1e-17 * s && tot > 1 - 1e-14)
        break;
    }
    return s;
  }
  auto g = [&](double t) {
    double v = f.pdf(t, p);
    return std::isfinite(v) ? (t - m) * (t - m) * v : 0.0;
  };
  double e1 = 0, e2 = 0;
  double r = (std::isinf(a) ? sf::quad(g, -Inf, m, 0.0, 1e-13, 400, &e1) : sf::quad(g, a, m, 0.0, 1e-13, 400, &e1)) +
             (std::isinf(b) ? sf::quad(g, m, Inf, 0.0, 1e-13, 400, &e2) : sf::quad(g, m, b, 0.0, 1e-13, 400, &e2));
  if (e1 + e2 > 1e-6 * std::max(1.0, std::fabs(r)))
    return Inf;
  return r;
}

} // namespace pd
} // namespace scipy
} // namespace nc
