// Continuous families, alpha to gumbel_r: standardized pdf / cdf / sf / ppf
// in the forms SciPy uses (loc 0, scale 1).
#include "pd_common.h"

namespace nc {
namespace scipy {
namespace pd {

void addContA(std::vector<Family> &v) {
  // alpha(a): positive values, Phi(a - 1/x) / Phi(a)
  add(v, "alpha", {"a"}, OK(p[0] > 0), POS,
      PDF(x <= 0 ? 0.0 : std::exp(-0.5 * (p[0] - 1 / x) * (p[0] - 1 / x)) / (x * x * sf::ndtr(p[0]) * std::sqrt(2 * PI))),
      PDF(x <= 0 ? 0.0 : sf::ndtr(p[0] - 1 / x) / sf::ndtr(p[0])), nullptr,
      PDF(1.0 / (p[0] - sf::ndtri(x * sf::ndtr(p[0])))));

  add(v, "anglit", {}, nullptr, SUPP(a = -PI / 4; b = PI / 4), PDF(std::cos(2 * x)),
      PDF(std::sin(x + PI / 4) * std::sin(x + PI / 4)), PDF(std::cos(x + PI / 4) * std::cos(x + PI / 4)),
      PDF(std::asin(std::sqrt(x)) - PI / 4));

  add(v, "arcsine", {}, nullptr, UNIT, PDF(1.0 / (PI * std::sqrt(x * (1 - x)))), PDF(2.0 / PI * std::asin(std::sqrt(x))),
      PDF(2.0 / PI * std::acos(std::sqrt(x))), PDF(std::sin(PI * x / 2) * std::sin(PI * x / 2)));

  // argus(chi): Psi(chi) = Phi(chi) - chi phi(chi) - 1/2 = gammainc(3/2, chi^2/2) / 2
  add(v, "argus", {"chi"}, OK(p[0] > 0), UNIT,
      PDF(std::pow(p[0], 3) / (std::sqrt(2 * PI) * 0.5 * sf::gammainc(1.5, p[0] * p[0] / 2)) * x * std::sqrt(1 - x * x) *
          std::exp(-p[0] * p[0] * (1 - x * x) / 2)),
      PDF((sf::gammaincc(1.5, p[0] * p[0] * (1 - x * x) / 2) - sf::gammaincc(1.5, p[0] * p[0] / 2)) /
          sf::gammainc(1.5, p[0] * p[0] / 2)),
      PDF(sf::gammainc(1.5, p[0] * p[0] * (1 - x * x) / 2) / sf::gammainc(1.5, p[0] * p[0] / 2)), nullptr);

  add(v, "beta", {"a", "b"}, OK(p[0] > 0 && p[1] > 0), UNIT, PDF(betaPdf(x, p[0], p[1])),
      PDF(sf::betainc(p[0], p[1], x)), PDF(sf::betaincc(p[0], p[1], x)), PDF(sf::betaincinv(p[0], p[1], x)),
      PDF(sf::betainccinv(p[0], p[1], x)));

  add(v, "betaprime", {"a", "b"}, OK(p[0] > 0 && p[1] > 0), POS,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 1 / sf::beta(p[0], p[1]) : 0.0))
                 : std::exp((p[0] - 1) * std::log(x) - (p[0] + p[1]) * std::log1p(x) - sf::lbeta(p[0], p[1]))),
      PDF(sf::betainc(p[0], p[1], x / (1 + x))), PDF(sf::betaincc(p[0], p[1], x / (1 + x))),
      PDF(ratioOdds(sf::betaincinv(p[0], p[1], x))), PDF(ratioOdds(sf::betainccinv(p[0], p[1], x))));

  add(v, "bradford", {"c"}, OK(p[0] > 0), UNIT, PDF(p[0] / (std::log1p(p[0]) * (1 + p[0] * x))),
      PDF(std::log1p(p[0] * x) / std::log1p(p[0])), nullptr, PDF(std::expm1(x * std::log1p(p[0])) / p[0]));

  // burr (type III): cdf (1 + x^-c)^-d = x^(cd) (1 + x^c)^-d
  add(v, "burr", {"c", "d"}, OK(p[0] > 0 && p[1] > 0), POS,
      PDF(x == 0 ? (p[0] * p[1] < 1 ? Inf : (p[0] * p[1] == 1 ? p[0] * p[1] : 0.0))
                 : p[0] * p[1] * std::exp((p[0] * p[1] - 1) * std::log(x) - (p[1] + 1) * std::log1p(std::pow(x, p[0])))),
      PDF(x == 0 ? 0.0 : std::exp(p[0] * p[1] * std::log(x) - p[1] * std::log1p(std::pow(x, p[0])))),
      PDF(x == 0 ? 1.0 : -std::expm1(-p[1] * std::log1p(std::pow(x, -p[0])))),
      PDF(std::pow(std::expm1(-std::log(x) / p[1]), -1.0 / p[0])));

  add(v, "burr12", {"c", "d"}, OK(p[0] > 0 && p[1] > 0), POS,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? p[0] * p[1] : 0.0))
                 : p[0] * p[1] * std::exp((p[0] - 1) * std::log(x) - (p[1] + 1) * std::log1p(std::pow(x, p[0])))),
      PDF(-std::expm1(-p[1] * std::log1p(std::pow(x, p[0])))), PDF(std::exp(-p[1] * std::log1p(std::pow(x, p[0])))),
      PDF(std::pow(std::expm1(-std::log1p(-x) / p[1]), 1.0 / p[0])),
      PDF(std::pow(std::expm1(-std::log(x) / p[1]), 1.0 / p[0])));

  add(v, "cauchy", {}, nullptr, nullptr, PDF(1.0 / (PI * (1 + x * x))), PDF(0.5 + std::atan(x) / PI),
      PDF(0.5 - std::atan(x) / PI), PDF(std::tan(PI * (x - 0.5))), PDF(std::tan(PI * (0.5 - x))));

  add(v, "chi", {"df"}, OK(p[0] > 0), POS,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? std::sqrt(2 / PI) : 0.0))
                 : std::exp((p[0] - 1) * std::log(x) - x * x / 2 - (p[0] / 2 - 1) * std::log(2.0) - std::lgamma(p[0] / 2))),
      PDF(sf::gammainc(p[0] / 2, x * x / 2)), PDF(sf::gammaincc(p[0] / 2, x * x / 2)),
      PDF(std::sqrt(2 * sf::gammaincinv(p[0] / 2, x))), PDF(std::sqrt(2 * sf::gammainccinv(p[0] / 2, x))));

  add(v, "chi2", {"df"}, OK(p[0] > 0), POS, PDF(chi2Pdf(x, p[0])), PDF(sf::gammainc(p[0] / 2, x / 2)),
      PDF(sf::gammaincc(p[0] / 2, x / 2)), PDF(2 * sf::gammaincinv(p[0] / 2, x)), PDF(2 * sf::gammainccinv(p[0] / 2, x)));

  add(v, "cosine", {}, nullptr, SUPP(a = -PI; b = PI), PDF((1 + std::cos(x)) / (2 * PI)),
      PDF((PI + x + std::sin(x)) / (2 * PI)), PDF((PI - x - std::sin(x)) / (2 * PI)), nullptr);

  add(v, "crystalball", {"beta", "m"}, OK(p[0] > 0 && p[1] > 1), nullptr, PDF(crystalPdf(x, p[0], p[1])),
      PDF(crystalCdf(x, p[0], p[1])), nullptr, nullptr);

  add(v, "dgamma", {"a"}, OK(p[0] > 0), nullptr,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 0.5 : 0.0))
                 : std::exp((p[0] - 1) * std::log(std::fabs(x)) - std::fabs(x) - std::lgamma(p[0])) / 2),
      PDF(x > 0 ? 0.5 + 0.5 * sf::gammainc(p[0], x) : 0.5 * sf::gammaincc(p[0], -x)),
      PDF(x > 0 ? 0.5 * sf::gammaincc(p[0], x) : 0.5 + 0.5 * sf::gammainc(p[0], -x)),
      PDF(x > 0.5 ? sf::gammaincinv(p[0], 2 * x - 1) : -sf::gammainccinv(p[0], 2 * x)));

  add(v, "dpareto_lognorm", {"u", "s", "a", "b"}, OK(p[1] > 0 && p[2] > 0 && p[3] > 0), POS,
      PDF(dplnPdf(x, p)), PDF(dplnCdf(x, p)), nullptr, nullptr);

  add(v, "dweibull", {"c"}, OK(p[0] > 0), nullptr,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 0.5 : 0.0))
                 : p[0] / 2 * std::pow(std::fabs(x), p[0] - 1) * std::exp(-std::pow(std::fabs(x), p[0]))),
      PDF(x > 0 ? 1 - 0.5 * std::exp(-std::pow(x, p[0])) : 0.5 * std::exp(-std::pow(-x, p[0]))),
      PDF(x > 0 ? 0.5 * std::exp(-std::pow(x, p[0])) : 1 - 0.5 * std::exp(-std::pow(-x, p[0]))),
      PDF(x > 0.5 ? std::pow(-std::log(2 * (1 - x)), 1 / p[0]) : -std::pow(-std::log(2 * x), 1 / p[0])));

  add(v, "erlang", {"a"}, OK(p[0] > 0), POS, PDF(gammaPdf(x, p[0])), PDF(sf::gammainc(p[0], x)),
      PDF(sf::gammaincc(p[0], x)), PDF(sf::gammaincinv(p[0], x)), PDF(sf::gammainccinv(p[0], x)));

  add(v, "expon", {}, nullptr, POS, PDF(std::exp(-x)), PDF(-std::expm1(-x)), PDF(std::exp(-x)), PDF(-std::log1p(-x)),
      PDF(-std::log(x)));

  add(v, "exponnorm", {"K"}, OK(p[0] > 0), nullptr, PDF(exponnormPdf(x, p[0])), PDF(exponnormCdf(x, p[0])), nullptr,
      nullptr);

  add(v, "exponpow", {"b"}, OK(p[0] > 0), POS,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 1.0 : 0.0))
                 : p[0] * std::pow(x, p[0] - 1) * std::exp(1 + std::pow(x, p[0]) - std::exp(std::pow(x, p[0])))),
      PDF(-std::expm1(-std::expm1(std::pow(x, p[0])))), PDF(std::exp(-std::expm1(std::pow(x, p[0])))),
      PDF(std::pow(std::log1p(-std::log1p(-x)), 1 / p[0])), PDF(std::pow(std::log1p(-std::log(x)), 1 / p[0])));

  add(v, "exponweib", {"a", "c"}, OK(p[0] > 0 && p[1] > 0), POS,
      PDF(x == 0 ? (p[0] * p[1] < 1 ? Inf : (p[0] * p[1] == 1 ? 1.0 : 0.0))
                 : p[0] * p[1] * std::pow(x, p[1] - 1) * std::exp(-std::pow(x, p[1])) *
                       std::pow(-std::expm1(-std::pow(x, p[1])), p[0] - 1)),
      PDF(std::pow(-std::expm1(-std::pow(x, p[1])), p[0])), nullptr,
      PDF(std::pow(-std::log1p(-std::pow(x, 1 / p[0])), 1 / p[1])));

  add(v, "f", {"dfn", "dfd"}, OK(p[0] > 0 && p[1] > 0), POS, PDF(fPdf(x, p[0], p[1])), PDF(sf::fdtr(p[0], p[1], x)),
      PDF(sf::fdtrc(p[0], p[1], x)), PDF(sf::fdtri(p[0], p[1], x)), nullptr);

  add(v, "fatiguelife", {"c"}, OK(p[0] > 0), POS,
      PDF(x <= 0 ? 0.0
                 : (x + 1) / (2 * p[0] * std::sqrt(2 * PI * x * x * x)) *
                       std::exp(-(x - 1) * (x - 1) / (2 * x * p[0] * p[0]))),
      PDF(x <= 0 ? 0.0 : sf::ndtr((std::sqrt(x) - 1 / std::sqrt(x)) / p[0])),
      PDF(x <= 0 ? 1.0 : sf::ndtr(-(std::sqrt(x) - 1 / std::sqrt(x)) / p[0])),
      PDF(fatigueInv(p[0] * sf::ndtri(x))), PDF(fatigueInv(-p[0] * sf::ndtri(x))));

  add(v, "fisk", {"c"}, OK(p[0] > 0), POS,
      PDF(x == 0 ? (p[0] < 1 ? Inf : (p[0] == 1 ? 1.0 : 0.0))
                 : p[0] * std::pow(x, p[0] - 1) / ((1 + std::pow(x, p[0])) * (1 + std::pow(x, p[0])))),
      PDF(x == 0 ? 0.0 : 1 / (1 + std::pow(x, -p[0]))), PDF(1 / (1 + std::pow(x, p[0]))),
      PDF(std::pow(x / (1 - x), 1 / p[0])), PDF(std::pow((1 - x) / x, 1 / p[0])));

  add(v, "foldcauchy", {"c"}, OK(p[0] >= 0), POS,
      PDF(1 / (PI * (1 + (x - p[0]) * (x - p[0]))) + 1 / (PI * (1 + (x + p[0]) * (x + p[0])))),
      PDF((std::atan(x - p[0]) + std::atan(x + p[0])) / PI), nullptr, nullptr);

  add(v, "foldnorm", {"c"}, OK(p[0] >= 0), POS, PDF(phi(x - p[0]) + phi(x + p[0])),
      PDF(0.5 * (std::erf((x - p[0]) / std::sqrt(2.0)) + std::erf((x + p[0]) / std::sqrt(2.0)))),
      PDF(sf::ndtr(-(x - p[0])) + sf::ndtr(-(x + p[0]))), nullptr);

  add(v, "gamma", {"a"}, OK(p[0] > 0), POS, PDF(gammaPdf(x, p[0])), PDF(sf::gammainc(p[0], x)),
      PDF(sf::gammaincc(p[0], x)), PDF(sf::gammaincinv(p[0], x)), PDF(sf::gammainccinv(p[0], x)));

  add(v, "gausshyper", {"a", "b", "c", "z"}, OK(p[0] > 0 && p[1] > 0 && p[3] > -1), UNIT,
      PDF(std::exp((p[0] - 1) * std::log(x) + (p[1] - 1) * std::log1p(-x) - p[2] * std::log1p(p[3] * x) -
                   sf::lbeta(p[0], p[1])) /
          sf::hyp2f1(p[2], p[0], p[0] + p[1], -p[3])),
      nullptr, nullptr, nullptr);

  add(v, "genexpon", {"a", "b", "c"}, OK(p[0] > 0 && p[1] > 0 && p[2] > 0), POS,
      PDF((p[0] + p[1] * (-std::expm1(-p[2] * x))) * std::exp(-(p[0] + p[1]) * x + p[1] / p[2] * (-std::expm1(-p[2] * x)))),
      PDF(-std::expm1(-(p[0] + p[1]) * x + p[1] / p[2] * (-std::expm1(-p[2] * x)))),
      PDF(std::exp(-(p[0] + p[1]) * x + p[1] / p[2] * (-std::expm1(-p[2] * x)))), nullptr);

  add(v, "genextreme", {"c"}, nullptr,
      SUPP(if (p[0] > 0) {
        a = -Inf;
        b = 1 / p[0];
      } else if (p[0] < 0) {
        a = 1 / p[0];
        b = Inf;
      } else {
        a = -Inf;
        b = Inf;
      }),
      PDF(genextPdf(x, p[0])), PDF(std::exp(-genextT(x, p[0]))), PDF(-std::expm1(-genextT(x, p[0]))),
      PDF(p[0] == 0 ? -std::log(-std::log(x)) : -std::expm1(p[0] * std::log(-std::log(x))) / p[0]),
      PDF(p[0] == 0 ? -std::log(-std::log1p(-x)) : -std::expm1(p[0] * std::log(-std::log1p(-x))) / p[0]));

  add(v, "gengamma", {"a", "c"}, OK(p[0] > 0 && p[1] != 0), POS,
      PDF(x == 0 ? (p[0] * p[1] < 1 ? Inf : (p[0] * p[1] == 1 ? std::fabs(p[1]) / std::tgamma(p[0]) : 0.0))
                 : std::fabs(p[1]) * std::exp((p[1] * p[0] - 1) * std::log(x) - std::pow(x, p[1]) - std::lgamma(p[0]))),
      PDF(p[1] > 0 ? sf::gammainc(p[0], std::pow(x, p[1])) : sf::gammaincc(p[0], std::pow(x, p[1]))),
      PDF(p[1] > 0 ? sf::gammaincc(p[0], std::pow(x, p[1])) : sf::gammainc(p[0], std::pow(x, p[1]))),
      PDF(p[1] > 0 ? std::pow(sf::gammaincinv(p[0], x), 1 / p[1]) : std::pow(sf::gammainccinv(p[0], x), 1 / p[1])),
      PDF(p[1] > 0 ? std::pow(sf::gammainccinv(p[0], x), 1 / p[1]) : std::pow(sf::gammaincinv(p[0], x), 1 / p[1])));

  add(v, "genhalflogistic", {"c"}, OK(p[0] > 0), SUPP(a = 0; b = 1 / p[0]),
      PDF(2 * std::pow(1 - p[0] * x, 1 / p[0] - 1) / ((1 + std::pow(1 - p[0] * x, 1 / p[0])) * (1 + std::pow(1 - p[0] * x, 1 / p[0])))),
      PDF((1 - std::pow(1 - p[0] * x, 1 / p[0])) / (1 + std::pow(1 - p[0] * x, 1 / p[0]))),
      PDF(2 * std::pow(1 - p[0] * x, 1 / p[0]) / (1 + std::pow(1 - p[0] * x, 1 / p[0]))),
      PDF((1 - std::pow((1 - x) / (1 + x), p[0])) / p[0]));

  add(v, "genhyperbolic", {"p", "a", "b"}, OK(p[1] > 0 && std::fabs(p[2]) < p[1]), nullptr, PDF(genhypPdf(x, p)),
      nullptr, nullptr, nullptr);

  add(v, "geninvgauss", {"p", "b"}, OK(p[1] > 0), POS,
      PDF(x <= 0 ? 0.0
                 : std::exp((p[0] - 1) * std::log(x) - p[1] * (x + 1 / x) / 2 + p[1]) / (2 * sf::besselk(p[0], p[1], true))),
      nullptr, nullptr, nullptr);

  add(v, "genlogistic", {"c"}, OK(p[0] > 0), nullptr,
      PDF(std::exp(std::log(p[0]) - x - (p[0] + 1) * softplus(-x))), PDF(std::exp(-p[0] * softplus(-x))),
      PDF(-std::expm1(-p[0] * softplus(-x))), PDF(-std::log(std::expm1(-std::log(x) / p[0]))),
      PDF(-std::log(std::expm1(-std::log1p(-x) / p[0]))));

  add(v, "gennorm", {"beta"}, OK(p[0] > 0), nullptr,
      PDF(p[0] / (2 * std::tgamma(1 / p[0])) * std::exp(-std::pow(std::fabs(x), p[0]))),
      PDF(x > 0 ? 0.5 + 0.5 * sf::gammainc(1 / p[0], std::pow(x, p[0])) : 0.5 * sf::gammaincc(1 / p[0], std::pow(-x, p[0]))),
      PDF(x > 0 ? 0.5 * sf::gammaincc(1 / p[0], std::pow(x, p[0])) : 0.5 + 0.5 * sf::gammainc(1 / p[0], std::pow(-x, p[0]))),
      PDF(x > 0.5 ? std::pow(sf::gammaincinv(1 / p[0], 2 * x - 1), 1 / p[0])
                  : -std::pow(sf::gammainccinv(1 / p[0], 2 * x), 1 / p[0])));

  add(v, "genpareto", {"c"}, nullptr, SUPP(a = 0; b = p[0] < 0 ? -1 / p[0] : Inf),
      PDF(p[0] == 0 ? std::exp(-x) : std::exp(-(1 + 1 / p[0]) * std::log1p(p[0] * x))),
      PDF(p[0] == 0 ? -std::expm1(-x) : -std::expm1(-std::log1p(p[0] * x) / p[0])),
      PDF(p[0] == 0 ? std::exp(-x) : std::exp(-std::log1p(p[0] * x) / p[0])),
      PDF(p[0] == 0 ? -std::log1p(-x) : std::expm1(-p[0] * std::log1p(-x)) / p[0]),
      PDF(p[0] == 0 ? -std::log(x) : std::expm1(-p[0] * std::log(x)) / p[0]));

  add(v, "gibrat", {}, nullptr, POS, PDF(x <= 0 ? 0.0 : std::exp(-std::log(x) * std::log(x) / 2) / (x * std::sqrt(2 * PI))),
      PDF(x <= 0 ? 0.0 : sf::ndtr(std::log(x))), PDF(x <= 0 ? 1.0 : sf::ndtr(-std::log(x))), PDF(std::exp(sf::ndtri(x))),
      PDF(std::exp(-sf::ndtri(x))));

  add(v, "gompertz", {"c"}, OK(p[0] > 0), POS, PDF(p[0] * std::exp(x) * std::exp(-p[0] * std::expm1(x))),
      PDF(-std::expm1(-p[0] * std::expm1(x))), PDF(std::exp(-p[0] * std::expm1(x))),
      PDF(std::log1p(-std::log1p(-x) / p[0])), PDF(std::log1p(-std::log(x) / p[0])));

  add(v, "gumbel_l", {}, nullptr, nullptr, PDF(std::exp(x - std::exp(x))), PDF(-std::expm1(-std::exp(x))),
      PDF(std::exp(-std::exp(x))), PDF(std::log(-std::log1p(-x))), PDF(std::log(-std::log(x))));

  add(v, "gumbel_r", {}, nullptr, nullptr, PDF(std::exp(-x - std::exp(-x))), PDF(std::exp(-std::exp(-x))),
      PDF(-std::expm1(-std::exp(-x))), PDF(-std::log(-std::log(x))), PDF(-std::log(-std::log1p(-x))));
}

} // namespace pd
} // namespace scipy
} // namespace nc
