// Section 22 of 25 - Probability Distributions (scipy.stats distributions).
//
// Every family in pd_cont_a.cpp, pd_cont_b.cpp and pd_discrete.cpp becomes
// five NC functions: name_pdf (name_pmf for discrete laws), name_cdf,
// name_sf, name_ppf and name_rvs. Arguments are positional:
//   name_pdf(x, shapes..., loc = 0, scale = 1)     (discrete: no scale)
//   name_ppf(q, shapes..., loc, scale)
//   name_rvs(shapes..., [loc, [scale]], n)          n is always the last one
// poisson_binom takes its probabilities as one array.
#include "probability_distributions_main.h"

#include <cmath>
#include <random>

#include "../../ops/matrix/matrix.h"
#include "../scipy_core.h"
#include "../special_functions/sf_ufunc.h"
#include "pd_engine.h"

namespace nc {
namespace scipy {

namespace {
using pd::Family;

std::string paramList(const Family &f, const char *first, bool withScale) {
  std::string s = first;
  for (const auto &n : f.shapeNames)
    s += ", " + n;
  s += withScale ? ", loc, scale" : ", loc";
  return s;
}

void addFamily(Registry &reg, const Family &fam) {
  const Family *fp = &fam;
  int ns = fam.nshape;
  bool disc = fam.discrete;
  int extra = disc ? 1 : 2;
  int nargs = 1 + ns + extra;
  std::vector<double> defs(nargs, 0.0);
  if (!disc)
    defs[nargs - 1] = 1.0;
  auto kernel = [fp, ns, disc](int which) {
    return [fp, ns, disc, which](const double *x) -> double {
      const double *p = x + 1;
      double loc = x[1 + ns], scale = disc ? 1.0 : x[2 + ns];
      switch (which) {
      case 0:
        return pd::pdfLS(*fp, x[0], p, loc, scale);
      case 1:
        return pd::cdfLS(*fp, x[0], p, loc, scale);
      case 2:
        return pd::sfLS(*fp, x[0], p, loc, scale);
      default:
        return pd::ppfLS(*fp, x[0], p, loc, scale);
      }
    };
  };
  const char *suffix[4] = {disc ? "_pmf" : "_pdf", "_cdf", "_sf", "_ppf"};
  for (int w = 0; w < 4; w++) {
    auto k = kernel(w);
    std::string name = fam.name + suffix[w];
    reg.add(makeSpec(name.c_str(), Section::ProbabilityDistributions, 1 + ns, nargs,
                     paramList(fam, w == 3 ? "q" : "x", !disc).c_str(),
                     [k, nargs, defs](const Args &a, CallContext &ctx) -> Value { return umap(a, ctx, nargs, defs, k); },
                     false));
  }
  // rvs(shapes..., [loc, [scale]], n)
  std::string rname = fam.name + "_rvs";
  std::string rparams;
  for (const auto &n : fam.shapeNames)
    rparams += n + ", ";
  rparams += disc ? "[loc,] n" : "[loc, [scale,]] n";
  reg.add(makeSpec(rname.c_str(), Section::ProbabilityDistributions, ns + 1, ns + 1 + extra, rparams.c_str(),
                   [fp, ns, disc](const Args &a, CallContext &ctx) -> Value {
                     std::vector<double> p(ns);
                     for (int i = 0; i < ns; i++)
                       if (!argNumber(a, i, ctx, p[i]))
                         return Value(0.0);
                     size_t last = a.size() - 1;
                     double loc = 0, scale = 1;
                     if (last > static_cast<size_t>(ns) && !argNumber(a, ns, ctx, loc))
                       return Value(0.0);
                     if (!disc && last > static_cast<size_t>(ns) + 1 && !argNumber(a, ns + 1, ctx, scale))
                       return Value(0.0);
                     long long n;
                     if (!argNonNegativeInt(a, last, ctx, n))
                       return Value(0.0);
                     if (n > 10000000) {
                       ctx.fail("n must be at most 10000000");
                       return Value(0.0);
                     }
                     if (!pd::shapesOk(*fp, p.data()) || (!disc && !(scale > 0))) {
                       ctx.fail("the shape parameters are outside the allowed range");
                       return Value(0.0);
                     }
                     std::mt19937_64 g(ncRandomEngine()());
                     Vec out(n);
                     for (long long i = 0; i < n; i++)
                       out[i] = pd::rvsLS(*fp, g, p.data(), loc, scale);
                     return toValue(out);
                   },
                   false));
}

// ---- Poisson binomial: shape is an array of probabilities ----
bool pbProbs(const Args &a, size_t i, CallContext &ctx, Vec &p) {
  if (!getVec(a, i, ctx, p))
    return false;
  for (double v : p)
    if (!(v >= 0 && v <= 1)) {
      ctx.fail("the probabilities must lie in [0, 1]");
      return false;
    }
  return true;
}
Vec pbPmf(const Vec &p) {
  Vec f(p.size() + 1, 0.0);
  f[0] = 1.0;
  for (size_t i = 0; i < p.size(); i++)
    for (size_t k = i + 1; k-- > 0;) {
      f[k + 1] += f[k] * p[i];
      f[k] *= 1 - p[i];
    }
  return f;
}
Value pbEval(const Args &a, CallContext &ctx, int which) {
  Vec p;
  if (!pbProbs(a, 1, ctx, p))
    return Value(0.0);
  double loc = optNum(a, 2, 0.0);
  Vec f = pbPmf(p), c(f.size());
  double s = 0;
  for (size_t k = 0; k < f.size(); k++) {
    s += f[k];
    c[k] = std::min(1.0, s);
  }
  double n = static_cast<double>(p.size());
  return umap(Args{a[0]}, ctx, 1, {}, [&](const double *x) -> double {
    double k = x[0] - loc;
    switch (which) {
    case 0:
      return (k != std::floor(k) || k < 0 || k > n) ? 0.0 : f[static_cast<size_t>(k)];
    case 1:
      return k < 0 ? 0.0 : (k >= n ? 1.0 : c[static_cast<size_t>(std::floor(k))]);
    case 2:
      return k < 0 ? 1.0 : (k >= n ? 0.0 : 1 - c[static_cast<size_t>(std::floor(k))]);
    default: {
      double q = x[0];
      if (!(q >= 0 && q <= 1))
        return kNaN;
      if (q == 0)
        return -1 + loc;
      for (size_t j = 0; j < c.size(); j++)
        if (c[j] >= q)
          return j + loc;
      return n + loc;
    }
    }
  });
}
} // namespace

void registerProbabilityDistributions(Registry &reg) {
  std::vector<std::string> kernels;
  for (const Family &f : pd::families()) {
    addFamily(reg, f);
    for (const char *s : {"_pdf", "_pmf", "_cdf", "_sf", "_ppf"})
      kernels.push_back(f.name + s);
  }

#define SP_SEC Section::ProbabilityDistributions
  SP_ADD("poisson_binom_pmf", 2, 3, "x, p, loc") { return pbEval(a, ctx, 0); } SP_END
  SP_ADD("poisson_binom_cdf", 2, 3, "x, p, loc") { return pbEval(a, ctx, 1); } SP_END
  SP_ADD("poisson_binom_sf", 2, 3, "x, p, loc") { return pbEval(a, ctx, 2); } SP_END
  SP_ADD("poisson_binom_ppf", 2, 3, "q, p, loc") { return pbEval(a, ctx, 3); } SP_END
  SP_ADD("poisson_binom_rvs", 2, 3, "p, [loc,] n") {
    Vec p;
    if (!pbProbs(a, 0, ctx, p))
      return Value(0.0);
    double loc = a.size() == 3 ? optNum(a, 1, 0.0) : 0.0;
    long long n;
    if (!argNonNegativeInt(a, a.size() - 1, ctx, n))
      return Value(0.0);
    std::mt19937_64 g(ncRandomEngine()());
    Vec out(n);
    for (long long i = 0; i < n; i++) {
      double s = 0;
      for (double q : p)
        s += pd::uniform01(g) < q ? 1 : 0;
      out[i] = s + loc;
    }
    return toValue(out);
  } SP_END
#undef SP_SEC
  reg.setParallel(kernels, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
