# Scipy — SciPy-equivalent functions for NC

2643 entries in 25 sections (23 numbered sections + Appendix A as 24 + Appendix B as 25),
each section owned and developed independently. Same design as `../Numpy/`.

```
runtime/interpreter/Scipy/
├── scipy_main.h / .cpp           entry point: initialize(), tryCall(), tryConstant()
├── scipy_registry.h / .cpp       name → FunctionSpec / ConstantSpec, section table, reserved names
├── scipy_common.h                shared argument / result helpers (same as Numpy's)
├── scipy_sources.cmake           globs every .cpp in this tree for the build
├── clustering/                       1  scipy.cluster                  39
├── constants/                        2  scipy.constants               164
├── datasets/                         3  scipy.datasets                  5
├── differentiation/                  4  scipy.differentiate             3
├── fourier_transforms/               5  scipy.fft                      41
├── legacy_fft/                       6  scipy.fftpack                  35
├── integration_odes/                 7  scipy.integrate                33
├── interpolation/                    8  scipy.interpolate              56
├── input_output/                     9  scipy.io                       34
├── linear_algebra/                  10  scipy.linalg                  110
├── image_processing/                11  scipy.ndimage                  75
├── orthogonal_distance_regression/  12  scipy.odr                      14
├── optimization_root_finding/       13  scipy.optimize                 71
├── signal_processing/               14  scipy.signal                  158
├── window_functions/                15  scipy.signal.windows           26
├── sparse_matrices/                 16  scipy.sparse                   66
├── sparse_linear_algebra/           17  scipy.sparse.linalg            38
├── graph_routines/                  18  scipy.sparse.csgraph           26
├── spatial_algorithms/              19  scipy.spatial                  52
├── special_functions/               20  scipy.special                 359
├── statistics/                      21  scipy.stats                   200
├── probability_distributions/       22  scipy.stats                   131
├── masked_array_statistics/         23  scipy.stats.mstats             73
├── removed_since_1_8/               24  (various)                      60
├── blas_lapack_wrappers/            25  scipy.linalg.blas / lapack    774
                                                                     2643
```

Each section folder holds `<folder>_main.h` and `<folder>_main.cpp` with an empty
`register<Section>(Registry&)` that `scipy_main.cpp` calls.

## How a call reaches your code

```
callBuiltin(name, args)
  1. builtinTable (ops/)         existing builtins always win
  2. nc::numpy::tryCall()        NumPy-equivalent functions
  3. nc::scipy::tryCall()        SciPy-equivalent functions   ← this folder
  4. logbN family, then "Unknown function"
```

Functions need no lexer/parser change: `f(x)` is already an `ExprKind::Call`, and
both the tree-walker and the JIT reach `callBuiltin()`.

**Constants** (`scipy.constants`) are values used as a bare name (`speed_of_light`,
no parentheses). Register them with `reg.addConstant({...})` in `constants/`.
They are read through `nc::scipy::tryConstant()`. **Not wired into NC yet — the
constants design is pending**, so constants can be registered but not used in
NC code.

## Adding an entry (section developer)

1. In `<section>/<section>_main.cpp`, copy the commented example.
2. Fill in: NC name, `Section::...`, min/max args, usage text, summary, SciPy original, lambda.
3. For groups of functions, add `<section>/<prefix>_<group>.h/.cpp` with a
   `register<Group>(Registry&)` and call it from your section's register function.
4. Rebuild, then call the new function from NC by its name.

## Rules

| Rule | Why |
|---|---|
| Use the NC name from the team's agreed name list; function names are case-insensitive | same as every other builtin |
| A function name already owned by an ops/ builtin or a NumPy function is skipped | the existing one stays; printed at startup |
| NC keywords, parser-reserved calls and `logbN` names are skipped | they never reach `callBuiltin()` |
| Constant names are case-sensitive (`G` ≠ `g`) | they behave like NC variables |
| Arguments are positional only, for now | named arguments (`f(a=3, axis=0)`) are a planned parser feature |
| Report bad input with `ctx.fail("...")`, then return any Value | one `Error: name: ...` line, statement stops |
| Complex arguments are refused unless the spec sets `acceptsComplex = true` | FFT / signal sections will set it |
| Use the helpers in `scipy_common.h` | identical error wording everywhere |

## Phases 1 and 2 (sections 1 to 19)

Done. The handover for phases 3 to 5 is `docs/SciPy_Phase_Handover.md`, and the
front-end changes are in `docs/SciPy_Phase1_2_Frontend_Changes.md`.

- **Constants** reach NC as bare names through `tryConstant` (a hook in the parser).
- **NC callbacks** run through the parser host that `bindScipyCallbacks` sets: `NcFn`
  and `callNC` in `scipy_core.h`.
- **Central guards** in `tryCall` (scipy_main.cpp): empty inputs are refused unless the
  function is listed in `kEmptyOk`; counts in `kCountArgs` and `*_win` must be from 0
  to 10000000.
- **Tests**: `src/test/scipy` (`tests_*.py` and the generated `.nc`); tools in `tools/`.

## Still open

- **N-D arrays**, **named arguments** — same as Numpy.
- **Units on constants** — `unit` is documentation for now; NC values can carry
  L/T/M dimensions, so constants could later return dimensioned values.
