// Section 4 of 25 - Differentiation (scipy.differentiate). Central differences
// with Richardson extrapolation; every evaluation calls the NC function.
#include "differentiation_main.h"

#include "../scipy_core.h"

#define SP_SEC Section::Differentiation

namespace nc {
namespace scipy {

namespace {

// d/dx g at x: Ridders' table of shrinking steps, with its error estimate.
template <class G> double ridders(G g, double x, double h0, double &err) {
  const int N = 8;
  const double con = 1.4, con2 = con * con;
  double a[N][N];
  double h = h0;
  err = kInf;
  double ans = 0.0;
  a[0][0] = (g(x + h) - g(x - h)) / (2.0 * h);
  ans = a[0][0];
  for (int i = 1; i < N; i++) {
    h /= con;
    a[0][i] = (g(x + h) - g(x - h)) / (2.0 * h);
    double fac = con2;
    for (int j = 1; j <= i; j++) {
      a[j][i] = (a[j - 1][i] * fac - a[j - 1][i - 1]) / (fac - 1.0);
      fac *= con2;
      const double e = std::max(std::fabs(a[j][i] - a[j - 1][i]), std::fabs(a[j][i] - a[j - 1][i - 1]));
      if (e <= err) {
        err = e;
        ans = a[j][i];
      }
    }
    if (std::fabs(a[i][i] - a[i - 1][i - 1]) >= 2.0 * err)
      break;
  }
  return ans;
}

} // namespace

void registerDifferentiation(Registry &reg) {
  SP_ADD("jacobian", 2, 2, "fn, x") {
    Vec x;
    if (!isCallable(a[0]) || !getVec(a, 1, ctx, x)) {
      if (ctx.ok())
        ctx.fail("the first argument must name an NC function");
      return Value(0.0);
    }
    NcFn f(a[0]);
    Vec y0 = f.vecOfVec(x);
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    const size_t m = y0.size(), n = x.size();
    Mat J(m, n), E(m, n);
    double worst = 0.0;
    for (size_t i = 0; i < m; i++)
      for (size_t j = 0; j < n; j++) {
        Vec p = x;
        double e = 0.0;
        J(i, j) = ridders([&](double t) {
          p[j] = t;
          Vec v = f.vecOfVec(p);
          return f.failed || v.size() != m ? kNaN : v[i];
        }, x[j], std::max(0.1, std::fabs(x[j]) * 0.1), e);
        E(i, j) = e;
        worst = std::max(worst, e);
      }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"df", toValue(J)}, {"error", toValue(E)}, {"success", Value::boolean(worst < 1e-5)}});
  } SP_END
  SP_ADD("hessian", 2, 2, "fn, x") {
    Vec x;
    if (!isCallable(a[0]) || !getVec(a, 1, ctx, x)) {
      if (ctx.ok())
        ctx.fail("the first argument must name an NC function");
      return Value(0.0);
    }
    NcFn f(a[0]);
    const size_t n = x.size();
    Mat H(n, n), E(n, n);
    double worst = 0.0;
    for (size_t i = 0; i < n; i++)
      for (size_t j = i; j < n; j++) {
        // d/dxj of the Ridders first derivative along xi.
        double e = 0.0;
        Vec p = x;
        const double v = ridders([&](double t) {
          p[j] = t;
          double inner = 0.0;
          Vec q = p;
          return ridders([&](double s) {
            q[i] = s;
            return f.ofVec(q);
          }, q[i], std::max(0.05, std::fabs(q[i]) * 0.05), inner);
        }, x[j], std::max(0.1, std::fabs(x[j]) * 0.1), e);
        H(i, j) = H(j, i) = v;
        E(i, j) = E(j, i) = e;
        worst = std::max(worst, e);
      }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"ddf", toValue(H)}, {"error", toValue(E)}, {"success", Value::boolean(worst < 1e-4)}});
  } SP_END
  reg.setParallel({"jacobian", "hessian"}, ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
