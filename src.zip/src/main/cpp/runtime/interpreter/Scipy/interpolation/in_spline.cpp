#include "in_spline.h"

#include "../linear_algebra/la_core.h"

namespace nc {
namespace scipy {
namespace spl {

size_t findSpan(const Vec &t, int k, size_t nc, double x) {
  if (x >= t[nc])
    return nc - 1;
  if (x <= t[k])
    return k;
  size_t lo = k, hi = nc;
  while (hi - lo > 1) {
    const size_t mid = (lo + hi) / 2;
    if (x >= t[mid])
      lo = mid;
    else
      hi = mid;
  }
  return lo;
}

void basisAt(const Vec &t, int k, size_t span, double x, double *N) {
  Vec left(k + 1), right(k + 1);
  N[0] = 1.0;
  for (int j = 1; j <= k; j++) {
    left[j] = x - t[span + 1 - j];
    right[j] = t[span + j] - x;
    double saved = 0.0;
    for (int r = 0; r < j; r++) {
      const double den = right[r + 1] + left[j - r];
      const double tmp = den != 0.0 ? N[r] / den : 0.0;
      N[r] = saved + right[r + 1] * tmp;
      saved = left[j - r] * tmp;
    }
    N[j] = saved;
  }
}

BSpline derivative(const BSpline &s, int n) {
  BSpline d = s;
  for (int m = 0; m < n && d.k > 0; m++) {
    const size_t nc = d.t.size() - d.k - 1;
    Vec c(nc - 1);
    for (size_t i = 0; i + 1 < nc; i++) {
      const double den = d.t[i + d.k + 1] - d.t[i + 1];
      c[i] = den != 0.0 ? d.k * (d.c[i + 1] - d.c[i]) / den : 0.0;
    }
    d.t = Vec(d.t.begin() + 1, d.t.end() - 1);
    d.c = c;
    d.k--;
  }
  return d;
}

BSpline antiderivative(const BSpline &s, int n) {
  BSpline d = s;
  for (int m = 0; m < n; m++) {
    const size_t nc = d.t.size() - d.k - 1;
    Vec c(nc + 1, 0.0);
    for (size_t i = 0; i < nc; i++)
      c[i + 1] = c[i] + d.c[i] * (d.t[i + d.k + 1] - d.t[i]) / (d.k + 1.0);
    Vec t;
    t.push_back(d.t.front());
    t.insert(t.end(), d.t.begin(), d.t.end());
    t.push_back(d.t.back());
    d.t = t;
    d.c = c;
    d.k++;
  }
  return d;
}

double evaluate(const BSpline &s, double x, int der) {
  if (der > 0) {
    if (der > s.k)
      return 0.0;
    return evaluate(derivative(s, der), x, 0);
  }
  const size_t nc = s.t.size() - s.k - 1;
  const size_t span = findSpan(s.t, s.k, nc, x);
  Vec N(s.k + 1);
  basisAt(s.t, s.k, span, x, N.data());
  double v = 0.0;
  for (int i = 0; i <= s.k; i++)
    v += N[i] * s.c[span - s.k + i];
  return v;
}

double integral(const BSpline &s, double a, double b) {
  BSpline A = antiderivative(s, 1);
  const double lo = s.t[s.k], hi = s.t[s.t.size() - s.k - 1];
  auto clip = [&](double v) { return std::min(hi, std::max(lo, v)); };
  return evaluate(A, clip(b)) - evaluate(A, clip(a));
}

namespace {
// The design matrix of the spline basis at x.
Mat design(const Vec &x, const Vec &t, int k) {
  const size_t nc = t.size() - k - 1;
  Mat A(x.size(), nc);
  Vec N(k + 1);
  for (size_t i = 0; i < x.size(); i++) {
    const size_t span = findSpan(t, k, nc, x[i]);
    basisAt(t, k, span, x[i], N.data());
    for (int q = 0; q <= k; q++)
      A(i, span - k + q) = N[q];
  }
  return A;
}

// The jumps of the k-th derivative at the interior knots, as a matrix on c.
Mat jumpMatrix(const Vec &t, int k) {
  const size_t nc = t.size() - k - 1;
  std::vector<double> interior;
  for (size_t i = k + 1; i < nc; i++)
    interior.push_back(t[i]);
  Mat B(interior.size(), nc);
  for (size_t b = 0; b < interior.size(); b++)
    for (size_t j = 0; j < nc; j++) {
      // k-th derivative of basis j is constant on each knot span: the jump at the knot.
      BSpline e;
      e.t = t;
      e.c.assign(nc, 0.0);
      e.c[j] = 1.0;
      e.k = k;
      BSpline d = derivative(e, k); // degree 0
      const size_t m = d.t.size() - 1;
      size_t pos = b; // the span left of interior knot b, in the differentiated spline
      B(b, j) = (pos + 1 < m ? d.c[pos + 1] : 0.0) - (pos < m ? d.c[pos] : 0.0);
    }
  return B;
}
} // namespace

bool interpolating(const Vec &x, const Vec &y, int k, BSpline &out) {
  const size_t n = x.size();
  if (n < static_cast<size_t>(k) + 1)
    return false;
  Vec t;
  if (k == 0) {
    t = x;
    t.push_back(x.back());
    if (n >= 2)
      t.back() = x.back();
    out.t = t;
    out.c = y;
    out.k = 0;
    return true;
  }
  for (int i = 0; i <= k; i++)
    t.push_back(x.front());
  if (k % 2 == 1) {
    // Not-a-knot.
    for (size_t i = (k + 1) / 2; i + (k + 1) / 2 < n; i++)
      t.push_back(x[i]);
  } else {
    for (size_t i = k / 2; i + k / 2 + 1 < n; i++)
      t.push_back(0.5 * (x[i] + x[i + 1]));
  }
  for (int i = 0; i <= k; i++)
    t.push_back(x.back());
  Mat A = design(x, t, k);
  if (A.r != A.c)
    return false;
  Vec c = y;
  if (!la::solveVec(A, c))
    return false;
  out.t = t;
  out.c = c;
  out.k = k;
  return true;
}

bool lsq(const Vec &x, const Vec &y, const Vec *w, const Vec &t, int k, BSpline &out) {
  if (t.size() < static_cast<size_t>(2 * k + 2))
    return false;
  Mat A = design(x, t, k);
  Vec b = y;
  if (w)
    for (size_t i = 0; i < x.size(); i++) {
      for (size_t j = 0; j < A.c; j++)
        A(i, j) *= (*w)[i];
      b[i] *= (*w)[i];
    }
  out.t = t;
  out.c = la::lstsqMin(A, b);
  out.k = k;
  return true;
}

bool smoothing(const Vec &x, const Vec &y, const Vec *w, int k, double s, BSpline &out, std::vector<Vec> *history) {
  const size_t m = x.size();
  if (m < static_cast<size_t>(k) + 1)
    return false;
  auto resid = [&](const BSpline &sp, Vec *r) {
    double fp = 0.0;
    if (r)
      r->assign(m, 0.0);
    for (size_t i = 0; i < m; i++) {
      const double e = (w ? (*w)[i] : 1.0) * (y[i] - evaluate(sp, x[i]));
      fp += e * e;
      if (r)
        (*r)[i] = e * e;
    }
    return fp;
  };
  Vec t;
  for (int i = 0; i <= k; i++)
    t.push_back(x.front());
  for (int i = 0; i <= k; i++)
    t.push_back(x.back());
  BSpline cur;
  double fp = 0.0;
  size_t nplus = 1;
  const double acc = 0.001 * s;
  double fpOld = kInf;
  for (int iter = 0; iter < static_cast<int>(m) + 2; iter++) {
    if (history)
      history->push_back(t);
    if (!lsq(x, y, w, t, k, cur))
      return false;
    Vec r;
    fp = resid(cur, &r);
    if (fp <= s + acc)
      break;
    const size_t nc = t.size() - k - 1;
    if (nc >= m)
      break;
    // Knots to add: the growth rule of FITPACK.
    if (iter == 0)
      nplus = 1;
    else {
      const double pre = fpOld > fp ? nplus * (fpOld - s) / (fpOld - fp) : 2.0 * nplus;
      nplus = std::max<size_t>(1, std::min<size_t>(static_cast<size_t>(std::min(2.0 * nplus, pre)), 2 * nplus));
    }
    fpOld = fp;
    // Split the intervals with the largest residual sum (that still hold data points).
    for (size_t add = 0; add < nplus && t.size() - k - 1 < m; add++) {
      struct Part {
        double sum;
        size_t first, last;
      };
      std::vector<Part> parts;
      size_t span0 = k;
      Part cur2{0.0, 0, 0};
      for (size_t i = 0; i < m; i++) {
        const size_t sp = findSpan(t, k, t.size() - k - 1, x[i]);
        if (sp != span0 && i > 0) {
          cur2.last = i - 1;
          parts.push_back(cur2);
          cur2 = Part{0.0, i, i};
          span0 = sp;
        } else if (i == 0) {
          span0 = sp;
        }
        cur2.sum += r[i];
      }
      cur2.last = m - 1;
      parts.push_back(cur2);
      double best = -1.0;
      long pick = -1;
      for (size_t q = 0; q < parts.size(); q++)
        if (parts[q].last > parts[q].first + 1 && parts[q].sum > best) {
          best = parts[q].sum;
          pick = (long)q;
        }
      if (pick < 0)
        break;
      const size_t mid = (parts[pick].first + parts[pick].last + 1) / 2;
      const double knot = x[mid];
      if (std::find(t.begin(), t.end(), knot) != t.end()) {
        parts[pick].sum = -1.0;
        break;
      }
      t.insert(std::upper_bound(t.begin() + k + 1, t.end() - k - 1, knot), knot);
      // The added interval's residual no longer counts for the next pick.
      for (size_t i = parts[pick].first; i <= parts[pick].last; i++)
        r[i] *= 0.25;
    }
  }
  if (fp <= s + acc || t.size() - k - 1 >= m) {
    // Tune p in minimise p * ||y - s||^2 + ||jumps||^2, so the residual becomes s.
    if (fp < s - acc && s > 0.0 && t.size() > static_cast<size_t>(2 * k + 2)) {
      Mat A = design(x, t, k);
      Vec b = y;
      if (w)
        for (size_t i = 0; i < m; i++) {
          for (size_t j = 0; j < A.c; j++)
            A(i, j) *= (*w)[i];
          b[i] *= (*w)[i];
        }
      Mat B = jumpMatrix(t, k);
      const Mat AtA = mul(transposeOf(A), A), BtB = mul(transposeOf(B), B);
      Vec Atb = mulVec(transposeOf(A), b);
      auto solveP = [&](double p, BSpline &sp) {
        Mat M = AtA;
        for (size_t i = 0; i < M.a.size(); i++)
          M.a[i] = p * AtA.a[i] + BtB.a[i];
        Vec c = Atb;
        for (double &v : c)
          v *= p;
        if (!la::solveVec(M, c))
          return false;
        sp.t = t;
        sp.c = c;
        sp.k = k;
        return true;
      };
      // F(p) falls from the fit with no interior freedom to fp as p grows.
      double lo = 0.0, hi = 1.0;
      BSpline sp;
      for (int it = 0; it < 60; it++) {
        if (!solveP(hi, sp))
          break;
        if (resid(sp, nullptr) <= s)
          break;
        lo = hi;
        hi *= 4.0;
      }
      for (int it = 0; it < 60; it++) {
        const double p = lo == 0.0 ? hi * 0.5 : std::sqrt(lo * hi);
        if (!solveP(p, sp))
          break;
        const double f = resid(sp, nullptr);
        if (std::fabs(f - s) <= acc) {
          cur = sp;
          break;
        }
        if (f > s)
          lo = p;
        else
          hi = p;
        cur = sp;
      }
    }
  }
  out = cur;
  return true;
}

Value toValue(const BSpline &s) {
  return makeDict({{"t", scipy::toValue(s.t)}, {"c", scipy::toValue(s.c)}, {"k", Value((double)s.k)}});
}

bool fromValue(const Value &v, BSpline &s) {
  const Value *t = dictGet(v, "t"), *c = dictGet(v, "c"), *k = dictGet(v, "k");
  if (!t || !c || !k || !readVec(*t, s.t) || !readVec(*c, s.c) || !isPlainNumber(*k))
    return false;
  s.k = (int)k->number;
  return s.t.size() == s.c.size() + s.k + 1 || s.t.size() >= s.c.size();
}

bool readTck(const Args &a, size_t i, CallContext &ctx, BSpline &s) {
  if (i >= a.size() || !fromValue(a[i], s)) {
    ctx.fail("the " + ordinal(i) + " argument must be a spline Dict {t, c, k}, e.g. from splrep()");
    return false;
  }
  // SciPy pads c with zeros to the length of t; only the real coefficients count.
  s.c.resize(s.t.size() - s.k - 1);
  return true;
}

} // namespace spl
} // namespace scipy
} // namespace nc
