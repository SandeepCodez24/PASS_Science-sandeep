// Interpolation in several variables: scattered data, regular grids, surface splines.
#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "../spatial_algorithms/sa_geom.h"
#include "in_spline.h"
#include "interpolation_main.h"

#define SP_SEC Section::Interpolation

namespace nc {
namespace scipy {

namespace {

double rbfKernel(const std::string &k, double r, double eps) {
  const double s = eps * r;
  if (k == "linear") return -s;
  if (k == "thin_plate_spline") return s == 0.0 ? 0.0 : s * s * std::log(s);
  if (k == "cubic") return s * s * s;
  if (k == "quintic") return -s * s * s * s * s;
  if (k == "multiquadric") return -std::sqrt(s * s + 1.0);
  if (k == "inverse_multiquadric") return 1.0 / std::sqrt(s * s + 1.0);
  if (k == "inverse_quadratic") return 1.0 / (s * s + 1.0);
  return std::exp(-s * s); // gaussian
}
int rbfMinDegree(const std::string &k) {
  if (k == "linear" || k == "thin_plate_spline" || k == "multiquadric") return k == "multiquadric" ? 0 : (k == "linear" ? 0 : 1);
  if (k == "cubic") return 1;
  if (k == "quintic") return 2;
  return -1;
}

// Monomial exponents up to a total degree.
void monomials(size_t d, int deg, std::vector<std::vector<int>> &out) {
  std::vector<int> cur(d, 0);
  std::function<void(size_t, int)> rec = [&](size_t i, int left) {
    if (i == d) {
      out.push_back(cur);
      return;
    }
    for (int e = 0; e <= left; e++) {
      cur[i] = e;
      rec(i + 1, left - e);
    }
    cur[i] = 0;
  };
  if (deg >= 0)
    rec(0, deg);
}

// Tensor interpolation of a surface spline: a spline along each row, then along columns.
bool tensorInterp(const Vec &gx, const Vec &gy, const Mat &z, int kx, int ky, Vec &tx, Vec &ty, Mat &c) {
  c = Mat(0, 0);
  std::vector<Vec> rows;
  for (size_t i = 0; i < gx.size(); i++) {
    spl::BSpline s;
    if (!spl::interpolating(gy, Vec(z.row(i), z.row(i) + z.c), ky, s))
      return false;
    ty = s.t;
    rows.push_back(s.c);
  }
  const size_t ncY = rows[0].size();
  for (size_t j = 0; j < ncY; j++) {
    Vec col(gx.size());
    for (size_t i = 0; i < gx.size(); i++)
      col[i] = rows[i][j];
    spl::BSpline s;
    if (!spl::interpolating(gx, col, kx, s))
      return false;
    if (j == 0) {
      tx = s.t;
      c = Mat(s.c.size(), ncY);
    }
    for (size_t i = 0; i < s.c.size(); i++)
      c(i, j) = s.c[i];
  }
  return true;
}

double surfaceAt(const Vec &tx, const Vec &ty, const Mat &c, int kx, int ky, double x, double y) {
  const size_t sx = spl::findSpan(tx, kx, c.r, x), sy = spl::findSpan(ty, ky, c.c, y);
  Vec Nx(kx + 1), Ny(ky + 1);
  spl::basisAt(tx, kx, sx, x, Nx.data());
  spl::basisAt(ty, ky, sy, y, Ny.data());
  double v = 0.0;
  for (int i = 0; i <= kx; i++)
    for (int j = 0; j <= ky; j++)
      v += Nx[i] * Ny[j] * c(sx - kx + i, sy - ky + j);
  return v;
}

// Least-squares tensor spline on given full knot vectors.
Mat lsqSurface(const Vec &x, const Vec &y, const Vec &z, const Vec &tx, const Vec &ty, int kx, int ky) {
  const size_t ncx = tx.size() - kx - 1, ncy = ty.size() - ky - 1;
  Mat A(x.size(), ncx * ncy);
  Vec Nx(kx + 1), Ny(ky + 1);
  for (size_t r = 0; r < x.size(); r++) {
    const size_t sx = spl::findSpan(tx, kx, ncx, x[r]), sy = spl::findSpan(ty, ky, ncy, y[r]);
    spl::basisAt(tx, kx, sx, x[r], Nx.data());
    spl::basisAt(ty, ky, sy, y[r], Ny.data());
    for (int i = 0; i <= kx; i++)
      for (int j = 0; j <= ky; j++)
        A(r, (sx - kx + i) * ncy + sy - ky + j) = Nx[i] * Ny[j];
  }
  Vec c = la::lstsqMin(A, z);
  Mat C(ncx, ncy);
  C.a = c;
  return C;
}

Vec clampedKnots(double lo, double hi, const Vec &inner, int k) {
  Vec t(k + 1, lo);
  t.insert(t.end(), inner.begin(), inner.end());
  t.insert(t.end(), k + 1, hi);
  return t;
}

Value surfaceDict(const Vec &tx, const Vec &ty, const Mat &c, int kx, int ky) {
  return makeDict({{"tx", toValue(tx)}, {"ty", toValue(ty)}, {"c", toValue(c)}, {"kx", Value((double)kx)}, {"ky", Value((double)ky)}});
}

// Knots added at the midpoints of the data until the residual reaches s.
bool fitSurface(const Vec &x, const Vec &y, const Vec &z, int kx, int ky, double s, Vec &tx, Vec &ty, Mat &C) {
  double xlo = *std::min_element(x.begin(), x.end()), xhi = *std::max_element(x.begin(), x.end());
  double ylo = *std::min_element(y.begin(), y.end()), yhi = *std::max_element(y.begin(), y.end());
  if (x.size() < (size_t)((kx + 1) * (ky + 1)))
    return false;
  Vec inX, inY;
  for (int it = 0; it < 12; it++) {
    tx = clampedKnots(xlo, xhi, inX, kx);
    ty = clampedKnots(ylo, yhi, inY, ky);
    C = lsqSurface(x, y, z, tx, ty, kx, ky);
    double fp = 0.0;
    for (size_t i = 0; i < x.size(); i++) {
      const double e = z[i] - surfaceAt(tx, ty, C, kx, ky, x[i], y[i]);
      fp += e * e;
    }
    if (fp <= s || (inX.size() + kx + 1) * (inY.size() + ky + 1) * 2 > x.size())
      break;
    auto refine = [](Vec &in, double lo, double hi) {
      Vec all{lo};
      all.insert(all.end(), in.begin(), in.end());
      all.push_back(hi);
      Vec out;
      for (size_t i = 0; i + 1 < all.size(); i++) {
        if (i)
          out.push_back(all[i]);
        out.push_back(0.5 * (all[i] + all[i + 1]));
      }
      in = out;
    };
    refine(inX, xlo, xhi);
    refine(inY, ylo, yhi);
  }
  return true;
}

// Clough-Tocher: one cubic Bezier patch on each of the triangle's three parts.
struct CTGrad {
  double gx, gy;
};
double cloughTocher(const Mat &P, const Vec &v, const std::vector<CTGrad> &g, const std::vector<size_t> &t, const Vec &b) {
  // Bernstein control points of the macro-element, in the Lawson form.
  const double *p[3] = {P.row(t[0]), P.row(t[1]), P.row(t[2])};
  double f[3], c1[3][2];
  for (int i = 0; i < 3; i++) {
    f[i] = v[t[i]];
    const int j = (i + 1) % 3, k = (i + 2) % 3;
    c1[i][0] = f[i] + (g[t[i]].gx * (p[j][0] - p[i][0]) + g[t[i]].gy * (p[j][1] - p[i][1])) / 3.0;
    c1[i][1] = f[i] + (g[t[i]].gx * (p[k][0] - p[i][0]) + g[t[i]].gy * (p[k][1] - p[i][1])) / 3.0;
  }
  double near[3];
  for (int i = 0; i < 3; i++) // the control point next to the centre, toward vertex i
    near[i] = (f[i] + c1[i][0] + c1[i][1]) / 3.0;
  double side[3]; // the control point on the centre side of edge i -> i + 1, C1 across the inner edges
  for (int i = 0; i < 3; i++) {
    const int j = (i + 1) % 3;
    side[i] = (c1[i][0] + c1[j][1] + (near[i] + near[j]) * 1.5) / 5.0;
  }
  const double centre = (near[0] + near[1] + near[2]) / 3.0;
  // Which of the three parts holds the point.
  int part = 0;
  if (b[0] <= b[1] && b[0] <= b[2])
    part = 1; // opposite vertex 0: vertices 1, 2
  else if (b[1] <= b[0] && b[1] <= b[2])
    part = 2; // vertices 2, 0
  else
    part = 0; // vertices 0, 1
  const int i = part, j = (part + 1) % 3, k = 3 - i - j;
  // Barycentric coordinates in (i, j, centre).
  const double wk = 3.0 * b[k];
  const double wi = b[i] - b[k], wj = b[j] - b[k];
  const double u = wi, w = wj, c = wk;
  const double u2 = u * u, w2 = w * w, c2 = c * c;
  return u2 * u * f[i] + w2 * w * f[j] + c2 * c * centre + 3.0 * u2 * w * c1[i][0] + 3.0 * u * w2 * c1[j][1] + 3.0 * u2 * c * near[i] +
         3.0 * w2 * c * near[j] + 3.0 * u * c2 * (centre + 2.0 * near[i]) / 3.0 * 0.0 + 3.0 * u * c2 * ((2.0 * near[i] + near[j] + near[k]) / 4.0 * 0.0 + (near[i] + centre) / 2.0) +
         3.0 * w * c2 * (near[j] + centre) / 2.0 + 6.0 * u * w * c * side[i];
}

// The gradient at each point from a least-squares quadratic on its nearest neighbours.
std::vector<CTGrad> estimateGradients(const Mat &P, const Vec &v) {
  const size_t n = P.r;
  std::vector<CTGrad> g(n);
  for (size_t p = 0; p < n; p++) {
    std::vector<std::pair<double, size_t>> near;
    for (size_t q = 0; q < n; q++)
      if (q != p)
        near.push_back({std::hypot(P(q, 0) - P(p, 0), P(q, 1) - P(p, 1)), q});
    const size_t m = std::min<size_t>(12, near.size());
    std::partial_sort(near.begin(), near.begin() + m, near.end());
    const size_t cols = m >= 5 ? 5 : 2;
    Mat A(m, cols);
    Vec b(m);
    for (size_t r = 0; r < m; r++) {
      const double dx = P(near[r].second, 0) - P(p, 0), dy = P(near[r].second, 1) - P(p, 1);
      const double w = 1.0 / std::max(near[r].first, 1e-300);
      A(r, 0) = dx * w;
      A(r, 1) = dy * w;
      if (cols == 5) {
        A(r, 2) = dx * dx * w;
        A(r, 3) = dx * dy * w;
        A(r, 4) = dy * dy * w;
      }
      b[r] = (v[near[r].second] - v[p]) * w;
    }
    Vec c = la::lstsqMin(A, b);
    g[p] = {c[0], c[1]};
  }
  return g;
}

bool getPoints(const Args &a, CallContext &ctx, Mat &P, Vec &v, Mat &Q) {
  if (!getMat(a, 0, ctx, P) || !getVec(a, 1, ctx, v) || !getMat(a, 2, ctx, Q))
    return false;
  if (v.size() != P.r) {
    ctx.fail("values must have one number per point");
    return false;
  }
  if (Q.c != P.c) {
    ctx.fail("the query points need " + std::to_string(P.c) + " coordinates");
    return false;
  }
  return true;
}

// [g, g] in NC is one long row: the shape of `values` tells where to cut it.
bool splitAxes(const Value &gridV, const std::vector<size_t> &sizes, std::vector<Vec> &axes) {
  Mat m;
  if (!readMat(gridV, m))
    return false;
  axes.clear();
  if (m.r == sizes.size() && m.r > 1) { // one row per axis (equal lengths)
    for (size_t i = 0; i < m.r; i++)
      axes.emplace_back(m.row(i), m.row(i) + m.c);
    return m.c == sizes[0];
  }
  size_t total = 0;
  for (size_t s : sizes)
    total += s;
  if (m.a.size() != total)
    return false;
  size_t pos = 0;
  for (size_t s : sizes) {
    axes.emplace_back(m.a.begin() + pos, m.a.begin() + pos + s);
    pos += s;
  }
  return true;
}

} // namespace

void registerInterpolationNd(Registry &reg) {
  SP_ADD("griddata", 3, 4, "points, values, xi, method=\"linear\"") {
    Mat P, Q;
    Vec v;
    if (!getPoints(a, ctx, P, v, Q))
      return Value(0.0);
    const std::string m = optText(a, 3, "linear");
    Vec o(Q.r, kNaN);
    if (m == "nearest") {
      par::forBlocks(Q.r, {par::Kind::Compute, 1000.0}, [&](size_t bb, size_t ee) {
        for (size_t i = bb; i < ee; i++) {
          double best = kInf;
          for (size_t p = 0; p < P.r; p++) {
            double s = 0.0;
            for (size_t j = 0; j < P.c; j++)
              s += (Q(i, j) - P(p, j)) * (Q(i, j) - P(p, j));
            if (s < best) {
              best = s;
              o[i] = v[p];
            }
          }
        }
      });
      return toValue(o);
    }
    if (m != "linear" && m != "cubic") {
      ctx.fail("method must be \"linear\", \"nearest\" or \"cubic\"");
      return Value(0.0);
    }
    if (m == "cubic" && P.c != 2) {
      ctx.fail("method \"cubic\" works on two-dimensional points");
      return Value(0.0);
    }
    std::vector<std::vector<size_t>> simp;
    if (!geom::delaunay(P, simp)) {
      ctx.fail("the points do not span the space");
      return Value(0.0);
    }
    std::vector<CTGrad> g;
    if (m == "cubic")
      g = estimateGradients(P, v);
    for (size_t i = 0; i < Q.r; i++) {
      Vec bary;
      const long long s = geom::findSimplex(P, simp, Q.row(i), &bary);
      if (s < 0)
        continue;
      if (m == "cubic") {
        o[i] = cloughTocher(P, v, g, simp[(size_t)s], bary);
      } else {
        double t = 0.0;
        for (size_t k = 0; k < bary.size(); k++)
          t += bary[k] * v[simp[(size_t)s][k]];
        o[i] = t;
      }
    }
    return toValue(o);
  } SP_END
  SP_ADD("rbf_interp", 3, 6, "points, values, xi, kernel=\"thin_plate_spline\", epsilon=1, degree") {
    Mat P, Q;
    Vec v;
    if (!getPoints(a, ctx, P, v, Q))
      return Value(0.0);
    const std::string kernel = optText(a, 3, "thin_plate_spline");
    static const char *known[] = {"linear", "thin_plate_spline", "cubic", "quintic", "multiquadric", "inverse_multiquadric", "inverse_quadratic", "gaussian"};
    if (std::find_if(std::begin(known), std::end(known), [&](const char *k) { return kernel == k; }) == std::end(known)) {
      ctx.fail("unknown kernel \"" + kernel + "\"");
      return Value(0.0);
    }
    const double eps = optNum(a, 4, 1.0);
    const int degree = isNumberArg(a, 5) ? (int)a[5].number : rbfMinDegree(kernel);
    std::vector<std::vector<int>> pw;
    monomials(P.c, degree, pw);
    const size_t n = P.r, m = pw.size();
    // Polynomial part on shifted, scaled coordinates, as SciPy.
    Vec lo(P.c, kInf), hi(P.c, -kInf);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < P.c; j++) {
        lo[j] = std::min(lo[j], P(i, j));
        hi[j] = std::max(hi[j], P(i, j));
      }
    auto poly = [&](const double *x, size_t k) {
      double t = 1.0;
      for (size_t j = 0; j < P.c; j++) {
        const double sc = hi[j] > lo[j] ? (hi[j] - lo[j]) / 2.0 : 1.0;
        t *= std::pow((x[j] - (hi[j] + lo[j]) / 2.0) / sc, pw[k][j]);
      }
      return t;
    };
    auto dist = [&](const double *x, const double *y) {
      double s = 0.0;
      for (size_t j = 0; j < P.c; j++)
        s += (x[j] - y[j]) * (x[j] - y[j]);
      return std::sqrt(s);
    };
    Mat M(n + m, n + m);
    Vec rhs(n + m, 0.0);
    for (size_t i = 0; i < n; i++) {
      rhs[i] = v[i];
      for (size_t j = 0; j < n; j++)
        M(i, j) = rbfKernel(kernel, dist(P.row(i), P.row(j)), eps);
      for (size_t k = 0; k < m; k++)
        M(i, n + k) = M(n + k, i) = poly(P.row(i), k);
    }
    if (!la::solveVec(M, rhs)) {
      ctx.fail("the system is singular; check for repeated points or too few points for the degree");
      return Value(0.0);
    }
    Vec o(Q.r);
    par::forBlocks(Q.r, {par::Kind::Compute, 500.0}, [&](size_t bb, size_t ee) {
      for (size_t r = bb; r < ee; r++) {
        double s = 0.0;
        for (size_t i = 0; i < n; i++)
          s += rhs[i] * rbfKernel(kernel, dist(Q.row(r), P.row(i)), eps);
        for (size_t k = 0; k < m; k++)
          s += rhs[n + k] * poly(Q.row(r), k);
        o[r] = s;
      }
    });
    return toValue(o);
  } SP_END
  SP_ADD("grid_interp", 3, 4, "grid, values, xi, method=\"linear\"") {
    Mat Z, Q;
    if (!getMat(a, 1, ctx, Z) || !getMat(a, 2, ctx, Q))
      return Value(0.0);
    std::vector<Vec> axes;
    std::vector<size_t> sizes{Z.r, Z.c};
    if (Z.r == 1) {
      sizes = {Z.c};
    }
    if (!splitAxes(a[0], sizes, axes)) {
      ctx.fail("the grid axes do not fit the shape of values");
      return Value(0.0);
    }
    if (Q.c != axes.size()) {
      ctx.fail("the query points need " + std::to_string(axes.size()) + " coordinates");
      return Value(0.0);
    }
    const std::string m = optText(a, 3, "linear");
    if (m != "linear" && m != "nearest" && m != "cubic") {
      ctx.fail("method must be \"linear\", \"nearest\" or \"cubic\"");
      return Value(0.0);
    }
    Vec o(Q.r);
    Vec tx, ty;
    Mat C;
    const bool twoD = axes.size() == 2;
    if (m == "cubic" && (!twoD || !tensorInterp(axes[0], axes[1], Z, 3, 3, tx, ty, C))) {
      ctx.fail("\"cubic\" needs a two-dimensional grid of at least four points per axis");
      return Value(0.0);
    }
    auto loc = [](const Vec &g, double x) {
      size_t i = std::upper_bound(g.begin(), g.end(), x) - g.begin();
      i = i == 0 ? 0 : i - 1;
      return std::min(i, g.size() - 2);
    };
    for (size_t r = 0; r < Q.r; r++) {
      bool inside = true;
      for (size_t d = 0; d < axes.size(); d++)
        inside = inside && Q(r, d) >= axes[d].front() && Q(r, d) <= axes[d].back();
      if (!inside) {
        ctx.fail("a query point lies outside the grid");
        return Value(0.0);
      }
      if (m == "cubic") {
        o[r] = surfaceAt(tx, ty, C, 3, 3, Q(r, 0), Q(r, 1));
        continue;
      }
      const size_t i = loc(axes[0], Q(r, 0));
      const double s = (Q(r, 0) - axes[0][i]) / (axes[0][i + 1] - axes[0][i]);
      if (!twoD) {
        o[r] = m == "nearest" ? Z(0, s <= 0.5 ? i : i + 1) : (1 - s) * Z(0, i) + s * Z(0, i + 1);
        continue;
      }
      const size_t j = loc(axes[1], Q(r, 1));
      const double u = (Q(r, 1) - axes[1][j]) / (axes[1][j + 1] - axes[1][j]);
      if (m == "nearest")
        o[r] = Z(s <= 0.5 ? i : i + 1, u <= 0.5 ? j : j + 1);
      else
        o[r] = (1 - s) * ((1 - u) * Z(i, j) + u * Z(i, j + 1)) + s * ((1 - u) * Z(i + 1, j) + u * Z(i + 1, j + 1));
    }
    return toValue(o);
  } SP_END
  SP_ADD("ndppoly_eval", 3, 3, "c, breaks, points") {
    // Two variables: c holds, per interval of the first axis, one row of (k + 1)^2-style
    // coefficients in the order [power of x, power of y] for a single cell, as an (kx+1) x (ky+1) matrix.
    Mat c, br, Q;
    if (!getMat(a, 0, ctx, c) || !getMat(a, 1, ctx, br) || !getMat(a, 2, ctx, Q))
      return Value(0.0);
    if (br.c < 2 || Q.c != 2 || br.r != 2) {
      ctx.fail("breaks needs one row per axis, for two variables");
      return Value(0.0);
    }
    const double x0 = br(0, 0), y0 = br(1, 0);
    Vec o(Q.r);
    for (size_t r = 0; r < Q.r; r++) {
      double s = 0.0;
      for (size_t i = 0; i < c.r; i++) {
        double t = 0.0;
        for (size_t j = 0; j < c.c; j++)
          t = t * (Q(r, 1) - y0) + c(i, j);
        s = s * (Q(r, 0) - x0) + t;
      }
      o[r] = s;
    }
    return toValue(o);
  } SP_END
  SP_ADD("ndbspline_eval", 4, 4, "t, c, k, points") {
    Mat T, C, Q;
    long long k;
    if (!getMat(a, 0, ctx, T) || !getMat(a, 1, ctx, C) || !argNonNegativeInt(a, 2, ctx, k) || !getMat(a, 3, ctx, Q))
      return Value(0.0);
    if (T.r != 2 || Q.c != 2) {
      ctx.fail("t needs one row of knots per axis, for two variables");
      return Value(0.0);
    }
    Vec tx(T.row(0), T.row(0) + T.c), ty(T.row(1), T.row(1) + T.c), o(Q.r);
    for (size_t r = 0; r < Q.r; r++)
      o[r] = surfaceAt(tx, ty, C, (int)k, (int)k, Q(r, 0), Q(r, 1));
    return toValue(o);
  } SP_END
  SP_ADD("rect_bispline", 5, 7, "gx, gy, z, xq, yq, kx=3, ky=3") {
    Vec gx, gy, qx, qy, tx, ty;
    Mat z, C;
    if (!getVec(a, 0, ctx, gx) || !getVec(a, 1, ctx, gy) || !getMat(a, 2, ctx, z) || !getVec(a, 3, ctx, qx) || !getVec(a, 4, ctx, qy))
      return Value(0.0);
    if (z.r != gx.size() || z.c != gy.size()) {
      ctx.fail("z must have one row per gx value and one column per gy value");
      return Value(0.0);
    }
    const int kx = (int)optInt(a, 5, 3), ky = (int)optInt(a, 6, 3);
    if (!tensorInterp(gx, gy, z, kx, ky, tx, ty, C)) {
      ctx.fail("too few grid points for this degree");
      return Value(0.0);
    }
    if (isPlainNumber(a[3]) && isPlainNumber(a[4]))
      return Value(surfaceAt(tx, ty, C, kx, ky, qx[0], qy[0]));
    Mat o(qx.size(), qy.size());
    for (size_t i = 0; i < qx.size(); i++)
      for (size_t j = 0; j < qy.size(); j++)
        o(i, j) = surfaceAt(tx, ty, C, kx, ky, qx[i], qy[j]);
    return toValue(o);
  } SP_END
#define NC_XYZ                                                                                     \
  Vec x, y, z;                                                                                     \
  if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y) || !getVec(a, 2, ctx, z))                     \
    return Value(0.0);                                                                             \
  if (x.size() != y.size() || x.size() != z.size()) {                                              \
    ctx.fail("x, y and z must have the same length");                                              \
    return Value(0.0);                                                                             \
  }
#define NC_FIT_SURFACE(NAME)                                                                       \
  SP_ADD(NAME, 3, 6, "x, y, z, kx=3, ky=3, s") {                                                   \
    NC_XYZ                                                                                         \
    const int kx = (int)optInt(a, 3, 3), ky = (int)optInt(a, 4, 3);                                \
    const double m = (double)x.size();                                                             \
    const double s = isNumberArg(a, 5) ? a[5].number : m - std::sqrt(2.0 * m);                     \
    Vec tx, ty;                                                                                    \
    Mat C;                                                                                         \
    if (!fitSurface(x, y, z, kx, ky, s, tx, ty, C)) {                                              \
      ctx.fail("too few points for these degrees");                                                \
      return Value(0.0);                                                                           \
    }                                                                                              \
    return surfaceDict(tx, ty, C, kx, ky);                                                         \
  } SP_END
  NC_FIT_SURFACE("smooth_bispline")
  NC_FIT_SURFACE("bisplrep")
  SP_ADD("lsq_bispline", 5, 7, "x, y, z, tx, ty, kx=3, ky=3") {
    NC_XYZ
    Vec ix, iy;
    if (!getVec(a, 3, ctx, ix) || !getVec(a, 4, ctx, iy))
      return Value(0.0);
    const int kx = (int)optInt(a, 5, 3), ky = (int)optInt(a, 6, 3);
    Vec tx = clampedKnots(*std::min_element(x.begin(), x.end()), *std::max_element(x.begin(), x.end()), ix, kx);
    Vec ty = clampedKnots(*std::min_element(y.begin(), y.end()), *std::max_element(y.begin(), y.end()), iy, ky);
    return surfaceDict(tx, ty, lsqSurface(x, y, z, tx, ty, kx, ky), kx, ky);
  } SP_END
  SP_ADD("bisplev", 3, 3, "x, y, tck") {
    Vec qx, qy, tx, ty;
    Mat C;
    const Value *txv = dictGet(a[2], "tx"), *tyv = dictGet(a[2], "ty"), *cv = dictGet(a[2], "c"), *kxv = dictGet(a[2], "kx"), *kyv = dictGet(a[2], "ky");
    if (!getVec(a, 0, ctx, qx) || !getVec(a, 1, ctx, qy))
      return Value(0.0);
    if (!txv || !tyv || !cv || !kxv || !kyv || !readVec(*txv, tx) || !readVec(*tyv, ty) || !readMat(*cv, C)) {
      ctx.fail("the third argument must be a surface Dict from bisplrep()");
      return Value(0.0);
    }
    const int kx = (int)kxv->number, ky = (int)kyv->number;
    if (isPlainNumber(a[0]) && isPlainNumber(a[1]))
      return Value(surfaceAt(tx, ty, C, kx, ky, qx[0], qy[0]));
    Mat o(qx.size(), qy.size());
    for (size_t i = 0; i < qx.size(); i++)
      for (size_t j = 0; j < qy.size(); j++)
        o(i, j) = surfaceAt(tx, ty, C, kx, ky, qx[i], qy[j]);
    return toValue(o);
  } SP_END
  // Splines on a sphere are tensor splines in (theta, phi); bisplev evaluates them.
  SP_ADD("sphere_grid_spline", 3, 3, "lats, lons, values") {
    Vec la_, lo, tx, ty;
    Mat z, C;
    if (!getVec(a, 0, ctx, la_) || !getVec(a, 1, ctx, lo) || !getMat(a, 2, ctx, z))
      return Value(0.0);
    if (z.r != la_.size() || z.c != lo.size()) {
      ctx.fail("values must have one row per latitude and one column per longitude");
      return Value(0.0);
    }
    for (double v : la_)
      if (v < 0.0 || v > kPi) {
        ctx.fail("lats must lie between 0 and pi");
        return Value(0.0);
      }
    for (double v : lo)
      if (v < 0.0 || v > 2.0 * kPi) {
        ctx.fail("lons must lie between 0 and 2*pi");
        return Value(0.0);
      }
    if (!tensorInterp(la_, lo, z, 3, 3, tx, ty, C)) {
      ctx.fail("needs at least four latitudes and four longitudes");
      return Value(0.0);
    }
    return surfaceDict(tx, ty, C, 3, 3);
  } SP_END
  SP_ADD("sphere_smooth_spline", 3, 4, "theta, phi, values, s=0") {
    NC_XYZ
    Vec tx, ty;
    Mat C;
    if (!fitSurface(x, y, z, 3, 3, optNum(a, 3, 0.0), tx, ty, C)) {
      ctx.fail("needs at least sixteen points");
      return Value(0.0);
    }
    return surfaceDict(tx, ty, C, 3, 3);
  } SP_END
  SP_ADD("sphere_lsq_spline", 5, 5, "theta, phi, values, tt, tp") {
    NC_XYZ
    Vec it, ip;
    if (!getVec(a, 3, ctx, it) || !getVec(a, 4, ctx, ip))
      return Value(0.0);
    Vec tx = clampedKnots(0.0, kPi, it, 3), ty = clampedKnots(0.0, 2.0 * kPi, ip, 3);
    return surfaceDict(tx, ty, lsqSurface(x, y, z, tx, ty, 3, 3), 3, 3);
  } SP_END
  reg.setParallel({"griddata", "rbf_interp"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
