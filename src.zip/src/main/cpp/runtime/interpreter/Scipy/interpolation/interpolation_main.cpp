// Section 8 of 25 - Interpolation (scipy.interpolate). 1-D rules and B-splines here;
// surfaces and scattered data in in_nd.cpp. Evaluation at many points goes through
// forBlocks: the model is read-only by then.
#include "interpolation_main.h"

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "in_spline.h"

#define SP_SEC Section::Interpolation

namespace nc {
namespace scipy {

void registerInterpolationNd(Registry &reg);

namespace {

constexpr par::Cost kEvalCost{par::Kind::Compute, 100.0};

// xq as given, and the result in the same shape: a number stays a number.
template <class F> Value evalAt(const Value &xq, F fn) {
  if (isPlainNumber(xq))
    return Value(fn(xq.number));
  Vec q;
  readVec(xq, q);
  Vec o(q.size());
  par::forBlocks(q.size(), kEvalCost, [&](size_t b, size_t e) {
    for (size_t i = b; i < e; i++)
      o[i] = fn(q[i]);
  });
  return toValue(o);
}

bool xyq(const Args &a, CallContext &ctx, Vec &x, Vec &y, size_t qi = 2, bool increasing = true) {
  if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y))
    return false;
  if (x.size() != y.size() || x.empty()) {
    ctx.fail("x and y must have the same length and not be empty");
    return false;
  }
  if (increasing)
    for (size_t i = 1; i < x.size(); i++)
      if (!(x[i] > x[i - 1])) {
        ctx.fail("x must be strictly increasing");
        return false;
      }
  if (qi < a.size() && !numericCells(a[qi])) {
    ctx.fail("the query points must be a number or an array of numbers");
    return false;
  }
  return true;
}

size_t bracket(const Vec &x, double v) {
  size_t i = std::upper_bound(x.begin(), x.end(), v) - x.begin();
  if (i == 0)
    return 0;
  if (i >= x.size())
    return x.size() - 2;
  return i - 1;
}

// Piecewise cubic from values and slopes.
double hermiteAt(const Vec &x, const Vec &y, const Vec &d, double v) {
  const size_t i = bracket(x, v);
  const double h = x[i + 1] - x[i], s = (v - x[i]) / h;
  return (1 + 2 * s) * (1 - s) * (1 - s) * y[i] + s * (1 - s) * (1 - s) * h * d[i] + s * s * (3 - 2 * s) * y[i + 1] + s * s * (s - 1) * h * d[i + 1];
}

Vec pchipSlopes(const Vec &x, const Vec &y) {
  const size_t n = x.size();
  Vec h(n - 1), m(n - 1), d(n, 0.0);
  for (size_t i = 0; i + 1 < n; i++) {
    h[i] = x[i + 1] - x[i];
    m[i] = (y[i + 1] - y[i]) / h[i];
  }
  if (n == 2) {
    d[0] = d[1] = m[0];
    return d;
  }
  for (size_t i = 1; i + 1 < n; i++) {
    if (m[i - 1] * m[i] <= 0.0)
      continue;
    const double w1 = 2 * h[i] + h[i - 1], w2 = h[i] + 2 * h[i - 1];
    d[i] = (w1 + w2) / (w1 / m[i - 1] + w2 / m[i]);
  }
  auto edge = [](double h0, double h1, double m0, double m1) {
    double e = ((2 * h0 + h1) * m0 - h0 * m1) / (h0 + h1);
    if (e * m0 <= 0.0)
      return 0.0;
    if (m0 * m1 <= 0.0 && std::fabs(e) > 3 * std::fabs(m0))
      return 3 * m0;
    return e;
  };
  d[0] = edge(h[0], h[1], m[0], m[1]);
  d[n - 1] = edge(h[n - 2], h[n - 3], m[n - 2], m[n - 3]);
  return d;
}

Vec akimaSlopes(const Vec &x, const Vec &y) {
  const size_t n = x.size();
  Vec m(n + 3);
  for (size_t i = 0; i + 1 < n; i++)
    m[i + 2] = (y[i + 1] - y[i]) / (x[i + 1] - x[i]);
  m[1] = 2 * m[2] - m[3];
  m[0] = 2 * m[1] - m[2];
  m[n + 1] = 2 * m[n] - m[n - 1];
  m[n + 2] = 2 * m[n + 1] - m[n];
  Vec d(n);
  double big = 0.0;
  for (size_t i = 0; i < n; i++) {
    big = std::max(big, std::fabs(m[i + 2]));
    big = std::max(big, std::fabs(m[i + 1]));
  }
  for (size_t i = 0; i < n; i++) {
    const double w1 = std::fabs(m[i + 3] - m[i + 2]), w2 = std::fabs(m[i + 1] - m[i]);
    if (w1 + w2 > 1e-9 * big)
      d[i] = (w1 * m[i + 1] + w2 * m[i + 2]) / (w1 + w2);
    else
      d[i] = 0.5 * (m[i + 1] + m[i + 2]);
  }
  return d;
}

// Second-order boundary conditions decide the slopes of the cubic spline.
bool cubicSlopes(const Vec &x, const Vec &y, const std::string &bc, Vec &d, CallContext &ctx) {
  const size_t n = x.size();
  d.assign(n, 0.0);
  if (n == 2) {
    d[0] = d[1] = (y[1] - y[0]) / (x[1] - x[0]);
    return true;
  }
  Mat A(n, n);
  Vec b(n, 0.0), h(n - 1), s(n - 1);
  for (size_t i = 0; i + 1 < n; i++) {
    h[i] = x[i + 1] - x[i];
    s[i] = (y[i + 1] - y[i]) / h[i];
  }
  for (size_t i = 1; i + 1 < n; i++) {
    A(i, i - 1) = h[i];
    A(i, i) = 2 * (h[i - 1] + h[i]);
    A(i, i + 1) = h[i - 1];
    b[i] = 3 * (h[i] * s[i - 1] + h[i - 1] * s[i]);
  }
  if (bc == "natural") {
    A(0, 0) = 2;
    A(0, 1) = 1;
    b[0] = 3 * s[0];
    A(n - 1, n - 1) = 2;
    A(n - 1, n - 2) = 1;
    b[n - 1] = 3 * s[n - 2];
  } else if (bc == "clamped") {
    A(0, 0) = 1;
    A(n - 1, n - 1) = 1;
  } else if (bc == "periodic") {
    if (std::fabs(y[0] - y[n - 1]) > 1e-10 * (1.0 + std::fabs(y[0]))) {
      ctx.fail("periodic needs the first and last y to be equal");
      return false;
    }
    A(0, 0) = 1;
    A(0, n - 1) = -1;
    A(n - 1, 0) = 2 * h[n - 2];
    A(n - 1, 1) = h[n - 2];
    A(n - 1, n - 2) = h[0];
    A(n - 1, n - 1) = 2 * h[0];
    b[n - 1] = 3 * (h[n - 2] * s[0] + h[0] * s[n - 2]);
  } else if (bc == "not-a-knot") {
    if (n == 3) {
      // One parabola.
      const double a0 = (s[1] - s[0]) / (h[0] + h[1]);
      d[0] = s[0] - a0 * h[0];
      d[1] = s[0] + a0 * h[0];
      d[2] = s[1] + a0 * h[1];
      return true;
    }
    A(0, 0) = h[1];
    A(0, 1) = h[0] + h[1];
    b[0] = ((h[0] + 2 * (h[0] + h[1])) * h[1] * s[0] + h[0] * h[0] * s[1]) / (h[0] + h[1]);
    A(n - 1, n - 1) = h[n - 3];
    A(n - 1, n - 2) = h[n - 2] + h[n - 3];
    b[n - 1] = (h[n - 2] * h[n - 2] * s[n - 3] + (2 * (h[n - 2] + h[n - 3]) + h[n - 2]) * h[n - 3] * s[n - 2]) / (h[n - 2] + h[n - 3]);
  } else {
    ctx.fail("bc must be \"not-a-knot\", \"natural\", \"clamped\" or \"periodic\"");
    return false;
  }
  d = b;
  return la::solveVec(A, d);
}

// Rational interpolation in barycentric form.
double barycentricAt(const Vec &x, const Vec &y, const Vec &w, double v) {
  double n = 0.0, m = 0.0;
  for (size_t i = 0; i < x.size(); i++) {
    if (v == x[i])
      return y[i];
    const double t = w[i] / (v - x[i]);
    n += t * y[i];
    m += t;
  }
  return n / m;
}

// Divided differences allowing repeated nodes: the repeats carry derivatives.
Vec kroghCoeffs(const Vec &x, const Vec &y) {
  const size_t n = x.size();
  Vec c(n, 0.0), V(n, 0.0);
  c[0] = y[0];
  for (size_t k = 1; k < n; k++) {
    size_t s = 0;
    while (s + 1 <= k && x[k - s - 1] == x[k])
      s++;
    double f = 1.0;
    for (size_t q = 2; q <= s; q++)
      f *= (double)q;
    V[0] = y[k] / f;
    for (size_t i = 0; i + s < k; i++)
      V[i + 1] = (c[i] - V[i]) / (x[i] - x[k]);
    c[k] = V[k - s];
  }
  return c;
}

} // namespace

void registerInterpolation(Registry &reg) {
  SP_ADD("interp1d", 3, 4, "x, y, xq, kind=\"linear\"") {
    Vec x, y;
    if (!xyq(a, ctx, x, y))
      return Value(0.0);
    const std::string kind = optText(a, 3, "linear");
    Vec q;
    readVec(a[2], q);
    for (double v : q)
      if (v < x.front() || v > x.back()) {
        ctx.fail("a query point lies outside the range of x");
        return Value(0.0);
      }
    if (kind == "linear")
      return evalAt(a[2], [&](double v) {
        const size_t i = bracket(x, v);
        return y[i] + (y[i + 1] - y[i]) * (v - x[i]) / (x[i + 1] - x[i]);
      });
    if (kind == "nearest")
      return evalAt(a[2], [&](double v) {
        size_t i = 0;
        double best = kInf;
        for (size_t k = 0; k < x.size(); k++)
          if (std::fabs(x[k] - v) < best) {
            best = std::fabs(x[k] - v);
            i = k;
          }
        return y[i];
      });
    int k = kind == "zero" ? 0 : kind == "slinear" ? 1 : kind == "quadratic" ? 2 : kind == "cubic" ? 3 : -1;
    if (k < 0) {
      ctx.fail("kind must be \"linear\", \"nearest\", \"zero\", \"slinear\", \"quadratic\" or \"cubic\"");
      return Value(0.0);
    }
    spl::BSpline s;
    if (!spl::interpolating(x, y, k, s)) {
      ctx.fail("too few points for this kind");
      return Value(0.0);
    }
    return evalAt(a[2], [&](double v) { return spl::evaluate(s, v); });
  } SP_END
  SP_ADD("spline_interp", 3, 4, "x, y, xq, k=3") {
    Vec x, y;
    if (!xyq(a, ctx, x, y))
      return Value(0.0);
    spl::BSpline s;
    const int k = (int)optInt(a, 3, 3);
    if (k < 0 || !spl::interpolating(x, y, k, s)) {
      ctx.fail("needs at least k + 1 points");
      return Value(0.0);
    }
    return evalAt(a[2], [&](double v) { return spl::evaluate(s, v); });
  } SP_END
  SP_ADD("cubic_spline", 3, 4, "x, y, xq, bc=\"not-a-knot\"") {
    Vec x, y, d;
    if (!xyq(a, ctx, x, y) || x.size() < 2) {
      if (ctx.ok())
        ctx.fail("needs at least two points");
      return Value(0.0);
    }
    if (!cubicSlopes(x, y, optText(a, 3, "not-a-knot"), d, ctx))
      return Value(0.0);
    return evalAt(a[2], [&](double v) { return hermiteAt(x, y, d, v); });
  } SP_END
  SP_ADD("pchip", 3, 3, "x, y, xq") {
    Vec x, y;
    if (!xyq(a, ctx, x, y) || x.size() < 2) {
      if (ctx.ok())
        ctx.fail("needs at least two points");
      return Value(0.0);
    }
    Vec d = pchipSlopes(x, y);
    return evalAt(a[2], [&](double v) { return hermiteAt(x, y, d, v); });
  } SP_END
  SP_ADD("akima", 3, 3, "x, y, xq") {
    Vec x, y;
    if (!xyq(a, ctx, x, y) || x.size() < 2) {
      if (ctx.ok())
        ctx.fail("needs at least two points");
      return Value(0.0);
    }
    Vec d = akimaSlopes(x, y);
    return evalAt(a[2], [&](double v) { return hermiteAt(x, y, d, v); });
  } SP_END
  SP_ADD("hermite_spline", 4, 4, "x, y, dydx, xq") {
    Vec x, y, d;
    if (!xyq(a, ctx, x, y, 3) || !getVec(a, 2, ctx, d))
      return Value(0.0);
    if (d.size() != x.size() || x.size() < 2) {
      ctx.fail("dydx must have the length of x, and at least two points are needed");
      return Value(0.0);
    }
    return evalAt(a[3], [&](double v) { return hermiteAt(x, y, d, v); });
  } SP_END
  SP_ADD("barycentric_interp", 3, 3, "xi, yi, xq") {
    Vec x, y;
    if (!xyq(a, ctx, x, y, 2, false))
      return Value(0.0);
    Vec w(x.size(), 1.0);
    double span = 0.0;
    for (double v : x)
      span = std::max(span, std::fabs(v - x[0]));
    for (size_t i = 0; i < x.size(); i++)
      for (size_t j = 0; j < x.size(); j++)
        if (i != j)
          w[i] /= (x[i] - x[j]) * (4.0 / (span == 0.0 ? 1.0 : span));
    return evalAt(a[2], [&](double v) { return barycentricAt(x, y, w, v); });
  } SP_END
  SP_ADD("krogh_interp", 3, 3, "xi, yi, xq") {
    Vec x, y;
    if (!xyq(a, ctx, x, y, 2, false))
      return Value(0.0);
    Vec c = kroghCoeffs(x, y);
    return evalAt(a[2], [&](double v) {
      double s = c.back();
      for (size_t i = c.size() - 1; i-- > 0;)
        s = s * (v - x[i]) + c[i];
      return s;
    });
  } SP_END
  SP_ADD("floater_hormann", 3, 4, "x, y, xq, d=3") {
    Vec x, y;
    if (!xyq(a, ctx, x, y))
      return Value(0.0);
    const long n = (long)x.size() - 1, d = optInt(a, 3, 3);
    if (d < 0 || d > n) {
      ctx.fail("d must lie between 0 and the number of points - 1");
      return Value(0.0);
    }
    Vec w(n + 1, 0.0);
    for (long k = 0; k <= n; k++) {
      double sum = 0.0;
      for (long i = std::max(k - d, 0L); i <= std::min(k, n - d); i++) {
        double prod = 1.0;
        for (long j = i; j <= i + d; j++)
          if (j != k)
            prod /= std::fabs(x[k] - x[j]);
        sum += prod;
      }
      w[k] = ((k - d) % 2 == 0 ? 1.0 : -1.0) * sum;
    }
    return evalAt(a[2], [&](double v) { return barycentricAt(x, y, w, v); });
  } SP_END
  SP_ADD("aaa_interp", 3, 5, "x, y, xq, rtol=1e-13, max_terms=100") {
    // The AAA greedy loop; the weights come from the smallest singular vector of the Loewner matrix.
    CVec x, y, q;
    if (!getCVec(a, 0, ctx, x) || !getCVec(a, 1, ctx, y) || !getCVec(a, 2, ctx, q))
      return Value(0.0);
    if (x.size() != y.size() || x.empty()) {
      ctx.fail("x and y must have the same length and not be empty");
      return Value(0.0);
    }
    const double rtol = optNum(a, 3, 1e-13);
    const size_t maxTerms = (size_t)optInt(a, 4, 100);
    const size_t M = x.size();
    double ynorm = 0.0;
    cd ymean = 0.0;
    for (const cd &v : y) {
      ynorm = std::max(ynorm, std::abs(v));
      ymean += v;
    }
    ymean /= (double)M;
    CVec r(M, ymean);
    std::vector<size_t> sup;
    std::vector<char> used(M, 0);
    CVec w;
    auto evalR = [&](const cd &z) {
      cd n = 0.0, d = 0.0;
      for (size_t k = 0; k < sup.size(); k++) {
        if (z == x[sup[k]])
          return y[sup[k]];
        cd t = w[k] / (z - x[sup[k]]);
        n += t * y[sup[k]];
        d += t;
      }
      return n / d;
    };
    for (size_t m = 0; m < std::min(maxTerms, (M + 1) / 2 + 1) && m < M; m++) {
      double worst = -1.0;
      size_t pick = 0;
      for (size_t i = 0; i < M; i++)
        if (!used[i] && std::abs(y[i] - r[i]) > worst) {
          worst = std::abs(y[i] - r[i]);
          pick = i;
        }
      used[pick] = 1;
      sup.push_back(pick);
      std::vector<size_t> rest;
      for (size_t i = 0; i < M; i++)
        if (!used[i])
          rest.push_back(i);
      if (rest.empty()) {
        w.assign(sup.size(), 1.0);
        // All points are support points: any weights interpolate.
        break;
      }
      CMat L(rest.size(), sup.size());
      for (size_t i = 0; i < rest.size(); i++)
        for (size_t j = 0; j < sup.size(); j++)
          L(i, j) = (y[rest[i]] - y[sup[j]]) / (x[rest[i]] - x[sup[j]]);
      CMat U, V;
      Vec sv;
      CMat Full = L;
      if (L.r < L.c) {
        // Pad so the null vector appears.
        Full = CMat(L.c, L.c);
        for (size_t i = 0; i < L.r; i++)
          for (size_t j = 0; j < L.c; j++)
            Full(i, j) = L(i, j);
      }
      la::svdThin(Full, U, sv, V);
      w.resize(sup.size());
      for (size_t j = 0; j < sup.size(); j++)
        w[j] = V(j, V.c - 1);
      double err = 0.0;
      for (size_t i = 0; i < M; i++) {
        r[i] = used[i] ? y[i] : evalR(x[i]);
        err = std::max(err, std::abs(y[i] - r[i]));
      }
      if (err <= rtol * ynorm)
        break;
    }
    CVec o(q.size());
    for (size_t i = 0; i < q.size(); i++)
      o[i] = evalR(q[i]);
    if (isPlainNumber(a[2]))
      return a[1].hasComplex() || a[0].hasComplex() ? scalarOf(o[0]) : Value(o[0].real());
    if (!a[0].hasComplex() && !a[1].hasComplex() && !a[2].hasComplex())
      for (cd &z : o)
        z = z.real();
    return realIfPossible(o);
  } SP_ENDC
  SP_ADD("ppoly_eval", 3, 3, "c, breaks, xq") {
    Mat c;
    Vec br;
    if (!getMat(a, 0, ctx, c) || !getVec(a, 1, ctx, br))
      return Value(0.0);
    if (c.c + 1 != br.size() || !numericCells(a[2])) {
      ctx.fail("c needs one column per interval, and xq must be numbers");
      return Value(0.0);
    }
    return evalAt(a[2], [&](double v) {
      const size_t i = bracket(br, v);
      double s = 0.0;
      for (size_t k = 0; k < c.r; k++)
        s = s * (v - br[i]) + c(k, i);
      return s;
    });
  } SP_END
  SP_ADD("bpoly_eval", 3, 3, "c, breaks, xq") {
    Mat c;
    Vec br;
    if (!getMat(a, 0, ctx, c) || !getVec(a, 1, ctx, br))
      return Value(0.0);
    if (c.c + 1 != br.size() || !numericCells(a[2])) {
      ctx.fail("c needs one column per interval, and xq must be numbers");
      return Value(0.0);
    }
    return evalAt(a[2], [&](double v) {
      const size_t i = bracket(br, v);
      const double s = (v - br[i]) / (br[i + 1] - br[i]);
      Vec w(c.r);
      for (size_t k = 0; k < c.r; k++)
        w[k] = c(k, i);
      for (size_t l = c.r; l-- > 1;)
        for (size_t k = 0; k < l; k++)
          w[k] = (1 - s) * w[k] + s * w[k + 1];
      return w.empty() ? 0.0 : w[0];
    });
  } SP_END
  SP_ADD("bspline_eval", 4, 4, "t, c, k, xq") {
    spl::BSpline s;
    long long k;
    if (!getVec(a, 0, ctx, s.t) || !getVec(a, 1, ctx, s.c) || !argNonNegativeInt(a, 2, ctx, k))
      return Value(0.0);
    s.k = (int)k;
    if (s.t.size() < s.c.size() + s.k + 1 || !numericCells(a[3])) {
      ctx.fail("t must have at least len(c) + k + 1 knots, and xq must be numbers");
      return Value(0.0);
    }
    return evalAt(a[3], [&](double v) { return spl::evaluate(s, v); });
  } SP_END
  SP_ADD("lsq_spline", 3, 4, "x, y, t, k=3") {
    Vec x, y, t;
    if (!xyq(a, ctx, x, y, 9, false) || !getVec(a, 2, ctx, t))
      return Value(0.0);
    spl::BSpline s;
    if (!spl::lsq(x, y, nullptr, t, (int)optInt(a, 3, 3), s)) {
      ctx.fail("too few knots for this degree");
      return Value(0.0);
    }
    return spl::toValue(s);
  } SP_END
  SP_ADD("smoothing_spline", 3, 4, "x, y, xq, lam") {
    // Natural cubic smoothing spline; lam by generalised cross-validation unless given.
    Vec x, y;
    if (!xyq(a, ctx, x, y))
      return Value(0.0);
    const size_t n = x.size();
    if (n < 5) {
      ctx.fail("needs at least five points");
      return Value(0.0);
    }
    Vec h(n - 1);
    for (size_t i = 0; i + 1 < n; i++)
      h[i] = x[i + 1] - x[i];
    Mat Q(n, n - 2), R(n - 2, n - 2);
    for (size_t j = 0; j + 2 < n; j++) {
      Q(j, j) = 1.0 / h[j];
      Q(j + 1, j) = -1.0 / h[j] - 1.0 / h[j + 1];
      Q(j + 2, j) = 1.0 / h[j + 1];
      R(j, j) = (h[j] + h[j + 1]) / 3.0;
      if (j + 3 < n)
        R(j, j + 1) = R(j + 1, j) = h[j + 1] / 6.0;
    }
    Mat Rinv;
    la::inverse(R, Rinv);
    Mat K = mul(mul(Q, Rinv), transposeOf(Q));
    auto fit = [&](double lam, Vec &g, double &gcv) {
      Mat A = K;
      for (double &v : A.a)
        v *= lam;
      for (size_t i = 0; i < n; i++)
        A(i, i) += 1.0;
      Mat Ainv;
      la::inverse(A, Ainv);
      g = mulVec(Ainv, y);
      double rss = 0.0, tr = 0.0;
      for (size_t i = 0; i < n; i++) {
        rss += (y[i] - g[i]) * (y[i] - g[i]);
        tr += 1.0 - Ainv(i, i);
      }
      gcv = rss / (double)n / std::pow(tr / (double)n, 2.0);
    };
    Vec g;
    double gcv, lam;
    if (isNumberArg(a, 3)) {
      lam = a[3].number;
      fit(lam, g, gcv);
    } else {
      // Grid in log lam, then golden-section refinement.
      double bestL = -10.0, best = kInf;
      for (double l = -10; l <= 10; l += 0.5) {
        fit(std::pow(10.0, l), g, gcv);
        if (gcv < best) {
          best = gcv;
          bestL = l;
        }
      }
      double lo = bestL - 0.5, hi = bestL + 0.5;
      const double ph = 0.6180339887498949;
      for (int it = 0; it < 40; it++) {
        const double c = hi - ph * (hi - lo), d = lo + ph * (hi - lo);
        double fc, fd;
        fit(std::pow(10.0, c), g, fc);
        fit(std::pow(10.0, d), g, fd);
        if (fc < fd)
          hi = d;
        else
          lo = c;
      }
      lam = std::pow(10.0, 0.5 * (lo + hi));
      fit(lam, g, gcv);
    }
    // Natural spline through g: slopes from the second derivatives gamma.
    Vec gam = mulVec(Rinv, mulVec(transposeOf(Q), g));
    Vec m2(n, 0.0);
    for (size_t i = 0; i + 2 < n; i++)
      m2[i + 1] = gam[i];
    return evalAt(a[2], [&](double v) {
      const size_t i = bracket(x, v);
      const double hh = h[i], t = (v - x[i]) / hh;
      const double A = 1 - t, B = t;
      return A * g[i] + B * g[i + 1] + ((A * A * A - A) * m2[i] + (B * B * B - B) * m2[i + 1]) * hh * hh / 6.0;
    });
  } SP_END
  SP_ADD("spline_fit", 3, 4, "x, y, s, k=3") {
    Vec x, y;
    double s;
    if (!xyq(a, ctx, x, y, 9, false) || !argNumber(a, 2, ctx, s))
      return Value(0.0);
    spl::BSpline o;
    if (!spl::smoothing(x, y, nullptr, (int)optInt(a, 3, 3), s, o)) {
      ctx.fail("too few points for this degree");
      return Value(0.0);
    }
    return spl::toValue(o);
  } SP_END
  SP_ADD("spline_knots", 3, 4, "x, y, s, k=3") {
    Vec x, y;
    double s;
    if (!xyq(a, ctx, x, y, 9, false) || !argNumber(a, 2, ctx, s))
      return Value(0.0);
    spl::BSpline o;
    std::vector<Vec> h;
    if (!spl::smoothing(x, y, nullptr, (int)optInt(a, 3, 3), s, o, &h)) {
      ctx.fail("too few points for this degree");
      return Value(0.0);
    }
    std::vector<Value> cells;
    for (const Vec &t : h)
      cells.push_back(toValue(t));
    return Value(std::vector<Value>(cells));
  } SP_END
  SP_ADD("splrep", 2, 4, "x, y, k=3, s=0") {
    Vec x, y;
    if (!xyq(a, ctx, x, y, 9, false))
      return Value(0.0);
    const int k = (int)optInt(a, 2, 3);
    const double s = optNum(a, 3, 0.0);
    spl::BSpline o;
    if (k < 1 || k > 5 || (s == 0.0 ? !spl::interpolating(x, y, k, o) : !spl::smoothing(x, y, nullptr, k, s, o))) {
      ctx.fail("k must be 1 to 5 and x needs more than k points");
      return Value(0.0);
    }
    return spl::toValue(o);
  } SP_END
  SP_ADD("splev", 2, 3, "xq, tck, der=0") {
    spl::BSpline s;
    if (!numericCells(a[0])) {
      ctx.fail("the query points must be numbers");
      return Value(0.0);
    }
    if (!spl::readTck(a, 1, ctx, s))
      return Value(0.0);
    const int der = (int)optInt(a, 2, 0);
    return evalAt(a[0], [&](double v) { return spl::evaluate(s, v, der); });
  } SP_END
  SP_ADD("splint", 3, 3, "a, b, tck") {
    double lo, hi;
    spl::BSpline s;
    if (!argNumber(a, 0, ctx, lo) || !argNumber(a, 1, ctx, hi) || !spl::readTck(a, 2, ctx, s))
      return Value(0.0);
    return Value(spl::integral(s, lo, hi));
  } SP_END
  SP_ADD("sproot", 1, 1, "tck") {
    // Sign changes of the spline on a fine grid in every knot span, then bisection.
    spl::BSpline s;
    if (!spl::readTck(a, 0, ctx, s))
      return Value(0.0);
    if (s.k != 3) {
      ctx.fail("sproot works on cubic splines");
      return Value(0.0);
    }
    Vec roots;
    const size_t last = s.t.size() - s.k - 1;
    for (size_t i = s.k; i < last; i++) {
      if (s.t[i + 1] <= s.t[i])
        continue;
      const int steps = 16;
      double x0 = s.t[i], f0 = spl::evaluate(s, x0);
      for (int q = 1; q <= steps; q++) {
        const double x1 = s.t[i] + (s.t[i + 1] - s.t[i]) * q / steps, f1 = spl::evaluate(s, x1);
        if (f0 == 0.0) {
          if (roots.empty() || std::fabs(roots.back() - x0) > 1e-12)
            roots.push_back(x0);
        } else if (f0 * f1 < 0.0) {
          double lo = x0, hi = x1, flo = f0;
          for (int it = 0; it < 80; it++) {
            const double mid = 0.5 * (lo + hi), fm = spl::evaluate(s, mid);
            if (flo * fm <= 0.0)
              hi = mid;
            else {
              lo = mid;
              flo = fm;
            }
          }
          roots.push_back(0.5 * (lo + hi));
        }
        x0 = x1;
        f0 = f1;
      }
    }
    return toValue(roots);
  } SP_END
  SP_ADD("spalde", 2, 2, "xq, tck") {
    spl::BSpline s;
    Vec q;
    if (!getVec(a, 0, ctx, q) || !spl::readTck(a, 1, ctx, s))
      return Value(0.0);
    Mat o(q.size(), s.k + 1);
    for (size_t i = 0; i < q.size(); i++)
      for (int d = 0; d <= s.k; d++)
        o(i, d) = spl::evaluate(s, q[i], d);
    return q.size() == 1 ? toValue(o.a) : toValue(o);
  } SP_END
  SP_ADD("splder", 1, 2, "tck, n=1") {
    spl::BSpline s;
    if (!spl::readTck(a, 0, ctx, s))
      return Value(0.0);
    const int n = (int)optInt(a, 1, 1);
    if (n < 0 || n > s.k) {
      ctx.fail("the order must lie between 0 and the degree of the spline");
      return Value(0.0);
    }
    return spl::toValue(spl::derivative(s, n));
  } SP_END
  SP_ADD("splantider", 1, 2, "tck, n=1") {
    spl::BSpline s;
    if (!spl::readTck(a, 0, ctx, s))
      return Value(0.0);
    return spl::toValue(spl::antiderivative(s, (int)optInt(a, 1, 1)));
  } SP_END
  SP_ADD("spline_insert_knot", 2, 3, "x, tck, m=1") {
    double x;
    spl::BSpline s;
    if (!argNumber(a, 0, ctx, x) || !spl::readTck(a, 1, ctx, s))
      return Value(0.0);
    const long m = (long)optInt(a, 2, 1);
    for (long q = 0; q < m; q++) {
      // Boehm's algorithm.
      const size_t nc = s.t.size() - s.k - 1;
      const size_t span = spl::findSpan(s.t, s.k, nc, x);
      Vec c(nc + 1);
      for (size_t i = 0; i <= nc; i++) {
        if (i + s.k <= span)
          c[i] = s.c[i];
        else if (i > span)
          c[i] = s.c[i - 1];
        else {
          const double al = (x - s.t[i]) / (s.t[i + s.k] - s.t[i]);
          c[i] = al * s.c[i] + (1 - al) * s.c[i - 1];
        }
      }
      s.t.insert(s.t.begin() + span + 1, x);
      s.c = c;
    }
    return spl::toValue(s);
  } SP_END
  // A curve: one spline per dimension over a shared parameter u (chord length).
#define NC_CURVE_FIT(NAME)                                                                         \
  SP_ADD(NAME, 1, 3, "coords, s=0, k=3") {                                                         \
    Mat C;                                                                                         \
    if (!getMat(a, 0, ctx, C))                                                                     \
      return Value(0.0);                                                                           \
    const double sm = optNum(a, 1, 0.0);                                                           \
    const int k = (int)optInt(a, 2, 3);                                                            \
    Vec u(C.c, 0.0);                                                                               \
    for (size_t j = 1; j < C.c; j++) {                                                             \
      double d = 0.0;                                                                              \
      for (size_t i = 0; i < C.r; i++)                                                             \
        d += (C(i, j) - C(i, j - 1)) * (C(i, j) - C(i, j - 1));                                    \
      u[j] = u[j - 1] + std::sqrt(d);                                                              \
    }                                                                                              \
    if (u.back() <= 0.0) {                                                                         \
      ctx.fail("the curve has no length");                                                         \
      return Value(0.0);                                                                           \
    }                                                                                              \
    for (double &v : u)                                                                            \
      v /= u.back();                                                                               \
    std::vector<Value> rows;                                                                       \
    Vec knots;                                                                                     \
    Mat coef;                                                                                      \
    for (size_t i = 0; i < C.r; i++) {                                                             \
      Vec y(C.row(i), C.row(i) + C.c);                                                             \
      spl::BSpline s;                                                                              \
      const bool ok = sm == 0.0 ? spl::interpolating(u, y, k, s) : spl::smoothing(u, y, nullptr, k, sm / (double)C.r, s); \
      if (!ok) {                                                                                   \
        ctx.fail("too few points for this degree");                                                \
        return Value(0.0);                                                                         \
      }                                                                                            \
      if (i == 0) {                                                                                \
        knots = s.t;                                                                               \
        coef = Mat(C.r, s.c.size());                                                               \
      } else if (s.t != knots) {                                                                   \
        spl::lsq(u, y, nullptr, knots, k, s);                                                      \
      }                                                                                            \
      std::copy(s.c.begin(), s.c.end(), coef.row(i));                                              \
    }                                                                                              \
    Value tck = makeDict({{"t", toValue(knots)}, {"c", toValue(coef)}, {"k", Value((double)k)}});  \
    return makeDict({{"tck", tck}, {"spline", tck}, {"u", toValue(u)}});                           \
  } SP_END
  NC_CURVE_FIT("splprep")
  NC_CURVE_FIT("spline_fit_curve")
  SP_ADD("uni_spline", 3, 5, "x, y, xq, s, k=3") {
    Vec x, y;
    if (!xyq(a, ctx, x, y, 2, false))
      return Value(0.0);
    const int k = (int)optInt(a, 4, 3);
    const double s = isNumberArg(a, 3) ? a[3].number : (double)x.size();
    spl::BSpline o;
    if (s == 0.0 ? !spl::interpolating(x, y, k, o) : !spl::smoothing(x, y, nullptr, k, s, o)) {
      ctx.fail("too few points for this degree");
      return Value(0.0);
    }
    return evalAt(a[2], [&](double v) { return spl::evaluate(o, v); });
  } SP_END
  SP_ADD("lsq_uni_spline", 4, 5, "x, y, knots, xq, k=3") {
    Vec x, y, kn;
    if (!xyq(a, ctx, x, y, 3, false) || !getVec(a, 2, ctx, kn))
      return Value(0.0);
    const int k = (int)optInt(a, 4, 3);
    Vec t;
    for (int i = 0; i <= k; i++)
      t.push_back(x.front());
    t.insert(t.end(), kn.begin(), kn.end());
    for (int i = 0; i <= k; i++)
      t.push_back(x.back());
    spl::BSpline o;
    if (!spl::lsq(x, y, nullptr, t, k, o)) {
      ctx.fail("too few knots for this degree");
      return Value(0.0);
    }
    return evalAt(a[3], [&](double v) { return spl::evaluate(o, v); });
  } SP_END
  SP_ADD("lagrange", 2, 2, "x, y") {
    Vec x, y;
    if (!xyq(a, ctx, x, y, 9, false))
      return Value(0.0);
    const size_t n = x.size();
    Vec out(n, 0.0);
    for (size_t i = 0; i < n; i++) {
      Vec p{1.0};
      double den = 1.0;
      for (size_t j = 0; j < n; j++) {
        if (j == i)
          continue;
        Vec q(p.size() + 1, 0.0);
        for (size_t k = 0; k < p.size(); k++) {
          q[k] += p[k];
          q[k + 1] -= p[k] * x[j];
        }
        p = q;
        den *= x[i] - x[j];
      }
      for (size_t k = 0; k < n; k++)
        out[k] += p[k] * y[i] / den;
    }
    return toValue(out);
  } SP_END
  SP_ADD("taylor_poly", 4, 5, "fn, x, degree, scale, order") {
    // Fits a polynomial to samples on Chebyshev nodes, as approximate_taylor_polynomial.
    double x0, scale;
    long long deg;
    if (!isCallable(a[0]) || !argNumber(a, 1, ctx, x0) || !argNonNegativeInt(a, 2, ctx, deg) || !argNumber(a, 3, ctx, scale)) {
      if (ctx.ok())
        ctx.fail("the first argument must name an NC function");
      return Value(0.0);
    }
    const long long order = isNumberArg(a, 4) ? std::max((long long)a[4].number, deg) : deg;
    NcFn f(a[0]);
    const size_t n = (size_t)order + 1;
    Vec xs(n), ys(n);
    for (size_t i = 0; i < n; i++) {
      xs[i] = scale * std::cos(kPi * (double)i / (double)n);
      ys[i] = f.scalar(x0 + xs[i]);
      if (f.failed) {
        ctx.fail(f.failText());
        return Value(0.0);
      }
    }
    Mat V(n, n);
    for (size_t i = 0; i < n; i++) {
      double p = 1.0;
      for (size_t j = 0; j < n; j++) {
        V(i, j) = p;
        p *= xs[i];
      }
    }
    Vec c = la::lstsqMin(V, ys);
    Vec out((size_t)deg + 1);
    for (size_t k = 0; k <= (size_t)deg; k++)
      out[(size_t)deg - k] = c[k];
    return toValue(out);
  } SP_END
  SP_ADD("pade", 2, 3, "coeffs, m, n") {
    Vec an;
    long long m;
    if (!getVec(a, 0, ctx, an) || !argNonNegativeInt(a, 1, ctx, m))
      return Value(0.0);
    long long N = isNumberArg(a, 2) ? (long long)a[2].number : (long long)an.size() - 1 - m;
    if (N < 0 || (size_t)(N + m + 1) > an.size()) {
      ctx.fail("the orders need more coefficients than given");
      return Value(0.0);
    }
    an.resize((size_t)(N + m + 1));
    const size_t nn = (size_t)N, mm = (size_t)m, tot = nn + mm + 1;
    Mat A(tot, tot);
    Vec b(tot);
    for (size_t i = 0; i <= nn; i++)
      A(i, i) = 1.0;
    for (size_t r = 0; r < tot; r++) {
      b[r] = an[r];
      for (size_t k = 1; k <= mm; k++)
        if (r >= k)
          A(r, nn + k) = -an[r - k];
    }
    if (!la::solveVec(A, b)) {
      ctx.fail("this Pade approximant does not exist");
      return Value(0.0);
    }
    Vec p, q{1.0};
    for (size_t i = 0; i <= nn; i++)
      p.push_back(b[i]);
    for (size_t k = 1; k <= mm; k++)
      q.push_back(b[nn + k]);
    std::reverse(p.begin(), p.end());
    std::reverse(q.begin(), q.end());
    return makeDict({{"p", toValue(p)}, {"q", toValue(q)}});
  } SP_END
  registerInterpolationNd(reg);
  reg.setParallel({"interp1d", "spline_interp", "cubic_spline", "pchip", "akima", "hermite_spline", "barycentric_interp", "krogh_interp",
                   "floater_hormann", "ppoly_eval", "bpoly_eval", "bspline_eval", "splev", "uni_spline", "lsq_uni_spline", "smoothing_spline"},
                  ParallelClass::Kernel);
  reg.setParallel({"taylor_poly"}, ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
