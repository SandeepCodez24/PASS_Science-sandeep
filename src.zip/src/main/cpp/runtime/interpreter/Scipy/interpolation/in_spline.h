// B-spline kernels of the interpolation section.
#ifndef NC_SCIPY_IN_SPLINE_H
#define NC_SCIPY_IN_SPLINE_H

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace spl {

struct BSpline {
  Vec t, c;
  int k = 3;
};

size_t findSpan(const Vec &t, int k, size_t nc, double x);
// The k + 1 basis functions that are not zero at x, in interval `span`.
void basisAt(const Vec &t, int k, size_t span, double x, double *out);
double evaluate(const BSpline &s, double x, int der = 0);
BSpline derivative(const BSpline &s, int n);
BSpline antiderivative(const BSpline &s, int n);
double integral(const BSpline &s, double a, double b);
// Passes through every point; knots chosen as make_interp_spline does.
bool interpolating(const Vec &x, const Vec &y, int k, BSpline &out);
// Least squares for given full knots.
bool lsq(const Vec &x, const Vec &y, const Vec *w, const Vec &t, int k, BSpline &out);
// FITPACK-style smoothing: knots added where the residual is largest until the
// squared residual can reach s, then the jump penalty is tuned to give exactly s.
bool smoothing(const Vec &x, const Vec &y, const Vec *w, int k, double s, BSpline &out, std::vector<Vec> *history = nullptr);
Value toValue(const BSpline &s);
bool fromValue(const Value &v, BSpline &s);
bool readTck(const Args &a, size_t i, CallContext &ctx, BSpline &s);

} // namespace spl
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_IN_SPLINE_H
