// What the optimisation files share.
#ifndef NC_SCIPY_OP_SHARED_H
#define NC_SCIPY_OP_SHARED_H

#include <functional>
#include <iostream>
#include <memory>

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace opt {

Vec numGrad(const std::function<double(const Vec &)> &f, const Vec &x, double f0);
double vnorm(const Vec &v);
double vdot(const Vec &a, const Vec &b);

// An objective; `fn` may be replaced (augmented Lagrangian) while the NC function stays.
struct Problem {
  std::function<double(const Vec &)> fn;
  std::function<Vec(const Vec &, double)> gradFn;
  std::shared_ptr<NcFn> nc, ncJac;
  double f(const Vec &x) const { return fn(x); }
  Vec grad(const Vec &x, double f0) const { return gradFn ? gradFn(x, f0) : numGrad(fn, x, f0); }
  bool failed() const { return (nc && nc->failed) || (ncJac && ncJac->failed); }
  std::string failText() const { return nc && nc->failed ? nc->failText() : (ncJac ? ncJac->failText() : "failed"); }
};

struct Result {
  Vec x, grad;
  double fun = 0.0;
  bool success = false;
  long nit = 0, nfev = 0;
  std::string message;
  Mat hessInv;
};

Value resultDict(const Result &r);
bool getFn(const Args &a, size_t i, CallContext &ctx);
bool getBounds(const Args &a, size_t i, CallContext &ctx, Mat &b, size_t n);

} // namespace opt

namespace graph_shared {
// Assignment problem, smallest total cost; infinite entries are forbidden pairs.
bool assignmentMin(const Mat &cost, IVec &rows, IVec &cols);
} // namespace graph_shared

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_OP_SHARED_H
