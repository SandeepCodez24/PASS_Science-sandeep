// Least squares of scipy.optimize, and orthogonal distance regression (section 12).
#include "../linear_algebra/la_core.h"
#include "op_shared.h"
#include "optimization_root_finding_main.h"

#define SP_SEC Section::OptimizationRootFinding

namespace nc {
namespace scipy {

using namespace opt;

namespace {

struct LmResult {
  Vec x, f;
  Mat J;
  long nfev = 0;
  bool ok = false;
};

Mat fdJacobian(const std::function<Vec(const Vec &)> &F, const Vec &x, const Vec &f0, const Mat *bounds) {
  Mat J(f0.size(), x.size());
  Vec p = x;
  for (size_t j = 0; j < x.size(); j++) {
    double h = std::sqrt(kEps) * std::max(1e-3, std::fabs(x[j]));
    if (bounds && !bounds->a.empty() && x[j] + h > (*bounds)(j, 1))
      h = -h;
    p[j] = x[j] + h;
    Vec f1 = F(p);
    for (size_t i = 0; i < f0.size(); i++)
      J(i, j) = (f1[i] - f0[i]) / h;
    p[j] = x[j];
  }
  return J;
}

// Levenberg-Marquardt, with the steps projected on the bounds (the "trf" and "dogbox" routes too).
LmResult levenberg(const std::function<Vec(const Vec &)> &F, Vec x, const Mat &bounds, const std::function<bool()> &failed, double tol, long maxit) {
  LmResult r;
  auto project = [&](Vec v) {
    if (!bounds.a.empty())
      for (size_t i = 0; i < v.size(); i++)
        v[i] = std::min(bounds(i, 1), std::max(bounds(i, 0), v[i]));
    return v;
  };
  x = project(x);
  Vec f = F(x);
  double cost = vdot(f, f), lambda = 1e-4;
  for (long it = 0; it < maxit && !failed(); it++) {
    Mat J = fdJacobian(F, x, f, &bounds);
    Mat JtJ = mul(transposeOf(J), J);
    Vec g = mulVec(transposeOf(J), f);
    double gmax = 0.0;
    for (size_t i = 0; i < g.size(); i++) {
      // Variables held at a bound do not count when the gradient pushes outwards.
      const bool held = !bounds.a.empty() && ((x[i] <= bounds(i, 0) && g[i] > 0) || (x[i] >= bounds(i, 1) && g[i] < 0));
      if (!held)
        gmax = std::max(gmax, std::fabs(g[i]));
    }
    if (gmax <= tol) {
      r.ok = true;
      break;
    }
    bool improved = false;
    for (int t = 0; t < 40; t++) {
      Mat A = JtJ;
      for (size_t i = 0; i < A.r; i++)
        A(i, i) += lambda * std::max(JtJ(i, i), 1e-12);
      Vec d = g;
      if (la::solveVec(A, d)) {
        Vec xn = x;
        for (size_t i = 0; i < x.size(); i++)
          xn[i] -= d[i];
        xn = project(xn);
        Vec fn = F(xn);
        const double cn = vdot(fn, fn);
        if (cn < cost) {
          const double drop = cost - cn;
          double dx = 0.0;
          for (size_t i = 0; i < x.size(); i++)
            dx = std::max(dx, std::fabs(xn[i] - x[i]));
          x = xn;
          f = fn;
          cost = cn;
          lambda = std::max(lambda * 0.2, 1e-15);
          improved = true;
          if (drop <= tol * cn || dx <= tol * (tol + vnorm(x)))
            r.ok = true;
          break;
        }
      }
      lambda *= 4.0;
    }
    if (!improved) {
      r.ok = true;
      break;
    }
    if (r.ok)
      break;
  }
  r.x = x;
  r.f = f;
  if (!failed())
    r.J = fdJacobian(F, x, f, &bounds);
  return r;
}

// The model call: f(x, p1, p2, ...) with an array or the parameters spread out.
Value callModel(NcFn &f, const Value &x, const Vec &p, bool asArray) {
  Args in{x};
  if (asArray)
    in.push_back(toValue(p));
  else
    for (double v : p)
      in.push_back(Value(v));
  return f.raw(in);
}

} // namespace

void registerOptLeastSquares(Registry &reg) {
  SP_ADD("least_squares", 2, 5, "fn, x0, bounds, method=\"trf\", tol=1e-8") {
    Vec x0;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, x0))
      return Value(0.0);
    Mat bd;
    if (!getBounds(a, 2, ctx, bd, x0.size()))
      return Value(0.0);
    const std::string m = optText(a, 3, "trf");
    if (m != "trf" && m != "dogbox" && m != "lm") {
      ctx.fail("method must be \"trf\", \"dogbox\" or \"lm\"");
      return Value(0.0);
    }
    NcFn f(a[0]);
    LmResult r = levenberg([&](const Vec &x) {
      Vec v = f.vecOfVec(x);
      return f.failed ? Vec(1, kNaN) : v;
    }, x0, bd, [&] { return f.failed; }, optNum(a, 4, 1e-8), 200 * (long)x0.size());
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"x", toValue(r.x)}, {"cost", Value(0.5 * vdot(r.f, r.f))}, {"fun", toValue(r.f)}, {"jac", toValue(r.J)},
                     {"success", Value::boolean(r.ok)}, {"nfev", Value((double)f.calls)}});
  } SP_END
  SP_ADD("nnls", 2, 2, "A, b") {
    // Lawson and Hanson's active-set method.
    Mat A;
    Vec b;
    if (!getMat(a, 0, ctx, A) || !getVec(a, 1, ctx, b))
      return Value(0.0);
    if (A.r != b.size()) {
      ctx.fail("A must have one row per value of b");
      return Value(0.0);
    }
    const size_t n = A.c;
    Vec x(n, 0.0);
    std::vector<char> passive(n, 0);
    Mat At = transposeOf(A);
    for (long iter = 0; iter < 30 * (long)n + 30; iter++) {
      Vec res = b;
      Vec Ax = mulVec(A, x);
      for (size_t i = 0; i < res.size(); i++)
        res[i] -= Ax[i];
      Vec w = mulVec(At, res);
      long pick = -1;
      double best = 1e-12 * (1.0 + vnorm(b));
      for (size_t j = 0; j < n; j++)
        if (!passive[j] && w[j] > best) {
          best = w[j];
          pick = (long)j;
        }
      if (pick < 0)
        break;
      passive[(size_t)pick] = 1;
      for (int inner = 0; inner <= (int)n; inner++) {
        std::vector<size_t> idx;
        for (size_t j = 0; j < n; j++)
          if (passive[j])
            idx.push_back(j);
        Mat Ap(A.r, idx.size());
        for (size_t i = 0; i < A.r; i++)
          for (size_t q = 0; q < idx.size(); q++)
            Ap(i, q) = A(i, idx[q]);
        Vec s = la::lstsqMin(Ap, b);
        bool feasible = true;
        for (double v : s)
          feasible = feasible && v > 0.0;
        if (feasible) {
          std::fill(x.begin(), x.end(), 0.0);
          for (size_t q = 0; q < idx.size(); q++)
            x[idx[q]] = s[q];
          break;
        }
        double alpha = 1.0;
        for (size_t q = 0; q < idx.size(); q++)
          if (s[q] <= 0.0)
            alpha = std::min(alpha, x[idx[q]] / (x[idx[q]] - s[q]));
        for (size_t q = 0; q < idx.size(); q++) {
          x[idx[q]] += alpha * (s[q] - x[idx[q]]);
          if (x[idx[q]] <= 1e-14) {
            x[idx[q]] = 0.0;
            passive[idx[q]] = 0;
          }
        }
      }
    }
    Vec Ax = mulVec(A, x);
    double rn = 0.0;
    for (size_t i = 0; i < b.size(); i++)
      rn += (b[i] - Ax[i]) * (b[i] - Ax[i]);
    return makeDict({{"x", toValue(x)}, {"rnorm", Value(std::sqrt(rn))}});
  } SP_END
  SP_ADD("lsq_linear", 2, 3, "A, b, bounds") {
    // Bounded-variable least squares: an active set over free variables.
    Mat A;
    Vec b, bv;
    if (!getMat(a, 0, ctx, A) || !getVec(a, 1, ctx, b))
      return Value(0.0);
    if (A.r != b.size()) {
      ctx.fail("A must have one row per value of b");
      return Value(0.0);
    }
    const size_t n = A.c;
    Vec lo(n, -kInf), hi(n, kInf);
    if (a.size() > 2 && !isOmitted(a, 2)) {
      Mat bm;
      if (!getMat(a, 2, ctx, bm))
        return Value(0.0);
      if (bm.a.size() == 2)
        for (size_t i = 0; i < n; i++) {
          lo[i] = bm.a[0];
          hi[i] = bm.a[1];
        }
      else if (bm.c == 2 && bm.r == n)
        for (size_t i = 0; i < n; i++) {
          lo[i] = bm(i, 0);
          hi[i] = bm(i, 1);
        }
      else {
        ctx.fail("bounds must be [low, high] or one such row per variable");
        return Value(0.0);
      }
    }
    Vec x = la::lstsqMin(A, b);
    std::vector<int> st(n, 0); // -1 at low, 1 at high
    for (size_t i = 0; i < n; i++)
      if (x[i] < lo[i]) {
        x[i] = lo[i];
        st[i] = -1;
      } else if (x[i] > hi[i]) {
        x[i] = hi[i];
        st[i] = 1;
      }
    Mat At = transposeOf(A);
    bool done = false;
    for (int it = 0; it < 200 && !done; it++) {
      // Solve on the free variables, walking back to the box when a step leaves it.
      std::vector<size_t> freeV;
      for (size_t j = 0; j < n; j++)
        if (st[j] == 0)
          freeV.push_back(j);
      Vec rhs = b;
      for (size_t j = 0; j < n; j++)
        if (st[j] != 0)
          for (size_t i = 0; i < A.r; i++)
            rhs[i] -= A(i, j) * x[j];
      if (!freeV.empty()) {
        Mat Af(A.r, freeV.size());
        for (size_t i = 0; i < A.r; i++)
          for (size_t q = 0; q < freeV.size(); q++)
            Af(i, q) = A(i, freeV[q]);
        Vec s = la::lstsqMin(Af, rhs);
        double alpha = 1.0;
        long hit = -1;
        for (size_t q = 0; q < freeV.size(); q++) {
          const size_t j = freeV[q];
          const double d = s[q] - x[j];
          if (d > 0 && x[j] + d > hi[j] && (hi[j] - x[j]) / d < alpha) {
            alpha = (hi[j] - x[j]) / d;
            hit = (long)j;
          } else if (d < 0 && x[j] + d < lo[j] && (lo[j] - x[j]) / d < alpha) {
            alpha = (lo[j] - x[j]) / d;
            hit = (long)j;
          }
        }
        for (size_t q = 0; q < freeV.size(); q++)
          x[freeV[q]] += alpha * (s[q] - x[freeV[q]]);
        if (hit >= 0) {
          st[(size_t)hit] = s[0] * 0.0 + (x[(size_t)hit] >= hi[(size_t)hit] ? 1 : -1);
          continue;
        }
      }
      Vec Ax = mulVec(A, x), r(b.size());
      for (size_t i = 0; i < b.size(); i++)
        r[i] = b[i] - Ax[i];
      Vec g = mulVec(At, r);
      double worst = 1e-10;
      long rel = -1;
      for (size_t j = 0; j < n; j++) {
        const double v = st[j] == -1 ? g[j] : st[j] == 1 ? -g[j] : 0.0;
        if (v > worst) {
          worst = v;
          rel = (long)j;
        }
      }
      if (rel < 0)
        done = true;
      else
        st[(size_t)rel] = 0;
    }
    Vec Ax = mulVec(A, x);
    double c = 0.0;
    for (size_t i = 0; i < b.size(); i++)
      c += (b[i] - Ax[i]) * (b[i] - Ax[i]);
    return makeDict({{"x", toValue(x)}, {"cost", Value(0.5 * c)}, {"success", Value::boolean(done)}});
  } SP_END
  SP_ADD("isotonic_regression", 1, 3, "y, weights, increasing=1") {
    // Pool adjacent violators.
    Vec y, w;
    if (!getVec(a, 0, ctx, y))
      return Value(0.0);
    if (!isOmitted(a, 1)) {
      if (!getVec(a, 1, ctx, w))
        return Value(0.0);
    } else {
      w.assign(y.size(), 1.0);
    }
    if (w.size() != y.size()) {
      ctx.fail("weights must have the length of y");
      return Value(0.0);
    }
    const bool inc = optBool(a, 2, true);
    if (!inc)
      std::reverse(y.begin(), y.end()), std::reverse(w.begin(), w.end());
    struct B {
      double m, w;
      size_t n;
    };
    std::vector<B> st;
    for (size_t i = 0; i < y.size(); i++) {
      B b{y[i], w[i], 1};
      while (!st.empty() && st.back().m >= b.m) {
        const double tw = st.back().w + b.w;
        b.m = (st.back().m * st.back().w + b.m * b.w) / tw;
        b.w = tw;
        b.n += st.back().n;
        st.pop_back();
      }
      st.push_back(b);
    }
    Vec x, bw;
    IVec blocks{0};
    size_t pos = 0;
    for (const B &b : st) {
      x.insert(x.end(), b.n, b.m);
      bw.push_back(b.w);
      pos += b.n;
      blocks.push_back((long long)pos);
    }
    if (!inc) {
      std::reverse(x.begin(), x.end());
      std::reverse(bw.begin(), bw.end());
      IVec bk;
      for (size_t i = blocks.size(); i-- > 0;)
        bk.push_back((long long)y.size() - blocks[i]);
      blocks = bk;
    }
    return makeDict({{"x", toValue(x)}, {"weights", toValue(bw)}, {"blocks", toValue(blocks)}});
  } SP_END
  SP_ADD("curve_fit", 3, 5, "fn, x, y, p0, sigma") {
    Vec y, sigma;
    if (!getFn(a, 0, ctx) || !getVec(a, 2, ctx, y))
      return Value(0.0);
    NcFn f(a[0]);
    Vec p0;
    if (!isOmitted(a, 3)) {
      if (!getVec(a, 3, ctx, p0))
        return Value(0.0);
    }
    if (a.size() > 4 && !isOmitted(a, 4) && !getVec(a, 4, ctx, sigma))
      return Value(0.0);
    if (sigma.size() == 1)
      sigma.assign(y.size(), double(sigma[0]));
    // How many parameters: try f(x, p1, ..., pk) with growing k when p0 is left out.
    bool asArray = false;
    if (p0.empty()) {
      const int inputs = functionInputCount(a[0]);
      if (inputs < 2) {
        ctx.fail("give a starting guess p0: the number of parameters could not be read from the function");
        return Value(0.0);
      }
      p0.assign((size_t)inputs - 1, 1.0);
    }
    auto residual = [&](const Vec &p) {
      Value out = callModel(f, a[1], p, asArray);
      Vec v;
      if (f.failed || !readVec(out, v) || v.size() != y.size()) {
        f.failed = true;
        return Vec(y.size(), kNaN);
      }
      for (size_t i = 0; i < v.size(); i++) {
        v[i] = v[i] - y[i];
        if (!sigma.empty())
          v[i] /= sigma[i];
      }
      return v;
    };
    LmResult r = levenberg(residual, p0, Mat(), [&] { return f.failed; }, 1e-10, 500 * (long)p0.size());
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    const double dof = (double)y.size() - (double)p0.size();
    Mat pc = la::pinv(mul(transposeOf(r.J), r.J));
    if (sigma.empty() && dof > 0)
      for (double &v : pc.a)
        v *= vdot(r.f, r.f) / dof;
    return makeDict({{"popt", toValue(r.x)}, {"pcov", toValue(pc)}, {"success", Value::boolean(r.ok)}});
  } SP_END
}

namespace {

// y = f(beta, x) for the built-in models of odr_fit.
bool builtinModel(const std::string &name, size_t &nbeta, size_t nvars, std::function<double(const Vec &, const double *)> &fn) {
  if (name == "linear") {
    nbeta = 2;
    fn = [](const Vec &b, const double *x) { return b[0] * x[0] + b[1]; };
  } else if (name == "quadratic") {
    nbeta = 3;
    fn = [](const Vec &b, const double *x) { return b[0] * x[0] * x[0] + b[1] * x[0] + b[2]; };
  } else if (name == "exponential") {
    nbeta = 2;
    fn = [](const Vec &b, const double *x) { return b[0] + std::exp(b[1] * x[0]); };
  } else if (name == "multilinear") {
    nbeta = nvars + 1;
    fn = [nvars](const Vec &b, const double *x) {
      double s = b[0];
      for (size_t i = 0; i < nvars; i++)
        s += b[i + 1] * x[i];
      return s;
    };
  } else if (name.rfind("poly", 0) == 0 && name.size() > 4) {
    const size_t deg = (size_t)std::atoi(name.c_str() + 4);
    nbeta = deg + 1;
    // Ascending powers: beta[0] + beta[1] x + ...
    fn = [deg](const Vec &b, const double *x) {
      double s = 0.0;
      for (size_t i = deg + 1; i-- > 0;)
        s = s * x[0] + b[i];
      return s;
    };
  } else {
    return false;
  }
  return true;
}

} // namespace

void registerOdrFit(Registry &reg) {
#undef SP_SEC
#define SP_SEC Section::OrthogonalDistanceRegression
  SP_ADD("odr_fit", 3, 6, "fn, x, y, beta0, sx, sy") {
    // Minimises sum((y - f(beta, x + d)) / sy)^2 + sum(d / sx)^2 over beta and the
    // x corrections d; the d are solved for inside each step (Boggs and Rogers' idea).
    if (!getFn(a, 0, ctx))
      return Value(0.0);
    Mat X;
    Vec y;
    if (!getMat(a, 1, ctx, X) || !getVec(a, 2, ctx, y))
      return Value(0.0);
    // One row per input variable; a plain Array is one variable.
    if (X.c != y.size() && X.r == y.size())
      X = transposeOf(X);
    if (X.c != y.size()) {
      ctx.fail("x must have one value per value of y");
      return Value(0.0);
    }
    const size_t m = X.r, n = y.size();
    std::function<double(const Vec &, const double *)> model;
    size_t nbeta = 0;
    const bool named = a[0].isText && builtinModel(a[0].text(), nbeta, m, model);
    NcFn f(a[0]);
    Vec beta;
    if (!isOmitted(a, 3) || (a.size() > 3 && !isPlainNumber(a[3]))) {
      if (!getVec(a, 3, ctx, beta))
        return Value(0.0);
    }
    if (named && !beta.empty() && beta.size() != nbeta) {
      ctx.fail("this model has " + std::to_string(nbeta) + " parameters, beta0 gives " + std::to_string(beta.size()));
      return Value(0.0);
    }
    if (beta.empty()) {
      if (!named) {
        ctx.fail("a model function needs a starting guess beta0");
        return Value(0.0);
      }
      // A linear fit in the model's parameters starts close; a polynomial is exact.
      beta.assign(nbeta, 1.0);
    }
    Vec sx, sy;
    if (a.size() > 4 && !isOmitted(a, 4) && !getVec(a, 4, ctx, sx))
      return Value(0.0);
    if (a.size() > 5 && !isOmitted(a, 5) && !getVec(a, 5, ctx, sy))
      return Value(0.0);
    auto weight = [](const Vec &s, size_t i) { return s.empty() ? 1.0 : 1.0 / (s.size() == 1 ? s[0] : s[i]); };
    auto modelAt = [&](const Vec &b, const Mat &Xc, Vec &out) {
      out.resize(n);
      if (named) {
        Vec row(m);
        for (size_t i = 0; i < n; i++) {
          for (size_t k = 0; k < m; k++)
            row[k] = Xc(k, i);
          out[i] = model(b, row.data());
        }
        return true;
      }
      Value xv = m == 1 ? toValue(Xc.a) : toValue(Xc);
      Value o = f.raw({toValue(b), xv});
      Vec v;
      if (f.failed || !readVec(o, v) || v.size() != n) {
        f.failed = true;
        return false;
      }
      out = v;
      return true;
    };
    // Unknowns: beta, then the corrections d (m * n of them).
    const size_t nb = beta.size(), nd = m * n;
    Vec p(nb + nd, 0.0);
    std::copy(beta.begin(), beta.end(), p.begin());
    auto residual = [&](const Vec &q) {
      Vec b(q.begin(), q.begin() + nb);
      Mat Xc = X;
      for (size_t k = 0; k < m; k++)
        for (size_t i = 0; i < n; i++)
          Xc(k, i) += q[nb + k * n + i];
      Vec fv;
      Vec r(n + nd);
      if (!modelAt(b, Xc, fv))
        return r;
      for (size_t i = 0; i < n; i++)
        r[i] = (fv[i] - y[i]) * weight(sy, i);
      for (size_t j = 0; j < nd; j++)
        r[n + j] = q[nb + j] * weight(sx, j % n);
      return r;
    };
    LmResult lm = levenberg(residual, p, Mat(), [&] { return f.failed; }, 1e-12, 200);
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    Vec best(lm.x.begin(), lm.x.begin() + nb);
    // Covariance of beta from the Jacobian's Schur complement.
    Mat JtJ = mul(transposeOf(lm.J), lm.J);
    Mat Inv = la::pinv(JtJ);
    Mat cov(nb, nb);
    for (size_t i = 0; i < nb; i++)
      for (size_t j = 0; j < nb; j++)
        cov(i, j) = Inv(i, j);
    const double dof = (double)n - (double)nb;
    const double resVar = dof > 0 ? vdot(lm.f, lm.f) / dof : 0.0;
    Vec sd(nb);
    for (size_t i = 0; i < nb; i++)
      sd[i] = std::sqrt(std::max(0.0, cov(i, i) * resVar));
    return makeDict({{"beta", toValue(best)}, {"sd_beta", toValue(sd)}, {"cov_beta", toValue(cov)}, {"res_var", Value(resVar)},
                     {"info", Value(lm.ok ? 1.0 : 4.0)}});
  } SP_END
  reg.setParallel({"odr_fit"}, ParallelClass::Interpreter);
#undef SP_SEC
#define SP_SEC Section::OptimizationRootFinding
}

} // namespace scipy
} // namespace nc
