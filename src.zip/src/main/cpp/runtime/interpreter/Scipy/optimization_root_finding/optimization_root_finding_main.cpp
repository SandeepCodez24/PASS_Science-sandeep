// Section 13 of 25 - Optimization & Root Finding (scipy.optimize): local and global
// minimisers here; roots, least squares and linear programming in the op_*.cpp files.
// Every evaluation calls the NC function, so all of this stays on the interpreter thread.
#include "optimization_root_finding_main.h"

#include <map>
#include <random>

#include "../../ops/matrix/matrix.h"
#include "../linear_algebra/la_core.h"
#include "op_shared.h"

#define SP_SEC Section::OptimizationRootFinding

namespace nc {
namespace scipy {

void registerOptRoots(Registry &reg);
void registerOptLeastSquares(Registry &reg);
void registerOptLinear(Registry &reg);

namespace opt {

Vec numGrad(const std::function<double(const Vec &)> &f, const Vec &x, double f0) {
  Vec g(x.size()), p = x;
  for (size_t i = 0; i < x.size(); i++) {
    const double h = std::sqrt(kEps) * std::max(1.0, std::fabs(x[i]));
    p[i] = x[i] + h;
    g[i] = (f(p) - f0) / h;
    p[i] = x[i];
  }
  return g;
}

double vnorm(const Vec &v) {
  double s = 0.0;
  for (double x : v)
    s += x * x;
  return std::sqrt(s);
}
double vdot(const Vec &a, const Vec &b) {
  double s = 0.0;
  for (size_t i = 0; i < a.size(); i++)
    s += a[i] * b[i];
  return s;
}

Value resultDict(const Result &r) {
  DictInit d{{"x", toValue(r.x)}, {"fun", Value(r.fun)}, {"success", Value::boolean(r.success)}, {"nit", Value((double)r.nit)},
             {"nfev", Value((double)r.nfev)}, {"message", Value(r.message)}};
  if (!r.hessInv.a.empty())
    d.push_back({"hess_inv", toValue(r.hessInv)});
  if (!r.grad.empty())
    d.push_back({"jac", toValue(r.grad)});
  return makeDict(d);
}

// Strong-Wolfe line search with zoom; returns the step, or 0 when it fails.
double wolfeSearch(const Problem &P, const Vec &x, const Vec &d, double f0, const Vec &g0, double &fNew, Vec &gNew, double a0 = 1.0) {
  const double c1 = 1e-4, c2 = 0.9;
  const double dg0 = vdot(g0, d);
  if (dg0 >= 0.0)
    return 0.0;
  Vec p(x.size());
  auto phi = [&](double al, Vec *grad) {
    for (size_t i = 0; i < x.size(); i++)
      p[i] = x[i] + al * d[i];
    const double f = P.f(p);
    if (grad)
      *grad = P.grad(p, f);
    return f;
  };
  double aPrev = 0.0, fPrev = f0, dgPrev = dg0, al = a0;
  Vec g;
  auto zoom = [&](double lo, double hi, double flo, double dglo) {
    for (int it = 0; it < 30; it++) {
      // Quadratic interpolation, safeguarded by bisection.
      Vec dummy;
      double fhi = phi(hi, nullptr);
      double m = lo - 0.5 * dglo * (hi - lo) * (hi - lo) / (fhi - flo - dglo * (hi - lo));
      const double l = std::min(lo, hi), u = std::max(lo, hi);
      if (!(m > l + 0.1 * (u - l) && m < u - 0.1 * (u - l)))
        m = 0.5 * (lo + hi);
      const double fm = phi(m, &g);
      const double dgm = vdot(g, d);
      if (fm > f0 + c1 * m * dg0 || fm >= flo) {
        hi = m;
      } else {
        if (std::fabs(dgm) <= -c2 * dg0) {
          fNew = fm;
          gNew = g;
          return m;
        }
        if (dgm * (hi - lo) >= 0.0)
          hi = lo;
        lo = m;
        flo = fm;
        dglo = dgm;
      }
      if (std::fabs(hi - lo) < 1e-14)
        break;
    }
    const double fl = phi(lo, &g);
    fNew = fl;
    gNew = g;
    return fl < f0 ? lo : 0.0;
  };
  for (int i = 0; i < 25; i++) {
    const double f = phi(al, &g);
    if (P.failed())
      return 0.0;
    if (f > f0 + c1 * al * dg0 || (i > 0 && f >= fPrev))
      return zoom(aPrev, al, fPrev, dgPrev);
    const double dg = vdot(g, d);
    if (std::fabs(dg) <= -c2 * dg0) {
      fNew = f;
      gNew = g;
      return al;
    }
    if (dg >= 0.0)
      return zoom(al, aPrev, f, dg);
    aPrev = al;
    fPrev = f;
    dgPrev = dg;
    al *= 2.0;
  }
  fNew = fPrev;
  gNew = g;
  return aPrev;
}

Result bfgs(const Problem &P, Vec x, double gtol, long maxit, const char *hessUpdate) {
  const size_t n = x.size();
  Result r;
  double f = P.f(x);
  Vec g = P.grad(x, f);
  Mat H = Mat::eye(n);
  const bool sr1 = hessUpdate && std::string(hessUpdate) == "SR1";
  long it = 0;
  for (; it < maxit && !P.failed(); it++) {
    double gmax = 0.0;
    for (double v : g)
      gmax = std::max(gmax, std::fabs(v));
    if (gmax <= gtol) {
      r.success = true;
      r.message = "Optimization terminated successfully.";
      break;
    }
    Vec d = mulVec(H, g);
    for (double &v : d)
      v = -v;
    if (vdot(d, g) >= 0.0) {
      H = Mat::eye(n);
      d = g;
      for (double &v : d)
        v = -v;
    }
    double fNew = f;
    Vec gNew;
    const double step0 = it == 0 ? std::min(1.0, 1.0 / std::max(vnorm(g), 1e-300)) : 1.0;
    const double al = wolfeSearch(P, x, d, f, g, fNew, gNew, step0);
    if (al == 0.0) {
      if (it > 0 && H.a != Mat::eye(n).a) {
        H = Mat::eye(n);
        continue;
      }
      r.message = "Desired error not necessarily achieved due to precision loss.";
      r.success = gmax <= 1e-3;
      break;
    }
    Vec s(n), y(n);
    for (size_t i = 0; i < n; i++) {
      s[i] = al * d[i];
      y[i] = gNew[i] - g[i];
      x[i] += s[i];
    }
    const double df = std::fabs(f - fNew);
    f = fNew;
    g = gNew;
    const double ys = vdot(y, s);
    if (sr1) {
      Vec Hy = mulVec(H, y), w(n);
      for (size_t i = 0; i < n; i++)
        w[i] = s[i] - Hy[i];
      const double den = vdot(w, y);
      if (std::fabs(den) > 1e-8 * vnorm(w) * vnorm(y))
        for (size_t i = 0; i < n; i++)
          for (size_t j = 0; j < n; j++)
            H(i, j) += w[i] * w[j] / den;
    } else if (ys > 1e-14) {
      Vec Hy = mulVec(H, y);
      const double yHy = vdot(y, Hy);
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
          H(i, j) += (1.0 + yHy / ys) * s[i] * s[j] / ys - (Hy[i] * s[j] + s[i] * Hy[j]) / ys;
    }
    if (df == 0.0 && vnorm(s) == 0.0)
      break;
  }
  if (it >= maxit)
    r.message = "Maximum number of iterations has been exceeded.";
  r.x = x;
  r.fun = f;
  r.grad = g;
  r.hessInv = H;
  r.nit = it;
  return r;
}

Result conjugateGradient(const Problem &P, Vec x, double gtol, long maxit) {
  const size_t n = x.size();
  Result r;
  double f = P.f(x);
  Vec g = P.grad(x, f), d = g;
  for (double &v : d)
    v = -v;
  long it = 0;
  for (; it < maxit && !P.failed(); it++) {
    double gmax = 0.0;
    for (double v : g)
      gmax = std::max(gmax, std::fabs(v));
    if (gmax <= gtol) {
      r.success = true;
      r.message = "Optimization terminated successfully.";
      break;
    }
    double fNew = f;
    Vec gNew;
    double al = wolfeSearch(P, x, d, f, g, fNew, gNew, it == 0 ? 1.0 / std::max(vnorm(g), 1e-300) : 1.0);
    if (al == 0.0) {
      // Restart along the steepest descent once.
      for (size_t i = 0; i < n; i++)
        d[i] = -g[i];
      al = wolfeSearch(P, x, d, f, g, fNew, gNew, 1.0 / std::max(vnorm(g), 1e-300));
      if (al == 0.0) {
        r.message = "Desired error not necessarily achieved due to precision loss.";
        r.success = gmax <= 1e-3;
        break;
      }
    }
    Vec y(n);
    for (size_t i = 0; i < n; i++) {
      x[i] += al * d[i];
      y[i] = gNew[i] - g[i];
    }
    const double beta = std::max(0.0, vdot(gNew, y) / vdot(g, g)); // Polak-Ribiere+
    for (size_t i = 0; i < n; i++)
      d[i] = -gNew[i] + beta * d[i];
    f = fNew;
    g = gNew;
  }
  r.x = x;
  r.fun = f;
  r.grad = g;
  r.nit = it;
  return r;
}

Result newtonCG(const Problem &P, Vec x, double xtol, long maxit) {
  const size_t n = x.size();
  Result r;
  double f = P.f(x);
  Vec g = P.grad(x, f);
  long it = 0;
  for (; it < maxit && !P.failed(); it++) {
    // Truncated CG on H d = -g, with products by a difference of gradients.
    Vec d(n, 0.0), rr = g, p = g;
    for (double &v : p)
      v = -v;
    const double gn = vnorm(g), tol = std::min(0.5, std::sqrt(gn)) * gn;
    double rs = vdot(rr, rr);
    for (size_t k = 0; k < 2 * n + 5; k++) {
      if (std::sqrt(rs) <= tol)
        break;
      Vec q(n), xp(n);
      const double eps = std::sqrt(kEps) * (1.0 + vnorm(x)) / std::max(vnorm(p), 1e-300);
      for (size_t i = 0; i < n; i++)
        xp[i] = x[i] + eps * p[i];
      const double fp = P.f(xp);
      Vec gp = P.grad(xp, fp);
      for (size_t i = 0; i < n; i++)
        q[i] = (gp[i] - g[i]) / eps;
      const double curv = vdot(p, q);
      if (curv <= 0.0) {
        if (k == 0)
          d = p;
        break;
      }
      const double al = rs / curv;
      for (size_t i = 0; i < n; i++) {
        d[i] += al * p[i];
        rr[i] += al * q[i];
      }
      const double rn = vdot(rr, rr);
      for (size_t i = 0; i < n; i++)
        p[i] = -rr[i] + (rn / rs) * p[i];
      rs = rn;
    }
    double fNew = f;
    Vec gNew;
    const double al = wolfeSearch(P, x, d, f, g, fNew, gNew);
    if (al == 0.0) {
      r.message = "Warning: Desired error not necessarily achieved due to precision loss.";
      r.success = vnorm(g) < 1e-3;
      break;
    }
    double stepMax = 0.0;
    for (size_t i = 0; i < n; i++) {
      x[i] += al * d[i];
      stepMax = std::max(stepMax, std::fabs(al * d[i]));
    }
    f = fNew;
    g = gNew;
    if (stepMax <= xtol) {
      r.success = true;
      r.message = "Optimization terminated successfully.";
      it++;
      break;
    }
  }
  r.x = x;
  r.fun = f;
  r.grad = g;
  r.nit = it;
  return r;
}

Vec clip(Vec x, const Mat &bounds) {
  if (bounds.a.empty())
    return x;
  for (size_t i = 0; i < x.size() && i < bounds.r; i++)
    x[i] = std::min(bounds(i, 1), std::max(bounds(i, 0), x[i]));
  return x;
}

Result nelderMead(const Problem &P, const Vec &x0, const Mat &bounds, double xatol, double fatol, long maxit) {
  const size_t n = x0.size();
  std::vector<Vec> sim(n + 1, x0);
  for (size_t i = 0; i < n; i++)
    sim[i + 1][i] = x0[i] != 0.0 ? x0[i] * 1.05 : 0.00025;
  for (Vec &s : sim)
    s = clip(s, bounds);
  Vec fs(n + 1);
  for (size_t i = 0; i <= n; i++)
    fs[i] = P.f(sim[i]);
  const double rho = 1.0, chi = 2.0, psi = 0.5, sigma = 0.5;
  Result r;
  long it = 0;
  std::vector<size_t> o(n + 1);
  for (; it < maxit && !P.failed(); it++) {
    for (size_t i = 0; i <= n; i++)
      o[i] = i;
    std::sort(o.begin(), o.end(), [&](size_t a, size_t b) { return fs[a] < fs[b]; });
    std::vector<Vec> s2(n + 1);
    Vec f2(n + 1);
    for (size_t i = 0; i <= n; i++) {
      s2[i] = sim[o[i]];
      f2[i] = fs[o[i]];
    }
    sim = s2;
    fs = f2;
    double dx = 0.0, df = 0.0;
    for (size_t i = 1; i <= n; i++) {
      df = std::max(df, std::fabs(fs[i] - fs[0]));
      for (size_t j = 0; j < n; j++)
        dx = std::max(dx, std::fabs(sim[i][j] - sim[0][j]));
    }
    if (dx <= xatol && df <= fatol) {
      r.success = true;
      r.message = "Optimization terminated successfully.";
      break;
    }
    Vec bar(n, 0.0);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        bar[j] += sim[i][j] / (double)n;
    auto along = [&](double t) {
      Vec v(n);
      for (size_t j = 0; j < n; j++)
        v[j] = bar[j] + t * (sim[n][j] - bar[j]);
      return clip(v, bounds);
    };
    Vec xr = along(-rho);
    const double fr = P.f(xr);
    bool shrink = false;
    if (fr < fs[0]) {
      Vec xe = along(-rho * chi);
      const double fe = P.f(xe);
      if (fe < fr) {
        sim[n] = xe;
        fs[n] = fe;
      } else {
        sim[n] = xr;
        fs[n] = fr;
      }
    } else if (fr < fs[n - 1]) {
      sim[n] = xr;
      fs[n] = fr;
    } else if (fr < fs[n]) {
      Vec xc = along(-psi * rho);
      const double fc = P.f(xc);
      if (fc <= fr) {
        sim[n] = xc;
        fs[n] = fc;
      } else
        shrink = true;
    } else {
      Vec xc = along(psi);
      const double fc = P.f(xc);
      if (fc < fs[n]) {
        sim[n] = xc;
        fs[n] = fc;
      } else
        shrink = true;
    }
    if (shrink)
      for (size_t i = 1; i <= n; i++) {
        for (size_t j = 0; j < n; j++)
          sim[i][j] = sim[0][j] + sigma * (sim[i][j] - sim[0][j]);
        sim[i] = clip(sim[i], bounds);
        fs[i] = P.f(sim[i]);
      }
  }
  size_t best = 0;
  for (size_t i = 1; i <= n; i++)
    if (fs[i] < fs[best])
      best = i;
  r.x = sim[best];
  r.fun = fs[best];
  r.nit = it;
  if (!r.success)
    r.message = "Maximum number of iterations has been exceeded.";
  return r;
}

// Brent's method along a line.
double lineMin(const std::function<double(double)> &f, double a, double b, double c, double tol, double &fx) {
  const double cg = 0.3819660112501051;
  double lo = std::min(a, c), hi = std::max(a, c);
  double x = b, w = b, v = b, fw, fv, d = 0.0, e = 0.0;
  fx = fw = fv = f(x);
  for (int it = 0; it < 200; it++) {
    const double m = 0.5 * (lo + hi), t1 = tol * std::fabs(x) + 1e-11, t2 = 2.0 * t1;
    if (std::fabs(x - m) <= t2 - 0.5 * (hi - lo))
      break;
    double u;
    bool golden = true;
    if (std::fabs(e) > t1) {
      double r = (x - w) * (fx - fv), q = (x - v) * (fx - fw), p = (x - v) * q - (x - w) * r;
      q = 2.0 * (q - r);
      if (q > 0.0)
        p = -p;
      q = std::fabs(q);
      const double etemp = e;
      e = d;
      if (!(std::fabs(p) >= std::fabs(0.5 * q * etemp) || p <= q * (lo - x) || p >= q * (hi - x))) {
        d = p / q;
        u = x + d;
        if (u - lo < t2 || hi - u < t2)
          d = m - x >= 0 ? t1 : -t1;
        golden = false;
      }
    }
    if (golden) {
      e = x >= m ? lo - x : hi - x;
      d = cg * e;
    }
    u = std::fabs(d) >= t1 ? x + d : x + (d >= 0 ? t1 : -t1);
    const double fu = f(u);
    if (fu <= fx) {
      if (u >= x)
        lo = x;
      else
        hi = x;
      v = w;
      fv = fw;
      w = x;
      fw = fx;
      x = u;
      fx = fu;
    } else {
      if (u < x)
        lo = u;
      else
        hi = u;
      if (fu <= fw || w == x) {
        v = w;
        fv = fw;
        w = u;
        fw = fu;
      } else if (fu <= fv || v == x || v == w) {
        v = u;
        fv = fu;
      }
    }
  }
  return x;
}

void bracketMin(const std::function<double(double)> &f, double &xa, double &xb, double &xc, double &fa, double &fb, double &fc, long &calls) {
  const double gold = 1.618034, glimit = 110.0;
  fa = f(xa);
  fb = f(xb);
  calls = 2;
  if (fa < fb) {
    std::swap(xa, xb);
    std::swap(fa, fb);
  }
  xc = xb + gold * (xb - xa);
  fc = f(xc);
  calls++;
  for (int it = 0; fc < fb && it < 1000; it++) {
    const double t1 = (xb - xa) * (fb - fc), t2 = (xb - xc) * (fb - fa), val = t2 - t1;
    const double denom = std::fabs(val) < 1e-21 ? 2e-21 : 2.0 * val;
    double w = xb - ((xb - xc) * t2 - (xb - xa) * t1) / denom;
    const double wlim = xb + glimit * (xc - xb);
    double fw;
    if ((w - xc) * (xb - w) > 0.0) {
      fw = f(w);
      calls++;
      if (fw < fc) {
        xa = xb;
        xb = w;
        fa = fb;
        fb = fw;
        break;
      }
      if (fw > fb) {
        xc = w;
        fc = fw;
        break;
      }
      w = xc + gold * (xc - xb);
      fw = f(w);
      calls++;
    } else if ((w - wlim) * (wlim - xc) >= 0.0) {
      w = wlim;
      fw = f(w);
      calls++;
    } else if ((w - wlim) * (xc - w) > 0.0) {
      fw = f(w);
      calls++;
      if (fw < fc) {
        xb = xc;
        xc = w;
        w = xc + gold * (xc - xb);
        fb = fc;
        fc = fw;
        fw = f(w);
        calls++;
      }
    } else {
      w = xc + gold * (xc - xb);
      fw = f(w);
      calls++;
    }
    xa = xb;
    xb = xc;
    xc = w;
    fa = fb;
    fb = fc;
    fc = fw;
  }
}

Result powell(const Problem &P, Vec x, const Mat &bounds, double xtol, double ftol, long maxit) {
  const size_t n = x.size();
  Mat dirs = Mat::eye(n);
  Result r;
  x = clip(x, bounds);
  double f = P.f(x);
  long it = 0;
  auto searchAlong = [&](Vec &px, const double *d, double &fv) {
    auto g = [&](double t) {
      Vec q(n);
      for (size_t i = 0; i < n; i++)
        q[i] = px[i] + t * d[i];
      return P.f(clip(q, bounds));
    };
    double xa = 0.0, xb = 1.0, xc, fa, fb, fc;
    long calls;
    bracketMin(g, xa, xb, xc, fa, fb, fc, calls);
    double fm;
    const double t = lineMin(g, xa, xb, xc, 1e-6, fm);
    if (fm < fv) {
      for (size_t i = 0; i < n; i++)
        px[i] += t * d[i];
      px = clip(px, bounds);
      fv = fm;
    }
  };
  for (; it < maxit && !P.failed(); it++) {
    const Vec xStart = x;
    const double fStart = f;
    size_t bigIdx = 0;
    double bigDrop = 0.0;
    for (size_t i = 0; i < n; i++) {
      const double before = f;
      searchAlong(x, dirs.row(i), f);
      if (before - f > bigDrop) {
        bigDrop = before - f;
        bigIdx = i;
      }
    }
    double dx = 0.0;
    for (size_t i = 0; i < n; i++)
      dx = std::max(dx, std::fabs(x[i] - xStart[i]));
    if (2.0 * (fStart - f) <= ftol * (std::fabs(fStart) + std::fabs(f)) + 1e-20 && dx <= xtol + 1e-4) {
      r.success = true;
      r.message = "Optimization terminated successfully.";
      break;
    }
    Vec dn(n), xe(n);
    for (size_t i = 0; i < n; i++) {
      dn[i] = x[i] - xStart[i];
      xe[i] = 2.0 * x[i] - xStart[i];
    }
    const double fe = P.f(clip(xe, bounds));
    if (fe < fStart && 2.0 * (fStart - 2.0 * f + fe) * std::pow(fStart - f - bigDrop, 2) < bigDrop * std::pow(fStart - fe, 2)) {
      searchAlong(x, dn.data(), f);
      for (size_t j = 0; j < n; j++) {
        dirs(bigIdx, j) = dirs(n - 1, j);
        dirs(n - 1, j) = dn[j];
      }
    }
  }
  r.x = x;
  r.fun = f;
  r.nit = it;
  if (!r.success)
    r.message = "Maximum number of iterations has been exceeded.";
  return r;
}

// Projected limited-memory BFGS for simple bounds.
Result lbfgsb(const Problem &P, Vec x, const Mat &bounds, double gtol, long maxit, Mat *hessInv) {
  const size_t n = x.size(), mem = 10;
  x = clip(x, bounds);
  Result r;
  double f = P.f(x);
  Vec g = P.grad(x, f);
  std::vector<Vec> S, Y;
  long it = 0;
  auto projGrad = [&](const Vec &gr, const Vec &xc) {
    double m = 0.0;
    for (size_t i = 0; i < n; i++) {
      double v = xc[i] - gr[i];
      if (!bounds.a.empty())
        v = std::min(bounds(i, 1), std::max(bounds(i, 0), v));
      m = std::max(m, std::fabs(v - xc[i]));
    }
    return m;
  };
  for (; it < maxit && !P.failed(); it++) {
    if (projGrad(g, x) <= gtol) {
      r.success = true;
      r.message = "CONVERGENCE: NORM OF PROJECTED GRADIENT <= PGTOL";
      break;
    }
    // Two-loop recursion on the free variables.
    std::vector<char> active(n, 0);
    if (!bounds.a.empty())
      for (size_t i = 0; i < n; i++)
        active[i] = (x[i] <= bounds(i, 0) && g[i] > 0) || (x[i] >= bounds(i, 1) && g[i] < 0);
    Vec q = g;
    for (size_t i = 0; i < n; i++)
      if (active[i])
        q[i] = 0.0;
    Vec alpha(S.size());
    for (size_t k = S.size(); k-- > 0;) {
      alpha[k] = vdot(S[k], q) / vdot(Y[k], S[k]);
      for (size_t i = 0; i < n; i++)
        q[i] -= alpha[k] * Y[k][i];
    }
    if (!S.empty()) {
      const double gam = vdot(S.back(), Y.back()) / vdot(Y.back(), Y.back());
      for (double &v : q)
        v *= gam;
    }
    for (size_t k = 0; k < S.size(); k++) {
      const double be = vdot(Y[k], q) / vdot(Y[k], S[k]);
      for (size_t i = 0; i < n; i++)
        q[i] += (alpha[k] - be) * S[k][i];
    }
    Vec d(n);
    for (size_t i = 0; i < n; i++)
      d[i] = active[i] ? 0.0 : -q[i];
    if (vdot(d, g) >= 0.0)
      for (size_t i = 0; i < n; i++)
        d[i] = active[i] ? 0.0 : -g[i];
    // Backtracking on the projected path.
    double step = S.empty() ? std::min(1.0, 1.0 / std::max(vnorm(g), 1e-300)) : 1.0;
    Vec xn(n);
    double fn = f;
    bool ok = false;
    for (int t = 0; t < 40; t++) {
      for (size_t i = 0; i < n; i++)
        xn[i] = x[i] + step * d[i];
      xn = clip(xn, bounds);
      fn = P.f(xn);
      double dec = 0.0;
      for (size_t i = 0; i < n; i++)
        dec += g[i] * (xn[i] - x[i]);
      if (fn <= f + 1e-4 * dec) {
        ok = true;
        break;
      }
      step *= 0.5;
    }
    if (!ok) {
      r.success = projGrad(g, x) < 1e-3;
      r.message = "ABNORMAL_TERMINATION_IN_LNSRCH";
      break;
    }
    Vec gn = P.grad(xn, fn), s(n), y(n);
    for (size_t i = 0; i < n; i++) {
      s[i] = xn[i] - x[i];
      y[i] = gn[i] - g[i];
    }
    if (vdot(s, y) > 1e-10 * vdot(y, y)) {
      S.push_back(s);
      Y.push_back(y);
      if (S.size() > mem) {
        S.erase(S.begin());
        Y.erase(Y.begin());
      }
    }
    const double df = f - fn;
    x = xn;
    f = fn;
    g = gn;
    if (df <= 2.2e-9 * std::max({std::fabs(f), std::fabs(f + df), 1.0}) && it > 0 && vnorm(s) < 1e-10) {
      r.success = true;
      r.message = "CONVERGENCE: REL_REDUCTION_OF_F <= FACTR*EPSMCH";
      break;
    }
  }
  r.x = x;
  r.fun = f;
  r.grad = g;
  r.nit = it;
  if (hessInv) {
    // The inverse Hessian as a matrix: the BFGS update from the stored pairs.
    Mat H = Mat::eye(n);
    if (!S.empty()) {
      const double gam = vdot(S.back(), Y.back()) / vdot(Y.back(), Y.back());
      for (size_t i = 0; i < n; i++)
        H(i, i) = gam;
    }
    for (size_t k = 0; k < S.size(); k++) {
      const double ys = vdot(Y[k], S[k]);
      Vec Hy = mulVec(H, Y[k]);
      const double yHy = vdot(Y[k], Hy);
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
          H(i, j) += (1.0 + yHy / ys) * S[k][i] * S[k][j] / ys - (Hy[i] * S[k][j] + S[k][i] * Hy[j]) / ys;
    }
    *hessInv = H;
  }
  return r;
}

// Constraints in the form g(x) >= 0 (inequalities) or g(x) = 0 (equalities).
struct ConTerm {
  std::function<Vec(const Vec &)> g;
  bool equality;
};

bool parseConstraint(const Value &c, std::vector<ConTerm> &out, std::string &err) {
  const Value *k = dictGet(c, "kind");
  if (!k || !k->isText) {
    // A Dict of constraints: dict(["a","b"], ...) or d["a"] = c1.
    if (c.isDict) {
      for (const auto &kv : c.dict())
        if (!parseConstraint(kv.second, out, err))
          return false;
      if (!c.dict().empty())
        return true;
    }
    err = "a constraint must come from linear_constraint() or nonlinear_constraint()";
    return false;
  }
  Vec lo, hi;
  const Value *lv = dictGet(c, "low"), *hv = dictGet(c, "high");
  if (!lv || !hv || !readVec(*lv, lo) || !readVec(*hv, hi)) {
    err = "this constraint has no limits";
    return false;
  }
  std::function<Vec(const Vec &)> fn;
  if (k->text() == "linear") {
    Mat A;
    if (!readMat(*dictGet(c, "A"), A)) {
      err = "this constraint has no matrix";
      return false;
    }
    fn = [A](const Vec &x) { return mulVec(A, x); };
  } else {
    auto f = std::make_shared<NcFn>(*dictGet(c, "fn"));
    fn = [f](const Vec &x) { return f->vecOfVec(x); };
  }
  Vec probe; // sizes are checked when the term is evaluated
  auto expand = [](const Vec &v, size_t n) { return v.size() == n ? v : Vec(n, v.empty() ? 0.0 : v[0]); };
  // Each row gives up to two inequality terms, or one equality.
  out.push_back({[=](const Vec &x) {
                   Vec v = fn(x), L = expand(lo, v.size()), H = expand(hi, v.size()), o;
                   for (size_t i = 0; i < v.size(); i++)
                     if (L[i] == H[i])
                       o.push_back(v[i] - L[i]);
                   return o;
                 },
                 true});
  out.push_back({[=](const Vec &x) {
                   Vec v = fn(x), L = expand(lo, v.size()), H = expand(hi, v.size()), o;
                   for (size_t i = 0; i < v.size(); i++) {
                     if (L[i] == H[i])
                       continue;
                     if (!std::isinf(L[i]))
                       o.push_back(v[i] - L[i]);
                     if (!std::isinf(H[i]))
                       o.push_back(H[i] - v[i]);
                   }
                   return o;
                 },
                 false});
  return true;
}

Vec evalTerms(const std::vector<ConTerm> &cons, const Vec &x, bool equality) {
  Vec o;
  for (const ConTerm &c : cons)
    if (c.equality == equality) {
      Vec v = c.g(x);
      o.insert(o.end(), v.begin(), v.end());
    }
  return o;
}

// Bounds count as inequality terms for the penalty methods.
void addBoundTerms(const Mat &bounds, std::vector<ConTerm> &cons) {
  if (bounds.a.empty())
    return;
  cons.push_back({[bounds](const Vec &x) {
                    Vec o;
                    for (size_t i = 0; i < x.size() && i < bounds.r; i++) {
                      if (!std::isinf(bounds(i, 0)))
                        o.push_back(x[i] - bounds(i, 0));
                      if (!std::isinf(bounds(i, 1)))
                        o.push_back(bounds(i, 1) - x[i]);
                    }
                    return o;
                  },
                  false});
}

// Sequential quadratic programming with an active-set QP (the "SLSQP" and
// "trust-constr" paths; COBYLA uses an augmented Lagrangian instead).
Result sqp(const Problem &P, Vec x, const std::vector<ConTerm> &cons, long maxit, double tol) {
  const size_t n = x.size();
  Result r;
  double f = P.f(x);
  Vec g = P.grad(x, f);
  Mat B = Mat::eye(n);
  auto jacOf = [&](const Vec &xc, bool eq, Vec &val) {
    val = evalTerms(cons, xc, eq);
    Mat J(val.size(), n);
    Vec p = xc;
    for (size_t j = 0; j < n; j++) {
      const double h = 1e-7 * std::max(1.0, std::fabs(xc[j]));
      p[j] = xc[j] + h;
      Vec v2 = evalTerms(cons, p, eq);
      for (size_t i = 0; i < val.size(); i++)
        J(i, j) = (v2[i] - val[i]) / h;
      p[j] = xc[j];
    }
    return J;
  };
  double mu = 10.0;
  long it = 0;
  for (; it < maxit && !P.failed(); it++) {
    Vec ce, ci;
    Mat Je = jacOf(x, true, ce), Ji = jacOf(x, false, ci);
    // Active-set solve of: min 1/2 d'Bd + g'd, Je d + ce = 0, Ji d + ci >= 0.
    std::vector<size_t> act;
    for (size_t i = 0; i < ci.size(); i++)
      if (ci[i] <= 1e-9)
        act.push_back(i);
    Vec d(n, 0.0), lam;
    for (int qp = 0; qp < 60; qp++) {
      const size_t m = ce.size() + act.size();
      Mat K(n + m, n + m);
      Vec rhs(n + m, 0.0);
      for (size_t i = 0; i < n; i++) {
        rhs[i] = -g[i];
        for (size_t j = 0; j < n; j++)
          K(i, j) = B(i, j);
      }
      for (size_t q = 0; q < m; q++) {
        const bool isE = q < ce.size();
        for (size_t j = 0; j < n; j++) {
          const double v = isE ? Je(q, j) : Ji(act[q - ce.size()], j);
          K(n + q, j) = v;
          K(j, n + q) = -v;
        }
        rhs[n + q] = isE ? -ce[q] : -ci[act[q - ce.size()]];
      }
      Vec sol = la::lstsqMin(K, rhs);
      Vec dn(sol.begin(), sol.begin() + n);
      lam.assign(sol.begin() + n, sol.end());
      // Most violated inactive constraint, or the most negative multiplier.
      double worst = -1e-10;
      long add = -1;
      for (size_t i = 0; i < ci.size(); i++) {
        if (std::find(act.begin(), act.end(), i) != act.end())
          continue;
        double v = ci[i];
        for (size_t j = 0; j < n; j++)
          v += Ji(i, j) * dn[j];
        if (v < worst) {
          worst = v;
          add = (long)i;
        }
      }
      d = dn;
      if (add >= 0) {
        act.push_back((size_t)add);
        continue;
      }
      double lmin = -1e-10;
      long drop = -1;
      for (size_t q = 0; q < act.size(); q++)
        if (lam[ce.size() + q] < lmin) {
          lmin = lam[ce.size() + q];
          drop = (long)q;
        }
      if (drop < 0)
        break;
      act.erase(act.begin() + drop);
    }
    double viol = 0.0;
    for (double v : ce)
      viol += std::fabs(v);
    for (double v : ci)
      viol += std::max(0.0, -v);
    double lmax = 0.0;
    for (double v : lam)
      lmax = std::max(lmax, std::fabs(v));
    mu = std::max(mu, 2.0 * lmax + 1.0);
    if (vnorm(d) <= tol && viol <= tol * 10.0) {
      r.success = true;
      r.message = "Optimization terminated successfully";
      break;
    }
    // Merit-function line search.
    auto merit = [&](const Vec &xc, double fc) {
      double m = fc;
      for (double v : evalTerms(cons, xc, true))
        m += mu * std::fabs(v);
      for (double v : evalTerms(cons, xc, false))
        m += mu * std::max(0.0, -v);
      return m;
    };
    const double m0 = merit(x, f);
    double step = 1.0, fn = f;
    Vec xn(n);
    bool ok = false;
    for (int t = 0; t < 30; t++) {
      for (size_t i = 0; i < n; i++)
        xn[i] = x[i] + step * d[i];
      fn = P.f(xn);
      if (merit(xn, fn) <= m0 - 1e-6 * step * vdot(d, d) || merit(xn, fn) < m0) {
        ok = true;
        break;
      }
      step *= 0.5;
    }
    if (!ok) {
      r.success = viol <= 1e-6;
      r.message = "Positive directional derivative for linesearch";
      break;
    }
    Vec gn = P.grad(xn, fn), s(n), y(n);
    // Gradient of the Lagrangian, for the Hessian update.
    Vec lamE(lam.begin(), lam.begin() + ce.size());
    Vec ceN, ciN;
    Mat JeN = jacOf(xn, true, ceN), JiN = jacOf(xn, false, ciN);
    for (size_t i = 0; i < n; i++) {
      s[i] = xn[i] - x[i];
      y[i] = gn[i] - g[i];
      for (size_t q = 0; q < ce.size(); q++)
        y[i] -= lam[q] * (JeN(q, i) - Je(q, i));
      for (size_t q = 0; q < act.size(); q++)
        y[i] -= lam[ce.size() + q] * (JiN(act[q], i) - Ji(act[q], i));
    }
    // Damped BFGS (Powell).
    Vec Bs = mulVec(B, s);
    const double sBs = vdot(s, Bs), sy = vdot(s, y);
    const double th = sy >= 0.2 * sBs ? 1.0 : 0.8 * sBs / (sBs - sy);
    Vec w(n);
    for (size_t i = 0; i < n; i++)
      w[i] = th * y[i] + (1.0 - th) * Bs[i];
    const double sw = vdot(s, w);
    if (sw > 1e-14 && sBs > 1e-14)
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
          B(i, j) += w[i] * w[j] / sw - Bs[i] * Bs[j] / sBs;
    x = xn;
    f = fn;
    g = gn;
  }
  r.x = x;
  r.fun = f;
  r.grad = g;
  r.nit = it;
  if (r.message.empty())
    r.message = "Iteration limit reached";
  return r;
}

// Derivative-free constrained: augmented Lagrangian around Nelder-Mead (for COBYLA).
Result constrainedDFO(const Problem &P, Vec x, const std::vector<ConTerm> &cons, long maxit, double tol) {
  Vec lamE(evalTerms(cons, x, true).size(), 0.0), lamI(evalTerms(cons, x, false).size(), 0.0);
  double rho = 10.0;
  Result inner;
  for (int outer = 0; outer < 25; outer++) {
    Problem AL = P;
    AL.fn = [&](const Vec &v) {
      double s = P.f(v);
      Vec ce = evalTerms(cons, v, true), ci = evalTerms(cons, v, false);
      for (size_t i = 0; i < ce.size(); i++)
        s += lamE[i] * ce[i] + 0.5 * rho * ce[i] * ce[i];
      for (size_t i = 0; i < ci.size(); i++) {
        const double t = std::max(0.0, lamI[i] - rho * ci[i]);
        s += (t * t - lamI[i] * lamI[i]) / (2.0 * rho);
      }
      return s;
    };
    inner = nelderMead(AL, x, Mat(), tol, tol, maxit);
    x = inner.x;
    Vec ce = evalTerms(cons, x, true), ci = evalTerms(cons, x, false);
    double viol = 0.0;
    for (size_t i = 0; i < ce.size(); i++) {
      lamE[i] += rho * ce[i];
      viol = std::max(viol, std::fabs(ce[i]));
    }
    for (size_t i = 0; i < ci.size(); i++) {
      lamI[i] = std::max(0.0, lamI[i] - rho * ci[i]);
      viol = std::max(viol, -ci[i]);
    }
    if (viol <= tol)
      break;
    rho *= 4.0;
  }
  Result r;
  r.x = x;
  r.fun = P.f(x);
  r.nit = inner.nit;
  r.success = !P.failed();
  r.message = "Optimization terminated successfully.";
  return r;
}

Problem makeProblem(const Value &fn, const Value *jac) {
  Problem p;
  p.nc = std::make_shared<NcFn>(fn);
  auto f = p.nc;
  p.fn = [f](const Vec &x) { return f->ofVec(x); };
  if (jac && isCallable(*jac)) {
    p.ncJac = std::make_shared<NcFn>(*jac);
    auto j = p.ncJac;
    p.gradFn = [j](const Vec &x, double) { return j->vecOfVec(x); };
  }
  return p;
}

bool getFn(const Args &a, size_t i, CallContext &ctx) {
  if (i >= a.size() || !isCallable(a[i])) {
    ctx.fail("the " + ordinal(i) + " argument must name an NC function, e.g. \"f\" or @f");
    return false;
  }
  return true;
}

bool getBounds(const Args &a, size_t i, CallContext &ctx, Mat &b, size_t n) {
  if (isOmitted(a, i)) {
    b = Mat();
    return true;
  }
  if (!getMat(a, i, ctx, b))
    return false;
  if (b.c != 2) {
    ctx.fail("bounds needs one [low, high] row per variable");
    return false;
  }
  if (n && b.r == 1 && n > 1) {
    Mat e(n, 2);
    for (size_t k = 0; k < n; k++) {
      e(k, 0) = b(0, 0);
      e(k, 1) = b(0, 1);
    }
    b = e;
  }
  if (n && b.r != n) {
    ctx.fail("bounds needs one row per variable");
    return false;
  }
  return true;
}

} // namespace opt

using namespace opt;

namespace {

// Global searches run a local polish at the end.
Result polish(const Problem &P, const Vec &x, const Mat &bounds) {
  Mat H;
  return lbfgsb(P, x, bounds, 1e-7, 500, &H);
}

Value minimizeScalar(const Args &a, CallContext &ctx) {
  if (!getFn(a, 0, ctx))
    return Value(0.0);
  std::string method = optText(a, 2, "");
  Vec br;
  const bool hasBounds = a.size() > 1 && !isOmitted(a, 1);
  if (hasBounds && !getVec(a, 1, ctx, br))
    return Value(0.0);
  if (method.empty())
    method = hasBounds && br.size() == 2 ? "bounded" : "brent";
  NcFn f(a[0]);
  std::function<double(double)> g = [&](double t) { return f.scalar(t); };
  double x = 0.0, fx = 0.0;
  long nit = 0;
  if (method == "bounded") {
    if (br.size() != 2) {
      ctx.fail("method \"bounded\" needs bounds [low, high]");
      return Value(0.0);
    }
    x = lineMin(g, br[0], 0.5 * (br[0] + br[1] - (br[1] - br[0]) * (std::sqrt(5.0) - 2.0)), br[1], 1e-8, fx);
  } else if (method == "brent" || method == "golden") {
    double xa = 0.0, xb = 1.0, xc, fa, fb, fc;
    long calls;
    if (br.size() >= 2) {
      xa = br[0];
      xb = br[1];
    }
    bracketMin(g, xa, xb, xc, fa, fb, fc, calls);
    if (method == "brent") {
      x = lineMin(g, xa, xb, xc, 1.48e-8, fx);
    } else {
      const double r = 0.6180339887498949;
      double lo = std::min(xa, xc), hi = std::max(xa, xc);
      double c = hi - r * (hi - lo), d = lo + r * (hi - lo), fcc = g(c), fd = g(d);
      for (; nit < 200 && std::fabs(hi - lo) > 1.48e-8 * (std::fabs(c) + std::fabs(d)); nit++) {
        if (fcc < fd) {
          hi = d;
          d = c;
          fd = fcc;
          c = hi - r * (hi - lo);
          fcc = g(c);
        } else {
          lo = c;
          c = d;
          fcc = fd;
          d = lo + r * (hi - lo);
          fd = g(d);
        }
      }
      x = fcc < fd ? c : d;
      fx = std::min(fcc, fd);
    }
  } else {
    ctx.fail("method must be \"brent\", \"bounded\" or \"golden\"");
    return Value(0.0);
  }
  if (f.failed) {
    ctx.fail(f.failText());
    return Value(0.0);
  }
  return makeDict({{"x", Value(x)}, {"fun", Value(fx)}, {"success", Value::boolean(true)}, {"nfev", Value((double)f.calls)}, {"message", Value(std::string("Optimization terminated successfully."))}});
}

} // namespace

void registerOptimizationRootFinding(Registry &reg) {
  SP_ADD("minimize", 2, 9, "fn, x0, method, bounds, constraints, jac, hess, tol, maxiter") {
    Vec x0;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, x0))
      return Value(0.0);
    const size_t n = x0.size();
    Mat bounds;
    if (!getBounds(a, 3, ctx, bounds, n))
      return Value(0.0);
    std::vector<ConTerm> cons;
    std::string err;
    const bool hasCons = !isOmitted(a, 4);
    if (hasCons && !parseConstraint(a[4], cons, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    std::string method = optText(a, 2, "");
    if (method.empty())
      method = hasCons ? "SLSQP" : (!bounds.a.empty() ? "L-BFGS-B" : "BFGS");
    const Value *jac = a.size() > 5 && isCallable(a[5]) ? &a[5] : nullptr;
    const std::string hess = optText(a, 6, "");
    const double tol = isNumberArg(a, 7) && a[7].number > 0 ? a[7].number : 0.0;
    const long maxit = isNumberArg(a, 8) && a[8].number > 0 ? (long)a[8].number : 0;
    Problem P = makeProblem(a[0], jac);
    Result r;
    if (method == "BFGS") {
      r = bfgs(P, x0, tol > 0 ? tol : 1e-5, maxit ? maxit : 200 * (long)n, nullptr);
    } else if (method == "CG") {
      r = conjugateGradient(P, x0, tol > 0 ? tol : 1e-5, maxit ? maxit : 200 * (long)n);
    } else if (method == "Newton-CG") {
      if (!jac) {
        ctx.fail("method \"Newton-CG\" needs a gradient function (jac)");
        return Value(0.0);
      }
      r = newtonCG(P, x0, tol > 0 ? tol : 1e-5, maxit ? maxit : 200 * (long)n);
    } else if (method == "Nelder-Mead" || method == "nelder-mead") {
      r = nelderMead(P, x0, bounds, tol > 0 ? tol : 1e-4, tol > 0 ? tol : 1e-4, maxit ? maxit : 200 * (long)n);
    } else if (method == "Powell") {
      r = powell(P, x0, bounds, tol > 0 ? tol : 1e-4, tol > 0 ? tol : 1e-4, maxit ? maxit : 1000 * (long)n);
    } else if (method == "L-BFGS-B" || method == "TNC") {
      Mat H;
      r = lbfgsb(P, x0, bounds, tol > 0 ? tol : 1e-5, maxit ? maxit : 15000, &H);
      if (method == "L-BFGS-B")
        r.hessInv = H;
    } else if (method == "SLSQP" || method == "trust-constr") {
      addBoundTerms(bounds, cons);
      if (method == "trust-constr" && !hasCons && bounds.a.empty()) {
        r = bfgs(P, x0, tol > 0 ? tol : 1e-8, maxit ? maxit : 1000, hess.c_str());
      } else {
        r = sqp(P, x0, cons, maxit ? maxit : (method == "SLSQP" ? 100 : 1000), tol > 0 ? tol : 1e-7);
      }
    } else if (method == "COBYLA") {
      addBoundTerms(bounds, cons);
      r = constrainedDFO(P, x0, cons, maxit ? maxit : 1000, tol > 0 ? tol : 1e-5);
    } else {
      ctx.fail("unknown method \"" + method + "\"");
      return Value(0.0);
    }
    if (P.failed()) {
      ctx.fail(P.failText());
      return Value(0.0);
    }
    r.nfev = P.nc->calls;
    return resultDict(r);
  } SP_END
  SP_ADD("minimize_scalar", 1, 3, "fn, bounds, method") { return minimizeScalar(a, ctx); } SP_END
  SP_ADD("show_options", 0, 2, "solver, method") {
    (void)ctx;
    const std::string solver = optText(a, 0, "minimize"), m = optText(a, 1, "");
    static const std::map<std::string, std::string> opts = {
        {"minimize", "methods: BFGS, CG, Newton-CG, Nelder-Mead, Powell, L-BFGS-B, TNC, SLSQP, COBYLA, trust-constr. Inputs: fn, x0, method, bounds, constraints, jac, hess, tol, maxiter."},
        {"nelder-mead", "tol sets xatol and fatol (default 1e-4); maxiter defaults to 200 * n."},
        {"powell", "tol sets xtol and ftol (default 1e-4); bounds are honoured; maxiter defaults to 1000 * n."},
        {"bfgs", "tol is gtol (default 1e-5); maxiter defaults to 200 * n."},
        {"cg", "tol is gtol (default 1e-5); maxiter defaults to 200 * n."},
        {"newton-cg", "needs jac; tol is xtol (default 1e-5); maxiter defaults to 200 * n."},
        {"l-bfgs-b", "tol is pgtol (default 1e-5); bounds are honoured; hess_inv is returned as a matrix."},
        {"tnc", "same engine and options as L-BFGS-B here."},
        {"slsqp", "constraints and bounds are honoured; tol default 1e-7; maxiter 100."},
        {"cobyla", "derivative-free; constraints and bounds are honoured; tol default 1e-5."},
        {"trust-constr", "constraints and bounds are honoured; hess may be \"BFGS\" or \"SR1\"; tol default 1e-7."},
        {"root", "methods: hybr, lm, broyden1, broyden2, anderson, linearmixing, diagbroyden, excitingmixing, krylov."},
        {"root_scalar", "methods: brentq, brenth, ridder, bisect, toms748, newton, secant, halley."},
        {"linprog", "dense simplex with bounds; inputs: c, A_ub, b_ub, A_eq, b_eq, bounds."},
        {"minimize_scalar", "methods: brent, bounded, golden."}};
    std::string key = m.empty() ? solver : m;
    for (char &c : key)
      c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    auto it = opts.find(key);
    const std::string text = it == opts.end() ? "no options are listed for \"" + key + "\"" : it->second;
    std::cout << text << "\n";
    return Value(text);
  } SP_END
  SP_ADD("nonlinear_constraint", 3, 3, "fn, low, high") {
    if (!isCallable(a[0])) {
      ctx.fail("the first argument must name an NC function g(x)");
      return Value(0.0);
    }
    return makeDict({{"kind", Value(std::string("nonlinear"))}, {"fn", a[0]}, {"low", a[1]}, {"high", a[2]}});
  } SP_END
  SP_ADD("linear_constraint", 3, 3, "A, low, high") {
    Mat A;
    if (!getMat(a, 0, ctx, A))
      return Value(0.0);
    return makeDict({{"kind", Value(std::string("linear"))}, {"A", toValue(A)}, {"low", a[1]}, {"high", a[2]}});
  } SP_END
  SP_ADD("bounds", 2, 2, "low, high") {
    Vec lo, hi;
    if (!getVec(a, 0, ctx, lo) || !getVec(a, 1, ctx, hi))
      return Value(0.0);
    if (lo.size() != hi.size()) {
      ctx.fail("low and high must have the same length");
      return Value(0.0);
    }
    Mat b(lo.size(), 2);
    for (size_t i = 0; i < lo.size(); i++) {
      b(i, 0) = lo[i];
      b(i, 1) = hi[i];
    }
    return toValue(b);
  } SP_END
  SP_ADD("bracket_min", 1, 3, "fn, xa=0, xb=1") {
    if (!getFn(a, 0, ctx))
      return Value(0.0);
    NcFn f(a[0]);
    double xa = optNum(a, 1, 0.0), xb = optNum(a, 2, 1.0), xc, fa, fb, fc;
    long calls;
    bracketMin([&](double t) { return f.scalar(t); }, xa, xb, xc, fa, fb, fc, calls);
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"xa", Value(xa)}, {"xb", Value(xb)}, {"xc", Value(xc)}, {"fa", Value(fa)}, {"fb", Value(fb)}, {"fc", Value(fc)}, {"calls", Value((double)calls)}});
  } SP_END
  SP_ADD("line_search", 4, 4, "fn, grad, x, p") {
    Vec x, p;
    if (!getFn(a, 0, ctx) || !getFn(a, 1, ctx) || !getVec(a, 2, ctx, x) || !getVec(a, 3, ctx, p))
      return Value(0.0);
    if (x.size() != p.size()) {
      ctx.fail("x and p must have the same length");
      return Value(0.0);
    }
    Problem P = makeProblem(a[0], &a[1]);
    const double f0 = P.f(x);
    Vec g0 = P.grad(x, f0), gn;
    double fn = f0;
    const double al = wolfeSearch(P, x, p, f0, g0, fn, gn);
    if (P.failed()) {
      ctx.fail(P.failText());
      return Value(0.0);
    }
    return makeDict({{"alpha", Value(al)}, {"fc", Value((double)P.nc->calls)}, {"gc", Value((double)P.ncJac->calls)}, {"new_fval", Value(fn)}});
  } SP_END
  SP_ADD("basin_hopping", 2, 4, "fn, x0, niter=100, seed") {
    Vec x0;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, x0))
      return Value(0.0);
    const long niter = optInt(a, 2, 100);
    std::mt19937_64 gen = isNumberArg(a, 3) ? std::mt19937_64((unsigned long long)a[3].number) : std::mt19937_64(ncRandomEngine()());
    std::uniform_real_distribution<double> u(-0.5, 0.5), acc(0.0, 1.0);
    Problem P = makeProblem(a[0], nullptr);
    Result cur = bfgs(P, x0, 1e-5, 200 * (long)x0.size(), nullptr), best = cur;
    for (long k = 0; k < niter && !P.failed(); k++) {
      Vec t = cur.x;
      for (double &v : t)
        v += u(gen);
      Result nx = bfgs(P, t, 1e-5, 200 * (long)x0.size(), nullptr);
      if (nx.fun < cur.fun || acc(gen) < std::exp(-(nx.fun - cur.fun)))
        cur = nx;
      if (nx.fun < best.fun)
        best = nx;
    }
    if (P.failed()) {
      ctx.fail(P.failText());
      return Value(0.0);
    }
    best.nfev = P.nc->calls;
    best.nit = niter;
    best.success = true;
    best.message = "basin hopping finished";
    best.hessInv = Mat();
    return resultDict(best);
  } SP_END
  SP_ADD("brute_force_min", 2, 3, "fn, ranges, Ns=20") {
    Mat rng;
    if (!getFn(a, 0, ctx) || !getMat(a, 1, ctx, rng))
      return Value(0.0);
    if (rng.c != 2) {
      ctx.fail("ranges needs one [low, high] row per variable");
      return Value(0.0);
    }
    const long ns = optInt(a, 2, 20);
    const size_t d = rng.r;
    Problem P = makeProblem(a[0], nullptr);
    std::vector<long> idx(d, 0);
    Vec x(d), bestX(d);
    double best = kInf;
    while (true) {
      for (size_t i = 0; i < d; i++)
        x[i] = rng(i, 0) + (rng(i, 1) - rng(i, 0)) * idx[i] / (double)(ns - 1);
      const double f = P.f(x);
      if (P.failed()) {
        ctx.fail(P.failText());
        return Value(0.0);
      }
      if (f < best) {
        best = f;
        bestX = x;
      }
      size_t k = 0;
      while (k < d && ++idx[k] == ns)
        idx[k++] = 0;
      if (k == d)
        break;
    }
    // Polished by a simplex search, as scipy's default finish does.
    Result r = nelderMead(P, bestX, rng, 1e-8, 1e-8, 400 * (long)d);
    return toValue(r.fun <= best ? r.x : bestX);
  } SP_END
  SP_ADD("differential_evolution", 2, 5, "fn, bounds, seed, maxiter=1000, popsize=15") {
    Mat bd;
    if (!getFn(a, 0, ctx) || !getBounds(a, 1, ctx, bd, 0))
      return Value(0.0);
    const size_t d = bd.r, np = (size_t)optInt(a, 4, 15) * d;
    std::mt19937_64 gen = isNumberArg(a, 2) ? std::mt19937_64((unsigned long long)a[2].number) : std::mt19937_64(ncRandomEngine()());
    std::uniform_real_distribution<double> u;
    Problem P = makeProblem(a[0], nullptr);
    std::vector<Vec> pop(np, Vec(d));
    Vec fit(np);
    for (size_t i = 0; i < np; i++) {
      for (size_t j = 0; j < d; j++)
        pop[i][j] = bd(j, 0) + u(gen) * (bd(j, 1) - bd(j, 0));
      fit[i] = P.f(pop[i]);
    }
    size_t best = std::min_element(fit.begin(), fit.end()) - fit.begin();
    long it = 0;
    const long maxit = optInt(a, 3, 1000);
    for (; it < maxit && !P.failed(); it++) {
      for (size_t i = 0; i < np; i++) {
        size_t r1, r2;
        do r1 = gen() % np; while (r1 == i);
        do r2 = gen() % np; while (r2 == i || r2 == r1);
        const double F = 0.5 + 0.5 * u(gen);
        Vec t = pop[i];
        size_t jr = gen() % d;
        for (size_t j = 0; j < d; j++)
          if (j == jr || u(gen) < 0.7) {
            t[j] = pop[best][j] + F * (pop[r1][j] - pop[r2][j]);
            t[j] = std::min(bd(j, 1), std::max(bd(j, 0), t[j]));
          }
        const double ft = P.f(t);
        if (ft <= fit[i]) {
          pop[i] = t;
          fit[i] = ft;
          if (ft < fit[best])
            best = i;
        }
      }
      double m = 0.0, s = 0.0;
      for (double v : fit)
        m += v / (double)np;
      for (double v : fit)
        s += (v - m) * (v - m) / (double)np;
      if (std::sqrt(s) <= 0.01 * std::fabs(m) + 1e-10 * 0.0 + 1e-300 && std::sqrt(s) <= 1e-2 * std::max(std::fabs(m), 1e-8))
        break;
    }
    Result r = polish(P, pop[best], bd);
    if (fit[best] < r.fun) {
      r.x = pop[best];
      r.fun = fit[best];
    }
    if (P.failed()) {
      ctx.fail(P.failText());
      return Value(0.0);
    }
    r.nit = it;
    r.nfev = P.nc->calls;
    r.success = true;
    r.message = "Optimization terminated successfully.";
    r.hessInv = Mat();
    return resultDict(r);
  } SP_END
  SP_ADD("shgo", 2, 3, "fn, bounds, n=64") {
    // Sampling on a low-discrepancy set, local minima kept as those lower than
    // their neighbours in the point graph, each polished.
    Mat bd;
    if (!getFn(a, 0, ctx) || !getBounds(a, 1, ctx, bd, 0))
      return Value(0.0);
    const size_t d = bd.r;
    const long n = optInt(a, 2, 64);
    static const int primes[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
    if (d > 10) {
      ctx.fail("at most 10 variables");
      return Value(0.0);
    }
    Problem P = makeProblem(a[0], nullptr);
    std::vector<Vec> pts((size_t)n, Vec(d));
    Vec fv((size_t)n);
    for (long i = 0; i < n; i++) {
      for (size_t j = 0; j < d; j++) {
        double f = 1.0, r = 0.0;
        unsigned long v = (unsigned long)i + 1;
        while (v > 0) {
          f /= primes[j];
          r += f * (double)(v % primes[j]);
          v /= primes[j];
        }
        pts[(size_t)i][j] = bd(j, 0) + r * (bd(j, 1) - bd(j, 0));
      }
      fv[(size_t)i] = P.f(pts[(size_t)i]);
    }
    std::vector<Result> found;
    const size_t nb = std::min<size_t>(2 * d + 2, (size_t)n - 1);
    for (size_t i = 0; i < (size_t)n && !P.failed(); i++) {
      std::vector<std::pair<double, size_t>> ds;
      for (size_t k = 0; k < (size_t)n; k++)
        if (k != i) {
          double s = 0.0;
          for (size_t j = 0; j < d; j++)
            s += (pts[i][j] - pts[k][j]) * (pts[i][j] - pts[k][j]);
          ds.push_back({s, k});
        }
      std::partial_sort(ds.begin(), ds.begin() + nb, ds.end());
      bool low = true;
      for (size_t q = 0; q < nb && low; q++)
        low = fv[i] <= fv[ds[q].second];
      if (!low)
        continue;
      Result r = polish(P, pts[i], bd);
      bool dup = false;
      for (const Result &e : found) {
        double s = 0.0;
        for (size_t j = 0; j < d; j++)
          s = std::max(s, std::fabs(e.x[j] - r.x[j]));
        dup = dup || s < 1e-4;
      }
      if (!dup)
        found.push_back(r);
    }
    if (P.failed() || found.empty()) {
      ctx.fail(P.failed() ? P.failText() : "no local minimum was found");
      return Value(0.0);
    }
    std::sort(found.begin(), found.end(), [](const Result &x, const Result &y) { return x.fun < y.fun; });
    Mat xl(found.size(), d);
    Vec fl;
    for (size_t i = 0; i < found.size(); i++) {
      std::copy(found[i].x.begin(), found[i].x.end(), xl.row(i));
      fl.push_back(found[i].fun);
    }
    Result best = found[0];
    best.nfev = P.nc->calls;
    best.success = true;
    best.message = "Optimization terminated successfully.";
    best.hessInv = Mat();
    Value v = resultDict(best);
    v.dictMut().emplace("xl", toValue(xl));
    v.dictMut().emplace("funl", toValue(fl));
    return v;
  } SP_END
  SP_ADD("dual_annealing", 2, 4, "fn, bounds, seed, maxiter=1000") {
    // Generalised simulated annealing: Tsallis-style visits with temperature decay.
    Mat bd;
    if (!getFn(a, 0, ctx) || !getBounds(a, 1, ctx, bd, 0))
      return Value(0.0);
    const size_t d = bd.r;
    const long maxit = optInt(a, 3, 1000);
    std::mt19937_64 gen = isNumberArg(a, 2) ? std::mt19937_64((unsigned long long)a[2].number) : std::mt19937_64(ncRandomEngine()());
    std::uniform_real_distribution<double> u;
    std::cauchy_distribution<double> cau;
    Problem P = makeProblem(a[0], nullptr);
    Vec x(d);
    for (size_t j = 0; j < d; j++)
      x[j] = bd(j, 0) + u(gen) * (bd(j, 1) - bd(j, 0));
    double f = P.f(x);
    Vec best = x;
    double fbest = f;
    const double T0 = 5230.0, qv = 2.62;
    const double t1 = std::exp((qv - 1.0) * std::log(2.0)) - 1.0;
    for (long it = 1; it <= maxit && !P.failed(); it++) {
      const double T = T0 * t1 / (std::exp((qv - 1.0) * std::log(it + 1.0)) - 1.0);
      for (size_t j = 0; j < d; j++) {
        Vec c = x;
        const double range = bd(j, 1) - bd(j, 0);
        double step = cau(gen) * std::pow(T / T0, 0.5) * range * 0.1;
        double v = c[j] + step;
        v = bd(j, 0) + std::fmod(std::fmod(v - bd(j, 0), range) + range, range);
        c[j] = v;
        const double fc = P.f(c);
        if (fc <= f || u(gen) < std::exp(-(fc - f) / std::max(T, 1e-300))) {
          x = c;
          f = fc;
          if (f < fbest) {
            fbest = f;
            best = x;
          }
        }
      }
      if (it % 50 == 0) {
        Result r = polish(P, best, bd);
        if (r.fun < fbest) {
          fbest = r.fun;
          best = r.x;
          x = best;
          f = fbest;
        }
      }
    }
    Result r = polish(P, best, bd);
    if (r.fun > fbest) {
      r.x = best;
      r.fun = fbest;
    }
    if (P.failed()) {
      ctx.fail(P.failText());
      return Value(0.0);
    }
    r.nit = maxit;
    r.nfev = P.nc->calls;
    r.success = true;
    r.message = "Maximum number of iteration reached";
    r.hessInv = Mat();
    return resultDict(r);
  } SP_END
  SP_ADD("direct_search", 2, 4, "fn, bounds, maxfun=2000, tol=1e-4") {
    // DIRECT: trisect the potentially optimal hyper-rectangles.
    Mat bd;
    if (!getFn(a, 0, ctx) || !getBounds(a, 1, ctx, bd, 0))
      return Value(0.0);
    const size_t d = bd.r;
    const long maxf = optInt(a, 2, 2000);
    Problem P = makeProblem(a[0], nullptr);
    struct Box {
      Vec c, side;
      double f, size;
    };
    auto scaled = [&](const Vec &u) {
      Vec x(d);
      for (size_t j = 0; j < d; j++)
        x[j] = bd(j, 0) + u[j] * (bd(j, 1) - bd(j, 0));
      return x;
    };
    auto sizeOf = [](const Vec &s) {
      double t = 0.0;
      for (double v : s)
        t += v * v;
      return std::sqrt(t) / 2.0;
    };
    std::vector<Box> boxes;
    Vec c0(d, 0.5), s0(d, 1.0);
    boxes.push_back({c0, s0, P.f(scaled(c0)), sizeOf(s0)});
    long nf = 1;
    size_t bestI = 0;
    const double eps = 1e-4;
    for (long it = 0; it < 1000 && nf < maxf && !P.failed(); it++) {
      // The lower convex hull of (size, f) picks the potentially optimal boxes.
      std::map<double, size_t> low;
      for (size_t i = 0; i < boxes.size(); i++) {
        auto q = low.find(boxes[i].size);
        if (q == low.end() || boxes[i].f < boxes[q->second].f)
          low[boxes[i].size] = i;
      }
      std::vector<std::pair<double, size_t>> h;
      for (auto &e : low) {
        while (h.size() >= 2) {
          const auto &p1 = h[h.size() - 2], &p2 = h.back();
          const double cr = (boxes[p2.second].f - boxes[p1.second].f) * (e.first - p1.first) -
                            (boxes[e.second].f - boxes[p1.second].f) * (p2.first - p1.first);
          if (cr >= 0.0)
            h.pop_back();
          else
            break;
        }
        h.push_back(e);
      }
      for (size_t q = 0; q < h.size() && nf < maxf; q++) {
        const size_t i = h[q].second;
        // Keep only boxes that could improve by a useful amount.
        if (q + 1 < h.size()) {
          const double slope = (boxes[h[q + 1].second].f - boxes[i].f) / (h[q + 1].first - h[q].first);
          if (boxes[i].f + slope * (0 - h[q].first) * -1.0 * 0.0 + (boxes[i].f - slope * h[q].first) > 2.0 * boxes[bestI].f - eps * std::fabs(boxes[bestI].f) + 1e300)
            continue;
        }
        const Box b = boxes[i];
        double longest = 0.0;
        for (double s : b.side)
          longest = std::max(longest, s);
        std::vector<size_t> dims;
        for (size_t j = 0; j < d; j++)
          if (b.side[j] >= longest * (1.0 - 1e-12))
            dims.push_back(j);
        const double delta = longest / 3.0;
        struct Probe {
          size_t j;
          double fp, fm;
        };
        std::vector<Probe> pr;
        for (size_t j : dims) {
          Vec cp = b.c, cm = b.c;
          cp[j] += delta;
          cm[j] -= delta;
          pr.push_back({j, P.f(scaled(cp)), P.f(scaled(cm))});
          nf += 2;
        }
        std::sort(pr.begin(), pr.end(), [](const Probe &x, const Probe &y) { return std::min(x.fp, x.fm) < std::min(y.fp, y.fm); });
        Vec side = b.side;
        for (const Probe &p : pr) {
          side[p.j] = delta;
          Vec cp = b.c, cm = b.c;
          cp[p.j] += delta;
          cm[p.j] -= delta;
          boxes.push_back({cp, side, p.fp, sizeOf(side)});
          boxes.push_back({cm, side, p.fm, sizeOf(side)});
        }
        boxes[i].side = side;
        boxes[i].size = sizeOf(side);
      }
      for (size_t i = 0; i < boxes.size(); i++)
        if (boxes[i].f < boxes[bestI].f)
          bestI = i;
    }
    if (P.failed()) {
      ctx.fail(P.failText());
      return Value(0.0);
    }
    Result r;
    r.x = scaled(boxes[bestI].c);
    r.fun = boxes[bestI].f;
    r.nfev = nf;
    r.nit = 0;
    r.success = true;
    r.message = "The volume of the hyperrectangle containing the lowest function value found is below the limit.";
    return resultDict(r);
  } SP_END
  SP_ADD("approx_grad", 2, 3, "x, fn, eps=1.49e-8") {
    Vec x;
    if (!getVec(a, 0, ctx, x) || !getFn(a, 1, ctx))
      return Value(0.0);
    const double eps = optNum(a, 2, 1.4901161193847656e-08);
    NcFn f(a[1]);
    const double f0 = f.ofVec(x);
    Vec g(x.size()), p = x;
    for (size_t i = 0; i < x.size(); i++) {
      p[i] = x[i] + eps;
      g[i] = (f.ofVec(p) - f0) / eps;
      p[i] = x[i];
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return toValue(g);
  } SP_END
  SP_ADD("check_grad", 3, 4, "fn, grad, x0, eps=1.49e-8") {
    Vec x;
    if (!getFn(a, 0, ctx) || !getFn(a, 1, ctx) || !getVec(a, 2, ctx, x))
      return Value(0.0);
    const double eps = optNum(a, 3, 1.4901161193847656e-08);
    NcFn f(a[0]), gf(a[1]);
    const double f0 = f.ofVec(x);
    Vec g = gf.vecOfVec(x), p = x;
    double s = 0.0;
    for (size_t i = 0; i < x.size() && !gf.failed; i++) {
      p[i] = x[i] + eps;
      const double est = (f.ofVec(p) - f0) / eps;
      p[i] = x[i];
      s += (est - g[i]) * (est - g[i]);
    }
    if (f.failed || gf.failed) {
      ctx.fail((f.failed ? f : gf).failText());
      return Value(0.0);
    }
    return Value(std::sqrt(s));
  } SP_END
  SP_ADD("rosen", 1, 1, "x") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    double s = 0.0;
    for (size_t i = 0; i + 1 < x.size(); i++)
      s += 100.0 * std::pow(x[i + 1] - x[i] * x[i], 2.0) + std::pow(1.0 - x[i], 2.0);
    return Value(s);
  } SP_END
  SP_ADD("rosen_der", 1, 1, "x") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const size_t n = x.size();
    Vec g(n, 0.0);
    for (size_t i = 0; i + 1 < n; i++) {
      g[i] += -400.0 * x[i] * (x[i + 1] - x[i] * x[i]) - 2.0 * (1.0 - x[i]);
      g[i + 1] += 200.0 * (x[i + 1] - x[i] * x[i]);
    }
    return toValue(g);
  } SP_END
  SP_ADD("rosen_hess", 1, 1, "x") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const size_t n = x.size();
    Mat H(n, n);
    for (size_t i = 0; i + 1 < n; i++) {
      H(i, i) += 1200.0 * x[i] * x[i] - 400.0 * x[i + 1] + 2.0;
      H(i + 1, i + 1) += 200.0;
      H(i, i + 1) = H(i + 1, i) = -400.0 * x[i];
    }
    return toValue(H);
  } SP_END
  SP_ADD("rosen_hess_prod", 2, 2, "x, p") {
    Vec x, p;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, p))
      return Value(0.0);
    if (x.size() != p.size()) {
      ctx.fail("x and p must have the same length");
      return Value(0.0);
    }
    const size_t n = x.size();
    Vec o(n, 0.0);
    for (size_t i = 0; i + 1 < n; i++) {
      o[i] += (1200.0 * x[i] * x[i] - 400.0 * x[i + 1] + 2.0) * p[i] - 400.0 * x[i] * p[i + 1];
      o[i + 1] += 200.0 * p[i + 1] - 400.0 * x[i] * p[i];
    }
    return toValue(o);
  } SP_END
  registerOptRoots(reg);
  registerOptLeastSquares(reg);
  registerOptLinear(reg);
  reg.setParallel({"minimize", "minimize_scalar", "bracket_min", "line_search", "basin_hopping", "brute_force_min", "differential_evolution", "shgo",
                   "dual_annealing", "direct_search", "approx_grad", "check_grad", "root", "root_scalar", "fixed_point", "least_squares", "curve_fit"},
                  ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
