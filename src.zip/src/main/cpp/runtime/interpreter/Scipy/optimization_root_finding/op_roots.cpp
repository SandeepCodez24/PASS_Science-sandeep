// Root finding of scipy.optimize: root_scalar with its bracketing and open methods,
// root with its multidimensional methods, fixed_point.
#include "../linear_algebra/la_core.h"
#include "op_shared.h"
#include "optimization_root_finding_main.h"

#define SP_SEC Section::OptimizationRootFinding

namespace nc {
namespace scipy {

using namespace opt;

namespace {

struct RootOut {
  double root = kNaN;
  bool converged = false;
  long iterations = 0;
};
using F1 = std::function<double(double)>;
constexpr double kXtol = 2e-12, kRtol = 8.881784197001252e-16;

RootOut bisect(const F1 &f, double a, double b, double fa, long maxit) {
  RootOut o;
  for (; o.iterations < maxit; o.iterations++) {
    const double m = 0.5 * (a + b), fm = f(m);
    o.root = m;
    if (fm == 0.0 || 0.5 * (b - a) < kXtol + kRtol * std::fabs(m)) {
      o.converged = true;
      return o;
    }
    if (fa * fm < 0.0) {
      b = m;
    } else {
      a = m;
      fa = fm;
    }
  }
  return o;
}

// Brent (inverse quadratic) or the hyperbolic variant.
RootOut brent(const F1 &f, double a, double b, double fa, double fb, long maxit, bool hyperbolic) {
  RootOut o;
  double c = a, fc = fa, d = b - a, e = d;
  for (; o.iterations < maxit; o.iterations++) {
    if (std::fabs(fc) < std::fabs(fb)) {
      a = b;
      b = c;
      c = a;
      fa = fb;
      fb = fc;
      fc = fa;
    }
    const double tol = kXtol + kRtol * std::fabs(b), m = 0.5 * (c - b);
    if (std::fabs(m) <= tol || fb == 0.0) {
      o.root = b;
      o.converged = true;
      return o;
    }
    if (std::fabs(e) < tol || std::fabs(fa) <= std::fabs(fb)) {
      d = m;
      e = m;
    } else {
      double p, q, s = fb / fa;
      if (a == c) {
        p = 2.0 * m * s;
        q = 1.0 - s;
      } else if (hyperbolic) {
        const double dpre = (fa - fb) / (a - b), dblk = (fc - fb) / (c - b);
        p = -fb * (fc - fa) / (fc * dpre - fa * dblk);
        q = 1.0;
      } else {
        const double qq = fa / fc, r = fb / fc;
        p = s * (2.0 * m * qq * (qq - r) - (b - a) * (r - 1.0));
        q = (qq - 1.0) * (r - 1.0) * (s - 1.0);
      }
      // d is p / q: p >= 0 with the sign in q.
      if (p > 0.0)
        q = -q;
      else
        p = -p;
      if (hyperbolic || a == c)
        q = -q;
      const double lim = std::min(3.0 * std::fabs(m * q) - std::fabs(tol * q), std::fabs(e * q));
      if (2.0 * p < lim) {
        e = d;
        d = p / q;
      } else {
        d = m;
        e = m;
      }
    }
    a = b;
    fa = fb;
    b += std::fabs(d) > tol ? d : (m > 0 ? tol : -tol);
    fb = f(b);
    if ((fb > 0) == (fc > 0)) {
      c = a;
      fc = fa;
      d = b - a;
      e = d;
    }
  }
  o.root = b;
  return o;
}

RootOut ridder(const F1 &f, double a, double b, double fa, double fb, long maxit) {
  RootOut o;
  for (; o.iterations < maxit; o.iterations++) {
    const double m = 0.5 * (a + b), fm = f(m);
    const double s = std::sqrt(fm * fm - fa * fb);
    if (s == 0.0) {
      o.root = m;
      o.converged = true;
      return o;
    }
    const double x = m + (m - a) * ((fa > fb ? 1.0 : -1.0) * fm / s), fx = f(x);
    o.root = x;
    if (fx == 0.0) {
      o.converged = true;
      return o;
    }
    if ((fm > 0) != (fx > 0)) {
      a = m;
      fa = fm;
      b = x;
      fb = fx;
    } else if ((fa > 0) != (fx > 0)) {
      b = x;
      fb = fx;
    } else {
      a = x;
      fa = fx;
    }
    if (a > b) {
      std::swap(a, b);
      std::swap(fa, fb);
    }
    if (std::fabs(b - a) < kXtol + kRtol * std::fabs(x)) {
      o.converged = true;
      return o;
    }
  }
  return o;
}

// TOMS 748 in its simple form: quadratic and cubic inverse interpolation with bisection fallback.
RootOut toms748(const F1 &f, double a, double b, double fa, double fb, long maxit) {
  RootOut o;
  double d = kNaN, fd = kNaN;
  auto bracketTo = [&](double c) {
    const double fc = f(c);
    if (fc == 0.0) {
      a = b = c;
      fa = fb = 0.0;
      return;
    }
    if ((fa > 0) != (fc > 0)) {
      d = b;
      fd = fb;
      b = c;
      fb = fc;
    } else {
      d = a;
      fd = fa;
      a = c;
      fa = fc;
    }
  };
  for (; o.iterations < maxit; o.iterations++) {
    if (std::fabs(b - a) <= 2.0 * (kXtol + kRtol * std::fabs(b)) || fa == 0.0 || fb == 0.0)
      break;
    const double w0 = b - a;
    double c = b - fb * (b - a) / (fb - fa); // secant
    if (d == d && fd != fa && fd != fb && fa != fb) {
      // Inverse quadratic through a, b, d.
      const double t = a * fb * fd / ((fa - fb) * (fa - fd)) + b * fa * fd / ((fb - fa) * (fb - fd)) + d * fa * fb / ((fd - fa) * (fd - fb));
      if (t > a && t < b)
        c = t;
    }
    const double delta = 0.7 * (kXtol + kRtol * std::fabs(b));
    c = std::min(b - delta, std::max(a + delta, c));
    bracketTo(c);
    if (fa == 0.0 || fb == 0.0)
      break;
    if (b - a > 0.5 * w0)
      bracketTo(0.5 * (a + b));
  }
  o.root = std::fabs(fa) < std::fabs(fb) ? a : b;
  o.converged = o.iterations < maxit;
  return o;
}

RootOut newtonStep(const F1 &f, const F1 *fp, const F1 *fpp, double x, double x1, long maxit) {
  RootOut o;
  if (fp) {
    for (; o.iterations < maxit; o.iterations++) {
      const double fx = f(x);
      if (fx == 0.0) {
        o.root = x;
        o.converged = true;
        return o;
      }
      const double d = (*fp)(x);
      if (d == 0.0)
        break;
      double step = fx / d;
      if (fpp) {
        const double dd = (*fpp)(x);
        const double adj = dd / d * step / 2.0;
        if (std::fabs(adj) < 1.0)
          step /= 1.0 - adj;
      }
      const double nx = x - step;
      if (std::fabs(nx - x) < 1.48e-8 * 1e-4 + 1e-14 * std::fabs(nx)) {
        o.root = nx;
        o.converged = true;
        return o;
      }
      x = nx;
    }
    o.root = x;
    return o;
  }
  double p0 = x, p1 = x1, q0 = f(p0), q1 = f(p1);
  if (std::fabs(q1) < std::fabs(q0)) {
    std::swap(p0, p1);
    std::swap(q0, q1);
  }
  for (; o.iterations < maxit; o.iterations++) {
    if (q1 == q0) {
      o.root = 0.5 * (p0 + p1);
      o.converged = p0 == p1;
      return o;
    }
    const double p = std::fabs(q1) > std::fabs(q0) ? (-q0 / q1 * p1 + p0) / (1.0 - q0 / q1) : (-q1 / q0 * p0 + p1) / (1.0 - q1 / q0);
    if (std::fabs(p - p1) <= 1e-13 + 1e-13 * std::fabs(p)) {
      o.root = p;
      o.converged = true;
      return o;
    }
    p0 = p1;
    q0 = q1;
    p1 = p;
    q1 = f(p1);
  }
  o.root = p1;
  return o;
}

// Multidimensional roots. J is a finite-difference Jacobian.
Mat fdJac(const std::function<Vec(const Vec &)> &F, const Vec &x, const Vec &f0) {
  Mat J(f0.size(), x.size());
  Vec p = x;
  for (size_t j = 0; j < x.size(); j++) {
    const double h = std::sqrt(kEps) * std::max(1e-3, std::fabs(x[j]));
    p[j] = x[j] + h;
    Vec f1 = F(p);
    for (size_t i = 0; i < f0.size(); i++)
      J(i, j) = (f1[i] - f0[i]) / h;
    p[j] = x[j];
  }
  return J;
}

struct RootSolve {
  Vec x;
  bool ok = false;
  std::string msg;
  long nit = 0;
};

// Newton with backtracking (the "hybr", "lm" and "krylov" routes differ only in the step solve).
RootSolve dampedNewton(const std::function<Vec(const Vec &)> &F, Vec x, const std::function<bool()> &failed, double tol, long maxit, bool levenberg) {
  RootSolve r;
  Vec f = F(x);
  double lambda = 1e-3;
  for (; r.nit < maxit && !failed(); r.nit++) {
    double nf = vnorm(f);
    if (nf <= tol) {
      r.ok = true;
      break;
    }
    Mat J = fdJac(F, x, f);
    Vec d;
    if (levenberg) {
      Mat JtJ = mul(transposeOf(J), J);
      Vec g = mulVec(transposeOf(J), f);
      double best = nf;
      for (int t = 0; t < 30; t++) {
        Mat A = JtJ;
        for (size_t i = 0; i < A.r; i++)
          A(i, i) += lambda * std::max(JtJ(i, i), 1e-12);
        d = g;
        if (!la::solveVec(A, d))
          d.assign(x.size(), 0.0);
        Vec xn = x;
        for (size_t i = 0; i < x.size(); i++)
          xn[i] -= d[i];
        Vec fn = F(xn);
        if (vnorm(fn) < best) {
          x = xn;
          f = fn;
          lambda = std::max(lambda * 0.3, 1e-14);
          break;
        }
        lambda *= 4.0;
      }
      if (vnorm(f) >= nf) {
        r.ok = nf <= 1e-6;
        break;
      }
      continue;
    }
    d = la::lstsqMin(J, f);
    double step = 1.0;
    bool ok = false;
    for (int t = 0; t < 40; t++) {
      Vec xn = x;
      for (size_t i = 0; i < x.size(); i++)
        xn[i] -= step * d[i];
      Vec fn = F(xn);
      if (vnorm(fn) < (1.0 - 1e-4 * step) * nf) {
        x = xn;
        f = fn;
        ok = true;
        break;
      }
      step *= 0.5;
    }
    if (!ok) {
      r.ok = nf <= 1e-6;
      break;
    }
  }
  r.x = x;
  if (vnorm(f) <= std::max(tol, 1e-8))
    r.ok = true;
  return r;
}

// Broyden with J0 from finite differences; first or second update (or diagonal).
RootSolve broyden(const std::function<Vec(const Vec &)> &F, Vec x, const std::function<bool()> &failed, double tol, long maxit, int kind) {
  RootSolve r;
  const size_t n = x.size();
  Vec f = F(x);
  Mat J = fdJac(F, x, f);
  if (kind == 3)
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        if (i != j)
          J(i, j) = 0.0;
  Mat Jinv;
  if (!la::inverse(J, Jinv))
    Jinv = Mat::eye(n);
  for (; r.nit < maxit && !failed(); r.nit++) {
    const double nf = vnorm(f);
    if (nf <= tol) {
      r.ok = true;
      break;
    }
    Vec d = mulVec(Jinv, f);
    double step = 1.0;
    Vec xn(n), fn;
    bool ok = false;
    for (int t = 0; t < 25; t++) {
      for (size_t i = 0; i < n; i++)
        xn[i] = x[i] - step * d[i];
      fn = F(xn);
      if (vnorm(fn) < nf) {
        ok = true;
        break;
      }
      step *= 0.5;
    }
    if (!ok)
      break;
    Vec s(n), y(n);
    for (size_t i = 0; i < n; i++) {
      s[i] = xn[i] - x[i];
      y[i] = fn[i] - f[i];
    }
    Vec Jy = mulVec(Jinv, y);
    if (kind == 1) {
      Vec sJ = mulVec(transposeOf(Jinv), s);
      const double den = vdot(s, Jy);
      if (den != 0.0)
        for (size_t i = 0; i < n; i++)
          for (size_t j = 0; j < n; j++)
            Jinv(i, j) += (s[i] - Jy[i]) * sJ[j] / den;
    } else if (kind == 2) {
      const double den = vdot(y, y);
      if (den != 0.0)
        for (size_t i = 0; i < n; i++)
          for (size_t j = 0; j < n; j++)
            Jinv(i, j) += (s[i] - Jy[i]) * y[j] / den;
    } else {
      for (size_t i = 0; i < n; i++)
        if (y[i] != 0.0)
          Jinv(i, i) = s[i] / y[i];
    }
    x = xn;
    f = fn;
  }
  r.x = x;
  r.ok = r.ok || vnorm(f) <= tol;
  return r;
}

// Mixing x <- x + alpha F(x), with alpha chosen as scipy does; Anderson keeps a window of the last steps.
RootSolve mixing(const std::function<Vec(const Vec &)> &F, Vec x, const std::function<bool()> &failed, double tol, long maxit, size_t window, bool exciting) {
  RootSolve r;
  const size_t n = x.size();
  Vec f = F(x);
  const double nf0 = vnorm(f);
  const double alpha = nf0 > 0.0 ? 0.5 * std::max(vnorm(x), 1.0) / nf0 : 1.0;
  Vec beta(n, alpha);
  std::vector<Vec> dX, dF;
  for (; r.nit < maxit && !failed(); r.nit++) {
    const double nf = vnorm(f);
    if (nf <= tol) {
      r.ok = true;
      break;
    }
    Vec step(n);
    for (size_t i = 0; i < n; i++)
      step[i] = beta[i] * f[i];
    if (window > 0 && !dX.empty()) {
      Mat G(n, dF.size());
      for (size_t j = 0; j < dF.size(); j++)
        for (size_t i = 0; i < n; i++)
          G(i, j) = dF[j][i];
      Vec gam = la::lstsqMin(G, f);
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < dF.size(); j++)
          step[i] -= gam[j] * (dX[j][i] + alpha * dF[j][i]);
    }
    Vec xn(n), fn;
    double t = 1.0;
    for (int back = 0; back < 30; back++) {
      for (size_t i = 0; i < n; i++)
        xn[i] = x[i] + t * step[i];
      fn = F(xn);
      if (vnorm(fn) < nf)
        break;
      t *= 0.5;
    }
    if (exciting)
      for (size_t i = 0; i < n; i++)
        beta[i] = fn[i] * f[i] > 0 ? std::min(beta[i] + alpha, 1.0) : alpha;
    if (window > 0) {
      Vec a1(n), a2(n);
      for (size_t i = 0; i < n; i++) {
        a1[i] = xn[i] - x[i];
        a2[i] = fn[i] - f[i];
      }
      dX.push_back(a1);
      dF.push_back(a2);
      if (dX.size() > window) {
        dX.erase(dX.begin());
        dF.erase(dF.begin());
      }
    }
    x = xn;
    f = fn;
    if (!std::isfinite(vnorm(f)))
      break;
  }
  r.x = x;
  r.ok = r.ok || vnorm(f) <= tol;
  return r;
}

} // namespace

void registerOptRoots(Registry &reg) {
  SP_ADD("root_scalar", 2, 6, "fn, bracket, x0, method, fprime, x1") {
    if (!getFn(a, 0, ctx))
      return Value(0.0);
    Vec br;
    if (!isOmitted(a, 1) && !getVec(a, 1, ctx, br))
      return Value(0.0);
    const bool hasX0 = isNumberArg(a, 2) && (br.empty() || a[2].number != 0.0);
    std::string method = optText(a, 3, "");
    NcFn f(a[0]);
    F1 g = [&](double t) { return f.scalar(t); };
    std::unique_ptr<NcFn> fpN;
    F1 fp;
    if (a.size() > 4 && isCallable(a[4])) {
      fpN = std::make_unique<NcFn>(a[4]);
      fp = [&](double t) { return fpN->scalar(t); };
    }
    if (method.empty())
      method = br.size() == 2 ? "brentq" : (fp ? "newton" : "secant");
    RootOut o;
    const long maxit = 1000;
    if (method == "brentq" || method == "brenth" || method == "bisect" || method == "ridder" || method == "toms748") {
      if (br.size() != 2) {
        ctx.fail("method \"" + method + "\" needs a bracket [a, b]");
        return Value(0.0);
      }
      const double fa = g(br[0]), fb = g(br[1]);
      if (f.failed) {
        ctx.fail(f.failText());
        return Value(0.0);
      }
      if (fa == 0.0 || fb == 0.0) {
        o.root = fa == 0.0 ? br[0] : br[1];
        o.converged = true;
      } else if ((fa > 0) == (fb > 0)) {
        ctx.fail("f(a) and f(b) must have different signs");
        return Value(0.0);
      } else if (method == "brentq")
        o = brent(g, br[0], br[1], fa, fb, maxit, false);
      else if (method == "brenth")
        o = brent(g, br[0], br[1], fa, fb, maxit, true);
      else if (method == "bisect")
        o = bisect(g, std::min(br[0], br[1]), std::max(br[0], br[1]), br[0] < br[1] ? fa : fb, maxit);
      else if (method == "ridder")
        o = ridder(g, std::min(br[0], br[1]), std::max(br[0], br[1]), br[0] < br[1] ? fa : fb, br[0] < br[1] ? fb : fa, maxit);
      else
        o = toms748(g, std::min(br[0], br[1]), std::max(br[0], br[1]), br[0] < br[1] ? fa : fb, br[0] < br[1] ? fb : fa, maxit);
    } else if (method == "newton" || method == "secant" || method == "halley") {
      if (!hasX0) {
        ctx.fail("method \"" + method + "\" needs a starting guess x0");
        return Value(0.0);
      }
      const double x0 = a[2].number;
      if (method == "newton" && !fp) {
        method = "secant";
      }
      const double x1 = isNumberArg(a, 5) ? a[5].number : x0 * (1.0 + 1e-4) + (x0 >= 0 ? 1e-4 : -1e-4);
      o = newtonStep(g, method == "secant" ? nullptr : &fp, nullptr, x0, x1, maxit);
    } else {
      ctx.fail("unknown method \"" + method + "\"");
      return Value(0.0);
    }
    if (f.failed || (fpN && fpN->failed)) {
      ctx.fail(f.failed ? f.failText() : fpN->failText());
      return Value(0.0);
    }
    return makeDict({{"root", Value(o.root)}, {"converged", Value::boolean(o.converged)}, {"iterations", Value((double)o.iterations)},
                     {"function_calls", Value((double)f.calls)}, {"method", Value(method)}});
  } SP_END
  SP_ADD("fixed_point", 2, 3, "fn, x0, xtol=1e-8") {
    Vec x;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, x))
      return Value(0.0);
    const double tol = optNum(a, 2, 1e-8);
    NcFn f(a[0]);
    const bool scalar = isPlainNumber(a[1]);
    auto eval = [&](const Vec &v) -> Vec {
      if (scalar)
        return {f.scalar(v[0])};
      return f.vecOfVec(v);
    };
    // Steffensen's acceleration, as scipy's del2.
    for (int it = 0; it < 500; it++) {
      Vec p1 = eval(x), p2 = eval(p1);
      if (f.failed || p1.size() != x.size() || p2.size() != x.size()) {
        ctx.fail(f.failed ? f.failText() : "the function must return as many values as it takes");
        return Value(0.0);
      }
      Vec p(x.size());
      double rel = 0.0;
      for (size_t i = 0; i < x.size(); i++) {
        const double den = p2[i] - 2.0 * p1[i] + x[i];
        p[i] = den == 0.0 ? p2[i] : x[i] - (p1[i] - x[i]) * (p1[i] - x[i]) / den;
        rel = std::max(rel, x[i] != 0.0 ? std::fabs((p[i] - x[i]) / x[i]) : std::fabs(p[i]));
      }
      x = p;
      if (rel < tol)
        return scalar ? Value(x[0]) : toValue(x);
    }
    ctx.fail("no fixed point was found within 500 iterations");
    return Value(0.0);
  } SP_END
  SP_ADD("root", 2, 4, "fn, x0, method=\"hybr\", tol=1e-10") {
    Vec x0;
    if (!getFn(a, 0, ctx) || !getVec(a, 1, ctx, x0))
      return Value(0.0);
    const std::string m = optText(a, 2, "hybr");
    const double tol = optNum(a, 3, 1e-10);
    NcFn f(a[0]);
    const size_t n = x0.size();
    std::function<Vec(const Vec &)> F = [&](const Vec &x) {
      Vec v = f.vecOfVec(x);
      if (f.failed || v.size() != n) {
        f.failed = true;
        return Vec(n, kNaN);
      }
      return v;
    };
    std::function<bool()> failed = [&] { return f.failed; };
    RootSolve r;
    const long maxit = 2000;
    if (m == "hybr" || m == "krylov")
      r = dampedNewton(F, x0, failed, tol, maxit, false);
    else if (m == "lm")
      r = dampedNewton(F, x0, failed, tol, maxit, true);
    else if (m == "broyden1")
      r = broyden(F, x0, failed, tol, maxit, 1);
    else if (m == "broyden2")
      r = broyden(F, x0, failed, tol, maxit, 2);
    else if (m == "diagbroyden")
      r = broyden(F, x0, failed, tol, maxit, 3);
    else if (m == "anderson")
      r = mixing(F, x0, failed, tol, maxit * 5, 5, false);
    else if (m == "linearmixing")
      r = mixing(F, x0, failed, tol, maxit * 5, 0, false);
    else if (m == "excitingmixing")
      r = mixing(F, x0, failed, tol, maxit * 5, 0, true);
    else {
      ctx.fail("unknown method \"" + m + "\"");
      return Value(0.0);
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return makeDict({{"x", toValue(r.x)}, {"success", Value::boolean(r.ok)}, {"nit", Value((double)r.nit)},
                     {"message", Value(std::string(r.ok ? "The solution converged." : "The iteration is not making good progress."))}});
  } SP_END
}

} // namespace scipy
} // namespace nc
