// Linear programming and assignment problems of scipy.optimize.
#include "../linear_algebra/la_core.h"
#include "op_shared.h"
#include "optimization_root_finding_main.h"

#define SP_SEC Section::OptimizationRootFinding

namespace nc {
namespace scipy {

using namespace opt;

namespace {

struct LpProblem {
  Vec c, bub, beq;
  Mat Aub, Aeq;
  Vec lo, hi;
};
struct LpResult {
  Vec x;
  double fun = 0.0;
  int status = 0; // 0 optimal, 2 infeasible, 3 unbounded, 1 iteration limit
  long nit = 0;
};

// Two-phase simplex with Bland's rule, on x >= 0 after shifting the bounds.
LpResult simplex(const LpProblem &P) {
  const size_t n = P.c.size();
  LpResult res;
  // Variables: y = x - lo (or hi - x when only hi is finite; free splits in two).
  struct Map {
    size_t col;
    double sign, shift;
    long neg; // the column of a free variable's negative part
  };
  std::vector<Map> map(n);
  size_t cols = 0;
  for (size_t j = 0; j < n; j++) {
    if (!std::isinf(P.lo[j]))
      map[j] = {cols++, 1.0, P.lo[j], -1};
    else if (!std::isinf(P.hi[j]))
      map[j] = {cols++, -1.0, P.hi[j], -1};
    else {
      map[j] = {cols, 1.0, 0.0, (long)cols + 1};
      cols += 2;
    }
  }
  // Rows: A_ub, upper bounds of doubly bounded variables, A_eq.
  std::vector<Vec> rows;
  Vec rhs;
  std::vector<char> isEq;
  auto addRow = [&](const double *a, double b, bool eq) {
    Vec r(cols, 0.0);
    double shift = 0.0;
    for (size_t j = 0; j < n; j++) {
      r[map[j].col] += a[j] * map[j].sign;
      if (map[j].neg >= 0)
        r[(size_t)map[j].neg] -= a[j];
      shift += a[j] * map[j].shift;
    }
    rows.push_back(r);
    rhs.push_back(b - shift);
    isEq.push_back(eq);
  };
  for (size_t i = 0; i < P.Aub.r; i++)
    addRow(P.Aub.row(i), P.bub[i], false);
  for (size_t j = 0; j < n; j++)
    if (!std::isinf(P.lo[j]) && !std::isinf(P.hi[j])) {
      Vec e(n, 0.0);
      e[j] = 1.0;
      addRow(e.data(), P.hi[j], false);
    }
  for (size_t i = 0; i < P.Aeq.r; i++)
    addRow(P.Aeq.row(i), P.beq[i], true);
  const size_t m = rows.size();
  size_t slacks = 0;
  for (char e : isEq)
    slacks += !e;
  const size_t total = cols + slacks + m; // structural, slack, artificial
  Mat T(m + 1, total + 1);
  std::vector<size_t> basis(m);
  size_t sl = cols;
  for (size_t i = 0; i < m; i++) {
    double sgn = rhs[i] < 0.0 ? -1.0 : 1.0;
    for (size_t j = 0; j < cols; j++)
      T(i, j) = sgn * rows[i][j];
    if (!isEq[i])
      T(i, sl++) = sgn;
    T(i, cols + slacks + i) = 1.0;
    T(i, total) = sgn * rhs[i];
    basis[i] = cols + slacks + i;
  }
  auto pivot = [&](size_t pr, size_t pc) {
    const double pv = T(pr, pc);
    for (size_t j = 0; j <= total; j++)
      T(pr, j) /= pv;
    for (size_t i = 0; i <= m; i++) {
      if (i == pr)
        continue;
      const double f = T(i, pc);
      if (f != 0.0)
        for (size_t j = 0; j <= total; j++)
          T(i, j) -= f * T(pr, j);
    }
    basis[pr] = pc;
  };
  auto run = [&](size_t limitCols) {
    for (long it = 0; it < 100000; it++) {
      size_t pc = limitCols;
      for (size_t j = 0; j < limitCols; j++)
        if (T(m, j) < -1e-9) {
          pc = j;
          break;
        }
      if (pc == limitCols)
        return 0;
      size_t pr = m;
      double best = kInf;
      for (size_t i = 0; i < m; i++)
        if (T(i, pc) > 1e-9) {
          const double q = T(i, total) / T(i, pc);
          if (q < best - 1e-12 || (std::fabs(q - best) <= 1e-12 && pr < m && basis[i] < basis[pr])) {
            best = q;
            pr = i;
          }
        }
      if (pr == m)
        return 3;
      pivot(pr, pc);
      res.nit++;
    }
    return 1;
  };
  // Phase 1.
  for (size_t j = 0; j <= total; j++) {
    double s = 0.0;
    if (j < cols + slacks || j == total)
      for (size_t i = 0; i < m; i++)
        s -= T(i, j);
    T(m, j) = s;
  }
  run(cols + slacks);
  if (std::fabs(T(m, total)) > 1e-7) {
    res.status = 2;
    return res;
  }
  for (size_t i = 0; i < m; i++)
    if (basis[i] >= cols + slacks) {
      for (size_t j = 0; j < cols + slacks; j++)
        if (std::fabs(T(i, j)) > 1e-9) {
          pivot(i, j);
          break;
        }
    }
  // Phase 2.
  Vec cost(cols + slacks, 0.0);
  for (size_t j = 0; j < n; j++) {
    cost[map[j].col] += P.c[j] * map[j].sign;
    if (map[j].neg >= 0)
      cost[(size_t)map[j].neg] -= P.c[j];
  }
  for (size_t j = 0; j <= total; j++)
    T(m, j) = j < cols + slacks ? cost[j] : 0.0;
  for (size_t i = 0; i < m; i++)
    if (basis[i] < cols + slacks && cost[basis[i]] != 0.0) {
      const double f = cost[basis[i]];
      for (size_t j = 0; j <= total; j++)
        T(m, j) -= f * T(i, j);
    }
  const int st = run(cols + slacks);
  if (st) {
    res.status = st;
    return res;
  }
  Vec y(total, 0.0);
  for (size_t i = 0; i < m; i++)
    y[basis[i]] = T(i, total);
  res.x.resize(n);
  for (size_t j = 0; j < n; j++) {
    res.x[j] = map[j].shift + map[j].sign * y[map[j].col];
    if (map[j].neg >= 0)
      res.x[j] -= y[(size_t)map[j].neg];
  }
  res.fun = vdot(P.c, res.x);
  return res;
}

// Rows of a Matrix input, tolerant of a 1 x n Array holding one row.
bool optMat(const Args &a, size_t i, CallContext &ctx, Mat &m, size_t cols) {
  if (isOmitted(a, i)) {
    m = Mat(0, cols);
    return true;
  }
  if (!getMat(a, i, ctx, m))
    return false;
  if (m.c != cols) {
    ctx.fail("the " + ordinal(i) + " argument must have one column per variable");
    return false;
  }
  return true;
}

void setBounds(LpProblem &P, const Mat &bd) {
  const size_t n = P.c.size();
  P.lo.assign(n, 0.0);
  P.hi.assign(n, kInf);
  if (bd.a.empty())
    return;
  for (size_t j = 0; j < n; j++) {
    const size_t r = bd.r == 1 ? 0 : j;
    P.lo[j] = bd(r, 0);
    P.hi[j] = bd(r, 1);
  }
}

const char *lpMessage(int s) {
  return s == 0 ? "Optimization terminated successfully." : s == 2 ? "The problem is infeasible." : s == 3 ? "The problem is unbounded." : "Iteration limit reached.";
}

Value lpDict(const LpResult &r) {
  return makeDict({{"x", toValue(r.x)}, {"fun", Value(r.fun)}, {"success", Value::boolean(r.status == 0)}, {"status", Value((double)r.status)},
                   {"nit", Value((double)r.nit)}, {"message", Value(std::string(lpMessage(r.status)))}});
}

// Branch and bound on the integer variables.
void branch(LpProblem P, const std::vector<char> &integer, LpResult &best, long &nodes) {
  if (++nodes > 200000)
    return;
  LpResult r = simplex(P);
  if (r.status != 0 || (best.status == 0 && r.fun >= best.fun - 1e-9))
    return;
  long pick = -1;
  double frac = 1e-7;
  for (size_t j = 0; j < r.x.size(); j++)
    if (integer[j]) {
      const double f = std::fabs(r.x[j] - std::round(r.x[j]));
      if (f > frac) {
        frac = f;
        pick = (long)j;
      }
    }
  if (pick < 0) {
    for (size_t j = 0; j < r.x.size(); j++)
      if (integer[j])
        r.x[j] = std::round(r.x[j]);
    best = r;
    best.status = 0;
    return;
  }
  const double v = r.x[(size_t)pick];
  LpProblem down = P, up = P;
  down.hi[(size_t)pick] = std::floor(v);
  up.lo[(size_t)pick] = std::ceil(v);
  branch(down, integer, best, nodes);
  branch(up, integer, best, nodes);
}

// Adds a linear_constraint Dict, or a Dict of them, as rows of the problem.
bool addLinearConstraint(const Value &c, LpProblem &P, std::string &err) {
  const Value *k = dictGet(c, "kind");
  if (!k) {
    if (c.isDict && !c.dict().empty()) {
      for (const auto &kv : c.dict())
        if (!addLinearConstraint(kv.second, P, err))
          return false;
      return true;
    }
    err = "constraints must come from linear_constraint()";
    return false;
  }
  Mat A;
  Vec lo, hi;
  if (k->text() != "linear" || !readMat(*dictGet(c, "A"), A) || !readVec(*dictGet(c, "low"), lo) || !readVec(*dictGet(c, "high"), hi) || A.c != P.c.size()) {
    err = "constraints must come from linear_constraint() and have one column per variable";
    return false;
  }
  for (size_t i = 0; i < A.r; i++) {
    const double L = lo.size() == 1 ? lo[0] : lo[i], H = hi.size() == 1 ? hi[0] : hi[i];
    auto append = [&](Mat &M, Vec &b, double sign, double rhs) {
      Mat N(M.r + 1, P.c.size());
      std::copy(M.a.begin(), M.a.end(), N.a.begin());
      for (size_t j = 0; j < A.c; j++)
        N(M.r, j) = sign * A(i, j);
      M = N;
      b.push_back(sign * rhs);
    };
    if (L == H) {
      append(P.Aeq, P.beq, 1.0, H);
      continue;
    }
    if (!std::isinf(H))
      append(P.Aub, P.bub, 1.0, H);
    if (!std::isinf(L))
      append(P.Aub, P.bub, -1.0, L);
  }
  return true;
}

} // namespace

void registerOptLinear(Registry &reg) {
  SP_ADD("linprog", 1, 6, "c, A_ub, b_ub, A_eq, b_eq, bounds") {
    LpProblem P;
    if (!getVec(a, 0, ctx, P.c))
      return Value(0.0);
    const size_t n = P.c.size();
    Mat bd;
    if (!optMat(a, 1, ctx, P.Aub, n) || !optMat(a, 3, ctx, P.Aeq, n) || !getBounds(a, 5, ctx, bd, 0))
      return Value(0.0);
    if (P.Aub.r && !getVec(a, 2, ctx, P.bub))
      return Value(0.0);
    if (P.Aeq.r && !getVec(a, 4, ctx, P.beq))
      return Value(0.0);
    if (P.bub.size() != P.Aub.r || P.beq.size() != P.Aeq.r) {
      ctx.fail("each limit array must have one value per row of its matrix");
      return Value(0.0);
    }
    if (!bd.a.empty() && bd.r != 1 && bd.r != n) {
      ctx.fail("bounds needs one [low, high] row, or one per variable");
      return Value(0.0);
    }
    setBounds(P, bd);
    return lpDict(simplex(P));
  } SP_END
  SP_ADD("milp", 1, 4, "c, constraints, integrality, bounds") {
    LpProblem P;
    if (!getVec(a, 0, ctx, P.c))
      return Value(0.0);
    const size_t n = P.c.size();
    P.Aub = Mat(0, n);
    P.Aeq = Mat(0, n);
    if (!isOmitted(a, 1)) {
      std::string err;
      if (!addLinearConstraint(a[1], P, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
    }
    std::vector<char> integer(n, 0);
    if (!isOmitted(a, 2) || (a.size() > 2 && isPlainNumber(a[2]) && a[2].number != 0.0)) {
      Vec iv;
      if (!getVec(a, 2, ctx, iv))
        return Value(0.0);
      if (iv.size() == 1)
        iv.assign(n, double(iv[0]));
      if (iv.size() != n) {
        ctx.fail("integrality needs one value per variable");
        return Value(0.0);
      }
      for (size_t j = 0; j < n; j++)
        integer[j] = iv[j] != 0.0;
    }
    Mat bd;
    if (!getBounds(a, 3, ctx, bd, 0))
      return Value(0.0);
    setBounds(P, bd);
    LpResult best;
    best.status = 2;
    long nodes = 0;
    branch(P, integer, best, nodes);
    if (best.status != 0) {
      LpResult relax = simplex(P);
      if (relax.status == 3)
        best.status = 3;
    }
    return lpDict(best);
  } SP_END
  SP_ADD("assignment", 1, 2, "cost, maximize=0") {
    Mat C;
    if (!getMat(a, 0, ctx, C))
      return Value(0.0);
    if (optBool(a, 1, false))
      for (double &v : C.a)
        v = -v;
    IVec rows, cols;
    if (!graph_shared::assignmentMin(C, rows, cols)) {
      ctx.fail("no complete assignment exists");
      return Value(0.0);
    }
    return makeDict({{"rows", toValue(rows)}, {"cols", toValue(cols)}});
  } SP_END
  SP_ADD("quadratic_assignment", 2, 4, "A, B, method=\"faq\", maximize=0") {
    // Restarted 2-opt from assignment-based starting points: minimises trace(A P B' P').
    Mat A, B;
    if (!getSquare(a, 0, ctx, A) || !getSquare(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r) {
      ctx.fail("A and B must have the same size");
      return Value(0.0);
    }
    const std::string m = optText(a, 2, "faq");
    if (m != "faq" && m != "2opt") {
      ctx.fail("method must be \"faq\" or \"2opt\"");
      return Value(0.0);
    }
    const double sgn = optBool(a, 3, false) ? -1.0 : 1.0;
    const size_t n = A.r;
    auto cost = [&](const std::vector<size_t> &p) {
      double s = 0.0;
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
          s += A(i, j) * B(p[i], p[j]);
      return s;
    };
    std::vector<size_t> perm(n), best;
    double bestF = kInf;
    long nit = 0;
    for (size_t start = 0; start < std::max<size_t>(1, std::min<size_t>(n, 8)); start++) {
      for (size_t i = 0; i < n; i++)
        perm[i] = (i + start) % n;
      double f = sgn * cost(perm);
      for (bool again = true; again;) {
        again = false;
        for (size_t i = 0; i < n; i++)
          for (size_t j = i + 1; j < n; j++) {
            std::swap(perm[i], perm[j]);
            const double t = sgn * cost(perm);
            if (t < f - 1e-12) {
              f = t;
              again = true;
              nit++;
            } else {
              std::swap(perm[i], perm[j]);
            }
          }
      }
      if (f < bestF) {
        bestF = f;
        best = perm;
      }
    }
    IVec col(best.begin(), best.end());
    return makeDict({{"col_ind", toValue(col)}, {"fun", Value(sgn * bestF)}, {"nit", Value((double)nit)}});
  } SP_END
}

} // namespace scipy
} // namespace nc
