// Section 24 of 25 - Removed Since SciPy 1.8 (with Replacements) - Appendix A
// SciPy module: (various)
// Planned entries: 60
//
// This file is the ONE place where this section's entries are mapped to NC
// names. Nothing outside this folder needs to change when you add one.//
// Appendix A note: these are functions SciPy removed after 1.8, each with a
// documented replacement. If NC keeps an old name, register it here and make
// its implementation call the replacement's implementation (the replacement
// lives in its own section) rather than duplicating the code.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        removed_since_1_8/rs_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerRemovedSince18() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Scipy/scipy_sources.cmake globs the whole Scipy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 25 sections.
//   - A name already used by an NC builtin (ops/), by a NumPy function
//     (Numpy/), by an NC keyword or a parser-reserved call is skipped: the
//     existing one stays. The reason is printed at startup.
#include "removed_since_1_8_main.h"

#include "../scipy_core.h"

namespace nc {
namespace scipy {

void registerRmFunctions(Registry &reg);

void registerRemovedSince18(Registry &reg) { registerRmFunctions(reg); }

} // namespace scipy
} // namespace nc
