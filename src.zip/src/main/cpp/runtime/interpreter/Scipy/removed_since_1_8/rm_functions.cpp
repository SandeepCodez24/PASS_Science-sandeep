// Appendix A: functions removed from SciPy since 1.8 that NC still provides
// (B-spline basis, complex sort, the continuous wavelet transform and its
// wavelets, Daubechies filters and the cascade algorithm, qmf, item counts,
// tri, the generalized eigenproblem as ?ggev reports it, numerical
// derivatives, finite-difference weights, the boolean metrics SciPy
// dropped from distance (mismatch_frac, kulczynski1) and help). The other
// removed names map to existing functions.
#include "removed_since_1_8_main.h"

#include <iostream>
#include <map>

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::RemovedSince18

namespace {

// Cox-de Boor recursion for the basis element on knots t, at x (0 outside)
double bsplineBasis(const Vec &t, double x) {
  size_t k = t.size() - 1; // number of intervals
  if (x < t.front() || x > t.back() || k == 0)
    return 0.0;
  Vec N(k, 0.0);
  for (size_t i = 0; i < k; i++)
    if ((t[i] <= x && x < t[i + 1]) || (x == t.back() && i + 1 == k && t[i] < t[i + 1]))
      N[i] = 1.0;
  for (size_t d = 1; d < k; d++)
    for (size_t i = 0; i + d < k; i++) {
      double a = t[i + d] - t[i], b = t[i + d + 1] - t[i + 1];
      double v = 0;
      if (a > 0)
        v += (x - t[i]) / a * N[i];
      if (b > 0)
        v += (t[i + d + 1] - x) / b * N[i + 1];
      N[i] = v;
    }
  return N[0];
}

CVec ricker(size_t points, double a) {
  double A = 2 / (std::sqrt(3 * a) * std::pow(kPi, 0.25)), w = a * a;
  CVec v(points);
  for (size_t i = 0; i < points; i++) {
    double x = double(i) - (points - 1.0) / 2, x2 = x * x;
    v[i] = A * (1 - x2 / w) * std::exp(-x2 / (2 * w));
  }
  return v;
}
CVec morlet2(size_t points, double s, double w) {
  CVec v(points);
  for (size_t i = 0; i < points; i++) {
    double x = (double(i) - (points - 1.0) / 2) / s;
    v[i] = std::exp(cd(0, w * x)) * std::exp(-0.5 * x * x) * std::pow(kPi, -0.25) * std::sqrt(1 / s);
  }
  return v;
}

// Daubechies low-pass filter with p vanishing moments (SciPy's daub)
bool daub(int p, Vec &h) {
  const double s2 = std::sqrt(2.0);
  if (p < 1)
    return false;
  if (p == 1) {
    h = {1 / s2, 1 / s2};
    return true;
  }
  if (p == 2) {
    double f = s2 / 8, c = std::sqrt(3.0);
    h = {f * (1 + c), f * (3 + c), f * (3 - c), f * (1 - c)};
    return true;
  }
  if (p == 3) {
    double tmp = 12 * std::sqrt(10.0);
    cd z1(1.5 + std::sqrt(15 + tmp) / 6, -(std::sqrt(15.0) + std::sqrt(tmp - 15)) / 6), z1c = std::conj(z1);
    double f = s2 / 8, d0 = ((1.0 - z1) * (1.0 - z1c)).real(), a0 = (z1 * z1c).real(), a1 = 2 * z1.real();
    h = {f / d0 * a0, f / d0 * (3 * a0 - a1), f / d0 * (3 * a0 - 3 * a1 + 1), f / d0 * (a0 - 3 * a1 + 3), f / d0 * (3 - a1), f / d0};
    return true;
  }
  if (p >= 35)
    return false;
  CVec P(p);
  for (int k = 0; k < p; k++) // comb(p - 1 + k, k), highest power first
    P[p - 1 - k] = std::round(std::exp(std::lgamma(p + k) - std::lgamma(k + 1.0) - std::lgamma(p + 0.0)));
  CVec y = la::polyRoots(P);
  // q = prod (z - z1) over the roots outside the unit circle; c = (z + 1)^p
  CVec q = {1.0};
  for (int k = 0; k < p - 1; k++) {
    cd part = 2.0 * std::sqrt(y[k] * (y[k] - 1.0)), cst = 1.0 - 2.0 * y[k], z1 = cst + part;
    if (std::abs(z1) < 1)
      z1 = cst - part;
    CVec nq(q.size() + 1, 0.0);
    for (size_t i = 0; i < q.size(); i++) {
      nq[i] += q[i];
      nq[i + 1] -= z1 * q[i];
    }
    q = nq;
  }
  Vec c = {1.0};
  for (int k = 0; k < p; k++) {
    Vec nc(c.size() + 1, 0.0);
    for (size_t i = 0; i < c.size(); i++) {
      nc[i] += c[i];
      nc[i + 1] += c[i];
    }
    c = nc;
  }
  Vec r(c.size() + q.size() - 1, 0.0);
  for (size_t i = 0; i < c.size(); i++)
    for (size_t j = 0; j < q.size(); j++)
      r[i + j] += c[i] * q[j].real();
  double s = 0;
  for (double v : r)
    s += v;
  h.assign(r.rbegin(), r.rend());
  for (double &v : h)
    v = v / s * s2;
  return true;
}

Vec qmfOf(const Vec &h) {
  Vec g(h.rbegin(), h.rend());
  for (size_t k = 1; k < g.size(); k += 2)
    g[k] = -g[k];
  return g;
}

bool waveletName(const Args &a, size_t i, CallContext &ctx, Vec &h) {
  int p = 0;
  if (i < a.size() && a[i].isText) {
    std::string n = a[i].text();
    if ((n.rfind("db", 0) == 0 && n.size() > 2) || (n.rfind("daub", 0) == 0 && n.size() > 4))
      p = std::atoi(n.c_str() + (n[1] == 'b' ? 2 : 4));
  } else if (isNumberArg(a, i))
    p = static_cast<int>(a[i].number);
  if (!daub(p, h)) {
    ctx.fail("the wavelet must be \"db1\" ... \"db34\" (or the number of vanishing moments 1 ... 34)");
    return false;
  }
  return true;
}

// NumPy's convolve(data, kernel, mode="same") for a kernel no longer than the data
CVec convolveSame(const CVec &x, const CVec &k) {
  size_t n = x.size(), m = k.size(), off = (m - 1) / 2;
  CVec out(n, 0.0);
  for (size_t i = 0; i < n; i++) {
    cd s = 0;
    size_t j = i + off; // index into the full convolution
    for (size_t t = 0; t < m; t++)
      if (j >= t && j - t < n)
        s += x[j - t] * k[t];
    out[i] = s;
  }
  return out;
}

// null vector of a square complex matrix (smallest singular value)
CVec nullVec(const CMat &M) {
  CMat U, V;
  Vec s;
  la::svdThin(M, U, s, V);
  size_t c = V.c - 1;
  CVec v(V.r);
  for (size_t i = 0; i < V.r; i++)
    v[i] = V(i, c);
  // LAPACK's normalization: largest |re| + |im| is 1
  double big = 0;
  for (const cd &z : v)
    big = std::max(big, std::fabs(z.real()) + std::fabs(z.imag()));
  for (cd &z : v)
    z /= big;
  return v;
}
// Boolean dissimilarity of two rows (nonzero = true) from their counts:
// tt = both true, tf = u only, ft = v only.
using BoolMetric = double (*)(double tt, double tf, double ft, double n);
double mismatchFrac(double, double tf, double ft, double n) { return (tf + ft) / n; }
double kulczynski1(double tt, double tf, double ft, double) {
  return tf + ft == 0 ? (tt == 0 ? kNaN : kInf) : tt / (tf + ft);
}

// metric(u, v) for two vectors -> number; for two matrices (one observation
// per row) -> the matrix of all pairs, as cdist gives
Value boolMetric(const Args &a, CallContext &ctx, BoolMetric f) {
  Mat U, V;
  if (!getMat(a, 0, ctx, U) || !getMat(a, 1, ctx, V))
    return Value(0.0);
  bool pairs = a[0].isMatrix && a[1].isMatrix && (U.r > 1 || V.r > 1);
  if (!pairs) {
    Vec u = U.a, v = V.a;
    U = Mat(1, u.size());
    U.a = u;
    V = Mat(1, v.size());
    V.a = v;
  }
  if (U.c != V.c || U.c == 0) {
    ctx.fail("u and v must have the same, non-zero length (the same number of columns)");
    return Value(0.0);
  }
  for (const Mat *m : {&U, &V})
    for (double e : m->a)
      if (std::isnan(e)) {
        ctx.fail("the inputs must not hold NaN");
        return Value(0.0);
      }
  Mat D(U.r, V.r);
  for (size_t i = 0; i < U.r; i++)
    for (size_t j = 0; j < V.r; j++) {
      double tt = 0, tf = 0, ft = 0;
      for (size_t k = 0; k < U.c; k++) {
        bool x = U(i, k) != 0, y = V(j, k) != 0;
        tt += x && y;
        tf += x && !y;
        ft += !x && y;
      }
      D(i, j) = f(tt, tf, ft, double(U.c));
    }
  return pairs ? toValue(D) : Value(D(0, 0));
}
} // namespace

void registerRmFunctions(Registry &reg) {
  SP_ADD("bspline_basis", 2, 2, "knots, x") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    if (t.size() < 2) {
      ctx.fail("needs at least 2 knots");
      return Value(0.0);
    }
    for (size_t i = 1; i < t.size(); i++)
      if (t[i] < t[i - 1]) {
        ctx.fail("the knots must not decrease");
        return Value(0.0);
      }
    if (isPlainNumber(a[1]))
      return Value(bsplineBasis(t, a[1].number));
    Mat x;
    if (!getMat(a, 1, ctx, x))
      return Value(0.0);
    for (double &v : x.a)
      v = bsplineBasis(t, v);
    return a[1].isMatrix && x.r > 1 ? toValue(x) : toValue(x.a);
  } SP_END

  SP_ADD("sort_by_magnitude", 1, 1, "data") {
    CVec z;
    if (!getCVec(a, 0, ctx, z))
      return Value(0.0);
    std::stable_sort(z.begin(), z.end(), [](const cd &p, const cd &q) { return std::abs(p) < std::abs(q); });
    return realIfPossible(z);
  } SP_ENDC

  SP_ADD("ricker_wavelet", 1, 2, "t, a") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    double w = optNum(a, 1, 1.0);
    if (!(w > 0)) {
      ctx.fail("a must be positive");
      return Value(0.0);
    }
    double A = 2 / (std::sqrt(3 * w) * std::pow(kPi, 0.25));
    for (double &x : t)
      x = A * (1 - x * x / (w * w)) * std::exp(-x * x / (2 * w * w));
    return toValue(t);
  } SP_END

  SP_ADD("morlet_wavelet", 1, 3, "t, w, complete") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    double w = optNum(a, 1, 5.0);
    bool complete = optBool(a, 2, true);
    CVec out(t.size());
    for (size_t i = 0; i < t.size(); i++) {
      cd v = std::exp(cd(0, w * t[i]));
      if (complete)
        v -= std::exp(-0.5 * w * w);
      out[i] = v * std::exp(-0.5 * t[i] * t[i]) * std::pow(kPi, -0.25);
    }
    return toValue(out);
  } SP_END

  SP_ADD("morlet2_wavelet", 1, 3, "t, w, s") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    double w = optNum(a, 1, 5.0), s = optNum(a, 2, 1.0);
    if (!(s > 0)) {
      ctx.fail("s must be positive");
      return Value(0.0);
    }
    CVec out(t.size());
    for (size_t i = 0; i < t.size(); i++) {
      double x = t[i] / s;
      out[i] = std::exp(cd(0, w * x)) * std::exp(-0.5 * x * x) * std::pow(kPi, -0.25) * std::sqrt(1 / s);
    }
    return toValue(out);
  } SP_END

  SP_ADD("cwt", 2, 4, "data, widths, wavelet, w") {
    CVec x;
    Vec wd;
    if (!getCVec(a, 0, ctx, x) || !getVec(a, 1, ctx, wd))
      return Value(0.0);
    std::string wv = optText(a, 2, "ricker");
    bool rk = wv == "ricker" || wv == "mexh";
    if (!rk && wv != "morlet2" && wv != "morl") {
      ctx.fail("wavelet must be \"ricker\" (\"mexh\") or \"morlet2\" (\"morl\")");
      return Value(0.0);
    }
    double w0 = optNum(a, 3, 5.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    CMat out(wd.size(), x.size());
    bool real = rk;
    for (const cd &z : x)
      real = real && z.imag() == 0;
    for (size_t r = 0; r < wd.size(); r++) {
      if (!(wd[r] > 0)) {
        ctx.fail("the widths must be positive");
        return Value(0.0);
      }
      size_t N = std::min(static_cast<size_t>(10 * wd[r]), x.size());
      if (N < 1)
        N = 1;
      CVec k = rk ? ricker(N, wd[r]) : morlet2(N, wd[r], w0);
      for (cd &z : k)
        z = std::conj(z);
      std::reverse(k.begin(), k.end());
      CVec row = convolveSame(x, k);
      for (size_t i = 0; i < x.size(); i++)
        out(r, i) = row[i];
    }
    if (real) {
      Mat m(out.r, out.c);
      for (size_t i = 0; i < m.a.size(); i++)
        m.a[i] = out.a[i].real();
      return toValue(m);
    }
    return toValue(out);
  } SP_ENDC

  SP_ADD("wavelet_filters", 1, 1, "name") {
    Vec h;
    if (!waveletName(a, 0, ctx, h))
      return Value(0.0);
    return toValue(h);
  } SP_END

  SP_ADD("qmf", 1, 1, "h") {
    Vec h;
    if (!getVec(a, 0, ctx, h))
      return Value(0.0);
    return toValue(qmfOf(h));
  } SP_END

  SP_ADD("wavelet_function", 1, 2, "name, level") {
    Vec hk;
    if (a[0].isText) {
      if (!waveletName(a, 0, ctx, hk))
        return Value(0.0);
    } else if (!getVec(a, 0, ctx, hk))
      return Value(0.0);
    long long J = optInt(a, 1, 7);
    size_t N = hk.size() - 1;
    if (hk.size() < 2 || J < 1 || double(J) > 30 - std::log2(double(N + 1))) {
      ctx.fail("needs at least 2 filter coefficients and 1 <= level <= 30 - log2(len(h))");
      return Value(0.0);
    }
    Vec gk = qmfOf(hk);
    auto take = [&](const Vec &v, long long i) { return (i < 0 || i > (long long)N) ? 0.0 : v[size_t(i)]; };
    Mat m[2][2];
    for (int p = 0; p < 2; p++)
      for (int q = 0; q < 2; q++) {
        m[p][q] = Mat(N, N);
        for (size_t n = 0; n < N; n++)
          for (size_t k = 0; k < N; k++)
            m[p][q](n, k) = std::sqrt(2.0) * take(p == 0 ? hk : gk, 2 * (long long)n - (long long)k + q);
      }
    auto dot = [&](const Mat &M, const Vec &v) {
      Vec r(M.r, 0.0);
      for (size_t i = 0; i < M.r; i++)
        for (size_t j = 0; j < M.c; j++)
          r[i] += M(i, j) * v[j];
      return r;
    };
    size_t step = size_t(1) << J, len = N * step;
    Vec x(len), phi(len, 0.0), psi(len, 0.0);
    for (size_t i = 0; i < len; i++)
      x[i] = double(i) / step;
    CMat A(N, N);
    for (size_t i = 0; i < N * N; i++)
      A.a[i] = m[0][0].a[i];
    CVec lam;
    CMat V;
    la::eigGeneral(A, lam, &V);
    size_t ind = 0;
    for (size_t i = 1; i < lam.size(); i++)
      if (std::abs(lam[i] - 1.0) < std::abs(lam[ind] - 1.0))
        ind = i;
    Vec v(N);
    double sm = 0;
    for (size_t i = 0; i < N; i++) {
      v[i] = V(i, ind).real();
      sm += v[i];
    }
    if (sm < 0) {
      for (double &e : v)
        e = -e;
      sm = -sm;
    }
    for (double &e : v)
      e /= sm;
    std::map<std::string, Vec> bit;
    bit["0"] = v;
    bit["1"] = dot(m[0][1], v);
    auto put = [&](Vec &dst, size_t start, const Vec &vals) {
      for (size_t i = 0, p = start; i < vals.size() && p < len; i++, p += step)
        dst[p] = vals[i];
    };
    put(phi, 0, bit["0"]);
    put(phi, size_t(1) << (J - 1), bit["1"]);
    put(psi, 0, dot(m[1][0], bit["0"]));
    put(psi, size_t(1) << (J - 1), dot(m[1][1], bit["0"]));
    std::vector<std::string> prev = {"1"};
    for (long long level = 2; level <= J; level++) {
      std::vector<std::string> keys;
      for (char c0 : {'0', '1'})
        for (const std::string &p : prev)
          keys.push_back(std::string(1, c0) + p);
      size_t fac = size_t(1) << (J - level);
      for (const std::string &key : keys) {
        size_t num = 0;
        for (long long pos = 0; pos < level; pos++)
          if (key[pos] == '1')
            num += size_t(1) << (level - 1 - pos);
        const Vec &past = bit[key.substr(1)];
        int ii = key[0] - '0';
        Vec tmp = dot(m[0][ii], past);
        bit[key] = tmp;
        put(phi, num * fac, tmp);
        put(psi, num * fac, dot(m[1][ii], past));
      }
      prev = keys;
    }
    return makeDict({{"x", toValue(x)}, {"phi", toValue(phi)}, {"psi", toValue(psi)}});
  } SP_END

  SP_ADD("unique_counts", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    std::map<double, double> c;
    for (double v : x)
      if (!std::isnan(v))
        c[v]++;
    Vec vals, cnts;
    for (const auto &kv : c) {
      vals.push_back(kv.first);
      cnts.push_back(kv.second);
    }
    return makeDict({{"values", toValue(vals)}, {"counts", toValue(cnts)}});
  } SP_END

  SP_ADD("tri", 1, 3, "n, m, k") {
    long long n, m, k = 0;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    m = n;
    if (a.size() > 1 && !argNonNegativeInt(a, 1, ctx, m))
      return Value(0.0);
    if (a.size() > 2 && !argInt(a, 2, ctx, k))
      return Value(0.0);
    if (n * m > 100000000) {
      ctx.fail("the matrix is too large");
      return Value(0.0);
    }
    Mat t(static_cast<size_t>(n), static_cast<size_t>(m));
    for (long long i = 0; i < n; i++)
      for (long long j = 0; j < m; j++)
        t(size_t(i), size_t(j)) = j <= i + k ? 1.0 : 0.0;
    return toValue(t);
  } SP_END

  SP_ADD("lapack_ggev", 2, 2, "A, B") {
    CMat A, B;
    if (!getCSquare(a, 0, ctx, A) || !getCSquare(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r) {
      ctx.fail("A and B must have the same size");
      return Value(0.0);
    }
    size_t n = A.r;
    CMat AA, BB, Q, Z;
    la::complexQZ(A, B, AA, BB, Q, Z);
    Vec ar(n), ai(n), be(n);
    CMat vl(n, n), vr(n, n);
    for (size_t i = 0; i < n; i++) {
      cd al = AA(i, i), bt = BB(i, i);
      if (std::abs(bt) > 0) { // make beta real and >= 0
        cd ph = std::conj(bt) / std::abs(bt);
        al *= ph;
        bt *= ph;
      }
      ar[i] = al.real();
      ai[i] = al.imag();
      be[i] = bt.real();
      // (beta A - alpha B) v = 0 and its adjoint for the left vector
      CMat M(n, n), Mh(n, n);
      for (size_t r = 0; r < n; r++)
        for (size_t c = 0; c < n; c++) {
          M(r, c) = bt * A(r, c) - al * B(r, c);
          Mh(c, r) = std::conj(M(r, c));
        }
      CVec x = nullVec(M), y = nullVec(Mh);
      for (size_t r = 0; r < n; r++) {
        vr(r, i) = x[r];
        vl(r, i) = y[r];
      }
    }
    return makeDict({{"alphar", toValue(ar)},
                     {"alphai", toValue(ai)},
                     {"beta", toValue(be)},
                     {"vl", realIfPossible(vl)},
                     {"vr", realIfPossible(vr)},
                     {"info", Value(0.0)}});
  } SP_ENDC

  SP_ADD("derivative", 2, 4, "fn, x, initial_step, step_factor") {
    if (!isCallable(a[0])) {
      ctx.fail("fn must name an NC function of x");
      return Value(0.0);
    }
    Vec xs;
    if (!getVec(a, 1, ctx, xs))
      return Value(0.0);
    double h0 = optNum(a, 2, 0.5), fac = optNum(a, 3, 2.0);
    if (!(h0 > 0) || !(fac > 1)) {
      ctx.fail("initial_step must be positive and step_factor greater than 1");
      return Value(0.0);
    }
    NcFn f(a[0]);
    Vec df(xs.size()), er(xs.size()), ok(xs.size()), nit(xs.size()), nfev(xs.size());
    const int ntab = 12;
    for (size_t p = 0; p < xs.size(); p++) {
      // Ridders: central differences extrapolated to step 0 (Neville tableau)
      double x = xs[p], h = h0, best = kNaN, err = kInf;
      std::vector<Vec> T(ntab, Vec(ntab, 0.0));
      long calls0 = f.calls;
      int it = 0;
      T[0][0] = (f.scalar(x + h) - f.scalar(x - h)) / (2 * h);
      for (int i = 1; i < ntab && !f.failed; i++) {
        it = i;
        h /= fac;
        T[0][i] = (f.scalar(x + h) - f.scalar(x - h)) / (2 * h);
        double ff = fac * fac;
        for (int j = 1; j <= i; j++) {
          T[j][i] = (T[j - 1][i] * ff - T[j - 1][i - 1]) / (ff - 1);
          ff *= fac * fac;
          double e = std::max(std::fabs(T[j][i] - T[j - 1][i]), std::fabs(T[j][i] - T[j - 1][i - 1]));
          if (e <= err) {
            err = e;
            best = T[j][i];
          }
        }
        if (std::fabs(T[i][i] - T[i - 1][i - 1]) >= 2 * err)
          break;
      }
      if (f.failed) {
        ctx.fail(f.failText());
        return Value(0.0);
      }
      df[p] = best;
      er[p] = err;
      ok[p] = std::isfinite(best) && err <= std::sqrt(kEps) * (1 + std::fabs(best));
      nit[p] = it;
      nfev[p] = double(f.calls - calls0);
    }
    if (isPlainNumber(a[1]))
      return makeDict({{"df", Value(df[0])}, {"error", Value(er[0])}, {"success", Value(ok[0] != 0)}, {"nit", Value(nit[0])},
                       {"nfev", Value(nfev[0])}});
    return makeDict({{"df", toValue(df)}, {"error", toValue(er)}, {"success", toValue(ok)}, {"nit", toValue(nit)}, {"nfev", toValue(nfev)}});
  } SP_END
  reg.setParallel({"derivative"}, ParallelClass::Interpreter);

  SP_ADD("central_diff_weights", 1, 2, "n, order") {
    long long np_, nd = 1;
    if (!argInt(a, 0, ctx, np_) || (a.size() > 1 && !argInt(a, 1, ctx, nd)))
      return Value(0.0);
    if (np_ % 2 == 0 || np_ < nd + 1 || nd < 0 || np_ > 41) {
      ctx.fail("n must be odd, at most 41 and greater than order");
      return Value(0.0);
    }
    // row `order` of the inverse Vandermonde matrix of -n/2 .. n/2, times order!
    size_t n = static_cast<size_t>(np_);
    Mat X(n, n), Xi;
    long long ho = np_ / 2;
    for (size_t i = 0; i < n; i++)
      for (size_t k = 0; k < n; k++)
        X(i, k) = std::pow(double(static_cast<long long>(i) - ho), double(k));
    if (!la::inverse(X, Xi)) {
      ctx.fail("the weights could not be computed");
      return Value(0.0);
    }
    double f = std::tgamma(double(nd) + 1);
    Vec w(n);
    for (size_t k = 0; k < n; k++)
      w[k] = f * Xi(static_cast<size_t>(nd), k);
    return toValue(w);
  } SP_END

  reg.add(makeSpec("mismatch_frac", SP_SEC, 2, 2, "u, v",
                   [](const Args &a, CallContext &ctx) { return boolMetric(a, ctx, mismatchFrac); }, false));
  reg.add(makeSpec("kulczynski1", SP_SEC, 2, 2, "u, v",
                   [](const Args &a, CallContext &ctx) { return boolMetric(a, ctx, kulczynski1); }, false));

  SP_ADD("help", 0, 1, "name") {
    Registry &r = Registry::instance();
    if (a.empty()) {
      std::cout << "help(name): the inputs and summary of a SciPy function, e.g. help(\"integrate\")\n";
      return Value(std::string());
    }
    std::string n;
    if (!argText(a, 0, ctx, n))
      return Value(0.0);
    const FunctionSpec *s = r.find(n);
    if (!s) {
      ctx.fail("'" + n + "' is not a SciPy function in NC");
      return Value(0.0);
    }
    std::cout << s->signature << "\n";
    if (!s->summary.empty())
      std::cout << "  " << s->summary << "\n";
    if (!s->scipyName.empty())
      std::cout << "  SciPy: " << s->scipyName << "\n";
    return Value(std::string());
  } SP_END
}

} // namespace scipy
} // namespace nc
