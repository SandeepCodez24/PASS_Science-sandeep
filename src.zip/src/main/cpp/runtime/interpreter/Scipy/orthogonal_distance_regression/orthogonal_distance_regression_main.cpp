// Section 12 of 25 - Orthogonal Distance Regression (scipy.odr). All eleven SciPy
// entries become the one function odr_fit(), which lives with the other
// least-squares code (optimization_root_finding/op_lsq.cpp).
#include "orthogonal_distance_regression_main.h"

namespace nc {
namespace scipy {

void registerOdrFit(Registry &reg);

void registerOrthogonalDistanceRegression(Registry &reg) { registerOdrFit(reg); }

} // namespace scipy
} // namespace nc
