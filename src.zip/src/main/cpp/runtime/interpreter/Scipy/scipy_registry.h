// SciPy-equivalent function and constant registry.
//
// Same design as Numpy/numpy_registry.h: every SciPy-style function in NC is
// one FunctionSpec stored here, keyed by its NC name, added by its section's
// register<Section>() (<section>/<section>_main.cpp). scipy_main.cpp calls all
// 25 of those once, at first use. Lookup is by name at run time from
// callBuiltin(), so no lexer or parser change is needed for a function.
//
// scipy.constants is different: its entries are VALUES (speed of light,
// Planck constant, ...), written in NC as a bare name with no parentheses.
// Those go in the constant table (addConstant / findConstant), read through
// nc::scipy::tryConstant() - see scipy_main.h.
#ifndef NC_SCIPY_REGISTRY_H
#define NC_SCIPY_REGISTRY_H

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "../core/value.h"

namespace nc {
namespace scipy {

// The 25 sections from the SciPy literature survey (23 numbered sections plus
// Appendix A as 24 and Appendix B as 25). Planned counts total 2643.
enum class Section {
  Clustering = 0, //  1  scipy.cluster (39)
  Constants, //  2  scipy.constants (164)
  Datasets, //  3  scipy.datasets (5)
  Differentiation, //  4  scipy.differentiate (3)
  FourierTransforms, //  5  scipy.fft (41)
  LegacyFft, //  6  scipy.fftpack (35)
  IntegrationOdes, //  7  scipy.integrate (33)
  Interpolation, //  8  scipy.interpolate (56)
  InputOutput, //  9  scipy.io (34)
  LinearAlgebra, // 10  scipy.linalg (110)
  ImageProcessing, // 11  scipy.ndimage (75)
  OrthogonalDistanceRegression, // 12  scipy.odr (14)
  OptimizationRootFinding, // 13  scipy.optimize (71)
  SignalProcessing, // 14  scipy.signal (158)
  WindowFunctions, // 15  scipy.signal.windows (26)
  SparseMatrices, // 16  scipy.sparse (66)
  SparseLinearAlgebra, // 17  scipy.sparse.linalg (38)
  GraphRoutines, // 18  scipy.sparse.csgraph (26)
  SpatialAlgorithms, // 19  scipy.spatial (52)
  SpecialFunctions, // 20  scipy.special (359)
  Statistics, // 21  scipy.stats (200)
  ProbabilityDistributions, // 22  scipy.stats (131)
  MaskedArrayStatistics, // 23  scipy.stats.mstats (73)
  RemovedSince18, // 24  (various) (60)
  BlasLapackWrappers, // 25  scipy.linalg.blas / lapack (774)
  Count // not a section - the number of sections
};

struct SectionInfo {
  Section section;
  const char *folder;  // folder name under Scipy/
  const char *title;   // human-readable title from the survey
  const char *module;  // SciPy module it covers
  int plannedEntries;  // entry count from the survey
};

// Table of all 25 sections, indexed by static_cast<int>(Section).
const SectionInfo &sectionInfo(Section s);

// Passed to every implementation. Report a problem with fail(): it prints one
// "Error: <function>: <message>" line to stderr and marks the call failed, so
// the statement stops like any other NC runtime error. Return any Value after
// calling fail() - it is discarded.
class CallContext {
public:
  explicit CallContext(const std::string &functionName) : name_(functionName) {}

  void fail(const std::string &message);
  // A failure whose error line was already printed (a builtin called from
  // inside this one reported it): stop without a second line.
  void failSilently() { ok_ = false; }
  bool ok() const { return ok_; }
  const std::string &functionName() const { return name_; }

private:
  const std::string &name_;
  bool ok_ = true;
};

using Impl = std::function<Value(const std::vector<Value> &args, CallContext &ctx)>;

constexpr int kVariadic = -1; // maxArgs value meaning "no upper limit"

// How a function may use threads (docs/Multicore_Multithread_Architecture.md, section 5).
enum class ParallelClass {
  Serial,     // never uses threads (the default)
  Kernel,     // its kernels go through nc::scipy::par (scipy_parallel.h)
  Interpreter // calls back into NC code, so every callback stays on one thread
};

struct FunctionSpec {
  std::string name;       // NC name - lookup is case-insensitive, like builtins
  Section section;        // which folder owns it
  int minArgs = 0;        // checked by the dispatcher before impl runs
  int maxArgs = 0;        // kVariadic for no upper limit
  std::string signature;  // shown in errors/help, e.g. "fft(x[, n])"
  std::string summary;    // one line
  std::string scipyName;  // the SciPy original, e.g. "scipy.fft.fft" (traceability)
  Impl impl;
  // Complex arguments are refused before impl runs unless this is true -
  // same rule callBuiltin() applies to the ops/ builtins. FFT-style sections
  // will set this to true.
  bool acceptsComplex = false;
  ParallelClass par = ParallelClass::Serial;
};

// A named value from scipy.constants, used in NC as a bare name.
struct ConstantSpec {
  std::string name;       // NC name, e.g. "speed_of_light"
  double value = 0.0;
  std::string unit;       // documentation only for now, e.g. "m s^-1"
  std::string scipyName;  // e.g. "scipy.constants.c"
};

// Why a FUNCTION name may not be used (empty string = allowed):
//   - an existing NC builtin from ops/ (sum, mean, det, ...) - existing kept
//   - a NumPy-equivalent function already registered (Numpy/) - NumPy kept,
//     because callBuiltin() consults Numpy before Scipy
//   - an NC keyword, a parser-reserved call, or the logbN family
std::string reservedReason(const std::string &name);

class Registry {
public:
  static Registry &instance();

  // Returns false (and prints why) if the name is reserved or already
  // registered - the first registration wins.
  bool add(FunctionSpec spec);
  const FunctionSpec *find(const std::string &name) const; // case-insensitive
  // Sets the threading class of functions already added; unknown names are ignored.
  void setParallel(const std::vector<std::string> &names, ParallelClass cls);

  // Constants (scipy.constants). Names are case-SENSITIVE, like NC variables
  // (G and g are different constants). Returns false on a duplicate.
  bool addConstant(ConstantSpec spec);
  const ConstantSpec *findConstant(const std::string &name) const;

  bool contains(const std::string &name) const { return find(name) != nullptr; }
  size_t size() const { return functions_.size(); }
  // Every function's name (as registered), unsorted - the IDE's
  // op:"functions" list (docs/Process_Window_CPP.md P3).
  std::vector<std::string> allNames() const {
    std::vector<std::string> out;
    out.reserve(functions_.size());
    for (const auto &kv : functions_)
      out.push_back(kv.second.name);
    return out;
  }
  size_t constantCount() const { return constants_.size(); }

  std::vector<std::string> names(Section s) const;     // one section's functions, sorted

private:
  Registry() = default;
  std::unordered_map<std::string, FunctionSpec> functions_; // key: lowercased name
  std::unordered_map<std::string, ConstantSpec> constants_; // key: exact name
};

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_REGISTRY_H
