// Wires the 25 section folders into one registry and dispatches calls.
//
// Adding a function never touches this file - it goes in its section's
// <section>_main.cpp. This file changes only if a whole new section is added.
#include <unordered_set>
#include <unordered_map>
#include <cmath>
#include "scipy_main.h"

#include <exception>
#include <iostream>
#include <mutex>

#include "scipy_core.h"
#include "scipy_registry.h"

#include "clustering/clustering_main.h"
#include "constants/constants_main.h"
#include "datasets/datasets_main.h"
#include "differentiation/differentiation_main.h"
#include "fourier_transforms/fourier_transforms_main.h"
#include "legacy_fft/legacy_fft_main.h"
#include "integration_odes/integration_odes_main.h"
#include "interpolation/interpolation_main.h"
#include "input_output/input_output_main.h"
#include "linear_algebra/linear_algebra_main.h"
#include "image_processing/image_processing_main.h"
#include "orthogonal_distance_regression/orthogonal_distance_regression_main.h"
#include "optimization_root_finding/optimization_root_finding_main.h"
#include "signal_processing/signal_processing_main.h"
#include "window_functions/window_functions_main.h"
#include "sparse_matrices/sparse_matrices_main.h"
#include "sparse_linear_algebra/sparse_linear_algebra_main.h"
#include "graph_routines/graph_routines_main.h"
#include "spatial_algorithms/spatial_algorithms_main.h"
#include "special_functions/special_functions_main.h"
#include "statistics/statistics_main.h"
#include "probability_distributions/probability_distributions_main.h"
#include "masked_array_statistics/masked_array_statistics_main.h"
#include "removed_since_1_8/removed_since_1_8_main.h"
#include "blas_lapack_wrappers/blas_lapack_wrappers_main.h"

namespace nc {
namespace scipy {

namespace {

void *g_callbackHost = nullptr;
CallbackFn g_callback = nullptr;
InputCountFn g_inputCount = nullptr;

std::string argCountText(int minArgs, int maxArgs) {
  if (maxArgs == kVariadic)
    return "at least " + std::to_string(minArgs);
  if (minArgs == maxArgs)
    return std::to_string(minArgs);
  return std::to_string(minArgs) + " to " + std::to_string(maxArgs);
}

} // namespace

void setCallbackHost(void *host, CallbackFn fn, InputCountFn count) {
  g_callbackHost = host;
  g_callback = fn;
  g_inputCount = count;
}

int functionInputCount(const Value &fn) {
  if (!g_inputCount)
    return -1;
  return g_inputCount(g_callbackHost, fn.isFunctionRef ? fn.funcRefName() : fn.text());
}

bool callNC(const Value &fn, const Args &args, Value &out) {
  if (!g_callback) {
    std::cerr << "Error: NC functions cannot be called from here\n";
    return false;
  }
  if (fn.isFunctionRef)
    return g_callback(g_callbackHost, fn, args, out);
  Value ref;
  ref.isFunctionRef = true;
  ref.funcRefNameMut() = fn.text();
  return g_callback(g_callbackHost, ref, args, out);
}

void initialize() {
  static std::once_flag once;
  std::call_once(once, [] {
    Registry &reg = Registry::instance();
    registerClustering(reg);
    registerConstants(reg);
    registerDatasets(reg);
    registerDifferentiation(reg);
    registerFourierTransforms(reg);
    registerLegacyFft(reg);
    registerIntegrationOdes(reg);
    registerInterpolation(reg);
    registerInputOutput(reg);
    registerLinearAlgebra(reg);
    registerImageProcessing(reg);
    registerOrthogonalDistanceRegression(reg);
    registerOptimizationRootFinding(reg);
    registerSignalProcessing(reg);
    registerWindowFunctions(reg);
    registerSparseMatrices(reg);
    registerSparseLinearAlgebra(reg);
    registerGraphRoutines(reg);
    registerSpatialAlgorithms(reg);
    registerSpecialFunctions(reg);
    registerStatistics(reg);
    registerProbabilityDistributions(reg);
    registerMaskedArrayStatistics(reg);
    registerRemovedSince18(reg);
    registerBlasLapackWrappers(reg);
  });
}

bool isScipyFunction(const std::string &name) {
  initialize();
  return Registry::instance().contains(name);
}

bool tryConstant(const std::string &name, double &out) {
  initialize();
  const ConstantSpec *c = Registry::instance().findConstant(name);
  if (!c)
    return false;
  out = c->value;
  return true;
}

bool tryCall(const std::string &name, const std::vector<Value> &args, Value &out, bool &ok) {
  initialize();

  const FunctionSpec *spec = Registry::instance().find(name);
  if (!spec)
    return false;

  ok = true;
  out = Value(0.0);

  int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kVariadic && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects "
              << argCountText(spec->minArgs, spec->maxArgs) << " argument(s), got " << argc;
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }

  if (!spec->acceptsComplex) {
    for (const Value &a : args) {
      if (a.hasComplex()) {
        std::cerr << "Error: '" << spec->name << "' does not support complex numbers yet\n";
        ok = false;
        return true;
      }
    }
  }

  // Empty inputs: most functions index into their data, so a 0 x 0 input stops here.
  static const std::unordered_set<std::string> kEmptyOk = {
      "abcd_normalize",
      "bilinear_zpk",
      "censored_data",
      "dataset_clear_cache",
      "freqs_zpk",
      "freqz_zpk",
      "invres",
      "invresz",
      "lp2bp_zpk",
      "lp2bs_zpk",
      "lp2hp_zpk",
      "lp2lp_zpk",
      "lti_system",
      "sparse_bsr",
      "sparse_coo",
      "sparse_csc",
      "sparse_csr",
      "sparse_dia",
      "sparse_dok",
      "sparse_lil",
      "sparse_matrix",
      "zpk2sos",
      "zpk2ss",
      "zpk2tf",
      "zpk_system"};
  if (!kEmptyOk.count(spec->name)) {
    for (size_t i = 0; i < args.size(); i++) {
      const Value &a = args[i];
      if ((a.isArray && a.length() == 0) || (a.isMatrix && !a.isND() && (a.rows() == 0 || a.cols() == 0))) {
        std::cerr << "Error: " << spec->name << ": the " << ordinal(i) << " argument must not be empty\n";
        ok = false;
        return true;
      }
    }
  }
  // Counts and sizes: a whole number from 0 to kMaxCount.
  static const std::unordered_map<std::string, std::vector<size_t>> kCountArgs = {
      {"fftfreq", {0}}, {"rfftfreq", {0}}, {"rfftfreq_packed", {0}}, {"czt_points", {0}}, {"unit_impulse", {0}}, {"sparse_eye", {0, 1}},
      {"rot_random", {0}}, {"rot_identity", {0}}, {"butter_proto", {0}}, {"cheby1_proto", {0}}, {"cheby2_proto", {0}}, {"ellip_proto", {0}},
      {"bessel_proto", {0}}, {"butter", {0}}, {"cheby1", {0}}, {"cheby2", {0}}, {"ellip", {0}}, {"bessel", {0}}, {"iir_filter", {0}},
      {"firwin", {0}}, {"firwin2", {0}}, {"firls", {0}}, {"remez", {0}}, {"get_window", {1}}, {"max_len_seq", {2}}, {"savgol_coeffs", {0}},
      {"rand_rotation", {0}}, {"rand_orthogonal", {0}}, {"rand_unitary", {0}}, {"rand_direction", {0}}, {"tri", {0, 1}},
      {"sobol_sample", {0, 1}}, {"halton_sample", {0, 1}}, {"latin_hypercube", {0, 1}}, {"central_diff_weights", {0, 1}}};
  constexpr double kMaxCount = 1e7;
  auto countBad = [](const Value &v) { return isPlainNumber(v) && !v.isComplex && (!(v.number >= 0.0) || v.number > kMaxCount || v.number != std::floor(v.number)); };
  std::vector<size_t> counts;
  if (spec->name.size() > 4 && spec->name.compare(spec->name.size() - 4, 4, "_win") == 0)
    counts = {0};
  else if (kCountArgs.count(spec->name))
    counts = kCountArgs.at(spec->name);
  for (size_t i : counts)
    if (i < args.size() && countBad(args[i])) {
      std::cerr << "Error: " << spec->name << ": the " << ordinal(i) << " argument must be a whole number from 0 to 10000000\n";
      ok = false;
      return true;
    }

  CallContext ctx(spec->name);
  Value result;
  try {
    result = spec->impl(args, ctx);
  } catch (const std::exception &e) {
    ctx.fail(std::string("internal error: ") + e.what());
  } catch (...) {
    ctx.fail("internal error");
  }

  if (!ctx.ok()) {
    ok = false;
    return true;
  }
  out = std::move(result);
  return true;
}

} // namespace scipy
} // namespace nc
