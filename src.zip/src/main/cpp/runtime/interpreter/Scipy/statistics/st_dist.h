// Section 21: distribution values (normal_dist(0, 1), make_dist("gamma", ...),
// custom_dist("bell"), mixture_dist(...), ...). In NC a distribution is a Dict
// whose "dist" field names its kind; readDist() turns it back into a Dist with
// pdf / cdf / ppf / moments / sampling, used by the dist_* functions and by
// the samplers. A custom distribution calls an NC function, so everything
// built on Dist runs on the interpreter thread.
#ifndef NC_SCIPY_ST_DIST_H
#define NC_SCIPY_ST_DIST_H

#include <memory>
#include <random>

#include "st_common.h"

namespace nc {
namespace scipy {
namespace st {

struct Dist {
  bool discrete = false;
  virtual ~Dist() = default;
  virtual double pdf(double x) const = 0; // pmf for a discrete distribution
  virtual double cdf(double x) const = 0;
  virtual double sf(double x) const { return 1 - cdf(x); }
  virtual double ppf(double q) const;
  virtual void support(double &a, double &b) const = 0;
  virtual double mean() const;
  virtual double var() const;
  virtual double rvs(std::mt19937_64 &g) const { return ppf(pd::uniform01(g)); }
  // An NC callback inside failed (its error has been printed).
  virtual bool failed() const { return false; }
};
using DistPtr = std::shared_ptr<const Dist>;

// A distribution Dict, or the name of a family without shape parameters ("norm").
DistPtr readDist(const Value &v, CallContext &ctx);
// The Dict of a family distribution.
Value familyDistValue(const std::string &name, const Vec &shapes, double loc, double scale);

} // namespace st
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_ST_DIST_H
