// Section 21: k-sample tests (ANOVA and its robust relatives, Tukey HSD,
// Dunnett, Kruskal-Wallis, Friedman, Page, k-sample Anderson-Darling),
// goodness-of-fit tests (KS, Cramer-von Mises, Monte Carlo), survival
// (log-rank), contingency tables and the combination of p-values.
#include "st_common.h"
#include "statistics_main.h"

#include <random>

#include "../../ops/matrix/matrix.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace st {
double chi2Table(const Mat &t, bool correction, double &dof, Mat &expected);
}

namespace {
using namespace st;

Value sp(double s, double p) { return makeDict({{"statistic", Value(s)}, {"pvalue", Value(p)}}); }
double chi2sf(double x, double df) { return sf::chdtrc(df, x); }

// cdf given as a family name ("norm"), as "norm_cdf", or as an NC function name.
struct CdfRef {
  const pd::Family *fam = nullptr;
  Vec shapes;
  Value fn;
  bool viaNC = false;
  bool resolve(const Args &a, size_t i, CallContext &ctx) {
    if (i >= a.size() || !isCallable(a[i])) {
      ctx.fail("the " + ordinal(i) + " argument must name a distribution (\"norm\") or a cdf function (\"norm_cdf\")");
      return false;
    }
    std::string n = a[i].isText ? a[i].text() : a[i].funcRefName();
    (void)ctx;
    std::string base = n.size() > 4 && n.compare(n.size() - 4, 4, "_cdf") == 0 ? n.substr(0, n.size() - 4) : n;
    fam = pd::findFamily(base);
    if (fam) {
      shapes.assign(fam->nshape, 0.0);
      for (int k = 0; k < fam->nshape; k++) {
        if (!isNumberArg(a, i + 1 + k)) {
          ctx.fail("give the " + std::to_string(fam->nshape) + " shape parameter(s) of '" + base + "' after its name");
          return false;
        }
        shapes[k] = a[i + 1 + k].number;
      }
      return true;
    }
    fn = a[i];
    viaNC = true;
    return true;
  }
  double operator()(double x, bool &failed) {
    if (fam)
      return pd::cdf(*fam, x, shapes.data());
    NcFn f(fn);
    double v = f.scalar(x);
    failed = failed || f.failed;
    return v;
  }
};

double cvmLimitCdf(double x) {
  double tot = 0;
  for (int k = 0; k < 200; k++) {
    double y = 4 * k + 1, q = y * y / (16 * x);
    double term = std::exp(std::lgamma(k + 0.5) - std::lgamma(k + 1.0)) / (std::pow(kPi, 1.5) * std::sqrt(x)) * std::sqrt(y) *
                  std::exp(-q) * sf::besselk(0.25, q);
    tot += term;
    if (std::fabs(term) < 1e-7)
      break;
  }
  return tot;
}
double psi1Mod(double x) {
  auto ed2 = [](double y) {
    double z = y * y / 4;
    return std::exp(-z) * std::pow(y / 2, 1.5) * (sf::besselk(0.25, z) + sf::besselk(0.75, z)) / std::sqrt(kPi);
  };
  auto ed3 = [](double y) {
    double z = y * y / 4;
    return std::exp(-z) / std::sqrt(kPi) * std::pow(y / 2, 2.5) *
           (2 * sf::besselk(0.25, z) + 3 * sf::besselk(0.75, z) - sf::besselk(1.25, z));
  };
  double tot = 0;
  for (int k = 0; k < 200; k++) {
    double m = 2 * k + 1, sx = 2 * std::sqrt(x), y1 = std::pow(x, 0.75), y2 = std::pow(x, 1.25);
    double g1 = std::tgamma(k + 0.5), g3 = std::tgamma(k + 1.5);
    double A = m * g1 * ed2((4 * k + 3) / sx) / (9 * y1) + g1 * ed3((4 * k + 1) / sx) / (72 * y2) +
               2 * (m + 2) * g3 * ed3((4 * k + 5) / sx) / (12 * y2) + 7 * m * g1 * ed2((4 * k + 1) / sx) / (144 * y1) +
               7 * m * g1 * ed2((4 * k + 5) / sx) / (144 * y1);
    double z = -A / (kPi * std::tgamma(k + 1.0));
    tot += z;
    if (std::fabs(z) < 1e-7)
      break;
  }
  return tot;
}
double cvmCdf(double x, double n) {
  if (x <= 1.0 / (12 * n))
    return 0.0;
  if (x >= n / 3.0)
    return 1.0;
  return cvmLimitCdf(x) * (1 + 1.0 / (12 * n)) + psi1Mod(x) / n;
}

// Least-squares quadratic through (x, y), as NumPy's polyfit(x, y, 2).
void quadFit(const Vec &x, const Vec &y, double &c2, double &c1, double &c0) {
  double S[5] = {0, 0, 0, 0, 0}, T[3] = {0, 0, 0};
  for (size_t i = 0; i < x.size(); i++) {
    double p = 1;
    for (int k = 0; k < 5; k++) {
      S[k] += p;
      if (k < 3)
        T[k] += p * y[i];
      p *= x[i];
    }
  }
  // solve [[S4 S3 S2][S3 S2 S1][S2 S1 S0]] [c2 c1 c0] = [T2 T1 T0]
  double M[3][4] = {{S[4], S[3], S[2], T[2]}, {S[3], S[2], S[1], T[1]}, {S[2], S[1], S[0], T[0]}};
  for (int c = 0; c < 3; c++) {
    int piv = c;
    for (int r = c + 1; r < 3; r++)
      if (std::fabs(M[r][c]) > std::fabs(M[piv][c]))
        piv = r;
    for (int k = 0; k < 4; k++)
      std::swap(M[c][k], M[piv][k]);
    for (int r = 0; r < 3; r++)
      if (r != c) {
        double f = M[r][c] / M[c][c];
        for (int k = 0; k < 4; k++)
          M[r][k] -= f * M[c][k];
      }
  }
  c2 = M[0][3] / M[0][0];
  c1 = M[1][3] / M[1][1];
  c0 = M[2][3] / M[2][2];
}

double mse(const std::vector<Vec> &g, double &df) {
  double N = 0, s = 0;
  for (const Vec &x : g) {
    N += x.size();
    s += (x.size() - 1) * var(x);
  }
  df = N - g.size();
  return s / df;
}

// P(max_j |Z_j| < c s) for the Dunnett one-factor correlation structure.
double dunnettCdf(double c, const Vec &lam, double df) {
  auto inner = [&](double s) {
    return sf::quad([&](double z) {
      double prod = std::exp(-z * z / 2) / std::sqrt(2 * kPi);
      for (double l : lam) {
        double r = std::sqrt(1 - l * l);
        prod *= sf::ndtr((c * s - l * z) / r) - sf::ndtr((-c * s - l * z) / r);
      }
      return prod;
    }, -9.0, 9.0, 0.0, 1e-11, 400);
  };
  if (std::isinf(df))
    return inner(1.0);
  double sd = 1 / std::sqrt(df);
  auto fs = [&](double s) {
    return std::exp(df / 2 * std::log(df) - std::lgamma(df / 2) - (df / 2 - 1) * std::log(2.0) + (df - 1) * std::log(s) - df * s * s / 2);
  };
  return sf::quad([&](double s) { return s <= 0 ? 0.0 : fs(s) * inner(s); }, std::max(0.0, 1 - 12 * sd), 1 + 12 * sd, 0.0, 1e-10, 400);
}

double adStat(Vec u) {
  std::sort(u.begin(), u.end());
  double n = u.size(), a = -n;
  for (size_t i = 0; i < u.size(); i++) {
    double c = std::min(std::max(u[i], 1e-300), 1 - 1e-16), d = std::min(std::max(u[u.size() - 1 - i], 1e-300), 1 - 1e-16);
    a -= (2.0 * (i + 1) - 1) / n * (std::log(c) + std::log1p(-d));
  }
  return a;
}
} // namespace

void registerStKsample(Registry &reg) {
  SP_ADD("anova_oneway", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    double N = 0, gm = 0;
    for (const Vec &x : g) {
      N += x.size();
      for (double v : x)
        gm += v;
    }
    gm /= N;
    double ssb = 0, ssw = 0, k = g.size();
    for (const Vec &x : g) {
      double m = mean(x);
      ssb += x.size() * (m - gm) * (m - gm);
      for (double v : x)
        ssw += (v - m) * (v - m);
    }
    double F = (ssb / (k - 1)) / (ssw / (N - k));
    return sp(F, sf::fdtrc(k - 1, N - k, F));
  } SP_END

  SP_ADD("tukey_hsd", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    double df, ms = mse(g, df);
    size_t k = g.size();
    Mat S(k, k), P(k, k);
    const pd::Family *sr = pd::findFamily("studentized_range");
    for (size_t i = 0; i < k; i++)
      for (size_t j = 0; j < k; j++) {
        S(i, j) = mean(g[i]) - mean(g[j]);
        if (i == j) {
          P(i, j) = 1;
          continue;
        }
        double q = std::fabs(S(i, j)) / std::sqrt(ms / 2 * (1.0 / g[i].size() + 1.0 / g[j].size()));
        double pr[2] = {double(k), df};
        P(i, j) = pd::sf(*sr, q, pr);
      }
    return makeDict({{"statistic", toValue(S)}, {"pvalue", toValue(P)}});
  } SP_END

  SP_ADD("dunnett", 2, kVariadic, "groups..., control") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    Vec ctrl = g.back();
    g.pop_back();
    std::vector<Vec> all(g);
    all.push_back(ctrl);
    double df, ms = mse(all, df), nc = ctrl.size();
    Vec t(g.size()), lam(g.size()), p(g.size());
    for (size_t i = 0; i < g.size(); i++) {
      double ni = g[i].size();
      t[i] = (mean(g[i]) - mean(ctrl)) / std::sqrt(ms * (1 / ni + 1 / nc));
      lam[i] = std::sqrt(ni / (ni + nc));
    }
    for (size_t i = 0; i < g.size(); i++)
      p[i] = std::min(1.0, std::max(0.0, 1 - dunnettCdf(std::fabs(t[i]), lam, df)));
    return makeDict({{"statistic", toValue(t)}, {"pvalue", toValue(p)}});
  } SP_END

  SP_ADD("kruskal", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    Vec all;
    for (const Vec &x : g)
      all.insert(all.end(), x.begin(), x.end());
    Vec r = rankdata(all);
    double N = all.size(), h = 0;
    size_t off = 0;
    for (const Vec &x : g) {
      double s = 0;
      for (size_t i = 0; i < x.size(); i++)
        s += r[off + i];
      off += x.size();
      h += s * s / x.size();
    }
    h = 12.0 / (N * (N + 1)) * h - 3 * (N + 1);
    double tc = tieCorrect(r);
    if (tc == 0) {
      ctx.fail("all values are equal");
      return Value(0.0);
    }
    h /= tc;
    return sp(h, chi2sf(h, g.size() - 1.0));
  } SP_END

  SP_ADD("alexander_govern", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    size_t k = g.size();
    Vec se(k), w(k), m(k);
    double sw = 0;
    for (size_t i = 0; i < k; i++) {
      if (g[i].size() < 2) {
        ctx.fail("every group needs at least 2 values");
        return Value(0.0);
      }
      m[i] = mean(g[i]);
      se[i] = std::sqrt(var(g[i]) / g[i].size());
      w[i] = 1 / (se[i] * se[i]);
      sw += w[i];
    }
    double xw = 0;
    for (size_t i = 0; i < k; i++)
      xw += w[i] / sw * m[i];
    double A = 0;
    for (size_t i = 0; i < k; i++) {
      double t = (m[i] - xw) / se[i], v = g[i].size() - 1.0;
      double aa = v - 0.5, b = 48 * aa * aa, c = std::sqrt(aa * std::log1p(t * t / v));
      double z = c + (c * c * c + 3 * c) / b -
                 (4 * std::pow(c, 7) + 33 * std::pow(c, 5) + 240 * c * c * c + 855 * c) / (10 * b * b + 8 * b * std::pow(c, 4) + 1000 * b);
      A += z * z;
    }
    return sp(A, chi2sf(A, k - 1.0));
  } SP_END

  SP_ADD("fligner", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    Vec all;
    for (const Vec &x : g) {
      double md = median(x);
      for (double v : x)
        all.push_back(std::fabs(v - md));
    }
    Vec r = rankdata(all);
    double N = all.size();
    Vec as(r.size());
    for (size_t i = 0; i < r.size(); i++)
      as[i] = sf::ndtri(r[i] / (2 * (N + 1)) + 0.5);
    double abar = mean(as), stat = 0;
    size_t off = 0;
    for (const Vec &x : g) {
      double s = 0;
      for (size_t i = 0; i < x.size(); i++)
        s += as[off + i];
      off += x.size();
      double ai = s / x.size();
      stat += x.size() * (ai - abar) * (ai - abar);
    }
    stat /= var(as, 1);
    return sp(stat, chi2sf(stat, g.size() - 1.0));
  } SP_END

  SP_ADD("levene", 1, kVariadic, "groups..., center") {
    std::string center = "median";
    Args b(a);
    if (!b.empty() && b.back().isText) {
      center = b.back().text();
      b.pop_back();
    }
    if (center != "median" && center != "mean" && center != "trimmed") {
      ctx.fail("center must be \"median\", \"mean\" or \"trimmed\"");
      return Value(0.0);
    }
    std::vector<Vec> g;
    if (!readGroups(b, 0, ctx, g))
      return Value(0.0);
    double N = 0, k = g.size();
    std::vector<Vec> Z;
    for (const Vec &x : g) {
      double c;
      if (center == "median")
        c = median(x);
      else if (center == "mean")
        c = mean(x);
      else {
        Vec s = sorted(x);
        size_t cut = static_cast<size_t>(0.05 * s.size());
        c = mean(Vec(s.begin() + cut, s.end() - cut));
      }
      Vec z(x.size());
      for (size_t i = 0; i < x.size(); i++)
        z[i] = std::fabs(x[i] - c);
      Z.push_back(z);
      N += x.size();
    }
    double zbar = 0;
    for (const Vec &z : Z)
      for (double v : z)
        zbar += v;
    zbar /= N;
    double num = 0, den = 0;
    for (const Vec &z : Z) {
      double zi = mean(z);
      num += z.size() * (zi - zbar) * (zi - zbar);
      for (double v : z)
        den += (v - zi) * (v - zi);
    }
    double W = (N - k) / (k - 1) * num / den;
    return sp(W, sf::fdtrc(k - 1, N - k, W));
  } SP_END

  SP_ADD("bartlett", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    double N = 0, k = g.size(), spv = 0, sl = 0, sinv = 0;
    for (const Vec &x : g) {
      double n = x.size(), v = var(x);
      N += n;
      spv += (n - 1) * v;
      sl += (n - 1) * std::log(v);
      sinv += 1 / (n - 1);
    }
    spv /= (N - k);
    double num = (N - k) * std::log(spv) - sl, den = 1 + 1 / (3 * (k - 1)) * (sinv - 1 / (N - k));
    double T = num / den;
    return sp(T, chi2sf(T, k - 1));
  } SP_END

  SP_ADD("median_test", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g))
      return Value(0.0);
    Vec all;
    for (const Vec &x : g)
      all.insert(all.end(), x.begin(), x.end());
    double gm = median(all);
    Mat t(2, g.size());
    for (size_t j = 0; j < g.size(); j++)
      for (double v : g[j])
        t(v > gm ? 0 : 1, j) += 1;
    double dof;
    Mat e;
    double s = chi2Table(t, true, dof, e);
    return makeDict({{"statistic", Value(s)}, {"pvalue", Value(chi2sf(s, dof))}, {"median", Value(gm)}, {"table", toValue(t)}});
  } SP_END

  SP_ADD("friedman", 3, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g, 3))
      return Value(0.0);
    size_t n = g[0].size(), k = g.size();
    for (const Vec &x : g)
      if (x.size() != n) {
        ctx.fail("all groups must have the same length");
        return Value(0.0);
      }
    Vec R(k, 0.0);
    double ties = 0;
    for (size_t i = 0; i < n; i++) {
      Vec row(k);
      for (size_t j = 0; j < k; j++)
        row[j] = g[j][i];
      Vec r = rankdata(row);
      for (size_t j = 0; j < k; j++)
        R[j] += r[j];
      for (double t : tieCounts(row))
        if (t > 1)
          ties += t * (t * t - 1);
    }
    double c = 1 - ties / (k * (k * k - 1.0) * n), ss = 0;
    for (double v : R)
      ss += v * v;
    double chi = (12.0 / (k * n * (k + 1.0)) * ss - 3.0 * n * (k + 1)) / c;
    return sp(chi, chi2sf(chi, k - 1.0));
  } SP_END

  SP_ADD("anderson_ksamp", 1, kVariadic, "samples, midrank") {
    Args b(a);
    bool midrank = true;
    if (b.size() > 1 && isPlainNumber(b.back())) {
      midrank = b.back().number != 0;
      b.pop_back();
    }
    std::vector<Vec> g;
    if (!readGroups(b, 0, ctx, g))
      return Value(0.0);
    Vec Z;
    for (const Vec &x : g)
      Z.insert(Z.end(), x.begin(), x.end());
    std::sort(Z.begin(), Z.end());
    Vec Zs(Z);
    Zs.erase(std::unique(Zs.begin(), Zs.end()), Zs.end());
    double N = Z.size(), k = g.size(), A2 = 0;
    if (Zs.size() < 2) {
      ctx.fail("needs more than one distinct value");
      return Value(0.0);
    }
    if (midrank) {
      for (const Vec &x : g) {
        Vec s = sorted(x);
        double ni = s.size(), part = 0;
        for (double z : Zs) {
          double left = double(std::lower_bound(Z.begin(), Z.end(), z) - Z.begin());
          double lj = double(std::upper_bound(Z.begin(), Z.end(), z) - Z.begin()) - left;
          double Bj = left + lj / 2;
          double right = double(std::upper_bound(s.begin(), s.end(), z) - s.begin());
          double fij = right - double(std::lower_bound(s.begin(), s.end(), z) - s.begin());
          double Mij = right - fij / 2;
          part += lj / N * std::pow(N * Mij - Bj * ni, 2) / (Bj * (N - Bj) - N * lj / 4);
        }
        A2 += part / ni;
      }
      A2 *= (N - 1) / N;
    } else {
      for (const Vec &x : g) {
        Vec s = sorted(x);
        double ni = s.size(), part = 0;
        for (size_t zi = 0; zi + 1 < Zs.size(); zi++) {
          double z = Zs[zi];
          double lj = double(std::upper_bound(Z.begin(), Z.end(), z) - std::lower_bound(Z.begin(), Z.end(), z));
          double Bj = double(std::upper_bound(Z.begin(), Z.end(), z) - Z.begin());
          double Mij = double(std::upper_bound(s.begin(), s.end(), z) - s.begin());
          part += lj / N * std::pow(N * Mij - Bj * ni, 2) / (Bj * (N - Bj));
        }
        A2 += part / ni;
      }
    }
    double H = 0;
    for (const Vec &x : g)
      H += 1.0 / x.size();
    double hcs = 0, gsum = 0, cum = 0;
    for (double j = N - 1; j > 1; j--) {
      cum += 1 / j;
      // g = sum over i of (cumulative sum up to i) / (i + 2)
    }
    hcs = cum;
    cum = 0;
    {
      Vec cs;
      for (double j = N - 1; j > 1; j--) {
        cum += 1 / j;
        cs.push_back(cum);
      }
      for (size_t i = 0; i < cs.size(); i++)
        gsum += cs[i] / (i + 2.0);
    }
    double h = hcs + 1, gg = gsum;
    double aa = (4 * gg - 6) * (k - 1) + (10 - 6 * gg) * H;
    double bb = (2 * gg - 4) * k * k + 8 * h * k + (2 * gg - 14 * h - 4) * H - 8 * h + 4 * gg - 6;
    double cc = (6 * h + 2 * gg - 2) * k * k + (4 * h - 4 * gg + 6) * k + (2 * h - 6) * H + 4 * h;
    double dd = (2 * h + 6) * k * k - 4 * h * k;
    double sigmasq = (aa * N * N * N + bb * N * N + cc * N + dd) / ((N - 1) * (N - 2) * (N - 3));
    double m = k - 1, A2s = (A2 - m) / std::sqrt(sigmasq);
    const double b0[7] = {0.675, 1.281, 1.645, 1.96, 2.326, 2.573, 3.085};
    const double b1[7] = {-0.245, 0.25, 0.678, 1.149, 1.822, 2.364, 3.615};
    const double b2[7] = {-0.105, -0.305, -0.362, -0.391, -0.396, -0.345, -0.154};
    const double sig[7] = {0.25, 0.1, 0.05, 0.025, 0.01, 0.005, 0.001};
    Vec crit(7), ls(7);
    for (int i = 0; i < 7; i++) {
      crit[i] = b0[i] + b1[i] / std::sqrt(m) + b2[i] / m;
      ls[i] = std::log(sig[i]);
    }
    double p;
    if (A2s < crit[0])
      p = 0.25;
    else if (A2s > crit[6])
      p = 0.001;
    else {
      double c2, c1, c0;
      quadFit(crit, ls, c2, c1, c0);
      p = std::exp((c2 * A2s + c1) * A2s + c0);
    }
    return makeDict({{"statistic", Value(A2s)}, {"critical_values", toValue(crit)}, {"pvalue", Value(p)}});
  } SP_END

  SP_ADD("page_trend_test", 1, 2, "data, method") {
    Mat d;
    if (!getMat(a, 0, ctx, d))
      return Value(0.0);
    size_t n = d.r, k = d.c;
    if (n < 1 || k < 3) {
      ctx.fail("needs at least 3 treatments (columns)");
      return Value(0.0);
    }
    double L = 0;
    for (size_t i = 0; i < n; i++) {
      Vec r = rankdata(Vec(d.row(i), d.row(i) + k));
      for (size_t j = 0; j < k; j++)
        L += (j + 1.0) * r[j];
    }
    std::string method = optText(a, 1, "auto");
    if (method == "auto")
      method = (k <= 8 && n <= 100) ? "exact" : "asymptotic";
    double p;
    if (method == "exact") {
      // distribution of sum_j j * pi_j over permutations, convolved over the rows
      std::vector<int> perm(k);
      std::iota(perm.begin(), perm.end(), 1);
      int lo = 0, hi = 0;
      for (size_t j = 0; j < k; j++) {
        lo += int(j + 1) * int(k - j);
        hi += int(j + 1) * int(j + 1);
      }
      Vec one(hi - lo + 1, 0.0);
      double cnt = 0;
      do {
        int s = 0;
        for (size_t j = 0; j < k; j++)
          s += int(j + 1) * perm[j];
        one[s - lo] += 1;
        cnt++;
      } while (std::next_permutation(perm.begin(), perm.end()));
      for (double &v : one)
        v /= cnt;
      Vec dist = {1.0};
      for (size_t i = 0; i < n; i++) {
        Vec nd(dist.size() + one.size() - 1, 0.0);
        for (size_t x = 0; x < dist.size(); x++)
          for (size_t y = 0; y < one.size(); y++)
            nd[x + y] += dist[x] * one[y];
        dist = nd;
      }
      double base = n * lo, s = 0;
      for (size_t x = 0; x < dist.size(); x++)
        if (base + x >= L - 1e-9)
          s += dist[x];
      p = std::min(1.0, s);
    } else {
      double E = n * k * (k + 1.0) * (k + 1.0) / 4, V = n * k * k * (k + 1.0) * (k * k - 1.0) / 144;
      p = sf::ndtr(-(L - E) / std::sqrt(V));
    }
    return makeDict({{"statistic", Value(L)}, {"pvalue", Value(p)}, {"method", Value(method)}});
  } SP_END

  SP_ADD("logrank", 2, 3, "x, y, alternative") {
    auto read = [&](size_t i, Vec &ev, Vec &cen) {
      const Value &v = a[i];
      if (v.isDict) {
        const Value *u = dictGet(v, "uncensored"), *r = dictGet(v, "right");
        if (!u || !readVec(*u, ev)) {
          ctx.fail("the censored data needs an 'uncensored' array");
          return false;
        }
        if (r)
          readVec(*r, cen);
        return true;
      }
      if (!getVec(a, i, ctx, ev))
        return false;
      return true;
    };
    Vec ex, cx, ey, cy;
    if (!read(0, ex, cx) || !read(1, ey, cy))
      return Value(0.0);
    std::string alt = optText(a, 2, "two-sided");
    Vec times(ex);
    times.insert(times.end(), ey.begin(), ey.end());
    std::sort(times.begin(), times.end());
    times.erase(std::unique(times.begin(), times.end()), times.end());
    auto atRisk = [](const Vec &e, const Vec &c, double t) {
      double n = 0;
      for (double v : e)
        n += v >= t;
      for (double v : c)
        n += v >= t;
      return n;
    };
    auto events = [](const Vec &e, double t) {
      double n = 0;
      for (double v : e)
        n += v == t;
      return n;
    };
    double U = 0, V = 0;
    for (double t : times) {
      double n1 = atRisk(ex, cx, t), n2 = atRisk(ey, cy, t), d1 = events(ex, t), d2 = events(ey, t);
      double n = n1 + n2, d = d1 + d2;
      if (n < 1)
        continue;
      U += d1 - d * n1 / n;
      if (n > 1)
        V += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1);
    }
    double z = U / std::sqrt(V);
    return sp(z, normP(z, alt == "two-sided" ? alt : (alt == "less" ? "greater" : "less")));
  } SP_END

  // ---- contingency tables ----
  auto chi2c = [](const Args &a, CallContext &ctx) -> Value {
    Mat t;
    if (!getMat(a, 0, ctx, t))
      return Value(0.0);
    for (double v : t.a)
      if (v < 0) {
        ctx.fail("the table must not hold negative counts");
        return Value(0.0);
      }
    double dof;
    Mat e;
    double s = chi2Table(t, optBool(a, 1, true), dof, e);
    for (double v : e.a)
      if (v == 0) {
        ctx.fail("the table has a zero expected count");
        return Value(0.0);
      }
    double p = dof == 0 ? 1.0 : chi2sf(s, dof);
    if (dof == 0)
      s = 0;
    return makeDict({{"statistic", Value(s)}, {"pvalue", Value(p)}, {"dof", Value(dof)}, {"expected", toValue(e)}});
  };
  reg.add(makeSpec("chi2_contingency", SP_SEC, 1, 2, "table, correction", chi2c, false));

  SP_ADD("power_divergence", 1, 3, "observed, expected, lambda") {
    Vec o, e;
    if (!getVec(a, 0, ctx, o))
      return Value(0.0);
    if (a.size() > 1 && !isOmitted(a, 1)) {
      if (!getVec(a, 1, ctx, e))
        return Value(0.0);
    } else {
      e.assign(o.size(), mean(o));
    }
    if (e.size() != o.size()) {
      ctx.fail("observed and expected must have the same length");
      return Value(0.0);
    }
    double lam = 1;
    if (a.size() > 2) {
      if (a[2].isText) {
        std::string n = a[2].text();
        if (n == "pearson")
          lam = 1;
        else if (n == "log-likelihood")
          lam = 0;
        else if (n == "freeman-tukey")
          lam = -0.5;
        else if (n == "mod-log-likelihood")
          lam = -1;
        else if (n == "neyman")
          lam = -2;
        else if (n == "cressie-read")
          lam = 2.0 / 3;
        else {
          ctx.fail("unknown lambda name '" + n + "'");
          return Value(0.0);
        }
      } else
        lam = optNum(a, 2, 1);
    }
    double s = 0;
    for (size_t i = 0; i < o.size(); i++) {
      if (lam == 0)
        s += 2 * (o[i] == 0 ? 0.0 : o[i] * std::log(o[i] / e[i]));
      else if (lam == -1)
        s += 2 * (e[i] == 0 ? 0.0 : e[i] * std::log(e[i] / o[i]));
      else
        s += 2 / (lam * (lam + 1)) * o[i] * (std::pow(o[i] / e[i], lam) - 1);
    }
    return sp(s, chi2sf(s, o.size() - 1.0));
  } SP_END

  SP_ADD("combine_pvalues", 1, 3, "pvalues, method, weights") {
    Vec p, w;
    if (!getVec(a, 0, ctx, p))
      return Value(0.0);
    std::string m = optText(a, 1, "fisher");
    double k = p.size(), s = 0, pv;
    if (m == "fisher") {
      for (double v : p)
        s -= 2 * std::log(v);
      pv = chi2sf(s, 2 * k);
    } else if (m == "pearson") {
      for (double v : p)
        s += 2 * std::log1p(-v);
      pv = sf::chdtr(2 * k, -s);
    } else if (m == "tippett") {
      s = *std::min_element(p.begin(), p.end());
      pv = -std::expm1(k * std::log1p(-s));
    } else if (m == "stouffer") {
      if (a.size() > 2 && !getVec(a, 2, ctx, w))
        return Value(0.0);
      if (w.empty())
        w.assign(p.size(), 1.0);
      double ww = 0;
      for (size_t i = 0; i < p.size(); i++) {
        s += w[i] * -sf::ndtri(p[i]);
        ww += w[i] * w[i];
      }
      s /= std::sqrt(ww);
      pv = sf::ndtr(-s);
    } else if (m == "mudholkar_george") {
      for (double v : p)
        s += -std::log(v) + std::log1p(-v);
      double nu = 5 * k + 4, f = std::sqrt(3 / k) / kPi * std::sqrt(nu / (nu - 2));
      pv = sf::stdtr(nu, -s * f);
    } else {
      ctx.fail("method must be \"fisher\", \"pearson\", \"tippett\", \"stouffer\" or \"mudholkar_george\"");
      return Value(0.0);
    }
    return sp(s, pv);
  } SP_END

  SP_ADD("fdr_adjust", 1, 2, "pvalues, method") {
    Vec p;
    if (!getVec(a, 0, ctx, p))
      return Value(0.0);
    std::string m = optText(a, 1, "bh");
    if (m != "bh" && m != "by") {
      ctx.fail("method must be \"bh\" or \"by\"");
      return Value(0.0);
    }
    size_t n = p.size();
    std::vector<size_t> idx(n);
    std::iota(idx.begin(), idx.end(), 0);
    std::sort(idx.begin(), idx.end(), [&](size_t x, size_t y) { return p[x] < p[y]; });
    double c = 1;
    if (m == "by") {
      c = 0;
      for (size_t i = 1; i <= n; i++)
        c += 1.0 / i;
    }
    Vec adj(n);
    double run = kInf;
    for (size_t k = n; k-- > 0;) {
      double v = p[idx[k]] * n / (k + 1) * c;
      run = std::min(run, v);
      adj[idx[k]] = std::min(1.0, run);
    }
    return toValue(adj);
  } SP_END

  // ---- goodness of fit ----
  SP_ADD("ks_1samp", 2, kVariadic, "data, cdf, shapes...") {
    Vec x;
    if (!getVec(a, 0, ctx, x) || x.empty()) {
      if (ctx.ok())
        ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    CdfRef c;
    if (!c.resolve(a, 1, ctx))
      return Value(0.0);
    Vec s = sorted(x);
    double n = s.size(), D = 0;
    bool failed = false;
    for (size_t i = 0; i < s.size(); i++) {
      double F = c(s[i], failed);
      D = std::max({D, (i + 1) / n - F, F - i / n});
    }
    if (failed) {
      ctx.fail("the cdf function could not be evaluated");
      return Value(0.0);
    }
    const pd::Family *k2 = pd::findFamily("kstwo");
    double pn = n;
    return sp(D, std::min(1.0, pd::sf(*k2, D, &pn)));
  } SP_END
  reg.setParallel({"ks_1samp"}, ParallelClass::Interpreter);

  SP_ADD("ks_test", 2, kVariadic, "data, dist, shapes...") {
    Vec x;
    if (!getVec(a, 0, ctx, x) || x.empty()) {
      if (ctx.ok())
        ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    if (a[1].isText || a[1].isFunctionRef) {
      CdfRef c;
      if (!c.resolve(a, 1, ctx))
        return Value(0.0);
      Vec s = sorted(x);
      double n = s.size(), D = 0;
      bool failed = false;
      for (size_t i = 0; i < s.size(); i++) {
        double F = c(s[i], failed);
        D = std::max({D, (i + 1) / n - F, F - i / n});
      }
      if (failed) {
        ctx.fail("the cdf function could not be evaluated");
        return Value(0.0);
      }
      const pd::Family *k2 = pd::findFamily("kstwo");
      double pn = n;
      return sp(D, std::min(1.0, pd::sf(*k2, D, &pn)));
    }
    Value r;
    if (!callNC(Value(std::string("ks_2samp")), Args{a[0], a[1]}, r)) {
      ctx.fail("the second sample could not be used");
      return Value(0.0);
    }
    return r;
  } SP_END
  reg.setParallel({"ks_test"}, ParallelClass::Interpreter);

  SP_ADD("cramer_vonmises", 2, kVariadic, "data, dist, shapes...") {
    Vec x;
    if (!getVec(a, 0, ctx, x) || x.size() < 2) {
      if (ctx.ok())
        ctx.fail("needs at least 2 values");
      return Value(0.0);
    }
    CdfRef c;
    if (!c.resolve(a, 1, ctx))
      return Value(0.0);
    Vec s = sorted(x);
    double n = s.size(), W = 1 / (12 * n);
    bool failed = false;
    for (size_t i = 0; i < s.size(); i++) {
      double u = c(s[i], failed);
      W += std::pow(u - (2.0 * i + 1) / (2 * n), 2);
    }
    if (failed) {
      ctx.fail("the cdf function could not be evaluated");
      return Value(0.0);
    }
    return sp(W, std::max(0.0, 1 - cvmCdf(W, n)));
  } SP_END
  reg.setParallel({"cramer_vonmises"}, ParallelClass::Interpreter);

  SP_ADD("goodness_of_fit", 2, 4, "dist, data, n_samples, statistic") {
    std::string dn;
    Vec x;
    if (!argText(a, 0, ctx, dn) || !getVec(a, 1, ctx, x))
      return Value(0.0);
    const pd::Family *f = pd::findFamily(dn);
    if (!f || f->nshape != 0 || f->discrete) {
      ctx.fail("dist must be a continuous family without shape parameters (\"norm\", \"logistic\", \"expon\", ...)");
      return Value(0.0);
    }
    if (x.size() < 3) {
      ctx.fail("needs at least 3 values");
      return Value(0.0);
    }
    long long ns = optInt(a, 2, 9999);
    std::string stn = optText(a, 3, "ad");
    if (ns < 1 || ns > 1000000 || (stn != "ad" && stn != "ks" && stn != "cvm")) {
      ctx.fail("n_samples from 1 to 1000000; statistic \"ad\", \"ks\" or \"cvm\"");
      return Value(0.0);
    }
    // maximum-likelihood loc and scale
    auto fit = [&](const Vec &s, double &loc, double &sc) {
      if (dn == "norm") { // SciPy's estimate: the sample standard deviation
        loc = mean(s);
        sc = std::sqrt(var(s));
        return;
      }
      auto nll = [&](double l, double c) {
        double t = 0;
        for (double v : s) {
          double p = pd::pdfLS(*f, v, nullptr, l, c);
          t -= p > 0 ? std::log(p) : -1e300;
        }
        return t;
      };
      loc = median(s);
      sc = std::sqrt(var(s, 0));
      if (sc <= 0)
        sc = 1;
      for (int it = 0; it < 40; it++) {
        double ol = loc, os = sc;
        loc = minimize1([&](double l) { return nll(l, sc); }, loc - sc, loc + sc, 1e-12);
        sc = std::exp(minimize1([&](double u) { return nll(loc, std::exp(u)); }, std::log(sc) - 0.3, std::log(sc) + 0.3, 1e-12));
        if (std::fabs(ol - loc) + std::fabs(os - sc) < 1e-12 * (1 + std::fabs(loc) + sc))
          break;
      }
    };
    auto stat = [&](const Vec &s, double loc, double sc) {
      Vec u(s.size());
      for (size_t i = 0; i < s.size(); i++)
        u[i] = pd::cdfLS(*f, s[i], nullptr, loc, sc);
      std::sort(u.begin(), u.end());
      double n = u.size();
      if (stn == "ad")
        return adStat(u);
      if (stn == "ks") {
        double D = 0;
        for (size_t i = 0; i < u.size(); i++)
          D = std::max({D, (i + 1) / n - u[i], u[i] - i / n});
        return D;
      }
      double W = 1 / (12 * n);
      for (size_t i = 0; i < u.size(); i++)
        W += std::pow(u[i] - (2.0 * i + 1) / (2 * n), 2);
      return W;
    };
    double loc, sc;
    fit(x, loc, sc);
    double T = stat(x, loc, sc);
    std::mt19937_64 g(ncRandomEngine()());
    double cnt = 0;
    Vec s(x.size());
    for (long long r = 0; r < ns; r++) {
      for (double &v : s)
        v = pd::rvsLS(*f, g, nullptr, loc, sc);
      double l2, s2;
      fit(s, l2, s2);
      cnt += stat(s, l2, s2) >= T;
    }
    Value fr = makeDict({{"loc", Value(loc)}, {"scale", Value(sc)}});
    return makeDict({{"statistic", Value(T)}, {"pvalue", Value((cnt + 1) / (ns + 1))}, {"fit_result", fr}});
  } SP_END
}

} // namespace scipy
} // namespace nc
