// Section 21, multivariate distributions: densities (multivariate normal and
// t, Dirichlet, Dirichlet-multinomial, multinomial, multivariate
// hypergeometric, normal-inverse-gamma, von Mises-Fisher) and random draws
// (matrix normal and t, Wishart, inverse Wishart, random rotations,
// orthogonal and unitary matrices, correlation matrices, tables, directions).
#include "st_common.h"
#include "statistics_main.h"

#include "../../ops/matrix/matrix.h"
#include "../linear_algebra/la_core.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace {
using namespace st;

Mat mul(const Mat &A, const Mat &B) {
  Mat C(A.r, B.c);
  for (size_t i = 0; i < A.r; i++)
    for (size_t k = 0; k < A.c; k++) {
      double v = A(i, k);
      if (v != 0)
        for (size_t j = 0; j < B.c; j++)
          C(i, j) += v * B(k, j);
    }
  return C;
}

// A = L L^T for a symmetric positive semi-definite A (eigen-decomposition
// when Cholesky fails). False when A is not positive semi-definite.
bool sqrtFactor(const Mat &A, Mat &L) {
  if (la::cholLower(A, L))
    return true;
  Vec w;
  Mat V;
  la::eigHermitian(A, w, V);
  double top = 0;
  for (double e : w)
    top = std::max(top, std::fabs(e));
  L = Mat(A.r, A.r);
  for (size_t k = 0; k < w.size(); k++) {
    if (w[k] < -1e-10 * (1 + top))
      return false;
    double s = std::sqrt(std::max(0.0, w[k]));
    for (size_t i = 0; i < A.r; i++)
      L(i, k) = V(i, k) * s;
  }
  return true;
}

bool symPosDef(const Args &a, size_t i, CallContext &ctx, Mat &S, size_t n, const char *what) {
  if (!getSquare(a, i, ctx, S))
    return false;
  if (S.r != n) {
    ctx.fail(std::string(what) + " must be " + std::to_string(n) + " x " + std::to_string(n));
    return false;
  }
  return true;
}

// log-density of N(mu, S) at x; false when S is singular
bool mvnLogPdf(const Vec &x, const Vec &mu, const Mat &S, double &out) {
  Mat L;
  if (!la::cholLower(S, L))
    return false;
  size_t d = x.size();
  Vec z(d);
  double logdet = 0;
  for (size_t i = 0; i < d; i++) {
    double s = x[i] - mu[i];
    for (size_t k = 0; k < i; k++)
      s -= L(i, k) * z[k];
    z[i] = s / L(i, i);
    logdet += 2 * std::log(L(i, i));
  }
  double q = 0;
  for (double v : z)
    q += v * v;
  out = -0.5 * (d * std::log(2 * kPi) + logdet + q);
  return true;
}

Mat gaussMat(std::mt19937_64 &g, size_t r, size_t c) {
  Mat m(r, c);
  for (double &v : m.a)
    v = pd::stdNormal(g);
  return m;
}

// Bartlett: W = L A A^T L^T with A lower, A_ii^2 ~ chi2(df - i), A_ij ~ N(0, 1)
Mat wishartDraw(std::mt19937_64 &g, double df, const Mat &L) {
  size_t p = L.r;
  Mat A(p, p);
  for (size_t i = 0; i < p; i++) {
    A(i, i) = std::sqrt(2 * pd::stdGamma(g, (df - i) / 2));
    for (size_t j = 0; j < i; j++)
      A(i, j) = pd::stdNormal(g);
  }
  Mat LA = mul(L, A);
  return mul(LA, transposeOf(LA));
}

// orthogonal matrix from QR of a Gaussian, signs fixed (Haar measure)
Mat haarOrthogonal(std::mt19937_64 &g, size_t n) {
  Mat Q, R;
  la::qrFactor(gaussMat(g, n, n), Q, R);
  for (size_t j = 0; j < n; j++)
    if (R(j, j) < 0)
      for (size_t i = 0; i < n; i++)
        Q(i, j) = -Q(i, j);
  return Q;
}

double logFactorial(double k) { return std::lgamma(k + 1); }

bool countsArg(const Args &a, size_t i, CallContext &ctx, Vec &x) {
  if (!getVec(a, i, ctx, x))
    return false;
  for (double v : x)
    if (!(v >= 0) || v != std::floor(v)) {
      ctx.fail("the counts must be whole numbers >= 0");
      return false;
    }
  return true;
}
} // namespace

void registerStMulti(Registry &reg) {
  SP_ADD("mvnormal_pdf", 1, 3, "x, mean, cov") {
    Mat X;
    if (!getMat(a, 0, ctx, X))
      return Value(0.0);
    bool many = a[0].isMatrix && X.r > 1;
    if (!many) {
      Vec v = X.a;
      X = Mat(1, v.size());
      X.a = v;
    }
    size_t d = X.c;
    Vec mu(d, 0.0);
    if (a.size() > 1 && !getVec(a, 1, ctx, mu))
      return Value(0.0);
    if (mu.size() == 1 && d > 1)
      mu.assign(d, double(mu[0]));
    Mat S = Mat::eye(d);
    if (a.size() > 2) {
      if (isPlainNumber(a[2]))
        for (size_t i = 0; i < d; i++)
          S(i, i) = a[2].number;
      else if (a[2].isArray && !a[2].isMatrix) {
        Vec dg;
        readVec(a[2], dg);
        if (dg.size() != d) {
          ctx.fail("a diagonal cov needs one variance per dimension");
          return Value(0.0);
        }
        for (size_t i = 0; i < d; i++)
          S(i, i) = dg[i];
      } else if (!symPosDef(a, 2, ctx, S, d, "cov"))
        return Value(0.0);
    }
    if (mu.size() != d) {
      ctx.fail("mean must have one value per dimension");
      return Value(0.0);
    }
    Vec out(X.r);
    for (size_t i = 0; i < X.r; i++) {
      double lp;
      if (!mvnLogPdf(Vec(X.row(i), X.row(i) + d), mu, S, lp)) {
        ctx.fail("cov must be symmetric positive definite");
        return Value(0.0);
      }
      out[i] = std::exp(lp);
    }
    return many ? toValue(out) : Value(out[0]);
  } SP_END

  SP_ADD("mvt_pdf", 4, 4, "x, loc, shape, df") {
    Vec x, mu;
    Mat S;
    double df;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, mu) || !symPosDef(a, 2, ctx, S, x.size(), "shape") || !argNumber(a, 3, ctx, df))
      return Value(0.0);
    if (mu.size() != x.size() || !(df > 0)) {
      ctx.fail("loc must match x and df must be positive");
      return Value(0.0);
    }
    Mat L;
    if (!la::cholLower(S, L)) {
      ctx.fail("shape must be symmetric positive definite");
      return Value(0.0);
    }
    size_t p = x.size();
    Vec z(p);
    double logdet = 0, q = 0;
    for (size_t i = 0; i < p; i++) {
      double s = x[i] - mu[i];
      for (size_t k = 0; k < i; k++)
        s -= L(i, k) * z[k];
      z[i] = s / L(i, i);
      q += z[i] * z[i];
      logdet += 2 * std::log(L(i, i));
    }
    if (std::isinf(df)) {
      double lp = -0.5 * (p * std::log(2 * kPi) + logdet + q);
      return Value(std::exp(lp));
    }
    double lp = std::lgamma((df + p) / 2) - std::lgamma(df / 2) - 0.5 * p * std::log(df * kPi) - 0.5 * logdet -
                (df + p) / 2 * std::log1p(q / df);
    return Value(std::exp(lp));
  } SP_END

  SP_ADD("dirichlet_pdf", 2, 2, "x, alpha") {
    Vec x, al;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, al))
      return Value(0.0);
    if (x.size() + 1 == al.size()) { // last component left out, as SciPy allows
      double s = 0;
      for (double v : x)
        s += v;
      x.push_back(1 - s);
    }
    if (x.size() != al.size() || al.size() < 2) {
      ctx.fail("x and alpha must have the same length (at least 2)");
      return Value(0.0);
    }
    double s = 0, a0 = 0, lp = 0;
    for (size_t i = 0; i < x.size(); i++) {
      if (!(al[i] > 0)) {
        ctx.fail("alpha must be positive");
        return Value(0.0);
      }
      if (!(x[i] >= 0 && x[i] <= 1)) {
        ctx.fail("x must be in [0, 1]");
        return Value(0.0);
      }
      s += x[i];
      a0 += al[i];
      lp += (al[i] - 1) * std::log(x[i]) - std::lgamma(al[i]);
    }
    if (std::fabs(s - 1) > 1e-10) {
      ctx.fail("x must sum to 1");
      return Value(0.0);
    }
    return Value(std::exp(lp + std::lgamma(a0)));
  } SP_END

  SP_ADD("dirichlet_multinomial_pmf", 3, 3, "x, alpha, n") {
    Vec x, al;
    long long n;
    if (!countsArg(a, 0, ctx, x) || !getVec(a, 1, ctx, al) || !argNonNegativeInt(a, 2, ctx, n))
      return Value(0.0);
    if (x.size() != al.size()) {
      ctx.fail("x and alpha must have the same length");
      return Value(0.0);
    }
    double s = 0, a0 = 0, lp = 0;
    for (size_t i = 0; i < x.size(); i++) {
      if (!(al[i] > 0)) {
        ctx.fail("alpha must be positive");
        return Value(0.0);
      }
      s += x[i];
      a0 += al[i];
      lp += std::lgamma(x[i] + al[i]) - std::lgamma(al[i]) - logFactorial(x[i]);
    }
    if (s != double(n))
      return Value(0.0);
    return Value(std::exp(lp + std::lgamma(a0) + logFactorial(double(n)) - std::lgamma(double(n) + a0)));
  } SP_END

  SP_ADD("multinomial_pmf", 3, 3, "x, n, p") {
    Vec x, p;
    long long n;
    if (!countsArg(a, 0, ctx, x) || !argNonNegativeInt(a, 1, ctx, n) || !getVec(a, 2, ctx, p))
      return Value(0.0);
    if (x.size() != p.size()) {
      ctx.fail("x and p must have the same length");
      return Value(0.0);
    }
    double s = 0, ps = 0, lp = logFactorial(double(n));
    for (size_t i = 0; i < x.size(); i++) {
      if (!(p[i] >= 0 && p[i] <= 1)) {
        ctx.fail("p must be probabilities");
        return Value(0.0);
      }
      s += x[i];
      ps += p[i];
      lp -= logFactorial(x[i]);
      if (x[i] > 0) {
        if (p[i] == 0)
          return Value(0.0);
        lp += x[i] * std::log(p[i]);
      }
    }
    if (std::fabs(ps - 1) > 1e-8) {
      ctx.fail("p must sum to 1");
      return Value(0.0);
    }
    return Value(s == double(n) ? std::exp(lp) : 0.0);
  } SP_END

  SP_ADD("mv_hypergeom_pmf", 3, 3, "x, m, n") {
    Vec x, m;
    long long n;
    if (!countsArg(a, 0, ctx, x) || !countsArg(a, 1, ctx, m) || !argNonNegativeInt(a, 2, ctx, n))
      return Value(0.0);
    if (x.size() != m.size()) {
      ctx.fail("x and m must have the same length");
      return Value(0.0);
    }
    auto lchoose = [](double N, double k) { return std::lgamma(N + 1) - std::lgamma(k + 1) - std::lgamma(N - k + 1); };
    double s = 0, M = 0, lp = 0;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] > m[i])
        return Value(0.0);
      s += x[i];
      M += m[i];
      lp += lchoose(m[i], x[i]);
    }
    if (double(n) > M) {
      ctx.fail("n must not exceed the total number of items");
      return Value(0.0);
    }
    return Value(s == double(n) ? std::exp(lp - lchoose(M, double(n))) : 0.0);
  } SP_END

  SP_ADD("normal_inv_gamma_pdf", 6, 6, "x, s2, mu, lmbda, a, b") {
    double v[6];
    for (int i = 0; i < 6; i++)
      if (!argNumber(a, i, ctx, v[i]))
        return Value(0.0);
    double x = v[0], s2 = v[1], mu = v[2], lam = v[3], al = v[4], b = v[5];
    if (!(lam > 0 && al > 0 && b > 0)) {
      ctx.fail("lmbda, a and b must be positive");
      return Value(0.0);
    }
    if (!(s2 > 0))
      return Value(0.0);
    double lp = 0.5 * std::log(lam) - 0.5 * std::log(2 * kPi * s2) + al * std::log(b) - std::lgamma(al) - (al + 1) * std::log(s2) -
                (2 * b + lam * (x - mu) * (x - mu)) / (2 * s2);
    return Value(std::exp(lp));
  } SP_END

  SP_ADD("vonmises_fisher_pdf", 3, 3, "x, mu, kappa") {
    Vec x, mu;
    double k;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, mu) || !argNumber(a, 2, ctx, k))
      return Value(0.0);
    if (x.size() != mu.size() || x.size() < 2 || !(k >= 0)) {
      ctx.fail("x and mu must be unit vectors of the same dimension (>= 2) and kappa >= 0");
      return Value(0.0);
    }
    double nm = 0, nx = 0, dot = 0;
    for (size_t i = 0; i < x.size(); i++) {
      nm += mu[i] * mu[i];
      nx += x[i] * x[i];
      dot += x[i] * mu[i];
    }
    if (std::fabs(nm - 1) > 1e-8) {
      ctx.fail("mu must be a unit vector");
      return Value(0.0);
    }
    if (std::fabs(nx - 1) > 1e-8)
      return Value(0.0);
    double p = x.size(), lc;
    if (k == 0) // 1 / area of the sphere
      lc = std::lgamma(p / 2) - std::log(2.0) - p / 2 * std::log(kPi);
    else if (p == 3)
      lc = std::log(k) - std::log(2 * kPi) - k - std::log1p(-std::exp(-2 * k));
    else
      lc = (p / 2 - 1) * std::log(k) - p / 2 * std::log(2 * kPi) - std::log(sf::besseli(p / 2 - 1, k, true)) - k;
    return Value(std::exp(lc + k * dot));
  } SP_END

  // ---- random draws ----
  SP_ADD("matrix_normal_rvs", 1, 3, "mean, rowcov, colcov") {
    Mat M;
    if (!getMat(a, 0, ctx, M))
      return Value(0.0);
    Mat U = Mat::eye(M.r), V = Mat::eye(M.c);
    if (a.size() > 1 && !symPosDef(a, 1, ctx, U, M.r, "rowcov"))
      return Value(0.0);
    if (a.size() > 2 && !symPosDef(a, 2, ctx, V, M.c, "colcov"))
      return Value(0.0);
    Mat A, B;
    if (!sqrtFactor(U, A) || !sqrtFactor(V, B)) {
      ctx.fail("rowcov and colcov must be positive semi-definite");
      return Value(0.0);
    }
    std::mt19937_64 g(ncRandomEngine()());
    Mat X = mul(mul(A, gaussMat(g, M.r, M.c)), transposeOf(B));
    for (size_t i = 0; i < X.a.size(); i++)
      X.a[i] += M.a[i];
    return toValue(X);
  } SP_END

  SP_ADD("matrix_t_rvs", 4, 4, "mean, row_spread, col_spread, df") {
    Mat M, U, V;
    double df;
    if (!getMat(a, 0, ctx, M) || !symPosDef(a, 1, ctx, U, M.r, "row_spread") || !symPosDef(a, 2, ctx, V, M.c, "col_spread") ||
        !argNumber(a, 3, ctx, df))
      return Value(0.0);
    if (!(df > 0)) {
      ctx.fail("df must be positive");
      return Value(0.0);
    }
    // X | S ~ MN(M, S, V) with S ~ inverse-Wishart(df + n - 1, U)
    Mat Ui, Li, B;
    if (!la::inverse(U, Ui) || !la::cholLower(Ui, Li) || !sqrtFactor(V, B)) {
      ctx.fail("row_spread must be positive definite and col_spread positive semi-definite");
      return Value(0.0);
    }
    std::mt19937_64 g(ncRandomEngine()());
    Mat W = wishartDraw(g, df + M.r - 1, Li), S, A;
    if (!la::inverse(W, S) || !sqrtFactor(S, A)) {
      ctx.fail("the draw failed (df too small?)");
      return Value(0.0);
    }
    Mat X = mul(mul(A, gaussMat(g, M.r, M.c)), transposeOf(B));
    for (size_t i = 0; i < X.a.size(); i++)
      X.a[i] += M.a[i];
    return toValue(X);
  } SP_END

  auto wish = [](bool inv) {
    return [inv](const Args &a, CallContext &ctx) -> Value {
      double df;
      Mat S;
      if (!argNumber(a, 0, ctx, df))
        return Value(0.0);
      if (isPlainNumber(a[1])) {
        S = Mat(1, 1, a[1].number);
      } else if (!getSquare(a, 1, ctx, S))
        return Value(0.0);
      size_t p = S.r;
      if (!(df > p - 1.0)) {
        ctx.fail("df must be greater than dimension - 1");
        return Value(0.0);
      }
      Mat base = S, L;
      if (inv && !la::inverse(S, base)) {
        ctx.fail("scale must be positive definite");
        return Value(0.0);
      }
      if (!la::cholLower(base, L)) {
        ctx.fail("scale must be positive definite");
        return Value(0.0);
      }
      std::mt19937_64 g(ncRandomEngine()());
      Mat W = wishartDraw(g, df, L);
      if (inv) {
        Mat Wi;
        la::inverse(W, Wi);
        W = Wi;
      }
      return p == 1 ? Value(W(0, 0)) : toValue(W);
    };
  };
  reg.add(makeSpec("wishart_rvs", SP_SEC, 2, 2, "df, scale", wish(false), false));
  reg.add(makeSpec("invwishart_rvs", SP_SEC, 2, 2, "df, scale", wish(true), false));

  auto orth = [](int kind) { // 0 rotation, 1 orthogonal
    return [kind](const Args &a, CallContext &ctx) -> Value {
      long long n;
      if (!argInt(a, 0, ctx, n))
        return Value(0.0);
      if (n < 1 || n > 2000) {
        ctx.fail("n must be from 1 to 2000");
        return Value(0.0);
      }
      std::mt19937_64 g(ncRandomEngine()());
      Mat Q = haarOrthogonal(g, static_cast<size_t>(n));
      if (kind == 0 && la::det(Q) < 0)
        for (size_t i = 0; i < Q.r; i++)
          Q(i, 0) = -Q(i, 0);
      return toValue(Q);
    };
  };
  reg.add(makeSpec("rand_rotation", SP_SEC, 1, 1, "n", orth(0), false));
  reg.add(makeSpec("rand_orthogonal", SP_SEC, 1, 1, "n", orth(1), false));

  SP_ADD("rand_unitary", 1, 1, "n") {
    long long n;
    if (!argInt(a, 0, ctx, n))
      return Value(0.0);
    if (n < 1 || n > 2000) {
      ctx.fail("n must be from 1 to 2000");
      return Value(0.0);
    }
    std::mt19937_64 g(ncRandomEngine()());
    CMat Z(static_cast<size_t>(n), static_cast<size_t>(n));
    for (cd &z : Z.a)
      z = cd(pd::stdNormal(g), pd::stdNormal(g)) / std::sqrt(2.0);
    CMat Q, R;
    la::qrFactor(Z, Q, R);
    for (size_t j = 0; j < Q.c; j++) {
      cd ph = std::abs(R(j, j)) > 0 ? R(j, j) / std::abs(R(j, j)) : cd(1);
      for (size_t i = 0; i < Q.r; i++)
        Q(i, j) *= ph;
    }
    return toValue(Q);
  } SP_END

  SP_ADD("rand_correlation", 1, 1, "eigs") {
    Vec e;
    if (!getVec(a, 0, ctx, e))
      return Value(0.0);
    size_t d = e.size();
    double s = 0;
    for (double v : e) {
      if (v < 0) {
        ctx.fail("the eigenvalues must not be negative");
        return Value(0.0);
      }
      s += v;
    }
    if (d < 1 || std::fabs(s - d) > 1e-10 * d) {
      ctx.fail("the eigenvalues must sum to their count (the dimension)");
      return Value(0.0);
    }
    std::mt19937_64 g(ncRandomEngine()());
    Mat Q = haarOrthogonal(g, d), m(d, d);
    for (size_t i = 0; i < d; i++)
      for (size_t j = 0; j < d; j++)
        for (size_t k = 0; k < d; k++)
          m(i, j) += Q(i, k) * e[k] * Q(j, k);
    // Givens rotations to a unit diagonal (Bendel and Mickey; Davies and Higham)
    for (size_t i = 0; i + 1 < d; i++) {
      if (m(i, i) == 1)
        continue;
      size_t j = i + 1;
      for (; j < d; j++)
        if (m(i, i) > 1 ? m(j, j) < 1 : m(j, j) > 1)
          break;
      if (j == d)
        j = d - 1;
      double aii = m(i, i) - 1, ajj = m(j, j) - 1, aij = m(i, j), c, sn;
      if (ajj == 0) {
        c = 0;
        sn = 1;
      } else {
        double dd = std::sqrt(std::max(aij * aij - aii * ajj, 0.0));
        double t = (aij + std::copysign(dd, aij)) / ajj;
        c = 1 / std::sqrt(1 + t * t);
        sn = c == 0 ? 1.0 : c * t;
      }
      // m = G^T m G with G = I except G_ii = G_jj = c, G_ji = s, G_ij = -s
      for (size_t k = 0; k < d; k++) { // columns
        double x = m(k, i), y = m(k, j);
        m(k, i) = c * x + sn * y;
        m(k, j) = -sn * x + c * y;
      }
      for (size_t k = 0; k < d; k++) { // rows
        double x = m(i, k), y = m(j, k);
        m(i, k) = c * x + sn * y;
        m(j, k) = -sn * x + c * y;
      }
    }
    for (size_t i = 0; i < d; i++) {
      m(i, i) = 1;
      for (size_t j = 0; j < i; j++)
        m(i, j) = m(j, i) = 0.5 * (m(i, j) + m(j, i));
    }
    return toValue(m);
  } SP_END

  SP_ADD("rand_table", 2, 2, "row, col") {
    Vec r, c;
    if (!countsArg(a, 0, ctx, r) || !countsArg(a, 1, ctx, c))
      return Value(0.0);
    double sr = 0, sc = 0;
    for (double v : r)
      sr += v;
    for (double v : c)
      sc += v;
    if (sr != sc || sr > 1e8) {
      ctx.fail("row and column totals must have the same sum");
      return Value(0.0);
    }
    // a uniformly random arrangement of the column labels, cut into rows
    std::vector<size_t> lab;
    for (size_t j = 0; j < c.size(); j++)
      lab.insert(lab.end(), size_t(c[j]), j);
    std::mt19937_64 g(ncRandomEngine()());
    std::shuffle(lab.begin(), lab.end(), g);
    Mat t(r.size(), c.size());
    size_t pos = 0;
    for (size_t i = 0; i < r.size(); i++)
      for (size_t k = 0; k < size_t(r[i]); k++)
        t(i, lab[pos++]) += 1;
    return toValue(t);
  } SP_END

  SP_ADD("rand_direction", 1, 1, "dim") {
    long long d;
    if (!argInt(a, 0, ctx, d))
      return Value(0.0);
    if (d < 1 || d > 10000000) {
      ctx.fail("dim must be from 1 to 10000000");
      return Value(0.0);
    }
    std::mt19937_64 g(ncRandomEngine()());
    Vec v(static_cast<size_t>(d));
    double s;
    do {
      s = 0;
      for (double &x : v) {
        x = pd::stdNormal(g);
        s += x * x;
      }
    } while (s == 0);
    s = std::sqrt(s);
    for (double &x : v)
      x /= s;
    return toValue(v);
  } SP_END
}

} // namespace scipy
} // namespace nc
