// Section 21, hypothesis tests and correlations: t tests, normality tests,
// rank tests (with their exact null distributions where SciPy uses them),
// k-sample tests, contingency-table tests, p-value combination.
#include "st_common.h"
#include "statistics_main.h"

#include <map>

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace st {
double chi2Table(const Mat &t, bool correction, double &dof, Mat &expected);
}

namespace {
using namespace st;

bool getData(const Args &a, size_t i, CallContext &ctx, Vec &x, size_t minN = 1) {
  if (!getVec(a, i, ctx, x))
    return false;
  if (x.size() < minN) {
    ctx.fail("the " + ordinal(i) + " argument needs at least " + std::to_string(minN) + " values");
    return false;
  }
  return true;
}
bool altArg(const Args &a, size_t i, CallContext &ctx, std::string &alt) {
  alt = optText(a, i, "two-sided");
  if (alt != "two-sided" && alt != "less" && alt != "greater") {
    ctx.fail("alternative must be \"two-sided\", \"less\" or \"greater\"");
    return false;
  }
  return true;
}
Value sp(double s, double p) { return makeDict({{"statistic", Value(s)}, {"pvalue", Value(p)}}); }
Value spdf(double s, double p, double df) {
  return makeDict({{"statistic", Value(s)}, {"pvalue", Value(p)}, {"df", Value(df)}});
}
double chi2sf(double x, double df) { return sf::chdtrc(df, x); }
double tsf(double t, double df) { return sf::stdtr(df, -t); }

// Kendall's tau statistics.
void kendallCounts(const Vec &x, const Vec &y, double &P, double &Q, double &tx, double &ty) {
  P = Q = tx = ty = 0;
  size_t n = x.size();
  for (size_t i = 0; i < n; i++)
    for (size_t j = i + 1; j < n; j++) {
      double s = (x[i] - x[j]) * (y[i] - y[j]);
      if (s > 0)
        P++;
      else if (s < 0)
        Q++;
      else {
        if (x[i] == x[j] && y[i] != y[j])
          tx++;
        if (y[i] == y[j] && x[i] != x[j])
          ty++;
      }
    }
}

// Number of permutations of n with exactly k inversions (Mahonian numbers), as a distribution.
Vec mahonian(int n) {
  Vec c(1, 1.0);
  for (int m = 2; m <= n; m++) {
    Vec d(c.size() + m - 1, 0.0);
    // sliding window sum of width m
    double run = 0;
    for (size_t k = 0; k < d.size(); k++) {
      if (k < c.size())
        run += c[k];
      if (k >= static_cast<size_t>(m) && k - m < c.size())
        run -= c[k - m];
      d[k] = run;
    }
    double tot = 0;
    for (double v : d)
      tot += v;
    for (double &v : d)
      v /= tot;
    c = d;
  }
  return c;
}

// Exact null distribution of the Wilcoxon signed-rank statistic T+ for n pairs.
Vec signedRankDist(int n) {
  int maxS = n * (n + 1) / 2;
  Vec c(maxS + 1, 0.0);
  c[0] = 1;
  for (int k = 1; k <= n; k++)
    for (int s = maxS; s >= k; s--)
      c[s] += c[s - k];
  double tot = std::ldexp(1.0, n);
  for (double &v : c)
    v /= tot;
  return c;
}

// Exact null distribution of the Mann-Whitney U for sizes m, n (no ties).
Vec mannWhitneyDist(int m, int n) {
  // f(m, n, u): number of arrangements; DP over m with u up to m*n
  std::vector<Vec> f(n + 1, Vec(m * n + 1, 0.0));
  std::vector<std::vector<Vec>> g;
  // classical recursion p(u; m, n) = (m p(u - n; m - 1, n) + n p(u; m, n - 1)) / (m + n)
  std::vector<std::vector<Vec>> P(m + 1, std::vector<Vec>(n + 1));
  for (int i = 0; i <= m; i++)
    for (int j = 0; j <= n; j++) {
      P[i][j].assign(i * j + 1, 0.0);
      if (i == 0 || j == 0) {
        P[i][j][0] = 1.0;
        continue;
      }
      for (int u = 0; u <= i * j; u++) {
        double a1 = (u - j >= 0 && u - j <= (i - 1) * j) ? P[i - 1][j][u - j] : 0.0;
        double a2 = (u <= i * (j - 1)) ? P[i][j - 1][u] : 0.0;
        P[i][j][u] = (i * a1 + j * a2) / (i + j);
      }
    }
  (void)f;
  (void)g;
  return P[m][n];
}

double cdfAt(const Vec &pmf, double x) {
  double s = 0;
  for (size_t k = 0; k < pmf.size() && k <= x + 1e-9; k++)
    s += pmf[k];
  return std::min(1.0, s);
}
double sfAt(const Vec &pmf, double x) { // P(X >= x)
  double s = 0;
  for (size_t k = pmf.size(); k-- > 0;) {
    if (k + 1e-9 < x)
      break;
    s += pmf[k];
  }
  return std::min(1.0, s);
}

// Two-sample Kolmogorov-Smirnov: P(D >= d) by counting lattice paths.
double ks2Exact(int m, int n, double d) {
  // h = d * m * n, an integer for an observed statistic
  double h = std::round(d * m * n);
  // inside: |i n - j m| < h for every point
  std::vector<double> prev(n + 1, 0.0), cur(n + 1, 0.0);
  double lc = 0; // paths are normalised step by step: weight of each step = 1/(remaining choices) keeps magnitudes small
  for (int j = 0; j <= n; j++)
    prev[j] = (std::fabs(0.0 * n - double(j) * m) < h) ? (j == 0 ? 1.0 : prev[j - 1]) : 0.0;
  for (int i = 1; i <= m; i++) {
    for (int j = 0; j <= n; j++) {
      double v = prev[j] + (j ? cur[j - 1] : 0.0);
      cur[j] = (std::fabs(double(i) * n - double(j) * m) < h) ? v : 0.0;
    }
    // rescale against overflow
    double mx = 0;
    for (double v : cur)
      mx = std::max(mx, v);
    if (mx > 1e250) {
      for (double &v : cur)
        v /= 1e250;
      lc += std::log(1e250);
    }
    std::swap(prev, cur);
  }
  double inside = std::log(prev[n]) + lc;
  double total = std::lgamma(m + n + 1.0) - std::lgamma(m + 1.0) - std::lgamma(n + 1.0);
  return std::max(0.0, std::min(1.0, -std::expm1(inside - total)));
}

// Symmetric eigen-decomposition (Jacobi), for small pseudo-inverses.
void jacobiEig(Mat A, Vec &w, Mat &V) {
  size_t n = A.r;
  V = Mat::eye(n);
  for (int sweep = 0; sweep < 100; sweep++) {
    double off = 0;
    for (size_t i = 0; i < n; i++)
      for (size_t j = i + 1; j < n; j++)
        off += A(i, j) * A(i, j);
    if (off < 1e-30)
      break;
    for (size_t p = 0; p < n; p++)
      for (size_t q = p + 1; q < n; q++) {
        if (std::fabs(A(p, q)) < 1e-300)
          continue;
        double th = (A(q, q) - A(p, p)) / (2 * A(p, q));
        double t = (th >= 0 ? 1.0 : -1.0) / (std::fabs(th) + std::sqrt(th * th + 1));
        double c = 1 / std::sqrt(t * t + 1), s = t * c;
        for (size_t k = 0; k < n; k++) {
          double akp = A(k, p), akq = A(k, q);
          A(k, p) = c * akp - s * akq;
          A(k, q) = s * akp + c * akq;
        }
        for (size_t k = 0; k < n; k++) {
          double apk = A(p, k), aqk = A(q, k);
          A(p, k) = c * apk - s * aqk;
          A(q, k) = s * apk + c * aqk;
        }
        for (size_t k = 0; k < n; k++) {
          double vkp = V(k, p), vkq = V(k, q);
          V(k, p) = c * vkp - s * vkq;
          V(k, q) = s * vkp + c * vkq;
        }
      }
  }
  w.resize(n);
  for (size_t i = 0; i < n; i++)
    w[i] = A(i, i);
}

// Shapiro-Wilk W and p-value (Royston 1995, AS R94).
bool swilk(Vec x, double &W, double &pw) {
  size_t n = x.size();
  std::sort(x.begin(), x.end());
  if (n < 3)
    return false;
  size_t nn2 = n / 2;
  Vec a(nn2 + 1, 0.0); // 1-based
  const double small = 1e-19;
  const double g[2] = {-2.273, 0.459};
  const double c1[6] = {0.0, 0.221157, -0.147981, -2.07119, 4.434685, -2.706056};
  const double c2[6] = {0.0, 0.042981, -0.293762, -1.752461, 5.682633, -3.582633};
  const double c3[4] = {0.544, -0.39978, 0.025054, -6.714e-4};
  const double c4[4] = {1.3822, -0.77857, 0.062767, -0.0020322};
  const double c5[4] = {-1.5861, -0.31082, -0.083751, 0.0038915};
  const double c6[3] = {-0.4803, -0.082676, 0.0030302};
  auto poly = [](const double *cc, int nord, double xx) {
    double r = cc[0];
    if (nord > 1) {
      double p = xx * cc[nord - 1];
      for (int j = nord - 2; j > 0; j--)
        p = (p + cc[j]) * xx;
      r += p;
    }
    return r;
  };
  double an = n;
  if (n == 3) {
    a[1] = std::sqrt(0.5);
  } else {
    double an25 = an + 0.25, summ2 = 0, ssumm2, rsn;
    Vec m(nn2 + 1);
    for (size_t i = 1; i <= nn2; i++) {
      m[i] = sf::ndtri((i - 0.375) / an25);
      summ2 += m[i] * m[i];
    }
    summ2 *= 2;
    ssumm2 = std::sqrt(summ2);
    rsn = 1 / std::sqrt(an);
    double a1 = poly(c1, 6, rsn) - m[1] / ssumm2;
    size_t i1;
    double fac;
    if (n > 5) {
      i1 = 3;
      double a2 = -m[2] / ssumm2 + poly(c2, 6, rsn);
      fac = std::sqrt((summ2 - 2 * m[1] * m[1] - 2 * m[2] * m[2]) / (1 - 2 * a1 * a1 - 2 * a2 * a2));
      a[2] = a2;
    } else {
      i1 = 2;
      fac = std::sqrt((summ2 - 2 * m[1] * m[1]) / (1 - 2 * a1 * a1));
    }
    a[1] = a1;
    for (size_t i = i1; i <= nn2; i++)
      a[i] = -m[i] / fac;
  }
  double range = x[n - 1] - x[0];
  if (range < small)
    return false;
  double xx = x[0] / range, sx = xx, sa = -a[1];
  for (size_t i = 1, j = n - 1; i < n; j--) {
    double xi = x[i] / range;
    sx += xi;
    i++;
    if (i != j)
      sa += ((i - j > 0) ? 1 : ((i == j) ? 0 : -1)) * a[std::min(i, j)];
    xx = xi;
  }
  // recompute W directly (clearer than the Fortran loop above)
  double mean = 0;
  for (double v : x)
    mean += v;
  mean /= n;
  double ssq = 0, num = 0;
  for (double v : x)
    ssq += (v - mean) * (v - mean);
  for (size_t i = 1; i <= nn2; i++)
    num += a[i] * (x[n - i] - x[i - 1]);
  W = num * num / ssq;
  if (W > 1)
    W = 1;
  double w1 = std::log(1 - W);
  if (n == 3) {
    const double pi6 = 1.90985931710274, stqr = 1.04719755119660;
    pw = std::max(0.0, pi6 * (std::asin(std::sqrt(W)) - stqr));
    return true;
  }
  double xn = std::log(an), m2, s;
  if (n <= 11) {
    double gamma = poly(g, 2, an);
    if (w1 >= gamma) {
      pw = 1e-99;
      return true;
    }
    double y = -std::log(gamma - w1);
    m2 = poly(c3, 4, an);
    s = std::exp(poly(c4, 4, an));
    pw = sf::ndtr(-(y - m2) / s);
  } else {
    m2 = poly(c5, 4, xn);
    s = std::exp(poly(c6, 3, xn));
    pw = sf::ndtr(-(w1 - m2) / s);
  }
  (void)sx;
  (void)sa;
  return true;
}

// Fisher's exact test p-value for a 2x2 table.
double fisherP(double a, double b, double c, double d, const std::string &alt) {
  double n1 = a + b, n2 = c + d, k = a + c, N = n1 + n2;
  auto lpmf = [&](double x) {
    return std::lgamma(n1 + 1) - std::lgamma(x + 1) - std::lgamma(n1 - x + 1) + std::lgamma(n2 + 1) -
           std::lgamma(k - x + 1) - std::lgamma(n2 - k + x + 1) - (std::lgamma(N + 1) - std::lgamma(k + 1) - std::lgamma(N - k + 1));
  };
  double lo = std::max(0.0, k - n2), hi = std::min(k, n1);
  if (alt == "less") {
    double s = 0;
    for (double x = lo; x <= a; x++)
      s += std::exp(lpmf(x));
    return std::min(1.0, s);
  }
  if (alt == "greater") {
    double s = 0;
    for (double x = a; x <= hi; x++)
      s += std::exp(lpmf(x));
    return std::min(1.0, s);
  }
  double p0 = std::exp(lpmf(a)), s = 0;
  for (double x = lo; x <= hi; x++) {
    double p = std::exp(lpmf(x));
    if (p <= p0 * (1 + 1e-7))
      s += p;
  }
  return std::min(1.0, s);
}

double binomTestP(double k, double n, double p, const std::string &alt) {
  if (alt == "less")
    return sf::bdtr(k, n, p);
  if (alt == "greater")
    return sf::bdtrc(k - 1, n, p);
  auto pmf = [&](double x) {
    return std::exp(std::lgamma(n + 1) - std::lgamma(x + 1) - std::lgamma(n - x + 1) + x * std::log(p) + (n - x) * std::log1p(-p));
  };
  if (p == 0)
    return k == 0 ? 1.0 : 0.0;
  if (p == 1)
    return k == n ? 1.0 : 0.0;
  double d = pmf(k), rerr = 1 + 1e-7;
  if (k == p * n)
    return 1.0;
  double pv;
  if (k < p * n) {
    double y = 0;
    for (double i = std::ceil(p * n); i <= n; i++)
      if (pmf(i) <= d * rerr)
        y++;
    pv = sf::bdtr(k, n, p) + sf::bdtrc(n - y, n, p);
  } else {
    double y = 0;
    for (double i = 0; i <= std::floor(p * n); i++)
      if (pmf(i) <= d * rerr)
        y++;
    pv = sf::bdtr(y - 1, n, p) + sf::bdtrc(k - 1, n, p);
  }
  return std::min(1.0, pv);
}

double ansariStat(const Vec &x, const Vec &y) {
  Vec all(x);
  all.insert(all.end(), y.begin(), y.end());
  Vec r = rankdata(all);
  double N = all.size(), s = 0;
  for (size_t i = 0; i < x.size(); i++)
    s += std::min(r[i], N - r[i] + 1);
  return s;
}

// Exact p-value of the two-sample Cramer-von Mises U (Xiao, Gordon and
// Hunt 2007, Algorithm 1), counting the arrangements as SciPy does.
double cvm2Exact(double s, size_t m, size_t n) {
  long long mm = static_cast<long long>(m), nn = static_cast<long long>(n);
  long long g = std::gcd(mm, nn), lcm = mm / g * nn;
  long long A = lcm / mm, B = lcm / nn, mn = mm * nn;
  double zeta = std::floor(double(lcm) * lcm * (mm + nn) * (6 * s - double(mn) * (4 * mn - 1)) / (6.0 * mn * mn));
  std::vector<std::map<long long, double>> gs(m + 1);
  gs[0][0] = 1;
  for (long long u = 0; u <= nn; u++) {
    std::vector<std::map<long long, double>> next(m + 1);
    std::map<long long, double> tmp;
    for (long long v = 0; v <= mm; v++) {
      for (const auto &kv : gs[v])
        tmp[kv.first] += kv.second;
      long long add = (A * v - B * u) * (A * v - B * u);
      std::map<long long, double> sh;
      for (const auto &kv : tmp)
        sh[kv.first + add] = kv.second;
      tmp.swap(sh);
      next[v] = tmp;
    }
    gs.swap(next);
  }
  double cnt = 0, tot = 0;
  for (const auto &kv : gs[m]) {
    tot += kv.second;
    if (double(kv.first) >= zeta)
      cnt += kv.second;
  }
  return cnt / tot;
}

// Barnard's and Boschloo's tests: maximum over the nuisance parameter
// (statistics and comparisons written as SciPy writes them, so ties agree)
double barnardBoschloo(const Mat &t, const std::string &alt, bool boschloo, double &stat) {
  int n1 = static_cast<int>(t(0, 0) + t(1, 0)), n2 = static_cast<int>(t(0, 1) + t(1, 1));
  int x1o = static_cast<int>(t(0, 0)), x2o = static_cast<int>(t(0, 1));
  if (boschloo && alt == "two-sided") {
    double sl, sg;
    double pl = barnardBoschloo(t, "less", true, sl), pg = barnardBoschloo(t, "greater", true, sg);
    stat = pl < pg ? sl : sg;
    return std::min(1.0, 2 * std::min(pl, pg));
  }
  auto wald = [&](int x1, int x2) {
    double p1 = double(x1) / n1, p2 = double(x2) / n2;
    if (p1 == p2)
      return 0.0;
    double p = double(x1 + x2) / (n1 + n2);
    return (p1 - p2) / std::sqrt(p * (1 - p) * (1.0 / n1 + 1.0 / n2));
  };
  // hypergeometric cdf of the first column (less) or of the second (greater)
  auto fisherStat = [&](int x1, int x2) {
    return alt == "less" ? fisherP(x1, x2, n1 - x1, n2 - x2, "less") : fisherP(x2, x1, n2 - x2, n1 - x1, "less");
  };
  std::vector<std::vector<char>> ind(n1 + 1, std::vector<char>(n2 + 1, 0));
  if (!boschloo) {
    double T0 = wald(x1o, x2o);
    stat = T0;
    for (int i = 0; i <= n1; i++)
      for (int j = 0; j <= n2; j++) {
        double T = wald(i, j);
        ind[i][j] = alt == "two-sided" ? std::fabs(T) >= std::fabs(T0) : alt == "less" ? T <= T0 : T >= T0;
      }
  } else {
    double F0 = fisherStat(x1o, x2o);
    stat = F0;
    for (int i = 0; i <= n1; i++)
      for (int j = 0; j <= n2; j++)
        ind[i][j] = fisherStat(i, j) <= F0 * (1 + 1e-13);
  }
  auto pval = [&](double pi) {
    if (pi <= 0 || pi >= 1)
      return 0.0;
    double s = 0;
    for (int i = 0; i <= n1; i++) {
      double li = std::lgamma(n1 + 1.0) - std::lgamma(i + 1.0) - std::lgamma(n1 - i + 1.0) + i * std::log(pi) + (n1 - i) * std::log1p(-pi);
      for (int j = 0; j <= n2; j++)
        if (ind[i][j])
          s += std::exp(li + std::lgamma(n2 + 1.0) - std::lgamma(j + 1.0) - std::lgamma(n2 - j + 1.0) + j * std::log(pi) +
                        (n2 - j) * std::log1p(-pi));
    }
    return s;
  };
  double best = 0, bx = 0.5;
  for (int k = 1; k < 2000; k++) {
    double v = pval(k / 2000.0);
    if (v > best) {
      best = v;
      bx = k / 2000.0;
    }
  }
  double xm = minimize1([&](double pi) { return -pval(std::min(std::max(pi, 1e-12), 1 - 1e-12)); }, bx - 5e-4, bx + 5e-4, 1e-12);
  best = std::max(best, pval(std::min(std::max(xm, 1e-12), 1 - 1e-12)));
  return std::min(1.0, best);
}

} // namespace

void registerStTests(Registry &reg) {
  // ---- correlation ----
  SP_ADD("pearsonr", 2, 5, "x, y, alternative, method, n") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    double r = pearson(x, y), n = x.size();
    std::string method = optText(a, 3, "exact");
    double p;
    if (method == "permutation" || method == "montecarlo") {
      long long reps = optInt(a, 4, 9999);
      if (reps < 1 || reps > 10000000) {
        ctx.fail("n must be from 1 to 10000000");
        return Value(0.0);
      }
      std::mt19937_64 g(12345 ^ static_cast<unsigned long long>(n));
      double cnt = 0;
      Vec yy(y);
      for (long long i = 0; i < reps; i++) {
        if (method == "permutation")
          std::shuffle(yy.begin(), yy.end(), g);
        else
          for (double &v : yy)
            v = pd::stdNormal(g);
        double rr = pearson(x, yy);
        bool hit = alt == "less" ? rr <= r : alt == "greater" ? rr >= r : std::fabs(rr) >= std::fabs(r) - 1e-14;
        cnt += hit;
      }
      p = (cnt + 1) / (reps + 1);
    } else if (method == "exact") {
      // r has the beta(n/2 - 1, n/2 - 1) law on [-1, 1] under the null
      double ab = n / 2 - 1;
      double cdfr = sf::betainc(ab, ab, (r + 1) / 2), sfr = sf::betaincc(ab, ab, (r + 1) / 2);
      p = pAlt(cdfr, sfr, alt);
    } else {
      ctx.fail("method must be \"exact\", \"permutation\" or \"montecarlo\"");
      return Value(0.0);
    }
    return sp(r, p);
  } SP_END

  SP_ADD("pearsonr_ci", 2, 5, "x, y, method, n, confidence") {
    Vec x, y;
    if (!getData(a, 0, ctx, x, 4) || !getData(a, 1, ctx, y, 4))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    std::string m = optText(a, 2, "fisher");
    double conf = optNum(a, 4, 0.95);
    double r = pearson(x, y), n = x.size(), lo, hi;
    if (m == "fisher") {
      double z = std::atanh(r), se = 1 / std::sqrt(n - 3), zc = sf::ndtri(0.5 + conf / 2);
      lo = std::tanh(z - zc * se);
      hi = std::tanh(z + zc * se);
    } else if (m == "bootstrap") {
      long long reps = optInt(a, 3, 9999);
      if (reps < 2 || reps > 1000000) {
        ctx.fail("n must be from 2 to 1000000");
        return Value(0.0);
      }
      std::mt19937_64 g(54321);
      Vec rs(reps), xb(x.size()), yb(x.size());
      for (long long b = 0; b < reps; b++) {
        for (size_t i = 0; i < x.size(); i++) {
          size_t k = static_cast<size_t>(pd::uniform01(g) * x.size());
          xb[i] = x[k];
          yb[i] = y[k];
        }
        rs[b] = pearson(xb, yb);
      }
      lo = quantile(rs, (1 - conf) / 2);
      hi = quantile(rs, 1 - (1 - conf) / 2);
    } else {
      ctx.fail("method must be \"fisher\" or \"bootstrap\"");
      return Value(0.0);
    }
    return makeDict({{"low", Value(lo)}, {"high", Value(hi)}});
  } SP_END

  SP_ADD("point_biserial", 2, 2, "x, y") {
    Vec x, y;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    double r = pearson(x, y), ab = x.size() / 2.0 - 1;
    return sp(r, pAlt(sf::betainc(ab, ab, (r + 1) / 2), sf::betaincc(ab, ab, (r + 1) / 2), "two-sided"));
  } SP_END

  auto spearman = [](const Args &a, CallContext &ctx) -> Value {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    double r = pearson(rankdata(x), rankdata(y)), n = x.size(), df = n - 2;
    double t = r * std::sqrt(df / ((r + 1) * (1 - r)));
    double p = std::fabs(r) >= 1 ? (alt == "two-sided" ? 0.0 : ((alt == "greater") == (r > 0) ? 0.0 : 1.0)) : tP(t, df, alt);
    return sp(r, p);
  };
  reg.add(makeSpec("spearmanr", SP_SEC, 2, 3, "x, y, alternative", spearman, false));
  reg.add(makeSpec("spearman_rho", SP_SEC, 2, 3, "x, y, alternative", spearman, false));

  SP_ADD("kendalltau", 2, 4, "x, y, variant, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 3, ctx, alt))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    std::string var = optText(a, 2, "b");
    double P, Q, tx, ty, n = x.size();
    kendallCounts(x, y, P, Q, tx, ty);
    double tot = n * (n - 1) / 2;
    // pairs tied in both are excluded from both denominators' counts of n0 - n1 / n0 - n2
    Vec xt = tieCounts(x), yt = tieCounts(y);
    double sx = 0, sy = 0;
    for (double t : xt)
      sx += t * (t - 1) / 2;
    for (double t : yt)
      sy += t * (t - 1) / 2;
    double tau;
    if (var == "b")
      tau = (P - Q) / std::sqrt((tot - sx) * (tot - sy));
    else if (var == "c") {
      Vec ux = sorted(x), uy = sorted(y);
      double kx = std::unique(ux.begin(), ux.end()) - ux.begin(), ky = std::unique(uy.begin(), uy.end()) - uy.begin();
      double m = std::min(kx, ky);
      tau = 2 * (P - Q) / (n * n * (m - 1) / m);
    } else {
      ctx.fail("variant must be \"b\" or \"c\"");
      return Value(0.0);
    }
    double p;
    bool noTies = sx == 0 && sy == 0;
    double dis = Q;
    if (noTies && (n <= 33 || std::min(dis, tot - dis) <= 1)) {
      Vec d = mahonian(static_cast<int>(n));
      double cl = cdfAt(d, dis), cu = sfAt(d, dis); // small inversions = positive association
      p = alt == "greater" ? cl : alt == "less" ? cu : std::min(1.0, 2 * std::min(cl, cu));
    } else {
      double m = n * (n - 1);
      double v1 = 0, v2 = 0, v3x = 0, v3y = 0, vx = 0, vy = 0;
      for (double t : xt) {
        v1 += t * (t - 1) * (2 * t + 5);
        vx += t * (t - 1);
        v3x += t * (t - 1) * (t - 2);
      }
      for (double t : yt) {
        v2 += t * (t - 1) * (2 * t + 5);
        vy += t * (t - 1);
        v3y += t * (t - 1) * (t - 2);
      }
      double varS = (m * (2 * n + 5) - v1 - v2) / 18 + vx * vy / (2 * m) + v3x * v3y / (9 * m * (n - 2));
      double z = (P - Q) / std::sqrt(varS);
      p = normP(z, alt);
    }
    return sp(tau, p);
  } SP_END

  SP_ADD("weighted_tau", 2, 3, "x, y, rank") {
    Vec x, y;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    size_t n = x.size();
    // hyperbolic weights 1/(r + 1) of the ranks by decreasing importance, additive pair weights
    auto tauBy = [&](const Vec &p, const Vec &s) {
      std::vector<size_t> idx(n);
      std::iota(idx.begin(), idx.end(), 0);
      std::stable_sort(idx.begin(), idx.end(), [&](size_t i, size_t j) {
        if (p[i] != p[j])
          return p[i] > p[j];
        return s[i] > s[j];
      });
      Vec rank(n);
      for (size_t k = 0; k < n; k++)
        rank[idx[k]] = double(k);
      double num = 0, dx = 0, dy = 0;
      for (size_t i = 0; i < n; i++)
        for (size_t j = i + 1; j < n; j++) {
          double w = 1 / (rank[i] + 1) + 1 / (rank[j] + 1);
          double sx = (x[i] > x[j]) - (x[i] < x[j]), sy = (y[i] > y[j]) - (y[i] < y[j]);
          num += w * sx * sy;
          dx += w * (sx != 0);
          dy += w * (sy != 0);
        }
      return num / std::sqrt(dx * dy);
    };
    double t = optBool(a, 2, true) ? 0.5 * (tauBy(x, y) + tauBy(y, x)) : tauBy(x, y);
    return sp(t, kNaN);
  } SP_END

  SP_ADD("somers_d", 1, 3, "x, y, alternative") {
    Mat A;
    std::string alt;
    if (!altArg(a, 2, ctx, alt))
      return Value(0.0);
    bool table = a.size() == 1 || (isOmitted(a, 1) && a[0].isMatrix && a[0].rows() > 1);
    if (table) {
      if (!getMat(a, 0, ctx, A))
        return Value(0.0);
    } else {
      Vec x, y;
      if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y))
        return Value(0.0);
      if (x.size() != y.size()) {
        ctx.fail("x and y must have the same length");
        return Value(0.0);
      }
      Vec ux = sorted(x), uy = sorted(y);
      ux.erase(std::unique(ux.begin(), ux.end()), ux.end());
      uy.erase(std::unique(uy.begin(), uy.end()), uy.end());
      A = Mat(ux.size(), uy.size());
      for (size_t i = 0; i < x.size(); i++)
        A(std::lower_bound(ux.begin(), ux.end(), x[i]) - ux.begin(), std::lower_bound(uy.begin(), uy.end(), y[i]) - uy.begin()) += 1;
    }
    if (A.r <= 1 || A.c <= 1)
      return makeDict({{"statistic", Value(kNaN)}, {"pvalue", Value(kNaN)}, {"table", toValue(A)}});
    double NA = 0;
    for (double v : A.a)
      NA += v;
    double PA = 0, QA = 0, AD2 = 0, Sri2 = 0;
    for (size_t i = 0; i < A.r; i++) {
      double rs = 0;
      for (size_t j = 0; j < A.c; j++)
        rs += A(i, j);
      Sri2 += rs * rs;
    }
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < A.c; j++) {
        double conc = 0, disc = 0;
        for (size_t k = 0; k < A.r; k++)
          for (size_t l = 0; l < A.c; l++) {
            if ((k < i && l < j) || (k > i && l > j))
              conc += A(k, l);
            if ((k < i && l > j) || (k > i && l < j))
              disc += A(k, l);
          }
        PA += A(i, j) * conc;
        QA += A(i, j) * disc;
        AD2 += A(i, j) * (conc - disc) * (conc - disc);
      }
    double d = (PA - QA) / (NA * NA - Sri2);
    double S = AD2 - (PA - QA) * (PA - QA) / NA;
    double Z = (PA - QA) / std::sqrt(4 * S);
    return makeDict({{"statistic", Value(d)}, {"pvalue", Value(normP(Z, alt))}, {"table", toValue(A)}});
  } SP_END

  SP_ADD("chatterjee_xi", 2, 3, "x, y, y_continuous") {
    Vec x, y;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    size_t n = x.size();
    std::vector<size_t> idx(n);
    std::iota(idx.begin(), idx.end(), 0);
    std::stable_sort(idx.begin(), idx.end(), [&](size_t i, size_t j) { return x[i] < x[j]; });
    Vec ys(n);
    for (size_t k = 0; k < n; k++)
      ys[k] = y[idx[k]];
    Vec r = rankdata(ys, "max"), l(n);
    Vec neg(n);
    for (size_t k = 0; k < n; k++)
      neg[k] = -ys[k];
    l = rankdata(neg, "max");
    double num = 0, den = 0;
    for (size_t k = 0; k + 1 < n; k++)
      num += std::fabs(r[k + 1] - r[k]);
    for (size_t k = 0; k < n; k++)
      den += l[k] * (n - l[k]);
    double xi = 1 - n * num / (2 * den);
    double sd;
    if (optBool(a, 2, false))
      sd = std::sqrt(2.0 / 5.0 / n);
    else {
      // Chatterjee (2021), Theorem 2.2 variance for possibly tied y
      Vec u = sorted(r);
      double nn = n, an = 0, bn = 0, cn = 0, dn = 0;
      for (size_t i = 0; i < n; i++)
        an += (2 * nn - 2 * (i + 1) + 1) * u[i] * u[i];
      an /= nn * nn * nn * nn;
      Vec cu(n);
      double run = 0;
      for (size_t i = 0; i < n; i++) {
        run += u[i];
        cu[i] = run;
      }
      for (size_t i = 0; i < n; i++)
        bn += (cu[i] + (nn - (i + 1)) * u[i]) * (cu[i] + (nn - (i + 1)) * u[i]);
      bn /= nn * nn * nn * nn * nn;
      for (size_t i = 0; i < n; i++)
        cn += (2 * nn - 2 * (i + 1) + 1) * u[i];
      cn /= nn * nn * nn;
      for (size_t k = 0; k < n; k++)
        dn += l[k] * (nn - l[k]);
      dn /= nn * nn * nn;
      double tau2 = (an - 2 * bn + cn * cn) / (dn * dn);
      sd = std::sqrt(tau2 / nn);
    }
    return sp(xi, sf::ndtr(-xi / sd));
  } SP_END

  SP_ADD("theil_slopes", 2, 3, "y, x, alpha") {
    Vec y, x;
    if (!getData(a, 0, ctx, y, 2))
      return Value(0.0);
    if (a.size() > 1 && !isOmitted(a, 1)) {
      if (!getData(a, 1, ctx, x, 2))
        return Value(0.0);
    } else {
      x.resize(y.size());
      for (size_t i = 0; i < y.size(); i++)
        x[i] = double(i);
    }
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    double alpha = optNum(a, 2, 0.95);
    Vec slopes;
    for (size_t i = 0; i < x.size(); i++)
      for (size_t j = 0; j < x.size(); j++)
        if (x[j] > x[i])
          slopes.push_back((y[j] - y[i]) / (x[j] - x[i]));
    if (slopes.empty()) {
      ctx.fail("all x values are equal");
      return Value(0.0);
    }
    std::sort(slopes.begin(), slopes.end());
    double slope = median(slopes), icpt = median(y) - slope * median(x);
    if (alpha > 0.5)
      alpha = 1 - alpha;
    double z = sf::ndtri(alpha / 2), nt = slopes.size(), ny = y.size();
    double sig = ny * (ny - 1) * (2 * ny + 5);
    for (double k : tieCounts(x))
      if (k > 1)
        sig -= k * (k - 1) * (2 * k + 5);
    for (double k : tieCounts(y))
      if (k > 1)
        sig -= k * (k - 1) * (2 * k + 5);
    double sigma = std::sqrt(sig / 18);
    long long Ru = std::min<long long>(std::llround((nt - z * sigma) / 2), (long long)nt - 1);
    long long Rl = std::max<long long>(std::llround((nt + z * sigma) / 2) - 1, 0);
    return makeDict({{"slope", Value(slope)}, {"intercept", Value(icpt)}, {"low_slope", Value(slopes[Rl])},
                     {"high_slope", Value(slopes[Ru])}});
  } SP_END

  SP_ADD("siegel_slopes", 2, 3, "y, x, method") {
    Vec y, x;
    if (!getData(a, 0, ctx, y, 2))
      return Value(0.0);
    if (a.size() > 1 && !isOmitted(a, 1)) {
      if (!getData(a, 1, ctx, x, 2))
        return Value(0.0);
    } else {
      x.resize(y.size());
      for (size_t i = 0; i < y.size(); i++)
        x[i] = double(i);
    }
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    std::string method = optText(a, 2, "hierarchical");
    size_t n = x.size();
    Vec meds, icps;
    for (size_t i = 0; i < n; i++) {
      Vec s, c;
      for (size_t j = 0; j < n; j++)
        if (x[j] != x[i]) {
          s.push_back((y[j] - y[i]) / (x[j] - x[i]));
          c.push_back((x[j] * y[i] - x[i] * y[j]) / (x[j] - x[i]));
        }
      if (!s.empty()) {
        meds.push_back(median(s));
        icps.push_back(median(c));
      }
    }
    double slope = median(meds), icpt;
    if (method == "separate")
      icpt = median(icps);
    else {
      Vec r(n);
      for (size_t i = 0; i < n; i++)
        r[i] = y[i] - slope * x[i];
      icpt = median(r);
    }
    return makeDict({{"slope", Value(slope)}, {"intercept", Value(icpt)}});
  } SP_END

  // ---- t tests ----
  SP_ADD("ttest_1samp", 2, 3, "data, popmean, alternative") {
    Vec x;
    double mu;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !argNumber(a, 1, ctx, mu) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    double n = x.size(), t = (mean(x) - mu) / std::sqrt(var(x) / n);
    return spdf(t, tP(t, n - 1, alt), n - 1);
  } SP_END

  SP_ADD("ttest_ind", 2, 4, "a, b, equal_var, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 3, ctx, alt))
      return Value(0.0);
    bool eq = optBool(a, 2, true);
    double n1 = x.size(), n2 = y.size(), v1 = var(x), v2 = var(y), t, df;
    if (eq) {
      df = n1 + n2 - 2;
      double sp2 = ((n1 - 1) * v1 + (n2 - 1) * v2) / df;
      t = (mean(x) - mean(y)) / std::sqrt(sp2 * (1 / n1 + 1 / n2));
    } else {
      double a1 = v1 / n1, a2 = v2 / n2;
      t = (mean(x) - mean(y)) / std::sqrt(a1 + a2);
      df = (a1 + a2) * (a1 + a2) / (a1 * a1 / (n1 - 1) + a2 * a2 / (n2 - 1));
    }
    return spdf(t, tP(t, df, alt), df);
  } SP_END

  SP_ADD("ttest_from_stats", 6, 8, "mean1, std1, n1, mean2, std2, n2, equal_var, alternative") {
    double m1, s1, n1, m2, s2, n2;
    std::string alt;
    if (!argNumber(a, 0, ctx, m1) || !argNumber(a, 1, ctx, s1) || !argNumber(a, 2, ctx, n1) || !argNumber(a, 3, ctx, m2) ||
        !argNumber(a, 4, ctx, s2) || !argNumber(a, 5, ctx, n2) || !altArg(a, 7, ctx, alt))
      return Value(0.0);
    bool eq = optBool(a, 6, true);
    double t, df;
    if (eq) {
      df = n1 + n2 - 2;
      double sp2 = ((n1 - 1) * s1 * s1 + (n2 - 1) * s2 * s2) / df;
      t = (m1 - m2) / std::sqrt(sp2 * (1 / n1 + 1 / n2));
    } else {
      double a1 = s1 * s1 / n1, a2 = s2 * s2 / n2;
      t = (m1 - m2) / std::sqrt(a1 + a2);
      df = (a1 + a2) * (a1 + a2) / (a1 * a1 / (n1 - 1) + a2 * a2 / (n2 - 1));
    }
    return spdf(t, tP(t, df, alt), df);
  } SP_END

  SP_ADD("ttest_rel", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("the samples must have the same length");
      return Value(0.0);
    }
    Vec d(x.size());
    for (size_t i = 0; i < x.size(); i++)
      d[i] = x[i] - y[i];
    double n = d.size(), t = mean(d) / std::sqrt(var(d) / n);
    return spdf(t, tP(t, n - 1, alt), n - 1);
  } SP_END

  SP_ADD("binom_test", 2, 4, "k, n, p, alternative") {
    double k, n;
    std::string alt;
    if (!argNumber(a, 0, ctx, k) || !argNumber(a, 1, ctx, n) || !altArg(a, 3, ctx, alt))
      return Value(0.0);
    double p = optNum(a, 2, 0.5);
    if (k < 0 || n < 1 || k > n || k != std::floor(k) || n != std::floor(n) || p < 0 || p > 1) {
      ctx.fail("needs whole numbers 0 <= k <= n, n >= 1 and 0 <= p <= 1");
      return Value(0.0);
    }
    return sp(k / n, binomTestP(k, n, p, alt));
  } SP_END

  SP_ADD("quantile_test", 1, 4, "data, q, p, alternative") {
    Vec x;
    std::string alt;
    if (!getData(a, 0, ctx, x) || !altArg(a, 3, ctx, alt))
      return Value(0.0);
    double q = optNum(a, 1, 0), p = optNum(a, 2, 0.5), n = x.size(), T1 = 0, T2 = 0;
    for (double v : x) {
      T1 += v <= q;
      T2 += v < q;
    }
    double pl = sf::bdtr(T1, n, p), pg = sf::bdtrc(T2 - 1, n, p);
    if (alt == "less")
      return sp(T1, pl);
    if (alt == "greater")
      return sp(T2, pg);
    return sp(pl <= pg ? T1 : T2, std::min(1.0, 2 * std::min(pl, pg)));
  } SP_END

  // ---- normality ----
  SP_ADD("skew_test", 1, 2, "data, alternative") {
    Vec x;
    std::string alt;
    if (!getData(a, 0, ctx, x, 8) || !altArg(a, 1, ctx, alt))
      return Value(0.0);
    double n = x.size(), b2 = skewness(x);
    double y = b2 * std::sqrt((n + 1) * (n + 3) / (6 * (n - 2)));
    double beta2 = 3 * (n * n + 27 * n - 70) * (n + 1) * (n + 3) / ((n - 2) * (n + 5) * (n + 7) * (n + 9));
    double W2 = -1 + std::sqrt(2 * (beta2 - 1)), delta = 1 / std::sqrt(0.5 * std::log(W2)), al = std::sqrt(2 / (W2 - 1));
    if (y == 0)
      y = 1;
    double Z = delta * std::log(y / al + std::sqrt((y / al) * (y / al) + 1));
    return sp(Z, normP(Z, alt));
  } SP_END

  SP_ADD("kurtosis_test", 1, 2, "data, alternative") {
    Vec x;
    std::string alt;
    if (!getData(a, 0, ctx, x, 5) || !altArg(a, 1, ctx, alt))
      return Value(0.0);
    double n = x.size(), b2 = kurtosis(x, false);
    double E = 3 * (n - 1) / (n + 1), vb2 = 24 * n * (n - 2) * (n - 3) / ((n + 1) * (n + 1) * (n + 3) * (n + 5));
    double xx = (b2 - E) / std::sqrt(vb2);
    double sb1 = 6 * (n * n - 5 * n + 2) / ((n + 7) * (n + 9)) * std::sqrt(6 * (n + 3) * (n + 5) / (n * (n - 2) * (n - 3)));
    double A = 6 + 8 / sb1 * (2 / sb1 + std::sqrt(1 + 4 / (sb1 * sb1)));
    double t1 = 1 - 2 / (9 * A), den = 1 + xx * std::sqrt(2 / (A - 4));
    double t2 = (den < 0 ? -1.0 : 1.0) * std::cbrt((1 - 2 / A) / std::fabs(den));
    double Z = (t1 - t2) / std::sqrt(2 / (9 * A));
    return sp(Z, normP(Z, alt));
  } SP_END

  SP_ADD("normal_test", 1, 1, "data") {
    Vec x;
    if (!getData(a, 0, ctx, x, 8))
      return Value(0.0);
    double n = x.size();
    double b2 = skewness(x), y = b2 * std::sqrt((n + 1) * (n + 3) / (6 * (n - 2)));
    double beta2 = 3 * (n * n + 27 * n - 70) * (n + 1) * (n + 3) / ((n - 2) * (n + 5) * (n + 7) * (n + 9));
    double W2 = -1 + std::sqrt(2 * (beta2 - 1)), delta = 1 / std::sqrt(0.5 * std::log(W2)), al = std::sqrt(2 / (W2 - 1));
    if (y == 0)
      y = 1;
    double s = delta * std::log(y / al + std::sqrt((y / al) * (y / al) + 1));
    double k2 = kurtosis(x, false), E = 3 * (n - 1) / (n + 1);
    double vb2 = 24 * n * (n - 2) * (n - 3) / ((n + 1) * (n + 1) * (n + 3) * (n + 5));
    double xx = (k2 - E) / std::sqrt(vb2);
    double sb1 = 6 * (n * n - 5 * n + 2) / ((n + 7) * (n + 9)) * std::sqrt(6 * (n + 3) * (n + 5) / (n * (n - 2) * (n - 3)));
    double A = 6 + 8 / sb1 * (2 / sb1 + std::sqrt(1 + 4 / (sb1 * sb1)));
    double t1 = 1 - 2 / (9 * A), den = 1 + xx * std::sqrt(2 / (A - 4));
    double t2 = (den < 0 ? -1.0 : 1.0) * std::cbrt((1 - 2 / A) / std::fabs(den));
    double k = (t1 - t2) / std::sqrt(2 / (9 * A));
    double K2 = s * s + k * k;
    return sp(K2, chi2sf(K2, 2));
  } SP_END

  SP_ADD("jarque_bera", 1, 1, "data") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    double n = x.size(), S = skewness(x), K = kurtosis(x);
    double jb = n / 6 * (S * S + K * K / 4);
    return sp(jb, chi2sf(jb, 2));
  } SP_END

  SP_ADD("shapiro", 1, 1, "data") {
    Vec x;
    if (!getData(a, 0, ctx, x, 3))
      return Value(0.0);
    if (x.size() > 5000) {
      ctx.fail("at most 5000 values");
      return Value(0.0);
    }
    double W, p;
    if (!swilk(x, W, p)) {
      ctx.fail("the data must not all be equal");
      return Value(0.0);
    }
    return sp(W, p);
  } SP_END

  SP_ADD("anderson", 1, 2, "data, dist") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    std::string d = optText(a, 1, "norm");
    double n = x.size();
    Vec s = sorted(x), lc(x.size()), ls(x.size()), crit, sig;
    if (d == "norm") {
      double m = mean(x), sd = std::sqrt(var(x, 1));
      for (size_t i = 0; i < s.size(); i++) {
        double z = (s[i] - m) / sd;
        lc[i] = sf::log_ndtr(z);
        ls[i] = sf::log_ndtr(-z);
      }
      for (double v : {0.576, 0.656, 0.787, 0.918, 1.092})
        crit.push_back(std::round(v / (1 + 4 / n - 25 / (n * n)) * 1000) / 1000);
      sig = {15, 10, 5, 2.5, 1};
    } else if (d == "expon") {
      double m = mean(x);
      for (size_t i = 0; i < s.size(); i++) {
        double z = s[i] / m;
        lc[i] = std::log(-std::expm1(-z));
        ls[i] = -z;
      }
      for (double v : {0.922, 1.078, 1.341, 1.606, 1.957})
        crit.push_back(std::round(v / (1 + 0.6 / n) * 1000) / 1000);
      sig = {15, 10, 5, 2.5, 1};
    } else if (d == "logistic" || d == "gumbel" || d == "gumbel_r" || d == "gumbel_l") {
      // maximum-likelihood fit of loc and scale
      bool logi = d == "logistic", left = d == "gumbel_l";
      auto nll = [&](double loc, double sc) {
        if (sc <= 0)
          return kInf;
        double l = 0;
        for (double v : x) {
          double z = (v - loc) / sc;
          if (logi)
            l += -z - 2 * std::log1p(std::exp(-z)) - std::log(sc);
          else if (left)
            l += z - std::exp(z) - std::log(sc);
          else
            l += -z - std::exp(-z) - std::log(sc);
        }
        return -l;
      };
      double loc = mean(x), sc = std::sqrt(var(x, 1));
      for (int it = 0; it < 60; it++) {
        loc = minimize1([&](double t) { return nll(t, sc); }, loc - sc, loc + sc, 1e-13);
        double ns = minimize1([&](double t) { return nll(loc, std::exp(t)); }, std::log(sc) - 0.5, std::log(sc) + 0.5, 1e-13);
        if (std::fabs(std::exp(ns) - sc) < 1e-14 * sc)
          break;
        sc = std::exp(ns);
      }
      for (size_t i = 0; i < s.size(); i++) {
        double z = (s[i] - loc) / sc;
        if (logi) {
          lc[i] = -std::log1p(std::exp(-z));
          ls[i] = -std::log1p(std::exp(z));
        } else if (left) {
          lc[i] = std::log(-std::expm1(-std::exp(z)));
          ls[i] = -std::exp(z);
        } else {
          lc[i] = -std::exp(-z);
          ls[i] = std::log(-std::expm1(-std::exp(-z)));
        }
      }
      if (logi) {
        for (double v : {0.426, 0.563, 0.660, 0.769, 0.906, 1.010})
          crit.push_back(std::round(v / (1 + 0.25 / n) * 1000) / 1000);
        sig = {25, 10, 5, 2.5, 1, 0.5};
      } else {
        for (double v : {0.474, 0.637, 0.757, 0.877, 1.038})
          crit.push_back(std::round(v / (1 + 0.2 / std::sqrt(n)) * 1000) / 1000);
        sig = {25, 10, 5, 2.5, 1};
      }
    } else {
      ctx.fail("dist must be \"norm\", \"expon\", \"logistic\", \"gumbel_l\" or \"gumbel_r\"");
      return Value(0.0);
    }
    double A2 = -n;
    for (size_t i = 0; i < s.size(); i++)
      A2 -= (2.0 * (i + 1) - 1) / n * (lc[i] + ls[s.size() - 1 - i]);
    return makeDict({{"statistic", Value(A2)}, {"critical_values", toValue(crit)}, {"significance_level", toValue(sig)}});
  } SP_END

  // ---- two-sample and k-sample tests ----
  SP_ADD("mann_whitney", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    Vec r = rankdata(all);
    double n1 = x.size(), n2 = y.size(), R1 = 0;
    for (size_t i = 0; i < x.size(); i++)
      R1 += r[i];
    double U1 = R1 - n1 * (n1 + 1) / 2, U2 = n1 * n2 - U1;
    Vec tc = tieCounts(all);
    bool ties = false;
    for (double t : tc)
      ties = ties || t > 1;
    double p;
    if (n1 <= 8 && n2 <= 8 && !ties) {
      Vec d = mannWhitneyDist(static_cast<int>(n1), static_cast<int>(n2));
      if (alt == "greater")
        p = sfAt(d, U1);
      else if (alt == "less")
        p = sfAt(d, U2);
      else
        p = std::min(1.0, 2 * sfAt(d, std::max(U1, U2)));
    } else {
      double N = n1 + n2, mu = n1 * n2 / 2, tsum = 0;
      for (double t : tc)
        tsum += t * t * t - t;
      double s = std::sqrt(n1 * n2 / 12 * ((N + 1) - tsum / (N * (N - 1))));
      double U = alt == "greater" ? U1 : alt == "less" ? U2 : std::max(U1, U2);
      double z = (U - mu - 0.5) / s;
      p = sf::ndtr(-z);
      if (alt == "two-sided")
        p = std::min(1.0, 2 * p);
    }
    return sp(U1, p);
  } SP_END

  SP_ADD("wilcoxon", 1, 3, "d, y, alternative") {
    Vec d, y;
    std::string alt = "two-sided";
    if (!getData(a, 0, ctx, d))
      return Value(0.0);
    size_t altPos = 1;
    if (a.size() > 1 && !a[1].isText) {
      if (!getVec(a, 1, ctx, y))
        return Value(0.0);
      if (y.size() != d.size()) {
        ctx.fail("x and y must have the same length");
        return Value(0.0);
      }
      for (size_t i = 0; i < d.size(); i++)
        d[i] -= y[i];
      altPos = 2;
    }
    if (!altArg(a, altPos, ctx, alt))
      return Value(0.0);
    Vec nz;
    bool zeros = false;
    for (double v : d) {
      if (v != 0)
        nz.push_back(v);
      else
        zeros = true;
    }
    if (nz.empty()) {
      ctx.fail("all differences are zero");
      return Value(0.0);
    }
    Vec ab(nz.size());
    for (size_t i = 0; i < nz.size(); i++)
      ab[i] = std::fabs(nz[i]);
    Vec r = rankdata(ab);
    double rp = 0, rm = 0;
    for (size_t i = 0; i < nz.size(); i++)
      (nz[i] > 0 ? rp : rm) += r[i];
    double n = nz.size(), p;
    bool ties = false;
    for (double t : tieCounts(ab))
      ties = ties || t > 1;
    double stat = alt == "two-sided" ? std::min(rp, rm) : rp;
    if (n <= 50 && !ties && !zeros) {
      Vec dist = signedRankDist(static_cast<int>(n));
      double cl = cdfAt(dist, rp), cu = sfAt(dist, rp);
      p = alt == "less" ? cl : alt == "greater" ? cu : std::min(1.0, 2 * std::min(cl, cu));
    } else {
      double mn = n * (n + 1) / 4, se = n * (n + 1) * (2 * n + 1);
      double tsum = 0;
      for (double t : tieCounts(ab))
        tsum += t * t * t - t;
      se = std::sqrt((se - tsum / 2) / 24);
      double z = (rp - mn) / se;
      p = normP(z, alt);
    }
    return sp(stat, p);
  } SP_END

  SP_ADD("rank_sums", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    Vec r = rankdata(all);
    double n1 = x.size(), n2 = y.size(), s = 0;
    for (size_t i = 0; i < x.size(); i++)
      s += r[i];
    double z = (s - n1 * (n1 + n2 + 1) / 2) / std::sqrt(n1 * n2 * (n1 + n2 + 1) / 12);
    return sp(z, normP(z, alt));
  } SP_END

  SP_ADD("brunner_munzel", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    Vec rc = rankdata(all), rx = rankdata(x), ry = rankdata(y);
    double nx = x.size(), ny = y.size();
    Vec rcx(rc.begin(), rc.begin() + x.size()), rcy(rc.begin() + x.size(), rc.end());
    double mcx = mean(rcx), mcy = mean(rcy), mx = mean(rx), my = mean(ry), Sx = 0, Sy = 0;
    for (size_t i = 0; i < x.size(); i++)
      Sx += std::pow(rcx[i] - rx[i] - mcx + mx, 2);
    for (size_t i = 0; i < y.size(); i++)
      Sy += std::pow(rcy[i] - ry[i] - mcy + my, 2);
    Sx /= nx - 1;
    Sy /= ny - 1;
    double w = nx * ny * (mcy - mcx) / ((nx + ny) * std::sqrt(nx * Sx + ny * Sy));
    double df = std::pow(nx * Sx + ny * Sy, 2) / (std::pow(nx * Sx, 2) / (nx - 1) + std::pow(ny * Sy, 2) / (ny - 1));
    // SciPy takes the p-value of -w
    double p = alt == "two-sided" ? std::min(1.0, 2 * tsf(std::fabs(w), df)) : alt == "greater" ? tsf(-w, df) : sf::stdtr(df, -w);
    return sp(w, p);
  } SP_END

  SP_ADD("ks_2samp", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    Vec sx = sorted(x), sy = sorted(y), all = sx;
    all.insert(all.end(), sy.begin(), sy.end());
    double n1 = sx.size(), n2 = sy.size(), dp = 0, dm = 0;
    for (double v : all) {
      double c1 = double(std::upper_bound(sx.begin(), sx.end(), v) - sx.begin()) / n1;
      double c2 = double(std::upper_bound(sy.begin(), sy.end(), v) - sy.begin()) / n2;
      dp = std::max(dp, c1 - c2);
      dm = std::max(dm, c2 - c1);
    }
    double D = alt == "greater" ? dp : alt == "less" ? dm : std::max(dp, dm);
    double p;
    if (alt == "two-sided" && n1 * n2 <= 10000)
      p = ks2Exact(static_cast<int>(n1), static_cast<int>(n2), D);
    else if (alt == "two-sided") {
      double en = n1 * n2 / (n1 + n2);
      p = sf::kolmogorov(std::sqrt(en) * D);
    } else {
      double m = std::max(n1, n2), n = std::min(n1, n2), z = std::sqrt(m * n / (m + n)) * D;
      double expt = -2 * z * z - 2 * z * (m + 2 * n) / std::sqrt(m * n * (m + n)) / 3.0;
      p = std::exp(expt);
    }
    return sp(D, std::max(0.0, std::min(1.0, p)));
  } SP_END

  SP_ADD("cramer_vonmises_2samp", 2, 3, "a, b, method") {
    Vec x, y;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2))
      return Value(0.0);
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    Vec r = rankdata(all);
    double nx = x.size(), ny = y.size(), N = nx + ny;
    Vec rx(r.begin(), r.begin() + x.size()), ry(r.begin() + x.size(), r.end());
    std::sort(rx.begin(), rx.end());
    std::sort(ry.begin(), ry.end());
    double u = 0;
    for (size_t i = 0; i < rx.size(); i++)
      u += nx * std::pow(rx[i] - (i + 1), 2);
    for (size_t j = 0; j < ry.size(); j++)
      u += ny * std::pow(ry[j] - (j + 1), 2);
    double k = nx * ny;
    double t = u / (k * N) - (4 * k - 1) / (6 * N);
    std::string method = optText(a, 2, "auto");
    if (method != "auto" && method != "exact" && method != "asymptotic") {
      ctx.fail("method must be \"auto\", \"exact\" or \"asymptotic\"");
      return Value(0.0);
    }
    if (method == "exact" || (method == "auto" && nx <= 20 && ny <= 20))
      return sp(t, cvm2Exact(u, x.size(), y.size()));
    // asymptotic p-value (Anderson 1962)
    double et = (1 + 1 / N) / 6;
    double vt = (N + 1) * (4 * k * N - 3 * (nx * nx + ny * ny) - 2 * k) / (45 * N * N * 4 * k);
    double tn = 1 / 6.0 + (t - et) / std::sqrt(45 * vt);
    double p;
    if (tn < 0.003)
      p = 1.0;
    else {
      // limiting distribution of the Cramer-von Mises statistic
      double tot = 0;
      for (int kk = 0; kk < 200; kk++) {
        double yy = 4 * kk + 1, q = yy * yy / (16 * tn);
        double term = std::exp(std::lgamma(kk + 0.5) - std::lgamma(kk + 1.0)) / (std::pow(kPi, 1.5) * std::sqrt(tn)) *
                      std::sqrt(yy) * std::exp(-q) * sf::besselk(0.25, q);
        tot += term;
        if (std::fabs(term) < 1e-7)
          break;
      }
      p = std::max(0.0, 1 - tot);
    }
    return sp(t, p);
  } SP_END

  SP_ADD("epps_singleton", 2, 3, "a, b, t") {
    Vec x, y, tt = {0.4, 0.8};
    if (!getData(a, 0, ctx, x, 5) || !getData(a, 1, ctx, y, 5))
      return Value(0.0);
    if (a.size() > 2 && !getVec(a, 2, ctx, tt))
      return Value(0.0);
    double nx = x.size(), ny = y.size(), n = nx + ny;
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    double sigma = (quantile(all, 0.75) - quantile(all, 0.25)) / 2;
    size_t K = 2 * tt.size();
    auto feats = [&](double v) {
      Vec f(K);
      for (size_t i = 0; i < tt.size(); i++) {
        f[i] = std::cos(tt[i] / sigma * v);
        f[tt.size() + i] = std::sin(tt[i] / sigma * v);
      }
      return f;
    };
    auto covOf = [&](const Vec &s, Vec &m) {
      Mat c(K, K);
      m.assign(K, 0.0);
      std::vector<Vec> g;
      for (double v : s)
        g.push_back(feats(v));
      for (const Vec &f : g)
        for (size_t i = 0; i < K; i++)
          m[i] += f[i] / s.size();
      for (const Vec &f : g)
        for (size_t i = 0; i < K; i++)
          for (size_t j = 0; j < K; j++)
            c(i, j) += (f[i] - m[i]) * (f[j] - m[j]) / s.size();
      return c;
    };
    Vec mx, my;
    Mat cx = covOf(x, mx), cy = covOf(y, my), est(K, K);
    for (size_t i = 0; i < K * K; i++)
      est.a[i] = n / nx * cx.a[i] + n / ny * cy.a[i];
    Vec w;
    Mat V;
    jacobiEig(est, w, V);
    double wmax = 0;
    for (double v : w)
      wmax = std::max(wmax, std::fabs(v));
    double rank = 0;
    Vec gd(K);
    for (size_t i = 0; i < K; i++)
      gd[i] = mx[i] - my[i];
    double W = 0;
    for (size_t k = 0; k < K; k++) {
      if (std::fabs(w[k]) <= wmax * K * 2.2e-16)
        continue;
      rank++;
      double proj = 0;
      for (size_t i = 0; i < K; i++)
        proj += V(i, k) * gd[i];
      W += proj * proj / w[k];
    }
    W *= n;
    if (std::max(nx, ny) < 25)
      W *= 1.0 / (1.0 + std::pow(n, -0.45) + 10.1 * (std::pow(nx, -1.7) + std::pow(ny, -1.7)));
    return sp(W, chi2sf(W, rank));
  } SP_END

  SP_ADD("ansari", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 1) || !getData(a, 1, ctx, y, 1) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    double m = x.size(), n = y.size(), N = m + n;
    double AB = ansariStat(x, y);
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    bool ties = false;
    for (double t : tieCounts(all))
      ties = ties || t > 1;
    if (m < 55 && n < 55 && !ties) {
      // exact: distribution of the sum of scores min(i, N - i + 1) over subsets of size m
      int Ni = static_cast<int>(N), mi = static_cast<int>(m), maxS = 0;
      std::vector<int> sc(Ni);
      for (int i = 1; i <= Ni; i++) {
        sc[i - 1] = std::min(i, Ni - i + 1);
        maxS += sc[i - 1];
      }
      std::vector<Vec> c(mi + 1, Vec(maxS + 1, 0.0));
      c[0][0] = 1;
      for (int i = 0; i < Ni; i++)
        for (int k = std::min(i + 1, mi); k >= 1; k--)
          for (int s = maxS; s >= sc[i]; s--)
            c[k][s] += c[k - 1][s - sc[i]];
      Vec d = c[mi];
      double tot = 0;
      for (double v : d)
        tot += v;
      double lo = 0, hi = 0;
      for (size_t s = 0; s < d.size(); s++) {
        if (s <= AB + 1e-9)
          lo += d[s];
        if (s + 1e-9 >= AB)
          hi += d[s];
      }
      lo /= tot;
      hi /= tot;
      double p = alt == "less" ? hi : alt == "greater" ? lo : std::min(1.0, 2 * std::min(lo, hi));
      return sp(AB, p);
    }
    double mnAB, varAB;
    if (static_cast<long long>(N) % 2 == 0) {
      mnAB = m * (N + 2) / 4;
      varAB = m * n * (N + 2) * (N - 2) / 48 / (N - 1);
    } else {
      mnAB = m * (N + 1) * (N + 1) / 4 / N;
      varAB = m * n * (N + 1) * (3 + N * N) / (48 * N * N);
    }
    if (ties) {
      Vec r = rankdata(all);
      double fr = 0;
      for (size_t i = 0; i < r.size(); i++) {
        double s = std::min(r[i], N - r[i] + 1);
        fr += s * s;
      }
      if (static_cast<long long>(N) % 2 == 0)
        varAB = m * n * (16 * fr - N * (N + 2) * (N + 2)) / (16 * N * (N - 1));
      else
        varAB = m * n * (16 * N * fr - (N + 1) * (N + 1) * (N + 1) * (N + 1)) / (16 * N * N * (N - 1));
    }
    double z = (mnAB - AB) / std::sqrt(varAB);
    return sp(AB, normP(z, alt));
  } SP_END

  SP_ADD("mood_test", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    double m = x.size(), n = y.size(), N = m + n;
    if (N < 3) {
      ctx.fail("needs at least 3 values in all");
      return Value(0.0);
    }
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    // with ties: each tied group shares the average of its rank scores (Mielke)
    Vec s = sorted(all);
    double T = 0;
    Vec sx = sorted(x);
    size_t i = 0;
    double E = m * (N * N - 1) / 12, VarT = 0;
    double sumPhi = 0;
    std::vector<std::pair<double, double>> grp; // (value, phibar), group size
    while (i < s.size()) {
      size_t j = i;
      while (j + 1 < s.size() && s[j + 1] == s[i])
        j++;
      double phi = 0;
      for (size_t k = i; k <= j; k++)
        phi += std::pow(k + 1 - (N + 1) / 2, 2);
      double t = double(j - i + 1);
      double cnt = double(std::upper_bound(sx.begin(), sx.end(), s[i]) - std::lower_bound(sx.begin(), sx.end(), s[i]));
      T += cnt * phi / t;
      VarT += phi * phi / t;
      sumPhi += phi;
      i = j + 1;
    }
    VarT = m * n / (N * (N - 1)) * VarT - m * n / (N * N * (N - 1)) * sumPhi * sumPhi;
    double z = (T - E) / std::sqrt(VarT);
    return sp(z, normP(z, alt));
  } SP_END

  SP_ADD("bws_test", 2, 3, "a, b, alternative") {
    Vec x, y;
    std::string alt;
    if (!getData(a, 0, ctx, x, 2) || !getData(a, 1, ctx, y, 2) || !altArg(a, 2, ctx, alt))
      return Value(0.0);
    auto stat = [&](const Vec &xx, const Vec &yy) {
      Vec all(xx);
      all.insert(all.end(), yy.begin(), yy.end());
      Vec r = rankdata(all);
      double n1 = xx.size(), n2 = yy.size();
      Vec rx(r.begin(), r.begin() + xx.size()), ry(r.begin() + xx.size(), r.end());
      std::sort(rx.begin(), rx.end());
      std::sort(ry.begin(), ry.end());
      double bx = 0, by = 0;
      for (size_t i = 0; i < rx.size(); i++) {
        double k = i + 1, f = k / (n1 + 1);
        double dd = rx[i] - (n1 + n2) / n1 * k;
        bx += dd * dd / (f * (1 - f) * n2 * (n1 + n2) / n1);
      }
      for (size_t j = 0; j < ry.size(); j++) {
        double k = j + 1, f = k / (n2 + 1);
        double dd = ry[j] - (n1 + n2) / n2 * k;
        by += dd * dd / (f * (1 - f) * n1 * (n1 + n2) / n2);
      }
      return 0.5 * (bx / n1 + by / n2);
    };
    double B = stat(x, y);
    // permutation p-value
    std::mt19937_64 g(97531);
    Vec all(x);
    all.insert(all.end(), y.begin(), y.end());
    double cnt = 0;
    const int R = 9999;
    for (int i = 0; i < R; i++) {
      std::shuffle(all.begin(), all.end(), g);
      double b = stat(Vec(all.begin(), all.begin() + x.size()), Vec(all.begin() + x.size(), all.end()));
      cnt += b >= B - 1e-12;
    }
    return sp(B, (cnt + 1) / (R + 1));
  } SP_END

  SP_ADD("poisson_means_test", 4, 6, "k1, n1, k2, n2, diff, alternative") {
    double k1, n1, k2, n2;
    std::string alt;
    if (!argNumber(a, 0, ctx, k1) || !argNumber(a, 1, ctx, n1) || !argNumber(a, 2, ctx, k2) || !argNumber(a, 3, ctx, n2) ||
        !altArg(a, 5, ctx, alt))
      return Value(0.0);
    double diff = optNum(a, 4, 0);
    if (k1 < 0 || k2 < 0 || k1 != std::floor(k1) || k2 != std::floor(k2) || n1 <= 0 || n2 <= 0 || diff < 0) {
      ctx.fail("needs whole counts k1, k2 >= 0, sizes n1, n2 > 0 and diff >= 0");
      return Value(0.0);
    }
    double l2 = (k1 + k2) / (n1 + n2) - diff * n1 / (n1 + n2);
    if (l2 <= 0)
      return sp(0, 1);
    double var = k1 / (n1 * n1) + k2 / (n2 * n2);
    double tobs = (k1 / n1 - k2 / n2 - diff) / std::sqrt(var);
    double nl1 = n1 * (l2 + diff), nl2 = n2 * l2;
    const pd::Family *P = pd::findFamily("poisson");
    double a1 = pd::ppf(*P, 1e-10, &nl1), b1 = pd::ppf(*P, 1 - 1e-16, &nl1);
    double a2 = pd::ppf(*P, 1e-10, &nl2), b2 = pd::ppf(*P, 1 - 1e-16, &nl2);
    double pv = 0;
    for (double x1 = a1; x1 <= b1; x1++)
      for (double x2 = a2; x2 <= b2; x2++) {
        double l1x = x1 / n1, l2x = x2 / n2, v = l1x / n1 + l2x / n2;
        double t = (l1x - l2x - diff) / std::sqrt(v);
        bool hit;
        if (v == 0)
          hit = alt == "two-sided" ? std::fabs(tobs) == 0 && false : false;
        else
          hit = alt == "two-sided" ? std::fabs(t) >= std::fabs(tobs) : alt == "less" ? t <= tobs : t >= tobs;
        if (v == 0 && (l1x - l2x - diff) != 0)
          hit = alt == "two-sided" ? true : (alt == "less" ? (l1x - l2x - diff) < 0 : (l1x - l2x - diff) > 0);
        if (hit)
          pv += pd::pdf(*P, x1, &nl1) * pd::pdf(*P, x2, &nl2);
      }
    return sp(tobs, pv);
  } SP_END

  // ---- 2x2 exact tests ----
  SP_ADD("fisher_exact", 1, 2, "table, alternative") {
    Mat t;
    std::string alt;
    if (!getMat(a, 0, ctx, t) || !altArg(a, 1, ctx, alt))
      return Value(0.0);
    if (t.r != 2 || t.c != 2) {
      ctx.fail("the table must be 2 x 2");
      return Value(0.0);
    }
    double or_ = (t(0, 1) * t(1, 0) == 0) ? (t(0, 0) * t(1, 1) == 0 ? kNaN : kInf) : t(0, 0) * t(1, 1) / (t(0, 1) * t(1, 0));
    return sp(or_, fisherP(t(0, 0), t(0, 1), t(1, 0), t(1, 1), alt));
  } SP_END

  SP_ADD("odds_ratio", 1, 2, "table, kind") {
    Mat t;
    if (!getMat(a, 0, ctx, t))
      return Value(0.0);
    if (t.r != 2 || t.c != 2) {
      ctx.fail("the table must be 2 x 2");
      return Value(0.0);
    }
    std::string kind = optText(a, 1, "conditional");
    double A = t(0, 0), B = t(0, 1), C = t(1, 0), D = t(1, 1);
    if (kind == "sample")
      return makeDict({{"statistic", Value((B * C == 0) ? (A * D == 0 ? kNaN : kInf) : A * D / (B * C))}});
    if (kind != "conditional") {
      ctx.fail("kind must be \"conditional\" or \"sample\"");
      return Value(0.0);
    }
    if (A == 0 && D == 0)
      return makeDict({{"statistic", Value(kNaN)}});
    if (B * C == 0)
      return makeDict({{"statistic", Value(kInf)}});
    if (A * D == 0)
      return makeDict({{"statistic", Value(0.0)}});
    // conditional MLE: the Fisher noncentral hypergeometric mean equals A
    double n1 = A + B, n2 = C + D, k = A + C;
    double lo = std::max(0.0, k - n2), hi = std::min(k, n1);
    auto meanAt = [&](double lw) {
      double mx = -kInf;
      std::vector<double> l;
      for (double x = lo; x <= hi; x++) {
        double v = std::lgamma(n1 + 1) - std::lgamma(x + 1) - std::lgamma(n1 - x + 1) + std::lgamma(n2 + 1) -
                   std::lgamma(k - x + 1) - std::lgamma(n2 - k + x + 1) + x * lw;
        l.push_back(v);
        mx = std::max(mx, v);
      }
      double s = 0, m = 0, x = lo;
      for (double v : l) {
        double w = std::exp(v - mx);
        s += w;
        m += w * x;
        x += 1;
      }
      return m / s;
    };
    double lw = sf::brent([&](double u) { return meanAt(u) - A; }, -50, 50, 1e-14, 500);
    return makeDict({{"statistic", Value(std::exp(lw))}});
  } SP_END

  SP_ADD("barnard_exact", 1, 2, "table, alternative") {
    Mat t;
    std::string alt;
    if (!getMat(a, 0, ctx, t) || !altArg(a, 1, ctx, alt))
      return Value(0.0);
    if (t.r != 2 || t.c != 2 || t.a[0] < 0 || t.a[1] < 0 || t.a[2] < 0 || t.a[3] < 0) {
      ctx.fail("the table must be 2 x 2 with non-negative counts");
      return Value(0.0);
    }
    if (t(0, 0) + t(1, 0) == 0 || t(0, 1) + t(1, 1) == 0)
      return sp(0, 1);
    double s;
    double p = barnardBoschloo(t, alt, false, s);
    return sp(s, p);
  } SP_END
  SP_ADD("boschloo_exact", 1, 2, "table, alternative") {
    Mat t;
    std::string alt;
    if (!getMat(a, 0, ctx, t) || !altArg(a, 1, ctx, alt))
      return Value(0.0);
    if (t.r != 2 || t.c != 2 || t.a[0] < 0 || t.a[1] < 0 || t.a[2] < 0 || t.a[3] < 0) {
      ctx.fail("the table must be 2 x 2 with non-negative counts");
      return Value(0.0);
    }
    if (t(0, 0) + t(1, 0) == 0 || t(0, 1) + t(1, 1) == 0)
      return sp(1, 1);
    double s;
    double p = barnardBoschloo(t, alt, true, s);
    return sp(s, p);
  } SP_END
}

} // namespace scipy
} // namespace nc
