// Section 21, distribution values: make_dist, normal_dist, uniform_dist,
// logistic_dist, binomial_dist, custom_dist, custom_discrete_dist, hist_dist,
// mixture_dist, order_stat_dist, truncate_dist, abs_dist, exp_dist, log_dist,
// their methods dist_pdf ... dist_median, and the functions that return or
// use distributions: mvs_dist, bayes_mvs, dist_fit; with censored_data and
// cov_diagonal.
#include "st_dist.h"
#include "statistics_main.h"

#include "../../ops/matrix/matrix.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace st {

// ---- generic parts of Dist ----

double Dist::ppf(double q) const {
  if (std::isnan(q) || q < 0 || q > 1)
    return kNaN;
  double a, b;
  support(a, b);
  if (q == 0)
    return discrete ? a - 1 : a;
  if (q == 1)
    return b;
  if (discrete) {
    // smallest integer k with cdf(k) >= q
    double lo = std::isfinite(a) ? a - 1 : -1, hi = std::isfinite(b) ? b : 1, step = 1;
    if (!std::isfinite(a))
      while (cdf(lo) >= q && step < 1e18) {
        lo -= step;
        step *= 2;
      }
    step = 1;
    if (!std::isfinite(b))
      while (cdf(hi) < q && step < 1e18) {
        hi += step;
        step *= 2;
      }
    while (hi - lo > 1) {
      double m = std::floor((lo + hi) / 2);
      if (cdf(m) >= q)
        hi = m;
      else
        lo = m;
      if (failed())
        return kNaN;
    }
    return hi;
  }
  double lo = a, hi = b, step = 1;
  if (!std::isfinite(a)) {
    lo = std::isfinite(b) ? b - 1 : -1;
    while (cdf(lo) > q && step < 1e300) {
      lo -= step;
      step *= 2;
    }
  }
  step = 1;
  if (!std::isfinite(b)) {
    hi = std::isfinite(a) ? a + 1 : 1;
    while (cdf(hi) < q && step < 1e300) {
      hi += step;
      step *= 2;
    }
  }
  if (failed())
    return kNaN;
  return sf::brent([&](double x) { return cdf(x) - q; }, lo, hi, 1e-15 * (1 + std::fabs(lo) + std::fabs(hi)));
}

namespace {
// sum of g(k) * pmf(k) over the support (tails below 1e-15 left out)
double discreteSum(const Dist &d, const std::function<double(double)> &g) {
  double a, b;
  d.support(a, b);
  double lo = std::isfinite(a) ? a : d.ppf(1e-15), hi = std::isfinite(b) ? b : d.ppf(1 - 1e-15);
  if (!std::isfinite(lo) || !std::isfinite(hi) || hi - lo > 1e7)
    return kNaN;
  double s = 0;
  for (double k = lo; k <= hi; k++)
    s += g(k) * d.pdf(k);
  return s;
}
} // namespace

double Dist::mean() const {
  if (discrete)
    return discreteSum(*this, [](double k) { return k; });
  double a, b;
  support(a, b);
  return sf::quad([&](double x) { return x * pdf(x); }, a, b, 1e-13, 1e-11, 400);
}
double Dist::var() const {
  double m = mean();
  if (!std::isfinite(m))
    return kNaN;
  if (discrete)
    return discreteSum(*this, [&](double k) { return (k - m) * (k - m); });
  double a, b;
  support(a, b);
  return sf::quad([&](double x) { return (x - m) * (x - m) * pdf(x); }, a, b, 1e-13, 1e-11, 400);
}

namespace {

struct FamDist : Dist {
  const pd::Family *f;
  Vec p;
  double loc, scale;
  FamDist(const pd::Family *fam, Vec shapes, double l, double s) : f(fam), p(std::move(shapes)), loc(l), scale(s) {
    discrete = f->discrete;
  }
  double pdf(double x) const override { return pd::pdfLS(*f, x, p.data(), loc, scale); }
  double cdf(double x) const override { return pd::cdfLS(*f, x, p.data(), loc, scale); }
  double sf(double x) const override { return pd::sfLS(*f, x, p.data(), loc, scale); }
  double ppf(double q) const override { return pd::ppfLS(*f, q, p.data(), loc, scale); }
  void support(double &a, double &b) const override {
    pd::support(*f, p.data(), a, b);
    double s = discrete ? 1 : scale;
    a = a * s + loc;
    b = b * s + loc;
  }
  double mean() const override { return pd::mean(*f, p.data()) * (discrete ? 1 : scale) + loc; }
  double var() const override {
    double s = discrete ? 1 : scale;
    return pd::variance(*f, p.data()) * s * s;
  }
  double rvs(std::mt19937_64 &g) const override { return pd::rvsLS(*f, g, p.data(), loc, scale); }
};

// continuous, from an NC density
struct NcPdfDist : Dist {
  mutable NcFn fn;
  double a, b;
  NcPdfDist(const Value &f, double lo, double hi) : fn(f), a(lo), b(hi) {}
  double pdf(double x) const override { return (x < a || x > b) ? 0.0 : fn.scalar(x); }
  double cdf(double x) const override {
    if (x <= a)
      return 0;
    if (x >= b)
      return 1;
    return std::min(1.0, std::max(0.0, sf::quad([&](double t) { return pdf(t); }, a, x, 1e-14, 1e-11, 400)));
  }
  void support(double &lo, double &hi) const override {
    lo = a;
    hi = b;
  }
  bool failed() const override { return fn.failed; }
};

struct TableDist : Dist { // values with probabilities
  Vec v, pr, cum;
  TableDist(const Vec &values, const Vec &probs) {
    discrete = true;
    std::vector<size_t> idx(values.size());
    std::iota(idx.begin(), idx.end(), 0);
    std::stable_sort(idx.begin(), idx.end(), [&](size_t x, size_t y) { return values[x] < values[y]; });
    double c = 0;
    for (size_t i : idx) {
      if (!v.empty() && v.back() == values[i]) {
        pr.back() += probs[i];
        c += probs[i];
        cum.back() = c;
        continue;
      }
      v.push_back(values[i]);
      pr.push_back(probs[i]);
      c += probs[i];
      cum.push_back(c);
    }
  }
  double pdf(double x) const override {
    auto it = std::lower_bound(v.begin(), v.end(), x);
    return (it != v.end() && *it == x) ? pr[it - v.begin()] : 0.0;
  }
  double cdf(double x) const override {
    auto it = std::upper_bound(v.begin(), v.end(), x);
    return it == v.begin() ? 0.0 : std::min(1.0, cum[it - v.begin() - 1]);
  }
  double ppf(double q) const override {
    if (std::isnan(q) || q < 0 || q > 1)
      return kNaN;
    if (q == 0)
      return v.front() - 1;
    for (size_t i = 0; i < v.size(); i++)
      if (cum[i] >= q - 1e-14)
        return v[i];
    return v.back();
  }
  void support(double &a, double &b) const override {
    a = v.front();
    b = v.back();
  }
  double mean() const override {
    double s = 0;
    for (size_t i = 0; i < v.size(); i++)
      s += v[i] * pr[i];
    return s;
  }
  double var() const override {
    double m = mean(), s = 0;
    for (size_t i = 0; i < v.size(); i++)
      s += (v[i] - m) * (v[i] - m) * pr[i];
    return s;
  }
};

struct HistDist : Dist {
  Vec e, pr, cum; // pr: probability of each bin
  HistDist(const Vec &counts, const Vec &edges) : e(edges) {
    double t = 0;
    for (double c : counts)
      t += c;
    double c = 0;
    cum.push_back(0);
    for (double k : counts) {
      pr.push_back(k / t);
      c += k / t;
      cum.push_back(c);
    }
  }
  size_t bin(double x) const { return std::upper_bound(e.begin(), e.end(), x) - e.begin() - 1; }
  double pdf(double x) const override {
    if (x < e.front() || x >= e.back())
      return 0;
    size_t i = bin(x);
    return pr[i] / (e[i + 1] - e[i]);
  }
  double cdf(double x) const override {
    if (x <= e.front())
      return 0;
    if (x >= e.back())
      return 1;
    size_t i = bin(x);
    return cum[i] + pr[i] * (x - e[i]) / (e[i + 1] - e[i]);
  }
  double ppf(double q) const override {
    if (std::isnan(q) || q < 0 || q > 1)
      return kNaN;
    for (size_t i = 0; i < pr.size(); i++)
      if (cum[i + 1] >= q && pr[i] > 0)
        return e[i] + (q - cum[i]) / pr[i] * (e[i + 1] - e[i]);
    return e.back();
  }
  void support(double &a, double &b) const override {
    a = e.front();
    b = e.back();
  }
  double mean() const override {
    double s = 0;
    for (size_t i = 0; i < pr.size(); i++)
      s += pr[i] * (e[i] + e[i + 1]) / 2;
    return s;
  }
  double var() const override {
    double m = mean(), s = 0;
    for (size_t i = 0; i < pr.size(); i++)
      s += pr[i] * (e[i] * e[i] + e[i] * e[i + 1] + e[i + 1] * e[i + 1]) / 3;
    return s - m * m;
  }
};

struct MixDist : Dist {
  std::vector<DistPtr> c;
  Vec w;
  double pdf(double x) const override {
    double s = 0;
    for (size_t i = 0; i < c.size(); i++)
      s += w[i] * c[i]->pdf(x);
    return s;
  }
  double cdf(double x) const override {
    double s = 0;
    for (size_t i = 0; i < c.size(); i++)
      s += w[i] * c[i]->cdf(x);
    return s;
  }
  double sf(double x) const override {
    double s = 0;
    for (size_t i = 0; i < c.size(); i++)
      s += w[i] * c[i]->sf(x);
    return s;
  }
  void support(double &a, double &b) const override {
    a = kInf;
    b = -kInf;
    for (const DistPtr &d : c) {
      double x, y;
      d->support(x, y);
      a = std::min(a, x);
      b = std::max(b, y);
    }
  }
  double mean() const override {
    double s = 0;
    for (size_t i = 0; i < c.size(); i++)
      s += w[i] * c[i]->mean();
    return s;
  }
  double var() const override {
    double m = mean(), s = 0;
    for (size_t i = 0; i < c.size(); i++) {
      double mi = c[i]->mean();
      s += w[i] * (c[i]->var() + mi * mi);
    }
    return s - m * m;
  }
  double rvs(std::mt19937_64 &g) const override {
    double u = pd::uniform01(g), s = 0;
    for (size_t i = 0; i < c.size(); i++) {
      s += w[i];
      if (u <= s)
        return c[i]->rvs(g);
    }
    return c.back()->rvs(g);
  }
  bool failed() const override {
    for (const DistPtr &d : c)
      if (d->failed())
        return true;
    return false;
  }
};

struct OrderDist : Dist { // r-th smallest of n
  DistPtr b;
  double r, n;
  OrderDist(DistPtr base, double rr, double nn) : b(std::move(base)), r(rr), n(nn) { discrete = b->discrete; }
  double pdf(double x) const override {
    if (discrete)
      return cdf(x) - cdf(x - 1);
    double F = b->cdf(x), f = b->pdf(x);
    if (f == 0)
      return 0;
    return std::exp(std::lgamma(n + 1) - std::lgamma(r) - std::lgamma(n - r + 1) + (r - 1) * std::log(F) + (n - r) * std::log1p(-F)) * f;
  }
  double cdf(double x) const override { return sf::betainc(r, n - r + 1, b->cdf(x)); }
  double sf(double x) const override { return sf::betaincc(r, n - r + 1, b->cdf(x)); }
  double ppf(double q) const override { return b->ppf(sf::betaincinv(r, n - r + 1, q)); }
  void support(double &a, double &c) const override { b->support(a, c); }
  bool failed() const override { return b->failed(); }
};

struct TruncDist : Dist {
  DistPtr b;
  double lb, ub, Flo, Z;
  TruncDist(DistPtr base, double l, double u) : b(std::move(base)), lb(l), ub(u) {
    discrete = b->discrete;
    Flo = discrete ? b->cdf(std::ceil(lb) - 1) : b->cdf(lb);
    Z = b->cdf(ub) - Flo;
  }
  double pdf(double x) const override { return (x < lb || x > ub) ? 0.0 : b->pdf(x) / Z; }
  double cdf(double x) const override {
    if (x < lb)
      return 0;
    if (x >= ub)
      return 1;
    return (b->cdf(x) - Flo) / Z;
  }
  double ppf(double q) const override {
    if (std::isnan(q) || q < 0 || q > 1)
      return kNaN;
    return std::min(ub, std::max(discrete ? std::ceil(lb) : lb, b->ppf(Flo + q * Z)));
  }
  void support(double &a, double &c) const override {
    b->support(a, c);
    a = std::max(a, lb);
    c = std::min(c, ub);
  }
  bool failed() const override { return b->failed(); }
};

enum class Tf { Abs, Exp, Log };
struct TfDist : Dist {
  DistPtr b;
  Tf t;
  TfDist(DistPtr base, Tf tf) : b(std::move(base)), t(tf) {}
  double pdf(double y) const override {
    switch (t) {
    case Tf::Abs:
      return y < 0 ? 0.0 : (y == 0 ? b->pdf(0) : b->pdf(y) + b->pdf(-y));
    case Tf::Exp:
      return y <= 0 ? 0.0 : b->pdf(std::log(y)) / y;
    default:
      return b->pdf(std::exp(y)) * std::exp(y);
    }
  }
  double cdf(double y) const override {
    switch (t) {
    case Tf::Abs:
      return y < 0 ? 0.0 : b->cdf(y) - b->cdf(-y);
    case Tf::Exp:
      return y <= 0 ? 0.0 : b->cdf(std::log(y));
    default:
      return b->cdf(std::exp(y));
    }
  }
  double sf(double y) const override {
    switch (t) {
    case Tf::Abs:
      return y < 0 ? 1.0 : b->sf(y) + b->cdf(-y);
    case Tf::Exp:
      return y <= 0 ? 1.0 : b->sf(std::log(y));
    default:
      return b->sf(std::exp(y));
    }
  }
  double ppf(double q) const override {
    if (t == Tf::Exp)
      return std::exp(b->ppf(q));
    if (t == Tf::Log)
      return std::log(b->ppf(q));
    return Dist::ppf(q);
  }
  void support(double &a, double &c) const override {
    double x, y;
    b->support(x, y);
    if (t == Tf::Abs) {
      a = (x <= 0 && y >= 0) ? 0.0 : std::min(std::fabs(x), std::fabs(y));
      c = std::max(std::fabs(x), std::fabs(y));
    } else if (t == Tf::Exp) {
      a = std::exp(x);
      c = std::exp(y);
    } else {
      a = std::log(std::max(x, 0.0));
      c = std::log(y);
    }
  }
  double rvs(std::mt19937_64 &g) const override {
    double x = b->rvs(g);
    return t == Tf::Abs ? std::fabs(x) : t == Tf::Exp ? std::exp(x) : std::log(x);
  }
  bool failed() const override { return b->failed(); }
};

double fieldNum(const Value &d, const char *k, double def) {
  const Value *v = dictGet(d, k);
  return (v && isPlainNumber(*v)) ? v->number : def;
}

DistPtr readDistAt(const Value &v, CallContext &ctx, int depth) {
  if (depth > 50) {
    ctx.fail("the distribution is nested too deeply");
    return nullptr;
  }
  if (v.isText) {
    const pd::Family *f = pd::findFamily(v.text());
    if (!f || f->arrayShape) {
      ctx.fail("unknown distribution '" + v.text() + "'");
      return nullptr;
    }
    if (f->nshape > 0) {
      ctx.fail("'" + v.text() + "' has shape parameters: build it with make_dist(\"" + v.text() + "\", params)");
      return nullptr;
    }
    return std::make_shared<FamDist>(f, Vec(), 0.0, 1.0);
  }
  const Value *kind = dictGet(v, "dist");
  if (!v.isDict || !kind || !kind->isText) {
    ctx.fail("expected a distribution (a Dict from normal_dist(), make_dist(), ...) or a family name such as \"norm\"");
    return nullptr;
  }
  std::string k = kind->text();
  auto base = [&]() -> DistPtr {
    const Value *b = dictGet(v, "base");
    if (!b) {
      ctx.fail("the distribution has no 'base' field");
      return nullptr;
    }
    return readDistAt(*b, ctx, depth + 1);
  };
  if (k == "family") {
    const Value *n = dictGet(v, "name");
    const pd::Family *f = (n && n->isText) ? pd::findFamily(n->text()) : nullptr;
    Vec sh;
    const Value *s = dictGet(v, "shapes");
    if (s)
      readVec(*s, sh);
    if (!f || f->arrayShape || int(sh.size()) != f->nshape) {
      ctx.fail("the family distribution is not valid");
      return nullptr;
    }
    return std::make_shared<FamDist>(f, sh, fieldNum(v, "loc", 0), fieldNum(v, "scale", 1));
  }
  if (k == "custom") {
    const Value *f = dictGet(v, "pdf");
    if (!f || !isCallable(*f)) {
      ctx.fail("the custom distribution has no 'pdf' function");
      return nullptr;
    }
    return std::make_shared<NcPdfDist>(*f, fieldNum(v, "a", -kInf), fieldNum(v, "b", kInf));
  }
  if (k == "discrete" || k == "histogram") {
    Vec x, y;
    const Value *vx = dictGet(v, k == "discrete" ? "values" : "counts"), *vy = dictGet(v, k == "discrete" ? "probs" : "edges");
    if (!vx || !vy || !readVec(*vx, x) || !readVec(*vy, y) || x.empty()) {
      ctx.fail("the " + k + " distribution is not valid");
      return nullptr;
    }
    if (k == "discrete")
      return std::make_shared<TableDist>(x, y);
    return std::make_shared<HistDist>(x, y);
  }
  if (k == "mixture") {
    auto m = std::make_shared<MixDist>();
    const Value *c = dictGet(v, "components"), *w = dictGet(v, "weights");
    if (!c || !c->isDict || !w || !readVec(*w, m->w)) {
      ctx.fail("the mixture distribution is not valid");
      return nullptr;
    }
    for (size_t i = 0; i < m->w.size(); i++) {
      const Value *ci = dictGet(*c, "c" + std::to_string(i + 1));
      if (!ci) {
        ctx.fail("the mixture distribution is not valid");
        return nullptr;
      }
      DistPtr d = readDistAt(*ci, ctx, depth + 1);
      if (!d)
        return nullptr;
      m->c.push_back(d);
    }
    m->discrete = m->c[0]->discrete;
    return m;
  }
  if (k == "order" || k == "truncate" || k == "abs" || k == "exp" || k == "log") {
    DistPtr b = base();
    if (!b)
      return nullptr;
    if (k == "order")
      return std::make_shared<OrderDist>(b, fieldNum(v, "r", 1), fieldNum(v, "n", 1));
    if (k == "truncate")
      return std::make_shared<TruncDist>(b, fieldNum(v, "lb", -kInf), fieldNum(v, "ub", kInf));
    return std::make_shared<TfDist>(b, k == "abs" ? Tf::Abs : k == "exp" ? Tf::Exp : Tf::Log);
  }
  ctx.fail("unknown distribution kind '" + k + "'");
  return nullptr;
}

// x scalar -> number; array / matrix -> the same shape
Value mapShape(const Value &x, CallContext &ctx, const std::function<double(double)> &f) {
  if (isPlainNumber(x))
    return Value(f(x.number));
  Mat m;
  if (!readMat(x, m)) {
    ctx.fail("expected a number or an array of numbers");
    return Value(0.0);
  }
  for (double &v : m.a)
    v = f(v);
  return x.isMatrix && m.r > 1 ? toValue(m) : toValue(m.a);
}

Value transformValue(const char *kind, const Value &base) { return makeDict({{"dist", Value(std::string(kind))}, {"base", base}}); }

double nllOf(const pd::Family &f, const Vec &x, const Vec &shapes, double loc, double scale) {
  if (!pd::shapesOk(f, shapes.data()) || (!f.discrete && scale <= 0))
    return kInf;
  double s = 0, bad = 0;
  for (double v : x) {
    double p = pd::pdfLS(f, v, shapes.data(), loc, scale);
    if (p > 0 && std::isfinite(p))
      s -= std::log(p);
    else
      bad++;
  }
  // points outside the support: SciPy's penalty
  return bad ? s + bad * 1e10 : s;
}

// Nelder-Mead in the box [lo, hi] (points are clipped into the box).
Vec nelderMead(const std::function<double(const Vec &)> &f, Vec x0, const Vec &lo, const Vec &hi, int iters) {
  size_t n = x0.size();
  auto clip = [&](Vec v) {
    for (size_t i = 0; i < n; i++)
      v[i] = std::min(hi[i], std::max(lo[i], v[i]));
    return v;
  };
  std::vector<Vec> s(n + 1, clip(x0));
  Vec fs(n + 1);
  for (size_t i = 0; i < n; i++)
    s[i + 1][i] += 0.1 * (hi[i] - lo[i]) * (s[i + 1][i] + 0.1 * (hi[i] - lo[i]) > hi[i] ? -1 : 1);
  for (size_t i = 0; i <= n; i++)
    fs[i] = f(s[i] = clip(s[i]));
  for (int it = 0; it < iters; it++) {
    std::vector<size_t> o(n + 1);
    std::iota(o.begin(), o.end(), 0);
    std::sort(o.begin(), o.end(), [&](size_t a, size_t b) { return fs[a] < fs[b]; });
    std::vector<Vec> s2;
    Vec f2;
    for (size_t i : o) {
      s2.push_back(s[i]);
      f2.push_back(fs[i]);
    }
    s = s2;
    fs = f2;
    double spread = 0;
    for (size_t i = 0; i < n; i++)
      spread = std::max(spread, std::fabs(s[n][i] - s[0][i]) / (hi[i] - lo[i]));
    if (spread < 1e-11 && std::fabs(fs[n] - fs[0]) < 1e-12 * (1 + std::fabs(fs[0])))
      break;
    Vec c(n, 0.0);
    for (size_t i = 0; i < n; i++)
      for (size_t k = 0; k < n; k++)
        c[k] += s[i][k] / n;
    auto along = [&](double t) {
      Vec v(n);
      for (size_t k = 0; k < n; k++)
        v[k] = c[k] + t * (s[n][k] - c[k]);
      return clip(v);
    };
    Vec xr = along(-1);
    double fr = f(xr);
    if (fr < fs[0]) {
      Vec xe = along(-2);
      double fe = f(xe);
      if (fe < fr) {
        s[n] = xe;
        fs[n] = fe;
      } else {
        s[n] = xr;
        fs[n] = fr;
      }
    } else if (fr < fs[n - 1]) {
      s[n] = xr;
      fs[n] = fr;
    } else {
      Vec xc = along(fr < fs[n] ? -0.5 : 0.5);
      double fc = f(xc);
      if (fc < std::min(fr, fs[n])) {
        s[n] = xc;
        fs[n] = fc;
      } else {
        for (size_t i = 1; i <= n; i++) {
          for (size_t k = 0; k < n; k++)
            s[i][k] = s[0][k] + 0.5 * (s[i][k] - s[0][k]);
          fs[i] = f(s[i]);
        }
      }
    }
  }
  size_t best = std::min_element(fs.begin(), fs.end()) - fs.begin();
  return s[best];
}

Value mvsValues(const Vec &x, double &n) {
  n = x.size();
  double xbar = mean(x), C = var(x, 0);
  if (n > 1000)
    return makeDict({{"mean", familyDistValue("norm", {}, xbar, std::sqrt(C / n))},
                     {"var", familyDistValue("norm", {}, C, std::sqrt(2.0 / n) * C)},
                     {"std", familyDistValue("norm", {}, std::sqrt(C), std::sqrt(C / (2 * n)))}});
  double nm1 = n - 1, fac = n * C / 2, val = nm1 / 2;
  return makeDict({{"mean", familyDistValue("t", {nm1}, xbar, std::sqrt(C / nm1))},
                   {"var", familyDistValue("invgamma", {val}, 0, fac)},
                   {"std", familyDistValue("gengamma", {val, -2}, 0, std::sqrt(fac))}});
}

} // namespace

DistPtr readDist(const Value &v, CallContext &ctx) { return readDistAt(v, ctx, 0); }

Value familyDistValue(const std::string &name, const Vec &shapes, double loc, double scale) {
  return makeDict({{"dist", Value(std::string("family"))},
                   {"name", Value(name)},
                   {"shapes", toValue(shapes)},
                   {"loc", Value(loc)},
                   {"scale", Value(scale)}});
}

} // namespace st

using namespace st;

void registerStDist(Registry &reg) {
  SP_ADD("make_dist", 1, 2, "dist, params") {
    std::string n;
    if (!argText(a, 0, ctx, n))
      return Value(0.0);
    const pd::Family *f = pd::findFamily(n);
    if (!f || f->arrayShape) {
      ctx.fail("unknown distribution '" + n + "'");
      return Value(0.0);
    }
    Vec sh(f->nshape, kNaN);
    double loc = 0, scale = 1;
    if (a.size() > 1) {
      if (!a[1].isDict) {
        ctx.fail("params must be a Dict of shape parameters (and loc, scale)");
        return Value(0.0);
      }
      for (const auto &kv : a[1].dict()) {
        if (!isPlainNumber(kv.second)) {
          ctx.fail("parameter '" + kv.first + "' must be a number");
          return Value(0.0);
        }
        if (kv.first == "loc")
          loc = kv.second.number;
        else if (kv.first == "scale")
          scale = kv.second.number;
        else {
          auto it = std::find(f->shapeNames.begin(), f->shapeNames.end(), kv.first);
          if (it == f->shapeNames.end()) {
            ctx.fail("'" + n + "' has no parameter '" + kv.first + "'");
            return Value(0.0);
          }
          sh[it - f->shapeNames.begin()] = kv.second.number;
        }
      }
    }
    for (size_t i = 0; i < sh.size(); i++)
      if (std::isnan(sh[i])) {
        ctx.fail("give the shape parameter '" + f->shapeNames[i] + "' of '" + n + "' in params");
        return Value(0.0);
      }
    if (!pd::shapesOk(*f, sh.data()) || scale <= 0) {
      ctx.fail("the parameters are outside the domain of '" + n + "'");
      return Value(0.0);
    }
    return familyDistValue(n, sh, loc, scale);
  } SP_END

  SP_ADD("normal_dist", 0, 2, "mu, sigma") {
    double mu = optNum(a, 0, 0), s = optNum(a, 1, 1);
    if (!(s > 0)) {
      ctx.fail("sigma must be positive");
      return Value(0.0);
    }
    return familyDistValue("norm", {}, mu, s);
  } SP_END

  SP_ADD("uniform_dist", 2, 2, "a, b") {
    double lo, hi;
    if (!argNumber(a, 0, ctx, lo) || !argNumber(a, 1, ctx, hi))
      return Value(0.0);
    if (!(hi > lo)) {
      ctx.fail("b must be greater than a");
      return Value(0.0);
    }
    return familyDistValue("uniform", {}, lo, hi - lo);
  } SP_END

  SP_ADD("logistic_dist", 0, 0, "") { return familyDistValue("logistic", {}, 0, 1); } SP_END

  SP_ADD("binomial_dist", 2, 2, "n, p") {
    long long n;
    double p;
    if (!argNonNegativeInt(a, 0, ctx, n) || !argNumber(a, 1, ctx, p))
      return Value(0.0);
    if (!(p >= 0 && p <= 1)) {
      ctx.fail("p must be between 0 and 1");
      return Value(0.0);
    }
    return familyDistValue("binom", {double(n), p}, 0, 1);
  } SP_END

  SP_ADD("custom_dist", 1, 3, "pdf, a, b") {
    if (!isCallable(a[0])) {
      ctx.fail("pdf must name an NC function of x");
      return Value(0.0);
    }
    double lo = optNum(a, 1, -kInf), hi = optNum(a, 2, kInf);
    if (!(hi > lo)) {
      ctx.fail("b must be greater than a");
      return Value(0.0);
    }
    return makeDict({{"dist", Value(std::string("custom"))}, {"pdf", a[0]}, {"a", Value(lo)}, {"b", Value(hi)}});
  } SP_END

  SP_ADD("custom_discrete_dist", 2, 2, "values, probs") {
    Vec v, p;
    if (!getVec(a, 0, ctx, v) || !getVec(a, 1, ctx, p))
      return Value(0.0);
    if (v.empty() || v.size() != p.size()) {
      ctx.fail("values and probs must have the same, non-zero length");
      return Value(0.0);
    }
    double s = 0;
    for (double q : p) {
      if (!(q >= 0)) {
        ctx.fail("probs must not be negative");
        return Value(0.0);
      }
      s += q;
    }
    if (std::fabs(s - 1) > 1e-8) {
      ctx.fail("probs must sum to 1");
      return Value(0.0);
    }
    return makeDict({{"dist", Value(std::string("discrete"))}, {"values", toValue(v)}, {"probs", toValue(p)}});
  } SP_END

  SP_ADD("hist_dist", 2, 2, "counts, edges") {
    Vec c, e;
    if (!getVec(a, 0, ctx, c) || !getVec(a, 1, ctx, e))
      return Value(0.0);
    if (c.empty() || e.size() != c.size() + 1) {
      ctx.fail("edges must have one more element than counts");
      return Value(0.0);
    }
    double s = 0;
    for (size_t i = 0; i < c.size(); i++) {
      if (!(e[i + 1] > e[i]) || c[i] < 0) {
        ctx.fail("edges must increase and counts must not be negative");
        return Value(0.0);
      }
      s += c[i];
    }
    if (s <= 0) {
      ctx.fail("the counts must not all be 0");
      return Value(0.0);
    }
    return makeDict({{"dist", Value(std::string("histogram"))}, {"counts", toValue(c)}, {"edges", toValue(e)}});
  } SP_END

  SP_ADD("mixture_dist", 1, kVariadic, "dists..., weights") {
    Args d(a);
    Vec w;
    if (!d.back().isDict && !d.back().isText) {
      if (!readVec(d.back(), w)) {
        ctx.fail("weights must be an array of numbers");
        return Value(0.0);
      }
      d.pop_back();
    }
    if (d.empty()) {
      ctx.fail("give the component distributions as separate arguments, then the weights");
      return Value(0.0);
    }
    if (w.empty())
      w.assign(d.size(), 1.0 / d.size());
    if (w.size() != d.size()) {
      ctx.fail("give one weight per component");
      return Value(0.0);
    }
    double s = 0;
    for (double x : w) {
      if (!(x >= 0)) {
        ctx.fail("weights must not be negative");
        return Value(0.0);
      }
      s += x;
    }
    if (std::fabs(s - 1) > 1e-8) {
      ctx.fail("weights must sum to 1");
      return Value(0.0);
    }
    std::unordered_map<std::string, Value> comps;
    bool disc = false;
    for (size_t i = 0; i < d.size(); i++) {
      DistPtr p = readDist(d[i], ctx);
      if (!p)
        return Value(0.0);
      if (i > 0 && p->discrete != disc) {
        ctx.fail("the components must all be continuous or all discrete");
        return Value(0.0);
      }
      disc = p->discrete;
      comps.emplace("c" + std::to_string(i + 1), d[i]);
    }
    return makeDict({{"dist", Value(std::string("mixture"))}, {"components", Value(comps)}, {"weights", toValue(w)}});
  } SP_END

  SP_ADD("order_stat_dist", 3, 3, "dist, r, n") {
    long long r, n;
    if (!readDist(a[0], ctx) || !argInt(a, 1, ctx, r) || !argInt(a, 2, ctx, n))
      return Value(0.0);
    if (n < 1 || r < 1 || r > n) {
      ctx.fail("needs 1 <= r <= n");
      return Value(0.0);
    }
    return makeDict({{"dist", Value(std::string("order"))}, {"base", a[0]}, {"r", Value(double(r))}, {"n", Value(double(n))}});
  } SP_END

  SP_ADD("truncate_dist", 1, 3, "dist, lb, ub") {
    DistPtr d = readDist(a[0], ctx);
    if (!d)
      return Value(0.0);
    double lb = optNum(a, 1, -kInf), ub = optNum(a, 2, kInf);
    if (!(ub > lb)) {
      ctx.fail("ub must be greater than lb");
      return Value(0.0);
    }
    double Z = d->cdf(ub) - (d->discrete ? d->cdf(std::ceil(lb) - 1) : d->cdf(lb));
    if (!(Z > 0)) {
      ctx.fail("the distribution has no probability between lb and ub");
      return Value(0.0);
    }
    return makeDict({{"dist", Value(std::string("truncate"))}, {"base", a[0]}, {"lb", Value(lb)}, {"ub", Value(ub)}});
  } SP_END

  auto tf = [](const char *kind) {
    return [kind](const Args &a, CallContext &ctx) -> Value {
      DistPtr d = readDist(a[0], ctx);
      if (!d)
        return Value(0.0);
      if (d->discrete) {
        ctx.fail("needs a continuous distribution");
        return Value(0.0);
      }
      if (std::string(kind) == "log") {
        double lo, hi;
        d->support(lo, hi);
        if (lo < 0) {
          ctx.fail("the distribution must be on the positive numbers");
          return Value(0.0);
        }
      }
      return transformValue(kind, a[0]);
    };
  };
  reg.add(makeSpec("abs_dist", SP_SEC, 1, 1, "dist", tf("abs"), false));
  reg.add(makeSpec("exp_dist", SP_SEC, 1, 1, "dist", tf("exp"), false));
  reg.add(makeSpec("log_dist", SP_SEC, 1, 1, "dist", tf("log"), false));

  // ---- methods ----
  auto method = [](int which) {
    return [which](const Args &a, CallContext &ctx) -> Value {
      DistPtr d = readDist(a[0], ctx);
      if (!d)
        return Value(0.0);
      Value r;
      if (which <= 4) {
        if (a.size() < 2) {
          ctx.fail("give the point(s) to evaluate");
          return Value(0.0);
        }
        r = mapShape(a[1], ctx, [&](double x) {
          switch (which) {
          case 0:
            return d->pdf(x);
          case 1:
            return d->cdf(x);
          case 2:
            return d->sf(x);
          case 3:
            return d->ppf(x);
          default:
            return d->pdf(x); // pmf
          }
        });
      } else if (which == 5) {
        long long n = 1;
        if (a.size() > 1 && !argNonNegativeInt(a, 1, ctx, n))
          return Value(0.0);
        if (n > 100000000) {
          ctx.fail("n is too large");
          return Value(0.0);
        }
        std::mt19937_64 g(ncRandomEngine()());
        Vec v(static_cast<size_t>(n));
        for (double &x : v) {
          x = d->rvs(g);
          if (d->failed())
            break;
        }
        r = a.size() > 1 ? toValue(v) : Value(v.empty() ? kNaN : v[0]);
      } else {
        double m = 0;
        switch (which) {
        case 6:
          m = d->mean();
          break;
        case 7:
          m = d->var();
          break;
        case 8:
          m = std::sqrt(d->var());
          break;
        default:
          m = d->ppf(0.5);
        }
        r = Value(m);
      }
      if (d->failed()) {
        ctx.fail("the distribution's NC function could not be evaluated");
        return Value(0.0);
      }
      return r;
    };
  };
  reg.add(makeSpec("dist_pdf", SP_SEC, 2, 2, "dist, x", method(0), false));
  reg.add(makeSpec("dist_cdf", SP_SEC, 2, 2, "dist, x", method(1), false));
  reg.add(makeSpec("dist_sf", SP_SEC, 2, 2, "dist, x", method(2), false));
  reg.add(makeSpec("dist_ppf", SP_SEC, 2, 2, "dist, q", method(3), false));
  reg.add(makeSpec("dist_pmf", SP_SEC, 2, 2, "dist, k", method(4), false));
  reg.add(makeSpec("dist_rvs", SP_SEC, 1, 2, "dist, n", method(5), false));
  reg.add(makeSpec("dist_mean", SP_SEC, 1, 1, "dist", method(6), false));
  reg.add(makeSpec("dist_var", SP_SEC, 1, 1, "dist", method(7), false));
  reg.add(makeSpec("dist_std", SP_SEC, 1, 1, "dist", method(8), false));
  reg.add(makeSpec("dist_median", SP_SEC, 1, 1, "dist", method(9), false));

  // ---- functions built on distributions ----
  SP_ADD("mvs_dist", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.size() < 2) {
      ctx.fail("needs at least 2 values");
      return Value(0.0);
    }
    double n;
    return mvsValues(x, n);
  } SP_END

  SP_ADD("bayes_mvs", 1, 2, "data, alpha") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    double al = optNum(a, 1, 0.9);
    if (x.size() < 2 || !(al > 0 && al < 1)) {
      ctx.fail("needs at least 2 values and 0 < alpha < 1");
      return Value(0.0);
    }
    double n;
    Value m = mvsValues(x, n);
    DictInit out;
    for (const char *k : {"mean", "var", "std"}) {
      DistPtr d = readDist(*dictGet(m, k), ctx);
      Vec mm = {d->ppf((1 - al) / 2), d->ppf((1 + al) / 2)};
      out.push_back({k, makeDict({{"statistic", Value(d->mean())}, {"minmax", toValue(mm)}})});
    }
    return makeDict(out);
  } SP_END

  SP_ADD("dist_fit", 2, 3, "dist, data, bounds") {
    std::string n;
    Vec x;
    if (!argText(a, 0, ctx, n) || !getVec(a, 1, ctx, x))
      return Value(0.0);
    const pd::Family *f = pd::findFamily(n);
    if (!f || f->arrayShape) {
      ctx.fail("unknown distribution '" + n + "'");
      return Value(0.0);
    }
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    std::vector<std::string> names = f->shapeNames;
    names.push_back("loc");
    if (!f->discrete)
      names.push_back("scale");
    size_t np = names.size();
    Vec lo(np, kNaN), hi(np, kNaN);
    if (a.size() > 2) {
      if (a[2].isDict) {
        for (const auto &kv : a[2].dict()) {
          auto it = std::find(names.begin(), names.end(), kv.first);
          Vec b;
          if (it == names.end() || !readVec(kv.second, b) || b.size() != 2) {
            ctx.fail("bounds: '" + kv.first + "' is not a parameter of '" + n + "', or its bound is not [low, high]");
            return Value(0.0);
          }
          lo[it - names.begin()] = b[0];
          hi[it - names.begin()] = b[1];
        }
      } else {
        Mat b;
        if (!getMat(a, 2, ctx, b))
          return Value(0.0);
        if (b.c != 2 || b.r > np) {
          ctx.fail("bounds must be a Dict or a matrix with one [low, high] row per parameter");
          return Value(0.0);
        }
        for (size_t i = 0; i < b.r; i++) {
          lo[i] = b(i, 0);
          hi[i] = b(i, 1);
        }
      }
    }
    std::vector<size_t> freeIdx;
    Vec fixedVal(np, 0.0);
    for (size_t i = 0; i < np; i++) {
      if (std::isnan(lo[i])) {
        if (i < size_t(f->nshape)) {
          ctx.fail("give bounds for the shape parameter '" + names[i] + "'");
          return Value(0.0);
        }
        fixedVal[i] = names[i] == "scale" ? 1.0 : 0.0;
        continue;
      }
      if (!(hi[i] >= lo[i]) || !std::isfinite(lo[i]) || !std::isfinite(hi[i])) {
        ctx.fail("bounds of '" + names[i] + "' must be finite with low <= high");
        return Value(0.0);
      }
      freeIdx.push_back(i);
    }
    auto full = [&](const Vec &u) {
      Vec p(fixedVal);
      for (size_t k = 0; k < freeIdx.size(); k++)
        p[freeIdx[k]] = u[k];
      return p;
    };
    auto nll = [&](const Vec &u) {
      Vec p = full(u);
      Vec sh(p.begin(), p.begin() + f->nshape);
      return nllOf(*f, x, sh, p[f->nshape], f->discrete ? 1.0 : p[f->nshape + 1]);
    };
    size_t m = freeIdx.size();
    Vec flo(m), fhi(m);
    for (size_t k = 0; k < m; k++) {
      flo[k] = lo[freeIdx[k]];
      fhi[k] = hi[freeIdx[k]];
    }
    Vec best;
    double bestF = kInf;
    if (m == 0) {
      best = {};
      bestF = nll(best);
    } else {
      // starts: a coarse grid of the box, then Nelder-Mead from the best few
      std::mt19937_64 g(12345);
      std::vector<std::pair<double, Vec>> starts;
      for (int s = 0; s < 60 * int(m); s++) {
        Vec u(m);
        for (size_t k = 0; k < m; k++)
          u[k] = flo[k] + (s == 0 ? 0.5 : pd::uniform01(g)) * (fhi[k] - flo[k]);
        starts.push_back({nll(u), u});
      }
      std::sort(starts.begin(), starts.end(), [](const auto &p, const auto &q) { return p.first < q.first; });
      for (size_t s = 0; s < std::min<size_t>(5, starts.size()); s++) {
        Vec u = nelderMead(nll, starts[s].second, flo, fhi, 4000);
        u = nelderMead(nll, u, flo, fhi, 4000);
        double fu = nll(u);
        if (fu < bestF) {
          bestF = fu;
          best = u;
        }
      }
    }
    Vec p = full(best);
    if (f->discrete)
      for (int k = 0; k < f->nshape; k++)
        if (f->shapeNames[k] == "n")
          p[k] = std::round(p[k]);
    return makeDict({{"params", toValue(p)}, {"success", Value(std::isfinite(bestF))}, {"nllf", Value(bestF)}});
  } SP_END

  SP_ADD("censored_data", 1, 3, "uncensored, right, left") {
    Vec u, r, l;
    if (!getVec(a, 0, ctx, u))
      return Value(0.0);
    if (a.size() > 1 && !getVec(a, 1, ctx, r))
      return Value(0.0);
    if (a.size() > 2 && !getVec(a, 2, ctx, l))
      return Value(0.0);
    return makeDict({{"uncensored", toValue(u)}, {"right", toValue(r)}, {"left", toValue(l)}});
  } SP_END

  SP_ADD("cov_diagonal", 1, 1, "d") {
    Vec d;
    if (!getVec(a, 0, ctx, d))
      return Value(0.0);
    for (double v : d)
      if (!(v >= 0)) {
        ctx.fail("the variances must not be negative");
        return Value(0.0);
      }
    Mat m(d.size(), d.size());
    for (size_t i = 0; i < d.size(); i++)
      m(i, i) = d[i];
    return toValue(m);
  } SP_END

  reg.setParallel({"custom_dist", "mixture_dist", "order_stat_dist", "truncate_dist", "abs_dist", "exp_dist", "log_dist", "dist_pdf",
                   "dist_cdf", "dist_sf", "dist_ppf", "dist_pmf", "dist_rvs", "dist_mean", "dist_var", "dist_std", "dist_median"},
                  ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
