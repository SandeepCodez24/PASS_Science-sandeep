// Section 21, quasi-Monte Carlo (scipy.stats.qmc): Sobol and Halton
// sequences, Latin hypercube and Poisson-disk sampling, QMC multinomial and
// multivariate normal draws, discrepancies and scaling; and the random-number
// samplers of scipy.stats.sampling (numerical inversion, transformed density
// rejection, ratio of uniforms, alias and guide tables).
#include "st_dist.h"
#include "statistics_main.h"

#include <cstdint>

#include "../../ops/matrix/matrix.h"
#include "../linear_algebra/la_core.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace st {

extern const int kSobolMaxDim;
extern const std::uint32_t kSobolPoly[];
extern const std::uint32_t kSobolVinit[][18];

Mat sobolPoints(size_t d, size_t n, std::mt19937_64 *shift) {
  const int bits = 30;
  std::vector<std::vector<std::uint64_t>> v(d, std::vector<std::uint64_t>(bits, 0));
  for (int i = 0; i < bits; i++)
    v[0][i] = 1;
  for (size_t j = 1; j < d; j++) {
    std::uint64_t p = kSobolPoly[j];
    int m = 0;
    while ((p >> (m + 1)) != 0)
      m++;
    for (int k = 0; k < m; k++)
      v[j][k] = kSobolVinit[j][k];
    for (int k = m; k < bits; k++) {
      std::uint64_t nv = v[j][k - m], pow2 = 1;
      for (int t = 0; t < m; t++) {
        pow2 <<= 1;
        if ((p >> (m - 1 - t)) & 1)
          nv ^= pow2 * v[j][k - t - 1];
      }
      v[j][k] = nv;
    }
  }
  std::uint64_t pow2 = 1;
  for (int k = 0; k < bits; k++) {
    for (size_t j = 0; j < d; j++)
      v[j][bits - 1 - k] *= pow2;
    pow2 <<= 1;
  }
  std::vector<std::uint64_t> q(d, 0);
  if (shift)
    for (auto &x : q)
      x = (*shift)() & ((std::uint64_t(1) << bits) - 1);
  Mat out(n, d);
  const double scale = 1.0 / double(std::uint64_t(1) << bits);
  for (size_t i = 0; i < n; i++) {
    int c = 0;
    while ((i >> c) & 1)
      c++;
    for (size_t j = 0; j < d; j++) {
      out(i, j) = double(q[j]) * scale;
      q[j] ^= v[j][c];
    }
  }
  return out;
}

namespace {

std::vector<int> primes(size_t n) {
  std::vector<int> p;
  for (int k = 2; p.size() < n; k++) {
    bool ok = true;
    for (int q : p) {
      if (q * q > k)
        break;
      if (k % q == 0) {
        ok = false;
        break;
      }
    }
    if (ok)
      p.push_back(k);
  }
  return p;
}

// the engine for a call: its own when a seed is given, NC's otherwise
struct Rng {
  std::mt19937_64 g;
  Rng(const Args &a, size_t i) : g(isNumberArg(a, i) ? std::mt19937_64(std::uint64_t(a[i].number)) : std::mt19937_64(ncRandomEngine()())) {}
};

bool dimCount(const Args &a, size_t i, CallContext &ctx, long long &v, long long lo, long long hi, const char *what) {
  if (!argInt(a, i, ctx, v))
    return false;
  if (v < lo || v > hi) {
    ctx.fail(std::string(what) + " must be from " + std::to_string(lo) + " to " + std::to_string(hi));
    return false;
  }
  return true;
}

bool unitSample(const Args &a, size_t i, CallContext &ctx, Mat &m) {
  if (!getMat(a, i, ctx, m))
    return false;
  if (a[i].isArray && !a[i].isMatrix) { // one point per element
    Vec v = m.a;
    m = Mat(v.size(), 1);
    m.a = v;
  }
  for (double v : m.a)
    if (!(v >= 0 && v <= 1)) {
      ctx.fail("the sample must be inside the unit hypercube [0, 1]");
      return false;
    }
  return true;
}

double discrepancyOf(const Mat &x, const std::string &method) {
  size_t n = x.r, d = x.c;
  double nn = n;
  if (method == "CD") {
    double d1 = 0, d2 = 0;
    for (size_t i = 0; i < n; i++) {
      double p = 1;
      for (size_t k = 0; k < d; k++) {
        double t = std::fabs(x(i, k) - 0.5);
        p *= 1 + 0.5 * t - 0.5 * t * t;
      }
      d1 += p;
      for (size_t j = 0; j < n; j++) {
        double q = 1;
        for (size_t k = 0; k < d; k++)
          q *= 1 + 0.5 * std::fabs(x(i, k) - 0.5) + 0.5 * std::fabs(x(j, k) - 0.5) - 0.5 * std::fabs(x(i, k) - x(j, k));
        d2 += q;
      }
    }
    return std::pow(13.0 / 12, double(d)) - 2.0 / nn * d1 + d2 / (nn * nn);
  }
  if (method == "WD") {
    double s = 0;
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        double q = 1;
        for (size_t k = 0; k < d; k++) {
          double t = std::fabs(x(i, k) - x(j, k));
          q *= 1.5 - t * (1 - t);
        }
        s += q;
      }
    return -std::pow(4.0 / 3, double(d)) + s / (nn * nn);
  }
  if (method == "MD") {
    double d1 = 0, d2 = 0;
    for (size_t i = 0; i < n; i++) {
      double p = 1;
      for (size_t k = 0; k < d; k++) {
        double t = std::fabs(x(i, k) - 0.5);
        p *= 5.0 / 3 - 0.25 * t - 0.25 * t * t;
      }
      d1 += p;
      for (size_t j = 0; j < n; j++) {
        double q = 1;
        for (size_t k = 0; k < d; k++) {
          double t = std::fabs(x(i, k) - x(j, k));
          q *= 15.0 / 8 - 0.25 * std::fabs(x(i, k) - 0.5) - 0.25 * std::fabs(x(j, k) - 0.5) - 0.75 * t + 0.5 * t * t;
        }
        d2 += q;
      }
    }
    return std::pow(19.0 / 12, double(d)) - 2.0 / nn * d1 + d2 / (nn * nn);
  }
  // L2-star
  double d1 = 0, d2 = 0;
  for (size_t i = 0; i < n; i++) {
    double p = 1;
    for (size_t k = 0; k < d; k++)
      p *= 1 - x(i, k) * x(i, k);
    d1 += p;
    for (size_t j = 0; j < n; j++) {
      double q = 1;
      for (size_t k = 0; k < d; k++)
        q *= 1 - std::max(x(i, k), x(j, k));
      d2 += q;
    }
  }
  return std::sqrt(std::pow(3.0, -double(d)) - std::pow(2.0, 1.0 - d) / nn * d1 + d2 / (nn * nn));
}

// Transformed density rejection with T = log (adaptive rejection sampling).
struct Tdr {
  NcFn f, df;
  Vec x, h, s; // abscissae, log density, its slope
  explicit Tdr(const Value &pdf, const Value &dpdf) : f(pdf), df(dpdf) {}
  bool eval(double t, double &ht, double &st) {
    double p = f.scalar(t), dp = df.scalar(t);
    if (f.failed || df.failed || !(p > 0))
      return false;
    ht = std::log(p);
    st = dp / p;
    return std::isfinite(ht) && std::isfinite(st);
  }
  bool add(double t) {
    double ht, st;
    if (!eval(t, ht, st))
      return false;
    size_t i = std::lower_bound(x.begin(), x.end(), t) - x.begin();
    if (i < x.size() && x[i] == t)
      return true;
    x.insert(x.begin() + i, t);
    h.insert(h.begin() + i, ht);
    s.insert(s.begin() + i, st);
    return true;
  }
  bool init(std::string &why) {
    if (!add(-1) || !add(0) || !add(1)) {
      why = "the density must be positive at -1, 0 and 1";
      return false;
    }
    for (double step = 2; s.front() <= 0 && step < 1e8; step *= 2)
      if (!add(x.front() - step)) {
        why = "the density is not positive far left of 0";
        return false;
      }
    for (double step = 2; s.back() >= 0 && step < 1e8; step *= 2)
      if (!add(x.back() + step)) {
        why = "the density is not positive far right of 0";
        return false;
      }
    if (s.front() <= 0 || s.back() >= 0) {
      why = "the density does not decrease in its tails";
      return false;
    }
    return true;
  }
  double sample(std::mt19937_64 &g, bool &ok) {
    for (int tries = 0; tries < 10000; tries++) {
      size_t k = x.size();
      Vec z(k + 1);
      z[0] = -kInf;
      z[k] = kInf;
      for (size_t i = 0; i + 1 < k; i++) {
        double ds = s[i] - s[i + 1];
        z[i + 1] = ds > 1e-300 ? (h[i + 1] - h[i] - x[i + 1] * s[i + 1] + x[i] * s[i]) / ds : 0.5 * (x[i] + x[i + 1]);
      }
      double c = *std::max_element(h.begin(), h.end());
      Vec mass(k);
      for (size_t i = 0; i < k; i++) {
        double lo = z[i], hi = z[i + 1];
        if (std::fabs(s[i]) < 1e-12)
          mass[i] = std::exp(h[i] - c) * (hi - lo);
        else
          mass[i] = std::exp(h[i] - c) * (std::exp(s[i] * (hi - x[i])) - std::exp(s[i] * (lo - x[i]))) / s[i];
        if (!(mass[i] >= 0))
          mass[i] = 0;
      }
      double tot = 0;
      for (double m : mass)
        tot += m;
      double u = pd::uniform01(g) * tot;
      size_t i = 0;
      while (i + 1 < k && u > mass[i]) {
        u -= mass[i];
        i++;
      }
      double lo = z[i], hi = z[i + 1], w = pd::uniform01(g), t;
      if (std::fabs(s[i]) < 1e-12)
        t = lo + w * (hi - lo);
      else {
        double ea = std::exp(s[i] * (lo - x[i])), eb = std::exp(s[i] * (hi - x[i]));
        t = x[i] + std::log(ea + w * (eb - ea)) / s[i];
      }
      if (!std::isfinite(t))
        continue;
      double ut = h[i] + s[i] * (t - x[i]);
      double ht, st;
      double p = f.scalar(t);
      if (f.failed) {
        ok = false;
        return kNaN;
      }
      if (p > 0 && pd::uniform01(g) <= std::exp(std::log(p) - ut))
        return t;
      if (x.size() < 60 && eval(t, ht, st))
        add(t);
      if (f.failed || df.failed) {
        ok = false;
        return kNaN;
      }
    }
    ok = false;
    return kNaN;
  }
};

Value draws(const Vec &v) { return toValue(v); }

} // namespace
} // namespace st

using namespace st;

void registerStQmc(Registry &reg) {
  SP_ADD("sobol_sample", 2, 3, "d, m, seed") {
    long long d, m;
    if (!dimCount(a, 0, ctx, d, 1, kSobolMaxDim, "d") || !dimCount(a, 1, ctx, m, 0, 24, "m"))
      return Value(0.0);
    if (a.size() > 2) {
      Rng r(a, 2);
      return toValue(sobolPoints(static_cast<size_t>(d), size_t(1) << m, &r.g));
    }
    return toValue(sobolPoints(static_cast<size_t>(d), size_t(1) << m, nullptr));
  } SP_END

  SP_ADD("halton_sample", 2, 3, "d, n, seed") {
    long long d, n;
    if (!dimCount(a, 0, ctx, d, 1, 10000, "d") || !dimCount(a, 1, ctx, n, 0, 100000000, "n"))
      return Value(0.0);
    std::vector<int> b = primes(static_cast<size_t>(d));
    Vec shift(static_cast<size_t>(d), 0.0);
    if (a.size() > 2) {
      Rng r(a, 2);
      for (double &s : shift)
        s = pd::uniform01(r.g);
    }
    Mat out(static_cast<size_t>(n), static_cast<size_t>(d));
    for (size_t i = 0; i < size_t(n); i++)
      for (size_t j = 0; j < size_t(d); j++) {
        double f = 1, v = 0;
        for (unsigned long long k = i; k > 0; k /= b[j]) {
          f /= b[j];
          v += f * double(k % b[j]);
        }
        v += shift[j];
        out(i, j) = v - std::floor(v);
      }
    return toValue(out);
  } SP_END

  SP_ADD("latin_hypercube", 2, 3, "d, n, seed") {
    long long d, n;
    if (!dimCount(a, 0, ctx, d, 1, 100000, "d") || !dimCount(a, 1, ctx, n, 1, 100000000, "n"))
      return Value(0.0);
    Rng r(a, 2);
    Mat out(static_cast<size_t>(n), static_cast<size_t>(d));
    std::vector<size_t> perm(static_cast<size_t>(n));
    for (size_t j = 0; j < size_t(d); j++) {
      std::iota(perm.begin(), perm.end(), 0);
      std::shuffle(perm.begin(), perm.end(), r.g);
      for (size_t i = 0; i < size_t(n); i++)
        out(i, j) = (perm[i] + pd::uniform01(r.g)) / double(n);
    }
    return toValue(out);
  } SP_END

  SP_ADD("poisson_disk", 3, 4, "d, radius, n, seed") {
    long long d, n;
    double rad;
    if (!dimCount(a, 0, ctx, d, 1, 100, "d") || !argNumber(a, 1, ctx, rad) || !dimCount(a, 2, ctx, n, 1, 100000, "n"))
      return Value(0.0);
    if (!(rad > 0)) {
      ctx.fail("radius must be positive");
      return Value(0.0);
    }
    Rng r(a, 3);
    std::vector<Vec> pts;
    std::vector<size_t> active;
    auto farEnough = [&](const Vec &p) {
      for (const Vec &q : pts) {
        double s = 0;
        for (size_t k = 0; k < p.size(); k++)
          s += (p[k] - q[k]) * (p[k] - q[k]);
        if (s < rad * rad)
          return false;
      }
      return true;
    };
    Vec p0(static_cast<size_t>(d));
    for (double &v : p0)
      v = pd::uniform01(r.g);
    pts.push_back(p0);
    active.push_back(0);
    while (!active.empty() && pts.size() < size_t(n)) {
      size_t ai = std::uniform_int_distribution<size_t>(0, active.size() - 1)(r.g);
      const Vec c = pts[active[ai]];
      bool found = false;
      for (int k = 0; k < 30 && !found; k++) {
        // a point in the shell [r, 2r] around c, inside the cube
        Vec dir(static_cast<size_t>(d));
        double nr = 0;
        for (double &v : dir) {
          v = pd::stdNormal(r.g);
          nr += v * v;
        }
        nr = std::sqrt(nr);
        double rr = rad * std::pow(1 + pd::uniform01(r.g) * (std::pow(2.0, double(d)) - 1), 1.0 / d);
        Vec q(static_cast<size_t>(d));
        bool inside = true;
        for (size_t t = 0; t < q.size(); t++) {
          q[t] = c[t] + rr * dir[t] / nr;
          inside = inside && q[t] >= 0 && q[t] <= 1;
        }
        if (inside && farEnough(q)) {
          pts.push_back(q);
          active.push_back(pts.size() - 1);
          found = true;
        }
      }
      if (!found)
        active.erase(active.begin() + ai);
    }
    Mat out(pts.size(), static_cast<size_t>(d));
    for (size_t i = 0; i < pts.size(); i++)
      for (size_t t = 0; t < size_t(d); t++)
        out(i, t) = pts[i][t];
    return toValue(out);
  } SP_END

  SP_ADD("multinomial_qmc", 3, 4, "pvals, n_trials, n, seed") {
    Vec p;
    long long nt, n;
    if (!getVec(a, 0, ctx, p) || !dimCount(a, 1, ctx, nt, 0, 100000000, "n_trials") || !dimCount(a, 2, ctx, n, 0, 10000000, "n"))
      return Value(0.0);
    double s = 0;
    for (double v : p) {
      if (!(v >= 0)) {
        ctx.fail("pvals must not be negative");
        return Value(0.0);
      }
      s += v;
    }
    if (p.empty() || std::fabs(s - 1) > 1e-8) {
      ctx.fail("pvals must sum to 1");
      return Value(0.0);
    }
    Rng r(a, 3);
    Vec cum(p.size());
    std::partial_sum(p.begin(), p.end(), cum.begin());
    cum.back() = 1;
    Mat out(static_cast<size_t>(n), p.size());
    for (size_t i = 0; i < size_t(n); i++) {
      Mat u = sobolPoints(1, size_t(nt), &r.g);
      for (double x : u.a)
        out(i, std::min<size_t>(p.size() - 1, std::upper_bound(cum.begin(), cum.end(), x) - cum.begin())) += 1;
    }
    return toValue(out);
  } SP_END

  SP_ADD("mvnormal_qmc", 2, 4, "mean, cov, n, seed") {
    Vec mu;
    if (!getVec(a, 0, ctx, mu) || mu.empty()) {
      if (ctx.ok())
        ctx.fail("mean must not be empty");
      return Value(0.0);
    }
    size_t d = mu.size(), ni = 1;
    Mat C = Mat::eye(d);
    if (a.size() >= 3) {
      if (!getSquare(a, 1, ctx, C))
        return Value(0.0);
      ni = 2;
    }
    long long n;
    if (!dimCount(a, ni, ctx, n, 1, 100000000, "n"))
      return Value(0.0);
    if (C.r != d) {
      ctx.fail("cov must be " + std::to_string(d) + " x " + std::to_string(d));
      return Value(0.0);
    }
    Vec w;
    Mat V;
    la::eigHermitian(C, w, V);
    for (double e : w)
      if (e < -1e-10 * (1 + std::fabs(w.back()))) {
        ctx.fail("cov must be positive semi-definite");
        return Value(0.0);
      }
    Rng r(a, ni + 1);
    Mat u = sobolPoints(d, size_t(n), &r.g), out(static_cast<size_t>(n), d);
    for (size_t i = 0; i < size_t(n); i++) {
      Vec z(d);
      for (size_t k = 0; k < d; k++)
        z[k] = sf::ndtri(std::min(1 - 1e-16, std::max(1e-16, u(i, k))));
      for (size_t j = 0; j < d; j++) {
        double s = mu[j];
        for (size_t k = 0; k < d; k++)
          s += V(j, k) * std::sqrt(std::max(0.0, w[k])) * z[k];
        out(i, j) = s;
      }
    }
    return toValue(out);
  } SP_END

  SP_ADD("discrepancy", 1, 2, "sample, method") {
    Mat x;
    if (!unitSample(a, 0, ctx, x))
      return Value(0.0);
    std::string m = optText(a, 1, "CD");
    if (m != "CD" && m != "WD" && m != "MD" && m != "L2-star") {
      ctx.fail("method must be \"CD\", \"WD\", \"MD\" or \"L2-star\"");
      return Value(0.0);
    }
    return Value(discrepancyOf(x, m));
  } SP_END

  SP_ADD("geometric_discrepancy", 1, 2, "sample, method") {
    Mat x;
    if (!unitSample(a, 0, ctx, x))
      return Value(0.0);
    if (x.r < 2) {
      ctx.fail("the sample needs at least two points");
      return Value(0.0);
    }
    std::string m = optText(a, 1, "mindist");
    if (m != "mindist" && m != "mst") {
      ctx.fail("method must be \"mindist\" or \"mst\"");
      return Value(0.0);
    }
    size_t n = x.r;
    Mat D(n, n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        double s = 0;
        for (size_t k = 0; k < x.c; k++)
          s += (x(i, k) - x(j, k)) * (x(i, k) - x(j, k));
        D(i, j) = std::sqrt(s);
      }
    if (m == "mindist") {
      double best = kInf;
      for (size_t i = 0; i < n; i++)
        for (size_t j = i + 1; j < n; j++)
          if (D(i, j) > 0)
            best = std::min(best, D(i, j));
      return Value(best);
    }
    // Prim's minimum spanning tree; zero distances are not edges
    std::vector<bool> in(n, false);
    Vec key(n, kInf);
    key[0] = 0;
    double tot = 0;
    size_t edges = 0;
    for (size_t it = 0; it < n; it++) {
      size_t u = n;
      for (size_t i = 0; i < n; i++)
        if (!in[i] && (u == n || key[i] < key[u]))
          u = i;
      in[u] = true;
      if (it > 0 && std::isfinite(key[u])) {
        tot += key[u];
        edges++;
      }
      for (size_t v = 0; v < n; v++)
        if (!in[v] && D(u, v) > 0 && D(u, v) < key[v])
          key[v] = D(u, v);
    }
    return Value(edges ? tot / edges : kNaN);
  } SP_END

  SP_ADD("update_discrepancy", 3, 3, "x_new, sample, initial") {
    Vec xn;
    Mat s;
    double init;
    if (!getVec(a, 0, ctx, xn) || !unitSample(a, 1, ctx, s) || !argNumber(a, 2, ctx, init))
      return Value(0.0);
    if (xn.size() != s.c) {
      ctx.fail("x_new must have one value per column of the sample");
      return Value(0.0);
    }
    for (double v : xn)
      if (!(v >= 0 && v <= 1)) {
        ctx.fail("x_new must be inside the unit hypercube");
        return Value(0.0);
      }
    double n = s.r + 1.0, p1 = 1, p3 = 1, d2 = 0;
    for (double v : xn) {
      double t = std::fabs(v - 0.5);
      p1 *= 1 + 0.5 * t - 0.5 * t * t;
      p3 *= 1 + t;
    }
    for (size_t i = 0; i < s.r; i++) {
      double q = 1;
      for (size_t k = 0; k < s.c; k++)
        q *= 1 + 0.5 * std::fabs(xn[k] - 0.5) + 0.5 * std::fabs(s(i, k) - 0.5) - 0.5 * std::fabs(xn[k] - s(i, k));
      d2 += q;
    }
    return Value(init - 2 / n * p1 + 2 / (n * n) * d2 + p3 / (n * n));
  } SP_END

  SP_ADD("qmc_scale", 3, 4, "sample, lower, upper, reverse") {
    Mat x;
    Vec lo, hi;
    if (!getMat(a, 0, ctx, x) || !getVec(a, 1, ctx, lo) || !getVec(a, 2, ctx, hi))
      return Value(0.0);
    if (lo.size() == 1)
      lo.assign(x.c, double(lo[0]));
    if (hi.size() == 1)
      hi.assign(x.c, double(hi[0]));
    if (lo.size() != x.c || hi.size() != x.c) {
      ctx.fail("lower and upper need one value per column of the sample");
      return Value(0.0);
    }
    for (size_t k = 0; k < x.c; k++)
      if (!(hi[k] > lo[k])) {
        ctx.fail("upper must be greater than lower");
        return Value(0.0);
      }
    bool rev = optBool(a, 3, false);
    for (size_t i = 0; i < x.r; i++)
      for (size_t k = 0; k < x.c; k++) {
        double &v = x(i, k);
        if (rev) {
          v = (v - lo[k]) / (hi[k] - lo[k]);
          if (v < 0 || v > 1) {
            ctx.fail("the sample is not inside the given bounds");
            return Value(0.0);
          }
        } else {
          if (v < 0 || v > 1) {
            ctx.fail("the sample must be inside the unit hypercube");
            return Value(0.0);
          }
          v = lo[k] + v * (hi[k] - lo[k]);
        }
      }
    return toValue(x);
  } SP_END

  // ---- samplers ----
  auto inversion = [](const Args &a, CallContext &ctx) -> Value {
    DistPtr d = readDist(a[0], ctx);
    long long n;
    if (!d || !argNonNegativeInt(a, 1, ctx, n))
      return Value(0.0);
    if (n > 100000000) {
      ctx.fail("n is too large");
      return Value(0.0);
    }
    Rng r(a, 2);
    Vec v(static_cast<size_t>(n));
    for (double &x : v) {
      x = d->ppf(pd::uniform01(r.g));
      if (d->failed()) {
        ctx.fail("the distribution's NC function could not be evaluated");
        return Value(0.0);
      }
    }
    return draws(v);
  };
  reg.add(makeSpec("sample_inverse_poly", SP_SEC, 2, 3, "dist, n, seed", inversion, false));
  reg.add(makeSpec("sample_inverse_hermite", SP_SEC, 2, 3, "dist, n, seed", inversion, false));
  reg.add(makeSpec("sample_fast_inverse", SP_SEC, 2, 3, "dist, n, seed", inversion, false));

  SP_ADD("sample_tdr", 3, 4, "pdf, dpdf, n, seed") {
    long long n;
    if (!isCallable(a[0]) || !isCallable(a[1])) {
      ctx.fail("pdf and dpdf must name NC functions of x");
      return Value(0.0);
    }
    if (!argNonNegativeInt(a, 2, ctx, n))
      return Value(0.0);
    Tdr t(a[0], a[1]);
    std::string why;
    if (!t.init(why)) {
      if (!t.f.failed && !t.df.failed)
        ctx.fail(why + " (needs a log-concave density)");
      else
        ctx.fail(t.f.failText());
      return Value(0.0);
    }
    Rng r(a, 3);
    Vec v(static_cast<size_t>(n));
    for (double &x : v) {
      bool ok = true;
      x = t.sample(r.g, ok);
      if (!ok) {
        ctx.fail(t.f.failed || t.df.failed ? t.f.failText() : "the sampler did not accept a point (is the density log-concave?)");
        return Value(0.0);
      }
    }
    return draws(v);
  } SP_END

  SP_ADD("sample_ratio_uniforms", 4, 6, "pdf, mode, area, n | pdf, umax, vmin, vmax, n") {
    if (!isCallable(a[0])) {
      ctx.fail("pdf must name an NC function of x");
      return Value(0.0);
    }
    for (size_t i = 1; i < a.size(); i++)
      if (!isPlainNumber(a[i])) {
        ctx.fail("the " + ordinal(i) + " argument must be a number");
        return Value(0.0);
      }
    NcFn f(a[0]);
    double umax, vmin, vmax, shift = 0;
    long long n;
    size_t seedAt;
    bool simple = a.size() == 4; // the general form may add a seed: 6 inputs
    if (simple) { // pdf, mode, area, n
      double mode = a[1].number, area = a[2].number;
      double fm = f.scalar(mode);
      if (f.failed || !(fm > 0) || !(area > 0)) {
        ctx.fail(f.failed ? f.failText() : "the pdf must be positive at the mode and area positive");
        return Value(0.0);
      }
      umax = std::sqrt(fm);
      vmax = area / umax;
      vmin = -vmax;
      shift = mode;
      n = static_cast<long long>(a[3].number);
      seedAt = 4;
    } else { // pdf, umax, vmin, vmax, n
      umax = a[1].number;
      vmin = a[2].number;
      vmax = a[3].number;
      n = static_cast<long long>(a[4].number);
      seedAt = 5;
    }
    if (n < 0 || !(umax > 0) || !(vmax > vmin)) {
      ctx.fail("needs n >= 0, umax > 0 and vmin < vmax");
      return Value(0.0);
    }
    Rng r(a, seedAt);
    Vec v(static_cast<size_t>(n));
    for (double &x : v) {
      bool got = false;
      for (int k = 0; k < 1000000 && !got; k++) {
        double u = pd::uniform01(r.g) * umax, w = vmin + pd::uniform01(r.g) * (vmax - vmin);
        double t = w / u + shift, p = f.scalar(t);
        if (f.failed) {
          ctx.fail(f.failText());
          return Value(0.0);
        }
        if (u * u <= p) {
          x = t;
          got = true;
        }
      }
      if (!got) {
        ctx.fail("no point was accepted: check the bounds");
        return Value(0.0);
      }
    }
    return draws(v);
  } SP_END

  auto discrete = [](bool alias) {
    return [alias](const Args &a, CallContext &ctx) -> Value {
      Vec p;
      long long n;
      if (!getVec(a, 0, ctx, p) || !argNonNegativeInt(a, 1, ctx, n))
        return Value(0.0);
      double s = 0;
      for (double v : p) {
        if (!(v >= 0) || !std::isfinite(v)) {
          ctx.fail("the probabilities must be finite and not negative");
          return Value(0.0);
        }
        s += v;
      }
      if (p.empty() || s <= 0) {
        ctx.fail("the probabilities must not all be 0");
        return Value(0.0);
      }
      size_t k = p.size();
      for (double &v : p)
        v /= s;
      Rng r(a, 2);
      Vec out(static_cast<size_t>(n));
      if (alias) { // Walker / Vose alias table
        Vec prob(k);
        std::vector<size_t> al(k), small, large;
        Vec q(k);
        for (size_t i = 0; i < k; i++) {
          q[i] = p[i] * k;
          (q[i] < 1 ? small : large).push_back(i);
        }
        while (!small.empty() && !large.empty()) {
          size_t l = small.back(), g = large.back();
          small.pop_back();
          large.pop_back();
          prob[l] = q[l];
          al[l] = g;
          q[g] = q[g] + q[l] - 1;
          (q[g] < 1 ? small : large).push_back(g);
        }
        for (size_t i : large)
          prob[i] = 1;
        for (size_t i : small)
          prob[i] = 1;
        for (double &x : out) {
          double u = pd::uniform01(r.g) * k;
          size_t i = std::min(k - 1, static_cast<size_t>(u));
          x = double((u - i) < prob[i] ? i : al[i]);
        }
      } else { // guide table
        Vec cum(k);
        std::partial_sum(p.begin(), p.end(), cum.begin());
        cum.back() = 1;
        std::vector<size_t> guide(k);
        size_t j = 0;
        for (size_t i = 0; i < k; i++) {
          while (cum[j] < double(i) / k)
            j++;
          guide[i] = j;
        }
        for (double &x : out) {
          double u = pd::uniform01(r.g);
          size_t i = guide[std::min(k - 1, size_t(u * k))];
          while (cum[i] < u)
            i++;
          x = double(i);
        }
      }
      return draws(out);
    };
  };
  reg.add(makeSpec("sample_discrete_alias", SP_SEC, 2, 3, "pv, n, seed", discrete(true), false));
  reg.add(makeSpec("sample_discrete_guide", SP_SEC, 2, 3, "pv, n, seed", discrete(false), false));

  reg.setParallel({"sample_inverse_poly", "sample_inverse_hermite", "sample_fast_inverse", "sample_tdr", "sample_ratio_uniforms"},
                  ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
