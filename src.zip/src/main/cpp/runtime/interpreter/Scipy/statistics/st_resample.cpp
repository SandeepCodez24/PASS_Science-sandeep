// Section 21, resampling: Monte Carlo and permutation tests, the bootstrap,
// the power of a test by simulation, Sobol sensitivity indices, and the
// multiscale graph correlation (MGC) test. The statistics are NC functions,
// so these run on the interpreter thread.
#include "st_dist.h"
#include "statistics_main.h"

#include "../../ops/matrix/matrix.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace {
using namespace st;

// A sample generator: a distribution (name or Dict) or an NC function of n.
struct Gen {
  DistPtr d;
  Value fn;
  bool viaNC = false;
  bool read(const Value &v, CallContext &ctx) {
    if (v.isText && pd::findFamily(v.text())) {
      d = readDist(v, ctx);
      return d != nullptr;
    }
    if (v.isDict) {
      d = readDist(v, ctx);
      return d != nullptr;
    }
    if (!isCallable(v)) {
      ctx.fail("a generator must be a distribution (\"norm\", normal_dist(0, 1)) or an NC function of n");
      return false;
    }
    fn = v;
    viaNC = true;
    return true;
  }
  bool draw(size_t n, std::mt19937_64 &g, Vec &out, CallContext &ctx) {
    if (!viaNC) {
      out.resize(n);
      for (double &x : out)
        x = d->rvs(g);
      if (d->failed()) {
        ctx.fail("the distribution's NC function could not be evaluated");
        return false;
      }
      return true;
    }
    Value r;
    if (!callNC(fn, {Value(double(n))}, r) || !readVec(r, out)) {
      ctx.fail("the generator could not be evaluated (it must return an array of n numbers)");
      return false;
    }
    if (out.size() != n) {
      ctx.fail("the generator returned " + std::to_string(out.size()) + " values instead of " + std::to_string(n));
      return false;
    }
    return true;
  }
};

// statistic(samples...) -> number
bool callStat(const Value &fn, const std::vector<Vec> &s, double &out, CallContext &ctx) {
  Args in;
  for (const Vec &v : s)
    in.push_back(toValue(v));
  Value r;
  Vec v;
  if (!callNC(fn, in, r) || !readVec(r, v) || v.empty()) {
    ctx.fail("the statistic function could not be evaluated (it must return a number)");
    return false;
  }
  out = v[0];
  return true;
}

// SciPy's p-value of `obs` within a null distribution (with its own 'gamma' tolerance)
double resampleP(const Vec &null, double obs, const std::string &alt, bool exact) {
  double gamma = std::fabs(obs) * kEps * 100, n = null.size(), less = 0, greater = 0;
  for (double v : null) {
    less += v <= obs + gamma;
    greater += v >= obs - gamma;
  }
  double adj = exact ? 0 : 1;
  double pl = (less + adj) / (n + adj), pg = (greater + adj) / (n + adj);
  if (alt == "less")
    return pl;
  if (alt == "greater")
    return pg;
  return std::min(1.0, 2 * std::min(pl, pg));
}

bool altArg(const Args &a, size_t i, CallContext &ctx, std::string &alt) {
  alt = optText(a, i, "two-sided");
  if (alt != "two-sided" && alt != "less" && alt != "greater") {
    ctx.fail("alternative must be \"two-sided\", \"less\" or \"greater\"");
    return false;
  }
  return true;
}

// Leading sample arguments (arrays, or a matrix of rows) up to the first function.
bool leadingSamples(const Args &a, size_t &next, CallContext &ctx, std::vector<Vec> &g) {
  size_t k = 0;
  while (k < a.size() && !a[k].isText && !a[k].isFunctionRef)
    k++;
  if (k == 0 || k == a.size()) {
    ctx.fail("give the sample(s), then the statistic function");
    return false;
  }
  Args s(a.begin(), a.begin() + k);
  if (!readGroups(s, 0, ctx, g, 1))
    return false;
  next = k;
  return true;
}

double pctl(Vec v, double q) { return quantile(std::move(v), std::min(1.0, std::max(0.0, q))); }

// ---- MGC ----
Mat distMat(const Mat &x) {
  size_t n = x.r;
  Mat D(n, n);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      double s = 0;
      for (size_t k = 0; k < x.c; k++)
        s += (x(i, k) - x(j, k)) * (x(i, k) - x(j, k));
      D(i, j) = std::sqrt(s);
    }
  return D;
}
void centerRank(const Mat &D, Mat &C, std::vector<std::vector<int>> &R) {
  size_t n = D.r;
  C = D;
  R.assign(n, std::vector<int>(n));
  for (size_t j = 0; j < n; j++) {
    Vec col(n);
    double m = 0;
    for (size_t i = 0; i < n; i++) {
      col[i] = D(i, j);
      m += col[i];
    }
    m = m / n * n / (n - 1.0);
    Vec r = rankdata(col, "dense");
    for (size_t i = 0; i < n; i++) {
      R[i][j] = int(r[i]) - 1;
      C(i, j) = D(i, j) - m;
    }
  }
  for (size_t i = 0; i < n; i++)
    C(i, i) = 0;
}
// cov_xy over (rank_x, rank_y) neighbourhoods; Y and RY are used transposed
Mat localCov(const Mat &X, const Mat &Y, const std::vector<std::vector<int>> &RX, const std::vector<std::vector<int>> &RY) {
  size_t n = X.r;
  int nx = 0, ny = 0;
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      nx = std::max(nx, RX[i][j] + 1);
      ny = std::max(ny, RY[j][i] + 1);
    }
  Mat cov(nx, ny);
  Vec ex(nx, 0.0), ey(ny, 0.0);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      double a = X(i, j), b = Y(j, i);
      int k = RX[i][j], l = RY[j][i];
      cov(k, l) += a * b;
      ex[k] += a;
      ey[l] += b;
    }
  for (int k = 1; k < nx; k++) {
    cov(k, 0) += cov(k - 1, 0);
    ex[k] += ex[k - 1];
  }
  for (int l = 1; l < ny; l++) {
    cov(0, l) += cov(0, l - 1);
    ey[l] += ey[l - 1];
  }
  for (int k = 0; k + 1 < nx; k++)
    for (int l = 0; l + 1 < ny; l++)
      cov(k + 1, l + 1) += cov(k + 1, l) + cov(k, l + 1) - cov(k, l);
  double n2 = double(n) * n;
  for (int k = 0; k < nx; k++)
    for (int l = 0; l < ny; l++)
      cov(k, l) -= ex[k] * ey[l] / n2;
  return cov;
}
Mat localCorr(const Mat &Dx, const Mat &Dy) {
  Mat Cx, Cy;
  std::vector<std::vector<int>> Rx, Ry;
  centerRank(Dx, Cx, Rx);
  centerRank(Dy, Cy, Ry);
  Mat cxy = localCov(Cx, Cy, Rx, Ry), vx = localCov(Cx, Cx, Rx, Rx), vy = localCov(Cy, Cy, Ry, Ry);
  Mat corr = cxy;
  for (size_t k = 0; k < corr.r; k++)
    for (size_t l = 0; l < corr.c; l++) {
      double a = vx(k, k), b = vy(l, l);
      if (a <= 0 || b <= 0) {
        corr(k, l) = 0;
        continue;
      }
      corr(k, l) = std::min(1.0, cxy(k, l) / std::sqrt(a * b));
    }
  return corr;
}
double mgcStat(const Mat &Dx, const Mat &Dy) {
  Mat M = localCorr(Dx, Dy);
  size_t m = M.r, n = M.c;
  double stat = M(m - 1, n - 1);
  if (m == 1 || n == 1)
    return stat;
  double ss = Dx.r - 1.0;
  double per = 1 - 0.02 / ss, th = ss * (ss - 3) / 4 - 0.5;
  const pd::Family *beta = pd::findFamily("beta");
  double pr[2] = {th, th};
  th = pd::ppf(*beta, per, pr) * 2 - 1;
  th = std::max(th, M(m - 1, n - 1));
  // largest 4-connected region above the threshold
  std::vector<int> lab(m * n, 0);
  int nl = 0;
  std::vector<int> sizes(1, 0);
  for (size_t s = 0; s < m * n; s++) {
    if (lab[s] || !(M.a[s] > th))
      continue;
    nl++;
    int cnt = 0;
    std::vector<size_t> st{s};
    lab[s] = nl;
    while (!st.empty()) {
      size_t c = st.back();
      st.pop_back();
      cnt++;
      size_t i = c / n, j = c % n;
      size_t nb[4] = {i > 0 ? c - n : c, i + 1 < m ? c + n : c, j > 0 ? c - 1 : c, j + 1 < n ? c + 1 : c};
      for (size_t q : nb)
        if (q != c && !lab[q] && M.a[q] > th) {
          lab[q] = nl;
          st.push_back(q);
        }
    }
    sizes.push_back(cnt);
  }
  if (nl == 0)
    return stat;
  int best = 1;
  for (int l = 2; l <= nl; l++)
    if (sizes[l] > sizes[best])
      best = l;
  if (sizes[best] >= std::ceil(0.02 * std::max(m, n)) * std::min(m, n)) {
    double mx = -kInf;
    for (size_t s = 0; s < m * n; s++)
      if (lab[s] == best)
        mx = std::max(mx, M.a[s]);
    if (mx >= stat)
      stat = mx;
  }
  return stat;
}
bool samplesMat(const Value &v, Mat &m) {
  if (!readMat(v, m))
    return false;
  if (!v.isMatrix || m.r == 1) { // one observation per element
    Vec a = m.a;
    m = Mat(a.size(), 1);
    m.a = a;
  }
  return true;
}
} // namespace

void registerStResample(Registry &reg) {
  SP_ADD("monte_carlo_test", 4, 5, "data, rvs, statistic, n, alternative") {
    Vec x;
    if (!getVec(a, 0, ctx, x) || x.empty()) {
      if (ctx.ok())
        ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    Gen gen;
    long long n;
    std::string alt;
    if (!gen.read(a[1], ctx) || !argNonNegativeInt(a, 3, ctx, n) || !altArg(a, 4, ctx, alt))
      return Value(0.0);
    if (!isCallable(a[2])) {
      ctx.fail("statistic must name an NC function");
      return Value(0.0);
    }
    double obs;
    if (!callStat(a[2], {x}, obs, ctx))
      return Value(0.0);
    std::mt19937_64 g(ncRandomEngine()());
    Vec null(static_cast<size_t>(n)), s;
    for (double &v : null)
      if (!gen.draw(x.size(), g, s, ctx) || !callStat(a[2], {s}, v, ctx))
        return Value(0.0);
    return makeDict({{"statistic", Value(obs)}, {"pvalue", Value(resampleP(null, obs, alt, false))}, {"null_distribution", toValue(null)}});
  } SP_END

  SP_ADD("permutation_test", 3, kVariadic, "samples..., statistic, n, alternative") {
    std::vector<Vec> g;
    size_t k;
    if (!leadingSamples(a, k, ctx, g))
      return Value(0.0);
    Value stat = a[k];
    long long n = 9999;
    if (k + 1 < a.size() && !argNonNegativeInt(a, k + 1, ctx, n))
      return Value(0.0);
    std::string alt;
    if (!altArg(a, k + 2, ctx, alt))
      return Value(0.0);
    if (g.size() < 2) {
      ctx.fail("needs at least two samples");
      return Value(0.0);
    }
    double obs;
    if (!callStat(stat, g, obs, ctx))
      return Value(0.0);
    Vec pool;
    std::vector<size_t> sz;
    for (const Vec &v : g) {
      pool.insert(pool.end(), v.begin(), v.end());
      sz.push_back(v.size());
    }
    size_t N = pool.size();
    // distinct partitions of the pooled data
    double parts = std::lgamma(N + 1.0);
    for (size_t s : sz)
      parts -= std::lgamma(s + 1.0);
    parts = std::exp(parts);
    Vec null;
    bool exact = g.size() == 2 && parts <= double(n) + 0.5;
    auto split = [&](const std::vector<size_t> &order) {
      std::vector<Vec> s;
      size_t off = 0;
      for (size_t m : sz) {
        Vec v;
        for (size_t i = 0; i < m; i++)
          v.push_back(pool[order[off + i]]);
        off += m;
        s.push_back(v);
      }
      return s;
    };
    if (exact) { // every choice of the first sample's positions
      std::vector<bool> pick(N, false);
      std::fill(pick.begin(), pick.begin() + sz[0], true);
      do {
        std::vector<size_t> order;
        for (size_t i = 0; i < N; i++)
          if (pick[i])
            order.push_back(i);
        for (size_t i = 0; i < N; i++)
          if (!pick[i])
            order.push_back(i);
        double v;
        if (!callStat(stat, split(order), v, ctx))
          return Value(0.0);
        null.push_back(v);
      } while (std::prev_permutation(pick.begin(), pick.end()));
    } else {
      std::mt19937_64 rg(ncRandomEngine()());
      std::vector<size_t> order(N);
      std::iota(order.begin(), order.end(), 0);
      for (long long r = 0; r < n; r++) {
        std::shuffle(order.begin(), order.end(), rg);
        double v;
        if (!callStat(stat, split(order), v, ctx))
          return Value(0.0);
        null.push_back(v);
      }
    }
    return makeDict({{"statistic", Value(obs)}, {"pvalue", Value(resampleP(null, obs, alt, exact))}, {"null_distribution", toValue(null)}});
  } SP_END

  SP_ADD("bootstrap", 2, kVariadic, "samples..., statistic, n, confidence, method") {
    std::vector<Vec> g;
    size_t k;
    if (!leadingSamples(a, k, ctx, g))
      return Value(0.0);
    Value stat = a[k];
    long long n = 9999;
    if (k + 1 < a.size() && !argNonNegativeInt(a, k + 1, ctx, n))
      return Value(0.0);
    double conf = optNum(a, k + 2, 0.95);
    std::string method = optText(a, k + 3, "BCa");
    if (!(conf > 0 && conf < 1) || n < 2) {
      ctx.fail("needs n >= 2 and 0 < confidence < 1");
      return Value(0.0);
    }
    if (method != "BCa" && method != "percentile" && method != "basic") {
      ctx.fail("method must be \"BCa\", \"percentile\" or \"basic\"");
      return Value(0.0);
    }
    double theta;
    if (!callStat(stat, g, theta, ctx))
      return Value(0.0);
    std::mt19937_64 rg(ncRandomEngine()());
    Vec boot(static_cast<size_t>(n));
    std::vector<Vec> s(g.size());
    for (double &v : boot) {
      for (size_t j = 0; j < g.size(); j++) {
        s[j].resize(g[j].size());
        std::uniform_int_distribution<size_t> pick(0, g[j].size() - 1);
        for (double &x : s[j])
          x = g[j][pick(rg)];
      }
      if (!callStat(stat, s, v, ctx))
        return Value(0.0);
    }
    double alpha = (1 - conf) / 2, lo, hi;
    if (method == "percentile") {
      lo = pctl(boot, alpha);
      hi = pctl(boot, 1 - alpha);
    } else if (method == "basic") {
      lo = 2 * theta - pctl(boot, 1 - alpha);
      hi = 2 * theta - pctl(boot, alpha);
    } else {
      double below = 0, eq = 0;
      for (double v : boot) {
        below += v < theta;
        eq += v == theta;
      }
      double z0 = sf::ndtri((below + eq / 2) / boot.size());
      // acceleration from the jackknife, sample by sample
      double num = 0, den = 0;
      for (size_t j = 0; j < g.size(); j++) {
        size_t nj = g[j].size();
        if (nj < 2)
          continue;
        Vec th(nj);
        std::vector<Vec> jk(g);
        for (size_t i = 0; i < nj; i++) {
          jk[j] = g[j];
          jk[j].erase(jk[j].begin() + i);
          if (!callStat(stat, jk, th[i], ctx))
            return Value(0.0);
        }
        double m = mean(th), s3 = 0, s2 = 0;
        for (double t : th) {
          double u = (nj - 1.0) * (m - t);
          s3 += u * u * u;
          s2 += u * u;
        }
        num += s3 / std::pow(double(nj), 3);
        den += s2 / std::pow(double(nj), 2);
      }
      double ah = den > 0 ? num / (6 * std::pow(den, 1.5)) : 0;
      double za = sf::ndtri(alpha), n1 = z0 + za, n2 = z0 - za;
      double a1 = sf::ndtr(z0 + n1 / (1 - ah * n1)), a2 = sf::ndtr(z0 + n2 / (1 - ah * n2));
      lo = std::isnan(a1) ? kNaN : pctl(boot, a1);
      hi = std::isnan(a2) ? kNaN : pctl(boot, a2);
    }
    return makeDict({{"confidence_interval", toValue(Vec{lo, hi})},
                     {"standard_error", Value(std::sqrt(var(boot)))},
                     {"bootstrap_distribution", toValue(boot)}});
  } SP_END

  SP_ADD("test_power", 3, 5, "test, rvs, n_obs, n, significance") {
    if (!isCallable(a[0])) {
      ctx.fail("test must name a test function (\"ttest_ind\") or an NC function returning a p-value");
      return Value(0.0);
    }
    std::vector<Value> rv = listItems(a[1]);
    Vec nobs;
    if (!getVec(a, 2, ctx, nobs))
      return Value(0.0);
    if (nobs.size() == 1 && rv.size() > 1)
      nobs.assign(rv.size(), nobs[0]);
    if (nobs.size() != rv.size()) {
      ctx.fail("give one sample size per generator");
      return Value(0.0);
    }
    long long n = 10000;
    if (a.size() > 3 && !argNonNegativeInt(a, 3, ctx, n))
      return Value(0.0);
    double alpha = optNum(a, 4, 0.01);
    std::vector<Gen> gens(rv.size());
    for (size_t i = 0; i < rv.size(); i++) {
      if (!gens[i].read(rv[i], ctx))
        return Value(0.0);
      if (!(nobs[i] >= 1) || nobs[i] != std::floor(nobs[i])) {
        ctx.fail("the sample sizes must be whole numbers >= 1");
        return Value(0.0);
      }
    }
    std::mt19937_64 g(ncRandomEngine()());
    double hits = 0;
    for (long long r = 0; r < n; r++) {
      Args in;
      for (size_t i = 0; i < gens.size(); i++) {
        Vec s;
        if (!gens[i].draw(size_t(nobs[i]), g, s, ctx))
          return Value(0.0);
        in.push_back(toValue(s));
      }
      Value out;
      if (!callNC(a[0], in, out)) {
        ctx.fail("the test could not be evaluated");
        return Value(0.0);
      }
      const Value *pv = dictGet(out, "pvalue");
      double p = pv && isPlainNumber(*pv) ? pv->number : (isPlainNumber(out) ? out.number : kNaN);
      if (std::isnan(p)) {
        ctx.fail("the test must return a p-value or a Dict with a 'pvalue' field");
        return Value(0.0);
      }
      hits += p < alpha;
    }
    return makeDict({{"power", Value(n ? hits / n : kNaN)}});
  } SP_END

  SP_ADD("sobol_indices", 3, 3, "fn, n, dists") {
    if (!isCallable(a[0])) {
      ctx.fail("fn must name an NC function of a d x n matrix (one column per point)");
      return Value(0.0);
    }
    long long n;
    if (!argInt(a, 1, ctx, n))
      return Value(0.0);
    if (n < 2 || (n & (n - 1)) != 0 || n > (1 << 22)) {
      ctx.fail("n must be a power of 2 (from 2 to 4194304)");
      return Value(0.0);
    }
    std::vector<Value> dv = listItems(a[2]);
    size_t d = dv.size();
    if (2 * d > 1024) {
      ctx.fail("at most 512 inputs");
      return Value(0.0);
    }
    std::vector<DistPtr> ds;
    for (const Value &v : dv) {
      DistPtr p = readDist(v, ctx);
      if (!p)
        return Value(0.0);
      ds.push_back(p);
    }
    std::mt19937_64 g(ncRandomEngine()());
    Mat u = sobolPoints(2 * d, size_t(n), &g);
    Mat A(d, static_cast<size_t>(n)), B(d, static_cast<size_t>(n));
    for (size_t i = 0; i < size_t(n); i++)
      for (size_t j = 0; j < d; j++) {
        A(j, i) = ds[j]->ppf(u(i, j));
        B(j, i) = ds[j]->ppf(u(i, d + j));
      }
    auto eval = [&](const Mat &X, Vec &f) {
      Value out;
      if (!callNC(a[0], {toValue(X)}, out) || !readVec(out, f) || f.size() != size_t(n)) {
        ctx.fail("fn must return one value per column (point)");
        return false;
      }
      return true;
    };
    Vec fA, fB;
    if (!eval(A, fA) || !eval(B, fB))
      return Value(0.0);
    Vec both(fA);
    both.insert(both.end(), fB.begin(), fB.end());
    double v = var(both, 0);
    Vec S1(d), ST(d);
    for (size_t j = 0; j < d; j++) {
      Mat AB = A;
      for (size_t i = 0; i < size_t(n); i++)
        AB(j, i) = B(j, i);
      Vec fAB;
      if (!eval(AB, fAB))
        return Value(0.0);
      double s1 = 0, st = 0;
      for (size_t i = 0; i < size_t(n); i++) {
        s1 += fB[i] * (fAB[i] - fA[i]);
        st += (fA[i] - fAB[i]) * (fA[i] - fAB[i]);
      }
      S1[j] = s1 / n / v;
      ST[j] = 0.5 * st / n / v;
    }
    return makeDict({{"first_order", toValue(S1)}, {"total_order", toValue(ST)}});
  } SP_END

  SP_ADD("mgc_test", 2, 4, "x, y, reps, seed") {
    Mat x, y;
    if (!samplesMat(a[0], x) || !samplesMat(a[1], y)) {
      ctx.fail("x and y must be arrays or matrices (one row per observation)");
      return Value(0.0);
    }
    long long reps = 1000;
    if (a.size() > 2 && !argNonNegativeInt(a, 2, ctx, reps))
      return Value(0.0);
    if (x.r != y.r) {
      if (x.c != y.c) {
        ctx.fail("x and y must have the same number of rows, or the same number of columns (two-sample test)");
        return Value(0.0);
      }
      // two-sample: stack the samples, labels 0 / 1
      Mat s(x.r + y.r, x.c), l(x.r + y.r, 1);
      for (size_t i = 0; i < x.r; i++)
        std::copy(x.row(i), x.row(i) + x.c, s.row(i));
      for (size_t i = 0; i < y.r; i++) {
        std::copy(y.row(i), y.row(i) + y.c, s.row(x.r + i));
        l(x.r + i, 0) = 1;
      }
      x = s;
      y = l;
    }
    if (x.r < 5) {
      ctx.fail("MGC needs at least 5 samples");
      return Value(0.0);
    }
    Mat Dx = distMat(x), Dy = distMat(y);
    double stat = mgcStat(Dx, Dy);
    std::mt19937_64 g = isNumberArg(a, 3) ? std::mt19937_64(std::uint64_t(a[3].number)) : std::mt19937_64(ncRandomEngine()());
    size_t n = Dy.r;
    std::vector<size_t> o(n);
    std::iota(o.begin(), o.end(), 0);
    double ge = 0;
    Vec null;
    for (long long r = 0; r < reps; r++) {
      std::shuffle(o.begin(), o.end(), g);
      Mat P(n, n);
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
          P(i, j) = Dy(o[i], o[j]);
      double s = mgcStat(Dx, P);
      null.push_back(s);
      ge += s >= stat;
    }
    return makeDict({{"statistic", Value(stat)}, {"pvalue", Value((1 + ge) / (1 + reps))}, {"null_dist", toValue(null)}});
  } SP_END

  reg.setParallel({"monte_carlo_test", "permutation_test", "bootstrap", "test_power", "sobol_indices"}, ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
