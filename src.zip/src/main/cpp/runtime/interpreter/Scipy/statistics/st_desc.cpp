// Section 21, descriptive part: summaries, moments, trimmed statistics,
// ranks, frequency tables, binned statistics, transforms (Box-Cox,
// Yeo-Johnson), probability plots, circular statistics, distances, KDE and
// contingency-table helpers.
#include "st_common.h"
#include "statistics_main.h"

#include <map>

#include "../special_functions/sf_ufunc.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::Statistics

namespace st {

std::vector<Value> listItems(const Value &v) {
  std::vector<Value> out;
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      out.push_back(v.at(i));
  } else if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        out.push_back(v.at(r, c));
  } else {
    out.push_back(v);
  }
  return out;
}

bool readGroups(const Args &a, size_t from, CallContext &ctx, std::vector<Vec> &groups, size_t minGroups) {
  groups.clear();
  auto dropNaN = [](Vec v) {
    v.erase(std::remove_if(v.begin(), v.end(), [](double d) { return std::isnan(d); }), v.end());
    return v;
  };
  if (a.size() == from + 1 && a[from].isMatrix && a[from].rows() > 1) {
    Mat m;
    if (!getMat(a, from, ctx, m))
      return false;
    for (size_t i = 0; i < m.r; i++)
      groups.push_back(dropNaN(Vec(m.row(i), m.row(i) + m.c)));
  } else {
    for (size_t i = from; i < a.size(); i++) {
      Vec g;
      if (!getVec(a, i, ctx, g))
        return false;
      groups.push_back(dropNaN(g));
    }
  }
  if (groups.size() < minGroups) {
    ctx.fail("give at least " + std::to_string(minGroups) +
             " samples, as separate arrays or as the rows of one matrix (pad shorter rows with NaN)");
    return false;
  }
  for (const Vec &g : groups)
    if (g.empty()) {
      ctx.fail("every sample needs at least one value");
      return false;
    }
  return true;
}

} // namespace st

namespace {
using namespace st;

bool getData(const Args &a, size_t i, CallContext &ctx, Vec &x, size_t minN = 1) {
  if (!getVec(a, i, ctx, x))
    return false;
  if (x.size() < minN) {
    ctx.fail("the " + ordinal(i) + " argument needs at least " + std::to_string(minN) + " values");
    return false;
  }
  return true;
}

bool limitsArg(const Args &a, size_t i, CallContext &ctx, double &lo, double &hi) {
  lo = -kInf;
  hi = kInf;
  if (isOmitted(a, i) && !(i < a.size() && isPlainNumber(a[i])))
    return true;
  Vec l;
  if (!getVec(a, i, ctx, l))
    return false;
  if (l.size() != 2) {
    ctx.fail("the limits must be an array [low, high]");
    return false;
  }
  lo = std::isnan(l[0]) ? -kInf : l[0];
  hi = std::isnan(l[1]) ? kInf : l[1];
  return true;
}

Vec within(const Vec &x, double lo, double hi) {
  Vec o;
  for (double v : x)
    if (v >= lo && v <= hi)
      o.push_back(v);
  return o;
}

Value histResult(const Vec &x, long long bins, bool cumulative, const char *first) {
  double mn = *std::min_element(x.begin(), x.end()), mx = *std::max_element(x.begin(), x.end());
  double s = (mx - mn) / (2.0 * (bins - 1.0));
  double lo = mn - s, hi = mx + s;
  if (bins == 1) {
    lo = mn - 0.5;
    hi = mx + 0.5;
  }
  Vec edges(bins + 1);
  for (long long i = 0; i <= bins; i++)
    edges[i] = lo + (hi - lo) * i / bins;
  Vec h(bins, 0.0), sx = sorted(x);
  for (long long b = 0; b < bins; b++) {
    auto l = std::lower_bound(sx.begin(), sx.end(), edges[b]);
    auto r = std::lower_bound(sx.begin(), sx.end(), edges[b + 1]);
    h[b] = double(r - l);
  }
  double inLast = 0;
  for (double v : x)
    if (v == edges[bins])
      inLast++;
  h[bins - 1] += inLast;
  double binned = 0;
  for (double c : h)
    binned += c;
  double extra = x.size() - binned;
  if (cumulative)
    for (long long b = 1; b < bins; b++)
      h[b] += h[b - 1];
  else
    for (double &c : h)
      c /= x.size();
  return makeDict({{first, toValue(h)}, {"lowerlimit", Value(lo)}, {"binsize", Value(edges[1] - edges[0])},
                   {"extrapoints", Value(extra)}});
}

double statOf(const std::string &s, const Vec &v) {
  if (s == "count")
    return double(v.size());
  if (v.empty())
    return (s == "sum") ? 0.0 : kNaN;
  if (s == "mean")
    return mean(v);
  if (s == "sum") {
    double t = 0;
    for (double d : v)
      t += d;
    return t;
  }
  if (s == "median")
    return median(v);
  if (s == "std")
    return std::sqrt(var(v, 0));
  if (s == "min")
    return *std::min_element(v.begin(), v.end());
  if (s == "max")
    return *std::max_element(v.begin(), v.end());
  return kNaN;
}
bool statName(const std::string &s, CallContext &ctx) {
  static const char *ok[] = {"mean", "sum", "count", "median", "std", "min", "max"};
  for (const char *o : ok)
    if (s == o)
      return true;
  ctx.fail("statistic must be \"mean\", \"sum\", \"count\", \"median\", \"std\", \"min\" or \"max\"");
  return false;
}

Vec edgesOf(const Vec &x, long long bins) {
  double lo = *std::min_element(x.begin(), x.end()), hi = *std::max_element(x.begin(), x.end());
  if (lo == hi) {
    lo -= 0.5;
    hi += 0.5;
  }
  Vec e(bins + 1);
  for (long long i = 0; i <= bins; i++)
    e[i] = lo + (hi - lo) * i / bins;
  return e;
}
// 1-based bin number in [1, bins], the last bin closed on the right.
long long binOf(const Vec &e, double v) {
  long long b = std::upper_bound(e.begin(), e.end(), v) - e.begin();
  if (v == e.back())
    b = static_cast<long long>(e.size()) - 1;
  return b;
}

double boxcoxT(double x, double l) { return l == 0 ? std::log(x) : std::expm1(l * std::log(x)) / l; }
double yjT(double x, double l) {
  if (x >= 0)
    return l == 0 ? std::log1p(x) : std::expm1(l * std::log1p(x)) / l;
  return l == 2 ? -std::log1p(-x) : -std::expm1((2 - l) * std::log1p(-x)) / (2 - l);
}
double boxcoxLlf(double l, const Vec &x) {
  double sl = 0;
  Vec y(x.size());
  for (size_t i = 0; i < x.size(); i++) {
    sl += std::log(x[i]);
    y[i] = boxcoxT(x[i], l);
  }
  return (l - 1) * sl - x.size() / 2.0 * std::log(var(y, 0));
}
double yjLlf(double l, const Vec &x) {
  double s = 0;
  Vec y(x.size());
  for (size_t i = 0; i < x.size(); i++) {
    s += (x[i] < 0 ? -1.0 : 1.0) * std::log1p(std::fabs(x[i]));
    y[i] = yjT(x[i], l);
  }
  return -double(x.size()) / 2.0 * std::log(var(y, 0)) + (l - 1) * s;
}
double normR(const Vec &y) { // probability-plot correlation against the normal law
  Vec m = orderStatMedians(y.size()), osm(y.size());
  for (size_t i = 0; i < y.size(); i++)
    osm[i] = sf::ndtri(m[i]);
  return pearson(osm, sorted(y));
}
double distR(const std::string &dist, const Vec &y, double shape) {
  const pd::Family *f = pd::findFamily(dist);
  Vec m = orderStatMedians(y.size()), osm(y.size());
  for (size_t i = 0; i < y.size(); i++)
    osm[i] = pd::ppf(*f, m[i], &shape);
  return pearson(osm, sorted(y));
}

double circMean(const Vec &x, double hi, double lo) {
  double s = 0, c = 0, k = 2 * kPi / (hi - lo);
  for (double v : x) {
    s += std::sin((v - lo) * k);
    c += std::cos((v - lo) * k);
  }
  double r = std::atan2(s, c);
  if (r < 0)
    r += 2 * kPi;
  double out = r / k + lo;
  if (out >= hi) // keep in [lo, hi)
    out -= hi - lo;
  return out;
}
double circR(const Vec &x, double hi, double lo) {
  double s = 0, c = 0, k = 2 * kPi / (hi - lo);
  for (double v : x) {
    s += std::sin((v - lo) * k);
    c += std::cos((v - lo) * k);
  }
  return std::hypot(s, c) / x.size();
}

// 1-D Wasserstein / energy distance from the two empirical cdfs.
double cdfDistance(int p, const Vec &u, const Vec &v) {
  Vec su = sorted(u), sv = sorted(v), all = su;
  all.insert(all.end(), sv.begin(), sv.end());
  std::sort(all.begin(), all.end());
  double total = 0;
  for (size_t i = 0; i + 1 < all.size(); i++) {
    double d = all[i + 1] - all[i];
    double cu = double(std::upper_bound(su.begin(), su.end(), all[i]) - su.begin()) / su.size();
    double cv = double(std::upper_bound(sv.begin(), sv.end(), all[i]) - sv.begin()) / sv.size();
    total += (p == 1 ? std::fabs(cu - cv) : (cu - cv) * (cu - cv)) * d;
  }
  return p == 1 ? total : std::sqrt(2 * total);
}

// Minimum-cost assignment (Hungarian algorithm) for wasserstein_nd with equal sizes.
double assignmentCost(const Mat &C) {
  size_t n = C.r;
  std::vector<double> u(n + 1), v(n + 1);
  std::vector<size_t> p(n + 1), way(n + 1);
  for (size_t i = 1; i <= n; i++) {
    p[0] = i;
    size_t j0 = 0;
    std::vector<double> minv(n + 1, kInf);
    std::vector<char> used(n + 1, 0);
    do {
      used[j0] = 1;
      size_t i0 = p[j0], j1 = 0;
      double delta = kInf;
      for (size_t j = 1; j <= n; j++)
        if (!used[j]) {
          double cur = C(i0 - 1, j - 1) - u[i0] - v[j];
          if (cur < minv[j]) {
            minv[j] = cur;
            way[j] = j0;
          }
          if (minv[j] < delta) {
            delta = minv[j];
            j1 = j;
          }
        }
      for (size_t j = 0; j <= n; j++)
        if (used[j]) {
          u[p[j]] += delta;
          v[j] -= delta;
        } else
          minv[j] -= delta;
      j0 = j1;
    } while (p[j0] != 0);
    do {
      size_t j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0);
  }
  double cost = 0;
  for (size_t j = 1; j <= n; j++)
    cost += C(p[j] - 1, j - 1);
  return cost;
}

// Gaussian KDE with Scott's or Silverman's factor (or a given one).
bool kde(const Mat &data, const Mat &pts, double bwFactor, Vec &out) {
  size_t d = data.r, n = data.c;
  // covariance of the data (rows = dimensions)
  Mat cov(d, d);
  Vec mu(d, 0.0);
  for (size_t i = 0; i < d; i++) {
    for (size_t k = 0; k < n; k++)
      mu[i] += data(i, k);
    mu[i] /= n;
  }
  for (size_t i = 0; i < d; i++)
    for (size_t j = 0; j < d; j++) {
      double s = 0;
      for (size_t k = 0; k < n; k++)
        s += (data(i, k) - mu[i]) * (data(j, k) - mu[j]);
      cov(i, j) = s / (n - 1) * bwFactor * bwFactor;
    }
  // Cholesky of the kernel covariance
  Mat L(d, d);
  for (size_t i = 0; i < d; i++)
    for (size_t j = 0; j <= i; j++) {
      double s = cov(i, j);
      for (size_t k = 0; k < j; k++)
        s -= L(i, k) * L(j, k);
      if (i == j) {
        if (s <= 0)
          return false;
        L(i, i) = std::sqrt(s);
      } else
        L(i, j) = s / L(j, j);
    }
  double logdet = 0;
  for (size_t i = 0; i < d; i++)
    logdet += 2 * std::log(L(i, i));
  double norm = std::exp(-0.5 * logdet - d / 2.0 * std::log(2 * kPi)) / n;
  out.assign(pts.c, 0.0);
  for (size_t q = 0; q < pts.c; q++) {
    double s = 0;
    for (size_t k = 0; k < n; k++) {
      Vec z(d);
      for (size_t i = 0; i < d; i++) {
        double t = pts(i, q) - data(i, k);
        for (size_t j = 0; j < i; j++)
          t -= L(i, j) * z[j];
        z[i] = t / L(i, i);
      }
      double e = 0;
      for (double zi : z)
        e += zi * zi;
      s += std::exp(-0.5 * e);
    }
    out[q] = s * norm;
  }
  return true;
}

Mat expectedFreq(const Mat &t) {
  double tot = 0;
  Vec rs(t.r, 0.0), cs(t.c, 0.0);
  for (size_t i = 0; i < t.r; i++)
    for (size_t j = 0; j < t.c; j++) {
      rs[i] += t(i, j);
      cs[j] += t(i, j);
      tot += t(i, j);
    }
  Mat e(t.r, t.c);
  for (size_t i = 0; i < t.r; i++)
    for (size_t j = 0; j < t.c; j++)
      e(i, j) = rs[i] * cs[j] / tot;
  return e;
}
} // namespace

namespace st {
// Chi-square statistic of a table (with Yates' correction for one degree of freedom).
double chi2Table(const Mat &t, bool correction, double &dof, Mat &expected) {
  expected = expectedFreq(t);
  dof = double((t.r - 1) * (t.c - 1));
  double s = 0;
  for (size_t i = 0; i < t.a.size(); i++) {
    double d = t.a[i] - expected.a[i];
    if (correction && dof == 1) {
      double c = std::min(0.5, std::fabs(d));
      d = std::fabs(d) - c;
    }
    s += d * d / expected.a[i];
  }
  return s;
}
} // namespace st

void registerStDesc(Registry &reg) {
  SP_ADD("describe", 1, 2, "data, ddof") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double ddof = optNum(a, 1, 1);
    return makeDict({{"nobs", Value(double(x.size()))},
                     {"minmax", toValue(Vec{*std::min_element(x.begin(), x.end()), *std::max_element(x.begin(), x.end())})},
                     {"mean", Value(mean(x))},
                     {"variance", Value(var(x, ddof))},
                     {"skewness", Value(skewness(x))},
                     {"kurtosis", Value(kurtosis(x))}});
  } SP_END

  SP_ADD("power_mean", 2, 2, "data, p") {
    Vec x;
    double p;
    if (!getData(a, 0, ctx, x) || !argNumber(a, 1, ctx, p))
      return Value(0.0);
    for (double v : x)
      if (v < 0) {
        ctx.fail("the data must not be negative");
        return Value(0.0);
      }
    if (p == 0) {
      double s = 0;
      for (double v : x)
        s += std::log(v);
      return Value(std::exp(s / x.size()));
    }
    if (std::isinf(p))
      return Value(p > 0 ? *std::max_element(x.begin(), x.end()) : *std::min_element(x.begin(), x.end()));
    double s = 0;
    for (double v : x)
      s += std::pow(v, p);
    return Value(std::pow(s / x.size(), 1 / p));
  } SP_END

  SP_ADD("moment", 1, 3, "data, order, center") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double k = optNum(a, 1, 1);
    double c = (a.size() > 2 && isPlainNumber(a[2])) ? a[2].number : mean(x);
    if (k == 1 && a.size() <= 2)
      return Value(0.0);
    double s = 0;
    for (double v : x)
      s += std::pow(v - c, k);
    return Value(s / x.size());
  } SP_END

  SP_ADD("lmoment", 1, 3, "data, order, standardize") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    Vec order = {1, 2, 3, 4};
    if (a.size() > 1 && !isOmitted(a, 1) && !getVec(a, 1, ctx, order))
      return Value(0.0);
    bool stdz = optBool(a, 2, true);
    int kmax = 0;
    for (double o : order) {
      if (!(o >= 1 && o <= 10000) || o != std::floor(o)) {
        ctx.fail("orders must be whole numbers from 1 to 10000");
        return Value(0.0);
      }
      kmax = std::max(kmax, static_cast<int>(o));
    }
    Vec s = sorted(x);
    size_t n = s.size();
    // probability weighted moments b_r, then l_{r+1} = sum_k p*_{r,k} b_k (shifted Legendre)
    Vec b(kmax, 0.0), l(kmax, kNaN);
    for (int r = 0; r < kmax && r < static_cast<int>(n); r++) {
      double t = 0;
      for (size_t i = r; i < n; i++)
        t += std::exp(std::lgamma(double(i) + 1) - std::lgamma(double(i) - r + 1) -
                      (std::lgamma(double(n)) - std::lgamma(double(n) - r))) *
             s[i];
      b[r] = t / n;
    }
    for (int r = 0; r < kmax && r < static_cast<int>(n); r++) {
      double t = 0;
      for (int k = 0; k <= r; k++) {
        double c = ((r - k) % 2 ? -1.0 : 1.0) * sf::binom(r, k) * sf::binom(r + k, k);
        t += c * b[k];
      }
      l[r] = t;
    }
    if (stdz)
      for (int r = 2; r < kmax; r++)
        l[r] /= l[1];
    Vec out;
    for (double o : order)
      out.push_back(l[static_cast<int>(o) - 1]);
    if (isNumberArg(a, 1))
      return Value(out[0]);
    return toValue(out);
  } SP_END

  SP_ADD("expectile", 1, 2, "data, alpha") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double al = optNum(a, 1, 0.5);
    if (al < 0 || al > 1) {
      ctx.fail("alpha must lie in [0, 1]");
      return Value(0.0);
    }
    auto f = [&](double t) {
      double s = 0;
      for (double v : x)
        s += std::fabs((v <= t ? 1.0 : 0.0) - al) * (t - v);
      return s / x.size();
    };
    double lo = *std::min_element(x.begin(), x.end()), hi = *std::max_element(x.begin(), x.end());
    if (lo == hi)
      return Value(lo);
    return Value(sf::brent(f, lo, hi, 1e-15, 500));
  } SP_END

  SP_ADD("kstat", 1, 2, "data, n") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double k = optNum(a, 1, 2);
    if (k < 1 || k > 4 || k != std::floor(k)) {
      ctx.fail("n must be 1, 2, 3 or 4");
      return Value(0.0);
    }
    double N = x.size(), S[5] = {0, 0, 0, 0, 0};
    for (double v : x)
      for (int j = 1; j <= 4; j++)
        S[j] += std::pow(v, j);
    double r;
    if (k == 1)
      r = S[1] / N;
    else if (k == 2)
      r = (N * S[2] - S[1] * S[1]) / (N * (N - 1));
    else if (k == 3)
      r = (2 * S[1] * S[1] * S[1] - 3 * N * S[1] * S[2] + N * N * S[3]) / (N * (N - 1) * (N - 2));
    else
      r = (-6 * std::pow(S[1], 4) + 12 * N * S[1] * S[1] * S[2] - 3 * N * (N - 1) * S[2] * S[2] -
           4 * N * (N + 1) * S[1] * S[3] + N * N * (N + 1) * S[4]) /
          (N * (N - 1) * (N - 2) * (N - 3));
    return Value(r);
  } SP_END

  SP_ADD("kstat_var", 1, 2, "data, n") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double k = optNum(a, 1, 1), N = x.size();
    double S[5] = {0, 0, 0, 0, 0};
    for (double v : x)
      for (int j = 1; j <= 4; j++)
        S[j] += std::pow(v, j);
    double k2 = (N * S[2] - S[1] * S[1]) / (N * (N - 1));
    if (k == 1)
      return Value(k2 / N);
    if (k == 2) {
      double k4 = (-6 * std::pow(S[1], 4) + 12 * N * S[1] * S[1] * S[2] - 3 * N * (N - 1) * S[2] * S[2] -
                   4 * N * (N + 1) * S[1] * S[3] + N * N * (N + 1) * S[4]) /
                  (N * (N - 1) * (N - 2) * (N - 3));
      return Value((2 * N * k2 * k2 + (N - 1) * k4) / (N * (N + 1)));
    }
    ctx.fail("n must be 1 or 2");
    return Value(0.0);
  } SP_END

  SP_ADD("trimmed_mean", 1, 2, "data, limits") {
    Vec x;
    double lo, hi;
    if (!getData(a, 0, ctx, x) || !limitsArg(a, 1, ctx, lo, hi))
      return Value(0.0);
    Vec y = within(x, lo, hi);
    return Value(y.empty() ? kNaN : mean(y));
  } SP_END
  SP_ADD("trimmed_var", 1, 2, "data, limits") {
    Vec x;
    double lo, hi;
    if (!getData(a, 0, ctx, x) || !limitsArg(a, 1, ctx, lo, hi))
      return Value(0.0);
    Vec y = within(x, lo, hi);
    return Value(y.size() < 2 ? kNaN : var(y, 1));
  } SP_END
  SP_ADD("trimmed_sd", 1, 2, "data, limits") {
    Vec x;
    double lo, hi;
    if (!getData(a, 0, ctx, x) || !limitsArg(a, 1, ctx, lo, hi))
      return Value(0.0);
    Vec y = within(x, lo, hi);
    return Value(y.size() < 2 ? kNaN : std::sqrt(var(y, 1)));
  } SP_END
  SP_ADD("trimmed_sem", 1, 2, "data, limits") {
    Vec x;
    double lo, hi;
    if (!getData(a, 0, ctx, x) || !limitsArg(a, 1, ctx, lo, hi))
      return Value(0.0);
    Vec y = within(x, lo, hi);
    return Value(y.size() < 2 ? kNaN : std::sqrt(var(y, 1) / y.size()));
  } SP_END
  SP_ADD("trimmed_min", 1, 2, "data, lower") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double lo = a.size() > 1 && isPlainNumber(a[1]) ? a[1].number : -kInf;
    Vec y = within(x, lo, kInf);
    return Value(y.empty() ? kNaN : *std::min_element(y.begin(), y.end()));
  } SP_END
  SP_ADD("trimmed_max", 1, 2, "data, upper") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double hi = a.size() > 1 && isPlainNumber(a[1]) ? a[1].number : kInf;
    Vec y = within(x, -kInf, hi);
    return Value(y.empty() ? kNaN : *std::max_element(y.begin(), y.end()));
  } SP_END

  SP_ADD("rank_data", 1, 2, "data, method") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    std::string m = optText(a, 1, "average");
    if (m != "average" && m != "min" && m != "max" && m != "dense" && m != "ordinal") {
      ctx.fail("method must be \"average\", \"min\", \"max\", \"dense\" or \"ordinal\"");
      return Value(0.0);
    }
    for (double v : x)
      if (std::isnan(v)) {
        Vec r(x.size(), kNaN);
        return toValue(r);
      }
    return toValue(rankdata(x, m));
  } SP_END

  SP_ADD("tie_correct", 1, 1, "ranks") {
    Vec r;
    if (!getData(a, 0, ctx, r))
      return Value(0.0);
    return Value(tieCorrect(r));
  } SP_END

  SP_ADD("geo_sd", 1, 2, "data, ddof") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    Vec l(x.size());
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] <= 0) {
        ctx.fail("the data must be positive");
        return Value(0.0);
      }
      l[i] = std::log(x[i]);
    }
    return Value(std::exp(std::sqrt(var(l, optNum(a, 1, 1)))));
  } SP_END

  SP_ADD("geo_zscore", 1, 2, "data, ddof") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    Vec l(x.size());
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] <= 0) {
        ctx.fail("the data must be positive");
        return Value(0.0);
      }
      l[i] = std::log(x[i]);
    }
    double m = mean(l), s = std::sqrt(var(l, optNum(a, 1, 0)));
    for (double &v : l)
      v = (v - m) / s;
    return toValue(l);
  } SP_END

  SP_ADD("zmap", 2, 3, "scores, compare, ddof") {
    Vec s, c;
    if (!getData(a, 0, ctx, s) || !getData(a, 1, ctx, c, 2))
      return Value(0.0);
    double m = mean(c), sd = std::sqrt(var(c, optNum(a, 2, 0)));
    for (double &v : s)
      v = (v - m) / sd;
    return isPlainNumber(a[0]) ? Value(s[0]) : toValue(s);
  } SP_END

  SP_ADD("entropy", 1, 3, "p, q, base") {
    Vec p, q;
    if (!getData(a, 0, ctx, p))
      return Value(0.0);
    bool haveQ = a.size() > 1 && !isOmitted(a, 1);
    if (haveQ && !getVec(a, 1, ctx, q))
      return Value(0.0);
    if (haveQ && q.size() != p.size()) {
      ctx.fail("p and q must have the same length");
      return Value(0.0);
    }
    double base = optNum(a, 2, 0);
    double sp = 0, sq = 0;
    for (double v : p)
      sp += v;
    for (double v : q)
      sq += v;
    double h = 0;
    for (size_t i = 0; i < p.size(); i++) {
      double pi = p[i] / sp;
      if (!haveQ)
        h += pi > 0 ? -pi * std::log(pi) : (pi == 0 ? 0.0 : -kInf);
      else {
        double qi = q[i] / sq;
        h += pi > 0 && qi > 0 ? pi * std::log(pi / qi) : (pi == 0 && qi >= 0 ? 0.0 : kInf);
      }
    }
    if (base > 0)
      h /= std::log(base);
    return Value(h);
  } SP_END

  SP_ADD("differential_entropy", 1, 3, "data, method, window_length") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    size_t n = x.size();
    std::string method = optText(a, 1, "auto");
    long long m = isNumberArg(a, 2) ? static_cast<long long>(a[2].number) : static_cast<long long>(std::floor(std::sqrt(double(n)) + 0.5));
    if (!(2 <= 2 * m && 2 * m < static_cast<long long>(n))) {
      ctx.fail("the window length must be positive and less than half the sample size");
      return Value(0.0);
    }
    if (method == "auto")
      method = n <= 10 ? "van es" : (n <= 1000 ? "ebrahimi" : "vasicek");
    Vec s = sorted(x);
    auto X = [&](long long i) { return s[std::min<long long>(std::max<long long>(i, 0), n - 1)]; };
    double h = 0;
    if (method == "vasicek") {
      for (long long i = 0; i < (long long)n; i++)
        h += std::log(n / (2.0 * m) * (X(i + m) - X(i - m)));
      h /= n;
    } else if (method == "van es") {
      for (long long i = 0; i + m < (long long)n; i++)
        h += std::log((n + 1.0) / m * (s[i + m] - s[i]));
      h /= (n - m);
      for (long long k = m; k <= (long long)n; k++)
        h += 1.0 / k;
      h += std::log(double(m)) - std::log(n + 1.0);
    } else if (method == "ebrahimi") {
      for (long long i = 1; i <= (long long)n; i++) {
        double ci = i <= m ? 1 + (i - 1.0) / m : 2.0;
        if (i >= (long long)n - m + 1)
          ci = 1 + double(n - i) / m;
        h += std::log(n * (X(i - 1 + m) - X(i - 1 - m)) / (ci * m));
      }
      h /= n;
    } else if (method == "correa") {
      for (long long i = 1; i <= (long long)n; i++) {
        double xb = 0;
        for (long long j = i - m; j <= i + m; j++)
          xb += X(j - 1);
        xb /= (2 * m + 1);
        double num = 0, den = 0;
        for (long long j = i - m; j <= i + m; j++) {
          double d = X(j - 1) - xb;
          num += d * (j - i);
          den += d * d;
        }
        h += std::log(num / (n * den));
      }
      h = -h / n;
    } else {
      ctx.fail("method must be \"auto\", \"vasicek\", \"van es\", \"ebrahimi\" or \"correa\"");
      return Value(0.0);
    }
    return Value(h);
  } SP_END

  SP_ADD("median_abs_dev", 1, 2, "data, scale") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double scale = 1.0;
    if (a.size() > 1) {
      if (a[1].isText) {
        if (a[1].text() != "normal") {
          ctx.fail("scale must be a number or \"normal\"");
          return Value(0.0);
        }
        scale = 1.0 / sf::ndtri(0.75);
      } else
        scale = optNum(a, 1, 1.0);
    }
    double m = median(x);
    Vec d(x.size());
    for (size_t i = 0; i < x.size(); i++)
      d[i] = std::fabs(x[i] - m);
    return Value(median(d) / scale);
  } SP_END

  SP_ADD("cum_freq", 1, 2, "data, bins") {
    Vec x;
    long long b = 10;
    if (!getData(a, 0, ctx, x) || (a.size() > 1 && !argNonNegativeInt(a, 1, ctx, b)))
      return Value(0.0);
    if (b < 1) {
      ctx.fail("bins must be at least 1");
      return Value(0.0);
    }
    return histResult(x, b, true, "cumcount");
  } SP_END

  SP_ADD("rel_freq", 1, 2, "data, bins") {
    Vec x;
    long long b = 10;
    if (!getData(a, 0, ctx, x) || (a.size() > 1 && !argNonNegativeInt(a, 1, ctx, b)))
      return Value(0.0);
    if (b < 1) {
      ctx.fail("bins must be at least 1");
      return Value(0.0);
    }
    return histResult(x, b, false, "frequency");
  } SP_END

  SP_ADD("percentile_of_score", 2, 3, "data, score, kind") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    std::string kind = optText(a, 2, "rank");
    if (kind != "rank" && kind != "weak" && kind != "strict" && kind != "mean") {
      ctx.fail("kind must be \"rank\", \"weak\", \"strict\" or \"mean\"");
      return Value(0.0);
    }
    return umap(Args{a[1]}, ctx, 1, {}, [&](const double *s) -> double {
      double n = x.size(), left = 0, right = 0;
      for (double v : x) {
        left += v < s[0];
        right += v <= s[0];
      }
      if (kind == "rank")
        return (left + right + (left < right ? 1 : 0)) * (50.0 / n);
      if (kind == "strict")
        return left * 100.0 / n;
      if (kind == "weak")
        return right * 100.0 / n;
      return (left + right) * 50.0 / n;
    });
  } SP_END

  SP_ADD("binned_stat", 2, 4, "x, y, statistic, bins") {
    Vec x, y;
    if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    std::string st = optText(a, 2, "mean");
    long long bins = optInt(a, 3, 10);
    if (!statName(st, ctx))
      return Value(0.0);
    if (bins < 1 || bins > 1000000) {
      ctx.fail("bins must be from 1 to 1000000");
      return Value(0.0);
    }
    Vec e = edgesOf(x, bins), bn(x.size());
    std::vector<Vec> grp(bins);
    for (size_t i = 0; i < x.size(); i++) {
      long long b = binOf(e, x[i]);
      bn[i] = double(b);
      if (b >= 1 && b <= bins)
        grp[b - 1].push_back(y[i]);
    }
    Vec out(bins);
    for (long long b = 0; b < bins; b++)
      out[b] = statOf(st, grp[b]);
    return makeDict({{"statistic", toValue(out)}, {"bin_edges", toValue(e)}, {"binnumber", toValue(bn)}});
  } SP_END

  SP_ADD("binned_stat2d", 2, 5, "x, y, values, statistic, bins") {
    Vec x, y, v;
    if (!getData(a, 0, ctx, x) || !getData(a, 1, ctx, y))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    bool haveV = a.size() > 2 && !isOmitted(a, 2);
    if (haveV && !getVec(a, 2, ctx, v))
      return Value(0.0);
    if (!haveV)
      v.assign(x.size(), 0.0);
    std::string st = optText(a, 3, "mean");
    long long bins = optInt(a, 4, 10);
    if (!statName(st, ctx))
      return Value(0.0);
    if (bins < 1 || bins > 10000) {
      ctx.fail("bins must be from 1 to 10000");
      return Value(0.0);
    }
    Vec ex = edgesOf(x, bins), ey = edgesOf(y, bins);
    std::vector<Vec> grp(bins * bins);
    for (size_t i = 0; i < x.size(); i++) {
      long long bx = binOf(ex, x[i]), by = binOf(ey, y[i]);
      if (bx >= 1 && bx <= bins && by >= 1 && by <= bins)
        grp[(bx - 1) * bins + by - 1].push_back(v[i]);
    }
    Mat out(bins, bins);
    for (long long i = 0; i < bins * bins; i++)
      out.a[i] = statOf(st, grp[i]);
    return makeDict({{"statistic", toValue(out)}, {"x_edge", toValue(ex)}, {"y_edge", toValue(ey)}});
  } SP_END

  SP_ADD("binned_stat_dd", 1, 4, "sample, values, statistic, bins") {
    Mat s;
    Vec v;
    if (!getMat(a, 0, ctx, s))
      return Value(0.0);
    bool haveV = a.size() > 1 && !isOmitted(a, 1);
    if (haveV && !getVec(a, 1, ctx, v))
      return Value(0.0);
    if (!haveV)
      v.assign(s.r, 0.0);
    std::string st = optText(a, 2, "mean");
    long long bins = optInt(a, 3, 10);
    if (!statName(st, ctx))
      return Value(0.0);
    size_t d = s.c;
    double cells = std::pow(double(bins), double(d));
    if (bins < 1 || cells > 1e7) {
      ctx.fail("bins^dimensions must be at most 10000000");
      return Value(0.0);
    }
    std::vector<Vec> edges(d);
    for (size_t j = 0; j < d; j++) {
      Vec col(s.r);
      for (size_t i = 0; i < s.r; i++)
        col[i] = s(i, j);
      edges[j] = edgesOf(col, bins);
    }
    std::vector<Vec> grp(static_cast<size_t>(cells));
    for (size_t i = 0; i < s.r; i++) {
      size_t idx = 0;
      bool in = true;
      for (size_t j = 0; j < d; j++) {
        long long b = binOf(edges[j], s(i, j));
        if (b < 1 || b > bins)
          in = false;
        idx = idx * bins + (b - 1);
      }
      if (in)
        grp[idx].push_back(v[i]);
    }
    Vec out(grp.size());
    for (size_t i = 0; i < grp.size(); i++)
      out[i] = statOf(st, grp[i]);
    Mat em(d, bins + 1);
    for (size_t j = 0; j < d; j++)
      std::copy(edges[j].begin(), edges[j].end(), em.row(j));
    return makeDict({{"statistic", toValue(out)}, {"bin_edges", toValue(em)}});
  } SP_END

  SP_ADD("obrien_transform", 1, kVariadic, "groups...") {
    std::vector<Vec> g;
    if (!readGroups(a, 0, ctx, g, 1))
      return Value(0.0);
    size_t maxn = 0;
    for (const Vec &x : g)
      maxn = std::max(maxn, x.size());
    Mat out(g.size(), maxn, kNaN);
    for (size_t k = 0; k < g.size(); k++) {
      const Vec &x = g[k];
      double n = x.size(), m = mean(x), v = var(x, 1);
      if (n < 3) {
        ctx.fail("every group needs at least 3 values");
        return Value(0.0);
      }
      for (size_t i = 0; i < x.size(); i++)
        out(k, i) = ((n - 1.5) * n * (x[i] - m) * (x[i] - m) - 0.5 * v * (n - 1)) / ((n - 1) * (n - 2));
    }
    return toValue(out);
  } SP_END

  SP_ADD("sigma_clip", 1, 3, "data, low, high") {
    Vec c;
    if (!getData(a, 0, ctx, c))
      return Value(0.0);
    double lo = optNum(a, 1, 4), hi = optNum(a, 2, 4), cl = 0, cu = 0;
    size_t before;
    do {
      before = c.size();
      double m = mean(c), s = std::sqrt(var(c, 0));
      cl = m - s * lo;
      cu = m + s * hi;
      c = within(c, cl, cu);
    } while (c.size() != before && !c.empty());
    return makeDict({{"clipped", toValue(c)}, {"lower", Value(cl)}, {"upper", Value(cu)}});
  } SP_END

  SP_ADD("trim_both", 2, 2, "data, cut") {
    Vec x;
    double cut;
    if (!getData(a, 0, ctx, x) || !argNumber(a, 1, ctx, cut))
      return Value(0.0);
    if (!(cut >= 0 && cut <= 1)) {
      ctx.fail("the proportion must be from 0 to 1");
      return Value(0.0);
    }
    size_t n = x.size(), lo = static_cast<size_t>(cut * n), hi = n - lo;
    if (lo >= hi) {
      ctx.fail("the proportion is too big");
      return Value(0.0);
    }
    Vec s = sorted(x);
    return toValue(Vec(s.begin() + lo, s.begin() + hi));
  } SP_END

  SP_ADD("trim_one", 2, 3, "data, cut, tail") {
    Vec x;
    double cut;
    if (!getData(a, 0, ctx, x) || !argNumber(a, 1, ctx, cut))
      return Value(0.0);
    std::string tail = optText(a, 2, "right");
    if (tail != "left" && tail != "right") {
      ctx.fail("tail must be \"left\" or \"right\"");
      return Value(0.0);
    }
    size_t n = x.size();
    if (cut >= 1)
      return toValue(Vec());
    size_t k = static_cast<size_t>(cut * n);
    Vec s = sorted(x);
    return tail == "left" ? toValue(Vec(s.begin() + k, s.end())) : toValue(Vec(s.begin(), s.end() - k));
  } SP_END

  // ---- Box-Cox and Yeo-Johnson ----
  SP_ADD("boxcox_llf", 2, 2, "lmbda, data") {
    double l;
    Vec x;
    if (!argNumber(a, 0, ctx, l) || !getData(a, 1, ctx, x))
      return Value(0.0);
    return Value(boxcoxLlf(l, x));
  } SP_END
  SP_ADD("yeojohnson_llf", 2, 2, "lmbda, data") {
    double l;
    Vec x;
    if (!argNumber(a, 0, ctx, l) || !getData(a, 1, ctx, x))
      return Value(0.0);
    return Value(yjLlf(l, x));
  } SP_END

  SP_ADD("boxcox_normmax", 1, 2, "data, method") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    for (double v : x)
      if (v <= 0) {
        ctx.fail("the data must be positive");
        return Value(0.0);
      }
    std::string m = optText(a, 1, "pearsonr");
    if (m == "mle")
      return Value(minimize1([&](double l) { return -boxcoxLlf(l, x); }, -2.0, 2.0));
    if (m != "pearsonr") {
      ctx.fail("method must be \"pearsonr\" or \"mle\"");
      return Value(0.0);
    }
    return Value(minimize1([&](double l) {
      Vec y(x.size());
      for (size_t i = 0; i < x.size(); i++)
        y[i] = boxcoxT(x[i], l);
      return 1 - normR(y);
    }, -2.0, 2.0));
  } SP_END

  SP_ADD("boxcox_fit", 1, 2, "data, lmbda") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    for (double v : x)
      if (v <= 0) {
        ctx.fail("the data must be positive");
        return Value(0.0);
      }
    double l = isNumberArg(a, 1) ? a[1].number : minimize1([&](double t) { return -boxcoxLlf(t, x); }, -2.0, 2.0);
    Vec y(x.size());
    for (size_t i = 0; i < x.size(); i++)
      y[i] = boxcoxT(x[i], l);
    return makeDict({{"data", toValue(y)}, {"lambda", Value(l)}});
  } SP_END

  SP_ADD("yeojohnson_normmax", 1, 1, "data") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    return Value(minimize1([&](double l) { return -yjLlf(l, x); }, -2.0, 2.0));
  } SP_END

  SP_ADD("yeojohnson_fit", 1, 2, "data, lmbda") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    double l = isNumberArg(a, 1) ? a[1].number : minimize1([&](double t) { return -yjLlf(t, x); }, -2.0, 2.0);
    Vec y(x.size());
    for (size_t i = 0; i < x.size(); i++)
      y[i] = yjT(x[i], l);
    return makeDict({{"data", toValue(y)}, {"lambda", Value(l)}});
  } SP_END

  SP_ADD("boxcox_normplot", 3, 4, "data, la, lb, N") {
    Vec x;
    double la, lb;
    if (!getData(a, 0, ctx, x, 2) || !argNumber(a, 1, ctx, la) || !argNumber(a, 2, ctx, lb))
      return Value(0.0);
    long long N = optInt(a, 3, 80);
    if (N < 2 || N > 100000 || !(lb > la)) {
      ctx.fail("needs la < lb and N from 2 to 100000");
      return Value(0.0);
    }
    for (double v : x)
      if (v <= 0) {
        ctx.fail("the data must be positive");
        return Value(0.0);
      }
    Vec ls(N), pc(N);
    for (long long i = 0; i < N; i++) {
      ls[i] = la + (lb - la) * i / (N - 1);
      Vec y(x.size());
      for (size_t k = 0; k < x.size(); k++)
        y[k] = boxcoxT(x[k], ls[i]);
      pc[i] = normR(y);
    }
    return makeDict({{"lmbdas", toValue(ls)}, {"ppcc", toValue(pc)}});
  } SP_END
  SP_ADD("yeojohnson_normplot", 3, 4, "data, la, lb, N") {
    Vec x;
    double la, lb;
    if (!getData(a, 0, ctx, x, 2) || !argNumber(a, 1, ctx, la) || !argNumber(a, 2, ctx, lb))
      return Value(0.0);
    long long N = optInt(a, 3, 80);
    if (N < 2 || N > 100000 || !(lb > la)) {
      ctx.fail("needs la < lb and N from 2 to 100000");
      return Value(0.0);
    }
    Vec ls(N), pc(N);
    for (long long i = 0; i < N; i++) {
      ls[i] = la + (lb - la) * i / (N - 1);
      Vec y(x.size());
      for (size_t k = 0; k < x.size(); k++)
        y[k] = yjT(x[k], ls[i]);
      pc[i] = normR(y);
    }
    return makeDict({{"lmbdas", toValue(ls)}, {"ppcc", toValue(pc)}});
  } SP_END

  SP_ADD("ppcc_max", 1, 2, "data, dist") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    std::string d = optText(a, 1, "tukeylambda");
    const pd::Family *f = pd::findFamily(d);
    if (!f || f->nshape != 1) {
      ctx.fail("dist must be the name of a distribution with one shape parameter");
      return Value(0.0);
    }
    return Value(minimize1([&](double s) {
      double r = distR(d, x, s);
      return std::isnan(r) ? 2.0 : 1 - r;
    }, 0.0, 1.0));
  } SP_END

  SP_ADD("ppcc_plot", 3, 5, "data, a, b, dist, N") {
    Vec x;
    double lo, hi;
    if (!getData(a, 0, ctx, x, 2) || !argNumber(a, 1, ctx, lo) || !argNumber(a, 2, ctx, hi))
      return Value(0.0);
    std::string d = optText(a, 3, "tukeylambda");
    long long N = optInt(a, 4, 80);
    const pd::Family *f = pd::findFamily(d);
    if (!f || f->nshape != 1 || N < 2 || N > 100000) {
      ctx.fail("dist must be the name of a distribution with one shape parameter, N from 2 to 100000");
      return Value(0.0);
    }
    Vec sv(N), pc(N);
    for (long long i = 0; i < N; i++) {
      sv[i] = lo + (hi - lo) * i / (N - 1);
      pc[i] = distR(d, x, sv[i]);
    }
    return makeDict({{"svals", toValue(sv)}, {"ppcc", toValue(pc)}});
  } SP_END

  SP_ADD("prob_plot", 1, 3, "data, dist, shape") {
    Vec x;
    if (!getData(a, 0, ctx, x, 2))
      return Value(0.0);
    std::string d = optText(a, 1, "norm");
    const pd::Family *f = pd::findFamily(d);
    if (!f) {
      ctx.fail("unknown distribution '" + d + "'");
      return Value(0.0);
    }
    Vec shapes(f->nshape, 0.0);
    if (f->nshape > 0) {
      Vec s;
      if (a.size() < 3 || !getVec(a, 2, ctx, s) || s.size() != static_cast<size_t>(f->nshape)) {
        if (ctx.ok())
          ctx.fail("give the shape parameters of '" + d + "' as the third argument");
        return Value(0.0);
      }
      shapes = s;
    }
    Vec m = orderStatMedians(x.size()), osm(x.size()), osr = sorted(x);
    for (size_t i = 0; i < x.size(); i++)
      osm[i] = pd::ppf(*f, m[i], shapes.data());
    double sl, ic, r;
    linregress(osm, osr, sl, ic, r);
    return makeDict({{"osm", toValue(osm)}, {"osr", toValue(osr)}, {"slope", Value(sl)}, {"intercept", Value(ic)},
                     {"r", Value(r)}});
  } SP_END

  SP_ADD("ecdf", 1, 2, "data, x") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    Vec s = sorted(x);
    if (a.size() < 2) {
      Vec q, p;
      for (size_t i = 0; i < s.size(); i++)
        if (i + 1 == s.size() || s[i + 1] != s[i]) {
          q.push_back(s[i]);
          p.push_back(double(i + 1) / s.size());
        }
      return makeDict({{"quantiles", toValue(q)}, {"probabilities", toValue(p)}});
    }
    return umap(Args{a[1]}, ctx, 1, {}, [&](const double *v) -> double {
      return double(std::upper_bound(s.begin(), s.end(), v[0]) - s.begin()) / s.size();
    });
  } SP_END
  // SciPy's Hyndman-Fan estimators: three step methods (offset dp) and six
  // interpolating ones (plotting positions a, b); "linear" is the default.
  SP_ADD("estimated_cdf", 2, 3, "data, x, method") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    const std::string m = optText(a, 2, "linear");
    static const std::map<std::string, double> steps = {
        {"inverted_cdf", 0.0}, {"averaged_inverted_cdf", 0.0}, {"closest_observation", 0.5}};
    static const std::map<std::string, std::pair<double, double>> lines = {
        {"interpolated_inverted_cdf", {0.0, 1.0}}, {"hazen", {0.5, 0.5}}, {"weibull", {0.0, 0.0}},
        {"linear", {1.0, 1.0}}, {"median_unbiased", {1.0 / 3, 1.0 / 3}}, {"normal_unbiased", {0.375, 0.375}}};
    const auto st = steps.find(m);
    const auto ln = lines.find(m);
    if (st == steps.end() && ln == lines.end()) {
      ctx.fail("estimated_cdf: unknown method \"" + m + "\"");
      return Value(0.0);
    }
    Vec s = sorted(x);
    const double n = double(s.size());
    return umap(Args{a[1]}, ctx, 1, {}, [&](const double *v) -> double {
      const double y = v[0];
      if (std::isnan(y))
        return y;
      if (y < s.front())
        return 0.0;
      if (y > s.back())
        return 1.0;
      const size_t up = size_t(std::upper_bound(s.begin(), s.end(), y) - s.begin());
      double p;
      if (st != steps.end()) {
        p = (double(up) + st->second) / n;
      } else {
        const size_t jmax = s.size() - 1, jmin = std::min<size_t>(jmax, 1);
        const size_t jp1 = std::clamp(up, jmin, jmax);
        const size_t j = jp1 > 0 ? jp1 - 1 : 0;
        const double xj = s[j], xj1 = s[jp1];
        const double delta = xj1 > xj && std::isfinite(xj) ? (y - xj) / (xj1 - xj) : 1.0;
        p = (double(jp1) + delta - ln->second.first) / (n + 1 - ln->second.first - ln->second.second);
      }
      return std::clamp(p, 0.0, 1.0);
    });
  } SP_END

  // ---- circular ----
  SP_ADD("circ_mean", 1, 3, "angles, high, low") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double hi = optNum(a, 1, 2 * kPi), lo = optNum(a, 2, 0);
    if (!(hi > lo)) {
      ctx.fail("high must be above low");
      return Value(0.0);
    }
    return Value(circMean(x, hi, lo));
  } SP_END
  SP_ADD("circ_var", 1, 3, "angles, high, low") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double hi = optNum(a, 1, 2 * kPi), lo = optNum(a, 2, 0);
    return Value(1 - circR(x, hi, lo));
  } SP_END
  SP_ADD("circ_sd", 1, 3, "angles, high, low") {
    Vec x;
    if (!getData(a, 0, ctx, x))
      return Value(0.0);
    double hi = optNum(a, 1, 2 * kPi), lo = optNum(a, 2, 0);
    double r = std::min(1.0, circR(x, hi, lo));
    return Value((hi - lo) / (2 * kPi) * std::sqrt(-2 * std::log(r)));
  } SP_END

  SP_ADD("directional_stats", 1, 2, "data, normalize") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    bool norm = optBool(a, 1, true);
    Vec s(m.c, 0.0);
    for (size_t i = 0; i < m.r; i++) {
      double l = 0;
      for (size_t j = 0; j < m.c; j++)
        l += m(i, j) * m(i, j);
      l = norm ? std::sqrt(l) : 1.0;
      for (size_t j = 0; j < m.c; j++)
        s[j] += m(i, j) / l;
    }
    double len = 0;
    for (double &v : s) {
      v /= m.r;
      len += v * v;
    }
    len = std::sqrt(len);
    Vec dir(s);
    for (double &v : dir)
      v /= len;
    return makeDict({{"mean_direction", toValue(dir)}, {"mean_resultant_length", Value(len)}});
  } SP_END

  // ---- distances between samples ----
  SP_ADD("wasserstein", 2, 2, "u, v") {
    Vec u, v;
    if (!getData(a, 0, ctx, u) || !getData(a, 1, ctx, v))
      return Value(0.0);
    return Value(cdfDistance(1, u, v));
  } SP_END
  SP_ADD("energy_distance", 2, 2, "u, v") {
    Vec u, v;
    if (!getData(a, 0, ctx, u) || !getData(a, 1, ctx, v))
      return Value(0.0);
    return Value(cdfDistance(2, u, v));
  } SP_END
  SP_ADD("wasserstein_nd", 2, 2, "u, v") {
    Mat u, v;
    if (!getMat(a, 0, ctx, u) || !getMat(a, 1, ctx, v))
      return Value(0.0);
    if (u.c != v.c) {
      ctx.fail("the point sets must have the same number of columns");
      return Value(0.0);
    }
    if (u.r != v.r) {
      ctx.fail("this version needs point sets of the same size");
      return Value(0.0);
    }
    if (u.r > 2000) {
      ctx.fail("at most 2000 points per set");
      return Value(0.0);
    }
    for (const Mat *m : {&u, &v})
      for (double e : m->a)
        if (!std::isfinite(e)) {
          ctx.fail("the points must be finite");
          return Value(0.0);
        }
    Mat C(u.r, v.r);
    for (size_t i = 0; i < u.r; i++)
      for (size_t j = 0; j < v.r; j++) {
        double s = 0;
        for (size_t k = 0; k < u.c; k++)
          s += (u(i, k) - v(j, k)) * (u(i, k) - v(j, k));
        C(i, j) = std::sqrt(s);
      }
    return Value(assignmentCost(C) / u.r);
  } SP_END

  SP_ADD("gaussian_kde", 2, 3, "data, points, bw") {
    Mat d, p;
    if (!getMat(a, 0, ctx, d) || !getMat(a, 1, ctx, p))
      return Value(0.0);
    if (d.r == 1 && p.r != 1) { // 1-D data with a column of points
      Mat q(1, p.a.size());
      q.a = p.a;
      p = q;
    }
    if (d.r == 1 && p.r == 1) {
    } else if (p.r != d.r) {
      ctx.fail("data and points must have the same number of rows (one row per dimension)");
      return Value(0.0);
    }
    double n = d.c, dim = d.r;
    double fac = std::pow(n, -1.0 / (dim + 4)); // Scott
    if (a.size() > 2) {
      if (a[2].isText) {
        if (a[2].text() == "silverman")
          fac = std::pow(n * (dim + 2) / 4.0, -1.0 / (dim + 4));
        else if (a[2].text() != "scott") {
          ctx.fail("bw must be \"scott\", \"silverman\" or a number");
          return Value(0.0);
        }
      } else if (isPlainNumber(a[2]) && a[2].number > 0)
        fac = a[2].number;
    }
    Vec out;
    if (!kde(d, p, fac, out)) {
      ctx.fail("the data covariance is singular");
      return Value(0.0);
    }
    return isPlainNumber(a[1]) ? Value(out[0]) : toValue(out);
  } SP_END

  // ---- contingency tables ----
  SP_ADD("crosstab", 2, 2, "a, b") {
    std::vector<Value> A = listItems(a[0]), B = listItems(a[1]);
    if (A.size() != B.size()) {
      ctx.fail("a and b must have the same length");
      return Value(0.0);
    }
    auto key = [](const Value &v) { return v.isText ? "s" + v.text() : "n" + std::to_string(v.number); };
    std::map<std::string, Value> ua, ub;
    for (const Value &v : A)
      ua.emplace(key(v), v);
    for (const Value &v : B)
      ub.emplace(key(v), v);
    // order: numbers ascending, texts ascending (NumPy's unique sorts)
    auto ordered = [](const std::map<std::string, Value> &m) {
      std::vector<Value> out;
      std::vector<std::pair<double, Value>> nums;
      for (const auto &kv : m)
        if (!kv.second.isText)
          nums.push_back({kv.second.number, kv.second});
      std::sort(nums.begin(), nums.end(), [](const auto &x, const auto &y) { return x.first < y.first; });
      for (auto &p : nums)
        out.push_back(p.second);
      for (const auto &kv : m)
        if (kv.second.isText)
          out.push_back(kv.second);
      return out;
    };
    std::vector<Value> la = ordered(ua), lb = ordered(ub);
    std::map<std::string, size_t> ia, ib;
    for (size_t i = 0; i < la.size(); i++)
      ia[key(la[i])] = i;
    for (size_t i = 0; i < lb.size(); i++)
      ib[key(lb[i])] = i;
    Mat c(la.size(), lb.size());
    for (size_t i = 0; i < A.size(); i++)
      c(ia[key(A[i])], ib[key(B[i])]) += 1;
    return makeDict({{"elements_a", Value(std::vector<std::vector<Value>>{la})},
                     {"elements_b", Value(std::vector<std::vector<Value>>{lb})},
                     {"count", toValue(c)}});
  } SP_END

  SP_ADD("margins", 1, 1, "table") {
    Mat t;
    if (!getMat(a, 0, ctx, t))
      return Value(0.0);
    Mat rs(t.r, 1);
    Vec cs(t.c, 0.0);
    for (size_t i = 0; i < t.r; i++)
      for (size_t j = 0; j < t.c; j++) {
        rs(i, 0) += t(i, j);
        cs[j] += t(i, j);
      }
    return makeDict({{"rows", toValue(rs)}, {"cols", toValue(cs)}});
  } SP_END

  SP_ADD("expected_freq", 1, 1, "table") {
    Mat t;
    if (!getMat(a, 0, ctx, t))
      return Value(0.0);
    return toValue(expectedFreq(t));
  } SP_END

  SP_ADD("association", 1, 3, "table, method, correction") {
    Mat t;
    if (!getMat(a, 0, ctx, t))
      return Value(0.0);
    std::string m = optText(a, 1, "cramer");
    double dof;
    Mat e;
    double chi2 = chi2Table(t, optBool(a, 2, false), dof, e);
    double n = 0;
    for (double v : t.a)
      n += v;
    double phi2 = chi2 / n;
    double r = t.r, c = t.c;
    if (m == "cramer")
      return Value(std::sqrt(phi2 / std::min(r - 1, c - 1)));
    if (m == "tschuprow")
      return Value(std::sqrt(phi2 / std::sqrt((r - 1) * (c - 1))));
    if (m == "pearson")
      return Value(std::sqrt(phi2 / (1 + phi2)));
    ctx.fail("method must be \"cramer\", \"tschuprow\" or \"pearson\"");
    return Value(0.0);
  } SP_END

  SP_ADD("relative_risk", 4, 4, "exposed_cases, exposed_total, control_cases, control_total") {
    double ec, et, cc, ct;
    if (!argNumber(a, 0, ctx, ec) || !argNumber(a, 1, ctx, et) || !argNumber(a, 2, ctx, cc) || !argNumber(a, 3, ctx, ct))
      return Value(0.0);
    if (ec > et || cc > ct || et <= 0 || ct <= 0 || ec < 0 || cc < 0) {
      ctx.fail("cases must lie between 0 and their totals, and totals must be positive");
      return Value(0.0);
    }
    double rr = (ec / et) / (cc / ct);
    // log-normal confidence interval at 95 %
    double se = std::sqrt(1 / ec - 1 / et + 1 / cc - 1 / ct), z = sf::ndtri(0.975);
    return makeDict({{"relative_risk", Value(rr)},
                     {"low", Value(std::exp(std::log(rr) - z * se))},
                     {"high", Value(std::exp(std::log(rr) + z * se))}});
  } SP_END
}

} // namespace scipy
} // namespace nc
