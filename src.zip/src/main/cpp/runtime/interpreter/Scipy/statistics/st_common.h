// Shared helpers for section 21 (statistics) and section 23 (masked-array
// statistics): reading samples, ranks, moments, simple regressions and a
// one-dimensional minimizer. Pure functions, no NC callbacks.
#ifndef NC_SCIPY_ST_COMMON_H
#define NC_SCIPY_ST_COMMON_H

#include <algorithm>
#include <cmath>
#include <functional>
#include <numeric>
#include <string>
#include <vector>

#include "../probability_distributions/pd_engine.h"
#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace st {

inline double mean(const Vec &x) {
  double s = 0;
  for (double v : x)
    s += v;
  return x.empty() ? kNaN : s / x.size();
}
inline double var(const Vec &x, double ddof = 1) {
  double m = mean(x), s = 0;
  for (double v : x)
    s += (v - m) * (v - m);
  return s / (x.size() - ddof);
}
inline double cmoment(const Vec &x, int k) {
  double m = mean(x), s = 0;
  for (double v : x)
    s += std::pow(v - m, k);
  return s / x.size();
}
inline double skewness(const Vec &x, bool bias = true) {
  double n = x.size(), m2 = cmoment(x, 2), m3 = cmoment(x, 3);
  double g = m2 == 0 ? kNaN : m3 / std::pow(m2, 1.5);
  if (!bias && n > 2)
    g *= std::sqrt(n * (n - 1)) / (n - 2);
  return g;
}
inline double kurtosis(const Vec &x, bool fisher = true, bool bias = true) {
  double n = x.size(), m2 = cmoment(x, 2), m4 = cmoment(x, 4);
  double g = m2 == 0 ? kNaN : m4 / (m2 * m2);
  if (!bias && n > 3)
    g = 1.0 / (n - 2) / (n - 3) * ((n * n - 1.0) * g - 3 * (n - 1) * (n - 1.0)) + 3.0;
  return fisher ? g - 3 : g;
}
inline Vec sorted(Vec x) {
  std::sort(x.begin(), x.end());
  return x;
}
inline double median(Vec x) {
  if (x.empty())
    return kNaN;
  std::sort(x.begin(), x.end());
  size_t n = x.size();
  return n % 2 ? x[n / 2] : 0.5 * (x[n / 2 - 1] + x[n / 2]);
}
// NumPy's default (linear) quantile.
inline double quantile(Vec x, double q) {
  std::sort(x.begin(), x.end());
  double h = (x.size() - 1) * q;
  size_t lo = static_cast<size_t>(std::floor(h));
  size_t hi = std::min(lo + 1, x.size() - 1);
  return x[lo] + (h - lo) * (x[hi] - x[lo]);
}

// Ranks 1..n: "average", "min", "max", "dense", "ordinal".
inline Vec rankdata(const Vec &x, const std::string &method = "average") {
  size_t n = x.size();
  std::vector<size_t> idx(n);
  std::iota(idx.begin(), idx.end(), 0);
  std::stable_sort(idx.begin(), idx.end(), [&](size_t a, size_t b) { return x[a] < x[b]; });
  Vec r(n);
  if (method == "ordinal") {
    for (size_t i = 0; i < n; i++)
      r[idx[i]] = i + 1.0;
    return r;
  }
  size_t i = 0;
  double dense = 0;
  while (i < n) {
    size_t j = i;
    while (j + 1 < n && x[idx[j + 1]] == x[idx[i]])
      j++;
    dense += 1;
    double v = method == "min" ? i + 1.0 : method == "max" ? j + 1.0 : method == "dense" ? dense : 0.5 * (i + j) + 1.0;
    for (size_t k = i; k <= j; k++)
      r[idx[k]] = v;
    i = j + 1;
  }
  return r;
}
// Sizes of the groups of tied values.
inline std::vector<double> tieCounts(const Vec &x) {
  Vec s = sorted(x);
  std::vector<double> t;
  size_t i = 0;
  while (i < s.size()) {
    size_t j = i;
    while (j + 1 < s.size() && s[j + 1] == s[i])
      j++;
    t.push_back(double(j - i + 1));
    i = j + 1;
  }
  return t;
}
inline double tieCorrect(const Vec &ranks) {
  double n = ranks.size();
  if (n < 2)
    return 1.0;
  double s = 0;
  for (double t : tieCounts(ranks))
    s += t * t * t - t;
  return 1.0 - s / (n * n * n - n);
}

inline double pearson(const Vec &x, const Vec &y) {
  double mx = mean(x), my = mean(y), sxy = 0, sxx = 0, syy = 0;
  for (size_t i = 0; i < x.size(); i++) {
    sxy += (x[i] - mx) * (y[i] - my);
    sxx += (x[i] - mx) * (x[i] - mx);
    syy += (y[i] - my) * (y[i] - my);
  }
  double r = sxy / std::sqrt(sxx * syy);
  return std::max(-1.0, std::min(1.0, r));
}
inline void linregress(const Vec &x, const Vec &y, double &slope, double &icpt, double &r) {
  double mx = mean(x), my = mean(y), sxy = 0, sxx = 0;
  for (size_t i = 0; i < x.size(); i++) {
    sxy += (x[i] - mx) * (y[i] - my);
    sxx += (x[i] - mx) * (x[i] - mx);
  }
  slope = sxy / sxx;
  icpt = my - slope * mx;
  r = pearson(x, y);
}

// Two-sided / one-sided p-values from a statistic with symmetric null cdf.
inline double pAlt(double cdfv, double sfv, const std::string &alt) {
  if (alt == "less")
    return cdfv;
  if (alt == "greater")
    return sfv;
  return std::min(1.0, 2 * std::min(cdfv, sfv));
}
inline double normP(double z, const std::string &alt) { return pAlt(sf::ndtr(z), sf::ndtr(-z), alt); }
inline double tP(double t, double df, const std::string &alt) {
  return pAlt(sf::stdtr(df, t), sf::stdtr(df, -t), alt);
}

// Brent's minimization of f on a bracket around [a, b] (golden section + parabolas).
inline double minimize1(const std::function<double(double)> &f, double a, double b, double tol = 1e-10) {
  // expand to a bracket a < c < b with f(c) below both ends
  double fa = f(a), fb = f(b);
  if (fb > fa) {
    std::swap(a, b);
    std::swap(fa, fb);
  }
  double c = b + 1.618034 * (b - a), fc = f(c);
  for (int i = 0; i < 100 && fc < fb; i++) {
    a = b;
    fa = fb;
    b = c;
    fb = fc;
    c = b + 1.618034 * (b - a);
    fc = f(c);
  }
  double lo = std::min(a, c), hi = std::max(a, c);
  const double g = 0.3819660;
  double x = b, w = b, v = b, fx = fb, fw = fb, fv = fb, d = 0, e = 0;
  for (int it = 0; it < 500; it++) {
    double m = 0.5 * (lo + hi), t1 = tol * std::fabs(x) + 1e-12, t2 = 2 * t1;
    if (std::fabs(x - m) <= t2 - 0.5 * (hi - lo))
      break;
    double u;
    if (std::fabs(e) > t1) {
      double r = (x - w) * (fx - fv), q = (x - v) * (fx - fw), p = (x - v) * q - (x - w) * r;
      q = 2 * (q - r);
      if (q > 0)
        p = -p;
      q = std::fabs(q);
      double et = e;
      e = d;
      if (std::fabs(p) >= std::fabs(0.5 * q * et) || p <= q * (lo - x) || p >= q * (hi - x)) {
        e = (x >= m ? lo : hi) - x;
        d = g * e;
      } else {
        d = p / q;
        u = x + d;
        if (u - lo < t2 || hi - u < t2)
          d = (m - x) >= 0 ? t1 : -t1;
      }
    } else {
      e = (x >= m ? lo : hi) - x;
      d = g * e;
    }
    u = x + (std::fabs(d) >= t1 ? d : (d > 0 ? t1 : -t1));
    double fu = f(u);
    if (fu <= fx) {
      if (u >= x)
        lo = x;
      else
        hi = x;
      v = w;
      fv = fw;
      w = x;
      fw = fx;
      x = u;
      fx = fu;
    } else {
      if (u < x)
        lo = u;
      else
        hi = u;
      if (fu <= fw || w == x) {
        v = w;
        fv = fw;
        w = u;
        fw = fu;
      } else if (fu <= fv || v == x || v == w) {
        v = u;
        fv = fu;
      }
    }
  }
  return x;
}

// Filliben's estimate of the uniform order statistic medians.
inline Vec orderStatMedians(size_t n) {
  Vec v(n);
  for (size_t i = 0; i < n; i++)
    v[i] = (i + 1 - 0.3175) / (n + 0.365);
  v[n - 1] = std::pow(0.5, 1.0 / n);
  v[0] = 1 - v[n - 1];
  return v;
}

// Groups given as separate arguments (Arrays) or as one list of Arrays.
bool readGroups(const Args &a, size_t from, CallContext &ctx, std::vector<Vec> &groups, size_t minGroups = 2);
// The elements of an NC list (array or 1xN matrix of values) as Values.
std::vector<Value> listItems(const Value &v);
// The first n points (rows) of the d-dimensional Sobol sequence (d <= 1024),
// as SciPy's unscrambled Sobol; with `shift`, a random digital shift (XOR).
Mat sobolPoints(size_t d, size_t n, std::mt19937_64 *shift);

} // namespace st
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_ST_COMMON_H
