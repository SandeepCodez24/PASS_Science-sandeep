// Section 3 of 25 - Datasets (scipy.datasets): the three sample files, fetched once
// from SciPy's dataset repositories and kept in a cache folder: NC_DATASET_DIR when
// set, otherwise .nc/datasets in the home folder. Each file is checked by its SHA-256.
// The formats are read here without libraries: pickle (only the raw array inside),
// a bzip2 stream, and an .npz archive.
#include "datasets_main.h"

#include <cstdint>
#include <cstdlib>
#include <filesystem>

#include "../../Numpy/importing_data/io_common.h"
#include "../../Numpy/importing_data/io_zip.h"
#include "../scipy_core.h"

#define SP_SEC Section::Datasets

namespace nc {
namespace scipy {

namespace {

namespace fs = std::filesystem;

struct DataFile {
  const char *name, *file, *url, *sha;
};
const DataFile kFiles[] = {
    {"ascent", "ascent.dat", "https://raw.githubusercontent.com/scipy/dataset-ascent/main/ascent.dat", "03ce124c1afc880f87b55f6b061110e2e1e939679184f5614e38dacc6c1957e2"},
    {"ecg", "ecg.dat", "https://raw.githubusercontent.com/scipy/dataset-ecg/main/ecg.dat", "f20ad3365fb9b7f845d0e5c48b6fe67081377ee466c3a220b7f69f35c8958baf"},
    {"face", "face.dat", "https://raw.githubusercontent.com/scipy/dataset-face/main/face.dat", "9d8b0b4d081313e2b485748c770472e5a95ed1738146883d84c7030493e82886"}};

// An environment variable, or "" when it is not set. getenv() is flagged as
// unsafe by the MSVC runtime; _dupenv_s() is its replacement there.
std::string envVar(const char *name) {
#ifdef _MSC_VER
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, name) != 0 || buffer == nullptr)
    return std::string();
  std::string value(buffer);
  std::free(buffer);
  return value;
#else
  const char *value = std::getenv(name);
  return value ? std::string(value) : std::string();
#endif
}

std::string cacheDir() {
  const std::string d = envVar("NC_DATASET_DIR");
  if (!d.empty())
    return d;
  std::string home = envVar("HOME");
  if (home.empty())
    home = envVar("USERPROFILE");
  const fs::path base = !home.empty() ? fs::path(home) : fs::temp_directory_path();
  return (base / ".nc" / "datasets").string();
}

// ---- SHA-256 ----
std::string sha256Hex(const std::string &in) {
  static const uint32_t K[64] = {
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74,
      0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d,
      0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e,
      0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
      0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};
  uint32_t h[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
  std::string m = in;
  const uint64_t bits = (uint64_t)in.size() * 8;
  m.push_back((char)0x80);
  while (m.size() % 64 != 56)
    m.push_back('\0');
  for (int i = 7; i >= 0; i--)
    m.push_back((char)((bits >> (8 * i)) & 0xff));
  auto rr = [](uint32_t x, int n) { return (x >> n) | (x << (32 - n)); };
  uint32_t w[64];
  for (size_t off = 0; off < m.size(); off += 64) {
    for (int t = 0; t < 16; t++) {
      const unsigned char *p = reinterpret_cast<const unsigned char *>(m.data()) + off + 4 * t;
      w[t] = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
    }
    for (int t = 16; t < 64; t++)
      w[t] = w[t - 16] + (rr(w[t - 15], 7) ^ rr(w[t - 15], 18) ^ (w[t - 15] >> 3)) + w[t - 7] + (rr(w[t - 2], 17) ^ rr(w[t - 2], 19) ^ (w[t - 2] >> 10));
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int t = 0; t < 64; t++) {
      const uint32_t t1 = hh + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & f) ^ (~e & g)) + K[t] + w[t];
      const uint32_t t2 = (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
      hh = g;
      g = f;
      f = e;
      e = d + t1;
      d = c;
      c = b;
      b = a;
      a = t1 + t2;
    }
    h[0] += a;
    h[1] += b;
    h[2] += c;
    h[3] += d;
    h[4] += e;
    h[5] += f;
    h[6] += g;
    h[7] += hh;
  }
  static const char *hex = "0123456789abcdef";
  std::string o;
  for (uint32_t v : h)
    for (int i = 28; i >= 0; i -= 4)
      o.push_back(hex[(v >> i) & 0xf]);
  return o;
}

// ---- bzip2 ----
struct BitReader {
  const std::string &s;
  size_t pos = 0;
  uint64_t acc = 0;
  int have = 0;
  bool over = false;
  explicit BitReader(const std::string &in) : s(in) {}
  uint32_t get(int n) {
    while (have < n) {
      if (pos >= s.size()) {
        over = true;
        acc <<= 8;
      } else {
        acc = (acc << 8) | (unsigned char)s[pos++];
      }
      have += 8;
    }
    have -= n;
    return (uint32_t)((acc >> have) & ((1ULL << n) - 1));
  }
  void align() { have -= have % 8; }
};

bool bunzip2(const std::string &in, std::string &out, std::string &err) {
  BitReader br(in);
  bool first = true;
  while (true) {
    if (!first && br.pos >= in.size() && br.have < 8)
      return true;
    if (br.get(8) != 'B' || br.get(8) != 'Z' || br.get(8) != 'h') {
      if (!first)
        return true; // padding after the last stream
      err = "not a bzip2 stream";
      return false;
    }
    first = false;
    const uint32_t level = br.get(8) - '0';
    if (level < 1 || level > 9) {
      err = "bad bzip2 level";
      return false;
    }
    const size_t maxBlock = level * 100000;
    std::vector<uint32_t> tt(maxBlock);
    while (true) {
      const uint64_t magic = ((uint64_t)br.get(24) << 24) | br.get(24);
      br.get(32); // block or stream CRC
      if (magic == 0x177245385090ULL) {
        br.align();
        break;
      }
      if (magic != 0x314159265359ULL) {
        err = "bad bzip2 block";
        return false;
      }
      if (br.get(1)) {
        err = "randomised bzip2 blocks are not supported";
        return false;
      }
      const uint32_t origPtr = br.get(24);
      // Symbols in use.
      unsigned char seq[256];
      int inUse = 0;
      const uint32_t used16 = br.get(16);
      for (int i = 0; i < 16; i++)
        if (used16 & (0x8000u >> i)) {
          const uint32_t bits = br.get(16);
          for (int j = 0; j < 16; j++)
            if (bits & (0x8000u >> j))
              seq[inUse++] = (unsigned char)(i * 16 + j);
        }
      if (inUse == 0) {
        err = "bad bzip2 block";
        return false;
      }
      const int alpha = inUse + 2;
      const int nGroups = (int)br.get(3);
      const int nSel = (int)br.get(15);
      if (nGroups < 2 || nGroups > 6 || nSel < 1) {
        err = "bad bzip2 tables";
        return false;
      }
      std::vector<unsigned char> sel((size_t)nSel);
      unsigned char mtfG[6] = {0, 1, 2, 3, 4, 5};
      for (int i = 0; i < nSel; i++) {
        int j = 0;
        while (br.get(1)) {
          if (++j >= nGroups) {
            err = "bad bzip2 selectors";
            return false;
          }
        }
        const unsigned char v = mtfG[j];
        for (; j > 0; j--)
          mtfG[j] = mtfG[j - 1];
        mtfG[0] = v;
        sel[(size_t)i] = v;
      }
      // Canonical Huffman tables.
      int limit[6][22], base[6][22], perm[6][258], minLen[6];
      for (int t = 0; t < nGroups; t++) {
        unsigned char len[258];
        int cur = (int)br.get(5);
        for (int i = 0; i < alpha; i++) {
          while (true) {
            if (cur < 1 || cur > 20) {
              err = "bad bzip2 code lengths";
              return false;
            }
            if (!br.get(1))
              break;
            cur += br.get(1) ? -1 : 1;
          }
          len[i] = (unsigned char)cur;
        }
        int lo = 32, hi = 0;
        for (int i = 0; i < alpha; i++) {
          lo = std::min<int>(lo, len[i]);
          hi = std::max<int>(hi, len[i]);
        }
        minLen[t] = lo;
        int pp = 0, count[22] = {0};
        for (int l = lo; l <= hi; l++)
          for (int i = 0; i < alpha; i++)
            if (len[i] == l)
              perm[t][pp++] = i;
        for (int i = 0; i < alpha; i++)
          count[len[i]]++;
        int code = 0, idx = 0;
        for (int l = lo; l <= hi; l++) {
          code += count[l];
          limit[t][l] = code - 1; // largest code of this length
          base[t][l] = idx - (code - count[l]);
          idx += count[l];
          code <<= 1;
        }
        limit[t][hi + 1] = 0x7fffffff;
        base[t][hi + 1] = 0;
        for (int l = hi + 2; l < 22; l++) {
          limit[t][l] = 0x7fffffff;
          base[t][l] = 0;
        }
      }
      // Run-length and move-to-front symbols to the last column.
      unsigned char mtf[256];
      for (int i = 0; i < inUse; i++)
        mtf[i] = (unsigned char)i;
      uint32_t freq[256] = {0};
      size_t n = 0;
      int group = 0, left = 0;
      size_t runLen = 0, runBit = 0;
      const int eob = inUse + 1;
      int table = 0;
      while (true) {
        if (left == 0) {
          if (group >= nSel) {
            err = "bad bzip2 data";
            return false;
          }
          table = sel[(size_t)group++];
          left = 50;
        }
        left--;
        int l = minLen[table];
        int code = (int)br.get(l);
        while (code > limit[table][l]) {
          l++;
          if (l > 21) {
            err = "bad bzip2 code";
            return false;
          }
          code = (code << 1) | (int)br.get(1);
        }
        if (br.over) {
          err = "truncated bzip2 data";
          return false;
        }
        const int sym = perm[table][code + base[table][l]];
        if (sym <= 1) {
          runLen += (size_t)(sym + 1) << runBit;
          runBit++;
          continue;
        }
        if (runLen) {
          const unsigned char c = seq[mtf[0]];
          if (n + runLen > maxBlock) {
            err = "bad bzip2 run";
            return false;
          }
          freq[c] += (uint32_t)runLen;
          for (size_t i = 0; i < runLen; i++)
            tt[n++] = c;
          runLen = runBit = 0;
        }
        if (sym == eob)
          break;
        const int at = sym - 1;
        const unsigned char v = mtf[at];
        for (int i = at; i > 0; i--)
          mtf[i] = mtf[i - 1];
        mtf[0] = v;
        if (n >= maxBlock) {
          err = "bad bzip2 block size";
          return false;
        }
        const unsigned char c = seq[v];
        freq[c]++;
        tt[n++] = c;
      }
      if (origPtr >= n && n > 0) {
        err = "bad bzip2 origin";
        return false;
      }
      // Inverse Burrows-Wheeler, then the first run-length layer.
      uint32_t sum = 0, cum[256];
      for (int i = 0; i < 256; i++) {
        cum[i] = sum;
        sum += freq[i];
      }
      for (size_t i = 0; i < n; i++) {
        const unsigned char c = (unsigned char)(tt[i] & 0xff);
        tt[cum[c]++] |= (uint32_t)i << 8;
      }
      if (n) {
        uint32_t p = tt[origPtr] >> 8;
        int runCount = 0, prev = -1;
        for (size_t i = 0; i < n; i++) {
          const uint32_t e = tt[p];
          const unsigned char c = (unsigned char)(e & 0xff);
          p = e >> 8;
          if (runCount == 4) {
            out.append((size_t)c, (char)prev);
            runCount = 0;
            prev = -1;
            continue;
          }
          if ((int)c == prev) {
            runCount++;
          } else {
            prev = c;
            runCount = 1;
          }
          out.push_back((char)c);
        }
      }
    }
    if (br.pos >= in.size())
      return true;
  }
}

// ---- files ----
bool fetchInto(const DataFile &d, const std::string &dir, std::string &bytes, std::string &err) {
  const fs::path path = fs::path(dir) / d.file;
  if (io::fileExists(path.string()) && io::readFile(path.string(), bytes, err) && sha256Hex(bytes) == d.sha)
    return true;
  if (!io::fetchUrl(d.url, bytes, err)) {
    err = std::string("could not download ") + d.file + " (" + err + "); place it in " + dir + " by hand";
    return false;
  }
  if (sha256Hex(bytes) != d.sha) {
    err = std::string("the download of ") + d.file + " has the wrong checksum";
    return false;
  }
  std::error_code ec;
  fs::create_directories(dir, ec);
  std::string werr;
  if (!io::writeFile(path.string(), bytes, false, werr)) {
    // The data is good; only the cache could not be kept.
    err.clear();
  }
  return true;
}

const DataFile *fileNamed(const std::string &name) {
  for (const DataFile &d : kFiles)
    if (name == d.name || name == d.file)
      return &d;
  return nullptr;
}

} // namespace

void registerDatasets(Registry &reg) {
  SP_ADD("dataset_ascent", 0, 0, "") {
    std::string bytes, err;
    if (!fetchInto(*fileNamed("ascent"), cacheDir(), bytes, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    // A pickled uint8 array: the BINBYTES opcode, its 4-byte length, the 512 x 512 values.
    const std::string mark = std::string("B\x00\x00\x04\x00", 5);
    const size_t at = bytes.find(mark);
    if (at == std::string::npos || at + 5 + 262144 > bytes.size()) {
      ctx.fail("ascent.dat does not hold the expected array");
      return Value(0.0);
    }
    Mat m(512, 512);
    for (size_t i = 0; i < m.a.size(); i++)
      m.a[i] = (unsigned char)bytes[at + 5 + i];
    return toValue(m);
  } SP_END
  SP_ADD("dataset_face", 0, 1, "gray=0") {
    std::string bytes, raw, err;
    if (!fetchInto(*fileNamed("face"), cacheDir(), bytes, err) || !bunzip2(bytes, raw, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const size_t R = 768, C = 1024;
    if (raw.size() != R * C * 3) {
      ctx.fail("face.dat does not hold the expected image");
      return Value(0.0);
    }
    auto at = [&](size_t i, size_t j, size_t k) { return (double)(unsigned char)raw[(i * C + j) * 3 + k]; };
    if (optBool(a, 0, false)) {
      Mat g(R, C);
      for (size_t i = 0; i < R; i++)
        for (size_t j = 0; j < C; j++)
          g(i, j) = std::floor(0.21 * at(i, j, 0) + 0.71 * at(i, j, 1) + 0.07 * at(i, j, 2));
      return toValue(g);
    }
    Mat r(R, C), gr(R, C), b(R, C);
    for (size_t i = 0; i < R; i++)
      for (size_t j = 0; j < C; j++) {
        r(i, j) = at(i, j, 0);
        gr(i, j) = at(i, j, 1);
        b(i, j) = at(i, j, 2);
      }
    return makeDict({{"r", toValue(r)}, {"g", toValue(gr)}, {"b", toValue(b)}});
  } SP_END
  SP_ADD("dataset_ecg", 0, 0, "") {
    std::string bytes, npy, err;
    io::ZipReader zip;
    if (!fetchInto(*fileNamed("ecg"), cacheDir(), bytes, err) || !zip.open(bytes, err) || !zip.read("ecg.npy", npy, err)) {
      ctx.fail(err.empty() ? "ecg.dat could not be read" : err);
      return Value(0.0);
    }
    // .npy: magic, version, header length, a text header, then uint16 values.
    if (npy.size() < 10 || npy.compare(0, 6, "\x93NUMPY") != 0) {
      ctx.fail("ecg.dat does not hold a NumPy array");
      return Value(0.0);
    }
    const size_t hl = (unsigned char)npy[8] | ((size_t)(unsigned char)npy[9] << 8), start = 10 + hl;
    Vec v((npy.size() - start) / 2);
    for (size_t i = 0; i < v.size(); i++) {
      const unsigned adc = (unsigned char)npy[start + 2 * i] | ((unsigned)(unsigned char)npy[start + 2 * i + 1] << 8);
      v[i] = ((double)adc - 1024.0) / 200.0;
    }
    return toValue(v);
  } SP_END
  SP_ADD("dataset_download_all", 0, 1, "path") {
    const std::string dir = optText(a, 0, cacheDir());
    for (const DataFile &d : kFiles) {
      std::string bytes, err;
      if (!fetchInto(d, dir, bytes, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
    }
    return Value();
  } SP_END
  SP_ADD("dataset_clear_cache", 0, 1, "names") {
    std::vector<std::string> names;
    if (!a.empty() && !isOmitted(a, 0)) {
      const Value &v = a[0];
      if (v.isText)
        names.push_back(v.text());
      else if (v.isArray)
        for (size_t i = 0; i < v.length(); i++)
          names.push_back(v.at(i).isText ? v.at(i).text() : "");
      else if (v.isMatrix && !v.isND())
        for (size_t r = 0; r < v.rows(); r++)
          for (size_t c = 0; c < v.cols(); c++)
            names.push_back(v.at(r, c).isText ? v.at(r, c).text() : "");
    } else {
      for (const DataFile &d : kFiles)
        names.push_back(d.name);
    }
    const std::string dir = cacheDir();
    for (const std::string &n : names) {
      const DataFile *d = fileNamed(n);
      if (!d) {
        ctx.fail("the datasets are \"ascent\", \"face\" and \"ecg\", not \"" + n + "\"");
        return Value(0.0);
      }
      std::error_code ec;
      fs::remove(fs::path(dir) / d->file, ec);
    }
    return Value();
  } SP_END
}

} // namespace scipy
} // namespace nc
