#include "sa_geom.h"

#include <map>
#include <random>

#include "../linear_algebra/la_core.h"

namespace nc {
namespace scipy {
namespace geom {

namespace {

// Unit vector orthogonal to the d-1 edges from v[0]; false if they are dependent.
bool hyperplane(const Mat &P, const std::vector<size_t> &v, Vec &n) {
  const size_t d = P.c;
  Mat M(d - 1, d);
  for (size_t i = 1; i < d; i++)
    for (size_t j = 0; j < d; j++)
      M(i - 1, j) = P(v[i], j) - P(v[0], j);
  // Row reduction with full pivoting; the free column gives the null vector.
  std::vector<size_t> colOrder(d);
  for (size_t j = 0; j < d; j++)
    colOrder[j] = j;
  double scale = 0.0;
  for (double x : M.a)
    scale = std::max(scale, std::fabs(x));
  for (size_t k = 0; k + 1 < d; k++) {
    size_t pr = k, pc = k;
    double best = 0.0;
    for (size_t i = k; i + 1 < d; i++)
      for (size_t j = k; j < d; j++)
        if (std::fabs(M(i, colOrder[j])) > best) {
          best = std::fabs(M(i, colOrder[j]));
          pr = i;
          pc = j;
        }
    if (best <= 1e-13 * scale)
      return false;
    if (pr != k)
      for (size_t j = 0; j < d; j++)
        std::swap(M(pr, j), M(k, j));
    std::swap(colOrder[k], colOrder[pc]);
    for (size_t i = 0; i + 1 < d; i++) {
      if (i == k)
        continue;
      const double f = M(i, colOrder[k]) / M(k, colOrder[k]);
      if (f != 0.0)
        for (size_t j = 0; j < d; j++)
          M(i, j) -= f * M(k, j);
    }
  }
  n.assign(d, 0.0);
  n[colOrder[d - 1]] = 1.0;
  for (size_t k = 0; k + 1 < d; k++)
    n[colOrder[k]] = -M(k, colOrder[d - 1]) / M(k, colOrder[k]);
  double len = 0.0;
  for (double x : n)
    len += x * x;
  len = std::sqrt(len);
  for (double &x : n)
    x /= len;
  return true;
}

double planeDist(const Facet &f, const double *p, size_t d) {
  double s = f.offset;
  for (size_t i = 0; i < d; i++)
    s += f.normal[i] * p[i];
  return s;
}

bool makeFacet(const Mat &P, std::vector<size_t> v, const Vec &inner, Facet &f) {
  if (!hyperplane(P, v, f.normal))
    return false;
  f.v = std::move(v);
  f.offset = 0.0;
  for (size_t i = 0; i < P.c; i++)
    f.offset -= f.normal[i] * P(f.v[0], i);
  if (planeDist(f, inner.data(), P.c) > 0.0) {
    for (double &x : f.normal)
      x = -x;
    f.offset = -f.offset;
  }
  return true;
}

// d + 1 affinely independent points, chosen greedily for size.
bool initialSimplex(const Mat &P, std::vector<size_t> &out, double scale) {
  const size_t n = P.r, d = P.c;
  out.clear();
  size_t first = 0;
  for (size_t i = 1; i < n; i++)
    if (P(i, 0) < P(first, 0))
      first = i;
  out.push_back(first);
  std::vector<Vec> basis;
  for (size_t k = 0; k < d; k++) {
    double best = 0.0;
    size_t bi = n;
    Vec bv;
    for (size_t i = 0; i < n; i++) {
      Vec e(d);
      for (size_t j = 0; j < d; j++)
        e[j] = P(i, j) - P(first, j);
      for (const Vec &b : basis) {
        double t = 0.0;
        for (size_t j = 0; j < d; j++)
          t += e[j] * b[j];
        for (size_t j = 0; j < d; j++)
          e[j] -= t * b[j];
      }
      double nn = 0.0;
      for (double x : e)
        nn += x * x;
      if (nn > best) {
        best = nn;
        bi = i;
        bv = e;
      }
    }
    if (bi == n || std::sqrt(best) <= 1e-14 * scale)
      return false;
    best = std::sqrt(best);
    for (double &x : bv)
      x /= best;
    basis.push_back(bv);
    out.push_back(bi);
  }
  return true;
}

} // namespace

bool convexHull(const Mat &P, std::vector<Facet> &facets) {
  const size_t n = P.r, d = P.c;
  facets.clear();
  if (d < 2 || n < d + 1)
    return false;
  double scale = 0.0;
  for (size_t j = 0; j < d; j++) {
    double lo = kInf, hi = -kInf;
    for (size_t i = 0; i < n; i++) {
      lo = std::min(lo, P(i, j));
      hi = std::max(hi, P(i, j));
    }
    scale = std::max(scale, hi - lo);
  }
  std::vector<size_t> simplex;
  if (!initialSimplex(P, simplex, scale))
    return false;
  Vec inner(d, 0.0);
  for (size_t s : simplex)
    for (size_t j = 0; j < d; j++)
      inner[j] += P(s, j) / static_cast<double>(d + 1);
  for (size_t omit = 0; omit <= d; omit++) {
    std::vector<size_t> v;
    for (size_t k = 0; k <= d; k++)
      if (k != omit)
        v.push_back(simplex[k]);
    Facet f;
    if (!makeFacet(P, v, inner, f))
      return false;
    facets.push_back(std::move(f));
  }
  std::vector<char> used(n, 0);
  for (size_t s : simplex)
    used[s] = 1;
  const double eps = 1e-12 * scale;
  std::vector<char> visible;
  for (size_t i = 0; i < n; i++) {
    if (used[i])
      continue;
    visible.assign(facets.size(), 0);
    bool any = false;
    for (size_t f = 0; f < facets.size(); f++)
      if (planeDist(facets[f], P.row(i), d) > eps) {
        visible[f] = 1;
        any = true;
      }
    if (!any)
      continue;
    // The horizon: ridges used by exactly one visible facet.
    std::map<std::vector<size_t>, int> ridges;
    for (size_t f = 0; f < facets.size(); f++) {
      if (!visible[f])
        continue;
      for (size_t k = 0; k < d; k++) {
        std::vector<size_t> r;
        for (size_t q = 0; q < d; q++)
          if (q != k)
            r.push_back(facets[f].v[q]);
        std::sort(r.begin(), r.end());
        ridges[r]++;
      }
    }
    std::vector<Facet> next;
    next.reserve(facets.size());
    for (size_t f = 0; f < facets.size(); f++)
      if (!visible[f])
        next.push_back(std::move(facets[f]));
    for (const auto &r : ridges) {
      if (r.second != 1)
        continue;
      std::vector<size_t> v = r.first;
      v.push_back(i);
      Facet f;
      if (makeFacet(P, v, inner, f))
        next.push_back(std::move(f));
    }
    facets = std::move(next);
  }
  return true;
}

std::vector<std::vector<long long>> facetNeighbors(const std::vector<std::vector<size_t>> &simplices, size_t) {
  std::map<std::vector<size_t>, std::pair<long long, size_t>> seen;
  std::vector<std::vector<long long>> nb(simplices.size());
  for (size_t f = 0; f < simplices.size(); f++) {
    const auto &s = simplices[f];
    nb[f].assign(s.size(), -1);
    for (size_t k = 0; k < s.size(); k++) {
      std::vector<size_t> r;
      for (size_t q = 0; q < s.size(); q++)
        if (q != k)
          r.push_back(s[q]);
      std::sort(r.begin(), r.end());
      auto it = seen.find(r);
      if (it == seen.end()) {
        seen.emplace(r, std::make_pair((long long)f, k));
      } else {
        nb[f][k] = it->second.first;
        nb[(size_t)it->second.first][it->second.second] = (long long)f;
      }
    }
  }
  return nb;
}

bool delaunay(const Mat &P, std::vector<std::vector<size_t>> &simplices) {
  const size_t n = P.r, d = P.c;
  simplices.clear();
  if (n < d + 1)
    return false;
  // Centred and scaled, then lifted. A tiny repeatable joggle separates points
  // on a common circle (a grid has many), which would otherwise stay coplanar.
  Vec mean(d, 0.0);
  double scale = 0.0;
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < d; j++)
      mean[j] += P(i, j) / static_cast<double>(n);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < d; j++)
      scale = std::max(scale, std::fabs(P(i, j) - mean[j]));
  if (scale == 0.0)
    return false;
  std::mt19937_64 gen(987654321);
  std::uniform_real_distribution<double> u(-1.0, 1.0);
  Mat L(n, d + 1);
  for (size_t i = 0; i < n; i++) {
    double s = 0.0;
    for (size_t j = 0; j < d; j++) {
      L(i, j) = (P(i, j) - mean[j]) / scale;
      s += L(i, j) * L(i, j);
    }
    L(i, d) = s + 1e-10 * u(gen);
  }
  std::vector<Facet> hull;
  if (!convexHull(L, hull))
    return false;
  // Facets seen from below; flat slivers on the outer edge are dropped.
  for (const Facet &f : hull) {
    if (f.normal[d] >= -1e-9)
      continue;
    Mat E(d, d);
    double norm = 0.0;
    for (size_t i = 1; i <= d; i++)
      for (size_t j = 0; j < d; j++) {
        E(i - 1, j) = L(f.v[i], j) - L(f.v[0], j);
        norm = std::max(norm, std::fabs(E(i - 1, j)));
      }
    double vol = std::fabs(la::det(E));
    if (vol <= 1e-12 * std::pow(norm, static_cast<double>(d)))
      continue;
    simplices.push_back(f.v);
  }
  // A stable order: orientation positive, smallest index first.
  std::sort(simplices.begin(), simplices.end());
  return !simplices.empty();
}

long long findSimplex(const Mat &P, const std::vector<std::vector<size_t>> &simplices, const double *q, Vec *bary) {
  const size_t d = P.c;
  Mat T(d, d);
  for (size_t s = 0; s < simplices.size(); s++) {
    const auto &v = simplices[s];
    for (size_t i = 0; i < d; i++)
      for (size_t j = 0; j < d; j++)
        T(j, i) = P(v[i], j) - P(v[d], j);
    Vec b(d);
    for (size_t j = 0; j < d; j++)
      b[j] = q[j] - P(v[d], j);
    if (!la::solveVec(T, b))
      continue;
    double last = 1.0;
    bool inside = true;
    for (size_t i = 0; i < d; i++) {
      inside = inside && b[i] >= -1e-12;
      last -= b[i];
    }
    if (inside && last >= -1e-12) {
      if (bary) {
        b.push_back(last);
        *bary = b;
      }
      return static_cast<long long>(s);
    }
  }
  return -1;
}

} // namespace geom
} // namespace scipy
} // namespace nc
