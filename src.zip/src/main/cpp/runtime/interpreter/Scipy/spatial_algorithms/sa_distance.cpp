// Distances of scipy.spatial.distance: the dist_* pair functions, pdist and cdist.
#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "spatial_algorithms_main.h"

#define SP_SEC Section::SpatialAlgorithms

namespace nc {
namespace scipy {

namespace {

using Metric = std::function<double(const double *, const double *, size_t)>;

double euclid(const double *u, const double *v, size_t n) {
  double s = 0.0;
  for (size_t i = 0; i < n; i++)
    s += (u[i] - v[i]) * (u[i] - v[i]);
  return std::sqrt(s);
}
double sqeuclid(const double *u, const double *v, size_t n) {
  double s = 0.0;
  for (size_t i = 0; i < n; i++)
    s += (u[i] - v[i]) * (u[i] - v[i]);
  return s;
}
double cityblock(const double *u, const double *v, size_t n) {
  double s = 0.0;
  for (size_t i = 0; i < n; i++)
    s += std::fabs(u[i] - v[i]);
  return s;
}
double chebyshev(const double *u, const double *v, size_t n) {
  double s = 0.0;
  for (size_t i = 0; i < n; i++)
    s = std::max(s, std::fabs(u[i] - v[i]));
  return s;
}
double braycurtis(const double *u, const double *v, size_t n) {
  double a = 0.0, b = 0.0;
  for (size_t i = 0; i < n; i++) {
    a += std::fabs(u[i] - v[i]);
    b += std::fabs(u[i] + v[i]);
  }
  return a / b;
}
double canberra(const double *u, const double *v, size_t n) {
  double s = 0.0;
  for (size_t i = 0; i < n; i++) {
    const double d = std::fabs(u[i]) + std::fabs(v[i]);
    if (d != 0.0)
      s += std::fabs(u[i] - v[i]) / d;
  }
  return s;
}
double cosineDist(const double *u, const double *v, size_t n) {
  double uv = 0.0, uu = 0.0, vv = 0.0;
  for (size_t i = 0; i < n; i++) {
    uv += u[i] * v[i];
    uu += u[i] * u[i];
    vv += v[i] * v[i];
  }
  return 1.0 - uv / std::sqrt(uu * vv);
}
double correlationDist(const double *u, const double *v, size_t n) {
  double mu = 0.0, mv = 0.0;
  for (size_t i = 0; i < n; i++) {
    mu += u[i];
    mv += v[i];
  }
  mu /= (double)n;
  mv /= (double)n;
  double uv = 0.0, uu = 0.0, vv = 0.0;
  for (size_t i = 0; i < n; i++) {
    uv += (u[i] - mu) * (v[i] - mv);
    uu += (u[i] - mu) * (u[i] - mu);
    vv += (v[i] - mv) * (v[i] - mv);
  }
  return 1.0 - uv / std::sqrt(uu * vv);
}
double hammingDist(const double *u, const double *v, size_t n) {
  double s = 0.0;
  for (size_t i = 0; i < n; i++)
    s += u[i] != v[i];
  return s / (double)n;
}
// The counts of a pair of 0/1 vectors.
struct Tally {
  double tt = 0, tf = 0, ft = 0, ff = 0;
  Tally(const double *u, const double *v, size_t n) {
    for (size_t i = 0; i < n; i++) {
      const bool a = u[i] != 0.0, b = v[i] != 0.0;
      if (a && b) tt++;
      else if (a) tf++;
      else if (b) ft++;
      else ff++;
    }
  }
};
double jaccard(const double *u, const double *v, size_t n) {
  Tally t(u, v, n);
  const double d = t.tt + t.tf + t.ft;
  return d == 0.0 ? 0.0 : (t.tf + t.ft) / d;
}
double dice(const double *u, const double *v, size_t n) {
  Tally t(u, v, n);
  const double d = 2.0 * t.tt + t.tf + t.ft;
  return d == 0.0 ? 0.0 : (t.tf + t.ft) / d;
}
double rogerstanimoto(const double *u, const double *v, size_t n) {
  Tally t(u, v, n);
  const double R = 2.0 * (t.tf + t.ft);
  return R / (t.tt + t.ff + R);
}
double russellrao(const double *u, const double *v, size_t n) {
  Tally t(u, v, n);
  return ((double)n - t.tt) / (double)n;
}
double sokalsneath(const double *u, const double *v, size_t n) {
  Tally t(u, v, n);
  const double R = 2.0 * (t.tf + t.ft);
  const double d = t.tt + R;
  return d == 0.0 ? kNaN : R / d;
}
double yule(const double *u, const double *v, size_t n) {
  Tally t(u, v, n);
  const double half = t.tf * t.ft;
  if (half == 0.0)
    return 0.0;
  return 2.0 * half / (t.tt * t.ff + half);
}

bool metricByName(const std::string &m, const Vec &param, Metric &out, std::string &err) {
  if (m == "euclidean") out = euclid;
  else if (m == "sqeuclidean") out = sqeuclid;
  else if (m == "cityblock") out = cityblock;
  else if (m == "chebyshev") out = chebyshev;
  else if (m == "braycurtis") out = braycurtis;
  else if (m == "canberra") out = canberra;
  else if (m == "cosine") out = cosineDist;
  else if (m == "correlation") out = correlationDist;
  else if (m == "hamming") out = hammingDist;
  else if (m == "jaccard") out = jaccard;
  else if (m == "dice") out = dice;
  else if (m == "rogerstanimoto") out = rogerstanimoto;
  else if (m == "russellrao") out = russellrao;
  else if (m == "sokalsneath") out = sokalsneath;
  else if (m == "yule") out = yule;
  else if (m == "minkowski") {
    const double p = param.empty() ? 2.0 : param[0];
    out = [p](const double *u, const double *v, size_t n) {
      double s = 0.0;
      for (size_t i = 0; i < n; i++)
        s += std::pow(std::fabs(u[i] - v[i]), p);
      return std::pow(s, 1.0 / p);
    };
  } else {
    err = "unknown metric \"" + m + "\"";
    return false;
  }
  return true;
}

constexpr par::Cost kPairCost{par::Kind::Compute, 40.0};

// u, v of equal length.
bool pairArgs(const Args &a, CallContext &ctx, Vec &u, Vec &v) {
  if (!getVec(a, 0, ctx, u) || !getVec(a, 1, ctx, v))
    return false;
  if (u.size() != v.size()) {
    ctx.fail("the two vectors must have the same length");
    return false;
  }
  return true;
}

} // namespace

#define NC_DIST(NAME, FN)                                                                          \
  SP_ADD(NAME, 2, 2, "u, v") {                                                                     \
    Vec u, v;                                                                                      \
    if (!pairArgs(a, ctx, u, v))                                                                   \
      return Value(0.0);                                                                           \
    return Value(FN(u.data(), v.data(), u.size()));                                                \
  } SP_END

void registerSpatialDistances(Registry &reg) {
  SP_ADD("cdist", 2, 3, "A, B, metric=\"euclidean\"") {
    Mat A, B;
    if (!getMat(a, 0, ctx, A) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.c != B.c) {
      ctx.fail("A and B must have the same number of columns");
      return Value(0.0);
    }
    Metric m;
    std::string err;
    if (!metricByName(optText(a, 2, "euclidean"), {}, m, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Mat D(A.r, B.r);
    par::forBlocks(A.r, kPairCost, [&](size_t b, size_t e) {
      for (size_t i = b; i < e; i++)
        for (size_t j = 0; j < B.r; j++)
          D(i, j) = m(A.row(i), B.row(j), A.c);
    });
    return toValue(D);
  } SP_END
  SP_ADD("pdist", 1, 2, "points, metric=\"euclidean\"") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    Metric m;
    std::string err;
    if (!metricByName(optText(a, 1, "euclidean"), {}, m, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const size_t n = P.r;
    Vec d(n * (n ? n - 1 : 0) / 2);
    par::forBlocks(n, kPairCost, [&](size_t b, size_t e) {
      for (size_t i = b; i < e; i++) {
        size_t k = i * n - i * (i + 1) / 2; // first slot of row i
        for (size_t j = i + 1; j < n; j++)
          d[k++] = m(P.row(i), P.row(j), P.c);
      }
    });
    return toValue(d);
  } SP_END
  SP_ADD("squareform", 1, 1, "d") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    if (m.r == 1 || m.c == 1) {
      const size_t c = m.a.size();
      const size_t n = (size_t)std::llround((1.0 + std::sqrt(1.0 + 8.0 * (double)c)) / 2.0);
      if (n * (n - 1) / 2 != c) {
        ctx.fail("a condensed distance list has n*(n-1)/2 values");
        return Value(0.0);
      }
      Mat D(n, n);
      size_t k = 0;
      for (size_t i = 0; i < n; i++)
        for (size_t j = i + 1; j < n; j++)
          D(i, j) = D(j, i) = m.a[k++];
      return toValue(D);
    }
    if (m.r != m.c) {
      ctx.fail("the argument must be a condensed list or a square matrix");
      return Value(0.0);
    }
    Vec d;
    for (size_t i = 0; i < m.r; i++)
      for (size_t j = i + 1; j < m.r; j++)
        d.push_back(m(i, j));
    return toValue(d);
  } SP_END
  SP_ADD("directed_hausdorff", 2, 2, "A, B") {
    Mat A, B;
    if (!getMat(a, 0, ctx, A) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.c != B.c) {
      ctx.fail("A and B must have the same number of columns");
      return Value(0.0);
    }
    double best = -1.0;
    size_t bi = 0, bj = 0;
    for (size_t i = 0; i < A.r; i++) {
      double nearest = kInf;
      size_t nj = 0;
      for (size_t j = 0; j < B.r; j++) {
        const double d = sqeuclid(A.row(i), B.row(j), A.c);
        if (d < nearest) {
          nearest = d;
          nj = j;
        }
      }
      if (nearest > best) {
        best = nearest;
        bi = i;
        bj = nj;
      }
    }
    return makeDict({{"dist", Value(std::sqrt(best))}, {"i", Value((double)bi)}, {"j", Value((double)bj)}});
  } SP_END
  SP_ADD("is_valid_dm", 1, 2, "D, tol=0") {
    Mat D;
    if (!readMat(a[0], D) || D.r != D.c)
      return Value::boolean(false);
    const double tol = optNum(a, 1, 0.0);
    for (size_t i = 0; i < D.r; i++) {
      if (D(i, i) != 0.0)
        return Value::boolean(false);
      for (size_t j = 0; j < D.c; j++)
        if (D(i, j) < 0.0 || std::fabs(D(i, j) - D(j, i)) > tol)
          return Value::boolean(false);
    }
    return Value::boolean(true);
  } SP_END
  SP_ADD("is_valid_condensed", 1, 1, "d") {
    Vec d;
    if (!readVec(a[0], d))
      return Value::boolean(false);
    const size_t n = (size_t)std::llround((1.0 + std::sqrt(1.0 + 8.0 * (double)d.size())) / 2.0);
    if (n * (n - 1) / 2 != d.size())
      return Value::boolean(false);
    for (double v : d)
      if (v < 0.0)
        return Value::boolean(false);
    return Value::boolean(true);
  } SP_END
  SP_ADD("dm_count", 1, 1, "D") {
    Mat D;
    if (!getMat(a, 0, ctx, D))
      return Value(0.0);
    if (D.r != D.c) {
      ctx.fail("the distance matrix must be square");
      return Value(0.0);
    }
    return Value((double)D.r);
  } SP_END
  SP_ADD("condensed_count", 1, 1, "d") {
    Vec d;
    if (!getVec(a, 0, ctx, d))
      return Value(0.0);
    const size_t n = (size_t)std::llround((1.0 + std::sqrt(1.0 + 8.0 * (double)d.size())) / 2.0);
    if (n * (n - 1) / 2 != d.size()) {
      ctx.fail("a condensed distance list has n*(n-1)/2 values");
      return Value(0.0);
    }
    return Value((double)n);
  } SP_END
  NC_DIST("dist_braycurtis", braycurtis)
  NC_DIST("dist_canberra", canberra)
  NC_DIST("dist_chebyshev", chebyshev)
  NC_DIST("dist_cityblock", cityblock)
  NC_DIST("dist_correlation", correlationDist)
  NC_DIST("dist_cosine", cosineDist)
  NC_DIST("dist_sqeuclidean", sqeuclid)
  NC_DIST("dist_dice", dice)
  NC_DIST("dist_hamming", hammingDist)
  NC_DIST("dist_jaccard", jaccard)
  NC_DIST("dist_rogerstanimoto", rogerstanimoto)
  NC_DIST("dist_russellrao", russellrao)
  NC_DIST("dist_sokalsneath", sokalsneath)
  NC_DIST("dist_yule", yule)
  SP_ADD("dist_jensenshannon", 2, 3, "p, q, base") {
    Vec p, q;
    if (!pairArgs(a, ctx, p, q))
      return Value(0.0);
    double sp_ = 0.0, sq = 0.0;
    for (size_t i = 0; i < p.size(); i++) {
      sp_ += p[i];
      sq += q[i];
    }
    double js = 0.0;
    for (size_t i = 0; i < p.size(); i++) {
      const double pi = p[i] / sp_, qi = q[i] / sq, m = 0.5 * (pi + qi);
      if (pi > 0.0)
        js += 0.5 * pi * std::log(pi / m);
      if (qi > 0.0)
        js += 0.5 * qi * std::log(qi / m);
    }
    if (isNumberArg(a, 2))
      js /= std::log(a[2].number);
    return Value(std::sqrt(std::max(0.0, js)));
  } SP_END
  SP_ADD("dist_mahalanobis", 3, 3, "u, v, VI") {
    Vec u, v;
    Mat VI;
    if (!pairArgs(a, ctx, u, v) || !getSquare(a, 2, ctx, VI))
      return Value(0.0);
    if (VI.r != u.size()) {
      ctx.fail("VI must have one row per value of u");
      return Value(0.0);
    }
    double s = 0.0;
    for (size_t i = 0; i < u.size(); i++)
      for (size_t j = 0; j < u.size(); j++)
        s += (u[i] - v[i]) * VI(i, j) * (u[j] - v[j]);
    return Value(std::sqrt(s));
  } SP_END
  SP_ADD("dist_minkowski", 2, 3, "u, v, p=2") {
    Vec u, v;
    if (!pairArgs(a, ctx, u, v))
      return Value(0.0);
    const double p = optNum(a, 2, 2.0);
    if (p <= 0.0) {
      ctx.fail("p must be above 0");
      return Value(0.0);
    }
    if (std::isinf(p))
      return Value(chebyshev(u.data(), v.data(), u.size()));
    double s = 0.0;
    for (size_t i = 0; i < u.size(); i++)
      s += std::pow(std::fabs(u[i] - v[i]), p);
    return Value(std::pow(s, 1.0 / p));
  } SP_END
  SP_ADD("dist_minkowski_p", 2, 3, "u, v, p=2") {
    Vec u, v;
    if (!pairArgs(a, ctx, u, v))
      return Value(0.0);
    const double p = optNum(a, 2, 2.0);
    double s = 0.0;
    for (size_t i = 0; i < u.size(); i++)
      s += std::pow(std::fabs(u[i] - v[i]), p);
    return Value(s);
  } SP_END
  SP_ADD("dist_seuclidean", 3, 3, "u, v, V") {
    Vec u, v, V;
    if (!pairArgs(a, ctx, u, v) || !getVec(a, 2, ctx, V))
      return Value(0.0);
    if (V.size() != u.size()) {
      ctx.fail("V must have one value per value of u");
      return Value(0.0);
    }
    double s = 0.0;
    for (size_t i = 0; i < u.size(); i++)
      s += (u[i] - v[i]) * (u[i] - v[i]) / V[i];
    return Value(std::sqrt(s));
  } SP_END
  SP_ADD("procrustes_fit", 2, 2, "A, B") {
    Mat A, B;
    if (!getMat(a, 0, ctx, A) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r || A.c != B.c || A.r < 2) {
      ctx.fail("A and B must have the same shape and at least two rows");
      return Value(0.0);
    }
    auto standardize = [](Mat &M) {
      for (size_t j = 0; j < M.c; j++) {
        double m = 0.0;
        for (size_t i = 0; i < M.r; i++)
          m += M(i, j);
        m /= (double)M.r;
        for (size_t i = 0; i < M.r; i++)
          M(i, j) -= m;
      }
      const double n = la::frobenius(M);
      for (double &v : M.a)
        v /= n;
      return n;
    };
    if (standardize(A) == 0.0 || standardize(B) == 0.0) {
      ctx.fail("the inputs must not be constant");
      return Value(0.0);
    }
    Mat U, V;
    Vec s;
    la::svdThin(mul(transposeOf(B), A), U, s, V);
    Mat R = mul(U, transposeOf(V));
    double scale = 0.0;
    for (double x : s)
      scale += x;
    Mat B2 = mul(B, R);
    for (double &v : B2.a)
      v *= scale;
    double disp = 0.0;
    for (size_t i = 0; i < A.a.size(); i++)
      disp += (A.a[i] - B2.a[i]) * (A.a[i] - B2.a[i]);
    return makeDict({{"mtx1", toValue(A)}, {"mtx2", toValue(B2)}, {"disparity", Value(disp)}});
  } SP_END
  SP_ADD("slerp", 3, 3, "start, end, t") {
    Vec s, e, t;
    if (!pairArgs(a, ctx, s, e) || !getVec(a, 2, ctx, t))
      return Value(0.0);
    double dot = 0.0, ns = 0.0, ne = 0.0;
    for (size_t i = 0; i < s.size(); i++) {
      dot += s[i] * e[i];
      ns += s[i] * s[i];
      ne += e[i] * e[i];
    }
    if (std::fabs(ns - 1.0) > 1e-8 || std::fabs(ne - 1.0) > 1e-8) {
      ctx.fail("start and end must be unit vectors");
      return Value(0.0);
    }
    const double om = std::acos(std::min(1.0, std::max(-1.0, dot)));
    Mat R(t.size(), s.size());
    for (size_t k = 0; k < t.size(); k++)
      for (size_t i = 0; i < s.size(); i++)
        R(k, i) = om < 1e-12 ? s[i] : (std::sin((1.0 - t[k]) * om) * s[i] + std::sin(t[k] * om) * e[i]) / std::sin(om);
    return toValue(R);
  } SP_END
  reg.setParallel({"cdist", "pdist"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
