// 3-D rotations and rigid transforms (scipy.spatial.transform). A rotation Dict
// holds quat, an n x 4 matrix of [x, y, z, w] rows.
#include <array>
#include <random>

#include "../../ops/matrix/matrix.h"
#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "spatial_algorithms_main.h"

#define SP_SEC Section::SpatialAlgorithms

namespace nc {
namespace scipy {

namespace {

struct Quat {
  double x = 0, y = 0, z = 0, w = 1;
};
Quat qmul(const Quat &p, const Quat &q) {
  return {p.w * q.x + p.x * q.w + p.y * q.z - p.z * q.y, p.w * q.y - p.x * q.z + p.y * q.w + p.z * q.x,
          p.w * q.z + p.x * q.y - p.y * q.x + p.z * q.w, p.w * q.w - p.x * q.x - p.y * q.y - p.z * q.z};
}
Quat qconj(const Quat &q) { return {-q.x, -q.y, -q.z, q.w}; }
void qnorm(Quat &q) {
  const double n = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w);
  q.x /= n;
  q.y /= n;
  q.z /= n;
  q.w /= n;
}
Quat fromRotvec(const double *r) {
  const double th = std::sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]);
  const double s = th < 1e-6 ? 0.5 - th * th / 48.0 : std::sin(th / 2.0) / th;
  return {r[0] * s, r[1] * s, r[2] * s, std::cos(th / 2.0)};
}
void toRotvec(const Quat &qi, double *r) {
  Quat q = qi;
  if (q.w < 0) {
    q = {-q.x, -q.y, -q.z, -q.w};
  }
  const double nv = std::sqrt(q.x * q.x + q.y * q.y + q.z * q.z);
  const double th = 2.0 * std::atan2(nv, q.w);
  const double s = th < 1e-6 ? 2.0 + th * th / 12.0 : th / std::sin(th / 2.0);
  r[0] = q.x * s;
  r[1] = q.y * s;
  r[2] = q.z * s;
}
void rotate(const Quat &q, const double *v, double *o) {
  const double tx = 2.0 * (q.y * v[2] - q.z * v[1]), ty = 2.0 * (q.z * v[0] - q.x * v[2]), tz = 2.0 * (q.x * v[1] - q.y * v[0]);
  o[0] = v[0] + q.w * tx + q.y * tz - q.z * ty;
  o[1] = v[1] + q.w * ty + q.z * tx - q.x * tz;
  o[2] = v[2] + q.w * tz + q.x * ty - q.y * tx;
}
void toMatrix(const Quat &q, double m[3][3]) {
  m[0][0] = 1 - 2 * (q.y * q.y + q.z * q.z);
  m[0][1] = 2 * (q.x * q.y - q.z * q.w);
  m[0][2] = 2 * (q.x * q.z + q.y * q.w);
  m[1][0] = 2 * (q.x * q.y + q.z * q.w);
  m[1][1] = 1 - 2 * (q.x * q.x + q.z * q.z);
  m[1][2] = 2 * (q.y * q.z - q.x * q.w);
  m[2][0] = 2 * (q.x * q.z - q.y * q.w);
  m[2][1] = 2 * (q.y * q.z + q.x * q.w);
  m[2][2] = 1 - 2 * (q.x * q.x + q.y * q.y);
}

Value rotValue(const std::vector<Quat> &q, bool single) {
  Mat M(q.size(), 4);
  for (size_t i = 0; i < q.size(); i++) {
    M(i, 0) = q[i].x;
    M(i, 1) = q[i].y;
    M(i, 2) = q[i].z;
    M(i, 3) = q[i].w;
  }
  return makeDict({{"quat", toValue(M)}, {"single", Value::boolean(single)}});
}
bool readRot(const Value &v, std::vector<Quat> &q, bool *single = nullptr) {
  const Value *qv = dictGet(v, "quat"), *sv = dictGet(v, "single");
  Mat M;
  if (!qv || !readMat(*qv, M) || M.c != 4)
    return false;
  q.resize(M.r);
  for (size_t i = 0; i < M.r; i++)
    q[i] = {M(i, 0), M(i, 1), M(i, 2), M(i, 3)};
  if (single)
    *single = sv && sv->number != 0.0;
  return true;
}

// Euler angles, the axis letters as in SciPy: lower case extrinsic, upper case intrinsic.
bool axisOf(char c, int &k) {
  switch (std::tolower(static_cast<unsigned char>(c))) {
  case 'x': k = 0; return true;
  case 'y': k = 1; return true;
  case 'z': k = 2; return true;
  default: return false;
  }
}

// The angles of a rotation by Shuster's method for any valid three-axis sequence.
bool asEuler(const Quat &qi, const std::string &seqIn, Vec &ang) {
  const bool intrinsic = std::isupper(static_cast<unsigned char>(seqIn[0]));
  std::string s = seqIn;
  if (intrinsic)
    std::reverse(s.begin(), s.end());
  int i, j, k;
  if (!axisOf(s[0], i) || !axisOf(s[1], j) || !axisOf(s[2], k) || i == j || j == k)
    return false;
  const bool symmetric = i == k;
  if (symmetric)
    k = 3 - i - j;
  const double sign = ((i - j) * (j - k) * (k - i)) / 2;
  const double q[4] = {qi.x, qi.y, qi.z, qi.w};
  double a0, b0, c0, d0;
  if (symmetric) {
    a0 = q[3];
    b0 = q[i];
    c0 = q[j];
    d0 = q[k] * sign;
  } else {
    a0 = q[3] - q[j];
    b0 = q[i] + q[k] * sign;
    c0 = q[j] + q[3];
    d0 = q[k] * sign - q[i];
  }
  ang.assign(3, 0.0);
  const size_t first = intrinsic ? 2 : 0, third = intrinsic ? 0 : 2;
  ang[1] = 2.0 * std::atan2(std::hypot(c0, d0), std::hypot(a0, b0));
  const bool case1 = std::fabs(ang[1]) <= 1e-7, case2 = std::fabs(ang[1] - kPi) <= 1e-7;
  const double half_sum = std::atan2(b0, a0), half_diff = std::atan2(d0, c0);
  if (!case1 && !case2) {
    ang[first] = half_sum - half_diff;
    ang[third] = half_sum + half_diff;
  } else {
    // Gimbal lock: the third angle is set to zero.
    ang[2] = 0.0;
    ang[0] = case1 ? 2.0 * half_sum : 2.0 * half_diff * (intrinsic ? 1.0 : -1.0);
  }
  if (!symmetric) {
    ang[third] *= sign;
    ang[1] -= kPi / 2.0;
  }
  for (double &v : ang) {
    if (v < -kPi)
      v += 2.0 * kPi;
    else if (v > kPi)
      v -= 2.0 * kPi;
  }
  return true;
}

Quat axisQuat(int k, double angle) {
  Quat q;
  q.w = std::cos(angle / 2.0);
  const double s = std::sin(angle / 2.0);
  if (k == 0) q.x = s;
  if (k == 1) q.y = s;
  if (k == 2) q.z = s;
  return q;
}

// Index of the key interval holding t.
size_t intervalOf(const Vec &times, double t) {
  size_t i = 0;
  while (i + 2 < times.size() && t >= times[i + 1])
    i++;
  return i;
}

} // namespace

void registerSpatialRotations(Registry &reg) {
  SP_ADD("rot_identity", 0, 1, "n") {
    (void)ctx;
    const long long n = optInt(a, 0, 1);
    return rotValue(std::vector<Quat>((size_t)n), a.empty());
  } SP_END
  SP_ADD("rot_from_euler", 2, 3, "axes, angles, degrees=0") {
    std::string seq;
    Mat ang;
    if (!argText(a, 0, ctx, seq) || !getMat(a, 1, ctx, ang))
      return Value(0.0);
    if (seq.empty() || seq.size() > 3) {
      ctx.fail("axes must name one to three axes, e.g. \"z\" or \"xyz\"");
      return Value(0.0);
    }
    const double f = optBool(a, 2, false) ? kPi / 180.0 : 1.0;
    const bool intrinsic = std::isupper(static_cast<unsigned char>(seq[0]));
    const size_t naxes = seq.size();
    // One axis: an Array holds one angle per rotation. Otherwise one row per rotation.
    size_t rows = naxes == 1 ? ang.a.size() : ang.r;
    if (naxes > 1 && ang.c != naxes) {
      ctx.fail("give one angle per axis");
      return Value(0.0);
    }
    std::vector<Quat> out(rows);
    for (size_t r = 0; r < rows; r++) {
      Quat q;
      for (size_t k = 0; k < naxes; k++) {
        int ax;
        if (!axisOf(seq[k], ax)) {
          ctx.fail("axes may only use x, y and z");
          return Value(0.0);
        }
        const double v = naxes == 1 ? ang.a[r] : ang(r, k);
        Quat e = axisQuat(ax, v * f);
        q = intrinsic ? qmul(q, e) : qmul(e, q);
      }
      qnorm(q);
      out[r] = q;
    }
    return rotValue(out, isPlainNumber(a[1]) || (naxes > 1 && ang.r == 1));
  } SP_END
  SP_ADD("rot_apply", 2, 2, "r, vectors") {
    std::vector<Quat> q;
    Mat V;
    if (!readRot(a[0], q)) {
      ctx.fail("the first argument must be a rotation");
      return Value(0.0);
    }
    if (!getMat(a, 1, ctx, V))
      return Value(0.0);
    if (V.c != 3) {
      ctx.fail("the vectors must have three columns");
      return Value(0.0);
    }
    const size_t n = std::max(q.size(), V.r);
    if ((q.size() != 1 && V.r != 1 && q.size() != V.r)) {
      ctx.fail("give one rotation per vector, or one of either");
      return Value(0.0);
    }
    Mat O(n, 3);
    for (size_t i = 0; i < n; i++)
      rotate(q[q.size() == 1 ? 0 : i], V.row(V.r == 1 ? 0 : i), O.row(i));
    if (n == 1)
      return toValue(O.a);
    return toValue(O);
  } SP_END
  SP_ADD("rot_from_quat", 1, 1, "quat") {
    Mat M;
    if (!getMat(a, 0, ctx, M))
      return Value(0.0);
    if (M.c != 4) {
      ctx.fail("a quaternion is [x, y, z, w]");
      return Value(0.0);
    }
    std::vector<Quat> q(M.r);
    for (size_t i = 0; i < M.r; i++) {
      q[i] = {M(i, 0), M(i, 1), M(i, 2), M(i, 3)};
      if (q[i].x == 0 && q[i].y == 0 && q[i].z == 0 && q[i].w == 0) {
        ctx.fail("a quaternion must not be all zero");
        return Value(0.0);
      }
      qnorm(q[i]);
    }
    return rotValue(q, M.r == 1);
  } SP_END
  SP_ADD("rot_as_matrix", 1, 1, "r") {
    std::vector<Quat> q;
    if (!readRot(a[0], q)) {
      ctx.fail("the argument must be a rotation");
      return Value(0.0);
    }
    if (q.size() != 1) {
      ctx.fail("this holds several rotations; rot_as_matrix takes one at a time");
      return Value(0.0);
    }
    double m[3][3];
    toMatrix(q[0], m);
    Mat M(3, 3);
    for (int i = 0; i < 3; i++)
      for (int j = 0; j < 3; j++)
        M(i, j) = m[i][j];
    return toValue(M);
  } SP_END
  SP_ADD("rot_from_rotvec", 1, 2, "rotvec, degrees=0") {
    Mat M;
    if (!getMat(a, 0, ctx, M))
      return Value(0.0);
    if (M.c != 3) {
      ctx.fail("a rotation vector has three values");
      return Value(0.0);
    }
    const double f = optBool(a, 1, false) ? kPi / 180.0 : 1.0;
    std::vector<Quat> q(M.r);
    for (size_t i = 0; i < M.r; i++) {
      double r[3] = {M(i, 0) * f, M(i, 1) * f, M(i, 2) * f};
      q[i] = fromRotvec(r);
    }
    return rotValue(q, M.r == 1);
  } SP_END
  SP_ADD("rot_as_euler", 2, 3, "r, axes, degrees=0") {
    std::vector<Quat> q;
    std::string seq;
    if (!readRot(a[0], q)) {
      ctx.fail("the first argument must be a rotation");
      return Value(0.0);
    }
    if (!argText(a, 1, ctx, seq))
      return Value(0.0);
    if (seq.size() != 3) {
      ctx.fail("axes must name three axes, e.g. \"xyz\"");
      return Value(0.0);
    }
    const double f = optBool(a, 2, false) ? 180.0 / kPi : 1.0;
    Mat O(q.size(), 3);
    for (size_t i = 0; i < q.size(); i++) {
      Vec ang;
      if (!asEuler(q[i], seq, ang)) {
        ctx.fail("not a valid axis sequence: \"" + seq + "\"");
        return Value(0.0);
      }
      for (size_t k = 0; k < 3; k++)
        O(i, k) = ang[k] * f;
    }
    return q.size() == 1 ? toValue(O.a) : toValue(O);
  } SP_END
  SP_ADD("rot_random", 0, 2, "n, seed") {
    (void)ctx;
    const long long n = isNumberArg(a, 0) && a[0].number > 0 ? (long long)a[0].number : 1;
    std::mt19937_64 gen = isNumberArg(a, 1) ? std::mt19937_64((unsigned long long)a[1].number) : std::mt19937_64(ncRandomEngine()());
    std::normal_distribution<double> nd;
    std::vector<Quat> q((size_t)n);
    for (Quat &p : q) {
      p = {nd(gen), nd(gen), nd(gen), nd(gen)};
      qnorm(p);
    }
    return rotValue(q, a.empty());
  } SP_END
  SP_ADD("rot_slerp", 3, 3, "times, rotations, t") {
    Vec times, t;
    std::vector<Quat> q;
    if (!getVec(a, 0, ctx, times) || !getVec(a, 2, ctx, t))
      return Value(0.0);
    if (!readRot(a[1], q) || q.size() != times.size() || q.size() < 2) {
      ctx.fail("rotations must hold one rotation per time, and at least two");
      return Value(0.0);
    }
    std::vector<Quat> out(t.size());
    for (size_t k = 0; k < t.size(); k++) {
      if (t[k] < times.front() || t[k] > times.back()) {
        ctx.fail("the query times must lie within the key times");
        return Value(0.0);
      }
      const size_t i = intervalOf(times, t[k]);
      const double s = (t[k] - times[i]) / (times[i + 1] - times[i]);
      double r[3];
      toRotvec(qmul(q[i + 1], qconj(q[i])), r);
      for (double &c : r)
        c *= s;
      out[k] = qmul(fromRotvec(r), q[i]);
      qnorm(out[k]);
    }
    return rotValue(out, false);
  } SP_END
  // Cubic in each interval's rotation vector, with end rates from the neighbours:
  // passes through the keys, continuous in rate.
  SP_ADD("rot_spline", 3, 3, "times, rotations, t") {
    Vec times, t;
    std::vector<Quat> q;
    if (!getVec(a, 0, ctx, times) || !getVec(a, 2, ctx, t))
      return Value(0.0);
    if (!readRot(a[1], q) || q.size() != times.size() || q.size() < 2) {
      ctx.fail("rotations must hold one rotation per time, and at least two");
      return Value(0.0);
    }
    const size_t n = times.size();
    std::vector<std::array<double, 3>> incr(n - 1), rate(n);
    for (size_t i = 0; i + 1 < n; i++) {
      double r[3];
      toRotvec(qmul(q[i + 1], qconj(q[i])), r);
      for (int c = 0; c < 3; c++)
        incr[i][c] = r[c];
    }
    for (size_t i = 0; i < n; i++)
      for (int c = 0; c < 3; c++) {
        if (i == 0)
          rate[i][c] = incr[0][c] / (times[1] - times[0]);
        else if (i + 1 == n)
          rate[i][c] = incr[n - 2][c] / (times[n - 1] - times[n - 2]);
        else
          rate[i][c] = 0.5 * (incr[i - 1][c] / (times[i] - times[i - 1]) + incr[i][c] / (times[i + 1] - times[i]));
      }
    std::vector<Quat> out(t.size());
    for (size_t k = 0; k < t.size(); k++) {
      if (t[k] < times.front() || t[k] > times.back()) {
        ctx.fail("the query times must lie within the key times");
        return Value(0.0);
      }
      const size_t i = intervalOf(times, t[k]);
      const double h = times[i + 1] - times[i], s = (t[k] - times[i]) / h;
      double r[3];
      for (int c = 0; c < 3; c++) {
        const double d0 = rate[i][c] * h, d1 = rate[i + 1][c] * h, D = incr[i][c];
        r[c] = (d0 + d1 - 2.0 * D) * s * s * s + (3.0 * D - 2.0 * d0 - d1) * s * s + d0 * s;
      }
      out[k] = qmul(fromRotvec(r), q[i]);
      qnorm(out[k]);
    }
    return rotValue(out, false);
  } SP_END
  SP_ADD("rigid_transform", 2, 2, "translation, rotation") {
    Vec tr;
    std::vector<Quat> q;
    if (!getVec(a, 0, ctx, tr))
      return Value(0.0);
    if (tr.size() != 3 || !readRot(a[1], q) || q.size() != 1) {
      ctx.fail("give a translation [x, y, z] and one rotation");
      return Value(0.0);
    }
    return makeDict({{"translation", toValue(tr)}, {"rotation", a[1]}});
  } SP_END
  SP_ADD("rigid_apply", 2, 2, "t, points") {
    const Value *tv = dictGet(a[0], "translation"), *rv = dictGet(a[0], "rotation");
    Vec tr;
    std::vector<Quat> q;
    Mat V;
    if (!tv || !rv || !readVec(*tv, tr) || !readRot(*rv, q)) {
      ctx.fail("the first argument must be the result of rigid_transform()");
      return Value(0.0);
    }
    if (!getMat(a, 1, ctx, V))
      return Value(0.0);
    if (V.c != 3) {
      ctx.fail("the points must have three columns");
      return Value(0.0);
    }
    Mat O(V.r, 3);
    for (size_t i = 0; i < V.r; i++) {
      rotate(q[0], V.row(i), O.row(i));
      for (int c = 0; c < 3; c++)
        O(i, c) += tr[c];
    }
    if (V.r == 1)
      return toValue(O.a);
    return toValue(O);
  } SP_END
}

} // namespace scipy
} // namespace nc
