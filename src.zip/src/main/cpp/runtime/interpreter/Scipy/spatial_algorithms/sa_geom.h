// Computational geometry kernels: convex hull in any dimension (incremental,
// exact enough for doubles), Delaunay triangulation by lifting to the paraboloid.
#ifndef NC_SCIPY_SA_GEOM_H
#define NC_SCIPY_SA_GEOM_H

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace geom {

struct Facet {
  std::vector<size_t> v; // d vertices
  Vec normal;            // outward, unit length
  double offset = 0.0;   // normal . x + offset = 0 on the facet
};

// False when the points do not span the space.
bool convexHull(const Mat &P, std::vector<Facet> &facets);
// neighbors[f][k] is the facet opposite vertex k of facet f, or -1.
std::vector<std::vector<long long>> facetNeighbors(const std::vector<std::vector<size_t>> &simplices, size_t dim);
// Simplices (d + 1 vertices each); false when the points are degenerate.
bool delaunay(const Mat &P, std::vector<std::vector<size_t>> &simplices);
// The simplex holding q, or -1. bary gets d + 1 barycentric coordinates.
long long findSimplex(const Mat &P, const std::vector<std::vector<size_t>> &simplices, const double *q, Vec *bary);

} // namespace geom
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SA_GEOM_H
