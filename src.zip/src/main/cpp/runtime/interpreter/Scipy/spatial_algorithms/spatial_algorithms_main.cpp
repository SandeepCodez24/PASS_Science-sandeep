// Section 19 of 25 - Spatial Algorithms (scipy.spatial): trees, hulls and
// triangulations here; distances and rotations in sa_distance.cpp and sa_rotation.cpp.
#include "spatial_algorithms_main.h"

#include <functional>
#include <map>
#include <queue>

#include "../../builtins/builtins.h"
#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "sa_geom.h"

#define SP_SEC Section::SpatialAlgorithms

namespace nc {
namespace scipy {

void registerSpatialDistances(Registry &reg);
void registerSpatialRotations(Registry &reg);

namespace {

// A k-d tree held as an implicit balanced tree: the point order, each range's
// middle element the split, the axis cycling with depth.
void buildTree(const Mat &P, std::vector<size_t> &idx, size_t lo, size_t hi, size_t depth) {
  if (hi - lo < 2)
    return;
  const size_t mid = (lo + hi) / 2, ax = depth % P.c;
  std::nth_element(idx.begin() + lo, idx.begin() + mid, idx.begin() + hi,
                   [&](size_t x, size_t y) { return P(x, ax) < P(y, ax); });
  buildTree(P, idx, lo, mid, depth + 1);
  buildTree(P, idx, mid + 1, hi, depth + 1);
}

struct Tree {
  Mat P;
  std::vector<size_t> idx;
};

bool readTree(const Value &t, Tree &out) {
  const Value *p = dictGet(t, "points"), *i = dictGet(t, "order");
  Vec ord;
  if (!p || !i || !readMat(*p, out.P) || !readVec(*i, ord))
    return false;
  out.idx.assign(ord.begin(), ord.end());
  return true;
}

double sqDistTo(const Mat &P, size_t i, const double *q) {
  double s = 0.0;
  for (size_t j = 0; j < P.c; j++)
    s += (P(i, j) - q[j]) * (P(i, j) - q[j]);
  return s;
}

void nearest(const Tree &T, const double *q, size_t k, size_t lo, size_t hi, size_t depth,
             std::priority_queue<std::pair<double, size_t>> &best) {
  if (lo >= hi)
    return;
  const size_t mid = (lo + hi) / 2, pt = T.idx[mid], ax = depth % T.P.c;
  const double d = sqDistTo(T.P, pt, q);
  if (best.size() < k)
    best.push({d, pt});
  else if (d < best.top().first) {
    best.pop();
    best.push({d, pt});
  }
  const double diff = q[ax] - T.P(pt, ax);
  const bool leftFirst = diff < 0.0;
  nearest(T, q, k, leftFirst ? lo : mid + 1, leftFirst ? mid : hi, depth + 1, best);
  if (best.size() < k || diff * diff < best.top().first)
    nearest(T, q, k, leftFirst ? mid + 1 : lo, leftFirst ? hi : mid, depth + 1, best);
}

void inBall(const Tree &T, const double *q, double r2, size_t lo, size_t hi, size_t depth, IVec &out) {
  if (lo >= hi)
    return;
  const size_t mid = (lo + hi) / 2, pt = T.idx[mid], ax = depth % T.P.c;
  if (sqDistTo(T.P, pt, q) <= r2)
    out.push_back((long long)pt);
  const double diff = q[ax] - T.P(pt, ax);
  if (diff <= 0.0 || diff * diff <= r2)
    inBall(T, q, r2, lo, mid, depth + 1, out);
  if (diff >= 0.0 || diff * diff <= r2)
    inBall(T, q, r2, mid + 1, hi, depth + 1, out);
}

Value listOf(const std::vector<IVec> &lists) {
  std::vector<Value> cells;
  for (const IVec &l : lists)
    cells.push_back(toValue(l));
  return Value(std::vector<Value>(cells));
}

template <class C> Mat indexMat(const std::vector<C> &rows, size_t cols) {
  Mat M(rows.size(), cols);
  for (size_t i = 0; i < rows.size(); i++)
    for (size_t j = 0; j < cols && j < rows[i].size(); j++)
      M(i, j) = static_cast<double>(rows[i][j]);
  return M;
}

// The centre of the circumscribed sphere of a simplex.
bool circumcentre(const Mat &P, const std::vector<size_t> &v, Vec &c) {
  const size_t d = P.c;
  Mat A(d, d);
  Vec b(d);
  for (size_t i = 0; i < d; i++) {
    double s = 0.0;
    for (size_t j = 0; j < d; j++) {
      A(i, j) = P(v[i + 1], j) - P(v[0], j);
      s += A(i, j) * A(i, j);
    }
    b[i] = 0.5 * s;
  }
  if (!la::solveVec(A, b))
    return false;
  c = b;
  for (size_t j = 0; j < d; j++)
    c[j] += P(v[0], j);
  return true;
}

bool triangulation(const Value &t, Mat &P, std::vector<std::vector<size_t>> &simp) {
  const Value *p = dictGet(t, "points"), *s = dictGet(t, "simplices");
  Mat S;
  if (!p || !s || !readMat(*p, P) || !readMat(*s, S))
    return false;
  simp.assign(S.r, std::vector<size_t>(S.c));
  for (size_t i = 0; i < S.r; i++)
    for (size_t j = 0; j < S.c; j++)
      simp[i][j] = (size_t)S(i, j);
  return true;
}

void plotLines(const Vec &x, const Vec &y) { callBuiltin("plot", {toValue(x), toValue(y)}); }

} // namespace

void registerSpatialAlgorithms(Registry &reg) {
  SP_ADD("kdtree", 1, 1, "points") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    std::vector<size_t> idx(P.r);
    for (size_t i = 0; i < P.r; i++)
      idx[i] = i;
    buildTree(P, idx, 0, P.r, 0);
    IVec ord(idx.begin(), idx.end());
    return makeDict({{"points", toValue(P)}, {"order", toValue(ord)}, {"m", Value((double)P.c)}, {"n", Value((double)P.r)}});
  } SP_END
  SP_ADD("kdtree_query", 2, 3, "tree, query, k=1") {
    Tree T;
    Mat Q;
    if (!readTree(a[0], T)) {
      ctx.fail("the first argument must be the result of kdtree()");
      return Value(0.0);
    }
    if (!getMat(a, 1, ctx, Q))
      return Value(0.0);
    if (Q.c != T.P.c) {
      ctx.fail("each query point needs " + std::to_string(T.P.c) + " coordinates");
      return Value(0.0);
    }
    const long long k = optInt(a, 2, 1);
    if (k < 1) {
      ctx.fail("k must be at least 1");
      return Value(0.0);
    }
    Mat D(Q.r, (size_t)k, kInf), I(Q.r, (size_t)k, (double)T.P.r);
    par::forBlocks(Q.r, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
      for (size_t r = b; r < e; r++) {
        std::priority_queue<std::pair<double, size_t>> best;
        nearest(T, Q.row(r), (size_t)k, 0, T.idx.size(), 0, best);
        for (size_t c = best.size(); c-- > 0;) {
          D(r, c) = std::sqrt(best.top().first);
          I(r, c) = (double)best.top().second;
          best.pop();
        }
      }
    });
    if (Q.r == 1 && k == 1)
      return makeDict({{"dist", Value(D.a[0])}, {"index", Value(I.a[0])}});
    if (Q.r == 1 || k == 1) {
      return makeDict({{"dist", toValue(D.a)}, {"index", toValue(I.a)}});
    }
    return makeDict({{"dist", toValue(D)}, {"index", toValue(I)}});
  } SP_END
  SP_ADD("kdtree_ball", 3, 3, "tree, point, r") {
    Tree T;
    Vec q;
    double r;
    if (!readTree(a[0], T)) {
      ctx.fail("the first argument must be the result of kdtree()");
      return Value(0.0);
    }
    if (!getVec(a, 1, ctx, q) || !argNumber(a, 2, ctx, r))
      return Value(0.0);
    if (q.size() != T.P.c) {
      ctx.fail("the point needs " + std::to_string(T.P.c) + " coordinates");
      return Value(0.0);
    }
    IVec out;
    inBall(T, q.data(), r * r, 0, T.idx.size(), 0, out);
    std::sort(out.begin(), out.end());
    return toValue(out);
  } SP_END
  SP_ADD("box_volume", 2, 2, "mins, maxes") {
    Vec lo, hi;
    if (!getVec(a, 0, ctx, lo) || !getVec(a, 1, ctx, hi))
      return Value(0.0);
    if (lo.size() != hi.size()) {
      ctx.fail("mins and maxes must have the same length");
      return Value(0.0);
    }
    double v = 1.0;
    for (size_t i = 0; i < lo.size(); i++)
      v *= hi[i] - lo[i];
    return Value(v);
  } SP_END
  SP_ADD("delaunay", 1, 1, "points") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    std::vector<std::vector<size_t>> simp;
    if (!geom::delaunay(P, simp)) {
      ctx.fail("the points do not span the space, or there are too few");
      return Value(0.0);
    }
    auto nb = geom::facetNeighbors(simp, P.c);
    return makeDict({{"points", toValue(P)}, {"simplices", toValue(indexMat(simp, P.c + 1))}, {"neighbors", toValue(indexMat(nb, P.c + 1))}});
  } SP_END
  SP_ADD("convex_hull", 1, 1, "points") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    std::vector<geom::Facet> f;
    if (!geom::convexHull(P, f)) {
      ctx.fail("the points do not span the space, or there are too few");
      return Value(0.0);
    }
    const size_t d = P.c;
    std::vector<std::vector<size_t>> simp;
    Mat eq(f.size(), d + 1);
    for (size_t i = 0; i < f.size(); i++) {
      simp.push_back(f[i].v);
      for (size_t j = 0; j < d; j++)
        eq(i, j) = f[i].normal[j];
      eq(i, d) = f[i].offset;
    }
    // Area of the boundary and volume inside, from one point inside.
    Vec inner(d, 0.0);
    std::vector<char> isV(P.r, 0);
    for (const auto &s : simp)
      for (size_t v : s)
        isV[v] = 1;
    IVec verts;
    for (size_t i = 0; i < P.r; i++)
      if (isV[i]) {
        verts.push_back((long long)i);
        for (size_t j = 0; j < d; j++)
          inner[j] += P(i, j);
      }
    for (double &x : inner)
      x /= (double)verts.size();
    double area = 0.0, volume = 0.0, fact = 1.0;
    for (size_t k = 2; k < d; k++)
      fact *= (double)k;
    for (const auto &fc : f) {
      // The facet's (d-1)-volume by Gram determinant.
      Mat E(d - 1, d);
      for (size_t i = 1; i < d; i++)
        for (size_t j = 0; j < d; j++)
          E(i - 1, j) = P(fc.v[i], j) - P(fc.v[0], j);
      const double g = std::sqrt(std::max(0.0, la::det(mul(E, transposeOf(E)))));
      const double ar = g / fact;
      double h = fc.offset;
      for (size_t j = 0; j < d; j++)
        h += fc.normal[j] * inner[j];
      area += ar;
      volume += ar * std::fabs(h) / (double)d;
    }
    // In 2-D, SciPy lists hull vertices counter-clockwise.
    if (d == 2) {
      std::sort(verts.begin(), verts.end(), [&](long long x, long long y) {
        return std::atan2(P((size_t)x, 1) - inner[1], P((size_t)x, 0) - inner[0]) <
               std::atan2(P((size_t)y, 1) - inner[1], P((size_t)y, 0) - inner[0]);
      });
    }
    return makeDict({{"points", toValue(P)}, {"vertices", toValue(verts)}, {"simplices", toValue(indexMat(simp, d))},
                     {"equations", toValue(eq)}, {"volume", Value(volume)}, {"area", Value(area)}});
  } SP_END
  SP_ADD("voronoi", 1, 1, "points") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    std::vector<std::vector<size_t>> simp;
    if (!geom::delaunay(P, simp)) {
      ctx.fail("the points do not span the space, or there are too few");
      return Value(0.0);
    }
    const size_t d = P.c;
    Mat V(simp.size(), d);
    for (size_t s = 0; s < simp.size(); s++) {
      Vec c;
      if (circumcentre(P, simp[s], c))
        std::copy(c.begin(), c.end(), V.row(s));
    }
    auto nb = geom::facetNeighbors(simp, d);
    std::vector<IVec> regions(P.r);
    std::vector<char> unbounded(P.r, 0);
    std::vector<std::vector<long long>> ridgePts, ridgeVerts;
    for (size_t s = 0; s < simp.size(); s++) {
      for (size_t k = 0; k <= d; k++)
        regions[simp[s][k]].push_back((long long)s);
      for (size_t k = 0; k <= d; k++) {
        const long long other = nb[s][k];
        if (other >= 0 && other < (long long)s)
          continue;
        // The face opposite vertex k separates each pair of its vertices in 2-D.
        if (d == 2) {
          long long p0 = -1, p1 = -1;
          for (size_t q = 0; q <= 2; q++)
            if (q != k) {
              if (p0 < 0)
                p0 = (long long)simp[s][q];
              else
                p1 = (long long)simp[s][q];
            }
          ridgePts.push_back({p0, p1});
          ridgeVerts.push_back({other, (long long)s});
          if (other < 0) {
            unbounded[(size_t)p0] = 1;
            unbounded[(size_t)p1] = 1;
          }
        } else if (other < 0) {
          for (size_t q = 0; q <= d; q++)
            if (q != k)
              unbounded[simp[s][q]] = 1;
        }
      }
    }
    if (d == 2) {
      for (size_t p = 0; p < P.r; p++) {
        IVec &r = regions[p];
        std::sort(r.begin(), r.end(), [&](long long x, long long y) {
          return std::atan2(V((size_t)x, 1) - P(p, 1), V((size_t)x, 0) - P(p, 0)) <
                 std::atan2(V((size_t)y, 1) - P(p, 1), V((size_t)y, 0) - P(p, 0));
        });
      }
    }
    for (size_t p = 0; p < P.r; p++)
      if (unbounded[p])
        regions[p].insert(regions[p].begin(), -1);
    return makeDict({{"points", toValue(P)}, {"vertices", toValue(V)}, {"regions", listOf(regions)},
                     {"ridge_points", toValue(indexMat(ridgePts, 2))}, {"ridge_vertices", toValue(indexMat(ridgeVerts, 2))}});
  } SP_END
  SP_ADD("spherical_voronoi", 1, 3, "points, radius=1, center") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    if (P.c != 3) {
      ctx.fail("the points must have three columns");
      return Value(0.0);
    }
    const double radius = optNum(a, 1, 1.0);
    Vec cen(3, 0.0);
    if (a.size() > 2 && (!readVec(a[2], cen) || cen.size() != 3)) {
      ctx.fail("center must be [x, y, z]");
      return Value(0.0);
    }
    if (P.r < 4 || !(radius > 0.0)) {
      ctx.fail("at least four points and a positive radius are needed");
      return Value(0.0);
    }
    Mat U = P;
    for (size_t i = 0; i < U.r; i++)
      for (size_t j = 0; j < 3; j++)
        U(i, j) = (U(i, j) - cen[j]) / radius;
    std::vector<geom::Facet> f;
    if (!geom::convexHull(U, f)) {
      ctx.fail("the points do not span the sphere");
      return Value(0.0);
    }
    Mat V(f.size(), 3);
    std::vector<IVec> regions(P.r);
    for (size_t s = 0; s < f.size(); s++) {
      for (size_t j = 0; j < 3; j++)
        V(s, j) = f[s].normal[j] * radius + cen[j];
      for (size_t v : f[s].v)
        regions[v].push_back((long long)s);
    }
    // Each region's vertices around its generator.
    for (size_t p = 0; p < P.r; p++) {
      Vec n{U(p, 0), U(p, 1), U(p, 2)};
      Vec e1 = std::fabs(n[0]) < 0.9 ? Vec{1, 0, 0} : Vec{0, 1, 0};
      double t = e1[0] * n[0] + e1[1] * n[1] + e1[2] * n[2];
      for (int j = 0; j < 3; j++)
        e1[j] -= t * n[j];
      double ln = std::sqrt(e1[0] * e1[0] + e1[1] * e1[1] + e1[2] * e1[2]);
      for (int j = 0; j < 3; j++)
        e1[j] /= ln;
      Vec e2{n[1] * e1[2] - n[2] * e1[1], n[2] * e1[0] - n[0] * e1[2], n[0] * e1[1] - n[1] * e1[0]};
      auto angle = [&](long long s) {
        double x = 0.0, y = 0.0;
        for (int j = 0; j < 3; j++) {
          const double w = (V((size_t)s, j) - cen[j]) / radius;
          x += w * e1[j];
          y += w * e2[j];
        }
        return std::atan2(y, x);
      };
      std::sort(regions[p].begin(), regions[p].end(), [&](long long x, long long y) { return angle(x) < angle(y); });
    }
    return makeDict({{"points", toValue(P)}, {"vertices", toValue(V)}, {"regions", listOf(regions)}, {"radius", Value(radius)}});
  } SP_END
  SP_ADD("halfspace_intersection", 2, 2, "halfspaces, interior") {
    // Duality: each halfspace a.x + b <= 0 maps to the point a / -(a.x0 + b);
    // the facets of their hull are the corners of the intersection.
    Mat H;
    Vec x0;
    if (!getMat(a, 0, ctx, H) || !getVec(a, 1, ctx, x0))
      return Value(0.0);
    const size_t d = x0.size();
    if (H.c != d + 1) {
      ctx.fail("each halfspace row needs " + std::to_string(d) + " coefficients and an offset");
      return Value(0.0);
    }
    Mat D(H.r, d);
    for (size_t i = 0; i < H.r; i++) {
      double s = H(i, d);
      for (size_t j = 0; j < d; j++)
        s += H(i, j) * x0[j];
      if (s >= 0.0) {
        ctx.fail("the interior point is not inside every halfspace");
        return Value(0.0);
      }
      for (size_t j = 0; j < d; j++)
        D(i, j) = H(i, j) / -s;
    }
    std::vector<geom::Facet> f;
    if (!geom::convexHull(D, f)) {
      ctx.fail("the halfspaces do not bound a region");
      return Value(0.0);
    }
    Mat X(f.size(), d);
    for (size_t s = 0; s < f.size(); s++)
      for (size_t j = 0; j < d; j++)
        X(s, j) = f[s].normal[j] / -f[s].offset + x0[j];
    return makeDict({{"intersections", toValue(X)}, {"interior_point", toValue(x0)}, {"halfspaces", toValue(H)}});
  } SP_END
  SP_ADD("find_simplex", 2, 2, "tri, points") {
    Mat P, Q;
    std::vector<std::vector<size_t>> simp;
    if (!triangulation(a[0], P, simp)) {
      ctx.fail("the first argument must be the result of delaunay()");
      return Value(0.0);
    }
    if (!getMat(a, 1, ctx, Q))
      return Value(0.0);
    if (Q.c != P.c) {
      ctx.fail("each point needs " + std::to_string(P.c) + " coordinates");
      return Value(0.0);
    }
    IVec out(Q.r);
    for (size_t i = 0; i < Q.r; i++)
      out[i] = geom::findSimplex(P, simp, Q.row(i), nullptr);
    return toValue(out);
  } SP_END
  SP_ADD("plot_delaunay", 1, 1, "tri") {
    Mat P;
    std::vector<std::vector<size_t>> simp;
    if (!triangulation(a[0], P, simp) || P.c != 2) {
      ctx.fail("the argument must be a 2-D result of delaunay()");
      return Value(0.0);
    }
    Vec x, y;
    for (const auto &s : simp) {
      for (int k = 0; k < 4; k++) {
        x.push_back(P(s[k % 3], 0));
        y.push_back(P(s[k % 3], 1));
      }
      x.push_back(kNaN);
      y.push_back(kNaN);
    }
    plotLines(x, y);
    return Value(0.0);
  } SP_END
  SP_ADD("plot_convex_hull", 1, 1, "hull") {
    const Value *pv = dictGet(a[0], "points"), *sv = dictGet(a[0], "simplices");
    Mat P, S;
    if (!pv || !sv || !readMat(*pv, P) || !readMat(*sv, S) || P.c != 2) {
      ctx.fail("the argument must be a 2-D result of convex_hull()");
      return Value(0.0);
    }
    Vec x, y;
    for (size_t i = 0; i < S.r; i++) {
      x.push_back(P((size_t)S(i, 0), 0));
      y.push_back(P((size_t)S(i, 0), 1));
      x.push_back(P((size_t)S(i, 1), 0));
      y.push_back(P((size_t)S(i, 1), 1));
      x.push_back(kNaN);
      y.push_back(kNaN);
    }
    plotLines(x, y);
    return Value(0.0);
  } SP_END
  SP_ADD("plot_voronoi", 1, 1, "vor") {
    const Value *vv = dictGet(a[0], "vertices"), *rv = dictGet(a[0], "ridge_vertices");
    Mat V, R;
    if (!vv || !rv || !readMat(*vv, V) || !readMat(*rv, R) || V.c != 2) {
      ctx.fail("the argument must be a 2-D result of voronoi()");
      return Value(0.0);
    }
    Vec x, y;
    for (size_t i = 0; i < R.r; i++) {
      if (R(i, 0) < 0 || R(i, 1) < 0)
        continue;
      x.push_back(V((size_t)R(i, 0), 0));
      y.push_back(V((size_t)R(i, 0), 1));
      x.push_back(V((size_t)R(i, 1), 0));
      y.push_back(V((size_t)R(i, 1), 1));
      x.push_back(kNaN);
      y.push_back(kNaN);
    }
    plotLines(x, y);
    return Value(0.0);
  } SP_END
  registerSpatialDistances(reg);
  registerSpatialRotations(reg);
  reg.setParallel({"kdtree_query"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
