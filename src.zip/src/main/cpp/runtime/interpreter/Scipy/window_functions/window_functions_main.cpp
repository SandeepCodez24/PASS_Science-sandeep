// Section 15 of 25 - Window Functions (scipy.signal.windows).
// sym = 1 (the default) gives a symmetric window; sym = 0 a periodic one.
// get_window() is registered with the signal section; windowByName() here serves it.
#include "window_functions_main.h"

#include "../fourier_transforms/ft_core.h"
#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "../signal_processing/sg_core.h"

#define SP_SEC Section::WindowFunctions

namespace nc {
namespace scipy {

namespace {

constexpr par::Cost kWinCost{par::Kind::Compute, 20.0};

double besselI0(double x) {
  double s = 1.0, t = 1.0, q = x * x / 4.0;
  for (int k = 1; k < 500; k++) {
    t *= q / (static_cast<double>(k) * k);
    s += t;
    if (t < s * 1e-17)
      break;
  }
  return s;
}

// A symmetric window of n+1 points with the last dropped is the periodic form.
struct Extend {
  size_t m;
  bool drop;
  Extend(size_t n, bool sym) : m(sym ? n : n + 1), drop(!sym) {}
  Vec finish(Vec w) const {
    if (drop)
      w.pop_back();
    return w;
  }
};

template <class F> Vec fill(size_t n, F fn) {
  Vec w(n);
  par::forBlocks(n, kWinCost, [&](size_t b, size_t e) {
    for (size_t i = b; i < e; i++)
      w[i] = fn(i);
  });
  return w;
}

Vec generalCosine(size_t n, const Vec &c, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double step = 2.0 * kPi / static_cast<double>(ex.m - 1);
  Vec w = fill(ex.m, [&](size_t i) {
    const double fac = -kPi + step * static_cast<double>(i);
    double s = 0.0;
    for (size_t k = 0; k < c.size(); k++)
      s += c[k] * std::cos(static_cast<double>(k) * fac);
    return s;
  });
  return ex.finish(w);
}

Vec kaiserWin(size_t n, double beta, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double alpha = static_cast<double>(ex.m - 1) / 2.0, den = besselI0(beta);
  Vec w = fill(ex.m, [&](size_t i) {
    const double t = (static_cast<double>(i) - alpha) / alpha;
    return besselI0(beta * std::sqrt(std::max(0.0, 1.0 - t * t))) / den;
  });
  return ex.finish(w);
}

Vec gaussWin(size_t n, double std_, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double c = (static_cast<double>(ex.m) - 1.0) / 2.0;
  return ex.finish(fill(ex.m, [&](size_t i) {
    const double t = (static_cast<double>(i) - c) / std_;
    return std::exp(-0.5 * t * t);
  }));
}

Vec generalGauss(size_t n, double p, double sig, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double c = (static_cast<double>(ex.m) - 1.0) / 2.0;
  return ex.finish(fill(ex.m, [&](size_t i) {
    return std::exp(-0.5 * std::pow(std::fabs((static_cast<double>(i) - c) / sig), 2.0 * p));
  }));
}

Vec triangWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const size_t m = ex.m;
  Vec w(m);
  for (size_t i = 0; i < (m + 1) / 2; i++) {
    const double v = m % 2 == 0 ? (2.0 * i + 1.0) / m : 2.0 * (i + 1.0) / (m + 1.0);
    w[i] = w[m - 1 - i] = v;
  }
  return ex.finish(w);
}

Vec bartlettWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double d = static_cast<double>(ex.m - 1);
  return ex.finish(fill(ex.m, [&](size_t i) {
    const double x = static_cast<double>(i);
    return x <= d / 2.0 ? 2.0 * x / d : 2.0 - 2.0 * x / d;
  }));
}

Vec parzenWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double m = static_cast<double>(ex.m);
  return ex.finish(fill(ex.m, [&](size_t i) {
    const double t = std::fabs(-(m - 1) / 2.0 + static_cast<double>(i));
    const double r = t / (m / 2.0);
    return t <= (m - 1) / 4.0 ? 1.0 - 6.0 * r * r + 6.0 * r * r * r : 2.0 * std::pow(1.0 - r, 3.0);
  }));
}

Vec bohmanWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  Vec w = fill(ex.m, [&](size_t i) {
    if (i == 0 || i == ex.m - 1)
      return 0.0;
    const double f = std::fabs(-1.0 + 2.0 * static_cast<double>(i) / static_cast<double>(ex.m - 1));
    return (1.0 - f) * std::cos(kPi * f) + 1.0 / kPi * std::sin(kPi * f);
  });
  return ex.finish(w);
}

Vec barthannWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double d = static_cast<double>(ex.m - 1);
  return ex.finish(fill(ex.m, [&](size_t i) {
    const double f = std::fabs(static_cast<double>(i) / d - 0.5);
    return 0.62 - 0.48 * f + 0.38 * std::cos(2.0 * kPi * f);
  }));
}

Vec cosineWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double m = static_cast<double>(ex.m);
  return ex.finish(fill(ex.m, [&](size_t i) { return std::sin(kPi / m * (static_cast<double>(i) + 0.5)); }));
}

Vec tukeyWin(size_t n, double alpha, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  if (alpha <= 0.0)
    return Vec(n, 1.0);
  if (alpha >= 1.0)
    return generalCosine(n, {0.5, 0.5}, sym);
  Extend ex(n, sym);
  const double d = static_cast<double>(ex.m - 1);
  const size_t width = static_cast<size_t>(std::floor(alpha * d / 2.0));
  Vec w = fill(ex.m, [&](size_t i) {
    const double x = static_cast<double>(i);
    if (i <= width)
      return 0.5 * (1.0 + std::cos(kPi * (-1.0 + 2.0 * x / alpha / d)));
    if (i >= ex.m - 1 - width)
      return 0.5 * (1.0 + std::cos(kPi * (-2.0 / alpha + 1.0 + 2.0 * x / alpha / d)));
    return 1.0;
  });
  return ex.finish(w);
}

Vec exponentialWin(size_t n, double center, bool hasCenter, double tau, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double c = hasCenter ? center : (static_cast<double>(ex.m) - 1.0) / 2.0;
  return ex.finish(fill(ex.m, [&](size_t i) { return std::exp(-std::fabs(static_cast<double>(i) - c) / tau); }));
}

Vec lanczosWin(size_t n, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double d = static_cast<double>(ex.m - 1);
  return ex.finish(fill(ex.m, [&](size_t i) {
    const double x = 2.0 * static_cast<double>(i) / d - 1.0;
    return x == 0.0 ? 1.0 : std::sin(kPi * x) / (kPi * x);
  }));
}

Vec chebwin(size_t n, double at, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const size_t M = ex.m;
  const double order = static_cast<double>(M) - 1.0;
  const double beta = std::cosh(1.0 / order * std::acosh(std::pow(10.0, std::fabs(at) / 20.0)));
  CVec p(M);
  for (size_t k = 0; k < M; k++) {
    const double x = beta * std::cos(kPi * static_cast<double>(k) / static_cast<double>(M));
    double t;
    if (x > 1.0)
      t = std::cosh(order * std::acosh(x));
    else if (x < -1.0)
      t = (2.0 * (M % 2) - 1.0) * std::cosh(order * std::acosh(-x));
    else
      t = std::cos(order * std::acos(x));
    p[k] = t;
  }
  Vec w(M);
  if (M % 2) {
    CVec f = ft::fftOf(p);
    const size_t half = (M + 1) / 2;
    for (size_t i = 0; i < half; i++) {
      w[half - 1 + i] = f[i].real();
      w[half - 1 - i] = f[i].real();
    }
  } else {
    for (size_t k = 0; k < M; k++)
      p[k] *= std::polar(1.0, kPi / static_cast<double>(M) * static_cast<double>(k));
    CVec f = ft::fftOf(p);
    const size_t half = M / 2 + 1;
    for (size_t i = 1; i < half; i++) {
      w[half - 1 + i - 1] = f[i].real();
      w[half - 1 - i] = f[i].real();
    }
  }
  double mx = 0.0;
  for (double v : w)
    mx = std::max(mx, v);
  for (double &v : w)
    v /= mx;
  return ex.finish(w);
}

Vec taylorWin(size_t n, int nbar, double sll, bool norm, bool sym) {
  if (n <= 1)
    return Vec(n, 1.0);
  Extend ex(n, sym);
  const double B = std::pow(10.0, sll / 20.0);
  const double A = std::acosh(B) / kPi;
  const double s2 = nbar * nbar / (A * A + (nbar - 0.5) * (nbar - 0.5));
  Vec Fm(nbar - 1);
  for (int m = 1; m < nbar; m++) {
    const double mm = m;
    double numer = (m % 2 == 1 ? 1.0 : -1.0);
    for (int k = 1; k < nbar; k++)
      numer *= 1.0 - mm * mm / s2 / (A * A + (k - 0.5) * (k - 0.5));
    double denom = 2.0;
    for (int k = 1; k < nbar; k++)
      if (k != m)
        denom *= 1.0 - mm * mm / (static_cast<double>(k) * k);
    Fm[m - 1] = numer / denom;
  }
  const double M = static_cast<double>(ex.m);
  auto wAt = [&](double x) {
    double s = 0.0;
    for (int m = 1; m < nbar; m++)
      s += Fm[m - 1] * std::cos(2.0 * kPi * m * (x - M / 2.0 + 0.5) / M);
    return 1.0 + 2.0 * s;
  };
  Vec w = fill(ex.m, [&](size_t i) { return wAt(static_cast<double>(i)); });
  if (norm) {
    const double scale = 1.0 / wAt((M - 1.0) / 2.0);
    for (double &v : w)
      v *= scale;
  }
  return ex.finish(w);
}

Vec kbdWin(size_t n, double beta, bool sym) {
  // Kaiser-Bessel-derived: root of the cumulative sum of a Kaiser window.
  const size_t half = n / 2;
  Vec k = kaiserWin(half + 1, beta, true);
  Vec cs(k.size());
  double s = 0.0;
  for (size_t i = 0; i < k.size(); i++) {
    s += k[i];
    cs[i] = s;
  }
  Vec w(n);
  for (size_t i = 0; i < half; i++) {
    w[i] = std::sqrt(cs[i] / cs.back());
    w[n - 1 - i] = w[i];
  }
  (void)sym;
  return w;
}

// Slepian tapers: eigenvectors of the symmetric tridiagonal matrix.
Mat dpssWin(size_t n, double NW, size_t kmax, bool sym, bool approximate) {
  Extend ex(n, sym);
  const size_t M = ex.m;
  const double W = NW / static_cast<double>(M);
  Mat A(M, M);
  for (size_t i = 0; i < M; i++) {
    const double x = (static_cast<double>(M) - 1.0 - 2.0 * i) / 2.0;
    A(i, i) = x * x * std::cos(2.0 * kPi * W);
    if (i + 1 < M)
      A(i, i + 1) = A(i + 1, i) = 0.5 * (i + 1.0) * (static_cast<double>(M) - i - 1.0);
  }
  Vec w;
  Mat Z;
  la::eigHermitian(A, w, Z);
  Mat out(kmax, n);
  const double thresh = std::max(1e-7, 1.0 / static_cast<double>(M));
  double mx = 0.0;
  for (size_t k = 0; k < kmax; k++) {
    const size_t col = M - 1 - k;
    // SciPy's sign rules: even tapers sum positive, odd ones begin with a positive lobe.
    double sgn = 1.0;
    if (k % 2 == 0) {
      double sum = 0.0;
      for (size_t i = 0; i < M; i++)
        sum += Z(i, col);
      if (sum < 0.0)
        sgn = -1.0;
    } else {
      for (size_t i = 0; i < M; i++)
        if (Z(i, col) * Z(i, col) > thresh) {
          sgn = Z(i, col) < 0.0 ? -1.0 : 1.0;
          break;
        }
    }
    for (size_t i = 0; i < n; i++) {
      out(k, i) = Z(i, col) * sgn;
      if (k == 0)
        mx = std::max(mx, out(k, i));
    }
    if (k == 0)
      for (size_t i = n; i < M; i++)
        mx = std::max(mx, Z(i, col) * sgn);
  }
  if (approximate) {
    // Unit peak, then the even-length correction of SciPy's "approximate" norm.
    const double md = static_cast<double>(M);
    const double f = (M % 2 == 0 ? md * md / (md * md + NW) : 1.0) / mx;
    for (double &v : out.a)
      v *= f;
  }
  return out;
}

Vec flattopCoeffs() {
  return {0.21557895, 0.41663158, 0.277263158, 0.083578947, 0.006947368};
}
Vec hammingCoeffs(double alpha) { return {alpha, 1.0 - alpha}; }

#define NC_WIN_SIZE                                                                                \
  long long n;                                                                                     \
  if (!argNonNegativeInt(a, 0, ctx, n))                                                            \
    return Value(0.0);

} // namespace

namespace sg {

bool windowByName(const std::string &nameIn, const Vec &p, size_t n, bool sym, Vec &out, std::string &err) {
  std::string name = nameIn;
  for (char &c : name)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  auto need = [&](size_t k) {
    if (p.size() < k) {
      err = "the window \"" + name + "\" needs a parameter: [\"" + name + "\", value]";
      return false;
    }
    return true;
  };
  if (name == "hann" || name == "hanning") out = generalCosine(n, {0.5, 0.5}, sym);
  else if (name == "hamming") out = generalCosine(n, hammingCoeffs(0.54), sym);
  else if (name == "blackman") out = generalCosine(n, {0.42, 0.50, 0.08}, sym);
  else if (name == "blackmanharris") out = generalCosine(n, {0.35875, 0.48829, 0.14128, 0.01168}, sym);
  else if (name == "nuttall") out = generalCosine(n, {0.3635819, 0.4891775, 0.1365995, 0.0106411}, sym);
  else if (name == "flattop") out = generalCosine(n, flattopCoeffs(), sym);
  else if (name == "boxcar" || name == "rectangular" || name == "ones") out.assign(n, 1.0);
  else if (name == "triang" || name == "triangle") out = triangWin(n, sym);
  else if (name == "bartlett") out = bartlettWin(n, sym);
  else if (name == "parzen") out = parzenWin(n, sym);
  else if (name == "bohman") out = bohmanWin(n, sym);
  else if (name == "barthann") out = barthannWin(n, sym);
  else if (name == "cosine") out = cosineWin(n, sym);
  else if (name == "lanczos" || name == "sinc") out = lanczosWin(n, sym);
  else if (name == "tukey") out = tukeyWin(n, p.empty() ? 0.5 : p[0], sym);
  else if (name == "exponential" || name == "poisson") out = exponentialWin(n, 0.0, false, p.empty() ? 1.0 : p[0], sym);
  else if (name == "taylor") out = taylorWin(n, p.empty() ? 4 : (int)p[0], p.size() < 2 ? 30.0 : p[1], true, sym);
  else if (name == "kaiser") { if (!need(1)) return false; out = kaiserWin(n, p[0], sym); }
  else if (name == "gaussian" || name == "gauss") { if (!need(1)) return false; out = gaussWin(n, p[0], sym); }
  else if (name == "chebwin") { if (!need(1)) return false; out = chebwin(n, p[0], sym); }
  else if (name == "general_hamming") { if (!need(1)) return false; out = generalCosine(n, hammingCoeffs(p[0]), sym); }
  else if (name == "general_gaussian") { if (!need(2)) return false; out = generalGauss(n, p[0], p[1], sym); }
  else {
    err = "unknown window \"" + nameIn + "\"";
    return false;
  }
  return true;
}

} // namespace sg

void registerWindowFunctions(Registry &reg) {
  SP_ADD("barthann_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(barthannWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("bartlett_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(bartlettWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("blackman_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(generalCosine((size_t)n, {0.42, 0.50, 0.08}, optBool(a, 1, true))); } SP_END
  SP_ADD("blackmanharris_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(generalCosine((size_t)n, {0.35875, 0.48829, 0.14128, 0.01168}, optBool(a, 1, true))); } SP_END
  SP_ADD("bohman_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(bohmanWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("boxcar_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(Vec((size_t)n, 1.0)); } SP_END
  SP_ADD("chebwin_win", 2, 3, "n, at, sym=1") {
    NC_WIN_SIZE double at;
    if (!argNumber(a, 1, ctx, at))
      return Value(0.0);
    return toValue(chebwin((size_t)n, at, optBool(a, 2, true)));
  } SP_END
  SP_ADD("cosine_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(cosineWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("dpss_win", 2, 4, "n, NW, Kmax, sym=1") {
    NC_WIN_SIZE double nw;
    if (!argNumber(a, 1, ctx, nw))
      return Value(0.0);
    if (nw <= 0.0 || nw >= n / 2.0) {
      ctx.fail("NW must be above 0 and below n / 2");
      return Value(0.0);
    }
    const bool one = isOmitted(a, 2);
    const size_t k = one ? 1 : (size_t)optInt(a, 2, 1);
    Mat m = dpssWin((size_t)n, nw, k, optBool(a, 3, true), one);
    return one ? toValue(m.a) : toValue(m);
  } SP_END
  SP_ADD("exponential_win", 1, 4, "n, tau=1, center, sym=1") {
    NC_WIN_SIZE
    return toValue(exponentialWin((size_t)n, optNum(a, 2, 0.0), a.size() > 2, optNum(a, 1, 1.0), optBool(a, 3, true)));
  } SP_END
  SP_ADD("flattop_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(generalCosine((size_t)n, flattopCoeffs(), optBool(a, 1, true))); } SP_END
  SP_ADD("gaussian_win", 2, 3, "n, std, sym=1") {
    NC_WIN_SIZE double s;
    if (!argNumber(a, 1, ctx, s))
      return Value(0.0);
    return toValue(gaussWin((size_t)n, s, optBool(a, 2, true)));
  } SP_END
  SP_ADD("general_cosine_win", 2, 3, "n, a, sym=1") {
    NC_WIN_SIZE Vec c;
    if (!getVec(a, 1, ctx, c))
      return Value(0.0);
    return toValue(generalCosine((size_t)n, c, optBool(a, 2, true)));
  } SP_END
  SP_ADD("general_gaussian_win", 3, 4, "n, p, sig, sym=1") {
    NC_WIN_SIZE double p, s;
    if (!argNumber(a, 1, ctx, p) || !argNumber(a, 2, ctx, s))
      return Value(0.0);
    return toValue(generalGauss((size_t)n, p, s, optBool(a, 3, true)));
  } SP_END
  SP_ADD("general_hamming_win", 2, 3, "n, alpha, sym=1") {
    NC_WIN_SIZE double al;
    if (!argNumber(a, 1, ctx, al))
      return Value(0.0);
    return toValue(generalCosine((size_t)n, hammingCoeffs(al), optBool(a, 2, true)));
  } SP_END
  SP_ADD("hamming_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(generalCosine((size_t)n, hammingCoeffs(0.54), optBool(a, 1, true))); } SP_END
  SP_ADD("hann_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(generalCosine((size_t)n, {0.5, 0.5}, optBool(a, 1, true))); } SP_END
  SP_ADD("kaiser_win", 2, 3, "n, beta, sym=1") {
    NC_WIN_SIZE double b;
    if (!argNumber(a, 1, ctx, b))
      return Value(0.0);
    return toValue(kaiserWin((size_t)n, b, optBool(a, 2, true)));
  } SP_END
  SP_ADD("kbd_win", 2, 2, "n, beta") {
    NC_WIN_SIZE double b;
    if (!argNumber(a, 1, ctx, b))
      return Value(0.0);
    if (n % 2) {
      ctx.fail("n must be even");
      return Value(0.0);
    }
    return toValue(kbdWin((size_t)n, b, true));
  } SP_END
  SP_ADD("lanczos_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(lanczosWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("nuttall_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(generalCosine((size_t)n, {0.3635819, 0.4891775, 0.1365995, 0.0106411}, optBool(a, 1, true))); } SP_END
  SP_ADD("parzen_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(parzenWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("taylor_win", 1, 4, "n, nbar=4, sll=30, sym=1") { NC_WIN_SIZE return toValue(taylorWin((size_t)n, (int)optInt(a, 1, 4), optNum(a, 2, 30.0), true, optBool(a, 3, true))); } SP_END
  SP_ADD("triang_win", 1, 2, "n, sym=1") { NC_WIN_SIZE return toValue(triangWin((size_t)n, optBool(a, 1, true))); } SP_END
  SP_ADD("tukey_win", 1, 3, "n, alpha=0.5, sym=1") { NC_WIN_SIZE return toValue(tukeyWin((size_t)n, optNum(a, 1, 0.5), optBool(a, 2, true))); } SP_END
}

} // namespace scipy
} // namespace nc
