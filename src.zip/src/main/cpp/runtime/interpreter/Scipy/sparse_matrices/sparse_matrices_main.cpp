// Section 16 of 25 - Sparse Matrices (scipy.sparse).
#include "sparse_matrices_main.h"

#include <fstream>
#include <random>

#include "../../ops/matrix/matrix.h"
#include "../scipy_core.h"
#include "sp_core.h"

#define SP_SEC Section::SparseMatrices

namespace nc {
namespace scipy {

using namespace sp;
using scipy::sp::toValue;

namespace {

bool getShape(const Args &a, size_t i, CallContext &ctx, size_t &r, size_t &c) {
  Vec s;
  if (i >= a.size() || !readVec(a[i], s) || s.size() != 2 || s[0] < 0 || s[1] < 0) {
    ctx.fail("the " + ordinal(i) + " argument must be a shape [rows, cols]");
    return false;
  }
  r = static_cast<size_t>(s[0]);
  c = static_cast<size_t>(s[1]);
  return true;
}

// Dense matrix, Sparse, or Dict {data, rows, cols} with an optional shape.
bool buildFrom(const Args &a, CallContext &ctx, const std::string &fmt, Sparse &out) {
  if (a[0].isDict) {
    Vec v, ri, ci;
    const Value *dv = dictGet(a[0], "data"), *rv = dictGet(a[0], "rows"), *cv = dictGet(a[0], "cols");
    if (!dv || !rv || !cv || !readVec(*dv, v) || !readVec(*rv, ri) || !readVec(*cv, ci) || v.size() != ri.size() || v.size() != ci.size()) {
      ctx.fail("a Dict input needs data, rows and cols of the same length");
      return false;
    }
    size_t r = 0, c = 0;
    if (a.size() > 1) {
      if (!getShape(a, 1, ctx, r, c))
        return false;
    } else {
      for (size_t i = 0; i < v.size(); i++) {
        r = std::max(r, static_cast<size_t>(ri[i]) + 1);
        c = std::max(c, static_cast<size_t>(ci[i]) + 1);
      }
    }
    std::vector<Triplet> t;
    for (size_t i = 0; i < v.size(); i++) {
      if (ri[i] < 0 || ci[i] < 0 || ri[i] >= (double)r || ci[i] >= (double)c) {
        ctx.fail("a position lies outside the shape");
        return false;
      }
      t.push_back({static_cast<size_t>(ri[i]), static_cast<size_t>(ci[i]), v[i]});
    }
    out = fromTriplets(r, c, std::move(t), fmt);
    return true;
  }
  if (!getAny(a, 0, ctx, out))
    return false;
  out.fmt = fmt;
  return true;
}

// Values placed on diagonals. `aligned`: each row holds its diagonal by column
// (dia_array, spdiags); otherwise values run along the diagonal from its start.
Sparse diagonals(const Mat &d, const Vec &off, size_t r, size_t c, bool aligned, bool scalarFill, const std::string &fmt) {
  std::vector<Triplet> t;
  for (size_t q = 0; q < off.size(); q++) {
    const long long k = static_cast<long long>(off[q]);
    const size_t startI = k < 0 ? static_cast<size_t>(-k) : 0, startJ = k > 0 ? static_cast<size_t>(k) : 0;
    for (size_t step = 0; startI + step < r && startJ + step < c; step++) {
      const size_t i = startI + step, j = startJ + step;
      double v;
      if (scalarFill)
        v = d.a[q];
      else if (aligned)
        v = j < d.c ? d(q, j) : 0.0;
      else
        v = step < d.c ? d(q, step) : 0.0;
      if (v != 0.0)
        t.push_back({i, j, v});
    }
  }
  return fromTriplets(r, c, std::move(t), fmt);
}

Sparse hstack(const std::vector<Sparse> &m, const std::string &fmt) {
  std::vector<Triplet> t;
  size_t off = 0, rows = m.empty() ? 0 : m[0].r;
  for (const Sparse &s : m) {
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        t.push_back({i, s.idx[k] + off, s.val[k]});
    off += s.c;
  }
  return fromTriplets(rows, off, std::move(t), fmt);
}
Sparse vstack(const std::vector<Sparse> &m, const std::string &fmt) {
  std::vector<Triplet> t;
  size_t off = 0, cols = m.empty() ? 0 : m[0].c;
  for (const Sparse &s : m) {
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        t.push_back({i + off, s.idx[k], s.val[k]});
    off += s.r;
  }
  return fromTriplets(off, cols, std::move(t), fmt);
}
Sparse kronecker(const Sparse &a, const Sparse &b) {
  std::vector<Triplet> t;
  for (size_t i = 0; i < a.r; i++)
    for (size_t k = a.ptr[i]; k < a.ptr[i + 1]; k++)
      for (size_t p = 0; p < b.r; p++)
        for (size_t q = b.ptr[p]; q < b.ptr[p + 1]; q++)
          t.push_back({i * b.r + p, a.idx[k] * b.c + b.idx[q], a.val[k] * b.val[q]});
  return fromTriplets(a.r * b.r, a.c * b.c, std::move(t));
}
Sparse identity(size_t n, size_t m, long long k, const std::string &fmt) {
  std::vector<Triplet> t;
  const size_t si = k < 0 ? static_cast<size_t>(-k) : 0, sj = k > 0 ? static_cast<size_t>(k) : 0;
  for (size_t s = 0; si + s < n && sj + s < m; s++)
    t.push_back({si + s, sj + s, 1.0});
  return fromTriplets(n, m, std::move(t), fmt);
}
Sparse triangle(const Sparse &s, long long k, bool lower) {
  std::vector<Triplet> t;
  for (size_t i = 0; i < s.r; i++)
    for (size_t q = s.ptr[i]; q < s.ptr[i + 1]; q++) {
      const long long d = static_cast<long long>(s.idx[q]) - static_cast<long long>(i);
      if (lower ? d <= k : d >= k)
        t.push_back({i, s.idx[q], s.val[q]});
    }
  return fromTriplets(s.r, s.c, std::move(t), s.fmt);
}

bool formatKnown(const std::string &f) {
  return f == "csr" || f == "csc" || f == "coo" || f == "bsr" || f == "dia" || f == "dok" || f == "lil";
}
const char kMagic[] = "NCSPARSE1";

} // namespace

void registerSparseMatrices(Registry &reg) {
  SP_ADD("sparse_csr", 1, 2, "data, shape") {
    Sparse s;
    return buildFrom(a, ctx, "csr", s) ? toValue(s) : Value(0.0);
  } SP_END
  SP_ADD("sparse_csc", 1, 2, "data, shape") {
    Sparse s;
    return buildFrom(a, ctx, "csc", s) ? toValue(s) : Value(0.0);
  } SP_END
  SP_ADD("sparse_coo", 1, 4, "values, rows, cols, shape  or  data") {
    if (a.size() == 1) {
      Sparse s;
      return buildFrom(a, ctx, "coo", s) ? toValue(s) : Value(0.0);
    }
    Vec v, ri, ci;
    if (!getVec(a, 0, ctx, v) || a.size() < 3 || !getVec(a, 1, ctx, ri) || !getVec(a, 2, ctx, ci)) {
      if (ctx.ok())
        ctx.fail("give values, rows and cols");
      return Value(0.0);
    }
    if (v.size() != ri.size() || v.size() != ci.size()) {
      ctx.fail("values, rows and cols must have the same length");
      return Value(0.0);
    }
    size_t r = 0, c = 0;
    if (a.size() > 3) {
      if (!getShape(a, 3, ctx, r, c))
        return Value(0.0);
    } else {
      for (size_t i = 0; i < v.size(); i++) {
        r = std::max(r, static_cast<size_t>(ri[i]) + 1);
        c = std::max(c, static_cast<size_t>(ci[i]) + 1);
      }
    }
    std::vector<Triplet> t;
    for (size_t i = 0; i < v.size(); i++) {
      if (ri[i] < 0 || ci[i] < 0 || ri[i] >= (double)r || ci[i] >= (double)c) {
        ctx.fail("a position lies outside the shape");
        return Value(0.0);
      }
      t.push_back({static_cast<size_t>(ri[i]), static_cast<size_t>(ci[i]), v[i]});
    }
    return toValue(fromTriplets(r, c, std::move(t), "coo"));
  } SP_END
  SP_ADD("sparse_bsr", 1, 2, "data, blocksize") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (a.size() > 1) {
      Vec b;
      if (!getVec(a, 1, ctx, b))
        return Value(0.0);
      if (b.size() != 2 || b[0] < 1 || b[1] < 1 || s.r % (size_t)b[0] != 0 || s.c % (size_t)b[1] != 0) {
        ctx.fail("blocksize [r, c] must divide the shape");
        return Value(0.0);
      }
    }
    s.fmt = "bsr";
    return toValue(s);
  } SP_END
  SP_ADD("sparse_dia", 3, 3, "diags, offsets, shape") {
    Mat d;
    Vec off;
    size_t r, c;
    if (!getMat(a, 0, ctx, d) || !getVec(a, 1, ctx, off) || !getShape(a, 2, ctx, r, c))
      return Value(0.0);
    if (d.r != off.size()) {
      ctx.fail("diags needs one row per offset");
      return Value(0.0);
    }
    return toValue(diagonals(d, off, r, c, true, false, "dia"));
  } SP_END
  SP_ADD("sparse_dok", 1, 1, "shape") {
    size_t r, c;
    if (!getShape(a, 0, ctx, r, c))
      return Value(0.0);
    return toValue(fromTriplets(r, c, {}, "dok"));
  } SP_END
  SP_ADD("sparse_lil", 1, 1, "shape") {
    size_t r, c;
    if (!getShape(a, 0, ctx, r, c))
      return Value(0.0);
    return toValue(fromTriplets(r, c, {}, "lil"));
  } SP_END
  SP_ADD("sparse_set", 4, 4, "M, i, j, value") {
    Sparse s;
    long long i, j;
    double v;
    if (!fromValue(a[0], s)) {
      ctx.fail("the first argument must be a sparse matrix");
      return Value(0.0);
    }
    if (!argNonNegativeInt(a, 1, ctx, i) || !argNonNegativeInt(a, 2, ctx, j) || !argNumber(a, 3, ctx, v))
      return Value(0.0);
    if ((size_t)i >= s.r || (size_t)j >= s.c) {
      ctx.fail("the position lies outside the matrix");
      return Value(0.0);
    }
    std::vector<Triplet> t;
    for (size_t p = 0; p < s.r; p++)
      for (size_t k = s.ptr[p]; k < s.ptr[p + 1]; k++)
        if (p != (size_t)i || s.idx[k] != (size_t)j)
          t.push_back({p, s.idx[k], s.val[k]});
    t.push_back({(size_t)i, (size_t)j, v});
    return toValue(fromTriplets(s.r, s.c, std::move(t), s.fmt));
  } SP_END
  SP_ADD("is_sparse", 1, 1, "x") { (void)ctx; return Value::boolean(isSparse(a[0])); } SP_ENDC
  SP_ADD("sparse_diags", 2, 4, "diags, offsets, shape, format=\"dia\"") {
    Mat d;
    Vec off;
    if (!getMat(a, 0, ctx, d) || !getVec(a, 1, ctx, off))
      return Value(0.0);
    const std::string fmt = optText(a, 3, "dia");
    const bool scalars = d.r <= 1 && d.a.size() == off.size() && off.size() >= 1;
    size_t r = 0, c = 0;
    if (a.size() > 2 && !a[2].isText) {
      if (!getShape(a, 2, ctx, r, c))
        return Value(0.0);
    } else {
      // The smallest square shape holding the first diagonal.
      const size_t len = scalars ? 1 : d.c;
      r = c = len + static_cast<size_t>(std::fabs(off.empty() ? 0.0 : off[0]));
    }
    if (!scalars && d.r != off.size()) {
      if (off.size() == 1 && d.r == 1) {
      } else {
        ctx.fail("give one value or one row of values per offset");
        return Value(0.0);
      }
    }
    if (off.size() == 1 && !scalars && a.size() < 3)
      r = c = d.c + static_cast<size_t>(std::fabs(off[0]));
    return toValue(diagonals(d, off, r, c, false, scalars, fmt));
  } SP_END
  SP_ADD("sparse_eye", 1, 4, "n, m, k=0, format=\"dia\"") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    const long long m = isNumberArg(a, 1) ? (long long)a[1].number : n;
    const std::string fmt = optText(a, 3, "dia");
    if (!formatKnown(fmt)) {
      ctx.fail("unknown format \"" + fmt + "\"");
      return Value(0.0);
    }
    return toValue(identity((size_t)n, (size_t)m, optInt(a, 2, 0), fmt));
  } SP_END
  SP_ADD("sparse_rand", 3, 4, "rows, cols, density, seed") {
    long long r, c;
    double den;
    if (!argNonNegativeInt(a, 0, ctx, r) || !argNonNegativeInt(a, 1, ctx, c) || !argNumber(a, 2, ctx, den))
      return Value(0.0);
    if (den < 0.0 || den > 1.0) {
      ctx.fail("density must lie between 0 and 1");
      return Value(0.0);
    }
    std::mt19937_64 gen = isNumberArg(a, 3) ? std::mt19937_64((unsigned long long)a[3].number) : std::mt19937_64(ncRandomEngine()());
    const size_t total = (size_t)r * (size_t)c, want = (size_t)std::llround(den * (double)total);
    std::vector<size_t> pos(total);
    for (size_t i = 0; i < total; i++)
      pos[i] = i;
    std::uniform_real_distribution<double> u;
    std::vector<Triplet> t;
    for (size_t k = 0; k < want; k++) {
      std::swap(pos[k], pos[k + gen() % (total - k)]);
      t.push_back({pos[k] / (size_t)c, pos[k] % (size_t)c, u(gen)});
    }
    return toValue(fromTriplets((size_t)r, (size_t)c, std::move(t), "coo"));
  } SP_END
  // A matrix literal cannot hold objects, so the grid is given by its size:
  // sparse_block(2, 2, S, 0, 0, S) stands for the table's [S, 0; 0, S].
  SP_ADD("sparse_block", 1, kVariadic, "rows, cols, b00, b01, ...  or  blocks") {
    if (a.size() == 1) {
      Sparse s;
      if (!getAny(a, 0, ctx, s))
        return Value(0.0);
      return toValue(s);
    }
    long long nr, nc;
    if (!argNonNegativeInt(a, 0, ctx, nr) || !argNonNegativeInt(a, 1, ctx, nc))
      return Value(0.0);
    if (a.size() != 2 + (size_t)(nr * nc)) {
      ctx.fail("give rows * cols blocks after the grid size; a 0 is an empty block");
      return Value(0.0);
    }
    std::vector<Sparse> bl((size_t)(nr * nc));
    std::vector<char> empty((size_t)(nr * nc), 0);
    Vec heights((size_t)nr, -1.0), widths((size_t)nc, -1.0);
    for (long long p = 0; p < nr; p++)
      for (long long q = 0; q < nc; q++) {
        const size_t i = (size_t)(p * nc + q);
        if (isPlainNumber(a[2 + i]) && a[2 + i].number == 0.0) {
          empty[i] = 1;
          continue;
        }
        if (!getAny(a, 2 + i, ctx, bl[i]))
          return Value(0.0);
        if ((heights[p] >= 0 && heights[p] != (double)bl[i].r) || (widths[q] >= 0 && widths[q] != (double)bl[i].c)) {
          ctx.fail("the blocks of a row or a column do not fit together");
          return Value(0.0);
        }
        heights[p] = (double)bl[i].r;
        widths[q] = (double)bl[i].c;
      }
    for (double v : heights)
      if (v < 0) {
        ctx.fail("a row of blocks is all empty, so its height is unknown");
        return Value(0.0);
      }
    for (double v : widths)
      if (v < 0) {
        ctx.fail("a column of blocks is all empty, so its width is unknown");
        return Value(0.0);
      }
    std::vector<Triplet> t;
    size_t r0 = 0, total = 0;
    for (double w : widths)
      total += (size_t)w;
    for (long long p = 0; p < nr; p++) {
      size_t c0 = 0;
      for (long long q = 0; q < nc; q++) {
        const size_t i = (size_t)(p * nc + q);
        if (!empty[i])
          for (size_t x = 0; x < bl[i].r; x++)
            for (size_t k = bl[i].ptr[x]; k < bl[i].ptr[x + 1]; k++)
              t.push_back({r0 + x, c0 + bl[i].idx[k], bl[i].val[k]});
        c0 += (size_t)widths[q];
      }
      r0 += (size_t)heights[p];
    }
    return toValue(fromTriplets(r0, total, std::move(t), "coo"));
  } SP_END
  SP_ADD("sparse_spdiags", 4, 4, "data, offsets, m, n") {
    Mat d;
    Vec off;
    long long m, n;
    if (!getMat(a, 0, ctx, d) || !getVec(a, 1, ctx, off) || !argNonNegativeInt(a, 2, ctx, m) || !argNonNegativeInt(a, 3, ctx, n))
      return Value(0.0);
    if (d.r != off.size()) {
      ctx.fail("data needs one row per offset");
      return Value(0.0);
    }
    return toValue(diagonals(d, off, (size_t)m, (size_t)n, true, false, "dia"));
  } SP_END
  SP_ADD("sparse_kron", 2, 2, "A, B") {
    Sparse x, y;
    if (!getAny(a, 0, ctx, x) || !getAny(a, 1, ctx, y))
      return Value(0.0);
    return toValue(kronecker(x, y));
  } SP_END
  SP_ADD("sparse_kronsum", 2, 2, "A, B") {
    Sparse x, y;
    if (!getAny(a, 0, ctx, x) || !getAny(a, 1, ctx, y))
      return Value(0.0);
    if (x.r != x.c || y.r != y.c) {
      ctx.fail("both matrices must be square");
      return Value(0.0);
    }
    // SciPy: kron(I_B, A) + kron(B, I_A)
    Sparse p = kronecker(identity(y.r, y.r, 0, "csr"), x), q = kronecker(y, identity(x.r, x.r, 0, "csr"));
    std::vector<Triplet> t;
    for (const Sparse *s : {&p, &q})
      for (size_t i = 0; i < s->r; i++)
        for (size_t k = s->ptr[i]; k < s->ptr[i + 1]; k++)
          t.push_back({i, s->idx[k], s->val[k]});
    return toValue(fromTriplets(p.r, p.c, std::move(t)));
  } SP_END
  SP_ADD("sparse_block_diag", 1, kVariadic, "A, B, ...") {
    std::vector<Triplet> t;
    size_t r0 = 0, c0 = 0;
    for (size_t b = 0; b < a.size(); b++) {
      Sparse s;
      if (!getAny(a, b, ctx, s))
        return Value(0.0);
      for (size_t i = 0; i < s.r; i++)
        for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
          t.push_back({r0 + i, c0 + s.idx[k], s.val[k]});
      r0 += s.r;
      c0 += s.c;
    }
    return toValue(fromTriplets(r0, c0, std::move(t), "coo"));
  } SP_END
  SP_ADD("sparse_hstack", 2, kVariadic, "A, B, ...") {
    std::vector<Sparse> m(a.size());
    for (size_t i = 0; i < a.size(); i++) {
      if (!getAny(a, i, ctx, m[i]))
        return Value(0.0);
      if (m[i].r != m[0].r) {
        ctx.fail("all matrices must have the same number of rows");
        return Value(0.0);
      }
    }
    return toValue(hstack(m, m[0].fmt));
  } SP_END
  SP_ADD("sparse_vstack", 2, kVariadic, "A, B, ...") {
    std::vector<Sparse> m(a.size());
    for (size_t i = 0; i < a.size(); i++) {
      if (!getAny(a, i, ctx, m[i]))
        return Value(0.0);
      if (m[i].c != m[0].c) {
        ctx.fail("all matrices must have the same number of columns");
        return Value(0.0);
      }
    }
    return toValue(vstack(m, m[0].fmt));
  } SP_END
  SP_ADD("sparse_tril", 1, 2, "A, k=0") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    return toValue(triangle(s, optInt(a, 1, 0), true));
  } SP_END
  SP_ADD("sparse_triu", 1, 2, "A, k=0") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    return toValue(triangle(s, optInt(a, 1, 0), false));
  } SP_END
  SP_ADD("sparse_find", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    Vec ri, ci, v;
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        if (s.val[k] != 0.0) {
          ri.push_back((double)i);
          ci.push_back((double)s.idx[k]);
          v.push_back(s.val[k]);
        }
    return makeDict({{"rows", toValue(ri)}, {"cols", toValue(ci)}, {"values", toValue(v)}});
  } SP_END
  SP_ADD("sparse_transpose", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    return toValue(transpose(s));
  } SP_END
  SP_ADD("sparse_save", 2, 2, "file, A") {
    std::string file;
    Sparse s;
    if (!argText(a, 0, ctx, file) || !getAny(a, 1, ctx, s))
      return Value(0.0);
    std::ofstream f(file, std::ios::binary);
    if (!f) {
      ctx.fail("cannot write \"" + file + "\"");
      return Value(0.0);
    }
    auto u64 = [&](unsigned long long v) { f.write(reinterpret_cast<const char *>(&v), 8); };
    f.write(kMagic, 9);
    u64(s.r);
    u64(s.c);
    u64(s.nnz());
    u64(s.fmt.size());
    f.write(s.fmt.data(), (std::streamsize)s.fmt.size());
    for (size_t p : s.ptr)
      u64(p);
    for (size_t p : s.idx)
      u64(p);
    f.write(reinterpret_cast<const char *>(s.val.data()), (std::streamsize)(s.val.size() * 8));
    return Value(0.0);
  } SP_END
  SP_ADD("sparse_load", 1, 1, "file") {
    std::string file;
    if (!argText(a, 0, ctx, file))
      return Value(0.0);
    std::ifstream f(file, std::ios::binary);
    char magic[9] = {0};
    if (!f || !f.read(magic, 9) || std::string(magic, 9) != std::string(kMagic, 9)) {
      ctx.fail("\"" + file + "\" is not a file written by sparse_save()");
      return Value(0.0);
    }
    auto u64 = [&]() {
      unsigned long long v = 0;
      f.read(reinterpret_cast<char *>(&v), 8);
      return static_cast<size_t>(v);
    };
    Sparse s;
    s.r = u64();
    s.c = u64();
    const size_t nnz = u64(), fl = u64();
    s.fmt.resize(fl);
    f.read(&s.fmt[0], (std::streamsize)fl);
    s.ptr.resize(s.r + 1);
    for (size_t &p : s.ptr)
      p = u64();
    s.idx.resize(nnz);
    for (size_t &p : s.idx)
      p = u64();
    s.val.resize(nnz);
    f.read(reinterpret_cast<char *>(s.val.data()), (std::streamsize)(nnz * 8));
    if (!f) {
      ctx.fail("\"" + file + "\" is cut short");
      return Value(0.0);
    }
    return toValue(s);
  } SP_END
  SP_ADD("sparse_format", 1, 1, "A") {
    Sparse s;
    if (!fromValue(a[0], s)) {
      ctx.fail("the argument must be a sparse matrix");
      return Value(0.0);
    }
    return Value(s.fmt);
  } SP_END
  SP_ADD("sparse_to_dense", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    return scipy::toValue(toDense(s));
  } SP_END
  SP_ADD("sparse_convert", 2, 2, "A, format") {
    Sparse s;
    std::string fmt;
    if (!getAny(a, 0, ctx, s) || !argText(a, 1, ctx, fmt))
      return Value(0.0);
    if (!formatKnown(fmt)) {
      ctx.fail("unknown format \"" + fmt + "\"");
      return Value(0.0);
    }
    s.fmt = fmt;
    return toValue(s);
  } SP_END
  SP_ADD("sparse_info", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    const Sparse v = s.fmt == "csc" ? transpose(s) : s;
    IVec in(v.idx.begin(), v.idx.end()), ip(v.ptr.begin(), v.ptr.end());
    return makeDict({{"nnz", Value((double)s.nnz())}, {"data", scipy::toValue(v.val)}, {"indices", scipy::toValue(in)}, {"indptr", scipy::toValue(ip)}});
  } SP_END
  SP_ADD("sparse_sum", 1, 2, "A, axis") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (!isNumberArg(a, 1)) {
      double t = 0.0;
      for (double v : s.val)
        t += v;
      return Value(t);
    }
    const bool rows = a[1].number == 1.0;
    Vec o(rows ? s.r : s.c, 0.0);
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        o[rows ? i : s.idx[k]] += s.val[k];
    return toValue(o);
  } SP_END
  SP_ADD("sparse_max", 1, 2, "A, axis") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (!isNumberArg(a, 1)) {
      double t = s.nnz() < s.r * s.c ? 0.0 : -kInf;
      for (double v : s.val)
        t = std::max(t, v);
      return Value(t);
    }
    Mat D = toDense(s);
    const bool rows = a[1].number == 1.0;
    Vec o(rows ? s.r : s.c, -kInf);
    for (size_t i = 0; i < s.r; i++)
      for (size_t j = 0; j < s.c; j++) {
        double &slot = o[rows ? i : j];
        slot = std::max(slot, D(i, j));
      }
    return toValue(o);
  } SP_END
  SP_ADD("sparse_power", 2, 2, "A, p") {
    Sparse s;
    double p;
    if (!getAny(a, 0, ctx, s) || !argNumber(a, 1, ctx, p))
      return Value(0.0);
    for (double &v : s.val)
      v = std::pow(v, p);
    return toValue(s);
  } SP_END
  SP_ADD("sparse_prune", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    std::vector<Triplet> t;
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        t.push_back({i, s.idx[k], s.val[k]});
    return toValue(fromTriplets(s.r, s.c, std::move(t), s.fmt));
  } SP_END
  SP_ADD("sparse_sort_indices", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    std::vector<Triplet> t;
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        t.push_back({i, s.idx[k], s.val[k]});
    return toValue(fromTriplets(s.r, s.c, std::move(t), s.fmt, true));
  } SP_END
  SP_ADD("sparse_nnz", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    size_t n = 0;
    for (double v : s.val)
      n += v != 0.0;
    return Value((double)n);
  } SP_END
  reg.setParallel({"sparse_mul"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
