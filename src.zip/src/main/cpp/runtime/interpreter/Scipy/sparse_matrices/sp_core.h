// The Sparse value and the kernels on it. In NC a Sparse is an object of class
// NcSparse with the fields shape, format, data, indices and indptr; the numbers
// are always held as compressed rows (CSR) and `format` records which storage
// the script asked for, so every format behaves the same.
#ifndef NC_SCIPY_SP_CORE_H
#define NC_SCIPY_SP_CORE_H

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace sp {

struct Sparse {
  size_t r = 0, c = 0;
  std::vector<size_t> ptr{0};
  std::vector<size_t> idx;
  Vec val;
  std::string fmt = "csr";
  size_t nnz() const { return val.size(); }
  void reserveRows() { ptr.assign(r + 1, 0); }
};

bool isSparse(const Value &v);
Value toValue(const Sparse &s);
bool fromValue(const Value &v, Sparse &s);
Sparse fromDense(const Mat &m, const std::string &fmt = "csr");
Mat toDense(const Sparse &s);
struct Triplet {
  size_t i, j;
  double v;
};
// Sorted; duplicates add up. Explicit zeros stay when keepZeros is set.
Sparse fromTriplets(size_t r, size_t c, std::vector<Triplet> t, const std::string &fmt = "csr", bool keepZeros = false);
Sparse transpose(const Sparse &s);
Vec mulVec(const Sparse &s, const Vec &x);
Vec mulVecT(const Sparse &s, const Vec &x); // A' x
Sparse mulSparse(const Sparse &a, const Sparse &b);
// Sparse, or a dense matrix read as one: the "Sparse or Matrix" inputs.
bool readAny(const Value &v, Sparse &s);
bool getAny(const Args &a, size_t i, CallContext &ctx, Sparse &s);

// A left-looking LU with partial pivoting: L U = A(perm_r, perm_c) (lower has unit diagonal).
struct SparseLU {
  Sparse L, U;
  std::vector<size_t> permR, permC;
  bool singular = false;
};
SparseLU sparseLU(const Sparse &A, double dropTol = 0.0);
Vec luSolve(const SparseLU &f, const Vec &b);

} // namespace sp
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SP_CORE_H
