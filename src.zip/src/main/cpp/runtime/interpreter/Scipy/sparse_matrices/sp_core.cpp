#include "sp_core.h"

namespace nc {
namespace scipy {
namespace sp {

bool isSparse(const Value &v) { return v.isObject && v.className() == "NcSparse"; }

namespace {
template <class C> Value ints(const C &c) {
  std::vector<Value> row;
  row.reserve(c.size());
  for (auto x : c)
    row.push_back(Value(static_cast<double>(x)));
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}
} // namespace

Value toValue(const Sparse &s) {
  Value o;
  o.isObject = true;
  o.classNameMut() = "NcSparse";
  auto &d = o.dictMut();
  d.emplace("shape", scipy::toValue(Vec{static_cast<double>(s.r), static_cast<double>(s.c)}));
  d.emplace("format", Value(s.fmt));
  d.emplace("data", scipy::toValue(s.val));
  d.emplace("indices", ints(s.idx));
  d.emplace("indptr", ints(s.ptr));
  d.emplace("nnz", Value(static_cast<double>(s.nnz())));
  return o;
}

bool fromValue(const Value &v, Sparse &s) {
  if (!isSparse(v))
    return false;
  const Value *sh = dictGet(v, "shape"), *f = dictGet(v, "format"), *da = dictGet(v, "data"), *in = dictGet(v, "indices"), *ip = dictGet(v, "indptr");
  Vec shape, ind, ptr;
  if (!sh || !f || !da || !in || !ip || !readVec(*sh, shape) || shape.size() != 2 || !readVec(*da, s.val) || !readVec(*in, ind) || !readVec(*ip, ptr))
    return false;
  s.r = static_cast<size_t>(shape[0]);
  s.c = static_cast<size_t>(shape[1]);
  s.fmt = f->text();
  s.idx.resize(ind.size());
  for (size_t i = 0; i < ind.size(); i++)
    s.idx[i] = static_cast<size_t>(ind[i]);
  s.ptr.resize(ptr.size());
  for (size_t i = 0; i < ptr.size(); i++)
    s.ptr[i] = static_cast<size_t>(ptr[i]);
  return s.ptr.size() == s.r + 1;
}

Sparse fromDense(const Mat &m, const std::string &fmt) {
  Sparse s;
  s.r = m.r;
  s.c = m.c;
  s.fmt = fmt;
  s.ptr.assign(m.r + 1, 0);
  for (size_t i = 0; i < m.r; i++) {
    for (size_t j = 0; j < m.c; j++)
      if (m(i, j) != 0.0) {
        s.idx.push_back(j);
        s.val.push_back(m(i, j));
      }
    s.ptr[i + 1] = s.val.size();
  }
  return s;
}

Mat toDense(const Sparse &s) {
  Mat m(s.r, s.c);
  for (size_t i = 0; i < s.r; i++)
    for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
      m(i, s.idx[k]) += s.val[k];
  return m;
}

Sparse fromTriplets(size_t r, size_t c, std::vector<Triplet> t, const std::string &fmt, bool keepZeros) {
  std::stable_sort(t.begin(), t.end(), [](const Triplet &a, const Triplet &b) {
    return a.i != b.i ? a.i < b.i : a.j < b.j;
  });
  Sparse s;
  s.r = r;
  s.c = c;
  s.fmt = fmt;
  s.ptr.assign(r + 1, 0);
  size_t k = 0;
  for (size_t i = 0; i < r; i++) {
    while (k < t.size() && t[k].i == i) {
      size_t j = t[k].j;
      double v = 0.0;
      while (k < t.size() && t[k].i == i && t[k].j == j)
        v += t[k++].v;
      if (v != 0.0 || keepZeros) {
        s.idx.push_back(j);
        s.val.push_back(v);
      }
    }
    s.ptr[i + 1] = s.val.size();
  }
  return s;
}

Sparse transpose(const Sparse &s) {
  Sparse t;
  t.r = s.c;
  t.c = s.r;
  t.fmt = s.fmt;
  t.ptr.assign(t.r + 1, 0);
  for (size_t j : s.idx)
    t.ptr[j + 1]++;
  for (size_t i = 0; i < t.r; i++)
    t.ptr[i + 1] += t.ptr[i];
  t.idx.resize(s.nnz());
  t.val.resize(s.nnz());
  std::vector<size_t> next(t.ptr.begin(), t.ptr.end() - 1);
  for (size_t i = 0; i < s.r; i++)
    for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++) {
      const size_t pos = next[s.idx[k]]++;
      t.idx[pos] = i;
      t.val[pos] = s.val[k];
    }
  return t;
}

Vec mulVec(const Sparse &s, const Vec &x) {
  Vec y(s.r, 0.0);
  par::forBlocks(s.r, {par::Kind::Compute, 30.0}, [&](size_t b, size_t e) {
    for (size_t i = b; i < e; i++) {
      double t = 0.0;
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
        t += s.val[k] * x[s.idx[k]];
      y[i] = t;
    }
  });
  return y;
}

Vec mulVecT(const Sparse &s, const Vec &x) {
  Vec y(s.c, 0.0);
  for (size_t i = 0; i < s.r; i++)
    for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
      y[s.idx[k]] += s.val[k] * x[i];
  return y;
}

Sparse mulSparse(const Sparse &a, const Sparse &b) {
  std::vector<Triplet> t;
  Vec work(b.c, 0.0);
  std::vector<size_t> touched;
  std::vector<char> seen(b.c, 0);
  for (size_t i = 0; i < a.r; i++) {
    touched.clear();
    for (size_t k = a.ptr[i]; k < a.ptr[i + 1]; k++) {
      const size_t m = a.idx[k];
      for (size_t q = b.ptr[m]; q < b.ptr[m + 1]; q++) {
        const size_t j = b.idx[q];
        if (!seen[j]) {
          seen[j] = 1;
          touched.push_back(j);
        }
        work[j] += a.val[k] * b.val[q];
      }
    }
    for (size_t j : touched) {
      t.push_back({i, j, work[j]});
      work[j] = 0.0;
      seen[j] = 0;
    }
  }
  return fromTriplets(a.r, b.c, std::move(t), a.fmt);
}

bool readAny(const Value &v, Sparse &s) {
  if (fromValue(v, s))
    return true;
  Mat m;
  if (!readMat(v, m))
    return false;
  s = fromDense(m);
  return true;
}

bool getAny(const Args &a, size_t i, CallContext &ctx, Sparse &s) {
  if (i >= a.size() || !readAny(a[i], s)) {
    ctx.fail("the " + ordinal(i) + " argument must be a sparse matrix or a matrix of numbers");
    return false;
  }
  return true;
}

SparseLU sparseLU(const Sparse &A, double dropTol) {
  // Left-looking over the columns of A, with partial pivoting on the rows.
  const size_t n = A.r;
  SparseLU f;
  Sparse At = transpose(A); // columns of A as rows of At
  f.permR.assign(n, n);     // row -> pivot position
  f.permC.resize(n);
  for (size_t j = 0; j < n; j++)
    f.permC[j] = j;
  std::vector<std::vector<std::pair<size_t, double>>> Lc(n), Uc(n); // by column; L rows are original rows
  Vec x(n, 0.0);
  std::vector<char> mark(n, 0);
  std::vector<size_t> pattern;
  for (size_t j = 0; j < n; j++) {
    pattern.clear();
    for (size_t k = At.ptr[j]; k < At.ptr[j + 1]; k++) {
      x[At.idx[k]] = At.val[k];
      if (!mark[At.idx[k]]) {
        mark[At.idx[k]] = 1;
        pattern.push_back(At.idx[k]);
      }
    }
    // Pivots applied in order; the rows already pivoted form the U part.
    std::vector<size_t> doneRows;
    for (size_t idx = 0; idx < pattern.size(); idx++)
      if (f.permR[pattern[idx]] < j)
        doneRows.push_back(pattern[idx]);
    std::sort(doneRows.begin(), doneRows.end(), [&](size_t p, size_t q) { return f.permR[p] < f.permR[q]; });
    std::vector<std::pair<size_t, size_t>> heap;
    for (size_t r : doneRows)
      heap.push_back({f.permR[r], r});
    std::make_heap(heap.begin(), heap.end(), std::greater<std::pair<size_t, size_t>>());
    while (!heap.empty()) {
      std::pop_heap(heap.begin(), heap.end(), std::greater<std::pair<size_t, size_t>>());
      const size_t pos = heap.back().first, r = heap.back().second;
      heap.pop_back();
      const double v = x[r];
      if (v == 0.0)
        continue;
      for (const auto &e : Lc[pos]) {
        const size_t rr = e.first;
        if (!mark[rr]) {
          mark[rr] = 1;
          pattern.push_back(rr);
          if (f.permR[rr] < j) {
            heap.push_back({f.permR[rr], rr});
            std::push_heap(heap.begin(), heap.end(), std::greater<std::pair<size_t, size_t>>());
          }
        }
        x[rr] -= e.second * v;
      }
    }
    // Pick the pivot among the rows not used yet.
    double best = 0.0;
    size_t pr = n;
    for (size_t r : pattern)
      if (f.permR[r] == n && std::fabs(x[r]) > best) {
        best = std::fabs(x[r]);
        pr = r;
      }
    if (pr == n) {
      f.singular = true;
      for (size_t r : pattern) {
        x[r] = 0.0;
        mark[r] = 0;
      }
      return f;
    }
    f.permR[pr] = j;
    const double piv = x[pr];
    for (size_t r : pattern) {
      const double v = x[r];
      if (f.permR[r] < j) {
        if (f.permR[r] != j && (dropTol == 0.0 || std::fabs(v) > dropTol))
          Uc[j].push_back({f.permR[r], v});
      } else if (r == pr) {
        Uc[j].push_back({j, piv});
      } else if (f.permR[r] == n && v != 0.0 && (dropTol == 0.0 || std::fabs(v / piv) > dropTol)) {
        Lc[j].push_back({r, v / piv});
      }
      x[r] = 0.0;
      mark[r] = 0;
    }
  }
  std::vector<Triplet> tl, tu;
  for (size_t j = 0; j < n; j++) {
    tl.push_back({j, j, 1.0});
    for (const auto &e : Lc[j])
      tl.push_back({f.permR[e.first], j, e.second});
    for (const auto &e : Uc[j])
      tu.push_back({e.first, j, e.second});
  }
  f.L = fromTriplets(n, n, std::move(tl), "csc");
  f.U = fromTriplets(n, n, std::move(tu), "csc");
  return f;
}

Vec luSolve(const SparseLU &f, const Vec &b) {
  const size_t n = b.size();
  Vec y(n, 0.0);
  for (size_t i = 0; i < n; i++)
    y[f.permR[i]] = b[i];
  for (size_t i = 0; i < n; i++) {
    double s = y[i];
    for (size_t k = f.L.ptr[i]; k < f.L.ptr[i + 1]; k++)
      if (f.L.idx[k] < i)
        s -= f.L.val[k] * y[f.L.idx[k]];
    y[i] = s;
  }
  for (size_t i = n; i-- > 0;) {
    double s = y[i], d = 1.0;
    for (size_t k = f.U.ptr[i]; k < f.U.ptr[i + 1]; k++) {
      if (f.U.idx[k] > i)
        s -= f.U.val[k] * y[f.U.idx[k]];
      else if (f.U.idx[k] == i)
        d = f.U.val[k];
    }
    y[i] = s / d;
  }
  Vec x(n);
  for (size_t j = 0; j < n; j++)
    x[f.permC[j]] = y[j];
  return x;
}

} // namespace sp
} // namespace scipy
} // namespace nc
