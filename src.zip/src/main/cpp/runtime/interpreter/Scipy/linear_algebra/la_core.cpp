#include "la_core.h"

namespace nc {
namespace scipy {
namespace la {

// Implicit single-shift QR on a complex Hessenberg matrix, accumulating Z.
void complexSchur(const CMat &A, CMat &T_, CMat &Z) {
  const size_t n = A.r;
  hessenberg(A, T_, Z);
  if (n == 0)
    return;
  long hi = static_cast<long>(n) - 1;
  int iter = 0;
  while (hi > 0) {
    long l = hi;
    for (; l > 0; l--) {
      double sub = std::abs(T_(l, l - 1));
      double scale = std::abs(T_(l, l)) + std::abs(T_(l - 1, l - 1));
      if (scale == 0.0)
        scale = frobenius(T_);
      if (sub <= kEps * scale) {
        T_(l, l - 1) = 0.0;
        break;
      }
    }
    if (l == hi) {
      hi--;
      iter = 0;
      continue;
    }
    iter++;
    if (iter > 300)
      break;
    // Wilkinson shift, with an exceptional shift now and then.
    cd a = T_(hi - 1, hi - 1), b = T_(hi - 1, hi), c = T_(hi, hi - 1), d = T_(hi, hi);
    cd tr = a + d, dt = a * d - b * c;
    cd disc = std::sqrt(tr * tr / 4.0 - dt);
    cd e1 = tr / 2.0 + disc, e2 = tr / 2.0 - disc;
    cd shift = std::abs(e1 - d) < std::abs(e2 - d) ? e1 : e2;
    if (iter % 30 == 0)
      shift = T_(hi, hi) + cd(std::abs(T_(hi, hi - 1)), 0.0);
    std::vector<std::pair<double, cd>> rot(hi - l);
    for (long k = l; k <= hi; k++)
      T_(k, k) -= shift;
    for (long k = l; k < hi; k++) {
      cd x = T_(k, k), y = T_(k + 1, k);
      double r = std::hypot(std::abs(x), std::abs(y));
      double cs;
      cd sn;
      if (r == 0.0) {
        cs = 1.0;
        sn = 0.0;
      } else if (std::abs(x) == 0.0) {
        cs = 0.0;
        sn = std::conj(y) / std::abs(y);
      } else {
        cs = std::abs(x) / r;
        sn = (x / std::abs(x)) * std::conj(y) / r;
      }
      rot[k - l] = {cs, sn};
      for (size_t j = k; j < n; j++) {
        cd u = T_(k, j), v = T_(k + 1, j);
        T_(k, j) = cs * u + sn * v;
        T_(k + 1, j) = -std::conj(sn) * u + cs * v;
      }
    }
    for (long k = l; k < hi; k++) {
      double cs = rot[k - l].first;
      cd sn = rot[k - l].second;
      for (long i = 0; i <= std::min(k + 1, hi); i++) {
        cd u = T_(i, k), v = T_(i, k + 1);
        T_(i, k) = cs * u + std::conj(sn) * v;
        T_(i, k + 1) = -sn * u + cs * v;
      }
      for (size_t i = 0; i < n; i++) {
        cd u = Z(i, k), v = Z(i, k + 1);
        Z(i, k) = cs * u + std::conj(sn) * v;
        Z(i, k + 1) = -sn * u + cs * v;
      }
    }
    for (long k = l; k <= hi; k++)
      T_(k, k) += shift;
  }
  for (size_t i = 1; i < n; i++)
    for (size_t j = 0; j < i; j++)
      T_(i, j) = 0.0;
}

namespace {
// Applies the 3-vector Householder of Francis' step to rows/columns k..k+2.
void applyFrancis(Mat &H, Mat &Z, size_t n, long k, const double *v, int len, long lo, long hi) {
  double vv = 0.0;
  for (int i = 0; i < len; i++)
    vv += v[i] * v[i];
  if (vv == 0.0)
    return;
  double beta = 2.0 / vv;
  for (size_t j = (k > lo ? k - 1 : k); j < n; j++) {
    double s = 0.0;
    for (int i = 0; i < len; i++)
      s += v[i] * H(k + i, j);
    s *= beta;
    for (int i = 0; i < len; i++)
      H(k + i, j) -= s * v[i];
  }
  long top = std::min(k + 3, hi);
  for (long r = 0; r <= top; r++) {
    double s = 0.0;
    for (int i = 0; i < len; i++)
      s += H(r, k + i) * v[i];
    s *= beta;
    for (int i = 0; i < len; i++)
      H(r, k + i) -= s * v[i];
  }
  for (size_t r = 0; r < n; r++) {
    double s = 0.0;
    for (int i = 0; i < len; i++)
      s += Z(r, k + i) * v[i];
    s *= beta;
    for (int i = 0; i < len; i++)
      Z(r, k + i) -= s * v[i];
  }
}

// Rotates the 2x2 block at p so it is upper triangular when its eigenvalues
// are real; otherwise makes the diagonal equal (the standard form).
void standardizeBlock(Mat &T_, Mat &Z, size_t p) {
  const size_t n = T_.r;
  double a = T_(p, p), b = T_(p, p + 1), c = T_(p + 1, p), d = T_(p + 1, p + 1);
  double cs, sn;
  if (c == 0.0)
    return;
  double half = (a - d) / 2.0, disc = half * half + b * c;
  if (disc >= 0.0) {
    double z = half + (half >= 0 ? 1.0 : -1.0) * std::sqrt(disc);
    double r = std::hypot(z, c);
    cs = z / r;
    sn = c / r;
  } else {
    // a' - d' = (a - d) cos 2t + (b + c) sin 2t = 0
    const double t = 0.5 * std::atan2(d - a, b + c);
    cs = std::cos(t);
    sn = std::sin(t);
  }
  for (size_t j = 0; j < n; j++) {
    double u = T_(p, j), v = T_(p + 1, j);
    T_(p, j) = cs * u + sn * v;
    T_(p + 1, j) = -sn * u + cs * v;
  }
  for (size_t i = 0; i < n; i++) {
    double u = T_(i, p), v = T_(i, p + 1);
    T_(i, p) = cs * u + sn * v;
    T_(i, p + 1) = -sn * u + cs * v;
    u = Z(i, p);
    v = Z(i, p + 1);
    Z(i, p) = cs * u + sn * v;
    Z(i, p + 1) = -sn * u + cs * v;
  }
  if (disc >= 0.0)
    T_(p + 1, p) = 0.0;
}
} // namespace

// Francis double-shift QR.
void realSchur(const Mat &A, Mat &T_, Mat &Z) {
  const size_t n = A.r;
  hessenberg(A, T_, Z);
  if (n < 2)
    return;
  long hi = static_cast<long>(n) - 1;
  int iter = 0;
  while (hi > 0) {
    long l = hi;
    for (; l > 0; l--) {
      double s = std::fabs(T_(l - 1, l - 1)) + std::fabs(T_(l, l));
      if (s == 0.0)
        s = frobenius(T_);
      if (std::fabs(T_(l, l - 1)) <= kEps * s) {
        T_(l, l - 1) = 0.0;
        break;
      }
    }
    if (l == hi) {
      hi--;
      iter = 0;
      continue;
    }
    if (l == hi - 1) {
      standardizeBlock(T_, Z, static_cast<size_t>(l));
      hi -= 2;
      iter = 0;
      continue;
    }
    iter++;
    if (iter > 300)
      break;
    double s = T_(hi - 1, hi - 1) + T_(hi, hi);
    double t = T_(hi - 1, hi - 1) * T_(hi, hi) - T_(hi - 1, hi) * T_(hi, hi - 1);
    if (iter % 20 == 0) {
      double w = std::fabs(T_(hi, hi - 1)) + std::fabs(T_(hi - 1, hi - 2));
      s = 1.5 * w;
      t = w * w;
    }
    double x = T_(l, l) * T_(l, l) + T_(l, l + 1) * T_(l + 1, l) - s * T_(l, l) + t;
    double y = T_(l + 1, l) * (T_(l, l) + T_(l + 1, l + 1) - s);
    double z = T_(l + 1, l) * T_(l + 2, l + 1);
    for (long k = l; k <= hi - 2; k++) {
      double v[3] = {x, y, z};
      double norm = std::sqrt(x * x + y * y + z * z);
      if (norm != 0.0) {
        v[0] += x >= 0 ? norm : -norm;
        applyFrancis(T_, Z, n, k, v, 3, l, hi);
        if (k > l) {
          T_(k + 1, k - 1) = 0.0;
          T_(k + 2, k - 1) = 0.0;
        }
      }
      x = T_(k + 1, k);
      y = T_(k + 2, k);
      z = k < hi - 2 ? T_(k + 3, k) : 0.0;
    }
    double v[2] = {x, y};
    double norm = std::hypot(x, y);
    if (norm != 0.0) {
      v[0] += x >= 0 ? norm : -norm;
      applyFrancis(T_, Z, n, hi - 1, v, 2, l, hi);
      T_(hi, hi - 2) = 0.0;
    }
  }
  for (size_t i = 2; i < n; i++)
    for (size_t j = 0; j + 1 < i; j++)
      T_(i, j) = 0.0;
}

void eigGeneral(const CMat &A, CVec &w, CMat *V) {
  CMat T_, Z;
  complexSchur(A, T_, Z);
  const size_t n = A.r;
  w.resize(n);
  for (size_t i = 0; i < n; i++)
    w[i] = T_(i, i);
  if (!V)
    return;
  const double norm = std::max(frobenius(T_), 1e-300);
  CMat X(n, n);
  for (size_t k = 0; k < n; k++) {
    X(k, k) = 1.0;
    for (size_t ii = k; ii-- > 0;) {
      cd s = 0.0;
      for (size_t j = ii + 1; j <= k; j++)
        s += T_(ii, j) * X(j, k);
      cd d = T_(ii, ii) - T_(k, k);
      if (std::abs(d) < kEps * norm)
        d = kEps * norm;
      X(ii, k) = -s / d;
    }
  }
  *V = mul(Z, X);
  for (size_t k = 0; k < n; k++) {
    double t = 0.0;
    for (size_t i = 0; i < n; i++)
      t += std::norm((*V)(i, k));
    t = std::sqrt(t);
    if (t > 0.0)
      for (size_t i = 0; i < n; i++)
        (*V)(i, k) /= t;
  }
}

namespace {
struct Givens {
  double c;
  cd s;
};
// c, s with [c s; -conj(s) c] [x; y] = [r; 0]
Givens zeroLower(const cd &x, const cd &y) {
  double r = std::hypot(std::abs(x), std::abs(y));
  if (r == 0.0)
    return {1.0, 0.0};
  if (std::abs(x) == 0.0)
    return {0.0, std::conj(y) / std::abs(y)};
  return {std::abs(x) / r, (x / std::abs(x)) * std::conj(y) / r};
}
void rowRot(CMat &M, const Givens &g, size_t p, size_t q, size_t from) {
  for (size_t j = from; j < M.c; j++) {
    cd u = M(p, j), v = M(q, j);
    M(p, j) = g.c * u + g.s * v;
    M(q, j) = -std::conj(g.s) * u + g.c * v;
  }
}
// Multiplies column p, q from the right by the adjoint of the row rotation.
void colRotAdj(CMat &M, const Givens &g, size_t p, size_t q, size_t rows) {
  for (size_t i = 0; i < rows; i++) {
    cd u = M(i, p), v = M(i, q);
    M(i, p) = g.c * u + std::conj(g.s) * v;
    M(i, q) = -g.s * u + g.c * v;
  }
}
// c, s for a column rotation zeroing x in [x y] (entry at column p).
Givens zeroLeft(const cd &x, const cd &y) {
  // The first result of colRotL is c x - conj(s) y, which must be 0.
  double r = std::hypot(std::abs(x), std::abs(y));
  if (r == 0.0)
    return {1.0, 0.0};
  if (std::abs(y) == 0.0)
    return {0.0, 1.0};
  double c = std::abs(y) / r;
  cd s = (y / std::abs(y)) * std::conj(x) / r;
  return {c, s};
}
void colRotL(CMat &M, const Givens &g, size_t p, size_t q, size_t rows) {
  for (size_t i = 0; i < rows; i++) {
    cd u = M(i, p), v = M(i, q);
    M(i, p) = g.c * u - std::conj(g.s) * v;
    M(i, q) = g.s * u + g.c * v;
  }
}
} // namespace

// Single-shift complex QZ (Golub and Van Loan, 7.7) with Wilkinson shifts.
void complexQZ(const CMat &Ain, const CMat &Bin, CMat &AA, CMat &BB, CMat &Q, CMat &Z) {
  const size_t n = Ain.r;
  CMat Q0, R0;
  qrFactor(Bin, Q0, R0);
  AA = mul(adjointOf(Q0), Ain);
  BB = R0;
  Q = Q0;
  Z = CMat::eye(n);
  // Hessenberg-triangular reduction.
  for (size_t j = 0; j + 2 < n; j++)
    for (size_t i = n - 1; i > j + 1; i--) {
      Givens g = zeroLower(AA(i - 1, j), AA(i, j));
      rowRot(AA, g, i - 1, i, j);
      rowRot(BB, g, i - 1, i, i - 1);
      colRotAdj(Q, g, i - 1, i, n);
      AA(i, j) = 0.0;
      Givens h = zeroLeft(BB(i, i - 1), BB(i, i));
      colRotL(BB, h, i - 1, i, i + 1);
      colRotL(AA, h, i - 1, i, n);
      colRotL(Z, h, i - 1, i, n);
      BB(i, i - 1) = 0.0;
    }
  const double na = std::max(frobenius(AA), 1e-300), nb = std::max(frobenius(BB), 1e-300);
  long hi = static_cast<long>(n) - 1;
  int iter = 0, total = 0;
  const int maxTotal = 60 * static_cast<int>(n) + 60;
  while (hi > 0 && total < maxTotal) {
    if (std::abs(AA(hi, hi - 1)) <= kEps * na) {
      AA(hi, hi - 1) = 0.0;
      hi--;
      iter = 0;
      continue;
    }
    if (std::abs(BB(hi, hi)) <= kEps * nb) {
      // Infinite eigenvalue: push the zero of B out at the bottom.
      BB(hi, hi) = 0.0;
      Givens h = zeroLeft(AA(hi, hi - 1), AA(hi, hi));
      colRotL(AA, h, hi - 1, hi, hi + 1);
      colRotL(BB, h, hi - 1, hi, hi);
      colRotL(Z, h, hi - 1, hi, n);
      AA(hi, hi - 1) = 0.0;
      hi--;
      iter = 0;
      continue;
    }
    long l = hi;
    while (l > 0 && std::abs(AA(l, l - 1)) > kEps * na)
      l--;
    if (l > 0)
      AA(l, l - 1) = 0.0;
    // A zero on the diagonal of B inside the block: chase it down to row hi,
    // where the step above deflates it (Golub and Van Loan, 7.7.5).
    long zk = -1;
    for (long k = l; k < hi; k++)
      if (std::abs(BB(k, k)) <= kEps * nb) {
        zk = k;
        break;
      }
    if (zk >= 0) {
      BB(zk, zk) = 0.0;
      for (long k = zk; k < hi; k++) {
        Givens g = zeroLower(BB(k, k + 1), BB(k + 1, k + 1));
        rowRot(BB, g, k, k + 1, k + 1);
        rowRot(AA, g, k, k + 1, k > l ? k - 1 : k);
        colRotAdj(Q, g, k, k + 1, n);
        BB(k + 1, k + 1) = 0.0;
        if (k > l) { // remove the fill-in A(k+1, k-1) with a column rotation
          Givens h = zeroLeft(AA(k + 1, k - 1), AA(k + 1, k));
          colRotL(AA, h, k - 1, k, n);
          colRotL(BB, h, k - 1, k, k + 1);
          colRotL(Z, h, k - 1, k, n);
          AA(k + 1, k - 1) = 0.0;
        }
      }
      continue;
    }
    iter++;
    total++;
    // Wilkinson shift: the eigenvalue of the trailing 2 x 2 pencil nearer to
    // A(hi,hi)/B(hi,hi). It is complex for a complex pair, so real input with
    // complex eigenvalues converges. Now and then an exceptional complex shift.
    cd shift;
    {
      cd a11 = AA(hi - 1, hi - 1), a12 = AA(hi - 1, hi), a21 = AA(hi, hi - 1), a22 = AA(hi, hi);
      cd b11 = BB(hi - 1, hi - 1), b12 = BB(hi - 1, hi), b22 = BB(hi, hi);
      cd qa = b11 * b22, qb = -(a11 * b22 + a22 * b11 - a21 * b12), qc = a11 * a22 - a12 * a21;
      cd disc = std::sqrt(qb * qb - 4.0 * qa * qc);
      cd den = std::abs(qb + disc) >= std::abs(qb - disc) ? -(qb + disc) : -(qb - disc);
      cd ray = a22 / b22;
      if (std::abs(den) > 0) {
        cd r1 = den / (2.0 * qa), r2 = 2.0 * qc / den;
        shift = std::abs(r1 - ray) <= std::abs(r2 - ray) ? r1 : r2;
      } else {
        shift = ray;
      }
      if (!std::isfinite(shift.real()) || !std::isfinite(shift.imag()))
        shift = ray;
    }
    if (iter % 11 == 0) {
      double m = std::abs(AA(hi, hi - 1)) / std::max(std::abs(BB(hi - 1, hi - 1)), 1e-300);
      shift = AA(hi, hi) / BB(hi, hi) + m * std::polar(1.0, 0.7 * iter);
    }
    cd x = AA(l, l) - shift * BB(l, l), y = AA(l + 1, l);
    for (long k = l; k < hi; k++) {
      Givens g = zeroLower(x, y);
      size_t from = k > l ? k - 1 : k;
      rowRot(AA, g, k, k + 1, from);
      rowRot(BB, g, k, k + 1, k);
      colRotAdj(Q, g, k, k + 1, n);
      if (k > l)
        AA(k + 1, k - 1) = 0.0;
      Givens h = zeroLeft(BB(k + 1, k), BB(k + 1, k + 1));
      colRotL(BB, h, k, k + 1, k + 2);
      colRotL(AA, h, k, k + 1, n);
      colRotL(Z, h, k, k + 1, n);
      BB(k + 1, k) = 0.0;
      if (k + 1 < hi) {
        x = AA(k + 1, k);
        y = AA(k + 2, k);
      }
    }
  }
  for (size_t i = 1; i < n; i++)
    for (size_t j = 0; j < i; j++) {
      AA(i, j) = 0.0;
      BB(i, j) = 0.0;
    }
}

void reorderSchur(CMat &T_, CMat &Z, const std::vector<bool> &keepIn) {
  std::vector<bool> keep = keepIn;
  const size_t n = T_.r;
  size_t target = 0;
  for (size_t i = 0; i < n; i++) {
    if (!keep[i])
      continue;
    for (size_t k = i; k > target; k--) {
      // Swap the diagonal entries k-1 and k.
      cd a = T_(k - 1, k - 1), b = T_(k, k), t = T_(k - 1, k);
      Givens g = zeroLower(t, b - a);
      rowRot(T_, g, k - 1, k, 0);
      colRotAdj(T_, g, k - 1, k, n);
      colRotAdj(Z, g, k - 1, k, n);
      T_(k, k - 1) = 0.0;
      T_(k - 1, k - 1) = b;
      T_(k, k) = a;
    }
    target++;
  }
}

void reorderQZ(CMat &AA, CMat &BB, CMat &Q, CMat &Z, const std::vector<bool> &keep) {
  const size_t n = AA.r;
  size_t target = 0;
  for (size_t i = 0; i < n; i++) {
    if (!keep[i])
      continue;
    for (size_t k = i; k > target; k--) {
      // Swap positions k-1, k of the pencil (Van Dooren).
      const size_t p = k - 1, q = k;
      cd f = BB(q, q) * AA(p, p) - AA(q, q) * BB(p, p);
      cd h = BB(q, q) * AA(p, q) - AA(q, q) * BB(p, q);
      // Right rotation making the swap.
      Givens r = zeroLeft(f, h);
      colRotL(AA, r, p, q, q + 1);
      colRotL(BB, r, p, q, q + 1);
      colRotL(Z, r, p, q, n);
      // Left rotation restoring the triangles.
      const bool useA = std::abs(AA(p, p)) + std::abs(AA(q, p)) >= std::abs(BB(p, p)) + std::abs(BB(q, p));
      Givens l = useA ? zeroLower(AA(p, p), AA(q, p)) : zeroLower(BB(p, p), BB(q, p));
      rowRot(AA, l, p, q, p);
      rowRot(BB, l, p, q, p);
      colRotAdj(Q, l, p, q, n);
      AA(q, p) = 0.0;
      BB(q, p) = 0.0;
    }
    target++;
  }
}

bool sylvester(const CMat &A, const CMat &B, const CMat &C, CMat &X) {
  CMat RA, UA, RB, UB;
  complexSchur(A, RA, UA);
  complexSchur(B, RB, UB);
  CMat F = mul(mul(adjointOf(UA), C), UB);
  const size_t m = A.r, n = B.r;
  CMat Y(m, n);
  for (size_t j = 0; j < n; j++)
    for (size_t ii = m; ii-- > 0;) {
      cd s = F(ii, j);
      for (size_t k = ii + 1; k < m; k++)
        s -= RA(ii, k) * Y(k, j);
      for (size_t k = 0; k < j; k++)
        s -= Y(ii, k) * RB(k, j);
      cd d = RA(ii, ii) + RB(j, j);
      if (std::abs(d) == 0.0)
        return false;
      Y(ii, j) = s / d;
    }
  X = mul(mul(UA, Y), adjointOf(UB));
  return true;
}

CMat expm(const CMat &A) {
  const size_t n = A.r;
  double nrm = 0.0;
  for (size_t j = 0; j < n; j++) {
    double s = 0.0;
    for (size_t i = 0; i < n; i++)
      s += std::abs(A(i, j));
    nrm = std::max(nrm, s);
  }
  int sq = 0;
  if (nrm > 0.5)
    sq = std::max(0, static_cast<int>(std::ceil(std::log2(nrm / 0.5))));
  CMat S = A;
  for (cd &z : S.a)
    z /= std::pow(2.0, sq);
  // Pade(13,13) coefficients.
  static const double b[] = {64764752532480000.0, 32382376266240000.0, 7771770303897600.0,
                             1187353796428800.0,  129060195264000.0,   10559470521600.0,
                             670442572800.0,      33522128640.0,       1323241920.0,
                             40840800.0,          960960.0,            16380.0,
                             182.0,               1.0};
  CMat I = CMat::eye(n), S2 = mul(S, S), S4 = mul(S2, S2), S6 = mul(S4, S2);
  CMat U(n, n), V(n, n);
  for (size_t i = 0; i < n * n; i++) {
    U.a[i] = b[13] * S6.a[i] + b[11] * S4.a[i] + b[9] * S2.a[i];
    V.a[i] = b[12] * S6.a[i] + b[10] * S4.a[i] + b[8] * S2.a[i];
  }
  U = mul(S6, U);
  V = mul(S6, V);
  for (size_t i = 0; i < n * n; i++) {
    U.a[i] += b[7] * S6.a[i] + b[5] * S4.a[i] + b[3] * S2.a[i] + b[1] * I.a[i];
    V.a[i] += b[6] * S6.a[i] + b[4] * S4.a[i] + b[2] * S2.a[i] + b[0] * I.a[i];
  }
  U = mul(S, U);
  CMat P(n, n), R(n, n);
  for (size_t i = 0; i < n * n; i++) {
    P.a[i] = V.a[i] + U.a[i];
    R.a[i] = V.a[i] - U.a[i];
  }
  solve(R, P);
  for (int k = 0; k < sq; k++)
    P = mul(P, P);
  return P;
}

Mat expmReal(const Mat &A) {
  CMat e = expm(toComplex(A));
  Mat o(A.r, A.c);
  for (size_t i = 0; i < e.a.size(); i++)
    o.a[i] = e.a[i].real();
  return o;
}

CVec polyRoots(const CVec &coeffsIn) {
  size_t s = 0;
  while (s < coeffsIn.size() && coeffsIn[s] == cd(0.0))
    s++;
  CVec c(coeffsIn.begin() + s, coeffsIn.end());
  size_t zeros = 0;
  while (!c.empty() && c.back() == cd(0.0)) {
    c.pop_back();
    zeros++;
  }
  CVec roots;
  if (c.size() > 1) {
    const size_t n = c.size() - 1;
    CMat C(n, n);
    for (size_t j = 0; j < n; j++)
      C(0, j) = -c[j + 1] / c[0];
    for (size_t i = 1; i < n; i++)
      C(i, i - 1) = 1.0;
    eigGeneral(C, roots, nullptr);
  }
  roots.insert(roots.end(), zeros, cd(0.0));
  return roots;
}

} // namespace la
} // namespace scipy
} // namespace nc
