// Dense linear algebra written for the Scipy tree: LU, QR, Cholesky, SVD,
// Hermitian and general eigenproblems, Schur and QZ. Templates over double and
// std::complex<double>. Other sections (signal, optimize, sparse, spatial, ...)
// include this header. Each routine reads and writes plain buffers, so a later
// parallel version (scipy_parallel.h) can replace an inner loop without any
// change for its callers.
#ifndef NC_SCIPY_LA_CORE_H
#define NC_SCIPY_LA_CORE_H

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace la {

inline double absOf(double x) { return std::fabs(x); }
inline double absOf(const cd &x) { return std::abs(x); }
inline double realOf(double x) { return x; }
inline double realOf(const cd &x) { return x.real(); }

template <class T> double frobenius(const MatT<T> &m) {
  double s = 0.0;
  for (const T &x : m.a)
    s += absOf(x) * absOf(x);
  return std::sqrt(s);
}

// ---- LU with partial pivoting: A overwritten by L\U, piv[i] = row swapped with i ----

template <class T> bool luFactor(MatT<T> &A, std::vector<size_t> &piv) {
  const size_t n = std::min(A.r, A.c);
  piv.resize(n);
  bool regular = true;
  for (size_t k = 0; k < n; k++) {
    size_t p = k;
    double best = absOf(A(k, k));
    for (size_t i = k + 1; i < A.r; i++)
      if (absOf(A(i, k)) > best) {
        best = absOf(A(i, k));
        p = i;
      }
    piv[k] = p;
    if (best == 0.0) {
      regular = false;
      continue;
    }
    if (p != k)
      for (size_t j = 0; j < A.c; j++)
        std::swap(A(k, j), A(p, j));
    for (size_t i = k + 1; i < A.r; i++) {
      A(i, k) /= A(k, k);
      const T f = A(i, k);
      if (f == T(0))
        continue;
      for (size_t j = k + 1; j < A.c; j++)
        A(i, j) -= f * A(k, j);
    }
  }
  return regular;
}

// Solves with the factors; B has one column per right-hand side.
template <class T>
void luSolveInPlace(const MatT<T> &LU, const std::vector<size_t> &piv, MatT<T> &B) {
  const size_t n = LU.r;
  for (size_t k = 0; k < piv.size(); k++)
    if (piv[k] != k)
      for (size_t j = 0; j < B.c; j++)
        std::swap(B(k, j), B(piv[k], j));
  for (size_t j = 0; j < B.c; j++) {
    for (size_t i = 0; i < n; i++)
      for (size_t k = 0; k < i; k++)
        B(i, j) -= LU(i, k) * B(k, j);
    for (size_t ii = n; ii-- > 0;) {
      for (size_t k = ii + 1; k < n; k++)
        B(ii, j) -= LU(ii, k) * B(k, j);
      B(ii, j) /= LU(ii, ii);
    }
  }
}

template <class T> bool solve(MatT<T> A, MatT<T> &B) {
  std::vector<size_t> piv;
  if (!luFactor(A, piv))
    return false;
  luSolveInPlace(A, piv, B);
  return true;
}
template <class T> bool solveVec(const MatT<T> &A, std::vector<T> &b) {
  MatT<T> B(b.size(), 1);
  B.a = b;
  if (!solve(A, B))
    return false;
  b = B.a;
  return true;
}
template <class T> bool inverse(const MatT<T> &A, MatT<T> &out) {
  out = MatT<T>::eye(A.r);
  return solve(A, out);
}
template <class T> T det(MatT<T> A) {
  std::vector<size_t> piv;
  if (!luFactor(A, piv))
    return T(0);
  T d(1);
  for (size_t i = 0; i < A.r; i++) {
    d *= A(i, i);
    if (piv[i] != i)
      d = -d;
  }
  return d;
}

// ---- Householder QR: A = Q R, Q square ----

// The reflector x -> H x with H x = beta e1; v[0] = 1. Returns tau.
template <class T> T houseVec(T *x, size_t n, size_t step, T &beta) {
  double normRest = 0.0;
  for (size_t i = 1; i < n; i++)
    normRest += absOf(x[i * step]) * absOf(x[i * step]);
  const T alpha = x[0];
  if (normRest == 0.0 && (absOf(alpha) == 0.0 || std::imag(cd(alpha)) == 0.0)) {
    beta = alpha;
    return T(0);
  }
  double norm = std::sqrt(absOf(alpha) * absOf(alpha) + normRest);
  double b = realOf(alpha) >= 0 ? -norm : norm;
  beta = T(b);
  T tau = (T(b) - alpha) / T(b);
  T scale = T(1) / (alpha - T(b));
  for (size_t i = 1; i < n; i++)
    x[i * step] *= scale;
  x[0] = T(1);
  return tau;
}

template <class T> void qrFactor(MatT<T> A, MatT<T> &Q, MatT<T> &R) {
  const size_t m = A.r, n = A.c, k = std::min(m, n);
  Q = MatT<T>::eye(m);
  std::vector<T> v(m);
  for (size_t j = 0; j < k; j++) {
    T beta;
    T tau = houseVec(&A(j, j), m - j, A.c, beta);
    for (size_t i = j; i < m; i++)
      v[i] = A(i, j);
    if (tau != T(0)) {
      // A = (I - conj(tau) v v^H) A, keeping Q*H accumulated.
      for (size_t c = j + 1; c < n; c++) {
        T s(0);
        for (size_t i = j; i < m; i++)
          s += conjOf(v[i]) * A(i, c);
        s *= conjOf(tau);
        for (size_t i = j; i < m; i++)
          A(i, c) -= v[i] * s;
      }
      for (size_t r = 0; r < m; r++) {
        T s(0);
        for (size_t i = j; i < m; i++)
          s += Q(r, i) * v[i];
        s *= tau;
        for (size_t i = j; i < m; i++)
          Q(r, i) -= s * conjOf(v[i]);
      }
    }
    A(j, j) = beta;
    for (size_t i = j + 1; i < m; i++)
      A(i, j) = T(0);
  }
  R = A;
}

// Least squares through the SVD is in lstsqMin; this is the plain QR one for full rank.
template <class T> bool cholLower(const MatT<T> &A, MatT<T> &L) {
  const size_t n = A.r;
  L = MatT<T>(n, n);
  for (size_t j = 0; j < n; j++) {
    double d = realOf(A(j, j));
    for (size_t k = 0; k < j; k++)
      d -= absOf(L(j, k)) * absOf(L(j, k));
    if (!(d > 0.0))
      return false;
    L(j, j) = T(std::sqrt(d));
    for (size_t i = j + 1; i < n; i++) {
      T s = A(i, j);
      for (size_t k = 0; k < j; k++)
        s -= L(i, k) * conjOf(L(j, k));
      L(i, j) = s / L(j, j);
    }
  }
  return true;
}

// ---- SVD by one-sided Jacobi: A = U diag(s) V^H, s descending, U is m x k, V is n x k ----

template <class T> void svdThin(const MatT<T> &Ain, MatT<T> &U, Vec &s, MatT<T> &V) {
  if (Ain.r < Ain.c) {
    MatT<T> U2, V2;
    svdThin(adjointOf(Ain), U2, s, V2);
    U = V2;
    V = U2;
    return;
  }
  MatT<T> A = Ain;
  const size_t m = A.r, n = A.c;
  V = MatT<T>::eye(n);
  for (int sweep = 0; sweep < 60; sweep++) {
    bool rotated = false;
    for (size_t p = 0; p + 1 < n; p++)
      for (size_t q = p + 1; q < n; q++) {
        double app = 0.0, aqq = 0.0;
        T apq(0);
        for (size_t i = 0; i < m; i++) {
          app += absOf(A(i, p)) * absOf(A(i, p));
          aqq += absOf(A(i, q)) * absOf(A(i, q));
          apq += conjOf(A(i, p)) * A(i, q);
        }
        double g = absOf(apq);
        if (g == 0.0 || g <= 1e-16 * std::sqrt(app * aqq))
          continue;
        rotated = true;
        double zeta = (aqq - app) / (2.0 * g);
        double t = (zeta >= 0 ? 1.0 : -1.0) / (std::fabs(zeta) + std::sqrt(1.0 + zeta * zeta));
        double cs = 1.0 / std::sqrt(1.0 + t * t), sn = cs * t;
        T ph = apq / T(g); // unit phase of apq
        for (size_t i = 0; i < m; i++) {
          T x = A(i, p), y = A(i, q);
          A(i, p) = T(cs) * x - T(sn) * conjOf(ph) * y;
          A(i, q) = T(sn) * ph * x + T(cs) * y;
        }
        for (size_t i = 0; i < n; i++) {
          T x = V(i, p), y = V(i, q);
          V(i, p) = T(cs) * x - T(sn) * conjOf(ph) * y;
          V(i, q) = T(sn) * ph * x + T(cs) * y;
        }
      }
    if (!rotated)
      break;
  }
  std::vector<std::pair<double, size_t>> order(n);
  for (size_t j = 0; j < n; j++) {
    double t = 0.0;
    for (size_t i = 0; i < m; i++)
      t += absOf(A(i, j)) * absOf(A(i, j));
    order[j] = {std::sqrt(t), j};
  }
  std::stable_sort(order.begin(), order.end(),
                   [](const auto &x, const auto &y) { return x.first > y.first; });
  s.resize(n);
  U = MatT<T>(m, n);
  MatT<T> V2(n, n);
  const double big = n ? order[0].first : 0.0;
  std::vector<size_t> nulls;
  for (size_t k = 0; k < n; k++) {
    s[k] = order[k].first;
    size_t j = order[k].second;
    for (size_t i = 0; i < n; i++)
      V2(i, k) = V(i, j);
    if (s[k] > 1e-15 * big && s[k] > 0.0) {
      for (size_t i = 0; i < m; i++)
        U(i, k) = A(i, j) / T(s[k]);
    } else {
      nulls.push_back(k);
    }
  }
  V = V2;
  // Columns for zero singular values: complete U by Gram-Schmidt.
  for (size_t k : nulls) {
    for (size_t e = 0; e < m; e++) {
      std::vector<T> v(m, T(0));
      v[e] = T(1);
      for (int pass = 0; pass < 2; pass++)
        for (size_t c = 0; c < n; c++) {
          if (c == k || (std::find(nulls.begin(), nulls.end(), c) != nulls.end() && c > k))
            continue;
          T d(0);
          for (size_t i = 0; i < m; i++)
            d += conjOf(U(i, c)) * v[i];
          for (size_t i = 0; i < m; i++)
            v[i] -= d * U(i, c);
        }
      double nv = 0.0;
      for (const T &x : v)
        nv += absOf(x) * absOf(x);
      if (nv > 1e-8) {
        nv = std::sqrt(nv);
        for (size_t i = 0; i < m; i++)
          U(i, k) = v[i] / T(nv);
        break;
      }
    }
  }
}

// Extends the k orthonormal columns of U to a full m x m unitary matrix.
template <class T> MatT<T> completeBasis(const MatT<T> &U) {
  const size_t m = U.r, k = U.c;
  MatT<T> F(m, m);
  for (size_t i = 0; i < m; i++)
    for (size_t j = 0; j < k; j++)
      F(i, j) = U(i, j);
  size_t filled = k;
  for (size_t e = 0; e < m && filled < m; e++) {
    std::vector<T> v(m, T(0));
    v[e] = T(1);
    for (int pass = 0; pass < 2; pass++)
      for (size_t c = 0; c < filled; c++) {
        T d(0);
        for (size_t i = 0; i < m; i++)
          d += conjOf(F(i, c)) * v[i];
        for (size_t i = 0; i < m; i++)
          v[i] -= d * F(i, c);
      }
    double nv = 0.0;
    for (const T &x : v)
      nv += absOf(x) * absOf(x);
    if (nv > 1e-10) {
      nv = std::sqrt(nv);
      for (size_t i = 0; i < m; i++)
        F(i, filled) = v[i] / T(nv);
      filled++;
    }
  }
  return F;
}

// Minimum-norm least squares; rank uses the same cut-off as LAPACK's gelsd.
template <class T>
std::vector<T> lstsqMin(const MatT<T> &A, const std::vector<T> &b, size_t *rankOut = nullptr,
                        Vec *sOut = nullptr) {
  MatT<T> U, V;
  Vec s;
  svdThin(A, U, s, V);
  const double cut = kEps * static_cast<double>(std::max(A.r, A.c)) * (s.empty() ? 0.0 : s[0]);
  std::vector<T> x(A.c, T(0));
  size_t rank = 0;
  for (size_t k = 0; k < s.size(); k++) {
    if (s[k] <= cut)
      continue;
    rank++;
    T d(0);
    for (size_t i = 0; i < A.r; i++)
      d += conjOf(U(i, k)) * b[i];
    d /= T(s[k]);
    for (size_t i = 0; i < A.c; i++)
      x[i] += d * V(i, k);
  }
  if (rankOut)
    *rankOut = rank;
  if (sOut)
    *sOut = s;
  return x;
}

template <class T> MatT<T> pinv(const MatT<T> &A) {
  MatT<T> U, V;
  Vec s;
  svdThin(A, U, s, V);
  const double cut = kEps * static_cast<double>(std::max(A.r, A.c)) * (s.empty() ? 0.0 : s[0]);
  MatT<T> P(A.c, A.r);
  for (size_t k = 0; k < s.size(); k++) {
    if (s[k] <= cut)
      continue;
    for (size_t i = 0; i < A.c; i++)
      for (size_t j = 0; j < A.r; j++)
        P(i, j) += V(i, k) * conjOf(U(j, k)) / T(s[k]);
  }
  return P;
}

// ---- Hermitian eigenproblem by cyclic Jacobi: values ascending ----

template <class T> void eigHermitian(MatT<T> A, Vec &w, MatT<T> &Z) {
  const size_t n = A.r;
  Z = MatT<T>::eye(n);
  for (int sweep = 0; sweep < 100; sweep++) {
    double off = 0.0, all = 0.0;
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        all += absOf(A(i, j)) * absOf(A(i, j));
        if (i != j)
          off += absOf(A(i, j)) * absOf(A(i, j));
      }
    if (off <= 1e-32 * all || off == 0.0)
      break;
    for (size_t p = 0; p + 1 < n; p++)
      for (size_t q = p + 1; q < n; q++) {
        double g = absOf(A(p, q));
        if (g == 0.0)
          continue;
        T ph = A(p, q) / T(g);
        double theta = (realOf(A(q, q)) - realOf(A(p, p))) / (2.0 * g);
        double t = (theta >= 0 ? 1.0 : -1.0) / (std::fabs(theta) + std::sqrt(theta * theta + 1.0));
        double cs = 1.0 / std::sqrt(t * t + 1.0), sn = t * cs;
        for (size_t k = 0; k < n; k++) {
          T x = A(k, p), y = A(k, q);
          A(k, p) = T(cs) * x - T(sn) * conjOf(ph) * y;
          A(k, q) = T(sn) * ph * x + T(cs) * y;
        }
        for (size_t k = 0; k < n; k++) {
          T x = A(p, k), y = A(q, k);
          A(p, k) = T(cs) * x - T(sn) * ph * y;
          A(q, k) = T(sn) * conjOf(ph) * x + T(cs) * y;
        }
        for (size_t k = 0; k < n; k++) {
          T x = Z(k, p), y = Z(k, q);
          Z(k, p) = T(cs) * x - T(sn) * conjOf(ph) * y;
          Z(k, q) = T(sn) * ph * x + T(cs) * y;
        }
      }
  }
  std::vector<size_t> idx(n);
  for (size_t i = 0; i < n; i++)
    idx[i] = i;
  std::sort(idx.begin(), idx.end(),
            [&](size_t x, size_t y) { return realOf(A(x, x)) < realOf(A(y, y)); });
  w.resize(n);
  MatT<T> Z2(n, n);
  for (size_t k = 0; k < n; k++) {
    w[k] = realOf(A(idx[k], idx[k]));
    for (size_t i = 0; i < n; i++)
      Z2(i, k) = Z(i, idx[k]);
  }
  Z = Z2;
}

// ---- Hessenberg reduction: A = Q H Q^H ----

template <class T> void hessenberg(MatT<T> A, MatT<T> &H, MatT<T> &Q) {
  const size_t n = A.r;
  Q = MatT<T>::eye(n);
  std::vector<T> v(n);
  for (size_t k = 0; k + 2 < n; k++) {
    T beta;
    T tau = houseVec(&A(k + 1, k), n - k - 1, A.c, beta);
    for (size_t i = k + 1; i < n; i++)
      v[i] = A(i, k);
    A(k + 1, k) = beta;
    for (size_t i = k + 2; i < n; i++)
      A(i, k) = T(0);
    if (tau == T(0))
      continue;
    for (size_t c = k + 1; c < n; c++) {
      T s(0);
      for (size_t i = k + 1; i < n; i++)
        s += conjOf(v[i]) * A(i, c);
      s *= conjOf(tau);
      for (size_t i = k + 1; i < n; i++)
        A(i, c) -= v[i] * s;
    }
    for (size_t r = 0; r < n; r++) {
      T s(0);
      for (size_t i = k + 1; i < n; i++)
        s += A(r, i) * v[i];
      s *= tau;
      for (size_t i = k + 1; i < n; i++)
        A(r, i) -= s * conjOf(v[i]);
    }
    for (size_t r = 0; r < n; r++) {
      T s(0);
      for (size_t i = k + 1; i < n; i++)
        s += Q(r, i) * v[i];
      s *= tau;
      for (size_t i = k + 1; i < n; i++)
        Q(r, i) -= s * conjOf(v[i]);
    }
  }
  H = A;
}

// The cpp file holds the routines that are not templates.
// A = Z T Z^H, T upper triangular.
void complexSchur(const CMat &A, CMat &T_, CMat &Z);
// A = Z T Z', T quasi upper triangular with standard 2x2 blocks.
void realSchur(const Mat &A, Mat &T_, Mat &Z);
// Eigenvalues (not sorted) and, if wanted, right eigenvectors as columns of unit norm.
void eigGeneral(const CMat &A, CVec &w, CMat *V);
// A = Q AA Z^H, B = Q BB Z^H, AA and BB upper triangular.
void complexQZ(const CMat &A, const CMat &B, CMat &AA, CMat &BB, CMat &Q, CMat &Z);
// Moves the diagonal entries with keep[i] true to the top of a Schur form.
void reorderSchur(CMat &T_, CMat &Z, const std::vector<bool> &keep);
void reorderQZ(CMat &AA, CMat &BB, CMat &Q, CMat &Z, const std::vector<bool> &keep);
// Solves A X + X B = C for general A, B.
bool sylvester(const CMat &A, const CMat &B, const CMat &C, CMat &X);
// exp(A) by scaling and squaring with a Pade approximant.
Mat expmReal(const Mat &A);
CMat expm(const CMat &A);
// Eigenvalues of a real or complex matrix sorted for a stable result.
CVec polyRoots(const CVec &coeffs);

} // namespace la
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_LA_CORE_H
