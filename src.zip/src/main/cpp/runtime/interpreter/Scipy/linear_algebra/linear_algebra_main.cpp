// Section 10 of 25 - Linear Algebra (scipy.linalg).
// solve, lstsq, svd, qr and cholesky already exist in Numpy/ and are not repeated.
#include "linear_algebra_main.h"

#include <random>

#include "../fourier_transforms/ft_core.h"
#include "../signal_processing/sg_core.h"
#include "../../ops/matrix/matrix.h"
#include "la_core.h"

#define SP_SEC Section::LinearAlgebra

namespace nc {
namespace scipy {

namespace {

using namespace la;

// A b column for the solvers: an array becomes one column; a matrix stays.
bool getRhs(const Args &a, size_t i, CallContext &ctx, CMat &B, bool &wasVec) {
  if (i >= a.size() || !numericCells(a[i])) {
    ctx.fail("the " + ordinal(i) + " argument must be an array or matrix of numbers");
    return false;
  }
  CMat m;
  readCMat(a[i], m);
  wasVec = m.r <= 1 || m.c == 1;
  if (m.r == 1) {
    B = CMat(m.c, 1);
    B.a = m.a;
  } else {
    B = m;
  }
  return true;
}
Value rhsResult(const CMat &X, bool wasVec) {
  if (!wasVec)
    return realIfPossible(X);
  CVec v(X.a);
  return realIfPossible(v);
}

// Band storage to dense. ab has (l + u + 1) rows; ab(u + i - j, j) = A(i, j).
CMat bandToDense(const CMat &ab, size_t l, size_t u) {
  const size_t n = ab.c;
  CMat A(n, n);
  for (size_t j = 0; j < n; j++)
    for (size_t i = (j > u ? j - u : 0); i < std::min(n, j + l + 1); i++)
      A(i, j) = ab(u + i - j, j);
  return A;
}
// Upper or lower symmetric band storage to dense.
CMat symBandToDense(const CMat &ab, bool lower) {
  const size_t n = ab.c, w = ab.r - 1;
  CMat A(n, n);
  for (size_t j = 0; j < n; j++)
    for (size_t d = 0; d <= w; d++) {
      if (lower) {
        if (j + d < n) {
          A(j + d, j) = ab(d, j);
          A(j, j + d) = std::conj(ab(d, j));
        }
      } else if (j >= d) {
        A(j - d, j) = ab(w - d, j);
        A(j, j - d) = std::conj(ab(w - d, j));
      }
    }
  return A;
}
CMat toeplitzDense(const CVec &c, const CVec &r) {
  CMat T(c.size(), r.size());
  for (size_t i = 0; i < T.r; i++)
    for (size_t j = 0; j < T.c; j++)
      T(i, j) = i >= j ? c[i - j] : r[j - i];
  return T;
}
Mat diagMat(const Vec &s, size_t m, size_t n) {
  Mat S(m, n);
  for (size_t i = 0; i < s.size() && i < std::min(m, n); i++)
    S(i, i) = s[i];
  return S;
}

// Column-pivoted Householder QR: A P = Q R (as in the interpolative decomposition).
void pivotedQR(Mat A, Mat &R, IVec &perm) {
  const size_t m = A.r, n = A.c;
  perm.resize(n);
  for (size_t i = 0; i < n; i++)
    perm[i] = static_cast<long long>(i);
  Vec v(m);
  for (size_t k = 0; k < std::min(m, n); k++) {
    size_t best = k;
    double bn = -1.0;
    for (size_t j = k; j < n; j++) {
      double s = 0.0;
      for (size_t i = k; i < m; i++)
        s += A(i, j) * A(i, j);
      if (s > bn * (1.0 + 1e-13)) {
        bn = s;
        best = j;
      }
    }
    if (best != k) {
      std::swap(perm[k], perm[best]);
      for (size_t i = 0; i < m; i++)
        std::swap(A(i, k), A(i, best));
    }
    double beta;
    double tau = houseVec(&A(k, k), m - k, A.c, beta);
    for (size_t i = k; i < m; i++)
      v[i] = A(i, k);
    if (tau != 0.0)
      for (size_t c = k + 1; c < n; c++) {
        double s = 0.0;
        for (size_t i = k; i < m; i++)
          s += v[i] * A(i, c);
        s *= tau;
        for (size_t i = k; i < m; i++)
          A(i, c) -= v[i] * s;
      }
    A(k, k) = beta;
    for (size_t i = k + 1; i < m; i++)
      A(i, k) = 0.0;
  }
  R = A;
}

// Bunch-Kaufman on a Hermitian matrix: P A P^H = L D L^H.
void bunchKaufman(CMat A, CMat &L, CMat &D, IVec &perm) {
  const size_t n = A.r;
  const double alpha = (1.0 + std::sqrt(17.0)) / 8.0;
  L = CMat::eye(n);
  D = CMat(n, n);
  perm.resize(n);
  for (size_t i = 0; i < n; i++)
    perm[i] = static_cast<long long>(i);
  auto swapRC = [&](size_t x, size_t y, size_t k) {
    if (x == y)
      return;
    for (size_t j = 0; j < n; j++)
      std::swap(A(x, j), A(y, j));
    for (size_t i = 0; i < n; i++)
      std::swap(A(i, x), A(i, y));
    for (size_t j = 0; j < k; j++)
      std::swap(L(x, j), L(y, j));
    std::swap(perm[x], perm[y]);
  };
  size_t k = 0;
  while (k < n) {
    double lambda = 0.0;
    size_t rr = k;
    for (size_t i = k + 1; i < n; i++)
      if (std::abs(A(i, k)) > lambda) {
        lambda = std::abs(A(i, k));
        rr = i;
      }
    size_t step = 1;
    if (lambda > 0.0 && std::abs(A(k, k)) < alpha * lambda) {
      double sigma = 0.0;
      for (size_t i = k; i < n; i++)
        if (i != rr)
          sigma = std::max(sigma, std::abs(A(i, rr)));
      if (std::abs(A(k, k)) * sigma >= alpha * lambda * lambda) {
      } else if (std::abs(A(rr, rr)) >= alpha * sigma) {
        swapRC(k, rr, k);
      } else {
        swapRC(k + 1, rr, k);
        step = 2;
      }
    }
    if (step == 1) {
      D(k, k) = A(k, k);
      if (std::abs(A(k, k)) > 0.0)
        for (size_t i = k + 1; i < n; i++)
          L(i, k) = A(i, k) / A(k, k);
      for (size_t i = k + 1; i < n; i++)
        for (size_t j = k + 1; j < n; j++)
          A(i, j) -= L(i, k) * A(k, k) * std::conj(L(j, k));
    } else {
      cd a11 = A(k, k), a21 = A(k + 1, k), a22 = A(k + 1, k + 1), a12 = A(k, k + 1);
      D(k, k) = a11;
      D(k + 1, k) = a21;
      D(k, k + 1) = a12;
      D(k + 1, k + 1) = a22;
      cd dt = a11 * a22 - a12 * a21;
      for (size_t i = k + 2; i < n; i++) {
        cd x = A(i, k), y = A(i, k + 1);
        L(i, k) = (x * a22 - y * a21) / dt;
        L(i, k + 1) = (y * a11 - x * a12) / dt;
      }
      for (size_t i = k + 2; i < n; i++)
        for (size_t j = k + 2; j < n; j++)
          A(i, j) -= L(i, k) * std::conj(A(j, k)) + L(i, k + 1) * std::conj(A(j, k + 1));
    }
    k += step;
  }
}

// Continuous-time Riccati through the ordered Schur form of the Hamiltonian.
bool careSolve(const CMat &A, const CMat &B, const CMat &Q, const CMat &R, CMat &X) {
  const size_t n = A.r;
  CMat Rinv;
  if (!inverse(R, Rinv))
    return false;
  CMat G = mul(mul(B, Rinv), adjointOf(B));
  CMat H(2 * n, 2 * n);
  CMat Ah = adjointOf(A);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      H(i, j) = A(i, j);
      H(i, j + n) = -G(i, j);
      H(i + n, j) = -Q(i, j);
      H(i + n, j + n) = -Ah(i, j);
    }
  CMat T_, Z;
  complexSchur(H, T_, Z);
  std::vector<bool> keep(2 * n);
  size_t count = 0;
  for (size_t i = 0; i < 2 * n; i++) {
    keep[i] = T_(i, i).real() < 0.0;
    count += keep[i];
  }
  if (count != n)
    return false;
  reorderSchur(T_, Z, keep);
  CMat U1(n, n), U2(n, n);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < n; j++) {
      U1(i, j) = Z(i, j);
      U2(i, j) = Z(i + n, j);
    }
  // X U1 = U2
  CMat aU1 = adjointOf(U1), aU2 = adjointOf(U2);
  if (!solve(aU1, aU2))
    return false;
  X = adjointOf(aU2);
  return true;
}

// Discrete-time Riccati by the structure-preserving doubling algorithm.
bool dareSolve(const CMat &A, const CMat &B, const CMat &Q, const CMat &R, CMat &X) {
  const size_t n = A.r;
  CMat Rinv;
  if (!inverse(R, Rinv))
    return false;
  CMat Ak = A, Gk = mul(mul(B, Rinv), adjointOf(B)), Hk = Q;
  CMat I = CMat::eye(n);
  for (int it = 0; it < 200; it++) {
    CMat W = mul(Gk, Hk);
    for (size_t i = 0; i < n; i++)
      W(i, i) += 1.0;
    CMat W1 = Ak; // inv(I + G H) A
    if (!solve(W, W1))
      return false;
    CMat W2 = Gk; // inv(I + G H) G
    if (!solve(W, W2))
      return false;
    CMat newA = mul(Ak, W1);
    CMat newG = mul(mul(Ak, W2), adjointOf(Ak));
    CMat newH = mul(mul(adjointOf(Ak), Hk), W1);
    double change = 0.0, size = 1e-300;
    for (size_t i = 0; i < n * n; i++) {
      Gk.a[i] += newG.a[i];
      Hk.a[i] += newH.a[i];
      change += std::norm(newH.a[i]);
      size += std::norm(Hk.a[i]);
    }
    Ak = newA;
    if (change <= 1e-30 * size)
      break;
  }
  X = Hk;
  return true;
}

// The generic CS decomposition, reached by SVDs of the blocks: X = U CS V^H.
void cosSin(const Mat &X, size_t p, size_t q, Mat &U, Mat &CS, Mat &Vh) {
  const size_t m = X.r;
  auto block = [&](size_t r0, size_t r1, size_t c0, size_t c1) {
    Mat b(r1 - r0, c1 - c0);
    for (size_t i = r0; i < r1; i++)
      for (size_t j = c0; j < c1; j++)
        b(i - r0, j - c0) = X(i, j);
    return b;
  };
  auto fullSvd = [](const Mat &A, Mat &Uo, Vec &s, Mat &Vo) {
    if (A.r == 0 || A.c == 0) {
      Uo = Mat::eye(A.r);
      Vo = Mat::eye(A.c);
      s.clear();
      return;
    }
    Mat U0, V0;
    svdThin(A, U0, s, V0);
    Uo = completeBasis(U0);
    Vo = completeBasis(V0);
  };
  Mat U1, V1;
  Vec c;
  fullSvd(block(0, p, 0, q), U1, c, V1);
  // Columns of X21 V1 and rows of U1' X12 are orthogonal: normalise to get U2, V2.
  Mat X21V = mul(block(p, m, 0, q), V1);
  Mat U2(m - p, 0);
  {
    std::vector<Vec> cols;
    for (size_t j = 0; j < q && cols.size() < m - p; j++) {
      double n2 = 0.0;
      for (size_t i = 0; i < m - p; i++)
        n2 += X21V(i, j) * X21V(i, j);
      if (n2 > 1e-20) {
        Vec col(m - p);
        for (size_t i = 0; i < m - p; i++)
          col[i] = X21V(i, j) / std::sqrt(n2);
        cols.push_back(col);
      }
    }
    Mat F(m - p, cols.size());
    for (size_t j = 0; j < cols.size(); j++)
      for (size_t i = 0; i < m - p; i++)
        F(i, j) = cols[j][i];
    U2 = completeBasis(F);
  }
  Mat U1tX12 = mul(transposeOf(U1), block(0, p, q, m));
  Mat V2;
  {
    std::vector<Vec> rows;
    for (size_t i = 0; i < p && rows.size() < m - q; i++) {
      double n2 = 0.0;
      for (size_t j = 0; j < m - q; j++)
        n2 += U1tX12(i, j) * U1tX12(i, j);
      if (n2 > 1e-20) {
        Vec row(m - q);
        for (size_t j = 0; j < m - q; j++)
          row[j] = U1tX12(i, j) / std::sqrt(n2);
        rows.push_back(row);
      }
    }
    Mat F(m - q, rows.size());
    for (size_t j = 0; j < rows.size(); j++)
      for (size_t i = 0; i < m - q; i++)
        F(i, j) = rows[j][i];
    V2 = completeBasis(F);
  }
  U = Mat(m, m);
  Mat V(m, m);
  for (size_t i = 0; i < p; i++)
    for (size_t j = 0; j < p; j++)
      U(i, j) = U1(i, j);
  for (size_t i = 0; i < m - p; i++)
    for (size_t j = 0; j < m - p; j++)
      U(i + p, j + p) = U2(i, j);
  for (size_t i = 0; i < q; i++)
    for (size_t j = 0; j < q; j++)
      V(i, j) = V1(i, j);
  for (size_t i = 0; i < m - q; i++)
    for (size_t j = 0; j < m - q; j++)
      V(i + q, j + q) = V2(i, j);
  CS = mul(mul(transposeOf(U), X), V);
  for (double &v : CS.a)
    if (std::fabs(v) < 1e-13)
      v = 0.0;
  Vh = transposeOf(V);
}

std::mt19937_64 rngFor(const Args &a, size_t i) {
  if (isNumberArg(a, i))
    return std::mt19937_64(static_cast<unsigned long long>(a[i].number));
  return std::mt19937_64(ncRandomEngine()());
}

// Largest singular value by power iteration on A'A (repeatable start).
double powerNorm(const Mat &A, long its) {
  std::mt19937_64 gen(12345);
  std::normal_distribution<double> nd;
  Vec v(A.c);
  for (double &x : v)
    x = nd(gen);
  double est = 0.0;
  Mat At = transposeOf(A);
  for (long k = 0; k < its; k++) {
    Vec w = mulVec(At, mulVec(A, v));
    double n = 0.0;
    for (double x : w)
      n += x * x;
    n = std::sqrt(n);
    if (n == 0.0)
      return 0.0;
    for (size_t i = 0; i < w.size(); i++)
      v[i] = w[i] / n;
    est = std::sqrt(n);
  }
  return est;
}

// Which BLAS prefix suits the data: d for real, z for complex.
std::string blasPrefix(const Args &a, size_t i) {
  return (i < a.size() && a[i].hasComplex()) ? "z" : "d";
}

void registerSolvers(Registry &reg) {
  SP_ADD("solve_banded", 3, 3, "l_u, ab, b") {
    Vec lu;
    CMat ab, B;
    bool isV;
    if (!getVec(a, 0, ctx, lu) || !getCMat(a, 1, ctx, ab) || !getRhs(a, 2, ctx, B, isV))
      return Value(0.0);
    if (lu.size() != 2 || ab.r != static_cast<size_t>(lu[0] + lu[1] + 1)) {
      ctx.fail("ab must have lower + upper + 1 rows");
      return Value(0.0);
    }
    if (!solve(bandToDense(ab, (size_t)lu[0], (size_t)lu[1]), B)) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    return rhsResult(B, isV);
  } SP_ENDC
  SP_ADD("solve_banded_sym", 2, 2, "ab, b") {
    CMat ab, B;
    bool isV;
    if (!getCMat(a, 0, ctx, ab) || !getRhs(a, 1, ctx, B, isV))
      return Value(0.0);
    CMat A = symBandToDense(ab, false), L;
    if (B.r != A.r) {
      ctx.fail("b must have one row per column of ab");
      return Value(0.0);
    }
    if (!cholLower(A, L)) {
      ctx.fail("the matrix is not positive definite");
      return Value(0.0);
    }
    solve(A, B);
    return rhsResult(B, isV);
  } SP_ENDC
  SP_ADD("solve_circulant", 2, 2, "c, b") {
    CVec c, b;
    if (!getCVec(a, 0, ctx, c) || !getCVec(a, 1, ctx, b))
      return Value(0.0);
    if (c.size() != b.size()) {
      ctx.fail("c and b must have the same length");
      return Value(0.0);
    }
    CVec fc = ft::fftOf(c), fb = ft::fftOf(b);
    for (size_t i = 0; i < fc.size(); i++) {
      if (std::abs(fc[i]) == 0.0) {
        ctx.fail("the matrix is singular");
        return Value(0.0);
      }
      fb[i] /= fc[i];
    }
    CVec x = ft::ifftOf(fb);
    if (!a[0].hasComplex() && !a[1].hasComplex())
      for (cd &z : x)
        z = z.real();
    return realIfPossible(x);
  } SP_ENDC
  SP_ADD("solve_triangular", 2, 3, "A, b, lower=0") {
    CMat A, B;
    bool isV;
    if (!getCSquare(a, 0, ctx, A) || !getRhs(a, 1, ctx, B, isV))
      return Value(0.0);
    const bool lower = optBool(a, 2, false);
    const size_t n = A.r;
    for (size_t i = 0; i < n; i++)
      if (A(i, i) == cd(0.0)) {
        ctx.fail("the matrix is singular");
        return Value(0.0);
      }
    for (size_t j = 0; j < B.c; j++) {
      if (lower)
        for (size_t i = 0; i < n; i++) {
          for (size_t k = 0; k < i; k++)
            B(i, j) -= A(i, k) * B(k, j);
          B(i, j) /= A(i, i);
        }
      else
        for (size_t i = n; i-- > 0;) {
          for (size_t k = i + 1; k < n; k++)
            B(i, j) -= A(i, k) * B(k, j);
          B(i, j) /= A(i, i);
        }
    }
    return rhsResult(B, isV);
  } SP_ENDC
  SP_ADD("solve_toeplitz", 2, 3, "c, b[, r]") {
    // c, b  or  c, r, b (first column, first row, right-hand side)
    CVec c, r, b;
    if (!getCVec(a, 0, ctx, c) || !getCVec(a, a.size() == 3 ? 2 : 1, ctx, b))
      return Value(0.0);
    if (a.size() == 3) {
      if (!getCVec(a, 1, ctx, r))
        return Value(0.0);
    } else {
      r = c;
      for (cd &z : r)
        z = std::conj(z);
    }
    if (c.size() != b.size() || r.size() != b.size()) {
      ctx.fail("c and b must have the same length");
      return Value(0.0);
    }
    if (!solveVec(toeplitzDense(c, r), b)) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    return realIfPossible(b);
  } SP_ENDC
  SP_ADD("toeplitz_mul", 2, 3, "c, x[, r]") {
    CVec c, r;
    CMat X;
    bool isV;
    if (!getCVec(a, 0, ctx, c) || !getRhs(a, 1, ctx, X, isV))
      return Value(0.0);
    if (a.size() == 3) {
      if (!getCVec(a, 2, ctx, r))
        return Value(0.0);
    } else {
      r = c;
      for (cd &z : r)
        z = std::conj(z);
    }
    if (r.size() != X.r) {
      ctx.fail("x must have as many rows as the first row has values");
      return Value(0.0);
    }
    return rhsResult(mul(toeplitzDense(c, r), X), isV);
  } SP_ENDC
  SP_ADD("solve_sylvester", 3, 3, "A, B, Q") {
    CMat A, B, Q, X;
    if (!getCSquare(a, 0, ctx, A) || !getCSquare(a, 1, ctx, B) || !getCMat(a, 2, ctx, Q))
      return Value(0.0);
    if (Q.r != A.r || Q.c != B.r || !sylvester(A, B, Q, X)) {
      ctx.fail("no unique solution: check the sizes, and that A and -B share no eigenvalue");
      return Value(0.0);
    }
    if (!a[0].hasComplex() && !a[1].hasComplex() && !a[2].hasComplex())
      for (cd &z : X.a)
        z = z.real();
    return realIfPossible(X);
  } SP_ENDC
  SP_ADD("solve_care", 4, 4, "a, b, q, r") {
    CMat A, B, Q, R, X;
    if (!getCSquare(a, 0, ctx, A) || !getCMat(a, 1, ctx, B) || !getCMat(a, 2, ctx, Q) || !getCMat(a, 3, ctx, R))
      return Value(0.0);
    if (B.r != A.r || Q.r != A.r || Q.c != A.c || R.r != B.c || R.c != B.c) {
      ctx.fail("the sizes must fit: a and q n x n, b n x m, r m x m");
      return Value(0.0);
    }
    if (!careSolve(A, B, Q, R, X)) {
      ctx.fail("the Hamiltonian has eigenvalues too close to the imaginary axis");
      return Value(0.0);
    }
    bool anyC = false;
    for (const Value &v : a)
      anyC = anyC || v.hasComplex();
    if (!anyC)
      for (cd &z : X.a)
        z = z.real();
    return realIfPossible(X);
  } SP_ENDC
  SP_ADD("solve_dare", 4, 4, "a, b, q, r") {
    CMat A, B, Q, R, X;
    if (!getCSquare(a, 0, ctx, A) || !getCMat(a, 1, ctx, B) || !getCMat(a, 2, ctx, Q) || !getCMat(a, 3, ctx, R))
      return Value(0.0);
    if (B.r != A.r || Q.r != A.r || Q.c != A.c || R.r != B.c || R.c != B.c) {
      ctx.fail("the sizes must fit: a and q n x n, b n x m, r m x m");
      return Value(0.0);
    }
    if (!dareSolve(A, B, Q, R, X)) {
      ctx.fail("the system could not be solved: check that (a, b) is stabilisable");
      return Value(0.0);
    }
    return realIfPossible(X);
  } SP_ENDC
  SP_ADD("solve_lyapunov", 2, 2, "A, Q") {
    CMat A, Q, X;
    if (!getCSquare(a, 0, ctx, A) || !getCMat(a, 1, ctx, Q))
      return Value(0.0);
    if (Q.r != A.r || Q.c != A.c || !sylvester(A, adjointOf(A), Q, X)) {
      ctx.fail("no unique solution for these matrices");
      return Value(0.0);
    }
    if (!a[0].hasComplex() && !a[1].hasComplex())
      for (cd &z : X.a)
        z = z.real();
    return realIfPossible(X);
  } SP_ENDC
  SP_ADD("solve_dlyapunov", 2, 2, "A, Q") {
    // A X A^H - X + Q = 0, with the bilinear map to a continuous equation.
    CMat A, Q;
    if (!getCSquare(a, 0, ctx, A) || !getCMat(a, 1, ctx, Q))
      return Value(0.0);
    const size_t n = A.r;
    CMat Ah = adjointOf(A), Iplus = CMat::eye(n), Iminus = CMat::eye(n);
    for (size_t i = 0; i < n * n; i++) {
      Iplus.a[i] += Ah.a[i];
      Iminus.a[i] -= Ah.a[i];
    }
    // B = (A^H - I)(A^H + I)^-1 ; B^H X + X B = -C with C from Q.
    CMat Inv, X;
    CMat AhmI = Ah;
    for (size_t i = 0; i < n; i++)
      AhmI(i, i) -= 1.0;
    if (!inverse(Iplus, Inv)) {
      ctx.fail("A has eigenvalue -1: no solution by this method");
      return Value(0.0);
    }
    CMat B = mul(AhmI, Inv);
    CMat Bh = adjointOf(B);
    CMat C = mul(mul(adjointOf(Inv), Q), Inv);
    for (cd &z : C.a)
      z *= -2.0;
    if (!sylvester(Bh, B, C, X)) {
      ctx.fail("no unique solution for this matrix");
      return Value(0.0);
    }
    if (!a[0].hasComplex() && !a[1].hasComplex())
      for (cd &z : X.a)
        z = z.real();
    return realIfPossible(X);
  } SP_ENDC
}

void registerProperties(Registry &reg) {
  SP_ADD("khatri_rao", 2, 2, "A, B") {
    CMat A, B;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.c != B.c) {
      ctx.fail("the two matrices must have the same number of columns");
      return Value(0.0);
    }
    CMat K(A.r * B.r, A.c);
    for (size_t i = 0; i < A.r; i++)
      for (size_t k = 0; k < B.r; k++)
        for (size_t j = 0; j < A.c; j++)
          K(i * B.r + k, j) = A(i, j) * B(k, j);
    return realIfPossible(K);
  } SP_ENDC
  SP_ADD("procrustes", 2, 2, "A, B") {
    Mat A, B;
    if (!getMat(a, 0, ctx, A) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r || A.c != B.c) {
      ctx.fail("the two matrices must have the same shape");
      return Value(0.0);
    }
    Mat U, V;
    Vec s;
    svdThin(mul(transposeOf(A), B), U, s, V);
    double scale = 0.0;
    for (double x : s)
      scale += x;
    return makeDict({{"R", toValue(mul(U, transposeOf(V)))}, {"scale", Value(scale)}});
  } SP_END
  SP_ADD("matrix_balance", 1, 1, "A") {
    Mat A;
    if (!getSquare(a, 0, ctx, A))
      return Value(0.0);
    const size_t n = A.r;
    Vec t(n, 1.0);
    for (bool again = true; again;) {
      again = false;
      for (size_t i = 0; i < n; i++) {
        double c = 0.0, r = 0.0;
        for (size_t j = 0; j < n; j++)
          if (j != i) {
            c += std::fabs(A(j, i));
            r += std::fabs(A(i, j));
          }
        if (c == 0.0 || r == 0.0)
          continue;
        double f = 1.0, s = c + r;
        while (c < r / 2.0) {
          c *= 2.0;
          r /= 2.0;
          f *= 2.0;
        }
        while (c >= r * 2.0) {
          c /= 2.0;
          r *= 2.0;
          f /= 2.0;
        }
        if (c + r < 0.95 * s) {
          again = true;
          t[i] *= f;
          for (size_t j = 0; j < n; j++)
            A(i, j) /= f;
          for (size_t j = 0; j < n; j++)
            A(j, i) *= f;
        }
      }
    }
    return makeDict({{"B", toValue(A)}, {"T", toValue(diagMat(t, n, n))}});
  } SP_END
  SP_ADD("subspace_angles", 2, 2, "A, B") {
    Mat A, B;
    if (!getMat(a, 0, ctx, A) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r) {
      ctx.fail("the two matrices must have the same number of rows");
      return Value(0.0);
    }
    auto basis = [](const Mat &M) {
      Mat U, V;
      Vec s;
      svdThin(M, U, s, V);
      size_t rank = 0;
      for (double x : s)
        rank += x > kEps * static_cast<double>(std::max(M.r, M.c)) * s[0];
      Mat Q(M.r, rank);
      for (size_t i = 0; i < M.r; i++)
        for (size_t j = 0; j < rank; j++)
          Q(i, j) = U(i, j);
      return Q;
    };
    Mat Qa = basis(A), Qb = basis(B);
    if (Qa.c < Qb.c)
      std::swap(Qa, Qb);
    Mat U, V;
    Vec cosv;
    svdThin(mul(transposeOf(Qa), Qb), U, cosv, V);
    // Accurate for small angles: the sines from Qb - Qa Qa' Qb.
    Mat P = mul(Qa, mul(transposeOf(Qa), Qb));
    Mat D(Qb.r, Qb.c);
    for (size_t i = 0; i < D.a.size(); i++)
      D.a[i] = Qb.a[i] - P.a[i];
    Mat U2, V2;
    Vec sinv;
    svdThin(D, U2, sinv, V2);
    const size_t n = cosv.size();
    Vec out(n);
    for (size_t i = 0; i < n; i++)
      out[i] = cosv[i] * cosv[i] >= 0.5 ? std::asin(std::min(1.0, sinv[i]))
                                        : std::acos(std::min(1.0, cosv[n - 1 - i]));
    return toValue(out);
  } SP_END
  SP_ADD("bandwidth", 1, 1, "A") {
    CMat A;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    long lo = 0, up = 0;
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < A.c; j++)
        if (A(i, j) != cd(0.0)) {
          lo = std::max(lo, static_cast<long>(i) - static_cast<long>(j));
          up = std::max(up, static_cast<long>(j) - static_cast<long>(i));
        }
    return makeDict({{"lower", Value(static_cast<double>(lo))}, {"upper", Value(static_cast<double>(up))}});
  } SP_ENDC
  SP_ADD("is_symmetric", 1, 2, "A, atol=0") {
    CMat A;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    if (A.r != A.c)
      return Value::boolean(false);
    const double tol = optNum(a, 1, 0.0);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < i; j++)
        if (std::abs(A(i, j) - A(j, i)) > tol)
          return Value::boolean(false);
    return Value::boolean(true);
  } SP_ENDC
  SP_ADD("is_hermitian", 1, 2, "A, atol=0") {
    CMat A;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    if (A.r != A.c)
      return Value::boolean(false);
    const double tol = optNum(a, 1, 0.0);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j <= i; j++)
        if (std::abs(A(i, j) - std::conj(A(j, i))) > tol)
          return Value::boolean(false);
    return Value::boolean(true);
  } SP_ENDC
  SP_ADD("orth", 1, 1, "A") {
    CMat A, U, V;
    Vec s;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    svdThin(A, U, s, V);
    size_t rank = 0;
    for (double x : s)
      rank += x > kEps * static_cast<double>(std::max(A.r, A.c)) * s[0];
    CMat Q(A.r, rank);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < rank; j++)
        Q(i, j) = U(i, j);
    return realIfPossible(Q);
  } SP_ENDC
  SP_ADD("null_space", 1, 1, "A") {
    CMat A, U, V;
    Vec s;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    CMat Ah = adjointOf(A);
    svdThin(mul(Ah, A), U, s, V);
    // Singular values of A are the square roots of those of A^H A; use A itself for the cut.
    CMat U2, V2;
    Vec s2;
    svdThin(A, U2, s2, V2);
    CMat Vf = completeBasis(V2);
    size_t rank = 0;
    for (double x : s2)
      rank += x > kEps * static_cast<double>(std::max(A.r, A.c)) * s2[0];
    CMat N(A.c, A.c - rank);
    for (size_t i = 0; i < A.c; i++)
      for (size_t j = rank; j < A.c; j++)
        N(i, j - rank) = Vf(i, j);
    return realIfPossible(N);
  } SP_ENDC
  SP_ADD("svd_values", 1, 1, "A") {
    CMat A, U, V;
    Vec s;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    svdThin(A, U, s, V);
    return toValue(s);
  } SP_ENDC
  SP_ADD("diag_svd", 3, 3, "s, m, n") {
    Vec s;
    long long m, n;
    if (!getVec(a, 0, ctx, s) || !argNonNegativeInt(a, 1, ctx, m) || !argNonNegativeInt(a, 2, ctx, n))
      return Value(0.0);
    if (s.size() > static_cast<size_t>(std::min(m, n))) {
      ctx.fail("s has more values than fit on the diagonal");
      return Value(0.0);
    }
    return toValue(diagMat(s, (size_t)m, (size_t)n));
  } SP_END
  SP_ADD("expm_frechet", 2, 2, "A, E") {
    // exp of the block matrix [A E; 0 A] holds the derivative in its corner.
    CMat A, E;
    if (!getCSquare(a, 0, ctx, A) || !getCMat(a, 1, ctx, E))
      return Value(0.0);
    if (E.r != A.r || E.c != A.c) {
      ctx.fail("E must have the shape of A");
      return Value(0.0);
    }
    const size_t n = A.r;
    CMat M(2 * n, 2 * n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        M(i, j) = A(i, j);
        M(i + n, j + n) = A(i, j);
        M(i, j + n) = E(i, j);
      }
    CMat X = expm(M), Ex(n, n), L(n, n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        Ex(i, j) = X(i, j);
        L(i, j) = X(i, j + n);
      }
    if (!a[0].hasComplex() && !a[1].hasComplex()) {
      for (cd &z : Ex.a)
        z = z.real();
      for (cd &z : L.a)
        z = z.real();
    }
    return makeDict({{"expm", realIfPossible(Ex)}, {"frechet", realIfPossible(L)}});
  } SP_ENDC
  SP_ADD("expm_cond", 1, 1, "A") {
    // Relative condition number in the Frobenius norm: the largest direction
    // of the Frechet derivative, taken over the full basis (as SciPy).
    CMat A;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    const size_t n = A.r;
    Mat K(n * n, n * n);
    CMat Ex = expm(A);
    for (size_t p = 0; p < n * n; p++) {
      CMat M(2 * n, 2 * n);
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++) {
          M(i, j) = A(i, j);
          M(i + n, j + n) = A(i, j);
        }
      M(p / n, p % n + n) = 1.0;
      CMat X = expm(M);
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
          K(i * n + j, p) = X(i, j + n).real();
    }
    Mat U, V;
    Vec s;
    svdThin(K, U, s, V);
    return Value(s[0] * frobenius(A) / frobenius(Ex));
  } SP_ENDC
}

void registerDecompositions(Registry &reg) {
  SP_ADD("eig_banded", 1, 2, "ab, lower=0") {
    CMat ab, Z;
    Vec w;
    if (!getCMat(a, 0, ctx, ab))
      return Value(0.0);
    eigHermitian(symBandToDense(ab, optBool(a, 1, false)), w, Z);
    return makeDict({{"values", toValue(w)}, {"vectors", realIfPossible(Z)}});
  } SP_ENDC
  SP_ADD("eigvals_banded", 1, 2, "ab, lower=0") {
    CMat ab, Z;
    Vec w;
    if (!getCMat(a, 0, ctx, ab))
      return Value(0.0);
    eigHermitian(symBandToDense(ab, optBool(a, 1, false)), w, Z);
    return toValue(w);
  } SP_ENDC
  SP_ADD("eigh_tridiag", 2, 2, "d, e") {
    Vec d, e, w;
    Mat Z;
    if (!getVec(a, 0, ctx, d) || !getVec(a, 1, ctx, e))
      return Value(0.0);
    if (e.size() + 1 != d.size()) {
      ctx.fail("e must be one shorter than d");
      return Value(0.0);
    }
    Mat A(d.size(), d.size());
    for (size_t i = 0; i < d.size(); i++) {
      A(i, i) = d[i];
      if (i < e.size())
        A(i, i + 1) = A(i + 1, i) = e[i];
    }
    eigHermitian(A, w, Z);
    return makeDict({{"values", toValue(w)}, {"vectors", toValue(Z)}});
  } SP_END
  SP_ADD("eigvalsh_tridiag", 2, 2, "d, e") {
    Vec d, e, w;
    Mat Z;
    if (!getVec(a, 0, ctx, d) || !getVec(a, 1, ctx, e))
      return Value(0.0);
    if (e.size() + 1 != d.size()) {
      ctx.fail("e must be one shorter than d");
      return Value(0.0);
    }
    Mat A(d.size(), d.size());
    for (size_t i = 0; i < d.size(); i++) {
      A(i, i) = d[i];
      if (i < e.size())
        A(i, i + 1) = A(i + 1, i) = e[i];
    }
    eigHermitian(A, w, Z);
    return toValue(w);
  } SP_END
  SP_ADD("lu", 1, 1, "A") {
    CMat A;
    std::vector<size_t> piv;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    const size_t m = A.r, n = A.c, k = std::min(m, n);
    luFactor(A, piv);
    CMat P = CMat::eye(m), L(m, k), U(k, n);
    for (size_t i = 0; i < k; i++)
      if (piv[i] != i)
        for (size_t j = 0; j < m; j++)
          std::swap(P(j, i), P(j, piv[i]));
    for (size_t i = 0; i < m; i++)
      for (size_t j = 0; j < k; j++)
        L(i, j) = i == j ? cd(1.0) : (i > j ? A(i, j) : cd(0.0));
    for (size_t i = 0; i < k; i++)
      for (size_t j = i; j < n; j++)
        U(i, j) = A(i, j);
    return makeDict({{"P", realIfPossible(P)}, {"L", realIfPossible(L)}, {"U", realIfPossible(U)}});
  } SP_ENDC
  SP_ADD("lu_factor", 1, 1, "A") {
    CMat A;
    std::vector<size_t> piv;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    luFactor(A, piv);
    IVec p(piv.begin(), piv.end());
    return makeDict({{"lu", realIfPossible(A)}, {"piv", toValue(p)}});
  } SP_ENDC
  SP_ADD("lu_solve", 2, 2, "f, b") {
    CMat LU, B;
    Vec p;
    bool isV;
    const Value *lu = dictGet(a[0], "lu"), *pv = dictGet(a[0], "piv");
    if (!lu || !pv || !readCMat(*lu, LU) || !readVec(*pv, p)) {
      ctx.fail("the first argument must be the result of lu_factor()");
      return Value(0.0);
    }
    if (!getRhs(a, 1, ctx, B, isV))
      return Value(0.0);
    if (B.r != LU.r) {
      ctx.fail("b must have as many rows as the matrix");
      return Value(0.0);
    }
    std::vector<size_t> piv(p.begin(), p.end());
    luSolveInPlace(LU, piv, B);
    return rhsResult(B, isV);
  } SP_ENDC
  SP_ADD("ldl", 1, 1, "A") {
    CMat A, L, D;
    IVec perm;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    bunchKaufman(A, L, D, perm);
    // L in the original row order: A = L D L^H.
    CMat Lo(A.r, A.r);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < A.r; j++)
        Lo(static_cast<size_t>(perm[i]), j) = L(i, j);
    return makeDict({{"L", realIfPossible(Lo)}, {"D", realIfPossible(D)}, {"perm", toValue(perm)}});
  } SP_ENDC
  SP_ADD("cholesky_banded", 1, 2, "ab, lower=0") {
    CMat ab, L;
    if (!getCMat(a, 0, ctx, ab))
      return Value(0.0);
    const bool lower = optBool(a, 1, false);
    if (!cholLower(symBandToDense(ab, lower), L)) {
      ctx.fail("the matrix is not positive definite");
      return Value(0.0);
    }
    CMat cb(ab.r, ab.c);
    const size_t w = ab.r - 1, n = ab.c;
    for (size_t j = 0; j < n; j++)
      for (size_t d = 0; d <= w; d++) {
        if (lower) {
          if (j + d < n)
            cb(d, j) = L(j + d, j);
        } else if (j >= d) {
          cb(w - d, j) = std::conj(L(j, j - d));
        }
      }
    return realIfPossible(cb);
  } SP_ENDC
  SP_ADD("cho_factor", 1, 2, "A, lower=0") {
    CMat A, L;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    if (!cholLower(A, L)) {
      ctx.fail("the matrix is not positive definite");
      return Value(0.0);
    }
    const bool lower = optBool(a, 1, false);
    return makeDict({{"c", realIfPossible(lower ? L : adjointOf(L))}, {"lower", Value::boolean(lower)}});
  } SP_ENDC
  SP_ADD("cho_solve", 2, 2, "f, b") {
    CMat C, B;
    bool isV;
    const Value *c = dictGet(a[0], "c"), *lo = dictGet(a[0], "lower");
    if (!c || !lo || !readCMat(*c, C)) {
      ctx.fail("the first argument must be the result of cho_factor()");
      return Value(0.0);
    }
    if (!getRhs(a, 1, ctx, B, isV))
      return Value(0.0);
    CMat L = lo->number != 0.0 ? C : adjointOf(C);
    CMat A = mul(L, adjointOf(L));
    solve(A, B);
    return rhsResult(B, isV);
  } SP_ENDC
  SP_ADD("cho_solve_banded", 3, 3, "cb, lower, b") {
    CMat cb, B;
    bool isV;
    if (!getCMat(a, 0, ctx, cb) || !getRhs(a, 2, ctx, B, isV))
      return Value(0.0);
    const bool lower = optBool(a, 1, false);
    const size_t w = cb.r - 1, n = cb.c;
    if (B.r != n) {
      ctx.fail("b must have one row per column of cb");
      return Value(0.0);
    }
    CMat L(n, n);
    for (size_t j = 0; j < n; j++)
      for (size_t d = 0; d <= w; d++) {
        if (lower) {
          if (j + d < n)
            L(j + d, j) = cb(d, j);
        } else if (j >= d) {
          L(j, j - d) = std::conj(cb(w - d, j));
        }
      }
    solve(mul(L, adjointOf(L)), B);
    return rhsResult(B, isV);
  } SP_ENDC
  SP_ADD("polar", 1, 2, "A, side=\"right\"") {
    CMat A, U, V;
    Vec s;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    svdThin(A, U, s, V);
    CMat W = mul(U, adjointOf(V));
    CMat S(s.size(), s.size());
    for (size_t i = 0; i < s.size(); i++)
      S(i, i) = s[i];
    const bool left = optText(a, 1, "right") == "left";
    CMat P = left ? mul(mul(U, S), adjointOf(U)) : mul(mul(V, S), adjointOf(V));
    return makeDict({{"U", realIfPossible(W)}, {"P", realIfPossible(P)}});
  } SP_ENDC
  SP_ADD("qr_multiply", 2, 2, "A, C") {
    CMat A, C, Q, R;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, C))
      return Value(0.0);
    if (C.r != A.c && C.r != A.r) {
      ctx.fail("C does not fit Q");
      return Value(0.0);
    }
    qrFactor(A, Q, R);
    return makeDict({{"CQ", realIfPossible(mul(C, Q))}, {"R", realIfPossible(R)}});
  } SP_ENDC
  SP_ADD("qr_update", 4, 4, "Q, R, u, v") {
    CMat Q, R, Q2, R2;
    CVec u, v;
    if (!getCMat(a, 0, ctx, Q) || !getCMat(a, 1, ctx, R) || !getCVec(a, 2, ctx, u) || !getCVec(a, 3, ctx, v))
      return Value(0.0);
    if (u.size() != Q.r || v.size() != R.c) {
      ctx.fail("u must fit the rows of Q and v the columns of R");
      return Value(0.0);
    }
    CMat A = mul(Q, R);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < A.c; j++)
        A(i, j) += u[i] * std::conj(v[j]);
    qrFactor(A, Q2, R2);
    return makeDict({{"Q", realIfPossible(Q2)}, {"R", realIfPossible(R2)}});
  } SP_ENDC
  SP_ADD("qr_delete", 3, 5, "Q, R, k, p=1, which=\"row\"") {
    CMat Q, R, Q2, R2;
    long long k;
    if (!getCMat(a, 0, ctx, Q) || !getCMat(a, 1, ctx, R) || !argNonNegativeInt(a, 2, ctx, k))
      return Value(0.0);
    const long long p = optInt(a, 3, 1);
    const std::string which = optText(a, 4, "row");
    CMat A = mul(Q, R);
    const bool row = which == "row";
    if ((row ? static_cast<size_t>(k + p) > A.r : static_cast<size_t>(k + p) > A.c) || p < 0) {
      ctx.fail("the rows or columns to delete lie outside the matrix");
      return Value(0.0);
    }
    CMat B(row ? A.r - p : A.r, row ? A.c : A.c - p);
    for (size_t i = 0; i < B.r; i++)
      for (size_t j = 0; j < B.c; j++)
        B(i, j) = A(row && (long long)i >= k ? i + p : i, !row && (long long)j >= k ? j + p : j);
    qrFactor(B, Q2, R2);
    return makeDict({{"Q", realIfPossible(Q2)}, {"R", realIfPossible(R2)}});
  } SP_ENDC
  SP_ADD("qr_insert", 4, 5, "Q, R, u, k, which=\"row\"") {
    CMat Q, R, Q2, R2;
    CVec u;
    long long k;
    if (!getCMat(a, 0, ctx, Q) || !getCMat(a, 1, ctx, R) || !getCVec(a, 2, ctx, u) || !argNonNegativeInt(a, 3, ctx, k))
      return Value(0.0);
    const bool row = optText(a, 4, "row") == "row";
    CMat A = mul(Q, R);
    if (u.size() != (row ? A.c : A.r) || static_cast<size_t>(k) > (row ? A.r : A.c)) {
      ctx.fail("the new row or column does not fit the matrix");
      return Value(0.0);
    }
    CMat B(row ? A.r + 1 : A.r, row ? A.c : A.c + 1);
    for (size_t i = 0; i < B.r; i++)
      for (size_t j = 0; j < B.c; j++) {
        if (row && (long long)i == k)
          B(i, j) = u[j];
        else if (!row && (long long)j == k)
          B(i, j) = u[i];
        else
          B(i, j) = A(row && (long long)i > k ? i - 1 : i, !row && (long long)j > k ? j - 1 : j);
      }
    qrFactor(B, Q2, R2);
    return makeDict({{"Q", realIfPossible(Q2)}, {"R", realIfPossible(R2)}});
  } SP_ENDC
  SP_ADD("rq", 1, 1, "A") {
    // RQ of A from QR of the flipped adjoint.
    CMat A, Q0, R0;
    if (!getCMat(a, 0, ctx, A))
      return Value(0.0);
    const size_t m = A.r, n = A.c;
    CMat F(n, m);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < m; j++)
        F(i, j) = std::conj(A(m - 1 - j, n - 1 - i));
    qrFactor(F, Q0, R0);
    CMat R(m, n), Q(n, n);
    for (size_t i = 0; i < m; i++)
      for (size_t j = 0; j < n; j++)
        R(i, j) = std::conj(R0(n - 1 - j, m - 1 - i));
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        Q(i, j) = std::conj(Q0(n - 1 - j, n - 1 - i));
    return makeDict({{"R", realIfPossible(R)}, {"Q", realIfPossible(Q)}});
  } SP_ENDC
  SP_ADD("qz", 2, 3, "A, B, output=\"real\"") {
    CMat A, B, AA, BB, Q, Z;
    if (!getCSquare(a, 0, ctx, A) || !getCSquare(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r) {
      ctx.fail("A and B must have the same size");
      return Value(0.0);
    }
    complexQZ(A, B, AA, BB, Q, Z);
    return makeDict({{"AA", realIfPossible(AA)}, {"BB", realIfPossible(BB)}, {"Q", realIfPossible(Q)}, {"Z", realIfPossible(Z)}});
  } SP_ENDC
  SP_ADD("ordqz", 2, 3, "A, B, sort=\"lhp\"") {
    CMat A, B, AA, BB, Q, Z;
    if (!getCSquare(a, 0, ctx, A) || !getCSquare(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r) {
      ctx.fail("A and B must have the same size");
      return Value(0.0);
    }
    const std::string sort = optText(a, 2, "lhp");
    if (sort != "lhp" && sort != "rhp" && sort != "iuc" && sort != "ouc") {
      ctx.fail("sort must be \"lhp\", \"rhp\", \"iuc\" or \"ouc\"");
      return Value(0.0);
    }
    complexQZ(A, B, AA, BB, Q, Z);
    std::vector<bool> keep(A.r);
    for (size_t i = 0; i < A.r; i++) {
      if (BB(i, i) == cd(0.0)) {
        keep[i] = sort == "ouc";
        continue;
      }
      cd e = AA(i, i) / BB(i, i);
      keep[i] = sort == "lhp" ? e.real() < 0 : sort == "rhp" ? e.real() > 0 : sort == "iuc" ? std::abs(e) < 1 : std::abs(e) > 1;
    }
    reorderQZ(AA, BB, Q, Z, keep);
    CVec al(A.r), be(A.r);
    for (size_t i = 0; i < A.r; i++) {
      al[i] = AA(i, i);
      be[i] = BB(i, i);
    }
    return makeDict({{"AA", realIfPossible(AA)}, {"BB", realIfPossible(BB)}, {"alpha", realIfPossible(al)}, {"beta", realIfPossible(be)}, {"Q", realIfPossible(Q)}, {"Z", realIfPossible(Z)}});
  } SP_ENDC
  SP_ADD("schur", 1, 2, "A, output=\"real\"") {
    const std::string out = optText(a, 1, "real");
    if (!a[0].hasComplex() && out == "real") {
      Mat A, T_, Z;
      if (!getSquare(a, 0, ctx, A))
        return Value(0.0);
      realSchur(A, T_, Z);
      return makeDict({{"T", toValue(T_)}, {"Z", toValue(Z)}});
    }
    CMat A, T_, Z;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    complexSchur(A, T_, Z);
    return makeDict({{"T", toValue(T_)}, {"Z", toValue(Z)}});
  } SP_ENDC
  SP_ADD("rsf2csf", 2, 2, "T, Z") {
    CMat T_, Z;
    if (!getCSquare(a, 0, ctx, T_) || !getCSquare(a, 1, ctx, Z))
      return Value(0.0);
    const size_t n = T_.r;
    for (size_t m = n; m-- > 1;) {
      if (std::abs(T_(m, m - 1)) > kEps * (std::abs(T_(m - 1, m - 1)) + std::abs(T_(m, m)))) {
        cd aa = T_(m - 1, m - 1), bb = T_(m - 1, m), cc = T_(m, m - 1), dd = T_(m, m);
        cd e = (aa + dd) / 2.0 + std::sqrt((aa - dd) * (aa - dd) / 4.0 + bb * cc);
        cd mu = e - dd;
        double r = std::hypot(std::abs(mu), std::abs(cc));
        cd co = mu / r, si = cc / r;
        for (size_t j = m - 1; j < n; j++) {
          cd u = T_(m - 1, j), v = T_(m, j);
          T_(m - 1, j) = std::conj(co) * u + si * v;
          T_(m, j) = -si * u + co * v;
        }
        for (size_t i = 0; i <= m; i++) {
          cd u = T_(i, m - 1), v = T_(i, m);
          T_(i, m - 1) = co * u + si * v;
          T_(i, m) = -si * u + std::conj(co) * v;
        }
        for (size_t i = 0; i < n; i++) {
          cd u = Z(i, m - 1), v = Z(i, m);
          Z(i, m - 1) = co * u + si * v;
          Z(i, m) = -si * u + std::conj(co) * v;
        }
      }
      T_(m, m - 1) = 0.0;
    }
    return makeDict({{"T", toValue(T_)}, {"Z", toValue(Z)}});
  } SP_ENDC
  SP_ADD("hessenberg", 1, 2, "A, calc_q=0") {
    CMat A, H, Q;
    if (!getCSquare(a, 0, ctx, A))
      return Value(0.0);
    la::hessenberg(A, H, Q);
    if (optBool(a, 1, false))
      return makeDict({{"H", realIfPossible(H)}, {"Q", realIfPossible(Q)}});
    return realIfPossible(H);
  } SP_ENDC
  SP_ADD("cdf2rdf", 2, 2, "w, v") {
    CVec w;
    CMat v;
    if (!getCVec(a, 0, ctx, w) || !getCSquare(a, 1, ctx, v))
      return Value(0.0);
    const size_t n = w.size();
    if (v.r != n) {
      ctx.fail("v must have one column per value of w");
      return Value(0.0);
    }
    Mat wr(n, n), vr(n, n);
    for (size_t j = 0; j < n; j++) {
      if (w[j].imag() == 0.0) {
        wr(j, j) = w[j].real();
        for (size_t i = 0; i < n; i++)
          vr(i, j) = v(i, j).real();
        continue;
      }
      if (j + 1 >= n || w[j + 1] != std::conj(w[j])) {
        ctx.fail("complex eigenvalues must come in adjacent conjugate pairs");
        return Value(0.0);
      }
      wr(j, j) = wr(j + 1, j + 1) = w[j].real();
      wr(j, j + 1) = w[j].imag();
      wr(j + 1, j) = -w[j].imag();
      for (size_t i = 0; i < n; i++) {
        vr(i, j) = v(i, j).real();
        vr(i, j + 1) = v(i, j).imag();
      }
      j++;
    }
    return makeDict({{"wr", toValue(wr)}, {"vr", toValue(vr)}});
  } SP_ENDC
  SP_ADD("cossin", 3, 3, "X, p, q") {
    Mat X, U, CS, Vh;
    long long p, q;
    if (!getSquare(a, 0, ctx, X) || !argNonNegativeInt(a, 1, ctx, p) || !argNonNegativeInt(a, 2, ctx, q))
      return Value(0.0);
    if ((size_t)p > X.r || (size_t)q > X.r) {
      ctx.fail("p and q must not exceed the matrix size");
      return Value(0.0);
    }
    cosSin(X, (size_t)p, (size_t)q, U, CS, Vh);
    return makeDict({{"U", toValue(U)}, {"CS", toValue(CS)}, {"VDH", toValue(Vh)}});
  } SP_END
}

void registerSpecialMatrices(Registry &reg) {
  SP_ADD("block_diag", 1, kVariadic, "A, B, ...") {
    size_t rows = 0, cols = 0;
    std::vector<CMat> ms(a.size());
    for (size_t i = 0; i < a.size(); i++) {
      if (!getCMat(a, i, ctx, ms[i]))
        return Value(0.0);
      rows += ms[i].r;
      cols += ms[i].c;
    }
    CMat B(rows, cols);
    size_t r0 = 0, c0 = 0;
    for (const CMat &m : ms) {
      for (size_t i = 0; i < m.r; i++)
        for (size_t j = 0; j < m.c; j++)
          B(r0 + i, c0 + j) = m(i, j);
      r0 += m.r;
      c0 += m.c;
    }
    return realIfPossible(B);
  } SP_ENDC
  SP_ADD("circulant", 1, 1, "c") {
    CVec c;
    if (!getCVec(a, 0, ctx, c))
      return Value(0.0);
    const size_t n = c.size();
    CMat C(n, n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        C(i, j) = c[(i + n - j) % n];
    return realIfPossible(C);
  } SP_ENDC
  SP_ADD("companion", 1, 1, "coeffs") {
    CVec c;
    if (!getCVec(a, 0, ctx, c))
      return Value(0.0);
    if (c.size() < 2 || c[0] == cd(0.0)) {
      ctx.fail("coeffs needs at least two values and a first value that is not zero");
      return Value(0.0);
    }
    const size_t n = c.size() - 1;
    CMat C(n, n);
    for (size_t j = 0; j < n; j++)
      C(0, j) = -c[j + 1] / c[0];
    for (size_t i = 1; i < n; i++)
      C(i, i - 1) = 1.0;
    return realIfPossible(C);
  } SP_ENDC
  SP_ADD("convolution_matrix", 2, 3, "a, n, mode=\"full\"") {
    CVec k;
    long long n;
    if (!getCVec(a, 0, ctx, k) || !argNonNegativeInt(a, 1, ctx, n))
      return Value(0.0);
    const std::string mode = optText(a, 2, "full");
    const size_t m = k.size(), N = (size_t)n;
    if (m == 0 || N == 0) {
      ctx.fail("the kernel and n must not be empty");
      return Value(0.0);
    }
    const size_t full = m + N - 1;
    size_t start = 0, rows = full;
    if (mode == "same") {
      rows = std::max(m, N);
      start = (full - rows) / 2;
    } else if (mode == "valid") {
      rows = std::max(m, N) - std::min(m, N) + 1;
      start = std::min(m, N) - 1;
    } else if (mode != "full") {
      ctx.fail("mode must be \"full\", \"same\" or \"valid\"");
      return Value(0.0);
    }
    CMat C(rows, N);
    for (size_t i = 0; i < rows; i++)
      for (size_t j = 0; j < N; j++) {
        const size_t f = i + start;
        if (f >= j && f - j < m)
          C(i, j) = k[f - j];
      }
    return realIfPossible(C);
  } SP_ENDC
  SP_ADD("dft_matrix", 1, 2, "n, scale=\"\"") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    const std::string scale = optText(a, 1, "");
    const double f = scale == "sqrtn" ? 1.0 / std::sqrt((double)n) : scale == "n" ? 1.0 / (double)n : 1.0;
    CMat D((size_t)n, (size_t)n);
    for (long long i = 0; i < n; i++)
      for (long long j = 0; j < n; j++) {
        const long long k = (i * j) % n;
        // Exact at the multiples of a quarter turn.
        cd w = (4 * k) % n == 0 ? (k * 4 / n == 0 ? cd(1, 0) : k * 4 / n == 1 ? cd(0, -1) : k * 4 / n == 2 ? cd(-1, 0) : cd(0, 1))
                                : std::polar(1.0, -2.0 * kPi * (double)k / (double)n);
        D((size_t)i, (size_t)j) = w * f;
      }
    return toValue(D);
  } SP_END
  SP_ADD("fiedler", 1, 1, "a") {
    Vec v;
    if (!getVec(a, 0, ctx, v))
      return Value(0.0);
    Mat F(v.size(), v.size());
    for (size_t i = 0; i < v.size(); i++)
      for (size_t j = 0; j < v.size(); j++)
        F(i, j) = std::fabs(v[i] - v[j]);
    return toValue(F);
  } SP_END
  SP_ADD("fiedler_companion", 1, 1, "coeffs") {
    CVec c;
    if (!getCVec(a, 0, ctx, c))
      return Value(0.0);
    if (c.size() < 2 || c[0] == cd(0.0)) {
      ctx.fail("coeffs needs at least two values and a first value that is not zero");
      return Value(0.0);
    }
    for (size_t i = c.size(); i-- > 0;)
      c[i] /= c[0];
    const size_t n = c.size() - 1;
    if (n == 1)
      return scalarOf(-c[1]);
    CMat F(n, n);
    // The pentadiagonal pattern of scipy.linalg.fiedler_companion.
    for (size_t i = 3, j = 1; i < n; i += 2, j += 2)
      F(i, j) = 1.0;
    for (size_t i = 2, j = 1, m = 3; i < n; i += 2, j += 2, m += 2)
      F(i, j) = -c[m];
    for (size_t i = 0, j = 2; j < n; i += 2, j += 2)
      F(i, j) = 1.0;
    for (size_t i = 0, j = 1, m = 2; j < n; i += 2, j += 2, m += 2)
      F(i, j) = -c[m];
    F(0, 0) = -c[1];
    F(1, 0) = 1.0;
    return realIfPossible(F);
  } SP_ENDC
  SP_ADD("hadamard", 1, 1, "n") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    if (n < 1 || (n & (n - 1)) != 0) {
      ctx.fail("n must be a power of 2");
      return Value(0.0);
    }
    Mat H((size_t)n, (size_t)n, 1.0);
    for (size_t i = 0; i < H.r; i++)
      for (size_t j = 0; j < H.c; j++) {
        size_t b = i & j;
        int parity = 0;
        for (; b; b >>= 1)
          parity ^= b & 1;
        H(i, j) = parity ? -1.0 : 1.0;
      }
    return toValue(H);
  } SP_END
  SP_ADD("hankel", 1, 2, "c, r") {
    CVec c, r;
    if (!getCVec(a, 0, ctx, c))
      return Value(0.0);
    if (a.size() > 1) {
      if (!getCVec(a, 1, ctx, r))
        return Value(0.0);
    } else {
      r.assign(c.size(), 0.0);
    }
    CMat H(c.size(), r.size());
    for (size_t i = 0; i < H.r; i++)
      for (size_t j = 0; j < H.c; j++)
        H(i, j) = i + j < c.size() ? c[i + j] : r[i + j - c.size() + 1];
    return realIfPossible(H);
  } SP_ENDC
  SP_ADD("helmert", 1, 2, "n, full=0") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    const bool full = optBool(a, 1, false);
    const size_t N = (size_t)n;
    Mat H(N, N);
    for (size_t j = 0; j < N; j++)
      H(0, j) = 1.0 / std::sqrt((double)N);
    for (size_t i = 1; i < N; i++) {
      const double d = std::sqrt((double)(i * (i + 1)));
      for (size_t j = 0; j < i; j++)
        H(i, j) = 1.0 / d;
      H(i, i) = -(double)i / d;
    }
    if (full)
      return toValue(H);
    Mat S(N ? N - 1 : 0, N);
    for (size_t i = 1; i < N; i++)
      for (size_t j = 0; j < N; j++)
        S(i - 1, j) = H(i, j);
    return toValue(S);
  } SP_END
  // Two tables share this name: hilbert(n) builds the matrix (linalg.hilbert),
  // hilbert(data) gives the analytic signal (signal.hilbert).
  SP_ADD("hilbert", 1, 2, "n  or  data[, n]") {
    if (a.size() == 1 && isPlainNumber(a[0])) {
      long long n;
      if (!argNonNegativeInt(a, 0, ctx, n))
        return Value(0.0);
      Mat H((size_t)n, (size_t)n);
      for (size_t i = 0; i < H.r; i++)
        for (size_t j = 0; j < H.c; j++)
          H(i, j) = 1.0 / (double)(i + j + 1);
      return toValue(H);
    }
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    return toValue(sg::analytic(x, (size_t)optInt(a, 1, (long long)x.size())));
  } SP_END
  SP_ADD("inv_hilbert", 1, 1, "n") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    auto binom = [](long long nn, long long k) {
      double b = 1.0;
      for (long long i = 1; i <= k; i++)
        b = b * (double)(nn - k + i) / (double)i;
      return std::round(b);
    };
    Mat H((size_t)n, (size_t)n);
    for (long long i = 0; i < n; i++)
      for (long long j = 0; j <= i; j++) {
        double s = (i + j) % 2 ? -1.0 : 1.0;
        double v = s * (double)(i + j + 1) * binom(n + i, n - j - 1) * binom(n + j, n - i - 1) *
                   binom(i + j, i) * binom(i + j, i);
        H((size_t)i, (size_t)j) = H((size_t)j, (size_t)i) = v;
      }
    return toValue(H);
  } SP_END
  SP_ADD("leslie", 2, 2, "f, s") {
    Vec f, s;
    if (!getVec(a, 0, ctx, f) || !getVec(a, 1, ctx, s))
      return Value(0.0);
    if (f.empty() || s.size() + 1 != f.size()) {
      ctx.fail("s must be one shorter than f");
      return Value(0.0);
    }
    Mat L(f.size(), f.size());
    for (size_t j = 0; j < f.size(); j++)
      L(0, j) = f[j];
    for (size_t i = 0; i < s.size(); i++)
      L(i + 1, i) = s[i];
    return toValue(L);
  } SP_END
  SP_ADD("pascal", 1, 2, "n, kind=\"symmetric\"") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    const std::string kind = optText(a, 1, "symmetric");
    if (kind != "symmetric" && kind != "lower" && kind != "upper") {
      ctx.fail("kind must be \"symmetric\", \"lower\" or \"upper\"");
      return Value(0.0);
    }
    Mat L((size_t)n, (size_t)n);
    for (size_t i = 0; i < L.r; i++) {
      L(i, 0) = 1.0;
      for (size_t j = 1; j <= i; j++)
        L(i, j) = L(i - 1, j - 1) + (j < i ? L(i - 1, j) : 0.0);
    }
    if (kind == "lower")
      return toValue(L);
    if (kind == "upper")
      return toValue(transposeOf(L));
    return toValue(mul(L, transposeOf(L)));
  } SP_END
  SP_ADD("inv_pascal", 1, 2, "n, kind=\"symmetric\"") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    const std::string kind = optText(a, 1, "symmetric");
    if (kind != "symmetric" && kind != "lower" && kind != "upper") {
      ctx.fail("kind must be \"symmetric\", \"lower\" or \"upper\"");
      return Value(0.0);
    }
    Mat L((size_t)n, (size_t)n);
    for (size_t i = 0; i < L.r; i++) {
      L(i, 0) = i == 0 ? 1.0 : 1.0;
      for (size_t j = 1; j <= i; j++)
        L(i, j) = L(i - 1, j - 1) + (j < i ? L(i - 1, j) : 0.0);
    }
    Mat Li = L; // inverse of lower Pascal: the same entries with alternating signs
    for (size_t i = 0; i < L.r; i++)
      for (size_t j = 0; j <= i; j++)
        Li(i, j) = ((i + j) % 2 ? -1.0 : 1.0) * L(i, j);
    if (kind == "lower")
      return toValue(Li);
    if (kind == "upper")
      return toValue(transposeOf(Li));
    return toValue(mul(transposeOf(Li), Li));
  } SP_END
  SP_ADD("toeplitz", 1, 2, "c, r") {
    CVec c, r;
    if (!getCVec(a, 0, ctx, c))
      return Value(0.0);
    if (a.size() > 1) {
      if (!getCVec(a, 1, ctx, r))
        return Value(0.0);
    } else {
      r = c;
      for (cd &z : r)
        z = std::conj(z);
    }
    return realIfPossible(toeplitzDense(c, r));
  } SP_ENDC
  SP_ADD("sketch", 2, 3, "A, rows, seed") {
    Mat A;
    long long rows;
    if (!getMat(a, 0, ctx, A) || !argNonNegativeInt(a, 1, ctx, rows))
      return Value(0.0);
    std::mt19937_64 gen = rngFor(a, 2);
    Mat S((size_t)rows, A.c);
    for (size_t i = 0; i < A.r; i++) {
      const size_t h = rows ? gen() % (unsigned long long)rows : 0;
      const double sg = (gen() & 1) ? 1.0 : -1.0;
      for (size_t j = 0; j < A.c; j++)
        S(h, j) += sg * A(i, j);
    }
    return toValue(S);
  } SP_END
}

void registerLowLevelAndInterpolative(Registry &reg) {
  SP_ADD("blas_function", 1, 2, "name, arrays") {
    std::string n;
    if (!argText(a, 0, ctx, n))
      return Value(0.0);
    return Value(blasPrefix(a, 1) + n);
  } SP_ENDC
  SP_ADD("lapack_function", 1, 2, "name, arrays") {
    std::string n;
    if (!argText(a, 0, ctx, n))
      return Value(0.0);
    return Value(blasPrefix(a, 1) + n);
  } SP_ENDC
  SP_ADD("best_blas_type", 0, 1, "arrays") {
    const bool c = !a.empty() && a[0].hasComplex();
    return makeDict({{"prefix", Value(std::string(c ? "z" : "d"))},
                     {"dtype", Value(std::string(c ? "complex128" : "float64"))}});
  } SP_ENDC
  SP_ADD("interp_decomp", 2, 2, "A, k") {
    Mat A, R;
    IVec perm;
    if (!getMat(a, 0, ctx, A) || !isNumberArg(a, 1)) {
      if (ctx.ok())
        ctx.fail("the second argument must be a rank or an accuracy");
      return Value(0.0);
    }
    pivotedQR(A, R, perm);
    size_t k = 0;
    const double kv = a[1].number;
    if (kv >= 1.0 && kv == std::floor(kv)) {
      k = std::min<size_t>((size_t)kv, std::min(A.r, A.c));
    } else {
      const double cut = kv * std::fabs(R(0, 0));
      while (k < std::min(A.r, A.c) && std::fabs(R(k, k)) > cut)
        k++;
    }
    Mat proj(k, A.c - k);
    for (size_t j = k; j < A.c; j++) {
      for (size_t ii = k; ii-- > 0;) {
        double s = R(ii, j);
        for (size_t l = ii + 1; l < k; l++)
          s -= R(ii, l) * proj(l, j - k);
        proj(ii, j - k) = s / R(ii, ii);
      }
    }
    return makeDict({{"idx", toValue(perm)}, {"proj", toValue(proj)}});
  } SP_END
  SP_ADD("id_interp_matrix", 2, 2, "idx, proj") {
    Vec idx;
    Mat proj;
    if (!getVec(a, 0, ctx, idx) || !getMat(a, 1, ctx, proj))
      return Value(0.0);
    const size_t n = idx.size(), k = proj.r ? proj.r : (proj.c <= n ? n - proj.c : n + 1);
    for (double v : idx)
      if (v < 0 || v >= (double)n || v != std::floor(v)) {
        ctx.fail("idx must hold column numbers from 0 to " + std::to_string(n ? n - 1 : 0));
        return Value(0.0);
      }
    if (k > n || (proj.a.size() && (proj.r != k || proj.c != n - k))) {
      ctx.fail("proj must be k x (n - k) for these idx");
      return Value(0.0);
    }
    Mat P(k, n);
    for (size_t i = 0; i < k; i++) {
      P(i, (size_t)idx[i]) = 1.0;
      for (size_t j = k; j < n; j++)
        P(i, (size_t)idx[j]) = proj(i, j - k);
    }
    return toValue(P);
  } SP_END
  SP_ADD("id_reconstruct", 3, 3, "B, idx, proj") {
    Mat B, proj;
    Vec idx;
    if (!getMat(a, 0, ctx, B) || !getVec(a, 1, ctx, idx) || !getMat(a, 2, ctx, proj))
      return Value(0.0);
    const size_t n = idx.size(), k = B.c;
    if (proj.r != k && proj.a.size() != 0) {
      ctx.fail("proj must have one row per column of B");
      return Value(0.0);
    }
    for (double v : idx)
      if (v < 0 || v >= (double)n || v != std::floor(v)) {
        ctx.fail("idx must hold column numbers from 0 to " + std::to_string(n ? n - 1 : 0));
        return Value(0.0);
      }
    if (k > n || (proj.a.size() && (proj.r != k || proj.c != n - k))) {
      ctx.fail("proj must be k x (n - k) for these idx");
      return Value(0.0);
    }
    Mat P(k, n);
    for (size_t i = 0; i < k; i++) {
      P(i, (size_t)idx[i]) = 1.0;
      for (size_t j = k; j < n; j++)
        P(i, (size_t)idx[j]) = proj(i, j - k);
    }
    return toValue(mul(B, P));
  } SP_END
  SP_ADD("id_skeleton", 3, 3, "A, k, idx") {
    Mat A;
    long long k;
    Vec idx;
    if (!getMat(a, 0, ctx, A) || !argNonNegativeInt(a, 1, ctx, k) || !getVec(a, 2, ctx, idx))
      return Value(0.0);
    if ((size_t)k > idx.size()) {
      ctx.fail("k is larger than idx");
      return Value(0.0);
    }
    Mat B(A.r, (size_t)k);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < (size_t)k; j++)
        B(i, j) = A(i, (size_t)idx[j]);
    return toValue(B);
  } SP_END
  SP_ADD("id_to_svd", 3, 3, "B, idx, proj") {
    Mat B, proj;
    Vec idx;
    if (!getMat(a, 0, ctx, B) || !getVec(a, 1, ctx, idx) || !getMat(a, 2, ctx, proj))
      return Value(0.0);
    const size_t n = idx.size(), k = B.c;
    for (double v : idx)
      if (v < 0 || v >= (double)n || v != std::floor(v)) {
        ctx.fail("idx must hold column numbers from 0 to " + std::to_string(n ? n - 1 : 0));
        return Value(0.0);
      }
    if (k > n || (proj.a.size() && (proj.r != k || proj.c != n - k))) {
      ctx.fail("proj must be k x (n - k) for these idx");
      return Value(0.0);
    }
    Mat P(k, n);
    for (size_t i = 0; i < k; i++) {
      P(i, (size_t)idx[i]) = 1.0;
      for (size_t j = k; j < n; j++)
        P(i, (size_t)idx[j]) = proj(i, j - k);
    }
    Mat U, V;
    Vec s;
    svdThin(mul(B, P), U, s, V);
    s.resize(k);
    Mat Uk(U.r, k), Vk(V.r, k);
    for (size_t j = 0; j < k; j++) {
      for (size_t i = 0; i < U.r; i++)
        Uk(i, j) = U(i, j);
      for (size_t i = 0; i < V.r; i++)
        Vk(i, j) = V(i, j);
    }
    return makeDict({{"U", toValue(Uk)}, {"S", toValue(s)}, {"V", toValue(Vk)}});
  } SP_END
  SP_ADD("svd_approx", 2, 2, "A, k") {
    Mat A, U, V;
    Vec s;
    if (!getMat(a, 0, ctx, A) || !isNumberArg(a, 1)) {
      if (ctx.ok())
        ctx.fail("the second argument must be a rank or an accuracy");
      return Value(0.0);
    }
    svdThin(A, U, s, V);
    const double kv = a[1].number;
    size_t k = 0;
    if (kv >= 1.0 && kv == std::floor(kv))
      k = std::min((size_t)kv, s.size());
    else
      while (k < s.size() && s[k] > kv * s[0])
        k++;
    Mat Uk(U.r, k), Vk(V.r, k);
    for (size_t j = 0; j < k; j++) {
      for (size_t i = 0; i < U.r; i++)
        Uk(i, j) = U(i, j);
      for (size_t i = 0; i < V.r; i++)
        Vk(i, j) = V(i, j);
    }
    s.resize(k);
    return makeDict({{"U", toValue(Uk)}, {"S", toValue(s)}, {"V", toValue(Vk)}});
  } SP_END
  SP_ADD("estimate_rank", 2, 2, "A, eps") {
    Mat A, U, V;
    Vec s;
    double e;
    if (!getMat(a, 0, ctx, A) || !argNumber(a, 1, ctx, e))
      return Value(0.0);
    svdThin(A, U, s, V);
    size_t k = 0;
    while (k < s.size() && s[k] > e * s[0])
      k++;
    return Value((double)k);
  } SP_END
  SP_ADD("estimate_norm", 1, 2, "A, its=20") {
    Mat A;
    if (!getMat(a, 0, ctx, A))
      return Value(0.0);
    return Value(powerNorm(A, optInt(a, 1, 20)));
  } SP_END
  SP_ADD("estimate_norm_diff", 2, 3, "A, B, its=20") {
    Mat A, B;
    if (!getMat(a, 0, ctx, A) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (A.r != B.r || A.c != B.c) {
      ctx.fail("A and B must have the same shape");
      return Value(0.0);
    }
    for (size_t i = 0; i < A.a.size(); i++)
      A.a[i] -= B.a[i];
    return Value(powerNorm(A, optInt(a, 2, 20)));
  } SP_END
}

} // namespace

void registerLinearAlgebra(Registry &reg) {
  registerSolvers(reg);
  registerProperties(reg);
  registerDecompositions(reg);
  registerSpecialMatrices(reg);
  registerLowLevelAndInterpolative(reg);
}

} // namespace scipy
} // namespace nc
