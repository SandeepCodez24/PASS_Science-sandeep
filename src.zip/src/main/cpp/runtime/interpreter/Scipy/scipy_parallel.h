// The threading seam of every SciPy kernel (docs/Multicore_Multithread_Architecture.md, section 4).
//
// Kernels call forBlocks / reduceBlocks / tasks and never write a thread or a
// pragma themselves. Since 2026-11-05 this file is a thin layer over nc::par
// (runtime/execution/parallel/par.h), the one threading library of NC: the
// blocks run on several cores when the work is large enough.
//
// What stays exactly as it was:
//  - Block sizes. blockSize() below is the original rule, so every reduction
//    combines the same blocks in the same order as before: results are
//    bit-identical to the serial seam, at every thread count.
//  - Kernels whose cost is 0 ("not measured yet": the Task sites for FFT
//    lines, graph sources) and tasks() run serially, as before. Give such a
//    site a measured cost - after checking its body against the rules
//    below - to let it use threads.
//  - Stop does not cut a SciPy kernel short (Plan::stoppable = false): these
//    functions return void / a value and cannot give up a half-done result.
//    The statement stops as soon as the kernel returns.
//
// Rules for a body (section 12 of the design): raw buffers only - no Value
// copies, no printing, no callBuiltin, no callback into NC, no random numbers,
// no static that changes (a lazily filled table must be a function-local
// static initialised by its constructor, which C++ makes thread-safe).
#ifndef NC_SCIPY_PARALLEL_H
#define NC_SCIPY_PARALLEL_H

#include <cstddef>
#include <functional>
#include <vector>

#include "parallel/par.h"

namespace nc {
namespace scipy {
namespace par {

using Kind = nc::par::Kind; // Stream, Reduce, Compute, Task
using Cost = nc::par::Cost; // {kind, ns per item}

// Block size in items: about 50 us of work, a power of two, at least 1024.
// A Task block is one item. (The original rule - kept for identical results.)
inline size_t blockSize(const Cost &cost) {
  if (cost.kind == Kind::Task)
    return 1;
  double want = 50000.0 / (cost.nsPerItem > 0.0 ? cost.nsPerItem : 1.0);
  size_t b = 1024;
  while (static_cast<double>(b) < want)
    b <<= 1;
  return b;
}

inline nc::par::Plan planFor(size_t n, const Cost &cost) {
  nc::par::Plan p = nc::par::planWithBlockSize(n, cost, blockSize(cost));
  p.stoppable = false;
  return p;
}

inline const char *labelFor(Kind k) {
  switch (k) {
  case Kind::Stream:
    return "stream kernel";
  case Kind::Reduce:
    return "reduction";
  case Kind::Task:
    return "task kernel";
  default:
    return "compute kernel";
  }
}

// body(begin, end) over [0, n), in blocks that depend only on n and cost.
template <class Body> void forBlocks(size_t n, Cost cost, Body body) {
  const nc::par::Plan p = planFor(n, cost);
  nc::par::forPlan(p, cost.kind, labelFor(cost.kind), body);
}

// Per-block results combined in index order on the calling thread.
template <class T, class BlockFn, class Combine>
T reduceBlocks(size_t n, Cost cost, T init, BlockFn fn, Combine combine) {
  const nc::par::Plan p = planFor(n, cost);
  if (p.blocks == 0)
    return init;
  std::vector<T> parts(p.blocks, init);
  nc::par::forPlan(p, cost.kind, labelFor(cost.kind),
                   [&](size_t b, size_t e) { parts[b / p.blockSize] = fn(b, e); });
  for (const T &part : parts)
    init = combine(init, part);
  return init;
}

// Serial, as before: its one user (.ndat HDF5 encoding) has not been checked
// for thread safety yet. Switch to nc::par::tasks() once it has.
inline void tasks(const std::vector<std::function<void()>> &work) {
  for (const auto &w : work)
    w();
}

} // namespace par
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_PARALLEL_H
