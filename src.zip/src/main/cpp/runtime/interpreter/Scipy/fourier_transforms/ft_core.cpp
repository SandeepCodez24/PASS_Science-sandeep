#include "ft_core.h"

namespace nc {
namespace scipy {
namespace ft {

namespace {
void radix2(CVec &a, bool inverse) {
  const size_t n = a.size();
  for (size_t i = 1, j = 0; i < n; i++) {
    size_t bit = n >> 1;
    for (; j & bit; bit >>= 1)
      j ^= bit;
    j ^= bit;
    if (i < j)
      std::swap(a[i], a[j]);
  }
  for (size_t len = 2; len <= n; len <<= 1) {
    const double ang = 2.0 * kPi / static_cast<double>(len) * (inverse ? 1 : -1);
    CVec tw(len / 2);
    for (size_t k = 0; k < len / 2; k++)
      tw[k] = std::polar(1.0, ang * static_cast<double>(k));
    for (size_t i = 0; i < n; i += len)
      for (size_t k = 0; k < len / 2; k++) {
        cd u = a[i + k], v = a[i + k + len / 2] * tw[k];
        a[i + k] = u + v;
        a[i + k + len / 2] = u - v;
      }
  }
}

void bluestein(CVec &x, bool inverse) {
  const size_t n = x.size();
  size_t m = 1;
  while (m < 2 * n + 1)
    m <<= 1;
  CVec w(n), A(m, 0.0), B(m, 0.0);
  const double sign = inverse ? 1.0 : -1.0;
  for (size_t k = 0; k < n; k++) {
    // k*k mod 2n keeps the angle accurate for long lines.
    const unsigned long long kk = (static_cast<unsigned long long>(k) * k) % (2ULL * n);
    w[k] = std::polar(1.0, sign * kPi * static_cast<double>(kk) / static_cast<double>(n));
    A[k] = x[k] * w[k];
  }
  B[0] = std::conj(w[0]);
  for (size_t k = 1; k < n; k++)
    B[k] = B[m - k] = std::conj(w[k]);
  radix2(A, false);
  radix2(B, false);
  for (size_t i = 0; i < m; i++)
    A[i] *= B[i];
  radix2(A, true);
  for (size_t k = 0; k < n; k++)
    x[k] = A[k] / static_cast<double>(m) * w[k];
}
} // namespace

void fft(CVec &x, bool inverse) {
  const size_t n = x.size();
  if (n < 2)
    return;
  if ((n & (n - 1)) == 0)
    radix2(x, inverse);
  else
    bluestein(x, inverse);
  if (inverse)
    for (cd &z : x)
      z /= static_cast<double>(n);
}

void fftRows(CMat &m, bool inverse) {
  par::forBlocks(m.r, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    CVec line(m.c);
    for (size_t i = b; i < e; i++) {
      std::copy(m.row(i), m.row(i) + m.c, line.begin());
      fft(line, inverse);
      std::copy(line.begin(), line.end(), m.row(i));
    }
  });
}

void fftCols(CMat &m, bool inverse) {
  par::forBlocks(m.c, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    CVec line(m.r);
    for (size_t j = b; j < e; j++) {
      for (size_t i = 0; i < m.r; i++)
        line[i] = m(i, j);
      fft(line, inverse);
      for (size_t i = 0; i < m.r; i++)
        m(i, j) = line[i];
    }
  });
}

CVec convolveFullC(const CVec &a, const CVec &b) {
  if (a.empty() || b.empty())
    return {};
  const size_t n = a.size() + b.size() - 1;
  if (std::min(a.size(), b.size()) < 32) {
    CVec o(n, 0.0);
    for (size_t i = 0; i < a.size(); i++)
      for (size_t j = 0; j < b.size(); j++)
        o[i + j] += a[i] * b[j];
    return o;
  }
  size_t m = 1;
  while (m < n)
    m <<= 1;
  CVec A(a), B(b);
  A.resize(m);
  B.resize(m);
  radix2(A, false);
  radix2(B, false);
  for (size_t i = 0; i < m; i++)
    A[i] *= B[i];
  fft(A, true);
  A.resize(n);
  return A;
}

Vec convolveFull(const Vec &a, const Vec &b) {
  if (a.empty() || b.empty())
    return {};
  const size_t n = a.size() + b.size() - 1;
  Vec o(n, 0.0);
  if (std::min(a.size(), b.size()) < 32) {
    for (size_t i = 0; i < a.size(); i++)
      for (size_t j = 0; j < b.size(); j++)
        o[i + j] += a[i] * b[j];
    return o;
  }
  CVec c = convolveFullC(toComplex(a), toComplex(b));
  for (size_t i = 0; i < n; i++)
    o[i] = c[i].real();
  return o;
}

size_t nextFast(size_t n) {
  if (n <= 6)
    return n;
  for (size_t m = n;; m++) {
    size_t k = m;
    for (size_t p : {2, 3, 5})
      while (k % p == 0)
        k /= p;
    if (k == 1)
      return m;
  }
}

size_t prevFast(size_t n) {
  for (size_t m = n; m > 1; m--) {
    size_t k = m;
    for (size_t p : {2, 3, 5})
      while (k % p == 0)
        k /= p;
    if (k == 1)
      return m;
  }
  return 1;
}

// The transforms below follow their definitions through one complex FFT of
// length 2n or 4n (O(n log n), the scaling is SciPy's "backward" norm).

namespace {
// y[k] = sum x[n] cos(pi k (2n+1) / (2N)) * 2   (type 2, no norm)
Vec dct2raw(const Vec &x) {
  const size_t n = x.size();
  CVec z(2 * n, 0.0);
  for (size_t i = 0; i < n; i++)
    z[i] = x[i];
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++)
    y[k] = 2.0 * (z[k] * std::polar(1.0, -kPi * static_cast<double>(k) / (2.0 * n))).real();
  return y;
}
// y[k] = x[0] + 2 sum_{n>=1} x[n] cos(pi (2k+1) n / (2N))   (type 3, no norm)
Vec dct3raw(const Vec &x) {
  const size_t n = x.size();
  CVec z(2 * n, 0.0);
  for (size_t i = 0; i < n; i++)
    z[i] = x[i] * std::polar(1.0, -kPi * static_cast<double>(i) / (2.0 * n));
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++) {
    // z[k] = sum x[i] exp(-i pi i (2k+1) / (2N))
    y[k] = 2.0 * z[k].real() - x[0];
  }
  return y;
}
Vec dct1raw(const Vec &x) {
  const size_t n = x.size();
  if (n == 1)
    return {x[0]};
  CVec z(2 * (n - 1), 0.0);
  for (size_t i = 0; i < n; i++)
    z[i] = x[i];
  for (size_t i = 1; i + 1 < n; i++)
    z[2 * (n - 1) - i] = x[i];
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++)
    y[k] = z[k].real();
  return y;
}
// y[k] = 2 sum x[n] cos(pi (2k+1)(2n+1) / (4N))
Vec dct4raw(const Vec &x) {
  const size_t n = x.size();
  CVec z(8 * n, 0.0);
  for (size_t i = 0; i < n; i++)
    z[2 * i + 1] = x[i];
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++)
    y[k] = 2.0 * z[2 * k + 1].real();
  return y;
}
} // namespace

Vec dct(const Vec &x, int type, bool ortho, bool inverse) {
  const size_t n = x.size();
  const double N = static_cast<double>(n);
  if (n == 0)
    return {};
  int t = type;
  if (inverse)
    t = type == 2 ? 3 : type == 3 ? 2 : type;
  Vec in = x, y;
  if (ortho) {
    if (t == 1 && n > 1) {
      in[0] *= std::sqrt(2.0);
      in[n - 1] *= std::sqrt(2.0);
    }
    if (t == 3)
      in[0] *= std::sqrt(2.0);
  }
  y = t == 1 ? dct1raw(in) : t == 2 ? dct2raw(in) : t == 3 ? dct3raw(in) : dct4raw(in);
  if (ortho) {
    if (t == 1) {
      const double f = n > 1 ? 1.0 / std::sqrt(2.0 * (N - 1.0)) : 1.0;
      for (double &v : y)
        v *= f;
      if (n > 1) {
        y[0] /= std::sqrt(2.0);
        y[n - 1] /= std::sqrt(2.0);
      }
    } else {
      const double f = 1.0 / std::sqrt(2.0 * N);
      for (double &v : y)
        v *= f;
      if (t == 2)
        y[0] /= std::sqrt(2.0);
    }
    return y;
  }
  if (inverse) {
    const double f = t == 1 ? (n > 1 ? 1.0 / (2.0 * (N - 1.0)) : 1.0) : 1.0 / (2.0 * N);
    for (double &v : y)
      v *= f;
  }
  return y;
}

namespace {
Vec dstRaw(const Vec &x, int t) {
  const size_t n = x.size();
  const double N = static_cast<double>(n);
  Vec y(n, 0.0);
  if (t == 1) {
    CVec z(2 * (n + 1), 0.0);
    for (size_t i = 0; i < n; i++) {
      z[i + 1] = x[i];
      z[2 * (n + 1) - i - 1] = -x[i];
    }
    fft(z, false);
    for (size_t k = 0; k < n; k++)
      y[k] = -z[k + 1].imag();
  } else if (t == 2) {
    // y[k] = 2 sum x[n] sin(pi (k+1)(2n+1)/(2N))
    CVec z(2 * n, 0.0);
    for (size_t i = 0; i < n; i++)
      z[i] = x[i] * std::polar(1.0, -kPi * static_cast<double>(i) / N * 0.0);
    fft(z, false);
    for (size_t k = 0; k < n; k++) {
      cd w = z[(k + 1) % (2 * n)] * std::polar(1.0, -kPi * static_cast<double>(k + 1) / (2.0 * N));
      y[k] = -2.0 * w.imag();
    }
  } else if (t == 3) {
    // y[k] = (-1)^k x[N-1] + 2 sum_{n<N-1} x[n] sin(pi (2k+1)(n+1)/(2N))
    CVec z(2 * n, 0.0);
    for (size_t i = 0; i + 1 < n; i++)
      z[i] = x[i] * std::polar(1.0, -kPi * static_cast<double>(i + 1) / (2.0 * N));
    fft(z, false);
    for (size_t k = 0; k < n; k++) {
      cd w = z[k] * std::polar(1.0, -kPi * static_cast<double>(k) * 2.0 / (2.0 * N));
      y[k] = -2.0 * w.imag() + (k % 2 ? -1.0 : 1.0) * x[n - 1];
    }
  } else {
    // y[k] = 2 sum x[n] sin(pi (2k+1)(2n+1)/(4N))
    CVec z(8 * n, 0.0);
    for (size_t i = 0; i < n; i++)
      z[2 * i + 1] = x[i];
    fft(z, false);
    for (size_t k = 0; k < n; k++)
      y[k] = -2.0 * z[2 * k + 1].imag();
  }
  return y;
}
} // namespace

Vec dst(const Vec &x, int type, bool ortho, bool inverse) {
  const size_t n = x.size();
  const double N = static_cast<double>(n);
  if (n == 0)
    return {};
  int t = type;
  if (inverse)
    t = type == 2 ? 3 : type == 3 ? 2 : type;
  Vec in = x;
  if (ortho && t == 3)
    in[n - 1] *= std::sqrt(2.0);
  Vec y = dstRaw(in, t);
  if (ortho) {
    const double f = t == 1 ? 1.0 / std::sqrt(2.0 * (N + 1.0)) : 1.0 / std::sqrt(2.0 * N);
    for (double &v : y)
      v *= f;
    if (t == 2)
      y[n - 1] /= std::sqrt(2.0);
    return y;
  }
  if (inverse) {
    const double f = t == 1 ? 1.0 / (2.0 * (N + 1.0)) : 1.0 / (2.0 * N);
    for (double &v : y)
      v *= f;
  }
  return y;
}

} // namespace ft
} // namespace scipy
} // namespace nc
