#include "ft_core.h"

#include <map>
#include <memory>
#include <mutex>

namespace nc {
namespace scipy {
namespace ft {

namespace {
// The FFT engine (2026-11-20, docs/design_fix_1_4.md section 12): a
// self-sorting mixed-radix (Stockham) FFT for every length whose prime
// factors are all <= 13 - radix 4, 2, 3 written out, 5, 7, 11, 13 as small
// DFTs - and Bluestein's method for any other length, padded to the next
// 2*3*5-smooth length. Before 2026-11-20: radix 2 only, and Bluestein padded
// to a power of two (a 400,000-point transform ran three 2,097,152-point
// FFTs; now it is one 400,000-point FFT). Every twiddle is cos/sin of
// 2*pi*((j*k) mod n)/n, computed directly (no recurrence), so the accuracy
// is that of a textbook FFT: ~1e-16 * log2(n) relative to the largest
// element. Each stage reads one buffer and writes the other, on several
// cores for a long transform; a stage cut short by Stop is simply redone.

// One stage: `p`-point butterflies over `m` groups with stride `s`.
struct Stage {
  size_t p = 0, m = 0, s = 0;
  CVec tw; // tw[j*(p-1) + k-1] = exp(sign 2 pi i j k / (p*m)), j < m, 1 <= k < p
  CVec wp; // wp[r] = exp(sign 2 pi i r / p) (the small-DFT roots, p >= 5)
};
struct Plan {
  size_t n = 0;
  bool inverse = false;
  std::vector<Stage> stages;
};

// The radices of n (4 first, then 2, 3, 5, 7, 11, 13); false if n has a
// larger prime factor.
bool smallRadices(size_t n, std::vector<size_t> &out) {
  out.clear();
  while (n % 4 == 0) {
    out.push_back(4);
    n /= 4;
  }
  for (size_t p : {2, 3, 5, 7, 11, 13})
    while (n % p == 0) {
      out.push_back(p);
      n /= p;
    }
  return n == 1;
}

cd rootOf(size_t num, size_t den, double sign) {
  // exp(sign 2 pi i num / den), num reduced mod den first.
  const double a = sign * 2.0 * kPi * static_cast<double>(num % den) / static_cast<double>(den);
  return cd(std::cos(a), std::sin(a));
}

std::shared_ptr<const Plan> planFor(size_t n, bool inverse) {
  static std::mutex mtx;
  static std::map<std::pair<size_t, bool>, std::shared_ptr<const Plan>> cache;
  {
    std::lock_guard<std::mutex> guard(mtx);
    auto it = cache.find({n, inverse});
    if (it != cache.end())
      return it->second;
  }
  auto plan = std::make_shared<Plan>();
  plan->n = n;
  plan->inverse = inverse;
  std::vector<size_t> radices;
  smallRadices(n, radices);
  const double sign = inverse ? 1.0 : -1.0;
  size_t len = n, s = 1;
  for (size_t p : radices) {
    Stage st;
    st.p = p;
    st.m = len / p;
    st.s = s;
    st.tw.resize(st.m * (p - 1));
    for (size_t j = 0; j < st.m; j++)
      for (size_t k = 1; k < p; k++)
        st.tw[j * (p - 1) + k - 1] = rootOf(j * k, len, sign);
    if (p >= 5) {
      st.wp.resize(p);
      for (size_t r = 0; r < p; r++)
        st.wp[r] = rootOf(r, p, sign);
    }
    plan->stages.push_back(std::move(st));
    len /= p;
    s *= p;
  }
  std::lock_guard<std::mutex> guard(mtx);
  if (cache.size() >= 32) // plans of many lengths: start over
    cache.clear();
  cache[{n, inverse}] = plan;
  return plan;
}

// Below this length a stage runs on one core.
constexpr size_t kParallelFft = 1u << 14;

// The p-point DFT of a[0..p-1] into b (sign: -1 forward, +1 inverse).
inline void smallDft(const Stage &st, double sign, const cd *a, cd *b) {
  switch (st.p) {
  case 2:
    b[0] = a[0] + a[1];
    b[1] = a[0] - a[1];
    return;
  case 3: {
    const double h = sign * 0.86602540378443864676; // sin(2 pi / 3)
    const cd t = a[1] + a[2], d = a[1] - a[2];
    const cd c = a[0] - 0.5 * t;
    const cd rot(-h * d.imag(), h * d.real()); // i * h * d
    b[0] = a[0] + t;
    b[1] = c + rot;
    b[2] = c - rot;
    return;
  }
  case 4: {
    const cd t0 = a[0] + a[2], t1 = a[0] - a[2], t2 = a[1] + a[3], d = a[1] - a[3];
    const cd t3(-sign * d.imag(), sign * d.real()); // sign * i * d
    b[0] = t0 + t2;
    b[2] = t0 - t2;
    b[1] = t1 + t3;
    b[3] = t1 - t3;
    return;
  }
  default: {
    const size_t p = st.p;
    for (size_t k = 0; k < p; k++) {
      cd acc = a[0];
      for (size_t r = 1; r < p; r++)
        acc += a[r] * st.wp[(r * k) % p];
      b[k] = acc;
    }
    return;
  }
  }
}

// The unnormalized transform of x in place (length with small factors).
void stockham(CVec &x, bool inverse) {
  const size_t n = x.size();
  if (n < 2)
    return;
  const std::shared_ptr<const Plan> plan = planFor(n, inverse);
  const double sign = inverse ? 1.0 : -1.0;
  CVec y(n);
  CVec *src = &x, *dst = &y;
  for (const Stage &st : plan->stages) {
    const size_t p = st.p, m = st.m, s = st.s;
    const cd *in = src->data();
    cd *out = dst->data();
    auto body = [&](size_t first, size_t last) {
      cd a[13], b[13];
      for (size_t t = first; t < last; t++) {
        const size_t j = t / s, q = t % s;
        for (size_t r = 0; r < p; r++)
          a[r] = in[q + s * (j + r * m)];
        smallDft(st, sign, a, b);
        cd *o = out + q + s * p * j;
        o[0] = b[0];
        const cd *w = st.tw.data() + j * (p - 1);
        for (size_t k = 1; k < p; k++)
          o[s * k] = b[k] * w[k - 1];
      }
    };
    const size_t groups = m * s;
    if (n < kParallelFft ||
        ::nc::par::forBlocks(groups, ::nc::par::stream(2.0 * static_cast<double>(p)), "fft", body) !=
            ::nc::par::Outcome::Done)
      body(0, groups); // small, or Stop cut it short: the whole stage again (same input)
    std::swap(src, dst);
  }
  if (src != &x)
    x.swap(*src);
}

size_t smoothAtLeast(size_t n) { // the next 2*3*5-smooth length >= n
  for (size_t m = std::max<size_t>(n, 1);; m++) {
    size_t k = m;
    for (size_t p : {2, 3, 5})
      while (k % p == 0)
        k /= p;
    if (k == 1)
      return m;
  }
}

// Bluestein's chirp w and the transform of its conjugate, for one length.
struct Chirp {
  size_t n = 0, m = 0;
  bool inverse = false;
  CVec w, Bhat;
};

std::shared_ptr<const Chirp> chirpFor(size_t n, bool inverse) {
  static std::mutex mtx;
  static std::shared_ptr<const Chirp> recent[2];
  {
    std::lock_guard<std::mutex> guard(mtx);
    for (const auto &c : recent)
      if (c && c->n == n && c->inverse == inverse)
        return c;
  }
  auto c = std::make_shared<Chirp>();
  c->n = n;
  c->inverse = inverse;
  c->m = smoothAtLeast(2 * n - 1);
  c->w.resize(n);
  const double sign = inverse ? 1.0 : -1.0;
  for (size_t k = 0; k < n; k++) {
    // k*k mod 2n keeps the angle accurate for long lines.
    const unsigned long long kk = (static_cast<unsigned long long>(k) * k) % (2ULL * n);
    c->w[k] = std::polar(1.0, sign * kPi * static_cast<double>(kk) / static_cast<double>(n));
  }
  c->Bhat.assign(c->m, 0.0);
  c->Bhat[0] = std::conj(c->w[0]);
  for (size_t k = 1; k < n; k++)
    c->Bhat[k] = c->Bhat[c->m - k] = std::conj(c->w[k]);
  stockham(c->Bhat, false);
  std::lock_guard<std::mutex> guard(mtx);
  recent[1] = recent[0];
  recent[0] = c;
  return c;
}

void bluestein(CVec &x, bool inverse) {
  const size_t n = x.size();
  const std::shared_ptr<const Chirp> c = chirpFor(n, inverse);
  const size_t m = c->m;
  const CVec &w = c->w, &B = c->Bhat;
  CVec A(m, 0.0);
  for (size_t k = 0; k < n; k++)
    A[k] = x[k] * w[k];
  stockham(A, false);
  for (size_t i = 0; i < m; i++)
    A[i] *= B[i];
  stockham(A, true);
  for (size_t k = 0; k < n; k++)
    x[k] = A[k] / static_cast<double>(m) * w[k];
}

// The unnormalized transform, any length.
void transformRaw(CVec &x, bool inverse) {
  const size_t n = x.size();
  if (n < 2)
    return;
  std::vector<size_t> radices;
  if (smallRadices(n, radices))
    stockham(x, inverse);
  else
    bluestein(x, inverse);
}
} // namespace

void fft(CVec &x, bool inverse) {
  const size_t n = x.size();
  if (n < 2)
    return;
  transformRaw(x, inverse);
  if (inverse)
    for (cd &z : x)
      z /= static_cast<double>(n);
}

void fftRows(CMat &m, bool inverse) {
  par::forBlocks(m.r, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    CVec line(m.c);
    for (size_t i = b; i < e; i++) {
      std::copy(m.row(i), m.row(i) + m.c, line.begin());
      fft(line, inverse);
      std::copy(line.begin(), line.end(), m.row(i));
    }
  });
}

void fftCols(CMat &m, bool inverse) {
  par::forBlocks(m.c, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    CVec line(m.r);
    for (size_t j = b; j < e; j++) {
      for (size_t i = 0; i < m.r; i++)
        line[i] = m(i, j);
      fft(line, inverse);
      for (size_t i = 0; i < m.r; i++)
        m(i, j) = line[i];
    }
  });
}

CVec convolveFullC(const CVec &a, const CVec &b) {
  if (a.empty() || b.empty())
    return {};
  const size_t n = a.size() + b.size() - 1;
  if (std::min(a.size(), b.size()) < 32) {
    CVec o(n, 0.0);
    for (size_t i = 0; i < a.size(); i++)
      for (size_t j = 0; j < b.size(); j++)
        o[i + j] += a[i] * b[j];
    return o;
  }
  size_t m = 1;
  while (m < n)
    m <<= 1;
  CVec A(a), B(b);
  A.resize(m);
  B.resize(m);
  transformRaw(A, false);
  transformRaw(B, false);
  for (size_t i = 0; i < m; i++)
    A[i] *= B[i];
  fft(A, true);
  A.resize(n);
  return A;
}

Vec convolveFull(const Vec &a, const Vec &b) {
  if (a.empty() || b.empty())
    return {};
  const size_t n = a.size() + b.size() - 1;
  Vec o(n, 0.0);
  if (std::min(a.size(), b.size()) < 32) {
    for (size_t i = 0; i < a.size(); i++)
      for (size_t j = 0; j < b.size(); j++)
        o[i + j] += a[i] * b[j];
    return o;
  }
  CVec c = convolveFullC(toComplex(a), toComplex(b));
  for (size_t i = 0; i < n; i++)
    o[i] = c[i].real();
  return o;
}

size_t nextFast(size_t n) {
  if (n <= 6)
    return n;
  for (size_t m = n;; m++) {
    size_t k = m;
    for (size_t p : {2, 3, 5})
      while (k % p == 0)
        k /= p;
    if (k == 1)
      return m;
  }
}

size_t prevFast(size_t n) {
  for (size_t m = n; m > 1; m--) {
    size_t k = m;
    for (size_t p : {2, 3, 5})
      while (k % p == 0)
        k /= p;
    if (k == 1)
      return m;
  }
  return 1;
}

// The transforms below follow their definitions through one complex FFT of
// length 2n or 4n (O(n log n), the scaling is SciPy's "backward" norm).

namespace {
// y[k] = sum x[n] cos(pi k (2n+1) / (2N)) * 2   (type 2, no norm)
Vec dct2raw(const Vec &x) {
  const size_t n = x.size();
  CVec z(2 * n, 0.0);
  for (size_t i = 0; i < n; i++)
    z[i] = x[i];
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++)
    y[k] = 2.0 * (z[k] * std::polar(1.0, -kPi * static_cast<double>(k) / (2.0 * n))).real();
  return y;
}
// y[k] = x[0] + 2 sum_{n>=1} x[n] cos(pi (2k+1) n / (2N))   (type 3, no norm)
Vec dct3raw(const Vec &x) {
  const size_t n = x.size();
  CVec z(2 * n, 0.0);
  for (size_t i = 0; i < n; i++)
    z[i] = x[i] * std::polar(1.0, -kPi * static_cast<double>(i) / (2.0 * n));
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++) {
    // z[k] = sum x[i] exp(-i pi i (2k+1) / (2N))
    y[k] = 2.0 * z[k].real() - x[0];
  }
  return y;
}
Vec dct1raw(const Vec &x) {
  const size_t n = x.size();
  if (n == 1)
    return {x[0]};
  CVec z(2 * (n - 1), 0.0);
  for (size_t i = 0; i < n; i++)
    z[i] = x[i];
  for (size_t i = 1; i + 1 < n; i++)
    z[2 * (n - 1) - i] = x[i];
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++)
    y[k] = z[k].real();
  return y;
}
// y[k] = 2 sum x[n] cos(pi (2k+1)(2n+1) / (4N))
Vec dct4raw(const Vec &x) {
  const size_t n = x.size();
  CVec z(8 * n, 0.0);
  for (size_t i = 0; i < n; i++)
    z[2 * i + 1] = x[i];
  fft(z, false);
  Vec y(n);
  for (size_t k = 0; k < n; k++)
    y[k] = 2.0 * z[2 * k + 1].real();
  return y;
}
} // namespace

Vec dct(const Vec &x, int type, bool ortho, bool inverse) {
  const size_t n = x.size();
  const double N = static_cast<double>(n);
  if (n == 0)
    return {};
  int t = type;
  if (inverse)
    t = type == 2 ? 3 : type == 3 ? 2 : type;
  Vec in = x, y;
  if (ortho) {
    if (t == 1 && n > 1) {
      in[0] *= std::sqrt(2.0);
      in[n - 1] *= std::sqrt(2.0);
    }
    if (t == 3)
      in[0] *= std::sqrt(2.0);
  }
  y = t == 1 ? dct1raw(in) : t == 2 ? dct2raw(in) : t == 3 ? dct3raw(in) : dct4raw(in);
  if (ortho) {
    if (t == 1) {
      const double f = n > 1 ? 1.0 / std::sqrt(2.0 * (N - 1.0)) : 1.0;
      for (double &v : y)
        v *= f;
      if (n > 1) {
        y[0] /= std::sqrt(2.0);
        y[n - 1] /= std::sqrt(2.0);
      }
    } else {
      const double f = 1.0 / std::sqrt(2.0 * N);
      for (double &v : y)
        v *= f;
      if (t == 2)
        y[0] /= std::sqrt(2.0);
    }
    return y;
  }
  if (inverse) {
    const double f = t == 1 ? (n > 1 ? 1.0 / (2.0 * (N - 1.0)) : 1.0) : 1.0 / (2.0 * N);
    for (double &v : y)
      v *= f;
  }
  return y;
}

namespace {
Vec dstRaw(const Vec &x, int t) {
  const size_t n = x.size();
  const double N = static_cast<double>(n);
  Vec y(n, 0.0);
  if (t == 1) {
    CVec z(2 * (n + 1), 0.0);
    for (size_t i = 0; i < n; i++) {
      z[i + 1] = x[i];
      z[2 * (n + 1) - i - 1] = -x[i];
    }
    fft(z, false);
    for (size_t k = 0; k < n; k++)
      y[k] = -z[k + 1].imag();
  } else if (t == 2) {
    // y[k] = 2 sum x[n] sin(pi (k+1)(2n+1)/(2N))
    CVec z(2 * n, 0.0);
    for (size_t i = 0; i < n; i++)
      z[i] = x[i] * std::polar(1.0, -kPi * static_cast<double>(i) / N * 0.0);
    fft(z, false);
    for (size_t k = 0; k < n; k++) {
      cd w = z[(k + 1) % (2 * n)] * std::polar(1.0, -kPi * static_cast<double>(k + 1) / (2.0 * N));
      y[k] = -2.0 * w.imag();
    }
  } else if (t == 3) {
    // y[k] = (-1)^k x[N-1] + 2 sum_{n<N-1} x[n] sin(pi (2k+1)(n+1)/(2N))
    CVec z(2 * n, 0.0);
    for (size_t i = 0; i + 1 < n; i++)
      z[i] = x[i] * std::polar(1.0, -kPi * static_cast<double>(i + 1) / (2.0 * N));
    fft(z, false);
    for (size_t k = 0; k < n; k++) {
      cd w = z[k] * std::polar(1.0, -kPi * static_cast<double>(k) * 2.0 / (2.0 * N));
      y[k] = -2.0 * w.imag() + (k % 2 ? -1.0 : 1.0) * x[n - 1];
    }
  } else {
    // y[k] = 2 sum x[n] sin(pi (2k+1)(2n+1)/(4N))
    CVec z(8 * n, 0.0);
    for (size_t i = 0; i < n; i++)
      z[2 * i + 1] = x[i];
    fft(z, false);
    for (size_t k = 0; k < n; k++)
      y[k] = -2.0 * z[2 * k + 1].imag();
  }
  return y;
}
} // namespace

Vec dst(const Vec &x, int type, bool ortho, bool inverse) {
  const size_t n = x.size();
  const double N = static_cast<double>(n);
  if (n == 0)
    return {};
  int t = type;
  if (inverse)
    t = type == 2 ? 3 : type == 3 ? 2 : type;
  Vec in = x;
  if (ortho && t == 3)
    in[n - 1] *= std::sqrt(2.0);
  Vec y = dstRaw(in, t);
  if (ortho) {
    const double f = t == 1 ? 1.0 / std::sqrt(2.0 * (N + 1.0)) : 1.0 / std::sqrt(2.0 * N);
    for (double &v : y)
      v *= f;
    if (t == 2)
      y[n - 1] /= std::sqrt(2.0);
    return y;
  }
  if (inverse) {
    const double f = t == 1 ? 1.0 / (2.0 * (N + 1.0)) : 1.0 / (2.0 * N);
    for (double &v : y)
      v *= f;
  }
  return y;
}

} // namespace ft
} // namespace scipy
} // namespace nc
