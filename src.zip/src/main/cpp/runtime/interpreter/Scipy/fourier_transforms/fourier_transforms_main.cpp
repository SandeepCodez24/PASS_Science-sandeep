// Section 5 of 25 - Fourier Transforms (scipy.fft).
#include "fourier_transforms_main.h"

#include <cstdlib>

#include "../linear_algebra/la_core.h"
#include "ft_core.h"
#include "ft_shared.h"

#define SP_SEC Section::FourierTransforms

namespace nc {
namespace scipy {

namespace {
int g_workers = 1; // what set_fft_workers() asked for; the kernels read it when threads arrive
}

namespace ft {

bool normOf(const Args &a, size_t i, CallContext &ctx, int &norm) {
  const std::string n = optText(a, i, "backward");
  norm = n == "backward" ? 0 : n == "ortho" ? 1 : n == "forward" ? 2 : -1;
  if (norm < 0)
    ctx.fail("norm must be \"backward\", \"ortho\" or \"forward\"");
  return norm >= 0;
}

CVec line1d(CVec x, size_t n, bool inverse, int norm) {
  x.resize(n, 0.0);
  fft(x, inverse);
  double f = 1.0;
  const double N = static_cast<double>(n);
  if (inverse)
    f = norm == 1 ? std::sqrt(N) : norm == 2 ? N : 1.0;
  else
    f = norm == 1 ? 1.0 / std::sqrt(N) : norm == 2 ? 1.0 / N : 1.0;
  if (f != 1.0)
    for (cd &z : x)
      z *= f;
  return x;
}

bool isLine(const Value &v) {
  if (!v.isMatrix)
    return true;
  return v.rows() <= 1 || v.cols() == 1;
}

// n-dimensional here means 1-D or 2-D (the tables say so).
Value ndTransform(const Value &v, bool inverse) {
  if (isLine(v)) {
    CVec x;
    readCVec(v, x);
    fft(x, inverse);
    return toValue(x);
  }
  CMat m;
  readCMat(v, m);
  fft2(m, inverse);
  return toValue(m);
}

// Half-spectrum of a real matrix: rfft along the last axis, fft along the first.
CMat rfft2Of(const Mat &m) {
  CMat f(m.r, m.c / 2 + 1);
  par::forBlocks(m.r, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    CVec line(m.c);
    for (size_t i = b; i < e; i++) {
      for (size_t j = 0; j < m.c; j++)
        line[j] = m(i, j);
      fft(line, false);
      for (size_t j = 0; j < f.c; j++)
        f(i, j) = line[j];
    }
  });
  fftCols(f, false);
  return f;
}

Vec irfftLine(const CVec &in, size_t n) {
  CVec full(n, 0.0);
  const size_t half = n / 2 + 1;
  for (size_t k = 0; k < half && k < in.size(); k++)
    full[k] = in[k];
  if (!in.empty())
    full[0] = in[0].real();
  if (n % 2 == 0 && n / 2 < in.size())
    full[n / 2] = in[n / 2].real();
  for (size_t k = 1; k < n - k; k++)
    full[n - k] = std::conj(full[k]);
  fft(full, true);
  Vec o(n);
  for (size_t i = 0; i < n; i++)
    o[i] = full[i].real();
  return o;
}

Mat irfft2Of(CMat f, size_t cols) {
  fftCols(f, true);
  Mat o(f.r, cols);
  par::forBlocks(f.r, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    for (size_t i = b; i < e; i++) {
      CVec line(f.row(i), f.row(i) + f.c);
      Vec r = irfftLine(line, cols);
      std::copy(r.begin(), r.end(), o.row(i));
    }
  });
  return o;
}

Value applyLinewise(const Value &v, const std::function<Vec(const Vec &)> &fn) {
  // Along the rows, then along the columns: the separable n-D transforms.
  if (isLine(v)) {
    Vec x;
    readVec(v, x);
    return toValue(fn(x));
  }
  Mat m;
  readMat(v, m);
  for (size_t i = 0; i < m.r; i++) {
    Vec line(m.row(i), m.row(i) + m.c);
    Vec r = fn(line);
    std::copy(r.begin(), r.end(), m.row(i));
  }
  for (size_t j = 0; j < m.c; j++) {
    Vec line(m.r);
    for (size_t i = 0; i < m.r; i++)
      line[i] = m(i, j);
    Vec r = fn(line);
    for (size_t i = 0; i < m.r; i++)
      m(i, j) = r[i];
  }
  return toValue(m);
}

bool typeOf(const Args &a, size_t i, CallContext &ctx, int &type) {
  type = static_cast<int>(optInt(a, i, 2));
  if (type < 1 || type > 4) {
    ctx.fail("type must be 1, 2, 3 or 4");
    return false;
  }
  return true;
}

// Fast Hankel transform (Talman's algorithm), the same steps as SciPy's fht.
double logGammaRe(double re, double im, double &phase) {
  // log Gamma(re + i im) by the Lanczos approximation.
  static const double g[] = {676.5203681218851,   -1259.1392167224028, 771.32342877765313,
                             -176.61502916214059, 12.507343278686905,  -0.13857109526572012,
                             9.9843695780195716e-6, 1.5056327351493116e-7};
  cd z(re, im);
  cd refl = 0.0;
  bool reflected = false;
  if (re < 0.5) {
    reflected = true;
    refl = std::log(kPi / std::sin(kPi * z));
    z = 1.0 - z;
  }
  z -= 1.0;
  cd x = 0.99999999999980993;
  for (int i = 0; i < 8; i++)
    x += g[i] / (z + static_cast<double>(i + 1));
  cd t = z + 7.5;
  cd r = 0.5 * std::log(2.0 * kPi) + (z + 0.5) * std::log(t) - t + std::log(x);
  if (reflected)
    r = refl - r;
  phase = r.imag();
  return r.real();
}

CVec fhtCoefficients(size_t n, double dln, double mu, double offset, double bias) {
  // The u_m of Hamilton (2000), for m = 0 .. n/2.
  const size_t half = n / 2 + 1;
  CVec u(half);
  const double ln2 = std::log(2.0);
  const double x = (mu + 1.0 + bias) / 2.0, x2 = (mu + 1.0 - bias) / 2.0;
  for (size_t m = 0; m < half; m++) {
    const double y = kPi * static_cast<double>(m) / (static_cast<double>(n) * dln);
    double pa, pb;
    const double la = logGammaRe(x, y, pa), lb = logGammaRe(x2, y, pb);
    const double t = 2.0 * (ln2 - offset) * y + pa + pb;
    double mag = std::exp(ln2 * bias + la - lb);
    u[m] = std::polar(mag, t);
  }
  if (n % 2 == 0)
    u[half - 1] = u[half - 1].real();
  return u;
}

Vec fastHankel(const Vec &ain, double dln, double mu, double offset, double bias, bool inverse) {
  const size_t n = ain.size();
  Vec a = ain;
  const double jc = (static_cast<double>(n) - 1.0) / 2.0;
  if (bias != 0.0)
    for (size_t j = 0; j < n; j++)
      a[j] *= std::exp((inverse ? 1.0 : -1.0) * bias * (static_cast<double>(j) - jc) * dln);
  CVec u = fhtCoefficients(n, dln, mu, offset, bias);
  CVec fa(n);
  for (size_t i = 0; i < n; i++)
    fa[i] = a[i];
  fft(fa, false);
  CVec half(u.size());
  for (size_t m = 0; m < u.size(); m++) {
    half[m] = inverse ? fa[m] / std::conj(u[m]) : fa[m] * u[m];
    if (!std::isfinite(half[m].real()) || !std::isfinite(half[m].imag()))
      half[m] = 0.0;
  }
  Vec o = irfftLine(half, n);
  std::reverse(o.begin(), o.end());
  if (bias != 0.0)
    for (size_t j = 0; j < n; j++) {
      const double f = std::exp(-bias * ((static_cast<double>(j) - jc) * dln + offset));
      o[j] = inverse ? o[j] / f : o[j] * f;
    }
  return o;
}

} // namespace ft

using namespace ft;

void registerFourierTransforms(Registry &reg) {
  SP_ADD("fft", 1, 3, "data, n, norm=\"backward\"") {
    CVec x;
    int norm;
    if (!getCVec(a, 0, ctx, x) || !normOf(a, 2, ctx, norm))
      return Value(0.0);
    return toValue(line1d(x, isOmitted(a, 1) ? x.size() : (size_t)optInt(a, 1, 0), false, norm));
  } SP_ENDC
  SP_ADD("ifft", 1, 3, "data, n, norm=\"backward\"") {
    CVec x;
    int norm;
    if (!getCVec(a, 0, ctx, x) || !normOf(a, 2, ctx, norm))
      return Value(0.0);
    return toValue(line1d(x, isOmitted(a, 1) ? x.size() : (size_t)optInt(a, 1, 0), true, norm));
  } SP_ENDC
  SP_ADD("fft2", 1, 1, "data") {
    CMat m;
    if (!getCMat(a, 0, ctx, m))
      return Value(0.0);
    ft::fft2(m, false);
    return toValue(m);
  } SP_ENDC
  SP_ADD("ifft2", 1, 1, "data") {
    CMat m;
    if (!getCMat(a, 0, ctx, m))
      return Value(0.0);
    ft::fft2(m, true);
    return toValue(m);
  } SP_ENDC
  SP_ADD("fftn", 1, 1, "data") {
    CMat m;
    if (!getCMat(a, 0, ctx, m))
      return Value(0.0);
    return ndTransform(a[0], false);
  } SP_ENDC
  SP_ADD("ifftn", 1, 1, "data") {
    CMat m;
    if (!getCMat(a, 0, ctx, m))
      return Value(0.0);
    return ndTransform(a[0], true);
  } SP_ENDC
  SP_ADD("rfft", 1, 2, "data, n") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const size_t n = isOmitted(a, 1) ? x.size() : (size_t)optInt(a, 1, 0);
    CVec z = toComplex(x);
    z.resize(n, 0.0);
    fft(z, false);
    z.resize(n / 2 + 1);
    return toValue(z);
  } SP_END
  SP_ADD("irfft", 1, 2, "data, n") {
    CVec z;
    if (!getCVec(a, 0, ctx, z))
      return Value(0.0);
    if (!isOmitted(a, 1) && (!isPlainNumber(a[1]) || a[1].number < 1 || a[1].number > 1e7 || a[1].number != std::floor(a[1].number))) {
      ctx.fail("n must be a whole number, 1 or more");
      return Value(0.0);
    }
    const size_t n = isOmitted(a, 1) ? (z.size() > 1 ? 2 * (z.size() - 1) : 1) : (size_t)optInt(a, 1, 0);
    return toValue(irfftLine(z, n));
  } SP_ENDC
  SP_ADD("rfft2", 1, 1, "data") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    return toValue(rfft2Of(m));
  } SP_END
  SP_ADD("irfft2", 1, 2, "data, shape") {
    CMat f;
    Vec shape;
    if (!getCMat(a, 0, ctx, f))
      return Value(0.0);
    size_t cols = f.c > 1 ? 2 * (f.c - 1) : 1;
    if (a.size() > 1) {
      if (!getVec(a, 1, ctx, shape) || shape.size() != 2) {
        if (ctx.ok())
          ctx.fail("shape must be [rows, cols]");
        return Value(0.0);
      }
      cols = (size_t)shape[1];
    }
    return toValue(irfft2Of(f, cols));
  } SP_ENDC
  SP_ADD("rfftn", 1, 1, "data") {
    if (isLine(a[0])) {
      Vec x;
      if (!getVec(a, 0, ctx, x))
        return Value(0.0);
      CVec z = toComplex(x);
      fft(z, false);
      z.resize(x.size() / 2 + 1);
      return toValue(z);
    }
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    return toValue(rfft2Of(m));
  } SP_END
  SP_ADD("irfftn", 1, 1, "data") {
    if (isLine(a[0])) {
      CVec z;
      if (!getCVec(a, 0, ctx, z))
        return Value(0.0);
      return toValue(irfftLine(z, z.size() > 1 ? 2 * (z.size() - 1) : 1));
    }
    CMat f;
    if (!getCMat(a, 0, ctx, f))
      return Value(0.0);
    return toValue(irfft2Of(f, f.c > 1 ? 2 * (f.c - 1) : 1));
  } SP_ENDC
  SP_ADD("hfft", 1, 2, "data, n") {
    // The FFT of a Hermitian-symmetric signal: irfft of the conjugate, times n.
    CVec z;
    if (!getCVec(a, 0, ctx, z))
      return Value(0.0);
    if (!isOmitted(a, 1) && (!isPlainNumber(a[1]) || a[1].number < 1 || a[1].number > 1e7 || a[1].number != std::floor(a[1].number))) {
      ctx.fail("n must be a whole number, 1 or more");
      return Value(0.0);
    }
    const size_t n = isOmitted(a, 1) ? (z.size() > 1 ? 2 * (z.size() - 1) : 1) : (size_t)optInt(a, 1, 0);
    for (cd &v : z)
      v = std::conj(v);
    Vec o = irfftLine(z, n);
    for (double &v : o)
      v *= static_cast<double>(n);
    return toValue(o);
  } SP_ENDC
  SP_ADD("ihfft", 1, 2, "data, n") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const size_t n = isOmitted(a, 1) ? x.size() : (size_t)optInt(a, 1, 0);
    CVec z = toComplex(x);
    z.resize(n, 0.0);
    fft(z, false);
    z.resize(n / 2 + 1);
    for (cd &v : z)
      v = std::conj(v) / static_cast<double>(n);
    return toValue(z);
  } SP_END
  SP_ADD("hfft2", 1, 1, "data") {
    CMat f;
    if (!getCMat(a, 0, ctx, f))
      return Value(0.0);
    for (cd &v : f.a)
      v = std::conj(v);
    const size_t cols = f.c > 1 ? 2 * (f.c - 1) : 1;
    Mat o = irfft2Of(f, cols);
    for (double &v : o.a)
      v *= static_cast<double>(o.r * o.c);
    return toValue(o);
  } SP_ENDC
  SP_ADD("ihfft2", 1, 1, "data") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    CMat f = rfft2Of(m);
    for (cd &v : f.a)
      v = std::conj(v) / static_cast<double>(m.r * m.c);
    return toValue(f);
  } SP_END
  SP_ADD("hfftn", 1, 1, "data") {
    if (isLine(a[0])) {
      CVec z;
      if (!getCVec(a, 0, ctx, z))
        return Value(0.0);
      const size_t n = z.size() > 1 ? 2 * (z.size() - 1) : 1;
      for (cd &v : z)
        v = std::conj(v);
      Vec o = irfftLine(z, n);
      for (double &v : o)
        v *= static_cast<double>(n);
      return toValue(o);
    }
    CMat f;
    if (!getCMat(a, 0, ctx, f))
      return Value(0.0);
    for (cd &v : f.a)
      v = std::conj(v);
    Mat o = irfft2Of(f, f.c > 1 ? 2 * (f.c - 1) : 1);
    for (double &v : o.a)
      v *= static_cast<double>(o.r * o.c);
    return toValue(o);
  } SP_ENDC
  SP_ADD("ihfftn", 1, 1, "data") {
    if (isLine(a[0])) {
      Vec x;
      if (!getVec(a, 0, ctx, x))
        return Value(0.0);
      CVec z = toComplex(x);
      fft(z, false);
      z.resize(x.size() / 2 + 1);
      for (cd &v : z)
        v = std::conj(v) / static_cast<double>(x.size());
      return toValue(z);
    }
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    CMat f = rfft2Of(m);
    for (cd &v : f.a)
      v = std::conj(v) / static_cast<double>(m.r * m.c);
    return toValue(f);
  } SP_END
  SP_ADD("dct", 1, 3, "data, type=2, norm=\"\"") {
    Vec x;
    int t;
    if (!getVec(a, 0, ctx, x) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    return toValue(ft::dct(x, t, optText(a, 2, "") == "ortho", false));
  } SP_END
  SP_ADD("idct", 1, 3, "data, type=2, norm=\"\"") {
    Vec x;
    int t;
    if (!getVec(a, 0, ctx, x) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    return toValue(ft::dct(x, t, optText(a, 2, "") == "ortho", true));
  } SP_END
  SP_ADD("dctn", 1, 3, "data, type=2, norm=\"\"") {
    Mat m;
    int t;
    if (!getMat(a, 0, ctx, m) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    const bool o = optText(a, 2, "") == "ortho";
    return applyLinewise(a[0], [=](const Vec &l) { return ft::dct(l, t, o, false); });
  } SP_END
  SP_ADD("idctn", 1, 3, "data, type=2, norm=\"\"") {
    Mat m;
    int t;
    if (!getMat(a, 0, ctx, m) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    const bool o = optText(a, 2, "") == "ortho";
    return applyLinewise(a[0], [=](const Vec &l) { return ft::dct(l, t, o, true); });
  } SP_END
  SP_ADD("dst", 1, 3, "data, type=2, norm=\"\"") {
    Vec x;
    int t;
    if (!getVec(a, 0, ctx, x) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    return toValue(ft::dst(x, t, optText(a, 2, "") == "ortho", false));
  } SP_END
  SP_ADD("idst", 1, 3, "data, type=2, norm=\"\"") {
    Vec x;
    int t;
    if (!getVec(a, 0, ctx, x) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    return toValue(ft::dst(x, t, optText(a, 2, "") == "ortho", true));
  } SP_END
  SP_ADD("dstn", 1, 3, "data, type=2, norm=\"\"") {
    Mat m;
    int t;
    if (!getMat(a, 0, ctx, m) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    const bool o = optText(a, 2, "") == "ortho";
    return applyLinewise(a[0], [=](const Vec &l) { return ft::dst(l, t, o, false); });
  } SP_END
  SP_ADD("idstn", 1, 3, "data, type=2, norm=\"\"") {
    Mat m;
    int t;
    if (!getMat(a, 0, ctx, m) || !typeOf(a, 1, ctx, t))
      return Value(0.0);
    const bool o = optText(a, 2, "") == "ortho";
    return applyLinewise(a[0], [=](const Vec &l) { return ft::dst(l, t, o, true); });
  } SP_END
  SP_ADD("fht", 3, 5, "data, dln, mu, offset=0, bias=0") {
    Vec x;
    double dln, mu;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, dln) || !argNumber(a, 2, ctx, mu))
      return Value(0.0);
    return toValue(fastHankel(x, dln, mu, optNum(a, 3, 0.0), optNum(a, 4, 0.0), false));
  } SP_END
  SP_ADD("ifht", 3, 5, "data, dln, mu, offset=0, bias=0") {
    Vec x;
    double dln, mu;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, dln) || !argNumber(a, 2, ctx, mu))
      return Value(0.0);
    return toValue(fastHankel(x, dln, mu, optNum(a, 3, 0.0), optNum(a, 4, 0.0), true));
  } SP_END
  SP_ADD("fht_offset", 2, 4, "dln, mu, initial=0, bias=0") {
    double dln, mu;
    if (!argNumber(a, 0, ctx, dln) || !argNumber(a, 1, ctx, mu))
      return Value(0.0);
    const double initial = optNum(a, 2, 0.0), bias = optNum(a, 3, 0.0);
    const double y = kPi / (2.0 * dln);
    double pa, pb;
    logGammaRe((mu + 1.0 + bias) / 2.0, y, pa);
    logGammaRe((mu + 1.0 - bias) / 2.0, y, pb);
    double t = 2.0 * (std::log(2.0) - initial) * y + pa + pb;
    t = t / kPi;
    return Value(initial + (t - std::round(t)) * dln);
  } SP_END
  SP_ADD("fftfreq", 1, 2, "n, d=1") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n) || n == 0) {
      if (ctx.ok())
        ctx.fail("n must be at least 1");
      return Value(0.0);
    }
    const double d = optNum(a, 1, 1.0);
    Vec f((size_t)n);
    const long long pos = (n - 1) / 2 + 1;
    for (long long i = 0; i < n; i++)
      f[(size_t)i] = static_cast<double>(i < pos ? i : i - n) / (static_cast<double>(n) * d);
    return toValue(f);
  } SP_END
  SP_ADD("rfftfreq", 1, 2, "n, d=1") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n) || n == 0) {
      if (ctx.ok())
        ctx.fail("n must be at least 1");
      return Value(0.0);
    }
    const double d = optNum(a, 1, 1.0);
    Vec f((size_t)(n / 2 + 1));
    for (size_t i = 0; i < f.size(); i++)
      f[i] = static_cast<double>(i) / (static_cast<double>(n) * d);
    return toValue(f);
  } SP_END
  SP_ADD("fftshift", 1, 1, "data") {
    CMat m;
    if (!getCMat(a, 0, ctx, m))
      return Value(0.0);
    CMat o(m.r, m.c);
    const size_t sr = isLine(a[0]) && m.r == 1 ? 0 : m.r / 2, sc = m.c == 1 ? 0 : m.c / 2;
    for (size_t i = 0; i < m.r; i++)
      for (size_t j = 0; j < m.c; j++)
        o((i + sr) % m.r, (j + sc) % m.c) = m(i, j);
    return realIfPossible(o);
  } SP_ENDC
  SP_ADD("ifftshift", 1, 1, "data") {
    CMat m;
    if (!getCMat(a, 0, ctx, m))
      return Value(0.0);
    CMat o(m.r, m.c);
    const size_t sr = m.r == 1 ? 0 : m.r - m.r / 2, sc = m.c == 1 ? 0 : m.c - m.c / 2;
    for (size_t i = 0; i < m.r; i++)
      for (size_t j = 0; j < m.c; j++)
        o((i + sr) % m.r, (j + sc) % m.c) = m(i, j);
    return realIfPossible(o);
  } SP_ENDC
  SP_ADD("next_fast_len", 1, 2, "n, real=0") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    return Value(static_cast<double>(nextFast((size_t)n)));
  } SP_END
  SP_ADD("prev_fast_len", 1, 2, "n, real=0") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    return Value(static_cast<double>(prevFast((size_t)n)));
  } SP_END
  SP_ADD("set_fft_workers", 1, 1, "n") {
    long long n;
    if (!argInt(a, 0, ctx, n))
      return Value(0.0);
    if (n < 1) {
      ctx.fail("n must be at least 1");
      return Value(0.0);
    }
    g_workers = static_cast<int>(n);
    return Value(0.0);
  } SP_END
  SP_ADD("get_fft_workers", 0, 0, "") { return Value(static_cast<double>(g_workers)); } SP_END
  reg.setParallel({"fft2", "ifft2", "fftn", "ifftn", "rfft2", "irfft2", "rfftn", "irfftn", "hfft2",
                   "ihfft2", "hfftn", "ihfftn", "dctn", "idctn", "dstn", "idstn"},
                  ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
