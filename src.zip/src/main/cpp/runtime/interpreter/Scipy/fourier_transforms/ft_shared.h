// Fourier helpers used by the legacy FFT section as well.
#ifndef NC_SCIPY_FT_SHARED_H
#define NC_SCIPY_FT_SHARED_H

#include <functional>

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace ft {

bool isLine(const Value &v);
Vec irfftLine(const CVec &in, size_t n);
CVec line1d(CVec x, size_t n, bool inverse, int norm);

} // namespace ft
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_FT_SHARED_H
