// FFT kernels shared by the Fourier, legacy FFT, signal, image and linear
// algebra sections: radix-2 for powers of two, Bluestein for every other length.
#ifndef NC_SCIPY_FT_CORE_H
#define NC_SCIPY_FT_CORE_H

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace ft {

// In place; inverse divides by n. Any length.
void fft(CVec &x, bool inverse);
inline CVec fftOf(CVec x) {
  fft(x, false);
  return x;
}
inline CVec ifftOf(CVec x) {
  fft(x, true);
  return x;
}
// Transforms along the rows and/or the columns, one line per task.
void fftRows(CMat &m, bool inverse);
void fftCols(CMat &m, bool inverse);
inline void fft2(CMat &m, bool inverse) {
  fftRows(m, inverse);
  fftCols(m, inverse);
}
// Linear convolution through the FFT, length a + b - 1.
Vec convolveFull(const Vec &a, const Vec &b);
CVec convolveFullC(const CVec &a, const CVec &b);
// Next length with only the factors 2, 3, 5.
size_t nextFast(size_t n);
size_t prevFast(size_t n);
// DCT / DST of types 1-4 of a real line, SciPy's scaling; ortho applies "ortho".
Vec dct(const Vec &x, int type, bool ortho, bool inverse);
Vec dst(const Vec &x, int type, bool ortho, bool inverse);

} // namespace ft
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_FT_CORE_H
