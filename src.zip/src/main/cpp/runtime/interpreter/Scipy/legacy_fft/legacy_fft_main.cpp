// Section 6 of 25 - Legacy FFT (scipy.fftpack). The plain transforms are the
// functions of section 5 under the same names; only fftpack's own ones are here.
#include "legacy_fft_main.h"

#include "../fourier_transforms/ft_core.h"
#include "../fourier_transforms/ft_shared.h"
#include "../scipy_core.h"

#define SP_SEC Section::LegacyFft

namespace nc {
namespace scipy {

namespace {

// fftpack multiplies each Fourier coefficient y[j] by a factor of the
// wavenumber j (in 2*pi/period units); the Nyquist term is dropped or kept as
// each routine does. fn(k) gives the factor for wavenumber k > 0.
Vec spectralMap(const Vec &x, const std::function<cd(double)> &fn, double zeroFactor, bool keepNyquist) {
  const size_t n = x.size();
  CVec z = ft::fftOf(toComplex(x));
  z[0] *= zeroFactor;
  for (size_t k = 1; k < n; k++) {
    if (2 * k == n) {
      if (keepNyquist)
        z[k] *= fn(static_cast<double>(k)).real();
      else
        z[k] = 0.0;
      continue;
    }
    const double w = static_cast<double>(k < n - k ? k : n - k);
    const cd f = fn(w);
    z[k] *= k < n - k ? f : std::conj(f);
  }
  ft::fft(z, true);
  Vec o(n);
  for (size_t i = 0; i < n; i++)
    o[i] = z[i].real();
  return o;
}

// The packed layout: y(0), Re y(1), Im y(1), Re y(2), ...
Vec rfftPacked(const Vec &x, size_t n) {
  CVec z = toComplex(x);
  z.resize(n, 0.0);
  ft::fft(z, false);
  Vec o(n);
  if (n)
    o[0] = z[0].real();
  for (size_t k = 1; k < (n + 1) / 2; k++) {
    o[2 * k - 1] = z[k].real();
    o[2 * k] = z[k].imag();
  }
  if (n && n % 2 == 0)
    o[n - 1] = z[n / 2].real();
  return o;
}

Vec irfftPacked(const Vec &p) {
  const size_t n = p.size();
  CVec z(n / 2 + 1, 0.0);
  if (n)
    z[0] = p[0];
  for (size_t k = 1; k < (n + 1) / 2; k++)
    z[k] = cd(p[2 * k - 1], p[2 * k]);
  if (n && n % 2 == 0)
    z[n / 2] = p[n - 1];
  return ft::irfftLine(z, n);
}

double periodScale(const Args &a, size_t i) { return 2.0 * kPi / optNum(a, i, 2.0 * kPi); }

} // namespace

void registerLegacyFft(Registry &reg) {
  SP_ADD("rfft_packed", 1, 2, "data, n") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    return toValue(rfftPacked(x, isOmitted(a, 1) ? x.size() : (size_t)optInt(a, 1, 0)));
  } SP_END
  SP_ADD("irfft_packed", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    return toValue(irfftPacked(x));
  } SP_END
  SP_ADD("fft_diff", 1, 3, "data, order=1, period=2*pi") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const int order = static_cast<int>(optInt(a, 1, 1));
    const double s = periodScale(a, 2);
    if (order == 0)
      return toValue(x);
    return toValue(spectralMap(
        x, [=](double k) { return std::pow(cd(0.0, 1.0) * (k * s), order); }, 0.0, order % 2 == 0));
  } SP_END
  SP_ADD("tilbert", 2, 3, "data, h, period=2*pi") {
    Vec x;
    double h;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, h))
      return Value(0.0);
    const double s = periodScale(a, 2);
    return toValue(spectralMap(
        x, [=](double k) { return cd(0.0, 1.0) / std::tanh(h * k * s); }, 0.0, false));
  } SP_END
  SP_ADD("itilbert", 2, 3, "data, h, period=2*pi") {
    Vec x;
    double h;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, h))
      return Value(0.0);
    const double s = periodScale(a, 2);
    return toValue(spectralMap(
        x, [=](double k) { return cd(0.0, -1.0) * std::tanh(h * k * s); }, 0.0, false));
  } SP_END
  SP_ADD("fft_hilbert", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    return toValue(spectralMap(x, [](double) { return cd(0.0, 1.0); }, 0.0, false));
  } SP_END
  SP_ADD("fft_ihilbert", 1, 1, "data") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    return toValue(spectralMap(x, [](double) { return cd(0.0, -1.0); }, 0.0, false));
  } SP_END
  SP_ADD("cs_diff", 3, 4, "data, a, b, period=2*pi") {
    Vec x;
    double A, B;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, A) || !argNumber(a, 2, ctx, B))
      return Value(0.0);
    const double s = periodScale(a, 3);
    return toValue(spectralMap(
        x, [=](double k) { return cd(0.0, -1.0) * (std::cosh(A * k * s) / std::sinh(B * k * s)); }, 0.0, false));
  } SP_END
  SP_ADD("sc_diff", 3, 4, "data, a, b, period=2*pi") {
    Vec x;
    double A, B;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, A) || !argNumber(a, 2, ctx, B))
      return Value(0.0);
    const double s = periodScale(a, 3);
    return toValue(spectralMap(
        x, [=](double k) { return cd(0.0, 1.0) * (std::sinh(A * k * s) / std::cosh(B * k * s)); }, 0.0, false));
  } SP_END
  SP_ADD("ss_diff", 3, 4, "data, a, b, period=2*pi") {
    Vec x;
    double A, B;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, A) || !argNumber(a, 2, ctx, B))
      return Value(0.0);
    const double s = periodScale(a, 3);
    const double zero = B != 0.0 ? A / B : 0.0;
    return toValue(spectralMap(
        x, [=](double k) { return cd(std::sinh(A * k * s) / std::sinh(B * k * s), 0.0); }, zero, true));
  } SP_END
  SP_ADD("cc_diff", 3, 4, "data, a, b, period=2*pi") {
    Vec x;
    double A, B;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, A) || !argNumber(a, 2, ctx, B))
      return Value(0.0);
    const double s = periodScale(a, 3);
    return toValue(spectralMap(
        x, [=](double k) { return cd(std::cosh(A * k * s) / std::cosh(B * k * s), 0.0); }, 1.0, true));
  } SP_END
  SP_ADD("fft_shift_signal", 2, 3, "data, a, period=2*pi") {
    Vec x;
    double A;
    if (!getVec(a, 0, ctx, x) || !argNumber(a, 1, ctx, A))
      return Value(0.0);
    const double s = periodScale(a, 2);
    return toValue(spectralMap(x, [=](double k) { return std::polar(1.0, A * k * s); }, 1.0, true));
  } SP_END
  SP_ADD("rfftfreq_packed", 1, 2, "n, d=1") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n) || n == 0) {
      if (ctx.ok())
        ctx.fail("n must be at least 1");
      return Value(0.0);
    }
    const double d = optNum(a, 1, 1.0);
    Vec f((size_t)n);
    for (long long i = 1; i < n; i++)
      f[(size_t)i] = static_cast<double>((i + 1) / 2) / (static_cast<double>(n) * d);
    return toValue(f);
  } SP_END
  SP_ADD("fft_conv_kernel", 2, 2, "n, fn") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n) || !isCallable(a[1])) {
      if (ctx.ok())
        ctx.fail("the second argument must name a function of the wavenumber k");
      return Value(0.0);
    }
    NcFn f(a[1]);
    const double scale = 1.0 / static_cast<double>(n);
    Vec om((size_t)n);
    // Packed like rfft_packed: wavenumbers 0, 1, 1, 2, 2, ...
    for (long long i = 0; i < n; i++) {
      const double k = i == 0 ? 0.0 : static_cast<double>((i + 1) / 2);
      om[(size_t)i] = f.scalar(k) * scale;
      if (f.failed) {
        ctx.fail(f.failText());
        return Value(0.0);
      }
    }
    return toValue(om);
  } SP_END
  // Two tables share this name: fft_convolve(data, kernel) with a kernel from
  // fft_conv_kernel() of the same length (fftpack.convolve); any other call is
  // the linear convolution of signal.fftconvolve.
  SP_ADD("fft_convolve", 2, 3, "data, kernel  or  a, b, mode=\"full\"") {
    CMat A, B;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, B))
      return Value(0.0);
    if (a.size() == 2 && ft::isLine(a[0]) && ft::isLine(a[1]) && A.a.size() == B.a.size()) {
      Vec x, om;
      if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, om))
        return Value(0.0);
      Vec p = rfftPacked(x, x.size());
      for (size_t i = 0; i < p.size(); i++)
        p[i] *= om[i] * static_cast<double>(p.size()); // the kernel holds the 1/n
      return toValue(irfftPacked(p));
    }
    const std::string mode = optText(a, 2, "full");
    if (mode != "full" && mode != "same" && mode != "valid") {
      ctx.fail("mode must be \"full\", \"same\" or \"valid\"");
      return Value(0.0);
    }
    size_t fr = A.r + B.r - 1, fc = A.c + B.c - 1;
    size_t mr = 1, mc = 1;
    while (mr < fr)
      mr <<= 1;
    while (mc < fc)
      mc <<= 1;
    CMat FA(mr, mc), FB(mr, mc);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < A.c; j++)
        FA(i, j) = A(i, j);
    for (size_t i = 0; i < B.r; i++)
      for (size_t j = 0; j < B.c; j++)
        FB(i, j) = B(i, j);
    ft::fft2(FA, false);
    ft::fft2(FB, false);
    for (size_t i = 0; i < FA.a.size(); i++)
      FA.a[i] *= FB.a[i];
    ft::fft2(FA, true);
    const bool cplx = a[0].hasComplex() || a[1].hasComplex();
    size_t rr = fr, rc = fc, sr = 0, sc = 0;
    if (mode == "same") {
      rr = A.r;
      rc = A.c;
      sr = (fr - rr) / 2;
      sc = (fc - rc) / 2;
    } else if (mode == "valid") {
      if (B.r > A.r || B.c > A.c) {
        ctx.fail("for mode \"valid\" the second input must not be larger than the first");
        return Value(0.0);
      }
      rr = A.r - B.r + 1;
      rc = A.c - B.c + 1;
      sr = B.r - 1;
      sc = B.c - 1;
    }
    CMat o(rr, rc);
    for (size_t i = 0; i < rr; i++)
      for (size_t j = 0; j < rc; j++) {
        cd v = FA(i + sr, j + sc);
        o(i, j) = cplx ? v : cd(v.real(), 0.0);
      }
    return realIfPossible(o);
  } SP_ENDC
  SP_ADD("fft_convolve_z", 3, 3, "data, kernel_real, kernel_imag") {
    Vec x, re, im;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, re) || !getVec(a, 2, ctx, im))
      return Value(0.0);
    if (re.size() != x.size() || im.size() != x.size()) {
      ctx.fail("the kernels must have the length of the data");
      return Value(0.0);
    }
    // As fftpack: each packed value mixes in its partner through the imaginary kernel.
    Vec p = rfftPacked(x, x.size());
    Vec o(p.size());
    const size_t n = p.size();
    if (n)
      o[0] = p[0] * (re[0] + im[0]);
    for (size_t k = 1; k + 1 < n; k += 2) {
      o[k] = p[k] * re[k] + p[k + 1] * im[k + 1];
      o[k + 1] = p[k + 1] * re[k + 1] + p[k] * im[k];
    }
    if (n > 1 && n % 2 == 0)
      o[n - 1] = p[n - 1] * (re[n - 1] + im[n - 1]);
    for (double &v : o)
      v *= static_cast<double>(n); // the kernels hold the 1/n
    return toValue(irfftPacked(o));
  } SP_END
}

} // namespace scipy
} // namespace nc
