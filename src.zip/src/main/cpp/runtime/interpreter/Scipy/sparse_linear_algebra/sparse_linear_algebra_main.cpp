// Section 17 of 25 - Sparse Linear Algebra (scipy.sparse.linalg). The product A*v
// is the only way these solvers touch A, so Sparse, Matrix and an NC function
// (linear_operator) all work, and the product is where threads will go.
#include "sparse_linear_algebra_main.h"

#include <random>

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "../sparse_matrices/sp_core.h"

#define SP_SEC Section::SparseLinearAlgebra

namespace nc {
namespace scipy {

using namespace sp;

namespace {

double dot(const Vec &x, const Vec &y) {
  return par::reduceBlocks(x.size(), {par::Kind::Reduce, 1.0}, 0.0,
                           [&](size_t b, size_t e) {
                             double s = 0.0;
                             for (size_t i = b; i < e; i++)
                               s += x[i] * y[i];
                             return s;
                           },
                           [](double p, double q) { return p + q; });
}
double norm2(const Vec &x) { return std::sqrt(dot(x, x)); }
void axpy(double a, const Vec &x, Vec &y) {
  for (size_t i = 0; i < x.size(); i++)
    y[i] += a * x[i];
}

// A dense, sparse or function-backed operator.
struct Op {
  size_t r = 0, c = 0;
  Sparse S;
  bool useS = false;
  Value matvec, rmatvec;
  mutable bool failed = false;
  Vec mul(const Vec &x) const {
    if (useS)
      return sp::mulVec(S, x);
    Value o;
    Vec y;
    if (failed || !callNC(matvec, {toValue(x)}, o) || !readVec(o, y) || y.size() != r) {
      failed = true;
      return Vec(r, kNaN);
    }
    return y;
  }
  Vec mulT(const Vec &x) const {
    if (useS)
      return sp::mulVecT(S, x);
    Value o;
    Vec y;
    if (!isCallable(rmatvec)) {
      failed = true;
      return Vec(c, kNaN);
    }
    if (failed || !callNC(rmatvec, {toValue(x)}, o) || !readVec(o, y) || y.size() != c) {
      failed = true;
      return Vec(c, kNaN);
    }
    return y;
  }
};

bool isOperatorValue(const Value &v) {
  const Value *k = dictGet(v, "kind");
  return v.isDict && k && k->isText && k->text() == "linear_operator";
}

bool getOp(const Args &a, size_t i, CallContext &ctx, Op &op) {
  if (i < a.size() && isOperatorValue(a[i])) {
    Vec shape;
    const Value *sh = dictGet(a[i], "shape"), *mv = dictGet(a[i], "matvec"), *rm = dictGet(a[i], "rmatvec"), *mt = dictGet(a[i], "matrix");
    if (!sh || !readVec(*sh, shape) || shape.size() != 2) {
      ctx.fail("this operator has no valid shape");
      return false;
    }
    op.r = (size_t)shape[0];
    op.c = (size_t)shape[1];
    if (mt) {
      if (!readAny(*mt, op.S)) {
        ctx.fail("this operator has no valid matrix");
        return false;
      }
      op.useS = true;
    } else if (mv) {
      op.matvec = *mv;
      if (rm)
        op.rmatvec = *rm;
    }
    return true;
  }
  if (!getAny(a, i, ctx, op.S))
    return false;
  op.useS = true;
  op.r = op.S.r;
  op.c = op.S.c;
  return true;
}

struct IterResult {
  Vec x;
  long info = 0;
};

// All the iterative solvers below return when ||r|| <= tol * ||b||.
IterResult cgSolve(const Op &A, const Vec &b, double tol, long maxit) {
  IterResult R{Vec(b.size(), 0.0), 1};
  Vec r = b, p = r;
  double rs = dot(r, r);
  const double target = tol * norm2(b);
  for (long k = 0; k < maxit; k++) {
    if (std::sqrt(rs) <= target) {
      R.info = 0;
      return R;
    }
    Vec q = A.mul(p);
    const double al = rs / dot(p, q);
    axpy(al, p, R.x);
    axpy(-al, q, r);
    const double rn = dot(r, r);
    const double be = rn / rs;
    for (size_t i = 0; i < p.size(); i++)
      p[i] = r[i] + be * p[i];
    rs = rn;
  }
  R.info = std::sqrt(rs) <= target ? 0 : maxit;
  return R;
}

IterResult bicgSolve(const Op &A, const Vec &b, double tol, long maxit) {
  IterResult R{Vec(b.size(), 0.0), maxit};
  Vec r = b, rt = b, p = r, pt = rt;
  double rho = dot(r, rt);
  const double target = tol * norm2(b);
  for (long k = 0; k < maxit; k++) {
    if (norm2(r) <= target) {
      R.info = 0;
      return R;
    }
    Vec q = A.mul(p), qt = A.mulT(pt);
    const double al = rho / dot(pt, q);
    axpy(al, p, R.x);
    axpy(-al, q, r);
    axpy(-al, qt, rt);
    const double rn = dot(r, rt);
    const double be = rn / rho;
    for (size_t i = 0; i < p.size(); i++) {
      p[i] = r[i] + be * p[i];
      pt[i] = rt[i] + be * pt[i];
    }
    rho = rn;
  }
  if (norm2(r) <= target)
    R.info = 0;
  return R;
}

IterResult bicgstabSolve(const Op &A, const Vec &b, double tol, long maxit) {
  IterResult R{Vec(b.size(), 0.0), maxit};
  Vec r = b, r0 = b, p(b.size(), 0.0), v(b.size(), 0.0);
  double rho = 1.0, al = 1.0, om = 1.0;
  const double target = tol * norm2(b);
  for (long k = 0; k < maxit; k++) {
    if (norm2(r) <= target) {
      R.info = 0;
      return R;
    }
    const double rn = dot(r0, r);
    const double be = (rn / rho) * (al / om);
    for (size_t i = 0; i < p.size(); i++)
      p[i] = r[i] + be * (p[i] - om * v[i]);
    v = A.mul(p);
    al = rn / dot(r0, v);
    Vec s = r;
    axpy(-al, v, s);
    if (norm2(s) <= target) {
      axpy(al, p, R.x);
      R.info = 0;
      return R;
    }
    Vec t = A.mul(s);
    om = dot(t, s) / dot(t, t);
    axpy(al, p, R.x);
    axpy(om, s, R.x);
    r = s;
    axpy(-om, t, r);
    rho = rn;
  }
  if (norm2(r) <= target)
    R.info = 0;
  return R;
}

IterResult cgsSolve(const Op &A, const Vec &b, double tol, long maxit) {
  IterResult R{Vec(b.size(), 0.0), maxit};
  Vec r = b, r0 = b, p(b.size(), 0.0), u(b.size(), 0.0), q(b.size(), 0.0);
  double rho = 1.0;
  const double target = tol * norm2(b);
  for (long k = 0; k < maxit; k++) {
    if (norm2(r) <= target) {
      R.info = 0;
      return R;
    }
    const double rn = dot(r0, r);
    const double be = k == 0 ? 0.0 : rn / rho;
    for (size_t i = 0; i < p.size(); i++) {
      u[i] = r[i] + be * q[i];
      p[i] = u[i] + be * (q[i] + be * p[i]);
    }
    Vec v = A.mul(p);
    const double al = rn / dot(r0, v);
    for (size_t i = 0; i < p.size(); i++)
      q[i] = u[i] - al * v[i];
    Vec w = u;
    axpy(1.0, q, w);
    axpy(al, w, R.x);
    Vec Aw = A.mul(w);
    axpy(-al, Aw, r);
    rho = rn;
  }
  if (norm2(r) <= target)
    R.info = 0;
  return R;
}

// GMRES with optional deflation vectors: each cycle's Krylov space is extended
// by the vectors in `extra` (LGMRES and GCROT(m,k) keep their error directions there).
IterResult gmresCore(const Op &A, const Vec &b, double tol, long maxit, long restart, long keep) {
  const size_t n = b.size();
  IterResult R{Vec(n, 0.0), maxit};
  const double target = tol * norm2(b);
  std::vector<Vec> outer;
  long iters = 0;
  while (iters < maxit) {
    Vec r = b;
    axpy(-1.0, A.mul(R.x), r);
    const double beta = norm2(r);
    if (beta <= target) {
      R.info = 0;
      return R;
    }
    const long inner = std::min<long>(restart, static_cast<long>(n));
    const long m = inner + static_cast<long>(outer.size());
    std::vector<Vec> V, Z;
    Mat H(m + 1, m);
    V.push_back(r);
    for (double &v : V[0])
      v /= beta;
    Vec g(m + 1, 0.0), cs(m, 0.0), sn(m, 0.0);
    g[0] = beta;
    long j = 0;
    for (; j < m; j++) {
      // The first steps follow the Krylov space; the last ones the kept directions.
      Vec zj = j < inner ? V[j] : outer[j - inner];
      Vec w = A.mul(zj);
      Z.push_back(zj);
      for (long i = 0; i <= j; i++) {
        H(i, j) = dot(w, V[i]);
        axpy(-H(i, j), V[i], w);
      }
      H(j + 1, j) = norm2(w);
      const bool breakdown = H(j + 1, j) <= 1e-14 * beta;
      if (!breakdown) {
        for (double &v : w)
          v /= H(j + 1, j);
        V.push_back(w);
      }
      for (long i = 0; i < j; i++) {
        const double t = cs[i] * H(i, j) + sn[i] * H(i + 1, j);
        H(i + 1, j) = -sn[i] * H(i, j) + cs[i] * H(i + 1, j);
        H(i, j) = t;
      }
      const double rr = std::hypot(H(j, j), H(j + 1, j));
      cs[j] = rr == 0.0 ? 1.0 : H(j, j) / rr;
      sn[j] = rr == 0.0 ? 0.0 : H(j + 1, j) / rr;
      H(j, j) = rr;
      H(j + 1, j) = 0.0;
      g[j + 1] = -sn[j] * g[j];
      g[j] = cs[j] * g[j];
      iters++;
      if (std::fabs(g[j + 1]) <= target || breakdown) {
        j++;
        break;
      }
    }
    Vec y(j, 0.0);
    for (long i = j - 1; i >= 0; i--) {
      double s = g[i];
      for (long k = i + 1; k < j; k++)
        s -= H(i, k) * y[k];
      y[i] = H(i, i) != 0.0 ? s / H(i, i) : 0.0;
    }
    Vec dx(n, 0.0);
    for (long i = 0; i < j; i++)
      axpy(y[i], Z[i], dx);
    axpy(1.0, dx, R.x);
    if (keep > 0) {
      const double nd = norm2(dx);
      if (nd > 0.0) {
        for (double &v : dx)
          v /= nd;
        outer.insert(outer.begin(), dx);
        if (static_cast<long>(outer.size()) > keep)
          outer.pop_back();
      }
    }
  }
  Vec r = b;
  axpy(-1.0, A.mul(R.x), r);
  if (norm2(r) <= target)
    R.info = 0;
  return R;
}

// MINRES (Paige and Saunders) for symmetric A.
IterResult minresSolve(const Op &A, const Vec &b, double tol, long maxit) {
  const size_t n = b.size();
  IterResult R{Vec(n, 0.0), maxit};
  Vec v = b, vOld(n, 0.0), w(n, 0.0), wOld(n, 0.0);
  double beta = norm2(b), betaOld = 0.0;
  const double target = tol * beta;
  if (beta == 0.0) {
    R.info = 0;
    return R;
  }
  double eta = beta, c = 1.0, s = 0.0, cOld = 1.0, sOld = 0.0;
  for (double &q : v)
    q /= beta;
  double res = beta;
  for (long k = 0; k < maxit; k++) {
    if (res <= target) {
      R.info = 0;
      return R;
    }
    Vec Av = A.mul(v);
    const double alpha = dot(v, Av);
    Vec vNew = Av;
    axpy(-alpha, v, vNew);
    axpy(-beta * (k ? 1.0 : 0.0), vOld, vNew);
    const double betaNew = norm2(vNew);
    const double r3 = sOld * beta;
    const double r2 = c * cOld * beta + s * alpha * 1.0;
    const double r1t = -s * cOld * beta + c * alpha;
    const double r1 = std::hypot(r1t, betaNew);
    const double cNew = r1 == 0.0 ? 1.0 : r1t / r1, sNew = r1 == 0.0 ? 0.0 : betaNew / r1;
    Vec wNew(n);
    for (size_t i = 0; i < n; i++)
      wNew[i] = r1 == 0.0 ? 0.0 : (v[i] - r3 * wOld[i] - r2 * w[i]) / r1;
    axpy(cNew * eta, wNew, R.x);
    eta = -sNew * eta;
    res = std::fabs(eta);
    wOld = w;
    w = wNew;
    vOld = v;
    if (betaNew > 0.0)
      for (size_t i = 0; i < n; i++)
        v[i] = vNew[i] / betaNew;
    betaOld = beta;
    beta = betaNew;
    sOld = s;
    cOld = c;
    s = sNew;
    c = cNew;
    (void)betaOld;
    if (betaNew == 0.0)
      break;
  }
  if (res <= target)
    R.info = 0;
  return R;
}

// QMR by simple look-ahead-free two-sided Lanczos.
IterResult qmrSolve(const Op &A, const Vec &b, double tol, long maxit) {
  const size_t n = b.size();
  IterResult R{Vec(n, 0.0), maxit};
  Vec r = b, vt = r, wt = r;
  const double target = tol * norm2(b);
  double rho = norm2(vt), xi = norm2(wt), gamma = 1.0, eta = -1.0, epsv = 1.0, theta = 0.0;
  Vec v(n), w(n), p(n, 0.0), q(n, 0.0), d(n, 0.0), s(n, 0.0);
  for (long k = 0; k < maxit; k++) {
    if (norm2(r) <= target) {
      R.info = 0;
      return R;
    }
    for (size_t i = 0; i < n; i++) {
      v[i] = vt[i] / rho;
      w[i] = wt[i] / xi;
    }
    const double delta = dot(w, v);
    if (delta == 0.0)
      break;
    if (k == 0) {
      p = v;
      q = w;
    } else {
      const double pcoef = xi * delta / epsv, qcoef = rho * delta / epsv;
      for (size_t i = 0; i < n; i++) {
        p[i] = v[i] - pcoef * p[i];
        q[i] = w[i] - qcoef * q[i];
      }
    }
    Vec pt = A.mul(p);
    epsv = dot(q, pt);
    if (epsv == 0.0)
      break;
    const double beta = epsv / delta;
    vt = pt;
    axpy(-beta, v, vt);
    wt = A.mulT(q);
    axpy(-beta, w, wt);
    const double rhoOld = rho;
    rho = norm2(vt);
    xi = norm2(wt);
    const double thetaOld = theta, gammaOld = gamma;
    theta = rho / (gammaOld * std::fabs(beta));
    gamma = 1.0 / std::sqrt(1.0 + theta * theta);
    if (gamma == 0.0)
      break;
    eta = -eta * rhoOld * gamma * gamma / (beta * gammaOld * gammaOld);
    if (k == 0) {
      for (size_t i = 0; i < n; i++) {
        d[i] = eta * p[i];
        s[i] = eta * pt[i];
      }
    } else {
      const double f = (thetaOld * gamma) * (thetaOld * gamma);
      for (size_t i = 0; i < n; i++) {
        d[i] = eta * p[i] + f * d[i];
        s[i] = eta * pt[i] + f * s[i];
      }
    }
    axpy(1.0, d, R.x);
    axpy(-1.0, s, r);
  }
  if (norm2(r) <= target)
    R.info = 0;
  return R;
}

IterResult tfqmrSolve(const Op &A, const Vec &b, double tol, long maxit) {
  const size_t n = b.size();
  IterResult R{Vec(n, 0.0), maxit};
  Vec r0 = b, w = r0, u = r0, d(n, 0.0), v = A.mul(u), Au = v;
  double tau = norm2(r0), theta = 0.0, eta = 0.0, rho = dot(r0, r0);
  const double target = tol * norm2(b);
  Vec u2 = u;
  for (long k = 0; k < maxit; k++) {
    const double sigma = dot(r0, v);
    if (sigma == 0.0)
      break;
    const double alpha = rho / sigma;
    u2 = u;
    axpy(-alpha, v, u2);
    Vec Au2 = A.mul(u2);
    for (int half = 0; half < 2; half++) {
      const Vec &uu = half == 0 ? u : u2;
      const Vec &Auu = half == 0 ? Au : Au2;
      axpy(-alpha, Auu, w);
      const double nw = norm2(w);
      const double thetaNew = nw / tau;
      const double c = 1.0 / std::sqrt(1.0 + thetaNew * thetaNew);
      const double dcoef = theta * theta * eta / alpha;
      for (size_t i = 0; i < n; i++)
        d[i] = uu[i] + dcoef * d[i];
      tau = tau * thetaNew * c;
      eta = c * c * alpha;
      theta = thetaNew;
      axpy(eta, d, R.x);
      if (tau * std::sqrt(k * 2.0 + half + 2.0) <= target) {
        Vec rr = b;
        axpy(-1.0, A.mul(R.x), rr);
        if (norm2(rr) <= target * 10.0) {
          R.info = 0;
          return R;
        }
      }
    }
    const double rhoNew = dot(r0, w);
    const double beta = rhoNew / rho;
    rho = rhoNew;
    for (size_t i = 0; i < n; i++)
      u[i] = w[i] + beta * u2[i];
    Au = A.mul(u);
    for (size_t i = 0; i < n; i++)
      v[i] = Au[i] + beta * (Au2[i] + beta * v[i]);
  }
  Vec rr = b;
  axpy(-1.0, A.mul(R.x), rr);
  if (norm2(rr) <= target * 10.0)
    R.info = 0;
  return R;
}

// LSQR and LSMR on A x ~ b.
void lsqrSolve(const Op &A, const Vec &b, double tol, long maxit, Vec &x, long &istop, long &itn, double &rnorm) {
  x.assign(A.c, 0.0);
  Vec u = b;
  double beta = norm2(u), alpha = 0.0;
  istop = 0;
  itn = 0;
  rnorm = beta;
  if (beta == 0.0)
    return;
  for (double &q : u)
    q /= beta;
  Vec v = A.mulT(u);
  alpha = norm2(v);
  if (alpha == 0.0)
    return;
  for (double &q : v)
    q /= alpha;
  Vec w = v;
  double phiBar = beta, rhoBar = alpha;
  const double bnorm = beta;
  double anorm2 = 0.0;
  for (itn = 1; itn <= maxit; itn++) {
    Vec Av = A.mul(v);
    for (size_t i = 0; i < u.size(); i++)
      u[i] = Av[i] - alpha * u[i];
    beta = norm2(u);
    if (beta > 0.0) {
      for (double &q : u)
        q /= beta;
      anorm2 += alpha * alpha + beta * beta;
      Vec Atu = A.mulT(u);
      for (size_t i = 0; i < v.size(); i++)
        v[i] = Atu[i] - beta * v[i];
      alpha = norm2(v);
      if (alpha > 0.0)
        for (double &q : v)
          q /= alpha;
    }
    const double rho = std::hypot(rhoBar, beta), c = rhoBar / rho, s = beta / rho;
    const double theta = s * alpha;
    rhoBar = -c * alpha;
    const double phi = c * phiBar;
    phiBar = s * phiBar;
    axpy(phi / rho, w, x);
    for (size_t i = 0; i < w.size(); i++)
      w[i] = v[i] - (theta / rho) * w[i];
    rnorm = phiBar;
    const double arnorm = phiBar * alpha * std::fabs(c);
    const double an = std::sqrt(anorm2);
    if (rnorm <= tol * (bnorm + an * norm2(x))) {
      istop = 1;
      break;
    }
    if (arnorm <= tol * an * rnorm) {
      istop = 2;
      break;
    }
  }
  if (istop == 0)
    istop = 7;
}

void lsmrSolve(const Op &A, const Vec &b, double tol, long maxit, Vec &x, long &istop, long &itn, double &normr) {
  x.assign(A.c, 0.0);
  Vec u = b;
  double beta = norm2(u);
  normr = beta;
  istop = 0;
  itn = 0;
  if (beta == 0.0)
    return;
  for (double &q : u)
    q /= beta;
  Vec v = A.mulT(u);
  double alpha = norm2(v);
  if (alpha == 0.0)
    return;
  for (double &q : v)
    q /= alpha;
  double alphaBar = alpha, zetaBar = alpha * beta, rho = 1.0, rhoBar = 1.0, cBar = 1.0, sBar = 0.0;
  Vec h = v, hBar(A.c, 0.0);
  const double bnorm = beta;
  double anorm2 = alpha * alpha;
  for (itn = 1; itn <= maxit; itn++) {
    Vec Av = A.mul(v);
    for (size_t i = 0; i < u.size(); i++)
      u[i] = Av[i] - alpha * u[i];
    beta = norm2(u);
    if (beta > 0.0) {
      for (double &q : u)
        q /= beta;
      Vec Atu = A.mulT(u);
      for (size_t i = 0; i < v.size(); i++)
        v[i] = Atu[i] - beta * v[i];
      alpha = norm2(v);
      if (alpha > 0.0)
        for (double &q : v)
          q /= alpha;
    }
    anorm2 += alpha * alpha + beta * beta;
    const double rhoOld = rho;
    rho = std::hypot(alphaBar, beta);
    const double c = alphaBar / rho, s = beta / rho;
    const double theta = s * alpha;
    alphaBar = c * alpha;
    const double rhoBarOld = rhoBar, thetaBar = sBar * rho;
    const double rhoTmp = cBar * rho;
    rhoBar = std::hypot(rhoTmp, theta);
    cBar = rhoTmp / rhoBar;
    sBar = theta / rhoBar;
    const double zeta = cBar * zetaBar;
    zetaBar = -sBar * zetaBar;
    for (size_t i = 0; i < h.size(); i++) {
      hBar[i] = h[i] - (thetaBar * rho / (rhoOld * rhoBarOld)) * hBar[i];
      x[i] += (zeta / (rho * rhoBar)) * hBar[i];
      h[i] = v[i] - (theta / rho) * h[i];
    }
    Vec res = b;
    axpy(-1.0, A.mul(x), res);
    normr = norm2(res);
    const double an = std::sqrt(anorm2);
    if (normr <= tol * (bnorm + an * norm2(x))) {
      istop = 1;
      break;
    }
    if (std::fabs(zetaBar) <= tol * an * normr) {
      istop = 2;
      break;
    }
  }
  if (istop == 0)
    istop = 7;
}

Mat denseOf(const Op &A) {
  if (A.useS)
    return toDense(A.S);
  Mat D(A.r, A.c);
  Vec e(A.c, 0.0);
  for (size_t j = 0; j < A.c; j++) {
    e[j] = 1.0;
    Vec col = A.mul(e);
    for (size_t i = 0; i < A.r; i++)
      D(i, j) = col[i];
    e[j] = 0.0;
  }
  return D;
}

// Thick-restart Lanczos for a few eigenpairs of a symmetric operator. Small
// problems go straight to the dense solver.
void symEigs(const Op &A, size_t k, const std::string &which, Vec &w, Mat &Z) {
  const size_t n = A.r;
  auto sortedPick = [&](const Vec &vals, std::vector<size_t> &order) {
    order.resize(vals.size());
    for (size_t i = 0; i < vals.size(); i++)
      order[i] = i;
    std::sort(order.begin(), order.end(), [&](size_t x, size_t y) {
      if (which == "LM") return std::fabs(vals[x]) > std::fabs(vals[y]);
      if (which == "SM") return std::fabs(vals[x]) < std::fabs(vals[y]);
      if (which == "SA") return vals[x] < vals[y];
      return vals[x] > vals[y]; // LA
    });
  };
  auto finish = [&](const Vec &vals, const Mat &vecs, const std::vector<size_t> &order) {
    std::vector<size_t> sel(order.begin(), order.begin() + k);
    std::sort(sel.begin(), sel.end(), [&](size_t x, size_t y) { return vals[x] < vals[y]; });
    w.resize(k);
    Z = Mat(n, k);
    for (size_t j = 0; j < k; j++) {
      w[j] = vals[sel[j]];
      for (size_t i = 0; i < n; i++)
        Z(i, j) = vecs(i, sel[j]);
    }
  };
  std::vector<size_t> order;
  if (n <= 600) {
    Vec vals;
    Mat vecs;
    la::eigHermitian(denseOf(A), vals, vecs);
    sortedPick(vals, order);
    finish(vals, vecs, order);
    return;
  }
  // One eigenpair at a time, each search kept orthogonal to those found, so a
  // repeated eigenvalue is found as often as it occurs. Restarts keep the best Ritz vectors.
  const size_t m = std::min(n - 1, std::max<size_t>(k + 40, 60));
  std::mt19937_64 gen(1234);
  std::normal_distribution<double> nd;
  std::vector<Vec> locked;
  Vec lockedVals;
  auto purge = [&](Vec &q) {
    for (int pass = 0; pass < 2; pass++)
      for (const Vec &l : locked)
        axpy(-dot(q, l), l, q);
  };
  for (size_t found = 0; found < k; found++) {
    Vec v0(n);
    for (double &x : v0)
      x = nd(gen);
    purge(v0);
    const double n0 = norm2(v0);
    for (double &x : v0)
      x /= n0;
    std::vector<Vec> V{v0};
    Vec best;
    double bestVal = 0.0;
    for (int cycle = 0; cycle < 400; cycle++) {
      const size_t start = V.size() - 1;
      Mat T(m, m);
      for (size_t i = 0; i < start; i++) {
        Vec q = A.mul(V[i]);
        for (size_t j = 0; j < V.size(); j++)
          T(i, j) = T(j, i) = dot(q, V[j]);
      }
      for (size_t j = start; j < m; j++) {
        Vec q = A.mul(V[j]);
        purge(q);
        for (size_t i = 0; i <= j; i++) {
          const double h = dot(q, V[i]);
          T(i, j) = T(j, i) = h;
          axpy(-h, V[i], q);
        }
        for (size_t i = 0; i <= j; i++)
          axpy(-dot(q, V[i]), V[i], q);
        const double nq = norm2(q);
        if (nq > 0.0)
          for (double &x : q)
            x /= nq;
        if (V.size() <= j + 1)
          V.push_back(q);
        else
          V[j + 1] = q;
      }
      Vec vals;
      Mat S;
      la::eigHermitian(T, vals, S);
      sortedPick(vals, order);
      Vec x(n, 0.0);
      for (size_t j = 0; j < m; j++)
        axpy(S(j, order[0]), V[j], x);
      Vec r = A.mul(x);
      purge(r);
      axpy(-vals[order[0]], x, r);
      best = x;
      bestVal = vals[order[0]];
      if (norm2(r) <= 1e-9 * std::max(1e-300, std::fabs(bestVal)))
        break;
      const size_t keepN = std::min(m - 1, std::max<size_t>(4, m / 2));
      std::vector<Vec> W;
      for (size_t c = 0; c < keepN; c++) {
        Vec y(n, 0.0);
        for (size_t j = 0; j < m; j++)
          axpy(S(j, order[c]), V[j], y);
        W.push_back(y);
      }
      W.push_back(V[m]);
      V = W;
    }
    locked.push_back(best);
    lockedVals.push_back(bestVal);
  }
  Mat vecs(n, k);
  for (size_t c = 0; c < k; c++)
    for (size_t i = 0; i < n; i++)
      vecs(i, c) = locked[c][i];
  order.resize(k);
  for (size_t c = 0; c < k; c++)
    order[c] = c;
  finish(lockedVals, vecs, order);
}

} // namespace

void registerSparseLinearAlgebra(Registry &reg) {
  SP_ADD("linear_operator", 1, 3, "A  or  shape, matvec, rmatvec") {
    if (a.size() == 1) {
      Sparse s;
      if (!getAny(a, 0, ctx, s))
        return Value(0.0);
      return makeDict({{"kind", Value(std::string("linear_operator"))}, {"shape", toValue(Vec{(double)s.r, (double)s.c})}, {"matrix", sp::toValue(s)}});
    }
    Vec shape;
    if (!getVec(a, 0, ctx, shape) || shape.size() != 2 || !isCallable(a[1])) {
      if (ctx.ok())
        ctx.fail("give [rows, cols] and the name of an NC function v -> A*v");
      return Value(0.0);
    }
    DictInit d{{"kind", Value(std::string("linear_operator"))}, {"shape", toValue(shape)}, {"matvec", a[1]}};
    if (a.size() > 2)
      d.push_back({"rmatvec", a[2]});
    return makeDict(d);
  } SP_END
  // Declared here because operators live in this section; handles every input
  // form of the sparse tables.
  SP_ADD("sparse_mul", 2, 2, "A, B") {
    Op op;
    if (!getOp(a, 0, ctx, op))
      return Value(0.0);
    if (isSparse(a[1])) {
      Sparse B;
      fromValue(a[1], B);
      if (!op.useS) {
        ctx.fail("an operator can only multiply arrays and matrices");
        return Value(0.0);
      }
      if (op.c != B.r) {
        ctx.fail("the sizes do not fit: " + std::to_string(op.c) + " columns against " + std::to_string(B.r) + " rows");
        return Value(0.0);
      }
      return sp::toValue(mulSparse(op.S, B));
    }
    Mat X;
    if (!getMat(a, 1, ctx, X))
      return Value(0.0);
    const bool line = X.r == 1 || X.c == 1;
    if (line && X.a.size() == op.c) {
      Vec y = op.mul(X.a);
      if (op.failed) {
        ctx.fail("the operator's function could not be evaluated");
        return Value(0.0);
      }
      return toValue(y);
    }
    if (X.r != op.c) {
      ctx.fail("the sizes do not fit: " + std::to_string(op.c) + " columns against " + std::to_string(X.r) + " rows");
      return Value(0.0);
    }
    Mat O(op.r, X.c);
    for (size_t j = 0; j < X.c; j++) {
      Vec col(X.r);
      for (size_t i = 0; i < X.r; i++)
        col[i] = X(i, j);
      Vec y = op.mul(col);
      for (size_t i = 0; i < op.r; i++)
        O(i, j) = y[i];
    }
    return toValue(O);
  } SP_END
  SP_ADD("laplacian_grid", 1, 2, "shape, boundary=\"neumann\"") {
    Vec sh;
    if (!getVec(a, 0, ctx, sh))
      return Value(0.0);
    const std::string bc = optText(a, 1, "neumann");
    if (bc != "dirichlet" && bc != "neumann" && bc != "periodic") {
      ctx.fail("boundary must be \"dirichlet\", \"neumann\" or \"periodic\"");
      return Value(0.0);
    }
    double totalD = 1.0;
    for (double v : sh) {
      if (!(v >= 1.0) || v != std::floor(v)) {
        ctx.fail("each size of the shape must be a whole number, 1 or more");
        return Value(0.0);
      }
      totalD *= v;
    }
    if (totalD > 1e7) {
      ctx.fail("the grid must have at most 10000000 points");
      return Value(0.0);
    }
    size_t total = (size_t)totalD;
    std::vector<Triplet> t;
    size_t stride = total;
    for (double dv : sh) {
      const size_t n = (size_t)dv;
      stride /= n;
      for (size_t p = 0; p < total; p++) {
        const size_t coord = (p / stride) % n;
        double diag = -2.0;
        if (coord > 0)
          t.push_back({p, p - stride, 1.0});
        else if (bc == "periodic" && n > 1)
          t.push_back({p, p + stride * (n - 1), 1.0});
        else if (bc == "neumann")
          diag += 1.0;
        if (coord + 1 < n)
          t.push_back({p, p + stride, 1.0});
        else if (bc == "periodic" && n > 1)
          t.push_back({p, p - stride * (n - 1), 1.0});
        else if (bc == "neumann")
          diag += 1.0;
        t.push_back({p, p, diag});
      }
    }
    return sp::toValue(fromTriplets(total, total, std::move(t), "csr"));
  } SP_END
  SP_ADD("sparse_inv", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (s.r != s.c) {
      ctx.fail("the matrix must be square");
      return Value(0.0);
    }
    SparseLU f = sparseLU(s);
    if (f.singular) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    std::vector<Triplet> t;
    Vec e(s.r, 0.0);
    for (size_t j = 0; j < s.r; j++) {
      e[j] = 1.0;
      Vec x = luSolve(f, e);
      e[j] = 0.0;
      for (size_t i = 0; i < s.r; i++)
        if (x[i] != 0.0)
          t.push_back({i, j, x[i]});
    }
    return sp::toValue(fromTriplets(s.r, s.c, std::move(t), s.fmt));
  } SP_END
  SP_ADD("sparse_norm", 1, 2, "A, ord=\"fro\"") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (a.size() > 1 && !a[1].isText) {
      const double o = optNum(a, 1, 1.0);
      Vec sums(std::isinf(o) ? s.r : s.c, 0.0);
      if (std::fabs(o) != 1.0 && !std::isinf(o)) {
        ctx.fail("ord must be \"fro\", 1, -1, inf or -inf");
        return Value(0.0);
      }
      for (size_t i = 0; i < s.r; i++)
        for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++)
          sums[std::isinf(o) ? i : s.idx[k]] += std::fabs(s.val[k]);
      return Value(o > 0 ? *std::max_element(sums.begin(), sums.end()) : *std::min_element(sums.begin(), sums.end()));
    }
    double t = 0.0;
    for (double v : s.val)
      t += v * v;
    return Value(std::sqrt(t));
  } SP_END
  SP_ADD("onenorm_est", 1, 1, "A") {
    Op op;
    if (!getOp(a, 0, ctx, op))
      return Value(0.0);
    if (op.useS) {
      Vec sums(op.c, 0.0);
      for (size_t i = 0; i < op.S.r; i++)
        for (size_t k = op.S.ptr[i]; k < op.S.ptr[i + 1]; k++)
          sums[op.S.idx[k]] += std::fabs(op.S.val[k]);
      return Value(*std::max_element(sums.begin(), sums.end()));
    }
    // Higham's power method on the 1-norm, for operators.
    Vec x(op.c, 1.0 / (double)op.c);
    double est = 0.0;
    for (int it = 0; it < 6 && !op.failed; it++) {
      Vec y = op.mul(x);
      double n1 = 0.0;
      for (double v : y)
        n1 += std::fabs(v);
      if (n1 <= est && it > 0)
        break;
      est = n1;
      Vec sg(y.size());
      for (size_t i = 0; i < y.size(); i++)
        sg[i] = y[i] >= 0 ? 1.0 : -1.0;
      Vec z = op.mulT(sg);
      size_t j = 0;
      for (size_t i = 0; i < z.size(); i++)
        if (std::fabs(z[i]) > std::fabs(z[j]))
          j = i;
      std::fill(x.begin(), x.end(), 0.0);
      x[j] = 1.0;
    }
    return Value(est);
  } SP_END
  SP_ADD("sparse_solve", 2, 2, "A, b") {
    Sparse s;
    Mat B;
    if (!getAny(a, 0, ctx, s) || !getMat(a, 1, ctx, B))
      return Value(0.0);
    if (s.r != s.c) {
      ctx.fail("the matrix must be square");
      return Value(0.0);
    }
    SparseLU f = sparseLU(s);
    if (f.singular) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    if (B.r == 1 || B.c == 1) {
      if (B.a.size() != s.r) {
        ctx.fail("b must have one value per row of A");
        return Value(0.0);
      }
      return toValue(luSolve(f, B.a));
    }
    if (B.r != s.r) {
      ctx.fail("b must have as many rows as A");
      return Value(0.0);
    }
    Mat X(B.r, B.c);
    for (size_t j = 0; j < B.c; j++) {
      Vec c(B.r);
      for (size_t i = 0; i < B.r; i++)
        c[i] = B(i, j);
      Vec x = luSolve(f, c);
      for (size_t i = 0; i < B.r; i++)
        X(i, j) = x[i];
    }
    return toValue(X);
  } SP_END
  SP_ADD("sparse_solve_tri", 2, 3, "A, b, lower=1") {
    Sparse s;
    Vec b;
    if (!getAny(a, 0, ctx, s) || !getVec(a, 1, ctx, b))
      return Value(0.0);
    if (s.r != s.c || b.size() != s.r) {
      ctx.fail("A must be square and b must have one value per row");
      return Value(0.0);
    }
    const bool lower = optBool(a, 2, true);
    const size_t n = s.r;
    Vec x = b;
    auto step = [&](size_t i) {
      double t = x[i], d = 0.0;
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++) {
        const size_t j = s.idx[k];
        if (j == i)
          d = s.val[k];
        else if (lower ? j < i : j > i)
          t -= s.val[k] * x[j];
      }
      if (d == 0.0)
        return false;
      x[i] = t / d;
      return true;
    };
    bool ok = true;
    if (lower)
      for (size_t i = 0; i < n && ok; i++)
        ok = step(i);
    else
      for (size_t i = n; i-- > 0 && ok;)
        ok = step(i);
    if (!ok) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    return toValue(x);
  } SP_END
  SP_ADD("sparse_is_tri", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    bool lo = true, up = true;
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++) {
        if (s.idx[k] > i)
          lo = false;
        if (s.idx[k] < i)
          up = false;
      }
    return makeDict({{"lower", Value::boolean(lo)}, {"upper", Value::boolean(up)}});
  } SP_END
  SP_ADD("sparse_bandwidth", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    long lo = 0, up = 0;
    for (size_t i = 0; i < s.r; i++)
      for (size_t k = s.ptr[i]; k < s.ptr[i + 1]; k++) {
        lo = std::max(lo, (long)i - (long)s.idx[k]);
        up = std::max(up, (long)s.idx[k] - (long)i);
      }
    return makeDict({{"lower", Value((double)lo)}, {"upper", Value((double)up)}});
  } SP_END
#define NC_LU_RESULT(F)                                                                            \
  IVec pr(s.r), pc(F.permC.begin(), F.permC.end());                                                \
  for (size_t i = 0; i < s.r; i++)                                                                 \
    pr[i] = (long long)F.permR[i];                                                                 \
  return makeDict({{"L", sp::toValue(F.L)}, {"U", sp::toValue(F.U)}, {"perm_r", toValue(pr)}, {"perm_c", toValue(pc)}});
  SP_ADD("sparse_lu", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (s.r != s.c) {
      ctx.fail("the matrix must be square");
      return Value(0.0);
    }
    SparseLU f = sparseLU(s);
    if (f.singular) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    NC_LU_RESULT(f)
  } SP_END
  SP_ADD("sparse_factorize", 1, 1, "A") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (s.r != s.c) {
      ctx.fail("the matrix must be square");
      return Value(0.0);
    }
    SparseLU f = sparseLU(s);
    if (f.singular) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    NC_LU_RESULT(f)
  } SP_END
  SP_ADD("sparse_ilu", 1, 2, "A, drop_tol=1e-4") {
    Sparse s;
    if (!getAny(a, 0, ctx, s))
      return Value(0.0);
    if (s.r != s.c) {
      ctx.fail("the matrix must be square");
      return Value(0.0);
    }
    SparseLU f = sparseLU(s, optNum(a, 1, 1e-4));
    if (f.singular) {
      ctx.fail("the matrix is singular");
      return Value(0.0);
    }
    NC_LU_RESULT(f)
  } SP_END
  SP_ADD("sparse_lu_solve", 2, 2, "f, b") {
    SparseLU f;
    Vec b, pr, pc;
    const Value *L = dictGet(a[0], "L"), *U = dictGet(a[0], "U"), *rp = dictGet(a[0], "perm_r"), *cp = dictGet(a[0], "perm_c");
    if (!L || !U || !rp || !cp || !fromValue(*L, f.L) || !fromValue(*U, f.U) || !readVec(*rp, pr) || !readVec(*cp, pc)) {
      ctx.fail("the first argument must come from sparse_lu(), sparse_ilu() or sparse_factorize()");
      return Value(0.0);
    }
    if (!getVec(a, 1, ctx, b))
      return Value(0.0);
    if (b.size() != pr.size()) {
      ctx.fail("b must have one value per row");
      return Value(0.0);
    }
    f.permR.assign(pr.begin(), pr.end());
    f.permC.assign(pc.begin(), pc.end());
    return toValue(luSolve(f, b));
  } SP_END
  SP_ADD("iter_solve", 2, 6, "A, b, method=\"gmres\", tol=1e-5, maxiter, restart=20") {
    Op op;
    Vec b;
    if (!getOp(a, 0, ctx, op) || !getVec(a, 1, ctx, b))
      return Value(0.0);
    if (op.r != op.c || b.size() != op.r) {
      ctx.fail("A must be square and b must have one value per row");
      return Value(0.0);
    }
    const std::string m = optText(a, 2, "gmres");
    const double tol = optNum(a, 3, 1e-5);
    const long maxit = isNumberArg(a, 4) && a[4].number > 0 ? (long)a[4].number : (long)std::max<size_t>(1000, 10 * b.size());
    const long restart = isNumberArg(a, 5) ? (long)a[5].number : 20;
    IterResult r;
    if (m == "cg") r = cgSolve(op, b, tol, maxit);
    else if (m == "bicg") r = bicgSolve(op, b, tol, maxit);
    else if (m == "bicgstab") r = bicgstabSolve(op, b, tol, maxit);
    else if (m == "cgs") r = cgsSolve(op, b, tol, maxit);
    else if (m == "gmres") r = gmresCore(op, b, tol, maxit, restart, 0);
    else if (m == "lgmres") r = gmresCore(op, b, tol, maxit, 30, 3);
    else if (m == "gcrotmk") r = gmresCore(op, b, tol, maxit, 20, 20);
    else if (m == "minres") r = minresSolve(op, b, tol, maxit);
    else if (m == "qmr") r = qmrSolve(op, b, tol, maxit);
    else if (m == "tfqmr") r = tfqmrSolve(op, b, tol, maxit);
    else {
      ctx.fail("unknown method \"" + m + "\"");
      return Value(0.0);
    }
    if (op.failed) {
      ctx.fail("the operator's function could not be evaluated");
      return Value(0.0);
    }
    return makeDict({{"x", toValue(r.x)}, {"info", Value((double)r.info)}});
  } SP_END
  SP_ADD("sparse_lstsq", 2, 4, "A, b, method=\"lsqr\", tol=1e-8") {
    Op op;
    Vec b;
    if (!getOp(a, 0, ctx, op) || !getVec(a, 1, ctx, b))
      return Value(0.0);
    if (b.size() != op.r) {
      ctx.fail("b must have one value per row of A");
      return Value(0.0);
    }
    const std::string m = optText(a, 2, "lsqr");
    const double tol = optNum(a, 3, 1e-8);
    Vec x;
    long istop = 0, itn = 0;
    double rn = 0.0;
    const long maxit = (long)std::max(op.r, op.c) * 4 + 50;
    if (m == "lsqr") {
      lsqrSolve(op, b, tol, maxit, x, istop, itn, rn);
      return makeDict({{"x", toValue(x)}, {"istop", Value((double)istop)}, {"itn", Value((double)itn)}, {"r1norm", Value(rn)}});
    }
    if (m == "lsmr") {
      lsmrSolve(op, b, tol, maxit, x, istop, itn, rn);
      return makeDict({{"x", toValue(x)}, {"istop", Value((double)istop)}, {"itn", Value((double)itn)}, {"normr", Value(rn)}});
    }
    ctx.fail("method must be \"lsqr\" or \"lsmr\"");
    return Value(0.0);
  } SP_END
  SP_ADD("sparse_eigs", 2, 3, "A, k, which=\"LM\"") {
    Op op;
    long long k;
    if (!getOp(a, 0, ctx, op) || !argNonNegativeInt(a, 1, ctx, k))
      return Value(0.0);
    if (op.r != op.c || k < 1 || (size_t)k >= op.r) {
      ctx.fail("A must be square and k between 1 and n - 1");
      return Value(0.0);
    }
    const std::string which = optText(a, 2, "LM");
    CVec w;
    CMat V;
    la::eigGeneral(toComplex(denseOf(op)), w, &V);
    std::vector<size_t> ord(w.size());
    for (size_t i = 0; i < w.size(); i++)
      ord[i] = i;
    auto key = [&](size_t i) {
      if (which == "LM") return -std::abs(w[i]);
      if (which == "SM") return std::abs(w[i]);
      if (which == "LR") return -w[i].real();
      if (which == "SR") return w[i].real();
      if (which == "LI") return -std::fabs(w[i].imag());
      return std::fabs(w[i].imag());
    };
    std::stable_sort(ord.begin(), ord.end(), [&](size_t x, size_t y) { return key(x) < key(y); });
    CVec wk((size_t)k);
    CMat Vk(op.r, (size_t)k);
    for (size_t c = 0; c < (size_t)k; c++) {
      wk[c] = w[ord[c]];
      for (size_t i = 0; i < op.r; i++)
        Vk(i, c) = V(i, ord[c]);
    }
    return makeDict({{"values", toValue(wk)}, {"vectors", toValue(Vk)}});
  } SP_END
  SP_ADD("sparse_eigsh", 2, 3, "A, k, which=\"LM\"") {
    Op op;
    long long k;
    if (!getOp(a, 0, ctx, op) || !argNonNegativeInt(a, 1, ctx, k))
      return Value(0.0);
    if (op.r != op.c || k < 1 || (size_t)k >= op.r) {
      ctx.fail("A must be square and k between 1 and n - 1");
      return Value(0.0);
    }
    Vec w;
    Mat Z;
    symEigs(op, (size_t)k, optText(a, 2, "LM"), w, Z);
    return makeDict({{"values", toValue(w)}, {"vectors", toValue(Z)}});
  } SP_END
  SP_ADD("lobpcg", 2, 4, "A, X, largest=1, tol=1e-8") {
    // Locally optimal block preconditioned CG: Rayleigh-Ritz over [X, R, P].
    Op op;
    Mat X;
    if (!getOp(a, 0, ctx, op) || !getMat(a, 1, ctx, X))
      return Value(0.0);
    if (op.r != op.c || X.r != op.r || X.c < 1 || X.c > X.r) {
      ctx.fail("A must be square and X must have one row per row of A, with at most that many columns");
      return Value(0.0);
    }
    const bool largest = optBool(a, 2, true);
    const double tol = optNum(a, 3, 1e-8);
    const size_t n = X.r, k = X.c;
    auto orth = [&](std::vector<Vec> &B) {
      std::vector<Vec> O;
      for (Vec v : B) {
        for (int pass = 0; pass < 2; pass++)
          for (const Vec &o : O)
            axpy(-dot(v, o), o, v);
        const double nv = norm2(v);
        if (nv > 1e-10) {
          for (double &q : v)
            q /= nv;
          O.push_back(v);
        }
      }
      B = O;
    };
    std::vector<Vec> cur, prev;
    for (size_t j = 0; j < k; j++) {
      Vec c(n);
      for (size_t i = 0; i < n; i++)
        c[i] = X(i, j);
      cur.push_back(c);
    }
    orth(cur);
    Vec values(k, 0.0);
    for (int it = 0; it < 500; it++) {
      std::vector<Vec> basis = cur;
      // Residuals with the current Ritz values.
      Vec rv(cur.size());
      std::vector<Vec> res;
      double worst = 0.0;
      for (size_t j = 0; j < cur.size(); j++) {
        Vec Ax = op.mul(cur[j]);
        const double th = dot(cur[j], Ax);
        axpy(-th, cur[j], Ax);
        worst = std::max(worst, norm2(Ax));
        res.push_back(Ax);
        values[j] = th;
      }
      if (it > 0 && worst <= tol * std::max(1.0, std::fabs(values[0])))
        break;
      basis.insert(basis.end(), res.begin(), res.end());
      basis.insert(basis.end(), prev.begin(), prev.end());
      orth(basis);
      const size_t m = basis.size();
      Mat T(m, m);
      std::vector<Vec> AB;
      for (const Vec &v : basis)
        AB.push_back(op.mul(v));
      for (size_t i = 0; i < m; i++)
        for (size_t j = 0; j <= i; j++)
          T(i, j) = T(j, i) = dot(basis[i], AB[j]);
      Vec w;
      Mat S;
      la::eigHermitian(T, w, S);
      std::vector<Vec> nxt;
      for (size_t j = 0; j < k && j < m; j++) {
        const size_t col = largest ? m - 1 - j : j;
        Vec v(n, 0.0);
        for (size_t q = 0; q < m; q++)
          axpy(S(q, col), basis[q], v);
        nxt.push_back(v);
      }
      prev = cur;
      cur = nxt;
      orth(cur);
    }
    Mat Z(n, cur.size());
    Vec vals(cur.size());
    for (size_t j = 0; j < cur.size(); j++) {
      Vec Ax = op.mul(cur[j]);
      vals[j] = dot(cur[j], Ax);
      for (size_t i = 0; i < n; i++)
        Z(i, j) = cur[j][i];
    }
    return makeDict({{"values", toValue(vals)}, {"vectors", toValue(Z)}});
  } SP_END
  SP_ADD("sparse_svds", 2, 2, "A, k") {
    Op op;
    long long k;
    if (!getOp(a, 0, ctx, op) || !argNonNegativeInt(a, 1, ctx, k))
      return Value(0.0);
    if (k < 1 || (size_t)k > std::min(op.r, op.c)) {
      ctx.fail("k must lie between 1 and the smaller matrix size");
      return Value(0.0);
    }
    Mat U0, V0;
    Vec s0;
    la::svdThin(denseOf(op), U0, s0, V0);
    const size_t K = (size_t)k;
    Mat U(op.r, K), Vt(K, op.c);
    Vec s(K);
    for (size_t c = 0; c < K; c++) {
      s[c] = s0[K - 1 - c];
      for (size_t i = 0; i < op.r; i++)
        U(i, c) = U0(i, K - 1 - c);
      for (size_t j = 0; j < op.c; j++)
        Vt(c, j) = V0(j, K - 1 - c);
    }
    return makeDict({{"U", toValue(U)}, {"s", toValue(s)}, {"Vt", toValue(Vt)}});
  } SP_END
  reg.setParallel({"iter_solve", "sparse_lstsq", "sparse_mul", "lobpcg", "sparse_eigsh"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
