// Bessel functions of real order: Temme's series for small arguments,
// Steed's continued fractions (Thompson & Barnett) for large ones, and the
// Hankel expansions far out. The I/K engine also runs on complex arguments,
// which gives complex J, Y, Hankel and the Kelvin functions.
#include "sf_core.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {
const double EPS = 1e-16;
const double FPMIN = 1e-300;
const int MAXIT = 200000;
const double BIG = 1e250;

double sinpi(double x) {
  double r = std::fmod(x, 2.0);
  if (r == std::floor(r))
    return 0.0;
  return std::sin(PI * r);
}
double cospi(double x) {
  double r = std::fmod(std::fabs(x), 2.0);
  if (r == 0.5 || r == 1.5)
    return 0.0;
  return std::cos(PI * r);
}

// 1/Gamma(1+x), 1/Gamma(1-x) and Temme's gam1, gam2 for |x| <= 1/2, from
// ln Gamma(1+x) = -gamma x + sum_k (-1)^k zeta(k) x^k / k.
void beschb(double x, double &gam1, double &gam2, double &gampl, double &gammi) {
  // Filled once, thread-safely (a function-local static's initialiser runs
  // exactly once even when several nc::par threads arrive together; the old
  // "static bool init" flag was a data race under threads).
  struct ZetaTable {
    double v[64] = {};
    ZetaTable() {
      for (int k = 2; k < 64; k++)
        v[k] = riemann_zeta(k);
    }
  };
  static const ZetaTable zeta;
  const double *Z = zeta.v;
  double le = 0.0, lo = -EULER * x, p = x;
  for (int k = 2; k < 64; k++) {
    p *= x;
    double t = Z[k] * p / k;
    if (k % 2 == 0)
      le += t;
    else
      lo -= t;
    if (std::fabs(t) < 1e-18)
      break;
  }
  double ee = std::exp(-le);
  gam1 = (x == 0.0) ? -EULER : ee * std::sinh(lo) / x;
  gam2 = ee * std::cosh(lo);
  gampl = std::exp(-le - lo);
  gammi = std::exp(-le + lo);
}

// Hankel asymptotic P, Q for large x.
void hankelPQ(double nu, double x, double &P, double &Q) {
  double mu = 4 * nu * nu;
  P = 1.0;
  Q = 0.0;
  double term = 1.0, last = Inf;
  for (int k = 1; k < 200; k++) {
    term *= (mu - (2.0 * k - 1) * (2.0 * k - 1)) / (k * 8.0 * x);
    if (std::fabs(term) > last && k > 2)
      break;
    last = std::fabs(term);
    double sgn = ((k / 2) % 2 == 0) ? 1.0 : -1.0;
    if (k % 2 == 0)
      P += sgn * term;
    else
      Q += sgn * term;
    if (std::fabs(term) < 1e-17)
      break;
  }
}

// J_nu, Y_nu and derivatives for nu >= 0, x > 0 (NR bessjy, with rescaling).
void bessjy(double x, double xnu, double &rj, double &ry, double &rjp, double &ryp) {
  if (x > 25.0 + xnu * xnu / 2.0) {
    double P, Q, P1, Q1;
    hankelPQ(xnu, x, P, Q);
    hankelPQ(xnu + 1, x, P1, Q1);
    double chi = x - (xnu / 2.0 + 0.25) * PI;
    double chi1 = x - ((xnu + 1) / 2.0 + 0.25) * PI;
    double s = std::sqrt(2.0 / (PI * x));
    rj = s * (P * std::cos(chi) - Q * std::sin(chi));
    ry = s * (P * std::sin(chi) + Q * std::cos(chi));
    double rj1 = s * (P1 * std::cos(chi1) - Q1 * std::sin(chi1));
    double ry1 = s * (P1 * std::sin(chi1) + Q1 * std::cos(chi1));
    rjp = xnu / x * rj - rj1;
    ryp = xnu / x * ry - ry1;
    return;
  }
  int nl = (x < 2.0) ? static_cast<int>(xnu + 0.5) : std::max(0, static_cast<int>(xnu - x + 1.5));
  double xmu = xnu - nl, xmu2 = xmu * xmu;
  double xi = 1.0 / x, xi2 = 2.0 * xi, w = xi2 / PI;
  int isign = 1;
  double h = xnu * xi;
  if (h < FPMIN)
    h = FPMIN;
  double b = xi2 * xnu, d = 0.0, c = h;
  for (int i = 1; i <= MAXIT; i++) {
    b += xi2;
    d = b - d;
    if (std::fabs(d) < FPMIN)
      d = FPMIN;
    c = b - 1.0 / c;
    if (std::fabs(c) < FPMIN)
      c = FPMIN;
    d = 1.0 / d;
    double del = c * d;
    h = del * h;
    if (d < 0.0)
      isign = -isign;
    if (std::fabs(del - 1.0) < EPS)
      break;
  }
  double rjl = isign * 1e-30, rjpl = h * rjl, rjl1 = rjl, rjp1 = rjpl;
  double fact = xnu * xi;
  for (int l = nl; l >= 1; l--) {
    double rjtemp = fact * rjl + rjpl;
    fact -= xi;
    rjpl = fact * rjtemp - rjl;
    rjl = rjtemp;
    if (std::fabs(rjl) > BIG) {
      rjl /= BIG;
      rjpl /= BIG;
      rjl1 /= BIG;
      rjp1 /= BIG;
    }
  }
  if (rjl == 0.0)
    rjl = EPS;
  double f = rjpl / rjl;
  double rjmu, rymu, rymup, ry1;
  if (x < 2.0) {
    double x2 = 0.5 * x, pimu = PI * xmu;
    double fct = (std::fabs(pimu) < EPS ? 1.0 : pimu / std::sin(pimu));
    d = -std::log(x2);
    double e = xmu * d;
    double fact2 = (std::fabs(e) < EPS ? 1.0 : std::sinh(e) / e);
    double gam1, gam2, gampl, gammi;
    beschb(xmu, gam1, gam2, gampl, gammi);
    double ff = 2.0 / PI * fct * (gam1 * std::cosh(e) + gam2 * fact2 * d);
    e = std::exp(e);
    double p = e / (gampl * PI), q = 1.0 / (e * PI * gammi);
    double pimu2 = 0.5 * pimu;
    double fact3 = (std::fabs(pimu2) < EPS ? 1.0 : std::sin(pimu2) / pimu2);
    double r = PI * pimu2 * fact3 * fact3;
    c = 1.0;
    d = -x2 * x2;
    double sum = ff + r * q, sum1 = p;
    for (int i = 1; i <= MAXIT; i++) {
      ff = (i * ff + p + q) / (i * i - xmu2);
      c *= (d / i);
      p /= (i - xmu);
      q /= (i + xmu);
      double del = c * (ff + r * q);
      sum += del;
      double del1 = c * p - i * del;
      sum1 += del1;
      if (std::fabs(del) < (1.0 + std::fabs(sum)) * EPS)
        break;
    }
    rymu = -sum;
    ry1 = -sum1 * xi2;
    rymup = xmu * xi * rymu - ry1;
    rjmu = w / (rymup - f * rymu);
  } else {
    double a = 0.25 - xmu2, p = -0.5 * xi, q = 1.0;
    double br = 2.0 * x, bi = 2.0;
    double fct = a * xi / (p * p + q * q);
    double cr = br + q * fct, ci = bi + p * fct;
    double den = br * br + bi * bi;
    double dr = br / den, di = -bi / den;
    double dlr = cr * dr - ci * di, dli = cr * di + ci * dr;
    double temp = p * dlr - q * dli;
    q = p * dli + q * dlr;
    p = temp;
    for (int i = 2; i <= MAXIT; i++) {
      a += 2 * (i - 1);
      bi += 2.0;
      dr = a * dr + br;
      di = a * di + bi;
      if (std::fabs(dr) + std::fabs(di) < FPMIN)
        dr = FPMIN;
      fct = a / (cr * cr + ci * ci);
      cr = br + cr * fct;
      ci = bi - ci * fct;
      if (std::fabs(cr) + std::fabs(ci) < FPMIN)
        cr = FPMIN;
      den = dr * dr + di * di;
      dr /= den;
      di /= -den;
      dlr = cr * dr - ci * di;
      dli = cr * di + ci * dr;
      temp = p * dlr - q * dli;
      q = p * dli + q * dlr;
      p = temp;
      if (std::fabs(dlr - 1.0) + std::fabs(dli) < EPS)
        break;
    }
    double gam = (p - f) / q;
    rjmu = std::sqrt(w / ((p - f) * gam + q));
    rjmu = (rjl >= 0) ? std::fabs(rjmu) : -std::fabs(rjmu);
    rymu = rjmu * gam;
    rymup = rymu * (p + q / gam);
    ry1 = xmu * xi * rymu - rymup;
  }
  double fct = rjmu / rjl;
  rj = rjl1 * fct;
  rjp = rjp1 * fct;
  for (int i = 1; i <= nl; i++) {
    double rytemp = (xmu + i) * xi2 * ry1 - rymu;
    rymu = ry1;
    ry1 = rytemp;
    if (std::isinf(ry1))
      break;
  }
  ry = rymu;
  ryp = xnu * xi * rymu - ry1;
}

// I_nu, K_nu (and derivatives) for nu >= 0 and Re z >= 0, z != 0. With
// `scaled`, I comes out times exp(-z) and K times exp(z). Works for real T
// (double) and complex T.
template <class T>
void bessikT(T x, double xnu, bool scaled, T &ri, T &rk, T &rip, T &rkp) {
  int nl = static_cast<int>(xnu + 0.5);
  double xmu = xnu - nl, xmu2 = xmu * xmu;
  T xi = 1.0 / x, xi2 = 2.0 * xi;
  T h = xnu * xi;
  if (std::abs(h) < FPMIN)
    h = FPMIN;
  T b = xi2 * xnu, d = 0.0, c = h;
  for (int i = 1; i <= MAXIT; i++) {
    b += xi2;
    d = 1.0 / (b + d);
    c = b + 1.0 / c;
    T del = c * d;
    h = del * h;
    if (std::abs(del - 1.0) < EPS)
      break;
  }
  T ril = 1e-30, ripl = h * ril, ril1 = ril, rip1 = ripl;
  T fact = xnu * xi;
  for (int l = nl; l >= 1; l--) {
    T ritemp = fact * ril + ripl;
    fact -= xi;
    ripl = fact * ritemp + ril;
    ril = ritemp;
    if (std::abs(ril) > BIG) {
      ril /= BIG;
      ripl /= BIG;
      ril1 /= BIG;
      rip1 /= BIG;
    }
  }
  T f = ripl / ril;
  T rkmu, rk1;
  bool kScaled;
  if (std::abs(x) < 2.0) {
    T x2 = 0.5 * x;
    double pimu = PI * xmu;
    double fct = (std::fabs(pimu) < EPS ? 1.0 : pimu / std::sin(pimu));
    d = -std::log(x2);
    T e = xmu * d;
    T fact2 = (std::abs(e) < EPS ? T(1.0) : std::sinh(e) / e);
    double gam1, gam2, gampl, gammi;
    beschb(xmu, gam1, gam2, gampl, gammi);
    T ff = fct * (gam1 * std::cosh(e) + gam2 * fact2 * d);
    T sum = ff;
    e = std::exp(e);
    T p = 0.5 * e / gampl, q = 0.5 / (e * gammi);
    c = 1.0;
    d = x2 * x2;
    T sum1 = p;
    for (int i = 1; i <= MAXIT; i++) {
      ff = (double(i) * ff + p + q) / (double(i) * i - xmu2);
      c *= (d / double(i));
      p /= (i - xmu);
      q /= (i + xmu);
      T del = c * ff;
      sum += del;
      T del1 = c * (p - double(i) * ff);
      sum1 += del1;
      if (std::abs(del) < std::abs(sum) * EPS)
        break;
    }
    rkmu = sum;
    rk1 = sum1 * xi2;
    kScaled = false;
  } else {
    b = 2.0 * (1.0 + x);
    d = 1.0 / b;
    T delh = d;
    h = d;
    T q1 = 0.0, q2 = 1.0;
    double a1 = 0.25 - xmu2;
    T q = a1;
    c = a1;
    double a = -a1;
    T s = 1.0 + q * delh;
    for (int i = 2; i <= MAXIT; i++) {
      a -= 2 * (i - 1);
      c = -a * c / double(i);
      T qnew = (q1 - b * q2) / a;
      q1 = q2;
      q2 = qnew;
      q += c * qnew;
      b += 2.0;
      d = 1.0 / (b + a * d);
      delh = (b * d - 1.0) * delh;
      h += delh;
      T dels = q * delh;
      s += dels;
      if (std::abs(dels / s) < EPS)
        break;
    }
    h = a1 * h;
    rkmu = std::sqrt(PI / (2.0 * x)) / s; // times exp(-x) for the true value
    rk1 = rkmu * (xmu + x + 0.5 - h) * xi;
    kScaled = true;
  }
  if (scaled && !kScaled) {
    T ex = std::exp(x);
    rkmu *= ex;
    rk1 *= ex;
  } else if (!scaled && kScaled) {
    T ex = std::exp(-x);
    rkmu *= ex;
    rk1 *= ex;
  }
  // Wronskian: I K' - I' K = -1/x holds for the scaled pair as well (with
  // I scaled by exp(-x) and K by exp(x)) since the factors cancel.
  T rkmup = xmu * xi * rkmu - rk1;
  T rimu = xi / (f * rkmu - rkmup);
  ri = (rimu * ril1) / ril;
  rip = (rimu * rip1) / ril;
  for (int i = 1; i <= nl; i++) {
    T rktemp = (xmu + i) * xi2 * rk1 + rkmu;
    rkmu = rk1;
    rk1 = rktemp;
  }
  rk = rkmu;
  rkp = xnu * xi * rkmu - rk1;
}

// Large-x expansion of exp(-x) I_nu(x).
double iScaledAsym(double nu, double x) {
  double mu = 4 * nu * nu, term = 1.0, sum = 1.0, last = Inf;
  for (int k = 1; k < 200; k++) {
    term *= -(mu - (2.0 * k - 1) * (2.0 * k - 1)) / (k * 8.0 * x);
    if (std::fabs(term) > last)
      break;
    last = std::fabs(term);
    sum += term;
    if (std::fabs(term) < 1e-17 * std::fabs(sum))
      break;
  }
  return sum / std::sqrt(2 * PI * x);
}

void bessikReal(double x, double nu, bool scaled, double &i, double &k) {
  double ip, kp;
  bessikT<double>(x, nu, scaled, i, k, ip, kp);
}
} // namespace

// ---- real order, real argument ----

double besselj(double v, double x) {
  if (std::isnan(v) || std::isnan(x))
    return NaN;
  if (x < 0) {
    if (v != std::floor(v))
      return NaN;
    double r = besselj(v, -x);
    return std::fmod(std::fabs(v), 2.0) == 1.0 ? -r : r;
  }
  if (x == 0) {
    if (v == 0)
      return 1.0;
    if (v > 0 || v == std::floor(v))
      return 0.0;
    return Inf;
  }
  if (std::isinf(x))
    return 0.0;
  if (v < 0) {
    if (v == std::floor(v))
      return (std::fmod(-v, 2.0) == 1.0 ? -1.0 : 1.0) * besselj(-v, x);
    double j, y, jp, yp;
    bessjy(x, -v, j, y, jp, yp);
    return cospi(-v) * j - sinpi(-v) * y;
  }
  double j, y, jp, yp;
  bessjy(x, v, j, y, jp, yp);
  return j;
}

double bessely(double v, double x) {
  if (std::isnan(v) || std::isnan(x) || x < 0)
    return NaN;
  if (x == 0)
    return -Inf;
  if (std::isinf(x))
    return 0.0;
  if (v < 0) {
    if (v == std::floor(v))
      return (std::fmod(-v, 2.0) == 1.0 ? -1.0 : 1.0) * bessely(-v, x);
    double j, y, jp, yp;
    bessjy(x, -v, j, y, jp, yp);
    return sinpi(-v) * j + cospi(-v) * y;
  }
  double j, y, jp, yp;
  bessjy(x, v, j, y, jp, yp);
  return y;
}

double besseli(double v, double x, bool scaled) {
  if (std::isnan(v) || std::isnan(x))
    return NaN;
  if (x < 0) {
    if (v != std::floor(v))
      return NaN;
    double r = besseli(v, -x, scaled);
    return std::fmod(std::fabs(v), 2.0) == 1.0 ? -r : r;
  }
  if (x == 0) {
    if (v == 0)
      return 1.0;
    if (v > 0 || v == std::floor(v))
      return 0.0;
    return Inf;
  }
  if (std::isinf(x))
    return scaled ? 0.0 : Inf;
  double av = std::fabs(v);
  double i, k;
  if (x > 30 && x > av * av) {
    i = iScaledAsym(av, x);
    if (!scaled)
      i *= std::exp(x);
    if (v < 0 && v != std::floor(v)) {
      double kk = besselk(av, x, true); // K e^x
      double kterm = 2.0 / PI * sinpi(av) * kk;
      i += scaled ? kterm * std::exp(-2 * x) : kterm * std::exp(-x);
    }
    return i;
  }
  bessikReal(x, av, scaled, i, k);
  if (v < 0 && v != std::floor(v)) {
    double kterm = 2.0 / PI * sinpi(av) * k;
    if (scaled)
      kterm *= std::exp(-2 * x);
    i += kterm;
  }
  return i;
}

double besselk(double v, double x, bool scaled) {
  if (std::isnan(v) || std::isnan(x) || x < 0)
    return NaN;
  if (x == 0)
    return Inf;
  if (std::isinf(x))
    return 0.0;
  double i, k;
  if (!scaled && x > 705)
    return 0.0;
  bessikReal(x, std::fabs(v), scaled, i, k);
  return k;
}

// ---- complex argument ----

namespace {
const cd CI(0.0, 1.0);

void bessikC(double v, cd z, bool scaled, cd &i, cd &k) {
  cd ip, kp;
  bessikT<cd>(z, v, scaled, i, k, ip, kp);
}

// I and K for v >= 0 anywhere in the plane (unscaled).
void ikAnywhere(double v, cd z, cd &i, cd &k) {
  if (z.real() >= 0) {
    bessikC(v, z, false, i, k);
    return;
  }
  cd w = -z, iw, kw;
  bessikC(v, w, false, iw, kw);
  double s = (z.imag() >= 0) ? 1.0 : -1.0;
  cd ph = std::exp(s * CI * (v * PI));
  i = ph * iw;
  k = std::conj(ph) * kw - s * CI * PI * iw;
}

// I_v, K_v with v of any sign, via reflection.
void ikOrder(double v, cd z, cd &i, cd &k) {
  double av = std::fabs(v);
  ikAnywhere(av, z, i, k);
  if (v < 0 && v != std::floor(v))
    i += 2.0 / PI * sinpi(av) * k;
}
} // namespace

cd besseli(double v, cd z, bool scaled) {
  if (z.imag() == 0.0 && (z.real() >= 0 || v == std::floor(v)))
    return cd(besseli(v, z.real(), scaled), 0.0);
  if (z == cd(0, 0))
    return cd(besseli(v, 0.0), 0.0);
  cd i, k;
  ikOrder(v, z, i, k);
  if (scaled)
    i *= std::exp(-std::fabs(z.real()));
  return i;
}

cd besselk(double v, cd z, bool scaled) {
  if (z.imag() == 0.0 && z.real() >= 0)
    return cd(besselk(v, z.real(), scaled), 0.0);
  if (z == cd(0, 0))
    return cd(Inf, 0.0);
  cd i, k;
  ikOrder(v, z, i, k);
  if (scaled)
    k *= std::exp(z);
  return k;
}

namespace {
// J, H1, H2 for any real order and complex z.
void jhh(double v, cd z, cd &j, cd &h1, cd &h2) {
  double av = std::fabs(v);
  cd i, k;
  if (z.imag() >= 0) {
    ikAnywhere(av, -CI * z, i, k);
    j = std::exp(CI * (av * PI / 2)) * i;
    h1 = 2.0 / (PI * CI) * std::exp(-CI * (av * PI / 2)) * k;
    h2 = 2.0 * j - h1;
  } else {
    ikAnywhere(av, CI * z, i, k);
    j = std::exp(-CI * (av * PI / 2)) * i;
    h2 = -2.0 / (PI * CI) * std::exp(CI * (av * PI / 2)) * k;
    h1 = 2.0 * j - h2;
  }
  if (v < 0) {
    // H1_{-v} = e^{i v pi} H1_v, H2_{-v} = e^{-i v pi} H2_v.
    cd e = std::exp(CI * (av * PI));
    h1 *= e;
    h2 *= std::conj(e);
    j = 0.5 * (h1 + h2);
  }
}
} // namespace

cd besselj(double v, cd z, bool scaled) {
  if (z.imag() == 0.0 && (z.real() >= 0 || v == std::floor(v))) {
    double r = besselj(v, z.real());
    return cd(r, 0.0);
  }
  if (z == cd(0, 0))
    return cd(besselj(v, 0.0), 0.0);
  cd j, h1, h2;
  jhh(v, z, j, h1, h2);
  if (scaled)
    j *= std::exp(-std::fabs(z.imag()));
  return j;
}

cd bessely(double v, cd z, bool scaled) {
  if (z.imag() == 0.0 && z.real() >= 0)
    return cd(bessely(v, z.real()), 0.0);
  if (z == cd(0, 0))
    return cd(-Inf, 0.0);
  cd j, h1, h2;
  jhh(v, z, j, h1, h2);
  cd y = (h1 - h2) / (2.0 * CI);
  if (scaled)
    y *= std::exp(-std::fabs(z.imag()));
  return y;
}

cd hankel1(double v, cd z, bool scaled) {
  if (z == cd(0, 0))
    return cd(NaN, NaN);
  cd h1;
  if (z.imag() == 0.0 && z.real() > 0)
    h1 = cd(besselj(v, z.real()), bessely(v, z.real()));
  else {
    cd j, h2;
    jhh(v, z, j, h1, h2);
  }
  if (scaled)
    h1 *= std::exp(-CI * z);
  return h1;
}

cd hankel2(double v, cd z, bool scaled) {
  if (z == cd(0, 0))
    return cd(NaN, NaN);
  cd h2;
  if (z.imag() == 0.0 && z.real() > 0)
    h2 = cd(besselj(v, z.real()), -bessely(v, z.real()));
  else {
    cd j, h1;
    jhh(v, z, j, h1, h2);
  }
  if (scaled)
    h2 *= std::exp(CI * z);
  return h2;
}

double bessel_deriv(char kind, double v, double x, int n) {
  if (n < 0)
    return NaN;
  double sum = 0.0, binom = 1.0;
  double phase = (kind == 'i' || kind == 'k') ? 1.0 : -1.0;
  for (int k = 0; k <= n; k++) {
    double order = v - n + 2.0 * k, f;
    switch (kind) {
    case 'j':
      f = besselj(order, x);
      break;
    case 'y':
      f = bessely(order, x);
      break;
    case 'i':
      f = besseli(order, x);
      break;
    default:
      f = besselk(order, x);
      break;
    }
    sum += binom * std::pow(phase, k) * f;
    binom = binom * (n - k) / (k + 1.0);
  }
  double r = std::ldexp(sum, -n);
  if (kind == 'k' && (n % 2))
    r = -r;
  return r;
}

cd hankel_deriv(int kind, double v, double x, int n) {
  cd sum = 0.0;
  double binom = 1.0;
  for (int k = 0; k <= n; k++) {
    double order = v - n + 2.0 * k;
    cd f = kind == 1 ? hankel1(order, cd(x, 0)) : hankel2(order, cd(x, 0));
    sum += binom * ((k % 2) ? -1.0 : 1.0) * f;
    binom = binom * (n - k) / (k + 1.0);
  }
  return sum * std::ldexp(1.0, -n);
}

// ---- Airy ----

void airy(double x, double &ai, double &aip, double &bi, double &bip) {
  const double ONOVRT = 0.57735026918962576451;
  if (std::isnan(x)) {
    ai = aip = bi = bip = NaN;
    return;
  }
  double ax = std::fabs(x), rootx = std::sqrt(ax), z = 2.0 / 3.0 * ax * rootx;
  if (x > 0.0) {
    if (z > 700) {
      ai = aip = 0.0;
      bi = bip = Inf;
      return;
    }
    double ri, rk;
    bessikReal(z, 1.0 / 3.0, false, ri, rk);
    ai = rootx * ONOVRT * rk / PI;
    bi = rootx * (rk / PI + 2.0 * ONOVRT * ri);
    bessikReal(z, 2.0 / 3.0, false, ri, rk);
    aip = -x * ONOVRT * rk / PI;
    bip = x * (rk / PI + 2.0 * ONOVRT * ri);
  } else if (x < 0.0) {
    double rj, ry, rjp, ryp;
    bessjy(z, 1.0 / 3.0, rj, ry, rjp, ryp);
    ai = 0.5 * rootx * (rj - ONOVRT * ry);
    bi = -0.5 * rootx * (ry + ONOVRT * rj);
    bessjy(z, 2.0 / 3.0, rj, ry, rjp, ryp);
    aip = 0.5 * ax * (ONOVRT * ry + rj);
    bip = 0.5 * ax * (ONOVRT * rj - ry);
  } else {
    ai = 0.355028053887817239;
    aip = -0.258819403792806798;
    bi = ai / ONOVRT;
    bip = -aip / ONOVRT;
  }
}

void airye(double x, double &ai, double &aip, double &bi, double &bip) {
  const double ONOVRT = 0.57735026918962576451;
  if (x <= 0.0 || std::isnan(x)) {
    airy(x, ai, aip, bi, bip);
    return;
  }
  double rootx = std::sqrt(x), z = 2.0 / 3.0 * x * rootx;
  double ri, rk, ri2, rk2;
  bessikReal(z, 1.0 / 3.0, true, ri, rk); // ri = I e^-z, rk = K e^z
  bessikReal(z, 2.0 / 3.0, true, ri2, rk2);
  ai = rootx * ONOVRT * rk / PI;
  aip = -x * ONOVRT * rk2 / PI;
  double e2 = std::exp(-2 * z);
  bi = rootx * (rk * e2 / PI + 2.0 * ONOVRT * ri);
  bip = x * (rk2 * e2 / PI + 2.0 * ONOVRT * ri2);
}

// ---- Struve ----

namespace {
double struveSeries(double v, double x, bool modified) {
  double sum = 0.0, half = x / 2.0;
  double lp = (v + 1) * std::log(half);
  for (int k = 0; k < 500; k++) {
    double g1 = k + 1.5, g2 = k + v + 1.5;
    if (g2 <= 0 && g2 == std::floor(g2))
      continue;
    double lt = lp + 2.0 * k * std::log(half) - std::lgamma(g1) - std::lgamma(g2);
    double t = std::exp(lt) * gammasgn(g2);
    if (!modified && (k % 2))
      t = -t;
    sum += t;
    if (k > 5 && std::fabs(t) < 1e-17 * std::fabs(sum))
      break;
  }
  return sum;
}
// H_v - Y_v for large x.
double struveAsym(double v, double x, bool &ok) {
  double sum = 0.0, last = Inf;
  ok = false;
  for (int k = 0; k < 100; k++) {
    double g = v + 0.5 - k;
    if (g <= 0 && g == std::floor(g)) {
      ok = true;
      break;
    }
    double t = std::exp(std::lgamma(k + 0.5) + (v - 2.0 * k - 1) * std::log(x / 2.0) - std::lgamma(g)) * gammasgn(g);
    if (std::fabs(t) > last) {
      ok = last < 1e-15 * std::fabs(sum);
      break;
    }
    last = std::fabs(t);
    sum += t;
    if (std::fabs(t) < 1e-17 * std::fabs(sum)) {
      ok = true;
      break;
    }
  }
  return sum / PI;
}
} // namespace

double struve_h(double v, double x) {
  if (std::isnan(v) || std::isnan(x))
    return NaN;
  if (x < 0) {
    if (v != std::floor(v))
      return NaN;
    double r = struve_h(v, -x);
    return std::fmod(std::fabs(v), 2.0) == 0.0 ? -r : r;
  }
  if (x == 0)
    return (v > -1) ? 0.0 : (v == -1 ? 2.0 / PI : Inf);
  if (x > 20 + std::fabs(v)) {
    bool ok;
    double a = struveAsym(v, x, ok);
    if (ok)
      return bessely(v, x) + a;
  }
  if (x < 8 || v <= -0.5)
    return struveSeries(v, x, false);
  auto f = [&](double th) { return std::sin(x * std::sin(th)) * std::pow(std::cos(th), 2 * v); };
  double I = quad(f, 0.0, PI / 2, 0.0, 1e-14, 2000);
  return 2.0 * std::pow(x / 2.0, v) / (SQRTPI * std::tgamma(v + 0.5)) * I;
}

double struve_l(double v, double x) {
  if (std::isnan(v) || std::isnan(x))
    return NaN;
  if (x < 0) {
    if (v != std::floor(v))
      return NaN;
    double r = struve_l(v, -x);
    return std::fmod(std::fabs(v), 2.0) == 0.0 ? -r : r;
  }
  if (x == 0)
    return (v > -1) ? 0.0 : (v == -1 ? 2.0 / PI : Inf);
  if (x > 40 && x > v * v) {
    // L_v = I_{-v} - (1/pi) sum (-1)^(k+1) Gamma(k+1/2) (x/2)^(v-2k-1) / Gamma(v+1/2-k)
    double sum = 0.0, last = Inf;
    for (int k = 0; k < 60; k++) {
      double g = v + 0.5 - k;
      if (g <= 0 && g == std::floor(g))
        break;
      double t = std::exp(std::lgamma(k + 0.5) + (v - 2.0 * k - 1) * std::log(x / 2.0) - std::lgamma(g)) * gammasgn(g);
      if (std::fabs(t) > last)
        break;
      last = std::fabs(t);
      sum += ((k + 1) % 2 ? -1.0 : 1.0) * t;
    }
    return besseli(-v, x) - sum / PI;
  }
  return struveSeries(v, x, true);
}

// ---- Kelvin ----

cd kelvin_be(double x) {
  if (std::isnan(x))
    return cd(NaN, NaN);
  double ax = std::fabs(x);
  if (ax == 0)
    return cd(1.0, 0.0);
  cd i, k;
  ikAnywhere(0.0, ax * std::exp(CI * (PI / 4)), i, k);
  return i;
}

cd kelvin_ke(double x) {
  if (std::isnan(x) || x < 0)
    return cd(NaN, NaN);
  if (x == 0)
    return cd(Inf, -PI / 4);
  cd i, k;
  ikAnywhere(0.0, x * std::exp(CI * (PI / 4)), i, k);
  return k;
}

cd kelvin_bep(double x) {
  if (std::isnan(x))
    return cd(NaN, NaN);
  if (x == 0)
    return cd(0.0, 0.0);
  double ax = std::fabs(x);
  cd e = std::exp(CI * (PI / 4)), i, k;
  ikAnywhere(1.0, ax * e, i, k);
  cd r = e * i;
  return x < 0 ? -r : r;
}

cd kelvin_kep(double x) {
  if (std::isnan(x) || x < 0)
    return cd(NaN, NaN);
  if (x == 0)
    return cd(-Inf, 0.0);
  cd e = std::exp(CI * (PI / 4)), i, k;
  ikAnywhere(1.0, x * e, i, k);
  return -e * k;
}

// ---- spherical Bessel ----

double sph_jn(int n, double x, bool deriv) {
  if (n < 0 || std::isnan(x))
    return NaN;
  if (deriv) {
    if (n == 0)
      return -sph_jn(1, x, false);
    if (x == 0)
      return n == 1 ? 1.0 / 3.0 : 0.0;
    return sph_jn(n - 1, x, false) - (n + 1) / x * sph_jn(n, x, false);
  }
  if (x == 0)
    return n == 0 ? 1.0 : 0.0;
  if (std::isinf(x))
    return 0.0;
  if (x < 0)
    return (n % 2 ? -1.0 : 1.0) * sph_jn(n, -x, false);
  if (n == 0)
    return std::sin(x) / x;
  return std::sqrt(PI / (2 * x)) * besselj(n + 0.5, x);
}

double sph_yn(int n, double x, bool deriv) {
  if (n < 0 || std::isnan(x))
    return NaN;
  if (deriv) {
    if (n == 0)
      return -sph_yn(1, x, false);
    return sph_yn(n - 1, x, false) - (n + 1) / x * sph_yn(n, x, false);
  }
  if (x == 0)
    return -Inf;
  if (std::isinf(x))
    return 0.0;
  if (x < 0)
    return (n % 2 ? 1.0 : -1.0) * sph_yn(n, -x, false);
  if (n == 0)
    return -std::cos(x) / x;
  return std::sqrt(PI / (2 * x)) * bessely(n + 0.5, x);
}

double sph_in(int n, double x, bool deriv) {
  if (n < 0 || std::isnan(x))
    return NaN;
  if (deriv) {
    if (n == 0)
      return sph_in(1, x, false);
    if (x == 0)
      return n == 1 ? 1.0 / 3.0 : 0.0;
    return sph_in(n - 1, x, false) - (n + 1) / x * sph_in(n, x, false);
  }
  if (x == 0)
    return n == 0 ? 1.0 : 0.0;
  if (x < 0)
    return (n % 2 ? -1.0 : 1.0) * sph_in(n, -x, false);
  if (std::isinf(x))
    return Inf;
  return std::sqrt(PI / (2 * x)) * besseli(n + 0.5, x);
}

double sph_kn(int n, double x, bool deriv) {
  if (n < 0 || std::isnan(x))
    return NaN;
  if (deriv) {
    if (n == 0)
      return -sph_kn(1, x, false);
    return -sph_kn(n - 1, x, false) - (n + 1) / x * sph_kn(n, x, false);
  }
  if (x == 0)
    return Inf;
  if (x < 0)
    return NaN;
  if (std::isinf(x))
    return 0.0;
  return std::sqrt(PI / (2 * x)) * besselk(n + 0.5, x);
}

cd sph_jn(int n, cd z, bool deriv) {
  if (z.imag() == 0.0)
    return sph_jn(n, z.real(), deriv);
  if (deriv)
    return n == 0 ? -sph_jn(1, z, false) : sph_jn(n - 1, z, false) - double(n + 1) / z * sph_jn(n, z, false);
  return std::sqrt(PI / (2.0 * z)) * besselj(n + 0.5, z);
}
cd sph_yn(int n, cd z, bool deriv) {
  if (z.imag() == 0.0)
    return sph_yn(n, z.real(), deriv);
  if (deriv)
    return n == 0 ? -sph_yn(1, z, false) : sph_yn(n - 1, z, false) - double(n + 1) / z * sph_yn(n, z, false);
  return std::sqrt(PI / (2.0 * z)) * bessely(n + 0.5, z);
}
cd sph_in(int n, cd z, bool deriv) {
  if (z.imag() == 0.0)
    return sph_in(n, z.real(), deriv);
  if (deriv)
    return n == 0 ? sph_in(1, z, false) : sph_in(n - 1, z, false) - double(n + 1) / z * sph_in(n, z, false);
  return std::sqrt(PI / (2.0 * z)) * besseli(n + 0.5, z);
}
cd sph_kn(int n, cd z, bool deriv) {
  if (z.imag() == 0.0)
    return sph_kn(n, z.real(), deriv);
  if (deriv)
    return n == 0 ? -sph_kn(1, z, false) : -sph_kn(n - 1, z, false) - double(n + 1) / z * sph_kn(n, z, false);
  return std::sqrt(PI / (2.0 * z)) * besselk(n + 0.5, z);
}

} // namespace sf
} // namespace scipy
} // namespace nc
