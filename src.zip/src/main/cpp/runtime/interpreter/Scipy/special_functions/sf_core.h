// Scalar kernels of scipy.special, written from the published algorithms
// (Cephes, Temme, Carlson, Thompson-Barnett, Weideman, Golub-Welsch).
// Pure functions of their numbers: no Value, no printing, safe on any thread.
// Statistics and the probability distributions (sections 21-23) use them too.
//
// Conventions: a result outside the function's domain is NaN; a pole is +inf
// or -inf as SciPy gives it.
#ifndef NC_SCIPY_SF_CORE_H
#define NC_SCIPY_SF_CORE_H

#include <complex>
#include <functional>
#include <limits>
#include <vector>

namespace nc {
namespace scipy {
namespace sf {

using cd = std::complex<double>;

constexpr double PI = 3.14159265358979323846;
constexpr double EULER = 0.57721566490153286061;
constexpr double SQRTPI = 1.77245385090551602730;
constexpr double LOG_SQRT_2PI = 0.91893853320467274178;
constexpr double NaN = std::numeric_limits<double>::quiet_NaN();
constexpr double Inf = std::numeric_limits<double>::infinity();

// ---- gamma family (sf_gamma.cpp) ----
double gamma(double x);
cd gamma(cd z);
double lgam(double x);    // log|Gamma(x)|
cd loggamma(cd z);        // principal branch
double rgamma(double x);  // 1/Gamma(x), 0 at the poles
double gammasgn(double x);
double digamma(double x);
cd digamma(cd z);
double polygamma(int n, double x);
double zeta(double s, double q); // Hurwitz zeta
double riemann_zeta(double s);
double zetac(double s);          // zeta(s) - 1
double beta(double a, double b);
double lbeta(double a, double b);   // log|B(a, b)|
double binom(double n, double k);
double poch(double z, double m);
double lfactorial(double n);
double gammainc(double a, double x);  // regularized lower P(a, x)
double gammaincc(double a, double x); // regularized upper Q(a, x)
double gammaincinv(double a, double p);
double gammainccinv(double a, double q);
double betainc(double a, double b, double x);
double betaincc(double a, double b, double x);
double betaincinv(double a, double b, double y);
double betainccinv(double a, double b, double y);
double multigammaln(double a, int d);

// ---- error function family (sf_erf.cpp) ----
double erfcx(double x);
double erfi(double x);
double dawsn(double x);
double erfinv(double y);
double erfcinv(double y);
cd faddeeva(cd z); // w(z) = exp(-z^2) erfc(-iz)
cd erf(cd z);
cd erfc(cd z);
cd erfcx(cd z);
cd erfi(cd z);
cd dawsn(cd z);
double ndtr(double x);
double log_ndtr(double x);
cd log_ndtr(cd z);
double ndtri(double p);
double ndtri_exp(double y);
double owens_t(double h, double a);
double voigt(double x, double sigma, double gam);
double expi(double x);
cd expi(cd z);
double exp1(double x);
cd exp1(cd z);
double expn(int n, double x);
void sici(double x, double &si, double &ci);
void sici(cd z, cd &si, cd &ci);
void shichi(double x, double &shi, double &chi);
void shichi(cd z, cd &shi, cd &chi);
void fresnel(double x, double &s, double &c);
void fresnel(cd z, cd &s, cd &c);
double spence(double x);
cd spence(cd z);
cd lambertw(cd z, int k, double tol);
double wrightomega(double x);
cd wrightomega(cd z);
double kolmogorov(double y);
double kolmogi(double p);
double kolmogorov_cdf(double y);
double smirnov(int n, double d);
double smirnovi(int n, double p);

// ---- Bessel family (sf_bessel.cpp) ----
// Real order v, real x. Scaled forms multiply by exp(-|x|) (I), exp(x) (K).
double besselj(double v, double x);
double bessely(double v, double x);
double besseli(double v, double x, bool scaled = false);
double besselk(double v, double x, bool scaled = false);
// Complex argument, real order. scaled: J,Y by exp(-|Im z|), I by exp(-|Re z|), K by exp(z).
cd besselj(double v, cd z, bool scaled = false);
cd bessely(double v, cd z, bool scaled = false);
cd besseli(double v, cd z, bool scaled = false);
cd besselk(double v, cd z, bool scaled = false);
cd hankel1(double v, cd z, bool scaled = false);
cd hankel2(double v, cd z, bool scaled = false);
// n-th derivative of J, Y, I, K, H1, H2 (DLMF 10.6.7).
double bessel_deriv(char kind, double v, double x, int n);
cd hankel_deriv(int kind, double v, double x, int n);
void airy(double x, double &ai, double &aip, double &bi, double &bip);
void airye(double x, double &ai, double &aip, double &bi, double &bip);
double struve_h(double v, double x);
double struve_l(double v, double x);
cd kelvin_be(double x);  // ber + i bei
cd kelvin_ke(double x);  // ker + i kei
cd kelvin_bep(double x); // ber' + i bei'
cd kelvin_kep(double x); // ker' + i kei'
double sph_jn(int n, double x, bool deriv);
double sph_yn(int n, double x, bool deriv);
double sph_in(int n, double x, bool deriv);
double sph_kn(int n, double x, bool deriv);
cd sph_jn(int n, cd z, bool deriv);
cd sph_yn(int n, cd z, bool deriv);
cd sph_in(int n, cd z, bool deriv);
cd sph_kn(int n, cd z, bool deriv);
// First nt positive zeros of f, starting from a bracketing scan.
std::vector<double> zeros_of(const std::function<double(double)> &f, int nt, double start, double step);

// ---- elliptic integrals (sf_ellip.cpp) ----
double elliprf(double x, double y, double z);
double elliprd(double x, double y, double z);
double elliprj(double x, double y, double z, double p);
double elliprc(double x, double y);
double elliprg(double x, double y, double z);
double ellipk(double m);
double ellipkm1(double p);
double ellipe(double m);
double ellipkinc(double phi, double m);
double ellipeinc(double phi, double m);
void ellipj(double u, double m, double &sn, double &cn, double &dn, double &ph);
double agm(double a, double b);

// ---- hypergeometric and related (sf_hyper.cpp) ----
double hyp0f1(double b, double z);
cd hyp0f1(double b, cd z);
double hyp1f1(double a, double b, double x);
double hyperu(double a, double b, double x);
double hyp2f1(double a, double b, double c, double x);
cd hyp2f1(double a, double b, double c, cd z);
void pbdv(double v, double x, double &d, double &dp);
void pbvv(double v, double x, double &vv, double &vp);
void pbwa(double a, double x, double &w, double &wp);
double wright_bessel(double a, double b, double x);
double log_wright_bessel(double a, double b, double x);

// ---- integration helper (sf_quad.cpp) ----
// Adaptive Gauss-Kronrod 15-point on [a, b]; infinite ends are mapped.
double quad(const std::function<double(double)> &f, double a, double b, double epsabs = 1e-13,
            double epsrel = 1e-12, int limit = 200, double *err = nullptr);
// Root of f in [a, b] with f(a), f(b) of opposite signs (Brent).
double brent(const std::function<double(double)> &f, double a, double b, double xtol = 1e-15,
             int maxit = 300);
// Symmetric tridiagonal eigenvalues and first components of eigenvectors (Golub-Welsch).
void tridiag_eig(std::vector<double> d, std::vector<double> e, std::vector<double> &vals,
                 std::vector<std::vector<double>> *vecs);

} // namespace sf
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SF_CORE_H
