// Orthogonal polynomials, Legendre functions, Mathieu and spheroidal wave
// functions, ellipsoidal harmonics and the cdflib-style distribution
// functions. Same rules as sf_core.h: pure numbers, thread-safe.
#ifndef NC_SCIPY_SF_POLY_H
#define NC_SCIPY_SF_POLY_H

#include <string>
#include <complex>
#include <vector>

#include "sf_core.h"

namespace nc {
namespace scipy {
namespace sf {

// ---- orthogonal polynomials (sf_poly.cpp) ----
double eval_legendre(double n, double x);
double eval_chebyt(double n, double x);
double eval_chebyu(double n, double x);
double eval_chebyc(double n, double x);
double eval_chebys(double n, double x);
double eval_jacobi(double n, double a, double b, double x);
double eval_sh_jacobi(double n, double p, double q, double x);
double eval_gegenbauer(double n, double a, double x);
double eval_genlaguerre(double n, double a, double x);
double eval_laguerre(double n, double x);
double eval_hermite(double n, double x);
double eval_hermitenorm(double n, double x);
// Coefficients, highest power first. fam: legendre, chebyt, chebyu, chebyc,
// chebys, jacobi, laguerre, genlaguerre, hermite, hermitenorm, gegenbauer,
// sh_legendre, sh_chebyt, sh_chebyu, sh_jacobi.
std::vector<double> poly_coef(const std::string &fam, int n, double a, double b);
// Gauss nodes and weights for the same families; false on invalid parameters.
bool gauss_rule(const std::string &fam, int n, double a, double b, std::vector<double> &x, std::vector<double> &w);

double assoc_legendre(int n, int m, double x, bool norm); // with the Condon-Shortley phase
// The same for complex z, with (1 - z^2)^(m/2) on the principal branch (SciPy branch_cut 2).
std::complex<double> assoc_legendre_c(int n, int m, std::complex<double> z, bool norm);
double sph_legendre(int n, int m, double theta);
double legendre_deriv(int n, double x, int d);
double lpmv(double m, double v, double x);
void lqn(int n, cd z, std::vector<cd> &Q, std::vector<cd> &Qd);
void lqmn(int m, int n, double x, std::vector<std::vector<double>> &Q, std::vector<std::vector<double>> &Qd);

// ---- Mathieu, spheroidal, Lame (sf_wave.cpp) ----
double mathieu_a(double m, double q);
double mathieu_b(double m, double q);
// Fourier coefficients A (even) or B (odd), unit normalization, ce(0) > 0 / se'(0) > 0.
std::vector<double> mathieu_coef(bool even, int m, double q, int count);
void mathieu_ce(double m, double q, double xdeg, double &y, double &yp);
void mathieu_se(double m, double q, double xdeg, double &y, double &yp);
void mathieu_mc(int kind, double m, double q, double x, double &y, double &yp); // Mc^(1), Mc^(2)
void mathieu_ms(int kind, double m, double q, double x, double &y, double &yp);
double sph_cv(bool prolate, int m, int n, double c);
std::vector<double> sph_cv_seq(bool prolate, int m, int n, double c);
void sph_ang1(bool prolate, int m, int n, double c, double cv, double x, double &s, double &sp);
void sph_rad1(bool prolate, int m, int n, double c, double cv, double x, double &r, double &rp);
void sph_rad2(bool prolate, int m, int n, double c, double cv, double x, double &r, double &rp);
double ellip_harm(double h2, double k2, int n, int p, double s, double signm, double signn);
double ellip_harm_2(double h2, double k2, int n, int p, double s);
double ellip_normal(double h2, double k2, int n, int p);

// ---- distribution functions in cdflib style (sf_cdf.cpp) ----
double bdtr(double k, double n, double p);
double bdtrc(double k, double n, double p);
double bdtri(double k, double n, double y);
double bdtrik(double y, double n, double p);
double bdtrin(double k, double y, double p);
double btdtria(double p, double b, double x);
double btdtrib(double a, double p, double x);
double chdtr(double v, double x);
double chdtrc(double v, double x);
double chdtri(double v, double p);
double chdtriv(double p, double x);
double chndtr(double x, double df, double nc);
double chndtridf(double x, double p, double nc);
double chndtrinc(double x, double df, double p);
double chndtrix(double p, double df, double nc);
double fdtr(double dfn, double dfd, double x);
double fdtrc(double dfn, double dfd, double x);
double fdtri(double dfn, double dfd, double p);
double fdtridfd(double dfn, double p, double x);
double gdtr(double a, double b, double x);
double gdtrc(double a, double b, double x);
double gdtria(double p, double b, double x);
double gdtrib(double a, double p, double x);
double gdtrix(double a, double b, double p);
double nbdtr(double k, double n, double p);
double nbdtrc(double k, double n, double p);
double nbdtri(double k, double n, double y);
double nbdtrik(double y, double n, double p);
double nbdtrin(double k, double y, double p);
double ncfdtr(double dfn, double dfd, double nc, double f);
double ncfdtri(double dfn, double dfd, double nc, double p);
double ncfdtridfd(double dfn, double p, double nc, double f);
double ncfdtridfn(double p, double dfd, double nc, double f);
double ncfdtrinc(double dfn, double dfd, double p, double f);
double nctdtr(double df, double nc, double t);
double nctdtridf(double p, double nc, double t);
double nctdtrinc(double df, double p, double t);
double nctdtrit(double df, double nc, double p);
double nrdtrimn(double p, double sd, double x);
double nrdtrisd(double mn, double p, double x);
double pdtr(double k, double m);
double pdtrc(double k, double m);
double pdtri(double k, double y);
double pdtrik(double p, double m);
double stdtr(double df, double t);
double stdtridf(double p, double t);
double stdtrit(double df, double p);
double tklmbda(double x, double lmbda);
// Noncentral densities used by the distributions.
double ncx2_pdf(double x, double df, double nc);
double ncf_pdf(double x, double dfn, double dfd, double nc);
double nct_pdf(double x, double df, double nc);
// Solve F(x) = target for monotone F on [lo, hi] (searching in log space when
// lo > 0); returns the nearer bound when the target is out of reach, like cdflib.
double cdf_search(const std::function<double(double)> &F, double target, double lo, double hi, bool logScale);

} // namespace sf
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SF_POLY_H
