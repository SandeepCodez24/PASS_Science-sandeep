// Elliptic integrals through Carlson's symmetric forms (duplication theorem,
// Numer. Algorithms 10, 1995), Jacobi elliptic functions by descending Landen
// transformation, and the arithmetic-geometric mean.
#include "sf_core.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {
const double R = 1e-16;
}

double elliprc(double x, double y) {
  if (std::isnan(x) || std::isnan(y) || x < 0 || y == 0)
    return NaN;
  if (std::isinf(x) || std::isinf(y))
    return 0.0;
  if (y < 0) // Cauchy principal value
    return std::sqrt(x / (x - y)) * elliprc(x - y, -y);
  if (x == 0)
    return PI / (2.0 * std::sqrt(y));
  double A0 = (x + 2 * y) / 3.0, A = A0;
  double Q = std::pow(3 * R, -1.0 / 8.0) * std::fabs(A0 - x), fac = 1.0;
  for (int it = 0; it < 100 && fac * Q >= std::fabs(A); it++) {
    double lam = 2 * std::sqrt(x) * std::sqrt(y) + y;
    x = (x + lam) / 4;
    y = (y + lam) / 4;
    A = (A + lam) / 4;
    fac /= 4;
  }
  double s = (y - A) / A;
  double s2 = s * s;
  return (1 + s2 * (3.0 / 10 + s * (1.0 / 7 + s * (3.0 / 8 + s * (9.0 / 22 + s * (159.0 / 208 + s * 9.0 / 8)))))) /
         std::sqrt(A);
}

double elliprf(double x, double y, double z) {
  if (std::isnan(x) || std::isnan(y) || std::isnan(z) || x < 0 || y < 0 || z < 0)
    return NaN;
  if ((x == 0) + (y == 0) + (z == 0) > 1)
    return Inf;
  if (std::isinf(x) || std::isinf(y) || std::isinf(z))
    return 0.0;
  double A0 = (x + y + z) / 3.0, A = A0;
  double Q = std::pow(3 * R, -1.0 / 6.0) * std::max({std::fabs(A0 - x), std::fabs(A0 - y), std::fabs(A0 - z)});
  double fac = 1.0;
  for (int it = 0; it < 100 && fac * Q >= std::fabs(A); it++) {
    double sx = std::sqrt(x), sy = std::sqrt(y), sz = std::sqrt(z);
    double lam = sx * sy + sy * sz + sz * sx;
    x = (x + lam) / 4;
    y = (y + lam) / 4;
    z = (z + lam) / 4;
    A = (A + lam) / 4;
    fac /= 4;
  }
  double X = (A - x) / A, Y = (A - y) / A, Z = -(X + Y);
  double E2 = X * Y - Z * Z, E3 = X * Y * Z;
  return (1 - E2 / 10 + E3 / 14 + E2 * E2 / 24 - 3 * E2 * E3 / 44) / std::sqrt(A);
}

double elliprd(double x, double y, double z) {
  if (std::isnan(x) || std::isnan(y) || std::isnan(z) || x < 0 || y < 0 || z <= 0)
    return NaN;
  if (x == 0 && y == 0)
    return Inf;
  if (std::isinf(x) || std::isinf(y) || std::isinf(z))
    return 0.0;
  double A0 = (x + y + 3 * z) / 5.0, A = A0;
  double Q = std::pow(R / 4, -1.0 / 6.0) * std::max({std::fabs(A0 - x), std::fabs(A0 - y), std::fabs(A0 - z)});
  double fac = 1.0, sum = 0.0;
  for (int it = 0; it < 100 && fac * Q >= std::fabs(A); it++) {
    double sx = std::sqrt(x), sy = std::sqrt(y), sz = std::sqrt(z);
    double lam = sx * sy + sy * sz + sz * sx;
    sum += fac / (sz * (z + lam));
    x = (x + lam) / 4;
    y = (y + lam) / 4;
    z = (z + lam) / 4;
    A = (A + lam) / 4;
    fac /= 4;
  }
  double X = (A - x) / A, Y = (A - y) / A, Z = -(X + Y) / 3;
  double XY = X * Y, Z2 = Z * Z;
  double E2 = XY - 6 * Z2, E3 = (3 * XY - 8 * Z2) * Z, E4 = 3 * (XY - Z2) * Z2, E5 = XY * Z2 * Z;
  return fac * std::pow(A, -1.5) *
             (1 - 3 * E2 / 14 + E3 / 6 + 9 * E2 * E2 / 88 - 3 * E4 / 22 - 9 * E2 * E3 / 52 + 3 * E5 / 26) +
         3 * sum;
}

double elliprj(double x, double y, double z, double p) {
  if (std::isnan(x) || std::isnan(y) || std::isnan(z) || std::isnan(p) || x < 0 || y < 0 || z < 0)
    return NaN;
  if (p == 0 || (x == 0) + (y == 0) + (z == 0) > 1)
    return Inf;
  if (p < 0) {
    // Carlson's formula for the principal value with p < 0.
    double xs = x, ys = y, zs = z;
    if (xs > ys)
      std::swap(xs, ys);
    if (ys > zs)
      std::swap(ys, zs);
    if (xs > ys)
      std::swap(xs, ys);
    double q = -p;
    double pp = (zs * (xs + ys + q) - xs * ys) / (zs + q);
    double r = (pp - zs) * elliprj(xs, ys, zs, pp) - 3 * elliprf(xs, ys, zs) +
               3 * std::sqrt(xs * ys * zs / (xs * ys + pp * q)) * elliprc(xs * ys + pp * q, pp * q);
    return r / (zs + q);
  }
  double A0 = (x + y + z + 2 * p) / 5.0, A = A0;
  double delta = (p - x) * (p - y) * (p - z);
  double Q = std::pow(R / 4, -1.0 / 6.0) *
             std::max({std::fabs(A0 - x), std::fabs(A0 - y), std::fabs(A0 - z), std::fabs(A0 - p)});
  double fac = 1.0, sum = 0.0, f3 = 1.0;
  for (int it = 0; it < 100 && fac * Q >= std::fabs(A); it++) {
    double sx = std::sqrt(x), sy = std::sqrt(y), sz = std::sqrt(z), sp = std::sqrt(p);
    double lam = sx * sy + sy * sz + sz * sx;
    double d = (sp + sx) * (sp + sy) * (sp + sz);
    double e = delta * f3 / (d * d);
    sum += fac * elliprc(1.0, 1.0 + e) / d;
    x = (x + lam) / 4;
    y = (y + lam) / 4;
    z = (z + lam) / 4;
    p = (p + lam) / 4;
    A = (A + lam) / 4;
    fac /= 4;
    f3 /= 64;
  }
  double X = (A - x) / A, Y = (A - y) / A, Z = (A - z) / A, P = -(X + Y + Z) / 2;
  double E2 = X * Y + X * Z + Y * Z - 3 * P * P;
  double E3 = X * Y * Z + 2 * E2 * P + 4 * P * P * P;
  double E4 = (2 * X * Y * Z + E2 * P + 3 * P * P * P) * P;
  double E5 = X * Y * Z * P * P;
  return fac * std::pow(A, -1.5) *
             (1 - 3 * E2 / 14 + E3 / 6 + 9 * E2 * E2 / 88 - 3 * E4 / 22 - 9 * E2 * E3 / 52 + 3 * E5 / 26) +
         6 * sum;
}

double elliprg(double x, double y, double z) {
  if (std::isnan(x) || std::isnan(y) || std::isnan(z) || x < 0 || y < 0 || z < 0)
    return NaN;
  if (std::isinf(x) || std::isinf(y) || std::isinf(z))
    return Inf;
  // Put the largest last so z > 0 unless all are zero.
  double v[3] = {x, y, z};
  std::sort(v, v + 3);
  x = v[0];
  y = v[1];
  z = v[2];
  if (z == 0)
    return 0.0;
  if (y == 0)
    return std::sqrt(z) / 2; // DLMF 19.20.3
  double r = z * elliprf(x, y, z) - (x - z) * (y - z) * elliprd(x, y, z) / 3.0;
  if (x > 0)
    r += std::sqrt(x * y / z);
  return r / 2.0;
}

double ellipk(double m) {
  if (std::isnan(m) || m > 1)
    return NaN;
  if (m == 1)
    return Inf;
  if (m == -Inf)
    return 0.0;
  return elliprf(0.0, 1.0 - m, 1.0);
}

double ellipkm1(double p) {
  if (std::isnan(p) || p < 0)
    return NaN;
  if (p == 0)
    return Inf;
  return elliprf(0.0, p, 1.0);
}

double ellipe(double m) {
  if (std::isnan(m) || m > 1)
    return NaN;
  if (m == 1)
    return 1.0;
  if (m == -Inf)
    return Inf;
  double y = 1.0 - m;
  return elliprf(0.0, y, 1.0) - m / 3.0 * elliprd(0.0, y, 1.0);
}

double ellipkinc(double phi, double m) {
  if (std::isnan(phi) || std::isnan(m) || m > 1e300)
    return NaN;
  if (std::isinf(phi))
    return phi;
  if (m == 0)
    return phi;
  double k = std::round(phi / PI);
  double p0 = phi - k * PI;
  double s = std::sin(p0), c = std::cos(p0);
  double y = 1.0 - m * s * s;
  if (y < 0)
    return NaN;
  double f = s * elliprf(c * c, y, 1.0);
  if (k != 0) {
    if (m >= 1)
      return k > 0 ? Inf : -Inf;
    f += 2 * k * ellipk(m);
  }
  return f;
}

double ellipeinc(double phi, double m) {
  if (std::isnan(phi) || std::isnan(m))
    return NaN;
  if (std::isinf(phi))
    return phi;
  if (m == 0)
    return phi;
  double k = std::round(phi / PI);
  double p0 = phi - k * PI;
  double s = std::sin(p0), c = std::cos(p0);
  double y = 1.0 - m * s * s;
  if (y < 0)
    return NaN;
  double e = s * elliprf(c * c, y, 1.0) - m / 3.0 * s * s * s * elliprd(c * c, y, 1.0);
  if (k != 0)
    e += 2 * k * ellipe(m);
  return e;
}

void ellipj(double u, double m, double &sn, double &cn, double &dn, double &ph) {
  if (std::isnan(u) || std::isnan(m) || m < 0 || m > 1) {
    sn = cn = dn = ph = NaN;
    return;
  }
  if (m < 1e-9) {
    double t = std::sin(u), b = std::cos(u), ai = 0.25 * m * (u - t * b);
    sn = t - ai * b;
    cn = b + ai * t;
    ph = u - ai;
    dn = 1.0 - 0.5 * m * t * t;
    return;
  }
  if (m >= 0.9999999999) {
    double ai = 0.25 * (1.0 - m), b = std::cosh(u), t = std::tanh(u), phi = 1.0 / b;
    double twon = b * std::sinh(u);
    sn = t + ai * (twon - u) / (b * b);
    ph = 2.0 * std::atan(std::exp(u)) - PI / 2 + ai * (twon - u) / b;
    ai *= t * phi;
    cn = phi - ai * (twon - u);
    dn = phi + ai * (twon + u);
    return;
  }
  double a[10], c[10];
  a[0] = 1.0;
  double b = std::sqrt(1.0 - m);
  c[0] = std::sqrt(m);
  double twon = 1.0;
  int i = 0;
  while (std::fabs(c[i] / a[i]) > 2.2e-16) {
    if (i > 7)
      break;
    double ai = a[i];
    ++i;
    c[i] = (ai - b) / 2.0;
    double t = std::sqrt(ai * b);
    a[i] = (ai + b) / 2.0;
    b = t;
    twon *= 2.0;
  }
  double phi = twon * a[i] * u, bb = 0.0;
  do {
    double t = c[i] * std::sin(phi) / a[i];
    bb = phi;
    phi = (std::asin(t) + phi) / 2.0;
  } while (--i);
  sn = std::sin(phi);
  double t = std::cos(phi);
  cn = t;
  dn = t / std::cos(phi - bb);
  ph = phi;
}

double agm(double a, double b) {
  if (std::isnan(a) || std::isnan(b))
    return NaN;
  if ((a < 0 && b > 0) || (a > 0 && b < 0))
    return NaN;
  if (a == 0 || b == 0)
    return 0.0;
  if (a == b)
    return a;
  double sgn = 1.0;
  if (a < 0) {
    sgn = -1.0;
    a = -a;
    b = -b;
  }
  if (std::isinf(a) || std::isinf(b))
    return sgn * Inf;
  for (int i = 0; i < 100; i++) {
    double an = 0.5 * (a + b), bn = std::sqrt(a) * std::sqrt(b);
    if (std::fabs(an - bn) <= 2.2e-16 * an) {
      a = an;
      break;
    }
    a = an;
    b = bn;
  }
  return sgn * a;
}

} // namespace sf
} // namespace scipy
} // namespace nc
