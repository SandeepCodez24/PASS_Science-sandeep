// Error functions, normal distribution, exponential and trigonometric
// integrals, Fresnel integrals, dilogarithm, Lambert W, Kolmogorov-Smirnov.
#include "sf_core.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {
const double kEps = 2.220446049250313e-16;
const cd I(0.0, 1.0);

// Weideman's rational approximation of w(z) for Im z >= 0 (SIAM J. Numer. Anal. 31, 1994).
struct Weideman {
  static const int N = 48;
  double L;
  double c[N];
  Weideman() {
    const int M = 2 * N, M2 = 2 * M;
    L = std::sqrt(N / std::sqrt(2.0));
    for (int n = 1; n <= N; n++) {
      double s = 0.0;
      for (int k = -M + 1; k <= M - 1; k++) {
        double th = k * PI / M;
        double t = L * std::tan(th / 2.0);
        double f = std::exp(-t * t) * (L * L + t * t);
        s += f * std::cos(PI * n * k / M);
      }
      c[n - 1] = s / M2;
    }
  }
  cd operator()(cd z) const {
    cd Z = (L + I * z) / (L - I * z);
    cd p = 0.0;
    for (int n = N - 1; n >= 0; n--)
      p = p * Z + c[n];
    cd d = L - I * z;
    return 2.0 * p / (d * d) + (1.0 / SQRTPI) / d;
  }
};
const Weideman &weideman() {
  static const Weideman w;
  return w;
}

cd erfSeries(cd z) {
  cd z2 = z * z, term = z, sum = z;
  for (int n = 1; n < 200; n++) {
    term *= -z2 / double(n);
    cd t = term / double(2 * n + 1);
    sum += t;
    if (std::abs(t) < kEps * std::abs(sum))
      break;
  }
  return 2.0 / SQRTPI * sum;
}
} // namespace

// ---- real error functions ----

double erfcx(double x) {
  if (std::isnan(x))
    return NaN;
  if (x < 0) {
    if (x < -26.7)
      return Inf;
    return 2.0 * std::exp(x * x) - erfcx(-x);
  }
  if (x < 2.0)
    return std::exp(x * x) * std::erfc(x);
  if (x > 5e7)
    return 1.0 / (SQRTPI * x);
  // erfc(x) e^{x^2} = 1/sqrt(pi) * 1/(x + (1/2)/(x + 1/(x + (3/2)/(x + ...))))
  const double tiny = 1e-300;
  double f = x, C = x, D = 0.0;
  for (int k = 1; k < 5000; k++) {
    double a = k / 2.0;
    D = x + a * D;
    if (std::fabs(D) < tiny)
      D = tiny;
    C = x + a / C;
    if (std::fabs(C) < tiny)
      C = tiny;
    D = 1.0 / D;
    double del = C * D;
    f *= del;
    if (std::fabs(del - 1.0) < kEps)
      break;
  }
  return 1.0 / (SQRTPI * f);
}

double dawsn(double x) {
  if (std::isnan(x))
    return NaN;
  double ax = std::fabs(x);
  double r;
  if (ax <= 10.0) {
    double x2 = ax * ax, term = ax, sum = ax;
    for (int n = 1; n < 400; n++) {
      term *= x2 / n;
      double t = term / (2 * n + 1);
      sum += t;
      if (t < kEps * sum)
        break;
    }
    r = std::exp(-x2) * sum;
  } else {
    double y = 1.0 / (2.0 * ax * ax), term = 1.0, sum = 1.0;
    for (int k = 1; k < 60; k++) {
      double nt = term * (2 * k - 1) * y;
      if (nt > term)
        break;
      term = nt;
      sum += term;
      if (term < kEps * sum)
        break;
    }
    r = sum / (2.0 * ax);
  }
  return x < 0 ? -r : r;
}

double erfi(double x) {
  if (std::isnan(x))
    return NaN;
  if (std::fabs(x) > 26.7)
    return x > 0 ? Inf : -Inf;
  return 2.0 / SQRTPI * std::exp(x * x) * dawsn(x);
}

double erfinv(double y) {
  if (std::isnan(y) || y < -1 || y > 1)
    return NaN;
  if (y == 1)
    return Inf;
  if (y == -1)
    return -Inf;
  if (std::fabs(y) > 0.5)
    return y > 0 ? erfcinv(1.0 - y) : -erfcinv(1.0 + y);
  // Giles' single-precision start, then Halley steps on erf.
  double w = -std::log((1.0 - y) * (1.0 + y)), p;
  w -= 2.5;
  p = 2.81022636e-08;
  p = 3.43273939e-07 + p * w;
  p = -3.5233877e-06 + p * w;
  p = -4.39150654e-06 + p * w;
  p = 0.00021858087 + p * w;
  p = -0.00125372503 + p * w;
  p = -0.00417768164 + p * w;
  p = 0.246640727 + p * w;
  p = 1.50140941 + p * w;
  double x = p * y;
  for (int i = 0; i < 3; i++) {
    double e = std::erf(x) - y;
    double d = 2.0 / SQRTPI * std::exp(-x * x);
    x -= e / (d + x * e);
  }
  return x;
}

double erfcinv(double y) {
  if (std::isnan(y) || y < 0 || y > 2)
    return NaN;
  if (y == 0)
    return Inf;
  if (y == 2)
    return -Inf;
  if (y > 1)
    return -erfcinv(2.0 - y);
  if (y > 0.5)
    return erfinv(1.0 - y);
  return -ndtri(0.5 * y) / std::sqrt(2.0);
}

// ---- complex error functions ----

cd faddeeva(cd z) {
  if (z.imag() == 0.0) {
    double x = z.real();
    return cd(std::exp(-x * x), 2.0 / SQRTPI * dawsn(x));
  }
  if (z.imag() < 0)
    return 2.0 * std::exp(-z * z) - faddeeva(-z);
  if (z.real() == 0.0)
    return cd(erfcx(z.imag()), 0.0);
  return weideman()(z);
}

cd erf(cd z) {
  if (z.imag() == 0.0)
    return cd(std::erf(z.real()), 0.0);
  if (std::abs(z) < 2.0)
    return erfSeries(z);
  if (z.real() < 0)
    return -erf(-z);
  return 1.0 - std::exp(-z * z) * faddeeva(I * z);
}

cd erfc(cd z) {
  if (z.imag() == 0.0)
    return cd(std::erfc(z.real()), 0.0);
  if (z.real() < 0)
    return 2.0 - erfc(-z);
  if (std::abs(z) < 0.5)
    return 1.0 - erfSeries(z);
  return std::exp(-z * z) * faddeeva(I * z);
}

cd erfcx(cd z) {
  if (z.imag() == 0.0)
    return cd(erfcx(z.real()), 0.0);
  return faddeeva(I * z);
}

cd erfi(cd z) {
  if (z.imag() == 0.0)
    return cd(erfi(z.real()), 0.0);
  return -I * erf(I * z);
}

cd dawsn(cd z) {
  if (z.imag() == 0.0)
    return cd(dawsn(z.real()), 0.0);
  if (std::abs(z) < 0.5) {
    // D(z) = sum (-1)^n 2^n z^(2n+1) / (2n+1)!!
    cd term = z, sum = z, z2 = z * z;
    for (int n = 1; n < 100; n++) {
      term *= -2.0 * z2 / double(2 * n + 1);
      sum += term;
      if (std::abs(term) < kEps * std::abs(sum))
        break;
    }
    return sum;
  }
  return SQRTPI / 2.0 * I * (std::exp(-z * z) - faddeeva(z));
}

// ---- normal distribution ----

double ndtr(double x) {
  if (std::isnan(x))
    return NaN;
  return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

double log_ndtr(double x) {
  if (std::isnan(x))
    return NaN;
  if (x > 6.0)
    return std::log1p(-0.5 * std::erfc(x / std::sqrt(2.0)));
  if (x > -1.0)
    return std::log(ndtr(x));
  double t = -x / std::sqrt(2.0);
  return std::log(0.5 * erfcx(t)) - t * t;
}

cd log_ndtr(cd z) {
  if (z.imag() == 0.0)
    return cd(log_ndtr(z.real()), 0.0);
  cd t = -z / std::sqrt(2.0);
  if (z.real() > 6.0)
    return std::log(1.0 - 0.5 * erfc(-t));
  if (z.real() > -1.0)
    return std::log(0.5 * erfc(t));
  return std::log(0.5 * faddeeva(I * t)) - t * t;
}

double ndtri(double p) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  if (p == 0)
    return -Inf;
  if (p == 1)
    return Inf;
  static const double a[] = {-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
                             1.383577518672690e+02,  -3.066479806614716e+01, 2.506628277459239e+00};
  static const double b[] = {-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
                             6.680131188771972e+01, -1.328068155288572e+01};
  static const double c[] = {-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
                             -2.549732539343734e+00, 4.374664141464968e+00,  2.938163982698783e+00};
  static const double d[] = {7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
                             3.754408661907416e+00};
  const double plow = 0.02425;
  double x;
  bool upper = p > 0.5;
  double pp = upper ? 1.0 - p : p;
  if (pp < plow) {
    double q = std::sqrt(-2.0 * std::log(pp));
    x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
        ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
  } else {
    double q = pp - 0.5, r = q * q;
    x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q /
        (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0);
  }
  // x solves Phi(x) = pp (pp <= 1/2, so x <= 0). Halley steps on the lower tail.
  for (int i = 0; i < 2; i++) {
    double e = 0.5 * std::erfc(-x / std::sqrt(2.0)) - pp;
    double u = e * std::sqrt(2.0 * PI) * std::exp(x * x / 2.0);
    x = x - u / (1.0 + x * u / 2.0);
  }
  return upper ? -x : x;
}

double ndtri_exp(double y) {
  if (std::isnan(y) || y > 0)
    return NaN;
  if (y == 0)
    return Inf;
  if (y == -Inf)
    return -Inf;
  if (y > -0.6931471805599453)
    return -ndtri(-std::expm1(y));
  if (y > -700)
    return ndtri(std::exp(y));
  // Deep tail: Newton on log_ndtr.
  double x = -std::sqrt(-2.0 * y - std::log(-2.0 * y) - std::log(2.0 * PI));
  for (int i = 0; i < 50; i++) {
    double f = log_ndtr(x) - y;
    double t = -x / std::sqrt(2.0);
    double dlog = 2.0 / (std::sqrt(2.0 * PI) * erfcx(t)); // phi(x)/Phi(x)
    double dx = f / dlog;
    x -= dx;
    if (std::fabs(dx) < 1e-15 * std::fabs(x))
      break;
  }
  return x;
}

double owens_t(double h, double a) {
  if (std::isnan(h) || std::isnan(a))
    return NaN;
  if (a < 0)
    return -owens_t(h, -a);
  h = std::fabs(h);
  if (a == 0)
    return 0.0;
  if (std::isinf(a))
    return 0.5 * ndtr(-h);
  if (h == 0)
    return std::atan(a) / (2 * PI);
  if (a <= 1.0) {
    double scale = std::exp(-0.5 * h * h);
    if (scale == 0.0)
      return 0.0;
    auto f = [&](double x) { return std::exp(-0.5 * h * h * x * x) / (1 + x * x); };
    return scale * quad(f, 0.0, a, 0.0, 1e-14) / (2 * PI);
  }
  double ah = a * h;
  double q1 = ndtr(-h), q2 = ndtr(-ah);
  return 0.5 * (q1 + q2) - q1 * q2 - owens_t(ah, 1.0 / a);
}

double voigt(double x, double sigma, double gam) {
  if (std::isnan(x) || std::isnan(sigma) || std::isnan(gam))
    return NaN;
  if (sigma == 0) {
    if (gam == 0)
      return x == 0 ? Inf : 0.0;
    return gam / (PI * (x * x + gam * gam));
  }
  if (gam == 0)
    return std::exp(-x * x / (2 * sigma * sigma)) / (sigma * std::sqrt(2 * PI));
  cd z = cd(x, gam) / (sigma * std::sqrt(2.0));
  return faddeeva(z).real() / (sigma * std::sqrt(2 * PI));
}

// ---- exponential integrals ----

double expn(int n, double x) {
  if (std::isnan(x) || n < 0 || x < 0)
    return NaN;
  if (x == 0)
    return n > 1 ? 1.0 / (n - 1) : Inf;
  if (n == 0)
    return std::exp(-x) / x;
  if (x > 700)
    return 0.0;
  const double tiny = 1e-300;
  int nm1 = n - 1;
  if (x > 1.0) {
    double b = x + n, c = 1.0 / tiny, d = 1.0 / b, h = d;
    for (int i = 1; i < 100000; i++) {
      double a = -i * double(nm1 + i);
      b += 2.0;
      d = 1.0 / (a * d + b);
      c = b + a / c;
      double del = c * d;
      h *= del;
      if (std::fabs(del - 1.0) < kEps)
        break;
    }
    return h * std::exp(-x);
  }
  double ans = nm1 != 0 ? 1.0 / nm1 : -std::log(x) - EULER;
  double fact = 1.0;
  for (int i = 1; i < 100000; i++) {
    fact *= -x / i;
    double del;
    if (i != nm1)
      del = -fact / (i - nm1);
    else {
      double psi = -EULER;
      for (int ii = 1; ii <= nm1; ii++)
        psi += 1.0 / ii;
      del = fact * (-std::log(x) + psi);
    }
    ans += del;
    if (std::fabs(del) < std::fabs(ans) * kEps)
      break;
  }
  return ans;
}

double expi(double x) {
  if (std::isnan(x))
    return NaN;
  if (x == 0)
    return -Inf;
  if (x < 0)
    return -expn(1, -x);
  if (x > 709.8)
    return Inf;
  if (x < 40) {
    double sum = 0.0, term = 1.0;
    for (int k = 1; k < 1000; k++) {
      term *= x / k;
      double t = term / k;
      sum += t;
      if (t < kEps * sum)
        break;
    }
    return EULER + std::log(x) + sum;
  }
  double sum = 1.0, term = 1.0;
  for (int k = 1; k < 100; k++) {
    double prev = term;
    term *= k / x;
    if (term > prev)
      break;
    sum += term;
    if (term < kEps * sum)
      break;
  }
  return std::exp(x) / x * sum;
}

double exp1(double x) {
  if (std::isnan(x))
    return NaN;
  if (x < 0)
    return NaN;
  return expn(1, x);
}

cd exp1(cd z) {
  if (z.imag() == 0.0 && z.real() >= 0)
    return cd(expn(1, z.real()), 0.0);
  if (z == cd(0.0, 0.0))
    return cd(Inf, 0.0);
  if (std::abs(z) < 5.0 || (z.real() < 0 && std::fabs(z.imag()) < 4.0 * std::abs(z.real()))) {
    cd sum = 0.0, term = 1.0;
    for (int k = 1; k < 3000; k++) {
      term *= -z / double(k);
      cd t = term / double(k);
      sum += t;
      if (std::abs(t) < kEps * std::abs(sum))
        break;
    }
    cd r = -EULER - std::log(z) - sum;
    if (z.imag() == 0.0) // negative real axis: SciPy takes the upper side
      r = cd(r.real(), -PI);
    return r;
  }
  // Continued fraction (n = 1), valid away from the negative real axis.
  const double tiny = 1e-300;
  cd b = z + 1.0, c = 1.0 / tiny, d = 1.0 / b, h = d;
  for (int i = 1; i < 100000; i++) {
    double a = -double(i) * i;
    b += 2.0;
    d = 1.0 / (a * d + b);
    c = b + a / c;
    cd del = c * d;
    h *= del;
    if (std::abs(del - 1.0) < kEps)
      break;
  }
  return h * std::exp(-z);
}

cd expi(cd z) {
  if (z.imag() == 0.0)
    return cd(expi(z.real()), 0.0);
  cd r = -exp1(-z);
  return r + (z.imag() > 0 ? cd(0, PI) : cd(0, -PI));
}

void sici(double x, double &si, double &ci) {
  if (std::isnan(x)) {
    si = ci = NaN;
    return;
  }
  double t = std::fabs(x);
  if (t == 0.0) {
    si = 0.0;
    ci = -Inf;
    return;
  }
  if (std::isinf(t)) {
    si = x > 0 ? PI / 2 : -PI / 2;
    ci = 0.0;
    if (x < 0)
      ci = NaN;
    return;
  }
  const double tiny = 1e-300;
  if (t > 2.0) {
    cd b(1.0, t), c = 1.0 / tiny, d = 1.0 / b, h = d;
    for (int i = 2; i < 100000; i++) {
      double a = -double(i - 1) * (i - 1);
      b += 2.0;
      d = 1.0 / (a * d + b);
      c = b + a / c;
      cd del = c * d;
      h *= del;
      if (std::fabs(del.real() - 1.0) + std::fabs(del.imag()) < kEps)
        break;
    }
    h *= cd(std::cos(t), -std::sin(t));
    ci = -h.real();
    si = PI / 2 + h.imag();
  } else {
    double sum, sums = 0, sumc = 0, sign = 1.0, fact = 1.0;
    bool odd = true;
    if (t < std::sqrt(tiny)) {
      sumc = 0.0;
      sums = t;
    } else {
      sum = sums = sumc = 0.0;
      for (int k = 1; k < 1000; k++) {
        fact *= t / k;
        double term = fact / k;
        sum += sign * term;
        double err = term / std::fabs(sum);
        if (odd) {
          sign = -sign;
          sums = sum;
          sum = sumc;
        } else {
          sumc = sum;
          sum = sums;
        }
        if (err < kEps)
          break;
        odd = !odd;
      }
    }
    si = sums;
    ci = sumc + std::log(t) + EULER;
  }
  if (x < 0)
    si = -si; // SciPy returns Ci(|x|), the real part, for x < 0
}

void sici(cd z, cd &si, cd &ci) {
  if (z.imag() == 0.0 && z.real() > 0) {
    double s, c;
    sici(z.real(), s, c);
    si = s;
    ci = c;
    return;
  }
  bool neg = z.real() < 0 || (z.real() == 0 && z.imag() < 0);
  cd w = neg ? -z : z;
  cd e1 = exp1(I * w), e2 = exp1(-I * w);
  cd s = (e2 - e1) / (2.0 * I) + PI / 2;
  cd c = -0.5 * (e1 + e2);
  if (neg) {
    s = -s;
    c = c + (z.imag() >= 0 ? cd(0, PI) : cd(0, -PI));
  }
  si = s;
  ci = c;
}

void shichi(double x, double &shi, double &chi) {
  if (std::isnan(x)) {
    shi = chi = NaN;
    return;
  }
  double t = std::fabs(x);
  if (t == 0) {
    shi = 0.0;
    chi = -Inf;
    return;
  }
  if (t < 40) {
    double term = 1.0, s = 0.0, c = 0.0;
    for (int k = 1; k < 1000; k++) {
      term *= t / k;
      double v = term / k;
      if (k % 2)
        s += v;
      else
        c += v;
      if (v < kEps * (s + std::fabs(c)))
        break;
    }
    shi = s;
    chi = EULER + std::log(t) + c;
  } else {
    double ei = expi(t), e1 = expn(1, t);
    shi = 0.5 * (ei + e1);
    chi = 0.5 * (ei - e1);
  }
  if (x < 0)
    shi = -shi;
}

void shichi(cd z, cd &shi, cd &chi) {
  if (z.imag() == 0.0) {
    double s, c;
    shichi(z.real(), s, c);
    shi = s;
    chi = c;
    return;
  }
  cd s, c;
  sici(I * z, s, c);
  shi = -I * s;
  // Chi(z) = Ci(iz) - log(iz) + log(z)
  chi = c - std::log(I * z) + std::log(z);
}

void fresnel(double x, double &s, double &c) {
  if (std::isnan(x)) {
    s = c = NaN;
    return;
  }
  double ax = std::fabs(x);
  const double tiny = 1e-300;
  if (std::isinf(ax)) {
    s = c = 0.5;
  } else if (ax < std::sqrt(tiny)) {
    s = 0.0;
    c = ax;
  } else if (ax <= 1.5) {
    double sum = 0.0, sums = 0.0, sumc = ax, sign = 1.0, fact = PI / 2 * ax * ax, term = ax;
    bool odd = true;
    int n = 3;
    for (int k = 1; k < 1000; k++) {
      term *= fact / k;
      sum += sign * term / n;
      double test = std::fabs(sum) * kEps;
      if (odd) {
        sign = -sign;
        sums = sum;
        sum = sumc;
      } else {
        sumc = sum;
        sum = sums;
      }
      if (term < test)
        break;
      odd = !odd;
      n += 2;
    }
    s = sums;
    c = sumc;
  } else {
    double pix2 = PI * ax * ax;
    cd b(1.0, -pix2), cc(1.0 / tiny, 0.0), d = 1.0 / b, h = d;
    int n = -1;
    for (int k = 2; k < 100000; k++) {
      n += 2;
      double a = -double(n) * (n + 1);
      b += 4.0;
      d = 1.0 / (a * d + b);
      cc = b + a / cc;
      cd del = cc * d;
      h *= del;
      if (std::fabs(del.real() - 1.0) + std::fabs(del.imag()) < kEps)
        break;
    }
    h *= cd(ax, -ax);
    cd cs = cd(0.5, 0.5) * (1.0 - cd(std::cos(0.5 * pix2), std::sin(0.5 * pix2)) * h);
    c = cs.real();
    s = cs.imag();
  }
  if (x < 0) {
    c = -c;
    s = -s;
  }
}

void fresnel(cd z, cd &s, cd &c) {
  if (z.imag() == 0.0) {
    double rs, rc;
    fresnel(z.real(), rs, rc);
    s = rs;
    c = rc;
    return;
  }
  // C + iS = (1+i)/2 erf(sqrt(pi)(1-i)z/2), C - iS = (1-i)/2 erf(sqrt(pi)(1+i)z/2)
  cd A = (1.0 + I) / 2.0 * erf(SQRTPI / 2.0 * (1.0 - I) * z);
  cd B = (1.0 - I) / 2.0 * erf(SQRTPI / 2.0 * (1.0 + I) * z);
  c = (A + B) / 2.0;
  s = (A - B) / (2.0 * I);
}

// ---- dilogarithm: spence(z) = Li2(1 - z) ----

namespace {
cd li2(cd u) {
  if (u == cd(0.0, 0.0))
    return 0.0;
  if (u == cd(1.0, 0.0))
    return PI * PI / 6.0;
  if (std::abs(u) > 1.0) {
    cd l = std::log(-u);
    if (u.imag() == 0.0) // -u is negative real: take the branch SciPy uses (upper side)
      l = cd(std::log(u.real()), -PI);
    return -li2(1.0 / u) - PI * PI / 6.0 - 0.5 * l * l;
  }
  if (u.real() > 0.5)
    return -li2(1.0 - u) + PI * PI / 6.0 - std::log(u) * std::log(1.0 - u);
  // Bernoulli numbers, filled once and thread-safely (function-local static;
  // the old "static bool init" flag was a data race under nc::par threads).
  struct BernoulliTable {
    double v[40] = {};
    BernoulliTable() {
      v[0] = 1.0;
      v[1] = -0.5;
      for (int n = 2; n < 40; n++)
        v[n] = (n % 2) ? 0.0
                       : ((n / 2) % 2 ? 1.0 : -1.0) * 2.0 * std::exp(std::lgamma(n + 1.0)) *
                             riemann_zeta(n) / std::pow(2 * PI, n);
    }
  };
  static const BernoulliTable bernoulli;
  const double *B = bernoulli.v;
  cd w = -std::log(1.0 - u), sum = 0.0, p = w;
  double fact = 1.0;
  for (int n = 0; n < 40; n++) {
    fact *= (n + 1);
    cd t = B[n] * p / fact;
    sum += t;
    if (n > 2 && n % 2 == 0 && std::abs(t) < kEps * std::abs(sum))
      break;
    p *= w;
  }
  return sum;
}
} // namespace

double spence(double x) {
  if (std::isnan(x) || x < 0)
    return NaN;
  if (x == 1.0)
    return 0.0;
  if (x == 0.0)
    return PI * PI / 6.0;
  return li2(cd(1.0 - x, 0.0)).real();
}

cd spence(cd z) {
  if (z.imag() == 0.0 && z.real() >= 0)
    return cd(spence(z.real()), 0.0);
  return li2(1.0 - z);
}

// ---- Lambert W and Wright omega ----

cd lambertw(cd z, int k, double tol) {
  if (std::isnan(z.real()) || std::isnan(z.imag()))
    return cd(NaN, NaN);
  if (z == cd(0.0, 0.0))
    return k == 0 ? cd(0.0, 0.0) : cd(-Inf, 0.0);
  if (z.real() == Inf && k == 0)
    return cd(Inf, 0.0);
  const double EXPN1 = 0.36787944117144232160;
  cd w;
  auto asy = [&]() {
    cd l = std::log(z) + cd(0.0, 2 * PI * k);
    return l - std::log(l);
  };
  if (k == 0) {
    if (std::abs(z + EXPN1) < 0.3) {
      cd p = std::sqrt(2.0 * (std::exp(1.0) * z + 1.0));
      w = -1.0 + p - p * p / 3.0 + 11.0 / 72.0 * p * p * p;
    } else if (z.real() > -1.0 && z.real() < 1.5 && std::fabs(z.imag()) < 1.0 &&
               -2.5 * std::fabs(z.imag()) - 0.2 < z.real()) {
      w = std::log(1.0 + z);
    } else
      w = asy();
  } else if (k == -1 && std::abs(z + EXPN1) < 0.3 && z.imag() == 0.0 && z.real() < 0) {
    cd p = std::sqrt(2.0 * (std::exp(1.0) * z + 1.0));
    w = -1.0 - p - p * p / 3.0 - 11.0 / 72.0 * p * p * p;
  } else
    w = asy();
  for (int i = 0; i < 200; i++) {
    cd wn;
    if (w.real() >= 0) {
      cd ew = std::exp(-w);
      cd wewz = w - z * ew;
      wn = w - wewz / (w + 1.0 - (w + 2.0) * wewz / (2.0 * w + 2.0));
    } else {
      cd ew = std::exp(w);
      cd wew = w * ew;
      cd wewz = wew - z;
      wn = w - wewz / (wew + ew - (w + 2.0) * wewz / (2.0 * w + 2.0));
    }
    if (std::abs(wn - w) <= tol * std::abs(wn))
      return wn;
    w = wn;
  }
  return w;
}

double wrightomega(double x) {
  if (std::isnan(x))
    return NaN;
  if (x == Inf)
    return Inf;
  if (x == -Inf)
    return 0.0;
  if (x < -745)
    return 0.0;
  if (x > 1e18)
    return x;
  double w = x > 1 ? x - std::log(x) : (x < -2 ? std::exp(x) : std::exp(x) * (1 + x / 2) / (1 + x));
  if (!(w > 0))
    w = 0.5;
  for (int i = 0; i < 100; i++) {
    double f = w + std::log(w) - x;
    double d1 = 1 + 1 / w, d2 = -1 / (w * w);
    double dw = f / (d1 - f * d2 / (2 * d1));
    double wn = w - dw;
    if (wn <= 0)
      wn = w / 10;
    if (std::fabs(wn - w) < 1e-16 * std::fabs(wn)) {
      w = wn;
      break;
    }
    w = wn;
  }
  return w;
}

cd wrightomega(cd z) {
  if (z.imag() == 0.0)
    return cd(wrightomega(z.real()), 0.0);
  double K = std::ceil((z.imag() - PI) / (2 * PI));
  cd w = lambertw(std::exp(z), static_cast<int>(K), 1e-15);
  for (int i = 0; i < 20; i++) {
    cd f = w + std::log(w) - z;
    cd dw = f / (1.0 + 1.0 / w);
    w -= dw;
    if (std::abs(dw) < 1e-16 * std::abs(w))
      break;
  }
  return w;
}

// ---- Kolmogorov-Smirnov ----

double kolmogorov(double y) {
  if (std::isnan(y))
    return NaN;
  if (y <= 0)
    return 1.0;
  if (y <= 1.0) {
    double cdf = kolmogorov_cdf(y);
    return 1.0 - cdf;
  }
  double sum = 0.0;
  for (int k = 1; k < 100; k++) {
    double t = std::exp(-2.0 * k * k * y * y);
    sum += (k % 2 ? 1 : -1) * t;
    if (t < 1e-20)
      break;
  }
  return 2.0 * sum;
}

double kolmogorov_cdf(double y) {
  if (std::isnan(y))
    return NaN;
  if (y <= 0)
    return 0.0;
  if (y <= 1.0) {
    double sum = 0.0;
    for (int k = 1; k < 100; k++) {
      double t = std::exp(-(2.0 * k - 1) * (2.0 * k - 1) * PI * PI / (8.0 * y * y));
      sum += t;
      if (t < 1e-20 * sum || t == 0)
        break;
    }
    return std::sqrt(2 * PI) / y * sum;
  }
  return 1.0 - kolmogorov(y);
}

double kolmogi(double p) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  if (p == 1)
    return 0.0;
  if (p == 0)
    return Inf;
  if (p > 0.5)
    return brent([&](double y) { return kolmogorov_cdf(y) - (1.0 - p); }, 1e-3, 1.5, 1e-16);
  double hi = 1.0;
  while (kolmogorov(hi) > p)
    hi *= 2;
  return brent([&](double y) { return kolmogorov(y) - p; }, 0.1, hi, 1e-16);
}

double smirnov(int n, double d) {
  if (std::isnan(d) || n <= 0)
    return NaN;
  if (d <= 0)
    return 1.0;
  if (d >= 1)
    return 0.0;
  if (n == 1)
    return 1.0 - d;
  int jmax = static_cast<int>(std::floor(n * (1.0 - d)));
  if (n * (1.0 - d) - jmax < 1e-12 && jmax > 0 && 1.0 - d - double(jmax) / n <= 0)
    jmax--;
  double lgn = std::lgamma(n + 1.0);
  double sum = 0.0;
  for (int j = 0; j <= jmax; j++) {
    double a = 1.0 - d - double(j) / n;
    if (a <= 0)
      break;
    double b = d + double(j) / n;
    double lt = lgn - std::lgamma(j + 1.0) - std::lgamma(n - j + 1.0) + (n - j) * std::log(a) + (j - 1) * std::log(b);
    sum += std::exp(lt);
  }
  return d * sum;
}

double smirnovi(int n, double p) {
  if (std::isnan(p) || n <= 0 || p < 0 || p > 1)
    return NaN;
  if (p == 1)
    return 0.0;
  if (p == 0)
    return 1.0;
  return brent([&](double d) { return smirnov(n, d) - p; }, 0.0, 1.0, 1e-16);
}

} // namespace sf
} // namespace scipy
} // namespace nc
