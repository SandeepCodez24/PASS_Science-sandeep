// Numerical helpers for the special functions: adaptive Gauss-Kronrod
// quadrature, Brent's root finder and the symmetric tridiagonal eigenproblem.
#include "sf_core.h"

#include <algorithm>
#include <cmath>
#include <queue>

namespace nc {
namespace scipy {
namespace sf {

namespace {
const double XGK[8] = {0.991455371120812639206854697526329, 0.949107912342758524526189684047851,
                       0.864864423359769072789712788640926, 0.741531185599394439863864773280788,
                       0.586087235467691130294144845693013, 0.405845151377397166906606412076961,
                       0.207784955007898467600689403773245, 0.0};
const double WGK[8] = {0.022935322010529224963732008058970, 0.063092092629978553290700663189204,
                       0.104790010322250183839876322541518, 0.140653259715525918745189590510238,
                       0.169004726639267902826583426598550, 0.190350578064785409913256402421014,
                       0.204432940075298892414161999234649, 0.209482141084727828012999174891714};
const double WG[4] = {0.129484966168869693270611432679082, 0.279705391489276667901467771423780,
                      0.381830050505118944950369775488975, 0.417959183673469387755102040816327};

struct Piece {
  double a, b, val, err;
  bool operator<(const Piece &o) const { return err < o.err; }
};

Piece gk15(const std::function<double(double)> &f, double a, double b) {
  double c = 0.5 * (a + b), h = 0.5 * (b - a);
  double fc = f(c);
  double rk = fc * WGK[7], rg = fc * WG[3];
  for (int j = 0; j < 7; j++) {
    double dx = h * XGK[j];
    double f1 = f(c - dx), f2 = f(c + dx);
    rk += WGK[j] * (f1 + f2);
    if (j % 2 == 1)
      rg += WG[j / 2] * (f1 + f2);
  }
  Piece p{a, b, rk * h, std::fabs((rk - rg) * h)};
  if (!std::isfinite(p.val))
    p.err = Inf;
  return p;
}
} // namespace

double quad(const std::function<double(double)> &f0, double a, double b, double epsabs, double epsrel,
            int limit, double *err) {
  if (a == b) {
    if (err)
      *err = 0;
    return 0.0;
  }
  if (a > b)
    return -quad(f0, b, a, epsabs, epsrel, limit, err);
  std::function<double(double)> f = f0;
  double lo = a, hi = b;
  if (std::isinf(a) && std::isinf(b)) {
    double e1 = 0, e2 = 0;
    double r = quad(f0, -Inf, 0.0, epsabs / 2, epsrel, limit, &e1) + quad(f0, 0.0, Inf, epsabs / 2, epsrel, limit, &e2);
    if (err)
      *err = e1 + e2;
    return r;
  }
  if (std::isinf(b)) {
    f = [&f0, a](double t) {
      if (t >= 1.0)
        return 0.0;
      double x = a + t / (1.0 - t);
      double v = f0(x) / ((1.0 - t) * (1.0 - t));
      return std::isfinite(v) ? v : 0.0;
    };
    lo = 0.0;
    hi = 1.0;
  } else if (std::isinf(a)) {
    f = [&f0, b](double t) {
      if (t <= 0.0)
        return 0.0;
      double x = b - (1.0 - t) / t;
      double v = f0(x) / (t * t);
      return std::isfinite(v) ? v : 0.0;
    };
    lo = 0.0;
    hi = 1.0;
  }
  std::priority_queue<Piece> q;
  Piece p0 = gk15(f, lo, hi);
  double total = p0.val, terr = p0.err;
  q.push(p0);
  int n = 1;
  while (terr > std::max(epsabs, epsrel * std::fabs(total)) && n < limit) {
    Piece w = q.top();
    q.pop();
    double m = 0.5 * (w.a + w.b);
    if (m <= w.a || m >= w.b) {
      q.push(w);
      break;
    }
    Piece l = gk15(f, w.a, m), r = gk15(f, m, w.b);
    total += l.val + r.val - w.val;
    terr += l.err + r.err - w.err;
    q.push(l);
    q.push(r);
    n++;
  }
  // Re-add from pieces to avoid drift from the running update.
  total = 0.0;
  terr = 0.0;
  while (!q.empty()) {
    total += q.top().val;
    terr += q.top().err;
    q.pop();
  }
  if (err)
    *err = terr;
  return total;
}

double brent(const std::function<double(double)> &f, double a, double b, double xtol, int maxit) {
  double fa = f(a), fb = f(b);
  if (std::isnan(fa) || std::isnan(fb))
    return NaN;
  if (fa == 0)
    return a;
  if (fb == 0)
    return b;
  if ((fa > 0) == (fb > 0))
    return NaN;
  double c = a, fc = fa, d = b - a, e = d;
  for (int it = 0; it < maxit; it++) {
    if ((fb > 0) == (fc > 0)) {
      c = a;
      fc = fa;
      d = e = b - a;
    }
    if (std::fabs(fc) < std::fabs(fb)) {
      a = b;
      b = c;
      c = a;
      fa = fb;
      fb = fc;
      fc = fa;
    }
    double tol1 = 2.0 * 2.2e-16 * std::fabs(b) + 0.5 * xtol;
    double xm = 0.5 * (c - b);
    if (std::fabs(xm) <= tol1 || fb == 0)
      return b;
    if (std::fabs(e) >= tol1 && std::fabs(fa) > std::fabs(fb)) {
      double s = fb / fa, p, q;
      if (a == c) {
        p = 2.0 * xm * s;
        q = 1.0 - s;
      } else {
        double qq = fa / fc, r = fb / fc;
        p = s * (2.0 * xm * qq * (qq - r) - (b - a) * (r - 1.0));
        q = (qq - 1.0) * (r - 1.0) * (s - 1.0);
      }
      if (p > 0)
        q = -q;
      p = std::fabs(p);
      double min1 = 3.0 * xm * q - std::fabs(tol1 * q), min2 = std::fabs(e * q);
      if (2.0 * p < std::min(min1, min2)) {
        e = d;
        d = p / q;
      } else {
        d = xm;
        e = d;
      }
    } else {
      d = xm;
      e = d;
    }
    a = b;
    fa = fb;
    b += std::fabs(d) > tol1 ? d : (xm > 0 ? tol1 : -tol1);
    fb = f(b);
    if (std::isnan(fb))
      return NaN;
  }
  return b;
}

void tridiag_eig(std::vector<double> d, std::vector<double> e, std::vector<double> &vals,
                 std::vector<std::vector<double>> *vecs) {
  size_t n = d.size();
  e.resize(n, 0.0);
  // vecs: nullptr = values only; size 1 on entry = first row only; else the full matrix.
  bool firstOnly = vecs && vecs->size() == 1;
  std::vector<std::vector<double>> z;
  if (vecs) {
    if (firstOnly) {
      z.assign(1, std::vector<double>(n, 0.0));
      if (n)
        z[0][0] = 1.0;
    } else {
      z.assign(n, std::vector<double>(n, 0.0));
      for (size_t i = 0; i < n; i++)
        z[i][i] = 1.0;
    }
  }
  for (size_t l = 0; l < n; l++) {
    int iter = 0;
    size_t m;
    do {
      for (m = l; m + 1 < n; m++) {
        double dd = std::fabs(d[m]) + std::fabs(d[m + 1]);
        if (std::fabs(e[m]) <= 2.2e-16 * dd)
          break;
      }
      if (m != l) {
        if (iter++ == 60)
          break;
        double g = (d[l + 1] - d[l]) / (2.0 * e[l]);
        double r = std::hypot(g, 1.0);
        g = d[m] - d[l] + e[l] / (g + (g >= 0 ? std::fabs(r) : -std::fabs(r)));
        double s = 1.0, c = 1.0, p = 0.0;
        bool early = false;
        for (size_t ii = m; ii-- > l;) {
          double f = s * e[ii], b = c * e[ii];
          r = std::hypot(f, g);
          e[ii + 1] = r;
          if (r == 0.0) {
            d[ii + 1] -= p;
            e[m] = 0.0;
            early = true;
            break;
          }
          s = f / r;
          c = g / r;
          g = d[ii + 1] - p;
          r = (d[ii] - g) * s + 2.0 * c * b;
          p = s * r;
          d[ii + 1] = g + p;
          g = c * r - b;
          for (auto &row : z) {
            double fz = row[ii + 1];
            row[ii + 1] = s * row[ii] + c * fz;
            row[ii] = c * row[ii] - s * fz;
          }
        }
        if (early)
          continue;
        d[l] -= p;
        e[l] = g;
        e[m] = 0.0;
      }
    } while (m != l);
  }
  std::vector<size_t> idx(n);
  for (size_t i = 0; i < n; i++)
    idx[i] = i;
  std::sort(idx.begin(), idx.end(), [&](size_t x, size_t y) { return d[x] < d[y]; });
  vals.resize(n);
  for (size_t i = 0; i < n; i++)
    vals[i] = d[idx[i]];
  if (vecs) {
    vecs->assign(z.size(), std::vector<double>(n));
    for (size_t r = 0; r < z.size(); r++)
      for (size_t i = 0; i < n; i++)
        (*vecs)[r][i] = z[r][idx[i]];
  }
}

std::vector<double> zeros_of(const std::function<double(double)> &f, int nt, double start, double step) {
  std::vector<double> out;
  double a = start, fa = f(a);
  int guard = 0;
  while (static_cast<int>(out.size()) < nt && guard++ < 1000000) {
    double b = a + step, fb = f(b);
    if (fa == 0.0) {
      out.push_back(a);
    } else if ((fa < 0) != (fb < 0) && !std::isnan(fa) && !std::isnan(fb)) {
      out.push_back(brent(f, a, b, 1e-15));
    }
    a = b;
    fa = fb;
  }
  return out;
}

} // namespace sf
} // namespace scipy
} // namespace nc
