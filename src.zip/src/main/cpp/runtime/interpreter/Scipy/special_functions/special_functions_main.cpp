// Section 20 of 25 - Special Functions
// SciPy module: scipy.special
// Planned entries: 359
//
// This file is the ONE place where this section's entries are mapped to NC
// names. Nothing outside this folder needs to change when you add one.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        special_functions/sf_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerSpecialFunctions() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Scipy/scipy_sources.cmake globs the whole Scipy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 25 sections.
//   - A name already used by an NC builtin (ops/), by a NumPy function
//     (Numpy/), by an NC keyword or a parser-reserved call is skipped: the
//     existing one stays. The reason is printed at startup.
#include "special_functions_main.h"

namespace nc {
namespace scipy {

void registerSfBasic(Registry &reg);
void registerSfBessel(Registry &reg);
void registerSfPoly(Registry &reg);

// The section is split by family: sf_reg_basic.cpp (gamma, erf, elementary,
// elliptic, hypergeometric, cdflib), sf_reg_bessel.cpp (Bessel, Airy, Struve,
// Kelvin, zeros, integrals), sf_reg_poly.cpp (orthogonal polynomials,
// Legendre, Mathieu, spheroidal, ellipsoidal, parabolic cylinder). The scalar
// kernels are in sf_*.cpp, declared in sf_core.h and sf_poly.h.
void registerSpecialFunctions(Registry &reg) {
  registerSfBasic(reg);
  registerSfBessel(reg);
  registerSfPoly(reg);
  reg.setParallel(reg.names(Section::SpecialFunctions), ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
