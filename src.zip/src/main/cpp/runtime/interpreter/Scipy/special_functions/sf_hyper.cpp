// Hypergeometric functions 0F1, 1F1, U and 2F1, the parabolic cylinder
// functions D, V and W, and Wright's generalized Bessel function.
#include "sf_core.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {
const double kEps = 2.220446049250313e-16;

bool nonPosInt(double x) { return x <= 0 && x == std::floor(x); }

// Kummer series M(a, b, x), summed until the terms are negligible.
double m1Series(double a, double b, double x, int maxit = 100000) {
  double term = 1.0, sum = 1.0;
  for (int k = 0; k < maxit; k++) {
    if (a + k == 0)
      break;
    term *= (a + k) / (b + k) * x / (k + 1);
    sum += term;
    if (std::fabs(term) < kEps * std::fabs(sum) && k > std::fabs(x))
      break;
    if (!std::isfinite(sum))
      break;
  }
  return sum;
}

template <class T> T f21Series(double a, double b, double c, T z, int maxit = 2000000) {
  T term = 1.0, sum = 1.0;
  for (int k = 0; k < maxit; k++) {
    if (a + k == 0 || b + k == 0)
      break;
    term *= (a + k) * (b + k) / ((c + k) * (k + 1.0)) * z;
    sum += term;
    if (std::abs(term) < kEps * std::abs(sum) && k > 5)
      break;
  }
  return sum;
}
} // namespace

double hyp0f1(double b, double z) {
  if (std::isnan(b) || std::isnan(z))
    return NaN;
  if (nonPosInt(b))
    return NaN;
  if (z == 0)
    return 1.0;
  if (std::fabs(z) < 10 || std::fabs(z) < std::fabs(b)) {
    double term = 1.0, sum = 1.0;
    for (int k = 0; k < 10000; k++) {
      term *= z / ((b + k) * (k + 1.0));
      sum += term;
      if (std::fabs(term) < kEps * std::fabs(sum))
        break;
    }
    return sum;
  }
  double r = std::sqrt(std::fabs(z));
  double lg = std::lgamma(b) + (1 - b) * std::log(r);
  double sg = gammasgn(b);
  if (z > 0) {
    double i = besseli(b - 1, 2 * r, true);
    return sg * std::exp(lg + 2 * r) * i;
  }
  return sg * std::exp(lg) * besselj(b - 1, 2 * r);
}

cd hyp0f1(double b, cd z) {
  if (z.imag() == 0.0)
    return cd(hyp0f1(b, z.real()), 0.0);
  if (nonPosInt(b))
    return cd(NaN, NaN);
  if (std::abs(z) < 20) {
    cd term = 1.0, sum = 1.0;
    for (int k = 0; k < 10000; k++) {
      term *= z / ((b + k) * (k + 1.0));
      sum += term;
      if (std::abs(term) < kEps * std::abs(sum))
        break;
    }
    return sum;
  }
  cd r = std::sqrt(z);
  return gamma(b) * std::pow(r, 1.0 - b) * besseli(b - 1, 2.0 * r);
}

double hyp1f1(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x))
    return NaN;
  if (nonPosInt(b)) {
    if (nonPosInt(a) && a > b)
      return m1Series(a, b, x);
    return Inf;
  }
  if (a == 0 || x == 0)
    return 1.0;
  if (a == b)
    return std::exp(x);
  if (nonPosInt(a))
    return m1Series(a, b, x);
  if (x < 0) {
    // Kummer transformation keeps the series positive.
    double t = m1Series(b - a, b, -x);
    return std::exp(x) * t;
  }
  if (x > 60 && x > 2 * std::fabs(b) && x > 2 * std::fabs(a)) {
    // Large x: leading exponential term of the asymptotic expansion.
    double s = 1.0, term = 1.0, last = Inf;
    for (int k = 0; k < 200; k++) {
      term *= (b - a + k) * (1 - a + k) / ((k + 1.0) * x);
      if (std::fabs(term) > last)
        break;
      last = std::fabs(term);
      s += term;
      if (std::fabs(term) < kEps * std::fabs(s))
        break;
    }
    double l = std::lgamma(b) - std::lgamma(a) + x + (a - b) * std::log(x);
    return gammasgn(b) * gammasgn(a) * std::exp(l) * s;
  }
  return m1Series(a, b, x);
}

double hyperu(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || x < 0)
    return NaN;
  if (x == 0) {
    if (b > 1)
      return Inf;
    if (b < 1 && !nonPosInt(a))
      return std::tgamma(1 - b) / std::tgamma(a - b + 1);
    return NaN;
  }
  if (a == 0)
    return 1.0;
  if (nonPosInt(a)) {
    // Polynomial: U(-n, b, x) = (-1)^n sum_k C(n,k) (-1)^k (b+k)_(n-k) x^k
    int n = static_cast<int>(-a);
    double sum = 0.0;
    for (int k = 0; k <= n; k++) {
      double lc = std::lgamma(n + 1.0) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1.0);
      sum += ((k % 2) ? -1.0 : 1.0) * std::exp(lc) * poch(b + k, n - k) * std::pow(x, k);
    }
    return ((n % 2) ? -1.0 : 1.0) * sum;
  }
  auto integral = [&](double aa, double bb) {
    // U(a,b,x) = 1/Gamma(a) int_0^inf e^{-x t} t^{a-1} (1+t)^{b-a-1} dt, t = s^{1/a}
    double p = 1.0 / aa;
    auto f = [&](double s) {
      if (s == 0)
        return 0.0;
      double t = std::pow(s, p);
      return std::exp(-x * t + (bb - aa - 1) * std::log1p(t));
    };
    double I = quad(f, 0.0, Inf, 0.0, 1e-13, 4000);
    return p * I / std::tgamma(aa);
  };
  if (a > 0 && a < 150)
    return integral(a, b);
  double a2 = a - b + 1;
  if (a2 > 0 && a2 < 150)
    return std::pow(x, 1 - b) * integral(a2, 2 - b);
  return NaN;
}

double hyp2f1(double a, double b, double c, double z) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(c) || std::isnan(z))
    return NaN;
  bool polyA = nonPosInt(a), polyB = nonPosInt(b);
  if (nonPosInt(c)) {
    bool ok = (polyA && a > c) || (polyB && b > c);
    if (!ok)
      return Inf;
  }
  if (z == 0 || a == 0 || b == 0)
    return 1.0;
  if (polyA || polyB)
    return f21Series(a, b, c, z);
  if (z > 1)
    return NaN;
  if (z == 1) {
    double s = c - a - b;
    if (s <= 0)
      return Inf;
    return std::exp(std::lgamma(c) + std::lgamma(s) - std::lgamma(c - a) - std::lgamma(c - b)) * gammasgn(c) *
           gammasgn(s) * gammasgn(c - a) * gammasgn(c - b);
  }
  if (z < -1) {
    // Pfaff: (1-z)^-a F(a, c-b; c; z/(z-1)), the new argument lies in (1/2, 1).
    double w = z / (z - 1);
    return std::pow(1 - z, -a) * hyp2f1(a, c - b, c, w);
  }
  if (z < 0) {
    if (z > -0.5)
      return f21Series(a, b, c, z);
    double w = z / (z - 1);
    return std::pow(1 - z, -a) * hyp2f1(a, c - b, c, w);
  }
  if (z <= 0.9)
    return f21Series(a, b, c, z);
  double s = c - a - b;
  if (std::fabs(s - std::round(s)) > 1e-8) {
    double t1 = gamma(c) * gamma(s) * rgamma(c - a) * rgamma(c - b);
    double t2 = gamma(c) * gamma(-s) * rgamma(a) * rgamma(b);
    return t1 * f21Series(a, b, 1 - s, 1 - z) + std::pow(1 - z, s) * t2 * f21Series(c - a, c - b, s + 1, 1 - z);
  }
  // c - a - b integer: Euler transform when it helps, else the slow series.
  if (s > 0)
    return f21Series(a, b, c, z, 50000000);
  return std::pow(1 - z, s) * f21Series(c - a, c - b, c, z, 50000000);
}

cd hyp2f1(double a, double b, double c, cd z) {
  if (z.imag() == 0.0 && z.real() <= 1)
    return cd(hyp2f1(a, b, c, z.real()), 0.0);
  if (nonPosInt(c) && !((nonPosInt(a) && a > c) || (nonPosInt(b) && b > c)))
    return cd(Inf, 0.0);
  if (nonPosInt(a) || nonPosInt(b))
    return f21Series(a, b, c, z);
  double r0 = std::abs(z), r1 = std::abs(z / (z - 1.0)), r2 = std::abs(1.0 - z), r3 = std::abs(1.0 / z);
  double s = c - a - b;
  bool sInt = std::fabs(s - std::round(s)) < 1e-8, abInt = std::fabs((a - b) - std::round(a - b)) < 1e-8;
  if (r0 <= 0.9)
    return f21Series(a, b, c, z);
  if (r1 <= 0.9)
    return std::pow(1.0 - z, -a) * f21Series(a, c - b, c, z / (z - 1.0));
  if (r2 <= 0.9 && !sInt) {
    double t1 = gamma(c) * gamma(s) * rgamma(c - a) * rgamma(c - b);
    double t2 = gamma(c) * gamma(-s) * rgamma(a) * rgamma(b);
    return t1 * f21Series(a, b, 1 - s, 1.0 - z) + std::pow(1.0 - z, s) * t2 * f21Series(c - a, c - b, s + 1, 1.0 - z);
  }
  if (r3 <= 0.9 && !abInt) {
    double t1 = gamma(c) * gamma(b - a) * rgamma(b) * rgamma(c - a);
    double t2 = gamma(c) * gamma(a - b) * rgamma(a) * rgamma(c - b);
    return t1 * std::pow(-z, -a) * f21Series(a, a - c + 1, a - b + 1, 1.0 / z) +
           t2 * std::pow(-z, -b) * f21Series(b, b - c + 1, b - a + 1, 1.0 / z);
  }
  return f21Series(a, b, c, z, 50000000);
}

// ---- parabolic cylinder functions ----

namespace {
// U(a,x) and V(a,x) with derivatives, from their power series (DLMF 12.4, 12.7).
void uvSeries(double a, double x, double &U, double &Up, double &V, double &Vp) {
  double z = x * x / 2, e = std::exp(-x * x / 4);
  double al = a / 2 + 0.25, be = a / 2 + 0.75;
  double M1 = m1Series(al, 0.5, z), M1d = al / 0.5 * m1Series(al + 1, 1.5, z);
  double M2 = m1Series(be, 1.5, z), M2d = be / 1.5 * m1Series(be + 1, 2.5, z);
  double u1 = e * M1, u1p = -x / 2 * u1 + e * M1d * x;
  double u2 = x * e * M2, u2p = e * M2 * (1 - x * x / 2) + x * e * M2d * x;
  double s = 0.25 + a / 2, t = 0.75 + a / 2;
  double U0 = SQRTPI / std::pow(2.0, a / 2 + 0.25) * rgamma(0.75 + a / 2);
  double U0p = -SQRTPI / std::pow(2.0, a / 2 - 0.25) * rgamma(0.25 + a / 2);
  double V0 = std::pow(2.0, s) * std::sin(PI * s) * rgamma(1 - s);
  double V0p = std::pow(2.0, t) * std::sin(PI * t) * rgamma(1 - t);
  U = U0 * u1 + U0p * u2;
  Up = U0 * u1p + U0p * u2p;
  V = V0 * u1 + V0p * u2;
  Vp = V0 * u1p + V0p * u2p;
}

// D_v(x) for x > 0, v < 0: e^{-x^2/4}/Gamma(-v) int_0^inf t^{-v-1} e^{-x t - t^2/2} dt.
double dvIntegral(double v, double x) {
  double p = -1.0 / v; // t = s^p removes the t^{-v-1} singularity
  auto f = [&](double s) {
    if (s == 0)
      return 0.0;
    double t = std::pow(s, p);
    return std::exp(-x * t - t * t / 2);
  };
  return std::exp(-x * x / 4) * p * quad(f, 0.0, Inf, 0.0, 1e-14, 4000) / std::tgamma(-v);
}

double dvAsym(double v, double x) {
  double sum = 1.0, term = 1.0, last = Inf;
  for (int k = 1; k < 100; k++) {
    term *= -(v - 2 * k + 2) * (v - 2 * k + 1) / (2.0 * k * x * x);
    if (std::fabs(term) > last)
      break;
    last = std::fabs(term);
    sum += term;
    if (std::fabs(term) < kEps * std::fabs(sum))
      break;
  }
  return std::exp(v * std::log(x) - x * x / 4) * sum;
}

double dv(double v, double x) {
  if (v >= 0 && v == std::floor(v) && v < 200) {
    // D_n(x) = e^{-x^2/4} He_n(x)
    int n = static_cast<int>(v);
    double h0 = 1.0, h1 = x;
    if (n == 0)
      h1 = h0;
    for (int k = 1; k < n; k++) {
      double h2 = x * h1 - k * h0;
      h0 = h1;
      h1 = h2;
    }
    return std::exp(-x * x / 4) * (n == 0 ? 1.0 : h1);
  }
  if (x > 0 && v < 0 && x > 1)
    return dvIntegral(v, x);
  if (x > 8 && x * x > 8 * std::fabs(v) + 40)
    return dvAsym(v, x);
  double U, Up, V, Vp;
  uvSeries(-v - 0.5, x, U, Up, V, Vp);
  return U;
}
} // namespace

void pbdv(double v, double x, double &d, double &dp) {
  if (std::isnan(v) || std::isnan(x)) {
    d = dp = NaN;
    return;
  }
  d = dv(v, x);
  // D_v'(x) = x/2 D_v(x) - D_{v+1}(x)
  dp = x / 2 * d - dv(v + 1, x);
}

void pbvv(double v, double x, double &vv, double &vp) {
  if (std::isnan(v) || std::isnan(x)) {
    vv = vp = NaN;
    return;
  }
  double U, Up;
  uvSeries(-v - 0.5, x, U, Up, vv, vp);
}

void pbwa(double a, double x, double &w, double &wp) {
  if (std::isnan(a) || std::isnan(x)) {
    w = wp = NaN;
    return;
  }
  double ax = std::fabs(x);
  // w'' + (x^2/4 - a) w = 0 as sum c_k x^k / k!, with c_{k+2} = a c_k - k(k-1)/4 c_{k-2}.
  auto series = [&](double c0, double c1, double &val, double &der) {
    std::vector<double> c = {c0, c1};
    val = der = 0.0;
    double p = 1.0; // ax^k / k!
    for (int k = 0; k < 3000; k++) {
      while (static_cast<int>(c.size()) <= k + 1) {
        int m = static_cast<int>(c.size());
        c.push_back(a * c[m - 2] - (m >= 4 ? (m - 2) * (m - 3) / 4.0 * c[m - 4] : 0.0));
      }
      double tv = c[k] * p, td = c[k + 1] * p;
      val += tv;
      der += td;
      if (k > 30 && std::fabs(tv) + std::fabs(td) < 1e-17 * (std::fabs(val) + std::fabs(der)))
        break;
      p *= ax / (k + 1);
    }
  };
  double w1, w1p, w2, w2p;
  series(1.0, 0.0, w1, w1p);
  series(0.0, 1.0, w2, w2p);
  double g1 = std::abs(std::exp(loggamma(cd(0.25, a / 2)))), g3 = std::abs(std::exp(loggamma(cd(0.75, a / 2))));
  double k1 = std::sqrt(g1 / g3), k2 = std::sqrt(2 * g3 / g1), f = std::pow(2.0, -0.75);
  double s = x >= 0 ? 1.0 : -1.0;
  w = f * (k1 * w1 - s * k2 * w2);
  // d/dx of W(a, s|x|): s * d/d|x|
  wp = s * f * (k1 * w1p - s * k2 * w2p);
}

// ---- Wright's generalized Bessel function ----

double wright_bessel(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || a < 0 || b < 0 || x < 0)
    return NaN;
  if (x == 0)
    return rgamma(b);
  double sum = 0.0;
  for (int k = 0; k < 100000; k++) {
    double g = a * k + b;
    double t;
    if (nonPosInt(g))
      t = 0.0;
    else
      t = std::exp(k * std::log(x) - std::lgamma(k + 1.0) - std::lgamma(g)) * gammasgn(g);
    sum += t;
    if (k > x && std::fabs(t) < kEps * std::fabs(sum))
      break;
    if (!std::isfinite(sum))
      return Inf;
  }
  return sum;
}

double log_wright_bessel(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || a < 0 || b < 0 || x < 0)
    return NaN;
  if (x == 0)
    return -std::lgamma(b);
  // log-sum-exp over the (positive) terms
  std::vector<double> lt;
  double mx = -Inf;
  for (int k = 0; k < 200000; k++) {
    double g = a * k + b;
    if (nonPosInt(g))
      continue;
    double l = k * std::log(x) - std::lgamma(k + 1.0) - std::lgamma(g);
    lt.push_back(l);
    if (l > mx)
      mx = l;
    if (k > 10 && l < mx - 40 && k > x)
      break;
  }
  double s = 0.0;
  for (double l : lt)
    s += std::exp(l - mx);
  return mx + std::log(s);
}

} // namespace sf
} // namespace scipy
} // namespace nc
