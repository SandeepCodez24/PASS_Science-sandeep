// Gamma, beta, zeta and the incomplete gamma and beta functions.
#include "sf_core.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {

const double kEps = 2.220446049250313e-16;

// Lanczos g = 7, n = 9: Gamma(z+1) = sqrt(2 pi) t^(z+1/2) e^-t A(z), t = z + 7.5.
const double kLg = 7.0;
const double kLp[9] = {0.99999999999980993,  676.5203681218851,     -1259.1392167224028,
                       771.32342877765313,   -176.61502916214059,   12.507343278686905,
                       -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7};

double lanczosA(double z) {
  double s = kLp[0];
  for (int k = 1; k < 9; k++)
    s += kLp[k] / (z + k);
  return s;
}

double log1pmx(double t) {
  if (std::fabs(t) < 0.5) {
    double sum = 0.0, p = t;
    for (int k = 2; k < 200; k++) {
      p *= -t;
      double term = p / k;
      sum += term;
      if (std::fabs(term) < kEps * std::fabs(sum))
        break;
    }
    return sum;
  }
  return std::log1p(t) - t;
}

// x^a e^-x / Gamma(a), computed without the cancellation of a log x - x - lgamma(a).
double igamFac(double a, double x) {
  if (std::fabs(a - x) > 0.4 * std::fabs(a) || a < 10.0) {
    double ax = a * std::log(x) - x - std::lgamma(a);
    if (ax < -745.0)
      return 0.0;
    return std::exp(ax);
  }
  double fac = a + kLg - 0.5;
  double num = x - fac;
  double res = std::sqrt(fac) / (std::sqrt(2.0 * PI) * lanczosA(a - 1.0));
  return res * std::exp(a * log1pmx(num / fac) - num * (kLg - 0.5) / fac);
}

// lgamma(1 + a), accurate for small a.
double lgam1p(double a) {
  if (std::fabs(a) <= 0.2) {
    double sum = -EULER * a, p = a;
    for (int k = 2; k < 60; k++) {
      p *= -a;
      double term = riemann_zeta(k) * p / k;
      sum += term;
      if (std::fabs(term) < kEps * std::fabs(sum))
        break;
    }
    return sum;
  }
  return std::lgamma(1.0 + a);
}

double igamSeries(double a, double x) {
  double fac = igamFac(a, x);
  if (fac == 0.0)
    return 0.0;
  double r = a, c = 1.0, ans = 1.0;
  for (int i = 0; i < 200000; i++) {
    r += 1.0;
    c *= x / r;
    ans += c;
    if (c <= kEps * ans)
      break;
  }
  return ans * fac / a;
}

double igamcSeries(double a, double x) {
  double fac = 1.0, sum = 0.0;
  for (int n = 1; n < 2000; n++) {
    fac *= -x / n;
    double term = fac / (a + n);
    sum += term;
    if (std::fabs(term) <= kEps * std::fabs(sum))
      break;
  }
  double logx = std::log(x);
  double term = -std::expm1(a * logx - lgam1p(a));
  return term - std::exp(a * logx - std::lgamma(a)) * sum;
}

double igamcCf(double a, double x) {
  double fac = igamFac(a, x);
  if (fac == 0.0)
    return 0.0;
  const double tiny = 1e-300;
  double b = x + 1.0 - a, c = 1.0 / tiny, d = 1.0 / b, h = d;
  for (int i = 1; i < 200000; i++) {
    double an = -i * (i - a);
    b += 2.0;
    d = an * d + b;
    if (std::fabs(d) < tiny)
      d = tiny;
    c = b + an / c;
    if (std::fabs(c) < tiny)
      c = tiny;
    d = 1.0 / d;
    double del = d * c;
    h *= del;
    if (std::fabs(del - 1.0) < kEps)
      break;
  }
  return fac * h;
}

// Monotone inversion of F on [lo, hi]: F(x) = target, with derivative dF.
// Newton steps inside the bracket, bisection (geometric when the bracket spans
// decades) otherwise. `increasing` tells the direction of F.
double invertMonotone(const std::function<double(double)> &F, const std::function<double(double)> &dF,
                      double target, double lo, double hi, double x0, bool increasing) {
  double x = std::min(std::max(x0, lo), hi);
  if (!(x > lo && x < hi))
    x = (lo > 0 && hi / lo > 100) ? std::sqrt(lo * hi) : 0.5 * (lo + hi);
  for (int it = 0; it < 400; it++) {
    double f = F(x) - target;
    if (std::isnan(f))
      return NaN;
    if (f == 0.0)
      return x;
    bool below = increasing ? f < 0 : f > 0;
    if (below)
      lo = x;
    else
      hi = x;
    double xn = NaN;
    double d = dF ? dF(x) : NaN;
    if (std::isfinite(d) && d != 0.0)
      xn = x - f / d;
    if (!(xn > lo && xn < hi)) {
      if (lo > 0 && hi / lo > 100)
        xn = std::sqrt(lo * hi);
      else
        xn = 0.5 * (lo + hi);
    }
    if (std::fabs(xn - x) <= 4 * kEps * std::fabs(xn) || hi - lo <= 4 * kEps * std::fabs(hi))
      return xn;
    x = xn;
  }
  return x;
}

} // namespace

double gamma(double x) {
  if (x == 0.0)
    return std::signbit(x) ? -Inf : Inf;
  if (x < 0 && x == std::floor(x))
    return NaN;
  return std::tgamma(x);
}

double lgam(double x) {
  if (x <= 0 && x == std::floor(x))
    return Inf;
  return std::lgamma(x);
}

double gammasgn(double x) {
  if (std::isnan(x))
    return NaN;
  if (x > 0)
    return 1.0;
  if (x == 0)
    return std::signbit(x) ? -1.0 : 1.0;
  if (x == std::floor(x))
    return NaN;
  double f = std::floor(x);
  return (static_cast<long long>(std::fmod(f, 2.0)) == 0) ? 1.0 : -1.0;
}

double rgamma(double x) {
  if (x <= 0 && x == std::floor(x))
    return 0.0;
  if (x > 171.7)
    return std::exp(-std::lgamma(x));
  return 1.0 / std::tgamma(x);
}

cd loggamma(cd z) {
  if (z.imag() == 0.0 && z.real() > 0.0)
    return cd(std::lgamma(z.real()), 0.0);
  if (z.imag() == 0.0 && z.real() <= 0 && z.real() == std::floor(z.real()))
    return cd(NaN, NaN);
  if (z.real() < -1000.0)
    return cd(NaN, NaN);
  cd shift(0.0, 0.0);
  while (z.real() < 10.0 && std::abs(z) < 30.0) {
    shift += std::log(z);
    z += 1.0;
  }
  static const double B[] = {1.0 / 6, -1.0 / 30, 1.0 / 42, -1.0 / 30, 5.0 / 66, -691.0 / 2730, 7.0 / 6,
                             -3617.0 / 510};
  cd r = (z - 0.5) * std::log(z) - z + LOG_SQRT_2PI;
  cd zp = z, z2 = z * z;
  for (int k = 1; k <= 8; k++) {
    r += B[k - 1] / ((2.0 * k) * (2.0 * k - 1.0) * zp);
    zp *= z2;
  }
  return r - shift;
}

cd gamma(cd z) {
  if (z.imag() == 0.0)
    return cd(gamma(z.real()), 0.0);
  if (z.real() < 0.5)
    return PI / (std::sin(PI * z) * gamma(1.0 - z));
  return std::exp(loggamma(z));
}

double digamma(double x) {
  if (std::isnan(x))
    return NaN;
  if (x == 0.0)
    return std::signbit(x) ? Inf : -Inf;
  if (x < 0) {
    if (x == std::floor(x))
      return NaN;
    double r = x - std::floor(x);
    return digamma(1.0 - x) - PI / std::tan(PI * r);
  }
  double res = 0.0;
  while (x < 10.0) {
    res -= 1.0 / x;
    x += 1.0;
  }
  static const double B[] = {1.0 / 6, -1.0 / 30, 1.0 / 42, -1.0 / 30, 5.0 / 66, -691.0 / 2730, 7.0 / 6};
  double x2 = 1.0 / (x * x), p = x2, s = 0.0;
  for (int k = 1; k <= 7; k++) {
    s += B[k - 1] / (2.0 * k) * p;
    p *= x2;
  }
  return res + std::log(x) - 0.5 / x - s;
}

cd digamma(cd z) {
  if (z.imag() == 0.0)
    return cd(digamma(z.real()), 0.0);
  cd res = 0.0;
  if (z.real() < 0.5) {
    res = -PI / std::tan(PI * z);
    z = 1.0 - z;
  }
  while (std::abs(z) < 15.0) {
    res -= 1.0 / z;
    z += 1.0;
  }
  static const double B[] = {1.0 / 6, -1.0 / 30, 1.0 / 42, -1.0 / 30, 5.0 / 66, -691.0 / 2730, 7.0 / 6};
  cd x2 = 1.0 / (z * z), p = x2, s = 0.0;
  for (int k = 1; k <= 7; k++) {
    s += B[k - 1] / (2.0 * k) * p;
    p *= x2;
  }
  return res + std::log(z) - 0.5 / z - s;
}

namespace {
double hurwitzEM(double x, double q);
}

double zeta(double x, double q) {
  if (std::isnan(x) || std::isnan(q))
    return NaN;
  if (x == 1.0)
    return Inf;
  if (x < 1.0)
    return NaN;
  return hurwitzEM(x, q);
}

namespace {
// Euler-Maclaurin summation; valid for any x != 1 when q > 0.
double hurwitzEM(double x, double q) {
  if (q <= 0.0) {
    if (q == std::floor(q))
      return Inf;
    if (x != std::floor(x))
      return NaN;
    // Integer s: move q above zero, adding the terms passed over.
    double add = 0.0;
    while (q <= 0.0) {
      add += std::pow(q, -x);
      q += 1.0;
    }
    return add + zeta(x, q);
  }
  if (q > 1e8)
    return (1.0 / (x - 1.0) + 1.0 / (2.0 * q)) * std::pow(q, 1.0 - x);
  static const double A[] = {12.0,
                             -720.0,
                             30240.0,
                             -1209600.0,
                             47900160.0,
                             -1.8924375803183791606e9,
                             7.47242496e10,
                             -2.950130727918164224e12,
                             1.1646782814350067249e14,
                             -4.5979787224074726105e15,
                             1.8152105401943546773e17,
                             -7.1661652561756670113e18};
  double s = std::pow(q, -x), a = q, b = 0.0;
  int i = 0;
  while (i < 9 || a <= 9.0) {
    i++;
    a += 1.0;
    b = std::pow(a, -x);
    s += b;
    if (std::fabs(b / s) < kEps)
      return s;
  }
  double w = a;
  s += b * w / (x - 1.0);
  s -= 0.5 * b;
  a = 1.0;
  double k = 0.0;
  for (i = 0; i < 12; i++) {
    a *= x + k;
    b /= w;
    double t = a * b / A[i];
    s += t;
    if (std::fabs(t / s) < kEps)
      break;
    k += 1.0;
    a *= x + k;
    b /= w;
    k += 1.0;
  }
  return s;
}
} // namespace

double riemann_zeta(double s) {
  if (std::isnan(s))
    return NaN;
  if (s == 1.0)
    return Inf;
  if (s > 1.0)
    return s > 60 ? 1.0 + std::pow(2.0, -s) + std::pow(3.0, -s) : zeta(s, 1.0);
  if (s == 0.0)
    return -0.5;
  if (s > 0.0)
    return hurwitzEM(s, 1.0);
  if (s < 0 && std::fmod(s, 2.0) == 0.0)
    return 0.0;
  // Functional equation.
  double t = 1.0 - s;
  if (t > 171.0)
    return (std::sin(PI * s / 2.0) > 0 ? 1 : -1) * Inf;
  return std::pow(2.0, s) * std::pow(PI, s - 1.0) * std::sin(PI * s / 2.0) * std::tgamma(t) *
         riemann_zeta(t);
}

double zetac(double s) {
  if (std::isnan(s))
    return NaN;
  if (s > 1.0)
    return s > 127 ? std::pow(2.0, -s) : zeta(s, 2.0);
  if (s == 1.0)
    return Inf;
  return riemann_zeta(s) - 1.0;
}

double polygamma(int n, double x) {
  if (n < 0)
    return NaN;
  if (n == 0)
    return digamma(x);
  double f = std::exp(std::lgamma(n + 1.0)) * zeta(n + 1.0, x);
  return (n % 2 == 1) ? f : -f;
}

double lbeta(double a, double b) {
  if (std::fabs(a) < std::fabs(b))
    std::swap(a, b);
  if (b <= 0 && b == std::floor(b))
    return Inf;
  if (a > 1e6 * std::fabs(b) && a > 1e6) {
    double r = std::lgamma(b) - b * std::log(a);
    r += b * (1 - b) / (2 * a);
    r += b * (1 - b) * (1 - 2 * b) / (12 * a * a);
    r += -b * b * (1 - b) * (1 - b) / (12 * a * a * a);
    return r;
  }
  return std::lgamma(a) + std::lgamma(b) - std::lgamma(a + b);
}

double beta(double a, double b) {
  if (std::isnan(a) || std::isnan(b))
    return NaN;
  if ((a <= 0 && a == std::floor(a)) || (b <= 0 && b == std::floor(b))) {
    // Integer poles can cancel against Gamma(a + b).
    double s = a + b;
    if (s <= 0 && s == std::floor(s)) {
      if (a == std::floor(a) && b == std::floor(b) && a <= 0 && b <= 0)
        return Inf;
    }
    return Inf;
  }
  double s = a + b;
  if (std::fabs(a) < 170 && std::fabs(b) < 170 && std::fabs(s) < 170 &&
      !(s <= 0 && s == std::floor(s))) {
    double ga = std::tgamma(a), gb = std::tgamma(b), gs = std::tgamma(s);
    if (std::fabs(ga) > std::fabs(gb))
      return ga / gs * gb;
    return gb / gs * ga;
  }
  if (s <= 0 && s == std::floor(s))
    return 0.0;
  double sign = gammasgn(a) * gammasgn(b) * gammasgn(s);
  return sign * std::exp(lbeta(a, b));
}

double binom(double n, double k) {
  if (std::isnan(n) || std::isnan(k))
    return NaN;
  if (n < 0 && n == std::floor(n))
    return NaN;
  double kx = std::floor(k);
  if (k == kx && (std::fabs(n) > 1e-8 || n == 0)) {
    double nx = std::floor(n);
    if (nx == n && kx > nx / 2 && nx > 0)
      kx = nx - kx;
    if (kx >= 0 && kx < 20) {
      double num = 1.0, den = 1.0;
      for (int i = 1; i < 1 + static_cast<int>(kx); i++) {
        num *= i + n - kx;
        den *= i;
        if (std::fabs(num) > 1e50) {
          num /= den;
          den = 1.0;
        }
      }
      return num / den;
    }
  }
  if (n >= 1e10 * k && k > 0)
    return std::exp(-lbeta(1 + n - k, 1 + k) - std::log(n + 1));
  if (k > 1e8 * std::fabs(n)) {
    double num = gamma(1 + n) / std::fabs(k) + gamma(1 + n) * n / (2 * k * k);
    num /= PI * std::pow(std::fabs(k), n);
    if (k > 0) {
      kx = std::floor(k);
      double dk = k, sgn = 1.0;
      if (kx == k) {
        dk = k - kx;
        sgn = (std::fmod(kx, 2.0) == 0) ? 1 : -1;
      }
      return num * std::sin((dk - n) * PI) * sgn;
    }
    kx = std::floor(k);
    if (kx == k)
      return 0.0;
    return num * std::sin(k * PI);
  }
  return 1.0 / (n + 1) / beta(1 + n - k, 1 + k);
}

double poch(double z, double m) {
  if (std::isnan(z) || std::isnan(m))
    return NaN;
  if (m == 0.0)
    return 1.0;
  double r = 1.0;
  int guard = 0;
  while (m >= 1.0 && guard++ < 10000) {
    if (z + m - 1 == 0)
      break;
    m -= 1.0;
    r *= z + m;
    if (m == 0.0)
      return r;
  }
  guard = 0;
  while (m <= -1.0 && guard++ < 10000) {
    r /= z + m;
    m += 1.0;
    if (m == 0.0)
      return r;
  }
  double zm = z + m;
  if ((zm <= 0 && zm == std::floor(zm)) && !(z <= 0 && z == std::floor(z)))
    return Inf * r;
  if (z <= 0 && z == std::floor(z) && !(zm <= 0 && zm == std::floor(zm)))
    return 0.0;
  if (std::fabs(z) < 150 && std::fabs(zm) < 150 && !(z <= 0 && z == std::floor(z)))
    return r * std::tgamma(zm) / std::tgamma(z);
  return r * gammasgn(zm) * gammasgn(z) * std::exp(lgam(zm) - lgam(z));
}

double lfactorial(double n) { return std::lgamma(n + 1.0); }

double gammainc(double a, double x) {
  if (std::isnan(a) || std::isnan(x) || x < 0 || a < 0)
    return NaN;
  if (a == 0)
    return x > 0 ? 1.0 : NaN;
  if (x == 0)
    return 0.0;
  if (std::isinf(a))
    return std::isinf(x) ? NaN : 0.0;
  if (std::isinf(x))
    return 1.0;
  if (x > 1.0 && x > a)
    return 1.0 - gammaincc(a, x);
  return igamSeries(a, x);
}

double gammaincc(double a, double x) {
  if (std::isnan(a) || std::isnan(x) || x < 0 || a < 0)
    return NaN;
  if (a == 0)
    return x > 0 ? 0.0 : NaN;
  if (x == 0)
    return 1.0;
  if (std::isinf(a))
    return std::isinf(x) ? NaN : 1.0;
  if (std::isinf(x))
    return 0.0;
  if (x < 1.1) {
    if (x < 0.5) {
      if (-0.4 / std::log(x) < a)
        return 1.0 - igamSeries(a, x);
      return igamcSeries(a, x);
    }
    if (x * 1.1 < a)
      return 1.0 - igamSeries(a, x);
    return igamcSeries(a, x);
  }
  if (x < a)
    return 1.0 - igamSeries(a, x);
  return igamcCf(a, x);
}

namespace {
double gammaGuess(double a, double p, double q) {
  // Wilson-Hilferty, then a small-p power law when that goes negative.
  double z = ndtri(p);
  double t = 1.0 - 1.0 / (9 * a) + z / (3 * std::sqrt(a));
  double x = a * t * t * t;
  double small = std::exp((std::log(p) + std::lgamma(a + 1.0)) / a);
  if (!(x > 0) || (p < 0.05 && small < x))
    x = small;
  if (q < 1e-3 && a < 1) {
    double big = -std::log(q) - std::lgamma(a);
    if (big > x)
      x = big;
  }
  if (!(x > 0) || !std::isfinite(x))
    x = a;
  return x;
}
double gammaDeriv(double a, double x) {
  return std::exp((a - 1) * std::log(x) - x - std::lgamma(a));
}
} // namespace

double gammaincinv(double a, double p) {
  if (std::isnan(a) || std::isnan(p) || a < 0 || p < 0 || p > 1)
    return NaN;
  if (p == 0)
    return 0.0;
  if (p == 1)
    return Inf;
  if (a == 0)
    return p > 0 ? 0.0 : NaN;
  double q = 1.0 - p;
  double x0 = gammaGuess(a, p, q);
  if (p <= 0.9)
    return invertMonotone([&](double x) { return gammainc(a, x); },
                          [&](double x) { return gammaDeriv(a, x); }, p, 0.0, 1e308, x0, true);
  return invertMonotone([&](double x) { return gammaincc(a, x); },
                        [&](double x) { return -gammaDeriv(a, x); }, q, 0.0, 1e308, x0, false);
}

double gammainccinv(double a, double q) {
  if (std::isnan(a) || std::isnan(q) || a < 0 || q < 0 || q > 1)
    return NaN;
  if (q == 1)
    return 0.0;
  if (q == 0)
    return Inf;
  if (a == 0)
    return 0.0;
  double p = 1.0 - q;
  double x0 = gammaGuess(a, p, q);
  if (q < 0.5)
    return invertMonotone([&](double x) { return gammaincc(a, x); },
                          [&](double x) { return -gammaDeriv(a, x); }, q, 0.0, 1e308, x0, false);
  return invertMonotone([&](double x) { return gammainc(a, x); },
                        [&](double x) { return gammaDeriv(a, x); }, p, 0.0, 1e308, x0, true);
}

namespace {
double betacf(double a, double b, double x) {
  const double tiny = 1e-300;
  double qab = a + b, qap = a + 1.0, qam = a - 1.0;
  double c = 1.0, d = 1.0 - qab * x / qap;
  if (std::fabs(d) < tiny)
    d = tiny;
  d = 1.0 / d;
  double h = d;
  for (int m = 1; m < 100000; m++) {
    int m2 = 2 * m;
    double aa = m * (b - m) * x / ((qam + m2) * (a + m2));
    d = 1.0 + aa * d;
    if (std::fabs(d) < tiny)
      d = tiny;
    c = 1.0 + aa / c;
    if (std::fabs(c) < tiny)
      c = tiny;
    d = 1.0 / d;
    h *= d * c;
    aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
    d = 1.0 + aa * d;
    if (std::fabs(d) < tiny)
      d = tiny;
    c = 1.0 + aa / c;
    if (std::fabs(c) < tiny)
      c = tiny;
    d = 1.0 / d;
    double del = d * c;
    h *= del;
    if (std::fabs(del - 1.0) < kEps)
      break;
  }
  return h;
}
// I_x(a, b) via the continued fraction, x below the mean so it converges fast.
double betaincLow(double a, double b, double x) {
  double lfront = a * std::log(x) + b * std::log1p(-x) - lbeta(a, b);
  return std::exp(lfront) * betacf(a, b, x) / a;
}
// Power series for small x (DiDonato & Morris BPSER).
double betaSeries(double a, double b, double x) {
  double sum = 0.0, t = 1.0;
  for (int n = 1; n < 100000; n++) {
    t *= (n - b) * x / n;
    double term = t / (a + n);
    sum += term;
    if (std::fabs(term) < kEps * std::fabs(sum + 1.0 / a))
      break;
  }
  return std::exp(a * std::log(x) - lbeta(a, b)) * (1.0 / a + sum);
}
} // namespace

double betainc(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || a < 0 || b < 0 || x < 0 || x > 1)
    return NaN;
  if (a == 0 && b == 0)
    return NaN;
  if (a == 0)
    return 1.0;
  if (b == 0)
    return 0.0;
  if (std::isinf(a) || std::isinf(b))
    return std::isinf(a) && std::isinf(b) ? NaN : (std::isinf(a) ? 0.0 : 1.0);
  if (x == 0)
    return 0.0;
  if (x == 1)
    return 1.0;
  if (b * x <= 1.0 && x <= 0.5 && a > 0)
    return betaSeries(a, b, x);
  if (x < (a + 1.0) / (a + b + 2.0))
    return betaincLow(a, b, x);
  return 1.0 - betaincc(a, b, x);
}

double betaincc(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || a < 0 || b < 0 || x < 0 || x > 1)
    return NaN;
  if (a == 0 && b == 0)
    return NaN;
  if (a == 0)
    return 0.0;
  if (b == 0)
    return 1.0;
  if (std::isinf(a) || std::isinf(b))
    return std::isinf(a) && std::isinf(b) ? NaN : (std::isinf(a) ? 1.0 : 0.0);
  if (x == 0)
    return 1.0;
  if (x == 1)
    return 0.0;
  double y = 1.0 - x;
  if (a * y <= 1.0 && y <= 0.5)
    return betaSeries(b, a, y);
  if (x >= (a + 1.0) / (a + b + 2.0))
    return betaincLow(b, a, y);
  return 1.0 - betainc(a, b, x);
}

namespace {
double betaDeriv(double a, double b, double x) {
  return std::exp((a - 1) * std::log(x) + (b - 1) * std::log1p(-x) - lbeta(a, b));
}
double betaGuess(double a, double b, double y) {
  double x;
  if (a >= 1 && b >= 1) {
    double z = -ndtri(y);
    double lam = (z * z - 3.0) / 6.0;
    double h = 2.0 / (1.0 / (2 * a - 1) + 1.0 / (2 * b - 1));
    double w = z * std::sqrt(h + lam) / h - (1.0 / (2 * b - 1) - 1.0 / (2 * a - 1)) * (lam + 5.0 / 6 - 2.0 / (3 * h));
    x = a / (a + b * std::exp(2 * w));
  } else {
    double lna = std::log(a / (a + b)), lnb = std::log(b / (a + b));
    double t = std::exp(a * lna) / a, u = std::exp(b * lnb) / b, w = t + u;
    if (y < t / w)
      x = std::pow(a * w * y, 1.0 / a);
    else
      x = 1.0 - std::pow(b * w * (1 - y), 1.0 / b);
  }
  if (!(x > 0 && x < 1))
    x = 0.5;
  return x;
}
} // namespace

double betaincinv(double a, double b, double y) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(y) || a <= 0 || b <= 0 || y < 0 || y > 1)
    return NaN;
  if (y == 0)
    return 0.0;
  if (y == 1)
    return 1.0;
  double x0 = betaGuess(a, b, y);
  if (y <= 0.5)
    return invertMonotone([&](double x) { return betainc(a, b, x); },
                          [&](double x) { return betaDeriv(a, b, x); }, y, 0.0, 1.0, x0, true);
  // Solve in the complement for accuracy near 1.
  double q = 1.0 - y;
  double w = invertMonotone([&](double t) { return betainc(b, a, t); },
                            [&](double t) { return betaDeriv(b, a, t); }, q, 0.0, 1.0, 1.0 - x0, true);
  return 1.0 - w;
}

double betainccinv(double a, double b, double y) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(y) || a <= 0 || b <= 0 || y < 0 || y > 1)
    return NaN;
  if (y == 0)
    return 1.0;
  if (y == 1)
    return 0.0;
  // I_x(a,b) complement = I_{1-x}(b, a).
  double w = betaincinv(b, a, y);
  return 1.0 - w;
}

double multigammaln(double a, int d) {
  double r = d * (d - 1) / 4.0 * std::log(PI);
  for (int j = 1; j <= d; j++)
    r += std::lgamma(a + (1.0 - j) / 2.0);
  return r;
}

} // namespace sf
} // namespace scipy
} // namespace nc
