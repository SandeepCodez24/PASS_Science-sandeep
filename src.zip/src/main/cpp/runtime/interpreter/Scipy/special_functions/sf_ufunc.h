// Element-wise application of scalar kernels to NC values, the way NumPy
// ufuncs work: every argument is a number, an array or a matrix; numbers are
// broadcast; the result has the shape of the array arguments (all of which
// must hold the same number of elements). Used by sections 20 to 23.
#ifndef NC_SCIPY_SF_UFUNC_H
#define NC_SCIPY_SF_UFUNC_H

#include <functional>
#include <string>
#include <vector>

#include "../scipy_core.h"

namespace nc {
namespace scipy {

struct UArg {
  bool scalar = true;
  bool complex = false;
  Vec re;
  CVec cx;
};

struct UShape {
  bool scalar = true;
  size_t r = 1, c = 1, n = 1;
};

// Reads arguments 0..nargs-1 (missing optional ones take defs[i]).
inline bool ureadArgs(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs,
                      std::vector<UArg> &out, UShape &shape) {
  out.assign(nargs, UArg());
  shape = UShape();
  bool haveShape = false;
  for (size_t i = 0; i < nargs; i++) {
    UArg &u = out[i];
    if (i >= a.size()) {
      u.re = {i < defs.size() ? defs[i] : kNaN};
      u.cx = {cd(u.re[0], 0.0)};
      continue;
    }
    const Value &v = a[i];
    if (!readCVec(v, u.cx)) {
      ctx.fail("the " + ordinal(i) + " argument must be a number, an array or a matrix of numbers");
      return false;
    }
    u.re.resize(u.cx.size());
    for (size_t k = 0; k < u.cx.size(); k++) {
      u.re[k] = u.cx[k].real();
      if (u.cx[k].imag() != 0.0)
        u.complex = true;
    }
    u.scalar = isPlainNumber(v);
    if (!u.scalar) {
      size_t r = 1, c = u.cx.size();
      if (v.isMatrix) {
        r = v.rows();
        c = v.cols();
      }
      if (!haveShape) {
        shape.scalar = false;
        shape.r = r;
        shape.c = c;
        shape.n = u.cx.size();
        haveShape = true;
      } else if (u.cx.size() != shape.n) {
        if (shape.n == 1) {
          shape.r = r;
          shape.c = c;
          shape.n = u.cx.size();
        } else if (u.cx.size() != 1) {
          ctx.fail("the array arguments must have the same number of elements");
          return false;
        }
      }
    }
  }
  return true;
}

inline double uget(const UArg &u, size_t k) { return u.re.size() == 1 ? u.re[0] : u.re[k]; }
inline cd ugetc(const UArg &u, size_t k) { return u.cx.size() == 1 ? u.cx[0] : u.cx[k]; }

inline Value ushapeReal(const UShape &s, const Vec &v) {
  if (s.scalar)
    return Value(v[0]);
  Mat m(s.r, s.c);
  m.a = v;
  return toValue(m);
}
inline Value ushapeComplex(const UShape &s, const CVec &v) {
  if (s.scalar)
    return scalarOf(v[0]);
  CMat m(s.r, s.c);
  m.a = v;
  return realIfPossible(m);
}

using RealK = std::function<double(const double *)>;
using CplxK = std::function<cd(const cd *)>;

// Real kernel over all elements.
inline Value umap(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs, const RealK &f) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  for (size_t i = 0; i < nargs; i++)
    if (u[i].complex) {
      ctx.fail("the " + ordinal(i) + " argument must be real");
      return Value(0.0);
    }
  Vec out(s.n);
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<double> x(nargs);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = uget(u[i], k);
      out[k] = f(x.data());
    }
  });
  return ushapeReal(s, out);
}

// Real kernel for real input, complex kernel as soon as any input is complex.
inline Value umapC(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs, const RealK &fr,
                   const CplxK &fc) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  bool anyC = false;
  for (const UArg &x : u)
    anyC = anyC || x.complex;
  if (!anyC)
    return umap(a, ctx, nargs, defs, fr);
  CVec out(s.n);
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<cd> x(nargs);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = ugetc(u[i], k);
      out[k] = fc(x.data());
    }
  });
  return ushapeComplex(s, out);
}

// Complex-valued result from real input (Hankel functions, Lambert W, ...).
inline Value umapToC(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs,
                     const std::function<cd(const cd *)> &f, bool allowComplexIn = true) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  if (!allowComplexIn)
    for (size_t i = 0; i < nargs; i++)
      if (u[i].complex) {
        ctx.fail("the " + ordinal(i) + " argument must be real");
        return Value(0.0);
      }
  CVec out(s.n);
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<cd> x(nargs);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = ugetc(u[i], k);
      out[k] = f(x.data());
    }
  });
  return ushapeComplex(s, out);
}

// Several outputs per element, returned as a Dict of same-shaped values.
inline Value umapDict(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs,
                      const std::vector<std::string> &names, const std::function<void(const cd *, cd *)> &f,
                      bool allowComplexIn) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  if (!allowComplexIn)
    for (size_t i = 0; i < nargs; i++)
      if (u[i].complex) {
        ctx.fail("the " + ordinal(i) + " argument must be real");
        return Value(0.0);
      }
  size_t no = names.size();
  std::vector<CVec> out(no, CVec(s.n));
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<cd> x(nargs), y(no);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = ugetc(u[i], k);
      f(x.data(), y.data());
      for (size_t j = 0; j < no; j++)
        out[j][k] = y[j];
    }
  });
  DictInit d;
  for (size_t j = 0; j < no; j++)
    d.push_back({names[j], ushapeComplex(s, out[j])});
  return makeDict(d);
}

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SF_UFUNC_H
