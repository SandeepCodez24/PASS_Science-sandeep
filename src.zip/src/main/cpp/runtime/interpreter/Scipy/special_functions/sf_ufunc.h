// Element-wise application of scalar kernels to NC values, the way NumPy
// ufuncs work: every argument is a number, an array or a matrix; numbers are
// broadcast; the result has the shape of the array arguments (all of which
// must hold the same number of elements). Used by sections 20 to 23.
#ifndef NC_SCIPY_SF_UFUNC_H
#define NC_SCIPY_SF_UFUNC_H

#include <functional>
#include <string>
#include <vector>

#include "../scipy_core.h"

namespace nc {
namespace scipy {

struct UArg {
  bool scalar = true;
  bool complex = false;
  Vec re;
  CVec cx;
  // A packed real vector read in place (2026-11-20): its buffer already is
  // in row-major order, so `re` stays empty and the numbers are read from
  // here (the argument Value outlives the call).
  const double *view = nullptr;
  size_t viewCount = 0;
  size_t count() const { return view ? viewCount : re.size(); }
};

struct UShape {
  bool scalar = true;
  size_t r = 1, c = 1, n = 1;
};

// Reads arguments 0..nargs-1 (missing optional ones take defs[i]).
inline bool ureadArgs(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs,
                      std::vector<UArg> &out, UShape &shape) {
  out.assign(nargs, UArg());
  shape = UShape();
  bool haveShape = false;
  for (size_t i = 0; i < nargs; i++) {
    UArg &u = out[i];
    if (i >= a.size()) {
      u.re = {i < defs.size() ? defs[i] : kNaN};
      u.cx = {cd(u.re[0], 0.0)};
      continue;
    }
    const Value &v = a[i];
    // A packed real array / matrix: its numbers straight into `re`, with no
    // complex copy (2026-11-20). `cx` stays empty: ugetc() reads `re` then.
    if (v.isPacked() && !v.isND() && (v.isArray || (v.isMatrix && (v.rows() == 1 || v.cols() == 1))) &&
        v.packedSize() > 0) {
      u.view = v.packedData(); // a vector: storage order is row-major order
      u.viewCount = v.packedSize();
      u.cx.clear();
    } else if (v.isPacked() && !v.isND() && (v.isArray || v.isMatrix) && ncpack::readRowMajor(v, u.re)) {
      u.cx.clear();
    } else {
      if (!readCVec(v, u.cx)) {
        ctx.fail("the " + ordinal(i) + " argument must be a number, an array or a matrix of numbers");
        return false;
      }
      u.re.resize(u.cx.size());
      for (size_t k = 0; k < u.cx.size(); k++) {
        u.re[k] = u.cx[k].real();
        if (u.cx[k].imag() != 0.0)
          u.complex = true;
      }
    }
    const size_t count = u.count();
    u.scalar = isPlainNumber(v);
    if (!u.scalar) {
      size_t r = 1, c = count;
      if (v.isMatrix) {
        r = v.rows();
        c = v.cols();
      }
      if (!haveShape) {
        shape.scalar = false;
        shape.r = r;
        shape.c = c;
        shape.n = count;
        haveShape = true;
      } else if (count != shape.n) {
        if (shape.n == 1) {
          shape.r = r;
          shape.c = c;
          shape.n = count;
        } else if (count != 1) {
          ctx.fail("the array arguments must have the same number of elements");
          return false;
        }
      }
    }
  }
  return true;
}

inline double uget(const UArg &u, size_t k) {
  if (u.view)
    return u.viewCount == 1 ? u.view[0] : u.view[k];
  return u.re.size() == 1 ? u.re[0] : u.re[k];
}
// `cx` is empty for an argument read on the real fast path (ureadArgs()).
inline cd ugetc(const UArg &u, size_t k) {
  if (u.cx.empty())
    return cd(uget(u, k), 0.0);
  return u.cx.size() == 1 ? u.cx[0] : u.cx[k];
}

// A vector-shaped result takes `v` over as its buffer (no copy, 2026-11-20).
inline Value ushapeReal(const UShape &s, nc::F64Buf &&v) {
  if (!s.scalar && s.r > 0 && s.c > 0 && v.size() == s.r * s.c && (s.r == 1 || s.c == 1))
    return Value::ndPacked({s.r, s.c}, std::move(v), false);
  if (s.scalar)
    return Value(v[0]);
  if (s.r > 0 && s.c > 0 && v.size() == s.r * s.c) // toValue(Mat) without the Mat copy
    return ncpack::matrixFromRowMajor(v.data(), s.r, s.c);
  Mat m(s.r, s.c);
  m.a.assign(v.begin(), v.end());
  return toValue(m);
}
inline Value ushapeComplex(const UShape &s, const CVec &v) {
  if (s.scalar)
    return scalarOf(v[0]);
  CMat m(s.r, s.c);
  m.a = v;
  return realIfPossible(m);
}

using RealK = std::function<double(const double *)>;
using CplxK = std::function<cd(const cd *)>;

// The real kernel over arguments ureadArgs() already read and checked.
inline Value umapRead(const std::vector<UArg> &u, const UShape &s, size_t nargs, const RealK &f) {
  nc::F64Buf out(s.n); // every element written (the SciPy seam never stops half-way)
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<double> x(nargs);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = uget(u[i], k);
      out[k] = f(x.data());
    }
  });
  return ushapeReal(s, std::move(out));
}

// Real kernel over all elements.
inline Value umap(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs, const RealK &f) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  for (size_t i = 0; i < nargs; i++)
    if (u[i].complex) {
      ctx.fail("the " + ordinal(i) + " argument must be real");
      return Value(0.0);
    }
  return umapRead(u, s, nargs, f);
}

// Real kernel for real input, complex kernel as soon as any input is complex.
inline Value umapC(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs, const RealK &fr,
                   const CplxK &fc) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  bool anyC = false;
  for (const UArg &x : u)
    anyC = anyC || x.complex;
  if (!anyC) // all real: the arguments are read already (2026-11-20: read twice before)
    return umapRead(u, s, nargs, fr);
  CVec out(s.n);
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<cd> x(nargs);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = ugetc(u[i], k);
      out[k] = fc(x.data());
    }
  });
  return ushapeComplex(s, out);
}

// Complex-valued result from real input (Hankel functions, Lambert W, ...).
inline Value umapToC(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs,
                     const std::function<cd(const cd *)> &f, bool allowComplexIn = true) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  if (!allowComplexIn)
    for (size_t i = 0; i < nargs; i++)
      if (u[i].complex) {
        ctx.fail("the " + ordinal(i) + " argument must be real");
        return Value(0.0);
      }
  CVec out(s.n);
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<cd> x(nargs);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = ugetc(u[i], k);
      out[k] = f(x.data());
    }
  });
  return ushapeComplex(s, out);
}

// Several outputs per element, returned as a Dict of same-shaped values.
inline Value umapDict(const Args &a, CallContext &ctx, size_t nargs, const std::vector<double> &defs,
                      const std::vector<std::string> &names, const std::function<void(const cd *, cd *)> &f,
                      bool allowComplexIn) {
  std::vector<UArg> u;
  UShape s;
  if (!ureadArgs(a, ctx, nargs, defs, u, s))
    return Value(0.0);
  if (!allowComplexIn)
    for (size_t i = 0; i < nargs; i++)
      if (u[i].complex) {
        ctx.fail("the " + ordinal(i) + " argument must be real");
        return Value(0.0);
      }
  size_t no = names.size();
  std::vector<CVec> out(no, CVec(s.n));
  par::forBlocks(s.n, {par::Kind::Compute, 2000.0}, [&](size_t b, size_t e) {
    std::vector<cd> x(nargs), y(no);
    for (size_t k = b; k < e; k++) {
      for (size_t i = 0; i < nargs; i++)
        x[i] = ugetc(u[i], k);
      f(x.data(), y.data());
      for (size_t j = 0; j < no; j++)
        out[j][k] = y[j];
    }
  });
  DictInit d;
  for (size_t j = 0; j < no; j++)
    d.push_back({names[j], ushapeComplex(s, out[j])});
  return makeDict(d);
}

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SF_UFUNC_H
