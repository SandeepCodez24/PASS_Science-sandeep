// Mathieu functions (characteristic values and Fourier coefficients from the
// symmetric tridiagonal recurrences, radial functions from Bessel products,
// DLMF 28.24), spheroidal wave functions (Flammer's Legendre and spherical
// Bessel expansions) and ellipsoidal harmonics (Lame functions, Dassios).
#include "sf_poly.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {
// kd: 1 = ce even, 2 = ce odd, 3 = se even, 4 = se odd.
struct Block {
  std::vector<double> vals;
  std::vector<std::vector<double>> vecs; // vecs[component][eigen index]
};
Block mathieuBlock(int kd, double q, int N) {
  std::vector<double> d(N), e(N > 1 ? N - 1 : 0, q);
  for (int k = 0; k < N; k++) {
    double o = (kd == 1) ? 2.0 * k : (kd == 3 ? 2.0 * k + 2 : 2.0 * k + 1);
    d[k] = o * o;
  }
  if (kd == 1 && N > 1)
    e[0] = std::sqrt(2.0) * q;
  if (kd == 2)
    d[0] += q;
  if (kd == 4)
    d[0] -= q;
  Block b;
  tridiag_eig(d, e, b.vals, &b.vecs);
  return b;
}
int blockSize(double m, double q, int extra) { return static_cast<int>(m / 2) + 40 + static_cast<int>(3 * std::sqrt(std::fabs(q))) + extra; }
void classOf(bool even, int m, int &kd, int &idx) {
  if (even) {
    kd = (m % 2 == 0) ? 1 : 2;
    idx = (m % 2 == 0) ? m / 2 : (m - 1) / 2;
  } else {
    kd = (m % 2 == 0) ? 3 : 4;
    idx = (m % 2 == 0) ? m / 2 - 1 : (m - 1) / 2;
  }
}
// orders of the Fourier terms for a block
double orderOf(int kd, int k) { return kd == 1 ? 2.0 * k : (kd == 3 ? 2.0 * k + 2 : 2.0 * k + 1); }
} // namespace

double mathieu_a(double m, double q) {
  if (std::isnan(m) || std::isnan(q) || m < 0 || m != std::floor(m))
    return NaN;
  int mi = static_cast<int>(m), kd, idx;
  classOf(true, mi, kd, idx);
  Block b = mathieuBlock(kd, q, blockSize(m, q, 0));
  return b.vals[idx];
}

double mathieu_b(double m, double q) {
  if (std::isnan(m) || std::isnan(q) || m < 1 || m != std::floor(m))
    return NaN;
  int mi = static_cast<int>(m), kd, idx;
  classOf(false, mi, kd, idx);
  Block b = mathieuBlock(kd, q, blockSize(m, q, 0));
  return b.vals[idx];
}

std::vector<double> mathieu_coef(bool even, int m, double q, int count) {
  int kd, idx;
  classOf(even, m, kd, idx);
  if (idx < 0)
    return {};
  int N = std::max(blockSize(m, q, 0), count + 5);
  Block b = mathieuBlock(kd, q, N);
  std::vector<double> c(N);
  for (int k = 0; k < N; k++)
    c[k] = b.vecs[k][idx];
  if (kd == 1)
    c[0] /= std::sqrt(2.0);
  // sign: ce(0) > 0 for the even functions, se'(0) > 0 for the odd ones
  double s = 0.0;
  for (int k = 0; k < N; k++)
    s += even ? c[k] : orderOf(kd, k) * c[k];
  if (s < 0)
    for (double &v : c)
      v = -v;
  c.resize(count);
  return c;
}

void mathieu_ce(double m, double q, double xdeg, double &y, double &yp) {
  y = yp = NaN;
  if (std::isnan(m) || std::isnan(q) || std::isnan(xdeg) || m < 0 || m != std::floor(m))
    return;
  int mi = static_cast<int>(m), kd, idx;
  classOf(true, mi, kd, idx);
  int N = blockSize(m, q, 0);
  std::vector<double> c = mathieu_coef(true, mi, q, N);
  double x = xdeg * PI / 180.0;
  y = yp = 0.0;
  for (int k = 0; k < N; k++) {
    double o = orderOf(kd, k);
    y += c[k] * std::cos(o * x);
    yp -= o * c[k] * std::sin(o * x);
  }
}

void mathieu_se(double m, double q, double xdeg, double &y, double &yp) {
  y = yp = NaN;
  if (std::isnan(m) || std::isnan(q) || std::isnan(xdeg) || m < 1 || m != std::floor(m))
    return;
  int mi = static_cast<int>(m), kd, idx;
  classOf(false, mi, kd, idx);
  int N = blockSize(m, q, 0);
  std::vector<double> c = mathieu_coef(false, mi, q, N);
  double x = xdeg * PI / 180.0;
  y = yp = 0.0;
  for (int k = 0; k < N; k++) {
    double o = orderOf(kd, k);
    y += c[k] * std::sin(o * x);
    yp += o * c[k] * std::cos(o * x);
  }
}

namespace {
double jOrder(int k, double u) { return besselj(k, u); }
double cOrder(int kind, int k, double u) { return kind == 1 ? besselj(k, u) : bessely(k, u); }
double dJ(int k, double u) { return 0.5 * (besselj(k - 1, u) - besselj(k + 1, u)); }
double dC(int kind, int k, double u) {
  return kind == 1 ? dJ(k, u) : 0.5 * (bessely(k - 1, u) - bessely(k + 1, u));
}
// Radial Mathieu functions from Bessel products (DLMF 28.24.1-4 with s = 0).
void radial(bool even, int kind, int m, double q, double z, double &y, double &yp) {
  y = yp = NaN;
  if (q <= 0)
    return;
  int kd, idx;
  classOf(even, m, kd, idx);
  if (idx < 0)
    return;
  int N = blockSize(m, q, 0);
  std::vector<double> c = mathieu_coef(even, m, q, N);
  double h = std::sqrt(q);
  double u1 = h * std::exp(-z), u2 = h * std::exp(z);
  int n = (kd == 1 || kd == 3) ? (kd == 1 ? m / 2 : m / 2 - 1) : (m - 1) / 2;
  int shift = (kd == 1) ? 0 : (kd == 3 ? 2 : 1); // order gap between the two Bessel factors
  double ref = c[0];
  y = yp = 0.0;
  for (int l = 0; l < N; l++) {
    double sg = ((l + n) % 2 == 0) ? 1.0 : -1.0;
    double w = sg * c[l] / ref;
    double t, tp;
    if (kd == 1) {
      t = jOrder(l, u1) * cOrder(kind, l, u2);
      tp = -u1 * dJ(l, u1) * cOrder(kind, l, u2) + jOrder(l, u1) * u2 * dC(kind, l, u2);
    } else {
      double sgn = even ? 1.0 : -1.0;
      double a1 = jOrder(l, u1), a2 = cOrder(kind, l + shift, u2);
      double b1 = jOrder(l + shift, u1), b2 = cOrder(kind, l, u2);
      t = a1 * a2 + sgn * b1 * b2;
      tp = (-u1 * dJ(l, u1)) * a2 + a1 * (u2 * dC(kind, l + shift, u2)) +
           sgn * ((-u1 * dJ(l + shift, u1)) * b2 + b1 * (u2 * dC(kind, l, u2)));
    }
    y += w * t;
    yp += w * tp;
    if (l > 10 && std::fabs(w) < 1e-17)
      break;
  }
}
} // namespace

void mathieu_mc(int kind, double m, double q, double x, double &y, double &yp) {
  y = yp = NaN;
  if (std::isnan(m) || std::isnan(q) || std::isnan(x) || m < 0 || m != std::floor(m))
    return;
  radial(true, kind, static_cast<int>(m), q, x, y, yp);
}

void mathieu_ms(int kind, double m, double q, double x, double &y, double &yp) {
  y = yp = NaN;
  if (std::isnan(m) || std::isnan(q) || std::isnan(x) || m < 1 || m != std::floor(m))
    return;
  radial(false, kind, static_cast<int>(m), q, x, y, yp);
}

// ---- spheroidal wave functions ----

namespace {
struct Spheroid {
  double cv = NaN;
  std::vector<double> d; // d_r for r = p, p + 2, ...
  int p = 0;             // parity of n - m
};

// Flammer's recurrence a_r d_{r+2} + (b_r - cv) d_r + g_r d_{r-2} = 0 (c^2 -> -c^2 for oblate).
Spheroid solve(bool prolate, int m, int n, double c, double cvGiven) {
  Spheroid s;
  s.p = (n - m) % 2;
  int K = (n - m) / 2 + 30 + static_cast<int>(1.5 * c);
  double c2 = prolate ? c * c : -c * c;
  std::vector<double> diag(K), al(K), ga(K);
  for (int k = 0; k < K; k++) {
    double r = s.p + 2.0 * k;
    double mr = m + r;
    al[k] = (2 * m + r + 2) * (2 * m + r + 1) * c2 / ((2 * m + 2 * r + 3) * (2 * m + 2 * r + 5));
    diag[k] = mr * (mr + 1) + (2 * mr * (mr + 1) - 2.0 * m * m - 1) * c2 / ((2 * m + 2 * r - 1) * (2 * m + 2 * r + 3));
    ga[k] = r * (r - 1) * c2 / ((2 * m + 2 * r - 3) * (2 * m + 2 * r - 1));
  }
  std::vector<double> off(K > 1 ? K - 1 : 0), scale(K, 1.0);
  for (int k = 0; k + 1 < K; k++) {
    double prod = al[k] * ga[k + 1];
    off[k] = (al[k] >= 0 ? 1.0 : -1.0) * std::sqrt(std::fabs(prod));
    scale[k + 1] = scale[k] * (al[k] != 0 ? std::sqrt(std::fabs(ga[k + 1] / al[k])) : 1.0);
  }
  std::vector<double> vals;
  std::vector<std::vector<double>> vecs;
  tridiag_eig(diag, off, vals, &vecs);
  int idx = (n - m) / 2;
  if (!std::isnan(cvGiven)) {
    double best = Inf;
    for (int k = 0; k < K; k++)
      if (std::fabs(vals[k] - cvGiven) < best) {
        best = std::fabs(vals[k] - cvGiven);
        idx = k;
      }
  }
  s.cv = std::isnan(cvGiven) ? vals[idx] : cvGiven;
  s.d.resize(K);
  for (int k = 0; k < K; k++)
    s.d[k] = vecs[k][idx] * scale[k];
  return s;
}

// P_l^m without the Condon-Shortley phase, and its derivative.
double pNoCS(int l, int m, double x) { return ((m % 2) ? -1.0 : 1.0) * assoc_legendre(l, m, x, false); }
double dpNoCS(int l, int m, double x) {
  if (l == 0)
    return 0.0;
  double w = 1 - x * x;
  if (w == 0)
    return NaN;
  return ((l + m) * pNoCS(l - 1, m, x) - l * x * pNoCS(l, m, x)) / w;
}

// Flammer normalization of the angular function.
void normalizeAngular(Spheroid &s, int m, int n) {
  double raw = 0.0, want;
  for (size_t k = 0; k < s.d.size(); k++) {
    int l = m + s.p + 2 * static_cast<int>(k);
    raw += s.d[k] * (s.p == 0 ? pNoCS(l, m, 0.0) : dpNoCS(l, m, 0.0));
  }
  want = (s.p == 0) ? pNoCS(n, m, 0.0) : dpNoCS(n, m, 0.0);
  if (raw != 0)
    for (double &v : s.d)
      v *= want / raw;
}
} // namespace

double sph_cv(bool prolate, int m, int n, double c) {
  if (m < 0 || n < m || std::isnan(c))
    return NaN;
  return solve(prolate, m, n, c, NaN).cv;
}

std::vector<double> sph_cv_seq(bool prolate, int m, int n, double c) {
  std::vector<double> out;
  if (m < 0 || n < m || std::isnan(c))
    return out;
  for (int k = m; k <= n; k++)
    out.push_back(sph_cv(prolate, m, k, c));
  return out;
}

void sph_ang1(bool prolate, int m, int n, double c, double cv, double x, double &s, double &sp) {
  s = sp = NaN;
  if (m < 0 || n < m || std::isnan(c) || std::isnan(x) || std::fabs(x) >= 1)
    return;
  Spheroid sp0 = solve(prolate, m, n, c, cv);
  normalizeAngular(sp0, m, n);
  s = sp = 0.0;
  for (size_t k = 0; k < sp0.d.size(); k++) {
    int l = m + sp0.p + 2 * static_cast<int>(k);
    s += sp0.d[k] * pNoCS(l, m, x);
    sp += sp0.d[k] * dpNoCS(l, m, x);
  }
}

namespace {
void radialSph(bool prolate, int kind, int m, int n, double c, double cv, double xi, double &r, double &rp) {
  r = rp = NaN;
  if (m < 0 || n < m || std::isnan(c) || std::isnan(xi) || (prolate && xi <= 1) || (!prolate && xi < 0))
    return;
  Spheroid s = solve(prolate, m, n, c, cv);
  normalizeAngular(s, m, n);
  double norm = 0.0, sum = 0.0, dsum = 0.0, cx = c * xi;
  for (size_t k = 0; k < s.d.size(); k++) {
    int r0 = s.p + 2 * static_cast<int>(k);
    double f = std::exp(std::lgamma(2.0 * m + r0 + 1) - std::lgamma(r0 + 1.0)) * s.d[k];
    norm += f;
    double sg = (((r0 + m - n) / 2) % 2 == 0) ? 1.0 : -1.0;
    int order = m + r0;
    double z = kind == 1 ? sph_jn(order, cx, false) : sph_yn(order, cx, false);
    double zp = kind == 1 ? sph_jn(order, cx, true) : sph_yn(order, cx, true);
    sum += sg * f * z;
    dsum += sg * f * c * zp;
  }
  double t = prolate ? 1 - 1 / (xi * xi) : 1 + 1 / (xi * xi);
  double A = std::pow(t, m / 2.0);
  double Ap = (m == 0) ? 0.0 : (m / 2.0) * std::pow(t, m / 2.0 - 1) * (prolate ? 2 / (xi * xi * xi) : -2 / (xi * xi * xi));
  r = A * sum / norm;
  rp = (Ap * sum + A * dsum) / norm;
}
} // namespace

void sph_rad1(bool prolate, int m, int n, double c, double cv, double x, double &r, double &rp) {
  radialSph(prolate, 1, m, n, c, cv, x, r, rp);
}
void sph_rad2(bool prolate, int m, int n, double c, double cv, double x, double &r, double &rp) {
  radialSph(prolate, 2, m, n, c, cv, x, r, rp);
}

// ---- ellipsoidal harmonics ----

namespace {
bool lameCoefficients(double h2, double k2, int n, int p, std::vector<double> &eigv) {
  if (n < 0 || p < 1 || p > 2 * n + 1)
    return false;
  int r = n / 2, tp, size;
  char t;
  double alpha = h2, beta = k2 - h2, gamma = alpha - beta;
  if (p - 1 < r + 1) {
    t = 'K';
    tp = p;
    size = r + 1;
  } else if (p - 1 < (n - r) + (r + 1)) {
    t = 'L';
    tp = p - (r + 1);
    size = n - r;
  } else if (p - 1 < (n - r) + (n - r) + (r + 1)) {
    t = 'M';
    tp = p - (n - r) - (r + 1);
    size = n - r;
  } else {
    t = 'N';
    tp = p - (n - r) - (n - r) - (r + 1);
    size = r;
  }
  if (size < 1)
    return false;
  std::vector<double> g(size), d(size), f(size);
  for (int j = 0; j < size; j++) {
    bool odd = n % 2;
    if (t == 'K') {
      g[j] = -(2.0 * j + 2) * (2 * j + 1) * beta;
      if (odd) {
        f[j] = -alpha * (2.0 * (r - (j + 1)) + 2) * (2.0 * ((j + 1) + r) + 1);
        d[j] = ((2.0 * r + 1) * (2 * r + 2) - 4.0 * j * j) * alpha + (2.0 * j + 1) * (2 * j + 1) * beta;
      } else {
        f[j] = -alpha * (2.0 * (r - (j + 1)) + 2) * (2.0 * (r + (j + 1)) - 1);
        d[j] = 2.0 * r * (2 * r + 1) * alpha - 4.0 * j * j * gamma;
      }
    } else if (t == 'L') {
      g[j] = -(2.0 * j + 2) * (2 * j + 3) * beta;
      if (odd) {
        f[j] = -alpha * (2.0 * (r - (j + 1)) + 2) * (2.0 * ((j + 1) + r) + 1);
        d[j] = (2.0 * r + 1) * (2 * r + 2) * alpha - (2.0 * j + 1) * (2 * j + 1) * gamma;
      } else {
        f[j] = -alpha * (2.0 * (r - (j + 1))) * (2.0 * (r + (j + 1)) + 1);
        d[j] = (2.0 * r * (2 * r + 1) - (2.0 * j + 1) * (2 * j + 1)) * alpha + (2.0 * j + 2) * (2 * j + 2) * beta;
      }
    } else if (t == 'M') {
      g[j] = -(2.0 * j + 2) * (2 * j + 1) * beta;
      if (odd) {
        f[j] = -alpha * (2.0 * (r - (j + 1)) + 2) * (2.0 * ((j + 1) + r) + 1);
        d[j] = ((2.0 * r + 1) * (2 * r + 2) - (2.0 * j + 1) * (2 * j + 1)) * alpha + 4.0 * j * j * beta;
      } else {
        f[j] = -alpha * (2.0 * (r - (j + 1))) * (2.0 * (r + (j + 1)) + 1);
        d[j] = 2.0 * r * (2 * r + 1) * alpha - (2.0 * j + 1) * (2 * j + 1) * gamma;
      }
    } else {
      g[j] = -(2.0 * j + 2) * (2 * j + 3) * beta;
      if (odd) {
        f[j] = -alpha * (2.0 * (r - (j + 1)) + 2) * (2.0 * ((j + 1) + r) + 3);
        d[j] = (2.0 * r + 1) * (2 * r + 2) * alpha - (2.0 * j + 2) * (2 * j + 2) * gamma;
      } else {
        f[j] = -alpha * (2.0 * (r - (j + 1))) * (2.0 * (r + (j + 1)) + 1);
        d[j] = (2.0 * r * (2 * r + 1) - (2.0 * j + 2) * (2 * j + 2)) * alpha + (2.0 * j + 1) * (2 * j + 1) * beta;
      }
    }
  }
  std::vector<double> ss(size), dd(size > 1 ? size - 1 : 0);
  for (int i = 0; i < size; i++)
    ss[i] = i == 0 ? 1.0 : std::sqrt(g[i - 1] / f[i - 1]) * ss[i - 1];
  for (int i = 0; i + 1 < size; i++)
    dd[i] = g[i] * ss[i] / ss[i + 1];
  std::vector<double> vals;
  std::vector<std::vector<double>> vecs;
  tridiag_eig(d, dd, vals, &vecs);
  eigv.resize(size);
  for (int i = 0; i < size; i++)
    eigv[i] = vecs[i][tp - 1] / ss[i];
  double last = eigv[size - 1] / std::pow(-h2, size - 1);
  for (int i = 0; i < size; i++)
    eigv[i] /= last;
  return true;
}

double lameEval(double h2, double k2, int n, int p, double s, const std::vector<double> &eigv, double signm, double signn) {
  double s2 = s * s, psi;
  int r = n / 2, size;
  if (p - 1 < r + 1) {
    size = r + 1;
    psi = std::pow(s, n - 2 * r);
  } else if (p - 1 < (n - r) + (r + 1)) {
    size = n - r;
    psi = std::pow(s, 1 - n + 2 * r) * signm * std::sqrt(std::fabs(s2 - h2));
  } else if (p - 1 < (n - r) + (n - r) + (r + 1)) {
    size = n - r;
    psi = std::pow(s, 1 - n + 2 * r) * signn * std::sqrt(std::fabs(s2 - k2));
  } else {
    size = r;
    psi = std::pow(s, n - 2 * r) * signm * signn * std::sqrt(std::fabs((s2 - h2) * (s2 - k2)));
  }
  double lam = 1.0 - s2 / h2;
  double pp = eigv[size - 1];
  for (int j = size - 2; j >= 0; j--)
    pp = pp * lam + eigv[j];
  return pp * psi;
}
} // namespace

double ellip_harm(double h2, double k2, int n, int p, double s, double signm, double signn) {
  std::vector<double> eigv;
  if (std::isnan(h2) || std::isnan(k2) || std::isnan(s) || !lameCoefficients(h2, k2, n, p, eigv))
    return NaN;
  return lameEval(h2, k2, n, p, s, eigv, signm, signn);
}

double ellip_harm_2(double h2, double k2, int n, int p, double s) {
  std::vector<double> eigv;
  if (std::isnan(h2) || std::isnan(k2) || std::isnan(s) || h2 < 0 || k2 <= h2 || s * s < k2 ||
      !lameCoefficients(h2, k2, n, p, eigv))
    return NaN;
  auto f = [&](double t) {
    double e = lameEval(h2, k2, n, p, 1.0 / t, eigv, 1, 1);
    return 1.0 / (e * e * std::sqrt((1 - t * t * h2) * (1 - t * t * k2)));
  };
  double I = quad(f, 0.0, 1.0 / s, 0.0, 1e-14, 2000);
  return (2 * n + 1) * lameEval(h2, k2, n, p, s, eigv, 1, 1) * I;
}

double ellip_normal(double h2, double k2, int n, int p) {
  std::vector<double> eigv;
  if (std::isnan(h2) || std::isnan(k2) || h2 <= 0 || k2 <= h2 || !lameCoefficients(h2, k2, n, p, eigv))
    return NaN;
  double h = std::sqrt(h2);
  auto E = [&](double t) { return lameEval(h2, k2, n, p, t, eigv, 1, 1); };
  // [0, h]: t = h sin(th) removes 1/sqrt(h^2 - t^2); [h, k]: t^2 = h^2 cos^2 + k^2 sin^2 removes both roots.
  auto in0 = [&](double th, bool sq) {
    double t = h * std::sin(th), e = E(t);
    return e * e * (sq ? t * t : 1.0) / std::sqrt(k2 - t * t);
  };
  auto in1 = [&](double ph, bool sq) {
    double t = std::sqrt(h2 * std::cos(ph) * std::cos(ph) + k2 * std::sin(ph) * std::sin(ph)), e = E(t);
    return e * e * (sq ? t * t : 1.0) / t;
  };
  double A = quad([&](double th) { return in0(th, true); }, 0.0, PI / 2, 0.0, 1e-14, 2000);
  double B = quad([&](double ph) { return in1(ph, false); }, 0.0, PI / 2, 0.0, 1e-14, 2000);
  double C = quad([&](double th) { return in0(th, false); }, 0.0, PI / 2, 0.0, 1e-14, 2000);
  double D = quad([&](double ph) { return in1(ph, true); }, 0.0, PI / 2, 0.0, 1e-14, 2000);
  return 8.0 * (C * D - A * B);
}

} // namespace sf
} // namespace scipy
} // namespace nc
