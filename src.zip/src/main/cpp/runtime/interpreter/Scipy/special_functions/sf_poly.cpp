// Orthogonal polynomials (values, coefficients, Gauss rules by Golub-Welsch)
// and the Legendre functions of the first and second kind.
#include "sf_poly.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

namespace {
bool isInt(double n) { return n == std::floor(n) && std::fabs(n) < 1e9; }
double z1(double x) { return (1.0 - x) / 2.0; }

using Poly = std::vector<double>; // lowest power first

Poly mulX(const Poly &p) {
  Poly r(p.size() + 1, 0.0);
  for (size_t i = 0; i < p.size(); i++)
    r[i + 1] = p[i];
  return r;
}
Poly axpy(double a, const Poly &x, double b, const Poly &y) {
  Poly r(std::max(x.size(), y.size()), 0.0);
  for (size_t i = 0; i < x.size(); i++)
    r[i] += a * x[i];
  for (size_t i = 0; i < y.size(); i++)
    r[i] += b * y[i];
  return r;
}
// p(s x + t)
Poly compose(const Poly &p, double s, double t) {
  Poly r = {0.0};
  for (size_t k = p.size(); k-- > 0;) {
    Poly m = axpy(s, mulX(r), t, r);
    m[0] += p[k];
    r = m;
  }
  return r;
}
} // namespace

// ---- values ----

double eval_legendre(double n, double x) {
  if (std::isnan(n) || std::isnan(x))
    return NaN;
  if (!isInt(n))
    return hyp2f1(-n, n + 1, 1.0, z1(x));
  long long k = static_cast<long long>(n);
  if (k < 0)
    k = -k - 1;
  if (k == 0)
    return 1.0;
  double p0 = 1.0, p1 = x;
  for (long long j = 1; j < k; j++) {
    double p2 = ((2 * j + 1) * x * p1 - j * p0) / (j + 1);
    p0 = p1;
    p1 = p2;
  }
  return p1;
}

double eval_chebyt(double n, double x) {
  if (std::isnan(n) || std::isnan(x))
    return NaN;
  if (!isInt(n))
    return hyp2f1(-n, n, 0.5, z1(x));
  long long k = std::llabs(static_cast<long long>(n));
  if (std::fabs(x) <= 1 && k > 20)
    return std::cos(k * std::acos(x));
  double t0 = 1.0, t1 = x;
  if (k == 0)
    return 1.0;
  for (long long j = 1; j < k; j++) {
    double t2 = 2 * x * t1 - t0;
    t0 = t1;
    t1 = t2;
  }
  return t1;
}

double eval_chebyu(double n, double x) {
  if (std::isnan(n) || std::isnan(x))
    return NaN;
  if (!isInt(n))
    return (n + 1) * hyp2f1(-n, n + 2, 1.5, z1(x));
  long long k = static_cast<long long>(n);
  if (k == -1)
    return 0.0;
  if (k < -1)
    return -eval_chebyu(double(-k - 2), x);
  double u0 = 1.0, u1 = 2 * x;
  if (k == 0)
    return 1.0;
  for (long long j = 1; j < k; j++) {
    double u2 = 2 * x * u1 - u0;
    u0 = u1;
    u1 = u2;
  }
  return u1;
}

double eval_chebyc(double n, double x) { return 2.0 * eval_chebyt(n, x / 2.0); }
double eval_chebys(double n, double x) { return eval_chebyu(n, x / 2.0); }

double eval_jacobi(double n, double a, double b, double x) {
  if (std::isnan(n) || std::isnan(a) || std::isnan(b) || std::isnan(x))
    return NaN;
  if (!isInt(n) || n < 0)
    return binom(n + a, n) * hyp2f1(-n, n + a + b + 1, a + 1, z1(x));
  long long k = static_cast<long long>(n);
  double p0 = 1.0;
  if (k == 0)
    return 1.0;
  double p1 = (a + 1) + (a + b + 2) * (x - 1) / 2.0;
  for (long long j = 1; j < k; j++) {
    double s = 2.0 * j + a + b;
    double d = 2.0 * (j + 1) * (j + a + b + 1) * s;
    if (d == 0)
      return binom(n + a, n) * hyp2f1(-n, n + a + b + 1, a + 1, z1(x));
    double p2 = ((s + 1) * ((s + 2) * s * x + a * a - b * b) * p1 - 2.0 * (j + a) * (j + b) * (s + 2) * p0) / d;
    p0 = p1;
    p1 = p2;
  }
  return p1;
}

double eval_sh_jacobi(double n, double p, double q, double x) {
  return eval_jacobi(n, p - q, q - 1, 2 * x - 1) / binom(2 * n + p - 1, n);
}

double eval_gegenbauer(double n, double a, double x) {
  if (std::isnan(n) || std::isnan(a) || std::isnan(x))
    return NaN;
  if (!isInt(n)) {
    if (a == 0)
      return NaN;
    return binom(n + 2 * a - 1, n) * hyp2f1(-n, n + 2 * a, a + 0.5, z1(x));
  }
  long long k = static_cast<long long>(n);
  if (k < 0)
    return 0.0;
  if (k == 0)
    return 1.0;
  if (a == 0)
    return 2.0 / k * eval_chebyt(double(k), x);
  double c0 = 1.0, c1 = 2 * a * x;
  for (long long j = 1; j < k; j++) {
    double c2 = (2 * x * (j + a) * c1 - (j + 2 * a - 1) * c0) / (j + 1);
    c0 = c1;
    c1 = c2;
  }
  return c1;
}

double eval_genlaguerre(double n, double a, double x) {
  if (std::isnan(n) || std::isnan(a) || std::isnan(x) || a <= -1)
    return NaN;
  if (!isInt(n))
    return binom(n + a, n) * hyp1f1(-n, a + 1, x);
  long long k = static_cast<long long>(n);
  if (k < 0)
    return 0.0;
  if (k == 0)
    return 1.0;
  double l0 = 1.0, l1 = 1 + a - x;
  for (long long j = 1; j < k; j++) {
    double l2 = ((2 * j + 1 + a - x) * l1 - (j + a) * l0) / (j + 1);
    l0 = l1;
    l1 = l2;
  }
  return l1;
}

double eval_laguerre(double n, double x) { return eval_genlaguerre(n, 0.0, x); }

double eval_hermite(double n, double x) {
  if (std::isnan(n) || std::isnan(x) || n < 0 || !isInt(n))
    return NaN;
  long long k = static_cast<long long>(n);
  if (k == 0)
    return 1.0;
  double h0 = 1.0, h1 = 2 * x;
  for (long long j = 1; j < k; j++) {
    double h2 = 2 * x * h1 - 2.0 * j * h0;
    h0 = h1;
    h1 = h2;
  }
  return h1;
}

double eval_hermitenorm(double n, double x) {
  if (std::isnan(n) || std::isnan(x) || n < 0 || !isInt(n))
    return NaN;
  long long k = static_cast<long long>(n);
  if (k == 0)
    return 1.0;
  double h0 = 1.0, h1 = x;
  for (long long j = 1; j < k; j++) {
    double h2 = x * h1 - double(j) * h0;
    h0 = h1;
    h1 = h2;
  }
  return h1;
}

// ---- coefficients (highest power first) ----

std::vector<double> poly_coef(const std::string &fam, int n, double a, double b) {
  if (n < 0)
    return {};
  Poly p0 = {1.0}, p1;
  std::string f = fam;
  bool shifted = false;
  double scale = 1.0;
  if (f == "sh_legendre" || f == "sh_chebyt" || f == "sh_chebyu") {
    shifted = true;
    f = f.substr(3);
  }
  if (f == "sh_jacobi") {
    shifted = true;
    double p = a, q = b;
    a = p - q;
    b = q - 1;
    scale = 1.0 / binom(2.0 * n + p - 1, n);
    f = "jacobi";
  }
  auto step = [&](int k, const Poly &pk, const Poly &pkm1) -> Poly {
    const Poly x = mulX(pk);
    if (f == "legendre")
      return axpy((2.0 * k + 1) / (k + 1), x, -double(k) / (k + 1), pkm1);
    if (f == "chebyt" || f == "chebyc")
      return axpy(2.0, x, -1.0, pkm1);
    if (f == "chebyu" || f == "chebys")
      return axpy(2.0, x, -1.0, pkm1);
    if (f == "hermite")
      return axpy(2.0, x, -2.0 * k, pkm1);
    if (f == "hermitenorm")
      return axpy(1.0, x, -double(k), pkm1);
    if (f == "laguerre" || f == "genlaguerre") {
      Poly r = axpy(-1.0 / (k + 1), x, -(k + a) / (k + 1), pkm1);
      return axpy(1.0, r, (2.0 * k + 1 + a) / (k + 1), pk);
    }
    if (f == "gegenbauer")
      return axpy(2.0 * (k + a) / (k + 1), x, -(k + 2 * a - 1) / (k + 1), pkm1);
    // jacobi
    double s = 2.0 * k + a + b;
    double d = 2.0 * (k + 1) * (k + a + b + 1) * s;
    Poly r = axpy((s + 1) * (s + 2) * s / d, x, -2.0 * (k + a) * (k + b) * (s + 2) / d, pkm1);
    return axpy(1.0, r, (s + 1) * (a * a - b * b) / d, pk);
  };
  if (f == "legendre" || f == "chebyt" || f == "chebyc" || f == "hermitenorm")
    p1 = {0.0, 1.0};
  else if (f == "chebyu" || f == "chebys" || f == "hermite")
    p1 = {0.0, 2.0};
  else if (f == "laguerre" || f == "genlaguerre")
    p1 = {1.0 + a, -1.0};
  else if (f == "gegenbauer")
    p1 = {0.0, 2.0 * a};
  else
    p1 = {(a + 1) - (a + b + 2) / 2.0, (a + b + 2) / 2.0};
  Poly r = (n == 0) ? p0 : p1;
  for (int k = 1; k < n; k++) {
    Poly p2 = step(k, p1, p0);
    p0 = p1;
    p1 = p2;
    r = p1;
  }
  if (f == "chebyc") {
    double s = 2.0;
    for (size_t j = 0; j < r.size(); j++) {
      r[j] *= s;
      s /= 2.0;
    }
  } else if (f == "chebys") {
    double s = 1.0;
    for (size_t j = 0; j < r.size(); j++) {
      r[j] *= s;
      s /= 2.0;
    }
  }
  if (shifted)
    r = compose(r, 2.0, -1.0);
  for (double &c : r)
    c *= scale;
  r.resize(static_cast<size_t>(n) + 1, 0.0);
  std::reverse(r.begin(), r.end());
  return r;
}

// ---- Gauss rules ----

bool gauss_rule(const std::string &fam, int n, double a, double b, std::vector<double> &x, std::vector<double> &w) {
  if (n < 1)
    return false;
  std::string f = fam;
  double shift = 0, xs = 1, ws = 1;
  if (f == "sh_legendre") {
    f = "legendre";
    shift = 1;
    xs = 0.5;
    ws = 0.5;
  } else if (f == "sh_chebyt") {
    f = "chebyt";
    shift = 1;
    xs = 0.5;
  } else if (f == "sh_chebyu") {
    f = "chebyu";
    shift = 1;
    xs = 0.5;
    ws = 0.25;
  } else if (f == "sh_jacobi") {
    double p = a, q = b;
    if (!(p - q > -1 && q > 0))
      return false;
    f = "jacobi";
    a = p - q;
    b = q - 1;
    shift = 1;
    xs = 0.5;
    ws = std::pow(2.0, -p);
  } else if (f == "chebyc") {
    f = "chebyt";
    xs = 2;
    ws = 2;
  } else if (f == "chebys") {
    f = "chebyu";
    xs = 2;
    ws = 2;
  } else if (f == "gegenbauer") {
    if (!(a > -0.5))
      return false;
    f = "jacobi";
    double al = a - 0.5;
    a = b = al;
  }
  x.assign(n, 0.0);
  w.assign(n, 0.0);
  if (f == "chebyt") {
    for (int k = 0; k < n; k++) {
      x[k] = -std::cos(PI * (2.0 * k + 1) / (2.0 * n));
      w[k] = PI / n;
    }
  } else if (f == "chebyu") {
    for (int k = 0; k < n; k++) {
      double t = PI * (k + 1) / (n + 1.0);
      x[k] = -std::cos(t);
      w[k] = PI / (n + 1.0) * std::sin(t) * std::sin(t);
    }
  } else {
    std::vector<double> d(n, 0.0), e(n > 1 ? n - 1 : 0, 0.0);
    double mu0;
    if (f == "legendre") {
      for (int k = 1; k < n; k++)
        e[k - 1] = k / std::sqrt(4.0 * k * k - 1.0);
      mu0 = 2.0;
    } else if (f == "hermite") {
      for (int k = 1; k < n; k++)
        e[k - 1] = std::sqrt(k / 2.0);
      mu0 = SQRTPI;
    } else if (f == "hermitenorm") {
      for (int k = 1; k < n; k++)
        e[k - 1] = std::sqrt(double(k));
      mu0 = std::sqrt(2 * PI);
    } else if (f == "laguerre" || f == "genlaguerre") {
      if (f == "laguerre")
        a = 0;
      if (!(a > -1))
        return false;
      for (int k = 0; k < n; k++)
        d[k] = 2.0 * k + a + 1;
      for (int k = 1; k < n; k++)
        e[k - 1] = std::sqrt(k * (k + a));
      mu0 = std::tgamma(a + 1);
    } else { // jacobi
      if (!(a > -1 && b > -1))
        return false;
      double ab = a + b;
      d[0] = (b - a) / (ab + 2);
      for (int k = 1; k < n; k++) {
        double s = 2.0 * k + ab;
        d[k] = (b * b - a * a) / (s * (s + 2));
        e[k - 1] = 2.0 / s * std::sqrt(k * (k + a) * (k + b) * (k + ab) / ((s - 1) * (s + 1)));
      }
      if (n > 1) // k = 1: (k + a + b)/(s - 1) = 1, written out so a + b = -1 does not give 0/0
        e[0] = 2.0 / (2 + ab) * std::sqrt((1 + a) * (1 + b) / (3 + ab));
      mu0 = std::exp((ab + 1) * std::log(2.0) + std::lgamma(a + 1) + std::lgamma(b + 1) - std::lgamma(ab + 2));
    }
    std::vector<double> vals;
    std::vector<std::vector<double>> first(1);
    tridiag_eig(d, e, vals, &first);
    for (int k = 0; k < n; k++) {
      x[k] = vals[k];
      w[k] = mu0 * first[0][k] * first[0][k];
    }
    // symmetric families: make the nodes exactly antisymmetric
    if (f == "legendre" || f == "hermite" || f == "hermitenorm" || (f == "jacobi" && a == b)) {
      for (int k = 0; k < n / 2; k++) {
        double m = 0.5 * (x[n - 1 - k] - x[k]);
        x[k] = -m;
        x[n - 1 - k] = m;
        double wm = 0.5 * (w[k] + w[n - 1 - k]);
        w[k] = w[n - 1 - k] = wm;
      }
      if (n % 2)
        x[n / 2] = 0.0;
    }
  }
  for (int k = 0; k < n; k++) {
    x[k] = (x[k] + shift) * xs;
    w[k] *= ws;
  }
  return true;
}

// ---- Legendre functions ----

double assoc_legendre(int n, int m, double x, bool norm) {
  if (std::isnan(x))
    return NaN;
  if (n < 0)
    n = -n - 1;
  int am = std::abs(m);
  if (am > n)
    return 0.0;
  // P_m^m = (-1)^m (2m-1)!! (1-x^2)^(m/2), then up in n.
  double s = std::sqrt(std::fabs(1.0 - x * x));
  double pmm = 1.0;
  for (int i = 1; i <= am; i++)
    pmm *= -(2.0 * i - 1) * s;
  double p = pmm;
  if (n > am) {
    double pm1 = x * (2.0 * am + 1) * pmm;
    double pa = pmm, pb = pm1;
    for (int l = am + 2; l <= n; l++) {
      double pc = ((2.0 * l - 1) * x * pb - (l + am - 1.0) * pa) / (l - am);
      pa = pb;
      pb = pc;
    }
    p = pb;
  }
  double lratio = std::lgamma(n - am + 1.0) - std::lgamma(n + am + 1.0);
  if (m < 0)
    p *= ((am % 2) ? -1.0 : 1.0) * std::exp(lratio);
  if (norm) {
    // normalized over [-1, 1]
    double f = std::sqrt((2.0 * n + 1) / 2.0 * std::exp(m < 0 ? -lratio : lratio));
    p *= f;
  }
  return p;
}

std::complex<double> assoc_legendre_c(int n, int m, std::complex<double> z, bool norm) {
  using C = std::complex<double>;
  if (std::isnan(z.real()) || std::isnan(z.imag()))
    return C(NaN, NaN);
  if (n < 0)
    n = -n - 1;
  int am = std::abs(m);
  if (am > n)
    return 0.0;
  C w = std::sqrt(1.0 - z * z), pmm = 1.0;
  for (int i = 1; i <= am; i++)
    pmm *= -(2.0 * i - 1) * w;
  C p = pmm;
  if (n > am) {
    C pa = pmm, pb = z * (2.0 * am + 1) * pmm;
    for (int l = am + 2; l <= n; l++) {
      C pc = ((2.0 * l - 1) * z * pb - (l + am - 1.0) * pa) / double(l - am);
      pa = pb;
      pb = pc;
    }
    p = pb;
  }
  double lratio = std::lgamma(n - am + 1.0) - std::lgamma(n + am + 1.0);
  if (m < 0)
    p *= ((am % 2) ? -1.0 : 1.0) * std::exp(lratio);
  if (norm)
    p *= std::sqrt((2.0 * n + 1) / 2.0 * std::exp(m < 0 ? -lratio : lratio));
  return p;
}

double sph_legendre(int n, int m, double theta) {
  int am = std::abs(m);
  if (am > n || n < 0)
    return 0.0;
  double p = assoc_legendre(n, am, std::cos(theta), false);
  double lratio = std::lgamma(n - am + 1.0) - std::lgamma(n + am + 1.0);
  double r = std::sqrt((2.0 * n + 1) / (4 * PI) * std::exp(lratio)) * p;
  if (m < 0 && (am % 2))
    r = -r;
  // the formula uses |sin(theta)|; SciPy follows sin(theta) itself
  if (std::sin(theta) < 0 && (am % 2))
    r = -r;
  return r;
}

double legendre_deriv(int n, double x, int d) {
  // d-th derivative of P_n via (k+1)P^(d)_{k+1} = (2k+1)(x P^(d)_k + d P^(d-1)_k) - k P^(d)_{k-1}
  if (n < 0)
    n = -n - 1;
  std::vector<std::vector<double>> P(d + 1, std::vector<double>(n + 1, 0.0));
  for (int dd = 0; dd <= d; dd++) {
    for (int k = 0; k <= n; k++) {
      double v;
      if (k == 0)
        v = dd == 0 ? 1.0 : 0.0;
      else if (k == 1)
        v = dd == 0 ? x : (dd == 1 ? 1.0 : 0.0);
      else {
        int j = k - 1;
        v = ((2.0 * j + 1) * (x * P[dd][j] + (dd ? dd * P[dd - 1][j] : 0.0)) - j * P[dd][j - 1]) / (j + 1);
      }
      P[dd][k] = v;
    }
  }
  return P[d][n];
}

double lpmv(double m, double v, double x) {
  if (std::isnan(m) || std::isnan(v) || std::isnan(x))
    return NaN;
  if (m != std::floor(m))
    return NaN;
  if (x < -1 || x > 1)
    return NaN;
  int mi = static_cast<int>(m);
  if (v < 0)
    v = -v - 1;
  if (v == std::floor(v) && v < 1e6)
    return assoc_legendre(static_cast<int>(v), mi, x, false);
  int am = std::abs(mi);
  if (x == 1.0)
    return am == 0 ? 1.0 : 0.0;
  // P_v^m(x) = (-1)^m Gamma(v+m+1)/(2^m Gamma(v-m+1) m!) (1-x^2)^(m/2) 2F1(m-v, m+v+1; m+1; (1-x)/2)
  double f = std::pow(1 - x * x, am / 2.0) * std::pow(2.0, -am) / std::tgamma(am + 1.0);
  double g = poch(v - am + 1, 2.0 * am); // Gamma(v+m+1)/Gamma(v-m+1)
  double r = ((am % 2) ? -1.0 : 1.0) * g * f * hyp2f1(am - v, am + v + 1, am + 1.0, (1 - x) / 2);
  if (mi < 0) // P_v^{-m} = (-1)^m Gamma(v-m+1)/Gamma(v+m+1) P_v^m
    r = ((am % 2) ? -1.0 : 1.0) * r / g;
  return r;
}

void lqn(int n, cd z, std::vector<cd> &Q, std::vector<cd> &Qd) {
  Q.assign(n + 1, 0.0);
  Qd.assign(n + 1, 0.0);
  bool inside = z.imag() == 0.0 && std::fabs(z.real()) < 1.0;
  cd q0 = inside ? cd(0.5 * std::log((1.0 + z.real()) / (1.0 - z.real())), 0.0)
                 : 0.5 * std::log((z + 1.0) / (z - 1.0));
  Q[0] = q0;
  if (n >= 1)
    Q[1] = z * q0 - 1.0;
  for (int k = 1; k < n; k++)
    Q[k + 1] = ((2.0 * k + 1) * z * Q[k] - double(k) * Q[k - 1]) / double(k + 1);
  cd den = 1.0 - z * z;
  if (!inside)
    den = -(z * z - 1.0);
  Qd[0] = 1.0 / den;
  for (int k = 1; k <= n; k++)
    Qd[k] = double(k) * (Q[k - 1] - z * Q[k]) / den;
}

void lqmn(int m, int n, double x, std::vector<std::vector<double>> &Q, std::vector<std::vector<double>> &Qd) {
  // Ferrers functions of the second kind for |x| < 1 (with the Condon-Shortley phase).
  int N = n + 1;
  std::vector<cd> q, qd;
  lqn(N, cd(x, 0), q, qd);
  double s = std::sqrt(std::fabs(1 - x * x)), w = 1 - x * x;
  std::vector<std::vector<double>> A(m + 1, std::vector<double>(N + 1, 0.0));
  for (int k = 0; k <= N; k++) {
    A[0][k] = q[k].real();
    if (m >= 1)
      A[1][k] = -s * qd[k].real();
    for (int mu = 0; mu + 2 <= m; mu++)
      A[mu + 2][k] = -2.0 * (mu + 1) * x / s * A[mu + 1][k] - (k - mu) * (k + mu + 1.0) * A[mu][k];
  }
  Q.assign(m + 1, std::vector<double>(n + 1, 0.0));
  Qd.assign(m + 1, std::vector<double>(n + 1, 0.0));
  for (int mu = 0; mu <= m; mu++)
    for (int k = 0; k <= n; k++) {
      Q[mu][k] = A[mu][k];
      Qd[mu][k] = ((mu - k - 1.0) * A[mu][k + 1] + (k + 1.0) * x * A[mu][k]) / w;
    }
}

} // namespace sf
} // namespace scipy
} // namespace nc
