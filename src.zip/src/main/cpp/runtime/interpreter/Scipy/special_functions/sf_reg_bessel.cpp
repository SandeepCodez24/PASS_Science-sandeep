// Section 20, part 2: Bessel, Hankel, Airy, Struve and Kelvin functions,
// spherical Bessel functions, their zeros, and integrals of them.
#include "special_functions_main.h"

#include <algorithm>
#include <cmath>

#include "sf_poly.h"
#include "sf_ufunc.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::SpecialFunctions
#define DEF(...) std::vector<double>{__VA_ARGS__}
#define UF(NAME, MINA, MAXA, PARAMS, DEFS, EXPR)                                                                    \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                                                \
    return umap(a, ctx, MAXA, DEFS, [](const double *x) -> double { return EXPR; });                                \
  }                                                                                                                 \
  SP_END
#define UFC(NAME, MINA, MAXA, PARAMS, DEFS, EXPR, CEXPR)                                                            \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                                                \
    return umapC(a, ctx, MAXA, DEFS, [](const double *x) -> double { return EXPR; },                                \
                 [](const cd *z) -> cd { return CEXPR; });                                                          \
  }                                                                                                                 \
  SP_ENDC
// Complex result from real inputs.
#define UFTOC(NAME, MINA, MAXA, PARAMS, DEFS, CEXPR)                                                                \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                                                \
    return umapToC(a, ctx, MAXA, DEFS, [](const cd *z) -> cd { return CEXPR; });                                    \
  }                                                                                                                 \
  SP_ENDC

namespace {
using namespace sf;

bool countArg(const Args &a, size_t i, CallContext &ctx, long long &n, long long lo = 1) {
  if (!argInt(a, i, ctx, n))
    return false;
  if (n < lo || n > 100000) {
    ctx.fail("the " + ordinal(i) + " argument must be a whole number from " + std::to_string(lo) + " to 100000");
    return false;
  }
  return true;
}

// Positive zeros of f scanned from `start`.
Vec zerosFrom(const std::function<double(double)> &f, long long nt, double start, double step) {
  return zeros_of(f, static_cast<int>(nt), start, step);
}
// Negative zeros, nearest to the origin first.
Vec negZeros(const std::function<double(double)> &f, long long nt) {
  Vec z = zeros_of([&](double t) { return f(-t); }, static_cast<int>(nt), 1e-9, 0.05);
  for (double &v : z)
    v = -v;
  return z;
}

double jprime(double n, double x) { return bessel_deriv('j', n, x, 1); }
double yprime(double n, double x) { return bessel_deriv('y', n, x, 1); }

// Sum of an oscillating integral to infinity: pieces of one period, then
// repeated averaging of the partial sums (Euler's transformation).
double oscTail(const std::function<double(double)> &f, double x, double period) {
  const int N = 64;
  Vec partial(N);
  double s = 0.0;
  for (int k = 0; k < N; k++) {
    s += quad(f, x + k * period, x + (k + 1) * period, 0.0, 1e-14, 200);
    partial[k] = s;
  }
  Vec t(partial.begin() + N / 2, partial.end());
  for (int r = 0; r < 24 && t.size() > 1; r++) {
    Vec u(t.size() - 1);
    for (size_t i = 0; i + 1 < t.size(); i++)
      u[i] = 0.5 * (t[i] + t[i + 1]);
    t = u;
  }
  return t[0];
}

// Complex zero of g by Newton from z0.
cd newtonC(const std::function<cd(cd)> &g, const std::function<cd(cd)> &dg, cd z) {
  for (int i = 0; i < 100; i++) {
    cd dz = g(z) / dg(z);
    z -= dz;
    if (std::abs(dz) < 1e-15 * std::abs(z))
      break;
  }
  return z;
}

cd fresS(cd z) {
  cd s, c;
  fresnel(z, s, c);
  return s;
}
cd fresC(cd z) {
  cd s, c;
  fresnel(z, s, c);
  return c;
}
CVec fresnelZeros(bool sine, long long nt) {
  CVec out;
  for (long long n = 1; n <= nt; n++) {
    // z^2 = 4n (sine) or 4n - 1 (cosine) + (2i/pi) acosh(pi z / 2), iterated a few times
    cd z = std::sqrt(cd(sine ? 4.0 * n : 4.0 * n - 1, 0.0));
    for (int i = 0; i < 6; i++)
      z = std::sqrt(cd(sine ? 4.0 * n : 4.0 * n - 1, 0.0) + cd(0, 2.0 / PI) * std::acosh(PI * z / 2.0));
    if (sine)
      z = newtonC(fresS, [](cd w) { return std::sin(PI * w * w / 2.0); }, z);
    else
      z = newtonC(fresC, [](cd w) { return std::cos(PI * w * w / 2.0); }, z);
    out.push_back(z);
  }
  return out;
}

double itStruve0Series(double x) {
  double sum = 0.0;
  for (int k = 0; k < 300; k++) {
    double t = 2.0 * std::exp((2 * k + 2) * std::log(x / 2) - 2 * std::lgamma(k + 1.5)) / (2 * k + 2);
    sum += (k % 2 ? -1.0 : 1.0) * t;
    if (k > 3 && t < 1e-17 * std::fabs(sum))
      break;
  }
  return sum;
}
} // namespace

void registerSfBessel(Registry &reg) {
  // ---- Bessel functions of the first and second kind ----
  UF("j0", 1, 1, "x", DEF(), besselj(0, x[0]))
  UF("j1", 1, 1, "x", DEF(), besselj(1, x[0]))
  UF("jn", 2, 2, "n, x", DEF(), (x[0] != std::floor(x[0]) ? kNaN : besselj(x[0], x[1])))
  UFC("jv", 2, 2, "v, z", DEF(), besselj(x[0], x[1]), besselj(z[0].real(), z[1]))
  UFC("jve", 2, 2, "v, z", DEF(), besselj(x[0], x[1]), besselj(z[0].real(), z[1], true))
  UF("y0", 1, 1, "x", DEF(), bessely(0, x[0]))
  UF("y1", 1, 1, "x", DEF(), bessely(1, x[0]))
  UF("yn", 2, 2, "n, x", DEF(), (x[0] != std::floor(x[0]) ? kNaN : bessely(x[0], x[1])))
  UFC("yv", 2, 2, "v, z", DEF(), bessely(x[0], x[1]), bessely(z[0].real(), z[1]))
  UFC("yve", 2, 2, "v, z", DEF(), bessely(x[0], x[1]), bessely(z[0].real(), z[1], true))
  UF("i0", 1, 1, "x", DEF(), besseli(0, x[0]))
  UF("i0e", 1, 1, "x", DEF(), besseli(0, x[0], true))
  UF("i1", 1, 1, "x", DEF(), besseli(1, x[0]))
  UF("i1e", 1, 1, "x", DEF(), besseli(1, x[0], true))
  UFC("iv", 2, 2, "v, z", DEF(), besseli(x[0], x[1]), besseli(z[0].real(), z[1]))
  UFC("ive", 2, 2, "v, z", DEF(), besseli(x[0], x[1], true), besseli(z[0].real(), z[1], true))
  UF("k0", 1, 1, "x", DEF(), besselk(0, x[0]))
  UF("k0e", 1, 1, "x", DEF(), besselk(0, x[0], true))
  UF("k1", 1, 1, "x", DEF(), besselk(1, x[0]))
  UF("k1e", 1, 1, "x", DEF(), besselk(1, x[0], true))
  UF("kn", 2, 2, "n, x", DEF(), (x[0] != std::floor(x[0]) ? kNaN : besselk(x[0], x[1])))
  UFC("kv", 2, 2, "v, z", DEF(), besselk(x[0], x[1]), besselk(z[0].real(), z[1]))
  UFC("kve", 2, 2, "v, z", DEF(), besselk(x[0], x[1], true), besselk(z[0].real(), z[1], true))
  UFTOC("hankel1", 2, 2, "v, z", DEF(), hankel1(z[0].real(), z[1]))
  UFTOC("hankel1e", 2, 2, "v, z", DEF(), hankel1(z[0].real(), z[1], true))
  UFTOC("hankel2", 2, 2, "v, z", DEF(), hankel2(z[0].real(), z[1]))
  UFTOC("hankel2e", 2, 2, "v, z", DEF(), hankel2(z[0].real(), z[1], true))

  // ---- derivatives ----
  UF("jvp", 2, 3, "v, x, n", DEF(0, 0, 1), (x[2] < 0 || x[2] != std::floor(x[2]) ? kNaN : bessel_deriv('j', x[0], x[1], (int)x[2])))
  UF("yvp", 2, 3, "v, x, n", DEF(0, 0, 1), (x[2] < 0 || x[2] != std::floor(x[2]) ? kNaN : bessel_deriv('y', x[0], x[1], (int)x[2])))
  UF("ivp", 2, 3, "v, x, n", DEF(0, 0, 1), (x[2] < 0 || x[2] != std::floor(x[2]) ? kNaN : bessel_deriv('i', x[0], x[1], (int)x[2])))
  UF("kvp", 2, 3, "v, x, n", DEF(0, 0, 1), (x[2] < 0 || x[2] != std::floor(x[2]) ? kNaN : bessel_deriv('k', x[0], x[1], (int)x[2])))
  UFTOC("h1vp", 2, 3, "v, x, n", DEF(0, 0, 1), hankel_deriv(1, z[0].real(), z[1].real(), (int)z[2].real()))
  UFTOC("h2vp", 2, 3, "v, x, n", DEF(0, 0, 1), hankel_deriv(2, z[0].real(), z[1].real(), (int)z[2].real()))

  // ---- spherical Bessel ----
  UFC("spherical_jn", 2, 3, "n, x, derivative", DEF(0, 0, 0), sph_jn((int)x[0], x[1], x[2] != 0),
      sph_jn((int)z[0].real(), z[1], z[2].real() != 0))
  UFC("spherical_yn", 2, 3, "n, x, derivative", DEF(0, 0, 0), sph_yn((int)x[0], x[1], x[2] != 0),
      sph_yn((int)z[0].real(), z[1], z[2].real() != 0))
  UFC("spherical_in", 2, 3, "n, x, derivative", DEF(0, 0, 0), sph_in((int)x[0], x[1], x[2] != 0),
      sph_in((int)z[0].real(), z[1], z[2].real() != 0))
  UFC("spherical_kn", 2, 3, "n, x, derivative", DEF(0, 0, 0), sph_kn((int)x[0], x[1], x[2] != 0),
      sph_kn((int)z[0].real(), z[1], z[2].real() != 0))

  SP_ADD("riccati_jn", 2, 2, "n, x") {
    long long n;
    double x;
    if (!countArg(a, 0, ctx, n, 0) || !argNumber(a, 1, ctx, x))
      return Value(0.0);
    Vec s(n + 1), sp(n + 1);
    for (long long k = 0; k <= n; k++) {
      double j = sph_jn((int)k, x, false), jp = sph_jn((int)k, x, true);
      s[k] = x * j;
      sp[k] = j + x * jp;
    }
    return makeDict({{"jn", toValue(s)}, {"jnp", toValue(sp)}});
  } SP_END

  SP_ADD("riccati_yn", 2, 2, "n, x") {
    long long n;
    double x;
    if (!countArg(a, 0, ctx, n, 0) || !argNumber(a, 1, ctx, x))
      return Value(0.0);
    Vec s(n + 1), sp(n + 1);
    for (long long k = 0; k <= n; k++) {
      double y = sph_yn((int)k, x, false), yp = sph_yn((int)k, x, true);
      s[k] = x * y;
      sp[k] = y + x * yp;
    }
    return makeDict({{"yn", toValue(s)}, {"ynp", toValue(sp)}});
  } SP_END

  SP_ADD("lmbda", 2, 2, "v, x") {
    double v, x;
    if (!argNumber(a, 0, ctx, v) || !argNumber(a, 1, ctx, x))
      return Value(0.0);
    if (v < 0 || v > 100000) {
      ctx.fail("v must be from 0 to 100000");
      return Value(0.0);
    }
    double v0 = v - std::floor(v);
    int n = static_cast<int>(std::floor(v));
    auto lam = [&](double nu) {
      if (x == 0)
        return 1.0;
      return std::exp(std::lgamma(nu + 1) + nu * std::log(2.0 / std::fabs(x))) * besselj(nu, std::fabs(x));
    };
    Vec vals(n + 1), ders(n + 1);
    for (int k = 0; k <= n; k++) {
      double nu = v0 + k;
      vals[k] = lam(nu);
      ders[k] = -x / (2 * (nu + 1)) * lam(nu + 1);
    }
    return makeDict({{"vals", toValue(vals)}, {"ders", toValue(ders)}});
  } SP_END

  // ---- Airy ----
  SP_ADD("airy", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"Ai", "Aip", "Bi", "Bip"}, [](const cd *z, cd *o) {
      double ai, aip, bi, bip;
      sf::airy(z[0].real(), ai, aip, bi, bip);
      o[0] = ai;
      o[1] = aip;
      o[2] = bi;
      o[3] = bip;
    }, false);
  } SP_END
  SP_ADD("airye", 1, 1, "z") {
    return umapDict(a, ctx, 1, DEF(), {"eAi", "eAip", "eBi", "eBip"}, [](const cd *z, cd *o) {
      double ai, aip, bi, bip, x = z[0].real();
      sf::airye(x, ai, aip, bi, bip);
      if (x < 0) // exp(2/3 x^1.5) is complex there; SciPy gives NaN for the Ai parts
        ai = aip = kNaN;
      o[0] = ai;
      o[1] = aip;
      o[2] = bi;
      o[3] = bip;
    }, false);
  } SP_END

  SP_ADD("ai_zeros", 1, 1, "n") {
    long long n;
    if (!countArg(a, 0, ctx, n))
      return Value(0.0);
    auto Ai = [](double x) { double a1, a2, b1, b2; sf::airy(x, a1, a2, b1, b2); return a1; };
    auto Aip = [](double x) { double a1, a2, b1, b2; sf::airy(x, a1, a2, b1, b2); return a2; };
    Vec za = negZeros(Ai, n), zp = negZeros(Aip, n), ai(n), aip(n);
    for (long long k = 0; k < n; k++) {
      ai[k] = Ai(zp[k]);
      aip[k] = Aip(za[k]);
    }
    return makeDict({{"a", toValue(za)}, {"ap", toValue(zp)}, {"ai", toValue(ai)}, {"aip", toValue(aip)}});
  } SP_END

  SP_ADD("bi_zeros", 1, 1, "n") {
    long long n;
    if (!countArg(a, 0, ctx, n))
      return Value(0.0);
    auto Bi = [](double x) { double a1, a2, b1, b2; sf::airy(x, a1, a2, b1, b2); return b1; };
    auto Bip = [](double x) { double a1, a2, b1, b2; sf::airy(x, a1, a2, b1, b2); return b2; };
    Vec zb = negZeros(Bi, n), zp = negZeros(Bip, n), bi(n), bip(n);
    for (long long k = 0; k < n; k++) {
      bi[k] = Bi(zp[k]);
      bip[k] = Bip(zb[k]);
    }
    return makeDict({{"b", toValue(zb)}, {"bp", toValue(zp)}, {"bi", toValue(bi)}, {"bip", toValue(bip)}});
  } SP_END

  // ---- zeros of Bessel functions ----
  SP_ADD("jn_zeros", 2, 2, "n, nt") {
    long long n, nt;
    if (!countArg(a, 0, ctx, n, 0) || !countArg(a, 1, ctx, nt))
      return Value(0.0);
    return toValue(zerosFrom([n](double x) { return besselj(double(n), x); }, nt, 1e-6, 0.25));
  } SP_END

  SP_ADD("jnp_zeros", 2, 2, "n, nt") {
    long long n, nt;
    if (!countArg(a, 0, ctx, n, 0) || !countArg(a, 1, ctx, nt))
      return Value(0.0);
    return toValue(zerosFrom([n](double x) { return jprime(double(n), x); }, nt, 0.01, 0.25));
  } SP_END

  SP_ADD("yn_zeros", 2, 2, "n, nt") {
    long long n, nt;
    if (!countArg(a, 0, ctx, n, 0) || !countArg(a, 1, ctx, nt))
      return Value(0.0);
    return toValue(zerosFrom([n](double x) { return bessely(double(n), x); }, nt, 1e-3, 0.25));
  } SP_END

  SP_ADD("ynp_zeros", 2, 2, "n, nt") {
    long long n, nt;
    if (!countArg(a, 0, ctx, n, 0) || !countArg(a, 1, ctx, nt))
      return Value(0.0);
    return toValue(zerosFrom([n](double x) { return yprime(double(n), x); }, nt, 1e-3, 0.25));
  } SP_END

  SP_ADD("jnyn_zeros", 2, 2, "n, nt") {
    long long n, nt;
    if (!countArg(a, 0, ctx, n, 0) || !countArg(a, 1, ctx, nt))
      return Value(0.0);
    double v = double(n);
    return makeDict({{"jn", toValue(zerosFrom([v](double x) { return besselj(v, x); }, nt, 1e-6, 0.25))},
                     {"jnp", toValue(zerosFrom([v](double x) { return jprime(v, x); }, nt, 0.01, 0.25))},
                     {"yn", toValue(zerosFrom([v](double x) { return bessely(v, x); }, nt, 1e-3, 0.25))},
                     {"ynp", toValue(zerosFrom([v](double x) { return yprime(v, x); }, nt, 1e-3, 0.25))}});
  } SP_END

  SP_ADD("jnjnp_zeros", 1, 1, "nt") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    struct Z {
      double z;
      int n, m, t;
    };
    std::vector<Z> all;
    for (double X = 8.0;; X *= 1.5) {
      all.clear();
      all.push_back({0.0, 0, 0, 1}); // J0'(0) = 0 is zero number 0 of J0'
      for (int n = 0; n <= static_cast<int>(X); n++) {
        int m = 0;
        double v = n;
        auto fj = [v](double x) { return besselj(v, x); };
        auto fp = [v](double x) { return jprime(v, x); };
        double s = 1e-6, fa = fj(s);
        for (double b = s + 0.2; b < X + 0.2; b += 0.2) {
          double fb = fj(b);
          if ((fa < 0) != (fb < 0))
            all.push_back({brent(fj, b - 0.2, b, 1e-15), n, ++m, 0});
          fa = fb;
        }
        m = 0;
        s = 0.01;
        fa = fp(s);
        for (double b = s + 0.2; b < X + 0.2; b += 0.2) {
          double fb = fp(b);
          if ((fa < 0) != (fb < 0))
            all.push_back({brent(fp, b - 0.2, b, 1e-15), n, ++m, 1});
          fa = fb;
        }
      }
      std::vector<Z> kept;
      for (const Z &z : all)
        if (z.z < X)
          kept.push_back(z);
      if (static_cast<long long>(kept.size()) >= nt + 2 || X > 1e5) {
        std::stable_sort(kept.begin(), kept.end(), [](const Z &p, const Z &q) {
          if (std::fabs(p.z - q.z) > 1e-10)
            return p.z < q.z;
          return p.t < q.t;
        });
        Vec zo, nn, mm, tt;
        for (long long k = 0; k < nt && k < static_cast<long long>(kept.size()); k++) {
          zo.push_back(kept[k].z);
          nn.push_back(kept[k].n);
          mm.push_back(kept[k].m);
          tt.push_back(kept[k].t);
        }
        return makeDict({{"zo", toValue(zo)}, {"n", toValue(nn)}, {"m", toValue(mm)}, {"t", toValue(tt)}});
      }
    }
  } SP_END

  SP_ADD("y0_zeros", 1, 2, "nt, complex") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    Vec z = zerosFrom([](double x) { return bessely(0, x); }, nt, 1e-3, 0.25), d(z.size());
    for (size_t k = 0; k < z.size(); k++)
      d[k] = bessely(1, z[k]); // SciPy reports Y1 at the zeros (= -Y0')
    return makeDict({{"z", toValue(z)}, {"d", toValue(d)}});
  } SP_END

  SP_ADD("y1_zeros", 1, 2, "nt, complex") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    Vec z = zerosFrom([](double x) { return bessely(1, x); }, nt, 1e-3, 0.25), d(z.size());
    for (size_t k = 0; k < z.size(); k++)
      d[k] = bessely(0, z[k]) - bessely(1, z[k]) / z[k];
    return makeDict({{"z", toValue(z)}, {"d", toValue(d)}});
  } SP_END

  SP_ADD("y1p_zeros", 1, 2, "nt, complex") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    Vec z = zerosFrom([](double x) { return yprime(1, x); }, nt, 1e-2, 0.25), d(z.size());
    for (size_t k = 0; k < z.size(); k++)
      d[k] = bessely(1, z[k]);
    return makeDict({{"z", toValue(z)}, {"d", toValue(d)}});
  } SP_END

  // ---- complex zeros of erf and the Fresnel integrals ----
  SP_ADD("erf_zeros", 1, 1, "nt") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    CVec out;
    for (long long n = 1; n <= nt; n++) {
      double r = std::sqrt(PI * (n - 0.125));
      cd z0(r, r);
      out.push_back(newtonC([](cd z) { return sf::erf(z); }, [](cd z) { return 2.0 / SQRTPI * std::exp(-z * z); }, z0));
    }
    return toValue(out);
  } SP_END

  SP_ADD("fresnel_zeros", 1, 1, "nt") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    return makeDict({{"zs", toValue(fresnelZeros(true, nt))}, {"zc", toValue(fresnelZeros(false, nt))}});
  } SP_END
  SP_ADD("fresnels_zeros", 1, 1, "nt") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    return toValue(fresnelZeros(true, nt));
  } SP_END
  SP_ADD("fresnelc_zeros", 1, 1, "nt") {
    long long nt;
    if (!countArg(a, 0, ctx, nt))
      return Value(0.0);
    return toValue(fresnelZeros(false, nt));
  } SP_END

  // ---- Struve ----
  UF("struve", 2, 2, "v, x", DEF(), struve_h(x[0], x[1]))
  UF("modstruve", 2, 2, "v, x", DEF(), struve_l(x[0], x[1]))
  UF("itstruve0", 1, 1, "x", DEF(),
     (std::fabs(x[0]) < 8 ? itStruve0Series(std::fabs(x[0]))
                         : quad([](double t) { return struve_h(0, t); }, 0.0, std::fabs(x[0]), 0.0, 1e-13, 2000)))
  UF("it2struve0", 1, 1, "x", DEF(),
     (x[0] < 0 ? kNaN
               : PI / 2 - quad([](double t) { return t == 0 ? 2.0 / PI : struve_h(0, t) / t; }, 0.0, x[0], 0.0, 1e-13,
                               2000)))
  UF("itmodstruve0", 1, 1, "x", DEF(),
     ([](double x) {
       double ax = std::fabs(x), sum = 0.0;
       for (int k = 0; k < 2000; k++) {
         double t = 2.0 * std::exp((2 * k + 2) * std::log(ax / 2) - 2 * std::lgamma(k + 1.5)) / (2 * k + 2);
         sum += t;
         if (k > ax && t < 1e-17 * sum)
           break;
       }
       return sum;
     })(x[0]))

  // ---- Kelvin ----
  UF("ber", 1, 1, "x", DEF(), kelvin_be(x[0]).real())
  UF("bei", 1, 1, "x", DEF(), kelvin_be(x[0]).imag())
  UF("ker", 1, 1, "x", DEF(), kelvin_ke(x[0]).real())
  UF("kei", 1, 1, "x", DEF(), kelvin_ke(x[0]).imag())
  UF("berp", 1, 1, "x", DEF(), kelvin_bep(x[0]).real())
  UF("beip", 1, 1, "x", DEF(), kelvin_bep(x[0]).imag())
  UF("kerp", 1, 1, "x", DEF(), kelvin_kep(x[0]).real())
  UF("keip", 1, 1, "x", DEF(), kelvin_kep(x[0]).imag())
  SP_ADD("kelvin", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"Be", "Ke", "Bep", "Kep"}, [](const cd *z, cd *o) {
      double x = z[0].real();
      o[0] = kelvin_be(x);
      o[1] = kelvin_ke(x);
      o[2] = kelvin_bep(x);
      o[3] = kelvin_kep(x);
    }, false);
  } SP_END

  {
    using KF = double (*)(double);
    struct KZ {
      const char *name;
      KF f;
      double start;
    };
    static const KZ kz[] = {
        {"ber_zeros", [](double x) { return kelvin_be(x).real(); }, 1e-3},
        {"bei_zeros", [](double x) { return kelvin_be(x).imag(); }, 1e-3},
        {"ker_zeros", [](double x) { return kelvin_ke(x).real(); }, 1e-3},
        {"kei_zeros", [](double x) { return kelvin_ke(x).imag(); }, 1e-3},
        {"berp_zeros", [](double x) { return kelvin_bep(x).real(); }, 1e-3},
        {"beip_zeros", [](double x) { return kelvin_bep(x).imag(); }, 1e-3},
        {"kerp_zeros", [](double x) { return kelvin_kep(x).real(); }, 1e-3},
        {"keip_zeros", [](double x) { return kelvin_kep(x).imag(); }, 1e-3},
    };
    for (const KZ &k : kz) {
      KF f = k.f;
      double st = k.start;
      reg.add(makeSpec(k.name, SP_SEC, 1, 1, "nt", [f, st](const Args &a, CallContext &ctx) -> Value {
        long long nt;
        if (!countArg(a, 0, ctx, nt))
          return Value(0.0);
        return toValue(zeros_of(f, static_cast<int>(nt), st, 0.1));
      }, false));
    }
    SP_ADD("kelvin_zeros", 1, 1, "nt") {
      long long nt;
      if (!countArg(a, 0, ctx, nt))
        return Value(0.0);
      // order: ber, bei, ker, kei, berp, beip, kerp, keip
      KF fs[8] = {kz[0].f, kz[1].f, kz[2].f, kz[3].f, kz[4].f, kz[5].f, kz[6].f, kz[7].f};
      DictInit d;
      for (int i = 0; i < 8; i++)
        d.push_back({"r" + std::to_string(i), toValue(zeros_of(fs[i], static_cast<int>(nt), 1e-3, 0.1))});
      return makeDict(d);
    } SP_END
  }

  // ---- integrals ----
  UF("besselpoly", 3, 3, "a, lmb, nu", DEF(),
     ([](double aa, double lm, double nu) {
       if (lm <= -1)
         return kNaN;
       return quad([&](double t) { return t == 0 ? (lm == 0 && nu == 0 ? 1.0 : 0.0) : std::pow(t, lm) * besselj(nu, 2 * aa * t); },
                   0.0, 1.0, 0.0, 1e-14, 2000);
     })(x[0], x[1], x[2]))

  SP_ADD("itairy", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"Apt", "Bpt", "Ant", "Bnt"}, [](const cd *z, cd *o) {
      double x = z[0].real();
      auto ai = [](double t) { double a1, a2, b1, b2; sf::airy(t, a1, a2, b1, b2); return a1; };
      auto bi = [](double t) { double a1, a2, b1, b2; sf::airy(t, a1, a2, b1, b2); return b1; };
      o[0] = quad(ai, 0.0, x, 0.0, 1e-14, 2000);
      o[1] = quad(bi, 0.0, x, 0.0, 1e-14, 2000);
      o[2] = quad([&](double t) { return ai(-t); }, 0.0, x, 0.0, 1e-14, 2000);
      o[3] = quad([&](double t) { return bi(-t); }, 0.0, x, 0.0, 1e-14, 2000);
    }, false);
  } SP_END

  SP_ADD("iti0k0", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"ii0", "ik0"}, [](const cd *z, cd *o) {
      double x = z[0].real();
      if (x < 0) {
        o[0] = o[1] = kNaN;
        return;
      }
      o[0] = quad([](double t) { return besseli(0, t); }, 0.0, x, 0.0, 1e-14, 2000);
      // t = s^2 removes the logarithm of K0 at 0
      double sx = std::sqrt(x);
      o[1] = quad([](double s) { return s == 0 ? 0.0 : 2 * s * besselk(0, s * s); }, 0.0, sx, 0.0, 1e-14, 2000);
    }, false);
  } SP_END

  SP_ADD("it2i0k0", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"ii0", "ik0"}, [](const cd *z, cd *o) {
      double x = z[0].real();
      if (x < 0) {
        o[0] = o[1] = kNaN;
        return;
      }
      double sum = 0.0;
      for (int k = 1; k < 5000; k++) {
        double t = std::exp(2 * k * std::log(x / 2) - 2 * std::lgamma(k + 1.0)) / (2.0 * k);
        sum += t;
        if (k > x && t < 1e-17 * sum)
          break;
      }
      o[0] = sum;
      o[1] = quad([](double t) { return besselk(0, t) / t; }, x, kInf, 0.0, 1e-13, 2000);
    }, false);
  } SP_END

  SP_ADD("itj0y0", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"ij0", "iy0"}, [](const cd *z, cd *o) {
      double x = z[0].real();
      if (x < 0) {
        o[0] = o[1] = kNaN;
        return;
      }
      o[0] = quad([](double t) { return besselj(0, t); }, 0.0, x, 0.0, 1e-14, 2000);
      double c = std::min(x, 1.0);
      double head = quad([](double s) { return s == 0 ? 0.0 : 2 * s * bessely(0, s * s); }, 0.0, std::sqrt(c), 0.0, 1e-14, 2000);
      o[1] = head + (x > 1 ? quad([](double t) { return bessely(0, t); }, 1.0, x, 0.0, 1e-14, 2000) : 0.0);
    }, false);
  } SP_END

  SP_ADD("it2j0y0", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"ij0", "iy0"}, [](const cd *z, cd *o) {
      double x = z[0].real();
      if (x < 0) {
        o[0] = o[1] = kNaN;
        return;
      }
      o[0] = quad([](double t) { return t == 0 ? 0.0 : (1 - besselj(0, t)) / t; }, 0.0, x, 0.0, 1e-14, 2000);
      o[1] = oscTail([](double t) { return bessely(0, t) / t; }, x, PI);
    }, false);
  } SP_END
}

} // namespace scipy
} // namespace nc
