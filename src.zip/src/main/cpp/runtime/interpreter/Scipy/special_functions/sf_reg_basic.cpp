// Section 20, part 1: gamma and beta families, error functions, exponential
// and logarithmic helpers, combinatorics, elliptic and hypergeometric
// functions, and the cdflib-style distribution functions.
#include "special_functions_main.h"

#include <cmath>
#include <map>
#include <mutex>

#include "sf_poly.h"
#include "sf_ufunc.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::SpecialFunctions
#define DEF(...) std::vector<double>{__VA_ARGS__}
// Element-wise real function: EXPR reads x[0], x[1], ...
#define UF(NAME, MINA, MAXA, PARAMS, DEFS, EXPR)                                                                    \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                                                \
    return umap(a, ctx, MAXA, DEFS, [](const double *x) -> double { return EXPR; });                                \
  }                                                                                                                 \
  SP_END
// Element-wise with a complex version CEXPR reading z[0], ...
#define UFC(NAME, MINA, MAXA, PARAMS, DEFS, EXPR, CEXPR)                                                            \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                                                \
    return umapC(a, ctx, MAXA, DEFS, [](const double *x) -> double { return EXPR; },                                \
                 [](const cd *z) -> cd { return CEXPR; });                                                          \
  }                                                                                                                 \
  SP_ENDC

namespace {
using namespace sf;

double I(double v) { return std::floor(v); }

// special_get_err / special_set_err: NC's kernels return NaN or inf instead of
// raising, so the table only records what the user asked for.
std::mutex g_errMutex;
std::map<std::string, std::string> &errTable() {
  static std::map<std::string, std::string> t = {{"singular", "ignore"}, {"underflow", "ignore"},
                                                 {"overflow", "ignore"}, {"slow", "ignore"},
                                                 {"loss", "ignore"},     {"no_result", "ignore"},
                                                 {"domain", "ignore"},   {"arg", "ignore"},
                                                 {"memory", "ignore"},   {"other", "ignore"}};
  return t;
}
Value errDict() {
  DictInit d;
  for (const auto &kv : errTable())
    d.push_back({kv.first, Value(kv.second)});
  return makeDict(d);
}

cd cexpm1(cd z) {
  double x = z.real(), y = z.imag();
  double s = std::sin(y / 2);
  return cd(std::expm1(x) * std::cos(y) - 2 * s * s, std::exp(x) * std::sin(y));
}

double softplus1(double x) { return x > 0 ? x + std::log1p(std::exp(-x)) : std::log1p(std::exp(x)); }

double exactProduct(double from, double count) {
  double r = 1.0;
  for (double i = 0; i < count; i++)
    r *= from + i;
  return r;
}

double combFn(double n, double k, bool exact, bool rep) {
  if (std::isnan(n) || std::isnan(k))
    return kNaN;
  if (rep)
    n = n + k - 1;
  if (exact) {
    n = std::floor(n);
    k = std::floor(k);
    if (k > n || n < 0 || k < 0)
      return 0.0;
    k = std::min(k, n - k);
    double r = 1.0;
    for (double i = 1; i <= k; i++)
      r = r * (n - k + i) / i;
    return std::round(r);
  }
  if (k > n || n < 0 || k < 0)
    return 0.0;
  return binom(n, k);
}

double permFn(double n, double k, bool exact) {
  if (std::isnan(n) || std::isnan(k))
    return kNaN;
  if (exact) {
    n = std::floor(n);
    k = std::floor(k);
  }
  if (k > n || n < 0 || k < 0)
    return 0.0;
  return exact ? exactProduct(n - k + 1, k) : poch(n - k + 1, k);
}

double fact2(double n) {
  if (std::isnan(n))
    return kNaN;
  n = std::floor(n);
  if (n < 0)
    return 0.0;
  if (n > 301) // beyond the double range
    return kInf;
  double r = 1.0;
  for (double v = n; v > 0; v -= 2)
    r *= v;
  return r;
}

double factk(double n, double k) {
  if (std::isnan(n) || std::isnan(k) || k < 1)
    return kNaN;
  n = std::floor(n);
  if (n < 0)
    return 0.0;
  if (std::isinf(n))
    return kInf;
  double r = 1.0;
  for (double v = n; v > 0 && std::isfinite(r); v -= k) // stops once the product overflows
    r *= v;
  return r;
}

double stirling2Fn(double nn, double kk) {
  if (std::isnan(nn) || std::isnan(kk))
    return kNaN;
  long long n = static_cast<long long>(std::floor(nn)), k = static_cast<long long>(std::floor(kk));
  if (n < 0 || k < 0 || k > n)
    return 0.0;
  if (n == 0)
    return k == 0 ? 1.0 : 0.0;
  if (k == 0)
    return 0.0;
  if (n > 5000) // keep the table small; S(n, k) overflows long before
    return kInf;
  std::vector<double> row(k + 1, 0.0);
  row[0] = 1.0; // S(0,0)
  for (long long i = 1; i <= n; i++) {
    for (long long j = std::min(i, k); j >= 1; j--)
      row[j] = j * row[j] + row[j - 1];
    row[0] = 0.0;
  }
  return row[k];
}

double diricFn(double x, double n) {
  if (std::isnan(x) || std::isnan(n) || n < 1 || n != std::floor(n))
    return kNaN;
  double half = std::sin(x / 2);
  if (std::fabs(half) < 1e-15) {
    double k = std::round(x / (2 * PI));
    double e = k * (n - 1);
    return std::fmod(std::fabs(e), 2.0) == 1.0 ? -1.0 : 1.0;
  }
  return std::sin(n * x / 2) / (n * half);
}

// Softmax family along an axis (-1/omitted = all elements).
bool axisArg(const Args &a, size_t i, CallContext &ctx, int &axis) {
  // left out or "all": every element; 0 / -2: down the columns; 1 / -1: along the rows
  axis = -1;
  if (i >= a.size() || (a[i].isText && (a[i].text() == "all" || a[i].text() == "none")))
    return true;
  if (!isPlainNumber(a[i]) || a[i].number != std::floor(a[i].number) || a[i].number < -2 || a[i].number > 1) {
    ctx.fail("the axis must be 0 (down the columns), 1 (along the rows) or \"all\"");
    return false;
  }
  axis = static_cast<int>(a[i].number);
  axis = axis == -2 ? 0 : (axis == -1 ? 1 : axis);
  return true;
}

template <class F> Mat alongAxis(const Mat &m, int axis, F f) {
  // f(values, out) works on one slice
  Mat out(m.r, m.c);
  if (axis < 0) {
    Vec v = m.a, o(v.size());
    f(v, o);
    out.a = o;
    return out;
  }
  if (axis == 1 || m.r == 1) {
    for (size_t i = 0; i < m.r; i++) {
      Vec v(m.row(i), m.row(i) + m.c), o(m.c);
      f(v, o);
      std::copy(o.begin(), o.end(), out.row(i));
    }
  } else {
    for (size_t j = 0; j < m.c; j++) {
      Vec v(m.r), o(m.r);
      for (size_t i = 0; i < m.r; i++)
        v[i] = m(i, j);
      f(v, o);
      for (size_t i = 0; i < m.r; i++)
        out(i, j) = o[i];
    }
  }
  return out;
}

void softmaxSlice(const Vec &v, Vec &o, bool log) {
  double mx = -kInf;
  for (double x : v)
    mx = std::max(mx, x);
  double s = 0.0;
  for (double x : v)
    s += std::exp(x - mx);
  double ls = std::log(s);
  for (size_t i = 0; i < v.size(); i++)
    o[i] = log ? v[i] - mx - ls : std::exp(v[i] - mx - ls);
}

double lse(const Vec &v, const Vec *b) {
  double mx = -kInf;
  for (size_t i = 0; i < v.size(); i++)
    if (!b || (*b)[i] != 0)
      mx = std::max(mx, v[i]);
  if (std::isinf(mx))
    return mx;
  double s = 0.0;
  for (size_t i = 0; i < v.size(); i++)
    s += (b ? (*b)[i] : 1.0) * std::exp(v[i] - mx);
  if (s < 0)
    return kNaN;
  return mx + std::log(s);
}

} // namespace

void registerSfBasic(Registry &reg) {
  // ---- error state ----
  SP_ADD("special_get_err", 0, 0, "") {
    std::lock_guard<std::mutex> lock(g_errMutex);
    return errDict();
  } SP_END

  SP_ADD("special_set_err", 2, 2, "kind, action") {
    std::string kind, action;
    if (!argText(a, 0, ctx, kind) || !argText(a, 1, ctx, action))
      return Value(0.0);
    if (action != "ignore" && action != "warn" && action != "raise" && action != "print" && action != "call") {
      ctx.fail("the action must be \"ignore\", \"warn\" or \"raise\"");
      return Value(0.0);
    }
    std::lock_guard<std::mutex> lock(g_errMutex);
    Value old = errDict();
    auto &t = errTable();
    if (kind == "all") {
      for (auto &kv : t)
        kv.second = action;
    } else if (t.count(kind)) {
      t[kind] = action;
    } else {
      ctx.fail("unknown error kind '" + kind + "' - use \"singular\", \"underflow\", \"overflow\", \"slow\", \"loss\", "
               "\"no_result\", \"domain\", \"arg\", \"other\" or \"all\"");
      return Value(0.0);
    }
    return old;
  } SP_END

  // ---- gamma family ----
  UFC("gamma", 1, 1, "x", DEF(), sf::gamma(x[0]), sf::gamma(z[0]))
  UF("gammaln", 1, 1, "x", DEF(), lgam(x[0]))
  UFC("loggamma", 1, 1, "z", DEF(), (x[0] < 0 ? kNaN : (x[0] == 0 ? kInf : std::lgamma(x[0]))), sf::loggamma(z[0]))
  UFC("rgamma", 1, 1, "x", DEF(), rgamma(x[0]), (1.0 / sf::gamma(z[0])))
  UF("gammasgn", 1, 1, "x", DEF(), gammasgn(x[0]))
  UFC("digamma", 1, 1, "x", DEF(), digamma(x[0]), digamma(z[0]))
  UF("polygamma", 2, 2, "n, x", DEF(), (x[0] != I(x[0]) ? kNaN : polygamma(static_cast<int>(x[0]), x[1])))
  UF("multigammaln", 2, 2, "a, d", DEF(),
     (x[1] < 1 || x[1] != I(x[1]) || x[0] <= (x[1] - 1) / 2 ? kNaN : multigammaln(x[0], static_cast<int>(x[1]))))
  UF("zeta", 1, 2, "x, q", DEF(0, kNaN), (std::isnan(x[1]) ? riemann_zeta(x[0]) : zeta(x[0], x[1])))
  UF("zetac", 1, 1, "x", DEF(), zetac(x[0]))
  UF("beta", 2, 2, "a, b", DEF(), sf::beta(x[0], x[1]))
  UF("betaln", 2, 2, "a, b", DEF(), lbeta(x[0], x[1]))
  UF("binom", 2, 2, "n, k", DEF(), binom(x[0], x[1]))
  UF("poch", 2, 2, "z, m", DEF(), poch(x[0], x[1]))
  UF("betainc", 3, 3, "a, b, x", DEF(), betainc(x[0], x[1], x[2]))
  UF("betaincc", 3, 3, "a, b, x", DEF(), betaincc(x[0], x[1], x[2]))
  UF("betaincinv", 3, 3, "a, b, y", DEF(), betaincinv(x[0], x[1], x[2]))
  UF("betainccinv", 3, 3, "a, b, y", DEF(), betainccinv(x[0], x[1], x[2]))
  UF("gammainc", 2, 2, "a, x", DEF(), gammainc(x[0], x[1]))
  UF("gammaincc", 2, 2, "a, x", DEF(), gammaincc(x[0], x[1]))
  UF("gammaincinv", 2, 2, "a, y", DEF(), gammaincinv(x[0], x[1]))
  UF("gammainccinv", 2, 2, "a, y", DEF(), gammainccinv(x[0], x[1]))

  // ---- error functions ----
  UFC("erf", 1, 1, "x", DEF(), std::erf(x[0]), sf::erf(z[0]))
  UFC("erfc", 1, 1, "x", DEF(), std::erfc(x[0]), sf::erfc(z[0]))
  UFC("erfcx", 1, 1, "x", DEF(), erfcx(x[0]), erfcx(z[0]))
  UFC("erfi", 1, 1, "x", DEF(), erfi(x[0]), erfi(z[0]))
  UFC("dawsn", 1, 1, "x", DEF(), dawsn(x[0]), dawsn(z[0]))
  UF("erfinv", 1, 1, "y", DEF(), erfinv(x[0]))
  UF("erfcinv", 1, 1, "y", DEF(), erfcinv(x[0]))
  SP_ADD("wofz", 1, 1, "z") {
    return umapToC(a, ctx, 1, DEF(), [](const cd *z) { return faddeeva(z[0]); });
  } SP_ENDC
  UFC("ndtr", 1, 1, "x", DEF(), ndtr(x[0]), (0.5 * sf::erfc(-z[0] / std::sqrt(2.0))))
  UFC("log_ndtr", 1, 1, "x", DEF(), log_ndtr(x[0]), log_ndtr(z[0]))
  UF("ndtri", 1, 1, "p", DEF(), ndtri(x[0]))
  UF("ndtri_exp", 1, 1, "y", DEF(), ndtri_exp(x[0]))
  UF("owens_t", 2, 2, "h, a", DEF(), owens_t(x[0], x[1]))
  UF("voigt_profile", 3, 3, "x, sigma, gamma", DEF(), voigt(x[0], x[1], x[2]))

  // ---- exponential and logarithmic helpers ----
  UFC("exp1", 1, 1, "x", DEF(), exp1(x[0]), exp1(z[0]))
  UFC("expi", 1, 1, "x", DEF(), expi(x[0]), expi(z[0]))
  UF("expn", 2, 2, "n, x", DEF(), (x[0] != I(x[0]) ? kNaN : expn(static_cast<int>(x[0]), x[1])))
  UF("exprel", 1, 1, "x", DEF(), (x[0] == 0 ? 1.0 : (std::isinf(x[0]) && x[0] > 0 ? kInf : std::expm1(x[0]) / x[0])))
  UF("expit", 1, 1, "x", DEF(), (x[0] >= 0 ? 1.0 / (1.0 + std::exp(-x[0])) : std::exp(x[0]) / (1.0 + std::exp(x[0]))))
  UF("log_expit", 1, 1, "x", DEF(), (x[0] >= 0 ? -std::log1p(std::exp(-x[0])) : x[0] - std::log1p(std::exp(x[0]))))
  UF("logit", 1, 1, "p", DEF(), (x[0] < 0 || x[0] > 1 ? kNaN : std::log(x[0] / (1 - x[0]))))
  UF("exp10", 1, 1, "x", DEF(), std::pow(10.0, x[0]))
  UFC("expm1", 1, 1, "x", DEF(), std::expm1(x[0]), cexpm1(z[0]))
  UF("cosm1", 1, 1, "x", DEF(), (-2.0 * std::sin(x[0] / 2) * std::sin(x[0] / 2)))
  UF("powm1", 2, 2, "x, y", DEF(),
     (x[1] == 0 ? 0.0
                : (x[0] > 0 ? std::expm1(x[1] * std::log(x[0]))
                            : (x[0] == 0 ? (x[1] < 0 ? kInf : -1.0)
                                         : (x[1] == I(x[1]) ? std::pow(x[0], x[1]) - 1.0 : kNaN)))))
  UF("xlogy", 2, 2, "x, y", DEF(), (x[0] == 0 && !std::isnan(x[1]) ? 0.0 : x[0] * std::log(x[1])))
  UF("xlog1py", 2, 2, "x, y", DEF(), (x[0] == 0 && !std::isnan(x[1]) ? 0.0 : x[0] * std::log1p(x[1])))
  UF("entr", 1, 1, "x", DEF(), (std::isnan(x[0]) ? kNaN : (x[0] > 0 ? -x[0] * std::log(x[0]) : (x[0] == 0 ? 0.0 : -kInf))))
  UF("rel_entr", 2, 2, "x, y", DEF(),
     (std::isnan(x[0]) || std::isnan(x[1]) ? kNaN
                                           : (x[0] > 0 && x[1] > 0 ? x[0] * std::log(x[0] / x[1])
                                                                   : (x[0] == 0 && x[1] >= 0 ? 0.0 : kInf))))
  UF("kl_div", 2, 2, "x, y", DEF(),
     (std::isnan(x[0]) || std::isnan(x[1]) ? kNaN
                                           : (x[0] > 0 && x[1] > 0 ? x[0] * std::log(x[0] / x[1]) - x[0] + x[1]
                                                                   : (x[0] == 0 && x[1] >= 0 ? x[1] : kInf))))
  UF("huber", 2, 2, "delta, r", DEF(),
     (x[0] < 0 ? kInf : (std::fabs(x[1]) <= x[0] ? x[1] * x[1] / 2 : x[0] * (std::fabs(x[1]) - x[0] / 2))))
  UF("pseudo_huber", 2, 2, "delta, r", DEF(),
     (x[0] < 0 ? kInf
               : (x[0] == 0 || x[1] == 0 ? 0.0
                                          : x[0] * x[0] * (std::sqrt(1 + (x[1] / x[0]) * (x[1] / x[0])) - 1))))
  UF("boxcox", 2, 2, "x, lmbda", DEF(),
     (x[1] == 0 ? std::log(x[0]) : std::expm1(x[1] * std::log(x[0])) / x[1]))
  UF("boxcox1p", 2, 2, "x, lmbda", DEF(),
     (x[1] == 0 ? std::log1p(x[0]) : std::expm1(x[1] * std::log1p(x[0])) / x[1]))
  UF("inv_boxcox", 2, 2, "y, lmbda", DEF(), (x[1] == 0 ? std::exp(x[0]) : std::exp(std::log1p(x[1] * x[0]) / x[1])))
  UF("inv_boxcox1p", 2, 2, "y, lmbda", DEF(),
     (x[1] == 0 ? std::expm1(x[0]) : std::expm1(std::log1p(x[1] * x[0]) / x[1])))
  UF("agm", 2, 2, "a, b", DEF(), agm(x[0], x[1]))
  UF("softplus", 1, 1, "x", DEF(), softplus1(x[0]))
  UF("diric", 2, 2, "x, n", DEF(), diricFn(x[0], x[1]))

  SP_ADD("softmax", 1, 2, "x, axis") {
    Mat m;
    int axis;
    if (!getMat(a, 0, ctx, m) || !axisArg(a, 1, ctx, axis))
      return Value(0.0);
    Mat o = alongAxis(m, axis, [](const Vec &v, Vec &r) { softmaxSlice(v, r, false); });
    return isPlainNumber(a[0]) ? Value(o.a[0]) : toValue(o);
  } SP_END

  SP_ADD("log_softmax", 1, 2, "x, axis") {
    Mat m;
    int axis;
    if (!getMat(a, 0, ctx, m) || !axisArg(a, 1, ctx, axis))
      return Value(0.0);
    Mat o = alongAxis(m, axis, [](const Vec &v, Vec &r) { softmaxSlice(v, r, true); });
    return isPlainNumber(a[0]) ? Value(o.a[0]) : toValue(o);
  } SP_END

  SP_ADD("logsumexp", 1, 3, "x, axis, b") {
    Mat m, bm;
    int axis = -1;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    if (!axisArg(a, 1, ctx, axis))
      return Value(0.0);
    bool haveB = a.size() > 2;
    if (haveB) {
      if (!getMat(a, 2, ctx, bm))
        return Value(0.0);
      if (bm.a.size() == 1)
        bm = Mat(m.r, m.c, bm.a[0]);
      if (bm.a.size() != m.a.size()) {
        ctx.fail("b must have as many elements as x");
        return Value(0.0);
      }
    }
    if (axis < 0 || m.r == 1) {
      return Value(lse(m.a, haveB ? &bm.a : nullptr));
    }
    Vec out;
    if (axis == 1) {
      for (size_t i = 0; i < m.r; i++) {
        Vec v(m.row(i), m.row(i) + m.c), w;
        if (haveB)
          w.assign(bm.row(i), bm.row(i) + m.c);
        out.push_back(lse(v, haveB ? &w : nullptr));
      }
    } else {
      for (size_t j = 0; j < m.c; j++) {
        Vec v(m.r), w(m.r);
        for (size_t i = 0; i < m.r; i++) {
          v[i] = m(i, j);
          if (haveB)
            w[i] = bm(i, j);
        }
        out.push_back(lse(v, haveB ? &w : nullptr));
      }
    }
    return toValue(out);
  } SP_END

  // ---- combinatorics ----
  UF("comb", 2, 4, "n, k, exact, repetition", DEF(0, 0, 0, 0), combFn(x[0], x[1], x[2] != 0, x[3] != 0))
  UF("perm", 2, 3, "n, k, exact", DEF(0, 0, 0), permFn(x[0], x[1], x[2] != 0))
  UF("factorial2", 1, 2, "n, exact", DEF(0, 0), fact2(x[0]))
  UF("factorialk", 2, 3, "n, k, exact", DEF(0, 0, 1), factk(x[0], x[1]))
  UF("stirling2", 2, 3, "n, k, exact", DEF(0, 0, 0), stirling2Fn(x[0], x[1]))

  SP_ADD("bernoulli", 1, 1, "n") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    if (n > 100000) {
      ctx.fail("n is too large");
      return Value(0.0);
    }
    Vec b(n + 1, 0.0);
    b[0] = 1.0;
    if (n >= 1)
      b[1] = -0.5;
    // B_2k = (-1)^(k+1) 2 (2k)! zeta(2k) / (2 pi)^(2k): the ratio (2k)!/(2 pi)^(2k) built term by term
    double ratio = 1.0;
    for (long long k = 1; k <= n; k++) {
      ratio *= k / (2 * PI);
      if (k % 2 == 0 && k >= 2)
        b[k] = ((k / 2) % 2 ? 1.0 : -1.0) * 2.0 * ratio * riemann_zeta(double(k));
      if (!std::isfinite(ratio))
        break;
    }
    return toValue(b);
  } SP_END

  SP_ADD("euler_numbers", 1, 1, "n") {
    long long n;
    if (!argNonNegativeInt(a, 0, ctx, n))
      return Value(0.0);
    if (n > 100000) {
      ctx.fail("n is too large");
      return Value(0.0);
    }
    Vec e(n + 1, 0.0);
    for (long long k = 0; k <= n; k += 2) {
      // E_k = (-1)^(k/2) 2^(k+2) k! beta(k+1) / pi^(k+1), beta = Dirichlet beta via Hurwitz zeta
      double s = k + 1.0;
      double dbeta = std::pow(4.0, -s) * (zeta(s, 0.25) - zeta(s, 0.75));
      double l = (k + 2) * std::log(2.0) + std::lgamma(k + 1.0) - (k + 1) * std::log(PI);
      double v = std::exp(l) * dbeta;
      e[k] = ((k / 2) % 2 ? -1.0 : 1.0) * std::round(v);
      if (k > 30)
        e[k] = ((k / 2) % 2 ? -1.0 : 1.0) * v;
    }
    return toValue(e);
  } SP_END

  // ---- Lambert W, Wright omega, dilogarithm ----
  SP_ADD("lambertw", 1, 3, "z, k, tol") {
    return umapToC(a, ctx, 3, DEF(0, 0, 1e-8), [](const cd *z) {
      return lambertw(z[0], static_cast<int>(z[1].real()), z[2].real() > 0 ? z[2].real() : 1e-8);
    });
  } SP_ENDC
  UFC("wrightomega", 1, 1, "z", DEF(), wrightomega(x[0]), wrightomega(z[0]))
  UFC("spence", 1, 1, "z", DEF(), spence(x[0]), spence(z[0]))

  // ---- integrals returning pairs ----
  SP_ADD("sici", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"si", "ci"}, [](const cd *z, cd *o) {
      if (z[0].imag() == 0) {
        double s, c;
        sici(z[0].real(), s, c);
        o[0] = s;
        o[1] = c;
      } else
        sici(z[0], o[0], o[1]);
    }, true);
  } SP_ENDC
  SP_ADD("shichi", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"shi", "chi"}, [](const cd *z, cd *o) {
      if (z[0].imag() == 0) {
        double s, c;
        shichi(z[0].real(), s, c);
        o[0] = s;
        o[1] = c;
      } else
        shichi(z[0], o[0], o[1]);
    }, true);
  } SP_ENDC
  SP_ADD("fresnel", 1, 1, "z") {
    return umapDict(a, ctx, 1, DEF(), {"S", "C"}, [](const cd *z, cd *o) {
      if (z[0].imag() == 0) {
        double s, c;
        fresnel(z[0].real(), s, c);
        o[0] = s;
        o[1] = c;
      } else
        fresnel(z[0], o[0], o[1]);
    }, true);
  } SP_ENDC
  SP_ADD("modfresnelp", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"fp", "kp"}, [](const cd *z, cd *o) {
      // F+(x) = int_x^inf e^{i t^2} dt, K+ = e^{-i(x^2 + pi/4)} F+ / sqrt(pi)
      double x = z[0].real(), u = x * std::sqrt(2.0 / PI), s, c;
      fresnel(u, s, c);
      cd f = SQRTPI / 2.0 * std::exp(cd(0, PI / 4)) - std::sqrt(PI / 2) * cd(c, s);
      o[0] = f;
      o[1] = std::exp(cd(0, -(x * x + PI / 4))) * f / SQRTPI;
    }, false);
  } SP_END
  SP_ADD("modfresnelm", 1, 1, "x") {
    return umapDict(a, ctx, 1, DEF(), {"fm", "km"}, [](const cd *z, cd *o) {
      double x = z[0].real(), u = x * std::sqrt(2.0 / PI), s, c;
      fresnel(u, s, c);
      cd f = SQRTPI / 2.0 * std::exp(cd(0, -PI / 4)) - std::sqrt(PI / 2) * cd(c, -s);
      o[0] = f;
      o[1] = std::exp(cd(0, x * x + PI / 4)) * f / SQRTPI;
    }, false);
  } SP_END

  // ---- Kolmogorov-Smirnov ----
  UF("kolmogorov", 1, 1, "y", DEF(), kolmogorov(x[0]))
  UF("kolmogi", 1, 1, "p", DEF(), kolmogi(x[0]))
  UF("smirnov", 2, 2, "n, d", DEF(), (x[0] != I(x[0]) ? kNaN : smirnov(static_cast<int>(x[0]), x[1])))
  UF("smirnovi", 2, 2, "n, p", DEF(), (x[0] != I(x[0]) ? kNaN : smirnovi(static_cast<int>(x[0]), x[1])))

  // ---- elliptic ----
  UF("ellipk", 1, 1, "m", DEF(), ellipk(x[0]))
  UF("ellipkm1", 1, 1, "p", DEF(), ellipkm1(x[0]))
  UF("ellipe", 1, 1, "m", DEF(), ellipe(x[0]))
  UF("ellipkinc", 2, 2, "phi, m", DEF(), (x[1] > 1 ? kNaN : ellipkinc(x[0], x[1])))
  UF("ellipeinc", 2, 2, "phi, m", DEF(), (x[1] > 1 ? kNaN : ellipeinc(x[0], x[1])))
  SP_ADD("ellipj", 2, 2, "u, m") {
    return umapDict(a, ctx, 2, DEF(), {"sn", "cn", "dn", "ph"}, [](const cd *z, cd *o) {
      double sn, cn, dn, ph;
      ellipj(z[0].real(), z[1].real(), sn, cn, dn, ph);
      o[0] = sn;
      o[1] = cn;
      o[2] = dn;
      o[3] = ph;
    }, false);
  } SP_END
  UF("elliprc", 2, 2, "x, y", DEF(), elliprc(x[0], x[1]))
  UF("elliprd", 3, 3, "x, y, z", DEF(), elliprd(x[0], x[1], x[2]))
  UF("elliprf", 3, 3, "x, y, z", DEF(), elliprf(x[0], x[1], x[2]))
  UF("elliprg", 3, 3, "x, y, z", DEF(), elliprg(x[0], x[1], x[2]))
  UF("elliprj", 4, 4, "x, y, z, p", DEF(), elliprj(x[0], x[1], x[2], x[3]))

  // ---- hypergeometric ----
  UFC("hyp0f1", 2, 2, "b, z", DEF(), hyp0f1(x[0], x[1]), hyp0f1(z[0].real(), z[1]))
  UF("hyp1f1", 3, 3, "a, b, x", DEF(), hyp1f1(x[0], x[1], x[2]))
  UFC("hyp2f1", 4, 4, "a, b, c, z", DEF(), hyp2f1(x[0], x[1], x[2], x[3]),
      hyp2f1(z[0].real(), z[1].real(), z[2].real(), z[3]))
  UF("hyperu", 3, 3, "a, b, x", DEF(), hyperu(x[0], x[1], x[2]))
  UF("wright_bessel", 3, 3, "a, b, x", DEF(), wright_bessel(x[0], x[1], x[2]))
  UF("log_wright_bessel", 3, 3, "a, b, x", DEF(), log_wright_bessel(x[0], x[1], x[2]))

  // ---- cdflib-style distribution functions ----
  UF("bdtr", 3, 3, "k, n, p", DEF(), bdtr(x[0], x[1], x[2]))
  UF("bdtrc", 3, 3, "k, n, p", DEF(), bdtrc(x[0], x[1], x[2]))
  UF("bdtri", 3, 3, "k, n, y", DEF(), bdtri(x[0], x[1], x[2]))
  UF("bdtrik", 3, 3, "y, n, p", DEF(), bdtrik(x[0], x[1], x[2]))
  UF("bdtrin", 3, 3, "k, y, p", DEF(), bdtrin(x[0], x[1], x[2]))
  UF("btdtria", 3, 3, "p, b, x", DEF(), btdtria(x[0], x[1], x[2]))
  UF("btdtrib", 3, 3, "a, p, x", DEF(), btdtrib(x[0], x[1], x[2]))
  UF("chdtr", 2, 2, "v, x", DEF(), chdtr(x[0], x[1]))
  UF("chdtrc", 2, 2, "v, x", DEF(), chdtrc(x[0], x[1]))
  UF("chdtri", 2, 2, "v, p", DEF(), chdtri(x[0], x[1]))
  UF("chdtriv", 2, 2, "p, x", DEF(), chdtriv(x[0], x[1]))
  UF("chndtr", 3, 3, "x, df, nc", DEF(), chndtr(x[0], x[1], x[2]))
  UF("chndtridf", 3, 3, "x, p, nc", DEF(), chndtridf(x[0], x[1], x[2]))
  UF("chndtrinc", 3, 3, "x, df, p", DEF(), chndtrinc(x[0], x[1], x[2]))
  UF("chndtrix", 3, 3, "p, df, nc", DEF(), chndtrix(x[0], x[1], x[2]))
  UF("fdtr", 3, 3, "dfn, dfd, x", DEF(), fdtr(x[0], x[1], x[2]))
  UF("fdtrc", 3, 3, "dfn, dfd, x", DEF(), fdtrc(x[0], x[1], x[2]))
  UF("fdtri", 3, 3, "dfn, dfd, p", DEF(), fdtri(x[0], x[1], x[2]))
  UF("fdtridfd", 3, 3, "dfn, p, x", DEF(), fdtridfd(x[0], x[1], x[2]))
  UF("gdtr", 3, 3, "a, b, x", DEF(), gdtr(x[0], x[1], x[2]))
  UF("gdtrc", 3, 3, "a, b, x", DEF(), gdtrc(x[0], x[1], x[2]))
  UF("gdtria", 3, 3, "p, b, x", DEF(), gdtria(x[0], x[1], x[2]))
  UF("gdtrib", 3, 3, "a, p, x", DEF(), gdtrib(x[0], x[1], x[2]))
  UF("gdtrix", 3, 3, "a, b, p", DEF(), gdtrix(x[0], x[1], x[2]))
  UF("nbdtr", 3, 3, "k, n, p", DEF(), nbdtr(x[0], x[1], x[2]))
  UF("nbdtrc", 3, 3, "k, n, p", DEF(), nbdtrc(x[0], x[1], x[2]))
  UF("nbdtri", 3, 3, "k, n, y", DEF(), nbdtri(x[0], x[1], x[2]))
  UF("nbdtrik", 3, 3, "y, n, p", DEF(), nbdtrik(x[0], x[1], x[2]))
  UF("nbdtrin", 3, 3, "k, y, p", DEF(), nbdtrin(x[0], x[1], x[2]))
  UF("ncfdtr", 4, 4, "dfn, dfd, nc, f", DEF(), ncfdtr(x[0], x[1], x[2], x[3]))
  UF("ncfdtri", 4, 4, "dfn, dfd, nc, p", DEF(), ncfdtri(x[0], x[1], x[2], x[3]))
  UF("ncfdtridfd", 4, 4, "dfn, p, nc, f", DEF(), ncfdtridfd(x[0], x[1], x[2], x[3]))
  UF("ncfdtridfn", 4, 4, "p, dfd, nc, f", DEF(), ncfdtridfn(x[0], x[1], x[2], x[3]))
  UF("ncfdtrinc", 4, 4, "dfn, dfd, p, f", DEF(), ncfdtrinc(x[0], x[1], x[2], x[3]))
  UF("nctdtr", 3, 3, "df, nc, t", DEF(), nctdtr(x[0], x[1], x[2]))
  UF("nctdtridf", 3, 3, "p, nc, t", DEF(), nctdtridf(x[0], x[1], x[2]))
  UF("nctdtrinc", 3, 3, "df, p, t", DEF(), nctdtrinc(x[0], x[1], x[2]))
  UF("nctdtrit", 3, 3, "df, nc, p", DEF(), nctdtrit(x[0], x[1], x[2]))
  UF("nrdtrimn", 3, 3, "p, std, x", DEF(), nrdtrimn(x[0], x[1], x[2]))
  UF("nrdtrisd", 3, 3, "mn, p, x", DEF(), nrdtrisd(x[0], x[1], x[2]))
  UF("pdtr", 2, 2, "k, m", DEF(), pdtr(x[0], x[1]))
  UF("pdtrc", 2, 2, "k, m", DEF(), pdtrc(x[0], x[1]))
  UF("pdtri", 2, 2, "k, y", DEF(), pdtri(x[0], x[1]))
  UF("pdtrik", 2, 2, "p, m", DEF(), pdtrik(x[0], x[1]))
  UF("stdtr", 2, 2, "df, t", DEF(), stdtr(x[0], x[1]))
  UF("stdtridf", 2, 2, "p, t", DEF(), stdtridf(x[0], x[1]))
  UF("stdtrit", 2, 2, "df, p", DEF(), stdtrit(x[0], x[1]))
  UF("tklmbda", 2, 2, "x, lmbda", DEF(), tklmbda(x[0], x[1]))
}

} // namespace scipy
} // namespace nc
