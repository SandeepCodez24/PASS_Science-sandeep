// Distribution functions in the style of cdflib (bdtr, chdtr, fdtr, ...):
// the cumulative functions through the incomplete gamma and beta functions,
// their inverses, and the noncentral chi-square, F and t distributions.
#include "sf_poly.h"

#include <algorithm>
#include <cmath>

namespace nc {
namespace scipy {
namespace sf {

double cdf_search(const std::function<double(double)> &F, double target, double lo, double hi, bool logScale) {
  // As cdflib's dinvr: look at both ends first and return the better bound
  // when the target is not bracketed; otherwise step out from a start value
  // (doubling the step) to the nearest crossing, then refine with Brent.
  if (std::isnan(target))
    return NaN;
  auto toX = [&](double u) { return logScale ? std::exp(u) : u; };
  auto g = [&](double u) { return F(toX(u)) - target; };
  double a = logScale ? std::log(lo) : lo, b = logScale ? std::log(hi) : hi;
  double fa = g(a), fb = g(b);
  for (int i = 0; i < 60 && std::isnan(fa); i++) {
    a += (b - a) / 8;
    fa = g(a);
  }
  for (int i = 0; i < 60 && std::isnan(fb); i++) {
    b -= (b - a) / 8;
    fb = g(b);
  }
  if (std::isnan(fa) || std::isnan(fb))
    return NaN;
  if (fa == 0)
    return toX(a);
  if (fb == 0)
    return toX(b);
  if ((fa > 0) == (fb > 0))
    return toX(std::fabs(fa) <= std::fabs(fb) ? a : b);
  double u = logScale ? std::min(std::max(std::log(5.0), a), b) : 0.5 * (a + b);
  double fu = g(u);
  if (std::isnan(fu) || fu == 0)
    return std::isnan(fu) ? toX(brent(g, a, b, 1e-15, 500)) : toX(u);
  // the crossing lies toward the end whose sign differs from f(u)
  int dir = ((fu > 0) == (fa > 0)) ? 1 : -1;
  double step = logScale ? 0.5 : (b - a) / 16;
  for (int it = 0; it < 400; it++) {
    double w = dir > 0 ? std::min(u + step, b) : std::max(u - step, a);
    double fw = (w == a) ? fa : (w == b ? fb : g(w));
    if (std::isnan(fw))
      break;
    if (fw == 0)
      return toX(w);
    if ((fw > 0) != (fu > 0)) {
      double l = std::min(u, w), r = std::max(u, w);
      return toX(brent(g, l, r, 1e-15 * std::max(1.0, std::fabs(r)), 500));
    }
    u = w;
    fu = fw;
    step *= 2;
  }
  return toX(brent(g, a, b, 1e-15, 500));
}

namespace {
// sum_j Poisson(lam, j) * term(j), summed outward from the mode.
template <class F> double poissonMix(double lam, F term) {
  if (lam == 0)
    return term(0);
  long long j0 = static_cast<long long>(std::floor(lam));
  double w0 = std::exp(-lam + j0 * std::log(lam) - std::lgamma(j0 + 1.0));
  double sum = 0.0, w = w0;
  for (long long j = j0; j < j0 + 100000; j++) {
    double t = w * term(static_cast<double>(j));
    sum += t;
    if (w < 1e-18 * std::max(sum, 1e-300) || w < 1e-300)
      break;
    w *= lam / (j + 1.0);
  }
  w = w0;
  for (long long j = j0 - 1; j >= 0; j--) {
    w *= (j + 1.0) / lam;
    double t = w * term(static_cast<double>(j));
    sum += t;
    if (w < 1e-18 * std::max(sum, 1e-300) || w < 1e-300)
      break;
  }
  return sum;
}
const double BLO = 1e-100, BHI = 1e100;
} // namespace

// ---- binomial ----

double bdtr(double k, double n, double p) {
  if (std::isnan(k) || std::isnan(n) || std::isnan(p) || p < 0 || p > 1 || n < 0)
    return NaN;
  k = std::floor(k);
  n = std::floor(n);
  if (k < 0)
    return 0.0;
  if (k >= n)
    return 1.0;
  return betainc(n - k, k + 1, 1.0 - p);
}

double bdtrc(double k, double n, double p) {
  if (std::isnan(k) || std::isnan(n) || std::isnan(p) || p < 0 || p > 1 || n < 0)
    return NaN;
  k = std::floor(k);
  n = std::floor(n);
  if (k < 0)
    return 1.0;
  if (k >= n)
    return 0.0;
  return betainc(k + 1, n - k, p);
}

double bdtri(double k, double n, double y) {
  if (std::isnan(k) || std::isnan(n) || std::isnan(y) || y < 0 || y > 1)
    return NaN;
  k = std::floor(k);
  n = std::floor(n);
  if (k < 0 || k >= n)
    return NaN;
  return betainccinv(k + 1, n - k, y);
}

double bdtrik(double y, double n, double p) {
  if (std::isnan(y) || std::isnan(n) || std::isnan(p) || y < 0 || y > 1 || p < 0 || p > 1 || n < 0)
    return NaN;
  auto F = [&](double k) { return k >= n ? 1.0 : betainc(n - k, k + 1, 1.0 - p); };
  return cdf_search(F, y, 0.0, n, false);
}

double bdtrin(double k, double y, double p) {
  if (std::isnan(y) || std::isnan(k) || std::isnan(p) || y < 0 || y > 1 || p < 0 || p > 1 || k < 0)
    return NaN;
  auto F = [&](double n) { return n <= k ? 1.0 : betainc(n - k, k + 1, 1.0 - p); };
  return cdf_search(F, y, std::max(k, BLO), BHI, true);
}

double btdtria(double p, double b, double x) {
  if (std::isnan(p) || std::isnan(b) || std::isnan(x) || p < 0 || p > 1 || b <= 0 || x < 0 || x > 1)
    return NaN;
  return cdf_search([&](double a) { return betainc(a, b, x); }, p, BLO, BHI, true);
}

double btdtrib(double a, double p, double x) {
  if (std::isnan(p) || std::isnan(a) || std::isnan(x) || p < 0 || p > 1 || a <= 0 || x < 0 || x > 1)
    return NaN;
  return cdf_search([&](double b) { return betainc(a, b, x); }, p, BLO, BHI, true);
}

// ---- chi-square ----

double chdtr(double v, double x) {
  if (std::isnan(v) || std::isnan(x) || v <= 0)
    return NaN;
  if (x <= 0)
    return 0.0;
  return gammainc(v / 2, x / 2);
}

double chdtrc(double v, double x) {
  if (std::isnan(v) || std::isnan(x) || v <= 0)
    return NaN;
  if (x <= 0)
    return 1.0;
  return gammaincc(v / 2, x / 2);
}

double chdtri(double v, double p) {
  if (std::isnan(v) || std::isnan(p) || v <= 0 || p < 0 || p > 1)
    return NaN;
  return 2 * gammainccinv(v / 2, p);
}

double chdtriv(double p, double x) {
  if (std::isnan(p) || std::isnan(x) || p < 0 || p > 1 || x < 0)
    return NaN;
  return cdf_search([&](double v) { return chdtr(v, x); }, p, BLO, BHI, true);
}

double chndtr(double x, double df, double nc) {
  if (std::isnan(x) || std::isnan(df) || std::isnan(nc) || df <= 0 || nc < 0)
    return NaN;
  if (x <= 0)
    return 0.0;
  if (std::isinf(x))
    return 1.0;
  double s = poissonMix(nc / 2, [&](double j) { return gammainc(df / 2 + j, x / 2); });
  return std::min(1.0, s);
}

double chndtridf(double x, double p, double nc) {
  if (std::isnan(x) || std::isnan(p) || std::isnan(nc) || p < 0 || p > 1 || x < 0 || nc < 0)
    return NaN;
  return cdf_search([&](double df) { return chndtr(x, df, nc); }, p, BLO, BHI, true);
}

double chndtrinc(double x, double df, double p) {
  if (std::isnan(x) || std::isnan(p) || std::isnan(df) || p < 0 || p > 1 || x < 0 || df <= 0)
    return NaN;
  return cdf_search([&](double nc) { return chndtr(x, df, nc); }, p, BLO, 1e4, true);
}

double chndtrix(double p, double df, double nc) {
  if (std::isnan(df) || std::isnan(p) || std::isnan(nc) || p < 0 || p > 1 || df <= 0 || nc < 0)
    return NaN;
  if (p == 0)
    return 0.0;
  if (p == 1)
    return Inf;
  return cdf_search([&](double x) { return chndtr(x, df, nc); }, p, BLO, BHI, true);
}

double ncx2_pdf(double x, double df, double nc) {
  if (std::isnan(x) || std::isnan(df) || std::isnan(nc) || df <= 0 || nc < 0)
    return NaN;
  if (x < 0)
    return 0.0;
  if (nc == 0) {
    if (x == 0)
      return df < 2 ? Inf : (df == 2 ? 0.5 : 0.0);
    return std::exp((df / 2 - 1) * std::log(x) - x / 2 - (df / 2) * std::log(2.0) - std::lgamma(df / 2));
  }
  if (x == 0)
    return df < 2 ? Inf : (df == 2 ? 0.5 * std::exp(-nc / 2) : 0.0);
  double z = std::sqrt(nc * x);
  double l = -(x + nc) / 2 + z + (df - 2) / 4 * std::log(x / nc);
  return 0.5 * std::exp(l) * besseli(df / 2 - 1, z, true);
}

// ---- F ----

double fdtr(double dfn, double dfd, double x) {
  if (std::isnan(dfn) || std::isnan(dfd) || std::isnan(x) || dfn <= 0 || dfd <= 0)
    return NaN;
  if (x <= 0)
    return 0.0;
  if (std::isinf(x))
    return 1.0;
  double w = dfn * x;
  if (w > dfd) // the beta argument is near 1: use the complement form
    return betaincc(dfd / 2, dfn / 2, dfd / (dfd + w));
  return betainc(dfn / 2, dfd / 2, w / (w + dfd));
}

double fdtrc(double dfn, double dfd, double x) {
  if (std::isnan(dfn) || std::isnan(dfd) || std::isnan(x) || dfn <= 0 || dfd <= 0)
    return NaN;
  if (x <= 0)
    return 1.0;
  if (std::isinf(x))
    return 0.0;
  double w = dfn * x;
  if (w > dfd)
    return betainc(dfd / 2, dfn / 2, dfd / (dfd + w));
  return betaincc(dfn / 2, dfd / 2, w / (w + dfd));
}

double fdtri(double dfn, double dfd, double p) {
  if (std::isnan(dfn) || std::isnan(dfd) || std::isnan(p) || dfn <= 0 || dfd <= 0 || p < 0 || p > 1)
    return NaN;
  if (p > 0.5) {
    double w1 = betaincinv(dfd / 2, dfn / 2, 1 - p); // = 1 - w
    return dfd * (1 - w1) / (dfn * w1);
  }
  double w = betaincinv(dfn / 2, dfd / 2, p);
  return dfd * w / (dfn * (1 - w));
}

double fdtridfd(double dfn, double p, double x) {
  if (std::isnan(dfn) || std::isnan(x) || std::isnan(p) || dfn <= 0 || x < 0 || p < 0 || p > 1)
    return NaN;
  return cdf_search([&](double dfd) { return fdtr(dfn, dfd, x); }, p, BLO, BHI, true);
}

double ncfdtr(double dfn, double dfd, double nc, double f) {
  if (std::isnan(dfn) || std::isnan(dfd) || std::isnan(nc) || std::isnan(f) || dfn <= 0 || dfd <= 0 || nc < 0)
    return NaN;
  if (f <= 0)
    return 0.0;
  if (std::isinf(f))
    return 1.0;
  double w = dfn * f, y = w / (w + dfd), yc = dfd / (w + dfd);
  double s = poissonMix(nc / 2, [&](double j) {
    return y > 0.5 ? betaincc(dfd / 2, dfn / 2 + j, yc) : betainc(dfn / 2 + j, dfd / 2, y);
  });
  return std::min(1.0, s);
}

double ncfdtri(double dfn, double dfd, double nc, double p) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  if (p == 0)
    return 0.0;
  if (p == 1)
    return Inf;
  return cdf_search([&](double f) { return ncfdtr(dfn, dfd, nc, f); }, p, BLO, BHI, true);
}

double ncfdtridfd(double dfn, double p, double nc, double f) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  return cdf_search([&](double dfd) { return ncfdtr(dfn, dfd, nc, f); }, p, BLO, BHI, true);
}

double ncfdtridfn(double p, double dfd, double nc, double f) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  return cdf_search([&](double dfn) { return ncfdtr(dfn, dfd, nc, f); }, p, BLO, BHI, true);
}

double ncfdtrinc(double dfn, double dfd, double p, double f) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  double r = cdf_search([&](double nc) { return ncfdtr(dfn, dfd, nc, f); }, p, BLO, 1e4, true);
  return r <= BLO ? 0.0 : r;
}

double ncf_pdf(double x, double dfn, double dfd, double nc) {
  if (std::isnan(x) || dfn <= 0 || dfd <= 0 || nc < 0)
    return NaN;
  if (x < 0)
    return 0.0;
  double r = dfn / dfd;
  return poissonMix(nc / 2, [&](double j) {
    double n1 = dfn + 2 * j;
    if (x == 0)
      return n1 < 2 ? Inf : (n1 == 2 ? r : 0.0);
    double t = r * x;
    double l = std::log(r) + (n1 / 2 - 1) * std::log(t) - (n1 + dfd) / 2 * std::log1p(t) - lbeta(n1 / 2, dfd / 2);
    return std::exp(l);
  });
}

// ---- gamma ----

double gdtr(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || a <= 0 || b <= 0)
    return NaN;
  if (x <= 0)
    return 0.0;
  return gammainc(b, a * x);
}

double gdtrc(double a, double b, double x) {
  if (std::isnan(a) || std::isnan(b) || std::isnan(x) || a <= 0 || b <= 0)
    return NaN;
  if (x <= 0)
    return 1.0;
  return gammaincc(b, a * x);
}

double gdtria(double p, double b, double x) {
  if (std::isnan(p) || std::isnan(b) || std::isnan(x) || p < 0 || p > 1 || b <= 0 || x <= 0)
    return NaN;
  return gammaincinv(b, p) / x;
}

double gdtrib(double a, double p, double x) {
  if (std::isnan(p) || std::isnan(a) || std::isnan(x) || p < 0 || p > 1 || a <= 0 || x < 0)
    return NaN;
  return cdf_search([&](double b) { return gammainc(b, a * x); }, p, BLO, BHI, true);
}

double gdtrix(double a, double b, double p) {
  if (std::isnan(p) || std::isnan(a) || std::isnan(b) || p < 0 || p > 1 || a <= 0 || b <= 0)
    return NaN;
  return gammaincinv(b, p) / a;
}

// ---- negative binomial ----

double nbdtr(double k, double n, double p) {
  if (std::isnan(k) || std::isnan(n) || std::isnan(p) || p < 0 || p > 1 || n <= 0)
    return NaN;
  k = std::floor(k);
  if (k < 0)
    return 0.0;
  return betainc(n, k + 1, p);
}

double nbdtrc(double k, double n, double p) {
  if (std::isnan(k) || std::isnan(n) || std::isnan(p) || p < 0 || p > 1 || n <= 0)
    return NaN;
  k = std::floor(k);
  if (k < 0)
    return 1.0;
  return betainc(k + 1, n, 1.0 - p);
}

double nbdtri(double k, double n, double y) {
  if (std::isnan(k) || std::isnan(n) || std::isnan(y) || y < 0 || y > 1 || n <= 0)
    return NaN;
  k = std::floor(k);
  if (k < 0)
    return NaN;
  return betaincinv(n, k + 1, y);
}

double nbdtrik(double y, double n, double p) {
  if (std::isnan(y) || std::isnan(n) || std::isnan(p) || y < 0 || y > 1 || p < 0 || p > 1 || n <= 0)
    return NaN;
  double r = cdf_search([&](double k) { return betainc(n, k + 1, p); }, y, BLO, BHI, true);
  return r <= BLO ? 0.0 : r;
}

double nbdtrin(double k, double y, double p) {
  if (std::isnan(y) || std::isnan(k) || std::isnan(p) || y < 0 || y > 1 || p < 0 || p > 1 || k < 0)
    return NaN;
  return cdf_search([&](double n) { return betainc(n, k + 1, p); }, y, BLO, BHI, true);
}

// ---- normal ----

double nrdtrimn(double p, double sd, double x) {
  if (std::isnan(p) || std::isnan(sd) || std::isnan(x) || p <= 0 || p >= 1 || sd <= 0)
    return NaN;
  return x - sd * ndtri(p);
}

double nrdtrisd(double mn, double p, double x) {
  if (std::isnan(p) || std::isnan(mn) || std::isnan(x) || p <= 0 || p >= 1)
    return NaN;
  double z = ndtri(p);
  if (z == 0)
    return NaN;
  return (x - mn) / z;
}

// ---- Poisson ----

double pdtr(double k, double m) {
  if (std::isnan(k) || std::isnan(m) || m < 0)
    return NaN;
  k = std::floor(k);
  if (k < 0)
    return 0.0;
  if (m == 0)
    return 1.0;
  return gammaincc(k + 1, m);
}

double pdtrc(double k, double m) {
  if (std::isnan(k) || std::isnan(m) || m < 0)
    return NaN;
  k = std::floor(k);
  if (k < 0)
    return 1.0;
  if (m == 0)
    return 0.0;
  return gammainc(k + 1, m);
}

double pdtri(double k, double y) {
  if (std::isnan(k) || std::isnan(y) || y < 0 || y > 1)
    return NaN;
  k = std::floor(k);
  if (k < 0)
    return NaN;
  return gammainccinv(k + 1, y);
}

double pdtrik(double p, double m) {
  if (std::isnan(p) || std::isnan(m) || p < 0 || p > 1 || m < 0)
    return NaN;
  double r = cdf_search([&](double k) { return gammaincc(k + 1, m); }, p, BLO, BHI, true);
  return r <= BLO ? 0.0 : r;
}

// ---- Student t ----

double stdtr(double df, double t) {
  if (std::isnan(df) || std::isnan(t) || df <= 0)
    return NaN;
  if (std::isinf(t))
    return t > 0 ? 1.0 : 0.0;
  if (std::isinf(df))
    return ndtr(t);
  double x = df / (df + t * t);
  double tail = 0.5 * betainc(df / 2, 0.5, x);
  return t < 0 ? tail : 1.0 - tail;
}

double stdtridf(double p, double t) {
  if (std::isnan(p) || std::isnan(t) || p < 0 || p > 1)
    return NaN;
  return cdf_search([&](double df) { return stdtr(df, t); }, p, BLO, 1e10, true);
}

double stdtrit(double df, double p) {
  if (std::isnan(df) || std::isnan(p) || df <= 0 || p < 0 || p > 1)
    return NaN;
  if (p == 0)
    return -Inf;
  if (p == 1)
    return Inf;
  if (p == 0.5)
    return 0.0;
  double q = std::min(p, 1 - p);
  double x = betaincinv(df / 2, 0.5, 2 * q);
  double t = std::sqrt(df * (1 - x) / x);
  if (x > 0.999) // small t: use the complement for precision
    t = std::sqrt(df * betainccinv(df / 2, 0.5, 2 * q) / x);
  return p < 0.5 ? -t : t;
}

namespace {
// Lenth's AS 243 for t >= 0.
double nctPos(double t, double df, double del) {
  double x = t * t / (t * t + df), omx = df / (t * t + df); // 1 - x, kept exact for tiny df
  double base = ndtr(-del);
  if (x <= 0)
    return base;
  double lambda = del * del;
  double p = 0.5 * std::exp(-0.5 * lambda);
  double q = std::sqrt(2.0 / PI) * p * del;
  double s = 0.5 - p;
  double a = 0.5, b = 0.5 * df;
  double rxb = std::pow(omx, b);
  double albeta = std::lgamma(a) + std::lgamma(b) - std::lgamma(a + b);
  double xodd = x > 0.5 ? betaincc(b, a, omx) : betainc(a, b, x);
  double godd = 2 * rxb * std::exp(a * std::log(x) - albeta);
  double xeven = 1 - rxb;
  double geven = b * x * rxb;
  double tnc = p * xodd + q * xeven;
  for (int en = 1; en < 100000; en++) {
    a += 1.0;
    xodd -= godd;
    xeven -= geven;
    godd *= x * (a + b - 1) / a;
    geven *= x * (a + b - 0.5) / (a + 0.5);
    p *= lambda / (2.0 * en);
    q *= lambda / (2.0 * en + 1);
    s -= p;
    tnc += p * xodd + q * xeven;
    double errbd = 2 * s * (xodd - godd);
    if (std::fabs(errbd) < 1e-15 && en > lambda / 2)
      break;
  }
  return std::min(1.0, std::max(0.0, tnc + base));
}
} // namespace

double nctdtr(double df, double nc, double t) {
  if (std::isnan(df) || std::isnan(nc) || std::isnan(t) || df <= 0)
    return NaN;
  if (std::isinf(t))
    return t > 0 ? 1.0 : 0.0;
  if (nc == 0)
    return stdtr(df, t);
  if (t >= 0)
    return nctPos(t, df, nc);
  return 1.0 - nctPos(-t, df, -nc);
}

double nct_pdf(double x, double df, double nc) {
  if (std::isnan(x) || std::isnan(df) || std::isnan(nc) || df <= 0)
    return NaN;
  if (x == 0)
    return std::exp(std::lgamma((df + 1) / 2) - 0.5 * nc * nc - std::lgamma(df / 2)) / std::sqrt(PI * df);
  return df / x * (nctdtr(df + 2, nc, x * std::sqrt((df + 2) / df)) - nctdtr(df, nc, x));
}

double nctdtridf(double p, double nc, double t) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  return cdf_search([&](double df) { return nctdtr(df, nc, t); }, p, BLO, BHI, true);
}

double nctdtrinc(double df, double p, double t) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  double hi = 1.0;
  while (nctdtr(df, hi, t) > p && hi < 1e4)
    hi *= 2;
  double lo = -1.0;
  while (nctdtr(df, lo, t) < p && lo > -1e4)
    lo *= 2;
  return cdf_search([&](double nc) { return nctdtr(df, nc, t); }, p, lo, hi, false);
}

double nctdtrit(double df, double nc, double p) {
  if (std::isnan(p) || p < 0 || p > 1)
    return NaN;
  if (p == 0)
    return -Inf;
  if (p == 1)
    return Inf;
  double hi = std::max(1.0, nc + 1);
  while (nctdtr(df, nc, hi) < p && hi < 1e100)
    hi *= 2;
  double lo = std::min(-1.0, nc - 1);
  while (nctdtr(df, nc, lo) > p && lo > -1e100)
    lo *= 2;
  return cdf_search([&](double t) { return nctdtr(df, nc, t); }, p, lo, hi, false);
}

// ---- Tukey lambda ----

double tklmbda(double x, double lmbda) {
  if (std::isnan(x) || std::isnan(lmbda))
    return NaN;
  if (lmbda == 0)
    return 1.0 / (1.0 + std::exp(-x));
  if (lmbda > 0) {
    if (x >= 1.0 / lmbda)
      return 1.0;
    if (x <= -1.0 / lmbda)
      return 0.0;
  }
  auto Q = [&](double F) { return (std::pow(F, lmbda) - std::pow(1 - F, lmbda)) / lmbda - x; };
  if (x == 0)
    return 0.5;
  // bracket in (0, 1/2] or [1/2, 1) and solve
  if (x > 0)
    return brent(Q, 0.5, 1.0, 1e-17);
  return brent(Q, 1e-300, 0.5, 1e-300);
}

} // namespace sf
} // namespace scipy
} // namespace nc
