// Section 20, part 3: orthogonal polynomials and Gauss rules, Legendre
// functions and spherical harmonics, Mathieu, spheroidal, ellipsoidal and
// parabolic cylinder functions.
#include "special_functions_main.h"

#include <cmath>

#include "sf_poly.h"
#include "sf_ufunc.h"

namespace nc {
namespace scipy {

#define SP_SEC Section::SpecialFunctions
#define DEF(...) std::vector<double>{__VA_ARGS__}
#define UF(NAME, MINA, MAXA, PARAMS, DEFS, EXPR)                                                                    \
  SP_ADD(NAME, MINA, MAXA, PARAMS) {                                                                                \
    return umap(a, ctx, MAXA, DEFS, [](const double *x) -> double { return EXPR; });                                \
  }                                                                                                                 \
  SP_END

namespace {
using namespace sf;

bool degreeArg(const Args &a, size_t i, CallContext &ctx, long long &n, long long lo = 0) {
  if (!argInt(a, i, ctx, n))
    return false;
  if (n < lo || n > 100000) {
    ctx.fail("the " + ordinal(i) + " argument must be a whole number from " + std::to_string(lo) + " to 100000");
    return false;
  }
  return true;
}

int I(double v) { return static_cast<int>(v); }
bool isWhole(double v) { return v == std::floor(v) && std::fabs(v) < 1e6; }

Value polyCoef(const Args &a, CallContext &ctx, const std::string &fam, int nparams) {
  long long n;
  if (!degreeArg(a, 0, ctx, n))
    return Value(0.0);
  double p1 = 0, p2 = 0;
  if (nparams >= 1 && !argNumber(a, 1, ctx, p1))
    return Value(0.0);
  if (nparams >= 2 && !argNumber(a, 2, ctx, p2))
    return Value(0.0);
  if ((fam == "jacobi" && (p1 <= -1 || p2 <= -1)) || (fam == "genlaguerre" && p1 <= -1) ||
      (fam == "gegenbauer" && p1 <= -0.5) || (fam == "sh_jacobi" && (p1 - p2 <= -1 || p2 <= 0))) {
    ctx.fail("the parameters are outside the allowed range");
    return Value(0.0);
  }
  return toValue(poly_coef(fam, static_cast<int>(n), p1, p2));
}

Value gaussRule(const Args &a, CallContext &ctx, const std::string &fam, int nparams) {
  long long n;
  if (!degreeArg(a, 0, ctx, n, 1))
    return Value(0.0);
  double p1 = 0, p2 = 0;
  if (nparams >= 1 && !argNumber(a, 1, ctx, p1))
    return Value(0.0);
  if (nparams >= 2 && !argNumber(a, 2, ctx, p2))
    return Value(0.0);
  Vec x, w;
  if (!gauss_rule(fam, static_cast<int>(n), p1, p2, x, w)) {
    ctx.fail("the parameters are outside the allowed range");
    return Value(0.0);
  }
  return makeDict({{"nodes", toValue(x)}, {"weights", toValue(w)}});
}

// A matrix with columns for m = 0..M, then -M..-1 (NumPy's negative indexing).
template <class F> Mat allOrders(int n, int m, F f) {
  int am = std::abs(m);
  Mat out(n + 1, 2 * am + 1);
  for (int l = 0; l <= n; l++)
    for (int j = 0; j < 2 * am + 1; j++) {
      int mm = j <= am ? j : j - (2 * am + 1);
      out(l, j) = f(l, mm);
    }
  return out;
}

Value mathieuCoef(const Args &a, CallContext &ctx, bool even) {
  double m, q;
  if (!argNumber(a, 0, ctx, m) || !argNumber(a, 1, ctx, q))
    return Value(0.0);
  if (m < (even ? 0 : 1) || m != std::floor(m) || m > 10000) {
    ctx.fail(even ? "m must be a whole number from 0" : "m must be a whole number from 1");
    return Value(0.0);
  }
  if (q < 0) {
    ctx.fail("q must not be negative");
    return Value(0.0);
  }
  double sq = std::sqrt(q);
  double qm = q <= 1 ? 7.5 + 56.1 * sq - 134.7 * q + 90.7 * sq * q : 17.0 + 3.1 * sq - 0.126 * q + 0.0037 * sq * q;
  int km = static_cast<int>(qm + 0.5 * m);
  return toValue(mathieu_coef(even, static_cast<int>(m), q, km));
}

std::function<void(const cd *, cd *)> pair2(void (*f)(double, double, double, double &, double &), double mul = 1) {
  return [f, mul](const cd *z, cd *o) {
    double y, yp;
    f(z[0].real(), z[1].real(), z[2].real() * mul, y, yp);
    o[0] = y;
    o[1] = yp;
  };
}

void ceW(double m, double q, double x, double &y, double &yp) { mathieu_ce(m, q, x, y, yp); }
void seW(double m, double q, double x, double &y, double &yp) { mathieu_se(m, q, x, y, yp); }
void mc1(double m, double q, double x, double &y, double &yp) { mathieu_mc(1, m, q, x, y, yp); }
void mc2(double m, double q, double x, double &y, double &yp) { mathieu_mc(2, m, q, x, y, yp); }
void ms1(double m, double q, double x, double &y, double &yp) { mathieu_ms(1, m, q, x, y, yp); }
void ms2(double m, double q, double x, double &y, double &yp) { mathieu_ms(2, m, q, x, y, yp); }

using SphFn = void (*)(bool, int, int, double, double, double, double &, double &);
Value spheroid(const Args &a, CallContext &ctx, bool prolate, SphFn f, bool withCv) {
  size_t n = withCv ? 5 : 4;
  return umapDict(a, ctx, n, DEF(), {"s", "sp"}, [prolate, f, withCv](const cd *z, cd *o) {
    double m = z[0].real(), nn = z[1].real(), c = z[2].real();
    double cv = withCv ? z[3].real() : kNaN, x = z[withCv ? 4 : 3].real();
    double s = kNaN, sp = kNaN;
    if (isWhole(m) && isWhole(nn) && m >= 0 && nn >= m)
      f(prolate, I(m), I(nn), c, cv, x, s, sp);
    o[0] = s;
    o[1] = sp;
  }, false);
}

// D_v, V_v sequences for orders v0, v0 + 1, ..., v.
Value pbSeq(const Args &a, CallContext &ctx, bool dfun) {
  double v, x;
  if (!argNumber(a, 0, ctx, v) || !argNumber(a, 1, ctx, x))
    return Value(0.0);
  if (std::fabs(v) > 1000) {
    ctx.fail("v must be from -1000 to 1000");
    return Value(0.0);
  }
  int n = static_cast<int>(std::floor(std::fabs(v)));
  double v0 = std::fabs(v) - n, sg = v < 0 ? -1.0 : 1.0;
  Vec dv(n + 1), dp(n + 1);
  for (int k = 0; k <= n; k++) {
    double order = sg * (v0 + k), y, yp;
    if (dfun)
      pbdv(order, x, y, yp);
    else
      pbvv(order, x, y, yp);
    dv[k] = y;
    dp[k] = yp;
  }
  return makeDict({{"dv", toValue(dv)}, {"dp", toValue(dp)}});
}
} // namespace

void registerSfPoly(Registry &reg) {
  // ---- polynomial values ----
  UF("eval_legendre", 2, 2, "n, x", DEF(), eval_legendre(x[0], x[1]))
  UF("eval_chebyt", 2, 2, "n, x", DEF(), eval_chebyt(x[0], x[1]))
  UF("eval_chebyu", 2, 2, "n, x", DEF(), eval_chebyu(x[0], x[1]))
  UF("eval_chebyc", 2, 2, "n, x", DEF(), eval_chebyc(x[0], x[1]))
  UF("eval_chebys", 2, 2, "n, x", DEF(), eval_chebys(x[0], x[1]))
  UF("eval_jacobi", 4, 4, "n, alpha, beta, x", DEF(), eval_jacobi(x[0], x[1], x[2], x[3]))
  UF("eval_sh_jacobi", 4, 4, "n, p, q, x", DEF(), eval_sh_jacobi(x[0], x[1], x[2], x[3]))
  UF("eval_gegenbauer", 3, 3, "n, alpha, x", DEF(),
     (x[1] == 0 && isWhole(x[0]) ? (x[0] == 0 ? 1.0 : 0.0) : eval_gegenbauer(x[0], x[1], x[2])))
  UF("eval_genlaguerre", 3, 3, "n, alpha, x", DEF(), eval_genlaguerre(x[0], x[1], x[2]))
  UF("eval_laguerre", 2, 2, "n, x", DEF(), eval_laguerre(x[0], x[1]))
  UF("eval_hermite", 2, 2, "n, x", DEF(), eval_hermite(x[0], x[1]))
  UF("eval_hermitenorm", 2, 2, "n, x", DEF(), eval_hermitenorm(x[0], x[1]))
  UF("eval_sh_legendre", 2, 2, "n, x", DEF(), eval_legendre(x[0], 2 * x[1] - 1))
  UF("eval_sh_chebyt", 2, 2, "n, x", DEF(), eval_chebyt(x[0], 2 * x[1] - 1))
  UF("eval_sh_chebyu", 2, 2, "n, x", DEF(), eval_chebyu(x[0], 2 * x[1] - 1))
  UF("assoc_laguerre", 2, 3, "x, n, k", DEF(0, 0, 0), eval_genlaguerre(x[1], x[2], x[0]))

  // ---- polynomial coefficients ----
  SP_ADD("legendre_poly", 1, 1, "n") { return polyCoef(a, ctx, "legendre", 0); } SP_END
  SP_ADD("chebyt_poly", 1, 1, "n") { return polyCoef(a, ctx, "chebyt", 0); } SP_END
  SP_ADD("chebyu_poly", 1, 1, "n") { return polyCoef(a, ctx, "chebyu", 0); } SP_END
  SP_ADD("chebyc_poly", 1, 1, "n") { return polyCoef(a, ctx, "chebyc", 0); } SP_END
  SP_ADD("chebys_poly", 1, 1, "n") { return polyCoef(a, ctx, "chebys", 0); } SP_END
  SP_ADD("jacobi_poly", 3, 3, "n, alpha, beta") { return polyCoef(a, ctx, "jacobi", 2); } SP_END
  SP_ADD("laguerre_poly", 1, 1, "n") { return polyCoef(a, ctx, "laguerre", 0); } SP_END
  SP_ADD("genlaguerre_poly", 2, 2, "n, alpha") { return polyCoef(a, ctx, "genlaguerre", 1); } SP_END
  SP_ADD("hermite_poly", 1, 1, "n") { return polyCoef(a, ctx, "hermite", 0); } SP_END
  SP_ADD("hermitenorm_poly", 1, 1, "n") { return polyCoef(a, ctx, "hermitenorm", 0); } SP_END
  SP_ADD("gegenbauer_poly", 2, 2, "n, alpha") { return polyCoef(a, ctx, "gegenbauer", 1); } SP_END
  SP_ADD("sh_legendre_poly", 1, 1, "n") { return polyCoef(a, ctx, "sh_legendre", 0); } SP_END
  SP_ADD("sh_chebyt_poly", 1, 1, "n") { return polyCoef(a, ctx, "sh_chebyt", 0); } SP_END
  SP_ADD("sh_chebyu_poly", 1, 1, "n") { return polyCoef(a, ctx, "sh_chebyu", 0); } SP_END
  SP_ADD("sh_jacobi_poly", 3, 3, "n, p, q") { return polyCoef(a, ctx, "sh_jacobi", 2); } SP_END

  // ---- Gauss rules ----
  SP_ADD("roots_legendre", 1, 1, "n") { return gaussRule(a, ctx, "legendre", 0); } SP_END
  SP_ADD("roots_chebyt", 1, 1, "n") { return gaussRule(a, ctx, "chebyt", 0); } SP_END
  SP_ADD("roots_chebyu", 1, 1, "n") { return gaussRule(a, ctx, "chebyu", 0); } SP_END
  SP_ADD("roots_chebyc", 1, 1, "n") { return gaussRule(a, ctx, "chebyc", 0); } SP_END
  SP_ADD("roots_chebys", 1, 1, "n") { return gaussRule(a, ctx, "chebys", 0); } SP_END
  SP_ADD("roots_jacobi", 3, 3, "n, alpha, beta") { return gaussRule(a, ctx, "jacobi", 2); } SP_END
  SP_ADD("roots_laguerre", 1, 1, "n") { return gaussRule(a, ctx, "laguerre", 0); } SP_END
  SP_ADD("roots_genlaguerre", 2, 2, "n, alpha") { return gaussRule(a, ctx, "genlaguerre", 1); } SP_END
  SP_ADD("roots_hermite", 1, 1, "n") { return gaussRule(a, ctx, "hermite", 0); } SP_END
  SP_ADD("roots_hermitenorm", 1, 1, "n") { return gaussRule(a, ctx, "hermitenorm", 0); } SP_END
  SP_ADD("roots_gegenbauer", 2, 2, "n, alpha") { return gaussRule(a, ctx, "gegenbauer", 1); } SP_END
  SP_ADD("roots_sh_legendre", 1, 1, "n") { return gaussRule(a, ctx, "sh_legendre", 0); } SP_END
  SP_ADD("roots_sh_chebyt", 1, 1, "n") { return gaussRule(a, ctx, "sh_chebyt", 0); } SP_END
  SP_ADD("roots_sh_chebyu", 1, 1, "n") { return gaussRule(a, ctx, "sh_chebyu", 0); } SP_END
  SP_ADD("roots_sh_jacobi", 3, 3, "n, p1, q1") { return gaussRule(a, ctx, "sh_jacobi", 2); } SP_END

  // ---- Legendre functions ----
  SP_ADD("legendre_p", 2, 3, "n, x, diff_n") {
    long long n, d = 0;
    if (!degreeArg(a, 0, ctx, n))
      return Value(0.0);
    if (a.size() > 2 && !degreeArg(a, 2, ctx, d))
      return Value(0.0);
    if (d > 2) {
      ctx.fail("diff_n must be 0, 1 or 2");
      return Value(0.0);
    }
    if (d == 0)
      return umap(Args{Value(double(n)), a[1]}, ctx, 2, DEF(), [](const double *x) { return eval_legendre(x[0], x[1]); });
    Vec xs;
    if (!getVec(a, 1, ctx, xs))
      return Value(0.0);
    Mat out(d + 1, xs.size());
    for (long long k = 0; k <= d; k++)
      for (size_t j = 0; j < xs.size(); j++)
        out(k, j) = legendre_deriv(static_cast<int>(n), xs[j], static_cast<int>(k));
    if (isPlainNumber(a[1])) {
      Vec col(d + 1);
      for (long long k = 0; k <= d; k++)
        col[k] = out(k, 0);
      return toValue(col);
    }
    return toValue(out);
  } SP_END

  SP_ADD("legendre_p_all", 2, 2, "n, x") {
    long long n;
    Vec xs;
    if (!degreeArg(a, 0, ctx, n) || !getVec(a, 1, ctx, xs))
      return Value(0.0);
    Mat out(n + 1, xs.size());
    for (size_t j = 0; j < xs.size(); j++)
      for (long long k = 0; k <= n; k++)
        out(k, j) = eval_legendre(double(k), xs[j]);
    if (isPlainNumber(a[1])) {
      Vec r(n + 1);
      for (long long k = 0; k <= n; k++)
        r[k] = out(k, 0);
      return toValue(r);
    }
    return toValue(out);
  } SP_END

  // real |x| > 1 with m != 0 has no real value on SciPy's branch: NaN; complex input gives it
  SP_ADD("assoc_legendre_p", 3, 4, "n, m, x, norm") {
    return umapC(
        a, ctx, 4, DEF(0, 0, 0, 0),
        [](const double *x) -> double {
          if (!isWhole(x[0]) || !isWhole(x[1]) || (std::fabs(x[2]) > 1 && x[1] != 0))
            return kNaN;
          return assoc_legendre(I(x[0]), I(x[1]), x[2], x[3] != 0);
        },
        [](const cd *z) -> cd {
          if (!isWhole(z[0].real()) || !isWhole(z[1].real()))
            return cd(kNaN, kNaN);
          return assoc_legendre_c(I(z[0].real()), I(z[1].real()), z[2], z[3].real() != 0);
        });
  } SP_ENDC
  UF("sph_legendre_p", 3, 3, "n, m, theta", DEF(),
     (!isWhole(x[0]) || !isWhole(x[1]) || x[0] < 0 ? kNaN : sph_legendre(I(x[0]), I(x[1]), x[2])))
  UF("lpmv", 3, 3, "m, v, x", DEF(), lpmv(x[0], x[1], x[2]))

  SP_ADD("assoc_legendre_p_all", 3, 4, "n, m, x, norm") {
    long long n, m;
    if (!degreeArg(a, 0, ctx, n) || !argInt(a, 1, ctx, m))
      return Value(0.0);
    bool norm = optBool(a, 3, false);
    if (a[2].isComplex) {
      cd z = cd(a[2].number, a[2].imag);
      int am = static_cast<int>(std::llabs(m));
      CMat out(static_cast<size_t>(n) + 1, 2 * am + 1);
      for (int l = 0; l <= n; l++)
        for (int j = 0; j < 2 * am + 1; j++)
          out(l, j) = assoc_legendre_c(l, j <= am ? j : j - (2 * am + 1), z, norm);
      return toValue(out);
    }
    double x;
    if (!argNumber(a, 2, ctx, x))
      return Value(0.0);
    return toValue(allOrders(static_cast<int>(n), static_cast<int>(m), [&](int l, int mm) {
      return std::fabs(x) > 1 && mm != 0 ? kNaN : assoc_legendre(l, mm, x, norm);
    }));
  } SP_ENDC

  SP_ADD("sph_legendre_p_all", 3, 3, "n, m, theta") {
    long long n, m;
    double th;
    if (!degreeArg(a, 0, ctx, n) || !argInt(a, 1, ctx, m) || !argNumber(a, 2, ctx, th))
      return Value(0.0);
    return toValue(allOrders(static_cast<int>(n), static_cast<int>(m), [&](int l, int mm) { return sph_legendre(l, mm, th); }));
  } SP_END

  SP_ADD("sph_harm_y", 4, 4, "n, m, theta, phi") {
    return umapToC(a, ctx, 4, DEF(), [](const cd *z) -> cd {
      double n = z[0].real(), m = z[1].real();
      if (!isWhole(n) || !isWhole(m) || n < 0)
        return cd(kNaN, kNaN);
      return sph_legendre(I(n), I(m), z[2].real()) * std::exp(cd(0, m * z[3].real()));
    }, false);
  } SP_END

  SP_ADD("sph_harm_y_all", 4, 4, "n, m, theta, phi") {
    long long n, m;
    double th, ph;
    if (!degreeArg(a, 0, ctx, n) || !argInt(a, 1, ctx, m) || !argNumber(a, 2, ctx, th) || !argNumber(a, 3, ctx, ph))
      return Value(0.0);
    int am = static_cast<int>(std::llabs(m));
    CMat out(n + 1, 2 * am + 1);
    for (int l = 0; l <= n; l++)
      for (int j = 0; j < 2 * am + 1; j++) {
        int mm = j <= am ? j : j - (2 * am + 1);
        out(l, j) = sph_legendre(l, mm, th) * std::exp(cd(0, mm * ph));
      }
    return toValue(out);
  } SP_END

  SP_ADD("lqn", 2, 2, "n, z") {
    long long n;
    if (!degreeArg(a, 0, ctx, n))
      return Value(0.0);
    if (!isPlainNumber(a[1])) {
      ctx.fail("the second argument must be a number");
      return Value(0.0);
    }
    cd z(a[1].number, a[1].isComplex ? a[1].imag : 0.0);
    std::vector<cd> q, qd;
    lqn(static_cast<int>(n), z, q, qd);
    return makeDict({{"Qn", realIfPossible(CVec(q))}, {"Qnd", realIfPossible(CVec(qd))}});
  } SP_ENDC

  SP_ADD("lqmn", 3, 3, "m, n, z") {
    long long m, n;
    double x;
    if (!degreeArg(a, 0, ctx, m) || !degreeArg(a, 1, ctx, n) || !argNumber(a, 2, ctx, x))
      return Value(0.0);
    if (std::fabs(x) >= 1) {
      ctx.fail("z must lie strictly between -1 and 1");
      return Value(0.0);
    }
    std::vector<std::vector<double>> q, qd;
    lqmn(static_cast<int>(m), static_cast<int>(n), x, q, qd);
    Mat Q(m + 1, n + 1), D(m + 1, n + 1);
    for (long long i = 0; i <= m; i++)
      for (long long j = 0; j <= n; j++) {
        Q(i, j) = q[i][j];
        D(i, j) = qd[i][j];
      }
    return makeDict({{"Qmn", toValue(Q)}, {"Qmnd", toValue(D)}});
  } SP_END

  // ---- ellipsoidal harmonics ----
  UF("ellip_harm", 5, 7, "h2, k2, n, p, s, signm, signn", DEF(0, 0, 0, 0, 0, 1, 1),
     (!isWhole(x[2]) || !isWhole(x[3]) ? kNaN : ellip_harm(x[0], x[1], I(x[2]), I(x[3]), x[4], x[5] < 0 ? -1.0 : 1.0, x[6] < 0 ? -1.0 : 1.0)))
  UF("ellip_harm_2", 5, 5, "h2, k2, n, p, s", DEF(), (!isWhole(x[2]) || !isWhole(x[3]) ? kNaN : ellip_harm_2(x[0], x[1], I(x[2]), I(x[3]), x[4])))
  UF("ellip_normal", 4, 4, "h2, k2, n, p", DEF(), (!isWhole(x[2]) || !isWhole(x[3]) ? kNaN : ellip_normal(x[0], x[1], I(x[2]), I(x[3]))))

  // ---- Mathieu ----
  UF("mathieu_a", 2, 2, "m, q", DEF(), mathieu_a(x[0], x[1]))
  UF("mathieu_b", 2, 2, "m, q", DEF(), mathieu_b(x[0], x[1]))
  SP_ADD("mathieu_even_coef", 2, 2, "m, q") { return mathieuCoef(a, ctx, true); } SP_END
  SP_ADD("mathieu_odd_coef", 2, 2, "m, q") { return mathieuCoef(a, ctx, false); } SP_END
  SP_ADD("mathieu_cem", 3, 3, "m, q, x") { return umapDict(a, ctx, 3, DEF(), {"y", "yp"}, pair2(ceW), false); } SP_END
  SP_ADD("mathieu_sem", 3, 3, "m, q, x") { return umapDict(a, ctx, 3, DEF(), {"y", "yp"}, pair2(seW), false); } SP_END
  SP_ADD("mathieu_modcem1", 3, 3, "m, q, x") { return umapDict(a, ctx, 3, DEF(), {"y", "yp"}, pair2(mc1), false); } SP_END
  SP_ADD("mathieu_modcem2", 3, 3, "m, q, x") { return umapDict(a, ctx, 3, DEF(), {"y", "yp"}, pair2(mc2), false); } SP_END
  SP_ADD("mathieu_modsem1", 3, 3, "m, q, x") { return umapDict(a, ctx, 3, DEF(), {"y", "yp"}, pair2(ms1), false); } SP_END
  SP_ADD("mathieu_modsem2", 3, 3, "m, q, x") { return umapDict(a, ctx, 3, DEF(), {"y", "yp"}, pair2(ms2), false); } SP_END

  // ---- spheroidal wave functions ----
  UF("pro_cv", 3, 3, "m, n, c", DEF(), (!isWhole(x[0]) || !isWhole(x[1]) ? kNaN : sph_cv(true, I(x[0]), I(x[1]), x[2])))
  UF("obl_cv", 3, 3, "m, n, c", DEF(), (!isWhole(x[0]) || !isWhole(x[1]) ? kNaN : sph_cv(false, I(x[0]), I(x[1]), x[2])))
  SP_ADD("pro_cv_seq", 3, 3, "m, n, c") {
    long long m, n;
    double c;
    if (!degreeArg(a, 0, ctx, m) || !degreeArg(a, 1, ctx, n) || !argNumber(a, 2, ctx, c))
      return Value(0.0);
    if (n < m || n - m > 199) {
      ctx.fail("n must be from m to m + 199");
      return Value(0.0);
    }
    return toValue(sph_cv_seq(true, static_cast<int>(m), static_cast<int>(n), c));
  } SP_END
  SP_ADD("obl_cv_seq", 3, 3, "m, n, c") {
    long long m, n;
    double c;
    if (!degreeArg(a, 0, ctx, m) || !degreeArg(a, 1, ctx, n) || !argNumber(a, 2, ctx, c))
      return Value(0.0);
    if (n < m || n - m > 199) {
      ctx.fail("n must be from m to m + 199");
      return Value(0.0);
    }
    return toValue(sph_cv_seq(false, static_cast<int>(m), static_cast<int>(n), c));
  } SP_END
  SP_ADD("pro_ang1", 4, 4, "m, n, c, x") { return spheroid(a, ctx, true, sph_ang1, false); } SP_END
  SP_ADD("pro_ang1_cv", 5, 5, "m, n, c, cv, x") { return spheroid(a, ctx, true, sph_ang1, true); } SP_END
  SP_ADD("obl_ang1", 4, 4, "m, n, c, x") { return spheroid(a, ctx, false, sph_ang1, false); } SP_END
  SP_ADD("obl_ang1_cv", 5, 5, "m, n, c, cv, x") { return spheroid(a, ctx, false, sph_ang1, true); } SP_END
  SP_ADD("pro_rad1", 4, 4, "m, n, c, x") { return spheroid(a, ctx, true, sph_rad1, false); } SP_END
  SP_ADD("pro_rad1_cv", 5, 5, "m, n, c, cv, x") { return spheroid(a, ctx, true, sph_rad1, true); } SP_END
  SP_ADD("pro_rad2", 4, 4, "m, n, c, x") { return spheroid(a, ctx, true, sph_rad2, false); } SP_END
  SP_ADD("pro_rad2_cv", 5, 5, "m, n, c, cv, x") { return spheroid(a, ctx, true, sph_rad2, true); } SP_END
  SP_ADD("obl_rad1", 4, 4, "m, n, c, x") { return spheroid(a, ctx, false, sph_rad1, false); } SP_END
  SP_ADD("obl_rad1_cv", 5, 5, "m, n, c, cv, x") { return spheroid(a, ctx, false, sph_rad1, true); } SP_END
  SP_ADD("obl_rad2", 4, 4, "m, n, c, x") { return spheroid(a, ctx, false, sph_rad2, false); } SP_END
  SP_ADD("obl_rad2_cv", 5, 5, "m, n, c, cv, x") { return spheroid(a, ctx, false, sph_rad2, true); } SP_END

  // ---- parabolic cylinder ----
  SP_ADD("pbdv", 2, 2, "v, x") {
    return umapDict(a, ctx, 2, DEF(), {"d", "dp"}, [](const cd *z, cd *o) {
      double d, dp;
      pbdv(z[0].real(), z[1].real(), d, dp);
      o[0] = d;
      o[1] = dp;
    }, false);
  } SP_END
  SP_ADD("pbvv", 2, 2, "v, x") {
    return umapDict(a, ctx, 2, DEF(), {"v", "vp"}, [](const cd *z, cd *o) {
      double v, vp;
      pbvv(z[0].real(), z[1].real(), v, vp);
      o[0] = v;
      o[1] = vp;
    }, false);
  } SP_END
  SP_ADD("pbwa", 2, 2, "a, x") {
    return umapDict(a, ctx, 2, DEF(), {"w", "wp"}, [](const cd *z, cd *o) {
      double w, wp;
      pbwa(z[0].real(), z[1].real(), w, wp);
      o[0] = w;
      o[1] = wp;
    }, false);
  } SP_END
  SP_ADD("pbdv_seq", 2, 2, "v, x") { return pbSeq(a, ctx, true); } SP_END
  SP_ADD("pbvv_seq", 2, 2, "v, x") { return pbSeq(a, ctx, false); } SP_END
  SP_ADD("pbdn_seq", 2, 2, "n, z") {
    long long n;
    if (!degreeArg(a, 0, ctx, n))
      return Value(0.0);
    if (!isPlainNumber(a[1])) {
      ctx.fail("the second argument must be a number");
      return Value(0.0);
    }
    cd z(a[1].number, a[1].isComplex ? a[1].imag : 0.0);
    // D_k(z) = exp(-z^2/4) He_k(z); D_k'(z) = z/2 D_k(z) - D_{k+1}(z)
    std::vector<cd> he(n + 2);
    he[0] = 1.0;
    he[1] = z;
    for (long long k = 1; k + 1 <= n + 1; k++)
      he[k + 1] = z * he[k] - double(k) * he[k - 1];
    cd e = std::exp(-z * z / 4.0);
    CVec dv(n + 1), dp(n + 1);
    for (long long k = 0; k <= n; k++) {
      dv[k] = e * he[k];
      dp[k] = z / 2.0 * dv[k] - e * he[k + 1];
    }
    return makeDict({{"dv", realIfPossible(dv)}, {"dp", realIfPossible(dp)}});
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
