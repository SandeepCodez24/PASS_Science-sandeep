// Section 1 of 25 - Clustering (scipy.cluster). A linkage matrix Z has n-1 rows
// [a, b, distance, size], as in SciPy; pdist() lives in spatial_algorithms.
#include "clustering_main.h"

#include <array>
#include <functional>
#include <map>
#include <random>

#include "../../ops/matrix/matrix.h"
#include "../scipy_core.h"

#define SP_SEC Section::Clustering

namespace nc {
namespace scipy {

namespace {

double sqDist(const double *a, const double *b, size_t d) {
  double s = 0.0;
  for (size_t i = 0; i < d; i++)
    s += (a[i] - b[i]) * (a[i] - b[i]);
  return s;
}

// Nearest centre per point: labels and distances.
void assign(const Mat &data, const Mat &cen, IVec &labels, Vec &dist) {
  labels.assign(data.r, 0);
  dist.assign(data.r, 0.0);
  par::forBlocks(data.r, {par::Kind::Compute, 50.0}, [&](size_t b, size_t e) {
    for (size_t i = b; i < e; i++) {
      double best = kInf;
      long long lab = 0;
      for (size_t k = 0; k < cen.r; k++) {
        const double d = sqDist(data.row(i), cen.row(k), data.c);
        if (d < best) {
          best = d;
          lab = static_cast<long long>(k);
        }
      }
      labels[i] = lab;
      dist[i] = std::sqrt(best);
    }
  });
}

// The merge methods of the Lance-Williams update.
enum class Link { Single, Complete, Average, Weighted, Centroid, Median, Ward };
bool linkOf(const std::string &s, Link &l) {
  if (s == "single") l = Link::Single;
  else if (s == "complete") l = Link::Complete;
  else if (s == "average") l = Link::Average;
  else if (s == "weighted") l = Link::Weighted;
  else if (s == "centroid") l = Link::Centroid;
  else if (s == "median") l = Link::Median;
  else if (s == "ward") l = Link::Ward;
  else return false;
  return true;
}

Vec euclidCondensed(const Mat &P) {
  Vec d(P.r * (P.r ? P.r - 1 : 0) / 2);
  size_t k = 0;
  for (size_t i = 0; i < P.r; i++)
    for (size_t j = i + 1; j < P.r; j++)
      d[k++] = std::sqrt(sqDist(P.row(i), P.row(j), P.c));
  return d;
}

// Agglomerative clustering on a full distance matrix, with SciPy's ordering of
// the two ids in each row (smaller first) and of the rows (by distance).
Mat linkageFrom(const Vec &cond, size_t n, Link how) {
  Mat D(n, n);
  size_t k = 0;
  for (size_t i = 0; i < n; i++)
    for (size_t j = i + 1; j < n; j++)
      D(i, j) = D(j, i) = cond[k++];
  const bool squared = how == Link::Centroid || how == Link::Median || how == Link::Ward;
  if (squared)
    for (double &v : D.a)
      v *= v;
  std::vector<size_t> ids(n), size(n, 1);
  std::vector<bool> alive(n, true);
  for (size_t i = 0; i < n; i++)
    ids[i] = i;
  Mat Z(n ? n - 1 : 0, 4);
  size_t nextId = n;
  std::vector<std::array<double, 4>> rows;
  for (size_t step = 0; step + 1 < n; step++) {
    size_t x = 0, y = 0;
    double best = kInf;
    for (size_t i = 0; i < n; i++) {
      if (!alive[i])
        continue;
      for (size_t j = i + 1; j < n; j++)
        if (alive[j] && D(i, j) < best) {
          best = D(i, j);
          x = i;
          y = j;
        }
    }
    const double nx = static_cast<double>(size[x]), ny = static_cast<double>(size[y]);
    for (size_t i = 0; i < n; i++) {
      if (!alive[i] || i == x || i == y)
        continue;
      const double dx = D(i, x), dy = D(i, y), ni = static_cast<double>(size[i]);
      double nd;
      switch (how) {
      case Link::Single: nd = std::min(dx, dy); break;
      case Link::Complete: nd = std::max(dx, dy); break;
      case Link::Average: nd = (nx * dx + ny * dy) / (nx + ny); break;
      case Link::Weighted: nd = 0.5 * (dx + dy); break;
      case Link::Centroid: nd = (nx * dx + ny * dy - nx * ny * best / (nx + ny)) / (nx + ny); break;
      case Link::Median: nd = 0.5 * dx + 0.5 * dy - 0.25 * best; break;
      default: nd = ((ni + nx) * dx + (ni + ny) * dy - ni * best) / (ni + nx + ny); break;
      }
      D(i, y) = D(y, i) = nd;
    }
    double a0 = static_cast<double>(std::min(ids[x], ids[y])), b0 = static_cast<double>(std::max(ids[x], ids[y]));
    rows.push_back({a0, b0, squared ? std::sqrt(best) : best, nx + ny});
    alive[x] = false;
    size[y] = size[x] + size[y];
    ids[y] = nextId++;
  }
  for (size_t i = 0; i < rows.size(); i++)
    for (size_t j = 0; j < 4; j++)
      Z(i, j) = rows[i][j];
  return Z;
}

bool getLinkage(const Args &a, size_t i, CallContext &ctx, Mat &Z) {
  if (!getMat(a, i, ctx, Z))
    return false;
  if (Z.c != 4 && Z.r != 0) {
    ctx.fail("the " + ordinal(i) + " argument must be a linkage matrix (four columns)");
    return false;
  }
  return true;
}

// Leaves below each node of a linkage: the left-to-right order at the root.
void leavesOf(const Mat &Z, size_t n, size_t node, IVec &out) {
  std::vector<size_t> stack{node};
  while (!stack.empty()) {
    size_t v = stack.back();
    stack.pop_back();
    if (v < n) {
      out.push_back(static_cast<long long>(v));
      continue;
    }
    stack.push_back(static_cast<size_t>(Z(v - n, 1)));
    stack.push_back(static_cast<size_t>(Z(v - n, 0)));
  }
}

IVec flatMaxClust(const Mat &Z, size_t n, size_t want) {
  // Cut the last merges so at most `want` clusters stay, keeping tied merges together.
  // Monotonic criterion: per node, the largest merge distance below it.
  Vec md(Z.r);
  for (size_t i = 0; i < Z.r; i++) {
    md[i] = Z(i, 2);
    for (int s = 0; s < 2; s++) {
      size_t c = static_cast<size_t>(Z(i, s));
      if (c >= n)
        md[i] = std::max(md[i], md[c - n]);
    }
  }
  Vec sorted = md;
  std::sort(sorted.begin(), sorted.end());
  // Largest threshold giving at most `want` clusters.
  std::vector<double> th;
  th.push_back(0.0);
  th.insert(th.end(), sorted.begin(), sorted.end());
  IVec lab(n, 0);
  auto labels = [&](double t) {
    IVec l(n, 0);
    long long next = 0;
    std::vector<std::pair<size_t, long long>> stack;
    stack.push_back({2 * n - 2, -1});
    while (!stack.empty()) {
      auto cur = stack.back();
      stack.pop_back();
      size_t v = cur.first;
      long long c = cur.second;
      if (v >= n) {
        if (c < 0 && md[v - n] <= t)
          c = ++next;
        stack.push_back({static_cast<size_t>(Z(v - n, 1)), c});
        stack.push_back({static_cast<size_t>(Z(v - n, 0)), c});
      } else {
        l[v] = c < 0 ? ++next : c;
      }
    }
    return std::make_pair(l, next);
  };
  size_t lo = 0, hi = th.size() - 1;
  while (lo < hi) {
    size_t mid = (lo + hi + 1) / 2;
    if (labels(th[mid]).second >= 1 && static_cast<size_t>(labels(th[mid]).second) >= want && mid > 0) {
      // too few cuts? keep searching towards the smallest count >= want
      lo = mid;
    } else {
      hi = mid - 1;
    }
  }
  // lo gives >= want clusters; move up while the count stays above `want`.
  size_t idx = lo;
  auto r = labels(th[idx]);
  if (static_cast<size_t>(r.second) > want && idx + 1 < th.size())
    r = labels(th[idx + 1]);
  return r.first;
}

IVec flatByNodeTest(const Mat &Z, size_t n, const std::function<bool(size_t)> &accept) {
  // A node and everything below it form one cluster when accept(node) holds for
  // it and for every node below (the monotonic rule of fcluster).
  std::vector<char> ok(Z.r);
  for (size_t i = 0; i < Z.r; i++) {
    ok[i] = accept(i);
    for (int s = 0; s < 2; s++) {
      size_t c = static_cast<size_t>(Z(i, s));
      if (c >= n && !ok[c - n])
        ok[i] = 0;
    }
  }
  IVec l(n, 0);
  long long next = 0;
  std::vector<std::pair<size_t, long long>> stack;
  stack.push_back({2 * n - 2, -1});
  while (!stack.empty()) {
    auto cur = stack.back();
    stack.pop_back();
    if (cur.first >= n) {
      long long c = cur.second;
      if (c < 0 && ok[cur.first - n])
        c = ++next;
      stack.push_back({static_cast<size_t>(Z(cur.first - n, 1)), c});
      stack.push_back({static_cast<size_t>(Z(cur.first - n, 0)), c});
    } else {
      l[cur.first] = cur.second < 0 ? ++next : cur.second;
    }
  }
  return l;
}

Mat inconsistency(const Mat &Z, size_t n, long long depth) {
  Mat R(Z.r, 4);
  for (size_t i = 0; i < Z.r; i++) {
    std::vector<std::pair<size_t, long long>> stack{{i + n, 0}};
    Vec h;
    while (!stack.empty()) {
      auto cur = stack.back();
      stack.pop_back();
      if (cur.first < n || cur.second >= depth)
        continue;
      h.push_back(Z(cur.first - n, 2));
      stack.push_back({static_cast<size_t>(Z(cur.first - n, 0)), cur.second + 1});
      stack.push_back({static_cast<size_t>(Z(cur.first - n, 1)), cur.second + 1});
    }
    double m = 0.0, sq = 0.0;
    for (double v : h) {
      m += v;
      sq += v * v;
    }
    const double N = static_cast<double>(h.size());
    m /= N;
    double sd = h.size() > 1 ? std::sqrt(std::max(0.0, (sq - N * m * m) / (N - 1.0))) : 0.0;
    R(i, 0) = m;
    R(i, 1) = sd;
    R(i, 2) = N;
    R(i, 3) = sd > 0.0 ? (Z(i, 2) - m) / sd : 0.0;
  }
  return R;
}

Vec maxOverSubtree(const Mat &Z, size_t n, const Vec &own) {
  Vec m(Z.r);
  for (size_t i = 0; i < Z.r; i++) {
    m[i] = own[i];
    for (int s = 0; s < 2; s++) {
      size_t c = static_cast<size_t>(Z(i, s));
      if (c >= n)
        m[i] = std::max(m[i], m[c - n]);
    }
  }
  return m;
}

Value nodeDict(const Mat &Z, size_t n, size_t id) {
  if (id < n)
    return makeDict({{"id", Value(static_cast<double>(id))}, {"count", Value(1.0)}, {"dist", Value(0.0)}, {"is_leaf", Value::boolean(true)}});
  const size_t i = id - n;
  return makeDict({{"id", Value(static_cast<double>(id))}, {"count", Value(Z(i, 3))}, {"dist", Value(Z(i, 2))}, {"is_leaf", Value::boolean(false)},
                   {"left", nodeDict(Z, n, static_cast<size_t>(Z(i, 0)))}, {"right", nodeDict(Z, n, static_cast<size_t>(Z(i, 1)))}});
}

std::vector<std::string> g_linkColors = {"C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9"};

void kmeansOnce(const Mat &P, Mat &cen, IVec &lab, Vec &dist) {
  for (int it = 0; it < 300; it++) {
    assign(P, cen, lab, dist);
    Mat next(cen.r, cen.c);
    Vec count(cen.r, 0.0);
    for (size_t i = 0; i < P.r; i++) {
      count[(size_t)lab[i]] += 1.0;
      for (size_t j = 0; j < P.c; j++)
        next((size_t)lab[i], j) += P(i, j);
    }
    bool same = true;
    for (size_t k = 0; k < cen.r; k++) {
      if (count[k] == 0.0) {
        for (size_t j = 0; j < cen.c; j++)
          next(k, j) = cen(k, j);
        continue;
      }
      for (size_t j = 0; j < cen.c; j++) {
        next(k, j) /= count[k];
        if (std::fabs(next(k, j) - cen(k, j)) > 1e-12)
          same = false;
      }
    }
    cen = next;
    if (same)
      break;
  }
  assign(P, cen, lab, dist);
}

std::mt19937_64 seeded(const Args &a, size_t i) {
  if (isNumberArg(a, i))
    return std::mt19937_64(static_cast<unsigned long long>(a[i].number));
  return std::mt19937_64(ncRandomEngine()());
}

// A disjoint set: items, parents and sizes kept in a Dict.
size_t dsFind(Vec &parent, size_t i) {
  while (static_cast<size_t>(parent[i]) != i) {
    parent[i] = parent[static_cast<size_t>(parent[i])];
    i = static_cast<size_t>(parent[i]);
  }
  return i;
}
bool dsIndex(const Vec &items, double v, size_t &out) {
  for (size_t i = 0; i < items.size(); i++)
    if (items[i] == v) {
      out = i;
      return true;
    }
  return false;
}

} // namespace

void registerClustering(Registry &reg) {
  SP_ADD("whiten", 1, 1, "data") {
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    for (size_t j = 0; j < P.c; j++) {
      double m = 0.0, s = 0.0;
      for (size_t i = 0; i < P.r; i++)
        m += P(i, j);
      m /= static_cast<double>(P.r);
      for (size_t i = 0; i < P.r; i++)
        s += (P(i, j) - m) * (P(i, j) - m);
      s = std::sqrt(s / static_cast<double>(P.r));
      if (s > 0.0)
        for (size_t i = 0; i < P.r; i++)
          P(i, j) /= s;
    }
    return toValue(P);
  } SP_END
  SP_ADD("kmeans", 2, 3, "data, k, seed") {
    Mat P;
    long long k;
    if (!getMat(a, 0, ctx, P) || !argNonNegativeInt(a, 1, ctx, k))
      return Value(0.0);
    if (k < 1 || (size_t)k > P.r) {
      ctx.fail("k must be between 1 and the number of points");
      return Value(0.0);
    }
    std::mt19937_64 gen = seeded(a, 2);
    Mat bestC;
    double bestD = kInf;
    for (int run = 0; run < 20; run++) {
      std::vector<size_t> idx(P.r);
      for (size_t i = 0; i < P.r; i++)
        idx[i] = i;
      std::shuffle(idx.begin(), idx.end(), gen);
      Mat cen((size_t)k, P.c);
      for (size_t c = 0; c < (size_t)k; c++)
        for (size_t j = 0; j < P.c; j++)
          cen(c, j) = P(idx[c], j);
      IVec lab;
      Vec dist;
      kmeansOnce(P, cen, lab, dist);
      double d = 0.0;
      for (double v : dist)
        d += v;
      d /= static_cast<double>(P.r);
      if (d < bestD) {
        bestD = d;
        bestC = cen;
      }
    }
    return makeDict({{"centroids", toValue(bestC)}, {"distortion", Value(bestD)}});
  } SP_END
  SP_ADD("kmeans2", 2, 3, "data, k, seed") {
    Mat P;
    long long k;
    if (!getMat(a, 0, ctx, P) || !argNonNegativeInt(a, 1, ctx, k))
      return Value(0.0);
    if (k < 1 || (size_t)k > P.r) {
      ctx.fail("k must be between 1 and the number of points");
      return Value(0.0);
    }
    std::mt19937_64 gen = seeded(a, 2);
    std::vector<size_t> idx(P.r);
    for (size_t i = 0; i < P.r; i++)
      idx[i] = i;
    std::shuffle(idx.begin(), idx.end(), gen);
    Mat cen((size_t)k, P.c);
    for (size_t c = 0; c < (size_t)k; c++)
      for (size_t j = 0; j < P.c; j++)
        cen(c, j) = P(idx[c], j);
    IVec lab;
    Vec dist;
    kmeansOnce(P, cen, lab, dist);
    return makeDict({{"centroids", toValue(cen)}, {"labels", toValue(lab)}});
  } SP_END
  SP_ADD("assign_clusters", 2, 2, "data, centroids") {
    Mat P, C;
    if (!getMat(a, 0, ctx, P) || !getMat(a, 1, ctx, C))
      return Value(0.0);
    if (P.c != C.c) {
      ctx.fail("data and centroids must have the same number of columns");
      return Value(0.0);
    }
    IVec lab;
    Vec dist;
    assign(P, C, lab, dist);
    return makeDict({{"labels", toValue(lab)}, {"dist", toValue(dist)}});
  } SP_END
  SP_ADD("linkage", 1, 2, "data, method=\"single\"") {
    const std::string m = optText(a, 1, "single");
    Link how;
    if (!linkOf(m, how)) {
      ctx.fail("unknown method \"" + m + "\"");
      return Value(0.0);
    }
    Mat P;
    if (!getMat(a, 0, ctx, P))
      return Value(0.0);
    if (P.r == 1) { // an Array: condensed distances
      const size_t c = P.c;
      const size_t n = static_cast<size_t>((1.0 + std::sqrt(1.0 + 8.0 * (double)c)) / 2.0);
      if (n * (n - 1) / 2 != c) {
        ctx.fail("a condensed distance list has n*(n-1)/2 values");
        return Value(0.0);
      }
      return toValue(linkageFrom(P.a, n, how));
    }
    return toValue(linkageFrom(euclidCondensed(P), P.r, how));
  } SP_END
#define NC_LINK_COND(NAME, HOW)                                                                    \
  SP_ADD(NAME, 1, 1, "dist") {                                                                     \
    Vec c;                                                                                         \
    if (!getVec(a, 0, ctx, c))                                                                     \
      return Value(0.0);                                                                           \
    const size_t n = static_cast<size_t>((1.0 + std::sqrt(1.0 + 8.0 * (double)c.size())) / 2.0);   \
    if (n * (n - 1) / 2 != c.size()) {                                                             \
      ctx.fail("a condensed distance list has n*(n-1)/2 values");                                  \
      return Value(0.0);                                                                           \
    }                                                                                              \
    return toValue(linkageFrom(c, n, HOW));                                                        \
  } SP_END
  NC_LINK_COND("linkage_single", Link::Single)
  NC_LINK_COND("linkage_complete", Link::Complete)
  NC_LINK_COND("linkage_average", Link::Average)
  NC_LINK_COND("linkage_weighted", Link::Weighted)
#define NC_LINK_PTS(NAME, HOW)                                                                     \
  SP_ADD(NAME, 1, 1, "data") {                                                                     \
    Mat P;                                                                                         \
    if (!getMat(a, 0, ctx, P))                                                                     \
      return Value(0.0);                                                                           \
    return toValue(linkageFrom(euclidCondensed(P), P.r, HOW));                                     \
  } SP_END
  NC_LINK_PTS("linkage_centroid", Link::Centroid)
  NC_LINK_PTS("linkage_median", Link::Median)
  NC_LINK_PTS("linkage_ward", Link::Ward)
  SP_ADD("fcluster", 2, 3, "Z, t, criterion=\"inconsistent\"") {
    Mat Z;
    double t;
    if (!getLinkage(a, 0, ctx, Z) || !argNumber(a, 1, ctx, t))
      return Value(0.0);
    const size_t n = Z.r + 1;
    const std::string c = optText(a, 2, "inconsistent");
    if (c == "maxclust")
      return toValue(flatMaxClust(Z, n, (size_t)t));
    if (c == "distance")
      return toValue(flatByNodeTest(Z, n, [&](size_t i) { return Z(i, 2) <= t; }));
    if (c == "inconsistent") {
      Mat R = inconsistency(Z, n, 2);
      return toValue(flatByNodeTest(Z, n, [&](size_t i) { return R(i, 3) <= t; }));
    }
    ctx.fail("criterion must be \"maxclust\", \"distance\" or \"inconsistent\"");
    return Value(0.0);
  } SP_END
  SP_ADD("fcluster_data", 2, 3, "data, t, criterion=\"inconsistent\"") {
    Mat P;
    double t;
    if (!getMat(a, 0, ctx, P) || !argNumber(a, 1, ctx, t))
      return Value(0.0);
    Mat Z = linkageFrom(euclidCondensed(P), P.r, Link::Single);
    const size_t n = Z.r + 1;
    const std::string c = optText(a, 2, "inconsistent");
    if (c == "maxclust")
      return toValue(flatMaxClust(Z, n, (size_t)t));
    if (c == "distance")
      return toValue(flatByNodeTest(Z, n, [&](size_t i) { return Z(i, 2) <= t; }));
    Mat R = inconsistency(Z, n, 2);
    return toValue(flatByNodeTest(Z, n, [&](size_t i) { return R(i, 3) <= t; }));
  } SP_END
  SP_ADD("cluster_leaders", 2, 2, "Z, labels") {
    Mat Z;
    Vec lab;
    if (!getLinkage(a, 0, ctx, Z) || !getVec(a, 1, ctx, lab))
      return Value(0.0);
    const size_t n = Z.r + 1;
    if (lab.size() != n) {
      ctx.fail("labels must have one value per point");
      return Value(0.0);
    }
    IVec leaders, ids;
    std::vector<size_t> stack{2 * n - 2};
    while (!stack.empty()) {
      const size_t node = stack.back();
      stack.pop_back();
      IVec lv;
      leavesOf(Z, n, node, lv);
      bool same = true;
      for (long long v : lv)
        same = same && lab[(size_t)v] == lab[(size_t)lv[0]];
      if (same) {
        leaders.push_back(static_cast<long long>(node));
        ids.push_back(static_cast<long long>(lab[(size_t)lv[0]]));
      } else if (node >= n) {
        stack.push_back(static_cast<size_t>(Z(node - n, 1)));
        stack.push_back(static_cast<size_t>(Z(node - n, 0)));
      }
    }
    std::vector<size_t> order(leaders.size());
    for (size_t i = 0; i < order.size(); i++)
      order[i] = i;
    std::sort(order.begin(), order.end(), [&](size_t x, size_t y) { return leaders[x] < leaders[y]; });
    IVec l2, i2;
    for (size_t o : order) {
      l2.push_back(leaders[o]);
      i2.push_back(ids[o]);
    }
    return makeDict({{"leaders", toValue(l2)}, {"ids", toValue(i2)}});
  } SP_END
  SP_ADD("cut_tree", 1, 2, "Z, n_clusters") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    const size_t n = Z.r + 1;
    Vec want;
    if (a.size() > 1) {
      if (!getVec(a, 1, ctx, want))
        return Value(0.0);
    } else {
      for (size_t k = n; k >= 1; k--)
        want.push_back(static_cast<double>(k));
    }
    Mat C(n, want.size());
    for (size_t w = 0; w < want.size(); w++) {
      // Apply the first n - k merges; labels numbered by first appearance.
      const size_t merges = n - static_cast<size_t>(want[w]);
      std::vector<size_t> parent(2 * n - 1);
      for (size_t i = 0; i < parent.size(); i++)
        parent[i] = i;
      for (size_t m = 0; m < merges; m++) {
        parent[static_cast<size_t>(Z(m, 0))] = n + m;
        parent[static_cast<size_t>(Z(m, 1))] = n + m;
      }
      std::unordered_map<size_t, long long> seen;
      for (size_t i = 0; i < n; i++) {
        size_t r = i;
        while (parent[r] != r)
          r = parent[r];
        auto it = seen.find(r);
        if (it == seen.end())
          it = seen.emplace(r, static_cast<long long>(seen.size())).first;
        C(i, w) = static_cast<double>(it->second);
      }
    }
    return toValue(C);
  } SP_END
  SP_ADD("cophenet", 1, 2, "Z, dist") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    const size_t n = Z.r + 1;
    Mat C(n, n);
    for (size_t i = 0; i < Z.r; i++) {
      IVec l, r;
      leavesOf(Z, n, static_cast<size_t>(Z(i, 0)), l);
      leavesOf(Z, n, static_cast<size_t>(Z(i, 1)), r);
      for (long long x : l)
        for (long long y : r)
          C((size_t)x, (size_t)y) = C((size_t)y, (size_t)x) = Z(i, 2);
    }
    Vec coph;
    for (size_t i = 0; i < n; i++)
      for (size_t j = i + 1; j < n; j++)
        coph.push_back(C(i, j));
    if (a.size() < 2)
      return toValue(coph);
    Vec d;
    if (!getVec(a, 1, ctx, d))
      return Value(0.0);
    if (d.size() != coph.size()) {
      ctx.fail("dist must be the condensed distances of the same points");
      return Value(0.0);
    }
    double mc = 0.0, md = 0.0;
    for (size_t i = 0; i < d.size(); i++) {
      mc += coph[i];
      md += d[i];
    }
    mc /= static_cast<double>(d.size());
    md /= static_cast<double>(d.size());
    double sxy = 0.0, sxx = 0.0, syy = 0.0;
    for (size_t i = 0; i < d.size(); i++) {
      sxy += (coph[i] - mc) * (d[i] - md);
      sxx += (coph[i] - mc) * (coph[i] - mc);
      syy += (d[i] - md) * (d[i] - md);
    }
    return makeDict({{"c", Value(sxy / std::sqrt(sxx * syy))}, {"coph_dists", toValue(coph)}});
  } SP_END
  SP_ADD("inconsistent", 1, 2, "Z, depth=2") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    return toValue(inconsistency(Z, Z.r + 1, optInt(a, 1, 2)));
  } SP_END
  SP_ADD("max_inconsistent", 2, 2, "Z, R") {
    Mat Z, R;
    if (!getLinkage(a, 0, ctx, Z) || !getMat(a, 1, ctx, R))
      return Value(0.0);
    Vec own(Z.r);
    for (size_t i = 0; i < Z.r; i++)
      own[i] = R(i, 3);
    return toValue(maxOverSubtree(Z, Z.r + 1, own));
  } SP_END
  SP_ADD("max_dists", 1, 1, "Z") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    Vec own(Z.r);
    for (size_t i = 0; i < Z.r; i++)
      own[i] = Z(i, 2);
    return toValue(maxOverSubtree(Z, Z.r + 1, own));
  } SP_END
  SP_ADD("max_rstat", 3, 3, "Z, R, i") {
    Mat Z, R;
    long long col;
    if (!getLinkage(a, 0, ctx, Z) || !getMat(a, 1, ctx, R) || !argNonNegativeInt(a, 2, ctx, col))
      return Value(0.0);
    if (col > 3 || R.c != 4) {
      ctx.fail("i must be 0, 1, 2 or 3 and R an inconsistency matrix");
      return Value(0.0);
    }
    Vec own(Z.r);
    for (size_t i = 0; i < Z.r; i++)
      own[i] = R(i, (size_t)col);
    return toValue(maxOverSubtree(Z, Z.r + 1, own));
  } SP_END
  SP_ADD("to_mlab_linkage", 1, 1, "Z") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    Mat M(Z.r, 3);
    for (size_t i = 0; i < Z.r; i++) {
      M(i, 0) = Z(i, 0) + 1.0;
      M(i, 1) = Z(i, 1) + 1.0;
      M(i, 2) = Z(i, 2);
    }
    return toValue(M);
  } SP_END
  SP_ADD("from_mlab_linkage", 1, 1, "Z") {
    Mat M;
    if (!getMat(a, 0, ctx, M))
      return Value(0.0);
    if (M.c < 3) {
      ctx.fail("a MATLAB linkage matrix has three columns");
      return Value(0.0);
    }
    const size_t n = M.r + 1;
    Mat Z(M.r, 4);
    Vec sz(2 * n - 1, 1.0);
    for (size_t i = 0; i < M.r; i++) {
      for (int c = 0; c < 2; c++)
        if (!(M(i, c) >= 1.0) || !(M(i, c) <= (double)(n + i)) || M(i, c) != std::floor(M(i, c))) {
          ctx.fail("row " + std::to_string(i) + " joins a cluster that does not exist yet");
          return Value(0.0);
        }
      Z(i, 0) = M(i, 0) - 1.0;
      Z(i, 1) = M(i, 1) - 1.0;
      Z(i, 2) = M(i, 2);
      sz[n + i] = sz[(size_t)Z(i, 0)] + sz[(size_t)Z(i, 1)];
      Z(i, 3) = sz[n + i];
    }
    return toValue(Z);
  } SP_END
  SP_ADD("dendrogram", 1, 2, "Z, no_plot=0") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    const size_t n = Z.r + 1;
    // Lay out: smaller clusters first, heights at the merge distance, leaves 5, 15, 25...
    IVec leaves;
    Mat icoord(Z.r, 4), dcoord(Z.r, 4);
    std::function<void(size_t, double &, double &, size_t &)> walk2 = [&](size_t node, double &pos, double &h, size_t &row) {
      if (node < n) {
        pos = 5.0 + 10.0 * static_cast<double>(leaves.size());
        h = 0.0;
        leaves.push_back(static_cast<long long>(node));
        return;
      }
      size_t l = static_cast<size_t>(Z(node - n, 0)), r = static_cast<size_t>(Z(node - n, 1));
      const double cl = l < n ? 1.0 : Z(l - n, 3), cr = r < n ? 1.0 : Z(r - n, 3);
      if (cr < cl)
        std::swap(l, r);
      double pl, hl, pr, hr;
      walk2(l, pl, hl, row);
      walk2(r, pr, hr, row);
      pos = (pl + pr) / 2.0;
      h = Z(node - n, 2);
      icoord(row, 0) = pl;
      icoord(row, 1) = pl;
      icoord(row, 2) = pr;
      icoord(row, 3) = pr;
      dcoord(row, 0) = hl;
      dcoord(row, 1) = h;
      dcoord(row, 2) = h;
      dcoord(row, 3) = hr;
      row++;
    };
    double p, h;
    size_t row = 0;
    walk2(2 * n - 2, p, h, row);
    std::vector<std::string> cols(Z.r, g_linkColors.empty() ? "C0" : g_linkColors[0]);
    return makeDict({{"leaves", toValue(leaves)}, {"icoord", toValue(icoord)}, {"dcoord", toValue(dcoord)}, {"color_list", namesValue(cols)}});
  } SP_END
  SP_ADD("set_link_colors", 1, 1, "colors") {
    std::vector<std::string> c;
    if (a[0].isText) {
      c.push_back(a[0].text());
    } else if (a[0].isMatrix) {
      for (size_t i = 0; i < a[0].cols(); i++) {
        Value e = a[0].at(0, i);
        if (e.isText)
          c.push_back(e.text());
      }
    }
    if (c.empty()) {
      ctx.fail("colors must be text, e.g. [\"m\",\"c\",\"y\"]");
      return Value(0.0);
    }
    g_linkColors = c;
    return Value(0.0);
  } SP_END
  SP_ADD("leaves_list", 1, 1, "Z") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    IVec l;
    leavesOf(Z, Z.r + 1, 2 * Z.r, l);
    return toValue(l);
  } SP_END
  SP_ADD("optimal_leaf_order", 2, 2, "Z, data") {
    // Minimises the sum of neighbouring leaf distances (Bar-Joseph et al.), by
    // dynamic programming over the two end leaves of each subtree.
    Mat Z, P;
    if (!getLinkage(a, 0, ctx, Z) || !getMat(a, 1, ctx, P))
      return Value(0.0);
    const size_t n = Z.r + 1;
    if (P.r != n) {
      ctx.fail("data must hold the same points as the linkage");
      return Value(0.0);
    }
    Mat D(n, n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        D(i, j) = std::sqrt(sqDist(P.row(i), P.row(j), P.c));
    using Key = std::pair<long long, long long>;
    struct Best {
      double cost;
      long long m, k;
    };
    std::vector<std::map<Key, Best>> tab(Z.r);
    std::vector<IVec> lv(2 * n - 1);
    for (size_t i = 0; i < n; i++)
      lv[i] = {static_cast<long long>(i)};
    auto costOf = [&](size_t node, long long u, long long w) {
      if (node < n)
        return 0.0;
      return tab[node - n].at({u, w}).cost;
    };
    for (size_t i = 0; i < Z.r; i++) {
      size_t l = static_cast<size_t>(Z(i, 0)), r = static_cast<size_t>(Z(i, 1));
      lv[n + i] = lv[l];
      lv[n + i].insert(lv[n + i].end(), lv[r].begin(), lv[r].end());
      auto solve = [&](size_t L, size_t R) {
        for (long long u : lv[L])
          for (long long w : lv[R]) {
            Best b{kInf, -1, -1};
            auto innerL = lv[L].size() == 1 ? IVec{u} : lv[L];
            auto innerR = lv[R].size() == 1 ? IVec{w} : lv[R];
            for (long long m : innerL) {
              if (lv[L].size() > 1 && !tab[L - n].count({u, m}))
                continue;
              for (long long k : innerR) {
                if (lv[R].size() > 1 && !tab[R - n].count({k, w}))
                  continue;
                const double c = costOf(L, u, m) + D((size_t)m, (size_t)k) + costOf(R, k, w);
                if (c < b.cost)
                  b = {c, m, k};
              }
            }
            tab[i][{u, w}] = b;
            tab[i][{w, u}] = {b.cost, b.k, b.m};
          }
      };
      solve(l, r);
    }
    // Rebuild the order from the root, then rewrite Z so its children follow it.
    long long bu = -1, bw = -1;
    double bc = kInf;
    for (auto &e : tab[Z.r - 1])
      if (e.second.cost < bc) {
        bc = e.second.cost;
        bu = e.first.first;
        bw = e.first.second;
      }
    Mat Z2 = Z;
    std::function<void(size_t, long long, long long)> build = [&](size_t node, long long u, long long w) {
      if (node < n)
        return;
      const size_t i = node - n;
      size_t l = static_cast<size_t>(Z(i, 0)), r = static_cast<size_t>(Z(i, 1));
      if (std::find(lv[l].begin(), lv[l].end(), u) == lv[l].end())
        std::swap(l, r);
      Z2(i, 0) = static_cast<double>(l);
      Z2(i, 1) = static_cast<double>(r);
      const Best &b = tab[i].at({u, w});
      build(l, u, b.m);
      build(r, b.k, w);
    };
    build(2 * n - 2, bu, bw);
    return toValue(Z2);
  } SP_END
  SP_ADD("to_tree", 1, 1, "Z") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    return nodeDict(Z, Z.r + 1, 2 * Z.r);
  } SP_END
  SP_ADD("is_valid_linkage", 1, 1, "Z") {
    Mat Z;
    if (!readMat(a[0], Z) || Z.c != 4 || Z.r == 0)
      return Value::boolean(false);
    const size_t n = Z.r + 1;
    std::vector<char> used(2 * n - 1, 0);
    for (size_t i = 0; i < Z.r; i++) {
      if (Z(i, 2) < 0.0 || Z(i, 3) < 2.0)
        return Value::boolean(false);
      for (int s = 0; s < 2; s++) {
        const double v = Z(i, s);
        if (v < 0.0 || v != std::floor(v) || v >= static_cast<double>(n + i) || used[(size_t)v])
          return Value::boolean(false);
        used[(size_t)v] = 1;
      }
    }
    return Value::boolean(true);
  } SP_END
  SP_ADD("is_valid_inconsistency", 1, 1, "R") {
    Mat R;
    if (!readMat(a[0], R) || R.c != 4 || R.r == 0)
      return Value::boolean(false);
    for (size_t i = 0; i < R.r; i++)
      if (R(i, 1) < 0.0 || R(i, 2) < 0.0)
        return Value::boolean(false);
    return Value::boolean(true);
  } SP_END
  SP_ADD("is_monotonic", 1, 1, "Z") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    for (size_t i = 0; i + 1 < Z.r; i++)
      if (Z(i, 2) > Z(i + 1, 2))
        return Value::boolean(false);
    return Value::boolean(true);
  } SP_END
  SP_ADD("is_isomorphic", 2, 2, "a, b") {
    Vec x, y;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y))
      return Value(0.0);
    if (x.size() != y.size()) {
      ctx.fail("the two label lists must have the same length");
      return Value(0.0);
    }
    std::unordered_map<double, double> f, g;
    for (size_t i = 0; i < x.size(); i++) {
      auto fi = f.emplace(x[i], y[i]).first;
      auto gi = g.emplace(y[i], x[i]).first;
      if (fi->second != y[i] || gi->second != x[i])
        return Value::boolean(false);
    }
    return Value::boolean(true);
  } SP_END
  SP_ADD("linkage_corresponds", 2, 2, "Z, dist") {
    Mat Z;
    Vec d;
    if (!getLinkage(a, 0, ctx, Z) || !getVec(a, 1, ctx, d))
      return Value(0.0);
    const size_t n = Z.r + 1;
    return Value::boolean(n * (n - 1) / 2 == d.size());
  } SP_END
  SP_ADD("linkage_count", 1, 1, "Z") {
    Mat Z;
    if (!getLinkage(a, 0, ctx, Z))
      return Value(0.0);
    return Value(static_cast<double>(Z.r + 1));
  } SP_END
  SP_ADD("disjoint_set", 0, 1, "items") {
    Vec it;
    if (!a.empty() && !getVec(a, 0, ctx, it))
      return Value(0.0);
    Vec parent(it.size()), sz(it.size(), 1.0);
    for (size_t i = 0; i < it.size(); i++)
      parent[i] = static_cast<double>(i);
    return makeDict({{"items", toValue(it)}, {"parent", toValue(parent)}, {"size", toValue(sz)}, {"n_subsets", Value((double)it.size())}});
  } SP_END
  SP_ADD("ds_merge", 3, 3, "ds, a, b") {
    const Value *ip = dictGet(a[0], "items"), *pp = dictGet(a[0], "parent"), *sp = dictGet(a[0], "size"), *np = dictGet(a[0], "n_subsets");
    Vec it, parent, sz;
    double x, y;
    if (!ip || !pp || !sp || !np || !readVec(*ip, it) || !readVec(*pp, parent) || !readVec(*sp, sz)) {
      ctx.fail("the first argument must be the result of disjoint_set()");
      return Value(0.0);
    }
    if (!argNumber(a, 1, ctx, x) || !argNumber(a, 2, ctx, y))
      return Value(0.0);
    size_t ix, iy;
    if (!dsIndex(it, x, ix) || !dsIndex(it, y, iy)) {
      ctx.fail("the item is not in the set");
      return Value(0.0);
    }
    size_t rx = dsFind(parent, ix), ry = dsFind(parent, iy);
    double subsets = np->number;
    if (rx != ry) {
      if (sz[rx] < sz[ry])
        std::swap(rx, ry);
      parent[ry] = static_cast<double>(rx);
      sz[rx] += sz[ry];
      subsets -= 1.0;
    }
    return makeDict({{"items", toValue(it)}, {"parent", toValue(parent)}, {"size", toValue(sz)}, {"n_subsets", Value(subsets)}});
  } SP_END
  SP_ADD("ds_connected", 3, 3, "ds, a, b") {
    const Value *ip = dictGet(a[0], "items"), *pp = dictGet(a[0], "parent");
    Vec it, parent;
    double x, y;
    if (!ip || !pp || !readVec(*ip, it) || !readVec(*pp, parent)) {
      ctx.fail("the first argument must be the result of disjoint_set()");
      return Value(0.0);
    }
    if (!argNumber(a, 1, ctx, x) || !argNumber(a, 2, ctx, y))
      return Value(0.0);
    size_t ix, iy;
    if (!dsIndex(it, x, ix) || !dsIndex(it, y, iy)) {
      ctx.fail("the item is not in the set");
      return Value(0.0);
    }
    return Value::boolean(dsFind(parent, ix) == dsFind(parent, iy));
  } SP_END
  reg.setParallel({"assign_clusters", "kmeans", "kmeans2"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
