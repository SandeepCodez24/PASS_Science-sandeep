#include "sg_core.h"

#include "../fourier_transforms/ft_core.h"

namespace nc {
namespace scipy {
namespace sg {

CVec analytic(const Vec &xin, size_t n) {
  CVec z = toComplex(xin);
  z.resize(n, 0.0);
  ft::fft(z, false);
  for (size_t k = 1; k < n; k++) {
    if (2 * k < n)
      z[k] *= 2.0;
    else if (2 * k > n)
      z[k] = 0.0;
  }
  ft::fft(z, true);
  return z;
}

} // namespace sg
} // namespace scipy
} // namespace nc
