// LTI systems. A system is a Dict: {b, a}, {z, p, k} or {A, B, C, D}, with a key
// dt when it is discrete. Simulation works on the state-space form.
#include "../linear_algebra/la_core.h"
#include "sg_core.h"
#include "signal_processing_main.h"

#define SP_SEC Section::SignalProcessing

namespace nc {
namespace scipy {

using namespace sg;

namespace {

Value tagged(Value d, double dt) {
  if (dt != 0.0)
    d.dictMut().emplace("dt", Value(dt));
  return d;
}

struct System {
  enum Kind { Tf, Zp, State } kind = Tf;
  Vec b, a;
  Zpk f;
  Ss s;
  double dt = 0.0;
};

bool readSystem(const Value &v, System &o, std::string &err) {
  if (!v.isDict) {
    err = "the system must be a Dict from tf_system(), zpk_system(), ss_system() or lti_system()";
    return false;
  }
  if (const Value *d = dictGet(v, "dt"))
    o.dt = d->number;
  if (dictGet(v, "A")) {
    o.kind = System::State;
    const Value *B = dictGet(v, "B"), *C = dictGet(v, "C"), *D = dictGet(v, "D");
    if (!B || !C || !D || !readMat(*dictGet(v, "A"), o.s.A) || !readMat(*B, o.s.B) || !readMat(*C, o.s.C) || !readMat(*D, o.s.D)) {
      err = "this system needs the matrices A, B, C and D";
      return false;
    }
    return abcdNormalize(o.s, err);
  }
  if (dictGet(v, "z")) {
    o.kind = System::Zp;
    const Value *p = dictGet(v, "p"), *k = dictGet(v, "k");
    if (!p || !k || !readCVec(*dictGet(v, "z"), o.f.z) || !readCVec(*p, o.f.p)) {
      err = "this system needs z, p and k";
      return false;
    }
    o.f.k = k->number;
    return true;
  }
  const Value *b = dictGet(v, "b"), *a = dictGet(v, "a");
  if (!b || !a || !readVec(*b, o.b) || !readVec(*a, o.a)) {
    err = "the system must be a Dict from tf_system(), zpk_system(), ss_system() or lti_system()";
    return false;
  }
  return true;
}

bool asTf(const System &in, Vec &b, Vec &a, std::string &err) {
  if (in.kind == System::Tf) {
    b = in.b;
    a = in.a;
    return normalizeTf(b, a, err);
  }
  if (in.kind == System::Zp) {
    zpk2tf(in.f, b, a);
    return true;
  }
  if (in.s.D.r != 1 || in.s.B.c != 1) {
    err = "a one-input, one-output system is needed here";
    return false;
  }
  Mat num;
  ss2tf(in.s, 0, num, a);
  b = num.a;
  return normalizeTf(b, a, err);
}

bool asSs(const System &in, Ss &s, std::string &err) {
  if (in.kind == System::State) {
    s = in.s;
    return true;
  }
  Vec b, a;
  if (!asTf(in, b, a, err))
    return false;
  return tf2ss(b, a, s, err);
}

Vec defaultTimes(const Mat &A, size_t n) {
  CVec w;
  double r = kInf;
  if (A.r) {
    la::eigGeneral(toComplex(A), w, nullptr);
    for (const cd &v : w)
      r = std::min(r, std::fabs(v.real()));
  }
  if (r == 0.0 || std::isinf(r))
    r = 1.0;
  const double tc = 1.0 / r;
  Vec t(n);
  for (size_t i = 0; i < n; i++)
    t[i] = n > 1 ? 7.0 * tc * (double)i / (double)(n - 1) : 0.0;
  return t;
}

// Output as an Array for one output, as a Matrix (one row per step) otherwise.
Value signalsValue(const Mat &m) {
  if (m.c == 1)
    return toValue(m.a);
  return toValue(m);
}

// Simulates x' = Ax + Bu with the input held (interp false) or linear between steps.
bool simulate(const Ss &s, const Mat *U, const Vec &T, const Vec *X0, bool interp, Mat &Y, Mat &X, std::string &err) {
  const size_t n = s.A.r, m = s.B.c, steps = T.size();
  if (steps == 0) {
    err = "the time array must not be empty";
    return false;
  }
  X = Mat(steps, n);
  Vec x0(n, 0.0);
  if (X0) {
    if (X0->size() != n) {
      err = "the initial state must have one value per state";
      return false;
    }
    x0 = *X0;
  }
  if (T[0] < 0.0) {
    err = "the initial time must be nonnegative";
    return false;
  }
  if (T[0] > 0.0) {
    Mat E = la::expmReal([&] {
      Mat t = s.A;
      for (double &v : t.a)
        v *= T[0];
      return t;
    }());
    x0 = mulVec(E, x0);
  }
  std::copy(x0.begin(), x0.end(), X.row(0));
  const double dt = steps > 1 ? T[1] - T[0] : 0.0;
  for (size_t i = 1; i < steps; i++)
    if (std::fabs(T[i] - T[i - 1] - dt) > 1e-8 * (std::fabs(dt) + std::fabs(T[i]))) {
      err = "the time steps must be equally spaced";
      return false;
    }
  if (U && (U->r != steps || U->c != m)) {
    err = "the input must have one value per time step (one column per input)";
    return false;
  }
  if (steps > 1) {
    const size_t q = interp && U ? n + 2 * m : n + m;
    Mat M(q, q);
    for (size_t i = 0; i < n; i++) {
      for (size_t j = 0; j < n; j++)
        M(i, j) = s.A(i, j) * dt;
      for (size_t j = 0; j < m; j++)
        M(i, n + j) = s.B(i, j) * dt;
    }
    if (interp && U)
      for (size_t j = 0; j < m; j++)
        M(n + j, n + m + j) = 1.0;
    Mat E = la::expmReal(M);
    for (size_t k = 1; k < steps; k++) {
      Vec prev(X.row(k - 1), X.row(k - 1) + n), next(n, 0.0);
      for (size_t i = 0; i < n; i++) {
        for (size_t j = 0; j < n; j++)
          next[i] += E(i, j) * prev[j];
        if (U) {
          for (size_t j = 0; j < m; j++) {
            if (interp) {
              const double b1 = E(i, n + m + j), b0 = E(i, n + j) - b1;
              next[i] += b0 * (*U)(k - 1, j) + b1 * (*U)(k, j);
            } else {
              next[i] += E(i, n + j) * (*U)(k - 1, j);
            }
          }
        }
      }
      std::copy(next.begin(), next.end(), X.row(k));
    }
  }
  Y = Mat(steps, s.C.r);
  for (size_t k = 0; k < steps; k++)
    for (size_t i = 0; i < s.C.r; i++) {
      double v = 0.0;
      for (size_t j = 0; j < n; j++)
        v += s.C(i, j) * X(k, j);
      if (U)
        for (size_t j = 0; j < m; j++)
          v += s.D(i, j) * (*U)(k, j);
      Y(k, i) = v;
    }
  return true;
}

bool discreteRun(const Ss &s, const Mat &U, Mat &Y, Mat &X) {
  const size_t n = s.A.r, steps = U.r;
  X = Mat(steps, n);
  Y = Mat(steps, s.C.r);
  for (size_t k = 0; k < steps; k++) {
    for (size_t i = 0; i < s.C.r; i++) {
      double v = 0.0;
      for (size_t j = 0; j < n; j++)
        v += s.C(i, j) * X(k, j);
      for (size_t j = 0; j < s.D.c; j++)
        v += s.D(i, j) * U(k, j);
      Y(k, i) = v;
    }
    if (k + 1 < steps)
      for (size_t i = 0; i < n; i++) {
        double v = 0.0;
        for (size_t j = 0; j < n; j++)
          v += s.A(i, j) * X(k, j);
        for (size_t j = 0; j < s.B.c; j++)
          v += s.B(i, j) * U(k, j);
        X(k + 1, i) = v;
      }
  }
  return true;
}

// One input: an Array read as a column.
bool inputColumns(const Args &a, size_t i, CallContext &ctx, Mat &U) {
  if (!getMat(a, i, ctx, U))
    return false;
  if (U.r == 1 && U.c > 1)
    U = transposeOf(U);
  return true;
}

Vec lineTimes(size_t n, double dt) {
  Vec t(n);
  for (size_t i = 0; i < n; i++)
    t[i] = (double)i * dt;
  return t;
}

// The grid of a frequency response: an Array, a point count, or the default.
bool contResponse(const System &sys, const Args &a, size_t iw, size_t def, Vec &w, CVec &h, CallContext &ctx) {
  std::string err;
  if (sys.kind == System::State && (sys.s.D.r != 1 || sys.s.B.c != 1)) {
    ctx.fail("a one-input, one-output system is needed here");
    return false;
  }
  CVec z, p;
  double k = 1.0;
  Vec b, ca;
  if (sys.kind == System::Tf) {
    b = sys.b;
    ca = sys.a;
    if (!normalizeTf(b, ca, err)) {
      ctx.fail(err);
      return false;
    }
    z = rootsOf(b);
    p = rootsOf(ca);
  } else {
    Zpk f;
    if (sys.kind == System::Zp) {
      f = sys.f;
    } else {
      Vec nb, na;
      if (!asTf(sys, nb, na, err) || !tf2zpk(nb, na, f, err)) {
        ctx.fail(err);
        return false;
      }
    }
    z = f.z;
    p = f.p;
    k = f.k;
  }
  if (a.size() > iw && !isPlainNumber(a[iw])) {
    if (!getVec(a, iw, ctx, w))
      return false;
  } else {
    w = findFreqs(p, z, (size_t)(isOmitted(a, iw) ? (long long)def : optInt(a, iw, (long long)def)));
  }
  h.resize(w.size());
  for (size_t i = 0; i < w.size(); i++) {
    const cd s(0.0, w[i]);
    if (sys.kind == System::Tf) {
      h[i] = polyval(b, s) / polyval(ca, s);
    } else {
      cd v(k);
      for (const cd &q : z)
        v *= s - q;
      for (const cd &q : p)
        v /= s - q;
      h[i] = v;
    }
  }
  return true;
}

bool discResponse(const System &sys, const Args &a, size_t iw, size_t def, Vec &w, CVec &h, CallContext &ctx) {
  if (a.size() > iw && !isPlainNumber(a[iw])) {
    if (!getVec(a, iw, ctx, w))
      return false;
  } else {
    w = angleGrid((size_t)(isOmitted(a, iw) ? (long long)def : optInt(a, iw, (long long)def)), false);
  }
  std::string err;
  if (sys.kind == System::Tf) {
    Vec b = sys.b, ca = sys.a;
    // From powers of z to powers of 1/z.
    if (b.size() > ca.size())
      ca.insert(ca.begin(), b.size() - ca.size(), 0.0);
    else
      b.insert(b.begin(), ca.size() - b.size(), 0.0);
    h = freqzAt(b, ca, w);
    return true;
  }
  Zpk f;
  if (sys.kind == System::Zp) {
    f = sys.f;
  } else {
    Vec nb, na;
    if (!asTf(sys, nb, na, err) || !tf2zpk(nb, na, f, err)) {
      ctx.fail(err);
      return false;
    }
  }
  h = freqzZpkAt(f.z, f.p, f.k, w);
  return true;
}

Value bodeDict(const Vec &w, const CVec &h, double scale) {
  Vec mag(h.size()), ph(h.size()), wo(w);
  for (size_t i = 0; i < h.size(); i++) {
    mag[i] = 20.0 * std::log10(std::abs(h[i]));
    ph[i] = std::arg(h[i]);
  }
  ph = unwrapped(ph);
  for (double &v : ph)
    v *= 180.0 / kPi;
  for (double &v : wo)
    v *= scale;
  return makeDict({{"w", toValue(wo)}, {"mag", toValue(mag)}, {"phase", toValue(ph)}});
}

Mat scaled(Mat m, double f) {
  for (double &v : m.a)
    v *= f;
  return m;
}

bool discretize(const Ss &s, double dt, const std::string &methodIn, double alphaIn, Ss &o, std::string &err) {
  const size_t n = s.A.r, m = s.B.c;
  std::string method = methodIn;
  double alpha = alphaIn;
  if (method == "bilinear" || method == "tustin") {
    method = "gbt";
    alpha = 0.5;
  } else if (method == "euler" || method == "forward_diff") {
    method = "gbt";
    alpha = 0.0;
  } else if (method == "backward_diff") {
    method = "gbt";
    alpha = 1.0;
  }
  if (method == "gbt") {
    if (alpha < 0.0 || alpha > 1.0) {
      err = "alpha must be from 0 to 1";
      return false;
    }
    Mat ima = Mat::eye(n), ipa = Mat::eye(n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        ima(i, j) -= alpha * dt * s.A(i, j);
        ipa(i, j) += (1.0 - alpha) * dt * s.A(i, j);
      }
    o.A = ipa;
    o.B = scaled(s.B, dt);
    Mat Ct = transposeOf(s.C);
    if (!la::solve(ima, o.A) || !la::solve(ima, o.B) || !la::solve(transposeOf(ima), Ct)) {
      err = "this step and alpha give a singular system";
      return false;
    }
    o.C = transposeOf(Ct);
    o.D = s.D;
    Mat cb = mul(s.C, o.B);
    for (size_t i = 0; i < o.D.a.size(); i++)
      o.D.a[i] += alpha * cb.a[i];
    return true;
  }
  if (method == "zoh" || method == "foh") {
    const size_t q = method == "zoh" ? n + m : n + 2 * m;
    Mat M(q, q);
    for (size_t i = 0; i < n; i++) {
      for (size_t j = 0; j < n; j++)
        M(i, j) = s.A(i, j) * dt;
      for (size_t j = 0; j < m; j++)
        M(i, n + j) = s.B(i, j) * dt;
    }
    if (method == "foh")
      for (size_t j = 0; j < m; j++)
        M(n + j, n + m + j) = 1.0;
    Mat E = la::expmReal(M);
    o.A = Mat(n, n);
    o.B = Mat(n, m);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        o.A(i, j) = E(i, j);
    o.C = s.C;
    o.D = s.D;
    if (method == "zoh") {
      for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < m; j++)
          o.B(i, j) = E(i, n + j);
      return true;
    }
    Mat m13(n, m);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < m; j++)
        m13(i, j) = E(i, n + m + j);
    Mat am = mul(o.A, m13);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < m; j++)
        o.B(i, j) = E(i, n + j) - m13(i, j) + am(i, j);
    Mat cm = mul(s.C, m13);
    for (size_t i = 0; i < o.D.a.size(); i++)
      o.D.a[i] += cm.a[i];
    return true;
  }
  if (method == "impulse") {
    for (double v : s.D.a)
      if (v != 0.0) {
        err = "the impulse method needs D = 0";
        return false;
      }
    o.A = la::expmReal(scaled(s.A, dt));
    o.B = scaled(mul(o.A, s.B), dt);
    o.C = s.C;
    o.D = scaled(mul(s.C, s.B), dt);
    return true;
  }
  err = "method must be \"zoh\", \"foh\", \"gbt\", \"bilinear\", \"euler\", \"backward_diff\" or \"impulse\"";
  return false;
}

// Rank through the SVD.
size_t rankOf(const Mat &A) {
  Mat U, V;
  Vec s;
  la::svdThin(A, U, s, V);
  size_t r = 0;
  const double top = s.empty() ? 0.0 : s[0];
  for (double v : s)
    if (v > 1e-12 * top)
      r++;
  return r;
}

} // namespace

void registerSgSystems(Registry &reg) {
  SP_ADD("tf_system", 2, 3, "b, a, dt") {
    Vec b, ca;
    if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca))
      return Value(0.0);
    std::string err;
    if (!normalizeTf(b, ca, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return tagged(tfDict(b, ca), optNum(a, 2, 0.0));
  } SP_END
  SP_ADD("zpk_system", 3, 4, "z, p, k, dt") {
    Zpk f;
    if (!getCVec(a, 0, ctx, f.z) || !getCVec(a, 1, ctx, f.p))
      return Value(0.0);
    f.k = optNum(a, 2, 1.0);
    return tagged(zpkDict(f), optNum(a, 3, 0.0));
  } SP_ENDC
  SP_ADD("ss_system", 4, 5, "A, B, C, D, dt") {
    Ss s;
    if (!getMat(a, 0, ctx, s.A) || !getMat(a, 1, ctx, s.B) || !getMat(a, 2, ctx, s.C) || !getMat(a, 3, ctx, s.D))
      return Value(0.0);
    std::string err;
    if (!abcdNormalize(s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return tagged(ssDict(s), optNum(a, 4, 0.0));
  } SP_END
  SP_ADD("lti_system", 2, 4, "b, a  or  z, p, k  or  A, B, C, D") {
    std::string err;
    if (a.size() == 2) {
      Vec b, ca;
      if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca))
        return Value(0.0);
      if (!normalizeTf(b, ca, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
      return tfDict(b, ca);
    }
    if (a.size() == 3) {
      Zpk f;
      if (!getCVec(a, 0, ctx, f.z) || !getCVec(a, 1, ctx, f.p))
        return Value(0.0);
      f.k = optNum(a, 2, 1.0);
      return zpkDict(f);
    }
    Ss s;
    if (!getMat(a, 0, ctx, s.A) || !getMat(a, 1, ctx, s.B) || !getMat(a, 2, ctx, s.C) || !getMat(a, 3, ctx, s.D))
      return Value(0.0);
    if (!abcdNormalize(s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return ssDict(s);
  } SP_ENDC
#define SG_SYS(I)                                                                                  \
  System sys;                                                                                      \
  std::string err;                                                                                 \
  if (I >= a.size() || !readSystem(a[I], sys, err)) {                                              \
    ctx.fail(err.empty() ? "a system is needed" : err);                                            \
    return Value(0.0);                                                                             \
  }
  SP_ADD("lsim", 2, 5, "sys, u, t, x0, interp=1") {
    SG_SYS(0)
    Ss s;
    if (!asSs(sys, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Vec T, x0;
    if (!getVec(a, 2, ctx, T))
      return Value(0.0);
    const Vec *px = nullptr;
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (!getVec(a, 3, ctx, x0))
        return Value(0.0);
      px = &x0;
    }
    Mat U, Y, X;
    bool hasU = !isOmitted(a, 1);
    if (hasU && !inputColumns(a, 1, ctx, U))
      return Value(0.0);
    if (hasU && isPlainNumber(a[1])) {
      U = Mat(T.size(), s.B.c, a[1].number);
    }
    if (!simulate(s, hasU ? &U : nullptr, T, px, optBool(a, 4, true), Y, X, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return makeDict({{"t", toValue(T)}, {"y", signalsValue(Y)}, {"x", signalsValue(X)}});
  } SP_END
  SP_ADD("impulse_response", 1, 4, "sys, t, x0, n=100") {
    SG_SYS(0)
    Ss s;
    if (!asSs(sys, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Vec T, x0;
    if (a.size() > 1 && !isOmitted(a, 1)) {
      if (!getVec(a, 1, ctx, T))
        return Value(0.0);
    } else {
      T = defaultTimes(s.A, (size_t)(isOmitted(a, 3) ? 100 : optInt(a, 3, 100)));
    }
    Vec X(s.B.a);
    if (a.size() > 2 && !isOmitted(a, 2)) {
      if (!getVec(a, 2, ctx, x0))
        return Value(0.0);
      for (size_t i = 0; i < X.size() && i < x0.size(); i++)
        X[i] += x0[i];
    }
    Mat Y, XS;
    if (!simulate(s, nullptr, T, &X, false, Y, XS, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return makeDict({{"t", toValue(T)}, {"y", signalsValue(Y)}});
  } SP_END
  SP_ADD("step_response", 1, 4, "sys, t, x0, n=100") {
    SG_SYS(0)
    Ss s;
    if (!asSs(sys, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Vec T, x0;
    if (a.size() > 1 && !isOmitted(a, 1)) {
      if (!getVec(a, 1, ctx, T))
        return Value(0.0);
    } else {
      T = defaultTimes(s.A, (size_t)(isOmitted(a, 3) ? 100 : optInt(a, 3, 100)));
    }
    const Vec *px = nullptr;
    if (a.size() > 2 && !isOmitted(a, 2)) {
      if (!getVec(a, 2, ctx, x0))
        return Value(0.0);
      px = &x0;
    }
    Mat U(T.size(), s.B.c, 1.0), Y, X;
    if (!simulate(s, &U, T, px, false, Y, X, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return makeDict({{"t", toValue(T)}, {"y", signalsValue(Y)}});
  } SP_END
  SP_ADD("freq_response", 1, 2, "sys, w") {
    SG_SYS(0)
    Vec w;
    CVec h;
    if (!contResponse(sys, a, 1, 10000, w, h, ctx))
      return Value(0.0);
    return makeDict({{"w", toValue(w)}, {"H", toValue(h)}});
  } SP_END
  SP_ADD("bode", 1, 2, "sys, w") {
    SG_SYS(0)
    Vec w;
    CVec h;
    if (!contResponse(sys, a, 1, 100, w, h, ctx))
      return Value(0.0);
    return bodeDict(w, h, 1.0);
  } SP_END
  // ---- discrete systems ----
#define SG_DSYS(I)                                                                                 \
  SG_SYS(I)                                                                                        \
  if (sys.dt == 0.0) {                                                                             \
    ctx.fail("this needs a discrete system: give the step dt, e.g. tf_system(b, a, 0.1)");         \
    return Value(0.0);                                                                             \
  }
  SP_ADD("dlsim", 2, 2, "sys, u") {
    SG_DSYS(0)
    Ss s;
    if (!asSs(sys, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Mat U, Y, X;
    if (!inputColumns(a, 1, ctx, U))
      return Value(0.0);
    if (U.c != s.B.c) {
      ctx.fail("the input must have one column per system input");
      return Value(0.0);
    }
    discreteRun(s, U, Y, X);
    return makeDict({{"t", toValue(lineTimes(U.r, sys.dt))}, {"y", signalsValue(Y)}, {"x", signalsValue(X)}});
  } SP_END
  SP_ADD("dimpulse", 1, 2, "sys, n=100") {
    SG_DSYS(0)
    Ss s;
    if (!asSs(sys, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const size_t n = (size_t)(isOmitted(a, 1) ? 100 : optInt(a, 1, 100));
    Mat U(n, s.B.c), Y, X;
    if (n)
      U(0, 0) = 1.0;
    discreteRun(s, U, Y, X);
    return makeDict({{"t", toValue(lineTimes(n, sys.dt))}, {"y", signalsValue(Y)}});
  } SP_END
  SP_ADD("dstep", 1, 2, "sys, n=100") {
    SG_DSYS(0)
    Ss s;
    if (!asSs(sys, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const size_t n = (size_t)(isOmitted(a, 1) ? 100 : optInt(a, 1, 100));
    Mat U(n, s.B.c), Y, X;
    for (size_t i = 0; i < n; i++)
      U(i, 0) = 1.0;
    discreteRun(s, U, Y, X);
    return makeDict({{"t", toValue(lineTimes(n, sys.dt))}, {"y", signalsValue(Y)}});
  } SP_END
  SP_ADD("dfreq_response", 1, 2, "sys, w") {
    SG_DSYS(0)
    Vec w;
    CVec h;
    if (!discResponse(sys, a, 1, 10000, w, h, ctx))
      return Value(0.0);
    return makeDict({{"w", toValue(w)}, {"H", toValue(h)}});
  } SP_END
  SP_ADD("dbode", 1, 2, "sys, w") {
    SG_DSYS(0)
    Vec w;
    CVec h;
    if (!discResponse(sys, a, 1, 100, w, h, ctx))
      return Value(0.0);
    return bodeDict(w, h, 1.0 / sys.dt);
  } SP_END
  SP_ADD("cont2discrete", 2, 4, "sys, dt, method=\"zoh\", alpha") {
    SG_SYS(0)
    const double dt = optNum(a, 1, 0.0);
    if (dt <= 0.0) {
      ctx.fail("dt must be positive");
      return Value(0.0);
    }
    Ss s, o;
    if (!asSs(sys, s, err) || !discretize(s, dt, optText(a, 2, "zoh"), optNum(a, 3, 0.5), o, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (sys.kind == System::State)
      return tagged(ssDict(o), dt);
    Mat num;
    Vec den;
    ss2tf(o, 0, num, den);
    Vec bn = num.a;
    if (sys.kind == System::Zp) {
      Zpk f;
      if (!tf2zpk(bn, den, f, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
      return tagged(zpkDict(f), dt);
    }
    return tagged(tfDict(bn, den), dt);
  } SP_END
  SP_ADD("place_poles", 3, 3, "A, B, poles") {
    // Kautsky-Nichols-Van Dooren: an eigenvector for each pole inside the allowed
    // space, then sweeps that make them more orthogonal (for real poles).
    Mat A, B;
    CVec poles;
    if (!getSquare(a, 0, ctx, A) || !getMat(a, 1, ctx, B) || !getCVec(a, 2, ctx, poles))
      return Value(0.0);
    const size_t n = A.r;
    if (B.r != n) {
      ctx.fail("A and B must have the same number of rows");
      return Value(0.0);
    }
    if (poles.size() != n) {
      ctx.fail("one pole per state is needed");
      return Value(0.0);
    }
    const size_t rb = rankOf(B);
    if (rb == 0) {
      ctx.fail("B must not be zero");
      return Value(0.0);
    }
    // scipy's order: the reals, then complex pairs with the negative imaginary part leading.
    {
      CVec cplx, real;
      for (const cd &p : poles) {
        if (p.imag() == 0.0)
          real.push_back(p);
        else if (p.imag() > 0.0)
          cplx.push_back(p);
      }
      CVec neg;
      for (const cd &p : poles)
        if (p.imag() < 0.0)
          neg.push_back(p);
      if (cplx.size() != neg.size()) {
        ctx.fail("complex poles must come in conjugate pairs");
        return Value(0.0);
      }
      std::sort(neg.begin(), neg.end(), [](const cd &x, const cd &y) { return x.real() != y.real() ? x.real() < y.real() : x.imag() < y.imag(); });
      std::sort(real.begin(), real.end(), [](const cd &x, const cd &y) { return x.real() < y.real(); });
      poles = real;
      for (const cd &p : neg) {
        poles.push_back(p);
        poles.push_back(std::conj(p));
      }
    }
    Mat Qb, Rb;
    la::qrFactor(B, Qb, Rb);
    Mat U1(n, n - rb), U0(n, rb), Z(rb, B.c);
    for (size_t i = 0; i < n; i++) {
      for (size_t j = 0; j < rb; j++)
        U0(i, j) = Qb(i, j);
      for (size_t j = rb; j < n; j++)
        U1(i, j - rb) = Qb(i, j);
    }
    for (size_t i = 0; i < rb; i++)
      for (size_t j = 0; j < B.c; j++)
        Z(i, j) = Rb(i, j);
    Mat K;
    if (rb == n) {
      Mat D(n, n);
      for (size_t i = 0; i < n; i++) {
        D(i, i) = poles[i].real();
        if (poles[i].imag() != 0.0) {
          D(i, i + 1) = -poles[i].imag();
          D(i + 1, i + 1) = poles[i].real();
          D(i + 1, i) = poles[i].imag();
          i++;
        }
      }
      for (size_t i = 0; i < n * n; i++)
        D.a[i] -= A.a[i];
      K = mul(la::pinv(B), D);
    } else {
      CMat X(n, n);
      std::vector<Mat> kers(n);
      for (size_t j = 0; j < n; j++) {
        // The kernel of U1'(A - p I), as columns.
        CMat S(n - rb, n);
        for (size_t i = 0; i < n - rb; i++)
          for (size_t k = 0; k < n; k++) {
            cd v(0.0);
            for (size_t q = 0; q < n; q++)
              v += U1(q, i) * (A(q, k) - (q == k ? poles[j] : cd(0.0)));
            S(i, k) = v;
          }
        CMat Q, R;
        la::qrFactor(adjointOf(S), Q, R);
        CVec x(n, cd(0.0));
        for (size_t c = n - rb; c < n; c++)
          for (size_t i = 0; i < n; i++)
            x[i] += Q(i, c);
        double nn = 0.0;
        for (const cd &v : x)
          nn += std::norm(v);
        nn = std::sqrt(nn);
        for (size_t i = 0; i < n; i++)
          X(i, j) = x[i] / nn;
        if (poles[j].imag() == 0.0) {
          Mat ker(n, rb);
          for (size_t i = 0; i < n; i++)
            for (size_t c = 0; c < rb; c++)
              ker(i, c) = Q(i, n - rb + c).real();
          // Real pole: the real kernel, taken from the real matrix.
          Mat Sr(n - rb, n);
          for (size_t i = 0; i < Sr.a.size(); i++)
            Sr.a[i] = S.a[i].real();
          Mat Qr, Rr;
          la::qrFactor(transposeOf(Sr), Qr, Rr);
          for (size_t i = 0; i < n; i++)
            for (size_t c = 0; c < rb; c++)
              ker(i, c) = Qr(i, n - rb + c);
          kers[j] = ker;
          Vec xr(n, 0.0);
          for (size_t c = 0; c < rb; c++)
            for (size_t i = 0; i < n; i++)
              xr[i] += ker(i, c);
          double rn = 0.0;
          for (double v : xr)
            rn += v * v;
          rn = std::sqrt(rn);
          for (size_t i = 0; i < n; i++)
            X(i, j) = xr[i] / rn;
        }
        if (poles[j].imag() != 0.0) {
          for (size_t i = 0; i < n; i++)
            X(i, j + 1) = std::conj(X(i, j));
          j++;
        }
      }
      if (rb > 1) {
        for (int sweep = 0; sweep < 30; sweep++) {
          for (size_t j = 0; j < n; j++) {
            if (poles[j].imag() != 0.0 || kers[j].a.empty())
              continue;
            CMat Y(n, n - 1);
            for (size_t i = 0; i < n; i++) {
              size_t q = 0;
              for (size_t c = 0; c < n; c++)
                if (c != j)
                  Y(i, q++) = X(i, c);
            }
            CMat Q, R;
            la::qrFactor(Y, Q, R);
            CVec y(n);
            for (size_t i = 0; i < n; i++)
              y[i] = Q(i, n - 1);
            CVec nx(n, cd(0.0));
            const Mat &ker = kers[j];
            for (size_t c = 0; c < ker.c; c++) {
              cd d(0.0);
              for (size_t i = 0; i < n; i++)
                d += ker(i, c) * y[i];
              for (size_t i = 0; i < n; i++)
                nx[i] += ker(i, c) * d;
            }
            double nn = 0.0;
            for (const cd &v : nx)
              nn += std::norm(v);
            if (nn > 1e-20) {
              nn = std::sqrt(nn);
              for (size_t i = 0; i < n; i++)
                X(i, j) = nx[i] / nn;
            }
          }
        }
      }
      // M = X diag(p) X^-1; B K = M - A.
      CMat Xi;
      if (!la::inverse(X, Xi)) {
        ctx.fail("the poles could not be placed: the transfer matrix is singular");
        return Value(0.0);
      }
      CMat D = X;
      for (size_t j = 0; j < n; j++)
        for (size_t i = 0; i < n; i++)
          D(i, j) *= poles[j];
      CMat MM = mul(D, Xi);
      Mat diff(n, n);
      for (size_t i = 0; i < n * n; i++)
        diff.a[i] = MM.a[i].real() - A.a[i];
      Mat rhs = mul(transposeOf(U0), diff);
      K = mul(la::pinv(Z), rhs);
    }
    // scipy's sign: the closed loop is A - B K.
    for (double &v : K.a)
      v = -v;
    Mat loop = A, bk = mul(B, K);
    for (size_t i = 0; i < n * n; i++)
      loop.a[i] -= bk.a[i];
    CVec got;
    la::eigGeneral(toComplex(loop), got, nullptr);
    sortRoots(got);
    return makeDict({{"gain_matrix", toValue(K)}, {"computed_poles", realIfPossible(got)}, {"requested_poles", realIfPossible(poles)}});
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
