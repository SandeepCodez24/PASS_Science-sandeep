// Spectral estimation: periodogram, Welch, cross spectra, spectrogram, STFT in both
// of scipy's forms, Lomb-Scargle, and the chirp-z transform.
#include "../fourier_transforms/ft_core.h"
#include "../fourier_transforms/ft_shared.h"
#include "sg_core.h"
#include "signal_processing_main.h"

#define SP_SEC Section::SignalProcessing

namespace nc {
namespace scipy {

using namespace sg;

namespace {

struct SegSpec {
  double fs = 1.0;
  size_t nperseg = 256, noverlap = 0, nfft = 0;
  Vec win;
  bool detrendOn = true;
  bool density = true;
};

// The window argument gives the segment length when it holds the samples.
bool segSetup(const Args &a, size_t iWin, size_t iSeg, size_t iOver, size_t iNfft, const std::string &defWin, size_t n, size_t defOverDiv, SegSpec &s, CallContext &ctx) {
  const bool hasWin = a.size() > iWin && !isOmitted(a, iWin);
  long long seg = isOmitted(a, iSeg) ? 0 : optInt(a, iSeg, 0);
  std::string err;
  if (hasWin && isWindowSamples(a[iWin])) {
    if (!readVec(a[iWin], s.win) || s.win.empty()) {
      ctx.fail("the window must not be empty");
      return false;
    }
    if (seg && (size_t)seg != s.win.size()) {
      ctx.fail("nperseg must match the length of the window");
      return false;
    }
    s.nperseg = s.win.size();
    if (s.nperseg > n) {
      ctx.fail("the window is longer than the data");
      return false;
    }
  } else {
    s.nperseg = seg > 0 ? (size_t)seg : 256;
    if (s.nperseg > n)
      s.nperseg = n;
    bool ok;
    if (hasWin) {
      ok = windowFromValue(a[iWin], s.nperseg, false, s.win, err);
    } else {
      if (defWin == "tukey-0.25")
        ok = windowByName("tukey", {0.25}, s.nperseg, false, s.win, err);
      else
        ok = windowByName(defWin, {}, s.nperseg, false, s.win, err);
    }
    if (!ok) {
      ctx.fail(err);
      return false;
    }
  }
  if (a.size() > iOver && !isOmitted(a, iOver)) {
    const long long o = optInt(a, iOver, 0);
    if (o < 0 || (size_t)o >= s.nperseg) {
      ctx.fail("noverlap must be less than nperseg");
      return false;
    }
    s.noverlap = (size_t)o;
  } else {
    s.noverlap = s.nperseg / defOverDiv;
  }
  const long long nf = isOmitted(a, iNfft) ? 0 : optInt(a, iNfft, 0);
  if (nf && (size_t)nf < s.nperseg) {
    ctx.fail("nfft must be at least nperseg");
    return false;
  }
  s.nfft = nf ? (size_t)nf : s.nperseg;
  return true;
}

// conj(X) * Y of the windowed segments, one column per segment, one-sided.
CMat crossSegments(const Vec &x, const Vec *y, const SegSpec &s, bool stftMode) {
  const size_t step = s.nperseg - s.noverlap, n = x.size();
  const size_t segs = n >= s.nperseg ? (n - s.nperseg) / step + 1 : 0;
  const size_t bins = s.nfft / 2 + 1;
  double sw = 0.0, sw2 = 0.0;
  for (double v : s.win) {
    sw += v;
    sw2 += v * v;
  }
  const double scale = stftMode ? 1.0 / sw : (s.density ? 1.0 / (s.fs * sw2) : 1.0 / (sw * sw));
  CMat R(bins, segs);
  auto transform = [&](const Vec &d, size_t k) {
    Vec seg(d.begin() + (long)(k * step), d.begin() + (long)(k * step + s.nperseg));
    if (s.detrendOn)
      seg = detrendLine(seg, false);
    CVec f(s.nfft, cd(0.0));
    for (size_t i = 0; i < s.nperseg; i++)
      f[i] = seg[i] * s.win[i];
    ft::fft(f, false);
    return f;
  };
  for (size_t k = 0; k < segs; k++) {
    CVec fx = transform(x, k);
    if (stftMode) {
      for (size_t b = 0; b < bins; b++)
        R(b, k) = fx[b] * scale;
      continue;
    }
    CVec fy = y ? transform(*y, k) : fx;
    for (size_t b = 0; b < bins; b++) {
      cd v = std::conj(fx[b]) * fy[b] * scale;
      if (b > 0 && !(s.nfft % 2 == 0 && b == bins - 1))
        v *= 2.0;
      R(b, k) = v;
    }
  }
  return R;
}

Vec freqAxis(const SegSpec &s) {
  Vec f(s.nfft / 2 + 1);
  for (size_t i = 0; i < f.size(); i++)
    f[i] = (double)i * s.fs / (double)s.nfft;
  return f;
}

Vec timeAxis(size_t n, const SegSpec &s) {
  const size_t step = s.nperseg - s.noverlap;
  Vec t;
  for (double v = (double)s.nperseg / 2.0; v < (double)n - (double)s.nperseg / 2.0 + 1.0; v += (double)step)
    t.push_back(v / s.fs);
  return t;
}

CVec meanColumns(const CMat &R) {
  CVec o(R.r, cd(0.0));
  for (size_t i = 0; i < R.r; i++) {
    for (size_t k = 0; k < R.c; k++)
      o[i] += R(i, k);
    if (R.c)
      o[i] /= (double)R.c;
  }
  return o;
}

Vec realOf(const CVec &v) { return realParts(v); }

cd complexArg(const Args &a, size_t i, cd def) {
  if (i >= a.size() || !isPlainNumber(a[i]))
    return def;
  return a[i].isComplex ? cd(a[i].number, a[i].imag) : cd(a[i].number);
}

// X_k = sum x_n a^-n w^(n k), through Bluestein's convolution.
CVec cztCore(const CVec &x, size_t m, cd w, cd a) {
  const size_t n = x.size();
  const cd lw = std::log(w), la = std::log(a);
  auto wPow = [&](double sq) { return std::exp(lw * (sq / 2.0)); };
  CVec u(n), h(n + m - 1);
  for (size_t i = 0; i < n; i++)
    u[i] = x[i] * std::exp(-la * (double)i) * wPow((double)i * (double)i);
  for (size_t j = 0; j < h.size(); j++) {
    const double d = (double)j - (double)(n - 1);
    h[j] = 1.0 / wPow(d * d);
  }
  CVec c = ft::convolveFullC(u, h);
  CVec o(m);
  for (size_t k = 0; k < m; k++)
    o[k] = wPow((double)k * (double)k) * c[k + n - 1];
  return o;
}

} // namespace

void registerSgSpectral(Registry &reg) {
  SP_ADD("periodogram", 1, 4, "data, fs=1, window=\"boxcar\", nfft") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    SegSpec s;
    s.fs = isOmitted(a, 1) ? 1.0 : optNum(a, 1, 1.0);
    std::string err;
    s.nperseg = x.size();
    if (a.size() > 2 && !isOmitted(a, 2)) {
      if (!windowFromValue(a[2], x.size(), false, s.win, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
    } else {
      s.win.assign(x.size(), 1.0);
    }
    const long long nf = isOmitted(a, 3) ? 0 : optInt(a, 3, 0);
    Vec d = x;
    if (nf && (size_t)nf < x.size()) {
      d.resize((size_t)nf);
      s.win.resize((size_t)nf);
      s.nperseg = (size_t)nf;
    }
    s.nfft = nf ? (size_t)nf : x.size();
    CMat R = crossSegments(d, nullptr, s, false);
    return makeDict({{"f", toValue(freqAxis(s))}, {"Pxx", toValue(realOf(meanColumns(R)))}});
  } SP_END
  SP_ADD("welch", 1, 6, "data, fs=1, nperseg=256, window=\"hann\", noverlap, nfft") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    SegSpec s;
    s.fs = isOmitted(a, 1) ? 1.0 : optNum(a, 1, 1.0);
    if (!segSetup(a, 3, 2, 4, 5, "hann", x.size(), 2, s, ctx))
      return Value(0.0);
    CMat R = crossSegments(x, nullptr, s, false);
    return makeDict({{"f", toValue(freqAxis(s))}, {"Pxx", toValue(realOf(meanColumns(R)))}});
  } SP_END
  SP_ADD("csd", 2, 7, "x, y, fs=1, nperseg=256, window=\"hann\", noverlap, nfft") {
    Vec x, y;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y))
      return Value(0.0);
    if (x.size() != y.size() || x.empty()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    SegSpec s;
    s.fs = isOmitted(a, 2) ? 1.0 : optNum(a, 2, 1.0);
    if (!segSetup(a, 4, 3, 5, 6, "hann", x.size(), 2, s, ctx))
      return Value(0.0);
    CMat R = crossSegments(x, &y, s, false);
    return makeDict({{"f", toValue(freqAxis(s))}, {"Pxy", toValue(meanColumns(R))}});
  } SP_END
  SP_ADD("coherence", 2, 7, "x, y, fs=1, nperseg=256, window=\"hann\", noverlap, nfft") {
    Vec x, y;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y))
      return Value(0.0);
    if (x.size() != y.size() || x.empty()) {
      ctx.fail("x and y must have the same length");
      return Value(0.0);
    }
    SegSpec s;
    s.fs = isOmitted(a, 2) ? 1.0 : optNum(a, 2, 1.0);
    if (!segSetup(a, 4, 3, 5, 6, "hann", x.size(), 2, s, ctx))
      return Value(0.0);
    const CVec pxy = meanColumns(crossSegments(x, &y, s, false));
    const CVec pxx = meanColumns(crossSegments(x, nullptr, s, false)), pyy = meanColumns(crossSegments(y, nullptr, s, false));
    Vec c(pxy.size());
    for (size_t i = 0; i < c.size(); i++)
      c[i] = std::norm(pxy[i]) / pxx[i].real() / pyy[i].real();
    return makeDict({{"f", toValue(freqAxis(s))}, {"Cxy", toValue(c)}});
  } SP_END
  SP_ADD("spectrogram", 1, 6, "data, fs=1, nperseg=256, window, noverlap, nfft") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    SegSpec s;
    s.fs = isOmitted(a, 1) ? 1.0 : optNum(a, 1, 1.0);
    if (!segSetup(a, 3, 2, 4, 5, "tukey-0.25", x.size(), 8, s, ctx))
      return Value(0.0);
    CMat R = crossSegments(x, nullptr, s, false);
    Mat P(R.r, R.c);
    for (size_t i = 0; i < R.a.size(); i++)
      P.a[i] = R.a[i].real();
    return makeDict({{"f", toValue(freqAxis(s))}, {"t", toValue(timeAxis(x.size(), s))}, {"Sxx", toValue(P)}});
  } SP_END
  SP_ADD("stft", 1, 6, "data, window, hop, fs  or  data, fs=1, nperseg=256, window=\"hann\", noverlap, nfft") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    // ShortTimeFFT form: the second input holds the window samples.
    if (a.size() > 1 && isWindowSamples(a[1])) {
      Vec w;
      if (!readVec(a[1], w) || w.empty() || !isNumberArg(a, 2)) {
        ctx.fail("this form is stft(data, window samples, hop, fs)");
        return Value(0.0);
      }
      const long hop = (long)a[2].number, m = (long)w.size(), mid = m / 2, n = (long)x.size();
      if (hop < 1) {
        ctx.fail("hop must be 1 or more");
        return Value(0.0);
      }
      if (n < m - mid) {
        ctx.fail("the data must have at least half a window of samples");
        return Value(0.0);
      }
      auto allZero = [&](long from, long to) {
        for (long i = std::max(0L, from); i < std::min(m, to); i++)
          if (w[(size_t)i] != 0.0)
            return false;
        return true;
      };
      // First slice: move left until the window no longer reaches t >= 0.
      long pMin = 0;
      for (long nn = -mid, p = 0; nn > -mid - m - 1; nn -= hop, p++) {
        const long next = nn - hop;
        if (next + m <= 0 || allZero(m + next, m)) {
          pMin = -p;
          break;
        }
      }
      // Last slice: move right until the window no longer reaches t < n.
      long q1 = n / hop, pMax = q1 + 1;
      for (long k = q1 * hop - mid, q = q1; k < n + m; k += hop, q++) {
        const long next = k + hop;
        if (next >= n || allZero(0, n - next)) {
          pMax = q + 1;
          break;
        }
      }
      const size_t bins = (size_t)m / 2 + 1, cols = (size_t)(pMax - pMin);
      CMat S(bins, cols);
      for (long p = pMin; p < pMax; p++) {
        const long k0 = p * hop - mid;
        CVec f((size_t)m);
        for (long i = 0; i < m; i++) {
          const long idx = k0 + i;
          const double v = idx >= 0 && idx < n ? x[(size_t)idx] : 0.0;
          // Rolled by the window's middle, as scipy does: time zero at bin phase zero.
          f[(size_t)(((i - mid) % m + m) % m)] = v * w[(size_t)i];
        }
        ft::fft(f, false);
        for (size_t b = 0; b < bins; b++)
          S(b, (size_t)(p - pMin)) = f[b];
      }
      return toValue(S);
    }
    SegSpec s;
    s.fs = isOmitted(a, 1) ? 1.0 : optNum(a, 1, 1.0);
    s.detrendOn = false;
    if (!segSetup(a, 3, 2, 4, 5, "hann", x.size(), 2, s, ctx))
      return Value(0.0);
    // Boundary zeros, then padding to a whole number of steps.
    const size_t step = s.nperseg - s.noverlap, half = s.nperseg / 2;
    Vec ext(half, 0.0);
    ext.insert(ext.end(), x.begin(), x.end());
    ext.insert(ext.end(), half, 0.0);
    const size_t rest = (ext.size() - s.nperseg) % step;
    if (rest)
      ext.insert(ext.end(), step - rest, 0.0);
    CMat Z = crossSegments(ext, nullptr, s, true);
    Vec t = timeAxis(ext.size(), s);
    for (double &v : t)
      v -= ((double)s.nperseg / 2.0) / s.fs;
    return makeDict({{"f", toValue(freqAxis(s))}, {"t", toValue(t)}, {"Zxx", toValue(Z)}});
  } SP_END
  SP_ADD("istft", 1, 6, "Zxx, fs=1, nperseg, window=\"hann\", noverlap, nfft") {
    CMat Z;
    if (!getCMat(a, 0, ctx, Z))
      return Value(0.0);
    if (Z.r < 2 || Z.c < 1) {
      ctx.fail("Zxx must have at least two rows (frequencies) and one column (time)");
      return Value(0.0);
    }
    const double fs = isOmitted(a, 1) ? 1.0 : optNum(a, 1, 1.0);
    const size_t def = 2 * (Z.r - 1);
    const size_t nfftA = isOmitted(a, 5) ? 0 : (size_t)optInt(a, 5, 0);
    const size_t nperseg = isOmitted(a, 2) ? (nfftA ? nfftA : def) : (size_t)optInt(a, 2, 0);
    const size_t nfft = nfftA ? nfftA : nperseg;
    if (nfft / 2 + 1 != Z.r) {
      ctx.fail("nperseg does not match the number of rows of Zxx");
      return Value(0.0);
    }
    const size_t noverlap = isOmitted(a, 4) ? nperseg / 2 : (size_t)optInt(a, 4, 0);
    if (noverlap >= nperseg) {
      ctx.fail("noverlap must be less than nperseg");
      return Value(0.0);
    }
    const size_t step = nperseg - noverlap;
    Vec w;
    std::string err;
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (!windowFromValue(a[3], nperseg, false, w, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
    } else if (!windowByName("hann", {}, nperseg, false, w, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    double sw = 0.0;
    for (double v : w)
      sw += v;
    const size_t segs = Z.c, outLen = nperseg + (segs - 1) * step;
    Vec x(outLen, 0.0), norm(outLen, 0.0);
    for (size_t k = 0; k < segs; k++) {
      CVec col(Z.r);
      for (size_t b = 0; b < Z.r; b++)
        col[b] = Z(b, k);
      Vec seg = ft::irfftLine(col, nfft);
      for (size_t i = 0; i < nperseg; i++) {
        x[k * step + i] += seg[i] * sw * w[i];
        norm[k * step + i] += w[i] * w[i];
      }
    }
    const size_t half = nperseg / 2;
    Vec o;
    for (size_t i = half; i + half < outLen; i++)
      o.push_back(x[i] / (norm[i] > 1e-10 ? norm[i] : 1.0));
    Vec t(o.size());
    for (size_t i = 0; i < t.size(); i++)
      t[i] = (double)i / fs;
    return makeDict({{"t", toValue(t)}, {"x", toValue(o)}});
  } SP_ENDC
  SP_ADD("stft_dual_window", 2, 3, "window, hop, desired_dual") {
    Vec w, des;
    if (!getVec(a, 0, ctx, w))
      return Value(0.0);
    const long long hop = optInt(a, 1, 0);
    if (hop < 1 || (size_t)hop > w.size() || w.empty()) {
      ctx.fail("hop must be from 1 to the window length");
      return Value(0.0);
    }
    if (a.size() > 2 && !isOmitted(a, 2)) {
      if (!getVec(a, 2, ctx, des))
        return Value(0.0);
      if (des.size() != w.size()) {
        ctx.fail("desired_dual must have the length of the window");
        return Value(0.0);
      }
    } else {
      des.assign(w.size(), 1.0);
    }
    const size_t n = w.size(), h = (size_t)hop;
    auto spread = [&](const Vec &v) {
      Vec o = v;
      for (size_t k = h; k < n; k += h)
        for (size_t i = 0; i + k < n; i++) {
          o[i + k] += v[i];
          o[i] += v[i + k];
        }
      return o;
    };
    Vec w2(n), wdd(n);
    for (size_t i = 0; i < n; i++) {
      w2[i] = w[i] * w[i];
      wdd[i] = w[i] * des[i];
    }
    Vec DD = spread(w2);
    const double top = *std::max_element(DD.begin(), DD.end());
    for (double v : DD)
      if (v < 1e-15 * top) {
        ctx.fail("this window and hop do not give an invertible transform");
        return Value(0.0);
      }
    Vec wd(n), qd = spread(wdd);
    for (size_t i = 0; i < n; i++) {
      wd[i] = w[i] / DD[i];
      qd[i] *= wd[i];
    }
    double num = 0.0, den = 0.0;
    for (size_t i = 0; i < n; i++) {
      num += qd[i] * wd[i];
      den += qd[i] * qd[i];
    }
    const double alpha = num / den;
    Vec dual(n);
    for (size_t i = 0; i < n; i++)
      dual[i] = wd[i] + alpha * (des[i] - qd[i]);
    return makeDict({{"dual", toValue(dual)}, {"alpha", Value(alpha)}});
  } SP_END
  SP_ADD("lomb_scargle", 3, 6, "t, y, freqs, normalize=0, floating_mean=0, weights") {
    Vec x, y, freqs, wt;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, y) || !getVec(a, 2, ctx, freqs))
      return Value(0.0);
    if (x.size() != y.size() || x.empty() || freqs.empty()) {
      ctx.fail("t and y must have the same length, and freqs must not be empty");
      return Value(0.0);
    }
    std::string norm = "power";
    if (a.size() > 3) {
      if (a[3].isText)
        norm = a[3].text();
      else if (optBool(a, 3, false))
        norm = "normalize";
    }
    if (norm != "power" && norm != "normalize" && norm != "amplitude") {
      ctx.fail("normalize must be 0, 1, \"power\", \"normalize\" or \"amplitude\"");
      return Value(0.0);
    }
    const bool fm = optBool(a, 4, false);
    const size_t n = x.size();
    if (a.size() > 5 && !isOmitted(a, 5)) {
      if (!getVec(a, 5, ctx, wt))
        return Value(0.0);
      if (wt.size() != n) {
        ctx.fail("weights must have the length of t");
        return Value(0.0);
      }
    } else {
      wt.assign(n, 1.0);
    }
    double ws = 0.0;
    for (double v : wt) {
      if (v < 0.0) {
        ctx.fail("weights must not be negative");
        return Value(0.0);
      }
      ws += v;
    }
    if (ws <= 0.0) {
      ctx.fail("weights must sum to a positive value");
      return Value(0.0);
    }
    for (double &v : wt)
      v /= ws;
    double Y = 0.0, YY = 0.0;
    for (size_t i = 0; i < n; i++) {
      Y += wt[i] * y[i];
      YY += wt[i] * y[i] * y[i];
    }
    if (fm)
      YY -= Y * Y;
    const double epsneg = kEps / 2.0;
    Vec pg(freqs.size());
    CVec amp(freqs.size());
    for (size_t f = 0; f < freqs.size(); f++) {
      double CC = 0.0, CS = 0.0, C = 0.0, S = 0.0;
      for (size_t i = 0; i < n; i++) {
        const double ph = freqs[f] * x[i], c = std::cos(ph), s = std::sin(ph);
        CC += wt[i] * c * c;
        CS += wt[i] * c * s;
        C += wt[i] * c;
        S += wt[i] * s;
      }
      double SS = 1.0 - CC;
      if (fm) {
        CC -= C * C;
        SS -= S * S;
        CS -= C * S;
      }
      const double tau = 0.5 * std::atan2(2.0 * CS, CC - SS);
      double YC = 0.0, YS = 0.0;
      CC = 0.0;
      C = 0.0;
      S = 0.0;
      for (size_t i = 0; i < n; i++) {
        const double ph = freqs[f] * x[i] - tau, c = std::cos(ph), s = std::sin(ph);
        YC += wt[i] * y[i] * c;
        YS += wt[i] * y[i] * s;
        CC += wt[i] * c * c;
        C += wt[i] * c;
        S += wt[i] * s;
      }
      SS = 1.0 - CC;
      if (fm) {
        YC -= Y * C;
        YS -= Y * S;
        CC -= C * C;
        SS -= S * S;
      }
      CC = std::max(CC, epsneg);
      SS = std::max(SS, epsneg);
      const double ca = YC / CC, cb = YS / SS;
      pg[f] = 2.0 * (ca * YC + cb * YS);
      if (norm == "power")
        pg[f] *= (double)n / 4.0;
      else if (norm == "normalize")
        pg[f] *= 0.5 / YY;
      else
        amp[f] = cd(ca, cb) * std::polar(1.0, tau);
    }
    return norm == "amplitude" ? toValue(amp) : toValue(pg);
  } SP_END
  SP_ADD("vector_strength", 2, 2, "events, period") {
    Vec ev, pd;
    if (!getVec(a, 0, ctx, ev) || !getVec(a, 1, ctx, pd))
      return Value(0.0);
    if (pd.empty()) {
      ctx.fail("period must not be empty");
      return Value(0.0);
    }
    Vec st, ph;
    for (double p : pd) {
      if (p <= 0.0) {
        ctx.fail("periods must be positive");
        return Value(0.0);
      }
      cd m(0.0);
      for (double e : ev)
        m += std::polar(1.0, 2.0 * kPi * e / p);
      m /= (double)ev.size();
      st.push_back(std::abs(m));
      ph.push_back(std::arg(m));
    }
    if (isPlainNumber(a[1]))
      return makeDict({{"strength", Value(st[0])}, {"phase", Value(ph[0])}});
    return makeDict({{"strength", toValue(st)}, {"phase", toValue(ph)}});
  } SP_END
#define SG_OLA(NAME, SQUARED)                                                                      \
  SP_ADD(NAME, 3, 4, "window, nperseg, noverlap, tol=1e-10") {                                     \
    const size_t np = (size_t)optInt(a, 1, 0), no = (size_t)optInt(a, 2, 0);                       \
    if (np < 1 || no >= np) {                                                                      \
      ctx.fail("nperseg must be positive and noverlap below it");                                  \
      return Value(0.0);                                                                           \
    }                                                                                              \
    Vec w;                                                                                         \
    std::string err;                                                                               \
    if (!windowFromValue(a[0], np, false, w, err)) {                                               \
      ctx.fail(err);                                                                               \
      return Value(0.0);                                                                           \
    }                                                                                              \
    const double tol = isOmitted(a, 3) ? 1e-10 : optNum(a, 3, 1e-10);                              \
    const size_t step = np - no;                                                                   \
    Vec bins(step, 0.0);                                                                           \
    auto cell = [&](double v) { return SQUARED ? v * v : v; };                                     \
    for (size_t ii = 0; ii < np / step; ii++)                                                      \
      for (size_t i = 0; i < step; i++)                                                            \
        bins[i] += cell(w[ii * step + i]);                                                         \
    const size_t rest = np % step;                                                                 \
    for (size_t i = 0; i < rest; i++)                                                              \
      bins[i] += cell(w[np - rest + i]);                                                           \
    if (SQUARED)                                                                                   \
      return Value::boolean(*std::min_element(bins.begin(), bins.end()) > tol);                    \
    Vec sorted = bins;                                                                             \
    std::sort(sorted.begin(), sorted.end());                                                       \
    const size_t ns = sorted.size();                                                               \
    const double med = ns % 2 ? sorted[ns / 2] : 0.5 * (sorted[ns / 2 - 1] + sorted[ns / 2]);      \
    double dev = 0.0;                                                                              \
    for (double v : bins)                                                                          \
      dev = std::max(dev, std::fabs(v - med));                                                     \
    return Value::boolean(dev < tol);                                                              \
  } SP_END
  SG_OLA("check_cola", false)
  SG_OLA("check_nola", true)
  SP_ADD("czt", 1, 4, "data, m, w, a=1") {
    CVec x;
    if (!getCVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    const size_t m = (size_t)(isOmitted(a, 1) ? (long long)x.size() : optInt(a, 1, 0));
    if (m < 1) {
      ctx.fail("m must be 1 or more");
      return Value(0.0);
    }
    const cd w = isOmitted(a, 2) ? std::polar(1.0, -2.0 * kPi / (double)m) : complexArg(a, 2, cd(1.0));
    return toValue(cztCore(x, m, w, isOmitted(a, 3) ? cd(1.0) : complexArg(a, 3, cd(1.0))));
  } SP_ENDC
  SP_ADD("zoom_fft", 2, 4, "data, fn, fs=2  or  data, fn, m, fs") {
    CVec x;
    Vec fn;
    if (!getCVec(a, 0, ctx, x) || !getVec(a, 1, ctx, fn))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    double f1 = 0.0, f2;
    if (fn.size() == 1) {
      f2 = fn[0];
    } else if (fn.size() == 2) {
      f1 = fn[0];
      f2 = fn[1];
    } else {
      ctx.fail("fn must be [f1, f2] or just f2");
      return Value(0.0);
    }
    // With three inputs the third is fs; with four it is m, then fs.
    const double fs = a.size() == 3 ? optNum(a, 2, 2.0) : (isOmitted(a, 3) ? 2.0 : optNum(a, 3, 2.0));
    const size_t m = a.size() >= 4 && !isOmitted(a, 2) ? (size_t)optInt(a, 2, 0) : x.size();
    if (m < 1 || fs <= 0.0) {
      ctx.fail("m and fs must be positive");
      return Value(0.0);
    }
    const double scale = (f2 - f1) / fs;
    return toValue(cztCore(x, m, std::polar(1.0, -2.0 * kPi * scale / (double)m), std::polar(1.0, 2.0 * kPi * f1 / fs)));
  } SP_ENDC
  SP_ADD("czt_points", 1, 3, "m, w, a=1") {
    const long long m = optInt(a, 0, 0);
    if (m < 1) {
      ctx.fail("m must be 1 or more");
      return Value(0.0);
    }
    const cd ca = isOmitted(a, 2) ? cd(1.0) : complexArg(a, 2, cd(1.0));
    const bool hasW = !isOmitted(a, 1);
    const cd lw = hasW ? std::log(complexArg(a, 1, cd(1.0))) : cd(0.0);
    CVec z((size_t)m);
    for (long long k = 0; k < m; k++)
      z[(size_t)k] = hasW ? ca * std::exp(-lw * (double)k) : ca * std::polar(1.0, 2.0 * kPi * (double)k / (double)m);
    return toValue(z);
  } SP_ENDC
}

} // namespace scipy
} // namespace nc
