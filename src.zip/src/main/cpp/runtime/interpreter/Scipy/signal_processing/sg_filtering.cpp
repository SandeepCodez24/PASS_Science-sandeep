// Filtering and convolution: lfilter, sos filters, forward-backward filters,
// savgol, order filters, 2-D convolution, B-spline filters, resampling.
#include <numeric>

#include "../fourier_transforms/ft_core.h"
#include "../fourier_transforms/ft_shared.h"
#include "../linear_algebra/la_core.h"
#include "sg_core.h"
#include "signal_processing_main.h"

#define SP_SEC Section::SignalProcessing

namespace nc {
namespace scipy {
namespace sg {

Vec convolveDirect(const Vec &a, const Vec &b) {
  if (a.empty() || b.empty())
    return {};
  Vec o(a.size() + b.size() - 1, 0.0);
  for (size_t i = 0; i < a.size(); i++)
    for (size_t j = 0; j < b.size(); j++)
      o[i + j] += a[i] * b[j];
  return o;
}

Vec lfilter(const Vec &bIn, const Vec &aIn, const Vec &x, Vec *zi) {
  const double a0 = aIn[0];
  const size_t L = std::max(bIn.size(), aIn.size());
  Vec b(L, 0.0), a(L, 0.0);
  for (size_t i = 0; i < bIn.size(); i++)
    b[i] = bIn[i] / a0;
  for (size_t i = 0; i < aIn.size(); i++)
    a[i] = aIn[i] / a0;
  Vec z(L > 1 ? L - 1 : 0, 0.0);
  if (zi && zi->size() == z.size())
    z = *zi;
  Vec y(x.size());
  for (size_t n = 0; n < x.size(); n++) {
    const double out = b[0] * x[n] + (z.empty() ? 0.0 : z[0]);
    for (size_t i = 0; i + 1 < z.size(); i++)
      z[i] = b[i + 1] * x[n] + z[i + 1] - a[i + 1] * out;
    if (!z.empty())
      z.back() = b[L - 1] * x[n] - a[L - 1] * out;
    y[n] = out;
  }
  if (zi)
    *zi = z;
  return y;
}

Vec lfilterZi(Vec b, Vec a) {
  while (a.size() > 1 && a[0] == 0.0)
    a.erase(a.begin());
  const double a0 = a[0];
  for (double &v : b)
    v /= a0;
  for (double &v : a)
    v /= a0;
  const size_t n = std::max(a.size(), b.size());
  a.resize(n, 0.0);
  b.resize(n, 0.0);
  if (n <= 1)
    return {};
  Mat M(n - 1, n - 1);
  Vec B(n - 1);
  for (size_t i = 0; i + 1 < n; i++) {
    M(i, i) = 1.0;
    M(i, 0) += a[i + 1]; // minus the transposed companion matrix
    if (i + 1 < n - 1)
      M(i, i + 1) -= 1.0;
    B[i] = b[i + 1] - a[i + 1] * b[0];
  }
  la::solveVec(M, B);
  return B;
}

Vec sosfilt(const Mat &sos, const Vec &xIn, Mat *zi) {
  Vec x = xIn;
  for (size_t s = 0; s < sos.r; s++) {
    const double *c = sos.row(s);
    const double a0 = c[3], b0 = c[0] / a0, b1 = c[1] / a0, b2 = c[2] / a0, a1 = c[4] / a0, a2 = c[5] / a0;
    double z0 = zi ? (*zi)(s, 0) : 0.0, z1 = zi ? (*zi)(s, 1) : 0.0;
    for (size_t n = 0; n < x.size(); n++) {
      const double in = x[n], out = b0 * in + z0;
      z0 = b1 * in - a1 * out + z1;
      z1 = b2 * in - a2 * out;
      x[n] = out;
    }
    if (zi) {
      (*zi)(s, 0) = z0;
      (*zi)(s, 1) = z1;
    }
  }
  return x;
}

Mat sosfiltZi(const Mat &sos) {
  Mat zi(sos.r, 2);
  double scale = 1.0;
  for (size_t s = 0; s < sos.r; s++) {
    Vec b(sos.row(s), sos.row(s) + 3), a(sos.row(s) + 3, sos.row(s) + 6);
    Vec z = lfilterZi(b, a);
    zi(s, 0) = scale * z[0];
    zi(s, 1) = scale * z[1];
    scale *= (b[0] + b[1] + b[2]) / (a[0] + a[1] + a[2]);
  }
  return zi;
}

static bool oddExt(const Vec &x, size_t edge, Vec &ext, std::string &err) {
  if (x.size() <= edge) {
    err = "the data must be longer than " + std::to_string(edge) + " samples for this filter";
    return false;
  }
  ext.clear();
  ext.reserve(x.size() + 2 * edge);
  for (size_t i = edge; i >= 1; i--)
    ext.push_back(2.0 * x[0] - x[i]);
  ext.insert(ext.end(), x.begin(), x.end());
  for (size_t i = 1; i <= edge; i++)
    ext.push_back(2.0 * x.back() - x[x.size() - 1 - i]);
  return true;
}

bool filtfilt(const Vec &b, const Vec &a, const Vec &x, Vec &out, std::string &err) {
  const size_t ntaps = std::max(a.size(), b.size()), edge = ntaps * 3;
  Vec ext;
  if (!oddExt(x, edge, ext, err))
    return false;
  const Vec zi = lfilterZi(b, a);
  Vec z = zi;
  for (double &v : z)
    v *= ext[0];
  Vec y = lfilter(b, a, ext, &z);
  z = zi;
  for (double &v : z)
    v *= y.back();
  std::reverse(y.begin(), y.end());
  y = lfilter(b, a, y, &z);
  std::reverse(y.begin(), y.end());
  out.assign(y.begin() + (long)edge, y.end() - (long)edge);
  return true;
}

bool sosFiltfilt(const Mat &sos, const Vec &x, Vec &out, std::string &err) {
  size_t ntaps = 2 * sos.r + 1, zb = 0, za = 0;
  for (size_t s = 0; s < sos.r; s++) {
    zb += sos(s, 2) == 0.0;
    za += sos(s, 5) == 0.0;
  }
  ntaps -= std::min(zb, za);
  const size_t edge = ntaps * 3;
  Vec ext;
  if (!oddExt(x, edge, ext, err))
    return false;
  const Mat zi = sosfiltZi(sos);
  Mat z = zi;
  for (double &v : z.a)
    v *= ext[0];
  Vec y = sosfilt(sos, ext, &z);
  z = zi;
  for (double &v : z.a)
    v *= y.back();
  std::reverse(y.begin(), y.end());
  y = sosfilt(sos, y, &z);
  std::reverse(y.begin(), y.end());
  out.assign(y.begin() + (long)edge, y.end() - (long)edge);
  return true;
}

Vec upfirdn(const Vec &h, const Vec &x, size_t up, size_t down) {
  const size_t nOut = ((x.size() - 1) * up + h.size() - 1) / down + 1;
  Vec y(nOut, 0.0);
  for (size_t i = 0; i < nOut; i++) {
    const size_t pos = i * down;
    // x[k] sits at k * up; h covers pos - h.size() + 1 .. pos.
    size_t k = pos >= h.size() - 1 ? (pos - (h.size() - 1) + up - 1) / up : 0;
    for (; k < x.size() && k * up <= pos; k++)
      y[i] += x[k] * h[pos - k * up];
  }
  return y;
}

bool resamplePoly(const Vec &x, long upIn, long downIn, const Vec *taps, const Value *window, Vec &out, std::string &err) {
  if (upIn < 1 || downIn < 1) {
    err = "up and down must be whole numbers, 1 or more";
    return false;
  }
  if (x.empty()) {
    out.clear();
    return true;
  }
  const size_t nIn = x.size();
  size_t nOut = nIn * (size_t)upIn;
  nOut = nOut / (size_t)downIn + (nOut % (size_t)downIn ? 1 : 0);
  if (upIn == 1 && downIn == 1) {
    out = x;
    return true;
  }
  const long g = std::gcd(upIn, downIn);
  const size_t up = (size_t)(upIn / g), down = (size_t)(downIn / g);
  if (up == 1 && down == 1) {
    out = x;
    return true;
  }
  Vec h;
  size_t halfLen;
  if (taps) {
    h = *taps;
    halfLen = (h.size() - 1) / 2;
  } else {
    const size_t maxRate = std::max(up, down);
    halfLen = 10 * maxRate;
    Value dflt(std::vector<std::vector<Value>>{{Value(std::string("kaiser")), Value(5.0)}});
    if (!firwin((long)(2 * halfLen + 1), Vec{1.0 / (double)maxRate}, window ? window : &dflt, true, true, 2.0, h, err))
      return false;
  }
  for (double &v : h)
    v *= (double)up;
  const size_t pre = down - halfLen % down;
  size_t post = 0;
  const size_t removeFront = (halfLen + pre) / down;
  auto lenOut = [&](size_t lh) { return ((nIn - 1) * up + lh - 1) / down + 1; };
  while (lenOut(h.size() + pre + post) < nOut + removeFront)
    post++;
  Vec hp(pre, 0.0);
  hp.insert(hp.end(), h.begin(), h.end());
  hp.insert(hp.end(), post, 0.0);
  Vec y = upfirdn(hp, x, up, down);
  out.assign(y.begin() + (long)removeFront, y.begin() + (long)(removeFront + nOut));
  return true;
}

Vec detrendLine(const Vec &x, bool linear) {
  const size_t n = x.size();
  Vec o = x;
  if (!n)
    return o;
  double mx = 0.0;
  for (double v : x)
    mx += v;
  mx /= (double)n;
  if (!linear || n == 1) {
    for (double &v : o)
      v -= mx;
    return o;
  }
  const double mt = 0.5 * (double)(n - 1);
  double num = 0.0, den = 0.0;
  for (size_t i = 0; i < n; i++) {
    num += ((double)i - mt) * (x[i] - mx);
    den += ((double)i - mt) * ((double)i - mt);
  }
  const double s = num / den;
  for (size_t i = 0; i < n; i++)
    o[i] = x[i] - mx - s * ((double)i - mt);
  return o;
}

} // namespace sg

using namespace sg;

namespace {

long extIndex(long i, long n, int kind) { // 1 wrap, 2 symmetric, 0 fill
  if (i >= 0 && i < n)
    return i;
  if (kind == 1)
    return ((i % n) + n) % n;
  if (kind == 2) {
    const long p = 2 * n;
    long m = ((i % p) + p) % p;
    return m < n ? m : p - 1 - m;
  }
  return -1;
}

bool conv2Direct(const CMat &A, const CMat &B, const std::string &mode, const std::string &boundary, cd fill, CMat &out, std::string &err, bool flipped = false) {
  int kind;
  if (boundary == "fill" || boundary == "pad")
    kind = 0;
  else if (boundary == "wrap" || boundary == "circular")
    kind = 1;
  else if (boundary == "symm" || boundary == "symmetric")
    kind = 2;
  else {
    err = "boundary must be \"fill\", \"wrap\" or \"symm\"";
    return false;
  }
  if (A.a.empty() || B.a.empty()) {
    err = "the inputs must not be empty";
    return false;
  }
  size_t outR, outC, offR, offC;
  if (mode == "full") {
    outR = A.r + B.r - 1;
    outC = A.c + B.c - 1;
    offR = offC = 0;
  } else if (mode == "same") {
    outR = A.r;
    outC = A.c;
    // A flipped kernel (correlation) keeps its centre on the other side.
    offR = flipped ? B.r / 2 : (B.r - 1) / 2;
    offC = flipped ? B.c / 2 : (B.c - 1) / 2;
  } else if (mode == "valid") {
    if (A.r < B.r || A.c < B.c) {
      err = "in mode \"valid\" one input must be at least as large as the other in both directions";
      return false;
    }
    outR = A.r - B.r + 1;
    outC = A.c - B.c + 1;
    offR = B.r - 1;
    offC = B.c - 1;
  } else {
    err = "mode must be \"full\", \"same\" or \"valid\"";
    return false;
  }
  out = CMat(outR, outC);
  for (size_t i = 0; i < outR; i++)
    for (size_t j = 0; j < outC; j++) {
      cd s(0.0);
      for (size_t k = 0; k < B.r; k++)
        for (size_t l = 0; l < B.c; l++) {
          const long ii = extIndex((long)(i + offR) - (long)k, (long)A.r, kind), jj = extIndex((long)(j + offC) - (long)l, (long)A.c, kind);
          s += B(k, l) * (ii < 0 || jj < 0 ? fill : A((size_t)ii, (size_t)jj));
        }
      out(i, j) = s;
    }
  return true;
}

Value matResult(const CMat &m, bool realInput) {
  if (!realInput)
    return toValue(m);
  Mat o(m.r, m.c);
  for (size_t i = 0; i < m.a.size(); i++)
    o.a[i] = m.a[i].real();
  return toValue(o);
}

bool allReal(const CMat &m) {
  for (const cd &z : m.a)
    if (z.imag() != 0.0)
      return false;
  return true;
}

// sep_fir2d's boundary: symmetric, the end samples repeat.
Vec firMirror(const Vec &x, const Vec &h) {
  const long n = (long)x.size(), M = (long)h.size() / 2;
  Vec o((size_t)n, 0.0);
  for (long i = 0; i < n; i++)
    for (long j = 0; j < (long)h.size(); j++)
      o[(size_t)i] += h[(size_t)j] * x[(size_t)extIndex(i + M - j, n, 2)];
  return o;
}
Mat sepFir(const Mat &m, const Vec &hrow, const Vec &hcol) {
  Mat o = m;
  for (size_t i = 0; i < o.r; i++) {
    Vec r = firMirror(Vec(o.row(i), o.row(i) + o.c), hrow);
    std::copy(r.begin(), r.end(), o.row(i));
  }
  for (size_t j = 0; j < o.c; j++) {
    Vec c(o.r);
    for (size_t i = 0; i < o.r; i++)
      c[i] = o(i, j);
    c = firMirror(c, hcol);
    for (size_t i = 0; i < o.r; i++)
      o(i, j) = c[i];
  }
  return o;
}

// Mirror-symmetric first-order pair: scipy's symiirorder1.
Vec symIir1(const Vec &x, double c0, double z1) {
  const size_t n = x.size();
  Vec y(n);
  double s = 0.0, pw = 1.0;
  for (size_t k = 0; k < n; k++) {
    s += pw * x[k];
    pw *= z1;
  }
  y[0] = x[0] + z1 * s;
  for (size_t k = 1; k < n; k++)
    y[k] = x[k] + z1 * y[k - 1];
  Vec o(n);
  o[n - 1] = -c0 / (z1 - 1.0) * y[n - 1];
  for (size_t k = n - 1; k-- > 0;)
    o[k] = c0 * y[k] + z1 * o[k + 1];
  return o;
}
// Mirror-symmetric second-order pair: scipy's symiirorder2.
Vec symIir2(const Vec &x, double r, double omega, bool smoothCoeffForm = false) {
  const size_t n = x.size();
  const double cs = 1.0 - 2.0 * r * std::cos(omega) + r * r, a2 = 2.0 * r * std::cos(omega), a3 = -r * r;
  auto hc = [&](long k) { return k < 0 ? 0.0 : cs / std::sin(omega) * std::pow(r, (double)k) * std::sin(omega * (double)(k + 1)); };
  auto hs = [&](long k) {
    const double c0 = cs * cs * (1.0 + r * r) / (1.0 - r * r) / (1.0 - 2.0 * r * r * std::cos(2.0 * omega) + std::pow(r, 4.0));
    const double gamma = (1.0 - r * r) / (1.0 + r * r) / std::tan(omega);
    const double ak = std::fabs((double)k);
    return c0 * std::pow(r, ak) * (std::cos(omega * ak) + gamma * std::sin(omega * ak));
  };
  Vec y(n);
  // cspline1d's smoothing path starts its second value differently from symiirorder2.
  double y0 = hc(0) * x[0], y1 = smoothCoeffForm ? hc(0) * x[0] + (n > 1 ? hc(1) * x[1] : 0.0) : (n > 1 ? hc(0) * x[1] : 0.0) + hc(1) * x[0];
  for (size_t k = 0; k < n; k++) {
    y0 += hc((long)k + 1) * x[k];
    y1 += hc((long)k + 2) * x[k];
  }
  y[0] = y0;
  if (n > 1)
    y[1] = y1;
  for (size_t k = 2; k < n; k++)
    y[k] = cs * x[k] + a2 * y[k - 1] + a3 * y[k - 2];
  double e0 = 0.0, e1 = 0.0;
  for (size_t k = 0; k < n; k++) {
    const double v = x[n - 1 - k];
    e0 += (hs((long)k) + hs((long)k + 1)) * v;
    e1 += (hs((long)k - 1) + hs((long)k + 2)) * v;
  }
  Vec o(n);
  o[n - 1] = e0;
  if (n > 1)
    o[n - 2] = e1;
  for (size_t k = n >= 2 ? n - 2 : 0; k-- > 0;)
    o[k] = cs * y[k] + a2 * o[k + 1] + a3 * o[k + 2];
  return o;
}

void coeffSmooth(double lam, double &rho, double &omega) {
  const double xi = 1.0 - 96.0 * lam + 24.0 * lam * std::sqrt(3.0 + 144.0 * lam);
  omega = std::atan2(std::sqrt(144.0 * lam - 1.0), std::sqrt(xi));
  rho = (24.0 * lam - 1.0 - std::sqrt(xi)) / (24.0 * lam);
  rho *= std::sqrt((48.0 * lam + 24.0 * lam * std::sqrt(3.0 + 144.0 * lam)) / xi);
}

template <class F> Mat applyRowsCols(const Mat &m, F f) {
  Mat o = m;
  for (size_t i = 0; i < o.r; i++) {
    Vec r = f(Vec(o.row(i), o.row(i) + o.c));
    std::copy(r.begin(), r.end(), o.row(i));
  }
  for (size_t j = 0; j < o.c; j++) {
    Vec c(o.r);
    for (size_t i = 0; i < o.r; i++)
      c[i] = o(i, j);
    c = f(c);
    for (size_t i = 0; i < o.r; i++)
      o(i, j) = c[i];
  }
  return o;
}

Mat cspline2dCore(const Mat &m, double lam) {
  if (lam <= 1.0 / 144.0) {
    const double r = -2.0 + std::sqrt(3.0);
    return applyRowsCols(m, [&](const Vec &v) { return symIir1(v, -r * 6.0, r); });
  }
  const double tmp = std::sqrt(3.0 + 144.0 * lam), xi = 1.0 - 96.0 * lam + 24.0 * lam * tmp;
  const double omega = std::atan(std::sqrt((144.0 * lam - 1.0) / xi)), t2 = std::sqrt(xi);
  const double r = (24.0 * lam - 1.0 - t2) / (24.0 * lam) * std::sqrt(48.0 * lam + 24.0 * lam * tmp) / t2;
  return applyRowsCols(m, [&](const Vec &v) { return symIir2(v, r, omega); });
}

double cubicBasis(double x) {
  x = std::fabs(x);
  if (x < 1.0)
    return 2.0 / 3.0 - 0.5 * x * x * (2.0 - x);
  if (x < 2.0)
    return std::pow(2.0 - x, 3.0) / 6.0;
  return 0.0;
}
double quadraticBasis(double x) {
  x = std::fabs(x);
  if (x < 0.5)
    return 0.75 - x * x;
  if (x < 1.5)
    return 0.5 * (x - 1.5) * (x - 1.5);
  return 0.0;
}
double splineEval(const Vec &c, double x, bool cubic) {
  const long N = (long)c.size();
  if (!std::isfinite(x))
    return kNaN;
  // Mirror-symmetric extension: fold into [0, N - 1].
  if (N == 1)
    x = 0.0;
  else {
    const double period = 2.0 * (double)(N - 1);
    x = std::fmod(std::fabs(x), period);
    if (x > (double)(N - 1))
      x = period - x;
  }
  double s = 0.0;
  const long low = (long)std::floor(x - (cubic ? 2.0 : 1.5)) + 1;
  for (int i = 0; i < (cubic ? 4 : 3); i++) {
    const long j = low + i;
    const size_t idx = (size_t)std::min(N - 1, std::max(0L, j));
    s += c[idx] * (cubic ? cubicBasis(x - (double)j) : quadraticBasis(x - (double)j));
  }
  return s;
}

// Window sums with zeros outside the data.
Mat boxSum(const Mat &m, size_t kr, size_t kc) {
  Mat o(m.r, m.c);
  const long hr = (long)(kr - 1) / 2, hc = (long)(kc - 1) / 2;
  for (long i = 0; i < (long)m.r; i++)
    for (long j = 0; j < (long)m.c; j++) {
      double s = 0.0;
      for (long k = i - hr; k < i - hr + (long)kr; k++)
        for (long l = j - hc; l < j - hc + (long)kc; l++)
          if (k >= 0 && k < (long)m.r && l >= 0 && l < (long)m.c)
            s += m((size_t)k, (size_t)l);
      o((size_t)i, (size_t)j) = s;
    }
  return o;
}

// The rank-th value in the window, zeros outside the data.
Mat orderFilter(const Mat &m, const Mat &domain, size_t rank) {
  const long hr = (long)(domain.r - 1) / 2, hc = (long)(domain.c - 1) / 2;
  Mat o(m.r, m.c);
  Vec w;
  for (long i = 0; i < (long)m.r; i++)
    for (long j = 0; j < (long)m.c; j++) {
      w.clear();
      for (long k = 0; k < (long)domain.r; k++)
        for (long l = 0; l < (long)domain.c; l++) {
          if (domain((size_t)k, (size_t)l) == 0.0)
            continue;
          const long ii = i - hr + k, jj = j - hc + l;
          w.push_back(ii >= 0 && ii < (long)m.r && jj >= 0 && jj < (long)m.c ? m((size_t)ii, (size_t)jj) : 0.0);
        }
      std::nth_element(w.begin(), w.begin() + (long)rank, w.end());
      o((size_t)i, (size_t)j) = w[rank];
    }
  return o;
}

Value lineOrMatrix(const Mat &m, bool line) { return line ? toValue(m.a) : toValue(m); }

bool kernelSizes(const Args &a, size_t i, bool line, CallContext &ctx, size_t &kr, size_t &kc, long long def) {
  kr = line ? 1 : (size_t)def;
  kc = (size_t)def;
  if (i >= a.size() || isOmitted(a, i))
    return true;
  Vec s;
  if (!getVec(a, i, ctx, s))
    return false;
  if (s.size() == 1) {
    kc = (size_t)s[0];
    if (!line)
      kr = kc;
  } else if (s.size() == 2 && !line) {
    kr = (size_t)s[0];
    kc = (size_t)s[1];
  } else {
    ctx.fail("the size must be one number, or [rows, cols] for a matrix");
    return false;
  }
  if (kr % 2 == 0 || kc % 2 == 0) {
    ctx.fail("the window size must be odd");
    return false;
  }
  return true;
}

// Vandermonde-free Savitzky-Golay coefficients for the fit and the convolution.
bool savgolCoeffs(long window, long order, long deriv, double delta, Vec &c, std::string &err) {
  if (order >= window) {
    err = "polyorder must be less than the window length";
    return false;
  }
  const double pos = window % 2 ? (double)(window / 2) : (double)(window / 2) - 0.5;
  if (deriv > order) {
    c.assign((size_t)window, 0.0);
    return true;
  }
  Mat A((size_t)order + 1, (size_t)window);
  for (long j = 0; j < window; j++) {
    const double x = pos - (double)j;
    double p = 1.0;
    for (long i = 0; i <= order; i++) {
      A((size_t)i, (size_t)j) = p;
      p *= x;
    }
  }
  Vec y((size_t)order + 1, 0.0);
  y[(size_t)deriv] = std::tgamma((double)deriv + 1.0) / std::pow(delta, (double)deriv);
  c = la::lstsqMin(A, y);
  return true;
}

} // namespace

void registerSgFiltering(Registry &reg) {
  // ---- convolution ----
  SP_ADD("oa_convolve", 2, 3, "a, b, mode=\"full\"") {
    CMat A, B;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, B))
      return Value(0.0);
    const std::string mode = optText(a, 2, "full");
    if (mode != "full" && mode != "same" && mode != "valid") {
      ctx.fail("mode must be \"full\", \"same\" or \"valid\"");
      return Value(0.0);
    }
    if (A.a.empty() || B.a.empty()) {
      ctx.fail("the inputs must not be empty");
      return Value(0.0);
    }
    if (mode == "valid" && (A.r < B.r || A.c < B.c)) {
      if (A.r > B.r || A.c > B.c) {
        ctx.fail("in mode \"valid\" one input must be at least as large as the other in both directions");
        return Value(0.0);
      }
      std::swap(A, B);
    }
    const bool real = allReal(A) && allReal(B);
    const size_t fr = A.r + B.r - 1, fc = A.c + B.c - 1;
    size_t mr = 1, mc = 1;
    while (mr < fr)
      mr <<= 1;
    while (mc < fc)
      mc <<= 1;
    CMat FA(mr, mc), FB(mr, mc);
    for (size_t i = 0; i < A.r; i++)
      for (size_t j = 0; j < A.c; j++)
        FA(i, j) = A(i, j);
    for (size_t i = 0; i < B.r; i++)
      for (size_t j = 0; j < B.c; j++)
        FB(i, j) = B(i, j);
    ft::fft2(FA, false);
    ft::fft2(FB, false);
    for (size_t i = 0; i < FA.a.size(); i++)
      FA.a[i] *= FB.a[i];
    ft::fft2(FA, true);
    size_t oR = fr, oC = fc;
    if (mode == "same") {
      oR = A.r;
      oC = A.c;
    } else if (mode == "valid") {
      oR = A.r - B.r + 1;
      oC = A.c - B.c + 1;
    }
    const size_t sr = (fr - oR) / 2, sc = (fc - oC) / 2;
    CMat O(oR, oC);
    for (size_t i = 0; i < oR; i++)
      for (size_t j = 0; j < oC; j++)
        O(i, j) = FA(i + sr, j + sc);
    return matResult(O, real);
  } SP_ENDC
  SP_ADD("convolve2d", 2, 5, "a, b, mode=\"full\", boundary=\"fill\", fillvalue=0") {
    CMat A, B, O;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, B))
      return Value(0.0);
    const std::string mode = optText(a, 2, "full");
    const bool real = allReal(A) && allReal(B);
    if (mode == "valid" && A.r <= B.r && A.c <= B.c && (A.r < B.r || A.c < B.c))
      std::swap(A, B);
    std::string err;
    if (!conv2Direct(A, B, mode, optText(a, 3, "fill"), optNum(a, 4, 0.0), O, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return matResult(O, real);
  } SP_ENDC
  SP_ADD("correlate2d", 2, 5, "a, b, mode=\"full\", boundary=\"fill\", fillvalue=0") {
    CMat A, B, O;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, B))
      return Value(0.0);
    const std::string mode = optText(a, 2, "full");
    const bool real = allReal(A) && allReal(B);
    const bool swapped = mode == "valid" && A.a.size() < B.a.size();
    CMat Bf(B.r, B.c);
    std::string err;
    if (swapped) {
      CMat Bc(B.r, B.c);
      for (size_t i = 0; i < B.a.size(); i++)
        Bc.a[i] = std::conj(B.a[i]);
      CMat Ar(A.r, A.c);
      for (size_t i = 0; i < A.r; i++)
        for (size_t j = 0; j < A.c; j++)
          Ar(i, j) = A(A.r - 1 - i, A.c - 1 - j);
      if (!conv2Direct(Bc, Ar, mode, optText(a, 3, "fill"), optNum(a, 4, 0.0), O, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
      CMat Rev(O.r, O.c);
      for (size_t i = 0; i < O.r; i++)
        for (size_t j = 0; j < O.c; j++)
          Rev(i, j) = O(O.r - 1 - i, O.c - 1 - j);
      return matResult(Rev, real);
    }
    for (size_t i = 0; i < B.r; i++)
      for (size_t j = 0; j < B.c; j++)
        Bf(i, j) = std::conj(B(B.r - 1 - i, B.c - 1 - j));
    if (!conv2Direct(A, Bf, mode, optText(a, 3, "fill"), optNum(a, 4, 0.0), O, err, true)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return matResult(O, real);
  } SP_ENDC
  SP_ADD("sep_fir2d", 3, 3, "img, hrow, hcol") {
    Mat m;
    Vec hr, hc;
    if (!getMat(a, 0, ctx, m) || !getVec(a, 1, ctx, hr) || !getVec(a, 2, ctx, hc))
      return Value(0.0);
    if (hr.size() % 2 == 0 || hc.size() % 2 == 0) {
      ctx.fail("hrow and hcol must have an odd length");
      return Value(0.0);
    }
    return toValue(sepFir(m, hr, hc));
  } SP_END
  SP_ADD("conv_method", 2, 3, "a, b, mode=\"full\"") {
    CMat A, B;
    if (!getCMat(a, 0, ctx, A) || !getCMat(a, 1, ctx, B))
      return Value(0.0);
    const std::string mode = optText(a, 2, "full");
    const bool line = ft::isLine(a[0]) && ft::isLine(a[1]);
    double s1 = (double)A.a.size(), s2 = (double)B.a.size(), direct = 0.0;
    const double N = (double)(A.r + B.r - 1) * (double)(A.c + B.c - 1);
    double oSize = 0.0;
    if (mode == "full")
      oSize = N;
    else if (mode == "valid")
      oSize = (std::fabs((double)A.r - (double)B.r) + 1.0) * (std::fabs((double)A.c - (double)B.c) + 1.0);
    else if (mode == "same")
      oSize = s1;
    else {
      ctx.fail("mode must be \"full\", \"same\" or \"valid\"");
      return Value(0.0);
    }
    if (line) {
      const long long i1 = (long long)s1, i2 = (long long)s2;
      if (mode == "full")
        direct = s1 * s2;
      else if (mode == "valid")
        direct = i2 >= i1 ? (s2 - s1 + 1.0) * s1 : (s1 - s2 + 1.0) * s2;
      else
        direct = i1 < i2 ? s1 * s2 : s1 * s2 - (double)(i2 / 2 * ((i2 + 1) / 2));
    } else {
      direct = mode == "same" ? s1 * s2 : std::min(s1, s2) * oSize;
    }
    const double lineN = s1 + s2 - 1.0, fftOps = 3.0 * (line ? lineN : N) * std::log(line ? lineN : N);
    const double offset = line ? -0.001 : -0.0001;
    double oF, oD, oO = offset;
    if (line) {
      if (mode == "valid") {
        oF = 1.89095737e-09;
        oD = 2.1364985e-10;
      } else if (mode == "full") {
        oF = 1.764907e-09;
        oD = 2.1414831e-10;
      } else if (s2 <= s1) {
        oF = 3.2646654e-09;
        oD = 2.8478277e-10;
      } else {
        oF = 3.21635404e-09;
        oD = 1.1773253e-08;
        oO = -1e-05;
      }
    } else if (mode == "valid") {
      oF = 1.85927e-09;
      oD = 2.11242e-08;
    } else if (mode == "full") {
      oF = 1.99817e-09;
      oD = 1.66174e-08;
    } else {
      oF = 2.04735e-09;
      oD = 1.55367e-08;
    }
    return Value(std::string(oF * fftOps < oD * direct + oO ? "fft" : "direct"));
  } SP_ENDC
  SP_ADD("correlation_lags", 2, 3, "n1, n2, mode=\"full\"") {
    const long long n1 = optInt(a, 0, 0), n2 = optInt(a, 1, 0);
    const std::string mode = optText(a, 2, "full");
    IVec lags;
    if (mode == "full" || mode == "same") {
      for (long long v = -n2 + 1; v < n1; v++)
        lags.push_back(v);
      if (mode == "same") {
        const long long mid = (long long)lags.size() / 2, bd = n1 / 2;
        lags = IVec(lags.begin() + (long)(mid - bd), lags.begin() + (long)(mid + bd + (n1 % 2 ? 1 : 0)));
      }
    } else if (mode == "valid") {
      const long long bd = n1 - n2;
      if (bd >= 0)
        for (long long v = 0; v <= bd; v++)
          lags.push_back(v);
      else
        for (long long v = bd; v <= 0; v++)
          lags.push_back(v);
    } else {
      ctx.fail("mode must be \"full\", \"same\" or \"valid\"");
      return Value(0.0);
    }
    return toValue(lags);
  } SP_END
  // ---- B-spline filters ----
  SP_ADD("cspline1d", 1, 2, "data, lambda=0") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    const double lam = optNum(a, 1, 0.0);
    if (lam != 0.0) {
      double rho, om;
      coeffSmooth(lam, rho, om);
      return toValue(symIir2(x, rho, om, true));
    }
    const double r = -2.0 + std::sqrt(3.0);
    return toValue(symIir1(x, -r * 6.0, r));
  } SP_END
  SP_ADD("qspline1d", 1, 2, "data, lambda=0") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    if (x.empty()) {
      ctx.fail("the data must not be empty");
      return Value(0.0);
    }
    if (optNum(a, 1, 0.0) != 0.0) {
      ctx.fail("smoothing quadratic splines is not supported (as in scipy)");
      return Value(0.0);
    }
    const double r = -3.0 + 2.0 * std::sqrt(2.0);
    return toValue(symIir1(x, -r * 8.0, r));
  } SP_END
  SP_ADD("cspline2d", 1, 2, "data, lambda=0") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    return toValue(cspline2dCore(m, optNum(a, 1, 0.0)));
  } SP_END
  SP_ADD("qspline2d", 1, 2, "data, lambda=0") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    if (optNum(a, 1, 0.0) > 0.0) {
      ctx.fail("lambda must be negative or zero");
      return Value(0.0);
    }
    const double r = -3.0 + 2.0 * std::sqrt(2.0);
    return toValue(applyRowsCols(m, [&](const Vec &v) { return symIir1(v, -r * 8.0, r); }));
  } SP_END
#define SG_SPLINE_EVAL(NAME, CUBIC)                                                                \
  SP_ADD(NAME, 2, 4, "coeffs, xq, dx=1, x0=0") {                                                   \
    Vec c, q;                                                                                      \
    if (!getVec(a, 0, ctx, c) || !getVec(a, 1, ctx, q))                                            \
      return Value(0.0);                                                                           \
    if (c.empty()) {                                                                               \
      ctx.fail("the coefficients must not be empty");                                              \
      return Value(0.0);                                                                           \
    }                                                                                              \
    const double dx = isOmitted(a, 2) ? 1.0 : optNum(a, 2, 1.0), x0 = optNum(a, 3, 0.0);           \
    for (double &v : q)                                                                            \
      v = splineEval(c, (v - x0) / dx, CUBIC);                                                     \
    return toValue(q);                                                                             \
  } SP_END
  SG_SPLINE_EVAL("cspline1d_eval", true)
  SG_SPLINE_EVAL("qspline1d_eval", false)
  SP_ADD("spline_smooth2d", 1, 2, "data, lambda=5") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    const Vec h{1.0 / 6.0, 4.0 / 6.0, 1.0 / 6.0};
    return toValue(sepFir(cspline2dCore(m, optNum(a, 1, 5.0)), h, h));
  } SP_END
  SP_ADD("gauss_spline", 2, 2, "x, n") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const double s = (optNum(a, 1, 0.0) + 1.0) / 12.0;
    for (double &v : x)
      v = 1.0 / std::sqrt(2.0 * kPi * s) * std::exp(-v * v / 2.0 / s);
    return toValue(x);
  } SP_END
  SP_ADD("sym_iir1", 3, 3, "data, c0, z1") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const double z1 = optNum(a, 2, 0.0);
    if (std::fabs(z1) >= 1.0 || x.empty()) {
      ctx.fail("z1 must be below 1 in size, and the data must not be empty");
      return Value(0.0);
    }
    return toValue(symIir1(x, optNum(a, 1, 0.0), z1));
  } SP_END
  SP_ADD("sym_iir2", 3, 3, "data, r, omega") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const double r = optNum(a, 1, 0.0);
    if (r >= 1.0 || x.empty()) {
      ctx.fail("r must be below 1, and the data must not be empty");
      return Value(0.0);
    }
    return toValue(symIir2(x, r, optNum(a, 2, 0.0)));
  } SP_END
  // ---- order filters ----
  SP_ADD("order_filter", 3, 3, "data, domain, rank") {
    Mat m, dom;
    if (!getMat(a, 0, ctx, m) || !getMat(a, 1, ctx, dom))
      return Value(0.0);
    if (dom.r % 2 == 0 || dom.c % 2 == 0) {
      ctx.fail("the domain must have an odd size in each direction");
      return Value(0.0);
    }
    size_t count = 0;
    for (double v : dom.a)
      count += v != 0.0;
    const long long rank = optInt(a, 2, 0);
    if (rank < 0 || (size_t)rank >= count) {
      ctx.fail("rank must be below the number of nonzero values in the domain");
      return Value(0.0);
    }
    return lineOrMatrix(orderFilter(m, dom, (size_t)rank), ft::isLine(a[0]));
  } SP_END
  SP_ADD("medfilt", 1, 2, "data, size=3") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    const bool line = ft::isLine(a[0]);
    if (line && m.c == 1 && m.r > 1)
      m = transposeOf(m);
    size_t kr, kc;
    if (!kernelSizes(a, 1, line, ctx, kr, kc, 3))
      return Value(0.0);
    return lineOrMatrix(orderFilter(m, Mat(kr, kc, 1.0), kr * kc / 2), line);
  } SP_END
  SP_ADD("medfilt2d", 1, 2, "img, size=3") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    size_t kr, kc;
    if (!kernelSizes(a, 1, false, ctx, kr, kc, 3))
      return Value(0.0);
    return toValue(orderFilter(m, Mat(kr, kc, 1.0), kr * kc / 2));
  } SP_END
  SP_ADD("wiener", 1, 3, "data, size=3, noise") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    const bool line = ft::isLine(a[0]);
    if (line && m.c == 1 && m.r > 1)
      m = transposeOf(m);
    size_t kr, kc;
    if (!kernelSizes(a, 1, line, ctx, kr, kc, 3))
      return Value(0.0);
    const double area = (double)(kr * kc);
    Mat mean = boxSum(m, kr, kc), sq = m;
    for (double &v : sq.a)
      v *= v;
    Mat var = boxSum(sq, kr, kc);
    double noise = 0.0;
    for (size_t i = 0; i < mean.a.size(); i++) {
      mean.a[i] /= area;
      var.a[i] = var.a[i] / area - mean.a[i] * mean.a[i];
      noise += var.a[i];
    }
    noise = isOmitted(a, 2) ? noise / (double)var.a.size() : optNum(a, 2, 0.0);
    Mat o(m.r, m.c);
    for (size_t i = 0; i < o.a.size(); i++)
      o.a[i] = var.a[i] < noise ? mean.a[i] : (m.a[i] - mean.a[i]) * (1.0 - noise / var.a[i]) + mean.a[i];
    return lineOrMatrix(o, line);
  } SP_END
  // ---- IIR and FIR filtering ----
  SP_ADD("lfilter", 3, 4, "b, a, data, zi") {
    Vec b, ca, x, zi;
    if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca) || !getVec(a, 2, ctx, x))
      return Value(0.0);
    if (ca.empty() || ca[0] == 0.0 || b.empty()) {
      ctx.fail("a[0] must not be 0, and b must not be empty");
      return Value(0.0);
    }
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (!getVec(a, 3, ctx, zi))
        return Value(0.0);
      if (zi.size() != std::max(b.size(), ca.size()) - 1) {
        ctx.fail("zi must have max(len(a), len(b)) - 1 values");
        return Value(0.0);
      }
      Vec y = lfilter(b, ca, x, &zi);
      return makeDict({{"y", toValue(y)}, {"zf", toValue(zi)}});
    }
    return toValue(lfilter(b, ca, x));
  } SP_END
  SP_ADD("lfiltic", 3, 4, "b, a, y, x") {
    Vec b, ca, y, x;
    if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca) || !getVec(a, 2, ctx, y))
      return Value(0.0);
    if (a.size() > 3 && !isOmitted(a, 3) && !getVec(a, 3, ctx, x))
      return Value(0.0);
    const size_t N = ca.size() - 1, M = b.size() - 1, K = std::max(M, N);
    x.resize(std::max(x.size(), M), 0.0);
    y.resize(std::max(y.size(), N), 0.0);
    Vec zi(K, 0.0);
    for (size_t m = 0; m < M; m++)
      for (size_t i = 0; i < M - m; i++)
        zi[m] += b[m + 1 + i] * x[i];
    for (size_t m = 0; m < N; m++)
      for (size_t i = 0; i < N - m; i++)
        zi[m] -= ca[m + 1 + i] * y[i];
    if (ca[0] != 1.0)
      for (double &v : zi)
        v /= ca[0];
    return toValue(zi);
  } SP_END
  SP_ADD("lfilter_zi", 2, 2, "b, a") {
    Vec b, ca;
    if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca))
      return Value(0.0);
    return toValue(lfilterZi(b, ca));
  } SP_END
  SP_ADD("filtfilt", 3, 3, "b, a, data") {
    Vec b, ca, x, o;
    if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca) || !getVec(a, 2, ctx, x))
      return Value(0.0);
    std::string err;
    if (!filtfilt(b, ca, x, o, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(o);
  } SP_END
  SP_ADD("savgol_coeffs", 2, 4, "window, polyorder, deriv=0, delta=1") {
    Vec c;
    std::string err;
    if (!savgolCoeffs((long)optInt(a, 0, 0), (long)optInt(a, 1, 0), (long)optInt(a, 2, 0), isOmitted(a, 3) ? 1.0 : optNum(a, 3, 1.0), c, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(c);
  } SP_END
  SP_ADD("savgol_filter", 3, 5, "data, window, polyorder, deriv=0, delta=1") {
    Vec x, c;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const long window = (long)optInt(a, 1, 0), order = (long)optInt(a, 2, 0), deriv = (long)optInt(a, 3, 0);
    const double delta = isOmitted(a, 4) ? 1.0 : optNum(a, 4, 1.0);
    if (window % 2 == 0 || window < 1) {
      ctx.fail("the window must be odd");
      return Value(0.0);
    }
    if ((size_t)window > x.size()) {
      ctx.fail("the window must not be longer than the data");
      return Value(0.0);
    }
    std::string err;
    if (!savgolCoeffs(window, order, deriv, delta, c, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const long n = (long)x.size(), half = window / 2;
    Vec y((size_t)n, 0.0);
    for (long i = half; i < n - half; i++)
      for (long j = 0; j < window; j++)
        y[(size_t)i] += c[(size_t)j] * x[(size_t)(i + half - j)];
    // The ends come from a polynomial fit to the first and the last window.
    auto edge = [&](long start, long from, long to) {
      Mat V((size_t)window, (size_t)order + 1);
      Vec seg((size_t)window);
      for (long i = 0; i < window; i++) {
        seg[(size_t)i] = x[(size_t)(start + i)];
        double p = 1.0;
        for (long k = order; k >= 0; k--) {
          V((size_t)i, (size_t)k) = p;
          p *= (double)i;
        }
      }
      Vec pc = la::lstsqMin(V, seg);
      for (long d = 0; d < deriv; d++) {
        Vec dp;
        for (size_t k = 0; k + 1 < pc.size(); k++)
          dp.push_back(pc[k] * (double)(pc.size() - 1 - k));
        pc = dp.empty() ? Vec{0.0} : dp;
      }
      for (long i = from; i < to; i++)
        y[(size_t)i] = polyvalReal(pc, (double)(i - start)) / std::pow(delta, (double)deriv);
    };
    edge(0, 0, half);
    edge(n - window, n - half, n);
    return toValue(y);
  } SP_END
  SP_ADD("deconvolve", 2, 2, "signal, divisor") {
    Vec num, den;
    if (!getVec(a, 0, ctx, num) || !getVec(a, 1, ctx, den))
      return Value(0.0);
    if (den.empty() || den[0] == 0.0) {
      ctx.fail("the first value of the divisor must not be 0");
      return Value(0.0);
    }
    Vec quot, rem = num;
    if (den.size() <= num.size()) {
      Vec input(num.size() - den.size() + 1, 0.0);
      input[0] = 1.0;
      quot = lfilter(num, den, input);
      Vec c = convolveDirect(den, quot);
      for (size_t i = 0; i < rem.size(); i++)
        rem[i] -= c[i];
    }
    return makeDict({{"quotient", toValue(quot)}, {"remainder", toValue(rem)}});
  } SP_END
#define SG_SOS_ARG(I)                                                                              \
  Mat sos;                                                                                         \
  if (!getMat(a, I, ctx, sos))                                                                     \
    return Value(0.0);                                                                             \
  if (sos.c != 6) {                                                                                \
    ctx.fail("sos must have six columns");                                                         \
    return Value(0.0);                                                                             \
  }
  SP_ADD("sos_filter", 2, 3, "sos, data, zi") {
    SG_SOS_ARG(0)
    Vec x;
    if (!getVec(a, 1, ctx, x))
      return Value(0.0);
    if (a.size() > 2 && !isOmitted(a, 2)) {
      Mat zi;
      if (!getMat(a, 2, ctx, zi))
        return Value(0.0);
      if (zi.r != sos.r || zi.c != 2) {
        ctx.fail("zi must have one row of two values per section");
        return Value(0.0);
      }
      Vec y = sosfilt(sos, x, &zi);
      return makeDict({{"y", toValue(y)}, {"zf", toValue(zi)}});
    }
    return toValue(sosfilt(sos, x));
  } SP_END
  SP_ADD("sos_filter_zi", 1, 1, "sos") {
    SG_SOS_ARG(0)
    return toValue(sosfiltZi(sos));
  } SP_END
  SP_ADD("sos_filtfilt", 2, 2, "sos, data") {
    SG_SOS_ARG(0)
    Vec x, o;
    if (!getVec(a, 1, ctx, x))
      return Value(0.0);
    std::string err;
    if (!sosFiltfilt(sos, x, o, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(o);
  } SP_END
  // ---- analytic signals ----
  SP_ADD("hilbert2", 1, 1, "data") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    CMat F = toComplex(m);
    ft::fft2(F, false);
    const size_t k0 = (F.r + 1) / 2, k1 = (F.c + 1) / 2;
    for (size_t i = 0; i < F.r; i++)
      for (size_t j = 0; j < F.c; j++) {
        const double fi = i == 0 ? 1.0 : (i < k0 ? 2.0 : 0.0), fj = j == 0 ? 1.0 : (j < k1 ? 2.0 : 0.0);
        F(i, j) *= fi * fj;
      }
    ft::fft2(F, true);
    return toValue(F);
  } SP_END
  SP_ADD("envelope", 1, 2, "data, bp_in") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const long n = (long)x.size();
    long lo = 1, hi = (n + 1) / 2;
    if (a.size() > 1 && !isOmitted(a, 1)) {
      Vec bp;
      if (!getVec(a, 1, ctx, bp) || bp.size() != 2) {
        ctx.fail("bp_in must be [first bin, end bin]");
        return Value(0.0);
      }
      lo = (long)bp[0];
      hi = (long)bp[1];
      if (lo < 0 || lo >= hi || hi > (n + 1) / 2) {
        ctx.fail("for real data bp_in must satisfy 0 <= first < end <= (n + 1) / 2");
        return Value(0.0);
      }
    }
    CVec F = ft::fftOf(toComplex(x)), G((size_t)n, cd(0.0));
    for (long i = lo; i < hi; i++)
      G[(size_t)i] = F[(size_t)i] * (i == 0 ? 1.0 : 2.0);
    ft::fft(G, true);
    Vec e((size_t)n);
    for (long i = 0; i < n; i++)
      e[(size_t)i] = std::abs(G[(size_t)i]);
    return toValue(e);
  } SP_END
  // ---- rate changes and clean-ups ----
  SP_ADD("detrend", 1, 2, "data, type=\"linear\"") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    const std::string t = optText(a, 1, "linear");
    if (t != "linear" && t != "constant" && t != "l" && t != "c") {
      ctx.fail("type must be \"linear\" or \"constant\"");
      return Value(0.0);
    }
    const bool lin = t[0] == 'l', line = ft::isLine(a[0]);
    if (line && m.c == 1 && m.r > 1)
      m = transposeOf(m);
    for (size_t i = 0; i < m.r; i++) {
      Vec r = detrendLine(Vec(m.row(i), m.row(i) + m.c), lin);
      std::copy(r.begin(), r.end(), m.row(i));
    }
    return lineOrMatrix(m, line);
  } SP_END
  SP_ADD("resample", 2, 2, "data, num") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const long long numIn = optInt(a, 1, 0);
    if (numIn < 1 || x.empty()) {
      ctx.fail("num must be 1 or more, and the data must not be empty");
      return Value(0.0);
    }
    const size_t num = (size_t)numIn, Nx = x.size(), N = std::min(num, Nx), nyq = N / 2 + 1;
    CVec X = ft::fftOf(toComplex(x)), Y(num / 2 + 1, cd(0.0));
    for (size_t i = 0; i < nyq && i < Y.size(); i++)
      Y[i] = X[i];
    if (N % 2 == 0) {
      if (num < Nx)
        Y[N / 2] *= 2.0;
      else if (Nx < num)
        Y[N / 2] *= 0.5;
    }
    Vec y = ft::irfftLine(Y, num);
    for (double &v : y)
      v *= (double)num / (double)Nx;
    return toValue(y);
  } SP_END
  SP_ADD("resample_poly", 3, 4, "data, up, down, window") {
    Vec x, o, taps;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const Value *win = nullptr;
    const Vec *tp = nullptr;
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (isWindowSamples(a[3])) {
        if (!getVec(a, 3, ctx, taps))
          return Value(0.0);
        tp = &taps;
      } else {
        win = &a[3];
      }
    }
    std::string err;
    if (!resamplePoly(x, (long)optInt(a, 1, 0), (long)optInt(a, 2, 0), tp, win, o, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(o);
  } SP_END
  SP_ADD("upfirdn", 2, 4, "h, data, up=1, down=1") {
    Vec h, x;
    if (!getVec(a, 0, ctx, h) || !getVec(a, 1, ctx, x))
      return Value(0.0);
    const long long up = isOmitted(a, 2) ? 1 : optInt(a, 2, 1), down = isOmitted(a, 3) ? 1 : optInt(a, 3, 1);
    if (up < 1 || down < 1 || h.empty() || x.empty()) {
      ctx.fail("up and down must be 1 or more, and h and the data must not be empty");
      return Value(0.0);
    }
    return toValue(upfirdn(h, x, (size_t)up, (size_t)down));
  } SP_END
  SP_ADD("decimate", 2, 4, "data, q, ftype=\"iir\", n") {
    Vec x, y;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const long long q = optInt(a, 1, 0);
    if (q < 1) {
      ctx.fail("q must be a whole number, 1 or more");
      return Value(0.0);
    }
    const std::string ftype = optText(a, 2, "iir");
    std::string err;
    if (ftype == "fir") {
      const long nn = isOmitted(a, 3) ? 20 * (long)q : (long)optInt(a, 3, 0);
      Vec h;
      if (!firwin(nn + 1, Vec{1.0 / (double)q}, nullptr, true, true, 2.0, h, err) || !resamplePoly(x, 1, (long)q, &h, nullptr, y, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
      return toValue(y);
    }
    if (ftype != "iir") {
      ctx.fail("ftype must be \"iir\" or \"fir\"");
      return Value(0.0);
    }
    const int nn = isOmitted(a, 3) ? 8 : (int)optInt(a, 3, 8);
    Zpk f;
    Mat sos;
    if (!iirDesign(nn, Vec{0.8 / (double)q}, "lowpass", "cheby1", 0.05, 0.0, "", 0.0, f, err) || !zpk2sos(f, sos, err) || !sosFiltfilt(sos, x, y, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Vec o;
    for (size_t i = 0; i < y.size(); i += (size_t)q)
      o.push_back(y[i]);
    return toValue(o);
  } SP_END
  SP_ADD("whittaker_smooth", 2, 4, "data, lamb, order=2, weights") {
    // Solves (W + lamb D'D) z = W y with D the differences of the given order.
    Vec y, w;
    if (!getVec(a, 0, ctx, y))
      return Value(0.0);
    const double lamb = optNum(a, 1, 0.0);
    const size_t order = (size_t)(isOmitted(a, 2) ? 2 : optInt(a, 2, 2));
    const size_t n = y.size();
    if (lamb < 0.0) {
      ctx.fail("lamb must not be negative");
      return Value(0.0);
    }
    if (n <= order) {
      ctx.fail("the data must be longer than the order");
      return Value(0.0);
    }
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (!getVec(a, 3, ctx, w))
        return Value(0.0);
      if (w.size() != n) {
        ctx.fail("weights must have the length of the data");
        return Value(0.0);
      }
    } else {
      w.assign(n, 1.0);
    }
    Vec d{1.0};
    for (size_t i = 0; i < order; i++)
      d = polyMul(d, Vec{1.0, -1.0});
    // Banded Cholesky, band = order.
    Mat B(n, order + 1);
    for (size_t i = 0; i < n; i++)
      B(i, 0) = w[i];
    for (size_t row = 0; row + order < n; row++)
      for (size_t p = 0; p <= order; p++)
        for (size_t q = p; q <= order; q++)
          B(row + p, q - p) += lamb * d[p] * d[q];
    for (size_t j = 0; j < n; j++) {
      double s = B(j, 0);
      for (size_t k = j > order ? j - order : 0; k < j; k++)
        s -= B(k, j - k) * B(k, j - k) * B(k, 0);
      B(j, 0) = s;
      for (size_t i = 1; i <= order && i + j < n; i++) {
        double t = B(j, i);
        for (size_t k = j + i > order ? j + i - order : 0; k < j; k++)
          t -= B(k, j - k) * B(k, j + i - k) * B(k, 0);
        B(j, i) = t / B(j, 0);
      }
    }
    Vec z(n);
    for (size_t i = 0; i < n; i++)
      z[i] = w[i] * y[i];
    for (size_t i = 0; i < n; i++)
      for (size_t k = i > order ? i - order : 0; k < i; k++)
        z[i] -= B(k, i - k) * z[k];
    for (size_t i = 0; i < n; i++)
      z[i] /= B(i, 0);
    for (size_t i = n; i-- > 0;)
      for (size_t k = 1; k <= order && i + k < n; k++)
        z[i] -= B(i, k) * z[i + k];
    return toValue(z);
  } SP_END
}

} // namespace scipy
} // namespace nc
