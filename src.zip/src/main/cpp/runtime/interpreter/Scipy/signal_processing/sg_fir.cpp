// FIR design: windowed sinc, frequency sampling, least squares, Parks-McClellan,
// minimum phase, and the Kaiser formulas.
#include "../fourier_transforms/ft_core.h"
#include "../fourier_transforms/ft_shared.h"
#include "../linear_algebra/la_core.h"
#include "sg_core.h"
#include "signal_processing_main.h"

#define SP_SEC Section::SignalProcessing

namespace nc {
namespace scipy {
namespace sg {

static double sincPi(double x) { return x == 0.0 ? 1.0 : std::sin(kPi * x) / (kPi * x); }

bool firwin(long numtaps, const Vec &cutoffIn, const Value *window, bool passZero, bool scale, double fs, Vec &h, std::string &err) {
  if (numtaps < 1) {
    err = "numtaps must be at least 1";
    return false;
  }
  const double nyq = 0.5 * fs;
  Vec cut = cutoffIn;
  for (double &v : cut)
    v /= nyq;
  for (size_t i = 0; i < cut.size(); i++)
    if (cut[i] <= 0.0 || cut[i] >= 1.0 || (i && cut[i] <= cut[i - 1])) {
      err = "the cutoffs must increase and lie strictly between 0 and fs/2";
      return false;
    }
  if (cut.empty()) {
    err = "at least one cutoff is needed";
    return false;
  }
  const bool passNyq = ((cut.size() & 1) != 0) != passZero;
  if (passNyq && numtaps % 2 == 0) {
    err = "a filter with non-zero gain at Nyquist needs an odd numtaps";
    return false;
  }
  Vec edges;
  if (passZero)
    edges.push_back(0.0);
  edges.insert(edges.end(), cut.begin(), cut.end());
  if (passNyq)
    edges.push_back(1.0);
  const double alpha = 0.5 * (double)(numtaps - 1);
  h.assign((size_t)numtaps, 0.0);
  for (size_t b = 0; b + 1 < edges.size(); b += 2)
    for (long i = 0; i < numtaps; i++) {
      const double m = (double)i - alpha;
      h[(size_t)i] += edges[b + 1] * sincPi(edges[b + 1] * m) - edges[b] * sincPi(edges[b] * m);
    }
  Vec win;
  if (window) {
    if (!windowFromValue(*window, (size_t)numtaps, true, win, err))
      return false;
  } else if (!windowByName("hamming", {}, (size_t)numtaps, true, win, err)) {
    return false;
  }
  for (long i = 0; i < numtaps; i++)
    h[(size_t)i] *= win[(size_t)i];
  if (scale) {
    const double left = edges[0], right = edges[1];
    const double sf = left == 0.0 ? 0.0 : (right == 1.0 ? 1.0 : 0.5 * (left + right));
    double s = 0.0;
    for (long i = 0; i < numtaps; i++)
      s += h[(size_t)i] * std::cos(kPi * ((double)i - alpha) * sf);
    for (double &v : h)
      v /= s;
  }
  return true;
}

} // namespace sg

using namespace sg;

namespace {

// Parks-McClellan on Type I and II filters; bands and frequencies in cycles per sample.
bool remezExchange(long numtaps, const Vec &bands, const Vec &des, const Vec &wt, long maxiter, long density, const std::string &type, Vec &h, std::string &err) {
  const bool odd = numtaps % 2 == 1;
  const size_t r = (size_t)(numtaps / 2 + (odd ? 1 : 0)) + 1; // extrema = functions + 1
  std::vector<double> grid, D, W;
  const double delf = 0.5 / (double)(density * (long)(r - 1));
  const size_t nb = bands.size() / 2;
  for (size_t b = 0; b < nb; b++) {
    const double lo = b == 0 && bands[0] == 0.0 ? 0.0 : bands[2 * b], hi = bands[2 * b + 1];
    const long pts = std::max(1L, (long)std::llround((hi - lo) / delf));
    for (long i = 0; i <= pts; i++) {
      double f = lo + (hi - lo) * (double)i / (double)pts;
      if (!odd && f > 0.5 - 1e-12)
        continue; // cos(pi f) vanishes here
      double gain = des[b];
      if (type == "differentiator")
        gain = des[b] * f;
      grid.push_back(f);
      D.push_back(gain);
      W.push_back(type == "differentiator" && f > 0.0 ? wt[b] / f : wt[b]);
    }
  }
  if (grid.size() < r) {
    err = "the bands leave too few frequency points for this numtaps";
    return false;
  }
  // Type II: A(f) = cos(pi f) P(f).
  Vec Dp = D, Wp = W;
  if (!odd)
    for (size_t i = 0; i < grid.size(); i++) {
      const double c = std::cos(kPi * grid[i]);
      Dp[i] = D[i] / c;
      Wp[i] = W[i] * c;
    }
  const size_t ng = grid.size();
  std::vector<size_t> ext(r);
  for (size_t i = 0; i < r; i++)
    ext[i] = i * (ng - 1) / (r - 1);
  Vec X(ng);
  for (size_t i = 0; i < ng; i++)
    X[i] = std::cos(2.0 * kPi * grid[i]);
  Vec bary(r), yExt(r);
  double delta = 0.0;
  // Barycentric evaluation through the r-1 first points, with the weights of all.
  auto evalAt = [&](double x) {
    double num = 0.0, den = 0.0;
    for (size_t k = 0; k + 1 < r; k++) {
      const double d = x - X[ext[k]];
      if (std::fabs(d) < 1e-14)
        return yExt[k];
      const double t = bary[k] / d;
      num += t * yExt[k];
      den += t;
    }
    return num / den;
  };
  auto setup = [&]() {
    for (size_t k = 0; k + 1 < r; k++) {
      double b = 1.0;
      const double xk = X[ext[k]];
      for (size_t j = 0; j + 1 < r; j++)
        if (j != k)
          b *= 2.0 * (xk - X[ext[j]]);
      bary[k] = 1.0 / b;
    }
    // delta from the full set of r points.
    double num = 0.0, den = 0.0, sgn = 1.0;
    for (size_t k = 0; k < r; k++) {
      double b = 1.0;
      const double xk = X[ext[k]];
      for (size_t j = 0; j < r; j++)
        if (j != k)
          b *= 2.0 * (xk - X[ext[j]]);
      num += Dp[ext[k]] / b;
      den += sgn / (b * Wp[ext[k]]);
      sgn = -sgn;
    }
    delta = num / den;
    sgn = 1.0;
    for (size_t k = 0; k < r; k++) {
      yExt[k] = Dp[ext[k]] - sgn * delta / Wp[ext[k]];
      sgn = -sgn;
    }
  };
  for (long it = 0; it < maxiter; it++) {
    setup();
    Vec E(ng);
    for (size_t i = 0; i < ng; i++)
      E[i] = Wp[i] * (Dp[i] - evalAt(X[i]));
    // Local extrema of the error, ends included.
    std::vector<size_t> cand;
    for (size_t i = 0; i < ng; i++) {
      const bool upL = i == 0 || std::fabs(E[i]) >= std::fabs(E[i - 1]) || E[i] * E[i - 1] <= 0.0;
      const bool upR = i + 1 == ng || std::fabs(E[i]) >= std::fabs(E[i + 1]) || E[i] * E[i + 1] <= 0.0;
      if (upL && upR && E[i] != 0.0)
        cand.push_back(i);
    }
    // Neighbours of one sign collapse into the largest.
    std::vector<size_t> alt;
    for (size_t i : cand) {
      if (!alt.empty() && E[alt.back()] * E[i] > 0.0) {
        if (std::fabs(E[i]) > std::fabs(E[alt.back()]))
          alt.back() = i;
      } else {
        alt.push_back(i);
      }
    }
    while (alt.size() > r) {
      if (alt.size() == r + 1) {
        if (std::fabs(E[alt.front()]) < std::fabs(E[alt.back()]))
          alt.erase(alt.begin());
        else
          alt.pop_back();
      } else {
        // Drop the smallest neighbouring pair, keeping the alternation.
        size_t best = 0;
        double bv = kInf;
        for (size_t i = 0; i + 1 < alt.size(); i++) {
          const double v = std::max(std::fabs(E[alt[i]]), std::fabs(E[alt[i + 1]]));
          if (v < bv) {
            bv = v;
            best = i;
          }
        }
        alt.erase(alt.begin() + (long)best, alt.begin() + (long)best + 2);
      }
    }
    double emax = 0.0, emin = kInf;
    for (size_t i : alt) {
      emax = std::max(emax, std::fabs(E[i]));
      emin = std::min(emin, std::fabs(E[i]));
    }
    const bool same = alt == ext;
    if (alt.size() == r)
      ext = alt;
    if (same || (emax - emin) <= 1e-9 * emax)
      break;
  }
  setup();
  // Inverse DFT of the amplitude on numtaps uniform points.
  const size_t N = (size_t)numtaps;
  Vec A(N / 2 + 1);
  for (size_t k = 0; k < A.size(); k++) {
    const double f = (double)k / (double)N;
    if (!odd && k == N / 2) {
      A[k] = 0.0;
      continue;
    }
    double v = evalAt(std::cos(2.0 * kPi * f));
    if (!odd)
      v *= std::cos(kPi * f);
    A[k] = v;
  }
  h.assign(N, 0.0);
  const double M = 0.5 * (double)(N - 1);
  for (size_t n = 0; n < N; n++) {
    double s = A[0];
    for (size_t k = 1; k < A.size(); k++) {
      if (2 * k == N)
        continue;
      s += 2.0 * A[k] * std::cos(2.0 * kPi * (double)k * ((double)n - M) / (double)N);
    }
    h[n] = s / (double)N;
  }
  return true;
}

} // namespace

void registerSgFir(Registry &reg) {
  SP_ADD("firwin", 2, 6, "numtaps, cutoff, window=\"hamming\", pass_zero=1, scale=1, fs=2") {
    Vec cut, h;
    if (!isNumberArg(a, 0) || !getVec(a, 1, ctx, cut))
      return Value(0.0);
    bool passZero = true;
    if (a.size() > 3) {
      if (a[3].isText) {
        const std::string s = a[3].text();
        if (s == "bandstop" || s == "lowpass")
          passZero = true;
        else if (s == "bandpass" || s == "highpass")
          passZero = false;
        else {
          ctx.fail("pass_zero must be a truth value, or \"lowpass\", \"highpass\", \"bandpass\", \"bandstop\"");
          return Value(0.0);
        }
      } else {
        passZero = optBool(a, 3, true);
      }
    }
    const Value *win = a.size() > 2 && !isOmitted(a, 2) ? &a[2] : nullptr;
    const double fs = isOmitted(a, 5) ? 2.0 : optNum(a, 5, 2.0);
    std::string err;
    if (!sg::firwin((long)a[0].number, cut, win, passZero, optBool(a, 4, true), fs, h, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(h);
  } SP_END
  SP_ADD("firwin2", 3, 6, "numtaps, freq, gain, window=\"hamming\", nfreqs, fs=2") {
    Vec freq, gain;
    if (!isNumberArg(a, 0) || !getVec(a, 1, ctx, freq) || !getVec(a, 2, ctx, gain))
      return Value(0.0);
    const long numtaps = (long)a[0].number;
    const double fs = isOmitted(a, 5) ? 2.0 : optNum(a, 5, 2.0), nyq = 0.5 * fs;
    if (freq.size() != gain.size() || freq.empty()) {
      ctx.fail("freq and gain must have the same length");
      return Value(0.0);
    }
    if (freq.front() != 0.0 || freq.back() != nyq) {
      ctx.fail("freq must start with 0 and end with fs/2");
      return Value(0.0);
    }
    for (size_t i = 0; i + 1 < freq.size(); i++) {
      if (freq[i] > freq[i + 1]) {
        ctx.fail("freq must not decrease");
        return Value(0.0);
      }
    }
    if (numtaps % 2 == 0 && gain.back() != 0.0) {
      ctx.fail("a filter with even numtaps must have zero gain at the Nyquist frequency");
      return Value(0.0);
    }
    size_t nf = (size_t)(isOmitted(a, 4) ? 0 : optInt(a, 4, 0));
    if (!nf)
      nf = 1 + ((size_t)1 << (size_t)std::ceil(std::log2((double)numtaps)));
    const double eps = kEps * nyq;
    for (size_t k = 0; k + 1 < freq.size(); k++)
      if (freq[k] == freq[k + 1]) {
        freq[k] -= eps;
        freq[k + 1] += eps;
      }
    CVec fx2(nf);
    size_t seg = 0;
    for (size_t i = 0; i < nf; i++) {
      const double x = nyq * (double)i / (double)(nf - 1);
      while (seg + 2 < freq.size() && x > freq[seg + 1])
        seg++;
      const double t = (x - freq[seg]) / (freq[seg + 1] - freq[seg]);
      double g = gain[seg] + t * (gain[seg + 1] - gain[seg]);
      if (x <= freq.front())
        g = gain.front();
      if (x >= freq.back())
        g = gain.back();
      fx2[i] = g * std::polar(1.0, -0.5 * (double)(numtaps - 1) * kPi * x / nyq);
    }
    Vec full = ft::irfftLine(fx2, 2 * (nf - 1));
    Vec win(numtaps, 1.0);
    std::string err;
    if (a.size() <= 3 || !isOmitted(a, 3)) {
      if (a.size() > 3) {
        if (!windowFromValue(a[3], (size_t)numtaps, true, win, err)) {
          ctx.fail(err);
          return Value(0.0);
        }
      } else if (!windowByName("hamming", {}, (size_t)numtaps, true, win, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
    }
    Vec out((size_t)numtaps);
    for (size_t i = 0; i < out.size(); i++)
      out[i] = full[i] * win[i];
    return toValue(out);
  } SP_END
  SP_ADD("firls", 3, 5, "numtaps, bands, desired, weight, fs=2") {
    Vec bands, des, wt;
    if (!isNumberArg(a, 0) || !getVec(a, 1, ctx, bands) || !getVec(a, 2, ctx, des))
      return Value(0.0);
    const long numtaps = (long)a[0].number;
    if (numtaps % 2 == 0) {
      ctx.fail("numtaps must be odd");
      return Value(0.0);
    }
    if (bands.size() % 2 || bands.empty() || bands.size() != des.size()) {
      ctx.fail("bands and desired must hold the same even number of values");
      return Value(0.0);
    }
    const double fs = isOmitted(a, 4) ? 2.0 : optNum(a, 4, 2.0), nyq = 0.5 * fs;
    for (double &v : bands)
      v /= nyq;
    for (size_t i = 0; i + 1 < bands.size(); i++)
      if (bands[i] > bands[i + 1] || bands[i] < 0.0 || bands[i + 1] > 1.0) {
        ctx.fail("bands must increase from 0 towards fs/2");
        return Value(0.0);
      }
    const size_t nb = bands.size() / 2;
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (!getVec(a, 3, ctx, wt))
        return Value(0.0);
      if (wt.size() != nb) {
        ctx.fail("weight needs one value per band");
        return Value(0.0);
      }
    } else {
      wt.assign(nb, 1.0);
    }
    const size_t M = (size_t)(numtaps - 1) / 2;
    auto sinc = [](double x) { return x == 0.0 ? 1.0 : std::sin(kPi * x) / (kPi * x); };
    Vec q((size_t)numtaps, 0.0);
    for (long n = 0; n < numtaps; n++)
      for (size_t k = 0; k < nb; k++) {
        const double f1 = bands[2 * k], f2 = bands[2 * k + 1];
        q[(size_t)n] += wt[k] * (sinc(f2 * (double)n) * f2 - sinc(f1 * (double)n) * f1);
      }
    Mat Q(M + 1, M + 1);
    for (size_t i = 0; i <= M; i++)
      for (size_t j = 0; j <= M; j++)
        Q(i, j) = q[i > j ? i - j : j - i] + q[i + j];
    Vec b(M + 1, 0.0);
    for (size_t k = 0; k < nb; k++) {
      const double f1 = bands[2 * k], f2 = bands[2 * k + 1], m = (des[2 * k + 1] - des[2 * k]) / (f2 - f1), c = des[2 * k] - f1 * m;
      for (size_t n = 0; n <= M; n++) {
        const double dn = (double)n;
        auto term = [&](double f) {
          double v = f * (m * f + c) * sinc(f * dn);
          if (n == 0)
            v -= m * f * f / 2.0;
          else
            v += m * std::cos(dn * kPi * f) / ((kPi * dn) * (kPi * dn));
          return v;
        };
        b[n] += wt[k] * (term(f2) - term(f1));
      }
    }
    Vec coef = b;
    if (!la::solveVec(Q, coef))
      coef = la::lstsqMin(Q, b);
    Vec h;
    for (size_t i = M; i >= 1; i--)
      h.push_back(coef[i]);
    h.push_back(2.0 * coef[0]);
    for (size_t i = 1; i <= M; i++)
      h.push_back(coef[i]);
    return toValue(h);
  } SP_END
  SP_ADD("remez", 3, 8, "numtaps, bands, desired, weight, type=\"bandpass\", maxiter=25, density=16, fs=1") {
    Vec bands, des, wt;
    if (!isNumberArg(a, 0) || !getVec(a, 1, ctx, bands) || !getVec(a, 2, ctx, des))
      return Value(0.0);
    const double fs = isOmitted(a, 7) ? 1.0 : optNum(a, 7, 1.0);
    if (bands.size() % 2 || bands.empty() || des.size() != bands.size() / 2) {
      ctx.fail("bands needs two edges per band, desired one gain per band");
      return Value(0.0);
    }
    for (double &v : bands)
      v /= fs;
    for (size_t i = 0; i + 1 < bands.size(); i++)
      if (bands[i] >= bands[i + 1]) {
        ctx.fail("bands must increase");
        return Value(0.0);
      }
    if (bands.front() < 0.0 || bands.back() > 0.5) {
      ctx.fail("the band edges must lie between 0 and fs/2");
      return Value(0.0);
    }
    if (a.size() > 3 && !isOmitted(a, 3)) {
      if (!getVec(a, 3, ctx, wt))
        return Value(0.0);
      if (wt.size() != des.size()) {
        ctx.fail("weight needs one value per band");
        return Value(0.0);
      }
    } else {
      wt.assign(des.size(), 1.0);
    }
    const std::string type = optText(a, 4, "bandpass");
    if (type != "bandpass") {
      ctx.fail("this version designs type \"bandpass\" filters");
      return Value(0.0);
    }
    Vec h;
    std::string err;
    if (!remezExchange((long)a[0].number, bands, des, wt, (long)(isOmitted(a, 5) ? 25 : optInt(a, 5, 25)) * 4, (long)(isOmitted(a, 6) ? 16 : optInt(a, 6, 16)), type, h, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(h);
  } SP_END
  SP_ADD("minimum_phase", 1, 3, "h, method=\"homomorphic\", n_fft") {
    Vec h;
    if (!getVec(a, 0, ctx, h))
      return Value(0.0);
    if (h.size() <= 2) {
      ctx.fail("h must have more than two taps");
      return Value(0.0);
    }
    const std::string method = optText(a, 1, "homomorphic");
    if (method != "homomorphic" && method != "hilbert") {
      ctx.fail("method must be \"homomorphic\" or \"hilbert\"");
      return Value(0.0);
    }
    size_t nfft = (size_t)(isOmitted(a, 2) ? 0 : optInt(a, 2, 0));
    if (!nfft)
      nfft = (size_t)1 << (size_t)std::ceil(std::log2(2.0 * (double)(h.size() - 1) / 0.01));
    if (nfft < h.size()) {
      ctx.fail("n_fft must be at least the length of h");
      return Value(0.0);
    }
    const size_t half = h.size() / 2;
    CVec F(nfft, cd(0.0));
    for (size_t i = 0; i < h.size(); i++)
      F[i] = h[i];
    ft::fft(F, false);
    Vec out(nfft);
    if (method == "hilbert") {
      Vec H(nfft);
      double top = -kInf, low = kInf;
      for (size_t i = 0; i < nfft; i++) {
        H[i] = (F[i] * std::polar(1.0, (double)i * 2.0 * kPi / (double)nfft * (double)half)).real();
        top = std::max(top, H[i]);
        low = std::min(low, H[i]);
      }
      const double dp = top - 1.0, ds = -low, S = 4.0 / std::pow(std::sqrt(1.0 + dp + ds) + std::sqrt(1.0 - dp + ds), 2.0);
      for (double &v : H)
        v = std::sqrt((v + ds) * S) + 1e-10;
      CVec lg(nfft);
      for (size_t i = 0; i < nfft; i++)
        lg[i] = std::log(H[i]);
      ft::fft(lg, true);
      const size_t mid = nfft / 2;
      for (size_t i = 0; i < nfft; i++)
        lg[i] *= i == 0 || i == mid ? 0.0 : (i < mid ? 1.0 : -1.0);
      ft::fft(lg, false);
      CVec z(nfft);
      for (size_t i = 0; i < nfft; i++)
        z[i] = H[i] * std::exp(lg[i]);
      ft::fft(z, true);
      for (size_t i = 0; i < nfft; i++)
        out[i] = z[i].real();
    } else {
      Vec mag(nfft);
      double mn = kInf;
      for (size_t i = 0; i < nfft; i++) {
        mag[i] = std::abs(F[i]);
        if (mag[i] > 0.0)
          mn = std::min(mn, mag[i]);
      }
      CVec lg(nfft);
      for (size_t i = 0; i < nfft; i++)
        lg[i] = 0.5 * std::log(mag[i] + 1e-7 * mn);
      ft::fft(lg, true);
      const size_t stop = nfft / 2;
      for (size_t i = 0; i < nfft; i++) {
        const double w = i == 0 ? 1.0 : (i < stop ? 2.0 : (i == stop ? 1.0 + (double)(nfft % 2) : 0.0));
        lg[i] = lg[i].real() * w;
      }
      ft::fft(lg, false);
      for (cd &v : lg)
        v = std::exp(v);
      ft::fft(lg, true);
      for (size_t i = 0; i < nfft; i++)
        out[i] = lg[i].real();
    }
    out.resize(half + h.size() % 2);
    return toValue(out);
  } SP_END
  SP_ADD("kaiser_atten", 2, 2, "numtaps, width") {
    (void)ctx;
    return Value(2.285 * (optNum(a, 0, 1) - 1.0) * kPi * optNum(a, 1, 0) + 7.95);
  } SP_END
  SP_ADD("kaiser_beta", 1, 1, "atten") {
    (void)ctx;
    const double A = optNum(a, 0, 0);
    return Value(A > 50.0 ? 0.1102 * (A - 8.7) : (A > 21.0 ? 0.5842 * std::pow(A - 21.0, 0.4) + 0.07886 * (A - 21.0) : 0.0));
  } SP_END
  SP_ADD("kaiser_order", 2, 2, "ripple, width") {
    const double A = std::fabs(optNum(a, 0, 0)), w = optNum(a, 1, 0);
    if (A < 8.0) {
      ctx.fail("the requested attenuation is too small for the Kaiser formula: it must be at least 8 dB");
      return Value(0.0);
    }
    const double nt = (A - 7.95) / (2.285 * kPi * w) + 1.0;
    const double beta = A > 50.0 ? 0.1102 * (A - 8.7) : (A > 21.0 ? 0.5842 * std::pow(A - 21.0, 0.4) + 0.07886 * (A - 21.0) : 0.0);
    return makeDict({{"numtaps", Value(std::ceil(nt))}, {"beta", Value(beta)}});
  } SP_END
  SP_ADD("firwin_2d", 3, 4, "shape, windows, fc, fs=2") {
    Vec sh;
    if (!getVec(a, 0, ctx, sh) || sh.size() != 2) {
      ctx.fail("shape must be [rows, cols]");
      return Value(0.0);
    }
    Value w0, w1;
    if (a[1].isText) {
      w0 = w1 = a[1];
    } else if (a[1].isArray && a[1].length() == 2) {
      w0 = a[1].at(0);
      w1 = a[1].at(1);
    } else if (a[1].isMatrix && a[1].rows() == 1 && a[1].cols() == 2) {
      w0 = a[1].at(0, 0);
      w1 = a[1].at(0, 1);
    } else {
      ctx.fail("windows must be one name, or two names [\"hamming\", \"hann\"]");
      return Value(0.0);
    }
    Vec fc;
    if (!getVec(a, 2, ctx, fc))
      return Value(0.0);
    const double fs = isOmitted(a, 3) ? 2.0 : optNum(a, 3, 2.0);
    Vec h0, h1;
    std::string err;
    if (!sg::firwin((long)sh[0], fc, &w0, true, true, fs, h0, err) || !sg::firwin((long)sh[1], fc, &w1, true, true, fs, h1, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    Mat H(h0.size(), h1.size());
    for (size_t i = 0; i < H.r; i++)
      for (size_t j = 0; j < H.c; j++)
        H(i, j) = h0[i] * h1[j];
    return toValue(H);
  } SP_END
}

} // namespace scipy
} // namespace nc
