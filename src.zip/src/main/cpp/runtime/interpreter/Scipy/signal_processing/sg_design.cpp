// IIR design: analog prototypes, frequency transforms, the classical filters and
// their order estimates, conversions between forms, partial fractions, responses.
#include <functional>
#include <map>

#include "../linear_algebra/la_core.h"
#include "sg_core.h"
#include "signal_processing_main.h"

#define SP_SEC Section::SignalProcessing

namespace nc {
namespace scipy {
namespace sg {

Vec polyMul(const Vec &a, const Vec &b) {
  if (a.empty() || b.empty())
    return {};
  Vec o(a.size() + b.size() - 1, 0.0);
  for (size_t i = 0; i < a.size(); i++)
    for (size_t j = 0; j < b.size(); j++)
      o[i + j] += a[i] * b[j];
  return o;
}
CVec polyMulC(const CVec &a, const CVec &b) {
  if (a.empty() || b.empty())
    return {};
  CVec o(a.size() + b.size() - 1, cd(0.0));
  for (size_t i = 0; i < a.size(); i++)
    for (size_t j = 0; j < b.size(); j++)
      o[i + j] += a[i] * b[j];
  return o;
}
CVec polyAddC(const CVec &a, const CVec &b) {
  const size_t n = std::max(a.size(), b.size());
  CVec o(n, cd(0.0));
  for (size_t i = 0; i < a.size(); i++)
    o[n - a.size() + i] += a[i];
  for (size_t i = 0; i < b.size(); i++)
    o[n - b.size() + i] += b[i];
  return o;
}
CVec polyOfRoots(const CVec &roots) {
  CVec p{cd(1.0)};
  for (const cd &z : roots)
    p = polyMulC(p, CVec{cd(1.0), -z});
  return p;
}
cd polyval(const CVec &c, cd x) {
  cd s(0.0);
  for (const cd &v : c)
    s = s * x + v;
  return s;
}
cd polyval(const Vec &c, cd x) {
  cd s(0.0);
  for (double v : c)
    s = s * x + v;
  return s;
}
double polyvalReal(const Vec &c, double x) {
  double s = 0.0;
  for (double v : c)
    s = s * x + v;
  return s;
}
Vec realParts(const CVec &v) {
  Vec o(v.size());
  for (size_t i = 0; i < v.size(); i++)
    o[i] = v[i].real();
  return o;
}
void sortRoots(CVec &r) {
  std::sort(r.begin(), r.end(), [](const cd &a, const cd &b) {
    if (std::fabs(a.real() - b.real()) > 1e-9 * (1.0 + std::fabs(a.real())))
      return a.real() < b.real();
    return a.imag() < b.imag();
  });
}
CVec rootsOf(const Vec &in) {
  size_t first = 0, last = in.size();
  while (first < last && in[first] == 0.0)
    first++;
  size_t zeros = 0;
  while (last > first && in[last - 1] == 0.0) {
    last--;
    zeros++;
  }
  CVec out(zeros, cd(0.0));
  if (last - first >= 2) {
    CVec c(in.begin() + (long)first, in.begin() + (long)last);
    CVec r = la::polyRoots(c);
    // A real polynomial: make the conjugate pairs exact.
    std::vector<char> done(r.size(), 0);
    for (size_t i = 0; i < r.size(); i++) {
      if (done[i] || r[i].imag() <= 0.0)
        continue;
      long best = -1;
      double bd = kInf;
      for (size_t j = 0; j < r.size(); j++)
        if (!done[j] && r[j].imag() < 0.0 && std::abs(r[j] - std::conj(r[i])) < bd) {
          bd = std::abs(r[j] - std::conj(r[i]));
          best = (long)j;
        }
      if (best >= 0) {
        const cd m = 0.5 * (r[i] + std::conj(r[(size_t)best]));
        r[i] = m;
        r[(size_t)best] = std::conj(m);
        done[i] = done[(size_t)best] = 1;
      }
    }
    for (size_t i = 0; i < r.size(); i++)
      if (!done[i])
        r[i] = cd(r[i].real(), 0.0);
    out.insert(out.end(), r.begin(), r.end());
  }
  sortRoots(out);
  return out;
}

bool normalizeTf(Vec &b, Vec &a, std::string &err) {
  size_t i = 0;
  while (i < a.size() && a[i] == 0.0)
    i++;
  if (i == a.size()) {
    err = "the denominator must have at least one nonzero coefficient";
    return false;
  }
  a.erase(a.begin(), a.begin() + (long)i);
  const double d = a[0];
  for (double &v : a)
    v /= d;
  for (double &v : b)
    v /= d;
  size_t lead = 0;
  while (lead + 1 < b.size() && std::fabs(b[lead]) <= 1e-14)
    lead++;
  b.erase(b.begin(), b.begin() + (long)lead);
  return true;
}

bool tf2zpk(Vec b, Vec a, Zpk &out, std::string &err) {
  if (!normalizeTf(b, a, err))
    return false;
  out.k = b.empty() ? 0.0 : b[0];
  if (out.k != 0.0)
    for (double &v : b)
      v /= out.k;
  out.z = rootsOf(b);
  out.p = rootsOf(a);
  return true;
}

static Vec realPoly(const CVec &p) { return realParts(p); }

void zpk2tf(const Zpk &f, Vec &b, Vec &a) {
  b = realPoly(polyOfRoots(f.z));
  for (double &v : b)
    v *= f.k;
  a = realPoly(polyOfRoots(f.p));
}

// Pairs up conjugates: the ones with positive imaginary part, then the real ones.
static bool cplxReal(CVec z, CVec &pairs, Vec &reals, std::string &err) {
  const double tol = 100.0 * kEps;
  std::stable_sort(z.begin(), z.end(), [](const cd &x, const cd &y) {
    if (x.real() != y.real())
      return x.real() < y.real();
    return std::fabs(x.imag()) < std::fabs(y.imag());
  });
  CVec zp, zn;
  for (const cd &v : z) {
    if (std::fabs(v.imag()) <= tol * std::abs(v))
      reals.push_back(v.real());
    else if (v.imag() > 0.0)
      zp.push_back(v);
    else
      zn.push_back(v);
  }
  if (zp.size() != zn.size()) {
    err = "the roots must come in conjugate pairs";
    return false;
  }
  auto byImag = [&](CVec &v) {
    std::stable_sort(v.begin(), v.end(), [&](const cd &x, const cd &y) {
      if (std::fabs(x.real() - y.real()) > tol * std::max(std::abs(x), std::abs(y)))
        return x.real() < y.real();
      return std::fabs(x.imag()) < std::fabs(y.imag());
    });
  };
  byImag(zp);
  byImag(zn);
  for (size_t i = 0; i < zp.size(); i++) {
    if (std::abs(zp[i] - std::conj(zn[i])) > std::max(1e-8, tol) * std::abs(zn[i])) {
      err = "the roots must come in conjugate pairs";
      return false;
    }
    pairs.push_back((zp[i] + std::conj(zn[i])) * 0.5);
  }
  return true;
}

static size_t nearestIdx(const CVec &from, const cd &to, int which) { // 0 any, 1 real, 2 complex
  long best = -1;
  double bd = kInf;
  for (size_t i = 0; i < from.size(); i++) {
    const bool isReal = from[i].imag() == 0.0;
    if ((which == 1 && !isReal) || (which == 2 && isReal))
      continue;
    const double d = std::abs(from[i] - to);
    if (d < bd) {
      bd = d;
      best = (long)i;
    }
  }
  return (size_t)best;
}

static void singleSection(Mat &sos, size_t si, const CVec &z, const CVec &p) {
  Zpk f;
  f.z = z;
  f.p = p;
  Vec b, a;
  zpk2tf(f, b, a);
  for (size_t i = 0; i < b.size(); i++)
    sos(si, 3 - b.size() + i) = b[i];
  for (size_t i = 0; i < a.size(); i++)
    sos(si, 6 - a.size() + i) = a[i];
}

bool zpk2sos(const Zpk &f, Mat &sos, std::string &err) {
  CVec zIn = f.z, pIn = f.p;
  if (zIn.empty() && pIn.empty()) {
    sos = Mat(1, 6);
    sos(0, 0) = f.k;
    sos(0, 3) = 1.0;
    return true;
  }
  const size_t maxN = std::max(zIn.size(), pIn.size());
  zIn.resize(maxN, cd(0.0));
  pIn.resize(maxN, cd(0.0));
  const size_t sections = (maxN + 1) / 2;
  if (pIn.size() % 2 == 1) {
    zIn.push_back(cd(0.0));
    pIn.push_back(cd(0.0));
  }
  CVec zc, pc;
  Vec zr, pr;
  if (!cplxReal(zIn, zc, zr, err) || !cplxReal(pIn, pc, pr, err))
    return false;
  CVec z = zc, p = pc;
  z.insert(z.end(), zr.begin(), zr.end());
  p.insert(p.end(), pr.begin(), pr.end());
  auto worst = [](const CVec &v) {
    size_t b = 0;
    for (size_t i = 1; i < v.size(); i++)
      if (std::fabs(1.0 - std::abs(v[i])) < std::fabs(1.0 - std::abs(v[b])))
        b = i;
    return b;
  };
  auto countReal = [](const CVec &v) {
    size_t c = 0;
    for (const cd &x : v)
      c += x.imag() == 0.0;
    return c;
  };
  sos = Mat(sections, 6);
  for (size_t si = sections; si-- > 0;) {
    const size_t pi1 = worst(p);
    const cd p1 = p[pi1];
    p.erase(p.begin() + (long)pi1);
    const bool p1Real = p1.imag() == 0.0;
    if (p1Real && countReal(p) == 0) {
      const size_t zi = nearestIdx(z, p1, 1);
      const cd z1 = z[zi];
      z.erase(z.begin() + (long)zi);
      singleSection(sos, si, {z1, cd(0.0)}, {p1, cd(0.0)});
    } else if (p.size() + 1 == z.size() && !p1Real && countReal(p) == 1 && countReal(z) == 1) {
      const size_t zi = nearestIdx(z, p1, 2);
      const cd z1 = z[zi];
      z.erase(z.begin() + (long)zi);
      singleSection(sos, si, {z1, std::conj(z1)}, {p1, std::conj(p1)});
    } else {
      cd p2;
      if (p1Real) {
        long best = -1;
        for (size_t i = 0; i < p.size(); i++)
          if (p[i].imag() == 0.0 && (best < 0 || std::fabs(1.0 - std::abs(p[i])) < std::fabs(1.0 - std::abs(p[(size_t)best]))))
            best = (long)i;
        p2 = p[(size_t)best];
        p.erase(p.begin() + best);
      } else {
        p2 = std::conj(p1);
      }
      if (!z.empty()) {
        const size_t zi = nearestIdx(z, p1, 0);
        const cd z1 = z[zi];
        z.erase(z.begin() + (long)zi);
        if (z1.imag() != 0.0) {
          singleSection(sos, si, {z1, std::conj(z1)}, {p1, p2});
        } else if (!z.empty()) {
          const size_t zj = nearestIdx(z, p1, 1);
          const cd z2 = z[zj];
          z.erase(z.begin() + (long)zj);
          singleSection(sos, si, {z1, z2}, {p1, p2});
        } else {
          singleSection(sos, si, {z1}, {p1, p2});
        }
      } else {
        singleSection(sos, si, {}, {p1, p2});
      }
    }
  }
  for (size_t j = 0; j < 3; j++)
    sos(0, j) *= f.k;
  return true;
}

Zpk sos2zpk(const Mat &sos) {
  Zpk o;
  o.z.assign(sos.r * 2, cd(0.0));
  o.p.assign(sos.r * 2, cd(0.0));
  std::string err;
  for (size_t i = 0; i < sos.r; i++) {
    Vec b(sos.row(i), sos.row(i) + 3), a(sos.row(i) + 3, sos.row(i) + 6);
    Zpk s;
    if (!tf2zpk(b, a, s, err))
      continue;
    std::copy(s.z.begin(), s.z.end(), o.z.begin() + (long)(2 * i));
    std::copy(s.p.begin(), s.p.end(), o.p.begin() + (long)(2 * i));
    o.k *= s.k;
  }
  return o;
}

void sos2tf(const Mat &sos, Vec &b, Vec &a) {
  b = Vec{1.0};
  a = Vec{1.0};
  for (size_t i = 0; i < sos.r; i++) {
    b = polyMul(b, Vec(sos.row(i), sos.row(i) + 3));
    a = polyMul(a, Vec(sos.row(i) + 3, sos.row(i) + 6));
  }
  // scipy trims the factors of s^0 left over from first-order sections.
  size_t trim = 0;
  while (trim + 1 < a.size() && trim + 1 < b.size() && a[a.size() - 1 - trim] == 0.0 && b[b.size() - 1 - trim] == 0.0)
    trim++;
  a.resize(a.size() - trim);
  b.resize(b.size() - trim);
}

bool tf2ss(Vec b, Vec a, Ss &out, std::string &err) {
  if (!normalizeTf(b, a, err))
    return false;
  const size_t K = a.size();
  if (b.size() > K) {
    err = "the numerator must not have a higher degree than the denominator";
    return false;
  }
  b.insert(b.begin(), K - b.size(), 0.0);
  if (K == 1) {
    out.A = Mat(1, 1);
    out.B = Mat(1, 1);
    out.C = Mat(1, 1);
    out.D = Mat(1, 1, b[0]);
    return true;
  }
  const size_t n = K - 1;
  out.A = Mat(n, n);
  for (size_t j = 0; j < n; j++)
    out.A(0, j) = -a[j + 1];
  for (size_t i = 1; i < n; i++)
    out.A(i, i - 1) = 1.0;
  out.B = Mat(n, 1);
  out.B(0, 0) = 1.0;
  out.C = Mat(1, n);
  for (size_t j = 0; j < n; j++)
    out.C(0, j) = b[j + 1] - b[0] * a[j + 1];
  out.D = Mat(1, 1, b[0]);
  return true;
}

static Vec charPoly(const Mat &A) {
  if (A.r == 0)
    return {1.0};
  CVec w;
  la::eigGeneral(toComplex(A), w, nullptr);
  return realParts(polyOfRoots(w));
}

void ss2tf(const Ss &s, size_t input, Mat &num, Vec &den) {
  den = charPoly(s.A);
  const size_t n = s.A.r, outs = s.D.r;
  num = Mat(outs, n + 1);
  Vec Bcol(n);
  for (size_t i = 0; i < n; i++)
    Bcol[i] = s.B(i, input);
  for (size_t k = 0; k < outs; k++) {
    Mat T = s.A;
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++)
        T(i, j) -= Bcol[i] * s.C(k, j);
    Vec q = charPoly(T);
    for (size_t j = 0; j <= n; j++)
      num(k, j) = q[j] + (s.D(k, input) - 1.0) * den[j];
  }
}

bool abcdNormalize(Ss &s, std::string &err) {
  size_t p = s.A.r ? s.A.r : (s.B.r ? s.B.r : s.C.c);
  size_t q = s.B.c ? s.B.c : s.D.c;
  size_t r = s.C.r ? s.C.r : s.D.r;
  if (s.A.a.empty() && !p)
    p = 0;
  if (!q)
    q = 1;
  if (!r)
    r = 1;
  if (s.A.a.empty())
    s.A = Mat(p, p);
  if (s.B.a.empty())
    s.B = Mat(p, q);
  if (s.C.a.empty())
    s.C = Mat(r, p);
  if (s.D.a.empty())
    s.D = Mat(r, q);
  if (s.A.r != s.A.c) {
    err = "A must be square";
    return false;
  }
  if (s.A.r != s.B.r) {
    err = "A and B must have the same number of rows";
    return false;
  }
  if (s.A.c != s.C.c) {
    err = "A and C must have the same number of columns";
    return false;
  }
  if (s.D.r != s.C.r) {
    err = "C and D must have the same number of rows";
    return false;
  }
  if (s.D.c != s.B.c) {
    err = "B and D must have the same number of columns";
    return false;
  }
  return true;
}

Value tfDict(const Vec &b, const Vec &a) { return makeDict({{"b", toValue(b)}, {"a", toValue(a)}}); }
Value zpkDict(const Zpk &f) { return makeDict({{"z", realIfPossible(f.z)}, {"p", realIfPossible(f.p)}, {"k", Value(f.k)}}); }
Value ssDict(const Ss &s) { return makeDict({{"A", toValue(s.A)}, {"B", toValue(s.B)}, {"C", toValue(s.C)}, {"D", toValue(s.D)}}); }

CVec freqsAt(const Vec &b, const Vec &a, const CVec &s) {
  CVec h(s.size());
  for (size_t i = 0; i < s.size(); i++)
    h[i] = polyval(b, s[i]) / polyval(a, s[i]);
  return h;
}

Vec findFreqs(const CVec &poles, const CVec &zeros, size_t n) {
  CVec ez;
  if (poles.empty())
    ez.push_back(cd(-1000.0));
  for (const cd &v : poles)
    if (v.imag() >= 0.0)
      ez.push_back(v);
  for (const cd &v : zeros)
    if (std::abs(v) < 1e5 && v.imag() >= 0.0)
      ez.push_back(v);
  double top = -kInf, low = kInf;
  for (const cd &v : ez) {
    const double integ = std::abs(v) < 1e-10 ? 1.0 : 0.0;
    top = std::max(top, 3.0 * std::fabs(v.real() + integ) + 1.5 * v.imag());
    low = std::min(low, std::fabs(v.real() + integ) + 2.0 * v.imag());
  }
  const double hi = std::nearbyint(std::log10(top) + 0.5), lo = std::nearbyint(std::log10(0.1 * low) - 0.5);
  Vec w(n);
  for (size_t i = 0; i < n; i++)
    w[i] = std::pow(10.0, n > 1 ? lo + (hi - lo) * (double)i / (double)(n - 1) : lo);
  return w;
}

Vec angleGrid(size_t n, bool whole) {
  Vec w(n);
  for (size_t i = 0; i < n; i++)
    w[i] = (whole ? 2.0 : 1.0) * kPi * (double)i / (double)n;
  return w;
}

CVec freqzAt(const Vec &b, const Vec &a, const Vec &w) {
  Vec br(b.rbegin(), b.rend()), ar(a.rbegin(), a.rend());
  CVec h(w.size());
  for (size_t i = 0; i < w.size(); i++) {
    const cd z = std::polar(1.0, -w[i]);
    h[i] = polyval(br, z) / polyval(ar, z);
  }
  return h;
}

CVec freqzZpkAt(const CVec &z, const CVec &p, double k, const Vec &w) {
  CVec h(w.size());
  for (size_t i = 0; i < w.size(); i++) {
    const cd e = std::polar(1.0, w[i]);
    cd v(k);
    for (const cd &q : z)
      v *= e - q;
    for (const cd &q : p)
      v /= e - q;
    h[i] = v;
  }
  return h;
}

Vec unwrapped(Vec p) {
  for (size_t i = 1; i < p.size(); i++) {
    double d = p[i] - p[i - 1];
    double m = std::fmod(d + kPi, 2.0 * kPi);
    if (m < 0)
      m += 2.0 * kPi;
    m -= kPi;
    if (m == -kPi && d > 0)
      m = kPi;
    const double corr = std::fabs(d) < kPi ? 0.0 : m - d;
    p[i] += corr;
    for (size_t j = i + 1; j < p.size(); j++)
      p[j] += corr;
  }
  return p;
}

} // namespace sg

using namespace sg;

namespace {

// ---- elliptic integrals and functions (Jacobi), by the arithmetic-geometric mean ----
double agm(double a, double b) {
  for (int i = 0; i < 60 && std::fabs(a - b) > 1e-16 * a; i++) {
    const double t = 0.5 * (a + b);
    b = std::sqrt(a * b);
    a = t;
  }
  return a;
}
double ellipK(double m) { return m > 1.0 ? kNaN : (m == 1.0 ? kInf : kPi / (2.0 * agm(1.0, std::sqrt(1.0 - m)))); }
double ellipKm1(double p) { return p <= 0.0 ? kInf : kPi / (2.0 * agm(1.0, std::sqrt(p))); }
void ellipJ(double u, double m, double &sn, double &cn, double &dn) {
  double a[32], c[32];
  a[0] = 1.0;
  double b = std::sqrt(1.0 - m);
  c[0] = std::sqrt(m);
  int n = 0;
  while (std::fabs(c[n]) > 1e-16 && n < 30) {
    const double an = 0.5 * (a[n] + b);
    c[n + 1] = 0.5 * (a[n] - b);
    b = std::sqrt(a[n] * b);
    a[n + 1] = an;
    n++;
  }
  double phi = std::ldexp(a[n] * u, n), prev = phi;
  for (int i = n; i > 0; i--) {
    prev = phi;
    phi = 0.5 * (std::asin(c[i] / a[i] * std::sin(phi)) + phi);
  }
  sn = std::sin(phi);
  cn = std::cos(phi);
  dn = n > 0 && std::fabs(std::cos(prev - phi)) > 0.1 ? cn / std::cos(prev - phi) : std::sqrt(std::max(0.0, 1.0 - m * sn * sn));
}
double pow10m1(double x) { return std::expm1(x * std::log(10.0)); }

double ellipDeg(int n, double m1) {
  const double q1 = std::exp(-kPi * ellipKm1(m1) / ellipK(m1)), q = std::pow(q1, 1.0 / n);
  double num = 0.0, den = 1.0;
  for (int k = 0; k <= 7; k++) {
    num += std::pow(q, k * (k + 1));
    den += 2.0 * std::pow(q, (k + 1) * (k + 1));
  }
  return 16.0 * q * std::pow(num / den, 4);
}

double arcJacSc1(double w, double m) {
  auto complement = [](cd k) { return std::sqrt((1.0 - k) * (1.0 + k)); };
  std::vector<double> ks{std::sqrt(m)};
  while (ks.back() != 0.0 && ks.size() < 12) {
    const double kp = complement(ks.back()).real();
    ks.push_back((1.0 - kp) / (1.0 + kp));
  }
  double K = kPi / 2.0;
  for (size_t i = 1; i < ks.size(); i++)
    K *= 1.0 + ks[i];
  cd wn(0.0, w);
  for (size_t i = 0; i + 1 < ks.size(); i++)
    wn = 2.0 * wn / ((1.0 + ks[i + 1]) * (1.0 + complement(ks[i] * wn)));
  const cd z = K * (2.0 / kPi) * std::asin(wn);
  return z.imag();
}

Zpk buttap(int N) {
  Zpk f;
  for (int m = -N + 1; m < N; m += 2)
    f.p.push_back(-std::polar(1.0, kPi * m / (2.0 * N)));
  return f;
}
Zpk cheb1ap(int N, double rp) {
  Zpk f;
  if (N == 0) {
    f.k = std::pow(10.0, -rp / 20.0);
    return f;
  }
  const double eps = std::sqrt(std::pow(10.0, 0.1 * rp) - 1.0), mu = std::asinh(1.0 / eps) / N;
  cd prod(1.0);
  for (int m = -N + 1; m < N; m += 2) {
    const cd pv = -std::sinh(cd(mu, kPi * m / (2.0 * N)));
    f.p.push_back(pv);
    prod *= -pv;
  }
  f.k = prod.real();
  if (N % 2 == 0)
    f.k /= std::sqrt(1.0 + eps * eps);
  return f;
}
Zpk cheb2ap(int N, double rs) {
  Zpk f;
  if (N == 0)
    return f;
  const double de = 1.0 / std::sqrt(std::pow(10.0, 0.1 * rs) - 1.0), mu = std::asinh(1.0 / de) / N;
  cd prod(1.0);
  for (int m = -N + 1; m < N; m += 2) {
    if (m == 0)
      continue;
    const cd z(0.0, 1.0 / std::sin(m * kPi / (2.0 * N)));
    f.z.push_back(z);
    prod /= -z;
  }
  for (int m = -N + 1; m < N; m += 2) {
    const cd q = -std::polar(1.0, kPi * m / (2.0 * N));
    const cd pv = 1.0 / cd(std::sinh(mu) * q.real(), std::cosh(mu) * q.imag());
    f.p.push_back(pv);
    prod *= -pv;
  }
  f.k = prod.real();
  return f;
}
bool ellipap(int N, double rp, double rs, Zpk &f, std::string &err) {
  f = Zpk();
  if (N == 0) {
    f.k = std::pow(10.0, -rp / 20.0);
    return true;
  }
  if (N == 1) {
    const double pv = -std::sqrt(1.0 / pow10m1(0.1 * rp));
    f.p = {cd(pv)};
    f.k = -pv;
    return true;
  }
  const double epsSq = pow10m1(0.1 * rp), eps = std::sqrt(epsSq), ck1 = epsSq / pow10m1(0.1 * rs);
  if (ck1 == 0.0) {
    err = "the ripple and attenuation give an empty transition band";
    return false;
  }
  const double K0 = ellipK(ck1), m = ellipDeg(N, ck1), capk = ellipK(m);
  std::vector<double> s, c, d;
  for (int j = 1 - N % 2; j < N; j += 2) {
    double sn, cn, dn;
    ellipJ(j * capk / N, m, sn, cn, dn);
    s.push_back(sn);
    c.push_back(cn);
    d.push_back(dn);
  }
  CVec zs;
  for (double v : s)
    if (std::fabs(v) > 1e-14)
      zs.push_back(cd(0.0, 1.0 / (std::sqrt(m) * v)));
  f.z = zs;
  for (const cd &v : zs)
    f.z.push_back(std::conj(v));
  const double r = arcJacSc1(1.0 / eps, ck1), v0 = capk * r / (N * K0);
  double sv, cv, dv;
  ellipJ(v0, 1.0 - m, sv, cv, dv);
  CVec ps;
  for (size_t i = 0; i < s.size(); i++)
    ps.push_back(-(cd(c[i] * d[i] * sv * cv, s[i] * dv)) / (1.0 - std::pow(d[i] * sv, 2.0)));
  double norm = 0.0;
  for (const cd &v : ps)
    norm += std::norm(v);
  norm = std::sqrt(norm);
  f.p = ps;
  for (const cd &v : ps)
    if (N % 2 == 0 || std::fabs(v.imag()) > 1e-14 * norm)
      f.p.push_back(std::conj(v));
  cd prod(1.0);
  for (const cd &v : f.p)
    prod *= -v;
  for (const cd &v : f.z)
    prod /= -v;
  f.k = prod.real();
  if (N % 2 == 0)
    f.k /= std::sqrt(1.0 + epsSq);
  return true;
}
bool besselap(int N, const std::string &norm, Zpk &f, std::string &err) {
  f = Zpk();
  if (N == 0)
    return true;
  if (norm != "phase" && norm != "delay" && norm != "mag") {
    err = "norm must be \"phase\", \"delay\" or \"mag\"";
    return false;
  }
  if (N > 25) {
    err = "the Bessel order must be at most 25";
    return false;
  }
  CVec c((size_t)N + 1);
  double v = 1.0;
  c[0] = 1.0;
  for (int k = N - 1; k >= 0; k--) {
    v *= (2.0 * N - k) * (k + 1.0) / (2.0 * (N - k));
    c[(size_t)(N - k)] = v;
  }
  f.p = la::polyRoots(c);
  sortRoots(f.p);
  const double aLast = v;
  if (norm == "phase") {
    const double s = std::pow(10.0, -std::log10(aLast) / N);
    for (cd &q : f.p)
      q *= s;
    f.k = 1.0;
    return true;
  }
  f.k = aLast;
  if (norm == "mag") {
    auto cut = [&](double w) {
      cd h(aLast);
      for (const cd &q : f.p)
        h /= cd(0.0, w) - q;
      return std::abs(h) - std::sqrt(0.5);
    };
    double x0 = 1.5, x1 = 1.5 * (1.0 + 1e-4) + 1e-4, q0 = cut(x0), q1 = cut(x1);
    for (int i = 0; i < 100 && q1 != q0; i++) {
      const double xn = x1 - q1 * (x1 - x0) / (q1 - q0);
      x0 = x1;
      q0 = q1;
      x1 = xn;
      q1 = cut(x1);
      if (std::fabs(x1 - x0) < 1e-13)
        break;
    }
    for (cd &q : f.p)
      q /= x1;
    f.k = std::pow(x1, -N) * aLast;
  }
  return true;
}

// ---- frequency transforms ----
Zpk lpToLp(const Zpk &f, double wo) {
  Zpk o = f;
  for (cd &v : o.z)
    v *= wo;
  for (cd &v : o.p)
    v *= wo;
  o.k = f.k * std::pow(wo, (double)(f.p.size() - f.z.size()));
  return o;
}
cd prodNeg(const CVec &v) {
  cd s(1.0);
  for (const cd &x : v)
    s *= -x;
  return s;
}
Zpk lpToHp(const Zpk &f, double wo) {
  Zpk o;
  for (const cd &v : f.z)
    o.z.push_back(wo / v);
  for (const cd &v : f.p)
    o.p.push_back(wo / v);
  o.z.insert(o.z.end(), f.p.size() - f.z.size(), cd(0.0));
  o.k = f.k * (prodNeg(f.z) / prodNeg(f.p)).real();
  return o;
}
Zpk lpToBp(const Zpk &f, double wo, double bw) {
  Zpk o;
  auto spread = [&](const CVec &in, CVec &out) {
    CVec lo;
    for (const cd &v : in)
      lo.push_back(v * bw / 2.0);
    for (const cd &v : lo)
      out.push_back(v + std::sqrt(v * v - wo * wo));
    for (const cd &v : lo)
      out.push_back(v - std::sqrt(v * v - wo * wo));
  };
  spread(f.z, o.z);
  spread(f.p, o.p);
  o.z.insert(o.z.end(), f.p.size() - f.z.size(), cd(0.0));
  o.k = f.k * std::pow(bw, (double)(f.p.size() - f.z.size()));
  return o;
}
Zpk lpToBs(const Zpk &f, double wo, double bw) {
  Zpk o;
  auto spread = [&](const CVec &in, CVec &out) {
    CVec hi;
    for (const cd &v : in)
      hi.push_back((bw / 2.0) / v);
    for (const cd &v : hi)
      out.push_back(v + std::sqrt(v * v - wo * wo));
    for (const cd &v : hi)
      out.push_back(v - std::sqrt(v * v - wo * wo));
  };
  spread(f.z, o.z);
  spread(f.p, o.p);
  const size_t deg = f.p.size() - f.z.size();
  o.z.insert(o.z.end(), deg, cd(0.0, wo));
  o.z.insert(o.z.end(), deg, cd(0.0, -wo));
  o.k = f.k * (prodNeg(f.z) / prodNeg(f.p)).real();
  return o;
}
Zpk bilinearZpk(const Zpk &f, double fs) {
  const double fs2 = 2.0 * fs;
  Zpk o;
  cd num(1.0), den(1.0);
  for (const cd &v : f.z) {
    o.z.push_back((fs2 + v) / (fs2 - v));
    num *= fs2 - v;
  }
  for (const cd &v : f.p) {
    o.p.push_back((fs2 + v) / (fs2 - v));
    den *= fs2 - v;
  }
  o.z.insert(o.z.end(), f.p.size() - f.z.size(), cd(-1.0));
  o.k = f.k * (num / den).real();
  return o;
}

// sum c_i P^i Q^(M-i), the substitution s -> P/Q in a polynomial of degree up to M.
Vec substitute(const Vec &c, size_t M, const Vec &P, const Vec &Q) {
  Vec out{0.0};
  const size_t N = c.size() - 1;
  auto powOf = [](const Vec &x, size_t e) {
    Vec r{1.0};
    for (size_t i = 0; i < e; i++)
      r = polyMul(r, x);
    return r;
  };
  for (size_t i = 0; i <= N; i++) {
    Vec t = polyMul(powOf(P, i), powOf(Q, M - i));
    for (double &v : t)
      v *= c[N - i];
    if (t.size() > out.size())
      out.insert(out.begin(), t.size() - out.size(), 0.0);
    for (size_t j = 0; j < t.size(); j++)
      out[out.size() - t.size() + j] += t[j];
  }
  return out;
}
bool tfSubstitute(Vec b, Vec a, const Vec &P, const Vec &Q, Value &out, CallContext &ctx) {
  const size_t M = std::max(b.size(), a.size()) - 1;
  Vec nb = substitute(b, M, P, Q), na = substitute(a, M, P, Q);
  std::string err;
  if (!normalizeTf(nb, na, err)) {
    ctx.fail(err);
    return false;
  }
  out = tfDict(nb, na);
  return true;
}

bool getZpk(const Args &a, size_t i, CallContext &ctx, Zpk &f) {
  if (!getCVec(a, i, ctx, f.z) || !getCVec(a, i + 1, ctx, f.p))
    return false;
  if (!isNumberArg(a, i + 2)) {
    ctx.fail("the " + ordinal(i + 2) + " argument must be the gain, a number");
    return false;
  }
  f.k = a[i + 2].number;
  if (f.z.size() > f.p.size()) {
    ctx.fail("the system must not have more zeros than poles");
    return false;
  }
  return true;
}

std::string bandType(std::string s, const Vec &wn, bool given) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (!given)
    return wn.size() == 2 ? "bandpass" : "lowpass";
  if (s == "low" || s == "lowpass" || s == "lp" || s == "l")
    return "lowpass";
  if (s == "high" || s == "highpass" || s == "hp" || s == "h")
    return "highpass";
  if (s == "bandpass" || s == "band" || s == "pass" || s == "bp")
    return "bandpass";
  if (s == "bandstop" || s == "stop" || s == "bs")
    return "bandstop";
  return "";
}

Value finishFilter(const Zpk &f, const std::string &output, CallContext &ctx) {
  if (output == "zpk")
    return zpkDict(f);
  if (output == "sos") {
    Mat s;
    std::string err;
    if (!zpk2sos(f, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(s);
  }
  if (output != "ba") {
    ctx.fail("output must be \"ba\", \"zpk\" or \"sos\"");
    return Value(0.0);
  }
  Vec b, a;
  zpk2tf(f, b, a);
  return tfDict(b, a);
}

// n, Wn, btype, output, fs at the given positions.
Value namedFilter(const Args &a, CallContext &ctx, const std::string &ftype, size_t iWn, double rp, double rs, const std::string &norm, size_t iOutput) {
  if (!isNumberArg(a, 0) || a[0].number < 0 || a[0].number != std::floor(a[0].number)) {
    ctx.fail("the order must be a whole number, 0 or more");
    return Value(0.0);
  }
  Vec wn;
  if (!getVec(a, iWn, ctx, wn))
    return Value(0.0);
  const bool has = iWn + 1 < a.size() && a[iWn + 1].isText;
  const std::string bt = bandType(has ? a[iWn + 1].text() : "", wn, has);
  if (bt.empty()) {
    ctx.fail("btype must be \"low\", \"high\", \"bandpass\" or \"bandstop\"");
    return Value(0.0);
  }
  const std::string output = optText(a, iOutput, "ba");
  const double fs = optNum(a, iOutput + 1, 0.0);
  Zpk f;
  std::string err;
  if (!iirDesign((int)a[0].number, wn, bt, ftype, rp, rs, norm, fs, f, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  return finishFilter(f, output, ctx);
}

// ---- order estimates ----
double bandStopObj(double wp, size_t ind, const Vec &passb, const Vec &stopb, double gpass, double gstop, const std::string &type, bool &ok) {
  Vec pb = passb;
  pb[ind] = wp;
  double nat = kInf;
  for (double s : stopb)
    nat = std::min(nat, std::fabs(s * (pb[0] - pb[1]) / (s * s - pb[0] * pb[1])));
  const double GS = std::pow(10.0, 0.1 * std::fabs(gstop)), GP = std::pow(10.0, 0.1 * std::fabs(gpass));
  ok = true;
  if (type == "butter")
    return std::log10((GS - 1.0) / (GP - 1.0)) / (2.0 * std::log10(nat));
  if (type == "cheby")
    return std::acosh(std::sqrt((GS - 1.0) / (GP - 1.0))) / std::acosh(nat);
  if (type == "ellip") {
    const double arg1 = std::sqrt((GP - 1.0) / (GS - 1.0)), arg0 = 1.0 / nat;
    return ellipK(arg0 * arg0) * ellipK(1.0 - arg1 * arg1) / (ellipK(1.0 - arg0 * arg0) * ellipK(arg1 * arg1));
  }
  ok = false;
  return kNaN;
}

// scipy's bounded Brent (fminbound).
double fminbound(const std::function<double(double)> &f, double a, double b) {
  const double xatol = 1e-5, se = std::sqrt(2.2e-16), gm = 0.5 * (3.0 - std::sqrt(5.0));
  double fulc = a + gm * (b - a), nfc = fulc, xf = fulc, rat = 0.0, e = 0.0, x = xf;
  double fx = f(x), ffulc = fx, fnfc = fx, xm = 0.5 * (a + b), tol1 = se * std::fabs(xf) + xatol / 3.0, tol2 = 2.0 * tol1;
  for (int it = 0; it < 500 && std::fabs(xf - xm) > tol2 - 0.5 * (b - a); it++) {
    bool golden = true;
    if (std::fabs(e) > tol1) {
      golden = false;
      double r = (xf - nfc) * (fx - ffulc), q = (xf - fulc) * (fx - fnfc), p = (xf - fulc) * q - (xf - nfc) * r;
      q = 2.0 * (q - r);
      if (q > 0.0)
        p = -p;
      q = std::fabs(q);
      r = e;
      e = rat;
      if (std::fabs(p) < std::fabs(0.5 * q * r) && p > q * (a - xf) && p < q * (b - xf)) {
        rat = p / q;
        x = xf + rat;
        if (x - a < tol2 || b - x < tol2)
          rat = tol1 * (xm - xf >= 0.0 ? 1.0 : -1.0);
      } else {
        golden = true;
      }
    }
    if (golden) {
      e = xf >= xm ? a - xf : b - xf;
      rat = gm * e;
    }
    x = xf + (rat >= 0.0 ? 1.0 : -1.0) * std::max(std::fabs(rat), tol1);
    const double fu = f(x);
    if (fu <= fx) {
      if (x >= xf)
        a = xf;
      else
        b = xf;
      fulc = nfc;
      ffulc = fnfc;
      nfc = xf;
      fnfc = fx;
      xf = x;
      fx = fu;
    } else {
      if (x < xf)
        a = x;
      else
        b = x;
      if (fu <= fnfc || nfc == xf) {
        fulc = nfc;
        ffulc = fnfc;
        nfc = x;
        fnfc = fu;
      } else if (fu <= ffulc || fulc == xf || fulc == nfc) {
        fulc = x;
        ffulc = fu;
      }
    }
    xm = 0.5 * (a + b);
    tol1 = se * std::fabs(xf) + xatol / 3.0;
    tol2 = 2.0 * tol1;
  }
  return xf;
}

struct OrderIn {
  Vec wp, ws, passb, stopb;
  int type = 1; // 1 low, 2 high, 3 stop, 4 pass
  double gpass = 0, gstop = 0, fs = 0, nat = 0;
};

bool orderInputs(const Args &a, CallContext &ctx, OrderIn &o, const std::string &kind, size_t iFs) {
  if (!getVec(a, 0, ctx, o.wp) || !getVec(a, 1, ctx, o.ws))
    return false;
  if (o.wp.size() != o.ws.size() || (o.wp.size() != 1 && o.wp.size() != 2)) {
    ctx.fail("wp and ws must both be one edge, or both two edges");
    return false;
  }
  o.gpass = a[2].number;
  o.gstop = a[3].number;
  if (o.gpass <= 0.0 || o.gpass > o.gstop) {
    ctx.fail("gpass must be positive and no larger than gstop");
    return false;
  }
  o.fs = optNum(a, iFs, 0.0);
  if (o.fs > 0.0) {
    for (double &v : o.wp)
      v = 2.0 * v / o.fs;
    for (double &v : o.ws)
      v = 2.0 * v / o.fs;
  }
  o.type = 2 * ((int)o.wp.size() - 1) + 1;
  if (o.wp[0] >= o.ws[0])
    o.type += 1;
  o.passb = o.wp;
  o.stopb = o.ws;
  for (double &v : o.passb)
    v = std::tan(kPi * v / 2.0);
  for (double &v : o.stopb)
    v = std::tan(kPi * v / 2.0);
  Vec nat;
  if (o.type == 1)
    nat = {o.stopb[0] / o.passb[0]};
  else if (o.type == 2)
    nat = {o.passb[0] / o.stopb[0]};
  else if (o.type == 3) {
    bool ok;
    Vec pb = o.passb;
    const double w0 = fminbound([&](double w) { return bandStopObj(w, 0, pb, o.stopb, o.gpass, o.gstop, kind, ok); }, pb[0], o.stopb[0] - 1e-12);
    pb[0] = w0;
    const double w1 = fminbound([&](double w) { return bandStopObj(w, 1, pb, o.stopb, o.gpass, o.gstop, kind, ok); }, o.stopb[1] + 1e-12, pb[1]);
    pb[1] = w1;
    o.passb = pb;
    for (double s : o.stopb)
      nat.push_back(s * (pb[0] - pb[1]) / (s * s - pb[0] * pb[1]));
  } else {
    for (double s : o.stopb)
      nat.push_back((s * s - o.passb[0] * o.passb[1]) / (s * (o.passb[0] - o.passb[1])));
  }
  o.nat = kInf;
  for (double v : nat)
    o.nat = std::min(o.nat, std::fabs(v));
  return true;
}

Value orderResult(int N, Vec WN, const OrderIn &o) {
  for (double &v : WN) {
    v = std::atan(v) * 2.0 / kPi;
    if (o.fs > 0.0)
      v = v * o.fs / 2.0;
  }
  return makeDict({{"N", Value((double)N)}, {"Wn", WN.size() == 1 ? Value(WN[0]) : toValue(WN)}});
}

bool buttord(OrderIn &o, int &N, Vec &WN) {
  const double GS = std::pow(10.0, 0.1 * std::fabs(o.gstop)), GP = std::pow(10.0, 0.1 * std::fabs(o.gpass));
  N = (int)std::ceil(std::log10((GS - 1.0) / (GP - 1.0)) / (2.0 * std::log10(o.nat)));
  const double W0 = std::pow(GP - 1.0, -1.0 / (2.0 * N));
  const Vec &pb = o.passb;
  if (o.type == 1)
    WN = {W0 * pb[0]};
  else if (o.type == 2)
    WN = {pb[0] / W0};
  else if (o.type == 3) {
    const double disc = std::sqrt((pb[1] - pb[0]) * (pb[1] - pb[0]) + 4.0 * W0 * W0 * pb[0] * pb[1]);
    WN = {std::fabs(((pb[1] - pb[0]) + disc) / (2.0 * W0)), std::fabs(((pb[1] - pb[0]) - disc) / (2.0 * W0))};
    std::sort(WN.begin(), WN.end());
  } else {
    WN.clear();
    for (double w : {-W0, W0})
      WN.push_back(std::fabs(-w * (pb[1] - pb[0]) / 2.0 + std::sqrt(w * w / 4.0 * (pb[1] - pb[0]) * (pb[1] - pb[0]) + pb[0] * pb[1])));
    std::sort(WN.begin(), WN.end());
  }
  return true;
}
bool cheb1ord(OrderIn &o, int &N, Vec &WN) {
  const double GS = std::pow(10.0, 0.1 * std::fabs(o.gstop)), GP = std::pow(10.0, 0.1 * std::fabs(o.gpass));
  N = (int)std::ceil(std::acosh(std::sqrt((GS - 1.0) / (GP - 1.0))) / std::acosh(o.nat));
  WN = o.passb;
  return true;
}
bool cheb2ord(OrderIn &o, int &N, Vec &WN) {
  const double GS = std::pow(10.0, 0.1 * std::fabs(o.gstop)), GP = std::pow(10.0, 0.1 * std::fabs(o.gpass));
  const double vps = std::acosh(std::sqrt((GS - 1.0) / (GP - 1.0)));
  N = (int)std::ceil(vps / std::acosh(o.nat));
  const double nf = 1.0 / std::cosh(vps / N);
  const Vec &pb = o.passb;
  if (o.type == 1)
    WN = {pb[0] / nf};
  else if (o.type == 2)
    WN = {pb[0] * nf};
  else if (o.type == 3) {
    const double n0 = nf / 2.0 * (pb[0] - pb[1]) + std::sqrt(nf * nf * (pb[1] - pb[0]) * (pb[1] - pb[0]) / 4.0 + pb[1] * pb[0]);
    WN = {n0, pb[1] * pb[0] / n0};
  } else {
    const double n0 = 1.0 / (2.0 * nf) * (pb[0] - pb[1]) + std::sqrt((pb[1] - pb[0]) * (pb[1] - pb[0]) / (4.0 * nf * nf) + pb[1] * pb[0]);
    WN = {n0, pb[0] * pb[1] / n0};
  }
  return true;
}
bool ellipord(OrderIn &o, int &N, Vec &WN) {
  const double GS = std::pow(10.0, 0.1 * std::fabs(o.gstop)), GP = std::pow(10.0, 0.1 * std::fabs(o.gpass));
  const double arg1 = std::sqrt((GS - 1.0) / (GP - 1.0)), arg0 = 1.0 / o.nat;
  N = (int)std::ceil(ellipK(arg0 * arg0) * ellipKm1(1.0 / (arg1 * arg1)) / (ellipKm1(arg0 * arg0) * ellipK(1.0 / (arg1 * arg1))));
  WN = o.passb;
  return true;
}

// ---- partial fractions ----
void polyDivC(const CVec &u, const CVec &v, CVec &q, CVec &r) {
  const size_t m = u.size() - 1, n = v.size() - 1;
  const cd scale = 1.0 / v[0];
  r = u;
  q.assign(m >= n ? m - n + 1 : 1, cd(0.0));
  if (m >= n)
    for (size_t k = 0; k <= m - n; k++) {
      const cd d = scale * r[k];
      q[k] = d;
      for (size_t i = 0; i <= n; i++)
        r[k + i] -= d * v[i];
    }
  size_t lead = 0;
  while (lead + 1 < r.size() && std::abs(r[lead]) <= 1e-8)
    lead++;
  r.erase(r.begin(), r.begin() + (long)lead);
}

void computeFactors(const CVec &roots, const std::vector<int> &mult, bool includePowers, std::vector<CVec> &factors, CVec &whole) {
  CVec current{cd(1.0)};
  std::vector<CVec> suffixes{current};
  for (size_t i = roots.size(); i-- > 1;) {
    const CVec mono{cd(1.0), -roots[i]};
    for (int k = 0; k < mult[i]; k++)
      current = polyMulC(current, mono);
    suffixes.push_back(current);
  }
  std::reverse(suffixes.begin(), suffixes.end());
  factors.clear();
  current = CVec{cd(1.0)};
  for (size_t i = 0; i < roots.size(); i++) {
    const CVec mono{cd(1.0), -roots[i]};
    std::vector<CVec> block;
    for (int k = 0; k < mult[i]; k++) {
      if (k == 0 || includePowers)
        block.push_back(polyMulC(current, suffixes[i]));
      current = polyMulC(current, mono);
    }
    factors.insert(factors.end(), block.rbegin(), block.rend());
  }
  whole = current;
}

CVec computeResidues(const CVec &poles, const std::vector<int> &mult, const CVec &numerator) {
  std::vector<CVec> denom;
  CVec whole;
  computeFactors(poles, mult, false, denom, whole);
  CVec res;
  for (size_t i = 0; i < poles.size(); i++) {
    CVec factor = denom[i];
    if (mult[i] == 1) {
      res.push_back(polyval(numerator, poles[i]) / polyval(factor, poles[i]));
      continue;
    }
    CVec numer = numerator, q, d;
    const CVec mono{cd(1.0), -poles[i]};
    polyDivC(factor, mono, q, d);
    factor = q;
    const cd dv = d[0];
    CVec block;
    for (int k = 0; k < mult[i]; k++) {
      CVec nq, nr;
      polyDivC(numer, mono, nq, nr);
      const cd r = nr[0] / dv;
      CVec sc = factor;
      for (cd &v : sc)
        v *= -r;
      numer = polyAddC(nq, sc);
      block.push_back(r);
    }
    res.insert(res.end(), block.rbegin(), block.rend());
  }
  return res;
}

cd reduceGroup(const CVec &g, const std::string &rtype) {
  if (rtype == "avg" || rtype == "mean") {
    cd s(0.0);
    for (const cd &v : g)
      s += v;
    return s / (double)g.size();
  }
  auto less = [](const cd &x, const cd &y) { return x.real() != y.real() ? x.real() < y.real() : x.imag() < y.imag(); };
  return rtype == "max" || rtype == "maximum" ? *std::max_element(g.begin(), g.end(), less) : *std::min_element(g.begin(), g.end(), less);
}

void uniqueRoots(const CVec &p, double tol, const std::string &rtype, CVec &uniq, std::vector<int> &mult) {
  std::vector<char> used(p.size(), 0);
  for (size_t i = 0; i < p.size(); i++) {
    if (used[i])
      continue;
    if (!std::isfinite(p[i].real()) || !std::isfinite(p[i].imag())) {
      used[i] = 1;
      uniq.push_back(p[i]);
      mult.push_back(1);
      continue;
    }
    CVec g;
    for (size_t j = 0; j < p.size(); j++)
      if (!used[j] && std::abs(p[j] - p[i]) <= tol) {
        g.push_back(p[j]);
        used[j] = 1;
      }
    uniq.push_back(reduceGroup(g, rtype));
    mult.push_back((int)g.size());
  }
}
void groupPoles(const CVec &p, double tol, const std::string &rtype, CVec &uniq, std::vector<int> &mult) {
  if (p.empty())
    return;
  cd pole = p[0];
  CVec block{pole};
  for (size_t i = 1; i < p.size(); i++) {
    if (std::abs(p[i] - pole) <= tol) {
      block.push_back(pole);
    } else {
      uniq.push_back(reduceGroup(block, rtype));
      mult.push_back((int)block.size());
      pole = p[i];
      block = CVec{pole};
    }
  }
  uniq.push_back(reduceGroup(block, rtype));
  mult.push_back((int)block.size());
}
void sortByAbs(CVec &poles, std::vector<int> &mult) {
  std::vector<size_t> o(poles.size());
  for (size_t i = 0; i < o.size(); i++)
    o[i] = i;
  std::stable_sort(o.begin(), o.end(), [&](size_t x, size_t y) { return std::abs(poles[x]) < std::abs(poles[y]); });
  CVec p2;
  std::vector<int> m2;
  for (size_t i : o) {
    p2.push_back(poles[i]);
    m2.push_back(mult[i]);
  }
  poles = p2;
  mult = m2;
}
CVec trimFront(CVec v) {
  size_t i = 0;
  while (i < v.size() && v[i] == cd(0.0))
    i++;
  v.erase(v.begin(), v.begin() + (long)i);
  return v;
}
CVec trimBack(CVec v) {
  while (!v.empty() && v.back() == cd(0.0))
    v.pop_back();
  return v;
}

Value residueDict(const CVec &r, const CVec &p, const CVec &k) {
  auto cleaned = [](CVec v) {
    double m = 0.0;
    for (const cd &x : v)
      m = std::max(m, std::abs(x));
    for (cd &x : v)
      if (std::fabs(x.imag()) <= 1e-12 * m)
        x = cd(x.real(), 0.0);
    return v;
  };
  return makeDict({{"r", realIfPossible(cleaned(r))}, {"p", realIfPossible(cleaned(p))}, {"k", realIfPossible(cleaned(k))}});
}

} // namespace

namespace sg {

bool iirDesign(int N, const Vec &wnIn, const std::string &btype, const std::string &ftype, double rp, double rs,
               const std::string &norm, double fs, Zpk &out, std::string &err) {
  Vec wn = wnIn;
  if (fs > 0.0)
    for (double &v : wn)
      v = 2.0 * v / fs;
  for (double v : wn)
    if (v <= 0.0 || v >= 1.0) {
      err = "the critical frequencies must be between 0 and 1 (1 is Nyquist), or between 0 and fs/2";
      return false;
    }
  const bool band = btype == "bandpass" || btype == "bandstop";
  if (wn.size() != (band ? 2u : 1u)) {
    err = band ? "a band filter needs Wn = [low, high]" : "a low or high pass filter needs one Wn";
    return false;
  }
  if (band && wn[0] >= wn[1]) {
    err = "Wn must be increasing: [low, high]";
    return false;
  }
  Zpk proto;
  if (ftype == "butter")
    proto = buttap(N);
  else if (ftype == "cheby1") {
    if (!(rp > 0.0)) {
      err = "cheby1 needs the pass-band ripple rp, in dB";
      return false;
    }
    proto = cheb1ap(N, rp);
  } else if (ftype == "cheby2") {
    if (!(rs > 0.0)) {
      err = "cheby2 needs the stop-band attenuation rs, in dB";
      return false;
    }
    proto = cheb2ap(N, rs);
  } else if (ftype == "ellip") {
    if (!(rp > 0.0) || !(rs > 0.0)) {
      err = "ellip needs rp and rs, in dB";
      return false;
    }
    if (!ellipap(N, rp, rs, proto, err))
      return false;
  } else if (ftype == "bessel") {
    if (!besselap(N, norm.empty() ? "phase" : norm, proto, err))
      return false;
  } else {
    err = "ftype must be \"butter\", \"cheby1\", \"cheby2\", \"ellip\" or \"bessel\"";
    return false;
  }
  Vec warped(wn.size());
  for (size_t i = 0; i < wn.size(); i++)
    warped[i] = 4.0 * std::tan(kPi * wn[i] / 2.0);
  if (btype == "lowpass")
    proto = lpToLp(proto, warped[0]);
  else if (btype == "highpass")
    proto = lpToHp(proto, warped[0]);
  else {
    const double bw = warped[1] - warped[0], wo = std::sqrt(warped[0] * warped[1]);
    proto = btype == "bandpass" ? lpToBp(proto, wo, bw) : lpToBs(proto, wo, bw);
  }
  out = bilinearZpk(proto, 2.0);
  return true;
}

} // namespace sg

void registerSgDesign(Registry &reg) {
  // ---- prototypes ----
  SP_ADD("butter_proto", 1, 1, "n") {
    (void)ctx;
    return zpkDict(buttap((int)optInt(a, 0, 1)));
  } SP_END
  SP_ADD("cheby1_proto", 2, 2, "n, rp") {
    (void)ctx;
    return zpkDict(cheb1ap((int)optInt(a, 0, 1), optNum(a, 1, 1.0)));
  } SP_END
  SP_ADD("cheby2_proto", 2, 2, "n, rs") {
    (void)ctx;
    return zpkDict(cheb2ap((int)optInt(a, 0, 1), optNum(a, 1, 40.0)));
  } SP_END
  SP_ADD("ellip_proto", 3, 3, "n, rp, rs") {
    Zpk f;
    std::string err;
    if (!ellipap((int)optInt(a, 0, 1), optNum(a, 1, 1.0), optNum(a, 2, 40.0), f, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return zpkDict(f);
  } SP_END
  SP_ADD("bessel_proto", 1, 2, "n, norm=\"phase\"") {
    Zpk f;
    std::string err;
    if (!besselap((int)optInt(a, 0, 1), optText(a, 1, "phase"), f, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return zpkDict(f);
  } SP_END
  // ---- frequency transforms ----
#define SG_TF_ARGS                                                                                 \
  Vec b, ca;                                                                                       \
  if (!getVec(a, 0, ctx, b) || !getVec(a, 1, ctx, ca))                                             \
    return Value(0.0);
  SP_ADD("lp2lp", 2, 3, "b, a, wo=1") {
    SG_TF_ARGS
    Value o;
    tfSubstitute(b, ca, {1.0 / optNum(a, 2, 1.0), 0.0}, {1.0}, o, ctx);
    return o;
  } SP_END
  SP_ADD("lp2hp", 2, 3, "b, a, wo=1") {
    SG_TF_ARGS
    Value o;
    tfSubstitute(b, ca, {optNum(a, 2, 1.0)}, {1.0, 0.0}, o, ctx);
    return o;
  } SP_END
  SP_ADD("lp2bp", 2, 4, "b, a, wo=1, bw=1") {
    SG_TF_ARGS
    const double wo = optNum(a, 2, 1.0), bw = optNum(a, 3, 1.0);
    Value o;
    tfSubstitute(b, ca, {1.0, 0.0, wo * wo}, {bw, 0.0}, o, ctx);
    return o;
  } SP_END
  SP_ADD("lp2bs", 2, 4, "b, a, wo=1, bw=1") {
    SG_TF_ARGS
    const double wo = optNum(a, 2, 1.0), bw = optNum(a, 3, 1.0);
    Value o;
    tfSubstitute(b, ca, {bw, 0.0}, {1.0, 0.0, wo * wo}, o, ctx);
    return o;
  } SP_END
  SP_ADD("bilinear", 2, 3, "b, a, fs=1") {
    SG_TF_ARGS
    const double f2 = 2.0 * optNum(a, 2, 1.0);
    Value o;
    tfSubstitute(b, ca, {f2, -f2}, {1.0, 1.0}, o, ctx);
    return o;
  } SP_END
  SP_ADD("lp2lp_zpk", 3, 4, "z, p, k, wo=1") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    return zpkDict(lpToLp(f, optNum(a, 3, 1.0)));
  } SP_ENDC
  SP_ADD("lp2hp_zpk", 3, 4, "z, p, k, wo=1") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    return zpkDict(lpToHp(f, optNum(a, 3, 1.0)));
  } SP_ENDC
  SP_ADD("lp2bp_zpk", 3, 5, "z, p, k, wo=1, bw=1") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    return zpkDict(lpToBp(f, optNum(a, 3, 1.0), optNum(a, 4, 1.0)));
  } SP_ENDC
  SP_ADD("lp2bs_zpk", 3, 5, "z, p, k, wo=1, bw=1") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    return zpkDict(lpToBs(f, optNum(a, 3, 1.0), optNum(a, 4, 1.0)));
  } SP_ENDC
  SP_ADD("bilinear_zpk", 4, 4, "z, p, k, fs") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    return zpkDict(bilinearZpk(f, optNum(a, 3, 1.0)));
  } SP_ENDC
  SP_ADD("tf_normalize", 2, 2, "b, a") {
    SG_TF_ARGS
    std::string err;
    if (!normalizeTf(b, ca, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return tfDict(b, ca);
  } SP_END
  // ---- the classical filters ----
  SP_ADD("butter", 2, 5, "n, Wn, btype=\"low\", output=\"ba\", fs") { return namedFilter(a, ctx, "butter", 1, 0, 0, "", 3); } SP_END
  SP_ADD("cheby1", 3, 6, "n, rp, Wn, btype=\"low\", output=\"ba\", fs") { return namedFilter(a, ctx, "cheby1", 2, optNum(a, 1, 0), 0, "", 4); } SP_END
  SP_ADD("cheby2", 3, 6, "n, rs, Wn, btype=\"low\", output=\"ba\", fs") { return namedFilter(a, ctx, "cheby2", 2, 0, optNum(a, 1, 0), "", 4); } SP_END
  SP_ADD("ellip", 4, 7, "n, rp, rs, Wn, btype=\"low\", output=\"ba\", fs") { return namedFilter(a, ctx, "ellip", 3, optNum(a, 1, 0), optNum(a, 2, 0), "", 5); } SP_END
  SP_ADD("bessel", 2, 6, "n, Wn, btype=\"low\", norm=\"phase\", output=\"ba\", fs") { return namedFilter(a, ctx, "bessel", 1, 0, 0, optText(a, 3, "phase"), 4); } SP_END
  SP_ADD("iir_filter", 3, 8, "n, Wn, btype, ftype=\"butter\", rp, rs, output=\"ba\", fs") {
    return namedFilter(a, ctx, optText(a, 3, "butter"), 1, optNum(a, 4, 0), optNum(a, 5, 0), "phase", 6);
  } SP_END
  SP_ADD("iir_design", 4, 7, "wp, ws, gpass, gstop, ftype=\"ellip\", output=\"ba\", fs") {
    std::string ftype = optText(a, 4, "ellip");
    const bool isCheb2 = ftype == "cheby2", isCheb1 = ftype == "cheby1", isEll = ftype == "ellip", isBut = ftype == "butter";
    if (!isCheb2 && !isCheb1 && !isEll && !isBut) {
      ctx.fail("ftype must be \"butter\", \"cheby1\", \"cheby2\" or \"ellip\"");
      return Value(0.0);
    }
    OrderIn o;
    if (!orderInputs(a, ctx, o, isEll ? "ellip" : (isBut ? "butter" : "cheby"), 6))
      return Value(0.0);
    int N = 0;
    Vec WN;
    if (isBut)
      buttord(o, N, WN);
    else if (isCheb1)
      cheb1ord(o, N, WN);
    else if (isCheb2)
      cheb2ord(o, N, WN);
    else
      ellipord(o, N, WN);
    for (double &v : WN)
      v = std::atan(v) * 2.0 / kPi;
    static const char *bands[] = {"lowpass", "highpass", "bandstop", "bandpass"};
    Zpk f;
    std::string err;
    if (!iirDesign(N, WN, bands[o.type - 1], ftype, o.gpass, o.gstop, "", 0.0, f, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return finishFilter(f, optText(a, 5, "ba"), ctx);
  } SP_END
#define SG_ORDER(NAME, KIND, FN)                                                                   \
  SP_ADD(NAME, 4, 5, "wp, ws, gpass, gstop, fs") {                                                 \
    OrderIn o;                                                                                     \
    if (!orderInputs(a, ctx, o, KIND, 4))                                                          \
      return Value(0.0);                                                                           \
    int N = 0;                                                                                     \
    Vec WN;                                                                                        \
    FN(o, N, WN);                                                                                  \
    return orderResult(N, WN, o);                                                                  \
  } SP_END
  SG_ORDER("butter_order", "butter", buttord)
  SG_ORDER("cheby1_order", "cheby", cheb1ord)
  SG_ORDER("cheby2_order", "cheby", cheb2ord)
  SG_ORDER("ellip_order", "ellip", ellipord)
  SP_ADD("band_stop_obj", 7, 7, "wp, ind, passb, stopb, gpass, gstop, type") {
    Vec pb, sb;
    if (!getVec(a, 2, ctx, pb) || !getVec(a, 3, ctx, sb))
      return Value(0.0);
    const long long ind = optInt(a, 1, 0);
    if (pb.size() != 2 || sb.size() != 2 || (ind != 0 && ind != 1)) {
      ctx.fail("passb and stopb need two edges each, and ind must be 0 or 1");
      return Value(0.0);
    }
    bool ok;
    const double v = bandStopObj(optNum(a, 0, 0), (size_t)ind, pb, sb, optNum(a, 4, 0), optNum(a, 5, 0), optText(a, 6, ""), ok);
    if (!ok) {
      ctx.fail("type must be \"butter\", \"cheby\" or \"ellip\"");
      return Value(0.0);
    }
    return Value(v);
  } SP_END
  SP_ADD("iir_notch", 2, 3, "w0, Q, fs=2") {
    const double fs = optNum(a, 2, 2.0), w0n = 2.0 * optNum(a, 0, 0) / fs, Q = optNum(a, 1, 1);
    if (w0n <= 0.0 || w0n >= 1.0) {
      ctx.fail("w0 must be between 0 and fs/2");
      return Value(0.0);
    }
    const double bw = kPi * w0n / Q, w0 = kPi * w0n, gb = std::sqrt(0.5);
    const double beta = (std::sqrt(1.0 - gb * gb) / gb) * std::tan(bw / 2.0), gain = 1.0 / (1.0 + beta);
    return tfDict({gain, -2.0 * gain * std::cos(w0), gain}, {1.0, -2.0 * gain * std::cos(w0), 2.0 * gain - 1.0});
  } SP_END
  SP_ADD("iir_peak", 2, 3, "w0, Q, fs=2") {
    const double fs = optNum(a, 2, 2.0), w0n = 2.0 * optNum(a, 0, 0) / fs, Q = optNum(a, 1, 1);
    if (w0n <= 0.0 || w0n >= 1.0) {
      ctx.fail("w0 must be between 0 and fs/2");
      return Value(0.0);
    }
    const double bw = kPi * w0n / Q, w0 = kPi * w0n, gb = std::sqrt(0.5);
    const double beta = (gb / std::sqrt(1.0 - gb * gb)) * std::tan(bw / 2.0), gain = 1.0 / (1.0 + beta);
    return tfDict({1.0 - gain, 0.0, -(1.0 - gain)}, {1.0, -2.0 * gain * std::cos(w0), 2.0 * gain - 1.0});
  } SP_END
  SP_ADD("iir_comb", 2, 5, "w0, Q, ftype=\"notch\", fs=2, pass_zero=0") {
    const double w0in = optNum(a, 0, 0), Q = optNum(a, 1, 1), fs = optNum(a, 3, 2.0);
    const std::string ftype = optText(a, 2, "notch");
    const bool passZero = optBool(a, 4, false);
    if (!(w0in > 0.0 && w0in < fs / 2.0)) {
      ctx.fail("w0 must be between 0 and fs/2");
      return Value(0.0);
    }
    if (ftype != "notch" && ftype != "peak") {
      ctx.fail("ftype must be \"notch\" or \"peak\"");
      return Value(0.0);
    }
    const size_t N = (size_t)std::round(fs / w0in);
    if (std::fabs(w0in - fs / (double)N) / fs > 1e-14) {
      ctx.fail("fs must be a whole multiple of w0");
      return Value(0.0);
    }
    const double w0 = 2.0 * kPi * w0in / fs, wd = w0 / Q;
    const double G0 = ftype == "notch" ? 1.0 : 0.0, G = ftype == "notch" ? 0.0 : 1.0, beta = std::tan((double)N * wd / 4.0);
    const double ax = (1.0 - beta) / (1.0 + beta), bx = (G0 + G * beta) / (1.0 + beta), cx = (G0 - G * beta) / (1.0 + beta);
    const bool neg = (ftype == "peak" && passZero) || (ftype == "notch" && !passZero);
    Vec b(N + 1, 0.0), ca(N + 1, 0.0);
    b[0] = bx;
    b[N] = neg ? -cx : cx;
    ca[0] = 1.0;
    ca[N] = neg ? -ax : ax;
    return tfDict(b, ca);
  } SP_END
  // ---- conversions ----
  SP_ADD("tf2zpk", 2, 2, "b, a") {
    SG_TF_ARGS
    Zpk f;
    std::string err;
    if (!tf2zpk(b, ca, f, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return zpkDict(f);
  } SP_END
  SP_ADD("tf2sos", 2, 2, "b, a") {
    SG_TF_ARGS
    Zpk f;
    Mat s;
    std::string err;
    if (!tf2zpk(b, ca, f, err) || !zpk2sos(f, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(s);
  } SP_END
  SP_ADD("tf2ss", 2, 2, "b, a") {
    SG_TF_ARGS
    Ss s;
    std::string err;
    if (!tf2ss(b, ca, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return ssDict(s);
  } SP_END
  SP_ADD("zpk2tf", 3, 3, "z, p, k") {
    Zpk f;
    if (!getCVec(a, 0, ctx, f.z) || !getCVec(a, 1, ctx, f.p))
      return Value(0.0);
    f.k = optNum(a, 2, 1.0);
    Vec b, ca;
    zpk2tf(f, b, ca);
    return tfDict(b, ca);
  } SP_ENDC
  SP_ADD("zpk2sos", 3, 3, "z, p, k") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    Mat s;
    std::string err;
    if (!zpk2sos(f, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(s);
  } SP_ENDC
  SP_ADD("zpk2ss", 3, 3, "z, p, k") {
    Zpk f;
    if (!getZpk(a, 0, ctx, f))
      return Value(0.0);
    Vec b, ca;
    zpk2tf(f, b, ca);
    Ss s;
    std::string err;
    if (!tf2ss(b, ca, s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return ssDict(s);
  } SP_ENDC
#define SG_SS_ARGS                                                                                 \
  Ss s;                                                                                            \
  if (!getMat(a, 0, ctx, s.A) || !getMat(a, 1, ctx, s.B) || !getMat(a, 2, ctx, s.C) || !getMat(a, 3, ctx, s.D)) \
    return Value(0.0);                                                                             \
  std::string err;                                                                                 \
  if (!abcdNormalize(s, err)) {                                                                    \
    ctx.fail(err);                                                                                 \
    return Value(0.0);                                                                             \
  }
  SP_ADD("ss2tf", 4, 5, "A, B, C, D, input=0") {
    SG_SS_ARGS
    const size_t in = (size_t)optInt(a, 4, 0);
    if (in >= s.B.c) {
      ctx.fail("input must be below the number of inputs");
      return Value(0.0);
    }
    Mat num;
    Vec den;
    ss2tf(s, in, num, den);
    if (num.r == 1)
      return tfDict(Vec(num.a.begin(), num.a.end()), den);
    return makeDict({{"b", toValue(num)}, {"a", toValue(den)}});
  } SP_END
  SP_ADD("ss2zpk", 4, 5, "A, B, C, D, input=0") {
    SG_SS_ARGS
    const size_t in = (size_t)optInt(a, 4, 0);
    if (in >= s.B.c || s.D.r != 1) {
      ctx.fail("one output is needed, and input must be below the number of inputs");
      return Value(0.0);
    }
    Mat num;
    Vec den;
    ss2tf(s, in, num, den);
    Zpk f;
    if (!tf2zpk(Vec(num.a.begin(), num.a.end()), den, f, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return zpkDict(f);
  } SP_END
  SP_ADD("abcd_normalize", 1, 4, "A, B, C, D") {
    Ss s;
    if (!isOmitted(a, 0) && !getMat(a, 0, ctx, s.A))
      return Value(0.0);
    if (!isOmitted(a, 1) && !getMat(a, 1, ctx, s.B))
      return Value(0.0);
    if (!isOmitted(a, 2) && !getMat(a, 2, ctx, s.C))
      return Value(0.0);
    if (a.size() > 3 && !getMat(a, 3, ctx, s.D))
      return Value(0.0);
    std::string err;
    if (!abcdNormalize(s, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return ssDict(s);
  } SP_END
  SP_ADD("sos2zpk", 1, 1, "sos") {
    Mat s;
    if (!getMat(a, 0, ctx, s))
      return Value(0.0);
    if (s.c != 6) {
      ctx.fail("sos must have six columns");
      return Value(0.0);
    }
    return zpkDict(sos2zpk(s));
  } SP_END
  SP_ADD("sos2tf", 1, 1, "sos") {
    Mat s;
    if (!getMat(a, 0, ctx, s))
      return Value(0.0);
    if (s.c != 6) {
      ctx.fail("sos must have six columns");
      return Value(0.0);
    }
    Vec b, ca;
    sos2tf(s, b, ca);
    return tfDict(b, ca);
  } SP_END
  // ---- partial fractions ----
  SP_ADD("unique_roots", 1, 3, "roots, tol=1e-3, rtype=\"min\"") {
    CVec p;
    if (!getCVec(a, 0, ctx, p))
      return Value(0.0);
    CVec u;
    std::vector<int> m;
    uniqueRoots(p, optNum(a, 1, 1e-3), optText(a, 2, "min"), u, m);
    Vec mv(m.begin(), m.end());
    return makeDict({{"roots", realIfPossible(u)}, {"mult", toValue(mv)}});
  } SP_ENDC
  SP_ADD("residue", 2, 4, "b, a, tol=1e-3, rtype=\"avg\"") {
    CVec b, ca;
    if (!getCVec(a, 0, ctx, b) || !getCVec(a, 1, ctx, ca))
      return Value(0.0);
    b = trimFront(b);
    ca = trimFront(ca);
    if (ca.empty()) {
      ctx.fail("the denominator must not be zero");
      return Value(0.0);
    }
    const double tol = optNum(a, 2, 1e-3);
    const std::string rtype = optText(a, 3, "avg");
    CVec poles = la::polyRoots(ca), k;
    if (b.empty()) {
      sortRoots(poles);
      return residueDict(CVec(poles.size(), cd(0.0)), poles, {});
    }
    if (b.size() >= ca.size()) {
      CVec q, r;
      polyDivC(b, ca, q, r);
      k = q;
      b = r;
    }
    CVec u;
    std::vector<int> m;
    uniqueRoots(poles, tol, rtype, u, m);
    sortByAbs(u, m);
    CVec res = computeResidues(u, m, b);
    CVec plist;
    for (size_t i = 0; i < u.size(); i++)
      plist.insert(plist.end(), (size_t)m[i], u[i]);
    for (cd &v : res)
      v /= ca[0];
    return residueDict(res, plist, k);
  } SP_ENDC
  SP_ADD("residuez", 2, 4, "b, a, tol=1e-3, rtype=\"avg\"") {
    CVec b, ca;
    if (!getCVec(a, 0, ctx, b) || !getCVec(a, 1, ctx, ca))
      return Value(0.0);
    b = trimBack(b);
    ca = trimBack(ca);
    if (ca.empty() || ca[0] == cd(0.0)) {
      ctx.fail("the first coefficient of the denominator must not be zero");
      return Value(0.0);
    }
    const double tol = optNum(a, 2, 1e-3);
    const std::string rtype = optText(a, 3, "avg");
    CVec poles = la::polyRoots(ca), kr;
    CVec brev(b.rbegin(), b.rend()), arev(ca.rbegin(), ca.rend());
    if (b.empty()) {
      sortRoots(poles);
      return residueDict(CVec(poles.size(), cd(0.0)), poles, {});
    }
    if (brev.size() >= arev.size()) {
      CVec q, r;
      polyDivC(brev, arev, q, r);
      kr = q;
      brev = r;
    }
    CVec u;
    std::vector<int> m;
    uniqueRoots(poles, tol, rtype, u, m);
    sortByAbs(u, m);
    CVec inv;
    for (const cd &v : u)
      inv.push_back(1.0 / v);
    CVec res = computeResidues(inv, m, brev);
    CVec plist;
    std::vector<int> powers;
    for (size_t i = 0; i < u.size(); i++)
      for (int q = 0; q < m[i]; q++) {
        plist.push_back(u[i]);
        powers.push_back(q + 1);
      }
    for (size_t i = 0; i < res.size(); i++)
      res[i] *= std::pow(-plist[i], powers[i]) / arev[0];
    return residueDict(res, plist, CVec(kr.rbegin(), kr.rend()));
  } SP_ENDC
  SP_ADD("invres", 2, 5, "r, p, k, tol=1e-3, rtype=\"avg\"") {
    CVec r, p, k;
    if (!getCVec(a, 0, ctx, r) || !getCVec(a, 1, ctx, p))
      return Value(0.0);
    if (a.size() > 2 && !getCVec(a, 2, ctx, k))
      return Value(0.0);
    k = trimFront(k);
    CVec u, den;
    std::vector<int> m;
    groupPoles(p, optNum(a, 3, 1e-3), optText(a, 4, "avg"), u, m);
    std::vector<CVec> fac;
    computeFactors(u, m, true, fac, den);
    CVec num = k.empty() ? CVec{cd(0.0)} : polyMulC(k, den);
    if (r.size() != fac.size()) {
      ctx.fail("r and p must have the same length");
      return Value(0.0);
    }
    for (size_t i = 0; i < r.size(); i++) {
      CVec t = fac[i];
      for (cd &v : t)
        v *= r[i];
      num = polyAddC(num, t);
    }
    return makeDict({{"b", realIfPossible(num)}, {"a", realIfPossible(den)}});
  } SP_ENDC
  SP_ADD("invresz", 2, 5, "r, p, k, tol=1e-3, rtype=\"avg\"") {
    CVec r, p, k;
    if (!getCVec(a, 0, ctx, r) || !getCVec(a, 1, ctx, p))
      return Value(0.0);
    if (a.size() > 2 && !getCVec(a, 2, ctx, k))
      return Value(0.0);
    k = trimBack(k);
    CVec u, den;
    std::vector<int> m;
    groupPoles(p, optNum(a, 3, 1e-3), optText(a, 4, "avg"), u, m);
    std::vector<CVec> fac;
    computeFactors(u, m, true, fac, den);
    const CVec drev(den.rbegin(), den.rend());
    CVec num = k.empty() ? CVec{cd(0.0)} : polyMulC(CVec(k.rbegin(), k.rend()), drev);
    if (r.size() != fac.size()) {
      ctx.fail("r and p must have the same length");
      return Value(0.0);
    }
    for (size_t i = 0; i < r.size(); i++) {
      CVec t(fac[i].rbegin(), fac[i].rend());
      for (cd &v : t)
        v *= r[i];
      num = polyAddC(num, t);
    }
    return makeDict({{"b", realIfPossible(CVec(num.rbegin(), num.rend()))}, {"a", realIfPossible(den)}});
  } SP_ENDC
  // ---- responses ----
  SP_ADD("find_freqs", 3, 3, "b, a, n") {
    SG_TF_ARGS
    return toValue(findFreqs(rootsOf(ca), rootsOf(b), (size_t)optInt(a, 2, 200)));
  } SP_END
  SP_ADD("freqs", 2, 3, "b, a, w") {
    SG_TF_ARGS
    Vec w;
    if (a.size() > 2 && !isPlainNumber(a[2])) {
      if (!getVec(a, 2, ctx, w))
        return Value(0.0);
    } else {
      w = findFreqs(rootsOf(ca), rootsOf(b), (size_t)(isOmitted(a, 2) ? 200 : optInt(a, 2, 200)));
    }
    CVec s;
    for (double v : w)
      s.push_back(cd(0.0, v));
    return makeDict({{"w", toValue(w)}, {"h", toValue(freqsAt(b, ca, s))}});
  } SP_END
  SP_ADD("freqs_zpk", 3, 4, "z, p, k, w") {
    Zpk f;
    if (!getCVec(a, 0, ctx, f.z) || !getCVec(a, 1, ctx, f.p))
      return Value(0.0);
    f.k = optNum(a, 2, 1.0);
    Vec w;
    if (a.size() > 3 && !isPlainNumber(a[3])) {
      if (!getVec(a, 3, ctx, w))
        return Value(0.0);
    } else {
      w = findFreqs(f.p, f.z, (size_t)(isOmitted(a, 3) ? 200 : optInt(a, 3, 200)));
    }
    CVec h(w.size());
    for (size_t i = 0; i < w.size(); i++) {
      const cd s(0.0, w[i]);
      cd v(f.k);
      for (const cd &q : f.z)
        v *= s - q;
      for (const cd &q : f.p)
        v /= s - q;
      h[i] = v;
    }
    return makeDict({{"w", toValue(w)}, {"h", toValue(h)}});
  } SP_ENDC
#define SG_WGRID(IDX)                                                                              \
  const double fs = a.size() > (IDX) + 1 && isPlainNumber(a[(IDX) + 1]) && a[(IDX) + 1].number > 0 ? a[(IDX) + 1].number : 2.0 * kPi; \
  Vec w, wOut;                                                                                     \
  if (a.size() > (IDX) && !isPlainNumber(a[IDX])) {                                                \
    if (!getVec(a, IDX, ctx, wOut))                                                                \
      return Value(0.0);                                                                           \
    for (double v : wOut)                                                                          \
      w.push_back(2.0 * kPi * v / fs);                                                             \
  } else {                                                                                         \
    w = angleGrid((size_t)(isOmitted(a, IDX) ? 512 : optInt(a, IDX, 512)), false);                 \
    for (double v : w)                                                                             \
      wOut.push_back(v * fs / (2.0 * kPi));                                                        \
  }
  SP_ADD("freqz", 1, 4, "b, a=1, n=512, fs=2*pi") {
    Vec b, ca{1.0};
    if (!getVec(a, 0, ctx, b))
      return Value(0.0);
    if (!isOmitted(a, 1) && !getVec(a, 1, ctx, ca))
      return Value(0.0);
    SG_WGRID(2)
    return makeDict({{"w", toValue(wOut)}, {"h", toValue(freqzAt(b, ca, w))}});
  } SP_END
  SP_ADD("freqz_sos", 1, 3, "sos, n=512, fs=2*pi") {
    Mat s;
    if (!getMat(a, 0, ctx, s))
      return Value(0.0);
    if (s.c != 6) {
      ctx.fail("sos must have six columns");
      return Value(0.0);
    }
    SG_WGRID(1)
    CVec h(w.size(), cd(1.0));
    for (size_t i = 0; i < s.r; i++) {
      CVec t = freqzAt(Vec(s.row(i), s.row(i) + 3), Vec(s.row(i) + 3, s.row(i) + 6), w);
      for (size_t k = 0; k < h.size(); k++)
        h[k] *= t[k];
    }
    return makeDict({{"w", toValue(wOut)}, {"h", toValue(h)}});
  } SP_END
  SP_ADD("freqz_zpk", 3, 5, "z, p, k, n=512, fs=2*pi") {
    Zpk f;
    if (!getCVec(a, 0, ctx, f.z) || !getCVec(a, 1, ctx, f.p))
      return Value(0.0);
    f.k = optNum(a, 2, 1.0);
    SG_WGRID(3)
    return makeDict({{"w", toValue(wOut)}, {"h", toValue(freqzZpkAt(f.z, f.p, f.k, w))}});
  } SP_ENDC
  SP_ADD("group_delay", 2, 4, "b, a, n=512, fs=2*pi") {
    SG_TF_ARGS
    SG_WGRID(2)
    Vec c = polyMul(b, Vec(ca.rbegin(), ca.rend()));
    Vec cr(c.size());
    for (size_t i = 0; i < c.size(); i++)
      cr[i] = c[i] * (double)i;
    Vec cRev(c.rbegin(), c.rend()), crRev(cr.rbegin(), cr.rend()), gd(w.size());
    for (size_t i = 0; i < w.size(); i++) {
      const cd z = std::polar(1.0, -w[i]);
      const cd num = polyval(crRev, z), den = polyval(cRev, z);
      gd[i] = std::abs(den) < 10.0 * kEps ? 0.0 : (num / den).real() - (double)ca.size() + 1.0;
    }
    return makeDict({{"w", toValue(wOut)}, {"gd", toValue(gd)}});
  } SP_END
  SP_ADD("gammatone", 2, 5, "freq, ftype, fs=2, order=4, numtaps") {
    const double freq = optNum(a, 0, 0), fs = isOmitted(a, 2) ? 2.0 : optNum(a, 2, 2.0);
    const std::string ftype = optText(a, 1, "");
    if (!(freq > 0.0 && freq < fs / 2.0)) {
      ctx.fail("freq must be between 0 and fs/2");
      return Value(0.0);
    }
    const double erb = freq / 9.26449 + 24.7;
    if (ftype == "fir") {
      const long order = (long)(isOmitted(a, 3) ? 4 : optInt(a, 3, 4));
      const long nt = (long)(isOmitted(a, 4) ? std::max((long long)(fs * 0.015), 15LL) : optInt(a, 4, 15));
      if (order < 1 || order > 24) {
        ctx.fail("order must be from 1 to 24");
        return Value(0.0);
      }
      const double bw = 1.019 * erb;
      Vec b((size_t)nt);
      double scale = 2.0 * std::pow(2.0 * kPi * bw, (double)order) / std::tgamma((double)order) / fs;
      for (long i = 0; i < nt; i++) {
        const double t = (double)i / fs;
        b[(size_t)i] = scale * std::pow(t, (double)(order - 1)) * std::exp(-2.0 * kPi * bw * t) * std::cos(2.0 * kPi * freq * t);
      }
      return tfDict(b, {1.0});
    }
    if (ftype != "iir") {
      ctx.fail("ftype must be \"fir\" or \"iir\"");
      return Value(0.0);
    }
    const double T = 1.0 / fs, bw = 2.0 * kPi * 1.019 * erb, fr = 2.0 * freq * kPi * T, bwT = bw * T;
    const cd g1 = -2.0 * std::exp(cd(0.0, 2.0 * fr)) * T, g2 = 2.0 * std::exp(cd(-bwT, fr)) * T;
    const double g3 = std::sqrt(3.0 + std::pow(2.0, 1.5)) * std::sin(fr), g4 = std::sqrt(3.0 - std::pow(2.0, 1.5)) * std::sin(fr);
    const cd g5 = std::exp(cd(0.0, 2.0 * fr));
    cd g = g1 + g2 * (std::cos(fr) - g4);
    g *= g1 + g2 * (std::cos(fr) + g4);
    g *= g1 + g2 * (std::cos(fr) - g3);
    g *= g1 + g2 * (std::cos(fr) + g3);
    g /= std::pow(-2.0 / std::exp(2.0 * bwT) - 2.0 * g5 + 2.0 * (1.0 + g5) / std::exp(bwT), 4);
    const double G = std::abs(g), T4 = std::pow(T, 4.0);
    Vec b{T4 / G, -4.0 * T4 * std::cos(fr) / std::exp(bwT) / G, 6.0 * T4 * std::cos(2.0 * fr) / std::exp(2.0 * bwT) / G,
          -4.0 * T4 * std::cos(3.0 * fr) / std::exp(3.0 * bwT) / G, T4 * std::cos(4.0 * fr) / std::exp(4.0 * bwT) / G};
    Vec ca{1.0, -8.0 * std::cos(fr) / std::exp(bwT), 4.0 * (4.0 + 3.0 * std::cos(2.0 * fr)) / std::exp(2.0 * bwT),
           -8.0 * (6.0 * std::cos(fr) + std::cos(3.0 * fr)) / std::exp(3.0 * bwT), 2.0 * (18.0 + 16.0 * std::cos(2.0 * fr) + std::cos(4.0 * fr)) / std::exp(4.0 * bwT),
           -8.0 * (6.0 * std::cos(fr) + std::cos(3.0 * fr)) / std::exp(5.0 * bwT), 4.0 * (4.0 + 3.0 * std::cos(2.0 * fr)) / std::exp(6.0 * bwT),
           -8.0 * std::cos(fr) / std::exp(7.0 * bwT), std::exp(-8.0 * bwT)};
    return tfDict(b, ca);
  } SP_END
}

} // namespace scipy
} // namespace nc
