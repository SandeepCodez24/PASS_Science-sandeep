// Section 14 of 25 - Signal Processing (scipy.signal). The functions live in:
//   sg_design.cpp     IIR design, prototypes, frequency transforms, form conversions, responses
//   sg_fir.cpp        FIR design
//   sg_filtering.cpp  filtering, convolution, splines, resampling
//   sg_systems.cpp    LTI systems, simulation, discretisation, pole placement
//   sg_waves.cpp      waveforms, get_window, peak finding
//   sg_spectral.cpp   spectral estimates, STFT, chirp-z
// convolve and correlate exist in Numpy and stay there; hilbert (dual with the
// Hilbert matrix) is registered with linear algebra, fft_convolve with legacy FFT.
#include "signal_processing_main.h"

#include "sg_core.h"

namespace nc {
namespace scipy {

void registerSignalProcessing(Registry &reg) {
  registerSgDesign(reg);
  registerSgFir(reg);
  registerSgFiltering(reg);
  registerSgSystems(reg);
  registerSgWaves(reg);
  registerSgSpectral(reg);
}

} // namespace scipy
} // namespace nc
