// Signal kernels shared by the files of this section, and used outside it.
#ifndef NC_SCIPY_SG_CORE_H
#define NC_SCIPY_SG_CORE_H

#include "../scipy_core.h"

namespace nc {
namespace scipy {
namespace sg {

// x + i H(x), computed over n points.
CVec analytic(const Vec &x, size_t n);
// A window by name; false if the name is not known. Parameters come from the
// list form ["kaiser", 8.0].
bool windowByName(const std::string &name, const Vec &params, size_t n, bool symmetric, Vec &out,
                  std::string &err);
// A window given as a name, as ["name", parameter] or as the samples themselves.
// With samples, a non-zero n must match their count.
bool windowFromValue(const Value &v, size_t n, bool symmetric, Vec &out, std::string &err);
inline bool isWindowSamples(const Value &v) { return !v.isText && numericCells(v) && !isPlainNumber(v); }

// ---- polynomials, highest power first ----
Vec polyMul(const Vec &a, const Vec &b);
CVec polyMulC(const CVec &a, const CVec &b);
CVec polyAddC(const CVec &a, const CVec &b);
CVec polyOfRoots(const CVec &roots);
cd polyval(const CVec &c, cd x);
cd polyval(const Vec &c, cd x);
double polyvalReal(const Vec &c, double x);
Vec realParts(const CVec &v);
// Roots sorted by real part, then by imaginary part.
CVec rootsOf(const Vec &coeffs);
void sortRoots(CVec &r);

// ---- filter forms ----
struct Zpk {
  CVec z, p;
  double k = 1.0;
};
struct Ss {
  Mat A, B, C, D;
};
bool normalizeTf(Vec &b, Vec &a, std::string &err);
bool tf2zpk(Vec b, Vec a, Zpk &out, std::string &err);
void zpk2tf(const Zpk &f, Vec &b, Vec &a);
bool zpk2sos(const Zpk &f, Mat &sos, std::string &err);
Zpk sos2zpk(const Mat &sos);
void sos2tf(const Mat &sos, Vec &b, Vec &a);
bool tf2ss(Vec b, Vec a, Ss &out, std::string &err);
void ss2tf(const Ss &s, size_t input, Mat &num, Vec &den);
// Fills what is left out with zeros and checks the sizes.
bool abcdNormalize(Ss &s, std::string &err);
Value tfDict(const Vec &b, const Vec &a);
Value zpkDict(const Zpk &f);
Value ssDict(const Ss &s);
// The response on the points s (a polynomial in s).
CVec freqsAt(const Vec &b, const Vec &a, const CVec &s);
Vec findFreqs(const CVec &poles, const CVec &zeros, size_t n);
// The discrete responses of freqz and freqz_zpk at the angles w.
CVec freqzAt(const Vec &b, const Vec &a, const Vec &w);
CVec freqzZpkAt(const CVec &z, const CVec &p, double k, const Vec &w);
Vec angleGrid(size_t n, bool whole);
Vec unwrapped(Vec phase);

// ---- filtering ----
// Direct form II transposed; zi is the state, updated when given.
Vec lfilter(const Vec &b, const Vec &a, const Vec &x, Vec *zi = nullptr);
Vec lfilterZi(Vec b, Vec a);
Vec sosfilt(const Mat &sos, const Vec &x, Mat *zi = nullptr);
Mat sosfiltZi(const Mat &sos);
bool filtfilt(const Vec &b, const Vec &a, const Vec &x, Vec &out, std::string &err);
bool sosFiltfilt(const Mat &sos, const Vec &x, Vec &out, std::string &err);
bool iirDesign(int n, const Vec &wn, const std::string &btype, const std::string &ftype, double rp, double rs,
               const std::string &norm, double fs, Zpk &out, std::string &err);
bool firwin(long numtaps, const Vec &cutoff, const Value *window, bool passZero, bool scale, double fs, Vec &h, std::string &err);
Vec upfirdn(const Vec &h, const Vec &x, size_t up, size_t down);
bool resamplePoly(const Vec &x, long up, long down, const Vec *taps, const Value *window, Vec &out, std::string &err);
Vec convolveDirect(const Vec &a, const Vec &b);
// Linear, or a removal of the mean.
Vec detrendLine(const Vec &x, bool linear);

} // namespace sg

// The registering parts of the section.
void registerSgDesign(Registry &reg);
void registerSgFir(Registry &reg);
void registerSgFiltering(Registry &reg);
void registerSgSystems(Registry &reg);
void registerSgWaves(Registry &reg);
void registerSgSpectral(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SG_CORE_H
