// Waveforms, get_window, relative extrema and peak finding.
#include <cstdlib>
#include <map>

#include "sg_core.h"
#include "signal_processing_main.h"

#define SP_SEC Section::SignalProcessing

namespace nc {
namespace scipy {

namespace sg {

bool windowFromValue(const Value &v, size_t n, bool symmetric, Vec &out, std::string &err) {
  if (v.isText)
    return windowByName(v.text(), {}, n, symmetric, out, err);
  // ["kaiser", 8.0]: a list with the name first.
  std::vector<Value> cells;
  if (v.isArray)
    for (size_t i = 0; i < v.length(); i++)
      cells.push_back(v.at(i));
  else if (v.isMatrix && !v.isND() && v.rows() == 1)
    for (size_t i = 0; i < v.cols(); i++)
      cells.push_back(v.at(0, i));
  if (!cells.empty() && cells[0].isText) {
    Vec p;
    for (size_t i = 1; i < cells.size(); i++) {
      // A list holding a name keeps its other cells as text.
      char *end = nullptr;
      const double t = cells[i].isText ? std::strtod(cells[i].text().c_str(), &end) : cells[i].number;
      if ((cells[i].isText && (end == cells[i].text().c_str() || *end)) || (!cells[i].isText && !isPlainNumber(cells[i]))) {
        err = "a window parameter must be a number";
        return false;
      }
      p.push_back(t);
    }
    return windowByName(cells[0].text(), p, n, symmetric, out, err);
  }
  if (!readVec(v, out)) {
    err = "the window must be a name, [\"name\", parameter] or an array of samples";
    return false;
  }
  if (n && out.size() != n) {
    err = "the window must have " + std::to_string(n) + " samples";
    return false;
  }
  return true;
}

} // namespace sg

using namespace sg;

namespace {

std::vector<long> relExtrema(const Vec &x, int order, bool greater) {
  std::vector<long> out;
  const long n = (long)x.size();
  for (long i = 0; i < n; i++) {
    bool ok = true;
    for (int s = 1; s <= order && ok; s++) {
      const double p = x[(size_t)std::min(n - 1, i + s)], m = x[(size_t)std::max(0L, i - s)];
      ok = greater ? (x[(size_t)i] > p && x[(size_t)i] > m) : (x[(size_t)i] < p && x[(size_t)i] < m);
    }
    if (ok)
      out.push_back(i);
  }
  return out;
}

Value indexValue(const std::vector<long> &v) {
  IVec o(v.begin(), v.end());
  return toValue(o);
}

// A limit: a number is the minimum, [min, max] both.
bool readLimits(const Args &a, size_t i, CallContext &ctx, bool &has, double &lo, double &hi) {
  has = false;
  lo = -kInf;
  hi = kInf;
  if (isOmitted(a, i))
    return true;
  has = true;
  if (isPlainNumber(a[i])) {
    lo = a[i].number;
    return true;
  }
  Vec v;
  if (!getVec(a, i, ctx, v))
    return false;
  if (v.size() == 1) {
    lo = v[0];
    return true;
  }
  if (v.size() != 2) {
    ctx.fail("the " + ordinal(i) + " argument must be a number or [min, max]");
    return false;
  }
  lo = v[0];
  hi = v[1];
  return true;
}

using Props = std::map<std::string, Vec>;

void keepOnly(std::vector<long> &peaks, Props &props, const std::vector<char> &keep) {
  std::vector<long> np;
  for (size_t i = 0; i < peaks.size(); i++)
    if (keep[i])
      np.push_back(peaks[i]);
  peaks = np;
  for (auto &e : props) {
    Vec n;
    for (size_t i = 0; i < e.second.size(); i++)
      if (keep[i])
        n.push_back(e.second[i]);
    e.second = n;
  }
}

void prominences(const Vec &x, const std::vector<long> &peaks, long wlen, Vec &prom, Vec &left, Vec &right) {
  const long n = (long)x.size();
  prom.resize(peaks.size());
  left.resize(peaks.size());
  right.resize(peaks.size());
  for (size_t k = 0; k < peaks.size(); k++) {
    const long p = peaks[k];
    long iMin = 0, iMax = n - 1;
    if (wlen >= 2) {
      iMin = std::max(p - wlen / 2, iMin);
      iMax = std::min(p + wlen / 2, iMax);
    }
    long i = p;
    double lm = x[(size_t)p];
    left[k] = (double)p;
    while (iMin <= i && x[(size_t)i] <= x[(size_t)p]) {
      if (x[(size_t)i] < lm) {
        lm = x[(size_t)i];
        left[k] = (double)i;
      }
      i--;
    }
    i = p;
    double rm = x[(size_t)p];
    right[k] = (double)p;
    while (i <= iMax && x[(size_t)i] <= x[(size_t)p]) {
      if (x[(size_t)i] < rm) {
        rm = x[(size_t)i];
        right[k] = (double)i;
      }
      i++;
    }
    prom[k] = x[(size_t)p] - std::max(lm, rm);
  }
}

void widths(const Vec &x, const std::vector<long> &peaks, double rel, const Vec &prom, const Vec &lb, const Vec &rb, Vec &w, Vec &h, Vec &li, Vec &ri) {
  const size_t m = peaks.size();
  w.resize(m);
  h.resize(m);
  li.resize(m);
  ri.resize(m);
  for (size_t p = 0; p < m; p++) {
    const long iMin = (long)lb[p], iMax = (long)rb[p], peak = peaks[p];
    const double height = x[(size_t)peak] - prom[p] * rel;
    h[p] = height;
    long i = peak;
    while (iMin < i && height < x[(size_t)i])
      i--;
    double l = (double)i;
    if (x[(size_t)i] < height)
      l += (height - x[(size_t)i]) / (x[(size_t)i + 1] - x[(size_t)i]);
    i = peak;
    while (i < iMax && height < x[(size_t)i])
      i++;
    double r = (double)i;
    if (x[(size_t)i] < height)
      r -= (height - x[(size_t)i]) / (x[(size_t)i - 1] - x[(size_t)i]);
    li[p] = l;
    ri[p] = r;
    w[p] = r - l;
  }
}

bool peakList(const Args &a, size_t i, CallContext &ctx, const Vec &x, std::vector<long> &peaks) {
  Vec v;
  if (!getVec(a, i, ctx, v))
    return false;
  for (double d : v) {
    if (d < 0.0 || d >= (double)x.size() || d != std::floor(d)) {
      ctx.fail("each peak must be an index into the data");
      return false;
    }
    peaks.push_back((long)d);
  }
  return true;
}

Vec ricker(size_t points, double a) {
  const double A = 2.0 / (std::sqrt(3.0 * a) * std::pow(kPi, 0.25)), wsq = a * a;
  Vec v(points);
  for (size_t i = 0; i < points; i++) {
    const double t = (double)i - ((double)points - 1.0) / 2.0, xsq = t * t;
    v[i] = A * (1.0 - xsq / wsq) * std::exp(-xsq / (2.0 * wsq));
  }
  return v;
}

} // namespace

void registerSgWaves(Registry &reg) {
  SP_ADD("chirp", 4, 7, "t, f0, t1, f1, method=\"linear\", phi=0, vertex_zero=1") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    const double f0 = optNum(a, 1, 0), t1 = optNum(a, 2, 1), f1 = optNum(a, 3, 0), phi = optNum(a, 5, 0) * kPi / 180.0;
    const std::string m = optText(a, 4, "linear");
    const bool vz = optBool(a, 6, true);
    for (double &v : t) {
      double ph;
      if (m == "linear" || m == "lin" || m == "li") {
        const double beta = (f1 - f0) / t1;
        ph = 2.0 * kPi * (f0 * v + 0.5 * beta * v * v);
      } else if (m == "quadratic" || m == "quad" || m == "q") {
        const double beta = (f1 - f0) / (t1 * t1);
        ph = vz ? 2.0 * kPi * (f0 * v + beta * v * v * v / 3.0) : 2.0 * kPi * (f1 * v + beta * (std::pow(t1 - v, 3.0) - t1 * t1 * t1) / 3.0);
      } else if (m == "logarithmic" || m == "log" || m == "lo") {
        if (f0 * f1 <= 0.0) {
          ctx.fail("f0 and f1 must be nonzero and of one sign for a logarithmic chirp");
          return Value(0.0);
        }
        if (f0 == f1)
          ph = 2.0 * kPi * f0 * v;
        else
          ph = 2.0 * kPi * (t1 / std::log(f1 / f0)) * f0 * (std::pow(f1 / f0, v / t1) - 1.0);
      } else if (m == "hyperbolic" || m == "hyp") {
        if (f0 == 0.0 || f1 == 0.0) {
          ctx.fail("f0 and f1 must be nonzero for a hyperbolic chirp");
          return Value(0.0);
        }
        if (f0 == f1) {
          ph = 2.0 * kPi * f0 * v;
        } else {
          const double sing = -f1 * t1 / (f0 - f1);
          ph = 2.0 * kPi * (-sing * f0) * std::log(std::fabs(1.0 - v / sing));
        }
      } else {
        ctx.fail("method must be \"linear\", \"quadratic\", \"logarithmic\" or \"hyperbolic\"");
        return Value(0.0);
      }
      v = std::cos(ph + phi);
    }
    return toValue(t);
  } SP_END
  SP_ADD("gauss_pulse", 1, 4, "t, fc=1000, bw=0.5, bwr=-6") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    const double fc = isOmitted(a, 1) ? 1000.0 : optNum(a, 1, 1000.0), bw = isOmitted(a, 2) ? 0.5 : optNum(a, 2, 0.5), bwr = isOmitted(a, 3) ? -6.0 : optNum(a, 3, -6.0);
    if (fc < 0.0 || bw <= 0.0 || bwr >= 0.0) {
      ctx.fail("fc must not be negative, bw must be positive and bwr must be negative");
      return Value(0.0);
    }
    const double ref = std::pow(10.0, bwr / 20.0), al = -(kPi * fc * bw) * (kPi * fc * bw) / (4.0 * std::log(ref));
    for (double &v : t)
      v = std::exp(-al * v * v) * std::cos(2.0 * kPi * fc * v);
    return toValue(t);
  } SP_END
  SP_ADD("max_len_seq", 1, 3, "nbits, state, length") {
    static const std::map<long long, std::vector<int>> tapsOf = {
        {2, {1}}, {3, {2}}, {4, {3}}, {5, {3}}, {6, {5}}, {7, {6}}, {8, {7, 6, 1}}, {9, {5}}, {10, {7}}, {11, {9}}, {12, {11, 10, 4}},
        {13, {12, 11, 8}}, {14, {13, 12, 2}}, {15, {14}}, {16, {15, 13, 4}}, {17, {14}}, {18, {11}}, {19, {18, 17, 14}}, {20, {17}},
        {21, {19}}, {22, {21}}, {23, {18}}, {24, {23, 22, 17}}, {25, {22}}, {26, {25, 24, 20}}, {27, {26, 25, 22}}, {28, {25}},
        {29, {27}}, {30, {29, 28, 7}}, {31, {28}}, {32, {31, 30, 10}}};
    const long long nbits = optInt(a, 0, 0);
    auto it = tapsOf.find(nbits);
    if (it == tapsOf.end()) {
      ctx.fail("nbits must be from 2 to 32");
      return Value(0.0);
    }
    std::vector<char> state((size_t)nbits, 1);
    if (a.size() > 1 && !isOmitted(a, 1)) {
      Vec s;
      if (!getVec(a, 1, ctx, s))
        return Value(0.0);
      if (s.size() != (size_t)nbits) {
        ctx.fail("state must have nbits values");
        return Value(0.0);
      }
      bool any = false;
      for (size_t i = 0; i < s.size(); i++) {
        state[i] = s[i] != 0.0;
        any = any || state[i];
      }
      if (!any) {
        ctx.fail("state must not be all zeros");
        return Value(0.0);
      }
    }
    const long long len = isOmitted(a, 2) ? (1LL << nbits) - 1 : optInt(a, 2, 0);
    if (len < 0) {
      ctx.fail("length must not be negative");
      return Value(0.0);
    }
    Vec seq((size_t)len);
    size_t idx = 0;
    for (long long i = 0; i < len; i++) {
      char fb = state[idx];
      seq[(size_t)i] = fb;
      for (int t : it->second)
        fb ^= state[((size_t)t + idx) % (size_t)nbits];
      state[idx] = fb;
      idx = (idx + 1) % (size_t)nbits;
    }
    Vec st((size_t)nbits);
    for (size_t i = 0; i < (size_t)nbits; i++)
      st[i] = state[(i + idx) % (size_t)nbits];
    return makeDict({{"seq", toValue(seq)}, {"state", toValue(st)}});
  } SP_END
  SP_ADD("sawtooth", 1, 2, "t, width=1") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    const double w = a.size() > 1 ? optNum(a, 1, 1.0) : 1.0;
    for (double &v : t) {
      double tm = std::fmod(v, 2.0 * kPi);
      if (tm < 0.0)
        tm += 2.0 * kPi;
      if (w > 1.0 || w < 0.0)
        v = kNaN;
      else if (tm < w * 2.0 * kPi)
        v = tm / (kPi * w) - 1.0;
      else
        v = (kPi * (w + 1.0) - tm) / (kPi * (1.0 - w));
    }
    return toValue(t);
  } SP_END
  SP_ADD("square_wave", 1, 2, "t, duty=0.5") {
    Vec t;
    if (!getVec(a, 0, ctx, t))
      return Value(0.0);
    const double w = a.size() > 1 ? optNum(a, 1, 0.5) : 0.5;
    for (double &v : t) {
      double tm = std::fmod(v, 2.0 * kPi);
      if (tm < 0.0)
        tm += 2.0 * kPi;
      v = (w > 1.0 || w < 0.0) ? kNaN : (tm < w * 2.0 * kPi ? 1.0 : -1.0);
    }
    return toValue(t);
  } SP_END
  SP_ADD("sweep_poly", 2, 3, "t, poly, phi=0") {
    Vec t, p;
    if (!getVec(a, 0, ctx, t) || !getVec(a, 1, ctx, p))
      return Value(0.0);
    const double phi = optNum(a, 2, 0.0) * kPi / 180.0;
    Vec in(p.size() + 1, 0.0);
    for (size_t i = 0; i < p.size(); i++)
      in[i] = p[i] / (double)(p.size() - i);
    for (double &v : t)
      v = std::cos(2.0 * kPi * polyvalReal(in, v) + phi);
    return toValue(t);
  } SP_END
  SP_ADD("unit_impulse", 1, 2, "n, idx=0") {
    if (!isNumberArg(a, 0) || a[0].number < 0) {
      ctx.fail("n must be a whole number");
      return Value(0.0);
    }
    const size_t n = (size_t)a[0].number;
    size_t idx = 0;
    if (a.size() > 1 && a[1].isText) {
      if (a[1].text() != "mid") {
        ctx.fail("idx must be a number or \"mid\"");
        return Value(0.0);
      }
      idx = n / 2;
    } else {
      idx = (size_t)optInt(a, 1, 0);
    }
    if (idx >= n) {
      ctx.fail("idx must be below n");
      return Value(0.0);
    }
    Vec v(n, 0.0);
    v[idx] = 1.0;
    return toValue(v);
  } SP_END
  SP_ADD("get_window", 2, 3, "window, n, fftbins=1") {
    if (!isNumberArg(a, 1) || a[1].number < 0) {
      ctx.fail("n must be a whole number");
      return Value(0.0);
    }
    Vec w;
    std::string err;
    if (!windowFromValue(a[0], (size_t)a[1].number, !optBool(a, 2, true), w, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return toValue(w);
  } SP_END
  // ---- relative extrema ----
#define SG_REL(NAME, GREATER)                                                                      \
  SP_ADD(NAME, 1, 2, "data, order=1") {                                                            \
    Vec x;                                                                                         \
    if (!getVec(a, 0, ctx, x))                                                                     \
      return Value(0.0);                                                                           \
    const long long order = isOmitted(a, 1) ? 1 : optInt(a, 1, 1);                                 \
    if (order < 1) {                                                                               \
      ctx.fail("order must be 1 or more");                                                         \
      return Value(0.0);                                                                           \
    }                                                                                              \
    return indexValue(relExtrema(x, (int)order, GREATER));                                         \
  } SP_END
  SG_REL("arg_rel_min", false)
  SG_REL("arg_rel_max", true)
  SP_ADD("arg_rel_extrema", 2, 3, "data, op, order=1") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const std::string op = optText(a, 1, "");
    if (op != ">" && op != "<") {
      ctx.fail("op must be \">\" or \"<\"");
      return Value(0.0);
    }
    const long long order = isOmitted(a, 2) ? 1 : optInt(a, 2, 1);
    if (order < 1) {
      ctx.fail("order must be 1 or more");
      return Value(0.0);
    }
    return indexValue(relExtrema(x, (int)order, op == ">"));
  } SP_END
  // ---- peaks ----
  SP_ADD("find_peaks", 1, 6, "data, height, distance, prominence, threshold, width") {
    Vec x;
    if (!getVec(a, 0, ctx, x))
      return Value(0.0);
    const long n = (long)x.size();
    std::vector<long> peaks;
    Vec plateau, leftE, rightE;
    for (long i = 1; i < n - 1;) {
      if (x[(size_t)(i - 1)] < x[(size_t)i]) {
        long ah = i + 1;
        while (ah < n - 1 && x[(size_t)ah] == x[(size_t)i])
          ah++;
        if (x[(size_t)ah] < x[(size_t)i]) {
          peaks.push_back((i + ah - 1) / 2);
          i = ah;
        }
      }
      i++;
    }
    Props props;
    bool has;
    double lo, hi;
    if (!readLimits(a, 1, ctx, has, lo, hi))
      return Value(0.0);
    if (has) {
      Vec &h = props["peak_heights"];
      std::vector<char> keep;
      for (long p : peaks) {
        const double v = x[(size_t)p];
        h.push_back(v);
        keep.push_back(lo <= v && v <= hi);
      }
      keepOnly(peaks, props, keep);
    }
    if (!readLimits(a, 4, ctx, has, lo, hi))
      return Value(0.0);
    if (has) {
      Vec &l = props["left_thresholds"], &r = props["right_thresholds"];
      std::vector<char> keep;
      for (long p : peaks) {
        const double dl = x[(size_t)p] - x[(size_t)(p - 1)], dr = x[(size_t)p] - x[(size_t)(p + 1)];
        l.push_back(dl);
        r.push_back(dr);
        keep.push_back(std::min(dl, dr) >= lo && std::max(dl, dr) <= hi);
      }
      keepOnly(peaks, props, keep);
    }
    if (!isOmitted(a, 2)) {
      const double dist = optNum(a, 2, 1.0);
      if (dist < 1.0) {
        ctx.fail("distance must be 1 or more");
        return Value(0.0);
      }
      const long dc = (long)std::ceil(dist), m = (long)peaks.size();
      std::vector<size_t> order((size_t)m);
      for (size_t i = 0; i < order.size(); i++)
        order[i] = i;
      std::stable_sort(order.begin(), order.end(), [&](size_t p, size_t q) { return x[(size_t)peaks[p]] < x[(size_t)peaks[q]]; });
      std::vector<char> keep((size_t)m, 1);
      for (long i = m - 1; i >= 0; i--) {
        const long j = (long)order[(size_t)i];
        if (!keep[(size_t)j])
          continue;
        for (long k = j - 1; k >= 0 && peaks[(size_t)j] - peaks[(size_t)k] < dc; k--)
          keep[(size_t)k] = 0;
        for (long k = j + 1; k < m && peaks[(size_t)k] - peaks[(size_t)j] < dc; k++)
          keep[(size_t)k] = 0;
      }
      keepOnly(peaks, props, keep);
    }
    bool hasW;
    double wlo, whi;
    if (!readLimits(a, 3, ctx, has, lo, hi) || !readLimits(a, 5, ctx, hasW, wlo, whi))
      return Value(0.0);
    if (has || hasW) {
      prominences(x, peaks, -1, props["prominences"], props["left_bases"], props["right_bases"]);
    }
    if (has) {
      std::vector<char> keep;
      for (double v : props["prominences"])
        keep.push_back(lo <= v && v <= hi);
      keepOnly(peaks, props, keep);
    }
    if (hasW) {
      widths(x, peaks, 0.5, props["prominences"], props["left_bases"], props["right_bases"], props["widths"], props["width_heights"], props["left_ips"], props["right_ips"]);
      std::vector<char> keep;
      for (double v : props["widths"])
        keep.push_back(wlo <= v && v <= whi);
      keepOnly(peaks, props, keep);
    }
    DictInit pd;
    for (const auto &e : props)
      pd.push_back({e.first, toValue(e.second)});
    return makeDict({{"peaks", indexValue(peaks)}, {"properties", makeDict(pd)}});
  } SP_END
  SP_ADD("peak_prominences", 2, 3, "data, peaks, wlen") {
    Vec x, p, l, r;
    std::vector<long> peaks;
    if (!getVec(a, 0, ctx, x) || !peakList(a, 1, ctx, x, peaks))
      return Value(0.0);
    prominences(x, peaks, isOmitted(a, 2) ? -1 : (long)optInt(a, 2, -1), p, l, r);
    return makeDict({{"prominences", toValue(p)}, {"left_bases", toValue(l)}, {"right_bases", toValue(r)}});
  } SP_END
  SP_ADD("peak_widths", 2, 3, "data, peaks, rel_height=0.5") {
    Vec x, p, l, r, w, h, li, ri;
    std::vector<long> peaks;
    if (!getVec(a, 0, ctx, x) || !peakList(a, 1, ctx, x, peaks))
      return Value(0.0);
    prominences(x, peaks, -1, p, l, r);
    widths(x, peaks, a.size() > 2 ? optNum(a, 2, 0.5) : 0.5, p, l, r, w, h, li, ri);
    return makeDict({{"widths", toValue(w)}, {"width_heights", toValue(h)}, {"left_ips", toValue(li)}, {"right_ips", toValue(ri)}});
  } SP_END
  SP_ADD("find_peaks_cwt", 2, 4, "data, widths, min_snr=1, noise_perc=10") {
    Vec x, wd;
    if (!getVec(a, 0, ctx, x) || !getVec(a, 1, ctx, wd))
      return Value(0.0);
    if (wd.empty() || x.empty()) {
      ctx.fail("the data and the widths must not be empty");
      return Value(0.0);
    }
    const double minSnr = isOmitted(a, 2) ? 1.0 : optNum(a, 2, 1.0), noisePerc = isOmitted(a, 3) ? 10.0 : optNum(a, 3, 10.0);
    const double gap = std::ceil(wd[0]);
    const size_t rows = wd.size(), cols = x.size();
    Mat cw(rows, cols);
    for (size_t r = 0; r < rows; r++) {
      const double N = std::min(10.0 * wd[r], (double)cols);
      Vec wv = ricker((size_t)std::ceil(N), wd[r]);
      std::reverse(wv.begin(), wv.end());
      Vec full = convolveDirect(x, wv);
      const size_t st = (wv.size() - 1) / 2;
      for (size_t c = 0; c < cols; c++)
        cw(r, c) = full[st + c];
    }
    // The ridge lines, followed from the widest scale down.
    std::vector<std::vector<size_t>> maxima(rows);
    long start = -1;
    for (size_t r = 0; r < rows; r++) {
      for (size_t c = 1; c + 1 < cols; c++)
        if (cw(r, c) > cw(r, c - 1) && cw(r, c) > cw(r, c + 1))
          maxima[r].push_back(c);
      if (!maxima[r].empty())
        start = (long)r;
    }
    struct Ridge {
      std::vector<long> rows, cols;
      double gap;
    };
    std::vector<Ridge> live, done;
    if (start >= 0) {
      for (size_t c : maxima[(size_t)start])
        live.push_back({{start}, {(long)c}, 0.0});
      for (long row = start - 1; row >= 0; row--) {
        for (Ridge &l : live)
          l.gap += 1.0;
        std::vector<long> prev;
        for (const Ridge &l : live)
          prev.push_back(l.cols.back());
        for (size_t c : maxima[(size_t)row]) {
          long best = -1;
          double bd = kInf;
          for (size_t q = 0; q < prev.size(); q++) {
            const double d = std::fabs((double)c - (double)prev[q]);
            if (d < bd) {
              bd = d;
              best = (long)q;
            }
          }
          if (best >= 0 && bd <= wd[(size_t)row] / 4.0) {
            Ridge &l = live[(size_t)best];
            l.cols.push_back((long)c);
            l.rows.push_back(row);
            l.gap = 0.0;
          } else {
            live.push_back({{row}, {(long)c}, 0.0});
          }
        }
        for (size_t q = live.size(); q-- > 0;)
          if (live[q].gap > gap) {
            done.push_back(live[q]);
            live.erase(live.begin() + (long)q);
          }
      }
    }
    done.insert(done.end(), live.begin(), live.end());
    const double minLen = std::ceil((double)rows / 4.0);
    const size_t win = (size_t)std::ceil((double)cols / 20.0), hf = win / 2, odd = win % 2;
    Vec noises(cols);
    for (size_t i = 0; i < cols; i++) {
      const size_t st = i >= hf ? i - hf : 0, en = std::min(i + hf + odd, cols);
      Vec seg;
      for (size_t k = st; k < en; k++)
        seg.push_back(cw(0, k));
      std::sort(seg.begin(), seg.end());
      const double idx = noisePerc / 100.0 * (double)(seg.size() - 1);
      const size_t lowI = (size_t)idx;
      noises[i] = (double)lowI == idx ? seg[lowI] : seg[lowI] * ((double)(lowI + 1) - idx) + seg[lowI + 1] * (idx - (double)lowI);
    }
    std::vector<long> out;
    for (Ridge &l : done) {
      if ((double)l.rows.size() < minLen)
        continue;
      // The first entry after sorting by row is the smallest row, added last.
      std::vector<size_t> order(l.rows.size());
      for (size_t i = 0; i < order.size(); i++)
        order[i] = i;
      std::stable_sort(order.begin(), order.end(), [&](size_t p, size_t q) { return l.rows[p] < l.rows[q]; });
      const long r0 = l.rows[order[0]], c0 = l.cols[order[0]];
      if (std::fabs(cw((size_t)r0, (size_t)c0) / noises[(size_t)c0]) < minSnr)
        continue;
      out.push_back(c0);
    }
    std::sort(out.begin(), out.end());
    return indexValue(out);
  } SP_END
}

} // namespace scipy
} // namespace nc
