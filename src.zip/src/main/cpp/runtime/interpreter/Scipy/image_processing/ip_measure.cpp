// Labels and measurements of ndimage, and the watershed.
#include <deque>
#include <map>

#include "image_processing_main.h"
#include "ip_shared.h"

#define SP_SEC Section::ImageProcessing

namespace nc {
namespace scipy {

using namespace ip;

namespace {

// The cells a measurement covers: every cell, labels > 0, or one label.
struct Region {
  std::vector<size_t> cells;
};

bool getLabels(const Args &a, size_t i, CallContext &ctx, const Mat &m, Mat &lb, bool &has) {
  has = i < a.size() && !isOmitted(a, i);
  if (!has)
    return true;
  if (!getMat(a, i, ctx, lb))
    return false;
  if (lb.r != m.r || lb.c != m.c) {
    ctx.fail("labels must have the shape of the image");
    return false;
  }
  return true;
}

std::vector<Region> regionsOf(const Mat &m, const Mat &lb, bool hasLabels, const Vec &index, bool hasIndex) {
  if (!hasLabels) {
    Region r;
    for (size_t i = 0; i < m.a.size(); i++)
      r.cells.push_back(i);
    return {r};
  }
  if (!hasIndex) {
    Region r;
    for (size_t i = 0; i < m.a.size(); i++)
      if (lb.a[i] > 0.0)
        r.cells.push_back(i);
    return {r};
  }
  std::vector<Region> out(index.size());
  for (size_t k = 0; k < index.size(); k++)
    for (size_t i = 0; i < m.a.size(); i++)
      if (lb.a[i] == index[k])
        out[k].cells.push_back(i);
  return out;
}

bool getIndex(const Args &a, size_t i, CallContext &ctx, Vec &index, bool &has) {
  has = i < a.size() && (!isPlainNumber(a[i]) || a[i].number != 0.0);
  if (!has)
    return true;
  return getVec(a, i, ctx, index);
}

Value scalarsOrArray(const Vec &v, bool scalar) { return scalar ? Value(v.empty() ? 0.0 : v[0]) : toValue(v); }

// 0-based row and column of a cell, as rows of a matrix.
Value positions(const std::vector<size_t> &cells, size_t C, bool scalar) {
  if (scalar) {
    if (cells.empty())
      return toValue(Vec{kNaN, kNaN});
    return toValue(Vec{(double)(cells[0] / C), (double)(cells[0] % C)});
  }
  Mat o(cells.size(), 2);
  for (size_t i = 0; i < cells.size(); i++) {
    o(i, 0) = (double)(cells[i] / C);
    o(i, 1) = (double)(cells[i] % C);
  }
  return toValue(o);
}

size_t bestCell(const Mat &m, const Region &r, bool wantMax) {
  size_t b = r.cells.empty() ? 0 : r.cells[0];
  for (size_t c : r.cells)
    if (wantMax ? m.a[c] > m.a[b] : m.a[c] < m.a[b])
      b = c;
  return b;
}

// Reads a square 3 x 3 structure, or the cross.
bool neighbourOffsets(const Args &a, size_t i, CallContext &ctx, std::vector<std::pair<long, long>> &off) {
  Mat s;
  if (i < a.size() && !isOmitted(a, i)) {
    if (!getMat(a, i, ctx, s))
      return false;
    if (s.r != 3 || s.c != 3) {
      ctx.fail("the structure must be 3 x 3");
      return false;
    }
  } else {
    s = Mat(3, 3);
    s(0, 1) = s(1, 0) = s(1, 1) = s(1, 2) = s(2, 1) = 1.0;
  }
  for (long p = 0; p < 3; p++)
    for (long q = 0; q < 3; q++)
      if (s((size_t)p, (size_t)q) != 0.0 && (p != 1 || q != 1))
        off.push_back({p - 1, q - 1});
  return true;
}

} // namespace

void registerImageMeasure(Registry &reg) {
  SP_ADD("img_label", 1, 2, "mask, structure") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    std::vector<std::pair<long, long>> off;
    if (!neighbourOffsets(a, 1, ctx, off))
      return Value(0.0);
    if (line)
      off = {{0, -1}, {0, 1}};
    Mat lb(m.r, m.c);
    long count = 0;
    std::vector<size_t> stack;
    for (size_t start = 0; start < m.a.size(); start++) {
      if (m.a[start] == 0.0 || lb.a[start] != 0.0)
        continue;
      count++;
      lb.a[start] = (double)count;
      stack.push_back(start);
      while (!stack.empty()) {
        const size_t at = stack.back();
        stack.pop_back();
        const long r = (long)(at / m.c), c = (long)(at % m.c);
        for (const auto &o : off) {
          const long p = r + o.first, q = c + o.second;
          if (p < 0 || p >= (long)m.r || q < 0 || q >= (long)m.c)
            continue;
          const size_t n = (size_t)p * m.c + (size_t)q;
          if (m.a[n] != 0.0 && lb.a[n] == 0.0) {
            lb.a[n] = (double)count;
            stack.push_back(n);
          }
        }
      }
    }
    return makeDict({{"labels", line ? toValue(lb.a) : toValue(lb)}, {"count", Value((double)count)}});
  } SP_END
  SP_ADD("find_objects", 1, 1, "labels") {
    Mat lb;
    if (!getMat(a, 0, ctx, lb))
      return Value(0.0);
    double top = 0.0;
    for (double v : lb.a) {
      if (!std::isfinite(v) || v > 1e7) {
        ctx.fail("labels must be whole numbers from 0 to 10000000");
        return Value(0.0);
      }
      top = std::max(top, v);
    }
    const size_t n = (size_t)top;
    Mat o(n, 4, kNaN);
    for (size_t i = 0; i < lb.r; i++)
      for (size_t j = 0; j < lb.c; j++) {
        const double v = lb(i, j);
        if (v < 1.0)
          continue;
        const size_t k = (size_t)v - 1;
        if (std::isnan(o(k, 0))) {
          o(k, 0) = (double)i;
          o(k, 1) = (double)i + 1.0;
          o(k, 2) = (double)j;
          o(k, 3) = (double)j + 1.0;
        } else {
          o(k, 0) = std::min(o(k, 0), (double)i);
          o(k, 1) = std::max(o(k, 1), (double)i + 1.0);
          o(k, 2) = std::min(o(k, 2), (double)j);
          o(k, 3) = std::max(o(k, 3), (double)j + 1.0);
        }
      }
    return toValue(o);
  } SP_END
  SP_ADD("value_indices", 1, 2, "data, ignore") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    const bool skip = isNumberArg(a, 1);
    const double ig = optNum(a, 1, 0.0);
    std::map<double, std::pair<Vec, Vec>> groups;
    for (size_t i = 0; i < m.r; i++)
      for (size_t j = 0; j < m.c; j++) {
        if (skip && m(i, j) == ig)
          continue;
        auto &g = groups[m(i, j)];
        g.first.push_back((double)i);
        g.second.push_back((double)j);
      }
    DictInit d;
    for (const auto &e : groups) {
      const double v = e.first;
      const std::string key = v == std::floor(v) && std::fabs(v) < 1e15 ? std::to_string((long long)v) : std::to_string(v);
      d.push_back({key, makeDict({{"rows", toValue(e.second.first)}, {"cols", toValue(e.second.second)}})});
    }
    return makeDict(d);
  } SP_END
  SP_ADD("labeled_apply", 4, 5, "img, labels, index, fn, default=0") {
    Mat m, lb;
    Vec idx;
    bool has;
    if (!getMat(a, 0, ctx, m) || !getLabels(a, 1, ctx, m, lb, has) || !getVec(a, 2, ctx, idx))
      return Value(0.0);
    if (!has) {
      ctx.fail("labels are needed");
      return Value(0.0);
    }
    if (!isCallable(a[3])) {
      ctx.fail("the fourth argument must name an NC function");
      return Value(0.0);
    }
    const double def = optNum(a, 4, 0.0);
    NcFn f(a[3]);
    Vec o;
    for (double k : idx) {
      Vec vals;
      for (size_t i = 0; i < m.a.size(); i++)
        if (lb.a[i] == k)
          vals.push_back(m.a[i]);
      o.push_back(vals.empty() ? def : f.ofVec(vals));
      if (f.failed) {
        ctx.fail(f.failText());
        return Value(0.0);
      }
    }
    return isPlainNumber(a[2]) ? Value(o[0]) : toValue(o);
  } SP_END
  SP_ADD("center_of_mass", 1, 3, "img, labels, index") {
    Mat m, lb;
    bool has, hasI;
    Vec idx;
    if (!getMat(a, 0, ctx, m) || !getLabels(a, 1, ctx, m, lb, has) || !getIndex(a, 2, ctx, idx, hasI))
      return Value(0.0);
    const std::vector<Region> rs = regionsOf(m, lb, has, idx, has && hasI);
    Mat o(rs.size(), 2);
    for (size_t k = 0; k < rs.size(); k++) {
      double s = 0.0, sr = 0.0, sc = 0.0;
      for (size_t c : rs[k].cells) {
        s += m.a[c];
        sr += m.a[c] * (double)(c / m.c);
        sc += m.a[c] * (double)(c % m.c);
      }
      o(k, 0) = sr / s;
      o(k, 1) = sc / s;
    }
    if (rs.size() == 1)
      return toValue(o.a);
    return toValue(o);
  } SP_END
  SP_ADD("img_extrema", 1, 3, "img, labels, index") {
    Mat m, lb;
    bool has, hasI;
    Vec idx;
    if (!getMat(a, 0, ctx, m) || !getLabels(a, 1, ctx, m, lb, has) || !getIndex(a, 2, ctx, idx, hasI))
      return Value(0.0);
    const std::vector<Region> rs = regionsOf(m, lb, has, idx, has && hasI);
    Vec mn, mx;
    std::vector<size_t> pmin, pmax;
    for (const Region &r : rs) {
      if (r.cells.empty()) {
        ctx.fail("a label has no cells");
        return Value(0.0);
      }
      const size_t b0 = bestCell(m, r, false), b1 = bestCell(m, r, true);
      mn.push_back(m.a[b0]);
      mx.push_back(m.a[b1]);
      pmin.push_back(b0);
      pmax.push_back(b1);
    }
    const bool one = rs.size() == 1;
    return makeDict({{"min", scalarsOrArray(mn, one)}, {"max", scalarsOrArray(mx, one)}, {"min_pos", positions(pmin, m.c, one)}, {"max_pos", positions(pmax, m.c, one)}});
  } SP_END
  SP_ADD("img_histogram", 4, 6, "img, min, max, bins, labels, index") {
    Mat m, lb;
    bool has, hasI;
    Vec idx;
    if (!getMat(a, 0, ctx, m) || !getLabels(a, 4, ctx, m, lb, has) || !getIndex(a, 5, ctx, idx, hasI))
      return Value(0.0);
    const double lo = optNum(a, 1, 0.0), hi = optNum(a, 2, 1.0);
    const long long bins = optInt(a, 3, 10);
    if (bins < 1 || !(hi > lo)) {
      ctx.fail("bins must be 1 or more, and max above min");
      return Value(0.0);
    }
    const std::vector<Region> rs = regionsOf(m, lb, has, idx, has && hasI);
    Mat H(rs.size(), (size_t)bins);
    const double w = (hi - lo) / (double)bins;
    for (size_t k = 0; k < rs.size(); k++)
      for (size_t c : rs[k].cells) {
        const double v = m.a[c];
        if (v < lo || v > hi)
          continue;
        size_t b = v == hi ? (size_t)bins - 1 : (size_t)((v - lo) / w);
        if (b >= (size_t)bins)
          b = (size_t)bins - 1;
        H(k, b) += 1.0;
      }
    return rs.size() == 1 ? toValue(H.a) : toValue(H);
  } SP_END
#define IP_ARGPOS(NAME, MAX)                                                                       \
  SP_ADD(NAME, 1, 3, "img, labels, index") {                                                       \
    Mat m, lb;                                                                                     \
    bool has, hasI;                                                                                \
    Vec idx;                                                                                       \
    if (!getMat(a, 0, ctx, m) || !getLabels(a, 1, ctx, m, lb, has) || !getIndex(a, 2, ctx, idx, hasI)) \
      return Value(0.0);                                                                           \
    const std::vector<Region> rs = regionsOf(m, lb, has, idx, has && hasI);                        \
    std::vector<size_t> p;                                                                         \
    for (const Region &r : rs)                                                                     \
      p.push_back(bestCell(m, r, MAX));                                                            \
    return positions(p, m.c, rs.size() == 1);                                                      \
  } SP_END
  IP_ARGPOS("img_argmax", true)
  IP_ARGPOS("img_argmin", false)
  SP_ADD("img_sum", 1, 3, "img, labels, index") {
    Mat m, lb;
    bool has, hasI;
    Vec idx;
    if (!getMat(a, 0, ctx, m) || !getLabels(a, 1, ctx, m, lb, has) || !getIndex(a, 2, ctx, idx, hasI))
      return Value(0.0);
    const std::vector<Region> rs = regionsOf(m, lb, has, idx, has && hasI);
    Vec o;
    for (const Region &r : rs) {
      double s = 0.0;
      for (size_t c : r.cells)
        s += m.a[c];
      o.push_back(s);
    }
    return has && hasI && !isPlainNumber(a[2]) ? toValue(o) : Value(o[0]);
  } SP_END
  SP_ADD("watershed", 2, 3, "img, markers, structure") {
    // The image foresting transform: cost of a path = its largest step between neighbours.
    Mat m, mk;
    if (!getMat(a, 0, ctx, m) || !getMat(a, 1, ctx, mk))
      return Value(0.0);
    if (mk.r != m.r || mk.c != m.c) {
      ctx.fail("markers must have the shape of the image");
      return Value(0.0);
    }
    std::vector<std::pair<long, long>> off;
    if (!neighbourOffsets(a, 2, ctx, off))
      return Value(0.0);
    double top = 0.0;
    for (double v : m.a) {
      if (v < 0.0 || v > 65535.0 || v != std::floor(v)) {
        ctx.fail("the image must hold whole numbers from 0 to 65535");
        return Value(0.0);
      }
      top = std::max(top, v);
    }
    const size_t levels = (size_t)top + 1, n = m.a.size();
    Vec cost(n, top + 1.0);
    std::vector<char> done(n, 0);
    Mat out = mk;
    std::vector<std::deque<size_t>> q(levels);
    for (size_t i = 0; i < n; i++)
      if (mk.a[i] != 0.0) {
        cost[i] = 0.0;
        q[0].push_back(i);
      }
    for (size_t lv = 0; lv < levels; lv++) {
      while (!q[lv].empty()) {
        const size_t p = q[lv].front();
        q[lv].pop_front();
        if (done[p] || cost[p] != (double)lv)
          continue;
        done[p] = 1;
        const long r = (long)(p / m.c), c = (long)(p % m.c);
        for (const auto &o : off) {
          const long x = r + o.first, y = c + o.second;
          if (x < 0 || x >= (long)m.r || y < 0 || y >= (long)m.c)
            continue;
          const size_t t = (size_t)x * m.c + (size_t)y;
          if (done[t])
            continue;
          const double v = std::max((double)lv, std::fabs(m.a[t] - m.a[p]));
          if (v < cost[t]) {
            cost[t] = v;
            out.a[t] = out.a[p];
            q[(size_t)v].push_back(t);
          }
        }
      }
    }
    return toValue(out);
  } SP_END
}

} // namespace scipy
} // namespace nc
