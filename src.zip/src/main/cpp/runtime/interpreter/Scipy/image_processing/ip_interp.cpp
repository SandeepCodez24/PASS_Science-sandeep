// Interpolation of ndimage: B-spline prefilters, map_coordinates and the transforms
// built on it, and the Fourier-domain filters.
#include "../fourier_transforms/ft_shared.h"
#include "image_processing_main.h"
#include "ip_shared.h"

#define SP_SEC Section::ImageProcessing

namespace nc {
namespace scipy {

using namespace ip;

namespace {

Vec polesOf(int order) {
  switch (order) {
  case 2:
    return {std::sqrt(8.0) - 3.0};
  case 3:
    return {std::sqrt(3.0) - 2.0};
  case 4:
    return {std::sqrt(664.0 - std::sqrt(438976.0)) + std::sqrt(304.0) - 19.0, std::sqrt(664.0 + std::sqrt(438976.0)) - std::sqrt(304.0) - 19.0};
  case 5:
    return {std::sqrt(67.5 - std::sqrt(4436.25)) + std::sqrt(26.25) - 6.5, std::sqrt(67.5 + std::sqrt(4436.25)) - std::sqrt(26.25) - 6.5};
  default:
    return {};
  }
}

// One line of the prefilter, in place. scipy's three boundary families.
void splineLine(Vec &c, int order, int mode) {
  const long n = (long)c.size();
  if (n == 1)
    return;
  const Vec poles = polesOf(order);
  double gain = 1.0;
  for (double z : poles)
    gain *= (1.0 - z) * (1.0 - 1.0 / z);
  for (double &v : c)
    v *= gain;
  for (double z : poles) {
    double zi = z;
    if (mode == kGridWrap) {
      for (long i = 1; i < n; i++) {
        c[0] += zi * c[(size_t)(n - i)];
        zi *= z;
      }
      c[0] /= 1.0 - zi;
    } else if (mode == kReflect) {
      const double zn = std::pow(z, (double)n), c0 = c[0];
      c[0] = c[0] + zn * c[(size_t)(n - 1)];
      for (long i = 1; i < n; i++) {
        c[0] += zi * (c[(size_t)i] + zn * c[(size_t)(n - 1 - i)]);
        zi *= z;
      }
      c[0] *= z / (1.0 - zn * zn);
      c[0] += c0;
    } else {
      const double zn1 = std::pow(z, (double)(n - 1));
      c[0] = c[0] + zn1 * c[(size_t)(n - 1)];
      for (long i = 1; i < n - 1; i++) {
        c[0] += zi * (c[(size_t)i] + zn1 * c[(size_t)(n - 1 - i)]);
        zi *= z;
      }
      c[0] /= 1.0 - zn1 * zn1;
    }
    for (long i = 1; i < n; i++)
      c[(size_t)i] += z * c[(size_t)(i - 1)];
    if (mode == kGridWrap) {
      zi = z;
      for (long i = 0; i < n - 1; i++) {
        c[(size_t)(n - 1)] += zi * c[(size_t)i];
        zi *= z;
      }
      c[(size_t)(n - 1)] *= z / (zi - 1.0);
    } else if (mode == kReflect) {
      c[(size_t)(n - 1)] *= z / (z - 1.0);
    } else {
      c[(size_t)(n - 1)] = (z * c[(size_t)(n - 2)] + c[(size_t)(n - 1)]) * z / (z * z - 1.0);
    }
    for (long i = n - 2; i >= 0; i--)
      c[(size_t)i] = z * (c[(size_t)(i + 1)] - c[(size_t)i]);
  }
}

// The boundary used by the prefilter for an interpolation mode.
int splineBoundary(int mode) { return mode == kReflect ? kReflect : (mode == kGridWrap ? kGridWrap : kMirror); }

Mat splineFilter2(const Mat &m, int order, int mode) {
  auto fn = [&](const Vec &v) {
    Vec c = v;
    splineLine(c, order, mode);
    return c;
  };
  Mat o = m;
  if (m.r > 1)
    o = alongAxis(o, 0, fn);
  if (m.c > 1)
    o = alongAxis(o, 1, fn);
  return o;
}

double bsplineBasis(int n, double t) {
  if (n == 0)
    return t >= -0.5 && t < 0.5 ? 1.0 : 0.0;
  const double h = (n + 1) / 2.0;
  return ((t + h) * bsplineBasis(n - 1, t + 0.5) + (h - t) * bsplineBasis(n - 1, t - 0.5)) / n;
}

// Where a coordinate lands; -1 means "use the constant".
double mapCoordinate(double in, long len, int mode) {
  if (in < 0.0) {
    if (mode == kMirror) {
      if (len <= 1)
        return 0.0;
      const long sz = 2 * len - 2;
      in = (double)(sz * (long)(-in / (double)sz)) + in;
      return in <= (double)(1 - len) ? in + (double)sz : -in;
    }
    if (mode == kReflect) {
      if (len <= 1)
        return 0.0;
      const long sz = 2 * len;
      if (in < -(double)sz)
        in = (double)(sz * (long)(-in / (double)sz)) + in;
      return in < -(double)len ? in + (double)sz : (in > -1e-15 ? 1e-15 : -in) - 1.0;
    }
    if (mode == kWrap) {
      if (len <= 1)
        return 0.0;
      const long sz = len - 1;
      return in + (double)(sz * ((long)(-in / (double)sz) + 1));
    }
    if (mode == kGridWrap) {
      if (len <= 1)
        return 0.0;
      return in + (double)(len * ((long)((-1.0 - in) / (double)len) + 1));
    }
    if (mode == kNearest)
      return 0.0;
    return -1.0;
  }
  if (in > (double)(len - 1)) {
    if (mode == kMirror) {
      if (len <= 1)
        return 0.0;
      const long sz = 2 * len - 2;
      in -= (double)(sz * (long)(in / (double)sz));
      return in >= (double)len ? (double)sz - in : in;
    }
    if (mode == kReflect) {
      if (len <= 1)
        return 0.0;
      const long sz = 2 * len;
      in -= (double)(sz * (long)(in / (double)sz));
      return in >= (double)len ? (double)sz - in - 1.0 : in;
    }
    if (mode == kWrap) {
      if (len <= 1)
        return 0.0;
      const long sz = len - 1;
      return in - (double)(sz * (long)(in / (double)sz));
    }
    if (mode == kGridWrap) {
      if (len <= 1)
        return 0.0;
      return in - (double)(len * (long)(in / (double)len));
    }
    if (mode == kNearest)
      return (double)(len - 1);
    return -1.0;
  }
  return in;
}

struct Interp {
  Mat coef;
  int order = 3, mode = kConstant;
  double cval = 0.0;
  long pad = 0;
};

bool prepare(const Mat &m, int order, int mode, double cval, Interp &ip, CallContext &ctx) {
  if (order < 0 || order > 5) {
    ctx.fail("the spline order must be from 0 to 5");
    return false;
  }
  ip.order = order;
  ip.mode = mode;
  ip.cval = cval;
  ip.coef = m;
  if (order > 1) {
    if (mode == kNearest) {
      // scipy pads the edges before filtering, for this mode only.
      ip.pad = 12;
      const size_t R = m.r + 24, C = m.c + 24;
      Mat P(R, C);
      for (size_t i = 0; i < R; i++)
        for (size_t j = 0; j < C; j++) {
          const long ii = std::min((long)m.r - 1, std::max(0L, (long)i - 12)), jj = std::min((long)m.c - 1, std::max(0L, (long)j - 12));
          P(i, j) = m((size_t)ii, (size_t)jj);
        }
      ip.coef = P;
    }
    ip.coef = splineFilter2(ip.coef, order, splineBoundary(mode));
  }
  return true;
}

double interpAt(const Interp &ip, double r, double c) {
  const Mat &m = ip.coef;
  const int order = ip.order;
  const double cr = mapCoordinate(r + (double)ip.pad, (long)m.r, ip.mode), cc = mapCoordinate(c + (double)ip.pad, (long)m.c, ip.mode);
  if (cr <= -1.0 || cc <= -1.0)
    return ip.cval;
  const long sr = order & 1 ? (long)std::floor(cr) - order / 2 : (long)std::floor(cr + 0.5) - order / 2;
  const long sc = order & 1 ? (long)std::floor(cc) - order / 2 : (long)std::floor(cc + 0.5) - order / 2;
  const int bnd = ip.mode == kConstant || ip.mode == kWrap || ip.mode == kNearest ? kMirror : ip.mode;
  double wr[6], wc[6];
  for (int i = 0; i <= order; i++) {
    wr[i] = order == 0 ? 1.0 : bsplineBasis(order, cr - (double)(sr + i));
    wc[i] = order == 0 ? 1.0 : bsplineBasis(order, cc - (double)(sc + i));
  }
  auto idx = [&](long i, long n) { return (long)mapCoordinate((double)i, n, bnd); };
  double out = 0.0;
  for (int i = 0; i <= order; i++) {
    const long ii = idx(sr + i, (long)m.r);
    if (wr[i] == 0.0)
      continue;
    double row = 0.0;
    for (int j = 0; j <= order; j++)
      row += wc[j] * m((size_t)ii, (size_t)idx(sc + j, (long)m.c));
    out += wr[i] * row;
  }
  return out;
}

// Common tail: order, mode, cval.
bool interpOpts(const Args &a, size_t i, int &order, int &mode, double &cval, CallContext &ctx) {
  order = i < a.size() && isPlainNumber(a[i]) ? (int)a[i].number : 3;
  if (!parseMode(a, i + 1, ctx, mode, "constant"))
    return false;
  cval = optNum(a, i + 2, 0.0);
  return true;
}

double cosDeg(double d) {
  d = std::fmod(std::fabs(d), 360.0);
  if (d == 90.0 || d == 270.0)
    return 0.0;
  if (d == 0.0)
    return 1.0;
  if (d == 180.0)
    return -1.0;
  return std::cos(d * kPi / 180.0);
}
double sinDeg(double d) {
  const double sign = d < 0.0 ? -1.0 : 1.0;
  d = std::fmod(std::fabs(d), 360.0);
  if (d == 0.0 || d == 180.0)
    return 0.0;
  if (d == 90.0)
    return sign;
  if (d == 270.0)
    return -sign;
  return sign * std::sin(d * kPi / 180.0);
}

double besselJ1(double x) {
  const double ax = std::fabs(x);
  double r;
  if (ax < 8.0) {
    double term = ax / 2.0, sum = term;
    const double q = -ax * ax / 4.0;
    for (int k = 1; k < 60; k++) {
      term *= q / ((double)k * (double)(k + 1));
      sum += term;
    }
    r = sum;
  } else {
    // Hankel's asymptotic form.
    const double z = 8.0 / ax, y = z * z, xx = ax - 2.356194491;
    const double p = 1.0 + y * (0.183105e-2 + y * (-0.3516396496e-4 + y * (0.2457520174e-5 + y * (-0.240337019e-6))));
    const double q = 0.04687499995 + y * (-0.2002690873e-3 + y * (0.8449199096e-5 + y * (-0.88228987e-6 + y * 0.105787412e-6)));
    r = std::sqrt(0.636619772 / ax) * (std::cos(xx) * p - z * std::sin(xx) * q);
  }
  return x < 0.0 ? -r : r;
}

// The FFT frequency index along an axis of `shape` (negative above the middle),
// or just the index for one-sided input (n >= 0 given).
double freqIndex(size_t k, size_t shape, bool oneSided) {
  if (oneSided)
    return (double)k;
  return k < (shape + 1) / 2 ? (double)k : (double)k - (double)shape;
}

struct FourierShape {
  size_t r, c;
  double shapeR, shapeC;
  bool oneSidedC, oneSidedR, line;
};

bool fourierInput(const Args &a, size_t iN, CallContext &ctx, CMat &F, FourierShape &fs, Vec &vals, size_t iVal) {
  if (!getCMat(a, 0, ctx, F))
    return false;
  fs.line = ft::isLine(a[0]);
  if (fs.line && F.c == 1 && F.r > 1)
    F = transposeOf(F);
  if (!getVec(a, iVal, ctx, vals))
    return false;
  if (vals.size() != 1 && vals.size() != (fs.line ? 1u : 2u)) {
    ctx.fail("give one value, or one value per axis");
    return false;
  }
  if (vals.size() == 1)
    vals.assign(2, double(vals[0]));
  else if (vals.size() == 2 && fs.line) {
    ctx.fail("give one value for an Array");
    return false;
  }
  const long n = iN < a.size() && isPlainNumber(a[iN]) ? (long)a[iN].number : -1;
  const long axis = iN + 1 < a.size() && isPlainNumber(a[iN + 1]) ? (long)a[iN + 1].number : -1;
  fs.r = F.r;
  fs.c = F.c;
  fs.shapeR = (double)F.r;
  fs.shapeC = (double)F.c;
  fs.oneSidedR = fs.oneSidedC = false;
  if (n > 0) {
    if (axis == 0 && !fs.line) {
      fs.oneSidedR = true;
      fs.shapeR = (double)n;
    } else {
      fs.oneSidedC = true;
      fs.shapeC = (double)n;
    }
  }
  return true;
}

Value fourierResult(const CMat &O, bool line) { return line ? toValue(O.a) : toValue(O); }

} // namespace

void registerImageInterp(Registry &reg) {
  SP_ADD("spline_filter", 1, 3, "img, order=3, mode=\"mirror\"") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    const long long order = a.size() > 1 && isPlainNumber(a[1]) ? (long long)a[1].number : 3;
    if (order < 2 || order > 5) {
      ctx.fail("the spline order must be from 2 to 5");
      return Value(0.0);
    }
    int mode;
    if (!parseMode(a, 2, ctx, mode, "mirror"))
      return Value(0.0);
    Mat o = splineFilter2(m, (int)order, splineBoundary(mode));
    return line ? toValue(o.a) : toValue(o);
  } SP_END
  SP_ADD("spline_filter1d", 1, 4, "data, order=3, axis=-1, mode=\"mirror\"") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    const long long order = a.size() > 1 && isPlainNumber(a[1]) ? (long long)a[1].number : 3;
    if (order < 0 || order > 5) {
      ctx.fail("the spline order must be from 0 to 5");
      return Value(0.0);
    }
    const long long axisIn = a.size() > 2 && isPlainNumber(a[2]) ? (long long)a[2].number : -1;
    int mode;
    if (!parseMode(a, 3, ctx, mode, "mirror"))
      return Value(0.0);
    const int axis = line ? 1 : (axisIn == 0 ? 0 : 1);
    Mat o = m;
    if (order >= 2)
      o = alongAxis(m, axis, [&](const Vec &v) {
        Vec c = v;
        splineLine(c, (int)order, splineBoundary(mode));
        return c;
      });
    return line ? toValue(o.a) : toValue(o);
  } SP_END
  SP_ADD("map_coordinates", 2, 5, "img, coords, order=3, mode=\"constant\", cval=0") {
    Mat m, co;
    if (!getMat(a, 0, ctx, m) || !getMat(a, 1, ctx, co))
      return Value(0.0);
    if (co.r != 2) {
      ctx.fail("coords needs two rows: row positions, then column positions");
      return Value(0.0);
    }
    int order, mode;
    double cval;
    if (!interpOpts(a, 2, order, mode, cval, ctx))
      return Value(0.0);
    Interp ip;
    if (!prepare(m, order, mode, cval, ip, ctx))
      return Value(0.0);
    Vec o(co.c);
    for (size_t j = 0; j < co.c; j++)
      o[j] = interpAt(ip, co(0, j), co(1, j));
    return toValue(o);
  } SP_END
  SP_ADD("affine_transform", 2, 7, "img, matrix, offset=0, order=3, mode=\"constant\", cval=0, shape") {
    Mat m, M;
    if (!getMat(a, 0, ctx, m) || !getMat(a, 1, ctx, M))
      return Value(0.0);
    Vec off{0.0, 0.0};
    if (a.size() > 2 && !isOmitted(a, 2)) {
      Vec v;
      if (!getVec(a, 2, ctx, v))
        return Value(0.0);
      if (v.size() == 1)
        off = {v[0], v[0]};
      else if (v.size() == 2)
        off = v;
      else {
        ctx.fail("offset must be one number or [rows, cols]");
        return Value(0.0);
      }
    }
    double A[2][2] = {{1, 0}, {0, 1}};
    if (M.a.size() == 2) { // a diagonal given as an Array
      A[0][0] = M.a[0];
      A[1][1] = M.a[1];
    } else if ((M.r == 2 && (M.c == 2 || M.c == 3)) || (M.r == 3 && M.c == 3)) {
      A[0][0] = M(0, 0);
      A[0][1] = M(0, 1);
      A[1][0] = M(1, 0);
      A[1][1] = M(1, 1);
      if (M.c == 3) {
        off = {M(0, 2), M(1, 2)};
      }
    } else {
      ctx.fail("matrix must be 2 x 2, 2 x 3, 3 x 3, or a diagonal of two values");
      return Value(0.0);
    }
    int order, mode;
    double cval;
    if (!interpOpts(a, 3, order, mode, cval, ctx))
      return Value(0.0);
    size_t R = m.r, C = m.c;
    if (a.size() > 6 && !isOmitted(a, 6)) {
      Vec s;
      if (!getVec(a, 6, ctx, s) || s.size() != 2) {
        ctx.fail("shape must be [rows, cols]");
        return Value(0.0);
      }
      R = (size_t)s[0];
      C = (size_t)s[1];
    }
    Interp ip;
    if (!prepare(m, order, mode, cval, ip, ctx))
      return Value(0.0);
    Mat o(R, C);
    for (size_t i = 0; i < R; i++)
      for (size_t j = 0; j < C; j++)
        o(i, j) = interpAt(ip, A[0][0] * (double)i + A[0][1] * (double)j + off[0], A[1][0] * (double)i + A[1][1] * (double)j + off[1]);
    return toValue(o);
  } SP_END
  SP_ADD("geometric_transform", 2, 5, "img, fn, order=3, mode=\"constant\", cval=0") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    if (!isCallable(a[1])) {
      ctx.fail("the second argument must name an NC function taking [row, col] and returning [row, col]");
      return Value(0.0);
    }
    int order, mode;
    double cval;
    if (!interpOpts(a, 2, order, mode, cval, ctx))
      return Value(0.0);
    Interp ip;
    if (!prepare(m, order, mode, cval, ip, ctx))
      return Value(0.0);
    NcFn f(a[1]);
    Mat o(m.r, m.c);
    for (size_t i = 0; i < m.r && !f.failed; i++)
      for (size_t j = 0; j < m.c && !f.failed; j++) {
        Vec p = f.vecOfVec({(double)i, (double)j});
        if (f.failed || p.size() != 2) {
          ctx.fail(f.failed ? f.failText() : "the function must return [row, col]");
          return Value(0.0);
        }
        o(i, j) = interpAt(ip, p[0], p[1]);
      }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return toValue(o);
  } SP_END
  SP_ADD("img_rotate", 2, 6, "img, angle, reshape=1, order=3, mode=\"constant\", cval=0") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    const double angle = optNum(a, 1, 0.0), c = cosDeg(angle), s = sinDeg(angle);
    if (!std::isfinite(angle)) {
      ctx.fail("the angle must be a finite number");
      return Value(0.0);
    }
    const bool reshape = a.size() > 2 && isPlainNumber(a[2]) ? a[2].number != 0.0 : true;
    int order, mode;
    double cval;
    if (!interpOpts(a, 3, order, mode, cval, ctx))
      return Value(0.0);
    // scipy's rotation acts on the plane (axis 0, axis 1) with [[c, s], [-s, c]].
    const double iy = (double)m.r, ix = (double)m.c;
    size_t R = m.r, C = m.c;
    if (reshape) {
      const double xs[4] = {0.0, 0.0, iy, iy}, ys[4] = {0.0, ix, 0.0, ix};
      double r0 = kInf, r1 = -kInf, c0 = kInf, c1 = -kInf;
      for (int k = 0; k < 4; k++) {
        const double u = c * xs[k] + s * ys[k], v = -s * xs[k] + c * ys[k];
        r0 = std::min(r0, u);
        r1 = std::max(r1, u);
        c0 = std::min(c0, v);
        c1 = std::max(c1, v);
      }
      R = (size_t)(r1 - r0 + 0.5);
      C = (size_t)(c1 - c0 + 0.5);
    }
    const double oy = ((double)R - 1.0) / 2.0, ox = ((double)C - 1.0) / 2.0;
    const double offR = (iy - 1.0) / 2.0 - (c * oy + s * ox), offC = (ix - 1.0) / 2.0 - (-s * oy + c * ox);
    Interp ip;
    if (!prepare(m, order, mode, cval, ip, ctx))
      return Value(0.0);
    Mat o(R, C);
    for (size_t i = 0; i < R; i++)
      for (size_t j = 0; j < C; j++)
        o(i, j) = interpAt(ip, c * (double)i + s * (double)j + offR, -s * (double)i + c * (double)j + offC);
    return toValue(o);
  } SP_END
  SP_ADD("img_shift", 2, 5, "img, shift, order=3, mode=\"constant\", cval=0") {
    Mat m;
    Vec sh;
    if (!getMat(a, 0, ctx, m) || !getVec(a, 1, ctx, sh))
      return Value(0.0);
    if (sh.size() == 1)
      sh.assign(2, double(sh[0]));
    if (sh.size() != 2) {
      ctx.fail("shift must be one number or [rows, cols]");
      return Value(0.0);
    }
    int order, mode;
    double cval;
    if (!interpOpts(a, 2, order, mode, cval, ctx))
      return Value(0.0);
    Interp ip;
    if (!prepare(m, order, mode, cval, ip, ctx))
      return Value(0.0);
    Mat o(m.r, m.c);
    for (size_t i = 0; i < m.r; i++)
      for (size_t j = 0; j < m.c; j++)
        o(i, j) = interpAt(ip, (double)i - sh[0], (double)j - sh[1]);
    return toValue(o);
  } SP_END
  SP_ADD("img_zoom", 2, 5, "img, factor, order=3, mode=\"constant\", cval=0") {
    Mat m;
    Vec fa;
    if (!getMat(a, 0, ctx, m) || !getVec(a, 1, ctx, fa))
      return Value(0.0);
    if (fa.size() == 1)
      fa.assign(2, double(fa[0]));
    if (fa.size() != 2) {
      ctx.fail("factor must be one number or [rows, cols]");
      return Value(0.0);
    }
    int order, mode;
    double cval;
    if (!interpOpts(a, 2, order, mode, cval, ctx))
      return Value(0.0);
    if (!(fa[0] > 0.0) || !(fa[1] > 0.0) || (double)m.r * fa[0] * (double)m.c * fa[1] > 1e7) {
      ctx.fail("factor must be positive, and the result at most 10000000 values");
      return Value(0.0);
    }
    const size_t R = (size_t)std::nearbyint((double)m.r * fa[0]), C = (size_t)std::nearbyint((double)m.c * fa[1]);
    if (R < 1 || C < 1) {
      ctx.fail("this factor leaves an empty image");
      return Value(0.0);
    }
    const double zr = R > 1 ? ((double)m.r - 1.0) / ((double)R - 1.0) : 1.0, zc = C > 1 ? ((double)m.c - 1.0) / ((double)C - 1.0) : 1.0;
    Interp ip;
    if (!prepare(m, order, mode, cval, ip, ctx))
      return Value(0.0);
    Mat o(R, C);
    for (size_t i = 0; i < R; i++)
      for (size_t j = 0; j < C; j++)
        o(i, j) = interpAt(ip, (double)i * zr, (double)j * zc);
    return toValue(o);
  } SP_END
  // ---- Fourier-domain filters ----
#define IP_FOURIER(NAME, ...)                                                                      \
  SP_ADD(NAME, 2, 4, "F, value, n=-1, axis=-1") {                                                  \
    CMat F;                                                                                        \
    FourierShape fs;                                                                               \
    Vec vals;                                                                                      \
    if (!fourierInput(a, 2, ctx, F, fs, vals, 1))                                                  \
      return Value(0.0);                                                                           \
    CMat O = F;                                                                                    \
    for (size_t i = 0; i < F.r; i++) {                                                             \
      const double kr = fs.line ? 0.0 : freqIndex(i, F.r, fs.oneSidedR);                           \
      for (size_t j = 0; j < F.c; j++) {                                                           \
        const double kc = freqIndex(j, F.c, fs.oneSidedC);                                         \
        cd w(1.0);                                                                                 \
        __VA_ARGS__;                                                                                \
        O(i, j) = F(i, j) * w;                                                                     \
      }                                                                                            \
    }                                                                                              \
    return fourierResult(O, fs.line);                                                              \
  } SP_ENDC
  IP_FOURIER("fourier_gaussian", {
    const double tr = kPi * vals[0] * kr / fs.shapeR, tc = kPi * vals[1] * kc / fs.shapeC;
    w = std::exp(-2.0 * (tr * tr + tc * tc));
  })
  IP_FOURIER("fourier_uniform", {
    const double tr = kPi * vals[0] * kr / fs.shapeR, tc = kPi * vals[1] * kc / fs.shapeC;
    double v = 1.0;
    if (tr != 0.0)
      v *= std::sin(tr) / tr;
    if (tc != 0.0)
      v *= std::sin(tc) / tc;
    w = v;
  })
  IP_FOURIER("fourier_shift", {
    w = std::polar(1.0, -2.0 * kPi * (vals[0] * kr / fs.shapeR + vals[1] * kc / fs.shapeC));
  })
  IP_FOURIER("fourier_ellipsoid", {
    const double tr = kPi * vals[0] * kr / fs.shapeR, tc = kPi * vals[1] * kc / fs.shapeC;
    const double t = std::sqrt(tr * tr + tc * tc);
    if (t > 0.0)
      w = fs.line ? std::sin(t) / t : 2.0 * besselJ1(t) / t;
  })
}

} // namespace scipy
} // namespace nc
