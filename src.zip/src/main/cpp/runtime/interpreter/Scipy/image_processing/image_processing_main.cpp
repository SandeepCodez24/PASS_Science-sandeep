// Section 11 of 25 - Image Processing (scipy.ndimage), for 1-D and 2-D data: an Array
// is one line, a Matrix an image. Boundaries follow ndimage's five modes. Filters
// and morphology are here; interpolation is in ip_interp.cpp, measurements in
// ip_measure.cpp.
#include "image_processing_main.h"

#include "../fourier_transforms/ft_shared.h"
#include "ip_shared.h"

#define SP_SEC Section::ImageProcessing

namespace nc {
namespace scipy {
namespace ip {

bool parseMode(const Args &a, size_t i, CallContext &ctx, int &mode, const std::string &def) {
  const std::string m = i < a.size() && a[i].isText ? a[i].text() : def;
  if (m == "reflect" || m == "grid-mirror")
    mode = kReflect;
  else if (m == "constant")
    mode = kConstant;
  else if (m == "nearest")
    mode = kNearest;
  else if (m == "mirror")
    mode = kMirror;
  else if (m == "wrap")
    mode = kWrap;
  else if (m == "grid-wrap")
    mode = kGridWrap;
  else {
    ctx.fail("mode must be \"reflect\", \"constant\", \"nearest\", \"mirror\" or \"wrap\"");
    return false;
  }
  return true;
}

long extIndex(long i, long n, int mode) {
  if (i >= 0 && i < n)
    return i;
  switch (mode) {
  case kConstant:
    return -1;
  case kNearest:
    return i < 0 ? 0 : n - 1;
  case kWrap:
  case kGridWrap:
    return ((i % n) + n) % n;
  case kMirror: {
    if (n == 1)
      return 0;
    const long p = 2 * n - 2;
    const long m = ((i % p) + p) % p;
    return m < n ? m : p - m;
  }
  default: {
    const long p = 2 * n;
    const long m = ((i % p) + p) % p;
    return m < n ? m : p - 1 - m;
  }
  }
}

Vec correlateLine(const Vec &x, const Vec &w, long origin, int mode, double cval) {
  const long n = (long)x.size(), L = (long)w.size(), c = L / 2 + origin;
  Vec o((size_t)n, 0.0);
  for (long i = 0; i < n; i++) {
    double s = 0.0;
    for (long j = 0; j < L; j++) {
      const double wj = w[(size_t)j];
      if (wj == 0.0)
        continue;
      const long k = extIndex(i + j - c, n, mode);
      s += wj * (k < 0 ? cval : x[(size_t)k]);
    }
    o[(size_t)i] = s;
  }
  return o;
}

Mat alongAxis(const Mat &m, int axis, const std::function<Vec(const Vec &)> &f) {
  Mat o = m;
  if (axis == 1) {
    for (size_t i = 0; i < m.r; i++) {
      Vec r = f(Vec(m.row(i), m.row(i) + m.c));
      std::copy(r.begin(), r.end(), o.row(i));
    }
  } else {
    Vec c(m.r);
    for (size_t j = 0; j < m.c; j++) {
      for (size_t i = 0; i < m.r; i++)
        c[i] = m(i, j);
      Vec v = f(c);
      for (size_t i = 0; i < m.r; i++)
        o(i, j) = v[i];
    }
  }
  return o;
}

bool getData(const Args &a, size_t i, CallContext &ctx, Mat &m, bool &line) {
  if (!getMat(a, i, ctx, m))
    return false;
  line = ft::isLine(a[i]);
  if (line && m.c == 1 && m.r > 1)
    m = transposeOf(m);
  return true;
}

} // namespace ip

using namespace ip;

namespace {

Value dataValue(const Mat &m, bool line) { return line ? toValue(m.a) : toValue(m); }

// -1 and 1 are the last axis, 0 the columns of a Matrix.
bool axisOf(const Args &a, size_t i, CallContext &ctx, bool line, int &axis) {
  long long v = i < a.size() && isPlainNumber(a[i]) ? (long long)a[i].number : -1;
  if (line && v != -1 && v != 0) {
    ctx.fail("an Array has only axis 0");
    return false;
  }
  if (v < -2 || v > 1) {
    ctx.fail("axis must be 0 or 1");
    return false;
  }
  axis = line ? 1 : (v == -2 ? 0 : (v == 0 ? 0 : 1));
  return true;
}

std::vector<int> axesOf(bool line) { return line ? std::vector<int>{1} : std::vector<int>{0, 1}; }

Vec gaussianKernel(double sigma, int order, long radius) {
  const double s2 = sigma * sigma;
  const size_t L = (size_t)(2 * radius + 1);
  Vec phi(L);
  double sum = 0.0;
  for (size_t i = 0; i < L; i++) {
    const double x = (double)i - (double)radius;
    phi[i] = std::exp(-0.5 / s2 * x * x);
    sum += phi[i];
  }
  for (double &v : phi)
    v /= sum;
  if (order == 0)
    return phi;
  // q(x) phi(x), with q' + q*(-x/s2) as the derivative rule.
  Vec q((size_t)order + 1, 0.0);
  q[0] = 1.0;
  for (int t = 0; t < order; t++) {
    Vec n((size_t)order + 1, 0.0);
    for (int e = 0; e <= order; e++) {
      if (e + 1 <= order)
        n[(size_t)e] += (double)(e + 1) * q[(size_t)e + 1];
      if (e >= 1)
        n[(size_t)e] -= q[(size_t)e - 1] / s2;
    }
    q = n;
  }
  for (size_t i = 0; i < L; i++) {
    const double x = (double)i - (double)radius;
    double v = 0.0;
    for (int e = order; e >= 0; e--)
      v = v * x + q[(size_t)e];
    phi[i] *= v;
  }
  return phi;
}

Vec gaussianLine(const Vec &x, double sigma, int order, int mode, double cval, double truncate) {
  const long radius = (long)(truncate * sigma + 0.5);
  Vec w = gaussianKernel(sigma, order, radius);
  std::reverse(w.begin(), w.end());
  return correlateLine(x, w, 0, mode, cval);
}

Mat gaussianND(const Mat &m, bool line, const Vec &sigma, const std::vector<int> &order, int mode, double cval, double truncate) {
  Mat o = m;
  const std::vector<int> ax = axesOf(line);
  for (size_t i = 0; i < ax.size(); i++) {
    const double s = sigma.size() == 1 ? sigma[0] : sigma[i];
    if (s > 1e-15)
      o = alongAxis(o, ax[i], [&](const Vec &v) { return gaussianLine(v, s, order[i], mode, cval, truncate); });
  }
  return o;
}

bool sigmaOf(const Args &a, size_t i, CallContext &ctx, bool line, Vec &s) {
  if (!getVec(a, i, ctx, s))
    return false;
  if (s.size() != 1 && s.size() != (line ? 1u : 2u)) {
    ctx.fail("sigma must be one number, or one number per axis");
    return false;
  }
  for (double v : s)
    if (v < 0.0) {
      ctx.fail("sigma must not be negative");
      return false;
    }
  return true;
}

// Size arguments: one number for both axes, or [rows, cols].
bool sizesOf(const Args &a, size_t i, CallContext &ctx, bool line, size_t &kr, size_t &kc, long long def = 3) {
  kr = line ? 1 : (size_t)def;
  kc = (size_t)def;
  if (i >= a.size() || isOmitted(a, i))
    return true;
  Vec s;
  if (!getVec(a, i, ctx, s))
    return false;
  if (s.size() == 1) {
    kc = (size_t)s[0];
    if (!line)
      kr = kc;
  } else if (s.size() == 2 && !line) {
    kr = (size_t)s[0];
    kc = (size_t)s[1];
  } else {
    ctx.fail("size must be one number, or [rows, cols] for a Matrix");
    return false;
  }
  if (kr < 1 || kc < 1) {
    ctx.fail("size must be 1 or more");
    return false;
  }
  return true;
}

// Extreme value of each window along a line; centre at size / 2 + origin.
Vec extremumLine(const Vec &x, size_t size, bool wantMax, long origin, int mode, double cval) {
  const long n = (long)x.size(), L = (long)size, c = L / 2 + origin;
  Vec o((size_t)n);
  for (long i = 0; i < n; i++) {
    double b = wantMax ? -kInf : kInf;
    for (long j = 0; j < L; j++) {
      const long k = extIndex(i + j - c, n, mode);
      const double v = k < 0 ? cval : x[(size_t)k];
      b = wantMax ? std::max(b, v) : std::min(b, v);
    }
    o[(size_t)i] = b;
  }
  return o;
}

Mat extremumFilter(const Mat &m, size_t kr, size_t kc, bool wantMax, long oR, long oC, int mode, double cval) {
  Mat o = alongAxis(m, 1, [&](const Vec &v) { return extremumLine(v, kc, wantMax, oC, mode, cval); });
  if (m.r > 1 || kr > 1)
    o = alongAxis(o, 0, [&](const Vec &v) { return extremumLine(v, kr, wantMax, oR, mode, cval); });
  return o;
}

Mat rankFilter(const Mat &m, size_t kr, size_t kc, long rank, int mode, double cval) {
  const long cr = (long)kr / 2, cc = (long)kc / 2;
  Mat o(m.r, m.c);
  Vec w(kr * kc);
  for (long i = 0; i < (long)m.r; i++)
    for (long j = 0; j < (long)m.c; j++) {
      size_t q = 0;
      for (long k = 0; k < (long)kr; k++)
        for (long l = 0; l < (long)kc; l++) {
          const long ii = extIndex(i + k - cr, (long)m.r, mode), jj = extIndex(j + l - cc, (long)m.c, mode);
          w[q++] = ii < 0 || jj < 0 ? cval : m((size_t)ii, (size_t)jj);
        }
      std::nth_element(w.begin(), w.begin() + rank, w.end());
      o((size_t)i, (size_t)j) = w[(size_t)rank];
    }
  return o;
}

Mat correlate2d(const Mat &m, const Mat &w, bool flip, int mode, double cval) {
  long cr = (long)w.r / 2, cc = (long)w.c / 2;
  if (flip) {
    // Mirrored weights, and even sizes keep their centre on the other side.
    if (w.r % 2 == 0)
      cr -= 1;
    if (w.c % 2 == 0)
      cc -= 1;
  }
  Mat o(m.r, m.c);
  for (long i = 0; i < (long)m.r; i++)
    for (long j = 0; j < (long)m.c; j++) {
      double s = 0.0;
      for (long k = 0; k < (long)w.r; k++)
        for (long l = 0; l < (long)w.c; l++) {
          const double v = flip ? w(w.r - 1 - (size_t)k, w.c - 1 - (size_t)l) : w((size_t)k, (size_t)l);
          if (v == 0.0)
            continue;
          const long ii = extIndex(i + k - cr, (long)m.r, mode), jj = extIndex(j + l - cc, (long)m.c, mode);
          s += v * (ii < 0 || jj < 0 ? cval : m((size_t)ii, (size_t)jj));
        }
      o((size_t)i, (size_t)j) = s;
    }
  return o;
}

Mat greyErode(const Mat &m, size_t kr, size_t kc, int mode, double cval) { return extremumFilter(m, kr, kc, false, 0, 0, mode, cval); }
Mat greyDilate(const Mat &m, size_t kr, size_t kc, int mode, double cval) {
  return extremumFilter(m, kr, kc, true, kr % 2 ? 0 : -1, kc % 2 ? 0 : -1, mode, cval);
}

// ---- binary morphology ----
Mat crossStructure(bool line) {
  if (line)
    return Mat(1, 3, 1.0);
  Mat s(3, 3);
  s(0, 1) = s(1, 0) = s(1, 1) = s(1, 2) = s(2, 1) = 1.0;
  return s;
}

bool structureOf(const Args &a, size_t i, CallContext &ctx, bool line, Mat &s) {
  if (i >= a.size() || isOmitted(a, i)) {
    s = crossStructure(line);
    return true;
  }
  return getMat(a, i, ctx, s);
}

// One pass: every structure cell must be on, with `border` standing for outside.
void erodePass(const std::vector<char> &in, size_t R, size_t C, const Mat &s, long cr, long cc, bool border, const std::vector<char> *mask, std::vector<char> &out, bool invert) {
  out.resize(in.size());
  for (long i = 0; i < (long)R; i++)
    for (long j = 0; j < (long)C; j++) {
      const size_t at = (size_t)i * C + (size_t)j;
      const char self = invert ? !in[at] : in[at];
      if (mask && !(*mask)[at]) {
        out[at] = in[at];
        continue;
      }
      char v = 1;
      for (long k = 0; k < (long)s.r && v; k++)
        for (long l = 0; l < (long)s.c && v; l++) {
          if (s((size_t)k, (size_t)l) == 0.0)
            continue;
          const long ii = i + k - cr, jj = j + l - cc;
          char cell;
          if (ii < 0 || ii >= (long)R || jj < 0 || jj >= (long)C)
            cell = border;
          else
            cell = invert ? !in[(size_t)ii * C + (size_t)jj] : in[(size_t)ii * C + (size_t)jj];
          if (!cell)
            v = 0;
        }
      (void)self;
      out[at] = invert ? !v : v;
    }
}

// Repeated passes; iterations < 1 runs until nothing changes.
std::vector<char> morphRun(std::vector<char> x, size_t R, size_t C, const Mat &s, long iterations, const std::vector<char> *mask, bool border, bool dilate) {
  Mat st = s;
  long cr = (long)s.r / 2, cc = (long)s.c / 2;
  bool bv = border;
  if (dilate) {
    // A dilation is the erosion of the complement with the mirrored structure.
    for (size_t i = 0; i < s.r; i++)
      for (size_t j = 0; j < s.c; j++)
        st(i, j) = s(s.r - 1 - i, s.c - 1 - j);
    if (s.r % 2 == 0)
      cr -= 1;
    if (s.c % 2 == 0)
      cc -= 1;
    bv = !border;
  }
  std::vector<char> y;
  for (long it = 0; iterations < 1 || it < iterations; it++) {
    erodePass(x, R, C, st, cr, cc, bv, mask, y, dilate);
    const bool same = y == x;
    x.swap(y);
    if (same)
      break;
  }
  return x;
}

std::vector<char> boolsOf(const Mat &m) {
  std::vector<char> b(m.a.size());
  for (size_t i = 0; i < b.size(); i++)
    b[i] = m.a[i] != 0.0;
  return b;
}
Mat matOf(const std::vector<char> &b, size_t R, size_t C) {
  Mat m(R, C);
  for (size_t i = 0; i < b.size(); i++)
    m.a[i] = b[i] ? 1.0 : 0.0;
  return m;
}
std::vector<char> notOf(std::vector<char> b) {
  for (char &v : b)
    v = !v;
  return b;
}

long itersOf(const Args &a, size_t i) { return i < a.size() && isPlainNumber(a[i]) ? (long)a[i].number : 1; }

// ---- distance transforms ----
// Squared distances along a line by the lower envelope of parabolas.
void edtLine(const double *f, double *d, size_t n, double step, std::vector<long> &v, Vec &z) {
  const double s2 = step * step;
  long k = -1;
  v.assign(n, 0);
  z.assign(n + 1, 0.0);
  for (size_t q = 0; q < n; q++) {
    if (std::isinf(f[q]))
      continue;
    double s = -kInf;
    while (k >= 0) {
      const long p = v[(size_t)k];
      s = ((f[q] + s2 * (double)q * (double)q) - (f[p] + s2 * (double)p * (double)p)) / (2.0 * s2 * ((double)q - (double)p));
      if (s <= z[(size_t)k])
        k--;
      else
        break;
    }
    k++;
    v[(size_t)k] = (long)q;
    z[(size_t)k] = k == 0 ? -kInf : s;
    z[(size_t)k + 1] = kInf;
  }
  if (k < 0) {
    for (size_t q = 0; q < n; q++)
      d[q] = kInf;
    return;
  }
  long j = 0;
  for (size_t q = 0; q < n; q++) {
    while (z[(size_t)j + 1] < (double)q)
      j++;
    const double dd = (double)q - (double)v[(size_t)j];
    d[q] = s2 * dd * dd + f[v[(size_t)j]];
  }
}

} // namespace

void registerImageInterp(Registry &reg);
void registerImageMeasure(Registry &reg);

void registerImageProcessing(Registry &reg) {
  // ---- correlation and convolution ----
#define IP_MODE(I)                                                                                 \
  int mode;                                                                                        \
  if (!parseMode(a, I, ctx, mode))                                                                 \
    return Value(0.0);                                                                             \
  const double cval = optNum(a, (I) + 1, 0.0);
  SP_ADD("img_convolve", 2, 4, "img, kernel, mode=\"reflect\", cval=0") {
    Mat m, w;
    if (!getMat(a, 0, ctx, m) || !getMat(a, 1, ctx, w))
      return Value(0.0);
    IP_MODE(2)
    return toValue(correlate2d(m, w, true, mode, cval));
  } SP_END
  SP_ADD("img_correlate", 2, 4, "img, kernel, mode=\"reflect\", cval=0") {
    Mat m, w;
    if (!getMat(a, 0, ctx, m) || !getMat(a, 1, ctx, w))
      return Value(0.0);
    IP_MODE(2)
    return toValue(correlate2d(m, w, false, mode, cval));
  } SP_END
  SP_ADD("img_convolve1d", 2, 5, "data, kernel, axis=-1, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    Vec w;
    int axis;
    if (!getData(a, 0, ctx, m, line) || !getVec(a, 1, ctx, w) || !axisOf(a, 2, ctx, line, axis))
      return Value(0.0);
    IP_MODE(3)
    std::reverse(w.begin(), w.end());
    const long origin = w.size() % 2 ? 0 : -1;
    return dataValue(alongAxis(m, axis, [&](const Vec &v) { return correlateLine(v, w, origin, mode, cval); }), line);
  } SP_END
  SP_ADD("img_correlate1d", 2, 5, "data, kernel, axis=-1, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    Vec w;
    int axis;
    if (!getData(a, 0, ctx, m, line) || !getVec(a, 1, ctx, w) || !axisOf(a, 2, ctx, line, axis))
      return Value(0.0);
    IP_MODE(3)
    return dataValue(alongAxis(m, axis, [&](const Vec &v) { return correlateLine(v, w, 0, mode, cval); }), line);
  } SP_END
  // ---- gaussian ----
  SP_ADD("gaussian_filter", 2, 5, "img, sigma, mode=\"reflect\", order=0, truncate=4") {
    Mat m;
    bool line;
    Vec s;
    if (!getData(a, 0, ctx, m, line) || !sigmaOf(a, 1, ctx, line, s))
      return Value(0.0);
    int mode;
    if (!parseMode(a, 2, ctx, mode))
      return Value(0.0);
    const int order = (int)optInt(a, 3, 0);
    return dataValue(gaussianND(m, line, s, std::vector<int>(2, order), mode, 0.0, isOmitted(a, 4) ? 4.0 : optNum(a, 4, 4.0)), line);
  } SP_END
  SP_ADD("gaussian_filter1d", 2, 6, "data, sigma, axis=-1, order=0, mode=\"reflect\", truncate=4") {
    Mat m;
    bool line;
    int axis;
    if (!getData(a, 0, ctx, m, line) || !axisOf(a, 2, ctx, line, axis))
      return Value(0.0);
    int mode;
    if (!parseMode(a, 4, ctx, mode))
      return Value(0.0);
    const double sigma = optNum(a, 1, 1.0), tr = isOmitted(a, 5) ? 4.0 : optNum(a, 5, 4.0);
    const int order = (int)optInt(a, 3, 0);
    return dataValue(alongAxis(m, axis, [&](const Vec &v) { return gaussianLine(v, sigma, order, mode, 0.0, tr); }), line);
  } SP_END
  SP_ADD("gaussian_gradient", 2, 3, "img, sigma, mode=\"reflect\"") {
    Mat m;
    bool line;
    Vec s;
    if (!getData(a, 0, ctx, m, line) || !sigmaOf(a, 1, ctx, line, s))
      return Value(0.0);
    int mode;
    if (!parseMode(a, 2, ctx, mode))
      return Value(0.0);
    const size_t axes = line ? 1 : 2;
    Mat o(m.r, m.c);
    for (size_t d = 0; d < axes; d++) {
      std::vector<int> order(2, 0);
      order[d] = 1;
      Mat g = gaussianND(m, line, s, order, mode, 0.0, 4.0);
      for (size_t i = 0; i < o.a.size(); i++)
        o.a[i] += g.a[i] * g.a[i];
    }
    for (double &v : o.a)
      v = std::sqrt(v);
    return dataValue(o, line);
  } SP_END
  SP_ADD("gaussian_laplace", 2, 3, "img, sigma, mode=\"reflect\"") {
    Mat m;
    bool line;
    Vec s;
    if (!getData(a, 0, ctx, m, line) || !sigmaOf(a, 1, ctx, line, s))
      return Value(0.0);
    int mode;
    if (!parseMode(a, 2, ctx, mode))
      return Value(0.0);
    const size_t axes = line ? 1 : 2;
    Mat o(m.r, m.c);
    for (size_t d = 0; d < axes; d++) {
      std::vector<int> order(2, 0);
      order[d] = 2;
      Mat g = gaussianND(m, line, s, order, mode, 0.0, 4.0);
      for (size_t i = 0; i < o.a.size(); i++)
        o.a[i] += g.a[i];
    }
    return dataValue(o, line);
  } SP_END
  // ---- functions supplied in NC ----
  SP_ADD("img_generic_filter", 2, 5, "img, fn, size=3, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    if (!isCallable(a[1])) {
      ctx.fail("the second argument must name an NC function");
      return Value(0.0);
    }
    size_t kr, kc;
    if (!sizesOf(a, 2, ctx, line, kr, kc))
      return Value(0.0);
    IP_MODE(3)
    NcFn f(a[1]);
    const long cr = (long)kr / 2, cc = (long)kc / 2;
    Mat o(m.r, m.c);
    Vec w(kr * kc);
    for (long i = 0; i < (long)m.r && !f.failed; i++)
      for (long j = 0; j < (long)m.c && !f.failed; j++) {
        size_t q = 0;
        for (long k = 0; k < (long)kr; k++)
          for (long l = 0; l < (long)kc; l++) {
            const long ii = extIndex(i + k - cr, (long)m.r, mode), jj = extIndex(j + l - cc, (long)m.c, mode);
            w[q++] = ii < 0 || jj < 0 ? cval : m((size_t)ii, (size_t)jj);
          }
        o((size_t)i, (size_t)j) = f.ofVec(w);
      }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    return dataValue(o, line);
  } SP_END
  SP_ADD("img_generic_filter1d", 3, 6, "data, fn, size, axis=-1, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    int axis;
    if (!getData(a, 0, ctx, m, line) || !axisOf(a, 3, ctx, line, axis))
      return Value(0.0);
    if (!isCallable(a[1])) {
      ctx.fail("the second argument must name an NC function");
      return Value(0.0);
    }
    const long size = (long)optInt(a, 2, 3);
    if (size < 1) {
      ctx.fail("size must be 1 or more");
      return Value(0.0);
    }
    IP_MODE(4)
    NcFn f(a[1]);
    // The function gets each line extended by the filter's reach and returns the line.
    const long before = size / 2, after = size - before - 1;
    bool bad = false;
    Mat o = alongAxis(m, axis, [&](const Vec &v) {
      const long n = (long)v.size();
      Vec ext;
      for (long i = -before; i < n + after; i++) {
        const long k = extIndex(i, n, mode);
        ext.push_back(k < 0 ? cval : v[(size_t)k]);
      }
      Vec r = f.vecOfVec(ext);
      // A function that returns the extended line as it came gets its reach cut off.
      if (!f.failed && (long)r.size() == n + before + after)
        r = Vec(r.begin() + before, r.end() - after);
      if (f.failed || (long)r.size() != n) {
        bad = true;
        return Vec((size_t)n, 0.0);
      }
      return r;
    });
    if (bad) {
      ctx.fail(f.failed ? f.failText() : "the function must return as many values as the line has samples");
      return Value(0.0);
    }
    return dataValue(o, line);
  } SP_END
  SP_ADD("img_vector_filter", 2, 5, "img, fn, size=3, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    if (!isCallable(a[1])) {
      ctx.fail("the second argument must name an NC function");
      return Value(0.0);
    }
    size_t kr, kc;
    if (!sizesOf(a, 2, ctx, line, kr, kc))
      return Value(0.0);
    IP_MODE(3)
    const long cr = (long)kr / 2, cc = (long)kc / 2;
    // One row per pixel, the row holding its window.
    Mat W(m.a.size(), kr * kc);
    size_t row = 0;
    for (long i = 0; i < (long)m.r; i++)
      for (long j = 0; j < (long)m.c; j++, row++) {
        size_t q = 0;
        for (long k = 0; k < (long)kr; k++)
          for (long l = 0; l < (long)kc; l++) {
            const long ii = extIndex(i + k - cr, (long)m.r, mode), jj = extIndex(j + l - cc, (long)m.c, mode);
            W(row, q++) = ii < 0 || jj < 0 ? cval : m((size_t)ii, (size_t)jj);
          }
      }
    NcFn f(a[1]);
    Vec res;
    Value whole = f.raw({toValue(W)});
    if (f.failed || !readVec(whole, res) || res.size() != m.a.size()) {
      // Not one value per row: then the function works on one window at a time.
      f.failed = false;
      res.resize(m.a.size());
      for (size_t r = 0; r < W.r && !f.failed; r++)
        res[r] = f.ofVec(Vec(W.row(r), W.row(r) + W.c));
    }
    if (f.failed) {
      ctx.fail(f.failText());
      return Value(0.0);
    }
    Mat o(m.r, m.c);
    o.a = res;
    return dataValue(o, line);
  } SP_END
  SP_ADD("img_generic_gradient", 2, 2, "img, fn") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    if (!isCallable(a[1])) {
      ctx.fail("the second argument must name an NC function, f(img, axis)");
      return Value(0.0);
    }
    NcFn f(a[1]);
    Mat o(m.r, m.c);
    for (int axis = 0; axis < 2; axis++) {
      Mat d;
      Value r = f.raw({a[0], Value((double)axis)});
      if (f.failed || !readMat(r, d) || d.a.size() != m.a.size()) {
        ctx.fail(f.failed ? f.failText() : "the function must return a matrix of the image's shape");
        return Value(0.0);
      }
      for (size_t i = 0; i < o.a.size(); i++)
        o.a[i] += d.a[i] * d.a[i];
    }
    for (double &v : o.a)
      v = std::sqrt(v);
    return toValue(o);
  } SP_END
  SP_ADD("img_generic_laplace", 2, 2, "img, fn") {
    Mat m;
    if (!getMat(a, 0, ctx, m))
      return Value(0.0);
    if (!isCallable(a[1])) {
      ctx.fail("the second argument must name an NC function, f(img, axis)");
      return Value(0.0);
    }
    NcFn f(a[1]);
    Mat o(m.r, m.c);
    for (int axis = 0; axis < 2; axis++) {
      Mat d;
      Value r = f.raw({a[0], Value((double)axis)});
      if (f.failed || !readMat(r, d) || d.a.size() != m.a.size()) {
        ctx.fail(f.failed ? f.failText() : "the function must return a matrix of the image's shape");
        return Value(0.0);
      }
      for (size_t i = 0; i < o.a.size(); i++)
        o.a[i] += d.a[i];
    }
    return toValue(o);
  } SP_END
  // ---- fixed derivative filters ----
  SP_ADD("img_laplace", 1, 3, "img, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    IP_MODE(1)
    Mat o(m.r, m.c);
    const Vec w{1.0, -2.0, 1.0};
    for (int ax : axesOf(line)) {
      Mat d = alongAxis(m, ax, [&](const Vec &v) { return correlateLine(v, w, 0, mode, cval); });
      for (size_t i = 0; i < o.a.size(); i++)
        o.a[i] += d.a[i];
    }
    return dataValue(o, line);
  } SP_END
#define IP_DERIV(NAME, SMOOTH)                                                                     \
  SP_ADD(NAME, 1, 4, "img, axis=-1, mode=\"reflect\", cval=0") {                                   \
    Mat m;                                                                                         \
    bool line;                                                                                     \
    int axis;                                                                                      \
    if (!getData(a, 0, ctx, m, line) || !axisOf(a, 1, ctx, line, axis))                            \
      return Value(0.0);                                                                           \
    IP_MODE(2)                                                                                     \
    const Vec d{-1.0, 0.0, 1.0}, s SMOOTH;                                                         \
    Mat o = alongAxis(m, axis, [&](const Vec &v) { return correlateLine(v, d, 0, mode, cval); });  \
    if (!line)                                                                                     \
      o = alongAxis(o, 1 - axis, [&](const Vec &v) { return correlateLine(v, s, 0, mode, cval); }); \
    return dataValue(o, line);                                                                     \
  } SP_END
  IP_DERIV("prewitt", {1.0 COMMA_ 1.0 COMMA_ 1.0})
  IP_DERIV("sobel", {1.0 COMMA_ 2.0 COMMA_ 1.0})
  // ---- rank and extreme filters ----
#define IP_EXT(NAME, MAX)                                                                          \
  SP_ADD(NAME, 1, 4, "img, size=3, mode=\"reflect\", cval=0") {                                    \
    Mat m;                                                                                         \
    bool line;                                                                                     \
    size_t kr, kc;                                                                                 \
    if (!getData(a, 0, ctx, m, line) || !sizesOf(a, 1, ctx, line, kr, kc))                         \
      return Value(0.0);                                                                           \
    IP_MODE(2)                                                                                     \
    return dataValue(extremumFilter(m, kr, kc, MAX, 0, 0, mode, cval), line);                      \
  } SP_END
  IP_EXT("max_filter", true)
  IP_EXT("min_filter", false)
#define IP_EXT1(NAME, MAX)                                                                         \
  SP_ADD(NAME, 2, 5, "data, size, axis=-1, mode=\"reflect\", cval=0") {                            \
    Mat m;                                                                                         \
    bool line;                                                                                     \
    int axis;                                                                                      \
    if (!getData(a, 0, ctx, m, line) || !axisOf(a, 2, ctx, line, axis))                            \
      return Value(0.0);                                                                           \
    IP_MODE(3)                                                                                     \
    const size_t sz = (size_t)optInt(a, 1, 3);                                                     \
    if (sz < 1) {                                                                                  \
      ctx.fail("size must be 1 or more");                                                          \
      return Value(0.0);                                                                           \
    }                                                                                              \
    return dataValue(alongAxis(m, axis, [&](const Vec &v) { return extremumLine(v, sz, MAX, 0, mode, cval); }), line); \
  } SP_END
  IP_EXT1("max_filter1d", true)
  IP_EXT1("min_filter1d", false)
  SP_ADD("median_filter", 1, 4, "img, size=3, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    size_t kr, kc;
    if (!getData(a, 0, ctx, m, line) || !sizesOf(a, 1, ctx, line, kr, kc))
      return Value(0.0);
    IP_MODE(2)
    return dataValue(rankFilter(m, kr, kc, (long)(kr * kc / 2), mode, cval), line);
  } SP_END
  SP_ADD("percentile_filter", 2, 5, "img, p, size=3, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    size_t kr, kc;
    if (!getData(a, 0, ctx, m, line) || !sizesOf(a, 2, ctx, line, kr, kc))
      return Value(0.0);
    IP_MODE(3)
    double p = optNum(a, 1, 50.0);
    if (p < 0.0)
      p += 100.0;
    if (p < 0.0 || p > 100.0) {
      ctx.fail("p must be from 0 to 100");
      return Value(0.0);
    }
    const size_t total = kr * kc;
    const long rank = p == 100.0 ? (long)total - 1 : (long)((double)total * p / 100.0);
    return dataValue(rankFilter(m, kr, kc, rank, mode, cval), line);
  } SP_END
  SP_ADD("rank_filter", 2, 5, "img, rank, size=3, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    size_t kr, kc;
    if (!getData(a, 0, ctx, m, line) || !sizesOf(a, 2, ctx, line, kr, kc))
      return Value(0.0);
    IP_MODE(3)
    long rank = (long)optInt(a, 1, 0);
    const long total = (long)(kr * kc);
    if (rank < 0)
      rank += total;
    if (rank < 0 || rank >= total) {
      ctx.fail("rank must be below the number of values in the window");
      return Value(0.0);
    }
    return dataValue(rankFilter(m, kr, kc, rank, mode, cval), line);
  } SP_END
  SP_ADD("uniform_filter", 1, 4, "img, size=3, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    size_t kr, kc;
    if (!getData(a, 0, ctx, m, line) || !sizesOf(a, 1, ctx, line, kr, kc))
      return Value(0.0);
    IP_MODE(2)
    Mat o = alongAxis(m, 1, [&](const Vec &v) { return correlateLine(v, Vec(kc, 1.0 / (double)kc), 0, mode, cval); });
    if (!line)
      o = alongAxis(o, 0, [&](const Vec &v) { return correlateLine(v, Vec(kr, 1.0 / (double)kr), 0, mode, cval); });
    return dataValue(o, line);
  } SP_END
  SP_ADD("uniform_filter1d", 2, 5, "data, size, axis=-1, mode=\"reflect\", cval=0") {
    Mat m;
    bool line;
    int axis;
    if (!getData(a, 0, ctx, m, line) || !axisOf(a, 2, ctx, line, axis))
      return Value(0.0);
    IP_MODE(3)
    const size_t sz = (size_t)optInt(a, 1, 3);
    if (sz < 1) {
      ctx.fail("size must be 1 or more");
      return Value(0.0);
    }
    return dataValue(alongAxis(m, axis, [&](const Vec &v) { return correlateLine(v, Vec(sz, 1.0 / (double)sz), 0, mode, cval); }), line);
  } SP_END
  // ---- grey morphology ----
#define IP_GREY(NAME, EXPR)                                                                        \
  SP_ADD(NAME, 1, 4, "img, size=3, mode=\"reflect\", cval=0") {                                    \
    Mat m;                                                                                         \
    bool line;                                                                                     \
    size_t kr, kc;                                                                                 \
    if (!getData(a, 0, ctx, m, line) || !sizesOf(a, 1, ctx, line, kr, kc))                         \
      return Value(0.0);                                                                           \
    IP_MODE(2)                                                                                     \
    Mat out;                                                                                       \
    EXPR;                                                                                          \
    return dataValue(out, line);                                                                   \
  } SP_END
  IP_GREY("grey_erosion", out = greyErode(m, kr, kc, mode, cval))
  IP_GREY("grey_dilation", out = greyDilate(m, kr, kc, mode, cval))
  IP_GREY("grey_opening", out = greyDilate(greyErode(m, kr, kc, mode, cval), kr, kc, mode, cval))
  IP_GREY("grey_closing", out = greyErode(greyDilate(m, kr, kc, mode, cval), kr, kc, mode, cval))
  IP_GREY("white_tophat", out = greyDilate(greyErode(m, kr, kc, mode, cval), kr, kc, mode, cval); for (size_t i = 0; i < out.a.size(); i++) out.a[i] = m.a[i] - out.a[i])
  IP_GREY("black_tophat", out = greyErode(greyDilate(m, kr, kc, mode, cval), kr, kc, mode, cval); for (size_t i = 0; i < out.a.size(); i++) out.a[i] -= m.a[i])
  IP_GREY("morph_gradient", out = greyDilate(m, kr, kc, mode, cval); const Mat er = greyErode(m, kr, kc, mode, cval); for (size_t i = 0; i < out.a.size(); i++) out.a[i] -= er.a[i])
  IP_GREY("morph_laplace", out = greyDilate(m, kr, kc, mode, cval); const Mat er = greyErode(m, kr, kc, mode, cval); for (size_t i = 0; i < out.a.size(); i++) out.a[i] += er.a[i] - 2.0 * m.a[i])
  // ---- binary morphology ----
#define IP_BIN_ARGS(ISTR)                                                                          \
  Mat m, st;                                                                                       \
  bool line;                                                                                       \
  if (!getData(a, 0, ctx, m, line) || !structureOf(a, ISTR, ctx, line, st))                        \
    return Value(0.0);                                                                             \
  const std::vector<char> in = boolsOf(m);
  SP_ADD("binary_erosion", 1, 4, "mask, structure, iterations=1, border=0") {
    IP_BIN_ARGS(1)
    return dataValue(matOf(morphRun(in, m.r, m.c, st, itersOf(a, 2), nullptr, optBool(a, 3, false), false), m.r, m.c), line);
  } SP_END
  SP_ADD("binary_dilation", 1, 4, "mask, structure, iterations=1, border=0") {
    IP_BIN_ARGS(1)
    return dataValue(matOf(morphRun(in, m.r, m.c, st, itersOf(a, 2), nullptr, optBool(a, 3, false), true), m.r, m.c), line);
  } SP_END
  SP_ADD("binary_opening", 1, 3, "mask, structure, iterations=1") {
    IP_BIN_ARGS(1)
    const long it = itersOf(a, 2);
    return dataValue(matOf(morphRun(morphRun(in, m.r, m.c, st, it, nullptr, false, false), m.r, m.c, st, it, nullptr, false, true), m.r, m.c), line);
  } SP_END
  SP_ADD("binary_closing", 1, 3, "mask, structure, iterations=1") {
    IP_BIN_ARGS(1)
    const long it = itersOf(a, 2);
    return dataValue(matOf(morphRun(morphRun(in, m.r, m.c, st, it, nullptr, false, true), m.r, m.c, st, it, nullptr, false, false), m.r, m.c), line);
  } SP_END
  SP_ADD("binary_fill_holes", 1, 2, "mask, structure") {
    IP_BIN_ARGS(1)
    const std::vector<char> outside = notOf(in);
    std::vector<char> seed(in.size(), 0);
    std::vector<char> grown = morphRun(seed, m.r, m.c, st, 0, &outside, true, true);
    return dataValue(matOf(notOf(grown), m.r, m.c), line);
  } SP_END
  SP_ADD("binary_hit_or_miss", 1, 3, "mask, structure1, structure2") {
    IP_BIN_ARGS(1)
    Mat s2 = st;
    if (a.size() > 2 && !isOmitted(a, 2)) {
      if (!getMat(a, 2, ctx, s2))
        return Value(0.0);
    } else {
      for (double &v : s2.a)
        v = v == 0.0 ? 1.0 : 0.0;
    }
    const std::vector<char> t1 = morphRun(in, m.r, m.c, st, 1, nullptr, false, false);
    const std::vector<char> t2 = morphRun(notOf(in), m.r, m.c, s2, 1, nullptr, false, false);
    std::vector<char> o(in.size());
    for (size_t i = 0; i < o.size(); i++)
      o[i] = t1[i] && t2[i];
    return dataValue(matOf(o, m.r, m.c), line);
  } SP_END
  SP_ADD("binary_propagation", 1, 3, "seeds, mask, structure") {
    IP_BIN_ARGS(2)
    if (a.size() > 1 && !isOmitted(a, 1)) {
      Mat mk;
      if (!getMat(a, 1, ctx, mk))
        return Value(0.0);
      if (mk.a.size() != m.a.size()) {
        ctx.fail("mask must have the shape of the seeds");
        return Value(0.0);
      }
      const std::vector<char> mb = boolsOf(mk);
      return dataValue(matOf(morphRun(in, m.r, m.c, st, 0, &mb, false, true), m.r, m.c), line);
    }
    return dataValue(matOf(morphRun(in, m.r, m.c, st, 0, nullptr, false, true), m.r, m.c), line);
  } SP_END
  SP_ADD("binary_structure", 2, 2, "rank, connectivity") {
    const long long rank = optInt(a, 0, 0), conn = optInt(a, 1, 1);
    if (rank < 1 || rank > 2) {
      ctx.fail("NC images have rank 1 or 2");
      return Value(0.0);
    }
    if (rank == 1) {
      Mat s(1, 3, 1.0);
      if (conn < 1) {
        s(0, 0) = s(0, 2) = 0.0;
      }
      return toValue(s.a);
    }
    Mat s(3, 3);
    for (long i = -1; i <= 1; i++)
      for (long j = -1; j <= 1; j++)
        s((size_t)(i + 1), (size_t)(j + 1)) = std::labs(i) + std::labs(j) <= conn ? 1.0 : 0.0;
    return toValue(s);
  } SP_END
  SP_ADD("iterate_structure", 2, 2, "structure, iterations") {
    Mat s;
    bool line;
    if (!getData(a, 0, ctx, s, line))
      return Value(0.0);
    const long it = (long)optInt(a, 1, 1);
    if (it < 2)
      return a[0];
    const size_t R = s.r + (size_t)(it - 1) * (s.r - 1), C = s.c + (size_t)(it - 1) * (s.c - 1);
    const size_t pr = (size_t)(it - 1) * (s.r / 2), pc = (size_t)(it - 1) * (s.c / 2);
    Mat o(R, C);
    for (size_t i = 0; i < s.r; i++)
      for (size_t j = 0; j < s.c; j++)
        o(i + pr, j + pc) = s(i, j);
    return dataValue(matOf(morphRun(boolsOf(o), R, C, s, it - 1, nullptr, false, true), R, C), line);
  } SP_END
  // ---- distance transforms ----
  SP_ADD("distance_bf", 1, 3, "mask, metric=\"euclidean\", sampling") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    std::string metric = optText(a, 1, "euclidean");
    int kind;
    if (metric == "euclidean")
      kind = 0;
    else if (metric == "taxicab" || metric == "cityblock" || metric == "manhattan")
      kind = 1;
    else if (metric == "chessboard")
      kind = 2;
    else {
      ctx.fail("metric must be \"euclidean\", \"taxicab\" or \"chessboard\"");
      return Value(0.0);
    }
    Vec sp{1.0, 1.0};
    if (a.size() > 2 && !isOmitted(a, 2)) {
      Vec v;
      if (!getVec(a, 2, ctx, v))
        return Value(0.0);
      if (v.size() == 1)
        sp = {v[0], v[0]};
      else if (v.size() == 2)
        sp = v;
      else {
        ctx.fail("sampling must be one number or one per axis");
        return Value(0.0);
      }
    }
    Mat o(m.r, m.c);
    for (long i = 0; i < (long)m.r; i++)
      for (long j = 0; j < (long)m.c; j++) {
        if (m((size_t)i, (size_t)j) == 0.0)
          continue;
        double best = kInf;
        for (long p = 0; p < (long)m.r; p++)
          for (long q = 0; q < (long)m.c; q++) {
            if (m((size_t)p, (size_t)q) != 0.0)
              continue;
            const double dr = sp[0] * (double)std::labs(p - i), dc = sp[1] * (double)std::labs(q - j);
            const double d = kind == 0 ? dr * dr + dc * dc : (kind == 1 ? dr + dc : std::max(dr, dc));
            best = std::min(best, d);
          }
        o((size_t)i, (size_t)j) = kind == 0 ? std::sqrt(best) : best;
      }
    return dataValue(o, line);
  } SP_END
  SP_ADD("distance_cdt", 1, 2, "mask, metric=\"chessboard\"") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    const std::string metric = optText(a, 1, "chessboard");
    const bool box = metric == "chessboard";
    if (!box && metric != "taxicab" && metric != "cityblock" && metric != "manhattan") {
      ctx.fail("metric must be \"chessboard\" or \"taxicab\"");
      return Value(0.0);
    }
    const double big = (double)(m.a.size() + m.r + m.c + 1);
    Mat d(m.r, m.c);
    bool anyZero = false;
    for (size_t i = 0; i < m.a.size(); i++) {
      d.a[i] = m.a[i] != 0.0 ? big : 0.0;
      anyZero = anyZero || m.a[i] == 0.0;
    }
    const long R = (long)m.r, C = (long)m.c;
    auto relax = [&](long i, long j, long di, long dj) {
      const long p = i + di, q = j + dj;
      if (p >= 0 && p < R && q >= 0 && q < C)
        d((size_t)i, (size_t)j) = std::min(d((size_t)i, (size_t)j), d((size_t)p, (size_t)q) + 1.0);
    };
    for (long i = 0; i < R; i++)
      for (long j = 0; j < C; j++) {
        relax(i, j, -1, 0);
        relax(i, j, 0, -1);
        if (box) {
          relax(i, j, -1, -1);
          relax(i, j, -1, 1);
        }
      }
    for (long i = R - 1; i >= 0; i--)
      for (long j = C - 1; j >= 0; j--) {
        relax(i, j, 1, 0);
        relax(i, j, 0, 1);
        if (box) {
          relax(i, j, 1, 1);
          relax(i, j, 1, -1);
        }
      }
    if (!anyZero)
      for (double &v : d.a)
        v = -1.0;
    return dataValue(d, line);
  } SP_END
  SP_ADD("distance_edt", 1, 2, "mask, sampling") {
    Mat m;
    bool line;
    if (!getData(a, 0, ctx, m, line))
      return Value(0.0);
    double sr = 1.0, sc = 1.0;
    if (a.size() > 1 && !isOmitted(a, 1)) {
      Vec v;
      if (!getVec(a, 1, ctx, v))
        return Value(0.0);
      if (v.size() == 1)
        sr = sc = v[0];
      else if (v.size() == 2) {
        sr = v[0];
        sc = v[1];
      } else {
        ctx.fail("sampling must be one number or one per axis");
        return Value(0.0);
      }
    }
    Mat d(m.r, m.c);
    for (size_t i = 0; i < m.a.size(); i++)
      d.a[i] = m.a[i] != 0.0 ? kInf : 0.0;
    std::vector<long> v;
    Vec z, tmp(std::max(m.r, m.c)), col(m.r);
    for (size_t i = 0; i < m.r; i++) {
      edtLine(d.row(i), tmp.data(), m.c, sc, v, z);
      std::copy(tmp.begin(), tmp.begin() + (long)m.c, d.row(i));
    }
    if (m.r > 1 && !line)
      for (size_t j = 0; j < m.c; j++) {
        for (size_t i = 0; i < m.r; i++)
          col[i] = d(i, j);
        edtLine(col.data(), tmp.data(), m.r, sr, v, z);
        for (size_t i = 0; i < m.r; i++)
          d(i, j) = tmp[i];
      }
    for (double &x : d.a)
      x = std::sqrt(x);
    return dataValue(d, line);
  } SP_END
  registerImageInterp(reg);
  registerImageMeasure(reg);
  reg.setParallel({"img_generic_filter", "img_generic_filter1d", "img_vector_filter", "img_generic_gradient", "img_generic_laplace", "geometric_transform", "labeled_apply"},
                  ParallelClass::Interpreter);
}

} // namespace scipy
} // namespace nc
