// What the image files share: boundary modes and line helpers.
#ifndef NC_SCIPY_IP_SHARED_H
#define NC_SCIPY_IP_SHARED_H

#include <functional>

#include "../scipy_core.h"

#define COMMA_ ,

namespace nc {
namespace scipy {
namespace ip {

enum Mode { kReflect, kConstant, kNearest, kMirror, kWrap, kGridWrap };

bool parseMode(const Args &a, size_t i, CallContext &ctx, int &mode, const std::string &def = "reflect");
// The index a position outside the data reads, or -1 for the constant.
long extIndex(long i, long n, int mode);
Vec correlateLine(const Vec &x, const Vec &w, long origin, int mode, double cval);
// axis 0 = columns, 1 = rows.
Mat alongAxis(const Mat &m, int axis, const std::function<Vec(const Vec &)> &f);
// A Matrix, or a line turned into one row.
bool getData(const Args &a, size_t i, CallContext &ctx, Mat &m, bool &line);

} // namespace ip
} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_IP_SHARED_H
