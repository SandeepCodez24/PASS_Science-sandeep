// Section 18 of 25 - Graph Routines (scipy.sparse.csgraph). A graph is a Sparse
// or Matrix of edge weights; zero means no edge.
#include "graph_routines_main.h"

#include <functional>
#include <limits>
#include <queue>

#include "../linear_algebra/la_core.h"
#include "../scipy_core.h"
#include "../sparse_matrices/sp_core.h"

#define SP_SEC Section::GraphRoutines

namespace nc {
namespace scipy {

using namespace sp;

namespace {

struct Edge {
  size_t to;
  double w;
};
using Adj = std::vector<std::vector<Edge>>;

Adj adjacency(const Sparse &g, bool directed) {
  Adj a(g.r);
  for (size_t i = 0; i < g.r; i++)
    for (size_t k = g.ptr[i]; k < g.ptr[i + 1]; k++)
      if (g.val[k] != 0.0) {
        a[i].push_back({g.idx[k], g.val[k]});
        if (!directed)
          a[g.idx[k]].push_back({i, g.val[k]});
      }
  return a;
}

bool getGraph(const Args &a, size_t i, CallContext &ctx, Sparse &g) {
  if (!getAny(a, i, ctx, g))
    return false;
  if (g.r != g.c) {
    ctx.fail("the graph must be a square matrix");
    return false;
  }
  return true;
}

void dijkstraFrom(const Adj &adj, size_t s, Vec &dist, IVec &pred) {
  const size_t n = adj.size();
  dist.assign(n, kInf);
  pred.assign(n, -9999);
  using QE = std::pair<double, size_t>;
  std::priority_queue<QE, std::vector<QE>, std::greater<QE>> q;
  dist[s] = 0.0;
  q.push({0.0, s});
  while (!q.empty()) {
    auto [d, u] = q.top();
    q.pop();
    if (d > dist[u])
      continue;
    for (const Edge &e : adj[u])
      if (d + e.w < dist[e.to]) {
        dist[e.to] = d + e.w;
        pred[e.to] = (long long)u;
        q.push({dist[e.to], e.to});
      }
  }
}

bool bellmanFrom(const Adj &adj, size_t s, Vec &dist, IVec &pred) {
  const size_t n = adj.size();
  dist.assign(n, kInf);
  pred.assign(n, -9999);
  dist[s] = 0.0;
  for (size_t it = 0; it < n; it++) {
    bool changed = false;
    for (size_t u = 0; u < n; u++) {
      if (dist[u] == kInf)
        continue;
      for (const Edge &e : adj[u])
        if (dist[u] + e.w < dist[e.to]) {
          dist[e.to] = dist[u] + e.w;
          pred[e.to] = (long long)u;
          changed = true;
        }
    }
    if (!changed)
      return true;
  }
  return false;
}

Mat floyd(const Sparse &g, bool directed) {
  const size_t n = g.r;
  Mat D(n, n, kInf);
  for (size_t i = 0; i < n; i++)
    D(i, i) = 0.0;
  for (size_t i = 0; i < n; i++)
    for (size_t k = g.ptr[i]; k < g.ptr[i + 1]; k++)
      if (g.val[k] != 0.0) {
        D(i, g.idx[k]) = std::min(D(i, g.idx[k]), g.val[k]);
        if (!directed)
          D(g.idx[k], i) = std::min(D(g.idx[k], i), g.val[k]);
      }
  for (size_t k = 0; k < n; k++)
    for (size_t i = 0; i < n; i++) {
      if (D(i, k) == kInf)
        continue;
      for (size_t j = 0; j < n; j++)
        if (D(i, k) + D(k, j) < D(i, j))
          D(i, j) = D(i, k) + D(k, j);
    }
  return D;
}

bool johnsonAll(const Adj &adj, Mat &D) {
  const size_t n = adj.size();
  // Potentials from a virtual source joined to every node.
  Vec h(n, 0.0);
  for (size_t it = 0; it <= n; it++) {
    bool changed = false;
    for (size_t u = 0; u < n; u++)
      for (const Edge &e : adj[u])
        if (h[u] + e.w < h[e.to]) {
          h[e.to] = h[u] + e.w;
          changed = true;
        }
    if (!changed)
      break;
    if (it == n)
      return false;
  }
  Adj rw = adj;
  for (size_t u = 0; u < n; u++)
    for (Edge &e : rw[u])
      e.w += h[u] - h[e.to];
  D = Mat(n, n);
  par::forBlocks(n, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    for (size_t s = b; s < e; s++) {
      Vec d;
      IVec p;
      dijkstraFrom(rw, s, d, p);
      for (size_t t = 0; t < n; t++)
        D(s, t) = d[t] == kInf ? kInf : d[t] - h[s] + h[t];
    }
  });
  return true;
}

// Sources: one Int, an Array, or all of them.
bool getSources(const Args &a, size_t i, size_t n, std::vector<size_t> &src, bool &single, CallContext &ctx) {
  single = false;
  src.clear();
  if (i >= a.size()) {
    for (size_t k = 0; k < n; k++)
      src.push_back(k);
    return true;
  }
  Vec v;
  if (!readVec(a[i], v)) {
    ctx.fail("the start nodes must be a number or an array");
    return false;
  }
  single = isPlainNumber(a[i]);
  for (double d : v) {
    if (d < 0 || d >= (double)n) {
      ctx.fail("a start node lies outside the graph");
      return false;
    }
    src.push_back((size_t)d);
  }
  return true;
}

Value rowsOrLine(const Mat &m, bool single) {
  if (single) {
    Vec v(m.a);
    return toValue(v);
  }
  return toValue(m);
}

void components(const Sparse &g, bool directed, const std::string &conn, IVec &labels, size_t &count) {
  const size_t n = g.r;
  labels.assign(n, -1);
  count = 0;
  if (!directed || conn != "strong") {
    Adj und = adjacency(g, false);
    std::vector<size_t> st;
    for (size_t s = 0; s < n; s++) {
      if (labels[s] >= 0)
        continue;
      st.push_back(s);
      labels[s] = (long long)count;
      while (!st.empty()) {
        size_t u = st.back();
        st.pop_back();
        for (const Edge &e : und[u])
          if (labels[e.to] < 0) {
            labels[e.to] = (long long)count;
            st.push_back(e.to);
          }
      }
      count++;
    }
    return;
  }
  // Tarjan, without recursion.
  Adj adj = adjacency(g, true);
  std::vector<long> idx(n, -1), low(n, 0);
  std::vector<char> on(n, 0);
  std::vector<size_t> stack, it(n, 0), call;
  long next = 0;
  for (size_t s = 0; s < n; s++) {
    if (idx[s] >= 0)
      continue;
    call.push_back(s);
    while (!call.empty()) {
      size_t u = call.back();
      if (idx[u] < 0) {
        idx[u] = low[u] = next++;
        stack.push_back(u);
        on[u] = 1;
      }
      if (it[u] < adj[u].size()) {
        size_t v = adj[u][it[u]++].to;
        if (idx[v] < 0)
          call.push_back(v);
        else if (on[v])
          low[u] = std::min(low[u], idx[v]);
      } else {
        if (low[u] == idx[u]) {
          while (true) {
            size_t w = stack.back();
            stack.pop_back();
            on[w] = 0;
            labels[w] = (long long)count;
            if (w == u)
              break;
          }
          count++;
        }
        call.pop_back();
        if (!call.empty())
          low[call.back()] = std::min(low[call.back()], low[u]);
      }
    }
  }
}

// Hopcroft-Karp over the rows of a bipartite graph. match[r] = column or -1.
IVec matchRows(const Sparse &g) {
  const size_t nr = g.r, nc = g.c;
  IVec mr(nr, -1), mc(nc, -1);
  std::vector<long> dist(nr);
  auto bfs = [&]() {
    std::queue<size_t> q;
    bool found = false;
    for (size_t r = 0; r < nr; r++) {
      if (mr[r] < 0) {
        dist[r] = 0;
        q.push(r);
      } else {
        dist[r] = -1;
      }
    }
    while (!q.empty()) {
      size_t r = q.front();
      q.pop();
      for (size_t k = g.ptr[r]; k < g.ptr[r + 1]; k++) {
        const long long m = mc[g.idx[k]];
        if (m < 0)
          found = true;
        else if (dist[(size_t)m] < 0) {
          dist[(size_t)m] = dist[r] + 1;
          q.push((size_t)m);
        }
      }
    }
    return found;
  };
  std::function<bool(size_t)> dfs = [&](size_t r) {
    for (size_t k = g.ptr[r]; k < g.ptr[r + 1]; k++) {
      const size_t c = g.idx[k];
      const long long m = mc[c];
      if (m < 0 || (dist[(size_t)m] == dist[r] + 1 && dfs((size_t)m))) {
        mr[r] = (long long)c;
        mc[c] = (long long)r;
        return true;
      }
    }
    dist[r] = -1;
    return false;
  };
  while (bfs())
    for (size_t r = 0; r < nr; r++)
      if (mr[r] < 0)
        dfs(r);
  return mr;
}

// Assignment problem on a dense matrix: the Hungarian method, O(n^3).
bool hungarian(const Mat &C, IVec &rowToCol) {
  const size_t n = C.r, m = C.c; // n <= m
  const double inf = kInf;
  Vec u(n + 1, 0.0), v(m + 1, 0.0);
  std::vector<size_t> p(m + 1, 0), way(m + 1, 0);
  for (size_t i = 1; i <= n; i++) {
    p[0] = i;
    size_t j0 = 0;
    Vec minv(m + 1, inf);
    std::vector<char> used(m + 1, 0);
    do {
      used[j0] = 1;
      const size_t i0 = p[j0];
      double delta = inf;
      size_t j1 = 0;
      for (size_t j = 1; j <= m; j++)
        if (!used[j]) {
          const double cur = C(i0 - 1, j - 1) - u[i0] - v[j];
          if (cur < minv[j]) {
            minv[j] = cur;
            way[j] = j0;
          }
          if (minv[j] < delta) {
            delta = minv[j];
            j1 = j;
          }
        }
      if (delta == inf)
        return false;
      for (size_t j = 0; j <= m; j++) {
        if (used[j]) {
          u[p[j]] += delta;
          v[j] -= delta;
        } else {
          minv[j] -= delta;
        }
      }
      j0 = j1;
    } while (p[j0] != 0);
    do {
      const size_t j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0);
  }
  rowToCol.assign(n, -1);
  for (size_t j = 1; j <= m; j++)
    if (p[j])
      rowToCol[p[j] - 1] = (long long)(j - 1);
  return true;
}

Value predsValue(const IVec &p) { return toValue(p); }

} // namespace

namespace graph_shared {
bool assignmentMin(const Mat &cost, IVec &rows, IVec &cols) {
  // Works with fewer rows than columns; a wide matrix is transposed first.
  if (cost.r <= cost.c) {
    IVec r2c;
    if (!hungarian(cost, r2c))
      return false;
    rows.clear();
    cols.clear();
    for (size_t i = 0; i < r2c.size(); i++) {
      rows.push_back((long long)i);
      cols.push_back(r2c[i]);
    }
    return true;
  }
  Mat t = transposeOf(cost);
  IVec r2c;
  if (!hungarian(t, r2c))
    return false;
  std::vector<std::pair<long long, long long>> pairs;
  for (size_t i = 0; i < r2c.size(); i++)
    pairs.push_back({r2c[i], (long long)i});
  std::sort(pairs.begin(), pairs.end());
  rows.clear();
  cols.clear();
  for (auto &q : pairs) {
    rows.push_back(q.first);
    cols.push_back(q.second);
  }
  return true;
}
} // namespace graph_shared

void registerGraphRoutines(Registry &reg) {
  SP_ADD("graph_components", 1, 3, "G, directed=1, connection=\"weak\"") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    IVec lab;
    size_t count;
    components(g, optBool(a, 1, true), optText(a, 2, "weak"), lab, count);
    return makeDict({{"count", Value((double)count)}, {"labels", toValue(lab)}});
  } SP_END
  SP_ADD("graph_laplacian", 1, 2, "G, normed=0") {
    const bool wasSparse = isSparse(a[0]);
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    const bool normed = optBool(a, 1, false);
    Mat D = toDense(g);
    const size_t n = D.r;
    Vec deg(n, 0.0);
    for (size_t j = 0; j < n; j++)
      for (size_t i = 0; i < n; i++)
        if (i != j)
          deg[j] += D(i, j);
    Mat L(n, n);
    for (size_t i = 0; i < n; i++)
      for (size_t j = 0; j < n; j++) {
        if (i == j)
          L(i, j) = normed ? (deg[i] > 0 ? 1.0 : 0.0) : deg[i];
        else
          L(i, j) = normed ? (deg[i] > 0 && deg[j] > 0 ? -D(i, j) / std::sqrt(deg[i] * deg[j]) : 0.0) : -D(i, j);
      }
    return wasSparse ? sp::toValue(fromDense(L, g.fmt)) : toValue(L);
  } SP_END
  SP_ADD("shortest_path", 1, 3, "G, directed=1, method=\"auto\"") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    const bool directed = optBool(a, 1, true);
    std::string m = optText(a, 2, "auto");
    if (m != "auto" && m != "D" && m != "FW" && m != "BF" && m != "J") {
      ctx.fail("method must be \"auto\", \"D\", \"FW\", \"BF\" or \"J\"");
      return Value(0.0);
    }
    bool neg = false;
    for (double v : g.val)
      neg = neg || v < 0.0;
    if (m == "auto")
      m = neg ? "J" : "D";
    Adj adj = adjacency(g, directed);
    const size_t n = g.r;
    Mat D(n, n);
    if (m == "FW") {
      D = floyd(g, directed);
    } else if (m == "J") {
      if (!johnsonAll(adj, D)) {
        ctx.fail("the graph has a negative cycle");
        return Value(0.0);
      }
    } else {
      if (m == "D" && neg) {
        ctx.fail("method \"D\" needs edge weights that are not negative");
        return Value(0.0);
      }
      bool ok = true;
      par::forBlocks(n, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
        for (size_t s = b; s < e; s++) {
          Vec dv;
          IVec p;
          if (m == "D")
            dijkstraFrom(adj, s, dv, p);
          else
            ok = bellmanFrom(adj, s, dv, p) && ok;
          for (size_t t = 0; t < n; t++)
            D(s, t) = dv[t];
        }
      });
      if (!ok) {
        ctx.fail("the graph has a negative cycle");
        return Value(0.0);
      }
    }
    return toValue(D);
  } SP_END
  SP_ADD("dijkstra", 1, 3, "G, indices, directed=1") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    for (double v : g.val)
      if (v < 0.0) {
        ctx.fail("dijkstra needs edge weights that are not negative");
        return Value(0.0);
      }
    std::vector<size_t> src;
    bool single;
    if (!getSources(a, 1, g.r, src, single, ctx))
      return Value(0.0);
    Adj adj = adjacency(g, optBool(a, 2, true));
    Mat D(src.size(), g.r);
    par::forBlocks(src.size(), {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
      for (size_t s = b; s < e; s++) {
        Vec dv;
        IVec p;
        dijkstraFrom(adj, src[s], dv, p);
        std::copy(dv.begin(), dv.end(), D.row(s));
      }
    });
    return rowsOrLine(D, single);
  } SP_END
  SP_ADD("floyd_warshall", 1, 2, "G, directed=1") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    return toValue(floyd(g, optBool(a, 1, true)));
  } SP_END
  SP_ADD("bellman_ford", 1, 3, "G, indices, directed=1") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    std::vector<size_t> src;
    bool single;
    if (!getSources(a, 1, g.r, src, single, ctx))
      return Value(0.0);
    Adj adj = adjacency(g, optBool(a, 2, true));
    Mat D(src.size(), g.r);
    for (size_t s = 0; s < src.size(); s++) {
      Vec dv;
      IVec p;
      if (!bellmanFrom(adj, src[s], dv, p)) {
        ctx.fail("the graph has a negative cycle");
        return Value(0.0);
      }
      std::copy(dv.begin(), dv.end(), D.row(s));
    }
    return rowsOrLine(D, single);
  } SP_END
  SP_ADD("johnson", 1, 2, "G, directed=1") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    Mat D;
    if (!johnsonAll(adjacency(g, optBool(a, 1, true)), D)) {
      ctx.fail("the graph has a negative cycle");
      return Value(0.0);
    }
    return toValue(D);
  } SP_END
  SP_ADD("k_shortest_paths", 4, 4, "G, source, sink, K") {
    // Yen's algorithm on top of Dijkstra.
    Sparse g;
    long long s, t, K;
    if (!getGraph(a, 0, ctx, g) || !argNonNegativeInt(a, 1, ctx, s) || !argNonNegativeInt(a, 2, ctx, t) || !argNonNegativeInt(a, 3, ctx, K))
      return Value(0.0);
    const size_t n = g.r;
    if ((size_t)s >= n || (size_t)t >= n) {
      ctx.fail("source or sink lies outside the graph");
      return Value(0.0);
    }
    Adj adj = adjacency(g, true);
    using Path = std::vector<size_t>;
    auto cost = [&](const Path &p) {
      double c = 0.0;
      for (size_t i = 0; i + 1 < p.size(); i++)
        for (const Edge &e : adj[p[i]])
          if (e.to == p[i + 1]) {
            c += e.w;
            break;
          }
      return c;
    };
    auto best = [&](const Adj &g2, size_t from, Path &out) {
      Vec d;
      IVec p;
      dijkstraFrom(g2, from, d, p);
      if (d[(size_t)t] == kInf)
        return false;
      out.clear();
      for (long long v = t; v != -9999; v = p[(size_t)v])
        out.push_back((size_t)v);
      std::reverse(out.begin(), out.end());
      return true;
    };
    std::vector<Path> A;
    std::vector<std::pair<double, Path>> B;
    Path first;
    if (best(adj, (size_t)s, first))
      A.push_back(first);
    for (long long k = 1; k < K && !A.empty() && A.size() == (size_t)k; k++) {
      const Path &last = A.back();
      for (size_t i = 0; i + 1 < last.size(); i++) {
        Path root(last.begin(), last.begin() + i + 1);
        Adj g2 = adj;
        for (const Path &p : A)
          if (p.size() > i + 1 && std::equal(root.begin(), root.end(), p.begin())) {
            auto &es = g2[p[i]];
            es.erase(std::remove_if(es.begin(), es.end(), [&](const Edge &e) { return e.to == p[i + 1]; }), es.end());
          }
        for (size_t q = 0; q < i; q++)
          g2[root[q]].clear();
        for (auto &es : g2)
          es.erase(std::remove_if(es.begin(), es.end(), [&](const Edge &e) {
            return std::find(root.begin(), root.end() - 1, e.to) != root.end() - 1;
          }), es.end());
        Path spur;
        if (!best(g2, root.back(), spur))
          continue;
        Path full = root;
        full.insert(full.end(), spur.begin() + 1, spur.end());
        const double c = cost(full);
        bool dup = false;
        for (auto &e : B)
          dup = dup || e.second == full;
        for (auto &e : A)
          dup = dup || e == full;
        if (!dup)
          B.push_back({c, full});
      }
      if (B.empty())
        break;
      auto it = std::min_element(B.begin(), B.end(), [](const auto &x, const auto &y) { return x.first < y.first; });
      A.push_back(it->second);
      B.erase(it);
    }
    Vec dist;
    Mat P(A.size(), n, -9999.0);
    for (size_t i = 0; i < A.size(); i++) {
      dist.push_back(cost(A[i]));
      for (size_t q = 1; q < A[i].size(); q++)
        P(i, A[i][q]) = (double)A[i][q - 1];
    }
    return makeDict({{"distances", toValue(dist)}, {"predecessors", toValue(P)}});
  } SP_END
  SP_ADD("bfs_order", 2, 3, "G, start, directed=1") {
    Sparse g;
    long long s;
    if (!getGraph(a, 0, ctx, g) || !argNonNegativeInt(a, 1, ctx, s))
      return Value(0.0);
    if ((size_t)s >= g.r) {
      ctx.fail("the start node lies outside the graph");
      return Value(0.0);
    }
    Adj adj = adjacency(g, optBool(a, 2, true));
    IVec order, pred(g.r, -9999);
    std::vector<char> seen(g.r, 0);
    std::queue<size_t> q;
    q.push((size_t)s);
    seen[(size_t)s] = 1;
    while (!q.empty()) {
      size_t u = q.front();
      q.pop();
      order.push_back((long long)u);
      for (const Edge &e : adj[u])
        if (!seen[e.to]) {
          seen[e.to] = 1;
          pred[e.to] = (long long)u;
          q.push(e.to);
        }
    }
    return makeDict({{"order", toValue(order)}, {"predecessors", predsValue(pred)}});
  } SP_END
  SP_ADD("dfs_order", 2, 3, "G, start, directed=1") {
    Sparse g;
    long long s;
    if (!getGraph(a, 0, ctx, g) || !argNonNegativeInt(a, 1, ctx, s))
      return Value(0.0);
    if ((size_t)s >= g.r) {
      ctx.fail("the start node lies outside the graph");
      return Value(0.0);
    }
    Adj adj = adjacency(g, optBool(a, 2, true));
    IVec order, pred(g.r, -9999);
    std::vector<char> seen(g.r, 0);
    std::function<void(size_t)> visit = [&](size_t u) {
      seen[u] = 1;
      order.push_back((long long)u);
      for (const Edge &e : adj[u])
        if (!seen[e.to]) {
          pred[e.to] = (long long)u;
          visit(e.to);
        }
    };
    visit((size_t)s);
    return makeDict({{"order", toValue(order)}, {"predecessors", predsValue(pred)}});
  } SP_END
  SP_ADD("bfs_tree", 2, 3, "G, start, directed=1") {
    Sparse g;
    long long s;
    if (!getGraph(a, 0, ctx, g) || !argNonNegativeInt(a, 1, ctx, s))
      return Value(0.0);
    if ((size_t)s >= g.r) {
      ctx.fail("the start node lies outside the graph");
      return Value(0.0);
    }
    Adj adj = adjacency(g, optBool(a, 2, true));
    std::vector<char> seen(g.r, 0);
    std::vector<Triplet> t;
    std::queue<size_t> q;
    q.push((size_t)s);
    seen[(size_t)s] = 1;
    while (!q.empty()) {
      size_t u = q.front();
      q.pop();
      for (const Edge &e : adj[u])
        if (!seen[e.to]) {
          seen[e.to] = 1;
          t.push_back({u, e.to, e.w});
          q.push(e.to);
        }
    }
    return sp::toValue(fromTriplets(g.r, g.c, std::move(t)));
  } SP_END
  SP_ADD("dfs_tree", 2, 3, "G, start, directed=1") {
    Sparse g;
    long long s;
    if (!getGraph(a, 0, ctx, g) || !argNonNegativeInt(a, 1, ctx, s))
      return Value(0.0);
    if ((size_t)s >= g.r) {
      ctx.fail("the start node lies outside the graph");
      return Value(0.0);
    }
    Adj adj = adjacency(g, optBool(a, 2, true));
    std::vector<char> seen(g.r, 0);
    std::vector<Triplet> t;
    std::function<void(size_t)> visit = [&](size_t u) {
      seen[u] = 1;
      for (const Edge &e : adj[u])
        if (!seen[e.to]) {
          t.push_back({u, e.to, e.w});
          visit(e.to);
        }
    };
    visit((size_t)s);
    return sp::toValue(fromTriplets(g.r, g.c, std::move(t)));
  } SP_END
  SP_ADD("min_spanning_tree", 1, 1, "G") {
    // Kruskal; the smaller weight of (i, j) and (j, i) counts.
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    struct E {
      double w;
      size_t i, j;
    };
    std::vector<E> es;
    for (size_t i = 0; i < g.r; i++)
      for (size_t k = g.ptr[i]; k < g.ptr[i + 1]; k++)
        if (g.val[k] != 0.0)
          es.push_back({g.val[k], i, g.idx[k]});
    std::stable_sort(es.begin(), es.end(), [](const E &x, const E &y) { return x.w < y.w; });
    std::vector<size_t> par_(g.r);
    for (size_t i = 0; i < g.r; i++)
      par_[i] = i;
    std::function<size_t(size_t)> find = [&](size_t x) { return par_[x] == x ? x : par_[x] = find(par_[x]); };
    std::vector<Triplet> t;
    for (const E &e : es) {
      const size_t x = find(e.i), y = find(e.j);
      if (x != y) {
        par_[x] = y;
        t.push_back({e.i, e.j, e.w});
      }
    }
    return sp::toValue(fromTriplets(g.r, g.c, std::move(t)));
  } SP_END
  SP_ADD("reverse_cuthill_mckee", 1, 2, "G, symmetric=0") {
    Sparse g;
    if (!getGraph(a, 0, ctx, g))
      return Value(0.0);
    const size_t n = g.r;
    Adj adj = adjacency(g, optBool(a, 1, false));
    if (!optBool(a, 1, false))
      adj = adjacency(g, false);
    std::vector<size_t> deg(n);
    for (size_t i = 0; i < n; i++)
      deg[i] = adj[i].size();
    std::vector<char> seen(n, 0);
    std::vector<size_t> byDeg(n);
    for (size_t i = 0; i < n; i++)
      byDeg[i] = i;
    std::stable_sort(byDeg.begin(), byDeg.end(), [&](size_t x, size_t y) { return deg[x] < deg[y]; });
    IVec order;
    for (size_t s : byDeg) {
      if (seen[s])
        continue;
      std::queue<size_t> q;
      q.push(s);
      seen[s] = 1;
      while (!q.empty()) {
        size_t u = q.front();
        q.pop();
        order.push_back((long long)u);
        std::vector<size_t> nb;
        for (const Edge &e : adj[u])
          if (!seen[e.to]) {
            seen[e.to] = 1;
            nb.push_back(e.to);
          }
        std::stable_sort(nb.begin(), nb.end(), [&](size_t x, size_t y) { return deg[x] < deg[y]; });
        for (size_t v : nb)
          q.push(v);
      }
    }
    std::reverse(order.begin(), order.end());
    return toValue(order);
  } SP_END
  SP_ADD("max_flow", 3, 3, "G, source, sink") {
    // Dinic's algorithm.
    Sparse g;
    long long s, t;
    if (!getGraph(a, 0, ctx, g) || !argNonNegativeInt(a, 1, ctx, s) || !argNonNegativeInt(a, 2, ctx, t))
      return Value(0.0);
    if ((size_t)s >= g.r || (size_t)t >= g.r || s == t) {
      ctx.fail("source and sink must be two different nodes of the graph");
      return Value(0.0);
    }
    struct FE {
      size_t to, rev;
      double cap;
      bool forward;
      size_t i, j;
    };
    std::vector<std::vector<FE>> net(g.r);
    for (size_t i = 0; i < g.r; i++)
      for (size_t k = g.ptr[i]; k < g.ptr[i + 1]; k++)
        if (g.val[k] > 0.0) {
          const size_t j = g.idx[k];
          net[i].push_back({j, net[j].size(), g.val[k], true, i, j});
          net[j].push_back({i, net[i].size() - 1, 0.0, false, i, j});
        }
    std::vector<long> level(g.r);
    std::vector<size_t> iter(g.r);
    auto bfs = [&]() {
      std::fill(level.begin(), level.end(), -1);
      std::queue<size_t> q;
      q.push((size_t)s);
      level[(size_t)s] = 0;
      while (!q.empty()) {
        size_t u = q.front();
        q.pop();
        for (const FE &e : net[u])
          if (e.cap > 0.0 && level[e.to] < 0) {
            level[e.to] = level[u] + 1;
            q.push(e.to);
          }
      }
      return level[(size_t)t] >= 0;
    };
    std::function<double(size_t, double)> dfs = [&](size_t u, double f) -> double {
      if (u == (size_t)t)
        return f;
      for (size_t &i = iter[u]; i < net[u].size(); i++) {
        FE &e = net[u][i];
        if (e.cap > 0.0 && level[e.to] == level[u] + 1) {
          const double d = dfs(e.to, std::min(f, e.cap));
          if (d > 0.0) {
            e.cap -= d;
            net[e.to][e.rev].cap += d;
            return d;
          }
        }
      }
      return 0.0;
    };
    double flow = 0.0;
    while (bfs()) {
      std::fill(iter.begin(), iter.end(), 0);
      for (double f = dfs((size_t)s, kInf); f > 0.0; f = dfs((size_t)s, kInf))
        flow += f;
    }
    std::vector<Triplet> ft;
    for (size_t u = 0; u < g.r; u++)
      for (const FE &e : net[u])
        if (!e.forward && e.cap > 0.0) {
          ft.push_back({e.i, e.j, e.cap});
          ft.push_back({e.j, e.i, -e.cap});
        }
    return makeDict({{"flow_value", Value(flow)}, {"flow", sp::toValue(fromTriplets(g.r, g.c, std::move(ft)))}});
  } SP_END
  SP_ADD("bipartite_matching", 1, 2, "G, perm_type=\"row\"") {
    Sparse g;
    if (!getAny(a, 0, ctx, g))
      return Value(0.0);
    const std::string pt = optText(a, 1, "row");
    if (pt != "row" && pt != "column") {
      ctx.fail("perm_type must be \"row\" or \"column\"");
      return Value(0.0);
    }
    IVec mr = matchRows(g);
    if (pt == "column")
      return toValue(mr);
    // "row": for each column, the row matched to it (SciPy's convention).
    IVec mc(g.c, -1);
    for (size_t r = 0; r < mr.size(); r++)
      if (mr[r] >= 0)
        mc[(size_t)mr[r]] = (long long)r;
    return toValue(mc);
  } SP_END
  SP_ADD("min_weight_matching", 1, 2, "G, maximize=0") {
    Sparse g;
    if (!getAny(a, 0, ctx, g))
      return Value(0.0);
    const bool mx = optBool(a, 1, false);
    Mat C(g.r, g.c, kInf);
    for (size_t i = 0; i < g.r; i++)
      for (size_t k = g.ptr[i]; k < g.ptr[i + 1]; k++)
        C(i, g.idx[k]) = mx ? -g.val[k] : g.val[k];
    IVec rows, cols;
    if (!graph_shared::assignmentMin(C, rows, cols)) {
      ctx.fail("no full matching exists");
      return Value(0.0);
    }
    return makeDict({{"rows", toValue(rows)}, {"cols", toValue(cols)}});
  } SP_END
  SP_ADD("structural_rank", 1, 1, "G") {
    Sparse g;
    if (!getAny(a, 0, ctx, g))
      return Value(0.0);
    IVec mr = matchRows(g);
    double n = 0.0;
    for (long long v : mr)
      n += v >= 0;
    return Value(n);
  } SP_END
  SP_ADD("path_dist_matrix", 2, 3, "G, predecessors, directed=1") {
    Sparse g;
    Mat P;
    if (!getGraph(a, 0, ctx, g) || !getMat(a, 1, ctx, P))
      return Value(0.0);
    const size_t n = g.r;
    if (P.r != n || P.c != n) {
      ctx.fail("predecessors must have the shape of the graph");
      return Value(0.0);
    }
    for (double v : P.a)
      if (!(v < (double)n) || v != std::floor(v)) {
        ctx.fail("predecessors must be node numbers, or negative for none");
        return Value(0.0);
      }
    Mat W = toDense(g);
    const bool directed = optBool(a, 2, true);
    Mat D(n, n, kInf);
    for (size_t i = 0; i < n; i++) {
      D(i, i) = 0.0;
      for (size_t j = 0; j < n; j++) {
        if (i == j)
          continue;
        double s = 0.0;
        long long v = (long long)j;
        bool ok = true;
        for (size_t guard = 0; v != (long long)i && guard <= n; guard++) {
          const double pr = P(i, (size_t)v);
          if (pr < 0) {
            ok = false;
            break;
          }
          double e = W((size_t)pr, (size_t)v);
          if (!directed && e == 0.0)
            e = W((size_t)v, (size_t)pr);
          s += e;
          v = (long long)pr;
        }
        if (ok && v == (long long)i)
          D(i, j) = s;
      }
    }
    return toValue(D);
  } SP_END
  SP_ADD("reconstruct_path", 2, 3, "G, predecessors, directed=1") {
    Sparse g;
    Vec p;
    if (!getGraph(a, 0, ctx, g) || !getVec(a, 1, ctx, p))
      return Value(0.0);
    if (p.size() != g.r) {
      ctx.fail("predecessors must have one value per node");
      return Value(0.0);
    }
    for (double v : p)
      if (!(v < (double)g.r) || v != std::floor(v) || g.r != g.c) {
        ctx.fail("predecessors must be node numbers, or negative for none, of a square graph");
        return Value(0.0);
      }
    Mat W = toDense(g);
    const bool directed = optBool(a, 2, true);
    std::vector<Triplet> t;
    for (size_t j = 0; j < p.size(); j++) {
      if (p[j] < 0)
        continue;
      double e = W((size_t)p[j], j);
      if (!directed && e == 0.0)
        e = W(j, (size_t)p[j]);
      t.push_back({(size_t)p[j], j, e});
    }
    return sp::toValue(fromTriplets(g.r, g.c, std::move(t)));
  } SP_END
  SP_ADD("graph_from_dense", 1, 2, "G, null_value=0") {
    Mat D;
    if (!getMat(a, 0, ctx, D))
      return Value(0.0);
    const double nv = optNum(a, 1, 0.0);
    std::vector<Triplet> t;
    for (size_t i = 0; i < D.r; i++)
      for (size_t j = 0; j < D.c; j++) {
        const double v = D(i, j);
        if (v == nv || v != v || v == 0.0 || std::isinf(v))
          continue;
        t.push_back({i, j, v});
      }
    return sp::toValue(fromTriplets(D.r, D.c, std::move(t)));
  } SP_END
  SP_ADD("graph_to_dense", 1, 2, "G, null_value=0") {
    Sparse g;
    if (!getAny(a, 0, ctx, g))
      return Value(0.0);
    const double nv = optNum(a, 1, 0.0);
    Mat D(g.r, g.c, nv);
    for (size_t i = 0; i < g.r; i++)
      for (size_t k = g.ptr[i]; k < g.ptr[i + 1]; k++)
        if (g.val[k] != 0.0)
          D(i, g.idx[k]) = g.val[k];
    return toValue(D);
  } SP_END
  reg.setParallel({"shortest_path", "dijkstra", "johnson"}, ParallelClass::Kernel);
}

} // namespace scipy
} // namespace nc
