// Section 2 of 25 - Physical & Mathematical Constants (scipy.constants).
// Constants are bare names; a variable the script assigns with the same name
// wins (Parser::readVariableOrConstant looks at variables first).
#include "constants_main.h"

#include "../scipy_core.h"
#include "co_table.h"

#define SP_SEC Section::Constants

namespace nc {
namespace scipy {

namespace {
const CodataRow *findCodata(const std::string &name) {
  static const std::unordered_map<std::string, const CodataRow *> table = [] {
    std::unordered_map<std::string, const CodataRow *> t;
    for (size_t i = 0; i < kCodataCount; i++)
      t.emplace(kCodata[i].name, &kCodata[i]);
    return t;
  }();
  auto it = table.find(name);
  return it == table.end() ? nullptr : it->second;
}

const CodataRow *needCodata(const Args &a, CallContext &ctx) {
  std::string n;
  if (!argText(a, 0, ctx, n))
    return nullptr;
  const CodataRow *r = findCodata(n);
  if (!r)
    ctx.fail("no physical constant is called \"" + n + "\" - constant_find(\"word\") lists the names");
  return r;
}

double toKelvin(double v, const std::string &u) {
  if (u == "kelvin") return v;
  if (u == "celsius") return v + 273.15;
  if (u == "fahrenheit") return (v - 32.0) * 5.0 / 9.0 + 273.15;
  return v * 5.0 / 9.0; // rankine
}
double fromKelvin(double v, const std::string &u) {
  if (u == "kelvin") return v;
  if (u == "celsius") return v - 273.15;
  if (u == "fahrenheit") return (v - 273.15) * 9.0 / 5.0 + 32.0;
  return v * 9.0 / 5.0; // rankine
}
std::string scaleName(const std::string &in) {
  std::string s = in;
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (s == "c" || s == "celsius") return "celsius";
  if (s == "k" || s == "kelvin") return "kelvin";
  if (s == "f" || s == "fahrenheit") return "fahrenheit";
  if (s == "r" || s == "rankine") return "rankine";
  return "";
}
Value sameShape(const Value &in, const std::function<double(double)> &fn, CallContext &ctx) {
  if (isPlainNumber(in))
    return Value(fn(in.number));
  Mat m;
  if (!readMat(in, m)) {
    ctx.fail("the values must be a number or an array of numbers");
    return Value(0.0);
  }
  for (double &v : m.a)
    v = fn(v);
  return toValue(m);
}
} // namespace

void registerConstants(Registry &reg) {
  for (size_t i = 0; i < kNamedCount; i++)
    reg.addConstant({kNamed[i].name, kNamed[i].value, kNamed[i].unit, kNamed[i].original});

  SP_ADD("constant_value", 1, 1, "name") {
    const CodataRow *r = needCodata(a, ctx);
    return r ? Value(r->value) : Value(0.0);
  } SP_END
  SP_ADD("constant_unit", 1, 1, "name") {
    const CodataRow *r = needCodata(a, ctx);
    return r ? Value(std::string(r->unit)) : Value(0.0);
  } SP_END
  SP_ADD("constant_precision", 1, 1, "name") {
    const CodataRow *r = needCodata(a, ctx);
    return r ? Value(r->value != 0.0 ? r->uncertainty / r->value : 0.0) : Value(0.0);
  } SP_END
  SP_ADD("constant_info", 1, 1, "name") {
    const CodataRow *r = needCodata(a, ctx);
    if (!r)
      return Value(0.0);
    return makeDict({{"value", Value(r->value)}, {"unit", Value(std::string(r->unit))}, {"uncertainty", Value(r->uncertainty)}});
  } SP_END
  SP_ADD("constant_find", 0, 1, "text") {
    std::string word = optText(a, 0, "");
    for (char &c : word)
      c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    std::vector<std::string> names;
    for (size_t i = 0; i < kCodataCount; i++) {
      std::string n = kCodata[i].name;
      for (char &c : n)
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
      if (kCodata[i].current && n.find(word) != std::string::npos)
        names.push_back(kCodata[i].name);
    }
    return namesValue(names);
  } SP_END
  SP_ADD("convert_temp", 3, 3, "values, from, to") {
    std::string f, t;
    if (!argText(a, 1, ctx, f) || !argText(a, 2, ctx, t))
      return Value(0.0);
    const std::string fs = scaleName(f), ts = scaleName(t);
    if (fs.empty() || ts.empty()) {
      ctx.fail("the scales are \"Celsius\", \"Kelvin\", \"Fahrenheit\" and \"Rankine\"");
      return Value(0.0);
    }
    return sameShape(a[0], [=](double v) { return fromKelvin(toKelvin(v, fs), ts); }, ctx);
  } SP_END
  SP_ADD("wavelength2freq", 1, 1, "lambda") {
    return sameShape(a[0], [](double v) { return 299792458.0 / v; }, ctx);
  } SP_END
  SP_ADD("freq2wavelength", 1, 1, "nu") {
    return sameShape(a[0], [](double v) { return 299792458.0 / v; }, ctx);
  } SP_END
}

} // namespace scipy
} // namespace nc
