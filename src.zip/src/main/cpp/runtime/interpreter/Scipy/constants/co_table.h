// Data tables of the constants section (generated into co_table.cpp).
#ifndef NC_SCIPY_CO_TABLE_H
#define NC_SCIPY_CO_TABLE_H

#include <cstddef>

namespace nc {
namespace scipy {

struct CodataRow {
  const char *name;
  double value;
  const char *unit;
  double uncertainty;
  bool current; // false: kept for old names, not listed by constant_find()
};
struct NamedConstant {
  const char *name;
  double value;
  const char *unit;
  const char *original;
};

extern const CodataRow kCodata[];
extern const size_t kCodataCount;
extern const NamedConstant kNamed[];
extern const size_t kNamedCount;

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_CO_TABLE_H
