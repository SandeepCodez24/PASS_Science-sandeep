// ODEs, Kreyszig chapters 1-4: qualitative and linear-equation tools.
//   direction_field  orthogonal_trajectories  picard_iteration      (ch. 1)
//   wronskian  variation_of_parameters  resonance_peak              (ch. 2-3)
//   phase_plane  find_critical_points  classify_critical_point      (ch. 4)
// The Jacobian of a system at a point is the existing jacobian() function
// (differentiation section), so the proposed jacobian_numeric is not added.
#include <algorithm>
#include <cmath>

#include "ode_builtin.h"

namespace nc {
namespace ops {

namespace ode {

bool readFunctionList(const Value &v, std::vector<Fn> &out) {
  out.clear();
  std::vector<Value> cells;
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      cells.push_back(v.at(i));
  } else if (v.isMatrix && !v.isND() && (v.rows() == 1 || v.cols() == 1)) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.cols(); c++)
        cells.push_back(v.at(r, c));
  } else {
    return false;
  }
  for (const Value &c : cells) {
    if (!isFnArg(c))
      return false;
    out.emplace_back(c);
  }
  return !out.empty();
}

bool SystemFn::read(const Value &v, CallContext &ctx) {
  parts_.clear();
  if (isFnArg(v)) {
    parts_.emplace_back(v);
    return true;
  }
  if (readFunctionList(v, parts_))
    return true;
  ctx.fail("the system must be a function returning [f1, f2, ...] (e.g. @F), or a list of "
           "functions, one per equation (e.g. [\"f1\", \"f2\"])");
  return false;
}

Vec SystemFn::eval(const Vec &x) {
  if (parts_.size() == 1)
    return parts_[0].vN(x);
  Vec out(parts_.size());
  for (size_t k = 0; k < parts_.size(); k++)
    out[k] = parts_[k].rN(x);
  return out;
}

bool SystemFn::failed() const {
  for (const Fn &f : parts_)
    if (f.failed())
      return true;
  return false;
}

std::string SystemFn::describe() const {
  return parts_.size() == 1 ? parts_[0].describe() : std::string("the system's functions");
}

} // namespace ode

namespace {

// x and y: two vectors (made into a meshgrid, rows along y) or two matrices of one shape.
bool argMesh(const Args &a, size_t ix, size_t iy, CallContext &ctx, Mat &X, Mat &Y) {
  if (given(a, ix) && given(a, iy) && isGridValue(a[ix]) && isGridValue(a[iy])) {
    if (!argMat(a, ix, ctx, X) || !argMat(a, iy, ctx, Y))
      return false;
    if (X.r != Y.r || X.c != Y.c) {
      ctx.fail("the two coordinate grids must have the same shape");
      return false;
    }
    return true;
  }
  Vec x, y;
  if (!argVec(a, ix, ctx, x) || !argVec(a, iy, ctx, y))
    return false;
  X = Mat(y.size(), x.size());
  Y = Mat(y.size(), x.size());
  for (size_t i = 0; i < y.size(); i++)
    for (size_t j = 0; j < x.size(); j++) {
      X(i, j) = x[j];
      Y(i, j) = y[i];
    }
  return true;
}

// Small dense solve (Gaussian elimination, partial pivoting).
bool solveSmall(Mat A, Vec b, Vec &x) {
  const size_t n = b.size();
  for (size_t k = 0; k < n; k++) {
    size_t p = k;
    for (size_t i = k + 1; i < n; i++)
      if (std::abs(A(i, k)) > std::abs(A(p, k)))
        p = i;
    if (A(p, k) == 0.0)
      return false;
    if (p != k) {
      for (size_t j = 0; j < n; j++)
        std::swap(A(k, j), A(p, j));
      std::swap(b[k], b[p]);
    }
    for (size_t i = k + 1; i < n; i++) {
      const double m = A(i, k) / A(k, k);
      for (size_t j = k; j < n; j++)
        A(i, j) -= m * A(k, j);
      b[i] -= m * b[k];
    }
  }
  x.assign(n, 0.0);
  for (size_t k = n; k-- > 0;) {
    double s = b[k];
    for (size_t j = k + 1; j < n; j++)
      s -= A(k, j) * x[j];
    x[k] = s / A(k, k);
  }
  return true;
}

// f'(t) of a function, fourth-order central difference.
double derivAt(Fn &f, double t) {
  const double h = stepFor({t});
  return (f.r(t - 2 * h) - 8 * f.r(t - h) + 8 * f.r(t + h) - f.r(t + 2 * h)) / (12 * h);
}

// k-th derivative by a central difference with one Richardson step (4th order).
double nthDerivAt(Fn &f, double t, int k) {
  if (k == 0)
    return f.r(t);
  if (k == 1)
    return derivAt(f, t);
  auto D = [&](double h) {
    double s = 0.0, binom = 1.0;
    for (int j = 0; j <= k; j++) {
      s += ((j % 2) ? -binom : binom) * f.r(t + (0.5 * k - j) * h);
      binom = binom * (k - j) / (j + 1);
    }
    return s / std::pow(h, k);
  };
  const double h = 2e-2 * std::max(1.0, std::abs(t));
  return (4.0 * D(0.5 * h) - D(h)) / 3.0;
}

// A function given as samples on x or as an NC function: its values (and derivatives) on x.
bool samplesOf(const Args &a, size_t i, const Vec &x, CallContext &ctx, Vec &y, Vec *dy) {
  if (isFnArg(a[i]) || isNumber(a[i])) {
    Fn f(a[i]);
    y.resize(x.size());
    if (dy)
      dy->resize(x.size());
    for (size_t k = 0; k < x.size(); k++) {
      y[k] = f.r(x[k]);
      if (dy)
        (*dy)[k] = f.isConstant() ? 0.0 : derivAt(f, x[k]);
    }
    return fnOk(f, ctx);
  }
  if (!argVec(a, i, ctx, y))
    return false;
  if (y.size() != x.size()) {
    ctx.fail(argLabel(i) + " must be a function or have one value per x (" +
             std::to_string(x.size()) + ")");
    return false;
  }
  if (dy)
    *dy = diff1(y, x);
  return true;
}

bool increasing(const Vec &x, CallContext &ctx, const char *name) {
  for (size_t k = 1; k < x.size(); k++)
    if (!(x[k] > x[k - 1])) {
      ctx.fail(std::string(name) + " must increase");
      return false;
    }
  return true;
}

} // namespace

#define OPS_DOMAIN Domain::Ode

void registerOde(OpsRegistry &reg) {

  // ---- ch. 1: direction field of y' = f(x, y) ----
  OPS_FN("direction_field", 3, 3, "direction_field(@f, x_grid, y_grid)", "Slope field",
         kCallsNC) {
    Fn f;
    Mat X, Y;
    if (!argCallable(a, 0, ctx, f) || !argMesh(a, 1, 2, ctx, X, Y))
      return Value();
    Mat U(X.r, X.c), V(X.r, X.c), S(X.r, X.c);
    for (size_t k = 0; k < X.a.size(); k++) {
      const double s = f.r2(X.a[k], Y.a[k]);
      const double n = std::sqrt(1.0 + s * s);
      S.a[k] = s;
      U.a[k] = std::isfinite(n) ? 1.0 / n : 0.0;
      V.a[k] = std::isfinite(n) ? s / n : (s > 0 ? 1.0 : -1.0);
    }
    if (!fnOk(f, ctx))
      return Value();
    return dictOf({{"X", matOf(X)}, {"Y", matOf(Y)}, {"U", matOf(U)}, {"V", matOf(V)},
                   {"slope", matOf(S)}});
  }
  OPS_END

  OPS_FN("orthogonal_trajectories", 3, 3, "orthogonal_trajectories(@f, x_grid, y_grid)",
         "Orthogonal slope field", kCallsNC) {
    Fn f;
    Mat X, Y;
    if (!argCallable(a, 0, ctx, f) || !argMesh(a, 1, 2, ctx, X, Y))
      return Value();
    // The family y' = f has orthogonal trajectories y' = -1/f: direction (-f, 1).
    Mat U(X.r, X.c), V(X.r, X.c), S(X.r, X.c);
    for (size_t k = 0; k < X.a.size(); k++) {
      const double s = f.r2(X.a[k], Y.a[k]);
      const double n = std::sqrt(1.0 + s * s);
      S.a[k] = s == 0.0 ? kInf : -1.0 / s;
      U.a[k] = std::isfinite(n) ? -s / n : (s > 0 ? -1.0 : 1.0);
      V.a[k] = std::isfinite(n) ? 1.0 / n : 0.0;
    }
    if (!fnOk(f, ctx))
      return Value();
    return dictOf({{"X", matOf(X)}, {"Y", matOf(Y)}, {"U", matOf(U)}, {"V", matOf(V)},
                   {"slope", matOf(S)}});
  }
  OPS_END

  OPS_FN("picard_iteration", 4, 4, "picard_iteration(@f, y0, t, iterations)",
         "Picard approximations", kCallsNC) {
    Fn f;
    double y0;
    Vec t;
    long long iters;
    if (!argCallable(a, 0, ctx, f) || !argNum(a, 1, ctx, y0) || !argVec(a, 2, ctx, t, 2) ||
        !argCount(a, 3, ctx, iters, 1, 200) || !increasing(t, ctx, "t"))
      return Value();
    // y_{n+1}(t) = y0 + integral from t0 to t of f(s, y_n(s)) ds; row n = y_n.
    Mat out(static_cast<size_t>(iters) + 1, t.size());
    Vec y(t.size(), y0), g(t.size());
    for (size_t j = 0; j < t.size(); j++)
      out(0, j) = y0;
    for (long long n = 1; n <= iters; n++) {
      for (size_t j = 0; j < t.size(); j++)
        g[j] = f.r2(t[j], y[j]);
      if (!fnOk(f, ctx))
        return Value();
      const Vec I = cumIntegrate(g, t);
      for (size_t j = 0; j < t.size(); j++) {
        y[j] = y0 + I[j];
        out(static_cast<size_t>(n), j) = y[j];
      }
    }
    return matOf(out);
  }
  OPS_END

  // ---- ch. 2-3 ----
  OPS_FN("wronskian", 2, 2, "wronskian(Y, t) | wronskian([\"y1\", \"y2\", ...], t)",
         "Wronskian determinant", kCallsNC) {
    Vec t;
    if (!argVec(a, 1, ctx, t))
      return Value();
    // rows[i][k] = (i-th derivative of y_k) at each t
    std::vector<Fn> fns;
    size_t n;
    std::vector<std::vector<Vec>> der; // der[k][i] = d^i y_k
    if (ode::readFunctionList(a[0], fns)) {
      n = fns.size();
      der.assign(n, std::vector<Vec>(n, Vec(t.size())));
      for (size_t k = 0; k < n; k++)
        for (size_t i = 0; i < n; i++)
          for (size_t j = 0; j < t.size(); j++)
            der[k][i][j] = nthDerivAt(fns[k], t[j], static_cast<int>(i));
      for (const Fn &f : fns)
        if (!fnOk(f, ctx))
          return Value();
    } else {
      Mat Y;
      if (!argMat(a, 0, ctx, Y))
        return Value();
      if (Y.c != t.size() && Y.r == t.size())
        Y = scipy::transposeOf(Y);
      if (Y.c != t.size()) {
        ctx.fail("Y must have one row per solution and one column per t value");
        return Value();
      }
      n = Y.r;
      if (t.size() < 2 * n + 1) {
        ctx.fail("sampled solutions need at least " + std::to_string(2 * n + 1) +
                 " points for their derivatives");
        return Value();
      }
      if (!increasing(t, ctx, "t"))
        return Value();
      der.assign(n, std::vector<Vec>(n));
      for (size_t k = 0; k < n; k++) {
        der[k][0] = Vec(Y.row(k), Y.row(k) + Y.c);
        for (size_t i = 1; i < n; i++)
          der[k][i] = diff1(der[k][i - 1], t);
      }
    }
    if (n < 2 || n > 6) {
      ctx.fail("the Wronskian needs 2 to 6 solutions");
      return Value();
    }
    Vec W(t.size());
    for (size_t j = 0; j < t.size(); j++) {
      Mat M(n, n);
      for (size_t i = 0; i < n; i++)
        for (size_t k = 0; k < n; k++)
          M(i, k) = der[k][i][j];
      // determinant by elimination
      double det = 1.0;
      for (size_t c = 0; c < n; c++) {
        size_t p = c;
        for (size_t r = c + 1; r < n; r++)
          if (std::abs(M(r, c)) > std::abs(M(p, c)))
            p = r;
        if (M(p, c) == 0.0) {
          det = 0.0;
          break;
        }
        if (p != c) {
          for (size_t q = 0; q < n; q++)
            std::swap(M(c, q), M(p, q));
          det = -det;
        }
        det *= M(c, c);
        for (size_t r = c + 1; r < n; r++) {
          const double m = M(r, c) / M(c, c);
          for (size_t q = c; q < n; q++)
            M(r, q) -= m * M(c, q);
        }
      }
      W[j] = det;
    }
    return vecLike(W, a[1]);
  }
  OPS_END

  OPS_FN("variation_of_parameters", 4, 4, "variation_of_parameters(y1, y2, r, x)",
         "Particular solution", kCallsNC) {
    Vec x, y1, y2, r, d1, d2;
    if (!argVec(a, 3, ctx, x, 3) || !increasing(x, ctx, "x") ||
        !samplesOf(a, 0, x, ctx, y1, &d1) || !samplesOf(a, 1, x, ctx, y2, &d2) ||
        !samplesOf(a, 2, x, ctx, r, nullptr))
      return Value();
    // y'' + p y' + q y = r:  yp = -y1 int(y2 r / W) + y2 int(y1 r / W)  (Kreyszig 2.10)
    Vec g1(x.size()), g2(x.size());
    for (size_t k = 0; k < x.size(); k++) {
      const double W = y1[k] * d2[k] - y2[k] * d1[k];
      if (std::abs(W) < 1e-300) {
        ctx.fail("the Wronskian of y1 and y2 is 0 at x = " + numText(x[k]) +
                 " - they must be independent solutions");
        return Value();
      }
      g1[k] = y2[k] * r[k] / W;
      g2[k] = y1[k] * r[k] / W;
    }
    const Vec I1 = cumIntegrate(g1, x), I2 = cumIntegrate(g2, x);
    Vec yp(x.size());
    for (size_t k = 0; k < x.size(); k++)
      yp[k] = -y1[k] * I1[k] + y2[k] * I2[k];
    return vecLike(yp, a[3]);
  }
  OPS_END

  OPS_FN("resonance_peak", 4, 5, "resonance_peak(m, c, k, omega_range[, F0])",
         "Resonance amplitude peak", 0) {
    double m, c, k, F0 = 1.0;
    Vec w;
    if (!argPositive(a, 0, ctx, m) || !argNum(a, 1, ctx, c) || !argPositive(a, 2, ctx, k) ||
        !argVec(a, 3, ctx, w) || (given(a, 4) && !argNum(a, 4, ctx, F0)))
      return Value();
    if (c < 0.0) {
      ctx.fail("the damping c must not be negative");
      return Value();
    }
    // [w_min, w_max] -> 1001 frequencies
    if (w.size() == 2) {
      const double lo = w[0], hi = w[1];
      w.resize(1001);
      for (size_t i = 0; i < w.size(); i++)
        w[i] = lo + (hi - lo) * static_cast<double>(i) / 1000.0;
    }
    for (double v : w)
      if (v < 0.0) {
        ctx.fail("the frequencies must not be negative");
        return Value();
      }
    // m y'' + c y' + k y = F0 cos(w t): amplitude C(w) = F0 / sqrt((k - m w^2)^2 + (c w)^2),
    // phase eta = atan2(c w, k - m w^2)  (Kreyszig 2.8).
    auto amp = [&](double om) {
      return std::abs(F0) / std::sqrt(std::pow(k - m * om * om, 2) + std::pow(c * om, 2));
    };
    Vec A(w.size()), eta(w.size());
    size_t best = 0;
    for (size_t i = 0; i < w.size(); i++) {
      A[i] = amp(w[i]);
      eta[i] = std::atan2(c * w[i], k - m * w[i] * w[i]);
      if (A[i] > A[best] || std::isinf(A[i]))
        best = i;
    }
    double wPeak, aPeak;
    const double w0 = std::sqrt(k / m), wmax2 = k / m - c * c / (2.0 * m * m);
    const double lo = *std::min_element(w.begin(), w.end()),
                 hi = *std::max_element(w.begin(), w.end());
    if (c == 0.0 && w0 >= lo && w0 <= hi) {
      wPeak = w0; // undamped: resonance, unbounded amplitude
      aPeak = kInf;
    } else if (wmax2 > 0.0 && std::sqrt(wmax2) >= lo && std::sqrt(wmax2) <= hi) {
      wPeak = std::sqrt(wmax2); // the exact maximum of C(w)
      aPeak = amp(wPeak);
    } else {
      wPeak = w[best]; // C(w) falls over the whole range: its largest value there
      aPeak = A[best];
    }
    return dictOf({{"omega_peak", Value(wPeak)},
                   {"amplitude_peak", Value(aPeak)},
                   {"omega0", Value(w0)},
                   {"omega", rowOf(w)},
                   {"amplitude", rowOf(A)},
                   {"phase", rowOf(eta)}});
  }
  OPS_END

  // ---- ch. 4: phase plane ----
  OPS_FN("phase_plane", 3, 3, "phase_plane(F, x1_grid, x2_grid)", "Phase-plane vector field",
         kCallsNC) {
    ode::SystemFn F;
    Mat X, Y;
    if (!F.read(a[0], ctx) || !argMesh(a, 1, 2, ctx, X, Y))
      return Value();
    Mat U(X.r, X.c), V(X.r, X.c), S(X.r, X.c);
    for (size_t k = 0; k < X.a.size(); k++) {
      const Vec v = F.eval({X.a[k], Y.a[k]});
      if (F.failed())
        break;
      if (v.size() != 2) {
        ctx.fail(F.describe() + " must give 2 components [x1', x2']");
        return Value();
      }
      U.a[k] = v[0];
      V.a[k] = v[1];
      S.a[k] = std::hypot(v[0], v[1]);
    }
    if (F.failed()) {
      ctx.fail(F.describe() + " could not be evaluated");
      return Value();
    }
    return dictOf({{"X1", matOf(X)}, {"X2", matOf(Y)}, {"U", matOf(U)}, {"V", matOf(V)},
                   {"speed", matOf(S)}});
  }
  OPS_END

  OPS_FN("find_critical_points", 2, 3, "find_critical_points(F, bounds[, starts])",
         "Critical points", kCallsNC) {
    ode::SystemFn F;
    Vec b;
    if (!F.read(a[0], ctx) || !argVec(a, 1, ctx, b))
      return Value();
    if (b.size() != 4 && b.size() != 6) {
      ctx.fail("bounds must be [x1_min, x1_max, x2_min, x2_max] (or 6 values for 3 equations)");
      return Value();
    }
    const size_t n = b.size() / 2;
    for (size_t d = 0; d < n; d++)
      if (!(b[2 * d + 1] > b[2 * d])) {
        ctx.fail("each upper bound must be larger than its lower bound");
        return Value();
      }
    long long starts = n == 2 ? 8 : 5;
    if (given(a, 2) && !argCount(a, 2, ctx, starts, 2, 50))
      return Value();
    double span = 0.0;
    for (size_t d = 0; d < n; d++)
      span = std::max(span, b[2 * d + 1] - b[2 * d]);
    // Newton from a grid of starting points, Jacobian by central differences.
    std::vector<Vec> found;
    const size_t total = static_cast<size_t>(std::pow(static_cast<double>(starts), n));
    for (size_t s = 0; s < total; s++) {
      Vec x(n);
      size_t rem = s;
      for (size_t d = 0; d < n; d++) {
        const size_t q = rem % static_cast<size_t>(starts);
        rem /= static_cast<size_t>(starts);
        x[d] = b[2 * d] + (b[2 * d + 1] - b[2 * d]) * (q + 0.5) / static_cast<double>(starts);
      }
      bool ok = false;
      for (int it = 0; it < 60; it++) {
        const Vec f = F.eval(x);
        if (F.failed() || f.size() != n)
          break;
        double fn = 0.0;
        for (double v : f)
          fn = std::max(fn, std::abs(v));
        if (fn < 1e-12) {
          ok = true;
          break;
        }
        Mat J(n, n);
        const double h = 1e-6 * std::max(1.0, span);
        for (size_t d = 0; d < n; d++) {
          Vec xp = x, xm = x;
          xp[d] += h;
          xm[d] -= h;
          const Vec fp = F.eval(xp), fm = F.eval(xm);
          if (fp.size() != n || fm.size() != n)
            break;
          for (size_t r = 0; r < n; r++)
            J(r, d) = (fp[r] - fm[r]) / (2 * h);
        }
        Vec dx, rhs(n);
        for (size_t r = 0; r < n; r++)
          rhs[r] = -f[r];
        if (!solveSmall(J, rhs, dx))
          break;
        double step = 0.0;
        for (size_t d = 0; d < n; d++) {
          x[d] += dx[d];
          step = std::max(step, std::abs(dx[d]));
        }
        if (step < 1e-13 * std::max(1.0, span)) {
          const Vec f2 = F.eval(x);
          double r2 = 0.0;
          for (double v : f2)
            r2 = std::max(r2, std::abs(v));
          ok = r2 < 1e-8;
          break;
        }
      }
      if (F.failed()) {
        ctx.fail(F.describe() + " could not be evaluated");
        return Value();
      }
      if (!ok)
        continue;
      bool inside = true;
      for (size_t d = 0; d < n; d++)
        inside = inside && x[d] >= b[2 * d] - 1e-9 * span && x[d] <= b[2 * d + 1] + 1e-9 * span;
      if (!inside)
        continue;
      bool dup = false;
      for (const Vec &p : found) {
        double dist = 0.0;
        for (size_t d = 0; d < n; d++)
          dist = std::max(dist, std::abs(p[d] - x[d]));
        dup = dup || dist < 1e-6 * std::max(1.0, span);
      }
      if (!dup) {
        for (double &v : x)
          if (std::abs(v) < 1e-12 * std::max(1.0, span))
            v = 0.0; // a root at 0 to rounding is 0
        found.push_back(x);
      }
    }
    std::sort(found.begin(), found.end());
    if (found.empty())
      return Value(std::vector<std::vector<Value>>{});
    Mat P(found.size(), n);
    for (size_t r = 0; r < found.size(); r++)
      for (size_t d = 0; d < n; d++)
        P(r, d) = found[r][d];
    return matOf(P);
  }
  OPS_END

  OPS_FN("classify_critical_point", 1, 1, "classify_critical_point(J)",
         "Critical point type, stability", 0) {
    Mat J;
    if (!argMat(a, 0, ctx, J))
      return Value();
    if (J.r != 2 || J.c != 2) {
      ctx.fail("J must be the 2 x 2 Jacobian of a system of two equations at the point");
      return Value();
    }
    // Kreyszig 4.4: p = trace, q = det, Delta = p^2 - 4q.
    const double p = J(0, 0) + J(1, 1), q = J(0, 0) * J(1, 1) - J(0, 1) * J(1, 0);
    const double D = p * p - 4.0 * q;
    double s = 0.0;
    for (double v : J.a)
      s = std::max(s, std::abs(v));
    const double tp = 1e-12 * std::max(1.0, s), tq = 1e-12 * std::max(1.0, s * s);
    const bool p0 = std::abs(p) <= tp, q0 = std::abs(q) <= tq, D0 = std::abs(D) <= tq;
    std::string type, detail, stability;
    if (q0) {
      type = "degenerate";
      detail = "det J = 0: the critical point is not isolated";
      stability = p < -tp ? "stable" : (p > tp ? "unstable" : "undetermined");
    } else if (q < 0) {
      type = "saddle";
      detail = "saddle point";
      stability = "unstable";
    } else if (p0) {
      type = "center";
      detail = "center";
      stability = "stable";
    } else if (D0 || D > 0) {
      type = "node";
      const bool scalar = std::abs(J(0, 1)) <= tp && std::abs(J(1, 0)) <= tp &&
                          std::abs(J(0, 0) - J(1, 1)) <= tp;
      detail = D0 ? (scalar ? "proper node" : "degenerate node") : "improper node";
      stability = p < 0 ? "stable and attractive" : "unstable";
    } else {
      type = "spiral";
      detail = "spiral point";
      stability = p < 0 ? "stable and attractive" : "unstable";
    }
    const cd root = std::sqrt(cd(D, 0.0));
    CVec ev = {(p - root) / 2.0, (p + root) / 2.0};
    return dictOf({{"type", Value(type)},
                   {"detail", Value(detail)},
                   {"stability", Value(stability)},
                   {"p", Value(p)},
                   {"q", Value(q)},
                   {"delta", Value(D)},
                   {"eigenvalues", rowOf(ev)}});
  }
  OPS_END

  registerOdeSeriesLaplace(reg);
}

} // namespace ops
} // namespace nc
