#pragma once
// Ordinary differential equations (Kreyszig chapters 1-6), registered in the
// ops registry (support/ops_registry.h) by registerOde():
//   ode_qualitative.cpp     ch. 1-4  direction fields, Picard, Wronskian,
//                                    variation of parameters, resonance,
//                                    phase plane and critical points
//   ode_series_laplace.cpp  ch. 5-6  power series, Frobenius, Sturm-Liouville,
//                                    Laplace transforms, delta, Volterra
#include <vector>

#include "../support/ops_math.h"

namespace nc {
namespace ops {

void registerOdeSeriesLaplace(OpsRegistry &reg);

namespace ode {

// A system x' = F(x): one NC function returning all components, or a list
// of NC functions, one per component ["f1", "f2"] or [@f1, @f2].
class SystemFn {
public:
  bool read(const Value &v, CallContext &ctx);
  Vec eval(const Vec &x); // F(x); NaN components after a failure
  bool failed() const;
  std::string describe() const;

private:
  std::vector<Fn> parts_; // one function, or one per component
};

// Lists of functions given as an array of names or references.
bool readFunctionList(const Value &v, std::vector<Fn> &out);

} // namespace ode
} // namespace ops
} // namespace nc
