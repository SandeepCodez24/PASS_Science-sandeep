// ODEs, Kreyszig chapters 5-6: series solutions, Sturm-Liouville problems
// and Laplace transforms.
//   power_series_coeffs  frobenius_roots  sturm_liouville_solve      (ch. 5)
//   laplace_transform  inv_laplace_transform  dirac_delta_approx
//   solve_volterra_eq                                                 (ch. 6)
#include <algorithm>
#include <cmath>

#include "../../Scipy/special_functions/sf_core.h"
#include "ode_builtin.h"

namespace nc {
namespace ops {

namespace {

// Taylor coefficients of a coefficient function about x0, N of them: a
// number (a constant), an array of coefficients, or an NC function (its
// Taylor coefficients on the circle |x - x0| = 0.5, so it must accept
// complex x and be analytic there).
bool taylorOf(const Args &a, size_t i, double x0, size_t N, CallContext &ctx, Vec &out) {
  out.assign(N, 0.0);
  if (isNumber(a[i])) {
    out[0] = a[i].number;
    return true;
  }
  if (isFnArg(a[i])) {
    Fn f(a[i]);
    const CVec c = circleCoefficients(f, x0, 0.5, 0, static_cast<long long>(N) - 1,
                                      circleSamples(static_cast<long long>(N)));
    if (!fnOk(f, ctx))
      return false;
    for (size_t k = 0; k < N; k++)
      out[k] = std::abs(c[k].real()) < 1e-14 ? 0.0 : c[k].real();
    return true;
  }
  Vec v;
  if (!argVec(a, i, ctx, v))
    return false;
  for (size_t k = 0; k < N && k < v.size(); k++)
    out[k] = v[k];
  return true;
}

} // namespace

#define OPS_DOMAIN Domain::Ode

void registerOdeSeriesLaplace(OpsRegistry &reg) {

  // ---- ch. 5 ----
  OPS_FN("power_series_coeffs", 5, 6, "power_series_coeffs(p, q, r, x0, N[, ic])",
         "Power series solution", kCallsNC) {
    double x0;
    long long N;
    if (!argNum(a, 3, ctx, x0) || !argCount(a, 4, ctx, N, 2, 200))
      return Value();
    const size_t n = static_cast<size_t>(N);
    Vec p, q, r;
    if (!taylorOf(a, 0, x0, n, ctx, p) || !taylorOf(a, 1, x0, n, ctx, q) ||
        !taylorOf(a, 2, x0, n, ctx, r))
      return Value();
    // y'' + p y' + q y = r, y = sum c_m (x - x0)^m:
    // (m+2)(m+1) c_{m+2} = r_m - sum_{k=0..m} [ p_{m-k} (k+1) c_{k+1} + q_{m-k} c_k ]
    auto solve = [&](double c0, double c1, bool withR) {
      Vec c(n, 0.0);
      c[0] = c0;
      c[1] = c1;
      for (size_t m = 0; m + 2 < n; m++) {
        double s = withR ? r[m] : 0.0;
        for (size_t k = 0; k <= m; k++)
          s -= p[m - k] * static_cast<double>(k + 1) * c[k + 1] + q[m - k] * c[k];
        c[m + 2] = s / static_cast<double>((m + 2) * (m + 1));
      }
      return c;
    };
    const Vec y1 = solve(1, 0, false), y2 = solve(0, 1, false), yp = solve(0, 0, true);
    DictInit d = {{"y1", rowOf(y1)}, {"y2", rowOf(y2)}, {"yp", rowOf(yp)}};
    if (given(a, 5)) {
      Vec ic;
      if (!argVec(a, 5, ctx, ic) || ic.size() != 2) {
        if (ctx.ok())
          ctx.fail("ic must be [y(x0), y'(x0)]");
        return Value();
      }
      d.push_back({"y", rowOf(solve(ic[0], ic[1], true))});
    }
    return dictOf(d);
  }
  OPS_END

  OPS_FN("frobenius_roots", 2, 2, "frobenius_roots(b0, c0)", "Indicial equation roots", 0) {
    double b0, c0;
    if (!argNum(a, 0, ctx, b0) || !argNum(a, 1, ctx, c0))
      return Value();
    // x^2 y'' + x b(x) y' + c(x) y = 0:  r(r - 1) + b0 r + c0 = 0  (Kreyszig 5.3)
    const double B = b0 - 1.0, disc = B * B - 4.0 * c0;
    const double tol = 1e-12 * std::max(1.0, B * B + std::abs(c0));
    Value r1, r2;
    int kase;
    std::string text;
    if (std::abs(disc) <= tol) {
      r1 = r2 = Value(-B / 2.0);
      kase = 2;
      text = "double root: y1 = x^r u(x), y2 = y1 ln x + x^r (A1 x + A2 x^2 + ...)";
    } else if (disc < 0) {
      const double re = -B / 2.0, im = std::sqrt(-disc) / 2.0;
      r1 = Value::complexNumber(re, im);
      r2 = Value::complexNumber(re, -im);
      kase = 1;
      text = "complex conjugate roots: two Frobenius series y = x^r (a0 + a1 x + ...)";
    } else {
      const double s = std::sqrt(disc);
      const double hi = (-B + s) / 2.0, lo = (-B - s) / 2.0, diff = hi - lo;
      r1 = Value(hi);
      r2 = Value(lo);
      if (std::abs(diff - std::round(diff)) <= 1e-9 * std::max(1.0, diff)) {
        kase = 3;
        text = "roots differ by an integer: y1 = x^r1 (a0 + ...), y2 = k y1 ln x + x^r2 (A0 + "
               "A1 x + ...)";
      } else {
        kase = 1;
        text = "distinct roots not differing by an integer: two Frobenius series";
      }
    }
    return dictOf({{"r1", r1}, {"r2", r2}, {"case", Value(static_cast<double>(kase))},
                   {"description", Value(text)}});
  }
  OPS_END

  OPS_FN("sturm_liouville_solve", 6, 7, "sturm_liouville_solve(p, q, r, bc_a, bc_b, N[, M])",
         "Sturm-Liouville eigenpairs", kCallsNC) {
    // [p y']' + [q + lambda r] y = 0 on [a, b];  k1 y(a) + k2 y'(a) = 0,
    // l1 y(b) + l2 y'(b) = 0  (Kreyszig 5.7).  bc_a = [a, k1, k2], bc_b = [b, l1, l2].
    Fn P, Q, R;
    Vec ba, bb;
    long long N, M = 300;
    if (!argFn(a, 0, ctx, P) || !argFn(a, 1, ctx, Q) || !argFn(a, 2, ctx, R) ||
        !argVec(a, 3, ctx, ba) || !argVec(a, 4, ctx, bb) || !argCount(a, 5, ctx, N, 1, 100) ||
        (given(a, 6) && !argCount(a, 6, ctx, M, 20, 2000)))
      return Value();
    if (ba.size() != 3 || bb.size() != 3) {
      ctx.fail("bc_a must be [a, k1, k2] and bc_b must be [b, l1, l2]");
      return Value();
    }
    const double A = ba[0], B = bb[0];
    if (!(B > A)) {
      ctx.fail("the interval needs b > a");
      return Value();
    }
    if ((ba[1] == 0 && ba[2] == 0) || (bb[1] == 0 && bb[2] == 0)) {
      ctx.fail("each boundary condition needs k1, k2 (or l1, l2) not both 0");
      return Value();
    }
    if (M < 4 * N) {
      ctx.fail("M must be at least 4 * N grid intervals to resolve N modes");
      return Value();
    }
    struct Disc {
      Vec x, w, rv;  // nodes kept, weights, r at nodes
      Vec d, e;      // symmetric tridiagonal C = W^-1/2 A W^-1/2
      size_t first;  // index of the first kept node on the full grid
    };
    // Finite-volume discretisation with M intervals (symmetric, any Robin conditions).
    auto build = [&](size_t m, Disc &D) -> bool {
      const double h = (B - A) / static_cast<double>(m);
      Vec x(m + 1), pv(m + 1), qv(m + 1), rv(m + 1), ph(m);
      for (size_t i = 0; i <= m; i++) {
        x[i] = A + h * static_cast<double>(i);
        pv[i] = P.r(x[i]);
        qv[i] = Q.r(x[i]);
        rv[i] = R.r(x[i]);
      }
      for (size_t i = 0; i < m; i++)
        ph[i] = P.r(x[i] + 0.5 * h);
      if (P.failed() || Q.failed() || R.failed())
        return false;
      for (size_t i = 0; i <= m; i++)
        if (!(pv[i] > 0.0) || !(rv[i] > 0.0)) {
          ctx.fail("a regular Sturm-Liouville problem needs p > 0 and r > 0 on [a, b]");
          return false;
        }
      const bool dirA = ba[2] == 0.0, dirB = bb[2] == 0.0;
      const size_t lo = dirA ? 1 : 0, hi = dirB ? m - 1 : m;
      const size_t n = hi - lo + 1;
      Vec Ad(n), Ae(n > 0 ? n - 1 : 0), W(n);
      for (size_t k = 0; k < n; k++) {
        const size_t i = lo + k;
        double diag = 0.0, wt = h;
        if (i > 0)
          diag += ph[i - 1] / h;
        if (i < m)
          diag += ph[i] / h;
        if (i == 0) { // Robin at a: y'(a) = -(k1/k2) y(a)
          wt = 0.5 * h;
          diag += -pv[0] * ba[1] / ba[2];
        }
        if (i == m) { // Robin at b: y'(b) = -(l1/l2) y(b)
          wt = 0.5 * h;
          diag += pv[m] * bb[1] / bb[2];
        }
        diag -= qv[i] * wt;
        Ad[k] = diag;
        W[k] = wt * rv[i];
        if (k + 1 < n)
          Ae[k] = -ph[i] / h;
      }
      D.d.resize(n);
      D.e.resize(n > 0 ? n - 1 : 0);
      for (size_t k = 0; k < n; k++)
        D.d[k] = Ad[k] / W[k];
      for (size_t k = 0; k + 1 < n; k++)
        D.e[k] = Ae[k] / std::sqrt(W[k] * W[k + 1]);
      D.x = x;
      D.w = W;
      D.rv = rv;
      D.first = lo;
      return true;
    };
    Disc fine, coarse;
    const size_t m = static_cast<size_t>(M);
    if (!build(m, fine) || !build(m / 2, coarse)) {
      if (ctx.ok())
        fnOk(P, ctx) && fnOk(Q, ctx) && fnOk(R, ctx);
      return Value();
    }
    if (fine.d.size() < static_cast<size_t>(N)) {
      ctx.fail("the grid is too small for N modes");
      return Value();
    }
    Vec lamF, lamC;
    std::vector<Vec> vecs;
    scipy::sf::tridiag_eig(fine.d, fine.e, lamF, &vecs);
    scipy::sf::tridiag_eig(coarse.d, coarse.e, lamC, nullptr);
    // Richardson: the discrete eigenvalues are lambda + c h^2 + ...
    Vec lam(static_cast<size_t>(N));
    for (size_t k = 0; k < lam.size(); k++)
      lam[k] = k < lamC.size() ? (4.0 * lamF[k] - lamC[k]) / 3.0 : lamF[k];
    // Eigenfunctions on the full grid: y = W^-1/2 z, normalised so that
    // integral r y^2 dx = 1 and y starts upward.
    Mat Y(static_cast<size_t>(N), m + 1);
    for (size_t k = 0; k < static_cast<size_t>(N); k++) {
      double norm = 0.0;
      for (size_t j = 0; j < fine.d.size(); j++) {
        const double y = vecs[j][k] / std::sqrt(fine.w[j]);
        Y(k, fine.first + j) = y;
        norm += fine.w[j] * y * y;
      }
      norm = std::sqrt(norm);
      double sgn = 0.0;
      for (size_t j = 0; j <= m && sgn == 0.0; j++)
        if (std::abs(Y(k, j)) > 1e-8)
          sgn = Y(k, j) > 0 ? 1.0 : -1.0;
      for (size_t j = 0; j <= m; j++)
        Y(k, j) *= (sgn < 0 ? -1.0 : 1.0) / norm;
    }
    return dictOf({{"eigenvalues", rowOf(lam)}, {"x", rowOf(fine.x)}, {"eigenfunctions", matOf(Y)}});
  }
  OPS_END

  // ---- ch. 6 ----
  OPS_FN("laplace_transform", 2, 2, "laplace_transform(@f, s)", "Laplace transform",
         kCallsNC | kComplexArgs) {
    Fn f;
    CVec s;
    if (!argCallable(a, 0, ctx, f) || !argCVec(a, 1, ctx, s))
      return Value();
    // F(s) = integral from 0 to inf of e^(-s t) f(t) dt; all s at once (one f call per node).
    const size_t m = s.size();
    QuadResult q = quadVec(
        [&](double t, double *out) {
          const cd ft = f.c(t);
          if (f.failed())
            return false;
          for (size_t k = 0; k < m; k++) {
            // where e^(-st) has underflowed the integrand is 0, even if f(t) overflowed
            const cd e = std::exp(-s[k] * t);
            const cd v = e == cd(0.0) ? cd(0.0) : e * ft;
            out[2 * k] = v.real();
            out[2 * k + 1] = v.imag();
          }
          return true;
        },
        2 * m, 0.0, kInf, 1e-12, 1e-10, 4000);
    if (!fnOk(f, ctx))
      return Value();
    if (!q.converged) {
      ctx.fail("the integral did not converge - e^(-s t) f(t) must decay (try a larger Re(s))");
      return Value();
    }
    CVec F(m);
    for (size_t k = 0; k < m; k++)
      F[k] = cd(q.value[2 * k], q.value[2 * k + 1]);
    return F.size() == 1 ? numOf(F[0]) : vecLike(F, a[1]);
  }
  OPS_END

  OPS_FN("inv_laplace_transform", 2, 4,
         "inv_laplace_transform(@F, t[, method=\"talbot\"|\"stehfest\"][, M])",
         "Inverse Laplace transform", kCallsNC) {
    Fn F;
    Vec t;
    if (!argCallable(a, 0, ctx, F) || !argVec(a, 1, ctx, t))
      return Value();
    std::string method = "talbot";
    if (given(a, 2) && !argText(a, 2, ctx, method))
      return Value();
    method = lowerText(method);
    if (method != "talbot" && method != "stehfest") {
      ctx.fail("method must be \"talbot\" (F takes complex s) or \"stehfest\" (real s only)");
      return Value();
    }
    long long M = method == "talbot" ? 24 : 14;
    if (given(a, 3) && !argCount(a, 3, ctx, M, 4, 64))
      return Value();
    if (method == "stehfest" && M % 2) {
      ctx.fail("the Stehfest method needs an even M");
      return Value();
    }
    for (double v : t)
      if (!(v > 0.0)) {
        ctx.fail("every t must be positive");
        return Value();
      }
    Vec out(t.size());
    if (method == "talbot") {
      // Fixed Talbot contour (Abate and Valko, 2004).
      for (size_t i = 0; i < t.size(); i++) {
        const double r = 2.0 * static_cast<double>(M) / (5.0 * t[i]);
        double sum = 0.5 * (F.c(cd(r, 0.0)) * std::exp(r * t[i])).real();
        for (long long k = 1; k < M; k++) {
          const double th = static_cast<double>(k) * kPi / static_cast<double>(M);
          const double cot = 1.0 / std::tan(th);
          const cd sk = r * th * cd(cot, 1.0);
          const double sig = th + (th * cot - 1.0) * cot;
          sum += (std::exp(t[i] * sk) * F.c(sk) * cd(1.0, sig)).real();
        }
        out[i] = r / static_cast<double>(M) * sum;
      }
    } else {
      const Vec V = stehfestWeights(static_cast<int>(M));
      for (size_t i = 0; i < t.size(); i++) {
        const double ln2t = std::log(2.0) / t[i];
        double sum = 0.0;
        for (long long k = 1; k <= M; k++)
          sum += V[static_cast<size_t>(k)] * F.r(static_cast<double>(k) * ln2t);
        out[i] = ln2t * sum;
      }
    }
    if (!fnOk(F, ctx))
      return Value();
    return out.size() == 1 ? Value(out[0]) : vecLike(out, a[1]);
  }
  OPS_END

  OPS_FN("dirac_delta_approx", 3, 4, "dirac_delta_approx(t, t0, width[, shape=\"rect\"|\"gauss\"])",
         "Impulse approximation", 0) {
    Vec t;
    double t0, k;
    if (!argVec(a, 0, ctx, t) || !argNum(a, 1, ctx, t0) || !argPositive(a, 2, ctx, k))
      return Value();
    std::string shape = "rect";
    if (given(a, 3) && !argText(a, 3, ctx, shape))
      return Value();
    shape = lowerText(shape);
    Vec d(t.size());
    if (shape == "rect") { // f_k = 1/k on [t0, t0 + k), area 1  (Kreyszig 6.4)
      for (size_t i = 0; i < t.size(); i++)
        d[i] = (t[i] >= t0 && t[i] < t0 + k) ? 1.0 / k : 0.0;
    } else if (shape == "gauss") { // normal density, standard deviation k
      for (size_t i = 0; i < t.size(); i++)
        d[i] = std::exp(-0.5 * std::pow((t[i] - t0) / k, 2)) / (k * std::sqrt(2.0 * kPi));
    } else {
      ctx.fail("shape must be \"rect\" or \"gauss\"");
      return Value();
    }
    return vecLike(d, a[0]);
  }
  OPS_END

  OPS_FN("solve_volterra_eq", 3, 3, "solve_volterra_eq(k, f, t)", "Volterra integral equation",
         kCallsNC) {
    // y(t) = f(t) + integral from t0 to t of k(t, tau) y(tau) dtau  (second kind),
    // trapezoid rule on the t grid. k(t, tau), or k(t - tau) when k takes one input.
    Fn K;
    Vec t, f;
    if (!argCallable(a, 0, ctx, K) || !argVec(a, 2, ctx, t, 2))
      return Value();
    for (size_t i = 1; i < t.size(); i++)
      if (!(t[i] > t[i - 1])) {
        ctx.fail("t must increase");
        return Value();
      }
    if (isFnArg(a[1]) || isNumber(a[1])) {
      Fn g(a[1]);
      f.resize(t.size());
      for (size_t i = 0; i < t.size(); i++)
        f[i] = g.r(t[i]);
      if (!fnOk(g, ctx))
        return Value();
    } else if (!argVec(a, 1, ctx, f) || f.size() != t.size()) {
      if (ctx.ok())
        ctx.fail("f must be a function or have one value per t");
      return Value();
    }
    const bool convolution = K.arity() == 1;
    // A convolution kernel on a uniform grid depends only on i - j: cache it.
    bool uniform = true;
    const double h0 = t[1] - t[0];
    for (size_t i = 2; i < t.size() && uniform; i++)
      uniform = std::abs((t[i] - t[i - 1]) - h0) <= 1e-9 * std::abs(h0);
    Vec kc;
    if (convolution && uniform) {
      kc.resize(t.size());
      for (size_t d = 0; d < t.size(); d++)
        kc[d] = K.r(static_cast<double>(d) * h0);
    }
    auto kern = [&](size_t i, size_t j) {
      if (!kc.empty())
        return kc[i - j];
      return convolution ? K.r(t[i] - t[j]) : K.r2(t[i], t[j]);
    };
    Vec y(t.size());
    y[0] = f[0];
    for (size_t i = 1; i < t.size(); i++) {
      double s = f[i];
      for (size_t j = 0; j < i; j++) {
        const double w = 0.5 * ((j > 0 ? t[j] - t[j - 1] : 0.0) + (t[j + 1] - t[j]));
        s += w * kern(i, j) * y[j];
      }
      const double wi = 0.5 * (t[i] - t[i - 1]);
      const double den = 1.0 - wi * kern(i, i);
      if (K.failed())
        break;
      if (den == 0.0) {
        ctx.fail("the step is too large for this kernel (1 - h k(t, t) / 2 = 0)");
        return Value();
      }
      y[i] = s / den;
    }
    if (!fnOk(K, ctx))
      return Value();
    return vecLike(y, a[2]);
  }
  OPS_END
}

} // namespace ops
} // namespace nc
