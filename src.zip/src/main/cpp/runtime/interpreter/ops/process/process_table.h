// Loaded tables (NcTable, NcParquet, NcFeather, ... - any object with
// `cols` and `data`) for the data processing functions and the Process Data
// window (docs/Process_Window_CPP.md P6, user decision 2026-11-17: the
// steps work column by column and the result is a table again, its column
// names, types and other fields kept).
#ifndef NC_OPS_PROCESS_TABLE_H
#define NC_OPS_PROCESS_TABLE_H

#include <string>
#include <vector>

#include "../../core/value.h"

namespace nc {
namespace ops {
namespace process {

// An object with `cols` and `data` (what load_csv & co. give).
bool isTableObject(const Value &v);

// The columns of a table object: names and one column vector each (a
// numeric array, or a cell array for text / mixed / typed columns).
bool tableColumns(const Value &table, std::vector<std::string> &names, std::vector<Value> &columns,
                  std::string &err);

// A table object like `original` (same class, its other fields kept - file,
// meta, ...) holding `columns` (each one vector of the same length, or an
// n x k matrix that becomes k columns <name>_0 .. <name>_k-1).
bool tableFromColumns(const Value &original, const std::vector<std::string> &names,
                      const std::vector<Value> &columns, Value &out, std::string &err);

// The table's rows `keep` (in that order).
bool tableTakeRows(const Value &table, const std::vector<size_t> &keep, Value &out, std::string &err);

// The number of rows of a table object.
size_t tableRowCount(const Value &table);

} // namespace process
} // namespace ops
} // namespace nc

#endif // NC_OPS_PROCESS_TABLE_H
