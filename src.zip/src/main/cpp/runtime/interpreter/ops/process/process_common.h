// Data processing built-ins (2026-11-17, docs/Process_Window_CPP.md P5) -
// the functions the Process Data window's operations write, usable from any
// script. Shared helpers of process_text.cpp, process_stats.cpp and
// process_encode.cpp.
//
// Values are handled as NumPy-style Grids (Numpy/numpy_nd.h): the shape as a
// matrix and the cells in row-major order, every cell a whole Value - so
// text, bools, integers and time values keep their type. Numeric results are
// packed float64.
//
// Missing values (core/value.h, docs/Import_Window.md §11): only a reader's
// tagged NaN is missing, unless a function is given the "nan" option, which
// also counts a plain NaN and an empty text "" (user decision 2026-11-17 -
// the Import rule stays).
#ifndef NC_OPS_PROCESS_COMMON_H
#define NC_OPS_PROCESS_COMMON_H

#include <cmath>
#include <string>
#include <vector>

#include "../../Numpy/numpy_nd.h"
#include "../support/ops_registry.h"

namespace nc {
namespace ops {
namespace process {

using numpy::ndx::Grid;
using scipy::CallContext;

// ---- cells ---------------------------------------------------------------

// A plain number (also bool / integer / narrow float), not text, a
// container, a time value or complex.
inline bool isNumberCell(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef &&
         !v.isComplex && !v.isTime();
}

// Missing: the reader's tagged NaN; with `nanToo` also a plain NaN and "".
inline bool isMissingCell(const Value &v, bool nanToo) {
  if (v.isText)
    return nanToo && v.text().empty();
  if (!isNumberCell(v))
    return false;
  if (isMissingNumber(v.number))
    return true;
  return nanToo && std::isnan(v.number);
}

// The optional "nan" word of ismissing / fillmissing / rmmissing.
// False (error reported) for any other value.
bool nanOption(const Value &v, CallContext &ctx);

// A Grid of any value a matrix may hold; fails for a dict / object.
bool gridArg(const Args &a, size_t i, CallContext &ctx, Grid &out);

// A 2-D value seen as rows x cols (a scalar is 1x1, an array 1xn).
// False for N-D.
inline bool twoD(const Grid &g) { return g.shape.size() == 2; }

// A vector: an array, a 1xn row or an nx1 column (a single value too).
inline bool isVector(const Grid &g) {
  return g.shape.size() == 2 && (g.shape[0] <= 1 || g.shape[1] <= 1);
}

// A text argument (lowercased), or `fallback` when the argument is missing.
bool textArg(const Args &a, size_t i, CallContext &ctx, const std::string &what,
             std::string &out);
bool optTextArg(const Args &a, size_t i, CallContext &ctx, const std::string &what,
                const std::string &fallback, std::string &out);
bool numberArg(const Args &a, size_t i, CallContext &ctx, const std::string &what, double &out);
bool wholeArg(const Args &a, size_t i, CallContext &ctx, const std::string &what, long long &out);

// "row 3, column 2" (from 0) of row-major cell k of a 2-D grid, or
// "element k" for anything else.
std::string where(const Grid &g, size_t k);

// The shortest text that reads back as exactly this number ("2.5", "0.1",
// "1e+21", "nan", "inf", "-inf").
std::string shortestText(double x);
// A cell as text: its text, "true" / "false", an integer's digits, a
// number's shortest text, a time value's display text; "" for a missing
// number (with `missingAsEmpty`).
std::string cellText(const Value &v, bool missingAsEmpty);

// The same kind of container as `like` (array, matrix) holding `cells`
// (row-major) in `shape`: a 1-D array input gives a 1-D array back.
Value rebuild(const Value &like, const nd::Shape &shape, const std::vector<Value> &cells);
// A packed float64 result of `shape` from row-major `vals`, the container
// kind of `like` (array or matrix).
Value packedLike(const Value &like, const nd::Shape &shape, const std::vector<double> &vals);

// Linear-interpolation percentile (NumPy's default, NC's percentile()) of
// sorted values; p in 0..100. NaN for none.
double percentileSorted(const std::vector<double> &sorted, double p);

// The series a statistic is taken over: for a vector the whole of it, for a
// 2-D matrix each column. Row-major cell indices of each series.
std::vector<std::vector<size_t>> columnSeries(const Grid &g);
// Each row (axis 1) / each column (axis 0) / all cells (axis -1).
std::vector<std::vector<size_t>> axisSeries(const Grid &g, int axis);

// The registration parts.
void registerProcessText(OpsRegistry &reg);     // process_text.cpp
void registerProcessStats(OpsRegistry &reg);    // process_stats.cpp
void registerProcessEncode(OpsRegistry &reg);   // process_encode.cpp

// One spec, with an optional `accepts` (a name shared with an older
// function: only the calls this one is for come here).
void addSpec(OpsRegistry &reg, const std::string &name, int minArgs, int maxArgs,
             const std::string &usage, const std::string &summary, unsigned flags, Impl impl,
             std::function<bool(const Args &)> accepts = {});

} // namespace process
} // namespace ops
} // namespace nc

#endif // NC_OPS_PROCESS_COMMON_H
