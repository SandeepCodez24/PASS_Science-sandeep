// Data processing built-ins, part 3 (docs/Process_Window_CPP.md P5.10):
// categories -> numbers.
//
// Input: one column of categories - a text array or a vector of numbers (an
// array, a 1xn row or an nx1 column); n = its length, one output row per
// element. Categories are ordered by value: numbers ascending, then texts by
// their bytes. A missing entry (the reader's tagged NaN, a plain nan or "")
// is no category: its row is all 0 (onehot, binary, hash) or nan (the
// others). Output float64.
//
// Choices made here (documented in docs/Process_Window_CPP.md):
//   hash_encode adds +1 (never -1) - the column is MurmurHash3 x86-32 (seed 0)
//   of the category's UTF-8 text mod n; a number is hashed as its shortest
//   text ("2.5").
//   binary_encode uses max(1, ceil(log2(k))) columns, most significant first.
#include "process_common.h"

#include <algorithm>
#include <cstring>
#include <map>
#include <numeric>

namespace nc {
namespace ops {
namespace process {

namespace {

struct Column {
  nd::Shape shape;            // of the input (output of a one-number encoder)
  std::vector<Value> cells;   // in order
  std::vector<int> cat;       // category index per row (sorted order), -1 = missing
  std::vector<Value> cats;    // the categories, sorted
};

bool columnOf(const Args &a, size_t i, CallContext &ctx, Column &out) {
  Grid g;
  if (!gridArg(a, i, ctx, g))
    return false;
  if (!isVector(g)) {
    ctx.fail("takes one column of categories (a vector); this value is " + nd::shapeText(g.shape) +
             " - encode one column at a time");
    return false;
  }
  for (size_t k = 0; k < g.cells.size(); k++) {
    const Value &c = g.cells[k];
    if (!c.isText && !isNumberCell(c)) {
      ctx.fail(where(g, k) + " is neither text nor a number");
      return false;
    }
  }
  out.shape = g.shape;
  out.cells = std::move(g.cells);
  std::vector<size_t> order;
  for (size_t k = 0; k < out.cells.size(); k++)
    if (!isMissingCell(out.cells[k], true))
      order.push_back(k);
  std::stable_sort(order.begin(), order.end(), [&](size_t x, size_t y) {
    return numpy::ndx::compareCells(out.cells[x], out.cells[y]) < 0;
  });
  out.cat.assign(out.cells.size(), -1);
  for (size_t i2 = 0; i2 < order.size(); i2++) {
    if (i2 == 0 || numpy::ndx::compareCells(out.cells[order[i2 - 1]], out.cells[order[i2]]) != 0)
      out.cats.push_back(out.cells[order[i2]]);
    out.cat[order[i2]] = static_cast<int>(out.cats.size()) - 1;
  }
  return true;
}

// An n x k matrix from row-major values.
Value table(size_t n, size_t k, const std::vector<double> &vals) {
  if (n == 0 || k == 0)
    return Value(std::vector<std::vector<Value>>{});
  std::vector<double> colMajor(n * k);
  for (size_t r = 0; r < n; r++)
    for (size_t c = 0; c < k; c++)
      colMajor[c * n + r] = vals[r * k + c];
  return Value::packedMatrix(colMajor.data(), n, k);
}

// One number per row, in the input's own shape (a row stays a row).
Value perRow(const Column &col, const std::vector<double> &vals) {
  return packedLike(Value(std::vector<std::vector<Value>>{}), col.shape, vals);
}

bool targetOf(const Args &a, size_t i, const Column &col, CallContext &ctx, std::vector<double> &t) {
  Grid g;
  if (!gridArg(a, i, ctx, g))
    return false;
  if (!isVector(g) || g.cells.size() != col.cells.size()) {
    ctx.fail("the target must be a vector with one value per row (" + std::to_string(col.cells.size()) +
             "); it is " + nd::shapeText(g.shape));
    return false;
  }
  t.resize(g.cells.size());
  for (size_t k = 0; k < g.cells.size(); k++) {
    if (!isNumberCell(g.cells[k])) {
      ctx.fail("target " + where(g, k) + " is not a number");
      return false;
    }
    t[k] = g.cells[k].number;
  }
  return true;
}

double nanValue() { return std::nan(""); }

// ---- MurmurHash3 x86 32-bit ------------------------------------------------

uint32_t murmur3(const std::string &s, uint32_t seed) {
  const uint8_t *data = reinterpret_cast<const uint8_t *>(s.data());
  const size_t len = s.size();
  const size_t nblocks = len / 4;
  uint32_t h = seed;
  const uint32_t c1 = 0xcc9e2d51, c2 = 0x1b873593;
  auto rotl = [](uint32_t x, int r) { return (x << r) | (x >> (32 - r)); };
  for (size_t i = 0; i < nblocks; i++) {
    // Read little-endian byte by byte: the same hash on every CPU.
    uint32_t k = static_cast<uint32_t>(data[i * 4]) | (static_cast<uint32_t>(data[i * 4 + 1]) << 8) |
        (static_cast<uint32_t>(data[i * 4 + 2]) << 16) | (static_cast<uint32_t>(data[i * 4 + 3]) << 24);
    k *= c1;
    k = rotl(k, 15);
    k *= c2;
    h ^= k;
    h = rotl(h, 13);
    h = h * 5 + 0xe6546b64;
  }
  const uint8_t *tail = data + nblocks * 4;
  uint32_t k1 = 0;
  switch (len & 3) {
  case 3:
    k1 ^= static_cast<uint32_t>(tail[2]) << 16;
    [[fallthrough]];
  case 2:
    k1 ^= static_cast<uint32_t>(tail[1]) << 8;
    [[fallthrough]];
  case 1:
    k1 ^= tail[0];
    k1 *= c1;
    k1 = rotl(k1, 15);
    k1 *= c2;
    h ^= k1;
  }
  h ^= static_cast<uint32_t>(len);
  h ^= h >> 16;
  h *= 0x85ebca6b;
  h ^= h >> 13;
  h *= 0xc2b2ae35;
  h ^= h >> 16;
  return h;
}

// ---- the encoders -------------------------------------------------------------

Value onehotImpl(const Args &a, CallContext &ctx) {
  bool dropFirst = false;
  if (a.size() > 1) {
    std::string opt;
    if (!textArg(a, 1, ctx, "the option", opt))
      return Value(0.0);
    if (opt != "drop_first") {
      ctx.fail("the option is \"drop_first\" (dummy encoding)");
      return Value(0.0);
    }
    dropFirst = true;
  }
  Column col;
  if (!columnOf(a, 0, ctx, col))
    return Value(0.0);
  const size_t n = col.cells.size(), k = col.cats.size(), skip = dropFirst ? 1 : 0;
  const size_t w = k > skip ? k - skip : 0;
  std::vector<double> v(n * w, 0.0);
  for (size_t r = 0; r < n; r++)
    if (col.cat[r] >= static_cast<int>(skip))
      v[r * w + static_cast<size_t>(col.cat[r]) - skip] = 1;
  return table(n, w, v);
}

Value binaryImpl(const Args &a, CallContext &ctx) {
  Column col;
  if (!columnOf(a, 0, ctx, col))
    return Value(0.0);
  const size_t n = col.cells.size(), k = col.cats.size();
  size_t bits = 1;
  while ((static_cast<size_t>(1) << bits) < k)
    bits++;
  std::vector<double> v(n * bits, 0.0);
  for (size_t r = 0; r < n; r++) {
    if (col.cat[r] < 0)
      continue;
    const size_t idx = static_cast<size_t>(col.cat[r]);
    for (size_t b = 0; b < bits; b++)
      v[r * bits + b] = static_cast<double>((idx >> (bits - 1 - b)) & 1u);
  }
  return table(n, bits, v);
}

Value hashImpl(const Args &a, CallContext &ctx) {
  long long w = 0;
  if (!wholeArg(a, 1, ctx, "the number of columns", w))
    return Value(0.0);
  if (w < 1 || w > 1000000) {
    ctx.fail("the number of columns must be 1 or more");
    return Value(0.0);
  }
  Column col;
  if (!columnOf(a, 0, ctx, col))
    return Value(0.0);
  const size_t n = col.cells.size(), k = static_cast<size_t>(w);
  std::vector<double> v(n * k, 0.0);
  for (size_t r = 0; r < n; r++) {
    if (col.cat[r] < 0)
      continue;
    const uint32_t h = murmur3(cellText(col.cells[r], false), 0);
    v[r * k + h % k] += 1;
  }
  return table(n, k, v);
}

Value countImpl(const Args &a, CallContext &ctx) {
  std::string as;
  if (!optTextArg(a, 1, ctx, "\"count\" or \"frequency\"", "count", as))
    return Value(0.0);
  if (as != "count" && as != "frequency") {
    ctx.fail("the second value is \"count\" or \"frequency\"");
    return Value(0.0);
  }
  Column col;
  if (!columnOf(a, 0, ctx, col))
    return Value(0.0);
  std::vector<double> counts(col.cats.size(), 0);
  for (int c : col.cat)
    if (c >= 0)
      counts[static_cast<size_t>(c)] += 1;
  const double n = static_cast<double>(col.cells.size());
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++)
    v[r] = col.cat[r] < 0 ? nanValue()
                          : (as == "count" ? counts[static_cast<size_t>(col.cat[r])]
                                           : counts[static_cast<size_t>(col.cat[r])] / n);
  return perRow(col, v);
}

Value labelImpl(const Args &a, CallContext &ctx) {
  Column col;
  if (!columnOf(a, 0, ctx, col))
    return Value(0.0);
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++)
    v[r] = col.cat[r] < 0 ? nanValue() : static_cast<double>(col.cat[r]);
  return perRow(col, v);
}

Value ordinalImpl(const Args &a, CallContext &ctx) {
  Column col;
  if (!columnOf(a, 0, ctx, col))
    return Value(0.0);
  Grid order;
  if (!gridArg(a, 1, ctx, order))
    return Value(0.0);
  for (size_t i = 0; i < order.cells.size(); i++)
    for (size_t j = 0; j < i; j++)
      if (numpy::ndx::compareCells(order.cells[i], order.cells[j]) == 0) {
        ctx.fail("\"" + cellText(order.cells[i], false) + "\" is in the order twice");
        return Value(0.0);
      }
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++) {
    if (col.cat[r] < 0) {
      v[r] = nanValue();
      continue;
    }
    bool found = false;
    for (size_t i = 0; i < order.cells.size() && !found; i++)
      if (numpy::ndx::compareCells(col.cells[r], order.cells[i]) == 0) {
        v[r] = static_cast<double>(i);
        found = true;
      }
    if (!found) {
      ctx.fail("\"" + cellText(col.cells[r], false) + "\" (row " + std::to_string(r) +
               ") is not in the order given");
      return Value(0.0);
    }
  }
  return perRow(col, v);
}

// Per category: rows with a target, their sum; and over all such rows.
struct TargetStats {
  std::vector<double> n, sum;
  double total = 0, count = 0;
};

TargetStats statsOf(const Column &col, const std::vector<double> &t) {
  TargetStats s;
  s.n.assign(col.cats.size(), 0);
  s.sum.assign(col.cats.size(), 0);
  for (size_t r = 0; r < t.size(); r++) {
    if (std::isnan(t[r]))
      continue; // a row without a target says nothing
    s.total += t[r];
    s.count += 1;
    if (col.cat[r] >= 0) {
      s.n[static_cast<size_t>(col.cat[r])] += 1;
      s.sum[static_cast<size_t>(col.cat[r])] += t[r];
    }
  }
  return s;
}

Value targetImpl(const Args &a, CallContext &ctx) {
  Column col;
  std::vector<double> t;
  if (!columnOf(a, 0, ctx, col) || !targetOf(a, 1, col, ctx, t))
    return Value(0.0);
  double m = 10;
  if (a.size() > 2 && !numberArg(a, 2, ctx, "the smoothing", m))
    return Value(0.0);
  if (!(m >= 0)) {
    ctx.fail("the smoothing must be 0 or more");
    return Value(0.0);
  }
  const TargetStats s = statsOf(col, t);
  const double mean = s.count > 0 ? s.total / s.count : nanValue();
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++) {
    if (col.cat[r] < 0) {
      v[r] = nanValue();
      continue;
    }
    const size_t c = static_cast<size_t>(col.cat[r]);
    const double nc_ = s.n[c];
    v[r] = nc_ + m > 0 ? (s.sum[c] + m * mean) / (nc_ + m) : mean;
  }
  return perRow(col, v);
}

Value looImpl(const Args &a, CallContext &ctx) {
  Column col;
  std::vector<double> t;
  if (!columnOf(a, 0, ctx, col) || !targetOf(a, 1, col, ctx, t))
    return Value(0.0);
  const TargetStats s = statsOf(col, t);
  const double mean = s.count > 0 ? s.total / s.count : nanValue();
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++) {
    if (col.cat[r] < 0) {
      v[r] = nanValue();
      continue;
    }
    const size_t c = static_cast<size_t>(col.cat[r]);
    double n = s.n[c], sum = s.sum[c];
    if (!std::isnan(t[r])) { // leave this row's own target out
      n -= 1;
      sum -= t[r];
    }
    v[r] = n > 0 ? sum / n : mean;
  }
  return perRow(col, v);
}

Value woeImpl(const Args &a, CallContext &ctx) {
  Column col;
  std::vector<double> t;
  if (!columnOf(a, 0, ctx, col) || !targetOf(a, 1, col, ctx, t))
    return Value(0.0);
  for (size_t r = 0; r < t.size(); r++)
    if (!std::isnan(t[r]) && t[r] != 0 && t[r] != 1) {
      ctx.fail("the target must be 0 / 1 - row " + std::to_string(r) + " is " + shortestText(t[r]));
      return Value(0.0);
    }
  std::vector<double> pos(col.cats.size(), 0), neg(col.cats.size(), 0);
  double P = 0, N = 0;
  for (size_t r = 0; r < t.size(); r++) {
    if (std::isnan(t[r]))
      continue;
    (t[r] == 1 ? P : N) += 1;
    if (col.cat[r] >= 0)
      (t[r] == 1 ? pos : neg)[static_cast<size_t>(col.cat[r])] += 1;
  }
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++) {
    if (col.cat[r] < 0) {
      v[r] = nanValue();
      continue;
    }
    const size_t c = static_cast<size_t>(col.cat[r]);
    v[r] = std::log(((pos[c] + 0.5) / (P + 0.5)) / ((neg[c] + 0.5) / (N + 0.5)));
  }
  return perRow(col, v);
}

Value catboostImpl(const Args &a, CallContext &ctx) {
  Column col;
  std::vector<double> t;
  if (!columnOf(a, 0, ctx, col) || !targetOf(a, 1, col, ctx, t))
    return Value(0.0);
  const TargetStats s = statsOf(col, t);
  double prior = s.count > 0 ? s.total / s.count : 0;
  if (a.size() > 2 && !numberArg(a, 2, ctx, "the prior", prior))
    return Value(0.0);
  std::vector<double> sum(col.cats.size(), 0), cnt(col.cats.size(), 0);
  std::vector<double> v(col.cells.size());
  for (size_t r = 0; r < v.size(); r++) { // row order: only the rows before count
    if (col.cat[r] < 0) {
      v[r] = nanValue();
      continue;
    }
    const size_t c = static_cast<size_t>(col.cat[r]);
    v[r] = (sum[c] + prior) / (cnt[c] + 1);
    if (!std::isnan(t[r])) {
      sum[c] += t[r];
      cnt[c] += 1;
    }
  }
  return perRow(col, v);
}

} // namespace

void registerProcessEncode(OpsRegistry &reg) {
  addSpec(reg, "onehot", 1, 2, "onehot(X[, \"drop_first\"])", "one column per category", 0,
          onehotImpl);
  addSpec(reg, "binary_encode", 1, 1, "binary_encode(X)", "category number in binary columns", 0,
          binaryImpl);
  addSpec(reg, "hash_encode", 2, 2, "hash_encode(X, n)", "categories hashed into n columns", 0,
          hashImpl);
  addSpec(reg, "count_encode", 1, 2, "count_encode(X[, \"count\" or \"frequency\"])",
          "how often each category occurs", 0, countImpl);
  addSpec(reg, "label_encode", 1, 1, "label_encode(X)", "categories numbered 0 .. k-1", 0, labelImpl);
  addSpec(reg, "ordinal_encode", 2, 2, "ordinal_encode(X, order)", "categories numbered by an order",
          0, ordinalImpl);
  addSpec(reg, "target_encode", 2, 3, "target_encode(X, target[, m])",
          "smoothed mean target per category", 0, targetImpl);
  addSpec(reg, "loo_encode", 2, 2, "loo_encode(X, target)", "leave-one-out mean target", 0, looImpl);
  addSpec(reg, "woe_encode", 2, 2, "woe_encode(X, target)", "weight of evidence per category", 0,
          woeImpl);
  addSpec(reg, "catboost_encode", 2, 3, "catboost_encode(X, target[, prior])",
          "ordered target statistic", 0, catboostImpl);
}

} // namespace process
} // namespace ops
} // namespace nc
