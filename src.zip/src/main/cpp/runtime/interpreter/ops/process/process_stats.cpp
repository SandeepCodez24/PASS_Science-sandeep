// Data processing built-ins, part 2 (docs/Process_Window_CPP.md P5.4 - P5.8,
// P7.1): missing entries, outliers, normalize, sortrows, squeeze /
// expand_dims, tril / triu, and the axis= forms of mean / median / var / sd
// / sum / sort.
//
// ismissing(X) and fillmissing(X, value) (Numpy/importing_data/io_common.cpp)
// keep their meaning: only a reader's tagged NaN is missing. The forms here
// are reached only for the new calls (OpsSpec::accepts):
//   ismissing(X, "nan")              plain nan and "" count too
//   fillmissing(X, value, "nan")     the same, filled with value
//   fillmissing(X, method[, "nan"])  mean median mode previous next linear
//   fillmissing(numbers, "text")     an error (it used to do nothing - P7.1)
#include "process_common.h"
#include "process_axis.h"
#include "process_table.h"

#include <algorithm>
#include <cctype>
#include <map>
#include <numeric>

#include "../../builtins/builtins.h"
#include "../../core/error_lines.h"
#include "../../Scipy/special_functions/sf_core.h"

namespace nc {
namespace ops {
namespace process {

namespace {

bool anyTextIn(const Value &v) {
  if (v.isText)
    return true;
  if (!(v.isArray || v.isMatrix))
    return false;
  const Grid g = numpy::ndx::gridOf(v);
  for (const Value &c : g.cells)
    if (c.isText)
      return true;
  return false;
}

const char *const kMethods[] = {"mean", "median", "mode", "previous", "next", "linear"};

bool isMethod(const Value &v) {
  if (!v.isText)
    return false;
  std::string t = v.text();
  for (char &c : t)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  for (const char *m : kMethods)
    if (t == m)
      return true;
  return false;
}

std::string methodList() { return "\"mean\", \"median\", \"mode\", \"previous\", \"next\" or \"linear\""; }

// ---- ismissing(X, "nan") ----------------------------------------------------

Value isMissingImpl(const Args &a, CallContext &ctx) {
  if (!nanOption(a[1], ctx))
    return Value(0.0);
  const Value &x = a[0];
  if (!(x.isArray || x.isMatrix))
    return Value::boolean(isMissingCell(x, true));
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  std::vector<Value> cells;
  cells.reserve(g.cells.size());
  for (const Value &c : g.cells)
    cells.push_back(Value::boolean(isMissingCell(c, true)));
  return rebuild(x, g.shape, cells);
}

// ---- fillmissing --------------------------------------------------------------

// Fills the missing cells of one series (row-major indices `idx` of `g`).
bool fillSeries(Grid &g, const std::vector<size_t> &idx, const std::string &method, bool nanToo,
                CallContext &ctx) {
  std::vector<size_t> known;
  for (size_t k : idx)
    if (!isMissingCell(g.cells[k], nanToo))
      known.push_back(k);
  if (known.size() == idx.size() || known.empty())
    return true; // nothing to fill, or nothing to fill from
  const bool numeric = method == "mean" || method == "median" || method == "linear";
  if (numeric) {
    for (size_t k : known)
      if (!isNumberCell(g.cells[k])) {
        ctx.fail("\"" + method + "\" needs numbers, and " + where(g, k) +
                 " is not one - use \"mode\", \"previous\" or \"next\" for text");
        return false;
      }
  }
  if (method == "mean" || method == "median") {
    std::vector<double> v;
    v.reserve(known.size());
    for (size_t k : known)
      v.push_back(g.cells[k].number);
    double fill = 0;
    if (method == "mean") {
      double s = 0;
      for (double d : v)
        s += d;
      fill = s / static_cast<double>(v.size());
    } else {
      std::sort(v.begin(), v.end());
      fill = percentileSorted(v, 50);
    }
    for (size_t k : idx)
      if (isMissingCell(g.cells[k], nanToo))
        g.cells[k] = Value(fill);
    return true;
  }
  if (method == "mode") {
    std::vector<size_t> order = known;
    std::stable_sort(order.begin(), order.end(), [&](size_t x, size_t y) {
      return numpy::ndx::compareCells(g.cells[x], g.cells[y]) < 0;
    });
    size_t best = order[0], bestCount = 0;
    for (size_t i = 0; i < order.size();) {
      size_t j = i;
      while (j < order.size() && numpy::ndx::compareCells(g.cells[order[i]], g.cells[order[j]]) == 0)
        j++;
      if (j - i > bestCount) { // ties: the smallest value (the first group)
        bestCount = j - i;
        best = order[i];
      }
      i = j;
    }
    const Value fill = g.cells[best];
    for (size_t k : idx)
      if (isMissingCell(g.cells[k], nanToo))
        g.cells[k] = fill;
    return true;
  }
  if (method == "previous" || method == "next") {
    const bool fwd = method == "previous";
    const size_t n = idx.size();
    bool have = false;
    Value last;
    for (size_t s = 0; s < n; s++) {
      const size_t k = idx[fwd ? s : n - 1 - s];
      if (!isMissingCell(g.cells[k], nanToo)) {
        last = g.cells[k];
        have = true;
      } else if (have) {
        g.cells[k] = last;
      }
    }
    return true;
  }
  // linear: a straight line between the known neighbours; the ends take the
  // nearest known value.
  std::vector<size_t> pos; // positions (within the series) of the known cells
  for (size_t s = 0; s < idx.size(); s++)
    if (!isMissingCell(g.cells[idx[s]], nanToo))
      pos.push_back(s);
  size_t next = 0;
  for (size_t s = 0; s < idx.size(); s++) {
    const size_t k = idx[s];
    while (next < pos.size() && pos[next] < s)
      next++;
    if (!isMissingCell(g.cells[k], nanToo))
      continue;
    if (next == 0) {
      g.cells[k] = Value(g.cells[idx[pos[0]]].number);
    } else if (next >= pos.size()) {
      g.cells[k] = Value(g.cells[idx[pos.back()]].number);
    } else {
      const size_t s0 = pos[next - 1], s1 = pos[next];
      const double v0 = g.cells[idx[s0]].number, v1 = g.cells[idx[s1]].number;
      const double t = static_cast<double>(s - s0) / static_cast<double>(s1 - s0);
      g.cells[k] = Value(v0 + (v1 - v0) * t);
    }
  }
  return true;
}

Value fillMissingImpl(const Args &a, CallContext &ctx) {
  const bool nanToo = a.size() == 3;
  if (nanToo && !nanOption(a[2], ctx))
    return Value(0.0);
  const Value &x = a[0];
  if (x.isDict || x.isObject || x.isFunctionRef) {
    ctx.fail("expects a number, text or a matrix");
    return Value(0.0);
  }
  if (!isMethod(a[1])) {
    if (a[1].isText && !anyTextIn(x)) {
      // P7.1: fillmissing(Y, "mean") used to be accepted and change nothing.
      ctx.fail("\"" + a[1].text() + "\" is not a method - use " + methodList() +
               ", or a number to put in every gap");
      return Value(0.0);
    }
    // A value for every gap.
    const Value &fill = a[1];
    if (!(x.isArray || x.isMatrix))
      return isMissingCell(x, nanToo) ? fill : x;
    Grid g = numpy::ndx::gridOf(x);
    for (Value &c : g.cells)
      if (isMissingCell(c, nanToo))
        c = fill;
    return rebuild(x, g.shape, g.cells);
  }
  std::string method = a[1].text();
  for (char &c : method)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (!(x.isArray || x.isMatrix))
    return x; // one value: nothing around it to fill from
  Grid g = numpy::ndx::gridOf(x);
  if (!twoD(g)) {
    ctx.fail("a method works per column of a 2-D matrix; this value is " + nd::shapeText(g.shape));
    return Value(0.0);
  }
  for (const auto &series : columnSeries(g))
    if (!fillSeries(g, series, method, nanToo, ctx))
      return Value(0.0);
  return rebuild(x, g.shape, g.cells);
}

bool fillMissingAccepts(const Args &a) {
  if (a.size() == 3)
    return true;
  if (a.size() == 2 && a[1].isText)
    return isMethod(a[1]) || !anyTextIn(a[0]);
  return false;
}

// ---- rmmissing ------------------------------------------------------------------

Value rmMissingImpl(const Args &a, CallContext &ctx) {
  const bool nanToo = a.size() == 2;
  if (nanToo && !nanOption(a[1], ctx))
    return Value(0.0);
  const Value &x = a[0];
  if (isTableObject(x)) { // a loaded table: the rows with a missing cell go
    std::vector<std::string> names;
    std::vector<Value> cols;
    std::string err;
    if (!tableColumns(x, names, cols, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    const size_t n = tableRowCount(x);
    std::vector<char> drop(n, 0);
    for (const Value &col : cols) {
      const Grid g = numpy::ndx::gridOf(col);
      for (size_t r = 0; r < n && r < g.cells.size(); r++)
        drop[r] = drop[r] || isMissingCell(g.cells[r], nanToo);
    }
    std::vector<size_t> keep;
    for (size_t r = 0; r < n; r++)
      if (!drop[r])
        keep.push_back(r);
    Value out;
    if (!tableTakeRows(x, keep, out, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    return out;
  }
  if (!(x.isArray || x.isMatrix))
    return x;
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  if (!twoD(g)) {
    ctx.fail("works on vectors and 2-D matrices; this value is " + nd::shapeText(g.shape));
    return Value(0.0);
  }
  const size_t R = g.shape[0], C = g.shape[1];
  if (isVector(g)) {
    std::vector<Value> keep;
    for (const Value &c : g.cells)
      if (!isMissingCell(c, nanToo))
        keep.push_back(c);
    const bool column = C == 1 && R > 1;
    return rebuild(x, column ? nd::Shape{keep.size(), 1} : nd::Shape{1, keep.size()}, keep);
  }
  std::vector<Value> keep;
  size_t rows = 0;
  for (size_t r = 0; r < R; r++) {
    bool any = false;
    for (size_t c = 0; c < C && !any; c++)
      any = isMissingCell(g.cells[r * C + c], nanToo);
    if (any)
      continue;
    keep.insert(keep.end(), g.cells.begin() + static_cast<std::ptrdiff_t>(r * C),
                g.cells.begin() + static_cast<std::ptrdiff_t>((r + 1) * C));
    rows++;
  }
  return rebuild(x, nd::Shape{rows, C}, keep);
}

// ---- numbers of a grid ----------------------------------------------------------

bool numbersOf(const Grid &g, CallContext &ctx, std::vector<double> &out) {
  out.resize(g.cells.size());
  for (size_t k = 0; k < g.cells.size(); k++) {
    const Value &c = g.cells[k];
    if (!isNumberCell(c)) {
      ctx.fail(where(g, k) + " is not a number - this works on numbers (cast or encode text first)");
      return false;
    }
    out[k] = c.number;
  }
  return true;
}

// The sorted non-NaN values of one series.
std::vector<double> sortedKnown(const std::vector<double> &v, const std::vector<size_t> &idx) {
  std::vector<double> s;
  s.reserve(idx.size());
  for (size_t k : idx)
    if (!std::isnan(v[k]))
      s.push_back(v[k]);
  std::sort(s.begin(), s.end());
  return s;
}

void meanSd(const std::vector<double> &s, double &mean, double &sd) {
  mean = 0;
  for (double d : s)
    mean += d;
  mean = s.empty() ? std::nan("") : mean / static_cast<double>(s.size());
  double ss = 0;
  for (double d : s)
    ss += (d - mean) * (d - mean);
  sd = s.size() < 2 ? 0 : std::sqrt(ss / static_cast<double>(s.size() - 1));
}

// ---- outliers -------------------------------------------------------------------

bool pairArg(const Value &v, double &lo, double &hi) {
  if (!(v.isArray || v.isMatrix))
    return false;
  const Grid g = numpy::ndx::gridOf(v);
  if (g.cells.size() != 2 || !isNumberCell(g.cells[0]) || !isNumberCell(g.cells[1]))
    return false;
  lo = g.cells[0].number;
  hi = g.cells[1].number;
  return true;
}

Value outliersImpl(const Args &a, CallContext &ctx) {
  std::string method, action;
  if (!textArg(a, 1, ctx, "the method", method) || !textArg(a, 3, ctx, "the action", action))
    return Value(0.0);
  if (method != "zscore" && method != "iqr" && method != "percentile" && method != "bounds") {
    ctx.fail("the method is \"zscore\", \"iqr\", \"percentile\" or \"bounds\", not \"" + method + "\"");
    return Value(0.0);
  }
  if (action != "clip" && action != "missing" && action != "drop") {
    ctx.fail("the action is \"clip\", \"missing\" or \"drop\", not \"" + action + "\"");
    return Value(0.0);
  }
  double k = 0, plo = 0, phi = 0;
  if (method == "zscore" || method == "iqr") {
    if (!isNumberCell(a[2]) || !(a[2].number > 0) || !std::isfinite(a[2].number)) {
      ctx.fail("k must be a number above 0, e.g. 3 (z-score) or 1.5 (IQR)");
      return Value(0.0);
    }
    k = a[2].number;
  } else {
    if (!pairArg(a[2], plo, phi) || !(plo <= phi)) {
      ctx.fail("the limits must be [lower, upper] with lower <= upper");
      return Value(0.0);
    }
    if (method == "percentile" && (plo < 0 || phi > 100)) {
      ctx.fail("percentiles go from 0 to 100");
      return Value(0.0);
    }
  }
  const Value &x = a[0];
  const bool scalar = !(x.isArray || x.isMatrix);
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  if (!twoD(g)) {
    ctx.fail("works on vectors and 2-D matrices; this value is " + nd::shapeText(g.shape));
    return Value(0.0);
  }
  std::vector<double> v;
  if (!numbersOf(g, ctx, v))
    return Value(0.0);
  std::vector<char> out(v.size(), 0);
  for (const auto &series : columnSeries(g)) {
    double lo = plo, hi = phi;
    if (method != "bounds") {
      const std::vector<double> s = sortedKnown(v, series);
      if (s.empty())
        continue;
      if (method == "zscore") {
        double m, sd;
        meanSd(s, m, sd);
        lo = m - k * sd;
        hi = m + k * sd;
      } else if (method == "iqr") {
        const double q1 = percentileSorted(s, 25), q3 = percentileSorted(s, 75);
        lo = q1 - k * (q3 - q1);
        hi = q3 + k * (q3 - q1);
      } else {
        lo = percentileSorted(s, plo);
        hi = percentileSorted(s, phi);
      }
    }
    for (size_t i : series) {
      const double d = v[i];
      if (std::isnan(d))
        continue; // missing values are never outliers
      if (d < lo || d > hi) {
        out[i] = 1;
        if (action == "clip")
          v[i] = d < lo ? lo : hi;
        else if (action == "missing")
          v[i] = missingNumber();
      }
    }
  }
  if (scalar)
    return action == "drop" && out[0] ? Value(std::vector<std::vector<Value>>{}) : Value(v[0]);
  if (action != "drop")
    return packedLike(x, g.shape, v);
  const size_t R = g.shape[0], C = g.shape[1];
  std::vector<double> keep;
  if (isVector(g)) {
    for (size_t i = 0; i < v.size(); i++)
      if (!out[i])
        keep.push_back(v[i]);
    const bool column = C == 1 && R > 1;
    return packedLike(x, column ? nd::Shape{keep.size(), 1} : nd::Shape{1, keep.size()}, keep);
  }
  size_t rows = 0;
  for (size_t r = 0; r < R; r++) {
    bool any = false;
    for (size_t c = 0; c < C; c++)
      any = any || out[r * C + c];
    if (any)
      continue;
    keep.insert(keep.end(), v.begin() + static_cast<std::ptrdiff_t>(r * C),
                v.begin() + static_cast<std::ptrdiff_t>((r + 1) * C));
    rows++;
  }
  return packedLike(x, nd::Shape{rows, C}, keep);
}

// ---- normalize ------------------------------------------------------------------

Value normalizeImpl(const Args &a, CallContext &ctx) {
  std::string method;
  if (!textArg(a, 1, ctx, "the method", method))
    return Value(0.0);
  static const char *const methods[] = {"l1", "l2", "maxabs", "minmax", "zscore", "robust", "gauss"};
  bool known = false;
  for (const char *m : methods)
    known = known || method == m;
  if (!known) {
    ctx.fail("the method is \"l1\", \"l2\", \"maxabs\", \"minmax\", \"zscore\", \"robust\" or "
             "\"gauss\", not \"" + method + "\"");
    return Value(0.0);
  }
  int axis = -1; // all values
  if (a.size() > 2) {
    const Value &ax = a[2];
    if (ax.isText) {
      std::string t = ax.text();
      for (char &c : t)
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
      if (t != "all") {
        ctx.fail("the axis is 0 (each column), 1 (each row) or \"all\"");
        return Value(0.0);
      }
    } else if (isNumberCell(ax) && (ax.number == 0 || ax.number == 1 || ax.number == -1 || ax.number == -2)) {
      axis = ax.number == 0 || ax.number == -2 ? 0 : 1;
    } else {
      ctx.fail("the axis is 0 (each column), 1 (each row) or \"all\"");
      return Value(0.0);
    }
  }
  double lo = 0, hi = 1;
  if (a.size() > 3) {
    if (method != "minmax") {
      ctx.fail("lower / upper ends go with \"minmax\" only");
      return Value(0.0);
    }
    if (!numberArg(a, 3, ctx, "the lower end", lo) || (a.size() > 4 && !numberArg(a, 4, ctx, "the upper end", hi)))
      return Value(0.0);
    if (!(lo < hi)) {
      ctx.fail("the lower end must be below the upper end");
      return Value(0.0);
    }
  }
  const Value &x = a[0];
  const bool scalar = !(x.isArray || x.isMatrix);
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  if (axis >= 0 && !twoD(g)) {
    ctx.fail("per column / row works on 2-D matrices; this value is " + nd::shapeText(g.shape) +
             " - leave the axis out to scale all values");
    return Value(0.0);
  }
  std::vector<double> v;
  if (!numbersOf(g, ctx, v))
    return Value(0.0);
  for (const auto &series : axisSeries(g, axis)) {
    const std::vector<double> s = sortedKnown(v, series);
    if (s.empty())
      continue;
    if (method == "gauss") {
      // Rank-Gauss: ranks (ties: the mean rank) -> (r - 0.5) / n -> the
      // inverse normal CDF.
      std::vector<size_t> known;
      for (size_t i : series)
        if (!std::isnan(v[i]))
          known.push_back(i);
      std::vector<size_t> order = known;
      std::stable_sort(order.begin(), order.end(), [&](size_t p, size_t q) { return v[p] < v[q]; });
      const double n = static_cast<double>(order.size());
      std::vector<double> result(v.size());
      for (size_t i = 0; i < order.size();) {
        size_t j = i;
        while (j < order.size() && v[order[j]] == v[order[i]])
          j++;
        const double rank = (static_cast<double>(i + 1) + static_cast<double>(j)) / 2.0; // 1-based mean
        const double z = nc::scipy::sf::ndtri((rank - 0.5) / n);
        for (size_t t = i; t < j; t++)
          result[order[t]] = z;
        i = j;
      }
      for (size_t i : known)
        v[i] = result[i];
      continue;
    }
    double shift = 0, scale = 1, offset = 0;
    if (method == "l1" || method == "l2" || method == "maxabs") {
      double n = 0;
      for (double d : s) {
        if (method == "l1")
          n += std::fabs(d);
        else if (method == "l2")
          n += d * d;
        else
          n = std::max(n, std::fabs(d));
      }
      scale = method == "l2" ? std::sqrt(n) : n;
    } else if (method == "minmax") {
      shift = s.front();
      scale = (s.back() - s.front()) / (hi - lo);
      offset = lo;
    } else if (method == "zscore") {
      double m, sd;
      meanSd(s, m, sd);
      shift = m;
      scale = sd;
    } else { // robust
      shift = percentileSorted(s, 50);
      scale = percentileSorted(s, 75) - percentileSorted(s, 25);
    }
    if (!(scale != 0) || !std::isfinite(scale))
      scale = 1; // a constant series: 0 (or the lower end), never nan
    for (size_t i : series)
      if (!std::isnan(v[i]))
        v[i] = (v[i] - shift) / scale + offset;
  }
  if (scalar)
    return Value(v[0]);
  return packedLike(x, g.shape, v);
}

// ---- sortrows -------------------------------------------------------------------

// sortrows on a loaded table: by column number or column name.
Value sortTableRows(const Args &a, CallContext &ctx, bool desc) {
  std::vector<std::string> names;
  std::vector<Value> cols;
  std::string err;
  if (!tableColumns(a[0], names, cols, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  long long c0 = -1;
  if (a[1].isText) {
    for (size_t i = 0; i < names.size(); i++)
      if (names[i] == a[1].text())
        c0 = static_cast<long long>(i);
    if (c0 < 0) {
      ctx.fail("the table has no column \"" + a[1].text() + "\"");
      return Value(0.0);
    }
  } else {
    long long col = 0;
    if (!wholeArg(a, 1, ctx, "the column (a number from 0, or a name)", col))
      return Value(0.0);
    c0 = col < 0 ? col + static_cast<long long>(names.size()) : col;
    if (c0 < 0 || c0 >= static_cast<long long>(names.size())) {
      ctx.fail("column " + std::to_string(col) + " does not exist - the table has " +
               std::to_string(names.size()) + " columns");
      return Value(0.0);
    }
  }
  const Grid g = numpy::ndx::gridOf(cols[static_cast<size_t>(c0)]);
  std::vector<size_t> rows(g.cells.size());
  std::iota(rows.begin(), rows.end(), 0);
  std::stable_sort(rows.begin(), rows.end(), [&](size_t p, size_t q) {
    const bool mx = isMissingCell(g.cells[p], true), my = isMissingCell(g.cells[q], true);
    if (mx || my)
      return !mx && my;
    const int r = numpy::ndx::compareCells(g.cells[p], g.cells[q]);
    return desc ? r > 0 : r < 0;
  });
  Value out;
  if (!tableTakeRows(a[0], rows, out, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  return out;
}

Value sortRowsImpl(const Args &a, CallContext &ctx) {
  std::string order;
  if (!optTextArg(a, 2, ctx, "the order", "ascending", order))
    return Value(0.0);
  if (order != "ascending" && order != "descending") {
    ctx.fail("the order is \"ascending\" or \"descending\"");
    return Value(0.0);
  }
  if (isTableObject(a[0]))
    return sortTableRows(a, ctx, order == "descending");
  long long col = 0;
  if (!wholeArg(a, 1, ctx, "the column", col))
    return Value(0.0);
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  if (!twoD(g)) {
    ctx.fail("works on 2-D matrices; this value is " + nd::shapeText(g.shape));
    return Value(0.0);
  }
  const size_t R = g.shape[0], C = g.shape[1];
  if (C == 0 || R == 0)
    return a[0];
  const long long c0 = col < 0 ? col + static_cast<long long>(C) : col;
  if (c0 < 0 || c0 >= static_cast<long long>(C)) {
    ctx.fail("column " + std::to_string(col) + " does not exist - the matrix has " + std::to_string(C) +
             " columns (0 to " + std::to_string(C - 1) + ")");
    return Value(0.0);
  }
  const size_t c = static_cast<size_t>(c0);
  const bool desc = order == "descending";
  std::vector<size_t> rows(R);
  std::iota(rows.begin(), rows.end(), 0);
  auto missing = [&](const Value &v) { return isMissingCell(v, true); };
  std::stable_sort(rows.begin(), rows.end(), [&](size_t p, size_t q) {
    const Value &x = g.cells[p * C + c], &y = g.cells[q * C + c];
    const bool mx = missing(x), my = missing(y);
    if (mx || my)
      return !mx && my; // missing rows last, in either order
    const int r = numpy::ndx::compareCells(x, y);
    return desc ? r > 0 : r < 0;
  });
  std::vector<Value> out;
  out.reserve(g.cells.size());
  for (size_t r : rows)
    out.insert(out.end(), g.cells.begin() + static_cast<std::ptrdiff_t>(r * C),
               g.cells.begin() + static_cast<std::ptrdiff_t>((r + 1) * C));
  return rebuild(a[0], g.shape, out);
}

// ---- squeeze / expand_dims / tril / triu ------------------------------------

Value squeezeImpl(const Args &a, CallContext &ctx) {
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  if (g.shape.size() <= 2)
    return a[0]; // a 2-D matrix keeps its shape (NC's smallest rank is 2)
  nd::Shape s;
  for (size_t d : g.shape)
    if (d != 1)
      s.push_back(d);
  if (s.size() < 2)
    s = nd::withRank(s, 2); // 1x5x1 -> [5] -> the row 1x5
  return nd::buildRowMajor(s, g.cells); // row-major order does not change
}

Value expandDimsImpl(const Args &a, CallContext &ctx) {
  long long axis = 0;
  if (!wholeArg(a, 1, ctx, "the axis", axis))
    return Value(0.0);
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  const long long n = static_cast<long long>(g.shape.size()) + 1;
  if (axis < -n || axis >= n) {
    ctx.fail("axis " + std::to_string(axis) + " does not exist - use 0 to " + std::to_string(n - 1) +
             " (or -1 to -" + std::to_string(n) + ")");
    return Value(0.0);
  }
  const size_t at = static_cast<size_t>(axis < 0 ? axis + n : axis);
  nd::Shape s = g.shape;
  s.insert(s.begin() + static_cast<std::ptrdiff_t>(at), 1);
  return nd::buildRowMajor(s, g.cells);
}

// A zero of the cell's own type, so a float32 / int16 / bool matrix keeps
// its type (a plain 0.0 next to float32 cells made a cell matrix).
Value zeroLike(const Value &c) {
  if (c.isText)
    return Value(std::string());
  if (c.isBool())
    return Value::boolean(false);
  if (c.isInt())
    return c.intIsUnsigned() ? Value::integerUnsigned(c.intType(), 0) : Value::integerSigned(c.intType(), 0);
  const FloatType ft = c.floatType();
  if (ft != FloatType::Float64)
    return Value::floating(ft, 0.0);
  return Value(0.0);
}

Value triangleImpl(const Args &a, CallContext &ctx, bool lower) {
  long long k = 0;
  if (a.size() > 1 && !wholeArg(a, 1, ctx, "k (the diagonal)", k))
    return Value(0.0);
  const Value &x = a[0];
  if (!(x.isArray || x.isMatrix))
    return (lower ? 0 >= -k : 0 <= -k) ? x : Value(0.0);
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  if (!twoD(g)) {
    ctx.fail("works on 2-D matrices; this value is " + nd::shapeText(g.shape));
    return Value(0.0);
  }
  const size_t C = g.shape[1];
  for (size_t i = 0; i < g.cells.size(); i++) {
    const long long r = static_cast<long long>(i / C), c = static_cast<long long>(i % C);
    const bool keep = lower ? c - r <= k : c - r >= k;
    if (!keep)
      g.cells[i] = zeroLike(g.cells[i]);
  }
  return rebuild(x, g.shape, g.cells);
}

} // namespace

// ---- axis= forms of mean / median / var / sd / sum / sort ----------------------

bool isAxisFunction(const std::string &key) {
  return key == "mean" || key == "median" || key == "var" || key == "sd" || key == "sum" ||
         key == "sort";
}

bool axisCall(const std::string &key, const Value &x, const Value &axisValue, Value &out,
              std::string &err) {
  if (!isNumberCell(axisValue) || !std::isfinite(axisValue.number) ||
      axisValue.number != std::floor(axisValue.number)) {
    err = "axis must be a whole number: 0 (each column) or 1 (each row)";
    return false;
  }
  long long ax = static_cast<long long>(axisValue.number);
  if (ax < 0)
    ax += 2;
  if (ax != 0 && ax != 1) {
    err = "axis " + std::to_string(static_cast<long long>(axisValue.number)) +
          " does not exist - use 0 (each column) or 1 (each row)";
    return false;
  }
  if (x.isDict || x.isObject || x.isFunctionRef || x.isText) {
    err = "expects a matrix";
    return false;
  }
  const Grid g = numpy::ndx::gridOf(x);
  if (g.shape.size() != 2) {
    err = "axis= works on 2-D matrices; this value is " + nd::shapeText(g.shape);
    return false;
  }
  const size_t R = g.shape[0], C = g.shape[1];
  const auto series = axisSeries(g, static_cast<int>(ax));
  std::vector<Value> results;
  results.reserve(series.size());
  for (const auto &idx : series) {
    std::vector<Value> slice;
    slice.reserve(idx.size());
    for (size_t k : idx)
      slice.push_back(g.cells[k]);
    // The existing function on each column / row, so its rules (nan, n < 2,
    // text order ...) are the same as for a whole vector.
    const Value row = numpy::ndx::rowOf(slice);
    const unsigned long before = nc::errorlines::count();
    Value r = callBuiltin(key, {row});
    if (nc::errorlines::count() != before || !g_lastBuiltinFound) {
      err.clear(); // already reported
      return false;
    }
    results.push_back(std::move(r));
  }
  if (key != "sort") {
    // One value per column (a 1 x C row) or per row (an R x 1 column).
    out = nd::buildRowMajor(ax == 0 ? nd::Shape{1, C} : nd::Shape{R, 1}, results);
    return true;
  }
  std::vector<Value> cells(g.cells.size());
  for (size_t s = 0; s < series.size(); s++) {
    const Grid sorted = numpy::ndx::gridOf(results[s]);
    if (sorted.cells.size() != series[s].size()) {
      err = "sort gave a different number of values";
      return false;
    }
    for (size_t i = 0; i < series[s].size(); i++)
      cells[series[s][i]] = sorted.cells[i];
  }
  out = rebuild(x, g.shape, cells);
  return true;
}

void registerProcessStats(OpsRegistry &reg) {
  addSpec(reg, "ismissing", 2, 2, "ismissing(X, \"nan\")", "missing, nan and \"\" too", kNDArgs,
          isMissingImpl, [](const Args &a) { return a.size() == 2; });
  addSpec(reg, "fillmissing", 2, 3, "fillmissing(X, value or method[, \"nan\"])",
          "gaps filled by a value or a statistic", 0, fillMissingImpl, fillMissingAccepts);
  addSpec(reg, "rmmissing", 1, 2, "rmmissing(X[, \"nan\"])", "missing entries (rows) dropped", 0,
          rmMissingImpl);
  addSpec(reg, "outliers", 4, 4, "outliers(X, method, arg, action)",
          "outliers clipped, marked missing or dropped", 0, outliersImpl);
  addSpec(reg, "normalize", 2, 5, "normalize(X, method[, axis[, lo, hi]])",
          "scaled per column, row or all", 0, normalizeImpl);
  addSpec(reg, "sortrows", 2, 3, "sortrows(X, col[, order])", "rows ordered by a column", 0,
          sortRowsImpl);
  addSpec(reg, "squeeze", 1, 1, "squeeze(X)", "axes of length 1 dropped", kNDArgs, squeezeImpl);
  addSpec(reg, "expand_dims", 2, 2, "expand_dims(X, axis)", "an axis of length 1 added", kNDArgs,
          expandDimsImpl);
  addSpec(reg, "tril", 1, 2, "tril(X[, k])", "lower triangle, the rest 0", 0,
          [](const Args &a, CallContext &ctx) { return triangleImpl(a, ctx, true); });
  addSpec(reg, "triu", 1, 2, "triu(X[, k])", "upper triangle, the rest 0", 0,
          [](const Args &a, CallContext &ctx) { return triangleImpl(a, ctx, false); });
}

} // namespace process
} // namespace ops
} // namespace nc
