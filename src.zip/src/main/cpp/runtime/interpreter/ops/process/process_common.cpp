// Shared helpers of the data processing built-ins - see process_common.h.
#include "process_common.h"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>

#include "../floating/floating.h"
#include "../time/time.h"

namespace nc {
namespace ops {

void registerProcessing(OpsRegistry &reg) {
  process::registerProcessText(reg);
  process::registerProcessStats(reg);
  process::registerProcessEncode(reg);
}

namespace process {

namespace {
std::string lowered(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}
} // namespace

void addSpec(OpsRegistry &reg, const std::string &name, int minArgs, int maxArgs,
             const std::string &usage, const std::string &summary, unsigned flags, Impl impl,
             std::function<bool(const Args &)> accepts) {
  OpsSpec s{name, Domain::DataProcessing, minArgs, maxArgs, usage, summary, flags, std::move(impl)};
  s.accepts = std::move(accepts);
  reg.add(std::move(s));
}

bool nanOption(const Value &v, CallContext &ctx) {
  if (v.isText && lowered(v.text()) == "nan")
    return true;
  ctx.fail("the last value may only be \"nan\" (count a plain nan and \"\" as missing too)");
  return false;
}

bool gridArg(const Args &a, size_t i, CallContext &ctx, Grid &out) {
  if (i >= a.size() || a[i].isDict || a[i].isObject || a[i].isFunctionRef) {
    ctx.fail(i >= a.size() ? "a value is missing"
                           : "value " + std::to_string(i + 1) +
                                 " must be a number, text or a matrix (a loaded object: use its "
                                 ".data, or the Process window, which works column by column)");
    return false;
  }
  out = numpy::ndx::gridOf(a[i]);
  return true;
}

bool textArg(const Args &a, size_t i, CallContext &ctx, const std::string &what,
             std::string &out) {
  if (i >= a.size() || !a[i].isText) {
    ctx.fail(what + " must be text, e.g. \"" + (what.empty() ? "" : what) + "\"");
    return false;
  }
  out = lowered(a[i].text());
  return true;
}

bool optTextArg(const Args &a, size_t i, CallContext &ctx, const std::string &what,
                const std::string &fallback, std::string &out) {
  if (i >= a.size()) {
    out = fallback;
    return true;
  }
  if (!a[i].isText) {
    ctx.fail(what + " must be text");
    return false;
  }
  out = lowered(a[i].text());
  return true;
}

bool numberArg(const Args &a, size_t i, CallContext &ctx, const std::string &what, double &out) {
  if (i >= a.size() || !isNumberCell(a[i])) {
    ctx.fail(what + " must be a number");
    return false;
  }
  out = a[i].number;
  return true;
}

bool wholeArg(const Args &a, size_t i, CallContext &ctx, const std::string &what, long long &out) {
  double d = 0;
  if (!numberArg(a, i, ctx, what, d))
    return false;
  if (!std::isfinite(d) || d != std::floor(d)) {
    ctx.fail(what + " must be a whole number");
    return false;
  }
  out = static_cast<long long>(d);
  return true;
}

std::string where(const Grid &g, size_t k) {
  if (g.shape.size() == 2 && g.shape[1] > 0) {
    if (g.shape[0] == 1)
      return "element " + std::to_string(k);
    return "row " + std::to_string(k / g.shape[1]) + ", column " + std::to_string(k % g.shape[1]);
  }
  return "element " + std::to_string(k);
}

std::string shortestText(double x) {
  if (std::isnan(x))
    return "nan";
  if (std::isinf(x))
    return x > 0 ? "inf" : "-inf";
  if (x == 0)
    return "0"; // also -0
  char buf[40];
  int p = 1;
  for (; p <= 17; p++) {
    std::snprintf(buf, sizeof buf, "%.*g", p, x);
    if (std::strtod(buf, nullptr) == x)
      break;
  }
  // Whole digits are written out below 1e16 ("1000", not "1e+03").
  const double ax = std::fabs(x);
  if (ax >= 1 && ax < 1e16) {
    const int intDigits = static_cast<int>(std::floor(std::log10(ax))) + 1;
    if (intDigits > p)
      std::snprintf(buf, sizeof buf, "%.*g", intDigits, x);
  }
  return buf;
}

namespace {
// The shortest text that reads back as `x` in a narrower float format.
std::string shortestInFormat(double x, FloatType t) {
  if (std::isnan(x) || std::isinf(x) || x == 0)
    return shortestText(x);
  char buf[40];
  int p = 1;
  for (; p <= 17; p++) {
    std::snprintf(buf, sizeof buf, "%.*g", p, x);
    if (roundToFloatType(t, std::strtod(buf, nullptr)) == x)
      break;
  }
  const double ax = std::fabs(x);
  if (ax >= 1 && ax < 1e16) {
    const int intDigits = static_cast<int>(std::floor(std::log10(ax))) + 1;
    if (intDigits > p)
      std::snprintf(buf, sizeof buf, "%.*g", intDigits, x);
  }
  return buf;
}
} // namespace

std::string cellText(const Value &v, bool missingAsEmpty) {
  if (v.isText)
    return v.text();
  if (v.isTime())
    return nctime::displayText(v);
  if (v.isBool())
    return v.number != 0 ? "true" : "false";
  if (v.isInt())
    return v.intText();
  if (v.isComplex) {
    const std::string re = shortestText(v.number), im = shortestText(std::fabs(v.imag));
    return re + (v.imag < 0 || (v.imag == 0 && std::signbit(v.imag)) ? "-" : "+") + im + "i";
  }
  if (missingAsEmpty && isMissingNumber(v.number))
    return "";
  const FloatType ft = v.floatType();
  if (ft != FloatType::Float64)
    return shortestInFormat(v.number, ft);
  return shortestText(v.number);
}

Value rebuild(const Value &like, const nd::Shape &shape, const std::vector<Value> &cells) {
  if (like.isArray && shape.size() == 2 && shape[0] == 1)
    return Value(cells);
  return nd::buildRowMajor(shape, cells);
}

Value packedLike(const Value &like, const nd::Shape &shape, const std::vector<double> &vals) {
  if (like.isArray && shape.size() == 2 && shape[0] == 1)
    return Value::packedArray(vals.data(), vals.size());
  if (shape.size() == 2) {
    const size_t R = shape[0], C = shape[1];
    if (R * C == 0)
      return Value(std::vector<std::vector<Value>>{});
    std::vector<double> colMajor(R * C);
    for (size_t r = 0; r < R; r++)
      for (size_t c = 0; c < C; c++)
        colMajor[c * R + r] = vals[r * C + c];
    return Value::packedMatrix(colMajor.data(), R, C);
  }
  std::vector<Value> cells;
  cells.reserve(vals.size());
  for (double d : vals)
    cells.emplace_back(d);
  return nd::buildRowMajor(shape, cells);
}

double percentileSorted(const std::vector<double> &d, double p) {
  const size_t n = d.size();
  if (n == 0)
    return std::nan("");
  if (n == 1)
    return d[0];
  const double rank = (p / 100.0) * static_cast<double>(n - 1);
  const size_t i = static_cast<size_t>(std::floor(rank));
  const size_t j = i + 1 < n ? i + 1 : i;
  const double frac = rank - static_cast<double>(i);
  return d[i] + (d[j] - d[i]) * frac;
}

std::vector<std::vector<size_t>> columnSeries(const Grid &g) {
  if (isVector(g))
    return axisSeries(g, -1);
  return axisSeries(g, 0);
}

std::vector<std::vector<size_t>> axisSeries(const Grid &g, int axis) {
  std::vector<std::vector<size_t>> out;
  const size_t n = g.cells.size();
  if (axis < 0 || g.shape.size() != 2) {
    std::vector<size_t> all(n);
    for (size_t k = 0; k < n; k++)
      all[k] = k;
    out.push_back(std::move(all));
    return out;
  }
  const size_t R = g.shape[0], C = g.shape[1];
  if (axis == 0) {
    out.assign(C, {});
    for (size_t c = 0; c < C; c++)
      for (size_t r = 0; r < R; r++)
        out[c].push_back(r * C + c);
  } else {
    out.assign(R, {});
    for (size_t r = 0; r < R; r++)
      for (size_t c = 0; c < C; c++)
        out[r].push_back(r * C + c);
  }
  return out;
}

} // namespace process
} // namespace ops
} // namespace nc
