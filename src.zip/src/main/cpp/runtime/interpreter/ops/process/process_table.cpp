// Loaded tables for the data processing functions - see process_table.h.
#include "process_table.h"

#include <unordered_set>

#include "../../Numpy/importing_data/io_common.h"
#include "../../Numpy/numpy_nd.h"

namespace nc {
namespace ops {
namespace process {

namespace {

// The fields of `original` that are not its columns or the table's own
// parts - kept on the rebuilt table (file, meta, sheet ...).
io::Fields extraFields(const Value &original, const std::vector<std::string> &oldNames) {
  std::unordered_set<std::string> skip = {"cols", "rows", "data", "schema"};
  for (const std::string &n : oldNames)
    skip.insert(io::fieldName(n));
  io::Fields extra;
  for (const auto &kv : original.dict())
    if (!skip.count(kv.first))
      extra[kv.first] = kv.second;
  return extra;
}

std::vector<std::string> namesOf(const Value &table) {
  std::vector<std::string> names;
  if (const Value *cols = io::field(table, "cols")) {
    const numpy::ndx::Grid g = numpy::ndx::gridOf(*cols);
    for (const Value &c : g.cells)
      names.push_back(c.isText ? c.text() : std::string());
  }
  return names;
}

} // namespace

bool isTableObject(const Value &v) {
  return v.isObject && io::field(v, "cols") != nullptr && io::field(v, "data") != nullptr;
}

size_t tableRowCount(const Value &table) {
  io::Table t;
  std::string err;
  if (!io::valueToTable(table, t, err, false, true))
    return 0;
  return t.rowCount();
}

bool tableColumns(const Value &table, std::vector<std::string> &names, std::vector<Value> &columns,
                  std::string &err) {
  io::Table t;
  if (!io::valueToTable(table, t, err, false, true))
    return false;
  names = t.cols;
  columns.clear();
  columns.reserve(t.cols.size());
  for (size_t c = 0; c < t.cols.size(); c++)
    columns.push_back(io::tableColumn(t, c));
  return true;
}

bool tableFromColumns(const Value &original, const std::vector<std::string> &names,
                      const std::vector<Value> &columns, Value &out, std::string &err) {
  io::Table t;
  std::vector<std::vector<Value>> cols; // each column's cells
  size_t n = 0;
  bool first = true;
  std::string firstName;
  for (size_t i = 0; i < columns.size(); i++) {
    const numpy::ndx::Grid g = numpy::ndx::gridOf(columns[i]);
    const std::string &name = i < names.size() ? names[i] : std::string();
    // A vector is one column; an n x k matrix (onehot ...) is k columns.
    size_t rows = 0, width = 1;
    if (g.shape.size() == 2 && (g.shape[0] == 1 || g.shape[1] == 1)) {
      rows = g.cells.size();
    } else if (g.shape.size() == 2) {
      rows = g.shape[0];
      width = g.shape[1];
    } else {
      err = "column '" + name + "' became " + nd::shapeText(g.shape) + " - a table column is a vector";
      return false;
    }
    if (first) {
      n = rows;
      first = false;
      firstName = name;
    } else if (rows != n) {
      err = "column '" + name + "' now has " + std::to_string(rows) + " rows and column '" + firstName + "' " +
            std::to_string(n) + " - a step that adds or drops rows must work on the whole table";
      return false;
    }
    for (size_t k = 0; k < width; k++) {
      std::vector<Value> cells(rows);
      for (size_t r = 0; r < rows; r++)
        cells[r] = width == 1 ? g.cells[r] : g.cells[r * width + k];
      cols.push_back(std::move(cells));
      t.cols.push_back(width == 1 ? name : name + "_" + std::to_string(k));
    }
  }
  t.rows.assign(n, {});
  for (size_t r = 0; r < n; r++) {
    t.rows[r].reserve(cols.size());
    for (auto &c : cols)
      t.rows[r].push_back(std::move(c[r]));
  }
  io::normalizeTable(t);
  out = io::tableObject(t, extraFields(original, namesOf(original)), original.className());
  return true;
}

bool tableTakeRows(const Value &table, const std::vector<size_t> &keep, Value &out, std::string &err) {
  io::Table t;
  if (!io::valueToTable(table, t, err, false, false))
    return false;
  io::tableToRows(t);
  std::vector<std::vector<Value>> rows;
  rows.reserve(keep.size());
  for (size_t r : keep) {
    if (r >= t.rows.size()) {
      err = "row " + std::to_string(r) + " is outside the table";
      return false;
    }
    rows.push_back(t.rows[r]);
  }
  t.rows = std::move(rows);
  out = io::tableObject(t, extraFields(table, namesOf(table)), table.className());
  return true;
}

} // namespace process
} // namespace ops
} // namespace nc
