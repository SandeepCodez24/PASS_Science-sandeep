// mean(A, axis=k), median, var, sd, sum and sort(A, axis=k)
// (docs/Process_Window_CPP.md P5.6) - called from callBuiltinNamed()
// (builtins/builtins.cpp) for exactly `f(A, axis=k)`. Each column (axis 0) or
// row (axis 1) goes through the function's own one-vector form, so the
// numbers are the ones the whole-vector call gives.
#ifndef NC_OPS_PROCESS_AXIS_H
#define NC_OPS_PROCESS_AXIS_H

#include <string>

#include "../../core/value.h"

namespace nc {
namespace ops {
namespace process {

bool isAxisFunction(const std::string &lowerName);

// False with `err` set - or `err` empty when the column's own call already
// printed its error.
bool axisCall(const std::string &lowerName, const Value &x, const Value &axis, Value &out,
              std::string &err);

} // namespace process
} // namespace ops
} // namespace nc

#endif // NC_OPS_PROCESS_AXIS_H
