// Data processing built-ins, part 1 (docs/Process_Window_CPP.md P5.1, P5.2,
// P5.3, P5.9): astype, the element-wise text functions, unique(X, "stable")
// and to_time.
//
// lower / upper / replace / split already existed for ONE text
// (ops/collections/collections_builtin.cpp). The forms here take a text
// array or matrix and are reached only for one (OpsSpec::accepts), so every
// call that worked before still goes to the old function, with its old
// answer and its old messages.
#include "../../core/unicode_case.h"
#include "process_common.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <numeric>

#include "../../builtins/builtins.h"
#include "../../core/error_lines.h"
#include "../time/time.h"

namespace nc {
namespace ops {
namespace process {

namespace {

// ---- UTF-8 ----------------------------------------------------------------

std::u32string decodeUtf8(const std::string &s) {
  std::u32string out;
  out.reserve(s.size());
  for (size_t i = 0; i < s.size();) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    char32_t cp = c;
    size_t len = 1;
    if (c >= 0xF0) {
      len = 4;
      cp = c & 0x07;
    } else if (c >= 0xE0) {
      len = 3;
      cp = c & 0x0F;
    } else if (c >= 0xC0) {
      len = 2;
      cp = c & 0x1F;
    }
    if (i + len > s.size()) { // a cut-off sequence: keep the bytes as they are
      len = 1;
      cp = c;
    } else {
      for (size_t k = 1; k < len; k++)
        cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3F);
    }
    out.push_back(cp);
    i += len;
  }
  return out;
}

std::string encodeUtf8(const std::u32string &s) {
  std::string out;
  out.reserve(s.size());
  for (char32_t cp : s) {
    if (cp < 0x80) {
      out.push_back(static_cast<char>(cp));
    } else if (cp < 0x800) {
      out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
      out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp < 0x10000) {
      out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
      out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
      out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
      out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
      out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
      out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
      out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
  }
  return out;
}

// White space as strip() (Numpy/working_with_data/wd_text.cpp) sees it.
bool isSpaceCp(char32_t c) {
  return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f' || c == 0x85 ||
         c == 0xA0 || c == 0x1680 || (c >= 0x2000 && c <= 0x200A) || c == 0x2028 || c == 0x2029 ||
         c == 0x202F || c == 0x205F || c == 0x3000;
}

// ---- helpers ----------------------------------------------------------------

bool anyTextCell(const Value &v) {
  if (!(v.isArray || v.isMatrix))
    return false;
  const Grid g = numpy::ndx::gridOf(v);
  for (const Value &c : g.cells)
    if (c.isText)
      return true;
  return false;
}

// A text array / matrix: the older one-text function is not for it.
bool textContainer(const Args &a) { return !a.empty() && anyTextCell(a[0]); }

// Every text cell through fn; other cells unchanged. Shape and container
// kept.
template <typename Fn> Value mapText(const Value &x, Fn fn) {
  if (x.isText)
    return Value(fn(x.text()));
  Grid g = numpy::ndx::gridOf(x);
  for (Value &c : g.cells)
    if (c.isText)
      c = Value(fn(c.text()));
  return rebuild(x, g.shape, g.cells);
}

// 0 lower, 1 upper, 2 swap - every cased letter, not only ASCII
// (core/unicode_case.h, 2026-11-18).
std::string asciiCase(const std::string &s, int mode) { return nc::textcase::changeCase(s, mode); }

Value caseImpl(const Args &a, CallContext &ctx, int mode) {
  if (!a[0].isText && !(a[0].isArray || a[0].isMatrix)) {
    ctx.fail("expects text or a text array, e.g. swapcase([\"Ab\", \"cD\"])");
    return Value(0.0);
  }
  return mapText(a[0], [mode](const std::string &s) { return asciiCase(s, mode); });
}

Value stripImpl(const Args &a, CallContext &ctx, bool front) {
  std::u32string set;
  if (a.size() > 1) {
    if (!a[1].isText) {
      ctx.fail("the characters to remove must be text, e.g. \" .\"");
      return Value(0.0);
    }
    set = decodeUtf8(a[1].text());
  }
  if (!a[0].isText && !(a[0].isArray || a[0].isMatrix)) {
    ctx.fail("expects text or a text array");
    return Value(0.0);
  }
  auto drop = [&](char32_t c) { return set.empty() ? isSpaceCp(c) : set.find(c) != std::u32string::npos; };
  return mapText(a[0], [&](const std::string &s) {
    const std::u32string u = decodeUtf8(s);
    size_t b = 0, e = u.size();
    if (front)
      while (b < e && drop(u[b]))
        b++;
    else
      while (e > b && drop(u[e - 1]))
        e--;
    return encodeUtf8(u.substr(b, e - b));
  });
}

Value replaceImpl(const Args &a, CallContext &ctx) {
  if (!a[1].isText || !a[2].isText) {
    ctx.fail("expects (texts, old, new) with old and new as text");
    return Value(0.0);
  }
  const std::string from = a[1].text(), to = a[2].text();
  if (from.empty()) {
    ctx.fail("the old text must not be empty");
    return Value(0.0);
  }
  return mapText(a[0], [&](std::string s) {
    for (size_t at = s.find(from); at != std::string::npos; at = s.find(from, at + to.size()))
      s.replace(at, from.size(), to);
    return s;
  });
}

Value splitImpl(const Args &a, CallContext &ctx) {
  if (!a[1].isText || a[1].text().empty()) {
    ctx.fail("the separator must be a text that is not empty, e.g. \",\"");
    return Value(0.0);
  }
  const std::string sep = a[1].text();
  const Grid g = numpy::ndx::gridOf(a[0]);
  std::vector<std::vector<std::string>> parts;
  size_t widest = 0;
  for (size_t k = 0; k < g.cells.size(); k++) {
    const Value &c = g.cells[k];
    if (!c.isText) {
      ctx.fail(where(g, k) + " is not text - split cuts texts");
      return Value(0.0);
    }
    std::vector<std::string> p;
    const std::string &s = c.text();
    size_t from = 0;
    for (size_t at = s.find(sep); at != std::string::npos; at = s.find(sep, from)) {
      p.push_back(s.substr(from, at - from));
      from = at + sep.size();
    }
    p.push_back(s.substr(from));
    widest = std::max(widest, p.size());
    parts.push_back(std::move(p));
  }
  std::vector<std::vector<Value>> rows;
  rows.reserve(parts.size());
  for (auto &p : parts) {
    std::vector<Value> row;
    row.reserve(widest);
    for (size_t i = 0; i < widest; i++)
      row.emplace_back(i < p.size() ? p[i] : std::string());
    rows.push_back(std::move(row));
  }
  return Value(std::move(rows));
}

// ---- unique(X, "stable") ---------------------------------------------------

Value uniqueImpl(const Args &a, CallContext &ctx) {
  std::string how;
  if (!textArg(a, 1, ctx, "the order", how))
    return Value(0.0);
  if (how == "sorted") {
    const unsigned long before = nc::errorlines::count();
    Value r = callBuiltin("unique", {a[0]}); // NumPy's unique: sorted
    if (nc::errorlines::count() != before || !g_lastBuiltinFound)
      ctx.failSilently();
    return r;
  }
  if (how != "stable") {
    ctx.fail("the order is \"stable\" (first seen) or \"sorted\", not \"" + how + "\"");
    return Value(0.0);
  }
  Grid g;
  if (!gridArg(a, 0, ctx, g))
    return Value(0.0);
  std::vector<size_t> idx(g.cells.size());
  std::iota(idx.begin(), idx.end(), 0);
  std::stable_sort(idx.begin(), idx.end(), [&](size_t x, size_t y) {
    return numpy::ndx::compareCells(g.cells[x], g.cells[y]) < 0;
  });
  std::vector<size_t> firsts;
  for (size_t i = 0; i < idx.size(); i++)
    if (i == 0 || numpy::ndx::compareCells(g.cells[idx[i - 1]], g.cells[idx[i]]) != 0)
      firsts.push_back(idx[i]); // stable sort: the first seen of its group
  std::sort(firsts.begin(), firsts.end());
  std::vector<Value> out;
  out.reserve(firsts.size());
  for (size_t k : firsts)
    out.push_back(g.cells[k]);
  return numpy::ndx::rowOf(out);
}

// ---- astype ---------------------------------------------------------------

bool parseNumberText(const std::string &t0, double &out) {
  size_t b = 0, e = t0.size();
  while (b < e && std::isspace(static_cast<unsigned char>(t0[b])))
    b++;
  while (e > b && std::isspace(static_cast<unsigned char>(t0[e - 1])))
    e--;
  const std::string t = t0.substr(b, e - b);
  if (t.empty()) {
    out = missingNumber(); // an empty text is a missing number
    return true;
  }
  std::string low = t;
  for (char &c : low)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (low == "true") {
    out = 1;
    return true;
  }
  if (low == "false") {
    out = 0;
    return true;
  }
  if (low == "nan") {
    out = std::nan("");
    return true;
  }
  if (low == "inf" || low == "+inf") {
    out = HUGE_VAL;
    return true;
  }
  if (low == "-inf") {
    out = -HUGE_VAL;
    return true;
  }
  char *end = nullptr;
  out = std::strtod(t.c_str(), &end);
  return end && *end == '\0';
}

const char *const kTypes[] = {"int8",    "int16",   "int32",   "int64",  "uint8",
                              "uint16",  "uint32",  "uint64",  "float8", "float16",
                              "float32", "float64", "double",  "bool",   "string"};

Value astypeImpl(const Args &a, CallContext &ctx) {
  std::string type;
  if (!textArg(a, 1, ctx, "the type", type))
    return Value(0.0);
  bool known = false;
  for (const char *t : kTypes)
    known = known || type == t;
  if (!known) {
    ctx.fail("unknown type \"" + type +
             "\" - use int8 ... int64, uint8 ... uint64, float8, float16, float32, float64, "
             "\"bool\" or \"string\"");
    return Value(0.0);
  }
  const Value &x = a[0];
  if (x.isDict || x.isObject || x.isFunctionRef) {
    ctx.fail("expects a number, text or a matrix");
    return Value(0.0);
  }
  const bool scalar = !(x.isArray || x.isMatrix);

  if (type == "string") {
    if (scalar)
      return Value(cellText(x, true));
    Grid g = numpy::ndx::gridOf(x);
    for (Value &c : g.cells)
      c = Value(cellText(c, true));
    return rebuild(x, g.shape, g.cells);
  }

  // Numbers from the cells: text is read as a number ("2.5", "true", "" =
  // missing); a time value or complex number has no plain number.
  Grid g = numpy::ndx::gridOf(x);
  bool anyText = false;
  std::vector<double> nums(g.cells.size());
  for (size_t k = 0; k < g.cells.size(); k++) {
    const Value &c = g.cells[k];
    if (c.isText) {
      anyText = true;
      if (!parseNumberText(c.text(), nums[k])) {
        ctx.fail(where(g, k) + ": \"" + c.text() + "\" is not a number");
        return Value(0.0);
      }
    } else if (c.isTime() || c.isComplex || !isNumberCell(c)) {
      ctx.fail(where(g, k) + " is a " + (c.isTime() ? "time value" : c.isComplex ? "complex number" : "value") +
               " - astype converts numbers and text");
      return Value(0.0);
    } else {
      nums[k] = c.number;
    }
  }

  if (type == "bool") {
    if (scalar)
      return Value::boolean(nums.empty() ? false : nums[0] != 0);
    if (g.shape.size() == 2 && g.shape[0] * g.shape[1] == 0)
      return x;
    // Typed bool tensor, storage order (column-major pages).
    std::vector<Value> cells;
    cells.reserve(nums.size());
    for (double d : nums)
      cells.push_back(Value::boolean(d != 0)); // nan counts as true, as in NumPy
    return rebuild(x, g.shape, cells);
  }

  // A numeric source: the type functions (int8(), float32(), ...) do the
  // conversion with their own rules (rounding, clipping, typed storage).
  Value source = anyText ? (scalar ? Value(nums.empty() ? 0.0 : nums[0]) : packedLike(x, g.shape, nums)) : x;
  std::string fn = type == "double" ? "float64" : type;
  if (type == "float8") {
    // e4m3 saturates: anything beyond +-448 becomes +-448 (float8() alone
    // makes it nan).
    if (scalar) {
      double d = source.number;
      if (std::isfinite(d) || std::isinf(d))
        d = std::max(-448.0, std::min(448.0, d));
      source = Value(d);
    } else {
      for (double &d : nums)
        if (!std::isnan(d))
          d = std::max(-448.0, std::min(448.0, d));
      source = packedLike(x, g.shape, nums);
    }
  }
  const unsigned long before = nc::errorlines::count();
  Value r = callBuiltin(fn, {source});
  if (nc::errorlines::count() != before || !g_lastBuiltinFound)
    ctx.failSilently();
  return r;
}

// ---- to_time ----------------------------------------------------------------

// Reads `t` with a layout of yyyy MM dd HH mm ss (any other character must be
// there as it is; ss may have a fraction). False when it does not fit.
bool readLayout(const std::string &t, const std::string &layout, double parts[6]) {
  parts[0] = 1970;
  parts[1] = 1;
  parts[2] = 1;
  parts[3] = parts[4] = parts[5] = 0;
  size_t i = 0, p = 0;
  auto digits = [&](size_t minD, size_t maxD, double &out) {
    size_t n = 0;
    double v = 0;
    while (i < t.size() && n < maxD && std::isdigit(static_cast<unsigned char>(t[i]))) {
      v = v * 10 + (t[i] - '0');
      i++;
      n++;
    }
    out = v;
    return n >= minD;
  };
  while (p < layout.size()) {
    if (layout.compare(p, 4, "yyyy") == 0) {
      if (!digits(4, 4, parts[0]))
        return false;
      p += 4;
    } else if (layout.compare(p, 2, "MM") == 0 || layout.compare(p, 2, "dd") == 0 ||
               layout.compare(p, 2, "HH") == 0 || layout.compare(p, 2, "mm") == 0) {
      const char k = layout[p];
      const int slot = k == 'M' ? 1 : k == 'd' ? 2 : k == 'H' ? 3 : 4;
      if (!digits(1, 2, parts[slot]))
        return false;
      p += 2;
    } else if (layout.compare(p, 2, "ss") == 0) {
      if (!digits(1, 2, parts[5]))
        return false;
      if (i < t.size() && t[i] == '.') { // a fraction of a second
        i++;
        double scale = 0.1;
        size_t n = 0;
        while (i < t.size() && std::isdigit(static_cast<unsigned char>(t[i]))) {
          parts[5] += (t[i] - '0') * scale;
          scale /= 10;
          i++;
          n++;
        }
        if (n == 0)
          return false;
      }
      p += 2;
    } else {
      if (i >= t.size() || t[i] != layout[p])
        return false;
      i++;
      p++;
    }
  }
  return i == t.size();
}

Value toTimeImpl(const Args &a, CallContext &ctx) {
  if (!a[1].isText) {
    ctx.fail("the layout must be text, e.g. \"yyyy-MM-dd\" or \"iso\"");
    return Value(0.0);
  }
  const std::string layout = a[1].text();
  std::string zoneName;
  if (a.size() > 2) {
    if (!a[2].isText) {
      ctx.fail("the time zone must be text, e.g. \"UTC\" or \"Asia/Kolkata\"");
      return Value(0.0);
    }
    zoneName = a[2].text();
  }
  const nctime::TimeZone *zone = nullptr;
  std::string err;
  if (!nctime::findZone(zoneName, zone, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  std::string low = layout;
  for (char &c : low)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  const bool iso = low == "iso" || low == "iso 8601" || low == "iso8601";
  if (!iso && layout.find("yyyy") == std::string::npos && layout.find("HH") == std::string::npos) {
    ctx.fail("the layout \"" + layout +
             "\" has no yyyy or HH - write it with yyyy MM dd HH mm ss, e.g. \"dd/MM/yyyy\", or "
             "\"iso\"");
    return Value(0.0);
  }
  auto one = [&](const Value &c, size_t k, const Grid *g, bool &bad) -> Value {
    if (c.isTimestamp())
      return c;
    if (!c.isText) {
      if (isMissingCell(c, true))
        return Value(missingNumber());
      bad = true;
      ctx.fail((g ? where(*g, k) : std::string("the value")) + " is not text - to_time reads dates written as text");
      return Value(0.0);
    }
    std::string t = c.text();
    while (!t.empty() && std::isspace(static_cast<unsigned char>(t.back())))
      t.pop_back();
    size_t b = 0;
    while (b < t.size() && std::isspace(static_cast<unsigned char>(t[b])))
      b++;
    t = t.substr(b);
    int64_t ns = 0;
    std::string why;
    if (iso) {
      if (!t.empty() && nctime::parseTimestamp(t, zone, ns, why))
        return Value::timestamp(ns);
      return Value(missingNumber());
    }
    double p[6];
    if (!readLayout(t, layout, p))
      return Value(missingNumber()); // a text that does not fit is missing
    if (!nctime::fromLocalParts(p[0], p[1], p[2], p[3], p[4], p[5], zone, ns, why))
      return Value(missingNumber()); // 31/02/2026, 25:00 ... is missing too
    return Value::timestamp(ns);
  };
  bool bad = false;
  if (!(a[0].isArray || a[0].isMatrix)) {
    Value r = one(a[0], 0, nullptr, bad);
    return bad ? Value(0.0) : r;
  }
  Grid g = numpy::ndx::gridOf(a[0]);
  for (size_t k = 0; k < g.cells.size() && !bad; k++)
    g.cells[k] = one(g.cells[k], k, &g, bad);
  if (bad)
    return Value(0.0);
  return rebuild(a[0], g.shape, g.cells);
}

} // namespace

void registerProcessText(OpsRegistry &reg) {
  addSpec(reg, "astype", 2, 2, "astype(X, type)", "values as another type", kNDArgs, astypeImpl);
  // P7.2: bool(A) of a matrix of numbers gave ONE value (is_true of the
  // whole matrix); now each element, as int8(A), float32(A) ... do. A
  // single value and text keep the old bool() (logical_builtin.cpp).
  addSpec(reg, "bool", 1, 1, "bool(X)", "true / false, element by element", kNDArgs,
          [](const Args &a, CallContext &ctx) { return astypeImpl({a[0], Value(std::string("bool"))}, ctx); },
          [](const Args &a) { return a.size() == 1 && (a[0].isArray || a[0].isMatrix) && !anyTextCell(a[0]); });

  addSpec(reg, "lower", 1, 1, "lower(T)", "lower case, every text", kNDArgs,
          [](const Args &a, CallContext &ctx) { return caseImpl(a, ctx, 0); }, textContainer);
  addSpec(reg, "upper", 1, 1, "upper(T)", "upper case, every text", kNDArgs,
          [](const Args &a, CallContext &ctx) { return caseImpl(a, ctx, 1); }, textContainer);
  addSpec(reg, "swapcase", 1, 1, "swapcase(T)", "lower and upper case swapped", kNDArgs,
          [](const Args &a, CallContext &ctx) { return caseImpl(a, ctx, 2); });
  addSpec(reg, "lstrip", 1, 2, "lstrip(T[, chars])", "characters removed at the start", kNDArgs,
          [](const Args &a, CallContext &ctx) { return stripImpl(a, ctx, true); });
  addSpec(reg, "rstrip", 1, 2, "rstrip(T[, chars])", "characters removed at the end", kNDArgs,
          [](const Args &a, CallContext &ctx) { return stripImpl(a, ctx, false); });
  addSpec(reg, "replace", 3, 3, "replace(T, old, new)", "every occurrence replaced, every text",
          kNDArgs, replaceImpl, textContainer);
  addSpec(reg, "split", 2, 2, "split(T, sep)", "every text cut, one row each", 0, splitImpl,
          textContainer);
  addSpec(reg, "unique", 2, 2, "unique(X, \"stable\")", "distinct values, first seen first",
          kNDArgs, uniqueImpl,
          [](const Args &a) { return a.size() == 2 && a[1].isText; });
  addSpec(reg, "to_time", 2, 3, "to_time(T, layout[, zone])", "texts read as dates / times",
          kNDArgs, toTimeImpl);
}

} // namespace process
} // namespace ops
} // namespace nc
