#pragma once
// runtime/interpreter/ops/matrix/matrix_index.h
//
// The one implementation of matrix indexing, slicing, slice assignment and
// matrix-literal building. Shared by the tree-walker (parser_factor.cpp,
// parser_exec_stmt.cpp) and the JIT bridge (value_bridge.cpp), so both
// paths give identical results and identical error messages.
//
// Indexing rules (0-based, MATLAB-like shapes):
//   A[m,n]            one element
//   A[m,:]  A[m,]  A[m]   row m            (1 x cols matrix)
//   A[:,n]  A[,n]         column n         (rows x 1 matrix)
//   A[a:b, c:d]       rows a..b, columns c..d - the stop is INCLUDED
//   A[a:s:b]          start:step:stop, e.g. A[0:2:8]
//   A[5:, :3]         an open end runs to the first/last index
//   A[-1]             negative indices count from the end (-1 = last)
//   A[::]  A[:]  A[:,:]   the whole matrix (a copy)
//   For a vector (1 x N or N x 1), one index picks ELEMENTS: v[2], v[1:3].
//
// Assignment uses the same selections. The right-hand side may be a single
// value (written into every selected cell), a matrix of exactly the
// selection's size, or - for a selection that is one row or one column - any
// vector with the right number of elements. Writing past the end grows the
// matrix (new cells are 0), and assigning by index to an undefined name
// creates the matrix, as in MATLAB.

#include <string>
#include <vector>

#include "../../core/value.h"

struct MatIndexKey {
  enum Kind { All, Scalar, Range };
  Kind kind = All;
  double scalar = 0.0; // Scalar
  // Range: any of the three parts may be left out (open end / step 1).
  bool hasStart = false, hasStep = false, hasStop = false;
  double start = 0.0, step = 1.0, stop = 0.0;
};

// True for a 1 x N or N x 1 matrix (including 1 x 1).
bool matIsVectorShape(const Value &v);

// A[keys] on a matrix or an array. `name` is used only in error messages.
// False (with `err` filled, no "Error:" prefix) on any problem.
bool matIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                 Value &out, std::string &err);

// A[keys] = rhs. `target` is the variable's current value when `exists`,
// ignored otherwise (an undefined name becomes a new matrix). On success
// `target` holds the updated value.
bool matIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                 const Value &rhs, const std::string &name, std::string &err);

// Builds the value of a matrix literal from its rows of already-evaluated
// cells: [1,2;3,4]. A cell that is itself a matrix (or an array, taken as a
// row) concatenates - [A, B] side by side, [A; B] stacked; empty matrices
// are skipped, as in MATLAB.
bool matBuildFromCells(const std::vector<std::vector<Value>> &rows, Value &out, std::string &err);

// Matrix transpose of any value: a number stays itself, an array becomes a
// column, a matrix of any cell kind (numbers, complex, text) is flipped.
Value matTransposeValue(const Value &v);

// Elements of a vector-shaped matrix (or an array) as a flat array; any
// other value is returned unchanged.
Value matVectorAsArray(const Value &v);

// An array as a matrix: a 1 x N row, or N x 1 when `asColumn`.
Value matArrayAsMatrix(const Value &v, bool asColumn);

// "2x3" - for error messages.
std::string matShapeText(const Value &v);
