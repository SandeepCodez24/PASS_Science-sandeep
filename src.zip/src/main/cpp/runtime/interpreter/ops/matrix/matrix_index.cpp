// runtime/interpreter/ops/matrix/matrix_index.cpp - see matrix_index.h.
#include "matrix_index.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace {

using Grid = std::vector<std::vector<Value>>;

std::string numText(double x) {
  char buf[40];
  std::snprintf(buf, sizeof buf, "%.15g", x);
  return buf;
}

std::string quoted(const std::string &name) { return name.empty() ? "the value" : "'" + name + "'"; }

// A value that is neither a matrix nor an array.
bool isSingle(const Value &v) { return !v.isMatrix && !v.isArray; }

size_t rowsOf(const Value &v) {
  if (v.isMatrix)
    return v.rows();
  if (v.isArray)
    return v.length() ? 1 : 0;
  return 1;
}

size_t colsOf(const Value &v) {
  if (v.isMatrix)
    return v.rows() ? v.cols() : 0;
  if (v.isArray)
    return v.length();
  return 1;
}

// Element (r, c) of a matrix, an array (taken as one row) or a single value.
Value cellOf(const Value &v, size_t r, size_t c) {
  if (v.isMatrix)
    return v.at(r, c);
  if (v.isArray)
    return v.at(c);
  return v;
}

// t-th element of a vector-shaped matrix or an array.
Value linearOf(const Value &v, size_t t) {
  if (v.isArray)
    return v.at(t);
  if (v.rows() == 1)
    return v.at(0, t);
  return v.at(t, 0);
}

bool wholeIndex(double x, long long &out) {
  if (!std::isfinite(x) || x != std::floor(x))
    return false;
  out = static_cast<long long>(x);
  return true;
}

// Resolves one key against a dimension of length n into a list of
// 0-based positions. `grow` (assignment only) lets positive indices reach
// past the end. `what` is "row", "column" or "element".
bool resolveKey(const MatIndexKey &k, size_t n, bool grow, const char *what,
                const std::string &name, std::vector<size_t> &idx, std::string &err) {
  idx.clear();
  const long long len = static_cast<long long>(n);
  const std::string plural = std::string(what) + "s";

  auto rangeText = [&]() {
    if (n == 0)
      return quoted(name) + " has no " + plural;
    return quoted(name) + " has " + std::to_string(n) + " " + (n == 1 ? std::string(what) : plural) +
           ", indexed 0.." + std::to_string(n - 1) + " (or -1..-" + std::to_string(n) + " from the end)";
  };

  // Normalizes one written index: negative counts from the end.
  auto normalize = [&](double raw, long long &out) -> bool {
    long long i = 0;
    if (!wholeIndex(raw, i)) {
      err = std::string(what) + " index " + numText(raw) + " is not a whole number";
      return false;
    }
    if (i < 0) {
      i += len;
      if (i < 0) {
        err = std::string(what) + " index " + numText(raw) + " is out of range - " + rangeText();
        return false;
      }
    }
    out = i;
    return true;
  };

  auto checkUpper = [&](long long i, double raw) -> bool {
    if (i >= len && !grow) {
      err = std::string(what) + " index " + numText(raw) + " is out of range - " + rangeText();
      return false;
    }
    return true;
  };

  switch (k.kind) {
  case MatIndexKey::All:
    for (size_t i = 0; i < n; i++)
      idx.push_back(i);
    return true;

  case MatIndexKey::Scalar: {
    long long i = 0;
    if (!normalize(k.scalar, i) || !checkUpper(i, k.scalar))
      return false;
    idx.push_back(static_cast<size_t>(i));
    return true;
  }

  case MatIndexKey::Range: {
    long long step = 1;
    if (k.hasStep) {
      if (!wholeIndex(k.step, step)) {
        err = "slice step " + numText(k.step) + " is not a whole number";
        return false;
      }
      if (step == 0) {
        err = "slice step cannot be 0";
        return false;
      }
    }
    long long s = 0, e = 0;
    if (k.hasStart) {
      if (!normalize(k.start, s))
        return false;
    } else {
      s = step > 0 ? 0 : len - 1;
    }
    if (k.hasStop) {
      if (!normalize(k.stop, e))
        return false;
    } else {
      e = step > 0 ? len - 1 : 0;
    }
    const bool empty = step > 0 ? (s > e) : (s < e);
    if (empty)
      return true; // A[5:3] - an empty selection, like MATLAB
    long long hi = std::max(s, e);
    if (!checkUpper(hi, hi == s ? k.start : k.stop))
      return false;
    if (step > 0)
      for (long long i = s; i <= e; i += step)
        idx.push_back(static_cast<size_t>(i));
    else
      for (long long i = s; i >= e; i += step)
        idx.push_back(static_cast<size_t>(i));
    return true;
  }
  }
  return true;
}

Value fromGrid(Grid g) { return Value(std::move(g)); }

} // namespace

bool matIsVectorShape(const Value &v) {
  return v.isMatrix && v.rows() > 0 && (v.rows() == 1 || v.cols() == 1);
}

std::string matShapeText(const Value &v) {
  if (v.isMatrix)
    return std::to_string(v.rows()) + "x" + std::to_string(v.rows() ? v.cols() : 0);
  if (v.isArray)
    return "1x" + std::to_string(v.length());
  return "1x1";
}

Value matVectorAsArray(const Value &v) {
  if (v.isArray || !matIsVectorShape(v))
    return v;
  std::vector<Value> out;
  const size_t n = v.rows() * v.cols();
  out.reserve(n);
  for (size_t t = 0; t < n; t++)
    out.push_back(linearOf(v, t));
  return Value(std::move(out));
}

Value matArrayAsMatrix(const Value &v, bool asColumn) {
  if (!v.isArray)
    return v;
  Grid g;
  if (asColumn) {
    for (size_t i = 0; i < v.length(); i++)
      g.push_back({v.at(i)});
  } else {
    g.push_back(v.elems());
  }
  return fromGrid(std::move(g));
}

Value matTransposeValue(const Value &v) {
  if (isSingle(v))
    return v;
  const size_t R = rowsOf(v), C = colsOf(v);
  if (R == 0 || C == 0)
    return v.isArray ? fromGrid(Grid{}) : v;
  Grid g(C, std::vector<Value>(R));
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < C; c++)
      g[c][r] = cellOf(v, r, c);
  return fromGrid(std::move(g));
}

/* ======================================================================
   Read
   ====================================================================== */

bool matIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                 Value &out, std::string &err) {
  if (keys.empty() || keys.size() > 2) {
    err = quoted(name) + " takes one or two indices inside [ ], got " + std::to_string(keys.size());
    return false;
  }

  // Flat array (e.g. the result of space()): one index, element-wise.
  if (v.isArray) {
    if (keys.size() != 1) {
      err = quoted(name) + " is a 1-D array - use one index, e.g. " +
            (name.empty() ? std::string("x") : name) + "[2]";
      return false;
    }
    std::vector<size_t> idx;
    if (!resolveKey(keys[0], v.length(), false, "element", name, idx, err))
      return false;
    if (keys[0].kind == MatIndexKey::Scalar) {
      out = v.at(idx[0]);
      return true;
    }
    std::vector<Value> sel;
    sel.reserve(idx.size());
    for (size_t i : idx)
      sel.push_back(v.at(i));
    out = Value(std::move(sel));
    return true;
  }

  if (!v.isMatrix) {
    err = quoted(name) + " is not a matrix - only matrices, arrays and dicts can be indexed with [ ]";
    return false;
  }

  const size_t R = v.rows(), C = R ? v.cols() : 0;

  if (keys.size() == 1) {
    // A vector: one index picks elements, keeping the vector's orientation.
    if (matIsVectorShape(v)) {
      const size_t n = R * C;
      std::vector<size_t> idx;
      if (!resolveKey(keys[0], n, false, "element", name, idx, err))
        return false;
      if (keys[0].kind == MatIndexKey::Scalar) {
        out = linearOf(v, idx[0]);
        return true;
      }
      Grid g;
      if (R == 1) {
        g.emplace_back();
        for (size_t i : idx)
          g[0].push_back(v.at(0, i));
        if (idx.empty())
          g.clear();
      } else {
        for (size_t i : idx)
          g.push_back({v.at(i, 0)});
      }
      out = fromGrid(std::move(g));
      return true;
    }

    // A general matrix: one index selects whole rows.
    std::vector<size_t> rows;
    if (!resolveKey(keys[0], R, false, "row", name, rows, err))
      return false;
    Grid g;
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(C);
      for (size_t c = 0; c < C; c++)
        row.push_back(v.at(r, c));
      g.push_back(std::move(row));
    }
    out = fromGrid(std::move(g));
    return true;
  }

  std::vector<size_t> rows, cols;
  if (!resolveKey(keys[0], R, false, "row", name, rows, err) ||
      !resolveKey(keys[1], C, false, "column", name, cols, err))
    return false;

  if (keys[0].kind == MatIndexKey::Scalar && keys[1].kind == MatIndexKey::Scalar) {
    out = v.at(rows[0], cols[0]);
    return true;
  }

  Grid g;
  if (!cols.empty()) {
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(cols.size());
      for (size_t c : cols)
        row.push_back(v.at(r, c));
      g.push_back(std::move(row));
    }
  }
  out = fromGrid(std::move(g));
  return true;
}

/* ======================================================================
   Write
   ====================================================================== */

bool matIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                 const Value &rhs, const std::string &name, std::string &err) {
  if (keys.empty() || keys.size() > 2) {
    err = quoted(name) + " takes one or two indices inside [ ], got " + std::to_string(keys.size());
    return false;
  }
  if (rhs.isDict || rhs.isObject || rhs.isFunctionRef) {
    err = "only numbers, text, arrays and matrices can be stored in a matrix";
    return false;
  }

  const bool rhsSingle = isSingle(rhs);
  const size_t rhsR = rowsOf(rhs), rhsC = colsOf(rhs);
  const size_t rhsN = rhsR * rhsC;
  const bool rhsVector = rhsSingle || rhs.isArray || matIsVectorShape(rhs);

  // ---- flat array target: one index, no growth -------------------------
  if (exists && target.isArray) {
    if (keys.size() != 1) {
      err = quoted(name) + " is a 1-D array - use one index, e.g. " + name + "[2] = value";
      return false;
    }
    std::vector<size_t> idx;
    if (!resolveKey(keys[0], target.length(), false, "element", name, idx, err))
      return false;
    if (!rhsSingle && !(rhsVector && rhsN == idx.size())) {
      err = "cannot assign " + matShapeText(rhs) + " values to " + std::to_string(idx.size()) +
            " element(s) of " + quoted(name);
      return false;
    }
    for (size_t t = 0; t < idx.size(); t++)
      target.setAt(idx[t], rhsSingle ? rhs : linearOf(rhs, t));
    return true;
  }

  if (exists && !target.isMatrix && (target.isText || target.isDict || target.isObject ||
                                     target.isFunctionRef)) {
    err = quoted(name) + " is not a matrix - [ ] assignment with numeric indices needs a matrix";
    return false;
  }

  // A plain number counts as a 1x1 matrix (x = 5; x[0,2] = 7 grows it).
  const bool targetIsMatrix = exists && target.isMatrix;
  const size_t R = targetIsMatrix ? target.rows() : (exists ? 1 : 0);
  const size_t C = targetIsMatrix ? (R ? target.cols() : 0) : (exists ? 1 : 0);
  auto currentCell = [&](size_t r, size_t c) -> Value {
    return targetIsMatrix ? target.at(r, c) : target;
  };

  std::vector<size_t> rows, cols;
  bool linear = false; // one index on a vector (or an empty / new matrix)
  bool rowOrient = true;

  if (keys.size() == 1) {
    const bool vectorTarget = (R == 1 || C == 1) || (R == 0 && C == 0);
    if (vectorTarget) {
      linear = true;
      rowOrient = (R <= 1); // 1xN, 1x1 and empty grow to the right
      const size_t n = R * C;
      std::vector<size_t> idx;
      if (keys[0].kind == MatIndexKey::All && n == 0) {
        for (size_t t = 0; !rhsSingle && t < rhsN; t++)
          idx.push_back(t);
      } else if (!resolveKey(keys[0], n, true, "element", name, idx, err)) {
        return false;
      }
      if (rowOrient) {
        rows = {0};
        cols = idx;
      } else {
        rows = idx;
        cols = {0};
      }
    } else {
      if (!resolveKey(keys[0], R, true, "row", name, rows, err))
        return false;
      for (size_t c = 0; c < C; c++)
        cols.push_back(c);
    }
  } else {
    if (keys[0].kind == MatIndexKey::All && R == 0) {
      for (size_t r = 0; !rhsSingle && r < rhsR; r++)
        rows.push_back(r);
    } else if (!resolveKey(keys[0], R, true, "row", name, rows, err)) {
      return false;
    }
    if (keys[1].kind == MatIndexKey::All && C == 0) {
      for (size_t c = 0; !rhsSingle && c < rhsC; c++)
        cols.push_back(c);
    } else if (!resolveKey(keys[1], C, true, "column", name, cols, err)) {
      return false;
    }
  }

  const size_t selR = linear ? (rowOrient ? 1 : rows.size()) : rows.size();
  const size_t selC = linear ? (rowOrient ? cols.size() : 1) : cols.size();
  if (selR == 0 || selC == 0)
    return true; // empty selection - nothing to write

  // How the right-hand side fills the selection.
  enum class Fill { Broadcast, Exact, Linear } fill;
  if (rhsSingle)
    fill = Fill::Broadcast;
  else if (rhsR == selR && rhsC == selC)
    fill = Fill::Exact;
  else if ((selR == 1 || selC == 1) && rhsVector && rhsN == selR * selC)
    fill = Fill::Linear;
  else {
    err = "cannot assign a " + matShapeText(rhs) + " value to a " + std::to_string(selR) + "x" +
          std::to_string(selC) + " selection of " + quoted(name) +
          " - the sizes must match, or assign a single value";
    return false;
  }

  auto rhsFor = [&](size_t i, size_t j) -> Value {
    switch (fill) {
    case Fill::Broadcast:
      return rhs;
    case Fill::Exact:
      return cellOf(rhs, i, j);
    case Fill::Linear:
      return linearOf(rhs, selR == 1 ? j : i);
    }
    return rhs;
  };

  size_t newR = R, newC = C;
  for (size_t r : rows)
    newR = std::max(newR, r + 1);
  for (size_t c : cols)
    newC = std::max(newC, c + 1);

  const bool rebuild = !targetIsMatrix || newR != R || newC != C;

  if (!rebuild) {
    for (size_t i = 0; i < rows.size(); i++)
      for (size_t j = 0; j < cols.size(); j++)
        target.setAt(rows[i], cols[j], rhsFor(i, j));
    return true;
  }

  Grid g(newR, std::vector<Value>(newC, Value(0.0)));
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < C; c++)
      g[r][c] = currentCell(r, c);
  for (size_t i = 0; i < rows.size(); i++)
    for (size_t j = 0; j < cols.size(); j++)
      g[rows[i]][cols[j]] = rhsFor(i, j);
  target = fromGrid(std::move(g));
  return true;
}

/* ======================================================================
   Matrix literal
   ====================================================================== */

bool matBuildFromCells(const std::vector<std::vector<Value>> &rows, Value &out, std::string &err) {
  bool anyContainer = false;
  for (const auto &row : rows)
    for (const auto &cell : row)
      if (!isSingle(cell))
        anyContainer = true;

  // Plain [1,2;3,4]: every cell one value.
  if (!anyContainer) {
    for (size_t r = 1; r < rows.size(); r++) {
      if (rows[r].size() != rows[0].size()) {
        err = "matrix literal: row " + std::to_string(r + 1) + " has " +
              std::to_string(rows[r].size()) + " value(s) but row 1 has " +
              std::to_string(rows[0].size()) + " - every row needs the same number of values";
        return false;
      }
    }
    out = fromGrid(rows);
    return true;
  }

  // Concatenation: [A, B] side by side, [A; B] stacked.
  Grid result;
  size_t width = 0;
  bool haveWidth = false;
  size_t widthRow = 0;
  for (size_t r = 0; r < rows.size(); r++) {
    size_t height = 0;
    bool haveHeight = false;
    Grid band;
    for (size_t k = 0; k < rows[r].size(); k++) {
      const Value &cell = rows[r][k];
      if (cell.isDict || cell.isObject || cell.isFunctionRef) {
        err = "matrix literal: row " + std::to_string(r + 1) + ", item " + std::to_string(k + 1) +
              " is not a number, text, array or matrix";
        return false;
      }
      const size_t h = rowsOf(cell), w = colsOf(cell);
      if (h == 0 || w == 0)
        continue; // [] items are skipped
      if (!haveHeight) {
        height = h;
        haveHeight = true;
        band.assign(height, {});
      } else if (h != height) {
        err = "matrix literal: row " + std::to_string(r + 1) + " joins items of different heights (" +
              std::to_string(height) + " and " + std::to_string(h) +
              " rows) - [A, B] needs A and B to have the same number of rows";
        return false;
      }
      for (size_t i = 0; i < h; i++)
        for (size_t j = 0; j < w; j++)
          band[i].push_back(cellOf(cell, i, j));
    }
    if (!haveHeight)
      continue;
    const size_t w = band[0].size();
    if (!haveWidth) {
      width = w;
      haveWidth = true;
      widthRow = r;
    } else if (w != width) {
      err = "matrix literal: row " + std::to_string(r + 1) + " is " + std::to_string(w) +
            " column(s) wide but row " + std::to_string(widthRow + 1) + " is " +
            std::to_string(width) + " - [A; B] needs A and B to have the same number of columns";
      return false;
    }
    for (auto &line : band)
      result.push_back(std::move(line));
  }
  out = fromGrid(std::move(result));
  return true;
}
