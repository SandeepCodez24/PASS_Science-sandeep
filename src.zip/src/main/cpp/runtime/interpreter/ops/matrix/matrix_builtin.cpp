#include "matrix_builtin.h"
#include "matrix.h"

#include <functional>
#include <iostream>
#include <unordered_map>

Value matrixBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= BASIC MATRIX OPS ================= */

      {"rank",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("rank", 1))
           return Value();
         return rank(a[0]);
       }},

      {"transpose",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("transpose", 1))
           return Value();
         return MatrixTranspose(a[0]);
       }},

      {"conjugate",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("conjugate", 1))
           return Value();
         return conjugate(a[0]);
       }},

      {"pseudo_inverse",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("pseudo_inverse", 1))
           return Value();
         return pseudo_inverse(a[0]);
       }},

      {"det",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("det", 1))
           return Value();
         return det(a[0]);
       }},

      {"adj",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("adj", 1))
           return Value();
         return adj(a[0]);
       }},

      {"had_prod",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("had_prod", 2))
           return Value();
         return had_prod(a[0], a[1]);
       }},

      {"inv",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv", 1))
           return Value();
         return inv(a[0]);
       }},

      {"Norm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Norm", 1))
           return Value();
         return Norm(a[0]);
       }},

      {"ElementWise",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("ElementWise", 2))
           return Value();
         return ElementWise(a[0], a[1]);
       }},
      {"Trace",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Trace", 1))
           return Value();
         return Trace(a[0]);
       }},

      {"onlyRows",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("onlyRows", 1))
           return Value();
         return OnlyRows(a[0]);
       }},
      {"onlyCols",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("onlyCols", 1))
           return Value();
         return OnlyCols(a[0]);
       }},
      {"Rows",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Rows", 1))
           return Value();
         return OnlyRows(a[0]);
       }},
      {"Cols",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Cols", 1))
           return Value();
         return OnlyCols(a[0]);
       }},

      /* ================= SPECIAL MATRICES ================= */

      {"diag",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("diag", 1))
           return Value();
         return diag(a[0]);
       }},

      {"upper_triangular",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("upper_triangular", 1))
           return Value();
         return upper_triangular(a[0]);
       }},

      {"Lower_Triangular",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Lower_Triangular", 1))
           return Value();
         return Lower_Triangular(a[0]);
       }},

      {"zero_matrix",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("zero_matrix", 1))
           return Value();
         return zero_matrix(a[0]);
       }},

      {"full_rank_matrix",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("full_rank_matrix", 1))
           return Value();
         return full_rank_matrix(a[0]);
       }},

      {"singular_matrix",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("singular_matrix", 1))
           return Value();
         return singular_matrix(a[0]);
       }},

      {"pd_matrix",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("pd_matrix", 1))
           return Value();
         return pd_matrix(a[0]);
       }},

      {"nd_matrix",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("nd_matrix", 1))
           return Value();
         return nd_matrix(a[0]);
       }},

      {"unit_matrix",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("unit_matrix", 1))
           return Value();
         return unit_matrix(a[0]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown matrix function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}