#include "matrix_arithmetic.h"
#include "matrix.h"
#include <iostream>

using namespace Eigen;

/* ================= MATRIX + MATRIX ================= */

Value matrix_add(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: matrix add requires same dimensions" << " ("
              << m1.rows() << "x" << m1.cols() << ") vs (" << m2.rows() << "x"
              << m2.cols() << ")\n";
    return Value(0);
  }

  MatrixXd r = m1 + m2;
  return toValue(r);
}

/* ================= MATRIX - MATRIX ================= */

Value matrix_sub(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: matrix sub requires same dimensions" << " ("
              << m1.rows() << "x" << m1.cols() << ") vs (" << m2.rows() << "x"
              << m2.cols() << ")\n";
    return Value(0);
  }

  MatrixXd r = m1 - m2;
  return toValue(r);
}

/* ================= MATRIX * MATRIX ================= */

Value matrix_mul(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);

  /* dimension safety */
  if (m1.cols() != m2.rows()) {
    std::cerr << "Error: matrix mul requires lhs.cols == rhs.rows" << " ("
              << m1.rows() << "x" << m1.cols() << ") vs (" << m2.rows() << "x"
              << m2.cols() << ")\n";
    return Value(0);
  }

  MatrixXd r = m1 * m2;
  return toValue(r);
}

/* ================= MATRIX / MATRIX ================= */

Value matrix_div(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);

  /* B must be square */
  if (m2.rows() != m2.cols()) {
    std::cerr << "Error: matrix division requires rhs to be square\n";
    return Value(0);
  }
  if (m1.cols() != m2.rows()) {
    std::cerr << "Error: matrix division requires lhs.cols == rhs.rows\n";
    return Value(0);
  }

  /* rhs must be invertible - scale-invariant check, see matrix.h's
     isEffectivelySingular() comment for why a raw determinant threshold is
     wrong (a well-conditioned but uniformly-scaled-down matrix has a tiny
     determinant purely from that scaling, not from being near-singular) */
  if (isEffectivelySingular(m2)) {
    std::cerr << "Error: matrix division requires rhs to be invertible\n";
    return Value(0);
  }

  MatrixXd r = m1 * m2.inverse();
  return toValue(r);
}

/* ================= SCALAR + MATRIX ================= */

Value scalar_matrix_add(Value s, Value m) {
  int r = m.rows();
  int c = m.cols();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(s.number + m.numAt(i, j));

  return Value(res);
}

/* ================= MATRIX + SCALAR ================= */

Value matrix_scalar_add(Value m, Value s) {
  int r = m.rows();
  int c = m.cols();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(m.numAt(i, j) + s.number);

  return Value(res);
}

/* ================= SCALAR - MATRIX ================= */

Value scalar_matrix_sub(Value s, Value m) {
  int r = m.rows();
  int c = m.cols();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(s.number - m.numAt(i, j));

  return Value(res);
}

/* ================= MATRIX - SCALAR ================= */

Value matrix_scalar_sub(Value m, Value s) {
  int r = m.rows();
  int c = m.cols();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(m.numAt(i, j) - s.number);

  return Value(res);
}

/* ================= SCALAR * MATRIX ================= */

Value scalar_matrix_mul(Value s, Value m) {
  int r = m.rows();
  int c = m.cols();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(s.number * m.numAt(i, j));

  return Value(res);
}

/* ================= SCALAR / MATRIX ================= */

Value scalar_matrix_div(Value s, Value m) {
  MatrixXd mat = toEigenMat(m);

  /* matrix must be square */

  if (mat.rows() != mat.cols()) {
    std::cerr << "Error: scalar / matrix requires a square matrix\n";
    return Value(0);
  }

  /* inverse must exist - same scale-invariant check as matrix_div() above,
     replacing the old exact `== 0` comparison (which only ever caught an
     EXACTLY zero determinant, missing anything merely near-singular from
     floating-point rounding, while ALSO being vulnerable to the same
     scale-dependence problem as every other determinant-threshold check
     in this file) */
  if (isEffectivelySingular(mat)) {
    std::cerr << "Error: scalar / matrix requires the matrix to be invertible\n";
    return Value(0);
  }

  MatrixXd r = s.number * mat.inverse();

  return toValue(r);
}

/* ================= MATRIX / SCALAR ================= */

Value matrix_scalar_div(Value m, Value s) {
  int r = m.rows();
  int c = m.cols();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(m.numAt(i, j) / s.number);

  return Value(res);
}
// matrix_pow() removed - see matrix_arithmetic.h's comment for why.
