#include "matrix_arithmetic.h"
#include "matrix.h"
#include <iostream>

using namespace Eigen;

/* ================= MATRIX + MATRIX ================= */

Value matrix_add(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: matrix add requires same dimensions" << " ("
              << m1.rows() << "x" << m1.cols() << ") vs (" << m2.rows() << "x"
              << m2.cols() << ")\n";
    return Value(0);
  }

  MatrixXd r = m1 + m2;
  return toValue(r);
}

/* ================= MATRIX - MATRIX ================= */

Value matrix_sub(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: matrix sub requires same dimensions" << " ("
              << m1.rows() << "x" << m1.cols() << ") vs (" << m2.rows() << "x"
              << m2.cols() << ")\n";
    return Value(0);
  }

  MatrixXd r = m1 - m2;
  return toValue(r);
}

/* ================= MATRIX * MATRIX ================= */

Value matrix_mul(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);

  /* dimension safety */
  if (m1.cols() != m2.rows()) {
    std::cerr << "Error: matrix mul requires lhs.cols == rhs.rows" << " ("
              << m1.rows() << "x" << m1.cols() << ") vs (" << m2.rows() << "x"
              << m2.cols() << ")\n";
    return Value(0);
  }

  MatrixXd r = m1 * m2;
  return toValue(r);
}

/* ================= MATRIX / MATRIX ================= */

Value matrix_div(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (m1.rows() == 0 || m1.cols() == 0 || m2.rows() == 0 || m2.cols() == 0)
    return Value(0);

  /* B must be square */
  if (m2.rows() != m2.cols()) {
    std::cerr << "Error: matrix division requires rhs to be square\n";
    return Value(0);
  }
  if (m1.cols() != m2.rows()) {
    std::cerr << "Error: matrix division requires lhs.cols == rhs.rows\n";
    return Value(0);
  }

  /* determinant must not be zero (tolerance) */
  const double tol = 1e-12;
  double det = m2.determinant();
  if (std::abs(det) <= tol) {
    std::cerr << "Error: matrix division requires rhs to be invertible\n";
    return Value(0);
  }

  MatrixXd r = m1 * m2.inverse();
  return toValue(r);
}

/* ================= SCALAR + MATRIX ================= */

Value scalar_matrix_add(Value s, Value m) {
  int r = m.matrix.size();
  int c = m.matrix[0].size();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(s.number + m.matrix[i][j].number);

  return Value(res);
}

/* ================= MATRIX + SCALAR ================= */

Value matrix_scalar_add(Value m, Value s) {
  int r = m.matrix.size();
  int c = m.matrix[0].size();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(m.matrix[i][j].number + s.number);

  return Value(res);
}

/* ================= SCALAR - MATRIX ================= */

Value scalar_matrix_sub(Value s, Value m) {
  int r = m.matrix.size();
  int c = m.matrix[0].size();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(s.number - m.matrix[i][j].number);

  return Value(res);
}

/* ================= MATRIX - SCALAR ================= */

Value matrix_scalar_sub(Value m, Value s) {
  int r = m.matrix.size();
  int c = m.matrix[0].size();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(m.matrix[i][j].number - s.number);

  return Value(res);
}

/* ================= SCALAR * MATRIX ================= */

Value scalar_matrix_mul(Value s, Value m) {
  int r = m.matrix.size();
  int c = m.matrix[0].size();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(s.number * m.matrix[i][j].number);

  return Value(res);
}

/* ================= SCALAR / MATRIX ================= */

Value scalar_matrix_div(Value s, Value m) {
  MatrixXd mat = toEigenMat(m);

  /* matrix must be square */

  if (mat.rows() != mat.cols())
    return Value(0);

  /* inverse must exist */

  if (mat.determinant() == 0)
    return Value(0);

  MatrixXd r = s.number * mat.inverse();

  return toValue(r);
}

/* ================= MATRIX / SCALAR ================= */

Value matrix_scalar_div(Value m, Value s) {
  int r = m.matrix.size();
  int c = m.matrix[0].size();

  std::vector<std::vector<Value>> res(r, std::vector<Value>(c));

  for (int i = 0; i < r; i++)
    for (int j = 0; j < c; j++)
      res[i][j] = Value(m.matrix[i][j].number / s.number);

  return Value(res);
}
Value matrix_pow(Value m, Value n) {
  MatrixXd mat = toEigenMat(m);

  /* must be square */
  if (mat.rows() == 0 || mat.cols() == 0 || mat.rows() != mat.cols())
    return Value(0);

  const double tol = 1e-12;

  // Reject non-integer powers.
  double nd = n.number;
  double rint = std::round(nd);
  if (std::abs(nd - rint) > tol)
    return Value(0);

  int p = (int)rint;

  // n == 0 => I
  if (p == 0)
    return toValue(MatrixXd::Identity(mat.rows(), mat.cols()));

  // n == -1 => inverse (invertibility check with tolerance)
  if (p == -1) {
    if (std::abs(mat.determinant()) <= tol)
      return Value(0);
    return toValue(mat.inverse());
  }

  // Reject n < -1
  if (p < -1)
    return Value(0);

  // n > 0
  MatrixXd acc = mat;
  for (int i = 1; i < p; i++)
    acc = acc * mat;
  return toValue(acc);
}
