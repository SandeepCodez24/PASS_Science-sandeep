#pragma once

#include "../../core/value.h"
#include <string>
#include <vector>


Value matrixBuiltin(const std::string &name, const std::vector<Value> &args);