#include "matrix.h"
#include "matrix_arithmetic.h"
#include "matrix_index.h"
#include "../../builtins/builtins.h"
#include <Eigen/Dense>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <random>
#include <string>

using namespace Eigen;

/* ================= MATRIX VALIDATION ================= */

static bool invalidMatrix(const MatrixXd &m) {
  return (m.rows() == 0 || m.cols() == 0);
}

bool isEffectivelySingular(const MatrixXd &m) {
  if (m.rows() != m.cols())
    return true; // not even square - never invertible
  if (m.rows() == 0)
    return true;
  Eigen::JacobiSVD<MatrixXd> svd(m);
  const auto &sv = svd.singularValues();
  if (sv.size() == 0)
    return true;
  double maxSV = sv.maxCoeff();
  if (maxSV == 0.0)
    return true; // the all-zero matrix
  double tol = std::numeric_limits<double>::epsilon() * std::max(m.rows(), m.cols()) * maxSV;
  return sv.minCoeff() <= tol;
}

/* ================= VALUE → EIGEN ================= */

MatrixXd toEigenMat(Value v) {
  if (v.isMatrix) {
    int rows = v.rows();
    if (rows == 0)
      return MatrixXd(0, 0);

    int cols = v.cols();
    // All-numeric matrix: its buffer is already in Eigen's own layout.
    if (v.isPacked())
      return Eigen::Map<const MatrixXd>(v.packedData(), rows, cols);

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.numAt(i, j);

    return m;
  }

  if (v.length() != 0 && v.at(0).isArray) {
    int rows = v.length();
    int cols = v.at(0).length();

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.at(i).numAt(j);

    return m;
  }

  // Flat array: treat as a column vector (n x 1).
  int size = v.length();
  if (size == 0)
    return MatrixXd(0, 0);

  MatrixXd m(size, 1);
  for (int i = 0; i < size; i++)
    m(i, 0) = v.numAt(i);

  return m;
}

/* ================= EIGEN → VALUE ================= */

Value toValue(MatrixXd m) {
  if (m.rows() > 0 && m.cols() > 0)
    return Value::packedMatrix(m.data(), m.rows(), m.cols());

  std::vector<std::vector<Value>> mat;

  for (int i = 0; i < m.rows(); i++) {
    std::vector<Value> row;

    for (int j = 0; j < m.cols(); j++)
      row.push_back(Value(m(i, j)));

    mat.push_back(row);
  }

  return Value(mat);
}

/* ================= COMPLEX CONVERSIONS ================= */

MatrixXcd toEigenCMat(const Value &v) {
  if (!v.isMatrix || v.rows() == 0 || v.cols() == 0)
    return MatrixXcd(0, 0);

  int rows = v.rows(), cols = v.cols();
  if (v.isPackedComplex())
    return Eigen::Map<const MatrixXcd>(v.packedComplexData(), rows, cols);

  MatrixXcd m(rows, cols);
  for (int i = 0; i < rows; i++) {
    if ((int)v.rowLength(i) != cols)
      return MatrixXcd(0, 0);
    for (int j = 0; j < cols; j++)
      m(i, j) = v.cnumAt(i, j);
  }
  return m;
}

Value toValueC(const MatrixXcd &m) {
  if (m.rows() == 0 || m.cols() == 0)
    return Value(std::vector<std::vector<Value>>{});
  Value result = Value::packedComplexMatrix(m.data(), m.rows(), m.cols());
  result.narrowIfReal();
  return result;
}

// Elementwise product of two complex (or mixed) matrices, for had_prod()
// and ElementWise() below.
static Value complexHadamard(const char *fnName, const Value &a, const Value &b) {
  MatrixXcd m1 = toEigenCMat(a);
  MatrixXcd m2 = toEigenCMat(b);

  if (m1.size() == 0 || m2.size() == 0) {
    std::cerr << "Error: " << fnName << " requires two non-empty matrices\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: " << fnName << " requires same dimensions (" << m1.rows() << "x"
              << m1.cols() << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  MatrixXcd r = m1.array() * m2.array();
  return toValueC(r);
}

/* ================= OPERATIONS ================= */

Value MatrixTranspose(Value a) {
  // Plain transpose: a complex matrix is not conjugated (use conj(A)').
  if (a.hasComplex()) {
    MatrixXcd cm = toEigenCMat(a);
    if (cm.size() == 0) {
      std::cerr << "Error: transpose requires a non-empty matrix\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }
    MatrixXcd t = cm.transpose();
    return toValueC(t);
  }
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: transpose requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return toValue(m.transpose());
}

Value det(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    // Determinant is undefined for a non-square matrix - returning 0 used
    // to be silent, indistinguishable from "this square matrix genuinely
    // has determinant 0" (i.e. singular). Reporting it directly avoids
    // that ambiguity.
    std::cerr << "Error: det requires a non-empty square matrix (got "
              << m.rows() << "x" << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return Value(m.determinant());
}

Value rank(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: rank requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return Value(m.fullPivLu().rank());
}

Value inv(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: inv requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  if (isEffectivelySingular(m)) {
    std::cerr << "Error: matrix is singular (not invertible)\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return toValue(m.inverse());
}

Value had_prod(Value a, Value b) {
  if (a.hasComplex() || b.hasComplex())
    return complexHadamard("had_prod", a, b);
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2)) {
    std::cerr << "Error: had_prod requires two non-empty matrices\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: had_prod requires same dimensions (" << m1.rows() << "x" << m1.cols()
              << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return toValue(m1.array() * m2.array());
}

Value pseudo_inverse(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: pinv requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // SVD-based Moore-Penrose pseudo-inverse.
  // pinv(A) = V * S^+ * U^T where A = U * S * V^T
  // Eigen 5: thin U/V are requested as a compile-time template option; the
  // old runtime form svd(m, ComputeThinU | ComputeThinV) is deprecated.
  Eigen::JacobiSVD<MatrixXd, Eigen::ComputeThinU | Eigen::ComputeThinV> svd(m);
  const auto &singular = svd.singularValues();

  // Tolerance for treating singular values as zero.
  // tol = eps * max(m,n) * maxSingular
  const double eps = std::numeric_limits<double>::epsilon();
  double maxSingular = 0.0;
  if (singular.size() > 0) {
    maxSingular = singular.maxCoeff();
  }
  const double tol = eps * std::max(m.rows(), m.cols()) * maxSingular;

  MatrixXd Splus = MatrixXd::Zero(singular.size(), singular.size());

  for (int i = 0; i < singular.size(); ++i) {
    if (singular(i) > tol) {
      Splus(i, i) = 1.0 / singular(i);
    }
  }

  MatrixXd pinv = svd.matrixV() * Splus * svd.matrixU().transpose();
  return toValue(pinv);
}

Value adj(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: adj requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  const int n = (int)m.rows();
  // Adjugate matrix: adj(A) = C^T where C_ij are cofactors.
  // We compute cofactors directly to avoid unstable determinant/inverse checks.
  MatrixXd adjMat(n, n);
  adjMat.setZero();

  if (n == 1) {
    adjMat(0, 0) = 1.0;
    return toValue(adjMat);
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      // Minor by removing row i and col j.
      MatrixXd minor(n - 1, n - 1);
      int r = 0;
      for (int rr = 0; rr < n; ++rr) {
        if (rr == i)
          continue;
        int c = 0;
        for (int cc = 0; cc < n; ++cc) {
          if (cc == j)
            continue;
          minor(r, c) = m(rr, cc);
          ++c;
        }
        ++r;
      }

      double detMinor = minor.determinant();
      double sign = ((i + j) % 2 == 0) ? 1.0 : -1.0;
      double cofactor = sign * detMinor;
      // adj(A) = C^T => adj(j,i) = C(i,j)
      adjMat(j, i) = cofactor;
    }
  }

  return toValue(adjMat);
}

Value Norm(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: matrix_norm requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  double sum = 0;
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < m.cols(); j++)
      sum += m(i, j) * m(i, j);

  return Value(std::sqrt(sum));
}

Value MatrixNormOrd(Value a, Value ord) {
  MatrixXcd m = a.hasComplex() ? toEigenCMat(a) : MatrixXcd(toEigenMat(a).cast<std::complex<double>>());
  if (m.size() == 0) {
    std::cerr << "Error: matrix_norm requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  MatrixXd mag = m.cwiseAbs();
  auto singular = [&]() {
    Eigen::JacobiSVD<MatrixXcd> svd(m);
    return Eigen::VectorXd(svd.singularValues());
  };
  if (ord.isText) {
    if (ord.text() == "fro")
      return Value(m.norm());
    if (ord.text() == "nuc")
      return Value(singular().sum());
    std::cerr << "Error: matrix_norm: ord must be \"fro\", \"nuc\", 1, -1, 2, -2, inf or -inf, "
                 "got \""
              << ord.text() << "\"\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  const double p = ord.number;
  if (p == 1)
    return Value(mag.colwise().sum().maxCoeff());
  if (p == -1)
    return Value(mag.colwise().sum().minCoeff());
  if (p == 2)
    return Value(singular().maxCoeff());
  if (p == -2)
    return Value(singular().minCoeff());
  if (std::isinf(p))
    return Value(p > 0 ? mag.rowwise().sum().maxCoeff() : mag.rowwise().sum().minCoeff());
  std::cerr << "Error: matrix_norm: ord must be \"fro\", \"nuc\", 1, -1, 2, -2, inf or -inf, got "
            << p << "\n";
  g_lastBuiltinFound = false; // stop the statement
  return Value(0);
}

Value diag(Value a) {
  // Diag(n) => n x n diagonal matrix filled with `n` on the diagonal.
  // If a is already a matrix, fall back to extracting its diagonal as a vector.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: diag requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }
    return toValue(MatrixXd::Identity(n, n) * a.number);
  }

  // A row or column vector ([1,2,3] or [1;2;3]) is a list of diagonal
  // entries, exactly like a 1-D array.
  if (a.isMatrix && a.rows() > 0 && (a.rows() == 1 || a.cols() == 1) &&
      a.rows() * a.cols() > 1) {
    std::vector<Value> entries;
    for (size_t r = 0; r < a.rows(); r++)
      for (size_t c = 0; c < a.cols(); c++)
        entries.push_back(a.at(r, c));
    return diag(Value(entries));
  }

  if (!a.isMatrix && a.isArray) {
    // Diag(vector) => diagonal matrix.
    MatrixXd m((int)a.length(), (int)a.length());
    m.setZero();
    for (int i = 0; i < (int)a.length(); i++)
      m(i, i) = a.numAt(i);
    return toValue(m);
  }

  // Only a.isMatrix can reach here (the two conditions above already cover
  // every other combination of isMatrix/isArray - a dead, exact-duplicate
  // third branch used to sit here re-testing the same "scalar" condition
  // the first branch already handles and returns from unconditionally;
  // removed as unreachable, not a behavior change).
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: diag requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // The diagonal of a matrix, as a column (MATLAB's diag(A)).
  int n = static_cast<int>(std::min(m.rows(), m.cols()));
  MatrixXd d(n, 1);
  for (int i = 0; i < n; i++)
    d(i, 0) = m(i, i);
  return toValue(d);
}

Value upper_triangular(Value a) {
  // upper_triangular(n) => generate an n x n upper-triangular matrix.
  // Documented expected form for n=3:
  // [[1,1,1],
  //  [0,1,1],
  //  [0,0,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: upper_triangular requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = i; j < n; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: upper_triangular requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // Mask below diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < i; j++)
      m(i, j) = 0;

  return toValue(m);
}

Value zero_matrix(Value a) {
  // zero_matrix(n) => n x n all-zero matrix.
  // If a is already a matrix, return a same-sized zero matrix.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: zero_matrix requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }
    return toValue(MatrixXd::Zero(n, n));
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: zero_matrix requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return toValue(MatrixXd::Zero(m.rows(), m.cols()));
}

Value Lower_Triangular(Value a) {
  // Lower_Triangular(n) => deterministic n x n lower-triangular matrix.
  // Documented expected form for n=3:
  // [[1,0,0],
  //  [1,1,0],
  //  [1,1,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: lower_triangular requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = 0; j <= i; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: lower_triangular requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // Mask above diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = i + 1; j < m.cols(); j++)
      m(i, j) = 0;

  return toValue(m);
}
Value ElementWise(Value a, Value b) {
  if (a.hasComplex() || b.hasComplex())
    return complexHadamard("element_wise", a, b);
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2)) {
    std::cerr << "Error: element_wise requires two non-empty matrices\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: element_wise requires same dimensions (" << m1.rows() << "x"
              << m1.cols() << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // Element-wise multiplication (Hadamard product).
  MatrixXd r = m1.array() * m2.array();

  return toValue(r);
}

Value full_rank_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: full_rank_matrix requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  int r = m.fullPivLu().rank();
  return Value(r == std::min(m.rows(), m.cols()));
}

Value singular_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: singular_matrix requires a non-empty square matrix (got " << m.rows()
              << "x" << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return Value(isEffectivelySingular(m));
}

Value pd_matrix(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: pd_matrix requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (m.rows() != m.cols()) {
    std::cerr << "Error: pd_matrix requires a square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (!m.isApprox(m.transpose())) {
    std::cerr << "Error: pd_matrix requires a symmetric matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  SelfAdjointEigenSolver<MatrixXd> es(m);

  const double tol = 1e-12;

  return Value(es.eigenvalues().minCoeff() > tol);
}

Value nd_matrix(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: nd_matrix requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (m.rows() != m.cols()) {
    std::cerr << "Error: nd_matrix requires a square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (!m.isApprox(m.transpose())) {
    std::cerr << "Error: nd_matrix requires a symmetric matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  SelfAdjointEigenSolver<MatrixXd> es(m);

  const double tol = 1e-12;

  return Value(es.eigenvalues().maxCoeff() < -tol);
}

Value unit_matrix(Value a) {
  int n = (int)a.number;
  if (n <= 0) {
    std::cerr << "Error: unit_matrix requires a positive size, got " << n << "\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return toValue(MatrixXd::Identity(n, n));
}

/* ---------- zeros / ones ---------- */

namespace {

// Reads one size: a whole number >= 0.
bool readSize(const char *fn, const Value &v, size_t &out) {
  if (v.isText || v.isArray || v.isMatrix || v.isDict || v.isObject || v.isFunctionRef ||
      v.hasComplex() || !std::isfinite(v.number) || v.number != std::floor(v.number) ||
      v.number < 0) {
    std::cerr << "Error: " << fn << ": a size must be a whole number >= 0 - use " << fn
              << "(m) or " << fn << "([m,n])\n";
    return false;
  }
  out = static_cast<size_t>(v.number);
  return true;
}

// The size argument shared by zeros / ones / nexus*: m (an m x m matrix) or
// [m,n] (m x n; a 1x2 / 2x1 matrix or a 2-element array).
bool readShape(const char *fn, const Value &s, size_t &rows, size_t &cols) {
  if (s.isMatrix || s.isArray) {
    const size_t count = s.isArray ? s.length() : s.rows() * (s.rows() ? s.cols() : 0);
    if (count != 2) {
      std::cerr << "Error: " << fn << ": the size [m,n] must have exactly 2 values, got "
                << count << "\n";
      return false;
    }
    Value a = s.isArray ? s.at(0) : s.at(0, 0);
    Value b = s.isArray ? s.at(1) : (s.rows() == 1 ? s.at(0, 1) : s.at(1, 0));
    return readSize(fn, a, rows) && readSize(fn, b, cols);
  }
  if (!readSize(fn, s, rows))
    return false;
  cols = rows;
  return true;
}

// fn(m) -> m x m, fn([m,n]) or fn(m, n) -> m x n, every element `fill`.
Value filledMatrix(const char *fn, const std::vector<Value> &args, double fill) {
  size_t rows = 0, cols = 0;
  bool ok = false;
  if (args.size() == 1) {
    ok = readShape(fn, args[0], rows, cols);
  } else if (args.size() == 2) {
    ok = readSize(fn, args[0], rows) && readSize(fn, args[1], cols);
  } else {
    std::cerr << "Error: " << fn << " expects 1 argument - " << fn << "(m) or " << fn
              << "([m,n]) - got " << args.size() << "\n";
  }
  if (!ok) {
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  if (rows == 0 || cols == 0)
    return Value(std::vector<std::vector<Value>>{}); // empty matrix
  return toValue(MatrixXd::Constant(static_cast<Eigen::Index>(rows),
                                    static_cast<Eigen::Index>(cols), fill));
}

} // namespace

Value zeros(const std::vector<Value> &args) { return filledMatrix("zeros", args, 0.0); }
Value ones(const std::vector<Value> &args) { return filledMatrix("ones", args, 1.0); }

/* ---------- random matrices: the nexus family ----------
   nexus<_shape><_kind>(size[, range])
     size   m (m x m) or [m,n] (m x n)
     range  [a, b] or range(a, b):
              integer / float / uniform  ->  [lower, upper]
              normal                     ->  [mean, SD]
     shape  (none) full,  _UTM upper triangle,  _LTM lower triangle
            (the diagonal is included; the rest is 0)
     kind   (none) whole numbers in [lower, upper], default [-100, 100]
            _float    real numbers in [lower, upper), default [-10, 10]
            _uniform  real numbers in [lower, upper), default [0, 1]
            _normal   normal distribution, default mean 1, SD 1
   nexus_seed(n) makes the following matrices repeatable. */

namespace {

std::mt19937_64 &nexusEngine() {
  static std::mt19937_64 engine{std::random_device{}()};
  return engine;
}

enum class NexusKind { Integer, Float, Uniform, Normal };
enum class NexusShape { Full, Upper, Lower };

// The optional range argument: exactly two real numbers.
bool readRange(const char *fn, const Value &r, double &a, double &b) {
  std::vector<Value> parts;
  if (r.isArray) {
    parts = r.elems();
  } else if (r.isMatrix) {
    for (size_t i = 0; i < r.rows(); i++)
      for (size_t j = 0; j < r.rowLength(i); j++)
        parts.push_back(r.at(i, j));
  }
  bool ok = parts.size() == 2;
  for (const Value &p : parts)
    ok = ok && !p.isText && !p.isArray && !p.isMatrix && !p.isDict && !p.isObject &&
         !p.isComplex && std::isfinite(p.number);
  if (!ok) {
    std::cerr << "Error: " << fn << ": the range must be two numbers, e.g. " << fn
              << "(5, range(50, 75)) or " << fn << "(5, [50, 75])\n";
    return false;
  }
  a = parts[0].number;
  b = parts[1].number;
  return true;
}

Value nexusMatrix(const char *fn, const std::vector<Value> &args, NexusKind kind,
                  NexusShape shape) {
  auto fail = [] {
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  };
  if (args.empty() || args.size() > 2) {
    std::cerr << "Error: " << fn << " expects " << fn << "(size) or " << fn
              << "(size, range) - got " << args.size() << " argument(s)\n";
    return fail();
  }
  size_t rows = 0, cols = 0;
  if (!readShape(fn, args[0], rows, cols))
    return fail();

  double a = 0, b = 0; // [lower, upper], or [mean, SD] for normal
  switch (kind) {
  case NexusKind::Integer: a = -100; b = 100; break;
  case NexusKind::Float: a = -10; b = 10; break;
  case NexusKind::Uniform: a = 0; b = 1; break;
  case NexusKind::Normal: a = 1; b = 1; break;
  }
  if (args.size() == 2 && !readRange(fn, args[1], a, b))
    return fail();

  if (kind == NexusKind::Normal) {
    if (b < 0) {
      std::cerr << "Error: " << fn << ": the standard deviation must not be negative, got " << b
                << " - the range is [mean, SD]\n";
      return fail();
    }
  } else if (a > b) {
    std::cerr << "Error: " << fn << ": the range [lower, upper] needs lower <= upper, got [" << a
              << ", " << b << "]\n";
    return fail();
  }
  if (kind == NexusKind::Integer) {
    a = std::ceil(a);
    b = std::floor(b);
    if (a > b) {
      std::cerr << "Error: " << fn << ": there is no whole number in the range\n";
      return fail();
    }
  }

  if (rows == 0 || cols == 0)
    return Value(std::vector<std::vector<Value>>{});

  std::mt19937_64 &rng = nexusEngine();
  std::uniform_int_distribution<long long> whole(static_cast<long long>(a),
                                                 static_cast<long long>(b));
  std::uniform_real_distribution<double> real(a, b);
  std::normal_distribution<double> normal(a, b);
  auto draw = [&]() -> double {
    switch (kind) {
    case NexusKind::Integer: return static_cast<double>(whole(rng));
    case NexusKind::Normal: return b == 0 ? a : normal(rng);
    default: return a == b ? a : real(rng);
    }
  };

  MatrixXd m = MatrixXd::Zero(static_cast<Eigen::Index>(rows), static_cast<Eigen::Index>(cols));
  for (Eigen::Index i = 0; i < m.rows(); i++)
    for (Eigen::Index j = 0; j < m.cols(); j++) {
      if ((shape == NexusShape::Upper && j < i) || (shape == NexusShape::Lower && j > i))
        continue; // outside the triangle: stays 0
      m(i, j) = draw();
    }
  return toValue(m);
}

} // namespace

Value nexus(const std::string &name, const std::vector<Value> &args) {
  std::string key = name;
  for (char &ch : key)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

  if (key == "nexus_seed") {
    if (args.size() != 1 || args[0].isText || args[0].isArray || args[0].isMatrix ||
        !std::isfinite(args[0].number) || args[0].number != std::floor(args[0].number) ||
        args[0].number < 0) {
      std::cerr << "Error: nexus_seed expects one whole number >= 0, e.g. nexus_seed(42)\n";
      g_lastBuiltinFound = false;
      return Value(0);
    }
    nexusEngine().seed(static_cast<std::uint64_t>(args[0].number));
    return Value(args[0].number);
  }

  NexusShape shape = NexusShape::Full;
  NexusKind kind = NexusKind::Integer;
  std::string rest = key.substr(5); // after "nexus"
  if (rest.rfind("_utm", 0) == 0) {
    shape = NexusShape::Upper;
    rest = rest.substr(4);
  } else if (rest.rfind("_ltm", 0) == 0) {
    shape = NexusShape::Lower;
    rest = rest.substr(4);
  }
  if (rest == "_float")
    kind = NexusKind::Float;
  else if (rest == "_uniform")
    kind = NexusKind::Uniform;
  else if (rest == "_normal")
    kind = NexusKind::Normal;
  else if (!rest.empty()) {
    std::cerr << "Error: Unknown matrix function '" << name << "'\n";
    g_lastBuiltinFound = false;
    return Value(0);
  }
  return nexusMatrix(key.c_str(), args, kind, shape);
}

Value Trace(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: trace requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return Value(m.trace());
}

Value OnlyRows(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> rows;
      for (const auto &item : a.elems()) rows.push_back(item);
      return Value(rows);
    }
    std::cerr << "Error: onlyRows expects a matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value();
  }
  std::vector<Value> rows;
  for (size_t r = 0; r < a.rows(); r++) {
    rows.push_back(Value(a.row(r)));
  }
  return Value(rows);
}

Value OnlyCols(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> cols;
      for (const auto &item : a.elems()) cols.push_back(item);
      return Value(cols);
    }
    std::cerr << "Error: onlyCols expects a matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value();
  }
  if (a.rows() == 0) return Value(std::vector<Value>{});
  size_t colCount = a.cols();
  std::vector<Value> cols;
  for (size_t c = 0; c < colCount; ++c) {
    std::vector<Value> colVec;
    for (size_t r = 0; r < a.rows(); ++r) {
      if (c < a.rowLength(r))
        colVec.push_back(a.at(r, c));
      else
        colVec.push_back(Value(0.0));
    }
    cols.push_back(Value(colVec));
  }
  return Value(cols);
}
/* =====================================================================
   INDEXING, SLICING, SLICE ASSIGNMENT, MATRIX LITERALS
   Declared in matrix_index.h (see there for every rule). Kept in this
   file so no build-file change is needed.
   ===================================================================== */


namespace {

using Grid = std::vector<std::vector<Value>>;

std::string numText(double x) {
  char buf[40];
  std::snprintf(buf, sizeof buf, "%.15g", x);
  return buf;
}

std::string quoted(const std::string &name) { return name.empty() ? "the value" : "'" + name + "'"; }

// A value that is neither a matrix nor an array.
bool isSingle(const Value &v) { return !v.isMatrix && !v.isArray; }

size_t rowsOf(const Value &v) {
  if (v.isMatrix)
    return v.rows();
  if (v.isArray)
    return v.length() ? 1 : 0;
  return 1;
}

size_t colsOf(const Value &v) {
  if (v.isMatrix)
    return v.rows() ? v.cols() : 0;
  if (v.isArray)
    return v.length();
  return 1;
}

// Element (r, c) of a matrix, an array (taken as one row) or a single value.
Value cellOf(const Value &v, size_t r, size_t c) {
  if (v.isMatrix)
    return v.at(r, c);
  if (v.isArray)
    return v.at(c);
  return v;
}

// t-th element of a vector-shaped matrix or an array.
Value linearOf(const Value &v, size_t t) {
  if (v.isArray)
    return v.at(t);
  if (v.rows() == 1)
    return v.at(0, t);
  return v.at(t, 0);
}

bool wholeIndex(double x, long long &out) {
  if (!std::isfinite(x) || x != std::floor(x))
    return false;
  out = static_cast<long long>(x);
  return true;
}

// Resolves one key against a dimension of length n into a list of
// 0-based positions. `grow` (assignment only) lets positive indices reach
// past the end. `what` is "row", "column" or "element".
bool resolveKey(const MatIndexKey &k, size_t n, bool grow, const char *what,
                const std::string &name, std::vector<size_t> &idx, std::string &err) {
  idx.clear();
  const long long len = static_cast<long long>(n);
  const std::string plural = std::string(what) + "s";

  auto rangeText = [&]() {
    if (n == 0)
      return quoted(name) + " has no " + plural;
    return quoted(name) + " has " + std::to_string(n) + " " + (n == 1 ? std::string(what) : plural) +
           ", indexed 0.." + std::to_string(n - 1) + " (or -1..-" + std::to_string(n) + " from the end)";
  };

  // Normalizes one written index: negative counts from the end.
  auto normalize = [&](double raw, long long &out) -> bool {
    long long i = 0;
    if (!wholeIndex(raw, i)) {
      err = std::string(what) + " index " + numText(raw) + " is not a whole number";
      return false;
    }
    if (i < 0) {
      i += len;
      if (i < 0) {
        err = std::string(what) + " index " + numText(raw) + " is out of range - " + rangeText();
        return false;
      }
    }
    out = i;
    return true;
  };

  auto checkUpper = [&](long long i, double raw) -> bool {
    if (i >= len && !grow) {
      err = std::string(what) + " index " + numText(raw) + " is out of range - " + rangeText();
      return false;
    }
    return true;
  };

  switch (k.kind) {
  case MatIndexKey::All:
    for (size_t i = 0; i < n; i++)
      idx.push_back(i);
    return true;

  case MatIndexKey::Scalar: {
    long long i = 0;
    if (!normalize(k.scalar, i) || !checkUpper(i, k.scalar))
      return false;
    idx.push_back(static_cast<size_t>(i));
    return true;
  }

  case MatIndexKey::Range: {
    long long step = 1;
    if (k.hasStep) {
      if (!wholeIndex(k.step, step)) {
        err = "slice step " + numText(k.step) + " is not a whole number";
        return false;
      }
      if (step == 0) {
        err = "slice step cannot be 0";
        return false;
      }
    }
    long long s = 0, e = 0;
    if (k.hasStart) {
      if (!normalize(k.start, s))
        return false;
    } else {
      s = step > 0 ? 0 : len - 1;
    }
    if (k.hasStop) {
      if (!normalize(k.stop, e))
        return false;
    } else {
      e = step > 0 ? len - 1 : 0;
    }
    const bool empty = step > 0 ? (s > e) : (s < e);
    if (empty)
      return true; // A[5:3] - an empty selection, like MATLAB
    long long hi = std::max(s, e);
    if (!checkUpper(hi, hi == s ? k.start : k.stop))
      return false;
    if (step > 0)
      for (long long i = s; i <= e; i += step)
        idx.push_back(static_cast<size_t>(i));
    else
      for (long long i = s; i >= e; i += step)
        idx.push_back(static_cast<size_t>(i));
    return true;
  }
  }
  return true;
}

Value fromGrid(Grid g) { return Value(std::move(g)); }

} // namespace

bool matIsVectorShape(const Value &v) {
  return v.isMatrix && v.rows() > 0 && (v.rows() == 1 || v.cols() == 1);
}

std::string matShapeText(const Value &v) {
  if (v.isMatrix)
    return std::to_string(v.rows()) + "x" + std::to_string(v.rows() ? v.cols() : 0);
  if (v.isArray)
    return "1x" + std::to_string(v.length());
  return "1x1";
}

Value matVectorAsArray(const Value &v) {
  if (v.isArray || !matIsVectorShape(v))
    return v;
  std::vector<Value> out;
  const size_t n = v.rows() * v.cols();
  out.reserve(n);
  for (size_t t = 0; t < n; t++)
    out.push_back(linearOf(v, t));
  return Value(std::move(out));
}

Value matArrayAsMatrix(const Value &v, bool asColumn) {
  if (!v.isArray)
    return v;
  Grid g;
  if (asColumn) {
    for (size_t i = 0; i < v.length(); i++)
      g.push_back({v.at(i)});
  } else {
    g.push_back(v.elems());
  }
  return fromGrid(std::move(g));
}

Value matTransposeValue(const Value &v) {
  if (isSingle(v))
    return v;
  const size_t R = rowsOf(v), C = colsOf(v);
  if (R == 0 || C == 0)
    return v.isArray ? fromGrid(Grid{}) : v;
  Grid g(C, std::vector<Value>(R));
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < C; c++)
      g[c][r] = cellOf(v, r, c);
  return fromGrid(std::move(g));
}

/* ======================================================================
   Read
   ====================================================================== */

bool matIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                 Value &out, std::string &err) {
  if (keys.empty() || keys.size() > 2) {
    err = quoted(name) + " takes one or two indices inside [ ], got " + std::to_string(keys.size());
    return false;
  }

  // Flat array (e.g. the result of space()): one index, element-wise.
  if (v.isArray) {
    if (keys.size() != 1) {
      err = quoted(name) + " is a 1-D array - use one index, e.g. " +
            (name.empty() ? std::string("x") : name) + "[2]";
      return false;
    }
    std::vector<size_t> idx;
    if (!resolveKey(keys[0], v.length(), false, "element", name, idx, err))
      return false;
    if (keys[0].kind == MatIndexKey::Scalar) {
      out = v.at(idx[0]);
      return true;
    }
    std::vector<Value> sel;
    sel.reserve(idx.size());
    for (size_t i : idx)
      sel.push_back(v.at(i));
    out = Value(std::move(sel));
    return true;
  }

  if (!v.isMatrix) {
    err = quoted(name) + " is not a matrix - only matrices, arrays and dicts can be indexed with [ ]";
    return false;
  }

  const size_t R = v.rows(), C = R ? v.cols() : 0;

  if (keys.size() == 1) {
    // A vector: one index picks elements, keeping the vector's orientation.
    if (matIsVectorShape(v)) {
      const size_t n = R * C;
      std::vector<size_t> idx;
      if (!resolveKey(keys[0], n, false, "element", name, idx, err))
        return false;
      if (keys[0].kind == MatIndexKey::Scalar) {
        out = linearOf(v, idx[0]);
        return true;
      }
      Grid g;
      if (R == 1) {
        g.emplace_back();
        for (size_t i : idx)
          g[0].push_back(v.at(0, i));
        if (idx.empty())
          g.clear();
      } else {
        for (size_t i : idx)
          g.push_back({v.at(i, 0)});
      }
      out = fromGrid(std::move(g));
      return true;
    }

    // A general matrix: one index selects whole rows.
    std::vector<size_t> rows;
    if (!resolveKey(keys[0], R, false, "row", name, rows, err))
      return false;
    Grid g;
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(C);
      for (size_t c = 0; c < C; c++)
        row.push_back(v.at(r, c));
      g.push_back(std::move(row));
    }
    out = fromGrid(std::move(g));
    return true;
  }

  std::vector<size_t> rows, cols;
  if (!resolveKey(keys[0], R, false, "row", name, rows, err) ||
      !resolveKey(keys[1], C, false, "column", name, cols, err))
    return false;

  if (keys[0].kind == MatIndexKey::Scalar && keys[1].kind == MatIndexKey::Scalar) {
    out = v.at(rows[0], cols[0]);
    return true;
  }

  Grid g;
  if (!cols.empty()) {
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(cols.size());
      for (size_t c : cols)
        row.push_back(v.at(r, c));
      g.push_back(std::move(row));
    }
  }
  out = fromGrid(std::move(g));
  return true;
}

/* ======================================================================
   Write
   ====================================================================== */

bool matIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                 const Value &rhs, const std::string &name, std::string &err) {
  if (keys.empty() || keys.size() > 2) {
    err = quoted(name) + " takes one or two indices inside [ ], got " + std::to_string(keys.size());
    return false;
  }
  if (rhs.isDict || rhs.isObject || rhs.isFunctionRef) {
    err = "only numbers, text, arrays and matrices can be stored in a matrix";
    return false;
  }

  const bool rhsSingle = isSingle(rhs);
  const size_t rhsR = rowsOf(rhs), rhsC = colsOf(rhs);
  const size_t rhsN = rhsR * rhsC;
  const bool rhsVector = rhsSingle || rhs.isArray || matIsVectorShape(rhs);

  // ---- flat array target: one index, no growth -------------------------
  if (exists && target.isArray) {
    if (keys.size() != 1) {
      err = quoted(name) + " is a 1-D array - use one index, e.g. " + name + "[2] = value";
      return false;
    }
    std::vector<size_t> idx;
    if (!resolveKey(keys[0], target.length(), false, "element", name, idx, err))
      return false;
    if (!rhsSingle && !(rhsVector && rhsN == idx.size())) {
      err = "cannot assign " + matShapeText(rhs) + " values to " + std::to_string(idx.size()) +
            " element(s) of " + quoted(name);
      return false;
    }
    for (size_t t = 0; t < idx.size(); t++)
      target.setAt(idx[t], rhsSingle ? rhs : linearOf(rhs, t));
    return true;
  }

  if (exists && !target.isMatrix && (target.isText || target.isDict || target.isObject ||
                                     target.isFunctionRef)) {
    err = quoted(name) + " is not a matrix - [ ] assignment with numeric indices needs a matrix";
    return false;
  }

  // A plain number counts as a 1x1 matrix (x = 5; x[0,2] = 7 grows it).
  const bool targetIsMatrix = exists && target.isMatrix;
  const size_t R = targetIsMatrix ? target.rows() : (exists ? 1 : 0);
  const size_t C = targetIsMatrix ? (R ? target.cols() : 0) : (exists ? 1 : 0);
  auto currentCell = [&](size_t r, size_t c) -> Value {
    return targetIsMatrix ? target.at(r, c) : target;
  };

  std::vector<size_t> rows, cols;
  bool linear = false; // one index on a vector (or an empty / new matrix)
  bool rowOrient = true;

  if (keys.size() == 1) {
    const bool vectorTarget = (R == 1 || C == 1) || (R == 0 && C == 0);
    if (vectorTarget) {
      linear = true;
      rowOrient = (R <= 1); // 1xN, 1x1 and empty grow to the right
      const size_t n = R * C;
      std::vector<size_t> idx;
      if (keys[0].kind == MatIndexKey::All && n == 0) {
        for (size_t t = 0; !rhsSingle && t < rhsN; t++)
          idx.push_back(t);
      } else if (!resolveKey(keys[0], n, true, "element", name, idx, err)) {
        return false;
      }
      if (rowOrient) {
        rows = {0};
        cols = idx;
      } else {
        rows = idx;
        cols = {0};
      }
    } else {
      if (!resolveKey(keys[0], R, true, "row", name, rows, err))
        return false;
      for (size_t c = 0; c < C; c++)
        cols.push_back(c);
    }
  } else {
    if (keys[0].kind == MatIndexKey::All && R == 0) {
      for (size_t r = 0; !rhsSingle && r < rhsR; r++)
        rows.push_back(r);
    } else if (!resolveKey(keys[0], R, true, "row", name, rows, err)) {
      return false;
    }
    if (keys[1].kind == MatIndexKey::All && C == 0) {
      for (size_t c = 0; !rhsSingle && c < rhsC; c++)
        cols.push_back(c);
    } else if (!resolveKey(keys[1], C, true, "column", name, cols, err)) {
      return false;
    }
  }

  const size_t selR = linear ? (rowOrient ? 1 : rows.size()) : rows.size();
  const size_t selC = linear ? (rowOrient ? cols.size() : 1) : cols.size();
  if (selR == 0 || selC == 0)
    return true; // empty selection - nothing to write

  // How the right-hand side fills the selection.
  enum class Fill { Broadcast, Exact, Linear } fill;
  if (rhsSingle)
    fill = Fill::Broadcast;
  else if (rhsR == selR && rhsC == selC)
    fill = Fill::Exact;
  else if ((selR == 1 || selC == 1) && rhsVector && rhsN == selR * selC)
    fill = Fill::Linear;
  else {
    err = "cannot assign a " + matShapeText(rhs) + " value to a " + std::to_string(selR) + "x" +
          std::to_string(selC) + " selection of " + quoted(name) +
          " - the sizes must match, or assign a single value";
    return false;
  }

  auto rhsFor = [&](size_t i, size_t j) -> Value {
    switch (fill) {
    case Fill::Broadcast:
      return rhs;
    case Fill::Exact:
      return cellOf(rhs, i, j);
    case Fill::Linear:
      return linearOf(rhs, selR == 1 ? j : i);
    }
    return rhs;
  };

  size_t newR = R, newC = C;
  for (size_t r : rows)
    newR = std::max(newR, r + 1);
  for (size_t c : cols)
    newC = std::max(newC, c + 1);

  const bool rebuild = !targetIsMatrix || newR != R || newC != C;

  if (!rebuild) {
    for (size_t i = 0; i < rows.size(); i++)
      for (size_t j = 0; j < cols.size(); j++)
        target.setAt(rows[i], cols[j], rhsFor(i, j));
    return true;
  }

  Grid g(newR, std::vector<Value>(newC, Value(0.0)));
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < C; c++)
      g[r][c] = currentCell(r, c);
  for (size_t i = 0; i < rows.size(); i++)
    for (size_t j = 0; j < cols.size(); j++)
      g[rows[i]][cols[j]] = rhsFor(i, j);
  target = fromGrid(std::move(g));
  return true;
}

/* ======================================================================
   Matrix literal
   ====================================================================== */

bool matBuildFromCells(const std::vector<std::vector<Value>> &rows, Value &out, std::string &err) {
  bool anyContainer = false;
  for (const auto &row : rows)
    for (const auto &cell : row)
      if (!isSingle(cell))
        anyContainer = true;

  // Plain [1,2;3,4]: every cell one value.
  if (!anyContainer) {
    for (size_t r = 1; r < rows.size(); r++) {
      if (rows[r].size() != rows[0].size()) {
        err = "matrix literal: row " + std::to_string(r + 1) + " has " +
              std::to_string(rows[r].size()) + " value(s) but row 1 has " +
              std::to_string(rows[0].size()) + " - every row needs the same number of values";
        return false;
      }
    }
    out = fromGrid(rows);
    return true;
  }

  // Concatenation: [A, B] side by side, [A; B] stacked.
  Grid result;
  size_t width = 0;
  bool haveWidth = false;
  size_t widthRow = 0;
  for (size_t r = 0; r < rows.size(); r++) {
    size_t height = 0;
    bool haveHeight = false;
    Grid band;
    for (size_t k = 0; k < rows[r].size(); k++) {
      const Value &cell = rows[r][k];
      if (cell.isDict || cell.isObject || cell.isFunctionRef) {
        err = "matrix literal: row " + std::to_string(r + 1) + ", item " + std::to_string(k + 1) +
              " is not a number, text, array or matrix";
        return false;
      }
      const size_t h = rowsOf(cell), w = colsOf(cell);
      if (h == 0 || w == 0)
        continue; // [] items are skipped
      if (!haveHeight) {
        height = h;
        haveHeight = true;
        band.assign(height, {});
      } else if (h != height) {
        err = "matrix literal: row " + std::to_string(r + 1) + " joins items of different heights (" +
              std::to_string(height) + " and " + std::to_string(h) +
              " rows) - [A, B] needs A and B to have the same number of rows";
        return false;
      }
      for (size_t i = 0; i < h; i++)
        for (size_t j = 0; j < w; j++)
          band[i].push_back(cellOf(cell, i, j));
    }
    if (!haveHeight)
      continue;
    const size_t w = band[0].size();
    if (!haveWidth) {
      width = w;
      haveWidth = true;
      widthRow = r;
    } else if (w != width) {
      err = "matrix literal: row " + std::to_string(r + 1) + " is " + std::to_string(w) +
            " column(s) wide but row " + std::to_string(widthRow + 1) + " is " +
            std::to_string(width) + " - [A; B] needs A and B to have the same number of columns";
      return false;
    }
    for (auto &line : band)
      result.push_back(std::move(line));
  }
  out = fromGrid(std::move(result));
  return true;
}
