#include "matrix.h"
#include "matrix_arithmetic.h"
#include <Eigen/Dense>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>

using namespace Eigen;

/* ================= MATRIX VALIDATION ================= */

static bool invalidMatrix(const MatrixXd &m) {
  return (m.rows() == 0 || m.cols() == 0);
}

bool isEffectivelySingular(const MatrixXd &m) {
  if (m.rows() != m.cols())
    return true; // not even square - never invertible
  if (m.rows() == 0)
    return true;
  Eigen::JacobiSVD<MatrixXd> svd(m);
  const auto &sv = svd.singularValues();
  if (sv.size() == 0)
    return true;
  double maxSV = sv.maxCoeff();
  if (maxSV == 0.0)
    return true; // the all-zero matrix
  double tol = std::numeric_limits<double>::epsilon() * std::max(m.rows(), m.cols()) * maxSV;
  return sv.minCoeff() <= tol;
}

/* ================= VALUE → EIGEN ================= */

MatrixXd toEigenMat(Value v) {
  if (v.isMatrix) {
    int rows = v.rows();
    if (rows == 0)
      return MatrixXd(0, 0);

    int cols = v.cols();
    // All-numeric matrix: its buffer is already in Eigen's own layout.
    if (v.isPacked())
      return Eigen::Map<const MatrixXd>(v.packedData(), rows, cols);

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.numAt(i, j);

    return m;
  }

  if (v.length() != 0 && v.at(0).isArray) {
    int rows = v.length();
    int cols = v.at(0).length();

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.at(i).numAt(j);

    return m;
  }

  // Flat array: treat as a column vector (n x 1).
  int size = v.length();
  if (size == 0)
    return MatrixXd(0, 0);

  MatrixXd m(size, 1);
  for (int i = 0; i < size; i++)
    m(i, 0) = v.numAt(i);

  return m;
}

/* ================= EIGEN → VALUE ================= */

Value toValue(MatrixXd m) {
  if (m.rows() > 0 && m.cols() > 0)
    return Value::packedMatrix(m.data(), m.rows(), m.cols());

  std::vector<std::vector<Value>> mat;

  for (int i = 0; i < m.rows(); i++) {
    std::vector<Value> row;

    for (int j = 0; j < m.cols(); j++)
      row.push_back(Value(m(i, j)));

    mat.push_back(row);
  }

  return Value(mat);
}

/* ================= COMPLEX CONVERSIONS ================= */

MatrixXcd toEigenCMat(const Value &v) {
  if (!v.isMatrix || v.rows() == 0 || v.cols() == 0)
    return MatrixXcd(0, 0);

  int rows = v.rows(), cols = v.cols();
  if (v.isPackedComplex())
    return Eigen::Map<const MatrixXcd>(v.packedComplexData(), rows, cols);

  MatrixXcd m(rows, cols);
  for (int i = 0; i < rows; i++) {
    if ((int)v.rowLength(i) != cols)
      return MatrixXcd(0, 0);
    for (int j = 0; j < cols; j++)
      m(i, j) = v.cnumAt(i, j);
  }
  return m;
}

Value toValueC(const MatrixXcd &m) {
  if (m.rows() == 0 || m.cols() == 0)
    return Value(std::vector<std::vector<Value>>{});
  Value result = Value::packedComplexMatrix(m.data(), m.rows(), m.cols());
  result.narrowIfReal();
  return result;
}

// Elementwise product of two complex (or mixed) matrices, for had_prod()
// and ElementWise() below.
static Value complexHadamard(const char *fnName, const Value &a, const Value &b) {
  MatrixXcd m1 = toEigenCMat(a);
  MatrixXcd m2 = toEigenCMat(b);

  if (m1.size() == 0 || m2.size() == 0) {
    std::cerr << "Error: " << fnName << " requires two non-empty matrices\n";
    return Value(0);
  }
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: " << fnName << " requires same dimensions (" << m1.rows() << "x"
              << m1.cols() << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    return Value(0);
  }
  MatrixXcd r = m1.array() * m2.array();
  return toValueC(r);
}

/* ================= OPERATIONS ================= */

Value MatrixTranspose(Value a) {
  // Plain transpose: a complex matrix is not conjugated (use conjugate()).
  if (a.hasComplex()) {
    MatrixXcd cm = toEigenCMat(a);
    if (cm.size() == 0) {
      std::cerr << "Error: transpose requires a non-empty matrix\n";
      return Value(0);
    }
    MatrixXcd t = cm.transpose();
    return toValueC(t);
  }
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: transpose requires a non-empty matrix\n";
    return Value(0);
  }
  return toValue(m.transpose());
}

Value det(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    // Determinant is undefined for a non-square matrix - returning 0 used
    // to be silent, indistinguishable from "this square matrix genuinely
    // has determinant 0" (i.e. singular). Reporting it directly avoids
    // that ambiguity.
    std::cerr << "Error: det requires a non-empty square matrix (got "
              << m.rows() << "x" << m.cols() << ")\n";
    return Value(0);
  }
  return Value(m.determinant());
}

Value rank(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: rank requires a non-empty matrix\n";
    return Value(0);
  }
  return Value(m.fullPivLu().rank());
}

Value inv(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: inv requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    return Value(0);
  }
  if (isEffectivelySingular(m)) {
    std::cerr << "Error: matrix is singular (not invertible)\n";
    return Value(0);
  }
  return toValue(m.inverse());
}

Value had_prod(Value a, Value b) {
  if (a.hasComplex() || b.hasComplex())
    return complexHadamard("had_prod", a, b);
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2)) {
    std::cerr << "Error: had_prod requires two non-empty matrices\n";
    return Value(0);
  }

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: had_prod requires same dimensions (" << m1.rows() << "x" << m1.cols()
              << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    return Value(0);
  }

  return toValue(m1.array() * m2.array());
}

/* ---------- FIXED NAME ---------- */
Value conjugate(Value a) {
  if (a.hasComplex()) {
    MatrixXcd cm = toEigenCMat(a);
    if (cm.size() == 0) {
      std::cerr << "Error: conjugate requires a non-empty matrix\n";
      return Value(0);
    }
    MatrixXcd c = cm.conjugate();
    return toValueC(c);
  }
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: conjugate requires a non-empty matrix\n";
    return Value(0);
  }
  return toValue(m.conjugate());
}

Value pseudo_inverse(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: pseudo_inverse requires a non-empty matrix\n";
    return Value(0);
  }

  // SVD-based Moore-Penrose pseudo-inverse.
  // pinv(A) = V * S^+ * U^T where A = U * S * V^T
  Eigen::JacobiSVD<MatrixXd> svd(m, Eigen::ComputeThinU | Eigen::ComputeThinV);
  const auto &singular = svd.singularValues();

  // Tolerance for treating singular values as zero.
  // tol = eps * max(m,n) * maxSingular
  const double eps = std::numeric_limits<double>::epsilon();
  double maxSingular = 0.0;
  if (singular.size() > 0) {
    maxSingular = singular.maxCoeff();
  }
  const double tol = eps * std::max(m.rows(), m.cols()) * maxSingular;

  MatrixXd Splus = MatrixXd::Zero(singular.size(), singular.size());

  for (int i = 0; i < singular.size(); ++i) {
    if (singular(i) > tol) {
      Splus(i, i) = 1.0 / singular(i);
    }
  }

  MatrixXd pinv = svd.matrixV() * Splus * svd.matrixU().transpose();
  return toValue(pinv);
}

Value adj(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: adj requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    return Value(0);
  }

  const int n = (int)m.rows();
  // Adjugate matrix: adj(A) = C^T where C_ij are cofactors.
  // We compute cofactors directly to avoid unstable determinant/inverse checks.
  MatrixXd adjMat(n, n);
  adjMat.setZero();

  if (n == 1) {
    adjMat(0, 0) = 1.0;
    return toValue(adjMat);
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      // Minor by removing row i and col j.
      MatrixXd minor(n - 1, n - 1);
      int r = 0;
      for (int rr = 0; rr < n; ++rr) {
        if (rr == i)
          continue;
        int c = 0;
        for (int cc = 0; cc < n; ++cc) {
          if (cc == j)
            continue;
          minor(r, c) = m(rr, cc);
          ++c;
        }
        ++r;
      }

      double detMinor = minor.determinant();
      double sign = ((i + j) % 2 == 0) ? 1.0 : -1.0;
      double cofactor = sign * detMinor;
      // adj(A) = C^T => adj(j,i) = C(i,j)
      adjMat(j, i) = cofactor;
    }
  }

  return toValue(adjMat);
}

Value Norm(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: matrix_norm requires a non-empty matrix\n";
    return Value(0);
  }

  double sum = 0;
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < m.cols(); j++)
      sum += m(i, j) * m(i, j);

  return Value(std::sqrt(sum));
}

Value diag(Value a) {
  // Diag(n) => n x n diagonal matrix filled with `n` on the diagonal.
  // If a is already a matrix, fall back to extracting its diagonal as a vector.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: diag requires a positive size, got " << n << "\n";
      return Value(0);
    }
    return toValue(MatrixXd::Identity(n, n) * a.number);
  }

  if (!a.isMatrix && a.isArray) {
    // Diag(vector) => diagonal matrix.
    MatrixXd m((int)a.length(), (int)a.length());
    m.setZero();
    for (int i = 0; i < (int)a.length(); i++)
      m(i, i) = a.numAt(i);
    return toValue(m);
  }

  // Only a.isMatrix can reach here (the two conditions above already cover
  // every other combination of isMatrix/isArray - a dead, exact-duplicate
  // third branch used to sit here re-testing the same "scalar" condition
  // the first branch already handles and returns from unconditionally;
  // removed as unreachable, not a behavior change).
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: diag requires a non-empty matrix\n";
    return Value(0);
  }

  // Extract diagonal to vector for backwards compatibility.
  std::vector<Value> res;
  int n = std::min(m.rows(), m.cols());

  for (int i = 0; i < n; i++)
    res.push_back(Value(m(i, i)));

  return Value(res);
}

Value upper_triangular(Value a) {
  // upper_triangular(n) => generate an n x n upper-triangular matrix.
  // Documented expected form for n=3:
  // [[1,1,1],
  //  [0,1,1],
  //  [0,0,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: upper_triangular requires a positive size, got " << n << "\n";
      return Value(0);
    }

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = i; j < n; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: upper_triangular requires a non-empty matrix\n";
    return Value(0);
  }

  // Mask below diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < i; j++)
      m(i, j) = 0;

  return toValue(m);
}

Value zero_matrix(Value a) {
  // zero_matrix(n) => n x n all-zero matrix.
  // If a is already a matrix, return a same-sized zero matrix.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: zero_matrix requires a positive size, got " << n << "\n";
      return Value(0);
    }
    return toValue(MatrixXd::Zero(n, n));
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: zero_matrix requires a non-empty matrix\n";
    return Value(0);
  }

  return toValue(MatrixXd::Zero(m.rows(), m.cols()));
}

Value Lower_Triangular(Value a) {
  // Lower_Triangular(n) => deterministic n x n lower-triangular matrix.
  // Documented expected form for n=3:
  // [[1,0,0],
  //  [1,1,0],
  //  [1,1,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: lower_triangular requires a positive size, got " << n << "\n";
      return Value(0);
    }

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = 0; j <= i; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: lower_triangular requires a non-empty matrix\n";
    return Value(0);
  }

  // Mask above diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = i + 1; j < m.cols(); j++)
      m(i, j) = 0;

  return toValue(m);
}
Value ElementWise(Value a, Value b) {
  if (a.hasComplex() || b.hasComplex())
    return complexHadamard("element_wise", a, b);
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2)) {
    std::cerr << "Error: element_wise requires two non-empty matrices\n";
    return Value(0);
  }

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: element_wise requires same dimensions (" << m1.rows() << "x"
              << m1.cols() << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    return Value(0);
  }

  // Element-wise multiplication (Hadamard product).
  MatrixXd r = m1.array() * m2.array();

  return toValue(r);
}

Value full_rank_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: full_rank_matrix requires a non-empty matrix\n";
    return Value(0);
  }

  int r = m.fullPivLu().rank();
  return Value(r == std::min(m.rows(), m.cols()));
}

Value singular_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: singular_matrix requires a non-empty square matrix (got " << m.rows()
              << "x" << m.cols() << ")\n";
    return Value(0);
  }

  return Value(isEffectivelySingular(m));
}

Value pd_matrix(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: pd_matrix requires a non-empty matrix\n";
    return Value(0);
  }

  if (m.rows() != m.cols()) {
    std::cerr << "Error: pd_matrix requires a square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    return Value(0);
  }

  if (!m.isApprox(m.transpose())) {
    std::cerr << "Error: pd_matrix requires a symmetric matrix\n";
    return Value(0);
  }

  SelfAdjointEigenSolver<MatrixXd> es(m);

  const double tol = 1e-12;

  return Value(es.eigenvalues().minCoeff() > tol);
}

Value nd_matrix(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: nd_matrix requires a non-empty matrix\n";
    return Value(0);
  }

  if (m.rows() != m.cols()) {
    std::cerr << "Error: nd_matrix requires a square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    return Value(0);
  }

  if (!m.isApprox(m.transpose())) {
    std::cerr << "Error: nd_matrix requires a symmetric matrix\n";
    return Value(0);
  }

  SelfAdjointEigenSolver<MatrixXd> es(m);

  const double tol = 1e-12;

  return Value(es.eigenvalues().maxCoeff() < -tol);
}

Value unit_matrix(Value a) {
  int n = (int)a.number;
  if (n <= 0) {
    std::cerr << "Error: unit_matrix requires a positive size, got " << n << "\n";
    return Value(0);
  }

  return toValue(MatrixXd::Identity(n, n));
}

Value Trace(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: trace requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    return Value(0);
  }

  return Value(m.trace());
}

Value OnlyRows(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> rows;
      for (const auto &item : a.elems()) rows.push_back(item);
      return Value(rows);
    }
    std::cerr << "Error: onlyRows expects a matrix\n";
    return Value();
  }
  std::vector<Value> rows;
  for (size_t r = 0; r < a.rows(); r++) {
    rows.push_back(Value(a.row(r)));
  }
  return Value(rows);
}

Value OnlyCols(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> cols;
      for (const auto &item : a.elems()) cols.push_back(item);
      return Value(cols);
    }
    std::cerr << "Error: onlyCols expects a matrix\n";
    return Value();
  }
  if (a.rows() == 0) return Value(std::vector<Value>{});
  size_t colCount = a.cols();
  std::vector<Value> cols;
  for (size_t c = 0; c < colCount; ++c) {
    std::vector<Value> colVec;
    for (size_t r = 0; r < a.rows(); ++r) {
      if (c < a.rowLength(r))
        colVec.push_back(a.at(r, c));
      else
        colVec.push_back(Value(0.0));
    }
    cols.push_back(Value(colVec));
  }
  return Value(cols);
}