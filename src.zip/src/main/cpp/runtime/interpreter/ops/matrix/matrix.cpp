#include "matrix.h"
#include "matrix_arithmetic.h"
#include <Eigen/Dense>
#include <cmath>
#include <iostream>

using namespace Eigen;

/* ================= MATRIX VALIDATION ================= */

static bool invalidMatrix(const MatrixXd &m) {
  return (m.rows() == 0 || m.cols() == 0);
}

/* ================= VALUE → EIGEN ================= */

MatrixXd toEigenMat(Value v) {
  if (v.isMatrix) {
    int rows = v.matrix.size();
    if (rows == 0)
      return MatrixXd(0, 0);

    int cols = v.matrix[0].size();
    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.matrix[i][j].number;

    return m;
  }

  if (!v.array.empty() && v.array[0].isArray) {
    int rows = v.array.size();
    int cols = v.array[0].array.size();

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.array[i].array[j].number;

    return m;
  }

  // Flat array: treat as a column vector (n x 1).
  int size = v.array.size();
  if (size == 0)
    return MatrixXd(0, 0);

  MatrixXd m(size, 1);
  for (int i = 0; i < size; i++)
    m(i, 0) = v.array[i].number;

  return m;
}

/* ================= EIGEN → VALUE ================= */

Value toValue(MatrixXd m) {
  std::vector<std::vector<Value>> mat;

  for (int i = 0; i < m.rows(); i++) {
    std::vector<Value> row;

    for (int j = 0; j < m.cols(); j++)
      row.push_back(Value(m(i, j)));

    mat.push_back(row);
  }

  return Value(mat);
}

/* ================= OPERATIONS ================= */

Value MatrixTranspose(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);
  return toValue(m.transpose());
}

Value det(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols())
    return Value(0);
  return Value(m.determinant());
}

Value rank(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);
  return Value(m.fullPivLu().rank());
}

Value inv(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols())
    return Value(0);
  const double tol = 1e-12;
  if (std::abs(m.determinant()) <= tol)
    return Value(0);
  return toValue(m.inverse());
}

Value had_prod(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2))
    return Value(0);

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols())
    return Value(0);

  return toValue(m1.array() * m2.array());
}

/* ---------- FIXED NAME ---------- */
Value conjugate(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);
  return toValue(m.conjugate());
}

Value pseudo_inverse(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);

  // SVD-based Moore-Penrose pseudo-inverse.
  // pinv(A) = V * S^+ * U^T where A = U * S * V^T
  Eigen::JacobiSVD<MatrixXd> svd(m, Eigen::ComputeThinU | Eigen::ComputeThinV);
  const auto &singular = svd.singularValues();

  // Tolerance for treating singular values as zero.
  // tol = eps * max(m,n) * maxSingular
  const double eps = std::numeric_limits<double>::epsilon();
  double maxSingular = 0.0;
  if (singular.size() > 0) {
    maxSingular = singular.maxCoeff();
  }
  const double tol = eps * std::max(m.rows(), m.cols()) * maxSingular;

  MatrixXd Splus = MatrixXd::Zero(singular.size(), singular.size());

  for (int i = 0; i < singular.size(); ++i) {
    if (singular(i) > tol) {
      Splus(i, i) = 1.0 / singular(i);
    }
  }

  MatrixXd pinv = svd.matrixV() * Splus * svd.matrixU().transpose();
  return toValue(pinv);
}

Value adj(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols())
    return Value(0);

  const int n = (int)m.rows();
  // Adjugate matrix: adj(A) = C^T where C_ij are cofactors.
  // We compute cofactors directly to avoid unstable determinant/inverse checks.
  MatrixXd adjMat(n, n);
  adjMat.setZero();

  if (n == 1) {
    adjMat(0, 0) = 1.0;
    return toValue(adjMat);
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      // Minor by removing row i and col j.
      MatrixXd minor(n - 1, n - 1);
      int r = 0;
      for (int rr = 0; rr < n; ++rr) {
        if (rr == i)
          continue;
        int c = 0;
        for (int cc = 0; cc < n; ++cc) {
          if (cc == j)
            continue;
          minor(r, c) = m(rr, cc);
          ++c;
        }
        ++r;
      }

      double detMinor = minor.determinant();
      double sign = ((i + j) % 2 == 0) ? 1.0 : -1.0;
      double cofactor = sign * detMinor;
      // adj(A) = C^T => adj(j,i) = C(i,j)
      adjMat(j, i) = cofactor;
    }
  }

  return toValue(adjMat);
}

Value Norm(Value a) {
  MatrixXd m = toEigenMat(a);

  std::cout << "rows=" << m.rows() << " cols=" << m.cols() << std::endl;

  if (invalidMatrix(m))
    return Value(0);

  double sum = 0;
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < m.cols(); j++)
      sum += m(i, j) * m(i, j);

  std::cout << "sum=" << sum << std::endl;

  return Value(std::sqrt(sum));
}

Value diag(Value a) {
  // Diag(n) => n x n diagonal matrix filled with `n` on the diagonal.
  // If a is already a matrix, fall back to extracting its diagonal as a vector.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0)
      return Value(0);
    return toValue(MatrixXd::Identity(n, n) * a.number);
  }

  if (!a.isMatrix && a.isArray) {
    // Diag(vector) => diagonal matrix.
    MatrixXd m((int)a.array.size(), (int)a.array.size());
    m.setZero();
    for (int i = 0; i < (int)a.array.size(); i++)
      m(i, i) = a.array[i].number;
    return toValue(m);
  }

  if (!a.isArray && !a.isMatrix) {
    // Fallback: scalar
    int n = (int)a.number;
    if (n <= 0)
      return Value(0);
    return toValue(MatrixXd::Identity(n, n) * a.number);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);

  // Extract diagonal to vector for backwards compatibility.
  std::vector<Value> res;
  int n = std::min(m.rows(), m.cols());

  for (int i = 0; i < n; i++)
    res.push_back(Value(m(i, i)));

  return Value(res);
}

Value upper_triangular(Value a) {
  // upper_triangular(n) => generate an n x n upper-triangular matrix.
  // Documented expected form for n=3:
  // [[1,1,1],
  //  [0,1,1],
  //  [0,0,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0)
      return Value(0);

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = i; j < n; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);

  // Mask below diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < i; j++)
      m(i, j) = 0;

  return toValue(m);
}

Value zero_matrix(Value a) {
  // zero_matrix(n) => n x n all-zero matrix.
  // If a is already a matrix, return a same-sized zero matrix.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0)
      return Value(0);
    return toValue(MatrixXd::Zero(n, n));
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);

  return toValue(MatrixXd::Zero(m.rows(), m.cols()));
}

Value Lower_Triangular(Value a) {
  // Lower_Triangular(n) => deterministic n x n lower-triangular matrix.
  // Documented expected form for n=3:
  // [[1,0,0],
  //  [1,1,0],
  //  [1,1,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0)
      return Value(0);

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = 0; j <= i; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);

  // Mask above diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = i + 1; j < m.cols(); j++)
      m(i, j) = 0;

  return toValue(m);
}
Value ElementWise(Value a, Value b) {
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2))
    return Value(0);

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols())
    return Value(0);

  // Element-wise multiplication (Hadamard product).
  MatrixXd r = m1.array() * m2.array();

  return toValue(r);
}

Value full_rank_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m))
    return Value(0);

  int r = m.fullPivLu().rank();
  return Value(r == std::min(m.rows(), m.cols()));
}

Value singular_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols())
    return Value(0);

  const double tol = 1e-12;
  return Value(std::abs(m.determinant()) <= tol);
}

Value pd_matrix(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m))
    return Value(0);

  if (m.rows() != m.cols())
    return Value(0);

  if (!m.isApprox(m.transpose()))
    return Value(0);

  SelfAdjointEigenSolver<MatrixXd> es(m);

  const double tol = 1e-12;

  return Value(es.eigenvalues().minCoeff() > tol);
}

Value nd_matrix(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m))
    return Value(0);

  if (m.rows() != m.cols())
    return Value(0);

  if (!m.isApprox(m.transpose()))
    return Value(0);

  SelfAdjointEigenSolver<MatrixXd> es(m);

  const double tol = 1e-12;

  return Value(es.eigenvalues().maxCoeff() < -tol);
}

Value unit_matrix(Value a) {
  int n = (int)a.number;
  if (n <= 0)
    return Value(0);

  return toValue(MatrixXd::Identity(n, n));
}

Value Trace(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols())
    return Value(0);

  return Value(m.trace());
}

Value OnlyRows(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> rows;
      for (const auto &item : a.array) rows.push_back(item);
      return Value(rows);
    }
    std::cerr << "Error: onlyRows expects a matrix\n";
    return Value();
  }
  std::vector<Value> rows;
  for (const auto &row : a.matrix) {
    rows.push_back(Value(row));
  }
  return Value(rows);
}

Value OnlyCols(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> cols;
      for (const auto &item : a.array) cols.push_back(item);
      return Value(cols);
    }
    std::cerr << "Error: onlyCols expects a matrix\n";
    return Value();
  }
  if (a.matrix.empty()) return Value(std::vector<Value>{});
  size_t colCount = a.matrix[0].size();
  std::vector<Value> cols;
  for (size_t c = 0; c < colCount; ++c) {
    std::vector<Value> colVec;
    for (size_t r = 0; r < a.matrix.size(); ++r) {
      if (c < a.matrix[r].size())
        colVec.push_back(a.matrix[r][c]);
      else
        colVec.push_back(Value(0.0));
    }
    cols.push_back(Value(colVec));
  }
  return Value(cols);
}