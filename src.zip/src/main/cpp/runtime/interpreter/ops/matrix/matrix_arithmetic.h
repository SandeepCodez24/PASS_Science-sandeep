#pragma once
#include "../../core/value.h"

/* MATRIX + MATRIX */
Value matrix_add(Value a, Value b);
Value matrix_sub(Value a, Value b);
Value matrix_mul(Value a, Value b);
Value matrix_div(Value a, Value b);

/* SCALAR + MATRIX */
Value scalar_matrix_add(Value s, Value m);
Value matrix_scalar_add(Value m, Value s);

/* SCALAR - MATRIX */
Value scalar_matrix_sub(Value s, Value m);
Value matrix_scalar_sub(Value m, Value s);

/* MULTIPLICATION */
Value scalar_matrix_mul(Value s, Value m);

/* DIVISION */
Value matrix_scalar_div(Value m, Value s);
Value scalar_matrix_div(Value s, Value m);
Value matrix_pow(Value m, Value n);