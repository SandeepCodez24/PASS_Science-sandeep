#pragma once
#include "../../core/value.h"

/* MATRIX + MATRIX */
Value matrix_add(Value a, Value b);
Value matrix_sub(Value a, Value b);
Value matrix_mul(Value a, Value b);
Value matrix_div(Value a, Value b);

/* SCALAR + MATRIX */
Value scalar_matrix_add(Value s, Value m);
Value matrix_scalar_add(Value m, Value s);

/* SCALAR - MATRIX */
Value scalar_matrix_sub(Value s, Value m);
Value matrix_scalar_sub(Value m, Value s);

/* MULTIPLICATION */
Value scalar_matrix_mul(Value s, Value m);

/* DIVISION */
Value matrix_scalar_div(Value m, Value s);
Value scalar_matrix_div(Value s, Value m);
// matrix_pow() removed (was dead code - fully implemented but never called
// from anywhere; the reachable "^" operator has its own, now-corrected,
// matrix-power logic directly in arithmetic.cpp's power() instead. See
// that function's own comment for the full history: this orphaned version
// was actually MORE correct than the reachable one it duplicated
// (rejected non-integer exponents and p < -1 instead of silently
// mishandling them), which is exactly why keeping two divergent
// implementations around was worth cleaning up rather than leaving as
// dead code that could confuse a future reader into thinking it was live).