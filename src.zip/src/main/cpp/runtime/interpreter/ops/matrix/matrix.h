#ifndef MATRIX_H
#define MATRIX_H
#include <Eigen/Dense>

#include "../../core/value.h"

Eigen::MatrixXd toEigenMat(Value v);
Value toValue(Eigen::MatrixXd m);

// Complex counterparts. toEigenCMat() accepts a real or complex matrix and
// gives back a 0x0 matrix for anything that is not a rectangular matrix.
// toValueC() narrows to a real matrix when no imaginary part is left.
Eigen::MatrixXcd toEigenCMat(const Value &v);
Value toValueC(const Eigen::MatrixXcd &m);

// Scale-invariant near-singularity test, shared by every matrix op that
// needs to decide "can this be inverted" (inv(), singular_matrix(),
// matrix_div(), scalar_matrix_div(), the matrix-power operator's negative-
// exponent case). Replaces the old convention of comparing raw
// |determinant()| against a fixed 1e-12 - a real bug found via direct
// testing: determinant scales with the matrix's entries to the n-th power
// (an n x n matrix scaled by c has determinant c^n * original), so
// `inv(0.001 * unit_matrix(5))` (a perfectly well-conditioned matrix -
// it's just identity scaled down) had determinant 0.001^5 = 1e-15, tripped
// the fixed threshold, and inv() silently returned 0 instead of the
// correct 1000*I, with no error at all. Uses the matrix's smallest
// singular value against a threshold that scales with its LARGEST
// singular value instead (the same relative-tolerance approach
// pseudo_inverse() already used for its own zero-singular-value cutoff) -
// this is invariant to uniform scaling of the matrix, unlike a determinant
// threshold.
bool isEffectivelySingular(const Eigen::MatrixXd &m);
// Value Transpose(Value a);
Value MatrixTranspose(Value a);
Value det(Value a);
Value rank(Value a);
Value inv(Value a);
Value had_prod(Value a, Value b);

Value conjugate(Value a);
Value Norm(Value a);
Value pseudo_inverse(Value a);
Value ElementWise(Value a, Value b);

Value Lower_Triangular(Value a);

Value adj(Value a);

Value Mat_Norm(Value a);

Value diag(Value a);
Value upper_triangular(Value a);
Value zero_matrix(Value a);
Value full_rank_matrix(Value a);
Value singular_matrix(Value a);

Value pd_matrix(Value a);
Value nd_matrix(Value a);

Value unit_matrix(Value a);
Value Trace(Value a);
Value OnlyRows(Value a);
Value OnlyCols(Value a);
#endif
