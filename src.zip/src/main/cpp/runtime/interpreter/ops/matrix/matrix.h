#ifndef MATRIX_H
#define MATRIX_H
#include <Eigen/Dense>

#include "../../core/value.h"

Eigen::MatrixXd toEigenMat(Value v);
Value toValue(Eigen::MatrixXd m);
// Value Transpose(Value a);
Value MatrixTranspose(Value a);
Value det(Value a);
Value rank(Value a);
Value inv(Value a);
Value had_prod(Value a, Value b);

Value conjugate(Value a);
Value Norm(Value a);
Value pseudo_inverse(Value a);
Value ElementWise(Value a, Value b);

Value Lower_Triangular(Value a);

Value adj(Value a);

Value Mat_Norm(Value a);

Value diag(Value a);
Value upper_triangular(Value a);
Value zero_matrix(Value a);
Value full_rank_matrix(Value a);
Value singular_matrix(Value a);

Value pd_matrix(Value a);
Value nd_matrix(Value a);

Value unit_matrix(Value a);
Value Trace(Value a);
Value OnlyRows(Value a);
Value OnlyCols(Value a);
#endif
