#include "ops_math.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <queue>
#include <sstream>

#include "../matrix/nd_array.h"

namespace nc {
namespace ops {

using scipy::ordinal;

std::string lowerText(std::string s) {
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  return s;
}

std::string argLabel(size_t i) {
  return i < 6 ? "the " + ordinal(i) + " argument" : "argument " + std::to_string(i + 1);
}

std::string numText(double v) {
  std::ostringstream s;
  s << v;
  return s.str();
}

/* ================= NC functions ================= */

Fn::Fn(const Value &v) {
  if (isFnArg(v)) {
    fn_ = v;
    arity_ = scipy::functionInputCount(v);
  } else if (scipy::isPlainNumber(v)) {
    constant_ = true;
    value_ = cd(v.number, v.isComplex ? v.imag : 0.0);
  } else {
    failed_ = true;
  }
}

std::string Fn::describe() const {
  if (constant_)
    return "the constant";
  if (fn_.isFunctionRef)
    return "the function '" + fn_.funcRefName() + "'";
  if (fn_.isText)
    return "the function '" + fn_.text() + "'";
  return "the function";
}

Value Fn::call(const Args &in) {
  if (constant_)
    return numOf(value_);
  if (failed_)
    return Value(kNaN);
  Value out;
  calls_++;
  if (!scipy::callNC(fn_, in, out)) {
    failed_ = true;
    return Value(kNaN);
  }
  return out;
}

bool Fn::readComplexScalar(const Value &out, cd &z) {
  if (scipy::isPlainNumber(out)) {
    z = cd(out.number, out.isComplex ? out.imag : 0.0);
    return true;
  }
  CVec v;
  if (scipy::readCVec(out, v) && !v.empty()) {
    z = v[0];
    return true;
  }
  failed_ = true;
  return false;
}

cd Fn::c(cd z) {
  if (constant_)
    return value_;
  Value in = z.imag() == 0.0 ? Value(z.real()) : Value::complexNumber(z.real(), z.imag());
  Value out = call({in});
  cd w;
  if (failed_ || !readComplexScalar(out, w))
    return cd(kNaN, kNaN);
  return w;
}

double Fn::r(double x) {
  if (constant_)
    return value_.real();
  Value out = call({Value(x)});
  cd w;
  if (failed_ || !readComplexScalar(out, w))
    return kNaN;
  return w.real();
}

double Fn::r2(double x, double y) { return rN({x, y}); }

Args Fn::pointArgs(const Vec &x) const {
  if (arity_ == 1 && x.size() > 1)
    return {rowOf(x)};
  Args in;
  in.reserve(x.size());
  for (double d : x)
    in.push_back(Value(d));
  return in;
}

double Fn::rN(const Vec &x) { return cN(x).real(); }

cd Fn::cN(const Vec &x) {
  if (constant_)
    return value_;
  Value out = call(pointArgs(x));
  cd w;
  if (failed_ || !readComplexScalar(out, w))
    return cd(kNaN, kNaN);
  return w;
}

Vec Fn::vN(const Vec &x) {
  if (constant_)
    return Vec(x.size(), value_.real());
  Value out = call(pointArgs(x));
  Vec v;
  if (failed_ || !scipy::readVec(out, v)) {
    failed_ = true;
    return Vec(x.size(), kNaN);
  }
  return v;
}

/* ================= arguments ================= */

bool argFn(const Args &a, size_t i, CallContext &ctx, Fn &out, bool allowConstant) {
  if (i < a.size() && isFnArg(a[i])) {
    out = Fn(a[i]);
    return true;
  }
  if (allowConstant && i < a.size() && scipy::isPlainNumber(a[i])) {
    out = Fn(a[i]);
    return true;
  }
  ctx.fail(argLabel(i) + " must be a function, e.g. @f" +
           std::string(allowConstant ? " (or a number for a constant)" : ""));
  return false;
}

// A plain number, or a matrix holding exactly one.
static bool oneNumber(const Value &v, cd &out) {
  if (scipy::isPlainNumber(v)) {
    out = cd(v.number, v.isComplex ? v.imag : 0.0);
    return true;
  }
  CVec c;
  if ((v.isArray || v.isMatrix) && scipy::readCVec(v, c) && c.size() == 1) {
    out = c[0];
    return true;
  }
  return false;
}

bool argNum(const Args &a, size_t i, CallContext &ctx, double &out) {
  cd z;
  if (i >= a.size() || !oneNumber(a[i], z) || z.imag() != 0.0) {
    ctx.fail(argLabel(i) + " must be a number");
    return false;
  }
  out = z.real();
  return true;
}

bool argPositive(const Args &a, size_t i, CallContext &ctx, double &out) {
  if (!argNum(a, i, ctx, out))
    return false;
  if (!(out > 0.0) || !std::isfinite(out)) {
    ctx.fail(argLabel(i) + " must be a positive number");
    return false;
  }
  return true;
}

bool argCount(const Args &a, size_t i, CallContext &ctx, long long &out, long long lo,
              long long hi) {
  double d = 0.0;
  if (!argNum(a, i, ctx, d))
    return false;
  if (!std::isfinite(d) || d != std::floor(d) || d < static_cast<double>(lo) ||
      d > static_cast<double>(hi)) {
    ctx.fail(argLabel(i) + " must be a whole number from " + std::to_string(lo) +
             " to " + std::to_string(hi));
    return false;
  }
  out = static_cast<long long>(d);
  return true;
}

bool argCNum(const Args &a, size_t i, CallContext &ctx, cd &out) {
  if (i >= a.size() || !oneNumber(a[i], out)) {
    ctx.fail(argLabel(i) + " must be a number (real or complex)");
    return false;
  }
  return true;
}

bool argVec(const Args &a, size_t i, CallContext &ctx, Vec &out, size_t minLen) {
  if (i >= a.size() || a[i].hasComplex() || !scipy::readVec(a[i], out)) {
    ctx.fail(argLabel(i) + " must be an array of real numbers");
    return false;
  }
  if (out.size() < minLen) {
    ctx.fail(argLabel(i) + " must have at least " + std::to_string(minLen) +
             " values");
    return false;
  }
  for (double d : out)
    if (!std::isfinite(d)) {
      ctx.fail(argLabel(i) + " holds a NaN or infinite value");
      return false;
    }
  return true;
}

bool argCVec(const Args &a, size_t i, CallContext &ctx, CVec &out, size_t minLen) {
  if (i >= a.size() || !scipy::readCVec(a[i], out)) {
    ctx.fail(argLabel(i) + " must be an array of numbers");
    return false;
  }
  if (out.size() < minLen) {
    ctx.fail(argLabel(i) + " must have at least " + std::to_string(minLen) +
             " values");
    return false;
  }
  return true;
}

bool argMat(const Args &a, size_t i, CallContext &ctx, Mat &out) {
  if (i >= a.size() || a[i].hasComplex() || a[i].isND() || !scipy::readMat(a[i], out) ||
      out.a.empty()) {
    ctx.fail(argLabel(i) + " must be a matrix of real numbers");
    return false;
  }
  return true;
}

bool argCMat(const Args &a, size_t i, CallContext &ctx, CMat &out) {
  if (i >= a.size() || a[i].isND() || !scipy::readCMat(a[i], out) || out.a.empty()) {
    ctx.fail(argLabel(i) + " must be a matrix of numbers");
    return false;
  }
  return true;
}

/* ================= shapes ================= */

bool isVectorValue(const Value &v) {
  if (v.isND())
    return false;
  if (v.isArray)
    return v.length() >= 2;
  if (v.isMatrix)
    return (v.rows() == 1 && v.cols() >= 2) || (v.cols() == 1 && v.rows() >= 2);
  return false;
}

bool isGridValue(const Value &v) {
  if (v.isND())
    return v.ndShape().size() == 3;
  return v.isMatrix && v.rows() >= 2 && v.cols() >= 2;
}

Value vecLike(const Vec &r, const Value &like) {
  if (!isColumnValue(like))
    return rowOf(r);
  Mat m(r.size(), 1);
  m.a = r;
  return matOf(m);
}

Value vecLike(const CVec &r, const Value &like) {
  if (!isColumnValue(like))
    return rowOf(r);
  CMat m(r.size(), 1);
  m.a = r;
  return matOf(m);
}

bool argAxis(const Args &a, size_t i, CallContext &ctx, int &axis, int count) {
  if (i < a.size() && a[i].isText) {
    const std::string t = lowerText(a[i].text());
    if (t == "x" || t == "y" || t == "z")
      axis = t[0] - 'x';
    else if (t.size() >= 2 && t[0] == 'x' && std::all_of(t.begin() + 1, t.end(), ::isdigit))
      axis = std::stoi(t.substr(1)) - 1;
    else
      axis = -1;
  } else if (i < a.size() && isNumber(a[i]) && a[i].number == std::floor(a[i].number)) {
    axis = static_cast<int>(a[i].number) - 1;
  } else {
    axis = -1;
  }
  if (axis < 0 || axis >= count) {
    ctx.fail(argLabel(i) + " must name the variable: \"x\", \"y\"" +
             std::string(count > 2 ? ", \"z\"" : "") + " or its number 1 to " +
             std::to_string(count));
    return false;
  }
  return true;
}

double stepFor(const Vec &p, double base) {
  double m = 1.0;
  for (double v : p)
    m = std::max(m, std::abs(v));
  return base * m;
}

double partialAt(Fn &f, const Vec &p, size_t i, double h) {
  Vec q = p;
  auto at = [&](double s) {
    q[i] = p[i] + s * h;
    return f.rN(q);
  };
  const double a = at(-2), b = at(-1), c = at(1), d = at(2);
  return (a - 8.0 * b + 8.0 * c - d) / (12.0 * h);
}

Vec vPartialAt(Fn &f, const Vec &p, size_t i, double h) {
  Vec q = p;
  auto at = [&](double s) {
    q[i] = p[i] + s * h;
    return f.vN(q);
  };
  const Vec a = at(-2), b = at(-1), c = at(1), d = at(2);
  Vec out(a.size(), kNaN);
  if (b.size() != a.size() || c.size() != a.size() || d.size() != a.size())
    return out;
  for (size_t k = 0; k < a.size(); k++)
    out[k] = (a[k] - 8.0 * b[k] + 8.0 * c[k] - d[k]) / (12.0 * h);
  return out;
}

/* ================= grids ================= */

bool readGrid(const Value &v, Grid &out) {
  if (v.hasComplex())
    return false;
  if (v.isND()) {
    const auto &s = v.ndShape();
    if (s.size() != 3)
      return false;
    out = Grid(s[0], s[1], s[2], 3);
    for (size_t k = 0; k < s[0]; k++)
      for (size_t i = 0; i < s[1]; i++)
        for (size_t j = 0; j < s[2]; j++) {
          Value e = v.ndAt(nd::storageIndex(s, {k, i, j}));
          if (!scipy::isPlainNumber(e))
            return false;
          out.at(k, i, j) = e.number;
        }
    return !out.a.empty();
  }
  Mat m;
  if (!scipy::readMat(v, m) || m.a.empty())
    return false;
  out = Grid(1, m.r, m.c, 2);
  out.a = m.a;
  return true;
}

bool argGrid(const Args &a, size_t i, CallContext &ctx, Grid &out) {
  if (i >= a.size() || !readGrid(a[i], out) || out.nx < 2 || out.ny < 2 ||
      (out.rank == 3 && out.nz < 2)) {
    ctx.fail(argLabel(i) +
             " must be a grid of real numbers, at least 2 points along each axis: a "
             "matrix (2-D) or an N-D matrix of shape [nz, ny, nx] (3-D)");
    return false;
  }
  return true;
}

Value gridValue(const Grid &g) {
  if (g.rank == 2) {
    Mat m(g.ny, g.nx);
    m.a = g.a;
    return matOf(m);
  }
  nd::Shape shape = {g.nz, g.ny, g.nx};
  std::vector<Value> cells(g.size());
  for (size_t k = 0; k < g.nz; k++)
    for (size_t i = 0; i < g.ny; i++)
      for (size_t j = 0; j < g.nx; j++)
        cells[nd::storageIndex(shape, {k, i, j})] = Value(g.at(k, i, j));
  return nd::build(shape, std::move(cells));
}

bool gridSpacing(const Args &a, size_t i, const Grid &g, CallContext &ctx, double h[3]) {
  h[0] = h[1] = h[2] = 1.0;
  const size_t need = g.rank == 3 ? 3 : 2;
  for (size_t k = 0; k < need && given(a, i + k); k++)
    if (!argPositive(a, i + k, ctx, h[k]))
      return false;
  if (a.size() > i + need) {
    ctx.fail("a " + std::to_string(g.rank) + "-D grid takes " + std::to_string(need) +
             " spacings at most");
    return false;
  }
  return true;
}

Value gridDict(const Grid &gx, const Grid &gy, const Grid *gz) {
  DictInit d = {{"x", gridValue(gx)}, {"y", gridValue(gy)}};
  if (gz)
    d.push_back({"z", gridValue(*gz)});
  return dictOf(d);
}

size_t leadingGrids(const Args &a, size_t maxCount, std::vector<Grid> &out) {
  out.clear();
  for (size_t i = 0; i < a.size() && i < maxCount; i++) {
    if (!isGridValue(a[i]))
      break;
    Grid g;
    if (!readGrid(a[i], g) || (!out.empty() && !g.sameShape(out[0])))
      break;
    out.push_back(std::move(g));
  }
  return out.size();
}

std::string shapeText(const Grid &g) {
  std::ostringstream s;
  if (g.rank == 3)
    s << g.nz << "x";
  s << g.ny << "x" << g.nx;
  return s.str();
}

// Derivative along one line of n samples (stride apart) with spacing h.
static void diffLine(const double *y, double *d, size_t n, size_t stride, double h) {
  if (n == 1) {
    d[0] = 0.0;
    return;
  }
  if (n == 2) {
    const double s = (y[stride] - y[0]) / h;
    d[0] = s;
    d[stride] = s;
    return;
  }
  for (size_t i = 1; i + 1 < n; i++)
    d[i * stride] = (y[(i + 1) * stride] - y[(i - 1) * stride]) / (2.0 * h);
  d[0] = (-3.0 * y[0] + 4.0 * y[stride] - y[2 * stride]) / (2.0 * h);
  const size_t L = (n - 1) * stride;
  d[L] = (3.0 * y[L] - 4.0 * y[L - stride] + y[L - 2 * stride]) / (2.0 * h);
}

// Fourth-order derivative along one line (n >= 5).
static void diffLine4(const double *y, double *d, size_t n, size_t stride, double h) {
  if (n < 5) {
    diffLine(y, d, n, stride, h);
    return;
  }
  auto Y = [&](size_t i) { return y[i * stride]; };
  const double k = 1.0 / (12.0 * h);
  for (size_t i = 2; i + 2 < n; i++)
    d[i * stride] = (Y(i - 2) - 8.0 * Y(i - 1) + 8.0 * Y(i + 1) - Y(i + 2)) * k;
  d[0] = (-25.0 * Y(0) + 48.0 * Y(1) - 36.0 * Y(2) + 16.0 * Y(3) - 3.0 * Y(4)) * k;
  d[stride] = (-3.0 * Y(0) - 10.0 * Y(1) + 18.0 * Y(2) - 6.0 * Y(3) + Y(4)) * k;
  const size_t m = n - 1;
  d[m * stride] = (25.0 * Y(m) - 48.0 * Y(m - 1) + 36.0 * Y(m - 2) - 16.0 * Y(m - 3) + 3.0 * Y(m - 4)) * k;
  d[(m - 1) * stride] =
      (3.0 * Y(m) + 10.0 * Y(m - 1) - 18.0 * Y(m - 2) + 6.0 * Y(m - 3) - Y(m - 4)) * k;
}

Grid gridDiff(const Grid &g, int axis, double h, int order) {
  Grid d(g.nz, g.ny, g.nx, g.rank);
  size_t n, stride, lines;
  if (axis == 0) {
    n = g.nx;
    stride = 1;
    lines = g.nz * g.ny;
  } else if (axis == 1) {
    n = g.ny;
    stride = g.nx;
    lines = g.nz * g.nx;
  } else {
    n = g.nz;
    stride = g.ny * g.nx;
    lines = g.ny * g.nx;
  }
  const double *src = g.a.data();
  double *dst = d.a.data();
  par::forBlocks(lines, {par::Kind::Stream, 4.0 * static_cast<double>(n)},
                 [&](size_t b, size_t e) {
                   for (size_t L = b; L < e; L++) {
                     size_t start;
                     if (axis == 0)
                       start = L * g.nx;
                     else if (axis == 1)
                       start = (L / g.nx) * g.ny * g.nx + (L % g.nx);
                     else
                       start = L;
                     if (order == 4)
                       diffLine4(src + start, dst + start, n, stride, h);
                     else
                       diffLine(src + start, dst + start, n, stride, h);
                   }
                 });
  return d;
}

Vec diff1(const Vec &y, double h, int order) {
  Vec d(y.size());
  if (y.empty())
    return d;
  if (order == 4)
    diffLine4(y.data(), d.data(), y.size(), 1, h);
  else
    diffLine(y.data(), d.data(), y.size(), 1, h);
  return d;
}

// Second-order differences at any spacing (the formulas np.gradient uses).
Vec diff1(const Vec &y, const Vec &x) {
  const size_t n = y.size();
  Vec d(n, 0.0);
  if (n < 2)
    return d;
  if (n == 2) {
    d[0] = d[1] = (y[1] - y[0]) / (x[1] - x[0]);
    return d;
  }
  for (size_t i = 1; i + 1 < n; i++) {
    const double hs = x[i] - x[i - 1], hd = x[i + 1] - x[i];
    d[i] = (hs * hs * y[i + 1] + (hd * hd - hs * hs) * y[i] - hd * hd * y[i - 1]) /
           (hs * hd * (hd + hs));
  }
  {
    const double h1 = x[1] - x[0], h2 = x[2] - x[1];
    const double a = -(2.0 * h1 + h2) / (h1 * (h1 + h2)), b = (h1 + h2) / (h1 * h2),
                 c = -h1 / (h2 * (h1 + h2));
    d[0] = a * y[0] + b * y[1] + c * y[2];
  }
  {
    const double h1 = x[n - 2] - x[n - 3], h2 = x[n - 1] - x[n - 2];
    const double a = h2 / (h1 * (h1 + h2)), b = -(h2 + h1) / (h1 * h2),
                 c = (2.0 * h2 + h1) / (h2 * (h1 + h2));
    d[n - 1] = a * y[n - 3] + b * y[n - 2] + c * y[n - 1];
  }
  return d;
}

/* ================= quadrature ================= */

void gaussLegendre(int n, Vec &x, Vec &w) {
  x.assign(n, 0.0);
  w.assign(n, 0.0);
  for (int i = 0; i < (n + 1) / 2; i++) {
    double z = std::cos(kPi * (i + 0.75) / (n + 0.5)), dp = 0.0;
    for (int it = 0; it < 100; it++) {
      double p0 = 1.0, p1 = 0.0;
      for (int k = 1; k <= n; k++) {
        const double p2 = p1;
        p1 = p0;
        p0 = ((2.0 * k - 1.0) * z * p1 - (k - 1.0) * p2) / k;
      }
      dp = n * (z * p0 - p1) / (z * z - 1.0);
      const double z1 = z;
      z = z1 - p0 / dp;
      if (std::abs(z - z1) < 1e-15)
        break;
    }
    // recompute the derivative at the converged node
    double p0 = 1.0, p1 = 0.0;
    for (int k = 1; k <= n; k++) {
      const double p2 = p1;
      p1 = p0;
      p0 = ((2.0 * k - 1.0) * z * p1 - (k - 1.0) * p2) / k;
    }
    dp = n * (z * p0 - p1) / (z * z - 1.0);
    x[i] = -z;
    x[n - 1 - i] = z;
    w[i] = w[n - 1 - i] = 2.0 / ((1.0 - z * z) * dp * dp);
  }
}

namespace {

const double kXgk[8] = {0.991455371120812639206854697526329, 0.949107912342758524526189684047851,
                        0.864864423359769072789712788640926, 0.741531185599394439863864773280788,
                        0.586087235467691130294144845693013, 0.405845151377397166906606412076961,
                        0.207784955007898467600689403773245, 0.0};
const double kWgk[8] = {0.022935322010529224963732008058970, 0.063092092629978553290700663189204,
                        0.104790010322250183839876322541518, 0.140653259715525918745189590510238,
                        0.169004726639267902826583426598550, 0.190350578064785409913256402421014,
                        0.204432940075298892414161999234649, 0.209482141084727828012999174891714};
const double kWg[4] = {0.129484966168869693270611432679082, 0.279705391489276667901467771423780,
                       0.381830050505118944950369775488975, 0.417959183673469387755102040816327};

struct Panel {
  double a, b, err;
  Vec val;
  bool operator<(const Panel &o) const { return err < o.err; }
};

} // namespace

QuadResult quadVec(const VecIntegrand &f0, size_t m, double a, double b, double epsabs,
                   double epsrel, int limit, int startPanels) {
  QuadResult res;
  res.value.assign(m, 0.0);
  if (a == b)
    return res;
  double sign = 1.0;
  if (a > b) {
    std::swap(a, b);
    sign = -1.0;
  }

  // Infinite ends become a finite interval in t.
  const bool loInf = std::isinf(a), hiInf = std::isinf(b);
  VecIntegrand f = f0;
  Vec tmp(m);
  if (std::isinf(a) && std::isinf(b)) {
    f = [&f0, &tmp, m](double t, double *out) {
      const double d = 1.0 - t * t;
      if (d <= 0.0) {
        std::fill(out, out + m, 0.0);
        return true;
      }
      const double x = t / d, jac = (1.0 + t * t) / (d * d);
      if (!f0(x, tmp.data()))
        return false;
      for (size_t k = 0; k < m; k++)
        out[k] = std::isfinite(jac) ? tmp[k] * jac : 0.0;
      return true;
    };
    a = -1.0;
    b = 1.0;
  } else if (std::isinf(b)) {
    const double lo = a;
    f = [&f0, &tmp, m, lo](double t, double *out) {
      const double d = 1.0 - t;
      if (d <= 0.0) {
        std::fill(out, out + m, 0.0);
        return true;
      }
      const double x = lo + t / d, jac = 1.0 / (d * d);
      if (!f0(x, tmp.data()))
        return false;
      for (size_t k = 0; k < m; k++)
        out[k] = std::isfinite(jac) ? tmp[k] * jac : 0.0;
      return true;
    };
    a = 0.0;
    b = 1.0;
  } else if (std::isinf(a)) {
    const double hi = b;
    f = [&f0, &tmp, m, hi](double t, double *out) {
      const double d = 1.0 - t;
      if (d <= 0.0) {
        std::fill(out, out + m, 0.0);
        return true;
      }
      const double x = hi - t / d, jac = 1.0 / (d * d);
      if (!f0(x, tmp.data()))
        return false;
      for (size_t k = 0; k < m; k++)
        out[k] = std::isfinite(jac) ? tmp[k] * jac : 0.0;
      return true;
    };
    a = 0.0;
    b = 1.0;
  }

  Vec fv(m), kr(m), gs(m);
  bool nonFinite = false; // an infinite / NaN sample: the integral is not trusted
  auto rule = [&](double lo, double hi, Panel &p) -> bool {
    const double c = 0.5 * (lo + hi), h = 0.5 * (hi - lo);
    std::fill(kr.begin(), kr.end(), 0.0);
    std::fill(gs.begin(), gs.end(), 0.0);
    // j = 0..7 run left to the centre (j = 7), j = 8..14 mirror them on the right.
    for (int j = 0; j < 15; j++) {
      const int idx = j < 8 ? j : 14 - j;
      const double x = j < 8 ? c - h * kXgk[idx] : c + h * kXgk[idx];
      if (!f(x, fv.data()))
        return false;
      for (size_t k = 0; k < m; k++) {
        double v = fv[k];
        if (!std::isfinite(v)) {
          nonFinite = true;
          v = 0.0;
        }
        kr[k] += kWgk[idx] * v;
        if (idx % 2 == 1)
          gs[k] += kWg[idx / 2] * v;
        else if (idx == 7)
          gs[k] += kWg[3] * v;
      }
    }
    p.a = lo;
    p.b = hi;
    p.val.assign(m, 0.0);
    p.err = 0.0;
    for (size_t k = 0; k < m; k++) {
      p.val[k] = kr[k] * h;
      p.err = std::max(p.err, std::abs((kr[k] - gs[k]) * h));
    }
    return true;
  };

  // Global adaptive: always split the panel with the largest error. Start
  // with 8 panels so a narrow feature is not missed by the first rule.
  std::priority_queue<Panel> heap;
  Vec total(m, 0.0);
  double err = 0.0;
  const int start = startPanels < 1 ? 1 : startPanels;
  for (int s = 0; s < start; s++) {
    Panel p;
    if (!rule(a + (b - a) * s / start, a + (b - a) * (s + 1) / start, p)) {
      res.ok = false;
      return res;
    }
    for (size_t k = 0; k < m; k++)
      total[k] += p.val[k];
    err += p.err;
    heap.push(std::move(p));
  }
  int panels = start;
  for (;;) {
    double mag = 0.0;
    for (double t : total)
      mag = std::max(mag, std::abs(t));
    if (err <= std::max(epsabs, epsrel * mag))
      break;
    if (panels >= limit) {
      res.converged = false;
      break;
    }
    Panel worst = heap.top();
    const double mid = 0.5 * (worst.a + worst.b);
    if (!(mid > worst.a && mid < worst.b)) { // cannot split further
      res.converged = false;
      break;
    }
    heap.pop();
    Panel l, r;
    if (!rule(worst.a, mid, l) || !rule(mid, worst.b, r)) {
      res.ok = false;
      return res;
    }
    for (size_t k = 0; k < m; k++)
      total[k] += l.val[k] + r.val[k] - worst.val[k];
    err += l.err + r.err - worst.err;
    heap.push(std::move(l));
    heap.push(std::move(r));
    panels++;
  }
  // Sum again from the panels, so running-sum rounding does not stay in the result.
  // An infinite range also checks its far tail (beyond about |x| = 1e4): a
  // divergent integral mapped onto a finite t interval can pass the
  // relative test, but then the tail panels carry much of the total.
  std::fill(total.begin(), total.end(), 0.0);
  Vec tail(m, 0.0);
  err = 0.0;
  const double tLo = loInf ? (hiInf ? -1.0 + 1e-4 : 1.0 - 1e-4) : -kInf;
  const double tHi = hiInf ? 1.0 - 1e-4 : kInf;
  while (!heap.empty()) {
    const Panel &p = heap.top();
    const bool far = (hiInf && p.a >= tHi) || (loInf && (hiInf ? p.b <= tLo : p.a >= tLo));
    for (size_t k = 0; k < m; k++) {
      total[k] += p.val[k];
      if (far)
        tail[k] += p.val[k];
    }
    err += p.err;
    heap.pop();
  }
  if (loInf || hiInf) {
    double tmax = 0.0, mag = 0.0;
    for (size_t k = 0; k < m; k++) {
      tmax = std::max(tmax, std::abs(tail[k]));
      mag = std::max(mag, std::abs(total[k]));
    }
    if (tmax > 1e-3 * mag && tmax > epsabs)
      res.converged = false;
  }
  res.value = total;
  res.error = err;
  if (nonFinite)
    res.converged = false;
  for (double &v : res.value)
    v *= sign;
  return res;
}

Vec cumIntegrate(const Vec &y, const Vec &x) {
  const size_t n = y.size();
  Vec out(n, 0.0);
  if (n < 2)
    return out;
  if (n == 2) {
    out[1] = 0.5 * (y[0] + y[1]) * (x[1] - x[0]);
    return out;
  }
  const double g = 1.0 / std::sqrt(3.0);
  for (size_t i = 0; i + 1 < n; i++) {
    // parabola through (p, p+1, p+2) containing [x_i, x_{i+1}]
    const size_t p = (i == 0) ? 0 : (i + 2 < n ? i - 1 : n - 3);
    const double x0 = x[p], x1 = x[p + 1], x2 = x[p + 2];
    auto q = [&](double t) {
      return y[p] * (t - x1) * (t - x2) / ((x0 - x1) * (x0 - x2)) +
             y[p + 1] * (t - x0) * (t - x2) / ((x1 - x0) * (x1 - x2)) +
             y[p + 2] * (t - x0) * (t - x1) / ((x2 - x0) * (x2 - x1));
    };
    const double c = 0.5 * (x[i] + x[i + 1]), h = 0.5 * (x[i + 1] - x[i]);
    out[i + 1] = out[i] + h * (q(c - h * g) + q(c + h * g));
  }
  return out;
}

double integrateSamples(const Vec &y, const Vec &x) {
  Vec c = cumIntegrate(y, x);
  return c.empty() ? 0.0 : c.back();
}

double integrateUniform(const double *y, size_t n, size_t stride, double h) {
  if (n < 2)
    return 0.0;
  auto Y = [&](size_t i) { return y[i * stride]; };
  const size_t m = n - 1; // intervals
  if (m == 1)
    return 0.5 * h * (Y(0) + Y(1));
  double s = 0.0;
  size_t simpsonEnd = (m % 2 == 0) ? m : m - 3;
  for (size_t i = 0; i + 2 <= simpsonEnd; i += 2)
    s += h / 3.0 * (Y(i) + 4.0 * Y(i + 1) + Y(i + 2));
  if (m % 2 == 1) {
    const size_t i = simpsonEnd;
    s += 3.0 * h / 8.0 * (Y(i) + 3.0 * Y(i + 1) + 3.0 * Y(i + 2) + Y(i + 3));
  }
  return s;
}

Vec stehfestWeights(int n) {
  Vec V(static_cast<size_t>(n) + 1, 0.0);
  const int h = n / 2;
  auto fact = [](int m) { return std::tgamma(m + 1.0); };
  for (int k = 1; k <= n; k++) {
    double s = 0.0;
    for (int j = (k + 1) / 2; j <= std::min(k, h); j++)
      s += std::pow(j, h) * fact(2 * j) /
           (fact(h - j) * fact(j) * fact(j - 1) * fact(k - j) * fact(2 * j - k));
    V[static_cast<size_t>(k)] = ((k + h) % 2 ? -1.0 : 1.0) * s;
  }
  return V;
}

/* ================= complex helpers ================= */

CVec circleCoefficients(Fn &f, cd z0, double r, long long kmin, long long kmax, size_t M) {
  CVec samples(M);
  for (size_t j = 0; j < M; j++) {
    const double t = 2.0 * kPi * static_cast<double>(j) / static_cast<double>(M);
    samples[j] = f.c(z0 + std::polar(r, t));
    if (f.failed())
      return {};
  }
  CVec c;
  c.reserve(static_cast<size_t>(kmax - kmin + 1));
  for (long long k = kmin; k <= kmax; k++) {
    cd s = 0.0;
    for (size_t j = 0; j < M; j++) {
      const double t = 2.0 * kPi * static_cast<double>(j) / static_cast<double>(M);
      s += samples[j] * std::polar(1.0, -static_cast<double>(k) * t);
    }
    c.push_back(s / static_cast<double>(M) / std::pow(r, static_cast<double>(k)));
  }
  return c;
}

cd complexDerivative(Fn &f, cd z, double h) {
  const cd a = f.c(z - 2.0 * h), b = f.c(z - h), c = f.c(z + h), d = f.c(z + 2.0 * h);
  return (a - 8.0 * b + 8.0 * c - d) / (12.0 * h);
}

} // namespace ops
} // namespace nc
