// Registry of the engineering-mathematics functions in ops/ (Kreyszig,
// Advanced Engineering Mathematics, chapters 1-25: calculus, vector fields,
// ODEs, Fourier series, PDEs, complex analysis, probability, statistics).
//
// Same idea as Scipy/scipy_registry.h: every function is one OpsSpec, added
// by its domain folder's register function (calculus/, complex/, fourier/,
// pde/, ode/, statistics/). callBuiltin() asks this registry FIRST, before
// builtinTable, so the calculus names that used to live there (ddt, laplace,
// curl, div, ...) are answered here - their old forms still work, the new
// forms are added beside them.
//
// Errors: an implementation calls ctx.fail("..."), which prints
// "Error: <name>: <message>" and stops the statement like any NC error.
//
// Threads (docs/Multicore_Multithread_Architecture.md): `flags` says how a
// function may use them. Kernel - its loops go through nc::scipy::par
// (Scipy/scipy_parallel.h), so it goes multicore when that file does.
// Interpreter - it calls back into NC, so the callbacks stay on the
// interpreter thread; the arithmetic on the sampled values may still go
// through par.
#ifndef NC_OPS_REGISTRY_H
#define NC_OPS_REGISTRY_H

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "../../Scipy/scipy_registry.h"
#include "../../core/value.h"

namespace nc {
namespace ops {

using Args = std::vector<Value>;
using scipy::CallContext;
using Impl = std::function<Value(const Args &args, CallContext &ctx)>;

// The folder (and the front end's colour group) a function belongs to.
enum class Domain {
  Calculus,       // calculus/  derivatives, gradient, Laplacian, series
  VectorCalculus, // calculus/  fields, line/surface/volume integrals (ch. 9-10)
  Ode,            // ode/       ch. 1-6
  Fourier,        // fourier/   ch. 11
  Pde,            // pde/       ch. 12
  Complex,        // complex/   ch. 13-18
  Probability,    // statistics/ ch. 24
  Statistics      // statistics/ ch. 25
};
const char *domainName(Domain d);

// flags
constexpr unsigned kComplexArgs = 1; // complex inputs are allowed
constexpr unsigned kNDArgs = 2;      // N-D (3-D grid) inputs are allowed
constexpr unsigned kKernel = 4;      // loops go through nc::scipy::par
constexpr unsigned kCallsNC = 8;     // calls NC functions (interpreter thread only)

constexpr int kAnyCount = -1; // maxArgs: no upper limit

struct OpsSpec {
  std::string name; // lowercase; lookup is case-insensitive like every builtin
  Domain domain;
  int minArgs;
  int maxArgs;
  std::string usage;   // "ddt(Y[, h])" - shown in errors and in the front end
  std::string summary; // two or three words
  unsigned flags;
  Impl impl;
  // When set and false for a call, the call is not this function's: it goes
  // on to the next table (for a name shared with a NumPy / SciPy function;
  // none is shared today - the complex residue is complex_residue).
  std::function<bool(const Args &)> accepts = {};
};

class OpsRegistry {
public:
  static OpsRegistry &instance();
  void add(OpsSpec spec); // a second spec of the same name is a programming error
  const OpsSpec *find(const std::string &name) const;
  std::vector<const OpsSpec *> all() const; // sorted by domain, then name

private:
  OpsRegistry() = default;
  std::unordered_map<std::string, OpsSpec> specs_;
};

// Registers every domain once (thread-safe).
void initialize();

// True when `name` is one of these functions; then `out` is the result and
// `ok` false when it failed (its error already printed).
bool tryCall(const std::string &name, const Args &args, Value &out, bool &ok);
bool isOpsFunction(const std::string &name);
// True when the name is this registry's alone (not shared through `accepts`
// with a function elsewhere) - the NumPy / SciPy tables then leave it alone.
bool ownsName(const std::string &name);
bool acceptsND(const std::string &name);
std::string usageOf(const std::string &name); // "" when unknown

// The domain register functions (one per folder).
void registerCalculus(OpsRegistry &reg);       // calculus/calculus_builtin.cpp
void registerVectorCalculus(OpsRegistry &reg); // calculus/calculus_fields.cpp
void registerOde(OpsRegistry &reg);            // ode/
void registerFourier(OpsRegistry &reg);        // fourier/
void registerPde(OpsRegistry &reg);            // pde/
void registerComplexAnalysis(OpsRegistry &reg); // complex/
void registerProbability(OpsRegistry &reg);    // statistics/statistics_probability.cpp
void registerInference(OpsRegistry &reg);      // statistics/statistics_inference.cpp

} // namespace ops
} // namespace nc

// OPS_FN("name", min, max, "usage", "summary", flags) { body using a, ctx } OPS_END
// A file defines OPS_DOMAIN first.
#define OPS_FN(NAME, MINA, MAXA, USAGE, SUMMARY, FLAGS)                                            \
  reg.add(OpsSpec{NAME, OPS_DOMAIN, MINA, MAXA, USAGE, SUMMARY, FLAGS,                             \
                  [](const Args &a, CallContext &ctx) -> Value
#define OPS_END                                                                                    \
  });

#endif // NC_OPS_REGISTRY_H
