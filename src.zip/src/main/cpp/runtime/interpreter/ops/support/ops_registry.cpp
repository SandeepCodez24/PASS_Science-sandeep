#include "ops_registry.h"

#include <algorithm>
#include <cctype>
#include <exception>
#include <iostream>
#include <mutex>

namespace nc {
namespace ops {

namespace {

std::string lower(std::string s) {
  std::transform(s.begin(), s.end(), s.begin(),
                 [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  return s;
}

std::string countText(int lo, int hi) {
  if (hi == kAnyCount)
    return "at least " + std::to_string(lo);
  if (lo == hi)
    return std::to_string(lo);
  return std::to_string(lo) + " to " + std::to_string(hi);
}

} // namespace

const char *domainName(Domain d) {
  switch (d) {
  case Domain::Calculus:
    return "calculus";
  case Domain::VectorCalculus:
    return "vector_calculus";
  case Domain::Ode:
    return "ode";
  case Domain::Fourier:
    return "fourier";
  case Domain::Pde:
    return "pde";
  case Domain::Complex:
    return "complex_analysis";
  case Domain::Probability:
    return "probability";
  case Domain::Statistics:
    return "mathematical_statistics"; // "statistics" is the NumPy section
  }
  return "?";
}

OpsRegistry &OpsRegistry::instance() {
  static OpsRegistry registry;
  return registry;
}

void OpsRegistry::add(OpsSpec spec) {
  std::string key = lower(spec.name);
  if (specs_.count(key)) {
    std::cerr << "ops registry: '" << spec.name << "' is registered twice\n";
    return;
  }
  spec.name = key;
  specs_.emplace(key, std::move(spec));
}

const OpsSpec *OpsRegistry::find(const std::string &name) const {
  auto it = specs_.find(lower(name));
  return it == specs_.end() ? nullptr : &it->second;
}

std::vector<const OpsSpec *> OpsRegistry::all() const {
  std::vector<const OpsSpec *> out;
  out.reserve(specs_.size());
  for (const auto &kv : specs_)
    out.push_back(&kv.second);
  std::sort(out.begin(), out.end(), [](const OpsSpec *x, const OpsSpec *y) {
    if (x->domain != y->domain)
      return static_cast<int>(x->domain) < static_cast<int>(y->domain);
    return x->name < y->name;
  });
  return out;
}

void initialize() {
  static std::once_flag once;
  std::call_once(once, [] {
    OpsRegistry &reg = OpsRegistry::instance();
    registerCalculus(reg);
    registerVectorCalculus(reg);
    registerOde(reg);
    registerFourier(reg);
    registerPde(reg);
    registerComplexAnalysis(reg);
    registerProbability(reg);
    registerInference(reg);
  });
}

bool isOpsFunction(const std::string &name) {
  initialize();
  return OpsRegistry::instance().find(name) != nullptr;
}

bool ownsName(const std::string &name) {
  initialize();
  const OpsSpec *s = OpsRegistry::instance().find(name);
  return s && !s->accepts;
}

bool acceptsND(const std::string &name) {
  initialize();
  const OpsSpec *s = OpsRegistry::instance().find(name);
  return s && (s->flags & kNDArgs);
}

std::string usageOf(const std::string &name) {
  initialize();
  const OpsSpec *s = OpsRegistry::instance().find(name);
  return s ? s->usage : std::string();
}

bool tryCall(const std::string &name, const Args &args, Value &out, bool &ok) {
  initialize();
  const OpsSpec *spec = OpsRegistry::instance().find(name);
  if (!spec || (spec->accepts && !spec->accepts(args)))
    return false;

  ok = true;
  out = Value(0.0);
  const int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kAnyCount && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects " << countText(spec->minArgs, spec->maxArgs)
              << " argument(s), got " << argc << " - usage: " << spec->usage << "\n";
    ok = false;
    return true;
  }
  if (!(spec->flags & kComplexArgs)) {
    for (const Value &v : args) {
      if (v.hasComplex()) {
        std::cerr << "Error: " << spec->name << ": complex numbers are not accepted here - usage: "
                  << spec->usage << "\n";
        ok = false;
        return true;
      }
    }
  }

  CallContext ctx(spec->name);
  try {
    out = spec->impl(args, ctx);
  } catch (const std::exception &e) {
    ctx.fail(e.what());
  }
  ok = ctx.ok();
  if (!ok)
    out = Value(0.0);
  return true;
}

} // namespace ops
} // namespace nc
