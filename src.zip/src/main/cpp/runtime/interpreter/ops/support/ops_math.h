// Shared numerics of the engineering-mathematics functions (ops_registry.h):
// calling NC functions, reading grids, finite differences and quadrature.
//
// Reuses the SciPy port's building blocks (Scipy/scipy_core.h: Vec, Mat,
// readers, result builders, callNC) instead of writing them again.
//
// Grid convention, used by every field function:
//   2-D grid  - a matrix Z with Z[i, j] = f(x_j, y_i): rows go along y,
//               columns along x (the meshgrid layout).
//   3-D grid  - an N-D matrix of shape [nz, ny, nx]: page k is the 2-D grid
//               at z_k, so G[k, i, j] = f(x_j, y_i, z_k).
#ifndef NC_OPS_MATH_H
#define NC_OPS_MATH_H

#include <complex>
#include <functional>
#include <string>
#include <vector>

#include "../../Scipy/scipy_core.h"
#include "ops_registry.h"

namespace nc {
namespace ops {

using scipy::cd;
using scipy::CMat;
using scipy::CVec;
using scipy::kEps;
using scipy::kInf;
using scipy::kNaN;
using scipy::kPi;
using scipy::Mat;
using scipy::Vec;
using DictInit = scipy::DictInit;
namespace par = scipy::par;

inline Value dictOf(const DictInit &fields) { return scipy::makeDict(fields); }
inline Value rowOf(const Vec &v) { return scipy::toValue(v); }
inline Value rowOf(const CVec &v) { return scipy::realIfPossible(v); }
inline Value matOf(const Mat &m) { return scipy::toValue(m); }
inline Value matOf(const CMat &m) { return scipy::realIfPossible(m); }
inline Value numOf(const cd &z) { return scipy::scalarOf(z); }

// ---- NC functions ----

// A function argument: an NC function (@f or "f"), or a plain number, which
// is taken as the constant function of that value (g = 0 for "no initial
// velocity"). After a failed call every later call returns NaN and failed()
// is true; loops check it and stop.
class Fn {
public:
  Fn() = default;
  explicit Fn(const Value &v);

  bool isConstant() const { return constant_; }
  bool failed() const { return failed_; }
  int arity() const { return arity_; } // -1 when it cannot be told (a builtin)
  long calls() const { return calls_; }
  std::string describe() const; // "the function 'f'" for messages

  Value call(const Args &in);
  cd c(cd z);              // f(z): complex number in, complex number out
  double r(double x);      // f(x): real in, real out
  double r2(double x, double y);
  double rN(const Vec &x); // f(x, y, ...) - or f([x, y, ...]) when f takes one input
  cd cN(const Vec &x);
  Vec vN(const Vec &x);    // vector result, e.g. F(x, y, z) = [P, Q, R]

private:
  Args pointArgs(const Vec &x) const;
  bool readComplexScalar(const Value &out, cd &z);
  Value fn_;
  bool constant_ = false;
  cd value_ = 0.0;
  bool failed_ = false;
  int arity_ = -1;
  long calls_ = 0;
};

// After a loop of calls: reports a failed function and returns false.
inline bool fnOk(const Fn &f, CallContext &ctx) {
  if (!f.failed())
    return true;
  ctx.fail(f.describe() + " could not be evaluated (it must return a number for each input)");
  return false;
}

// Reads argument i as a function (or a constant). False (error reported) otherwise.
bool argFn(const Args &a, size_t i, CallContext &ctx, Fn &out, bool allowConstant = true);
// Only an NC function, no constant.
inline bool argCallable(const Args &a, size_t i, CallContext &ctx, Fn &out) {
  return argFn(a, i, ctx, out, false);
}
bool argNum(const Args &a, size_t i, CallContext &ctx, double &out);
bool argPositive(const Args &a, size_t i, CallContext &ctx, double &out);
bool argCount(const Args &a, size_t i, CallContext &ctx, long long &out, long long lo,
              long long hi);
bool argCNum(const Args &a, size_t i, CallContext &ctx, cd &out);
bool argVec(const Args &a, size_t i, CallContext &ctx, Vec &out, size_t minLen = 1);
bool argCVec(const Args &a, size_t i, CallContext &ctx, CVec &out, size_t minLen = 1);
bool argMat(const Args &a, size_t i, CallContext &ctx, Mat &out);
bool argCMat(const Args &a, size_t i, CallContext &ctx, CMat &out);
using scipy::argText; // text in quotes (Scipy/scipy_common.h)
inline bool given(const Args &a, size_t i) { return i < a.size(); }
inline bool isFnArg(const Value &v) { return v.isFunctionRef || v.isText; }
inline bool isNumber(const Value &v) { return scipy::isPlainNumber(v) && !v.isComplex; }
std::string lowerText(std::string s);
// "the third argument" (first .. sixth), "argument 7" from the seventh on.
std::string argLabel(size_t i);
// A number for a message: up to 6 significant digits (0.5, 1e-07, ...).
std::string numText(double v);

// ---- shapes of values ----

// A 1-D array, or a matrix with one row or one column (2 or more values).
bool isVectorValue(const Value &v);
inline bool isColumnValue(const Value &v) { return v.isMatrix && !v.isND() && v.cols() == 1 && v.rows() > 1; }
// A matrix of at least 2 x 2, or a 3-D N-D matrix.
bool isGridValue(const Value &v);
// Result vector in the orientation of the input (column when it was one).
Value vecLike(const Vec &r, const Value &like);
Value vecLike(const CVec &r, const Value &like);
// "x"/"y"/"z" (or "x1".."xn"), or the variable number 1..n -> axis 0..n-1.
bool argAxis(const Args &a, size_t i, CallContext &ctx, int &axis, int count);

// ---- derivatives of NC functions at a point ----

// df/dx_i at p, fourth-order central difference with step h.
double partialAt(Fn &f, const Vec &p, size_t i, double h);
// Same for every component of a vector function.
Vec vPartialAt(Fn &f, const Vec &p, size_t i, double h);
// Default step for a point: 1e-3 * max(1, |p|).
double stepFor(const Vec &p, double base = 1e-3);

// ---- grids ----

struct Grid {
  size_t nz = 1, ny = 0, nx = 0;
  int rank = 2; // 2 for a matrix, 3 for an N-D [nz, ny, nx]
  Vec a;        // a[(k * ny + i) * nx + j]
  Grid() = default;
  Grid(size_t z, size_t y, size_t x, int rk) : nz(z), ny(y), nx(x), rank(rk), a(z * y * x, 0.0) {}
  double &at(size_t k, size_t i, size_t j) { return a[(k * ny + i) * nx + j]; }
  double at(size_t k, size_t i, size_t j) const { return a[(k * ny + i) * nx + j]; }
  size_t size() const { return a.size(); }
  bool sameShape(const Grid &o) const { return nz == o.nz && ny == o.ny && nx == o.nx; }
};
bool readGrid(const Value &v, Grid &out);
bool argGrid(const Args &a, size_t i, CallContext &ctx, Grid &out);
Value gridValue(const Grid &g);
std::string shapeText(const Grid &g);
// Spacings dx, dy[, dz] from argument i on (each 1 when left out); no more
// than the grid has axes.
bool gridSpacing(const Args &a, size_t i, const Grid &g, CallContext &ctx, double h[3]);
// {x: gx, y: gy[, z: gz]}
Value gridDict(const Grid &gx, const Grid &gy, const Grid *gz);
// The leading arguments that are grids of one shape (a vector field's
// components): how many there are, read into out.
size_t leadingGrids(const Args &a, size_t maxCount, std::vector<Grid> &out);

// d/dx (axis 0), d/dy (axis 1) or d/dz (axis 2) of a grid with spacing h:
// second-order central differences inside, second-order one-sided at the
// edges (first order when the axis has two points, 0 for one point).
// order 4: fourth-order differences (5-point stencils, one-sided at the
// edges) for smooth data such as the coordinates of a parametric surface or
// curve; lines shorter than 5 points use the second-order rule.
Grid gridDiff(const Grid &g, int axis, double h, int order = 2);
// Same rule on one sampled line, uniform spacing h, or at coordinates x.
Vec diff1(const Vec &y, double h, int order = 2);
Vec diff1(const Vec &y, const Vec &x);

// ---- quadrature ----

// n-point Gauss-Legendre nodes and weights on [-1, 1].
void gaussLegendre(int n, Vec &x, Vec &w);

// Adaptive Gauss-Kronrod (7, 15) integral of a VECTOR integrand on [a, b];
// either end may be infinite (mapped). f(x, out) fills out[0 .. m-1] and
// returns false to stop - then ok is false. Each node calls f once, so an
// integrand that costs one NC call per node gives all m components for it.
struct QuadResult {
  Vec value;
  double error = 0.0;
  bool ok = true;        // f never failed
  bool converged = true; // the tolerance was met within the panel limit
};
using VecIntegrand = std::function<bool(double x, double *out)>;
// startPanels: how many equal panels the first pass uses (8 sees narrow
// features; 1 for many short pieces such as the segments of a contour).
QuadResult quadVec(const VecIntegrand &f, size_t m, double a, double b, double epsabs = 1e-10,
                   double epsrel = 1e-10, int limit = 2000, int startPanels = 8);

// Running integral of samples y at x (y[0] -> 0), third order: each interval
// integrates the parabola through it and a neighbour (trapezoid for 2 points).
Vec cumIntegrate(const Vec &y, const Vec &x);
// Integral of samples over the whole of x (Simpson-type, any spacing).
double integrateSamples(const Vec &y, const Vec &x);
// Uniformly spaced: composite Simpson with a 3/8 tail, trapezoid for 2 points.
double integrateUniform(const double *y, size_t n, size_t stride, double h);

// Gaver-Stehfest weights V_1 .. V_n (n even; index 0 unused) for
// f(t) ~ (ln 2 / t) sum V_k F(k ln 2 / t), the real-s inverse Laplace transform.
Vec stehfestWeights(int n);

// ---- complex helpers ----

// f'(z) by the fourth-order central difference along the real axis.
cd complexDerivative(Fn &f, cd z, double h);
inline bool isFiniteC(const cd &z) { return std::isfinite(z.real()) && std::isfinite(z.imag()); }

// Laurent coefficients c_k, k = kmin .. kmax, of f around z0 from M samples
// on the circle |z - z0| = r (trapezoid rule = discrete Fourier transform,
// exponentially accurate for f analytic on an annulus around the circle):
// c_k = (1/M) sum_j f(z0 + r e^(i t_j)) e^(-i k t_j) / r^k.
CVec circleCoefficients(Fn &f, cd z0, double r, long long kmin, long long kmax, size_t M);
// Number of samples for coefficients up to |k| = kmax: at least 64, 4 per coefficient.
inline size_t circleSamples(long long kmax) {
  const size_t m = static_cast<size_t>(4 * (kmax + 1));
  return m < 64 ? 64 : m;
}

} // namespace ops
} // namespace nc

#endif // NC_OPS_MATH_H
