#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "../../core/value.h"

// Null sets (nullset_builtin.cpp) - letters of a non-English script made
// ready to use as variable names:
//
//   nullset_tamizh()      அ ஆ இ ஈ உ ஊ எ ஏ ஐ ஒ ஓ ஔ          (12 vowels)
//   nullset_malayalam()   അ ആ ഇ ഈ ഉ ഊ എ ഏ ഐ ഒ ഓ ഔ          (12 vowels)
//   nullset_sanskrit()    अ आ इ ई उ ऊ ऋ ॠ ऌ ॡ ए ऐ ओ औ      (14 vowels)
//   nullset_telugu()      అ ఆ ఇ ఈ ఉ ఊ ఋ ఎ ఏ ఐ ఒ ఓ ఔ అం అః  (15 vowels)
//   nullset_greek()       α β γ δ η θ λ μ ρ τ φ ω          (12 letters)
//
// Each call defines every letter of its set as 0 in the GLOBAL workspace
// (the one the IDE's Variable Explorer shows), the same as typing
// `α = 0` for each - except that a letter which already exists keeps its
// value. It takes no values and returns a 1xN row with the letters'
// current values, in set order.
//
// The letters and their spellings follow the IDE's own typing tables
// (src/main/java/language/replace/*.java, the "\var(...)" commands): the
// vowel maps for the Indian scripts, and for Greek the twelve names of
// core/symbols.h that are not constants (π and σ are pi and Stefan-Boltzmann).
//
// After a call the set is "active": the IDE's @WS line carries a "nullsets"
// section for it (runtime/data/WS_PROTOCOL.md) so the Variable Explorer can
// show the set as one row ([α, β, ...] = [0, 0, ...]) - crimson while a
// letter is 0, teal once the user gives it a value. A set stops being
// active when none of its letters is left in the workspace (`clear`).
namespace ncnullset {

struct Letter {
  const char *name;  // the variable name, UTF-8 ("α")
  const char *token; // how the IDE types it ("\\var(\\alpha)")
};

struct Set {
  const char *id;       // "greek"
  const char *function; // "nullset_greek"
  const char *script;   // "Greek"
  std::vector<Letter> letters;
};

// All five sets, in the order above.
const std::vector<Set> &sets();

// The set a function name belongs to ("nullset_greek" -> greek), or null.
const Set *findByFunction(const std::string &name);

// True for the five nullset_* names.
bool isNullsetFunction(const std::string &name);

// What the Variable Explorer shows for one letter.
//   "zero"     the letter is a plain number equal to 0 (crimson)
//   "set"      it holds anything else (teal)
//   "missing"  it is not in the workspace (not shown)
const char *stateOf(const Value *v);

// True (with the number) when v is a plain real number, not a bool.
bool scalarNumber(const Value &v, double &out);

// The call itself: defines the letters of `set` that `vars` does not hold
// yet as 0 (appended to `order`), marks the set active, and returns the
// 1xN row of current values. A letter holding something other than a
// number or text is shown in the row as NaN.
Value apply(const Set &set, std::unordered_map<std::string, Value> &vars,
            std::vector<std::string> &order);

// Active sets, in call order. refresh() drops a set none of whose letters
// is in `vars` any more; it returns true when that changed anything.
std::vector<const Set *> activeSets();
bool refresh(const std::unordered_map<std::string, Value> &vars);
// Forgets every active set (tests).
void resetActive();

} // namespace ncnullset
