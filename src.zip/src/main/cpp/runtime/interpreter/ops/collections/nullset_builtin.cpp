// Null sets - see nullset_builtin.h. Added 2026-11-10 to encourage letters
// of non-English scripts as everyday variable names: one call makes a whole
// set ready (each letter 0), and the IDE shows the set together and moves
// the letters the user has given a value to the top of its suggestions.
#include "nullset_builtin.h"

#include <algorithm>
#include <limits>
#include <unordered_map>

namespace ncnullset {

namespace {

// Spellings copied from the IDE's typing tables - keep them in step:
//   Tamil      src/main/java/language/replace/Tamil.java      TAMIL_VOWEL_MAP
//   Malayalam  src/main/java/language/replace/Malayalam.java  MALAYALAM_VOWEL_MAP
//   Sanskrit   src/main/java/language/replace/Sanskrit.java   "VOWELS" (preferred \\token form)
//   Telugu     src/main/java/language/replace/Telugu.java     TELUGU_VOWEL_MAP
//   Greek      src/main/java/language/replace/Greek.java      SYMBOL_MAP
// Left out on purpose:
//   Tamil ஃ (\akg): the aytham, not one of the 12 uyir vowels.
//   Malayalam \akg: dropped (user decision, 2026-11-10) - Malayalam.java
//   maps it to the TAMIL letter ஃ, a bug being fixed on the Java side. Do
//   not add it to the Malayalam set.
//   Greek π, σ: the constants pi and Stefan-Boltzmann (constants_builtin.cpp);
//   the other Greek letters: the twelve most used are those of core/symbols.h.
const std::vector<Set> &table() {
  static const std::vector<Set> t = {
      {"tamizh", "nullset_tamizh", "Tamil",
       {{"அ", "\\var(\\tamil(\\a))"},
        {"ஆ", "\\var(\\tamil(\\aa))"},
        {"இ", "\\var(\\tamil(\\e))"},
        {"ஈ", "\\var(\\tamil(\\ee))"},
        {"உ", "\\var(\\tamil(\\u))"},
        {"ஊ", "\\var(\\tamil(\\uu))"},
        {"எ", "\\var(\\tamil(\\ea))"},
        {"ஏ", "\\var(\\tamil(\\eaa))"},
        {"ஐ", "\\var(\\tamil(\\i))"},
        {"ஒ", "\\var(\\tamil(\\o))"},
        {"ஓ", "\\var(\\tamil(\\oo))"},
        {"ஔ", "\\var(\\tamil(\\au))"}}},
      {"malayalam", "nullset_malayalam", "Malayalam",
       {{"അ", "\\var(\\malayalam(\\a))"},
        {"ആ", "\\var(\\malayalam(\\aa))"},
        {"ഇ", "\\var(\\malayalam(\\e))"},
        {"ഈ", "\\var(\\malayalam(\\ee))"},
        {"ഉ", "\\var(\\malayalam(\\u))"},
        {"ഊ", "\\var(\\malayalam(\\uu))"},
        {"എ", "\\var(\\malayalam(\\ea))"},
        {"ഏ", "\\var(\\malayalam(\\eaa))"},
        {"ഐ", "\\var(\\malayalam(\\i))"},
        {"ഒ", "\\var(\\malayalam(\\o))"},
        {"ഓ", "\\var(\\malayalam(\\oo))"},
        {"ഔ", "\\var(\\malayalam(\\au))"}}},
      {"sanskrit", "nullset_sanskrit", "Sanskrit",
       {{"अ", "\\var(\\sanskrit(\\a))"},
        {"आ", "\\var(\\sanskrit(\\aa))"},
        {"इ", "\\var(\\sanskrit(\\i))"},
        {"ई", "\\var(\\sanskrit(\\ii))"},
        {"उ", "\\var(\\sanskrit(\\u))"},
        {"ऊ", "\\var(\\sanskrit(\\uu))"},
        {"ऋ", "\\var(\\sanskrit(\\r))"},
        {"ॠ", "\\var(\\sanskrit(\\rr))"},
        {"ऌ", "\\var(\\sanskrit(\\l))"},
        {"ॡ", "\\var(\\sanskrit(\\ll))"},
        {"ए", "\\var(\\sanskrit(\\e))"},
        {"ऐ", "\\var(\\sanskrit(\\ai))"},
        {"ओ", "\\var(\\sanskrit(\\o))"},
        {"औ", "\\var(\\sanskrit(\\au))"}}},
      {"telugu", "nullset_telugu", "Telugu",
       {{"అ", "\\var(\\telugu(\\a))"},
        {"ఆ", "\\var(\\telugu(\\aa))"},
        {"ఇ", "\\var(\\telugu(\\i))"},
        {"ఈ", "\\var(\\telugu(\\ii))"},
        {"ఉ", "\\var(\\telugu(\\u))"},
        {"ఊ", "\\var(\\telugu(\\uu))"},
        {"ఋ", "\\var(\\telugu(\\ru))"},
        {"ఎ", "\\var(\\telugu(\\e))"},
        {"ఏ", "\\var(\\telugu(\\ee))"},
        {"ఐ", "\\var(\\telugu(\\ai))"},
        {"ఒ", "\\var(\\telugu(\\o))"},
        {"ఓ", "\\var(\\telugu(\\oo))"},
        {"ఔ", "\\var(\\telugu(\\au))"},
        {"అం", "\\var(\\telugu(\\am))"},
        {"అః", "\\var(\\telugu(\\ah))"}}},
      {"greek", "nullset_greek", "Greek",
       {{"α", "\\var(\\alpha)"},
        {"β", "\\var(\\beta)"},
        {"γ", "\\var(\\gamma)"},
        {"δ", "\\var(\\delta)"},
        {"η", "\\var(\\eta)"},
        {"θ", "\\var(\\theta)"},
        {"λ", "\\var(\\lambda)"},
        {"μ", "\\var(\\mu)"},
        {"ρ", "\\var(\\rho)"},
        {"τ", "\\var(\\tau)"},
        {"φ", "\\var(\\phi)"},
        {"ω", "\\var(\\omega)"}}},
  };
  return t;
}

std::vector<const Set *> &active() {
  static std::vector<const Set *> a;
  return a;
}

bool plainNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
         !v.isFunctionRef && !v.isND() && !v.hasComplex();
}

bool holdsAny(const Set &set, const std::unordered_map<std::string, Value> &vars) {
  for (const Letter &l : set.letters)
    if (vars.count(l.name))
      return true;
  return false;
}

} // namespace

const std::vector<Set> &sets() { return table(); }

const Set *findByFunction(const std::string &name) {
  // Asked for every function call (parserOwnsName): one hash lookup instead
  // of comparing the name with every set (2026-11-21). The table never
  // changes, so the pointers stay valid.
  static const std::unordered_map<std::string, const Set *> byFunction = [] {
    std::unordered_map<std::string, const Set *> m;
    for (const Set &s : table())
      m.emplace(s.function, &s);
    return m;
  }();
  auto it = byFunction.find(name);
  return it == byFunction.end() ? nullptr : it->second;
}

bool isNullsetFunction(const std::string &name) { return findByFunction(name) != nullptr; }

const char *stateOf(const Value *v) {
  if (!v)
    return "missing";
  if (plainNumber(*v) && !v->isBool() && v->number == 0)
    return "zero";
  return "set";
}

bool scalarNumber(const Value &v, double &out) {
  if (!plainNumber(v) || v.isBool())
    return false;
  out = v.number;
  return true;
}

Value apply(const Set &set, std::unordered_map<std::string, Value> &vars,
            std::vector<std::string> &order) {
  std::vector<Value> row;
  row.reserve(set.letters.size());
  for (const Letter &l : set.letters) {
    auto it = vars.find(l.name);
    if (it == vars.end()) {
      it = vars.emplace(l.name, Value(0.0)).first;
      order.push_back(l.name);
    }
    const Value &v = it->second;
    if ((plainNumber(v) && !v.isBool()) || v.isText)
      row.push_back(v);
    else
      row.push_back(Value(std::numeric_limits<double>::quiet_NaN()));
  }
  auto &a = active();
  if (std::find(a.begin(), a.end(), &set) == a.end())
    a.push_back(&set);
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}

std::vector<const Set *> activeSets() { return active(); }

bool refresh(const std::unordered_map<std::string, Value> &vars) {
  auto &a = active();
  const std::size_t before = a.size();
  a.erase(std::remove_if(a.begin(), a.end(), [&](const Set *s) { return !holdsAny(*s, vars); }),
          a.end());
  return a.size() != before;
}

void resetActive() { active().clear(); }

} // namespace ncnullset
