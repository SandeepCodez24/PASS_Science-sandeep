#pragma once
#include "../../core/value.h"

/* ================= STANDARD TRIG ================= */

Value sin_op(Value a);
Value cos_op(Value a);
Value tan_op(Value a);

/* ================= RECIPROCAL TRIG ================= */

Value cosec_op(Value a);
Value sec_op(Value a);
Value cot_op(Value a);

/* ================= INVERSE TRIG ================= */

Value inv_sin_op(Value a);
Value inv_cos_op(Value a);
Value inv_tan_op(Value a);

// atan2(y, x): the two-argument arctangent - full-circle angle (-pi, pi]
// of the point (x, y), correctly handling all four quadrants and the x==0
// case, unlike inv_tan_op(y/x) (which loses the sign of x entirely and is
// undefined at x==0). Was completely absent from this codebase - a real
// gap for a MATLAB-like numeric language, since it's the standard way to
// get a vector's angle in any physics/engineering calculation.
Value atan2_op(Value y, Value x);

/* ================= INVERSE RECIPROCAL TRIG ================= */

Value inv_cosec_op(Value a);
Value inv_sec_op(Value a);
Value inv_cot_op(Value a);

/* ================= HYPERBOLIC ================= */

Value sinh_op(Value a);
Value cosh_op(Value a);
Value tanh_op(Value a);

/* ================= HYPERBOLIC RECIPROCAL ================= */

Value cosech_op(Value a);
Value sech_op(Value a);
Value coth_op(Value a);

/* ================= DEGREE BASED ================= */

Value sin_deg(Value a);
Value cos_deg(Value a);
Value tan_deg(Value a);
Value cosec_deg(Value a);
Value sec_deg(Value a);
Value cot_deg(Value a);