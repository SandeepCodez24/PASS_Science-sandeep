#define _USE_MATH_DEFINES
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "trigonometric.h"
#include "../../core/elementwise.h"
#include <iostream>

// Every function here is a mapElementwise() wrapper around a scalar
// std:: math call (NumPy/SciPy Parity Roadmap §4.1) - this is what fixes
// sin([0,1,2]) returning 0 instead of [0, 0.8414..., 0.9092...]: a
// scalar-only call used to read a.number directly, silently ignoring
// isArray/isMatrix (which default .number to 0). mapElementwise leaves
// scalar behavior byte-for-byte unchanged (it's still just fn(a.number) for
// a plain number) while adding array/matrix broadcast for free.
//
// Each one also has a complex branch, taken only when the argument holds a
// complex number: the same function from <complex>, whose branch cuts and
// principal values are the ones NumPy and MATLAB use. Real arguments never
// reach it, so their results are exactly what they were.

// Where the real inverse functions are undefined, a real argument gets the
// complex answer instead of NaN (mapElementwisePromoting). inv_sin/inv_cos
// are real only on [-1, 1]; inv_cosec/inv_sec, being inv_sin(1/x) and
// inv_cos(1/x), are real only outside (-1, 1). Zero, infinities and NaN are
// deliberately not promoted and keep their existing results.
// 1/z for the reciprocal inverse functions. A real z is divided as a real
// number: complex division would give 1/(-0.25+0i) an imaginary part of
// -0, and that sign decides which side of the branch cut inv_cosec and
// inv_sec land on.
static Cplx reciprocalC(Cplx z) {
  return z.imag() == 0.0 ? Cplx(1.0 / z.real(), 0.0) : 1.0 / z;
}

static bool outsideUnitInterval(double x) { return std::isfinite(x) && std::fabs(x) > 1.0; }
static bool insideUnitInterval(double x) { return x != 0.0 && std::fabs(x) < 1.0; }

/* ================= BASIC TRIG ================= */

Value sin_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::sin(z); });
  return mapElementwise(a, [](double x) { return std::sin(x); });
}

Value cos_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::cos(z); });
  return mapElementwise(a, [](double x) { return std::cos(x); });
}

Value tan_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::tan(z); });
  return mapElementwise(a, [](double x) { return std::tan(x); });
}

/* ================= RECIPROCAL TRIG ================= */

Value cosec_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return 1.0 / std::sin(z); });
  return mapElementwise(a, [](double x) { return 1.0 / std::sin(x); });
}

Value sec_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return 1.0 / std::cos(z); });
  return mapElementwise(a, [](double x) { return 1.0 / std::cos(x); });
}

Value cot_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::cos(z) / std::sin(z); });
  return mapElementwise(a, [](double x) { return std::cos(x) / std::sin(x); });
}

/* ================= INVERSE TRIG ================= */

Value inv_sin_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::asin(z); });
  return mapElementwisePromoting(
      a, [](double x) { return std::asin(x); }, outsideUnitInterval,
      [](Cplx z) { return std::asin(z); });
}

Value inv_cos_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::acos(z); });
  return mapElementwisePromoting(
      a, [](double x) { return std::acos(x); }, outsideUnitInterval,
      [](Cplx z) { return std::acos(z); });
}

Value inv_tan_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::atan(z); });
  return mapElementwise(a, [](double x) { return std::atan(x); });
}

// Two-argument arctangent - routed through zipElementwise (not a bare
// std::atan2 call) for the same reason every other op in this file routes
// through mapElementwise: array/matrix operands must broadcast correctly
// instead of silently reading .number (0 for a container-flagged Value).
Value atan2_op(Value y, Value x) {
  return zipElementwise(y, x, [](double yy, double xx) { return std::atan2(yy, xx); });
}

/* ================= INVERSE RECIPROCAL TRIG ================= */

Value inv_cosec_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::asin(reciprocalC(z)); });
  return mapElementwisePromoting(
      a, [](double x) { return std::asin(1.0 / x); }, insideUnitInterval,
      [](Cplx z) { return std::asin(reciprocalC(z)); });
}

Value inv_sec_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::acos(reciprocalC(z)); });
  return mapElementwisePromoting(
      a, [](double x) { return std::acos(1.0 / x); }, insideUnitInterval,
      [](Cplx z) { return std::acos(reciprocalC(z)); });
}

Value inv_cot_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::atan(reciprocalC(z)); });
  return mapElementwise(a, [](double x) { return std::atan(1.0 / x); });
}

/* ================= HYPERBOLIC ================= */

Value sinh_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::sinh(z); });
  return mapElementwise(a, [](double x) { return std::sinh(x); });
}

Value cosh_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::cosh(z); });
  return mapElementwise(a, [](double x) { return std::cosh(x); });
}

Value tanh_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::tanh(z); });
  return mapElementwise(a, [](double x) { return std::tanh(x); });
}

/* ================= HYPERBOLIC RECIPROCAL ================= */

Value cosech_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return 1.0 / std::sinh(z); });
  return mapElementwise(a, [](double x) { return 1.0 / std::sinh(x); });
}

Value sech_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return 1.0 / std::cosh(z); });
  return mapElementwise(a, [](double x) { return 1.0 / std::cosh(x); });
}

Value coth_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::cosh(z) / std::sinh(z); });
  return mapElementwise(a, [](double x) { return std::cosh(x) / std::sinh(x); });
}

/* ================= DEGREE SUPPORT ================= */

double deg2rad(double x) {
  return x * M_PI / 180.0;
}

static Cplx deg2radC(Cplx z) { return z * (M_PI / 180.0); }

Value sin_deg(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::sin(deg2radC(z)); });
  return mapElementwise(a, [](double x) { return std::sin(deg2rad(x)); });
}

Value cos_deg(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::cos(deg2radC(z)); });
  return mapElementwise(a, [](double x) { return std::cos(deg2rad(x)); });
}

Value tan_deg(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::tan(deg2radC(z)); });
  return mapElementwise(a, [](double x) { return std::tan(deg2rad(x)); });
}

/* ================= DEGREE RECIPROCAL TRIG ================= */

Value cosec_deg(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return 1.0 / std::sin(deg2radC(z)); });
  return mapElementwise(a, [](double x) { return 1.0 / std::sin(deg2rad(x)); });
}

Value sec_deg(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return 1.0 / std::cos(deg2radC(z)); });
  return mapElementwise(a, [](double x) { return 1.0 / std::cos(deg2rad(x)); });
}

Value cot_deg(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::cos(deg2radC(z)) / std::sin(deg2radC(z)); });
  return mapElementwise(
      a, [](double x) { return std::cos(deg2rad(x)) / std::sin(deg2rad(x)); });
}
