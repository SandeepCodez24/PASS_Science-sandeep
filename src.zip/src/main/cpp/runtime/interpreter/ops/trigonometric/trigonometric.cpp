#define _USE_MATH_DEFINES
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "trigonometric.h"
#include <iostream>
/* ================= BASIC TRIG ================= */

Value sin_op(Value a)
{
    return Value(std::sin(a.number));
}

Value cos_op(Value a)
{
    return Value(std::cos(a.number));
}

Value tan_op(Value a)
{
    return Value(std::tan(a.number));
}

/* ================= RECIPROCAL TRIG ================= */

Value cosec_op(Value a)
{
    return Value(1.0 / std::sin(a.number));
}

Value sec_op(Value a)
{
    return Value(1.0 / std::cos(a.number));
}

Value cot_op(Value a)
{
    return Value(std::cos(a.number) / std::sin(a.number));
}

/* ================= INVERSE TRIG ================= */

Value inv_sin_op(Value a)
{
    return Value(std::asin(a.number));
}

Value inv_cos_op(Value a)
{
    return Value(std::acos(a.number));
}

Value inv_tan_op(Value a)
{
    return Value(std::atan(a.number));
}

/* ================= INVERSE RECIPROCAL TRIG ================= */

Value inv_cosec_op(Value a)
{
    return Value(std::asin(1.0 / a.number));
}

Value inv_sec_op(Value a)
{
    return Value(std::acos(1.0 / a.number));
}

Value inv_cot_op(Value a)
{
    return Value(std::atan(1.0 / a.number));
}

/* ================= HYPERBOLIC ================= */

Value sinh_op(Value a)
{
    return Value(std::sinh(a.number));
}

Value cosh_op(Value a)
{
    return Value(std::cosh(a.number));
}

Value tanh_op(Value a)
{
    return Value(std::tanh(a.number));
}

/* ================= HYPERBOLIC RECIPROCAL ================= */

Value cosech_op(Value a)
{
    return Value(1.0 / std::sinh(a.number));
}

Value sech_op(Value a)
{
    return Value(1.0 / std::cosh(a.number));
}

Value coth_op(Value a)
{
    return Value(std::cosh(a.number) / std::sinh(a.number));
}

/* ================= DEGREE SUPPORT ================= */

double deg2rad(double x)
{
    return x * M_PI / 180.0;
}

Value sin_deg(Value a)
{
    return Value(std::sin(deg2rad(a.number)));
}

Value cos_deg(Value a)
{
    return Value(std::cos(deg2rad(a.number)));
}

Value tan_deg(Value a)
{
    return Value(std::tan(deg2rad(a.number)));
}
/* ================= DEGREE RECIPROCAL TRIG ================= */

Value cosec_deg(Value a)
{
    return Value(1.0 / std::sin(deg2rad(a.number)));
}

Value sec_deg(Value a)
{
    return Value(1.0 / std::cos(deg2rad(a.number)));
}

Value cot_deg(Value a)
{
    return Value(std::cos(deg2rad(a.number)) /
                 std::sin(deg2rad(a.number)));
}