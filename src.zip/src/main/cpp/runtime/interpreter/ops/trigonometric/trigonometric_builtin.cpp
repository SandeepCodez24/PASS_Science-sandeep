#include "trigonometric_builtin.h"
#include "../geometric/geometric.h"
#include "trigonometric.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>


Value trigonometricBuiltin(const std::string &name,
                           const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= STANDARD TRIG ================= */

      {"sin",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sin", 1))
           return Value(0);
         return sin_op(a[0]);
       }},

      {"cos",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cos", 1))
           return Value(0);
         return cos_op(a[0]);
       }},

      {"tan",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "tan", 1))
           return Value(0);
         return tan_op(a[0]);
       }},

      /* ================= RECIPROCAL TRIG ================= */

      {"cosec",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cosec", 1))
           return Value(0);
         return cosec_op(a[0]);
       }},

      {"sec",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sec", 1))
           return Value(0);
         return sec_op(a[0]);
       }},

      {"cot",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cot", 1))
           return Value(0);
         return cot_op(a[0]);
       }},

      /* ================= INVERSE TRIG ================= */

      {"inv_sin",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv_sin", 1))
           return Value(0);
         return inv_sin_op(a[0]);
       }},

      {"inv_cos",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv_cos", 1))
           return Value(0);
         return inv_cos_op(a[0]);
       }},

      {"inv_tan",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv_tan", 1))
           return Value(0);
         return inv_tan_op(a[0]);
       }},

      {"inv_cosec",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv_cosec", 1))
           return Value(0);
         return inv_cosec_op(a[0]);
       }},

      {"inv_sec",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv_sec", 1))
           return Value(0);
         return inv_sec_op(a[0]);
       }},

      {"inv_cot",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv_cot", 1))
           return Value(0);
         return inv_cot_op(a[0]);
       }},

      {"atan2",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "atan2", 2))
           return Value(0);
         return atan2_op(a[0], a[1]);
       }},

      /* ================= HYPERBOLIC ================= */

      {"sinh",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sinh", 1))
           return Value(0);
         return sinh_op(a[0]);
       }},

      {"cosh",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cosh", 1))
           return Value(0);
         return cosh_op(a[0]);
       }},

      {"tanh",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "tanh", 1))
           return Value(0);
         return tanh_op(a[0]);
       }},

      {"cosech",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cosech", 1))
           return Value(0);
         return cosech_op(a[0]);
       }},

      {"sech",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sech", 1))
           return Value(0);
         return sech_op(a[0]);
       }},

      {"coth",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "coth", 1))
           return Value(0);
         return coth_op(a[0]);
       }},

      /* ================= DEGREE MODE ================= */

      {"sin_deg",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sin_deg", 1))
           return Value(0);
         return sin_deg(a[0]);
       }},

      {"cos_deg",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cos_deg", 1))
           return Value(0);
         return cos_deg(a[0]);
       }},

      {"tan_deg",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "tan_deg", 1))
           return Value(0);
         return tan_deg(a[0]);
       }},

      {"cosec_deg",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cosec_deg", 1))
           return Value(0);
         return cosec_deg(a[0]);
       }},

      {"sec_deg",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sec_deg", 1))
           return Value(0);
         return sec_deg(a[0]);
       }},

      {"cot_deg",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cot_deg", 1))
           return Value(0);
         return cot_deg(a[0]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass) - see matrix_builtin.cpp for
  // the first fix of this kind and the full reasoning.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown trig function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}