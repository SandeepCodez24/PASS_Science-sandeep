#include "trigonometric_builtin.h"
#include "../geometric/geometric.h"
#include "trigonometric.h"

#include <functional>
#include <iostream>
#include <unordered_map>


Value trigonometricBuiltin(const std::string &name,
                           const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= STANDARD TRIG ================= */

      {"sin",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sin", 1))
           return Value(0);
         return sin_op(a[0]);
       }},

      {"cos",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cos", 1))
           return Value(0);
         return cos_op(a[0]);
       }},

      {"tan",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("tan", 1))
           return Value(0);
         return tan_op(a[0]);
       }},

      /* ================= RECIPROCAL TRIG ================= */

      {"cosec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cosec", 1))
           return Value(0);
         return cosec_op(a[0]);
       }},

      {"sec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sec", 1))
           return Value(0);
         return sec_op(a[0]);
       }},

      {"cot",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cot", 1))
           return Value(0);
         return cot_op(a[0]);
       }},

      /* ================= INVERSE TRIG ================= */

      {"inv_sin",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv_sin", 1))
           return Value(0);
         return inv_sin_op(a[0]);
       }},

      {"inv_cos",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv_cos", 1))
           return Value(0);
         return inv_cos_op(a[0]);
       }},

      {"inv_tan",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv_tan", 1))
           return Value(0);
         return inv_tan_op(a[0]);
       }},

      {"inv_cosec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv_cosec", 1))
           return Value(0);
         return inv_cosec_op(a[0]);
       }},

      {"inv_sec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv_sec", 1))
           return Value(0);
         return inv_sec_op(a[0]);
       }},

      {"inv_cot",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("inv_cot", 1))
           return Value(0);
         return inv_cot_op(a[0]);
       }},

      /* ================= HYPERBOLIC ================= */

      {"sinh",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sinh", 1))
           return Value(0);
         return sinh_op(a[0]);
       }},

      {"cosh",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cosh", 1))
           return Value(0);
         return cosh_op(a[0]);
       }},

      {"tanh",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("tanh", 1))
           return Value(0);
         return tanh_op(a[0]);
       }},

      {"cosech",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cosech", 1))
           return Value(0);
         return cosech_op(a[0]);
       }},

      {"sech",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sech", 1))
           return Value(0);
         return sech_op(a[0]);
       }},

      {"coth",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("coth", 1))
           return Value(0);
         return coth_op(a[0]);
       }},

      /* ================= DEGREE MODE ================= */

      {"sin_deg",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sin_deg", 1))
           return Value(0);
         return sin_deg(a[0]);
       }},

      {"cos_deg",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cos_deg", 1))
           return Value(0);
         return cos_deg(a[0]);
       }},

      {"tan_deg",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("tan_deg", 1))
           return Value(0);
         return tan_deg(a[0]);
       }},

      {"cosec_deg",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cosec_deg", 1))
           return Value(0);
         return cosec_deg(a[0]);
       }},

      {"sec_deg",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sec_deg", 1))
           return Value(0);
         return sec_deg(a[0]);
       }},

      {"cot_deg",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cot_deg", 1))
           return Value(0);
         return cot_deg(a[0]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown trig function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}