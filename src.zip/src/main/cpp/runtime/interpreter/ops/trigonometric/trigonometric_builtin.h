#pragma once

#include <string>
#include <vector>

#include "../../core/value.h"

// Dispatcher for trigonometric builtins
Value trigonometricBuiltin(const std::string &name,
                           const std::vector<Value> &args);
