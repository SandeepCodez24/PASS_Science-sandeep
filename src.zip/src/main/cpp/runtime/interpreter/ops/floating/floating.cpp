#include "floating.h"

#include <cfloat>
#include <cmath>
#include <cstring>
#include <vector>

#include "../../core/packed_read.h"
#include "../arithmetic/arithmetic.h" // tryCoerceTextToNumber
#include "parallel/par.h"

namespace {

// The formats, rounding and bit codec live in core/narrow_float.h
// (2026-11-21), shared with the compact typed-tensor storage.
const ncfloat::Format &formatOf(FloatType t)
{
    switch (t) {
    case FloatType::Float8:
        return ncfloat::kFloat8;
    case FloatType::Float16:
        return ncfloat::kFloat16;
    default:
        return ncfloat::kFloat32;
    }
}

Value floatScalar(FloatType t, double x)
{
    return t == FloatType::Float64 ? Value(x) : Value::floating(t, roundToFloatType(t, x));
}

void copyUnit(const Value &from, Value &to)
{
    to.dimL = from.dimL;
    to.dimT = from.dimT;
    to.dimM = from.dimM;
}

bool castScalar(const Value &v, FloatType t, Value &out, std::string &err)
{
    const std::string name = floatTypeName(t);
    if (v.isComplex) {
        if (t == FloatType::Float64) {
            out = v; // a complex number already is two float64 parts
            out.dropScalarType();
            return true;
        }
        err = "cannot convert a complex number to " + name + " (use real() or abs() first)";
        return false;
    }
    if (v.isDict || v.isObject || v.isFunctionRef) {
        err = name + "() expects a number, text, or an array/matrix of numbers";
        return false;
    }
    double x = v.number;
    if (v.isText) {
        if (!tryCoerceTextToNumber(v, x)) {
            err = name + "() could not parse '" + v.text() + "' as a number";
            return false;
        }
    }
    out = floatScalar(t, x);
    if (!v.isText)
        copyUnit(v, out);
    return true;
}

int rank(FloatType t)
{
    switch (t) {
    case FloatType::Float8:
        return 1;
    case FloatType::Float16:
        return 2;
    case FloatType::Float32:
        return 3;
    default:
        return 4;
    }
}

bool isSingleNumber(const Value &v)
{
    return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef;
}

} // namespace

double roundToFloatType(FloatType t, double x)
{
    if (t == FloatType::Float64)
        return x;
    return ncfloat::roundTo(formatOf(t), x);
}

const char *floatTypeName(FloatType t)
{
    switch (t) {
    case FloatType::Float8:
        return "float8";
    case FloatType::Float16:
        return "float16";
    case FloatType::Float32:
        return "float32";
    case FloatType::Float64:
        break;
    }
    return "float64";
}

bool floatTypeFromName(const std::string &name, FloatType &out)
{
    if (name == "float8")
        out = FloatType::Float8;
    else if (name == "float16")
        out = FloatType::Float16;
    else if (name == "float32")
        out = FloatType::Float32;
    else if (name == "float64")
        out = FloatType::Float64;
    else
        return false;
    return true;
}

bool isReservedWideFloatName(const std::string &name)
{
    return name == "float128" || name == "float256";
}

namespace {

ElemType elemTypeOf(FloatType t)
{
    switch (t) {
    case FloatType::Float8:
        return ElemType::F8;
    case FloatType::Float16:
        return ElemType::F16;
    case FloatType::Float32:
        return ElemType::F32;
    default:
        return ElemType::F64;
    }
}

// The fast path of castToFloat() (2026-11-20): a real packed array / matrix
// - float64, lazy range or typed - converted straight into the result's
// buffer on several cores. The element-by-element path made one 32-byte
// Value per element and then packed them: float16 of a 1 x 628318531 row
// needed ~20 GB and never finished. Each element gets exactly what
// castScalar() gives it (roundToFloatType of its double; the unit is the
// tensor's), and the result is the typed tensor that packing those cells
// made, so the bits are the same. Returns false when `v` is not such a
// tensor (the caller takes the old path); `stopped` is set when Stop ended
// the work.
bool castPackedToFloat(const Value &v, FloatType t, Value &out, bool &stopped)
{
    stopped = false;
    ncpacked::RealReader in;
    if (!in.open(v))
        return false;
    if (t == FloatType::Float64 && !in.typed()) {
        out = v; // already float64: the same values (a lazy range stays lazy)
        return true;
    }
    const size_t n = in.count();
    const char *label = floatTypeName(t);
    nc::par::Outcome r;
    if (t == FloatType::Float64) {
        nc::F64Buf buf(n); // every element written (or Stop: discarded)
        double *dst = buf.data();
        r = nc::par::forBlocks(n, nc::par::stream(2.0), label, [&](size_t b, size_t e) {
            for (size_t k = b; k < e; k++)
                dst[k] = in.at(k);
        });
        if (r != nc::par::Outcome::Done) {
            stopped = true;
            return true;
        }
        if (in.shape().size() == 1) {
            out = Value::packedArrayFrom(std::move(buf));
            out.setUnitDims(in.dimL(), in.dimT(), in.dimM());
        } else {
            out = Value::ndPacked(in.shape(), std::move(buf), false, in.dimL(), in.dimT(), in.dimM());
        }
        return true;
    }
    // float32: 4-byte floats; float16 / float8: their own 2- / 1-byte bit
    // patterns (core/narrow_float.h), each the element rounded to the format.
    const ElemType et = elemTypeOf(t);
    const size_t width = elemTypeBytes(et);
    std::vector<uint8_t> raw(n * width);
    uint8_t *dst = raw.data();
    r = nc::par::forBlocks(n, nc::par::compute(15.0), label, [&](size_t b, size_t e) {
        switch (et) {
        case ElemType::F16:
            for (size_t k = b; k < e; k++)
                ncfloat::storeF16(dst + 2 * k, in.at(k));
            break;
        case ElemType::F8:
            for (size_t k = b; k < e; k++)
                ncfloat::storeF8(dst + k, in.at(k));
            break;
        default:
            // The hardware conversion: the same bits as roundToFloatType()
            // (src/test/narrow_float_check.cpp).
            for (size_t k = b; k < e; k++)
                ncfloat::storeF32(dst + 4 * k, in.at(k));
            break;
        }
    });
    if (r != nc::par::Outcome::Done) {
        stopped = true;
        return true;
    }
    out = Value::typedTensor(et, in.shape(), std::move(raw), in.dimL(), in.dimT(), in.dimM());
    return true;
}

} // namespace

bool castToFloat(const Value &v, FloatType t, Value &out, std::string &err)
{
    if (v.isArray || v.isMatrix) {
        bool stopped = false;
        Value fast;
        if (castPackedToFloat(v, t, fast, stopped)) { // any rank (2026-11-21: N-D too)
            if (stopped) {
                err.clear();
                return false;
            }
            out = std::move(fast);
            return true;
        }
    }
    if (v.isND()) {
        // N-D cells (text, mixed ...): element by element, same shape.
        std::vector<Value> cells;
        cells.reserve(v.ndCount());
        nc::par::SerialProgress progress(floatTypeName(t), v.ndCount());
        for (size_t k = 0; k < v.ndCount(); k++) {
            Value cell;
            if (!castToFloat(v.ndAt(k), t, cell, err))
                return false;
            cells.push_back(std::move(cell));
            progress.tick(k);
        }
        out = Value::ndFromCells(v.ndShape(), std::move(cells));
        return true;
    }
    if (v.isArray) {
        std::vector<Value> cells;
        cells.reserve(v.length());
        nc::par::SerialProgress progress(floatTypeName(t), v.length());
        for (size_t i = 0; i < v.length(); i++) {
            Value cell;
            if (!castToFloat(v.at(i), t, cell, err))
                return false;
            cells.push_back(std::move(cell));
            progress.tick(i);
        }
        out = Value(std::move(cells)); // float64 cells pack into a numeric array
        return true;
    }
    if (v.isMatrix) {
        std::vector<std::vector<Value>> rows;
        rows.reserve(v.rows());
        // Cells done / cells in all (rows may differ in length: about).
        nc::par::SerialProgress progress(floatTypeName(t), v.rows() * (v.rows() ? v.rowLength(0) : 0));
        size_t done = 0;
        for (size_t r = 0; r < v.rows(); r++) {
            std::vector<Value> row;
            row.reserve(v.rowLength(r));
            for (size_t c = 0; c < v.rowLength(r); c++) {
                Value cell;
                if (!castToFloat(v.at(r, c), t, cell, err))
                    return false;
                row.push_back(std::move(cell));
                progress.tick(++done);
            }
            rows.push_back(std::move(row));
        }
        out = Value(std::move(rows));
        return true;
    }
    return castScalar(v, t, out, err);
}

FloatType binaryResultFloatType(const Value &a, const Value &b)
{
    if (!isSingleNumber(a) || !isSingleNumber(b))
        return FloatType::Float64;
    const FloatType ta = a.floatType(), tb = b.floatType();
    if (ta == FloatType::Float64)
        return tb;
    if (tb == FloatType::Float64)
        return ta;
    return rank(ta) >= rank(tb) ? ta : tb; // the wider format
}

Value applyFloatType(const Value &result, FloatType t)
{
    if (t == FloatType::Float64 || !isSingleNumber(result) || result.isComplex)
        return result;
    Value out = Value::floating(t, roundToFloatType(t, result.number));
    copyUnit(result, out);
    return out;
}

uint32_t encodeFloatBits(FloatType t, double x)
{
    if (t == FloatType::Float32) {
        const float f = static_cast<float>(x);
        uint32_t bits;
        std::memcpy(&bits, &f, sizeof bits);
        return bits;
    }
    return ncfloat::encodeBits(formatOf(t), x);
}

double decodeFloatBits(FloatType t, uint32_t bits)
{
    if (t == FloatType::Float32) {
        float f;
        std::memcpy(&f, &bits, sizeof f);
        return static_cast<double>(f);
    }
    if (t == FloatType::Float64)
        return 0.0; // not a narrow format; not used
    return ncfloat::decodeBits(formatOf(t), bits);
}
