#pragma once
#include "../../core/value.h"

/* ================= DATA CONVERSION ================= */

Value int_op(Value a);
Value float_op(Value a);
Value str_op(Value a);
Value round_op(Value a, Value decimals);
Value rad2dec_op(Value a);
Value dec2rad_op(Value a);

/* ================= SPACE GENERATORS ================= */

Value space_op(Value start, Value stop, Value points);
Value nlspace_op(Value start, Value end, Value points, Value type);
Value ndspace_op(Value range, Value mean, Value stdDev);
