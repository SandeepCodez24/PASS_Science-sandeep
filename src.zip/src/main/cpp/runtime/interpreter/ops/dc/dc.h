#pragma once
#include "../../core/value.h"

// Same "global out-of-band status flag" convention as statistics.h's
// g_lastStatsOk / vector.h's g_lastVectorOk / geometric.h's
// g_lastGeometricOk: g_lastBuiltinFound only means "the NAME was found in
// a dispatch table", not "the actual computation succeeded with valid
// inputs". Reset once per top-level dispatch call in dc_builtin.cpp; set
// false when an input is rejected (unparseable/non-numeric text passed to
// float(), a non-scalar argument where a single number was required, an
// unrecognized nlspace() type string, a malformed dict() call, a
// non-dict argument to keys()/values()/size()/match_key(), or a
// no-match match_key() lookup). Checked in parser_factor.cpp's
// ExprKind::Call case and nc_bridge_call_dynamic (value_bridge.cpp)
// right alongside g_lastVectorOk/g_lastStatsOk/g_lastGeometricOk. Before
// this flag existed, float("abc") and float([1,2,3]) both silently
// returned 0 with no error, round(3.456, [2,3]) silently rounded to 0
// decimals instead of rejecting the array, and nlspace(...)'s `type`
// argument silently substituted quadratic-ease spacing for ANY
// unrecognized string (including a typo of "log", or the seemingly
// reasonable "linear") - confirmed by direct testing.
extern bool g_lastDcOk;

/* ================= DATA CONVERSION ================= */

Value int_op(Value a);
Value float_op(Value a);
Value str_op(Value a);
Value round_op(Value a, Value decimals);
Value rad2dec_op(Value a);
Value dec2rad_op(Value a);

/* ================= SPACE GENERATORS ================= */

Value space_op(Value start, Value stop, Value points);
Value nlspace_op(Value start, Value end, Value points, Value type);
Value ndspace_op(Value range, Value mean, Value stdDev);
