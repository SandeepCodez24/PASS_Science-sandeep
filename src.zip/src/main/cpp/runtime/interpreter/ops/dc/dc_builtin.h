#pragma once
#include <string>
#include <vector>

#include "../../core/value.h"

Value dcBuiltin(const std::string &name, const std::vector<Value> &args);
