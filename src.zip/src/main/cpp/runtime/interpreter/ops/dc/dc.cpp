#include "dc.h"

#include <cmath>
#include <string>

#include "../../core/output.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* ================= DATA CONVERSION ================= */

Value int_op(Value a) { return Value(std::trunc(a.number)); }

Value float_op(Value a) {
  if (a.isText) {
    try {
      return Value(std::stod(a.text));
    } catch (...) {
      return Value(0.0);
    }
  }
  return Value(a.number);
}

Value str_op(Value a) {
  // Numbers/arrays/matrices get the same textual representation printValue
  // would show; text passes through unchanged.
  return Value(valueToString(a));
}

Value round_op(Value a, Value decimals) {
  int d = static_cast<int>(decimals.number);
  double factor = std::pow(10.0, d);
  if (factor == 0.0)
    return Value(a.number);
  return Value(std::round(a.number * factor) / factor);
}

Value rad2dec_op(Value a) { return Value(a.number * 180.0 / M_PI); }

Value dec2rad_op(Value a) { return Value(a.number * M_PI / 180.0); }

/* ================= SPACE GENERATORS ================= */

Value space_op(Value start, Value stop, Value points) {
  int n = static_cast<int>(points.number);
  std::vector<Value> result;

  if (n <= 0)
    return Value(result);
  if (n == 1) {
    result.push_back(Value(start.number));
    return Value(result);
  }

  double s = start.number, e = stop.number;
  double step = (e - s) / (n - 1);
  for (int i = 0; i < n; i++)
    result.push_back(Value(s + step * i));

  return Value(result);
}

Value nlspace_op(Value start, Value end, Value points, Value type) {
  int n = static_cast<int>(points.number);
  std::vector<Value> result;

  if (n <= 0)
    return Value(result);

  double s = start.number, e = end.number;

  std::string t = type.isText ? type.text : std::string();
  for (char &ch : t)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

  if (n == 1) {
    result.push_back(Value(s));
    return Value(result);
  }

  if (t == "log") {
    // Geometric (logarithmic) spacing. Undefined across/at zero, so fall
    // back to linear spacing in that case.
    if (s == 0.0 || e == 0.0 || (s < 0.0) != (e < 0.0)) {
      double step = (e - s) / (n - 1);
      for (int i = 0; i < n; i++)
        result.push_back(Value(s + step * i));
      return Value(result);
    }

    double sign = (s < 0.0) ? -1.0 : 1.0;
    double logS = std::log(std::fabs(s));
    double logE = std::log(std::fabs(e));
    double step = (logE - logS) / (n - 1);
    for (int i = 0; i < n; i++)
      result.push_back(Value(sign * std::exp(logS + step * i)));
    return Value(result);
  }

  // Default: quadratic-eased spacing (denser near `start`).
  for (int i = 0; i < n; i++) {
    double frac = static_cast<double>(i) / (n - 1);
    double eased = frac * frac;
    result.push_back(Value(s + (e - s) * eased));
  }
  return Value(result);
}

// Peter Acklam's rational approximation of the inverse standard-normal CDF
// (probit function). Public-domain algorithm; accurate to ~1.15e-9.
static double normSInv(double p) {
  if (p <= 0.0)
    p = 1e-10;
  if (p >= 1.0)
    p = 1.0 - 1e-10;

  static const double a[6] = {-3.969683028665376e+01, 2.209460984245205e+02,
                               -2.759285104469687e+02, 1.383577518672690e+02,
                               -3.066479806614716e+01, 2.506628277459239e+00};
  static const double b[5] = {-5.447609879822406e+01, 1.615858368580409e+02,
                               -1.556989798598866e+02, 6.680131188771972e+01,
                               -1.328068155288572e+01};
  static const double c[6] = {-7.784894002430293e-03, -3.223964580411365e-01,
                               -2.400758277161838e+00, -2.549732539343734e+00,
                               4.374664141464968e+00,  2.938163982698783e+00};
  static const double d[4] = {7.784695709041462e-03, 3.224671290700398e-01,
                               2.445134137142996e+00, 3.754408661907416e+00};

  const double pLow = 0.02425;
  const double pHigh = 1.0 - pLow;

  if (p < pLow) {
    double q = std::sqrt(-2.0 * std::log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
           ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
  }

  if (p <= pHigh) {
    double q = p - 0.5;
    double r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q /
           (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0);
  }

  double q = std::sqrt(-2.0 * std::log(1.0 - p));
  return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
          ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
}

Value ndspace_op(Value range, Value mean, Value stdDev) {
  int n = static_cast<int>(range.number);
  std::vector<Value> result;

  if (n <= 0)
    return Value(result);

  double mu = mean.number, sigma = stdDev.number;

  for (int i = 0; i < n; i++) {
    // Evenly spaced quantiles in (0,1), avoiding the 0/1 endpoints where
    // the inverse CDF diverges.
    double p = (i + 1.0) / (n + 1.0);
    double z = normSInv(p);
    result.push_back(Value(mu + sigma * z));
  }

  return Value(result);
}
