#include "dc.h"

#include <cmath>
#include <iostream>
#include <string>

#include "../../core/elementwise.h"
#include "../../core/output.h"
#include "../arithmetic/arithmetic.h" // tryCoerceTextToNumber

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

bool g_lastDcOk = true;

/* ================= DATA CONVERSION ================= */

// int_op/round_op/rad2dec_op/dec2rad_op route through mapElementwise()
// (NumPy/SciPy Parity Roadmap §4.1) instead of reading a.number directly,
// the same silent-wrong-answer-on-an-array bug fixed throughout
// arithmetic.cpp/trigonometric.cpp - scalar behavior is unchanged.

// A complex number is truncated / rounded one part at a time (what MATLAB's
// fix() and round() do).
Value int_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(
        a, [](Cplx z) { return Cplx(std::trunc(z.real()), std::trunc(z.imag())); });
  return mapElementwise(a, [](double x) { return std::trunc(x); });
}

Value float_op(Value a) {
  if (a.isText) {
    // A "num/denom" fraction (a dec2frac() result) is read as the number it
    // stands for; std::stod below would parse only the numerator ("2023/5500"
    // -> 2023).
    double frac;
    if (a.text().find('/') != std::string::npos && tryCoerceTextToNumber(a, frac))
      return Value(frac);
    try {
      return Value(std::stod(a.text()));
    } catch (...) {
      // Was silently returning 0.0 for ANY unparseable string
      // (float("abc")), indistinguishable from a legitimately-parsed
      // "0" - confirmed by direct testing.
      std::cerr << "Error: float() could not parse '" << a.text()
                << "' as a number\n";
      g_lastDcOk = false;
      return Value(0.0);
    }
  }
  if (a.isArray || a.isMatrix || a.isDict) {
    // Was silently reading a.number's default of 0 for any non-text,
    // non-number Value - float([1,2,3]) silently returned 0 with no
    // error at all. Same requireScalar hazard already fixed in
    // statistics.cpp/geometric_builtin.cpp.
    std::cerr << "Error: float() expects a number or a numeric string, not an "
                 "array/matrix/dict\n";
    g_lastDcOk = false;
    return Value(0.0);
  }
  return Value(a.number);
}

Value str_op(Value a) {
  // Numbers/arrays/matrices get the same textual representation printValue
  // would show; text passes through unchanged.
  return Value(valueToString(a));
}

Value round_op(Value a, Value decimals) {
  if (decimals.isArray || decimals.isMatrix || decimals.isText || decimals.isDict) {
    // Was silently reading decimals.number's default of 0 - round(3.456,
    // [2,3]) silently rounded to 0 decimals instead of rejecting the
    // array. Confirmed by direct testing.
    std::cerr << "Error: round()'s decimals argument must be a single number, "
                 "not an array/matrix/text/dict\n";
    g_lastDcOk = false;
    return Value(0);
  }
  // decimals is a COUNT of decimal places, not a general real-valued
  // parameter - "2.7 decimal places" is meaningless, but was silently
  // truncated with no error (round(3.456, 2.7) silently rounded to 2
  // places). Also bounded to what a double can actually resolve (~15
  // significant digits) - an unbounded decimals silently overflowed
  // 10^decimals to `inf`, producing a silent NaN result with no error
  // (round(3.456, 1000) silently gave "nan"). Both confirmed by direct
  // testing. Negative values are still allowed (rounding to the nearest
  // 10s/100s/... is a legitimate, pre-existing use, unlike the point
  // counts elsewhere in this file which must be non-negative).
  if (decimals.hasComplex()) {
    std::cerr << "Error: round()'s decimals argument must be a real whole number\n";
    g_lastDcOk = false;
    return Value(0);
  }
  if (std::abs(decimals.number - std::round(decimals.number)) > 1e-9) {
    std::cerr << "Error: round()'s decimals argument must be a whole number, got "
              << decimals.number << "\n";
    g_lastDcOk = false;
    return Value(0);
  }
  if (decimals.number < -15 || decimals.number > 15) {
    std::cerr << "Error: round()'s decimals argument must be between -15 and 15 "
                 "(double precision can't resolve more), got "
              << decimals.number << "\n";
    g_lastDcOk = false;
    return Value(0);
  }
  int d = static_cast<int>(decimals.number);
  double factor = std::pow(10.0, d);
  if (a.hasComplex()) {
    if (factor == 0.0)
      return a;
    return mapElementwiseC(a, [factor](Cplx z) {
      return Cplx(std::round(z.real() * factor) / factor, std::round(z.imag() * factor) / factor);
    });
  }
  if (factor == 0.0)
    return mapElementwise(a, [](double x) { return x; });
  return mapElementwise(a, [factor](double x) { return std::round(x * factor) / factor; });
}

Value rad2dec_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return z * (180.0 / M_PI); });
  return mapElementwise(a, [](double x) { return x * 180.0 / M_PI; });
}

Value dec2rad_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return z * (M_PI / 180.0); });
  return mapElementwise(a, [](double x) { return x * M_PI / 180.0; });
}

/* ================= SPACE GENERATORS ================= */

namespace {
// A point count is a whole number of samples, not a general real-valued
// parameter - it can legitimately be 0 (an empty result, same as MATLAB's
// linspace(a,b,0)), but a NEGATIVE count is meaningless and a FRACTIONAL
// count ("3.9 points") is meaningless too. Both used to be silently
// accepted: a negative count was treated identically to 0 (space(0,10,-5)
// silently returned [], indistinguishable from a legitimate zero-points
// request), and a fractional count was silently truncated with no
// warning (space(0,10,3.9) silently returned 3 points). Confirmed by
// direct testing.
bool requireValidPointCount(double raw, const char *fn, int &outN) {
  if (raw < 0) {
    std::cerr << "Error: " << fn << "'s point count must be non-negative, got " << raw
              << "\n";
    g_lastDcOk = false;
    return false;
  }
  if (std::abs(raw - std::round(raw)) > 1e-9) {
    std::cerr << "Error: " << fn << "'s point count must be a whole number, got " << raw
              << "\n";
    g_lastDcOk = false;
    return false;
  }
  outN = static_cast<int>(std::round(raw));
  return true;
}
} // namespace

Value space_op(Value start, Value stop, Value points) {
  int n;
  std::vector<Value> result;
  if (!requireValidPointCount(points.number, "space", n))
    return Value(result);

  if (n <= 0)
    return Value(result);
  if (n == 1) {
    result.push_back(Value(start.number));
    return Value(result);
  }

  double s = start.number, e = stop.number;
  double step = (e - s) / (n - 1);
  for (int i = 0; i < n; i++)
    result.push_back(Value(s + step * i));

  return Value(result);
}

Value nlspace_op(Value start, Value end, Value points, Value type) {
  int n;
  std::vector<Value> result;
  if (!requireValidPointCount(points.number, "nlspace", n))
    return Value(result);

  if (n <= 0)
    return Value(result);

  double s = start.number, e = end.number;

  std::string t = type.isText ? type.text() : std::string();
  for (char &ch : t)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

  // Was silently substituting the quadratic-ease branch below for ANY
  // string that wasn't exactly "log" - a typo of "log" (e.g. "lgo"), or
  // the seemingly reasonable "linear" (which this function never actually
  // implemented, despite space_op() above already being pure linear
  // spacing under a different name), all silently got quadratic-ease
  // spacing instead, indistinguishable from a legitimate request and with
  // no diagnostic that the type string wasn't recognized. Confirmed by
  // direct testing. Now requires one of the three actually-implemented
  // types explicitly.
  if (t != "log" && t != "linear" && t != "quad") {
    std::cerr << "Error: nlspace()'s type must be \"linear\", \"log\", or "
                 "\"quad\", got \""
              << (type.isText ? type.text() : std::string("<non-text>")) << "\"\n";
    g_lastDcOk = false;
    return Value(result);
  }

  if (n == 1) {
    result.push_back(Value(s));
    return Value(result);
  }

  if (t == "linear") {
    double step = (e - s) / (n - 1);
    for (int i = 0; i < n; i++)
      result.push_back(Value(s + step * i));
    return Value(result);
  }

  if (t == "log") {
    // Geometric (logarithmic) spacing. Undefined across/at zero, so fall
    // back to linear spacing in that case - but SAY so: this substitutes
    // a different algorithm than the one explicitly requested, the same
    // class of "silently deliver something other than what was asked for"
    // issue this function's own unrecognized-type check above now
    // rejects outright. A fallback is still reasonable here (there's no
    // sane way to do log spacing across zero), but doing it silently
    // isn't - confirmed by direct testing (nlspace(-5,5,5,"log") silently
    // returned linearly-spaced output with no indication "log" wasn't
    // actually honored).
    if (s == 0.0 || e == 0.0 || (s < 0.0) != (e < 0.0)) {
      std::cerr << "Warning: nlspace() can't do \"log\" spacing across/at zero "
                   "(start="
                << s << ", end=" << e << ") - falling back to linear spacing\n";
      double step = (e - s) / (n - 1);
      for (int i = 0; i < n; i++)
        result.push_back(Value(s + step * i));
      return Value(result);
    }

    double sign = (s < 0.0) ? -1.0 : 1.0;
    double logS = std::log(std::fabs(s));
    double logE = std::log(std::fabs(e));
    double step = (logE - logS) / (n - 1);
    for (int i = 0; i < n; i++)
      result.push_back(Value(sign * std::exp(logS + step * i)));
    return Value(result);
  }

  // t == "quad": quadratic-eased spacing (denser near `start`).
  for (int i = 0; i < n; i++) {
    double frac = static_cast<double>(i) / (n - 1);
    double eased = frac * frac;
    result.push_back(Value(s + (e - s) * eased));
  }
  return Value(result);
}

// Peter Acklam's rational approximation of the inverse standard-normal CDF
// (probit function). Public-domain algorithm; accurate to ~1.15e-9.
static double normSInv(double p) {
  if (p <= 0.0)
    p = 1e-10;
  if (p >= 1.0)
    p = 1.0 - 1e-10;

  static const double a[6] = {-3.969683028665376e+01, 2.209460984245205e+02,
                               -2.759285104469687e+02, 1.383577518672690e+02,
                               -3.066479806614716e+01, 2.506628277459239e+00};
  static const double b[5] = {-5.447609879822406e+01, 1.615858368580409e+02,
                               -1.556989798598866e+02, 6.680131188771972e+01,
                               -1.328068155288572e+01};
  static const double c[6] = {-7.784894002430293e-03, -3.223964580411365e-01,
                               -2.400758277161838e+00, -2.549732539343734e+00,
                               4.374664141464968e+00,  2.938163982698783e+00};
  static const double d[4] = {7.784695709041462e-03, 3.224671290700398e-01,
                               2.445134137142996e+00, 3.754408661907416e+00};

  const double pLow = 0.02425;
  const double pHigh = 1.0 - pLow;

  if (p < pLow) {
    double q = std::sqrt(-2.0 * std::log(p));
    return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
           ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
  }

  if (p <= pHigh) {
    double q = p - 0.5;
    double r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q /
           (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0);
  }

  double q = std::sqrt(-2.0 * std::log(1.0 - p));
  return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) /
          ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0);
}

Value ndspace_op(Value range, Value mean, Value stdDev) {
  int n;
  std::vector<Value> result;
  if (!requireValidPointCount(range.number, "ndspace", n))
    return Value(result);

  if (n <= 0)
    return Value(result);

  double mu = mean.number, sigma = stdDev.number;

  // A standard deviation is, by definition, non-negative - a negative
  // sigma isn't "a differently-shaped distribution", it silently mirrors
  // every sample around the mean instead (ndspace(5,0,-1) produced the
  // exact mirror image of ndspace(5,0,1)) with no error at all. Confirmed
  // by direct testing.
  if (sigma < 0) {
    std::cerr << "Error: ndspace's stdDev must be non-negative, got " << sigma << "\n";
    g_lastDcOk = false;
    return Value(result);
  }

  for (int i = 0; i < n; i++) {
    // Evenly spaced quantiles in (0,1), avoiding the 0/1 endpoints where
    // the inverse CDF diverges.
    double p = (i + 1.0) / (n + 1.0);
    double z = normSInv(p);
    result.push_back(Value(mu + sigma * z));
  }

  return Value(result);
}
