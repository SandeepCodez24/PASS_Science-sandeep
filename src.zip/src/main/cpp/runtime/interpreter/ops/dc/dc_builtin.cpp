#include "dc_builtin.h"
#include "dc.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

#include "../../../../compiler/compiler_src/conditional_opr/conditional_opr.h"
#include "../../core/output.h"

// A dict key needs a well-defined, canonical string identity - text and
// number both have one, but an array/matrix/dict/object doesn't (there's
// no single obvious string form for "the array [5,6]"). Was falling back
// to key.number, which defaults to 0 for every one of those kinds, so ANY
// array/matrix/dict-typed key silently became the same string key "0" as
// every other one - two DIFFERENT keys ([5,6] and [7,8]) collided into a
// single dict entry, silently discarding one of the two values, with no
// error at all. Confirmed by direct testing.
static bool dictKeyOf(const Value &key, std::string &out) {
  if (key.isText) {
    out = key.text();
    return true;
  }
  if (key.isArray || key.isMatrix || key.isDict || key.isObject) {
    std::cerr << "Error: dict() keys must be a number or string, not a(n) "
              << valueKindName(key) << "\n";
    g_lastDcOk = false;
    return false;
  }
  out = formatNumber(key.number);
  return true;
}

static Value buildDict(const std::vector<Value> &args) {
  std::unordered_map<std::string, Value> dict;

  if (args.empty())
    return Value(dict);

  if (args.size() != 2 || !args[0].isArray || !args[1].isArray ||
      args[0].length() != args[1].length()) {
    std::cerr << "Error: Function 'dict' expects either no args or two "
                 "equal-length arrays (keys, values)\n";
    g_lastDcOk = false;
    return Value();
  }

  for (size_t i = 0; i < args[0].length(); i++) {
    std::string key;
    if (!dictKeyOf(args[0].at(i), key))
      return Value();
    dict[key] = args[1].at(i);
  }

  return Value(dict);
}

static Value dictKeys(const Value &d) {
  std::vector<Value> out;
  for (const auto &kv : d.dict())
    out.push_back(Value(kv.first));
  return Value(out);
}

static Value dictValues(const Value &d) {
  std::vector<Value> out;
  for (const auto &kv : d.dict())
    out.push_back(kv.second);
  return Value(out);
}

static Value dictSize(const Value &d) {
  return Value(static_cast<double>(d.dict().size()));
}

// Spec: match_key takes a VALUE and returns the KEY that maps to it
// (reverse lookup), e.g. Key_1 = Dict_Variable.match_key['value_1'].
//
// Was falling back to comparing .number for anything that wasn't a
// text/text pair - .number defaults to 0 for EVERY array/matrix/dict, so
// any two array-valued (or matrix/dict-valued) dict entries compared as
// "equal" regardless of their actual contents. Confirmed by direct
// testing: with dict values [1,1] (key "a") and [2,2] (key "b"),
// match_key(d, [9,9]) - a target matching NEITHER stored value - still
// confidently returned "b", a fabricated match, not merely a missing-
// validation gap. Now delegates to the same structural/deep-equality
// helper conditional_opr.h's == operator already uses, so "same value"
// means the same thing here as it does everywhere else in the language.
static bool dictValueMatches(const Value &stored, const Value &target) {
  return valuesDeepEqual(stored, target);
}

static Value dictMatchKey(const Value &d, const Value &target) {
  for (const auto &kv : d.dict()) {
    if (dictValueMatches(kv.second, target))
      return Value(kv.first);
  }
  std::cerr << "Error: 'match_key' found no key for the given value\n";
  g_lastDcOk = false;
  return Value();
}

Value dcBuiltin(const std::string &name, const std::vector<Value> &args) {
  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      g_lastDcOk = false;
      return false;
    }
    return true;
  };

  // Same requireScalar hazard already fixed in statistics.cpp/
  // geometric_builtin.cpp: space()/nlspace()/ndspace()'s numeric arguments
  // read straight off `.number` with no check, so a non-scalar argument
  // silently defaulted to 0 instead of erroring (e.g. space(0,10,[5])
  // silently returned an empty array, having read points as 0). Originally
  // missed isText specifically - space("hello",10,5) silently read
  // start=0 too, with no error, since text wasn't in the rejection list.
  // Confirmed by direct testing.
  auto require_scalar = [](const Value &v, const std::string &fn,
                            const std::string &argDesc) -> bool {
    if (v.isArray || v.isMatrix || v.isText || v.isDict) {
      std::cerr << "Error: " << fn << "'s " << argDesc
                << " must be a single number, not an array/matrix/text/dict\n";
      g_lastDcOk = false;
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {
      {"int",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "int", 1)) return Value();
         return int_op(a[0]);
       }},

      {"float",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "float", 1)) return Value();
         return float_op(a[0]);
       }},

      {"str",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "str", 1)) return Value();
         return str_op(a[0]);
       }},

      {"round",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "round", 2)) return Value();
         return round_op(a[0], a[1]);
       }},

      {"rad2dec",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "rad2dec", 1)) return Value();
         return rad2dec_op(a[0]);
       }},

      {"dec2rad",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "dec2rad", 1)) return Value();
         return dec2rad_op(a[0]);
       }},

      {"space",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "space", 3)) return Value();
         if (!require_scalar(a[0], "space", "start") ||
             !require_scalar(a[1], "space", "stop") ||
             !require_scalar(a[2], "space", "points"))
           return Value();
         return space_op(a[0], a[1], a[2]);
       }},

      {"nlspace",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "nlspace", 4)) return Value();
         if (!require_scalar(a[0], "nlspace", "start") ||
             !require_scalar(a[1], "nlspace", "end") ||
             !require_scalar(a[2], "nlspace", "points"))
           return Value();
         return nlspace_op(a[0], a[1], a[2], a[3]);
       }},

      {"ndspace",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "ndspace", 3)) return Value();
         if (!require_scalar(a[0], "ndspace", "range") ||
             !require_scalar(a[1], "ndspace", "mean") ||
             !require_scalar(a[2], "ndspace", "stdDev"))
           return Value();
         return ndspace_op(a[0], a[1], a[2]);
       }},

      {"dict",
       [](const std::vector<Value> &a) -> Value {
         return buildDict(a);
       }},

      {"keys",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "keys", 1)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'keys' expects a dict\n";
           g_lastDcOk = false;
           return Value();
         }
         return dictKeys(a[0]);
       }},

      {"values",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "values", 1)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'values' expects a dict\n";
           g_lastDcOk = false;
           return Value();
         }
         return dictValues(a[0]);
       }},

      {"size",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "size", 1)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'size' expects a dict\n";
           g_lastDcOk = false;
           return Value();
         }
         return dictSize(a[0]);
       }},

      {"match_key",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "match_key", 2)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'match_key' expects a dict\n";
           g_lastDcOk = false;
           return Value();
         }
         return dictMatchKey(a[0], a[1]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass) - see matrix_builtin.cpp for
  // the first fix of this kind and the full reasoning.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown data-conversion function '" << name << "'\n";
    g_lastDcOk = false;
    return Value();
  }

  // Reset here, once per top-level dispatch call, rather than inside every
  // individual dc.cpp function - matches the statistics.cpp/
  // geometric_builtin.cpp precedent.
  g_lastDcOk = true;

  return it->second(args);
}
