#include "dc_builtin.h"
#include "dc.h"

#include <functional>
#include <iostream>
#include <unordered_map>

#include "../../core/output.h"

static std::string dictKeyOf(const Value &key) {
  return key.isText ? key.text : formatNumber(key.number);
}

static Value buildDict(const std::vector<Value> &args) {
  std::unordered_map<std::string, Value> dict;

  if (args.empty())
    return Value(dict);

  if (args.size() != 2 || !args[0].isArray || !args[1].isArray ||
      args[0].array.size() != args[1].array.size()) {
    std::cerr << "Error: Function 'dict' expects either no args or two "
                 "equal-length arrays (keys, values)\n";
    return Value();
  }

  for (size_t i = 0; i < args[0].array.size(); i++)
    dict[dictKeyOf(args[0].array[i])] = args[1].array[i];

  return Value(dict);
}

static Value dictKeys(const Value &d) {
  std::vector<Value> out;
  for (const auto &kv : d.dictMap)
    out.push_back(Value(kv.first));
  return Value(out);
}

static Value dictValues(const Value &d) {
  std::vector<Value> out;
  for (const auto &kv : d.dictMap)
    out.push_back(kv.second);
  return Value(out);
}

static Value dictSize(const Value &d) {
  return Value(static_cast<double>(d.dictMap.size()));
}

// Spec: match_key takes a VALUE and returns the KEY that maps to it
// (reverse lookup), e.g. Key_1 = Dict_Variable.match_key['value_1'].
static bool dictValueMatches(const Value &stored, const Value &target) {
  if (stored.isText && target.isText)
    return stored.text == target.text;
  if (stored.isText != target.isText)
    return false;
  return stored.number == target.number;
}

static Value dictMatchKey(const Value &d, const Value &target) {
  for (const auto &kv : d.dictMap) {
    if (dictValueMatches(kv.second, target))
      return Value(kv.first);
  }
  std::cerr << "Error: 'match_key' found no key for the given value\n";
  return Value();
}

Value dcBuiltin(const std::string &name, const std::vector<Value> &args) {
  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {
      {"int",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("int", 1)) return Value();
         return int_op(a[0]);
       }},

      {"float",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("float", 1)) return Value();
         return float_op(a[0]);
       }},

      {"str",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("str", 1)) return Value();
         return str_op(a[0]);
       }},

      {"round",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("round", 2)) return Value();
         return round_op(a[0], a[1]);
       }},

      {"rad2dec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("rad2dec", 1)) return Value();
         return rad2dec_op(a[0]);
       }},

      {"dec2rad",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("dec2rad", 1)) return Value();
         return dec2rad_op(a[0]);
       }},

      {"space",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("space", 3)) return Value();
         return space_op(a[0], a[1], a[2]);
       }},

      {"nlspace",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("nlspace", 4)) return Value();
         return nlspace_op(a[0], a[1], a[2], a[3]);
       }},

      {"ndspace",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("ndspace", 3)) return Value();
         return ndspace_op(a[0], a[1], a[2]);
       }},

      {"dict",
       [&](const std::vector<Value> &a) -> Value {
         return buildDict(a);
       }},

      {"keys",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("keys", 1)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'keys' expects a dict\n";
           return Value();
         }
         return dictKeys(a[0]);
       }},

      {"values",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("values", 1)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'values' expects a dict\n";
           return Value();
         }
         return dictValues(a[0]);
       }},

      {"size",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("size", 1)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'size' expects a dict\n";
           return Value();
         }
         return dictSize(a[0]);
       }},

      {"match_key",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("match_key", 2)) return Value();
         if (!a[0].isDict) {
           std::cerr << "Error: 'match_key' expects a dict\n";
           return Value();
         }
         return dictMatchKey(a[0], a[1]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown data-conversion function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}
