// Partial differential equations (Kreyszig chapter 12): separation of
// variables, D'Alembert's solution and transform methods.
//   solve_wave_1d_fourier  solve_wave_1d_dalembert  solve_heat_1d_fourier
//   solve_heat_1d_fourier_integral  solve_wave_2d_rectangular
//   solve_wave_2d_circular_bessel  solve_laplace_2d_polar
//   solve_laplace_3d_spherical  pde_solve_laplace_transform
//
// Results on a space-time grid are matrices U[i, j] = u(x_j, t_i): one row
// per time, one column per position. The rectangular membrane gives an N-D
// matrix [nt, ny, nx] (a plain matrix for one time). The series
// coefficients come first (with the NC calls, on the interpreter thread);
// summing the series on the grid goes through par (multicore-ready).
#include <cmath>

#include "../../Scipy/special_functions/sf_core.h"
#include "../fourier/fourier_core.h"

namespace nc {
namespace ops {

namespace {

// u[i, j] from a per-row filler, rows in parallel blocks.
template <class RowFn> Mat gridRows(size_t nt, size_t nx, RowFn fill) {
  Mat U(nt, nx);
  par::forBlocks(nt, {par::Kind::Compute, 50.0 * static_cast<double>(nx)},
                 [&](size_t b, size_t e) {
                   for (size_t i = b; i < e; i++)
                     fill(i, U.row(i));
                 });
  return U;
}

// First n positive zeros of J0 (Newton from McMahon's estimate).
Vec besselJ0Zeros(size_t n) {
  Vec z(n);
  for (size_t m = 1; m <= n; m++) {
    const double b = (static_cast<double>(m) - 0.25) * kPi;
    double x = b + 1.0 / (8.0 * b);
    for (int it = 0; it < 50; it++) {
      const double dx = scipy::sf::besselj(0.0, x) / -scipy::sf::besselj(1.0, x);
      x -= dx;
      if (std::abs(dx) < 1e-15 * x)
        break;
    }
    z[m - 1] = x;
  }
  return z;
}

// P_0 .. P_N at x (three-term recurrence).
Vec legendreAll(size_t N, double x) {
  Vec P(N + 1);
  P[0] = 1.0;
  if (N >= 1)
    P[1] = x;
  for (size_t n = 2; n <= N; n++)
    P[n] = ((2.0 * n - 1.0) * x * P[n - 1] - (n - 1.0) * P[n - 2]) / static_cast<double>(n);
  return P;
}

bool argNonNegVec(const Args &a, size_t i, CallContext &ctx, Vec &v, const char *what) {
  if (!argVec(a, i, ctx, v))
    return false;
  for (double d : v)
    if (d < 0.0) {
      ctx.fail(std::string(what) + " must not be negative");
      return false;
    }
  return true;
}

// Composite Gauss-Legendre nodes on [lo, hi]: `panels` panels of 8 points.
void compositeGL(double lo, double hi, size_t panels, Vec &x, Vec &w) {
  Vec gx, gw;
  gaussLegendre(8, gx, gw);
  x.clear();
  w.clear();
  const double h = (hi - lo) / static_cast<double>(panels);
  for (size_t p = 0; p < panels; p++) {
    const double c = lo + (p + 0.5) * h;
    for (size_t k = 0; k < 8; k++) {
      x.push_back(c + 0.5 * h * gx[k]);
      w.push_back(0.5 * h * gw[k]);
    }
  }
}

} // namespace

#define OPS_DOMAIN Domain::Pde

void registerPde(OpsRegistry &reg) {

  // ---- 1-D wave equation u_tt = c^2 u_xx, u(0) = u(L) = 0 (Kreyszig 12.3) ----
  OPS_FN("solve_wave_1d_fourier", 7, 7, "solve_wave_1d_fourier(f, g, L, c, x, t, N)",
         "Vibrating string series", kCallsNC | kKernel) {
    Fn f, g;
    double L, c;
    Vec x, t;
    long long N;
    if (!argFn(a, 0, ctx, f) || !argFn(a, 1, ctx, g) || !argPositive(a, 2, ctx, L) ||
        !argPositive(a, 3, ctx, c) || !argVec(a, 4, ctx, x) ||
        !argNonNegVec(a, 5, ctx, t, "t") || !argCount(a, 6, ctx, N, 1, 1000))
      return Value();
    const size_t n = static_cast<size_t>(N);
    Vec B, Bs(n, 0.0);
    if (!fourier::sineCoefficients(f, L, n, B, ctx))
      return Value();
    if (!(g.isConstant() && g.c(0.0) == cd(0.0))) {
      Vec G;
      if (!fourier::sineCoefficients(g, L, n, G, ctx))
        return Value();
      for (size_t k = 0; k < n; k++)
        Bs[k] = G[k] * L / (c * (k + 1.0) * kPi); // B*_n = (2/(c n pi)) int g sin
    }
    // u = sum (B_n cos(l_n t) + B*_n sin(l_n t)) sin(n pi x / L), l_n = c n pi / L
    return matOf(gridRows(t.size(), x.size(), [&](size_t i, double *row) {
      for (size_t j = 0; j < x.size(); j++) {
        double s = 0.0;
        for (size_t k = 0; k < n; k++) {
          const double nn = k + 1.0, l = c * nn * kPi / L;
          s += (B[k] * std::cos(l * t[i]) + Bs[k] * std::sin(l * t[i])) *
               std::sin(nn * kPi * x[j] / L);
        }
        row[j] = s;
      }
    }));
  }
  OPS_END

  OPS_FN("solve_wave_1d_dalembert", 5, 5, "solve_wave_1d_dalembert(f, g, c, x, t)",
         "D'Alembert wave solution", kCallsNC) {
    Fn f, g;
    double c;
    Vec x, t;
    if (!argFn(a, 0, ctx, f) || !argFn(a, 1, ctx, g) || !argPositive(a, 2, ctx, c) ||
        !argVec(a, 3, ctx, x) || !argNonNegVec(a, 4, ctx, t, "t"))
      return Value();
    // u = [f(x + ct) + f(x - ct)] / 2 + (1/2c) integral from x - ct to x + ct of g  (Kreyszig 12.4)
    const bool gZero = g.isConstant() && g.c(0.0) == cd(0.0);
    const bool gConst = g.isConstant();
    Mat U(t.size(), x.size());
    for (size_t i = 0; i < t.size(); i++)
      for (size_t j = 0; j < x.size(); j++) {
        const double lo = x[j] - c * t[i], hi = x[j] + c * t[i];
        double u = 0.5 * (f.r(hi) + f.r(lo));
        if (!gZero && hi > lo) {
          if (gConst) {
            u += g.c(0.0).real() * t[i];
          } else {
            QuadResult q = quadVec(
                [&](double s, double *out) {
                  out[0] = g.r(s);
                  return !g.failed();
                },
                1, lo, hi, 1e-12, 1e-10, 2000);
            u += q.value[0] / (2.0 * c);
          }
        }
        U(i, j) = u;
        if (f.failed() || g.failed())
          break;
      }
    if (!fnOk(f, ctx) || !fnOk(g, ctx))
      return Value();
    return matOf(U);
  }
  OPS_END

  // ---- 1-D heat equation u_t = c^2 u_xx, u(0) = u(L) = 0 (Kreyszig 12.6) ----
  OPS_FN("solve_heat_1d_fourier", 6, 6, "solve_heat_1d_fourier(f, L, c, x, t, N)",
         "Heat equation series", kCallsNC | kKernel) {
    Fn f;
    double L, c;
    Vec x, t;
    long long N;
    if (!argFn(a, 0, ctx, f) || !argPositive(a, 1, ctx, L) || !argPositive(a, 2, ctx, c) ||
        !argVec(a, 3, ctx, x) || !argNonNegVec(a, 4, ctx, t, "t") ||
        !argCount(a, 5, ctx, N, 1, 1000))
      return Value();
    const size_t n = static_cast<size_t>(N);
    Vec B;
    if (!fourier::sineCoefficients(f, L, n, B, ctx))
      return Value();
    // u = sum B_n sin(n pi x / L) e^(-l_n^2 t), l_n = c n pi / L
    return matOf(gridRows(t.size(), x.size(), [&](size_t i, double *row) {
      for (size_t j = 0; j < x.size(); j++) {
        double s = 0.0;
        for (size_t k = 0; k < n; k++) {
          const double nn = k + 1.0, l = c * nn * kPi / L;
          s += B[k] * std::sin(nn * kPi * x[j] / L) * std::exp(-l * l * t[i]);
        }
        row[j] = s;
      }
    }));
  }
  OPS_END

  OPS_FN("solve_heat_1d_fourier_integral", 4, 4, "solve_heat_1d_fourier_integral(f, c, x, t)",
         "Heat equation, infinite bar", kCallsNC) {
    Fn f;
    double c;
    Vec x, t;
    if (!argFn(a, 0, ctx, f) || !argPositive(a, 1, ctx, c) || !argVec(a, 2, ctx, x) ||
        !argNonNegVec(a, 3, ctx, t, "t"))
      return Value();
    // u(x, t) = 1/(2c sqrt(pi t)) integral of f(v) exp(-(x - v)^2 / (4 c^2 t)) dv
    //         = 1/sqrt(pi) integral of f(x + 2c sqrt(t) z) e^(-z^2) dz  (Kreyszig 12.7)
    Mat U(t.size(), x.size());
    for (size_t i = 0; i < t.size(); i++)
      for (size_t j = 0; j < x.size(); j++) {
        if (t[i] == 0.0) {
          U(i, j) = f.r(x[j]);
          continue;
        }
        const double s = 2.0 * c * std::sqrt(t[i]);
        QuadResult q = quadVec(
            [&](double z, double *out) {
              out[0] = f.r(x[j] + s * z) * std::exp(-z * z);
              return !f.failed();
            },
            1, -9.0, 9.0, 1e-12, 1e-10, 2000);
        U(i, j) = q.value[0] / std::sqrt(kPi);
        if (f.failed())
          break;
      }
    if (!fnOk(f, ctx))
      return Value();
    return matOf(U);
  }
  OPS_END

  // ---- rectangular membrane, double Fourier series (Kreyszig 12.9) ----
  OPS_FN("solve_wave_2d_rectangular", 10, 10,
         "solve_wave_2d_rectangular(f, g, a, b, c, x, y, t, N, M)", "Rectangular membrane",
         kCallsNC | kKernel | kNDArgs) {
    Fn f, g;
    double A, Bw, c;
    Vec x, y, t;
    long long N, M;
    if (!argFn(a, 0, ctx, f) || !argFn(a, 1, ctx, g) || !argPositive(a, 2, ctx, A) ||
        !argPositive(a, 3, ctx, Bw) || !argPositive(a, 4, ctx, c) || !argVec(a, 5, ctx, x) ||
        !argVec(a, 6, ctx, y) || !argNonNegVec(a, 7, ctx, t, "t") ||
        !argCount(a, 8, ctx, N, 1, 200) || !argCount(a, 9, ctx, M, 1, 200))
      return Value();
    const size_t nm = static_cast<size_t>(N), nn = static_cast<size_t>(M);
    // B_mn = 4/(ab) double integral of f sin(m pi x/a) sin(n pi y/b), by a
    // tensor Gauss-Legendre rule fine enough for the highest mode.
    Vec qx, wx, qy, wy;
    compositeGL(0.0, A, std::max<size_t>(4, nm / 2 + 2), qx, wx);
    compositeGL(0.0, Bw, std::max<size_t>(4, nn / 2 + 2), qy, wy);
    const bool gZero = g.isConstant() && g.c(0.0) == cd(0.0);
    Mat F(qy.size(), qx.size()), G(qy.size(), qx.size());
    for (size_t iy = 0; iy < qy.size(); iy++)
      for (size_t ix = 0; ix < qx.size(); ix++) {
        F(iy, ix) = f.r2(qx[ix], qy[iy]);
        G(iy, ix) = gZero ? 0.0 : g.r2(qx[ix], qy[iy]);
      }
    if (!fnOk(f, ctx) || !fnOk(g, ctx))
      return Value();
    Mat Bc(nm, nn), Bs(nm, nn), lam(nm, nn);
    for (size_t m = 0; m < nm; m++)
      for (size_t n = 0; n < nn; n++) {
        double sf = 0.0, sg = 0.0;
        for (size_t iy = 0; iy < qy.size(); iy++) {
          const double sy = std::sin((n + 1.0) * kPi * qy[iy] / Bw) * wy[iy];
          double rf = 0.0, rg = 0.0;
          for (size_t ix = 0; ix < qx.size(); ix++) {
            const double sx = std::sin((m + 1.0) * kPi * qx[ix] / A) * wx[ix];
            rf += F(iy, ix) * sx;
            rg += G(iy, ix) * sx;
          }
          sf += rf * sy;
          sg += rg * sy;
        }
        const double l = c * kPi * std::sqrt(std::pow((m + 1.0) / A, 2) + std::pow((n + 1.0) / Bw, 2));
        lam(m, n) = l;
        Bc(m, n) = 4.0 / (A * Bw) * sf;
        Bs(m, n) = 4.0 / (A * Bw * l) * sg;
      }
    Grid out(t.size(), y.size(), x.size(), 3);
    par::forBlocks(t.size(), {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
      for (size_t k = b; k < e; k++)
        for (size_t i = 0; i < y.size(); i++)
          for (size_t j = 0; j < x.size(); j++) {
            double s = 0.0;
            for (size_t m = 0; m < nm; m++) {
              const double sx = std::sin((m + 1.0) * kPi * x[j] / A);
              for (size_t n = 0; n < nn; n++)
                s += (Bc(m, n) * std::cos(lam(m, n) * t[k]) + Bs(m, n) * std::sin(lam(m, n) * t[k])) *
                     sx * std::sin((n + 1.0) * kPi * y[i] / Bw);
            }
            out.at(k, i, j) = s;
          }
    });
    if (t.size() == 1)
      out.rank = 2;
    return gridValue(out);
  }
  OPS_END

  // ---- circular membrane, radially symmetric (Kreyszig 12.10) ----
  OPS_FN("solve_wave_2d_circular_bessel", 7, 7,
         "solve_wave_2d_circular_bessel(f, g, R, c, r, t, N)", "Circular membrane (drum)",
         kCallsNC | kKernel) {
    Fn f, g;
    double R, c;
    Vec r, t;
    long long N;
    if (!argFn(a, 0, ctx, f) || !argFn(a, 1, ctx, g) || !argPositive(a, 2, ctx, R) ||
        !argPositive(a, 3, ctx, c) || !argNonNegVec(a, 4, ctx, r, "r") ||
        !argNonNegVec(a, 5, ctx, t, "t") || !argCount(a, 6, ctx, N, 1, 500))
      return Value();
    for (double v : r)
      if (v > R) {
        ctx.fail("every r must be within the membrane, 0 <= r <= R");
        return Value();
      }
    const size_t n = static_cast<size_t>(N);
    const Vec al = besselJ0Zeros(n);
    // A_m = 2/(R^2 J1(al_m)^2) integral 0..R of r f(r) J0(al_m r / R) dr,
    // B_m = 2/(c al_m R J1(al_m)^2) integral 0..R of r g(r) J0(al_m r / R) dr.
    QuadResult q = quadVec(
        [&](double s, double *out) {
          const double fs = f.r(s), gs = g.r(s);
          for (size_t m = 0; m < n; m++) {
            const double j0 = scipy::sf::besselj(0.0, al[m] * s / R);
            out[2 * m] = s * fs * j0;
            out[2 * m + 1] = s * gs * j0;
          }
          return !f.failed() && !g.failed();
        },
        2 * n, 0.0, R, 1e-13, 1e-11, 4000);
    if (!fnOk(f, ctx) || !fnOk(g, ctx))
      return Value();
    Vec Am(n), Bm(n), lam(n);
    for (size_t m = 0; m < n; m++) {
      const double j1 = scipy::sf::besselj(1.0, al[m]);
      Am[m] = 2.0 / (R * R * j1 * j1) * q.value[2 * m];
      Bm[m] = 2.0 / (c * al[m] * R * j1 * j1) * q.value[2 * m + 1];
      lam[m] = c * al[m] / R;
    }
    return matOf(gridRows(t.size(), r.size(), [&](size_t i, double *row) {
      for (size_t j = 0; j < r.size(); j++) {
        double s = 0.0;
        for (size_t m = 0; m < n; m++)
          s += (Am[m] * std::cos(lam[m] * t[i]) + Bm[m] * std::sin(lam[m] * t[i])) *
               scipy::sf::besselj(0.0, al[m] * r[j] / R);
        row[j] = s;
      }
    }));
  }
  OPS_END

  // ---- Laplace's equation in a disk (Kreyszig 12.10 / 18.4) ----
  OPS_FN("solve_laplace_2d_polar", 5, 5, "solve_laplace_2d_polar(f, R, r, theta, N)",
         "Laplace equation, disk", kCallsNC | kKernel) {
    Fn f;
    double R;
    Vec r, th;
    long long N;
    if (!argFn(a, 0, ctx, f) || !argPositive(a, 1, ctx, R) || !argNonNegVec(a, 2, ctx, r, "r") ||
        !argVec(a, 3, ctx, th) || !argCount(a, 4, ctx, N, 1, 1000))
      return Value();
    double a0;
    Vec an, bn;
    if (!fourier::realSeries(f, -kPi, 2.0 * kPi, static_cast<size_t>(N), a0, an, bn, ctx))
      return Value();
    // inside (r <= R): u = a0 + sum (r/R)^n (a_n cos n theta + b_n sin n theta);
    // outside: (R/r)^n, the solution bounded at infinity.
    return matOf(gridRows(r.size(), th.size(), [&](size_t i, double *row) {
      const double rho = r[i] <= R ? r[i] / R : R / r[i];
      for (size_t j = 0; j < th.size(); j++) {
        double s = a0, pw = 1.0;
        for (size_t n = 1; n <= an.size(); n++) {
          pw *= rho;
          s += pw * (an[n - 1] * std::cos(n * th[j]) + bn[n - 1] * std::sin(n * th[j]));
        }
        row[j] = s;
      }
    }));
  }
  OPS_END

  // ---- Laplace's equation in a sphere, axial symmetry (Kreyszig 12.11) ----
  OPS_FN("solve_laplace_3d_spherical", 5, 5, "solve_laplace_3d_spherical(f, R, r, phi, N)",
         "Laplace equation, sphere", kCallsNC | kKernel) {
    Fn f;
    double R;
    Vec r, ph;
    long long N;
    if (!argFn(a, 0, ctx, f) || !argPositive(a, 1, ctx, R) || !argNonNegVec(a, 2, ctx, r, "r") ||
        !argVec(a, 3, ctx, ph) || !argCount(a, 4, ctx, N, 0, 200))
      return Value();
    const size_t n = static_cast<size_t>(N);
    // A_n = (2n + 1)/2 integral 0..pi of f(phi) P_n(cos phi) sin phi dphi, n = 0..N
    QuadResult q = quadVec(
        [&](double p, double *out) {
          const double fp = f.r(p);
          const Vec P = legendreAll(n, std::cos(p));
          for (size_t k = 0; k <= n; k++)
            out[k] = fp * P[k] * std::sin(p);
          return !f.failed();
        },
        n + 1, 0.0, kPi, 1e-13, 1e-11, 4000);
    if (!fnOk(f, ctx))
      return Value();
    Vec An(n + 1);
    for (size_t k = 0; k <= n; k++)
      An[k] = (2.0 * k + 1.0) / 2.0 * q.value[k];
    // inside: u = sum A_n (r/R)^n P_n(cos phi); outside: sum A_n (R/r)^(n+1) P_n(cos phi)
    return matOf(gridRows(r.size(), ph.size(), [&](size_t i, double *row) {
      const bool inside = r[i] <= R;
      for (size_t j = 0; j < ph.size(); j++) {
        const Vec P = legendreAll(n, std::cos(ph[j]));
        double s = 0.0;
        for (size_t k = 0; k <= n; k++) {
          const double w = inside ? std::pow(r[i] / R, static_cast<double>(k))
                                  : std::pow(R / r[i], static_cast<double>(k) + 1.0);
          s += An[k] * w * P[k];
        }
        row[j] = s;
      }
    }));
  }
  OPS_END

  // ---- heat equation on a bar by the Laplace transform (Kreyszig 12.12) ----
  OPS_FN("pde_solve_laplace_transform", 6, 7,
         "pde_solve_laplace_transform(f, g0, gL, c, x, t[, M])", "Heat equation via Laplace",
         kCallsNC) {
    // u_t = c^2 u_xx on [x0, xL] (the first and last x), u(x, 0) = f(x),
    // u(x0, t) = g0(t), u(xL, t) = gL(t). In s:  c^2 U'' - s U = -f,
    // U(x0) = G0(s), U(xL) = GL(s), solved exactly with sinh's and a Green's
    // function, then inverted by the Gaver-Stehfest formula (real s only).
    Fn f, g0, gL;
    double c;
    Vec x, t;
    long long M = 14;
    if (!argFn(a, 0, ctx, f) || !argFn(a, 1, ctx, g0) || !argFn(a, 2, ctx, gL) ||
        !argPositive(a, 3, ctx, c) || !argVec(a, 4, ctx, x, 2) ||
        !argNonNegVec(a, 5, ctx, t, "t") || (given(a, 6) && !argCount(a, 6, ctx, M, 6, 20)))
      return Value();
    if (M % 2) {
      ctx.fail("M (Stehfest terms) must be even");
      return Value();
    }
    for (size_t i = 1; i < x.size(); i++)
      if (!(x[i] > x[i - 1])) {
        ctx.fail("x must increase");
        return Value();
      }
    const double X0 = x.front(), L = x.back() - X0;
    const Vec V = stehfestWeights(static_cast<int>(M));
    // f sampled on [0, u] and [u, L] for each x (local coordinate u = x - x0).
    struct Side {
      Vec xi, w, fv;
    };
    std::vector<Side> left(x.size()), right(x.size());
    for (size_t j = 0; j < x.size(); j++) {
      const double u = x[j] - X0;
      if (u > 0) {
        compositeGL(0.0, u, 32, left[j].xi, left[j].w);
        for (double v : left[j].xi)
          left[j].fv.push_back(f.r(X0 + v));
      }
      if (u < L) {
        compositeGL(u, L, 32, right[j].xi, right[j].w);
        for (double v : right[j].xi)
          right[j].fv.push_back(f.r(X0 + v));
      }
    }
    if (!fnOk(f, ctx))
      return Value();
    auto laplaceOf = [&](Fn &g, double s) -> double {
      if (g.isConstant())
        return g.c(0.0).real() / s;
      QuadResult q = quadVec(
          [&](double tt, double *out) {
            out[0] = std::exp(-s * tt) * g.r(tt);
            return !g.failed();
          },
          1, 0.0, kInf, 1e-13, 1e-10, 2000);
      return q.value[0];
    };
    Mat U(t.size(), x.size());
    for (size_t i = 0; i < t.size(); i++) {
      if (t[i] == 0.0) {
        for (size_t j = 0; j < x.size(); j++)
          U(i, j) = j == 0 ? g0.r(0.0) : (j + 1 == x.size() ? gL.r(0.0) : f.r(x[j]));
        continue;
      }
      const double ln2t = std::log(2.0) / t[i];
      Vec acc(x.size(), 0.0);
      for (int k = 1; k <= M; k++) {
        const double s = k * ln2t, kap = std::sqrt(s) / c;
        const double G0 = laplaceOf(g0, s), GL = laplaceOf(gL, s);
        if (g0.failed() || gL.failed())
          break;
        // sinh(kap a) / sinh(kap L) and sinh(kap a) sinh(kap b) / sinh(kap L), a + b <= L,
        // written with exponentials so large kap L does not overflow.
        const double den = -std::expm1(-2.0 * kap * L);
        auto r1 = [&](double aa) {
          return std::exp(kap * (aa - L)) * -std::expm1(-2.0 * kap * aa) / den;
        };
        auto r2 = [&](double aa, double bb) {
          return 0.5 * std::exp(kap * (aa + bb - L)) * -std::expm1(-2.0 * kap * aa) *
                 -std::expm1(-2.0 * kap * bb) / den;
        };
        for (size_t j = 0; j < x.size(); j++) {
          const double u = x[j] - X0;
          double Us = G0 * r1(L - u) + GL * r1(u);
          double I = 0.0;
          for (size_t q = 0; q < left[j].xi.size(); q++)
            I += left[j].w[q] * left[j].fv[q] * r2(L - u, left[j].xi[q]);
          for (size_t q = 0; q < right[j].xi.size(); q++)
            I += right[j].w[q] * right[j].fv[q] * r2(u, L - right[j].xi[q]);
          Us += I / (c * c * kap);
          acc[j] += V[static_cast<size_t>(k)] * Us;
        }
      }
      for (size_t j = 0; j < x.size(); j++)
        U(i, j) = ln2t * acc[j];
    }
    if (!fnOk(g0, ctx) || !fnOk(gL, ctx) || !fnOk(f, ctx))
      return Value();
    return matOf(U);
  }
  OPS_END
}

} // namespace ops
} // namespace nc
