#include "geometric_builtin.h"
#include "geometric.h"

#include <functional>
#include <iostream>
#include <unordered_map>

Value geometricBuiltin(const std::string &name,
                       const std::vector<Value> &args) {

  auto arg0 = args.size() > 0 ? args[0] : Value(0);
  auto arg1 = args.size() > 1 ? args[1] : Value(0);

  auto require_arity = [&](size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << name << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  using Fn = std::function<Value(const std::vector<Value> &)>;

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= CHARACTERS / SHAPES ================= */

      {"char_circle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_circle(a[0].number);
       }},

      {"char_square",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_square(a[0].number);
       }},

      {"char_triangle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_triangle(a[0].number);
       }},

      {"char_rectangle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_rectangle(a[0].number, a[1].number);
       }},

      {"char_ellipse",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_ellipse(a[0].number, a[1].number);
       }},

      {"char_pentagon",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_pentagon(a[0].number);
       }},

      {"char_hexagon",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_hexagon(a[0].number);
       }},

      {"char_heptagon",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_heptagon(a[0].number);
       }},

      {"char_nonagon",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_nonagon(a[0].number);
       }},

      {"char_semicircle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_semicircle(a[0].number);
       }},

      {"char_sphere",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_sphere(a[0].number);
       }},

      {"char_cylinder",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_cylinder(a[0].number, a[1].number);
       }},

      {"char_cone",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_cone(a[0].number, a[1].number);
       }},

      {"char_cube",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(1))
           return Value(0);
         return char_cube(a[0].number);
       }},
      {"char_rhombus",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_rhombus(a[0].number, a[1].number);
       }},

      {"char_rtriangle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_rtriangle(a[0].number, a[1].number);
       }},

      {"char_polygon",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(2))
           return Value(0);
         return char_polygon(a[0].number, a[1].number);
       }},

      {"char_trapezoid",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity(3))
           return Value(0);
         return char_trapezoid(a[0].number, a[1].number, a[2].number);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown geometric function '" << name << "'\n";
    return Value(0);
  }

  return it->second(args);
}