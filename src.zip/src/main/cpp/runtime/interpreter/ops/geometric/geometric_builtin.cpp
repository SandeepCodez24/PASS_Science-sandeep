#include "geometric_builtin.h"
#include "geometric.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

Value geometricBuiltin(const std::string &name,
                       const std::vector<Value> &args) {

  // Takes `a`/`fn` explicitly rather than capturing the enclosing
  // `args`/`name` by reference: this lambda's caller-lambdas below all live
  // inside a `static const table` built once on the first call to this
  // function and reused (dangling references and all) on every later call -
  // a [&] capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments/name.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      g_lastGeometricOk = false;
      return false;
    }
    return true;
  };

  // Every char_* function below reads its arguments straight off `.number`
  // with no check at all - a Value defaults `.number` to 0 when it's
  // actually an array/matrix/text/dict, so passing one of those silently
  // read as 0 with NO error whatsoever (worse than an out-of-range numeric
  // input, which at least gets rejected by geometric.cpp's own
  // requireNonNegative() checks): char_circle([1,2,3]) silently returned
  // "Area=0, Perimeter=0", indistinguishable from a legitimately-degenerate
  // zero-radius circle. Confirmed by direct testing. Same requireScalar
  // hazard/fix already applied to Percentile()/ZScore() in statistics.cpp.
  auto require_scalar = [](const Value &v, const std::string &fn,
                            const std::string &argDesc) -> bool {
    if (v.isArray || v.isMatrix || v.isText || v.isDict) {
      std::cerr << "Error: " << fn << "'s " << argDesc
                << " must be a single number, not an array/matrix/text/dict\n";
      g_lastGeometricOk = false;
      return false;
    }
    return true;
  };

  using Fn = std::function<Value(const std::vector<Value> &)>;

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= CHARACTERS / SHAPES ================= */

      {"char_circle",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_circle", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_circle", "radius"))
           return Value(0);
         return char_circle(a[0].number);
       }},

      {"char_square",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_square", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_square", "side length"))
           return Value(0);
         return char_square(a[0].number);
       }},

      {"char_triangle",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_triangle", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_triangle", "side length"))
           return Value(0);
         return char_triangle(a[0].number);
       }},

      {"char_rectangle",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_rectangle", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_rectangle", "base") ||
             !require_scalar(a[1], "char_rectangle", "height"))
           return Value(0);
         return char_rectangle(a[0].number, a[1].number);
       }},

      {"char_ellipse",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_ellipse", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_ellipse", "semi-major axis (a)") ||
             !require_scalar(a[1], "char_ellipse", "semi-minor axis (b)"))
           return Value(0);
         return char_ellipse(a[0].number, a[1].number);
       }},

      {"char_pentagon",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_pentagon", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_pentagon", "side length"))
           return Value(0);
         return char_pentagon(a[0].number);
       }},

      {"char_hexagon",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_hexagon", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_hexagon", "side length"))
           return Value(0);
         return char_hexagon(a[0].number);
       }},

      {"char_heptagon",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_heptagon", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_heptagon", "side length"))
           return Value(0);
         return char_heptagon(a[0].number);
       }},

      {"char_nonagon",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_nonagon", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_nonagon", "side length"))
           return Value(0);
         return char_nonagon(a[0].number);
       }},

      {"char_semicircle",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_semicircle", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_semicircle", "radius"))
           return Value(0);
         return char_semicircle(a[0].number);
       }},

      {"char_sphere",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_sphere", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_sphere", "radius"))
           return Value(0);
         return char_sphere(a[0].number);
       }},

      {"char_cylinder",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_cylinder", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_cylinder", "radius") ||
             !require_scalar(a[1], "char_cylinder", "height"))
           return Value(0);
         return char_cylinder(a[0].number, a[1].number);
       }},

      {"char_cone",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_cone", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_cone", "radius") ||
             !require_scalar(a[1], "char_cone", "height"))
           return Value(0);
         return char_cone(a[0].number, a[1].number);
       }},

      {"char_cube",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_cube", 1))
           return Value(0);
         if (!require_scalar(a[0], "char_cube", "side length"))
           return Value(0);
         return char_cube(a[0].number);
       }},
      {"char_rhombus",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_rhombus", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_rhombus", "first diagonal") ||
             !require_scalar(a[1], "char_rhombus", "second diagonal"))
           return Value(0);
         return char_rhombus(a[0].number, a[1].number);
       }},

      {"char_rtriangle",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_rtriangle", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_rtriangle", "base") ||
             !require_scalar(a[1], "char_rtriangle", "height"))
           return Value(0);
         return char_rtriangle(a[0].number, a[1].number);
       }},

      {"char_polygon",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_polygon", 2))
           return Value(0);
         if (!require_scalar(a[0], "char_polygon", "side length") ||
             !require_scalar(a[1], "char_polygon", "side count (n)"))
           return Value(0);
         return char_polygon(a[0].number, a[1].number);
       }},

      {"char_trapezoid",
       [require_arity, require_scalar](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "char_trapezoid", 3))
           return Value(0);
         if (!require_scalar(a[0], "char_trapezoid", "first parallel side") ||
             !require_scalar(a[1], "char_trapezoid", "second parallel side") ||
             !require_scalar(a[2], "char_trapezoid", "height"))
           return Value(0);
         return char_trapezoid(a[0].number, a[1].number, a[2].number);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass) - see matrix_builtin.cpp for
  // the first fix of this kind and the full reasoning.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown geometric function '" << name << "'\n";
    g_lastGeometricOk = false;
    return Value(0);
  }

  // Reset here, once per top-level dispatch call, rather than inside every
  // individual geometric.cpp function - matches the statistics.cpp/
  // statistics_builtin.cpp precedent (none of these shape functions call
  // each other internally, so there's no clobbering risk either way, but
  // centralizing keeps the convention consistent across domains).
  g_lastGeometricOk = true;

  return it->second(args);
}
