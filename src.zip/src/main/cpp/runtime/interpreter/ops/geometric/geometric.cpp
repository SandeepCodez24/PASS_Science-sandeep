#define _USE_MATH_DEFINES
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "geometric.h"
#include <sstream>

/* Circle */
Value char_circle(double r)
{
    double area = M_PI * r * r;
    double peri = 2 * M_PI * r;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Square */
Value char_square(double a)
{
    double area = a * a;
    double peri = 4 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Equilateral Triangle */
Value char_triangle(double a)
{
    double area = (sqrt(3) / 4) * a * a;
    double peri = 3 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Rectangle */
Value char_rectangle(double b, double h)
{
    double area = b * h;
    double peri = 2 * (b + h);

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Pentagon */
Value char_pentagon(double a)
{
    double area = (5 * a * a) / (4 * tan(M_PI / 5));
    double peri = 5 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Hexagon */
Value char_hexagon(double a)
{
    double area = (3 * sqrt(3) / 2) * a * a;
    double peri = 6 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Heptagon */
Value char_heptagon(double a)
{
    double area = (7 * a * a) / (4 * tan(M_PI / 7));
    double peri = 7 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Nonagon */
Value char_nonagon(double a)
{
    double area = (9 * a * a) / (4 * tan(M_PI / 9));
    double peri = 9 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Semicircle */
Value char_semicircle(double r)
{
    double area = (M_PI * r * r) / 2;
    double peri = M_PI * r + 2 * r;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Ellipse */
Value char_ellipse(double a, double b)
{
    double area = M_PI * a * b;
    double peri = M_PI * (3 * (a + b) - sqrt((3 * a + b) * (a + 3 * b)));

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Rhombus */
Value char_rhombus(double d1, double d2)
{
    double area = (d1 * d2) / 2;
    double side = sqrt(pow(d1 / 2, 2) + pow(d2 / 2, 2));
    double peri = 4 * side;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Right Triangle */
Value char_rtriangle(double b, double h)
{
    double area = (b * h) / 2;
    double peri = b + h + sqrt(b * b + h * h);

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Trapezoid */
Value char_trapezoid(double a, double b, double h)
{
    double area = (a + b) * h / 2;
    double side = sqrt(pow((b - a) / 2, 2) + h * h);
    double peri = a + b + 2 * side;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Sphere */
Value char_sphere(double r)
{
    double surf = 4 * M_PI * r * r;
    double vol = (4.0 / 3.0) * M_PI * pow(r, 3);

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}

/* Cylinder */
Value char_cylinder(double r, double h)
{
    double surf = 2 * M_PI * r * (r + h);
    double vol = M_PI * r * r * h;

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}

/* Cone */
Value char_cone(double r, double h)
{
    double l = sqrt(r * r + h * h);
    double surf = M_PI * r * (r + l);
    double vol = (M_PI * r * r * h) / 3;

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}

/* Cube */
Value char_cube(double a)
{
    double surf = 6 * a * a;
    double vol = a * a * a;

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}
/* Regular Polygon */

Value char_polygon(double a,double n)
{
    double area = (n * a * a) / (4 * tan(M_PI / n));
    double peri = n * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}