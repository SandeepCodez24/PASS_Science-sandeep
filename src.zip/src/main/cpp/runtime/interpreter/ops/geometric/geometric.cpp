#define _USE_MATH_DEFINES
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "geometric.h"
#include <iostream>
#include <sstream>

bool g_lastGeometricOk = true;

namespace {
// Every shape parameter here (radius, side length, height, diagonal, ...)
// is a physical measurement that has no meaning below zero - a negative
// input previously fed straight into the area/perimeter formulas and came
// back as a plausible-looking but nonsensical answer (e.g. a NEGATIVE
// perimeter). Zero is kept as a valid, allowed degenerate case (a
// zero-radius sphere, a zero-height trapezoid, ...) since the formulas
// already produce a sane "vanishes to nothing" answer (0) for it, not
// garbage - only strictly negative input is actually invalid.
bool requireNonNegative(double v, const char *fn, const char *argDesc) {
  if (v < 0) {
    std::cerr << "Error: " << fn << "'s " << argDesc
              << " must be non-negative, got " << v << "\n";
    g_lastGeometricOk = false;
    return false;
  }
  return true;
}
} // namespace

/* Circle */
Value char_circle(double r)
{
    if (!requireNonNegative(r, "char_circle", "radius"))
        return Value("char_circle requires a non-negative radius");

    double area = M_PI * r * r;
    double peri = 2 * M_PI * r;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Square */
Value char_square(double a)
{
    if (!requireNonNegative(a, "char_square", "side length"))
        return Value("char_square requires a non-negative side length");

    double area = a * a;
    double peri = 4 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Equilateral Triangle */
Value char_triangle(double a)
{
    if (!requireNonNegative(a, "char_triangle", "side length"))
        return Value("char_triangle requires a non-negative side length");

    double area = (sqrt(3) / 4) * a * a;
    double peri = 3 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Rectangle */
Value char_rectangle(double b, double h)
{
    if (!requireNonNegative(b, "char_rectangle", "base") ||
        !requireNonNegative(h, "char_rectangle", "height"))
        return Value("char_rectangle requires non-negative base and height");

    double area = b * h;
    double peri = 2 * (b + h);

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Pentagon */
Value char_pentagon(double a)
{
    if (!requireNonNegative(a, "char_pentagon", "side length"))
        return Value("char_pentagon requires a non-negative side length");

    double area = (5 * a * a) / (4 * tan(M_PI / 5));
    double peri = 5 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Hexagon */
Value char_hexagon(double a)
{
    if (!requireNonNegative(a, "char_hexagon", "side length"))
        return Value("char_hexagon requires a non-negative side length");

    double area = (3 * sqrt(3) / 2) * a * a;
    double peri = 6 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Heptagon */
Value char_heptagon(double a)
{
    if (!requireNonNegative(a, "char_heptagon", "side length"))
        return Value("char_heptagon requires a non-negative side length");

    double area = (7 * a * a) / (4 * tan(M_PI / 7));
    double peri = 7 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Nonagon */
Value char_nonagon(double a)
{
    if (!requireNonNegative(a, "char_nonagon", "side length"))
        return Value("char_nonagon requires a non-negative side length");

    double area = (9 * a * a) / (4 * tan(M_PI / 9));
    double peri = 9 * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Semicircle */
Value char_semicircle(double r)
{
    if (!requireNonNegative(r, "char_semicircle", "radius"))
        return Value("char_semicircle requires a non-negative radius");

    double area = (M_PI * r * r) / 2;
    double peri = M_PI * r + 2 * r;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Ellipse */
Value char_ellipse(double a, double b)
{
    if (!requireNonNegative(a, "char_ellipse", "semi-major axis (a)") ||
        !requireNonNegative(b, "char_ellipse", "semi-minor axis (b)"))
        return Value("char_ellipse requires non-negative semi-axes");

    double area = M_PI * a * b;
    double peri = M_PI * (3 * (a + b) - sqrt((3 * a + b) * (a + 3 * b)));

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Rhombus */
Value char_rhombus(double d1, double d2)
{
    if (!requireNonNegative(d1, "char_rhombus", "first diagonal") ||
        !requireNonNegative(d2, "char_rhombus", "second diagonal"))
        return Value("char_rhombus requires non-negative diagonals");

    double area = (d1 * d2) / 2;
    double side = sqrt(pow(d1 / 2, 2) + pow(d2 / 2, 2));
    double peri = 4 * side;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Right Triangle */
Value char_rtriangle(double b, double h)
{
    if (!requireNonNegative(b, "char_rtriangle", "base") ||
        !requireNonNegative(h, "char_rtriangle", "height"))
        return Value("char_rtriangle requires non-negative base and height");

    double area = (b * h) / 2;
    double peri = b + h + sqrt(b * b + h * h);

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

// NOTE: this computes the perimeter of an ISOSCELES (symmetric) trapezoid
// specifically, not a general trapezoid - the two parallel sides (a, b)
// and the height (h) alone do NOT determine a general trapezoid's
// perimeter (the horizontal offset between the two parallel sides also
// matters, and isn't a parameter here); `side` below is derived by
// assuming that offset splits evenly, i.e. the trapezoid is symmetric
// about the perpendicular bisector of both parallel sides. The area
// formula IS exact for any trapezoid (it only depends on a, b, h), just
// not the perimeter. Flagged as a name-vs-math mismatch, not fixed here,
// since a general trapezoid needs a 4th parameter (the offset, or all
// four side lengths) this function's signature doesn't have - same
// "documented simplification pending a signature/design change" category
// as vector.cpp's divergence()/Curl() (their own comments explain that
// precedent).
Value char_trapezoid(double a, double b, double h)
{
    if (!requireNonNegative(a, "char_trapezoid", "first parallel side") ||
        !requireNonNegative(b, "char_trapezoid", "second parallel side") ||
        !requireNonNegative(h, "char_trapezoid", "height"))
        return Value("char_trapezoid requires non-negative sides and height");

    double area = (a + b) * h / 2;
    double side = sqrt(pow((b - a) / 2, 2) + h * h);
    double peri = a + b + 2 * side;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}

/* Sphere */
Value char_sphere(double r)
{
    if (!requireNonNegative(r, "char_sphere", "radius"))
        return Value("char_sphere requires a non-negative radius");

    double surf = 4 * M_PI * r * r;
    double vol = (4.0 / 3.0) * M_PI * pow(r, 3);

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}

/* Cylinder */
Value char_cylinder(double r, double h)
{
    if (!requireNonNegative(r, "char_cylinder", "radius") ||
        !requireNonNegative(h, "char_cylinder", "height"))
        return Value("char_cylinder requires a non-negative radius and height");

    double surf = 2 * M_PI * r * (r + h);
    double vol = M_PI * r * r * h;

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}

/* Cone */
Value char_cone(double r, double h)
{
    if (!requireNonNegative(r, "char_cone", "radius") ||
        !requireNonNegative(h, "char_cone", "height"))
        return Value("char_cone requires a non-negative radius and height");

    double l = sqrt(r * r + h * h);
    double surf = M_PI * r * (r + l);
    double vol = (M_PI * r * r * h) / 3;

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}

/* Cube */
Value char_cube(double a)
{
    if (!requireNonNegative(a, "char_cube", "side length"))
        return Value("char_cube requires a non-negative side length");

    double surf = 6 * a * a;
    double vol = a * a * a;

    std::stringstream ss;
    ss << "Surface=" << surf << ", Volume=" << vol;

    return Value(ss.str());
}
/* Regular Polygon */

Value char_polygon(double a,double n)
{
    if (!requireNonNegative(a, "char_polygon", "side length"))
        return Value("char_polygon requires a non-negative side length");

    // n is a SIDE COUNT, not a general real-valued parameter like every
    // other shape's measurements above - "2.5 sides" is meaningless, and
    // n<3 isn't a polygon at all (the tan(pi/n) formula silently returned
    // near-zero garbage for n=2, a huge nonsensical value for n=1, and NaN
    // for n=0, all with no error). Requires an integer >= 3.
    if (n < 3 || std::abs(n - std::round(n)) > 1e-9) {
        std::cerr << "Error: char_polygon's side count (n) must be an integer >= 3, got "
                  << n << "\n";
        g_lastGeometricOk = false;
        return Value("char_polygon requires an integer side count (n) of at least 3");
    }

    double area = (n * a * a) / (4 * tan(M_PI / n));
    double peri = n * a;

    std::stringstream ss;
    ss << "Area=" << area << ", Perimeter=" << peri;

    return Value(ss.str());
}
