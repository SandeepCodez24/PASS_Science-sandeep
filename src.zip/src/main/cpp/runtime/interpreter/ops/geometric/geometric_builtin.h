#pragma once

#include <string>
#include <vector>

#include "../../core/value.h"

// Dispatcher for geometric builtins
Value geometricBuiltin(const std::string &name, const std::vector<Value> &args);
