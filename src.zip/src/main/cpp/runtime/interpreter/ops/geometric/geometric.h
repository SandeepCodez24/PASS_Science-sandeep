#pragma once
#include "../../core/value.h"

// Same "global out-of-band status flag" convention as statistics.h's
// g_lastStatsOk / vector.h's g_lastVectorOk: g_lastBuiltinFound only means
// "the NAME was found in a dispatch table", not "the actual computation
// succeeded with valid inputs" - these are plain free functions with no
// Parser access to set evaluationSucceeded_ directly. Reset once per
// top-level dispatch call in geometric_builtin.cpp (not inside each
// individual function - none of these call each other internally, so
// there's no clobbering risk either way, but centralizing matches the
// statistics.cpp precedent); set false when a shape parameter is rejected
// (negative radius/side/height/diagonal, or - for char_polygon() - a
// side count below 3 or a non-integer side count). Checked in
// parser_factor.cpp's ExprKind::Call case and nc_bridge_call_dynamic
// (value_bridge.cpp) right alongside g_lastVectorOk/g_lastStatsOk. Before
// this flag existed, this entire domain had NO input validation at all:
// char_circle(-5) silently returned "Area=78.5398, Perimeter=-31.4159" (a
// negative perimeter, meaningless but presented as a valid answer), and
// char_polygon(5, 2)/char_polygon(5, 0) silently returned near-zero/NaN
// garbage instead of rejecting a degenerate or undefined side count -
// confirmed by direct testing.
extern bool g_lastGeometricOk;

/* ===================== 2D SHAPES ===================== */

Value char_circle(double r);
Value char_square(double a);
Value char_triangle(double a);

Value char_pentagon(double a);
Value char_hexagon(double a);
Value char_heptagon(double a);
Value char_nonagon(double a);

Value char_rectangle(double b, double h);
Value char_rhombus(double d1, double d2);
Value char_rtriangle(double b, double h);

Value char_polygon(double a, double n);
// Perimeter assumes an ISOSCELES trapezoid specifically - see the matching
// comment on this function's definition in geometric.cpp.
Value char_trapezoid(double a, double b, double h);

Value char_semicircle(double r);
Value char_ellipse(double a, double b);

/* ===================== 3D SHAPES ===================== */

Value char_cube(double a);
Value char_sphere(double r);
Value char_cylinder(double r, double h);
Value char_cone(double r, double h);