#pragma once
#include "../../core/value.h"

/* ===================== 2D SHAPES ===================== */

Value char_circle(double r);
Value char_square(double a);
Value char_triangle(double a);

Value char_pentagon(double a);
Value char_hexagon(double a);
Value char_heptagon(double a);
Value char_nonagon(double a);

Value char_rectangle(double b, double h);
Value char_rhombus(double d1, double d2);
Value char_rtriangle(double b, double h);

Value char_polygon(double a, double n);
Value char_trapezoid(double a, double b, double h);

Value char_semicircle(double r);
Value char_ellipse(double a, double b);

/* ===================== 3D SHAPES ===================== */

Value char_cube(double a);
Value char_sphere(double r);
Value char_cylinder(double r, double h);
Value char_cone(double r, double h);