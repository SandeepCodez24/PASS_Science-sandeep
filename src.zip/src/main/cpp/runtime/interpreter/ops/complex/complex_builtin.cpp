#include "complex_builtin.h"

#include <cmath>
#include <complex>
#include <functional>
#include <iostream>
#include <unordered_map>
#include <unordered_set>

#include "../../builtins/builtins.h"

namespace {

// A scalar a complex function can work on: a real or complex number.
bool isNumberLike(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef;
}

double imagOf(const Value &v) { return v.isComplex ? v.imag : 0.0; }

// Applies fn to a number, or to every element of an array/matrix. Anything
// else is rejected: fn only ever sees a real or complex scalar.
Value mapNumbers(const std::string &fnName, const Value &a,
                 const std::function<Value(const Value &)> &fn) {
  if (isNumberLike(a))
    return fn(a);

  if (a.isArray || a.isMatrix) {
    bool ok = true;
    Value result = a;
    result.transformElems([&](const Value &elem) {
      if (!isNumberLike(elem)) {
        ok = false;
        return elem;
      }
      return fn(elem);
    });
    if (ok)
      return result;
  }

  std::cerr << "Error: " << fnName << " expects a number, or an array/matrix of numbers\n";
  g_lastBuiltinFound = false;
  return Value(0);
}

// A packed complex array/matrix with no unit, mapped straight off its buffer
// to a real result (real, imag, abs, angle) without building a Value per
// element. False when `a` is anything else; the caller then takes the
// general mapNumbers() route, which gives the same answer.
bool mapPackedToReal(const Value &a, const std::function<double(std::complex<double>)> &fn,
                     Value &out) {
  if (!a.isPackedComplex())
    return false;
  const Value first = a.isMatrix ? a.at(0, 0) : a.at(0);
  if (first.dimL != 0 || first.dimT != 0 || first.dimM != 0)
    return false;
  const size_t n = a.isMatrix ? a.rows() * a.cols() : a.length();
  const std::complex<double> *src = a.packedComplexData();
  std::vector<double> result(n);
  for (size_t k = 0; k < n; k++)
    result[k] = fn(src[k]);
  out = a.isMatrix ? Value::packedMatrix(result.data(), a.rows(), a.cols())
                   : Value::packedArray(result.data(), n);
  return true;
}

bool requireArity(const std::vector<Value> &a, const std::string &fn, size_t needed) {
  if (a.size() == needed)
    return true;
  std::cerr << "Error: Function '" << fn << "' expects " << needed << " args, got " << a.size()
            << "\n";
  g_lastBuiltinFound = false;
  return false;
}

// complex(re, im): both plain real numbers, or arrays/matrices of them with
// matching shape (a scalar on either side pairs with every element).
Value makeComplex(const Value &re, const Value &im) {
  auto realScalar = [](const Value &v) { return isNumberLike(v) && !v.isComplex; };

  if (realScalar(re) && realScalar(im))
    return Value::complexNumber(re.number, im.number);

  auto fail = [](const char *why) {
    std::cerr << "Error: complex " << why << "\n";
    g_lastBuiltinFound = false;
    return Value(0);
  };

  const Value &shape = (re.isArray || re.isMatrix) ? re : im;
  if (!shape.isArray && !shape.isMatrix)
    return fail("expects real numbers, or arrays/matrices of real numbers");

  auto partAt = [&](const Value &v, size_t r, size_t c, bool &ok) -> double {
    Value e = realScalar(v) ? v : (shape.isArray ? v.at(c) : v.at(r, c));
    if (!realScalar(e))
      ok = false;
    return e.number;
  };
  auto sameShape = [&](const Value &v) {
    if (realScalar(v))
      return true;
    if (shape.isArray)
      return v.isArray && v.length() == shape.length();
    if (!v.isMatrix || v.rows() != shape.rows())
      return false;
    for (size_t r = 0; r < shape.rows(); r++)
      if (v.rowLength(r) != shape.rowLength(r))
        return false;
    return true;
  };
  if (!sameShape(re) || !sameShape(im))
    return fail("expects its real and imaginary parts to have the same shape");

  bool ok = true;
  if (shape.isArray) {
    std::vector<Value> out;
    for (size_t i = 0; i < shape.length(); i++)
      out.push_back(Value::complexNumber(partAt(re, 0, i, ok), partAt(im, 0, i, ok)));
    return ok ? Value(std::move(out)) : fail("expects real numbers in both parts");
  }
  std::vector<std::vector<Value>> out;
  for (size_t r = 0; r < shape.rows(); r++) {
    std::vector<Value> row;
    for (size_t c = 0; c < shape.rowLength(r); c++)
      row.push_back(Value::complexNumber(partAt(re, r, c, ok), partAt(im, r, c, ok)));
    out.push_back(std::move(row));
  }
  return ok ? Value(std::move(out)) : fail("expects real numbers in both parts");
}

} // namespace

bool builtinAcceptsComplex(const std::string &name) {
  static const std::unordered_set<std::string> names = {
      // complex-number functions
      "complex", "real", "imag", "conj", "abs", "angle", "is_complex", "is_real",
      // containers and tests that never look inside a number
      "dict", "keys", "values", "size", "match_key", "is_empty", "isempty",
      // comparisons and truth tests, which share the complex-aware rules in
      // value_compare.cpp (equality on both parts, ordering on the real part)
      "eq", "ne", "lt", "gt", "le", "ge", "and", "or", "not", "bool", "is_true", "is_false",
      "if",
      // matrix functions with a complex path (matrix.cpp)
      "transpose", "conjugate", "had_prod", "element_wise",
      // math functions with a complex branch (arithmetic.cpp,
      // trigonometric.cpp, dc.cpp)
      "sqrt", "cbrt", "sqr", "cube", "exp", "log",
      "sin", "cos", "tan", "cosec", "sec", "cot",
      "inv_sin", "inv_cos", "inv_tan", "inv_cosec", "inv_sec", "inv_cot",
      "sinh", "cosh", "tanh", "cosech", "sech", "coth",
      "sin_deg", "cos_deg", "tan_deg", "cosec_deg", "sec_deg", "cot_deg",
      "int", "round", "rad2dec", "dec2rad",
      // number tests that look at both parts
      "is_zero", "isnan", "is_nan"};
  return names.count(name) != 0;
}

Value complexBuiltin(const std::string &name, const std::vector<Value> &args) {
  using Fn = std::function<Value(const std::vector<Value> &)>;

  static const std::unordered_map<std::string, Fn> table = {

      {"complex",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "complex", 2))
           return Value(0);
         return makeComplex(a[0], a[1]);
       }},

      {"real",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "real", 1))
           return Value(0);
         Value fast;
         if (mapPackedToReal(a[0], [](std::complex<double> z) { return z.real(); }, fast))
           return fast;
         return mapNumbers("real", a[0], [](const Value &z) {
           Value r(z.number);
           r.dimL = z.dimL;
           r.dimT = z.dimT;
           r.dimM = z.dimM;
           return r;
         });
       }},

      {"imag",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "imag", 1))
           return Value(0);
         Value fast;
         if (mapPackedToReal(a[0], [](std::complex<double> z) { return z.imag(); }, fast))
           return fast;
         return mapNumbers("imag", a[0], [](const Value &z) {
           Value r(imagOf(z));
           r.dimL = z.dimL;
           r.dimT = z.dimT;
           r.dimM = z.dimM;
           return r;
         });
       }},

      // The conjugate of a real number is itself, and stays real.
      {"conj",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "conj", 1))
           return Value(0);
         return mapNumbers("conj", a[0], [](const Value &z) {
           Value r = z;
           if (r.isComplex)
             r.imag = -r.imag;
           return r;
         });
       }},

      // Magnitude. std::hypot avoids the overflow of sqrt(re*re + im*im).
      {"abs",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "abs", 1))
           return Value(0);
         Value fast;
         if (mapPackedToReal(
                 a[0], [](std::complex<double> z) { return std::hypot(z.real(), z.imag()); }, fast))
           return fast;
         return mapNumbers("abs", a[0], [](const Value &z) {
           Value r(z.isComplex ? std::hypot(z.number, z.imag) : std::fabs(z.number));
           r.dimL = z.dimL;
           r.dimT = z.dimT;
           r.dimM = z.dimM;
           return r;
         });
       }},

      // Phase angle in radians, in (-pi, pi]. A unitless result whatever
      // unit the input carries.
      {"angle",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "angle", 1))
           return Value(0);
         Value fast;
         if (mapPackedToReal(
                 a[0], [](std::complex<double> z) { return std::atan2(z.imag(), z.real()); }, fast))
           return fast;
         return mapNumbers("angle", a[0],
                           [](const Value &z) { return Value(std::atan2(imagOf(z), z.number)); });
       }},

      // Answers for the value as a whole: an array counts as complex when
      // any element is.
      {"is_complex",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "is_complex", 1))
           return Value(0);
         return Value(a[0].hasComplex() ? 1.0 : 0.0);
       }},

      {"is_real",
       [](const std::vector<Value> &a) -> Value {
         if (!requireArity(a, "is_real", 1))
           return Value(0);
         return Value(a[0].hasComplex() ? 0.0 : 1.0);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown function '" << name << "'\n";
    g_lastBuiltinFound = false;
    return Value(0);
  }
  return it->second(args);
}
