#pragma once
#include <string>
#include <vector>

#include "../../core/value.h"

// complex(), real(), imag(), conj(), is_complex(), is_real(), plus abs() and
// the one-argument angle() once a complex value is involved.
Value complexBuiltin(const std::string &name, const std::vector<Value> &args);

// True when `name` (already lowercased) is a builtin that understands
// complex arguments. callBuiltin() (builtins.cpp) rejects a complex argument
// to any other builtin, since those read only a value's real part and would
// otherwise return a silently wrong answer.
bool builtinAcceptsComplex(const std::string &name);
