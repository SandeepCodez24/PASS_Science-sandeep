#pragma once
// Complex analysis (Kreyszig chapters 13-18), registered in the ops registry
// by registerComplexAnalysis():
//   complex_analysis.cpp  ch. 13-15  analyticity, derivatives, branches,
//                                    contour integrals, Cauchy, Taylor
//   complex_residue.cpp   ch. 16     Laurent series, poles, residues, real
//                                    integrals by residues
//   complex_mapping.cpp   ch. 17-18  conformal and Moebius maps, potential
//                                    theory
// The complex-number basics (complex, real, imag, conj, abs, angle) are
// complex_builtin.cpp's and are not repeated here.
#include <functional>

#include "../support/ops_math.h"

namespace nc {
namespace ops {

void registerComplexResidue(OpsRegistry &reg);
void registerComplexMapping(OpsRegistry &reg);
// Zeroes the rounding noise of circle coefficients c_k, k = kmin, kmin + 1, ...
void cleanCircleCoefficients(CVec &c, double r, long long kmin);

namespace cx {

// A path: an array (row or column) of 2 or more complex points, taken as
// straight segments from one point to the next (closed when the last point
// is the first, as generate_contour gives it).
bool argPath(const Args &a, size_t i, CallContext &ctx, CVec &path);

// integral along the path of kernel(z, f(z)) dz: adaptive Gauss-Kronrod on
// each straight segment (relative accuracy about 1e-12). False when f failed.
bool pathIntegral(Fn &f, const CVec &path, const std::function<cd(cd, cd)> &kernel, cd &out);

// Any number / array / matrix of complex numbers, element by element through
// op; the result keeps the input's shape (a number for a number).
bool mapElements(const Value &v, CallContext &ctx, size_t argIndex,
                 const std::function<cd(cd)> &op, Value &out);

// Winding number of f around 0 on the circle |z - z0| = r: zeros minus
// poles inside (argument principle), from the change of arg f.
double windingNumber(Fn &f, cd z0, double r, size_t samples = 128);

} // namespace cx
} // namespace ops
} // namespace nc
