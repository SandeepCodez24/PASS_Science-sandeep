// Complex analysis, Kreyszig chapters 17-18: conformal mapping and
// potential theory.
//   conformal_map  mobius_transform  mobius_from_points  cross_ratio  (ch. 17)
//   harmonic_conjugate  poisson_integral_disk  complex_potential
//   complex_velocity  joukowski_map                                    (ch. 18)
// poisson_integral_disk is the proposed poisson_disk: that name is already
// the existing Poisson-disk sampling function (quasi-Monte Carlo).
#include <cmath>

#include "../calculus/calculus.h"
#include "complex_analysis.h"

namespace nc {
namespace ops {

namespace {

const cd kCInf(kInf, 0.0);

// 2 x 2 complex matrix [a b; c d].
Value mobiusMatrix(cd a, cd b, cd c, cd d) {
  CMat m(2, 2);
  m(0, 0) = a;
  m(0, 1) = b;
  m(1, 0) = c;
  m(1, 1) = d;
  return matOf(m);
}

// The map z1, z2, z3 -> 0, 1, inf as [a b; c d]:  (z - z1)(z2 - z3) / ((z - z3)(z2 - z1)).
void toZeroOneInf(const cd z[3], cd m[4]) {
  m[0] = z[1] - z[2];
  m[1] = -z[0] * (z[1] - z[2]);
  m[2] = z[1] - z[0];
  m[3] = -z[2] * (z[1] - z[0]);
}

} // namespace

#define OPS_DOMAIN Domain::Complex

void registerComplexMapping(OpsRegistry &reg) {

  // ---- ch. 17 ----
  OPS_FN("conformal_map", 2, 2, "conformal_map(@f, Z)", "Map a grid by f",
         kComplexArgs | kCallsNC) {
    Fn f;
    if (!argCallable(a, 0, ctx, f))
      return Value();
    Value out;
    if (!cx::mapElements(a[1], ctx, 1, [&](cd z) { return f.c(z); }, out))
      return Value();
    return fnOk(f, ctx) ? out : Value();
  }
  OPS_END

  OPS_FN("mobius_transform", 5, 5, "mobius_transform(z, a, b, c, d)", "Linear fractional map",
         kComplexArgs) {
    cd A, B, C, D;
    if (!argCNum(a, 1, ctx, A) || !argCNum(a, 2, ctx, B) || !argCNum(a, 3, ctx, C) ||
        !argCNum(a, 4, ctx, D))
      return Value();
    if (A * D - B * C == cd(0.0)) {
      ctx.fail("ad - bc must not be 0 (the map would be constant)");
      return Value();
    }
    // w = (a z + b) / (c z + d)  (Kreyszig 17.2); the pole z = -d/c goes to infinity
    Value out;
    if (!cx::mapElements(a[0], ctx, 0,
                         [&](cd z) {
                           const cd den = C * z + D;
                           return den == cd(0.0) ? kCInf : (A * z + B) / den;
                         },
                         out))
      return Value();
    return out;
  }
  OPS_END

  OPS_FN("mobius_from_points", 2, 2, "mobius_from_points(z, w)", "Moebius map from 3 points",
         kComplexArgs) {
    CVec z, w;
    if (!argCVec(a, 0, ctx, z) || !argCVec(a, 1, ctx, w))
      return Value();
    if (z.size() != 3 || w.size() != 3) {
      ctx.fail("give 3 points z = [z1, z2, z3] and their images w = [w1, w2, w3]");
      return Value();
    }
    for (int i = 0; i < 3; i++)
      for (int j = i + 1; j < 3; j++)
        if (z[i] == z[j] || w[i] == w[j]) {
          ctx.fail("the 3 points (and the 3 images) must be distinct");
          return Value();
        }
    // Equal cross ratios (Kreyszig 17.3): T_w^-1 o T_z, both mapping their points to 0, 1, inf.
    cd mz[4], mw[4];
    toZeroOneInf(z.data(), mz);
    toZeroOneInf(w.data(), mw);
    // inverse of [p q; r s] is [s -q; -r p]
    const cd ia = mw[3], ib = -mw[1], ic = -mw[2], id = mw[0];
    cd A = ia * mz[0] + ib * mz[2], B = ia * mz[1] + ib * mz[3];
    cd C = ic * mz[0] + id * mz[2], D = ic * mz[1] + id * mz[3];
    // normalise to ad - bc = 1; of the two such matrices (M and -M) take the
    // one whose first nonzero of a, c has a positive real part
    const cd det = std::sqrt(A * D - B * C);
    A /= det, B /= det, C /= det, D /= det;
    const cd lead = std::abs(A) > 1e-14 ? A : C;
    if (lead.real() < 0 || (lead.real() == 0 && lead.imag() < 0))
      A = -A, B = -B, C = -C, D = -D;
    auto clean = [](cd v) {
      return cd(std::abs(v.real()) < 1e-13 ? 0.0 : v.real(), std::abs(v.imag()) < 1e-13 ? 0.0 : v.imag());
    };
    return mobiusMatrix(clean(A), clean(B), clean(C), clean(D));
  }
  OPS_END

  OPS_FN("cross_ratio", 4, 4, "cross_ratio(z1, z2, z3, z4)", "Cross-ratio invariant",
         kComplexArgs) {
    // (z1, z2; z3, z4) = (z1 - z3)(z2 - z4) / ((z1 - z4)(z2 - z3)); arrays element by element
    CMat m[4];
    size_t n = 1;
    for (size_t i = 0; i < 4; i++) {
      if (!argCMat(a, i, ctx, m[i]))
        return Value();
      n = std::max(n, m[i].a.size());
    }
    size_t shapeOf = 0;
    for (size_t i = 0; i < 4; i++) {
      if (m[i].a.size() != 1 && m[i].a.size() != n) {
        ctx.fail("the four inputs must be numbers or arrays of one size");
        return Value();
      }
      if (m[i].a.size() == n)
        shapeOf = i;
    }
    CMat out = m[shapeOf];
    for (size_t k = 0; k < n; k++) {
      auto at = [&](int i) { return m[i].a.size() == 1 ? m[i].a[0] : m[i].a[k]; };
      const cd den = (at(0) - at(3)) * (at(1) - at(2));
      out.a[k] = den == cd(0.0) ? kCInf : (at(0) - at(2)) * (at(1) - at(3)) / den;
    }
    return n == 1 ? numOf(out.a[0]) : matOf(out);
  }
  OPS_END

  // ---- ch. 18 ----
  OPS_FN("harmonic_conjugate", 3, 3, "harmonic_conjugate(u, dx, dy)", "Harmonic conjugate",
         kKernel) {
    Grid u;
    double dx, dy;
    if (!argGrid(a, 0, ctx, u) || !argPositive(a, 1, ctx, dx) || !argPositive(a, 2, ctx, dy))
      return Value();
    if (u.rank != 2 || u.ny < 2 || u.nx < 2) {
      ctx.fail("u must be a 2-D grid of at least 2 x 2 values, u[i, j] = u(x_j, y_i)");
      return Value();
    }
    // v_x = -u_y and v_y = u_x (Cauchy-Riemann), v = 0 at the first grid point (Kreyszig 18.1)
    Grid vx = gridDiff(u, 1, dy);
    for (double &t : vx.a)
      t = -t;
    const Grid vy = gridDiff(u, 0, dx);
    const double h[3] = {dx, dy, 1.0};
    return gridValue(calc::potentialOf({vx, vy}, h));
  }
  OPS_END

  OPS_FN("poisson_integral_disk", 3, 4, "poisson_integral_disk(@f, r, theta[, R])",
         "Poisson integral, disk", kCallsNC) {
    Fn f;
    Vec r, th;
    double R = 1.0;
    if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, r) || !argVec(a, 2, ctx, th) ||
        (given(a, 3) && !argPositive(a, 3, ctx, R)))
      return Value();
    for (double v : r)
      if (v < 0.0 || v > R) {
        ctx.fail("every r must be in [0, R]");
        return Value();
      }
    // u(r, theta) = 1/(2 pi) integral over -pi..pi of f(phi) (R^2 - r^2) /
    //               (R^2 - 2 R r cos(theta - phi) + r^2) d phi  (Kreyszig 18.5)
    const size_t m = r.size() * th.size();
    QuadResult q = quadVec(
        [&](double phi, double *out) {
          const double fp = f.r(phi);
          for (size_t i = 0; i < r.size(); i++)
            for (size_t j = 0; j < th.size(); j++) {
              const double den = R * R - 2.0 * R * r[i] * std::cos(th[j] - phi) + r[i] * r[i];
              out[i * th.size() + j] = r[i] == R ? 0.0 : fp * (R * R - r[i] * r[i]) / den;
            }
          return !f.failed();
        },
        m, -kPi, kPi, 1e-12, 1e-10, 6000);
    if (!fnOk(f, ctx))
      return Value();
    Mat U(r.size(), th.size());
    for (size_t i = 0; i < r.size(); i++)
      for (size_t j = 0; j < th.size(); j++)
        U(i, j) = r[i] == R ? f.r(th[j]) : q.value[i * th.size() + j] / (2.0 * kPi);
    return fnOk(f, ctx) ? matOf(U) : Value();
  }
  OPS_END

  OPS_FN("complex_potential", 2, 2, "complex_potential(V, Z)", "Potential and stream function",
         kComplexArgs | kCallsNC) {
    // F(z) = Phi + i Psi with F'(z) = conj(V) (Kreyszig 18.4), F = 0 at Z[0, 0]:
    // F' integrated along the grid lines (rows in x, columns in y), the mean of
    // the two orders.
    CMat Z;
    if (!argCMat(a, 1, ctx, Z))
      return Value();
    if (Z.r < 2 || Z.c < 2) {
      ctx.fail("Z must be a grid of at least 2 x 2 complex points (rows along y, columns along x)");
      return Value();
    }
    CMat V(Z.r, Z.c);
    if (isFnArg(a[0])) {
      Fn fv(a[0]);
      for (size_t k = 0; k < Z.a.size(); k++)
        V.a[k] = fv.c(Z.a[k]);
      if (!fnOk(fv, ctx))
        return Value();
    } else {
      if (!argCMat(a, 0, ctx, V))
        return Value();
      if (V.r != Z.r || V.c != Z.c) {
        ctx.fail("the velocity grid must have the shape of Z");
        return Value();
      }
    }
    // integral of g dz along a line of grid points, cumulative
    auto lineInt = [](const CVec &g, const CVec &z) {
      const size_t n = g.size();
      Vec s(n, 0.0), gr(n), gi(n);
      for (size_t k = 1; k < n; k++)
        s[k] = s[k - 1] + std::abs(z[k] - z[k - 1]);
      // dz = (dz/ds) ds along the (straight) line
      const cd dir = n > 1 && s[n - 1] > 0 ? (z[n - 1] - z[0]) / s[n - 1] : cd(1.0);
      for (size_t k = 0; k < n; k++) {
        const cd v = g[k] * dir;
        gr[k] = v.real();
        gi[k] = v.imag();
      }
      const Vec R = cumIntegrate(gr, s), I = cumIntegrate(gi, s);
      CVec out(n);
      for (size_t k = 0; k < n; k++)
        out[k] = cd(R[k], I[k]);
      return out;
    };
    CMat Fp(Z.r, Z.c), F(Z.r, Z.c);
    for (size_t k = 0; k < Z.a.size(); k++)
      Fp.a[k] = std::conj(V.a[k]);
    auto row = [&](const CMat &M, size_t i) { return CVec(M.row(i), M.row(i) + M.c); };
    auto col = [&](const CMat &M, size_t j) {
      CVec c(M.r);
      for (size_t i = 0; i < M.r; i++)
        c[i] = M(i, j);
      return c;
    };
    // order 1: along row 0, then up each column; order 2: up column 0, then along each row
    const CVec r0 = lineInt(row(Fp, 0), row(Z, 0)), c0 = lineInt(col(Fp, 0), col(Z, 0));
    for (size_t j = 0; j < Z.c; j++) {
      const CVec up = lineInt(col(Fp, j), col(Z, j));
      for (size_t i = 0; i < Z.r; i++)
        F(i, j) = 0.5 * (r0[j] + up[i]);
    }
    for (size_t i = 0; i < Z.r; i++) {
      const CVec along = lineInt(row(Fp, i), row(Z, i));
      for (size_t j = 0; j < Z.c; j++)
        F(i, j) += 0.5 * (c0[i] + along[j]);
    }
    Mat Phi(Z.r, Z.c), Psi(Z.r, Z.c);
    for (size_t k = 0; k < F.a.size(); k++) {
      Phi.a[k] = F.a[k].real();
      Psi.a[k] = F.a[k].imag();
    }
    return dictOf({{"F", matOf(F)}, {"potential", matOf(Phi)}, {"stream", matOf(Psi)}});
  }
  OPS_END

  OPS_FN("complex_velocity", 2, 2, "complex_velocity(@F, z)", "Velocity from potential",
         kComplexArgs | kCallsNC) {
    Fn F;
    if (!argCallable(a, 0, ctx, F))
      return Value();
    // V = V1 + i V2 = conj(F'(z))  (Kreyszig 18.4)
    Value V;
    if (!cx::mapElements(a[1], ctx, 1,
                         [&](cd z) {
                           return std::conj(
                               complexDerivative(F, z, 1e-3 * std::max(1.0, std::abs(z))));
                         },
                         V))
      return Value();
    if (!fnOk(F, ctx))
      return Value();
    CMat m;
    scipy::readCMat(V, m);
    Mat speed(m.r, m.c), dir(m.r, m.c);
    for (size_t k = 0; k < m.a.size(); k++) {
      speed.a[k] = std::abs(m.a[k]);
      dir.a[k] = std::arg(m.a[k]);
    }
    const bool scalar = scipy::isPlainNumber(V);
    return dictOf({{"V", V},
                   {"speed", scalar ? Value(speed.a[0]) : matOf(speed)},
                   {"angle", scalar ? Value(dir.a[0]) : matOf(dir)}});
  }
  OPS_END

  OPS_FN("joukowski_map", 2, 2, "joukowski_map(z, c)", "Joukowski airfoil map", kComplexArgs) {
    cd c;
    if (!argCNum(a, 1, ctx, c))
      return Value();
    // w = z + c^2 / z  (Kreyszig 17.1, 18.4)
    Value out;
    if (!cx::mapElements(a[0], ctx, 0, [&](cd z) { return z == cd(0.0) ? kCInf : z + c * c / z; },
                         out))
      return Value();
    return out;
  }
  OPS_END
}

} // namespace ops
} // namespace nc
