// Complex analysis, Kreyszig chapter 16: Laurent series and residues.
//   laurent_coeffs  find_poles  complex_residue  real_improper_integral
//   real_trig_integral
// complex_residue(@f, z0) is the residue of a function at a pole; the name
// residue belongs to the signal-processing residue(b, a) (partial fractions).
#include <algorithm>
#include <cmath>

#include "complex_analysis.h"

namespace nc {
namespace ops {

namespace {

struct Pole {
  cd z;
  int order;
};

// Poles of f among the points of a grid Z (rows and columns of points):
// local maxima of |f| are refined by Newton's method on 1/f and kept when
// the argument principle on a small circle counts a pole there.
std::vector<Pole> polesOnGrid(Fn &f, const CMat &Z, double margin, double &spacing) {
  std::vector<Pole> out;
  const size_t R = Z.r, C = Z.c;
  Mat A(R, C);
  for (size_t k = 0; k < Z.a.size(); k++) {
    const double m = std::abs(f.c(Z.a[k]));
    A.a[k] = std::isfinite(m) ? m : kInf;
    if (f.failed())
      return out;
  }
  // Grid spacing: the smallest distance between neighbouring points.
  spacing = kInf;
  for (size_t i = 0; i < R; i++)
    for (size_t j = 0; j < C; j++) {
      if (j + 1 < C)
        spacing = std::min(spacing, std::abs(Z(i, j + 1) - Z(i, j)));
      if (i + 1 < R)
        spacing = std::min(spacing, std::abs(Z(i + 1, j) - Z(i, j)));
    }
  if (!(spacing > 0.0) || !std::isfinite(spacing))
    return out;
  Vec sorted = A.a;
  std::sort(sorted.begin(), sorted.end());
  const double median = sorted[sorted.size() / 2];
  double xmin = kInf, xmax = -kInf, ymin = kInf, ymax = -kInf;
  for (const cd &z : Z.a) {
    xmin = std::min(xmin, z.real());
    xmax = std::max(xmax, z.real());
    ymin = std::min(ymin, z.imag());
    ymax = std::max(ymax, z.imag());
  }
  const double span = std::max(xmax - xmin, ymax - ymin);
  for (size_t i = 0; i < R; i++)
    for (size_t j = 0; j < C; j++) {
      const double v = A(i, j);
      bool isMax = v > 3.0 * median || std::isinf(v);
      for (int di = -1; di <= 1 && isMax; di++)
        for (int dj = -1; dj <= 1 && isMax; dj++) {
          const long long ii = static_cast<long long>(i) + di, jj = static_cast<long long>(j) + dj;
          if ((di || dj) && ii >= 0 && jj >= 0 && ii < static_cast<long long>(R) &&
              jj < static_cast<long long>(C))
            isMax = v >= A(static_cast<size_t>(ii), static_cast<size_t>(jj));
        }
      if (!isMax)
        continue;
      // Newton on g = 1/f (analytic near a pole, zero at it).
      cd z = Z(i, j);
      const double h = 1e-4 * spacing;
      for (int it = 0; it < 200; it++) {
        const cd fz = f.c(z);
        if (!isFiniteC(fz) || fz == cd(0.0))
          break; // at the pole (or a zero: rejected below)
        const cd g = 1.0 / fz;
        const cd gp = (1.0 / f.c(z + h) - 1.0 / f.c(z - h)) / (2.0 * h);
        if (!isFiniteC(gp) || gp == cd(0.0))
          break;
        const cd step = g / gp;
        z -= step;
        if (std::abs(step) < 1e-15 * std::max(1.0, std::abs(z)) || std::abs(z - Z(i, j)) > 3 * spacing)
          break;
      }
      if (f.failed())
        return out;
      if (std::abs(z - Z(i, j)) > 2.0 * spacing || z.real() < xmin - margin ||
          z.real() > xmax + margin || z.imag() < ymin - margin || z.imag() > ymax + margin)
        continue;
      bool dup = false;
      for (const Pole &p : out)
        dup = dup || std::abs(p.z - z) < 1e-6 * std::max(1.0, span);
      if (dup)
        continue;
      const double w = cx::windingNumber(f, z, 0.25 * spacing);
      const int order = -static_cast<int>(std::lround(w));
      if (order >= 1 && std::abs(w + order) < 0.1) {
        // round away the Newton noise of a pole on an axis
        const double tz = 1e-10 * std::max(1.0, span);
        z = cd(std::abs(z.real()) < tz ? 0.0 : z.real(), std::abs(z.imag()) < tz ? 0.0 : z.imag());
        out.push_back({z, order});
      }
    }
  std::sort(out.begin(), out.end(), [](const Pole &x, const Pole &y) {
    return x.z.real() != y.z.real() ? x.z.real() < y.z.real() : x.z.imag() < y.z.imag();
  });
  return out;
}

CMat boxGrid(double x0, double x1, double y0, double y1, size_t nx, size_t ny) {
  CMat Z(ny, nx);
  for (size_t i = 0; i < ny; i++)
    for (size_t j = 0; j < nx; j++)
      Z(i, j) = cd(x0 + (x1 - x0) * j / (nx - 1.0), y0 + (y1 - y0) * i / (ny - 1.0));
  return Z;
}

// Residue at z0 on a circle of radius r (the c_{-1} Laurent coefficient).
cd residueAt(Fn &f, cd z0, double r) {
  const CVec c = circleCoefficients(f, z0, r, -1, -1, 256);
  return c.empty() ? cd(kNaN, kNaN) : c[0];
}

// A radius for the residue circle: well inside the distance to other poles.
double residueRadius(const std::vector<Pole> &poles, size_t k, double spacing) {
  double r = 0.25 * spacing;
  for (size_t j = 0; j < poles.size(); j++)
    if (j != k)
      r = std::min(r, 0.4 * std::abs(poles[j].z - poles[k].z));
  return r;
}

Value cleanC(cd z, double scale) {
  const double t = 1e-12 * std::max(1.0, scale);
  return numOf(cd(std::abs(z.real()) < t ? 0.0 : z.real(), std::abs(z.imag()) < t ? 0.0 : z.imag()));
}

} // namespace

#define OPS_DOMAIN Domain::Complex

void registerComplexResidue(OpsRegistry &reg) {

  OPS_FN("laurent_coeffs", 4, 4, "laurent_coeffs(@f, z0, r, N)", "Laurent coefficients",
         kComplexArgs | kCallsNC) {
    Fn f;
    cd z0;
    double r;
    long long N;
    if (!argCallable(a, 0, ctx, f) || !argCNum(a, 1, ctx, z0) || !argPositive(a, 2, ctx, r) ||
        !argCount(a, 3, ctx, N, 0, 500))
      return Value();
    // c_n = 1/(2 pi i) closed integral of f(z) / (z - z0)^(n+1) dz on |z - z0| = r,
    // n = -N .. N (Kreyszig 16.1) - by the discrete Fourier transform of the circle samples.
    CVec c = circleCoefficients(f, z0, r, -N, N, circleSamples(N));
    if (!fnOk(f, ctx))
      return Value();
    cleanCircleCoefficients(c, r, -N);
    Vec n;
    for (long long k = -N; k <= N; k++)
      n.push_back(static_cast<double>(k));
    return dictOf({{"n", rowOf(n)}, {"c", rowOf(c)}});
  }
  OPS_END

  OPS_FN("find_poles", 2, 3, "find_poles(@f, domain[, n])", "Locate poles",
         kComplexArgs | kCallsNC) {
    Fn f;
    if (!argCallable(a, 0, ctx, f))
      return Value();
    // domain: a grid of complex points, or bounds [x_min, x_max, y_min, y_max].
    CMat Z;
    if (given(a, 1) && isGridValue(a[1])) {
      if (!argCMat(a, 1, ctx, Z))
        return Value();
    } else {
      Vec b;
      if (!argVec(a, 1, ctx, b) || b.size() != 4 || !(b[1] > b[0]) || !(b[3] > b[2])) {
        if (ctx.ok())
          ctx.fail("the domain must be a grid of complex points or [x_min, x_max, y_min, y_max]");
        return Value();
      }
      long long n = 81;
      if (given(a, 2) && !argCount(a, 2, ctx, n, 5, 1001))
        return Value();
      Z = boxGrid(b[0], b[1], b[2], b[3], static_cast<size_t>(n), static_cast<size_t>(n));
    }
    double spacing = 0.0;
    const std::vector<Pole> poles = polesOnGrid(f, Z, 0.0, spacing);
    if (!fnOk(f, ctx))
      return Value();
    CVec z;
    Vec order;
    for (const Pole &p : poles) {
      z.push_back(p.z);
      order.push_back(static_cast<double>(p.order));
    }
    if (z.empty())
      return dictOf({{"poles", Value(std::vector<std::vector<Value>>{})},
                     {"orders", Value(std::vector<std::vector<Value>>{})}});
    return dictOf({{"poles", rowOf(z)}, {"orders", rowOf(order)}});
  }
  OPS_END

  OPS_FN("complex_residue", 2, 3, "complex_residue(@f, z0[, r])", "Residue at a pole",
         kComplexArgs | kCallsNC) {
    Fn f;
    cd z0;
    if (!argCallable(a, 0, ctx, f) || !argCNum(a, 1, ctx, z0))
      return Value();
    // Res f(z0) = c_{-1} = 1/(2 pi i) closed integral of f dz around z0 (Kreyszig 16.3)
    double r = 1e-2 * std::max(1.0, std::abs(z0));
    if (given(a, 2) && !argPositive(a, 2, ctx, r))
      return Value();
    const cd res = residueAt(f, z0, r);
    if (!fnOk(f, ctx))
      return Value();
    return cleanC(res, std::abs(res));
  }
  OPS_END

  OPS_FN("real_improper_integral", 1, 3, "real_improper_integral(@f[, R, n])",
         "Real integral by residues", kCallsNC) {
    Fn f;
    double R = 10.0;
    long long n = 101;
    if (!argCallable(a, 0, ctx, f) || (given(a, 1) && !argPositive(a, 1, ctx, R)) ||
        (given(a, 2) && !argCount(a, 2, ctx, n, 11, 1001)))
      return Value();
    // integral from -inf to inf of f(x) dx = 2 pi i sum Res (upper half-plane)
    //   + pi i sum Res (simple poles on the real axis, principal value)  (Kreyszig 16.4)
    // Poles are searched in |Re z| <= R, 0 <= Im z <= R.
    const double hstep = 2.0 * R / static_cast<double>(n - 1);
    const size_t ny = static_cast<size_t>(std::ceil(R / hstep)) + 2;
    const CMat Z = boxGrid(-R, R, -hstep, -hstep + hstep * (ny - 1.0), static_cast<size_t>(n), ny);
    double spacing = 0.0;
    std::vector<Pole> poles = polesOnGrid(f, Z, 0.0, spacing);
    if (!fnOk(f, ctx))
      return Value();
    const double tz = 1e-8 * std::max(1.0, R);
    cd value = 0.0;
    CVec pz, res;
    bool realPole = false;
    for (size_t k = 0; k < poles.size(); k++) {
      const cd z = poles[k].z;
      if (z.imag() < -tz)
        continue;
      const cd rk = residueAt(f, z, residueRadius(poles, k, spacing));
      if (std::abs(z.imag()) <= tz) {
        if (poles[k].order != 1) {
          ctx.fail("a pole of order " + std::to_string(poles[k].order) +
                   " on the real axis: the integral does not exist");
          return Value();
        }
        realPole = true;
        value += cd(0.0, kPi) * rk;
      } else {
        value += cd(0.0, 2.0 * kPi) * rk;
      }
      pz.push_back(z);
      res.push_back(rk);
    }
    if (!fnOk(f, ctx))
      return Value();
    DictInit d = {{"value", cleanC(value, std::abs(value))},
                  {"poles", pz.empty() ? Value(std::vector<std::vector<Value>>{}) : rowOf(pz)},
                  {"residues", res.empty() ? Value(std::vector<std::vector<Value>>{}) : rowOf(res)}};
    // Cross-check by direct quadrature when no pole sits on the path.
    if (!realPole) {
      QuadResult q = quadVec(
          [&](double x, double *out) {
            out[0] = f.r(x);
            return !f.failed();
          },
          1, -kInf, kInf, 1e-12, 1e-10, 4000);
      if (q.ok && q.converged)
        d.push_back({"numeric", Value(q.value[0])});
    }
    return dictOf(d);
  }
  OPS_END

  OPS_FN("real_trig_integral", 1, 1, "real_trig_integral(@F)", "Integral over 0 to 2 pi",
         kCallsNC) {
    Fn F;
    if (!argCallable(a, 0, ctx, F))
      return Value();
    // integral from 0 to 2 pi of F(theta) d theta = closed integral over |z| = 1 of
    // F(theta(z)) dz / (i z), z = e^(i theta)  (Kreyszig 16.4). On the unit circle this is
    // the trapezoid rule in theta, exponentially accurate for smooth periodic F; the
    // number of points doubles until the value settles.
    double prev = kNaN, I = 0.0;
    Vec samples;
    for (size_t M = 64; M <= (1u << 18); M *= 2) {
      // reuse the M/2 samples, add the midpoints
      Vec next(M);
      for (size_t j = 0; j < M; j++)
        next[j] = (j % 2 == 0 && !samples.empty()) ? samples[j / 2]
                                                   : F.r(2.0 * kPi * static_cast<double>(j) / M);
      if (!fnOk(F, ctx))
        return Value();
      samples = next;
      double s = 0.0;
      for (double v : samples)
        s += v;
      I = s * 2.0 * kPi / static_cast<double>(M);
      if (std::abs(I - prev) <= 1e-13 * std::max(1.0, std::abs(I)))
        return Value(I);
      prev = I;
    }
    ctx.fail("the integral did not settle - is F smooth and 2 pi periodic?");
    return Value();
  }
  OPS_END
}

} // namespace ops
} // namespace nc
