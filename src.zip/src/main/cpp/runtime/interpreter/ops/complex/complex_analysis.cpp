// Complex analysis, Kreyszig chapters 13-15.
//   is_analytic  complex_deriv  branch_cut_unwrap                       (ch. 13)
//   contour_integrate  cauchy_eval  cauchy_deriv  generate_contour
//   ml_bound_estimate                                                    (ch. 14)
//   taylor_coeffs_cplx                                                   (ch. 15)
// The radius of convergence is the calculus table's rad_of_con(coeffs) and
// the Pade approximant the existing pade(coeffs, m, n), so the proposed
// radius_of_convergence and pade_approximant are not added again.
#include <algorithm>
#include <cmath>

#include "complex_analysis.h"

namespace nc {
namespace ops {

namespace cx {

bool argPath(const Args &a, size_t i, CallContext &ctx, CVec &path) {
  if (i >= a.size() || a[i].isND() || !scipy::readCVec(a[i], path) || path.size() < 2) {
    ctx.fail(argLabel(i) +
             " must be a path: an array of 2 or more complex points (see "
             "generate_contour)");
    return false;
  }
  for (const cd &z : path)
    if (!isFiniteC(z)) {
      ctx.fail("the path holds a NaN or infinite point");
      return false;
    }
  return true;
}

bool pathIntegral(Fn &f, const CVec &path, const std::function<cd(cd, cd)> &kernel, cd &out) {
  // Segment s: z(t) = z_s + t (z_{s+1} - z_s), dz = (z_{s+1} - z_s) dt, t in [0, 1].
  // The tolerance is set by the largest segment total so far, so short
  // segments of a fine contour stop early.
  out = 0.0;
  double scale = 0.0;
  for (size_t s = 0; s + 1 < path.size(); s++) {
    const cd z0 = path[s], dz = path[s + 1] - path[s];
    if (dz == cd(0.0))
      continue;
    QuadResult q = quadVec(
        [&](double t, double *o) {
          const cd z = z0 + t * dz;
          const cd v = kernel(z, f.c(z)) * dz;
          o[0] = v.real();
          o[1] = v.imag();
          return !f.failed();
        },
        2, 0.0, 1.0, 1e-14 * std::max(1.0, scale), 1e-12, 400, 1);
    if (!q.ok)
      return false;
    out += cd(q.value[0], q.value[1]);
    scale = std::max(scale, std::abs(cd(q.value[0], q.value[1])));
  }
  return !f.failed();
}

bool mapElements(const Value &v, CallContext &ctx, size_t argIndex,
                 const std::function<cd(cd)> &op, Value &out) {
  if (scipy::isPlainNumber(v)) {
    out = numOf(op(cd(v.number, v.isComplex ? v.imag : 0.0)));
    return true;
  }
  CMat m;
  if (v.isND() || !scipy::readCMat(v, m) || m.a.empty()) {
    ctx.fail(argLabel(argIndex) + " must be a number or a matrix of numbers");
    return false;
  }
  for (cd &z : m.a)
    z = op(z);
  out = matOf(m);
  return true;
}

double windingNumber(Fn &f, cd z0, double r, size_t samples) {
  double total = 0.0;
  cd prev = f.c(z0 + r);
  for (size_t j = 1; j <= samples; j++) {
    const cd cur = f.c(z0 + std::polar(r, 2.0 * kPi * static_cast<double>(j) / samples));
    total += std::arg(cur / prev);
    prev = cur;
  }
  return total / (2.0 * kPi);
}

} // namespace cx

namespace {

// Zeroes the rounding noise of circle coefficients c_k (k from kmin): the
// noise of c_k is about 1e-15 * max|f| / r^k.
void cleanCoefficients(CVec &c, double r, long long kmin) {
  double s = 0.0;
  for (size_t i = 0; i < c.size(); i++)
    s = std::max(s, std::abs(c[i]) * std::pow(r, static_cast<double>(kmin + static_cast<long long>(i))));
  for (size_t i = 0; i < c.size(); i++) {
    const double tol = 1e-13 * s / std::pow(r, static_cast<double>(kmin + static_cast<long long>(i)));
    c[i] = cd(std::abs(c[i].real()) < tol ? 0.0 : c[i].real(),
              std::abs(c[i].imag()) < tol ? 0.0 : c[i].imag());
  }
}

double pathLength(const CVec &p) {
  double L = 0.0;
  for (size_t i = 1; i < p.size(); i++)
    L += std::abs(p[i] - p[i - 1]);
  return L;
}

} // namespace

#define OPS_DOMAIN Domain::Complex

void registerComplexAnalysis(OpsRegistry &reg) {

  // ---- ch. 13 ----
  OPS_FN("is_analytic", 3, 4, "is_analytic(F, dx, dy[, tol])", "Cauchy-Riemann check",
         kComplexArgs | kKernel) {
    CMat F;
    double dx, dy, tol = 1e-3;
    if (!argCMat(a, 0, ctx, F) || !argPositive(a, 1, ctx, dx) || !argPositive(a, 2, ctx, dy) ||
        (given(a, 3) && !argPositive(a, 3, ctx, tol)))
      return Value();
    if (F.r < 2 || F.c < 2) {
      ctx.fail("F must be a grid of at least 2 x 2 values, F[i, j] = f(x_j + i y_i)");
      return Value();
    }
    // u_x = v_y and u_y = -v_x (Kreyszig 13.4)
    Grid u(1, F.r, F.c, 2), v(1, F.r, F.c, 2);
    for (size_t k = 0; k < F.a.size(); k++) {
      u.a[k] = F.a[k].real();
      v.a[k] = F.a[k].imag();
    }
    const Grid ux = gridDiff(u, 0, dx), uy = gridDiff(u, 1, dy), vx = gridDiff(v, 0, dx),
               vy = gridDiff(v, 1, dy);
    double res = 0.0, scale = 0.0;
    CMat d(F.r, F.c);
    for (size_t k = 0; k < F.a.size(); k++) {
      res = std::max({res, std::abs(ux.a[k] - vy.a[k]), std::abs(uy.a[k] + vx.a[k])});
      scale = std::max({scale, std::abs(ux.a[k]), std::abs(uy.a[k]), std::abs(vx.a[k]),
                        std::abs(vy.a[k])});
      d.a[k] = cd(ux.a[k], vx.a[k]); // f' = u_x + i v_x
    }
    const double rel = scale > 0.0 ? res / scale : 0.0;
    return dictOf({{"analytic", Value::boolean(rel <= tol)},
                   {"max_residual", Value(res)},
                   {"relative_residual", Value(rel)},
                   {"derivative", matOf(d)}});
  }
  OPS_END

  OPS_FN("complex_deriv", 2, 3, "complex_deriv(@f, z[, h])", "Complex derivative",
         kComplexArgs | kCallsNC) {
    Fn f;
    double h0 = 0.0;
    if (!argCallable(a, 0, ctx, f) || (given(a, 2) && !argPositive(a, 2, ctx, h0)))
      return Value();
    Value out;
    if (!cx::mapElements(a[1], ctx, 1,
                         [&](cd z) {
                           const double h = h0 > 0 ? h0 : 1e-3 * std::max(1.0, std::abs(z));
                           return complexDerivative(f, z, h);
                         },
                         out))
      return Value();
    return fnOk(f, ctx) ? out : Value();
  }
  OPS_END

  OPS_FN("branch_cut_unwrap", 1, 1, "branch_cut_unwrap(Z)", "Continuous arg, log, sqrt",
         kComplexArgs) {
    CMat Z;
    if (!argCMat(a, 0, ctx, Z))
      return Value();
    // Principal arg jumps by 2 pi across the negative real axis; follow it
    // continuously: down the first column, then along every row.
    Mat ph(Z.r, Z.c);
    auto step = [](double prev, double raw) {
      double d = raw - prev;
      d -= 2.0 * kPi * std::round(d / (2.0 * kPi));
      return prev + d;
    };
    for (size_t i = 0; i < Z.r; i++) {
      ph(i, 0) = i == 0 ? std::arg(Z(0, 0)) : step(ph(i - 1, 0), std::arg(Z(i, 0)));
      for (size_t j = 1; j < Z.c; j++)
        ph(i, j) = step(ph(i, j - 1), std::arg(Z(i, j)));
    }
    CMat lg(Z.r, Z.c), sq(Z.r, Z.c);
    for (size_t k = 0; k < Z.a.size(); k++) {
      lg.a[k] = cd(std::log(std::abs(Z.a[k])), ph.a[k]);
      sq.a[k] = std::polar(std::sqrt(std::abs(Z.a[k])), 0.5 * ph.a[k]);
    }
    return dictOf({{"phase", matOf(ph)}, {"log", matOf(lg)}, {"sqrt", matOf(sq)}});
  }
  OPS_END

  // ---- ch. 14 ----
  OPS_FN("contour_integrate", 2, 2, "contour_integrate(@f, path)", "Complex line integral",
         kComplexArgs | kCallsNC) {
    Fn f;
    CVec p;
    if (!argCallable(a, 0, ctx, f) || !cx::argPath(a, 1, ctx, p))
      return Value();
    cd I;
    if (!cx::pathIntegral(f, p, [](cd, cd fz) { return fz; }, I)) {
      fnOk(f, ctx);
      return Value();
    }
    return numOf(I);
  }
  OPS_END

  OPS_FN("cauchy_eval", 3, 3, "cauchy_eval(@f, z0, path)", "Cauchy integral formula",
         kComplexArgs | kCallsNC) {
    Fn f;
    cd z0;
    CVec p;
    if (!argCallable(a, 0, ctx, f) || !argCNum(a, 1, ctx, z0) || !cx::argPath(a, 2, ctx, p))
      return Value();
    // f(z0) = 1/(2 pi i) closed integral of f(z) / (z - z0) dz  (Kreyszig 14.3)
    cd I;
    if (!cx::pathIntegral(f, p, [z0](cd z, cd fz) { return fz / (z - z0); }, I)) {
      fnOk(f, ctx);
      return Value();
    }
    return numOf(I / cd(0.0, 2.0 * kPi));
  }
  OPS_END

  OPS_FN("cauchy_deriv", 4, 4, "cauchy_deriv(@f, z0, n, path)", "Derivative by Cauchy formula",
         kComplexArgs | kCallsNC) {
    Fn f;
    cd z0;
    long long n;
    CVec p;
    if (!argCallable(a, 0, ctx, f) || !argCNum(a, 1, ctx, z0) || !argCount(a, 2, ctx, n, 0, 30) ||
        !cx::argPath(a, 3, ctx, p))
      return Value();
    // f^(n)(z0) = n!/(2 pi i) closed integral of f(z) / (z - z0)^(n+1) dz  (Kreyszig 14.4)
    const double e = static_cast<double>(n + 1);
    cd I;
    if (!cx::pathIntegral(f, p, [z0, e](cd z, cd fz) { return fz / std::pow(z - z0, e); }, I)) {
      fnOk(f, ctx);
      return Value();
    }
    return numOf(std::tgamma(e) * I / cd(0.0, 2.0 * kPi));
  }
  OPS_END

  OPS_FN("generate_contour", 2, 2, "generate_contour(type, params)", "Standard contour path",
         kComplexArgs) {
    std::string type;
    CVec p;
    if (!argText(a, 0, ctx, type) || !argCVec(a, 1, ctx, p))
      return Value();
    type = lowerText(type);
    auto realAt = [&](size_t i) { return p[i].real(); };
    auto count = [&](size_t i, size_t def) -> long long {
      return p.size() > i ? static_cast<long long>(p[i].real()) : static_cast<long long>(def);
    };
    CVec out;
    if (type == "circle") { // [center, radius(, n)]
      if (p.size() < 2 || !(realAt(1) > 0.0)) {
        ctx.fail("circle needs [center, radius(, n)] with radius > 0");
        return Value();
      }
      const long long n = count(2, 256);
      if (n < 8) {
        ctx.fail("a circle needs n >= 8 points");
        return Value();
      }
      for (long long k = 0; k <= n; k++)
        out.push_back(p[0] + std::polar(realAt(1), 2.0 * kPi * k / n));
      out.back() = out.front();
    } else if (type == "arc") { // [center, radius, theta1, theta2(, n)]
      if (p.size() < 4 || !(realAt(1) > 0.0)) {
        ctx.fail("arc needs [center, radius, theta1, theta2(, n)] with radius > 0");
        return Value();
      }
      const long long n = count(4, 128);
      for (long long k = 0; k <= n; k++)
        out.push_back(p[0] + std::polar(realAt(1), realAt(2) + (realAt(3) - realAt(2)) * k / n));
    } else if (type == "line" || type == "segment") { // [z1, z2(, n)]
      if (p.size() < 2) {
        ctx.fail("line needs [z1, z2(, n)]");
        return Value();
      }
      const long long n = std::max<long long>(2, count(2, 2));
      for (long long k = 0; k < n; k++)
        out.push_back(p[0] + (p[1] - p[0]) * (static_cast<double>(k) / (n - 1)));
    } else if (type == "polygon") { // [z1, z2, ..., zk], closed
      if (p.size() < 3) {
        ctx.fail("polygon needs at least 3 vertices");
        return Value();
      }
      out = p;
      if (out.back() != out.front())
        out.push_back(out.front());
    } else if (type == "rectangle") { // [x0, y0, x1, y1] or [z_low_left, z_up_right]
      double x0, y0, x1, y1;
      if (p.size() == 4) {
        x0 = realAt(0), y0 = realAt(1), x1 = realAt(2), y1 = realAt(3);
      } else if (p.size() == 2) {
        x0 = p[0].real(), y0 = p[0].imag(), x1 = p[1].real(), y1 = p[1].imag();
      } else {
        ctx.fail("rectangle needs [x0, y0, x1, y1] or [lower-left, upper-right] corners");
        return Value();
      }
      if (!(x1 > x0) || !(y1 > y0)) {
        ctx.fail("rectangle needs x1 > x0 and y1 > y0");
        return Value();
      }
      out = {cd(x0, y0), cd(x1, y0), cd(x1, y1), cd(x0, y1), cd(x0, y0)};
    } else if (type == "semicircle") { // [R(, n)]: -R..R on the real axis, back over the upper arc
      if (p.empty() || !(realAt(0) > 0.0)) {
        ctx.fail("semicircle needs [R(, n)] with R > 0");
        return Value();
      }
      const long long n = count(1, 256);
      const double R = realAt(0);
      out.push_back(cd(-R, 0.0));
      for (long long k = 0; k <= n; k++)
        out.push_back(std::polar(R, kPi * k / n));
      out.back() = cd(-R, 0.0);
    } else {
      ctx.fail("type must be \"circle\", \"arc\", \"line\", \"polygon\", \"rectangle\" or "
               "\"semicircle\"");
      return Value();
    }
    return rowOf(out);
  }
  OPS_END

  OPS_FN("ml_bound_estimate", 2, 3, "ml_bound_estimate(@f, path[, samples])", "ML-inequality bound",
         kComplexArgs | kCallsNC) {
    Fn f;
    CVec p;
    long long per = 64;
    if (!argCallable(a, 0, ctx, f) || !cx::argPath(a, 1, ctx, p) ||
        (given(a, 2) && !argCount(a, 2, ctx, per, 2, 10000)))
      return Value();
    // |integral of f dz| <= M L, M = max |f| on the path (Kreyszig 14.1)
    double M = 0.0;
    cd at = p[0];
    for (size_t s = 0; s + 1 < p.size(); s++)
      for (long long k = 0; k <= per; k++) {
        const cd z = p[s] + (p[s + 1] - p[s]) * (static_cast<double>(k) / per);
        const double m = std::abs(f.c(z));
        if (m > M || std::isnan(m)) {
          M = m;
          at = z;
        }
      }
    if (!fnOk(f, ctx))
      return Value();
    const double L = pathLength(p);
    return dictOf({{"M", Value(M)}, {"L", Value(L)}, {"bound", Value(M * L)}, {"max_at", numOf(at)}});
  }
  OPS_END

  // ---- ch. 15 ----
  OPS_FN("taylor_coeffs_cplx", 3, 4, "taylor_coeffs_cplx(@f, z0, N[, r])", "Complex Taylor coefficients",
         kComplexArgs | kCallsNC) {
    Fn f;
    cd z0;
    long long N;
    double r = 0.5;
    if (!argCallable(a, 0, ctx, f) || !argCNum(a, 1, ctx, z0) || !argCount(a, 2, ctx, N, 1, 500) ||
        (given(a, 3) && !argPositive(a, 3, ctx, r)))
      return Value();
    // a_k = 1/(2 pi i) closed integral of f(z) / (z - z0)^(k+1) dz on |z - z0| = r  (Kreyszig 15.4)
    CVec c = circleCoefficients(f, z0, r, 0, N - 1, circleSamples(N));
    if (!fnOk(f, ctx))
      return Value();
    cleanCoefficients(c, r, 0);
    return rowOf(c);
  }
  OPS_END

  registerComplexResidue(reg);
  registerComplexMapping(reg);
}

// Used by complex_residue.cpp too.
void cleanCircleCoefficients(CVec &c, double r, long long kmin) { cleanCoefficients(c, r, kmin); }

} // namespace ops
} // namespace nc
