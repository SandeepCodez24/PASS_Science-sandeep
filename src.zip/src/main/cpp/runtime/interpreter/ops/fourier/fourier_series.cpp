// Fourier series, integrals and transforms (Kreyszig chapter 11).
//   fourier_coeffs_real  fourier_coeffs_complex  half_range_extension
//   parseval_error  forced_oscillation_fourier  fourier_transform_integral
//   fourier_sine_cosine_transform
// The discrete transforms (fft, ifft, ...) are already NC functions; these
// work on a FUNCTION by numerical integration instead of on samples.
#include <cmath>

#include "fourier_core.h"

namespace nc {
namespace ops {

namespace {

// Optional finite limits [a, b] for a transform integral.
bool optLimits(const Args &a, size_t i, double defLo, double defHi, CallContext &ctx, double &lo,
               double &hi) {
  lo = defLo;
  hi = defHi;
  if (!given(a, i))
    return true;
  Vec v;
  if (!argVec(a, i, ctx, v))
    return false;
  if (v.size() == 1 && std::isinf(defLo) == false) { // only the upper end
    hi = v[0];
  } else if (v.size() == 2) {
    lo = v[0];
    hi = v[1];
  } else {
    ctx.fail("the limits must be [a, b]");
    return false;
  }
  if (!(hi > lo)) {
    ctx.fail("the limits need b > a");
    return false;
  }
  return true;
}

} // namespace

#define OPS_DOMAIN Domain::Fourier

void registerFourier(OpsRegistry &reg) {

  OPS_FN("fourier_coeffs_real", 3, 4, "fourier_coeffs_real(@f, p, N[, start])",
         "Real Fourier coefficients", kCallsNC) {
    Fn f;
    double p, start;
    long long N;
    if (!argCallable(a, 0, ctx, f) || !argPositive(a, 1, ctx, p) ||
        !argCount(a, 2, ctx, N, 1, 500))
      return Value();
    start = -0.5 * p;
    if (given(a, 3) && !argNum(a, 3, ctx, start))
      return Value();
    double a0;
    Vec an, bn;
    if (!fourier::realSeries(f, start, p, static_cast<size_t>(N), a0, an, bn, ctx))
      return Value();
    return dictOf({{"a0", Value(a0)}, {"a", rowOf(an)}, {"b", rowOf(bn)}});
  }
  OPS_END

  OPS_FN("fourier_coeffs_complex", 3, 4, "fourier_coeffs_complex(@f, p, N[, start])",
         "Complex Fourier coefficients", kCallsNC) {
    Fn f;
    double p, start;
    long long N;
    if (!argCallable(a, 0, ctx, f) || !argPositive(a, 1, ctx, p) ||
        !argCount(a, 2, ctx, N, 1, 500))
      return Value();
    start = -0.5 * p;
    if (given(a, 3) && !argNum(a, 3, ctx, start))
      return Value();
    // c_n = (1/p) integral of f(x) e^(-i n w x) dx, w = 2 pi / p  (Kreyszig 11.4)
    CVec C, S;
    if (!fourier::trigIntegrals(f, start, start + p, 2.0 * kPi / p, static_cast<size_t>(N), C, S,
                                ctx))
      return Value();
    const cd I(0.0, 1.0);
    CVec c;
    Vec n;
    for (long long k = -N; k <= N; k++) {
      const size_t m = static_cast<size_t>(k < 0 ? -k : k);
      const cd ck = (C[m] - (k < 0 ? -1.0 : 1.0) * I * S[m]) / p;
      c.push_back(cd(std::abs(ck.real()) < 1e-15 ? 0.0 : ck.real(),
                     std::abs(ck.imag()) < 1e-15 ? 0.0 : ck.imag()));
      n.push_back(static_cast<double>(k));
    }
    return dictOf({{"n", rowOf(n)}, {"c", rowOf(c)}});
  }
  OPS_END

  OPS_FN("half_range_extension", 4, 4,
         "half_range_extension(@f, L, N, \"even\"|\"odd\")", "Half-range expansion", kCallsNC) {
    Fn f;
    double L;
    long long N;
    std::string type;
    if (!argCallable(a, 0, ctx, f) || !argPositive(a, 1, ctx, L) ||
        !argCount(a, 2, ctx, N, 1, 500) || !argText(a, 3, ctx, type))
      return Value();
    type = lowerText(type);
    const bool even = type == "even" || type == "cosine" || type == "cos";
    const bool odd = type == "odd" || type == "sine" || type == "sin";
    if (!even && !odd) {
      ctx.fail("the type must be \"even\" (cosine series) or \"odd\" (sine series)");
      return Value();
    }
    // f on (0, L) extended evenly (period 2L): a0 + sum a_n cos(n pi x / L), or
    // oddly: sum b_n sin(n pi x / L)  (Kreyszig 11.2).
    CVec C, S;
    if (!fourier::trigIntegrals(f, 0.0, L, kPi / L, static_cast<size_t>(N), C, S, ctx))
      return Value();
    Vec c(static_cast<size_t>(N));
    for (size_t n = 1; n <= c.size(); n++)
      c[n - 1] = 2.0 * (even ? C[n] : S[n]).real() / L;
    if (even)
      return dictOf({{"a0", Value(C[0].real() / L)}, {"a", rowOf(c)}});
    return dictOf({{"b", rowOf(c)}});
  }
  OPS_END

  OPS_FN("parseval_error", 3, 4, "parseval_error(@f, coeffs, p[, start])",
         "Minimum square error", kCallsNC) {
    Fn f;
    double p, start, a0;
    Vec an, bn;
    if (!argCallable(a, 0, ctx, f) || !fourier::readCoeffDict(a[1], a0, an, bn, ctx) ||
        !argPositive(a, 2, ctx, p))
      return Value();
    start = -0.5 * p;
    if (given(a, 3) && !argNum(a, 3, ctx, start))
      return Value();
    // E* = integral of f^2 - L [2 a0^2 + sum (a_n^2 + b_n^2)], L = p/2  (Kreyszig 11.6)
    QuadResult q = quadVec(
        [&](double x, double *out) {
          const double v = f.r(x);
          out[0] = v * v;
          return !f.failed();
        },
        1, start, start + p, 1e-13, 1e-11, 4000);
    if (!fnOk(f, ctx))
      return Value();
    const double L = 0.5 * p;
    double s = 2.0 * a0 * a0;
    for (size_t n = 0; n < an.size(); n++)
      s += an[n] * an[n] + bn[n] * bn[n];
    const double E = q.value[0] - L * s;
    return Value(std::abs(E) < 1e-12 * std::max(1.0, q.value[0]) ? 0.0 : E);
  }
  OPS_END

  OPS_FN("forced_oscillation_fourier", 5, 5, "forced_oscillation_fourier(coeffs, m, c, k, w)",
         "Steady-state periodic response", 0) {
    double a0, m, c, k, w;
    Vec an, bn;
    if (!fourier::readCoeffDict(a[0], a0, an, bn, ctx) || !argNum(a, 1, ctx, m) ||
        !argNum(a, 2, ctx, c) || !argNum(a, 3, ctx, k) || !argPositive(a, 4, ctx, w))
      return Value();
    // m y'' + c y' + k y = a0 + sum (a_n cos(n w t) + b_n sin(n w t)); steady state
    // y = A0 + sum (A_n cos(n w t) + B_n sin(n w t))  (Kreyszig 11.3):
    //   K = k - m (n w)^2, D = K^2 + (c n w)^2,
    //   A_n = (K a_n - c n w b_n) / D,  B_n = (c n w a_n + K b_n) / D.
    if (k == 0.0 && a0 != 0.0) {
      ctx.fail("k = 0 with a constant term a0 has no periodic solution");
      return Value();
    }
    const size_t N = an.size();
    Vec A(N), B(N), C(N);
    for (size_t n = 1; n <= N; n++) {
      const double om = static_cast<double>(n) * w, K = k - m * om * om, cw = c * om;
      const double D = K * K + cw * cw;
      if (D == 0.0) {
        if (an[n - 1] == 0.0 && bn[n - 1] == 0.0) {
          A[n - 1] = B[n - 1] = C[n - 1] = 0.0;
          continue;
        }
        ctx.fail("resonance: harmonic n = " + std::to_string(n) +
                 " has n w = sqrt(k/m) and no damping, so there is no periodic solution");
        return Value();
      }
      A[n - 1] = (K * an[n - 1] - cw * bn[n - 1]) / D;
      B[n - 1] = (cw * an[n - 1] + K * bn[n - 1]) / D;
      C[n - 1] = std::hypot(A[n - 1], B[n - 1]);
    }
    return dictOf({{"A0", Value(k == 0.0 ? 0.0 : a0 / k)},
                   {"A", rowOf(A)},
                   {"B", rowOf(B)},
                   {"amplitude", rowOf(C)}});
  }
  OPS_END

  OPS_FN("fourier_transform_integral", 2, 3, "fourier_transform_integral(@f, w[, limits])",
         "Continuous Fourier transform", kCallsNC) {
    Fn f;
    Vec w;
    double lo, hi;
    if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, w) ||
        !optLimits(a, 2, -kInf, kInf, ctx, lo, hi))
      return Value();
    // f^(w) = 1/sqrt(2 pi) integral of f(x) e^(-i w x) dx  (Kreyszig 11.9)
    const size_t m = w.size();
    QuadResult q = quadVec(
        [&](double x, double *out) {
          const cd fx = f.c(x);
          if (f.failed())
            return false;
          for (size_t k = 0; k < m; k++) {
            const cd v = fx * std::polar(1.0, -w[k] * x);
            out[2 * k] = v.real();
            out[2 * k + 1] = v.imag();
          }
          return true;
        },
        2 * m, lo, hi, 1e-12, 1e-10, 6000);
    if (!fnOk(f, ctx))
      return Value();
    if (!q.converged) {
      ctx.fail("the integral did not converge - f must decay at infinity (or give finite limits "
               "[a, b] when f is 0 outside them)");
      return Value();
    }
    CVec F(m);
    const double s = 1.0 / std::sqrt(2.0 * kPi);
    for (size_t k = 0; k < m; k++) {
      F[k] = s * cd(q.value[2 * k], q.value[2 * k + 1]);
      if (std::abs(F[k].imag()) < 1e-13 * std::max(1.0, std::abs(F[k])))
        F[k] = cd(F[k].real(), 0.0);
    }
    return F.size() == 1 ? numOf(F[0]) : vecLike(F, a[1]);
  }
  OPS_END

  OPS_FN("fourier_sine_cosine_transform", 3, 4,
         "fourier_sine_cosine_transform(@f, w, \"cos\"|\"sin\"[, b])", "Fourier cosine/sine transform",
         kCallsNC) {
    Fn f;
    Vec w;
    std::string type;
    double lo, hi;
    if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, w) || !argText(a, 2, ctx, type) ||
        !optLimits(a, 3, 0.0, kInf, ctx, lo, hi))
      return Value();
    type = lowerText(type);
    const bool isCos = type == "cos" || type == "cosine";
    if (!isCos && type != "sin" && type != "sine") {
      ctx.fail("the type must be \"cos\" or \"sin\"");
      return Value();
    }
    // f^_c(w) = sqrt(2/pi) integral from 0 to inf of f(x) cos(w x) dx; f^_s with sin
    // (Kreyszig 11.8).
    const size_t m = w.size();
    QuadResult q = quadVec(
        [&](double x, double *out) {
          const double fx = f.r(x);
          if (f.failed())
            return false;
          for (size_t k = 0; k < m; k++)
            out[k] = fx * (isCos ? std::cos(w[k] * x) : std::sin(w[k] * x));
          return true;
        },
        m, lo, hi, 1e-12, 1e-10, 6000);
    if (!fnOk(f, ctx))
      return Value();
    if (!q.converged) {
      ctx.fail("the integral did not converge - f must decay at infinity (or give a finite upper "
               "limit b when f is 0 beyond it)");
      return Value();
    }
    Vec F(m);
    for (size_t k = 0; k < m; k++)
      F[k] = std::sqrt(2.0 / kPi) * q.value[k];
    return F.size() == 1 ? Value(F[0]) : vecLike(F, a[1]);
  }
  OPS_END
}

} // namespace ops
} // namespace nc
