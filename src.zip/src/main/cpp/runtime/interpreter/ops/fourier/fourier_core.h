#pragma once
// Fourier-series building blocks shared by fourier/ (Kreyszig ch. 11) and
// pde/ (ch. 12, whose separation-of-variables solutions are Fourier series).
#include "../support/ops_math.h"

namespace nc {
namespace ops {
namespace fourier {

// C[n] = integral over [lo, hi] of f(x) cos(n w x) dx and
// S[n] = integral of f(x) sin(n w x) dx, n = 0 .. N, in ONE adaptive
// Gauss-Kronrod pass (one call of f per node). f may be complex valued.
// False (error reported) when f fails or the integrals do not converge.
bool trigIntegrals(Fn &f, double lo, double hi, double w, size_t N, CVec &C, CVec &S,
                   CallContext &ctx);

// The real Fourier series of f with period p on [start, start + p]
// (Kreyszig 11.2):  f ~ a0 + sum a_n cos(2 pi n x / p) + b_n sin(2 pi n x / p).
bool realSeries(Fn &f, double start, double p, size_t N, double &a0, Vec &an, Vec &bn,
                CallContext &ctx);

// b_n = (2/L) integral from 0 to L of f(x) sin(n pi x / L) dx, n = 1 .. N.
bool sineCoefficients(Fn &f, double L, size_t N, Vec &bn, CallContext &ctx);

// Reads a coefficient dict {a0, a, b} (any part may be missing = zeros).
bool readCoeffDict(const Value &v, double &a0, Vec &an, Vec &bn, CallContext &ctx);

} // namespace fourier
} // namespace ops
} // namespace nc
