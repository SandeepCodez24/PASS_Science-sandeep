#include "fourier_core.h"

#include <cmath>

namespace nc {
namespace ops {
namespace fourier {

bool trigIntegrals(Fn &f, double lo, double hi, double w, size_t N, CVec &C, CVec &S,
                   CallContext &ctx) {
  const size_t m = 4 * (N + 1); // per n: Re C, Im C, Re S, Im S
  QuadResult q = quadVec(
      [&](double x, double *out) {
        const cd fx = f.c(x);
        if (f.failed())
          return false;
        for (size_t n = 0; n <= N; n++) {
          const double c = std::cos(static_cast<double>(n) * w * x),
                       s = std::sin(static_cast<double>(n) * w * x);
          out[4 * n] = fx.real() * c;
          out[4 * n + 1] = fx.imag() * c;
          out[4 * n + 2] = fx.real() * s;
          out[4 * n + 3] = fx.imag() * s;
        }
        return true;
      },
      m, lo, hi, 1e-13, 1e-11, 4000);
  if (!fnOk(f, ctx))
    return false;
  if (!q.converged) {
    // A jump makes Gauss-Kronrod converge slowly; the result is still good
    // to about the panel width there, so only refuse a clearly bad one.
    double mag = 0.0;
    for (double v : q.value)
      mag = std::max(mag, std::abs(v));
    if (!(q.error <= 1e-6 * std::max(1.0, mag))) {
      ctx.fail("the coefficient integrals did not converge - is the function bounded on the "
               "interval?");
      return false;
    }
  }
  // Parts at rounding level of the largest one are exact zeros (an odd
  // function's cosine terms, ...).
  double scale = 0.0;
  for (double v : q.value)
    scale = std::max(scale, std::abs(v));
  for (double &v : q.value)
    if (std::abs(v) <= 1e-12 * scale)
      v = 0.0;
  C.assign(N + 1, 0.0);
  S.assign(N + 1, 0.0);
  for (size_t n = 0; n <= N; n++) {
    C[n] = cd(q.value[4 * n], q.value[4 * n + 1]);
    S[n] = cd(q.value[4 * n + 2], q.value[4 * n + 3]);
  }
  return true;
}

bool realSeries(Fn &f, double start, double p, size_t N, double &a0, Vec &an, Vec &bn,
                CallContext &ctx) {
  CVec C, S;
  if (!trigIntegrals(f, start, start + p, 2.0 * kPi / p, N, C, S, ctx))
    return false;
  a0 = C[0].real() / p;
  an.assign(N, 0.0);
  bn.assign(N, 0.0);
  for (size_t n = 1; n <= N; n++) {
    an[n - 1] = 2.0 * C[n].real() / p;
    bn[n - 1] = 2.0 * S[n].real() / p;
  }
  return true;
}

bool sineCoefficients(Fn &f, double L, size_t N, Vec &bn, CallContext &ctx) {
  CVec C, S;
  if (!trigIntegrals(f, 0.0, L, kPi / L, N, C, S, ctx))
    return false;
  bn.assign(N, 0.0);
  for (size_t n = 1; n <= N; n++)
    bn[n - 1] = 2.0 * S[n].real() / L;
  return true;
}

bool readCoeffDict(const Value &v, double &a0, Vec &an, Vec &bn, CallContext &ctx) {
  a0 = 0.0;
  an.clear();
  bn.clear();
  if (!v.isDict || (!scipy::dictGet(v, "a0") && !scipy::dictGet(v, "a") && !scipy::dictGet(v, "b"))) {
    ctx.fail("the coefficients must be a dict {a0, a, b}, e.g. the result of fourier_coeffs_real");
    return false;
  }
  if (const Value *x = scipy::dictGet(v, "a0")) {
    Vec t;
    if (!scipy::readVec(*x, t) || t.size() != 1) {
      ctx.fail("a0 must be a number");
      return false;
    }
    a0 = t[0];
  }
  if (const Value *x = scipy::dictGet(v, "a"))
    if (!scipy::readVec(*x, an)) {
      ctx.fail("a must be an array of numbers");
      return false;
    }
  if (const Value *x = scipy::dictGet(v, "b"))
    if (!scipy::readVec(*x, bn)) {
      ctx.fail("b must be an array of numbers");
      return false;
    }
  const size_t n = std::max(an.size(), bn.size());
  an.resize(n, 0.0);
  bn.resize(n, 0.0);
  return true;
}

} // namespace fourier
} // namespace ops
} // namespace nc
