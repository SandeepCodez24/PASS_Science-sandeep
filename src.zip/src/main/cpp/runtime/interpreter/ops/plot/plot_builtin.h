// ops/plot/plot_builtin.h

#pragma once

#include "../../core/value.h"
#include <string>
#include <vector>

Value plotBuiltin(const std::string &name, const std::vector<Value> &args);
Value barBuiltin(const std::string &, const std::vector<Value> &);