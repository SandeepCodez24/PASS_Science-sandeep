// ops/plot/plot_builtin.h

#pragma once

#include "../../core/value.h"
#include <string>
#include <vector>

// Same "global out-of-band status flag" convention as statistics.h's
// g_lastStatsOk / vector.h's g_lastVectorOk / etc. Reset true at the start
// of plotBuiltin()/barBuiltin(); set false on an arity mismatch, a
// non-array x/y, a non-numeric array element, or mismatched x/y lengths.
// Before this flag existed, plot([1,2,3,4,5], [10,20]) silently plotted
// only the first two points with no diagnostic that x's remaining three
// values were discarded, plot([1,2,3], ["a","b","c"]) silently plotted y
// as [0,0,0] (a non-numeric element's .number defaults to 0), and a wrong-
// arity call like `z = plot([1,2])` printed its arity error but still let
// `z` come back as a plain, further-usable Value(0) - confirmed by direct
// testing.
extern bool g_lastPlotOk;

Value plotBuiltin(const std::string &name, const std::vector<Value> &args);
Value barBuiltin(const std::string &, const std::vector<Value> &);