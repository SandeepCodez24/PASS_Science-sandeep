// ops/plot/plot_builtin.cpp

#include "plot_builtin.h"

#include <algorithm>
#include <iostream>
#include <sstream>

#include "../../core/output.h"

bool g_lastPlotOk = true;

static std::string buildPreview(const std::vector<Value> &arr) {
  std::ostringstream out;

  out << "[";

  size_t previewCount = std::min<size_t>(arr.size(), 5);

  for (size_t i = 0; i < previewCount; i++) {
    if (i > 0) {
      out << ",";
    }

    // Was raw `<< arr[i].number` - the only place left in the codebase
    // still hand-rolling its own double formatting instead of reusing
    // formatNumber(), so a preview's numbers could look stylistically
    // different from how the exact same values print anywhere else in
    // the language (e.g. ostream's bare "1e-08" vs formatNumber's
    // "1.000000e-08"). Not a wrong VALUE, just an inconsistent one.
    out << formatNumber(arr[i].number);
  }

  if (arr.size() > 5) {
    out << "...";
  }

  out << "]";

  return out.str();
}

namespace {
// Shared validation for plot()/bar(): both require exactly 2 array
// arguments of equal length, with every element an actual number. Before
// this existed:
//  - a non-numeric element (e.g. plot([1,2,3], ["a","b","c"])) silently
//    read .number's default of 0, plotting [0,0,0] with no error;
//  - mismatched x/y lengths (e.g. plot([1,2,3,4,5], [10,20])) were
//    silently truncated to the shorter length via std::min(), discarding
//    the extra points with no diagnostic that anything was dropped;
//  - none of these failure paths, nor the pre-existing arity/type checks,
//    ever set any success/failure flag, so a rejected call still returned
//    a plain, further-usable Value(0) as if it had succeeded.
// All confirmed by direct testing.
bool validatePlotArgs(const std::string &fn, const std::vector<Value> &args,
                       std::vector<Value> &x, std::vector<Value> &y) {
  if (args.size() != 2) {
    std::cerr << "Error: " << fn << " requires 2 arguments\n";
    g_lastPlotOk = false;
    return false;
  }

  if (!args[0].isArray || !args[1].isArray) {
    std::cerr << "Error: " << fn << " expects arrays\n";
    g_lastPlotOk = false;
    return false;
  }

  x = args[0].elems();
  y = args[1].elems();

  if (x.size() != y.size()) {
    std::cerr << "Error: " << fn << "'s x and y arrays must be the same length (got "
              << x.size() << " and " << y.size() << ")\n";
    g_lastPlotOk = false;
    return false;
  }

  for (size_t i = 0; i < x.size(); i++) {
    if (x[i].isArray || x[i].isMatrix || x[i].isText || x[i].isDict) {
      std::cerr << "Error: " << fn << "'s x[" << i << "] must be a number\n";
      g_lastPlotOk = false;
      return false;
    }
    if (y[i].isArray || y[i].isMatrix || y[i].isText || y[i].isDict) {
      std::cerr << "Error: " << fn << "'s y[" << i << "] must be a number\n";
      g_lastPlotOk = false;
      return false;
    }
  }

  return true;
}
} // namespace

Value plotBuiltin(const std::string &, const std::vector<Value> &args) {
  g_lastPlotOk = true;

  std::vector<Value> x, y;
  if (!validatePlotArgs("plot", args, x, y))
    return Value(0);

  std::cout << "@PLOT_BEGIN\n";

  // Variable information for workspace/sidebar
  std::cout << "@VAR x " << buildPreview(x) << " 1x" << x.size() << " double\n";

  std::cout << "@VAR y " << buildPreview(y) << " 1x" << y.size() << " double\n";

  for (size_t i = 0; i < x.size(); i++) {
    std::cout << "@PLOT " << formatNumber(x[i].number) << " " << formatNumber(y[i].number)
              << "\n";
  }

  std::cout << "@PLOT_END\n";
  std::cout.flush();

  return Value(0);
}

Value barBuiltin(const std::string &, const std::vector<Value> &args) {
  g_lastPlotOk = true;

  std::vector<Value> x, y;
  if (!validatePlotArgs("bar", args, x, y))
    return Value(0);

  std::cout << "@BAR_BEGIN\n";

  // Variable information for workspace/sidebar
  std::cout << "@VAR x " << buildPreview(x) << " 1x" << x.size() << " double\n";

  std::cout << "@VAR y " << buildPreview(y) << " 1x" << y.size() << " double\n";

  for (size_t i = 0; i < x.size(); i++) {
    std::cout << "@BAR " << formatNumber(x[i].number) << " " << formatNumber(y[i].number)
              << "\n";
  }

  // Was "@PLOT_END" - a copy-paste artifact from plotBuiltin above.
  // Confirmed 2026-09-16 that nothing on the Java side currently parses
  // any of these @PLOT_*/@BAR_* markers (grepped src/main/java/, zero
  // hits), so there's no existing consumer contract to preserve here -
  // fixed to match its own "@BAR_BEGIN" for a consistent begin/end pair.
  std::cout << "@BAR_END\n";
  std::cout.flush();

  return Value(0);
}
