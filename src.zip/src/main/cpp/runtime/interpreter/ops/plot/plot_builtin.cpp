// ops/plot/plot_builtin.cpp

#include "plot_builtin.h"

#include <algorithm>
#include <iostream>
#include <sstream>

static std::string buildPreview(const std::vector<Value> &arr) {
  std::ostringstream out;

  out << "[";

  size_t previewCount = std::min<size_t>(arr.size(), 5);

  for (size_t i = 0; i < previewCount; i++) {
    if (i > 0) {
      out << ",";
    }

    out << arr[i].number;
  }

  if (arr.size() > 5) {
    out << "...";
  }

  out << "]";

  return out.str();
}

Value plotBuiltin(const std::string &, const std::vector<Value> &args) {

  if (args.size() != 2) {
    std::cerr << "Error: plot requires 2 arguments\n";
    return Value(0);
  }

  if (!args[0].isArray || !args[1].isArray) {
    std::cerr << "Error: plot expects arrays\n";
    return Value(0);
  }

  const auto &x = args[0].array;
  const auto &y = args[1].array;

  size_t count = std::min(x.size(), y.size());

  std::cout << "@PLOT_BEGIN\n";

  // Variable information for workspace/sidebar
  std::cout << "@VAR x " << buildPreview(x) << " 1x" << x.size() << " double\n";

  std::cout << "@VAR y " << buildPreview(y) << " 1x" << y.size() << " double\n";

  for (size_t i = 0; i < count; i++) {
    std::cout << "@PLOT " << x[i].number << " " << y[i].number << "\n";
  }

  std::cout << "@PLOT_END\n";
  std::cout.flush();

  return Value(0);
}

Value barBuiltin(const std::string &, const std::vector<Value> &args) {

  if (args.size() != 2) {
    std::cerr << "Error: bar requires 2 arguments\n";
    return Value(0);
  }

  if (!args[0].isArray || !args[1].isArray) {
    std::cerr << "Error: bar expects arrays\n";
    return Value(0);
  }

  const auto &x = args[0].array;
  const auto &y = args[1].array;

  size_t count = std::min(x.size(), y.size());

  std::cout << "@BAR_BEGIN\n";

  // Variable information for workspace/sidebar
  std::cout << "@VAR x " << buildPreview(x) << " 1x" << x.size() << " double\n";

  std::cout << "@VAR y " << buildPreview(y) << " 1x" << y.size() << " double\n";

  for (size_t i = 0; i < count; i++) {
    std::cout << "@BAR " << x[i].number << " " << y[i].number << "\n";
  }

  std::cout << "@PLOT_END\n";
  std::cout.flush();

  return Value(0);
}