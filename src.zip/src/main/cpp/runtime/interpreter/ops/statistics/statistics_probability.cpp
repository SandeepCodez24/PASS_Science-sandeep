// Probability theory (Kreyszig chapter 24).
//   generate_permutations  generate_combinations  conditional_distribution
// Not added again (they exist): the empirical CDF at points is ecdf(data, x),
// the marginal distributions of a joint table are margins(P), and the
// distributions themselves (binomial, Poisson, hypergeometric, normal, ...)
// are the probability-distribution functions.
#include <cmath>

#include "../support/ops_math.h"

namespace nc {
namespace ops {

namespace {

constexpr double kMaxRows = 2e6;

// The elements of a vector (numbers, text, anything) as cells.
bool argCells(const Args &a, size_t i, CallContext &ctx, std::vector<Value> &cells) {
  cells.clear();
  const Value &v = a[i];
  if (v.isArray) {
    for (size_t k = 0; k < v.length(); k++)
      cells.push_back(v.at(k));
  } else if (v.isMatrix && !v.isND() && (v.rows() == 1 || v.cols() == 1)) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.cols(); c++)
        cells.push_back(v.at(r, c));
  } else if (scipy::isPlainNumber(v) || v.isText) {
    cells.push_back(v);
  } else {
    ctx.fail("the elements must be a vector, e.g. [1, 2, 3] or [\"a\", \"b\", \"c\"]");
    return false;
  }
  return true;
}

double logChoose(double n, double k) {
  return std::lgamma(n + 1.0) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1.0);
}

} // namespace

#define OPS_DOMAIN Domain::Probability

void registerProbability(OpsRegistry &reg) {

  OPS_FN("generate_permutations", 1, 2, "generate_permutations(elements[, r])",
         "All r-permutations", 0) {
    std::vector<Value> e;
    if (!argCells(a, 0, ctx, e))
      return Value();
    long long r = static_cast<long long>(e.size());
    if (given(a, 1) && !argCount(a, 1, ctx, r, 1, static_cast<long long>(e.size())))
      return Value();
    // n! / (n - r)! rows, in lexicographic order of the positions (Kreyszig 24.4)
    const double rows = std::exp(std::lgamma(e.size() + 1.0) - std::lgamma(e.size() - r + 1.0));
    if (rows > kMaxRows) {
      ctx.fail("that is " + std::to_string(static_cast<long long>(rows)) +
               " permutations - more than 2 000 000 rows");
      return Value();
    }
    std::vector<std::vector<Value>> out;
    std::vector<size_t> pick;
    std::vector<bool> used(e.size(), false);
    std::function<void()> rec = [&]() {
      if (pick.size() == static_cast<size_t>(r)) {
        std::vector<Value> row;
        for (size_t p : pick)
          row.push_back(e[p]);
        out.push_back(std::move(row));
        return;
      }
      for (size_t k = 0; k < e.size(); k++)
        if (!used[k]) {
          used[k] = true;
          pick.push_back(k);
          rec();
          pick.pop_back();
          used[k] = false;
        }
    };
    rec();
    return Value(std::move(out));
  }
  OPS_END

  OPS_FN("generate_combinations", 2, 2, "generate_combinations(elements, r)", "All r-combinations",
         0) {
    std::vector<Value> e;
    long long r;
    if (!argCells(a, 0, ctx, e) || !argCount(a, 1, ctx, r, 1, static_cast<long long>(e.size())))
      return Value();
    const size_t n = e.size(), k = static_cast<size_t>(r);
    // C(n, r) rows, lexicographic (Kreyszig 24.4)
    if (std::exp(logChoose(static_cast<double>(n), static_cast<double>(k))) > kMaxRows) {
      ctx.fail("that is more than 2 000 000 combinations");
      return Value();
    }
    std::vector<std::vector<Value>> out;
    std::vector<size_t> idx(k);
    for (size_t i = 0; i < k; i++)
      idx[i] = i;
    for (;;) {
      std::vector<Value> row;
      for (size_t p : idx)
        row.push_back(e[p]);
      out.push_back(std::move(row));
      size_t i = k;
      while (i > 0 && idx[i - 1] == n - k + i - 1)
        i--;
      if (i == 0)
        break;
      idx[i - 1]++;
      for (size_t j = i; j < k; j++)
        idx[j] = idx[j - 1] + 1;
    }
    return Value(std::move(out));
  }
  OPS_END

  OPS_FN("conditional_distribution", 3, 3, "conditional_distribution(P, given_index, axis)",
         "Conditional distribution", 0) {
    Mat P;
    long long k, axis;
    if (!argMat(a, 0, ctx, P) || !argCount(a, 2, ctx, axis, 0, 1))
      return Value();
    const long long lim = axis == 0 ? static_cast<long long>(P.r) - 1 : static_cast<long long>(P.c) - 1;
    if (!argCount(a, 1, ctx, k, 0, lim))
      return Value();
    for (double v : P.a)
      if (v < 0.0) {
        ctx.fail("a joint distribution has no negative probabilities");
        return Value();
      }
    // P[i, j] = P(X = x_i, Y = y_j) (Kreyszig 24.9).
    // axis 0: given X = x_k (row k): P(Y = y_j | X = x_k) = P[k, j] / sum_j P[k, j]
    // axis 1: given Y = y_k (column k): P(X = x_i | Y = y_k) = P[i, k] / sum_i P[i, k]
    Vec out;
    if (axis == 0)
      out.assign(P.row(static_cast<size_t>(k)), P.row(static_cast<size_t>(k)) + P.c);
    else
      for (size_t i = 0; i < P.r; i++)
        out.push_back(P(i, static_cast<size_t>(k)));
    double s = 0.0;
    for (double v : out)
      s += v;
    if (s <= 0.0) {
      ctx.fail("the condition has probability 0, so the conditional distribution is not defined");
      return Value();
    }
    for (double &v : out)
      v /= s;
    if (axis == 0)
      return rowOf(out);
    Mat c(out.size(), 1);
    c.a = out;
    return matOf(c);
  }
  OPS_END
}

} // namespace ops
} // namespace nc
