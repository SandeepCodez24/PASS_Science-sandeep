// Mathematical statistics (Kreyszig chapter 25).
//   confidence_interval_mean  confidence_interval_var  control_chart_limits
//   operating_characteristic_curve  sign_test
// Not added again (they exist): the Kolmogorov-Smirnov test is ks_test /
// ks_1samp / ks_2samp, the Wilcoxon rank-sum test is rank_sums (and
// mann_whitney); null_hypo, p_val_cal, chi_test and lsm are the traditional
// statistics functions.
#include <algorithm>
#include <cmath>

#include "../../Scipy/special_functions/sf_core.h"
#include "../../Scipy/special_functions/sf_poly.h"
#include "../support/ops_math.h"

namespace nc {
namespace ops {

namespace {

namespace sf = scipy::sf;

// Confidence level: 0.95 or 95 (percent).
bool argLevel(const Args &a, size_t i, CallContext &ctx, double &g) {
  if (!argNum(a, i, ctx, g))
    return false;
  if (g > 1.0 && g < 100.0)
    g /= 100.0;
  if (!(g > 0.0 && g < 1.0)) {
    ctx.fail("the confidence level must be between 0 and 1 (e.g. 0.95) or a percentage (95)");
    return false;
  }
  return true;
}

void meanVar(const Vec &x, double &mean, double &var) {
  mean = 0.0;
  for (double v : x)
    mean += v;
  mean /= static_cast<double>(x.size());
  var = 0.0;
  for (double v : x)
    var += (v - mean) * (v - mean);
  var /= static_cast<double>(x.size() - 1);
}

// d2(n) = E(range) / sigma and d3(n) = sd(range) / sigma of n normal values,
// from the integrals of the range distribution (Harter's formulas), so any
// subgroup size works without a table.
void rangeConstants(int n, double &d2, double &d3) {
  auto Phi = [](double x) { return sf::ndtr(x); };
  d2 = sf::quad([&](double x) { return 1.0 - std::pow(Phi(x), n) - std::pow(1.0 - Phi(x), n); },
                -sf::Inf, sf::Inf, 1e-12, 1e-11);
  // E(W^2) = 2 double integral over x < y of
  //          1 - F(y)^n - (1 - F(x))^n + (F(y) - F(x))^n
  const double ew2 = 2.0 * sf::quad(
                               [&](double y) {
                                 const double Fy = Phi(y);
                                 return sf::quad(
                                     [&](double x) {
                                       const double Fx = Phi(x);
                                       return 1.0 - std::pow(Fy, n) - std::pow(1.0 - Fx, n) +
                                              std::pow(Fy - Fx, n);
                                     },
                                     -sf::Inf, y, 1e-12, 1e-10);
                               },
                               -sf::Inf, sf::Inf, 1e-11, 1e-10);
  d3 = std::sqrt(std::max(0.0, ew2 - d2 * d2));
}

// c4(n) = E(s) / sigma
double c4Of(int n) {
  return std::sqrt(2.0 / (n - 1.0)) * std::exp(std::lgamma(n / 2.0) - std::lgamma((n - 1.0) / 2.0));
}

double logChoose(double n, double k) {
  if (k < 0 || k > n)
    return -sf::Inf;
  return std::lgamma(n + 1.0) - std::lgamma(k + 1.0) - std::lgamma(n - k + 1.0);
}

// P(X <= k), X ~ Binomial(n, p)
double binomCdf(long long k, long long n, double p) {
  if (k < 0)
    return 0.0;
  if (k >= n)
    return 1.0;
  double s = 0.0;
  for (long long x = 0; x <= k; x++) {
    if (p == 0.0) {
      s += x == 0 ? 1.0 : 0.0;
      continue;
    }
    if (p == 1.0) {
      s += x == n ? 1.0 : 0.0;
      continue;
    }
    s += std::exp(logChoose(static_cast<double>(n), static_cast<double>(x)) + x * std::log(p) +
                  (n - x) * std::log1p(-p));
  }
  return std::min(1.0, s);
}

// P(X >= k), X ~ Binomial(n, 1/2), summed directly (no 1 - cdf cancellation)
double binomUpperHalf(long long k, long long n) {
  if (k <= 0)
    return 1.0;
  double s = 0.0;
  for (long long x = k; x <= n; x++)
    s += std::exp(logChoose(static_cast<double>(n), static_cast<double>(x)) - n * std::log(2.0));
  return std::min(1.0, s);
}

} // namespace

#define OPS_DOMAIN Domain::Statistics

void registerInference(OpsRegistry &reg) {

  OPS_FN("confidence_interval_mean", 2, 3, "confidence_interval_mean(data, level[, known_variance])",
         "Confidence interval, mean", 0) {
    Vec x;
    double g, s2;
    if (!argVec(a, 0, ctx, x, 2) || !argLevel(a, 1, ctx, g))
      return Value();
    double mean, var;
    meanVar(x, mean, var);
    const double n = static_cast<double>(x.size());
    double c, half;
    std::string method;
    if (given(a, 2)) {
      // sigma^2 known: x_bar -+ c sigma / sqrt(n), Phi(c) = (1 + g)/2  (Kreyszig 25.3)
      if (!argPositive(a, 2, ctx, s2))
        return Value();
      c = sf::ndtri(0.5 * (1.0 + g));
      half = c * std::sqrt(s2 / n);
      method = "normal";
    } else {
      // unknown: x_bar -+ c s / sqrt(n), c from Student's t with n - 1 degrees of freedom
      c = sf::stdtrit(n - 1.0, 0.5 * (1.0 + g));
      half = c * std::sqrt(var / n);
      method = "t";
    }
    return dictOf({{"lower", Value(mean - half)},
                   {"upper", Value(mean + half)},
                   {"mean", Value(mean)},
                   {"half_width", Value(half)},
                   {"c", Value(c)},
                   {"method", Value(method)}});
  }
  OPS_END

  OPS_FN("confidence_interval_var", 2, 2, "confidence_interval_var(data, level)",
         "Confidence interval, variance", 0) {
    Vec x;
    double g;
    if (!argVec(a, 0, ctx, x, 2) || !argLevel(a, 1, ctx, g))
      return Value();
    double mean, var;
    meanVar(x, mean, var);
    const double df = static_cast<double>(x.size()) - 1.0;
    // [(n-1) s^2 / c2, (n-1) s^2 / c1], F(c1) = (1 - g)/2, F(c2) = (1 + g)/2 for
    // chi-square with n - 1 degrees of freedom (Kreyszig 25.3). chdtri takes the upper tail.
    const double c1 = sf::chdtri(df, 0.5 * (1.0 + g)), c2 = sf::chdtri(df, 0.5 * (1.0 - g));
    const double lo = df * var / c2, hi = df * var / c1;
    return dictOf({{"lower", Value(lo)},
                   {"upper", Value(hi)},
                   {"variance", Value(var)},
                   {"sd_lower", Value(std::sqrt(lo))},
                   {"sd_upper", Value(std::sqrt(hi))},
                   {"c1", Value(c1)},
                   {"c2", Value(c2)}});
  }
  OPS_END

  OPS_FN("control_chart_limits", 1, 3,
         "control_chart_limits(data[, type=\"x_bar\"|\"r\"|\"s\"|\"p\"][, k=3])",
         "Control chart limits", 0) {
    Mat X;
    if (!argMat(a, 0, ctx, X))
      return Value();
    std::string type = "x_bar";
    if (given(a, 1) && !argText(a, 1, ctx, type))
      return Value();
    type = lowerText(type);
    if (type == "xbar" || type == "mean")
      type = "x_bar";
    double k = 3.0;
    if (given(a, 2) && !argPositive(a, 2, ctx, k))
      return Value();
    // One sample (subgroup) per row (Kreyszig 25.5).
    const size_t m = X.r, n = X.c;
    if (m < 2 || n < 2 || n > 100) {
      ctx.fail("data must hold one sample per row: at least 2 samples of 2 to 100 values");
      return Value();
    }
    Vec mean(m), range(m), sd(m);
    for (size_t i = 0; i < m; i++) {
      const Vec row(X.row(i), X.row(i) + n);
      double mu, v;
      meanVar(row, mu, v);
      mean[i] = mu;
      sd[i] = std::sqrt(v);
      range[i] = *std::max_element(row.begin(), row.end()) - *std::min_element(row.begin(), row.end());
    }
    auto avg = [](const Vec &v) {
      double s = 0.0;
      for (double d : v)
        s += d;
      return s / static_cast<double>(v.size());
    };
    double cl, ucl, lcl;
    Vec stat;
    const int ni = static_cast<int>(n);
    if (type == "x_bar") { // x_bar_bar -+ k R_bar / (d2 sqrt(n))
      double d2, d3;
      rangeConstants(ni, d2, d3);
      cl = avg(mean);
      const double w = k * avg(range) / (d2 * std::sqrt(static_cast<double>(n)));
      ucl = cl + w;
      lcl = cl - w;
      stat = mean;
    } else if (type == "r") { // R_bar (1 -+ k d3 / d2)
      double d2, d3;
      rangeConstants(ni, d2, d3);
      cl = avg(range);
      ucl = cl * (1.0 + k * d3 / d2);
      lcl = std::max(0.0, cl * (1.0 - k * d3 / d2));
      stat = range;
    } else if (type == "s") { // s_bar (1 -+ k sqrt(1 - c4^2) / c4)
      const double c4 = c4Of(ni);
      cl = avg(sd);
      ucl = cl * (1.0 + k * std::sqrt(1.0 - c4 * c4) / c4);
      lcl = std::max(0.0, cl * (1.0 - k * std::sqrt(1.0 - c4 * c4) / c4));
      stat = sd;
    } else if (type == "p") { // p_bar -+ k sqrt(p_bar (1 - p_bar) / n), rows of 0/1 values
      for (double v : X.a)
        if (v != 0.0 && v != 1.0) {
          ctx.fail("a p chart needs 0 (good) / 1 (defective) values, one sample per row");
          return Value();
        }
      cl = avg(mean);
      const double w = k * std::sqrt(cl * (1.0 - cl) / static_cast<double>(n));
      ucl = std::min(1.0, cl + w);
      lcl = std::max(0.0, cl - w);
      stat = mean;
    } else {
      ctx.fail("type must be \"x_bar\", \"r\", \"s\" or \"p\"");
      return Value();
    }
    Vec out;
    for (size_t i = 0; i < m; i++)
      if (stat[i] > ucl || stat[i] < lcl)
        out.push_back(static_cast<double>(i));
    return dictOf({{"cl", Value(cl)},
                   {"ucl", Value(ucl)},
                   {"lcl", Value(lcl)},
                   {"values", rowOf(stat)},
                   {"out_of_control",
                    out.empty() ? Value(std::vector<std::vector<Value>>{}) : rowOf(out)}});
  }
  OPS_END

  OPS_FN("operating_characteristic_curve", 4, 4, "operating_characteristic_curve(N, n, c, p)",
         "Acceptance probability P(A)", 0) {
    double Nd;
    long long n, c;
    Vec p;
    if (!argNum(a, 0, ctx, Nd) || !argCount(a, 1, ctx, n, 1, 100000000) ||
        !argCount(a, 2, ctx, c, 0, 100000000) || !argVec(a, 3, ctx, p))
      return Value();
    const bool infinite = Nd == 0.0 || std::isinf(Nd);
    if (!infinite && (Nd != std::floor(Nd) || Nd < static_cast<double>(n))) {
      ctx.fail("the lot size N must be a whole number >= n (or 0 / inf for a very large lot)");
      return Value();
    }
    for (double v : p)
      if (v < 0.0 || v > 1.0) {
        ctx.fail("every defect fraction p must be in [0, 1]");
        return Value();
      }
    // Accept the lot when a sample of n has at most c defectives (Kreyszig 25.6):
    // P(A) = sum_{x <= c} C(M, x) C(N - M, n - x) / C(N, n), M = p N defectives
    // (hypergeometric); a very large lot (N = 0 or inf) is binomial.
    Vec PA(p.size());
    for (size_t i = 0; i < p.size(); i++) {
      if (infinite) {
        PA[i] = binomCdf(c, n, p[i]);
        continue;
      }
      const double M = std::round(p[i] * Nd);
      double s = 0.0;
      const double den = logChoose(Nd, static_cast<double>(n));
      for (long long x = 0; x <= c && x <= n; x++)
        s += std::exp(logChoose(M, static_cast<double>(x)) +
                      logChoose(Nd - M, static_cast<double>(n - x)) - den);
      PA[i] = std::min(1.0, s);
    }
    return vecLike(PA, a[3]);
  }
  OPS_END

  OPS_FN("sign_test", 2, 3, "sign_test(data, median0[, alternative]) | sign_test(x, y[, alternative])",
         "Sign test for the median", 0) {
    Vec x, m0;
    if (!argVec(a, 0, ctx, x) || !argVec(a, 1, ctx, m0))
      return Value();
    std::string alt = "two-sided";
    if (given(a, 2) && !argText(a, 2, ctx, alt))
      return Value();
    alt = lowerText(alt);
    if (alt == "two_sided")
      alt = "two-sided";
    if (alt != "two-sided" && alt != "greater" && alt != "less") {
      ctx.fail("alternative must be \"two-sided\", \"greater\" or \"less\"");
      return Value();
    }
    // Differences from the hypothesised median (or paired differences x - y); zeros are
    // dropped. Under H0 the number of positive signs is Binomial(n, 1/2) (Kreyszig 25.8).
    if (m0.size() != 1 && m0.size() != x.size()) {
      ctx.fail("the second argument must be the median (one number) or a paired sample of the "
               "same size");
      return Value();
    }
    long long pos = 0, neg = 0;
    for (size_t i = 0; i < x.size(); i++) {
      const double d = x[i] - (m0.size() == 1 ? m0[0] : m0[i]);
      if (d > 0)
        pos++;
      else if (d < 0)
        neg++;
    }
    const long long n = pos + neg;
    if (n == 0) {
      ctx.fail("every value equals the median - no signs to test");
      return Value();
    }
    double pv;
    if (alt == "greater") // H1: median > m0 - many positive signs
      pv = binomUpperHalf(pos, n);
    else if (alt == "less")
      pv = binomCdf(pos, n, 0.5);
    else
      pv = std::min(1.0, 2.0 * std::min(binomCdf(pos, n, 0.5), binomUpperHalf(pos, n)));
    return dictOf({{"positives", Value(static_cast<double>(pos))},
                   {"negatives", Value(static_cast<double>(neg))},
                   {"n", Value(static_cast<double>(n))},
                   {"p_value", Value(pv)},
                   {"alternative", Value(alt)}});
  }
  OPS_END
}

} // namespace ops
} // namespace nc
