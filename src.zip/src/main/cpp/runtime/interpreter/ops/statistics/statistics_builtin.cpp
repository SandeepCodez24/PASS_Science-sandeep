#include "statistics_builtin.h"
#include "statistics.h"

#include <functional>
#include <iostream>
#include <unordered_map>

Value statisticsBuiltin(const std::string &name,
                        const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= CENTRAL TENDENCY ================= */

      {"mean",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("mean", 1))
           return Value();
         return mean(a[0]);
       }},

      {"median",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("median", 1))
           return Value();
         return median(a[0]);
       }},

      {"mode",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("mode", 1))
           return Value();
         return mode(a[0]);
       }},

      {"geo_mean",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("geo_mean", 1))
           return Value();
         return geo_mean(a[0]);
       }},

      {"harmo_mean",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("harmo_mean", 1))
           return Value();
         return harmo_mean(a[0]);
       }},

      {"trim_mean",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("trim_mean", 1))
           return Value();
         return trim_mean(a[0]);
       }},

      /* ================= VARIABILITY ================= */

      {"PVAR",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("PVAR", 1))
           return Value();
         return PVAR(a[0]);
       }},

      {"var",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("var", 1))
           return Value();
         return var(a[0]);
       }},

      {"PSD",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("PSD", 1))
           return Value();
         return PSD(a[0]);
       }},

      {"sd",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sd", 1))
           return Value();
         return sd(a[0]);
       }},

      {"coeff_var",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("coeff_var", 1))
           return Value();
         return coeff_var(a[0]);
       }},

      {"skew",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("skew", 1))
           return Value();
         return skew(a[0]);
       }},

      {"Kurtosis",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Kurtosis", 1))
           return Value();
         return Kurtosis(a[0]);
       }},

      {"Std_Error",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Std_Error", 1))
           return Value();
         return Std_Error(a[0]);
       }},

      /* ================= RELATIONSHIP / CORRELATION ================= */

      {"corr_coeff",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("corr_coeff", 2))
           return Value();
         return corr_coeff(a[0], a[1]);
       }},

      {"co_var",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("co_var", 2))
           return Value();
         return co_var(a[0], a[1]);
       }},

      /* ================= STATISTICAL TESTS ================= */

      {"lsm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("lsm", 1))
           return Value();
         return lsm(a[0]);
       }},

      {"null_hypo",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("null_hypo", 1))
           return Value();
         return null_hypo(a[0]);
       }},

      {"p_val_cal",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("p_val_cal", 1))
           return Value();
         return p_val_cal(a[0]);
       }},

      {"chi_test",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("chi_test", 2))
           return Value();
         return chi_test(a[0], a[1]);
       }},

      /* ================= NORMALIZATION ================= */

      {"LNorm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("LNorm", 1))
           return Value();
         return Lnorm(a[0]);
       }},

      {"Lnorm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Lnorm", 1))
           return Value();
         return Lnorm(a[0]);
       }},

      {"lnorm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("lnorm", 1))
           return Value();
         return Lnorm(a[0]);
       }},

      /* ================= QUARTILES ================= */

      {"Q1",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Q1", 1))
           return Value();
         return Q1(a[0]);
       }},

      {"Q2",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Q2", 1))
           return Value();
         return Q2(a[0]);
       }},

      {"Q3",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Q3", 1))
           return Value();
         return Q3(a[0]);
       }},

      {"IQR",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("IQR", 1))
           return Value();
         return IQR(a[0]);
       }},

      {"Range",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Range", 1))
           return Value();
         return Range(a[0]);
       }},

      /* ================= BASIC EXTRA ================= */

      {"Sum",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Sum", 1))
           return Value();
         return Sum(a[0]);
       }},

      {"Count",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Count", 1))
           return Value();
         return Count(a[0]);
       }},

      {"Min",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Min", 1))
           return Value();
         return Min(a[0]);
       }},

      {"Max",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Max", 1))
           return Value();
         return Max(a[0]);
       }},

      {"Percentile",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Percentile", 2))
           return Value();
         return Percentile(a[0], a[1]);
       }},

      {"ZScore",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("ZScore", 3))
           return Value();
         return ZScore(a[0], a[1], a[2]);
       }},
      {"CV",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("CV", 1))
           return Value();
         return coeff_var(a[0]);
       }},

  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown statistics function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}