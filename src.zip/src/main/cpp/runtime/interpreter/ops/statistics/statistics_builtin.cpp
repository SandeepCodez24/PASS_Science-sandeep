#include "statistics_builtin.h"
#include "statistics.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

Value statisticsBuiltin(const std::string &name,
                        const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      g_lastStatsOk = false;
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= CENTRAL TENDENCY ================= */

      {"mean",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "mean", 1))
           return Value();
         return mean(a[0]);
       }},

      {"median",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "median", 1))
           return Value();
         return median(a[0]);
       }},

      {"mode",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "mode", 1))
           return Value();
         return mode(a[0]);
       }},

      {"geo_mean",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "geo_mean", 1))
           return Value();
         return geo_mean(a[0]);
       }},

      {"harmo_mean",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "harmo_mean", 1))
           return Value();
         return harmo_mean(a[0]);
       }},

      {"trim_mean",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "trim_mean", 1))
           return Value();
         return trim_mean(a[0]);
       }},

      /* ================= VARIABILITY ================= */

      {"pvar",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "pvar", 1))
           return Value();
         return PVAR(a[0]);
       }},

      {"var",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "var", 1))
           return Value();
         return var(a[0]);
       }},

      {"psd",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "psd", 1))
           return Value();
         return PSD(a[0]);
       }},

      {"sd",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sd", 1))
           return Value();
         return sd(a[0]);
       }},

      {"coeff_var",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "coeff_var", 1))
           return Value();
         return coeff_var(a[0]);
       }},

      {"skew",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "skew", 1))
           return Value();
         return skew(a[0]);
       }},

      {"kurtosis",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "kurtosis", 1))
           return Value();
         return Kurtosis(a[0]);
       }},

      {"std_error",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "std_error", 1))
           return Value();
         return Std_Error(a[0]);
       }},

      /* ================= RELATIONSHIP / CORRELATION ================= */

      {"corr_coeff",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "corr_coeff", 2))
           return Value();
         return corr_coeff(a[0], a[1]);
       }},

      {"co_var",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "co_var", 2))
           return Value();
         return co_var(a[0], a[1]);
       }},

      /* ================= STATISTICAL TESTS ================= */

      {"lsm",
       [](const std::vector<Value> &a) -> Value {
         // 1 arg: legacy fit against the array's own 0-based index.
         // 2 args: standard OLS fit of y (a[1]) on x (a[0]).
         if (a.size() == 1)
           return lsm(a[0]);
         if (a.size() == 2)
           return lsm(a[0], a[1]);
         std::cerr << "Error: Function 'lsm' expects 1 or 2 args, got "
                   << a.size() << "\n";
         g_lastStatsOk = false;
         return Value();
       }},

      {"null_hypo",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "null_hypo", 1))
           return Value();
         return null_hypo(a[0]);
       }},

      {"p_val_cal",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "p_val_cal", 1))
           return Value();
         return p_val_cal(a[0]);
       }},

      {"chi_test",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "chi_test", 2))
           return Value();
         return chi_test(a[0], a[1]);
       }},

      /* ================= NORMALIZATION ================= */

      {"lnorm",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "lnorm", 1))
           return Value();
         return Lnorm(a[0]);
       }},

      /* ================= QUARTILES ================= */

      {"Q1",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "Q1", 1))
           return Value();
         return Q1(a[0]);
       }},

      {"Q2",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "Q2", 1))
           return Value();
         return Q2(a[0]);
       }},

      {"Q3",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "Q3", 1))
           return Value();
         return Q3(a[0]);
       }},

      {"IQR",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "IQR", 1))
           return Value();
         return IQR(a[0]);
       }},

      {"range",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "range", 1))
           return Value();
         return Range(a[0]);
       }},

      /* ================= BASIC EXTRA ================= */

      {"sum",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sum", 1))
           return Value();
         return Sum(a[0]);
       }},

      {"count",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "count", 1))
           return Value();
         return Count(a[0]);
       }},

      {"min",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "min", 1))
           return Value();
         return Min(a[0]);
       }},

      {"max",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "max", 1))
           return Value();
         return Max(a[0]);
       }},

      {"percentile",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "percentile", 2))
           return Value();
         return Percentile(a[0], a[1]);
       }},

      {"z_score",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "z_score", 3))
           return Value();
         return ZScore(a[0], a[1], a[2]);
       }},
      {"cv",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cv", 1))
           return Value();
         return coeff_var(a[0]);
       }},

      // Orphaned before this fix: fully implemented in statistics.cpp but
      // never registered here (or in the outer builtins.cpp table), making
      // it permanently unreachable from any NC script - same pattern as
      // quotient/matrix_pow/norm_vector found earlier this pass.
      {"l2norm",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "l2norm", 1))
           return Value();
         return L2Norm(a[0]);
       }},

  };

  // Exact match first, THEN lowercase fallback (fixed 2026-09-16) -
  // deliberately NOT the same single-step lowercase used in every other
  // inner dispatch table this pass, because this table has a documented
  // exception: Q1/Q2/Q3/IQR are intentionally registered capitalized-only
  // (conventional statistics notation, per explicit request - see the
  // matching comment in the outer builtins.cpp table) and are meant to
  // stay case-SENSITIVE, unlike every other function here. Confirmed
  // live before this fix: "Q1(...)" worked, "q1(...)" already failed -
  // that's the intended, existing behavior, not a bug to flatten.
  // Trying the raw name first preserves that (an exact "Q1" call always
  // matches directly); falling back to a lowercased attempt only when
  // the raw match fails fixes case-insensitivity for the ~19 ordinary
  // lowercase-keyed functions here (e.g. "MEAN"/"Mean" now resolve to
  // "mean") without ever making "q1"/"iqr" spuriously match "Q1"/"IQR"
  // (lowercasing "q1" still doesn't equal the literal key "Q1").
  auto it = table.find(name);
  if (it == table.end()) {
    std::string key = name;
    std::transform(key.begin(), key.end(), key.begin(),
                   [](unsigned char c) { return std::tolower(c); });
    it = table.find(key);
  }
  if (it == table.end()) {
    std::cerr << "Error: Unknown statistics function '" << name << "'\n";
    g_lastStatsOk = false;
    return Value();
  }

  // Reset here, once per top-level dispatch call, rather than inside every
  // individual statistics.cpp function: several of those functions call
  // each other internally (PVAR/var/coeff_var/skew/Kurtosis/Std_Error all
  // call mean()/sd()/PSD() on the SAME already-validated argument) - a
  // reset inside each one would clobber an outer function's failure signal
  // the moment it called into an inner helper.
  g_lastStatsOk = true;

  return it->second(args);
}