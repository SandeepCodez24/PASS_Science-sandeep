#include "statistics.h"
#include "../../core/elementwise.h"
#include "../matrix/nd_array.h"
#include <algorithm>
#include <cstring>
#include <limits>
#include <cmath>
#include <iostream>
#include <sstream>
#include <utility>
#include <vector>

bool g_lastStatsOk = true;

/* helper */

// Packed real data (one flat buffer of doubles): the numbers in row-major
// order, read straight from the buffer - the same order and values the cell
// walk below gives, without building a Value per element (that walk was
// ~100x slower than the arithmetic it fed). An array is copied as it is; a
// matrix page by page, each column-major page read row by row.
static std::vector<double> packedRowMajor(const Value &v) {
  const double *buf = v.packedData();
  const size_t n = v.packedSize();
  if (v.isArray)
    return std::vector<double>(buf, buf + n);
  const std::vector<size_t> &shape = v.ndShape(); // [..., rows, cols]
  const size_t rows = shape[shape.size() - 2], cols = shape[shape.size() - 1];
  const size_t page = rows * cols;
  std::vector<double> d(n);
  size_t k = 0;
  for (size_t p = 0; p + page <= n && page > 0; p += page)
    for (size_t r = 0; r < rows; r++)
      for (size_t c = 0; c < cols; c++)
        d[k++] = buf[p + c * rows + r];
  return d;
}

static std::vector<double> toVec(Value v) {
  std::vector<double> d;

  if ((v.isMatrix || v.isArray) && v.isPacked())
    return packedRowMajor(v);

  if (v.isMatrix) {
    // A matrix of any shape counts as the list of all its elements, row by
    // row - the way max(A) and min(A) read it (and NumPy's np.mean(A)).
    for (const Value &cell : nd::rowMajorCells(v))
      d.push_back(cell.number);
  } else if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      d.push_back(v.numAt(i));
  }

  return d;
}

// toVec() above silently treats ANY non-array Value as an empty vector -
// every public function historically built its own "empty -> return 0"
// fallback ON TOP of that, so a genuinely-invalid non-array argument
// (mean(5), sum("x"), ...) silently produced the SAME output as a
// genuinely-empty array, with no way to tell them apart. This wrapper
// makes that distinction visible: it flags g_lastStatsOk=false and prints
// a clear error for a non-array input, then defers to toVec() for the
// actual (possibly still legitimately-empty) conversion.
static std::vector<double> toVecChecked(const Value &v, const char *fn) {
  if (!v.isArray && !v.isMatrix) {
    std::cerr << "Error: " << fn << " expects a vector or a matrix, got a "
              << (v.isText ? "string" : v.isDict ? "dict" : "number") << "\n";
    g_lastStatsOk = false;
    return {};
  }
  // Packed data holds plain numbers only: nothing to check.
  if (v.isPacked())
    return toVec(v);
  // Text elements have no value to compute with: they read as 0 in `number`.
  const std::vector<Value> cells = v.isMatrix ? nd::rowMajorCells(v) : v.elems();
  for (const Value &cell : cells)
    if (cell.isText || cell.isDict || cell.isObject || cell.isFunctionRef) {
      std::cerr << "Error: " << fn << " needs numbers - this value holds "
                << (cell.isText ? "text" : "non-numeric elements") << "\n";
      g_lastStatsOk = false;
      return {};
    }
  return toVec(v);
}

// Stops the statement with a message; for input a function cannot answer. A
// message returned as the result instead looked like a successful text value.
static Value statsError(const std::string &message) {
  std::cerr << "Error: " << message << "\n";
  g_lastStatsOk = false;
  return Value(0);
}

/* ---- multicore reductions (nc::par) ----

   sum / mean / var / pvar / sd / psd / l2norm read packed data straight
   from the buffer, in storage order, and add it up in blocks combined in
   block order (nc::par::reduceBlocks). The blocks depend on the element
   count only, so the result is the same for every thread count. Compared
   with the old row-by-row loop, the last bits of a sum can differ for a
   matrix of non-integer numbers (decision 2 of the design: accepted once);
   an array shorter than one block (65,536 elements) adds up exactly as
   before. Other data takes the old path through toVecChecked(). */

namespace {

constexpr nc::par::Cost kSumCost = nc::par::reduce(0.7); // measured: 0.7 ns per element

// The same cost for a rule with function steps (sin, exp ... 2026-11-23):
// each element is computed, not read, so the work is compute-bound and may
// use every core instead of the memory-bound cap. Only the thread count
// follows the kind; the blocks - and so the bits - depend on the size and
// nsPerItem alone (nc::par::plan).
nc::par::Cost costFor(nc::par::Cost c, const NumTensor *lazy) {
  return lazy && !lazy->portableRule() ? nc::par::Cost{nc::par::Kind::Compute, c.nsPerItem} : c;
}

// The numbers of `v` for a reduction: packed data in place (no copy), the
// rest copied by toVecChecked() (which reports non-numeric input).
struct NumView {
  const double *data = nullptr;
  // A lazy range (maybe with a chain): read element by element from its
  // rule, never built (2026-11-21) - sum([-pi:1e-8:pi] * 1000) needs no
  // 5 GB. Same blocks, same order, same values: the same bits.
  const NumTensor *lazy = nullptr;
  size_t n = 0;
  std::vector<double> owned;
  double at(size_t k) const { return lazy ? lazy->lazyValue(k) : data[k]; }
};

bool viewOf(const Value &v, const char *fn, NumView &view) {
  if ((v.isArray || v.isMatrix) && v.isPacked()) {
    view.lazy = v.lazyTensor();
    view.data = view.lazy ? nullptr : v.packedData();
    view.n = v.packedSize();
    return true;
  }
  view.owned = toVecChecked(v, fn);
  view.data = view.owned.data();
  view.n = view.owned.size();
  return g_lastStatsOk;
}

// sum of f(x) over the view; false when Stop was pressed (the caller then
// fails the call without a message - the REPL reports the stop).
template <class F> bool sumOf(const NumView &view, const char *label, F f, double &out) {
  const double *x = view.data;
  const NumTensor *lazy = view.lazy;
  const nc::par::Outcome r = nc::par::reduceBlocks(
      view.n, costFor(kSumCost, lazy), label, 0.0,
      [&](size_t begin, size_t end) {
        double s = 0;
        if (lazy)
          for (size_t k = begin; k < end; k++)
            s += f(lazy->lazyValue(k));
        else
          for (size_t k = begin; k < end; k++)
            s += f(x[k]);
        return s;
      },
      [](double acc, double part) { return acc + part; }, out);
  if (r != nc::par::Outcome::Done) {
    g_lastStatsOk = false;
    return false;
  }
  return true;
}

double identity(double x) { return x; }

// Median of d[lo, hi) (non-empty), reordering that range: nth_element
// instead of a full sort - the same value, in linear time.
/* ---- exact order statistics without a copy (2026-11-23, Phase 2) ----

   docs/Large_Data_Design.md section 5.3. median(X) / percentile(X, p) of a
   rule (6.28 G elements: 50 GB to copy) or of stored data whose copy does
   not fit: the k-th smallest value is found exactly by a radix selection
   over the values' 64-bit keys (order-preserving: -inf < ... < -0 < +0 <
   ... < inf), reading the data in place on several cores - 16 bits of the
   key per pass, until the candidates left fit in memory (or all 64 bits
   are known), then nth_element over those few. Typically 2-3 passes and a
   few MB. Data that can be copied keeps the old nth_element path, so every
   result that worked before is unchanged. NaN: the old path's answer is
   undefined (nth_element has no order for it); here any NaN makes the
   median NaN (and a percentile 0, as the old code turns a NaN result). */

uint64_t orderKey(double x) {
  uint64_t b;
  std::memcpy(&b, &x, sizeof b);
  return (b >> 63) ? ~b : (b | 0x8000000000000000ull);
}
double keyValue(uint64_t k) {
  const uint64_t b = (k >> 63) ? (k & 0x7FFFFFFFFFFFFFFFull) : ~k;
  double x;
  std::memcpy(&x, &b, sizeof x);
  return x;
}

// Element reader over storage order: a rule or a stored buffer, read in
// blocks (the order does not matter for a count).
struct BlockReader {
  const NumTensor *lazy = nullptr;
  const double *data = nullptr;
  size_t n = 0;
  void read(size_t first, size_t m, double *out) const {
    if (lazy)
      lazy->lazyBlock(first, m, out);
    else
      std::memcpy(out, data + first, m * sizeof(double));
  }
};

// Runs body(begin, end, part) over [0, n) in about 4 blocks per thread, part
// = the block's index; returns the number of blocks (0: Stop pressed).
template <class Body> size_t coarseBlocks(size_t n, bool compute, const char *label, Body &&body) {
  const size_t threads = static_cast<size_t>(std::max(1, nc::par::threadCount()));
  const size_t blockSize = std::max<size_t>(size_t(1) << 20, (n + threads * 4 - 1) / (threads * 4));
  nc::par::Plan plan = nc::par::planWithBlockSize(
      n, compute ? nc::par::Cost{nc::par::Kind::Compute, 2.0} : nc::par::reduce(1.0), blockSize);
  const nc::par::Outcome r = nc::par::forPlan(plan, compute ? nc::par::Kind::Compute : nc::par::Kind::Reduce, label,
                                              [&](size_t b, size_t e) { body(b, e, b / blockSize); });
  return r == nc::par::Outcome::Done ? plan.blocks : 0;
}

// The value of rank r (0-based, in key order) among the non-NaN elements,
// and how many elements have exactly that key / a smaller key. False:
// Stop pressed.
bool selectRank(const BlockReader &rd, bool compute, uint64_t r, uint64_t &key, uint64_t &below,
                uint64_t &equal) {
  constexpr size_t kChunk = size_t(1) << 16;
  constexpr uint64_t kCollect = uint64_t(1) << 24; // candidates gathered for the last step
  uint64_t prefix = 0;
  int known = 0; // high key bits fixed so far
  below = 0;
  while (true) {
    const int shift = 64 - known - 16;
    // Histogram of the next 16 bits among the keys that share the prefix.
    std::vector<std::vector<uint64_t>> parts;
    const size_t threads = static_cast<size_t>(std::max(1, nc::par::threadCount()));
    parts.resize(threads * 4 + 8);
    const size_t blocks = coarseBlocks(rd.n, compute, "select", [&](size_t b, size_t e, size_t part) {
      std::vector<uint64_t> &h = parts[part];
      h.assign(65536, 0);
      std::vector<double> x(kChunk);
      for (size_t at = b; at < e; at += kChunk) {
        const size_t m = std::min(kChunk, e - at);
        rd.read(at, m, x.data());
        for (size_t i = 0; i < m; i++) {
          if (std::isnan(x[i]))
            continue;
          const uint64_t k = orderKey(x[i]);
          if (known == 0 || (k >> (64 - known)) == prefix)
            h[(k >> shift) & 0xFFFF]++;
        }
      }
    });
    if (blocks == 0)
      return false;
    std::vector<uint64_t> hist(65536, 0);
    for (const std::vector<uint64_t> &h : parts)
      if (!h.empty())
        for (size_t d = 0; d < 65536; d++)
          hist[d] += h[d];
    uint64_t digit = 0, before = 0;
    while (digit < 65536 && before + hist[digit] <= r) {
      before += hist[digit];
      digit++;
    }
    if (digit == 65536) { // fewer non-NaN values than r + 1 (NaN): the caller sees the NaNs
      key = 0;
      equal = 0;
      return true;
    }
    r -= before;
    below += before;
    prefix = (prefix << 16) | digit;
    known += 16;
    const uint64_t inBucket = hist[digit];
    if (known == 64) {
      key = prefix;
      equal = inBucket;
      return true;
    }
    if (inBucket > kCollect)
      continue;
    // Few enough: gather them and pick exactly.
    std::vector<std::vector<uint64_t>> got(parts.size());
    const size_t blocks2 = coarseBlocks(rd.n, compute, "select", [&](size_t b, size_t e, size_t part) {
      std::vector<uint64_t> &g = got[part];
      std::vector<double> x(kChunk);
      for (size_t at = b; at < e; at += kChunk) {
        const size_t m = std::min(kChunk, e - at);
        rd.read(at, m, x.data());
        for (size_t i = 0; i < m; i++) {
          if (std::isnan(x[i]))
            continue;
          const uint64_t k = orderKey(x[i]);
          if ((k >> (64 - known)) == prefix)
            g.push_back(k);
        }
      }
    });
    if (blocks2 == 0)
      return false;
    std::vector<uint64_t> all;
    all.reserve(static_cast<size_t>(inBucket));
    for (const std::vector<uint64_t> &g : got)
      all.insert(all.end(), g.begin(), g.end());
    std::sort(all.begin(), all.end());
    key = all[static_cast<size_t>(r)];
    const auto lo = std::lower_bound(all.begin(), all.end(), key);
    const auto hi = std::upper_bound(all.begin(), all.end(), key);
    below += static_cast<uint64_t>(lo - all.begin());
    equal = static_cast<uint64_t>(hi - lo);
    return true;
  }
}

// NaN count and the smallest key above `key` (UINT64_MAX: none).
bool nanCountAndNextAbove(const BlockReader &rd, bool compute, bool wantNext, uint64_t key, uint64_t &nans,
                          uint64_t &next) {
  constexpr size_t kChunk = size_t(1) << 16;
  const size_t threads = static_cast<size_t>(std::max(1, nc::par::threadCount()));
  std::vector<uint64_t> nanParts(threads * 4 + 8, 0), nextParts(threads * 4 + 8, UINT64_MAX);
  const size_t blocks = coarseBlocks(rd.n, compute, "select", [&](size_t b, size_t e, size_t part) {
    std::vector<double> x(kChunk);
    uint64_t cnt = 0, best = UINT64_MAX;
    for (size_t at = b; at < e; at += kChunk) {
      const size_t m = std::min(kChunk, e - at);
      rd.read(at, m, x.data());
      for (size_t i = 0; i < m; i++) {
        if (std::isnan(x[i])) {
          cnt++;
          continue;
        }
        if (wantNext) {
          const uint64_t k = orderKey(x[i]);
          if (k > key && k < best)
            best = k;
        }
      }
    }
    nanParts[part] = cnt;
    nextParts[part] = best;
  });
  if (blocks == 0)
    return false;
  nans = 0;
  next = UINT64_MAX;
  for (size_t i = 0; i < nanParts.size(); i++) {
    nans += nanParts[i];
    next = std::min(next, nextParts[i]);
  }
  return true;
}

// The values of ranks i and i+1 (i+1 only when wantNext and it exists)
// among the n elements read by `rd`. status: 0 ok, 1 a NaN is present,
// 2 Stop pressed.
int ranksOf(const BlockReader &rd, bool compute, uint64_t i, bool wantNext, double &vi, double &vj) {
  uint64_t key = 0, below = 0, equal = 0;
  if (!selectRank(rd, compute, i, key, below, equal))
    return 2;
  const bool nextInside = !wantNext || i + 1 < below + equal;
  uint64_t nans = 0, next = UINT64_MAX;
  if (!nanCountAndNextAbove(rd, compute, !nextInside, key, nans, next))
    return 2;
  if (nans > 0)
    return 1;
  vi = keyValue(key);
  vj = nextInside || next == UINT64_MAX ? vi : keyValue(next);
  return 0;
}

// Read in place (no copy) for this value? A rule always; stored data only
// when its copy would not fit in memory now.
bool inPlaceOrder(const Value &a, BlockReader &rd, bool &compute) {
  if (!(a.isArray || a.isMatrix) || !a.isPacked())
    return false;
  const size_t n = a.packedSize();
  rd.lazy = a.lazyTensor();
  rd.n = n;
  compute = rd.lazy && !rd.lazy->portableRule();
  if (rd.lazy)
    return n > 0;
  if (n == 0 || nc::mem::fits(static_cast<uint64_t>(n) * 8u))
    return false;
  rd.data = a.packedData();
  return true;
}

double medianOfRange(std::vector<double> &d, size_t lo, size_t hi) {
  const size_t n = hi - lo;
  auto first = d.begin() + static_cast<std::ptrdiff_t>(lo);
  auto mid = first + static_cast<std::ptrdiff_t>(n / 2);
  std::nth_element(first, mid, d.begin() + static_cast<std::ptrdiff_t>(hi));
  if (n % 2 == 1)
    return *mid;
  const double upper = *mid;
  const double lower = *std::max_element(first, mid); // largest of the lower half
  return (lower + upper) / 2;
}

} // namespace

// Scalar-argument guard for Percentile()/ZScore(): a Value defaults
// `number` to 0 when it's actually an array/matrix/text/dict, so passing
// one of those where a single number was expected silently read as 0
// instead of failing - e.g. percentile(arr, [10,20]) silently computed the
// 0th percentile.
static bool requireScalar(const Value &v, const char *fn, const char *argDesc) {
  if (v.isArray || v.isMatrix || v.isText || v.isDict) {
    std::cerr << "Error: " << fn << "'s " << argDesc
              << " must be a single number, not an array/matrix/text/dict\n";
    g_lastStatsOk = false;
    return false;
  }
  return true;
}

/* ================= BASIC ================= */

Value mean(Value a) {
  NumView view;
  if (!viewOf(a, "mean", view))
    return Value(0);
  if (view.n == 0)
    return statsError("mean of an empty matrix has no value");

  double s = 0;
  if (!sumOf(view, "mean", identity, s))
    return Value(0);

  return Value(s / view.n);
}

Value median(Value a) {
  {
    BlockReader rd;
    bool compute = false;
    if (inPlaceOrder(a, rd, compute)) {
      const uint64_t n = rd.n;
      double lo = 0, hi = 0;
      const int st = ranksOf(rd, compute, n % 2 == 1 ? n / 2 : n / 2 - 1, n % 2 == 0, lo, hi);
      if (st == 2) {
        g_lastStatsOk = false; // Stop pressed
        return Value(0);
      }
      if (st == 1)
        return Value(std::numeric_limits<double>::quiet_NaN());
      return Value(n % 2 == 1 ? lo : (lo + hi) / 2); // the old formula
    }
  }
  auto d = toVecChecked(a, "median");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("median of an empty matrix has no value");

  return Value(medianOfRange(d, 0, d.size()));
}

Value mode(Value a) {
  auto d = toVecChecked(a, "mode");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("mode of an empty matrix has no value");

  std::sort(d.begin(), d.end());

  // Determine the maximum frequency and then collect all values having it.
  int maxCount = 1;
  int count = 1;
  for (size_t i = 1; i < d.size(); i++) {
    if (d[i] == d[i - 1])
      count++;
    else
      count = 1;

    if (count > maxCount)
      maxCount = count;
  }

  if (maxCount <= 1)
    return Value("No mode");

  std::vector<Value> modes;
  for (size_t i = 0; i < d.size();) {
    size_t j = i;
    while (j < d.size() && d[j] == d[i])
      j++;

    int freq = (int)(j - i);
    if (freq == maxCount)
      modes.push_back(Value(d[i]));

    i = j;
  }

  if (modes.size() == 1)
    return modes[0];

  // Multiple modes: return all modes as an array.
  return Value(modes);
}

/* ================= MEANS ================= */

Value geo_mean(Value a) {
  auto d = toVecChecked(a, "geo_mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("geo_mean of an empty matrix has no value");

  double sumLog = 0;

  for (double x : d) {
    if (x <= 0)
      return statsError("geo_mean requires positive values");

    sumLog += std::log(x);
  }

  return Value(std::exp(sumLog / d.size()));
}

Value harmo_mean(Value a) {
  auto d = toVecChecked(a, "harmo_mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("harmo_mean of an empty matrix has no value");

  // Harmonic mean is only mathematically defined for positive reals - the
  // previous check (x==0 only) let mixed-sign input through, silently
  // producing a nonsensical negative "mean" (confirmed: harmo_mean([-2,4])
  // gave -8). geo_mean() above already enforces this same x>0 requirement;
  // this brings harmo_mean in line with it.
  double s = 0;
  for (double x : d) {
    if (x <= 0)
      return statsError("harmo_mean requires positive values");

    s += 1.0 / x;
  }

  return Value(d.size() / s);
}

Value trim_mean(Value a) {
  auto d = toVecChecked(a, "trim_mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("trim_mean of an empty matrix has no value");

  std::sort(d.begin(), d.end());

  // Standard 10% trimmed mean: drop floor(0.1*n) elements from EACH end,
  // so the amount trimmed scales with dataset size, matching every
  // textbook/library definition (scipy.stats.trim_mean, MATLAB's
  // trimmean(X, 10)). The previous implementation always removed exactly
  // one element per side regardless of n — only a coincidental ~10% trim
  // for n≈15-20, and effectively no trimming at all for larger arrays.
  size_t n = d.size();
  size_t k = static_cast<size_t>(0.1 * static_cast<double>(n));

  if (2 * k >= n) {
    // Degenerate case for very small n (trimming would remove everything
    // or more) — fall back to the ordinary mean instead of an empty range.
    double s = 0;
    for (double x : d)
      s += x;
    return Value(s / static_cast<double>(n));
  }

  double s = 0;
  size_t count = 0;
  for (size_t i = k; i < n - k; i++) {
    s += d[i];
    count++;
  }

  return Value(s / static_cast<double>(count));
}

/* ================= VARIANCE ================= */

// Σ(x−mean)^2 over the view, two passes (as before); false on Stop.
static bool squaredDeviations(const NumView &view, const char *label, double &out) {
  double total = 0;
  if (!sumOf(view, label, identity, total))
    return false;
  const double m = total / view.n;
  return sumOf(view, label, [m](double x) { return (x - m) * (x - m); }, out);
}

Value PVAR(Value a) {
  NumView view;
  if (!viewOf(a, "pvar", view))
    return Value(0);
  if (view.n == 0)
    return statsError("pvar of an empty matrix has no value");

  double s = 0;
  if (!squaredDeviations(view, "pvar", s))
    return Value(0);

  // Population variance: Σ(x−μ)^2 / n
  return Value(s / view.n);
}

Value var(Value a) {
  NumView view;
  if (!viewOf(a, "var", view))
    return Value(0);
  if (view.n < 2)
    return statsError("var (the sample variance) needs at least 2 values - pvar is the population variance");

  double s = 0;
  if (!squaredDeviations(view, "var", s))
    return Value(0);

  // Sample variance: Σ(x−x̄)^2 / (n−1)
  return Value(s / (view.n - 1));
}

Value PSD(Value a) { return Value(std::sqrt(PVAR(a).number)); }

Value sd(Value a) { return Value(std::sqrt(var(a).number)); }

Value coeff_var(Value a) {
  double m = mean(a).number;
  if (!g_lastStatsOk)
    return Value(0);
  if (m == 0)
    return Value(0);

  // Coefficient of variation (percentage): (SD / Mean) * 100
  return Value(sd(a).number / m * 100.0);
}

/* ================= SHAPE ================= */

Value skew(Value a) {
  auto d = toVecChecked(a, "skew");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("skew of an empty matrix has no value");

  double m = mean(a).number;
  // Population (biased) skewness g1 = mean(((x-mean)/sigma)^3), where sigma
  // is the POPULATION standard deviation (n divisor) — the standard
  // textbook/library default (e.g. NumPy/SciPy's bias=True). Using the
  // *sample* standard deviation (n-1 divisor, sd()) here as before produced
  // a hybrid that matches neither this population formula nor the properly
  // bias-corrected sample estimator (Fisher-Pearson G1).
  double s_dev = PSD(a).number;
  if (s_dev == 0)
    return Value(0);

  double s = 0;
  for (double x : d)
    s += pow((x - m) / s_dev, 3);

  return Value(s / d.size());
}

/* ================= COVARIANCE ================= */

Value co_var(Value a, Value b) {
  auto x = toVecChecked(a, "co_var");
  auto y = toVecChecked(b, "co_var");
  if (!g_lastStatsOk)
    return Value(0);

  if (x.size() != y.size()) {
    std::cerr << "Error: co_var requires two arrays of the same length (got "
              << x.size() << " and " << y.size() << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }
  if (x.size() < 2) {
    std::cerr << "Error: co_var requires at least 2 data points (got " << x.size()
              << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }

  double meanX = mean(a).number;
  double meanY = mean(b).number;

  double cov = 0;
  for (size_t i = 0; i < x.size(); i++)
    cov += (x[i] - meanX) * (y[i] - meanY);

  return Value(cov / (x.size() - 1));
}

/* ================= CORRELATION ================= */

Value corr_coeff(Value a, Value b) {
  auto x = toVecChecked(a, "corr_coeff");
  auto y = toVecChecked(b, "corr_coeff");
  if (!g_lastStatsOk)
    return Value(0);

  if (x.size() != y.size()) {
    std::cerr << "Error: corr_coeff requires two arrays of the same length (got "
              << x.size() << " and " << y.size() << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }
  if (x.empty()) {
    std::cerr << "Error: corr_coeff requires at least 1 data point\n";
    g_lastStatsOk = false;
    return Value(0);
  }

  int n = (int)x.size();

  double meanX = 0, meanY = 0;
  for (int i = 0; i < n; i++) {
    meanX += x[i];
    meanY += y[i];
  }
  meanX /= n;
  meanY /= n;

  double num = 0, dx = 0, dy = 0;
  for (int i = 0; i < n; i++) {
    num += (x[i] - meanX) * (y[i] - meanY);
    dx += pow(x[i] - meanX, 2);
    dy += pow(y[i] - meanY, 2);
  }

  if (dx == 0 || dy == 0)
    return Value("Undefined");

  return Value(num / sqrt(dx * dy));
}
/* ================= REGRESSION ================= */

// The fitted line as text. A negative slope reads "y = 3 - 2x", not "+ -2x".
static Value lineText(double intercept, double slope) {
  std::stringstream ss;
  ss << "y = " << intercept << (slope < 0 ? " - " : " + ") << std::fabs(slope) << "x";
  return Value(ss.str());
}

// Single-array form: regresses the values against their own 0-based index
// (i.e. treats the array as a single time series/sequence y_0..y_n-1 with
// implicit x = 0,1,2,...). Kept for backward compatibility with callers
// that only have one series — but industry-standard least-squares/linear
// regression (numpy.polyfit, scipy.stats.linregress, R's lm(y~x)) fits two
// independent variables; use the lsm(x, y) overload below for that.
Value lsm(Value a) {
  auto d = toVecChecked(a, "lsm");
  if (!g_lastStatsOk)
    return Value(0);

  int n = d.size();

  if (n < 2)
    return statsError("lsm requires at least 2 data points");

  double sx = 0;
  double sy = 0;
  double sxy = 0;
  double sx2 = 0;

  for (int i = 0; i < n; i++) {
    sx += i;
    sy += d[i];
    sxy += i * d[i];
    sx2 += i * i;
  }

  double denom = n * sx2 - sx * sx;
  if (denom == 0)
    return statsError("lsm is undefined when every x is the same");

  double slope = (n * sxy - sx * sy) / denom;

  double intercept = (sy - slope * sx) / n;

  return lineText(intercept, slope);
}

// Two-array form: standard ordinary-least-squares simple linear regression
// of y on x, y = intercept + slope*x — the actual "least squares method"
// as defined by every standard reference, fitting real paired (x, y) data
// rather than an implicit index.
Value lsm(Value x, Value y) {
  auto X = toVecChecked(x, "lsm");
  auto Y = toVecChecked(y, "lsm");
  if (!g_lastStatsOk)
    return Value(0);

  if (X.size() != Y.size())
    return statsError("lsm requires x and y of the same length");
  if (X.size() < 2)
    return statsError("lsm requires at least 2 data points");

  int n = (int)X.size();

  double sx = 0, sy = 0, sxy = 0, sx2 = 0;
  for (int i = 0; i < n; i++) {
    sx += X[i];
    sy += Y[i];
    sxy += X[i] * Y[i];
    sx2 += X[i] * X[i];
  }

  double denom = n * sx2 - sx * sx;
  if (denom == 0)
    return statsError("lsm is undefined when every x is the same");

  double slope = (n * sxy - sx * sy) / denom;
  double intercept = (sy - slope * sx) / n;

  return lineText(intercept, slope);
}

/* ================= HYPOTHESIS ================= */

// Regularized incomplete beta function I_x(a, b), by the continued fraction of
// Numerical Recipes (Lentz's method); only needed for the Student-t tail below.
static double incompleteBeta(double x, double a, double b) {
  if (x <= 0.0)
    return 0.0;
  if (x >= 1.0)
    return 1.0;
  // The fraction converges quickly only for x < (a+1)/(a+b+2).
  if (x > (a + 1.0) / (a + b + 2.0))
    return 1.0 - incompleteBeta(1.0 - x, b, a);

  const double tiny = 1e-300;
  const double front = std::exp(std::lgamma(a + b) - std::lgamma(a) - std::lgamma(b) +
                                a * std::log(x) + b * std::log(1.0 - x)) /
                       a;
  double f = 1.0, c = 1.0, d = 0.0;
  for (int i = 0; i <= 500; i++) {
    const int m = i / 2;
    double numerator;
    if (i == 0)
      numerator = 1.0;
    else if (i % 2 == 0)
      numerator = (m * (b - m) * x) / ((a + 2.0 * m - 1.0) * (a + 2.0 * m));
    else
      numerator = -((a + m) * (a + b + m) * x) / ((a + 2.0 * m) * (a + 2.0 * m + 1.0));
    d = 1.0 + numerator * d;
    d = std::fabs(d) < tiny ? 1.0 / tiny : 1.0 / d;
    c = 1.0 + numerator / c;
    c = std::fabs(c) < tiny ? tiny : c;
    f *= c * d;
    if (std::fabs(1.0 - c * d) < 1e-15)
      break;
  }
  return front * (f - 1.0);
}

// Two-tailed p-value of the one-sample t-test of H0: "the mean of the data is
// 0" (scipy.stats.ttest_1samp(data, 0)). False, with an error, for too few
// points. Constant data has no spread: certain unless its mean is exactly 0.
static bool oneSampleP(const Value &data, const char *fn, double &p) {
  auto d = toVecChecked(data, fn);
  if (!g_lastStatsOk)
    return false;
  if (d.size() < 2) {
    statsError(std::string(fn) + " requires at least 2 data points");
    return false;
  }
  const double n = static_cast<double>(d.size());
  double m = 0;
  for (double x : d)
    m += x;
  m /= n;
  double s2 = 0;
  for (double x : d)
    s2 += (x - m) * (x - m);
  s2 /= n - 1.0;
  if (s2 == 0) {
    p = m == 0 ? 1.0 : 0.0;
    return true;
  }
  const double t2 = m * m / (s2 / n); // t squared
  const double df = n - 1.0;
  p = incompleteBeta(df / (df + t2), df / 2.0, 0.5);
  return true;
}

// null_hypo(p): the decision at the 5% level for a p-value.
// null_hypo(data): runs the one-sample t-test on the data first, so
// null_hypo(A) means "does the mean of A differ from 0?".
Value null_hypo(Value p) {
  double pValue = p.number;
  if (p.isArray || p.isMatrix) {
    if (!oneSampleP(p, "null_hypo", pValue))
      return Value(0);
  } else if (p.isText || p.isDict) {
    return statsError("null_hypo expects a p-value or a vector of data");
  }

  if (pValue < 0.05)
    return Value("Reject H0");

  return Value("Fail to Reject H0");
}

// p_val_cal(z): one-tailed p-value of a z-score, the area beyond |z|.
// p_val_cal(data): two-tailed p-value of the one-sample t-test of the data.
Value p_val_cal(Value z) {
  if (z.isArray || z.isMatrix) {
    double p = 0;
    if (!oneSampleP(z, "p_val_cal", p))
      return Value(0);
    return Value(p);
  }
  if (z.isText || z.isDict)
    return statsError("p_val_cal expects a z-score or a vector of data");

  double p = 0.5 * erfc(fabs(z.number) / sqrt(2.0));

  return Value(p);
}

Value chi_test(Value observed, Value expected) {
  auto O = toVecChecked(observed, "chi_test");
  auto E = toVecChecked(expected, "chi_test");
  if (!g_lastStatsOk)
    return Value(0);

  if (O.size() != E.size())
    return statsError("chi_test requires observed and expected of the same length");
  if (O.empty())
    return statsError("chi_test requires at least 1 data point");

  double chi = 0;

  for (size_t i = 0; i < O.size(); i++) {
    if (E[i] == 0)
      return statsError("chi_test: an expected value cannot be zero");

    chi += pow(O[i] - E[i], 2) / E[i];
  }

  return Value(chi);
}

/* ================= RANGE ================= */

Value Range(Value a) {
  auto d = toVecChecked(a, "range");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.empty())
    return statsError("range of an empty matrix has no value");

  auto minmax = std::minmax_element(d.begin(), d.end());

  return Value(*minmax.second - *minmax.first);
}

/* ================= QUARTILES ================= */

Value Q1(Value a) {
  auto d = toVecChecked(a, "Q1");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.size() < 2)
    return Value(0);

  // Median-of-halves method (exclude median for odd-sized datasets)
  size_t n = d.size();
  size_t half = n / 2;

  // For odd n: lower half is first half elements (median excluded).
  // For even n: lower half is first half elements.
  // nth_element puts the `half` smallest values in d[0, half) - the same
  // set a full sort would, in linear time.
  std::nth_element(d.begin(), d.begin() + static_cast<std::ptrdiff_t>(half), d.end());
  return Value(medianOfRange(d, 0, half));
}

Value Q2(Value a) { return median(a); }

Value Q3(Value a) {
  auto d = toVecChecked(a, "Q3");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.size() < 2)
    return Value(0);

  // Median-of-halves method (exclude median for odd-sized datasets)
  size_t n = d.size();
  size_t half = n / 2;

  // For odd n: upper half excludes the median element, so it must start
  // one element PAST it (index half + 1, since the median sits at index
  // `half` when n is odd) — starting at `half` itself (as before) included
  // the median in the upper half while Q1's lower half correctly excluded
  // it, making Q1/Q3 asymmetric around the median for any odd-sized input
  // (verified: Q1/Q3 of 1..15 came out 4/11.5 — not equidistant from the
  // median 8 — instead of the correct symmetric 4/12).
  // For even n: upper half is still the last half elements (no single
  // median element to exclude).
  size_t upperStart = half + (n % 2);
  // The n - upperStart largest values into d[upperStart, n), as a sort
  // would put them, without sorting.
  std::nth_element(d.begin(), d.begin() + static_cast<std::ptrdiff_t>(upperStart), d.end());
  return Value(medianOfRange(d, upperStart, n));
}

/* ================= IQR ================= */

Value IQR(Value a) { return Value(Q3(a).number - Q1(a).number); }

/* ================= BASIC EXTRA ================= */

Value Sum(Value a) {
  NumView view;
  if (!viewOf(a, "sum", view))
    return Value(0);
  if (view.n == 0)
    return Value(0);

  double s = 0;
  if (!sumOf(view, "sum", identity, s))
    return Value(0);

  return Value(s);
}

Value Count(Value a) {
  // Packed real data: its length, without copying it (2026-11-23).
  if ((a.isArray || a.isMatrix) && a.isPacked())
    return Value(static_cast<double>(a.packedSize()));
  auto d = toVecChecked(a, "count");
  return Value((double)d.size());
}

Value Min(Value a) {
  auto d = toVecChecked(a, "min");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("min of an empty matrix has no value");

  return Value(*std::min_element(d.begin(), d.end()));
}

Value Max(Value a) {
  auto d = toVecChecked(a, "max");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return statsError("max of an empty matrix has no value");

  return Value(*std::max_element(d.begin(), d.end()));
}

/* ================= max(A) / min(A) over matrices and N-D (R3) ================= */

namespace {

bool isPlainReal(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
         !v.isFunctionRef && !v.isComplex;
}

// The larger / smaller of a run of elements, NaN winning (np.max / np.min).
// Returns the element itself, so its unit or integer type is kept.
Value extremeOfCells(const std::vector<Value> &cells, bool larger) {
  size_t best = 0;
  for (size_t k = 0; k < cells.size(); k++) {
    if (std::isnan(cells[k].number))
      return cells[k];
    if (larger ? cells[k].number > cells[best].number : cells[k].number < cells[best].number)
      best = k;
  }
  return cells[best];
}

} // namespace

Value ExtremeOf(const Value &a, bool larger, bool hasAxis, long long axis) {
  const char *fn = larger ? "max" : "min";
  if (a.isText || a.isDict || a.isObject || a.isFunctionRef || a.hasComplex()) {
    std::cerr << "Error: " << fn << " needs real numbers, a vector, a matrix or an N-D matrix\n";
    g_lastStatsOk = false;
    return Value(0);
  }
  // Packed real numbers, no axis (2026-11-23): the same answer as the cell
  // walk below - NaN wins (the first NaN in row-major order, payload kept),
  // otherwise the first element in row-major order that no later one beats
  // strictly (so max([-0, 0]) is still -0) - read in place, on several
  // cores, without one 32-byte Value per element (628 M elements took
  // 20 GB of cells; a lazy rule of 6.28 G is read from the rule).
  if (!hasAxis && (a.isArray || a.isMatrix) && a.isPacked() && !a.isND()) {
    int16_t l = 0, t = 0, m = 0;
    a.unitDims(l, t, m);
    const NumTensor *lazy = a.lazyTensor();
    const double *data = lazy ? nullptr : a.packedData();
    const size_t R = a.isMatrix ? a.rows() : 1, C = a.isMatrix ? a.cols() : a.length();
    const size_t n = R * C;
    if (l == 0 && t == 0 && m == 0 && n > 0) {
      // Row-major position i -> storage (column-major) index.
      const bool vector = R == 1 || C == 1;
      auto at = [&](size_t i) {
        const size_t k = vector ? i : (i % C) * R + i / C;
        return lazy ? lazy->lazyValue(k) : data[k];
      };
      struct Best {
        bool nan = false;
        size_t index = SIZE_MAX; // SIZE_MAX: nothing seen (empty block)
        double value = 0;
      };
      auto better = [larger](double x, double best) { return larger ? x > best : x < best; };
      Best result;
      const nc::par::Outcome r = nc::par::reduceBlocks(
          n, costFor(nc::par::reduce(1.0), lazy), fn, Best{},
          [&](size_t begin, size_t end) {
            Best b;
            for (size_t i = begin; i < end; i++) {
              const double x = at(i);
              if (std::isnan(x))
                return Best{true, i, x};
              if (b.index == SIZE_MAX || better(x, b.value)) {
                b.index = i;
                b.value = x;
              }
            }
            return b;
          },
          [&](Best acc, const Best &part) {
            // Blocks combine in order: an earlier NaN, else a later strictly better one.
            if (acc.nan || part.index == SIZE_MAX)
              return acc;
            if (part.nan || acc.index == SIZE_MAX || better(part.value, acc.value))
              return part;
            return acc;
          },
          result);
      if (r != nc::par::Outcome::Done) {
        g_lastStatsOk = false; // Stop pressed
        return Value(0);
      }
      return Value(result.value);
    }
  }

  const nd::Shape shape = nd::shapeOf(a);
  const std::vector<Value> cells = nd::rowMajorCells(a); // last index fastest
  for (const Value &c : cells)
    if (!isPlainReal(c)) {
      std::cerr << "Error: " << fn << " needs real numbers - this value holds text or "
                << "complex elements\n";
      g_lastStatsOk = false;
      return Value(0);
    }
  if (cells.empty()) {
    std::cerr << "Error: " << fn << " of an empty matrix has no value\n";
    g_lastStatsOk = false;
    return Value(0);
  }

  if (!hasAxis)
    return extremeOfCells(cells, larger);

  const long long rank = static_cast<long long>(shape.size());
  const long long ax = axis < 0 ? axis + rank : axis;
  if (ax < 0 || ax >= rank) {
    std::cerr << "Error: " << fn << ": axis " << axis << " is out of range for a "
              << nd::shapeText(shape) << " value (axes 0 to " << rank - 1 << ", or -1 to -"
              << rank << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }

  // Result shape: the input shape without `ax`. Walk it in row-major order
  // and reduce along `ax` for each position.
  nd::Shape outShape;
  for (long long i = 0; i < rank; i++)
    if (i != ax)
      outShape.push_back(shape[static_cast<size_t>(i)]);
  std::vector<size_t> stride(shape.size(), 1); // row-major strides into `cells`
  for (size_t i = shape.size() - 1; i-- > 0;)
    stride[i] = stride[i + 1] * shape[i + 1];

  std::vector<Value> out;
  std::vector<size_t> pos(outShape.size(), 0);
  const size_t outCount = nd::countOf(outShape);
  for (size_t done = 0; done < outCount; done++) {
    size_t base = 0;
    for (size_t i = 0, j = 0; i < shape.size(); i++)
      if (static_cast<long long>(i) != ax)
        base += pos[j++] * stride[i];
    std::vector<Value> line;
    line.reserve(shape[static_cast<size_t>(ax)]);
    for (size_t k = 0; k < shape[static_cast<size_t>(ax)]; k++)
      line.push_back(cells[base + k * stride[static_cast<size_t>(ax)]]);
    out.push_back(extremeOfCells(line, larger));
    if (!outShape.empty())
      nd::nextIndex(pos, outShape);
  }
  return nd::buildRowMajor(outShape, out);
}

Value Percentile(Value a, Value p) {
  {
    BlockReader rd;
    bool compute = false;
    if (inPlaceOrder(a, rd, compute)) {
      if (!requireScalar(p, "percentile", "percentile value (p)"))
        return Value(0);
      if (p.number < 0.0 || p.number > 100.0)
        return statsError("percentile: p must be between 0 and 100");
      const size_t n = rd.n;
      // The old formula, the ranks found in place (see above).
      double rank = (p.number / 100.0) * (n - 1);
      size_t i = (size_t)std::floor(rank);
      size_t j = (i + 1 < n) ? (i + 1) : i;
      double di = 0, dj = 0;
      const int st = ranksOf(rd, compute, i, j != i, di, dj);
      if (st == 2) {
        g_lastStatsOk = false;
        return Value(0);
      }
      if (st == 1)
        return Value(0); // a NaN: the old code's answer for a NaN result
      double frac = rank - (double)i;
      double v = di + (dj - di) * frac;
      if (std::isnan(v) || std::isinf(v))
        return Value(0);
      return Value(v);
    }
  }
  auto d = toVecChecked(a, "percentile");
  if (!g_lastStatsOk)
    return Value(0);
  if (!requireScalar(p, "percentile", "percentile value (p)"))
    return Value(0);
  if (d.empty())
    return statsError("percentile of an empty matrix has no value");

  // Validate percentile p in [0, 100].
  if (p.number < 0.0 || p.number > 100.0)
    return statsError("percentile: p must be between 0 and 100");

  size_t n = d.size();
  if (n == 1)
    return Value(d[0]);

  // Linear interpolation between neighboring points.
  // rank = (p/100) * (n-1)
  double rank = (p.number / 100.0) * (n - 1);
  size_t i = (size_t)std::floor(rank);
  size_t j = (i + 1 < n) ? (i + 1) : i;

  // The i-th and j-th smallest values, as a full sort would give them:
  // nth_element puts the i-th in place with everything larger after it,
  // and the (i+1)-th is then the smallest of what follows.
  std::nth_element(d.begin(), d.begin() + static_cast<std::ptrdiff_t>(i), d.end());
  const double di = d[i];
  const double dj = j == i ? di : *std::min_element(d.begin() + static_cast<std::ptrdiff_t>(i) + 1, d.end());

  double frac = rank - (double)i;
  double v = di + (dj - di) * frac;

  if (std::isnan(v) || std::isinf(v))
    return Value(0);

  return Value(v);
}

/* ================= Z SCORE ================= */

Value ZScore(Value value, Value mean, Value sd) {
  if (!requireScalar(value, "z_score", "value") ||
      !requireScalar(mean, "z_score", "mean") ||
      !requireScalar(sd, "z_score", "sd"))
    return Value(0);

  if (sd.number == 0)
    return Value(0);

  return Value((value.number - mean.number) / sd.number);
}

/* ================= STANDARD ERROR ================= */

Value Std_Error(Value a) {
  auto d = toVecChecked(a, "std_error");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.empty())
    return statsError("std_error of an empty matrix has no value");

  return Value(sd(a).number / sqrt((double)d.size()));
}

/* ================= KURTOSIS ================= */

Value Kurtosis(Value a) {
  auto d = toVecChecked(a, "kurtosis");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.empty())
    return statsError("kurtosis of an empty matrix has no value");

  double m = mean(a).number;
  // Population excess kurtosis = mean(((x-mean)/sigma)^4) - 3, with sigma
  // the POPULATION standard deviation (n divisor) — same reasoning as
  // skew() above: mixing the *sample* SD (n-1) into this population-moment
  // formula matched no standard convention.
  double s_dev = PSD(a).number;

  if (s_dev == 0)
    return Value(0);

  double sum = 0;

  for (double x : d)
    sum += pow((x - m) / s_dev, 4);

  return Value((sum / d.size()) - 3.0);
}

/* ================= NORMALIZATION ================= */
Value L2Norm(Value a) {
  NumView view;
  if (!viewOf(a, "l2norm", view))
    return Value(0);
  if (view.n == 0)
    return Value(0);

  double sum = 0;
  if (!sumOf(view, "l2norm", [](double x) { return x * x; }, sum))
    return Value(0);

  return Value(std::sqrt(sum));
}

/* ================= NORMALIZATION (min-max) ================= */
Value Lnorm(Value a) {
  auto d = toVecChecked(a, "lnorm");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  auto minmax = std::minmax_element(d.begin(), d.end());
  double mn = *minmax.first;
  double mx = *minmax.second;

  // A matrix is scaled as a whole and keeps its shape.
  if (a.isMatrix)
    return mapElementwise(a, [mn, mx](double x) { return mx == mn ? 0.0 : (x - mn) / (mx - mn); });

  if (mx == mn) {
    // All elements are equal => normalized values are all 0.
    std::vector<Value> res;
    res.reserve(d.size());
    for (size_t i = 0; i < d.size(); ++i)
      res.push_back(Value(0));
    return Value(res);
  }

  std::vector<Value> res;
  res.reserve(d.size());
  double denom = (mx - mn);
  for (double x : d) {
    double t = (x - mn) / denom;
    res.push_back(Value(t));
  }
  return Value(res);
}
