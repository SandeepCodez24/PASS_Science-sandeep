#include "statistics.h"
#include <algorithm>
#include <cmath>
#include <sstream>
#include <vector>

/* helper */

static std::vector<double> toVec(Value v) {
  std::vector<double> d;

  if (v.isArray) {
    for (auto &x : v.array)
      d.push_back(x.number);
  }

  return d;
}

/* ================= BASIC ================= */

Value mean(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double s = 0;
  for (double x : d)
    s += x;

  return Value(s / d.size());
}

Value median(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  std::sort(d.begin(), d.end());

  int n = (int)d.size();

  if (n % 2 == 0)
    return Value((d[n / 2 - 1] + d[n / 2]) / 2);

  return Value(d[n / 2]);
}

Value mode(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  std::sort(d.begin(), d.end());

  // Determine the maximum frequency and then collect all values having it.
  int maxCount = 1;
  int count = 1;
  for (size_t i = 1; i < d.size(); i++) {
    if (d[i] == d[i - 1])
      count++;
    else
      count = 1;

    if (count > maxCount)
      maxCount = count;
  }

  if (maxCount <= 1)
    return Value("No mode");

  std::vector<Value> modes;
  for (size_t i = 0; i < d.size();) {
    size_t j = i;
    while (j < d.size() && d[j] == d[i])
      j++;

    int freq = (int)(j - i);
    if (freq == maxCount)
      modes.push_back(Value(d[i]));

    i = j;
  }

  if (modes.size() == 1)
    return modes[0];

  // Multiple modes: return all modes as an array.
  return Value(modes);
}

/* ================= MEANS ================= */

Value geo_mean(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double sumLog = 0;

  for (double x : d) {
    if (x <= 0)
      return Value("Geo_Mean requires positive values");

    sumLog += std::log(x);
  }

  return Value(std::exp(sumLog / d.size()));
}

Value harmo_mean(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double s = 0;
  for (double x : d) {
    if (x == 0)
      return Value("Division by zero");

    s += 1.0 / x;
  }
  if (s == 0)
    return Value(0);

  return Value(d.size() / s);
}

Value trim_mean(Value a) {
  auto d = toVec(a);
  if (d.size() < 3)
    return Value(0);

  std::sort(d.begin(), d.end());

  d.erase(d.begin());
  d.pop_back();

  if (d.empty())
    return Value(0);

  double s = 0;
  for (double x : d)
    s += x;

  return Value(s / d.size());
}

/* ================= VARIANCE ================= */

Value PVAR(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double m = mean(a).number;

  double s = 0;
  for (double x : d)
    s += (x - m) * (x - m);

  // Population variance: Σ(x−μ)^2 / n
  return Value(s / d.size());
}

Value var(Value a) {
  auto d = toVec(a);
  if (d.size() < 2)
    return Value(0);

  double m = mean(a).number;

  double s = 0;
  for (double x : d)
    s += (x - m) * (x - m);

  // Sample variance: Σ(x−x̄)^2 / (n−1)
  return Value(s / (d.size() - 1));
}

Value PSD(Value a) { return Value(std::sqrt(PVAR(a).number)); }

Value sd(Value a) { return Value(std::sqrt(var(a).number)); }

Value coeff_var(Value a) {
  double m = mean(a).number;
  if (m == 0)
    return Value(0);

  // Coefficient of variation (percentage): (SD / Mean) * 100
  return Value(sd(a).number / m * 100.0);
}

/* ================= SHAPE ================= */

Value skew(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double m = mean(a).number;
  double s_dev = sd(a).number;
  if (s_dev == 0)
    return Value(0);

  double s = 0;
  for (double x : d)
    s += pow((x - m) / s_dev, 3);

  return Value(s / d.size());
}

/* ================= COVARIANCE ================= */

Value co_var(Value a, Value b) {
  auto x = toVec(a);
  auto y = toVec(b);

  if (x.size() != y.size() || x.size() < 2)
    return Value(0);

  double meanX = mean(a).number;
  double meanY = mean(b).number;

  double cov = 0;
  for (size_t i = 0; i < x.size(); i++)
    cov += (x[i] - meanX) * (y[i] - meanY);

  return Value(cov / (x.size() - 1));
}

/* ================= CORRELATION ================= */

Value corr_coeff(Value a, Value b) {
  auto x = toVec(a);
  auto y = toVec(b);

  if (x.empty() || x.size() != y.size())
    return Value(0);

  int n = (int)x.size();

  double meanX = 0, meanY = 0;
  for (int i = 0; i < n; i++) {
    meanX += x[i];
    meanY += y[i];
  }
  meanX /= n;
  meanY /= n;

  double num = 0, dx = 0, dy = 0;
  for (int i = 0; i < n; i++) {
    num += (x[i] - meanX) * (y[i] - meanY);
    dx += pow(x[i] - meanX, 2);
    dy += pow(y[i] - meanY, 2);
  }

  if (dx == 0 || dy == 0)
    return Value("Undefined");

  return Value(num / sqrt(dx * dy));
}
/* ================= REGRESSION ================= */

Value lsm(Value a) {
  auto d = toVec(a);

  int n = d.size();

  if (n < 2)
    return Value("Invalid");

  double sx = 0;
  double sy = 0;
  double sxy = 0;
  double sx2 = 0;

  for (int i = 0; i < n; i++) {
    sx += i;
    sy += d[i];
    sxy += i * d[i];
    sx2 += i * i;
  }

  double denom = n * sx2 - sx * sx;
  if (denom == 0)
    return Value("Undefined");

  double slope = (n * sxy - sx * sy) / denom;

  double intercept = (sy - slope * sx) / n;

  std::stringstream ss;
  ss << "y = " << intercept << " + " << slope << "x";

  return Value(ss.str());
}

/* ================= HYPOTHESIS ================= */

Value null_hypo(Value p) {
  if (p.number < 0.05)
    return Value("Reject H0");

  return Value("Fail to Reject H0");
}

Value p_val_cal(Value z) {
  double p = 0.5 * erfc(fabs(z.number) / sqrt(2.0));

  return Value(p);
}

Value chi_test(Value observed, Value expected) {
  auto O = toVec(observed);
  auto E = toVec(expected);

  if (O.size() != E.size() || O.empty())
    return Value("Invalid");

  double chi = 0;

  for (size_t i = 0; i < O.size(); i++) {
    if (E[i] == 0)
      return Value("Expected value cannot be zero");

    chi += pow(O[i] - E[i], 2) / E[i];
  }

  return Value(chi);
}

/* ================= RANGE ================= */

Value Range(Value a) {
  auto d = toVec(a);

  if (d.empty())
    return Value(0);

  auto minmax = std::minmax_element(d.begin(), d.end());

  return Value(*minmax.second - *minmax.first);
}

/* ================= QUARTILES ================= */

Value Q1(Value a) {
  auto d = toVec(a);

  if (d.size() < 2)
    return Value(0);

  std::sort(d.begin(), d.end());

  // Median-of-halves method (exclude median for odd-sized datasets)
  size_t n = d.size();
  size_t half = n / 2;

  // For odd n: lower half is first half elements (median excluded).
  // For even n: lower half is first half elements.
  std::vector<double> lower(d.begin(), d.begin() + half);

  Value temp;
  temp.isArray = true;

  for (double x : lower)
    temp.array.push_back(Value(x));

  return median(temp);
}

Value Q2(Value a) { return median(a); }

Value Q3(Value a) {
  auto d = toVec(a);

  if (d.size() < 2)
    return Value(0);

  std::sort(d.begin(), d.end());

  // Median-of-halves method (exclude median for odd-sized datasets)
  size_t n = d.size();
  size_t half = n / 2;

  // For odd n: upper half excludes the median element.
  // For even n: upper half is the last half elements.
  std::vector<double> upper(d.begin() + half, d.end());

  Value temp;
  temp.isArray = true;

  for (double x : upper)
    temp.array.push_back(Value(x));

  return median(temp);
}

/* ================= IQR ================= */

Value IQR(Value a) { return Value(Q3(a).number - Q1(a).number); }

/* ================= BASIC EXTRA ================= */

Value Sum(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double s = 0;
  for (double x : d)
    s += x;

  return Value(s);
}

Value Count(Value a) {
  auto d = toVec(a);
  return Value((double)d.size());
}

Value Min(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  return Value(*std::min_element(d.begin(), d.end()));
}

Value Max(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  return Value(*std::max_element(d.begin(), d.end()));
}

Value Percentile(Value a, Value p) {
  auto d = toVec(a);
  if (d.empty())
    return Value("Empty array");

  // Validate percentile p in [0, 100].
  if (p.number < 0.0 || p.number > 100.0)
    return Value("Invalid percentile");

  std::sort(d.begin(), d.end());

  size_t n = d.size();
  if (n == 1)
    return Value(d[0]);

  // Linear interpolation between neighboring points.
  // rank = (p/100) * (n-1)
  double rank = (p.number / 100.0) * (n - 1);
  size_t i = (size_t)std::floor(rank);
  size_t j = (i + 1 < n) ? (i + 1) : i;

  double frac = rank - (double)i;
  double v = d[i] + (d[j] - d[i]) * frac;

  if (std::isnan(v) || std::isinf(v))
    return Value(0);

  return Value(v);
}

/* ================= Z SCORE ================= */

Value ZScore(Value value, Value mean, Value sd) {
  if (sd.number == 0)
    return Value(0);

  return Value((value.number - mean.number) / sd.number);
}

/* ================= STANDARD ERROR ================= */

Value Std_Error(Value a) {
  auto d = toVec(a);

  if (d.empty())
    return Value(0);

  return Value(sd(a).number / sqrt((double)d.size()));
}

/* ================= KURTOSIS ================= */

Value Kurtosis(Value a) {
  auto d = toVec(a);

  if (d.empty())
    return Value(0);

  double m = mean(a).number;
  double s_dev = sd(a).number;

  if (s_dev == 0)
    return Value(0);

  double sum = 0;

  for (double x : d)
    sum += pow((x - m) / s_dev, 4);

  return Value((sum / d.size()) - 3.0);
}

/* ================= NORMALIZATION ================= */
Value L2Norm(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  double sum = 0;
  for (double x : d)
    sum += x * x;

  return Value(std::sqrt(sum));
}

/* ================= NORMALIZATION (min-max) ================= */
Value Lnorm(Value a) {
  auto d = toVec(a);
  if (d.empty())
    return Value(0);

  auto minmax = std::minmax_element(d.begin(), d.end());
  double mn = *minmax.first;
  double mx = *minmax.second;

  if (mx == mn) {
    // All elements are equal => normalized values are all 0.
    std::vector<Value> res;
    res.reserve(d.size());
    for (size_t i = 0; i < d.size(); ++i)
      res.push_back(Value(0));
    return Value(res);
  }

  std::vector<Value> res;
  res.reserve(d.size());
  double denom = (mx - mn);
  for (double x : d) {
    double t = (x - mn) / denom;
    res.push_back(Value(t));
  }
  return Value(res);
}
