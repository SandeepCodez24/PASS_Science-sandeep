#include "statistics.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <sstream>
#include <utility>
#include <vector>

bool g_lastStatsOk = true;

/* helper */

static std::vector<double> toVec(Value v) {
  std::vector<double> d;

  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      d.push_back(v.numAt(i));
  }

  return d;
}

// toVec() above silently treats ANY non-array Value as an empty vector -
// every public function historically built its own "empty -> return 0"
// fallback ON TOP of that, so a genuinely-invalid non-array argument
// (mean(5), sum("x"), ...) silently produced the SAME output as a
// genuinely-empty array, with no way to tell them apart. This wrapper
// makes that distinction visible: it flags g_lastStatsOk=false and prints
// a clear error for a non-array input, then defers to toVec() for the
// actual (possibly still legitimately-empty) conversion.
static std::vector<double> toVecChecked(const Value &v, const char *fn) {
  if (!v.isArray) {
    std::cerr << "Error: " << fn << " expects an array, got a "
              << (v.isMatrix ? "matrix" : v.isText ? "string" : v.isDict ? "dict" : "number")
              << "\n";
    g_lastStatsOk = false;
    return {};
  }
  return toVec(v);
}

// Scalar-argument guard for Percentile()/ZScore(): a Value defaults
// `number` to 0 when it's actually an array/matrix/text/dict, so passing
// one of those where a single number was expected silently read as 0
// instead of failing - e.g. percentile(arr, [10,20]) silently computed the
// 0th percentile.
static bool requireScalar(const Value &v, const char *fn, const char *argDesc) {
  if (v.isArray || v.isMatrix || v.isText || v.isDict) {
    std::cerr << "Error: " << fn << "'s " << argDesc
              << " must be a single number, not an array/matrix/text/dict\n";
    g_lastStatsOk = false;
    return false;
  }
  return true;
}

/* ================= BASIC ================= */

Value mean(Value a) {
  auto d = toVecChecked(a, "mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  double s = 0;
  for (double x : d)
    s += x;

  return Value(s / d.size());
}

Value median(Value a) {
  auto d = toVecChecked(a, "median");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  std::sort(d.begin(), d.end());

  int n = (int)d.size();

  if (n % 2 == 0)
    return Value((d[n / 2 - 1] + d[n / 2]) / 2);

  return Value(d[n / 2]);
}

Value mode(Value a) {
  auto d = toVecChecked(a, "mode");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  std::sort(d.begin(), d.end());

  // Determine the maximum frequency and then collect all values having it.
  int maxCount = 1;
  int count = 1;
  for (size_t i = 1; i < d.size(); i++) {
    if (d[i] == d[i - 1])
      count++;
    else
      count = 1;

    if (count > maxCount)
      maxCount = count;
  }

  if (maxCount <= 1)
    return Value("No mode");

  std::vector<Value> modes;
  for (size_t i = 0; i < d.size();) {
    size_t j = i;
    while (j < d.size() && d[j] == d[i])
      j++;

    int freq = (int)(j - i);
    if (freq == maxCount)
      modes.push_back(Value(d[i]));

    i = j;
  }

  if (modes.size() == 1)
    return modes[0];

  // Multiple modes: return all modes as an array.
  return Value(modes);
}

/* ================= MEANS ================= */

Value geo_mean(Value a) {
  auto d = toVecChecked(a, "geo_mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  double sumLog = 0;

  for (double x : d) {
    if (x <= 0)
      return Value("Geo_Mean requires positive values");

    sumLog += std::log(x);
  }

  return Value(std::exp(sumLog / d.size()));
}

Value harmo_mean(Value a) {
  auto d = toVecChecked(a, "harmo_mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  // Harmonic mean is only mathematically defined for positive reals - the
  // previous check (x==0 only) let mixed-sign input through, silently
  // producing a nonsensical negative "mean" (confirmed: harmo_mean([-2,4])
  // gave -8). geo_mean() above already enforces this same x>0 requirement;
  // this brings harmo_mean in line with it.
  double s = 0;
  for (double x : d) {
    if (x <= 0)
      return Value("Harmo_Mean requires positive values");

    s += 1.0 / x;
  }

  return Value(d.size() / s);
}

Value trim_mean(Value a) {
  auto d = toVecChecked(a, "trim_mean");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.size() < 3)
    return Value(0);

  std::sort(d.begin(), d.end());

  // Standard 10% trimmed mean: drop floor(0.1*n) elements from EACH end,
  // so the amount trimmed scales with dataset size, matching every
  // textbook/library definition (scipy.stats.trim_mean, MATLAB's
  // trimmean(X, 10)). The previous implementation always removed exactly
  // one element per side regardless of n — only a coincidental ~10% trim
  // for n≈15-20, and effectively no trimming at all for larger arrays.
  size_t n = d.size();
  size_t k = static_cast<size_t>(0.1 * static_cast<double>(n));

  if (2 * k >= n) {
    // Degenerate case for very small n (trimming would remove everything
    // or more) — fall back to the ordinary mean instead of an empty range.
    double s = 0;
    for (double x : d)
      s += x;
    return Value(s / static_cast<double>(n));
  }

  double s = 0;
  size_t count = 0;
  for (size_t i = k; i < n - k; i++) {
    s += d[i];
    count++;
  }

  return Value(s / static_cast<double>(count));
}

/* ================= VARIANCE ================= */

Value PVAR(Value a) {
  auto d = toVecChecked(a, "pvar");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  double m = mean(a).number;

  double s = 0;
  for (double x : d)
    s += (x - m) * (x - m);

  // Population variance: Σ(x−μ)^2 / n
  return Value(s / d.size());
}

Value var(Value a) {
  auto d = toVecChecked(a, "var");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.size() < 2)
    return Value(0);

  double m = mean(a).number;

  double s = 0;
  for (double x : d)
    s += (x - m) * (x - m);

  // Sample variance: Σ(x−x̄)^2 / (n−1)
  return Value(s / (d.size() - 1));
}

Value PSD(Value a) { return Value(std::sqrt(PVAR(a).number)); }

Value sd(Value a) { return Value(std::sqrt(var(a).number)); }

Value coeff_var(Value a) {
  double m = mean(a).number;
  if (!g_lastStatsOk)
    return Value(0);
  if (m == 0)
    return Value(0);

  // Coefficient of variation (percentage): (SD / Mean) * 100
  return Value(sd(a).number / m * 100.0);
}

/* ================= SHAPE ================= */

Value skew(Value a) {
  auto d = toVecChecked(a, "skew");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  double m = mean(a).number;
  // Population (biased) skewness g1 = mean(((x-mean)/sigma)^3), where sigma
  // is the POPULATION standard deviation (n divisor) — the standard
  // textbook/library default (e.g. NumPy/SciPy's bias=True). Using the
  // *sample* standard deviation (n-1 divisor, sd()) here as before produced
  // a hybrid that matches neither this population formula nor the properly
  // bias-corrected sample estimator (Fisher-Pearson G1).
  double s_dev = PSD(a).number;
  if (s_dev == 0)
    return Value(0);

  double s = 0;
  for (double x : d)
    s += pow((x - m) / s_dev, 3);

  return Value(s / d.size());
}

/* ================= COVARIANCE ================= */

Value co_var(Value a, Value b) {
  auto x = toVecChecked(a, "co_var");
  auto y = toVecChecked(b, "co_var");
  if (!g_lastStatsOk)
    return Value(0);

  if (x.size() != y.size()) {
    std::cerr << "Error: co_var requires two arrays of the same length (got "
              << x.size() << " and " << y.size() << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }
  if (x.size() < 2) {
    std::cerr << "Error: co_var requires at least 2 data points (got " << x.size()
              << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }

  double meanX = mean(a).number;
  double meanY = mean(b).number;

  double cov = 0;
  for (size_t i = 0; i < x.size(); i++)
    cov += (x[i] - meanX) * (y[i] - meanY);

  return Value(cov / (x.size() - 1));
}

/* ================= CORRELATION ================= */

Value corr_coeff(Value a, Value b) {
  auto x = toVecChecked(a, "corr_coeff");
  auto y = toVecChecked(b, "corr_coeff");
  if (!g_lastStatsOk)
    return Value(0);

  if (x.size() != y.size()) {
    std::cerr << "Error: corr_coeff requires two arrays of the same length (got "
              << x.size() << " and " << y.size() << ")\n";
    g_lastStatsOk = false;
    return Value(0);
  }
  if (x.empty()) {
    std::cerr << "Error: corr_coeff requires at least 1 data point\n";
    g_lastStatsOk = false;
    return Value(0);
  }

  int n = (int)x.size();

  double meanX = 0, meanY = 0;
  for (int i = 0; i < n; i++) {
    meanX += x[i];
    meanY += y[i];
  }
  meanX /= n;
  meanY /= n;

  double num = 0, dx = 0, dy = 0;
  for (int i = 0; i < n; i++) {
    num += (x[i] - meanX) * (y[i] - meanY);
    dx += pow(x[i] - meanX, 2);
    dy += pow(y[i] - meanY, 2);
  }

  if (dx == 0 || dy == 0)
    return Value("Undefined");

  return Value(num / sqrt(dx * dy));
}
/* ================= REGRESSION ================= */

// Single-array form: regresses the values against their own 0-based index
// (i.e. treats the array as a single time series/sequence y_0..y_n-1 with
// implicit x = 0,1,2,...). Kept for backward compatibility with callers
// that only have one series — but industry-standard least-squares/linear
// regression (numpy.polyfit, scipy.stats.linregress, R's lm(y~x)) fits two
// independent variables; use the lsm(x, y) overload below for that.
Value lsm(Value a) {
  auto d = toVecChecked(a, "lsm");
  if (!g_lastStatsOk)
    return Value("Invalid");

  int n = d.size();

  if (n < 2)
    return Value("Invalid");

  double sx = 0;
  double sy = 0;
  double sxy = 0;
  double sx2 = 0;

  for (int i = 0; i < n; i++) {
    sx += i;
    sy += d[i];
    sxy += i * d[i];
    sx2 += i * i;
  }

  double denom = n * sx2 - sx * sx;
  if (denom == 0)
    return Value("Undefined");

  double slope = (n * sxy - sx * sy) / denom;

  double intercept = (sy - slope * sx) / n;

  std::stringstream ss;
  ss << "y = " << intercept << " + " << slope << "x";

  return Value(ss.str());
}

// Two-array form: standard ordinary-least-squares simple linear regression
// of y on x, y = intercept + slope*x — the actual "least squares method"
// as defined by every standard reference, fitting real paired (x, y) data
// rather than an implicit index.
Value lsm(Value x, Value y) {
  auto X = toVecChecked(x, "lsm");
  auto Y = toVecChecked(y, "lsm");
  if (!g_lastStatsOk)
    return Value("Invalid");

  if (X.size() != Y.size() || X.size() < 2)
    return Value("Invalid");

  int n = (int)X.size();

  double sx = 0, sy = 0, sxy = 0, sx2 = 0;
  for (int i = 0; i < n; i++) {
    sx += X[i];
    sy += Y[i];
    sxy += X[i] * Y[i];
    sx2 += X[i] * X[i];
  }

  double denom = n * sx2 - sx * sx;
  if (denom == 0)
    return Value("Undefined");

  double slope = (n * sxy - sx * sy) / denom;
  double intercept = (sy - slope * sx) / n;

  std::stringstream ss;
  ss << "y = " << intercept << " + " << slope << "x";

  return Value(ss.str());
}

/* ================= HYPOTHESIS ================= */

Value null_hypo(Value p) {
  // p must be a single p-value (scalar). A Value defaults `number` to 0
  // when it's actually an array/matrix/text/dict, so passing one of those
  // silently read as p=0 < 0.05 and always answered "Reject H0" regardless
  // of the real data — fail loudly instead.
  if (p.isArray || p.isMatrix || p.isText || p.isDict)
    return Value("null_hypo expects a single p-value (scalar) — pass the "
                 "result of p_val_cal(...) or chi_test(...), not a raw array");

  if (p.number < 0.05)
    return Value("Reject H0");

  return Value("Fail to Reject H0");
}

Value p_val_cal(Value z) {
  // z must be a single z-score (scalar) — same array-silently-reads-as-0
  // hazard as null_hypo() above.
  if (z.isArray || z.isMatrix || z.isText || z.isDict)
    return Value("p_val_cal expects a single z-score (scalar), not an "
                 "array/matrix/text/dict");

  double p = 0.5 * erfc(fabs(z.number) / sqrt(2.0));

  return Value(p);
}

Value chi_test(Value observed, Value expected) {
  auto O = toVecChecked(observed, "chi_test");
  auto E = toVecChecked(expected, "chi_test");
  if (!g_lastStatsOk)
    return Value("Invalid");

  if (O.size() != E.size() || O.empty())
    return Value("Invalid");

  double chi = 0;

  for (size_t i = 0; i < O.size(); i++) {
    if (E[i] == 0)
      return Value("Expected value cannot be zero");

    chi += pow(O[i] - E[i], 2) / E[i];
  }

  return Value(chi);
}

/* ================= RANGE ================= */

Value Range(Value a) {
  auto d = toVecChecked(a, "range");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.empty())
    return Value(0);

  auto minmax = std::minmax_element(d.begin(), d.end());

  return Value(*minmax.second - *minmax.first);
}

/* ================= QUARTILES ================= */

Value Q1(Value a) {
  auto d = toVecChecked(a, "Q1");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.size() < 2)
    return Value(0);

  std::sort(d.begin(), d.end());

  // Median-of-halves method (exclude median for odd-sized datasets)
  size_t n = d.size();
  size_t half = n / 2;

  // For odd n: lower half is first half elements (median excluded).
  // For even n: lower half is first half elements.
  std::vector<double> lower(d.begin(), d.begin() + half);

  std::vector<Value> halfVals;
  for (double x : lower)
    halfVals.push_back(Value(x));

  return median(Value(std::move(halfVals)));
}

Value Q2(Value a) { return median(a); }

Value Q3(Value a) {
  auto d = toVecChecked(a, "Q3");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.size() < 2)
    return Value(0);

  std::sort(d.begin(), d.end());

  // Median-of-halves method (exclude median for odd-sized datasets)
  size_t n = d.size();
  size_t half = n / 2;

  // For odd n: upper half excludes the median element, so it must start
  // one element PAST it (index half + 1, since the median sits at index
  // `half` when n is odd) — starting at `half` itself (as before) included
  // the median in the upper half while Q1's lower half correctly excluded
  // it, making Q1/Q3 asymmetric around the median for any odd-sized input
  // (verified: Q1/Q3 of 1..15 came out 4/11.5 — not equidistant from the
  // median 8 — instead of the correct symmetric 4/12).
  // For even n: upper half is still the last half elements (no single
  // median element to exclude).
  size_t upperStart = half + (n % 2);
  std::vector<double> upper(d.begin() + upperStart, d.end());

  std::vector<Value> halfVals;
  for (double x : upper)
    halfVals.push_back(Value(x));

  return median(Value(std::move(halfVals)));
}

/* ================= IQR ================= */

Value IQR(Value a) { return Value(Q3(a).number - Q1(a).number); }

/* ================= BASIC EXTRA ================= */

Value Sum(Value a) {
  auto d = toVecChecked(a, "sum");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  double s = 0;
  for (double x : d)
    s += x;

  return Value(s);
}

Value Count(Value a) {
  auto d = toVecChecked(a, "count");
  return Value((double)d.size());
}

Value Min(Value a) {
  auto d = toVecChecked(a, "min");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  return Value(*std::min_element(d.begin(), d.end()));
}

Value Max(Value a) {
  auto d = toVecChecked(a, "max");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  return Value(*std::max_element(d.begin(), d.end()));
}

Value Percentile(Value a, Value p) {
  auto d = toVecChecked(a, "percentile");
  if (!g_lastStatsOk)
    return Value(0);
  if (!requireScalar(p, "percentile", "percentile value (p)"))
    return Value(0);
  if (d.empty())
    return Value("Empty array");

  // Validate percentile p in [0, 100].
  if (p.number < 0.0 || p.number > 100.0)
    return Value("Invalid percentile");

  std::sort(d.begin(), d.end());

  size_t n = d.size();
  if (n == 1)
    return Value(d[0]);

  // Linear interpolation between neighboring points.
  // rank = (p/100) * (n-1)
  double rank = (p.number / 100.0) * (n - 1);
  size_t i = (size_t)std::floor(rank);
  size_t j = (i + 1 < n) ? (i + 1) : i;

  double frac = rank - (double)i;
  double v = d[i] + (d[j] - d[i]) * frac;

  if (std::isnan(v) || std::isinf(v))
    return Value(0);

  return Value(v);
}

/* ================= Z SCORE ================= */

Value ZScore(Value value, Value mean, Value sd) {
  if (!requireScalar(value, "z_score", "value") ||
      !requireScalar(mean, "z_score", "mean") ||
      !requireScalar(sd, "z_score", "sd"))
    return Value(0);

  if (sd.number == 0)
    return Value(0);

  return Value((value.number - mean.number) / sd.number);
}

/* ================= STANDARD ERROR ================= */

Value Std_Error(Value a) {
  auto d = toVecChecked(a, "std_error");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.empty())
    return Value(0);

  return Value(sd(a).number / sqrt((double)d.size()));
}

/* ================= KURTOSIS ================= */

Value Kurtosis(Value a) {
  auto d = toVecChecked(a, "kurtosis");
  if (!g_lastStatsOk)
    return Value(0);

  if (d.empty())
    return Value(0);

  double m = mean(a).number;
  // Population excess kurtosis = mean(((x-mean)/sigma)^4) - 3, with sigma
  // the POPULATION standard deviation (n divisor) — same reasoning as
  // skew() above: mixing the *sample* SD (n-1) into this population-moment
  // formula matched no standard convention.
  double s_dev = PSD(a).number;

  if (s_dev == 0)
    return Value(0);

  double sum = 0;

  for (double x : d)
    sum += pow((x - m) / s_dev, 4);

  return Value((sum / d.size()) - 3.0);
}

/* ================= NORMALIZATION ================= */
Value L2Norm(Value a) {
  auto d = toVecChecked(a, "l2norm");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  double sum = 0;
  for (double x : d)
    sum += x * x;

  return Value(std::sqrt(sum));
}

/* ================= NORMALIZATION (min-max) ================= */
Value Lnorm(Value a) {
  auto d = toVecChecked(a, "lnorm");
  if (!g_lastStatsOk)
    return Value(0);
  if (d.empty())
    return Value(0);

  auto minmax = std::minmax_element(d.begin(), d.end());
  double mn = *minmax.first;
  double mx = *minmax.second;

  if (mx == mn) {
    // All elements are equal => normalized values are all 0.
    std::vector<Value> res;
    res.reserve(d.size());
    for (size_t i = 0; i < d.size(); ++i)
      res.push_back(Value(0));
    return Value(res);
  }

  std::vector<Value> res;
  res.reserve(d.size());
  double denom = (mx - mn);
  for (double x : d) {
    double t = (x - mn) / denom;
    res.push_back(Value(t));
  }
  return Value(res);
}
