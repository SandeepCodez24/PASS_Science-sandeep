#pragma once
#include "../../core/value.h"

/* ================= BASIC STATS ================= */

Value mean(Value a);
Value median(Value a);
Value mode(Value a);

Value geo_mean(Value a);
Value harmo_mean(Value a);
Value trim_mean(Value a);

/* ================= VARIANCE ================= */

Value PVAR(Value a);
Value var(Value a);

// Population standard deviation and sample standard deviation
Value PSD(Value a);
Value sd(Value a);

Value coeff_var(Value a);
Value skew(Value a);

/* ================= ADVANCED ================= */

Value corr_coeff(Value a, Value b);
Value co_var(Value a, Value b);
Value lsm(Value a);

Value null_hypo(Value a);
Value p_val_cal(Value a);
Value chi_test(Value observed, Value expected);
Value L2Norm(Value a);
Value Lnorm(Value a);
/* ================= EXTRA STATISTICS ================= */

Value Range(Value a);

Value Q1(Value a);
Value Q2(Value a);
Value Q3(Value a);

Value IQR(Value a);

Value ZScore(Value value, Value mean, Value sd);

Value Std_Error(Value a);

Value Kurtosis(Value a);

// Additional basic statistics
Value Sum(Value a);
Value Count(Value a);
Value Min(Value a);
Value Max(Value a);
Value Percentile(Value a, Value p);
