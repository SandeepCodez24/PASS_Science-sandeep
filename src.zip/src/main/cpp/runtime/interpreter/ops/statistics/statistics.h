#pragma once
#include "../../core/value.h"

// Same "global out-of-band status flag" convention as vector.h's
// g_lastVectorOk / elementwise.h's g_lastElementwiseOk: g_lastBuiltinFound
// only means "the NAME was found in a dispatch table", not "the actual
// computation succeeded with valid inputs" - these are plain free
// functions with no Parser access to set evaluationSucceeded_ directly.
// Set true at the start of every public statistics.cpp function that
// validates its own input (toVec()'s caller, Percentile(), ZScore(), ...);
// false when an input is rejected (non-array where an array was required,
// non-scalar where a scalar was required, mismatched lengths, too few
// points). Checked in parser_factor.cpp's ExprKind::Call case and
// nc_bridge_call_dynamic (value_bridge.cpp) right alongside
// g_lastBuiltinFound/g_lastVectorOk. Before this flag existed, toVec()
// silently treated ANY non-array Value as an empty vector (mean(5) / sum(5)
// silently returned 0), and Percentile()/ZScore() silently read a
// non-scalar argument's default .number=0 instead of rejecting it
// (percentile(arr, [10,20]) silently computed the 0th percentile) -
// confirmed by direct testing.
extern bool g_lastStatsOk;

/* ================= BASIC STATS ================= */

Value mean(Value a);
Value median(Value a);
Value mode(Value a);

Value geo_mean(Value a);
Value harmo_mean(Value a);
Value trim_mean(Value a);

/* ================= VARIANCE ================= */

Value PVAR(Value a);
Value var(Value a);

// Population standard deviation and sample standard deviation
Value PSD(Value a);
Value sd(Value a);

Value coeff_var(Value a);
Value skew(Value a);

/* ================= ADVANCED ================= */

Value corr_coeff(Value a, Value b);
Value co_var(Value a, Value b);
Value lsm(Value a);
Value lsm(Value x, Value y);

Value null_hypo(Value a);
Value p_val_cal(Value a);
Value chi_test(Value observed, Value expected);
Value L2Norm(Value a);
Value Lnorm(Value a);
/* ================= EXTRA STATISTICS ================= */

Value Range(Value a);

Value Q1(Value a);
Value Q2(Value a);
Value Q3(Value a);

Value IQR(Value a);

Value ZScore(Value value, Value mean, Value sd);

Value Std_Error(Value a);

Value Kurtosis(Value a);

// Additional basic statistics
Value Sum(Value a);
Value Count(Value a);
Value Min(Value a);
Value Max(Value a);
Value Percentile(Value a, Value p);
