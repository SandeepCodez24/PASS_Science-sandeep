// Vector differential and integral calculus (Kreyszig chapters 9 and 10):
//   div  curl (curl_calc)  arc_length3  frenet_frames  directional_deriv
//   integrate_line  is_conservative  potential_field  integrate_surface
//   integrate_volume  eval_gauss_divergence
// Green's and Stokes's theorems are green_integral / stokes_integral in
// calculus_builtin.cpp (the proposed eval_greens_theorem and
// eval_stokes_theorem are those functions' grid / surface forms, not new
// names).
//
// Grids follow ops_math.h: Z[i, j] at (x_j, y_i); G[k, i, j] at (x_j, y_i, z_k).
#include <algorithm>
#include <array>
#include <cmath>

#include "../matrix/matrix_index.h"
#include "../vector/vector.h"
#include "calculus.h"
#include "calculus_builtin.h"

namespace nc {
namespace ops {

namespace {

// Points of a curve: one per row (n x 2 or n x 3); 2 or 3 rows of more than
// 3 columns are read as one point per column. 2-D points get z = 0.
bool argCurve(const Args &a, size_t i, CallContext &ctx, std::vector<std::array<double, 3>> &pts,
              size_t minPoints) {
  Mat m;
  if (!argMat(a, i, ctx, m))
    return false;
  if ((m.c != 2 && m.c != 3) && (m.r == 2 || m.r == 3))
    m = scipy::transposeOf(m);
  if (m.c != 2 && m.c != 3) {
    ctx.fail("the curve must be a matrix with one point per row, [x, y] or [x, y, z]");
    return false;
  }
  if (m.r < minPoints) {
    ctx.fail("the curve needs at least " + std::to_string(minPoints) + " points");
    return false;
  }
  pts.assign(m.r, {0.0, 0.0, 0.0});
  for (size_t r = 0; r < m.r; r++)
    for (size_t c = 0; c < m.c; c++)
      pts[r][c] = m(r, c);
  return true;
}

Value pointsMatrix(const std::vector<std::array<double, 3>> &p) {
  Mat m(p.size(), 3);
  for (size_t r = 0; r < p.size(); r++)
    for (size_t c = 0; c < 3; c++)
      m(r, c) = p[r][c];
  return matOf(m);
}

// The field forms shared by div and curl: k leading component grids (2 or
// 3) and their spacings. False (error reported) when the shapes do not fit.
bool fieldGrids(const Args &a, CallContext &ctx, std::vector<Grid> &comp, double h[3]) {
  const size_t k = leadingGrids(a, 3, comp);
  if (k < 2) {
    ctx.fail("give the field components as grids of one shape: (U, V[, dx, dy]) or (U, V, W[, "
             "dx, dy, dz])");
    return false;
  }
  if (k == 3 && comp[0].rank != 3) {
    ctx.fail("a 3-component field needs 3-D grids, N-D matrices of shape [nz, ny, nx]");
    return false;
  }
  if (k == 2 && comp[0].rank != 2) {
    ctx.fail("a 2-component field needs 2-D grids (matrices); give W for a 3-D field");
    return false;
  }
  return gridSpacing(a, k, comp[0], ctx, h);
}

Value divImpl(const Args &a, CallContext &ctx) {
  if (a.size() == 1) { // old form: sum of the components (vector.cpp)
    g_lastVectorOk = true;
    Value r = divergence(matVectorAsArray(a[0]));
    if (!g_lastVectorOk) {
      ctx.fail("div(a) expects a vector of numbers");
      return Value();
    }
    return r;
  }
  if (isFnArg(a[0])) {
    Fn F;
    Vec p;
    if (!argCallable(a, 0, ctx, F) || !argVec(a, 1, ctx, p))
      return Value();
    double h = stepFor(p);
    if (given(a, 2) && !argPositive(a, 2, ctx, h))
      return Value();
    double s = 0.0;
    for (size_t i = 0; i < p.size(); i++) {
      const Vec d = vPartialAt(F, p, i, h);
      if (!fnOk(F, ctx))
        return Value();
      if (d.size() != p.size()) {
        ctx.fail(F.describe() + " must return as many components as the point has (" +
                 std::to_string(p.size()) + ")");
        return Value();
      }
      s += d[i];
    }
    return Value(s);
  }
  std::vector<Grid> c;
  double h[3];
  if (!fieldGrids(a, ctx, c, h))
    return Value();
  Grid d = gridDiff(c[0], 0, h[0]);
  for (size_t ax = 1; ax < c.size(); ax++) {
    Grid e = gridDiff(c[ax], static_cast<int>(ax), h[ax]);
    for (size_t k = 0; k < d.size(); k++)
      d.a[k] += e.a[k];
  }
  return gridValue(d);
}

Value curlImpl(const Args &a, CallContext &ctx) {
  if (a.size() == 1) { // old form: cyclic difference of a 3-vector (vector.cpp)
    Value r = Curl(matVectorAsArray(a[0]));
    if (r.isText) {
      ctx.fail(r.text());
      return Value();
    }
    return matArrayAsMatrix(r, isColumnValue(a[0]));
  }
  if (isFnArg(a[0])) {
    Fn F;
    Vec p;
    if (!argCallable(a, 0, ctx, F) || !argVec(a, 1, ctx, p, 2))
      return Value();
    if (p.size() > 3) {
      ctx.fail("curl is defined for points in 2 or 3 dimensions");
      return Value();
    }
    double h = stepFor(p);
    if (given(a, 2) && !argPositive(a, 2, ctx, h))
      return Value();
    std::vector<Vec> d(p.size());
    for (size_t i = 0; i < p.size(); i++)
      d[i] = vPartialAt(F, p, i, h); // d[i][k] = dF_k / dx_i
    if (!fnOk(F, ctx))
      return Value();
    for (const Vec &v : d)
      if (v.size() != p.size()) {
        ctx.fail(F.describe() + " must return as many components as the point has");
        return Value();
      }
    if (p.size() == 2)
      return Value(d[0][1] - d[1][0]);
    return rowOf(Vec{d[1][2] - d[2][1], d[2][0] - d[0][2], d[0][1] - d[1][0]});
  }
  std::vector<Grid> c;
  double h[3];
  if (!fieldGrids(a, ctx, c, h))
    return Value();
  if (c.size() == 2) { // scalar curl dV/dx - dU/dy
    Grid vx = gridDiff(c[1], 0, h[0]), uy = gridDiff(c[0], 1, h[1]);
    for (size_t k = 0; k < vx.size(); k++)
      vx.a[k] -= uy.a[k];
    return gridValue(vx);
  }
  const Grid &U = c[0], &V = c[1], &W = c[2];
  Grid cx = gridDiff(W, 1, h[1]), t = gridDiff(V, 2, h[2]);
  for (size_t k = 0; k < cx.size(); k++)
    cx.a[k] -= t.a[k];
  Grid cy = gridDiff(U, 2, h[2]);
  t = gridDiff(W, 0, h[0]);
  for (size_t k = 0; k < cy.size(); k++)
    cy.a[k] -= t.a[k];
  Grid cz = gridDiff(V, 0, h[0]);
  t = gridDiff(U, 1, h[1]);
  for (size_t k = 0; k < cz.size(); k++)
    cz.a[k] -= t.a[k];
  return gridDict(cx, cy, &cz);
}

// Flux-type sum over a parametric surface: integral of g[k] du dv (u along
// columns, v along rows, unit steps).
double surfaceSum(const Vec &g, size_t R, size_t C) {
  Grid fg(1, R, C, 2);
  fg.a = g;
  return calc::integrate2(fg, 1.0, 1.0);
}

} // namespace

#define OPS_DOMAIN Domain::VectorCalculus

void registerVectorCalculus(OpsRegistry &reg) {

  const char *divUsage = "div(a) | div(@F, point[, h]) | div(U, V[, dx, dy]) | div(U, V, W[, dx, dy, dz])";
  reg.add(OpsSpec{"div", Domain::VectorCalculus, 1, 6, divUsage, "Divergence",
                  kNDArgs | kKernel | kCallsNC, divImpl});
  // divergence is the vector table's name for the same operation (kept).
  reg.add(OpsSpec{"divergence", Domain::VectorCalculus, 1, 6,
                  "divergence(...) - same forms as div", "Divergence", kNDArgs | kKernel | kCallsNC,
                  divImpl});
  const char *curlUsage =
      "curl([Fx, Fy, Fz]) | curl(@F, point[, h]) | curl(U, V[, dx, dy]) | curl(U, V, W[, dx, dy, dz])";
  reg.add(OpsSpec{"curl", Domain::VectorCalculus, 1, 6, curlUsage, "Curl",
                  kNDArgs | kKernel | kCallsNC, curlImpl});
  // curl_calc is the calculus table's name for the same operation (kept).
  reg.add(OpsSpec{"curl_calc", Domain::VectorCalculus, 1, 6,
                  "curl_calc(...) - same forms as curl", "Curl", kNDArgs | kKernel | kCallsNC,
                  curlImpl});

  // ---- curves ----
  OPS_FN("arc_length3", 1, 1, "arc_length3(curve_points)", "Cumulative arc length", 0) {
    std::vector<std::array<double, 3>> p;
    if (!argCurve(a, 0, ctx, p, 2))
      return Value();
    Vec s(p.size(), 0.0);
    for (size_t i = 1; i < p.size(); i++)
      s[i] = s[i - 1] + std::sqrt(std::pow(p[i][0] - p[i - 1][0], 2) +
                                  std::pow(p[i][1] - p[i - 1][1], 2) +
                                  std::pow(p[i][2] - p[i - 1][2], 2));
    return rowOf(s);
  }
  OPS_END

  OPS_FN("frenet_frames", 1, 2, "frenet_frames(curve_points[, t])", "Frenet frame, curvature", 0) {
    std::vector<std::array<double, 3>> p;
    if (!argCurve(a, 0, ctx, p, 5))
      return Value();
    const size_t n = p.size();
    Vec t(n);
    for (size_t i = 0; i < n; i++)
      t[i] = static_cast<double>(i);
    if (given(a, 1)) {
      if (!argVec(a, 1, ctx, t) || t.size() != n) {
        if (ctx.ok())
          ctx.fail("t must have one value per point");
        return Value();
      }
      for (size_t i = 1; i < n; i++)
        if (!(t[i] > t[i - 1])) {
          ctx.fail("t must increase");
          return Value();
        }
    }
    // r', r'', r''' by differences in t, one coordinate at a time: fourth
    // order when t is evenly spaced (the default), second order otherwise.
    bool even = true;
    const double ht = t[1] - t[0];
    for (size_t i = 2; i < n && even; i++)
      even = std::abs((t[i] - t[i - 1]) - ht) <= 1e-9 * std::abs(ht);
    std::array<Vec, 3> d1, d2, d3;
    for (int c = 0; c < 3; c++) {
      Vec x(n);
      for (size_t i = 0; i < n; i++)
        x[i] = p[i][c];
      d1[c] = even ? diff1(x, ht, 4) : diff1(x, t);
      d2[c] = even ? diff1(d1[c], ht, 4) : diff1(d1[c], t);
      d3[c] = even ? diff1(d2[c], ht, 4) : diff1(d2[c], t);
    }
    std::vector<std::array<double, 3>> T(n), N(n), B(n);
    Vec kappa(n), tau(n);
    for (size_t i = 0; i < n; i++) {
      const double r1[3] = {d1[0][i], d1[1][i], d1[2][i]};
      const double r2[3] = {d2[0][i], d2[1][i], d2[2][i]};
      const double r3[3] = {d3[0][i], d3[1][i], d3[2][i]};
      const double cr[3] = {r1[1] * r2[2] - r1[2] * r2[1], r1[2] * r2[0] - r1[0] * r2[2],
                            r1[0] * r2[1] - r1[1] * r2[0]};
      const double sp = std::sqrt(r1[0] * r1[0] + r1[1] * r1[1] + r1[2] * r1[2]);
      const double cn = std::sqrt(cr[0] * cr[0] + cr[1] * cr[1] + cr[2] * cr[2]);
      if (sp == 0.0) {
        ctx.fail("the curve stops (two equal points); its tangent is not defined at point " +
                 std::to_string(i));
        return Value();
      }
      for (int c = 0; c < 3; c++)
        T[i][c] = r1[c] / sp;
      kappa[i] = cn / (sp * sp * sp);
      // A straight piece (r' x r'' = 0 to rounding) has no normal: N = B = 0, tau = 0.
      if (cn <= 1e-12 * sp * sp) {
        N[i] = {0.0, 0.0, 0.0};
        B[i] = {0.0, 0.0, 0.0};
        kappa[i] = 0.0;
        tau[i] = 0.0;
        continue;
      }
      for (int c = 0; c < 3; c++)
        B[i][c] = cr[c] / cn;
      N[i] = {B[i][1] * T[i][2] - B[i][2] * T[i][1], B[i][2] * T[i][0] - B[i][0] * T[i][2],
              B[i][0] * T[i][1] - B[i][1] * T[i][0]};
      tau[i] = (cr[0] * r3[0] + cr[1] * r3[1] + cr[2] * r3[2]) / (cn * cn);
    }
    return dictOf({{"T", pointsMatrix(T)},
                   {"N", pointsMatrix(N)},
                   {"B", pointsMatrix(B)},
                   {"kappa", rowOf(kappa)},
                   {"tau", rowOf(tau)}});
  }
  OPS_END

  // ---- directional derivative ----
  OPS_FN("directional_deriv", 2, 5,
         "directional_deriv(F, direction[, dx, dy, dz]) | directional_deriv(@f, point, "
         "direction[, h])",
         "Directional derivative", kNDArgs | kKernel | kCallsNC) {
    if (isFnArg(a[0])) {
      Fn f;
      Vec p, u;
      if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, p) || a.size() < 3 ||
          !argVec(a, 2, ctx, u))
        return a.size() < 3 ? (ctx.fail("directional_deriv(@f, point, direction) needs the "
                                        "direction"),
                               Value())
                            : Value();
      if (u.size() != p.size()) {
        ctx.fail("the direction must have as many components as the point");
        return Value();
      }
      double len = 0.0;
      for (double v : u)
        len += v * v;
      len = std::sqrt(len);
      if (len == 0.0) {
        ctx.fail("the direction must not be the zero vector");
        return Value();
      }
      double h = stepFor(p);
      if (given(a, 3) && !argPositive(a, 3, ctx, h))
        return Value();
      double s = 0.0;
      for (size_t i = 0; i < p.size(); i++)
        if (u[i] != 0.0)
          s += partialAt(f, p, i, h) * u[i] / len;
      return fnOk(f, ctx) ? Value(s) : Value();
    }
    Grid g;
    Vec u;
    double h[3];
    if (!argGrid(a, 0, ctx, g) || !argVec(a, 1, ctx, u) || !gridSpacing(a, 2, g, ctx, h))
      return Value();
    if (u.size() != static_cast<size_t>(g.rank)) {
      ctx.fail("a " + std::to_string(g.rank) + "-D grid needs a direction of " +
               std::to_string(g.rank) + " components");
      return Value();
    }
    double len = 0.0;
    for (double v : u)
      len += v * v;
    len = std::sqrt(len);
    if (len == 0.0) {
      ctx.fail("the direction must not be the zero vector");
      return Value();
    }
    Grid out(g.nz, g.ny, g.nx, g.rank);
    for (int ax = 0; ax < g.rank; ax++) {
      if (u[ax] == 0.0)
        continue;
      Grid d = gridDiff(g, ax, h[ax]);
      for (size_t k = 0; k < out.size(); k++)
        out.a[k] += d.a[k] * u[ax] / len;
    }
    return gridValue(out);
  }
  OPS_END

  // ---- line integral (work) ----
  OPS_FN("integrate_line", 2, 2, "integrate_line(@F, path_points)", "Line integral (work)",
         kCallsNC) {
    Fn F;
    Mat P;
    if (!argCallable(a, 0, ctx, F) || !argMat(a, 1, ctx, P))
      return Value();
    if ((P.c < 2 || P.c > 3) && (P.r == 2 || P.r == 3))
      P = scipy::transposeOf(P);
    if (P.c < 2 || P.c > 3 || P.r < 2) {
      ctx.fail("the path must be a matrix with one point per row, [x, y] or [x, y, z], at least 2 "
               "points");
      return Value();
    }
    // Straight segments, Simpson's rule on each: exact for fields up to cubic along it.
    const size_t d = P.c;
    double work = 0.0;
    Vec prev;
    for (size_t i = 0; i + 1 < P.r; i++) {
      Vec p0(P.row(i), P.row(i) + d), p1(P.row(i + 1), P.row(i + 1) + d), pm(d), dr(d);
      for (size_t k = 0; k < d; k++) {
        pm[k] = 0.5 * (p0[k] + p1[k]);
        dr[k] = p1[k] - p0[k];
      }
      const Vec f0 = i == 0 ? F.vN(p0) : prev, fm = F.vN(pm), f1 = F.vN(p1);
      if (!fnOk(F, ctx))
        return Value();
      if (f0.size() != d || fm.size() != d || f1.size() != d) {
        ctx.fail(F.describe() + " must return " + std::to_string(d) + " components");
        return Value();
      }
      for (size_t k = 0; k < d; k++)
        work += (f0[k] + 4.0 * fm[k] + f1[k]) / 6.0 * dr[k];
      prev = f1;
    }
    return Value(work);
  }
  OPS_END

  // ---- path independence ----
  OPS_FN("is_conservative", 2, 7,
         "is_conservative(U, V[, tol, dx, dy]) | is_conservative(U, V, W[, tol, dx, dy, dz])",
         "Path independence test", kNDArgs | kKernel) {
    std::vector<Grid> c;
    const size_t k = leadingGrids(a, 3, c);
    if (k < 2 || (k == 3 && c[0].rank != 3) || (k == 2 && c[0].rank != 2)) {
      ctx.fail("give the field components as grids of one shape: (U, V) 2-D matrices or (U, V, "
               "W) 3-D N-D matrices");
      return Value();
    }
    double tol = 1e-3;
    if (given(a, k) && !argPositive(a, k, ctx, tol))
      return Value();
    double h[3];
    if (!gridSpacing(a, k + 1, c[0], ctx, h))
      return Value();
    // All first partials: their size sets the scale the curl is measured against.
    std::vector<std::vector<Grid>> d(k);
    double scale = 0.0;
    for (size_t comp = 0; comp < k; comp++)
      for (size_t ax = 0; ax < k; ax++) {
        d[comp].push_back(gridDiff(c[comp], static_cast<int>(ax), h[ax]));
        for (double v : d[comp][ax].a)
          scale = std::max(scale, std::abs(v));
      }
    double worst = 0.0;
    const size_t n = c[0].size();
    for (size_t p = 0; p < n; p++) {
      // d[i][j] = dF_i / dx_j
      worst = std::max(worst, std::abs(d[1][0].a[p] - d[0][1].a[p]));
      if (k == 3) {
        worst = std::max(worst, std::abs(d[2][1].a[p] - d[1][2].a[p]));
        worst = std::max(worst, std::abs(d[0][2].a[p] - d[2][0].a[p]));
      }
    }
    const double rel = scale > 0.0 ? worst / scale : 0.0;
    return dictOf({{"conservative", Value::boolean(rel <= tol)},
                   {"max_curl", Value(worst)},
                   {"relative_curl", Value(rel)}});
  }
  OPS_END

  // ---- scalar potential ----
  OPS_FN("potential_field", 2, 4, "potential_field(U, V[, W][, spacing])", "Scalar potential",
         kNDArgs | kKernel) {
    std::vector<Grid> c;
    const size_t k = leadingGrids(a, 3, c);
    if (k < 2 || (k == 3 && c[0].rank != 3) || (k == 2 && c[0].rank != 2)) {
      ctx.fail("give the field components as grids of one shape: (U, V) 2-D matrices or (U, V, "
               "W) 3-D N-D matrices");
      return Value();
    }
    Vec sp(k, 1.0);
    if (given(a, k)) {
      if (!argVec(a, k, ctx, sp) || sp.size() != k) {
        if (ctx.ok())
          ctx.fail("the spacing must be [dx, dy" + std::string(k == 3 ? ", dz]" : "]"));
        return Value();
      }
      for (double s : sp)
        if (!(s > 0.0)) {
          ctx.fail("every spacing must be positive");
          return Value();
        }
    }
    if (a.size() > k + 1) {
      ctx.fail("too many arguments - usage: potential_field(U, V[, W][, spacing])");
      return Value();
    }
    double h[3] = {sp[0], sp[1], k == 3 ? sp[2] : 1.0};
    const Grid f = calc::potentialOf(c, h);
    return gridValue(f);
  }
  OPS_END

  // ---- flux through a surface ----
  OPS_FN("integrate_surface", 4, 4, "integrate_surface(F, X, Y, Z)", "Surface flux integral",
         kCallsNC) {
    Mat X, Y, Z;
    if (!argMat(a, 1, ctx, X) || !argMat(a, 2, ctx, Y) || !argMat(a, 3, ctx, Z))
      return Value();
    if (X.r != Y.r || X.r != Z.r || X.c != Y.c || X.c != Z.c || X.r < 2 || X.c < 2) {
      ctx.fail("X, Y and Z must be grids of the same shape, at least 2 x 2");
      return Value();
    }
    const size_t R = X.r, C = X.c, n = R * C;
    // F: a function of (x, y, z), or a dict {x, y, z} of grids sampled on the surface.
    std::array<Vec, 3> Fv;
    if (a[0].isDict) {
      const char *keys[3] = {"x", "y", "z"};
      for (int c = 0; c < 3; c++) {
        const Value *g = scipy::dictGet(a[0], keys[c]);
        Mat m;
        if (!g || !scipy::readMat(*g, m) || m.r != R || m.c != C) {
          ctx.fail(std::string("the field dict needs a grid '") + keys[c] +
                   "' of the surface's shape");
          return Value();
        }
        Fv[c] = m.a;
      }
    } else {
      Fn F;
      if (!argCallable(a, 0, ctx, F))
        return Value();
      for (int c = 0; c < 3; c++)
        Fv[c].assign(n, 0.0);
      for (size_t k = 0; k < n; k++) {
        const Vec v = F.vN({X.a[k], Y.a[k], Z.a[k]});
        if (!fnOk(F, ctx))
          return Value();
        if (v.size() != 3) {
          ctx.fail(F.describe() + " must return 3 components [F1, F2, F3]");
          return Value();
        }
        for (int c = 0; c < 3; c++)
          Fv[c][k] = v[c];
      }
    }
    Grid gx(1, R, C, 2), gy(1, R, C, 2), gz(1, R, C, 2);
    gx.a = X.a;
    gy.a = Y.a;
    gz.a = Z.a;
    const Grid xu = gridDiff(gx, 0, 1, 4), yu = gridDiff(gy, 0, 1, 4), zu = gridDiff(gz, 0, 1, 4);
    const Grid xv = gridDiff(gx, 1, 1, 4), yv = gridDiff(gy, 1, 1, 4), zv = gridDiff(gz, 1, 1, 4);
    Vec g(n);
    for (size_t k = 0; k < n; k++) {
      const double n1 = yu.a[k] * zv.a[k] - zu.a[k] * yv.a[k];
      const double n2 = zu.a[k] * xv.a[k] - xu.a[k] * zv.a[k];
      const double n3 = xu.a[k] * yv.a[k] - yu.a[k] * xv.a[k];
      g[k] = Fv[0][k] * n1 + Fv[1][k] * n2 + Fv[2][k] * n3;
    }
    return Value(surfaceSum(g, R, C));
  }
  OPS_END

  // ---- double / triple integral of a grid ----
  OPS_FN("integrate_volume", 1, 4, "integrate_volume(G[, dx, dy, dz])", "Volume integral",
         kNDArgs | kKernel) {
    Grid g;
    double h[3];
    if (!argGrid(a, 0, ctx, g) || !gridSpacing(a, 1, g, ctx, h))
      return Value();
    if (g.rank == 2)
      return Value(calc::integrate2(g, h[0], h[1]));
    return Value(calc::integrate3(g, h[0], h[1], h[2]));
  }
  OPS_END

  // ---- Gauss's divergence theorem ----
  OPS_FN("eval_gauss_divergence", 2, 6,
         "eval_gauss_divergence(U, V[, dx, dy]) | eval_gauss_divergence(U, V, W[, dx, dy, dz])",
         "Divergence theorem", kNDArgs | kKernel) {
    std::vector<Grid> c;
    double h[3];
    if (!fieldGrids(a, ctx, c, h))
      return Value();
    const Grid &g0 = c[0];
    Grid dv = gridDiff(c[0], 0, h[0]);
    for (size_t ax = 1; ax < c.size(); ax++) {
      Grid e = gridDiff(c[ax], static_cast<int>(ax), h[ax]);
      for (size_t k = 0; k < dv.size(); k++)
        dv.a[k] += e.a[k];
    }
    double vol, flux = 0.0;
    if (c.size() == 2) {
      vol = calc::integrate2(dv, h[0], h[1]);
      // Outward flux through the rectangle's edges: F.n ds.
      Vec right(g0.ny), left(g0.ny), top(g0.nx), bottom(g0.nx);
      for (size_t i = 0; i < g0.ny; i++) {
        right[i] = c[0].at(0, i, g0.nx - 1);
        left[i] = c[0].at(0, i, 0);
      }
      for (size_t j = 0; j < g0.nx; j++) {
        top[j] = c[1].at(0, g0.ny - 1, j);
        bottom[j] = c[1].at(0, 0, j);
      }
      flux = integrateUniform(right.data(), g0.ny, 1, h[1]) -
             integrateUniform(left.data(), g0.ny, 1, h[1]) +
             integrateUniform(top.data(), g0.nx, 1, h[0]) -
             integrateUniform(bottom.data(), g0.nx, 1, h[0]);
    } else {
      vol = calc::integrate3(dv, h[0], h[1], h[2]);
      // Six faces of the box.
      auto face = [&](int comp, int axis, bool high) {
        const size_t nz = g0.nz, ny = g0.ny, nx = g0.nx;
        Grid f(1, axis == 1 ? nz : (axis == 0 ? nz : ny), axis == 2 ? nx : (axis == 0 ? ny : nx),
               2);
        double d1, d2;
        for (size_t p = 0; p < f.ny; p++)
          for (size_t q = 0; q < f.nx; q++) {
            size_t k, i, j;
            if (axis == 0) { // x face: rows z, columns y
              k = p, i = q, j = high ? nx - 1 : 0;
            } else if (axis == 1) { // y face: rows z, columns x
              k = p, i = high ? ny - 1 : 0, j = q;
            } else { // z face: rows y, columns x
              k = high ? nz - 1 : 0, i = p, j = q;
            }
            f.at(0, p, q) = c[comp].at(k, i, j);
          }
        if (axis == 0) {
          d1 = h[1];
          d2 = h[2];
        } else if (axis == 1) {
          d1 = h[0];
          d2 = h[2];
        } else {
          d1 = h[0];
          d2 = h[1];
        }
        return calc::integrate2(f, d1, d2);
      };
      for (int ax = 0; ax < 3; ax++)
        flux += face(ax, ax, true) - face(ax, ax, false);
    }
    return dictOf({{"volume_integral", Value(vol)}, {"surface_flux", Value(flux)}});
  }
  OPS_END
}

} // namespace ops
} // namespace nc
