#include "calculus_builtin.h"
#include "calculus.h"

#include <functional>
#include <iostream>
#include <unordered_map>


Value calculusBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ===== DIFFERENTIATION ===== */
      {"ddt",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("ddt", 3))
           return Value();
         return ddt(a[0], a[1], a[2]);
       }},

      {"pddt",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("pddt", 3))
           return Value();
         return pddt(a[0], a[1], a[2]);
       }},

      /* ===== ANALYSIS ===== */
      {"continuity",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("continuity", 1))
           return Value();
         return continuity(a[0]);
       }},

      {"grad",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("grad", 1))
           return Value();
         return grad(a[0]);
       }},

      // NOTE: "Curl" intentionally left capitalized here (both this inner
      // key and the outer builtins.cpp key). Lowercasing it would collide
      // with the pre-existing lowercase "curl" entry already registered by
      // the Vector category in the outer builtinTable, silently shadowing
      // one of the two working call paths. See rename report.
      {"Curl",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Curl", 1))
           return Value();
         return Curl_Calc(a[0]);
       }},

      {"laplace",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("laplace", 1))
           return Value();
         return laplace(a[0]);
       }},

      /* ===== INTEGRAL OPERATORS ===== */
      {"green_integral",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("green_integral", 1))
           return Value();
         return green_integral(a[0]);
       }},

      {"stokes_integral",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("stokes_integral", 1))
           return Value();
         return stokes_integral(a[0]);
       }},

      /* ===== SERIES / ADVANCED ===== */
      {"taylor_series",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("taylor_series", 2))
           return Value();
         return taylor_series(a[0], a[1]);
       }},

      {"rad_of_con",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("rad_of_con", 1))
           return Value();
         return rad_of_con(a[0]);
       }},

      /* ===== VECTOR OPERATOR ===== */
      {"Div",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Div", 1))
           return Value();
         return Div(a[0]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown calculus function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}