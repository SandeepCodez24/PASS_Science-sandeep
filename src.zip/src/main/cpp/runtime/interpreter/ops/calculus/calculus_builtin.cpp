// Calculus operations of the NC function table:
//   ddt  pddt  continuity  grad (grid form)  laplace  green_integral (grid
//   form)  stokes_integral  rad_of_con
// div and curl are in calculus_fields.cpp with the other vector-field
// functions. Every old form of these functions still works; the old forms
// are listed first in each block.
#include "calculus_builtin.h"

#include <cmath>

#include "../matrix/matrix_index.h"
#include "../vector/vector.h"
#include "calculus.h"

namespace nc {
namespace ops {

namespace {

// Elementwise (a - b) / (2h): the old ddt/pddt(f_plus, f_minus, h); h is one
// step or one step per value.
Value oldCentral(const Args &a, CallContext &ctx) {
  Vec p, m, h;
  if (!argVec(a, 0, ctx, p) || !argVec(a, 1, ctx, m) || !argVec(a, 2, ctx, h))
    return Value();
  if (p.size() != m.size() || (h.size() != 1 && h.size() != p.size())) {
    ctx.fail("f_plus, f_minus (and h, when it is not one number) must have the same number of "
             "values");
    return Value();
  }
  for (double v : h)
    if (v == 0.0) {
      ctx.fail("the step h must not be 0");
      return Value();
    }
  Vec r(p.size());
  for (size_t i = 0; i < p.size(); i++)
    r[i] = (p[i] - m[i]) / (2.0 * h[h.size() == 1 ? 0 : i]);
  return r.size() == 1 ? Value(r[0]) : vecLike(r, a[0]);
}

// f'(x) at each x, fourth-order central difference.
Value derivativeOfFunction(const Args &a, CallContext &ctx) {
  Fn f;
  Vec x;
  if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, x))
    return Value();
  double h0 = 0.0;
  if (given(a, 2) && !argPositive(a, 2, ctx, h0))
    return Value();
  Vec d(x.size());
  for (size_t i = 0; i < x.size(); i++) {
    const double h = h0 > 0.0 ? h0 : stepFor({x[i]});
    d[i] = (f.r(x[i] - 2 * h) - 8 * f.r(x[i] - h) + 8 * f.r(x[i] + h) - f.r(x[i] + 2 * h)) / (12 * h);
    if (!fnOk(f, ctx))
      return Value();
  }
  return d.size() == 1 ? Value(d[0]) : vecLike(d, a[1]);
}

// Spacing argument of a sampled line: a number h, or the coordinates x.
bool lineSpacing(const Args &a, size_t i, size_t n, CallContext &ctx, double &h, Vec &x) {
  h = 1.0;
  x.clear();
  if (!given(a, i))
    return true;
  if (isNumber(a[i]) || (a[i].isMatrix && !isVectorValue(a[i]))) {
    return argPositive(a, i, ctx, h);
  }
  if (!argVec(a, i, ctx, x))
    return false;
  if (x.size() != n) {
    ctx.fail("the coordinates must have as many values as the samples (" + std::to_string(n) + ")");
    return false;
  }
  for (size_t k = 1; k < n; k++)
    if (!(x[k] > x[k - 1])) {
      ctx.fail("the coordinates must increase");
      return false;
    }
  return true;
}

} // namespace

#define OPS_DOMAIN Domain::Calculus

void registerCalculus(OpsRegistry &reg) {

  // ---- ddt: derivative ----
  OPS_FN("ddt", 1, 3, "ddt(Y[, h or x]) | ddt(@f, x[, h]) | ddt(f_plus, f_minus, h)",
         "Derivative", kCallsNC) {
    if (isFnArg(a[0])) {
      if (a.size() < 2) {
        ctx.fail("ddt(@f, x[, h]) needs the point x");
        return Value();
      }
      return derivativeOfFunction(a, ctx);
    }
    if (a.size() == 3)
      return oldCentral(a, ctx);
    Vec y, x;
    double h;
    if (!argVec(a, 0, ctx, y, 2))
      return Value();
    if (a[0].isMatrix && !isVectorValue(a[0])) {
      ctx.fail("ddt differentiates one sampled line; for a grid use pddt(Z, \"x\") or grad(Z)");
      return Value();
    }
    if (!lineSpacing(a, 1, y.size(), ctx, h, x))
      return Value();
    return vecLike(x.empty() ? diff1(y, h) : diff1(y, x), a[0]);
  }
  OPS_END

  // ---- pddt: partial derivative ----
  OPS_FN("pddt", 2, 4,
         "pddt(Z, \"x\"|\"y\"|\"z\"[, h]) | pddt(@f, point, var[, h]) | pddt(f_plus, f_minus, h)",
         "Partial derivative", kCallsNC | kNDArgs) {
    if (isFnArg(a[0])) {
      Fn f;
      Vec p;
      int axis;
      if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, p) || a.size() < 3 ||
          !argAxis(a, 2, ctx, axis, static_cast<int>(p.size())))
        return a.size() < 3 ? (ctx.fail("pddt(@f, point, var[, h]) needs the variable"), Value())
                            : Value();
      double h = stepFor(p);
      if (given(a, 3) && !argPositive(a, 3, ctx, h))
        return Value();
      const double d = partialAt(f, p, static_cast<size_t>(axis), h);
      return fnOk(f, ctx) ? Value(d) : Value();
    }
    if (a.size() == 3 && !a[1].isText && !isGridValue(a[0]))
      return oldCentral(a, ctx);
    Grid g;
    if (!argGrid(a, 0, ctx, g))
      return Value();
    int axis;
    if (!argAxis(a, 1, ctx, axis, g.rank))
      return Value();
    double h = 1.0;
    if (given(a, 2) && !argPositive(a, 2, ctx, h))
      return Value();
    return gridValue(gridDiff(g, axis, h));
  }
  OPS_END

  // ---- continuity ----
  OPS_FN("continuity", 1, 3, "continuity(a) | continuity(@f, x0[, tol])", "Continuity check",
         kCallsNC | kComplexArgs) {
    if (!isFnArg(a[0])) {
      if (a.size() != 1) {
        ctx.fail("continuity(a) takes one value; for a function use continuity(@f, x0)");
        return Value();
      }
      CVec v;
      if (!scipy::readCVec(a[0], v)) {
        ctx.fail("the argument must be a number, an array or a matrix of numbers");
        return Value();
      }
      for (const cd &z : v)
        if (!isFiniteC(z))
          return Value(0.0);
      return Value(1.0);
    }
    // Left and right limits: |f(x0 +- h) - f(x0)| must shrink as h does.
    Fn f;
    Vec x0;
    if (!argCallable(a, 0, ctx, f) || !argVec(a, 1, ctx, x0))
      return Value();
    double tol = 1e-6;
    if (given(a, 2) && !argPositive(a, 2, ctx, tol))
      return Value();
    Vec out(x0.size());
    for (size_t i = 0; i < x0.size(); i++) {
      const double x = x0[i], s = std::max(1.0, std::abs(x));
      const cd f0 = f.c(x);
      bool cont = isFiniteC(f0);
      for (int side = -1; cont && side <= 1; side += 2) {
        double d[3];
        const double hs[3] = {1e-3, 1e-5, 1e-7};
        for (int k = 0; k < 3; k++)
          d[k] = std::abs(f.c(x + side * hs[k] * s) - f0);
        const double lim = tol * (1.0 + std::abs(f0));
        cont = std::isfinite(d[2]) && (d[2] <= lim || (d[2] < 0.5 * d[1] && d[1] < 0.5 * d[0]));
      }
      if (!fnOk(f, ctx))
        return Value();
      out[i] = cont ? 1.0 : 0.0;
    }
    return out.size() == 1 ? Value(out[0]) : vecLike(out, a[1]);
  }
  OPS_END

  // ---- grad: grid form (grad(@f, point) is the parser's) ----
  OPS_FN("grad", 1, 4, "grad(Y[, h]) | grad(Z[, dx, dy]) | grad(G[, dx, dy, dz]) | grad(@f, point[, h])",
         "Gradient", kNDArgs | kKernel) {
    if (isFnArg(a[0])) {
      ctx.fail("give the function as a reference: grad(@f, point)");
      return Value();
    }
    if (isVectorValue(a[0]) || isNumber(a[0])) {
      Vec y, x;
      double h;
      if (!argVec(a, 0, ctx, y, 2) || !lineSpacing(a, 1, y.size(), ctx, h, x))
        return Value();
      if (a.size() > 2) {
        ctx.fail("grad(Y[, h]) of a sampled line takes one spacing");
        return Value();
      }
      return vecLike(x.empty() ? diff1(y, h) : diff1(y, x), a[0]);
    }
    Grid g;
    double h[3];
    if (!argGrid(a, 0, ctx, g) || !gridSpacing(a, 1, g, ctx, h))
      return Value();
    Grid gx = gridDiff(g, 0, h[0]), gy = gridDiff(g, 1, h[1]);
    if (g.rank == 3) {
      Grid gz = gridDiff(g, 2, h[2]);
      return gridDict(gx, gy, &gz);
    }
    return gridDict(gx, gy, nullptr);
  }
  OPS_END

  // ---- laplace: Laplacian ----
  OPS_FN("laplace", 1, 4,
         "laplace([fxx, fyy, fzz]) | laplace(Y, h) | laplace(Z[, dx, dy]) | laplace(G[, dx, dy, "
         "dz]) | laplace(@f, point[, h])",
         "Laplacian", kNDArgs | kKernel | kCallsNC) {
    if (isFnArg(a[0])) {
      Fn f;
      Vec p;
      if (!argCallable(a, 0, ctx, f) || a.size() < 2 || !argVec(a, 1, ctx, p))
        return a.size() < 2 ? (ctx.fail("laplace(@f, point[, h]) needs the point"), Value())
                            : Value();
      double h = stepFor(p, 1e-2);
      if (given(a, 2) && !argPositive(a, 2, ctx, h))
        return Value();
      const double f0 = f.rN(p);
      double sum = 0.0;
      for (size_t i = 0; i < p.size(); i++) {
        Vec q = p;
        auto at = [&](double s) {
          q[i] = p[i] + s * h;
          return f.rN(q);
        };
        sum += (-at(2) + 16 * at(1) - 30 * f0 + 16 * at(-1) - at(-2)) / (12 * h * h);
      }
      return fnOk(f, ctx) ? Value(sum) : Value();
    }
    // Old form: one vector of second derivatives -> their sum.
    if (a.size() == 1 && !isGridValue(a[0])) {
      Vec v;
      if (!argVec(a, 0, ctx, v))
        return Value();
      double s = 0.0;
      for (double d : v)
        s += d;
      return Value(s);
    }
    if (isVectorValue(a[0])) {
      Vec y;
      double h;
      if (!argVec(a, 0, ctx, y, 3) || !argPositive(a, 1, ctx, h))
        return Value();
      if (a.size() > 2) {
        ctx.fail("laplace(Y, h) of a sampled line takes one spacing");
        return Value();
      }
      return vecLike(calc::secondDiff(y, h), a[0]);
    }
    Grid g;
    double h[3];
    if (!argGrid(a, 0, ctx, g) || !gridSpacing(a, 1, g, ctx, h))
      return Value();
    Grid lap = calc::gridSecondDiff(g, 0, h[0]);
    const int axes = g.rank == 3 ? 3 : 2;
    for (int ax = 1; ax < axes; ax++) {
      Grid d = calc::gridSecondDiff(g, ax, h[ax]);
      for (size_t k = 0; k < lap.size(); k++)
        lap.a[k] += d.a[k];
    }
    return gridValue(lap);
  }
  OPS_END

  // ---- green_integral: grid form (green_integral(@P, @Q, ...) is the parser's) ----
  OPS_FN("green_integral", 2, 7,
         "green_integral(P, Q[, dx, dy]) | green_integral(@P, @Q, x0, x1, y0, y1[, n])",
         "Green's theorem", kKernel) {
    if (isFnArg(a[0])) {
      ctx.fail("give the functions as references: green_integral(@P, @Q, x0, x1, y0, y1)");
      return Value();
    }
    Grid P, Q;
    if (!argGrid(a, 0, ctx, P) || !argGrid(a, 1, ctx, Q))
      return Value();
    if (P.rank != 2 || !P.sameShape(Q)) {
      ctx.fail("P and Q must be 2-D grids of the same shape (rows along y, columns along x)");
      return Value();
    }
    double h[3];
    if (!gridSpacing(a, 2, P, ctx, h))
      return Value();
    // Area integral of dQ/dx - dP/dy (Kreyszig 10.4): the circulation of
    // [P, Q] around the rectangle, counter-clockwise.
    Grid qx = gridDiff(Q, 0, h[0]), py = gridDiff(P, 1, h[1]);
    for (size_t k = 0; k < qx.size(); k++)
      qx.a[k] -= py.a[k];
    return Value(calc::integrate2(qx, h[0], h[1]));
  }
  OPS_END

  // ---- stokes_integral ----
  OPS_FN("stokes_integral", 1, 5, "stokes_integral([Fx, Fy, Fz]) | stokes_integral(@F, X, Y, Z[, h])",
         "Stokes' theorem", kCallsNC) {
    if (!isFnArg(a[0])) {
      if (a.size() != 1) {
        ctx.fail("the field must be a function: stokes_integral(@F, X, Y, Z)");
        return Value();
      }
      // Old form: the cyclic difference of a 3-vector (vector.cpp's curl).
      Value r = Curl(matVectorAsArray(a[0]));
      if (r.isText) {
        ctx.fail(r.text());
        return Value();
      }
      return matArrayAsMatrix(r, isColumnValue(a[0]));
    }
    // Surface r(u, v) = (X, Y, Z)[i, j]: u along the columns j, v along the
    // rows i, normal r_u x r_v. Flux of curl F through it, and the
    // circulation of F around its edge (u, v) counter-clockwise - equal by
    // Stokes' theorem (Kreyszig 10.9).
    Fn F;
    Mat X, Y, Z;
    if (a.size() < 4 || !argCallable(a, 0, ctx, F) || !argMat(a, 1, ctx, X) ||
        !argMat(a, 2, ctx, Y) || !argMat(a, 3, ctx, Z))
      return a.size() < 4 ? (ctx.fail("stokes_integral(@F, X, Y, Z) needs the surface grids"),
                             Value())
                          : Value();
    if (X.r != Y.r || X.r != Z.r || X.c != Y.c || X.c != Z.c || X.r < 2 || X.c < 2) {
      ctx.fail("X, Y and Z must be grids of the same shape, at least 2 x 2");
      return Value();
    }
    double h = 0.0;
    if (given(a, 4) && !argPositive(a, 4, ctx, h))
      return Value();
    const size_t R = X.r, C = X.c;
    Mat flux(R, C);
    Grid gx(1, R, C, 2), gy(1, R, C, 2), gz(1, R, C, 2);
    gx.a = X.a;
    gy.a = Y.a;
    gz.a = Z.a;
    Grid xu = gridDiff(gx, 0, 1, 4), yu = gridDiff(gy, 0, 1, 4), zu = gridDiff(gz, 0, 1, 4);
    Grid xv = gridDiff(gx, 1, 1, 4), yv = gridDiff(gy, 1, 1, 4), zv = gridDiff(gz, 1, 1, 4);
    for (size_t k = 0; k < R * C; k++) {
      const Vec p = {X.a[k], Y.a[k], Z.a[k]};
      const double hh = h > 0 ? h : stepFor(p);
      const Vec dx = vPartialAt(F, p, 0, hh), dy = vPartialAt(F, p, 1, hh),
                dz = vPartialAt(F, p, 2, hh);
      if (!fnOk(F, ctx))
        return Value();
      if (dx.size() != 3) {
        ctx.fail(F.describe() + " must return 3 components [F1, F2, F3]");
        return Value();
      }
      const double c1 = dy[2] - dz[1], c2 = dz[0] - dx[2], c3 = dx[1] - dy[0];
      const double n1 = yu.a[k] * zv.a[k] - zu.a[k] * yv.a[k];
      const double n2 = zu.a[k] * xv.a[k] - xu.a[k] * zv.a[k];
      const double n3 = xu.a[k] * yv.a[k] - yu.a[k] * xv.a[k];
      flux.a[k] = c1 * n1 + c2 * n2 + c3 * n3;
    }
    Grid fg(1, R, C, 2);
    fg.a = flux.a;
    const double surface = calc::integrate2(fg, 1.0, 1.0);
    // Edge: bottom row left->right, right column up, top row right->left, left column down.
    auto edge = [&](const std::vector<size_t> &idx) {
      const size_t n = idx.size();
      Vec px(n), py(n), pz(n), g(n);
      for (size_t t = 0; t < n; t++) {
        px[t] = X.a[idx[t]];
        py[t] = Y.a[idx[t]];
        pz[t] = Z.a[idx[t]];
      }
      const Vec dxt = diff1(px, 1.0, 4), dyt = diff1(py, 1.0, 4), dzt = diff1(pz, 1.0, 4);
      for (size_t t = 0; t < n; t++) {
        const Vec v = F.vN({px[t], py[t], pz[t]});
        g[t] = v.size() == 3 ? v[0] * dxt[t] + v[1] * dyt[t] + v[2] * dzt[t] : kNaN;
      }
      return integrateUniform(g.data(), n, 1, 1.0);
    };
    std::vector<size_t> bottom, right, top, left;
    for (size_t j = 0; j < C; j++)
      bottom.push_back(j);
    for (size_t i = 0; i < R; i++)
      right.push_back(i * C + C - 1);
    for (size_t j = C; j-- > 0;)
      top.push_back((R - 1) * C + j);
    for (size_t i = R; i-- > 0;)
      left.push_back(i * C);
    const double circ = edge(bottom) + edge(right) + edge(top) + edge(left);
    if (!fnOk(F, ctx))
      return Value();
    return dictOf({{"surface_integral", Value(surface)}, {"circulation", Value(circ)}});
  }
  OPS_END

  // ---- rad_of_con: radius of convergence ----
  OPS_FN("rad_of_con", 1, 1, "rad_of_con(coeffs)", "Radius of convergence", kComplexArgs) {
    CVec c;
    if (!argCVec(a, 0, ctx, c, 2))
      return Value();
    const double R = calc::radiusOfConvergence(c);
    if (std::isnan(R)) {
      ctx.fail("at least two coefficients must be nonzero");
      return Value();
    }
    return Value(R);
  }
  OPS_END
}

} // namespace ops
} // namespace nc
