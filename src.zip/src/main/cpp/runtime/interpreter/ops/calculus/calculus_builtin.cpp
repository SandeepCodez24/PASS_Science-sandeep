#include "calculus_builtin.h"
#include "calculus.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>


Value calculusBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ===== DIFFERENTIATION ===== */
      {"ddt",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "ddt", 3))
           return Value();
         return ddt(a[0], a[1], a[2]);
       }},

      {"pddt",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "pddt", 3))
           return Value();
         return pddt(a[0], a[1], a[2]);
       }},

      /* ===== ANALYSIS ===== */
      {"continuity",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "continuity", 1))
           return Value();
         return continuity(a[0]);
       }},

      // "grad" moved to a reserved Call-time interception in
      // parser_factor.cpp (evaluateExpr's ExprKind::Call case): the old
      // grad(a) here was a pure no-op identity function (see calculus.cpp's
      // git history) - a real gradient needs to call the user's function
      // repeatedly at perturbed points, which a plain free function with no
      // Parser access can't do. See parser_factor.cpp's own comment on the
      // "grad" interception for the real implementation.

      // "curl_calc" (not "curl" — that name is already owned by the Vector
      // category's "curl" in the outer table). Corrected 2026-09-16: this
      // is NOT a different underlying function, despite what this comment
      // used to claim - Curl_Calc(a) just calls the identical Curl(a) from
      // vector.cpp. It's registered under a second name purely so the
      // calculus domain can expose the same operation under a
      // calculus-appropriate name without colliding with the vector
      // domain's own registration of it.
      {"curl_calc",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "curl_calc", 1))
           return Value();
         return Curl_Calc(a[0]);
       }},

      {"laplace",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "laplace", 1))
           return Value();
         return laplace(a[0]);
       }},

      /* ===== INTEGRAL OPERATORS ===== */
      // "green_integral" moved to a reserved Call-time interception in
      // parser_factor.cpp, same reason as "grad" above - the old
      // green_integral(a) here just computed Q-P from two raw scalar
      // samples, with no derivative and no region to integrate over at
      // all; there was no mathematical justification for that number
      // approximating Green's theorem. The real implementation needs to
      // call P/Q repeatedly over a 2D grid, which requires Parser access.

      {"stokes_integral",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "stokes_integral", 1))
           return Value();
         return stokes_integral(a[0]);
       }},

      /* ===== SERIES / ADVANCED ===== */
      // "taylor_series" moved to a reserved Call-time interception in
      // parser_factor.cpp, same reason as "grad"/"green_integral" above -
      // the old taylor_series(x,n) here was hardcoded to ONLY ever compute
      // e^x's own Maclaurin series regardless of what function a caller
      // might have wanted; the real, general version needs to call an
      // arbitrary user function to numerically differentiate it, which
      // requires Parser access.

      {"rad_of_con",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "rad_of_con", 1))
           return Value();
         return rad_of_con(a[0]);
       }},

      /* ===== VECTOR OPERATOR ===== */
      {"div",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "div", 1))
           return Value();
         return Div(a[0]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass) - see matrix_builtin.cpp for
  // the first fix of this kind and the full reasoning.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown calculus function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}