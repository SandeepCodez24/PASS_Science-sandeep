#pragma once

#include "../../core/value.h"

Value ddt(Value fx_plus, Value fx_minus, Value h);

Value pddt(Value fx_plus, Value fx_minus, Value h);

Value continuity(Value a);

Value grad(Value a);

Value Curl_Calc(Value a);

Value laplace(Value a);

Value green_integral(Value a);

Value stokes_integral(Value a);

Value taylor_series(Value x, Value terms);

Value rad_of_con(Value a);

Value Div(Value a);