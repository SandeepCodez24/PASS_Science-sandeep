#pragma once
// Numerical kernels of the calculus functions: pure functions of numbers (no
// Value, no printing, no NC calls), safe on any thread. The NC-facing
// functions that use them are registered in calculus_builtin.cpp (ddt, pddt,
// continuity, grad, laplace, green_integral, stokes_integral, rad_of_con) and
// calculus_fields.cpp (div, curl and the vector-field integrals).
//
// grad(@f, point)/green_integral(@P, @Q, ...)/taylor_series(@f, ...) stay as
// reserved calls in parser_factor.cpp (tryReservedFunctionValueCall); their
// grid forms - grad(Z), green_integral(P, Q, dx, dy) - are passed on to the
// registry here.

#include <vector>

#include "../support/ops_math.h"

namespace nc {
namespace ops {
namespace calc {

// d2y/dx2 of samples spaced h: central inside, second-order one-sided at
// the ends (4 points or more); 0 with fewer than 3 points.
Vec secondDiff(const Vec &y, double h);
// Second derivative of a grid along one axis (0 = x, 1 = y, 2 = z).
Grid gridSecondDiff(const Grid &g, int axis, double h);

// Radius of convergence of sum a_n (z - z0)^n from its coefficients, from
// the ratios rho_m = |a_m / a_n|^(1/(m-n)) of consecutive nonzero
// coefficients (the last 8): factorial-type ratios (rho ~ 1/m or ~ m) give
// inf or 0; otherwise a Domb-Sykes fit of rho against 1/m (quadratic with 4
// ratios or more) gives 1/R at 1/m = 0 - exact for a_n = (n + 1)^k R^-n with
// k = 0 or 1. NaN when fewer than two coefficients are nonzero.
double radiusOfConvergence(const CVec &a);

// Scalar potential f of a gradient field (components c[0..k-1] = df/dx,
// df/dy[, df/dz], grids of one shape, spacings h): f = 0 at the first grid
// point, integrated along the axes and averaged over every axis order.
Grid potentialOf(const std::vector<Grid> &c, const double h[3]);

// Double integral of samples on a 2-D grid (Simpson in each direction).
double integrate2(const Grid &g, double dx, double dy);
// Triple integral on a 3-D grid.
double integrate3(const Grid &g, double dx, double dy, double dz);

} // namespace calc
} // namespace ops
} // namespace nc
