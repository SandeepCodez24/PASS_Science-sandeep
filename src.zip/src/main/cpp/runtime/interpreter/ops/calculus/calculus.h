#pragma once

#include "../../core/value.h"

Value ddt(Value fx_plus, Value fx_minus, Value h);

Value pddt(Value fx_plus, Value fx_minus, Value h);

Value continuity(Value a);

// grad()/green_integral()/taylor_series() moved to parser_factor.cpp
// (evaluateExpr's ExprKind::Call case, reserved-name interception) - all
// three need Parser access to repeatedly call a user-supplied function
// reference (@name), which a plain free function here can't do. See that
// file's own comments on each for the full history (grad() here used to be
// a no-op identity function; green_integral() computed Q-P from two raw
// scalar samples with no mathematical justification; taylor_series() was
// hardcoded to only ever compute e^x's series).

Value Curl_Calc(Value a);

Value laplace(Value a);

Value stokes_integral(Value a);

Value rad_of_con(Value a);

Value Div(Value a);