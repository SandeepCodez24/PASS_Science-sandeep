#pragma once

#include <string>
#include <vector>

#include "../../core/value.h"

Value calculusBuiltin(const std::string &name, const std::vector<Value> &args);