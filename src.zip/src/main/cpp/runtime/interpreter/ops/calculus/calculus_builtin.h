#pragma once

// The calculus functions are registered in the ops registry
// (support/ops_registry.h): registerCalculus() in calculus_builtin.cpp and
// registerVectorCalculus() in calculus_fields.cpp. callBuiltin() reaches
// them through nc::ops::tryCall().
#include "../support/ops_registry.h"
