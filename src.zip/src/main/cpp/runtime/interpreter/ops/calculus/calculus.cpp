#include "calculus.h"
#include "../vector/vector.h"

#include <cmath>
#include <limits>
#include <vector>


/* =====================================================
   DERIVATIVE
   Central Difference

   f'(x) ≈ (f(x+h)-f(x-h))/(2h)
   ===================================================== */

Value ddt(Value fx_plus, Value fx_minus, Value h) {
  if (h.number == 0)
    return Value(0);

  return Value((fx_plus.number - fx_minus.number) / (2.0 * h.number));
}

/* =====================================================
   PARTIAL DERIVATIVE
   Central Difference Approximation
   ===================================================== */

Value pddt(Value fx_plus, Value fx_minus, Value h) {
  if (h.number == 0)
    return Value(0);

  return Value((fx_plus.number - fx_minus.number) / (2.0 * h.number));
}

/* =====================================================
   CONTINUITY CHECK

   Returns:
   1 -> finite
   0 -> NaN / Infinity
   ===================================================== */

Value continuity(Value a) {
  if (std::isnan(a.number))
    return Value(0);

  if (std::isinf(a.number))
    return Value(0);

  return Value(1);
}

/* =====================================================
   GRADIENT

   Input:
   [df/dx,df/dy,df/dz]

   Returns same vector.
   ===================================================== */

Value grad(Value a) {
  if (!a.isArray)
    return Value(0);

  return a;
}

/* =====================================================
   CURL

   Uses vector module.
   ===================================================== */

Value Curl_Calc(Value a) { return Curl(a); }

/* =====================================================
   LAPLACIAN

   Input:
   [d²f/dx²,d²f/dy²,d²f/dz²]

   ∇²f = sum of second derivatives
   ===================================================== */

Value laplace(Value a) {
  if (!a.isArray)
    return Value(0);

  if (a.array.empty())
    return Value(0);

  double sum = 0;

  for (const auto &x : a.array)
    sum += x.number;

  return Value(sum);
}

/* =====================================================
   GREEN'S THEOREM APPROXIMATION

   Input:
   [P,Q]

   Approximation:
   ∂Q/∂x − ∂P/∂y

   Since symbolic differentiation
   is unavailable, we estimate
   using supplied values.
   ===================================================== */

Value green_integral(Value a) {
  if (!a.isArray)
    return Value(0);

  if (a.array.size() != 2)
    return Value(0);

  double P = a.array[0].number;
  double Q = a.array[1].number;

  return Value(Q - P);
}

/* =====================================================
   STOKES THEOREM APPROXIMATION

   Uses curl(F)

   Input:
   [Fx,Fy,Fz]
   ===================================================== */

Value stokes_integral(Value a) { return Curl(a); }

/* =====================================================
   TAYLOR SERIES

   e^x approximation

   Taylor_series(x,n)

   x = value
   n = number of terms
   ===================================================== */

Value taylor_series(Value x, Value terms) {
  int n = static_cast<int>(terms.number);

  if (n <= 0)
    return Value(0);

  double result = 0;

  for (int i = 0; i < n; i++) {
    double fact = 1;

    for (int j = 2; j <= i; j++)
      fact *= j;

    result += std::pow(x.number, i) / fact;
  }

  return Value(result);
}

/* =====================================================
   RADIUS OF CONVERGENCE

   Ratio Test

   Input:
   [a0,a1,a2,...]

   R ≈ |a_n / a_(n+1)|

   Uses last two coefficients.
   ===================================================== */

Value rad_of_con(Value a) {
  if (!a.isArray)
    return Value(0);

  int n = static_cast<int>(a.array.size());

  if (n < 2)
    return Value(0);

  double an = std::abs(a.array[n - 1].number);

  double an1 = std::abs(a.array[n - 2].number);

  if (an == 0)
    return Value(0);

  return Value(an1 / an);
}

/* =====================================================
   DIVERGENCE

   Uses vector package

   Input:
   [Fx,Fy,Fz]
   ===================================================== */

Value Div(Value a) { return divergence(a); }