#include "calculus.h"

#include <array>
#include <cmath>

namespace nc {
namespace ops {
namespace calc {

static void secondLine(const double *y, double *d, size_t n, size_t stride, double h) {
  const double h2 = h * h;
  if (n < 3) {
    for (size_t i = 0; i < n; i++)
      d[i * stride] = 0.0;
    return;
  }
  for (size_t i = 1; i + 1 < n; i++)
    d[i * stride] = (y[(i + 1) * stride] - 2.0 * y[i * stride] + y[(i - 1) * stride]) / h2;
  if (n == 3) {
    d[0] = d[stride];
    d[2 * stride] = d[stride];
    return;
  }
  const size_t L = (n - 1) * stride;
  d[0] = (2.0 * y[0] - 5.0 * y[stride] + 4.0 * y[2 * stride] - y[3 * stride]) / h2;
  d[L] = (2.0 * y[L] - 5.0 * y[L - stride] + 4.0 * y[L - 2 * stride] - y[L - 3 * stride]) / h2;
}

Vec secondDiff(const Vec &y, double h) {
  Vec d(y.size(), 0.0);
  if (!y.empty())
    secondLine(y.data(), d.data(), y.size(), 1, h);
  return d;
}

Grid gridSecondDiff(const Grid &g, int axis, double h) {
  Grid d(g.nz, g.ny, g.nx, g.rank);
  const size_t n = axis == 0 ? g.nx : axis == 1 ? g.ny : g.nz;
  const size_t stride = axis == 0 ? 1 : axis == 1 ? g.nx : g.ny * g.nx;
  const size_t lines = g.size() / (n ? n : 1);
  par::forBlocks(lines, {par::Kind::Stream, 4.0 * static_cast<double>(n)},
                 [&](size_t b, size_t e) {
                   for (size_t L = b; L < e; L++) {
                     size_t start;
                     if (axis == 0)
                       start = L * g.nx;
                     else if (axis == 1)
                       start = (L / g.nx) * g.ny * g.nx + (L % g.nx);
                     else
                       start = L;
                     secondLine(g.a.data() + start, d.a.data() + start, n, stride, h);
                   }
                 });
  return d;
}

double radiusOfConvergence(const CVec &a) {
  std::vector<size_t> nz;
  for (size_t i = 0; i < a.size(); i++)
    if (std::abs(a[i]) > 0.0 && isFiniteC(a[i]))
      nz.push_back(i);
  if (nz.size() < 2)
    return kNaN;
  // Points (1/m, rho_m) for consecutive nonzero indices n < m.
  Vec xs, ys;
  for (size_t k = 1; k < nz.size(); k++) {
    const double n = static_cast<double>(nz[k - 1]), m = static_cast<double>(nz[k]);
    const double rho = std::pow(std::abs(a[nz[k]]) / std::abs(a[nz[k - 1]]), 1.0 / (m - n));
    xs.push_back(1.0 / m);
    ys.push_back(rho);
  }
  // The tail decides convergence: the last 8 ratios at most.
  const size_t first = xs.size() > 8 ? xs.size() - 8 : 0;
  const size_t cnt = xs.size() - first;
  // Factorial-type coefficients: rho_m ~ m^p with p near -1 (1/n!: entire,
  // R = inf) or +1 (n!: R = 0). Slope of log rho against log m.
  if (cnt >= 3) {
    double sx = 0, sy = 0, sxx = 0, sxy = 0;
    for (size_t i = first; i < xs.size(); i++) {
      const double lx = -std::log(xs[i]), ly = std::log(ys[i]);
      sx += lx, sy += ly, sxx += lx * lx, sxy += lx * ly;
    }
    const double n = static_cast<double>(cnt), den = n * sxx - sx * sx;
    const double p = den > 0.0 ? (n * sxy - sx * sy) / den : 0.0;
    if (p < -0.5)
      return kInf;
    if (p > 0.5)
      return 0.0;
  }
  // Least squares rho = c0 + c1 x (+ c2 x^2 with 4 points or more), x = 1/m;
  // the limit c0 = 1/R.
  const size_t deg = cnt >= 4 ? 2 : (cnt >= 2 ? 1 : 0);
  double limit;
  if (deg == 0) {
    limit = ys.back();
  } else {
    // normal equations of the polynomial fit, solved by elimination
    double M[3][4] = {{0}};
    for (size_t i = first; i < xs.size(); i++) {
      double pw[5] = {1, xs[i], xs[i] * xs[i], 0, 0};
      pw[3] = pw[2] * xs[i];
      pw[4] = pw[3] * xs[i];
      for (size_t r = 0; r <= deg; r++) {
        for (size_t c = 0; c <= deg; c++)
          M[r][c] += pw[r + c];
        M[r][3] += pw[r] * ys[i];
      }
    }
    for (size_t k = 0; k <= deg; k++)
      for (size_t r = k + 1; r <= deg; r++) {
        const double f = M[r][k] / M[k][k];
        for (size_t c = k; c < 4; c++)
          M[r][c] -= f * M[k][c];
      }
    double coef[3] = {0, 0, 0};
    for (size_t k = deg + 1; k-- > 0;) {
      double s = M[k][3];
      for (size_t c = k + 1; c <= deg; c++)
        s -= M[k][c] * coef[c];
      coef[k] = s / M[k][k];
    }
    limit = coef[0];
  }
  // A limit at rounding level of the last ratio means the series is entire.
  const double scale = ys.back();
  if (limit <= 1e-9 * (scale > 1.0 ? scale : 1.0))
    return kInf;
  return 1.0 / limit;
}

// Cumulative integral along one axis of a grid with spacing h.
static Grid cumAlong(const Grid &g, int axis, double h) {
  Grid out(g.nz, g.ny, g.nx, g.rank);
  const size_t n = axis == 0 ? g.nx : axis == 1 ? g.ny : g.nz;
  const size_t stride = axis == 0 ? 1 : axis == 1 ? g.nx : g.ny * g.nx;
  Vec x(n);
  for (size_t t = 0; t < n; t++)
    x[t] = static_cast<double>(t) * h;
  const size_t lines = g.size() / n;
  par::forBlocks(lines, {par::Kind::Stream, 10.0 * static_cast<double>(n)},
                 [&](size_t b, size_t e) {
                   Vec y(n);
                   for (size_t L = b; L < e; L++) {
                     size_t start;
                     if (axis == 0)
                       start = L * g.nx;
                     else if (axis == 1)
                       start = (L / g.nx) * g.ny * g.nx + (L % g.nx);
                     else
                       start = L;
                     for (size_t t = 0; t < n; t++)
                       y[t] = g.a[start + t * stride];
                     const Vec c = cumIntegrate(y, x);
                     for (size_t t = 0; t < n; t++)
                       out.a[start + t * stride] = c[t];
                   }
                 });
  return out;
}

Grid potentialOf(const std::vector<Grid> &c, const double h[3]) {
  // Integrate along each axis from the first grid point; f(origin) = 0.
  // The result is the mean over every order of the axes, so a small
  // non-conservative part is not pushed into one direction.
  const size_t k = c.size();
  std::vector<Grid> cum;
  for (size_t ax = 0; ax < k; ax++)
    cum.push_back(cumAlong(c[ax], static_cast<int>(ax), h[ax]));
  const Grid &g0 = c[0];
  Grid f(g0.nz, g0.ny, g0.nx, g0.rank);
  const std::vector<std::array<int, 3>> orders =
      k == 2 ? std::vector<std::array<int, 3>>{{0, 1, 2}, {1, 0, 2}}
             : std::vector<std::array<int, 3>>{{0, 1, 2}, {0, 2, 1}, {1, 0, 2},
                                               {1, 2, 0}, {2, 0, 1}, {2, 1, 0}};
  for (size_t kk = 0; kk < g0.nz; kk++)
    for (size_t i = 0; i < g0.ny; i++)
      for (size_t j = 0; j < g0.nx; j++) {
        const size_t idx[3] = {j, i, kk}; // per axis x, y, z
        double sum = 0.0;
        for (const auto &o : orders) {
          // first axis o[0] with the others at 0, then o[1] with o[2] at 0, then o[2]
          size_t at[3] = {0, 0, 0};
          for (size_t s = 0; s < k; s++) {
            at[o[s]] = idx[o[s]];
            sum += cum[o[s]].at(at[2], at[1], at[0]);
          }
        }
        f.at(kk, i, j) = sum / static_cast<double>(orders.size());
      }
  return f;
}

double integrate2(const Grid &g, double dx, double dy) {
  Vec rows(g.ny);
  for (size_t i = 0; i < g.ny; i++)
    rows[i] = integrateUniform(&g.a[i * g.nx], g.nx, 1, dx);
  return integrateUniform(rows.data(), g.ny, 1, dy);
}

double integrate3(const Grid &g, double dx, double dy, double dz) {
  Vec pages(g.nz);
  par::forBlocks(g.nz, {par::Kind::Task, 0.0}, [&](size_t b, size_t e) {
    for (size_t k = b; k < e; k++) {
      Vec rows(g.ny);
      for (size_t i = 0; i < g.ny; i++)
        rows[i] = integrateUniform(&g.a[(k * g.ny + i) * g.nx], g.nx, 1, dx);
      pages[k] = integrateUniform(rows.data(), g.ny, 1, dy);
    }
  });
  return integrateUniform(pages.data(), g.nz, 1, dz);
}

} // namespace calc
} // namespace ops
} // namespace nc
