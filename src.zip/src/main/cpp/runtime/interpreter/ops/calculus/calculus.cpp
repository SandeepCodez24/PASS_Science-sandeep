#include "calculus.h"
#include "../vector/vector.h"

#include <cmath>
#include <limits>
#include <vector>


/* =====================================================
   DERIVATIVE
   Central Difference

   f'(x) ≈ (f(x+h)-f(x-h))/(2h)
   ===================================================== */

Value ddt(Value fx_plus, Value fx_minus, Value h) {
  if (h.number == 0)
    return Value(0);

  return Value((fx_plus.number - fx_minus.number) / (2.0 * h.number));
}

/* =====================================================
   PARTIAL DERIVATIVE
   Central Difference Approximation
   ===================================================== */

Value pddt(Value fx_plus, Value fx_minus, Value h) {
  if (h.number == 0)
    return Value(0);

  return Value((fx_plus.number - fx_minus.number) / (2.0 * h.number));
}

/* =====================================================
   CONTINUITY CHECK

   Returns:
   1 -> finite
   0 -> NaN / Infinity
   ===================================================== */

Value continuity(Value a) {
  if (std::isnan(a.number))
    return Value(0);

  if (std::isinf(a.number))
    return Value(0);

  return Value(1);
}

// grad() moved to parser_factor.cpp - see calculus.h's comment for why.

/* =====================================================
   CURL

   Uses vector module.
   ===================================================== */

// Intentional alias, not a separate implementation: exposes vector.cpp's
// Curl() under the calculus domain's name so "curl_calc" and "curl" can
// both be registered in builtins.cpp without colliding.
Value Curl_Calc(Value a) { return Curl(a); }

/* =====================================================
   LAPLACIAN

   Input:
   [d²f/dx²,d²f/dy²,d²f/dz²]

   ∇²f = sum of second derivatives
   ===================================================== */

Value laplace(Value a) {
  if (!a.isArray)
    return Value(0);

  if (a.length() == 0)
    return Value(0);

  double sum = 0;

  for (const auto &x : a.elems())
    sum += x.number;

  return Value(sum);
}

// green_integral() moved to parser_factor.cpp - see calculus.h's comment
// for why.

/* =====================================================
   STOKES THEOREM APPROXIMATION

   Uses curl(F)

   Input:
   [Fx,Fy,Fz]
   ===================================================== */

Value stokes_integral(Value a) { return Curl(a); }

// taylor_series() moved to parser_factor.cpp - see calculus.h's comment
// for why.

/* =====================================================
   RADIUS OF CONVERGENCE

   Ratio Test

   Input:
   [a0,a1,a2,...]

   R ≈ |a_n / a_(n+1)|

   Uses last two coefficients.
   ===================================================== */

Value rad_of_con(Value a) {
  if (!a.isArray)
    return Value(0);

  int n = static_cast<int>(a.length());

  if (n < 2)
    return Value(0);

  double an = std::abs(a.numAt(n - 1));

  double an1 = std::abs(a.numAt(n - 2));

  if (an == 0)
    return Value(0);

  return Value(an1 / an);
}

/* =====================================================
   DIVERGENCE

   Uses vector package

   Input:
   [Fx,Fy,Fz]
   ===================================================== */

// Intentional alias, not a separate implementation (same reasoning as
// Curl_Calc above): exposes vector.cpp's divergence() under the calculus
// domain's "div" name so it can be registered alongside "divergence"
// without colliding in builtins.cpp.
Value Div(Value a) { return divergence(a); }