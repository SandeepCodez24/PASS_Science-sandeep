// Calendar functions on timestamps - ranges of dates and business days.
//
//   date_range(start, stop[, step])          start, start+step, ... up to (not
//                                            including) stop; step = days(1)
//   is_busday(t[, weekmask][, zone][, holidays])     true on a business day
//   busday_count(begin, end[, ...])          business days from begin up to
//                                            (not including) end; negative
//                                            when end is before begin
//   busday_offset(t, n[, roll][, ...])       the business day n business days
//                                            after t (before, for n < 0)
//
// A "day" is a calendar day in a time zone (the computer's own unless `zone`
// names one), so the same timestamp can be a Friday in New York and a
// Saturday in Tokyo.
//
// weekmask says which weekdays are business days, Monday first:
//   "1111100"                 Monday-Friday (the default)
//   "Sun Mon Tue Wed Thu"     day names (or "Sunday ..."), any order
// so every country's working week can be written - e.g. a Sunday-Thursday
// week is "1111001" or "Sun Mon Tue Wed Thu".
//
// holidays: timestamps (or ISO date text, "2026-12-25") of days that are
// never business days; only their calendar day (in `zone`) counts.
//
// roll (busday_offset) - what to do when t itself is not a business day:
//   "raise"              an error (the default, as in NumPy)
//   "forward"            the next business day        (also "following")
//   "backward"           the previous business day    (also "preceding")
//   "modifiedfollowing"  forward, unless that leaves the month - then backward
//   "modifiedpreceding"  backward, unless that leaves the month - then forward
//
// busday_offset gives the START (00:00:00 local) of the business day it
// lands on - a business day is a date, as in NumPy.
#include "time_calendar.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <set>
#include <string>

#include "time.h"
#include "time_cells.h"

namespace nctime {

namespace {

using cells::mapCells;

// Monday = 0 ... Sunday = 6. Day 0 (1970-01-01) was a Thursday.
int weekdayOf(int64_t day) {
  int64_t w = (day + 3) % 7;
  return static_cast<int>(w < 0 ? w + 7 : w);
}

const char *const kDayNames[7] = {"Monday", "Tuesday",  "Wednesday", "Thursday",
                                  "Friday", "Saturday", "Sunday"};

struct Calendar {
  bool mask[7] = {true, true, true, true, true, false, false};
  std::set<int64_t> holidays; // local day numbers
  const TimeZone *zone = nullptr;
  int perWeek() const { return static_cast<int>(std::count(mask, mask + 7, true)); }
  bool isBusiness(int64_t day) const { return mask[weekdayOf(day)] && !holidays.count(day); }
};

std::string lower(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}

bool parseWeekmask(const Value &v, bool (&mask)[7], std::string &err) {
  const std::string usage = " - write 7 digits Monday to Sunday, e.g. \"1111100\", or day names, "
                            "e.g. \"Mon Tue Wed Thu Fri\"";
  if (!v.isText) {
    err = "weekmask must be text" + usage;
    return false;
  }
  const std::string s = v.text();
  bool digits = s.size() == 7;
  for (char c : s)
    digits = digits && (c == '0' || c == '1');
  if (digits) {
    for (int i = 0; i < 7; i++)
      mask[i] = s[static_cast<size_t>(i)] == '1';
  } else if (!s.empty() && s.find_first_not_of("01") == std::string::npos) {
    err = "invalid weekmask \"" + s + "\" - it needs exactly 7 digits, Monday to Sunday, e.g. "
          "\"1111100\"";
    return false;
  } else {
    std::fill(mask, mask + 7, false);
    std::string word;
    bool any = false;
    for (size_t i = 0; i <= s.size(); i++) {
      const char c = i < s.size() ? s[i] : ' ';
      if (c == ' ' || c == ',' || c == '\t') {
        if (word.empty())
          continue;
        const std::string w = lower(word);
        int found = -1;
        for (int d = 0; d < 7; d++) {
          const std::string full = lower(kDayNames[d]);
          if (w == full || w == full.substr(0, 3))
            found = d;
        }
        if (found < 0) {
          err = "invalid weekmask \"" + s + "\" ('" + word + "' is not a day)" + usage;
          return false;
        }
        mask[found] = true;
        any = true;
        word.clear();
      } else {
        word += c;
      }
    }
    if (!any) {
      err = "invalid weekmask \"" + s + "\"" + usage;
      return false;
    }
  }
  if (std::count(mask, mask + 7, true) == 0) {
    err = "the weekmask has no business days";
    return false;
  }
  return true;
}

// args[first] = weekmask, args[first+1] = zone, args[first+2] = holidays (optional).
bool readCalendar(const std::vector<Value> &args, size_t first, Calendar &cal, std::string &err) {
  if (args.size() > first && !parseWeekmask(args[first], cal.mask, err))
    return false;
  std::string zoneName;
  if (args.size() > first + 1) {
    if (!args[first + 1].isText) {
      err = "zone must be a time zone name in quotes, e.g. zone=\"UTC\"";
      return false;
    }
    zoneName = args[first + 1].text();
  }
  if (!findZone(zoneName, cal.zone, err))
    return false;
  if (args.size() > first + 2) {
    std::vector<Value> elems;
    if (!cells::elementsOf(args[first + 2], "holidays", elems, err))
      return false;
    for (const Value &h : elems) {
      int64_t ns = 0;
      if (h.isTimestamp()) {
        ns = h.timeNs();
      } else if (h.isText) {
        if (!parseTimestamp(h.text(), cal.zone, ns, err))
          return false;
      } else {
        err = "holidays must be timestamps or dates as text, e.g. holidays=[\"2026-12-25\", "
              "\"2026-12-26\"]";
        return false;
      }
      cal.holidays.insert(localDayNumber(ns, cal.zone));
    }
  }
  return true;
}

bool timestampElement(const std::string &fn, const Value &v, std::string &err) {
  if (!v.isTimestamp()) {
    err = fn + " expects a timestamp, got " + typeName(v) +
          (v.isText ? " - convert it first with to_timestamp(\"" + v.text() + "\")" : "");
    return false;
  }
  return true;
}

// Business days in [d0, d1), d0 <= d1.
int64_t countForward(const Calendar &cal, int64_t d0, int64_t d1) {
  const int64_t n = d1 - d0;
  int64_t count = (n / 7) * cal.perWeek();
  for (int64_t d = d0 + (n / 7) * 7; d < d1; d++)
    count += cal.mask[weekdayOf(d)] ? 1 : 0;
  for (int64_t h : cal.holidays)
    if (h >= d0 && h < d1 && cal.mask[weekdayOf(h)])
      count--;
  return count;
}

unsigned monthOf(int64_t day) {
  int64_t y = 0;
  unsigned m = 0, d = 0;
  civilFromDays(day, y, m, d);
  return m;
}

std::string dateText(int64_t day) {
  int64_t y = 0;
  unsigned m = 0, d = 0;
  civilFromDays(day, y, m, d);
  char buf[32];
  std::snprintf(buf, sizeof buf, "%04lld-%02u-%02u", static_cast<long long>(y), m, d);
  return buf;
}

// The next (step = +1) or previous (-1) business day from `day` (itself
// counts when `includeSelf`).
bool stepToBusiness(const Calendar &cal, int64_t &day, int step, bool includeSelf,
                    std::string &err) {
  if (!includeSelf)
    day += step;
  for (int guard = 0; !cal.isBusiness(day); guard++) {
    if (guard > 400000) { // every day a holiday for centuries
      err = kRangeError;
      return false;
    }
    day += step;
  }
  return true;
}

Value fail(const std::string &err) {
  reportTimeError(err);
  return Value(0.0);
}

} // namespace

Value dateRange(const std::vector<Value> &args) {
  const char *usage = "usage: date_range(start, stop[, step]) - e.g. "
                      "date_range(timestamp(2026, 1, 1), timestamp(2026, 2, 1), days(7))";
  if (args.size() < 2 || args.size() > 3)
    return fail(usage);
  if (!args[0].isTimestamp() || !args[1].isTimestamp())
    return fail(std::string("date_range expects two timestamps (start, stop) - ") + usage);
  const int64_t start = args[0].timeNs(), stop = args[1].timeNs();
  int64_t step = kNsPerDay;
  if (args.size() == 3) {
    if (!args[2].isDuration())
      return fail("date_range: step must be a duration, e.g. days(1) or hours(6), got " +
                  typeName(args[2]));
    step = args[2].timeNs();
    if (step == 0)
      return fail("date_range: step must not be zero");
  }
  int64_t span = 0;
  if (__builtin_sub_overflow(stop, start, &span))
    return fail(kRangeError);
  if ((span > 0) != (step > 0) || span == 0)
    return Value(std::vector<std::vector<Value>>{}); // nothing between them
  const uint64_t aspan = span < 0 ? 0 - static_cast<uint64_t>(span) : static_cast<uint64_t>(span);
  const uint64_t astep = step < 0 ? 0 - static_cast<uint64_t>(step) : static_cast<uint64_t>(step);
  const uint64_t count = (aspan + astep - 1) / astep; // stop not included
  if (count > 10000000)
    return fail("date_range would make " + std::to_string(count) +
                " timestamps - use a larger step (at most 10,000,000)");
  std::vector<Value> row;
  row.reserve(static_cast<size_t>(count));
  int64_t t = start;
  for (uint64_t i = 0; i < count; i++) {
    row.push_back(Value::timestamp(t));
    if (i + 1 < count && __builtin_add_overflow(t, step, &t))
      return fail(kRangeError);
  }
  return Value(std::vector<std::vector<Value>>{std::move(row)});
}

Value isBusday(const std::vector<Value> &args) {
  if (args.empty())
    return fail("usage: is_busday(t[, weekmask][, zone][, holidays])");
  Calendar cal;
  std::string err;
  if (!readCalendar(args, 1, cal, err))
    return fail(err);
  Value out;
  const bool ok = mapCells(
      "is_busday", {&args[0]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!timestampElement("is_busday", e[0], er))
          return false;
        r = Value::boolean(cal.isBusiness(localDayNumber(e[0].timeNs(), cal.zone)));
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

Value busdayCount(const std::vector<Value> &args) {
  if (args.size() < 2)
    return fail("usage: busday_count(begin, end[, weekmask][, zone][, holidays])");
  Calendar cal;
  std::string err;
  if (!readCalendar(args, 2, cal, err))
    return fail(err);
  Value out;
  const bool ok = mapCells(
      "busday_count", {&args[0], &args[1]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!timestampElement("busday_count", e[0], er) ||
            !timestampElement("busday_count", e[1], er))
          return false;
        const int64_t d0 = localDayNumber(e[0].timeNs(), cal.zone);
        const int64_t d1 = localDayNumber(e[1].timeNs(), cal.zone);
        const int64_t n = d0 <= d1 ? countForward(cal, d0, d1) : -countForward(cal, d1, d0);
        r = Value(static_cast<double>(n));
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

Value busdayOffset(const std::vector<Value> &args) {
  if (args.size() < 2)
    return fail("usage: busday_offset(t, n[, roll][, weekmask][, zone][, holidays])");
  std::string roll = "raise";
  if (args.size() > 2) {
    if (!args[2].isText)
      return fail("roll must be text: \"raise\", \"forward\", \"backward\", "
                  "\"modifiedfollowing\" or \"modifiedpreceding\"");
    roll = lower(args[2].text());
  }
  if (roll == "following")
    roll = "forward";
  if (roll == "preceding")
    roll = "backward";
  if (roll != "raise" && roll != "forward" && roll != "backward" && roll != "modifiedfollowing" &&
      roll != "modifiedpreceding")
    return fail("unknown roll \"" + args[2].text() +
                "\" - use \"raise\", \"forward\", \"backward\", \"modifiedfollowing\" or "
                "\"modifiedpreceding\"");
  Calendar cal;
  std::string err;
  if (!readCalendar(args, 3, cal, err))
    return fail(err);
  Value out;
  const bool ok = mapCells(
      "busday_offset", {&args[0], &args[1]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!timestampElement("busday_offset", e[0], er))
          return false;
        const Value &nv = e[1];
        if (nv.isText || nv.isTime() || nv.isComplex || !std::isfinite(nv.number) ||
            nv.number != std::floor(nv.number) || std::fabs(nv.number) > 400000) {
          er = "busday_offset: n must be a whole number of business days, e.g. 5 or -2";
          return false;
        }
        int64_t day = localDayNumber(e[0].timeNs(), cal.zone);
        if (!cal.isBusiness(day)) {
          const int64_t original = day;
          if (roll == "raise") {
            er = dateText(day) + " is not a business day (" + kDayNames[weekdayOf(day)] +
                 (cal.holidays.count(day) ? ", a holiday" : "") +
                 ") - give roll=\"forward\" or roll=\"backward\"";
            return false;
          }
          const bool forward = roll == "forward" || roll == "modifiedfollowing";
          if (!stepToBusiness(cal, day, forward ? 1 : -1, true, er))
            return false;
          if ((roll == "modifiedfollowing" || roll == "modifiedpreceding") &&
              monthOf(day) != monthOf(original)) {
            day = original;
            if (!stepToBusiness(cal, day, forward ? -1 : 1, true, er))
              return false;
          }
        }
        const long long n = static_cast<long long>(nv.number);
        for (long long k = 0; k < (n < 0 ? -n : n); k++)
          if (!stepToBusiness(cal, day, n < 0 ? -1 : 1, false, er))
            return false;
        int64_t ns = 0;
        if (!localDayStart(day, cal.zone, ns, er))
          return false;
        r = Value::timestamp(ns);
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

} // namespace nctime
