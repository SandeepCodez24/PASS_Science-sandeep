#!/usr/bin/env python3
"""Writes a table of time-zone answers from Python's own zoneinfo module, an
implementation independent of nc's, for compiler/tests/time_zone_tests.cpp:

    python make_time_zone_oracle.py oracle.txt
    nc_time_tests oracle.txt

For every zone: instants around each year's offset changes and a spread of other
instants from 1678 to 2261, and local times around the same changes.
"""
import datetime as dt
import random
import sys
import zoneinfo

EPOCH = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)
LOCAL_EPOCH = dt.datetime(1970, 1, 1)
FIRST = int((dt.datetime(1678, 1, 1, tzinfo=dt.timezone.utc) - EPOCH).total_seconds())
LAST = int((dt.datetime(2261, 12, 31, tzinfo=dt.timezone.utc) - EPOCH).total_seconds())


def offset_at(zone, utc):
    return int((EPOCH + dt.timedelta(seconds=utc)).astimezone(zone).utcoffset().total_seconds())


def changes(zone, begin, end, step):
    """Offset changes in [begin, end], each found exactly by bisection."""
    found = []
    t = begin
    before = offset_at(zone, t)
    while t < end:
        nxt = min(t + step, end)
        after = offset_at(zone, nxt)
        if after != before:
            lo, hi = t, nxt
            while hi - lo > 1:
                mid = (lo + hi) // 2
                if offset_at(zone, mid) == before:
                    lo = mid
                else:
                    hi = mid
            found.append((hi, before, offset_at(zone, hi)))
            t, before = hi, offset_at(zone, hi)
        else:
            t = nxt
    return found


def local_line(zone, name, local):
    naive = LOCAL_EPOCH + dt.timedelta(seconds=local)
    first = int(naive.replace(tzinfo=zone, fold=0).utcoffset().total_seconds())
    second = int(naive.replace(tzinfo=zone, fold=1).utcoffset().total_seconds())
    if first == second:
        return "local %s %d U %d 0" % (name, local, first)
    # PEP 495: inside a gap fold=0 gives the offset BEFORE the change, which is
    # the smaller one; inside an overlap it gives the larger one.
    return "local %s %d %s %d %d" % (name, local, "G" if first < second else "O", first, second)


def main():
    rng = random.Random(20261101)
    with open(sys.argv[1], "w", encoding="ascii", newline="\n") as out:
        for name in sorted(zoneinfo.available_timezones()):
            if name.startswith(("build/", "localtime", "Factory")):
                continue
            zone = zoneinfo.ZoneInfo(name)
            for _ in range(150):
                t = rng.randint(FIRST, LAST)
                out.write("utc %s %d %d\n" % (name, t, offset_at(zone, t)))
            # Weekly steps find every change that lasts over a week; the tiny
            # stretches some zones had historically are covered by the spread.
            begin = int((dt.datetime(1850, 1, 1, tzinfo=dt.timezone.utc) - EPOCH).total_seconds())
            end = int((dt.datetime(2045, 1, 1, tzinfo=dt.timezone.utc) - EPOCH).total_seconds())
            found = changes(zone, begin, end, 7 * 86400)
            late = changes(zone, LAST - 370 * 86400, LAST, 7 * 86400)
            for when, before, after in found + late:
                for t in (when - 1, when):
                    out.write("utc %s %d %d\n" % (name, t, offset_at(zone, t)))
                for local in (when + min(before, after) - 1, when + min(before, after),
                              when + (before + after) // 2, when + max(before, after) - 1,
                              when + max(before, after)):
                    out.write(local_line(zone, name, local) + "\n")


if __name__ == "__main__":
    main()
