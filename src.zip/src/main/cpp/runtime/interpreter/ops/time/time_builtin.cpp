// NC entry points of the date/time module - see time.h for the model.
//
//   creating          get_timestamp()  today([zone])  timestamp(y, mo, d[, h, mi, s][, zone])
//                     to_timestamp(text[, zone])
//   durations         seconds(n)  minutes(n)  hours(n)  days(n)
//   parts             get_time(t[, zone]) -> [h, m, s]    get_date(t[, zone]) -> [y, mo, d]
//                     set_time(t, h, m, s[, zone])        set_date(t, y, mo, d[, zone])
//   text              format_time(t[, pattern[, zone]])   format_duration(d)
//   converting        in_seconds(d)  in_minutes(d)  in_hours(d)  in_days(d)
//                     in_hms(d) -> [h, m, s]  (alias in_hrs_min_sec)
//   stopwatch         tic()  toc() -> duration   (one global stopwatch, monotonic clock)
//   calendar          date_range(start, stop[, step])   is_busday(t, ...)
//                     busday_count(begin, end, ...)     busday_offset(t, n, ...)
//                     (time_calendar.cpp)
//
// Every function works element by element on a matrix and keeps its shape,
// except get_time / get_date / in_hms, which give one row [a, b, c] per
// element (N elements -> N x 3, taken row by row).
#include "time_builtin.h"

#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <functional>
#include <limits>
#include <unordered_set>

#include "time.h"
#include "time_calendar.h"
#include "time_cells.h"

using namespace nctime;
using nctime::cells::mapCells;

namespace {

bool isNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
         !v.isFunctionRef && !v.isComplex && !v.isTime();
}

// An element that must be a plain number.
bool numberArg(const std::string &fn, const Value &v, double &out, std::string &err) {
  if (!isNumber(v)) {
    err = fn + " expects a number, got " + typeName(v);
    return false;
  }
  out = v.number;
  return true;
}

bool timestampArg(const std::string &fn, const Value &v, std::string &err) {
  if (!v.isTimestamp()) {
    err = fn + " expects a timestamp, got " + typeName(v);
    return false;
  }
  return true;
}

bool durationArg(const std::string &fn, const Value &v, std::string &err) {
  if (!v.isDuration()) {
    err = fn + " expects a duration, got " + typeName(v);
    return false;
  }
  return true;
}

Value fail(const std::string &err) {
  reportTimeError(err);
  return Value(0.0);
}

// Takes a trailing time-zone name off `args` (any text in the last place
// beyond `minArgs`) and finds it; "" = the computer's zone.
bool takeZone(std::vector<Value> &args, size_t minArgs, const TimeZone *&zone,
              std::string &err) {
  std::string name;
  if (args.size() > minArgs && args.back().isText) {
    name = args.back().text();
    args.pop_back();
  }
  return findZone(name, zone, err);
}

// One row of three numbers per element of `v` (N x 3, row by row): fn
// fills the three numbers of one element.
Value rowsOfThree(const std::string &fnName, const Value &v,
                  const std::function<bool(const Value &, double (&)[3], std::string &)> &fn) {
  std::vector<Value> elems;
  std::string err;
  if (!cells::elementsOf(v, fnName, elems, err))
    return fail(err);
  std::vector<std::vector<Value>> rows;
  rows.reserve(elems.size());
  for (const Value &e : elems) {
    double p[3] = {0, 0, 0};
    if (!fn(e, p, err))
      return fail(err);
    rows.push_back({Value(p[0]), Value(p[1]), Value(p[2])});
  }
  return Value(std::move(rows));
}

/* ---- creating ---- */

int64_t nowNs() {
  return std::chrono::time_point_cast<std::chrono::nanoseconds>(std::chrono::system_clock::now())
      .time_since_epoch()
      .count();
}

Value getTimestamp(const std::vector<Value> &args) {
  if (!args.empty())
    return fail("get_timestamp takes no arguments - usage: get_timestamp()");
  return Value::timestamp(nowNs());
}

// today([zone]): the start of today in that zone.
Value today(const std::vector<Value> &argsIn) {
  std::vector<Value> args = argsIn;
  const TimeZone *zone = nullptr;
  std::string err;
  if (args.size() > 1 || (args.size() == 1 && !args[0].isText))
    return fail("usage: today() or today(zone) - e.g. today(\"UTC\")");
  if (!takeZone(args, 0, zone, err))
    return fail(err);
  int64_t ns = 0;
  if (!startOfLocalDay(nowNs(), zone, ns, err))
    return fail(err);
  return Value::timestamp(ns);
}

// timestamp(y, mo, d[, h, mi, s][, zone])
Value makeTimestamp(const std::vector<Value> &argsIn) {
  std::vector<Value> args = argsIn;
  const TimeZone *zone = nullptr;
  std::string err;
  if (!takeZone(args, 0, zone, err))
    return fail(err);
  if (args.size() != 3 && args.size() != 6)
    return fail("timestamp expects 3 or 6 numbers and an optional time zone - usage: "
                "timestamp(year, month, day[, hour, minute, second][, zone]) - e.g. "
                "timestamp(2026, 10, 28, 14, 30, 0, \"UTC\")");
  std::vector<const Value *> inputs;
  for (const Value &a : args)
    inputs.push_back(&a);
  Value out;
  const bool ok = mapCells(
      "timestamp", inputs,
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        double p[6] = {0, 0, 0, 0, 0, 0};
        for (size_t i = 0; i < e.size(); i++)
          if (!numberArg("timestamp", e[i], p[i], er))
            return false;
        int64_t ns = 0;
        if (!fromLocalParts(p[0], p[1], p[2], p[3], p[4], p[5], zone, ns, er))
          return false;
        r = Value::timestamp(ns);
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

// to_timestamp(text[, zone])
Value toTimestamp(const std::vector<Value> &args) {
  if (args.empty() || args.size() > 2 || (args.size() == 2 && !args[1].isText))
    return fail("usage: to_timestamp(text[, zone]) - e.g. to_timestamp(\"2026-10-28 14:30:00\", "
                "\"UTC\")");
  const TimeZone *zone = nullptr;
  std::string err;
  if (!findZone(args.size() == 2 ? args[1].text() : "", zone, err))
    return fail(err);
  Value out;
  const bool ok = mapCells(
      "to_timestamp", {&args[0]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!e[0].isText) {
          er = "to_timestamp expects text, got " + typeName(e[0]);
          return false;
        }
        int64_t ns = 0;
        if (!parseTimestamp(e[0].text(), zone, ns, er))
          return false;
        r = Value::timestamp(ns);
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

// seconds(n) / minutes(n) / hours(n) / days(n)
Value makeDuration(const std::string &fn, int64_t unitNs, const std::vector<Value> &args) {
  if (args.size() != 1)
    return fail(fn + " expects one number (or a matrix of numbers) - e.g. " + fn + "(5)");
  Value out;
  std::string err;
  const bool ok = mapCells(
      fn, {&args[0]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        double n = 0.0;
        int64_t ns = 0;
        if (!numberArg(fn, e[0], n, er) || !durationFromNumber(n, unitNs, ns, er))
          return false;
        r = Value::duration(ns);
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

/* ---- parts ---- */

// get_time(t[, zone]) -> [h, m, s] / get_date(t[, zone]) -> [y, mo, d]
Value getParts(const std::string &fn, bool time, const std::vector<Value> &argsIn) {
  std::vector<Value> args = argsIn;
  const TimeZone *zone = nullptr;
  std::string err;
  if (!takeZone(args, 1, zone, err))
    return fail(err);
  if (args.size() != 1)
    return fail("usage: " + fn + "(t) or " + fn + "(t, zone)");
  return rowsOfThree(fn, args[0], [&](const Value &e, double (&p)[3], std::string &er) {
    if (!timestampArg(fn, e, er))
      return false;
    const LocalParts lp = toLocalParts(e.timeNs(), zone);
    if (time) {
      p[0] = lp.hour;
      p[1] = lp.minute;
      p[2] = lp.second + static_cast<double>(lp.nanos) / 1e9;
    } else {
      p[0] = lp.year;
      p[1] = lp.month;
      p[2] = lp.day;
    }
    return true;
  });
}

// set_time(t, h, m, s[, zone]) / set_date(t, y, mo, d[, zone]): a NEW
// timestamp - t itself (and the computer's clock) never change.
Value setParts(const std::string &fn, bool time, const std::vector<Value> &argsIn) {
  std::vector<Value> args = argsIn;
  const TimeZone *zone = nullptr;
  std::string err;
  if (!takeZone(args, 4, zone, err))
    return fail(err);
  if (args.size() != 4)
    return fail(std::string("usage: ") +
                (time ? "set_time(t, hour, minute, second[, zone])"
                      : "set_date(t, year, month, day[, zone])"));
  Value out;
  const bool ok = mapCells(
      fn, {&args[0], &args[1], &args[2], &args[3]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!timestampArg(fn, e[0], er))
          return false;
        double p[3] = {0, 0, 0};
        for (int i = 0; i < 3; i++)
          if (!numberArg(fn, e[i + 1], p[i], er))
            return false;
        const LocalParts lp = toLocalParts(e[0].timeNs(), zone);
        int64_t ns = 0;
        const bool built =
            time ? fromLocalParts(lp.year, lp.month, lp.day, p[0], p[1], p[2], zone, ns, er)
                 : fromLocalParts(p[0], p[1], p[2], lp.hour, lp.minute,
                                  lp.second + static_cast<double>(lp.nanos) / 1e9, zone, ns, er);
        if (!built)
          return false;
        r = Value::timestamp(ns);
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

// format_time(t[, pattern[, zone]])
Value formatTime(const std::vector<Value> &args) {
  if (args.empty() || args.size() > 3 || (args.size() >= 2 && !args[1].isText) ||
      (args.size() == 3 && !args[2].isText))
    return fail("usage: format_time(t[, pattern[, zone]]) - e.g. format_time(t, \"DD.MM.YYYY\", "
                "\"UTC\")");
  const std::string pattern = args.size() >= 2 ? args[1].text() : "YYYY-MM-DD hh:mm:ss";
  const TimeZone *zone = nullptr;
  std::string err;
  if (!findZone(args.size() == 3 ? args[2].text() : "", zone, err))
    return fail(err);
  Value out;
  const bool ok = mapCells(
      "format_time", {&args[0]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!timestampArg("format_time", e[0], er))
          return false;
        r = Value(formatTimestamp(e[0].timeNs(), pattern, zone));
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

/* ---- converting durations ---- */

// in_seconds / in_minutes / in_hours / in_days: whole units exactly, the
// rest as a fraction, so the result is as close as a float64 can be.
Value inUnits(const std::string &fn, int64_t unitNs, const std::vector<Value> &args) {
  if (args.size() != 1)
    return fail("usage: " + fn + "(d)");
  Value out;
  std::string err;
  const bool ok = mapCells(
      fn, {&args[0]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!durationArg(fn, e[0], er))
          return false;
        const int64_t ns = e[0].timeNs();
        r = Value(static_cast<double>(ns / unitNs) +
                  static_cast<double>(ns % unitNs) / static_cast<double>(unitNs));
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

// in_hms(d) -> [h, m, s]: h and m whole, s with its fraction; every part
// carries the sign of d, hours are not wrapped at 24.
Value inHms(const std::string &fn, const std::vector<Value> &args) {
  if (args.size() != 1)
    return fail("usage: " + fn + "(d)");
  return rowsOfThree(fn, args[0], [&](const Value &e, double (&p)[3], std::string &er) {
    if (!durationArg(fn, e, er))
      return false;
    const int64_t ns = e.timeNs();
    const uint64_t a = ns < 0 ? 0 - static_cast<uint64_t>(ns) : static_cast<uint64_t>(ns);
    const double sign = ns < 0 ? -1.0 : 1.0;
    const double h = static_cast<double>(a / kNsPerHour);
    const double m = static_cast<double>((a % kNsPerHour) / kNsPerMinute);
    const uint64_t restNs = a % kNsPerMinute;
    const double s = static_cast<double>(restNs / kNsPerSecond) +
                     static_cast<double>(restNs % kNsPerSecond) / 1e9;
    // A zero part stays 0 (not -0).
    p[0] = h == 0 ? 0.0 : sign * h;
    p[1] = m == 0 ? 0.0 : sign * m;
    p[2] = s == 0 ? 0.0 : sign * s;
    return true;
  });
}

Value formatDurationFn(const std::vector<Value> &args) {
  if (args.size() != 1)
    return fail("usage: format_duration(d)");
  Value out;
  std::string err;
  const bool ok = mapCells(
      "format_duration", {&args[0]},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!durationArg("format_duration", e[0], er))
          return false;
        r = Value(formatDuration(e[0].timeNs()));
        return true;
      },
      out, err);
  return ok ? out : fail(err);
}

/* ---- measuring elapsed time: one global stopwatch ----
   tic() starts (or restarts) it, toc() reads it without stopping it - call
   toc() as often as you like. It runs on the monotonic clock
   (std::chrono::steady_clock), which never jumps: changing the computer's
   clock, a time-server sync, daylight saving or the time zone has no effect
   on it, so it measures the same in every country. Its readings are not
   dates - only toc()'s duration comes out of it. */

constexpr int64_t kNotStarted = std::numeric_limits<int64_t>::min();
std::atomic<int64_t> g_ticNs{kNotStarted}; // steady_clock reading at the last tic()

int64_t steadyNowNs() {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
             std::chrono::steady_clock::now().time_since_epoch())
      .count();
}

// tic(): starts the stopwatch; gives back the wall-clock time it started
// (a timestamp, for the record - toc() does not need it).
Value tic(const std::vector<Value> &args) {
  if (!args.empty())
    return fail("tic takes no arguments - usage: tic() ... toc()");
  g_ticNs.store(steadyNowNs());
  return Value::timestamp(nowNs());
}

// toc(): the duration since the last tic().
Value toc(const std::vector<Value> &args) {
  if (!args.empty())
    return fail("toc takes no arguments - there is one stopwatch: tic() starts it, toc() "
                "reads it");
  const int64_t start = g_ticNs.load();
  if (start == kNotStarted)
    return fail("toc() called before tic()");
  return Value::duration(steadyNowNs() - start);
}

// "timestamp" / "duration" for the first time value in `v` (itself, or an
// element of it), "" when there is none.
std::string firstTimeType(const Value &v) {
  if (v.isTime())
    return typeName(v);
  if (v.isND()) {
    for (size_t k = 0; k < v.ndCount(); k++)
      if (v.ndAt(k).isTime())
        return typeName(v.ndAt(k));
  } else if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        if (v.at(r, c).isTime())
          return typeName(v.at(r, c));
  } else if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      if (v.at(i).isTime())
        return typeName(v.at(i));
  }
  return "";
}

} // namespace

Value timeBuiltin(const std::string &nameIn, const std::vector<Value> &args) {
  std::string name = nameIn;
  for (char &c : name)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (name == "get_timestamp")
    return getTimestamp(args);
  if (name == "tic")
    return tic(args);
  if (name == "toc")
    return toc(args);
  if (name == "today")
    return today(args);
  if (name == "timestamp")
    return makeTimestamp(args);
  if (name == "to_timestamp")
    return toTimestamp(args);
  if (name == "seconds")
    return makeDuration(name, kNsPerSecond, args);
  if (name == "minutes")
    return makeDuration(name, kNsPerMinute, args);
  if (name == "hours")
    return makeDuration(name, kNsPerHour, args);
  if (name == "days")
    return makeDuration(name, kNsPerDay, args);
  if (name == "get_time")
    return getParts(name, true, args);
  if (name == "get_date")
    return getParts(name, false, args);
  if (name == "set_time")
    return setParts(name, true, args);
  if (name == "set_date")
    return setParts(name, false, args);
  if (name == "format_time")
    return formatTime(args);
  if (name == "in_seconds")
    return inUnits(name, kNsPerSecond, args);
  if (name == "in_minutes")
    return inUnits(name, kNsPerMinute, args);
  if (name == "in_hours")
    return inUnits(name, kNsPerHour, args);
  if (name == "in_days")
    return inUnits(name, kNsPerDay, args);
  // in_hrs_min_sec is the same function under a second name.
  if (name == "in_hms" || name == "in_hrs_min_sec")
    return inHms(name, args);
  if (name == "format_duration")
    return formatDurationFn(args);
  if (name == "date_range")
    return dateRange(args);
  if (name == "is_busday")
    return isBusday(args);
  if (name == "busday_count")
    return busdayCount(args);
  if (name == "busday_offset")
    return busdayOffset(args);
  return fail("unknown time function '" + nameIn + "'");
}

namespace nctime {

TimeArgs timeArgsCall(const std::string &name, const std::vector<Value> &args, Value &out) {
  // Functions that only look at a value's shape or move its elements
  // around work on time values unchanged.
  static const std::unordered_set<std::string> shapeOnly = {
      "size", "numel", "length", "shape", "ndims", "isempty", "is_empty", "transpose",
      // NumPy joining / splitting (Numpy/combining_splitting/): they only move
      // elements, and the matrix type rules keep time values apart from numbers.
      "concat", "stack", "row_stack", "vstack", "column_stack", "hstack", "matrix_split",
      "vsplit", "hsplit",
      // NumPy inspecting (Numpy/inspecting_properties/): they read only the type / shape.
      "ndim", "is_scalar", "type", "is_type", "can_cast"};
  if (shapeOnly.count(name))
    return TimeArgs::PassThrough;

  if (name == "abs" && args.size() == 1) {
    std::string err;
    if (!timeAbs(args[0], out, err)) {
      reportTimeError(err);
      return TimeArgs::Refused;
    }
    return TimeArgs::Done;
  }
  // str(t): the text it prints as.
  if ((name == "str" || name == "string") && args.size() == 1 && args[0].isTime()) {
    out = Value(displayText(args[0]));
    return TimeArgs::Done;
  }

  std::string got;
  for (const Value &a : args)
    if ((got = firstTimeType(a)) != "")
      break;
  reportTimeError(name + " expects a number, got " + got +
                  (got == "duration" ? " - convert it first, e.g. in_seconds(d)"
                                     : " - read its parts first, e.g. get_date(t) or get_time(t)"));
  return TimeArgs::Refused;
}

} // namespace nctime
