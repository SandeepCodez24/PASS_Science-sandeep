#include "time_zone.h"

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <memory>
#include <mutex>
#include <system_error>
#include <unordered_map>

#include "time_zone_data.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace nctime {

namespace {

constexpr int64_t kSecondsPerDay = 86400;

int64_t floorDivide(int64_t a, int64_t b) {
  const int64_t q = a / b;
  return (a % b != 0 && (a < 0) != (b < 0)) ? q - 1 : q;
}

bool isLeapYear(int64_t y) { return y % 4 == 0 && (y % 100 != 0 || y % 400 == 0); }

} // namespace

// Howard Hinnant's days_from_civil / civil_from_days: a year counted from
// March, in eras of 400 years (146097 days).
int64_t daysFromCivil(int64_t year, unsigned month, unsigned day) {
  const int64_t y = month <= 2 ? year - 1 : year;
  const int64_t era = floorDivide(y, 400);
  const int64_t yoe = y - era * 400;
  const int64_t doy = (153 * (month > 2 ? month - 3 : month + 9) + 2) / 5 + day - 1;
  const int64_t doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return era * 146097 + doe - 719468;
}

void civilFromDays(int64_t dayNumber, int64_t &year, unsigned &month, unsigned &day) {
  const int64_t z = dayNumber + 719468;
  const int64_t era = floorDivide(z, 146097);
  const int64_t doe = z - era * 146097;
  const int64_t yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  const int64_t doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
  const int64_t mp = (5 * doy + 2) / 153;
  day = static_cast<unsigned>(doy - (153 * mp + 2) / 5 + 1);
  month = static_cast<unsigned>(mp < 10 ? mp + 3 : mp - 9);
  year = yoe + era * 400 + (month <= 2 ? 1 : 0);
}

unsigned lastDayOfMonth(int64_t year, unsigned month) {
  static const unsigned char lengths[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  return month == 2 && isLeapYear(year) ? 29 : lengths[month - 1];
}

/* ---- POSIX TZ rules: "EST5EDT,M3.2.0,M11.1.0" ---- */

namespace {

// "EST" or "<+0530>"; nc does not use the abbreviation itself.
bool skipAbbreviation(const std::string &s, size_t &pos) {
  const size_t start = pos;
  if (pos < s.size() && s[pos] == '<') {
    const size_t close = s.find('>', pos);
    if (close == std::string::npos)
      return false;
    pos = close + 1;
    return true;
  }
  while (pos < s.size() && ((s[pos] >= 'A' && s[pos] <= 'Z') || (s[pos] >= 'a' && s[pos] <= 'z')))
    pos++;
  return pos - start >= 3;
}

bool readInt(const std::string &s, size_t &pos, int &out) {
  const size_t start = pos;
  int v = 0;
  while (pos < s.size() && s[pos] >= '0' && s[pos] <= '9' && v < 100000)
    v = v * 10 + (s[pos++] - '0');
  out = v;
  return pos > start;
}

// [+-]hh[:mm[:ss]] in seconds.
bool readHms(const std::string &s, size_t &pos, int32_t &out) {
  int sign = 1;
  if (pos < s.size() && (s[pos] == '+' || s[pos] == '-'))
    sign = s[pos++] == '-' ? -1 : 1;
  int h = 0, m = 0, sec = 0;
  if (!readInt(s, pos, h) || h > 167)
    return false;
  if (pos < s.size() && s[pos] == ':') {
    pos++;
    if (!readInt(s, pos, m) || m > 59)
      return false;
    if (pos < s.size() && s[pos] == ':') {
      pos++;
      if (!readInt(s, pos, sec) || sec > 59)
        return false;
    }
  }
  out = sign * (h * 3600 + m * 60 + sec);
  return true;
}

bool readRuleDay(const std::string &s, size_t &pos, TimeZone::RuleDay &day) {
  using Form = TimeZone::RuleDay::Form;
  if (pos < s.size() && s[pos] == 'M') {
    pos++;
    day.form = Form::MonthWeekDay;
    if (!readInt(s, pos, day.a) || day.a < 1 || day.a > 12 || pos >= s.size() || s[pos++] != '.' ||
        !readInt(s, pos, day.b) || day.b < 1 || day.b > 5 || pos >= s.size() || s[pos++] != '.' ||
        !readInt(s, pos, day.c) || day.c > 6)
      return false;
  } else if (pos < s.size() && s[pos] == 'J') {
    pos++;
    day.form = Form::JulianNoLeap;
    if (!readInt(s, pos, day.a) || day.a < 1 || day.a > 365)
      return false;
  } else {
    day.form = Form::ZeroBased;
    if (!readInt(s, pos, day.a) || day.a > 365)
      return false;
  }
  day.time = 7200; // the default: 02:00:00
  if (pos < s.size() && s[pos] == '/') {
    pos++;
    if (!readHms(s, pos, day.time))
      return false;
  }
  return true;
}

// The local midnight (days since 1970) a rule day falls on in `year`.
int64_t ruleDayNumber(const TimeZone::RuleDay &d, int64_t year) {
  using Form = TimeZone::RuleDay::Form;
  if (d.form == Form::JulianNoLeap) {
    // 1-365, February 29 is never counted.
    const int64_t n = d.a - 1 + (isLeapYear(year) && d.a >= 60 ? 1 : 0);
    return daysFromCivil(year, 1, 1) + n;
  }
  if (d.form == Form::ZeroBased)
    return daysFromCivil(year, 1, 1) + d.a;
  // The b-th weekday c (0 = Sunday) of month a; week 5 means the last.
  const unsigned month = static_cast<unsigned>(d.a);
  const int64_t first = daysFromCivil(year, month, 1);
  const int weekdayOfFirst = static_cast<int>(((first + 4) % 7 + 7) % 7); // day 0 was a Thursday
  int64_t day = first + (d.c - weekdayOfFirst + 7) % 7 + (d.b - 1) * 7;
  const int64_t last = first + lastDayOfMonth(year, month) - 1;
  while (day > last)
    day -= 7;
  return day;
}

int64_t yearOfUtc(int64_t utc) {
  int64_t year = 0;
  unsigned month = 0, day = 0;
  civilFromDays(floorDivide(utc, kSecondsPerDay), year, month, day);
  return year;
}

uint32_t readBe32(const unsigned char *p) {
  return (static_cast<uint32_t>(p[0]) << 24) | (static_cast<uint32_t>(p[1]) << 16) |
         (static_cast<uint32_t>(p[2]) << 8) | static_cast<uint32_t>(p[3]);
}

int64_t readBe64(const unsigned char *p) {
  return static_cast<int64_t>((static_cast<uint64_t>(readBe32(p)) << 32) | readBe32(p + 4));
}

} // namespace

bool TimeZone::fromPosixRule(const std::string &rule, const std::string &name, TimeZone &out) {
  TimeZone z;
  z.name_ = name;
  size_t pos = 0;
  int32_t west = 0;
  if (!skipAbbreviation(rule, pos) || !readHms(rule, pos, west))
    return false;
  z.stdOffset_ = -west; // POSIX counts west of Greenwich
  z.dstOffset_ = z.stdOffset_;
  z.hasRule_ = true;
  if (pos < rule.size()) {
    if (!skipAbbreviation(rule, pos))
      return false;
    z.dstOffset_ = z.stdOffset_ + 3600;
    if (pos < rule.size() && rule[pos] != ',') {
      if (!readHms(rule, pos, west))
        return false;
      z.dstOffset_ = -west;
    }
    z.ruleHasDst_ = true;
    if (pos >= rule.size()) {
      // No dates: the POSIX default, United States rules.
      z.dstStart_ = {RuleDay::Form::MonthWeekDay, 3, 2, 0, 7200};
      z.dstEnd_ = {RuleDay::Form::MonthWeekDay, 11, 1, 0, 7200};
    } else if (rule[pos] != ',' || !readRuleDay(rule, ++pos, z.dstStart_) ||
               pos >= rule.size() || rule[pos] != ',' || !readRuleDay(rule, ++pos, z.dstEnd_)) {
      return false;
    }
  }
  if (pos != rule.size())
    return false;
  z.initialOffset_ = z.stdOffset_;
  out = std::move(z);
  return true;
}

bool TimeZone::fromTzif(const unsigned char *bytes, size_t size, const std::string &name,
                        TimeZone &out) {
  // A header: "TZif", version, 15 reserved bytes, then six big-endian counts.
  constexpr size_t kHeader = 44;
  struct Counts {
    uint32_t isut, isstd, leap, time, type, chars;
  };
  const auto readCounts = [&](size_t at, Counts &c) {
    if (at + kHeader > size || std::memcmp(bytes + at, "TZif", 4) != 0)
      return false;
    const unsigned char *p = bytes + at + 20;
    c = {readBe32(p), readBe32(p + 4), readBe32(p + 8), readBe32(p + 12), readBe32(p + 16),
         readBe32(p + 20)};
    // No real file comes near these; they keep the sizes below from overflowing.
    return c.isut <= 1u << 16 && c.isstd <= 1u << 16 && c.leap <= 1u << 16 &&
           c.time <= 1u << 20 && c.type >= 1 && c.type <= 256 && c.chars <= 1u << 16;
  };

  Counts c{};
  if (!readCounts(0, c) || bytes[4] < '2') // only 64-bit data (version 2 on) reaches 2262
    return false;
  // Skip the 32-bit block to the 64-bit one.
  const size_t second = kHeader + size_t{c.time} * 5 + size_t{c.type} * 6 + c.chars +
                        size_t{c.leap} * 8 + c.isstd + c.isut;
  if (!readCounts(second, c))
    return false;
  const size_t times = second + kHeader;
  const size_t indexes = times + size_t{c.time} * 8;
  const size_t types = indexes + c.time;
  const size_t footer = types + size_t{c.type} * 6 + c.chars + size_t{c.leap} * 12 + c.isstd + c.isut;
  if (footer > size)
    return false;

  const auto typeOffset = [&](size_t type) {
    return static_cast<int32_t>(readBe32(bytes + types + type * 6));
  };

  TimeZone z;
  z.name_ = name;
  z.initialOffset_ = typeOffset(0);
  int32_t current = z.initialOffset_;
  int64_t lastTransition = std::numeric_limits<int64_t>::min();
  z.times_.reserve(c.time);
  z.offsets_.reserve(c.time);
  for (uint32_t i = 0; i < c.time; i++) {
    const size_t type = bytes[indexes + i];
    if (type >= c.type)
      return false;
    const int64_t when = readBe64(bytes + times + size_t{i} * 8);
    if (i > 0 && when <= lastTransition)
      return false;
    lastTransition = when;
    // A change of name or of daylight flag alone does not move the clocks.
    const int32_t offset = typeOffset(type);
    if (offset != current) {
      z.times_.push_back(when);
      z.offsets_.push_back(offset);
      current = offset;
    }
  }

  // The footer: "\n" rule "\n"; an empty rule means nothing after the last change.
  if (footer < size && bytes[footer] == '\n') {
    const unsigned char *begin = bytes + footer + 1;
    const unsigned char *end = std::find(begin, bytes + size, static_cast<unsigned char>('\n'));
    if (end != begin) {
      TimeZone rule;
      if (!fromPosixRule(std::string(begin, end), name, rule))
        return false;
      z.hasRule_ = true;
      z.ruleFrom_ = lastTransition;
      z.ruleHasDst_ = rule.ruleHasDst_;
      z.stdOffset_ = rule.stdOffset_;
      z.dstOffset_ = rule.dstOffset_;
      z.dstStart_ = rule.dstStart_;
      z.dstEnd_ = rule.dstEnd_;
    }
  }
  out = std::move(z);
  return true;
}

// The changes of the rule in [firstYear, lastYear], oldest first. When the end
// of one year's daylight saving meets the start of the next (a zone on
// daylight saving all year), the start sorts last and wins.
size_t TimeZone::ruleEvents(int64_t firstYear, int64_t lastYear, Event *events) const {
  size_t n = 0;
  for (int64_t y = firstYear; y <= lastYear; y++) {
    events[n++] = {ruleDayNumber(dstEnd_, y) * kSecondsPerDay + dstEnd_.time - dstOffset_,
                   stdOffset_};
    events[n++] = {ruleDayNumber(dstStart_, y) * kSecondsPerDay + dstStart_.time - stdOffset_,
                   dstOffset_};
  }
  std::stable_sort(events, events + n, [](const Event &a, const Event &b) { return a.utc < b.utc; });
  return n;
}

int32_t TimeZone::ruleOffsetAt(int64_t utc) const {
  if (!ruleHasDst_)
    return stdOffset_;
  const int64_t year = yearOfUtc(utc);
  Event events[6];
  const size_t n = ruleEvents(year - 1, year + 1, events);
  // Rule times can reach a week past the year's end, so last year's events
  // always hold one at or before `utc`.
  int32_t offset = events[0].newOffset;
  for (size_t i = 0; i < n && events[i].utc <= utc; i++)
    offset = events[i].newOffset;
  return offset;
}

bool TimeZone::ruleNextChange(int64_t utc, int64_t &when, int32_t &newOffset) const {
  if (!ruleHasDst_ || stdOffset_ == dstOffset_)
    return false;
  int32_t current = ruleOffsetAt(utc);
  const int64_t year = yearOfUtc(utc);
  Event events[8];
  const size_t n = ruleEvents(year - 1, year + 2, events);
  for (size_t i = 0; i < n; i++) {
    if (events[i].utc <= utc)
      continue;
    // Tied events (daylight saving all year) cancel out.
    if (i + 1 < n && events[i + 1].utc == events[i].utc)
      continue;
    if (events[i].newOffset != current) {
      when = events[i].utc;
      newOffset = events[i].newOffset;
      return true;
    }
  }
  return false; // on daylight saving all year: no change ever comes
}

int32_t TimeZone::offsetAt(int64_t utc) const {
  if (hasRule_ && utc >= ruleFrom_)
    return ruleOffsetAt(utc);
  const auto it = std::upper_bound(times_.begin(), times_.end(), utc);
  return it == times_.begin() ? initialOffset_ : offsets_[static_cast<size_t>(it - times_.begin()) - 1];
}

bool TimeZone::nextChange(int64_t utc, int64_t &when, int32_t &newOffset) const {
  const auto it = std::upper_bound(times_.begin(), times_.end(), utc);
  if (it != times_.end()) {
    when = *it;
    newOffset = offsets_[static_cast<size_t>(it - times_.begin())];
    return true;
  }
  return hasRule_ && ruleNextChange(std::max(utc, ruleFrom_), when, newOffset);
}

LocalInfo TimeZone::lookupLocal(int64_t local) const {
  // Offsets stay under a day, and the largest jump ever (Manila, 1844) is a
  // whole day, so every instant that could show this local time lies within
  // two days of it. Walk the stretches of constant offset in that window.
  constexpr int64_t kWindow = 2 * kSecondsPerDay;
  const int64_t last = local + kWindow;
  int64_t begin = local - kWindow;
  int32_t offset = offsetAt(begin);

  LocalInfo info;
  int hits = 0;
  bool inGap = false;
  for (;;) {
    int64_t end = 0;
    int32_t after = 0;
    const bool more = nextChange(begin, end, after) && end <= last;
    // The stretch shows local times [begin + offset, end + offset). The
    // first stretch starts before the window, so `local` is never before it.
    if (local >= begin + offset && (!more || local < end + offset)) {
      if (hits == 0)
        info.firstOffset = offset;
      else if (hits == 1)
        info.secondOffset = offset;
      hits++;
    }
    if (!more)
      break;
    if (hits == 0 && local >= end + offset && local < end + after) {
      inGap = true;
      info.firstOffset = offset;
      info.secondOffset = after;
      info.transition = end;
    }
    begin = end;
    offset = after;
  }
  info.kind = hits >= 2 ? LocalInfo::Kind::Overlap
              : hits == 1 || !inGap ? LocalInfo::Kind::Unique
                                    : LocalInfo::Kind::Gap;
  return info;
}

/* ---- finding zones ---- */

const TimeZone *findTimeZone(const std::string &name) {
  const tzdata::ZoneEntry *first = tzdata::kZones;
  const tzdata::ZoneEntry *last = tzdata::kZones + tzdata::kZoneCount;
  const tzdata::ZoneEntry *entry = std::lower_bound(
      first, last, name, [](const tzdata::ZoneEntry &e, const std::string &n) { return n.compare(e.name) > 0; });
  if (entry == last || name != entry->name)
    return nullptr;

  static std::mutex mutex;
  static std::unordered_map<std::string, std::unique_ptr<TimeZone>> loaded;
  const std::lock_guard<std::mutex> lock(mutex);
  std::unique_ptr<TimeZone> &slot = loaded[name];
  if (!slot) {
    slot = std::make_unique<TimeZone>();
    if (!TimeZone::fromTzif(tzdata::kBlob + entry->offset, entry->size, name, *slot)) {
      slot.reset();
      return nullptr;
    }
  }
  return slot.get();
}

std::string zoneNameFromPath(const std::string &path) {
  static const std::string marker = "zoneinfo/";
  const size_t at = path.rfind(marker);
  return at == std::string::npos ? "" : path.substr(at + marker.size());
}

const char *timeZoneDataVersion() { return tzdata::kVersion; }

/* ---- the computer's zone: the only place the OS is asked anything ---- */

namespace {

std::string environmentTz() {
#ifdef _WIN32
  // getenv() is flagged as unsafe by the MSVC runtime.
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, "TZ") != 0 || buffer == nullptr)
    return "";
  std::string value(buffer);
  free(buffer);
  return value;
#else
  const char *value = std::getenv("TZ");
  return value ? value : "";
#endif
}

// The zone TZ describes: an IANA name, a path into a zoneinfo folder, or a
// POSIX rule ("IST-5:30"). A leading ':' is allowed on all of them.
const TimeZone *zoneFromEnvironment() {
  std::string tz = environmentTz();
  if (!tz.empty() && tz[0] == ':')
    tz.erase(0, 1);
  if (tz.empty())
    return nullptr;
  if (const TimeZone *zone = findTimeZone(tz))
    return zone;
  if (const TimeZone *zone = findTimeZone(zoneNameFromPath(tz)))
    return zone;
  static TimeZone fromRule;
  return TimeZone::fromPosixRule(tz, tz, fromRule) ? &fromRule : nullptr;
}

#ifdef _WIN32

std::string narrow(const wchar_t *text) {
  std::string out;
  for (; *text; text++)
    out += static_cast<char>(*text < 128 ? *text : '?');
  return out;
}

// Windows has its own zone names ("India Standard Time"); CLDR's table gives
// the IANA zone for the name and the user's country.
const TimeZone *zoneFromOs() {
  DYNAMIC_TIME_ZONE_INFORMATION info{};
  if (GetDynamicTimeZoneInformation(&info) == TIME_ZONE_ID_INVALID || info.TimeZoneKeyName[0] == 0)
    return nullptr;
  const std::string windowsName = narrow(info.TimeZoneKeyName);
  wchar_t territoryBuffer[8] = {};
  const GEOID geo = GetUserGeoID(GEOCLASS_NATION);
  const std::string territory =
      geo != GEOID_NOT_AVAILABLE && GetGeoInfoW(geo, GEO_ISO2, territoryBuffer, 8, 0) > 0
          ? narrow(territoryBuffer)
          : "";
  const char *fallback = nullptr;
  for (size_t i = 0; i < tzdata::kWindowsZoneCount; i++) {
    const tzdata::WindowsZoneEntry &row = tzdata::kWindowsZones[i];
    if (windowsName != row.windowsName)
      continue;
    if (territory == row.territory)
      return findTimeZone(row.ianaName);
    if (std::strcmp(row.territory, "001") == 0)
      fallback = row.ianaName;
  }
  return fallback ? findTimeZone(fallback) : nullptr;
}

#else

// macOS and most Linux systems: /etc/localtime is a link into a zoneinfo
// folder. Debian: /etc/timezone holds the name. Otherwise /etc/localtime may
// be a plain copy of the zone file, which reads as well as a built-in one.
const TimeZone *zoneFromOs() {
  std::error_code ec;
  const std::filesystem::path link = std::filesystem::read_symlink("/etc/localtime", ec);
  if (!ec)
    if (const TimeZone *zone = findTimeZone(zoneNameFromPath(link.generic_string())))
      return zone;

  std::ifstream nameFile("/etc/timezone");
  std::string name;
  if (nameFile >> name)
    if (const TimeZone *zone = findTimeZone(name))
      return zone;

  std::ifstream file("/etc/localtime", std::ios::binary);
  const std::vector<unsigned char> bytes{std::istreambuf_iterator<char>(file),
                                         std::istreambuf_iterator<char>()};
  static TimeZone copied;
  return !bytes.empty() && TimeZone::fromTzif(bytes.data(), bytes.size(), "localtime", copied)
             ? &copied
             : nullptr;
}

#endif

} // namespace

const TimeZone *localTimeZone() {
  static const TimeZone *const zone = [] {
    const TimeZone *found = zoneFromEnvironment();
    if (!found)
      found = zoneFromOs();
    return found ? found : findTimeZone("UTC");
  }();
  return zone;
}

} // namespace nctime
