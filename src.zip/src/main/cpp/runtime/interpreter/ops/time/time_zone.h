// Calendar arithmetic and time zones for NC, in portable C++ - the same rules
// and the same results on every operating system.
//
// C++20 <chrono> time zones cannot be relied on: Apple's libc++ does not have
// them, and elsewhere they read whatever database the OS provides. So nc
// carries its own copy of the IANA database (time_zone_data.cpp, regenerated
// by tools/gen_time_zone_data.py) in the standard TZif format, and reads it
// here. The only thing asked of the OS is the NAME of the computer's zone
// (localTimeZone).
//
// Every TimeZone is immutable once made, and all functions here may be called
// from several threads at once.
#pragma once

#include <cstdint>
#include <limits>
#include <string>
#include <vector>

namespace nctime {

// Day 0 is 1970-01-01, in the proleptic Gregorian calendar.
int64_t daysFromCivil(int64_t year, unsigned month, unsigned day);
void civilFromDays(int64_t dayNumber, int64_t &year, unsigned &month, unsigned &day);
unsigned lastDayOfMonth(int64_t year, unsigned month);

// What a local date and time means in a zone. Seconds count from 1970-01-01
// 00:00:00 local; subtracting an offset gives seconds since the UTC epoch.
struct LocalInfo {
  enum class Kind {
    Unique,  // one instant: firstOffset
    Gap,     // none, clocks jumped over it: firstOffset before, secondOffset after
    Overlap  // two, clocks fell back: firstOffset gives the earlier instant
  };
  Kind kind = Kind::Unique;
  int32_t firstOffset = 0;  // seconds east of UTC
  int32_t secondOffset = 0; // Gap and Overlap only
  int64_t transition = 0;   // Gap only: the UTC second clocks jumped
};

class TimeZone {
public:
  // `bytes` is a whole TZif file. False if it is not a valid one.
  static bool fromTzif(const unsigned char *bytes, size_t size, const std::string &name,
                       TimeZone &out);
  // `rule` is a POSIX TZ string such as "EST5EDT,M3.2.0,M11.1.0". False if it
  // is not a valid one.
  static bool fromPosixRule(const std::string &rule, const std::string &name, TimeZone &out);

  const std::string &name() const { return name_; }

  // Seconds east of UTC at the UTC second `utc`.
  int32_t offsetAt(int64_t utc) const;

  LocalInfo lookupLocal(int64_t localSeconds) const;

  // One day of the year on which daylight saving starts or ends in a POSIX
  // rule (public only so time_zone.cpp's helpers can name it).
  struct RuleDay {
    enum class Form { JulianNoLeap, ZeroBased, MonthWeekDay };
    Form form = Form::MonthWeekDay;
    int a = 0, b = 0, c = 0; // day; day; month, week, weekday
    int32_t time = 7200;     // local seconds after that midnight
  };

private:
  struct Event {
    int64_t utc;
    int32_t newOffset;
  };
  // The first change of offset after `utc`. False if there is none.
  bool nextChange(int64_t utc, int64_t &when, int32_t &newOffset) const;
  size_t ruleEvents(int64_t firstYear, int64_t lastYear, Event *events) const;
  int32_t ruleOffsetAt(int64_t utc) const;
  bool ruleNextChange(int64_t utc, int64_t &when, int32_t &newOffset) const;

  std::string name_;
  std::vector<int64_t> times_;    // UTC seconds of each change, ascending
  std::vector<int32_t> offsets_;  // the offset from that change on
  int32_t initialOffset_ = 0;     // before the first change
  // The rule from the TZif footer, in force from ruleFrom_ on: the file's last
  // transition, which may be a mere marker that changes no offset.
  bool hasRule_ = false;
  int64_t ruleFrom_ = std::numeric_limits<int64_t>::min();
  bool ruleHasDst_ = false;
  int32_t stdOffset_ = 0, dstOffset_ = 0;
  RuleDay dstStart_, dstEnd_;
};

// The zone called `name` (exact spelling, as in the IANA database), nullptr
// if there is none. It lives for the rest of the run.
const TimeZone *findTimeZone(const std::string &name);

// The computer's zone: the TZ environment variable if it names a zone, else
// what the OS says, else UTC. Read once.
const TimeZone *localTimeZone();

// The release of the built-in database, e.g. "2026b".
const char *timeZoneDataVersion();

// "Asia/Kolkata" from "/var/db/timezone/zoneinfo/Asia/Kolkata" - the part of
// a path after "zoneinfo/", or "" when it has none.
std::string zoneNameFromPath(const std::string &path);

} // namespace nctime
