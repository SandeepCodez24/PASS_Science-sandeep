#include "arithmetic_builtin.h"
#include "arithmetic.h"

#include <functional>
#include <iostream>
#include <unordered_map>


Value arithmeticBuiltin(const std::string &name,
                        const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ===== ROOTS ===== */
      {"sqrt",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sqrt", 1))
           return Value();
         return sqrt_op(a[0]);
       }},

      {"cbrt",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cbrt", 1))
           return Value();
         return cbrt_op(a[0]);
       }},

      /* ===== LOGARITHMS ===== */
      {"log",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("log", 1))
           return Value();
         return log_op(a[0]);
       }},

      {"log_base",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("log_base", 2))
           return Value();
         return log_base(a[0], a[1]);
       }},

      {"logb2",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("logb2", 1))
           return Value();
         return logb2_op(a[0]);
       }},

      /* ===== POWERS ===== */
      {"sqr",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("sqr", 1))
           return Value();
         return sqr_op(a[0]);
       }},

      {"cube",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("cube", 1))
           return Value();
         return cube_op(a[0]);
       }},

      {"exp",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("exp", 1))
           return Value();
         return exp_op(a[0]);
       }},

      /* ===== CONVERSIONS ===== */
      {"dec2frac",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("dec2frac", 1))
           return Value();
         return dec2frac(a[0]);
       }},

      {"frac2dec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("frac2dec", 1))
           return Value();
         return frac2dec(a[0]);
       }},

      /* ===== COMPATIBILITY ALIASES ===== */
      {"frac2deci",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("frac2deci", 1))
           return Value();
         return frac2deci(a[0]);
       }},

      {"deci2frac",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("deci2frac", 1))
           return Value();
         return deci2frac(a[0]);
       }},

      /* ===== BASIC OPS ===== */
      {"abs",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("abs", 1))
           return Value();
         return abs_op(a[0]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown arithmetic function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}