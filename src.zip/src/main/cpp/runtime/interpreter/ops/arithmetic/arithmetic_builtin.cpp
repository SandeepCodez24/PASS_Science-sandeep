#include "arithmetic_builtin.h"
#include "arithmetic.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>


Value arithmeticBuiltin(const std::string &name,
                        const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ===== ROOTS ===== */
      {"sqrt",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sqrt", 1))
           return Value();
         return sqrt_op(a[0]);
       }},

      {"cbrt",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cbrt", 1))
           return Value();
         return cbrt_op(a[0]);
       }},

      /* ===== LOGARITHMS =====
       * log-base-N is handled dynamically by callBuiltin() (builtins.cpp)
       * via the "logbN" name pattern (logb2, logb6, logb10, ...) - no
       * "log_base"/"logb2" keywords are registered here. */
      {"log",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "log", 1))
           return Value();
         return log_op(a[0]);
       }},

      /* ===== POWERS ===== */
      {"sqr",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "sqr", 1))
           return Value();
         return sqr_op(a[0]);
       }},

      {"cube",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cube", 1))
           return Value();
         return cube_op(a[0]);
       }},

      {"exp",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "exp", 1))
           return Value();
         return exp_op(a[0]);
       }},

      /* ===== CONVERSIONS ===== */
      {"dec2frac",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "dec2frac", 1))
           return Value();
         return dec2frac(a[0]);
       }},

      /* ===== COMPATIBILITY ALIASES ===== */
      {"frac2deci",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "frac2deci", 1))
           return Value();
         return frac2deci(a[0]);
       }},

      {"deci2frac",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "deci2frac", 1))
           return Value();
         return deci2frac(a[0]);
       }},

      /* ===== BASIC OPS ===== */
      {"abs",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "abs", 1))
           return Value();
         return abs_op(a[0]);
       }},

      // quotient(a,b): truncated (toward-zero) integer division - distinct
      // from the `//` operator (floor_div(), always rounds toward negative
      // infinity). Fully implemented in arithmetic.cpp/.h already (correct
      // sign handling, NaN/Infinity passthrough for non-finite operands,
      // array/matrix elementwise support via zipElementwise) but was never
      // registered in any dispatch table - a real, previously-unreachable
      // gap found via direct testing: `quotient(-7,2)` failed with "Unknown
      // function 'quotient'" despite the implementation working correctly
      // when called directly in C++ (confirmed via the parity/test harness
      // convention of calling arithmetic.cpp functions directly, not just
      // through this table).
      {"quotient",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "quotient", 2))
           return Value();
         return quotient(a[0], a[1]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass): this table used to be looked
  // up with the exact, non-lowercased name the caller typed - the outer
  // builtins.cpp table normalizes its OWN lookup, but that doesn't help
  // here, since it just calls arithmeticBuiltin(name, args) with the
  // original name once it's found which handler to dispatch to. Without
  // this, any casing other than a key's exact spelling failed with
  // "Unknown function", contradicting the documented case-insensitive
  // dispatch (see matrix_builtin.cpp for the first fix of this kind).
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown arithmetic function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}