#pragma once

#include "../../core/value.h"

Value add(Value a, Value b);
Value sub(Value a, Value b);
Value mul(Value a, Value b);
Value div_op(Value a, Value b);
Value mod_op(Value a, Value b);
Value quotient(Value a, Value b);
Value power(Value a, Value b);
Value factorial(Value a);

Value abs_op(Value a);
Value log_op(Value a);
Value exp_op(Value a);
Value sqrt_op(Value a);
Value cbrt_op(Value a);
Value sqr_op(Value a);
Value cube_op(Value a);
Value log_base(Value base, Value val);

Value frac2dec(Value a);
Value dec2frac(Value a);

// Compatibility/alias builtins required by tests
Value frac2deci(Value a);
Value deci2frac(Value a);

// log base 2
Value logb2_op(Value a);
