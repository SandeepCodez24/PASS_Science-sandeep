#pragma once

#include "../../core/value.h"

Value add(Value a, Value b);
Value sub(Value a, Value b);
Value mul(Value a, Value b);
Value div_op(Value a, Value b);
Value mod_op(Value a, Value b);
Value quotient(Value a, Value b);
Value floor_div(Value a, Value b);
Value power(Value a, Value b);
Value factorial(Value a);

// Unary minus on an already text-coerced operand: a number (real or
// complex, unit preserved), or every element of an array/matrix.
Value negate_op(Value a);

// The |x| form: determinant of a matrix, norm of an array, magnitude of a
// number. `ok` is false when the operand is rejected (an error was printed).
Value abs_or_norm(const Value &a, bool &ok);

Value abs_op(Value a);
Value log_op(Value a);
Value exp_op(Value a);
Value sqrt_op(Value a);
Value cbrt_op(Value a);
Value sqr_op(Value a);
Value cube_op(Value a);

// log base N: not registered as its own callable NC keyword — used only
// internally by callBuiltin()'s dynamic "logbN" dispatch (builtins.cpp),
// which is the sole log-base entry point exposed to scripts.
Value log_base(Value base, Value val);

Value dec2frac(Value a);

// Compatibility/alias builtins required by tests
Value frac2deci(Value a);
Value deci2frac(Value a);

// Auto-coercion for arithmetic/factorial: true and out=<value> if `v` is
// text that parses as a decimal or a dec2frac()-style "num/denom"
// fraction; false (out untouched) for a non-text Value or genuinely
// non-numeric text. See arithmetic.cpp's definition for the full
// rationale (mirrors Python's Fraction / Julia's Rational staying usable
// in further math despite printing as text).
bool tryCoerceTextToNumber(const Value &v, double &out);
