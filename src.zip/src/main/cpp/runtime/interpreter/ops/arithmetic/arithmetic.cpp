#include "arithmetic.h"
#include "../../core/elementwise.h"
#include "../matrix/matrix.h"
#include "../matrix/matrix_arithmetic.h"
#include "../integer/integer.h"
#include "../vector/vector.h"
#include <cmath>
#include <complex>
#include <iostream>
#include <numeric>
#include <sstream>

using Eigen::MatrixXcd;
using Eigen::MatrixXd;

/* ================= COMPLEX SCALARS =================
 *
 * A complex operand takes its own path at the top of each operator below, so
 * the real-number code underneath is untouched. Two numbers are computed
 * right here; anything involving an array or matrix goes through
 * zipElementwiseC() (elementwise.cpp) or Eigen's complex matrices.
 */

namespace {
enum class ComplexCase { None, Scalars, Containers };

bool isScalarNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef;
}

ComplexCase complexCase(const Value &a, const Value &b) {
  if (!a.hasComplex() && !b.hasComplex())
    return ComplexCase::None;
  return (isScalarNumber(a) && isScalarNumber(b)) ? ComplexCase::Scalars : ComplexCase::Containers;
}

Cplx toCplx(const Value &v) { return Cplx(v.number, v.isComplex ? v.imag : 0.0); }

// A result whose imaginary part is exactly zero is a real number again.
// Adding 0.0 turns a negative zero into a plain zero, so -(3i) prints as
// "0-3i" rather than "-0-3i".
Value fromCplx(Cplx z, int dimL = 0, int dimT = 0, int dimM = 0) {
  g_lastElementwiseOk = true;
  Value result = (z.imag() == 0.0) ? Value(z.real() + 0.0)
                                   : Value::complexNumber(z.real() + 0.0, z.imag());
  result.dimL = static_cast<int16_t>(dimL);
  result.dimT = static_cast<int16_t>(dimT);
  result.dimM = static_cast<int16_t>(dimM);
  return result;
}

// Reported through g_lastElementwiseOk, the flag evaluateBinaryOpValues()
// already checks after every operator.
Value complexUnsupported(const char *what) {
  std::cerr << "Error: " << what << " does not support complex numbers yet\n";
  g_lastElementwiseOk = false;
  return Value(0);
}

Value complexUndefined(const char *op) {
  std::cerr << "Error: '" << op << "' is not defined for complex numbers\n";
  g_lastElementwiseOk = false;
  return Value(0);
}
// Multicore fast path for the common real matrix cases of + - and the
// element-wise * / (nc::par, core/elementwise.h): two packed matrices of
// the same shape, or a packed matrix with a plain real number. Gives the
// same bits as the Eigen / cell paths it replaces (the same one IEEE
// operation per element) and the same unitless result, without copying
// the operands. False when the case is not one of those; the caller then
// goes on as before.
template <class Fn>
bool packedMatrixOp(const Value &a, const Value &b, Fn fn, const char *label, Value &out) {
  const bool plainA = !a.isMatrix && !a.isArray && !a.isText && !a.isDict && !a.isObject &&
                      !a.isFunctionRef && !a.isComplex;
  const bool plainB = !b.isMatrix && !b.isArray && !b.isText && !b.isDict && !b.isObject &&
                      !b.isFunctionRef && !b.isComplex;
  const bool fits = (a.isMatrix && b.isMatrix && a.sameShapeAs(b)) ||
                    (a.isMatrix && a.isPacked() && !a.isND() && plainB) ||
                    (b.isMatrix && b.isPacked() && !b.isND() && plainA);
  if (!fits)
    return false;
  out = zipElementwisePure(a, b, fn, kElementwiseArith, label);
  return true;
}
} // namespace

/* ================= BASIC ================= */

Value add(Value a, Value b) {
  // Array check FIRST, before any isMatrix branch - matters specifically
  // for a matrix+array combination (e.g. `[1,2,3] + [[1,2],[3,4]]`): the
  // matrix branches below call matrix_scalar_add()/scalar_matrix_add(),
  // which read the non-matrix side's .number completely unconditionally,
  // with no check that it's actually a scalar - an array's .number
  // defaults to 0, so the array silently vanished entirely and the matrix
  // came back unchanged, with no error at all. Checking isArray first
  // routes that combination into zipElementwise() (elementwise.cpp)
  // instead, which - since this fix - correctly rejects a matrix paired
  // with anything other than a genuine scalar. Matches the order mod_op()/
  // floor_div()/power() below already use, for the same reason.
  switch (complexCase(a, b)) {
  case ComplexCase::Scalars:
    return fromCplx(toCplx(a) + toCplx(b), a.dimL, a.dimT, a.dimM);
  case ComplexCase::Containers:
    return zipElementwiseC(a, b, [](Cplx x, Cplx y) { return x + y; });
  case ComplexCase::None:
    break;
  }

  if (a.isArray || b.isArray)
    return zipElementwisePure(a, b, [](double x, double y) { return x + y; }, kElementwiseArith, "+");

  {
    Value fast;
    if (packedMatrixOp(a, b, [](double x, double y) { return x + y; }, "+", fast))
      return fast;
  }

  if (a.isMatrix && b.isMatrix)
    return matrix_add(a, b);

  if (a.isMatrix && !b.isMatrix)
    return matrix_scalar_add(a, b);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_add(a, b);

  // Dimensional Integrity: +/- require matching dimensions — that
  // compatibility check happens at the call site (Parser::parseExpression,
  // which has evaluationSucceeded_/std::cerr to report it clearly), not
  // here. Assuming the caller already validated it, the result keeps the
  // (shared) dimension.
  Value result(a.number + b.number);
  result.dimL = a.dimL; result.dimT = a.dimT; result.dimM = a.dimM;
  return result;
}

Value sub(Value a, Value b) {
  // See add()'s own comment on why isArray is checked before any isMatrix
  // branch - identical hazard, identical fix.
  switch (complexCase(a, b)) {
  case ComplexCase::Scalars:
    return fromCplx(toCplx(a) - toCplx(b), a.dimL, a.dimT, a.dimM);
  case ComplexCase::Containers:
    return zipElementwiseC(a, b, [](Cplx x, Cplx y) { return x - y; });
  case ComplexCase::None:
    break;
  }

  if (a.isArray || b.isArray)
    return zipElementwisePure(a, b, [](double x, double y) { return x - y; }, kElementwiseArith, "-");

  {
    Value fast;
    if (packedMatrixOp(a, b, [](double x, double y) { return x - y; }, "-", fast))
      return fast;
  }

  if (a.isMatrix && b.isMatrix)
    return matrix_sub(a, b);

  if (a.isMatrix && !b.isMatrix)
    return matrix_scalar_sub(a, b);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_sub(a, b);

  Value result(a.number - b.number);
  result.dimL = a.dimL; result.dimT = a.dimT; result.dimM = a.dimM;
  return result;
}

Value mul(Value a, Value b) {
  switch (complexCase(a, b)) {
  case ComplexCase::Scalars:
    return fromCplx(toCplx(a) * toCplx(b), a.dimL + b.dimL, a.dimT + b.dimT, a.dimM + b.dimM);
  case ComplexCase::Containers: {
    if (!(a.isMatrix && b.isMatrix))
      return zipElementwiseC(a, b, [](Cplx x, Cplx y) { return x * y; });
    // matrix * matrix is the true matrix product, as for real matrices.
    MatrixXcd m1 = toEigenCMat(a);
    MatrixXcd m2 = toEigenCMat(b);
    if (m1.size() == 0 || m2.size() == 0 || m1.cols() != m2.rows()) {
      std::cerr << "Error: matrix dimensions do not match for multiplication\n";
      g_lastElementwiseOk = false;
      return Value(0);
    }
    g_lastElementwiseOk = true;
    MatrixXcd product = m1 * m2;
    return toValueC(product);
  }
  case ComplexCase::None:
    break;
  }

  if (a.isMatrix && b.isMatrix) {
    MatrixXd m1 = toEigenMat(a);
    MatrixXd m2 = toEigenMat(b);

    /* safety guard: matrix multiplication rule */

    if (m1.cols() != m2.rows())
      return Value(0);

    MatrixXd r = m1 * m2;

    return toValue(r);
  }

  // Checked before the matrix+scalar branches below, for the same reason
  // as add()/sub() above: scalar_matrix_mul() reads the non-matrix side's
  // .number unconditionally, with no check that it's actually a scalar -
  // `[1,2,3] * [[1,2],[3,4]]` would otherwise silently treat the array as
  // 0 instead of being rejected. True matrix*matrix multiplication (just
  // above) is unaffected - this only reorders the matrix+non-matrix case.
  if (a.isArray || b.isArray)
    return zipElementwisePure(a, b, [](double x, double y) { return x * y; }, kElementwiseArith, "*");

  {
    // Matrix with a number (matrix * matrix, the true product, is above).
    Value fast;
    if (packedMatrixOp(a, b, [](double x, double y) { return x * y; }, "*", fast))
      return fast;
  }

  if (a.isMatrix && !b.isMatrix)
    return scalar_matrix_mul(b, a);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_mul(a, b);

  // Dimensional Integrity: unlike +/-, * always combines cleanly (exponents
  // add) — there's no incompatible case to reject, so no check is needed
  // at the call site for this operator.
  Value result(a.number * b.number);
  result.dimL = a.dimL + b.dimL;
  result.dimT = a.dimT + b.dimT;
  result.dimM = a.dimM + b.dimM;
  return result;
}

Value div_op(Value a, Value b) {
  // See add()'s own comment on why isArray is checked before any isMatrix
  // branch - identical hazard, identical fix.
  switch (complexCase(a, b)) {
  case ComplexCase::Scalars:
    return fromCplx(toCplx(a) / toCplx(b), a.dimL - b.dimL, a.dimT - b.dimT, a.dimM - b.dimM);
  case ComplexCase::Containers:
    // Dividing BY a matrix means multiplying by its inverse, and there is
    // no complex inverse yet. Arrays and matrix/scalar are elementwise.
    if (b.isMatrix && !a.isArray)
      return complexUnsupported("division by a matrix");
    return zipElementwiseC(a, b, [](Cplx x, Cplx y) { return x / y; });
  case ComplexCase::None:
    break;
  }

  if (a.isArray || b.isArray)
    return zipElementwisePure(a, b, [](double x, double y) { return x / y; }, kElementwiseArith, "/");

  if (a.isMatrix && !b.isMatrix) {
    // Matrix / number (matrix / matrix is A * inv(B), below).
    Value fast;
    if (packedMatrixOp(a, b, [](double x, double y) { return x / y; }, "/", fast))
      return fast;
  }

  if (a.isMatrix && b.isMatrix)
    return matrix_div(a, b);

  if (a.isMatrix && !b.isMatrix)
    return matrix_scalar_div(a, b);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_div(a, b);

  // IEEE-754 division, unguarded: nonzero/0 naturally yields a signed
  // Infinity, 0/0 yields NaN - both real, representable double values that
  // Value::number already stores fine, replacing the previous silent
  // "b==0 -> 0" collapse (which discarded the distinction between the two
  // and was never a mathematically correct answer for either).
  Value result(a.number / b.number);
  result.dimL = a.dimL - b.dimL;
  result.dimT = a.dimT - b.dimT;
  result.dimM = a.dimM - b.dimM;
  return result;
}

Value mod_op(Value a, Value b) {
  // Matrix operands were entirely unhandled here - unlike every other
  // arithmetic op in this file (add/sub/mul/div_op/power/floor_div all
  // check isMatrix somewhere), mod_op only ever checked isArray, so a
  // matrix operand (e.g. `A % 3`) fell straight through to the scalar
  // .number path below and silently computed fmod(0, 3) = 0 (a matrix's
  // .number defaults to 0), the same silent-wrong-answer bug already fixed
  // for the other operators. zipElementwise() already implements
  // matrix+matrix (dimension-checked) and matrix+scalar (broadcast,
  // rejecting anything else) correctly - this just routes to it, same as
  // the isArray case just below.
  // A remainder needs an ordering, which complex numbers don't have.
  if (complexCase(a, b) != ComplexCase::None)
    return complexUndefined("%");

  if (a.isArray || b.isArray || a.isMatrix || b.isMatrix)
    return zipElementwise(a, b, [](double x, double y) { return std::fmod(x, y); });

  // Floating-point remainder (std::fmod), not truncated-to-int '%' - the
  // previous (int)a.number % (int)b.number silently discarded any
  // fractional part of BOTH operands (5.5 % 2.0 became 5 % 2 = 1 instead
  // of the correct 1.5). No b==0 guard needed: std::fmod(x, 0) is already
  // specified to return NaN (IEEE-754/C99), so removing the guard just lets
  // the standard library give the mathematically correct indeterminate
  // result instead of the previous silent 0.
  return Value(std::fmod(a.number, b.number));
}

static double quotientScalar(double x, double y) {
  if (!std::isfinite(x) || !std::isfinite(y) || y == 0)
    return x / y;
  return (double)((int)x / (int)y);
}

Value quotient(Value a, Value b) {
  if (a.isArray || b.isArray)
    return zipElementwise(a, b, quotientScalar);

  // Truncated integer division - but (int) on a non-finite double (as
  // b==0 now allows a.number/b.number to be, once div_op above lets
  // Infinity/NaN flow freely) is undefined behavior, so any non-finite
  // operand or literal zero divisor falls back to plain IEEE-754 double
  // division instead of the int cast: nonzero/0 -> signed Infinity,
  // 0/0 -> NaN, same convention as div_op.
  return Value(quotientScalar(a.number, b.number));
}

// The `//` operator (parser_expression.cpp's evaluateBinaryOpValues):
// TRUNCATED division - the quotient is rounded toward zero, as in C, C++ and
// Java, so 7 // -2 is -3 (not Python's floored -4). It pairs with `%`
// (mod_op(), std::fmod - remainder takes the dividend's sign), so
// a == (a // b) * b + a % b holds for every sign combination. The integer
// types use the same rule (ops/integer/integer.cpp), as does the JIT's
// native fast path (codegen.cpp, llvm.trunc).
//
// The name floor_div is kept for existing callers; it no longer floors.
// Arrays/matrices are elementwise. No b==0 guard needed: x/0 already gives
// the IEEE-754-correct signed Infinity/NaN, and std::trunc() of either
// passes it through unchanged.
Value floor_div(Value a, Value b) {
  if (complexCase(a, b) != ComplexCase::None)
    return complexUndefined("//");

  // + 0.0: -7 // 9 truncates to -0; print it as 0.
  return mapElementwise(zipElementwise(a, b, [](double x, double y) { return x / y; }),
                         [](double q) { return std::trunc(q) + 0.0; });
}

// The language constant `e` (builtins/constants_builtin.cpp: 2.718281828459045,
// i.e. the double nearest Euler's number, == M_E). Spelled as a literal here so
// it does not depend on M_E being exposed (MSVC needs _USE_MATH_DEFINES).
static constexpr double kEulerE = 2.718281828459045;

// Scalar x^y, shared by the array path and the scalar path in power().
//
// Plain std::pow for everything (0^0 -> 1, IEEE-754 / C99 "empty product"
// convention, matching C, Python, Java, JavaScript, MATLAB) EXCEPT a base equal
// to the constant `e`, which goes through std::exp(y) instead. pow(e, y) is
// pow(fl(e), y): the rounding error of the stored constant e (~1.4e-16
// relative) is multiplied by y and lands in the result, so `e^(log(2))`
// came out 1.9999999999999998 instead of 2. exp(y) is the correctly-rounded
// operation for "e to the y" and has no such error. Special values agree with
// pow: exp(0)=1, exp(inf)=inf, exp(-inf)=0, exp(nan)=nan.
static double powScalar(double x, double y) {
  if (x == kEulerE)
    return std::exp(y);
  return pow(x, y);
}

static double powerScalar(double x, double y) { return powScalar(x, y); }

// Real x^y is undefined (NaN) for a negative base and a fractional exponent.
static bool powNeedsComplex(double x, double y) {
  return x < 0.0 && std::isfinite(y) && y != std::floor(y);
}

static Cplx sqrtComplex(Cplx z);

// Complex x^y. A whole-number exponent is done by repeated multiplication so
// that results which should be exact are exact: (1+2i)^2 is -3+4i and i^2 is
// the real number -1, where the general exp(y*log(x)) route leaves rounding
// noise in both parts.
static Cplx powComplex(Cplx x, Cplx y) {
  // Two real operands that have a real answer get exactly the real
  // function's result, so the in-domain elements of a mixed array
  // ([-8, 8]^(1/3)) are bit-for-bit what they would be on their own.
  if (x.imag() == 0.0 && y.imag() == 0.0 && !powNeedsComplex(x.real(), y.real()))
    return Cplx(powScalar(x.real(), y.real()), 0.0);
  // x^0.5 is the square root, which sqrtComplex() computes without the
  // rounding noise of the general route ((-4)^0.5 is exactly 2i).
  if (y == Cplx(0.5, 0.0))
    return sqrtComplex(x);
  if (y.imag() == 0.0 && y.real() == std::floor(y.real()) && std::fabs(y.real()) <= 1024.0) {
    long n = static_cast<long>(std::fabs(y.real()));
    Cplx result(1.0, 0.0), base = x;
    while (n > 0) {
      if (n & 1)
        result *= base;
      base *= base;
      n >>= 1;
    }
    return y.real() < 0 ? Cplx(1.0, 0.0) / result : result;
  }
  // Same reason as powScalar(): exp(y) is the exact operation for e^y.
  if (x.imag() == 0.0 && x.real() == kEulerE)
    return std::exp(y);
  // log(0) is -inf, so the general route would give NaN for 0^y.
  if (x == Cplx(0.0, 0.0) && y.real() > 0.0)
    return Cplx(0.0, 0.0);
  return std::pow(x, y);
}

// The array form of the test above: true when any pair of elements (or an
// element paired with the scalar on the other side) needs the complex
// route. Mismatched or mixed shapes answer false and are left to
// zipElementwise(), which reports them.
static bool anyPowNeedsComplex(const Value &a, const Value &b) {
  if (b.isMatrix)
    return false;
  // A matrix base with a single-number exponent - the element-wise matrix
  // power (fractional exponent) asks this too.
  if (a.isMatrix) {
    for (size_t r = 0; r < a.rows(); r++)
      for (size_t c = 0; c < a.rowLength(r); c++)
        if (powNeedsComplex(a.numAt(r, c), b.number))
          return true;
    return false;
  }
  if (a.isArray && b.isArray && a.length() != b.length())
    return false;
  const size_t n = a.isArray ? a.length() : b.length();
  for (size_t i = 0; i < n; i++)
    if (powNeedsComplex(a.isArray ? a.numAt(i) : a.number, b.isArray ? b.numAt(i) : b.number))
      return true;
  return false;
}

Value power(Value a, Value b) {
  switch (complexCase(a, b)) {
  case ComplexCase::Scalars: {
    // Units follow the same rule as the real scalar path below.
    int p = (!b.isComplex && std::isfinite(b.number)) ? (int)b.number : 0;
    return fromCplx(powComplex(toCplx(a), toCplx(b)), a.dimL * p, a.dimT * p, a.dimM * p);
  }
  case ComplexCase::Containers: {
    if (a.isArray || b.isArray)
      return zipElementwiseC(a, b, powComplex);
    if (!a.isMatrix)
      return complexUnsupported("a matrix exponent");
    if (!isScalarNumber(b)) {
      std::cerr << "Error: the exponent of a matrix in '^' must be a single number - use "
                   "power(A, B) for element-wise powers\n";
      g_lastElementwiseOk = false;
      return Value(0);
    }
    // Not a whole number (or a complex exponent): element-wise, as for a
    // real matrix below - A^0.5 is the square root of every element.
    if (b.isComplex || !std::isfinite(b.number) ||
        std::abs(b.number - std::round(b.number)) > 1e-9)
      return zipElementwiseC(a, b, powComplex);
    // Matrix power: repeated matrix product, whole-number exponent.
    int p = static_cast<int>(std::round(b.number));
    if (p < 0)
      return complexUnsupported("a negative matrix power");
    MatrixXcd base = toEigenCMat(a);
    if (base.size() == 0 || base.rows() != base.cols()) {
      std::cerr << "Error: matrix power requires a square matrix\n";
      g_lastElementwiseOk = false;
      return Value(0);
    }
    g_lastElementwiseOk = true;
    MatrixXcd result = MatrixXcd::Identity(base.rows(), base.cols());
    for (int k = 0; k < p; k++)
      result = result * base;
    return toValueC(result);
  }
  case ComplexCase::None:
    break;
  }

  /* ARRAY POWER (elementwise) - was previously missing entirely: neither
     operand's isArray flag was checked, so [1,2,3]^2 fell through to the
     scalar path below and read a.number/b.number (0 for an array-flagged
     Value), silently returning 0 instead of raising an error or an
     elementwise result. Unit-dimension tracking (dimL/dimT/dimM below)
     isn't meaningful for an array the way it is for a scalar, so it's left
     unset here, same as every other array-arithmetic op above. */
  if (a.isArray || b.isArray) {
    if (anyPowNeedsComplex(a, b))
      return zipElementwiseC(a, b, powComplex);
    return zipElementwise(a, b, powerScalar);
  }

  /* MATRIX POWER */

  // A matrix as the EXPONENT (A^B, 2^A) has no meaning here - both used to
  // read the matrix's .number (always 0) as the exponent and silently
  // returned the identity matrix / 1. power(A, B) (Numpy/scalar_math) is the
  // element-wise form.
  if (b.isMatrix) {
    std::cerr << "Error: the exponent of '^' must be a single number when a matrix is "
                 "involved - use power(A, B) for element-wise powers\n";
    g_lastElementwiseOk = false;
    return Value(0);
  }

  if (a.isMatrix) {
    // NOTE (2026-10): the `^` OPERATOR no longer reaches this branch - its
    // matrix rules (whole-number powers only, A^2.3 an error, A^.n for
    // element-wise) live in ops/matrix/matrix_ops.cpp. power(A, n) - the
    // NumPy element-wise function - never sends a matrix here either. Kept
    // for any direct C++ caller.
    // Rule (team decision, 2026-10-17): a whole-number exponent is the
    // matrix power (repeated matrix product, inverse for negative); any
    // other exponent - fractional, Inf or NaN - is ELEMENT-WISE, so A^0.5
    // is the square root of every element, the same as power(A, 0.5).
    // Before this, a fractional exponent was an error ("matrix power
    // requires an integer exponent") whose statement still echoed 0, and
    // earlier still A^2.5 silently computed A^2.
    if (!std::isfinite(b.number) || std::abs(b.number - std::round(b.number)) > 1e-9) {
      // A negative element with a fractional exponent has no real answer:
      // the whole result is then complex, as for arrays and numbers.
      if (anyPowNeedsComplex(a, b))
        return zipElementwiseC(a, b, powComplex);
      return zipElementwise(a, b, powerScalar);
    }

    MatrixXd m = toEigenMat(a);
    int p = static_cast<int>(std::round(b.number));

    /* handle identity */

    if (p == 0)
      return toValue(MatrixXd::Identity(m.rows(), m.cols()));

    // Negative power: (A^-1)^|p|, not just A^-1 - a real bug found by
    // direct testing (A^-2 used to silently return A completely
    // unchanged, since the old "positive power" loop below, `for (int
    // i=1; i<p; i++)`, never executes at all when p is negative). Also
    // adds the invertibility check this path never had at all before -
    // A^-1 on a singular matrix used to silently return an Inf/NaN-filled
    // matrix from Eigen's .inverse() with no error, confirmed by direct
    // testing.
    MatrixXd base = m;
    if (p < 0) {
      if (isEffectivelySingular(m)) {
        std::cerr << "Error: matrix is singular - cannot raise it to a negative power\n";
        // Reported through the flag evaluateBinaryOpValues() checks, so the
        // statement stops instead of going on to echo the placeholder 0.
        g_lastElementwiseOk = false;
        return Value(0);
      }
      base = m.inverse();
      p = -p;
    }

    MatrixXd r = base;
    for (int i = 1; i < p; i++)
      r = r * base;

    return toValue(r);
  }

  /* SCALAR POWER */

  if (!a.isMatrix) {
    // Dimensional Integrity: raising a unit-tagged value to a power
    // multiplies each dimension exponent by it (e.g. (m/s)^2 = L^2 T^-2).
    // Only meaningful for an integer power of a unit-bearing base; b itself
    // being unit-bearing (a "3 meters"-th power) isn't a sensible operation
    // and isn't specially guarded against here — same "no check needed,
    // there's no ambiguous case" reasoning as mul()/div_op() above.
    //
    // pow() itself is IEEE-754-correct with no guard needed for
    // 1^Infinity -> 1, Infinity^0 -> 1 - both standard C99/IEEE-754-2008
    // pow() behavior, and so is 0^0 -> 1 (the "empty product" convention;
    // a 2026-09-17 NaN override for 0^0 was reverted so NC matches C,
    // Python, Java, JavaScript and MATLAB). Only the
    // dimension-tracking (int) cast below needs guarding against a
    // non-finite exponent (UB otherwise) - a unit-bearing base raised to
    // an infinite/NaN power isn't a meaningful dimensional operation, so
    // it falls back to unitless (p=0).
    int p = std::isfinite(b.number) ? (int)b.number : 0;
    // A negative base with a fractional exponent has no real answer, so it
    // gets the principal complex one ((-8)^(1/3) is 1+1.732i), as in MATLAB.
    if (powNeedsComplex(a.number, b.number))
      return fromCplx(powComplex(Cplx(a.number, 0.0), Cplx(b.number, 0.0)), a.dimL * p,
                      a.dimT * p, a.dimM * p);
    Value result(powScalar(a.number, b.number));
    result.dimL = a.dimL * p;
    result.dimT = a.dimT * p;
    result.dimM = a.dimM * p;
    return result;
  }

  /* SAFETY RETURN */

  return Value(0);
}

/* ================= UNARY MINUS / |x| ================= */

// An integer is negated exactly (int8(-128) has no int8 negation, so that
// is an error reported through g_lastElementwiseOk); a bool negates as the
// float64 it stands for (-true is -1).
Value negate_op(Value a) {
  g_lastElementwiseOk = true;
  // Packed real data (all plain numbers, one unit): flip the sign of every
  // element, on several cores when large. The element walk below unpacked a
  // 3000 x 3000 matrix into 9 million Values and packed it again (~0.4 s;
  // A *. (-1) took 0.024 s). Same values - a sign flip is exact, -0
  // included - and the unit is kept. Complex data keeps the walk, which
  // also narrows a result whose imaginary parts are all zero to real.
  if ((a.isArray || a.isMatrix) && a.isPacked()) {
    Value result;
    const bool done = a.mapPackedKeepUnit(
        [](const double *in, double *out, size_t n) {
          return nc::par::forBlocks(n, kElementwiseArith, "-", [&](size_t begin, size_t end) {
                   for (size_t k = begin; k < end; k++)
                     out[k] = -in[k];
                 }) == nc::par::Outcome::Done;
        },
        result);
    if (!done) {
      g_lastElementwiseOk = false; // Stop pressed: give the result up
      return Value(0);
    }
    return result;
  }
  if (a.isArray || a.isMatrix) {
    a.transformElems([](const Value &x) {
      if (x.isInt()) {
        Value neg;
        std::string err;
        if (integerNegate(x, neg, err))
          return neg;
        std::cerr << "Error: " << err << "\n";
        g_lastElementwiseOk = false;
        return x;
      }
      Value neg = x;
      // A bool negates as the float64 it stands for; a float8/16/32 keeps
      // its format (negation is exact in every format).
      if (neg.isBool())
        neg.dropScalarType();
      neg.number = -neg.number;
      if (neg.isComplex)
        neg.imag = -neg.imag;
      return neg;
    });
    if (!g_lastElementwiseOk)
      return Value(0);
    return a;
  }
  if (a.floatType() != FloatType::Float64 && !a.isComplex) {
    Value neg = a; // float8/16/32: negation is exact, the format stays
    neg.number = -neg.number;
    return neg;
  }
  if (a.isInt()) {
    Value neg;
    std::string err;
    if (integerNegate(a, neg, err))
      return neg;
    std::cerr << "Error: " << err << "\n";
    g_lastElementwiseOk = false;
    return Value(0);
  }
  if (a.isComplex)
    return fromCplx(Cplx(0.0, 0.0) - toCplx(a), a.dimL, a.dimT, a.dimM);
  // Dimensional Integrity: preserve the operand's unit through negation.
  Value negated(-a.number);
  negated.dimL = a.dimL;
  negated.dimT = a.dimT;
  negated.dimM = a.dimM;
  return negated;
}

Value abs_or_norm(const Value &a, bool &ok) {
  ok = true;
  if (a.isMatrix) {
    if (a.hasComplex()) {
      std::cerr << "Error: determinant does not support complex numbers yet\n";
      ok = false;
      return Value(0);
    }
    // |A| of a matrix is its determinant, so A must be square (a row or
    // column vector never gets here - |v| is its length).
    if (a.rows() == 0 || a.rows() != a.cols()) {
      std::cerr << "Error: |A| (determinant) needs a square matrix, got " << a.rows() << "x"
                << (a.rows() ? a.cols() : 0) << "\n";
      ok = false;
      return Value(0);
    }
    return det(a);
  }
  if (a.isArray) {
    if (a.hasComplex()) {
      // Norm of a complex vector: sqrt of the sum of squared magnitudes.
      double sumSquares = 0.0;
      for (size_t i = 0; i < a.length(); i++) {
        Value elem = a.at(i);
        if (!isScalarNumber(elem)) {
          std::cerr << "Error: norm expects an array of numbers\n";
          ok = false;
          return Value(0);
        }
        sumSquares += std::norm(toCplx(elem));
      }
      return Value(std::sqrt(sumSquares));
    }
    return Vec_Norm(a);
  }
  if (a.isComplex) {
    Value magnitude(std::hypot(a.number, a.imag));
    magnitude.dimL = a.dimL;
    magnitude.dimT = a.dimT;
    magnitude.dimM = a.dimM;
    return magnitude;
  }
  return abs_op(a);
}

/* ================= FACTORIAL ================= */

// Factorial, extended to the reals via the gamma function: x! = tgamma(x+1).
//   - non-negative integer  -> exact product loop (exact up to 22!, then
//                              correctly rounded doubles; >170! overflows to
//                              +inf, as IEEE-754 double must)
//   - negative integer      -> NaN (gamma has poles there; undefined)
//   - non-integer (2.5!)    -> tgamma(x+1)  (2.5! = 3.3233...)
//   - NaN / +-inf           -> NaN
// Arrays/matrices apply elementwise. Text keeps the old 0 convention.
static double factorialScalar(double x) {
  if (std::isnan(x) || std::isinf(x))
    return std::nan("");
  if (x == std::floor(x)) {
    if (x < 0)
      return std::nan("");
    if (x > 170)
      return INFINITY;
    double result = 1;
    for (int i = 2; i <= (int)x; i++)
      result *= i;
    return result;
  }
  return tgamma(x + 1);
}

Value factorial(Value a) {
  if (a.isText)
    return Value(0);
  return mapElementwise(a, factorialScalar);
}

/* ================= BASIC FUNCTIONS ================= */

// Every function below routes through mapElementwise() (NumPy/SciPy Parity
// Roadmap §4.1) instead of reading a.number directly: the earlier
// scalar-only form silently ignored isArray/isMatrix (an array/matrix
// Value's .number defaults to 0), so e.g. sqrt([1,4,9]) returned sqrt(0)
// instead of [1,2,3] - a silent-wrong-answer bug, not a missing feature.
// mapElementwise leaves scalar behavior byte-for-byte identical (it's still
// exactly fn(a.number) for a plain number) while adding array/matrix
// broadcast for free.

Value abs_op(Value a) { return mapElementwisePure(a, [](double x) { return fabs(x); }); }

// Principal complex square root, computed from the parts directly. The
// library's std::sqrt goes through the polar form, which leaves rounding
// noise where the answer is exact: it gives 1.2e-16+2i for sqrt(-4+0i).
// This form gives exactly 2i there, and exactly 2+1i for sqrt(3+4i).
static Cplx sqrtComplex(Cplx z) {
  const double re = z.real(), im = z.imag();
  if (re == 0.0 && im == 0.0)
    return Cplx(0.0, 0.0);
  if (!std::isfinite(re) || !std::isfinite(im))
    return std::sqrt(z);
  const double t = std::sqrt((std::fabs(re) + std::hypot(re, im)) / 2.0);
  if (re >= 0.0)
    return Cplx(t, im / (2.0 * t));
  return Cplx(std::fabs(im) / (2.0 * t), std::copysign(t, im));
}

Value sqrt_op(Value a) {
  // Real-domain sqrt: a negative input is undefined over the reals (its
  // well-defined answer is complex, which this language doesn't have a
  // type for), so it's NaN per IEEE-754/C99 sqrt() - the standard library
  // call already does this correctly with no guard needed; the previous
  // manual guard was the one silently substituting the wrong answer (0).
  // Complex input: the principal square root.
  if (a.hasComplex())
    return mapElementwiseC(a, sqrtComplex);
  // Real input: a negative number has no real square root, so it gets the
  // complex one (sqrt(-4) is 2i), as in MATLAB. Non-negative input takes
  // the plain real path, unchanged.
  return mapElementwisePromoting(
      a, [](double x) { return sqrt(x); }, [](double x) { return x < 0.0; }, sqrtComplex);
}

Value cbrt_op(Value a) {
  // Complex input: the principal cube root, z^(1/3). That is not the real
  // root for a negative number held as complex - cbrt(complex(-8, 0)) is
  // 1+1.732i, while the real cbrt(-8) below is -2.
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) {
      return z == Cplx(0.0, 0.0) ? Cplx(0.0, 0.0) : std::pow(z, 1.0 / 3.0);
    });
  return mapElementwisePure(a, [](double x) { return cbrt(x); });
}

// Complex sqr/cube multiply rather than call pow(), so results that should
// be whole are exact: sqr(1+2i) is -3+4i.
Value sqr_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return z * z; });
  return mapElementwisePure(a, [](double x) { return x * x; });
}

Value cube_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return z * z * z; });
  return mapElementwisePure(a, [](double x) { return x * x * x; });
}

Value log_op(Value a) {
  // Natural logarithm (base e), matching MATLAB's log(): exp(log(x)) == x
  // and log(exp(x)) == x. Base 10 is still available as logb10(x).
  // IEEE-754/C99 log() already gives the mathematically correct answer
  // for every input with no guard needed: log(0) -> -Infinity (the real
  // limit as x->0+), log(negative) -> NaN (undefined over the reals -
  // its well-defined answer is complex, which this language doesn't have a
  // type for). The previous guard substituted a human-readable error
  // *string* in place of a number for both cases, which was never a valid
  // Value to do arithmetic on further - -Infinity/NaN both are.
  // Complex input: the principal branch, imaginary part in (-pi, pi].
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::log(z); });
  // Real input: the log of a negative number is complex (log(-1) is pi*i),
  // as in MATLAB. log(0) is still -inf, and positive input is unchanged.
  return mapElementwisePromoting(
      a, [](double x) { return log(x); }, [](double x) { return x < 0.0; },
      [](Cplx z) { return std::log(z); });
}

Value log_base(Value base, Value val) {
  // Same reasoning as log_op: let log()/log() flow through unguarded and
  // pick up the IEEE-754-correct result for every previously-special-cased
  // input, rather than returning an error string in its place -
  //   val<=0:    log(val) is -Infinity (val==0) or NaN (val<0), same as
  //              log_op above.
  //   base<=0:   log(base) is likewise -Infinity or NaN, propagating
  //              through the division the same way any NaN/Infinity does.
  //   base==1:   log(1)==0, so this is log(val)/0 - a signed Infinity for
  //              val!=1 (the base-1 logarithm genuinely diverges), or
  //              log(1)/log(1) = 0/0 = NaN for val==1 (indeterminate,
  //              matching log_base(1,1) having no well-defined answer).
  // A dec2frac()-style "num/denom" text argument is read as its numeric
  // value (same coercion +,-,*,/ already apply); before this, logb4(F) read
  // the text Value's .number (0) and silently returned -inf.
  // Complex value: log(z) / log(base), elementwise for an array/matrix.
  if (val.hasComplex()) {
    const double realBase = base.number;
    return mapElementwiseC(val, [realBase](Cplx z) { return std::log(z) / std::log(realBase); });
  }
  double v = val.number, b = base.number, d;
  if (val.isText && val.text().find('/') != std::string::npos && tryCoerceTextToNumber(val, d))
    v = d;
  if (base.isText && base.text().find('/') != std::string::npos && tryCoerceTextToNumber(base, d))
    b = d;
  // A negative value has a complex logarithm (same rule as log_op). Only
  // for a usable base: base 0 and base 1 keep their existing results.
  if (v < 0.0 && b > 0.0 && b != 1.0)
    return mapElementwiseC(Value(v), [b](Cplx z) { return std::log(z) / std::log(b); });
  return Value(log(v) / log(b));
}

Value exp_op(Value a) {
  if (a.hasComplex())
    return mapElementwiseC(a, [](Cplx z) { return std::exp(z); });
  return mapElementwisePure(a, [](double x) { return exp(x); });
}

/* ================= FRACTIONS ================= */

// Continued-fraction decimal <-> fraction conversion (2026-09-24 rewrite -
// same hardening pass as factorial: extend correctness to more inputs
// instead of only the common case, and stop silently returning wrong
// answers for inputs the old code didn't handle). The previous dec2frac()
// used a fixed denominator of 1,000,000 for every input, which:
//   (a) never found the actual simplest fraction - 0.142857142857143
//       stayed "142857/1000000" instead of resolving to "1/7";
//   (b) computed `(int)(x * 1000000)` - a 32-bit int, silently overflowing
//       (wrapping to garbage, not erroring) for any |x| roughly >= 2147;
//   (c) converted NaN/+-inf straight to `int`, which is undefined
//       behavior in C++, not just a wrong answer.
// This uses the standard continued-fraction convergent algorithm (the same
// idea behind Python's Fraction.limit_denominator) with a denominator cap
// that keeps every intermediate product inside a long long's range.
static constexpr long long kFractionMaxDenominator = 1000000000LL;
static constexpr double kFractionEpsilon = 1e-9;

static bool decimalToFractionParts(double x, long long &numOut, long long &denOut) {
  if (!std::isfinite(x))
    return false;

  bool neg = x < 0;
  double val = std::fabs(x);

  // A fraction with denominator <= kFractionMaxDenominator can't add any
  // precision beyond rounding to the nearest integer once |x| itself
  // already exceeds that cap, and running the continued-fraction loop
  // below on such a value risks overflowing the h/k recurrence. Round
  // instead - the old fixed-denominator code effectively did the same
  // thing for any magnitude past its 6-decimal-digit window, just via
  // silent int overflow instead of an intentional, safe fallback.
  if (val >= (double)kFractionMaxDenominator) {
    long long rounded = (long long)std::llround(val);
    numOut = neg ? -rounded : rounded;
    denOut = 1;
    return true;
  }

  // Standard continued-fraction convergent recurrence:
  //   h(-1)=1, h(-2)=0, k(-1)=0, k(-2)=1
  //   a_i = floor(x_i); h_i = a_i*h(i-1) + h(i-2); k_i likewise
  //   x(i+1) = 1 / (x_i - a_i)
  // h_i/k_i converges to val; stopping early (remainder below epsilon, or
  // the next term would blow past the denominator cap) yields the
  // simplest fraction within that precision/size budget, rather than a
  // decimal blindly truncated to a fixed number of digits.
  long long hPrev2 = 0, hPrev1 = 1;
  long long kPrev2 = 1, kPrev1 = 0;
  long long h = 0, k = 1; // fallback convergent if nothing below gets accepted: "0/1"

  double cur = val;
  for (int i = 0; i < 64; i++) {
    long long a = (long long)std::floor(cur);
    if (a > kFractionMaxDenominator)
      break; // next term would overflow the h/k recurrence - stop here
    long long hNext = a * hPrev1 + hPrev2;
    long long kNext = a * kPrev1 + kPrev2;
    if (kNext > kFractionMaxDenominator || kNext <= 0)
      break;
    h = hNext; k = kNext;
    hPrev2 = hPrev1; hPrev1 = h;
    kPrev2 = kPrev1; kPrev1 = k;
    double rem = cur - (double)a;
    if (rem < kFractionEpsilon)
      break;
    cur = 1.0 / rem;
  }

  numOut = neg ? -h : h;
  denOut = k;
  return true;
}

// Reduces a decimal number to an exact "num/denom" text Value. Returns a
// text Value("0") + prints an error for non-finite input (NaN/+-inf) -
// factorial() rejects those the same way for the same reason: there is no
// finite fraction that represents them.
static Value decimalScalarToFractionValue(double x) {
  long long num, den;
  if (!decimalToFractionParts(x, num, den)) {
    std::cerr << "Error: dec2frac requires a finite number, got "
              << (std::isnan(x) ? "NaN" : (x > 0 ? "+inf" : "-inf")) << "\n";
    return Value(std::string("0"));
  }
  long long g = std::gcd(num < 0 ? -num : num, den);
  if (g > 1) { num /= g; den /= g; }
  std::stringstream ss;
  ss << num << "/" << den;
  return Value(ss.str());
}

// Parses "num/denom" (or a plain decimal written as text) back into a
// double. ok=false on a malformed string - previously std::stod would
// throw uncaught on garbage like "abc/def" and crash the interpreter;
// that's now a reported failure instead of a crash. A zero denominator is
// NOT special-cased to silently return 0 (as the old code did) - it's
// left to IEEE division, exactly like every other division in this file
// (see div_op): "5/0" correctly yields +inf, "0/0" yields NaN.
static double fractionTextToDecimalScalar(const std::string &text, bool &ok) {
  ok = true;
  size_t slash = text.find('/');
  try {
    if (slash != std::string::npos) {
      double num = std::stod(text.substr(0, slash));
      double denom = std::stod(text.substr(slash + 1));
      return num / denom;
    }
    return std::stod(text); // lenient: a plain decimal written as text
  } catch (const std::exception &) {
    ok = false;
    return 0.0;
  }
}

// Auto-coercion for arithmetic/factorial (2026-09-24): dec2frac()/
// deci2frac() print a "num/denom" TEXT Value purely for human-readable
// display - the same role MATLAB's own display-only rats() plays - but
// underneath it's still a real number. Rather than rejecting that text
// outright wherever a number is expected (+,-,*,/,%,//,^, factorial),
// those call sites use this to transparently read its numeric value
// first, the same way Python's Fraction/Julia's Rational stay usable in
// further math despite printing as text. Genuinely non-numeric text
// ("abc") still fails to coerce (ok=false), and the caller reports that
// exactly as before - this only ever widens what's accepted, never
// silently accepts garbage.
bool tryCoerceTextToNumber(const Value &v, double &out) {
  if (!v.isText)
    return false;
  bool ok;
  out = fractionTextToDecimalScalar(v.text(), ok);
  return ok;
}

Value frac2deci(Value a) {
  // Arrays/matrices apply elementwise (NumPy/SciPy Parity Roadmap - same
  // reasoning as every other op in this file: previously unhandled here,
  // so e.g. frac2deci(["1/2","3/4"]) fell through to the a.number==0
  // default and silently returned 0 instead of an array). Built by hand
  // rather than via mapElementwise()/zipElementwise(): those only ever
  // read/write a Value's plain `.number`, but a fraction element here is
  // itself a TEXT Value ("1/2"), which those helpers don't understand.
  if (a.isMatrix) {
    Value result = a;
    result.transformElems([](const Value &cell) {
      bool ok;
      double d = cell.isText ? fractionTextToDecimalScalar(cell.text(), ok)
                              : (ok = true, cell.number);
      if (!ok)
        std::cerr << "Error: frac2deci: malformed fraction text '" << cell.text() << "'\n";
      return Value(ok ? d : 0.0);
    });
    return result;
  }
  if (a.isArray) {
    Value result = a;
    result.transformElems([](const Value &elem) {
      bool ok;
      double d = elem.isText ? fractionTextToDecimalScalar(elem.text(), ok)
                              : (ok = true, elem.number);
      if (!ok)
        std::cerr << "Error: frac2deci: malformed fraction text '" << elem.text() << "'\n";
      return Value(ok ? d : 0.0);
    });
    return result;
  }

  // dec2frac()/deci2frac() return a TEXT Value "num/denom" - parse that
  // back into its decimal value. Reading a.number directly (as this used
  // to) silently gives 0 for a text Value, breaking the
  // frac2deci(dec2frac(x)) round trip.
  if (a.isText) {
    bool ok;
    double d = fractionTextToDecimalScalar(a.text(), ok);
    if (!ok) {
      std::cerr << "Error: frac2deci: malformed fraction text '" << a.text() << "'\n";
      return Value(0.0);
    }
    return Value(d);
  }

  // Compatibility wrapper: fraction is already evaluated as a numeric
  // value (e.g. NC's parser evaluates a literal fraction expression like
  // 3/4 directly, before this builtin ever sees it).
  return Value(a.number);
}

Value dec2frac(Value a) {
  // dec2frac's contract is "decimal number in, fraction text out" - a
  // text input has no .number to convert (it silently read 0 before an
  // earlier fix this session, e.g. dec2frac("0.5") gave "0/1"). Now that
  // dec2frac()'s own TEXT output is meant to auto-coerce back to a number
  // elsewhere (tryCoerceTextToNumber, just above), the same coercion
  // applies here too for consistency - dec2frac(deci2frac(x)) round-trips
  // instead of erroring, and dec2frac("0.5") works instead of failing.
  // Only genuinely non-numeric text ("abc") is still rejected.
  if (a.isText) {
    double d;
    if (!tryCoerceTextToNumber(a, d)) {
      std::cerr << "Error: dec2frac requires a number, not text\n";
      return Value(std::string("0"));
    }
    a = Value(d);
  }

  // Matrices are Eigen-backed and numeric-only throughout this codebase -
  // printMatrix() (output.cpp) always formats a cell via its .number,
  // never checking isText, so writing a fraction TEXT Value into a matrix
  // cell doesn't error, it just prints as "0" (a text Value's .number
  // default) for every cell - a silent-wrong-answer trap, not a working
  // feature. Reject it instead of producing a matrix that looks like it
  // worked but silently lost every value. Arrays don't have this problem -
  // formatArray() does check isText per element - so array input still
  // gets real elementwise conversion just below.
  if (a.isMatrix) {
    std::cerr << "Error: dec2frac does not support matrix input (a "
                  "fraction is text; this codebase's matrices are "
                  "numeric-only) - convert element-by-element instead\n";
    return Value(std::string("0"));
  }
  if (a.isArray) {
    Value result = a;
    result.transformElems(
        [](const Value &elem) { return decimalScalarToFractionValue(elem.number); });
    return result;
  }

  return decimalScalarToFractionValue(a.number);
}

// Compatibility wrapper: required by tests name.
Value deci2frac(Value a) { return dec2frac(a); }

