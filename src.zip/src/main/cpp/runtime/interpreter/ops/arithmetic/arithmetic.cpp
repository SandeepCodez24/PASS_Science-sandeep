#include "arithmetic.h"
#include "../matrix/matrix.h"
#include "../matrix/matrix_arithmetic.h"
#include <cmath>
#include <numeric>
#include <sstream>

using Eigen::MatrixXd;

/* ================= BASIC ================= */

Value add(Value a, Value b) {
  if (a.isMatrix && b.isMatrix)
    return matrix_add(a, b);

  if (a.isMatrix && !b.isMatrix)
    return matrix_scalar_add(a, b);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_add(a, b);

  // Dimensional Integrity: +/- require matching dimensions — that
  // compatibility check happens at the call site (Parser::parseExpression,
  // which has evaluationSucceeded_/std::cerr to report it clearly), not
  // here. Assuming the caller already validated it, the result keeps the
  // (shared) dimension.
  Value result(a.number + b.number);
  result.dimL = a.dimL; result.dimT = a.dimT; result.dimM = a.dimM;
  return result;
}

Value sub(Value a, Value b) {
  if (a.isMatrix && b.isMatrix)
    return matrix_sub(a, b);

  if (a.isMatrix && !b.isMatrix)
    return matrix_scalar_sub(a, b);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_sub(a, b);

  Value result(a.number - b.number);
  result.dimL = a.dimL; result.dimT = a.dimT; result.dimM = a.dimM;
  return result;
}

Value mul(Value a, Value b) {
  if (a.isMatrix && b.isMatrix) {
    MatrixXd m1 = toEigenMat(a);
    MatrixXd m2 = toEigenMat(b);

    /* safety guard: matrix multiplication rule */

    if (m1.cols() != m2.rows())
      return Value(0);

    MatrixXd r = m1 * m2;

    return toValue(r);
  }

  if (a.isMatrix && !b.isMatrix)
    return scalar_matrix_mul(b, a);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_mul(a, b);

  // Dimensional Integrity: unlike +/-, * always combines cleanly (exponents
  // add) — there's no incompatible case to reject, so no check is needed
  // at the call site for this operator.
  Value result(a.number * b.number);
  result.dimL = a.dimL + b.dimL;
  result.dimT = a.dimT + b.dimT;
  result.dimM = a.dimM + b.dimM;
  return result;
}

Value div_op(Value a, Value b) {
  if (a.isMatrix && b.isMatrix)
    return matrix_div(a, b);

  if (a.isMatrix && !b.isMatrix)
    return matrix_scalar_div(a, b);

  if (!a.isMatrix && b.isMatrix)
    return scalar_matrix_div(a, b);

  if (b.number == 0)
    return Value(0);

  Value result(a.number / b.number);
  result.dimL = a.dimL - b.dimL;
  result.dimT = a.dimT - b.dimT;
  result.dimM = a.dimM - b.dimM;
  return result;
}

Value mod_op(Value a, Value b) {
  if ((int)b.number == 0)
    return Value(0);
  return Value((int)a.number % (int)b.number);
}

Value quotient(Value a, Value b) {
  if ((int)b.number == 0)
    return Value(0);
  return Value((double)((int)a.number / (int)b.number));
}

Value power(Value a, Value b) {
  /* MATRIX POWER */

  if (a.isMatrix) {
    MatrixXd m = toEigenMat(a);

    int p = (int)b.number;

    /* handle inverse */

    if (p == -1)
      return toValue(m.inverse());

    /* handle identity */

    if (p == 0)
      return toValue(MatrixXd::Identity(m.rows(), m.cols()));

    /* positive power */

    MatrixXd r = m;

    for (int i = 1; i < p; i++)
      r = r * m;

    return toValue(r);
  }

  /* SCALAR POWER */

  if (!a.isMatrix) {
    // Dimensional Integrity: raising a unit-tagged value to a power
    // multiplies each dimension exponent by it (e.g. (m/s)^2 = L^2 T^-2).
    // Only meaningful for an integer power of a unit-bearing base; b itself
    // being unit-bearing (a "3 meters"-th power) isn't a sensible operation
    // and isn't specially guarded against here — same "no check needed,
    // there's no ambiguous case" reasoning as mul()/div_op() above.
    Value result(pow(a.number, b.number));
    int p = (int)b.number;
    result.dimL = a.dimL * p;
    result.dimT = a.dimT * p;
    result.dimM = a.dimM * p;
    return result;
  }

  /* SAFETY RETURN */

  return Value(0);
}

/* ================= FACTORIAL ================= */

Value factorial(Value a) {
  if (a.isText || a.isArray)
    return Value(0);

  if (a.number < 0)
    return Value(0);

  int n = (int)a.number;

  double result = 1;

  for (int i = 2; i <= n; i++)
    result *= i;

  return Value(result);
}

/* ================= BASIC FUNCTIONS ================= */

Value abs_op(Value a) { return Value(fabs(a.number)); }

Value sqrt_op(Value a) {
  if (a.number < 0)
    return Value(0);
  return Value(sqrt(a.number));
}

Value cbrt_op(Value a) { return Value(cbrt(a.number)); }

Value sqr_op(Value a) { return Value(a.number * a.number); }

Value cube_op(Value a) { return Value(a.number * a.number * a.number); }

Value log_op(Value a) {
  if (a.number <= 0)
    return Value(0);
  return Value(log10(a.number));
}

Value log_base(Value base, Value val) {
  if (base.number <= 0 || val.number <= 0)
    return Value(0);
  return Value(log(val.number) / log(base.number));
}

Value exp_op(Value a) { return Value(exp(a.number)); }

/* ================= FRACTIONS ================= */

Value frac2dec(Value a) { return Value(a.number); }

// Compatibility wrapper: fraction is already evaluated as a numeric value.
Value frac2deci(Value a) { return Value(a.number); }

Value dec2frac(Value a) {
  double x = a.number;

  int denom = 1000000;
  int num = (int)(x * denom);

  int g = std::gcd(num, denom);

  num /= g;
  denom /= g;

  std::stringstream ss;
  ss << num << "/" << denom;

  return Value(ss.str());
}

// Compatibility wrapper: required by tests name.
Value deci2frac(Value a) { return dec2frac(a); }

// log base 2 using natural log: log(x)/log(2)
Value logb2_op(Value a) {
  if (a.number <= 0)
    return Value(0);
  return Value(log(a.number) / log(2.0));
}
