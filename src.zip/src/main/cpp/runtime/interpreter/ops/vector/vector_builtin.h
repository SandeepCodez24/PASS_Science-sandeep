#pragma once

#include "../../core/value.h"

#include <string>
#include <vector>

// Dispatcher for vector builtins
Value vectorBuiltin(const std::string &name, const std::vector<Value> &args);
