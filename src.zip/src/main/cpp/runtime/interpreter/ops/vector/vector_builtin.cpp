#include "vector_builtin.h"
#include "vector.h"

#include <functional>
#include <iostream>
#include <unordered_map>

Value vectorBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= BASIC VECTOR OPS ================= */

      {"Dot",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Dot", 2))
           return Value();
         return Dot(a[0], a[1]);
       }},

      {"Cross",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Cross", 2))
           return Value();
         return VectorCross(a[0], a[1]);
       }},

      {"VectorCross",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("VectorCross", 2))
           return Value();
         return VectorCross(a[0], a[1]);
       }},

      {"dircos",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("dircos", 1))
           return Value();
         return dircos(a[0]);
       }},

      /* ================= VECTOR NORMALIZATION ================= */

      {"unit_vector",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("unit_vector", 1))
           return Value();
         return unit_vector(a[0]);
       }},

      {"norm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("norm", 1))
           return Value();
         return Vec_Norm(a[0]);
       }},

      {"norm_vector",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("norm_vector", 1))
           return Value();
         return Vec_Norm(a[0]);
       }},

      {"Norm",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Norm", 1))
           return Value();
         return Vec_Norm(a[0]);
       }},

      /* ================= ANGLES ================= */

      {"Angle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Angle", 2))
           return Value();
         return Angle(a[0], a[1]);
       }},

      {"angle",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("angle", 2))
           return Value();
         return Angle(a[0], a[1]);
       }},

      /* ================= PROJECTION ================= */

      {"Projection",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Projection", 2))
           return Value();
         return Projection(a[0], a[1]);
       }},

      {"ProjectionVec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("ProjectionVec", 2))
           return Value();
         return Projection(a[0], a[1]);
       }},

      {"proj",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("proj", 2))
           return Value();
         return Projection(a[0], a[1]);
       }},

      {"proj_vec",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("proj_vec", 1))
           return Value();
         return proj_vec(a[0]);
       }},

      /* ================= ORTHOGONALITY ================= */

      {"orthogonal",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("orthogonal", 1))
           return Value();
         return orthogonal(a[0]);
       }},

      {"orthonormal",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("orthonormal", 1))
           return Value();
         return orthonormal(a[0]);
       }},

      /* ================= EIGEN ================= */

      {"eigen_value",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("eigen_value", 1))
           return Value();
         return eigen_value(a[0]);
       }},

      {"eigen_vector",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("eigen_vector", 1))
           return Value();
         return eigen_vector(a[0]);
       }},

      /* ================= VECTOR CALCULUS ================= */

      {"divergence",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("divergence", 1))
           return Value();
         return divergence(a[0]);
       }},

      {"curl",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("curl", 1))
           return Value();
         return Curl(a[0]);
       }},

      {"Curl",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Curl", 1))
           return Value();
         return Curl(a[0]);
       }},

      /* ================= VECTOR TENSOR PRODUCT ================= */

      {"vector_tp",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("vector_tp", 3))
           return Value();
         return vector_tp(a[0], a[1], a[2]);
       }},

      {"vector_TP",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("vector_TP", 3))
           return Value();
         return vector_tp(a[0], a[1], a[2]);
       }},

      {"VectorTP",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("VectorTP", 3))
           return Value();
         return vector_tp(a[0], a[1], a[2]);
       }},

      {"vectorTP",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("vectorTP", 3))
           return Value();
         return vector_tp(a[0], a[1], a[2]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown vector function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}