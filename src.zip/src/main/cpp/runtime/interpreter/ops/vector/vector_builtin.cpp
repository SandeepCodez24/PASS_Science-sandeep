#include "vector_builtin.h"
#include "vector.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

Value vectorBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      // Was missing: unlike the equivalent fix already made in
      // statistics_builtin.cpp's require_arity, this never flagged the
      // failure - the caller's Value() default (number=0) was silently
      // treated as a successful result, so e.g. `z = dot([1,2,3]); z`
      // (wrong arity) silently assigned z=0 instead of leaving z unset.
      g_lastVectorOk = false;
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= BASIC VECTOR OPS ================= */

      {"dot",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "dot", 2))
           return Value();
         return Dot(a[0], a[1]);
       }},

      {"cross",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "cross", 2))
           return Value();
         return VectorCross(a[0], a[1]);
       }},

      {"dircos",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "dircos", 1))
           return Value();
         return dircos(a[0]);
       }},

      /* ================= VECTOR NORMALIZATION ================= */

      {"unit_vector",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "unit_vector", 1))
           return Value();
         return unit_vector(a[0]);
       }},

      {"norm",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "norm", 1))
           return Value();
         return Vec_Norm(a[0]);
       }},

      {"norm_vector",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "norm_vector", 1))
           return Value();
         return Vec_Norm(a[0]);
       }},

      /* ================= ANGLES ================= */

      {"angle",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "angle", 2))
           return Value();
         return Angle(a[0], a[1]);
       }},

      /* ================= PROJECTION ================= */

      {"proj",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "proj", 2))
           return Value();
         return Projection(a[0], a[1]);
       }},

      {"proj_vec",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "proj_vec", 1))
           return Value();
         return proj_vec(a[0]);
       }},

      /* ================= ORTHOGONALITY ================= */

      {"orthogonal",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "orthogonal", 1))
           return Value();
         return orthogonal(a[0]);
       }},

      {"orthonormal",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "orthonormal", 1))
           return Value();
         return orthonormal(a[0]);
       }},

      /* ================= EIGEN ================= */

      {"eigen_value",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "eigen_value", 1))
           return Value();
         return eigen_value(a[0]);
       }},

      {"eigen_vector",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "eigen_vector", 1))
           return Value();
         return eigen_vector(a[0]);
       }},

      /* ================= VECTOR CALCULUS ================= */

      {"divergence",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "divergence", 1))
           return Value();
         return divergence(a[0]);
       }},

      {"curl",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "curl", 1))
           return Value();
         return Curl(a[0]);
       }},

      /* ================= VECTOR TENSOR PRODUCT ================= */

      {"vector_tp",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "vector_tp", 3))
           return Value();
         return vector_tp(a[0], a[1], a[2]);
       }},

      // "vector_TP" removed 2026-09-16 (was dead/unreachable code — see
      // the matching note in builtins.cpp's outer table). "vectortp"
      // below was "vectorTP": lowercased for the same reason
      // "onlyrows"/"onlycols" were in matrix_builtin.cpp - this table is
      // looked up with the exact, non-lowercased caller-typed name, so a
      // mixed-case-only key here was unreachable under any other casing.
      {"vectortp",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "vectortp", 3))
           return Value();
         return vector_tp(a[0], a[1], a[2]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16) - same reasoning as the
  // matching fix in matrix_builtin.cpp: this table's lookup used the
  // exact, non-lowercased caller-typed name, so any casing other than a
  // key's exact spelling failed, contradicting the documented
  // case-insensitive dispatch.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown vector function '" << name << "'\n";
    // Purely defensive/theoretical today (the inner table above and the
    // outer builtins.cpp table that routes here are kept in sync, so this
    // branch shouldn't currently be reachable) - added for the same reason
    // as require_arity's fix just above: a silent Value(0) here would
    // otherwise read as success.
    g_lastVectorOk = false;
    return Value();
  }

  return it->second(args);
}