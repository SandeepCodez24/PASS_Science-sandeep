#include "vector.h"
#include <cmath>

VectorXd toEigenVec(Value v)
{
    VectorXd vec(v.array.size());

for(size_t i=0;i<v.array.size();i++)        vec(i)=v.array[i].number;

    return vec;
}

/* ================= BASIC ================= */

Value Dot(Value a, Value b)
{
    VectorXd v1=toEigenVec(a);
    VectorXd v2=toEigenVec(b);

    return Value(v1.dot(v2));
}

Value VectorCross(Value a, Value b)
{
    Vector3d v1(a.array[0].number,a.array[1].number,a.array[2].number);
    Vector3d v2(b.array[0].number,b.array[1].number,b.array[2].number);

    Vector3d r=v1.cross(v2);

    std::vector<Value> res;

    res.push_back(Value(r(0)));
    res.push_back(Value(r(1)));
    res.push_back(Value(r(2)));

    return Value(res);
}

Value Vec_Norm(Value a)
{
    VectorXd v=toEigenVec(a);

    return Value(v.norm());
}

Value unit_vector(Value a)
{
    VectorXd v=toEigenVec(a);

    v=v/v.norm();

    std::vector<Value> res;

    for(int i=0;i<v.size();i++)
        res.push_back(Value(v(i)));

    return Value(res);
}

Value dircos(Value a)
{
    VectorXd v=toEigenVec(a);

    double n=v.norm();

    std::vector<Value> res;

    for(int i=0;i<v.size();i++)
        res.push_back(Value(v(i)/n));

    return Value(res);
}

Value Angle(Value a, Value b)
{
    VectorXd v1=toEigenVec(a);
    VectorXd v2=toEigenVec(b);

    double ang=acos(v1.dot(v2)/(v1.norm()*v2.norm()));

    return Value(ang);
}

Value Projection(Value a, Value b)
{
    VectorXd v1=toEigenVec(a);
    VectorXd v2=toEigenVec(b);

    double scale=v1.dot(v2)/v2.dot(v2);

    VectorXd proj=scale*v2;

    std::vector<Value> res;

    for(int i=0;i<proj.size();i++)
        res.push_back(Value(proj(i)));

    return Value(res);
}

Value vector_tp(Value a, Value b, Value c)
{
    Vector3d v1(a.array[0].number,a.array[1].number,a.array[2].number);
    Vector3d v2(b.array[0].number,b.array[1].number,b.array[2].number);
    Vector3d v3(c.array[0].number,c.array[1].number,c.array[2].number);

    double r=v1.cross(v2).dot(v3);

    return Value(r);
}

/* ================= NEW OPERATIONS ================= */

Value proj_vec(Value a)
{
    VectorXd v=toEigenVec(a);

    v=v/v.norm();

    std::vector<Value> res;

    for(int i=0;i<v.size();i++)
        res.push_back(Value(v(i)));

    return Value(res);
}

Value orthogonal(Value a)
{
    VectorXd v=toEigenVec(a);

    std::vector<Value> res;

    res.push_back(Value(-v(1)));
    res.push_back(Value(v(0)));

    return Value(res);
}

Value orthonormal(Value a)
{
    VectorXd v=toEigenVec(a);

    VectorXd ortho(2);

    ortho(0)=-v(1);
    ortho(1)=v(0);

    ortho=ortho/ortho.norm();

    std::vector<Value> res;

    res.push_back(Value(ortho(0)));
    res.push_back(Value(ortho(1)));

    return Value(res);
}

Value eigen_value(Value a)
{
    int n=sqrt(a.array.size());

    MatrixXd m(n,n);

    int k=0;

    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            m(i,j)=a.array[k++].number;

    EigenSolver<MatrixXd> es(m);

    std::vector<Value> res;

    for(int i=0;i<n;i++)
        res.push_back(Value(es.eigenvalues()[i].real()));

    return Value(res);
}

Value eigen_vector(Value a)
{
    int n=sqrt(a.array.size());

    MatrixXd m(n,n);

    int k=0;

    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            m(i,j)=a.array[k++].number;

    EigenSolver<MatrixXd> es(m);

    MatrixXd vec=es.eigenvectors().real();

    std::vector<Value> res;

    for(int i=0;i<vec.rows();i++)
        for(int j=0;j<vec.cols();j++)
            res.push_back(Value(vec(i,j)));

    return Value(res);
}
/* ================= DIVERGENCE ================= */

Value divergence(Value a)
{
    VectorXd v = toEigenVec(a);

    double sum = 0;

    for(int i=0;i<v.size();i++)
        sum += v(i);

    return Value(sum);
}


/* ================= CURL ================= */

Value Curl(Value a)
{
    Vector3d v(a.array[0].number,
               a.array[1].number,
               a.array[2].number);

    Vector3d r;

    r(0) = v(1) - v(2);
    r(1) = v(2) - v(0);
    r(2) = v(0) - v(1);

    std::vector<Value> res;

    res.push_back(Value(r(0)));
    res.push_back(Value(r(1)));
    res.push_back(Value(r(2)));

    return Value(res);
}