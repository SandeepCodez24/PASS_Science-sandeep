#include "vector.h"
#include "../matrix/matrix.h"
#include <cmath>
#include <iostream>

namespace {
// Shared by eigen_value()/eigen_vector() below. Two real bugs this closes,
// both found by direct testing:
//  1. Both functions only ever read `a.array` (a FLAT array), never
//     `a.matrix` - every other matrix operation in this codebase
//     (det/inv/rank/transpose/...) accepts the natural nested
//     `[[...],[...]]` literal via toEigenMat(), so a user reasonably
//     trying that same convention here (`eigen_value([[2,0],[0,3]])`)
//     instead got `a.length()==0` (a matrix stores its data in
//     `.matrix`, not `.array`), building a 0x0 MatrixXd and crashing
//     Eigen's EigenSolver outright (`"you are using an empty matrix"`).
//  2. For the flat-array form, `int n = sqrt(a.length())` never
//     validated that size() was actually a perfect square - a 5-element
//     array silently used only the first 4 (as a wrong 2x2 matrix),
//     dropping the 5th element with zero warning.
bool buildSquareMatrixForEigen(const Value &a, MatrixXd &outM) {
  if (a.isMatrix) {
    outM = toEigenMat(a);
    if (outM.rows() == 0 || outM.cols() == 0 || outM.rows() != outM.cols()) {
      std::cerr << "Error: expected a non-empty square matrix, got " << outM.rows() << "x"
                << outM.cols() << "\n";
      g_lastVectorOk = false;
      return false;
    }
    return true;
  }

  if (!a.isArray) {
    std::cerr << "Error: expected a matrix or a flat array of its entries\n";
    g_lastVectorOk = false;
    return false;
  }

  size_t size = a.length();
  int n = static_cast<int>(std::round(std::sqrt(static_cast<double>(size))));
  if (n <= 0 || static_cast<size_t>(n) * static_cast<size_t>(n) != size) {
    std::cerr << "Error: a flat array input must have a perfect-square length (n^2 entries "
                 "for an n x n matrix), got "
              << size << "\n";
    g_lastVectorOk = false;
    return false;
  }

  outM = MatrixXd(n, n);
  int k = 0;
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      outM(i, j) = a.numAt(k++);
  return true;
}
} // namespace

bool g_lastVectorOk = true;

VectorXd toEigenVec(Value v)
{
    // Was completely unchecked - any non-array Value (a scalar, dict,
    // object, matrix) silently produced a zero-length vector here, so
    // e.g. dot(5, 10) silently returned 0 and norm(5) silently returned 0,
    // with no error at all. Confirmed by direct testing.
    if (!v.isArray) {
        std::cerr << "Error: expected a vector (array), got a "
                  << (v.isMatrix ? "matrix" : v.isText ? "string" : v.isDict ? "dict"
                                                                              : "number")
                  << "\n";
        g_lastVectorOk = false;
        return VectorXd(0);
    }

    VectorXd vec(v.length());

for(size_t i=0;i<v.length();i++)        vec(i)=v.numAt(i);

    return vec;
}

/* ================= BASIC ================= */

Value Dot(Value a, Value b)
{
    g_lastVectorOk = true;
    VectorXd v1=toEigenVec(a);
    VectorXd v2=toEigenVec(b);
    if (!g_lastVectorOk)
        return Value(0);

    // No length-match check existed at all - v1.dot(v2) on mismatched
    // sizes crashes the whole process via Eigen's own internal assertion
    // (`Assertion failed: (size() == other.size())`), confirmed by direct
    // testing (`dot([1,2,3],[1,2])`). Angle()/Projection() below share
    // this exact same underlying hazard, since they also call .dot().
    if (v1.size() != v2.size()) {
        std::cerr << "Error: dot requires two vectors of the same length (got "
                  << v1.size() << " and " << v2.size() << ")\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    return Value(v1.dot(v2));
}

Value VectorCross(Value a, Value b)
{
    // Cross product is only defined for 3D vectors. Without this check, a
    // non-length-3 or non-array input silently reads out-of-bounds into
    // a.at(0..2)/b.at(0..2) instead of failing loudly.
    if (!a.isArray || a.length() != 3 ||
        !b.isArray || b.length() != 3)
        return Value("cross expects two 3-element vectors (arrays of "
                     "length 3)");

    Vector3d v1(a.numAt(0),a.numAt(1),a.numAt(2));
    Vector3d v2(b.numAt(0),b.numAt(1),b.numAt(2));

    Vector3d r=v1.cross(v2);

    std::vector<Value> res;

    res.push_back(Value(r(0)));
    res.push_back(Value(r(1)));
    res.push_back(Value(r(2)));

    return Value(res);
}

Value Vec_Norm(Value a)
{
    g_lastVectorOk = true;
    VectorXd v=toEigenVec(a);
    if (!g_lastVectorOk)
        return Value(0);

    return Value(v.norm());
}

Value unit_vector(Value a)
{
    g_lastVectorOk = true;
    VectorXd v=toEigenVec(a);
    if (!g_lastVectorOk)
        return Value(0);

    // A zero vector has no direction - "unit vector" is mathematically
    // undefined for it, not "some direction" - so dividing by v.norm()==0
    // silently produced [nan,nan,...] with no error at all. Confirmed by
    // direct testing (unit_vector([0,0])).
    if (v.norm() == 0) {
        std::cerr << "Error: unit_vector is undefined for a zero vector\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    v=v/v.norm();

    std::vector<Value> res;

    for(int i=0;i<v.size();i++)
        res.push_back(Value(v(i)));

    return Value(res);
}

Value dircos(Value a)
{
    g_lastVectorOk = true;
    VectorXd v=toEigenVec(a);
    if (!g_lastVectorOk)
        return Value(0);

    // Direction cosines are undefined for a zero vector (no direction to
    // measure angles against) - dividing by n==0 below silently produced
    // [nan,nan,...] with no error. Same hazard as unit_vector() above.
    if (v.norm() == 0) {
        std::cerr << "Error: dircos is undefined for a zero vector\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    double n=v.norm();

    std::vector<Value> res;

    for(int i=0;i<v.size();i++)
        res.push_back(Value(v(i)/n));

    return Value(res);
}

Value Angle(Value a, Value b)
{
    g_lastVectorOk = true;
    VectorXd v1=toEigenVec(a);
    VectorXd v2=toEigenVec(b);
    if (!g_lastVectorOk)
        return Value(0);

    // Same missing length-match check as Dot() above (Angle() calls .dot()
    // internally too) - `angle([1,2,3],[1,2])` used to crash the process
    // via Eigen's own assertion instead of failing cleanly.
    if (v1.size() != v2.size()) {
        std::cerr << "Error: angle requires two vectors of the same length (got "
                  << v1.size() << " and " << v2.size() << ")\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    double ang=acos(v1.dot(v2)/(v1.norm()*v2.norm()));

    return Value(ang);
}

Value Projection(Value a, Value b)
{
    g_lastVectorOk = true;
    VectorXd v1=toEigenVec(a);
    VectorXd v2=toEigenVec(b);
    if (!g_lastVectorOk)
        return Value(0);

    // Same missing length-match check as Dot()/Angle() above (Projection()
    // calls .dot() internally too) - `proj([1,2,3],[1,2])` used to crash
    // the process via Eigen's own assertion instead of failing cleanly.
    if (v1.size() != v2.size()) {
        std::cerr << "Error: proj requires two vectors of the same length (got "
                  << v1.size() << " and " << v2.size() << ")\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    // Projecting onto a zero vector is undefined (no direction to project
    // onto) - dividing by v2.dot(v2)==0 silently produced [nan,nan,...]
    // with no error. Same hazard as unit_vector()/dircos()/orthonormal()
    // above.
    if (v2.dot(v2) == 0) {
        std::cerr << "Error: proj is undefined when projecting onto a zero vector\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    double scale=v1.dot(v2)/v2.dot(v2);

    VectorXd proj=scale*v2;

    std::vector<Value> res;

    for(int i=0;i<proj.size();i++)
        res.push_back(Value(proj(i)));

    return Value(res);
}

Value vector_tp(Value a, Value b, Value c)
{
    // a/b/c must each be a length-3 array (this is the 3D scalar triple
    // product). Without this check, a non-length-3 or non-array input
    // silently reads out-of-bounds into a.at(0..2) instead of failing
    // loudly.
    if (!a.isArray || a.length() != 3 ||
        !b.isArray || b.length() != 3 ||
        !c.isArray || c.length() != 3)
        return Value("vector_tp expects three 3-element vectors (arrays of "
                     "length 3)");

    Vector3d v1(a.numAt(0),a.numAt(1),a.numAt(2));
    Vector3d v2(b.numAt(0),b.numAt(1),b.numAt(2));
    Vector3d v3(c.numAt(0),c.numAt(1),c.numAt(2));

    double r=v1.cross(v2).dot(v3);

    return Value(r);
}

/* ================= NEW OPERATIONS ================= */

// Deliberate alias for unit_vector() - NOT a projection of `a` onto
// anything, despite the name. Found via direct testing to be byte-for-byte
// identical code to unit_vector() above; flagged here rather than changed,
// since (a) the actual math it computes is correct (a valid unit vector),
// just mislabeled, and (b) any script already calling proj_vec(v) as a
// 1-argument normalizer would break if this were changed to require a
// second "project onto" vector to match its name - a real fix would need a
// new, differently-named function instead of repurposing this one.
// Documented the same way this codebase already documents other
// intentional cross-domain aliases (see calculus.cpp's Curl_Calc()/Div()
// comments) so a future reader sees this as a known, deliberate quirk
// rather than uninvestigated duplicate code.
Value proj_vec(Value a)
{
    return unit_vector(a);
}

Value orthogonal(Value a)
{
    g_lastVectorOk = true;
    VectorXd v=toEigenVec(a);
    if (!g_lastVectorOk)
        return Value(0);

    // Hardcoded to 2D (v(0), v(1)) with no bounds check at all - any
    // vector that isn't exactly length 2 (e.g. a 1-element or 3-element
    // array) crashed the whole process via Eigen's own out-of-bounds
    // assertion (`Assertion failed: (index >= 0 && index < size())`)
    // instead of failing cleanly. Confirmed by direct testing
    // (`orthogonal([5])`). "Rotate 90 degrees" (this function's actual
    // operation) is inherently a 2D-only concept for a single unique
    // result anyway - a 3D vector has an entire PLANE of vectors
    // orthogonal to it, not one - so rejecting anything else here is the
    // mathematically correct behavior, not just a defensive check.
    if (v.size() != 2) {
        std::cerr << "Error: orthogonal requires a 2-element vector (got " << v.size()
                  << ") - a vector orthogonal to a non-2D vector is not unique\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    std::vector<Value> res;

    res.push_back(Value(-v(1)));
    res.push_back(Value(v(0)));

    return Value(res);
}

Value orthonormal(Value a)
{
    g_lastVectorOk = true;
    VectorXd v=toEigenVec(a);
    if (!g_lastVectorOk)
        return Value(0);

    // Same 2D-only hazard and fix as orthogonal() above.
    if (v.size() != 2) {
        std::cerr << "Error: orthonormal requires a 2-element vector (got " << v.size()
                  << ") - a vector orthogonal to a non-2D vector is not unique\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    // A zero vector has no orthonormal companion (rotating a zero vector
    // 90 degrees is still zero, so ortho.norm() below is 0 too) - dividing
    // by it silently produced [nan,nan] with no error. Same hazard as
    // unit_vector()/dircos() above.
    if (v.norm() == 0) {
        std::cerr << "Error: orthonormal is undefined for a zero vector\n";
        g_lastVectorOk = false;
        return Value(0);
    }

    VectorXd ortho(2);

    ortho(0)=-v(1);
    ortho(1)=v(0);

    ortho=ortho/ortho.norm();

    std::vector<Value> res;

    res.push_back(Value(ortho(0)));
    res.push_back(Value(ortho(1)));

    return Value(res);
}

Value eigen_value(Value a)
{
    g_lastVectorOk = true;
    MatrixXd m;
    if (!buildSquareMatrixForEigen(a, m))
        return Value(0);
    int n = static_cast<int>(m.rows());

    EigenSolver<MatrixXd> es(m);

    std::vector<Value> res;

    for(int i=0;i<n;i++)
        res.push_back(Value(es.eigenvalues()[i].real()));

    return Value(res);
}

Value eigen_vector(Value a)
{
    g_lastVectorOk = true;
    MatrixXd m;
    if (!buildSquareMatrixForEigen(a, m))
        return Value(0);

    EigenSolver<MatrixXd> es(m);

    MatrixXd vec=es.eigenvectors().real();

    std::vector<Value> res;

    for(int i=0;i<vec.rows();i++)
        for(int j=0;j<vec.cols();j++)
            res.push_back(Value(vec(i,j)));

    return Value(res);
}
/* ================= DIVERGENCE ================= */

// NOTE: this is NOT the textbook vector-calculus divergence operator
// (∇·F, the sum of a vector FIELD's partial derivatives w.r.t. position).
// It's a sum of a single constant vector's own components. Flagged
// 2026-09-16 as a real name-vs-math mismatch, not fixed here since a
// correct implementation needs a symbolic/field representation NC
// doesn't have yet (see docs/V0_Function_Verification_Checklist.md §6)
// - left as a documented simplification pending that design decision.
Value divergence(Value a)
{
    // Was missing the reset every other function in this file does at
    // entry - toEigenVec() only ever sets g_lastVectorOk FALSE (on invalid
    // input), never back to true, so a prior unrelated vector call's
    // failure earlier in the same script left this flag false, and a
    // completely valid divergence(...) call afterward had its correct
    // result silently discarded by the interpreter (the assignment never
    // landed) - confirmed by direct testing.
    g_lastVectorOk = true;
    VectorXd v = toEigenVec(a);
    if (!g_lastVectorOk)
        return Value(0);

    double sum = 0;

    for(int i=0;i<v.size();i++)
        sum += v(i);

    return Value(sum);
}


/* ================= CURL ================= */

// NOTE: same caveat as divergence() above - this is NOT the textbook
// curl operator (∇×F, a vector field's partial derivatives). It's a
// cyclic-difference formula on a single constant 3-vector's components.
// Documented simplification, not fixed here - see
// docs/V0_Function_Verification_Checklist.md §6.
Value Curl(Value a)
{
    // Same stale-flag hazard divergence() had (see its own comment above),
    // defensively closed here too even though it wasn't independently
    // reproducible for this function in testing: Curl() never reads
    // g_lastVectorOk itself, but the outer dispatcher checks it after
    // every vector-domain call regardless, so leaving a prior statement's
    // failure flag lingering here risks the same silently-discarded-valid-
    // result class of bug.
    g_lastVectorOk = true;

    // Only defined for 3D vectors. Without this check, a non-length-3 or
    // non-array input silently read out-of-bounds into a.at(0..2)
    // instead of failing loudly - same class of bug cross()/vector_tp()
    // had before their 2026-09-16 fix. Deliberately returns a string error
    // Value WITHOUT touching g_lastVectorOk here, same as the pre-existing,
    // still-functional convention VectorCross()/vector_tp() already use for
    // this same kind of shape validation - not the class of bug being fixed
    // in this pass.
    if (!a.isArray || a.length() != 3)
        return Value("curl expects a 3-element vector (array of length 3)");

    Vector3d v(a.numAt(0),
               a.numAt(1),
               a.numAt(2));

    Vector3d r;

    r(0) = v(1) - v(2);
    r(1) = v(2) - v(0);
    r(2) = v(0) - v(1);

    std::vector<Value> res;

    res.push_back(Value(r(0)));
    res.push_back(Value(r(1)));
    res.push_back(Value(r(2)));

    return Value(res);
}