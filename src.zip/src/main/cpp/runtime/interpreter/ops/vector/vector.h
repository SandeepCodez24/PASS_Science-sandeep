#ifndef VECTOR_H
#define VECTOR_H

#include "../../core/value.h"
#include <Eigen/Dense>

using namespace Eigen;

// Set true at the start of every public vector.cpp function, before it
// calls toEigenVec()/does its own shape validation; false when an input is
// rejected (not an array, mismatched lengths between two operands, wrong
// length for a fixed-dimension op like orthogonal()'s 2D-only shape).
// Same "global out-of-band status flag" convention elementwise.h's
// g_lastElementwiseOk already uses, for the same reason: these are plain
// free functions with no Parser access to set evaluationSucceeded_
// directly. Checked in parser_factor.cpp's ExprKind::Call case (and
// nc_bridge_call_dynamic, value_bridge.cpp) right alongside the existing
// g_lastBuiltinFound check - that flag only means "the NAME 'dot'/'angle'/
// ... was found in a dispatch table", not "the actual computation
// succeeded with valid inputs", so a genuinely-found name with invalid
// arguments needs this separate signal. Before this flag existed, several
// vector functions had no input validation at all: toEigenVec() silently
// treated ANY non-array Value as an empty vector (dot(5,10) silently
// returned 0), and Dot()/Angle()/Projection() had no length-match check
// between their two operands at all, letting Eigen's own internal
// assertion crash the whole process on a mismatch
// (`Assertion failed: (size() == other.size())`) instead of failing
// cleanly - confirmed by direct testing.
extern bool g_lastVectorOk;

VectorXd toEigenVec(Value v);

Value Dot(Value a, Value b);
// Value Cross(Value a, Value b);
Value VectorCross(Value a, Value b);
Value Vec_Norm(Value a);
Value unit_vector(Value a);
Value dircos(Value a);
Value Angle(Value a, Value b);
Value Projection(Value a, Value b);
Value vector_tp(Value a, Value b, Value c);

/* NEW OPERATIONS */

Value proj_vec(Value a);
Value orthogonal(Value a);
Value orthonormal(Value a);
Value eigen_value(Value a);
Value eigen_vector(Value a);
Value divergence(Value a);
Value Curl(Value a);

#endif