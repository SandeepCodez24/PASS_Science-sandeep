#ifndef VECTOR_H
#define VECTOR_H

#include "../../core/value.h"
#include <Eigen/Dense>

using namespace Eigen;

VectorXd toEigenVec(Value v);

Value Dot(Value a, Value b);
// Value Cross(Value a, Value b);
Value VectorCross(Value a, Value b);
Value Vec_Norm(Value a);
Value unit_vector(Value a);
Value dircos(Value a);
Value Angle(Value a, Value b);
Value Projection(Value a, Value b);
Value vector_tp(Value a, Value b, Value c);

/* NEW OPERATIONS */

Value proj_vec(Value a);
Value orthogonal(Value a);
Value orthonormal(Value a);
Value eigen_value(Value a);
Value eigen_vector(Value a);
Value divergence(Value a);
Value Curl(Value a);

#endif