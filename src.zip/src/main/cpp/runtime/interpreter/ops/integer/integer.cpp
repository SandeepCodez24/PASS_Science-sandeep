#include "integer.h"

#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
#include <vector>

#include "../../core/packed_read.h"
#include "../arithmetic/arithmetic.h" // tryCoerceTextToNumber
#include "parallel/par.h"

namespace {

// ---------------------------------------------------------------------------
// Wide: one exact integer covering every int8 ... uint64 value, i.e. the
// range -2^64 + 1 ... 2^64 - 1, as a sign and a 64-bit magnitude.
//
// Deliberately NOT __int128: on the clang + lld-link (x86_64-pc-windows-msvc)
// toolchain, 128-bit multiply/divide/convert compile to calls into
// compiler-rt (__divti3, __floattidf, __fixdfti, ...), which that build does
// not link. Everything here is plain 64-bit arithmetic the CPU does
// natively, so it builds the same with clang, MinGW-gcc, gcc and MSVC.
//
// An operation whose exact result leaves that range reports overflow; such a
// result is outside every supported integer type anyway.
// ---------------------------------------------------------------------------
struct Wide
{
    bool neg = false; // never set for zero
    uint64_t mag = 0;

    static Wide fromSigned(int64_t v)
    {
        Wide w;
        w.neg = v < 0;
        // Magnitude without overflow, INT64_MIN included.
        w.mag = w.neg ? static_cast<uint64_t>(-(v + 1)) + 1u : static_cast<uint64_t>(v);
        return w;
    }
    static Wide fromUnsigned(uint64_t v)
    {
        Wide w;
        w.mag = v;
        return w;
    }
    static Wide make(bool negative, uint64_t magnitude)
    {
        Wide w;
        w.mag = magnitude;
        w.neg = negative && magnitude != 0;
        return w;
    }

    Wide negated() const { return make(!neg, mag); }

    double toDouble() const
    {
        double d = static_cast<double>(mag);
        return neg ? -d : d;
    }

    std::string toString() const { return (neg ? "-" : "") + std::to_string(mag); }
};

int compare(const Wide &a, const Wide &b)
{
    if (a.neg != b.neg)
        return a.neg ? -1 : 1;
    if (a.mag == b.mag)
        return 0;
    const bool magLess = a.mag < b.mag;
    // Both negative: the larger magnitude is the smaller number.
    return (magLess != a.neg) ? -1 : 1;
}

// a + b; false on overflow.
bool addWide(const Wide &a, const Wide &b, Wide &out)
{
    if (a.neg == b.neg) {
        uint64_t sum = a.mag + b.mag;
        if (sum < a.mag)
            return false; // magnitude past 2^64 - 1
        out = Wide::make(a.neg, sum);
        return true;
    }
    // Opposite signs: the result takes the sign of the larger magnitude.
    if (a.mag >= b.mag)
        out = Wide::make(a.neg, a.mag - b.mag);
    else
        out = Wide::make(b.neg, b.mag - a.mag);
    return true;
}

bool subWide(const Wide &a, const Wide &b, Wide &out) { return addWide(a, b.negated(), out); }

bool mulWide(const Wide &a, const Wide &b, Wide &out)
{
    if (a.mag != 0 && b.mag > std::numeric_limits<uint64_t>::max() / a.mag)
        return false;
    out = Wide::make(a.neg != b.neg, a.mag * b.mag);
    return true;
}

// Truncated quotient and remainder (C semantics: the remainder has the sign
// of the dividend). `b` must not be zero.
void divModWide(const Wide &a, const Wide &b, Wide &quot, Wide &rem)
{
    quot = Wide::make(a.neg != b.neg, a.mag / b.mag);
    rem = Wide::make(a.neg, a.mag % b.mag);
}

struct Range
{
    Wide lo;
    Wide hi;
};

Range rangeOf(IntType t)
{
    switch (t) {
    case IntType::Int8:
        return {Wide::fromSigned(INT8_MIN), Wide::fromSigned(INT8_MAX)};
    case IntType::Int16:
        return {Wide::fromSigned(INT16_MIN), Wide::fromSigned(INT16_MAX)};
    case IntType::Int32:
        return {Wide::fromSigned(INT32_MIN), Wide::fromSigned(INT32_MAX)};
    case IntType::Int64:
        return {Wide::fromSigned(INT64_MIN), Wide::fromSigned(INT64_MAX)};
    case IntType::UInt8:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT8_MAX)};
    case IntType::UInt16:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT16_MAX)};
    case IntType::UInt32:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT32_MAX)};
    case IntType::UInt64:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT64_MAX)};
    case IntType::None:
        break;
    }
    return {Wide(), Wide()};
}

bool isUnsignedType(IntType t) { return static_cast<uint8_t>(t) >= static_cast<uint8_t>(IntType::UInt8); }

// A double in error messages: 300, 5.7, 1e+30 (not 300.000000).
std::string numberText(double x)
{
    char buf[32];
    std::snprintf(buf, sizeof buf, "%.15g", x);
    return buf;
}

Wide wideOf(const Value &v)
{
    return v.intIsUnsigned() ? Wide::fromUnsigned(static_cast<uint64_t>(v.intBits()))
                             : Wide::fromSigned(v.intBits());
}

// `w` must already be inside the type's range.
Value makeInt(IntType t, const Wide &w)
{
    if (isUnsignedType(t))
        return Value::integerUnsigned(t, w.mag);
    // In range for a signed type: magnitude <= 2^63, so this is exact
    // (2^63 only when negative, giving INT64_MIN).
    const int64_t v = w.neg ? static_cast<int64_t>(0 - w.mag) : static_cast<int64_t>(w.mag);
    return Value::integerSigned(t, v);
}

void copyUnit(const Value &from, Value &to)
{
    to.dimL = from.dimL;
    to.dimT = from.dimT;
    to.dimM = from.dimM;
}

std::string rangeText(IntType t)
{
    Range r = rangeOf(t);
    return r.lo.toString() + ".." + r.hi.toString();
}

std::string overflowText(IntType t, const std::string &what)
{
    return std::string(intTypeName(t)) + " overflow: " + what + " is outside " + rangeText(t);
}

// Range-checks `w` for type `t`; on failure fills `err` with
// "<type> overflow: <what> = <w> is outside lo..hi".
bool fitsOrError(IntType t, const Wide &w, const std::string &what, std::string &err)
{
    Range r = rangeOf(t);
    if (compare(w, r.lo) >= 0 && compare(w, r.hi) <= 0)
        return true;
    err = overflowText(t, what + " = " + w.toString());
    return false;
}

// Exact parse of optional sign + decimal digits. False for anything else, or
// for a magnitude past 2^64 - 1 (out of every range; reported by the caller
// through the float path).
bool parseIntegerText(const std::string &raw, Wide &out)
{
    size_t b = 0, e = raw.size();
    while (b < e && std::isspace(static_cast<unsigned char>(raw[b])))
        b++;
    while (e > b && std::isspace(static_cast<unsigned char>(raw[e - 1])))
        e--;
    if (b == e)
        return false;
    bool neg = false;
    if (raw[b] == '+' || raw[b] == '-') {
        neg = raw[b] == '-';
        b++;
    }
    if (b == e)
        return false;
    uint64_t mag = 0;
    const uint64_t max = std::numeric_limits<uint64_t>::max();
    for (size_t i = b; i < e; i++) {
        if (!std::isdigit(static_cast<unsigned char>(raw[i])))
            return false;
        const uint64_t digit = static_cast<uint64_t>(raw[i] - '0');
        if (mag > (max - digit) / 10)
            return false;
        mag = mag * 10 + digit;
    }
    out = Wide::make(neg, mag);
    return true;
}

bool castScalar(const Value &v, IntType t, Value &out, std::string &err)
{
    const std::string name = intTypeName(t);
    Wide w;

    if (v.isInt()) {
        w = wideOf(v);
        if (!fitsOrError(t, w, name + "(" + v.intText() + ")", err))
            return false;
    } else if (v.isBool()) {
        w = Wide::fromUnsigned(v.number != 0.0 ? 1 : 0);
    } else if (v.isComplex) {
        err = "cannot convert a complex number to " + name + " (use real() or abs() first)";
        return false;
    } else if (v.isText) {
        if (!parseIntegerText(v.text(), w)) {
            double d;
            if (!tryCoerceTextToNumber(v, d)) {
                err = name + "() could not parse '" + v.text() + "' as a number";
                return false;
            }
            return castScalar(Value(d), t, out, err);
        }
        if (!fitsOrError(t, w, name + "(\"" + v.text() + "\")", err))
            return false;
    } else if (v.isDict || v.isObject || v.isFunctionRef) {
        err = name + "() expects a number, text, or an array/matrix of numbers";
        return false;
    } else {
        const double x = v.number;
        if (std::isnan(x) || std::isinf(x)) {
            err = "cannot convert " + std::string(std::isnan(x) ? "NaN" : "Inf") + " to " + name;
            return false;
        }
        const double tx = std::trunc(x);
        const double mag = std::fabs(tx);
        // 2^64: the first magnitude a uint64 cannot hold (and so no type can).
        if (mag >= 18446744073709551616.0) {
            err = overflowText(t, name + "(" + numberText(x) + ")");
            return false;
        }
        w = Wide::make(tx < 0, static_cast<uint64_t>(mag));
        if (!fitsOrError(t, w, name + "(" + numberText(x) + ")", err))
            return false;
    }

    out = makeInt(t, w);
    copyUnit(v, out);
    return true;
}

// x ^ y for y >= 0, by repeated squaring; false when the result leaves the
// type's range (each step is checked, so nothing ever overflows silently).
bool powerWide(IntType t, const Wide &x, uint64_t y, Wide &out)
{
    const Range r = rangeOf(t);
    auto inRange = [&](const Wide &w) { return compare(w, r.lo) >= 0 && compare(w, r.hi) <= 0; };
    Wide result = Wide::fromUnsigned(1);
    Wide base = x;
    while (y > 0) {
        if (y & 1u) {
            if (!mulWide(result, base, result) || !inRange(result))
                return false;
        }
        y >>= 1;
        if (y > 0) {
            // base is needed again (a later bit is set), so it must stay
            // representable; once |base| > 2^32 its square no longer fits.
            if (!mulWide(base, base, base))
                return false;
        }
    }
    out = result;
    return true;
}

} // namespace

const char *intTypeName(IntType t)
{
    switch (t) {
    case IntType::Int8:
        return "int8";
    case IntType::Int16:
        return "int16";
    case IntType::Int32:
        return "int32";
    case IntType::Int64:
        return "int64";
    case IntType::UInt8:
        return "uint8";
    case IntType::UInt16:
        return "uint16";
    case IntType::UInt32:
        return "uint32";
    case IntType::UInt64:
        return "uint64";
    case IntType::None:
        break;
    }
    return "float64";
}

bool intTypeFromName(const std::string &name, IntType &out)
{
    static const struct
    {
        const char *name;
        IntType type;
    } table[] = {{"int8", IntType::Int8},     {"int16", IntType::Int16},
                 {"int32", IntType::Int32},   {"int64", IntType::Int64},
                 {"uint8", IntType::UInt8},   {"uint16", IntType::UInt16},
                 {"uint32", IntType::UInt32}, {"uint64", IntType::UInt64}};
    for (const auto &entry : table)
        if (name == entry.name) {
            out = entry.type;
            return true;
        }
    return false;
}

bool isReservedWideIntName(const std::string &name)
{
    return name == "int128" || name == "int256" || name == "uint128" || name == "uint256";
}

IntOpResult integerBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                            std::string &err)
{
    // Only integer-with-integer is computed here; anything else involving
    // an integer is float64 math done by the caller.
    if (!a.isInt() || !b.isInt())
        return IntOpResult::NotApplicable;
    if (op != "+" && op != "-" && op != "*" && op != "/" && op != "//" && op != "%" && op != "^")
        return IntOpResult::NotApplicable;

    const IntType t = a.intType();
    if (b.intType() != t) {
        err = std::string("cannot combine ") + intTypeName(t) + " and " +
              intTypeName(b.intType()) + " in '" + op + "' - convert one side first, e.g. " +
              intTypeName(t) + "(x)";
        return IntOpResult::Error;
    }

    const Wide x = wideOf(a), y = wideOf(b);
    const std::string expr = a.intText() + " " + op + " " + b.intText();
    Wide w;

    if (op == "/") {
        // True division is float64 (5/2 is 2.5), the same as for floats.
        out = Value(x.toDouble() / y.toDouble());
        out.dimL = a.dimL - b.dimL;
        out.dimT = a.dimT - b.dimT;
        out.dimM = a.dimM - b.dimM;
        return IntOpResult::Ok;
    }

    if (op == "^") {
        if (y.neg) {
            // A negative power is a fraction: float64, as for 5/2.
            out = Value(std::pow(x.toDouble(), y.toDouble()));
            return IntOpResult::Ok;
        }
        if (!powerWide(t, x, y.mag, w)) {
            err = overflowText(t, expr);
            return IntOpResult::Error;
        }
        out = makeInt(t, w);
        const int p = static_cast<int>(y.mag > 1000 ? 1000 : y.mag);
        out.dimL = static_cast<int16_t>(a.dimL * p);
        out.dimT = static_cast<int16_t>(a.dimT * p);
        out.dimM = static_cast<int16_t>(a.dimM * p);
        return IntOpResult::Ok;
    }

    bool exact = true;
    if (op == "+") {
        exact = addWide(x, y, w);
    } else if (op == "-") {
        exact = subWide(x, y, w);
    } else if (op == "*") {
        exact = mulWide(x, y, w);
    } else { // "//" or "%"
        if (y.mag == 0) {
            err = std::string("integer division by zero in '") + op + "' (" + expr + ")";
            return IntOpResult::Error;
        }
        Wide q, r;
        divModWide(x, y, q, r);
        if (op == "%") {
            // Truncated remainder: same sign as the dividend, the same rule
            // fmod() gives float64 values.
            w = r;
        } else {
            // Truncated division (toward zero), the same rule `//` uses for
            // float64: 7 // -2 is -3, and a == (a // b) * b + a % b.
            w = q;
        }
    }

    if (!exact) {
        err = overflowText(t, expr);
        return IntOpResult::Error;
    }
    if (!fitsOrError(t, w, expr, err))
        return IntOpResult::Error;

    out = makeInt(t, w);
    if (op == "*") {
        out.dimL = a.dimL + b.dimL;
        out.dimT = a.dimT + b.dimT;
        out.dimM = a.dimM + b.dimM;
    } else if (op == "//") {
        out.dimL = a.dimL - b.dimL;
        out.dimT = a.dimT - b.dimT;
        out.dimM = a.dimM - b.dimM;
    } else {
        copyUnit(a, out);
    }
    return IntOpResult::Ok;
}

bool integerNegate(const Value &a, Value &out, std::string &err)
{
    const IntType t = a.intType();
    const Wide w = wideOf(a).negated();
    if (!fitsOrError(t, w, "-(" + a.intText() + ")", err))
        return false;
    out = makeInt(t, w);
    copyUnit(a, out);
    return true;
}

namespace {

ElemType elemTypeOf(IntType t)
{
    switch (t) {
    case IntType::Int8: return ElemType::I8;
    case IntType::Int16: return ElemType::I16;
    case IntType::Int32: return ElemType::I32;
    case IntType::Int64: return ElemType::I64;
    case IntType::UInt8: return ElemType::U8;
    case IntType::UInt16: return ElemType::U16;
    case IntType::UInt32: return ElemType::U32;
    case IntType::UInt64: return ElemType::U64;
    case IntType::None: break;
    }
    return ElemType::I64;
}

// One element of the fast path below: true with the integer's bits when the
// element converts, false when castScalar() would refuse it (NaN, Inf, out
// of the type's range). Same truncation and the same range as castScalar().
struct IntTarget
{
    bool isSigned;
    int bits;
    // The range as doubles, worked out once (exact powers of two for every
    // width; 2026-11-21: they were recomputed per element).
    double lo, hiExclusive;
    IntTarget(bool s, int b)
        : isSigned(s), bits(b), lo(s ? -std::ldexp(1.0, b - 1) : 0.0),
          hiExclusive(s ? std::ldexp(1.0, b - 1) : std::ldexp(1.0, b))
    {
    }
    bool fromDouble(double x, int64_t &out) const
    {
        if (std::isnan(x) || std::isinf(x))
            return false;
        const double tx = std::trunc(x);
        if (isSigned) {
            if (tx < lo || tx >= hiExclusive)
                return false;
            out = static_cast<int64_t>(tx);
            return true;
        }
        // tx in (-1, 0) truncates to -0.0, which is 0 here as in castScalar().
        if (tx < 0.0 || tx >= hiExclusive)
            return false;
        out = static_cast<int64_t>(static_cast<uint64_t>(tx));
        return true;
    }
    // An integer element (exact bits; `fromUnsigned`: the bits are a uint64).
    bool fromInteger(int64_t v, bool fromUnsigned, int64_t &out) const
    {
        if (isSigned) {
            if (fromUnsigned && static_cast<uint64_t>(v) > static_cast<uint64_t>(INT64_MAX))
                return false;
            if (bits < 64) {
                const int64_t lo = -(int64_t(1) << (bits - 1));
                const int64_t hi = (int64_t(1) << (bits - 1)) - 1;
                if (v < lo || v > hi)
                    return false;
            }
            out = v;
            return true;
        }
        if (!fromUnsigned && v < 0)
            return false;
        if (bits < 64 && static_cast<uint64_t>(v) > (uint64_t(1) << bits) - 1)
            return false;
        out = v;
        return true;
    }
};

// The fast path of castToInteger() (2026-11-20): a real packed array /
// matrix - float64, lazy range or typed - converted on several cores into
// the result's raw buffer, instead of one 32-byte Value per element. Each
// element converts exactly as castScalar() converts it; the result is the
// typed tensor packing those cells made. On a refused element the error is
// castScalar()'s own message for the FIRST refused element in the order the
// element-by-element loop visits them (row by row), so it reads exactly as
// before. False when `v` is not such a tensor; `stopped` when Stop ended it.
bool castPackedToInteger(const Value &v, IntType t, Value &out, std::string &err, bool &stopped)
{
    stopped = false;
    ncpacked::RealReader in;
    if (!in.open(v))
        return false;
    const ElemType et = elemTypeOf(t);
    const size_t width = elemTypeBytes(et);
    const IntTarget target(!isUnsignedType(t), static_cast<int>(width * 8));
    const ElemType src = in.etype();
    const bool srcInt = ncpacked::isIntElem(src) || src == ElemType::Bool;
    const bool srcUnsigned = ncpacked::isUnsignedElem(src);
    auto convert = [&](size_t k, int64_t &bits) {
        if (!srcInt)
            return target.fromDouble(in.at(k), bits);
        int64_t b;
        double x;
        in.bitsAt(k, b, x);
        return target.fromInteger(b, srcUnsigned, bits);
    };

    const size_t n = in.count();
    std::vector<uint8_t> raw(n * width);
    uint8_t *dst = raw.data();
    std::atomic<bool> refused{false};
    const nc::par::Outcome r =
        nc::par::forBlocks(n, nc::par::compute(3.0), intTypeName(t), [&](size_t b, size_t e) {
            for (size_t k = b; k < e; k++) {
                int64_t bits = 0;
                if (!convert(k, bits)) {
                    refused.store(true, std::memory_order_relaxed);
                    return;
                }
                // Little-endian low bytes, as Value::writeTyped() stores them.
                const uint64_t u = static_cast<uint64_t>(bits);
                for (size_t i = 0; i < width; i++)
                    dst[k * width + i] = static_cast<uint8_t>(u >> (8 * i));
            }
        });
    if (r != nc::par::Outcome::Done) {
        stopped = true;
        return true;
    }
    if (refused.load()) {
        const std::vector<size_t> &shape = in.shape();
        if (shape.size() > 2) {
            // N-D (2026-11-21): the first refused element in storage order.
            for (size_t k = 0; k < n; k++) {
                int64_t bits = 0;
                if (convert(k, bits))
                    continue;
                Value ignored;
                if (castScalar(v.ndAt(k), t, ignored, err))
                    err = std::string(intTypeName(t)) + "() could not convert an element"; // not expected
                return true;
            }
        }
        // The element the old loop reached first: row by row for a matrix.
        const size_t rows = shape.size() == 2 ? shape[0] : 1;
        const size_t cols = shape.size() == 2 ? shape[1] : shape[0];
        for (size_t row = 0; row < rows; row++)
            for (size_t c = 0; c < cols; c++) {
                int64_t bits = 0;
                const size_t k = c * rows + row;
                if (convert(k, bits))
                    continue;
                Value ignored;
                if (castScalar(shape.size() == 2 ? v.at(row, c) : v.at(c), t, ignored, err))
                    err = std::string(intTypeName(t)) + "() could not convert an element"; // not expected
                return true;
            }
    }
    out = Value::typedTensor(et, in.shape(), std::move(raw), in.dimL(), in.dimT(), in.dimM());
    return true;
}

} // namespace

bool castToInteger(const Value &v, IntType t, Value &out, std::string &err)
{
    if (v.isArray || v.isMatrix) {
        bool stopped = false;
        Value fast;
        std::string fastErr;
        if (castPackedToInteger(v, t, fast, fastErr, stopped)) { // any rank (2026-11-21: N-D too)
            if (stopped) {
                err.clear();
                return false;
            }
            if (!fastErr.empty()) {
                err = fastErr;
                return false;
            }
            out = std::move(fast);
            return true;
        }
    }
    if (v.isND()) {
        // N-D cells (text, mixed ...): element by element, same shape.
        std::vector<Value> cells;
        cells.reserve(v.ndCount());
        nc::par::SerialProgress progress(intTypeName(t), v.ndCount());
        for (size_t k = 0; k < v.ndCount(); k++) {
            Value cell;
            if (!castToInteger(v.ndAt(k), t, cell, err))
                return false;
            cells.push_back(std::move(cell));
            progress.tick(k);
        }
        out = Value::ndFromCells(v.ndShape(), std::move(cells));
        return true;
    }
    if (v.isArray) {
        std::vector<Value> cells;
        cells.reserve(v.length());
        nc::par::SerialProgress progress(intTypeName(t), v.length());
        for (size_t i = 0; i < v.length(); i++) {
            Value cell;
            if (!castToInteger(v.at(i), t, cell, err))
                return false;
            cells.push_back(std::move(cell));
            progress.tick(i);
        }
        out = Value(std::move(cells));
        return true;
    }
    if (v.isMatrix) {
        std::vector<std::vector<Value>> rows;
        rows.reserve(v.rows());
        // Cells done / cells in all (rows may differ in length: about).
        nc::par::SerialProgress progress(intTypeName(t), v.rows() * (v.rows() ? v.rowLength(0) : 0));
        size_t done = 0;
        for (size_t r = 0; r < v.rows(); r++) {
            std::vector<Value> row;
            row.reserve(v.rowLength(r));
            for (size_t c = 0; c < v.rowLength(r); c++) {
                Value cell;
                if (!castToInteger(v.at(r, c), t, cell, err))
                    return false;
                row.push_back(std::move(cell));
                progress.tick(++done);
            }
            rows.push_back(std::move(row));
        }
        out = Value(std::move(rows));
        return true;
    }
    return castScalar(v, t, out, err);
}

int compareIntegers(const Value &a, const Value &b) { return compare(wideOf(a), wideOf(b)); }
