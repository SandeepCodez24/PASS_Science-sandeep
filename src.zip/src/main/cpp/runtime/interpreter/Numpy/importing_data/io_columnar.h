// Shared model of the columnar formats (CATEGORY 3: parquet, feather / Arrow
// IPC, orc): what a reader returns and what a writer is asked to write.
// Nulls are NaN cells, as in every other NC table.
#ifndef NC_IO_COLUMNAR_H
#define NC_IO_COLUMNAR_H

#include <cmath>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct ColStats {
  bool hasMin = false, hasMax = false;
  Value min, max;
  double nulls = -1, distinct = -1; // -1 = not recorded
};

struct ColGroup { // a parquet row group / feather record batch / orc stripe
  size_t rows = 0;
  uint64_t bytes = 0;
  std::vector<ColStats> stats; // per column of ColFile::table
};

struct ColFile {
  Table table;
  std::vector<std::string> types;                 // per column: int64 float64 bool str date timestamp ...
  std::vector<ColGroup> groups;
  std::vector<std::pair<std::string, std::string>> kv; // footer key-value metadata
  std::vector<std::string> skipped;               // columns that could not be decoded (lists, maps ...)
  std::string format, codec, createdBy;
  size_t totalRows = 0;
  size_t rowOffset = 0; // file rows before table.rows[0] (groups skipped by rowFirst)
};

// The decoders' table in column form (2026-11-15, docs/Import_Window.md §9):
// each row group's decoded columns go into one ColumnBuilder per column (and
// are freed), instead of becoming a row of Values per file row.
struct ColTableBuilder {
  std::vector<Value::ColumnBuilder> cols;
  size_t rows = 0;
  void init(size_t ncols) { cols.resize(ncols); }
  // One group: colVals[k] holds column k's n cells (a short one is padded with NaN).
  void addGroup(std::vector<std::vector<Value>> &colVals, size_t n) {
    for (size_t k = 0; k < cols.size() && k < colVals.size(); k++)
      addColumn(k, colVals[k], n);
    endGroup(n);
  }
  // Column k of the current group, as soon as it is decoded (so a group's
  // cells are never all held as Values at once); endGroup() after the last.
  void addColumn(size_t k, std::vector<Value> &vals, size_t n) {
    for (size_t r = 0; r < n; r++)
      cols[k].push(r < vals.size() ? std::move(vals[r]) : Value(missingNumber()));
    std::vector<Value>().swap(vals);
  }
  void endGroup(size_t n) {
    rows += n;
    for (auto &b : cols) // a column the group did not have: NaN, as a short one is padded
      while (b.size() < rows) b.pushNumber(missingNumber());
  }
  void finish(Table &t) {
    tableFromColumns(t, finishColumns(cols), rows);
  }
};

// simple "col op number" predicate used to skip groups by their min/max
struct Pushdown {
  bool active = false;
  std::string col, op;
  double value = 0;
  bool mayMatch(const ColStats &s) const; // false only when the stats rule the group out
};
Pushdown parsePushdown(const std::string &where);

struct ColReadOptions {
  std::vector<std::string> cols;   // empty = all
  std::vector<size_t> groups;      // 0-based, empty = all
  Pushdown pushdown;
  bool metaOnly = false;           // schema + stats, no data
  // File rows wanted (0-based, inclusive): row groups / stripes wholly
  // outside are skipped without decoding (rows= on a big file).
  size_t rowFirst = 0, rowLast = static_cast<size_t>(-1);
};

struct ColWriteOptions {
  std::string codec = "zstd";
  int level = 5;
  size_t groupRows = 0;            // 0 = automatic
  bool dictEnc = true;
  std::vector<std::pair<std::string, std::string>> kv;
  // E6 (2026-11-17): when set, the writer hands the bytes made so far to
  // `sink` after every row group / record batch / stripe and clears them,
  // so a big table is never held encoded; the writer then returns only the
  // rest (the footer). Offsets in the footer count the bytes handed over.
  std::function<bool(std::string &bytes, std::string &err)> sink;
};

// column kinds a writer uses: "int64" "float64" "bool" "str"
std::vector<std::string> writeKinds(const Table &t);

bool readParquet(std::string_view bytes, const ColReadOptions &o, ColFile &f, std::string &err);
std::string writeParquet(const Table &t, const ColWriteOptions &o, std::string &err);
bool readArrowIpc(std::string_view bytes, const ColReadOptions &o, ColFile &f, std::string &err);
std::string writeArrowIpc(const Table &t, const ColWriteOptions &o, std::string &err);
bool readOrc(std::string_view bytes, const ColReadOptions &o, ColFile &f, std::string &err);
std::string writeOrc(const Table &t, const ColWriteOptions &o, std::string &err);

// days since 1970-01-01 -> "YYYY-MM-DD"; seconds (fractional) -> "YYYY-MM-DD HH:MM:SS[.fff]"
std::string isoDate(int64_t days);
std::string isoTimestamp(double seconds, int digits);

} // namespace io
} // namespace nc

#endif // NC_IO_COLUMNAR_H
