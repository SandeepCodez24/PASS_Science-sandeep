// ZIP archives (PKWARE APPNOTE): reading stored/deflated entries and writing
// deflated archives. Used by xlsx / xlsm / xlsb and KMZ.
#ifndef NC_IO_ZIP_H
#define NC_IO_ZIP_H

#include <cstdint>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace nc {
namespace io {

// Reads the central directory from the end of the archive and each entry
// only when asked for, so over a memory-mapped file (SourceBytes) a 2 GB
// workbook costs its directory plus the parts actually read. ZIP64 archives
// (entries or offsets past 4 GB, more than 65535 entries) are read too.
struct ZipReader {
  struct Entry {
    std::string name;
    uint16_t method = 0;
    uint64_t compSize = 0, size = 0, localOffset = 0;
  };
  std::vector<Entry> entries;
  std::string_view data; // the archive - must outlive the reader
  bool open(std::string_view bytes, std::string &err);
  const Entry *find(const std::string &name) const;
  bool has(const std::string &name) const;
  bool read(const std::string &name, std::string &out, std::string &err) const;
};

struct ZipWriter {
  std::vector<std::pair<std::string, std::string>> files; // name, content
  void add(const std::string &name, const std::string &content) { files.emplace_back(name, content); }
  std::string finish(int level = 6) const;
};

} // namespace io
} // namespace nc

#endif // NC_IO_ZIP_H
