// What the Export window asks before it saves - see io_export.h.
#include "io_export.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>

#include "../numpy_common.h"
#include "../numpy_main.h"
#include "../../ops/matrix/matrix_index.h"
#include "io_columnar.h"
#include "io_image.h"
#include "io_net.h"
#include "io_probe.h"
#include "io_session.h"
#include "io_sys_map.h"

namespace nc {
namespace io {
namespace exportx {

namespace fs = std::filesystem;

namespace {

bool hasField(const Value &v, const char *name) { return field(v, name) != nullptr; }

bool tableObjectLike(const Value &v) { return v.isObject && hasField(v, "cols") && hasField(v, "data"); }

// How many rows / columns one dict value gives as table columns (the rule of
// valueToTable(), X3): a vector (1-D, 1xn, nx1) is one column, a 2-D matrix
// (rows x k) k columns. False for anything else.
bool columnsOf(const Value &c, size_t &rows, size_t &cols) {
  if (c.isND() || c.isDict || c.isObject)
    return false;
  if (c.isArray) {
    rows = c.length();
    cols = 1;
    return true;
  }
  if (!c.isMatrix)
    return false;
  if (c.rows() <= 1 || c.cols() <= 1) {
    rows = c.rows() * c.cols();
    cols = 1;
  } else {
    rows = c.rows();
    cols = c.cols();
  }
  return true;
}

// A dict whose values are equally long vectors (or 2-D matrices with that
// many rows): a table by columns. *width: the number of columns it gives.
bool dictOfColumns(const Value &v, size_t *len = nullptr, size_t *width = nullptr) {
  if (!v.isDict || v.dict().empty())
    return false;
  long long n = -1;
  size_t total = 0;
  for (const auto &kv : v.dict()) {
    size_t r = 0, c = 0;
    if (!columnsOf(kv.second, r, c))
      return false;
    if (n >= 0 && static_cast<long long>(r) != n)
      return false;
    n = static_cast<long long>(r);
    total += c;
  }
  if (len)
    *len = static_cast<size_t>(n);
  if (width)
    *width = total;
  return n > 0;
}

// Element k in storage order as a double (packed, typed or cells).
double numAt(const Value &v, size_t k) {
  if (v.isTypedPacked())
    return v.typedNumAt(k);
  if (v.isND() || v.isPacked())
    return v.ndNumAt(k);
  if (v.isArray)
    return v.at(k).number;
  const size_t R = v.rows();
  return v.at(k % R, k / R).number; // 2-D: column-major
}

uint64_t folderBytes(const fs::path &dir) {
  uint64_t n = 0;
  std::error_code ec;
  for (auto it = fs::recursive_directory_iterator(dir, ec); !ec && it != fs::recursive_directory_iterator();
       it.increment(ec))
    if (it->is_regular_file(ec))
      n += it->file_size(ec);
  return n;
}

std::string isoTime(std::time_t t) {
  std::tm tmv{};
#ifdef _WIN32
  gmtime_s(&tmv, &t);
#else
  gmtime_r(&t, &tmv);
#endif
  char buf[32];
  std::strftime(buf, sizeof buf, "%Y-%m-%dT%H:%M:%SZ", &tmv);
  return buf;
}

std::string optionText(const Options &opts, const std::string &name, const std::string &def) {
  for (const auto &kv : opts)
    if (kv.first == name) {
      std::string t = trim(kv.second);
      if (t.size() >= 2 && t.front() == '"' && t.back() == '"')
        t = t.substr(1, t.size() - 2);
      return lower(t);
    }
  return def;
}

bool isImageFormat(const std::string &f) {
  return f == "png" || f == "jpg" || f == "jpeg" || f == "bmp" || f == "gif" || f == "tiff" || f == "dicom";
}
bool isSheetFormat(const std::string &f) { return f == "xlsx" || f == "xlsm" || f == "xlsb" || f == "xls"; }
} // namespace

// ---- what a value is -------------------------------------------------------

const Value &mainData(const Value &v) {
  if (!v.isObject)
    return v;
  const std::string cls = v.className();
  const char *name = cls == "NcImage" ? "pixels" : cls == "NcAudio" ? "wave" : cls == "NcVideo" ? "frames" : nullptr;
  if (name) {
    const Value *f = field(v, name);
    if (f && (f->isArray || f->isMatrix))
      return *f;
  }
  return v;
}

std::string valueKind(const Value &v) {
  if (v.isObject) {
    const std::string cls = v.className();
    if (cls == "NcImage" || cls == "NcGeoRaster")
      return "image";
    if (cls == "NcAudio")
      return "audio";
    if (cls == "NcVideo")
      return "video";
    if (cls == "NcJson" || cls == "NcJsonNode" || cls == "NcXml" || cls == "NcXmlNode" || cls == "NcConfig" ||
        cls == "NcHtml")
      return "tree";
    if (tableObjectLike(v))
      return "table";
    return "object";
  }
  if (v.isText)
    return "text";
  if (v.isDict)
    return dictOfColumns(v) ? "table" : "tree";
  if (v.isND()) {
    const auto &s = v.ndShape();
    const size_t last = s.back();
    const bool channels = last == 1 || last == 3 || last == 4;
    if (s.size() == 3 && channels)
      return "image";
    if (s.size() == 4 && channels)
      return "video";
    return "tensor";
  }
  if (v.isMatrix || v.isArray)
    return "table";
  if (!v.isFunctionRef)
    return "number";
  return "object";
}

std::string dtypeOf(const Value &vIn) {
  const Value &v = mainData(vIn);
  if (v.isText)
    return "text";
  if (v.isTypedPacked())
    return elemTypeName(v.elemType());
  if (v.isPackedComplex())
    return "complex128";
  if (v.isPacked())
    return "float64";
  if (v.isArray || v.isMatrix || v.isDict || v.isObject)
    return "mixed";
  if (v.isComplex)
    return "complex128";
  return elemTypeName(Value::scalarElemType(v));
}

std::vector<size_t> shapeOf(const Value &vIn) {
  const Value &v = mainData(vIn);
  if (tableObjectLike(v)) {
    const Value *r = field(v, "rows"), *c = field(v, "cols");
    const size_t rows = r && !r->isArray && !r->isMatrix ? static_cast<size_t>(r->number) : 0;
    const size_t cols = c ? (c->isText ? 1 : c->isArray ? c->length() : c->rows() * c->cols()) : 0;
    return {rows, cols};
  }
  size_t len = 0;
  size_t width = 0;
  if (dictOfColumns(v, &len, &width))
    return {len, width};
  if (v.isND())
    return v.ndShape();
  if (v.isMatrix)
    return {v.rows(), v.rows() ? v.cols() : 0};
  if (v.isArray)
    return {v.length()};
  return {};
}

size_t axisLength(const Value &v) {
  const auto s = shapeOf(v);
  return s.empty() ? 1 : s[0];
}

size_t elementCount(const Value &v) {
  const auto s = shapeOf(v);
  size_t n = 1;
  for (size_t d : s)
    n *= d;
  return s.empty() ? 1 : n;
}

namespace {

Value prefixND(const Value &v, size_t n) {
  std::vector<size_t> shape = v.ndShape();
  const size_t count = v.ndCount(), per = shape[0] ? count / shape[0] : 0, m = n * per;
  shape[0] = n;
  if (v.isTypedPacked()) {
    const size_t b = elemTypeBytes(v.elemType());
    std::vector<uint8_t> raw(v.typedData(), v.typedData() + m * b);
    return Value::typedTensor(v.elemType(), shape, std::move(raw), v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
  }
  if (v.isPacked()) {
    nc::F64Buf buf(m);
    for (size_t k = 0; k < m; k++)
      buf[k] = v.ndNumAt(k);
    return Value::ndPacked(shape, std::move(buf), false, v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
  }
  if (v.isPackedComplex()) {
    nc::F64Buf buf(2 * m);
    for (size_t k = 0; k < m; k++) {
      const auto z = v.ndCnumAt(k);
      buf[2 * k] = z.real();
      buf[2 * k + 1] = z.imag();
    }
    return Value::ndPacked(shape, std::move(buf), true, v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
  }
  std::vector<Value> cells(m);
  for (size_t k = 0; k < m; k++)
    cells[k] = v.ndAt(k);
  return Value::ndFromCells(shape, std::move(cells));
}

Value prefixMatrix(const Value &v, size_t n) {
  const size_t R = v.rows(), C = v.cols();
  if (v.isTypedPacked()) {
    const size_t b = elemTypeBytes(v.elemType());
    std::vector<uint8_t> raw(n * C * b);
    const uint8_t *src = v.typedData();
    for (size_t c = 0; c < C; c++)
      std::memcpy(&raw[(c * n) * b], src + (c * R) * b, n * b);
    return Value::typedTensor(v.elemType(), {n, C}, std::move(raw), v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
  }
  if (v.isPacked()) {
    std::vector<double> buf(n * C);
    for (size_t c = 0; c < C; c++)
      for (size_t r = 0; r < n; r++)
        buf[c * n + r] = v.ndNumAt(c * R + r);
    return Value::packedMatrix(buf.data(), n, C);
  }
  std::vector<std::vector<Value>> rows(n);
  for (size_t r = 0; r < n; r++)
    rows[r] = v.row(r);
  return Value(std::move(rows));
}

Value prefixArray(const Value &v, size_t n) {
  if (v.isTypedPacked()) {
    const size_t b = elemTypeBytes(v.elemType());
    std::vector<uint8_t> raw(v.typedData(), v.typedData() + n * b);
    return Value::typedTensor(v.elemType(), {n}, std::move(raw), v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
  }
  if (v.isPacked()) {
    std::vector<double> buf(n);
    for (size_t k = 0; k < n; k++)
      buf[k] = v.ndNumAt(k);
    return Value::packedArray(buf.data(), n);
  }
  std::vector<Value> items(n);
  for (size_t k = 0; k < n; k++)
    items[k] = v.at(k);
  return Value(std::move(items));
}

} // namespace

Value sampleRows(const Value &v, size_t n) {
  const size_t total = axisLength(v);
  if (n >= total)
    return v;
  if (tableObjectLike(v)) {
    Table t;
    std::string err;
    if (!valueToTable(v, t, err, false, true))
      return v;
    std::vector<size_t> rows(n), cols(t.cols.size());
    for (size_t r = 0; r < n; r++)
      rows[r] = r;
    for (size_t c = 0; c < cols.size(); c++)
      cols[c] = c;
    return tableObject(tableTake(t, rows, cols), {}, v.className());
  }
  if (v.isObject) { // NcImage / NcAudio / NcVideo ...: every field as long as the data, cut
    Fields f;
    for (const auto &kv : v.dict()) {
      const Value &x = kv.second;
      f[kv.first] = (x.isArray || x.isMatrix) && axisLength(x) == total ? sampleRows(x, n) : x;
    }
    return makeObject(v.className(), std::move(f));
  }
  if (v.isDict) {
    // A dict of columns (X3): every column as long as the table is cut -
    // 1-D arrays, n x 1 / n x k matrices (first n rows) and 1 x n rows
    // (first n values, still a row). Cutting only the 1-D arrays left the
    // others whole, and the trial save then saw unequal columns.
    std::unordered_map<std::string, Value> d;
    for (const auto &kv : v.dict()) {
      const Value &x = kv.second;
      if (x.isArray && x.length() == total)
        d[kv.first] = prefixArray(x, n);
      else if (x.isMatrix && !x.isND() && x.rows() == total)
        d[kv.first] = prefixMatrix(x, n);
      else if (x.isMatrix && !x.isND() && x.rows() == 1 && x.cols() == total)
        d[kv.first] = matTransposeValue(prefixMatrix(matTransposeValue(x), n));
      else
        d[kv.first] = x;
    }
    Value out(std::move(d));
    out.dictOrderHintMut() = v.dictOrderHint(); // same keys: the order stays
    return out;
  }
  if (v.isND())
    return prefixND(v, n);
  if (v.isMatrix)
    return prefixMatrix(v, n);
  if (v.isArray)
    return prefixArray(v, n);
  return v;
}

// ---- trial saves -------------------------------------------------------------

bool trialSave(const std::string &format, const Value &data, const Options &opts, Trial &t, bool keep) {
  static std::atomic<unsigned> counter{0};
  t = Trial();
  std::error_code ec;
  fs::path dir = fs::temp_directory_path(ec);
  if (ec) {
    t.error = "no folder for temporary files";
    return false;
  }
  dir /= "nc_export_" + std::to_string(sysProcessId()) + "_" + std::to_string(counter++);
  fs::create_directories(dir, ec);
  const std::string fn = format == "ndat" ? std::string("save") : "save_" + format;
  const fs::path file = dir / ("probe." + format);
  std::vector<Value> args{Value(file.u8string()), data};
  std::vector<std::string> names{"", ""};
  for (const auto &kv : opts) {
    Value v;
    std::string err;
    if (!parseLiteral(kv.second, v, err)) {
      t.error = kv.first + ": " + err;
      fs::remove_all(dir, ec);
      return false;
    }
    args.push_back(v);
    names.push_back(kv.first);
  }
  std::ostringstream captured;
  std::streambuf *old = std::cerr.rdbuf(captured.rdbuf());
  Value out;
  bool ok = false;
  bool found = false;
  try {
    found = numpy::tryCall(fn, args, out, ok, names);
  } catch (const std::exception &e) {
    ok = false;
    captured << "Error: " << fn << ": " << e.what() << "\n";
  }
  std::cerr.rdbuf(old);
  std::istringstream lines(captured.str());
  std::string line;
  while (std::getline(lines, line)) {
    line = trim(line);
    if (line.rfind("Warning: ", 0) == 0) {
      std::string w = line.substr(9);
      if (w.rfind(fn + ": ", 0) == 0)
        w = w.substr(fn.size() + 2);
      t.warnings.push_back(w);
    } else if (line.rfind("Error: ", 0) == 0 && t.error.empty()) {
      std::string e = line.substr(7);
      if (e.rfind(fn + ": ", 0) == 0)
        e = e.substr(fn.size() + 2);
      t.error = e;
    }
  }
  if (!found)
    t.error = fn + " is not available";
  t.ok = found && ok;
  if (t.ok && t.error.empty() == false)
    t.ok = false;
  if (!t.ok && t.error.empty())
    t.error = fn + " failed";
  t.bytes = folderBytes(dir);
  if (t.ok) {
    if (fs::exists(file, ec))
      t.file = file.u8string();
    else
      for (auto it = fs::recursive_directory_iterator(dir, ec); !ec && it != fs::recursive_directory_iterator();
           it.increment(ec))
        if (it->is_regular_file(ec)) {
          t.file = it->path().u8string();
          break;
        }
  }
  t.folder = dir.u8string();
  if (!keep)
    dropTrial(t);
  return t.ok;
}

void dropTrial(Trial &t) {
  if (t.folder.empty())
    return;
  std::error_code ec;
  fs::remove_all(resolvePath(t.folder), ec);
  t.folder.clear();
}

Estimate estimateBytes(const std::string &format, const Value &data, const Options &opts) {
  constexpr size_t kWhole = 200000;   // elements encoded whole: exact
  constexpr size_t kSample = 100000;  // elements per sample otherwise
  Estimate e;
  const size_t n = axisLength(data), elems = std::max<size_t>(1, elementCount(data));
  Trial t;
  if (elems <= kWhole || n < 64) {
    if (!trialSave(format, data, opts, t)) {
      e.error = t.error;
      return e;
    }
    e.ok = e.exact = true;
    e.bytes = t.bytes;
    return e;
  }
  const size_t perRow = std::max<size_t>(1, elems / n);
  const size_t s1 = std::clamp<size_t>(kSample / perRow, 16, n / 4), s2 = 2 * s1;
  Trial a, b;
  if (!trialSave(format, sampleRows(data, s1), opts, a) || !trialSave(format, sampleRows(data, s2), opts, b)) {
    e.error = a.ok ? b.error : a.error;
    return e;
  }
  const double per = (static_cast<double>(b.bytes) - static_cast<double>(a.bytes)) / static_cast<double>(s2 - s1);
  const double fixed = static_cast<double>(a.bytes) - per * static_cast<double>(s1);
  const double whole = fixed + per * static_cast<double>(n);
  e.ok = true;
  e.bytes = static_cast<uint64_t>(std::max(static_cast<double>(b.bytes), std::round(whole)));
  return e;
}

// ---- losses / suggestions / limits ----------------------------------------------

std::string sizeLimitError(const std::string &format, const Value &v) {
  if (!isSheetFormat(format))
    return "";
  const auto s = shapeOf(v);
  if (s.empty())
    return "";
  const size_t rows = s[0], cols = s.size() > 1 ? s[1] : 1;
  const bool xls = format == "xls";
  const size_t maxRows = xls ? 65536 : 1048576, maxCols = xls ? 256 : 16384;
  if (rows + 1 > maxRows || cols > maxCols) // + 1: the header row
    return "a ." + format + " sheet holds at most " + std::to_string(maxRows) + " rows and " +
           std::to_string(maxCols) + " columns - the data is " + std::to_string(rows) + " x " +
           std::to_string(cols) + " (save it as csv / parquet, or in parts)";
  return "";
}

std::vector<std::string> lossesOf(const std::string &format, const Value &v, const Options &opts) {
  std::vector<std::string> out;
  const Value &m = mainData(v);
  const std::string dt = dtypeOf(v), kind = valueKind(v);
  const auto shape = shapeOf(v);
  const bool floaty = dt == "float64" || dt == "float32" || dt == "float16" || dt == "float8";
  const size_t channels = shape.size() >= 3 ? shape.back() : 1;
  if (dt == "complex128" && !(format == "ndat" || format == "mat" || format == "h5" || format == "hdf" ||
                              format == "he5" || format == "nc" || format == "cdf" || format == "npy"))
    out.push_back("complex numbers are written as text / their real part - .ndat, .mat, .h5 or .nc keep them");
  if (isImageFormat(format)) {
    if (format == "jpg" || format == "jpeg") {
      out.push_back("JPEG is lossy (quality=" + optionText(opts, "quality", "92") + ")");
      if (channels == 2 || channels == 4)
        out.push_back("the alpha channel is dropped (JPEG has none)");
    }
    if (format == "gif")
      out.push_back("colours are reduced to a palette of 256");
    const std::string depth = optionText(opts, "bit_depth", "8");
    if (dt == "uint16" && !(format == "png" && depth == "16") && format != "tiff" && format != "dicom")
      out.push_back("16-bit levels become 8-bit" + std::string(format == "png" ? " (bit_depth=16 keeps them)" : ""));
    else if (floaty && format != "tiff")
      out.push_back("float values become " + std::string(format == "png" && depth == "16" ? "16" : "8") +
                    "-bit levels (0..1 scaled to the full range)");
    else if (dt != "uint8" && dt != "uint16" && dt != "bool" && !floaty && format != "tiff")
      out.push_back(dt + " values become 8-bit levels (0..255)");
  } else if (format == "mp3" || format == "ogg") {
    out.push_back("lossy audio (bitrate=" + optionText(opts, "bitrate", "192k") + ")");
  } else if (format == "wav" || format == "flac") {
    const std::string bits = optionText(opts, "bits", "-1");
    if (floaty && (bits == "-1" || bits == "16"))
      out.push_back("float samples become 16-bit levels (bits=" + std::string(format == "wav" ? "32" : "24") +
                    " keeps more)");
  } else if (format == "mp4" || format == "avi" || format == "m4v" || format == "mov") {
    const std::string codec = optionText(opts, "codec", "h264");
    if (codec == "mjpeg" || codec == "mjpg" || codec == "jpeg")
      out.push_back("MJPEG is lossy (quality from crf=)");
    else
      out.push_back("colour is kept at half resolution (H.264 YUV 4:2:0)");
    if (dt != "uint8")
      out.push_back("values become 8-bit levels (0..255)");
  } else if (format == "fits" || format == "fit") {
    const std::string bitpix = optionText(opts, "bitpix", "-32");
    if (bitpix == "-32" && (dt == "float64" || dt == "mixed" || dt == "int32" || dt == "int64" || dt == "uint32" ||
                            dt == "uint64"))
      out.push_back("values are stored as float32 (bitpix=-32; bitpix=-64 keeps float64)");
  } else if (isSheetFormat(format)) {
    // text cells longer than Excel's cell limit, whole numbers beyond float64's exact range
    Table t;
    std::string err;
    if ((kind == "table" || kind == "number") && valueToTable(v, t, err, false, true)) {
      size_t longText = 0, bigInts = 0;
      const size_t rows = std::min<size_t>(t.rowCount(), 1000000 / std::max<size_t>(1, t.cols.size()));
      for (size_t r = 0; r < rows; r++)
        for (size_t c = 0; c < t.cols.size(); c++) {
          const Value x = t.cell(r, c);
          if (x.isText && x.text().size() > 32767)
            longText++;
          else if (x.isInt() && std::llabs(x.intBits()) > (1LL << 53))
            bigInts++;
        }
      if (longText)
        out.push_back(std::to_string(longText) + " text cell(s) are cut to 32 767 characters (Excel's limit)");
      if (bigInts)
        out.push_back(std::to_string(bigInts) + " whole number(s) beyond 2^53 become float64 (Excel keeps no more)");
    }
  }
  (void)m;
  return out;
}

std::vector<std::string> suggestFormats(const Value &v) {
  const std::string kind = valueKind(v);
  std::vector<std::string> candidates;
  if (kind == "table" || kind == "number")
    candidates = {"ndat", "parquet", "feather", "csv", "xlsx", "h5", "mat"};
  else if (kind == "image")
    candidates = {"ndat", "png", "tiff", "mat", "h5"};
  else if (kind == "audio")
    candidates = {"ndat", "flac", "wav", "mat"};
  else if (kind == "video")
    candidates = {"ndat", "mat", "h5"};
  else if (kind == "tree")
    candidates = {"ndat", "json", "yaml", "xml"};
  else if (kind == "tensor")
    candidates = {"ndat", "h5", "mat", "nc"};
  else if (kind == "text")
    candidates = {"ndat", "txt", "json"};
  else
    candidates = {"ndat", "mat"};
  const Value sample = sampleRows(v, 32);
  std::vector<std::string> out;
  for (const auto &f : candidates) {
    Trial t;
    if (trialSave(f, sample, {}, t) && lossesOf(f, v, {}).empty() && sizeLimitError(f, v).empty())
      out.push_back(f);
  }
  return out;
}

// ---- op "target" --------------------------------------------------------------------

void writeTarget(ncdata::JsonWriter &j, const std::string &file, const std::string &formatIn) {
  std::error_code ec;
  const fs::path p = resolvePath(file);
  const fs::path folder = p.parent_path();
  const bool folderExists = folder.empty() || fs::is_directory(folder, ec);
  const bool isFile = fs::is_regular_file(p, ec);
  const bool isFolder = fs::is_directory(p, ec);
  j.key("path").string(fs::path(p).lexically_normal().make_preferred().u8string());
  j.key("exists").boolean(isFile || isFolder);
  j.key("is_folder").boolean(isFolder);
  j.key("folder_exists").boolean(folderExists);
  uint64_t bytes = 0;
  if (isFile) {
    bytes = fs::file_size(p, ec);
    const auto ft = fs::last_write_time(p, ec);
    const auto sys = std::chrono::system_clock::now() +
                     std::chrono::duration_cast<std::chrono::system_clock::duration>(ft - fs::file_time_type::clock::now());
    j.key("bytes").unsignedInteger(bytes);
    j.key("modified").string(isoTime(std::chrono::system_clock::to_time_t(sys)));
  } else if (isFolder) {
    j.key("bytes").unsignedInteger(folderBytes(p));
    j.key("modified").string("");
  } else {
    j.key("bytes").unsignedInteger(0);
    j.key("modified").string("");
  }
  // writable: an existing file opened for writing without changing it (a
  // file open in Excel fails here); a new one: the folder takes a file
  bool writable = false;
  if (isFile) {
    std::fstream f(p, std::ios::in | std::ios::out | std::ios::binary);
    writable = static_cast<bool>(f);
  } else if (folderExists && !isFolder) {
    fs::path probe = folder / (".nc_write_test~" + std::to_string(sysProcessId()));
    {
      std::ofstream f(probe, std::ios::binary);
      writable = static_cast<bool>(f);
    }
    fs::remove(probe, ec);
  } else if (isFolder) {
    writable = true;
  }
  j.key("writable").boolean(writable);
  // the format: the one asked for, the file's own (when it exists), the name's
  std::string format = lower(formatIn);
  std::string existing;
  if (isFile) {
    existing = lower(extensionOf(file)) == "ndat" ? std::string("ndat") : detectFormat(file).format;
  }
  if (format.empty())
    format = lower(extensionOf(file)) == "ndat" ? std::string("ndat") : detectFormat(file).format;
  j.key("format").string(format);
  j.key("existing_format").string(existing);
  const bool same = isFile && !existing.empty() && existing == format;
  j.key("same_format").boolean(same);
  if (same) {
    std::ostringstream quiet;
    std::streambuf *old = std::cerr.rdbuf(quiet.rdbuf());
    std::string err;
    j.key("probe").beginObject();
    const bool ok = probeFile(file, format, j, err);
    j.endObject();
    std::cerr.rdbuf(old);
    if (!ok)
      j.key("probe_error").string(err.empty() ? "cannot probe the file" : err);
  }
  // appending: which save_ can add to an existing file, and how
  std::string append, meaning;
  if (isFile && same) {
    if (format == "csv" || format == "tsv" || format == "txt" || format == "dat")
      append = "mode=\"a\"", meaning = "adds the rows at the end (the header is not repeated)";
    else if (isSheetFormat(format) && format != "xls")
      append = "mode=\"a\"", meaning = "adds the sheets to the workbook";
    else if (format == "fits" || format == "fit")
      append = "mode=\"a\"", meaning = "adds an extension HDU";
    else if (format == "h5" || format == "hdf" || format == "he5")
      append = "mode=\"a\"", meaning = "adds the dataset to the file";
    else if (format == "yaml" || format == "yml")
      append = "mode=\"a\"", meaning = "adds a document (---)";
    else if (format == "ini")
      append = "mode=\"a\"", meaning = "merges the sections into the file";
    else if (format == "bin" || format == "custom")
      append = "mode=\"a\"", meaning = "adds the records at the end";
    else if (format == "sqlite")
      append = "mode=\"append\"", meaning = "adds the rows to the table";
  }
  j.key("can_append").boolean(!append.empty());
  j.key("append_option").string(append);
  j.key("append_meaning").string(meaning);
  fs::path zip = p;
  zip += ".zip";
  j.key("zip_file").string(zip.u8string());
  j.key("zip_exists").boolean(fs::exists(zip, ec));
}

// ---- op "peek" ------------------------------------------------------------------------

namespace {

// A picture of an image / video frame: every Nth pixel, longest side <= maxSide.
bool thumbnailOf(const Value &px, ncdata::JsonWriter &j, size_t maxSide) {
  size_t H = 0, W = 0, C = 1, frameOff = 0;
  const bool nd = px.isND();
  if (nd) {
    const auto &s = px.ndShape();
    if (s.size() == 3) {
      H = s[0], W = s[1], C = s[2];
    } else if (s.size() == 4) {
      H = s[1], W = s[2], C = s[3];
    } else {
      return false;
    }
  } else if (px.isMatrix) {
    H = px.rows(), W = px.cols();
  } else {
    return false;
  }
  if (!H || !W || C < 1 || C > 4)
    return false;
  (void)frameOff; // frame 0: storage starts with it
  const size_t step = std::max<size_t>(1, (std::max(H, W) + maxSide - 1) / std::max<size_t>(1, maxSide));
  const size_t tw = (W + step - 1) / step, th = (H + step - 1) / step;
  auto at = [&](size_t h, size_t w, size_t c) {
    if (nd)
      return numAt(px, h * (W * C) + c * W + w); // page h: W x C, column-major
    return numAt(px, w * H + h);
  };
  const std::string dt = dtypeOf(px);
  double hi = 255;
  if (dt == "uint16")
    hi = 65535;
  else if (dt.rfind("float", 0) == 0 || dt == "mixed") {
    double mx = 0;
    for (size_t y = 0; y < th; y++)
      for (size_t x = 0; x < tw; x++)
        for (size_t c = 0; c < C; c++) {
          const double v = at(y * step, x * step, c);
          if (std::isfinite(v))
            mx = std::max(mx, v);
        }
    hi = mx <= 1.0 ? 1.0 : 255.0;
  } else if (dt == "bool") {
    hi = 1;
  }
  Image img;
  img.width = tw;
  img.height = th;
  img.channels = C;
  img.bitDepth = 8;
  img.px.resize(tw * th * C);
  for (size_t y = 0; y < th; y++)
    for (size_t x = 0; x < tw; x++)
      for (size_t c = 0; c < C; c++) {
        double v = at(y * step, x * step, c);
        v = std::isfinite(v) ? std::clamp(v / hi * 255.0, 0.0, 255.0) : 0.0;
        img.px[(y * tw + x) * C + c] = std::round(v);
      }
  j.key("png").string(base64Encode(encodePng(img, 6, false, {})));
  j.key("width").unsignedInteger(W);
  j.key("height").unsignedInteger(H);
  j.key("channels").unsignedInteger(C);
  j.key("thumb_width").unsignedInteger(tw);
  j.key("thumb_height").unsignedInteger(th);
  return true;
}

void cellsOf(ncdata::JsonWriter &j, const Value &v, const PeekLimits &lim) {
  Table t;
  std::string err;
  if (!valueToTable(v, t, err, false, true)) {
    j.key("error").string(err);
    return;
  }
  const size_t rows = std::min(lim.rows, t.rowCount()), cols = std::min(lim.cols, t.cols.size());
  j.key("cols").beginArray();
  for (size_t c = 0; c < cols; c++)
    j.string(t.cols[c]);
  j.endArray();
  j.key("rows").beginArray();
  for (size_t r = 0; r < rows; r++) {
    j.beginArray();
    for (size_t c = 0; c < cols; c++)
      j.string(cellText(t.cell(r, c)));
    j.endArray();
  }
  j.endArray();
  j.key("total_rows").unsignedInteger(t.rowCount());
  j.key("total_cols").unsignedInteger(t.cols.size());
}

void audioOf(ncdata::JsonWriter &j, const Value &obj, const Value &wave, const PeekLimits &lim) {
  const size_t n = wave.isArray ? wave.length() : wave.rows();
  const size_t ch = wave.isArray ? 1 : std::max<size_t>(1, wave.cols());
  const size_t buckets = std::max<size_t>(1, std::min(lim.buckets, n));
  const Value *fs = field(obj, "fs");
  const double rate = fs && !fs->isArray ? fs->number : 0;
  j.key("samples").unsignedInteger(n);
  j.key("channels").unsignedInteger(ch);
  j.key("fs").number(rate);
  j.key("duration").number(rate > 0 ? static_cast<double>(n) / rate : 0);
  j.key("buckets").unsignedInteger(buckets);
  std::vector<std::vector<double>> lo(ch, std::vector<double>(buckets, INFINITY)), hi(ch, std::vector<double>(buckets, -INFINITY));
  for (size_t i = 0; i < n; i++) {
    const size_t b = std::min(buckets - 1, i * buckets / std::max<size_t>(1, n));
    for (size_t c = 0; c < ch; c++) {
      const double v = numAt(wave, wave.isArray ? i : c * n + i);
      if (v < lo[c][b])
        lo[c][b] = v;
      if (v > hi[c][b])
        hi[c][b] = v;
    }
  }
  auto list = [&](const char *key, const std::vector<std::vector<double>> &m) {
    j.key(key).beginArray();
    for (const auto &row : m) {
      j.beginArray();
      for (double v : row)
        j.number(std::isfinite(v) ? v : 0);
      j.endArray();
    }
    j.endArray();
  };
  list("min", lo);
  list("max", hi);
}

} // namespace

void writePeek(ncdata::JsonWriter &j, const Value &v, const PeekLimits &lim) {
  const std::string kind = valueKind(v);
  const Value &m = mainData(v);
  j.key("kind").string(kind);
  j.key("class").string(v.isObject ? v.className() : std::string());
  j.key("dtype").string(dtypeOf(v));
  j.key("shape").beginArray();
  for (size_t d : shapeOf(v))
    j.unsignedInteger(d);
  j.endArray();
  if (kind == "image" || kind == "video") {
    if (kind == "video" && m.isND())
      j.key("frames").unsignedInteger(m.ndShape()[0]);
    if (!thumbnailOf(m, j, lim.maxSide))
      j.key("note").string(kind == "video" ? "the frames are not loaded" : "no picture");
    return;
  }
  if (kind == "audio") {
    audioOf(j, v, m, lim);
    return;
  }
  if (kind == "table" || kind == "number") {
    if (m.isMatrix && !m.isND() && (m.isTypedPacked()) && m.rows() >= 16 && m.cols() >= 16)
      thumbnailOf(m, j, lim.maxSide); // a typed 2-D matrix may be a gray image: a picture as well
    cellsOf(j, v, lim);
    return;
  }
  if (kind == "tensor") { // the first 2-D page (all leading indices 0)
    const auto &s = m.ndShape();
    const size_t R = s[s.size() - 2], C = s.back();
    const size_t rows = std::min(lim.rows, R), cols = std::min(lim.cols, C);
    j.key("page").string("first 2-D page (leading indices 0)");
    j.key("rows").beginArray();
    for (size_t r = 0; r < rows; r++) {
      j.beginArray();
      for (size_t c = 0; c < cols; c++)
        j.string(cellText(m.ndAt(c * R + r)));
      j.endArray();
    }
    j.endArray();
    return;
  }
  if (kind == "text") {
    const std::string &t = v.text();
    j.key("text").string(t.substr(0, std::min<size_t>(t.size(), 10000)));
    j.key("length").unsignedInteger(t.size());
    return;
  }
  if (kind == "tree") {
    Preview p;
    fillPreview(v, nullptr, lim.nodes, p);
    j.key("cols").beginArray();
    for (const auto &c : p.cols)
      j.string(c);
    j.endArray();
    j.key("rows").beginArray();
    for (const auto &r : p.rows) {
      j.beginArray();
      for (const auto &c : r)
        j.string(c);
      j.endArray();
    }
    j.endArray();
    j.key("total_rows").unsignedInteger(p.totalRows);
    return;
  }
  if (kind == "number") {
    j.key("text").string(cellText(v));
    return;
  }
  // another object: its fields and what each is
  j.key("fields").beginArray();
  size_t k = 0;
  if (v.isObject || v.isDict) {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &key : keys) {
      if (k++ >= lim.nodes)
        break;
      const Value &x = v.dict().at(key);
      j.beginObject();
      j.key("name").string(key);
      j.key("kind").string(valueKind(x));
      j.key("dtype").string(dtypeOf(x));
      j.endObject();
    }
  }
  j.endArray();
}

} // namespace exportx
} // namespace io
} // namespace nc
