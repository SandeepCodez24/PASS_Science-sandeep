// Shared I/O pieces - see io_common.h.
#include "io_common.h"

#include <algorithm>
#include <charconv>
#include <chrono>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <set>

#include "../numpy_common.h"
#include "parallel/par.h"
#include "../../../data/DataEngine.h"
#include "io_deflate.h"
#include "io_sys_map.h"
#include "../../ops/time/time.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")
#endif
// File mapping for SourceBytes (all OSes): io_sys_map.cpp.

namespace nc {
namespace io {

// ---- progress / events ----------------------------------------------------

namespace {
std::mutex g_listenerMutex;
IoListener g_listener;
std::atomic<bool> g_cancel{false};
} // namespace

void setIoListener(IoListener listener) {
  std::lock_guard<std::mutex> lock(g_listenerMutex);
  g_listener = std::move(listener);
}

void emitEvent(const IoEvent &e) {
  IoListener copy;
  {
    std::lock_guard<std::mutex> lock(g_listenerMutex);
    copy = g_listener;
  }
  if (copy)
    copy(e);
}

namespace {
// The outermost reader running on this thread (EventScope). A reader's
// progress has two phases: reading the file (readFile reports it, 0 .. 0.5)
// and decoding (the reader's own reportProgress calls, mapped to 0.5 .. 1
// once the file was read). A reader that maps its file (SourceBytes) has
// no reading phase and reports 0 .. 1 itself. Fractions never go back.
struct ProgressState {
  int depth = 0;
  std::string function, file;
  bool loaded = false;
  double last = 0;
};
thread_local ProgressState t_progress;

bool emitProgress(const std::string &function, const std::string &file, double fraction) {
  IoEvent e;
  e.kind = "progress";
  e.function = function.empty() ? t_progress.function : function;
  e.file = file.empty() ? t_progress.file : file;
  e.fraction = std::clamp(fraction, 0.0, 1.0);
  if (t_progress.depth > 0) {
    e.fraction = std::max(e.fraction, t_progress.last);
    t_progress.last = e.fraction;
  }
  emitEvent(e);
  return g_cancel.load();
}
} // namespace

bool reportProgress(const std::string &function, const std::string &file, double fraction) {
  if (t_progress.depth > 0 && t_progress.loaded)
    fraction = 0.5 + 0.5 * std::clamp(fraction, 0.0, 1.0);
  return emitProgress(function, file, fraction);
}

void requestCancel() { g_cancel.store(true); }
void clearCancel() { g_cancel.store(false); }
bool cancelRequested() { return g_cancel.load(); }

EventScope::EventScope(const std::string &fn, const std::string &f) : function(fn), file(f) {
  if (t_progress.depth++ == 0) {
    clearCancel();
    t_progress.function = fn;
    t_progress.file = f;
    t_progress.loaded = false;
    t_progress.last = 0;
  }
  emitEvent({"open", function, file, 0, ""});
}

EventScope::~EventScope() {
  if (t_progress.depth > 0)
    t_progress.depth--;
  emitEvent({ok ? "done" : "error", function, file, ok ? 1.0 : 0.0, ""});
}

// ---- options --------------------------------------------------------------

std::string lower(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}

std::string trim(const std::string &s) {
  size_t b = 0, e = s.size();
  while (b < e && std::isspace(static_cast<unsigned char>(s[b])))
    b++;
  while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1])))
    e--;
  return s.substr(b, e - b);
}

bool given(const Value &v) {
  if (v.isText)
    return !v.text().empty();
  if (v.isArray)
    return v.length() > 0;
  if (v.isND()) // rows() is 0 for an N-D value: an image / tensor / video was taken as "not given" (E14)
    return v.ndCount() > 0;
  if (v.isMatrix)
    return v.rows() > 0;
  return true;
}

std::string optText(const Value &v, const std::string &def) {
  if (v.isText)
    return v.text().empty() ? def : v.text();
  if (numpy::isPlainNumber(v))
    return numberText(v.number);
  return def;
}

bool optBool(const Value &v, bool def) {
  if (v.isText) {
    std::string t = lower(v.text());
    if (t == "true" || t == "yes" || t == "on" || t == "1")
      return true;
    if (t == "false" || t == "no" || t == "off" || t == "0")
      return false;
    return def;
  }
  if (numpy::isPlainNumber(v))
    return v.number != 0;
  return def;
}

long long optInt(const Value &v, long long def) {
  if (numpy::isPlainNumber(v) && std::isfinite(v.number))
    return static_cast<long long>(std::llround(v.number));
  if (v.isText && !v.text().empty()) {
    char *end = nullptr;
    long long n = std::strtoll(v.text().c_str(), &end, 10);
    if (end && *end == '\0')
      return n;
  }
  return def;
}

double optNumber(const Value &v, double def) {
  if (numpy::isPlainNumber(v))
    return v.number;
  if (v.isText && !v.text().empty()) {
    char *end = nullptr;
    double d = std::strtod(v.text().c_str(), &end);
    if (end && *end == '\0')
      return d;
  }
  return def;
}

namespace {
void flattenCells(const Value &v, std::vector<Value> &out) {
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      out.push_back(v.at(i));
  } else if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        out.push_back(v.at(r, c));
  } else {
    out.push_back(v);
  }
}
} // namespace

std::vector<std::string> optTextList(const Value &v) {
  std::vector<std::string> out;
  if (!given(v))
    return out;
  std::vector<Value> cells;
  flattenCells(v, cells);
  for (const Value &c : cells)
    out.push_back(c.isText ? c.text() : cellText(c));
  return out;
}

std::vector<double> optNumbers(const Value &v) {
  std::vector<double> out;
  if (!given(v))
    return out;
  std::vector<Value> cells;
  flattenCells(v, cells);
  for (const Value &c : cells)
    out.push_back(c.isText ? optNumber(c, std::nan("")) : c.number);
  return out;
}

bool parseSpan(const std::string &text, Span &out) {
  const std::string t = trim(text);
  std::vector<std::string> parts;
  size_t from = 0;
  for (;;) {
    size_t c = t.find(':', from);
    parts.push_back(trim(t.substr(from, c == std::string::npos ? std::string::npos : c - from)));
    if (c == std::string::npos)
      break;
    from = c + 1;
  }
  if (parts.size() < 2 || parts.size() > 3)
    return false;
  auto whole = [](const std::string &s, long long &v) {
    if (s.empty())
      return false;
    char *end = nullptr;
    v = std::strtoll(s.c_str(), &end, 10);
    return end && *end == '\0';
  };
  Span s;
  if (!whole(parts[0], s.start) || s.start == 0)
    return false;
  const std::string &last = parts.back();
  if (last.empty() || lower(last) == "end")
    s.stop = -1;
  else if (!whole(last, s.stop) || s.stop == 0)
    return false;
  if (parts.size() == 3 && (!whole(parts[1], s.step) || s.step < 1))
    return false;
  out = s;
  return true;
}

void expandSpan(const Span &s, size_t count, std::vector<size_t> &out) {
  const long long n = static_cast<long long>(count);
  long long a = s.start < 0 ? n + s.start + 1 : s.start;
  long long b = s.stop < 0 ? n + s.stop + 1 : std::min(s.stop, n);
  if (a < 1)
    a = 1;
  for (long long k = a; k <= b; k += s.step)
    out.push_back(static_cast<size_t>(k - 1));
}

bool Selector::lastPosition(long long &last) const {
  if (all || !names.empty())
    return false;
  last = 0;
  for (long long p : positions) {
    if (p < 0)
      return false;
    last = std::max(last, p);
  }
  for (const Span &s : spans) {
    if (s.start < 0 || s.stop < 0)
      return false;
    last = std::max(last, s.stop);
  }
  return true;
}

bool rowsUpperBound(const Value &rows, long long &last) {
  Selector s;
  std::string err;
  return parseSelector(rows, s, err) && s.lastPosition(last);
}

bool parseSelector(const Value &v, Selector &out, std::string &err) {
  out = Selector();
  if (!given(v))
    return true;
  if (numpy::isPlainNumber(v) && v.number < 0 && !v.isText)
    return true; // -1 = all
  std::vector<Value> cells;
  flattenCells(v, cells);
  for (const Value &c : cells) {
    if (c.isText) {
      // "1:5", "10:", "10:-1", "1:3:12" written as text: a span.
      Span s;
      if (c.text().find(':') != std::string::npos && parseSpan(c.text(), s)) {
        out.spans.push_back(s);
        continue;
      }
      out.names.push_back(c.text());
    } else if (numpy::isPlainNumber(c)) {
      if (c.number != std::floor(c.number)) {
        err = "a position must be a whole number, got " + numberText(c.number);
        return false;
      }
      out.positions.push_back(static_cast<long long>(c.number));
    } else {
      err = "a selection must be names or positions";
      return false;
    }
  }
  out.all = out.positions.empty() && out.names.empty() && out.spans.empty();
  return true;
}

bool resolveSelector(const Selector &sel, const std::vector<std::string> &names, size_t count,
                     std::vector<size_t> &out, std::string &err) {
  out.clear();
  if (sel.all) {
    for (size_t i = 0; i < count; i++)
      out.push_back(i);
    return true;
  }
  for (long long p : sel.positions) {
    long long idx = p < 0 ? static_cast<long long>(count) + p : p - 1;
    if (idx < 0 || idx >= static_cast<long long>(count)) {
      err = "position " + std::to_string(p) + " is outside 1.." + std::to_string(count);
      return false;
    }
    out.push_back(static_cast<size_t>(idx));
  }
  for (const Span &s : sel.spans)
    expandSpan(s, count, out);
  for (const std::string &n : sel.names) {
    size_t found = names.size();
    for (size_t i = 0; i < names.size() && found == names.size(); i++)
      if (names[i] == n)
        found = i;
    for (size_t i = 0; i < names.size() && found == names.size(); i++)
      if (lower(names[i]) == lower(n) || fieldName(names[i]) == n)
        found = i;
    if (found == names.size()) {
      std::string list;
      for (size_t i = 0; i < names.size() && i < 12; i++)
        list += (i ? ", " : "") + names[i];
      err = "no column '" + n + "' (there are: " + list + (names.size() > 12 ? ", ..." : "") + ")";
      return false;
    }
    out.push_back(found);
  }
  return true;
}

bool parseByteSize(const std::string &text, uint64_t &bytes) {
  std::string t = lower(trim(text));
  if (t.empty())
    return false;
  size_t i = 0;
  while (i < t.size() && (std::isdigit(static_cast<unsigned char>(t[i])) || t[i] == '.'))
    i++;
  if (i == 0)
    return false;
  double n = std::strtod(t.substr(0, i).c_str(), nullptr);
  std::string unit = trim(t.substr(i));
  double mul = 1;
  if (unit.empty() || unit == "b" || unit == "bytes")
    mul = 1;
  else if (unit == "k" || unit == "kb" || unit == "kib")
    mul = 1024.0;
  else if (unit == "m" || unit == "mb" || unit == "mib")
    mul = 1024.0 * 1024;
  else if (unit == "g" || unit == "gb" || unit == "gib")
    mul = 1024.0 * 1024 * 1024;
  else
    return false;
  bytes = static_cast<uint64_t>(n * mul);
  return true;
}

std::string formatBytes(uint64_t n) {
  char buf[64];
  if (n >= 1024ull * 1024 * 1024)
    std::snprintf(buf, sizeof buf, "%.2f GB", n / (1024.0 * 1024 * 1024));
  else if (n >= 1024ull * 1024)
    std::snprintf(buf, sizeof buf, "%.2f MB", n / (1024.0 * 1024));
  else if (n >= 1024)
    std::snprintf(buf, sizeof buf, "%.1f KB", n / 1024.0);
  else
    std::snprintf(buf, sizeof buf, "%llu bytes", static_cast<unsigned long long>(n));
  return buf;
}

// ---- files ----------------------------------------------------------------

namespace {
std::filesystem::path toPath(const std::string &utf8) {
#ifdef _WIN32
  int n = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), nullptr, 0);
  std::wstring w(static_cast<size_t>(n), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), w.data(), n);
  return std::filesystem::path(w);
#else
  return std::filesystem::path(utf8);
#endif
}

} // namespace

std::filesystem::path resolvePath(const std::string &utf8) {
  std::filesystem::path path = toPath(utf8);
  if (path.is_relative() && !path.empty()) {
    const auto &currentFolder = ncdata::DataEngine::instance().currentFolder();
    if (!currentFolder.empty())
      path = currentFolder / path;
  }
  return path;
}

bool readFile(const std::string &path, std::string &bytes, std::string &err) {
  std::error_code ec;
  const auto p = resolvePath(path);
  if (!std::filesystem::exists(p, ec)) {
    err = "file not found: " + path;
    return false;
  }
  if (std::filesystem::is_directory(p, ec)) {
    err = "'" + path + "' is a folder, not a file";
    return false;
  }
  std::ifstream in(p, std::ios::binary);
  if (!in) {
    err = "cannot open '" + path + "' (locked or no read permission)";
    return false;
  }
  in.seekg(0, std::ios::end);
  std::streamoff size = in.tellg();
  in.seekg(0, std::ios::beg);
  bytes.assign(static_cast<size_t>(size < 0 ? 0 : size), '\0');
  // Large files inside a reader are read in 16 MB pieces: the progress bar
  // moves (0 .. 0.5 of the reader's bar) and the IDE's Stop works.
  const std::streamoff kPiece = std::streamoff(16) << 20;
  if (t_progress.depth > 0 && size > 2 * kPiece) {
    for (std::streamoff at = 0; at < size; at += kPiece) {
      const std::streamoff n = std::min(kPiece, size - at);
      in.read(bytes.data() + at, n);
      if (!in) {
        err = "reading '" + path + "' failed after " + formatBytes(static_cast<uint64_t>(at));
        return false;
      }
      if (emitProgress("", "", 0.5 * static_cast<double>(at + n) / static_cast<double>(size))) {
        bytes.clear();
        bytes.shrink_to_fit();
        err = "cancelled";
        return false;
      }
    }
    t_progress.loaded = true;
    return true;
  }
  if (size > 0)
    in.read(bytes.data(), size);
  return true;
}

bool readFileRange(const std::string &path, uint64_t offset, size_t n, std::string &bytes,
                   std::string &err) {
  bytes.clear();
  std::error_code ec;
  const auto p = resolvePath(path);
  if (!std::filesystem::is_regular_file(p, ec)) {
    err = std::filesystem::exists(p, ec) ? "'" + path + "' is not a file" : "file not found: " + path;
    return false;
  }
  const uint64_t size = static_cast<uint64_t>(std::filesystem::file_size(p, ec));
  if (ec) {
    err = "cannot read the size of '" + path + "'";
    return false;
  }
  if (offset >= size)
    return true;
  const uint64_t take = std::min<uint64_t>(n, size - offset);
  std::ifstream in(p, std::ios::binary);
  if (!in) {
    err = "cannot open '" + path + "' (locked or no read permission)";
    return false;
  }
  in.seekg(static_cast<std::streamoff>(offset), std::ios::beg);
  bytes.assign(static_cast<size_t>(take), '\0');
  in.read(bytes.data(), static_cast<std::streamsize>(take));
  bytes.resize(static_cast<size_t>(in.gcount()));
  return true;
}

bool readFileHead(const std::string &path, size_t n, std::string &bytes, std::string &err) {
  return readFileRange(path, 0, n, bytes, err);
}

bool readFileTail(const std::string &path, size_t n, std::string &bytes, std::string &err) {
  const uint64_t size = fileSize(path);
  return readFileRange(path, size > n ? size - n : 0, n, bytes, err);
}

// ---- SourceBytes: a mapped (or read) file -------------------------------------

SourceBytes::~SourceBytes() { close(); }

void SourceBytes::close() {
  if (map_) {
    SysMapping m;
    m.base = map_;
    m.size = mapSize_;
    m.handle = mapHandle_;
    sysUnmapFile(m);
  }
  map_ = nullptr;
  mapHandle_ = nullptr;
  mapSize_ = 0;
  owned_.clear();
  owned_.shrink_to_fit();
  view_ = std::string_view();
}

bool SourceBytes::open(const std::string &pathOrUrl, std::string &err, bool gunzip) {
  close();
  auto useOwned = [&]() {
    if (gunzip && !autoDecompress(owned_, err))
      return false;
    view_ = std::string_view(owned_);
    return true;
  };
  if (isUrl(pathOrUrl)) {
    if (!fetchUrl(pathOrUrl, owned_, err))
      return false;
    return useOwned();
  }
  std::error_code ec;
  const auto p = resolvePath(pathOrUrl);
  if (!std::filesystem::exists(p, ec)) {
    err = "file not found: " + pathOrUrl;
    return false;
  }
  if (std::filesystem::is_directory(p, ec)) {
    err = "'" + pathOrUrl + "' is a folder, not a file";
    return false;
  }
  const uint64_t size = static_cast<uint64_t>(std::filesystem::file_size(p, ec));
  if (ec) {
    err = "cannot read the size of '" + pathOrUrl + "'";
    return false;
  }
  // A gzip file has to be decompressed; an empty one cannot be mapped.
  bool gz = false;
  if (gunzip && size >= 6) { // (isGzip needs 18 bytes: a 2-byte head never matched)
    std::string head, e2;
    gz = readFileHead(pathOrUrl, 18, head, e2) && (isGzip(head) || looksZlib(head));
  }
  if (size > 0 && !gz && size <= static_cast<uint64_t>(SIZE_MAX)) {
    SysMapping m; // io_sys_map.cpp: the per-OS part, with a portable "not mapped"
    if (sysMapFile(p, size, m)) {
      map_ = m.base;
      mapHandle_ = m.handle;
    }
    if (map_) {
      mapSize_ = size;
      view_ = std::string_view(static_cast<const char *>(map_), static_cast<size_t>(size));
      return true;
    }
  }
  // Not mapped: read it (in pieces, with progress and Stop - readFile).
  if (!readFile(pathOrUrl, owned_, err))
    return false;
  return useOwned();
}

// ---- writing: FileSink, SaveScope (2026-11-17) ------------------------------

namespace {
constexpr size_t kSinkPiece = size_t(8) << 20; // bytes collected before a write / a deflate piece

struct PendingFile {
  std::filesystem::path target, temp;
  bool inPlace = false; // appended in place (mode="a"): nothing to move
};
struct SaveState {
  int depth = 0;
  std::string function, file;
  bool zip = false;
  std::vector<PendingFile> files;
  std::chrono::steady_clock::time_point start;
  double lastFraction = 0;
  SaveReport report;
};
thread_local SaveState t_save;
std::mutex g_reportMutex;
SaveReport g_lastReport;

std::string keyOf(const std::filesystem::path &p) {
  std::error_code ec;
  std::filesystem::path a = std::filesystem::absolute(p, ec);
  std::string k = (ec ? p : a).lexically_normal().generic_u8string();
#ifdef _WIN32
  k = lower(k); // one file, whatever the case of its name
#endif
  return k;
}

std::filesystem::path tempPathFor(const std::filesystem::path &target, const char *tag = "") {
  std::filesystem::path t = target;
  t += ".part~" + std::to_string(sysProcessId()) + tag;
  return t;
}

PendingFile *findPending(const std::filesystem::path &target) {
  const std::string k = keyOf(target);
  for (auto &f : t_save.files)
    if (keyOf(f.target) == k)
      return &f;
  return nullptr;
}

// The temporary file a new `target` is written to inside the running save.
std::filesystem::path pendingTemp(const std::filesystem::path &target) {
  if (PendingFile *f = findPending(target)) {
    f->inPlace = false;
    return f->temp;
  }
  t_save.files.push_back({target, tempPathFor(target), false});
  return t_save.files.back().temp;
}

void removeQuiet(const std::filesystem::path &p) {
  std::error_code ec;
  std::filesystem::remove(p, ec);
}

bool folderOk(const std::filesystem::path &p, std::string &err) {
  std::error_code ec;
  if (p.has_parent_path() && !std::filesystem::exists(p.parent_path(), ec)) {
    err = "folder does not exist: " + p.parent_path().u8string();
    return false;
  }
  return true;
}

void putLE(std::string &s, uint64_t v, int n) {
  for (int k = 0; k < n; k++)
    s.push_back(static_cast<char>((v >> (8 * k)) & 0xFF));
}

// The rows / cols a save reports for its data (-1 = not a table).
void dataShape(const Value &v, long long &rows, long long &cols) {
  rows = cols = -1;
  if (v.isObject) {
    const Value *r = field(v, "rows"), *c = field(v, "cols");
    if (r && !r->isText && !r->isArray && !r->isMatrix && c && (c->isArray || c->isMatrix || c->isText)) {
      rows = static_cast<long long>(r->number);
      cols = c->isText ? 1 : static_cast<long long>(c->isArray ? c->length() : c->rows() * c->cols());
    }
    return;
  }
  if (v.isText || v.isDict || v.isND())
    return;
  if (v.isMatrix) {
    rows = static_cast<long long>(v.rows());
    cols = static_cast<long long>(v.rows() ? v.rowLength(0) : 0);
  } else if (v.isArray) {
    rows = static_cast<long long>(v.length());
    cols = 1;
  }
}
} // namespace

FileSink::~FileSink() {
  if (open_)
    abandon();
}

bool FileSink::open(const std::string &path, bool append, std::string &err) {
  const auto p = resolvePath(path);
  if (!folderOk(p, err))
    return false;
  path_ = path;
  target_ = p;
  append_ = append;
  ownTemp_ = false;
  std::filesystem::path at = p;
  bool newEntry = false;
  if (append) {
    if (t_save.depth > 0) {
      if (PendingFile *f = findPending(p)) {
        at = f->temp; // appending to a file this save wrote: still the temporary one
      } else {
        t_save.files.push_back({p, p, true});
        newEntry = true;
      }
    }
  } else if (t_save.depth > 0) {
    newEntry = !findPending(p);
    at = pendingTemp(p);
  } else {
    at = tempPathFor(p);
    ownTemp_ = true;
  }
  temp_ = at;
  auto *out = new std::ofstream(at, std::ios::binary | (append ? std::ios::app : std::ios::trunc));
  if (!*out) {
    delete out;
    if (newEntry)
      t_save.files.pop_back();
    err = "cannot write '" + path + "' (no permission, or the file is open elsewhere)";
    return false;
  }
  out_ = out;
  open_ = true;
  buf_.clear();
  written_ = raw_ = 0;
  gzip_ = gzStarted_ = zlib_ = false;
  crc_ = 0;
  return true;
}

void FileSink::gzip(int level) {
  gzip_ = true;
  zlib_ = false;
  crc_ = 0;
  level_ = level < 0 ? 6 : std::clamp(level, 0, 9);
}

void FileSink::zlib(int level) {
  gzip(level);
  zlib_ = true;
  crc_ = 1; // adler32 starts at 1
}

bool FileSink::compression(const std::string &codec, int level, std::string &err) {
  const std::string c = lower(codec);
  if (c.empty() || c == "none" || c == "no" || c == "false")
    return true;
  if (c == "gz" || c == "gzip" || c == "yes" || c == "true" || c == "deflate") {
    gzip(level);
    return true;
  }
  if (c == "zlib") {
    zlib(level);
    return true;
  }
  err = "compress=\"" + codec + "\" is not built in; use \"gz\" (or \"none\")";
  return false;
}

bool FileSink::flush(bool last, std::string &err) {
  auto &out = *static_cast<std::ofstream *>(out_);
  std::string piece;
  const std::string *data = &buf_;
  if (gzip_) { // gzip or zlib around deflate pieces
    crc_ = zlib_ ? adler32(buf_.data(), buf_.size(), crc_) : crc32(buf_.data(), buf_.size(), crc_);
    if (!gzStarted_) {
      if (zlib_)
        piece.assign("\x78\x9C", 2);
      else
        piece.assign("\x1F\x8B\x08\x00\x00\x00\x00\x00\x00\xFF", 10);
      gzStarted_ = true;
    }
    piece += deflateRawPiece(buf_, level_, last);
    if (last && zlib_) {
      for (int k = 3; k >= 0; k--)
        piece.push_back(static_cast<char>((crc_ >> (8 * k)) & 0xFF));
    } else if (last) {
      putLE(piece, crc_, 4);
      putLE(piece, raw_ & 0xFFFFFFFFu, 4);
    }
    data = &piece;
  }
  out.write(data->data(), static_cast<std::streamsize>(data->size()));
  written_ += data->size();
  buf_.clear();
  if (!out) {
    err = "writing '" + path_ + "' failed (disk full?)";
    return false;
  }
  if (budget_ && written_ > budget_) {
    err = "the output passed max_size " + formatBytes(budget_) +
          " (try compress=\"gz\", fewer rows, or a larger max_size)";
    return false;
  }
  if (!last && saveProgress(t_save.lastFraction)) {
    err = "cancelled";
    return false;
  }
  return true;
}

bool FileSink::write(std::string_view bytes, std::string &err) {
  if (!open_) {
    err = "the file is not open";
    return false;
  }
  raw_ += bytes.size();
  if (!gzip_ && budget_ && written_ + buf_.size() + bytes.size() > budget_) {
    err = "the output passed max_size " + formatBytes(budget_) +
          " (try compress=\"gz\", fewer rows, or a larger max_size)";
    return false;
  }
  if (!gzip_ && buf_.empty() && bytes.size() >= kSinkPiece) { // a big piece: no copy
    auto &out = *static_cast<std::ofstream *>(out_);
    out.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    written_ += bytes.size();
    if (!out) {
      err = "writing '" + path_ + "' failed (disk full?)";
      return false;
    }
    return true;
  }
  buf_.append(bytes.data(), bytes.size());
  if (buf_.size() >= kSinkPiece)
    return flush(false, err);
  return true;
}

bool FileSink::close(std::string &err) {
  if (!open_)
    return true;
  if (!buf_.empty() || gzip_) {
    if (!flush(true, err)) {
      abandon();
      return false;
    }
  }
  auto *out = static_cast<std::ofstream *>(out_);
  out->close();
  const bool bad = out->fail();
  delete out;
  out_ = nullptr;
  open_ = false;
  if (bad) {
    err = "writing '" + path_ + "' failed (disk full?)";
    if (!append_)
      removeQuiet(temp_);
    return false;
  }
  if (ownTemp_) {
    if (!sysReplaceFile(temp_, target_, err)) {
      removeQuiet(temp_);
      return false;
    }
  }
  return true;
}

void FileSink::abandon() {
  if (out_) {
    delete static_cast<std::ofstream *>(out_);
    out_ = nullptr;
  }
  if (open_ && !append_) {
    removeQuiet(temp_);
    if (!ownTemp_ && t_save.depth > 0) {
      const std::string k = keyOf(target_);
      t_save.files.erase(std::remove_if(t_save.files.begin(), t_save.files.end(),
                                        [&](const PendingFile &f) { return keyOf(f.target) == k; }),
                         t_save.files.end());
    }
  }
  open_ = false;
}

bool writeFile(const std::string &path, const std::string &bytes, bool append, std::string &err) {
  FileSink s;
  if (!s.open(path, append, err))
    return false;
  constexpr size_t kSlice = size_t(16) << 20;
  const bool big = bytes.size() > kSlice;
  for (size_t at = 0; at < bytes.size(); at += kSlice) {
    const size_t n = std::min(kSlice, bytes.size() - at);
    if (!s.write(std::string_view(bytes).substr(at, n), err))
      return false; // ~FileSink deletes the partial file
    if (big && saveProgress(static_cast<double>(at + n) / static_cast<double>(bytes.size()))) {
      err = "cancelled";
      return false;
    }
  }
  return s.close(err);
}

std::string saveTargetPath(const std::string &path) {
  if (t_save.depth == 0)
    return path;
  return pendingTemp(resolvePath(path)).u8string();
}

bool saveProgress(double fraction) {
  if (t_save.depth == 0)
    return cancelRequested();
  fraction = std::max(std::clamp(fraction, 0.0, 1.0), t_save.lastFraction);
  t_save.lastFraction = fraction;
  emitEvent({"progress", t_save.function, t_save.file, fraction, ""});
  return cancelRequested();
}

SaveScope::SaveScope(const std::string &function, const std::string &file, bool zip, const Value *data) {
  if (t_save.depth++ > 0)
    return; // joins the running save
  outer_ = true;
  t_save.function = function;
  t_save.file = file;
  t_save.zip = zip;
  t_save.files.clear();
  t_save.lastFraction = 0;
  t_save.start = std::chrono::steady_clock::now();
  t_save.report = SaveReport();
  t_save.report.function = function;
  t_save.report.file = file.empty() ? std::string() : resolvePath(file).u8string();
  if (data)
    dataShape(*data, t_save.report.rows, t_save.report.cols);
}

const SaveReport &SaveScope::report() const { return t_save.report; }

namespace {
// zip=true: every file of the save into one archive (deflate, written piece
// by piece; ZIP64 fields when a size or offset passes 4 GB).
bool writeZip(const std::filesystem::path &archive, std::string &err) {
  const std::filesystem::path temp = tempPathFor(archive, "~zip");
  std::ofstream out(temp, std::ios::binary | std::ios::trunc);
  if (!out) {
    err = "cannot write '" + archive.u8string() + "' (no permission, or the file is open elsewhere)";
    return false;
  }
  // DOS time of now
  const std::time_t now = std::time(nullptr);
  std::tm tmv{};
#ifdef _WIN32
  localtime_s(&tmv, &now);
#else
  localtime_r(&now, &tmv);
#endif
  const uint16_t dosTime = static_cast<uint16_t>((tmv.tm_hour << 11) | (tmv.tm_min << 5) | (tmv.tm_sec / 2));
  const uint16_t dosDate =
      static_cast<uint16_t>(((std::max(tmv.tm_year, 80) - 80) << 9) | ((tmv.tm_mon + 1) << 5) | tmv.tm_mday);
  std::error_code ec;
  const std::filesystem::path base = archive.parent_path();
  std::string central;
  uint64_t offset = 0, done = 0, total = 0;
  for (const auto &f : t_save.files)
    total += std::filesystem::file_size(f.inPlace ? f.target : f.temp, ec);
  size_t count = 0;
  auto fail = [&](const std::string &m) {
    out.close();
    removeQuiet(temp);
    err = m;
    return false;
  };
  for (const auto &f : t_save.files) {
    const std::filesystem::path src = f.inPlace ? f.target : f.temp;
    std::string name;
    std::filesystem::path rel = f.target.lexically_relative(base);
    name = rel.empty() || rel.generic_u8string().rfind("..", 0) == 0 ? f.target.filename().generic_u8string()
                                                                     : rel.generic_u8string();
    if (keyOf(f.target) == keyOf(archive)) // the save was named x.zip: the entry is x
      name = name.substr(0, name.size() - 4);
    std::ifstream in(src, std::ios::binary);
    const uint64_t size = std::filesystem::file_size(src, ec);
    if (!in || ec)
      return fail("cannot read back '" + f.target.u8string() + "' for the zip");
    std::string local;
    putLE(local, 0x04034b50, 4);
    putLE(local, 45, 2);
    putLE(local, 0x0808, 2); // sizes in the data descriptor, UTF-8 names
    putLE(local, 8, 2);
    putLE(local, dosTime, 2);
    putLE(local, dosDate, 2);
    putLE(local, 0, 4);
    putLE(local, 0xFFFFFFFFu, 4);
    putLE(local, 0xFFFFFFFFu, 4);
    putLE(local, name.size(), 2);
    putLE(local, 20, 2);
    local += name;
    putLE(local, 0x0001, 2); // ZIP64: the descriptor carries 8-byte sizes
    putLE(local, 16, 2);
    putLE(local, 0, 8);
    putLE(local, 0, 8);
    out.write(local.data(), static_cast<std::streamsize>(local.size()));
    uint32_t crc = 0;
    uint64_t csize = 0, left = size;
    std::string piece;
    do {
      const size_t n = static_cast<size_t>(std::min<uint64_t>(kSinkPiece, left));
      piece.resize(n);
      in.read(&piece[0], static_cast<std::streamsize>(n));
      if (static_cast<size_t>(in.gcount()) != n)
        return fail("cannot read back '" + f.target.u8string() + "' for the zip");
      left -= n;
      crc = crc32(piece.data(), n, crc);
      const std::string comp = deflateRawPiece(piece, 6, left == 0);
      out.write(comp.data(), static_cast<std::streamsize>(comp.size()));
      csize += comp.size();
      done += n;
      if (total > kSinkPiece && saveProgress(total ? static_cast<double>(done) / static_cast<double>(total) : 1.0))
        return fail("cancelled");
    } while (left > 0);
    std::string desc;
    putLE(desc, 0x08074b50, 4);
    putLE(desc, crc, 4);
    putLE(desc, csize, 8);
    putLE(desc, size, 8);
    out.write(desc.data(), static_cast<std::streamsize>(desc.size()));
    std::string extra;
    const bool bigU = size >= 0xFFFFFFFFu, bigC = csize >= 0xFFFFFFFFu, bigO = offset >= 0xFFFFFFFFu;
    if (bigU)
      putLE(extra, size, 8);
    if (bigC)
      putLE(extra, csize, 8);
    if (bigO)
      putLE(extra, offset, 8);
    putLE(central, 0x02014b50, 4);
    putLE(central, 45, 2);
    putLE(central, 45, 2);
    putLE(central, 0x0808, 2);
    putLE(central, 8, 2);
    putLE(central, dosTime, 2);
    putLE(central, dosDate, 2);
    putLE(central, crc, 4);
    putLE(central, bigC ? 0xFFFFFFFFu : csize, 4);
    putLE(central, bigU ? 0xFFFFFFFFu : size, 4);
    putLE(central, name.size(), 2);
    putLE(central, extra.empty() ? 0 : extra.size() + 4, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 4);
    putLE(central, bigO ? 0xFFFFFFFFu : offset, 4);
    central += name;
    if (!extra.empty()) {
      putLE(central, 0x0001, 2);
      putLE(central, extra.size(), 2);
      central += extra;
    }
    offset += local.size() + csize + desc.size();
    count++;
  }
  const uint64_t cdOffset = offset, cdSize = central.size();
  std::string end = central;
  if (count >= 0xFFFF || cdOffset >= 0xFFFFFFFFu || cdSize >= 0xFFFFFFFFu) {
    const uint64_t z64 = cdOffset + cdSize;
    putLE(end, 0x06064b50, 4);
    putLE(end, 44, 8);
    putLE(end, 45, 2);
    putLE(end, 45, 2);
    putLE(end, 0, 4);
    putLE(end, 0, 4);
    putLE(end, count, 8);
    putLE(end, count, 8);
    putLE(end, cdSize, 8);
    putLE(end, cdOffset, 8);
    putLE(end, 0x07064b50, 4);
    putLE(end, 0, 4);
    putLE(end, z64, 8);
    putLE(end, 1, 4);
  }
  putLE(end, 0x06054b50, 4);
  putLE(end, 0, 2);
  putLE(end, 0, 2);
  putLE(end, std::min<uint64_t>(count, 0xFFFF), 2);
  putLE(end, std::min<uint64_t>(count, 0xFFFF), 2);
  putLE(end, std::min<uint64_t>(cdSize, 0xFFFFFFFFu), 4);
  putLE(end, std::min<uint64_t>(cdOffset, 0xFFFFFFFFu), 4);
  putLE(end, 0, 2);
  out.write(end.data(), static_cast<std::streamsize>(end.size()));
  out.close();
  if (out.fail())
    return fail("writing '" + archive.u8string() + "' failed (disk full?)");
  if (!sysReplaceFile(temp, archive, err)) {
    removeQuiet(temp);
    return false;
  }
  return true;
}
} // namespace

bool SaveScope::commit(std::string &err) {
  if (!outer_ || done_)
    return true;
  if (cancelRequested()) {
    err = "cancelled";
    return false; // the destructor deletes the temporary files
  }
  SaveReport &r = t_save.report;
  std::error_code ec;
  const std::string mainKey = r.file.empty() ? std::string() : keyOf(toPath(r.file));
  if (t_save.zip) {
    if (t_save.files.empty()) {
      err = "zip=true: the save wrote no file to put in the zip";
      return false;
    }
    // named after the file given - or, when the writer added to that name
    // (.ndat's extension, numbered parts), after the first file written
    std::filesystem::path archive = t_save.files.front().target;
    for (const auto &f : t_save.files)
      if (!mainKey.empty() && keyOf(f.target) == mainKey)
        archive = f.target;
    if (lower(archive.extension().u8string()) != ".zip")
      archive += ".zip";
    if (!writeZip(archive, err))
      return false;
    for (const auto &f : t_save.files)
      if (!f.inPlace)
        removeQuiet(f.temp);
    t_save.files.clear();
    r.zipped = true;
    r.file = archive.u8string();
    r.bytes = std::filesystem::file_size(archive, ec);
    r.files = {{r.file, r.bytes}};
  } else {
    r.files.clear();
    for (size_t i = 0; i < t_save.files.size(); i++) {
      const PendingFile &f = t_save.files[i];
      if (!f.inPlace && !sysReplaceFile(f.temp, f.target, err)) {
        for (size_t k = i; k < t_save.files.size(); k++)
          if (!t_save.files[k].inPlace)
            removeQuiet(t_save.files[k].temp);
        t_save.files.clear();
        return false;
      }
      r.files.push_back({f.target.u8string(), std::filesystem::file_size(f.target, ec)});
    }
    t_save.files.clear();
    r.bytes = 0;
    bool found = false;
    for (const auto &f : r.files)
      if (!mainKey.empty() && keyOf(toPath(f.first)) == mainKey) {
        r.bytes = f.second;
        found = true;
      }
    if (!found && !r.files.empty()) { // .ndat added its extension, split parts, a folder: the first file
      r.file = r.files.front().first;
      r.bytes = r.files.front().second;
    }
  }
  r.ok = true;
  done_ = true;
  return true;
}

SaveScope::~SaveScope() {
  t_save.depth--;
  if (!outer_)
    return;
  t_save.depth = 0;
  SaveReport &r = t_save.report;
  if (!done_) { // an error, Stop or an exception: no file is left behind
    for (const auto &f : t_save.files)
      if (!f.inPlace)
        removeQuiet(f.temp);
    t_save.files.clear();
    r.ok = false;
    r.cancelled = cancelRequested();
    r.files.clear();
    r.bytes = 0;
  }
  r.seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - t_save.start).count();
  std::lock_guard<std::mutex> lock(g_reportMutex);
  g_lastReport = r;
}

SaveReport lastSaveReport() {
  std::lock_guard<std::mutex> lock(g_reportMutex);
  return g_lastReport;
}

void clearLastSaveReport() {
  std::lock_guard<std::mutex> lock(g_reportMutex);
  g_lastReport = SaveReport();
}

bool savesFile(const std::string &name) {
  if (name == "save")
    return true;
  if (name.rfind("save_", 0) != 0)
    return false;
  for (const char *server : {"save_postgresql", "save_mysql", "save_oracle", "save_sqlserver"})
    if (name == server)
      return false;
  return true;
}

namespace {
// The 0-based position of parameter `want` in a parameter line (-1 = none);
// commas inside quotes / brackets do not split.
int paramIndex(const std::string &params, const std::string &want) {
  int index = 0, depth = 0;
  bool quoted = false;
  std::string cur;
  auto check = [&]() {
    std::string n = trim(cur.substr(0, cur.find('=')));
    if (!n.empty() && n.back() == '?')
      n.pop_back();
    return n == want;
  };
  for (size_t i = 0; i < params.size(); i++) {
    const char c = params[i];
    if (c == '\\' && quoted && i + 1 < params.size()) {
      cur += c;
      cur += params[++i];
      continue;
    }
    if (c == '"')
      quoted = !quoted;
    else if (!quoted && (c == '[' || c == '('))
      depth++;
    else if (!quoted && (c == ']' || c == ')'))
      depth--;
    if (c == ',' && !quoted && depth == 0) {
      if (check())
        return index;
      index++;
      cur.clear();
      continue;
    }
    cur += c;
  }
  return check() ? index : -1;
}
} // namespace

SingleFn wrapSave(const std::string &name, std::string &params, SingleFn fn) {
  const int modeAt = paramIndex(params, "mode");
  const bool database = name == "save_sqlite";
  params += ", zip=false";
  const int zipAt = paramIndex(params, "zip");
  // .ndat keeps a timestamp / duration with its type; every other format
  // writes the text it prints as (2026-11-18 - the writers used to read the
  // NaN a time value keeps in `number` and wrote "NaN").
  const bool keepsTime = name == "save" || name == "save_ndat" || name == "save_workspace";
  return [name, fn, modeAt, database, zipAt, keepsTime](const std::vector<Value> &a, CallContext &ctx) -> Value {
    std::vector<Value> b(a.begin(), a.end());
    if (!keepsTime)
      for (size_t i = 1; i < b.size(); i++) {
        bool changed = false;
        Value t = ::nctime::timesAsText(b[i], changed);
        if (changed)
          b[i] = std::move(t);
      }
    bool zip = false;
    if (zipAt >= 0 && static_cast<int>(b.size()) > zipAt) {
      const Value &z = b[static_cast<size_t>(zipAt)];
      if (given(z)) {
        if (!z.isBool() && (z.isText || z.isArray || z.isMatrix)) {
          ctx.fail("zip must be true or false");
          return Value(0.0);
        }
        zip = optBool(z, false);
      }
      b.erase(b.begin() + zipAt);
    }
    if (zip && !database && modeAt >= 0 && static_cast<int>(b.size()) > modeAt) {
      const std::string mode = lower(optText(b[static_cast<size_t>(modeAt)], "w"));
      if (mode == "a" || mode == "append") {
        ctx.fail("zip=true writes a new archive - it cannot be used with mode=\"" + mode + "\"");
        return Value(0.0);
      }
    }
    const std::string file = !b.empty() && b[0].isText ? b[0].text() : std::string();
    SaveScope scope(name, file, zip, b.size() > 1 ? &b[1] : nullptr);
    Value r = fn(b, ctx);
    if (!ctx.ok())
      return r;
    std::string err;
    if (!scope.commit(err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (zip && scope.outer())
      return Value(static_cast<double>(scope.report().bytes));
    return r;
  };
}

bool fileExists(const std::string &path) {
  std::error_code ec;
  return std::filesystem::exists(resolvePath(path), ec);
}

uint64_t fileSize(const std::string &path) {
  std::error_code ec;
  auto n = std::filesystem::file_size(resolvePath(path), ec);
  return ec ? 0 : static_cast<uint64_t>(n);
}

std::string extensionOf(const std::string &path) {
  size_t slash = path.find_last_of("/\\");
  size_t dot = path.find_last_of('.');
  if (dot == std::string::npos || (slash != std::string::npos && dot < slash))
    return "";
  return lower(path.substr(dot + 1));
}

bool isUrl(const std::string &s) {
  std::string l = lower(s.substr(0, 8));
  return l.rfind("http://", 0) == 0 || l.rfind("https://", 0) == 0;
}

bool fetchUrl(const std::string &url, std::string &bytes, std::string &err) {
#ifdef _WIN32
  int n = MultiByteToWideChar(CP_UTF8, 0, url.c_str(), -1, nullptr, 0);
  std::wstring wurl(static_cast<size_t>(n), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, url.c_str(), -1, wurl.data(), n);
  URL_COMPONENTS uc{};
  uc.dwStructSize = sizeof uc;
  wchar_t host[256] = {0}, pathBuf[4096] = {0};
  uc.lpszHostName = host;
  uc.dwHostNameLength = 255;
  uc.lpszUrlPath = pathBuf;
  uc.dwUrlPathLength = 4095;
  wchar_t extra[4096] = {0};
  uc.lpszExtraInfo = extra;
  uc.dwExtraInfoLength = 4095;
  if (!WinHttpCrackUrl(wurl.c_str(), 0, 0, &uc)) {
    err = "not a valid URL: " + url;
    return false;
  }
  std::wstring object = std::wstring(pathBuf) + extra;
  HINTERNET session = WinHttpOpen(L"NC-IO/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                  WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
  if (!session)
    session = WinHttpOpen(L"NC-IO/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME,
                          WINHTTP_NO_PROXY_BYPASS, 0);
  if (!session) {
    err = "network is not available (WinHTTP)";
    return false;
  }
  WinHttpSetTimeouts(session, 10000, 10000, 20000, 30000);
  HINTERNET connect = WinHttpConnect(session, host, uc.nPort, 0);
  HINTERNET request =
      connect ? WinHttpOpenRequest(connect, L"GET", object.c_str(), nullptr, WINHTTP_NO_REFERER,
                                   WINHTTP_DEFAULT_ACCEPT_TYPES,
                                   uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0)
              : nullptr;
  bool ok = request && WinHttpSendRequest(request, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                                          WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
            WinHttpReceiveResponse(request, nullptr);
  DWORD status = 0, len = sizeof status;
  if (ok)
    WinHttpQueryHeaders(request, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                        WINHTTP_HEADER_NAME_BY_INDEX, &status, &len, WINHTTP_NO_HEADER_INDEX);
  bytes.clear();
  if (ok && status >= 200 && status < 300) {
    for (;;) {
      DWORD avail = 0;
      if (!WinHttpQueryDataAvailable(request, &avail) || avail == 0)
        break;
      std::string chunk(avail, '\0');
      DWORD got = 0;
      if (!WinHttpReadData(request, chunk.data(), avail, &got) || got == 0)
        break;
      bytes.append(chunk, 0, got);
    }
  }
  if (request) WinHttpCloseHandle(request);
  if (connect) WinHttpCloseHandle(connect);
  WinHttpCloseHandle(session);
  if (!ok) {
    err = "cannot download " + url + " (no network, or the host refused)";
    return false;
  }
  if (status < 200 || status >= 300) {
    err = "download of " + url + " failed with HTTP status " + std::to_string(status);
    return false;
  }
  return true;
#else
  (void)bytes;
  err = "downloading URLs is only built in on Windows; save " + url + " to a file first";
  return false;
#endif
}

bool readSource(const std::string &pathOrUrl, std::string &bytes, std::string &err) {
  return isUrl(pathOrUrl) ? fetchUrl(pathOrUrl, bytes, err) : readFile(pathOrUrl, bytes, err);
}

// A zlib stream (compress="zlib" of the text writers): 0x78, a header whose
// check bits fit, no preset dictionary.
bool looksZlib(std::string_view b) {
  if (b.size() < 6)
    return false;
  const unsigned c0 = static_cast<unsigned char>(b[0]), c1 = static_cast<unsigned char>(b[1]);
  return c0 == 0x78 && (c0 * 256 + c1) % 31 == 0 && !(c1 & 0x20);
}

bool autoDecompress(std::string &bytes, std::string &err) {
  if (!isGzip(bytes)) {
    // zlib (2026-11-17): undone only when the whole stream inflates and its
    // adler32 matches - a text that merely starts like a zlib header ("x^")
    // stays as it is
    if (!looksZlib(bytes))
      return true;
    std::string out, e2;
    size_t used = 0;
    if (!inflateRaw(bytes, 2, out, e2, &used) || 2 + used + 4 > bytes.size())
      return true;
    uint32_t want = 0;
    for (int k = 0; k < 4; k++)
      want = (want << 8) | static_cast<unsigned char>(bytes[2 + used + k]);
    if (adler32(out.data(), out.size()) != want)
      return true;
    bytes.swap(out);
    return true;
  }
  std::string out;
  if (!gzipDecompress(bytes, out, err))
    return false;
  bytes.swap(out);
  return true;
}

bool applyCompression(const std::string &codec, int level, std::string &bytes, std::string &err) {
  const std::string c = lower(codec);
  if (c.empty() || c == "none" || c == "no" || c == "false")
    return true;
  if (level < 0)
    level = 6;
  level = std::clamp(level, 0, 9);
  if (c == "gz" || c == "gzip" || c == "yes" || c == "true" || c == "deflate") {
    bytes = gzipCompress(bytes, level);
    return true;
  }
  if (c == "zlib") {
    bytes = zlibCompress(bytes, level);
    return true;
  }
  err = "compress=\"" + codec + "\" is not built in; use \"gz\" (or \"none\")";
  return false;
}

bool compressOn(const Value &v, bool def) {
  if (!given(v))
    return def;
  if (v.isText) {
    const std::string t = lower(trim(v.text()));
    if (t == "none" || t == "no" || t == "false" || t == "off" || t == "0")
      return false;
    return true;
  }
  return optBool(v, def);
}

bool checkMaxSize(const Value &maxSize, uint64_t bytes, std::string &err) {
  if (!given(maxSize))
    return true;
  uint64_t budget = 0;
  if (!parseByteSize(optText(maxSize), budget)) {
    err = "max_size \"" + optText(maxSize) + "\" is not a size (write e.g. \"48kb\", \"5mb\")";
    return false;
  }
  if (bytes > budget) {
    err = "the output is " + formatBytes(bytes) + ", over max_size " + formatBytes(budget) +
          " (try compress=\"gz\", fewer rows, or a larger max_size)";
    return false;
  }
  return true;
}

// ---- encodings ------------------------------------------------------------

namespace {
void putUtf8(std::string &out, uint32_t cp) {
  if (cp < 0x80) {
    out.push_back(static_cast<char>(cp));
  } else if (cp < 0x800) {
    out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else if (cp < 0x10000) {
    out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else {
    out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  }
}

// Next code point of UTF-8 text (invalid bytes come back as themselves).
uint32_t nextUtf8(const std::string &s, size_t &i) {
  unsigned char c = static_cast<unsigned char>(s[i++]);
  if (c < 0x80)
    return c;
  int extra = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : c >= 0xC0 ? 1 : 0;
  uint32_t cp = c & (0x3F >> extra);
  for (int k = 0; k < extra && i < s.size(); k++)
    cp = (cp << 6) | (static_cast<unsigned char>(s[i++]) & 0x3F);
  return cp;
}

const uint16_t kCp1252[32] = {0x20AC, 0x81,   0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021,
                              0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0x8D,   0x017D, 0x8F,
                              0x90,   0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014,
                              0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x9D,   0x017E, 0x0178};
} // namespace

bool decodeText(const std::string &raw, const std::string &encIn, std::string &utf8,
                std::string &err) {
  std::string enc = lower(encIn);
  enc.erase(std::remove(enc.begin(), enc.end(), '_'), enc.end());
  utf8.clear();
  const unsigned char *p = reinterpret_cast<const unsigned char *>(raw.data());
  bool le16 = raw.size() >= 2 && p[0] == 0xFF && p[1] == 0xFE;
  bool be16 = raw.size() >= 2 && p[0] == 0xFE && p[1] == 0xFF;
  if (le16 || be16 || enc.rfind("utf-16", 0) == 0 || enc.rfind("utf16", 0) == 0) {
    bool big = be16 || enc == "utf-16be" || enc == "utf16be";
    size_t i = (le16 || be16) ? 2 : 0;
    while (i + 1 < raw.size()) {
      uint32_t u = big ? (p[i] << 8 | p[i + 1]) : (p[i + 1] << 8 | p[i]);
      i += 2;
      if (u >= 0xD800 && u < 0xDC00 && i + 1 < raw.size()) {
        uint32_t lo = big ? (p[i] << 8 | p[i + 1]) : (p[i + 1] << 8 | p[i]);
        i += 2;
        u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00);
      }
      putUtf8(utf8, u);
    }
    return true;
  }
  if (enc.empty() || enc == "utf-8" || enc == "utf8" || enc == "ascii" || enc == "us-ascii") {
    size_t start = (raw.size() >= 3 && p[0] == 0xEF && p[1] == 0xBB && p[2] == 0xBF) ? 3 : 0;
    utf8.assign(raw, start, std::string::npos);
    return true;
  }
  if (enc == "latin-1" || enc == "latin1" || enc == "iso-8859-1" || enc == "iso8859-1" ||
      enc == "cp1252" || enc == "windows-1252") {
    bool w = enc == "cp1252" || enc == "windows-1252";
    for (unsigned char c : raw)
      putUtf8(utf8, (w && c >= 0x80 && c < 0xA0) ? kCp1252[c - 0x80] : c);
    return true;
  }
  err = "unknown encoding \"" + encIn + "\" (built in: utf-8, latin-1, cp1252, utf-16)";
  return false;
}

bool encodeText(const std::string &utf8, const std::string &encIn, std::string &raw,
                std::string &err) {
  std::string enc = lower(encIn);
  raw.clear();
  if (enc.empty() || enc == "utf-8" || enc == "utf8" || enc == "ascii") {
    raw = utf8;
    return true;
  }
  if (enc == "utf-8-sig") {
    raw = "\xEF\xBB\xBF" + utf8;
    return true;
  }
  if (enc.rfind("utf-16", 0) == 0 || enc.rfind("utf16", 0) == 0) {
    bool big = enc.find("be") != std::string::npos;
    raw = big ? std::string("\xFE\xFF", 2) : std::string("\xFF\xFE", 2);
    auto put16 = [&](uint32_t u) {
      if (big) {
        raw.push_back(static_cast<char>(u >> 8));
        raw.push_back(static_cast<char>(u & 0xFF));
      } else {
        raw.push_back(static_cast<char>(u & 0xFF));
        raw.push_back(static_cast<char>(u >> 8));
      }
    };
    for (size_t i = 0; i < utf8.size();) {
      uint32_t cp = nextUtf8(utf8, i);
      if (cp >= 0x10000) {
        cp -= 0x10000;
        put16(0xD800 + (cp >> 10));
        put16(0xDC00 + (cp & 0x3FF));
      } else {
        put16(cp);
      }
    }
    return true;
  }
  if (enc == "latin-1" || enc == "latin1" || enc == "iso-8859-1" || enc == "cp1252" ||
      enc == "windows-1252") {
    for (size_t i = 0; i < utf8.size();) {
      uint32_t cp = nextUtf8(utf8, i);
      raw.push_back(cp < 256 ? static_cast<char>(cp) : '?');
    }
    return true;
  }
  err = "unknown encoding \"" + encIn + "\" (built in: utf-8, utf-8-sig, latin-1, utf-16)";
  return false;
}

// ---- values ---------------------------------------------------------------

Value makeObject(const std::string &className, Fields fields) {
  Value v(fields);
  v.isDict = false;
  v.isObject = true;
  v.classNameMut() = className;
  return v;
}

bool isObjectOf(const Value &v, const std::string &className) {
  return v.isObject && v.className() == className;
}

const Value *field(const Value &obj, const std::string &name) {
  if (!obj.isObject && !obj.isDict)
    return nullptr;
  auto it = obj.dict().find(name);
  return it == obj.dict().end() ? nullptr : &it->second;
}

Value textList(const std::vector<std::string> &items) {
  if (items.size() >= 16) { // one text column (what Value(cells) stores), made without a Value per text
    Value::ColumnBuilder b;
    b.reserve(items.size());
    for (const auto &s : items)
      b.pushText(s);
    return Value::columnArray(b.finish());
  }
  std::vector<Value> cells;
  cells.reserve(items.size());
  for (const auto &s : items)
    cells.push_back(Value(s));
  return Value(std::move(cells));
}

Value numberList(const std::vector<double> &items) { return numpy::makeArray(items); }

Value dictOf(const Fields &f) { return Value(f); }

namespace {
bool equalsNoCase(std::string_view s, const char *word) {
  const size_t n = std::strlen(word);
  if (s.size() != n)
    return false;
  for (size_t i = 0; i < n; i++)
    if (std::tolower(static_cast<unsigned char>(s[i])) != word[i])
      return false;
  return true;
}

} // namespace

// What a field is: `text` = the trimmed field (Text), `num` (Number).
FieldKind classifyField(std::string_view raw, const std::vector<std::string> &na, std::string_view &text,
                        double &num, int64_t *big) {
  size_t b = 0, e = raw.size();
  while (b < e && asciiSpace(raw[b]))
    b++;
  while (e > b && asciiSpace(raw[e - 1]))
    e--;
  const std::string_view s = raw.substr(b, e - b);
  for (const auto &n : na)
    if (s == n)
      return FieldKind::NaN;
  text = s;
  if (s.empty())
    return FieldKind::Text;
  if (equalsNoCase(s, "true"))
    return FieldKind::True;
  if (equalsNoCase(s, "false"))
    return FieldKind::False;
  // strtod reads only these first characters (s is trimmed): anything
  // else is text without asking it.
  const char c0 = s[0];
  if (!(std::isdigit(static_cast<unsigned char>(c0)) || c0 == '+' || c0 == '-' || c0 == '.' || c0 == 'i' ||
        c0 == 'I' || c0 == 'n' || c0 == 'N'))
    return FieldKind::Text;
  // A plain number the whole field is: std::from_chars (exact - correctly
  // rounded, as strtod; no copy, much faster). Anything else - a leading '+',
  // out of range, a field it does not read to the end ("2026-03-01", "0x1A"),
  // a NUL inside - takes the strtod path below, which decides as before.
  if (c0 != '+' && s.find('\0') == std::string_view::npos) {
    double fast = 0;
    const auto r = std::from_chars(s.data(), s.data() + s.size(), fast);
    if (r.ec == std::errc() && r.ptr == s.data() + s.size()) {
      num = fast;
      if (big && std::fabs(fast) >= 9007199254740992.0 && std::fabs(fast) < 9.3e18) {
        int64_t v = 0;
        const auto ri = std::from_chars(s.data(), s.data() + s.size(), v);
        if (ri.ec == std::errc() && ri.ptr == s.data() + s.size()) {
          *big = v;
          return FieldKind::BigInt;
        }
      }
      return FieldKind::Number;
    }
  }
  thread_local std::string buf;
  buf.assign(s.data(), s.size());
  const char *p = buf.c_str();
  char *end = nullptr;
  const double d = std::strtod(p, &end);
  if (end && *end == '\0' && end != p) {
    // strtod also takes "0x1A" and "infinity" - only plain decimal forms
    // and inf/nan count as numbers here.
    bool hex = false;
    for (size_t i = 0; i + 1 < s.size() && !hex; i++)
      hex = s[i] == '0' && (s[i + 1] == 'x' || s[i + 1] == 'X');
    if (!hex) {
      num = d;
      // a whole number past 2^53 (where a float64 starts to round): int64, exact
      if (big && std::fabs(d) >= 9007199254740992.0 && std::fabs(d) < 9.3e18) {
        std::string_view digits = s;
        if (digits[0] == '+')
          digits.remove_prefix(1);
        int64_t v = 0;
        const auto r = std::from_chars(digits.data(), digits.data() + digits.size(), v);
        if (r.ec == std::errc() && r.ptr == digits.data() + digits.size()) {
          *big = v;
          return FieldKind::BigInt;
        }
      }
      return FieldKind::Number;
    }
  }
  return FieldKind::Text;
}

Value parseCell(const std::string &raw, const std::vector<std::string> &na) {
  std::string_view text;
  double d = 0;
  int64_t big = 0;
  switch (classifyField(raw, na, text, d, &big)) {
  case FieldKind::BigInt: return Value::integerSigned(IntType::Int64, big);
  case FieldKind::NaN: return Value(missingNumber());
  case FieldKind::True: return Value::boolean(true);
  case FieldKind::False: return Value::boolean(false);
  case FieldKind::Number: return Value(d);
  case FieldKind::Text: break;
  }
  return Value(std::string(text));
}

bool pushCell(Value::ColumnBuilder &b, std::string_view raw, const std::vector<std::string> &na) {
  std::string_view text;
  double d = 0;
  int64_t big = 0;
  switch (classifyField(raw, na, text, d, &big)) {
  case FieldKind::BigInt: b.push(Value::integerSigned(IntType::Int64, big)); return true;
  case FieldKind::NaN: b.pushNumber(missingNumber()); return true;
  case FieldKind::True: b.push(Value::boolean(true)); return false;
  case FieldKind::False: b.push(Value::boolean(false)); return false;
  case FieldKind::Number: b.pushNumber(d); return true;
  case FieldKind::Text: break;
  }
  b.pushText(text);
  return false;
}

bool isNumberCell(const Value &v) { return numpy::isPlainNumber(v) && !v.isBool() && !v.isTime(); }

std::string numberText(double d, const std::string &fmt) {
  if (std::isnan(d))
    return "NaN";
  if (std::isinf(d))
    return d > 0 ? "Inf" : "-Inf";
  char buf[64];
  if (!fmt.empty()) {
    std::snprintf(buf, sizeof buf, fmt.c_str(), d);
    return buf;
  }
  if (d == std::floor(d) && std::fabs(d) < 1e15) {
    std::snprintf(buf, sizeof buf, "%.0f", d);
    return std::strcmp(buf, "-0") == 0 ? "0" : buf;
  }
  auto res = std::to_chars(buf, buf + sizeof buf, d);
  return std::string(buf, res.ptr);
}

std::string cellText(const Value &v, const std::string &floatFmt) {
  if (v.isText)
    return v.text();
  if (v.isBool())
    return v.number != 0 ? "true" : "false";
  if (v.isInt())
    return v.intText();
  if (numpy::isPlainNumber(v))
    return numberText(v.number, (v.number == std::floor(v.number)) ? "" : floatFmt);
  return "";
}

std::string fieldName(const std::string &raw) {
  std::string out;
  bool underscore = false;
  for (unsigned char c : raw) {
    if (std::isalnum(c) || c >= 0x80 || (c == '_' && !underscore)) {
      out.push_back(static_cast<char>(c));
      underscore = false;
    } else if (!out.empty() && !underscore) {
      out.push_back('_');
      underscore = true;
    }
  }
  while (!out.empty() && out.back() == '_')
    out.pop_back();
  if (!out.empty() && std::isdigit(static_cast<unsigned char>(out[0])))
    out = "x" + out;
  return out;
}

std::vector<std::string> uniqueNames(const std::vector<std::string> &raw) {
  std::vector<std::string> out;
  std::map<std::string, int> seen;
  for (size_t i = 0; i < raw.size(); i++) {
    std::string n = trim(raw[i]);
    if (n.empty())
      n = "Col_" + std::to_string(i + 1);
    if (seen.count(n)) {
      int k = ++seen[n];
      std::string cand = n + "_" + std::to_string(k);
      while (seen.count(cand))
        cand = n + "_" + std::to_string(++k);
      seen[cand] = 1;
      out.push_back(cand);
    } else {
      seen[n] = 1;
      out.push_back(n);
    }
  }
  return out;
}

// ---- tables ---------------------------------------------------------------

void tableToRows(Table &t) {
  if (!t.columnar)
    return;
  t.rows = t.data.isMatrix && t.data.rows() > 0 ? t.data.rowsCopy() : std::vector<std::vector<Value>>{};
  t.data = Value();
  t.columnar = false;
}

Table tableTake(const Table &t, const std::vector<size_t> &rows, const std::vector<size_t> &cols) {
  Table out;
  for (size_t c : cols)
    out.cols.push_back(t.cols[c]);
  if (!t.columnar) {
    out.rows.reserve(rows.size());
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(cols.size());
      for (size_t c : cols)
        row.push_back(t.rows[r][c]);
      out.rows.push_back(std::move(row));
    }
    return out;
  }
  if (rows.empty() || cols.empty()) { // as the row form: rows of no cells, or none
    tableFromColumns(out, {}, cols.empty() ? rows.size() : 0);
    return out;
  }
  out.columnar = true;
  if (t.data.isColumnar()) {
    bool allRows = rows.size() == t.data.rows();
    for (size_t k = 0; allRows && k < rows.size(); k++)
      allRows = rows[k] == k;
    out.data = t.data.columnarTake(allRows ? nullptr : &rows, cols); // every row: the columns are shared
  } else if (t.data.isPacked()) { // float64 numbers: gathered in the buffer
    std::vector<double> buf(rows.size() * cols.size());
    for (size_t k = 0; k < cols.size(); k++)
      for (size_t i = 0; i < rows.size(); i++)
        buf[k * rows.size() + i] = t.data.numAt(rows[i], cols[k]);
    out.data = Value::packedMatrix(buf.data(), rows.size(), cols.size()); // unitless, as the readers' tables are
  } else { // other cells (a small table): the cells, as the matrix constructor stores them
    std::vector<std::vector<Value>> m;
    m.reserve(rows.size());
    for (size_t r : rows) {
      std::vector<Value> row;
      for (size_t c : cols)
        row.push_back(t.data.at(r, c));
      m.push_back(std::move(row));
    }
    out.data = Value(std::move(m));
  }
  return out;
}

void tableKeepRows(Table &t, const std::vector<size_t> &keep) {
  if (!t.columnar) { // whole rows, as they are
    std::vector<std::vector<Value>> rows;
    rows.reserve(keep.size());
    for (size_t r : keep)
      rows.push_back(t.rows[r]); // (a row may be kept twice)
    t.rows = std::move(rows);
    return;
  }
  std::vector<size_t> all(t.cols.size());
  for (size_t c = 0; c < all.size(); c++)
    all[c] = c;
  t = tableTake(t, keep, all);
}

std::vector<std::shared_ptr<Value::Column>> finishColumns(std::vector<Value::ColumnBuilder> &builders) {
  std::vector<std::shared_ptr<Value::Column>> cols(builders.size());
  // each column on its own (kind, exceptions, dictionary): on several cores
  nc::par::tasks(builders.size(), 2.0e7, "table columns", [&](size_t c) { cols[c] = builders[c].finish(); });
  std::vector<Value::ColumnBuilder>().swap(builders);
  return cols;
}

bool TableSink::parsed(std::string_view raw, const std::vector<std::string> &na) { return pushCell(next(), raw, na); }

void TableSink::finish(Table &t) {
  if (at_ > 0)
    endRow(); // a row that was started
  tableFromColumns(t, finishColumns(cols_), rows_);
  rows_ = 0;
}

void tableFromColumns(Table &t, std::vector<std::shared_ptr<Value::Column>> cols, size_t nrows) {
  t.rows.clear();
  if (cols.empty()) { // rows of no cells: only the row form says how many
    t.columnar = false;
    t.data = Value();
    t.rows.assign(nrows, std::vector<Value>{});
    return;
  }
  t.columnar = true;
  t.data = Value::fromColumns(std::move(cols), nrows);
}

namespace {
// A number of its own type: int8 ... uint64, float32 / 16 / 8 (2026-11-15: the
// readers keep the file's type; a table of them is not made float64).
bool typedNumberCell(const Value &v) { return isNumberCell(v) && (v.isInt() || v.floatType() != FloatType::Float64); }

// Column c of a column-form table holds a typed number.
bool columnHasTypedNumbers(const Table &t, size_t c) {
  const Value &d = t.data;
  if (d.isTypedPacked())
    return d.elemType() != ElemType::Bool;
  if (!d.isColumnar()) { // packed float64, or plain cells (a small table)
    if (d.isPacked())
      return false;
    for (size_t r = 0; r < d.rows(); r++)
      if (typedNumberCell(d.at(r, c)))
        return true;
    return false;
  }
  const Value::Column &col = d.column(c);
  if (col.kind == Value::Column::Kind::Num && col.etype != ElemType::F64 && col.etype != ElemType::Bool &&
      col.excRows.size() < col.n)
    return true;
  for (const Value &v : col.excVals)
    if (typedNumberCell(v))
      return true;
  for (const Value &v : col.cells)
    if (typedNumberCell(v))
      return true;
  return false;
}

// Every cell of column c of a column-form table is a number (isNumberCell),
// read without making a Value per cell where the storage says so.
bool columnAllNumbers(const Table &t, size_t c) {
  const Value &d = t.data;
  if (d.isPacked())
    return true;
  if (!d.isColumnar()) {
    for (size_t r = 0; r < d.rows(); r++)
      if (!isNumberCell(d.at(r, c)))
        return false;
    return true;
  }
  const Value::Column &col = d.column(c);
  using K = Value::Column::Kind;
  if (col.kind == K::Cells) {
    for (const Value &v : col.cells)
      if (!isNumberCell(v))
        return false;
    return true;
  }
  if ((col.kind == K::Text || col.kind == K::Time) && col.excRows.size() < col.n)
    return false; // a text / time cell
  if (col.kind == K::Num && col.etype == ElemType::Bool && col.excRows.size() < col.n)
    return false; // a bool
  for (const Value &v : col.excVals)
    if (!isNumberCell(v))
      return false;
  return true;
}
} // namespace

void normalizeTable(Table &t) {
  if (t.columnar) {
    const size_t have = t.data.rows() > 0 ? t.data.cols() : t.cols.size();
    if (t.data.rows() > 0 && have < t.cols.size()) {
      tableToRows(t); // fewer cells than names: padded below
    } else {
      while (t.cols.size() < have)
        t.cols.push_back("");
      t.cols = uniqueNames(t.cols);
      return;
    }
  }
  size_t width = t.cols.size();
  for (const auto &r : t.rows)
    width = std::max(width, r.size());
  while (t.cols.size() < width)
    t.cols.push_back("");
  t.cols = uniqueNames(t.cols);
  for (auto &r : t.rows)
    while (r.size() < width)
      r.push_back(Value(missingNumber()));
}

Value tableData(const Table &t) {
  // Already a packed, unitless float64 matrix (all-number columns,
  // Value::fromColumns): that very matrix, shared (2026-11-23, Phase 4) - the
  // loop below rebuilt it number by number into a zeroed buffer, then copied
  // it once more.
  if (t.columnar && t.data.isMatrix && t.data.isPacked() && !t.data.isND() && !t.data.hasUnit() &&
      t.data.rows() > 0)
    return t.data;
  if (t.columnar && t.data.rows() > 0) {
    // all numbers: a packed float64 matrix, as below; else the cells
    const size_t R = t.data.rows(), C = t.data.cols();
    for (size_t c = 0; c < C; c++)
      if (!columnAllNumbers(t, c) || columnHasTypedNumbers(t, c))
        return t.data; // (typed numbers keep their type: never made float64)
    std::vector<double> buf(R * C);
    for (size_t c = 0; c < C; c++)
      for (size_t r = 0; r < R; r++)
        buf[c * R + r] = t.data.numAt(r, c);
    return Value::packedMatrix(buf.data(), R, C);
  }
  if (t.columnar)
    return numpy::makeMatrix(std::vector<std::vector<double>>{});
  bool numeric = true;
  for (const auto &r : t.rows) {
    for (const auto &c : r)
      if (!isNumberCell(c) || typedNumberCell(c)) { // typed numbers keep their type
        numeric = false;
        break;
      }
    if (!numeric)
      break;
  }
  if (numeric) {
    std::vector<std::vector<double>> m;
    m.reserve(t.rows.size());
    for (const auto &r : t.rows) {
      std::vector<double> row;
      row.reserve(r.size());
      for (const auto &c : r)
        row.push_back(c.number);
      m.push_back(std::move(row));
    }
    return numpy::makeMatrix(m);
  }
  return Value(t.rows);
}

Value tableData(Table &&t) {
  if (t.columnar) {
    Value v = tableData(static_cast<const Table &>(t));
    t.data = Value();
    return v;
  }
  for (const auto &r : t.rows)
    for (const auto &c : r)
      if (!isNumberCell(c))
        return Value(std::move(t.rows)); // a cell matrix: the rows move in
  const Table &ct = t;
  return tableData(ct); // numeric: packed from the numbers (no Value kept)
}

Value tableColumn(const Table &t, size_t c) {
  if (t.columnar) {
    const size_t R = t.rowCount();
    if ((columnAllNumbers(t, c) && !columnHasTypedNumbers(t, c)) || R == 0) {
      std::vector<double> v(R);
      for (size_t r = 0; r < R; r++)
        v[r] = t.data.numAt(r, c);
      return numpy::makeArray(v);
    }
    if (t.data.isColumnar()) // the table's own column, shared (D.name and D.data hold it once)
      return Value::columnArray(t.data.columnShared(c));
    std::vector<Value> cells;
    cells.reserve(R);
    for (size_t r = 0; r < R; r++)
      cells.push_back(t.data.at(r, c));
    return Value(std::move(cells));
  }
  bool numeric = true;
  for (const auto &r : t.rows)
    if (!isNumberCell(r[c]) || typedNumberCell(r[c])) { // typed numbers keep their type
      numeric = false;
      break;
    }
  if (numeric) {
    std::vector<double> v;
    v.reserve(t.rows.size());
    for (const auto &r : t.rows)
      v.push_back(r[c].number);
    return numpy::makeArray(v);
  }
  std::vector<Value> cells;
  cells.reserve(t.rows.size());
  for (const auto &r : t.rows)
    cells.push_back(r[c]);
  return Value(std::move(cells));
}

namespace {
bool looksLikeDate(const std::string &s) {
  // 2026-03-01, 2026-03-01T10:00:00, 2026/03/01 12:00
  if (s.size() < 10)
    return false;
  for (int i : {0, 1, 2, 3, 5, 6, 8, 9})
    if (!std::isdigit(static_cast<unsigned char>(s[i])))
      return false;
  return (s[4] == '-' && s[7] == '-') || (s[4] == '/' && s[7] == '/');
}
} // namespace

std::string columnType(const Table &t, size_t c) {
  bool any = false, allInt = true, allNum = true, allBool = true, allDate = true;
  auto visit = [&](const Value &v) {
    if (v.isText && v.text().empty())
      return;
    if (numpy::isPlainNumber(v) && std::isnan(v.number) && !v.isTime())
      return;
    any = true;
    if (!v.isBool())
      allBool = false;
    if (isNumberCell(v)) {
      if (v.number != std::floor(v.number))
        allInt = false;
      allDate = false;
    } else {
      allNum = false;
      allInt = false;
      if (!(v.isText && looksLikeDate(v.text())))
        allDate = false;
    }
  };
  if (t.columnar && t.data.isColumnar()) {
    // the same walk, reading numbers and texts from the column's storage
    const Value::Column &col = t.data.column(c);
    using K = Value::Column::Kind;
    for (size_t r = 0; r < col.n; r++) {
      if (col.kind == K::Cells || col.isExc(r) || col.kind == K::Time ||
          (col.kind == K::Num && col.etype != ElemType::F64)) {
        visit(col.get(r));
      } else if (col.kind == K::Text) {
        const std::string_view s = col.textAt(r);
        if (s.empty())
          continue;
        any = true;
        allBool = allNum = allInt = false;
        if (!looksLikeDate(std::string(s.substr(0, 10))))
          allDate = false;
      } else { // float64 number (unit or not: a plain number)
        const double x = col.f64[r];
        if (std::isnan(x))
          continue;
        any = true;
        allBool = false;
        if (x != std::floor(x))
          allInt = false;
        allDate = false;
      }
    }
  } else if (t.columnar) {
    for (size_t r = 0; r < t.data.rows(); r++)
      visit(t.data.at(r, c));
  } else {
    for (const auto &r : t.rows)
      visit(r[c]);
  }
  if (!any)
    return "empty";
  if (allBool)
    return "bool";
  if (allNum)
    return allInt ? "int64" : "float64";
  if (allDate)
    return "datetime";
  return "str";
}

Value tableSchema(const Table &t) {
  Fields f;
  for (size_t c = 0; c < t.cols.size(); c++)
    f[t.cols[c]] = Value(columnType(t, c));
  return Value(f);
}

Value tableObject(const Table &t, Fields extra, const std::string &cls) {
  Fields f;
  for (size_t c = 0; c < t.cols.size(); c++) {
    std::string n = fieldName(t.cols[c]);
    if (!n.empty())
      f[n] = tableColumn(t, c);
  }
  f["cols"] = textList(t.cols);
  f["rows"] = Value(static_cast<double>(t.rowCount()));
  f["data"] = tableData(t);
  f["schema"] = tableSchema(t);
  for (auto &kv : extra)
    f[kv.first] = std::move(kv.second);
  return makeObject(cls, std::move(f));
}

bool valueToTable(const Value &v, Table &t, std::string &err, bool firstRowHeader, bool keepColumns) {
  t = Table();
  if (v.isObject) {
    const Value *cols = field(v, "cols");
    const Value *data = field(v, "data");
    if (!cols || !data) {
      err = "this object (" + v.className() + ") is not a table";
      return false;
    }
    if (!valueToTable(*data, t, err, false, keepColumns))
      return false;
    std::vector<std::string> names = optTextList(*cols);
    for (size_t i = 0; i < names.size() && i < t.cols.size(); i++)
      t.cols[i] = names[i];
    normalizeTable(t);
    return true;
  }
  if (v.isDict) {
    // A dict of columns (docs/Export_Process_Modules_CPP.md X3), keys in the
    // order they were given (dict(A=A, B=B)), else sorted as before:
    //   a vector (1-D, 1xn or nx1) or a single value is one column named by
    //   its key; a 2-D matrix M (rows x k) gives the columns M_1 ... M_k.
    // Every column must be equally long - a short one is refused, never
    // padded (it used to be filled up with missing values silently).
    // Each cell keeps its own type, so int32 stays an integer column where
    // the format stores types.
    const std::vector<std::string> keys = v.orderedKeys();
    // float64 sources keep float64 in the typed formats (Table::declared)
    auto declaredOf = [](const Value &c) -> std::string {
      if (c.isTypedPacked())
        return (c.elemType() == ElemType::F32 || c.elemType() == ElemType::F64 || c.elemType() == ElemType::F16 || c.elemType() == ElemType::F8) ? "float64" : "";
      return c.isPacked() ? "float64" : "";
    };
    std::vector<std::string> declared;
    std::vector<std::string> names;
    std::vector<std::vector<Value>> cols;
    std::string firstKey;
    size_t n = 0;
    for (const auto &k : keys) {
      const Value &col = v.dict().at(k);
      if (col.isND()) {
        err = "'" + k + "' is an N-dimensional matrix - a table column is a vector (reshape it to 2-D first)";
        return false;
      }
      size_t len = 0;
      if (col.isArray) {
        std::vector<Value> cells;
        len = col.length();
        for (size_t i = 0; i < len; i++) cells.push_back(col.at(i));
        names.push_back(k);
        declared.push_back(declaredOf(col));
        cols.push_back(std::move(cells));
      } else if (col.isMatrix && (col.rows() <= 1 || col.cols() <= 1)) {
        std::vector<Value> cells;
        for (size_t r = 0; r < col.rows(); r++)
          for (size_t c = 0; c < col.rowLength(r); c++) cells.push_back(col.at(r, c));
        len = cells.size();
        names.push_back(k);
        declared.push_back(declaredOf(col));
        cols.push_back(std::move(cells));
      } else if (col.isMatrix) {
        len = col.rows();
        const size_t width = col.cols();
        for (size_t r = 0; r < len; r++)
          if (col.rowLength(r) != width) {
            err = "'" + k + "' has rows of different lengths - it cannot be table columns";
            return false;
          }
        for (size_t c = 0; c < width; c++) {
          std::vector<Value> cells;
          for (size_t r = 0; r < len; r++) cells.push_back(col.at(r, c));
          names.push_back(k + "_" + std::to_string(c + 1));
          declared.push_back(declaredOf(col));
          cols.push_back(std::move(cells));
        }
      } else {
        len = 1;
        names.push_back(k);
        declared.push_back(declaredOf(col));
        cols.push_back({col});
      }
      if (firstKey.empty()) {
        firstKey = k;
        n = len;
      } else if (len != n) {
        err = "the columns must be equally long: " + firstKey + " has " + std::to_string(n) +
              (n == 1 ? " value, " : " values, ") + k + " has " + std::to_string(len);
        return false;
      }
    }
    t.cols = names;
    t.declared = declared;
    t.rows.assign(n, std::vector<Value>(names.size(), Value(missingNumber())));
    for (size_t c = 0; c < cols.size(); c++)
      for (size_t r = 0; r < cols[c].size(); r++)
        t.rows[r][c] = cols[c][r];
    normalizeTable(t);
    return true;
  }
  if (v.isND()) {
    err = "an N-dimensional matrix cannot be written as a table - reshape it to 2-D first";
    return false;
  }
  if (v.isMatrix && keepColumns && (v.isColumnar() || v.isPacked() || v.isTypedPacked()) && v.rows() > 0 &&
      v.cols() > 0) {
    // column form: the matrix itself (rows 1.. of it below a header row)
    bool header = false;
    if (firstRowHeader) {
      header = true;
      for (size_t c = 0; c < v.cols() && header; c++)
        header = v.at(0, c).isText;
    }
    t.columnar = true;
    if (header) {
      for (size_t c = 0; c < v.cols(); c++)
        t.cols.push_back(v.at(0, c).text());
      if (v.rows() == 1) {
        t.data = Value(std::vector<std::vector<Value>>{});
      } else {
        std::vector<size_t> ri, ci;
        for (size_t r = 1; r < v.rows(); r++)
          ri.push_back(r);
        for (size_t c = 0; c < v.cols(); c++)
          ci.push_back(c);
        t.data = v.columnarTake(&ri, ci); // a header row is text: v is columnar
      }
    } else {
      t.data = v;
    }
    normalizeTable(t);
    return true;
  }
  if (v.isMatrix) {
    size_t start = 0;
    if (firstRowHeader && v.rows() > 0) {
      bool allText = v.rowLength(0) > 0;
      for (size_t c = 0; c < v.rowLength(0); c++)
        if (!v.at(0, c).isText)
          allText = false;
      if (allText) {
        for (size_t c = 0; c < v.rowLength(0); c++)
          t.cols.push_back(v.at(0, c).text());
        start = 1;
      }
    }
    for (size_t r = start; r < v.rows(); r++) {
      std::vector<Value> row;
      for (size_t c = 0; c < v.rowLength(r); c++)
        row.push_back(v.at(r, c));
      t.rows.push_back(std::move(row));
    }
    normalizeTable(t);
    return true;
  }
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      t.rows.push_back({v.at(i)});
    normalizeTable(t);
    return true;
  }
  if (v.isText || numpy::isPlainNumber(v)) {
    t.rows.push_back({v});
    normalizeTable(t);
    return true;
  }
  err = "this value cannot be written as a table";
  return false;
}

bool selectTable(Table &t, const Value &cols, const Value &rows, std::string &err) {
  Selector cs, rs;
  if (!parseSelector(cols, cs, err) || !parseSelector(rows, rs, err))
    return false;
  // Nothing selected (2026-11-23, Phase 4): the table as it is. The code
  // below turned a packed float64 table into rows of Values first (~150
  // bytes a cell: a 1 GB CSV of 50 M numbers peaked at 8.8 GB) only to
  // select every row and column and pack them again.
  auto none = [](const Selector &x) { return x.all && x.positions.empty() && x.spans.empty() && x.names.empty(); };
  if (none(cs) && none(rs))
    return true;
  std::vector<size_t> ci, ri;
  if (!resolveSelector(cs, t.cols, t.cols.size(), ci, err))
    return false;
  if (t.columnar && !t.data.isColumnar())
    tableToRows(t); // packed numbers / cells: the row form below
  const size_t nrows = t.rowCount();
  if (!rs.names.empty()) {
    err = "rows are selected by position (rows=[2:500], rows=\"10:\" to the end, rows=\"1:5:-1\" every 5th), "
          "not by name ('" + rs.names.front() + "')";
    return false;
  }
  if (!rs.all) {
    // Rows past the end are simply not there (rows=[1:1000] on 20 rows).
    Selector clipped = rs;
    clipped.positions.clear();
    for (long long p : rs.positions)
      if (p >= 1 && p <= static_cast<long long>(nrows))
        clipped.positions.push_back(p);
    clipped.all = false;
    if (!resolveSelector(clipped, {}, nrows, ri, err))
      return false;
  } else if (!resolveSelector(rs, {}, nrows, ri, err)) {
    return false;
  }
  if (t.columnar) {
    // the columns asked for, sharing a column taken with all its rows
    bool allRows = ri.size() == nrows;
    for (size_t k = 0; allRows && k < ri.size(); k++)
      allRows = ri[k] == k;
    std::vector<std::string> names;
    for (size_t c : ci)
      names.push_back(t.cols[c]);
    std::vector<std::shared_ptr<Value::Column>> cols;
    const size_t n = allRows ? nrows : ri.size();
    if (!ci.empty() && n > 0) {
      Value taken = t.data.columnarTake(allRows ? nullptr : &ri, ci);
      t.cols = std::move(names);
      t.data = std::move(taken);
      if (!t.data.isMatrix || t.data.rows() == 0)
        t.data = Value(std::vector<std::vector<Value>>{});
    } else {
      t.cols = std::move(names);
      tableFromColumns(t, {}, ci.empty() ? n : 0);
    }
    return true;
  }
  Table out;
  for (size_t c : ci)
    out.cols.push_back(t.cols[c]);
  for (size_t r : ri) {
    std::vector<Value> row;
    for (size_t c : ci)
      row.push_back(t.rows[r][c]);
    out.rows.push_back(std::move(row));
  }
  t = std::move(out);
  return true;
}

// ---- registration ---------------------------------------------------------

namespace {
std::vector<std::string> &ioNames() {
  static std::vector<std::string> names;
  return names;
}

bool countParams(const std::string &name, const std::string &params, int &minArgs, int &maxArgs) {
  std::vector<ncargs::ParamSpec> specs;
  std::string err;
  if (!ncargs::parseParamList(params, specs, err)) {
    std::cerr << "Error: importing_data: bad parameter line for " << name << ": " << err << "\n";
    return false;
  }
  minArgs = 0;
  for (const auto &s : specs)
    if (s.kind == ncargs::ParamKind::Required)
      minArgs++;
  maxArgs = static_cast<int>(specs.size());
  return true;
}
} // namespace

const std::vector<std::string> &registeredIoNames() { return ioNames(); }

void addFn(Registry &reg, const std::string &name, const std::string &paramsIn,
           const std::string &summary, const std::string &origin, SingleFn fn) {
  std::string params = paramsIn;
  if (savesFile(name)) // zip=, atomic files, the save report (2026-11-17)
    fn = wrapSave(name, params, std::move(fn));
  int mn = 0, mx = 0;
  if (!countParams(name, params, mn, mx))
    return;
  numpy::FunctionSpec spec;
  spec.name = name;
  spec.section = numpy::Section::ImportingData;
  spec.minArgs = mn;
  spec.maxArgs = mx;
  spec.signature = name + "(" + params + ")";
  spec.summary = summary;
  spec.numpyName = origin;
  spec.impl = std::move(fn);
  if (reg.add(std::move(spec))) {
    reg.setParams(name, params);
    ioNames().push_back(name);
  }
}

void addMulti(Registry &reg, const std::string &name, const std::string &params,
              const std::string &summary, const std::string &origin, int maxOutputs, MultiFn fn) {
  int mn = 0, mx = 0;
  if (!countParams(name, params, mn, mx))
    return;
  numpy::FunctionSpec spec;
  spec.name = name;
  spec.section = numpy::Section::ImportingData;
  spec.minArgs = mn;
  spec.maxArgs = mx;
  spec.signature = name + "(" + params + ")";
  spec.summary = summary;
  spec.numpyName = origin;
  spec.multiImpl = std::move(fn);
  spec.maxOutputs = maxOutputs;
  if (reg.add(std::move(spec))) {
    reg.setParams(name, params);
    ioNames().push_back(name);
  }
}

} // namespace io
} // namespace nc

namespace nc {
namespace io {

Value ndFromRowMajor(const std::vector<size_t> &shape, const std::vector<double> &vals) {
  if (shape.size() <= 1)
    return numpy::makeArray(vals);
  if (shape.size() == 2) {
    std::vector<std::vector<double>> m(shape[0], std::vector<double>(shape[1]));
    for (size_t r = 0; r < shape[0]; r++)
      for (size_t c = 0; c < shape[1]; c++)
        m[r][c] = vals[r * shape[1] + c];
    return numpy::makeMatrix(m);
  }
  const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1];
  nc::F64Buf buf(vals.size());
  const size_t page = rows * cols;
  for (size_t k = 0; k < vals.size(); k++) {
    size_t p = k / page, within = k % page;
    buf[p * page + (within % cols) * rows + within / cols] = vals[k];
  }
  return Value::ndPacked(shape, std::move(buf), false);
}

bool ndToRowMajor(const Value &v, std::vector<size_t> &shape, std::vector<double> &vals) {
  vals.clear();
  if (v.isND()) {
    shape = v.ndShape();
    const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1], page = rows * cols;
    size_t n = v.ndCount();
    vals.resize(n);
    for (size_t k = 0; k < n; k++) {
      size_t p = k / page, within = k % page;
      vals[k] = v.ndAt(p * page + (within % cols) * rows + within / cols).number;
    }
    return true;
  }
  if (v.isMatrix) {
    shape = {v.rows(), v.cols()};
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.cols(); c++)
        vals.push_back(c < v.rowLength(r) ? v.numAt(r, c) : 0);
    return true;
  }
  if (v.isArray) {
    shape = {v.length()};
    for (size_t i = 0; i < v.length(); i++)
      vals.push_back(v.numAt(i));
    return true;
  }
  if (numpy::isPlainNumber(v)) {
    shape = {1};
    vals.push_back(v.number);
    return true;
  }
  return false;
}

Value typedFromRowMajor(ElemType et, const std::vector<size_t> &shape, const std::vector<double> &vals,
                        bool exactOnly) {
  if (et == ElemType::F64 || vals.empty())
    return ndFromRowMajor(shape, vals);
  // never lossy: a value the type cannot hold exactly keeps the data float64
  double lo = 0, hi = 0;
  switch (et) {
  case ElemType::I8: lo = -128; hi = 127; break;
  case ElemType::I16: lo = -32768; hi = 32767; break;
  case ElemType::I32: lo = -2147483648.0; hi = 2147483647.0; break;
  case ElemType::I64: lo = -9223372036854775808.0; hi = 9223372036854774784.0; break;
  case ElemType::U8: hi = 255; break;
  case ElemType::U16: hi = 65535; break;
  case ElemType::U32: hi = 4294967295.0; break;
  case ElemType::U64: hi = 18446744073709549568.0; break;
  case ElemType::Bool: hi = 1; break;
  default: break;
  }
  const bool isFloat = et == ElemType::F32 || et == ElemType::F16 || et == ElemType::F8;
  for (double x : vals) {
    // A float element must be exact in ITS format (float16 / float8 since
    // 2026-11-21 are stored in their own 2 / 1 bytes).
    const double inFormat = et == ElemType::F16  ? ncfloat::roundTo(ncfloat::kFloat16, x)
                            : et == ElemType::F8 ? ncfloat::roundTo(ncfloat::kFloat8, x)
                                                 : static_cast<double>(static_cast<float>(x));
    const bool ok = isFloat ? (!exactOnly || x != x || inFormat == x)
                            : (x == std::floor(x) && x >= lo && x <= hi);
    if (!ok)
      return ndFromRowMajor(shape, vals);
  }
  const size_t b = elemTypeBytes(et), n = vals.size();
  std::vector<uint8_t> raw(n * b);
  // storage index of row-major element k (the layout ndFromRowMajor uses)
  const size_t rank = shape.size();
  const size_t rows = rank >= 2 ? shape[rank - 2] : 1, cols = rank >= 2 ? shape[rank - 1] : n;
  const size_t page = rows * cols;
  for (size_t k = 0; k < n; k++) {
    size_t at = k;
    if (rank >= 2) {
      const size_t p = k / page, within = k % page;
      at = p * page + (within % cols) * rows + within / cols;
    }
    uint8_t *dst = raw.data() + at * b;
    const double x = vals[k];
    switch (et) {
    case ElemType::I8: { int8_t v = static_cast<int8_t>(x); std::memcpy(dst, &v, 1); break; }
    case ElemType::I16: { int16_t v = static_cast<int16_t>(x); std::memcpy(dst, &v, 2); break; }
    case ElemType::I32: { int32_t v = static_cast<int32_t>(x); std::memcpy(dst, &v, 4); break; }
    case ElemType::I64: { int64_t v = static_cast<int64_t>(x); std::memcpy(dst, &v, 8); break; }
    case ElemType::U8: { uint8_t v = static_cast<uint8_t>(x); *dst = v; break; }
    case ElemType::U16: { uint16_t v = static_cast<uint16_t>(x); std::memcpy(dst, &v, 2); break; }
    case ElemType::U32: { uint32_t v = static_cast<uint32_t>(x); std::memcpy(dst, &v, 4); break; }
    case ElemType::U64: { uint64_t v = static_cast<uint64_t>(x); std::memcpy(dst, &v, 8); break; }
    case ElemType::F32: ncfloat::storeF32(dst, x); break;
    case ElemType::F16: ncfloat::storeF16(dst, x); break;
    case ElemType::F8: ncfloat::storeF8(dst, x); break;
    case ElemType::Bool: *dst = x != 0.0 ? 1 : 0; break;
    case ElemType::F64: break;
    }
  }
  return Value::typedTensor(et, rank <= 1 ? std::vector<size_t>{n} : shape, std::move(raw));
}

ElemType smallestLossless(ElemType stored, const std::vector<double> &vals) {
  if (stored != ElemType::F32)
    return stored; // integers / bool / float64: the type itself
  for (double x : vals)
    if (static_cast<double>(static_cast<float>(x)) != x && x == x) // NaN stays NaN in float32
      return ElemType::F64;
  return ElemType::F32;
}

// ---- ismissing / fillmissing (2026-11-15, docs/Import_Window.md §11) ------
//
// A reader gives a missing number (missingNumber(): a NaN with R's NA payload)
// for an empty / null / NA cell. It is a NaN to everything else; these two
// tell it apart from a computed NaN. Element-wise over a number, an array, a
// matrix (packed, cells or stored by columns) or an N-D matrix; an element's
// number is looked at first (numAt), so a table is not expanded into Values.

namespace {
bool missingScalar(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef &&
         isMissingNumber(v.number);
}

Value isMissingFn(const std::vector<Value> &a, CallContext &ctx) {
  (void)ctx;
  const Value &x = a[0];
  std::vector<uint8_t> raw;
  std::vector<size_t> shape;
  if (x.isND()) {
    shape = x.ndShape();
    raw.resize(x.ndCount());
    for (size_t k = 0; k < raw.size(); k++)
      raw[k] = isMissingNumber(x.ndNumAt(k)) && missingScalar(x.ndAt(k));
  } else if (x.isMatrix) {
    const size_t R = x.rows(), C = R ? x.cols() : 0;
    shape = {R, C};
    raw.resize(R * C);
    for (size_t c = 0; c < C; c++) // a typed matrix's storage order: column by column
      for (size_t r = 0; r < R; r++)
        raw[c * R + r] = isMissingNumber(x.numAt(r, c)) && missingScalar(x.at(r, c));
  } else if (x.isArray) {
    shape = {x.length()};
    raw.resize(x.length());
    for (size_t i = 0; i < raw.size(); i++)
      raw[i] = isMissingNumber(x.numAt(i)) && missingScalar(x.at(i));
  } else {
    return Value::boolean(missingScalar(x));
  }
  if (raw.empty())
    return x.isArray ? Value(std::vector<Value>{}) : Value(std::vector<std::vector<Value>>{});
  return Value::typedTensor(ElemType::Bool, std::move(shape), std::move(raw));
}

Value fillMissingFn(const std::vector<Value> &a, CallContext &ctx) {
  (void)ctx;
  const Value &x = a[0], &fill = a[1];
  if (x.isND()) {
    Value y = x;
    for (size_t k = 0; k < x.ndCount(); k++)
      if (isMissingNumber(x.ndNumAt(k)) && missingScalar(x.ndAt(k)))
        y.ndSetAt(k, fill);
    return y;
  }
  if (x.isMatrix) {
    Value y = x;
    const size_t R = x.rows(), C = R ? x.cols() : 0;
    for (size_t c = 0; c < C; c++)
      for (size_t r = 0; r < R; r++)
        if (isMissingNumber(x.numAt(r, c)) && missingScalar(x.at(r, c)))
          y.setAt(r, c, fill);
    return y;
  }
  if (x.isArray) {
    Value y = x;
    for (size_t i = 0; i < x.length(); i++)
      if (isMissingNumber(x.numAt(i)) && missingScalar(x.at(i)))
        y.setAt(i, fill);
    return y;
  }
  return missingScalar(x) ? fill : x;
}
} // namespace

void registerMissing(Registry &reg) {
  addFn(reg, "ismissing", "X",
        "true where X holds a missing value (an empty / null / NA cell of a file), element by element; a computed NaN is not missing",
        "pandas.isna", isMissingFn);
  addFn(reg, "fillmissing", "X, value",
        "X with every missing value (an empty / null / NA cell of a file) replaced by value", "pandas.DataFrame.fillna",
        fillMissingFn);
}

} // namespace io
} // namespace nc
