// NC data files (.ndat): save / load / read, ndat_info, ndat_export (io_ndat.h).
//
// ---- How save decides the storage of each entry ----------------------------
//
// An entry is one value: the data of save(file, data), one key of a saved
// dict, or one variable of the workspace (save(file) with no data). Each is
// classified:
//
//   tensor  a real float64 matrix or N-D matrix (no units)
//   table   an NcTable (from read_csv, read_parquet, ...) or a dict of
//           equal-length columns, each all numbers, all text or all bools
//   other   everything else (numbers, text, small data, dicts, objects,
//           units, timestamps, integer types, complex, function references)
//
// and stored as (policy "auto", the default):
//
//   tensor of 32768 values (256 KiB) or more that gzip at least halves (a
//          sample is compressed first) -> HDF5: chunked, byte-shuffled,
//          gzip level 4; read(file, name, "1:100, :") reads only the chunks
//          needed. A tensor that compresses less stays native: writing and
//          reading it is a plain copy (a slice of it is cut in memory).
//   table of 4096 cells or more, with text or bool columns -> Parquet with
//          dictionary encoding + zstd: text compresses many times over.
//   table of 4096 cells or more, all numeric -> Arrow IPC: decoding is a
//          plain copy, the fastest to load.
//   everything else -> native NDAT node: exact for every NC type, tiny
//          overhead, fastest for small values.
//
// Other policies: "compact" (smallest file: lower thresholds, gzip 9, every
// table Parquet zstd 9), "fast" (fastest load: tensors native, tables Arrow),
// "native" (everything native), and "hdf5" / "parquet" / "arrow" (that
// encoding for every entry it can hold).
//
// Exactness: before the file is written, every non-native section is decoded
// again and compared with the original (the deterministic NDAT fingerprint);
// an entry that would not come back identical is stored native instead, so
// read(save(x)) == x always.
//
// Threads: sections are encoded from prepared buffers through
// nc::scipy::par::tasks (Scipy/scipy_parallel.h), one task per HDF5 entry;
// everything that builds or compares NC values stays on the calling thread.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>
#include <set>

#include "../../../data/DataEngine.h"
#include "../../../data/DataSupport/BinaryIO.h"
#include "../../../data/DataSupport/NdatReader.h"
#include "../../../data/DataSupport/NdatWriter.h"
#include "../../Scipy/scipy_parallel.h"
#include "../numpy_common.h"
#include "../numpy_main.h"
#include "io_columnar.h"
#include "io_deflate.h"
#include "io_formats.h"
#include "io_h5.h"
#include "io_ndat.h"

namespace nc {
namespace io {

namespace {

using ncdata::bundle::BundleReader;
using ncdata::bundle::Encoding;
using ncdata::bundle::EntryInfo;
using ncdata::bundle::Root;
using ncdata::bundle::Section;

/* ================= policy ================= */

struct Policy {
  std::string name;
  size_t tensorMin = 32768;  // values; 0 = never HDF5
  int gzipLevel = 4;
  double maxRatio = 0.5;     // HDF5 only when the probe keeps at most this part of the size
  size_t tableMin = 4096;    // cells; 0 = never a table section
  bool numericArrow = true;  // numeric tables Arrow (else Parquet)
  bool textParquet = true;   // text / bool tables Parquet (else Arrow)
  int zstdLevel = 5;
};

bool policyOf(const std::string &raw, Policy &p, std::string &err) {
  const std::string n = lower(trim(raw.empty() ? "auto" : raw));
  p = Policy();
  p.name = n;
  if (n == "auto") {
  } else if (n == "compact" || n == "small") {
    p.name = "compact";
    p.tensorMin = 4096;
    p.maxRatio = 0.95;
    p.gzipLevel = 9;
    p.tableMin = 256;
    p.numericArrow = false;
    p.zstdLevel = 9;
  } else if (n == "fast") {
    p.tensorMin = 0;
    p.textParquet = false;
  } else if (n == "native") {
    p.tensorMin = 0;
    p.tableMin = 0;
  } else if (n == "hdf5" || n == "h5") {
    p.name = "hdf5";
    p.tensorMin = 1;
    p.maxRatio = 100.0; // always (uncompressed when it would not shrink)
    p.tableMin = 0;
  } else if (n == "parquet") {
    p.tensorMin = 0;
    p.tableMin = 1;
    p.numericArrow = false;
  } else if (n == "arrow" || n == "feather" || n == "ipc") {
    p.name = "arrow";
    p.tensorMin = 0;
    p.tableMin = 1;
    p.textParquet = false;
  } else {
    err = "the policy must be \"auto\", \"compact\", \"fast\", \"native\", \"hdf5\", \"parquet\" "
          "or \"arrow\" (got \"" + raw + "\")";
    return false;
  }
  return true;
}

/* ================= paths ================= */

std::filesystem::path ndatPath(const std::string &userPath) {
  std::filesystem::path p = resolvePath(userPath);
  if (!p.has_extension())
    p += ".ndat";
  return p;
}

// The function suffix (read_<ext>) for a file extension, "" when none.
std::string formatOf(const std::string &userPath) {
  std::string e = extensionOf(userPath);
  static const std::map<std::string, std::string> alias = {
      {"hdf5", "h5"}, {"arrow", "feather"}, {"ipc", "feather"}, {"yml", "yaml"}};
  auto it = alias.find(e);
  if (it != alias.end())
    e = it->second;
  return e;
}

bool hasIoFunction(const std::string &name) {
  const auto &names = registeredIoNames();
  return std::find(names.begin(), names.end(), name) != names.end();
}

/* ================= native ================= */

std::string nativeBytes(const Value &v) {
  ncdata::VectorSink s;
  ncdata::writeValueNode(s, v);
  return std::string(s.buffer.begin(), s.buffer.end());
}

bool nativeDecode(const std::string &bytes, Value &out, std::string &err) {
  ncdata::ByteReader r(reinterpret_cast<const uint8_t *>(bytes.data()), bytes.size());
  return ncdata::readValueNode(r, out, err) && r.ok();
}

uint64_t fingerprint(const Value &v) { return ncdata::valueFingerprint(v); }

/* ================= tensors <-> HDF5 ================= */

// A real float64 matrix / N-D matrix without a unit: its row-major numbers
// and shape. Only the packed form qualifies - it is plain float64 by
// construction - so this is one pass over raw doubles (column-major pages
// to row-major), with nothing to check per element.
bool tensorOf(const Value &v, std::vector<size_t> &shape, std::vector<double> &vals) {
  if (!v.isMatrix || !v.isPacked())
    return false;
  shape = v.isND() ? v.ndShape() : std::vector<size_t>{v.rows(), v.cols()};
  if (shape.size() < 2)
    return false;
  const Value first = v.isND() ? v.ndAt(0) : v.at(0, 0);
  if (first.dimL || first.dimT || first.dimM)
    return false;
  const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1];
  const size_t page = rows * cols;
  size_t n = 1;
  for (size_t d : shape)
    n *= d;
  const double *src = v.packedData();
  vals.resize(n);
  for (size_t p0 = 0; p0 < n; p0 += page)
    for (size_t c = 0; c < cols; c++)
      for (size_t r = 0; r < rows; r++)
        vals[p0 + r * cols + c] = src[p0 + c * rows + r];
  return true;
}

// The HDF5 file of one dataset "/data".
H5WNode tensorNode(const std::vector<size_t> &shape, const std::vector<double> &vals, int level) {
  H5WNode root;
  root.name = "/";
  root.group = true;
  H5WNode d;
  d.name = "data";
  d.group = false;
  d.data = h5Numbers(shape, vals);
  std::vector<uint64_t> dims(shape.begin(), shape.end());
  d.chunk = h5AutoChunk(dims, 8);
  d.compress = level > 0 ? "gzip" : "none";
  d.level = level > 0 ? level : 4;
  d.shuffle = level > 0;
  root.kids.push_back(std::move(d));
  return root;
}

// Reads "/data" (or part of it: slice "1:10, :", NC 1-based inclusive).
bool decodeTensor(const std::string &bytes, const std::string &slice, Value &out, std::string &err) {
  H5Reader r;
  if (!r.open(bytes, err))
    return false;
  const H5Object *o = r.find("/data");
  if (!o) {
    err = "the HDF5 section has no /data dataset";
    return false;
  }
  std::vector<std::pair<size_t, size_t>> ranges;
  std::vector<bool> single;
  if (!slice.empty() && !h5ParseSlice(slice, o->dims, ranges, err, &single))
    return false;
  H5Value v;
  if (!r.readData(*o, ranges, v, err))
    return false;
  if (!single.empty()) {
    std::vector<size_t> s;
    for (size_t d = 0; d < v.shape.size(); d++)
      if (d >= single.size() || !single[d])
        s.push_back(v.shape[d]);
    v.shape = s;
  }
  out = h5ToValue(v);
  return true;
}

/* ================= tables <-> Parquet / Arrow ================= */

enum class CellKind { None, Num, Text, Bool, Mixed };

CellKind kindOf(const Value &c) {
  if (c.isText)
    return CellKind::Text;
  if (c.isBool())
    return CellKind::Bool;
  if (numpy::isPlainNumber(c) && !c.isComplex)
    return CellKind::Num;
  return CellKind::Mixed;
}

// The cells of a vector-shaped value and how it was laid out.
bool columnCells(const Value &v, std::vector<Value> &cells, std::string &orient) {
  cells.clear();
  if (v.isND())
    return false;
  if (v.isArray) {
    orient = "array";
    for (size_t i = 0; i < v.length(); i++)
      cells.push_back(v.at(i));
    return true;
  }
  if (v.isMatrix && v.rows() == 1) {
    orient = "row";
    for (size_t c = 0; c < v.cols(); c++)
      cells.push_back(v.at(0, c));
    return true;
  }
  if (v.isMatrix && v.cols() == 1 && v.rows() > 1) {
    orient = "col";
    for (size_t r = 0; r < v.rows(); r++)
      cells.push_back(v.at(r, 0));
    return true;
  }
  return false;
}

Value columnValue(std::vector<Value> cells, const std::string &orient) {
  if (orient == "array")
    return Value(std::move(cells));
  if (orient == "col") {
    std::vector<std::vector<Value>> rows;
    for (auto &c : cells)
      rows.push_back({std::move(c)});
    return Value(std::move(rows));
  }
  return Value(std::vector<std::vector<Value>>{std::move(cells)});
}

// A table-shaped value as a Table, and the meta needed to rebuild it.
// numericOnly: every column holds numbers.
bool tableOf(const Value &v, Table &t, Value &meta, bool &numericOnly) {
  numericOnly = true;
  Fields m;
  if (v.isObject && field(v, "cols") && field(v, "data")) {
    // a table object (NcTable, or a reader's own table class)
    std::string err;
    if (!valueToTable(v, t, err) || t.cols.empty() || t.rows.empty())
      return false;
    // fields the table object does not rebuild by itself
    const Value rebuilt = tableObject(t, {}, v.className());
    Fields extra;
    for (const auto &kv : v.dict())
      if (!rebuilt.dict().count(kv.first))
        extra[kv.first] = kv.second;
    m["kind"] = Value("nctable");
    m["class"] = Value(v.className());
    m["extra"] = Value(extra);
  } else if (v.isDict && !v.dict().empty()) {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    size_t n = 0;
    Fields orient;
    std::vector<std::vector<Value>> cols;
    for (const auto &k : keys) {
      std::vector<Value> cells;
      std::string o;
      if (!columnCells(v.dict().at(k), cells, o) || cells.empty())
        return false;
      if (cols.empty())
        n = cells.size();
      else if (cells.size() != n)
        return false;
      CellKind kind = kindOf(cells[0]);
      for (const auto &c : cells)
        if (kindOf(c) != kind)
          return false;
      if (kind == CellKind::Mixed)
        return false;
      orient[k] = Value(o);
      cols.push_back(std::move(cells));
    }
    t = Table();
    t.cols = keys;
    t.rows.assign(n, std::vector<Value>(keys.size()));
    for (size_t c = 0; c < keys.size(); c++)
      for (size_t r = 0; r < n; r++)
        t.rows[r][c] = cols[c][r];
    m["kind"] = Value("columns");
    m["orient"] = Value(orient);
  } else if (v.isMatrix && !v.isND() && v.rows() >= 2 && v.cols() >= 1) {
    // A cell matrix whose columns are each all numbers, all text or all
    // bools (what read_csv gives), optionally under a row of text headers.
    const size_t R = v.rows(), C = v.cols();
    for (size_t r = 0; r < R; r++)
      if (v.rowLength(r) != C)
        return false;
    auto homogeneous = [&](size_t from, bool &anyText) {
      anyText = false;
      for (size_t c = 0; c < C; c++) {
        const CellKind k = kindOf(v.at(from, c));
        if (k == CellKind::Mixed)
          return false;
        if (k != CellKind::Num)
          anyText = true;
        for (size_t r = from + 1; r < R; r++)
          if (kindOf(v.at(r, c)) != k)
            return false;
      }
      return true;
    };
    bool anyText = false, header = false;
    if (!homogeneous(0, anyText)) {
      // a header row: all text, distinct and not empty
      std::set<std::string> seen;
      for (size_t c = 0; c < C; c++) {
        const Value h = v.at(0, c);
        if (!h.isText || h.text().empty() || !seen.insert(h.text()).second)
          return false;
      }
      if (R < 3 || !homogeneous(1, anyText))
        return false;
      header = true;
    }
    if (!anyText && !header)
      return false; // all numbers: a tensor, not a table
    t = Table();
    for (size_t c = 0; c < C; c++)
      t.cols.push_back(header ? v.at(0, c).text() : "c" + std::to_string(c + 1));
    for (size_t r = header ? 1 : 0; r < R; r++) {
      std::vector<Value> row;
      for (size_t c = 0; c < C; c++)
        row.push_back(v.at(r, c));
      t.rows.push_back(std::move(row));
    }
    m["kind"] = Value("cells");
    m["header"] = Value::boolean(header);
  } else {
    return false;
  }
  for (const auto &k : writeKinds(t))
    if (k != "int64" && k != "float64")
      numericOnly = false;
  m["rows"] = Value(static_cast<double>(t.rows.size()));
  m["cols"] = textList(t.cols);
  meta = Value(m);
  return true;
}

Value tableValue(const Table &t, const Value &meta) {
  const Value *kind = field(meta, "kind");
  if (kind && kind->isText && kind->text() == "nctable") {
    Fields extra;
    if (const Value *e = field(meta, "extra"))
      if (e->isDict)
        extra = e->dict();
    const Value *cls = field(meta, "class");
    return tableObject(t, extra, cls && cls->isText ? cls->text() : "NcTable");
  }
  if (kind && kind->isText && kind->text() == "cells") {
    const Value *h = field(meta, "header");
    std::vector<std::vector<Value>> rows;
    if (h && h->number != 0.0) {
      std::vector<Value> head;
      for (const auto &c : t.cols)
        head.push_back(Value(c));
      rows.push_back(std::move(head));
    }
    for (const auto &r : t.rows)
      rows.push_back(r);
    return Value(std::move(rows));
  }
  const Value *orient = field(meta, "orient");
  Fields out;
  for (size_t c = 0; c < t.cols.size(); c++) {
    std::vector<Value> cells;
    for (const auto &row : t.rows)
      cells.push_back(c < row.size() ? row[c] : Value(std::nan("")));
    std::string o = "row";
    if (orient && orient->isDict) {
      auto it = orient->dict().find(t.cols[c]);
      if (it != orient->dict().end() && it->second.isText)
        o = it->second.text();
    }
    out[t.cols[c]] = columnValue(std::move(cells), o);
  }
  return Value(out);
}

bool decodeTable(const std::string &bytes, Encoding enc, const std::vector<std::string> &cols,
                 const Value &meta, Value &out, std::string &err) {
  ColReadOptions o;
  o.cols = cols;
  ColFile f;
  const bool ok = enc == Encoding::Parquet ? readParquet(bytes, o, f, err) : readArrowIpc(bytes, o, f, err);
  if (!ok)
    return false;
  out = tableValue(f.table, meta);
  return true;
}

/* ================= planning one entry ================= */

struct Planned {
  Section section;
  std::string note; // why it is native, when a better encoding was refused
};

void addMeta(Value &meta, const std::string &key, const Value &v) {
  Fields f = meta.isDict ? meta.dict() : Fields{};
  f[key] = v;
  meta = Value(f);
}

Section nativeSection(const std::string &name, const Value &v, const std::string &note) {
  Section s;
  s.name = name;
  s.encoding = Encoding::Native;
  s.bytes = nativeBytes(v);
  Fields m;
  m["kind"] = Value("value");
  if (!note.empty())
    m["note"] = Value(note);
  s.meta = Value(m);
  return s;
}

// HDF5 jobs are encoded in parallel tasks; the rest is serial.
struct TensorJob {
  size_t index;
  std::vector<size_t> shape;
  std::vector<double> vals;
  int level;
  std::string bytes, err;
};

Value shapeValue(const std::vector<size_t> &shape) {
  std::vector<double> d(shape.begin(), shape.end());
  return numberList(d);
}

// How much of its size gzip keeps of the tensor, byte-shuffled as HDF5
// stores it, measured on up to 4 samples of 16384 values spread over the
// data (1 = incompressible). Costs a fraction of compressing everything, so
// noise-like data never pays for a slow compression that saves nothing.
double probeRatio(const std::vector<double> &vals, int level) {
  const size_t per = 16384, n = vals.size();
  if (n == 0)
    return 1.0;
  const size_t take = std::min<size_t>(4, (n + per - 1) / per);
  std::string raw;
  for (size_t s = 0; s < take; s++) {
    const size_t start = (take == 1 || n <= per) ? 0 : (n - per) * s / (take - 1);
    const size_t len = std::min(per, n - start);
    std::string block(len * 8, '\0');
    for (size_t k = 0; k < len; k++) {
      uint64_t bits;
      std::memcpy(&bits, &vals[start + k], 8);
      for (int byte = 0; byte < 8; byte++)
        block[byte * len + k] = static_cast<char>((bits >> (8 * byte)) & 0xff);
    }
    raw += block;
  }
  const std::string z = zlibCompress(raw, level > 0 ? level : 4);
  return static_cast<double>(z.size()) / static_cast<double>(raw.size());
}

// The first field / key whose value differs between two values ("" = none found).
std::string firstDifference(const Value &a, const Value &b) {
  if ((a.isDict || a.isObject) && (b.isDict || b.isObject)) {
    std::vector<std::string> keys;
    for (const auto &kv : a.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      auto it = b.dict().find(k);
      if (it == b.dict().end())
        return k + " (missing)";
      if (fingerprint(it->second) != fingerprint(a.dict().at(k)))
        return k;
    }
    for (const auto &kv : b.dict())
      if (!a.dict().count(kv.first))
        return kv.first + " (extra)";
  }
  return "";
}

bool planEntries(const NamedEntries &entries, const Policy &p, std::vector<Section> &out) {
  out.assign(entries.size(), Section());
  std::vector<bool> chosen(entries.size(), false);
  std::vector<TensorJob> jobs;
  std::vector<std::string> notes(entries.size());
  for (size_t i = 0; i < entries.size(); i++) {
    const std::string &name = entries[i].first;
    const Value &v = entries[i].second;
    out[i].name = name;
    std::vector<size_t> shape;
    std::vector<double> vals;
    if (p.tensorMin > 0 && tensorOf(v, shape, vals) && vals.size() >= p.tensorMin) {
      {
        const double ratio = probeRatio(vals, p.gzipLevel);
        if (ratio <= p.maxRatio) {
          const int level = ratio <= 0.95 ? p.gzipLevel : 0;
          jobs.push_back({i, std::move(shape), std::move(vals), level, "", ""});
          chosen[i] = true;
          continue;
        }
        notes[i] = "compresses to " + std::to_string(static_cast<int>(ratio * 100 + 0.5)) +
                   " % only - native is faster (slices still read)";
      }
    }
    Table t;
    Value meta;
    bool numeric = false;
    if (p.tableMin > 0 && tableOf(v, t, meta, numeric) && t.rows.size() * t.cols.size() >= p.tableMin) {
      const bool arrow = numeric ? p.numericArrow : !p.textParquet;
      ColWriteOptions o;
      o.codec = arrow ? "none" : "zstd";
      o.level = p.zstdLevel;
      std::string err;
      std::string bytes = arrow ? writeArrowIpc(t, o, err) : writeParquet(t, o, err);
      if (bytes.empty() || !err.empty()) {
        notes[i] = "table encoding failed: " + err;
        continue;
      }
      Value back;
      std::string derr;
      const Encoding enc = arrow ? Encoding::Arrow : Encoding::Parquet;
      if (!decodeTable(bytes, enc, {}, meta, back, derr) || fingerprint(back) != fingerprint(v)) {
        const std::string d = derr.empty() ? firstDifference(v, back) : derr;
        notes[i] = "would not read back exactly as a table" + (d.empty() ? "" : " (" + d + ")");
        continue;
      }
      addMeta(meta, "codec", Value(o.codec));
      out[i].encoding = enc;
      out[i].bytes = std::move(bytes);
      out[i].meta = meta;
      chosen[i] = true;
    }
  }
  // HDF5 sections: pure byte work on prepared buffers, one task per tensor.
  std::vector<std::function<void()>> work;
  for (auto &j : jobs)
    work.push_back([&j] { j.bytes = writeH5(tensorNode(j.shape, j.vals, j.level), 0, j.err); });
  scipy::par::tasks(work);
  for (auto &j : jobs) {
    if (!j.err.empty()) {
      chosen[j.index] = false;
      notes[j.index] = "HDF5 encoding failed: " + j.err;
      continue;
    }
    Fields m;
    m["kind"] = Value("tensor");
    m["shape"] = shapeValue(j.shape);
    m["codec"] = Value(j.level > 0 ? "gzip+shuffle" : "none");
    out[j.index].encoding = Encoding::Hdf5;
    out[j.index].bytes = std::move(j.bytes);
    out[j.index].meta = Value(m);
  }
  for (size_t i = 0; i < out.size(); i++)
    if (!chosen[i])
      out[i] = nativeSection(entries[i].first, entries[i].second, notes[i]);
  return true;
}

/* ================= reading entries ================= */

bool decodeEntry(BundleReader &r, const EntryInfo &e, const Value &part, Value &out, std::string &err) {
  std::string bytes;
  if (!r.section(e, bytes, err))
    return false;
  const bool partial = given(part);
  switch (e.encoding) {
  case Encoding::Native: {
    if (!nativeDecode(bytes, out, err))
      return false;
    if (!partial)
      return true;
    // a slice of a native tensor: cut in memory (native data reads fast)
    std::vector<size_t> shape;
    std::vector<double> vals;
    if (!part.isText || !tensorOf(out, shape, vals)) {
      err = "entry '" + e.name + "' is read whole - a part is a slice of a numeric matrix "
            "(\"1:10, :\") or the columns of a table";
      return false;
    }
    std::vector<uint64_t> dims(shape.begin(), shape.end());
    std::vector<std::pair<size_t, size_t>> ranges;
    std::vector<bool> single;
    if (!h5ParseSlice(part.text(), dims, ranges, err, &single))
      return false;
    std::vector<size_t> outShape, keepShape;
    for (size_t d = 0; d < shape.size(); d++) {
      outShape.push_back(ranges[d].second - ranges[d].first);
      if (d >= single.size() || !single[d])
        keepShape.push_back(outShape.back());
    }
    std::vector<double> sel;
    std::vector<size_t> idx(shape.size(), 0);
    size_t total = 1;
    for (size_t d : outShape)
      total *= d;
    sel.reserve(total);
    for (size_t k = 0; k < total; k++) {
      size_t flat = 0;
      for (size_t d = 0; d < shape.size(); d++)
        flat = flat * shape[d] + ranges[d].first + idx[d];
      sel.push_back(vals[flat]);
      for (size_t d = shape.size(); d-- > 0;) {
        if (++idx[d] < outShape[d])
          break;
        idx[d] = 0;
      }
    }
    out = keepShape.empty() ? Value(sel.empty() ? 0.0 : sel[0]) : ndFromRowMajor(keepShape, sel);
    return true;
  }
  case Encoding::Hdf5:
    if (partial && !part.isText) {
      err = "a part of tensor '" + e.name + "' is a slice in quotes, e.g. \"1:10, :\"";
      return false;
    }
    return decodeTensor(bytes, partial ? part.text() : "", out, err);
  case Encoding::Parquet:
  case Encoding::Arrow: {
    std::vector<std::string> cols = partial ? optTextList(part) : std::vector<std::string>{};
    if (partial && cols.empty()) {
      err = "a part of table '" + e.name + "' is a column name or a list of them, e.g. [\"time\", \"temp\"]";
      return false;
    }
    if (partial) {
      std::vector<std::string> have = optTextList(*field(e.meta, "cols"));
      for (const auto &c : cols)
        if (std::find(have.begin(), have.end(), c) == have.end()) {
          err = "table '" + e.name + "' has no column '" + c + "'";
          return false;
        }
    }
    return decodeTable(bytes, e.encoding, cols, e.meta, out, err);
  }
  }
  err = "unknown encoding";
  return false;
}

std::string entryNames(const BundleReader &r) {
  std::string s;
  for (const auto &e : r.entries())
    s += (s.empty() ? "" : ", ") + e.name;
  return s.empty() ? "(none)" : s;
}

// The whole file as one value: the value itself, or a dict of its entries.
bool readWhole(BundleReader &r, Value &out, std::string &err) {
  if (r.root() == Root::Value && r.entries().size() == 1)
    return decodeEntry(r, r.entries()[0], Value(""), out, err);
  Fields f;
  for (const auto &e : r.entries()) {
    Value v;
    if (!decodeEntry(r, e, Value(""), v, err))
      return false;
    f[e.name] = std::move(v);
  }
  out = Value(f);
  return true;
}

// Version 1 files (save_workspace): the variables.
bool readV1(const std::filesystem::path &p, NamedEntries &out, std::string &err) {
  ncdata::NamedValues nv;
  if (!ncdata::readNdatFile(p, nv, err))
    return false;
  out.assign(nv.begin(), nv.end());
  return true;
}

std::string isoTime(uint64_t ms) {
  std::time_t s = static_cast<std::time_t>(ms / 1000);
  std::tm tm{};
#ifdef _WIN32
  gmtime_s(&tm, &s);
#else
  gmtime_r(&s, &tm);
#endif
  char buf[32];
  std::strftime(buf, sizeof buf, "%Y-%m-%d %H:%M:%S UTC", &tm);
  return buf;
}

bool checkFile(const std::filesystem::path &p, CallContext &ctx, int &major) {
  std::error_code ec;
  if (!std::filesystem::is_regular_file(p, ec)) {
    ctx.fail("no such file: " + p.u8string());
    return false;
  }
  major = ncdata::bundle::ndatMajorVersion(p);
  if (major != 1 && major != 2) {
    ctx.fail(p.u8string() + " is not an .ndat file");
    return false;
  }
  return true;
}

/* ================= the NC functions ================= */

Value saveNdat(const std::vector<Value> &a, size_t policyArg, CallContext &ctx) {
  std::string file;
  if (!a[0].isText || (file = a[0].text()).empty()) {
    ctx.fail("the file name must be text, e.g. save(\"results.ndat\", data)");
    return Value(0.0);
  }
  const std::string policy = a.size() > policyArg && a[policyArg].isText ? a[policyArg].text() : "auto";
  if (a.size() > policyArg && !a[policyArg].isText) {
    ctx.fail("the policy must be text: \"auto\", \"compact\", \"fast\", \"native\", \"hdf5\", "
             "\"parquet\" or \"arrow\"");
    return Value(0.0);
  }
  // A dict becomes one entry per key - unless the policy stores it as ONE
  // table (a dict of columns big enough); anything else is one entry "data".
  Policy pol;
  std::string perr;
  if (!policyOf(policy, pol, perr)) {
    ctx.fail(perr);
    return Value(0.0);
  }
  NamedEntries entries;
  Root root = Root::Value;
  Table t;
  Value meta;
  bool numeric;
  const Value &data = a[1];
  const bool oneTable = pol.tableMin > 0 && tableOf(data, t, meta, numeric) &&
                        t.rows.size() * t.cols.size() >= pol.tableMin;
  if (data.isDict && !data.dict().empty() && !oneTable) {
    root = Root::Dict;
    std::vector<std::string> keys;
    for (const auto &kv : data.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys)
      entries.push_back({k, data.dict().at(k)});
  } else {
    entries.push_back({"data", data});
  }
  double bytes = 0;
  std::string err;
  if (!saveNdatEntries(file, root, entries, policy, bytes, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  return Value(bytes);
}

Value readNdat(const std::vector<Value> &a, CallContext &ctx) {
  const auto p = ndatPath(a[0].text());
  int major;
  if (!checkFile(p, ctx, major))
    return Value(0.0);
  const Value name = a.size() > 1 ? a[1] : Value("");
  const Value part = a.size() > 2 ? a[2] : Value("");
  if (given(name) && !name.isText) {
    ctx.fail("the entry name must be text, e.g. read(\"run.ndat\", \"A\")");
    return Value(0.0);
  }
  std::string err;
  if (major == 1) {
    NamedEntries vars;
    if (!readV1(p, vars, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (given(part)) {
      ctx.fail("a version 1 file (save_workspace) is read whole - parts can be read from files "
               "written by save");
      return Value(0.0);
    }
    Fields f;
    for (auto &nv : vars) {
      if (given(name) && nv.first == name.text())
        return nv.second;
      f[nv.first] = nv.second;
    }
    if (given(name)) {
      std::string names;
      for (auto &nv : vars)
        names += (names.empty() ? "" : ", ") + nv.first;
      ctx.fail("no entry '" + name.text() + "' in " + p.u8string() + " - it holds " + names);
      return Value(0.0);
    }
    return Value(f);
  }
  BundleReader r;
  if (!r.open(p, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Value out;
  if (!given(name)) {
    if (!readWhole(r, out, err))
      ctx.fail(err);
    return out;
  }
  const EntryInfo *e = r.find(name.text());
  // read(file, "temp") of a file holding one table: that column.
  if (!e && r.root() == Root::Value && r.entries().size() == 1 &&
      r.entries()[0].encoding != Encoding::Native && r.entries()[0].encoding != Encoding::Hdf5) {
    const EntryInfo &t = r.entries()[0];
    std::vector<std::string> cols = optTextList(*field(t.meta, "cols"));
    if (std::find(cols.begin(), cols.end(), name.text()) != cols.end()) {
      Value tbl;
      if (!decodeEntry(r, t, name, tbl, err)) {
        ctx.fail(err);
        return Value(0.0);
      }
      const Value *c = tbl.isDict ? &tbl.dict().at(name.text()) : field(tbl, fieldName(name.text()));
      return c ? *c : tbl;
    }
  }
  // read(file, "x") of a file holding one dict / object: its key or field x.
  if (!e && r.root() == Root::Value && r.entries().size() == 1 && !given(part)) {
    Value whole;
    if (!decodeEntry(r, r.entries()[0], Value(""), whole, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (whole.isDict || whole.isObject) {
      auto it = whole.dict().find(name.text());
      if (it != whole.dict().end())
        return it->second;
    }
  }
  if (!e) {
    ctx.fail("no entry '" + name.text() + "' in " + p.u8string() + " - it holds " + entryNames(r));
    return Value(0.0);
  }
  if (!decodeEntry(r, *e, part, out, err))
    ctx.fail(err);
  return out;
}

Value infoOf(const std::filesystem::path &p, CallContext &ctx) {
  int major;
  if (!checkFile(p, ctx, major))
    return Value(0.0);
  std::error_code ec;
  Fields f;
  f["file"] = Value(p.u8string());
  f["bytes"] = Value(static_cast<double>(std::filesystem::file_size(p, ec)));
  Table t;
  t.cols = {"name", "encoding", "kind", "shape", "bytes", "note"};
  std::string err;
  if (major == 1) {
    NamedEntries vars;
    if (!readV1(p, vars, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    f["version"] = Value("1");
    f["root"] = Value("workspace");
    for (auto &nv : vars)
      t.rows.push_back({Value(nv.first), Value("native"), Value("value"), Value(""),
                        Value(static_cast<double>(nativeBytes(nv.second).size())), Value("")});
  } else {
    BundleReader r;
    if (!r.open(p, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    f["version"] = Value("2." + std::to_string(r.minor()));
    f["root"] = Value(ncdata::bundle::rootName(r.root()));
    f["created"] = Value(isoTime(r.createdUnixMs()));
    for (const auto &e : r.entries()) {
      const Value *kind = field(e.meta, "kind"), *note = field(e.meta, "note");
      std::string shape;
      if (const Value *s = field(e.meta, "shape")) {
        for (double d : optNumbers(*s))
          shape += (shape.empty() ? "" : "x") + numberText(d);
      } else if (const Value *rows = field(e.meta, "rows")) {
        shape = numberText(rows->number) + " rows x " +
                std::to_string(optTextList(*field(e.meta, "cols")).size()) + " cols";
      }
      t.rows.push_back({Value(e.name), Value(ncdata::bundle::encodingName(e.encoding)),
                        Value(kind && kind->isText ? kind->text() : "value"), Value(shape),
                        Value(static_cast<double>(e.length)),
                        Value(note && note->isText ? note->text() : "")});
    }
  }
  f["entries"] = tableObject(t);
  return Value(f);
}

// save / load / read are for .ndat only; any other format has its own
// function (save_csv, read_h5, load_parquet, ...), named in the error.
bool ndatOnly(const std::string &op, const std::vector<Value> &a, CallContext &ctx) {
  if (isNdatPath(a[0].text()))
    return true;
  const std::string ext = extensionOf(a[0].text()), fn = op + "_" + formatOf(a[0].text());
  ctx.fail(op + " is for NC data files (.ndat) - " +
           (hasIoFunction(fn) ? "for a ." + ext + " file use " + fn + "(...)"
                              : "give a name without an extension or ending in .ndat"));
  return false;
}

bool fileArg(const std::vector<Value> &a, CallContext &ctx, const char *example) {
  if (a.empty() || !a[0].isText || a[0].text().empty()) {
    ctx.fail(std::string("the file name must be text in quotes, e.g. ") + example);
    return false;
  }
  return true;
}

// Like addFn, with a parameter line (named values work) and complex data allowed.
void addNamed(Registry &reg, const std::string &name, const std::string &params,
              const std::string &summary, numpy::Impl impl) {
  std::vector<ncargs::ParamSpec> specs;
  std::string err;
  if (!ncargs::parseParamList(params, specs, err)) {
    std::cerr << "Error: importing_data: bad parameter line for " << name << ": " << err << "\n";
    return;
  }
  numpy::FunctionSpec s;
  s.name = name;
  s.section = numpy::Section::ImportingData;
  s.minArgs = 0;
  for (const auto &p : specs)
    if (p.kind == ncargs::ParamKind::Required)
      s.minArgs++;
  s.maxArgs = static_cast<int>(specs.size());
  s.signature = name + "(" + params + ")";
  s.summary = summary;
  s.impl = std::move(impl);
  s.acceptsComplex = true;
  if (reg.add(std::move(s)))
    reg.setParams(name, params);
}

} // namespace

bool isNdatPath(const std::string &userPath) {
  const std::string e = extensionOf(userPath);
  return e.empty() || e == "ndat";
}

bool saveNdatEntries(const std::string &userPath, Root root, const NamedEntries &entries,
                     const std::string &policyName, double &bytes, std::string &err,
                     std::filesystem::path *written) {
  Policy p;
  if (!policyOf(policyName, p, err))
    return false;
  const auto path = ndatPath(userPath);
  std::vector<Section> sections;
  planEntries(entries, p, sections);
  if (!ncdata::bundle::writeBundle(path, root, sections, err))
    return false;
  std::error_code ec;
  bytes = static_cast<double>(std::filesystem::file_size(path, ec));
  if (written)
    *written = path;
  return true;
}

bool readNdatEntries(const std::filesystem::path &path, NamedEntries &out, std::string &err) {
  BundleReader r;
  if (!r.open(path, err))
    return false;
  out.clear();
  for (const auto &e : r.entries()) {
    Value v;
    if (!decodeEntry(r, e, Value(""), v, err))
      return false;
    out.push_back({e.name, std::move(v)});
  }
  return true;
}

void registerNdat(Registry &reg) {
  // ---- NC data files (.ndat). Other formats have their own functions. ----
  addNamed(reg, "save", "file, data, policy=\"auto\"",
           "save data in an NC data file (.ndat): each entry stored the best way (HDF5, Parquet, Arrow or native)",
           [](const std::vector<Value> &a, CallContext &ctx) -> Value {
             if (!fileArg(a, ctx, "save(\"results\", data)") || !ndatOnly("save", a, ctx))
               return Value(0.0);
             return saveNdat(a, 2, ctx);
           });
  addNamed(reg, "read", "file, name=\"\", part=\"\"",
           "read an NC data file (.ndat): all of it, one entry (name), or part of one (a slice or columns)",
           [](const std::vector<Value> &a, CallContext &ctx) -> Value {
             if (!fileArg(a, ctx, "read(\"results\")") || !ndatOnly("read", a, ctx))
               return Value(0.0);
             return readNdat(a, ctx);
           });
  addNamed(reg, "load", "file",
           "open an NC data file (.ndat) as an object: its entries as fields (D.A), plus D.ndat",
           [](const std::vector<Value> &a, CallContext &ctx) -> Value {
             if (!fileArg(a, ctx, "D = load(\"results\")") || !ndatOnly("load", a, ctx))
               return Value(0.0);
             const auto p = ndatPath(a[0].text());
             int major;
             if (!checkFile(p, ctx, major))
               return Value(0.0);
             std::string err;
             NamedEntries entries;
             if (!(major == 1 ? readV1(p, entries, err) : readNdatEntries(p, entries, err))) {
               ctx.fail(err);
               return Value(0.0);
             }
             Fields f;
             for (auto &e : entries)
               f[e.first] = std::move(e.second);
             if (!f.count("ndat"))
               f["ndat"] = infoOf(p, ctx);
             return makeObject("NcData", std::move(f));
           });
  addNamed(reg, "ndat_info", "file",
        "what an .ndat file holds: version, root, and per entry its encoding, kind, shape and bytes",
        [](const std::vector<Value> &a, CallContext &ctx) -> Value {
          if (!fileArg(a, ctx, "ndat_info(\"results\")"))
            return Value(0.0);
          return infoOf(ndatPath(a[0].text()), ctx);
        });
  addNamed(reg, "ndat_export", "file, name, out",
        "write one entry of an .ndat file as its own file (hdf5 / parquet / arrow sections are copied unchanged)",
        [](const std::vector<Value> &a, CallContext &ctx) -> Value {
          if (!fileArg(a, ctx, "ndat_export(\"run\", \"A\", \"A.h5\")"))
            return Value(0.0);
          if (!a[1].isText || !a[2].isText || a[2].text().empty()) {
            ctx.fail("the entry name and the output file must be text, e.g. ndat_export(\"run\", \"A\", \"A.h5\")");
            return Value(0.0);
          }
          const auto p = ndatPath(a[0].text());
          int major;
          if (!checkFile(p, ctx, major))
            return Value(0.0);
          const std::string outFile = a[2].text();
          const std::string fmt = formatOf(outFile);
          std::string err;
          if (major == 2) {
            BundleReader r;
            if (!r.open(p, err)) {
              ctx.fail(err);
              return Value(0.0);
            }
            const EntryInfo *e = r.find(a[1].text());
            if (!e) {
              ctx.fail("no entry '" + a[1].text() + "' in " + p.u8string() + " - it holds " + entryNames(r));
              return Value(0.0);
            }
            const bool same = (e->encoding == Encoding::Hdf5 && (fmt == "h5" || fmt == "hdf" || fmt == "he5")) ||
                              (e->encoding == Encoding::Parquet && fmt == "parquet") ||
                              (e->encoding == Encoding::Arrow && fmt == "feather");
            if (same) { // the section is already that file
              std::string bytes;
              if (!r.section(*e, bytes, err) || !writeFile(outFile, bytes, false, err)) {
                ctx.fail(err);
                return Value(0.0);
              }
              return Value(resolvePath(outFile).u8string());
            }
          }
          // anything else: decode the entry and write it with that format's save_<ext>
          const std::string fn = "save_" + fmt;
          if (fmt == "ndat" || fmt.empty() || !hasIoFunction(fn)) {
            ctx.fail("cannot write a ." + extensionOf(outFile) + " file - give the extension of a format "
                     "with a save_ function (h5, parquet, arrow, csv, json, mat, ...)");
            return Value(0.0);
          }
          const Value v = readNdat({a[0], a[1]}, ctx);
          if (!ctx.ok())
            return Value(0.0);
          Value out;
          bool ok = true;
          numpy::tryCall(fn, {a[2], v}, out, ok);
          if (!ok) {
            ctx.markFailed();
            return Value(0.0);
          }
          return Value(resolvePath(outFile).u8string());
        });
}

} // namespace io
} // namespace nc
