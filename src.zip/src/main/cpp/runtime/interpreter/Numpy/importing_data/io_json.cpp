// CATEGORY 6 - JSON: read_json / load_json / save_json (RFC 8259, JSON5
// comments and trailing commas, NDJSON with lines=true).
#include <algorithm>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_tree.h"

namespace nc {
namespace io {
namespace {

bool readTree(const std::string &file, bool lines, bool lenient, TreeNode &root, std::string &err) {
  std::string raw, text;
  if (!readSource(file, raw, err) || !autoDecompress(raw, err) || !decodeText(raw, "utf-8", text, err))
    return false;
  return lines ? parseJsonLines(text, lenient, root, err) : parseJson(text, lenient, root, err);
}

// ---- read_json(file, path=...) on a big file (2026-11-14) -------------------
//
// A path that starts with plain steps ($.store.book[3] ...) is followed
// through the memory-mapped text without building any tree: values that
// are not on the way are skipped character by character, and only the
// subtree it leads to is parsed; the rest of the path (wildcards, filters,
// ..) then runs on that subtree. The result is the one the whole-file
// parse gives. Anything this scanner does not handle exactly as the parser
// (comments, 'single quotes', bare keys, keys with escapes, trailing
// commas, a step that is not found) returns false and the caller parses
// the whole file - which then also gives the usual errors.
struct JsonStep {
  bool index = false;
  std::string key;
  size_t n = 0;
};

// The plain-step prefix of `path` and the rest ("" when the whole path is plain).
bool plainJsonPrefix(const std::string &pathIn, std::vector<JsonStep> &steps, std::string &rest) {
  std::string path = trim(pathIn);
  size_t i = 0;
  if (!path.empty() && path[0] == '$')
    i = 1;
  else if (!path.empty() && path[0] != '.' && path[0] != '[')
    path = "." + path;
  steps.clear();
  while (i < path.size()) {
    if (path.compare(i, 2, "..") == 0)
      break;
    if (path[i] == '.') {
      size_t e = i + 1;
      while (e < path.size() && path[e] != '.' && path[e] != '[')
        e++;
      const std::string key = path.substr(i + 1, e - i - 1);
      if (key.empty() || key == "*")
        break;
      steps.push_back({false, key, 0});
      i = e;
    } else if (path[i] == '[') {
      const size_t e = path.find(']', i);
      if (e == std::string::npos)
        break;
      const std::string in = trim(path.substr(i + 1, e - i - 1));
      if (!in.empty() && std::all_of(in.begin(), in.end(), [](char c) { return c >= '0' && c <= '9'; }) && in.size() < 18) {
        steps.push_back({true, "", static_cast<size_t>(std::stoull(in))});
      } else if (in.size() >= 2 && (in[0] == '\'' || in[0] == '"') && in.back() == in[0] &&
                 in.find_first_of("'\",", 1) == in.size() - 1) {
        steps.push_back({false, in.substr(1, in.size() - 2), 0});
      } else {
        break;
      }
      i = e + 1;
    } else {
      break;
    }
  }
  rest = i < path.size() ? path.substr(i) : std::string();
  return !steps.empty();
}

struct JsonScan {
  std::string_view s;
  size_t i = 0;
  int deepest = 0; // the deepest nesting skip() has gone through
  bool ws() { // false on a comment: not for this scanner
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r'))
      i++;
    return !(i + 1 < s.size() && s[i] == '/' && (s[i + 1] == '/' || s[i + 1] == '*'));
  }
  bool str(std::string *out) { // at '"'; escapes not allowed when out != nullptr
    if (i >= s.size() || s[i] != '"')
      return false;
    const size_t b = ++i;
    while (i < s.size() && s[i] != '"') {
      if (s[i] == '\\') {
        if (out)
          return false;
        i++;
      }
      i++;
    }
    if (i >= s.size())
      return false;
    if (out)
      *out = std::string(s.substr(b, i - b));
    i++;
    return true;
  }
  bool skip() { // one value
    if (!ws() || i >= s.size())
      return false;
    const char c = s[i];
    if (c == '"')
      return str(nullptr);
    if (c == '\'')
      return false;
    if (c == '{' || c == '[') {
      int depth = 0;
      while (i < s.size()) {
        const char d = s[i];
        if (d == '"') {
          if (!str(nullptr))
            return false;
          continue;
        }
        if (d == '\'' || (d == '/' && i + 1 < s.size() && (s[i + 1] == '/' || s[i + 1] == '*')))
          return false;
        if (d == '{' || d == '[')
          deepest = std::max(deepest, ++depth);
        else if (d == '}' || d == ']') {
          if (--depth == 0) {
            i++;
            return true;
          }
        }
        i++;
      }
      return false;
    }
    while (i < s.size() && s[i] != ',' && s[i] != '}' && s[i] != ']' && s[i] != ' ' && s[i] != '\n' &&
           s[i] != '\r' && s[i] != '\t')
      i++;
    return true;
  }
  // Moves to the value of `step` inside the value at i.
  bool enter(const JsonStep &step) {
    if (!ws() || i >= s.size())
      return false;
    if (!step.index) {
      if (s[i] != '{')
        return false;
      i++;
      for (;;) {
        if (!ws() || i >= s.size() || s[i] != '"')
          return false; // also '}' (not found) and bare / single-quoted keys
        std::string key;
        if (!str(&key) || !ws() || i >= s.size() || s[i] != ':')
          return false;
        i++;
        if (key == step.key)
          return ws();
        if (!skip() || !ws() || i >= s.size() || s[i] != ',')
          return false;
        i++;
      }
    }
    if (s[i] != '[')
      return false;
    i++;
    for (size_t k = 0;; k++) {
      if (!ws() || i >= s.size() || s[i] == ']')
        return false;
      if (k == step.n)
        return true;
      if (!skip() || !ws() || i >= s.size() || s[i] != ',')
        return false;
      i++;
    }
  }
};

// The JSONPath hits of `path` in `file` without parsing the whole file;
// false = not possible here (the caller parses the whole file).
bool fastJsonPath(const std::string &file, const std::string &path, bool lenient, TreeNode &payload, std::string &err) {
  std::vector<JsonStep> steps;
  std::string rest;
  if (isUrl(file) || !plainJsonPrefix(path, steps, rest))
    return false;
  SourceBytes src;
  std::string e2;
  if (!src.open(file, e2))
    return false;
  JsonScan sc;
  sc.s = src.view();
  if (sc.s.size() >= 2 && static_cast<unsigned char>(sc.s[0]) == 0x1F && static_cast<unsigned char>(sc.s[1]) == 0x8B)
    return false; // gzip
  if (sc.s.size() >= 3 && sc.s.compare(0, 3, "\xEF\xBB\xBF") == 0)
    sc.i = 3;
  for (const auto &st : steps)
    if (!sc.enter(st))
      return false;
  const size_t b = sc.i;
  if (!sc.skip())
    return false;
  TreeNode sub;
  if (!parseJson(std::string(sc.s.substr(b, sc.i - b)), lenient, sub, e2))
    return false;
  if (rest.empty()) {
    payload = std::move(sub);
    return true;
  }
  std::vector<const TreeNode *> hits;
  bool single = true;
  if (!jsonPath(sub, "$" + rest, hits, single, e2) || hits.empty())
    return false; // the whole-file path reports it
  if (single && hits.size() == 1) {
    payload = *hits[0];
  } else {
    payload = TreeNode();
    payload.type = TreeNode::Array;
    for (auto *h : hits)
      payload.items.push_back(*h);
  }
  (void)err;
  return true;
}

// read_json of a file that is one list of records ([{...}, {...}, ...]) as a
// table (2026-11-15): the records are found by the scanner above and parsed
// one at a time, straight into the table's columns - the file is never one
// tree (a tree takes ~40x the text). The table is the one treeToTable()
// makes of the whole-file parse: columns in first-seen order, a key missing
// from a record NaN. False when this is not such a file or the scanner
// cannot follow it (comments, single quotes, an empty list, a record nested
// 500 deep ...): the caller then parses the whole file as before.
bool streamJsonRecords(const std::string &file, bool lenient, Table &t, bool &cancelled) {
  cancelled = false;
  if (isUrl(file))
    return false;
  SourceBytes src;
  std::string e2;
  if (!src.open(file, e2))
    return false;
  JsonScan sc;
  sc.s = src.view();
  if (sc.s.size() >= 2 && static_cast<unsigned char>(sc.s[0]) == 0x1F && static_cast<unsigned char>(sc.s[1]) == 0x8B)
    return false; // gzip
  if (sc.s.size() >= 3 && sc.s.compare(0, 3, "\xEF\xBB\xBF") == 0)
    sc.i = 3;
  if (!sc.ws() || sc.i >= sc.s.size() || sc.s[sc.i] != '[')
    return false;
  sc.i++;
  std::vector<std::string> cols;
  std::unordered_map<std::string, size_t> where;
  std::vector<Value::ColumnBuilder> b;
  size_t n = 0;
  size_t nextReport = 1 << 20;
  for (;;) {
    if (!sc.ws() || sc.i >= sc.s.size() || sc.s[sc.i] != '{')
      return false; // not a record (or an empty list, a trailing comma ...)
    const size_t start = sc.i;
    sc.deepest = 0;
    if (!sc.skip() || sc.deepest >= 500)
      return false;
    TreeNode rec;
    if (!parseJson(std::string(sc.s.substr(start, sc.i - start)), lenient, rec, e2) || rec.type != TreeNode::Object)
      return false; // the whole-file parse gives the error
    for (const auto &kv : rec.keys)
      if (where.emplace(kv.first, cols.size()).second) { // a column first seen here: NaN above
        cols.push_back(kv.first);
        b.emplace_back();
        for (size_t r = 0; r < n; r++)
          b.back().pushNumber(missingNumber());
      }
    for (size_t c = 0; c < cols.size(); c++)
      b[c].push(treeCellValue(rec.find(cols[c])));
    n++;
    if (sc.i > nextReport) {
      if (reportProgress("read_json", file, static_cast<double>(sc.i) / static_cast<double>(sc.s.size())) || cancelRequested()) {
        cancelled = true;
        return false;
      }
      nextReport += 1 << 20;
    }
    if (!sc.ws() || sc.i >= sc.s.size())
      return false;
    if (sc.s[sc.i] == ',') {
      sc.i++;
      continue;
    }
    if (sc.s[sc.i] != ']')
      return false;
    sc.i++;
    break;
  }
  if (!sc.ws() || sc.i != sc.s.size())
    return false; // text after the list: the parser's error
  std::vector<std::shared_ptr<Value::Column>> out;
  for (auto &cb : b)
    out.push_back(cb.finish());
  t = Table();
  t.cols = std::move(cols);
  tableFromColumns(t, std::move(out), n);
  normalizeTable(t);
  return true;
}

// Top-level "_meta", "_comment", "_info" ... keys: info boxes beside the data.
TreeNode splitBoxes(TreeNode &root) {
  TreeNode boxes;
  boxes.type = TreeNode::Object;
  if (root.type != TreeNode::Object)
    return boxes;
  std::vector<std::pair<std::string, TreeNode>> keep;
  for (auto &kv : root.keys)
    (kv.first.rfind('_', 0) == 0 ? boxes.keys : keep).push_back(std::move(kv));
  root.keys = std::move(keep);
  // {"_meta": ..., "records": [...]} -> the payload is the records.
  if (!boxes.keys.empty() && root.keys.size() == 1 && root.keys[0].second.type == TreeNode::Array) {
    TreeNode only = std::move(root.keys[0].second);
    root = std::move(only);
  }
  return boxes;
}

bool isRecordList(const TreeNode &n) {
  if (n.type != TreeNode::Array || n.items.empty())
    return false;
  for (const auto &c : n.items)
    if (c.type != TreeNode::Object)
      return false;
  return true;
}

// read_json(file, path, lines, as_table, box, allow_cmt)
void readJson(const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev("read_json", file);
  const std::string path = optText(a[1], "");
  const bool lines = optBool(a[2], false), asTable = optBool(a[3], true), box = optBool(a[4], true);
  // A file that is one list of records, read as a table: record by record
  // into columns (streamJsonRecords), never as one tree.
  if (path.empty() && !lines && asTable) {
    Table t;
    bool cancelled = false;
    if (streamJsonRecords(file, optBool(a[5], true), t, cancelled)) {
      out.push_back(tableData(t));
      if (nout > 1) {
        Fields info;
        info["cols"] = textList(t.cols);
        TreeNode noBoxes; // a list has no "_" keys beside it
        noBoxes.type = TreeNode::Object;
        info["boxes"] = treeToValue(noBoxes);
        info["path"] = Value(path);
        info["type"] = Value(std::string("array"));
        out.push_back(makeObject("NcReadInfo", std::move(info)));
      }
      ev.ok = true;
      return;
    }
    if (cancelled)
      return ctx.fail("cancelled");
  }
  TreeNode root;
  TreeNode payload;
  const bool fast = !path.empty() && !lines && fastJsonPath(file, path, optBool(a[5], true), payload, err);
  if (!fast && !readTree(file, lines, optBool(a[5], true), root, err))
    return ctx.fail(err);
  TreeNode boxes;
  boxes.type = TreeNode::Object;
  if (box && path.empty())
    boxes = splitBoxes(root);
  if (fast) {
    // payload holds the path's value already
  } else if (!path.empty()) {
    std::vector<const TreeNode *> hits;
    bool single = true;
    if (!jsonPath(root, path, hits, single, err))
      return ctx.fail(err);
    if (hits.empty())
      return ctx.fail("JSONPath " + path + " matched nothing");
    if (single && hits.size() == 1) {
      payload = *hits[0];
    } else {
      payload.type = TreeNode::Array;
      for (auto *h : hits)
        payload.items.push_back(*h);
    }
  } else {
    payload = std::move(root);
  }
  std::vector<std::string> cols;
  if (asTable && isRecordList(payload)) {
    Table t;
    if (!treeToTable(payload, t, err))
      return ctx.fail(err);
    cols = t.cols;
    out.push_back(tableData(t));
  } else {
    out.push_back(treeToValue(payload));
  }
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(cols);
    info["boxes"] = treeToValue(boxes);
    info["path"] = Value(path);
    static const char *names[] = {"null", "bool", "number", "string", "array", "object"};
    info["type"] = Value(std::string(names[payload.type]));
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

// load_json(file, lines, allow_cmt)
Value loadJson(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev("load_json", file);
  TreeNode root;
  if (!readTree(file, optBool(a[1], false), optBool(a[2], true), root, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  std::vector<std::string> order;
  TreeNode boxes;
  boxes.type = TreeNode::Object;
  if (root.type == TreeNode::Object) {
    for (const auto &kv : root.keys) {
      order.push_back(kv.first);
      if (kv.first.rfind('_', 0) == 0)
        boxes.keys.push_back(kv);
      std::string n = fieldName(kv.first);
      f[n.empty() ? "_" : n] = treeToObject(kv.second, "NcJsonNode");
    }
  }
  f["default"] = treeToValue(root);
  f["key_order"] = textList(order);
  f["boxes"] = treeToValue(boxes);
  f["file"] = Value(file);
  if (root.type == TreeNode::Array)
    f["items"] = treeToObject(root, "NcJsonNode");
  ev.ok = true;
  return makeObject("NcJson", std::move(f));
}

// The tree behind a loaded object (or any value) for the methods below.
TreeNode treeOf(const Value &v) {
  if (isObjectOf(v, "NcJson")) {
    // The ordered NcJsonNode fields keep the file's key order at every
    // level (the plain `default` dict does not).
    if (const Value *items = field(v, "items"))
      return valueToTree(*items);
    const Value *order = field(v, "key_order");
    if (order && given(*order))
      return valueToTree(v); // key_order lists exactly the root keys
    const Value *def = field(v, "default");
    return def ? valueToTree(*def) : TreeNode();
  }
  return valueToTree(v);
}

Value keysMethod(const std::vector<Value> &a, CallContext &) {
  TreeNode n = treeOf(a[0]);
  std::vector<std::string> keys;
  for (const auto &kv : n.keys)
    keys.push_back(kv.first);
  return textList(keys);
}

Value valuesMethod(const std::vector<Value> &a, CallContext &) {
  TreeNode n = treeOf(a[0]);
  std::vector<Value> vals;
  for (const auto &kv : n.keys)
    vals.push_back(treeToObject(kv.second, "NcJsonNode"));
  return Value(std::move(vals));
}

Value queryMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string path, err;
  if (!numpy::argText(a, 1, ctx, path))
    return Value(0.0);
  TreeNode n = treeOf(a[0]);
  std::vector<const TreeNode *> hits;
  bool single = true;
  if (!jsonPath(n, path, hits, single, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (single && hits.size() == 1)
    return treeToObject(*hits[0], "NcJsonNode");
  std::vector<Value> cells;
  for (auto *h : hits)
    cells.push_back(treeToObject(*h, "NcJsonNode"));
  return Value(std::move(cells));
}

Value toTableMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string err;
  TreeNode n = treeOf(a[0]);
  const TreeNode *node = &n;
  std::vector<const TreeNode *> hits;
  TreeNode gathered;
  const std::string path = optText(a[1], "");
  if (!path.empty()) {
    bool single = true;
    if (!jsonPath(n, path, hits, single, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (hits.size() == 1 && hits[0]->type == TreeNode::Array) {
      node = hits[0];
    } else {
      gathered.type = TreeNode::Array;
      for (auto *h : hits)
        gathered.items.push_back(*h);
      node = &gathered;
    }
  }
  Table t;
  if (!treeToTable(*node, t, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  return tableObject(t);
}

Value getMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string key;
  if (!numpy::argText(a, 1, ctx, key))
    return Value(0.0);
  TreeNode n = treeOf(a[0]);
  if (const TreeNode *c = n.find(key))
    return treeToObject(*c, "NcJsonNode");
  if (const Value *f = field(a[0], key))
    return *f;
  ctx.fail("no key '" + key + "'");
  return Value(0.0);
}

// save_json(file, data, indent, minify, sort_keys, lines, nan_mode, boxes,
//           compress, level, max_size)
Value saveJson(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev("save_json", file);
  JsonStyle st;
  st.indent = static_cast<int>(optInt(a[2], 2));
  if (optBool(a[3], false))
    st.indent = 0;
  st.sortKeys = optBool(a[4], false);
  st.nanMode = lower(optText(a[6], "null"));
  if (st.nanMode != "null" && st.nanMode != "str") {
    ctx.fail("nan_mode must be \"null\" or \"str\"");
    return Value(0.0);
  }
  TreeNode root = isObjectOf(a[1], "NcJson") ? treeOf(a[1]) : valueToTree(a[1]);
  if (given(a[7])) {
    TreeNode boxes = a[7].isText ? TreeNode() : valueToTree(a[7]);
    if (a[7].isText) {
      boxes.type = TreeNode::Object;
      boxes.keys.emplace_back("_info", TreeNode::ofString(a[7].text()));
    }
    if (boxes.type != TreeNode::Object) {
      ctx.fail("boxes must be a dict (or a text, saved as \"_info\")");
      return Value(0.0);
    }
    if (root.type != TreeNode::Object) {
      TreeNode wrap;
      wrap.type = TreeNode::Object;
      wrap.keys = boxes.keys;
      wrap.keys.emplace_back("data", std::move(root));
      root = std::move(wrap);
    } else {
      auto keys = boxes.keys;
      for (auto &kv : root.keys)
        keys.push_back(std::move(kv));
      root.keys = std::move(keys);
    }
  }
  std::string text;
  if (optBool(a[5], false)) {
    JsonStyle line = st;
    line.indent = 0;
    if (root.type == TreeNode::Array)
      for (const auto &item : root.items)
        text += writeJson(item, line) + "\n";
    else
      text = writeJson(root, line) + "\n";
  } else {
    text = writeJson(root, st) + "\n";
  }
  if (!applyCompression(optText(a[8], "none"), static_cast<int>(optInt(a[9], -1)), text, err) ||
      !checkMaxSize(a[10], text.size(), err) || !writeFile(file, text, false, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  emitEvent({"saved", "save_json", file, 1.0, formatBytes(text.size())});
  ev.ok = true;
  return Value(static_cast<double>(text.size()));
}

} // namespace

void registerJson(Registry &reg) {
  addMulti(reg, "read_json",
           "file, path=\"\", lines=false, as_table=true, box=true, allow_cmt=true",
           "read a .json file (a JSONPath selects a branch; records become a table)",
           "pandas.read_json / json.load", 2, readJson);
  addFn(reg, "load_json", "file, lines=false, allow_cmt=true",
        "load a .json file as an object with dot access (D.sensor.calibration.gain)",
        "json.load", loadJson);
  addFn(reg, "save_json",
        "file, data, indent=2, minify=false, sort_keys=false, lines=false, nan_mode=\"null\", "
        "boxes=\"\", compress=\"none\", level=-1, max_size=\"\"",
        "write a value as JSON (tables become lists of records)", "json.dump", saveJson);
  for (const char *cls : {"NcJson", "NcJsonNode"}) {
    const std::string c = cls;
    addFn(reg, c + ".keys", "D", "keys of a loaded JSON object, in file order", "dict.keys", keysMethod);
    addFn(reg, c + ".values", "D", "values of a loaded JSON object, in file order", "dict.values",
          valuesMethod);
    addFn(reg, c + ".query", "D, path", "JSONPath query on a loaded JSON object", "jsonpath",
          queryMethod);
    addFn(reg, c + ".to_table", "D, path=\"\"", "a list of records (at a JSONPath) as a table",
          "pandas.json_normalize", toTableMethod);
    addFn(reg, c + ".get", "D, key", "the value of a key that is not a valid name (\"my-key\")",
          "dict.get", getMethod);
  }
}

} // namespace io
} // namespace nc
