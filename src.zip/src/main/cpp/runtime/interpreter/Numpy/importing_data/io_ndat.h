#pragma once
// NC's own data files (.ndat): save / load / read.
//
//   save(file, data, policy="auto")   load(file)   read(file, name="", part="")
//
// They take .ndat files only (a name without an extension means .ndat); every
// other format has its own functions (save_csv, read_h5, load_parquet, ...).
// A .ndat file is an NC data bundle (runtime/data/DataSupport/NdatBundle.h):
// every entry is stored in the encoding that suits it - native NDAT nodes,
// HDF5, Parquet or Arrow IPC - chosen by a storage policy, and checked to read
// back exactly before the file is written.

#include <filesystem>
#include <string>
#include <utility>
#include <vector>

#include "../../../data/DataSupport/NdatBundle.h"
#include "../../core/value.h"

namespace nc {
namespace numpy {
class Registry;
}
namespace io {

void registerNdat(numpy::Registry &reg); // save load read ndat_info ndat_export

using NamedEntries = std::vector<std::pair<std::string, Value>>;

// Writes a bundle with one entry per name (the parser's save(file) of the
// whole workspace uses Root::Workspace). `bytes` = size of the file written.
bool saveNdatEntries(const std::string &userPath, ncdata::bundle::Root root,
                     const NamedEntries &entries, const std::string &policy, double &bytes,
                     std::string &err, std::filesystem::path *written = nullptr);

// Every entry of a version-2 file, decoded (load_workspace of a bundle).
bool readNdatEntries(const std::filesystem::path &path, NamedEntries &out, std::string &err);

// True for a path that save/load/read treat as .ndat (".ndat" or no extension).
bool isNdatPath(const std::string &userPath);

} // namespace io
} // namespace nc
