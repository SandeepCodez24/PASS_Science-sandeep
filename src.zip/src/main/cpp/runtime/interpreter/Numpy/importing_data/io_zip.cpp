// ZIP read / write - see io_zip.h.
#include "io_zip.h"

#include <algorithm>

#include "io_bytes.h"
#include "io_deflate.h"

namespace nc {
namespace io {

bool ZipReader::open(std::string_view bytes, std::string &err) {
  data = bytes;
  entries.clear();
  // End of central directory: last 22..65557 bytes.
  if (bytes.size() < 22) {
    err = "not a zip archive (too short)";
    return false;
  }
  size_t eocd = std::string::npos;
  size_t lo = bytes.size() > 65557 ? bytes.size() - 65557 : 0;
  for (size_t p = bytes.size() - 22 + 1; p-- > lo;)
    if (u32le(bytes, p) == 0x06054b50) {
      eocd = p;
      break;
    }
  if (eocd == std::string::npos) {
    err = "not a zip archive (no central directory)";
    return false;
  }
  uint64_t count = u16le(bytes, eocd + 10);
  uint64_t cd = u32le(bytes, eocd + 16);
  // ZIP64: a locator just before the EOCD points at the ZIP64 end record,
  // which holds the 64-bit entry count and directory offset.
  if (eocd >= 20 && u32le(bytes, eocd - 20) == 0x07064b50) {
    const uint64_t rec = u64le(bytes, eocd - 20 + 8);
    if (rec + 56 <= bytes.size() && u32le(bytes, static_cast<size_t>(rec)) == 0x06064b50) {
      count = u64le(bytes, static_cast<size_t>(rec) + 32);
      cd = u64le(bytes, static_cast<size_t>(rec) + 48);
    }
  }
  if (count > bytes.size() / 46) {
    err = "damaged zip central directory";
    return false;
  }
  entries.reserve(static_cast<size_t>(count));
  for (uint64_t k = 0; k < count; k++) {
    if (cd + 46 > bytes.size() || u32le(bytes, static_cast<size_t>(cd)) != 0x02014b50) {
      err = "damaged zip central directory";
      return false;
    }
    const size_t c = static_cast<size_t>(cd);
    Entry e;
    e.method = u16le(bytes, c + 10);
    e.compSize = u32le(bytes, c + 20);
    e.size = u32le(bytes, c + 24);
    size_t nameLen = u16le(bytes, c + 28), extra = u16le(bytes, c + 30), comment = u16le(bytes, c + 32);
    e.localOffset = u32le(bytes, c + 42);
    if (c + 46 + nameLen + extra > bytes.size()) {
      err = "damaged zip central directory";
      return false;
    }
    e.name = std::string(bytes.substr(c + 46, nameLen));
    // ZIP64 extra field (id 1): the 64-bit values of the fields set to 0xFFFFFFFF, in this order
    for (size_t x = c + 46 + nameLen, xe = x + extra; x + 4 <= xe;) {
      const uint16_t id = u16le(bytes, x), len = u16le(bytes, x + 2);
      if (id == 0x0001) {
        size_t q = x + 4, qe = std::min(x + 4 + len, xe);
        if (e.size == 0xFFFFFFFFu && q + 8 <= qe) { e.size = u64le(bytes, q); q += 8; }
        if (e.compSize == 0xFFFFFFFFu && q + 8 <= qe) { e.compSize = u64le(bytes, q); q += 8; }
        if (e.localOffset == 0xFFFFFFFFu && q + 8 <= qe) { e.localOffset = u64le(bytes, q); q += 8; }
        break;
      }
      x += 4 + len;
    }
    entries.push_back(std::move(e));
    cd += 46 + nameLen + extra + comment;
  }
  return true;
}

const ZipReader::Entry *ZipReader::find(const std::string &name) const {
  for (const auto &e : entries)
    if (e.name == name)
      return &e;
  return nullptr;
}

bool ZipReader::has(const std::string &name) const { return find(name) != nullptr; }

bool ZipReader::read(const std::string &name, std::string &out, std::string &err) const {
  const Entry *e = find(name);
  if (!e) {
    err = "the archive has no entry " + name;
    return false;
  }
  const std::string_view b = data;
  const uint64_t p = e->localOffset;
  if (p + 30 > b.size() || u32le(b, static_cast<size_t>(p)) != 0x04034b50) {
    err = "damaged zip entry " + name;
    return false;
  }
  const uint64_t start = p + 30 + u16le(b, static_cast<size_t>(p) + 26) + u16le(b, static_cast<size_t>(p) + 28);
  if (start + e->compSize > b.size()) {
    err = "zip entry " + name + " runs past the end";
    return false;
  }
  const std::string_view body = b.substr(static_cast<size_t>(start), static_cast<size_t>(e->compSize));
  if (e->method == 0) {
    out.assign(body.data(), body.size());
    return true;
  }
  if (e->method == 8) {
    if (e->size > 0 && e->size < (uint64_t(1) << 40))
      out.reserve(static_cast<size_t>(e->size));
    return inflateRaw(body, 0, out, err);
  }
  err = "zip entry " + name + " uses compression method " + std::to_string(e->method) + " (only stored/deflate are built in)";
  return false;
}

std::string ZipWriter::finish(int level) const {
  std::string out, central;
  for (const auto &f : files) {
    std::string comp = deflateRaw(f.second, level);
    bool store = comp.size() >= f.second.size();
    const std::string &body = store ? f.second : comp;
    uint32_t crc = crc32(f.second.data(), f.second.size());
    size_t offset = out.size();
    putLE(out, 0x04034b50, 4);
    putLE(out, 20, 2);
    putLE(out, 0x0800, 2); // UTF-8 names
    putLE(out, store ? 0 : 8, 2);
    putLE(out, 0, 2);
    putLE(out, 0x5A21, 2); // 2025-01-01
    putLE(out, crc, 4);
    putLE(out, body.size(), 4);
    putLE(out, f.second.size(), 4);
    putLE(out, f.first.size(), 2);
    putLE(out, 0, 2);
    out += f.first + body;
    putLE(central, 0x02014b50, 4);
    putLE(central, 20, 2);
    putLE(central, 20, 2);
    putLE(central, 0x0800, 2);
    putLE(central, store ? 0 : 8, 2);
    putLE(central, 0, 2);
    putLE(central, 0x5A21, 2);
    putLE(central, crc, 4);
    putLE(central, body.size(), 4);
    putLE(central, f.second.size(), 4);
    putLE(central, f.first.size(), 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 4);
    putLE(central, offset, 4);
    central += f.first;
  }
  size_t cdOffset = out.size();
  out += central;
  putLE(out, 0x06054b50, 4);
  putLE(out, 0, 2);
  putLE(out, 0, 2);
  putLE(out, files.size(), 2);
  putLE(out, files.size(), 2);
  putLE(out, central.size(), 4);
  putLE(out, cdOffset, 4);
  putLE(out, 0, 2);
  return out;
}

} // namespace io
} // namespace nc
