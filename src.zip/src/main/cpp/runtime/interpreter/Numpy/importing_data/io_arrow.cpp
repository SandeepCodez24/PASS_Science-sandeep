// Feather v2 = Apache Arrow IPC file format (and the IPC stream format):
// FlatBuffers metadata, record batches, dictionary batches, LZ4_FRAME /
// ZSTD body compression. Hand-written.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>

#include "io_bytes.h"
#include "io_codecs.h"
#include "io_columnar.h"

namespace nc {
namespace io {
namespace {

// ---- FlatBuffers reading ----------------------------------------------------------------

struct FbTable {
  std::string_view b; // the whole file (a view - the caller keeps it alive)
  bool valid = false;
  size_t pos = 0; // table start
  size_t vt = 0;  // vtable start
  bool ok() const { return valid; }
  static FbTable at(std::string_view b, size_t pos) {
    FbTable t;
    if (pos + 4 > b.size()) return t;
    int32_t so = static_cast<int32_t>(u32le(b, pos));
    int64_t vt = static_cast<int64_t>(pos) - so;
    if (vt < 0 || static_cast<size_t>(vt) + 4 > b.size()) return t;
    t.b = b;
    t.valid = true;
    t.pos = pos;
    t.vt = static_cast<size_t>(vt);
    return t;
  }
  size_t field(int id) const { // absolute position of field id, 0 = absent
    if (!valid) return 0;
    uint16_t vsize = u16le(b, vt);
    size_t entry = 4 + 2 * static_cast<size_t>(id);
    if (entry + 2 > vsize || vt + entry + 2 > b.size()) return 0; // (a damaged vtable size)
    uint16_t o = u16le(b, vt + entry);
    return o ? pos + o : 0;
  }
  int64_t i(int id, int size, int64_t def = 0) const {
    size_t p = field(id);
    if (!p || p + size > b.size()) return def;
    uint64_t v = getLE(b, p, size);
    if (size < 8 && (v >> (8 * size - 1)) & 1) v |= ~0ull << (8 * size);
    return static_cast<int64_t>(v);
  }
  size_t ref(int id) const { size_t p = field(id); return p && p + 4 <= b.size() ? p + u32le(b, p) : 0; }
  FbTable table(int id) const { size_t p = ref(id); return p ? at(b, p) : FbTable(); }
  std::string str(int id) const {
    size_t p = ref(id);
    if (!p || p + 4 > b.size()) return "";
    uint32_t n = u32le(b, p);
    return p + 4 + n <= b.size() ? std::string(b.substr(p + 4, n)) : std::string();
  }
  size_t vecLen(int id) const { // (a damaged length is cut to what the file can hold)
    size_t p = ref(id);
    if (!p || p + 4 > b.size()) return 0;
    return std::min<size_t>(u32le(b, p), (b.size() - p - 4) / 4);
  }
  size_t vecData(int id) const { size_t p = ref(id); return p ? p + 4 : 0; }
  FbTable vecTable(int id, size_t k) const {
    size_t d = vecData(id) + 4 * k;
    return d + 4 <= b.size() ? at(b, d + u32le(b, d)) : FbTable();
  }
};

// ---- FlatBuffers building (back to front, like the official builder) ----------------------

struct FbBuilder {
  std::string buf; // the finished bytes are buf as-is; we prepend
  size_t minAlign = 1;
  std::vector<std::pair<int, size_t>> fields;
  size_t tableStart = 0;
  size_t size() const { return buf.size(); }
  void pad(size_t n) { buf.insert(0, n, '\0'); }
  void prep(size_t align, size_t extra) {
    minAlign = std::max(minAlign, align);
    size_t p = (~(buf.size() + extra) + 1) & (align - 1);
    pad(p);
  }
  void put(uint64_t v, size_t n) { std::string s; putLE(s, v, static_cast<int>(n)); buf.insert(0, s); }
  void scalar(uint64_t v, size_t n) { prep(n, 0); put(v, n); }
  size_t offsetTo(size_t off) { prep(4, 0); put(static_cast<uint32_t>(size() + 4 - off), 4); return size(); }
  size_t string(const std::string &s) {
    prep(4, s.size() + 1);
    buf.insert(0, 1, '\0');
    buf.insert(0, s);
    put(s.size(), 4);
    return size();
  }
  size_t offsets(const std::vector<size_t> &offs) {
    prep(4, 4 * offs.size());
    for (size_t k = offs.size(); k-- > 0;) put(static_cast<uint32_t>(size() + 4 - offs[k]), 4);
    put(offs.size(), 4);
    return size();
  }
  size_t structs(const std::vector<std::string> &items, size_t align) {
    size_t each = items.empty() ? 0 : items[0].size();
    prep(std::max<size_t>(align, 4), each * items.size());
    for (size_t k = items.size(); k-- > 0;) buf.insert(0, items[k]);
    prep(4, 0);
    put(items.size(), 4);
    return size();
  }
  void start() { fields.clear(); tableStart = size(); }
  void addScalar(int id, uint64_t v, size_t n) { scalar(v, n); fields.push_back({id, size()}); }
  void addOffset(int id, size_t off) { offsetTo(off); fields.push_back({id, size()}); }
  size_t end() {
    prep(4, 0);
    put(0, 4); // soffset placeholder
    size_t tableOff = size();
    int maxId = -1;
    for (auto &f : fields) maxId = std::max(maxId, f.first);
    std::vector<uint16_t> vt(static_cast<size_t>(maxId + 1), 0);
    for (auto &f : fields) vt[static_cast<size_t>(f.first)] = static_cast<uint16_t>(tableOff - f.second);
    std::string v;
    putLE(v, 4 + 2 * vt.size(), 2);
    putLE(v, tableOff - tableStart, 2);
    for (auto x : vt) putLE(v, x, 2);
    buf.insert(0, v);
    size_t vtOff = size();
    // soffset at the table start = table - vtable
    size_t at = size() - tableOff;
    std::string so;
    putLE(so, static_cast<uint32_t>(static_cast<int32_t>(vtOff - tableOff)), 4);
    std::memcpy(&buf[at], so.data(), 4);
    fields.clear();
    return tableOff;
  }
  std::string finish(size_t root) {
    prep(std::max<size_t>(minAlign, 8), 4);
    put(static_cast<uint32_t>(size() + 4 - root), 4);
    return buf;
  }
};

// ---- reading -------------------------------------------------------------------------------

struct ArrowField {
  std::string name;
  int type = 0;
  FbTable t;
  int bitWidth = 0, unit = 0, precision = 0, scale = 0;
  bool isSigned = true;
  bool dict = false;
  int64_t dictId = 0;
  int idxBits = 32;
  bool idxSigned = true;
  std::vector<ArrowField> kids;
};

ArrowField parseField(const FbTable &f) {
  ArrowField a;
  a.name = f.str(0);
  a.type = static_cast<int>(f.i(2, 1, 0));
  a.t = f.table(3);
  if (a.t.ok()) {
    if (a.type == 2) { a.bitWidth = static_cast<int>(a.t.i(0, 4, 32)); a.isSigned = a.t.i(1, 1, 0) != 0; }
    else if (a.type == 3) a.precision = static_cast<int>(a.t.i(0, 2, 0));
    else if (a.type == 7) { a.precision = static_cast<int>(a.t.i(0, 4, 0)); a.scale = static_cast<int>(a.t.i(1, 4, 0)); a.bitWidth = static_cast<int>(a.t.i(2, 4, 128)); }
    else if (a.type == 8 || a.type == 18) a.unit = static_cast<int>(a.t.i(0, 2, a.type == 8 ? 1 : 1));
    else if (a.type == 9) { a.unit = static_cast<int>(a.t.i(0, 2, 1)); a.bitWidth = static_cast<int>(a.t.i(1, 4, 32)); }
    else if (a.type == 10) a.unit = static_cast<int>(a.t.i(0, 2, 0));
    else if (a.type == 15) a.bitWidth = static_cast<int>(a.t.i(0, 4, 0));
  }
  FbTable d = f.table(4);
  if (d.ok()) {
    a.dict = true;
    a.dictId = d.i(0, 8, 0);
    FbTable it = d.table(1);
    if (it.ok()) { a.idxBits = static_cast<int>(it.i(0, 4, 32)); a.idxSigned = it.i(1, 1, 0) != 0; }
  }
  for (size_t k = 0; k < f.vecLen(5); k++) a.kids.push_back(parseField(f.vecTable(5, k)));
  return a;
}

std::string typeName(const ArrowField &a) {
  switch (a.type) {
  case 1: return "null";
  case 2: return std::string(a.isSigned ? "int" : "uint") + std::to_string(a.bitWidth);
  case 3: return a.precision == 0 ? "float16" : a.precision == 1 ? "float32" : "float64";
  case 4: case 19: return "binary";
  case 5: case 20: return "str";
  case 6: return "bool";
  case 7: return "decimal";
  case 8: return "date";
  case 9: return "time";
  case 10: return "timestamp";
  case 15: return "binary";
  case 18: return "duration";
  }
  return "type " + std::to_string(a.type);
}

struct Batch { // one decoded batch: flattened columns
  std::vector<std::vector<Value>> cols;
  size_t rows = 0;
};

struct BodyReader {
  std::string_view b;
  size_t body;
  FbTable rb;
  size_t node = 0, buffer = 0;
  int codec = -1; // -1 none, 0 lz4 frame, 1 zstd
  // The length every column must have (the record batch's, a struct's for
  // its children; -1 = not checked): the Arrow format requires it, and a
  // damaged length must not make a reader run away.
  int64_t expectLen = -1;
  std::string err;
  BodyReader(std::string_view bytes, size_t bodyStart, const FbTable &recordBatch) : b(bytes), body(bodyStart), rb(recordBatch) {
    FbTable c = rb.table(3);
    if (c.ok()) codec = static_cast<int>(c.i(0, 1, 0));
  }
  std::pair<int64_t, int64_t> nextNode() {
    size_t d = rb.vecData(1) + 16 * node++;
    if (!rb.vecData(1) || d + 16 > b.size()) return {0, 0};
    return {static_cast<int64_t>(u64le(b, d)), static_cast<int64_t>(u64le(b, d + 8))};
  }
  bool nextBuffer(std::string &out) {
    size_t d = rb.vecData(2) + 16 * buffer++;
    if (!rb.vecData(2) || d + 16 > b.size()) { err = "record batch has too few buffers"; return false; }
    uint64_t off = u64le(b, d), len = u64le(b, d + 8);
    if (body > b.size() || off > b.size() - body || len > b.size() - body - off) { err = "a buffer runs past the end of the file"; return false; }
    out = b.substr(static_cast<size_t>(body + off), static_cast<size_t>(len));
    if (codec >= 0 && out.size() >= 8) {
      int64_t ulen = static_cast<int64_t>(u64le(out, 0));
      std::string rest = out.substr(8);
      if (ulen == -1) { out = rest; return true; }
      std::string dec;
      if (!decompressWith(codec == 0 ? "lz4" : "zstd", rest, static_cast<size_t>(ulen), dec, err)) return false;
      out = dec;
    }
    return true;
  }
};

bool validAt(const std::string &bitmap, size_t i) {
  return bitmap.empty() || (i / 8 < bitmap.size() && ((static_cast<unsigned char>(bitmap[i / 8]) >> (i % 8)) & 1));
}

// decodes one field (and its children) into flat columns; `skipOnly` consumes buffers
bool decodeField(BodyReader &r, const ArrowField &f, std::vector<std::vector<Value>> &cols, std::vector<std::string> &names,
                 std::vector<std::string> &types, const std::string &prefix, const std::map<int64_t, std::vector<Value>> &dicts,
                 std::vector<std::string> &skipped, bool skipOnly) {
  auto node = r.nextNode();
  size_t n = static_cast<size_t>(node.first);
  if (!skipOnly && r.expectLen >= 0 && node.first != r.expectLen) {
    r.err = "column '" + prefix + f.name + "' has " + std::to_string(node.first) + " values, its record batch " +
            std::to_string(r.expectLen) + " (damaged)";
    return false;
  }
  std::string name = prefix + f.name;
  std::string validity, a1, a2;
  auto skipChildren = [&]() { for (const auto &k : f.kids) if (!decodeField(r, k, cols, names, types, name + ".", dicts, skipped, true)) return false; return true; };
  switch (f.dict ? 2 : f.type) { // a dictionary field carries validity + indices, whatever its value type
  case 1: break; // Null: no buffers
  case 13: { // struct: its children are as long as it is
    if (!r.nextBuffer(validity)) return false;
    const int64_t outer = r.expectLen;
    r.expectLen = skipOnly ? -1 : node.first;
    for (const auto &k : f.kids) if (!decodeField(r, k, cols, names, types, name + ".", dicts, skipped, skipOnly)) return false;
    r.expectLen = outer;
    return true;
  }
  case 12: case 17: case 21: // list / map / large list
    if (!r.nextBuffer(validity) || !r.nextBuffer(a1)) return false;
    if (!skipOnly) skipped.push_back(name + " (list)");
    return skipChildren();
  case 16: // fixed size list
    if (!r.nextBuffer(validity)) return false;
    if (!skipOnly) skipped.push_back(name + " (list)");
    return skipChildren();
  case 4: case 5: case 19: case 20:
    if (!r.nextBuffer(validity) || !r.nextBuffer(a1) || !r.nextBuffer(a2)) return false;
    break;
  case 14: case 22: case 23: case 24:
    r.err = "column '" + name + "' has an Arrow type (union / run-end / view) that is not built in";
    return false;
  default:
    if (!r.nextBuffer(validity) || !r.nextBuffer(a1)) return false;
  }
  if (skipOnly) return true;
  {
    size_t cap = SIZE_MAX; // the values this column's buffers can hold
    const int widthBits = f.dict ? f.idxBits : f.type == 2 || f.type == 7 || f.type == 9 ? f.bitWidth
                          : f.type == 3 ? (f.precision == 2 ? 64 : f.precision == 1 ? 32 : 16)
                          : f.type == 6 ? 1 : f.type == 8 ? (f.unit == 0 ? 32 : 64) : f.type == 10 || f.type == 18 ? 64
                          : f.type == 15 ? f.bitWidth * 8 : 0;
    if (widthBits > 0) cap = a1.size() * 8 / static_cast<size_t>(widthBits);
    if (!f.dict && (f.type == 4 || f.type == 5 || f.type == 19 || f.type == 20)) { // (a dictionary column holds indices)
      const size_t w = f.type >= 19 ? 8 : 4;
      cap = a1.size() >= w ? a1.size() / w - 1 : 0;
    }
    if (!validity.empty()) cap = std::min(cap, validity.size() * 8);
    if (f.type != 1 && n > cap) {
      r.err = "column '" + name + "' says " + std::to_string(n) + " values but its data holds " + std::to_string(cap) +
              " (" + std::to_string(a1.size()) + " bytes of " + std::to_string(widthBits) + "-bit values)";
      return false;
    }
    const bool okWidth = f.dict ? (f.idxBits == 8 || f.idxBits == 16 || f.idxBits == 32 || f.idxBits == 64)
                         : f.type == 2 || f.type == 9 ? (f.bitWidth == 8 || f.bitWidth == 16 || f.bitWidth == 32 || f.bitWidth == 64)
                         : f.type == 7 ? (f.bitWidth == 128 || f.bitWidth == 256)
                         : f.type == 15 ? f.bitWidth > 0 : true;
    if (!okWidth) {
      r.err = "column '" + name + "' has a damaged type (bit width " + std::to_string(f.dict ? f.idxBits : f.bitWidth) + ")";
      return false;
    }
  }
  std::vector<Value> out;
  out.reserve(f.type == 1 ? 0 : n);
  auto num = [&](size_t i, int bytes, bool sign) -> double {
    if ((i + 1) * bytes > a1.size()) return std::nan("");
    uint64_t v = getLE(a1, i * bytes, bytes);
    if (sign && bytes < 8 && (v >> (8 * bytes - 1)) & 1) v |= ~0ull << (8 * bytes);
    return sign ? static_cast<double>(static_cast<int64_t>(v)) : static_cast<double>(v);
  };
  for (size_t i = 0; i < n; i++) {
    if (f.type == 1 || !validAt(validity, i)) { out.push_back(Value(missingNumber())); continue; }
    if (f.dict) {
      double k = num(i, f.idxBits / 8, f.idxSigned);
      auto it = dicts.find(f.dictId);
      out.push_back(it != dicts.end() && k >= 0 && k < it->second.size() ? it->second[static_cast<size_t>(k)] : Value(std::nan("")));
      continue;
    }
    switch (f.type) {
    case 2: { // the column's own integer type (2026-11-15), exact at any size
      const size_t bytes = static_cast<size_t>(f.bitWidth / 8);
      if ((i + 1) * bytes > a1.size()) { out.push_back(Value(std::nan(""))); break; }
      uint64_t u = getLE(a1, i * bytes, static_cast<int>(bytes));
      if (f.isSigned) {
        if (bytes < 8 && ((u >> (8 * bytes - 1)) & 1)) u |= ~0ull << (8 * bytes);
        const IntType t = bytes == 1 ? IntType::Int8 : bytes == 2 ? IntType::Int16 : bytes == 4 ? IntType::Int32 : IntType::Int64;
        out.push_back(Value::integerSigned(t, static_cast<int64_t>(u)));
      } else {
        const IntType t = bytes == 1 ? IntType::UInt8 : bytes == 2 ? IntType::UInt16 : bytes == 4 ? IntType::UInt32 : IntType::UInt64;
        out.push_back(Value::integerUnsigned(t, u));
      }
      break;
    }
    case 3:
      if (f.precision == 2) out.push_back(Value(i * 8 + 8 <= a1.size() ? f64le(a1, i * 8) : std::nan("")));
      else if (f.precision == 1) out.push_back(i * 4 + 4 <= a1.size() ? Value::floating(FloatType::Float32, static_cast<double>(f32le(a1, i * 4))) : Value(std::nan("")));
      else {
        if (i * 2 + 2 > a1.size()) { out.push_back(Value(std::nan(""))); break; }
        uint16_t h = static_cast<uint16_t>(getLE(a1, i * 2, 2));
        int e = (h >> 10) & 31, m = h & 1023;
        double v = e == 0 ? std::ldexp(m, -24) : e == 31 ? (m ? std::nan("") : INFINITY) : std::ldexp(m + 1024, e - 25);
        out.push_back(Value((h & 0x8000) ? -v : v));
      }
      break;
    case 4: case 5: case 19: case 20: {
      int w = (f.type == 19 || f.type == 20) ? 8 : 4;
      if ((i + 2) * w > a1.size()) { out.push_back(Value(std::nan(""))); break; }
      uint64_t s = getLE(a1, i * w, w), e = getLE(a1, (i + 1) * w, w);
      out.push_back(Value(e <= a2.size() && s <= e ? a2.substr(static_cast<size_t>(s), static_cast<size_t>(e - s)) : std::string()));
      break;
    }
    case 6: out.push_back(Value::boolean(i / 8 < a1.size() && ((static_cast<unsigned char>(a1[i / 8]) >> (i % 8)) & 1))); break;
    case 7: { // decimal128 / 256: low 64 bits are enough for typical values
      size_t w = static_cast<size_t>(f.bitWidth / 8);
      if ((i + 1) * w > a1.size()) { out.push_back(Value(std::nan(""))); break; }
      int64_t lo = static_cast<int64_t>(u64le(a1, i * w));
      out.push_back(Value(static_cast<double>(lo) / std::pow(10.0, f.scale)));
      break;
    }
    case 8:
      if (f.unit == 0) out.push_back(Value(isoDate(static_cast<int64_t>(num(i, 4, true)))));
      else out.push_back(Value(isoDate(static_cast<int64_t>(std::floor(num(i, 8, true) / 86400000.0)))));
      break;
    case 9: { double v = num(i, f.bitWidth / 8, true); out.push_back(Value(v / (f.unit == 0 ? 1 : f.unit == 1 ? 1e3 : f.unit == 2 ? 1e6 : 1e9))); break; }
    case 10: {
      double v = num(i, 8, true), div = f.unit == 0 ? 1 : f.unit == 1 ? 1e3 : f.unit == 2 ? 1e6 : 1e9;
      out.push_back(Value(isoTimestamp(v / div, f.unit == 0 ? 0 : f.unit == 1 ? 3 : 6)));
      break;
    }
    case 15: { size_t w = static_cast<size_t>(f.bitWidth); out.push_back(Value((i + 1) * w <= a1.size() ? a1.substr(i * w, w) : std::string())); break; }
    case 18: { double v = num(i, 8, true); out.push_back(Value(v / (f.unit == 0 ? 1 : f.unit == 1 ? 1e3 : f.unit == 2 ? 1e6 : 1e9))); break; }
    default: out.push_back(Value(std::nan("")));
    }
  }
  cols.push_back(std::move(out));
  names.push_back(name);
  types.push_back(f.dict ? "category" : typeName(f));
  return true;
}

struct Msg {
  FbTable m;
  size_t body = 0;
  int64_t bodyLen = 0;
};

bool messageAt(std::string_view b, size_t pos, Msg &out, size_t &next) {
  if (pos + 8 > b.size()) return false;
  size_t p = pos;
  uint32_t len = u32le(b, p);
  if (len == 0xFFFFFFFFu) { p += 4; len = u32le(b, p); }
  p += 4;
  if (len == 0 || p + len > b.size()) return false;
  size_t root = p + u32le(b, p);
  out.m = FbTable::at(b, root);
  if (!out.m.ok()) return false;
  out.body = p + len;
  out.bodyLen = out.m.i(3, 8, 0);
  next = out.body + static_cast<size_t>(out.bodyLen);
  return true;
}

} // namespace

bool readArrowIpc(std::string_view b, const ColReadOptions &o, ColFile &f, std::string &err) {
  if (b.size() >= 4 && b.compare(0, 4, "FEA1") == 0) { err = "this is a Feather v1 file (before 2020) - not built in; re-save it as Feather v2"; return false; }
  bool fileFormat = b.size() >= 12 && b.compare(0, 6, "ARROW1") == 0 && b.compare(b.size() - 6, 6, "ARROW1") == 0;
  bool stream = !fileFormat && b.size() >= 8 && u32le(b, 0) == 0xFFFFFFFFu;
  if (!fileFormat && !stream) { err = "not a Feather v2 / Arrow IPC file (no ARROW1 magic)"; return false; }
  f.format = fileFormat ? "feather (Arrow IPC file)" : "Arrow IPC stream";
  FbTable schema;
  std::vector<size_t> batchPos, dictPos;
  if (fileFormat) {
    uint32_t flen = u32le(b, b.size() - 10);
    if (flen + 18 > b.size()) { err = "Arrow footer length is wrong"; return false; }
    size_t fstart = b.size() - 10 - flen;
    FbTable footer = FbTable::at(b, fstart + u32le(b, fstart));
    if (!footer.ok()) { err = "Arrow footer is damaged"; return false; }
    schema = footer.table(1);
    for (int which : {2, 3}) {
      size_t n = footer.vecLen(which), d = footer.vecData(which);
      for (size_t k = 0; k < n; k++) (which == 2 ? dictPos : batchPos).push_back(static_cast<size_t>(u64le(b, d + 24 * k)));
    }
  } else {
    size_t p = 0;
    while (p + 8 <= b.size()) {
      Msg m;
      size_t next;
      if (u32le(b, p) == 0xFFFFFFFFu && u32le(b, p + 4) == 0) break; // end of stream
      if (!messageAt(b, p, m, next)) break;
      int ht = static_cast<int>(m.m.i(1, 1, 0));
      if (ht == 1) schema = m.m.table(2);
      else if (ht == 2) dictPos.push_back(p);
      else if (ht == 3) batchPos.push_back(p);
      p = next;
    }
  }
  if (!schema.ok()) { err = "Arrow schema is missing"; return false; }
  std::vector<ArrowField> fields;
  for (size_t k = 0; k < schema.vecLen(1); k++) fields.push_back(parseField(schema.vecTable(1, k)));
  for (size_t k = 0; k < schema.vecLen(2); k++) { FbTable kv = schema.vecTable(2, k); f.kv.push_back({kv.str(0), kv.str(1)}); }
  // dictionaries
  std::map<int64_t, std::vector<Value>> dicts;
  std::map<int64_t, const ArrowField *> dictField;
  std::function<void(const ArrowField &)> findDicts = [&](const ArrowField &a) { if (a.dict) dictField[a.dictId] = &a; for (auto &k : a.kids) findDicts(k); };
  for (auto &a : fields) findDicts(a);
  for (size_t pos : dictPos) {
    Msg m;
    size_t next;
    if (!messageAt(b, pos, m, next)) { err = "a dictionary batch is damaged"; return false; }
    FbTable db = m.m.table(2);
    int64_t id = db.i(0, 8, 0);
    bool delta = db.i(2, 1, 0) != 0;
    auto it = dictField.find(id);
    if (it == dictField.end()) continue;
    ArrowField plain = *it->second;
    plain.dict = false;
    BodyReader r(b, m.body, db.table(1));
    r.expectLen = db.table(1).i(0, 8, 0); // the dictionary batch's length
    std::vector<std::vector<Value>> cols;
    std::vector<std::string> names, types, sk;
    if (!decodeField(r, plain, cols, names, types, "", {}, sk, false)) { err = r.err; return false; }
    if (!delta) dicts[id].clear();
    if (!cols.empty()) for (auto &v : cols[0]) dicts[id].push_back(v);
  }
  bool namesSet = false;
  std::vector<size_t> keep;
  // rows= window (ColReadOptions::rowFirst/rowLast): a batch wholly outside
  // it is not decoded - its row count is in its header. The first batch is
  // always decoded, for the column names.
  const bool window = o.rowFirst > 0 || o.rowLast != static_cast<size_t>(-1);
  size_t groupStart = 0;
  bool keptAny = false;
  ColTableBuilder tb;
  for (size_t g = 0; g < batchPos.size(); g++) {
    Msg m;
    size_t next;
    if (!messageAt(b, batchPos[g], m, next)) { err = "a record batch is damaged"; return false; }
    FbTable rb = m.m.table(2);
    if (rb.i(0, 8, 0) < 0) { err = "record batch " + std::to_string(g) + " has a negative length (damaged)"; return false; }
    const size_t rowsHere = static_cast<size_t>(rb.i(0, 8, 0)), first = groupStart;
    groupStart += rowsHere;
    const bool outside = window && (rowsHere == 0 || first + rowsHere <= o.rowFirst || first > o.rowLast);
    if (outside && namesSet && !o.metaOnly) {
      ColGroup cg;
      cg.rows = rowsHere;
      cg.bytes = static_cast<uint64_t>(m.bodyLen);
      cg.stats.assign(keep.size(), ColStats());
      f.groups.push_back(cg);
      f.totalRows += cg.rows;
      if (!keptAny) f.rowOffset = groupStart;
      continue;
    }
    if (o.metaOnly && namesSet) { // probe: the row count of a batch is in its header
      ColGroup cg;
      cg.rows = static_cast<size_t>(rb.i(0, 8, 0));
      cg.bytes = static_cast<uint64_t>(m.bodyLen);
      cg.stats.assign(keep.size(), ColStats());
      f.groups.push_back(cg);
      f.totalRows += cg.rows;
      continue;
    }
    reportProgress("read_feather", "", static_cast<double>(g) / static_cast<double>(batchPos.size()));
    if (cancelRequested()) { err = "cancelled"; return false; }
    BodyReader r(b, m.body, rb);
    r.expectLen = static_cast<int64_t>(rowsHere); // every column is this long
    if (r.codec > 1) { err = "Arrow body compression " + std::to_string(r.codec) + " is not built in"; return false; }
    if (g == 0) f.codec = r.codec == 0 ? "lz4" : r.codec == 1 ? "zstd" : "none";
    // One top-level field at a time (2026-11-15): its columns are decoded,
    // their statistics taken, and they go straight into the table's columns
    // - a batch is never held as Values all at once.
    ColGroup cg;
    cg.rows = static_cast<size_t>(rb.i(0, 8, 0));
    cg.bytes = static_cast<uint64_t>(m.bodyLen);
    const bool groupWanted = o.groups.empty() || std::find(o.groups.begin(), o.groups.end(), g) != o.groups.end();
    const bool addRows = groupWanted && !outside; // else: decoded for the names / statistics only
    std::vector<std::vector<Value>> cols;
    std::vector<std::string> names, types, sk, allNames;
    size_t leaf = 0; // index of the next column among all of the batch's
    for (const auto &a : fields) {
      cols.clear();
      names.clear();
      types.clear();
      if (!decodeField(r, a, cols, names, types, "", dicts, sk, false)) { err = r.err.empty() ? "a record batch is damaged" : r.err; return false; }
      for (size_t j = 0; j < cols.size(); j++, leaf++) {
        if (!namesSet) {
          allNames.push_back(names[j]);
          bool want = o.cols.empty();
          for (const auto &c : o.cols) if (c == names[j] || names[j].rfind(c + ".", 0) == 0) want = true;
          if (want) { keep.push_back(leaf); f.table.cols.push_back(names[j]); f.types.push_back(types[j]); tb.cols.emplace_back(); }
        }
        const auto kit = std::find(keep.begin(), keep.end(), leaf);
        if (kit == keep.end()) continue;
        const size_t ki = static_cast<size_t>(kit - keep.begin());
        ColStats st; // stats computed from the data (IPC stores none)
        double nulls = 0;
        for (const auto &v : cols[j]) {
          if (!v.isText && std::isnan(v.number)) { nulls++; continue; }
          auto less = [](const Value &x, const Value &y) { return x.isText || y.isText ? cellText(x) < cellText(y) : x.number < y.number; };
          if (!st.hasMin || less(v, st.min)) { st.min = v; st.hasMin = true; }
          if (!st.hasMax || less(st.max, v)) { st.max = v; st.hasMax = true; }
        }
        st.nulls = nulls;
        cg.stats.push_back(st); // kept columns come in their order
        if (addRows) tb.addColumn(ki, cols[j], cg.rows);
        else std::vector<Value>().swap(cols[j]);
      }
    }
    if (!namesSet) {
      f.skipped = sk;
      for (const auto &c : o.cols) {
        bool found = false;
        for (const auto &nm : allNames) if (nm == c || nm.rfind(c + ".", 0) == 0) found = true;
        if (!found) { std::string j; for (auto &nm : allNames) j += (j.empty() ? "" : ", ") + nm; err = "no column '" + c + "' (columns: " + j + ")"; return false; }
      }
      namesSet = true;
    }
    f.groups.push_back(cg);
    f.totalRows += cg.rows;
    if (!groupWanted) continue;
    if (outside) { // the first batch, decoded for its names only
      if (!keptAny) f.rowOffset = groupStart;
      continue;
    }
    if (window && !keptAny) { f.rowOffset = first; keptAny = true; }
    tb.endGroup(cg.rows);
  }
  if (namesSet && !o.metaOnly) tb.finish(f.table);
  if (!namesSet) { // no batches: names from the schema
    for (const auto &a : fields) { f.table.cols.push_back(a.name); f.types.push_back(typeName(a)); }
  }
  if (f.codec.empty()) f.codec = "none";
  return true;
}

// ---- writing -------------------------------------------------------------------------------

namespace {

std::string message(int headerType, const std::function<size_t(FbBuilder &)> &header, int64_t bodyLen) {
  FbBuilder fb;
  size_t h = header(fb);
  fb.start();
  fb.addScalar(3, static_cast<uint64_t>(bodyLen), 8);
  fb.addOffset(2, h);
  fb.addScalar(0, 4, 2);                 // MetadataVersion V5
  fb.addScalar(1, static_cast<uint64_t>(headerType), 1);
  size_t root = fb.end();
  std::string meta = fb.finish(root);
  while ((meta.size() + 8) % 8) meta.push_back('\0');
  std::string out;
  putLE(out, 0xFFFFFFFFu, 4);
  putLE(out, meta.size(), 4);
  return out + meta;
}

size_t schemaTable(FbBuilder &fb, const Table &t, const std::vector<std::string> &kinds, const ColWriteOptions &o) {
  std::vector<size_t> fieldOffs;
  for (size_t c = 0; c < t.cols.size(); c++) {
    const std::string &k = kinds[c];
    size_t type;
    int typeId;
    fb.start();
    if (k == "int64") { fb.addScalar(1, 1, 1); fb.addScalar(0, 64, 4); typeId = 2; }
    else if (k == "float64") { fb.addScalar(0, 2, 2); typeId = 3; }
    else if (k == "bool") typeId = 6;
    else typeId = 5;
    type = fb.end();
    size_t name = fb.string(t.cols[c]);
    size_t kids = fb.offsets({});
    fb.start();
    fb.addOffset(0, name);
    fb.addOffset(3, type);
    fb.addOffset(5, kids);
    fb.addScalar(1, 1, 1);
    fb.addScalar(2, static_cast<uint64_t>(typeId), 1);
    fieldOffs.push_back(fb.end());
  }
  size_t fieldsVec = fb.offsets(fieldOffs);
  std::vector<size_t> kvs;
  for (const auto &kv : o.kv) {
    size_t key = fb.string(kv.first), val = fb.string(kv.second);
    fb.start();
    fb.addOffset(0, key);
    fb.addOffset(1, val);
    kvs.push_back(fb.end());
  }
  size_t kvVec = kvs.empty() ? 0 : fb.offsets(kvs);
  fb.start();
  fb.addOffset(1, fieldsVec);
  if (kvVec) fb.addOffset(2, kvVec);
  fb.addScalar(0, 0, 2); // little endian
  return fb.end();
}

} // namespace

std::string writeArrowIpc(const Table &t, const ColWriteOptions &o, std::string &err) {
  int codec = -1;
  if (o.codec == "lz4") codec = 0;
  else if (o.codec == "zstd") codec = 1;
  else if (o.codec != "none") { err = "feather supports compress=\"zstd\", \"lz4\" or \"none\" (Arrow IPC has no " + o.codec + ")"; return ""; }
  std::vector<std::string> kinds = writeKinds(t);
  std::string out = std::string("ARROW1") + std::string(2, '\0');
  uint64_t base = 0; // bytes already handed to o.sink
  std::string schemaMsg = message(1, [&](FbBuilder &fb) { return schemaTable(fb, t, kinds, o); }, 0);
  out += schemaMsg;
  struct Block { int64_t offset; int32_t meta; int64_t body; };
  std::vector<Block> blocks;
  size_t nrows = t.rowCount();
  size_t groupRows = o.groupRows ? o.groupRows : std::max<size_t>(1, std::min<size_t>(nrows, 1u << 20));
  for (size_t from = 0; from < nrows || (nrows == 0 && blocks.empty()); from += groupRows) {
    size_t to = std::min(nrows, from + groupRows), n = to - from;
    std::string body;
    std::vector<std::string> nodes, bufs;
    auto addBuf = [&](std::string data) {
      if (codec >= 0 && !data.empty()) {
        std::string comp;
        std::string e2;
        compressWith(codec == 0 ? "lz4" : "zstd", o.level, data, comp, e2);
        std::string framed;
        if (comp.size() < data.size()) { putLE(framed, data.size(), 8); framed += comp; }
        else { putLE(framed, ~0ull, 8); framed += data; }
        data = framed;
      }
      std::string b;
      putLE(b, body.size(), 8);
      putLE(b, data.size(), 8);
      bufs.push_back(b);
      body += data;
      while (body.size() % 8) body.push_back('\0');
    };
    for (size_t c = 0; c < t.cols.size(); c++) {
      const std::string &k = kinds[c];
      std::string validity((n + 7) / 8, '\0');
      size_t nulls = 0;
      // this batch's cells of the column (column form: made for it)
      std::vector<Value> cellBuf;
      if (t.columnar) {
        cellBuf.reserve(n);
        for (size_t r = 0; r < n; r++) cellBuf.push_back(t.cell(from + r, c));
      }
      auto cellOf = [&](size_t r) -> const Value & { return t.columnar ? cellBuf[r] : t.rows[from + r][c]; };
      for (size_t r = 0; r < n; r++) {
        const Value &v = cellOf(r);
        // missing -> null; a computed NaN stays NaN in a float64 column (a column of
        // another kind cannot hold it: null); text in a non-text column: null
        bool null = (!v.isText && std::isnan(v.number) && (isMissingNumber(v.number) || k != "float64")) || (k != "str" && v.isText);
        if (null) nulls++; else validity[r / 8] |= static_cast<char>(1 << (r % 8));
      }
      std::string node;
      putLE(node, n, 8);
      putLE(node, nulls, 8);
      nodes.push_back(node);
      addBuf(nulls ? validity : std::string());
      if (k == "str") {
        std::string offs, data;
        putLE(offs, 0, 4);
        for (size_t r = 0; r < n; r++) {
          const Value &v = cellOf(r);
          if (v.isText || !std::isnan(v.number)) data += cellText(v);
          if (data.size() > 0x7FFFFFFF) { err = "a text column is over 2 GB in one batch - use a smaller group_rows"; return ""; }
          putLE(offs, data.size(), 4);
        }
        addBuf(offs);
        addBuf(data);
      } else if (k == "bool") {
        std::string bits((n + 7) / 8, '\0');
        for (size_t r = 0; r < n; r++) if (cellOf(r).number != 0 && !std::isnan(cellOf(r).number)) bits[r / 8] |= static_cast<char>(1 << (r % 8));
        addBuf(bits);
      } else {
        std::string data;
        for (size_t r = 0; r < n; r++) {
          double v = cellOf(r).isText ? 0 : cellOf(r).number;
          if (k == "int64") putLE(data, static_cast<uint64_t>(std::isnan(v) ? 0 : exactInt64(cellOf(r))), 8);
          else putF64LE(data, v);
        }
        addBuf(data);
      }
    }
    std::string msg = message(3, [&](FbBuilder &fb) {
      size_t comp = 0;
      if (codec >= 0) { fb.start(); fb.addScalar(0, static_cast<uint64_t>(codec), 1); fb.addScalar(1, 0, 1); comp = fb.end(); }
      size_t bufVec = fb.structs(bufs, 8);
      size_t nodeVec = fb.structs(nodes, 8);
      fb.start();
      fb.addScalar(0, n, 8);
      fb.addOffset(1, nodeVec);
      fb.addOffset(2, bufVec);
      if (comp) fb.addOffset(3, comp);
      return fb.end();
    }, static_cast<int64_t>(body.size()));
    blocks.push_back({static_cast<int64_t>(base + out.size()), static_cast<int32_t>(msg.size()), static_cast<int64_t>(body.size())});
    out += msg + body;
    if (o.sink) { // E6: this group is complete - hand it to the file
      if (!o.sink(out, err)) return "";
      base += out.size();
      out.clear();
    }
    if (saveProgress(nrows ? static_cast<double>(to) / static_cast<double>(nrows) : 1.0)) { err = "cancelled"; return ""; }
    if (nrows == 0) break;
  }
  putLE(out, 0xFFFFFFFFu, 4); // end of stream
  putLE(out, 0, 4);
  // footer
  FbBuilder fb;
  size_t schema = schemaTable(fb, t, kinds, o);
  std::vector<std::string> blk;
  for (const auto &b : blocks) { std::string s; putLE(s, b.offset, 8); putLE(s, static_cast<uint32_t>(b.meta), 4); putLE(s, 0, 4); putLE(s, b.body, 8); blk.push_back(s); }
  size_t batches = fb.structs(blk, 8);
  size_t dicts = fb.structs({}, 8);
  fb.start();
  fb.addOffset(1, schema);
  fb.addOffset(2, dicts);
  fb.addOffset(3, batches);
  fb.addScalar(0, 4, 2);
  size_t root = fb.end();
  std::string footer = fb.finish(root);
  out += footer;
  putLE(out, footer.size(), 4);
  out += "ARROW1";
  return out;
}

} // namespace io
} // namespace nc
