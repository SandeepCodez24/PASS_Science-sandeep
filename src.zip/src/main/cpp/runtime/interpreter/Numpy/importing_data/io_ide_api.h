// The IDE's Import / Process / Export windows -> nc.exe (added 2026-11-10).
//
// The Java IDE talks to nc.exe only through stdin / stdout, so the
// ImportSession API (io_session.h) is offered to it as protocol lines, in
// the same style as @WS / @VAR (runtime/data/WS_PROTOCOL.md):
//
//   IDE -> nc.exe   @cmd io {"id":"7","op":"code","action":"read","format":"csv",
//                            "file":"D:/data/a.csv","var":"T","options":{"hdr":"1"}}
//   nc.exe -> IDE   \x1E@IO {"v":1,"type":"io","id":"7","op":"code","ok":true,
//                            "code":"T = read_csv(\"D:/data/a.csv\", hdr=1);", ...}
//
// Requests ("op"):
//   formats    every format: id, category, title, extensions, which of
//              read / load / save exist and their function names
//   detect     which format a file is (first bytes; the extension breaks ties)
//   options    the named options of read_ / load_ / save_<format>
//   preview    the first rows of a file, as the Import window shows them
//   code       the NC line for a read / load / save, checked; the line shown
//              in the window's code column, the same text a script would use
//   run        runs that line (or any NC "code" the Process window built)
//              exactly as if typed in the Command Window: the variable lands
//              in the workspace, @WS follows, and one @IO answer says how it
//              went. Progress arrives meanwhile as \x1E@IOEV lines; the
//              IDE's Stop (interrupt.flag) cancels a long read - and a long
//              save, which then leaves no file (the old one stays whole).
//              A save's answer names the file(s) written, bytes, rows, cols.
// For the Export window (2026-11-17, docs/Export_Window.md):
//   target     the file about to be written: exists, bytes, modified,
//              writable, its format and probe, whether mode="a" can append
//   accepts    can a variable be saved as a format (the writer is run on it
//              in a scratch folder), what changes (losses), formats that
//              keep it whole
//   preview    with "action":"save": the first lines / schema / picture size
//              the file will have, and its estimated bytes
//   estimate   the bytes of the file for several option sets at once
//   peek       a bounded look at a variable of any size (cells, a picture,
//              a sound's min / max per bucket, a tree's first nodes)
// For the Process Data window (2026-11-17, docs/Process_Window_CPP.md):
//   functions  every built-in name nc.exe accepts in a call, and the
//              argument forms that came later ("unique:stable", ...)
//   process    check / run a pipeline of steps on a variable natively, one
//              @IOEV "step" event per step (compiler_src/process_runner.h)
//   check      parse NC code only: its syntax errors with line and column
//
// Full contract: docs/Import_Window.md and docs/Export_Window.md.
#ifndef NC_IO_IDE_API_H
#define NC_IO_IDE_API_H

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "../../core/value.h"

namespace nc {
namespace io {
namespace ide {

using Workspace = std::unordered_map<std::string, Value>;

// A "run" request, handed back to the REPL to execute.
struct RunRequest {
  std::string id;     // the request's id, echoed in every answer
  std::string code;   // NC text to run; empty = nothing to run
  std::string var;    // variable the run should leave behind ("" = none)
  std::string action; // "read" / "load" / "save" / "code"
  std::string function; // "read_csv" ... ("" for free code)
  // op:"process" / op:"check" (docs/Process_Window_CPP.md P2 / P4): these
  // need the REPL's Parser, so they come back here instead of as code -
  // kind is "process" or "check", json the whole request. main.cpp hands
  // them to compiler_src/process_runner.h. Empty kind = an ordinary run.
  std::string kind;
  std::string json;
};

// One protocol line ("@IO {...}" / "@IOEV {...}"), written whole
// under the same lock as every other @IO line.
void sendProtocolLine(const char *kind, const std::string &json);

// Handles the JSON after "@cmd io ". Every op except a valid "run" sends its
// @IO answer before returning; a valid "run" fills `run` instead and the
// caller runs run.code inside a RunScope.
void handleCommand(const std::string &json, const Workspace &globals, RunRequest &run);

// Around the execution of a run request: copies what is written to std::cerr
// (the error text for the answer) while still printing it, forwards I/O
// progress as @IOEV lines, and turns the IDE's Stop into a cancel of the
// reader. finish() sends the run's @IO answer.
class RunScope {
public:
  explicit RunScope(const RunRequest &run);
  ~RunScope();
  void finish(const Workspace &globals);

private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

} // namespace ide
} // namespace io
} // namespace nc

#endif // NC_IO_IDE_API_H
