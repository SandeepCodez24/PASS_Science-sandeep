// Read-only file mapping per OS - see io_sys_map.h.
#include "io_sys_map.h"

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#define NC_IO_MAP_WINDOWS 1
#elif defined(__unix__) || defined(__unix) || defined(__APPLE__) || defined(__linux__)
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#define NC_IO_MAP_POSIX 1
#endif

#include <cstddef>

namespace nc {
namespace io {

bool sysMapFile(const std::filesystem::path &path, uint64_t size, SysMapping &m) {
  m = SysMapping();
  if (size == 0 || size > static_cast<uint64_t>(SIZE_MAX))
    return false;
#if defined(NC_IO_MAP_WINDOWS)
  HANDLE f = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr,
                         OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (f == INVALID_HANDLE_VALUE)
    return false;
  HANDLE h = CreateFileMappingW(f, nullptr, PAGE_READONLY, 0, 0, nullptr);
  CloseHandle(f); // the mapping keeps the file open
  if (!h)
    return false;
  void *at = MapViewOfFile(h, FILE_MAP_READ, 0, 0, 0);
  if (!at) {
    CloseHandle(h);
    return false;
  }
  m.base = at;
  m.size = size;
  m.handle = h;
  return true;
#elif defined(NC_IO_MAP_POSIX)
  int fd = ::open(path.c_str(), O_RDONLY);
  if (fd < 0)
    return false;
  void *at = mmap(nullptr, static_cast<size_t>(size), PROT_READ, MAP_PRIVATE, fd, 0);
  ::close(fd); // the mapping keeps the file open
  if (at == MAP_FAILED)
    return false;
  m.base = at;
  m.size = size;
  return true;
#else
  (void)path;
  return false; // no mapping on this system: the caller reads the file
#endif
}

void sysUnmapFile(SysMapping &m) {
  if (!m.base)
    return;
#if defined(NC_IO_MAP_WINDOWS)
  UnmapViewOfFile(m.base);
  if (m.handle)
    CloseHandle(static_cast<HANDLE>(m.handle));
#elif defined(NC_IO_MAP_POSIX)
  munmap(m.base, static_cast<size_t>(m.size));
#endif
  m = SysMapping();
}

bool sysReplaceFile(const std::filesystem::path &from, const std::filesystem::path &to, std::string &err) {
#if defined(NC_IO_MAP_WINDOWS)
  if (MoveFileExW(from.c_str(), to.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
    return true;
  const DWORD code = GetLastError();
  err = "cannot replace '" + to.u8string() + "'" +
        (code == ERROR_ACCESS_DENIED || code == ERROR_SHARING_VIOLATION
             ? std::string(" (no permission, or the file is open elsewhere)")
             : " (Windows error " + std::to_string(code) + ")");
  return false;
#else
  std::error_code ec;
  std::filesystem::rename(from, to, ec); // rename() replaces atomically on POSIX
  if (!ec)
    return true;
  err = "cannot replace '" + to.u8string() + "': " + ec.message();
  return false;
#endif
}

unsigned long sysProcessId() {
#if defined(NC_IO_MAP_WINDOWS)
  return static_cast<unsigned long>(GetCurrentProcessId());
#elif defined(NC_IO_MAP_POSIX)
  return static_cast<unsigned long>(getpid());
#else
  return 0;
#endif
}

} // namespace io
} // namespace nc
