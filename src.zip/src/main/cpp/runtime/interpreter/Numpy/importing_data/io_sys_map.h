// Read-only memory mapping of a whole file - the only OS-specific code of
// the data I/O functions (moved here from io_common.cpp on 2026-11-14, as
// runtime/execution/parallel/sys_cpu.cpp keeps the CPU queries).
//
//   Windows        CreateFileMapping / MapViewOfFile
//   macOS, Linux,  POSIX open / mmap / munmap
//   BSD ...
//   anything else  no mapping: sysMapFile returns false and SourceBytes
//                  (io_common.h) reads the file into memory instead, so
//                  every reader still works, only without the paging gain.
#ifndef NC_IO_SYS_MAP_H
#define NC_IO_SYS_MAP_H

#include <cstdint>
#include <filesystem>
#include <string>

namespace nc {
namespace io {

struct SysMapping {
  void *base = nullptr;   // first byte of the file
  uint64_t size = 0;
  void *handle = nullptr; // Windows: the mapping object; unused elsewhere
};

// Maps the `size` bytes of `path` (size > 0). False = not mapped (the
// caller reads the file); never an error by itself.
bool sysMapFile(const std::filesystem::path &path, uint64_t size, SysMapping &m);
// Undoes sysMapFile; a no-op for an empty mapping.
void sysUnmapFile(SysMapping &m);

// Atomic saves (2026-11-17, docs/Export_Window.md): a writer writes
// `<name>.part~<pid>` and this moves it over the target in one step -
// MoveFileExW(MOVEFILE_REPLACE_EXISTING) on Windows, rename() on POSIX.
// The old file stays whole until the new one is complete.
bool sysReplaceFile(const std::filesystem::path &from, const std::filesystem::path &to, std::string &err);
// This process's id (part of the temporary file's name).
unsigned long sysProcessId();

} // namespace io
} // namespace nc

#endif // NC_IO_SYS_MAP_H
