// SQLite 3 database files, read and written directly (no SQLite library):
// table / index B-trees, records, overflow pages, sqlite_master schema.
#ifndef NC_IO_SQLITE_H
#define NC_IO_SQLITE_H

#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct DbColumn {
  std::string name, type;
  bool pk = false, notNull = false, rowidAlias = false;
  std::string references; // "other(col)"
};

// A PRIMARY KEY or UNIQUE constraint of a table, in the order its CREATE
// TABLE declares them. SQLite backs each one - except an INTEGER PRIMARY KEY,
// which is the rowid itself - with an automatic index named
// sqlite_autoindex_<table>_<n>, n counting from 1 in this order; a file
// without those indexes is "malformed" to SQLite.
struct DbKey {
  bool pk = false;
  bool rowid = false; // the INTEGER PRIMARY KEY: no index of its own
  std::vector<std::string> cols;
};

struct DbTable {
  std::string name, sql, comment;
  std::vector<DbColumn> cols;
  std::vector<DbKey> keys; // filled by parseCreateTable()
  std::vector<std::vector<Value>> rows;
  std::vector<int64_t> rowids;
  std::vector<std::pair<std::string, std::vector<std::string>>> indexes; // index name, columns
};

struct DbFile {
  std::vector<DbTable> tables;
  std::vector<std::pair<std::string, std::string>> views;  // name, sql
  std::vector<std::string> otherSql;                       // triggers
};

bool readSqlite(const std::string &bytes, DbFile &db, std::string &err, bool loadRows = true);
std::string writeSqlite(const DbFile &db);
// CREATE TABLE text -> columns (also used for server schemas).
void parseCreateTable(const std::string &sql, DbTable &t);
std::string createTableSql(const DbTable &t);
// The PRIMARY KEY / UNIQUE constraints of t as it will be written (its sql,
// or createTableSql(t) when it has none).
std::vector<DbKey> tableKeys(const DbTable &t);

} // namespace io
} // namespace nc

#endif // NC_IO_SQLITE_H
