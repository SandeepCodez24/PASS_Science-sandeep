// CATEGORY 3 - read_/load_/save_ parquet, feather, orc (shared front end).
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <iostream>
#include <map>
#include <set>

#include "../numpy_common.h"
#include "io_columnar.h"
#include "io_formats.h"
#include "io_sql.h"
#include "parallel/par.h"

namespace nc {
namespace io {
namespace {

namespace fs = std::filesystem;

bool decode(const std::string &fmt, std::string_view bytes, const ColReadOptions &o, ColFile &f, std::string &err) {
  if (fmt == "parquet") return readParquet(bytes, o, f, err);
  if (fmt == "feather") return readArrowIpc(bytes, o, f, err);
  return readOrc(bytes, o, f, err);
}

std::string encode(const std::string &fmt, const Table &t, const ColWriteOptions &o, std::string &err) {
  if (fmt == "parquet") return writeParquet(t, o, err);
  if (fmt == "feather") return writeArrowIpc(t, o, err);
  return writeOrc(t, o, err);
}

// "year=2024" directory names of a Hive-partitioned dataset
std::vector<std::pair<std::string, std::string>> partitionsOf(const fs::path &root, const fs::path &file) {
  std::vector<std::pair<std::string, std::string>> out;
  auto appendPartition = [&](const fs::path &part) {
    std::string s = part.string();
    size_t eq = s.find('=');
    if (eq != std::string::npos) out.push_back({s.substr(0, eq), s.substr(eq + 1)});
  };
  appendPartition(root.lexically_normal().filename());
  fs::path rel = fs::relative(file.parent_path(), root);
  for (const auto &part : rel) {
    appendPartition(part);
  }
  return out;
}

// a file, or a directory of files (Hive partitions become columns)
bool openColumnar(const std::string &fmt, const std::string &path, const ColReadOptions &o, ColFile &f, std::string &err) {
  std::error_code ec;
  const fs::path resolved = resolvePath(path);
  if (!isUrl(path) && fs::is_directory(resolved, ec)) {
    std::vector<fs::path> files;
    for (auto it = fs::recursive_directory_iterator(resolved, ec); it != fs::recursive_directory_iterator(); ++it)
      if (it->is_regular_file() && lower(it->path().extension().string()) == "." + fmt) files.push_back(it->path());
    std::sort(files.begin(), files.end());
    if (files.empty()) { err = "the folder has no ." + fmt + " files"; return false; }
    bool first = true;
    // the files' cells, appended column by column (column form, §9)
    std::vector<Value::ColumnBuilder> builders;
    size_t nrows = 0;
    for (const auto &p : files) {
      std::string bytes;
      if (!readFile(p.string(), bytes, err)) return false;
      ColFile part;
      ColReadOptions po = o;
      auto parts = partitionsOf(resolved, p);
      po.cols.erase(std::remove_if(po.cols.begin(), po.cols.end(), [&](const std::string &c) { for (auto &kv : parts) if (kv.first == c) return true; return false; }), po.cols.end());
      if (!decode(fmt, bytes, po, part, err)) { err = p.string() + ": " + err; return false; }
      const size_t dataCols = part.table.cols.size(), n = part.table.rowCount();
      std::vector<Value> partValues;
      for (const auto &kv : parts) {
        part.table.cols.push_back(kv.first);
        part.types.push_back("str");
        partValues.push_back(parseCell(kv.second, {}));
        for (auto &g : part.groups) g.stats.push_back(ColStats());
      }
      if (!first && part.table.cols != f.table.cols) { err = p.string() + ": its columns differ from the first file's"; return false; }
      if (first) builders.resize(part.table.cols.size());
      for (size_t c = 0; c < builders.size(); c++)
        for (size_t r = 0; r < n; r++)
          builders[c].push(c < dataCols ? part.table.cell(r, c) : partValues[c - dataCols]);
      nrows += n;
      part.table.rows.clear();
      part.table.data = Value();
      if (first) { f = part; first = false; continue; }
      for (auto &g : part.groups) f.groups.push_back(std::move(g));
      f.totalRows += part.totalRows;
    }
    std::vector<std::shared_ptr<Value::Column>> cols;
    for (auto &b : builders) cols.push_back(b.finish());
    tableFromColumns(f.table, std::move(cols), nrows);
    f.format += " dataset (" + std::to_string(files.size()) + " files)";
    return true;
  }
  // Mapped, not read: the decoder touches the footer and the column chunks
  // it needs, so cols= / groups= / rows= on a 200 GB file read only those.
  SourceBytes src;
  if (!src.open(path, err)) return false;
  return decode(fmt, src.view(), o, f, err);
}

// rows= as a window of file rows, so the readers skip whole row groups.
// Only when nothing else decides which rows are kept (groups=, where=, a
// folder dataset). A footer-only pass gives the row count for "10:" / -1.
// `local` receives the rows= option rewritten for the rows actually read.
bool rowWindow(const std::string &fmt, const std::string &path, const Value &rows, ColReadOptions &o,
               Value &local, std::string &err) {
  local = rows;
  if (!given(rows) || !o.groups.empty() || o.pushdown.active) return true;
  std::error_code ec;
  if (isUrl(path) || fs::is_directory(resolvePath(path), ec)) return true;
  Selector sel;
  if (!parseSelector(rows, sel, err)) return false;
  if (!sel.names.empty()) return true; // selectTable gives the error
  ColReadOptions meta = o;
  meta.metaOnly = true;
  ColFile head;
  if (!openColumnar(fmt, path, meta, head, err)) { err.clear(); return true; }
  std::vector<size_t> idx;
  Selector clipped = sel;
  clipped.positions.clear();
  for (long long p : sel.positions)
    if (p >= 1 && p <= static_cast<long long>(head.totalRows)) clipped.positions.push_back(p);
  clipped.all = false;
  if (!resolveSelector(clipped, {}, head.totalRows, idx, err)) return false;
  if (idx.empty()) { o.rowFirst = 1; o.rowLast = 0; local = rows; return true; }
  o.rowFirst = *std::min_element(idx.begin(), idx.end());
  o.rowLast = *std::max_element(idx.begin(), idx.end());
  // the positions again, now counted from the first row read
  std::vector<double> rel;
  rel.reserve(idx.size());
  for (size_t i : idx) rel.push_back(static_cast<double>(i - o.rowFirst + 1));
  local = numpy::makeArray(rel);
  return true;
}

// [0, 2] (0-based, as in the PDF) or 1-based positions; a 0 anywhere means 0-based
bool groupList(const Value &v, std::vector<size_t> &out, std::string &err) {
  out.clear();
  if (!given(v)) return true;
  std::vector<double> n = optNumbers(v);
  bool zero = std::find(n.begin(), n.end(), 0.0) != n.end();
  for (double d : n) {
    if (d < 0 || d != std::floor(d)) { err = "groups must be whole numbers"; return false; }
    if (!zero && d < 1) { err = "groups are numbered from 1 (or from 0 when a 0 is given)"; return false; }
    out.push_back(static_cast<size_t>(zero ? d : d - 1));
  }
  return true;
}

Value statsDict(const ColStats &s) {
  Fields f;
  f["min"] = s.hasMin ? s.min : Value(std::nan(""));
  f["max"] = s.hasMax ? s.max : Value(std::nan(""));
  f["null_count"] = Value(s.nulls);
  f["distinct_count"] = Value(s.distinct);
  return Value(f);
}

ColStats merge(const ColStats &a, const ColStats &b) {
  ColStats m = a;
  auto less = [](const Value &x, const Value &y) { return x.isText || y.isText ? cellText(x) < cellText(y) : x.number < y.number; };
  if (b.hasMin && (!m.hasMin || less(b.min, m.min))) { m.min = b.min; m.hasMin = true; }
  if (b.hasMax && (!m.hasMax || less(m.max, b.max))) { m.max = b.max; m.hasMax = true; }
  m.nulls = a.nulls < 0 || b.nulls < 0 ? -1 : a.nulls + b.nulls;
  m.distinct = -1;
  return m;
}

std::vector<std::string> boxesOf(const ColFile &f) {
  std::vector<std::string> out;
  for (const auto &kv : f.kv) {
    if (kv.first == "ARROW:schema" || kv.first == "pandas" || kv.second.size() > 2000) continue;
    out.push_back(kv.first + ": " + kv.second);
  }
  return out;
}

Value kvDict(const ColFile &f) {
  Fields d;
  for (const auto &kv : f.kv) d[kv.first] = Value(kv.second);
  return Value(d);
}

Value schemaDict(const ColFile &f) {
  Fields root;
  for (size_t c = 0; c < f.table.cols.size(); c++) {
    // nested "a.b.c" -> {a: {b: {c: type}}}
    std::vector<std::string> parts;
    size_t s = 0;
    const std::string &n = f.table.cols[c];
    while (s <= n.size()) { size_t e = n.find('.', s); if (e == std::string::npos) e = n.size(); parts.push_back(n.substr(s, e - s)); s = e + 1; }
    std::function<void(Fields &, size_t)> put = [&](Fields &into, size_t k) {
      if (k + 1 == parts.size()) { into[parts[k]] = Value(f.types[c]); return; }
      Fields sub = into.count(parts[k]) && into[parts[k]].isDict ? Fields(into[parts[k]].dict().begin(), into[parts[k]].dict().end()) : Fields();
      put(sub, k + 1);
      into[parts[k]] = Value(sub);
    };
    put(root, 0);
  }
  return Value(root);
}

// read_<fmt>(file, cols, groups, where, rows, mmap, threads, box)
void readCol(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  // threads=n (n >= 1): the cores for this read only (row groups / stripes
  // are decompressed with nc::par); the count is put back afterwards. The
  // result is the same for any n.
  struct ThreadScope {
    int previous = 0;
    ~ThreadScope() { if (previous > 0) nc::par::setThreadCount(previous); }
  } threadScope;
  {
    const long long n = optInt(a[6], -1);
    if (n >= 1) threadScope.previous = nc::par::setThreadCount(static_cast<int>(std::min<long long>(n, 1024)));
  }
  ColReadOptions o;
  o.cols = optTextList(a[1]);
  if (!groupList(a[2], o.groups, err)) return ctx.fail(err);
  std::string where = optText(a[3]);
  if (!where.empty()) o.pushdown = parsePushdown(where);
  Value rows = a[4];
  if (where.empty() && !rowWindow(fmt, file, a[4], o, rows, err)) return ctx.fail(err);
  ColFile f;
  if (!openColumnar(fmt, file, o, f, err)) return ctx.fail(err);
  // the window was applied: shift the rows the reader skipped
  if (o.rowFirst > 0 && f.rowOffset != o.rowFirst && given(rows) && !rows.isText) {
    std::vector<double> shifted;
    for (double p : optNumbers(rows)) shifted.push_back(p + static_cast<double>(o.rowFirst) - static_cast<double>(f.rowOffset));
    rows = numpy::makeArray(shifted);
  }
  for (size_t g : o.groups) if (g >= f.groups.size()) return ctx.fail("group " + std::to_string(g) + " does not exist (the file has " + std::to_string(f.groups.size()) + ")");
  Table &t = f.table;
  if (!o.cols.empty()) { // keep the order the user asked for
    Table s;
    for (const auto &c : o.cols) for (size_t k = 0; k < t.cols.size(); k++) if (t.cols[k] == c || t.cols[k].rfind(c + ".", 0) == 0) s.cols.push_back(t.cols[k]);
    std::vector<size_t> idx;
    for (const auto &c : s.cols) idx.push_back(static_cast<size_t>(std::find(t.cols.begin(), t.cols.end(), c) - t.cols.begin()));
    std::vector<size_t> all(t.rowCount());
    for (size_t r = 0; r < all.size(); r++) all[r] = r;
    t = tableTake(t, all, idx);
  }
  if (!where.empty()) {
    std::vector<size_t> keep;
    if (!sqlFilter(t, where, {}, keep, err)) return ctx.fail("where: " + err);
    tableKeepRows(t, keep);
  }
  if (given(rows) && !selectTable(t, Value(std::string()), rows, err)) return ctx.fail(err);
  out.push_back(tableData(t));
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(t.cols);
    info["schema"] = tableSchema(t);
    info["types"] = textList(f.types);
    info["rows"] = Value(static_cast<double>(t.rowCount()));
    info["total_rows"] = Value(static_cast<double>(f.totalRows));
    info["groups"] = Value(static_cast<double>(f.groups.size()));
    info["codec"] = Value(f.codec);
    info["format"] = Value(f.format);
    info["created_by"] = Value(f.createdBy);
    info["kv_meta"] = kvDict(f);
    info["skipped"] = textList(f.skipped);
    info["boxes"] = optBool(a[7], true) ? textList(boxesOf(f)) : textList({});
    out.push_back(makeObject("NcReadInfo", info));
  }
  ev.ok = true;
}

Value loadCol(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  ColReadOptions o;
  ColFile f;
  if (!openColumnar(fmt, file, o, f, err)) { ctx.fail(err); return Value(0.0); }
  Fields extra;
  // The table object once: D.default is it, and D has its fields plus the
  // ones below (copies share the columns - nothing is made twice).
  const Value base = tableObject(f.table);
  extra["default"] = base;
  extra["schema"] = schemaDict(f);
  extra["types"] = textList(f.types);
  std::vector<Value> groups;
  std::vector<ColStats> total(f.table.cols.size());
  for (size_t g = 0; g < f.groups.size(); g++) {
    const ColGroup &cg = f.groups[g];
    Fields gf, st;
    for (size_t c = 0; c < f.table.cols.size() && c < cg.stats.size(); c++) {
      st[f.table.cols[c]] = statsDict(cg.stats[c]);
      total[c] = g == 0 ? cg.stats[c] : merge(total[c], cg.stats[c]);
    }
    gf["index"] = Value(static_cast<double>(g));
    gf["rows"] = Value(static_cast<double>(cg.rows));
    gf["bytes"] = Value(static_cast<double>(cg.bytes));
    gf["stats"] = Value(st);
    groups.push_back(makeObject("NcRowGroup", gf));
  }
  extra["groups"] = Value(std::move(groups));
  Fields stats;
  for (size_t c = 0; c < f.table.cols.size(); c++) stats[fieldName(f.table.cols[c])] = statsDict(total[c]);
  extra["stats"] = Value(stats);
  extra["kv_meta"] = kvDict(f);
  extra["boxes"] = textList(boxesOf(f));
  extra["file"] = Value(file);
  extra["format"] = Value(f.format);
  extra["codec"] = Value(f.codec);
  extra["created_by"] = Value(f.createdBy);
  extra["skipped"] = textList(f.skipped);
  Fields own(base.dict().begin(), base.dict().end());
  for (auto &kv : extra) own[kv.first] = std::move(kv.second);
  Value obj = makeObject(fmt == "parquet" ? "NcParquet" : fmt == "feather" ? "NcFeather" : "NcOrc", std::move(own));
  // nested struct columns: D.user.address.city
  Fields fields(obj.dict().begin(), obj.dict().end());
  for (size_t c = 0; c < f.table.cols.size(); c++) {
    const std::string &n = f.table.cols[c];
    if (n.find('.') == std::string::npos) continue;
    std::vector<std::string> parts;
    size_t s = 0;
    while (s <= n.size()) { size_t e = n.find('.', s); if (e == std::string::npos) e = n.size(); parts.push_back(fieldName(n.substr(s, e - s))); s = e + 1; }
    std::function<Value(const Value *, size_t)> put = [&](const Value *node, size_t k) -> Value {
      if (k == parts.size()) return tableColumn(f.table, c);
      Fields sub;
      if (node && node->isObject) sub = Fields(node->dict().begin(), node->dict().end());
      const Value *child = sub.count(parts[k]) ? &sub[parts[k]] : nullptr;
      Value v = put(child, k + 1);
      sub[parts[k]] = v;
      return makeObject("NcStruct", sub);
    };
    const Value *top = fields.count(parts[0]) && fields[parts[0]].isObject ? &fields[parts[0]] : nullptr;
    Fields holder;
    Value built = put(top, 1);
    fields[parts[0]] = built;
  }
  ev.ok = true;
  return makeObject(obj.className(), fields);
}

// save_<fmt>(file, data, compress, level, group_rows, part_by, dict_enc, boxes, max_size, split_size)
Value saveCol(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  Table t;
  if (!valueToTable(a[1], t, err, true, true)) return fail(err); // a big table stays in column form
  if (t.cols.empty()) return fail("nothing to save - the data has no columns");
  // mixed literals keep numbers as text; a column of number-like text is numeric
  const size_t nrows = t.rowCount();
  auto setCell = [&](size_t r, size_t c, const Value &x) { if (t.columnar) t.data.setAt(r, c, x); else t.rows[r][c] = x; };
  for (size_t c = 0; c < t.cols.size(); c++) {
    if (t.columnar && t.data.isColumnar()) { // only a column holding text can change
      const Value::Column &col = t.data.column(c);
      bool anyText = col.kind == Value::Column::Kind::Text || col.kind == Value::Column::Kind::Cells;
      for (const Value &x : col.excVals) anyText = anyText || x.isText;
      if (!anyText) continue;
    } else if (t.columnar) {
      continue; // packed numbers: no text
    }
    bool all = true, any = false;
    for (size_t r = 0; r < nrows; r++) {
      const Value cell = t.cell(r, c);
      if (!cell.isText) continue;
      char *e = nullptr;
      const std::string &s = cell.text();
      std::strtod(s.c_str(), &e);
      if (s.empty() || !e || *e) { all = false; break; }
      any = true;
    }
    if (any && all)
      for (size_t r = 0; r < nrows; r++) { const Value cell = t.cell(r, c); if (cell.isText) setCell(r, c, Value(std::strtod(cell.text().c_str(), nullptr))); }
    bool bools = true, anyB = false; // "true" / "false" text -> booleans
    for (size_t r = 0; r < nrows; r++) { const Value cell = t.cell(r, c); if (!cell.isText) { if (!std::isnan(cell.number) && !cell.isBool()) bools = false; continue; } std::string s = lower(cell.text()); if (s != "true" && s != "false") { bools = false; break; } anyB = true; }
    if (bools && anyB)
      for (size_t r = 0; r < nrows; r++) { const Value cell = t.cell(r, c); if (cell.isText) setCell(r, c, Value::boolean(lower(cell.text()) == "true")); }
  }
  ColWriteOptions o;
  o.codec = lower(optText(a[2], "zstd"));
  if (o.codec == "no" || o.codec.empty() || o.codec == "uncompressed") o.codec = "none";
  if (o.codec == "yes") o.codec = "zstd";
  o.level = static_cast<int>(optInt(a[3], 5));
  long long gr = optInt(a[4], -1);
  if (gr == 0 || gr < -1) return fail("group_rows must be 1 or more");
  o.groupRows = gr > 0 ? static_cast<size_t>(gr) : 0;
  o.dictEnc = optBool(a[6], true);
  if (given(a[7])) {
    if (a[7].isDict) {
      std::vector<std::string> keys;
      for (const auto &kv : a[7].dict()) keys.push_back(kv.first);
      std::sort(keys.begin(), keys.end());
      for (const auto &k : keys) o.kv.push_back({k, cellText(a[7].dict().at(k))});
    } else {
      std::vector<std::string> bx = optTextList(a[7]);
      for (size_t i = 0; i < bx.size(); i++) o.kv.push_back({bx.size() == 1 ? "note" : "box_" + std::to_string(i + 1), bx[i]});
    }
  }
  std::vector<std::string> partBy = optTextList(a[5]);
  uint64_t total = 0;
  // E6 (2026-11-17): every row group / batch / stripe goes to the file as soon
  // as it is encoded (FileSink) - the encoded table is never held whole.
  auto writeOne = [&](const std::string &path, const Table &part) -> bool {
    std::error_code ec;
    fs::path pp(path);
    if (pp.has_parent_path()) fs::create_directories(pp.parent_path(), ec);
    FileSink sink;
    if (!sink.open(path, false, err)) return false;
    ColWriteOptions so = o;
    so.sink = [&sink](std::string &bytes, std::string &e) { return sink.write(bytes, e); };
    std::string tail = encode(fmt, part, so, err);
    if (!err.empty() || !sink.write(tail, err) || !sink.close(err)) return false;
    total += sink.bytes();
    return true;
  };
  std::vector<std::pair<std::string, Table>> parts;
  if (!partBy.empty()) { // Hive partitions: <file>/<col>=<value>/part-00000.<fmt>
    std::vector<size_t> pidx;
    for (const auto &p : partBy) {
      auto it = std::find(t.cols.begin(), t.cols.end(), p);
      if (it == t.cols.end()) return fail("part_by: no column '" + p + "'");
      pidx.push_back(static_cast<size_t>(it - t.cols.begin()));
    }
    // the rows of each partition (directory order), then those rows of the
    // other columns - per column, no row of Values
    std::vector<size_t> rest;
    for (size_t c = 0; c < t.cols.size(); c++) if (std::find(pidx.begin(), pidx.end(), c) == pidx.end()) rest.push_back(c);
    std::map<std::string, std::vector<size_t>> groups;
    for (size_t r = 0; r < t.rowCount(); r++) {
      std::string dir = file;
      for (size_t k = 0; k < pidx.size(); k++) dir += "/" + t.cols[pidx[k]] + "=" + cellText(t.cell(r, pidx[k]));
      groups[dir].push_back(r);
    }
    for (auto &kv : groups) parts.push_back({kv.first + "/part-00000." + fmt, tableTake(t, kv.second, rest)});
  } else parts.push_back({file, t});
  // E10 (2026-11-17): split_size= writes the parts. max_size= used to split
  // here too (the other writers treat it as a size limit): alone it still
  // splits, with a warning; next to split_size= it is the limit of the whole.
  uint64_t budget = 0, limit = 0;
  if (given(a[9])) {
    if (!parseByteSize(optText(a[9]), budget) || budget == 0) return fail("split_size must be a size like \"256mb\"");
  }
  if (given(a[8])) {
    std::string ms = optText(a[8]);
    uint64_t m = 0;
    if (!parseByteSize(ms, m)) return fail("max_size must be a size like \"256mb\"");
    if (given(a[9])) {
      limit = m;
    } else {
      budget = m;
      std::cerr << "Warning: save_" << fmt << ": max_size= splits the table into parts here - write split_size= for "
                   "that (max_size= is a size limit in the other save_ functions)\n";
    }
  }
  std::vector<std::string> written;
  for (auto &p : parts) {
    if (budget) { // split into numbered files when the budget is exceeded
      std::string probe = encode(fmt, p.second, o, err);
      if (!err.empty()) return fail(err);
      const size_t prows = p.second.rowCount();
      if (probe.size() > budget && prows > 1) {
        size_t n = static_cast<size_t>((probe.size() + budget - 1) / budget);
        n = std::min(n, prows);
        size_t per = (prows + n - 1) / n;
        fs::path base(p.first);
        std::string stem = (base.parent_path() / base.stem()).string();
        std::vector<size_t> allCols(p.second.cols.size());
        for (size_t c = 0; c < allCols.size(); c++) allCols[c] = c;
        for (size_t k = 0, from = 0; from < prows; k++, from += per) {
          std::vector<size_t> range;
          for (size_t r = from; r < std::min(prows, from + per); r++) range.push_back(r);
          Table s = tableTake(p.second, range, allCols);
          char suffix[32];
          std::snprintf(suffix, sizeof suffix, "_part%03zu.", k + 1);
          std::string path = stem + suffix + fmt;
          if (!writeOne(path, s)) return fail(err);
          written.push_back(path);
        }
        continue;
      }
    }
    if (!writeOne(p.first, p.second)) return fail(err);
    written.push_back(p.first);
  }
  if (limit && total > limit)
    return fail("the output is " + formatBytes(total) + ", over max_size " + formatBytes(limit) +
                " (try compress=\"zstd\", fewer rows, or a larger max_size)");
  ev.ok = true;
  return Value(static_cast<double>(total));
}

} // namespace

void registerColumnar(Registry &reg) {
  for (const char *ext : {"parquet", "feather", "orc"}) {
    const std::string e = ext;
    std::string what = e == "parquet" ? "Apache Parquet" : e == "feather" ? "Feather v2 / Arrow IPC" : "Apache ORC";
    std::string origin = e == "parquet" ? "pyarrow.parquet.read_table" : e == "feather" ? "pyarrow.feather.read_table" : "pyarrow.orc.read_table";
    addMulti(reg, "read_" + e, "file, cols=\"\", groups=\"\", where=\"\", rows=\"\", mmap=true, threads=-1, box=true",
             "read a ." + e + " table (" + what + "); cols= reads only those columns, groups= only those row groups, where= filters rows", origin, 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readCol(e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file", "load a ." + e + " table with its schema, row-group statistics and key-value metadata (D.cols, D.stats.<col>, D.groups)",
          origin, [e](const std::vector<Value> &a, CallContext &ctx) { return loadCol(e, a, ctx); });
    addFn(reg, "save_" + e,
          "file, data, compress=\"zstd\", level=5, group_rows=-1, part_by=\"\", dict_enc=true, boxes=\"\", max_size=\"\", split_size=\"\"",
          "write a table as ." + e + " (zstd / snappy / lz4 / gzip; part_by= writes Hive folders; boxes= go to the footer metadata)",
          e == "parquet" ? "pyarrow.parquet.write_table" : e == "feather" ? "pyarrow.feather.write_feather" : "pyarrow.orc.write_table",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveCol(e, a, ctx); });
  }
}

} // namespace io
} // namespace nc
