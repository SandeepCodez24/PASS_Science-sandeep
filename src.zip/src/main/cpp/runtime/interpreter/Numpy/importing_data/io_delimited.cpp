// CATEGORY 2 - delimited text: read_/load_/save_ csv, tsv, txt, dat.
//
// One tokenizer serves all four (they differ only in the default delimiter):
//   - RFC 4180 quoting ("a,b" and "" inside quotes, fields over several lines)
//   - comment lines (cmt="#"), kept with their line numbers
//   - virtual sheets: a line "# [Sheet: ABC]" (sec_fmt) starts section ABC
//   - the table block of a section is the longest run of rows with the
//     usual field count; the lines before/after it are "boxes" (free text
//     such as "Project: Agni") returned beside the data
//
// Memory (2026-11-14): a UTF-8 / ASCII file that is not gzip is tokenized
// straight from the memory-mapped file (SourceBytes) - no copy of the text
// is made. Record::raw and Parsed::rawLines are views into that text (or into
// the one decoded copy for other encodings), so a big file is held once as
// text, plus its fields and the values.
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <map>
#include <memory>
#include <string_view>

#include "../numpy_common.h"
#include "parallel/par.h"
#include "parallel/sys_cpu.h"
#include <cstdio>
#include "io_common.h"
#include "io_deflate.h"
#include "io_formats.h"

namespace nc {
namespace io {
namespace {

// A record keeps only where it is and how many fields it has (2026-11-15):
// its fields are split again from `raw` when they are needed (fieldsOf(),
// forEachField()), so a big file is never held as one std::string per field.
struct Record {
  std::string_view raw; // the record's text, a view into Parsed's text
  size_t line = 0;
  size_t nfields = 0;
};

struct Section {
  std::string name;
  std::vector<Record> records; // blank lines kept as records with no fields
};

struct Parsed {
  std::vector<Section> sections;
  std::vector<std::pair<size_t, std::string>> comments;
  std::vector<std::string_view> rawLines;
  std::string dlm; // the delimiter actually used ("ws" = runs of blanks)
  // What the views point into: the mapped file, or the decoded text. Held
  // through shared_ptr so the views stay valid when a Parsed is moved.
  std::shared_ptr<SourceBytes> mapped;
  std::shared_ptr<std::string> owned;
  bool cancelled = false; // Stop during tokenize: the records are incomplete
};

std::string trimView(std::string_view s) { return trim(std::string(s)); }

const std::vector<std::string> kDefaultNa = {"", "NA", "N/A", "NULL", "null", "NaN", "nan"};

// "\s+", "\\s+", "whitespace" -> "ws"; "\t", "tab" -> "\t"; "auto" stays.
std::string normalizeDelimiter(const std::string &d) {
  std::string l = lower(d);
  if (l == "\\s+" || l == "\\\\s+" || l == "s+" || l == "whitespace" || l == "space" || l == "ws" ||
      l == " " || l == "\\s")
    return "ws";
  if (l == "\\t" || l == "\\\\t" || l == "tab" || l == "\t")
    return "\t";
  if (l == "auto" || l.empty())
    return "auto";
  return d;
}

// Splits one physical line (no quotes spanning lines) - used for sniffing.
size_t quickCount(const std::string &line, const std::string &dlm) {
  size_t n = 1;
  bool q = false;
  for (size_t i = 0; i < line.size(); i++) {
    if (line[i] == '"')
      q = !q;
    else if (!q && line.compare(i, dlm.size(), dlm) == 0)
      n++;
  }
  return n;
}

std::string sniffDelimiter(std::string_view text, const std::string &cmt) {
  std::vector<std::string> lines;
  size_t start = 0;
  while (start < text.size() && lines.size() < 40) {
    size_t e = text.find('\n', start);
    if (e == std::string::npos)
      e = text.size();
    std::string l = trimView(text.substr(start, e - start));
    if (!l.empty() && (cmt.empty() || l.rfind(cmt, 0) != 0))
      lines.push_back(l);
    start = e + 1;
  }
  std::string best = "ws";
  size_t bestScore = 0;
  for (const char *cand : {",", "\t", ";", "|"}) {
    std::map<size_t, size_t> freq;
    for (const auto &l : lines)
      freq[quickCount(l, cand)]++;
    for (const auto &kv : freq)
      if (kv.first > 1 && kv.second * (kv.first > 1) > bestScore) {
        bestScore = kv.second;
        best = cand;
      }
  }
  return bestScore >= 1 ? best : "ws";
}

// Section marker from sec_fmt ("# [Sheet: {name}]") -> prefix/suffix.
// `s` without leading / trailing blanks (isspace, as trim()), no copy.
std::string_view trimmedView(std::string_view s) {
  size_t b = 0, e = s.size();
  while (b < e && asciiSpace(s[b]))
    b++;
  while (e > b && asciiSpace(s[e - 1]))
    e--;
  return s.substr(b, e - b);
}

// A section marker line ("# [Sheet: {name}]"): the parts of sec_fmt before
// and after {name}, split once per file.
struct MarkerFormat {
  bool any = false;
  std::string pre, post;
  explicit MarkerFormat(const std::string &secFmt) {
    const size_t at = secFmt.find("{name}");
    if (at == std::string::npos)
      return;
    any = true;
    pre = secFmt.substr(0, at);
    post = secFmt.substr(at + 6);
  }
};

// `line` is trimmed already.
bool matchMarker(std::string_view l, const MarkerFormat &mf, std::string &name) {
  if (!mf.any || l.size() < mf.pre.size() + mf.post.size() || l.compare(0, mf.pre.size(), mf.pre) != 0 ||
      l.compare(l.size() - mf.post.size(), mf.post.size(), mf.post) != 0)
    return false;
  name = std::string(trimmedView(l.substr(mf.pre.size(), l.size() - mf.pre.size() - mf.post.size())));
  return !name.empty();
}

// Splits the record starting at text[i] into fields (RFC 4180 quoting; a
// quoted field may run over line ends), calling onField(std::string_view)
// for each. Stops at the end of the record's last line (i then points at
// the '\n' / '\r' / end); counts the line ends inside quotes in `line`.
template <typename OnField>
void splitRecord(std::string_view text, size_t &i, const std::string &dlm, bool ws, size_t &line, OnField onField) {
  thread_local std::string fieldText;
  fieldText.clear();
  bool inField = false, quoted = false;
  // An unquoted field is a view into the text; only a quoted one is copied.
  size_t viewStart = std::string_view::npos;
  auto emit = [&]() {
    if (viewStart != std::string_view::npos && !quoted)
      onField(text.substr(viewStart, i - viewStart));
    else
      onField(std::string_view(fieldText));
    fieldText.clear();
    viewStart = std::string_view::npos;
  };
  bool copied = false; // the current field went through fieldText
  // a one-character delimiter (the usual case): compared as a char, and an
  // unquoted field is run over in one tight loop
  const char d1 = !ws && dlm.size() == 1 && dlm[0] != '"' ? dlm[0] : '\0';
  while (i < text.size()) {
    char c = text[i];
    if (quoted) {
      if (c == '"') {
        if (i + 1 < text.size() && text[i + 1] == '"') {
          fieldText.push_back('"');
          i += 2;
          continue;
        }
        quoted = false;
        i++;
        continue;
      }
      if (c == '\n')
        line++;
      fieldText.push_back(c);
      i++;
      continue;
    }
    if (c == '\n' || c == '\r') {
      break;
    }
    if (ws ? (c == ' ' || c == '\t') : d1 ? c == d1 : text.compare(i, dlm.size(), dlm) == 0) {
      if (ws) {
        if (inField) {
          if (copied) { viewStart = std::string_view::npos; }
          emit();
          copied = false;
          inField = false;
        }
        i++;
        continue;
      }
      if (copied) viewStart = std::string_view::npos;
      emit();
      copied = false;
      inField = false;
      i += dlm.size();
      if (i >= text.size() || text[i] == '\n' || text[i] == '\r') {
        fieldText.clear();
        onField(std::string_view()); // trailing delimiter = empty last field
      }
      continue;
    }
    if (c == '"' && !inField && fieldText.empty() && viewStart == std::string_view::npos) {
      quoted = true;
      inField = true;
      copied = true;
      i++;
      continue;
    }
    if (copied) {
      fieldText.push_back(c);
    } else {
      if (viewStart == std::string_view::npos)
        viewStart = i;
      if (d1) { // to the field's end ('"' inside an unquoted field is text)
        const char *q = text.data() + i + 1, *const qe = text.data() + text.size();
        while (q < qe && *q != d1 && *q != '\n' && *q != '\r')
          q++;
        i = static_cast<size_t>(q - text.data());
        inField = true;
        continue;
      }
    }
    inField = true;
    i++;
  }
  if (inField || !fieldText.empty()) { // fields stay verbatim; cells are trimmed when parsed
    if (copied) viewStart = std::string_view::npos;
    emit();
  }
}

// The fields of a record, split again from its text.
std::vector<std::string> fieldsOf(const Record &r, const std::string &dlm) {
  std::vector<std::string> out;
  if (r.nfields == 0)
    return out;
  out.reserve(r.nfields);
  size_t i = 0, line = 0;
  splitRecord(r.raw, i, dlm, dlm == "ws", line, [&](std::string_view f) { out.emplace_back(f); });
  return out;
}

template <typename OnField> void forEachField(const Record &r, const std::string &dlm, OnField onField) {
  if (r.nfields == 0)
    return;
  size_t i = 0, line = 0;
  splitRecord(r.raw, i, dlm, dlm == "ws", line, onField);
}

// The lines of text[begin .. end) (begin at the start of a line), as tokenize()
// reads them - section markers, comments, blank lines, records (a quoted field
// may run over line ends, and past `end`). Line numbers are counted from 0 at
// `begin` (the caller adds the line `begin` is on). `stop`: where the next line
// starts - past `end` when the last record ran over it (2026-11-15: chunks of a
// big file are scanned on several cores; see tokenize()).
struct LineScan {
  std::vector<std::pair<std::string, std::vector<Record>>> segs{{std::string(), {}}}; // [0]: before any marker here
  std::vector<std::pair<size_t, std::string>> comments;
  std::vector<std::string_view> rawLines;
  size_t stop = 0;
};

void scanLines(std::string_view text, size_t begin, size_t end, const std::string &dlm, bool ws, const std::string &cmt,
               const MarkerFormat &markerFormat, LineScan &out) {
  size_t i = begin, line = 0;
  while (i < end) {
    size_t lineEnd = text.find('\n', i);
    if (lineEnd == std::string::npos)
      lineEnd = text.size();
    std::string_view physical = text.substr(i, lineEnd - i);
    if (!physical.empty() && physical.back() == '\r')
      physical.remove_suffix(1);
    const std::string_view t = trimmedView(physical); // (a view: no copy per line)
    std::string marker;
    if (matchMarker(t, markerFormat, marker)) {
      out.rawLines.push_back(physical);
      out.segs.push_back({marker, {}});
      i = lineEnd + 1;
      line++;
      continue;
    }
    if (!cmt.empty() && t.rfind(cmt, 0) == 0) {
      out.rawLines.push_back(physical);
      out.comments.push_back({line, std::string(physical)});
      i = lineEnd + 1;
      line++;
      continue;
    }
    Record rec;
    rec.line = line;
    if (t.empty()) {
      rec.raw = physical;
      out.rawLines.push_back(physical);
      out.segs.back().second.push_back(rec);
      i = lineEnd + 1;
      line++;
      continue;
    }
    // One record - quoted fields may run over line ends.
    size_t recStart = i;
    splitRecord(text, i, dlm, ws, line, [&](std::string_view) { rec.nfields++; });
    size_t e = text.find('\n', i);
    if (e == std::string::npos)
      e = text.size();
    rec.raw = text.substr(recStart, e - recStart);
    if (!rec.raw.empty() && rec.raw.back() == '\r')
      rec.raw.remove_suffix(1);
    out.rawLines.push_back(rec.raw);
    out.segs.back().second.push_back(std::move(rec));
    i = e + 1;
    line++;
  }
  out.stop = i;
}

// `text` must outlive `p` (it is p.mapped / p.owned): records keep views.
//
// A big file (2026-11-15) is cut into chunks at line starts and every chunk is
// scanned on its own core (scanLines). A chunk assumes it starts at a record:
// wrong only when a quoted field runs over the cut - then the chunk before it
// stopped past its end, and this one is scanned again from there (on this
// thread; rare). The chunks are joined in order, line numbers shifted by the
// lines before each. The records are the ones one scan of the whole text gives.
void tokenize(std::string_view text, const std::string &dlmIn, const std::string &cmt,
              const std::string &secFmt, size_t skip, Parsed &p, const std::string &fn,
              const std::string &file) {
  std::string dlm = dlmIn == "auto" ? sniffDelimiter(text, cmt) : dlmIn;
  const MarkerFormat markerFormat(secFmt);
  p.dlm = dlm;
  const bool ws = dlm == "ws";
  p.sections.push_back({"", {}});
  size_t i = 0, line = 1;
  // skip=N drops the first N physical lines.
  while (skip > 0 && i < text.size()) {
    size_t e = text.find('\n', i);
    p.rawLines.push_back(text.substr(i, (e == std::string::npos ? text.size() : e) - i));
    i = e == std::string::npos ? text.size() : e + 1;
    line++;
    skip--;
  }
  // Chunks of ~1 MB, cut after a '\n' (a small text: one chunk, no threads).
  constexpr size_t kChunk = size_t(1) << 20;
  std::vector<size_t> cuts{i};
  while (text.size() - cuts.back() > kChunk + kChunk / 2) {
    const size_t nl = text.find('\n', cuts.back() + kChunk);
    if (nl == std::string::npos || nl + 1 >= text.size())
      break;
    cuts.push_back(nl + 1);
  }
  cuts.push_back(text.size());
  const size_t nChunks = cuts.size() - 1;
  std::vector<LineScan> scans(nChunks);
  std::vector<size_t> newlines(nChunks, 0); // physical lines in each chunk (any quoting)
  const nc::par::Outcome outcome = nc::par::tasks(nChunks, 2.0e6, "read_csv lines", [&](size_t k) {
    scanLines(text, cuts[k], cuts[k + 1], dlm, ws, cmt, markerFormat, scans[k]);
    newlines[k] = static_cast<size_t>(std::count(text.begin() + static_cast<std::ptrdiff_t>(cuts[k]),
                                                 text.begin() + static_cast<std::ptrdiff_t>(cuts[k + 1]), '\n'));
  });
  if (outcome == nc::par::Outcome::Stopped || reportProgress(fn, file, 0.9) || cancelRequested()) {
    p.cancelled = true; // Stop (the IDE's interrupt flag, seen by the progress listener)
    return;
  }
  // 1) in order: re-scan a chunk whose start a record ran over; the line each
  //    chunk starts on; where its segments and raw lines go.
  struct Place {
    size_t base = 0;                // the line the chunk starts on
    bool used = false;              // false: a record before covered it all
    size_t rawAt = 0;               // its first raw line in p.rawLines
    std::vector<std::pair<size_t, size_t>> segAt; // (section, first record) per segment
  };
  std::vector<Place> place(nChunks);
  const size_t sec0 = p.sections.size() - 1; // the section the text starts in (empty)
  std::vector<size_t> secSize{p.sections.back().records.size()};
  size_t at = i, rawTotal = 0; // at: where the next chunk really starts
  for (size_t k = 0; k < nChunks; k++) {
    Place &pl = place[k];
    pl.base = line;
    if (at > cuts[k]) { // the record before ran over the cut: scan again from its end
      if (at >= cuts[k + 1]) { // ... over this whole chunk
        line += newlines[k];
        continue;
      }
      pl.base = line + static_cast<size_t>(std::count(text.begin() + static_cast<std::ptrdiff_t>(cuts[k]),
                                                      text.begin() + static_cast<std::ptrdiff_t>(at), '\n'));
      scans[k] = LineScan();
      scanLines(text, at, cuts[k + 1], dlm, ws, cmt, markerFormat, scans[k]);
    }
    LineScan &sc = scans[k];
    pl.used = true;
    for (size_t s = 0; s < sc.segs.size(); s++) { // segment 0 goes on with the section before
      if (s > 0) {
        p.sections.push_back({sc.segs[s].first, {}});
        secSize.push_back(0);
      }
      pl.segAt.push_back({p.sections.size() - 1, secSize.back()});
      secSize.back() += sc.segs[s].second.size();
    }
    pl.rawAt = rawTotal;
    rawTotal += sc.rawLines.size();
    for (auto &c : sc.comments)
      p.comments.push_back({pl.base + c.first, std::move(c.second)});
    at = sc.stop;
    line += newlines[k];
  }
  // 2) every chunk copied into place on its own core (sized once)
  for (size_t s = 0; s < secSize.size(); s++)
    p.sections[sec0 + s].records.resize(secSize[s]);
  const size_t raw0 = p.rawLines.size(); // (the lines skip= dropped come first)
  p.rawLines.resize(raw0 + rawTotal);
  const nc::par::Outcome joined = nc::par::tasks(nChunks, 1.0e6, "read_csv join lines", [&](size_t k) {
    if (!place[k].used)
      return;
    LineScan &sc = scans[k];
    const Place &pl = place[k];
    for (size_t s = 0; s < sc.segs.size(); s++) {
      Record *into = p.sections[pl.segAt[s].first].records.data() + pl.segAt[s].second;
      for (const Record &r : sc.segs[s].second) {
        *into = r;
        into->line += pl.base;
        into++;
      }
    }
    std::copy(sc.rawLines.begin(), sc.rawLines.end(), p.rawLines.begin() + static_cast<std::ptrdiff_t>(raw0 + pl.rawAt));
    sc = LineScan(); // free it here, on this core
  });
  if (joined != nc::par::Outcome::Done) {
    p.cancelled = true;
    return;
  }
  // Content before the first marker is the "Main" section; drop it when it
  // holds nothing but blank lines.
  if (p.sections.size() > 1) {
    bool any = false;
    for (const auto &r : p.sections[0].records)
      if (r.nfields != 0)
        any = true;
    if (!any)
      p.sections.erase(p.sections.begin());
  }
  for (size_t s = 0; s < p.sections.size(); s++)
    if (p.sections[s].name.empty())
      p.sections[s].name = s == 0 ? "Main" : "Sheet" + std::to_string(s + 1);
}

struct Block {
  Table table;
  std::vector<std::string> boxes;
  size_t headerLine = 0; // 0 = no header
};

bool looksNumeric(const std::string &s, const std::vector<std::string> &na) {
  Value v = parseCell(s, na);
  return isNumberCell(v) && !std::isnan(v.number);
}

// The table block of one section, its header and the boxes around it. The
// cells go straight into columns (Value::ColumnBuilder, 2026-11-15): each
// row's fields are split from its text and parsed into the columns, so no
// Value is made per cell and no text per field is kept.
// What buildBlock() does once the table's rows are known (2026-11-23,
// Phase 4): the header, the width, the columns, the stray first / last rows,
// the table. rowAt(k) gives row k of the table (k < rowCount) - nullptr when
// the caller does not hold that row (the streaming read keeps only the
// first and last rows: then `outsideWindow` is set and false returned, and
// the caller reads the file the full way). maxFieldsFrom(first): the widest
// row from `first` on. fill(first, n, width, builders, numeric): every row
// from `first` into the column builders, and per column the number cells -
// false = Stop. One body for both reads, so their tables cannot drift apart.
template <class RowAt, class MaxFields, class Fill>
bool blockFromRows(size_t rowCount, RowAt &&rowAt, MaxFields &&maxFieldsFrom, Fill &&fill, long long hdr,
                   const std::vector<std::string> &na, const std::string &dlm, Block &b, std::string &err,
                   bool &outsideWindow) {
  outsideWindow = false;
  auto row = [&](size_t k) -> const Record & {
    const Record *r = rowAt(k);
    if (!r) {
      outsideWindow = true;
      static const Record kNone;
      return kNone;
    }
    return *r;
  };
  size_t first = 0;
  if (hdr > 0) {
    if (static_cast<size_t>(hdr) > rowCount) {
      err = "hdr=" + std::to_string(hdr) + " but the table has only " + std::to_string(rowCount) +
            " rows";
      return false;
    }
    for (long long k = 0; k < hdr - 1; k++)
      b.boxes.push_back(trimView(row(static_cast<size_t>(k)).raw));
    b.table.cols = fieldsOf(row(static_cast<size_t>(hdr - 1)), dlm);
    b.headerLine = row(static_cast<size_t>(hdr - 1)).line;
    first = static_cast<size_t>(hdr);
  } else if (hdr < 0 && rowCount > 0) {
    bool allText = true, unique = true;
    std::vector<std::string> seen;
    for (const auto &f : fieldsOf(row(0), dlm)) {
      std::string t = trim(f);
      if (t.empty() || looksNumeric(t, na))
        allText = false;
      if (std::find(seen.begin(), seen.end(), t) != seen.end())
        unique = false;
      seen.push_back(t);
    }
    bool numericLater = false;
    for (size_t k = 1; k < rowCount && k < 50 && !numericLater; k++)
      for (const auto &f : fieldsOf(row(k), dlm))
        if (looksNumeric(f, na)) {
          numericLater = true;
          break;
        }
    if (allText && (numericLater || (unique && rowCount > 1))) {
      b.table.cols = fieldsOf(row(0), dlm);
      b.headerLine = row(0).line;
      first = 1;
    }
  }
  if (outsideWindow)
    return false;
  for (auto &c : b.table.cols)
    c = trim(c);
  // The table rows are rows[first .. rowCount). Width: the header or the
  // widest row; shorter rows are padded with NaN (as normalizeTable() does).
  const size_t n = rowCount > first ? rowCount - first : 0;
  const size_t maxFields = maxFieldsFrom(first);
  const size_t width = std::max(maxFields, b.table.cols.size());
  std::vector<Value::ColumnBuilder> builders(width);
  for (auto &cb : builders)
    cb.reserve(n);
  std::vector<size_t> numeric(width, 0); // number cells (isNumberCell) among each column's real fields
  if (!fill(first, n, width, builders, numeric)) {
    err = "cancelled";
    return false;
  }
  std::vector<std::shared_ptr<Value::Column>> cols = finishColumns(builders);

  // A first/last row that puts words into mostly-numeric columns is free
  // text that happens to have the table's width ("End of scan").
  size_t lo = 0, hi = n; // the rows kept
  if (n >= 3) {
    auto stray = [&](size_t k) {
      const std::vector<std::string> f = fieldsOf(row(first + k), dlm);
      size_t numCols = 0, bad = 0;
      for (size_t c = 0; c < maxFields; c++) {
        if (numeric[c] * 3 < (hi - lo) * 2)
          continue;
        numCols++;
        if (c >= f.size()) {
          bad++;
          continue;
        }
        const Value v = parseCell(f[c], na);
        if (!isNumberCell(v) && !(v.isText && v.text().empty()))
          bad++;
      }
      return numCols > 0 && bad * 2 >= numCols && bad >= 1;
    };
    std::vector<std::string> tail;
    while (hi - lo > 2 && stray(hi - 1)) {
      if (outsideWindow)
        return false;
      tail.insert(tail.begin(), trimView(row(first + hi - 1).raw));
      hi--;
    }
    while (hi - lo > 2 && stray(lo)) {
      if (outsideWindow)
        return false;
      b.boxes.insert(b.boxes.begin(), trimView(row(first + lo).raw));
      lo++;
    }
    if (outsideWindow)
      return false;
    b.boxes.insert(b.boxes.end(), tail.begin(), tail.end());
  }
  tableFromColumns(b.table, std::move(cols), n);
  if (lo > 0 || hi < n) {
    // without the stray rows: their rows, and columns only they were wide enough for
    size_t keptWidth = b.table.cols.size();
    for (size_t k = lo; k < hi; k++)
      keptWidth = std::max(keptWidth, row(first + k).nfields);
    if (outsideWindow)
      return false;
    if (b.table.data.isColumnar()) {
      std::vector<size_t> ri, ci;
      for (size_t k = lo; k < hi; k++)
        ri.push_back(k);
      for (size_t c = 0; c < keptWidth; c++)
        ci.push_back(c);
      b.table.data = b.table.data.columnarTake(&ri, ci);
    } else {
      tableToRows(b.table);
      auto &tr = b.table.rows;
      tr.erase(tr.begin() + static_cast<std::ptrdiff_t>(hi), tr.end());
      tr.erase(tr.begin(), tr.begin() + static_cast<std::ptrdiff_t>(lo));
      for (auto &r : tr)
        r.resize(keptWidth);
    }
  }
  normalizeTable(b.table);
  return true;
}

bool buildBlock(Section &sec, long long hdr, const std::vector<std::string> &na, const std::string &dlm,
                Block &b, std::string &err) {
  b = Block(); // a block built from a shorter prefix before is replaced, not added to
  const bool ws = dlm == "ws";
  const auto &recs = sec.records;
  std::map<size_t, size_t> freq;
  size_t lastWidth = 0, *lastCount = nullptr; // (rows of one width follow each other: one map look-up per run)
  for (const auto &r : recs)
    if (r.nfields >= 2) {
      if (r.nfields != lastWidth) {
        lastWidth = r.nfields;
        lastCount = &freq[lastWidth];
      }
      ++*lastCount;
    }
  size_t mode = 1;
  size_t best = 0;
  for (const auto &kv : freq)
    if (kv.second > best || (kv.second == best && kv.first > mode)) {
      best = kv.second;
      mode = kv.first;
    }
  auto belongs = [&](const Record &r, bool first) {
    if (r.nfields == 0)
      return false;
    if (mode == 1)
      return true;
    if (r.nfields == mode)
      return true;
    // Short rows (missing trailing values) inside the table - not with
    // whitespace delimiters, where a sentence of words would match too.
    return !first && !ws && r.nfields >= 2 && r.nfields < mode;
  };
  size_t bestStart = 0, bestLen = 0;
  for (size_t s = 0; s < recs.size(); s++) {
    if (!belongs(recs[s], true))
      continue;
    size_t e = s + 1;
    while (e < recs.size() && belongs(recs[e], false))
      e++;
    // A blank line followed by more rows of the same width continues it.
    while (e + 1 < recs.size() && recs[e].nfields == 0 && recs[e + 1].nfields == mode &&
           mode > 1) {
      e++;
      while (e < recs.size() && belongs(recs[e], false))
        e++;
    }
    if (e - s > bestLen) {
      bestStart = s;
      bestLen = e - s;
    }
    s = e - 1;
  }
  std::vector<const Record *> rows;
  rows.reserve(bestLen);
  for (size_t k = bestStart; k < bestStart + bestLen; k++)
    if (recs[k].nfields != 0)
      rows.push_back(&recs[k]);
  for (size_t k = 0; k < recs.size(); k++)
    if ((k < bestStart || k >= bestStart + bestLen) && recs[k].nfields != 0)
      b.boxes.push_back(trimView(recs[k].raw));

  auto rowAt = [&](size_t k) -> const Record * { return rows[k]; };
  auto maxFieldsFrom = [&](size_t first) {
    size_t maxFields = 0; // widest row (the stray-row test below looks at these columns)
    for (size_t k = first; k < rows.size(); k++)
      maxFields = std::max(maxFields, rows[k]->nfields);
    return maxFields;
  };
  // The rows go into the columns on several cores (2026-11-15): each job takes
  // a range of rows and builds its own piece of every column straight from
  // the fields (pushCell: trim, the na list, the number parse); the pieces are
  // then joined in row order (ColumnBuilder::absorb - buffers appended), so
  // the columns are the ones one builder fed every row in turn makes, for any
  // number of threads. Stop is seen by the job runner (nc::par).
  auto fill = [&](size_t first, size_t n, size_t width, std::vector<Value::ColumnBuilder> &builders,
                  std::vector<size_t> &numeric) {
    constexpr size_t kJob = 16384;
    const size_t jobs = (n + kJob - 1) / kJob;
    std::vector<std::vector<Value::ColumnBuilder>> pieces(width); // [column][job]
    for (auto &pc : pieces)
      pc.resize(jobs);
    std::vector<std::vector<size_t>> pieceNumeric(jobs);
    const nc::par::Outcome outcome = nc::par::tasks(jobs, 300.0 * kJob * width, "read_csv columns", [&](size_t j) {
      const size_t r0 = first + j * kJob, r1 = std::min(rows.size(), r0 + kJob);
      std::vector<size_t> &num = pieceNumeric[j];
      num.assign(width, 0);
      std::vector<Value::ColumnBuilder> pb(width); // (this core's own, then handed over)
      for (auto &cb : pb)
        cb.reserve(r1 - r0);
      for (size_t k = r0; k < r1; k++) {
        size_t c = 0;
        forEachField(*rows[k], dlm, [&](std::string_view f) {
          if (pushCell(pb[c], f, na))
            num[c]++;
          c++;
        });
        for (; c < width; c++)
          pb[c].pushNumber(missingNumber()); // a short row: missing cells
      }
      for (size_t c = 0; c < width; c++)
        pieces[c][j] = std::move(pb[c]);
    });
    if (outcome == nc::par::Outcome::Stopped || cancelRequested())
      return false;
    // each column on its own core, its pieces in row order
    if (nc::par::tasks(width, 4.0 * static_cast<double>(n), "read_csv join",
                       [&](size_t c) { builders[c].absorbAll(pieces[c]); }) != nc::par::Outcome::Done)
      return false;
    for (size_t j = 0; j < jobs; j++)
      for (size_t c = 0; c < width; c++)
        numeric[c] += pieceNumeric[j][c];
    return true;
  };
  bool outsideWindow = false;
  return blockFromRows(rows.size(), rowAt, maxFieldsFrom, fill, hdr, na, dlm, b, err, outsideWindow);
}

struct ReadOpts {
  std::string dlm, cmt = "#", enc = "utf-8", secFmt = "# [Sheet: {name}]";
  long long hdr = -1, skip = 0;
  std::vector<std::string> na = kDefaultNa;
};

bool parseFile(const std::string &file, const ReadOpts &o, Parsed &p, const std::string &fn,
               std::string &err) {
  auto src = std::make_shared<SourceBytes>();
  if (!src->open(file, err))
    return false;
  const std::string_view v = src->view();
  std::string enc = lower(o.enc);
  enc.erase(std::remove(enc.begin(), enc.end(), '_'), enc.end());
  const bool gz = (v.size() >= 2 && static_cast<unsigned char>(v[0]) == 0x1F && static_cast<unsigned char>(v[1]) == 0x8B) ||
                  looksZlib(v); // compress="zlib" (2026-11-17)
  const bool bom16 = v.size() >= 2 && ((static_cast<unsigned char>(v[0]) == 0xFF && static_cast<unsigned char>(v[1]) == 0xFE) ||
                                       (static_cast<unsigned char>(v[0]) == 0xFE && static_cast<unsigned char>(v[1]) == 0xFF));
  const bool utf8 = enc.empty() || enc == "utf-8" || enc == "utf8" || enc == "ascii" || enc == "us-ascii";
  if (!gz && !bom16 && utf8) {
    // decodeText of UTF-8 is the bytes without a BOM: tokenize them in place
    const size_t start = v.size() >= 3 && static_cast<unsigned char>(v[0]) == 0xEF &&
                                 static_cast<unsigned char>(v[1]) == 0xBB && static_cast<unsigned char>(v[2]) == 0xBF
                             ? 3
                             : 0;
    p.mapped = src;
    tokenize(v.substr(start), o.dlm, o.cmt, o.secFmt, static_cast<size_t>(std::max(0LL, o.skip)), p, fn, file);
    if (p.cancelled) { err = "cancelled"; return false; }
    return true;
  }
  std::string raw(v);
  src.reset();
  auto text = std::make_shared<std::string>();
  if (!autoDecompress(raw, err) || !decodeText(raw, o.enc, *text, err))
    return false;
  std::string().swap(raw);
  p.owned = text;
  tokenize(*text, o.dlm, o.cmt, o.secFmt, static_cast<size_t>(std::max(0LL, o.skip)), p, fn, file);
  if (p.cancelled) { err = "cancelled"; return false; }
  return true;
}

// The first `bytes` of a local file, cut after its last complete line, parsed.
// `whole` = the prefix is the whole file. False with err only on real errors;
// `usable` false = the prefix cannot be cut safely (gzip, UTF-16) - read it all.
bool parsePrefix(const std::string &file, const ReadOpts &o, size_t bytes, Parsed &p, bool &whole, bool &usable,
                 const std::string &fn, std::string &err) {
  std::string raw, text;
  usable = false;
  if (!readFileHead(file, bytes, raw, err))
    return false;
  whole = raw.size() < bytes || static_cast<uint64_t>(raw.size()) >= fileSize(file);
  const std::string enc = lower(o.enc);
  if (isGzip(raw) || looksZlib(raw) || enc.rfind("utf-16", 0) == 0 || enc == "utf16")
    return true;
  if (!whole) {
    size_t nl = raw.rfind('\n');
    if (nl == std::string::npos)
      return true; // one line longer than the prefix
    raw.resize(nl + 1);
  }
  if (!decodeText(raw, o.enc, text, err))
    return false;
  p = Parsed();
  p.owned = std::make_shared<std::string>(std::move(text));
  tokenize(*p.owned, o.dlm, o.cmt, o.secFmt, static_cast<size_t>(std::max(0LL, o.skip)), p, fn, file);
  if (p.cancelled) { err = "cancelled"; return false; }
  usable = true;
  return true;
}

bool pickSection(const Parsed &p, const Value &sheet, size_t &idx, std::string &err) {
  idx = 0;
  if (!given(sheet) || (numpy::isPlainNumber(sheet) && sheet.number <= 0))
    return true;
  if (numpy::isPlainNumber(sheet)) {
    size_t k = static_cast<size_t>(sheet.number);
    if (k < 1 || k > p.sections.size()) {
      err = "sheet " + std::to_string(k) + " does not exist (the file has " +
            std::to_string(p.sections.size()) + ")";
      return false;
    }
    idx = k - 1;
    return true;
  }
  std::string want = optText(sheet);
  for (size_t s = 0; s < p.sections.size(); s++)
    if (p.sections[s].name == want || lower(p.sections[s].name) == lower(want)) {
      idx = s;
      return true;
    }
  std::string names;
  for (const auto &s : p.sections)
    names += (names.empty() ? "" : ", ") + s.name;
  err = "no sheet '" + want + "' (sheets: " + names + ")";
  return false;
}

Value commentsValue(const std::vector<std::pair<size_t, std::string>> &c) {
  std::vector<std::vector<Value>> m;
  for (const auto &kv : c)
    m.push_back({Value(static_cast<double>(kv.first)), Value(kv.second)});
  if (m.empty())
    return Value(std::vector<Value>{});
  return Value(m);
}

std::vector<std::string> sectionNames(const Parsed &p) {
  std::vector<std::string> n;
  for (const auto &s : p.sections)
    n.push_back(s.name);
  return n;
}

bool readOpts(const std::vector<Value> &a, size_t dlmAt, const std::string &defDlm, ReadOpts &o,
              std::string &err) {
  o.dlm = normalizeDelimiter(optText(a[dlmAt], defDlm));
  (void)err;
  return true;
}

std::string dlmText(const std::string &d) { return d == "ws" ? "\\s+" : d == "\t" ? "\\t" : d; }

// read_<fmt>(file, sheet, dlm, cols, rows, hdr, box, cmt, skip, enc, na, sec_fmt)
// ---- the streaming read (2026-11-23, Phase 4, docs/Large_Data_Design.md 19) ----
//
// tokenize() keeps a Record (32 bytes) and a raw line view (16) for every
// row of the file, and during its join a second copy of both: a 1 GB CSV of
// one column (50 M rows) peaked at 11.6 GB. For the plain big table - one
// section, no blank lines, every row the same width, no quoted field
// running over a chunk cut, no skip= - the file is read in two passes over
// its ~1 MB chunks, each chunk's records made and dropped on its own core:
//   1) widths, row counts, comments, and only the first and last 64 rows;
//   2) every row straight into column pieces, joined in order (as the full
//      read's jobs do).
// The table is then made by blockFromRows(), the very code of the full read,
// so the result is the same; anything that does not fit this shape (or a
// header / stray-row test that needs a row not kept) takes the full read.
// Returns 1 done, 0 not this shape (read the full way), -1 failed (err).
constexpr size_t kStreamFrom = size_t(64) << 20; // files from 64 MB (NC_CSV_STREAM=1: any size, for checks)

bool streamForced() {
  static const bool forced = [] {
    std::string text;
#ifdef _WIN32
    char *buffer = nullptr;
    size_t length = 0;
    if (_dupenv_s(&buffer, &length, "NC_CSV_STREAM") == 0 && buffer) {
      text = buffer;
      std::free(buffer);
    }
#else
    if (const char *value = std::getenv("NC_CSV_STREAM"))
      text = value;
#endif
    return text == "1";
  }();
  return forced;
}

// NC_CSV_DEBUG=1 (any value): the memory after each stage of a streaming read
// on stderr - how the Phase 4 numbers were measured (Windows only).
void csvStage(const char *what) {
  static const bool on = [] {
    char *buffer = nullptr;
    size_t length = 0;
    bool yes = false;
#ifdef _WIN32
    if (_dupenv_s(&buffer, &length, "NC_CSV_DEBUG") == 0 && buffer) {
      yes = true;
      std::free(buffer);
    }
#endif
    return yes;
  }();
  if (!on)
    return;
  nc::par::sys::MemoryInfo m;
  nc::par::sys::memoryInfo(m);
  std::fprintf(stderr, "[csv] %-28s used %.2f GB  peak %.2f GB\n", what, m.used / 1e9, m.peak / 1e9);
}

int readStreaming(const std::string &file, const ReadOpts &o, long long hdr, Parsed &p, Block &b,
                  const std::string &fn, std::string &err) {
  if (o.skip > 0 || isUrl(file))
    return 0;
  if (!streamForced() && fileSize(file) < kStreamFrom)
    return 0;
  auto src = std::make_shared<SourceBytes>();
  std::string openErr;
  if (!src->open(file, openErr))
    return 0; // the full read reports it
  const std::string_view v = src->view();
  std::string enc = lower(o.enc);
  enc.erase(std::remove(enc.begin(), enc.end(), '_'), enc.end());
  const bool gz = (v.size() >= 2 && static_cast<unsigned char>(v[0]) == 0x1F && static_cast<unsigned char>(v[1]) == 0x8B) ||
                  looksZlib(v);
  const bool bom16 = v.size() >= 2 && ((static_cast<unsigned char>(v[0]) == 0xFF && static_cast<unsigned char>(v[1]) == 0xFE) ||
                                       (static_cast<unsigned char>(v[0]) == 0xFE && static_cast<unsigned char>(v[1]) == 0xFF));
  const bool utf8 = enc.empty() || enc == "utf-8" || enc == "utf8" || enc == "ascii" || enc == "us-ascii";
  if (gz || bom16 || !utf8)
    return 0;
  const size_t bom = v.size() >= 3 && static_cast<unsigned char>(v[0]) == 0xEF &&
                             static_cast<unsigned char>(v[1]) == 0xBB && static_cast<unsigned char>(v[2]) == 0xBF
                         ? 3
                         : 0;
  const std::string_view text = v.substr(bom);
  const std::string dlm = o.dlm == "auto" ? sniffDelimiter(text, o.cmt) : o.dlm;
  const MarkerFormat markerFormat(o.secFmt);
  const bool ws = dlm == "ws";

  // the chunk cuts of tokenize()
  constexpr size_t kChunk = size_t(1) << 20;
  std::vector<size_t> cuts{0};
  while (text.size() - cuts.back() > kChunk + kChunk / 2) {
    const size_t nlAt = text.find('\n', cuts.back() + kChunk);
    if (nlAt == std::string::npos || nlAt + 1 >= text.size())
      break;
    cuts.push_back(nlAt + 1);
  }
  cuts.push_back(text.size());
  const size_t nChunks = cuts.size() - 1;

  // pass 1
  constexpr size_t kKeep = 64;
  struct ChunkInfo {
    bool plain = true; // stopped at its cut, no marker, no blank record
    size_t rows = 0, newlines = 0, minW = SIZE_MAX, maxW = 0;
    std::vector<Record> head, tail; // first / last kKeep rows (chunk-relative lines)
    std::vector<std::pair<size_t, std::string>> comments;
  };
  std::vector<ChunkInfo> info(nChunks);
  if (nc::par::tasks(nChunks, 2.0e6, "read_csv lines", [&](size_t k) {
        LineScan sc;
        scanLines(text, cuts[k], cuts[k + 1], dlm, ws, o.cmt, markerFormat, sc);
        ChunkInfo &ci = info[k];
        ci.newlines = static_cast<size_t>(std::count(text.begin() + static_cast<std::ptrdiff_t>(cuts[k]),
                                                     text.begin() + static_cast<std::ptrdiff_t>(cuts[k + 1]), '\n'));
        ci.plain = sc.stop == cuts[k + 1] && sc.segs.size() == 1;
        ci.comments = std::move(sc.comments);
        const std::vector<Record> &recs = sc.segs[0].second;
        for (const Record &r : recs) {
          if (r.nfields == 0) {
            ci.plain = false;
            break;
          }
          ci.minW = std::min(ci.minW, r.nfields);
          ci.maxW = std::max(ci.maxW, r.nfields);
        }
        ci.rows = recs.size();
        for (size_t i = 0; i < recs.size() && i < kKeep; i++)
          ci.head.push_back(recs[i]);
        for (size_t i = recs.size() > kKeep ? recs.size() - kKeep : 0; i < recs.size(); i++)
          ci.tail.push_back(recs[i]);
      }) != nc::par::Outcome::Done ||
      cancelRequested()) {
    err = "cancelled";
    return -1;
  }
  size_t W = 0, total = 0;
  for (const ChunkInfo &ci : info) {
    if (!ci.plain)
      return 0;
    if (ci.rows == 0)
      continue;
    if (ci.minW != ci.maxW || (W != 0 && ci.minW != W))
      return 0;
    W = ci.minW;
    total += ci.rows;
  }
  if (total == 0)
    return 0;
  csvStage("after pass 1");
  reportProgress(fn, file, 0.45);

  // global row numbers and lines; the kept rows
  std::vector<size_t> rowBase(nChunks + 1, 0), lineBase(nChunks, 1);
  for (size_t k = 0; k < nChunks; k++) {
    rowBase[k + 1] = rowBase[k] + info[k].rows;
    if (k > 0)
      lineBase[k] = lineBase[k - 1] + info[k - 1].newlines;
  }
  std::vector<Record> head, tail; // global rows [0, head.size()) and [total - tail.size(), total)
  for (size_t k = 0; k < nChunks && head.size() < kKeep; k++)
    for (const Record &r : info[k].head) {
      if (head.size() >= kKeep)
        break;
      head.push_back(r);
      head.back().line += lineBase[k];
    }
  for (size_t k = nChunks; k-- > 0 && tail.size() < kKeep;) {
    const std::vector<Record> &t = info[k].tail;
    for (size_t i = t.size(); i-- > 0 && tail.size() < kKeep;) {
      tail.push_back(t[i]);
      tail.back().line += lineBase[k];
    }
  }
  std::reverse(tail.begin(), tail.end());
  for (size_t k = 0; k < nChunks; k++) {
    for (auto &c : info[k].comments)
      p.comments.push_back({lineBase[k] + c.first, std::move(c.second)});
    info[k] = ChunkInfo(); // free the kept rows
  }
  auto rowAt = [&](size_t g) -> const Record * {
    if (g < head.size())
      return &head[g];
    if (g + tail.size() >= total)
      return &tail[g - (total - tail.size())];
    return nullptr;
  };

  // pass 2: every row into column pieces, chunk by chunk
  auto fill = [&](size_t first, size_t n, size_t width, std::vector<Value::ColumnBuilder> &builders,
                  std::vector<size_t> &numeric) {
    (void)n;
    std::vector<std::vector<Value::ColumnBuilder>> pieces(width); // [column][chunk]
    for (auto &pc : pieces)
      pc.resize(nChunks);
    std::vector<std::vector<size_t>> pieceNumeric(nChunks);
    const nc::par::Outcome outcome = nc::par::tasks(nChunks, 4.0e6, "read_csv columns", [&](size_t k) {
      std::vector<size_t> &num = pieceNumeric[k];
      num.assign(width, 0);
      if (rowBase[k + 1] <= first)
        return; // only header rows here
      LineScan sc;
      scanLines(text, cuts[k], cuts[k + 1], dlm, ws, o.cmt, markerFormat, sc);
      const std::vector<Record> &recs = sc.segs[0].second;
      std::vector<Value::ColumnBuilder> pb(width);
      for (auto &cb : pb)
        cb.reserve(recs.size());
      for (size_t i = 0; i < recs.size(); i++) {
        if (rowBase[k] + i < first)
          continue;
        size_t c = 0;
        forEachField(recs[i], dlm, [&](std::string_view f) {
          if (pushCell(pb[c], f, o.na))
            num[c]++;
          c++;
        });
        for (; c < width; c++)
          pb[c].pushNumber(missingNumber()); // (a header wider than the rows)
      }
      for (size_t c = 0; c < width; c++)
        pieces[c][k] = std::move(pb[c]);
    });
    if (outcome == nc::par::Outcome::Stopped || cancelRequested())
      return false;
    csvStage("after pass 2 pieces");
    if (nc::par::tasks(width, 4.0 * static_cast<double>(total), "read_csv join",
                       [&](size_t c) { builders[c].absorbAll(pieces[c]); }) != nc::par::Outcome::Done)
      return false;
    for (size_t k = 0; k < nChunks; k++)
      for (size_t c = 0; c < width; c++)
        numeric[c] += pieceNumeric[k][c];
    return true;
  };
  auto maxFieldsFrom = [&](size_t) { return W; };
  bool outsideWindow = false;
  if (!blockFromRows(total, rowAt, maxFieldsFrom, fill, hdr, o.na, dlm, b, err, outsideWindow)) {
    if (outsideWindow) {
      b = Block();
      p = Parsed();
      err.clear();
      return 0; // a row it needed was not kept: the full read
    }
    return -1;
  }
  csvStage("after the table");
  p.dlm = dlm;
  p.mapped = src;
  p.sections.push_back({"Main", {}});
  return 1;
}

void readDelimited(const std::string &fn, const std::string &defDlm, const std::vector<Value> &a,
                   size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev(fn, file);
  ReadOpts o;
  readOpts(a, 2, defDlm, o, err);
  o.hdr = a[5].isBool() ? (a[5].number != 0 ? 1 : 0) : optInt(a[5], -1);
  const bool box = optBool(a[6], true);
  o.cmt = a[7].isText ? a[7].text() : o.cmt;
  o.skip = optInt(a[8], 0);
  o.enc = optText(a[9], "utf-8");
  if (given(a[10]))
    o.na = optTextList(a[10]);
  o.secFmt = optText(a[11], o.secFmt);
  Parsed p;
  size_t sec = 0;
  Block b;
  bool done = false;
  // rows=[1:200] / "1:5:200" on a big local file: parse growing prefixes
  // (1 MB, 2 MB, 4 MB ...) until the table holds the last row asked for, so
  // the first rows of a 200 GB file cost a few MB. One row more than asked
  // is required, so the last row kept is never cut by the prefix. Text
  // after the table (boxes below it) is then not seen.
  long long lastRow = 0;
  constexpr size_t kStart = size_t(1) << 20;
  if (!isUrl(file) && rowsUpperBound(a[4], lastRow) && lastRow > 0 && fileSize(file) > 4 * kStart) {
    const uint64_t total = fileSize(file);
    // past half the file a prefix costs more than reading it once
    for (size_t want = kStart; static_cast<uint64_t>(want) * 2 <= total; want *= 2) {
      bool whole = false, usable = false;
      if (!parsePrefix(file, o, want, p, whole, usable, fn, err))
        return ctx.fail(err);
      if (!usable)
        break;
      if (cancelRequested())
        return ctx.fail("cancelled");
      std::string e2;
      if (pickSection(p, a[1], sec, e2) && buildBlock(p.sections[sec], o.hdr, o.na, p.dlm, b, e2) &&
          (whole || static_cast<long long>(b.table.rowCount()) > lastRow ||
           // the table ended before the prefix did: more bytes add no rows
           (sec + 1 < p.sections.size()))) {
        done = true;
        break;
      }
      if (whole) {
        if (!e2.empty())
          return ctx.fail(e2);
        done = true;
        break;
      }
      reportProgress(fn, file, std::min(0.9, static_cast<double>(want) / static_cast<double>(total)));
    }
  }
  if (!done) {
    p = Parsed();
    b = Block();
    // A big plain table: read in streaming passes (Phase 4, readStreaming).
    const int streamed = readStreaming(file, o, o.hdr, p, b, fn, err);
    if (streamed < 0)
      return ctx.fail(err);
    if (streamed == 1) {
      if (!pickSection(p, a[1], sec, err))
        return ctx.fail(err);
    } else {
      p = Parsed();
      if (!parseFile(file, o, p, fn, err))
        return ctx.fail(err);
      if (!pickSection(p, a[1], sec, err))
        return ctx.fail(err);
      b = Block();
      if (!buildBlock(p.sections[sec], o.hdr, o.na, p.dlm, b, err))
        return ctx.fail(err);
    }
  }
  if (!selectTable(b.table, a[3], a[4], err))
    return ctx.fail(err);
  if (b.table.rowCount() > 0xFFFF && (reportProgress("", "", 0.999) || cancelRequested())) // Stop before a big data value is made
    return ctx.fail("cancelled");
  Value info;
  if (nout > 1) { // from the table before its rows move into the data value
    Fields f;
    f["cols"] = textList(b.table.cols);
    f["schema"] = tableSchema(b.table);
    f["boxes"] = box ? textList(b.boxes) : textList({});
    f["comments"] = commentsValue(p.comments);
    f["sheet"] = Value(p.sections[sec].name);
    f["sheets"] = textList(sectionNames(p));
    f["dlm"] = Value(dlmText(p.dlm));
    f["header_line"] = Value(static_cast<double>(b.headerLine));
    f["rows"] = Value(static_cast<double>(b.table.rowCount()));
    info = makeObject("NcReadInfo", std::move(f));
  }
  csvStage("before tableData");
  out.push_back(tableData(std::move(b.table)));
  csvStage("after tableData");
  if (nout > 1)
    out.push_back(std::move(info));
  ev.ok = true;
}

// load_<fmt>(file, dlm, hdr, cmt, skip, enc, na, sec_fmt)
Value loadDelimited(const std::string &fn, const std::string &fmt, const std::string &defDlm,
                    const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  ReadOpts o;
  readOpts(a, 1, defDlm, o, err);
  o.hdr = a[2].isBool() ? (a[2].number != 0 ? 1 : 0) : optInt(a[2], -1);
  o.cmt = a[3].isText ? a[3].text() : o.cmt;
  o.skip = optInt(a[4], 0);
  o.enc = optText(a[5], "utf-8");
  if (given(a[6]))
    o.na = optTextList(a[6]);
  o.secFmt = optText(a[7], o.secFmt);
  Parsed p;
  if (!parseFile(file, o, p, fn, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  std::vector<std::string> allBoxes;
  Value def;
  Table defTable;
  for (size_t s = 0; s < p.sections.size(); s++) {
    Block b;
    if (!buildBlock(p.sections[s], o.hdr, o.na, p.dlm, b, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    for (const auto &bx : b.boxes)
      allBoxes.push_back(bx);
    Value tbl = tableObject(b.table, {{"boxes", textList(b.boxes)},
                                      {"name", Value(p.sections[s].name)}});
    if (s == 0) {
      def = tbl;
      defTable = b.table;
    }
    std::string fname = fieldName(p.sections[s].name);
    if (!fname.empty())
      f[fname] = tbl;
  }
  // The default table's columns are fields of D itself (D.Temp). They are the
  // default section object's own fields (a copy shares the buffers), not
  // made again - except "name" / "boxes", which that object uses itself.
  auto ofDefault = [&](const std::string &key, auto make) -> Value {
    const Value *x = key != "name" && key != "boxes" ? field(def, key) : nullptr;
    return x ? *x : make();
  };
  for (size_t c = 0; c < defTable.cols.size(); c++) {
    std::string n = fieldName(defTable.cols[c]);
    if (!n.empty() && !f.count(n))
      f[n] = ofDefault(n, [&] { return tableColumn(defTable, c); });
  }
  f["default"] = def;
  f["sheets"] = textList(sectionNames(p));
  f["cols"] = textList(defTable.cols);
  f["rows"] = Value(static_cast<double>(defTable.rowCount()));
  f["data"] = ofDefault("data", [&] { return tableData(defTable); });
  f["schema"] = ofDefault("schema", [&] { return tableSchema(defTable); });
  f["boxes"] = textList(allBoxes);
  f["comments"] = commentsValue(p.comments);
  f["raw_lines"] = textList(std::vector<std::string>(p.rawLines.begin(), p.rawLines.end()));
  f["file"] = Value(file);
  f["format"] = Value(fmt);
  f["dlm"] = Value(dlmText(p.dlm));
  ev.ok = true;
  return makeObject("NcDelimited", std::move(f));
}

std::string quoteField(const std::string &s, const std::string &dlm, bool all) {
  bool need = all || s.find('"') != std::string::npos || s.find('\n') != std::string::npos ||
              s.find('\r') != std::string::npos ||
              (dlm == "ws" ? (s.find(' ') != std::string::npos || s.find('\t') != std::string::npos ||
                              s.empty())
                           : s.find(dlm) != std::string::npos) ||
              (!s.empty() && (s.front() == ' ' || s.back() == ' '));
  if (!need)
    return s;
  std::string q = "\"";
  for (char c : s) {
    if (c == '"')
      q += "\"\"";
    else
      q.push_back(c);
  }
  return q + "\"";
}

bool generatedNames(const Table &t) {
  for (size_t i = 0; i < t.cols.size(); i++)
    if (t.cols[i] != "Col_" + std::to_string(i + 1))
      return false;
  return true;
}

void writeTable(const Table &t, const std::string &dlm, const std::string &hdrMode, bool quoteAll,
                const std::string &floatFmt, bool skipHeader, std::string &out) {
  bool header = !skipHeader && (hdrMode == "true" || hdrMode == "1" ||
                                (hdrMode == "auto" && !generatedNames(t)));
  if (dlm != "ws") {
    // Straight into the text, row by row: no text per cell is kept.
    auto line = [&](size_t n, auto textOf) {
      for (size_t c = 0; c < n; c++) {
        if (c)
          out += dlm;
        out += quoteField(textOf(c), dlm, quoteAll);
      }
      out += "\n";
    };
    if (header)
      line(t.cols.size(), [&](size_t c) { return t.cols[c]; });
    const size_t nrows = t.rowCount();
    for (size_t r = 0; r < nrows; r++) {
      if (t.columnar)
        line(t.data.cols(), [&](size_t c) { return cellText(t.data.at(r, c), floatFmt); });
      else
        line(t.rows[r].size(), [&](size_t c) { return cellText(t.rows[r][c], floatFmt); });
    }
    return;
  }
  std::vector<std::vector<std::string>> cells;
  std::vector<bool> numericCol(t.cols.size(), true);
  if (header)
    cells.push_back(t.cols);
  for (size_t ri = 0; ri < t.rowCount(); ri++) {
    const std::vector<Value> r = t.columnar ? t.data.row(ri) : t.rows[ri];
    std::vector<std::string> row;
    for (size_t c = 0; c < r.size(); c++) {
      if (!isNumberCell(r[c]))
        numericCol[c] = false;
      row.push_back(cellText(r[c], floatFmt));
    }
    cells.push_back(std::move(row));
  }
  if (dlm == "ws") {
    // Aligned columns: numbers to the right, text to the left.
    std::vector<size_t> width(t.cols.size(), 0);
    for (auto &row : cells)
      for (size_t c = 0; c < row.size(); c++) {
        row[c] = quoteField(row[c], dlm, quoteAll);
        width[c] = std::max(width[c], row[c].size());
      }
    for (const auto &row : cells) {
      std::string line;
      for (size_t c = 0; c < row.size(); c++) {
        std::string pad(width[c] - row[c].size(), ' ');
        if (c)
          line += "  ";
        line += numericCol[c] ? pad + row[c] : (c + 1 < row.size() ? row[c] + pad : row[c]);
      }
      while (!line.empty() && line.back() == ' ')
        line.pop_back();
      out += line + "\n";
    }
  }
}

// Sheets to write: a dict name -> table, or an NcDelimited object.
bool collectSheets(const Value &v, std::vector<std::pair<std::string, Table>> &out,
                   std::string &err) {
  // a loaded workbook (E13, 2026-11-17) holds its sheets the same way
  if (isObjectOf(v, "NcDelimited") || isObjectOf(v, "NcWorkbook")) {
    const Value *names = field(v, "sheets");
    for (const auto &n : optTextList(names ? *names : Value(std::string()))) {
      const Value *t = field(v, fieldName(n));
      Table tb;
      if (!t || !valueToTable(*t, tb, err, false, true))
        return false;
      out.push_back({n, tb});
    }
    return true;
  }
  if (!v.isDict) {
    err = "sheets must be a dict of name -> table (d = dict(); d[\"S1\"] = T1;)";
    return false;
  }
  std::vector<std::string> keys;
  for (const auto &kv : v.dict())
    keys.push_back(kv.first);
  std::sort(keys.begin(), keys.end());
  for (const auto &k : keys) {
    Table tb;
    if (!valueToTable(v.dict().at(k), tb, err, true, true))
      return false;
    out.push_back({k, tb});
  }
  return true;
}

// One row of a table as delimited text (writeTable's rule for a delimiter
// other than whitespace), appended to `out`.
void appendRow(const Table &t, size_t r, const std::string &dlm, bool quoteAll, const std::string &floatFmt,
               std::string &out) {
  const size_t n = t.columnar ? t.data.cols() : t.rows[r].size();
  for (size_t c = 0; c < n; c++) {
    if (c)
      out += dlm;
    out += quoteField(cellText(t.columnar ? t.data.at(r, c) : t.rows[r][c], floatFmt), dlm, quoteAll);
  }
  out += "\n";
}

// The byte-order mark encodeText() puts in front of the text for `enc`
// (dropped from every block after the first when streaming).
size_t bomLength(const std::string &encIn) {
  const std::string enc = lower(encIn);
  if (enc == "utf-8-sig")
    return 3;
  if (enc.rfind("utf-16", 0) == 0 || enc.rfind("utf16", 0) == 0)
    return 2;
  return 0;
}

// E6 / E10 (2026-11-17): the text of a save written block by block into
// FileSinks - the text of all rows is never held at once (a 20 GB table
// needs a few MB), compress= gz / zlib streamed, progress and Stop between
// blocks. `splitAt` > 0: numbered parts <stem>_part001.<ext> ... of at most
// that many bytes of text each (every part has the header; boxes only the
// first). `budget` (max_size=): over it is an error, with the same message
// as before; a big output stops as soon as it passes it.
struct StreamText {
  std::string fn, file, enc, compress, dlm, hdrMode, floatFmt;
  int level = -1;
  bool quoteAll = false, append = false;
  uint64_t splitAt = 0, budget = 0;
  std::vector<std::string> boxes;
  std::vector<std::string> written; // every file, in order
  uint64_t total = 0;
};

long long streamSheets(StreamText &s, const std::vector<std::pair<std::string, Table>> &sheets,
                       const std::string &secFmt, std::string &err) {
  constexpr size_t kBlock = size_t(4) << 20;
  constexpr uint64_t kEarlyStop = uint64_t(64) << 20; // past max_size with this much written: stop now
  const size_t bom = bomLength(s.enc);
  const std::string ext = extensionOf(s.file);
  FileSink sink;
  size_t part = 0;
  bool firstBlock = true;
  uint64_t partText = 0;
  std::string block, bytes;
  auto partPath = [&]() {
    if (!s.splitAt)
      return s.file;
    char suffix[32];
    std::snprintf(suffix, sizeof suffix, "_part%03zu", part);
    std::string stem = s.file.substr(0, s.file.size() - (ext.empty() ? 0 : ext.size() + 1));
    return stem + suffix + (ext.empty() ? "" : "." + ext);
  };
  auto put = [&]() -> bool {
    if (block.empty())
      return true;
    if (!encodeText(block, s.enc, bytes, err))
      return false;
    std::string_view v(bytes);
    if (!firstBlock && bom)
      v.remove_prefix(std::min(bom, v.size()));
    firstBlock = false;
    block.clear();
    if (!sink.write(v, err))
      return false;
    if (s.budget && sink.bytes() > s.budget && sink.rawBytes() > kEarlyStop) {
      err = "the output passed max_size " + formatBytes(s.budget) +
            " (try compress=\"gz\", fewer rows, or a larger max_size)";
      return false;
    }
    return true;
  };
  auto closePart = [&]() -> bool {
    if (!put() || !sink.close(err))
      return false;
    const uint64_t n = sink.bytes();
    s.total += n;
    s.written.push_back(sink.path());
    emitEvent({"saved", s.fn, sink.path(), 1.0, formatBytes(n)});
    return true;
  };
  auto openPart = [&]() -> bool {
    part++;
    firstBlock = true;
    partText = 0;
    if (!sink.open(partPath(), s.append && !s.splitAt, err))
      return false;
    return sink.compression(s.compress, s.level, err);
  };
  auto headerOf = [&](const Table &t, bool skip) {
    const bool header = !skip && (s.hdrMode == "true" || s.hdrMode == "1" || (s.hdrMode == "auto" && !generatedNames(t)));
    std::string h;
    if (header) {
      for (size_t c = 0; c < t.cols.size(); c++) {
        if (c)
          h += s.dlm;
        h += quoteField(t.cols[c], s.dlm, s.quoteAll);
      }
      h += "\n";
    }
    return h;
  };
  if (!openPart())
    return -1;
  if (!s.append)
    for (const auto &bx : s.boxes)
      block += quoteField(bx, s.dlm, false) + "\n";
  const bool marked = sheets.size() > 1 || !sheets[0].first.empty();
  size_t totalRows = 0, doneRows = 0;
  for (const auto &sh : sheets)
    totalRows += sh.second.rowCount();
  for (size_t si = 0; si < sheets.size(); si++) {
    const Table &t = sheets[si].second;
    if (marked && !sheets[si].first.empty()) {
      std::string marker = secFmt;
      const size_t at = marker.find("{name}");
      if (at != std::string::npos)
        marker.replace(at, 6, sheets[si].first);
      if (si > 0 || !block.empty() || sink.rawBytes() > 0)
        block += "\n";
      block += marker + "\n";
    }
    const std::string header = headerOf(t, s.append && si == 0 && !marked);
    block += header;
    partText = block.size();
    const size_t nrows = t.rowCount();
    std::string line;
    for (size_t r = 0; r < nrows; r++) {
      line.clear();
      appendRow(t, r, s.dlm, s.quoteAll, s.floatFmt, line);
      if (s.splitAt && partText + line.size() > s.splitAt && partText > header.size()) {
        if (!closePart() || !openPart())
          return -1;
        block = header;
        partText = header.size();
      }
      block += line;
      partText += line.size();
      if (block.size() >= kBlock) {
        if (!put())
          return -1;
        if (saveProgress(totalRows ? static_cast<double>(doneRows + r + 1) / static_cast<double>(totalRows) : 1.0)) {
          err = "cancelled";
          return -1;
        }
      }
    }
    doneRows += nrows;
  }
  if (!closePart())
    return -1;
  if (s.budget && s.total > s.budget) {
    err = "the output is " + formatBytes(s.total) + ", over max_size " + formatBytes(s.budget) +
          " (try compress=\"gz\", fewer rows, or a larger max_size)";
    return -1;
  }
  return static_cast<long long>(s.total);
}

// save_<fmt>(file, data, sheets, sec_fmt, boxes, dlm, hdr, quote, float_fmt,
//            enc, compress, level, max_size, mode, split, split_size)
Value saveDelimited(const std::string &fn, const std::string &defDlm, const std::vector<Value> &a,
                    CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  const std::string secFmt = optText(a[3], "# [Sheet: {name}]");
  std::vector<std::string> boxes = optTextList(a[4]);
  std::string dlm = normalizeDelimiter(optText(a[5], defDlm));
  if (dlm == "auto")
    dlm = "ws";
  std::string hdrMode = a[6].isBool() ? (a[6].number != 0 ? "true" : "false")
                                      : lower(optText(a[6], "auto"));
  const std::string quote = lower(optText(a[7], "minimal"));
  if (quote != "minimal" && quote != "all") {
    ctx.fail("quote must be \"minimal\" or \"all\"");
    return Value(0.0);
  }
  const std::string floatFmt = optText(a[8], "");
  const std::string enc = optText(a[9], "utf-8");
  const std::string compress = optText(a[10], "none");
  const int level = static_cast<int>(optInt(a[11], -1));
  const std::string mode = lower(optText(a[13], "w"));
  const bool split = optBool(a[14], false);
  if (mode != "w" && mode != "a") {
    ctx.fail("mode must be \"w\" (write) or \"a\" (append)");
    return Value(0.0);
  }
  std::vector<std::pair<std::string, Table>> sheets;
  if (given(a[2]) && !collectSheets(a[2], sheets, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (isObjectOf(a[1], "NcWorkbook")) { // its sheets; one sheet is written as a plain table
    std::vector<std::pair<std::string, Table>> wbSheets;
    if (!collectSheets(a[1], wbSheets, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (wbSheets.size() == 1)
      wbSheets[0].first.clear();
    sheets.insert(sheets.begin(), wbSheets.begin(), wbSheets.end());
  } else if (given(a[1])) {
    Table t;
    if (!valueToTable(a[1], t, err, true, true)) {
      ctx.fail(err);
      return Value(0.0);
    }
    sheets.insert(sheets.begin(), {"", t});
  }
  if (sheets.empty()) {
    ctx.fail("nothing to save - give data or sheets");
    return Value(0.0);
  }
  const bool append = mode == "a" && fileExists(file) && fileSize(file) > 0;
  auto render = [&](const std::vector<std::pair<std::string, Table>> &list, bool withBoxes,
                    std::string &text) {
    if (withBoxes)
      for (const auto &bx : boxes)
        text += quoteField(bx, dlm, false) + "\n";
    const bool marked = list.size() > 1 || !list[0].first.empty();
    for (size_t s = 0; s < list.size(); s++) {
      if (marked && !list[s].first.empty()) {
        std::string marker = secFmt;
        size_t at = marker.find("{name}");
        if (at != std::string::npos)
          marker.replace(at, 6, list[s].first);
        if (s > 0 || !text.empty())
          text += "\n";
        text += marker + "\n";
      }
      writeTable(list[s].second, dlm, hdrMode, quote == "all", floatFmt, append && s == 0 && !marked,
                 text);
    }
  };
  auto finish = [&](const std::string &path, std::string text, bool app) -> long long {
    std::string bytes;
    if (!encodeText(text, enc, bytes, err) || !applyCompression(compress, level, bytes, err) ||
        !checkMaxSize(a[12], bytes.size(), err) || !writeFile(path, bytes, app, err)) {
      ctx.fail(err);
      return -1;
    }
    emitEvent({"saved", fn, path, 1.0, formatBytes(bytes.size())});
    return static_cast<long long>(bytes.size());
  };
  long long total = 0;
  if (split && sheets.size() > 1) {
    std::string ext = extensionOf(file);
    for (const auto &s : sheets) {
      std::string text;
      render({s}, true, text);
      std::string name = s.first.empty() ? "Main" : s.first;
      long long n = finish(file + "_" + name + (ext.empty() ? "" : "." + ext), text, false);
      if (n < 0)
        return Value(0.0);
      total += n;
    }
  } else if (dlm == "ws") { // aligned columns need every row's width first: built whole
    if (given(a[15])) {
      ctx.fail("split_size= needs a delimiter (dlm=\",\", \"\\t\", ...) - aligned columns are written whole");
      return Value(0.0);
    }
    std::string text;
    render(sheets, !append, text);
    long long n = finish(file, text, append);
    if (n < 0)
      return Value(0.0);
    total = n;
  } else { // streamed block by block (E6)
    StreamText st;
    st.fn = fn;
    st.file = file;
    st.enc = enc;
    st.compress = compress;
    st.level = level;
    st.dlm = dlm;
    st.hdrMode = hdrMode;
    st.floatFmt = floatFmt;
    st.quoteAll = quote == "all";
    st.append = append;
    st.boxes = boxes;
    if (given(a[12]) && !parseByteSize(optText(a[12]), st.budget)) {
      ctx.fail("max_size \"" + optText(a[12]) + "\" is not a size (write e.g. \"48kb\", \"5mb\")");
      return Value(0.0);
    }
    if (given(a[15])) {
      if (!parseByteSize(optText(a[15]), st.splitAt) || st.splitAt == 0) {
        ctx.fail("split_size \"" + optText(a[15]) + "\" is not a size (write e.g. \"100mb\")");
        return Value(0.0);
      }
      if (mode == "a") {
        ctx.fail("split_size= writes new part files - it cannot append (mode=\"a\")");
        return Value(0.0);
      }
      if (sheets.size() > 1 || !sheets[0].first.empty()) {
        ctx.fail("split_size= splits one table - for several sheets use split=true");
        return Value(0.0);
      }
    }
    {
      std::string perr;
      FileSink probe; // the codec is checked before anything is written
      if (!probe.compression(compress, level, perr)) {
        ctx.fail(perr);
        return Value(0.0);
      }
    }
    std::string serr;
    const long long n = streamSheets(st, sheets, secFmt, serr);
    if (n < 0) {
      ctx.fail(serr);
      return Value(0.0);
    }
    total = n;
  }
  ev.ok = true;
  return Value(static_cast<double>(total));
}

Value sheetMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *names = field(a[0], "sheets");
  std::vector<std::string> list = optTextList(names ? *names : Value(std::string()));
  std::string want;
  if (numpy::isPlainNumber(a[1])) {
    size_t k = static_cast<size_t>(a[1].number);
    if (k < 1 || k > list.size()) {
      ctx.fail("sheet " + std::to_string(k) + " does not exist (there are " +
               std::to_string(list.size()) + ")");
      return Value(0.0);
    }
    want = list[k - 1];
  } else {
    want = optText(a[1]);
  }
  for (const auto &n : list)
    if (n == want || lower(n) == lower(want)) {
      const Value *t = field(a[0], fieldName(n));
      if (t)
        return *t;
    }
  ctx.fail("no sheet '" + want + "'");
  return Value(0.0);
}

} // namespace

void registerDelimited(Registry &reg) {
  struct Fmt {
    const char *ext, *dlm, *title;
  };
  const Fmt fmts[] = {{"csv", ",", "comma-separated values"},
                      {"tsv", "\\t", "tab-separated values"},
                      {"txt", "\\s+", "plain / structured text table"},
                      {"dat", "auto", "generic scientific/tabular data"}};
  for (const Fmt &f : fmts) {
    const std::string ext = f.ext, dlm = f.dlm;
    addMulti(reg, "read_" + ext,
             "file, sheet=\"\", dlm=\"" + dlm +
                 "\", cols=\"\", rows=\"\", hdr=-1, box=true, cmt=\"#\", skip=0, enc=\"utf-8\", na=\"\", sec_fmt=\"# [Sheet: {name}]\"",
             std::string("read the table of a .") + ext + " file (" + f.title + ")",
             "pandas.read_csv", 2,
             [ext, dlm](const std::vector<Value> &a, size_t nout, std::vector<Value> &out,
                        CallContext &ctx) { readDelimited("read_" + ext, dlm, a, nout, out, ctx); });
    addFn(reg, "load_" + ext,
          "file, dlm=\"" + dlm + "\", hdr=-1, cmt=\"#\", skip=0, enc=\"utf-8\", na=\"\", sec_fmt=\"# [Sheet: {name}]\"",
          std::string("load a .") + ext + " file as an object (sheets, columns, boxes, comments)",
          "pandas.read_csv",
          [ext, dlm](const std::vector<Value> &a, CallContext &ctx) {
            return loadDelimited("load_" + ext, ext, dlm, a, ctx);
          });
    addFn(reg, "save_" + ext,
          "file, data=\"\", sheets=\"\", sec_fmt=\"# [Sheet: {name}]\", boxes=\"\", dlm=\"" + dlm +
              "\", hdr=\"auto\", quote=\"minimal\", float_fmt=\"\", enc=\"utf-8\", compress=\"none\", "
              "level=-1, max_size=\"\", mode=\"w\", split=false, split_size=\"\"",
          std::string("write a table (or several sheets) to a .") + ext + " file",
          "pandas.DataFrame.to_csv",
          [ext, dlm](const std::vector<Value> &a, CallContext &ctx) {
            return saveDelimited("save_" + ext, dlm, a, ctx);
          });
  }
  addFn(reg, "NcDelimited.sheet", "D, name", "one sheet (section) of a loaded delimited file",
        "-", sheetMethod);
}

} // namespace io
} // namespace nc
