// What a file holds, and a small picture of it, for the IDE's Import window
// (ops "probe" and "thumbnail" of "@cmd io" - added 2026-11-14, see
// docs/Import_Window.md).
//
// Both read as little of the file as they can: a probe reads headers,
// footers and tables of contents (a 200 GB parquet costs its footer), a
// thumbnail decodes one picture or one video frame.
#ifndef NC_IO_PROBE_H
#define NC_IO_PROBE_H

#include <string>

#include "../../../data/DataSupport/JsonWriter.h"

namespace nc {
namespace io {

// Writes the probe fields ("kind", ...) into the open JSON object `j`.
// False with `err` when the file cannot be probed at all.
bool probeFile(const std::string &file, const std::string &format, ncdata::JsonWriter &j, std::string &err);

struct Thumbnail {
  std::string png;          // PNG bytes (not yet base64)
  size_t width = 0, height = 0;          // the full picture / frame
  size_t thumbWidth = 0, thumbHeight = 0; // the PNG
  size_t frame = 0;                       // the frame drawn (video, pages)
};
// One picture of `file`: frame `frame` (0-based) or the frame at `time`
// seconds (video; time < 0 = not given), longest side <= maxSide.
bool makeThumbnail(const std::string &file, const std::string &format, long long frame, double time, size_t maxSide,
                   Thumbnail &out, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_PROBE_H
