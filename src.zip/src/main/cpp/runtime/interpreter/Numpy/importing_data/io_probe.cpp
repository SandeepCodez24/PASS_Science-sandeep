// op "probe" and op "thumbnail" of the IDE's Import window - see io_probe.h.
//
// Everything here is portable C++ (no OS calls of its own): files are read
// through SourceBytes / readFile (io_common.h), which map or read them on
// Windows, macOS and Linux alike.
#include "io_probe.h"

#include <algorithm>
#include <cmath>

#include "../../../data/DataSupport/ValueJson.h"
#include "../numpy_common.h"
#include "io_audio.h"
#include "io_columnar.h"
#include "io_common.h"
#include "io_h5.h"
#include "io_headers.h"
#include "io_image.h"
#include "io_net.h"
#include "io_session.h"
#include "io_sheet.h"
#include "io_video.h"

namespace nc {
namespace io {
namespace {

using ncdata::JsonWriter;

constexpr uint64_t kFallbackMax = uint64_t(256) << 20; // load_<fmt> fallback only below this

void numbers(JsonWriter &j, const std::vector<uint64_t> &v) {
  j.beginArray();
  for (uint64_t x : v)
    j.unsignedInteger(x);
  j.endArray();
}

// A value as plain JSON (attributes, tags): numbers, text, lists of them.
void plainJson(JsonWriter &j, const Value &v, int depth = 0) {
  if (depth > 8) {
    j.string(cellText(v));
    return;
  }
  if (v.isText) {
    j.string(v.text());
  } else if (v.isDict || v.isObject) {
    j.beginObject();
    for (const auto &kv : v.dict()) {
      j.key(kv.first);
      plainJson(j, kv.second, depth + 1);
    }
    j.endObject();
  } else if (v.isArray || (v.isMatrix && !v.isND())) {
    std::vector<Value> cells;
    if (v.isArray)
      for (size_t i = 0; i < v.length() && i < 64; i++)
        cells.push_back(v.at(i));
    else
      for (size_t r = 0; r < v.rows() && cells.size() < 64; r++)
        for (size_t c = 0; c < v.rowLength(r) && cells.size() < 64; c++)
          cells.push_back(v.at(r, c));
    j.beginArray();
    for (const auto &c : cells)
      plainJson(j, c, depth + 1);
    j.endArray();
  } else if (numpy::isPlainNumber(v) && !v.isComplex) {
    if (v.isBool())
      j.boolean(v.number != 0);
    else if (std::isfinite(v.number))
      j.number(v.number);
    else
      j.null();
  } else {
    j.string(cellText(v));
  }
}

/* ---- tables ---- */

bool probeText(const std::string &file, const std::string &format, JsonWriter &j, std::string &err) {
  ImportSession s;
  s.setSource(file);
  s.setFormat(format);
  Preview p;
  if (!s.preview(5, p, err))
    return false;
  j.key("kind").string("table");
  j.key("rows").integer(p.totalExact ? static_cast<long long>(p.totalRows) : -1);
  j.key("rows_estimate").integer(p.totalExact ? static_cast<long long>(p.totalRows) : p.totalEstimate);
  j.key("cols").beginArray();
  for (const auto &c : p.cols) {
    j.beginObject();
    j.key("name").string(c);
    j.endObject();
  }
  j.endArray();
  j.key("boxes");
  j.beginArray();
  for (const auto &b : p.boxes)
    j.string(b);
  j.endArray();
  return true;
}

bool probeColumnar(const std::string &file, const std::string &format, JsonWriter &j, std::string &err) {
  SourceBytes src;
  if (!src.open(file, err))
    return false;
  ColReadOptions o;
  o.metaOnly = true;
  ColFile f;
  const bool ok = format == "parquet"  ? readParquet(src.view(), o, f, err)
                  : format == "orc"    ? readOrc(src.view(), o, f, err)
                                       : readArrowIpc(src.view(), o, f, err);
  if (!ok)
    return false;
  j.key("kind").string("table");
  j.key("rows").unsignedInteger(f.totalRows);
  j.key("rows_estimate").unsignedInteger(f.totalRows);
  j.key("cols").beginArray();
  for (size_t k = 0; k < f.table.cols.size(); k++) {
    j.beginObject();
    j.key("name").string(f.table.cols[k]);
    j.key("type").string(k < f.types.size() ? f.types[k] : "");
    j.endObject();
  }
  j.endArray();
  j.key("groups").unsignedInteger(f.groups.size());
  j.key("group_rows").beginArray();
  for (const auto &g : f.groups)
    j.unsignedInteger(g.rows);
  j.endArray();
  j.key("codec").string(f.codec);
  j.key("created_by").string(f.createdBy);
  j.key("skipped").beginArray();
  for (const auto &s : f.skipped)
    j.string(s);
  j.endArray();
  return true;
}

bool probeWorkbook(const std::string &file, const std::string &format, JsonWriter &j, std::string &err) {
  SourceBytes src; // mapped: the zip directory and the sheet parts only
  if (!src.open(file, err))
    return false;
  Workbook wb;
  const bool ok = format == "xls"    ? readXls(std::string(src.view()), wb, err)
                  : format == "xlsb" ? readXlsb(src.view(), wb, err)
                                     : readXlsx(src.view(), wb, err);
  if (!ok)
    return false;
  j.key("kind").string("workbook");
  j.key("active").unsignedInteger(wb.active);
  j.key("sheets").beginArray();
  for (const auto &s : wb.sheets) {
    j.beginObject();
    j.key("name").string(s.name);
    size_t r0, c0, r1, c1;
    if (s.usedRange(r0, c0, r1, c1)) {
      j.key("range").string(addressOf(r0, c0) + ":" + addressOf(r1, c1));
      j.key("rows").unsignedInteger(r1 - r0 + 1);
      j.key("cols").unsignedInteger(c1 - c0 + 1);
    } else {
      j.key("range").string("");
      j.key("rows").unsignedInteger(0);
      j.key("cols").unsignedInteger(0);
    }
    j.key("charts").unsignedInteger(s.charts);
    j.endObject();
  }
  j.endArray();
  return true;
}

bool probeDatabase(const std::string &file, JsonWriter &j, std::string &err) {
  std::vector<Value> res;
  if (!callIoFunction("read_sqlite",
                      {{"query", "\"SELECT name FROM sqlite_master WHERE type IN ('table', 'view') ORDER BY name\""}},
                      file, 1, res, err))
    return false;
  std::vector<std::string> names = optTextList(res[0]);
  if (!names.empty() && names.front() == "name")
    names.erase(names.begin()); // a header row
  j.key("kind").string("database");
  j.key("tables").beginArray();
  for (const auto &n : names) {
    j.beginObject();
    j.key("name").string(n);
    std::vector<Value> cnt;
    std::string e2, quotedName;
    for (char c : n)
      quotedName += c == ']' ? std::string("]]") : std::string(1, c);
    std::string q = "SELECT COUNT(*) FROM [" + quotedName + "]";
    if (callIoFunction("read_sqlite", {{"query", "\"" + q + "\""}}, file, 1, cnt, e2)) {
      std::vector<double> v = optNumbers(cnt[0]);
      double last = -1;
      for (double x : v)
        if (std::isfinite(x))
          last = x;
      j.key("rows").integer(static_cast<long long>(last));
    } else {
      j.key("rows").integer(-1);
    }
    j.endObject();
  }
  j.endArray();
  return true;
}

/* ---- scientific containers ---- */

std::string h5TypeName(const H5Type &t) {
  switch (t.cls) {
  case H5Type::Fixed:
    return (t.sign ? "int" : "uint") + std::to_string(t.size * 8);
  case H5Type::Float:
    return "float" + std::to_string(t.size * 8);
  case H5Type::String:
    return "string";
  case H5Type::VarLen:
    return t.vlenString ? "string" : "vlen";
  case H5Type::Compound:
    return "compound";
  case H5Type::Enum:
    return "enum";
  case H5Type::Reference:
    return "reference";
  case H5Type::Array:
    return "array";
  case H5Type::Bitfield:
    return "bitfield";
  case H5Type::Time:
    return "time";
  default:
    return "opaque";
  }
}

std::string h5Filter(const H5Object &o) {
  std::string s;
  for (const auto &f : o.filters) {
    std::string n = f.id == 1 ? "gzip" : f.id == 2 ? "shuffle" : f.id == 3 ? "fletcher32" : f.id == 4 ? "szip"
                  : f.id == 32000 ? "lzf" : f.id == 32015 ? "zstd" : "filter " + std::to_string(f.id);
    s += (s.empty() ? "" : "+") + n;
  }
  return s.empty() ? "none" : s;
}

void h5Nodes(const H5Reader &r, const H5Object &o, JsonWriter &j, size_t &count) {
  if (count >= 10000)
    return;
  count++;
  j.beginObject();
  j.key("path").string(o.path.empty() ? "/" : o.path);
  if (!o.softTarget.empty()) {
    j.key("kind").string("link");
    j.key("target").string(o.softTarget);
  } else if (o.group) {
    j.key("kind").string("group");
  } else {
    j.key("kind").string("dataset");
    j.key("shape");
    numbers(j, o.scalar ? std::vector<uint64_t>{} : o.dims);
    j.key("dtype").string(h5TypeName(o.type));
    j.key("chunks");
    numbers(j, o.layout == 2 ? o.chunk : std::vector<uint64_t>{});
    j.key("filter").string(h5Filter(o));
  }
  j.key("attrs");
  plainJson(j, h5AttrsDict(o, &r));
  j.endObject();
  for (const auto &k : o.kids)
    h5Nodes(r, k, j, count);
}

bool probeH5(const std::string &file, JsonWriter &j, std::string &err) {
  SourceBytes src; // mapped: only the object headers are read
  if (!src.open(file, err))
    return false;
  H5Reader r;
  if (!r.open(src.view(), err))
    return false;
  j.key("kind").string("tree");
  j.key("nodes").beginArray();
  size_t count = 0;
  h5Nodes(r, r.root, j, count);
  j.endArray();
  if (count >= 10000)
    j.key("note").string("the first 10000 objects");
  return true;
}

/* ---- media ---- */

bool probeVideo(const std::string &file, JsonWriter &j, std::string &err) {
  VideoProbe v;
  if (!probeVideoFile(file, v, err))
    return false;
  j.key("kind").string("video");
  j.key("width").unsignedInteger(v.width);
  j.key("height").unsignedInteger(v.height);
  j.key("fps").number(v.fps);
  j.key("frames").unsignedInteger(v.frames);
  j.key("duration").number(v.duration);
  j.key("codec").string(v.codec);
  j.key("container").string(v.container);
  j.key("subtitles").unsignedInteger(v.subtitles);
  j.key("chapters").unsignedInteger(v.chapters);
  j.key("audio");
  if (v.hasAudio) {
    j.beginObject();
    j.key("rate").unsignedInteger(v.audioRate);
    j.key("channels").unsignedInteger(v.audioChannels);
    j.key("codec").string(v.audioCodec);
    j.endObject();
  } else {
    j.null();
  }
  j.key("limits").beginObject();
  j.key("values").unsignedInteger(kVideoValueLimit);
  j.endObject();
  return true;
}

bool probeAudio(const std::string &file, const std::string &format, JsonWriter &j, std::string &err) {
  Audio a;
  if (!probeAudioFile(format, file, a, err))
    return false;
  j.key("kind").string("audio");
  j.key("rate").unsignedInteger(a.fs);
  j.key("channels").unsignedInteger(a.channels);
  j.key("frames").unsignedInteger(a.frames);
  j.key("duration").number(a.duration());
  j.key("bits").integer(a.bits);
  j.key("codec").string(a.codec);
  j.key("decodable").boolean(format == "wav" || format == "flac");
  j.key("tags").beginObject();
  for (const auto &t : a.tags)
    j.key(t.first).string(t.second);
  j.endObject();
  return true;
}

/* ---- header-only probes (added 2026-11-14): never the data ---- */

void treeJson(JsonWriter &j, const std::vector<ProbeNode> &nodes) {
  j.key("kind").string("tree");
  j.key("nodes").beginArray();
  for (const auto &n : nodes) {
    j.beginObject();
    j.key("path").string(n.path);
    j.key("kind").string(n.kind);
    if (n.kind == "dataset") {
      j.key("shape");
      numbers(j, n.shape);
      j.key("dtype").string(n.dtype);
      j.key("chunks");
      numbers(j, {});
      j.key("filter").string("none");
    }
    for (const auto &kv : n.extra) {
      j.key(kv.first);
      plainJson(j, kv.second);
    }
    j.key("attrs");
    plainJson(j, Value(n.attrs));
    j.endObject();
  }
  j.endArray();
}

// kind "object" as the load_ fallback writes it - the fields of `v`, plus
// the data fields that were not built (their class and size only).
void objectJson(JsonWriter &j, const Value &v, const std::vector<LazyField> &lazy) {
  j.key("kind").string("object");
  j.key("class").string(ncdata::classOf(v));
  struct Row {
    std::string name, cls, size;
    const Value *value;
  };
  std::vector<Row> rows;
  if (v.isDict || v.isObject)
    for (const auto &kv : v.dict())
      rows.push_back({kv.first, ncdata::classOf(kv.second), ncdata::sizeOf(kv.second), &kv.second});
  for (const auto &l : lazy) {
    bool dup = false;
    for (const auto &r : rows) dup = dup || r.name == l.name;
    if (!dup) rows.push_back({l.name, l.cls, l.size, nullptr});
  }
  std::sort(rows.begin(), rows.end(), [](const Row &a, const Row &b) { return a.name < b.name; });
  j.key("fields").beginArray();
  for (const auto &r : rows) {
    j.beginObject();
    j.key("name").string(r.name);
    j.key("class").string(r.cls);
    j.key("size").string(r.size);
    if (r.value && (r.value->isText || (numpy::isPlainNumber(*r.value) && !r.value->isComplex))) {
      j.key("value");
      plainJson(j, *r.value);
    }
    j.endObject();
  }
  j.endArray();
  j.key("header_only").boolean(true);
}

// True when this format has a header probe; `done` = it wrote the answer.
bool probeHeader(const std::string &file, const std::string &format, JsonWriter &j, bool &done, std::string &err) {
  done = false;
  if (isUrl(file)) return true; // a URL is fetched whole anyway: the load_ fallback
  std::vector<LazyField> lazy;
  Value obj;
  if (format == "nc" || format == "cdf") {
    std::string fmt;
    std::vector<Value> dims;
    std::vector<ProbeNode> nodes;
    if (!netcdfClassicTree(file, fmt, dims, nodes, err)) return err.empty(); // not classic: fall through
    treeJson(j, nodes);
    j.key("format_version").string(fmt);
    j.key("dims");
    plainJson(j, Value(dims));
    done = true;
    return true;
  }
  if (format == "fits" || format == "fit") {
    std::vector<ProbeNode> nodes;
    if (!fitsTree(file, nodes, err)) return false;
    treeJson(j, nodes);
    done = true;
    return true;
  }
  if (format == "tif" || format == "geotiff") {
    std::vector<Fields> pages;
    if (!geoHeaderObject(format, file, obj, lazy, pages, err)) return false;
    objectJson(j, obj, lazy);
    j.key("pages").beginArray();
    for (const auto &p : pages) plainJson(j, Value(p));
    j.endArray();
    done = true;
    return true;
  }
  if (format == "tiff" || format == "dicom") {
    if (!imageHeaderObject(format, file, obj, lazy, err)) return false;
    objectJson(j, obj, lazy);
    if (const Value *w = field(obj, "width")) j.key("width").number(w->number);
    if (const Value *h = field(obj, "height")) j.key("height").number(h->number);
    if (const Value *c = field(obj, "channels")) j.key("channels").number(c->number);
    size_t frames = 1;
    for (const auto &l : lazy)
      if (l.name == "frames") frames = static_cast<size_t>(std::atoll(l.size.substr(2).c_str()));
    j.key("frames").unsignedInteger(frames);
    if (format == "dicom")
      if (const Value *t = field(obj, "tags")) {
        j.key("tags");
        plainJson(j, *t);
      }
    done = true;
    return true;
  }
  if (format == "shp" || format == "shx" || format == "dbf") {
    Fields header;
    if (!shapeHeaderObject(format, file, obj, lazy, header, err)) return false;
    objectJson(j, obj, lazy);
    for (const auto &kv : header) {
      j.key(kv.first);
      plainJson(j, kv.second);
    }
    done = true;
    return true;
  }
  return true;
}

/* ---- everything else: the load_ object, summarised ---- */

bool probeObject(const std::string &file, const std::string &format, JsonWriter &j, std::string &err) {
  const std::string fn = format == "ndat" ? "ndat_info" : "load_" + format;
  if (format != "ndat" && !isUrl(file) && fileSize(file) > kFallbackMax) {
    j.key("kind").string("unknown");
    j.key("note").string("no header probe for ." + format + " files yet, and the file is too big to load for one");
    return true;
  }
  std::vector<Value> res;
  if (!callIoFunction(fn, {}, file, 1, res, err))
    return false;
  const Value &v = res[0];
  if (format == "ndat") {
    // ndat_info: the table of contents, one object per entry
    j.key("kind").string("bundle");
    for (const char *k : {"version", "created", "root"})
      if (const Value *f = field(v, k)) {
        j.key(k);
        plainJson(j, *f);
      }
    j.key("entries").beginArray();
    if (const Value *e = field(v, "entries")) {
      const char *cols[] = {"name", "encoding", "kind", "shape", "bytes", "note"};
      std::vector<std::vector<std::string>> c;
      for (const char *k : cols)
        c.push_back(field(*e, k) ? optTextList(*field(*e, k)) : std::vector<std::string>{});
      for (size_t r = 0; r < c[0].size(); r++) {
        j.beginObject();
        for (size_t k = 0; k < c.size(); k++) {
          const std::string val = r < c[k].size() ? c[k][r] : "";
          if (std::string(cols[k]) == "bytes")
            j.key(cols[k]).number(std::atof(val.c_str()));
          else
            j.key(cols[k]).string(val);
        }
        j.endObject();
      }
    }
    j.endArray();
    return true;
  }
  j.key("kind").string("object");
  j.key("class").string(ncdata::classOf(v));
  j.key("fields").beginArray();
  if (v.isDict || v.isObject) {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      const Value &f = v.dict().at(k);
      j.beginObject();
      j.key("name").string(k);
      j.key("class").string(ncdata::classOf(f));
      j.key("size").string(ncdata::sizeOf(f));
      if (f.isText || (numpy::isPlainNumber(f) && !f.isComplex)) {
        j.key("value");
        plainJson(j, f);
      }
      j.endObject();
    }
  }
  j.endArray();
  return true;
}

/* ---- thumbnails ---- */

// Row-major numbers of shape (H, W) / (H, W, C) / (1, H, W, C) -> 8-bit Image.
bool toPicture(const Value &v, Image &img, std::string &err) {
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!ndToRowMajor(v, shape, vals)) {
    err = "the data is not a picture";
    return false;
  }
  while (shape.size() > 3 && shape.front() == 1)
    shape.erase(shape.begin());
  if (shape.size() == 3 && shape[2] > 4) { // a cube (FITS / HDF): its first plane
    const size_t plane = shape[1] * shape[2];
    vals.resize(plane);
    shape = {shape[1], shape[2]};
  }
  if (shape.size() < 2 || shape.size() > 3) {
    err = "the data is not a picture";
    return false;
  }
  img = Image();
  img.height = shape[0];
  img.width = shape[1];
  size_t ch = shape.size() == 3 ? shape[2] : 1;
  // more than 4 bands (geo rasters): the first 3
  std::vector<double> px;
  const size_t keep = ch > 4 ? 3 : ch;
  px.reserve(img.width * img.height * keep);
  for (size_t p = 0; p < img.width * img.height; p++)
    for (size_t c = 0; c < keep; c++)
      px.push_back(vals[p * ch + c]);
  img.channels = keep;
  // scale to 0..255 unless it already is 8-bit
  double lo = INFINITY, hi = -INFINITY;
  bool whole = true;
  for (double x : px)
    if (std::isfinite(x)) {
      lo = std::min(lo, x);
      hi = std::max(hi, x);
      whole = whole && x == std::floor(x);
    }
  const bool byte = whole && lo >= 0 && hi <= 255;
  for (double &x : px) {
    if (!std::isfinite(x))
      x = 0;
    else if (!byte)
      x = hi > lo ? (x - lo) / (hi - lo) * 255.0 : 0;
    x = std::round(std::clamp(x, 0.0, 255.0));
  }
  img.px = std::move(px);
  img.bitDepth = 8;
  img.isFloat = false;
  return true;
}

} // namespace

bool probeFile(const std::string &file, const std::string &format, JsonWriter &j, std::string &err) {
  const std::string fam = optionHelpFamily(format);
  j.key("bytes").unsignedInteger(isUrl(file) ? 0 : fileSize(file));
  if (fam == "text")
    return probeText(file, format, j, err);
  if (fam == "col")
    return probeColumnar(file, format, j, err);
  if (fam == "sheet")
    return probeWorkbook(file, format, j, err);
  if (format == "sqlite")
    return probeDatabase(file, j, err);
  if (fam == "video")
    return probeVideo(file, j, err);
  if (fam == "audio")
    return probeAudio(file, format, j, err);
  if (fam == "h5")
    return probeH5(file, j, err);
  if (format == "mat" || format == "nc" || format == "cdf") {
    // v7.3 MAT-files and NetCDF-4 are HDF5 inside: the dataset tree
    std::string head, e2;
    if (readFileHead(file, 1 << 20, head, e2) && head.find("\x89HDF\r\n\x1a\n") != std::string::npos)
      return probeH5(file, j, err);
  }
  bool done = false;
  if (!probeHeader(file, format, j, done, err))
    return false;
  if (done)
    return true;
  return probeObject(file, format, j, err);
}

bool makeThumbnail(const std::string &file, const std::string &format, long long frame, double time, size_t maxSide,
                   Thumbnail &out, std::string &err) {
  const std::string fam = optionHelpFamily(format);
  std::vector<std::pair<std::string, std::string>> opts;
  out = Thumbnail();
  out.frame = frame < 0 ? 0 : static_cast<size_t>(frame);
  std::string fn = "read_" + format;
  if (fam == "video") {
    if (time >= 0) // the first frame at or after `time`
      opts = {{"time", "[" + numberText(time) + "]"}, {"stride", "1000000000"}};
    else
      opts = {{"frames", "[" + std::to_string(out.frame) + "]"}};
  } else if (fam == "image") {
    if (format == "tiff" || format == "gif" || format == "dicom")
      opts = {{"frame", std::to_string(out.frame)}};
  } else if (fam == "fits" || fam == "h5" || fam == "nc" || fam == "mat" || fam == "col" || fam == "text") {
    // numeric data drawn as a gray picture
  } else if (format == "ndat") {
    fn = "read";
  }
  std::vector<Value> res;
  if (!callIoFunction(fn, opts, file, 1, res, err))
    return false;
  Image img;
  if (!toPicture(res[0], img, err))
    return false;
  out.width = img.width;
  out.height = img.height;
  if (maxSide < 16)
    maxSide = 16;
  if (img.width > maxSide || img.height > maxSide) {
    const double k = static_cast<double>(maxSide) / static_cast<double>(std::max(img.width, img.height));
    const size_t w = std::max<size_t>(1, static_cast<size_t>(std::llround(img.width * k)));
    const size_t h = std::max<size_t>(1, static_cast<size_t>(std::llround(img.height * k)));
    img = resizeImage(img, w, h);
  }
  out.thumbWidth = img.width;
  out.thumbHeight = img.height;
  out.png = encodePng(img, 6, false, {});
  return !out.png.empty();
}

} // namespace io
} // namespace nc
