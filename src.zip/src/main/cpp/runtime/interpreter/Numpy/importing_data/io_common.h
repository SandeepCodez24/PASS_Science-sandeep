// Shared pieces of the read_* / load_* / save_* functions (Functions_Importing
// _Data.pdf): option reading, files, text encodings, tables, loaded objects,
// progress events, and registration.
//
// Conventions every format follows
//   read_<fmt>(file, ...)   returns the data itself (matrix / cell matrix /
//                           dict / text). [T, info] = read_<fmt>(...) also
//                           returns a dict of what was found around the data
//                           (cols, boxes, comments, ...).
//   load_<fmt>(file, ...)   returns an object (class "Nc<Kind>") read with
//                           dots: D.cols, D.ABC.cols, D.sheet("ABC").
//   save_<fmt>(file, data, ...) writes; returns the number of bytes written.
// Every option is a named input with a default; "" (or -1) means "not
// given", so any subset can be named in any order.
#ifndef NC_IO_COMMON_H
#define NC_IO_COMMON_H

#include <atomic>
#include <cmath>
#include <memory>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

#include "../numpy_registry.h"

namespace nc {
namespace io {

using numpy::CallContext;
using numpy::Registry;
using Fields = std::unordered_map<std::string, Value>;

// ---- progress / events (the UI hooks - see io_session.h) -----------------

struct IoEvent {
  std::string kind;     // "open", "progress", "done", "error", "saved"
  std::string function; // "read_csv"
  std::string file;
  double fraction = 0;  // 0..1 for "progress"
  std::string message;
};
using IoListener = std::function<void(const IoEvent &)>;
void setIoListener(IoListener listener); // empty function = no listener
void emitEvent(const IoEvent &e);
// Readers call this inside long loops; true = the user cancelled.
bool reportProgress(const std::string &function, const std::string &file, double fraction);
void requestCancel();
void clearCancel();
bool cancelRequested();

// ---- options --------------------------------------------------------------

// False for the "not given" markers: "" text, an empty array/matrix.
bool given(const Value &v);
std::string optText(const Value &v, const std::string &def = "");
bool optBool(const Value &v, bool def);
long long optInt(const Value &v, long long def);
double optNumber(const Value &v, double def);
// "A" or ["A", "B"] or 1xN / Nx1 text matrix -> list of texts.
std::vector<std::string> optTextList(const Value &v);
// Numbers of a number / array / matrix / range, flattened.
std::vector<double> optNumbers(const Value &v);
std::string lower(std::string s);
std::string trim(const std::string &s);

// A run of positions written as text (added 2026-11-14 for the Import
// window): "10:" / "10:-1" = row 10 to the end, "1:3:12" = 1, 4, 7, 10,
// "5:2:" = every 2nd from 5 to the end, "-100:-1" = the last 100. Positions
// are 1-based; a negative one counts from the end (-1 = the last), as NC's
// own index -1 does. A span needs the count to be expanded.
struct Span {
  long long start = 1, step = 1, stop = -1; // stop is inclusive
};
// "a:b", "a:", "a:s:b", "a:s:" -> span. False when `text` is not one.
bool parseSpan(const std::string &text, Span &out);
// The 0-based indices of `s` over `count` items (stop clipped to the end).
void expandSpan(const Span &s, size_t count, std::vector<size_t> &out);

// A column / row / sheet selection: 1-based positions, spans, or names.
struct Selector {
  bool all = true;
  std::vector<long long> positions; // 1-based
  std::vector<Span> spans;          // "10:" "1:3:12" ... (resolved with the count)
  std::vector<std::string> names;
  // The largest 1-based position the selection can touch, when that is
  // known without the count (no names, no open or negative end). Readers
  // use it to stop early: rows=[1:200] needs only 200 rows.
  bool lastPosition(long long &last) const;
};
bool parseSelector(const Value &v, Selector &out, std::string &err);
// Applies a selector to `count` items with names `names` -> 0-based indices.
bool resolveSelector(const Selector &sel, const std::vector<std::string> &names, size_t count,
                     std::vector<size_t> &out, std::string &err);
// The largest row a rows= option can touch (see Selector::lastPosition);
// false = all rows may be needed.
bool rowsUpperBound(const Value &rows, long long &last);

// "48kb", "5mb", "2 GB", "1200" -> bytes. False when it is not a size.
bool parseByteSize(const std::string &text, uint64_t &bytes);
std::string formatBytes(uint64_t n);

// ---- files ----------------------------------------------------------------

std::filesystem::path resolvePath(const std::string &path);
bool readFile(const std::string &path, std::string &bytes, std::string &err);
bool writeFile(const std::string &path, const std::string &bytes, bool append, std::string &err);
bool fileExists(const std::string &path);
uint64_t fileSize(const std::string &path);
std::string extensionOf(const std::string &path); // lower case, no dot
bool isUrl(const std::string &s);
// http:// and https:// GET (WinHTTP on Windows). False with err otherwise.
bool fetchUrl(const std::string &url, std::string &bytes, std::string &err);
// A local file or a URL.
bool readSource(const std::string &pathOrUrl, std::string &bytes, std::string &err);

// ---- writing (2026-11-17, docs/Export_Window.md §2) ------------------------
//
// FileSink: a file written piece by piece. Bytes are collected up to 8 MB
// and then written, so a writer that streams its output never holds all of
// it. Every new file is written atomically: the bytes go to
// `<name>.part~<pid>` in the same folder, and only a successful close()
// (outside a save) or the save's commit (inside save_<fmt>, see SaveScope)
// moves it over the target - a failed or stopped save leaves the old file
// whole. append = true writes into the file in place (mode="a"; not atomic).
// writeFile() is a FileSink of one piece.
class FileSink {
public:
  FileSink() = default;
  ~FileSink();
  FileSink(const FileSink &) = delete;
  FileSink &operator=(const FileSink &) = delete;
  bool open(const std::string &path, bool append, std::string &err);
  // gzip around everything written (compress="gz" while streaming); call
  // before the first write. One piece below 8 MB gives exactly the bytes of
  // gzipCompress(); bigger outputs are deflated in 8 MB pieces.
  void gzip(int level);
  // The same with a zlib wrapper (compress="zlib"): zlibCompress()'s bytes.
  void zlib(int level);
  // compress= of the text writers ("none" / "gz" / "zlib" and their aliases);
  // false with err for a codec that is not built in (applyCompression's rule).
  bool compression(const std::string &codec, int level, std::string &err);
  // A byte budget (max_size=): write() fails once the file passes it.
  void budget(uint64_t maxBytes) { budget_ = maxBytes; }
  bool write(std::string_view bytes, std::string &err);
  bool close(std::string &err); // the file is complete
  void abandon();               // stop: delete what was written
  uint64_t bytes() const { return written_ + (gzip_ ? 0 : buf_.size()); } // in the file (compressed)
  uint64_t rawBytes() const { return raw_; }                               // given to write()
  bool isOpen() const { return open_; }
  const std::string &path() const { return path_; }

private:
  bool flush(bool last, std::string &err);
  std::string path_;
  std::filesystem::path target_, temp_;
  void *out_ = nullptr; // std::ofstream
  std::string buf_;
  uint64_t written_ = 0, raw_ = 0, budget_ = 0;
  bool open_ = false, append_ = false, ownTemp_ = false, gzip_ = false, gzStarted_ = false, zlib_ = false;
  int level_ = 6;
  uint32_t crc_ = 0; // crc32 (gzip) or adler32 (zlib) of the bytes given
};

// One save_<fmt>() / save() call (every one is wrapped in a SaveScope by
// addFn / the .ndat registration). While it runs, every new file a writer
// writes (writeFile, FileSink, saveTargetPath) goes to a temporary file;
// commit() then moves them all over their targets - or, with zip=true,
// writes them into one `<file>.zip` (deflate) instead. A scope that ends
// without commit() (an error, Stop, an exception) deletes the temporary
// files. Nested scopes join the outermost one.
struct SaveReport {
  std::string function, file;            // file: the absolute path written (the .zip with zip=true)
  std::vector<std::pair<std::string, uint64_t>> files; // every file written, with its bytes
  uint64_t bytes = 0;                     // of `file` (all files together for split / bundles: see files)
  long long rows = -1, cols = -1;         // of the data, when it is a table / matrix
  double seconds = 0;
  bool ok = false, cancelled = false, zipped = false;
};
class SaveScope {
public:
  SaveScope(const std::string &function, const std::string &file, bool zip, const Value *data);
  ~SaveScope();
  SaveScope(const SaveScope &) = delete;
  SaveScope &operator=(const SaveScope &) = delete;
  bool outer() const { return outer_; }
  bool commit(std::string &err);
  const SaveReport &report() const;

private:
  bool outer_ = false, done_ = false;
};
// The report of the last outermost save on any thread (the IDE's run answer).
SaveReport lastSaveReport();
void clearLastSaveReport();
// For writers that write a file on their own (not through FileSink): the
// path to write instead of `path` - a temporary one inside a save, `path`
// itself outside. The save then treats it like a FileSink's file.
std::string saveTargetPath(const std::string &path);
// Progress of the running save (0..1), polling the IDE's Stop; true = stop.
bool saveProgress(double fraction);

// ---- big files (added 2026-11-14 for files of 20 GB - 500 GB) ------------
//
// `bytes` `n` bytes from `offset` (fewer at the end of the file).
bool readFileRange(const std::string &path, uint64_t offset, size_t n, std::string &bytes,
                   std::string &err);
// The first / last `n` bytes of a file (all of it when it is shorter).
bool readFileHead(const std::string &path, size_t n, std::string &bytes, std::string &err);
bool readFileTail(const std::string &path, size_t n, std::string &bytes, std::string &err);

// A whole file as read-only bytes, without reading it: the file is
// memory-mapped (MapViewOfFile on Windows, mmap on macOS / Linux / any
// POSIX system), so a parser that looks at the footer and one column chunk
// of a 200 GB file only makes the OS read those pages. When mapping is not
// possible (a URL, a gzip file, an exotic file system) the bytes are read
// into memory instead and the view points at them - the parser cannot tell.
class SourceBytes {
public:
  SourceBytes() = default;
  ~SourceBytes();
  SourceBytes(const SourceBytes &) = delete;
  SourceBytes &operator=(const SourceBytes &) = delete;
  // `gunzip`: a gzip file is decompressed into memory (it cannot be mapped).
  bool open(const std::string &pathOrUrl, std::string &err, bool gunzip = false);
  std::string_view view() const { return view_; }
  size_t size() const { return view_.size(); }
  bool mapped() const { return map_ != nullptr; }
  void close();

private:
  std::string owned_;
  std::string_view view_;
  void *map_ = nullptr; // start of the mapping
  uint64_t mapSize_ = 0;
  void *mapHandle_ = nullptr; // Windows mapping object (io_sys_map.cpp); unused elsewhere
};

// Undoes gzip when the bytes start with the gzip magic (any text format may
// be read straight from a .gz written with compress="gz").
bool autoDecompress(std::string &bytes, std::string &err);
// The start of a zlib stream (compress="zlib"); autoDecompress undoes one
// only when it inflates whole and its checksum matches (2026-11-17).
bool looksZlib(std::string_view bytes);
// compress = "", "none", "no" -> unchanged; "gz"/"gzip"/"yes"/"zlib"; others
// -> error naming what is built in. `level` 1..9 (-1 = 6).
bool applyCompression(const std::string &codec, int level, std::string &bytes, std::string &err);
// compress= of the writers that only switch compression on or off (mat, fig,
// png, tiff): off for "none" / "no" / "false" / "off" / 0 / false
// (2026-11-17: "none" - the catalogue's off value - used to mean on).
bool compressOn(const Value &v, bool def = true);
// Checks the byte budget of max_size="48kb" ("" = no budget).
bool checkMaxSize(const Value &maxSize, uint64_t bytes, std::string &err);

// Text encodings: utf-8 (BOM dropped), latin-1 / iso-8859-1 / cp1252,
// utf-16 / utf-16le / utf-16be (BOM honoured), ascii.
bool decodeText(const std::string &raw, const std::string &enc, std::string &utf8,
                std::string &err);
bool encodeText(const std::string &utf8, const std::string &enc, std::string &raw,
                std::string &err);

// ---- values ---------------------------------------------------------------

Value makeObject(const std::string &className, Fields fields);
bool isObjectOf(const Value &v, const std::string &className);
const Value *field(const Value &obj, const std::string &name);
Value textList(const std::vector<std::string> &items);
Value numberList(const std::vector<double> &items);
Value dictOf(const Fields &f);
// A cell of text as read from a file -> number, bool or text. `na` texts
// become NaN.
Value parseCell(const std::string &s, const std::vector<std::string> &na);
bool isNumberCell(const Value &v);
// Shortest text that reads back to the same double ("%.6f" when fmt given).
std::string numberText(double d, const std::string &fmt = "");
std::string cellText(const Value &v, const std::string &floatFmt = "");
// An identifier usable after a dot: "Max Temp (C)" -> "Max_Temp_C".
std::string fieldName(const std::string &raw);
// Unique, non-empty column names: blanks -> Col_<n>, repeats -> Name_2.
std::vector<std::string> uniqueNames(const std::vector<std::string> &raw);

// ---- tables ---------------------------------------------------------------

struct Table {
  std::vector<std::string> cols;
  std::vector<std::vector<Value>> rows; // every row cols.size() long
  // Column form (2026-11-15, docs/Import_Window.md §9): the big-table
  // readers (csv tsv txt dat, parquet, feather, orc) build the cells as one
  // matrix Value by columns (Value::ColumnBuilder) instead of a Value per
  // cell; `rows` is then empty. Read cells through rowCount() / cell(), or
  // call tableToRows() before code that walks `rows`.
  bool columnar = false;
  Value data;
  // The type a column had where it came from, when known: "float64" for a
  // float64 vector of a dict of columns (X3), so whole numbers in it stay
  // float64 instead of being written as int64. Empty (or "") = inferred
  // from the cells, as always. Same length as cols when given.
  std::vector<std::string> declared;
  size_t rowCount() const { return columnar ? data.rows() : rows.size(); }
  Value cell(size_t r, size_t c) const { return columnar ? data.at(r, c) : rows[r][c]; }
};
// Where a table reader puts its cells (2026-11-15): row by row in, one
// Value::ColumnBuilder per column underneath, so no row of Values is ever
// kept. A row shorter than the table, or a table that gets wider further
// down, is padded with NaN - what normalizeTable() does to rows.
class TableSink {
public:
  void reserve(size_t rows) { reserve_ = rows; }
  void cell(const Value &v) { next().push(v); }
  void cell(Value &&v) { next().push(std::move(v)); }
  void number(double d) { next().pushNumber(d); }
  void text(std::string_view s) { next().pushText(s); }
  void missing() { next().pushNumber(missingNumber()); } // a missing cell (an empty / null / NA one)
  // parseCell() of a field; true when it is a number or NaN
  bool parsed(std::string_view raw, const std::vector<std::string> &na);
  void endRow() {
    for (; at_ < cols_.size(); at_++) cols_[at_].pushNumber(missingNumber());
    at_ = 0;
    rows_++;
  }
  void row(std::vector<Value> &&cells) {
    for (auto &v : cells) cell(std::move(v));
    endRow();
  }
  size_t rows() const { return rows_; }
  size_t width() const { return cols_.size(); }
  // The cells as `t`'s column form (t.cols is left as it is).
  void finish(Table &t);

private:
  std::vector<Value::ColumnBuilder> cols_;
  size_t rows_ = 0, at_ = 0, reserve_ = 0;
  Value::ColumnBuilder &next() {
    if (at_ == cols_.size()) { // wider than every row so far
      cols_.emplace_back();
      cols_.back().reserve(reserve_);
      for (size_t r = 0; r < rows_; r++) cols_.back().pushNumber(missingNumber());
    }
    return cols_[at_++];
  }
};

// Finishes every builder (on several cores; each column on its own, so the
// result is the same for any thread count) and empties `builders`.
std::vector<std::shared_ptr<Value::Column>> finishColumns(std::vector<Value::ColumnBuilder> &builders);
// A cell as a writer's int64: an integer Value's exact value (int64 / uint64
// beyond 2^53 included), else the number truncated - what writers did before.
inline int64_t exactInt64(const Value &v) { return v.isInt() ? v.intBits() : static_cast<int64_t>(v.number); }
// std::isspace of the "C" locale NC runs in (space, \t \n \v \f \r), inline -
// it is asked of every cell's first and last characters.
inline bool asciiSpace(char c) { return c == ' ' || (c >= '\t' && c <= '\r'); }
// Column form -> row form (no change for a table already in rows).
void tableToRows(Table &t);
// Rows `rows` x columns `cols` (0-based, in those orders) of a table in either
// form, in the same form; the column form gathers per column (no row of
// Values, a column's text is not copied cell by cell).
Table tableTake(const Table &t, const std::vector<size_t> &rows, const std::vector<size_t> &cols);
// Only the rows `keep`, all columns.
void tableKeepRows(Table &t, const std::vector<size_t> &keep);
// A table in column form from finished columns (each `nrows` long).
void tableFromColumns(Table &t, std::vector<std::shared_ptr<Value::Column>> cols, size_t nrows);
// What parseCell() makes of a field, without making it: NaN (an `na`
// text), Text (`text` = the trimmed field, a view into `raw`), True / False,
// Number (`num`). Thread-safe (readers classify fields on several cores).
// BigInt (2026-11-15): a whole number beyond 2^53 - a float64 would round it -
// is an int64 (`big`), exact; every other number is a float64 (`num`).
enum class FieldKind : uint8_t { NaN, Text, True, False, Number, BigInt };
FieldKind classifyField(std::string_view raw, const std::vector<std::string> &na, std::string_view &text, double &num,
                        int64_t *big = nullptr);
// parseCell() of one field straight into a column (no Value for a text or
// a number). Returns true when the cell is a number or NaN (isNumberCell).
bool pushCell(Value::ColumnBuilder &b, std::string_view raw, const std::vector<std::string> &na);
// The data block: a packed numeric matrix when every cell is a number, a
// cell matrix otherwise. 0 rows -> empty matrix.
Value tableData(const Table &t);
// The same, taking the rows over (no copy of the cells; `t` is left empty).
Value tableData(Table &&t);
// Column `c` as a vector (numeric array or cell array).
Value tableColumn(const Table &t, size_t c);
std::string columnType(const Table &t, size_t c); // int64 float64 bool str datetime empty
Value tableSchema(const Table &t);
// The NcTable object: cols, rows (count), data, schema and one field per
// column (D.Temp). Extra fields are added on top.
Value tableObject(const Table &t, Fields extra = {}, const std::string &cls = "NcTable");
// Any table-like value -> Table: NcTable object, matrix, cell matrix (a text
// first row is a header when `firstRowHeader`), array (one column), dict of
// equal-length columns.
// keepColumns: a big matrix (column storage or packed) stays one Value - the table
// comes back in column form (Table::columnar) instead of a row of Values per
// row; only for callers that read cells through rowCount() / cell().
bool valueToTable(const Value &v, Table &t, std::string &err, bool firstRowHeader = false,
                  bool keepColumns = false);
// Rows / columns selection on a table (1-based selectors).
bool selectTable(Table &t, const Value &cols, const Value &rows, std::string &err);
// Returns a deduplicated list of columns padded to equal length.
void normalizeTable(Table &t);

// Row-major (C order) numbers -> NC array / matrix / N-D matrix of `shape`
// (NC keeps N-D data as column-major pages; this does the reordering).
Value ndFromRowMajor(const std::vector<size_t> &shape, const std::vector<double> &vals);
// NC array / matrix / N-D -> row-major numbers and shape.
bool ndToRowMajor(const Value &v, std::vector<size_t> &shape, std::vector<double> &vals);

// R9 typed results of the readers (2026-11-14). The same as ndFromRowMajor,
// stored as element type `et` (uint8, int16, float32 ...): `vals` must hold
// values that type represents exactly (F64 = ndFromRowMajor itself).
// `exactOnly` false: float32 asked for explicitly (dtype="float32") - values
// are rounded to it instead of keeping float64.
Value typedFromRowMajor(ElemType et, const std::vector<size_t> &shape, const std::vector<double> &vals,
                        bool exactOnly = true);
// The element type a reader gives data it read as `stored` (the file's own
// type, or the dtype= asked for): `stored` itself, except float32 values
// that are not all exact float32 numbers (computed ones, e.g. 32-bit audio
// scaled to -1..1), which stay float64 - nothing is ever lost. float64 data
// is never narrowed (later arithmetic would round to float32).
ElemType smallestLossless(ElemType stored, const std::vector<double> &vals);

// ---- registration ---------------------------------------------------------

using MultiFn = std::function<void(const std::vector<Value> &args, size_t nout,
                                   std::vector<Value> &out, CallContext &ctx)>;
using SingleFn = std::function<Value(const std::vector<Value> &args, CallContext &ctx)>;
// Registers `name` with its parameter line; min/max counts come from it.
void addFn(Registry &reg, const std::string &name, const std::string &params,
           const std::string &summary, const std::string &origin, SingleFn fn);
void addMulti(Registry &reg, const std::string &name, const std::string &params,
              const std::string &summary, const std::string &origin, int maxOutputs, MultiFn fn);
// Every function name registered through addFn/addMulti, for the session API.
const std::vector<std::string> &registeredIoNames();
// Wraps a save implementation in a SaveScope and adds zip= (2026-11-17):
// addFn does this for every save_<fmt> (not the database servers, which
// write no file), the .ndat registration for save(). `params` gets
// ", zip=false"; the implementation never sees zip=.
SingleFn wrapSave(const std::string &name, std::string &params, SingleFn fn);
// True for the functions wrapSave() applies to.
bool savesFile(const std::string &name);

// Wraps a reader with the open/done/error events.
struct EventScope {
  std::string function, file;
  bool ok = false;
  EventScope(const std::string &fn, const std::string &f);
  ~EventScope();
};

} // namespace io
} // namespace nc

#endif // NC_IO_COMMON_H
