// The workbook model shared by xlsx, xlsm, xls and xlsb: every reader fills a
// Workbook, every writer takes one, and read_/load_/save_ for all four
// formats are written once against it (io_spreadsheet.cpp).
#ifndef NC_IO_SHEET_H
#define NC_IO_SHEET_H

#include <functional>
#include <map>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct SheetCell {
  Value v;          // number, bool, text; NaN-free (missing cells are absent)
  std::string fml;  // formula without '=' ("" when none)
  bool bold = false;
  bool hasValue = true; // false: formula without a cached result
};

struct SheetBox {
  std::string pos;  // "H2"
  std::string text;
  std::string kind; // "comment", "textbox"
};

struct Sheet {
  std::string name;
  std::map<std::pair<size_t, size_t>, SheetCell> cells; // (row, col), 0-based
  std::vector<std::string> merged;                      // "A1:C1"
  std::vector<SheetBox> boxes;
  size_t charts = 0, pivots = 0;
  std::string freeze;                                   // "A2"
  std::vector<double> colWidths;                        // characters, by column
  bool loaded = true;                                   // false: skipped by a SheetFilter (name only)
  bool usedRange(size_t &r0, size_t &c0, size_t &r1, size_t &c1) const;
};

struct Workbook {
  std::vector<Sheet> sheets;
  size_t active = 0;
  Fields meta;                 // author, created, modified, title, application
  std::string vbaProject;      // xlsm: raw vbaProject.bin
  std::vector<std::pair<std::string, std::string>> vbaModules; // name, source
  std::vector<std::pair<std::string, size_t>> binBlocks;      // xlsb: part, record count
};

// "B4" <-> (row 3, col 1). Columns: A..Z, AA.. XFD.
bool parseAddress(const std::string &a, size_t &row, size_t &col);
std::string addressOf(size_t row, size_t col);
std::string columnName(size_t col);
bool parseRange(const std::string &r, size_t &r0, size_t &c0, size_t &r1, size_t &c1);

// Evaluates formulas without a cached result (+ - * / ^ & comparisons,
// numbers, text, cell refs, ranges, SUM AVERAGE MIN MAX COUNT ABS ROUND IF
// SQRT PRODUCT CONCAT LEN). Cells it cannot evaluate keep hasValue=false.
void evaluateFormulas(Sheet &s);

// Excel serial date (1900 system) -> "YYYY-MM-DD[ HH:MM:SS]".
std::string excelDateText(double serial);
// Number format code / built-in id that shows a date.
bool isDateFormat(int id, const std::string &code);

// Sheet -> table (range / header detection), and the boxes found outside it.
struct SheetTable {
  Table table;
  std::vector<std::string> boxes; // text outside the table + comments/text boxes
  size_t originRow = 0, originCol = 0, headerRows = 0;
};
bool sheetToTable(const Sheet &s, const std::string &range, long long hdr, bool evalFml,
                  const std::vector<std::string> &na, SheetTable &out, std::string &err);
// Table -> cells starting at `start` (bold header row when it has names).
void tableToSheet(const Table &t, bool header, const std::string &start, Sheet &s);

// What a reader decodes (added 2026-11-14 for big workbooks). Without a
// filter every sheet is read whole.
struct SheetFilter {
  // Called once with the sheet names (file order) and the active sheet:
  // fills `decode` (one flag per sheet). Sheets left out keep their name
  // only (Sheet::loaded = false). False with `err` stops the read.
  std::function<bool(const std::vector<std::string> &names, size_t active, std::vector<bool> &decode,
                     std::string &err)>
      pick;
  // Rows with a 0-based index >= rowLimit are not read (range="A1:G100"
  // needs 100 rows). The xlsx reader cuts the sheet XML there, before
  // parsing it.
  size_t rowLimit = static_cast<size_t>(-1);
};

// Readers / writers (io_xlsx.cpp, io_xls.cpp, io_xlsb.cpp).
bool readXlsx(std::string_view bytes, Workbook &wb, std::string &err, const SheetFilter *filter = nullptr);
std::string writeXlsx(const Workbook &wb, bool macroEnabled, int level);
bool readXls(const std::string &bytes, Workbook &wb, std::string &err, const SheetFilter *filter = nullptr);
bool writeXls(const Workbook &wb, std::string &out, std::string &err);
bool readXlsb(std::string_view bytes, Workbook &wb, std::string &err, const SheetFilter *filter = nullptr);
// MS-OVBA: module names and source from a vbaProject.bin.
void readVbaModules(const std::string &vbaProject, std::vector<std::pair<std::string, std::string>> &out);

} // namespace io
} // namespace nc

#endif // NC_IO_SHEET_H
