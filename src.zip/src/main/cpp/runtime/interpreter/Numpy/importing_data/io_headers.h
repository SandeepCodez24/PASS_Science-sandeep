// Header-only descriptions of a file for op "probe" (io_probe.cpp), added
// 2026-11-14: they read the headers / tables of contents of a file and
// never its data, so a probe costs the same for a 1 MB and a 500 GB file.
// Images and GeoTIFF are in io_image.h (imageHeaderObject, geoHeaderObject).
#ifndef NC_IO_HEADERS_H
#define NC_IO_HEADERS_H

#include <cstdint>
#include <string>
#include <vector>

#include "io_common.h"
#include "io_image.h" // LazyField

namespace nc {
namespace io {

// One node of a probe "tree" (the shape HDF5 files already use).
struct ProbeNode {
  std::string path;            // "/temp" (NetCDF), "0" / "1" (FITS HDU number)
  std::string kind;            // "group" or "dataset"
  std::string dtype;           // int8 ... float64, string, table
  std::vector<uint64_t> shape; // row-major, empty = scalar
  Fields attrs;
  Fields extra;                // further keys of the node (FITS: name, type)
};

// Classic NetCDF (CDF-1 / CDF-2 / CDF-5): the root group (global attributes)
// and one dataset per variable. `dims`: [{name, len, unlimited}]. False with
// err "" when the file is not classic NetCDF (the caller tries HDF5).
bool netcdfClassicTree(const std::string &file, std::string &format, std::vector<Value> &dims,
                       std::vector<ProbeNode> &nodes, std::string &err);

// FITS: one node per HDU, path = its number ("0" = primary), as hdu= takes it.
bool fitsTree(const std::string &file, std::vector<ProbeNode> &nodes, std::string &err);

// Shapefile (.shp / .shx / .dbf): the NcShapefile fields from the headers.
// `header`: shape_type, count, bbox, crs, dbf_fields [{name, type, length, decimals}].
bool shapeHeaderObject(const std::string &fmt, const std::string &file, Value &obj, std::vector<LazyField> &lazy,
                       Fields &header, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_HEADERS_H
