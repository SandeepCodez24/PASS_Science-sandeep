// Raster images shared by png, jpg/jpeg, tiff, bmp, gif, dicom (phase 2) and
// tif/geotiff, avi/mov MJPEG frames (phase 3).
#ifndef NC_IO_IMAGE_H
#define NC_IO_IMAGE_H

#include <array>
#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct Image {
  size_t width = 0, height = 0, channels = 1; // 1 gray, 2 gray+alpha, 3 RGB, 4 RGBA
  int bitDepth = 8;                            // 8, 16, 32
  bool isFloat = false;                        // samples are floating point
  std::vector<double> px;                      // row-major, channels interleaved
  double dpiX = 0, dpiY = 0;
  std::vector<std::pair<std::string, std::string>> text; // tEXt / COM / ImageDescription ...
  std::string colorSpace = "sRGB";
  std::string icc;
  Fields exif;
  Fields extra;               // format specific (DICOM tags, GeoTIFF keys ...)
  std::vector<Image> frames;  // further pages / frames (frame 0 is *this)
  double delay = 0;           // seconds per frame (gif)
  int orientation = 1;        // EXIF orientation (already applied when read)

  double maxValue() const { return isFloat ? 1.0 : (bitDepth >= 16 ? 65535.0 : 255.0); }
  double at(size_t x, size_t y, size_t c) const { return px[(y * width + x) * channels + c]; }
};

// Codecs (io_png.cpp, io_jpeg.cpp, io_tiff.cpp, io_bmpgif.cpp, io_dicom.cpp).
// rowLimit: rows from this one on are not decoded (left 0) - read_png with
// roi= needs the rows down to the bottom of the roi only. Ignored when the
// image is interlaced.
bool decodePng(const std::string &bytes, Image &img, std::string &err, size_t rowLimit = static_cast<size_t>(-1));
std::string encodePng(const Image &img, int level, bool palette, const std::vector<double> &transparent);
// meta = false: pixels only - no EXIF / extra fields, so no Value is made
// (video frames decoded on worker threads).
bool decodeJpeg(const std::string &bytes, Image &img, std::string &err, bool meta = true);
std::string encodeJpeg(const Image &img, int quality, bool subsample420, bool progressive);
// What decodeTiff decodes (default: every pixel of every page read).
struct TiffDecode {
  bool pixels = true;  // false: tags, sizes and layout only (probe, read planning)
  long long page = -1; // >= 0: pixels of this page only (0 = the first); the others header only
  // A window of that page (0-based pixels): only the strips / tiles that
  // cover it are decoded, and the page's px holds just the window - its
  // width / height are then w / h (Image::extra "window" records it).
  size_t x0 = 0, y0 = 0, w = 0, h = 0; // w == 0: the whole page
};
bool decodeTiff(std::string_view bytes, Image &img, std::string &err, bool allFrames,
                const TiffDecode *opt = nullptr);
struct TiffOptions {
  std::string codec = "lzw";    // none, lzw, deflate, packbits
  size_t tile = 0;              // 0 = strips
  bool overviews = false;       // reduced-resolution pages (COG style)
  bool bigtiff = false;
};
std::string encodeTiff(const std::vector<const Image *> &pages, const TiffOptions &opt);
bool decodeBmp(const std::string &bytes, Image &img, std::string &err);
std::string encodeBmp(const Image &img);
bool decodeGif(const std::string &bytes, Image &img, std::string &err);
std::string encodeGif(const std::vector<const Image *> &frames, double fps, int loop, size_t maxColors);
// headerOnly: tags, sizes and frame count from the header (the pixel data
// is not read; px stays empty) - op "probe".
bool decodeDicom(std::string_view bytes, Image &img, std::string &err, bool hu, bool headerOnly = false);
std::string encodeDicom(const Image &img, const Fields &patient, bool anonymize);

// op "probe" (io_probe.cpp): the load_<fmt> object built from the file's
// header alone. A field that would hold the data (pixels, raster, frames)
// is not built; its class and size are listed in `lazy` instead.
struct LazyField {
  std::string name, cls, size; // size as the Variable Explorer writes it: "480x640x3"
};
// tif / tiff / dicom read as images (NcImage)
bool imageHeaderObject(const std::string &fmt, const std::string &file, Value &obj, std::vector<LazyField> &lazy,
                       std::string &err);
// tif / geotiff read as rasters (NcGeoRaster); also one entry per page in `pages`
bool geoHeaderObject(const std::string &fmt, const std::string &file, Value &obj, std::vector<LazyField> &lazy,
                     std::vector<Fields> &pages, std::string &err);

// Conversions.
// (H,W) or (H,W,C); typed uint8 / uint16 / float32 when lossless (R9);
// float32: dtype="float32" was asked for (with asFloat).
Value imageToValue(const Image &img, bool asFloat, bool float32 = false);
bool valueToImage(const Value &v, Image &img, std::string &err);
Image convertChannels(const Image &img, const std::string &mode); // "gray", "rgb", "rgba"
Image cropImage(const Image &img, size_t x, size_t y, size_t w, size_t h);
Image resizeImage(const Image &img, size_t w, size_t h); // bilinear
Image to8bit(const Image &img);
// dtype="uint16": 1 - 16-bit levels kept as they are, deeper / float levels scaled to 0 .. 65535.
Image toUint16(const Image &img);
void applyOrientation(Image &img);                   // EXIF 1..8 -> upright
// Median-cut palette (<= maxColors) for an 8-bit RGB(A) image: indices + palette.
void quantize(const Image &img8, size_t maxColors, std::vector<uint8_t> &indices,
              std::vector<std::array<uint8_t, 4>> &palette);

} // namespace io
} // namespace nc

#endif // NC_IO_IMAGE_H
