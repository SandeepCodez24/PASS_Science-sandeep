// CATEGORY 7 - XML and CATEGORY 8 - HTML: read_/load_/save_ xml, html, htm.
#include <algorithm>
#include <cmath>
#include <functional>
#include <map>
#include <set>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_markup.h"
#include "io_tree.h"

namespace nc {
namespace io {
namespace {

const std::vector<std::string> kNa = {"", "NA", "N/A", "NULL", "null", "NaN"};

bool loadText(const std::string &file, const std::string &enc, std::string &text, std::string &err) {
  std::string raw;
  return readSource(file, raw, err) && autoDecompress(raw, err) && decodeText(raw, enc, text, err);
}

// "1,234.5" (thousands separators) also reads as a number in web tables.
Value webCell(const std::string &raw) {
  std::string s = trim(raw);
  Value v = parseCell(s, kNa);
  if (v.isText && s.find(',') != std::string::npos) {
    std::string digits;
    bool ok = !s.empty();
    for (char c : s)
      if (c != ',')
        digits.push_back(c);
    char *end = nullptr;
    double d = std::strtod(digits.c_str(), &end);
    if (ok && end && *end == '\0' && !digits.empty())
      return Value(d);
  }
  return v;
}

std::vector<std::pair<std::string, std::string>> nsPairs(const Value &v) {
  std::vector<std::pair<std::string, std::string>> out;
  if (v.isDict || v.isObject)
    for (const auto &kv : v.dict())
      out.emplace_back(kv.first, optText(kv.second));
  return out;
}

// ---- XML -> values ----------------------------------------------------------

bool isLeaf(const XNode *e) { return e->attrs.empty() && e->elements().empty(); }

// An element whose children are flat records -> table.
bool recordsToTable(const std::vector<const XNode *> &recs, const std::string &prefix, Table &t) {
  t = Table();
  for (const XNode *r : recs) {
    for (const auto &a : r->attrs)
      if (std::find(t.cols.begin(), t.cols.end(), prefix + a.first) == t.cols.end())
        t.cols.push_back(prefix + a.first);
    for (const XNode *c : r->elements()) {
      if (!isLeaf(c))
        return false;
      if (std::find(t.cols.begin(), t.cols.end(), c->name) == t.cols.end())
        t.cols.push_back(c->name);
    }
  }
  bool textValue = false;
  if (t.cols.empty()) { // <v>1</v><v>2</v> - one column of values
    t.cols.push_back(recs.empty() ? "value" : recs[0]->name);
    textValue = true;
  }
  for (const XNode *r : recs) {
    std::vector<Value> row;
    if (textValue) {
      row.push_back(parseCell(r->innerText(), kNa));
    } else {
      for (const auto &col : t.cols) {
        if (!prefix.empty() && col.rfind(prefix, 0) == 0 && r->attr(col.substr(prefix.size()))) {
          row.push_back(parseCell(*r->attr(col.substr(prefix.size())), kNa));
          continue;
        }
        if (prefix.empty() && r->attr(col)) {
          row.push_back(parseCell(*r->attr(col), kNa));
          continue;
        }
        Value cell(std::nan(""));
        for (const XNode *c : r->elements())
          if (c->name == col) {
            cell = parseCell(c->innerText(), kNa);
            break;
          }
        row.push_back(cell);
      }
    }
    t.rows.push_back(std::move(row));
  }
  normalizeTable(t);
  return true;
}

// The most repeated flat child group anywhere in the document.
bool findRecords(const XNode *e, std::vector<const XNode *> &best) {
  std::map<std::string, std::vector<const XNode *>> groups;
  for (const XNode *c : e->elements())
    groups[c->name].push_back(c);
  for (const auto &kv : groups) {
    if (kv.second.size() < 2 || kv.second.size() <= best.size())
      continue;
    bool flat = true;
    for (const XNode *r : kv.second)
      for (const XNode *c : r->elements())
        if (!isLeaf(c))
          flat = false;
    if (flat)
      best = kv.second;
  }
  for (const XNode *c : e->elements())
    findRecords(c, best);
  return !best.empty();
}

Value elementToDict(const XNode *e, const std::string &prefix) {
  if (isLeaf(e))
    return parseCell(e->innerText(), kNa);
  Fields f;
  for (const auto &a : e->attrs)
    f[prefix + a.first] = parseCell(a.second, kNa);
  std::map<std::string, std::vector<Value>> groups;
  std::vector<std::string> order;
  for (const XNode *c : e->elements()) {
    if (!groups.count(c->name))
      order.push_back(c->name);
    groups[c->name].push_back(elementToDict(c, prefix));
  }
  for (const auto &name : order) {
    auto &vals = groups[name];
    f[name] = vals.size() == 1 ? vals[0] : Value(vals);
  }
  std::string own = trim(e->ownText());
  if (!own.empty())
    f["#text"] = parseCell(own, kNa);
  return Value(f);
}

// The object form of an element keeps every child twice: in `children` (the
// tree, in document order - xpath(), select() and save_xml read it) and under
// a field named after its tag (D.catalog.book[0] - the shortcut). NC values
// are deep copies, so each level of shortcuts doubles everything below it: a
// node at depth d is stored 2^d times. That is nothing for a typical XML file
// (depth 3-6) but explodes on a web page (a Wikipedia article nests ~25
// levels: load_html of one ran for minutes and grew by ~150 MB/s).
//
// So the shortcuts are built only on the top levels, as deep as a budget of
// kObjectBudget node objects allows; below that a node keeps `children` only.
// Documents within the budget come out exactly as before.
namespace {
constexpr double kObjectBudget = 20000.0;

void depthHistogram(const XNode *e, size_t depth, std::vector<double> &hist) {
  if (hist.size() <= depth)
    hist.resize(depth + 1, 0.0);
  hist[depth] += 1.0;
  for (const XNode *c : e->elements())
    depthHistogram(c, depth + 1, hist);
}

// Levels of shortcuts that fit the budget: nodes at depth d are then stored
// 2^min(d, levels) times.
size_t shortcutLevels(const XNode *root) {
  std::vector<double> hist;
  depthHistogram(root, 0, hist);
  for (size_t levels = hist.size(); levels > 0; levels--) {
    double cost = 0.0;
    for (size_t d = 0; d < hist.size() && cost <= kObjectBudget; d++)
      cost += hist[d] * std::ldexp(1.0, static_cast<int>(std::min(d, levels)));
    if (cost <= kObjectBudget)
      return levels;
  }
  return 0;
}

Value elementToObjectAt(const XNode *e, size_t depth, size_t levels);
} // namespace

Value elementToObject(const XNode *e) { return elementToObjectAt(e, 0, shortcutLevels(e)); }

namespace {
Value elementToObjectAt(const XNode *e, size_t depth, size_t levels) {
  Fields f;
  Fields attrs;
  for (const auto &a : e->attrs)
    attrs[a.first] = Value(a.second);
  std::vector<Value> kids;
  std::map<std::string, std::vector<Value>> groups;
  const bool shortcuts = depth < levels;
  for (const XNode *c : e->elements()) {
    Value o = elementToObjectAt(c, depth + 1, levels);
    if (shortcuts)
      groups[c->name].push_back(o);
    kids.push_back(std::move(o));
  }
  for (auto &kv : groups) {
    std::string n = fieldName(kv.first);
    if (n.empty() || n == "tag" || n == "text" || n == "attrs" || n == "children")
      continue;
    f[n] = kv.second.size() == 1 ? kv.second[0] : Value(kv.second);
  }
  for (const auto &a : e->attrs) {
    std::string n = fieldName(a.first);
    if (!n.empty() && !f.count(n) && n != "tag" && n != "text" && n != "attrs" && n != "children")
      f[n] = Value(a.second);
  }
  f["tag"] = Value(e->name);
  f["text"] = Value(trim(e->innerText()));
  f["attrs"] = Value(attrs);
  f["children"] = Value(std::move(kids));
  return makeObject("NcXmlNode", std::move(f));
}
} // namespace

// Object (NcXmlNode / NcXml) -> element tree, for xpath() and save_xml.
bool objectToElement(const Value &v, XNode &out) {
  if (isObjectOf(v, "NcXml") || isObjectOf(v, "NcHtml")) {
    const Value *root = field(v, "root");
    return root && objectToElement(*root, out);
  }
  if (!isObjectOf(v, "NcXmlNode"))
    return false;
  out = XNode();
  out.kind = XNode::Element;
  out.name = optText(*field(v, "tag"));
  if (const Value *attrs = field(v, "attrs"))
    if (attrs->isDict) {
      std::vector<std::string> names;
      for (const auto &kv : attrs->dict())
        names.push_back(kv.first);
      std::sort(names.begin(), names.end());
      for (const auto &n : names)
        out.attrs.emplace_back(n, cellText(attrs->dict().at(n)));
    }
  const Value *kids = field(v, "children");
  size_t n = kids ? (kids->isArray ? kids->length() : 0) : 0;
  for (size_t i = 0; i < n; i++) {
    XNode k;
    if (objectToElement(kids->at(i), k))
      out.kids.push_back(std::move(k));
  }
  if (out.kids.empty()) {
    const Value *t = field(v, "text");
    if (t && !t->text().empty()) {
      XNode tx;
      tx.kind = XNode::Text;
      tx.text = t->text();
      out.kids.push_back(tx);
    }
  }
  return true;
}

Value itemsToValue(const std::vector<XItem> &items, bool objects, const std::string &prefix,
                   std::vector<std::string> *cols) {
  bool allElements = !items.empty();
  for (const auto &it : items)
    if (!it.attr.empty() || it.isText)
      allElements = false;
  if (allElements) {
    if (objects) {
      if (items.size() == 1)
        return elementToObject(items[0].node);
      std::vector<Value> v;
      for (const auto &it : items)
        v.push_back(elementToObject(it.node));
      return Value(std::move(v));
    }
    std::vector<const XNode *> nodes;
    for (const auto &it : items)
      nodes.push_back(it.node);
    Table t;
    bool anyStructure = false;
    for (auto *n : nodes)
      if (!isLeaf(n))
        anyStructure = true;
    if (anyStructure && recordsToTable(nodes, prefix, t)) {
      if (cols)
        *cols = t.cols;
      return tableData(t);
    }
    if (!anyStructure) {
      if (nodes.size() == 1)
        return parseCell(nodes[0]->innerText(), kNa);
      std::vector<Value> v;
      for (auto *n : nodes)
        v.push_back(parseCell(n->innerText(), kNa));
      return Value(std::move(v));
    }
    if (nodes.size() == 1)
      return elementToDict(nodes[0], prefix);
    std::vector<Value> v;
    for (auto *n : nodes)
      v.push_back(elementToDict(n, prefix));
    return Value(std::move(v));
  }
  if (items.size() == 1)
    return parseCell(items[0].value, kNa);
  std::vector<Value> v;
  for (const auto &it : items)
    v.push_back(it.node && it.attr.empty() && !it.isText ? Value(trim(it.node->innerText()))
                                                          : parseCell(it.value, kNa));
  return Value(std::move(v));
}

std::vector<std::string> collectBoxes(const XNode &n, bool html) {
  std::vector<std::string> out;
  std::function<void(const XNode &)> walk = [&](const XNode &x) {
    if (x.kind == XNode::Comment)
      out.push_back(trim(x.text));
    else if (!html && x.kind == XNode::CData)
      out.push_back(x.text);
    else if (!html && x.kind == XNode::PI && x.name != "xml")
      out.push_back("<?" + x.name + " " + x.text + "?>");
    else if (x.kind == XNode::Element) {
      bool box = false;
      if (html) {
        const std::string *cls = x.attr("class");
        std::string c = cls ? lower(*cls) : "";
        box = x.name == "aside" || x.name == "figcaption" || c.find("infobox") != std::string::npos ||
              c.find("note") != std::string::npos || c.find("alert") != std::string::npos ||
              c.find("callout") != std::string::npos || (x.attr("role") && *x.attr("role") == "note");
      } else {
        box = x.name == "header" || x.name == "description" || x.name == "metadata";
      }
      if (box) {
        std::string t = trim(x.innerText());
        if (!t.empty())
          out.push_back(t);
        if (html)
          return;
      }
      for (const auto &k : x.kids)
        walk(k);
    } else if (x.kind == XNode::Document) {
      for (const auto &k : x.kids)
        walk(k);
    }
  };
  walk(n);
  return out;
}

Value namespacesOf(const XNode &doc) {
  Fields f;
  std::function<void(const XNode &)> walk = [&](const XNode &x) {
    for (const auto &a : x.attrs) {
      if (a.first == "xmlns")
        f[""] = Value(a.second);
      else if (a.first.rfind("xmlns:", 0) == 0)
        f[a.first.substr(6)] = Value(a.second);
    }
    for (const auto &k : x.kids)
      if (k.kind == XNode::Element)
        walk(k);
  };
  walk(doc);
  return Value(f);
}

// ---- XSD (structural subset) ------------------------------------------------

struct XsdElement {
  std::string name, type;
  std::vector<std::pair<std::string, long long>> children; // name, minOccurs
  bool hasSequence = false;
  std::vector<std::string> requiredAttrs;
};

void collectXsd(const XNode &n, std::map<std::string, XsdElement> &decls, std::set<std::string> &globals,
                int depth) {
  for (const XNode *e : n.elements()) {
    std::string local = e->name.substr(e->name.find(':') == std::string::npos ? 0 : e->name.find(':') + 1);
    if (local == "element" && e->attr("name")) {
      XsdElement d;
      d.name = *e->attr("name");
      if (e->attr("type"))
        d.type = *e->attr("type");
      if (depth == 0)
        globals.insert(d.name);
      std::function<void(const XNode &)> body = [&](const XNode &x) {
        for (const XNode *c : x.elements()) {
          std::string l = c->name.substr(c->name.find(':') == std::string::npos ? 0 : c->name.find(':') + 1);
          if (l == "sequence" || l == "all" || l == "choice") {
            d.hasSequence = d.hasSequence || l != "choice";
            for (const XNode *s : c->elements()) {
              std::string sl = s->name.substr(s->name.find(':') == std::string::npos ? 0 : s->name.find(':') + 1);
              if (sl == "element") {
                std::string nm = s->attr("name") ? *s->attr("name") : s->attr("ref") ? *s->attr("ref") : "";
                long long mn = s->attr("minOccurs") ? std::atoll(s->attr("minOccurs")->c_str()) : 1;
                if (l == "choice")
                  mn = 0;
                if (!nm.empty())
                  d.children.emplace_back(nm, mn);
              }
            }
          } else if (l == "attribute" && c->attr("name") && c->attr("use") && *c->attr("use") == "required") {
            d.requiredAttrs.push_back(*c->attr("name"));
          } else if (l == "complexType" || l == "complexContent" || l == "extension") {
            body(*c);
          }
        }
      };
      body(*e);
      if (!decls.count(d.name) || depth == 0)
        decls[d.name] = d;
    }
    collectXsd(*e, decls, globals, depth + (local == "element" ? 1 : 0));
  }
}

bool validateXsd(const XNode &doc, const std::string &xsdPath, std::string &err) {
  std::string text;
  XNode xsd;
  if (!loadText(xsdPath, "utf-8", text, err) || !parseXml(text, xsd, err)) {
    err = "schema " + xsdPath + ": " + err;
    return false;
  }
  std::map<std::string, XsdElement> decls;
  std::set<std::string> globals;
  const XNode *sroot = rootElement(xsd);
  if (!sroot) {
    err = "schema " + xsdPath + " is empty";
    return false;
  }
  collectXsd(*sroot, decls, globals, 0);
  const XNode *root = rootElement(doc);
  if (!globals.count(root->name)) {
    err = "XSD: root element <" + root->name + "> is not declared in " + xsdPath;
    return false;
  }
  std::function<bool(const XNode *)> check = [&](const XNode *e) -> bool {
    auto it = decls.find(e->name);
    if (it != decls.end()) {
      const XsdElement &d = it->second;
      for (const auto &a : d.requiredAttrs)
        if (!e->attr(a)) {
          err = "XSD: <" + e->name + "> needs attribute '" + a + "'";
          return false;
        }
      std::map<std::string, long long> count;
      for (const XNode *c : e->elements())
        count[c->name]++;
      for (const auto &c : d.children)
        if (count[c.first] < c.second) {
          err = "XSD: <" + e->name + "> needs child <" + c.first + ">";
          return false;
        }
      if (d.hasSequence)
        for (const auto &kv : count) {
          bool known = false;
          for (const auto &c : d.children)
            if (c.first == kv.first)
              known = true;
          if (!known) {
            err = "XSD: <" + kv.first + "> is not allowed inside <" + e->name + ">";
            return false;
          }
        }
      std::string type = d.type.substr(d.type.find(':') == std::string::npos ? 0 : d.type.find(':') + 1);
      if (isLeaf(e) && !type.empty()) {
        std::string t = trim(e->innerText());
        char *end = nullptr;
        if ((type == "integer" || type == "int" || type == "long" || type == "short") &&
            (std::strtoll(t.c_str(), &end, 10), *end != '\0' || t.empty())) {
          err = "XSD: <" + e->name + "> must be an integer, got '" + t + "'";
          return false;
        }
        if ((type == "decimal" || type == "double" || type == "float") &&
            (std::strtod(t.c_str(), &end), *end != '\0' || t.empty())) {
          err = "XSD: <" + e->name + "> must be a number, got '" + t + "'";
          return false;
        }
        if (type == "boolean" && t != "true" && t != "false" && t != "1" && t != "0") {
          err = "XSD: <" + e->name + "> must be true/false, got '" + t + "'";
          return false;
        }
      }
    }
    for (const XNode *c : e->elements())
      if (!check(c))
        return false;
    return true;
  };
  return check(root);
}

// ---- read/load/save XML -------------------------------------------------------

// read_xml(file, xpath, ns, attr_prefix, box, validate_xsd, enc)
void readXml(const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err, text;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev("read_xml", file);
  XNode doc;
  if (!loadText(file, optText(a[6], "utf-8"), text, err) || !parseXml(text, doc, err))
    return ctx.fail(err);
  if (given(a[5]) && !validateXsd(doc, optText(a[5]), err))
    return ctx.fail(err);
  const std::string prefix = a[3].isText ? a[3].text() : "@";
  const std::string expr = optText(a[1], "");
  std::vector<std::string> cols;
  const XNode *root = rootElement(doc);
  if (!expr.empty()) {
    std::vector<XItem> items;
    if (!xpath(doc, expr, items, err, nsPairs(a[2])))
      return ctx.fail(err);
    if (items.empty())
      return ctx.fail("XPath " + expr + " matched nothing");
    out.push_back(itemsToValue(items, false, prefix, &cols));
  } else {
    std::vector<const XNode *> recs;
    Table t;
    if (findRecords(root, recs) && recordsToTable(recs, prefix, t)) {
      cols = t.cols;
      out.push_back(tableData(t));
    } else {
      out.push_back(elementToDict(root, prefix));
    }
  }
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(cols);
    info["root"] = Value(root->name);
    info["boxes"] = optBool(a[4], true) ? textList(collectBoxes(doc, false)) : textList({});
    info["namespaces"] = namespacesOf(doc);
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

// load_xml(file, enc)
Value loadXml(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err, text;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev("load_xml", file);
  XNode doc;
  if (!loadText(file, optText(a[1], "utf-8"), text, err) || !parseXml(text, doc, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  const XNode *root = rootElement(doc);
  Fields f;
  Value r = elementToObject(root);
  std::string rn = fieldName(root->name);
  if (!rn.empty())
    f[rn] = r;
  std::vector<std::string> comments;
  for (const auto &k : doc.kids)
    if (k.kind == XNode::Comment)
      comments.push_back(trim(k.text));
  std::function<void(const XNode &)> walk = [&](const XNode &x) {
    for (const auto &k : x.kids) {
      if (k.kind == XNode::Comment)
        comments.push_back(trim(k.text));
      else if (k.kind == XNode::Element)
        walk(k);
    }
  };
  walk(*root);
  f["root"] = r;
  f["comments"] = textList(comments);
  f["boxes"] = textList(collectBoxes(doc, false));
  f["namespaces"] = namespacesOf(doc);
  f["file"] = Value(file);
  ev.ok = true;
  return makeObject("NcXml", std::move(f));
}

Value xpathMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string expr, err;
  if (!numpy::argText(a, 1, ctx, expr))
    return Value(0.0);
  XNode root;
  if (!objectToElement(a[0], root)) {
    ctx.fail("xpath() works on a loaded XML/HTML object");
    return Value(0.0);
  }
  XNode doc;
  doc.kind = XNode::Document;
  doc.kids.push_back(std::move(root));
  std::vector<XItem> items;
  if (!xpath(doc, expr, items, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (items.empty())
    return Value(std::vector<Value>{});
  return itemsToValue(items, true, "@", nullptr);
}

bool validQName(const std::string &n) {
  if (n.empty() || !(std::isalpha(static_cast<unsigned char>(n[0])) || n[0] == '_'))
    return false;
  int colons = 0;
  for (size_t i = 0; i < n.size(); i++) {
    char c = n[i];
    if (c == ':') {
      if (++colons > 1 || i + 1 == n.size())
        return false;
      continue;
    }
    if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '-' || c == '.'))
      return false;
  }
  return true;
}

bool valueToElement(const std::string &name, const Value &v, XNode &out, std::string &err) {
  if (!validQName(name)) {
    err = "'" + name + "' is not a valid XML tag name (no spaces, must not start with a digit)";
    return false;
  }
  out = XNode();
  out.kind = XNode::Element;
  out.name = name;
  if (v.isDict || (v.isObject && !isObjectOf(v, "NcXmlNode"))) {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      const Value &x = v.dict().at(k);
      if (!k.empty() && k[0] == '@') {
        out.attrs.emplace_back(k.substr(1), cellText(x));
        continue;
      }
      if (k == "#text") {
        XNode t;
        t.kind = XNode::Text;
        t.text = cellText(x);
        out.kids.push_back(t);
        continue;
      }
      if ((x.isArray || (x.isMatrix && x.rows() == 1)) && !x.isText) {
        size_t n = x.isArray ? x.length() : x.rowLength(0);
        for (size_t i = 0; i < n; i++) {
          XNode c;
          if (!valueToElement(k, x.isArray ? x.at(i) : x.at(0, i), c, err))
            return false;
          out.kids.push_back(std::move(c));
        }
        continue;
      }
      XNode c;
      if (!valueToElement(k, x, c, err))
        return false;
      out.kids.push_back(std::move(c));
    }
    return true;
  }
  XNode t;
  t.kind = XNode::Text;
  t.text = cellText(v);
  if (!t.text.empty())
    out.kids.push_back(t);
  return true;
}

// save_xml(file, data, root, row_tag, indent, cdata, boxes, enc, compress, level)
Value saveXml(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev("save_xml", file);
  const std::string rootName = optText(a[2], "Dataset"), rowTag = optText(a[3], "Record");
  const int indent = static_cast<int>(optInt(a[4], 2));
  const std::vector<std::string> cdata = optTextList(a[5]);
  const std::string enc = optText(a[7], "utf-8");
  XNode doc;
  doc.kind = XNode::Document;
  for (const auto &bx : optTextList(a[6])) {
    XNode c;
    c.kind = XNode::Comment;
    std::string t = trim(bx);
    if (t.rfind("<!--", 0) == 0 && t.size() >= 7 && t.compare(t.size() - 3, 3, "-->") == 0)
      t = t.substr(4, t.size() - 7);
    c.text = " " + trim(t) + " ";
    doc.kids.push_back(c);
  }
  const Value &data = a[1];
  XNode rootEl;
  if (!validQName(rootName) || !validQName(rowTag)) {
    ctx.fail("root and row_tag must be valid XML tag names");
    return Value(0.0);
  }
  if (isObjectOf(data, "NcXml") || isObjectOf(data, "NcXmlNode")) {
    objectToElement(data, rootEl);
  } else if (data.isText) {
    XNode parsed;
    if (!parseXml(data.text(), parsed, err)) {
      ctx.fail("text data must be an XML document: " + err);
      return Value(0.0);
    }
    for (auto &k : parsed.kids)
      if (k.kind == XNode::Element)
        rootEl = k;
  } else if (data.isDict) {
    if (!valueToElement(rootName, data, rootEl, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
  } else {
    Table t;
    if (!valueToTable(data, t, err, true)) {
      ctx.fail(err);
      return Value(0.0);
    }
    rootEl.kind = XNode::Element;
    rootEl.name = rootName;
    for (const auto &c : t.cols)
      if (!(c.rfind("@", 0) == 0 ? validQName(c.substr(1)) : validQName(c))) {
        ctx.fail("column '" + c + "' is not a valid XML tag name (no spaces, must not start with a digit)");
        return Value(0.0);
      }
    for (const auto &r : t.rows) {
      XNode rec;
      rec.kind = XNode::Element;
      rec.name = rowTag;
      for (size_t c = 0; c < t.cols.size(); c++) {
        if (t.cols[c].rfind("@", 0) == 0) {
          rec.attrs.emplace_back(t.cols[c].substr(1), cellText(r[c]));
          continue;
        }
        XNode cell;
        cell.kind = XNode::Element;
        cell.name = t.cols[c];
        XNode tx;
        tx.kind = XNode::Text;
        tx.text = cellText(r[c]);
        if (!tx.text.empty())
          cell.kids.push_back(tx);
        rec.kids.push_back(std::move(cell));
      }
      rootEl.kids.push_back(std::move(rec));
    }
  }
  doc.kids.push_back(std::move(rootEl));
  std::string text = writeXml(doc, indent, cdata, enc == "utf-8" ? "UTF-8" : enc), bytes;
  if (!encodeText(text, enc, bytes, err) ||
      !applyCompression(optText(a[8], "none"), static_cast<int>(optInt(a[9], -1)), bytes, err) ||
      !writeFile(file, bytes, false, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  emitEvent({"saved", "save_xml", file, 1.0, formatBytes(bytes.size())});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

// ---- HTML ---------------------------------------------------------------------

struct HtmlTable {
  Table table;
  std::string id, caption;
};

void allOf(const XNode &n, const std::string &tag, std::vector<const XNode *> &out) {
  for (const auto &k : n.kids)
    if (k.kind == XNode::Element) {
      if (k.name == tag)
        out.push_back(&k);
      allOf(k, tag, out);
    }
}

std::string collapse(const std::string &s) {
  std::string out;
  bool sp = false;
  for (char c : s) {
    if (std::isspace(static_cast<unsigned char>(c))) {
      sp = !out.empty();
    } else {
      if (sp)
        out.push_back(' ');
      out.push_back(c);
      sp = false;
    }
  }
  return out;
}

HtmlTable htmlTable(const XNode *tbl) {
  HtmlTable h;
  if (const std::string *id = tbl->attr("id"))
    h.id = *id;
  std::vector<const XNode *> rows;
  std::function<void(const XNode *)> gather = [&](const XNode *n) {
    for (const XNode *c : n->elements()) {
      if (c->name == "caption")
        h.caption = collapse(c->innerText());
      else if (c->name == "tr")
        rows.push_back(c);
      else if (c->name == "thead" || c->name == "tbody" || c->name == "tfoot")
        gather(c);
    }
  };
  gather(tbl);
  // Grid with colspan / rowspan.
  std::vector<std::vector<std::string>> grid;
  std::vector<bool> headerRow;
  std::map<std::pair<size_t, size_t>, std::string> spanned;
  for (size_t r = 0; r < rows.size(); r++) {
    std::vector<std::string> line;
    bool allTh = true;
    size_t col = 0;
    for (const XNode *cell : rows[r]->elements()) {
      if (cell->name != "td" && cell->name != "th")
        continue;
      while (spanned.count({r, col}))
        line.push_back(spanned[{r, col++}]);
      if (cell->name != "th")
        allTh = false;
      std::string text = collapse(cell->innerText());
      long long cs = cell->attr("colspan") ? std::max(1LL, std::atoll(cell->attr("colspan")->c_str())) : 1;
      long long rs = cell->attr("rowspan") ? std::max(1LL, std::atoll(cell->attr("rowspan")->c_str())) : 1;
      for (long long k = 0; k < cs; k++) {
        line.push_back(text);
        for (long long d = 1; d < rs; d++)
          spanned[{r + static_cast<size_t>(d), col}] = text;
        col++;
      }
    }
    while (spanned.count({r, col}))
      line.push_back(spanned[{r, col++}]);
    if (line.empty())
      continue;
    grid.push_back(line);
    headerRow.push_back(allTh);
  }
  size_t first = 0;
  if (!grid.empty() && headerRow[0]) {
    h.table.cols = grid[0];
    first = 1;
  }
  for (size_t r = first; r < grid.size(); r++) {
    std::vector<Value> row;
    for (const auto &c : grid[r])
      row.push_back(webCell(c));
    h.table.rows.push_back(std::move(row));
  }
  normalizeTable(h.table);
  return h;
}

std::string visibleText(const XNode &n) {
  static const std::set<std::string> block = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5",
                                              "h6", "table", "section", "article", "header", "footer",
                                              "aside", "ul", "ol", "pre", "blockquote", "title"};
  std::string out;
  std::function<void(const XNode &)> walk = [&](const XNode &x) {
    if (x.kind == XNode::Text) {
      out += x.text;
      return;
    }
    if (x.kind != XNode::Element && x.kind != XNode::Document)
      return;
    if (x.name == "script" || x.name == "style" || x.name == "head" || x.name == "noscript")
      return;
    bool b = block.count(x.name) > 0;
    if (b)
      out += "\n";
    for (const auto &k : x.kids)
      walk(k);
    if (b)
      out += "\n";
    if (x.name == "td" || x.name == "th")
      out += "\t";
  };
  walk(n);
  // collapse blanks per line, drop empty lines
  std::string res, line;
  size_t start = 0;
  while (start <= out.size()) {
    size_t e = out.find('\n', start);
    if (e == std::string::npos)
      e = out.size();
    std::string l = collapse(out.substr(start, e - start));
    if (!l.empty())
      res += (res.empty() ? "" : "\n") + l;
    start = e + 1;
  }
  return res;
}

struct HtmlDoc {
  XNode doc;
  std::vector<HtmlTable> tables;
};

bool loadHtmlDoc(const std::string &file, HtmlDoc &h, std::string &err) {
  std::string text;
  if (!loadText(file, "utf-8", text, err))
    return false;
  parseHtml(text, h.doc);
  std::vector<const XNode *> tbls;
  allOf(h.doc, "table", tbls);
  for (const XNode *t : tbls)
    h.tables.push_back(htmlTable(t));
  return true;
}

Value linksOf(const XNode &doc) {
  std::vector<const XNode *> as;
  allOf(doc, "a", as);
  std::vector<std::vector<Value>> m;
  for (const XNode *a : as)
    if (const std::string *href = a->attr("href"))
      m.push_back({Value(*href), Value(collapse(a->innerText()))});
  if (m.empty())
    return Value(std::vector<Value>{});
  return Value(m);
}

Value metaOf(const XNode &doc) {
  std::vector<const XNode *> metas;
  allOf(doc, "meta", metas);
  Fields f;
  for (const XNode *m : metas) {
    const std::string *name = m->attr("name");
    if (!name)
      name = m->attr("property");
    if (!name)
      name = m->attr("charset") ? m->attr("charset") : nullptr;
    const std::string *content = m->attr("content");
    if (m->attr("charset"))
      f["charset"] = Value(*m->attr("charset"));
    else if (name && content)
      f[*name] = Value(*content);
  }
  return Value(f);
}

std::string titleOf(const XNode &doc) {
  std::vector<const XNode *> t;
  allOf(doc, "title", t);
  return t.empty() ? "" : collapse(t[0]->innerText());
}

bool pickTable(const HtmlDoc &h, const Value &sel, size_t &idx, std::string &err) {
  if (h.tables.empty()) {
    err = "the page has no <table>";
    return false;
  }
  if (!given(sel) || numpy::isPlainNumber(sel)) {
    long long k = given(sel) ? static_cast<long long>(sel.number) : 0;
    if (k < 0 || k >= static_cast<long long>(h.tables.size())) {
      err = "table " + std::to_string(k) + " does not exist (the page has " + std::to_string(h.tables.size()) +
            ", numbered from 0)";
      return false;
    }
    idx = static_cast<size_t>(k);
    return true;
  }
  std::string want = optText(sel);
  for (size_t k = 0; k < h.tables.size(); k++)
    if (h.tables[k].id == want || (!h.tables[k].caption.empty() &&
                                   lower(h.tables[k].caption).find(lower(want)) != std::string::npos)) {
      idx = k;
      return true;
    }
  err = "no table with id or caption '" + want + "'";
  return false;
}

Value tableObj(const HtmlTable &t) {
  return tableObject(t.table, {{"id", Value(t.id)}, {"caption", Value(t.caption)}});
}

// read_html(file, table, css, xpath, links, box)
void readHtml(const std::string &fn, const std::vector<Value> &a, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev(fn, file);
  HtmlDoc h;
  if (!loadHtmlDoc(file, h, err))
    return ctx.fail(err);
  std::vector<std::string> cols;
  const std::string css = optText(a[2], ""), xp = optText(a[3], "");
  if (!css.empty()) {
    std::vector<const XNode *> hits;
    if (!cssSelect(h.doc, css, hits, err))
      return ctx.fail(err);
    std::vector<std::string> texts;
    for (auto *n : hits)
      texts.push_back(collapse(n->innerText()));
    out.push_back(textList(texts));
  } else if (!xp.empty()) {
    std::vector<XItem> items;
    if (!xpath(h.doc, xp, items, err))
      return ctx.fail(err);
    if (items.size() == 1 && items[0].attr.empty() && !items[0].isText && items[0].node->name == "table") {
      HtmlTable t = htmlTable(items[0].node);
      cols = t.table.cols;
      out.push_back(tableData(t.table));
    } else {
      std::vector<Value> v;
      for (const auto &it : items)
        v.push_back(webCell(it.attr.empty() && !it.isText ? collapse(it.node->innerText()) : it.value));
      out.push_back(Value(std::move(v)));
    }
  } else if (optBool(a[4], false)) {
    out.push_back(linksOf(h.doc));
  } else {
    size_t idx = 0;
    if (!pickTable(h, a[1], idx, err))
      return ctx.fail(err);
    cols = h.tables[idx].table.cols;
    out.push_back(tableData(h.tables[idx].table));
  }
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(cols);
    info["tables"] = Value(static_cast<double>(h.tables.size()));
    info["title"] = Value(titleOf(h.doc));
    info["boxes"] = optBool(a[5], true) ? textList(collectBoxes(h.doc, true)) : textList({});
    info["meta"] = metaOf(h.doc);
    info["links"] = linksOf(h.doc);
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

Value htmlRootObject(const XNode &doc) {
  const XNode *html = nullptr;
  for (const auto &k : doc.kids)
    if (k.kind == XNode::Element)
      html = &k;
  if (!html) {
    XNode wrap;
    wrap.kind = XNode::Element;
    wrap.name = "html";
    return elementToObject(&wrap);
  }
  return elementToObject(html);
}

Value loadHtml(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  HtmlDoc h;
  if (!loadHtmlDoc(file, h, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  std::vector<Value> tables;
  std::vector<std::string> names;
  for (size_t k = 0; k < h.tables.size(); k++) {
    tables.push_back(tableObj(h.tables[k]));
    names.push_back(!h.tables[k].id.empty() ? h.tables[k].id
                                             : !h.tables[k].caption.empty() ? h.tables[k].caption
                                                                            : "table_" + std::to_string(k));
  }
  f["default"] = tables.empty() ? tableObject(Table()) : tables[0];
  f["tables"] = Value(std::move(tables));
  f["table_names"] = textList(names);
  f["title"] = Value(titleOf(h.doc));
  f["meta"] = metaOf(h.doc);
  f["boxes"] = textList(collectBoxes(h.doc, true));
  f["links"] = linksOf(h.doc);
  std::vector<const XNode *> imgs;
  allOf(h.doc, "img", imgs);
  std::vector<std::string> srcs;
  for (auto *i : imgs)
    if (const std::string *s = i->attr("src"))
      srcs.push_back(*s);
  f["images"] = textList(srcs);
  f["text"] = Value(visibleText(h.doc));
  f["file"] = Value(file);
  // The DOM itself, for D.select() / D.xpath().
  f["root"] = htmlRootObject(h.doc);
  ev.ok = true;
  return makeObject("NcHtml", std::move(f));
}

Value selectMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string css, err;
  if (!numpy::argText(a, 1, ctx, css))
    return Value(0.0);
  XNode root;
  if (!objectToElement(a[0], root)) {
    ctx.fail("select() works on a loaded HTML object");
    return Value(0.0);
  }
  XNode doc;
  doc.kind = XNode::Document;
  doc.kids.push_back(std::move(root));
  std::vector<const XNode *> hits;
  if (!cssSelect(doc, css, hits, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  std::vector<std::string> texts;
  for (auto *n : hits)
    texts.push_back(collapse(n->innerText()));
  return textList(texts);
}

Value tableMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *tables = field(a[0], "tables");
  const Value *names = field(a[0], "table_names");
  if (!tables || !tables->isArray || tables->length() == 0) {
    ctx.fail("the page has no <table>");
    return Value(0.0);
  }
  if (numpy::isPlainNumber(a[1])) {
    long long k = static_cast<long long>(a[1].number);
    if (k < 0 || k >= static_cast<long long>(tables->length())) {
      ctx.fail("table " + std::to_string(k) + " does not exist (numbered from 0)");
      return Value(0.0);
    }
    return tables->at(static_cast<size_t>(k));
  }
  std::string want = optText(a[1]);
  std::vector<std::string> list = names ? optTextList(*names) : std::vector<std::string>{};
  for (size_t k = 0; k < list.size(); k++)
    if (list[k] == want || lower(list[k]).find(lower(want)) != std::string::npos)
      return tables->at(k);
  for (size_t k = 0; k < tables->length(); k++) { // the caption, when the name is the id
    const Value tbl = tables->at(k); // at() returns a copy - keep it alive
    const Value *cap = field(tbl, "caption");
    if (cap && cap->isText && !want.empty() && lower(cap->text()).find(lower(want)) != std::string::npos)
      return tables->at(k);
  }
  ctx.fail("no table named '" + want + "'");
  return Value(0.0);
}

// ---- save_html ----------------------------------------------------------------

std::string themeCss(const std::string &theme) {
  std::string base =
      "body{font-family:Segoe UI,Helvetica,Arial,sans-serif;margin:24px;color:#1b1f24;background:#fff}"
      "h1{font-size:22px}h2{font-size:18px;margin-top:28px}"
      "table{border-collapse:collapse;margin:12px 0;font-size:14px}"
      "th,td{padding:6px 12px;text-align:left}td.num{text-align:right;font-variant-numeric:tabular-nums}"
      ".note{border-left:4px solid #3b6ea5;background:#f2f6fb;padding:8px 12px;margin:10px 0}";
  if (theme == "light")
    return base + "th{background:#eef1f5;border-bottom:2px solid #c9d1db}td{border-bottom:1px solid #e3e7ec}";
  if (theme == "minimal")
    return base + "th{border-bottom:1px solid #000}td{border-bottom:1px solid #eee}.note{background:none}";
  return base + "th{background:#1f3a5f;color:#fff}tr:nth-child(even) td{background:#f4f7fb}"
                "td{border-bottom:1px solid #dde3ea}";
}

std::string htmlTableText(const Table &t, bool header) {
  std::string s = "<table>\n";
  if (header) {
    s += "<thead><tr>";
    for (const auto &c : t.cols)
      s += "<th>" + escapeXml(c, false) + "</th>";
    s += "</tr></thead>\n";
  }
  s += "<tbody>\n";
  for (const auto &r : t.rows) {
    s += "<tr>";
    for (const auto &c : r)
      s += (isNumberCell(c) ? "<td class=\"num\">" : "<td>") + escapeXml(cellText(c), false) + "</td>";
    s += "</tr>\n";
  }
  return s + "</tbody>\n</table>\n";
}

std::string base64(const std::string &in) {
  static const char *t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  std::string out;
  size_t i = 0;
  while (i + 2 < in.size()) {
    uint32_t v = (static_cast<unsigned char>(in[i]) << 16) | (static_cast<unsigned char>(in[i + 1]) << 8) |
                 static_cast<unsigned char>(in[i + 2]);
    out += t[v >> 18];
    out += t[(v >> 12) & 63];
    out += t[(v >> 6) & 63];
    out += t[v & 63];
    i += 3;
  }
  if (i + 1 == in.size()) {
    uint32_t v = static_cast<unsigned char>(in[i]) << 16;
    out += t[v >> 18];
    out += t[(v >> 12) & 63];
    out += "==";
  } else if (i + 2 == in.size()) {
    uint32_t v = (static_cast<unsigned char>(in[i]) << 16) | (static_cast<unsigned char>(in[i + 1]) << 8);
    out += t[v >> 18];
    out += t[(v >> 12) & 63];
    out += t[(v >> 6) & 63];
    out += '=';
  }
  return out;
}

// <img src="local.png"> -> data URI, relative to the output file's folder.
std::string embedImages(const std::string &html, const std::string &outFile) {
  std::string out;
  size_t i = 0;
  std::string dir;
  size_t slash = outFile.find_last_of("/\\");
  if (slash != std::string::npos)
    dir = outFile.substr(0, slash + 1);
  while (true) {
    size_t at = lower(html.substr(i)).find("src=\"");
    if (at == std::string::npos) {
      out += html.substr(i);
      break;
    }
    at += i;
    size_t vb = at + 5, ve = html.find('"', vb);
    if (ve == std::string::npos) {
      out += html.substr(i);
      break;
    }
    std::string src = html.substr(vb, ve - vb);
    out += html.substr(i, vb - i);
    std::string ext = extensionOf(src), bytes, err;
    std::string mime = ext == "png" ? "image/png" : (ext == "jpg" || ext == "jpeg") ? "image/jpeg"
                       : ext == "gif" ? "image/gif" : ext == "svg" ? "image/svg+xml" : ext == "bmp" ? "image/bmp" : "";
    if (!mime.empty() && !isUrl(src) && src.rfind("data:", 0) != 0 &&
        (readFile(src, bytes, err) || readFile(dir + src, bytes, err)))
      out += "data:" + mime + ";base64," + base64(bytes);
    else
      out += src;
    i = ve;
  }
  return out;
}

// save_html(file, data, title, theme, css, boxes, embed_img, minify, mode)
Value saveHtml(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  const std::string title = optText(a[2], "Report"), theme = lower(optText(a[3], "navy"));
  if (theme != "navy" && theme != "light" && theme != "minimal") {
    ctx.fail("theme must be \"navy\", \"light\" or \"minimal\"");
    return Value(0.0);
  }
  const std::string mode = lower(optText(a[8], "w"));
  std::string body;
  for (const auto &bx : optTextList(a[5]))
    body += "<div class=\"note\">" + escapeXml(bx, false) + "</div>\n";
  const Value &data = a[1];
  if (data.isText) {
    body += data.text().find('<') != std::string::npos ? data.text() + "\n"
                                                       : "<p>" + escapeXml(data.text(), false) + "</p>\n";
  } else if (data.isDict) {
    std::vector<std::string> keys;
    for (const auto &kv : data.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      Table t;
      if (!valueToTable(data.dict().at(k), t, err, true)) {
        ctx.fail(err);
        return Value(0.0);
      }
      body += "<h2>" + escapeXml(k, false) + "</h2>\n" + htmlTableText(t, true);
    }
  } else if (given(data)) {
    Value src = isObjectOf(data, "NcHtml") ? *field(data, "default") : data;
    Table t;
    if (!valueToTable(src, t, err, true)) {
      ctx.fail(err);
      return Value(0.0);
    }
    bool generated = true;
    for (size_t i = 0; i < t.cols.size(); i++)
      if (t.cols[i] != "Col_" + std::to_string(i + 1))
        generated = false;
    body += htmlTableText(t, !generated);
  }
  if (optBool(a[6], true))
    body = embedImages(body, file);
  std::string style;
  const std::string css = optText(a[4], "");
  std::string cssText;
  if (!css.empty() && readFile(css, cssText, err))
    style = "<style>" + themeCss(theme) + cssText + "</style>";
  else if (!css.empty())
    style = "<style>" + themeCss(theme) + "</style><link rel=\"stylesheet\" href=\"" + escapeXml(css, true) + "\">";
  else
    style = "<style>" + themeCss(theme) + "</style>";
  std::string page;
  bool append = mode == "a" && fileExists(file);
  if (append) {
    std::string old;
    if (!readFile(file, old, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    size_t at = lower(old).rfind("</body>");
    page = at == std::string::npos ? old + body : old.substr(0, at) + body + old.substr(at);
  } else {
    page = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
           "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
           "<meta name=\"generator\" content=\"NC save_html\">\n<title>" +
           escapeXml(title, false) + "</title>\n" + style + "\n</head>\n<body>\n<h1>" + escapeXml(title, false) +
           "</h1>\n" + body + "</body>\n</html>\n";
  }
  if (optBool(a[7], false)) {
    std::string m;
    bool sp = false;
    for (char c : page) {
      if (c == '\n' || c == '\r' || c == '\t' || c == ' ') {
        if (!sp)
          m.push_back(' ');
        sp = true;
      } else {
        m.push_back(c);
        sp = false;
      }
    }
    page = m;
  }
  if (!writeFile(file, page, false, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  emitEvent({"saved", fn, file, 1.0, formatBytes(page.size())});
  ev.ok = true;
  return Value(static_cast<double>(page.size()));
}

} // namespace

void registerMarkup(Registry &reg) {
  addMulti(reg, "read_xml",
           "file, xpath=\"\", ns=\"\", attr_prefix=\"@\", box=true, validate_xsd=\"\", enc=\"utf-8\"",
           "read a .xml file (repeating records become a table; an XPath selects nodes)",
           "pandas.read_xml", 2, readXml);
  addFn(reg, "load_xml", "file, enc=\"utf-8\"",
        "load a .xml file as an element tree with dot access (D.catalog.book[0].title)",
        "xml.etree.ElementTree.parse", loadXml);
  addFn(reg, "save_xml",
        "file, data, root=\"Dataset\", row_tag=\"Record\", indent=2, cdata=\"\", boxes=\"\", "
        "enc=\"utf-8\", compress=\"none\", level=-1",
        "write a table, dict or loaded XML tree as XML", "pandas.DataFrame.to_xml", saveXml);
  for (const char *cls : {"NcXml", "NcXmlNode", "NcHtml"})
    addFn(reg, std::string(cls) + ".xpath", "D, expr", "XPath query on a loaded XML/HTML tree",
          "lxml xpath", xpathMethod);
  for (const char *ext : {"html", "htm"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, table=0, css=\"\", xpath=\"\", links=false, box=true",
             "read a table (or CSS/XPath matches, or links) from a ." + e + " page or URL",
             "pandas.read_html", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
               readHtml("read_" + e, a, nout, out, ctx);
             });
    addFn(reg, "load_" + e, "file",
          "load a ." + e + " page or URL: tables, title, meta, info boxes, links, images, text",
          "BeautifulSoup",
          [e](const std::vector<Value> &a, CallContext &ctx) { return loadHtml("load_" + e, a, ctx); });
    addFn(reg, "save_" + e,
          "file, data, title=\"Report\", theme=\"navy\", css=\"\", boxes=\"\", embed_img=true, "
          "minify=false, mode=\"w\"",
          "write a table (or HTML text) as a self-contained ." + e + " page",
          "pandas.DataFrame.to_html",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveHtml("save_" + e, a, ctx); });
  }
  addFn(reg, "NcHtml.select", "D, css", "texts of the elements matching a CSS selector",
        "BeautifulSoup.select", selectMethod);
  addFn(reg, "NcHtml.table", "D, name", "one table of a loaded page, by index (from 0), id or caption",
        "pandas.read_html", tableMethod);
}

} // namespace io
} // namespace nc
