// "@cmd io <json>" - the Import / Process / Export windows' channel to the
// I/O functions. See io_ide_api.h for the protocol and
// docs/Import_Window.md for the full contract.
//
// Everything here sits on top of what already exists - the format catalog,
// detectFormat(), optionsFor(), ImportSession::preview(), generateCode()
// (io_session.h) and the read_ / load_ / save_ functions themselves - so
// the IDE sees exactly what the io_* NC functions and a script see.
#include "io_ide_api.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <mutex>
#include <set>
#include <unordered_map>
#include <sstream>
#include <streambuf>
#include <thread>

#include "../../../data/DataSupport/JsonWriter.h"
#include "../../../data/DataSupport/ValueJson.h"
#include "../../../execution/Interrupt.h"
#include "parallel/par.h"
#include "../numpy_main.h"
#include "../numpy_registry.h"
#include "../../builtins/builtins.h"
#include "identifier_rules.h"
#include "io_columnar.h"
#include "io_common.h"
#include "io_export.h"
#include "io_session.h"
#include "io_net.h"
#include "io_probe.h"
#include "io_tree.h"
#include "io_video.h"

namespace nc {
namespace io {
namespace ide {

namespace {

constexpr int kVersion = 1;
// NC data files (.ndat): save / read / load without a suffix (io_ndat.cpp).
const char *kNdat = "ndat";

std::mutex &outputMutex() {
  static std::mutex m;
  return m;
}

void sendLine(const char *kind, const std::string &json) {
  std::lock_guard<std::mutex> lock(outputMutex());
  std::cout << '\x1E' << kind << ' ' << json << '\n' << std::flush;
}

// Every answer starts the same way.
void head(ncdata::JsonWriter &j, const std::string &id, const std::string &op, bool ok) {
  j.beginObject();
  j.key("v").integer(kVersion);
  j.key("type").string("io");
  j.key("id").string(id);
  j.key("op").string(op);
  j.key("ok").boolean(ok);
}

// The argument forms added after a function first existed, "function:form"
// (docs/Process_Window_CPP.md P3) - the window greys what is not listed.
const char *const kFeatures[] = {
    "fillmissing:method", "fillmissing:nan", "ismissing:nan", "rmmissing:nan", "unique:stable",
    "unique:sorted",      "lower:array",     "upper:array",   "replace:array", "split:array",
    "normalize:axis",     "mean:axis",       "median:axis",   "var:axis",      "sd:axis",
    "sum:axis",           "sort:axis",       "sortrows:table", "rmmissing:table",
    "astype:float8",      "process:table",   "process:sample", "functions:library",
    "check:parse"};

void opFunctions(const std::string &id) {
  ncdata::JsonWriter j;
  head(j, id, "functions", true);
  j.key("names").beginArray();
  for (const std::string &n : allBuiltinNames())
    j.string(n);
  j.endArray();
  j.key("features").beginArray();
  for (const char *f : kFeatures)
    j.string(f);
  j.endArray();
  j.endObject();
  sendLine("@IO", j.str());
}

void sendError(const std::string &id, const std::string &op, const std::string &error) {
  ncdata::JsonWriter j;
  head(j, id, op, false);
  j.key("error").string(error);
  j.endObject();
  sendLine("@IO", j.str());
}

void stringList(ncdata::JsonWriter &j, const std::vector<std::string> &items) {
  j.beginArray();
  for (const auto &s : items)
    j.string(s);
  j.endArray();
}

std::string textField(const TreeNode &req, const char *key) {
  const TreeNode *n = req.find(key);
  if (!n)
    return "";
  if (n->type == TreeNode::String)
    return n->str;
  if (n->type == TreeNode::Number) {
    char buf[64];
    std::snprintf(buf, sizeof buf, "%.17g", n->num);
    return buf;
  }
  return "";
}

std::vector<std::string> splitWords(const std::string &s) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : s) {
    if (c == ' ') {
      if (!cur.empty())
        out.push_back(cur);
      cur.clear();
    } else {
      cur += c;
    }
  }
  if (!cur.empty())
    out.push_back(cur);
  return out;
}

const numpy::FunctionSpec *specOf(const std::string &fn) {
  numpy::initialize();
  return numpy::Registry::instance().find(fn);
}

// read_csv, or read for .ndat.
std::string functionName(const std::string &action, const std::string &format) {
  return format == kNdat ? action : action + "_" + format;
}

bool knownFormat(const std::string &format) { return format == kNdat || findFormat(format); }

bool isAction(const std::string &a) { return a == "read" || a == "load" || a == "save"; }

/* ---- options given as JSON -> NC literal text ---- */

std::string numberLiteral(double d) {
  if (std::isfinite(d) && d == std::floor(d) && std::fabs(d) < 1e15) {
    char buf[32];
    std::snprintf(buf, sizeof buf, "%.0f", d);
    return buf;
  }
  char buf[64];
  std::snprintf(buf, sizeof buf, "%.17g", d);
  return buf;
}

std::string quoted(const std::string &s) {
  if (s.size() >= 2 && s.front() == '"' && s.back() == '"')
    return s;
  std::string out = "\"";
  for (char c : s)
    out += c == '"' ? std::string("\\\"") : std::string(1, c);
  return out + "\"";
}

// A JSON string is the option's text as typed in the window (NC literal
// syntax, a bare word counting as text - ImportSession::setOption's rule);
// numbers, true / false and arrays are written as NC literals. null = not
// given.
bool literalOf(const TreeNode &n, std::string &out) {
  switch (n.type) {
  case TreeNode::Null:
    return false;
  case TreeNode::Bool:
    out = n.b ? "true" : "false";
    return true;
  case TreeNode::Number:
    out = numberLiteral(n.num);
    return true;
  case TreeNode::String:
    out = n.str;
    return true;
  case TreeNode::Array: {
    out = "[";
    for (size_t i = 0; i < n.items.size(); i++) {
      const TreeNode &it = n.items[i];
      std::string piece;
      if (it.type == TreeNode::String)
        piece = quoted(it.str);
      else if (!literalOf(it, piece))
        piece = "\"\"";
      out += (i ? ", " : "") + piece;
    }
    out += "]";
    return true;
  }
  case TreeNode::Object:
    return false;
  }
  return false;
}

std::vector<OptionSpec> optionList(const std::string &action, const std::string &format) {
  std::vector<OptionSpec> opts;
  if (format != kNdat) {
    opts = optionsFor(format, action);
  } else if (const numpy::FunctionSpec *spec = specOf(action)) {
    // .ndat functions: the same rule as optionsFor(), from their parameter line.
    (void)spec;
    if (action == "read") {
      opts.push_back({"name", "text", "\"\"", "one entry of the file (\"\" = all of it)", {}});
      opts.push_back({"part", "text", "\"\"", "part of that entry: a slice \"1:100, :\" or columns", {}});
    } else if (action == "save") {
      opts.push_back({"data", "value", "", "the value to save", {}});
      opts.push_back({"policy", "text", "\"auto\"", "how each entry is stored",
                      {"auto", "compact", "fast", "native", "hdf5", "parquet", "arrow"}});
      opts.push_back({"zip", "bool", "false", "write the file into <file>.zip instead (deflate)", {}}); // E12
    }
  }
  // "data" of a save is the request's own "data" field, not an option.
  opts.erase(std::remove_if(opts.begin(), opts.end(), [](const OptionSpec &o) { return o.name == "data"; }),
             opts.end());
  return opts;
}

std::string unquote(const std::string &s) {
  std::string t = trim(s);
  if (t.size() >= 2 && t.front() == '"' && t.back() == '"')
    return t.substr(1, t.size() - 2);
  return t;
}

/* ---- several variables in one file (X1/X2, docs/Export_Process_Modules_CPP.md) ----

   "data": ["A", "B"] (the Export window's + Add New) saves the variables
   together as dict(A=A, B=B): one entry per variable in .ndat and the
   containers, one column per variable (a matrix gives its columns) in the
   table formats, refused by the one-variable formats. "labels" (optional,
   as long as "data") gives each its key - the name the user sees - when it
   differs from the workspace name in "data". */

enum class SetRule { Any, Columns, One };

SetRule setRuleOf(const std::string &format) {
  static const std::set<std::string> any = {kNdat, "mat", "h5", "hdf", "he5", "nc", "cdf", "json", "yaml", "yml"};
  static const std::set<std::string> columns = {"csv",  "tsv",     "txt",     "dat", "xlsx",   "xls", "xlsm",
                                                "xlsb", "parquet", "feather", "orc", "sqlite", "dbf"};
  if (any.count(format))
    return SetRule::Any;
  if (columns.count(format))
    return SetRule::Columns;
  return SetRule::One;
}

struct VarSet {
  std::vector<std::string> names; // workspace names
  std::vector<std::string> keys;  // their keys in the file
};

// "data" given as a JSON array. False when it is not one (a single name).
bool readVarSet(const TreeNode &req, VarSet &s) {
  const TreeNode *d = req.find("data");
  if (!d || d->type != TreeNode::Array)
    return false;
  for (const auto &it : d->items)
    s.names.push_back(it.type == TreeNode::String ? trim(it.str) : std::string());
  s.keys = s.names;
  if (const TreeNode *l = req.find("labels"); l && l->type == TreeNode::Array && l->items.size() == s.names.size())
    for (size_t i = 0; i < l->items.size(); i++) {
      std::string why;
      const std::string label = l->items[i].type == TreeNode::String ? trim(l->items[i].str) : std::string();
      if (!label.empty() && ncident::validateName(label, why))
        s.keys[i] = label;
    }
  return true;
}

// Rows of one value as table columns (valueToTable()'s rule): a vector is
// its length, a 2-D matrix its rows, a single value 1. False: no column.
bool columnRows(const Value &v, size_t &rows) {
  if (v.isND() || v.isDict || v.isObject)
    return false;
  if (v.isArray)
    rows = v.length();
  else if (v.isMatrix)
    rows = (v.rows() <= 1 || v.cols() <= 1) ? v.rows() * v.cols() : v.rows();
  else
    rows = 1;
  return true;
}

// One message per problem.
void checkVarSet(const VarSet &s, const Workspace &globals, const std::string &format,
                 std::vector<std::string> &errors) {
  if (s.names.empty()) {
    errors.push_back("\"data\" is missing - the variable (or NC expression) to save");
    return;
  }
  bool allFound = true;
  for (const auto &n : s.names) {
    std::string why;
    if (n.empty()) {
      errors.push_back("\"data\" holds an empty name");
      allFound = false;
    } else if (!ncident::validateName(n, why)) {
      errors.push_back("\"" + n + "\" is not a variable name - a list in \"data\" holds names only");
      allFound = false;
    } else if (!globals.count(n)) {
      errors.push_back("'" + n + "' is not in the workspace");
      allFound = false;
    }
  }
  std::set<std::string> seen, seenKeys;
  for (size_t i = 0; i < s.names.size(); i++)
    if (!seen.insert(s.names[i]).second || !seenKeys.insert(s.keys[i]).second) {
      errors.push_back("the variables must be different");
      break;
    }
  if (s.names.size() < 2 || format.empty())
    return;
  switch (setRuleOf(format)) {
  case SetRule::Any:
    return;
  case SetRule::One:
    errors.push_back(format + " holds one variable - give one name, or save as .ndat");
    return;
  case SetRule::Columns:
    break;
  }
  if (!allFound)
    return;
  size_t first = 0;
  for (size_t i = 0; i < s.names.size(); i++) {
    size_t rows = 0;
    if (!columnRows(globals.at(s.names[i]), rows)) {
      errors.push_back("'" + s.keys[i] + "' cannot be a table column - only vectors and 2-D matrices can (save as .ndat)");
      return;
    }
    if (i == 0) {
      first = rows;
    } else if (rows != first) {
      errors.push_back("the columns must be equally long: " + s.keys[0] + " has " + std::to_string(first) +
                       (first == 1 ? " value, " : " values, ") + s.keys[i] + " has " + std::to_string(rows));
      return;
    }
  }
}

// The NC expression the save line writes: the name itself for one variable,
// dict(A=A, B=B) for several.
std::string setExpression(const VarSet &s) {
  if (s.names.size() == 1)
    return s.names[0];
  std::string e = "dict(";
  for (size_t i = 0; i < s.names.size(); i++)
    e += (i ? ", " : "") + s.keys[i] + "=" + s.names[i];
  return e + ")";
}

// The value that expression gives (the workspace values, keys in order).
Value setValue(const VarSet &s, const Workspace &globals) {
  if (s.names.size() == 1)
    return globals.at(s.names[0]);
  std::unordered_map<std::string, Value> d;
  for (size_t i = 0; i < s.names.size(); i++)
    d[s.keys[i]] = globals.at(s.names[i]);
  Value v(d);
  v.dictOrderHintMut() = s.keys;
  return v;
}

/* ---- the request for code / run, checked ---- */

struct CodeRequest {
  std::string action, format, file, var, data, function, code;
  std::vector<std::pair<std::string, std::string>> options;
  std::vector<std::string> errors;
  bool isSet = false;           // "data" was a list (X1)
  std::vector<std::string> vars; // its names
};

void buildCode(const TreeNode &req, const Workspace &globals, CodeRequest &c) {
  c.action = lower(textField(req, "action"));
  c.format = lower(textField(req, "format"));
  c.file = textField(req, "file");
  c.var = trim(textField(req, "var"));
  c.data = trim(textField(req, "data"));

  if (c.format.empty() && !c.file.empty()) {
    if (lower(extensionOf(c.file)) == kNdat)
      c.format = kNdat;
    else
      c.format = detectFormat(c.file).format;
  }
  if (!isAction(c.action))
    c.errors.push_back("action must be \"read\", \"load\" or \"save\"");
  if (c.format.empty())
    c.errors.push_back("the format is not known - give \"format\", e.g. \"csv\"");
  else if (!knownFormat(c.format))
    c.errors.push_back("unknown format \"" + c.format + "\" - see op \"formats\"");
  if (c.file.empty())
    c.errors.push_back("\"file\" is missing");
  if (!c.errors.empty())
    return;

  c.function = functionName(c.action, c.format);
  if (!specOf(c.function)) {
    c.errors.push_back(c.function + " is not available");
    return;
  }

  // The variable the line fills (read / load) or the data it writes (save).
  VarSet set;
  if (c.action == "save" && readVarSet(req, set)) {
    // X1: several variables into one file
    c.isSet = true;
    c.vars = set.names;
    checkVarSet(set, globals, c.format, c.errors);
    c.data = setExpression(set);
  } else if (c.action == "save") {
    if (c.data.empty()) {
      c.errors.push_back("\"data\" is missing - the variable (or NC expression) to save");
    } else {
      std::string why;
      if (ncident::validateName(c.data, why) && !globals.count(c.data))
        c.errors.push_back("'" + c.data + "' is not in the workspace");
    }
  } else {
    if (c.var.empty())
      c.var = c.action == "load" ? "D" : "T";
    std::string why;
    if (!ncident::validateName(c.var, why))
      c.errors.push_back("\"" + c.var + "\" cannot be a variable name: " + why);
  }

  // Options: known names only, choice values checked.
  const std::vector<OptionSpec> specs = optionList(c.action, c.format);
  if (const TreeNode *opts = req.find("options")) {
    if (opts->type != TreeNode::Object) {
      c.errors.push_back("\"options\" must be an object: {\"name\": value}");
    } else {
      for (const auto &kv : opts->keys) {
        std::string literal;
        if (!literalOf(kv.second, literal) || trim(literal).empty())
          continue; // not given
        auto spec = std::find_if(specs.begin(), specs.end(),
                                 [&](const OptionSpec &o) { return o.name == kv.first; });
        if (spec == specs.end()) {
          std::string names;
          for (const auto &o : specs)
            names += (names.empty() ? "" : ", ") + o.name;
          c.errors.push_back(c.function + " has no option '" + kv.first + "'" +
                             (names.empty() ? " - it takes none" : " - its options are: " + names));
          continue;
        }
        // "no" is the same as "none" for the writers that switch compression off (compressOn)
        const std::string chosen = unquote(literal);
        const bool alias = chosen == "no" && std::find(spec->choices.begin(), spec->choices.end(), "none") != spec->choices.end();
        if (!spec->choices.empty() && !alias &&
            std::find(spec->choices.begin(), spec->choices.end(), chosen) == spec->choices.end()) {
          std::string list;
          for (const auto &ch : spec->choices)
            list += (list.empty() ? "\"" : ", \"") + ch + "\"";
          c.errors.push_back(kv.first + " must be one of " + list);
          continue;
        }
        Value parsed;
        std::string err;
        if (!parseLiteral(literal, parsed, err)) {
          c.errors.push_back(kv.first + ": " + err);
          continue;
        }
        c.options.push_back({kv.first, literal});
      }
    }
  }

  // The same generator as io_code() / ImportSession::code().
  const std::string fmtForCode = c.format == kNdat ? std::string("ndat") : c.format;
  c.code = generateCode(c.action, fmtForCode, c.file, c.action == "save" ? c.data : c.var, c.options);
  if (c.format == kNdat) {
    const std::string from = c.action + "_ndat(";
    const size_t at = c.code.find(from);
    if (at != std::string::npos)
      c.code.replace(at, from.size(), c.action + "(");
  }
}

void writeCodeFields(ncdata::JsonWriter &j, const CodeRequest &c) {
  j.key("action").string(c.action);
  j.key("format").string(c.format);
  j.key("function").string(c.function);
  j.key("file").string(c.file);
  j.key("var").string(c.action == "save" ? "" : c.var);
  j.key("data").string(c.action == "save" ? c.data : "");
  if (c.isSet) {
    // the window checks for this key: the list was understood (X1)
    j.key("vars");
    stringList(j, c.vars);
  }
  j.key("code").string(c.code);
  j.key("errors");
  stringList(j, c.errors);
}

/* ---- the ops ---- */

void opFormats(const std::string &id) {
  ncdata::JsonWriter j;
  head(j, id, "formats", true);
  j.key("formats").beginArray();
  auto one = [&](const std::string &fid, const std::string &cat, const std::string &title,
                 const std::string &exts) {
    j.beginObject();
    j.key("id").string(fid);
    j.key("category").string(cat);
    j.key("title").string(title);
    j.key("extensions");
    stringList(j, splitWords(exts));
    for (const char *action : {"read", "load", "save"}) {
      const std::string fn = functionName(action, fid);
      j.key(action).string(specOf(fn) ? fn : "");
    }
    j.endObject();
  };
  for (const auto &f : formatCatalog())
    one(f.id, f.category, f.title, f.extensions);
  one(kNdat, "NC data", "NC Data Bundle", ".ndat");
  j.endArray();
  j.endObject();
  sendLine("@IO", j.str());
}

void opDetect(const std::string &id, const TreeNode &req) {
  const std::string file = textField(req, "file");
  if (file.empty())
    return sendError(id, "detect", "\"file\" is missing");
  Detection d;
  if (lower(extensionOf(file)) == kNdat) {
    d.format = kNdat;
    d.category = "NC data";
    d.confidence = 1;
    d.reason = "extension .ndat";
  } else {
    d = detectFormat(file);
  }
  ncdata::JsonWriter j;
  head(j, id, "detect", true);
  j.key("file").string(file);
  j.key("format").string(d.format);
  j.key("category").string(d.category);
  j.key("confidence").number(d.confidence);
  j.key("reason").string(d.reason);
  j.key("compressed").boolean(d.compressed);
  for (const char *action : {"read", "load", "save"}) {
    const std::string fn = d.format.empty() ? "" : functionName(action, d.format);
    j.key(action).string(!fn.empty() && specOf(fn) ? fn : "");
  }
  j.endObject();
  sendLine("@IO", j.str());
}

void opOptions(const std::string &id, const TreeNode &req) {
  const std::string format = lower(textField(req, "format"));
  std::string action = lower(textField(req, "action"));
  if (action.empty())
    action = "read";
  if (!isAction(action))
    return sendError(id, "options", "action must be \"read\", \"load\" or \"save\"");
  if (!knownFormat(format))
    return sendError(id, "options", "unknown format \"" + format + "\" - see op \"formats\"");
  const std::string fn = functionName(action, format);
  const numpy::FunctionSpec *spec = specOf(fn);
  if (!spec)
    return sendError(id, "options", fn + " is not available");
  ncdata::JsonWriter j;
  head(j, id, "options", true);
  j.key("format").string(format);
  j.key("action").string(action);
  j.key("function").string(fn);
  j.key("signature").string(spec->signature);
  j.key("summary").string(spec->summary);
  j.key("options").beginArray();
  for (const auto &o : optionList(action, format)) {
    j.beginObject();
    j.key("name").string(o.name);
    j.key("type").string(o.type);
    j.key("default").string(o.defaultText);
    j.key("help").string(o.help);
    j.key("choices");
    stringList(j, o.choices);
    j.endObject();
  }
  j.endArray();
  // Hard limits of the reader, as data (the window warns with the same numbers).
  j.key("limits").beginObject();
  if (action == "read" && (format == "mp4" || format == "avi" || format == "m4v" || format == "mov"))
    j.key("values").unsignedInteger(kVideoValueLimit); // frames x height x width x channels per call
  j.endObject();
  j.endObject();
  sendLine("@IO", j.str());
}

void writePreview(ncdata::JsonWriter &j, const Preview &p) {
  j.key("kind").string(p.kind);
  j.key("cols");
  stringList(j, p.cols);
  j.key("rows").beginArray();
  for (const auto &r : p.rows)
    stringList(j, r);
  j.endArray();
  // -1 = only the start was read; total_rows_estimate then guesses the rest
  if (p.totalExact)
    j.key("total_rows").unsignedInteger(p.totalRows);
  else
    j.key("total_rows").integer(-1);
  j.key("total_rows_estimate").integer(p.totalExact ? static_cast<long long>(p.totalRows) : p.totalEstimate);
  j.key("rows_read").unsignedInteger(p.rows.size());
  j.key("limits").beginObject();
  for (const auto &kv : p.limits)
    j.key(kv.first).string(kv.second);
  j.endObject();
  j.key("boxes");
  stringList(j, p.boxes);
  j.key("note").string(p.note);
}

long long rowsOf(const TreeNode &req) {
  long long rows = 20;
  if (const TreeNode *n = req.find("rows"); n && n->type == TreeNode::Number && n->num >= 1)
    rows = static_cast<long long>(n->num);
  return rows;
}

// One entry of a .ndat bundle (R14): options name= (and part=) as for read().
// A table or matrix entry is read as its first rows ("1:N, :"); when that
// part does not fit the entry (a vector, a short matrix) it is read whole.
void opPreviewNdat(const std::string &id, const TreeNode &req, const std::string &file) {
  std::vector<std::pair<std::string, std::string>> opts;
  bool partGiven = false;
  if (const TreeNode *o = req.find("options"); o && o->type == TreeNode::Object)
    for (const auto &kv : o->keys) {
      std::string literal;
      if (!literalOf(kv.second, literal) || trim(literal).empty())
        continue;
      if (kv.first != "name" && kv.first != "part")
        return sendError(id, "preview", "read has no option '" + kv.first + "' - its options are: name, part");
      partGiven = partGiven || kv.first == "part";
      if (kv.first == "name" && literal.front() != '"')
        literal = (quoted)(literal); // (quoted): not std::quoted by ADL
      opts.push_back({kv.first, literal});
    }
  const bool named = std::any_of(opts.begin(), opts.end(), [](const auto &kv) { return kv.first == "name"; });
  const size_t rows = static_cast<size_t>(rowsOf(req));
  std::vector<Value> res;
  std::string err;
  bool limited = false;
  std::ostringstream quiet;
  std::streambuf *old = std::cerr.rdbuf(quiet.rdbuf());
  if (named && !partGiven) {
    auto first = opts;
    first.push_back({"part", "\"1:" + std::to_string(rows) + ", :\""});
    limited = callIoFunction("read", first, file, 1, res, err);
  }
  bool ok = limited || callIoFunction("read", opts, file, 1, res, err);
  std::cerr.rdbuf(old);
  if (!ok)
    return sendError(id, "preview", err);
  Preview p;
  fillPreview(res[0], nullptr, rows, p);
  if (limited) {
    p.limits.push_back({"part", "1:" + std::to_string(rows) + ", :"});
    // a table of named columns previews as a tree of its columns: its
    // row count is not the number of tree rows (the TOC has it)
    if (p.totalRows >= rows || p.kind == "tree") {
      p.totalExact = false;
      p.totalEstimate = -1;
    }
  }
  ncdata::JsonWriter j;
  head(j, id, "preview", true);
  j.key("file").string(file);
  j.key("format").string(kNdat);
  writePreview(j, p);
  std::string code = "T = read(\"" + file + "\"";
  for (const auto &kv : opts)
    code += ", " + kv.first + "=" + kv.second;
  j.key("code").string(code + ");");
  j.endObject();
  sendLine("@IO", j.str());
}

// op "probe" (R3): what the file holds, from its header / footer / TOC.
void opProbe(const std::string &id, const TreeNode &req) {
  const std::string file = textField(req, "file");
  if (file.empty())
    return sendError(id, "probe", "\"file\" is missing");
  std::string format = lower(textField(req, "format"));
  if (format.empty())
    format = lower(extensionOf(file)) == kNdat ? std::string(kNdat) : detectFormat(file).format;
  if (format.empty())
    return sendError(id, "probe", "the format of " + file + " is not known - give \"format\"");
  ncdata::JsonWriter j;
  head(j, id, "probe", true);
  j.key("file").string(file);
  j.key("format").string(format);
  std::string err;
  std::ostringstream quiet;
  std::streambuf *old = std::cerr.rdbuf(quiet.rdbuf());
  const bool ok = probeFile(file, format, j, err);
  std::cerr.rdbuf(old);
  if (!ok)
    return sendError(id, "probe", err.empty() ? "cannot probe " + file : err);
  j.endObject();
  sendLine("@IO", j.str());
}

// op "thumbnail" (R4): one picture (or video frame) as a base64 PNG.
void opThumbnail(const std::string &id, const TreeNode &req) {
  const std::string file = textField(req, "file");
  if (file.empty())
    return sendError(id, "thumbnail", "\"file\" is missing");
  std::string format = lower(textField(req, "format"));
  if (format.empty())
    format = lower(extensionOf(file)) == kNdat ? std::string(kNdat) : detectFormat(file).format;
  long long frame = 0;
  double time = -1;
  size_t maxSide = 520;
  if (const TreeNode *n = req.find("frame"); n && n->type == TreeNode::Number && n->num >= 0)
    frame = static_cast<long long>(n->num);
  if (const TreeNode *n = req.find("time"); n && n->type == TreeNode::Number && n->num >= 0)
    time = n->num;
  if (const TreeNode *n = req.find("max"); n && n->type == TreeNode::Number && n->num >= 16)
    maxSide = static_cast<size_t>(std::min(8192.0, n->num));
  Thumbnail t;
  std::string err;
  std::ostringstream quiet;
  std::streambuf *old = std::cerr.rdbuf(quiet.rdbuf());
  const bool ok = makeThumbnail(file, format, frame, time, maxSide, t, err);
  std::cerr.rdbuf(old);
  if (!ok)
    return sendError(id, "thumbnail", err.empty() ? "no picture in " + file : err);
  ncdata::JsonWriter j;
  head(j, id, "thumbnail", true);
  j.key("file").string(file);
  j.key("format").string(format);
  j.key("png").string(base64Encode(t.png));
  j.key("width").unsignedInteger(t.width);
  j.key("height").unsignedInteger(t.height);
  j.key("thumb_width").unsignedInteger(t.thumbWidth);
  j.key("thumb_height").unsignedInteger(t.thumbHeight);
  j.key("frame").integer(time >= 0 ? -1 : static_cast<long long>(t.frame));
  j.endObject();
  sendLine("@IO", j.str());
}

/* ---- the Export window's questions (2026-11-17, docs/Export_Window.md) ---- */

// The variable a request's "data" names. Only a name: an expression is not
// run before the user presses Save. A list of names (X2) is the dict a save
// of them writes (dict(A=A, B=B), keys in order) - `holder` keeps it - and
// is checked by the same rules as op "code" for `format`.
const Value *dataValue(const TreeNode &req, const Workspace &globals, std::string &err, Value *holder = nullptr,
                       const std::string &format = std::string()) {
  VarSet set;
  if (holder && readVarSet(req, set)) {
    std::vector<std::string> errors;
    checkVarSet(set, globals, format, errors);
    if (!errors.empty()) {
      err = errors.front();
      return nullptr;
    }
    *holder = setValue(set, globals);
    return holder;
  }
  const std::string data = trim(textField(req, "data"));
  if (data.empty()) {
    err = "\"data\" is missing - the variable to look at";
    return nullptr;
  }
  std::string why;
  if (!ncident::validateName(data, why)) {
    err = "\"data\" must be a variable name here (\"" + data + "\" is an expression; it runs only on Save)";
    return nullptr;
  }
  auto it = globals.find(data);
  if (it == globals.end()) {
    err = "'" + data + "' is not in the workspace";
    return nullptr;
  }
  return &it->second;
}

// "data" as the save line writes it: the name, or dict(A=A, B=B) for a list.
std::string dataText(const TreeNode &req) {
  VarSet set;
  if (readVarSet(req, set))
    return set.names.empty() ? std::string() : setExpression(set);
  return trim(textField(req, "data"));
}

// A save format the trial-save questions can answer for (a file is written).
bool fileFormat(const std::string &format, std::string &err) {
  if (!knownFormat(format)) {
    err = "unknown format \"" + format + "\" - see op \"formats\"";
    return false;
  }
  if (!savesFile(functionName("save", format))) {
    err = "save_" + format + " writes to a database server, not a file";
    return false;
  }
  return true;
}

// The options of a save, as NC literals; unknown names are errors.
bool saveOptions(const TreeNode *opts, const std::string &format, exportx::Options &out, std::string &err) {
  out.clear();
  if (!opts || opts->type == TreeNode::Null)
    return true;
  if (opts->type != TreeNode::Object) {
    err = "\"options\" must be an object: {\"name\": value}";
    return false;
  }
  const std::vector<OptionSpec> specs = optionList("save", format);
  for (const auto &kv : opts->keys) {
    std::string literal;
    if (!literalOf(kv.second, literal) || trim(literal).empty())
      continue;
    const bool known = std::any_of(specs.begin(), specs.end(), [&](const OptionSpec &o) { return o.name == kv.first; });
    // an option the catalogue hides (the writer ignores it) is still accepted
    if (!known && !specOf(functionName("save", format))->signature.empty() &&
        specOf(functionName("save", format))->signature.find(kv.first + "=") == std::string::npos) {
      err = functionName("save", format) + " has no option '" + kv.first + "'";
      return false;
    }
    out.push_back({kv.first, literal});
  }
  return true;
}

void writeStrings(ncdata::JsonWriter &j, const char *key, const std::vector<std::string> &items) {
  j.key(key);
  stringList(j, items);
}

// op "target" (E3): the file about to be written - without touching it.
void opTarget(const std::string &id, const TreeNode &req) {
  const std::string file = textField(req, "file");
  if (file.empty())
    return sendError(id, "target", "\"file\" is missing");
  ncdata::JsonWriter j;
  head(j, id, "target", true);
  j.key("file").string(file);
  exportx::writeTarget(j, file, lower(textField(req, "format")));
  j.endObject();
  sendLine("@IO", j.str());
}

// op "accepts" (E4): can this value be saved as this format, what changes,
// and which formats keep it whole. ok comes from the writer itself, run on
// the value (or its first rows) in a scratch folder.
void opAccepts(const std::string &id, const TreeNode &req, const Workspace &globals) {
  std::string err;
  const std::string format = lower(textField(req, "format"));
  Value set;
  const Value *v = dataValue(req, globals, err, &set, format);
  if (!v)
    return sendError(id, "accepts", err);
  if (!fileFormat(format, err))
    return sendError(id, "accepts", err);
  exportx::Options opts;
  if (!saveOptions(req.find("options"), format, opts, err))
    return sendError(id, "accepts", err);
  std::vector<std::string> errors;
  const std::string limit = exportx::sizeLimitError(format, *v);
  if (!limit.empty())
    errors.push_back(limit);
  exportx::Trial t;
  if (errors.empty() && !exportx::trialSave(format, exportx::sampleRows(*v, 64), opts, t))
    errors.push_back(t.error);
  ncdata::JsonWriter j;
  head(j, id, "accepts", errors.empty());
  j.key("data").string(dataText(req));
  j.key("format").string(format);
  j.key("kind").string(exportx::valueKind(*v));
  j.key("dtype").string(exportx::dtypeOf(*v));
  j.key("shape").beginArray();
  for (size_t d : exportx::shapeOf(*v))
    j.unsignedInteger(d);
  j.endArray();
  writeStrings(j, "errors", errors);
  writeStrings(j, "losses", errors.empty() ? exportx::lossesOf(format, *v, opts) : std::vector<std::string>{});
  writeStrings(j, "warnings", t.warnings);
  const bool wantSuggest = !(req.find("suggest") && req.find("suggest")->type == TreeNode::Bool && !req.find("suggest")->b);
  writeStrings(j, "suggest", wantSuggest ? exportx::suggestFormats(*v) : std::vector<std::string>{});
  if (!errors.empty())
    j.key("error").string(errors.front());
  j.endObject();
  sendLine("@IO", j.str());
}

// op "estimate" (E15): the bytes of the file for several option sets at once.
void opEstimate(const std::string &id, const TreeNode &req, const Workspace &globals) {
  std::string err;
  const std::string format = lower(textField(req, "format"));
  Value set;
  const Value *v = dataValue(req, globals, err, &set, format);
  if (!v)
    return sendError(id, "estimate", err);
  if (!fileFormat(format, err))
    return sendError(id, "estimate", err);
  std::vector<const TreeNode *> sets;
  if (const TreeNode *s = req.find("sets"); s && s->type == TreeNode::Array)
    for (const auto &it : s->items)
      sets.push_back(&it);
  if (sets.empty())
    sets.push_back(req.find("options")); // one set: the request's options
  ncdata::JsonWriter j;
  head(j, id, "estimate", true);
  j.key("format").string(format);
  j.key("rows").unsignedInteger(exportx::axisLength(*v));
  j.key("bytes").beginArray();
  std::vector<std::string> errors;
  std::vector<bool> exact;
  for (const TreeNode *s : sets) {
    exportx::Options opts;
    std::string oerr;
    if (!saveOptions(s, format, opts, oerr)) {
      j.integer(-1);
      errors.push_back(oerr);
      exact.push_back(false);
      continue;
    }
    const exportx::Estimate e = exportx::estimateBytes(format, *v, opts);
    if (e.ok)
      j.unsignedInteger(e.bytes);
    else
      j.integer(-1);
    errors.push_back(e.ok ? std::string() : e.error);
    exact.push_back(e.exact);
  }
  j.endArray();
  j.key("exact").beginArray();
  for (bool b : exact)
    j.boolean(b);
  j.endArray();
  writeStrings(j, "errors", errors);
  j.endObject();
  sendLine("@IO", j.str());
}

// op "peek" (E11): a bounded look at a variable of any size.
void opPeek(const std::string &id, const TreeNode &req, const Workspace &globals) {
  std::string err;
  Value set;
  const Value *v = dataValue(req, globals, err, &set);
  if (!v)
    return sendError(id, "peek", err);
  exportx::PeekLimits lim;
  auto num = [&](const char *key, size_t &out, size_t lo, size_t hi) {
    if (const TreeNode *n = req.find(key); n && n->type == TreeNode::Number && n->num >= 0)
      out = std::clamp(static_cast<size_t>(n->num), lo, hi);
  };
  num("rows", lim.rows, 1, 100000);
  num("cols", lim.cols, 1, 10000);
  num("max_side", lim.maxSide, 16, 4096);
  num("buckets", lim.buckets, 1, 100000);
  num("nodes", lim.nodes, 1, 100000);
  ncdata::JsonWriter j;
  head(j, id, "peek", true);
  j.key("data").string(dataText(req));
  exportx::writePeek(j, *v, lim);
  j.endObject();
  sendLine("@IO", j.str());
}

// op "preview" with action "save" (E5): what the file will hold, before it
// is written - the first lines of a text format, a columnar format's schema,
// an image's size - and its estimated bytes.
void opPreviewSave(const std::string &id, const TreeNode &req, const Workspace &globals) {
  std::string err;
  const std::string format = lower(textField(req, "format"));
  Value set;
  const Value *v = dataValue(req, globals, err, &set, format);
  if (!v)
    return sendError(id, "preview", err);
  if (!fileFormat(format, err))
    return sendError(id, "preview", err);
  exportx::Options opts;
  if (!saveOptions(req.find("options"), format, opts, err))
    return sendError(id, "preview", err);
  const size_t rows = static_cast<size_t>(rowsOf(req));
  const std::string limit = exportx::sizeLimitError(format, *v);
  if (!limit.empty())
    return sendError(id, "preview", limit);
  const Value sample = exportx::sampleRows(*v, rows);
  exportx::Trial t;
  if (!exportx::trialSave(format, sample, opts, t, true)) {
    exportx::dropTrial(t);
    return sendError(id, "preview", t.error);
  }
  ncdata::JsonWriter j;
  head(j, id, "preview", true);
  j.key("action").string("save");
  j.key("format").string(format);
  j.key("function").string(functionName("save", format));
  j.key("kind").string(exportx::valueKind(*v));
  j.key("dtype").string(exportx::dtypeOf(*v));
  j.key("shape").beginArray();
  for (size_t d : exportx::shapeOf(*v))
    j.unsignedInteger(d);
  j.endArray();
  j.key("total_rows").unsignedInteger(exportx::axisLength(*v));
  j.key("rows_shown").unsignedInteger(exportx::axisLength(sample));
  // text formats: the first lines exactly as written (gz / zlib undone)
  std::vector<std::string> lines;
  if (format == "csv" || format == "tsv" || format == "txt" || format == "dat" || format == "json" || format == "xml" ||
      format == "html" || format == "htm" || format == "yaml" || format == "yml" || format == "ini") {
    std::string raw, text, derr;
    if (readFileHead(t.file, size_t(256) << 10, raw, derr) && autoDecompress(raw, derr)) {
      std::string enc = "utf-8";
      for (const auto &kv : opts)
        if (kv.first == "enc")
          enc = unquote(kv.second);
      if (!decodeText(raw, enc, text, derr))
        text = raw;
      std::istringstream in(text);
      std::string line;
      while (lines.size() < rows + 20 && std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r')
          line.pop_back();
        lines.push_back(line);
      }
    }
  }
  writeStrings(j, "lines", lines);
  // columnar formats: the column types the writer uses, and the codec
  j.key("schema").beginArray();
  if (format == "parquet" || format == "feather" || format == "orc") {
    Table tb;
    std::string terr;
    if (valueToTable(sample, tb, terr, true, true)) {
      const std::vector<std::string> kinds = writeKinds(tb);
      for (size_t c = 0; c < tb.cols.size() && c < kinds.size(); c++) {
        j.beginObject();
        j.key("name").string(tb.cols[c]);
        j.key("type").string(kinds[c]);
        j.endObject();
      }
    }
  }
  j.endArray();
  std::string codec;
  for (const auto &kv : opts)
    if (kv.first == "compress" || kv.first == "codec")
      codec = unquote(kv.second);
  if (codec.empty())
    for (const auto &o : optionList("save", format))
      if (o.name == "compress" || o.name == "codec")
        codec = unquote(o.defaultText);
  j.key("codec").string(codec);
  // pictures: their size; sound: its rate and length
  const auto shape = exportx::shapeOf(*v);
  const std::string kind = exportx::valueKind(*v);
  if (kind == "image" || kind == "video") {
    const size_t off = kind == "video" ? 1 : 0;
    j.key("height").unsignedInteger(shape.size() > off ? shape[off] : 0);
    j.key("width").unsignedInteger(shape.size() > off + 1 ? shape[off + 1] : 0);
    j.key("channels").unsignedInteger(shape.size() > off + 2 ? shape[off + 2] : 1);
  }
  exportx::dropTrial(t);
  const exportx::Estimate e = exportx::estimateBytes(format, *v, opts);
  j.key("estimate_bytes").integer(e.ok ? static_cast<long long>(e.bytes) : -1);
  j.key("estimate_exact").boolean(e.exact);
  writeStrings(j, "losses", exportx::lossesOf(format, *v, opts));
  writeStrings(j, "warnings", t.warnings);
  j.key("code").string(generateCode("save", format == kNdat ? std::string("ndat") : format,
                                    textField(req, "file").empty() ? "out." + format : textField(req, "file"),
                                    dataText(req), opts));
  j.endObject();
  sendLine("@IO", j.str());
}

void opPreview(const std::string &id, const TreeNode &req) {
  const std::string file = textField(req, "file");
  if (file.empty())
    return sendError(id, "preview", "\"file\" is missing");
  ImportSession s;
  s.setSource(file);
  const std::string format = lower(textField(req, "format"));
  if (!format.empty())
    s.setFormat(format);
  else
    s.detect();
  if (s.format() == kNdat || lower(extensionOf(file)) == kNdat)
    return opPreviewNdat(id, req, file);
  if (const TreeNode *opts = req.find("options"); opts && opts->type == TreeNode::Object) {
    for (const auto &kv : opts->keys) {
      std::string literal;
      if (literalOf(kv.second, literal) && !trim(literal).empty())
        s.setOption(kv.first, literal);
    }
  }
  const long long rows = rowsOf(req);
  Preview p;
  std::string err;
  std::ostringstream quiet; // a reader's own "Error:" line goes into err, not the Command Window
  std::streambuf *old = std::cerr.rdbuf(quiet.rdbuf());
  const bool ok = s.preview(static_cast<size_t>(rows), p, err);
  std::cerr.rdbuf(old);
  if (!ok)
    return sendError(id, "preview", err);
  ncdata::JsonWriter j;
  head(j, id, "preview", true);
  j.key("file").string(file);
  j.key("format").string(s.format());
  writePreview(j, p);
  j.key("code").string(s.code("read"));
  j.endObject();
  sendLine("@IO", j.str());
}

void opCode(const std::string &id, const TreeNode &req, const Workspace &globals) {
  CodeRequest c;
  buildCode(req, globals, c);
  ncdata::JsonWriter j;
  head(j, id, "code", c.errors.empty());
  writeCodeFields(j, c);
  if (!c.errors.empty())
    j.key("error").string(c.errors.front());
  j.endObject();
  sendLine("@IO", j.str());
}

void opRun(const std::string &id, const TreeNode &req, const Workspace &globals, RunRequest &run) {
  const std::string freeCode = textField(req, "code");
  if (!freeCode.empty()) {
    // The Process window's own NC text (slicing, trimming, ...).
    run.id = id;
    run.code = freeCode;
    run.var = trim(textField(req, "var"));
    run.action = "code";
    return;
  }
  CodeRequest c;
  buildCode(req, globals, c);
  if (!c.errors.empty()) {
    ncdata::JsonWriter j;
    head(j, id, "run", false);
    writeCodeFields(j, c);
    j.key("error").string(c.errors.front());
    j.endObject();
    sendLine("@IO", j.str());
    return;
  }
  run.id = id;
  run.code = c.code;
  run.var = c.action == "save" ? "" : c.var;
  run.action = c.action;
  run.function = c.function;
}

/* ---- the memory a variable holds (the run answer's "bytes", R10) ---- */

// The bytes of a value's data as NC keeps it: a packed array / matrix /
// N-D tensor takes 8 bytes per number (16 complex); a cell, dict or object
// takes one Value per element plus what each holds; text its characters.
uint64_t valueBytes(const Value &v, int depth = 0) {
  constexpr uint64_t kCell = sizeof(Value);
  if (depth > 64)
    return kCell;
  if (v.isPacked() || v.isPackedComplex() || v.isTypedPacked())
    return static_cast<uint64_t>(v.tensorBytes()); // typed: 1 - 8 bytes per element (R9)
  if (v.isText)
    return v.text().size();
  if (v.isColumnar() || v.isColumnarArray()) { // column storage (§9): its buffers, plus what odd cells hold
    uint64_t n = static_cast<uint64_t>(v.columnarStorageBytes());
    const size_t ncols = v.isArray ? 1 : v.cols();
    for (size_t c = 0; c < ncols; c++) {
      const Value::Column &col = v.column(c);
      for (const Value &x : col.cells)
        n += valueBytes(x, depth + 1);
      for (const Value &x : col.excVals)
        n += valueBytes(x, depth + 1);
    }
    return n;
  }
  if (v.isDict || v.isObject) {
    uint64_t n = 0;
    for (const auto &kv : v.dict())
      n += kv.first.size() + kCell + valueBytes(kv.second, depth + 1);
    return n;
  }
  if (v.isND()) {
    uint64_t n = 0, count = 1;
    for (size_t s : v.ndShape())
      count *= s;
    for (uint64_t k = 0; k < count; k++)
      n += kCell + valueBytes(v.ndAt(static_cast<size_t>(k)), depth + 1);
    return n;
  }
  if (v.isMatrix) {
    uint64_t n = 0;
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        n += kCell + valueBytes(v.at(r, c), depth + 1);
    return n;
  }
  if (v.isArray) {
    uint64_t n = 0;
    for (size_t i = 0; i < v.length(); i++)
      n += kCell + valueBytes(v.at(i), depth + 1);
    return n;
  }
  return v.isComplex ? 16 : 8; // one number
}

/* ---- std::cerr copied while still printed ---- */

class TeeBuf : public std::streambuf {
public:
  explicit TeeBuf(std::streambuf *target) : target_(target) {}
  std::string copy;

protected:
  int overflow(int c) override {
    if (c == traits_type::eof())
      return traits_type::not_eof(c);
    copy += static_cast<char>(c);
    return target_->sputc(static_cast<char>(c));
  }
  std::streamsize xsputn(const char *s, std::streamsize n) override {
    copy.append(s, static_cast<size_t>(n));
    return target_->sputn(s, n);
  }
  int sync() override { return target_->pubsync(); }

private:
  std::streambuf *target_;
};

} // namespace

void handleCommand(const std::string &json, const Workspace &globals, RunRequest &run) {
  run = RunRequest();
  TreeNode req;
  std::string err;
  if (!parseJson(json, false, req, err) || req.type != TreeNode::Object)
    return sendError("", "", "the request is not a JSON object: " + (err.empty() ? json : err));
  const std::string id = textField(req, "id");
  const std::string op = lower(textField(req, "op"));
  if (op == "formats")
    return opFormats(id);
  if (op == "detect")
    return opDetect(id, req);
  if (op == "options")
    return opOptions(id, req);
  if (op == "preview")
    return lower(textField(req, "action")) == "save" ? opPreviewSave(id, req, globals) : opPreview(id, req);
  if (op == "target")
    return opTarget(id, req);
  if (op == "accepts")
    return opAccepts(id, req, globals);
  if (op == "estimate")
    return opEstimate(id, req, globals);
  if (op == "peek")
    return opPeek(id, req, globals);
  if (op == "code")
    return opCode(id, req, globals);
  if (op == "run")
    return opRun(id, req, globals, run);
  if (op == "probe")
    return opProbe(id, req);
  if (op == "thumbnail")
    return opThumbnail(id, req);
  if (op == "functions")
    return opFunctions(id);
  if (op == "process" || op == "check") {
    // Parser work: done by the REPL (main.cpp -> process_runner.h).
    run.id = id;
    run.kind = op;
    run.json = json;
    return;
  }
  sendError(id, op,
            "unknown op \"" + op +
                "\" - formats, detect, options, preview, probe, thumbnail, code, run, target, accepts, estimate, "
                "peek, functions, process or check");
}

void sendProtocolLine(const char *kind, const std::string &json) { sendLine(kind, json); }

// A multicore kernel inside a run (2026-11-20): its progress as an @IOEV
// "compute" event, at most ten a second (nc::par's progress sink):
//   {"kind":"compute","function":"float16","file":"","fraction":0.41,
//    "message":"412/1000"}
// Kept apart from "progress", which stays the reader's / writer's own
// monotonic fraction of the file.
static void sendComputeProgress(void *ctx, const char *label, std::size_t done, std::size_t total) {
  const std::string &id = *static_cast<const std::string *>(ctx);
  ncdata::JsonWriter j;
  j.beginObject();
  j.key("v").integer(kVersion);
  j.key("type").string("ioev");
  j.key("id").string(id);
  j.key("kind").string("compute");
  j.key("function").string(label ? label : "");
  j.key("file").string("");
  j.key("fraction").number(total ? static_cast<double>(done) / static_cast<double>(total) : 1.0);
  j.key("message").string(std::to_string(done) + "/" + std::to_string(total));
  j.endObject();
  sendLine("@IOEV", j.str());
}

struct RunScope::Impl {
  RunRequest run;
  TeeBuf tee;
  std::streambuf *oldCerr = nullptr;
  bool finished = false;
  std::unique_ptr<nc::par::ProgressScope> compute; // sendComputeProgress, ctx = run.id
  explicit Impl(const RunRequest &r) : run(r), tee(std::cerr.rdbuf()) {}
  void restore() {
    if (oldCerr) {
      std::cerr.flush();
      std::cerr.rdbuf(oldCerr);
      oldCerr = nullptr;
    }
    setIoListener({});
    compute.reset();
  }
};

RunScope::RunScope(const RunRequest &run) : impl_(new Impl(run)) {
  impl_->compute = std::make_unique<nc::par::ProgressScope>(&sendComputeProgress, &impl_->run.id);
  nc::par::loopResetForCommand(); // the run's for loops report from here
  clearCancel();
  clearLastSaveReport(); // E2: finish() reports the save this run makes
  impl_->oldCerr = std::cerr.rdbuf(&impl_->tee);
  const std::string id = run.id;
  const std::thread::id owner = std::this_thread::get_id();
  auto lastSent = std::make_shared<double>(-1.0);
  auto lastCheck = std::make_shared<std::chrono::steady_clock::time_point>();
  setIoListener([id, owner, lastSent, lastCheck](const IoEvent &e) {
    // The IDE's Stop button (interrupt.flag) cancels the reader too. Only
    // the interpreter thread may look at the flag (Interrupt.h). Readers
    // send events seldom (one per MB, per batch of rows), so the flag file
    // is looked at on every event - at most once per 30 ms - rather than
    // through poll(), which counts calls for the interpreter's tight loops.
    if (std::this_thread::get_id() == owner) {
      const auto now = std::chrono::steady_clock::now();
      if (now - *lastCheck >= std::chrono::milliseconds(30)) {
        *lastCheck = now;
        if (nc::Interrupt::pollNow())
          requestCancel();
      } else if (nc::Interrupt::requested()) {
        requestCancel();
      }
    }
    // At most one progress line per 1 %.
    if (e.kind == "progress") {
      if (e.fraction - *lastSent < 0.01 && e.fraction < 1.0)
        return;
      *lastSent = e.fraction;
    }
    ncdata::JsonWriter j;
    j.beginObject();
    j.key("v").integer(kVersion);
    j.key("type").string("ioev");
    j.key("id").string(id);
    j.key("kind").string(e.kind);
    j.key("function").string(e.function);
    j.key("file").string(e.file);
    j.key("fraction").number(e.fraction);
    j.key("message").string(e.message);
    j.endObject();
    sendLine("@IOEV", j.str());
  });
}

RunScope::~RunScope() {
  if (impl_)
    impl_->restore();
}

void RunScope::finish(const Workspace &globals) {
  Impl &m = *impl_;
  m.restore();
  if (m.finished)
    return;
  m.finished = true;

  std::vector<std::string> errors, warnings;
  {
    std::string line;
    auto take = [&](const std::string &l) {
      const std::string t = trim(l);
      if (t.rfind("Error: ", 0) == 0)
        errors.push_back(t.substr(7));
      else if (t.rfind("Warning: ", 0) == 0)
        warnings.push_back(t.substr(9));
      else if (t.find("Error") != std::string::npos)
        errors.push_back(t);
    };
    for (char ch : m.tee.copy) {
      if (ch == '\n') {
        take(line);
        line.clear();
      } else {
        line += ch;
      }
    }
    if (!line.empty())
      take(line);
  }
  const bool cancelled = cancelRequested() || nc::Interrupt::requested();
  clearCancel();

  ncdata::JsonWriter j;
  const Value *v = nullptr;
  if (!m.run.var.empty()) {
    auto it = globals.find(m.run.var);
    if (it != globals.end())
      v = &it->second;
  }
  const bool ok = errors.empty() && !cancelled && (m.run.var.empty() || v);
  head(j, m.run.id, "run", ok);
  j.key("action").string(m.run.action);
  j.key("function").string(m.run.function);
  j.key("code").string(m.run.code);
  j.key("var").string(m.run.var);
  const bool isSave = m.run.action == "save" || (m.run.action == "code" && m.run.var.empty());
  const SaveReport sr = isSave ? lastSaveReport() : SaveReport();
  const bool saved = isSave && !sr.function.empty();
  j.key("exists").boolean(v != nullptr || (saved && sr.ok));
  if (saved) {
    // E2 (2026-11-17): what the save wrote. file = the absolute path (the
    // .zip with zip=true), bytes = its size, files = every file written
    // (split parts, part_by folders, shapefile bundles) with its size.
    j.key("file").string(sr.ok ? sr.file : std::string());
    j.key("bytes").unsignedInteger(sr.ok ? sr.bytes : 0);
    j.key("files").beginArray();
    for (const auto &f : sr.files) {
      j.beginObject();
      j.key("file").string(f.first);
      j.key("bytes").unsignedInteger(f.second);
      j.endObject();
    }
    j.endArray();
    j.key("rows").integer(sr.rows);
    j.key("cols").integer(sr.cols);
    j.key("seconds").number(sr.seconds);
    j.key("zipped").boolean(sr.zipped);
  }
  if (v) {
    const ncdata::VariableSummary s = ncdata::summarizeVariable(m.run.var, *v, 0);
    j.key("class").string(s.cls);
    j.key("size").string(s.size);
    // the memory the variable holds (numbers are float64: 8 bytes each)
    j.key("bytes").unsignedInteger(valueBytes(*v));
  }
  j.key("cancelled").boolean(cancelled);
  j.key("error").string(cancelled ? std::string("cancelled") : errors.empty() ? std::string() : errors.front());
  j.key("errors");
  stringList(j, errors);
  j.key("warnings");
  stringList(j, warnings);
  j.endObject();
  sendLine("@IO", j.str());
}

} // namespace ide
} // namespace io
} // namespace nc
