// What the Export window asks before it saves (2026-11-17, docs/Export_Window.md):
// the kind of a value, a sample of it, a trial save of that sample into a
// private scratch folder, size estimates, what a format changes (losses),
// the facts of a target file, and a bounded look at a variable (peek).
//
// Everything here runs the real save_<fmt> writers - on the value, or on its
// first rows when it is big - so an answer can never disagree with what the
// writer does (E4: accepts ok <=> run ok).
#ifndef NC_IO_EXPORT_H
#define NC_IO_EXPORT_H

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

#include "../../../data/DataSupport/JsonWriter.h"
#include "io_common.h"

namespace nc {
namespace io {
namespace exportx {

using Options = std::vector<std::pair<std::string, std::string>>; // name -> NC literal

// "table" "image" "audio" "video" "tree" "tensor" "text" "number" "object"
std::string valueKind(const Value &v);
// The data a loaded object stands for (NcImage.pixels, NcAudio.wave,
// NcVideo.frames, an NcTable's data); the value itself otherwise.
const Value &mainData(const Value &v);
// Element type name ("uint8", "float64", "mixed" for cells / tables, "text").
std::string dtypeOf(const Value &v);
// The shape of the main data (rows, cols / H, W, C / T, H, W, C ...).
std::vector<size_t> shapeOf(const Value &v);
// Count along axis 0 (table rows, image rows, audio samples, video frames).
size_t axisLength(const Value &v);
// All elements (cells, pixels x channels, samples x channels).
size_t elementCount(const Value &v);
// The first `n` entries along axis 0, in the same storage kind (a typed
// uint8 image stays uint8, an NcTable stays a table) - `v` when n covers it.
Value sampleRows(const Value &v, size_t n);

// One trial save into a scratch folder of its own.
struct Trial {
  bool ok = false;
  std::string error;                 // the writer's message, without "Error: save_x: "
  std::vector<std::string> warnings; // "Warning: " lines
  uint64_t bytes = 0;                // every file written, together
  std::string folder, file;          // kept only when asked (keep = true)
};
// save_<format> (save() for "ndat") of `data` with `opts`; `keep`: the files
// stay until dropTrial() (the caller reads them).
bool trialSave(const std::string &format, const Value &data, const Options &opts, Trial &t, bool keep = false);
void dropTrial(Trial &t);

// The bytes save_<format> writes for the whole value: exact when the value is
// small enough to encode whole, else from encoding two samples of its first
// rows and scaling (bytes = fixed + per_row x rows).
struct Estimate {
  bool ok = false, exact = false;
  uint64_t bytes = 0;
  std::string error;
};
Estimate estimateBytes(const std::string &format, const Value &data, const Options &opts);

// What a save in `format` changes in the value (E4 losses), by the writers'
// rules: lossy codecs, narrowed element types, cut texts.
std::vector<std::string> lossesOf(const std::string &format, const Value &v, const Options &opts);
// Formats that keep the value whole, best first (each checked by a trial save).
std::vector<std::string> suggestFormats(const Value &v);
// Limits a writer has that a sample cannot show (sheet sizes): "" = none.
std::string sizeLimitError(const std::string &format, const Value &v);

// op "target" (E3): the facts of a file about to be written.
void writeTarget(ncdata::JsonWriter &j, const std::string &file, const std::string &format);
// op "peek" (E11): a bounded look at a value.
struct PeekLimits {
  size_t rows = 50, cols = 50, maxSide = 256, buckets = 1000, nodes = 3000;
};
void writePeek(ncdata::JsonWriter &j, const Value &v, const PeekLimits &lim);

} // namespace exportx
} // namespace io
} // namespace nc

#endif // NC_IO_EXPORT_H
