// DEFLATE (RFC 1951), zlib (RFC 1950) and gzip (RFC 1952), hand-written.
//
// Used by the I/O functions for compress="gz" on text formats (phase 1), and
// by the zip/PNG based formats (xlsx, png - phase 2). No third-party code.
#ifndef NC_IO_DEFLATE_H
#define NC_IO_DEFLATE_H

#include <cstdint>
#include <string>
#include <string_view>

namespace nc {
namespace io {

uint32_t crc32(const void *data, size_t n, uint32_t crc = 0);
uint32_t adler32(const void *data, size_t n, uint32_t adler = 1);

// Raw DEFLATE stream. `level` 0 = stored, 1..9 = how hard the matcher looks.
std::string deflateRaw(const std::string &in, int level = 6);
// One piece of a raw DEFLATE stream written piece by piece (2026-11-17, for
// writers that stream to the file): every piece but the `last` ends with an
// empty stored block (a sync flush), so pieces can be appended one after
// another and inflate as one stream. Each piece starts a fresh dictionary.
std::string deflateRawPiece(const std::string &in, int level, bool last);
// Raw DEFLATE stream -> bytes. False with `err` on a corrupt stream.
// `consumed` (optional) receives the number of input bytes used.
// `maxOut`: stop after the block that brings the output to at least this
// many bytes (a reader that only needs the start, e.g. a header).
bool inflateRaw(std::string_view in, size_t start, std::string &out, std::string &err,
                size_t *consumed = nullptr, size_t maxOut = static_cast<size_t>(-1));

std::string gzipCompress(const std::string &in, int level = 6);
bool gzipDecompress(const std::string &in, std::string &out, std::string &err);
bool isGzip(const std::string &bytes);

std::string zlibCompress(const std::string &in, int level = 6);
bool zlibDecompress(const std::string &in, std::string &out, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_DEFLATE_H
