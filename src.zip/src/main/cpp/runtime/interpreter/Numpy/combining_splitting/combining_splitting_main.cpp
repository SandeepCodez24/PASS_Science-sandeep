// Section 6 of 11 - Combining & Splitting
// Planned entries: 17
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   cs_join_split.cpp   concat stack row_stack vstack column_stack hstack
//                       matrix_split vsplit hsplit
//
// Names from the team's list that are not here: append (replaced by the
// extend operators M ,= X and M ;= X), block (the matrix literal
// [A, B; C, D] already does it), split (the existing text builtin keeps the
// name - the matrix one is matrix_split).
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        combining_splitting/cs_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerCombiningSplitting() below.
//   2. Register it with reg.add({...}) and give it a parameter line
//      (reg.setParams(name, "A, axis=0") - core/param_list.h).
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup.
#include "combining_splitting_main.h"

#include "cs_join_split.h"

namespace nc {
namespace numpy {

void registerCombiningSplitting(Registry &reg) { registerJoinSplit(reg); }

} // namespace numpy
} // namespace nc
