// Section 9 of 11 - Vector Math (136 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_VECTOR_MATH_MAIN_H
#define NC_NUMPY_VECTOR_MATH_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Vector Math function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerVectorMath(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_VECTOR_MATH_MAIN_H
