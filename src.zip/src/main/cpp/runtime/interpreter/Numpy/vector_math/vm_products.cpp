// Vector Math - products: dot, cross, inner, outer, tensordot, einsum, kron.
#include "vm_common.h"

#include <cctype>
#include <map>

namespace nc {
namespace numpy {
namespace vm {

namespace {

using Cplx = std::complex<double>;

// Elements of a matrix in row-by-row order (NumPy's flattening order).
std::vector<Cplx> flattenRowMajor(const MatrixXcd &m) {
  std::vector<Cplx> out;
  out.reserve(static_cast<size_t>(m.size()));
  for (Eigen::Index r = 0; r < m.rows(); r++)
    for (Eigen::Index c = 0; c < m.cols(); c++)
      out.push_back(m(r, c));
  return out;
}

bool isVectorShape(const MatrixXcd &m) { return m.rows() == 1 || m.cols() == 1; }

// The "dim" argument: 0 = down each column, 1 = along each row.
bool argDim(const std::vector<Value> &args, size_t i, CallContext &ctx, int &dim) {
  long long d = 0;
  if (!argInt(args, i, ctx, d))
    return false;
  if (d != 0 && d != 1) {
    ctx.fail("dim must be 0 (down each column) or 1 (along each row), got " + std::to_string(d));
    return false;
  }
  dim = static_cast<int>(d);
  return true;
}

/* ---- dot ------------------------------------------------------------------ */

Value dotImpl(const std::vector<Value> &args, CallContext &ctx) {
  MatrixXcd a, b;
  if (!argMatrixC(args, 0, ctx, a) || !argMatrixC(args, 1, ctx, b))
    return Value(0.0);

  if (args.size() == 2) {
    // np.vdot: every element of A (conjugated) times the matching element of
    // B, summed - A and B need the same number of elements.
    if (a.size() != b.size()) {
      ctx.fail("needs two values with the same number of elements, got " +
               std::to_string(a.size()) + " and " + std::to_string(b.size()));
      return Value(0.0);
    }
    if (!(isVectorShape(a) && isVectorShape(b)) && (a.rows() != b.rows() || a.cols() != b.cols())) {
      ctx.fail("needs two vectors, or two matrices of the same size - got " +
               std::to_string(a.rows()) + "x" + std::to_string(a.cols()) + " and " +
               std::to_string(b.rows()) + "x" + std::to_string(b.cols()));
      return Value(0.0);
    }
    std::vector<Cplx> x = flattenRowMajor(a), y = flattenRowMajor(b);
    Cplx sum(0.0, 0.0);
    for (size_t k = 0; k < x.size(); k++)
      sum += std::conj(x[k]) * y[k];
    return complexScalar(sum);
  }

  // dot(A, B, dim) - np.vecdot along one dimension.
  int dim = 0;
  if (!argDim(args, 2, ctx, dim))
    return Value(0.0);
  if (a.rows() != b.rows() || a.cols() != b.cols()) {
    ctx.fail("dot(A, B, dim) needs A and B of the same size");
    return Value(0.0);
  }
  MatrixXcd prod = (a.conjugate().array() * b.array()).matrix();
  MatrixXcd r = (dim == 0) ? MatrixXcd(prod.colwise().sum()) : MatrixXcd(prod.rowwise().sum());
  return fromEigenC(r);
}

/* ---- cross ---------------------------------------------------------------- */

Eigen::Vector3d cross3(const Eigen::Vector3d &x, const Eigen::Vector3d &y) { return x.cross(y); }

Value crossImpl(const std::vector<Value> &args, CallContext &ctx) {
  MatrixXd a, b;
  if (!argMatrix(args, 0, ctx, a) || !argMatrix(args, 1, ctx, b))
    return Value(0.0);

  // Two vectors (any orientation): 3-vectors give a vector, 2-vectors the
  // scalar z-component (NumPy).
  const bool aVec = a.rows() == 1 || a.cols() == 1;
  const bool bVec = b.rows() == 1 || b.cols() == 1;
  if (args.size() == 2 && aVec && bVec) {
    if (a.size() == 2 && b.size() == 2)
      return Value(a(0) * b(1) - a(1) * b(0));
    if (a.size() != 3 || b.size() != 3) {
      ctx.fail("needs two 3-element vectors (or two 2-element ones), got " +
               std::to_string(a.size()) + " and " + std::to_string(b.size()) + " elements");
      return Value(0.0);
    }
    Eigen::Vector3d r = cross3(Eigen::Vector3d(a(0), a(1), a(2)), Eigen::Vector3d(b(0), b(1), b(2)));
    std::vector<double> v = {r(0), r(1), r(2)};
    // Same orientation as the first vector (a 1-D array counts as a row).
    return (a.cols() == 1 && a.rows() == 3) ? columnVector(v) : rowVector(v);
  }

  if (a.rows() != b.rows() || a.cols() != b.cols()) {
    ctx.fail("needs two matrices of the same size, got " + shapeText(a) + " and " + shapeText(b));
    return Value(0.0);
  }
  int dim = -1;
  if (args.size() == 3 && !argDim(args, 2, ctx, dim))
    return Value(0.0);
  if (dim == -1) // no dim given: the rows if they hold 3 values, else the columns
    dim = (a.cols() == 3) ? 1 : 0;
  if ((dim == 1 && a.cols() != 3) || (dim == 0 && a.rows() != 3)) {
    ctx.fail(std::string("along dim ") + std::to_string(dim) + " each " +
             (dim == 1 ? "row" : "column") + " must have 3 values, but A is " + shapeText(a));
    return Value(0.0);
  }
  MatrixXd r(a.rows(), a.cols());
  if (dim == 1) {
    for (Eigen::Index i = 0; i < a.rows(); i++)
      r.row(i) = cross3(a.row(i).transpose(), b.row(i).transpose()).transpose();
  } else {
    for (Eigen::Index j = 0; j < a.cols(); j++)
      r.col(j) = cross3(a.col(j), b.col(j));
  }
  return fromEigen(r);
}

/* ---- einsum --------------------------------------------------------------- */

struct EinsumOperand {
  std::string letters;
  MatrixXd data; // a vector is stored 1 x N
};

double einsumElem(const EinsumOperand &op, const std::map<char, Eigen::Index> &at) {
  if (op.letters.empty())
    return op.data(0, 0);
  if (op.letters.size() == 1)
    return op.data(at.at(op.letters[0]));
  return op.data(at.at(op.letters[0]), at.at(op.letters[1]));
}

Value einsumImpl(const std::vector<Value> &args, CallContext &ctx) {
  std::string spec;
  if (!argText(args, 0, ctx, spec))
    return Value(0.0);
  std::string clean;
  for (char ch : spec)
    if (!std::isspace(static_cast<unsigned char>(ch)))
      clean += ch;

  std::string inputs = clean, output;
  bool explicitOut = false;
  const size_t arrow = clean.find("->");
  if (arrow != std::string::npos) {
    inputs = clean.substr(0, arrow);
    output = clean.substr(arrow + 2);
    explicitOut = true;
  }

  std::vector<std::string> terms;
  {
    std::string cur;
    for (char ch : inputs) {
      if (ch == ',') {
        terms.push_back(cur);
        cur.clear();
      } else {
        cur += ch;
      }
    }
    terms.push_back(cur);
  }
  if (terms.size() != args.size() - 1) {
    ctx.fail("'" + spec + "' names " + std::to_string(terms.size()) + " operand(s) but " +
             std::to_string(args.size() - 1) + " were given");
    return Value(0.0);
  }

  std::vector<EinsumOperand> ops;
  std::map<char, Eigen::Index> sizeOf;
  std::map<char, int> count;
  for (size_t k = 0; k < terms.size(); k++) {
    EinsumOperand op;
    op.letters = terms[k];
    for (char ch : op.letters)
      if (!std::isalpha(static_cast<unsigned char>(ch))) {
        ctx.fail("subscripts may only use letters, got '" + std::string(1, ch) + "'");
        return Value(0.0);
      }
    if (op.letters.size() > 2) {
      ctx.fail("only scalars, vectors and matrices are supported - '" + op.letters +
               "' has more than 2 indices");
      return Value(0.0);
    }
    if (!argMatrix(args, k + 1, ctx, op.data))
      return Value(0.0);
    std::vector<Eigen::Index> dims;
    if (op.letters.size() == 1) {
      if (op.data.rows() != 1 && op.data.cols() != 1) {
        ctx.fail("operand " + std::to_string(k + 1) + " ('" + op.letters +
                 "') must be a vector, got a " + shapeText(op.data) + " matrix");
        return Value(0.0);
      }
      op.data = Eigen::Map<MatrixXd>(op.data.data(), 1, op.data.size()).eval();
      dims = {op.data.cols()};
    } else if (op.letters.size() == 2) {
      dims = {op.data.rows(), op.data.cols()};
    } else if (op.data.size() != 1) {
      ctx.fail("operand " + std::to_string(k + 1) + " has no subscripts, so it must be a single value");
      return Value(0.0);
    }
    for (size_t d = 0; d < op.letters.size(); d++) {
      const char ch = op.letters[d];
      count[ch]++;
      auto it = sizeOf.find(ch);
      if (it == sizeOf.end())
        sizeOf[ch] = dims[d];
      else if (it->second != dims[d]) {
        ctx.fail(std::string("index '") + ch + "' has size " + std::to_string(it->second) +
                 " in one place and " + std::to_string(dims[d]) + " in another");
        return Value(0.0);
      }
    }
    ops.push_back(std::move(op));
  }

  if (!explicitOut) // implicit mode: letters used once, alphabetical
    for (const auto &kv : count)
      if (kv.second == 1)
        output += kv.first;
  if (output.size() > 2) {
    ctx.fail("the result may have at most 2 indices, got '" + output + "'");
    return Value(0.0);
  }
  for (char ch : output)
    if (!sizeOf.count(ch)) {
      ctx.fail(std::string("output index '") + ch + "' does not appear in the inputs");
      return Value(0.0);
    }

  std::vector<char> letters;
  for (const auto &kv : sizeOf)
    letters.push_back(kv.first);
  const Eigen::Index outR = output.size() == 2 ? sizeOf[output[0]] : 1;
  const Eigen::Index outC = output.empty() ? 1 : sizeOf[output.back()];
  MatrixXd result = MatrixXd::Zero(outR, outC);

  // Walk every combination of index values (odometer style).
  std::map<char, Eigen::Index> at;
  for (char ch : letters)
    at[ch] = 0;
  bool anyEmpty = false;
  for (char ch : letters)
    anyEmpty = anyEmpty || sizeOf[ch] == 0;
  while (!anyEmpty) {
    double prod = 1.0;
    for (const auto &op : ops)
      prod *= einsumElem(op, at);
    const Eigen::Index r = output.size() == 2 ? at[output[0]] : 0;
    const Eigen::Index c = output.empty() ? 0 : at[output.back()];
    result(r, c) += prod;
    size_t k = 0;
    for (; k < letters.size(); k++) {
      if (++at[letters[k]] < sizeOf[letters[k]])
        break;
      at[letters[k]] = 0;
    }
    if (k == letters.size())
      break;
  }

  if (output.empty())
    return Value(result(0, 0));
  return fromEigen(result);
}

} // namespace

void registerProducts(Registry &reg) {
  addFn(reg, "dot", 2, 3, "dot(A, B[, dim])",
        "dot product: sum of conj(A).*B as one number, or along dim (0 columns, 1 rows)",
        "np.vdot / np.vecdot", dotImpl, true);

  addFn(reg, "inner", 2, 2, "inner(A, B)",
        "inner product: a number for two vectors, A*B' for matrices", "np.inner",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXd a, b;
          if (!argMatrix(args, 0, ctx, a) || !argMatrix(args, 1, ctx, b))
            return Value(0.0);
          if (a.size() == 1 || b.size() == 1) // a single value scales the other
            return fromEigen(a.size() == 1 ? MatrixXd(a(0, 0) * b) : MatrixXd(b(0, 0) * a));
          const bool aVec = a.rows() == 1 || a.cols() == 1;
          const bool bVec = b.rows() == 1 || b.cols() == 1;
          if (aVec && bVec) {
            if (a.size() != b.size()) {
              ctx.fail("needs two vectors of the same length, got " + std::to_string(a.size()) +
                       " and " + std::to_string(b.size()));
              return Value(0.0);
            }
            double s = 0.0;
            for (Eigen::Index k = 0; k < a.size(); k++)
              s += a(k) * b(k);
            return Value(s);
          }
          if (aVec)
            a = Eigen::Map<MatrixXd>(a.data(), 1, a.size()).eval();
          if (bVec)
            b = Eigen::Map<MatrixXd>(b.data(), 1, b.size()).eval();
          if (a.cols() != b.cols()) {
            ctx.fail("the rows of A and B must have the same length, got " + shapeText(a) +
                     " and " + shapeText(b));
            return Value(0.0);
          }
          return scalarIfSingle(fromEigen(a * b.transpose()));
        });

  addFn(reg, "outer", 2, 2, "outer(a, b)", "outer product a(:) * b(:)' as a matrix", "np.outer",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a, b;
          if (!argMatrixC(args, 0, ctx, a) || !argMatrixC(args, 1, ctx, b))
            return Value(0.0);
          std::vector<Cplx> x = flattenRowMajor(a), y = flattenRowMajor(b);
          MatrixXcd r(static_cast<Eigen::Index>(x.size()), static_cast<Eigen::Index>(y.size()));
          for (size_t i = 0; i < x.size(); i++)
            for (size_t j = 0; j < y.size(); j++)
              r(static_cast<Eigen::Index>(i), static_cast<Eigen::Index>(j)) = x[i] * y[j];
          return fromEigenC(r);
        },
        true);

  addFn(reg, "cross", 2, 3, "cross(a, b[, dim])",
        "cross product of 3-element vectors; for matrices along each row (dim 1) or column (dim 0)",
        "np.cross", crossImpl);

  addFn(reg, "tensordot", 2, 3, "tensordot(A, B[, axes])",
        "axes 2 (default): sum(A.*B); axes 1: the matrix product A*B", "np.tensordot",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXd a, b;
          long long axes = 2;
          if (!argMatrix(args, 0, ctx, a) || !argMatrix(args, 1, ctx, b) ||
              (args.size() == 3 && !argInt(args, 2, ctx, axes)))
            return Value(0.0);
          if (axes == 2) {
            if (a.rows() != b.rows() || a.cols() != b.cols()) {
              ctx.fail("axes 2 needs A and B of the same size, got " + shapeText(a) + " and " +
                       shapeText(b));
              return Value(0.0);
            }
            return Value((a.array() * b.array()).sum());
          }
          if (axes == 1) {
            if (a.cols() != b.rows()) {
              ctx.fail("axes 1 needs the columns of A to equal the rows of B, got " +
                       shapeText(a) + " and " + shapeText(b));
              return Value(0.0);
            }
            return scalarIfSingle(fromEigen(a * b));
          }
          ctx.fail("axes must be 1 or 2 - NC matrices are 2-D (axes 0 would need 4-D; use "
                   "outer(A, B) or kron(A, B))");
          return Value(0.0);
        });

  addFn(reg, "einsum", 2, 4, "einsum(\"ij,jk->ik\", A, B)",
        "Einstein summation over 1-3 scalars/vectors/matrices, e.g. \"ii\" trace, \"ij->ji\" "
        "transpose",
        "np.einsum", einsumImpl);

  addFn(reg, "kron", 2, 2, "kron(A, B)", "Kronecker product: every element of A times all of B",
        "np.kron", [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a, b;
          if (!argMatrixC(args, 0, ctx, a) || !argMatrixC(args, 1, ctx, b))
            return Value(0.0);
          MatrixXcd r(a.rows() * b.rows(), a.cols() * b.cols());
          for (Eigen::Index i = 0; i < a.rows(); i++)
            for (Eigen::Index j = 0; j < a.cols(); j++)
              r.block(i * b.rows(), j * b.cols(), b.rows(), b.cols()) = a(i, j) * b;
          return scalarIfSingle(fromEigenC(r));
        },
        true);
}

} // namespace vm
} // namespace numpy
} // namespace nc
