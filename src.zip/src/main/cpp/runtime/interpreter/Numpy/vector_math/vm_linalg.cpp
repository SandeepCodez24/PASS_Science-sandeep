// Vector Math - linear algebra: norms, determinants, solving, eigenvalues,
// decompositions.
//
// Functions with several results are called as [Q, R] = qr(A) (or the older
// (Q, R) = qr(A)); a plain x = f(A) gets the result listed first in its
// signature unless the summary says otherwise.
#include "vm_common.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace nc {
namespace numpy {
namespace vm {

namespace {

using Cplx = std::complex<double>;

bool isSymmetric(const MatrixXd &m) {
  const double scale = std::max(1.0, m.cwiseAbs().maxCoeff());
  return (m - m.transpose()).cwiseAbs().maxCoeff() <= 1e-12 * scale;
}

bool isHermitian(const MatrixXcd &m) {
  const double scale = std::max(1.0, m.cwiseAbs().maxCoeff());
  return (m - m.adjoint()).cwiseAbs().maxCoeff() <= 1e-12 * scale;
}

bool argSquareC(const std::vector<Value> &args, size_t i, CallContext &ctx, MatrixXcd &out) {
  if (!argMatrixC(args, i, ctx, out))
    return false;
  if (out.rows() == 0 || out.rows() != out.cols()) {
    ctx.fail("needs a square matrix, got " + std::to_string(out.rows()) + "x" +
             std::to_string(out.cols()));
    return false;
  }
  return true;
}

double infinity() { return std::numeric_limits<double>::infinity(); }

/* ---- norms ---------------------------------------------------------------- */

// The `ord` argument: a number (inf/-inf allowed) or text ("fro", "nuc").
struct NormOrder {
  bool isText = false;
  std::string text;
  double p = 2.0;
};

bool argOrder(const std::vector<Value> &args, size_t i, CallContext &ctx, NormOrder &ord) {
  if (args[i].isText) {
    ord.isText = true;
    ord.text = args[i].text();
    return true;
  }
  return argNumber(args, i, ctx, ord.p);
}

Value vectorNorm(const std::vector<Value> &args, CallContext &ctx) {
  MatrixXcd m;
  NormOrder ord;
  if (!argMatrixC(args, 0, ctx, m) || (args.size() > 1 && !argOrder(args, 1, ctx, ord)))
    return Value(0.0);
  if (ord.isText) {
    ctx.fail("ord must be a number (1, 2, inf, ...) for vector_norm, got \"" + ord.text + "\"");
    return Value(0.0);
  }
  Eigen::ArrayXd mag = m.cwiseAbs().reshaped().array();
  const double p = ord.p;
  if (mag.size() == 0)
    return Value(0.0);
  if (std::isinf(p))
    return Value(p > 0 ? mag.maxCoeff() : mag.minCoeff());
  if (p == 0)
    return Value(static_cast<double>((mag != 0.0).count()));
  if (p == 1)
    return Value(mag.sum());
  if (p == 2)
    return Value(std::sqrt((mag * mag).sum()));
  return Value(std::pow(mag.pow(p).sum(), 1.0 / p));
}

/* ---- solving ---------------------------------------------------------------- */

// b as a matrix of right-hand-side columns; a 1xN row with N == n is turned
// into a column (and the answer turned back into a row).
bool argRhs(const std::vector<Value> &args, size_t i, CallContext &ctx, Eigen::Index n,
            MatrixXcd &b, bool &wasRow) {
  if (!argMatrixC(args, i, ctx, b))
    return false;
  wasRow = false;
  if (b.rows() == 1 && b.cols() == n && n > 1) {
    b.transposeInPlace();
    wasRow = true;
  }
  if (b.rows() != n) {
    ctx.fail("b must have " + std::to_string(n) + " rows to match A, got " +
             std::to_string(b.rows()) + "x" + std::to_string(b.cols()));
    return false;
  }
  return true;
}

Value solveImpl(const std::vector<Value> &args, CallContext &ctx) {
  MatrixXcd a, b;
  bool wasRow = false;
  if (!argSquareC(args, 0, ctx, a) || !argRhs(args, 1, ctx, a.rows(), b, wasRow))
    return Value(0.0);
  // Same "can this be inverted" rule as inv() for a real matrix.
  Eigen::FullPivLU<MatrixXcd> lu(a);
  const bool singular = args[0].hasComplex() ? !lu.isInvertible()
                                             : isEffectivelySingular(MatrixXd(a.real()));
  if (singular) {
    ctx.fail("A is singular (not invertible), so A x = b has no unique solution - try lstsq(A, b)");
    return Value(0.0);
  }
  MatrixXcd x = lu.solve(b);
  if (wasRow)
    x.transposeInPlace();
  return scalarIfSingle(fromEigenC(x));
}

/* ---- eigenvalues -------------------------------------------------------------- */

// Eigenvalues (as a column) and right eigenvectors (columns) of a square
// matrix. A real symmetric / complex Hermitian matrix gets real eigenvalues
// in ascending order.
bool eigDecompose(const std::vector<Value> &args, CallContext &ctx, MatrixXcd &values,
                  MatrixXcd &vectors) {
  MatrixXcd a;
  if (!argSquareC(args, 0, ctx, a))
    return false;
  const bool real = !args[0].hasComplex();
  if (real) {
    MatrixXd ar = a.real();
    if (isSymmetric(ar)) {
      Eigen::SelfAdjointEigenSolver<MatrixXd> es(ar);
      values = es.eigenvalues().cast<Cplx>();
      vectors = es.eigenvectors().cast<Cplx>();
      return true;
    }
    Eigen::EigenSolver<MatrixXd> es(ar);
    if (es.info() != Eigen::Success) {
      ctx.fail("the eigenvalue computation did not converge");
      return false;
    }
    values = es.eigenvalues();
    vectors = es.eigenvectors();
    return true;
  }
  if (isHermitian(a)) {
    Eigen::SelfAdjointEigenSolver<MatrixXcd> es(a);
    values = es.eigenvalues().cast<Cplx>();
    vectors = es.eigenvectors();
    return true;
  }
  Eigen::ComplexEigenSolver<MatrixXcd> es(a);
  if (es.info() != Eigen::Success) {
    ctx.fail("the eigenvalue computation did not converge");
    return false;
  }
  values = es.eigenvalues();
  vectors = es.eigenvectors();
  return true;
}

/* ---- SVD ---------------------------------------------------------------------- */

void svdImpl(const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
             CallContext &ctx) {
  MatrixXcd a;
  if (!argMatrixC(args, 0, ctx, a))
    return;
  if (a.size() == 0) {
    ctx.fail("needs a non-empty matrix");
    return;
  }
  if (!args[0].hasComplex()) {
    MatrixXd ar = a.real();
    NC_FULL_SVD(MatrixXd, svd, ar);
    Eigen::VectorXd s = svd.singularValues();
    if (nout == 1) {
      out.push_back(fromEigen(s));
      return;
    }
    MatrixXd S = MatrixXd::Zero(ar.rows(), ar.cols());
    for (Eigen::Index k = 0; k < s.size(); k++)
      S(k, k) = s(k);
    out.push_back(fromEigen(svd.matrixU()));
    out.push_back(fromEigen(S));
    if (nout > 2)
      out.push_back(fromEigen(svd.matrixV()));
    return;
  }
  NC_FULL_SVD(MatrixXcd, svd, a);
  Eigen::VectorXd s = svd.singularValues();
  if (nout == 1) {
    out.push_back(fromEigen(s));
    return;
  }
  MatrixXd S = MatrixXd::Zero(a.rows(), a.cols());
  for (Eigen::Index k = 0; k < s.size(); k++)
    S(k, k) = s(k);
  out.push_back(fromEigenC(svd.matrixU()));
  out.push_back(fromEigen(S));
  if (nout > 2)
    out.push_back(fromEigenC(svd.matrixV()));
}

double conditionNumber2(const MatrixXd &a) {
  Eigen::JacobiSVD<MatrixXd> svd(a);
  const Eigen::VectorXd s = svd.singularValues();
  if (s.size() == 0)
    return 0.0;
  const double smin = s(s.size() - 1);
  return smin == 0.0 ? infinity() : s(0) / smin;
}

} // namespace

void registerLinalg(Registry &reg) {
  // ---- norms and determinants --------------------------------------------
  // matrix_norm(A[, ord]) and trace(A) are existing builtins (ops/matrix).
  addFn(reg, "vector_norm", 1, 2, "vector_norm(x[, ord])",
        "p-norm of all elements (ord 2 default; 1, inf, -inf, 0 or any p)", "np.linalg.vector_norm",
        vectorNorm, true);

  addMulti(reg, "slogdet", 1, 1, 2, "[sign, logdet] = slogdet(A)",
           "sign and log|det(A)|, safe from overflow; x = slogdet(A) gives [sign, logdet]",
           "np.linalg.slogdet",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXcd a;
             if (!argSquareC(args, 0, ctx, a))
               return;
             Eigen::PartialPivLU<MatrixXcd> lu(a);
             const MatrixXcd &lum = lu.matrixLU();
             Cplx sign = lu.permutationP().determinant() < 0 ? Cplx(-1, 0) : Cplx(1, 0);
             double logdet = 0.0;
             for (Eigen::Index k = 0; k < lum.rows(); k++) {
               const Cplx d = lum(k, k);
               const double mag = std::abs(d);
               if (mag == 0.0) {
                 sign = Cplx(0, 0);
                 logdet = -infinity();
                 break;
               }
               sign *= d / mag;
               logdet += std::log(mag);
             }
             if (!args[0].hasComplex())
               sign = Cplx(std::round(sign.real()), 0.0);
             if (nout == 1) {
               if (sign.imag() == 0.0)
                 out.push_back(rowVector({sign.real(), logdet}));
               else
                 out.push_back(Value(std::vector<std::vector<Value>>{
                     {complexScalar(sign), Value(logdet)}}));
               return;
             }
             out.push_back(complexScalar(sign));
             out.push_back(Value(logdet));
           },
           true);

  // ---- solving -------------------------------------------------------------
  // pinv(A) is an existing builtin (ops/matrix).
  addFn(reg, "solve", 2, 2, "solve(A, b)", "x with A*x = b (A square and invertible)",
        "np.linalg.solve", solveImpl, true);

  addMulti(reg, "lstsq", 2, 2, 4, "[x, residuals, rank, s] = lstsq(A, b)",
           "least-squares (minimum-norm) x minimising |A*x - b|, plus residual sums, rank and "
           "singular values",
           "np.linalg.lstsq",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXd a, b;
             if (!argMatrix(args, 0, ctx, a) || !argMatrix(args, 1, ctx, b))
               return;
             bool wasRow = false;
             if (b.rows() == 1 && b.cols() == a.rows() && a.rows() > 1) {
               b.transposeInPlace();
               wasRow = true;
             }
             if (a.size() == 0 || b.rows() != a.rows()) {
               ctx.fail("b must have as many rows as A (" + std::to_string(a.rows()) + "), got " +
                        shapeText(b));
               return;
             }
             Eigen::CompleteOrthogonalDecomposition<MatrixXd> cod(a);
             MatrixXd x = cod.solve(b);
             const Eigen::Index rank = cod.rank();
             MatrixXd xOut = wasRow ? MatrixXd(x.transpose()) : x;
             out.push_back(scalarIfSingle(fromEigen(xOut)));
             if (nout > 1) {
               // Sum of squared residuals per column - only when the system
               // is overdetermined and of full rank (NumPy's rule).
               if (rank == a.cols() && a.rows() > a.cols()) {
                 MatrixXd res = (a * x - b).colwise().squaredNorm();
                 out.push_back(scalarIfSingle(fromEigen(res)));
               } else {
                 out.push_back(Value(std::vector<std::vector<Value>>{}));
               }
             }
             if (nout > 2)
               out.push_back(Value(static_cast<double>(rank)));
             if (nout > 3) {
               Eigen::JacobiSVD<MatrixXd> svd(a);
               out.push_back(fromEigen(svd.singularValues()));
             }
           });

  // ---- eigenvalues -----------------------------------------------------------
  addMulti(reg, "eig", 1, 1, 2, "[V, D] = eig(A)",
           "eigenvalues of A as a column; [V, D] = eig(A) gives eigenvectors V and diagonal D "
           "with A*V = V*D",
           "np.linalg.eig",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXcd values, vectors;
             if (!eigDecompose(args, ctx, values, vectors))
               return;
             if (nout == 1) {
               out.push_back(fromEigenC(values));
               return;
             }
             out.push_back(fromEigenC(vectors));
             out.push_back(fromEigenC(MatrixXcd(values.asDiagonal())));
           },
           true);

  addFn(reg, "eigvr", 1, 1, "eigvr(A)",
        "right eigenvectors of A as columns (A*v = lambda*v), in the order of eig(A)",
        "np.linalg.eig / np.linalg.eigh",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd values, vectors;
          if (!eigDecompose(args, ctx, values, vectors))
            return Value(0.0);
          return fromEigenC(vectors);
        },
        true);

  addFn(reg, "eigvl", 1, 1, "eigvl(A)",
        "left eigenvectors of A as columns (w'*A = lambda*w'), in the order of eig(A)",
        "scipy.linalg.eig(left=True)",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd values, vectors;
          if (!eigDecompose(args, ctx, values, vectors))
            return Value(0.0);
          // The rows of inv(V) are the left eigenvectors (conjugated), in the
          // same order as the eigenvalues; each is scaled to unit length.
          Eigen::FullPivLU<MatrixXcd> lu(vectors);
          if (!lu.isInvertible()) {
            ctx.fail("A is not diagonalizable (its eigenvectors are not independent), so its "
                     "left eigenvectors are not defined this way");
            return Value(0.0);
          }
          MatrixXcd w = lu.inverse().adjoint();
          for (Eigen::Index j = 0; j < w.cols(); j++) {
            const double n = w.col(j).norm();
            if (n > 0)
              w.col(j) /= n;
          }
          return fromEigenC(w);
        },
        true);

  addFn(reg, "eig_ascend", 1, 1, "eig_ascend(A)",
        "eigenvalues of a symmetric (Hermitian) matrix, ascending, as a column",
        "np.linalg.eigvalsh",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a;
          if (!argSquareC(args, 0, ctx, a))
            return Value(0.0);
          if (!isHermitian(a)) {
            ctx.fail("needs a symmetric (Hermitian) matrix - use eig(A) for a general one");
            return Value(0.0);
          }
          Eigen::SelfAdjointEigenSolver<MatrixXcd> es(a, Eigen::EigenvaluesOnly);
          return fromEigen(es.eigenvalues());
        },
        true);

  // ---- decompositions ----------------------------------------------------------
  addMulti(reg, "svd", 1, 1, 3, "[U, S, V] = svd(A)",
           "singular values as a column; [U, S, V] = svd(A) gives A = U*S*V'", "np.linalg.svd",
           svdImpl, true);

  addFn(reg, "svdvals", 1, 1, "svdvals(A)", "singular values of A, largest first, as a column",
        "np.linalg.svdvals",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<Value> out;
          svdImpl(args, 1, out, ctx);
          return out.empty() ? Value(0.0) : out[0];
        },
        true);

  addMulti(reg, "qr", 1, 1, 2, "[Q, R] = qr(A)",
           "QR decomposition A = Q*R (Q orthogonal, R upper triangular); R = qr(A) gives R",
           "np.linalg.qr",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXcd a;
             if (!argMatrixC(args, 0, ctx, a))
               return;
             if (a.size() == 0) {
               ctx.fail("needs a non-empty matrix");
               return;
             }
             Eigen::HouseholderQR<MatrixXcd> qr(a);
             MatrixXcd R = qr.matrixQR().triangularView<Eigen::Upper>();
             MatrixXcd Q = qr.householderQ() * MatrixXcd::Identity(a.rows(), a.rows());
             if (nout == 1) {
               out.push_back(fromEigenC(R));
               return;
             }
             out.push_back(fromEigenC(Q));
             out.push_back(fromEigenC(R));
           },
           true);

  addFn(reg, "cholesky", 1, 1, "cholesky(A)",
        "lower-triangular L with A = L*L' (A symmetric positive definite)", "np.linalg.cholesky",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a;
          if (!argSquareC(args, 0, ctx, a))
            return Value(0.0);
          if (!isHermitian(a)) {
            ctx.fail("needs a symmetric (Hermitian) matrix");
            return Value(0.0);
          }
          Eigen::LLT<MatrixXcd> llt(a);
          if (llt.info() != Eigen::Success) {
            ctx.fail("the matrix is not positive definite");
            return Value(0.0);
          }
          return fromEigenC(MatrixXcd(llt.matrixL()));
        },
        true);

  addFn(reg, "cond", 1, 2, "cond(A[, p])",
        "condition number of A: 2-norm by default, or p = 1, inf, \"fro\"", "np.linalg.cond",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXd a;
          NormOrder ord;
          if (!argMatrix(args, 0, ctx, a) || (args.size() > 1 && !argOrder(args, 1, ctx, ord)))
            return Value(0.0);
          if (a.size() == 0) {
            ctx.fail("needs a non-empty matrix");
            return Value(0.0);
          }
          if (!ord.isText && ord.p == 2)
            return Value(conditionNumber2(a));
          if (a.rows() != a.cols()) {
            ctx.fail("this norm needs a square matrix, got " + shapeText(a));
            return Value(0.0);
          }
          if (isEffectivelySingular(a))
            return Value(infinity());
          MatrixXd inv = a.inverse();
          auto norm = [&](const MatrixXd &m) -> double {
            if (ord.isText)
              return m.norm(); // "fro"
            if (ord.p == 1)
              return m.cwiseAbs().colwise().sum().maxCoeff();
            if (std::isinf(ord.p) && ord.p > 0)
              return m.cwiseAbs().rowwise().sum().maxCoeff();
            return -1.0;
          };
          if (ord.isText && ord.text != "fro") {
            ctx.fail("p must be 1, 2, inf or \"fro\", got \"" + ord.text + "\"");
            return Value(0.0);
          }
          const double n1 = norm(a);
          if (n1 < 0) {
            ctx.fail("p must be 1, 2, inf or \"fro\"");
            return Value(0.0);
          }
          return Value(n1 * norm(inv));
        });

  // ---- 2-D tensor forms ----------------------------------------------------------
  addFn(reg, "tensorinv", 1, 1, "tensorinv(A)", "inverse of A (2-D form of np.linalg.tensorinv)",
        "np.linalg.tensorinv",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXd a;
          if (!argSquare(args, 0, ctx, a))
            return Value(0.0);
          if (isEffectivelySingular(a)) {
            ctx.fail("the matrix is singular (not invertible)");
            return Value(0.0);
          }
          return fromEigen(a.inverse());
        });
  addFn(reg, "tensorsolve", 2, 2, "tensorsolve(A, b)",
        "x with A*x = b (2-D form of np.linalg.tensorsolve)", "np.linalg.tensorsolve",
        solveImpl, true);

  addFn(reg, "diagonal", 1, 2, "diagonal(A[, k])",
        "the k-th diagonal of A as a row (k = 0 main, > 0 above, < 0 below)",
        "np.linalg.diagonal",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a;
          long long k = 0;
          if (!argMatrixC(args, 0, ctx, a) || (args.size() > 1 && !argInt(args, 1, ctx, k)))
            return Value(0.0);
          std::vector<Value> d;
          for (Eigen::Index r = 0; r < a.rows(); r++) {
            const Eigen::Index c = r + static_cast<Eigen::Index>(k);
            if (c >= 0 && c < a.cols())
              d.push_back(complexScalar(a(r, c)));
          }
          if (d.empty())
            return Value(std::vector<std::vector<Value>>{});
          return Value(std::vector<std::vector<Value>>{d});
        },
        true);
}

} // namespace vm
} // namespace numpy
} // namespace nc
