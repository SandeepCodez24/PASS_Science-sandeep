// Section 9 of 11 - Vector Math
// Planned entries: 136  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in four group files:
//
//   vm_ufuncs.cpp    element-wise math   fmax fmin equal equiv isclose allclose
//                                        log1p logaddexp inv_tan2 hypot anglewrap
//                                        sinc fabs sign ceil floor rint fix trunc
//                                        gcd lcm heaviside copysign signbit
//                                        nextafter spacing frexp ldexp modf img
//                                        + families expN(x), logaddexpN(a, b)
//   vm_products.cpp  products            dot inner outer cross tensordot einsum kron
//   vm_linalg.cpp    linear algebra      vector_norm slogdet solve lstsq eig eigvr
//                                        eigvl eig_ascend svd svdvals qr cholesky
//                                        cond tensorinv tensorsolve diagonal
//   vm_poly.cpp      polynomials         convolve polyfit polyval poly1d roots poly
//                                        polyadd polysub polymul polydiv polyder
//   vm_common.h      shared argument readers / result builders
//
// Names from the team's list that are existing NC builtins keep the builtin
// (now matrix-aware): max, min (max(A) reduces, max(A, B) is element-wise),
// exp, round, trace, matrix_norm, pinv, conj, real, imag, angle, transpose.
//
// How to add a function
//   1. Put it in the group file it belongs to (or a new vm_<group>.cpp with a
//      register<Group>(Registry&) declared in vm_common.h and called below).
//   2. Register it with addFn(...) / addMulti(...) (vm_common.h).
//   3. Rebuild - new .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("vector_math")   lists what is there.
//
// Rules (same for every section)
//   - Arguments are positional only.
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
#include "vector_math_main.h"

#include <cctype>
#include <string>

#include "vm_common.h"

namespace nc {
namespace numpy {

void registerVectorMath(Registry &reg) {
  vm::registerUfuncs(reg);
  vm::registerProducts(reg);
  vm::registerLinalg(reg);
  vm::registerPoly(reg);
}

Value callVectorMathFamily(const std::string &name, const std::vector<Value> &args,
                           CallContext &ctx, bool &matched) {
  matched = false;
  std::string low = name;
  for (char &c : low)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

  // Longest prefix first: "logaddexp10" must not be read as exp-something.
  for (const char *family : {"logaddexp", "exp"}) {
    const std::string prefix = family;
    if (low.size() <= prefix.size() || low.rfind(prefix, 0) != 0)
      continue;
    const std::string digits = low.substr(prefix.size());
    if (digits.find_first_not_of("0123456789") != std::string::npos)
      continue;
    matched = true;
    double base = 0.0;
    try {
      base = std::stod(digits);
    } catch (...) {
      ctx.fail("the base " + digits + " is too large");
      return Value(0.0);
    }
    return prefix == "exp" ? vm::expFamily(base, args, ctx) : vm::logaddexpFamily(base, args, ctx);
  }
  return Value(0.0);
}

} // namespace numpy
} // namespace nc
