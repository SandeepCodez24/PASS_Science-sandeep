// Section 9 of 11 - Vector Math
// Planned entries: 136
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in four group files:
//
//   vm_ufuncs.cpp    element-wise math   fmax fmin equal equiv isclose allclose
//                                        log1p logaddexp inv_tan2 hypot anglewrap
//                                        sinc fabs sign ceil floor rint fix trunc
//                                        gcd lcm heaviside copysign signbit
//                                        nextafter spacing frexp ldexp modf img
//                                        + families expN(x), logaddexpN(a, b)
//   vm_products.cpp  products            dot inner outer cross tensordot einsum kron
//   vm_linalg.cpp    linear algebra      vector_norm slogdet solve lstsq eig eigvr
//                                        eigvl eig_ascend svd svdvals qr cholesky
//                                        cond tensorinv tensorsolve diagonal
//   vm_poly.cpp      polynomials         convolve polyfit polyval poly1d roots poly
//                                        polyadd polysub polymul polydiv polyder
//   vm_common.h      shared argument readers / result builders
//
// Names from the team's list that are existing NC builtins keep the builtin
// (now matrix-aware): max, min (max(A) reduces, max(A, B) is element-wise),
// exp, round, trace, matrix_norm, pinv, conj, real, imag, angle, transpose.
//
// How to add a function
//   1. Put it in the group file it belongs to (or a new vm_<group>.cpp with a
//      register<Group>(Registry&) declared in vm_common.h and called below).
//   2. Register it with addFn(...) / addMulti(...) (vm_common.h).
//   3. Rebuild - new .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Inputs by name
//   Every function's inputs are listed once, in kVectorMathParams below, as
//   one parameter line (core/param_list.h): "A, B, atol=0.1, rtol=0".
//   That line decides which values a call may name - allclose(A, B,
//   atol=0.2) - and the defaults; the code of a function then simply reads
//   its arguments by position, defaults already filled in. A new function
//   gets its line here too.
//
// Rules (same for every section)
//   - Arguments are read by position (named values are placed by the
//     parameter line before the function runs).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
#include "vector_math_main.h"

#include <cctype>
#include <string>

#include "vm_common.h"

namespace nc {
namespace numpy {

namespace {

// The inputs of every Vector Math function, by name, in the order the code
// reads them (core/param_list.h): `name` must be given, `name=value` has a
// default, `name?` may be left out. Data inputs keep this section's own
// letters (A, B, x, p ...); options use NumPy's names (rtol, atol, axis,
// axes, mode, ord ...). einsum takes a variable number of operands, so its
// values are given in order only.
struct ParamRow {
  const char *name;
  const char *params;
};

const ParamRow kVectorMathParams[] = {
    // vm_ufuncs.cpp - element-wise
    {"fmax", "A, B"},
    {"fmin", "A, B"},
    {"equal", "A, B"},
    {"equiv", "A, B"},
    {"isclose", "A, B, atol=0.1, rtol=0"},  // NC defaults (2026-10-27)
    {"allclose", "A, B, atol=0.1, rtol=0"}, // NC defaults (2026-10-27)
    {"log1p", "x"},
    {"logaddexp", "A, B"},
    {"inv_tan2", "Y, X"},
    {"hypot", "A, B"},
    {"anglewrap", "theta, discont=pi"},
    {"sinc", "x"},
    {"fabs", "x"},
    {"sign", "x"},
    {"ceil", "x"},
    {"floor", "x"},
    {"rint", "x"},
    {"fix", "x"},
    {"trunc", "x"},
    {"gcd", "A, B?"},
    {"lcm", "A, B?"},
    {"heaviside", "x, h0"},
    {"copysign", "x, s"},
    {"signbit", "x"},
    {"nextafter", "x, y"},
    {"spacing", "x"},
    {"frexp", "x"},
    {"ldexp", "m, e"},
    {"modf", "x"},
    {"img", "z"},
    // vm_products.cpp - products
    {"dot", "A, B, axis?"},
    {"inner", "A, B"},
    {"outer", "a, b"},
    {"cross", "a, b, axis?"},
    {"tensordot", "A, B, axes=2"},
    {"kron", "A, B"},
    // vm_linalg.cpp - linear algebra
    {"vector_norm", "x, ord=2"},
    {"slogdet", "A"},
    {"solve", "A, b"},
    {"lstsq", "A, b, rcond?"},
    {"eig", "A"},
    {"eigvr", "A"},
    {"eigvl", "A"},
    {"eig_ascend", "A"},
    {"svd", "A"},
    {"svdvals", "A"},
    {"qr", "A"},
    {"cholesky", "A"},
    {"cond", "A, p=2"},
    {"tensorinv", "A, ind=2"},   // N-D, as NumPy (R5)
    {"tensorsolve", "A, b, axes?"},
    {"diagonal", "A, k=0"},
    // vm_poly.cpp - polynomials
    {"convolve", "a, v, mode=\"full\""},
    {"polyfit", "x, y, deg"},
    {"polyval", "p, x"},
    {"poly1d", "c, r=false, variable=\"x\""}, // a value: P(x), P[k] (R6)
    {"roots", "p"},
    {"poly", "r"},
    {"polyadd", "p1, p2"},
    {"polysub", "p1, p2"},
    {"polymul", "p1, p2"},
    {"polydiv", "p1, p2"},
    {"polyder", "p, m=1"},
};

} // namespace

void registerVectorMath(Registry &reg) {
  vm::registerUfuncs(reg);
  vm::registerProducts(reg);
  vm::registerLinalg(reg);
  vm::registerPoly(reg);
  for (const ParamRow &row : kVectorMathParams)
    reg.setParams(row.name, row.params);
}

Value callVectorMathFamily(const std::string &name, const std::vector<Value> &args,
                           CallContext &ctx, bool &matched) {
  matched = false;
  std::string low = name;
  for (char &c : low)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

  // Longest prefix first: "logaddexp10" must not be read as exp-something.
  for (const char *family : {"logaddexp", "exp"}) {
    const std::string prefix = family;
    if (low.size() <= prefix.size() || low.rfind(prefix, 0) != 0)
      continue;
    const std::string digits = low.substr(prefix.size());
    if (digits.find_first_not_of("0123456789") != std::string::npos)
      continue;
    matched = true;
    double base = 0.0;
    try {
      base = std::stod(digits);
    } catch (...) {
      ctx.fail("the base " + digits + " is too large");
      return Value(0.0);
    }
    return prefix == "exp" ? vm::expFamily(base, args, ctx) : vm::logaddexpFamily(base, args, ctx);
  }
  return Value(0.0);
}

} // namespace numpy
} // namespace nc
