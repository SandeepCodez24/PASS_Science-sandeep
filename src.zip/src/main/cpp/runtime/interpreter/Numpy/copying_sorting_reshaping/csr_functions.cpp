// Copying, Sorting & Reshaping.
//
//   sort_asc(A[, axis])      ascending, along an axis            np.sort
//   sort_desc(A[, axis])     descending, along an axis           -np.sort(-A)
//   sort_complex(A[, axis])  ascending by real, then imaginary part, as complex
//                                                                np.sort_complex
//   flatten(A, order="C")    every element in one 1xN row        ndarray.flatten
//                            ("C" row by row, "F" column by column)
//   flip(A[, axis])          reversed along one axis, or every axis   np.flip
//   fliplr(A)                columns reversed (left <-> right)   np.fliplr
//   flipud(A)                rows reversed (up <-> down)         np.flipud
//   rot90(A, k=1)            turned 90 degrees counter-clockwise k times
//                            (k < 0: clockwise)                  np.rot90
//   roll(A, shift[, axis])   elements moved `shift` places, those falling off
//                            one end coming back at the other    np.roll
//
// Sorting order: numbers ascending with NaN always LAST (also in sort_desc),
// integers exactly, text in dictionary (byte) order, complex numbers by real
// then imaginary part. Equal elements keep their order (a stable sort).
//
// Which axis when none is given: a vector (one row or one column) is
// sorted along its length; any other matrix row by row (axis -1, NumPy's
// default). Name the axis to choose: axis=0 sorts every column.
//
// Matrix-centred choices: fliplr / flipud / rot90 always work on the COLUMNS
// and ROWS (axes -1 / -2), for an N-D matrix on every page - the same as
// NumPy for 2-D values. roll without an axis moves the elements in row-by-row
// order and keeps the shape (NumPy).
#include "csr_functions.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>

#include "../numpy_nd.h"
#include "../../core/par_sort.h"

namespace nc {
namespace numpy {

namespace {

using ndx::Grid;

bool isNaNCell(const Value &c) {
  return !c.isText && (std::isnan(c.number) || (c.isComplex && std::isnan(c.imag)));
}
bool isNaNCell(double c) { return std::isnan(c); }

// The axis to sort along: the named one, else a vector's length, else -1.
template <class G>
bool sortAxis(const std::vector<Value> &args, const G &a, CallContext &ctx, size_t &axis) {
  const size_t rank = a.shape.size();
  if (args.size() > 1)
    return ndx::resolveAxis(args[1], rank, ctx, axis);
  axis = rank - 1;
  if (rank == 2 && a.shape[1] == 1 && a.shape[0] > 1)
    axis = 0; // a column vector: along its length
  return true;
}

// Sorts every line of `g` along `axis` in place. A line that is contiguous
// (inner == 1: a row vector, or rows of a matrix) is sorted where it lies;
// a long one on several cores (core/par_sort.h - the same order as one
// stable sort).
template <class G> void sortLines(G &g, size_t axis, bool descending) {
  using T = typename G::Cell;
  const ndx::AxisView v = ndx::viewOf(g.shape, axis);
  auto less = [descending](const T &x, const T &y) {
    const bool nx = isNaNCell(x), ny = isNaNCell(y);
    if (nx || ny)
      return !nx && ny; // NaN last, either way
    const int c = ndx::compareCells(x, y);
    return descending ? c > 0 : c < 0;
  };
  if (v.inner == 1) {
    for (size_t o = 0; o < v.outer; o++) {
      T *first = g.cells.data() + o * v.len;
      if constexpr (std::is_same_v<T, double>)
        ncsort::stableSort(first, first + v.len, less); // several cores (numbers only:
      else                                             // no Value moves in a par block)
        std::stable_sort(first, first + v.len, less);
    }
    return;
  }
  std::vector<T> line(v.len);
  for (size_t o = 0; o < v.outer; o++)
    for (size_t i = 0; i < v.inner; i++) {
      for (size_t k = 0; k < v.len; k++)
        line[k] = g.cells[(o * v.len + k) * v.inner + i];
      std::stable_sort(line.begin(), line.end(), less);
      for (size_t k = 0; k < v.len; k++)
        g.cells[(o * v.len + k) * v.inner + i] = line[k];
    }
}

Impl sortImpl(bool descending, bool asComplex) {
  return [descending, asComplex](const std::vector<Value> &args, CallContext &ctx) -> Value {
    // All plain float64 (2026-11-20): sorted as doubles.
    ndx::NumGrid n;
    if (!asComplex && ndx::argNumGrid(args, 0, n)) {
      size_t axis = 0;
      if (!sortAxis(args, n, ctx, axis))
        return Value(0.0);
      if (n.count() > 0)
        sortLines(n, axis, descending);
      return ndx::valueOf(n);
    }
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    size_t axis = 0;
    if (!sortAxis(args, a, ctx, axis))
      return Value(0.0);
    if (asComplex) {
      for (Value &c : a.cells) {
        if (!isPlainNumber(c) || c.isTime()) {
          ctx.fail("it works on numbers");
          return Value(0.0);
        }
        if (!c.isComplex)
          c = Value::complexNumber(c.number, 0.0);
      }
    }
    if (a.count() > 0)
      sortLines(a, axis, descending);
    return ndx::valueOf(a);
  };
}

// Reverses `g` along `axis` (2026-11-20: by index, no vector per slice).
template <class G> void reverseAlong(G &g, size_t axis) {
  const size_t len = g.shape[axis];
  std::vector<size_t> from(len);
  for (size_t k = 0; k < len; k++)
    from[k] = len - 1 - k;
  g = ndx::gatherAlong(g, axis, from);
}

// Column by column (the FIRST index fastest) - flatten(A, "F").
template <class G> Value flattenF(const G &a) {
  std::vector<typename G::Cell> out;
  out.reserve(a.count());
  const nd::Shape &s = a.shape;
  std::vector<size_t> idx(s.size(), 0);
  if (a.count() > 0) {
    for (;;) {
      size_t flat = 0;
      for (size_t d = 0; d < s.size(); d++)
        flat = flat * s[d] + idx[d];
      out.push_back(a.cells[flat]);
      size_t d = 0;
      while (d < s.size() && ++idx[d] == s[d])
        idx[d++] = 0;
      if (d == s.size())
        break;
    }
  }
  return ndx::rowOf(out);
}

Value flatten(const std::vector<Value> &args, CallContext &ctx) {
  // A packed or typed (R9) array / matrix in C order: the elements moved
  // straight from the buffer into a 1 x n row - no Value per element, type
  // kept. Same elements and order as the cell walk below.
  if (!args.empty() && (args.size() < 2 || (args[1].isText && (args[1].text() == "C" || args[1].text() == "c"))) &&
      (args[0].isArray || args[0].isMatrix) && (args[0].isPacked() || args[0].isTypedPacked())) {
    const Value &v = args[0];
    std::vector<size_t> shape = v.isArray ? std::vector<size_t>{v.length()}
                                : v.isND()  ? v.ndShape()
                                            : std::vector<size_t>{v.rows(), v.cols()};
    size_t n = 1;
    for (size_t d : shape)
      n *= d;
    const size_t rank = shape.size();
    const size_t rows = rank >= 2 ? shape[rank - 2] : 1, cols = rank >= 2 ? shape[rank - 1] : n, page = rows * cols;
    auto storageOf = [&](size_t k) { // row-major position k -> storage index
      if (rank < 2)
        return k;
      const size_t p = k / page, within = k % page;
      return p * page + (within % cols) * rows + within / cols;
    };
    if (n > 0 && v.isTypedPacked()) {
      const size_t b = elemTypeBytes(v.elemType());
      std::vector<uint8_t> raw(n * b);
      const uint8_t *src = v.typedData();
      for (size_t k = 0; k < n; k++)
        std::memcpy(raw.data() + k * b, src + storageOf(k) * b, b);
      return Value::typedTensor(v.elemType(), {1, n}, std::move(raw), v.tensorDimL(), v.tensorDimT(),
                                v.tensorDimM());
    }
    if (n > 0 && v.isPacked() && v.dimL == 0 && v.dimT == 0 && v.dimM == 0) {
      std::vector<double> out(n);
      const double *src = v.packedData();
      for (size_t k = 0; k < n; k++)
        out[k] = src[storageOf(k)];
      return Value::packedMatrix(out.data(), 1, n);
    }
  }
  if (args.empty() || ndx::notMatrixData(args[0])) {
    Grid bad; // reports the first argument's error, as before
    ndx::argGrid(args, 0, ctx, bad);
    return Value(0.0);
  }
  std::string order;
  if (!argText(args, 1, ctx, order))
    return Value(0.0);
  for (char &c : order)
    c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  if (order != "C" && order != "F") {
    ctx.fail("order must be \"C\" (row by row) or \"F\" (column by column)");
    return Value(0.0);
  }
  ndx::NumGrid n; // all plain float64 (2026-11-20)
  if (ndx::argNumGrid(args, 0, n))
    return order == "C" ? ndx::rowOf(n.cells) : flattenF(n);
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  if (order == "C")
    return ndx::rowOf(a.cells);
  return flattenF(a);
}

// flip / fliplr / flipud of a packed unitless value (2026-11-20): its
// numbers in row-major order, reversed all at once or along one axis, then
// packed again - the value the Grid path below gives, without a Value per
// element (62.8 M elements: ~11 s before 2026-11-20). False: use the Grid path.
bool flipNumbers(const Value &v, bool allAxes, size_t axis, Value &out) {
  std::vector<double> x;
  if (v.hasUnit() || !ncpack::readRowMajorAnyRank(v, x) || x.empty())
    return false;
  const nd::Shape s = nd::shapeOf(v);
  if (allAxes) {
    std::reverse(x.begin(), x.end());
  } else {
    size_t outer = 1, inner = 1;
    for (size_t d = 0; d < axis; d++)
      outer *= s[d];
    for (size_t d = axis + 1; d < s.size(); d++)
      inner *= s[d];
    const size_t len = s[axis];
    for (size_t o = 0; o < outer; o++)
      for (size_t k = 0; k < len / 2; k++)
        std::swap_ranges(x.begin() + static_cast<std::ptrdiff_t>((o * len + k) * inner),
                         x.begin() + static_cast<std::ptrdiff_t>((o * len + k + 1) * inner),
                         x.begin() + static_cast<std::ptrdiff_t>((o * len + len - 1 - k) * inner));
  }
  out = ncpack::fromRowMajorShape(s, x);
  return true;
}

Value flip(const std::vector<Value> &args, CallContext &ctx) {
  if (!args.empty() && args[0].isPacked() && !args[0].hasUnit()) {
    const nd::Shape s = nd::shapeOf(args[0]);
    size_t axis = 0;
    if (args.size() > 1 && !ndx::resolveAxis(args[1], s.size(), ctx, axis))
      return Value(0.0);
    Value out;
    if (flipNumbers(args[0], args.size() <= 1, axis, out))
      return out;
  }
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  if (args.size() > 1) {
    size_t axis = 0;
    if (!ndx::resolveAxis(args[1], a.shape.size(), ctx, axis))
      return Value(0.0);
    reverseAlong(a, axis);
  } else {
    std::reverse(a.cells.begin(), a.cells.end()); // every axis at once
  }
  return ndx::valueOf(a);
}

Impl flipFixed(long long fromEnd) { // -1 columns, -2 rows
  return [fromEnd](const std::vector<Value> &args, CallContext &ctx) -> Value {
    if (!args.empty() && args[0].isPacked() && !args[0].hasUnit()) {
      const size_t rank = nd::shapeOf(args[0]).size();
      Value out;
      if (flipNumbers(args[0], false, static_cast<size_t>(static_cast<long long>(rank) + fromEnd), out))
        return out;
    }
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    reverseAlong(a, static_cast<size_t>(static_cast<long long>(a.shape.size()) + fromEnd));
    return ndx::valueOf(a);
  };
}

// One body for cells and for plain numbers (2026-11-20): `a` is a Grid or a
// NumGrid, the result is the same value either way.
template <class G> Value rot90Body(G a, long long k) {
  k = ((k % 4) + 4) % 4;
  const size_t rank = a.shape.size();
  const size_t R = a.shape[rank - 2], C = a.shape[rank - 1];
  const size_t pages = R * C == 0 ? 0 : a.count() / (R * C);
  for (long long turn = 0; turn < k; turn++) {
    // One quarter turn counter-clockwise: B[i][j] = A[j][C-1-i], B is C x R.
    const size_t r = a.shape[rank - 2], c = a.shape[rank - 1];
    std::vector<typename G::Cell> cells(a.count());
    for (size_t p = 0; p < pages; p++)
      for (size_t i = 0; i < c; i++)
        for (size_t j = 0; j < r; j++)
          cells[p * r * c + i * r + j] = a.cells[p * r * c + j * c + (c - 1 - i)];
    a.cells = std::move(cells);
    std::swap(a.shape[rank - 2], a.shape[rank - 1]);
  }
  return ndx::valueOf(a);
}

Value rot90(const std::vector<Value> &args, CallContext &ctx) {
  ndx::NumGrid n;
  const bool numbers = ndx::argNumGrid(args, 0, n);
  Grid a;
  if (!numbers && !ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  long long k = 0;
  if (!argInt(args, 1, ctx, k))
    return Value(0.0);
  return numbers ? rot90Body(std::move(n), k) : rot90Body(std::move(a), k);
}

// roll: elements (no axis) or whole slices (axis) moved `shift` places to the
// right, those falling off the end coming back at the front.
template <class G>
Value rollBody(G a, long long shift, const std::vector<Value> &args, CallContext &ctx) {
  if (args.size() < 3) {
    const long long n = static_cast<long long>(a.count());
    if (n > 0) {
      const long long s = ((shift % n) + n) % n; // to the right by s
      std::rotate(a.cells.begin(), a.cells.begin() + (n - s) % n, a.cells.end()); // shape kept
    }
    return ndx::valueOf(a);
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[2], a.shape.size(), ctx, axis))
    return Value(0.0);
  const long long len = static_cast<long long>(a.shape[axis]);
  if (len == 0)
    return ndx::valueOf(a);
  const long long s = ((shift % len) + len) % len;
  std::vector<size_t> from(static_cast<size_t>(len)); // out slice k = in slice k - s
  for (long long k = 0; k < len; k++)
    from[static_cast<size_t>(k)] = static_cast<size_t>((k + len - s) % len);
  return ndx::valueOf(ndx::gatherAlong(a, axis, from));
}

Value roll(const std::vector<Value> &args, CallContext &ctx) {
  ndx::NumGrid n;
  const bool numbers = ndx::argNumGrid(args, 0, n);
  Grid a;
  if (!numbers && !ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  long long shift = 0;
  if (!argInt(args, 1, ctx, shift))
    return Value(0.0);
  return numbers ? rollBody(std::move(n), shift, args, ctx) : rollBody(std::move(a), shift, args, ctx);
}

void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
         const char *numpyName, Impl impl) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::CopyingSortingReshaping;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = true; // they move elements; complex order is defined
  reg.add(std::move(spec));
}

} // namespace

void registerCopySortReshapeFunctions(Registry &reg) {
  add(reg, "sort_asc", 1, 2, "sorted ascending along an axis", "np.sort", sortImpl(false, false));
  add(reg, "sort_desc", 1, 2, "sorted descending along an axis", "-np.sort(-a)",
      sortImpl(true, false));
  add(reg, "sort_complex", 1, 2, "sorted by real then imaginary part", "np.sort_complex",
      sortImpl(false, true));
  add(reg, "flatten", 1, 2, "every element in one row", "ndarray.flatten", flatten);
  add(reg, "flip", 1, 2, "reversed along an axis (or all)", "np.flip", flip);
  add(reg, "fliplr", 1, 1, "columns reversed", "np.fliplr", flipFixed(-1));
  add(reg, "flipud", 1, 1, "rows reversed", "np.flipud", flipFixed(-2));
  add(reg, "rot90", 1, 2, "turned 90 degrees counter-clockwise", "np.rot90", rot90);
  add(reg, "roll", 2, 3, "elements moved around in a cycle", "np.roll", roll);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"sort_asc", "A, axis?"},   {"sort_desc", "A, axis?"},       {"sort_complex", "A, axis?"},
      {"flatten", "A, order=\"C\""}, {"flip", "A, axis?"},         {"fliplr", "A"},
      {"flipud", "A"},            {"rot90", "A, k=1"},             {"roll", "A, shift, axis?"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
