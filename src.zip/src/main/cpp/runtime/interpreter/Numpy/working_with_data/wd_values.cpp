// Working with Data - checking and cleaning values.
//
//   is_nan_each(A)   is_inf(A)   is_finite(A)   is_posinf(A)   is_neginf(A)
//                    true / false per element (shape kept). A complex number is
//                    NaN / infinite when either part is; is_posinf / is_neginf
//                    take real numbers. (The existing is_nan(x) stays for one
//                    number.)
//   [values, indices, inverse, counts] = unique_all(A)                  np.unique_all
//                    values: the distinct elements, sorted (a row)
//                    indices: where each first occurs (flat position, row by row)
//                    inverse: for every element of A, its place in values (A's shape)
//                    counts: how often each occurs
//   fill_nan(A, value=0, method="value", axis=-1)
//                    NaN replaced: "value" by value, "ffill" by the last number
//                    before it, "bfill" by the next one after it, "mean" by the
//                    mean of its line, "linear" by straight-line interpolation
//                    between its neighbours. Lines run along `axis` (a vector:
//                    along its length); where no neighbour exists, value is used.
#include <algorithm>
#include <cctype>
#include <cmath>
#include <string>
#include <vector>

#include "wd_common.h"
#include "../../core/par_sort.h"

namespace nc {
namespace numpy {
namespace wd {

namespace {

enum class Test { NaN, Inf, Finite, PosInf, NegInf };

Impl testImpl(Test t) {
  return [t](const std::vector<Value> &args, CallContext &ctx) -> Value {
    // Plain float64 (2026-11-20): one pass over the numbers, a bool tensor
    // straight out - what the per-element path below builds.
    ndx::NumGrid n;
    if (ndx::numGridOf(args[0], n) && n.count() > 0) {
      std::vector<uint8_t> on(n.count());
      for (size_t k = 0; k < on.size(); k++) {
        const double re = n.cells[k];
        bool b = false;
        switch (t) {
        case Test::NaN: b = std::isnan(re); break;
        case Test::Inf: b = std::isinf(re); break;
        case Test::Finite: b = std::isfinite(re); break;
        case Test::PosInf: b = std::isinf(re) && re > 0; break;
        case Test::NegInf: b = std::isinf(re) && re < 0; break;
        }
        on[k] = b ? 1 : 0;
      }
      return ndx::boolsOf(n.shape, on);
    }
    return mapElements(
        {args[0]},
        [t](const std::vector<Value> &e, Value &r, CallContext &c) {
          const Value &v = e[0];
          if (!isPlainNumber(v) || v.isTime()) {
            c.fail("it works on numbers");
            return false;
          }
          if (v.isComplex && (t == Test::PosInf || t == Test::NegInf)) {
            c.fail("it works on real numbers - a complex number has no sign of infinity");
            return false;
          }
          const double re = v.number, im = v.isComplex ? v.imag : 0.0;
          bool b = false;
          switch (t) {
          case Test::NaN: b = std::isnan(re) || std::isnan(im); break;
          case Test::Inf: b = std::isinf(re) || std::isinf(im); break;
          case Test::Finite: b = std::isfinite(re) && std::isfinite(im); break;
          case Test::PosInf: b = std::isinf(re) && re > 0; break;
          case Test::NegInf: b = std::isinf(re) && re < 0; break;
          }
          r = Value::boolean(b);
          return true;
        },
        ctx);
  };
}

// One body for cells and plain numbers (2026-11-20, numpy_nd.h NumGrid).
template <class G> bool uniqueAllBody(const G &a, std::vector<Value> &out) {
  using Cell = typename G::Cell;
  std::vector<size_t> order(a.count());
  for (size_t i = 0; i < order.size(); i++)
    order[i] = i;
  auto less = [&](size_t x, size_t y) { return ndx::compareCells(a.cells[x], a.cells[y]) < 0; };
  if constexpr (std::is_same_v<Cell, double>) // several cores, same order
    ncsort::stableSort(order.data(), order.data() + order.size(), less);
  else
    std::stable_sort(order.begin(), order.end(), less);
  std::vector<Cell> values;
  std::vector<double> first, counts, inverse(a.count());
  for (size_t k : order) {
    if (values.empty() || ndx::compareCells(values.back(), a.cells[k]) != 0) {
      values.push_back(a.cells[k]);
      first.push_back(static_cast<double>(k)); // stable sort: the earliest comes first
      counts.push_back(0);
    }
    counts.back() += 1;
    inverse[k] = static_cast<double>(values.size() - 1);
  }
  const ndx::NumGrid inv{a.shape, std::move(inverse)}; // packed directly
  const std::vector<Value> none;
  out = {ndx::rowOf(values), makeMatrix(std::vector<std::vector<double>>{first}),
         ndx::valueOf(inv), makeMatrix(std::vector<std::vector<double>>{counts})};
  if (values.empty())
    out = {ndx::rowOf(none), ndx::rowOf(none), ndx::valueOf(inv), ndx::rowOf(none)};
  return true;
}

bool uniqueAll(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  ndx::NumGrid n;
  if (ndx::argNumGrid(args, 0, n))
    return uniqueAllBody(n, out);
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return false;
  return uniqueAllBody(a, out);
}

Value fillNan(const std::vector<Value> &args, CallContext &ctx) {
  // A packed float64 value is read straight from its buffer (2026-11-20).
  ndx::NumGrid a;
  std::vector<double> &x = a.cells;
  if (!ndx::argNumGrid(args, 0, a)) {
    Grid g;
    if (!ndx::argGrid(args, 0, ctx, g))
      return Value(0.0);
    if (!ndx::realCells(g, x)) {
      ctx.fail("it works on real numbers");
      return Value(0.0);
    }
    a.shape = g.shape;
  }
  double value = 0;
  std::string method;
  if (!argNumber(args, 1, ctx, value) || !argText(args, 2, ctx, method))
    return Value(0.0);
  for (char &c : method)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (method != "value" && method != "ffill" && method != "bfill" && method != "mean" &&
      method != "linear") {
    ctx.fail("method must be \"value\", \"ffill\", \"bfill\", \"mean\" or \"linear\"");
    return Value(0.0);
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[3], a.shape.size(), ctx, axis))
    return Value(0.0);
  if (a.shape.size() == 2 && a.shape[1] == 1 && a.shape[0] > 1 && axis == 1)
    axis = 0; // a column vector: along its length
  const ndx::AxisView v = ndx::viewOf(a.shape, axis);
  std::vector<double> line(v.len);
  for (size_t o = 0; o < v.outer; o++)
    for (size_t i = 0; i < v.inner; i++) {
      for (size_t k = 0; k < v.len; k++)
        line[k] = x[(o * v.len + k) * v.inner + i];
      std::vector<double> l = line;
      if (method == "value") {
        for (double &d : l)
          if (std::isnan(d))
            d = value;
      } else if (method == "mean") {
        double s = 0, n = 0;
        for (double d : line)
          if (!std::isnan(d)) {
            s += d;
            n += 1;
          }
        for (double &d : l)
          if (std::isnan(d))
            d = n > 0 ? s / n : value;
      } else {
        // The nearest number before / after each position, in one pass each
        // way (2026-11-20; was a scan per NaN - quadratic in a run of NaNs).
        const long long len = static_cast<long long>(line.size());
        std::vector<long long> prevNum(line.size()), nextNum(line.size());
        long long last = -1;
        for (long long k = 0; k < len; k++) {
          prevNum[static_cast<size_t>(k)] = last;
          if (!std::isnan(line[static_cast<size_t>(k)]))
            last = k;
        }
        last = len;
        for (long long k = len - 1; k >= 0; k--) {
          nextNum[static_cast<size_t>(k)] = last;
          if (!std::isnan(line[static_cast<size_t>(k)]))
            last = k;
        }
        for (size_t k = 0; k < l.size(); k++) {
          if (!std::isnan(line[k]))
            continue;
          const long long p = prevNum[k], q = nextNum[k];
          const bool hasP = p >= 0, hasQ = q < static_cast<long long>(line.size());
          const double pv = hasP ? line[static_cast<size_t>(p)] : value;
          const double qv = hasQ ? line[static_cast<size_t>(q)] : value;
          if (method == "ffill")
            l[k] = pv;
          else if (method == "bfill")
            l[k] = qv;
          else if (hasP && hasQ) // linear
            l[k] = pv + (qv - pv) * static_cast<double>(static_cast<long long>(k) - p) /
                            static_cast<double>(q - p);
          else
            l[k] = hasP ? pv : (hasQ ? qv : value); // an end: the nearest number
        }
      }
      for (size_t k = 0; k < v.len; k++)
        x[(o * v.len + k) * v.inner + i] = l[k];
    }
  if (!args[0].isArray && !args[0].isMatrix && !args[0].isND())
    return Value(x[0]);
  return ndx::valueOf(a); // packed directly
}

} // namespace

void registerValueFunctions(Registry &reg) {
  add(reg, "is_nan_each", 1, 1, "per element: is it NaN", "np.isnan", testImpl(Test::NaN), true);
  add(reg, "is_inf", 1, 1, "per element: is it infinite", "np.isinf", testImpl(Test::Inf), true);
  add(reg, "is_finite", 1, 1, "per element: is it finite", "np.isfinite", testImpl(Test::Finite),
      true);
  add(reg, "is_posinf", 1, 1, "per element: is it +infinity", "np.isposinf",
      testImpl(Test::PosInf), true);
  add(reg, "is_neginf", 1, 1, "per element: is it -infinity", "np.isneginf",
      testImpl(Test::NegInf), true);
  {
    FunctionSpec spec;
    spec.name = "unique_all";
    spec.section = Section::WorkingWithData;
    spec.minArgs = 1;
    spec.maxArgs = 1;
    spec.signature = "unique_all";
    spec.summary = "distinct values with first positions, inverse and counts";
    spec.numpyName = "np.unique_all";
    spec.impl = ndx::resultsAsList(uniqueAll);
    spec.multiImpl = ndx::resultsPerName(uniqueAll);
    spec.maxOutputs = 4;
    spec.acceptsComplex = true;
    reg.add(std::move(spec));
  }
  add(reg, "fill_nan", 1, 4, "NaN replaced by a value or by neighbours", "pandas fillna",
      fillNan);

  reg.setParams("is_nan_each", "A");
  reg.setParams("is_inf", "A");
  reg.setParams("is_finite", "A");
  reg.setParams("is_posinf", "A");
  reg.setParams("is_neginf", "A");
  reg.setParams("unique_all", "A");
  reg.setParams("fill_nan", "A, value=0, method=\"value\", axis=-1");
}

} // namespace wd
} // namespace numpy
} // namespace nc
