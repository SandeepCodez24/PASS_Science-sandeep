# Numpy — NumPy-equivalent functions for NC

582 functions in 11 sections, each section owned and developed independently.

```
runtime/interpreter/Numpy/
├── numpy_main.h / .cpp        entry point: initialize(), tryCall()  ← only thing builtins.cpp calls
├── numpy_registry.h / .cpp    name → FunctionSpec table, section table (planned counts), reserved names
├── numpy_common.h             shared argument / result helpers
├── numpy_sources.cmake        globs every .cpp in this tree for the build
├── importing_data/            importing_data_main.h/.cpp            29
├── creating_arrays/           creating_arrays_main.h/.cpp           71
├── inspecting_properties/     inspecting_properties_main.h/.cpp     42
├── copying_sorting_reshaping/ copying_sorting_reshaping_main.h/.cpp 47
├── adding_removing_elements/  adding_removing_elements_main.h/.cpp  20
├── combining_splitting/       combining_splitting_main.h/.cpp       17
├── indexing_slicing/          indexing_slicing_main.h/.cpp          54
├── scalar_math/               scalar_math_main.h/.cpp               38
├── vector_math/               vector_math_main.h/.cpp              136
├── statistics/                statistics_main.h/.cpp                55
└── working_with_data/         working_with_data_main.h/.cpp         73
```

## How a call reaches your code

```
NC source      y = outer_demo(a, b);
Lexer          IDENT LPAREN IDENT COMMA IDENT RPAREN        (no change needed)
Parser         ExprKind::Call "outer_demo" [a, b]           (no change needed)
Tree-walker    evaluateExpr → callBuiltin(name, args)
JIT            nc_bridge_call_dynamic → callBuiltin(name, args)
callBuiltin    1. builtinTable (ops/)      → existing builtins always win
               2. nc::numpy::tryCall()     → Registry → arg check → your lambda
               3. logbN family, then "Unknown function"
```

The mapping from NC name to C++ code is the `reg.add({...})` entry in your
section. That is the only mapping a section developer writes.

## Adding a function (section developer)

1. In `<section>/<section>_main.cpp`, copy the commented example.
2. Fill in: NC name, `Section::...`, min/max args, usage text, summary, NumPy original, lambda.
3. For a group of functions, add `<section>/<prefix>_<group>.h/.cpp` with a
   `register<Group>(Registry&)` and call it from your section's register function.
4. Rebuild — new `.cpp` files are picked up automatically. Then in NC:

```
numpy_functions("vector_math")   % names registered in one section
numpy_functions()                % all registered names
numpy_status()                   % done / skipped / planned for all 11 sections
```

You never edit files outside your section folder.

## Rules

| Rule | Why |
|---|---|
| Use the NC name from the team's agreed name list; matching is case-insensitive | same as every other builtin |
| A name already owned by an ops/ builtin (`sum`, `mean`, `sin`, `det`, `dot`, …) is skipped | team decision: the existing builtin stays. Printed at startup, counted by `numpy_status()` |
| NC keywords, parser-reserved calls (`feval`, `grad`, `parent`, …) and `logbN` names are skipped | they never reach `callBuiltin()` |
| Arguments are positional only, for now | named arguments (`f(a=3, axis=0)`) are a planned parser feature |
| Report bad input with `ctx.fail("...")`, then return any Value | prints one `Error: name: ...` line and stops the statement, like every NC error |
| Complex arguments are refused unless the spec sets `acceptsComplex = true` | same rule as the ops/ builtins |
| Don't throw on user mistakes, don't print errors yourself, don't modify `args` | one consistent error path for all 582 functions |
| Use the helpers in `numpy_common.h` (`argNumber`, `argInt`, `argNumbers`, `makeArray`, `makeMatrix`, …) | identical error wording everywhere |

Note: a user-defined NC `function` with the same name as a NumPy function wins,
because evaluateExpr() checks user functions before builtins.

## Still open

- **N-D arrays** — NC values are scalar, 1-D array or 2-D matrix; 3-D+ format to be decided.
- **Named arguments** — `f(a=3, b=5)`, `axis=0`: parser + AST + call ABI change, planned.
