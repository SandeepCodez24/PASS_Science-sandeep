// Shape-and-axis helpers shared by the NumPy sections that move, cut, sort
// or compare the elements of a matrix of any rank (adding/removing,
// copying/sorting/reshaping, indexing, working with data ...).
// Header-only, like numpy_common.h.
//
// A value is handled as a Grid: its shape as a matrix (ops/matrix/nd_array.h -
// a single value [1, 1], a 1-D array [1, n], a matrix [r, c], an N-D matrix
// [d0, ..., r, c]) and its elements in ROW-MAJOR order (the last index
// fastest - the order NumPy's flat indices and reshape use). Every element
// stays a whole Value, so ints, bools, text and complex numbers keep their
// type; a result whose cells were mixed goes through the matrix type rules
// (unifyCells) so it holds what the matrix literal would.
//
// Axes count from the first (axis 0) and a negative axis from the end
// (-1 = columns, -2 = rows), as in NumPy.
#ifndef NC_NUMPY_ND_H
#define NC_NUMPY_ND_H

#include <cmath>
#include <functional>
#include <string>
#include <vector>

#include "numpy_common.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/matrix/nd_array.h"

namespace nc {
namespace numpy {
namespace ndx {

// A shape and its cells in row-major order. Grid holds whole Values (any
// element kind). NumGrid (2026-11-20) holds plain doubles: the same value
// when every element is a unitless float64, without a 32-byte Value per
// element - the functions below run one body on either (templates), and
// take NumGrid whenever numGridOf() accepts the input.
template <class T> struct GridOf {
  using Cell = T;
  nd::Shape shape;
  std::vector<T> cells; // row-major
  size_t count() const { return cells.size(); }
};
using Grid = GridOf<Value>;
using NumGrid = GridOf<double>;

inline Grid gridOf(const Value &v) {
  // Packed unitless float64 (2026-11-20): one buffer pass instead of
  // elementAt() per cell; each cell is the plain number elementAt() gave.
  std::vector<double> x;
  if (!v.hasUnit() && ncpack::readRowMajorAnyRank(v, x)) {
    Grid g{nd::shapeOf(v), {}};
    g.cells.reserve(x.size());
    for (double d : x)
      g.cells.emplace_back(d);
    return g;
  }
  return Grid{nd::shapeOf(v), nd::rowMajorCells(v)};
}

// A Grid back as a value: a 2-D matrix for rank 2, N-D for more, [] when empty.
inline Value valueOf(const Grid &g) { return nd::buildRowMajor(g.shape, g.cells); }

// The same for numbers: what buildRowMajor() gives for plain Value(d) cells.
inline Value valueOf(const NumGrid &g) {
  const nd::Shape shape = g.shape.size() < 2 ? nd::withRank(g.shape, 2) : g.shape;
  if (nd::countOf(shape) == 0)
    return Value(std::vector<std::vector<Value>>{});
  return ncpack::fromRowMajorShape(shape, g.cells);
}

// The cells as a 1xN row matrix (a flattened result).
inline Value rowOf(const std::vector<Value> &cells) {
  return nd::buildRowMajor({1, cells.size()}, cells);
}
inline Value rowOf(const std::vector<double> &cells) {
  if (cells.empty())
    return nd::buildRowMajor({1, 0}, std::vector<Value>{});
  return ncpack::matrixFromRowMajor(cells.data(), 1, cells.size());
}

// True for a dict, object or function reference - nothing a matrix holds.
inline bool notMatrixData(const Value &v) { return v.isDict || v.isObject || v.isFunctionRef; }

// `v` as a NumGrid: only a packed unitless float64 value (any rank) - every
// element a plain number, so the NumGrid gives back exactly what the Grid
// would. False for anything else (the caller takes the Grid path).
inline bool numGridOf(const Value &v, NumGrid &out) {
  if (notMatrixData(v) || v.hasUnit() || !v.isPacked())
    return false;
  if (!ncpack::readRowMajorAnyRank(v, out.cells))
    return false;
  out.shape = nd::shapeOf(v);
  return true;
}
inline bool argNumGrid(const std::vector<Value> &args, size_t i, NumGrid &out) {
  return i < args.size() && numGridOf(args[i], out);
}

// A "values" argument (put, replace_if, insert, where's x / y ...) as a
// NumGrid: what numGridOf() takes, and a plain unitless float64 number as
// the 1x1 grid gridOf() makes of it. Not for the main argument of a function
// that answers a single value with a single value.
inline bool valuesGridOf(const Value &v, NumGrid &out) {
  if (numGridOf(v, out))
    return true;
  if (!Value::packsAsPlainReal(v))
    return false;
  out.shape = {1, 1};
  out.cells = {v.number};
  return true;
}

// A condition / mask as a NumGrid (2026-11-20): what numGridOf() takes, and
// also a bool tensor (A > 2, k % 3 == 0 ...) as 0 / 1. Only for arguments
// that are used as true / false and nothing else - maskCell() gives the same
// answer for a bool cell and for its 0 / 1.
inline bool condGridOf(const Value &v, NumGrid &out) {
  if (valuesGridOf(v, out))
    return true;
  if (notMatrixData(v) || !v.isTypedPacked() || v.elemType() != ElemType::Bool || v.hasUnit())
    return false;
  const std::vector<size_t> &shape = v.tensorShape();
  const size_t n = v.tensorCount();
  const uint8_t *raw = v.typedData();
  out.shape = nd::shapeOf(v);
  out.cells.resize(n);
  if (shape.size() < 2) {
    for (size_t k = 0; k < n; k++)
      out.cells[k] = raw[k] ? 1.0 : 0.0;
    return true;
  }
  const size_t R = shape[shape.size() - 2], C = shape[shape.size() - 1], page = R * C;
  for (size_t p = 0; page && p < n / page; p++)
    for (size_t r = 0; r < R; r++)
      for (size_t c = 0; c < C; c++)
        out.cells[p * page + r * C + c] = raw[p * page + c * R + r] ? 1.0 : 0.0;
  return true;
}

// A true/false matrix of `shape0` from one 0/1 byte per element in row-major
// order (2026-11-20): the bool tensor valueOf() packs Value::boolean() cells
// into - one byte per element in storage order, same shape, no unit.
inline Value boolsOf(const nd::Shape &shape0, const std::vector<uint8_t> &rowMajor) {
  const nd::Shape shape = shape0.size() < 2 ? nd::withRank(shape0, 2) : shape0;
  if (nd::countOf(shape) == 0)
    return Value(std::vector<std::vector<Value>>{});
  const size_t R = shape[shape.size() - 2], C = shape[shape.size() - 1], page = R * C;
  std::vector<uint8_t> raw(rowMajor.size());
  for (size_t p = 0; page && p < rowMajor.size() / page; p++)
    ncpack::rowToColumnMajor(rowMajor.data() + p * page, R, C, raw.data() + p * page);
  return Value::typedTensor(ElemType::Bool, shape, std::move(raw));
}

// unifyCells() for numbers: plain float64 cells need no unifying.
inline bool unifyCells(std::vector<double> &, CallContext &) { return true; }

// args[i] as a Grid; fails for a dict / object / function reference.
inline bool argGrid(const std::vector<Value> &args, size_t i, CallContext &ctx, Grid &out) {
  if (i >= args.size() || notMatrixData(args[i])) {
    ctx.fail("the " + ordinal(i) + " argument must be a matrix, a number or text");
    return false;
  }
  out = gridOf(args[i]);
  return true;
}

// A whole number in [-rank, rank-1] (or [-(rank+1), rank] when `inserting`),
// as an axis index.
inline bool resolveAxis(const Value &a, size_t rank, CallContext &ctx, size_t &out,
                        bool inserting = false) {
  if (!isPlainNumber(a) || !std::isfinite(a.number) || a.number != std::floor(a.number)) {
    ctx.fail("axis must be a whole number, e.g. axis=0 (rows of a matrix) or axis=-1 (columns)");
    return false;
  }
  const long long n = static_cast<long long>(rank) + (inserting ? 1 : 0);
  const long long w = static_cast<long long>(a.number);
  if (w < -n || w >= n) {
    ctx.fail("axis " + std::to_string(w) + " does not exist for a " + std::to_string(rank) +
             "-D input - use 0 to " + std::to_string(n - 1) + " (or -1 to -" + std::to_string(n) +
             ")");
    return false;
  }
  out = static_cast<size_t>(w < 0 ? w + n : w);
  return true;
}

// How a row-major Grid walks along one axis: `outer` blocks, each holding
// `len` slices of `inner` consecutive cells.
struct AxisView {
  size_t outer = 1, len = 1, inner = 1;
};

inline AxisView viewOf(const nd::Shape &s, size_t axis) {
  AxisView v;
  v.len = s[axis];
  for (size_t d = 0; d < axis; d++)
    v.outer *= s[d];
  for (size_t d = axis + 1; d < s.size(); d++)
    v.inner *= s[d];
  return v;
}

// Slice k along `axis` (the cells with index k on that axis), row-major.
template <class T> std::vector<T> sliceCells(const GridOf<T> &g, size_t axis, size_t k) {
  const AxisView v = viewOf(g.shape, axis);
  std::vector<T> out;
  out.reserve(v.outer * v.inner);
  for (size_t o = 0; o < v.outer; o++) {
    const size_t start = (o * v.len + k) * v.inner;
    out.insert(out.end(), g.cells.begin() + start, g.cells.begin() + start + v.inner);
  }
  return out;
}

// Every slice along `axis`.
template <class T> std::vector<std::vector<T>> slicesOf(const GridOf<T> &g, size_t axis) {
  std::vector<std::vector<T>> out;
  out.reserve(g.shape[axis]);
  for (size_t k = 0; k < g.shape[axis]; k++)
    out.push_back(sliceCells(g, axis, k));
  return out;
}

// The Grid made of `slices` laid along `axis`; `shape` is the shape of the
// whole (its `axis` entry is replaced by slices.size()).
template <class T>
GridOf<T> fromSlices(nd::Shape shape, size_t axis, const std::vector<std::vector<T>> &slices) {
  shape[axis] = slices.size();
  GridOf<T> g;
  g.shape = shape;
  const AxisView v = viewOf(shape, axis);
  g.cells.reserve(nd::countOf(shape));
  for (size_t o = 0; o < v.outer; o++)
    for (const auto &s : slices)
      g.cells.insert(g.cells.end(), s.begin() + o * v.inner, s.begin() + (o + 1) * v.inner);
  return g;
}

// The grid whose slice k along `axis` is slice from[k] of `g` (2026-11-20):
// reordering, repeating or picking slices without building one vector per
// slice. fromSlices(g.shape, axis, {slicesOf(g, axis)[from[0]], ...}) - the
// same cells.
template <class T>
GridOf<T> gatherAlong(const GridOf<T> &g, size_t axis, const std::vector<size_t> &from) {
  const AxisView v = viewOf(g.shape, axis);
  GridOf<T> out;
  out.shape = g.shape;
  out.shape[axis] = from.size();
  out.cells.reserve(v.outer * from.size() * v.inner);
  for (size_t o = 0; o < v.outer; o++)
    for (size_t k : from) {
      const auto first = g.cells.begin() + static_cast<std::ptrdiff_t>((o * v.len + k) * v.inner);
      out.cells.insert(out.cells.end(), first, first + static_cast<std::ptrdiff_t>(v.inner));
    }
  return out;
}

// The matrix type rules over mixed cells (matUnifyCells).
inline bool unifyCells(std::vector<Value> &cells, CallContext &ctx) {
  std::string err;
  if (!matUnifyCells(cells, err)) {
    ctx.fail(err);
    return false;
  }
  return true;
}

// Every element of a value, row-major, when they are all real numbers
// (plain, bool, int, float32 ...). Complex, text and time values fail.
inline bool realCells(const Grid &g, std::vector<double> &out) {
  out.clear();
  out.reserve(g.count());
  for (const Value &c : g.cells) {
    if (!isPlainNumber(c) || c.isComplex || c.isTime())
      return false;
    out.push_back(c.number);
  }
  return true;
}

/* ---- ordering (unique, sort, ...) ----
   Numbers ascending with every NaN last (NaN counts equal to NaN, as in
   NumPy's unique); integers compared exactly; complex numbers by real part,
   then imaginary part (NumPy's order); text by its bytes (dictionary order
   for ASCII). A matrix holds one kind of element, so mixed kinds only meet
   here by mistake - text then sorts after numbers. */

inline int compareCells(const Value &a, const Value &b) {
  if (a.isText || b.isText) {
    if (a.isText != b.isText)
      return a.isText ? 1 : -1;
    const int c = a.text().compare(b.text());
    return c < 0 ? -1 : (c > 0 ? 1 : 0);
  }
  if (a.isInt() && b.isInt() && a.intIsUnsigned() == b.intIsUnsigned()) {
    if (a.intIsUnsigned()) {
      const uint64_t x = static_cast<uint64_t>(a.intBits()), y = static_cast<uint64_t>(b.intBits());
      return x < y ? -1 : (x > y ? 1 : 0);
    }
    return a.intBits() < b.intBits() ? -1 : (a.intBits() > b.intBits() ? 1 : 0);
  }
  auto cmpReal = [](double x, double y) {
    const bool nx = std::isnan(x), ny = std::isnan(y);
    if (nx || ny)
      return nx == ny ? 0 : (nx ? 1 : -1);
    return x < y ? -1 : (x > y ? 1 : 0);
  };
  const int r = cmpReal(a.number, b.number);
  if (r != 0)
    return r;
  return cmpReal(a.isComplex ? a.imag : 0.0, b.isComplex ? b.imag : 0.0);
}

// compareCells() for two plain numbers: the same order (NaN last, NaN equal
// to NaN).
inline int compareCells(double a, double b) {
  const bool na = std::isnan(a), nb = std::isnan(b);
  if (na || nb)
    return na == nb ? 0 : (na ? 1 : -1);
  return a < b ? -1 : (a > b ? 1 : 0);
}
template <class T> int compareSlices(const std::vector<T> &a, const std::vector<T> &b);

/* ---- functions with several results ----
   [r, c] = nonzero(A): one result per name. With one name the results come
   as a list (P = nonzero(A); P[0], P[1]) - a single result as itself. */

using ResultsFn =
    std::function<bool(const std::vector<Value> &, std::vector<Value> &, CallContext &)>;

inline Impl resultsAsList(ResultsFn fn) {
  return [fn](const std::vector<Value> &args, CallContext &ctx) -> Value {
    std::vector<Value> out;
    if (!fn(args, out, ctx))
      return Value(0.0);
    return out.size() == 1 ? out[0] : Value(std::move(out));
  };
}

inline MultiImpl resultsPerName(ResultsFn fn) {
  return [fn](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
    std::vector<Value> results;
    if (!fn(args, results, ctx))
      return;
    if (nout == 1) {
      out = {results.size() == 1 ? results[0] : Value(std::move(results))};
      return;
    }
    if (nout != results.size()) {
      ctx.fail("it gives " + std::to_string(results.size()) + " results, but " +
               std::to_string(nout) + " names were given");
      return;
    }
    out = std::move(results);
  };
}

// True / false of a mask element: a bool or number (0 = false).
inline bool maskCell(const Value &c, bool &out, CallContext &ctx) {
  if (!isPlainNumber(c) || c.isTime()) {
    ctx.fail("a condition must hold true/false (or numbers, 0 = false)");
    return false;
  }
  out = c.number != 0.0 || (c.isComplex && c.imag != 0.0);
  return true;
}
inline bool maskCell(double c, bool &out, CallContext &) {
  out = c != 0.0;
  return true;
}

// Lexicographic order of two equally long cell lists (rows, slices).
template <class T> int compareSlices(const std::vector<T> &a, const std::vector<T> &b) {
  for (size_t i = 0; i < a.size() && i < b.size(); i++)
    if (const int c = compareCells(a[i], b[i]))
      return c;
  return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
}

} // namespace ndx
} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_ND_H
