#include "numpy_registry.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <unordered_set>

// Defined in builtins/builtins.cpp: true if `name` is in its builtinTable
// (same case-insensitive matching callBuiltin() uses).
bool isCoreBuiltinName(const std::string &name);

namespace nc {
namespace numpy {

namespace {
const SectionInfo kSections[] = {
    {Section::ImportingData, "importing_data", "Importing Data", 29},
    {Section::CreatingArrays, "creating_arrays", "Creating Arrays", 71},
    {Section::InspectingProperties, "inspecting_properties", "Inspecting Properties", 42},
    {Section::CopyingSortingReshaping, "copying_sorting_reshaping", "Copying, Sorting, & Reshaping", 47},
    {Section::AddingRemovingElements, "adding_removing_elements", "Adding & Removing Elements", 20},
    {Section::CombiningSplitting, "combining_splitting", "Combining & Splitting", 17},
    {Section::IndexingSlicing, "indexing_slicing", "Indexing & Slicing", 54},
    {Section::ScalarMath, "scalar_math", "Scalar Math", 38},
    {Section::VectorMath, "vector_math", "Vector Math", 136},
    {Section::Statistics, "statistics", "Statistics", 55},
    {Section::WorkingWithData, "working_with_data", "Working with Data", 73},
};
static_assert(sizeof(kSections) / sizeof(kSections[0]) == static_cast<size_t>(Section::Count),
              "kSections must have one row per Section");

std::string lowered(const std::string &s) {
  std::string out = s;
  for (char &c : out)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return out;
}

// Words the lexer turns into their own tokens (lexer.cpp), block terminators
// and statement words the parser reads as identifiers (parser_program.cpp),
// and call names evaluateExpr() intercepts before callBuiltin() is ever
// reached (parser_factor.cpp). A NumPy function with one of these names
// could never be called.
const std::unordered_set<std::string> &languageReserved() {
  static const std::unordered_set<std::string> words = {
      // lexer keywords
      "true", "false", "print", "publish", "for", "in", "loop", "if", "else", "while",
      "elseif", "is_in", "is_not_in", "break", "continue", "function", "return", "class",
      "private", "protected", "abstract", "require", "ensure", "reversible",
      // block terminators / statement words
      "iend", "fend", "wend", "fnend", "csend", "new", "clear", "cls", "not",
      // calls handled by the parser before callBuiltin()
      "parent", "feval", "grad", "taylor_series", "green_integral", "save_workspace",
      "load_workspace",
      // this framework's own commands
      "numpy_functions", "numpy_status"};
  return words;
}
} // namespace

const SectionInfo &sectionInfo(Section s) { return kSections[static_cast<int>(s)]; }

int plannedTotal() {
  int total = 0;
  for (const auto &info : kSections)
    total += info.plannedEntries;
  return total;
}

std::string reservedReason(const std::string &name) {
  std::string low = lowered(name);
  if (languageReserved().count(low))
    return "is reserved by the NC language";
  // callBuiltin()'s dynamic log family: logb2, logb10, ...
  if (low.size() > 4 && low.rfind("logb", 0) == 0 &&
      low.find_first_not_of("0123456789", 4) == std::string::npos)
    return "belongs to the logbN family (logb2, logb10, ...)";
  if (isCoreBuiltinName(name))
    return "already exists as an NC builtin (ops/) - the existing one is kept";
  return "";
}

void CallContext::fail(const std::string &message) {
  if (ok_) // report only the first problem of a call
    std::cerr << "Error: " << name_ << ": " << message << "\n";
  ok_ = false;
}

Registry &Registry::instance() {
  static Registry registry;
  return registry;
}

bool Registry::add(FunctionSpec spec) {
  const char *folder = sectionInfo(spec.section).folder;
  auto reject = [&](const std::string &why) {
    std::cerr << "numpy [" << folder << "]: '" << spec.name << "' " << why << " - skipped\n";
    skipped_[static_cast<int>(spec.section)]++;
    return false;
  };

  if (spec.name.empty() || !spec.impl)
    return reject("has no name or no implementation");

  std::string why = reservedReason(spec.name);
  if (!why.empty())
    return reject(why);

  if (const FunctionSpec *existing = find(spec.name))
    return reject(std::string("is already registered by ") + sectionInfo(existing->section).folder);

  // Keyed by the lowercased name, so lookup is case-insensitive like
  // callBuiltin() and two spellings of one name count as a duplicate.
  std::string key = lowered(spec.name);
  functions_.emplace(std::move(key), std::move(spec));
  return true;
}

const FunctionSpec *Registry::find(const std::string &name) const {
  auto it = functions_.find(lowered(name));
  return it == functions_.end() ? nullptr : &it->second;
}

size_t Registry::countIn(Section s) const {
  size_t n = 0;
  for (const auto &entry : functions_)
    if (entry.second.section == s)
      n++;
  return n;
}

size_t Registry::skippedIn(Section s) const {
  auto it = skipped_.find(static_cast<int>(s));
  return it == skipped_.end() ? 0 : it->second;
}

std::vector<std::string> Registry::names() const {
  std::vector<std::string> out;
  out.reserve(functions_.size());
  for (const auto &entry : functions_)
    out.push_back(entry.second.name);
  std::sort(out.begin(), out.end());
  return out;
}

std::vector<std::string> Registry::names(Section s) const {
  std::vector<std::string> out;
  for (const auto &entry : functions_)
    if (entry.second.section == s)
      out.push_back(entry.second.name);
  std::sort(out.begin(), out.end());
  return out;
}

} // namespace numpy
} // namespace nc
