#include "numpy_registry.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <string>
#include <unordered_set>

// Defined in builtins/builtins.cpp: true if `name` is in its builtinTable
// (same case-insensitive matching callBuiltin() uses).
bool isCoreBuiltinName(const std::string &name);

namespace nc {
namespace numpy {

namespace {
const SectionInfo kSections[] = {
    {Section::ImportingData, "importing_data", "Importing Data", 168}, // read_/load_/save_ x 56 formats (Functions_Importing_Data.pdf)
    {Section::CreatingArrays, "creating_arrays", "Creating Arrays", 71},
    {Section::InspectingProperties, "inspecting_properties", "Inspecting Properties", 42},
    {Section::CopyingSortingReshaping, "copying_sorting_reshaping", "Copying, Sorting, & Reshaping", 47},
    {Section::AddingRemovingElements, "adding_removing_elements", "Adding & Removing Elements", 20},
    {Section::CombiningSplitting, "combining_splitting", "Combining & Splitting", 17},
    {Section::IndexingSlicing, "indexing_slicing", "Indexing & Slicing", 54},
    {Section::ScalarMath, "scalar_math", "Scalar Math", 38},
    {Section::VectorMath, "vector_math", "Vector Math", 136},
    {Section::Statistics, "statistics", "Statistics", 55},
    {Section::WorkingWithData, "working_with_data", "Working with Data", 73},
};
static_assert(sizeof(kSections) / sizeof(kSections[0]) == static_cast<size_t>(Section::Count),
              "kSections must have one row per Section");

std::string lowered(const std::string &s) {
  std::string out = s;
  for (char &c : out)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return out;
}

// Words the lexer turns into their own tokens (lexer.cpp), block terminators
// and statement words the parser reads as identifiers (parser_program.cpp),
// and call names evaluateExpr() intercepts before callBuiltin() is ever
// reached (parser_factor.cpp). A NumPy function with one of these names
// could never be called.
const std::unordered_set<std::string> &languageReserved() {
  static const std::unordered_set<std::string> words = {
      // lexer keywords
      "true", "false", "print", "publish", "for", "in", "loop", "if", "else", "while",
      "elseif", "is_in", "is_not_in", "break", "continue", "function", "return", "class",
      "private", "protected", "abstract", "require", "ensure", "reversible",
      // block terminators / statement words
      "iend", "fend", "wend", "fnend", "csend", "new", "clear", "cls", "not",
      // calls handled by the parser before callBuiltin()
      "parent", "feval", "grad", "taylor_series", "green_integral", "save_workspace",
      "load_workspace"};
  return words;
}
} // namespace

const SectionInfo &sectionInfo(Section s) { return kSections[static_cast<int>(s)]; }

std::string reservedReason(const std::string &name) {
  std::string low = lowered(name);
  if (languageReserved().count(low))
    return "is reserved by the NC language";
  // callBuiltin()'s dynamic log family: logb2, logb10, ...
  if (low.size() > 4 && low.rfind("logb", 0) == 0 &&
      low.find_first_not_of("0123456789", 4) == std::string::npos)
    return "belongs to the logbN family (logb2, logb10, ...)";
  // expN / logaddexpN families (exp2, exp10, logaddexp2, ...) - resolved by
  // numpy_main.cpp's tryCall(), see familyCall() there.
  for (const char *family : {"exp", "logaddexp"}) {
    const size_t n = std::char_traits<char>::length(family);
    if (low.size() > n && low.rfind(family, 0) == 0 &&
        low.find_first_not_of("0123456789", n) == std::string::npos)
      return std::string("belongs to the ") + family + "N family (" + family + "2, " + family +
             "10, ...)";
  }
  if (isCoreBuiltinName(name))
    return "already exists as an NC builtin (ops/) - the existing one is kept";
  return "";
}

void CallContext::fail(const std::string &message) {
  if (ok_) // report only the first problem of a call
    std::cerr << "Error: " << name_ << ": " << message << "\n";
  ok_ = false;
}

Registry &Registry::instance() {
  static Registry registry;
  return registry;
}

bool Registry::add(FunctionSpec spec) {
  const char *folder = sectionInfo(spec.section).folder;
  auto reject = [&](const std::string &why) {
    std::cerr << "numpy [" << folder << "]: '" << spec.name << "' " << why << " - skipped\n";
    return false;
  };

  if (spec.name.empty() || (!spec.impl && !spec.multiImpl))
    return reject("has no name or no implementation");

  std::string why = reservedReason(spec.name);
  if (!why.empty())
    return reject(why);

  if (const FunctionSpec *existing = find(spec.name))
    return reject(std::string("is already registered by ") + sectionInfo(existing->section).folder);

  // Keyed by the lowercased name, so lookup is case-insensitive like
  // callBuiltin() and two spellings of one name count as a duplicate.
  std::string key = lowered(spec.name);
  functions_.emplace(std::move(key), std::move(spec));
  return true;
}

const FunctionSpec *Registry::find(const std::string &name) const {
  auto it = functions_.find(lowered(name));
  return it == functions_.end() ? nullptr : &it->second;
}

void Registry::setParallel(const std::vector<std::string> &names, ParallelClass cls) {
  for (const std::string &n : names) {
    auto it = functions_.find(lowered(n));
    if (it != functions_.end())
      it->second.par = cls;
  }
}

bool Registry::setParams(const std::string &name, const std::string &paramLine) {
  auto it = functions_.find(lowered(name));
  if (it == functions_.end()) {
    std::cerr << "numpy: parameter table names '" << name << "', which is not registered\n";
    return false;
  }
  FunctionSpec &spec = it->second;
  std::vector<ncargs::ParamSpec> params;
  std::string err;
  if (!ncargs::parseParamList(paramLine, params, err)) {
    std::cerr << "numpy: parameters of '" << spec.name << "': " << err << "\n";
    return false;
  }
  int required = 0;
  for (const auto &p : params)
    required += p.kind == ncargs::ParamKind::Required ? 1 : 0;
  // "*A, axis=0" (core/param_list.h): a variadic function, needing the
  // inputs before *A plus at least one value for it.
  const int vIndex = ncargs::variadicIndex(params);
  const bool fits = vIndex >= 0 ? (spec.maxArgs == kVariadic && spec.minArgs == vIndex + 1)
                                : (spec.maxArgs != kVariadic && required == spec.minArgs &&
                                   static_cast<int>(params.size()) == spec.maxArgs);
  if (!fits) {
    std::cerr << "numpy: parameters of '" << spec.name << "' (\"" << paramLine << "\") do not "
              << "match its " << spec.minArgs << " to " << spec.maxArgs << " argument(s)\n";
    return false;
  }
  // Keep an outputs prefix such as "[q, r] = " from the hand-written usage.
  std::string prefix;
  const size_t eq = spec.signature.find(" = ");
  if (eq != std::string::npos && spec.signature.find('(') > eq)
    prefix = spec.signature.substr(0, eq + 3);
  spec.signature = prefix + ncargs::paramSignature(spec.name, params);
  spec.params = std::move(params);
  return true;
}

} // namespace numpy
} // namespace nc
