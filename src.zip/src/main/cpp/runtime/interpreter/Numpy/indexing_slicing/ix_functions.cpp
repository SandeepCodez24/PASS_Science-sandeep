// Indexing & Slicing.
//
//   take(A, indices[, axis])        elements (or slices) at positions      np.take
//   where(cond, x, y)               x where cond is true, else y           np.where
//   where(cond)                     the positions where cond is true (= nonzero)
//   nonzero(A)                      [r, c] = positions of the non-zero elements, one
//                                   row of indices per axis               np.nonzero
//   choose(idx, c0, c1, ...)        element k from choice idx[k]           np.choose
//   compress(cond, A[, axis])       elements (or slices) where cond is true np.compress
//   extract(cond, A)                elements of A where cond is true, as a row  np.extract
//   diag_indices(n, ndim=2)         [r, c] of the main diagonal of an n x n matrix
//   tril_indices(n, k=0, m?)        [r, c] of the lower triangle (on / below diagonal k)
//   triu_indices(n, k=0, m?)        [r, c] of the upper triangle (on / above diagonal k)
//   mask_indices(n, mask="triu", k=0)   [r, c] of the "triu" or "tril" part  np.mask_indices
//   ravel_index(index, dims)        flat positions of multi-indices       np.ravel_multi_index
//
// Positions are 0-based and flat positions count row by row (NumPy's order).
// A negative position counts from the end. Functions giving positions per
// axis return one 1xk row per axis: [r, c] = nonzero(A) - one name receives
// them all as a list. Index results can go straight back into a matrix:
// A[r[0, i], c[0, i]].
#include "ix_functions.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <string>
#include <vector>

#include "../numpy_nd.h"

namespace nc {
namespace numpy {

namespace {

using ndx::Grid;

// A whole number from a cell (a NumGrid cell: any finite whole double).
bool wholeCell(const Value &c, long long &out) {
  if (!isPlainNumber(c) || c.isComplex || c.isTime() || !std::isfinite(c.number) ||
      c.number != std::floor(c.number))
    return false;
  out = static_cast<long long>(c.number);
  return true;
}
bool wholeCell(double c, long long &out) {
  if (!std::isfinite(c) || c != std::floor(c))
    return false;
  out = static_cast<long long>(c);
  return true;
}

template <class G>
bool wholeCells(const G &g, std::vector<long long> &out, const char *what, CallContext &ctx) {
  out.clear();
  out.reserve(g.count());
  for (const auto &c : g.cells) {
    long long n = 0;
    if (!wholeCell(c, n)) {
      ctx.fail(std::string(what) + " must be whole numbers");
      return false;
    }
    out.push_back(n);
  }
  return true;
}

bool inRange(long long &i, long long n, const std::string &what, CallContext &ctx) {
  if (i < -n || i >= n) {
    ctx.fail("position " + std::to_string(i) + " is outside " + what + " (0.." +
             std::to_string(n - 1) + ")");
    return false;
  }
  if (i < 0)
    i += n;
  return true;
}

Value numberRow(const std::vector<long long> &v) {
  std::vector<double> cells(v.size()); // packed directly (2026-11-20)
  for (size_t k = 0; k < v.size(); k++)
    cells[k] = static_cast<double>(v[k]);
  return ndx::rowOf(cells);
}

// Since 2026-11-20 every function below has one body for cells (Grid) and
// for plain numbers (NumGrid); the NumGrid body runs when every matrix
// argument is a packed unitless float64 value, and gives the same value.

/* ---- take ---- */

template <class G>
Value takeBody(G &a, G &ig, const std::vector<Value> &args, CallContext &ctx) {
  using Cell = typename G::Cell;
  std::vector<long long> idx;
  if (!wholeCells(ig, idx, "indices", ctx))
    return Value(0.0);
  if (args.size() < 3) {
    // Flat positions; the result has the shape of `indices`.
    const long long n = static_cast<long long>(a.count());
    std::vector<Cell> cells;
    cells.reserve(idx.size());
    for (long long i : idx) {
      if (!inRange(i, n, "A's " + std::to_string(n) + " elements", ctx))
        return Value(0.0);
      cells.push_back(a.cells[static_cast<size_t>(i)]);
    }
    const bool single = !args[1].isMatrix && !args[1].isArray;
    if (single)
      return Value(cells[0]);
    return ndx::valueOf(G{ig.shape, cells});
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[2], a.shape.size(), ctx, axis))
    return Value(0.0);
  const size_t len = a.shape[axis];
  std::vector<size_t> from;
  from.reserve(idx.size());
  for (long long i : idx) {
    if (!inRange(i, static_cast<long long>(len), "axis " + std::to_string(axis), ctx))
      return Value(0.0);
    from.push_back(static_cast<size_t>(i));
  }
  return ndx::valueOf(ndx::gatherAlong(a, axis, from));
}

Value take(const std::vector<Value> &args, CallContext &ctx) {
  ndx::NumGrid na, ni;
  if (ndx::argNumGrid(args, 0, na) && ndx::argNumGrid(args, 1, ni))
    return takeBody(na, ni, args, ctx);
  Grid a, ig;
  if (!ndx::argGrid(args, 0, ctx, a) || !ndx::argGrid(args, 1, ctx, ig))
    return Value(0.0);
  return takeBody(a, ig, args, ctx);
}

/* ---- nonzero / where ---- */

template <class G>
bool nonzeroOf(const G &a, std::vector<Value> &out, CallContext &ctx) {
  const size_t rank = a.shape.size();
  std::vector<std::vector<long long>> per(rank);
  std::vector<size_t> idx(rank, 0);
  size_t k = 0;
  if (a.count() > 0)
    do {
      bool on = false;
      if (!ndx::maskCell(a.cells[k++], on, ctx))
        return false;
      if (on)
        for (size_t d = 0; d < rank; d++)
          per[d].push_back(static_cast<long long>(idx[d]));
    } while (nd::nextIndex(idx, a.shape));
  out.clear();
  for (const auto &p : per)
    out.push_back(numberRow(p));
  return true;
}

bool nonzeroResults(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  ndx::NumGrid na;
  if (ndx::argNumGrid(args, 0, na))
    return nonzeroOf(na, out, ctx);
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return false;
  return nonzeroOf(a, out, ctx);
}

template <class G>
Value whereBody(const G &c, const G &x, const G &y, const std::vector<Value> &args,
                CallContext &ctx) {
  using Cell = typename G::Cell;
  // One shape for all three (single values repeat).
  nd::Shape shape{1, 1};
  bool single = true;
  for (const G *g : {&c, &x, &y})
    if (g->count() != 1) {
      if (single) {
        shape = g->shape;
        single = false;
      } else if (g->shape != shape) {
        ctx.fail("cond, x and y must have the same size, or be single values (got " +
                 nd::shapeText(shape) + " and " + nd::shapeText(g->shape) + ")");
        return Value(0.0);
      }
    }
  const size_t n = nd::countOf(shape);
  std::vector<Cell> cells;
  cells.reserve(n);
  for (size_t k = 0; k < n; k++) {
    bool on = false;
    if (!ndx::maskCell(c.cells[c.count() == 1 ? 0 : k], on, ctx))
      return Value(0.0);
    cells.push_back(on ? x.cells[x.count() == 1 ? 0 : k] : y.cells[y.count() == 1 ? 0 : k]);
  }
  if (!ndx::unifyCells(cells, ctx))
    return Value(0.0);
  const bool allSingle = !args[0].isMatrix && !args[0].isArray && !args[1].isMatrix &&
                         !args[1].isArray && !args[2].isMatrix && !args[2].isArray;
  if (allSingle)
    return Value(cells[0]);
  return ndx::valueOf(G{shape, cells});
}

Value whereFn(const std::vector<Value> &args, CallContext &ctx) {
  if (args.size() == 1)
    return ndx::resultsAsList(nonzeroResults)(args, ctx);
  if (args.size() != 3) {
    ctx.fail("give both x and y - where(cond, x, y) - or only cond for the positions");
    return Value(0.0);
  }
  ndx::NumGrid nc, nx, ny; // cond may be a bool tensor (used only as true / false)
  if (ndx::condGridOf(args[0], nc) && ndx::valuesGridOf(args[1], nx) && ndx::valuesGridOf(args[2], ny))
    return whereBody(nc, nx, ny, args, ctx);
  Grid c, x, y;
  if (!ndx::argGrid(args, 0, ctx, c) || !ndx::argGrid(args, 1, ctx, x) ||
      !ndx::argGrid(args, 2, ctx, y))
    return Value(0.0);
  return whereBody(c, x, y, args, ctx);
}

/* ---- choose / compress / extract ---- */

template <class G>
Value chooseBody(const G &ig, const std::vector<G> &choices, const std::vector<Value> &args,
                 CallContext &ctx) {
  using Cell = typename G::Cell;
  std::vector<long long> idx;
  if (!wholeCells(ig, idx, "the choice numbers", ctx))
    return Value(0.0);
  for (size_t i = 0; i < choices.size(); i++) {
    const G &g = choices[i];
    if (g.count() != 1 && g.shape != ig.shape) {
      ctx.fail("choice " + std::to_string(i) + " must be a single value or have the size of "
               "idx (" + nd::shapeText(ig.shape) + "), got " + nd::shapeText(g.shape));
      return Value(0.0);
    }
  }
  std::vector<Cell> cells;
  cells.reserve(idx.size());
  for (size_t k = 0; k < idx.size(); k++) {
    long long c = idx[k];
    if (c < 0 || c >= static_cast<long long>(choices.size())) {
      ctx.fail("choice number " + std::to_string(c) + " does not exist - there are " +
               std::to_string(choices.size()) + " choices (0.." +
               std::to_string(choices.size() - 1) + ")");
      return Value(0.0);
    }
    const G &g = choices[static_cast<size_t>(c)];
    cells.push_back(g.cells[g.count() == 1 ? 0 : k]);
  }
  if (!ndx::unifyCells(cells, ctx))
    return Value(0.0);
  if (!args[0].isMatrix && !args[0].isArray)
    return Value(cells[0]);
  return ndx::valueOf(G{ig.shape, cells});
}

Value choose(const std::vector<Value> &args, CallContext &ctx) {
  // Numbers only when idx and every choice are plain float64.
  {
    ndx::NumGrid ni;
    std::vector<ndx::NumGrid> nchoices(args.size() > 0 ? args.size() - 1 : 0);
    bool numbers = ndx::argNumGrid(args, 0, ni);
    for (size_t i = 1; numbers && i < args.size(); i++)
      numbers = ndx::valuesGridOf(args[i], nchoices[i - 1]);
    if (numbers)
      return chooseBody(ni, nchoices, args, ctx);
  }
  // Cells. The old order of checks: idx read and checked, then each choice
  // read and its size checked, one after the other.
  Grid ig;
  if (!ndx::argGrid(args, 0, ctx, ig))
    return Value(0.0);
  std::vector<long long> idx;
  if (!wholeCells(ig, idx, "the choice numbers", ctx))
    return Value(0.0);
  std::vector<Grid> choices;
  for (size_t i = 1; i < args.size(); i++) {
    Grid g;
    if (!ndx::argGrid(args, i, ctx, g))
      return Value(0.0);
    if (g.count() != 1 && g.shape != ig.shape) {
      ctx.fail("choice " + std::to_string(i - 1) + " must be a single value or have the size of "
               "idx (" + nd::shapeText(ig.shape) + "), got " + nd::shapeText(g.shape));
      return Value(0.0);
    }
    choices.push_back(std::move(g));
  }
  return chooseBody(ig, choices, args, ctx);
}

template <class G> bool maskOf(const G &g, std::vector<bool> &out, CallContext &ctx) {
  out.clear();
  out.reserve(g.count());
  for (const auto &c : g.cells) {
    bool on = false;
    if (!ndx::maskCell(c, on, ctx))
      return false;
    out.push_back(on);
  }
  return true;
}

template <class G>
Value compressBody(const G &cg, const G &a, const std::vector<Value> &args, CallContext &ctx) {
  using Cell = typename G::Cell;
  std::vector<bool> keep;
  if (!maskOf(cg, keep, ctx))
    return Value(0.0);
  if (args.size() < 3) {
    if (keep.size() > a.count()) {
      ctx.fail("cond has " + std::to_string(keep.size()) + " entries but A only " +
               std::to_string(a.count()) + " elements");
      return Value(0.0);
    }
    std::vector<Cell> out;
    for (size_t k = 0; k < keep.size(); k++) // past the end of cond: not kept
      if (keep[k])
        out.push_back(a.cells[k]);
    return ndx::rowOf(out);
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[2], a.shape.size(), ctx, axis))
    return Value(0.0);
  const size_t len = a.shape[axis];
  if (keep.size() > len) {
    ctx.fail("cond has " + std::to_string(keep.size()) + " entries but A has only " +
             std::to_string(len) + " along axis " + std::to_string(axis));
    return Value(0.0);
  }
  std::vector<size_t> from;
  for (size_t k = 0; k < keep.size(); k++)
    if (keep[k])
      from.push_back(k);
  return ndx::valueOf(ndx::gatherAlong(a, axis, from));
}

Value compress(const std::vector<Value> &args, CallContext &ctx) {
  ndx::NumGrid nc, na; // cond may be a bool tensor (used only as true / false)
  if (ndx::condGridOf(args[0], nc) && ndx::argNumGrid(args, 1, na))
    return compressBody(nc, na, args, ctx);
  Grid cg, a;
  if (!ndx::argGrid(args, 0, ctx, cg) || !ndx::argGrid(args, 1, ctx, a))
    return Value(0.0);
  return compressBody(cg, a, args, ctx);
}

template <class G> Value extractBody(const G &cg, const G &a, CallContext &ctx) {
  using Cell = typename G::Cell;
  if (cg.count() != a.count()) {
    ctx.fail("cond must have as many elements as A (cond is " + nd::shapeText(cg.shape) +
             ", A is " + nd::shapeText(a.shape) + ")");
    return Value(0.0);
  }
  std::vector<bool> keep;
  if (!maskOf(cg, keep, ctx))
    return Value(0.0);
  std::vector<Cell> out;
  for (size_t k = 0; k < keep.size(); k++)
    if (keep[k])
      out.push_back(a.cells[k]);
  return ndx::rowOf(out);
}

Value extract(const std::vector<Value> &args, CallContext &ctx) {
  ndx::NumGrid nc, na; // cond may be a bool tensor (used only as true / false)
  if (ndx::condGridOf(args[0], nc) && ndx::argNumGrid(args, 1, na))
    return extractBody(nc, na, ctx);
  Grid cg, a;
  if (!ndx::argGrid(args, 0, ctx, cg) || !ndx::argGrid(args, 1, ctx, a))
    return Value(0.0);
  return extractBody(cg, a, ctx);
}

/* ---- index sets ---- */

bool diagIndices(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  long long n = 0, ndim = 0;
  if (!argNonNegativeInt(args, 0, ctx, n) || !argNonNegativeInt(args, 1, ctx, ndim))
    return false;
  if (ndim < 1) {
    ctx.fail("ndim must be at least 1");
    return false;
  }
  std::vector<long long> d;
  for (long long i = 0; i < n; i++)
    d.push_back(i);
  out.assign(static_cast<size_t>(ndim), numberRow(d));
  return true;
}

// [r, c] of the part of an n x m matrix with c - r >= k (upper) or <= k (lower).
bool triangle(long long n, long long k, long long m, bool upper, std::vector<Value> &out) {
  std::vector<long long> r, c;
  for (long long i = 0; i < n; i++)
    for (long long j = 0; j < m; j++)
      if (upper ? j - i >= k : j - i <= k) {
        r.push_back(i);
        c.push_back(j);
      }
  out = {numberRow(r), numberRow(c)};
  return true;
}

ndx::ResultsFn triangleFn(bool upper) {
  return [upper](const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
    long long n = 0, k = 0, m = 0;
    if (!argNonNegativeInt(args, 0, ctx, n) || !argInt(args, 1, ctx, k))
      return false;
    m = n;
    if (args.size() > 2 && !argNonNegativeInt(args, 2, ctx, m))
      return false;
    return triangle(n, k, m, upper, out);
  };
}

bool maskIndices(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  long long n = 0, k = 0;
  std::string mask;
  if (!argNonNegativeInt(args, 0, ctx, n) || !argText(args, 1, ctx, mask) ||
      !argInt(args, 2, ctx, k))
    return false;
  for (char &ch : mask)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  if (mask != "triu" && mask != "tril") {
    ctx.fail("mask must be \"triu\" (upper part) or \"tril\" (lower part)");
    return false;
  }
  return triangle(n, k, n, mask == "triu", out);
}

Value ravelIndex(const std::vector<Value> &args, CallContext &ctx) {
  Grid ig, dg;
  if (!ndx::argGrid(args, 0, ctx, ig) || !ndx::argGrid(args, 1, ctx, dg))
    return Value(0.0);
  std::vector<long long> idx, dims;
  if (!wholeCells(ig, idx, "the index", ctx) || !wholeCells(dg, dims, "dims", ctx))
    return Value(0.0);
  const size_t k = dims.size();
  for (long long d : dims)
    if (d < 1) {
      ctx.fail("every size in dims must be at least 1");
      return Value(0.0);
    }
  // One row per axis ([rows; cols] for points of a matrix), or one point
  // written as a single vector [r, c].
  size_t points = 0;
  bool onePoint = false;
  if (ig.shape.size() == 2 && ig.shape[0] == k) {
    points = ig.shape[1];
  } else if (ig.count() == k) {
    points = 1;
    onePoint = true;
  } else {
    ctx.fail("the index needs one row per axis of dims (" + std::to_string(k) +
             " rows), e.g. ravel_index([0, 1; 2, 3], [3, 4]) - got " + nd::shapeText(ig.shape));
    return Value(0.0);
  }
  std::vector<long long> flat;
  for (size_t p = 0; p < points; p++) {
    long long f = 0;
    for (size_t a = 0; a < k; a++) {
      const long long i = onePoint ? idx[a] : idx[a * points + p];
      if (i < 0 || i >= dims[a]) {
        ctx.fail("index " + std::to_string(i) + " is outside axis " + std::to_string(a) +
                 " (0.." + std::to_string(dims[a] - 1) + ")");
        return Value(0.0);
      }
      f = f * dims[a] + i;
    }
    flat.push_back(f);
  }
  if (onePoint)
    return Value(static_cast<double>(flat[0]));
  return numberRow(flat);
}

void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
         const char *numpyName, Impl impl) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::IndexingSlicing;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = true;
  reg.add(std::move(spec));
}

void addResults(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
                const char *numpyName, ndx::ResultsFn fn) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::IndexingSlicing;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = ndx::resultsAsList(fn);
  spec.multiImpl = ndx::resultsPerName(fn);
  spec.maxOutputs = 32;
  spec.acceptsComplex = true;
  reg.add(std::move(spec));
}

} // namespace

void registerIndexingFunctions(Registry &reg) {
  add(reg, "take", 2, 3, "elements or slices at positions", "np.take", take);
  add(reg, "where", 1, 3, "x where cond, else y", "np.where", whereFn);
  addResults(reg, "nonzero", 1, 1, "positions of the non-zero elements", "np.nonzero",
             nonzeroResults);
  {
    FunctionSpec spec;
    spec.name = "choose";
    spec.section = Section::IndexingSlicing;
    spec.minArgs = 2;
    spec.maxArgs = kVariadic;
    spec.signature = "choose(idx, c1, c2, ...)";
    spec.summary = "element k from choice idx[k]";
    spec.numpyName = "np.choose";
    spec.impl = choose;
    spec.acceptsComplex = true;
    reg.add(std::move(spec));
  }
  add(reg, "compress", 2, 3, "elements or slices where cond", "np.compress", compress);
  add(reg, "extract", 2, 2, "elements where cond, as a row", "np.extract", extract);
  addResults(reg, "diag_indices", 1, 2, "indices of the main diagonal", "np.diag_indices",
             diagIndices);
  addResults(reg, "tril_indices", 1, 3, "indices of the lower triangle", "np.tril_indices",
             triangleFn(false));
  addResults(reg, "triu_indices", 1, 3, "indices of the upper triangle", "np.triu_indices",
             triangleFn(true));
  addResults(reg, "mask_indices", 1, 3, "indices of the triu / tril part", "np.mask_indices",
             maskIndices);
  add(reg, "ravel_index", 2, 2, "flat positions of multi-indices", "np.ravel_multi_index",
      ravelIndex);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"take", "A, indices, axis?"},
      {"where", "cond, x?, y?"},
      {"nonzero", "A"},
      {"choose", "idx, *c"},
      {"compress", "cond, A, axis?"},
      {"extract", "cond, A"},
      {"diag_indices", "n, ndim=2"},
      {"tril_indices", "n, k=0, m?"},
      {"triu_indices", "n, k=0, m?"},
      {"mask_indices", "n, mask=\"triu\", k=0"},
      {"ravel_index", "index, dims"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
