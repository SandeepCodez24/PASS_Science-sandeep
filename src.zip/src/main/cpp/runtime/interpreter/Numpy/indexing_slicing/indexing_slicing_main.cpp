// Section 7 of 11 - Indexing & Slicing
// Planned entries: 54  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. Nothing outside this folder needs to change when you add one.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        indexing_slicing/is_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerIndexingSlicing() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("indexing_slicing")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "indexing_slicing_main.h"

#include "../numpy_common.h"

namespace nc {
namespace numpy {

void registerIndexingSlicing(Registry &reg) {
  (void)reg; // remove once the first function is registered

  // ---- example (copy, rename, then delete this comment block) -------------
  //
  // reg.add({
  //     "example_fill",                     // NC name
  //     Section::IndexingSlicing,
  //     2, 2,                               // min / max argument count
  //     "example_fill(n, value)",           // usage shown in errors
  //     "array of n copies of value",       // one-line summary
  //     "np.full",                          // NumPy original
  //     [](const std::vector<Value> &args, CallContext &ctx) -> Value {
  //       long long n = 0;
  //       double value = 0.0;
  //       if (!argNonNegativeInt(args, 0, ctx, n) || !argNumber(args, 1, ctx, value))
  //         return Value(0.0);
  //       return makeArray(std::vector<double>(static_cast<size_t>(n), value));
  //     },
  // });
}

} // namespace numpy
} // namespace nc
