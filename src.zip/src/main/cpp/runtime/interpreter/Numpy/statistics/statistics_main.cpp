// Section 10 of 11 - Statistics
// Planned entries: 55
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   st_reduce.cpp     average prod argmin argmax count_nonzero all any cumsum
//                     cumprod cumulative_sum cumulative_prod nan_mean nan_median
//                     nan_sum nan_prod nan_min nan_max nan_argmin nan_argmax
//                     nan_var nan_sd nan_percentile nan_quantile nan_cumsum
//                     nan_cumprod
//   st_hist.cpp       histogram bin_edges histogram2d histogramdd bincount digitize
//   st_calculus.cpp   correlate gradient trapz interp
//   st_common.h       shared readers (axis="all"), reduce / map helpers
//
// Reductions take axis="all" (every element, the default) or an axis number;
// along an axis the axis goes away, as in max(A, axis=k). Dropped by the
// team (2026-10-28): diff.
//
// How to add a function
//   1. Put it in the group file it belongs to (or a new st_<group>.cpp with a
//      register<Group>(Registry&) declared in st_common.h and called below).
//   2. Register it with addFn(...) / addResults(...) (st_common.h) and give it
//      a parameter line.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup.
#include "statistics_main.h"

#include "st_common.h"

namespace nc {
namespace numpy {

void registerStatistics(Registry &reg) {
  st::registerReductions(reg);
  st::registerHistograms(reg);
  st::registerCalculus(reg);
}

} // namespace numpy
} // namespace nc
