// NumPy-equivalent function registry.
//
// Every NumPy-style function in NC is one FunctionSpec stored here, keyed by
// its NC name. Each of the 11 section folders adds its own entries from its
// register<Section>() function (<section>/<section>_main.cpp), and
// numpy_main.cpp calls all 11 of those once, at first use.
//
// Lookup happens at RUN time, by name, from callBuiltin() - so adding a
// function needs no lexer or parser change: `zeros(3)` is already parsed as
// an ordinary ExprKind::Call node, and both the tree-walker
// (evaluateExpr -> callBuiltin) and the JIT (nc_bridge_call_dynamic ->
// callBuiltin) reach this registry through the same path.
#ifndef NC_NUMPY_REGISTRY_H
#define NC_NUMPY_REGISTRY_H

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "../core/value.h"

namespace nc {
namespace numpy {

// The 11 sections from the NumPy literature survey. Order and planned counts
// match the survey table (582 entries in total).
enum class Section {
  ImportingData = 0,
  CreatingArrays,
  InspectingProperties,
  CopyingSortingReshaping,
  AddingRemovingElements,
  CombiningSplitting,
  IndexingSlicing,
  ScalarMath,
  VectorMath,
  Statistics,
  WorkingWithData,
  Count // not a section - the number of sections
};

struct SectionInfo {
  Section section;
  const char *folder;  // folder name under Numpy/
  const char *title;   // human-readable title from the survey
  int plannedEntries;  // entry count from the survey
};

// Table of all 11 sections, indexed by static_cast<int>(Section).
const SectionInfo &sectionInfo(Section s);
int plannedTotal();

// Passed to every implementation. Report a problem with fail(): it prints one
// "Error: <function>: <message>" line to stderr and marks the call failed, so
// the statement stops exactly like any other NC runtime error (no assignment,
// no echo). Return any Value after calling fail() - it is discarded.
class CallContext {
public:
  explicit CallContext(const std::string &functionName) : name_(functionName) {}

  void fail(const std::string &message);
  // Marks the call failed WITHOUT printing - for when a shared routine
  // (power(), mapElementwise(), ...) has already printed its own error and
  // reported it through g_lastElementwiseOk.
  void markFailed() { ok_ = false; }
  bool ok() const { return ok_; }
  const std::string &functionName() const { return name_; }

private:
  const std::string &name_;
  bool ok_ = true;
};

using Impl = std::function<Value(const std::vector<Value> &args, CallContext &ctx)>;

constexpr int kVariadic = -1; // maxArgs value meaning "no upper limit"

struct FunctionSpec {
  std::string name;       // NC name - lookup is case-insensitive, like builtins
  Section section;        // which folder owns it
  int minArgs = 0;        // checked by the dispatcher before impl runs
  int maxArgs = 0;        // kVariadic for no upper limit
  std::string signature;  // shown in errors/help, e.g. "zeros(n[, m])"
  std::string summary;    // one line, e.g. "array of zeros"
  std::string numpyName;  // the NumPy original, e.g. "np.zeros" (traceability)
  Impl impl;
  // Complex arguments are refused before impl runs unless this is true -
  // same rule callBuiltin() applies to the existing ops/ builtins.
  bool acceptsComplex = false;
};

// Names a NumPy function may NOT use, and why (empty string = allowed):
//   - an existing NC builtin from ops/ (sum, mean, sin, det, ...): the
//     existing one is kept and the NumPy entry is skipped (team decision)
//   - an NC keyword (if, for, print, ...) - it never reaches a call
//   - a call the parser intercepts first (feval, grad, parent, ...)
//   - the framework's own numpy_functions / numpy_status
std::string reservedReason(const std::string &name);

class Registry {
public:
  static Registry &instance();

  // Returns false (and prints why) if the name is reserved (see
  // reservedReason) or already registered - the first registration wins, so
  // two sections can never silently overwrite each other's function.
  bool add(FunctionSpec spec);

  // Case-insensitive, like callBuiltin().
  const FunctionSpec *find(const std::string &name) const;
  bool contains(const std::string &name) const { return find(name) != nullptr; }

  size_t size() const { return functions_.size(); }
  size_t countIn(Section s) const;
  size_t skippedIn(Section s) const;

  // All registered names, sorted; optionally only one section.
  std::vector<std::string> names() const;
  std::vector<std::string> names(Section s) const;

private:
  Registry() = default;
  std::unordered_map<std::string, FunctionSpec> functions_; // key: lowercased name
  std::unordered_map<int, size_t> skipped_; // per section: rejected add() calls
};

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_REGISTRY_H
