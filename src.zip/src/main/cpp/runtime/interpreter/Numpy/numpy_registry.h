// NumPy-equivalent function registry.
//
// Every NumPy-style function in NC is one FunctionSpec stored here, keyed by
// its NC name. Each of the 11 section folders adds its own entries from its
// register<Section>() function (<section>/<section>_main.cpp), and
// numpy_main.cpp calls all 11 of those once, at first use.
//
// Lookup happens at RUN time, by name, from callBuiltin() - so adding a
// function needs no lexer or parser change: `zeros(3)` is already parsed as
// an ordinary ExprKind::Call node, and both the tree-walker
// (evaluateExpr -> callBuiltin) and the JIT (nc_bridge_call_dynamic ->
// callBuiltin) reach this registry through the same path.
#ifndef NC_NUMPY_REGISTRY_H
#define NC_NUMPY_REGISTRY_H

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "../core/param_list.h"
#include "../core/value.h"

namespace nc {
namespace numpy {

// The 11 sections from the NumPy literature survey. Order and planned counts
// match the survey table (721 entries in total; importing_data follows Functions_Importing_Data.pdf).
enum class Section {
  ImportingData = 0,
  CreatingArrays,
  InspectingProperties,
  CopyingSortingReshaping,
  AddingRemovingElements,
  CombiningSplitting,
  IndexingSlicing,
  ScalarMath,
  VectorMath,
  Statistics,
  WorkingWithData,
  Count // not a section - the number of sections
};

struct SectionInfo {
  Section section;
  const char *folder;  // folder name under Numpy/
  const char *title;   // human-readable title from the survey
  int plannedEntries;  // entry count from the survey
};

// Table of all 11 sections, indexed by static_cast<int>(Section).
const SectionInfo &sectionInfo(Section s);

// Passed to every implementation. Report a problem with fail(): it prints one
// "Error: <function>: <message>" line to stderr and marks the call failed, so
// the statement stops exactly like any other NC runtime error (no assignment,
// no echo). Return any Value after calling fail() - it is discarded.
class CallContext {
public:
  explicit CallContext(const std::string &functionName) : name_(functionName) {}

  void fail(const std::string &message);
  // Marks the call failed WITHOUT printing - for when a shared routine
  // (power(), mapElementwise(), ...) has already printed its own error and
  // reported it through g_lastElementwiseOk.
  void markFailed() { ok_ = false; }
  bool ok() const { return ok_; }
  const std::string &functionName() const { return name_; }

private:
  const std::string &name_;
  bool ok_ = true;
};

using Impl = std::function<Value(const std::vector<Value> &args, CallContext &ctx)>;

// A function with several results, called as [Q, R] = qr(A) (or
// (Q, R) = qr(A)): fills `out` with exactly `nout` values (1 <= nout <=
// maxOutputs). Report problems through ctx.fail() like any Impl.
using MultiImpl = std::function<void(const std::vector<Value> &args, size_t nout,
                                     std::vector<Value> &out, CallContext &ctx)>;

constexpr int kVariadic = -1; // maxArgs value meaning "no upper limit"

// How a function may use threads (docs/Multicore_Multithread_Architecture.md,
// section 5) - the same three classes as the SciPy registry. Today it is a
// record for reviewers and tools: a function listed as Kernel has its hot
// loops in nc::par (core/elementwise.h, statistics.cpp, ...); everything
// else is Serial unless setParallel() says otherwise.
enum class ParallelClass {
  Serial,     // never uses threads itself (the default)
  Kernel,     // its kernels go through nc::par
  Interpreter // calls back into NC code, so every callback stays on one thread
};

struct FunctionSpec {
  std::string name;       // NC name - lookup is case-insensitive, like builtins
  Section section;        // which folder owns it
  int minArgs = 0;        // checked by the dispatcher before impl runs
  int maxArgs = 0;        // kVariadic for no upper limit
  std::string signature;  // shown in errors/help, e.g. "zeros(n[, m])"
  std::string summary;    // one line, e.g. "array of zeros"
  std::string numpyName;  // the NumPy original, e.g. "np.zeros" (traceability)
  Impl impl;
  // Complex arguments are refused before impl runs unless this is true -
  // same rule callBuiltin() applies to the existing ops/ builtins.
  bool acceptsComplex = false;
  // Multi-output functions only (see MultiImpl). When `impl` is empty, a
  // plain call `x = f(...)` runs multiImpl with nout = 1.
  MultiImpl multiImpl = {};
  int maxOutputs = 1;
  // The inputs, by name, from the section's parameter table (see
  // Registry::setParams). Empty = values in order only: a call that names
  // a value is refused. When set, every call - named or not - is first
  // rewritten by ncargs::normalizeCall(), so impl always gets the inputs in
  // declaration order with defaults filled in; the defaults live only in
  // the parameter line.
  std::vector<ncargs::ParamSpec> params = {}; // "= {}": aggregate inits that stop earlier stay warning-free
  ParallelClass par = ParallelClass::Serial;
};

// Names a NumPy function may NOT use, and why (empty string = allowed):
//   - an existing NC builtin from ops/ (sum, mean, sin, det, ...): the
//     existing one is kept and the NumPy entry is skipped (team decision)
//   - an NC keyword (if, for, print, ...) - it never reaches a call
//   - a call the parser intercepts first (feval, grad, parent, ...)
std::string reservedReason(const std::string &name);

class Registry {
public:
  static Registry &instance();

  // Returns false (and prints why) if the name is reserved (see
  // reservedReason) or already registered - the first registration wins, so
  // two sections can never silently overwrite each other's function.
  bool add(FunctionSpec spec);

  // Case-insensitive, like callBuiltin().
  const FunctionSpec *find(const std::string &name) const;

  // Gives a registered function its inputs by name, from one parameter line
  // (core/param_list.h): "A, B, atol=0.1, rtol=0". The line must agree with
  // the function's minArgs / maxArgs (inputs without a default = minArgs,
  // all inputs = maxArgs); the usage text is rebuilt from it, keeping a
  // "[q, r] = " outputs prefix. Prints why and returns false otherwise, so a
  // wrong table line shows up at start-up.
  bool setParams(const std::string &name, const std::string &paramLine);
  bool contains(const std::string &name) const { return find(name) != nullptr; }

  // Sets the threading class of functions already added; unknown names are
  // ignored (same as the SciPy registry's setParallel).
  void setParallel(const std::vector<std::string> &names, ParallelClass cls);

  size_t size() const { return functions_.size(); }

private:
  Registry() = default;
  std::unordered_map<std::string, FunctionSpec> functions_; // key: lowercased name
};

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_REGISTRY_H
