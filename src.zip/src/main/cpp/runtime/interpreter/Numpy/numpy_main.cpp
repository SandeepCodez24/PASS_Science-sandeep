// Wires the 11 section folders into one registry and dispatches calls.
//
// Adding a function never touches this file - it goes in its section's
// <section>_main.cpp. This file changes only if a whole new section is added.
#include "numpy_main.h"

#include <exception>
#include <cctype>
#include <iomanip>
#include <iostream>
#include <mutex>

#include "numpy_registry.h"

#include "importing_data/importing_data_main.h"
#include "creating_arrays/creating_arrays_main.h"
#include "inspecting_properties/inspecting_properties_main.h"
#include "copying_sorting_reshaping/copying_sorting_reshaping_main.h"
#include "adding_removing_elements/adding_removing_elements_main.h"
#include "combining_splitting/combining_splitting_main.h"
#include "indexing_slicing/indexing_slicing_main.h"
#include "scalar_math/scalar_math_main.h"
#include "vector_math/vector_math_main.h"
#include "statistics/statistics_main.h"
#include "working_with_data/working_with_data_main.h"

namespace nc {
namespace numpy {

namespace {

// Two framework commands, not part of the 582: they let the team (and the
// IDE) see what is wired up.
//   numpy_functions()               -> array of every registered name
//   numpy_functions("vector_math")  -> names in one section
//   numpy_status()                  -> prints done / skipped / planned per section
const char *kListFn = "numpy_functions";
const char *kStatusFn = "numpy_status";

bool sectionByFolder(const std::string &folder, Section &out) {
  for (int i = 0; i < static_cast<int>(Section::Count); i++) {
    Section s = static_cast<Section>(i);
    if (folder == sectionInfo(s).folder) {
      out = s;
      return true;
    }
  }
  return false;
}

std::string argCountText(int minArgs, int maxArgs) {
  if (maxArgs == kVariadic)
    return "at least " + std::to_string(minArgs);
  if (minArgs == maxArgs)
    return std::to_string(minArgs);
  return std::to_string(minArgs) + " to " + std::to_string(maxArgs);
}

Value listFunctions(const std::vector<Value> &args, bool &ok) {
  const Registry &reg = Registry::instance();
  std::vector<std::string> names;
  if (args.empty()) {
    names = reg.names();
  } else if (args.size() == 1 && args[0].isText) {
    Section s;
    if (!sectionByFolder(args[0].text(), s)) {
      std::cerr << "Error: " << kListFn << ": unknown section '" << args[0].text()
                << "' - use a folder name such as \"vector_math\"\n";
      ok = false;
      return Value(0.0);
    }
    names = reg.names(s);
  } else {
    std::cerr << "Error: " << kListFn << " expects no arguments or one section name in quotes\n";
    ok = false;
    return Value(0.0);
  }
  std::vector<Value> out;
  out.reserve(names.size());
  for (const auto &n : names)
    out.push_back(Value(n));
  return Value(out);
}

Value printStatus(const std::vector<Value> &args, bool &ok) {
  if (!args.empty()) {
    std::cerr << "Error: " << kStatusFn << " takes no arguments\n";
    ok = false;
    return Value(0.0);
  }
  const Registry &reg = Registry::instance();
  size_t skippedTotal = 0;
  std::cout << std::left << std::setw(4) << "#" << std::setw(28) << "section" << std::right
            << std::setw(6) << "done" << std::setw(9) << "skipped" << std::setw(9) << "planned"
            << "\n";
  for (int i = 0; i < static_cast<int>(Section::Count); i++) {
    const SectionInfo &info = sectionInfo(static_cast<Section>(i));
    skippedTotal += reg.skippedIn(info.section);
    std::cout << std::left << std::setw(4) << (i + 1) << std::setw(28) << info.folder
              << std::right << std::setw(6) << reg.countIn(info.section) << std::setw(9)
              << reg.skippedIn(info.section) << std::setw(9) << info.plannedEntries << "\n";
  }
  std::cout << std::left << std::setw(32) << "    total" << std::right << std::setw(6)
            << reg.size() << std::setw(9) << skippedTotal << std::setw(9) << plannedTotal()
            << std::endl;
  return Value(static_cast<double>(reg.size()));
}

} // namespace

void initialize() {
  static std::once_flag once;
  std::call_once(once, [] {
    Registry &reg = Registry::instance();
    registerImportingData(reg);
    registerCreatingArrays(reg);
    registerInspectingProperties(reg);
    registerCopyingSortingReshaping(reg);
    registerAddingRemovingElements(reg);
    registerCombiningSplitting(reg);
    registerIndexingSlicing(reg);
    registerScalarMath(reg);
    registerVectorMath(reg);
    registerStatistics(reg);
    registerWorkingWithData(reg);
  });
}

// The expN / logaddexpN name families (exp2, exp10, logaddexp2, ...) are
// not registry entries - any digits are accepted - so they are matched here
// after the registry (vector_math/vm_ufuncs.cpp implements them).
bool isFamilyName(const std::string &name) {
  std::string low = name;
  for (char &c : low)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  for (const char *family : {"logaddexp", "exp"}) {
    const size_t n = std::char_traits<char>::length(family);
    if (low.size() > n && low.rfind(family, 0) == 0 &&
        low.find_first_not_of("0123456789", n) == std::string::npos)
      return true;
  }
  return false;
}

bool isNumpyFunction(const std::string &name) {
  initialize();
  return name == kListFn || name == kStatusFn || Registry::instance().contains(name) ||
         isFamilyName(name);
}

bool tryCall(const std::string &name, const std::vector<Value> &args, Value &out, bool &ok) {
  initialize();

  if (name == kListFn) {
    ok = true;
    out = listFunctions(args, ok);
    return true;
  }
  if (name == kStatusFn) {
    ok = true;
    out = printStatus(args, ok);
    return true;
  }

  const FunctionSpec *spec = Registry::instance().find(name);
  if (!spec) {
    if (!isFamilyName(name))
      return false;
    ok = true;
    CallContext ctx(name);
    bool matched = false;
    try {
      out = callVectorMathFamily(name, args, ctx, matched);
    } catch (const std::exception &e) {
      ctx.fail(std::string("internal error: ") + e.what());
    }
    if (!matched)
      return false;
    ok = ctx.ok();
    if (!ok)
      out = Value(0.0);
    return true;
  }

  ok = true;
  out = Value(0.0);

  int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kVariadic && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects "
              << argCountText(spec->minArgs, spec->maxArgs) << " argument(s), got " << argc;
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }

  if (!spec->acceptsComplex) {
    for (const Value &a : args) {
      if (a.hasComplex()) {
        std::cerr << "Error: '" << spec->name << "' does not support complex numbers yet\n";
        ok = false;
        return true;
      }
    }
  }

  CallContext ctx(spec->name);
  Value result;
  try {
    if (spec->impl) {
      result = spec->impl(args, ctx);
    } else {
      std::vector<Value> outs;
      spec->multiImpl(args, 1, outs, ctx);
      if (ctx.ok() && !outs.empty())
        result = outs[0];
    }
  } catch (const std::exception &e) {
    ctx.fail(std::string("internal error: ") + e.what());
  } catch (...) {
    ctx.fail("internal error");
  }

  if (!ctx.ok()) {
    ok = false;
    return true;
  }
  out = std::move(result);
  return true;
}

bool tryCallMulti(const std::string &name, const std::vector<Value> &args, size_t nout,
                  std::vector<Value> &out, bool &ok) {
  initialize();
  const FunctionSpec *spec = Registry::instance().find(name);
  if (!spec || !spec->multiImpl)
    return false;

  ok = true;
  out.clear();
  int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kVariadic && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects "
              << argCountText(spec->minArgs, spec->maxArgs) << " argument(s), got " << argc;
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }
  if (nout < 1 || nout > static_cast<size_t>(spec->maxOutputs)) {
    std::cerr << "Error: " << spec->name << " returns at most " << spec->maxOutputs
              << " value(s), but " << nout << " names were given";
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }
  if (!spec->acceptsComplex) {
    for (const Value &a : args) {
      if (a.hasComplex()) {
        std::cerr << "Error: '" << spec->name << "' does not support complex numbers yet\n";
        ok = false;
        return true;
      }
    }
  }

  CallContext ctx(spec->name);
  try {
    spec->multiImpl(args, nout, out, ctx);
  } catch (const std::exception &e) {
    ctx.fail(std::string("internal error: ") + e.what());
  } catch (...) {
    ctx.fail("internal error");
  }
  ok = ctx.ok() && out.size() == nout;
  if (ctx.ok() && out.size() != nout) {
    std::cerr << "Error: " << spec->name << ": internal error - produced " << out.size()
              << " value(s) for " << nout << " name(s)\n";
  }
  return true;
}

} // namespace numpy
} // namespace nc
