// Small shared helpers for NumPy-section implementations: reading arguments
// and building results. Header-only so every section can use them without
// another link dependency. Add a helper here only when two or more sections
// need it; section-specific helpers stay inside that section's folder.
//
// NC value shapes these map onto (core/value.h):
//   number  -> plain scalar (Value(double))
//   array   -> 1-D, Value(std::vector<Value>)              isArray
//   matrix  -> 2-D, Value(std::vector<std::vector<Value>>) isMatrix
// NC has no N-D (3+) array type yet - see README.md, "Open design points".
#ifndef NC_NUMPY_COMMON_H
#define NC_NUMPY_COMMON_H

#include <cmath>
#include <string>
#include <vector>

#include "numpy_registry.h"

namespace nc {
namespace numpy {

inline bool isPlainNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
         !v.isFunctionRef;
}

inline std::string ordinal(size_t i) {
  static const char *names[] = {"first", "second", "third", "fourth", "fifth", "sixth"};
  return i < 6 ? names[i] : ("argument " + std::to_string(i + 1));
}

// ---- reading arguments (each reports its own error through ctx) ----

inline bool argNumber(const std::vector<Value> &args, size_t i, CallContext &ctx, double &out) {
  if (i >= args.size() || !isPlainNumber(args[i])) {
    ctx.fail("the " + ordinal(i) + " argument must be a number");
    return false;
  }
  out = args[i].number;
  return true;
}

// A whole number (e.g. a count, an axis, a size).
inline bool argInt(const std::vector<Value> &args, size_t i, CallContext &ctx, long long &out) {
  double d = 0.0;
  if (!argNumber(args, i, ctx, d))
    return false;
  if (!std::isfinite(d) || d != std::floor(d)) {
    ctx.fail("the " + ordinal(i) + " argument must be a whole number");
    return false;
  }
  out = static_cast<long long>(d);
  return true;
}

inline bool argNonNegativeInt(const std::vector<Value> &args, size_t i, CallContext &ctx,
                              long long &out) {
  if (!argInt(args, i, ctx, out))
    return false;
  if (out < 0) {
    ctx.fail("the " + ordinal(i) + " argument must not be negative");
    return false;
  }
  return true;
}

inline bool argText(const std::vector<Value> &args, size_t i, CallContext &ctx, std::string &out) {
  if (i >= args.size() || !args[i].isText) {
    ctx.fail("the " + ordinal(i) + " argument must be text in quotes");
    return false;
  }
  out = args[i].text();
  return true;
}

// Scalar, array or matrix -> flat list of doubles (matrix read row by row).
// Fails on text, dicts, objects or non-numeric elements.
inline bool flattenNumbers(const Value &v, std::vector<double> &out) {
  out.clear();
  if (isPlainNumber(v)) {
    out.push_back(v.number);
    return true;
  }
  if (v.isArray) {
    for (const Value &e : v.elems()) {
      if (!isPlainNumber(e))
        return false;
      out.push_back(e.number);
    }
    return true;
  }
  if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.cols(); c++) {
        Value e = v.at(r, c);
        if (!isPlainNumber(e))
          return false;
        out.push_back(e.number);
      }
    return true;
  }
  return false;
}

inline bool argNumbers(const std::vector<Value> &args, size_t i, CallContext &ctx,
                       std::vector<double> &out) {
  if (i >= args.size() || !flattenNumbers(args[i], out)) {
    ctx.fail("the " + ordinal(i) + " argument must be a number, array or matrix of numbers");
    return false;
  }
  return true;
}

// ---- building results ----

inline Value makeArray(const std::vector<double> &values) {
  std::vector<Value> elems;
  elems.reserve(values.size());
  for (double d : values)
    elems.push_back(Value(d));
  return Value(elems);
}

inline Value makeMatrix(const std::vector<std::vector<double>> &rows) {
  std::vector<std::vector<Value>> m;
  m.reserve(rows.size());
  for (const auto &row : rows) {
    std::vector<Value> r;
    r.reserve(row.size());
    for (double d : row)
      r.push_back(Value(d));
    m.push_back(std::move(r));
  }
  return Value(m);
}

inline Value makeMatrix(size_t nrows, size_t ncols, double fill) {
  return makeMatrix(std::vector<std::vector<double>>(nrows, std::vector<double>(ncols, fill)));
}

inline Value makeText(const std::string &s) { return Value(s); }

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_COMMON_H
