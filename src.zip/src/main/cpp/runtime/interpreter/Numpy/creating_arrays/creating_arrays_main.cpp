// Section 2 of 11 - Creating Arrays
// Planned entries: 71
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   cr_functions.cpp   check_finite zeros_like ones_like vander meshgrid indices
//                      rand_choice shuffle permutation rand_binomial rand_poisson
//                      rand_exponential rand_beta rand_gamma rand_lognormal
//                      rand_chisquare rand_triangular rand_geometric
//                      rand_multinomial rand_mvnormal
//
// The random functions share the engine of nexus() (ops/matrix/matrix.cpp,
// ncRandomEngine()), so nexus_seed(n) makes all of them repeatable.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        creating_arrays/cr_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerCreatingArrays() below.
//   2. Register it with reg.add({...}) and give it a parameter line
//      (reg.setParams(name, "A, axis?") - core/param_list.h).
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup.
#include "creating_arrays_main.h"

#include "cr_functions.h"

namespace nc {
namespace numpy {

void registerCreatingArrays(Registry &reg) { registerCreatingFunctions(reg); }

} // namespace numpy
} // namespace nc
