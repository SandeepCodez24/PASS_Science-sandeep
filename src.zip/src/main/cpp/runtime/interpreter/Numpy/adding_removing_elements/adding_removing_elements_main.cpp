// Section 5 of 11 - Adding & Removing Elements
// Planned entries: 20
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   ar_functions.cpp   insert repeat pad trim_zeros unique put replace_if
//                      fill_diagonal nan_to_num
//
// Names from the team's list that are not here: append (replaced by the
// extend operators M ,= X and M ;= X), filter and remove_nan (dropped by the
// team, 2026-10-28).
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        adding_removing_elements/ar_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerAddingRemovingElements() below.
//   2. Register it with reg.add({...}) and give it a parameter line
//      (reg.setParams(name, "A, axis?") - core/param_list.h).
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   call the new function by its NC name.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup.
#include "adding_removing_elements_main.h"

#include "ar_functions.h"

namespace nc {
namespace numpy {

void registerAddingRemovingElements(Registry &reg) { registerAddRemoveFunctions(reg); }

} // namespace numpy
} // namespace nc
