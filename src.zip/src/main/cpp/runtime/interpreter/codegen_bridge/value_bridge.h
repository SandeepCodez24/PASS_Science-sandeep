#pragma once

// extern "C" ABI bridge between NC's existing Value-based tree-walking
// runtime and future LLVM-generated code (Step 3 of the codegen/JIT/AOT
// roadmap - the IR-emitting CodeGen visitor - is NOT built yet; this file
// only provides the callable surface it will eventually target).
//
// Design: the codegen strategy decided on is "bridge everything" - no
// generated code manipulates Value fields directly or gets its own raw-IR
// fast path for plain arithmetic. Every operation, including simple number
// addition, becomes a `call` to one of these functions. That's why these
// exist at all instead of only the ones that "need" a C++ runtime call
// (matrix/dict/object ops): uniformity was chosen over the extra
// complexity of a dual-path codegen split.
//
// Two categories of functions here, deliberately different shapes:
//   - Pure operators (arithmetic/comparison/logical/abs) take only Value*
//     operands - they don't touch any interpreter state, so no context
//     handle is needed or provided.
//   - Variable read/write need an NCContext, because NC variables live in
//     a specific Parser instance's `memory` map / slot-indexed call frame
//     (compiler_src/parser/parser.h) - there is no such thing as a
//     context-free variable access in this language. A future CodeGen
//     visitor must thread this context through every generated function
//     that touches a variable.
//
// Calling convention: every function takes `const Value*` for operands and
// writes its result into a caller-allocated `Value* out` out-parameter.
// Value (runtime/interpreter/core/value.h) is a large struct that embeds
// std::string/std::vector/std::unordered_map inline, not a compact tagged
// union - it is never passed or returned by value across this boundary.
// Every function returns `int` (0 = success, nonzero = the same kind of
// failure the tree-walker signals via Parser::evaluationSucceeded_ - a
// dimension mismatch, an unorderable comparison, an unknown variable) so
// generated code can check for errors without inspecting Value contents.
//
// Ownership: `out` is entirely caller-allocated and caller-owned - these
// functions only ever write into it (via Value's copy-assignment), never
// allocate or free anything themselves. No garbage collector or arena
// allocator is assumed here (both are still unimplemented stubs under
// runtime/memory/gc and runtime/memory/pool) - deliberately out of scope
// for this step.

#include "../core/value.h"

#ifdef __cplusplus
extern "C" {
#endif

// Opaque handle to a live Parser instance (compiler_src/parser/parser.h).
// Kept opaque here so this header stays includable without pulling in the
// whole parser - a caller that already has a real Parser* just
// reinterpret_cast's it in; value_bridge.cpp does the same cast back out.
typedef void *NCContext;

/* ---- Pure operators: BinaryOp (7 ops), UnaryOp (2 ops), AbsOrNorm ----
   Mirror Parser::evaluateBinaryOp/evaluateComparison/evaluateLogicalOp and
   evaluateExpr()'s UnaryOp/AbsOrNorm cases (compiler_src/parser/
   parser_expression.cpp, parser_factor.cpp) exactly, including their
   Dimensional Integrity guards - these are faithful wraps of the existing
   tree-walker's behavior, not a reimplementation. */

int nc_bridge_add(const Value *a, const Value *b, Value *out);
int nc_bridge_sub(const Value *a, const Value *b, Value *out);
int nc_bridge_mul(const Value *a, const Value *b, Value *out);
int nc_bridge_div(const Value *a, const Value *b, Value *out);
int nc_bridge_mod(const Value *a, const Value *b, Value *out);
int nc_bridge_floordiv(const Value *a, const Value *b, Value *out); // "//"
int nc_bridge_pow(const Value *a, const Value *b, Value *out);      // "^"

int nc_bridge_neg(const Value *a, Value *out); // unary "-"
int nc_bridge_not(const Value *a, Value *out); // unary "!"
// postfix "!" (factorial, e.g. `5!`) - a REAL, previously-undetected gap:
// UnaryOp codegen used to treat ANY text other than "!" as unary "-", so
// `5!` (Expr::text == "!post", not "!" or "-" - see ast.h's UnaryOp
// comment) silently computed -5 via nc_bridge_neg instead of 120, rather
// than being rejected at compile time or computing the real result -
// confirmed by direct repro against a real .nc file before this was fixed.
int nc_bridge_factorial(const Value *a, Value *out);

int nc_bridge_abs_or_norm(const Value *a, Value *out); // |x|

/* ---- Comparison (6 ops) ---- */
int nc_bridge_eq(const Value *a, const Value *b, Value *out);
int nc_bridge_neq(const Value *a, const Value *b, Value *out);
int nc_bridge_lt(const Value *a, const Value *b, Value *out);
int nc_bridge_gt(const Value *a, const Value *b, Value *out);
int nc_bridge_lte(const Value *a, const Value *b, Value *out);
int nc_bridge_gte(const Value *a, const Value *b, Value *out);

/* ---- LogicalOp (4 ops) ---- */
int nc_bridge_logical_and(const Value *a, const Value *b, Value *out);
int nc_bridge_logical_or(const Value *a, const Value *b, Value *out);
int nc_bridge_logical_nand(const Value *a, const Value *b, Value *out);
int nc_bridge_logical_nor(const Value *a, const Value *b, Value *out);

/* ---- Context-dependent: variable access + print ---- */

// name/slot mirror Expr::slot's convention exactly (ast.h): slot >= 0 means
// "index into the current call frame's slots_", -1 means "look `name` up in
// the string-keyed `memory` map instead". A future CodeGen visitor should
// pass whatever `Expr::slot` already resolved to, unchanged. `name` may be
// NULL when slot >= 0 and the caller has no name to hand back (mirrors how
// varGet/varSet/varExists already accept an unused `name` in that case) -
// this bridge always passes an empty string through rather than
// dereferencing a NULL, see value_bridge.cpp.
int nc_bridge_var_read(NCContext ctx, const char *name, int slot, Value *out);
int nc_bridge_var_write(NCContext ctx, const char *name, int slot, const Value *v);

// Reads a compiled function/method's DECLARED OUTPUT back out of the local
// scope about to be torn down - used only in a FunctionDecl/instance
// method's epilogue, in place of nc_bridge_var_read, for exactly this one
// purpose. Unlike nc_bridge_var_read (which falls back through
// readVariableOrConstant()'s constant/unit-constant/zero-arg-function
// resolution when the plain variable doesn't exist), this checks ONLY
// varExists() - a declared output is either a real local variable the body
// assigned, or it wasn't assigned at all, full stop; mirrors
// Parser::callUserFunction()/callUserFunctionMulti()/callInstanceMethod()'s
// own outScope.find(outName) == outScope.end() check exactly (parser_
// function.cpp/parser_class.cpp), including their specific "Error: output
// '<outName>' not assigned in function/method '<ownerName>'" message and
// evaluationSucceeded_ = false. A REAL, previously-accepted gap (this
// bridge used to not exist - nc_bridge_var_read's generic fallback was
// used instead, which correctly left the CALLER's target unassigned once
// nc_bridge_get_evaluation_succeeded()'s propagation fix landed, but with
// the wrong stderr text - "Unknown constant '<outName>'" instead of the
// tree-walker's specific message) - confirmed via real corpus testing
// (Testing_Files/t44_slot_output_not_assigned.nc, outside this harness).
int nc_bridge_read_declared_output(NCContext ctx, const char *outName, const char *ownerName,
                                    int isMethod, Value *out);

// Prints one value the same way a single-argument `print(x)`/`publish(x)`
// statement does (StmtKind::Publish, parser_exec_stmt.cpp): text values
// print raw, everything else goes through valueToString(), one trailing
// newline. Multi-argument publish (space-joined values) is out of scope
// for this slice. Does not need an NCContext - printing doesn't touch
// Parser instance state.
int nc_bridge_publish(const Value *v);

// Mirrors printValue() (runtime/interpreter/core/output.cpp/.h) exactly -
// the MATLAB-style auto-echo every unsuppressed statement (no trailing
// ';') triggers in the tree-walker: "<name> = <value>\n" when `name` is
// non-empty, or just "<value>\n" for a bare expression statement (name ==
// ""). A REAL, previously-undetected gap: codegen never called this at
// all for any statement shape until this was added - confirmed by `grep
// suppressOutput codegen.cpp` returning zero hits beforehand, and by
// direct repro against the built binary (`x = 5 + 3` with no semicolon,
// JIT on, printed nothing at all where the tree-walker prints "x = 8").
// Every 86 pre-existing parity-harness case passed anyway because they
// all either deliberately suppress output with ';' (to compare variable
// STATE via checkVar, not printed text) or use an explicit print()/
// publish() call (which routes through nc_bridge_publish above, a
// completely separate, already-correct path) - none of them exercised
// the implicit no-semicolon auto-echo itself. No NCContext needed -
// printing doesn't touch Parser instance state, same as nc_bridge_publish.
void nc_bridge_print_value(const char *name, const Value *v);

/* ---- Value lifetime helpers ----
   Added while building Step 3 (the CodeGen visitor) - a genuine gap in
   this header as originally written. Every function above assumed a C++
   caller who can just declare `Value out;` on its own stack and let the
   constructor run implicitly. Generated LLVM IR has no such thing: Value
   is a non-trivial struct (it embeds std::string/std::vector/
   std::unordered_map), so a raw `alloca` of its byte size is NOT a validly
   constructed object - calling any bridge function on it would be
   undefined behavior. These three functions are what let generated code
   create and release a properly-constructed Value of its own, to use as
   an operand or `out` argument to any function above. Existing signatures
   above are unchanged; this is a pure addition. */
Value *nc_bridge_value_create(void);          // heap-allocates + default-constructs
void nc_bridge_value_destroy(Value *v);       // destructs + frees
void nc_bridge_value_set_number(Value *v, double n); // *v = Value(n)
void nc_bridge_value_set_imaginary(Value *v, double im); // *v = 0 + im*i

/* ---- Control-flow helpers ----
   Added while building the control-flow slice of the CodeGen visitor
   (If/elseif/else, While, For-over-RangeLiteral, Break/Continue). Two more
   genuine gaps: the tree-walker's truthiness rule and its range-loop
   continuation rule both exist only as private, unexported logic (an
   anonymous-namespace free function and a lambda, respectively - neither
   reachable from outside the .cpp file that defines them), so generated IR
   has no way to reuse them without a new bridge entry. Both are faithful
   copies of that existing logic, not new semantics - see each one's
   comment for exactly what it mirrors. Existing signatures above are
   unchanged; this is a pure addition, same as the value lifetime helpers. */

// Same rule If/While/For conditions use to decide truthiness - mirrors
// truthy() (parser_exec_stmt.cpp, anonymous namespace): text values are
// truthy iff non-empty, everything else iff .number != 0. Returns 1/0, not
// an error code - there's no failure mode here. No NCContext needed -
// purely a function of `v`'s contents.
int nc_bridge_truthy(const Value *v);

// Reads the plain `double` stored in v->number - e.g. to pull a native
// counter/bound out of a RangeLiteral's start/stop/step operands (each of
// which is itself an arbitrary Expr - a literal, a variable, ... -
// evaluated through the normal bridge path first, same as any other
// expression). No NCContext needed.
double nc_bridge_get_number(const Value *v);

// Mirrors generateRange()'s shouldContinue lambda exactly (parser_
// block_exec.cpp), including its 1e-9 epsilon tolerance: given the loop's
// current native counter value, its step, its end bound, and whether the
// range's right bracket is inclusive (']') or exclusive (')'), returns
// 1 if the range loop should keep iterating, 0 if it should stop. The
// tree-walker fully materializes a range's values via generateRange()
// before iterating it as an array; CodeGen drives an equivalent native-
// double loop counter instead (see codegen.cpp's StmtKind::For case) and
// calls this once per iteration to decide when to stop, rather than
// re-deriving the direction/epsilon logic in IR. Left-bracket exclusivity
// (`(a:b]` skipping `a` itself) is compile-time-known from the
// RangeLiteral's own text and handled directly in codegen.cpp - it only
// affects the loop's initial value, not this per-iteration check.
int nc_bridge_range_should_continue(double current, double step, double end, int rightInclusive);

/* ---- Require/Ensure/ClearMemory helpers ----
   Added to close a CodeGen coverage gap (StmtKind::Require/Ensure/
   ClearMemory previously always rejected with ok_ = false). */

// Prints the exact stderr line executeStmt()'s StmtKind::Require/Ensure
// case does on a failed condition: "Error: precondition failed: <text>" (or
// "postcondition" when isRequire is 0), AND sets Parser::evaluationSucceeded_
// = false - unconditionally, matching the tree-walker exactly regardless of
// whether this Require/Ensure is at the top level or inside a user function/
// method body (unlike nc_bridge_signal_top_level_return, which IS gated on
// that - see codegen.h's inUserFunctionBody_). Needs an NCContext for this
// second part - a real gap once evaluationSucceeded_ = false's ROLE was
// understood: it's what the tree-walker relies on to propagate "this call
// failed partway through" out of invokeFunctionBody() to the caller
// (invokeFunctionBody() never saves/resets/restores it, unlike loopSignal_ -
// it's genuinely global, reset only once per top-level executeStmt()
// dispatch), so a require/ensure failure INSIDE a natively-JIT-compiled
// function had no way to make its caller's Assign leave the target
// unassigned the way the tree-walker does - confirmed by direct repro (a
// function whose require failed mid-loop still bound its caller's variable
// to a partial result via JIT). See nc_bridge_get_evaluation_succeeded()
// and nc_bridge_reset_evaluation_succeeded() for the other two pieces of
// this fix, and codegen.cpp's StmtKind::Assign comment for where the
// result is actually checked.
void nc_bridge_report_condition_failure(NCContext ctx, int isRequire, const char *conditionText);

// Reports a `while` statement exceeding the shared iteration cap
// (kMaxWhileIterations in ast.h): prints the same runtime error as the
// tree-walker. The JIT-generated loop then branches to its exit block, like
// the interpreter's `break`. Leaves evaluationSucceeded_ true - see the
// definition's comment for why (compiled code never resets it per statement).
void nc_bridge_report_while_limit(NCContext ctx);

// Context-aware BinaryOp/Comparison, used in place of nc_bridge_add/sub/.../
// nc_bridge_eq/lt/... above wherever the CALLER needs the failure actually
// surfaced (currently: everywhere codegen.cpp emits one of these - see
// below). The plain nc_bridge_add()-style functions above are faithful,
// dimension-checked mirrors of evaluateBinaryOp()/evaluateComparison() and
// correctly RETURN nonzero on a dimension mismatch/text-arithmetic/
// unorderable-comparison failure - but codegen.cpp's generated IR never
// checked that return code before this pair existed, so e.g. a JIT-compiled
// `5*m + 3*kg` (incompatible units) or `"a"+"b"` (text arithmetic) or
// `"abc" < 5` (unorderable types) silently produced a plausible-looking
// wrong answer (whatever nc_bridge_value_create()'s zero-initialized `out`
// happened to be) with NO error at all - confirmed by direct repro, and a
// real, silent divergence from the tree-walker, which always correctly
// rejects all three. These call straight into
// Parser::evaluateBinaryOpValues()/evaluateComparisonValues()
// (parser_expression.cpp) - the exact same logic and error messages
// evaluateBinaryOp()/evaluateComparison() use, just taking already-
// evaluated Values instead of Expr children - so generated code gets
// byte-identical behavior to the tree-walker, not a reimplementation.
// `op` is the NC operator's own text ("+", "<", ...), not a bridge function
// name. Same "0 = success" convention as every other status-returning
// function here; on failure, Parser::evaluationSucceeded_ is already set
// (and the error already printed) by the time this returns, exactly as if
// the tree-walker had evaluated the same expression - the caller only needs
// to avoid using `out`/avoid writing it somewhere visible on that path,
// mirroring executeAssignStmt()'s/executeStmt()'s own gating.
int nc_bridge_binary_op_checked(NCContext ctx, const char *op, const Value *a, const Value *b,
                                 Value *out);
int nc_bridge_comparison_checked(NCContext ctx, const char *op, const Value *a, const Value *b,
                                  Value *out);

// Called when nc_bridge_index_set() (above) returns nonzero - a real,
// smaller gap than the BinaryOp/Comparison one above, found the same way:
// codegen.cpp already correctly gates the auto-echo print on
// nc_bridge_index_set()'s status (a failed write, e.g. an out-of-range
// index, correctly stays silent on stdout, matching the tree-walker) but
// never reports the failure at all otherwise - so `arr[-1] = 99;` silently
// did nothing under JIT with no error, while the tree-walker always prints
// "Error: array index out of range for 'arr'" (executeIndexAssign(),
// parser_exec_stmt.cpp) and sets evaluationSucceeded_ = false. Since
// nc_bridge_index_set()'s single nonzero return doesn't distinguish which
// of its several checks failed (array/matrix bounds, row/column bounds,
// "not a matrix", multi-key dict shape, ...), this reports one general,
// accurate-enough message rather than replicating every exact wording -
// unlike the BinaryOp/Comparison fix, a wrong VALUE never reaches anywhere
// here (the container is provably unchanged either way), so this is a
// diagnostics gap, not a silent-wrong-answer one.
void nc_bridge_report_index_set_failure(NCContext ctx, const char *baseName);

// Sets Parser::evaluationSucceeded_ = true - called ONCE, at the very start
// of the outermost per-statement entry function CodeGen::compileStatements()
// builds, mirroring executeStmt()'s own `evaluationSucceeded_ = true;` reset
// at the top of every TOP-LEVEL statement dispatch (never inside a compiled
// FunctionDecl/constructor/method body - those correctly inherit whatever
// state is already current when they're called, exactly like
// invokeFunctionBody() never resetting it either). Without this, a failure
// from an EARLIER, unrelated top-level statement would incorrectly persist
// and make a later, actually-successful native function call look like it
// failed too.
void nc_bridge_reset_evaluation_succeeded(NCContext ctx);

// Returns 0 if Parser::evaluationSucceeded_ is currently true, nonzero if
// false - same "0 = success" convention as every other status-returning
// function in this header. Called right after a natively-compiled function/
// constructor call returns, to decide whether an internal require/ensure
// failure means the caller's Assign should skip writing/echoing the result -
// see nc_bridge_report_condition_failure's comment for the full mechanism.
int nc_bridge_get_evaluation_succeeded(NCContext ctx);

// Wipes the Parser's `memory`/insertionOrder and re-truncates variables.txt
// with a fresh header - calls Parser::clearMemoryAndPersist() (parser_
// exec_stmt.cpp), the exact same code executeStmt()'s StmtKind::ClearMemory
// case now also calls, extracted specifically so this trampoline and the
// tree-walker share one implementation rather than two copies that could
// drift.
void nc_bridge_clear_memory(NCContext ctx);

// Calls Parser::saveToFile() (persists `memory` to variables.txt) - a real
// gap found via direct testing: codegen.cpp's StmtKind::Assign/Index-write
// codegen never called anything equivalent to this at all, so EVERY
// natively-JIT-compiled assignment silently skipped persistence entirely,
// while the tree-walker calls saveToFile() after every successful one
// (executeAssignStmt()/executeIndexAssign(), parser_exec_stmt.cpp). Whether
// a variable survived to the next script invocation ended up depending
// entirely on whether JIT happened to natively compile that particular
// statement - confirmed by direct repro: `x = 5;` under JIT never wrote
// variables.txt at all, while the identical script ran through the
// tree-walker (JIT disabled) did. Call sites mirror the tree-walker's own
// exactly: every place codegen.cpp writes a variable via varWriteFn()/
// indexSetFn() on a path the tree-walker's equivalent also calls
// saveToFile() from (see nc_bridge_field_set's OWN call sites for the one
// exception - a field write is never persisted in either implementation,
// since object instances aren't persisted at all - variable_store.cpp's
// own comment on isObject).
void nc_bridge_save_to_file(NCContext ctx);

// Sets Parser::loopSignal_ to Return - exactly what a bare top-level
// `return;` or a failed top-level `require`/`ensure` already does in
// executeStmt(). A REAL, previously-undetected gap: codegen's StmtKind::
// Return/Require/Ensure only ever emitted a `br` to the enclosing compiled
// function's own epilogue - correct on its own, but that's Parser-state-
// invisible, so a caller checking Parser::consumeTopLevelStopSignal()
// after the JIT-compiled statement runs (main.cpp's REPL loop;
// ScriptManager::executeFile()'s JIT-aware Pass 2) never saw it and kept
// running the REST of the script - confirmed by direct repro against a
// real .nc file (a top-level `return;` mid-script had no effect at all
// under JIT, where the tree-walker correctly stops there). Codegen only
// calls this when NOT compiling a user function/method body (see
// codegen.h's inUserFunctionBody_) - inside one, this signal would have
// nothing to reset it before the call returns (unlike the tree-walker's
// invokeFunctionBody(), which explicitly saves/resets/restores
// loopSignal_ around every call), so setting it there would incorrectly
// leak past the call and stop the whole top-level script over a plain
// internal function return.
void nc_bridge_signal_top_level_return(NCContext ctx);

/* ---- Call-frame helpers ----
   Added while building user-defined function support (StmtKind::
   FunctionDecl / ExprKind::Call). The investigation behind these two is
   worth recording since it shaped the whole design: Parser::
   invokeFunctionBody() (parser_function.cpp) gives every call a fresh
   local scope by *moving* `memory`/`insertionOrder` (plus slots_/
   slotAssigned_ and several other fields this bridge's functions never
   touch) out into local C++ variables, clearing them, running the body,
   pulling the declared output back out, then moving the saved state back
   in - a manual save/restore of Parser's own member fields, which nests
   correctly for recursion only because each invokeFunctionBody() call is
   itself a real (recursive) C++ call with its own stack frame holding the
   saved state.
   nc_bridge_var_read()/nc_bridge_var_write() already operate on whatever
   `memory`/`slots_` currently IS on the Parser - confirmed by reading
   varGet()/varSet()/varExists() (parser_locals.cpp) directly, not assumed
   - so they need no changes. What's missing is the save/restore act
   itself: generated IR has no C++ call stack of local variables to hold
   the saved state the way invokeFunctionBody() does, so these two
   maintain an explicit stack of saved scopes instead, keyed by the
   NCContext (Parser*) they're called with - see value_bridge.cpp. Every
   codegen'd function this project compiles only ever resolves variables
   by name (slot == -1 always - Phase 6 slot resolution never runs on
   codegen'd ASTs), and varSet/varGet/varExists's slot==-1 path only
   touches memory/insertionOrder - so that's the only state these two
   need to save/restore for correctness at this scope; slots_ itself is
   left completely alone. */

// Saves the Parser's current `memory`/`insertionOrder` (pushed onto an
// internal stack keyed by `ctx`) and replaces them with a fresh, empty
// scope - the generated-code equivalent of invokeFunctionBody()'s save-
// and-clear step. Call once at the start of a compiled function's body,
// before binding parameters (nc_bridge_var_write with slot -1) into the
// now-fresh scope.
int nc_bridge_push_scope(NCContext ctx);

// Restores whatever nc_bridge_push_scope() most recently saved for `ctx`,
// discarding the scope that was active since then. Call once at the end
// of a compiled function's body (after reading its declared output back
// out via nc_bridge_var_read, which must happen BEFORE this call - the
// output lives in the scope being torn down). Push/pop calls for the same
// `ctx` must nest properly (LIFO) - exactly as they do automatically here,
// since every compiled function call pushes once on entry and pops once
// before returning, and recursion/nested calls are just more push/pop
// pairs on the same stack in the order calls actually happen.
int nc_bridge_pop_scope(NCContext ctx);

// Saves Parser::currentDefiningClass_ (pushed onto an internal LIFO stack
// keyed by `ctx`, same idiom as nc_bridge_push_scope/pop_scope above) and
// sets it to `className` - the compiled class's own name, for the duration
// of a compiled constructor/instance-method call. This is what
// checkFieldAccess() (called from nc_bridge_field_get/set now - see their
// comments) uses to decide "is the CURRENT call running as this class's
// own code" - private/protected field access enforcement was a documented,
// accepted gap until this existed (confirmed via real corpus testing,
// Testing_Files/t28_class_errors.nc/t29_encapsulation.nc, outside this
// harness: private/protected field reads/writes silently succeeded via
// JIT where the tree-walker correctly rejects them). Only called for a
// NATIVELY-compiled constructor/method (compileClassConstructor()/
// compileInstanceMethod()) - a class with inheritance/abstract/reversible/
// @rate still routes through the real callClassConstructor()/
// callInstanceMethod() (nc_bridge_call_dynamic), which already sets this
// correctly itself (invokeFunctionBody(), parser_function.cpp) - no
// codegen involvement needed there.
void nc_bridge_push_defining_class(NCContext ctx, const char *className);

// Restores whatever nc_bridge_push_defining_class() most recently saved.
// Call once at the end of a compiled constructor/method body - order
// relative to nc_bridge_pop_scope doesn't matter (different Parser field),
// but must still nest LIFO the same way push/pop_scope do.
void nc_bridge_pop_defining_class(NCContext ctx);

/* ---- Array/matrix/dict/text helpers ----
   Added while building array/matrix/dict support in the CodeGen visitor.
   Investigated first, against the real source, not assumed:
     - ArrayLiteral/MatrixLiteral construction (evaluateExpr(), parser_
       factor.cpp) is plain: evaluate each element/row once, in order,
       collect into a Value. No surprises there.
     - There is NO dict literal syntax (ast.h's ExprKind has no DictLiteral
       entry, confirmed). A dict comes into existence purely by auto-
       vivification: assigning through an index on a name that doesn't
       exist yet - A['key'] = v when A is undefined - creates an empty
       dict first (executeIndexAssign(), parser_exec_stmt.cpp), then sets
       the key. nc_bridge_index_set() below replicates exactly that.
     - CLAUDE.md (this repo's own instructions) documents "no working
       syntax to read a single array/matrix element by index" as a known,
       verified-2026-09 gap. Read directly against the CURRENT evaluateExpr()
       Index case rather than trusting that note: it is STALE. Per-element
       read fully works today - chained A[row][col], comma-form A[row,col],
       and array A[i] all have real, bounds-checked implementations calling
       evaluateExpr() on the receiver first, then indexing the result. Only
       wildcard (':') row/column slicing (A[:,col], A[row,:], A[:,:]) is
       out of scope for this codegen slice - see nc_bridge_index_get/set's
       own comments.
   Value's own array-of-Value / matrix-of-Value / string internals are
   never touched directly by generated IR (same "everything crosses
   through a bridge call" principle as every prior step) - these functions
   are the only way generated code builds or reads through a non-scalar
   Value. */

// Constructs a text Value (mirrors the Value(const std::string&)
// constructor) - e.g. for a StringLiteral, or a text-valued dict key.
void nc_bridge_value_set_text(Value *v, const char *s);

// Builds an array-valued Value from `count` already-evaluated element
// Values (mirrors evaluateExpr()'s ExprKind::ArrayLiteral case: each
// element evaluated once, in order, then collected - no per-element
// copying beyond that). `elements` is a plain C array of `count` Value*
// pointers, not owned - the caller still owns and must separately destroy
// each one after this call, same as every other bridge function's operand
// convention.
void nc_bridge_array_from_elements(const Value *const *elements, int count, Value *out);

// Builds a matrix-valued Value from `count` already-built row Values,
// each of which must itself be array-valued (mirrors Value's own
// std::vector<std::vector<Value>> representation - a matrix is just its
// rows). Codegen builds each row via nc_bridge_array_from_elements() first
// (a different construction PATH than evaluateExpr()'s MatrixLiteral case
// takes - that evaluates a row's cells directly rather than treating the
// row as its own ArrayLiteral - but an identical RESULT, since either way
// ends at the same vector-of-row-vectors shape). No rectangularity check,
// matching evaluateExpr()'s MatrixLiteral case exactly - it doesn't
// validate row lengths either, so neither does this.
void nc_bridge_matrix_from_rows(const Value *const *rows, int count, Value *out);

// Mirrors evaluateExpr()'s ExprKind::Index case (parser_factor.cpp),
// including wildcard (bare ':') row/column slicing. `receiver` is whatever
// the indexed expression evaluated to (already fetched by the caller,
// exactly like the tree-walker's own `Value v = evaluateExpr(receiverNode);`
// first step); `keys` is `keyCount` key Values EXCEPT that a Wildcard key
// is passed as a null pointer (codegen has no Value to evaluate a bare ':'
// into - ExprKind::Wildcard has no codegenExpr() case - so it marshals a
// null slot in that position instead of calling codegenExpr() on it; see
// codegen.cpp's ExprKind::Index case). Handles, by receiver's actual
// runtime type (never known at codegen time, so the dispatch has to live
// here rather than as compile-time-chosen IR):
//   matrix + 1 key: concrete -> whole row (array-valued - this is what
//     makes a chained A[row][col] read work as two separate calls to this
//     same function); null (A[:]) -> the whole matrix unchanged.
//   matrix + 2 keys: both concrete -> single element; both null (A[:,:])
//     -> the whole matrix unchanged; one null -> the other axis's whole
//     row/column (A[row,:] / A[:,col]).
//   array + 1 key: concrete -> element; null (A[:]) -> the whole array
//     unchanged.
//   dict + 1 key: value (key formatted via the same text/formatNumber rule
//     dictKeyOf() uses - parser_internal.h's dictKeyOf() itself isn't
//     reused directly since it's explicitly documented there as
//     parser_*.cpp-internal, not part of the public Parser API; replicated
//     as a faithful one-line copy in value_bridge.cpp instead). A dict never
//     supports a Wildcard key (no tree-walker case for it either).
// Returns nonzero (out of range, wrong key count/shape for the receiver, a
// receiver that's none of matrix/array/dict, or a dict key with a null/
// Wildcard key) rather than a Value on any of the tree-walker's error
// paths for this subset.
int nc_bridge_index_get(const Value *receiver, const Value *const *keys, int keyCount, Value *out);

// Mirrors executeIndexAssign() (parser_exec_stmt.cpp), including matrix
// wildcard row/column REPLACE (A[row,:]=v / A[:,col]=v, same null-pointer-
// for-Wildcard convention as nc_bridge_index_get() above) and multi-key
// dict assignment (A[k1,k2,...] = [v1,v2,...], keyCount == val->length()
// required): array A[i]=v, matrix A[row][col]=v/A[row,col]=v (both forms
// flatten to the same keyCount==2 call here; see codegen.cpp's comment on
// why executeIndexAssign() special-cases chained A[row][col]=v instead of
// naively decomposing it the way a READ does - naive decomposition would
// write into a COPY of the selected row, not the original matrix), and
// dict A['key']=v (auto-vivifying an empty dict first if `baseName`/
// `baseSlot` doesn't exist yet, exactly like executeIndexAssign()'s own
// varSet(slot, name, Value(unordered_map...)) fallback). Unlike every
// other bridge function, this one needs the base variable's NAME/SLOT
// directly (an NCContext, not just a receiver Value*) rather than a
// value already in hand: auto-vivification and "write back into the
// variable in place" both require touching the actual variable, not a
// disconnected copy - varRef() (parser_locals.cpp) is what this calls
// internally to get a mutable reference to it. A[:,:] (both keys null) has
// no tree-walker meaning ("needs at least one concrete index") and returns
// nonzero, same as the tree-walker's own rejection.
int nc_bridge_index_set(NCContext ctx, const char *baseName, int baseSlot,
                         const Value *const *keys, int keyCount, const Value *val);

/* ---- Class helpers ----
   Added while building the smallest genuinely-correct class mechanism:
   ClassDecl (a single, non-abstract, non-reversible, no-@rate, no-
   inheritance class), construction, FieldAccess, and one instance
   MethodCall. Investigated first, directly against parser_class.cpp (the
   real class-call machinery) and evaluateExpr()'s FieldAccess/MethodCall
   cases (parser_factor.cpp) - findings recorded in codegen.h's own
   "Classes" section (that's where the actual mechanism/design lives;
   this header only covers what crosses the ABI).
   One finding worth restating here since it's exactly why these are
   separate from the array/matrix/dict Index helpers rather than reused:
   an object Value's fields DO live in the same `dictMap` field a dict
   uses (value.h's own comment), but `isObject` and `isDict` are separate,
   mutually-exclusive flags (Value's constructors never set both) - so
   nc_bridge_index_get/set, which check `isDict`, would incorrectly reject
   every object receiver. Field access also differs structurally: the
   field name is always a compile-time-known string (Expr::text on a
   FieldAccess node), never a runtime-evaluated key expression the way an
   Index's bracketed key is - so there's no key-array marshaling needed
   here at all, just a plain `const char*`.
   checkFieldAccess()'s private/protected enforcement (parser_class.cpp)
   is NOT replicated by nc_bridge_field_get/set - an accepted, documented
   gap, not a silent behavior change: checkFieldAccess() returns true
   unconditionally for any field never declared restricted, and this
   slice's scope explicitly excludes restrictedFields - so for every class
   this codegen can actually compile, the two are behaviorally identical. */

// Constructs an empty object Value (isObject=true, given className, empty
// dictMap - no fields set yet) - what callClassConstructor()'s
// `freshInstance` is before its constructor body runs against it as
// `base` (parser_class.cpp). Lineage/snapshot/reversibility bookkeeping
// (Value::lineage, ::snapshots) is deliberately NOT populated - out of
// scope, see codegen.h.
void nc_bridge_value_set_object(Value *v, const char *className);

// Mirrors evaluateExpr()'s ExprKind::FieldAccess case (parser_factor.cpp)
// COMPLETELY - both the object-receiver field read AND the elementwise-dot-
// operator fallback for a non-object receiver (`A.B` meaning element-wise
// matrix multiply when A isn't an object, `B` reinterpreted as an ordinary
// variable name rather than a field name - see parser_factor.cpp's own
// comment on this). A REAL, previously-undetected gap: this used to be
// object-receiver-only, silently returning a nonzero status (with `out`
// left as whatever the caller's fresh Value already was - typically 0) for
// the elementwise-dot case instead of computing the real result OR
// rejecting at compile time - confirmed by direct repro (`M1.M2` on two
// matrices returned 0 via JIT instead of the real element-wise product).
// Needs an NCContext + slot (unlike the old object-only version) because
// the fallback calls readVariableOrConstant() for the right-hand operand,
// exactly like nc_bridge_var_read(). Returns nonzero if: the receiver is
// an object with no such field; OR the receiver isn't an object and either
// operand isn't a matrix (prints the tree-walker's own "Error: Dot
// operator requires two matrices" first, same as callBuiltin() printing
// its own error inside nc_bridge_call_dynamic).
// checkFieldAccess()'s private/protected enforcement (parser_class.cpp)
// is still NOT replicated for the object-receiver path - unchanged,
// accepted, documented gap (see this header's class-helpers section
// comment above) - orthogonal to the fix here.
int nc_bridge_field_get(NCContext ctx, const Value *receiver, const char *name, int slot, Value *out);

// Mirrors executeAssignStmt()'s ExprKind::FieldAccess target case
// (parser_exec_stmt.cpp): requires the base variable to already exist and
// be an object (no auto-vivification, unlike dict index-assign - you
// can't spontaneously create an object the way A['key']=v creates a
// dict), then writes directly into its dictMap via varRef(). Same
// NCContext/baseName/baseSlot shape as nc_bridge_index_set(), for the
// same reason: writing back into the actual variable, not a copy.
int nc_bridge_field_set(NCContext ctx, const char *baseName, int baseSlot,
                         const char *fieldName, const Value *val);

/* ---- Native-scalar performance path helper ----
   Added for the "make arithmetic actually fast" task. Investigated first,
   directly against value.h and the existing add()/sub()/mul()/div_op()
   implementations (arithmetic.cpp) - full findings live in codegen.h's
   own "Native-scalar performance path" section, including a genuine,
   subtle hazard found there (NOT here) about logical_gt()/logical_gte()'s
   NaN behavior that the fast path's comparison predicates have to match
   exactly. This one function is the entire ABI surface that effort added:
   everything else (extracting a native double, computing, boxing the
   result) already existed as nc_bridge_get_number()/nc_bridge_value_
   set_number() from earlier steps - this is the one genuinely missing
   piece, the runtime type+unit guard itself. */

// Returns 1 if `v` is safe for the native-scalar fast path: not text,
// array, matrix, dict, or object, AND unitless (dimL==dimT==dimM==0).
// Deliberately the FULL conservative check, not merely "isn't a matrix" -
// see codegen.h for why that distinction matters (none of add()/sub()/
// mul()/div_op() actually guard against isArray/isText/isDict/isObject
// either, only isMatrix - this guard has to be stricter than what those
// functions themselves check, to guarantee the fast path is only ever
// taken when the answer is byte-for-byte identical to calling them).
int nc_bridge_value_is_plain_number(const Value *v);

/* ---- Dynamic call dispatch ----
   Added to close the biggest remaining gap in codegen's ExprKind::Call
   coverage: everything that isn't a NATIVELY-COMPILED class constructor or
   user-defined function (classCtorArity_/functionArity_, populated only
   from what CodeGen itself has compiled this JIT session - see
   JitEngine's knownClasses_/knownFunctions_ comment). That "everything
   else" is actually THREE tiers, matching evaluateExpr()'s ExprKind::Call
   precedence exactly (classTable_ -> functionTable_ -> callBuiltin(),
   parser_factor.cpp), not just builtins:
     1. A class the tree-walker knows about (classTable_/hasClass()) but
        CodeGen never natively compiled - e.g. it has a parent/is abstract/
        is reversible/has @rate (ClassDecl codegen rejects all of those,
        ok_ = false), or it was simply defined before "@cmd jit on" / by a
        statement JIT never got to compile. Routes to the REAL
        callClassConstructor(), so inheritance/abstract/reversible/@rate
        all just work - no reimplementation, since the actual interpreter
        machinery runs.
     2. Likewise a function the tree-walker knows about (functionTable_/
        hasFunction()) that was never natively compiled. Routes to the
        real callUserFunction().
     3. Everything else - the ~100+ names registered in runtime/
        interpreter/builtins/builtins.cpp's builtinTable (sin, sqrt,
        transpose, det, sum, mean, ...) plus, symmetrically, any name
        that ISN'T registered anywhere. Routes to callBuiltin(), the tree-
        walker's own final-tier dispatcher - nothing to reimplement here
        either.
   This function used to be narrower (nc_bridge_call_builtin, tier 3 only)
   - renamed once it was confirmed that stopping at tier 3 was actually a
   correctness bug, not just a missed optimization: a real class/function
   the tree-walker knows about but tier-3-only dispatch doesn't recognize
   would incorrectly print "Error: Unknown function '<name>'" (from
   callBuiltin() failing to find it) instead of running the tree-walker's
   real behavior - reproduced directly against the built `nc` binary before
   this fix (define a class, `@cmd jit on`, construct it - wrongly failed). */

// Calls callClassConstructor()/callUserFunction()/callBuiltin() - whichever
// tier above actually recognizes `name` - exactly as evaluateExpr()'s
// ExprKind::Call case does. `argv` is `argc` already-evaluated, caller-
// owned operand Values (same non-owning-array convention as
// nc_bridge_index_get's `keys`/`keyCount`); `out` receives the result by
// copy either way, found or not (an unknown name's Value(0) is copied
// through unchanged, not special-cased). Returns 0 if `name` was
// recognized by any tier, nonzero otherwise - same "0 = success"
// convention every other int-returning function in this header uses.
// Unknown-name handling is NOT silent: callBuiltin() itself prints
// "Error: Unknown function '<name>'\n" to stderr before returning, the
// exact same call the tree-walker makes, so generated code that falls all
// the way through to tier 3 and still isn't found gets byte-for-byte
// identical error output. What generated code DOES still need to decide
// for itself is whether a nonzero return should block writing `*out` into
// a target variable - see codegen.cpp's StmtKind::Assign comment for how
// that's handled to mirror executeAssignStmt()'s "if (!evaluationSucceeded_)
// return;" gate. Needs an NCContext (unlike the old builtin-only version)
// because tiers 1/2 call into Parser methods, not just the context-free
// callBuiltin().
int nc_bridge_call_dynamic(NCContext ctx, const char *name, const Value *const *argv, int argc,
                            Value *out);

#ifdef __cplusplus
}
#endif
