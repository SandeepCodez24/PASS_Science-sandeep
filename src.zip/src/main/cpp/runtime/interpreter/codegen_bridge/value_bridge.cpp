#include "value_bridge.h"

#include "../../../compiler/compiler_src/conditional_opr/conditional_opr.h"
#include "../../../compiler/compiler_src/parser/parser.h"
#include "../builtins/builtins.h"
#include "../core/output.h"
#include "../core/elementwise.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/dc/dc.h"
#include "../ops/geometric/geometric.h"
#include "../ops/matrix/matrix.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/vector/vector.h"

#include <cmath>
#include <iostream>
#include <unordered_map>
#include <vector>

namespace {

inline Parser *asParser(NCContext ctx) { return reinterpret_cast<Parser *>(ctx); }

// Call-frame save/restore stack for nc_bridge_push_scope/pop_scope, keyed
// by Parser* - deliberately NOT a Parser member (parser.h is untouched by
// this whole codegen effort; this state exists purely to support generated
// code, so it lives entirely on the bridge side). One entry per currently-
// suspended (pushed but not yet popped) call on that Parser - .back() is
// always the innermost/most recent, matching normal LIFO call-frame
// nesting for recursion and nested calls.
struct SavedScope {
  std::unordered_map<std::string, Value> memory;
  std::vector<std::string> insertionOrder;
};
std::unordered_map<Parser *, std::vector<SavedScope>> g_scopeStacks;

// Same LIFO save/restore idiom as g_scopeStacks, for Parser::
// currentDefiningClass_ - see nc_bridge_push_defining_class's comment.
std::unordered_map<Parser *, std::vector<std::string>> g_definingClassStacks;

inline bool dimsMatch(const Value &v, const Value &r) {
  return v.dimL == r.dimL && v.dimT == r.dimT && v.dimM == r.dimM;
}

// Mirrors evaluateBinaryOp()/evaluateExpr()'s UnaryOp "!post" case
// (parser_expression.cpp/parser_factor.cpp): a text Value that's actually
// a dec2frac()-style "num/denom" fraction (or a plain decimal written as
// text) is auto-coerced to its numeric value in place; returns false
// (v left untouched) only for genuinely non-numeric text. A non-text `v`
// is left untouched and this returns true - safe to call unconditionally.
inline bool coerceTextInPlace(Value &v) {
  if (!v.isText)
    return true;
  double d;
  if (!tryCoerceTextToNumber(v, d))
    return false;
  v = Value(d);
  return true;
}

// Faithful copy of dictKeyOf() (parser_statement.cpp) - not reused
// directly because it's declared in parser_internal.h, which documents
// itself as "only parser_*.cpp files should include this", not part of
// the public Parser API this bridge otherwise builds on. formatNumber()
// (the one piece of real formatting logic involved) IS reused as-is, via
// output.h, already included above.
inline std::string bridgeDictKeyOf(const Value &key) {
  return key.isText ? key.text() : formatNumber(key.number);
}

// Shared by nc_bridge_lt/gt/lte/gte - mirrors evaluateComparison()'s
// ordering guard (parser_expression.cpp): both operands orderable and the
// same kind.
inline bool orderable(const Value &v, const Value &r) {
  return valueIsOrderable(v) && valueIsOrderable(r) && valueKindOf(v) == valueKindOf(r);
}

} // namespace

/* ---- BinaryOp ---- */

// None of +,-,*,/,%,//,^ mean anything for arbitrary text - mirrors the
// isText handling in Parser::evaluateBinaryOp() (parser_expression.cpp):
// without it, a text operand silently fell through to reading its
// .number (0 for any text Value), giving a plausible-looking but
// meaningless answer (0, or 0/0=NaN for division/mod). Text that's
// actually a dec2frac()-style fraction (or a plain decimal as text) is
// coerced to its number first via coerceTextInPlace(); only genuinely
// non-numeric text still returns the same nonzero-means-invalid-operands
// signal dimsMatch() already uses for a dimension mismatch.
int nc_bridge_add(const Value *a, const Value *b, Value *out) {
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv) || !dimsMatch(av, bv))
    return 1;
  *out = add(av, bv);
  return 0;
}

int nc_bridge_sub(const Value *a, const Value *b, Value *out) {
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv) || !dimsMatch(av, bv))
    return 1;
  *out = sub(av, bv);
  return 0;
}

int nc_bridge_mul(const Value *a, const Value *b, Value *out) {
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
    return 1;
  *out = mul(av, bv);
  return 0;
}

int nc_bridge_div(const Value *a, const Value *b, Value *out) {
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
    return 1;
  *out = div_op(av, bv);
  return 0;
}

int nc_bridge_mod(const Value *a, const Value *b, Value *out) {
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
    return 1;
  *out = mod_op(av, bv);
  return 0;
}

int nc_bridge_floordiv(const Value *a, const Value *b, Value *out) {
  // Was a standalone `std::floor(a->number/b->number)` (2026-09-22 fix):
  // unlike every other bridge function above, it never delegated to a
  // shared arithmetic.cpp function, so it never got the array/matrix
  // isArray/isMatrix handling those got - an array/matrix Value's .number
  // defaults to 0, so a JIT-compiled `A//2` on an array silently returned
  // 0 while the exact same expression as a non-JIT'd sub-expression (e.g.
  // as a publish() argument, which the JIT doesn't compile) correctly
  // returned the elementwise result via floor_div(). Delegating to the one
  // real implementation (now also used by evaluateBinaryOp()'s "//" case)
  // fixes the JIT path and removes the duplicate logic.
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
    return 1;
  *out = floor_div(av, bv);
  return 0;
}

int nc_bridge_pow(const Value *a, const Value *b, Value *out) {
  Value av = *a, bv = *b;
  if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
    return 1;
  *out = power(av, bv);
  return 0;
}

/* ---- UnaryOp ----
   No standalone free function exists for unary "-" - evaluateExpr()'s
   UnaryOp case (parser_factor.cpp) implements it inline (array/matrix
   elementwise negation, else negate .number while preserving unit
   dimensions). Both now call the one negate_op() in arithmetic.cpp. */

int nc_bridge_neg(const Value *a, Value *out) {
  // Mirrors the interpreter's UnaryOp "-" (parser_factor.cpp): a
  // dec2frac()-style "num/denom" text operand is negated as its number.
  if (a->isText && a->text().find('/') != std::string::npos) {
    double d;
    if (tryCoerceTextToNumber(*a, d)) {
      Value coerced(d);
      *out = Value(-coerced.number);
      return 0;
    }
  }
  *out = negate_op(*a);
  return 0;
}

int nc_bridge_not(const Value *a, Value *out) {
  *out = logical_not(*a);
  return 0;
}

int nc_bridge_factorial(const Value *a, Value *out) {
  // Mirrors evaluateExpr()'s UnaryOp "!post" case (parser_factor.cpp):
  // factorial of a unit-bearing quantity is rejected rather than silently
  // computed from the raw .number (which used to give (5*m)! = 120,
  // discarding the unit). Text that's actually a dec2frac()-style
  // fraction (or a plain decimal as text) is coerced to its number first
  // via coerceTextInPlace(); only genuinely non-numeric text ("abc"!)
  // still returns the same nonzero-return-means-dimension/type-failure
  // convention as nc_bridge_add's dimsMatch() check.
  Value av = *a;
  if (av.hasComplex()) {
    std::cerr << "Error: '!' (factorial) is not defined for complex numbers\n";
    return 1;
  }
  if (!coerceTextInPlace(av) || av.dimL != 0 || av.dimT != 0 || av.dimM != 0)
    return 1;
  *out = factorial(av);
  return 0;
}

int nc_bridge_abs_or_norm(const Value *a, Value *out) {
  // Same abs_or_norm() evaluateExpr()'s AbsOrNorm case calls: matrix ->
  // determinant, array -> vector norm, else scalar absolute value.
  bool ok = true;
  *out = abs_or_norm(*a, ok);
  return ok ? 0 : 1;
}

/* ---- Comparison ---- */

int nc_bridge_eq(const Value *a, const Value *b, Value *out) {
  if (!dimsMatch(*a, *b))
    return 1;
  *out = logical_eq(*a, *b);
  return 0;
}

int nc_bridge_neq(const Value *a, const Value *b, Value *out) {
  if (!dimsMatch(*a, *b))
    return 1;
  *out = logical_neq(*a, *b);
  return 0;
}

int nc_bridge_lt(const Value *a, const Value *b, Value *out) {
  if (!dimsMatch(*a, *b) || !orderable(*a, *b))
    return 1;
  *out = logical_lt(*a, *b);
  return 0;
}

int nc_bridge_gt(const Value *a, const Value *b, Value *out) {
  if (!dimsMatch(*a, *b) || !orderable(*a, *b))
    return 1;
  *out = logical_gt(*a, *b);
  return 0;
}

int nc_bridge_lte(const Value *a, const Value *b, Value *out) {
  if (!dimsMatch(*a, *b) || !orderable(*a, *b))
    return 1;
  *out = logical_lte(*a, *b);
  return 0;
}

int nc_bridge_gte(const Value *a, const Value *b, Value *out) {
  if (!dimsMatch(*a, *b) || !orderable(*a, *b))
    return 1;
  *out = logical_gte(*a, *b);
  return 0;
}

/* ---- LogicalOp ---- */

int nc_bridge_logical_and(const Value *a, const Value *b, Value *out) {
  *out = logical_and(*a, *b);
  return 0;
}

int nc_bridge_logical_or(const Value *a, const Value *b, Value *out) {
  *out = logical_or(*a, *b);
  return 0;
}

int nc_bridge_logical_nand(const Value *a, const Value *b, Value *out) {
  *out = logical_nand(*a, *b);
  return 0;
}

int nc_bridge_logical_nor(const Value *a, const Value *b, Value *out) {
  *out = logical_nor(*a, *b);
  return 0;
}

/* ---- Context-dependent ---- */

int nc_bridge_var_read(NCContext ctx, const char *name, int slot, Value *out) {
  Parser *p = asParser(ctx);
  std::string n = name ? std::string(name) : std::string();
  // Deliberately does NOT reset evaluationSucceeded_ = true before reading
  // (readVariableOrConstant() itself never touches it on a successful
  // lookup - only sets it false on failure, same as the tree-walker). A
  // reset here used to silently ERASE a real earlier failure in the same
  // call chain - concretely, a compiled function's epilogue reading its
  // declared output back out (nc_bridge_var_read, called unconditionally)
  // would wipe out a require/ensure failure from earlier in that same
  // body, right before the caller could ever observe it via
  // nc_bridge_get_evaluation_succeeded() - a real bug, found and fixed
  // together with that function; see its own comment.
  *out = p->readVariableOrConstant(n, slot);
  return p->evaluationSucceeded_ ? 0 : 1;
}

int nc_bridge_var_write(NCContext ctx, const char *name, int slot, const Value *v) {
  Parser *p = asParser(ctx);
  std::string n = name ? std::string(name) : std::string();
  p->varSet(slot, n, *v);
  return 0;
}

int nc_bridge_read_declared_output(NCContext ctx, const char *outName, const char *ownerName,
                                    int isMethod, Value *out) {
  Parser *p = asParser(ctx);
  std::string on = outName ? std::string(outName) : std::string();
  if (p->varExists(-1, on)) {
    *out = p->varGet(-1, on);
    return 0;
  }
  std::cerr << "Error: output '" << on << "' not assigned in " << (isMethod ? "method" : "function")
            << " '" << (ownerName ? ownerName : "") << "'\n";
  p->evaluationSucceeded_ = false;
  return 1;
}

int nc_bridge_publish(const Value *v) {
  // Mirrors executeStmt()'s StmtKind::Publish case for the single-argument
  // shape exactly (parser_exec_stmt.cpp): text prints raw, everything else
  // goes through valueToString(), one trailing newline.
  if (v->isText)
    std::cout << v->text();
  else
    std::cout << valueToString(*v);
  std::cout << std::endl;
  return 0;
}

void nc_bridge_print_value(const char *name, const Value *v) {
  printValue(name ? std::string(name) : std::string(), *v);
}

/* ---- Value lifetime helpers (see value_bridge.h) ---- */

Value *nc_bridge_value_create() { return new Value(); }

void nc_bridge_value_destroy(Value *v) { delete v; }

void nc_bridge_value_set_number(Value *v, double n) { *v = Value(n); }
void nc_bridge_value_set_imaginary(Value *v, double im) { *v = Value::complexNumber(0.0, im); }

/* ---- Control-flow helpers (see value_bridge.h) ---- */

int nc_bridge_truthy(const Value *v) {
  // Was its own hardcoded copy of the pre-fix truthy() logic (text:
  // non-empty; anything else: number != 0) - the exact same "JIT path has
  // a stale, separately-maintained duplicate" bug class found repeatedly
  // this session. Once parser_exec_stmt.cpp's truthy() was fixed to
  // delegate to valueIsTruthy() (treating a non-empty array/matrix/dict
  // as true, matching and()/or()/is_true()/... elsewhere in this same
  // fix pass), this JIT bridge function silently fell out of step: a
  // JIT-compiled `if (someArray)` still evaluated an array/dict condition
  // as false regardless of its contents, while the tree-walker correctly
  // evaluated the identical condition as true. Confirmed by direct
  // testing (disabling JIT made the same script's `if` take the opposite
  // branch). Now delegates to the same single definition.
  return valueIsTruthy(*v) ? 1 : 0;
}

double nc_bridge_get_number(const Value *v) { return v->number; }

int nc_bridge_range_should_continue(double current, double step, double end, int rightInclusive) {
  const double eps = 1e-9;
  if (step > 0)
    return (rightInclusive ? (current <= end + eps) : (current < end - eps)) ? 1 : 0;
  return (rightInclusive ? (current >= end - eps) : (current > end + eps)) ? 1 : 0;
}

/* ---- Call-frame helpers (see value_bridge.h) ---- */

int nc_bridge_push_scope(NCContext ctx) {
  Parser *p = asParser(ctx);
  SavedScope saved;
  saved.memory = std::move(p->memory);
  saved.insertionOrder = std::move(p->insertionOrder);
  p->memory.clear();
  p->insertionOrder.clear();
  g_scopeStacks[p].push_back(std::move(saved));
  return 0;
}

int nc_bridge_pop_scope(NCContext ctx) {
  Parser *p = asParser(ctx);
  auto it = g_scopeStacks.find(p);
  if (it == g_scopeStacks.end() || it->second.empty())
    return 1; // unbalanced push/pop - should never happen if codegen is correct
  SavedScope &saved = it->second.back();
  p->memory = std::move(saved.memory);
  p->insertionOrder = std::move(saved.insertionOrder);
  it->second.pop_back();
  return 0;
}

void nc_bridge_push_defining_class(NCContext ctx, const char *className) {
  Parser *p = asParser(ctx);
  g_definingClassStacks[p].push_back(p->currentDefiningClass_);
  p->currentDefiningClass_ = className ? std::string(className) : std::string();
}

void nc_bridge_pop_defining_class(NCContext ctx) {
  Parser *p = asParser(ctx);
  auto it = g_definingClassStacks.find(p);
  if (it == g_definingClassStacks.end() || it->second.empty())
    return; // unbalanced push/pop - should never happen if codegen is correct
  p->currentDefiningClass_ = it->second.back();
  it->second.pop_back();
}

/* ---- Array/matrix/dict/text helpers (see value_bridge.h) ---- */

void nc_bridge_value_set_text(Value *v, const char *s) {
  *v = Value(std::string(s ? s : ""));
}

void nc_bridge_array_from_elements(const Value *const *elements, int count, Value *out) {
  std::vector<Value> arr;
  arr.reserve(count > 0 ? static_cast<size_t>(count) : 0);
  for (int i = 0; i < count; ++i)
    arr.push_back(*elements[i]);
  *out = Value(arr);
}

void nc_bridge_matrix_from_rows(const Value *const *rows, int count, Value *out) {
  std::vector<std::vector<Value>> mat;
  mat.reserve(count > 0 ? static_cast<size_t>(count) : 0);
  for (int i = 0; i < count; ++i)
    mat.push_back(rows[i]->elems());
  *out = Value(mat);
}

int nc_bridge_index_get(const Value *receiver, const Value *const *keys, int keyCount, Value *out) {
  const Value &v = *receiver;

  if (v.isMatrix) {
    if (keyCount == 1) {
      if (keys[0] == nullptr) { // A[:] - whole matrix unchanged
        *out = v;
        return 0;
      }
      int row = static_cast<int>(keys[0]->number);
      if (row < 0 || static_cast<size_t>(row) >= v.rows())
        return 1;
      *out = Value(v.row(row));
      return 0;
    }
    if (keyCount == 2) {
      bool wildRow = (keys[0] == nullptr);
      bool wildCol = (keys[1] == nullptr);
      if (wildRow && wildCol) { // A[:,:] - whole matrix unchanged
        *out = v;
        return 0;
      }
      if (wildRow) { // A[:,col] - whole column, top to bottom
        int col = static_cast<int>(keys[1]->number);
        if (v.rows() == 0 || col < 0 || static_cast<size_t>(col) >= v.cols())
          return 1;
        std::vector<Value> colVec;
        for (size_t r = 0; r < v.rows(); r++)
          colVec.push_back(v.at(r, col));
        *out = Value(colVec);
        return 0;
      }
      if (wildCol) { // A[row,:] - whole row
        int row = static_cast<int>(keys[0]->number);
        if (row < 0 || static_cast<size_t>(row) >= v.rows())
          return 1;
        *out = Value(v.row(row));
        return 0;
      }
      int row = static_cast<int>(keys[0]->number);
      int col = static_cast<int>(keys[1]->number);
      if (row < 0 || static_cast<size_t>(row) >= v.rows() ||
          col < 0 || static_cast<size_t>(col) >= v.rowLength(row))
        return 1;
      *out = v.at(row, col);
      return 0;
    }
    return 1;
  }

  if (v.isArray) {
    if (keyCount != 1)
      return 1;
    if (keys[0] == nullptr) { // A[:] - whole array unchanged
      *out = v;
      return 0;
    }
    int idx = static_cast<int>(keys[0]->number);
    if (idx < 0 || static_cast<size_t>(idx) >= v.length())
      return 1;
    *out = v.at(idx);
    return 0;
  }

  if (!v.isDict || keyCount != 1 || keys[0] == nullptr)
    return 1;

  auto it = v.dict().find(bridgeDictKeyOf(*keys[0]));
  if (it == v.dict().end())
    return 1;
  *out = it->second;
  return 0;
}

int nc_bridge_index_set(NCContext ctx, const char *baseName, int baseSlot,
                         const Value *const *keys, int keyCount, const Value *val) {
  Parser *p = asParser(ctx);
  std::string name = baseName ? std::string(baseName) : std::string();

  if (keyCount == 2 && p->varExists(baseSlot, name) && p->varGet(baseSlot, name).isMatrix) {
    bool wildRow = (keys[0] == nullptr);
    bool wildCol = (keys[1] == nullptr);
    Value &mat = p->varRef(baseSlot, name);
    size_t nrows = mat.rows();
    size_t ncols = nrows ? mat.cols() : 0;

    if (wildRow && wildCol) // A[:,:] - no tree-walker meaning, same rejection
      return 1;

    if (wildCol) { // A[row,:] = value - replace the whole row
      int row = static_cast<int>(keys[0]->number);
      if (row < 0 || static_cast<size_t>(row) >= nrows)
        return 1;
      std::vector<Value> rowVec;
      if (val->isArray && val->length() == ncols)
        rowVec = val->elems();
      else if (val->isMatrix && val->rows() == 1 && val->cols() == ncols)
        rowVec = val->row(0);
      else
        return 1;
      mat.setRow(row, rowVec);
      return 0;
    }

    if (wildRow) { // A[:,col] = value - replace the whole column
      int col = static_cast<int>(keys[1]->number);
      if (col < 0 || static_cast<size_t>(col) >= ncols)
        return 1;
      std::vector<Value> colVec;
      if (val->isArray && val->length() == nrows) {
        colVec = val->elems();
      } else if (val->isMatrix && val->rows() == nrows && val->rows() != 0 &&
                 val->cols() == 1) {
        for (size_t r = 0; r < val->rows(); r++)
          colVec.push_back(val->at(r, 0));
      } else {
        return 1;
      }
      for (size_t r = 0; r < nrows; r++)
        mat.setAt(r, col, colVec[r]);
      return 0;
    }

    // A[row,col] = value - single element (comma form).
    int row = static_cast<int>(keys[0]->number);
    int col = static_cast<int>(keys[1]->number);
    if (row < 0 || static_cast<size_t>(row) >= nrows ||
        col < 0 || static_cast<size_t>(col) >= mat.rowLength(row))
      return 1;
    mat.setAt(row, col, *val);
    return 0;
  }

  if (keyCount == 1 && p->varExists(baseSlot, name) && p->varGet(baseSlot, name).isArray) {
    if (keys[0] == nullptr) // A[:] = value has no tree-walker write meaning
      return 1;
    Value &arr = p->varRef(baseSlot, name);
    int idx = static_cast<int>(keys[0]->number);
    if (idx < 0 || static_cast<size_t>(idx) >= arr.length())
      return 1;
    arr.setAt(idx, *val);
    return 0;
  }

  // Dict path: single key A['key']=v, or multi-key A[k1,k2,...]=[v1,v2,...]
  // (executeIndexAssign()'s multi-key dict assignment - keys.size() must
  // match val's array length, broadcasting element-wise). Auto-vivifies an
  // empty dict first if `name` doesn't exist yet, same as the tree-walker.
  for (int i = 0; i < keyCount; ++i)
    if (keys[i] == nullptr) // dict keys are never Wildcard
      return 1;

  if (!p->varExists(baseSlot, name)) {
    p->varSet(baseSlot, name, Value(std::unordered_map<std::string, Value>()));
  } else if (!p->varGet(baseSlot, name).isDict) {
    return 1;
  }

  if (keyCount == 1) {
    p->varRef(baseSlot, name).dictMut()[bridgeDictKeyOf(*keys[0])] = *val;
    return 0;
  }

  if (!val->isArray || static_cast<int>(val->length()) != keyCount)
    return 1;
  Value &dict = p->varRef(baseSlot, name);
  for (int i = 0; i < keyCount; ++i)
    dict.dictMut()[bridgeDictKeyOf(*keys[i])] = val->at(i);
  return 0;
}

/* ---- Class helpers (see value_bridge.h) ---- */

void nc_bridge_value_set_object(Value *v, const char *className) {
  *v = Value();
  v->isObject = true;
  v->classNameMut() = className ? std::string(className) : std::string();
}

int nc_bridge_field_get(NCContext ctx, const Value *receiver, const char *name, int slot, Value *out) {
  std::string n = name ? std::string(name) : std::string();

  if (!receiver->isObject) {
    // Elementwise dot operator (`A.B`, A not an object) - mirrors
    // evaluateExpr()'s ExprKind::FieldAccess fallback exactly: `name` is
    // reinterpreted as an ordinary variable name, not a field name.
    Parser *p = asParser(ctx);
    // readVariableOrConstant() itself prints its own error (e.g. "Unknown
    // constant") and sets evaluationSucceeded_=false on a bad name - the
    // tree-walker's FieldAccess case doesn't check that before its own
    // isMatrix check either, so a missing rhs variable prints BOTH that
    // error and "Dot operator requires two matrices" - replicated here
    // exactly rather than short-circuiting on it.
    Value rhs = p->readVariableOrConstant(n, slot);
    if (receiver->isMatrix && rhs.isMatrix) {
      *out = ElementWise(*receiver, rhs);
      return 0;
    }
    std::cerr << "Error: Dot operator requires two matrices\n";
    return 1;
  }

  // checkFieldAccess() prints its own "field '<n>' is private/protected in
  // class '<declaringClass>'" error and sets evaluationSucceeded_ = false
  // on denial - mirrors evaluateExpr()'s own `if (!checkFieldAccess(...))
  // return Value(0);` BEFORE the dictMap lookup exactly (parser_
  // factor.cpp). Relies on currentDefiningClass_ being correctly set for
  // the duration of a compiled method/constructor call - see
  // nc_bridge_push_defining_class's comment.
  Parser *pAccess = asParser(ctx);
  if (!pAccess->checkFieldAccess(receiver->className(), n))
    return 1;

  auto it = receiver->dict().find(n);
  if (it == receiver->dict().end())
    return 1;
  *out = it->second;
  return 0;
}

int nc_bridge_field_set(NCContext ctx, const char *baseName, int baseSlot,
                         const char *fieldName, const Value *val) {
  Parser *p = asParser(ctx);
  std::string name = baseName ? std::string(baseName) : std::string();
  std::string fname = fieldName ? std::string(fieldName) : std::string();
  // Mirrors executeAssignStmt()'s ExprKind::FieldAccess case exactly
  // (parser_exec_stmt.cpp), including its two distinct error messages -
  // a real, previously-accepted gap (this used to silently return 1 with
  // no message for either case).
  if (!p->varExists(baseSlot, name)) {
    std::cerr << "Error: '" << name << "' is not defined\n";
    p->evaluationSucceeded_ = false;
    return 1;
  }
  if (!p->varGet(baseSlot, name).isObject) {
    std::cerr << "Error: '" << name << "' is not an object\n";
    p->evaluationSucceeded_ = false;
    return 1;
  }
  // Same checkFieldAccess() gate as nc_bridge_field_get, in the same order
  // executeAssignStmt() uses it: after confirming the base exists and is
  // an object, before the actual write.
  if (!p->checkFieldAccess(p->varGet(baseSlot, name).className(), fname))
    return 1;
  p->varRef(baseSlot, name).dictMut()[fname] = *val;
  return 0;
}

/* ---- Native-scalar performance path helper (see value_bridge.h) ---- */

int nc_bridge_value_is_plain_number(const Value *v) {
  return (!v->isText && !v->isArray && !v->isMatrix && !v->isDict && !v->isObject &&
          !v->isComplex && v->dimL == 0 && v->dimT == 0 && v->dimM == 0)
             ? 1
             : 0;
}

/* ---- Dynamic call dispatch (see value_bridge.h) ---- */

int nc_bridge_call_dynamic(NCContext ctx, const char *name, const Value *const *argv, int argc,
                            Value *out) {
  Parser *p = asParser(ctx);
  std::vector<Value> args;
  args.reserve(argc > 0 ? static_cast<size_t>(argc) : 0);
  for (int i = 0; i < argc; ++i)
    args.push_back(*argv[i]);
  std::string n = name ? std::string(name) : std::string();

  // Same precedence as evaluateExpr()'s ExprKind::Call: classTable_ ->
  // functionTable_ -> callBuiltin(). Calling the REAL callClassConstructor/
  // callUserFunction (not a reimplementation) is what makes this correct
  // for inheritance/abstract/reversible/@rate classes and for any
  // function/class CodeGen never natively compiled - see value_bridge.h.
  //
  // `found` alone is NOT enough to mean "succeeded": callClassConstructor()/
  // callUserFunction() have a SECOND failure mode distinct from "name not
  // registered at all" - a registered name whose call still fails (abstract-
  // class instantiation rejected, a require/ensure failure inside the
  // constructor/function body, an unassigned declared output) leaves `found`
  // true but sets evaluationSucceeded_ = false. Missing this was a real bug,
  // reproduced directly (constructing an abstract class via JIT wrote a
  // bogus Value into the target variable instead of leaving it unassigned,
  // where the tree-walker correctly leaves it unset) - resetting
  // evaluationSucceeded_ = true first (these two functions are normally only
  // ever reached via evaluateExpr(), itself only ever reached via
  // executeStmt(), which resets this at the top of every statement - this
  // bridge calls them directly, bypassing that reset) and checking it
  // afterward, same as `found`, closes it.
  if (p->hasClass(n)) {
    bool found = false;
    p->evaluationSucceeded_ = true;
    *out = p->callClassConstructor(n, args, found);
    return (found && p->evaluationSucceeded_) ? 0 : 1;
  }
  if (p->hasFunction(n)) {
    bool found = false;
    p->evaluationSucceeded_ = true;
    *out = p->callUserFunction(n, args, found);
    return (found && p->evaluationSucceeded_) ? 0 : 1;
  }
  // feval/grad/taylor_series/green_integral - checked ahead of
  // callBuiltin() below, same precedence evaluateExpr()'s own
  // ExprKind::Call case gives this shared method. A real bug this closes:
  // without it, e.g. `fr = @f; grad(fr, [1,2,3]);` (the function reference
  // stored in a variable rather than written as a literal `@f` right at
  // the call site) compiled "successfully" as a generic dynamic-dispatch
  // call - `@f` written directly as the argument is itself an unsupported
  // codegen expression kind, which forces the WHOLE statement to fall
  // back to the tree-walker and accidentally reach the real
  // implementation, but a variable/array-index/etc. holding a function
  // reference is a perfectly ordinary, codegen-SUPPORTED expression, so
  // nothing forced that fallback - and this bridge never knew "grad" was
  // reserved, so it fell through to callBuiltin() and failed at runtime
  // with "Unknown function 'grad'". See tryReservedFunctionValueCall()'s
  // own comment (parser_factor.cpp) for the full history.
  {
    bool handledReserved = false;
    p->evaluationSucceeded_ = true;
    Value reservedResult = p->tryReservedFunctionValueCall(n, args, handledReserved);
    if (handledReserved) {
      *out = reservedResult;
      return p->evaluationSucceeded_ ? 0 : 1;
    }
  }
  // callBuiltin() is the exact same function evaluateExpr()'s ExprKind::
  // Call case calls (parser_factor.cpp) - not a reimplementation, so its
  // "Error: Unknown function '<name>'" stderr output and Value(0) fallback
  // for an unrecognized name come through unchanged.
  *out = callBuiltin(n, args);
  // g_lastVectorOk/g_lastStatsOk/g_lastGeometricOk/g_lastDcOk/
  // g_lastElementwiseOk: see vector.h/statistics.h/geometric.h/dc.h/
  // elementwise.h's own comments - a vector-, statistics-, geometric-,
  // dc-, or elementwise-routed builtin can be genuinely found yet still
  // reject its actual arguments. g_lastElementwiseOk in particular was
  // previously only ever checked on the binary-operator path
  // (parser_expression.cpp) - never here, on the function-CALL path -
  // so a scalar builtin routed through mapElementwise() (int()/round()/
  // rad2dec()/dec2rad() in dc.cpp, sin()/sqrt()/... elsewhere) that
  // rejected its input still printed the right error but let the call
  // silently "succeed" with Value(0) anyway. Confirmed by direct testing.
  return (g_lastBuiltinFound && g_lastVectorOk && g_lastStatsOk && g_lastGeometricOk &&
          g_lastDcOk && g_lastElementwiseOk && g_lastConditionalOk && g_lastPlotOk)
             ? 0
             : 1;
}

/* ---- Require/Ensure/ClearMemory (see value_bridge.h) ---- */

void nc_bridge_report_condition_failure(NCContext ctx, int isRequire, const char *conditionText) {
  std::cerr << "Error: " << (isRequire ? "precondition" : "postcondition")
            << " failed: " << (conditionText ? conditionText : "") << "\n";
  asParser(ctx)->evaluationSucceeded_ = false;
}

// Called from JIT-compiled code when a `while` statement exceeds
// kMaxWhileIterations (see ast.h). Prints the same error as the tree-walker's
// own While case in parser_exec_stmt.cpp, and the generated IR then breaks out
// of the loop, exactly like the interpreter's `break` after the same check.
//
// Deliberately leaves evaluationSucceeded_ TRUE rather than setting it false
// as the tree-walker does: the tree-walker's flag is reset at the top of every
// statement (executeStmt), so the false it leaves behind is gone by the very
// next statement - but compiled code only resets it once per top-level entry
// (see codegen.cpp's compileStatements). Leaving it false here would make
// every later Assign/publish in the same compiled loop silently skip - e.g.
// an outer loop's `o = o + 1` - and turn a capped inner loop into an endless
// outer one. Clearing it matches what the interpreter's next statement sees.
void nc_bridge_report_while_limit(NCContext ctx) {
  std::cerr << whileLimitErrorText();
  asParser(ctx)->evaluationSucceeded_ = true;
}

int nc_bridge_binary_op_checked(NCContext ctx, const char *op, const Value *a, const Value *b,
                                 Value *out) {
  Parser *p = asParser(ctx);
  std::string opStr = op ? std::string(op) : std::string();
  *out = p->evaluateBinaryOpValues(opStr, *a, *b);
  return p->evaluationSucceeded_ ? 0 : 1;
}

int nc_bridge_comparison_checked(NCContext ctx, const char *op, const Value *a, const Value *b,
                                  Value *out) {
  Parser *p = asParser(ctx);
  std::string opStr = op ? std::string(op) : std::string();
  *out = p->evaluateComparisonValues(opStr, *a, *b);
  return p->evaluationSucceeded_ ? 0 : 1;
}

void nc_bridge_report_index_set_failure(NCContext ctx, const char *baseName) {
  std::string name = baseName ? std::string(baseName) : std::string();
  std::cerr << "Error: index assignment out of range or invalid for '" << name << "'\n";
  asParser(ctx)->evaluationSucceeded_ = false;
}

void nc_bridge_clear_memory(NCContext ctx) { asParser(ctx)->clearMemoryAndPersist(); }

void nc_bridge_save_to_file(NCContext ctx) { asParser(ctx)->saveToFile(); }

void nc_bridge_signal_top_level_return(NCContext ctx) { asParser(ctx)->signalTopLevelReturn(); }

void nc_bridge_reset_evaluation_succeeded(NCContext ctx) { asParser(ctx)->evaluationSucceeded_ = true; }

int nc_bridge_get_evaluation_succeeded(NCContext ctx) {
  return asParser(ctx)->evaluationSucceeded_ ? 0 : 1;
}
