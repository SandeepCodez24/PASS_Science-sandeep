#include "../core/units.h"
#include "value_bridge.h"

#include "../../../compiler/compiler_src/conditional_opr/conditional_opr.h"
#include "../../../compiler/compiler_src/parser/parser.h"
#include "../builtins/builtins.h"
#include "../core/output.h"
#include "../core/elementwise.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/dc/dc.h"
#include "../ops/geometric/geometric.h"
#include "../ops/matrix/matrix.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/time/time.h"
#include "../ops/vector/vector.h"
#include "../Numpy/numpy_poly1d.h"

#include "../../execution/Interrupt.h"
#include "../../execution/analysis/analysis.h"
#include "../../execution/parallel/par.h"
#include "../../memory/governor.h"

#include <cmath>
#include <limits>
#include <deque>
#include <exception>
#include <new>
#include <stdexcept>
#include <iostream>
#include <unordered_map>
#include <vector>

namespace {

// Every bridge entry point that touches the Parser comes through here, so
// this is where Debug builds check that compiled code is on the interpreter
// thread (multicore rule 6 - see value_bridge.h). Release: nothing.
// The parser of the newest bridge call that had one: bridge functions without
// a context (logical operators, value builders) mark ITS statement failed.
Parser *g_lastParser = nullptr;

inline Parser *asParser(NCContext ctx) {
  nc::par::assertInterpreterThread("a JIT bridge call");
  g_lastParser = reinterpret_cast<Parser *>(ctx);
  return g_lastParser;
}

// No C++ exception may leave a bridge function (2026-11-23, docs/Large_Data_Design.md
// section 20): compiled code has no unwind tables the Windows unwinder can use, so an
// exception thrown through it ends nc.exe at once - no message, no crash report.
// Out of memory (std::bad_alloc, std::length_error) becomes the statement's error with
// the same text as Parser::executeStmt(); anything else goes to std::terminate() from
// here, still inside C++ frames, so the crash report runs as in the tree-walker.
void bridgeFailed(NCContext ctx, const std::exception &e) {
  std::cerr << "Error: " << nc::mem::outOfMemoryText(e) << "\n";
  Parser *p = ctx ? reinterpret_cast<Parser *>(ctx) : g_lastParser;
  if (p)
    p->evaluationSucceeded_ = false;
}

// See bridgeFailed(). NC_BRIDGE_CATCH(ctx, value): `ctx` (or nullptr) and the
// failure return value (nothing for a void function).
#define NC_BRIDGE_TRY try {
#define NC_BRIDGE_CATCH(ctx, ...)                                                                    \
  }                                                                                                  \
  catch (const std::bad_alloc &e) {                                                                  \
    bridgeFailed(ctx, e);                                                                            \
    return __VA_ARGS__;                                                                              \
  }                                                                                                  \
  catch (const std::length_error &e) {                                                               \
    bridgeFailed(ctx, e);                                                                            \
    return __VA_ARGS__;                                                                              \
  }                                                                                                  \
  catch (...) {                                                                                      \
    std::terminate();                                                                                \
  }

// Call-frame save/restore stack for nc_bridge_push_scope/pop_scope, keyed
// by Parser* - deliberately NOT a Parser member (parser.h is untouched by
// this whole codegen effort; this state exists purely to support generated
// code, so it lives entirely on the bridge side). One entry per currently-
// suspended (pushed but not yet popped) call on that Parser - .back() is
// always the innermost/most recent, matching normal LIFO call-frame
// nesting for recursion and nested calls.
struct SavedScope {
  std::unordered_map<std::string, Value> memory;
  std::vector<std::string> insertionOrder;
};
// A deque, not a vector: Parser::enterLocalScope() keeps a pointer to the
// outermost saved scope (the global workspace) for the whole call, and a
// deque never moves its existing elements when it grows.
std::unordered_map<Parser *, std::deque<SavedScope>> g_scopeStacks;

// Same LIFO save/restore idiom as g_scopeStacks, for Parser::
// currentDefiningClass_ - see nc_bridge_push_defining_class's comment.
std::unordered_map<Parser *, std::vector<std::string>> g_definingClassStacks;

inline bool dimsMatch(const Value &v, const Value &r) {
  return v.dimL == r.dimL && v.dimT == r.dimT && v.dimM == r.dimM;
}

// Mirrors evaluateBinaryOp() (parser_expression.cpp): false for a text
// operand, true (v untouched) for anything else - safe to call
// unconditionally. Until 2026-10-28 this read numeric text as its number;
// now text is never read as a number in an operator ("5" + 1 is an error -
// see textOperandError() there). The JIT only reaches these per-operator
// bridges with two plain numbers anyway (codegen's both_plain fast path)
// and sends everything else to the checked bridges.
inline bool coerceTextInPlace(Value &v) {
  return !v.isText;
}

// Faithful copy of dictKeyOf() (parser_statement.cpp) - not reused
// directly because it's declared in parser_internal.h, which documents
// itself as "only parser_*.cpp files should include this", not part of
// the public Parser API this bridge otherwise builds on. formatNumber()
// (the one piece of real formatting logic involved) IS reused as-is, via
// output.h, already included above.
inline std::string bridgeDictKeyOf(const Value &key) {
  return key.isText ? key.text() : formatNumber(key.number);
}

// JIT index keys -> the shared matrix-indexing form. A null key is a
// Wildcard (':' or an empty key); codegen never passes a Slice (a statement
// containing one is left to the tree-walker).
bool bridgeMatKeys(const Value *const *keys, int keyCount, std::vector<MatIndexKey> &out,
                   std::string &err) {
  out.clear();
  for (int i = 0; i < keyCount; ++i) {
    MatIndexKey key;
    if (keys[i] == nullptr) {
      key.kind = MatIndexKey::All;
    } else {
      Value k = *keys[i];
      if (k.isMatrix && k.rows() == 1 && k.cols() == 1)
        k = k.at(0, 0);
      if (k.isText || k.isArray || k.isMatrix || k.isDict || k.isObject || k.isFunctionRef ||
          k.hasComplex()) {
        err = "an index must be a whole number or a range like 2:5 - got a value of shape " +
              matShapeText(k);
        return false;
      }
      key.kind = MatIndexKey::Scalar;
      key.scalar = k.number;
    }
    out.push_back(key);
  }
  return true;
}

// Shared by nc_bridge_lt/gt/lte/gte - mirrors evaluateComparison()'s
// ordering guard (parser_expression.cpp): both operands orderable and the
// same kind.
inline bool orderable(const Value &v, const Value &r) {
  return valueIsOrderable(v) && valueIsOrderable(r) && valueKindOf(v) == valueKindOf(r);
}

} // namespace

/* ---- BinaryOp ---- */

// None of +,-,*,/,%,//,^ mean anything for arbitrary text - mirrors the
// isText handling in Parser::evaluateBinaryOp() (parser_expression.cpp):
// without it, a text operand silently fell through to reading its
// .number (0 for any text Value), giving a plausible-looking but
// meaningless answer (0, or 0/0=NaN for division/mod). Text that's
// actually a dec2frac()-style fraction (or a plain decimal as text) is
// coerced to its number first via coerceTextInPlace(); only genuinely
// non-numeric text still returns the same nonzero-means-invalid-operands
// signal dimsMatch() already uses for a dimension mismatch.
int nc_bridge_add(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv) || !dimsMatch(av, bv))
      return 1;
    *out = add(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_sub(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv) || !dimsMatch(av, bv))
      return 1;
    *out = sub(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_mul(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
      return 1;
    *out = mul(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_div(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
      return 1;
    *out = div_op(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_mod(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
      return 1;
    *out = mod_op(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_floordiv(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    // Was a standalone `std::floor(a->number/b->number)` (2026-09-22 fix):
    // unlike every other bridge function above, it never delegated to a
    // shared arithmetic.cpp function, so it never got the array/matrix
    // isArray/isMatrix handling those got - an array/matrix Value's .number
    // defaults to 0, so a JIT-compiled `A//2` on an array silently returned
    // 0 while the exact same expression as a non-JIT'd sub-expression (e.g.
    // as a publish() argument, which the JIT doesn't compile) correctly
    // returned the elementwise result via floor_div(). Delegating to the one
    // real implementation (now also used by evaluateBinaryOp()'s "//" case)
    // fixes the JIT path and removes the duplicate logic.
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
      return 1;
    *out = floor_div(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_pow(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    Value av = *a, bv = *b;
    if (!coerceTextInPlace(av) || !coerceTextInPlace(bv))
      return 1;
    *out = power(av, bv);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

/* ---- UnaryOp ----
   No standalone free function exists for unary "-" - evaluateExpr()'s
   UnaryOp case (parser_factor.cpp) implements it inline (array/matrix
   elementwise negation, else negate .number while preserving unit
   dimensions). Both now call the one negate_op() in arithmetic.cpp. */

int nc_bridge_neg_checked(NCContext ctx, const Value *a, Value *out) {
  NC_BRIDGE_TRY
    int rc = nc_bridge_neg(a, out);
    if (rc != 0)
      asParser(ctx)->evaluationSucceeded_ = false;
    return rc;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_not_checked(NCContext ctx, const Value *a, Value *out) {
  NC_BRIDGE_TRY
    int rc = nc_bridge_not(a, out);
    if (rc != 0)
      asParser(ctx)->evaluationSucceeded_ = false;
    return rc;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_factorial_checked(NCContext ctx, const Value *a, Value *out) {
  NC_BRIDGE_TRY
    int rc = nc_bridge_factorial(a, out);
    if (rc != 0)
      asParser(ctx)->evaluationSucceeded_ = false;
    return rc;
  NC_BRIDGE_CATCH(ctx, 1)
}

// The tree-walker's message for a unary operator that has no N-D meaning.
static int ndUnaryUnsupported(const char *what, const Value *a, Value *out) {
  std::cerr << "Error: " << what << " is not supported for N-D matrices yet (got a "
            << matShapeText(*a) << " matrix)\n";
  *out = Value(0);
  return 1;
}

int nc_bridge_neg(const Value *a, Value *out) {
  NC_BRIDGE_TRY
    // N-D: element by element, the same ndNegate() the tree-walker uses.
    if (a->isND()) {
      std::string err;
      g_lastElementwiseOk = true;
      if (!ndNegate(*a, *out, err)) {
        std::cerr << "Error: " << err << "\n";
        *out = Value(0);
        return 1;
      }
      // Stop pressed inside the multicore kernel: the half-negated result is
      // discarded, as in evaluateExpr()'s UnaryOp case.
      if (!g_lastElementwiseOk) {
        *out = Value(0);
        return 1;
      }
      return 0;
    }
    // Mirrors the interpreter's UnaryOp "-" (parser_factor.cpp): -d of a
    // duration, -t an error.
    if (nctime::containsTime(*a)) {
      std::string err;
      if (!nctime::timeNegate(*a, *out, err)) {
        nctime::reportTimeError(err);
        *out = Value(0);
        return 1;
      }
      return 0;
    }
    // Text is never read as a number (2026-10-28).
    if (a->isText) {
      std::cerr << "Error: '-' (negation) is not defined for text - convert it first, "
                   "e.g. -float(\""
                << a->text() << "\")\n";
      *out = Value(0);
      return 1;
    }
    *out = negate_op(*a);
    // negate_op() reports an integer that has no negation in its type
    // (-int8(-128)) through g_lastElementwiseOk.
    return g_lastElementwiseOk ? 0 : 1;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_not(const Value *a, Value *out) {
  NC_BRIDGE_TRY
    if (a->isND())
      return ndUnaryUnsupported("'!' (not)", a, out);
    *out = toBoolResult(logical_not(*a));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_factorial(const Value *a, Value *out) {
  NC_BRIDGE_TRY
    // Mirrors evaluateExpr()'s UnaryOp "!post" case (parser_factor.cpp):
    // factorial of a unit-bearing quantity is rejected rather than silently
    // computed from the raw .number (which used to give (5*m)! = 120,
    // discarding the unit). Text that's actually a dec2frac()-style
    // fraction (or a plain decimal as text) is coerced to its number first
    // via coerceTextInPlace(); only genuinely non-numeric text ("abc"!)
    // still returns the same nonzero-return-means-dimension/type-failure
    // convention as nc_bridge_add's dimsMatch() check.
    if (a->isND())
      return ndUnaryUnsupported("'!' (factorial)", a, out);
    Value av = *a;
    if (nctime::containsTime(av)) {
      nctime::reportTimeError("operator '!' is not defined for timestamps and durations");
      return 1;
    }
    if (av.hasComplex()) {
      std::cerr << "Error: '!' (factorial) is not defined for complex numbers\n";
      return 1;
    }
    if (av.isText) {
      std::cerr << "Error: '!' (factorial) requires a number, not text - convert it first, "
                   "e.g. float(\""
                << av.text() << "\")!\n";
      return 1;
    }
    if (av.dimL != 0 || av.dimT != 0 || av.dimM != 0)
      return 1;
    *out = factorial(av);
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_abs_or_norm(const Value *a, Value *out) {
  NC_BRIDGE_TRY
    // Same abs_or_norm() evaluateExpr()'s AbsOrNorm case calls: matrix ->
    // determinant, array -> vector norm, else scalar absolute value.
    // |d| of a duration: element by element (evaluateExpr()'s AbsOrNorm case).
    if (nctime::containsTime(*a)) {
      std::string err;
      if (!nctime::timeAbs(*a, *out, err)) {
        nctime::reportTimeError(err);
        *out = Value(0);
        return 1;
      }
      return 0;
    }
    if (a->isND())
      return ndUnaryUnsupported("|B| (absolute value / norm / determinant)", a, out);
    bool ok = true;
    // Same vector rule as evaluateExpr()'s AbsOrNorm case.
    Value inner = (matIsVectorShape(*a) && a->rows() * a->cols() > 1) ? matVectorAsArray(*a) : *a;
    // Same unit rule as evaluateExpr()'s AbsOrNorm case (core/units.h): |x|
    // and |v| keep the unit, the determinant of an n x n matrix has unit^n.
    const nc::units::Dim unit = nc::units::unitOf(inner);
    const int power = inner.isMatrix && inner.rows() > 1 ? static_cast<int>(inner.rows()) : 1;
    *out = abs_or_norm(unit.zero() ? inner : nc::units::stripped(inner), ok);
    if (!ok)
      return 1;
    if (!unit.zero()) {
      std::string err;
      if (!nc::units::attach(*out, {unit.l * power, unit.t * power, unit.m * power}, err)) {
        std::cerr << "Error: " << err << "\n";
        *out = Value(0);
        return 1;
      }
    }
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

/* ---- Comparison ---- */

int nc_bridge_eq(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    if (!dimsMatch(*a, *b))
      return 1;
    *out = toBoolResult(logical_eq(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_neq(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    if (!dimsMatch(*a, *b))
      return 1;
    *out = toBoolResult(logical_neq(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_lt(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    if (!dimsMatch(*a, *b) || !orderable(*a, *b))
      return 1;
    *out = toBoolResult(logical_lt(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_gt(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    if (!dimsMatch(*a, *b) || !orderable(*a, *b))
      return 1;
    *out = toBoolResult(logical_gt(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_lte(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    if (!dimsMatch(*a, *b) || !orderable(*a, *b))
      return 1;
    *out = toBoolResult(logical_lte(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_gte(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    if (!dimsMatch(*a, *b) || !orderable(*a, *b))
      return 1;
    *out = toBoolResult(logical_gte(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

/* ---- LogicalOp ---- */

int nc_bridge_logical_and(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    *out = toBoolResult(logical_and(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_logical_or(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    *out = toBoolResult(logical_or(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_logical_nand(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    *out = toBoolResult(logical_nand(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_logical_nor(const Value *a, const Value *b, Value *out) {
  NC_BRIDGE_TRY
    *out = toBoolResult(logical_nor(*a, *b));
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

/* ---- Context-dependent ---- */

int nc_bridge_var_read(NCContext ctx, const char *name, int slot, Value *out) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::string n = name ? std::string(name) : std::string();
    // Deliberately does NOT reset evaluationSucceeded_ = true before reading
    // (readVariableOrConstant() itself never touches it on a successful
    // lookup - only sets it false on failure, same as the tree-walker). A
    // reset here used to silently ERASE a real earlier failure in the same
    // call chain - concretely, a compiled function's epilogue reading its
    // declared output back out (nc_bridge_var_read, called unconditionally)
    // would wipe out a require/ensure failure from earlier in that same
    // body, right before the caller could ever observe it via
    // nc_bridge_get_evaluation_succeeded() - a real bug, found and fixed
    // together with that function; see its own comment.
    *out = p->readVariableOrConstant(n, slot);
    return p->evaluationSucceeded_ ? 0 : 1;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_var_write(NCContext ctx, const char *name, int slot, const Value *v) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::string n = name ? std::string(name) : std::string();
    p->varSet(slot, n, *v);
    return 0;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_read_declared_output(NCContext ctx, const char *outName, const char *ownerName,
                                    int isMethod, Value *out) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    // The body was stopped by an error (already printed): the call has no
    // result and fails quietly - no follow-on "output not assigned" error.
    // Same as invokeFunctionBody()'s errorAbort_ check.
    if (p->errorAbort_) {
      p->evaluationSucceeded_ = false;
      return 1;
    }
    std::string on = outName ? std::string(outName) : std::string();
    if (p->varExists(-1, on)) {
      *out = p->varGet(-1, on);
      return 0;
    }
    std::cerr << "Error: output '" << on << "' not assigned in " << (isMethod ? "method" : "function")
              << " '" << (ownerName ? ownerName : "") << "'\n";
    p->evaluationSucceeded_ = false;
    return 1;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_publish(const Value *v) {
  NC_BRIDGE_TRY
    // Mirrors executeStmt()'s StmtKind::Publish case for the single-argument
    // shape exactly (parser_exec_stmt.cpp): text prints raw, everything else
    // goes through valueToString(), one trailing newline.
    if (v->isText)
      std::cout << v->text();
    else
      std::cout << printText(*v); // a big value: its summary (2026-11-23)
    std::cout << std::endl;
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

void nc_bridge_print_value(const char *name, const Value *v) {
  NC_BRIDGE_TRY
    printValue(name ? std::string(name) : std::string(), *v);
  NC_BRIDGE_CATCH(nullptr)
}

/* ---- Value lifetime helpers (see value_bridge.h) ---- */

Value *nc_bridge_value_create() {
  // Every compiled expression creates its result slot here first, so this
  // also covers the context-free operator bridges (multicore rule 6).
  nc::par::assertInterpreterThread("a JIT bridge call");
  return new Value();
}

void nc_bridge_value_destroy(Value *v) { delete v; }

void nc_bridge_value_set_number(Value *v, double n) { *v = Value(n); }
void nc_bridge_value_set_imaginary(Value *v, double im) { *v = Value::complexNumber(0.0, im); }
void nc_bridge_value_set_bool(Value *v, int b) { *v = Value::boolean(b != 0); }

/* ---- Control-flow helpers (see value_bridge.h) ---- */

int nc_bridge_truthy(const Value *v) {
  NC_BRIDGE_TRY
    // Was its own hardcoded copy of the pre-fix truthy() logic (text:
    // non-empty; anything else: number != 0) - the exact same "JIT path has
    // a stale, separately-maintained duplicate" bug class found repeatedly
    // this session. Once parser_exec_stmt.cpp's truthy() was fixed to
    // delegate to valueIsTruthy() (treating a non-empty array/matrix/dict
    // as true, matching and()/or()/is_true()/... elsewhere in this same
    // fix pass), this JIT bridge function silently fell out of step: a
    // JIT-compiled `if (someArray)` still evaluated an array/dict condition
    // as false regardless of its contents, while the tree-walker correctly
    // evaluated the identical condition as true. Confirmed by direct
    // testing (disabling JIT made the same script's `if` take the opposite
    // branch). Now delegates to the same single definition.
    return valueIsTruthy(*v) ? 1 : 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

double nc_bridge_get_number(const Value *v) { return v->number; }

int nc_bridge_range_should_continue(double current, double step, double end, int rightInclusive) {
  const double eps = 1e-9;
  if (step > 0)
    return (rightInclusive ? (current <= end + eps) : (current < end - eps)) ? 1 : 0;
  return (rightInclusive ? (current >= end - eps) : (current > end + eps)) ? 1 : 0;
}

/* ---- Call-frame helpers (see value_bridge.h) ---- */

int nc_bridge_push_scope(NCContext ctx) {
  Parser *p = asParser(ctx);
  SavedScope saved;
  saved.memory = std::move(p->memory);
  saved.insertionOrder = std::move(p->insertionOrder);
  p->memory.clear();
  p->insertionOrder.clear();
  auto &stack = g_scopeStacks[p];
  stack.push_back(std::move(saved));
  p->enterLocalScope(&stack.back().memory, &stack.back().insertionOrder);
  return 0;
}

int nc_bridge_pop_scope(NCContext ctx) {
  Parser *p = asParser(ctx);
  auto it = g_scopeStacks.find(p);
  if (it == g_scopeStacks.end() || it->second.empty())
    return 1; // unbalanced push/pop - should never happen if codegen is correct
  SavedScope &saved = it->second.back();
  p->leaveLocalScope();
  p->memory = std::move(saved.memory);
  p->insertionOrder = std::move(saved.insertionOrder);
  it->second.pop_back();
  return 0;
}

void nc_bridge_push_defining_class(NCContext ctx, const char *className) {
  Parser *p = asParser(ctx);
  g_definingClassStacks[p].push_back(p->currentDefiningClass_);
  p->currentDefiningClass_ = className ? std::string(className) : std::string();
}

void nc_bridge_pop_defining_class(NCContext ctx) {
  Parser *p = asParser(ctx);
  auto it = g_definingClassStacks.find(p);
  if (it == g_definingClassStacks.end() || it->second.empty())
    return; // unbalanced push/pop - should never happen if codegen is correct
  p->currentDefiningClass_ = it->second.back();
  it->second.pop_back();
}

/* ---- Array/matrix/dict/text helpers (see value_bridge.h) ---- */

void nc_bridge_value_set_text(Value *v, const char *s) {
  NC_BRIDGE_TRY
    *v = Value(std::string(s ? s : ""));
  NC_BRIDGE_CATCH(nullptr)
}

void nc_bridge_array_from_elements(const Value *const *elements, int count, Value *out) {
  NC_BRIDGE_TRY
    std::vector<Value> arr;
    arr.reserve(count > 0 ? static_cast<size_t>(count) : 0);
    for (int i = 0; i < count; ++i)
      arr.push_back(*elements[i]);
    *out = Value(arr);
  NC_BRIDGE_CATCH(nullptr)
}

void nc_bridge_matrix_from_rows(const Value *const *rows, int count, Value *out) {
  NC_BRIDGE_TRY
    std::vector<std::vector<Value>> cells;
    cells.reserve(count > 0 ? static_cast<size_t>(count) : 0);
    for (int i = 0; i < count; ++i)
      cells.push_back(rows[i]->elems());
    std::string err;
    if (!matBuildFromCells(cells, *out, err))
      *out = Value(0);
  NC_BRIDGE_CATCH(nullptr)
}

int nc_bridge_matrix_build_checked(NCContext ctx, const Value *const *rows, int count, Value *out) {
  NC_BRIDGE_TRY
    std::vector<std::vector<Value>> cells;
    cells.reserve(count > 0 ? static_cast<size_t>(count) : 0);
    for (int i = 0; i < count; ++i)
      cells.push_back(rows[i]->elems());
    std::string err;
    if (matBuildFromCells(cells, *out, err))
      return 0;
    std::cerr << "Error: " << err << "\n";
    asParser(ctx)->evaluationSucceeded_ = false;
    *out = Value(0);
    return 1;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_transpose_checked(NCContext ctx, const Value *a, Value *out) {
  NC_BRIDGE_TRY
    if (a->isND()) {
      std::cerr << "Error: ' (transpose) is defined for 2-D matrices - transpose a 2-D slab such "
                   "as B[0]' (got a "
                << matShapeText(*a) << " matrix)\n";
      asParser(ctx)->evaluationSucceeded_ = false;
      *out = Value(0);
      return 1;
    }
    if (a->isDict || a->isObject || a->isFunctionRef) {
      std::cerr << "Error: ' (transpose) needs a number or a matrix\n";
      asParser(ctx)->evaluationSucceeded_ = false;
      *out = Value(0);
      return 1;
    }
    *out = matTransposeValue(*a);
    return 0;
  NC_BRIDGE_CATCH(ctx, 1)
}

// Silent form (kept for existing callers): status only, no message.
int nc_bridge_index_get(const Value *receiver, const Value *const *keys, int keyCount, Value *out) {
  NC_BRIDGE_TRY
    const Value &v = *receiver;

    if (v.isMatrix || v.isArray) {
      std::vector<MatIndexKey> mk;
      std::string err;
      if (!bridgeMatKeys(keys, keyCount, mk, err) || !matIndexGet(v, mk, "", *out, err))
        return 1;
      return 0;
    }

    if (nc::numpy::isPoly1d(v)) {
      std::string err;
      return (keyCount == 1 && keys[0] != nullptr &&
              nc::numpy::poly1dCoefficientOf(v, *keys[0], *out, err))
                 ? 0
                 : 1;
    }
    if (!v.isDict || keyCount != 1 || keys[0] == nullptr)
      return 1;

    auto it = v.dict().find(bridgeDictKeyOf(*keys[0]));
    if (it == v.dict().end())
      return 1;
    *out = it->second;
    return 0;
  NC_BRIDGE_CATCH(nullptr, 1)
}

int nc_bridge_index_get_checked(NCContext ctx, const char *name, const Value *receiver,
                                const Value *const *keys, int keyCount, Value *out) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    const std::string n = name ? std::string(name) : std::string();
    const Value &v = *receiver;
    auto fail = [&](const std::string &msg) {
      std::cerr << "Error: " << msg << "\n";
      p->evaluationSucceeded_ = false;
      *out = Value(0);
      return 1;
    };

    // Same order and messages as evaluateExpr()'s ExprKind::Index case.
    if (v.isMatrix || v.isArray) {
      std::vector<MatIndexKey> mk;
      std::string err;
      if (!bridgeMatKeys(keys, keyCount, mk, err) || !matIndexGet(v, mk, n, *out, err))
        return fail(err);
      return 0;
    }
    // P[k] on a poly1d - as evaluateExpr()'s ExprKind::Index.
    if (nc::numpy::isPoly1d(v)) {
      if (keyCount != 1 || keys[0] == nullptr)
        return fail(n + "[k] on a poly1d takes one whole number k");
      std::string err;
      if (!nc::numpy::poly1dCoefficientOf(v, *keys[0], *out, err))
        return fail(err);
      return 0;
    }
    // s[i] / s[a:b] on text - as evaluateExpr()'s ExprKind::Index: the text
    // as a vector of characters (UTF-8 code points).
    if (v.isText) {
      if (keyCount != 1)
        return fail("text takes one index - " + n + "[i] or " + n + "[a:b]");
      std::vector<Value> chars;
      const std::string &s = v.text();
      for (size_t i = 0; i < s.size();) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
        len = std::min(len, s.size() - i);
        chars.push_back(Value(s.substr(i, len)));
        i += len;
      }
      std::vector<MatIndexKey> mk;
      std::string err;
      Value picked;
      if (!bridgeMatKeys(keys, keyCount, mk, err) ||
          !matIndexGet(Value(std::move(chars)), mk, n, picked, err)) {
        const size_t at = err.find(" elements");
        if (at != std::string::npos)
          err.replace(at, 9, " characters");
        return fail(err);
      }
      if (picked.isText) {
        *out = picked;
        return 0;
      }
      std::string joined;
      for (const Value &ch : matVectorAsArray(picked).elems())
        joined += ch.text();
      *out = Value(joined);
      return 0;
    }
    if (!v.isDict)
      return fail("'" + n + "' is a " + valueKindName(v) +
                  " and cannot be indexed - only matrices, arrays, text and dicts can");
    if (keyCount != 1 || keys[0] == nullptr)
      return fail("dict '" + n + "' read takes exactly one key");
    const std::string k = bridgeDictKeyOf(*keys[0]);
    auto it = v.dict().find(k);
    if (it == v.dict().end())
      return fail("KeyError: dict key '" + k + "' not found in '" + n + "'");
    *out = it->second;
    return 0;
  NC_BRIDGE_CATCH(ctx, 1)
}

// Mirrors executeIndexAssign() (parser_exec_stmt.cpp): the same matrix /
// array rules (ops/matrix/matrix_index.h, including growth and creating a
// new matrix), the same dict decision, the same messages. Reports its own
// error and marks the statement failed; nc_bridge_report_index_set_failure
// then only has to keep the flag set.
int nc_bridge_index_set(NCContext ctx, const char *baseName, int baseSlot,
                         const Value *const *keys, int keyCount, const Value *val) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::string name = baseName ? std::string(baseName) : std::string();
    auto fail = [&](const std::string &msg) {
      std::cerr << "Error: " << msg << "\n";
      p->evaluationSucceeded_ = false;
      return 1;
    };

    const bool exists = p->varExists(baseSlot, name);
    bool anyWild = false, anyText = false;
    for (int i = 0; i < keyCount; ++i) {
      if (keys[i] == nullptr)
        anyWild = true;
      else if (keys[i]->isText)
        anyText = true;
    }
    const bool dictPath =
        exists ? p->varGet(baseSlot, name).isDict : (!anyWild && anyText);

    if (!dictPath) {
      std::vector<MatIndexKey> mk;
      std::string err;
      if (!bridgeMatKeys(keys, keyCount, mk, err))
        return fail(err);
      if (exists) {
        if (!matIndexSet(p->varRef(baseSlot, name), true, mk, *val, name, err))
          return fail(err);
      } else {
        Value created;
        if (!matIndexSet(created, false, mk, *val, name, err))
          return fail(err);
        p->varSet(baseSlot, name, created);
      }
      return 0;
    }

    if (anyWild)
      return fail("':' is not a dict key - '" + name + "' is a dict");

    if (!exists)
      p->varSet(baseSlot, name, Value(std::unordered_map<std::string, Value>()));

    if (keyCount == 1) {
      p->varRef(baseSlot, name).dictMut()[bridgeDictKeyOf(*keys[0])] = *val;
      return 0;
    }

    Value vals = matVectorAsArray(*val);
    if (!vals.isArray || static_cast<int>(vals.length()) != keyCount)
      return fail("multi-key dict assignment expects " + std::to_string(keyCount) + " values, e.g. " +
                  name + "['a','b'] = [1,2]");
    Value &dict = p->varRef(baseSlot, name);
    for (int i = 0; i < keyCount; ++i)
      dict.dictMut()[bridgeDictKeyOf(*keys[i])] = vals.at(i);
    return 0;
  NC_BRIDGE_CATCH(ctx, 1)
}

/* ---- Class helpers (see value_bridge.h) ---- */

void nc_bridge_value_set_object(Value *v, const char *className) {
  NC_BRIDGE_TRY
    *v = Value();
    v->isObject = true;
    v->classNameMut() = className ? std::string(className) : std::string();
  NC_BRIDGE_CATCH(nullptr)
}

int nc_bridge_field_get(NCContext ctx, const Value *receiver, const char *name, int slot, Value *out) {
  NC_BRIDGE_TRY
    std::string n = name ? std::string(name) : std::string();

    // d.key reads a dict entry, like d["key"] (2026-10-28) - same rule as
    // evaluateExpr()'s FieldAccess case.
    if (receiver->isDict && !receiver->isObject) {
      auto it = receiver->dict().find(n);
      if (it == receiver->dict().end()) {
        std::cerr << "Error: the dict has no key '" << n << "'\n";
        asParser(ctx)->evaluationSucceeded_ = false;
        return 1;
      }
      *out = it->second;
      return 0;
    }

    if (!receiver->isObject) {
      // Elementwise dot operator (`A.B`, A not an object) - mirrors
      // evaluateExpr()'s ExprKind::FieldAccess fallback exactly: `name` is
      // reinterpreted as an ordinary variable name, not a field name.
      Parser *p = asParser(ctx);
      // readVariableOrConstant() itself prints its own error (e.g. "Unknown
      // constant") and sets evaluationSucceeded_=false on a bad name - the
      // tree-walker's FieldAccess case doesn't check that before its own
      // isMatrix check either, so a missing rhs variable prints BOTH that
      // error and "Dot operator requires two matrices" - replicated here
      // exactly rather than short-circuiting on it.
      // The old element-wise dot operator `A.B` was replaced by A*.B -
      // same message as evaluateExpr()'s FieldAccess case.
      (void)slot;
      std::cerr << "Error: '." << n << "' - '.' reads a field of an object, and the value on its "
                << "left is " << (receiver->isMatrix ? "a matrix" : "not an object")
                << ". For element-wise multiplication use *. (e.g. A*.B)\n";
      p->evaluationSucceeded_ = false;
      return 1;
    }

    // checkFieldAccess() prints its own "field '<n>' is private/protected in
    // class '<declaringClass>'" error and sets evaluationSucceeded_ = false
    // on denial - mirrors evaluateExpr()'s own `if (!checkFieldAccess(...))
    // return Value(0);` BEFORE the dictMap lookup exactly (parser_
    // factor.cpp). Relies on currentDefiningClass_ being correctly set for
    // the duration of a compiled method/constructor call - see
    // nc_bridge_push_defining_class's comment.
    Parser *pAccess = asParser(ctx);
    if (!pAccess->checkFieldAccess(receiver->className(), n))
      return 1;

    auto it = receiver->dict().find(n);
    if (it == receiver->dict().end())
      return 1;
    *out = it->second;
    return 0;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_field_set(NCContext ctx, const char *baseName, int baseSlot,
                         const char *fieldName, const Value *val) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::string name = baseName ? std::string(baseName) : std::string();
    std::string fname = fieldName ? std::string(fieldName) : std::string();
    // Mirrors executeAssignStmt()'s ExprKind::FieldAccess case exactly
    // (parser_exec_stmt.cpp), including its two distinct error messages -
    // a real, previously-accepted gap (this used to silently return 1 with
    // no message for either case).
    if (!p->varExists(baseSlot, name)) {
      std::cerr << "Error: '" << name << "' is not defined\n";
      p->evaluationSucceeded_ = false;
      return 1;
    }
    if (!p->varGet(baseSlot, name).isObject) {
      std::cerr << "Error: '" << name << "' is not an object\n";
      p->evaluationSucceeded_ = false;
      return 1;
    }
    // Same checkFieldAccess() gate as nc_bridge_field_get, in the same order
    // executeAssignStmt() uses it: after confirming the base exists and is
    // an object, before the actual write.
    if (!p->checkFieldAccess(p->varGet(baseSlot, name).className(), fname))
      return 1;
    p->varRef(baseSlot, name).dictMut()[fname] = *val;
    return 0;
  NC_BRIDGE_CATCH(ctx, 1)
}

/* ---- Native-scalar performance path helper (see value_bridge.h) ---- */

int nc_bridge_value_is_plain_number(const Value *v) {
  // A bool, a fixed-width integer or a float8/16/32 is not "plain": the
  // native fast path computes in doubles and would turn int64 arithmetic
  // into float64 (skipping its overflow checks) or a float32 into float64,
  // so those take the checked bridge instead.
  // A timestamp / duration (ops/time/) is not plain either: its `number`
  // is NaN, and time arithmetic has its own rules (the checked bridge).
  return (!v->isText && !v->isArray && !v->isMatrix && !v->isDict && !v->isObject &&
          !v->isComplex && !v->isBool() && !v->isInt() && !v->isTime() &&
          v->floatType() == FloatType::Float64 && v->dimL == 0 && v->dimT == 0 &&
          v->dimM == 0)
             ? 1
             : 0;
}

/* ---- Dynamic call dispatch (see value_bridge.h) ---- */

int nc_bridge_call_dynamic(NCContext ctx, const char *name, const Value *const *argv, int argc,
                            Value *out) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::vector<Value> args;
    args.reserve(argc > 0 ? static_cast<size_t>(argc) : 0);
    for (int i = 0; i < argc; ++i)
      args.push_back(*argv[i]);
    std::string n = name ? std::string(name) : std::string();

    p->bindScipyCallbacks();
    // Same precedence as evaluateExpr()'s ExprKind::Call: classTable_ ->
    // functionTable_ -> callBuiltin(). Calling the REAL callClassConstructor/
    // callUserFunction (not a reimplementation) is what makes this correct
    // for inheritance/abstract/reversible/@rate classes and for any
    // function/class CodeGen never natively compiled - see value_bridge.h.
    //
    // `found` alone is NOT enough to mean "succeeded": callClassConstructor()/
    // callUserFunction() have a SECOND failure mode distinct from "name not
    // registered at all" - a registered name whose call still fails (abstract-
    // class instantiation rejected, a require/ensure failure inside the
    // constructor/function body, an unassigned declared output) leaves `found`
    // true but sets evaluationSucceeded_ = false. Missing this was a real bug,
    // reproduced directly (constructing an abstract class via JIT wrote a
    // bogus Value into the target variable instead of leaving it unassigned,
    // where the tree-walker correctly leaves it unset) - resetting
    // evaluationSucceeded_ = true first (these two functions are normally only
    // ever reached via evaluateExpr(), itself only ever reached via
    // executeStmt(), which resets this at the top of every statement - this
    // bridge calls them directly, bypassing that reset) and checking it
    // afterward, same as `found`, closes it.
    // P(x) on a poly1d held in a script variable - the same check, first,
    // as evaluateExpr()'s ExprKind::Call (locals of a function never get
    // here: codegen leaves those calls to the tree-walker).
    if (p->varExists(-1, n)) {
      const Value callee = p->varGet(-1, n);
      // f(x) where the variable f holds a function reference - as
      // evaluateExpr()'s ExprKind::Call.
      if (callee.isFunctionRef) {
        p->evaluationSucceeded_ = true;
        const unsigned long errorsBefore = nc::errorlines::count();
        *out = p->callFunctionValue(callee, args);
        return (p->evaluationSucceeded_ && nc::errorlines::count() == errorsBefore) ? 0 : 1;
      }
      if (nc::numpy::isPoly1d(callee)) {
        std::string err;
        if (args.size() != 1)
          err = n + " is a poly1d: it takes one value in order, e.g. " + n + "(2)";
        else if (nc::numpy::poly1dCall(callee, args[0], *out, err))
          return 0;
        if (args.size() == 1)
          err = n + ": " + err;
        std::cerr << "Error: " << err << "\n";
        p->evaluationSucceeded_ = false;
        *out = Value(0);
        return 1;
      }
    }
    // A function file or class file named exactly n is loaded here for
    // compiled code exactly as evaluateExpr() loads it - ahead of the
    // built-ins (M2/M3, Parser::loadFunctionFile()).
    if (!p->hasClass(n) && !p->hasFunction(n))
      p->loadFunctionFile(n);
    if (p->hasClass(n)) {
      bool found = false;
      p->evaluationSucceeded_ = true;
      *out = p->callClassConstructor(n, args, found);
      return (found && p->evaluationSucceeded_) ? 0 : 1;
    }
    if (p->hasFunction(n)) {
      bool found = false;
      p->evaluationSucceeded_ = true;
      *out = p->callUserFunction(n, args, found);
      return (found && p->evaluationSucceeded_) ? 0 : 1;
    }
    // feval/grad/taylor_series/green_integral - checked ahead of
    // callBuiltin() below, same precedence evaluateExpr()'s own
    // ExprKind::Call case gives this shared method. A real bug this closes:
    // without it, e.g. `fr = @f; grad(fr, [1,2,3]);` (the function reference
    // stored in a variable rather than written as a literal `@f` right at
    // the call site) compiled "successfully" as a generic dynamic-dispatch
    // call - `@f` written directly as the argument is itself an unsupported
    // codegen expression kind, which forces the WHOLE statement to fall
    // back to the tree-walker and accidentally reach the real
    // implementation, but a variable/array-index/etc. holding a function
    // reference is a perfectly ordinary, codegen-SUPPORTED expression, so
    // nothing forced that fallback - and this bridge never knew "grad" was
    // reserved, so it fell through to callBuiltin() and failed at runtime
    // with "Unknown function 'grad'". See tryReservedFunctionValueCall()'s
    // own comment (parser_factor.cpp) for the full history.
    {
      bool handledReserved = false;
      p->evaluationSucceeded_ = true;
      Value reservedResult = p->tryReservedFunctionValueCall(n, args, handledReserved);
      if (handledReserved) {
        *out = reservedResult;
        return p->evaluationSucceeded_ ? 0 : 1;
      }
    }
    // Built-ins by their exact name only (M3): Sum(...) is not sum.
    if (p->builtinCaseMismatch(n)) {
      *out = Value(0);
      return 1;
    }
    // Same N-D guard as evaluateExpr(): a builtin that only understands 2-D
    // matrices never sees an N-D one.
    {
      std::string ndErr;
      if (!ndBuiltinGuard(n, args, ndErr)) {
        std::cerr << "Error: " << ndErr << "\n";
        p->evaluationSucceeded_ = false;
        *out = Value(0);
        return 1;
      }
    }
    // callBuiltin() is the exact same function evaluateExpr()'s ExprKind::
    // Call case calls (parser_factor.cpp) - not a reimplementation, so its
    // "Error: Unknown function '<name>'" stderr output and Value(0) fallback
    // for an unrecognized name come through unchanged.
    const unsigned long errorsBefore = nc::errorlines::count();
    *out = callBuiltin(n, args);
    // An error line printed by the builtin is a failure too (error_lines.h).
    if (nc::errorlines::count() != errorsBefore)
      return 1;
    // g_lastVectorOk/g_lastStatsOk/g_lastGeometricOk/g_lastDcOk/
    // g_lastElementwiseOk: see vector.h/statistics.h/geometric.h/dc.h/
    // elementwise.h's own comments - a vector-, statistics-, geometric-,
    // dc-, or elementwise-routed builtin can be genuinely found yet still
    // reject its actual arguments. g_lastElementwiseOk in particular was
    // previously only ever checked on the binary-operator path
    // (parser_expression.cpp) - never here, on the function-CALL path -
    // so a scalar builtin routed through mapElementwise() (int()/round()/
    // rad2dec()/dec2rad() in dc.cpp, sin()/sqrt()/... elsewhere) that
    // rejected its input still printed the right error but let the call
    // silently "succeed" with Value(0) anyway. Confirmed by direct testing.
    return (g_lastBuiltinFound && g_lastVectorOk && g_lastStatsOk && g_lastGeometricOk &&
            g_lastDcOk && g_lastElementwiseOk && g_lastConditionalOk && g_lastPlotOk)
               ? 0
               : 1;
  NC_BRIDGE_CATCH(ctx, 1)
}

/* ---- Require/Ensure/ClearMemory (see value_bridge.h) ---- */

void nc_bridge_report_condition_failure(NCContext ctx, int isRequire, const char *conditionText,
                                        const char *contractMessage, int line) {
  // Same text as executeStmt()'s StmtKind::Require/Ensure case.
  const char *cond = conditionText ? conditionText : "";
  std::cerr << "Error: AssertionError: " << (isRequire ? "precondition" : "postcondition")
            << " failed: ";
  if (contractMessage && *contractMessage)
    std::cerr << contractMessage << " (" << cond << ")\n";
  else
    std::cerr << cond << "\n";
  Parser *p = asParser(ctx);
  p->evaluationSucceeded_ = false;
  // What noteStatementResult() does after this statement in the tree-walker.
  if (!p->errorAbort_) {
    p->errorAbort_ = true;
    p->errorLine_ = line > 0 ? static_cast<size_t>(line) : 0;
  }
}

// Called from JIT-compiled code when a `while` statement exceeds
// kMaxWhileIterations (see ast.h). Prints the same error as the tree-walker's
// own While case in parser_exec_stmt.cpp, and the generated IR then breaks out
// of the loop, exactly like the interpreter's `break` after the same check.
//
// Deliberately leaves evaluationSucceeded_ TRUE rather than setting it false
// as the tree-walker does: the tree-walker's flag is reset at the top of every
// statement (executeStmt), so the false it leaves behind is gone by the very
// next statement - but compiled code only resets it once per top-level entry
// (see codegen.cpp's compileStatements). Leaving it false here would make
// every later Assign/publish in the same compiled loop silently skip - e.g.
// an outer loop's `o = o + 1` - and turn a capped inner loop into an endless
// outer one. Clearing it matches what the interpreter's next statement sees.
void nc_bridge_report_while_limit(NCContext ctx) {
  std::cerr << whileLimitErrorText();
  asParser(ctx)->evaluationSucceeded_ = true;
}

int nc_bridge_binary_op_checked(NCContext ctx, const char *op, const Value *a, const Value *b,
                                 Value *out) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::string opStr = op ? std::string(op) : std::string();
    *out = p->evaluateBinaryOpValues(opStr, *a, *b);
    return p->evaluationSucceeded_ ? 0 : 1;
  NC_BRIDGE_CATCH(ctx, 1)
}

int nc_bridge_comparison_checked(NCContext ctx, const char *op, const Value *a, const Value *b,
                                  Value *out) {
  NC_BRIDGE_TRY
    Parser *p = asParser(ctx);
    std::string opStr = op ? std::string(op) : std::string();
    *out = p->evaluateComparisonValues(opStr, *a, *b);
    return p->evaluationSucceeded_ ? 0 : 1;
  NC_BRIDGE_CATCH(ctx, 1)
}

// nc_bridge_index_set() now prints its own, specific message (the same one
// the tree-walker prints) - this only keeps the statement marked failed.
void nc_bridge_report_index_set_failure(NCContext ctx, const char *baseName) {
  (void)baseName;
  asParser(ctx)->evaluationSucceeded_ = false;
}

void nc_bridge_clear_memory(NCContext ctx) { asParser(ctx)->clearMemory(); }

// No-op since variables.txt was retired (see value_bridge.h); codegen no
// longer emits calls to it.
void nc_bridge_save_to_file(NCContext ctx) { (void)ctx; }

int nc_bridge_poll_interrupt(NCContext ctx) {
  if (!nc::Interrupt::poll())
    return 0;
  Parser *p = asParser(ctx);
  p->evaluationSucceeded_ = false;
  // At top level the REPL / script driver must also stop after this
  // statement - the same signal a top-level `return;` raises. Inside a
  // call, the call itself fails (see invokeFunctionBody()).
  if (p->scopeDepth_ == 0)
    p->signalTopLevelReturn();
  return 1;
}

void nc_bridge_signal_top_level_return(NCContext ctx) { asParser(ctx)->signalTopLevelReturn(); }

void nc_bridge_reset_evaluation_succeeded(NCContext ctx) { asParser(ctx)->evaluationSucceeded_ = true; }

int nc_bridge_get_evaluation_succeeded(NCContext ctx) {
  return asParser(ctx)->evaluationSucceeded_ ? 0 : 1;
}

/* ---- Multicore and Analysis rules for compiled code (see value_bridge.h) ---- */

namespace {
// One entry per compiled loop now running, innermost last: whether the
// Analysis box was on when it began (nc::analysis::LoopScope's on_). Only
// ever touched by the interpreter thread. Tree-walker loops keep their own
// RAII LoopScope; the two nest strictly (a call from compiled code into the
// tree-walker returns before the compiled loop goes on), so analysis.cpp
// always sees one well-nested stack of loops.
std::vector<char> g_jitLoops;
} // namespace

void nc_bridge_analysis_statement(void) { nc::analysis::statement(); }

void nc_bridge_analysis_scalar_op(const char *op) {
  if (!nc::analysis::active())
    return;
  nc::analysis::OpScope scope(op, std::char_traits<char>::length(op));
  scope.computations(1); // binaryOpCost() of two plain numbers
}

int nc_bridge_analysis_loop_begin(int line, int isFor, int64_t total) {
  nc::par::assertInterpreterThread("a JIT bridge call");
  const int token = static_cast<int>(g_jitLoops.size());
  const bool on = nc::analysis::active();
  // bit 1: the Analysis box; bit 2: for-loop progress (nc::par::loopBegin,
  // 2026-11-21) - the tree-walker's LoopScope does the same.
  const bool progress = isFor != 0 && total > 0 && nc::par::progressSinkSet() && nc::par::loopBegin(line, total);
  g_jitLoops.push_back(static_cast<char>((on ? 1 : 0) | (progress ? 2 : 0)));
  if (on)
    nc::analysis::detail::loopBegin(line, isFor != 0, total);
  return token;
}

void nc_bridge_analysis_loop_iteration(void) {
  if (g_jitLoops.empty())
    return;
  const int flags = g_jitLoops.back();
  if (flags & 1)
    nc::analysis::detail::loopIteration();
  if (flags & 2)
    nc::par::loopIteration();
}

void nc_bridge_analysis_loop_end(int token) {
  if (token < 0)
    token = 0;
  while (g_jitLoops.size() > static_cast<size_t>(token)) {
    const int flags = g_jitLoops.back();
    g_jitLoops.pop_back();
    if (flags & 1)
      nc::analysis::detail::loopEnd();
    if (flags & 2)
      nc::par::loopEnd();
  }
}

int nc_bridge_analysis_loop_depth(void) { return static_cast<int>(g_jitLoops.size()); }

int64_t nc_bridge_range_iteration_count(double first, double step, double end, int rightInclusive) {
  // Since 2026-11-20 the compiled for-range loop runs exactly this many
  // times (k = 0 .. count-1) - the count the tree-walker's For case and
  // range literal use (core/range_spec.h). `first` already includes a '('
  // left bracket's step, so the spec is made with '['.
  if (step == 0.0)
    return -1; // the caller reported the zero step before asking
  return ncrange::make(first, step, end, '[', rightInclusive ? ']' : ')').count;
}

double nc_bridge_range_value(double first, double step, double end, int rightInclusive, int64_t k) {
  return ncrange::valueAt(ncrange::make(first, step, end, '[', rightInclusive ? ']' : ')'), k);
}

void nc_bridge_report_endless_range(NCContext ctx) {
  // Same text as Parser::evaluateRangeSpec() (parser_block_exec.cpp).
  std::cerr << "Error: range literal has no end - it would hold more than 2^53 elements\n";
  asParser(ctx)->evaluationSucceeded_ = false;
}

int nc_bridge_abs_or_norm_checked(NCContext ctx, const Value *a, Value *out) {
  NC_BRIDGE_TRY
    int rc = nc_bridge_abs_or_norm(a, out);
    if (rc != 0)
      asParser(ctx)->evaluationSucceeded_ = false;
    return rc;
  NC_BRIDGE_CATCH(ctx, 1)
}

void nc_bridge_report_zero_range_step(NCContext ctx) {
  // Same text as evaluateExpr()'s RangeLiteral case (parser_factor.cpp).
  std::cerr << "Error: range literal step cannot be zero\n";
  asParser(ctx)->evaluationSucceeded_ = false;
}
