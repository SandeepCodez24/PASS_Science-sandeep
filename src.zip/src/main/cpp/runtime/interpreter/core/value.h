#pragma once
#include <string>
#include <unordered_map>
#include <vector>

struct Value
{
    double number = 0;

    std::string text;

    std::vector<Value> array;

    std::vector<std::vector<Value>> matrix;

    std::unordered_map<std::string, Value> dictMap;

    bool isText = false;
    bool isArray = false;
    bool isMatrix = false;
    bool isDict = false;

    // Class instance: fields are stored in dictMap (same shape as a dict's
    // keyed storage — an object's fields ARE conceptually a name->Value
    // map), className records which class this instance belongs to so a
    // method call (obj.Method(...)) knows which class's method table to
    // resolve against. No dedicated constructor below (unlike the other
    // variants) — object Values are only ever built internally by the
    // class-call machinery (parser_class.cpp), never as a general-purpose
    // public Value type the way dict/array/matrix are.
    bool isObject = false;
    std::string className;

    // Traceability: an auto-maintained history of operations performed on
    // this instance — one entry appended on construction ("init(...)") and
    // one per instance method call ("MethodName(args) -> result"), read via
    // the reserved `.lineage()` call (see parser_factor.cpp). Populated by
    // callClassConstructor()/callInstanceMethod() (parser_class.cpp), never
    // by user code directly.
    std::vector<std::string> lineage;

    // Reversibility (opt-in — `reversible class Name(...)`): one field-state
    // snapshot per lineage entry (same index correspondence), only ever
    // populated for instances of a class marked reversible — a normal
    // class's instances leave this permanently empty, paying no snapshot
    // cost. Read/restored via the reserved `.rewind()` call
    // (parser_factor.cpp), populated by callClassConstructor()/
    // callInstanceMethod() (parser_class.cpp) right alongside `lineage`.
    std::vector<std::unordered_map<std::string, Value>> snapshots;

    // Temporal Determinism (opt-in via `@rate(...)` on the class — see
    // ClassDef::hasRate/rateHz): the simulated time this instance last
    // actually ran its step() method via `.tick(t)`. -1 means "never
    // ticked yet", so the first .tick() call always runs regardless of the
    // configured period.
    double lastTickTime = -1.0;

    // Dimensional Integrity: exponents over 3 base physical dimensions —
    // Length, Time, Mass (e.g. velocity is L^1 T^-1, force is L^1 M^1 T^-2).
    // All zero (the default) means unitless — every pre-existing numeric
    // Value in this codebase stays unitless and unaffected. Attached via
    // multiplying/dividing by a unit constant (m, s, kg, N, Pa — see
    // parser_factor.cpp's tryResolveUnitConstant()), not a dedicated
    // `<unit>` literal — that syntax from the design doc collides with the
    // existing `<`/`>` comparison tokens used throughout this whole
    // codebase, so it was deliberately not implemented as written; see the
    // memory notes for the full rationale.
    int dimL = 0, dimT = 0, dimM = 0;

    /* default */

    Value() {}

    /* number */

    Value(double n)
    {
        number = n;
        isText = false;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* string */

    Value(const std::string &s)
    {
        text = s;
        isText = true;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* array */

    Value(const std::vector<Value> &a)
    {
        array = a;
        isArray = true;
        isText = false;
        isMatrix = false;
        isDict = false;
    }

    /* matrix */

    Value(const std::vector<std::vector<Value>> &m)
    {
        matrix = m;
        isMatrix = true;
        isArray = false;
        isText = false;
        isDict = false;
    }

    /* dict */

    Value(const std::unordered_map<std::string, Value> &d)
    {
        dictMap = d;
        isDict = true;
        isText = false;
        isArray = false;
        isMatrix = false;
    }
};
