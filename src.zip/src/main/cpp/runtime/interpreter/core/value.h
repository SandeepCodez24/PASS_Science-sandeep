#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <mutex>

#include "narrow_float.h"
#include "range_spec.h"
#include <complex>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <string>
#include <string_view>
#include <unordered_map>
#include <type_traits>
#include <utility>
#include <vector>

namespace nc {

namespace mem { // runtime/memory/governor.h - the disk tier (Phase 3)
void *bufferAllocate(size_t bytes);
void bufferRelease(void *p, size_t bytes) noexcept;
} // namespace mem

// An allocator whose value-initialisation leaves a number unset
// (2026-11-23, docs/Large_Data_Design.md section 14 item 1). resize(n) and
// F64Buf(n) then only allocate: the kernel that fills the buffer - on
// several cores - is the first and only pass over it. std::vector<double>
// zeroed every new buffer on ONE thread first: 0.33 s of every 5 GB result,
// and before the governor's parallel pre-fault, 0.9 s. A value given
// explicitly (resize(n, 0.0), F64Buf(n, x)) is still written.
template <class T> struct DefaultInitAlloc : std::allocator<T> {
    using value_type = T;
    template <class U> struct rebind {
        using other = DefaultInitAlloc<U>;
    };
    DefaultInitAlloc() noexcept = default;
    template <class U> DefaultInitAlloc(const DefaultInitAlloc<U> &) noexcept {}
    // A big buffer (64 MB or more) goes through the memory governor's
    // bufferAllocate(): RAM when it fits, else a temporary file on disk
    // (Phase 3, 2026-11-23) - transparent to every user of the buffer.
    static constexpr size_t kBigBytes = size_t(64) << 20;
    T *allocate(size_t n)
    {
        if (n * sizeof(T) >= kBigBytes)
            return static_cast<T *>(nc::mem::bufferAllocate(n * sizeof(T)));
        return std::allocator<T>::allocate(n);
    }
    void deallocate(T *p, size_t n) noexcept
    {
        if (n * sizeof(T) >= kBigBytes) {
            nc::mem::bufferRelease(p, n * sizeof(T));
            return;
        }
        std::allocator<T>::deallocate(p, n);
    }
    template <class U> void construct(U *p) noexcept(std::is_nothrow_default_constructible_v<U>)
    {
        ::new (static_cast<void *>(p)) U;
    }
    template <class U, class... Args> void construct(U *p, Args &&...args)
    {
        ::new (static_cast<void *>(p)) U(std::forward<Args>(args)...);
    }
};
template <class T, class U> bool operator==(const DefaultInitAlloc<T> &, const DefaultInitAlloc<U> &) noexcept
{
    return true;
}
template <class T, class U> bool operator!=(const DefaultInitAlloc<T> &, const DefaultInitAlloc<U> &) noexcept
{
    return false;
}

// The float64 buffer of a packed tensor. EVERY element a builder adds must
// be written by that builder (or given a value): nothing is zero by itself.
using F64Buf = std::vector<double, DefaultInitAlloc<double>>;

} // namespace nc

// Flat storage for an array or matrix whose elements are all plain numbers:
// one contiguous block of doubles instead of one whole Value per element.
// Column-major (first index varies fastest), the layout Eigen and LAPACK
// use, so a matrix can be handed to them without rearranging it.
//
// An N-dimensional matrix (rank 3 or more, shape [d0, ..., rows, cols]) is
// stored as a run of 2-D pages: each page is one rows x cols matrix in the
// same column-major layout, and the pages follow each other in row-major
// order of the leading indices (the last leading index varies fastest). So
// every page can still be handed to Eigen as it is, and A[m] - the slab
// along the first axis - is one contiguous block. See Value::isND().
//
// Typed tensors (R9, 2026-11-14): an array / matrix whose elements are all
// integers of one type (int8 ... uint64), all bools, or all one narrower
// float format (float32 / float16 / float8) is stored the same way, but in
// that element's own size: `raw` holds the elements (etype says how) and
// `buf` stays empty. Every element read rebuilds the typed scalar
// (uint8(7), true, float32(1.5)), so a typed tensor behaves exactly like the
// cell array of typed scalars it replaces - it only takes 1 - 8 bytes per
// element instead of a 32-byte Value. float32 elements are 4-byte floats;
// since 2026-11-21 float16 elements are their own 2-byte binary16 bits and
// float8 elements their own 1-byte E4M3 bits (core/narrow_float.h; they
// used to be 4-byte floats too).
enum class ElemType : uint8_t
{
    F64 = 0, // `buf` (and complex)
    I8, I16, I32, I64,
    U8, U16, U32, U64,
    F32,  // 4-byte float
    F16,  // 2 bytes: binary16 bits
    F8,   // 1 byte: E4M3 bits
    Bool  // 1 byte, 0 / 1
};

inline size_t elemTypeBytes(ElemType t)
{
    switch (t) {
    case ElemType::I8: case ElemType::U8: case ElemType::Bool: return 1;
    case ElemType::I16: case ElemType::U16: return 2;
    case ElemType::F16: return 2; // its own binary16 bits (2026-11-21; was a 4-byte float)
    case ElemType::F8: return 1;  // its own E4M3 bits (2026-11-21; was a 4-byte float)
    case ElemType::I32: case ElemType::U32: case ElemType::F32: return 4;
    default: return 8;
    }
}

// The language's name of an element type ("uint8", "float32", "bool", "float64").
inline const char *elemTypeName(ElemType t)
{
    static const char *const names[] = {"float64", "int8",    "int16",   "int32",  "int64",
                                        "uint8",   "uint16",  "uint32",  "uint64", "float32",
                                        "float16", "float8",  "bool"};
    return names[static_cast<int>(t)];
}

struct NumTensor
{
    nc::F64Buf buf; // never zeroed by itself (nc::F64Buf, 2026-11-23)
    ElemType etype = ElemType::F64;
    std::vector<uint8_t> raw; // typed elements (etype != F64), elemTypeBytes() each
    // {length} for an array, {rows, cols} for a matrix,
    // {d0, ..., d(n-3), rows, cols} for an N-dimensional matrix.
    std::vector<size_t> shape;

    // Complex tensor: each element takes two consecutive doubles in `buf`,
    // real part then imaginary part. That is the layout std::complex<double>
    // and Eigen's complex matrices use, so the buffer can be handed to them
    // as it is.
    bool complex = false;

    // Unit dimensions shared by every element (see Value::dimL/dimT/dimM).
    int16_t dimL = 0, dimT = 0, dimM = 0;

    // A process-wide unique number that changes whenever `buf` / `raw` may
    // have been written (2026-11-20): a new tensor takes a fresh one, and
    // Value::ownTensor() - which every write calls first - takes another. A
    // copy keeps its source's stamp only while its bytes are identical.
    // Lets the IDE fingerprint reuse a big buffer's hash between prompts
    // (DataSupport/BinaryIO.h, HashSink).
    uint64_t stamp = nextStamp();
    static uint64_t nextStamp()
    {
        static std::atomic<uint64_t> counter{1};
        return counter.fetch_add(1, std::memory_order_relaxed);
    }

    // A lazy range (2026-11-20, docs/design_fix_1_4.md section 12): while
    // `pending`, `buf` is not built yet and element k of the storage order
    // is ncrange::valueAt(range, k) - a real float64 tensor in every other
    // respect. Reading one element computes it; anything that needs the
    // whole buffer calls materialize() first (Value does, in every accessor
    // that touches `buf`), which builds it once. `range` never changes.
    std::atomic<bool> pending{false};
    ncrange::Spec range;

    // Lazy arithmetic (2026-11-21): a lazy range may also carry a short
    // chain of scalar operations, applied in order to each element - A*1000,
    // (A - 1)/2, -A stay a rule instead of building 5 GB. Each step is the
    // very double operation the eager kernel does per element (x*c, x - c,
    // c - x, x/c, c/x, -x), so element k is bit for bit what the built
    // result would hold. Only while `pending`; never changes afterwards.
    //
    // Lazy functions (2026-11-23, docs/Large_Data_Design.md section 4.1):
    // Fn1 applies a pure element-wise function (sin, exp, abs ...) - the very
    // function the eager kernel calls on each element, so the bits are the
    // same; Fn2L / Fn2R combine the element with element k of another
    // operand of the same shape (x op y / y op x) - a lazy tensor, which may
    // itself carry a chain, or a stored buffer that is never written while
    // shared (copy on write). So sin(A) + A*2 is a small tree, not 100 GB.
    // Fn2C / Fn2CR (2026-11-23, Phase 5): a two-argument function with one
    // single number, fn(x, c) / fn(c, x) - X^.2 of a lazy X stays a rule.
    // Only the first seven kinds can be written to a file (portableRule()).
    enum class LazyOpKind : uint8_t { Add, Sub, RSub, Mul, Div, RDiv, Neg, Fn1, Fn2L, Fn2R, Fn2C, Fn2CR };
    struct LazyOp
    {
        LazyOp(LazyOpKind k, double constant) : kind(k), c(constant) {}
        LazyOpKind kind;
        double c;
        double (*fn1)(double) = nullptr;
        double (*fn2)(double, double) = nullptr; // Fn2L / Fn2R / Fn2C / Fn2CR
        std::shared_ptr<const NumTensor> other; // Fn2L / Fn2R
    };
    static constexpr size_t kMaxLazyOps = 32;   // a longer chain is built instead
    static constexpr size_t kMaxLazyNodes = 32; // steps in the whole tree
    std::vector<LazyOp> ops;
    // A lazy VIEW (2026-11-23, docs/Large_Data_Design.md section 17): the
    // chain starts from element k of a stored float64 buffer instead of a
    // range - sin(S) or S*2 + 1 of a big stored S is a rule over S, not a
    // new buffer (or two). `range.count` holds the element count. The base
    // is shared, never written: a write to its variable copies it first.
    std::shared_ptr<const NumTensor> base;

    // Every step is a scalar one (no Fn kinds): the rule can be written to
    // the session autosave as TAG_NUM_RANGE.
    bool portableRule() const
    {
        if (base)
            return false; // a view reads a buffer: written as data, not as a rule
        for (const LazyOp &op : ops)
            if (op.kind > LazyOpKind::Neg)
                return false;
        return true;
    }
    // Steps in the whole tree (this chain and the chains of the operands).
    size_t lazyNodes() const
    {
        size_t n = ops.size();
        for (const LazyOp &op : ops)
            if (op.other)
                n += 1 + op.other->lazyNodes();
        return n;
    }

    NumTensor() = default;
    NumTensor(const NumTensor &o)
        : buf(o.buf), etype(o.etype), raw(o.raw), shape(o.shape), complex(o.complex), dimL(o.dimL),
          dimT(o.dimT), dimM(o.dimM), stamp(o.stamp), pending(o.pending.load(std::memory_order_acquire)),
          range(o.range), ops(o.ops), base(o.base)
    {
    }

    // Element k of a lazy tensor: the range's element, then the chain.
    double lazyValue(size_t k) const
    {
#if defined(__clang__)
#pragma clang fp contract(off) // each step rounds on its own, as the eager kernels do
#endif
        double x = base ? base->realAt(k) : ncrange::valueAt(range, static_cast<int64_t>(k));
        for (const LazyOp &op : ops) {
            switch (op.kind) {
            case LazyOpKind::Add: x = x + op.c; break;
            case LazyOpKind::Sub: x = x - op.c; break;
            case LazyOpKind::RSub: x = op.c - x; break;
            case LazyOpKind::Mul: x = x * op.c; break;
            case LazyOpKind::Div: x = x / op.c; break;
            case LazyOpKind::RDiv: x = op.c / x; break;
            case LazyOpKind::Neg: x = -x; break;
            case LazyOpKind::Fn1: x = op.fn1(x); break;
            case LazyOpKind::Fn2L: x = op.fn2(x, op.other->realAt(k)); break;
            case LazyOpKind::Fn2R: x = op.fn2(op.other->realAt(k), x); break;
            case LazyOpKind::Fn2C: x = op.fn2(x, op.c); break;
            case LazyOpKind::Fn2CR: x = op.fn2(op.c, x); break;
            }
        }
        return x;
    }
    // Elements first .. first+m-1 of a lazy tensor into out - exactly
    // lazyValue() of each (every step works element by element, in the
    // same order), one step at a time over the block: the generic loops of
    // the filler, the writers and the hash cost one call per step and block
    // instead of a switch per element.
    void lazyBlock(size_t first, size_t m, double *out) const
    {
#if defined(__clang__)
#pragma clang fp contract(off) // as lazyValue()
#endif
        if (base)
            base->realBlock(first, m, out);
        else
            for (size_t i = 0; i < m; i++)
                out[i] = ncrange::valueAt(range, static_cast<int64_t>(first + i));
        std::vector<double> y;
        for (const LazyOp &op : ops) {
            const double c = op.c;
            switch (op.kind) {
            case LazyOpKind::Add: for (size_t i = 0; i < m; i++) out[i] = out[i] + c; break;
            case LazyOpKind::Sub: for (size_t i = 0; i < m; i++) out[i] = out[i] - c; break;
            case LazyOpKind::RSub: for (size_t i = 0; i < m; i++) out[i] = c - out[i]; break;
            case LazyOpKind::Mul: for (size_t i = 0; i < m; i++) out[i] = out[i] * c; break;
            case LazyOpKind::Div: for (size_t i = 0; i < m; i++) out[i] = out[i] / c; break;
            case LazyOpKind::RDiv: for (size_t i = 0; i < m; i++) out[i] = c / out[i]; break;
            case LazyOpKind::Neg: for (size_t i = 0; i < m; i++) out[i] = -out[i]; break;
            case LazyOpKind::Fn1: for (size_t i = 0; i < m; i++) out[i] = op.fn1(out[i]); break;
            case LazyOpKind::Fn2L:
            case LazyOpKind::Fn2R:
                y.resize(m);
                op.other->realBlock(first, m, y.data());
                if (op.kind == LazyOpKind::Fn2L)
                    for (size_t i = 0; i < m; i++) out[i] = op.fn2(out[i], y[i]);
                else
                    for (size_t i = 0; i < m; i++) out[i] = op.fn2(y[i], out[i]);
                break;
            case LazyOpKind::Fn2C: for (size_t i = 0; i < m; i++) out[i] = op.fn2(out[i], c); break;
            case LazyOpKind::Fn2CR: for (size_t i = 0; i < m; i++) out[i] = op.fn2(c, out[i]); break;
            }
        }
    }
    NumTensor &operator=(const NumTensor &) = delete;

    // Builds `buf` of a lazy range; a no-op otherwise. Safe from several
    // threads at once (double-checked under a lock); the stamp stays - the
    // bytes are the ones the range always stood for.
    void materialize()
    {
        if (!pending.load(std::memory_order_acquire))
            return;
        static std::mutex locks[16];
        std::lock_guard<std::mutex> guard(locks[(reinterpret_cast<uintptr_t>(this) >> 6) % 16]);
        if (!pending.load(std::memory_order_relaxed))
            return;
        const size_t n = range.count > 0 ? static_cast<size_t>(range.count) : 0;
        buf.resize(n);
        if (lazyFiller)
            lazyFiller(*this, buf.data(), n); // several cores (set by the interpreter)
        else
            for (size_t k = 0; k < n; k++)
                buf[k] = lazyValue(k);
        pending.store(false, std::memory_order_release);
    }
    // Writes elements 0..n-1 of a lazy tensor (lazyValue) into out,
    // completely (whatever happens, e.g. Stop). Set once at start-up by code
    // that may use the multicore library (parser_factor.cpp); null = one
    // core. Keeps this header free of that library.
    inline static void (*lazyFiller)(const NumTensor &, double *, size_t) = nullptr;
    // Element k of a real float64 tensor, lazy or not, without building it.
    double realAt(size_t k) const { return pending.load(std::memory_order_acquire) ? lazyValue(k) : buf[k]; }
    // Elements first .. first+m-1, lazy or not, without building it.
    void realBlock(size_t first, size_t m, double *out) const
    {
        if (pending.load(std::memory_order_acquire))
            lazyBlock(first, m, out);
        else
            for (size_t i = 0; i < m; i++)
                out[i] = buf[first + i];
    }
};

// A missing value (2026-11-15, docs/Import_Window.md §11): a NaN whose
// payload is 1954 - R's NA. It IS a NaN, so every script, display and
// computation treats it exactly as NaN (no new value kind); readers give it
// for an empty / null / NA cell, ismissing() tells it from a computed NaN,
// and the parquet / feather / orc writers write it as null and other NaNs as
// NaN. It travels wherever a double does (packed buffers, columns, copies),
// and arithmetic on it stays missing (the processor keeps a NaN's payload),
// as in R. A quiet NaN, sign ignored.
constexpr uint64_t kMissingBits = 0x7FF80000000007A2ull;
inline double missingNumber()
{
    double d;
    std::memcpy(&d, &kMissingBits, sizeof d);
    return d;
}
inline bool isMissingNumber(double d)
{
    uint64_t u;
    std::memcpy(&u, &d, sizeof u);
    return (u & 0x7FF8000000000000ull) == 0x7FF8000000000000ull && (u & 0xFFFFFFFFull) == 0x7A2ull;
}

// Fixed-width integer types. float64 stays the language's default number;
// an integer only exists when the script asks for one (int(), int8(), ...).
// The numbering is internal to the interpreter - the .ndat format has its
// own type tags (runtime/data/DataSupport/NdatTypes.h).
enum class IntType : uint8_t
{
    None = 0,
    Int8,
    Int16,
    Int32,
    Int64,
    UInt8,
    UInt16,
    UInt32,
    UInt64
};

// Floating-point storage formats. float64 is the language's default number
// and needs no tag; the narrower formats are opt-in (float32(x), ...). Every
// value is still computed in double precision and then rounded to its
// format, so a tagged number always holds a value that format can represent
// exactly. float128 has a reserved .ndat tag but no runtime support yet.
enum class FloatType : uint8_t
{
    Float64 = 0, // the default - untagged
    Float8,      // OCP FP8 E4M3: 1 sign, 4 exponent, 3 mantissa bits; max 448, no infinity
    Float16,     // IEEE 754 binary16 (half)
    Float32      // IEEE 754 binary32 (single)
};

// Rounds `x` to the nearest value representable in format `t` (ties to
// even; overflow gives +/-Inf, or NaN for float8). Float64 returns `x`.
// Defined in ops/floating/floating.cpp.
double roundToFloatType(FloatType t, double x);

// One NC value. A plain number is just the 32 bytes below; everything else
// a value can be (text, an array or matrix, a dict, a class instance, a
// function reference) keeps its data in a separately allocated Box, so the
// common case of a number never pays for it.
struct Value
{
    // The value of a plain number. For an integer it is the nearest double
    // to the exact integer (exact up to 2^53), and for a bool it is 1 or 0,
    // so code that only understands doubles keeps reading a sensible
    // number from either.
    double number = 0;

    union
    {
        // Imaginary part, meaningful only while isComplex is set. A complex
        // value keeps its real part in `number`, so code that only
        // understands real numbers still reads the real part.
        double imag = 0;

        // Integer only: the exact value. Signed types keep it as int64,
        // unsigned types keep the uint64 bit pattern. Shares storage with
        // `imag` because a value is never both complex and an integer.
        int64_t i64_;
    };

    // Column storage of a matrix (see "columnar matrices" below).
    struct Column;
    class ColumnBuilder;

  private:
    struct ColStore;

    // Everything a Value can hold beyond a number and a text (2026-11-15):
    // kept apart from the text so that a text Value - by far the most
    // common boxed Value (every text cell of a table, every key and name) -
    // costs its characters plus 40 bytes, not ~330.
    struct Ext
    {
        // An array/matrix lives in exactly one of two forms:
        //  - packed: `tensor` set, every element a plain number sharing one
        //    unit. This is the compact form, and copies of the Value share
        //    the buffer until one of them writes to it (ownTensor()).
        //  - cells: `array` / `matrix`, one whole Value per element. Used
        //    whenever the packed form can't represent the contents exactly
        //    (text, nested arrays, mixed units, rows of different lengths).
        // The constructors pick the packed form when it fits, and a write
        // that no longer fits switches that Value back to cells (unpack()).
        std::vector<Value> array;
        std::vector<std::vector<Value>> matrix;
        std::shared_ptr<NumTensor> tensor;

        // A third form of a 2-D matrix whose cells cannot be packed: stored
        // by columns (2026-11-15, docs/Import_Window.md §9). Shared by copies
        // like `tensor`; a write copies only the store and the one column it
        // changes. See "columnar matrices" below.
        std::shared_ptr<ColStore> cstore;

        // An N-dimensional matrix (rank >= 3) whose cells cannot be packed
        // (text, bools, integers, float32 ...): one Value per element, in
        // the same storage order as a packed N-D tensor (see NumTensor),
        // with its shape. Both empty for anything else.
        std::vector<Value> ndCells;
        std::vector<size_t> ndShape;

        // Dict entries, or a class instance's fields (an object's fields ARE
        // conceptually a name->Value map).
        std::unordered_map<std::string, Value> dict;
        // The order the dict's keys were given in (dict(A=A, B=B), a loaded
        // .ndat; docs/Export_Process_Modules_CPP.md X1). Only a hint: used
        // while it lists exactly the keys `dict` holds - a key added or
        // removed later makes orderedKeys() fall back to sorted order, as
        // before the hint existed.
        std::vector<std::string> dictOrder;
        // The order keys / fields were first set by d[k] = v or base.x = v
        // (setKeyOrdered()). Display only (displayKeys()) - unlike dictOrder
        // it never changes how a dict is saved or exported.
        std::vector<std::string> keyOrder;

        // Class instance: which class this instance belongs to, so a method
        // call (obj.Method(...)) knows which class's method table to resolve
        // against. Object Values are only ever built internally by the
        // class-call machinery (parser_class.cpp), never as a
        // general-purpose public Value type the way dict/array/matrix are.
        std::string className;

        // First-class function reference (`@name` - see ast.h's FunctionRef
        // comment). Deliberately just a NAME, not a pointer/closure of any
        // kind: functions are already looked up by name in Parser::
        // functionTable_ at call time everywhere else in this codebase (the
        // same principle classes/methods use - see ClassDef's own comments),
        // so a reference only ever needs to remember which name to
        // re-resolve later, via feval(). This means a reference stays valid
        // even if the function it names is later redefined (feval()
        // re-resolves by name each call, not a captured snapshot) -
        // consistent with every other late-bound name lookup in this
        // language, and much simpler than a real closure (no captured
        // environment to manage, no lifetime issues if the referenced
        // function's defining scope has since exited).
        std::string funcRefName;

        // Traceability: an auto-maintained history of operations performed
        // on this instance — one entry appended on construction
        // ("init(...)") and one per instance method call
        // ("MethodName(args) -> result"), read via the reserved `.lineage()`
        // call (see parser_factor.cpp). Populated by callClassConstructor()/
        // callInstanceMethod() (parser_class.cpp), never by user code
        // directly.
        std::vector<std::string> lineage;

        // Reversibility (opt-in — `reversible class Name(...)`): one
        // field-state snapshot per lineage entry (same index
        // correspondence), only ever populated for instances of a class
        // marked reversible — a normal class's instances leave this
        // permanently empty, paying no snapshot cost. Read/restored via the
        // reserved `.rewind()` call (parser_factor.cpp), populated by
        // callClassConstructor()/callInstanceMethod() (parser_class.cpp)
        // right alongside `lineage`.
        std::vector<std::unordered_map<std::string, Value>> snapshots;

        // Temporal Determinism (opt-in via `@rate(...)` on the class — see
        // ClassDef::hasRate/rateHz): the simulated time this instance last
        // actually ran its step() method via `.tick(t)`. -1 means "never
        // ticked yet", so the first .tick() call always runs regardless of
        // the configured period.
        double lastTickTime = -1.0;

        // Nothing in here differs from a freshly made Ext.
        bool isBlank() const
        {
            return array.empty() && matrix.empty() && !tensor && !cstore && ndCells.empty() &&
                   ndShape.empty() && dict.empty() && dictOrder.empty() && keyOrder.empty() && className.empty() && funcRefName.empty() &&
                   lineage.empty() && snapshots.empty() && lastTickTime == -1.0;
        }
    };

    struct Box
    {
        std::string text;
        std::unique_ptr<Ext> ext; // null until something beyond text is stored

        Box() = default;
        Box(const Box &o) : text(o.text), ext(o.ext ? std::make_unique<Ext>(*o.ext) : nullptr) {}
        Box &operator=(const Box &) = delete;

        // Nothing in here differs from a freshly made Box.
        bool isBlank() const { return text.empty() && onlyText(); }
        // Nothing but (possibly) text differs from a freshly made Box.
        bool onlyText() const { return !ext || ext->isBlank(); }
    };

    // Null until this Value needs something a plain number doesn't have.
    // Owned: copying a Value copies its Box.
    Box *box_ = nullptr;

  public:
    // One bit each, so that all of them plus the unit exponents below fit
    // in the 8 bytes left after number / imag / box_. Bit fields can't
    // carry a default here before C++20; the constructors clear them.
    bool isText : 1;
    bool isArray : 1;
    bool isMatrix : 1;
    bool isDict : 1;
    bool isObject : 1;      // class instance - see Box::className
    bool isFunctionRef : 1; // `@name` - see Box::funcRefName
    bool isComplex : 1;     // a complex number: number + imag*i

    // Raw scalar type tags - read them through isBool() / isInt(), which
    // also check that the tag still matches `number`. Older code that
    // copies a Value and then overwrites `.number` (unit-preserving math)
    // leaves the tag behind; the check makes such a value read back as the
    // plain float64 it has become instead of a stale bool/integer.
    bool boolTag_ : 1;
    uint8_t intTag_ : 4; // an IntType; 0 = not an integer
    uint8_t floatTag_ : 3; // a FloatType; 0 = plain float64

    // Dimensional Integrity: exponents over 3 base physical dimensions —
    // Length, Time, Mass (e.g. velocity is L^1 T^-1, force is L^1 M^1 T^-2).
    // All zero (the default) means unitless — every pre-existing numeric
    // Value in this codebase stays unitless and unaffected. Attached via
    // multiplying/dividing by a unit constant (m, s, kg, N, Pa — see
    // parser_factor.cpp's tryResolveUnitConstant()), not a dedicated
    // `<unit>` literal — that syntax from the design doc collides with the
    // existing `<`/`>` comparison tokens used throughout this whole
    // codebase, so it was deliberately not implemented as written; see the
    // memory notes for the full rationale.
    int16_t dimL = 0, dimT = 0, dimM = 0;

    /* copying / moving / destroying */

    // The imag/i64_ union is copied through i64_: its 8 bytes then travel
    // as an integer, so an integer's bit pattern is never pushed through a
    // floating-point register.
    Value(const Value &o)
        : number(o.number), i64_(o.i64_), box_(o.box_ ? new Box(*o.box_) : nullptr),
          isText(o.isText), isArray(o.isArray), isMatrix(o.isMatrix), isDict(o.isDict),
          isObject(o.isObject), isFunctionRef(o.isFunctionRef), isComplex(o.isComplex),
          boolTag_(o.boolTag_), intTag_(o.intTag_), floatTag_(o.floatTag_), dimL(o.dimL),
          dimT(o.dimT), dimM(o.dimM)
    {
    }

    Value(Value &&o) noexcept
        : number(o.number), i64_(o.i64_), box_(o.box_), isText(o.isText), isArray(o.isArray),
          isMatrix(o.isMatrix), isDict(o.isDict), isObject(o.isObject),
          isFunctionRef(o.isFunctionRef), isComplex(o.isComplex), boolTag_(o.boolTag_),
          intTag_(o.intTag_), floatTag_(o.floatTag_), dimL(o.dimL), dimT(o.dimT), dimM(o.dimM)
    {
        o.box_ = nullptr;
    }

    // Both assignments finish reading `o` before releasing this Value's old
    // Box: `o` may be an element living inside that Box (x = x.at(0)).
    Value &operator=(const Value &o)
    {
        if (this != &o) {
            Value copy(o);
            *this = std::move(copy);
        }
        return *this;
    }

    Value &operator=(Value &&o) noexcept
    {
        if (this != &o) {
            Box *old = box_;
            number = o.number;
            i64_ = o.i64_;
            isText = o.isText;
            isArray = o.isArray;
            isMatrix = o.isMatrix;
            isDict = o.isDict;
            isObject = o.isObject;
            isFunctionRef = o.isFunctionRef;
            isComplex = o.isComplex;
            boolTag_ = o.boolTag_;
            intTag_ = o.intTag_;
            floatTag_ = o.floatTag_;
            dimL = o.dimL;
            dimT = o.dimT;
            dimM = o.dimM;
            box_ = o.box_;
            o.box_ = nullptr;
            delete old;
        }
        return *this;
    }

    ~Value() { delete box_; }

    /* default */

    Value()
        : isText(false), isArray(false), isMatrix(false), isDict(false), isObject(false),
          isFunctionRef(false), isComplex(false), boolTag_(false), intTag_(0),
          floatTag_(0)
    {
    }

    /* number */

    Value(double n) : Value()
    {
        number = n;
        isText = false;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* complex number */

    static Value complexNumber(double re, double im)
    {
        Value v(re);
        v.imag = im;
        v.isComplex = true;
        return v;
    }

    /* bool */

    static Value boolean(bool b)
    {
        Value v(b ? 1.0 : 0.0);
        v.boolTag_ = true;
        return v;
    }

    /* fixed-width integers (the caller has range-checked the value) */

    static Value integerSigned(IntType t, int64_t n)
    {
        Value v(static_cast<double>(n));
        v.i64_ = n;
        v.intTag_ = static_cast<uint8_t>(t);
        return v;
    }

    static Value integerUnsigned(IntType t, uint64_t n)
    {
        Value v(static_cast<double>(n));
        v.i64_ = static_cast<int64_t>(n);
        v.intTag_ = static_cast<uint8_t>(t);
        return v;
    }

    /* narrower floating-point formats (the value must already be
       representable in `t` - see roundToFloatType()) */

    static Value floating(FloatType t, double n)
    {
        Value v(n);
        v.floatTag_ = static_cast<uint8_t>(t);
        return v;
    }

    /* date / time (ops/time/) - since 2026-10-28

       A timestamp is a point in time, a duration a length of time; both
       keep int64 nanoseconds in i64_ (a timestamp since 1970-01-01 00:00:00
       UTC). They borrow the integer tag field: tag values 9 and 10 are past
       every IntType, so no other code mistakes them for integers, and the
       Value stays 32 bytes. `number` is NaN, so any code that only reads
       doubles gets an obviously wrong result instead of a plausible one;
       callBuiltin() refuses time values for functions that do not know
       them. Like a bool or an integer, a time value never packs - a matrix
       of them uses the cell form. */

    static constexpr uint8_t kTimestampTag = 9;
    static constexpr uint8_t kDurationTag = 10;

    static Value timestamp(int64_t ns)
    {
        Value v(std::numeric_limits<double>::quiet_NaN());
        v.i64_ = ns;
        v.intTag_ = kTimestampTag;
        return v;
    }

    static Value duration(int64_t ns)
    {
        Value v(std::numeric_limits<double>::quiet_NaN());
        v.i64_ = ns;
        v.intTag_ = kDurationTag;
        return v;
    }

    // `number != number`: still NaN - code that copies a Value and then
    // overwrites `.number` leaves the tag behind (see isBool()), and such a
    // value reads back as the plain float64 it has become.
    bool isTimestamp() const { return intTag_ == kTimestampTag && isPlainScalar() && number != number; }
    bool isDuration() const { return intTag_ == kDurationTag && isPlainScalar() && number != number; }
    bool isTime() const { return isTimestamp() || isDuration(); }

    // Timestamp / duration only: the nanoseconds.
    int64_t timeNs() const { return i64_; }

    /* scalar type queries */

    // The storage format of a real number: Float64 (the default) unless the
    // value was made with float8/float16/float32 and still holds a value
    // that format represents exactly (see isBool() for why that is checked).
    FloatType floatType() const
    {
        if (floatTag_ == 0 || !isPlainScalar() || intTag_ != 0 || boolTag_)
            return FloatType::Float64;
        const FloatType t = static_cast<FloatType>(floatTag_);
        const double r = roundToFloatType(t, number);
        const bool same = (r == number) || (r != r && number != number); // NaN stays NaN
        return same ? t : FloatType::Float64;
    }

    // A real bool (true/false), not the float64 1/0.
    bool isBool() const
    {
        return boolTag_ && isPlainScalar() && (number == 0.0 || number == 1.0);
    }

    // A fixed-width integer (int8 ... uint64).
    bool isInt() const
    {
        if (intTag_ == 0 || intTag_ > static_cast<uint8_t>(IntType::UInt64) || !isPlainScalar())
            return false; // tags past UInt64 are the time types
        return intIsUnsigned() ? static_cast<double>(static_cast<uint64_t>(i64_)) == number
                               : static_cast<double>(i64_) == number;
    }

    // IntType::None unless isInt().
    IntType intType() const { return isInt() ? static_cast<IntType>(intTag_) : IntType::None; }

    // Integer only: whether intType() is one of the uint types.
    bool intIsUnsigned() const
    {
        return intTag_ >= static_cast<uint8_t>(IntType::UInt8) &&
               intTag_ <= static_cast<uint8_t>(IntType::UInt64);
    }

    // Integer only: the exact value (unsigned types: reinterpret as uint64).
    int64_t intBits() const { return i64_; }

    // Integer only: the exact value as decimal digits.
    std::string intText() const
    {
        return intIsUnsigned() ? std::to_string(static_cast<uint64_t>(i64_)) : std::to_string(i64_);
    }

    // Forget the bool / integer type, keeping `number`: the value becomes
    // the plain float64 it mirrors. Used before handing a value to code
    // that only computes in doubles.
    void dropScalarType()
    {
        boolTag_ = false;
        intTag_ = 0;
        floatTag_ = 0;
    }

    /* string */

    Value(const std::string &s) : Value()
    {
        if (!s.empty())
            wrText() = s;
        isText = true;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* array */

    Value(const std::vector<Value> &a) : Value()
    {
        if (auto t = pack(a)) {
            wr().tensor = std::move(t);
        } else if (!a.empty()) {
            if (a.size() >= 16 && anyArrayKind(a)) {
                std::vector<Value> copy(a);
                wr().cstore = columnarizeArray(copy);
            } else {
                wr().array = a;
            }
        }
        isArray = true;
        isText = false;
        isMatrix = false;
        isDict = false;
    }

    /* matrix */

    Value(const std::vector<std::vector<Value>> &m) : Value()
    {
        if (auto t = pack(m)) {
            wr().tensor = std::move(t);
        } else if (!m.empty()) {
            if (!(columnarCandidate(m) && (wr().cstore = columnarizeCopy(m))))
                wr().matrix = m;
        }
        isMatrix = true;
        isArray = false;
        isText = false;
        isDict = false;
    }

    /* dict */

    Value(const std::unordered_map<std::string, Value> &d) : Value()
    {
        if (!d.empty())
            wr().dict = d;
        isDict = true;
        isText = false;
        isArray = false;
        isMatrix = false;
    }

    /* array / matrix (moving) - same as the copying constructors above,
       minus the full copy of a container the caller is done with. */

    Value(std::vector<Value> &&a) : Value()
    {
        if (auto t = pack(a)) {
            wr().tensor = std::move(t);
        } else if (!a.empty()) {
            if (a.size() >= 16 && anyArrayKind(a))
                wr().cstore = columnarizeArray(a);
            else
                wr().array = std::move(a);
        }
        isArray = true;
    }

    Value(std::vector<std::vector<Value>> &&m) : Value()
    {
        if (auto t = pack(m)) {
            wr().tensor = std::move(t);
        } else if (!m.empty()) {
            if (!(columnarCandidate(m) && (wr().cstore = columnarize(m))))
                wr().matrix = std::move(m);
        }
        isMatrix = true;
    }

    /* ---- text / dict / object-state access ----

       Read with name(), change through nameMut(). Reading never allocates:
       a Value with no Box reads as empty. nameMut() gives the Value a Box
       if it doesn't have one yet. */

    const std::string &text() const { return rdText(); }
    std::string &textMut() { return wrText(); }

    const std::unordered_map<std::string, Value> &dict() const { return rd().dict; }
    std::unordered_map<std::string, Value> &dictMut() { return wr().dict; }

    // The key order hint (see Ext::dictOrder) and the keys in that order
    // when it still matches the dict, otherwise sorted.
    const std::vector<std::string> &dictOrderHint() const { return rd().dictOrder; }
    std::vector<std::string> &dictOrderHintMut() { return wr().dictOrder; }
    std::vector<std::string> orderedKeys() const
    {
        const auto &d = dict();
        const auto &hint = dictOrderHint();
        bool usable = !hint.empty() && hint.size() == d.size();
        for (size_t i = 0; usable && i < hint.size(); i++)
            usable = d.count(hint[i]) != 0;
        if (usable)
        {
            // and no key twice
            std::vector<std::string> sorted = hint;
            std::sort(sorted.begin(), sorted.end());
            usable = std::adjacent_find(sorted.begin(), sorted.end()) == sorted.end();
        }
        if (usable)
            return hint;
        std::vector<std::string> keys;
        keys.reserve(d.size());
        for (const auto &kv : d)
            keys.push_back(kv.first);
        std::sort(keys.begin(), keys.end());
        return keys;
    }

    // dict / object: sets one key and, when it is new, records its place in
    // keyOrder - as long as that still lists exactly the keys (an empty dict
    // starts one). So a dict filled by d["k"] = v, and an
    // object's fields set by base.x = v, keep the order they were given in
    // (2026-11-18: display used to follow the hash table).
    void setKeyOrdered(const std::string &key, const Value &v)
    {
        auto &d = wr().dict;
        auto it = d.find(key);
        if (it != d.end()) {
            it->second = v;
            return;
        }
        auto &order = wr().keyOrder;
        const bool tracked = order.size() == d.size();
        d.emplace(key, v);
        if (tracked)
            order.push_back(key);
    }
    // The keys in display order: the order hint (dict(A=, B=), a loaded
    // .ndat) or the order they were set in, whichever lists exactly the
    // keys; otherwise the order the hash table holds them in.
    std::vector<std::string> displayKeys() const
    {
        const auto &d = dict();
        for (const std::vector<std::string> *order : {&rd().dictOrder, &rd().keyOrder}) {
            bool usable = !order->empty() && order->size() == d.size();
            for (size_t i = 0; usable && i < order->size(); i++)
                usable = d.count((*order)[i]) != 0;
            if (usable)
                return *order;
        }
        std::vector<std::string> keys;
        keys.reserve(d.size());
        for (const auto &kv : d)
            keys.push_back(kv.first);
        return keys;
    }

    const std::string &className() const { return rd().className; }
    std::string &classNameMut() { return wr().className; }

    const std::string &funcRefName() const { return rd().funcRefName; }
    std::string &funcRefNameMut() { return wr().funcRefName; }

    const std::vector<std::string> &lineage() const { return rd().lineage; }
    std::vector<std::string> &lineageMut() { return wr().lineage; }

    const std::vector<std::unordered_map<std::string, Value>> &snapshots() const
    {
        return rd().snapshots;
    }
    std::vector<std::unordered_map<std::string, Value>> &snapshotsMut()
    {
        return wr().snapshots;
    }

    double lastTickTime() const { return rd().lastTickTime; }
    double &lastTickTimeMut() { return wr().lastTickTime; }

    // True for a complex number, or an array/matrix holding at least one.
    bool hasComplex() const
    {
        if (isComplex)
            return true;
        if (!box_)
            return false;
        if (rd().tensor)
            return rd().tensor->complex;
        if (rd().cstore && colHasComplex())
            return true;
        for (const Value &elem : rd().array)
            if (elem.hasComplex())
                return true;
        for (const auto &matRow : rd().matrix)
            for (const Value &cell : matRow)
                if (cell.hasComplex())
                    return true;
        for (const Value &cell : rd().ndCells)
            if (cell.hasComplex())
                return true;
        return false;
    }

    /* ---- array / matrix element access ----

       Every use of the `array` / `matrix` storage outside this struct goes
       through these, so the storage behind them can later become one flat
       numeric buffer without touching any caller. Elements are therefore
       passed BY VALUE, never by reference: a flat buffer of doubles has no
       `Value` object to hand out a reference to. Numeric loops should use
       numAt()/setNumAt(), which skip building a whole Value per element. */

    /* sizes

       rows() / cols() / at(r, c) and the rest of this section are the 2-D
       view. An N-dimensional matrix (isND()) answers 0 rows and 0 columns
       here, so code written for 2-D matrices sees it as empty and can never
       read a wrong element from it; N-D code uses the ndXxx() accessors
       further down. */

    size_t length() const
    {
        if (packed1())
            return rd().tensor->shape[0];
        return colArr() ? colRows() : rd().array.size();
    }
    size_t rows() const
    {
        if (packed2())
            return rd().tensor->shape[0];
        return colMat() ? colRows() : rd().matrix.size();
    }
    // Column count of the FIRST row (0 for an empty matrix). Rows are not
    // guaranteed equal-length in the cell form - use rowLength(r) where
    // that matters.
    size_t cols() const
    {
        if (packed2())
            return rd().tensor->shape[1];
        if (colMat())
            return colCount();
        return rd().matrix.empty() ? 0 : rd().matrix[0].size();
    }
    size_t rowLength(size_t r) const
    {
        if (packed2())
            return rd().tensor->shape[1];
        return colMat() ? colCount() : rd().matrix[r].size();
    }

    /* element read */

    Value at(size_t i) const
    {
        if (packed1())
            return elemOf(i);
        return colArr() ? colAt(i, 0) : rd().array[i];
    }
    Value at(size_t r, size_t c) const
    {
        if (packed2())
            return elemOf(offset(r, c));
        return colMat() ? colAt(r, c) : rd().matrix[r][c];
    }
    // The element's number; for a complex element, its real part.
    double numAt(size_t i) const
    {
        if (!packed1())
            return colArr() ? colNum(i, 0) : rd().array[i].number;
        return typed() ? typedNum(i) : rd().tensor->realAt(i * stride());
    }
    double numAt(size_t r, size_t c) const
    {
        if (!packed2())
            return colMat() ? colNum(r, c) : rd().matrix[r][c].number;
        return typed() ? typedNum(offset(r, c)) : rd().tensor->realAt(offset(r, c) * stride());
    }
    // The element as a complex number (imaginary part 0 for a real one).
    std::complex<double> cnumAt(size_t i) const
    {
        if (packed1())
            return cplxOf(i);
        return colArr() ? colCplx(i, 0) : cplxOf(rd().array[i]);
    }
    std::complex<double> cnumAt(size_t r, size_t c) const
    {
        if (packed2())
            return cplxOf(offset(r, c));
        return colMat() ? colCplx(r, c) : cplxOf(rd().matrix[r][c]);
    }

    /* element write */

    void setAt(size_t i, const Value &v)
    {
        if (colArr()) {
            colSet(i, 0, v);
            return;
        }
        if (packed1()) {
            if (fits(v)) {
                store(i, v);
                return;
            }
            unpack();
        }
        wr().array[i] = v;
    }
    void setAt(size_t r, size_t c, const Value &v)
    {
        if (colMat()) {
            colSet(r, c, v);
            return;
        }
        if (packed2()) {
            if (fits(v)) {
                store(offset(r, c), v);
                return;
            }
            unpack();
        }
        wr().matrix[r][c] = v;
    }
    // Overwrites only the element's number, leaving everything else about
    // it (unit dimensions, ...) as it was.
    // On a typed tensor this switches to cells first, so the element keeps
    // the old cell behaviour (its type tag goes stale and it reads back as
    // the float64 it now holds).
    void setNumAt(size_t i, double n)
    {
        if (colArr()) { // as on a cell: the element keeps everything but its number
            Value x = colAt(i, 0);
            x.number = n;
            colSet(i, 0, x);
            return;
        }
        if (typed())
            unpack();
        if (packed1()) {
            ownTensor();
            rd().tensor->buf[i * stride()] = n;
        } else {
            wr().array[i].number = n;
        }
    }
    void setNumAt(size_t r, size_t c, double n)
    {
        if (colMat()) {
            // as on a cell: the element keeps everything but its number
            Value x = colAt(r, c);
            x.number = n;
            colSet(r, c, x);
            return;
        }
        if (typed())
            unpack();
        if (packed2()) {
            ownTensor();
            rd().tensor->buf[offset(r, c) * stride()] = n;
        } else {
            wr().matrix[r][c].number = n;
        }
    }

    /* whole rows / whole containers (copies) */

    std::vector<Value> row(size_t r) const
    {
        if (colMat()) {
            std::vector<Value> out;
            out.reserve(colCount());
            for (size_t c = 0; c < colCount(); c++)
                out.push_back(colAt(r, c));
            return out;
        }
        if (!packed2())
            return rd().matrix[r];
        std::vector<Value> out;
        out.reserve(rd().tensor->shape[1]);
        for (size_t c = 0; c < rd().tensor->shape[1]; c++)
            out.push_back(elemOf(offset(r, c)));
        return out;
    }
    void setRow(size_t r, const std::vector<Value> &v)
    {
        if (colMat()) {
            if (v.size() == colCount()) {
                for (size_t c = 0; c < v.size(); c++)
                    colSet(r, c, v[c]);
                return;
            }
            uncolumn(); // a row of another length: cells
        }
        if (packed2()) {
            bool allFit = v.size() == rd().tensor->shape[1];
            for (size_t c = 0; allFit && c < v.size(); c++)
                allFit = fits(v[c]);
            if (allFit) {
                for (size_t c = 0; c < v.size(); c++)
                    store(offset(r, c), v[c]);
                return;
            }
            unpack();
        }
        wr().matrix[r] = v;
    }
    std::vector<Value> elems() const
    {
        if (colArr()) {
            std::vector<Value> out;
            out.reserve(colRows());
            for (size_t i = 0; i < colRows(); i++)
                out.push_back(colAt(i, 0));
            return out;
        }
        if (!packed1())
            return rd().array;
        std::vector<Value> out;
        out.reserve(rd().tensor->shape[0]);
        for (size_t i = 0; i < rd().tensor->shape[0]; i++)
            out.push_back(elemOf(i));
        return out;
    }
    std::vector<std::vector<Value>> rowsCopy() const
    {
        if (colMat()) {
            std::vector<std::vector<Value>> out(colRows());
            for (size_t r = 0; r < out.size(); r++)
                out[r].reserve(colCount());
            for (size_t c = 0; c < colCount(); c++) // column by column: each column read front to back
                for (size_t r = 0; r < out.size(); r++)
                    out[r].push_back(colAt(r, c));
            return out;
        }
        if (!packed2())
            return rd().matrix;
        std::vector<std::vector<Value>> out;
        out.reserve(rd().tensor->shape[0]);
        for (size_t r = 0; r < rd().tensor->shape[0]; r++)
            out.push_back(row(r));
        return out;
    }

    void append(const Value &v)
    {
        if (colArr())
            uncolumn(); // a growing array: cells (the constructor stores a finished one by column)
        if (packed1()) {
            if (fits(v)) {
                ownTensor();
                if (typed())
                    rd().tensor->raw.resize(rd().tensor->raw.size() + elemTypeBytes(rd().tensor->etype));
                else
                    rd().tensor->buf.resize(rd().tensor->buf.size() + stride());
                rd().tensor->shape[0]++;
                store(rd().tensor->shape[0] - 1, v);
                return;
            }
            unpack();
        }
        wr().array.push_back(v);
    }

    // Replaces each array element / matrix cell with fn(element). fn sees
    // and returns a whole Value, so anything it doesn't deliberately change
    // (unit dimensions, fraction text, a nested array) survives. Matrix
    // cells are visited row by row. General but slow on packed data (it
    // builds a Value per element) - numeric code should prefer mapPacked().
    template <typename Fn> void transformElems(Fn fn)
    {
        if (!box_)
            return; // nothing stored, so no elements
        bool wasPacked = static_cast<bool>(rd().tensor);
        const bool wasColumnar = static_cast<bool>(rd().cstore);
        if (wasColumnar)
            uncolumn();
        unpack();
        for (auto &elem : wr().array)
            elem = fn(static_cast<const Value &>(elem));
        for (auto &matRow : wr().matrix)
            for (auto &cell : matRow)
                cell = fn(static_cast<const Value &>(cell));
        for (auto &cell : wr().ndCells)
            cell = fn(static_cast<const Value &>(cell));
        if (wasPacked)
            repack();
        else if (wasColumnar && isMatrix && columnarCandidate(rd().matrix))
            if (auto cs = columnarize(wr().matrix))
                wr().cstore = std::move(cs); // columnarize() emptied the matrix
        if (wasColumnar && isArray && rd().array.size() >= 16)
            if (auto cs = columnarizeArray(wr().array))
                wr().cstore = std::move(cs);
    }

    /* ---- N-dimensional matrices (rank >= 3) ----

       [1,2;3,4;;5,6;7,8] is a 2x2x2 matrix: isMatrix is set, as for every
       matrix, and isND() tells it apart from a 2-D one. Shape
       [d0, ..., d(n-3), rows, cols]; elements live in the order described
       at NumTensor (2-D column-major pages, pages in row-major order of the
       leading indices). The "storage index" k below counts elements in that
       order, 0 .. ndCount()-1. The helpers in ops/matrix/nd_array.h turn a
       multi-index into a storage index. */

    bool isND() const
    {
        if (!isMatrix || !box_)
            return false;
        return rd().tensor ? rd().tensor->shape.size() >= 3 : rd().ndShape.size() >= 3;
    }

    // N-D only: the shape.
    const std::vector<size_t> &ndShape() const
    {
        return rd().tensor ? rd().tensor->shape : rd().ndShape;
    }
    size_t ndRank() const { return ndShape().size(); }
    size_t ndCount() const
    {
        size_t n = 1;
        for (size_t d : ndShape())
            n *= d;
        return n;
    }

    // N-D only: element at storage index k.
    Value ndAt(size_t k) const { return rd().tensor ? elemOf(k) : rd().ndCells[k]; }
    double ndNumAt(size_t k) const
    {
        if (!rd().tensor)
            return rd().ndCells[k].number;
        return typed() ? typedNum(k) : rd().tensor->realAt(k * stride());
    }
    std::complex<double> ndCnumAt(size_t k) const
    {
        return rd().tensor ? cplxOf(k) : cplxOf(rd().ndCells[k]);
    }

    // N-D only: overwrite the element at storage index k. A value the
    // packed buffer cannot hold switches the matrix to cells.
    void ndSetAt(size_t k, const Value &v)
    {
        if (rd().tensor) {
            if (fits(v)) {
                store(k, v);
                return;
            }
            unpack();
        }
        wr().ndCells[k] = v;
    }

    // An N-D matrix (shape.size() >= 3) holding `cells` in storage order
    // (cells.size() must equal the product of the shape). Packed when every
    // cell is a plain number sharing one unit, cells otherwise.
    static Value ndFromCells(std::vector<size_t> shape, std::vector<Value> cells)
    {
        Value v;
        v.isMatrix = true;
        if (auto t = pack(cells)) {
            t->shape = std::move(shape);
            v.wr().tensor = std::move(t);
        } else {
            v.wr().ndCells = std::move(cells);
            v.wr().ndShape = std::move(shape);
        }
        return v;
    }

    // An N-D matrix straight from a packed buffer in storage order (two
    // doubles per element, re then im, when `complex`). Every element
    // carries the unit l/t/m.
    static Value ndPacked(std::vector<size_t> shape, nc::F64Buf buf, bool complex,
                          int16_t l = 0, int16_t t = 0, int16_t m = 0)
    {
        Value v;
        v.isMatrix = true;
        auto tensor = std::make_shared<NumTensor>();
        tensor->shape = std::move(shape);
        tensor->buf = std::move(buf);
        tensor->complex = complex;
        tensor->dimL = l;
        tensor->dimT = t;
        tensor->dimM = m;
        v.wr().tensor = std::move(tensor);
        return v;
    }

    /* ---- packed (flat numeric buffer) fast paths ---- */

    // True when the elements are held as one flat buffer of plain REAL
    // numbers. A packed complex tensor answers false here on purpose: every
    // caller of this takes the buffer to be one double per element.
    // A typed tensor (uint8 ...) answers false: its elements are typed
    // scalars, and code on this fast path computes plain float64.
    bool isPacked() const { return rd().tensor && !rd().tensor->complex && rd().tensor->etype == ElemType::F64; }

    // A lazy range (2026-11-20): the 1 x count float64 row of `s` - the
    // value the range literal always gave - holding only the rule; its
    // buffer is built the first time something needs the whole of it
    // (NumTensor::materialize()). count >= 1.
    static Value lazyRow(const ncrange::Spec &s)
    {
        Value v;
        v.isMatrix = true;
        auto t = std::make_shared<NumTensor>();
        t->shape = {1, static_cast<size_t>(s.count)};
        t->range = s;
        t->pending.store(true, std::memory_order_relaxed);
        v.wr().tensor = std::move(t);
        return v;
    }
    // True, with its rule, while this is a PLAIN lazy range whose buffer has
    // not been built: element k of the storage order is ncrange::valueAt(out,
    // k). False for a lazy tensor with an arithmetic chain (lazyTensor()).
    bool lazyRange(ncrange::Spec &out) const
    {
        const auto &t = rd().tensor;
        if (!t || !t->pending.load(std::memory_order_acquire) || !t->ops.empty() || t->base)
            return false;
        out = t->range;
        return true;
    }
    // Any lazy tensor (a range, with or without an arithmetic chain) whose
    // buffer has not been built, or null: element k is its lazyValue(k).
    // The tensor never changes while it is lazy (2026-11-21).
    const NumTensor *lazyTensor() const
    {
        const auto &t = rd().tensor;
        return t && t->pending.load(std::memory_order_acquire) ? t.get() : nullptr;
    }
    // A lazy tensor's value with one more scalar step (A*1000, A - 1, -A):
    // still lazy, same shape, a fresh stamp. False (out untouched) when this
    // is not a unitless real lazy tensor or the chain is full - the caller
    // then computes it as usual.
    bool withLazyOp(NumTensor::LazyOpKind kind, double c, Value &out) const
    {
        const NumTensor *t = lazyTensor();
        if (!t || t->complex || t->etype != ElemType::F64 || t->dimL || t->dimT || t->dimM ||
            t->ops.size() >= NumTensor::kMaxLazyOps)
            return false;
        auto copy = std::make_shared<NumTensor>(*t);
        if (!copy->pending.load(std::memory_order_acquire))
            return false; // built meanwhile (another thread): compute as usual
        copy->ops.push_back({kind, c});
        copy->stamp = NumTensor::nextStamp();
        Value v;
        v.isArray = isArray;
        v.isMatrix = isMatrix;
        v.wr().tensor = std::move(copy);
        out = std::move(v);
        return true;
    }

    // A lazy VIEW of this stored, unitless, real float64 matrix / array
    // (2026-11-23): the same values, as a rule over this buffer (shared, not
    // copied), ready for withLazyOp / withLazyFn / withLazyZip. False for
    // anything else (already lazy, typed, complex, with a unit, N-D, empty).
    bool lazyView(Value &out) const
    {
        if (!(isArray || isMatrix) || !isPacked() || isND())
            return false;
        const std::shared_ptr<NumTensor> &t = rd().tensor;
        if (!t || t->pending.load(std::memory_order_acquire) || t->complex || t->etype != ElemType::F64 ||
            t->dimL || t->dimT || t->dimM || t->buf.empty())
            return false;
        auto view = std::make_shared<NumTensor>();
        view->shape = t->shape;
        view->range.count = static_cast<int64_t>(t->buf.size());
        view->base = t;
        view->pending.store(true, std::memory_order_relaxed);
        Value v;
        v.isArray = isArray;
        v.isMatrix = isMatrix;
        v.wr().tensor = std::move(view);
        out = std::move(v);
        return true;
    }

    // A lazy tensor's value with one more FUNCTION step (2026-11-23):
    // sin(A) of a lazy A stays a rule. fn must be pure (it runs on several
    // threads, any order) and the very function the eager kernel applies, so
    // every element has the same bits. False (out untouched) when this is not
    // a unitless real lazy tensor or the tree is full - the caller computes
    // it as usual.
    bool withLazyFn(double (*fn)(double), Value &out) const
    {
        NumTensor::LazyOp op{NumTensor::LazyOpKind::Fn1, 0.0};
        op.fn1 = fn;
        return fn && withLazyStep(std::move(op), out);
    }
    // fn(element, c) (scalarRight) or fn(c, element) as one more step
    // (2026-11-23, Phase 5): X^.2, 2^.X of a lazy X. Same rules as
    // withLazyFn(); c is a plain unitless real number.
    bool withLazyFnScalar(double (*fn)(double, double), double c, bool scalarRight, Value &out) const
    {
        NumTensor::LazyOp op{scalarRight ? NumTensor::LazyOpKind::Fn2C : NumTensor::LazyOpKind::Fn2CR, c};
        op.fn2 = fn;
        return fn && withLazyStep(std::move(op), out);
    }
    // withLazyFn / withLazyFnScalar: `op` appended to a copy of the chain.
    bool withLazyStep(NumTensor::LazyOp op, Value &out) const
    {
        const NumTensor *t = lazyTensor();
        if (!t || t->complex || t->etype != ElemType::F64 || t->dimL || t->dimT || t->dimM ||
            t->ops.size() >= NumTensor::kMaxLazyOps || t->lazyNodes() >= NumTensor::kMaxLazyNodes)
            return false;
        auto copy = std::make_shared<NumTensor>(*t);
        if (!copy->pending.load(std::memory_order_acquire))
            return false; // built meanwhile: compute as usual
        copy->ops.push_back(std::move(op));
        copy->stamp = NumTensor::nextStamp();
        Value v;
        v.isArray = isArray;
        v.isMatrix = isMatrix;
        v.wr().tensor = std::move(copy);
        out = std::move(v);
        return true;
    }
    // fn(this, other) element by element (thisLeft) or fn(other, this), as a
    // rule: at least one side lazy, both unitless real packed float64 of the
    // same shape and kind (array / matrix). The other side's tensor is
    // shared, never copied; if it is a stored buffer, a later write to its
    // variable copies that buffer first (copy on write), so the rule keeps
    // reading the values it was made from. False: compute as usual.
    bool withLazyZip(const Value &other, double (*fn)(double, double), bool thisLeft, Value &out) const
    {
        if (!fn || isArray != other.isArray || isMatrix != other.isMatrix || !isPacked() || !other.isPacked())
            return false;
        const std::shared_ptr<NumTensor> &a = rd().tensor;
        const std::shared_ptr<NumTensor> &b = other.rd().tensor;
        if (!a || !b || a->shape != b->shape)
            return false;
        auto plainReal = [](const NumTensor &t) {
            return !t.complex && t.etype == ElemType::F64 && !t.dimL && !t.dimT && !t.dimM;
        };
        if (!plainReal(*a) || !plainReal(*b))
            return false;
        const bool aLazy = a->pending.load(std::memory_order_acquire);
        const bool bLazy = b->pending.load(std::memory_order_acquire);
        if (!aLazy && !bLazy)
            return false;
        // The lazy side carries the chain; the other one is its operand.
        const std::shared_ptr<NumTensor> &base = aLazy ? a : b;
        const std::shared_ptr<NumTensor> &operand = aLazy ? b : a;
        const bool baseLeft = aLazy ? thisLeft : !thisLeft;
        const size_t nodes = base->lazyNodes() + 1 + (operand->pending.load() ? operand->lazyNodes() : 0);
        if (base->ops.size() >= NumTensor::kMaxLazyOps || nodes > NumTensor::kMaxLazyNodes)
            return false;
        auto copy = std::make_shared<NumTensor>(*base);
        if (!copy->pending.load(std::memory_order_acquire))
            return false;
        NumTensor::LazyOp op{baseLeft ? NumTensor::LazyOpKind::Fn2L : NumTensor::LazyOpKind::Fn2R, 0.0};
        op.fn2 = fn;
        op.other = operand;
        copy->ops.push_back(std::move(op));
        copy->stamp = NumTensor::nextStamp();
        Value v;
        v.isArray = isArray;
        v.isMatrix = isMatrix;
        v.wr().tensor = std::move(copy);
        out = std::move(v);
        return true;
    }

    // The packed buffer's stamp (NumTensor::stamp): equal stamps mean equal
    // bytes. 0 when there is no packed buffer.
    uint64_t tensorStamp() const { return box_ && rd().tensor ? rd().tensor->stamp : 0; }

    // True when `v` is a cell that pack() turns into a plain unitless real
    // float64 element: cells that all answer true pack into a real tensor
    // with no unit, so a builder may write their numbers into a buffer
    // directly (core/packed_build.h, 2026-11-20).
    static bool packsAsPlainReal(const Value &v)
    {
        return isPackable(v) && !v.isComplex && v.dimL == 0 && v.dimT == 0 && v.dimM == 0;
    }

    // True when the elements are held as one flat buffer of complex numbers.
    bool isPackedComplex() const { return rd().tensor && rd().tensor->complex; }

    /* ---- typed tensors (R9): int8 ... uint64, bool, float32/16/8 ---- */

    // Every element one integer type / bool / narrow float, held compactly.
    bool isTypedPacked() const { return typed(); }
    // The element type of a typed tensor; F64 for anything else.
    ElemType elemType() const { return rd().tensor ? rd().tensor->etype : ElemType::F64; }
    // Typed only: shape (as for an N-D matrix: {n}, {rows, cols}, {d0, ..}).
    const std::vector<size_t> &tensorShape() const { return rd().tensor->shape; }
    size_t tensorCount() const
    {
        size_t n = 1;
        for (size_t d : rd().tensor->shape)
            n *= d;
        return n;
    }
    // Typed only: the elements, elemTypeBytes() each, in storage order.
    const uint8_t *typedData() const { return rd().tensor->raw.data(); }
    uint8_t *typedDataMut()
    {
        ownTensor();
        return rd().tensor->raw.data();
    }
    // Bytes the elements take (packed of any type; 0 for cells).
    size_t tensorBytes() const
    {
        if (!rd().tensor)
            return 0;
        return typed() ? rd().tensor->raw.size() : packedSize() * sizeof(double);
    }
    // The one unit of a number, or of a packed array / matrix (every element
    // of one shares it). All zero for a unitless value and for anything
    // else (text, cells, dicts ...).
    void unitDims(int16_t &l, int16_t &t, int16_t &m) const
    {
        if (box_ && rd().tensor) {
            l = rd().tensor->dimL;
            t = rd().tensor->dimT;
            m = rd().tensor->dimM;
        } else if (!isText && !isArray && !isMatrix && !isDict && !isObject && !isFunctionRef) {
            l = dimL;
            t = dimT;
            m = dimM;
        } else {
            l = t = m = 0;
        }
    }
    bool hasUnit() const
    {
        int16_t l, t, m;
        unitDims(l, t, m);
        return l != 0 || t != 0 || m != 0;
    }
    // Sets that unit (on a number, or on every element of a packed array /
    // matrix); anything else is left as it is.
    void setUnitDims(int16_t l, int16_t t, int16_t m)
    {
        if (box_ && rd().tensor) {
            if (rd().tensor->dimL == l && rd().tensor->dimT == t && rd().tensor->dimM == m)
                return;
            ownTensor();
            NumTensor &ten = *wr().tensor;
            ten.dimL = l;
            ten.dimT = t;
            ten.dimM = m;
        } else if (!isText && !isArray && !isMatrix && !isDict && !isObject && !isFunctionRef) {
            dimL = l;
            dimT = t;
            dimM = m;
        }
    }

    // Typed only: the unit of every element.
    int16_t tensorDimL() const { return rd().tensor->dimL; }
    int16_t tensorDimT() const { return rd().tensor->dimT; }
    int16_t tensorDimM() const { return rd().tensor->dimM; }
    // Element k (storage order) of a typed tensor as a double.
    double typedNumAt(size_t k) const { return typedNum(k); }

    // Typed only: the plain float64 tensor of the same values, shape and
    // unit - what every float64 computation on the elements sees.
    Value widenedToF64() const
    {
        const NumTensor &t = *rd().tensor;
        Value v;
        v.isArray = isArray;
        v.isMatrix = isMatrix;
        auto out = std::make_shared<NumTensor>();
        out->shape = t.shape;
        out->dimL = t.dimL;
        out->dimT = t.dimT;
        out->dimM = t.dimM;
        const size_t n = tensorCount();
        out->buf.resize(n);
        for (size_t k = 0; k < n; k++)
            out->buf[k] = typedNum(k);
        v.wr().tensor = std::move(out);
        return v;
    }

    // A typed array (shape {n}) or matrix / N-D matrix (shape {rows, cols}
    // or longer) from `raw` (elemTypeBytes(t) per element, storage order).
    static Value typedTensor(ElemType t, std::vector<size_t> shape, std::vector<uint8_t> raw, int16_t l = 0,
                             int16_t tm = 0, int16_t m = 0)
    {
        Value v;
        if (shape.size() == 1)
            v.isArray = true;
        else
            v.isMatrix = true;
        auto ten = std::make_shared<NumTensor>();
        ten->etype = t;
        ten->shape = std::move(shape);
        ten->raw = std::move(raw);
        ten->dimL = l;
        ten->dimT = tm;
        ten->dimM = m;
        v.wr().tensor = std::move(ten);
        return v;
    }

    // The element type a scalar would be stored as in a typed tensor
    // (F64 = not a typed scalar: plain, complex, time, a stale tag ...).
    static ElemType scalarElemType(const Value &v)
    {
        if (v.isText || v.isArray || v.isMatrix || v.isDict || v.isObject || v.isFunctionRef || v.isComplex ||
            (v.box_ && !v.box_->isBlank()))
            return ElemType::F64;
        if (v.isBool())
            return ElemType::Bool;
        switch (v.intType()) {
        case IntType::Int8: return ElemType::I8;
        case IntType::Int16: return ElemType::I16;
        case IntType::Int32: return ElemType::I32;
        case IntType::Int64: return ElemType::I64;
        case IntType::UInt8: return ElemType::U8;
        case IntType::UInt16: return ElemType::U16;
        case IntType::UInt32: return ElemType::U32;
        case IntType::UInt64: return ElemType::U64;
        case IntType::None: break;
        }
        switch (v.floatType()) {
        case FloatType::Float32: return ElemType::F32;
        case FloatType::Float16: return ElemType::F16;
        case FloatType::Float8: return ElemType::F8;
        case FloatType::Float64: break;
        }
        return ElemType::F64;
    }

    // The typed scalar for raw element bits: integers from their exact
    // value (int64 / uint64 bit pattern), floats and bools from `x`.
    static Value typedScalar(ElemType t, int64_t bits, double x)
    {
        switch (t) {
        case ElemType::I8: return integerSigned(IntType::Int8, bits);
        case ElemType::I16: return integerSigned(IntType::Int16, bits);
        case ElemType::I32: return integerSigned(IntType::Int32, bits);
        case ElemType::I64: return integerSigned(IntType::Int64, bits);
        case ElemType::U8: return integerUnsigned(IntType::UInt8, static_cast<uint64_t>(bits));
        case ElemType::U16: return integerUnsigned(IntType::UInt16, static_cast<uint64_t>(bits));
        case ElemType::U32: return integerUnsigned(IntType::UInt32, static_cast<uint64_t>(bits));
        case ElemType::U64: return integerUnsigned(IntType::UInt64, static_cast<uint64_t>(bits));
        case ElemType::F32: return floating(FloatType::Float32, x);
        case ElemType::F16: return floating(FloatType::Float16, x);
        case ElemType::F8: return floating(FloatType::Float8, x);
        case ElemType::Bool: return boolean(x != 0.0);
        case ElemType::F64: break;
        }
        return Value(x);
    }

    // Packed complex only: the buffer, `re, im` per element, column-major
    // for a matrix.
    const std::complex<double> *packedComplexData() const
    {
        rd().tensor->materialize();
        return reinterpret_cast<const std::complex<double> *>(rd().tensor->buf.data());
    }

    // A unitless packed complex array / matrix copied from `n` (or
    // rows*cols, column-major) complex numbers. Sizes must be non-zero.
    static Value packedComplexArray(const std::complex<double> *data, size_t n)
    {
        Value v;
        v.isArray = true;
        v.wr().tensor = complexTensor(data, n);
        v.rd().tensor->shape = {n};
        return v;
    }
    static Value packedComplexMatrix(const std::complex<double> *colMajor, size_t nrows,
                                     size_t ncols)
    {
        Value v;
        v.isMatrix = true;
        v.wr().tensor = complexTensor(colMajor, nrows * ncols);
        v.rd().tensor->shape = {nrows, ncols};
        return v;
    }

    // If this is a packed complex array/matrix whose imaginary parts are all
    // exactly zero, turn it into the ordinary real packed form.
    void narrowIfReal()
    {
        if (!isPackedComplex())
            return;
        const nc::F64Buf &src = rd().tensor->buf;
        for (size_t k = 1; k < src.size(); k += 2)
            if (src[k] != 0.0)
                return;
        auto t = std::make_shared<NumTensor>();
        t->shape = rd().tensor->shape;
        t->dimL = rd().tensor->dimL;
        t->dimT = rd().tensor->dimT;
        t->dimM = rd().tensor->dimM;
        t->buf.resize(src.size() / 2);
        for (size_t k = 0; k < t->buf.size(); k++)
            t->buf[k] = src[2 * k] + 0.0; // + 0.0: no negative zeros
        wr().tensor = std::move(t);
    }

    // Packed only: the buffer itself, column-major for a matrix.
    const double *packedData() const
    {
        rd().tensor->materialize(); // a lazy range: built here, once
        return rd().tensor->buf.data();
    }

    // A unitless packed array / matrix copied from `n` (or rows*cols,
    // column-major) doubles.
    static Value packedArray(const double *data, size_t n)
    {
        Value v;
        v.isArray = true;
        v.wr().tensor = std::make_shared<NumTensor>();
        v.rd().tensor->buf.assign(data, data + n);
        v.rd().tensor->shape = {n};
        return v;
    }
    static Value packedMatrix(const double *colMajor, size_t nrows, size_t ncols)
    {
        Value v;
        v.isMatrix = true;
        v.wr().tensor = std::make_shared<NumTensor>();
        v.rd().tensor->buf.assign(colMajor, colMajor + nrows * ncols);
        v.rd().tensor->shape = {nrows, ncols};
        return v;
    }

    // Packed only: a copy of this Value with every element replaced by the
    // unitless number fn(element) - what assigning `Value(fn(x))` to each
    // element does, without building those Values. Elements are visited in
    // storage order, so fn must not depend on the order it is called in.
    template <typename Fn> Value mapPacked(Fn fn) const
    {
        rd().tensor->materialize();
        Value result = *this;
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        out->buf.resize(rd().tensor->buf.size());
        forEachOffset([&](size_t k) { out->buf[k] = fn(rd().tensor->buf[k]); });
        result.wr().tensor = std::move(out);
        return result;
    }

    // Packed only, `other` packed with the same shape: like mapPacked(),
    // with fn(thisElement, otherElement).
    template <typename Fn> Value zipPacked(const Value &other, Fn fn) const
    {
        rd().tensor->materialize();
        other.rd().tensor->materialize();
        Value result = *this;
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        out->buf.resize(rd().tensor->buf.size());
        forEachOffset(
            [&](size_t k) { out->buf[k] = fn(rd().tensor->buf[k], other.rd().tensor->buf[k]); });
        result.wr().tensor = std::move(out);
        return result;
    }

    // Packed only: the whole-buffer forms of mapPacked() / zipPacked(), for
    // multicore kernels (nc::par). The result has this Value's shape and no
    // unit, like mapPacked()'s. fill(in, out, n) - or fill(a, b, out, n) -
    // writes all n results and returns false to give the result up (Stop
    // pressed); `result` is then left untouched.
    //
    // A LAZY operand (a range, maybe with a chain) is never built for these
    // (2026-11-21): its elements are generated straight into the result's
    // buffer and fill() runs in place there (in == out) - every fill of
    // these two is element by element (out[k] from in[k] only, see
    // core/elementwise.h), so the values are the same, the operand stays a
    // rule, and the peak memory is the result alone.
    static void fillFromLazy(const NumTensor &lazy, double *out, size_t n)
    {
        if (NumTensor::lazyFiller)
            NumTensor::lazyFiller(lazy, out, n);
        else
            for (size_t k = 0; k < n; k++)
                out[k] = lazy.lazyValue(k);
    }
    template <typename Fill> bool mapPackedBuffer(Fill fill, Value &result) const
    {
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        if (const NumTensor *lazy = lazyTensor()) {
            const size_t n = packedSize();
            out->buf.resize(n);
            fillFromLazy(*lazy, out->buf.data(), n);
            if (!fill(out->buf.data(), out->buf.data(), n))
                return false;
        } else {
            rd().tensor->materialize();
            out->buf.resize(rd().tensor->buf.size());
            if (!fill(rd().tensor->buf.data(), out->buf.data(), out->buf.size()))
                return false;
        }
        result = *this;
        result.wr().tensor = std::move(out);
        return true;
    }
    template <typename Fill> bool zipPackedBuffer(const Value &other, Fill fill, Value &result) const
    {
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        const size_t n = packedSize();
        out->buf.resize(n);
        // This side: generated into the result (in place) or read where it is.
        const double *a = nullptr;
        if (const NumTensor *lazy = lazyTensor()) {
            fillFromLazy(*lazy, out->buf.data(), n);
            a = out->buf.data();
        } else {
            rd().tensor->materialize();
            a = rd().tensor->buf.data();
        }
        // The other side: a lazy one is generated into a temporary buffer
        // (freed after), so it stays a rule.
        std::vector<double> otherTemp;
        const double *b = nullptr;
        if (const NumTensor *lazyB = other.lazyTensor()) {
            otherTemp.resize(n);
            fillFromLazy(*lazyB, otherTemp.data(), n);
            b = otherTemp.data();
        } else {
            other.rd().tensor->materialize();
            b = other.rd().tensor->buf.data();
        }
        if (!fill(a, b, out->buf.data(), n))
            return false;
        result = *this;
        result.wr().tensor = std::move(out);
        return true;
    }

    // Packed (real or complex): a copy of this Value - same shape, same unit,
    // same real/complex form - whose raw buffer is filled by
    // fill(in, out, nDoubles). For operations that keep the unit, such as
    // negation (mapPackedBuffer() above drops it). False (result untouched)
    // when fill gives up (Stop pressed).
    template <typename Fill> bool mapPackedKeepUnit(Fill fill, Value &result) const
    {
        rd().tensor->materialize();
        const NumTensor &src = *rd().tensor;
        auto out = std::make_shared<NumTensor>();
        out->shape = src.shape;
        out->complex = src.complex;
        out->dimL = src.dimL;
        out->dimT = src.dimT;
        out->dimM = src.dimM;
        out->buf.resize(src.buf.size());
        if (!fill(src.buf.data(), out->buf.data(), out->buf.size()))
            return false;
        result = *this;
        result.wr().tensor = std::move(out);
        return true;
    }

    // Packed vector (1 x n or n x 1 matrix, real or complex) -> the 1-D
    // array of its elements, same unit; a buffer copy instead of one Value
    // per element. Both orientations store their elements in order.
    Value packedVectorAsArray() const
    {
        Value v;
        v.isArray = true;
        auto t = std::make_shared<NumTensor>(*rd().tensor);
        t->shape = {rd().tensor->shape[0] * rd().tensor->shape[1]};
        v.wr().tensor = std::move(t);
        return v;
    }

    // Packed 1-D array -> a 1 x n row or n x 1 column matrix, same unit.
    Value packedArrayAsVector(bool column) const
    {
        Value v;
        v.isMatrix = true;
        auto t = std::make_shared<NumTensor>(*rd().tensor);
        const size_t n = rd().tensor->shape[0];
        t->shape = column ? std::vector<size_t>{n, 1} : std::vector<size_t>{1, n};
        v.wr().tensor = std::move(t);
        return v;
    }

    // A unitless packed 1-D array that takes over `buf` (no copy).
    static Value packedArrayFrom(nc::F64Buf &&buf)
    {
        Value v;
        v.isArray = true;
        auto t = std::make_shared<NumTensor>();
        t->shape = {buf.size()};
        t->buf = std::move(buf);
        v.wr().tensor = std::move(t);
        return v;
    }

    // Packed only: number of doubles in the buffer (elements, real form).
    size_t packedSize() const
    {
        const NumTensor &t = *rd().tensor;
        return t.pending.load(std::memory_order_acquire) ? static_cast<size_t>(t.range.count) : t.buf.size();
    }

    bool sameShapeAs(const Value &other) const
    {
        return isPacked() && other.isPacked() && rd().tensor->shape == other.rd().tensor->shape;
    }

    /* ---- columnar matrices (2026-11-15, docs/Import_Window.md §9) ----

       A 2-D matrix whose cells cannot be packed (a table with a text
       column, say) used to be one 32-byte Value per cell plus a Box of a
       few hundred bytes per text. When its columns are each mostly of one
       kind it is now stored by columns instead:
        - Num:  float64 numbers (one unit per column), or one typed element
                type (int8 ... uint64, bool, float32/16/8) as in a typed
                tensor (R9);
        - Text: the texts in one UTF-8 arena + offsets; a column with few
                distinct texts keeps each once (a dictionary) + a code per row;
        - Time: timestamps or durations, int64 nanoseconds;
        - Cells: one Value per row (no common kind).
       A cell that does not fit its column's kind (a NaN in a text column, a
       blank text in a number column) is kept whole as an exception of that
       column, so one odd cell does not turn a column back into cells.

       Nothing outside sees the difference: rows() / cols() / at(r, c) /
       setAt() ... give and take exactly the cells the cell form held (each
       is rebuilt on reading), isPacked() stays false. Built by the matrix
       constructors (a non-packable rectangular matrix of 16 rows or more)
       and by the table readers through ColumnBuilder. */

    struct Column
    {
        enum class Kind : uint8_t { Num, Text, Time, Cells };
        Kind kind = Kind::Cells;
        size_t n = 0; // rows

        // Num: etype F64 -> f64, else raw (elemTypeBytes(etype) per row).
        ElemType etype = ElemType::F64;
        int16_t dimL = 0, dimT = 0, dimM = 0;
        nc::F64Buf f64; // RAM, or the disk tier when big (2026-11-23, Phase 4: imported columns)
        std::vector<uint8_t> raw;

        // Text: entry e is arena[off[e] .. off[e+1]) (off32 while the arena
        // is under 4 GB, off64 after). Row r is entry codes[r] when `codes`
        // is set (dictionary), else entry r.
        std::string arena;
        std::vector<uint32_t> off32;
        std::vector<uint64_t> off64;
        std::vector<uint32_t> codes;

        // Time: Value::kTimestampTag or kDurationTag.
        std::vector<int64_t> ns;
        uint8_t timeTag = 0;

        // Cells.
        std::vector<Value> cells;

        // Exceptions (Num / Text / Time): rows whose cell is held whole.
        // Sorted rows; a bit per row to answer "is it one?" at once.
        std::vector<size_t> excRows;
        std::vector<Value> excVals;
        std::vector<uint64_t> excBits;

        size_t entryCount() const
        {
            if (!off64.empty())
                return off64.size() - 1;
            return off32.empty() ? 0 : off32.size() - 1;
        }
        std::string_view entry(size_t e) const
        {
            if (!off64.empty())
                return std::string_view(arena.data() + off64[e], static_cast<size_t>(off64[e + 1] - off64[e]));
            return std::string_view(arena.data() + off32[e], off32[e + 1] - off32[e]);
        }
        // Text column, not an exception: the text of row r.
        std::string_view textAt(size_t r) const { return entry(codes.empty() ? r : codes[r]); }

        bool isExc(size_t r) const { return !excBits.empty() && ((excBits[r >> 6] >> (r & 63)) & 1u) != 0; }
        const Value &excAt(size_t r) const
        {
            return excVals[static_cast<size_t>(std::lower_bound(excRows.begin(), excRows.end(), r) - excRows.begin())];
        }

        // The cell of row r, exactly as the cell form held it.
        Value get(size_t r) const
        {
            if (kind == Kind::Cells)
                return cells[r];
            if (isExc(r))
                return excAt(r);
            switch (kind) {
            case Kind::Num: {
                Value v;
                if (etype == ElemType::F64) {
                    v = Value(f64[r]);
                } else {
                    int64_t bits;
                    double x;
                    decodeTyped(etype, raw.data() + r * elemTypeBytes(etype), bits, x);
                    v = typedScalar(etype, bits, x);
                }
                v.dimL = dimL;
                v.dimT = dimT;
                v.dimM = dimM;
                return v;
            }
            case Kind::Text: return Value(std::string(textAt(r)));
            case Kind::Time: return timeTag == kTimestampTag ? timestamp(ns[r]) : duration(ns[r]);
            case Kind::Cells: break;
            }
            return cells[r];
        }
        // get(r).number without building the Value.
        double num(size_t r) const
        {
            if (kind == Kind::Cells)
                return cells[r].number;
            if (isExc(r))
                return excAt(r).number;
            switch (kind) {
            case Kind::Num: {
                if (etype == ElemType::F64)
                    return f64[r];
                int64_t bits;
                double x;
                decodeTyped(etype, raw.data() + r * elemTypeBytes(etype), bits, x);
                return x;
            }
            case Kind::Text: return 0.0; // a text Value's number
            case Kind::Time: return std::numeric_limits<double>::quiet_NaN();
            case Kind::Cells: break;
            }
            return 0.0;
        }
        // Bytes the column's own storage takes (exceptions / cells: their
        // 32-byte Values only; what those hold is the caller's to add).
        size_t storageBytes() const
        {
            return f64.size() * sizeof(double) + raw.size() + arena.size() + off32.size() * 4 + off64.size() * 8 +
                   codes.size() * 4 + ns.size() * 8 + cells.size() * sizeof(Value) +
                   excRows.size() * (sizeof(size_t) + sizeof(Value)) + excBits.size() * 8;
        }
    };

    // Builds one column cell by cell (the table readers use it to make a
    // table without making a Value per cell). The kind is taken from the
    // first cell that is not a plain NaN or an empty text; cells that do not
    // fit it become exceptions. finish() settles the column: a column that
    // ended up with more exceptions than fitting cells is rebuilt in its most
    // common kind (or as cells), a text column with few distinct texts gets
    // a dictionary.
    class ColumnBuilder
    {
      public:
        void reserve(size_t n) { reserve_ = n; }
        size_t size() const { return c_.n + pending_.size(); }

        void push(const Value &v)
        {
            if (!decided_) {
                undecided(Value(v));
                return;
            }
            add(v);
        }
        void push(Value &&v)
        {
            if (!decided_) {
                undecided(std::move(v));
                return;
            }
            add(std::move(v));
        }
        // A plain unitless float64 number (what Value(d) is).
        void pushNumber(double d)
        {
            if (decided_ && c_.kind == Column::Kind::Num && c_.etype == ElemType::F64 && c_.dimL == 0 &&
                c_.dimT == 0 && c_.dimM == 0) {
                c_.f64.push_back(d);
                c_.n++;
                return;
            }
            push(Value(d));
        }
        // A plain text (what Value(std::string(s)) is).
        void pushText(std::string_view s)
        {
            if (decided_ && c_.kind == Column::Kind::Text) {
                appendText(s);
                c_.n++;
                return;
            }
            push(Value(std::string(s)));
        }

        // Appends the cells `o` holds after this builder's (2026-11-15: a table
        // read on several cores builds a piece of each column per core, and
        // the pieces are joined in order). The builder ends as one builder
        // pushed every cell in turn would: buffers of the same kind are
        // appended, anything else goes cell by cell.
        void absorb(ColumnBuilder &&o)
        {
            if (o.size() == 0)
                return;
            if (!o.decided_) { // only cells that say nothing about the kind yet
                for (Value &v : o.pending_)
                    push(std::move(v));
                return;
            }
            if (!decided_) { // this one held only such cells: the kind is o's (its first deciding cell)
                ColumnBuilder nb;
                nb.reserve_ = std::max(reserve_, size() + o.size());
                nb.setKind(o.key());
                for (Value &v : pending_)
                    nb.add(std::move(v));
                *this = std::move(nb);
            }
            const size_t n0 = c_.n;
            Column &oc = o.c_;
            if (key() == o.key()) {
                switch (c_.kind) {
                case Column::Kind::Num:
                    if (c_.etype == ElemType::F64)
                        c_.f64.insert(c_.f64.end(), oc.f64.begin(), oc.f64.end());
                    else
                        c_.raw.insert(c_.raw.end(), oc.raw.begin(), oc.raw.end());
                    break;
                case Column::Kind::Text: {
                    // (a builder's piece has no dictionary yet: entry r is row r)
                    const size_t m = oc.entryCount(), base = c_.arena.size();
                    if (!oc.codes.empty() || c_.arena.size() + oc.arena.size() > 0xFFFFFFFFull || !c_.off64.empty()) {
                        for (size_t r = 0; r < oc.n; r++)
                            appendText(oc.textAt(r)); // (offsets shifted; 64-bit ones past 4 GB)
                        break;
                    }
                    c_.arena.append(oc.arena);
                    // (resize, not reserve: it grows geometrically, a piece at a time)
                    const size_t o0 = c_.off32.size();
                    c_.off32.resize(o0 + m);
                    for (size_t e = 1; e <= m; e++) // all buffers appended, offsets shifted
                        c_.off32[o0 + e - 1] = static_cast<uint32_t>(base + oc.off32[e]);
                    break;
                }
                case Column::Kind::Time: c_.ns.insert(c_.ns.end(), oc.ns.begin(), oc.ns.end()); break;
                case Column::Kind::Cells:
                    c_.cells.insert(c_.cells.end(), std::make_move_iterator(oc.cells.begin()),
                                    std::make_move_iterator(oc.cells.end()));
                    break;
                }
                const size_t x0 = c_.excRows.size();
                c_.excRows.resize(x0 + oc.excRows.size());
                for (size_t k = 0; k < oc.excRows.size(); k++)
                    c_.excRows[x0 + k] = n0 + oc.excRows[k];
                c_.excVals.insert(c_.excVals.end(), std::make_move_iterator(oc.excVals.begin()),
                                  std::make_move_iterator(oc.excVals.end()));
                c_.n += oc.n;
                return;
            }
            // other kinds: o's cells one by one (no exception bits yet; its exception rows ascend)
            size_t ei = 0;
            for (size_t r = 0; r < oc.n; r++) {
                if (oc.kind == Column::Kind::Cells)
                    add(std::move(oc.cells[r]));
                else if (ei < oc.excRows.size() && oc.excRows[ei] == r)
                    add(std::move(oc.excVals[ei++]));
                else
                    add(oc.get(r));
            }
        }

        // absorb() of every piece in order, each buffer sized once for all
        // of them (no regrowth while a big column is joined); `parts` ends empty.
        void absorbAll(std::vector<ColumnBuilder> &parts)
        {
            size_t n = 0, arena = 0, exc = 0;
            for (const ColumnBuilder &p : parts) {
                n += p.size();
                arena += p.c_.arena.size();
                exc += p.c_.excRows.size();
            }
            reserve_ = std::max(reserve_, size() + n); // (used when the kind is set)
            bool sized = false;
            for (ColumnBuilder &p : parts) {
                if (decided_ && !sized) {
                    sized = true;
                    const size_t want = size() + n;
                    if (c_.kind == Column::Kind::Num && c_.etype == ElemType::F64)
                        c_.f64.reserve(want);
                    else if (c_.kind == Column::Kind::Num)
                        c_.raw.reserve(want * elemTypeBytes(c_.etype));
                    else if (c_.kind == Column::Kind::Text && c_.off64.empty()) {
                        c_.arena.reserve(c_.arena.size() + arena);
                        c_.off32.reserve(want + 1);
                    } else if (c_.kind == Column::Kind::Time)
                        c_.ns.reserve(want);
                    c_.excRows.reserve(c_.excRows.size() + exc);
                    c_.excVals.reserve(c_.excVals.size() + exc);
                }
                n -= p.size(); // (what is still to come)
                arena -= p.c_.arena.size();
                exc -= p.c_.excRows.size();
                absorb(std::move(p));
                p = ColumnBuilder(); // (freed as it goes)
            }
            std::vector<ColumnBuilder>().swap(parts);
        }

        std::shared_ptr<Column> finish()
        {
            if (!decided_)
                decide(pending_.empty() ? Value() : pending_.front(), true);
            if (c_.kind == Column::Kind::Cells || c_.excRows.size() * 2 > c_.n)
                regroup();
            if (c_.kind == Column::Kind::Text)
                dictionary();
            c_.excBits.clear();
            if (!c_.excRows.empty()) {
                c_.excBits.assign((c_.n + 63) / 64, 0);
                for (size_t r : c_.excRows)
                    c_.excBits[r >> 6] |= uint64_t(1) << (r & 63);
            }
            c_.f64.shrink_to_fit();
            c_.raw.shrink_to_fit();
            c_.arena.shrink_to_fit();
            c_.off32.shrink_to_fit();
            c_.off64.shrink_to_fit();
            c_.ns.shrink_to_fit();
            c_.cells.shrink_to_fit();
            auto out = std::make_shared<Column>(std::move(c_));
            *this = ColumnBuilder();
            return out;
        }

      private:
        friend struct Value;
        Column c_;
        bool decided_ = false;
        std::vector<Value> pending_;
        size_t reserve_ = 0;

        // Kind of a cell as a column would store it; false = none (cells).
        struct Key
        {
            Column::Kind kind = Column::Kind::Cells;
            ElemType et = ElemType::F64;
            int16_t l = 0, t = 0, m = 0;
            uint8_t timeTag = 0;
            bool operator==(const Key &o) const
            {
                return kind == o.kind && et == o.et && l == o.l && t == o.t && m == o.m && timeTag == o.timeTag;
            }
        };
        static bool keyOf(const Value &v, Key &k)
        {
            k = Key();
            if (v.isText) {
                if (!v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef && !v.isComplex &&
                    !v.boolTag_ && v.intTag_ == 0 && v.floatTag_ == 0 && v.dimL == 0 && v.dimT == 0 && v.dimM == 0 &&
                    v.number == 0.0 && v.i64_ == 0 && !std::signbit(v.number) && (!v.box_ || v.box_->onlyText())) {
                    k.kind = Column::Kind::Text;
                    return true;
                }
                return false;
            }
            if (v.isTime()) {
                const double qn = std::numeric_limits<double>::quiet_NaN();
                if ((!v.box_ || v.box_->isBlank()) && !v.boolTag_ && v.floatTag_ == 0 && v.dimL == 0 &&
                    v.dimT == 0 && v.dimM == 0 && std::memcmp(&v.number, &qn, sizeof qn) == 0) {
                    k.kind = Column::Kind::Time;
                    k.timeTag = v.intTag_;
                    return true;
                }
                return false;
            }
            if (isPackable(v) && !v.isComplex) {
                k.kind = Column::Kind::Num;
                k.l = v.dimL;
                k.t = v.dimT;
                k.m = v.dimM;
                return true;
            }
            const ElemType et = scalarElemType(v);
            if (et != ElemType::F64) {
                k.kind = Column::Kind::Num;
                k.et = et;
                k.l = v.dimL;
                k.t = v.dimT;
                k.m = v.dimM;
                return true;
            }
            return false;
        }
        Key key() const
        {
            Key k;
            k.kind = c_.kind;
            k.et = c_.etype;
            k.l = c_.dimL;
            k.t = c_.dimT;
            k.m = c_.dimM;
            k.timeTag = c_.timeTag;
            return k;
        }
        // A plain NaN or an empty text: says nothing about the column's kind.
        static bool undecisive(const Value &v)
        {
            if (v.isText)
                return v.text().empty();
            return isPackable(v) && !v.isComplex && v.number != v.number && v.dimL == 0 && v.dimT == 0 &&
                   v.dimM == 0;
        }
        void undecided(Value &&v)
        {
            if (undecisive(v) && pending_.size() < 4096) {
                pending_.push_back(std::move(v));
                return;
            }
            decide(v, false);
            add(std::move(v));
        }
        // Sets the kind from `v` and adds the cells held back so far.
        void decide(const Value &v, bool onlyPending)
        {
            Key k;
            if (!keyOf(v, k))
                k = Key(); // cells
            setKind(k);
            std::vector<Value> held = std::move(pending_);
            pending_.clear();
            for (Value &p : held)
                add(std::move(p));
            (void)onlyPending;
        }
        void setKind(const Key &k)
        {
            decided_ = true;
            c_.kind = k.kind;
            c_.etype = k.et;
            c_.dimL = k.l;
            c_.dimT = k.t;
            c_.dimM = k.m;
            c_.timeTag = k.timeTag;
            const size_t want = reserve_;
            switch (c_.kind) {
            case Column::Kind::Num:
                if (c_.etype == ElemType::F64)
                    c_.f64.reserve(want);
                else
                    c_.raw.reserve(want * elemTypeBytes(c_.etype));
                break;
            case Column::Kind::Text:
                c_.off32.reserve(want + 1);
                c_.off32.push_back(0);
                break;
            case Column::Kind::Time: c_.ns.reserve(want); break;
            case Column::Kind::Cells: c_.cells.reserve(want); break;
            }
        }
        void appendText(std::string_view s)
        {
            c_.arena.append(s.data(), s.size());
            if (c_.off64.empty() && c_.arena.size() > 0xFFFFFFFFull) {
                c_.off64.assign(c_.off32.begin(), c_.off32.end());
                std::vector<uint32_t>().swap(c_.off32);
            }
            if (!c_.off64.empty())
                c_.off64.push_back(c_.arena.size());
            else
                c_.off32.push_back(static_cast<uint32_t>(c_.arena.size()));
        }
        // An empty slot for an exception row.
        void appendBlank()
        {
            switch (c_.kind) {
            case Column::Kind::Num:
                if (c_.etype == ElemType::F64)
                    c_.f64.push_back(0.0);
                else
                    c_.raw.resize(c_.raw.size() + elemTypeBytes(c_.etype), 0);
                break;
            case Column::Kind::Text: appendText(std::string_view()); break;
            case Column::Kind::Time: c_.ns.push_back(0); break;
            case Column::Kind::Cells: break;
            }
        }
        template <typename V> void add(V &&v)
        {
            if (c_.kind == Column::Kind::Cells) {
                c_.cells.push_back(std::forward<V>(v));
                c_.n++;
                return;
            }
            Key k;
            if (keyOf(v, k) && k == key()) {
                switch (c_.kind) {
                case Column::Kind::Num:
                    if (c_.etype == ElemType::F64) {
                        c_.f64.push_back(v.number);
                    } else {
                        c_.raw.resize(c_.raw.size() + elemTypeBytes(c_.etype));
                        writeTyped(c_.etype, c_.raw.data() + c_.raw.size() - elemTypeBytes(c_.etype), v);
                    }
                    break;
                case Column::Kind::Text: appendText(v.text()); break;
                case Column::Kind::Time: c_.ns.push_back(v.i64_); break;
                case Column::Kind::Cells: break;
                }
            } else {
                appendBlank();
                c_.excRows.push_back(c_.n);
                c_.excVals.push_back(std::forward<V>(v));
            }
            c_.n++;
        }
        // Rebuilds the column in its most common kind when that kind holds
        // at least half the cells; otherwise as plain cells.
        void regroup()
        {
            const Key oldKey = key();
            Column old = std::move(c_);
            c_ = Column();
            // Builder state: no exception bits yet, exception rows ascend.
            std::vector<std::pair<Key, size_t>> counts;
            size_t ei = 0;
            for (size_t r = 0; r < old.n; r++) {
                Key k = oldKey;
                bool has = true;
                if (old.kind == Column::Kind::Cells)
                    has = keyOf(old.cells[r], k);
                else if (ei < old.excRows.size() && old.excRows[ei] == r)
                    has = keyOf(old.excVals[ei++], k);
                if (!has)
                    continue;
                bool found = false;
                for (auto &kc : counts)
                    if (kc.first == k) {
                        kc.second++;
                        found = true;
                        break;
                    }
                if (!found)
                    counts.push_back({k, 1});
            }
            Key best;
            size_t bestN = 0;
            for (const auto &kc : counts)
                if (kc.second > bestN) {
                    best = kc.first;
                    bestN = kc.second;
                }
            if (bestN * 2 < old.n || old.n == 0)
                best = Key(); // no kind holds half: cells
            reserve_ = old.n;
            setKind(best);
            pending_.clear();
            ei = 0;
            for (size_t r = 0; r < old.n; r++) {
                if (old.kind == Column::Kind::Cells)
                    add(std::move(old.cells[r]));
                else if (ei < old.excRows.size() && old.excRows[ei] == r)
                    add(std::move(old.excVals[ei++]));
                else
                    add(old.get(r)); // no exception bits: the stored cell
            }
        }
        // Text with few distinct entries: each kept once + a code per row.
        void dictionary()
        {
            const size_t n = c_.n;
            if (n < 64 || !c_.codes.empty() || n > 0xFFFFFFFFull)
                return;
            const size_t limit = n / 4;
            if (n > 32768) { // a cheap look first: mostly distinct texts at the start say "no dictionary"
                std::unordered_map<std::string_view, uint32_t> sample;
                const size_t m = 8192;
                for (size_t r = 0; r < m; r++)
                    sample.emplace(c_.entry(r), 0u);
                if (sample.size() > m / 2)
                    return;
            }
            std::unordered_map<std::string_view, uint32_t> ids;
            ids.reserve(std::min<size_t>(limit + 1, 1 << 16));
            std::vector<uint32_t> codes(n);
            std::vector<std::string_view> order;
            for (size_t r = 0; r < n; r++) {
                const std::string_view s = c_.entry(r);
                auto it = ids.find(s);
                if (it == ids.end()) {
                    if (order.size() >= limit)
                        return; // too many distinct texts
                    it = ids.emplace(s, static_cast<uint32_t>(order.size())).first;
                    order.push_back(s);
                }
                codes[r] = it->second;
            }
            size_t dictBytes = 0;
            for (const auto &s : order)
                dictBytes += s.size();
            const size_t oldBytes = c_.arena.size() + (c_.off64.empty() ? 4 : 8) * (n + 1);
            if (dictBytes + 4 * (order.size() + 1) + 4 * n >= oldBytes)
                return;
            std::string arena;
            arena.reserve(dictBytes);
            std::vector<uint32_t> off;
            off.reserve(order.size() + 1);
            off.push_back(0);
            for (const auto &s : order) {
                arena.append(s.data(), s.size());
                off.push_back(static_cast<uint32_t>(arena.size()));
            }
            c_.arena = std::move(arena);
            c_.off32 = std::move(off);
            std::vector<uint64_t>().swap(c_.off64);
            c_.codes = std::move(codes);
        }
    };

    // A columnar matrix (cstore set).
    bool isColumnar() const { return isMatrix && box_ && rd().cstore; }
    // Columnar only: column c's storage (read only; its kind, buffers ...).
    const Column &column(size_t c) const { return *rd().cstore->cols[c]; }
    std::shared_ptr<const Column> columnShared(size_t c) const { return rd().cstore->cols[c]; }

    // The matrix of `cols` (each nrows long) as the cell form would make
    // it: packed when every column is one number type without exceptions,
    // columnar when a column holds text or times, otherwise exactly what
    // Value(rows) makes of the same cells.
    static Value fromColumns(std::vector<std::shared_ptr<Column>> cols, size_t nrows)
    {
        if (nrows == 0 || cols.empty())
            return Value(std::vector<std::vector<Value>>{});
        bool allNum = true, anyText = false;
        const Column &c0 = *cols[0];
        for (const auto &cp : cols) {
            const Column &c = *cp;
            if (c.kind != Column::Kind::Num || !c.excRows.empty() || c.etype != c0.etype || c.dimL != c0.dimL ||
                c.dimT != c0.dimT || c.dimM != c0.dimM)
                allNum = false;
            if ((c.kind == Column::Kind::Text || c.kind == Column::Kind::Time) && c.excRows.size() < c.n)
                anyText = true;
        }
        Value v;
        v.isMatrix = true;
        if (allNum) {
            auto t = std::make_shared<NumTensor>();
            t->shape = {nrows, cols.size()};
            t->etype = c0.etype;
            t->dimL = c0.dimL;
            t->dimT = c0.dimT;
            t->dimM = c0.dimM;
            if (c0.etype == ElemType::F64) {
                t->buf.reserve(nrows * cols.size());
                for (const auto &cp : cols)
                    t->buf.insert(t->buf.end(), cp->f64.begin(), cp->f64.end());
            } else {
                t->raw.reserve(nrows * cols.size() * elemTypeBytes(c0.etype));
                for (const auto &cp : cols)
                    t->raw.insert(t->raw.end(), cp->raw.begin(), cp->raw.end());
            }
            v.wr().tensor = std::move(t);
            return v;
        }
        auto store = std::make_shared<ColStore>();
        store->nrows = nrows;
        store->cols = std::move(cols);
        v.wr().cstore = std::move(store);
        if (anyText)
            return v;
        return Value(v.rowsCopy()); // numbers of several kinds, cells ...: the constructor decides
    }

    // A 1-D array stored as one column (2026-11-15): a non-packable array of
    // 16 elements or more whose elements are mostly of one kind.
    bool isColumnarArray() const { return isArray && box_ && rd().cstore; }

    // One column as the 1-D array of its cells, as Value(cells) would make it:
    // packed when it is numbers of one type without exceptions, else the
    // column itself, shared (no copy) when it holds text or times.
    static Value columnArray(const std::shared_ptr<const Column> &col)
    {
        const Column &c = *col;
        if (c.n == 0)
            return Value(std::vector<Value>{});
        if (c.kind == Column::Kind::Num && c.excRows.empty()) {
            Value v;
            v.isArray = true;
            auto t = std::make_shared<NumTensor>();
            t->shape = {c.n};
            t->etype = c.etype;
            t->dimL = c.dimL;
            t->dimT = c.dimT;
            t->dimM = c.dimM;
            if (c.etype == ElemType::F64)
                t->buf.assign(c.f64.begin(), c.f64.end()); // a copy, as before
            else
                t->raw = c.raw;
            v.wr().tensor = std::move(t);
            return v;
        }
        if ((c.kind == Column::Kind::Text || c.kind == Column::Kind::Time) && c.excRows.size() < c.n) {
            Value v;
            v.isArray = true;
            auto store = std::make_shared<ColStore>();
            store->nrows = c.n;
            store->cols.push_back(std::const_pointer_cast<Column>(col)); // shared: a write copies it first
            v.wr().cstore = std::move(store);
            return v;
        }
        std::vector<Value> cells;
        cells.reserve(c.n);
        for (size_t r = 0; r < c.n; r++)
            cells.push_back(c.get(r));
        return Value(std::move(cells));
    }

    // Columnar only: rows `rows` (all when null) of the columns `cols`, as
    // indexing would make them (fromColumns()). Columns taken whole are
    // shared, not copied.
    Value columnarTake(const std::vector<size_t> *rows, const std::vector<size_t> &cols) const
    {
        const ColStore &cs = *rd().cstore;
        const size_t n = rows ? rows->size() : cs.nrows;
        std::vector<std::shared_ptr<Column>> out;
        out.reserve(cols.size());
        for (size_t c : cols) {
            const std::shared_ptr<Column> &src = cs.cols[c];
            if (!rows) {
                out.push_back(src);
                continue;
            }
            out.push_back(std::make_shared<Column>(gather(*src, *rows)));
        }
        return fromColumns(std::move(out), n);
    }

    // Columnar only: bytes the storage takes (exceptions / cells counted as
    // their 32-byte Values; see Column::storageBytes()).
    size_t columnarStorageBytes() const
    {
        size_t b = 0;
        for (const auto &c : rd().cstore->cols)
            b += c->storageBytes();
        return b;
    }

    // Column storage (a columnar matrix or 1-D array): true when a column is
    // of `kind`, or `f` holds for a cell kept as a whole Value (a Cells
    // column's cells, the exception cells) - no Value made per typed cell.
    template <class F> bool colAnyCell(Column::Kind kind, F &&f) const
    {
        for (const auto &cp : rd().cstore->cols) {
            if (cp->kind == kind)
                return true;
            for (const Value &v : cp->cells)
                if (f(v))
                    return true;
            for (const Value &v : cp->excVals)
                if (f(v))
                    return true;
        }
        return false;
    }

  private:
    struct ColStore
    {
        size_t nrows = 0;
        std::vector<std::shared_ptr<Column>> cols;
    };

    // Column storage of a matrix / of a 1-D array (one column).
    bool colMat() const { return isMatrix && rd().cstore; }
    bool colArr() const { return isArray && rd().cstore; }
    size_t colRows() const { return rd().cstore->nrows; }
    size_t colCount() const { return rd().cstore->cols.size(); }
    Value colAt(size_t r, size_t c) const { return rd().cstore->cols[c]->get(r); }
    double colNum(size_t r, size_t c) const { return rd().cstore->cols[c]->num(r); }
    std::complex<double> colCplx(size_t r, size_t c) const
    {
        const Column &col = *rd().cstore->cols[c];
        if (col.kind == Column::Kind::Cells)
            return cplxOf(col.cells[r]);
        if (col.isExc(r))
            return cplxOf(col.excAt(r));
        return std::complex<double>(col.num(r), 0.0);
    }
    bool colHasComplex() const
    {
        for (const auto &cp : rd().cstore->cols) {
            for (const Value &v : cp->cells)
                if (v.hasComplex())
                    return true;
            for (const Value &v : cp->excVals)
                if (v.hasComplex())
                    return true;
        }
        return false;
    }

    // Column c, no longer shared with any copy of this Value.
    Column &ownColumn(size_t c)
    {
        std::shared_ptr<ColStore> &cs = wr().cstore;
        if (cs.use_count() > 1)
            cs = std::make_shared<ColStore>(*cs);
        std::shared_ptr<Column> &col = cs->cols[c];
        if (col.use_count() > 1)
            col = std::make_shared<Column>(*col);
        return *col;
    }

    static void setExcBit(Column &col, size_t r, bool on)
    {
        if (col.excBits.empty())
            col.excBits.assign((col.n + 63) / 64, 0);
        if (on)
            col.excBits[r >> 6] |= uint64_t(1) << (r & 63);
        else
            col.excBits[r >> 6] &= ~(uint64_t(1) << (r & 63));
    }

    // Writes cell (r, c) of a columnar matrix.
    void colSet(size_t r, size_t c, const Value &v)
    {
        Column &col = ownColumn(c);
        if (col.kind == Column::Kind::Cells) {
            col.cells[r] = v;
            return;
        }
        ColumnBuilder::Key k;
        ColumnBuilder::Key ck;
        ck.kind = col.kind;
        ck.et = col.etype;
        ck.l = col.dimL;
        ck.t = col.dimT;
        ck.m = col.dimM;
        ck.timeTag = col.timeTag;
        const bool fit = ColumnBuilder::keyOf(v, k) && k == ck;
        if (fit && col.kind != Column::Kind::Text) {
            if (col.kind == Column::Kind::Num) {
                if (col.etype == ElemType::F64)
                    col.f64[r] = v.number;
                else
                    writeTyped(col.etype, col.raw.data() + r * elemTypeBytes(col.etype), v);
            } else {
                col.ns[r] = v.i64_;
            }
            if (col.isExc(r)) {
                const size_t at = static_cast<size_t>(std::lower_bound(col.excRows.begin(), col.excRows.end(), r) -
                                                      col.excRows.begin());
                col.excRows.erase(col.excRows.begin() + static_cast<std::ptrdiff_t>(at));
                col.excVals.erase(col.excVals.begin() + static_cast<std::ptrdiff_t>(at));
                setExcBit(col, r, false);
            }
            return;
        }
        // The text arena is never rewritten: a new text is an exception
        // (unless it is the text already there).
        if (fit && !col.isExc(r) && col.textAt(r) == std::string_view(v.text()))
            return;
        const size_t at = static_cast<size_t>(std::lower_bound(col.excRows.begin(), col.excRows.end(), r) -
                                              col.excRows.begin());
        if (col.isExc(r)) {
            col.excVals[at] = v;
        } else {
            col.excRows.insert(col.excRows.begin() + static_cast<std::ptrdiff_t>(at), r);
            col.excVals.insert(col.excVals.begin() + static_cast<std::ptrdiff_t>(at), v);
            setExcBit(col, r, true);
        }
        if (col.excRows.size() > col.n / 2 + 16)
            toCells(col);
    }

    static void toCells(Column &col)
    {
        std::vector<Value> cells;
        cells.reserve(col.n);
        for (size_t r = 0; r < col.n; r++)
            cells.push_back(col.get(r));
        Column out;
        out.kind = Column::Kind::Cells;
        out.n = col.n;
        out.cells = std::move(cells);
        col = std::move(out);
    }

    // Columnar -> cells, contents unchanged.
    void uncolumn()
    {
        if (!rd().cstore)
            return;
        if (isArray) {
            std::vector<Value> a = elems();
            wr().cstore.reset();
            wr().array = std::move(a);
            return;
        }
        std::vector<std::vector<Value>> m = rowsCopy();
        wr().cstore.reset();
        wr().matrix = std::move(m);
    }

    // Rows `rows` of one column, in that order.
    static Column gather(const Column &src, const std::vector<size_t> &rows)
    {
        Column out;
        out.kind = src.kind;
        out.n = rows.size();
        out.etype = src.etype;
        out.dimL = src.dimL;
        out.dimT = src.dimT;
        out.dimM = src.dimM;
        out.timeTag = src.timeTag;
        switch (src.kind) {
        case Column::Kind::Num:
            if (src.etype == ElemType::F64) {
                out.f64.reserve(rows.size());
                for (size_t r : rows)
                    out.f64.push_back(src.f64[r]);
            } else {
                const size_t b = elemTypeBytes(src.etype);
                out.raw.resize(rows.size() * b);
                for (size_t i = 0; i < rows.size(); i++)
                    std::memcpy(out.raw.data() + i * b, src.raw.data() + rows[i] * b, b);
            }
            break;
        case Column::Kind::Text:
            if (!src.codes.empty()) {
                out.arena = src.arena;
                out.off32 = src.off32;
                out.off64 = src.off64;
                out.codes.reserve(rows.size());
                for (size_t r : rows)
                    out.codes.push_back(src.codes[r]);
            } else {
                size_t bytes = 0;
                for (size_t r : rows)
                    bytes += src.textAt(r).size();
                out.arena.reserve(bytes);
                const bool wide = bytes > 0xFFFFFFFFull;
                if (wide)
                    out.off64.push_back(0);
                else
                    out.off32.push_back(0);
                for (size_t r : rows) {
                    const std::string_view s = src.textAt(r);
                    out.arena.append(s.data(), s.size());
                    if (wide)
                        out.off64.push_back(out.arena.size());
                    else
                        out.off32.push_back(static_cast<uint32_t>(out.arena.size()));
                }
            }
            break;
        case Column::Kind::Time:
            out.ns.reserve(rows.size());
            for (size_t r : rows)
                out.ns.push_back(src.ns[r]);
            break;
        case Column::Kind::Cells:
            out.cells.reserve(rows.size());
            for (size_t r : rows)
                out.cells.push_back(src.cells[r]);
            break;
        }
        if (!src.excRows.empty()) {
            for (size_t i = 0; i < rows.size(); i++)
                if (src.isExc(rows[i])) {
                    out.excRows.push_back(i);
                    out.excVals.push_back(src.excAt(rows[i]));
                }
            if (!out.excRows.empty()) {
                out.excBits.assign((out.n + 63) / 64, 0);
                for (size_t r : out.excRows)
                    out.excBits[r >> 6] |= uint64_t(1) << (r & 63);
            }
        }
        return out;
    }

    // Worth storing by columns: rectangular, at least 16 rows.
    static bool columnarCandidate(const std::vector<std::vector<Value>> &m)
    {
        if (m.size() < 16 || m[0].empty())
            return false;
        for (const auto &r : m)
            if (r.size() != m[0].size())
                return false;
        return true;
    }

    // Columns of a rectangular cell matrix, taking its cells over (`m` is
    // left empty); null - `m` untouched - when no column has a kind.
    static std::shared_ptr<ColStore> columnarize(std::vector<std::vector<Value>> &m)
    {
        const size_t R = m.size(), C = m[0].size();
        if (!anyColumnKind(m))
            return nullptr;
        std::vector<ColumnBuilder> b(C);
        for (auto &cb : b)
            cb.reserve(R);
        for (size_t r = 0; r < R; r++) {
            for (size_t c = 0; c < C; c++)
                b[c].push(std::move(m[r][c]));
            std::vector<Value>().swap(m[r]);
        }
        std::vector<std::vector<Value>>().swap(m);
        auto store = std::make_shared<ColStore>();
        store->nrows = R;
        for (auto &cb : b)
            store->cols.push_back(cb.finish());
        return store;
    }
    static std::shared_ptr<ColStore> columnarizeCopy(const std::vector<std::vector<Value>> &m)
    {
        const size_t R = m.size(), C = m[0].size();
        if (!anyColumnKind(m))
            return nullptr;
        std::vector<ColumnBuilder> b(C);
        for (auto &cb : b)
            cb.reserve(R);
        for (size_t r = 0; r < R; r++)
            for (size_t c = 0; c < C; c++)
                b[c].push(m[r][c]);
        auto store = std::make_shared<ColStore>();
        store->nrows = R;
        for (auto &cb : b)
            store->cols.push_back(cb.finish());
        return store;
    }
    // A 1-D array as one column (taking its elements over; `a` is left
    // empty). Called only when anyArrayKind(a).
    static std::shared_ptr<ColStore> columnarizeArray(std::vector<Value> &a)
    {
        ColumnBuilder b;
        b.reserve(a.size());
        for (Value &v : a)
            b.push(std::move(v));
        std::vector<Value>().swap(a);
        auto store = std::make_shared<ColStore>();
        store->nrows = b.size();
        store->cols.push_back(b.finish());
        return store;
    }
    // At least half the elements are of one kind (so one column gains something).
    static bool anyArrayKind(const std::vector<Value> &a)
    {
        ColumnBuilder::Key first;
        size_t same = 0, seen = 0;
        for (const Value &v : a) {
            ColumnBuilder::Key k;
            if (!ColumnBuilder::keyOf(v, k))
                continue;
            if (seen++ == 0)
                first = k;
            if (k == first)
                same++;
        }
        return same * 2 >= a.size();
    }

    // Some column has at least half its cells of one kind (so storing by
    // columns gains something).
    static bool anyColumnKind(const std::vector<std::vector<Value>> &m)
    {
        const size_t R = m.size(), C = m[0].size();
        for (size_t c = 0; c < C; c++) {
            ColumnBuilder::Key first;
            size_t same = 0, seen = 0;
            for (size_t r = 0; r < R; r++) {
                ColumnBuilder::Key k;
                if (!ColumnBuilder::keyOf(m[r][c], k))
                    continue;
                if (seen++ == 0)
                    first = k;
                if (k == first)
                    same++;
            }
            if (same * 2 >= R)
                return true;
        }
        return false;
    }

    // Element bits of a typed element at `p`.
    static void decodeTyped(ElemType et, const uint8_t *p, int64_t &bits, double &x)
    {
        switch (et) {
        case ElemType::I8: { int8_t v; std::memcpy(&v, p, 1); bits = v; x = v; return; }
        case ElemType::I16: { int16_t v; std::memcpy(&v, p, 2); bits = v; x = v; return; }
        case ElemType::I32: { int32_t v; std::memcpy(&v, p, 4); bits = v; x = v; return; }
        case ElemType::I64: { int64_t v; std::memcpy(&v, p, 8); bits = v; x = static_cast<double>(v); return; }
        case ElemType::U8: { bits = *p; x = *p; return; }
        case ElemType::U16: { uint16_t v; std::memcpy(&v, p, 2); bits = v; x = v; return; }
        case ElemType::U32: { uint32_t v; std::memcpy(&v, p, 4); bits = v; x = v; return; }
        case ElemType::U64: { uint64_t v; std::memcpy(&v, p, 8); bits = static_cast<int64_t>(v); x = static_cast<double>(v); return; }
        case ElemType::F32: bits = 0; x = ncfloat::loadF32(p); return;
        case ElemType::F16: bits = 0; x = ncfloat::loadF16(p); return;
        case ElemType::F8: bits = 0; x = ncfloat::loadF8(p); return;
        case ElemType::Bool: { bits = *p != 0; x = *p != 0 ? 1.0 : 0.0; return; }
        case ElemType::F64: break;
        }
        bits = 0;
        x = 0;
    }
    // The Box to read from: this Value's own, or a shared blank one.
    // The containers etc. to read from: this Value's own, or a shared blank.
    const Ext &rd() const
    {
        static const Ext blank;
        return box_ && box_->ext ? *box_->ext : blank;
    }
    // The containers etc. to write to, created on first use.
    Ext &wr()
    {
        if (!box_)
            box_ = new Box;
        if (!box_->ext)
            box_->ext = std::make_unique<Ext>();
        return *box_->ext;
    }
    const std::string &rdText() const
    {
        static const std::string empty;
        return box_ ? box_->text : empty;
    }
    std::string &wrText()
    {
        if (!box_)
            box_ = new Box;
        return box_->text;
    }

    bool packed1() const { return rd().tensor && rd().tensor->shape.size() == 1; }
    bool packed2() const { return rd().tensor && rd().tensor->shape.size() == 2; }
    bool typed() const { return rd().tensor && rd().tensor->etype != ElemType::F64; }

    // Typed element k: its exact integer bits (integers) and its double.
    void typedBits(size_t k, int64_t &bits, double &x) const
    {
        const NumTensor &t = *rd().tensor;
        const uint8_t *p = t.raw.data() + k * elemTypeBytes(t.etype);
        switch (t.etype) {
        case ElemType::I8: { int8_t v; std::memcpy(&v, p, 1); bits = v; x = v; return; }
        case ElemType::I16: { int16_t v; std::memcpy(&v, p, 2); bits = v; x = v; return; }
        case ElemType::I32: { int32_t v; std::memcpy(&v, p, 4); bits = v; x = v; return; }
        case ElemType::I64: { int64_t v; std::memcpy(&v, p, 8); bits = v; x = static_cast<double>(v); return; }
        case ElemType::U8: { bits = *p; x = *p; return; }
        case ElemType::U16: { uint16_t v; std::memcpy(&v, p, 2); bits = v; x = v; return; }
        case ElemType::U32: { uint32_t v; std::memcpy(&v, p, 4); bits = v; x = v; return; }
        case ElemType::U64: { uint64_t v; std::memcpy(&v, p, 8); bits = static_cast<int64_t>(v); x = static_cast<double>(v); return; }
        case ElemType::F32: bits = 0; x = ncfloat::loadF32(p); return;
        case ElemType::F16: bits = 0; x = ncfloat::loadF16(p); return;
        case ElemType::F8: bits = 0; x = ncfloat::loadF8(p); return;
        case ElemType::Bool: { bits = *p != 0; x = *p != 0 ? 1.0 : 0.0; return; }
        case ElemType::F64: break;
        }
        bits = 0;
        x = 0;
    }
    double typedNum(size_t k) const
    {
        int64_t bits;
        double x;
        typedBits(k, bits, x);
        return x;
    }
    // Writes the typed scalar `v` (scalarElemType(v) == etype) at element k.
    void typedStore(size_t k, const Value &v)
    {
        ownTensor();
        NumTensor &t = *wr().tensor;
        writeTyped(t.etype, t.raw.data() + k * elemTypeBytes(t.etype), v);
    }
    static void writeTyped(ElemType et, uint8_t *p, const Value &v)
    {
        switch (et) {
        case ElemType::I8: case ElemType::U8: { uint8_t b = static_cast<uint8_t>(v.i64_); *p = b; return; }
        case ElemType::I16: case ElemType::U16: { uint16_t b = static_cast<uint16_t>(v.i64_); std::memcpy(p, &b, 2); return; }
        case ElemType::I32: case ElemType::U32: { uint32_t b = static_cast<uint32_t>(v.i64_); std::memcpy(p, &b, 4); return; }
        case ElemType::I64: case ElemType::U64: { int64_t b = v.i64_; std::memcpy(p, &b, 8); return; }
        case ElemType::F32: ncfloat::storeF32(p, v.number); return;
        case ElemType::F16: ncfloat::storeF16(p, v.number); return;
        case ElemType::F8: ncfloat::storeF8(p, v.number); return;
        case ElemType::Bool: *p = v.number != 0.0 ? 1 : 0; return;
        case ElemType::F64: return;
        }
    }
    // Element index (not buffer index) of a matrix cell.
    size_t offset(size_t r, size_t c) const { return c * rd().tensor->shape[0] + r; }
    // Doubles per element in the packed buffer.
    size_t stride() const { return rd().tensor->complex ? 2 : 1; }

    // Calls fn(bufferIndex) for every element, in storage order (column by
    // column for a matrix). Every caller writes element k of its result from
    // element k of its operands, so the order cannot change a result; storage
    // order reads memory front to back instead of jumping a whole column per
    // step, as the old row-by-row walk of a matrix did.
    template <typename Fn> void forEachOffset(Fn fn) const
    {
        rd().tensor->materialize();
        const size_t n = rd().tensor->buf.size();
        for (size_t k = 0; k < n; k++)
            fn(k);
    }

    // A plain number or a complex one: nothing about it beyond its value
    // and unit differs from a freshly built Value, so it can be stored as
    // bare doubles and rebuilt later with nothing lost.
    // Bools, integers and float8/16/32 numbers stay in the cell form: the
    // packed buffer is float64 only.
    static bool isPackable(const Value &v)
    {
        return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
               !v.isFunctionRef && !v.boolTag_ && v.intTag_ == 0 && v.floatTag_ == 0 &&
               (!v.box_ || v.box_->isBlank());
    }

    // No container, text, function reference or complex part: just a
    // number (possibly with a unit).
    bool isPlainScalar() const
    {
        return !isText && !isArray && !isMatrix && !isDict && !isObject && !isFunctionRef &&
               !isComplex;
    }

    // Can `v` be stored in this Value's packed buffer without losing anything?
    // A complex `v` fits a real buffer too: store() widens it first.
    bool fits(const Value &v) const
    {
        const bool kind = typed() ? scalarElemType(v) == rd().tensor->etype : isPackable(v);
        return kind && v.dimL == rd().tensor->dimL && v.dimT == rd().tensor->dimT &&
               v.dimM == rd().tensor->dimM;
    }

    // Writes `v` (already checked with fits()) at element index `idx`.
    void store(size_t idx, const Value &v)
    {
        if (typed()) {
            typedStore(idx, v);
            return;
        }
        ownTensor();
        if (v.isComplex && !rd().tensor->complex)
            widen();
        NumTensor &t = *wr().tensor;
        if (t.complex) {
            t.buf[2 * idx] = v.number;
            t.buf[2 * idx + 1] = v.isComplex ? v.imag : 0.0;
        } else {
            t.buf[idx] = v.number;
        }
    }

    // Real packed buffer -> complex packed buffer, same values. Call after
    // ownTensor().
    void widen()
    {
        NumTensor &t = *wr().tensor;
        nc::F64Buf wide(t.buf.size() * 2, 0.0);
        for (size_t k = 0; k < t.buf.size(); k++)
            wide[2 * k] = t.buf[k];
        t.buf = std::move(wide);
        t.complex = true;
    }

    // The element at element index `idx` of the packed buffer. An element
    // of a complex tensor whose imaginary part is exactly zero reads back as
    // a real number, the same narrowing arithmetic results get.
    Value elemOf(size_t idx) const
    {
        const NumTensor &t = *rd().tensor;
        if (t.etype != ElemType::F64) {
            int64_t bits;
            double x;
            typedBits(idx, bits, x);
            Value tv = typedScalar(t.etype, bits, x);
            tv.dimL = t.dimL;
            tv.dimT = t.dimT;
            tv.dimM = t.dimM;
            return tv;
        }
        Value v = (t.complex && t.buf[2 * idx + 1] != 0.0)
                      ? complexNumber(t.buf[2 * idx], t.buf[2 * idx + 1])
                      : Value(t.realAt(idx * (t.complex ? 2 : 1)));
        v.dimL = t.dimL;
        v.dimT = t.dimT;
        v.dimM = t.dimM;
        return v;
    }

    std::complex<double> cplxOf(size_t idx) const
    {
        const NumTensor &t = *rd().tensor;
        if (t.etype != ElemType::F64)
            return std::complex<double>(typedNum(idx), 0.0);
        return t.complex ? std::complex<double>(t.buf[2 * idx], t.buf[2 * idx + 1])
                         : std::complex<double>(t.realAt(idx), 0.0);
    }
    static std::complex<double> cplxOf(const Value &v)
    {
        return std::complex<double>(v.number, v.isComplex ? v.imag : 0.0);
    }

    static std::shared_ptr<NumTensor> complexTensor(const std::complex<double> *data, size_t n)
    {
        auto t = std::make_shared<NumTensor>();
        t->complex = true;
        t->buf.resize(2 * n);
        for (size_t k = 0; k < n; k++) {
            t->buf[2 * k] = data[k].real();
            t->buf[2 * k + 1] = data[k].imag();
        }
        return t;
    }

    // Packed form of `a`, or null when it has to stay as cells (empty, or
    // an element that isn't a plain number in the same unit as the rest).
    // Typed form of n cells (get(k) = the cell at storage index k), or null
    // unless every cell is a typed scalar of one type and one unit.
    template <typename Get> static std::shared_ptr<NumTensor> packTyped(size_t n, Get get)
    {
        if (n == 0)
            return nullptr;
        const Value &first = get(0);
        const ElemType et = scalarElemType(first);
        if (et == ElemType::F64)
            return nullptr;
        for (size_t k = 1; k < n; k++) {
            const Value &v = get(k);
            if (scalarElemType(v) != et || v.dimL != first.dimL || v.dimT != first.dimT || v.dimM != first.dimM)
                return nullptr;
        }
        auto t = std::make_shared<NumTensor>();
        t->etype = et;
        t->dimL = first.dimL;
        t->dimT = first.dimT;
        t->dimM = first.dimM;
        const size_t b = elemTypeBytes(et);
        t->raw.resize(n * b);
        for (size_t k = 0; k < n; k++)
            writeTyped(et, t->raw.data() + k * b, get(k));
        return t;
    }

    static std::shared_ptr<NumTensor> pack(const std::vector<Value> &a)
    {
        if (a.empty())
            return nullptr;
        if (scalarElemType(a[0]) != ElemType::F64) {
            auto t = packTyped(a.size(), [&](size_t k) -> const Value & { return a[k]; });
            if (t)
                t->shape = {a.size()};
            return t;
        }
        bool anyComplex = false;
        for (const Value &v : a) {
            if (!isPackable(v) || v.dimL != a[0].dimL || v.dimT != a[0].dimT ||
                v.dimM != a[0].dimM)
                return nullptr;
            anyComplex = anyComplex || v.isComplex;
        }
        auto t = std::make_shared<NumTensor>();
        t->shape = {a.size()};
        t->dimL = a[0].dimL;
        t->dimT = a[0].dimT;
        t->dimM = a[0].dimM;
        t->complex = anyComplex;
        t->buf.reserve(a.size() * (anyComplex ? 2 : 1));
        for (const Value &v : a) {
            t->buf.push_back(v.number);
            if (anyComplex)
                t->buf.push_back(v.isComplex ? v.imag : 0.0);
        }
        return t;
    }

    // As above for a matrix, which additionally has to be rectangular.
    static std::shared_ptr<NumTensor> pack(const std::vector<std::vector<Value>> &m)
    {
        if (m.empty() || m[0].empty())
            return nullptr;
        const Value &first = m[0][0];
        if (scalarElemType(first) != ElemType::F64) {
            for (const auto &matRow : m)
                if (matRow.size() != m[0].size())
                    return nullptr;
            const size_t rows = m.size();
            auto t = packTyped(rows * m[0].size(), [&](size_t k) -> const Value & { return m[k % rows][k / rows]; });
            if (t)
                t->shape = {rows, m[0].size()};
            return t;
        }
        bool anyComplex = false;
        for (const auto &matRow : m) {
            if (matRow.size() != m[0].size())
                return nullptr;
            for (const Value &v : matRow) {
                if (!isPackable(v) || v.dimL != first.dimL || v.dimT != first.dimT ||
                    v.dimM != first.dimM)
                    return nullptr;
                anyComplex = anyComplex || v.isComplex;
            }
        }
        auto t = std::make_shared<NumTensor>();
        t->shape = {m.size(), m[0].size()};
        t->dimL = first.dimL;
        t->dimT = first.dimT;
        t->dimM = first.dimM;
        t->complex = anyComplex;
        const size_t step = anyComplex ? 2 : 1;
        t->buf.resize(m.size() * m[0].size() * step);
        for (size_t r = 0; r < m.size(); r++)
            for (size_t c = 0; c < m[0].size(); c++) {
                const Value &v = m[r][c];
                t->buf[(c * m.size() + r) * step] = v.number;
                if (anyComplex)
                    t->buf[(c * m.size() + r) * step + 1] = v.isComplex ? v.imag : 0.0;
            }
        return t;
    }

    // Before writing to the packed buffer: stop sharing it with any copies,
    // and give it a new stamp - its bytes are about to change.
    void ownTensor()
    {
        if (rd().tensor)
            rd().tensor->materialize(); // a lazy range is built before any write
        if (rd().tensor.use_count() > 1)
            wr().tensor = std::make_shared<NumTensor>(*rd().tensor);
        if (rd().tensor)
            wr().tensor->stamp = NumTensor::nextStamp();
    }

    // Packed -> cells, contents unchanged.
    void unpack()
    {
        if (!rd().tensor)
            return;
        if (packed1()) {
            wr().array = elems();
        } else if (packed2()) {
            wr().matrix = rowsCopy();
        } else {
            // N-D: keep every element, in the same storage order.
            const size_t n = ndCount();
            std::vector<Value> cells;
            cells.reserve(n);
            for (size_t k = 0; k < n; k++)
                cells.push_back(elemOf(k));
            wr().ndShape = rd().tensor->shape;
            wr().ndCells = std::move(cells);
        }
        wr().tensor.reset();
    }

    // Cells -> packed where the contents allow it.
    void repack()
    {
        if (!rd().ndCells.empty()) {
            if (auto t = pack(rd().ndCells)) {
                t->shape = rd().ndShape;
                wr().tensor = std::move(t);
                wr().ndCells.clear();
                wr().ndShape.clear();
            }
            return;
        }
        if (!rd().array.empty() && (wr().tensor = pack(rd().array)))
            wr().array.clear();
        else if (!rd().matrix.empty() && (wr().tensor = pack(rd().matrix)))
            wr().matrix.clear();
    }
};

static_assert(sizeof(Value) == 32, "Value is meant to stay a small handle - see Value::Box");

// Function references (`@name`) hold the name of the function they call.
// An anonymous function, @(x) x * 2, is registered under its own source text
// followed by kAnonymousSeparator and a number that keeps two identical
// texts apart (Parser, ExprKind::AnonymousFunction). Shown to the user, a
// reference reads as written: "@square", "@(x) x * 2".
constexpr char kAnonymousSeparator = '\x1f';

inline std::string functionRefText(const std::string &name)
{
    const size_t cut = name.find(kAnonymousSeparator);
    if (cut != std::string::npos)
        return name.substr(0, cut);
    return "@" + name;
}
