#pragma once
#include <complex>
#include <cstdint>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

// Flat storage for an array or matrix whose elements are all plain numbers:
// one contiguous block of doubles instead of one whole Value per element.
// Column-major (first index varies fastest), the layout Eigen and LAPACK
// use, so a matrix can be handed to them without rearranging it.
struct NumTensor
{
    std::vector<double> buf;
    std::vector<size_t> shape; // {length} for an array, {rows, cols} for a matrix

    // Complex tensor: each element takes two consecutive doubles in `buf`,
    // real part then imaginary part. That is the layout std::complex<double>
    // and Eigen's complex matrices use, so the buffer can be handed to them
    // as it is.
    bool complex = false;

    // Unit dimensions shared by every element (see Value::dimL/dimT/dimM).
    int16_t dimL = 0, dimT = 0, dimM = 0;
};

// One NC value. A plain number is just the 32 bytes below; everything else
// a value can be (text, an array or matrix, a dict, a class instance, a
// function reference) keeps its data in a separately allocated Box, so the
// common case of a number never pays for it.
struct Value
{
    double number = 0;

    // Imaginary part, meaningful only while isComplex is set. A complex
    // value keeps its real part in `number`, so code that only understands
    // real numbers still reads the real part.
    double imag = 0;

  private:
    struct Box
    {
        std::string text;

        // An array/matrix lives in exactly one of two forms:
        //  - packed: `tensor` set, every element a plain number sharing one
        //    unit. This is the compact form, and copies of the Value share
        //    the buffer until one of them writes to it (ownTensor()).
        //  - cells: `array` / `matrix`, one whole Value per element. Used
        //    whenever the packed form can't represent the contents exactly
        //    (text, nested arrays, mixed units, rows of different lengths).
        // The constructors pick the packed form when it fits, and a write
        // that no longer fits switches that Value back to cells (unpack()).
        std::vector<Value> array;
        std::vector<std::vector<Value>> matrix;
        std::shared_ptr<NumTensor> tensor;

        // Dict entries, or a class instance's fields (an object's fields ARE
        // conceptually a name->Value map).
        std::unordered_map<std::string, Value> dict;

        // Class instance: which class this instance belongs to, so a method
        // call (obj.Method(...)) knows which class's method table to resolve
        // against. Object Values are only ever built internally by the
        // class-call machinery (parser_class.cpp), never as a
        // general-purpose public Value type the way dict/array/matrix are.
        std::string className;

        // First-class function reference (`@name` - see ast.h's FunctionRef
        // comment). Deliberately just a NAME, not a pointer/closure of any
        // kind: functions are already looked up by name in Parser::
        // functionTable_ at call time everywhere else in this codebase (the
        // same principle classes/methods use - see ClassDef's own comments),
        // so a reference only ever needs to remember which name to
        // re-resolve later, via feval(). This means a reference stays valid
        // even if the function it names is later redefined (feval()
        // re-resolves by name each call, not a captured snapshot) -
        // consistent with every other late-bound name lookup in this
        // language, and much simpler than a real closure (no captured
        // environment to manage, no lifetime issues if the referenced
        // function's defining scope has since exited).
        std::string funcRefName;

        // Traceability: an auto-maintained history of operations performed
        // on this instance — one entry appended on construction
        // ("init(...)") and one per instance method call
        // ("MethodName(args) -> result"), read via the reserved `.lineage()`
        // call (see parser_factor.cpp). Populated by callClassConstructor()/
        // callInstanceMethod() (parser_class.cpp), never by user code
        // directly.
        std::vector<std::string> lineage;

        // Reversibility (opt-in — `reversible class Name(...)`): one
        // field-state snapshot per lineage entry (same index
        // correspondence), only ever populated for instances of a class
        // marked reversible — a normal class's instances leave this
        // permanently empty, paying no snapshot cost. Read/restored via the
        // reserved `.rewind()` call (parser_factor.cpp), populated by
        // callClassConstructor()/callInstanceMethod() (parser_class.cpp)
        // right alongside `lineage`.
        std::vector<std::unordered_map<std::string, Value>> snapshots;

        // Temporal Determinism (opt-in via `@rate(...)` on the class — see
        // ClassDef::hasRate/rateHz): the simulated time this instance last
        // actually ran its step() method via `.tick(t)`. -1 means "never
        // ticked yet", so the first .tick() call always runs regardless of
        // the configured period.
        double lastTickTime = -1.0;

        // Nothing in here differs from a freshly made Box.
        bool isBlank() const
        {
            return text.empty() && array.empty() && matrix.empty() && !tensor && dict.empty() &&
                   className.empty() && funcRefName.empty() && lineage.empty() &&
                   snapshots.empty() && lastTickTime == -1.0;
        }
    };

    // Null until this Value needs something a plain number doesn't have.
    // Owned: copying a Value copies its Box.
    Box *box_ = nullptr;

  public:
    // One bit each, so that all of them plus the unit exponents below fit
    // in the 8 bytes left after number / imag / box_. Bit fields can't
    // carry a default here before C++20; the constructors clear them.
    bool isText : 1;
    bool isArray : 1;
    bool isMatrix : 1;
    bool isDict : 1;
    bool isObject : 1;      // class instance - see Box::className
    bool isFunctionRef : 1; // `@name` - see Box::funcRefName
    bool isComplex : 1;     // a complex number: number + imag*i

    // Dimensional Integrity: exponents over 3 base physical dimensions —
    // Length, Time, Mass (e.g. velocity is L^1 T^-1, force is L^1 M^1 T^-2).
    // All zero (the default) means unitless — every pre-existing numeric
    // Value in this codebase stays unitless and unaffected. Attached via
    // multiplying/dividing by a unit constant (m, s, kg, N, Pa — see
    // parser_factor.cpp's tryResolveUnitConstant()), not a dedicated
    // `<unit>` literal — that syntax from the design doc collides with the
    // existing `<`/`>` comparison tokens used throughout this whole
    // codebase, so it was deliberately not implemented as written; see the
    // memory notes for the full rationale.
    int16_t dimL = 0, dimT = 0, dimM = 0;

    /* copying / moving / destroying */

    Value(const Value &o)
        : number(o.number), imag(o.imag), box_(o.box_ ? new Box(*o.box_) : nullptr),
          isText(o.isText), isArray(o.isArray), isMatrix(o.isMatrix), isDict(o.isDict),
          isObject(o.isObject), isFunctionRef(o.isFunctionRef), isComplex(o.isComplex),
          dimL(o.dimL), dimT(o.dimT), dimM(o.dimM)
    {
    }

    Value(Value &&o) noexcept
        : number(o.number), imag(o.imag), box_(o.box_), isText(o.isText), isArray(o.isArray),
          isMatrix(o.isMatrix), isDict(o.isDict), isObject(o.isObject),
          isFunctionRef(o.isFunctionRef), isComplex(o.isComplex), dimL(o.dimL), dimT(o.dimT),
          dimM(o.dimM)
    {
        o.box_ = nullptr;
    }

    // Both assignments finish reading `o` before releasing this Value's old
    // Box: `o` may be an element living inside that Box (x = x.at(0)).
    Value &operator=(const Value &o)
    {
        if (this != &o) {
            Value copy(o);
            *this = std::move(copy);
        }
        return *this;
    }

    Value &operator=(Value &&o) noexcept
    {
        if (this != &o) {
            Box *old = box_;
            number = o.number;
            imag = o.imag;
            isText = o.isText;
            isArray = o.isArray;
            isMatrix = o.isMatrix;
            isDict = o.isDict;
            isObject = o.isObject;
            isFunctionRef = o.isFunctionRef;
            isComplex = o.isComplex;
            dimL = o.dimL;
            dimT = o.dimT;
            dimM = o.dimM;
            box_ = o.box_;
            o.box_ = nullptr;
            delete old;
        }
        return *this;
    }

    ~Value() { delete box_; }

    /* default */

    Value()
        : isText(false), isArray(false), isMatrix(false), isDict(false), isObject(false),
          isFunctionRef(false), isComplex(false)
    {
    }

    /* number */

    Value(double n) : Value()
    {
        number = n;
        isText = false;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* complex number */

    static Value complexNumber(double re, double im)
    {
        Value v(re);
        v.imag = im;
        v.isComplex = true;
        return v;
    }

    /* string */

    Value(const std::string &s) : Value()
    {
        if (!s.empty())
            wr().text = s;
        isText = true;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* array */

    Value(const std::vector<Value> &a) : Value()
    {
        if (auto t = pack(a))
            wr().tensor = std::move(t);
        else if (!a.empty())
            wr().array = a;
        isArray = true;
        isText = false;
        isMatrix = false;
        isDict = false;
    }

    /* matrix */

    Value(const std::vector<std::vector<Value>> &m) : Value()
    {
        if (auto t = pack(m))
            wr().tensor = std::move(t);
        else if (!m.empty())
            wr().matrix = m;
        isMatrix = true;
        isArray = false;
        isText = false;
        isDict = false;
    }

    /* dict */

    Value(const std::unordered_map<std::string, Value> &d) : Value()
    {
        if (!d.empty())
            wr().dict = d;
        isDict = true;
        isText = false;
        isArray = false;
        isMatrix = false;
    }

    /* array / matrix (moving) - same as the copying constructors above,
       minus the full copy of a container the caller is done with. */

    Value(std::vector<Value> &&a) : Value()
    {
        if (auto t = pack(a))
            wr().tensor = std::move(t);
        else if (!a.empty())
            wr().array = std::move(a);
        isArray = true;
    }

    Value(std::vector<std::vector<Value>> &&m) : Value()
    {
        if (auto t = pack(m))
            wr().tensor = std::move(t);
        else if (!m.empty())
            wr().matrix = std::move(m);
        isMatrix = true;
    }

    /* ---- text / dict / object-state access ----

       Read with name(), change through nameMut(). Reading never allocates:
       a Value with no Box reads as empty. nameMut() gives the Value a Box
       if it doesn't have one yet. */

    const std::string &text() const { return rd().text; }
    std::string &textMut() { return wr().text; }

    const std::unordered_map<std::string, Value> &dict() const { return rd().dict; }
    std::unordered_map<std::string, Value> &dictMut() { return wr().dict; }

    const std::string &className() const { return rd().className; }
    std::string &classNameMut() { return wr().className; }

    const std::string &funcRefName() const { return rd().funcRefName; }
    std::string &funcRefNameMut() { return wr().funcRefName; }

    const std::vector<std::string> &lineage() const { return rd().lineage; }
    std::vector<std::string> &lineageMut() { return wr().lineage; }

    const std::vector<std::unordered_map<std::string, Value>> &snapshots() const
    {
        return rd().snapshots;
    }
    std::vector<std::unordered_map<std::string, Value>> &snapshotsMut()
    {
        return wr().snapshots;
    }

    double lastTickTime() const { return rd().lastTickTime; }
    double &lastTickTimeMut() { return wr().lastTickTime; }

    // True for a complex number, or an array/matrix holding at least one.
    bool hasComplex() const
    {
        if (isComplex)
            return true;
        if (!box_)
            return false;
        if (box_->tensor)
            return box_->tensor->complex;
        for (const Value &elem : box_->array)
            if (elem.hasComplex())
                return true;
        for (const auto &matRow : box_->matrix)
            for (const Value &cell : matRow)
                if (cell.hasComplex())
                    return true;
        return false;
    }

    /* ---- array / matrix element access ----

       Every use of the `array` / `matrix` storage outside this struct goes
       through these, so the storage behind them can later become one flat
       numeric buffer without touching any caller. Elements are therefore
       passed BY VALUE, never by reference: a flat buffer of doubles has no
       `Value` object to hand out a reference to. Numeric loops should use
       numAt()/setNumAt(), which skip building a whole Value per element. */

    /* sizes */

    size_t length() const { return packed1() ? rd().tensor->shape[0] : rd().array.size(); }
    size_t rows() const { return packed2() ? rd().tensor->shape[0] : rd().matrix.size(); }
    // Column count of the FIRST row (0 for an empty matrix). Rows are not
    // guaranteed equal-length in the cell form - use rowLength(r) where
    // that matters.
    size_t cols() const
    {
        if (packed2())
            return rd().tensor->shape[1];
        return rd().matrix.empty() ? 0 : rd().matrix[0].size();
    }
    size_t rowLength(size_t r) const { return packed2() ? rd().tensor->shape[1] : rd().matrix[r].size(); }

    /* element read */

    Value at(size_t i) const { return packed1() ? elemOf(i) : rd().array[i]; }
    Value at(size_t r, size_t c) const
    {
        return packed2() ? elemOf(offset(r, c)) : rd().matrix[r][c];
    }
    // The element's number; for a complex element, its real part.
    double numAt(size_t i) const
    {
        return packed1() ? rd().tensor->buf[i * stride()] : rd().array[i].number;
    }
    double numAt(size_t r, size_t c) const
    {
        return packed2() ? rd().tensor->buf[offset(r, c) * stride()] : rd().matrix[r][c].number;
    }
    // The element as a complex number (imaginary part 0 for a real one).
    std::complex<double> cnumAt(size_t i) const
    {
        return packed1() ? cplxOf(i) : cplxOf(rd().array[i]);
    }
    std::complex<double> cnumAt(size_t r, size_t c) const
    {
        return packed2() ? cplxOf(offset(r, c)) : cplxOf(rd().matrix[r][c]);
    }

    /* element write */

    void setAt(size_t i, const Value &v)
    {
        if (packed1()) {
            if (fits(v)) {
                store(i, v);
                return;
            }
            unpack();
        }
        wr().array[i] = v;
    }
    void setAt(size_t r, size_t c, const Value &v)
    {
        if (packed2()) {
            if (fits(v)) {
                store(offset(r, c), v);
                return;
            }
            unpack();
        }
        wr().matrix[r][c] = v;
    }
    // Overwrites only the element's number, leaving everything else about
    // it (unit dimensions, ...) as it was.
    void setNumAt(size_t i, double n)
    {
        if (packed1()) {
            ownTensor();
            rd().tensor->buf[i * stride()] = n;
        } else {
            wr().array[i].number = n;
        }
    }
    void setNumAt(size_t r, size_t c, double n)
    {
        if (packed2()) {
            ownTensor();
            rd().tensor->buf[offset(r, c) * stride()] = n;
        } else {
            wr().matrix[r][c].number = n;
        }
    }

    /* whole rows / whole containers (copies) */

    std::vector<Value> row(size_t r) const
    {
        if (!packed2())
            return rd().matrix[r];
        std::vector<Value> out;
        out.reserve(rd().tensor->shape[1]);
        for (size_t c = 0; c < rd().tensor->shape[1]; c++)
            out.push_back(elemOf(offset(r, c)));
        return out;
    }
    void setRow(size_t r, const std::vector<Value> &v)
    {
        if (packed2()) {
            bool allFit = v.size() == rd().tensor->shape[1];
            for (size_t c = 0; allFit && c < v.size(); c++)
                allFit = fits(v[c]);
            if (allFit) {
                for (size_t c = 0; c < v.size(); c++)
                    store(offset(r, c), v[c]);
                return;
            }
            unpack();
        }
        wr().matrix[r] = v;
    }
    std::vector<Value> elems() const
    {
        if (!packed1())
            return rd().array;
        std::vector<Value> out;
        out.reserve(rd().tensor->shape[0]);
        for (size_t i = 0; i < rd().tensor->shape[0]; i++)
            out.push_back(elemOf(i));
        return out;
    }
    std::vector<std::vector<Value>> rowsCopy() const
    {
        if (!packed2())
            return rd().matrix;
        std::vector<std::vector<Value>> out;
        out.reserve(rd().tensor->shape[0]);
        for (size_t r = 0; r < rd().tensor->shape[0]; r++)
            out.push_back(row(r));
        return out;
    }

    void append(const Value &v)
    {
        if (packed1()) {
            if (fits(v)) {
                ownTensor();
                rd().tensor->buf.resize(rd().tensor->buf.size() + stride());
                rd().tensor->shape[0]++;
                store(rd().tensor->shape[0] - 1, v);
                return;
            }
            unpack();
        }
        wr().array.push_back(v);
    }

    // Replaces each array element / matrix cell with fn(element). fn sees
    // and returns a whole Value, so anything it doesn't deliberately change
    // (unit dimensions, fraction text, a nested array) survives. Matrix
    // cells are visited row by row. General but slow on packed data (it
    // builds a Value per element) - numeric code should prefer mapPacked().
    template <typename Fn> void transformElems(Fn fn)
    {
        if (!box_)
            return; // nothing stored, so no elements
        bool wasPacked = static_cast<bool>(rd().tensor);
        unpack();
        for (auto &elem : wr().array)
            elem = fn(static_cast<const Value &>(elem));
        for (auto &matRow : wr().matrix)
            for (auto &cell : matRow)
                cell = fn(static_cast<const Value &>(cell));
        if (wasPacked)
            repack();
    }

    /* ---- packed (flat numeric buffer) fast paths ---- */

    // True when the elements are held as one flat buffer of plain REAL
    // numbers. A packed complex tensor answers false here on purpose: every
    // caller of this takes the buffer to be one double per element.
    bool isPacked() const { return rd().tensor && !rd().tensor->complex; }

    // True when the elements are held as one flat buffer of complex numbers.
    bool isPackedComplex() const { return rd().tensor && rd().tensor->complex; }

    // Packed complex only: the buffer, `re, im` per element, column-major
    // for a matrix.
    const std::complex<double> *packedComplexData() const
    {
        return reinterpret_cast<const std::complex<double> *>(rd().tensor->buf.data());
    }

    // A unitless packed complex array / matrix copied from `n` (or
    // rows*cols, column-major) complex numbers. Sizes must be non-zero.
    static Value packedComplexArray(const std::complex<double> *data, size_t n)
    {
        Value v;
        v.isArray = true;
        v.wr().tensor = complexTensor(data, n);
        v.rd().tensor->shape = {n};
        return v;
    }
    static Value packedComplexMatrix(const std::complex<double> *colMajor, size_t nrows,
                                     size_t ncols)
    {
        Value v;
        v.isMatrix = true;
        v.wr().tensor = complexTensor(colMajor, nrows * ncols);
        v.rd().tensor->shape = {nrows, ncols};
        return v;
    }

    // If this is a packed complex array/matrix whose imaginary parts are all
    // exactly zero, turn it into the ordinary real packed form.
    void narrowIfReal()
    {
        if (!isPackedComplex())
            return;
        const std::vector<double> &src = rd().tensor->buf;
        for (size_t k = 1; k < src.size(); k += 2)
            if (src[k] != 0.0)
                return;
        auto t = std::make_shared<NumTensor>();
        t->shape = rd().tensor->shape;
        t->dimL = rd().tensor->dimL;
        t->dimT = rd().tensor->dimT;
        t->dimM = rd().tensor->dimM;
        t->buf.resize(src.size() / 2);
        for (size_t k = 0; k < t->buf.size(); k++)
            t->buf[k] = src[2 * k] + 0.0; // + 0.0: no negative zeros
        wr().tensor = std::move(t);
    }

    // Packed only: the buffer itself, column-major for a matrix.
    const double *packedData() const { return rd().tensor->buf.data(); }

    // A unitless packed array / matrix copied from `n` (or rows*cols,
    // column-major) doubles.
    static Value packedArray(const double *data, size_t n)
    {
        Value v;
        v.isArray = true;
        v.wr().tensor = std::make_shared<NumTensor>();
        v.rd().tensor->buf.assign(data, data + n);
        v.rd().tensor->shape = {n};
        return v;
    }
    static Value packedMatrix(const double *colMajor, size_t nrows, size_t ncols)
    {
        Value v;
        v.isMatrix = true;
        v.wr().tensor = std::make_shared<NumTensor>();
        v.rd().tensor->buf.assign(colMajor, colMajor + nrows * ncols);
        v.rd().tensor->shape = {nrows, ncols};
        return v;
    }

    // Packed only: a copy of this Value with every element replaced by the
    // unitless number fn(element) - what assigning `Value(fn(x))` to each
    // element does, without building those Values. Matrix cells are visited
    // row by row, the same order the cell form is walked in.
    template <typename Fn> Value mapPacked(Fn fn) const
    {
        Value result = *this;
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        out->buf.resize(rd().tensor->buf.size());
        forEachOffset([&](size_t k) { out->buf[k] = fn(rd().tensor->buf[k]); });
        result.wr().tensor = std::move(out);
        return result;
    }

    // Packed only, `other` packed with the same shape: like mapPacked(),
    // with fn(thisElement, otherElement).
    template <typename Fn> Value zipPacked(const Value &other, Fn fn) const
    {
        Value result = *this;
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        out->buf.resize(rd().tensor->buf.size());
        forEachOffset(
            [&](size_t k) { out->buf[k] = fn(rd().tensor->buf[k], other.rd().tensor->buf[k]); });
        result.wr().tensor = std::move(out);
        return result;
    }

    bool sameShapeAs(const Value &other) const
    {
        return isPacked() && other.isPacked() && rd().tensor->shape == other.rd().tensor->shape;
    }

  private:
    // The Box to read from: this Value's own, or a shared blank one.
    const Box &rd() const
    {
        static const Box blank;
        return box_ ? *box_ : blank;
    }
    // The Box to write to, created on first use.
    Box &wr()
    {
        if (!box_)
            box_ = new Box;
        return *box_;
    }

    bool packed1() const { return rd().tensor && rd().tensor->shape.size() == 1; }
    bool packed2() const { return rd().tensor && rd().tensor->shape.size() == 2; }
    // Element index (not buffer index) of a matrix cell.
    size_t offset(size_t r, size_t c) const { return c * rd().tensor->shape[0] + r; }
    // Doubles per element in the packed buffer.
    size_t stride() const { return rd().tensor->complex ? 2 : 1; }

    // Calls fn(bufferIndex) for every element: in order for an array, row by
    // row for a matrix.
    template <typename Fn> void forEachOffset(Fn fn) const
    {
        if (packed1()) {
            for (size_t k = 0; k < rd().tensor->buf.size(); k++)
                fn(k);
            return;
        }
        for (size_t r = 0; r < rd().tensor->shape[0]; r++)
            for (size_t c = 0; c < rd().tensor->shape[1]; c++)
                fn(offset(r, c));
    }

    // A plain number or a complex one: nothing about it beyond its value
    // and unit differs from a freshly built Value, so it can be stored as
    // bare doubles and rebuilt later with nothing lost.
    static bool isPackable(const Value &v)
    {
        return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
               !v.isFunctionRef && (!v.box_ || v.box_->isBlank());
    }

    // Can `v` be stored in this Value's packed buffer without losing anything?
    // A complex `v` fits a real buffer too: store() widens it first.
    bool fits(const Value &v) const
    {
        return isPackable(v) && v.dimL == rd().tensor->dimL && v.dimT == rd().tensor->dimT &&
               v.dimM == rd().tensor->dimM;
    }

    // Writes `v` (already checked with fits()) at element index `idx`.
    void store(size_t idx, const Value &v)
    {
        ownTensor();
        if (v.isComplex && !rd().tensor->complex)
            widen();
        NumTensor &t = *wr().tensor;
        if (t.complex) {
            t.buf[2 * idx] = v.number;
            t.buf[2 * idx + 1] = v.isComplex ? v.imag : 0.0;
        } else {
            t.buf[idx] = v.number;
        }
    }

    // Real packed buffer -> complex packed buffer, same values. Call after
    // ownTensor().
    void widen()
    {
        NumTensor &t = *wr().tensor;
        std::vector<double> wide(t.buf.size() * 2, 0.0);
        for (size_t k = 0; k < t.buf.size(); k++)
            wide[2 * k] = t.buf[k];
        t.buf = std::move(wide);
        t.complex = true;
    }

    // The element at element index `idx` of the packed buffer. An element
    // of a complex tensor whose imaginary part is exactly zero reads back as
    // a real number, the same narrowing arithmetic results get.
    Value elemOf(size_t idx) const
    {
        const NumTensor &t = *rd().tensor;
        Value v = (t.complex && t.buf[2 * idx + 1] != 0.0)
                      ? complexNumber(t.buf[2 * idx], t.buf[2 * idx + 1])
                      : Value(t.buf[idx * (t.complex ? 2 : 1)]);
        v.dimL = t.dimL;
        v.dimT = t.dimT;
        v.dimM = t.dimM;
        return v;
    }

    std::complex<double> cplxOf(size_t idx) const
    {
        const NumTensor &t = *rd().tensor;
        return t.complex ? std::complex<double>(t.buf[2 * idx], t.buf[2 * idx + 1])
                         : std::complex<double>(t.buf[idx], 0.0);
    }
    static std::complex<double> cplxOf(const Value &v)
    {
        return std::complex<double>(v.number, v.isComplex ? v.imag : 0.0);
    }

    static std::shared_ptr<NumTensor> complexTensor(const std::complex<double> *data, size_t n)
    {
        auto t = std::make_shared<NumTensor>();
        t->complex = true;
        t->buf.resize(2 * n);
        for (size_t k = 0; k < n; k++) {
            t->buf[2 * k] = data[k].real();
            t->buf[2 * k + 1] = data[k].imag();
        }
        return t;
    }

    // Packed form of `a`, or null when it has to stay as cells (empty, or
    // an element that isn't a plain number in the same unit as the rest).
    static std::shared_ptr<NumTensor> pack(const std::vector<Value> &a)
    {
        if (a.empty())
            return nullptr;
        bool anyComplex = false;
        for (const Value &v : a) {
            if (!isPackable(v) || v.dimL != a[0].dimL || v.dimT != a[0].dimT ||
                v.dimM != a[0].dimM)
                return nullptr;
            anyComplex = anyComplex || v.isComplex;
        }
        auto t = std::make_shared<NumTensor>();
        t->shape = {a.size()};
        t->dimL = a[0].dimL;
        t->dimT = a[0].dimT;
        t->dimM = a[0].dimM;
        t->complex = anyComplex;
        t->buf.reserve(a.size() * (anyComplex ? 2 : 1));
        for (const Value &v : a) {
            t->buf.push_back(v.number);
            if (anyComplex)
                t->buf.push_back(v.isComplex ? v.imag : 0.0);
        }
        return t;
    }

    // As above for a matrix, which additionally has to be rectangular.
    static std::shared_ptr<NumTensor> pack(const std::vector<std::vector<Value>> &m)
    {
        if (m.empty() || m[0].empty())
            return nullptr;
        const Value &first = m[0][0];
        bool anyComplex = false;
        for (const auto &matRow : m) {
            if (matRow.size() != m[0].size())
                return nullptr;
            for (const Value &v : matRow) {
                if (!isPackable(v) || v.dimL != first.dimL || v.dimT != first.dimT ||
                    v.dimM != first.dimM)
                    return nullptr;
                anyComplex = anyComplex || v.isComplex;
            }
        }
        auto t = std::make_shared<NumTensor>();
        t->shape = {m.size(), m[0].size()};
        t->dimL = first.dimL;
        t->dimT = first.dimT;
        t->dimM = first.dimM;
        t->complex = anyComplex;
        const size_t step = anyComplex ? 2 : 1;
        t->buf.resize(m.size() * m[0].size() * step);
        for (size_t r = 0; r < m.size(); r++)
            for (size_t c = 0; c < m[0].size(); c++) {
                const Value &v = m[r][c];
                t->buf[(c * m.size() + r) * step] = v.number;
                if (anyComplex)
                    t->buf[(c * m.size() + r) * step + 1] = v.isComplex ? v.imag : 0.0;
            }
        return t;
    }

    // Before writing to the packed buffer: stop sharing it with any copies.
    void ownTensor()
    {
        if (rd().tensor.use_count() > 1)
            wr().tensor = std::make_shared<NumTensor>(*rd().tensor);
    }

    // Packed -> cells, contents unchanged.
    void unpack()
    {
        if (!rd().tensor)
            return;
        if (packed1())
            wr().array = elems();
        else
            wr().matrix = rowsCopy();
        wr().tensor.reset();
    }

    // Cells -> packed where the contents allow it.
    void repack()
    {
        if (!rd().array.empty() && (wr().tensor = pack(rd().array)))
            wr().array.clear();
        else if (!rd().matrix.empty() && (wr().tensor = pack(rd().matrix)))
            wr().matrix.clear();
    }
};

static_assert(sizeof(Value) == 32, "Value is meant to stay a small handle - see Value::Box");
