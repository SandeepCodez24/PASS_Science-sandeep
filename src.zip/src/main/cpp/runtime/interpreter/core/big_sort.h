#pragma once
// runtime/interpreter/core/big_sort.h - sort() and unique() of data larger
// than memory (2026-11-23, Phase 3, docs/Large_Data_Design.md section 18).
//
// The in-memory paths copy the vector (n doubles) and merge with a buffer of
// up to n/2 more; a rule is built first (n more). When that does not fit the
// memory governor's budget, ncsort::externalSort() sorts the data in chunks
// that do fit, keeping the runs and the result in nc::F64Buf buffers - on
// disk when needed (the disk tier). Same result, bit for bit.

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <string>

#include "governor.h"
#include "par_sort.h"
#include "value.h"

namespace ncbigsort {

// A packed, unitless, real float64 vector (1-D, 1 x n or n x 1)?
inline bool sortableVector(const Value &v) {
  if (!(v.isArray || v.isMatrix) || !v.isPacked() || v.isND() || v.hasUnit() || v.packedSize() == 0)
    return false;
  return v.isArray || v.rows() == 1 || v.cols() == 1;
}

// Test switch: NC_EXTERNAL_SORT=<chunk elements> forces the external sort
// with that chunk size at any size (checks compare it with the in-memory
// sort on small data). 0 / unset: off.
inline size_t forcedChunk() {
  static const size_t chunk = [] {
    std::string text;
#ifdef _WIN32
    char *buffer = nullptr;
    size_t length = 0;
    if (_dupenv_s(&buffer, &length, "NC_EXTERNAL_SORT") == 0 && buffer) {
      text = buffer;
      std::free(buffer);
    }
#else
    if (const char *value = std::getenv("NC_EXTERNAL_SORT"))
      text = value;
#endif
    return text.empty() ? size_t(0) : static_cast<size_t>(std::strtoull(text.c_str(), nullptr, 10));
  }();
  return chunk;
}

// True when the in-memory sort of `v` would not fit now (and the governor
// is on): the external sort is the way.
inline bool needsExternal(const Value &v) {
  if (forcedChunk() > 0)
    return true;
  if (!nc::mem::enforced())
    return false;
  const uint64_t n = v.packedSize();
  const uint64_t need = n * 8 + n * 4 + (v.lazyTensor() ? n * 8 : 0);
  return !nc::mem::fits(need);
}

// Sorts v (sortableVector) stably by `less` into `out` (n elements).
// 0: done; 1: an element was rejected; 2: Stop was pressed.
template <class Less, class Reject> int sortVector(const Value &v, Less less, Reject reject, nc::F64Buf &out) {
  const size_t n = v.packedSize();
  const NumTensor *lazy = v.lazyTensor();
  const double *data = lazy ? nullptr : v.packedData();
  // RAM for one chunk: a third of what may still be used (the chunk, the
  // stable sort's merge buffer, slack), at least 1 M elements.
  const nc::mem::Budget b = nc::mem::budget();
  uint64_t room = 0;
  if (b.known) {
    const uint64_t capLeft = b.cap > b.used ? b.cap - b.used : 0;
    const uint64_t freeLeft = b.available > b.reserve ? b.available - b.reserve : 0;
    room = std::min(capLeft, freeLeft);
  }
  const size_t chunk = forcedChunk() > 0
                           ? forcedChunk()
                           : std::max<size_t>(size_t(1) << 20, static_cast<size_t>(room / 3 / sizeof(double)));
  auto read = [&](size_t first, size_t m, double *dst) {
    if (lazy)
      lazy->lazyBlock(first, m, dst);
    else
      std::memcpy(dst, data + first, m * sizeof(double));
  };
  bool rejected = false;
  if (ncsort::externalSort(n, read, less, reject, chunk, out, rejected))
    return 0;
  return rejected ? 1 : 2;
}

// The result of sorting / unique-ing `v`: shaped like the in-memory paths
// give it (an array stays an array; a row or a column keeps its form).
inline Value vectorLike(const Value &v, nc::F64Buf &&buf) {
  const size_t n = buf.size();
  if (v.isArray)
    return Value::packedArrayFrom(std::move(buf));
  return Value::ndPacked(v.rows() > 1 ? std::vector<size_t>{n, 1} : std::vector<size_t>{1, n}, std::move(buf),
                         false);
}

} // namespace ncbigsort
