#pragma once

// float16 (IEEE binary16) and float8 (OCP E4M3): rounding, bit codec and the
// compact storage of typed tensors (2026-11-21).
//
// The one implementation of these formats. ops/floating (roundToFloatType,
// encodeFloatBits, decodeFloatBits) calls it, and so does value.h, whose
// typed tensors now keep a float16 element in 2 bytes and a float8 one in 1
// byte - their own bit patterns - instead of a 4-byte float. A float16 of
// 628 million elements is 1.26 GB, not 2.5 GB. Reading an element goes
// through a lookup table (every pattern decoded once, at first use).
//
// A stored element always holds a value its format represents exactly
// (the typed-tensor rule); store*() of any other value rounds it first,
// ties to even, as roundTo() does.

#include <cfloat>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>

namespace ncfloat {

// A binary floating-point format, described the way the rounding and the
// bit codec need it.
struct Format {
  int precision;    // significand bits, the implicit leading 1 included
  int minExponent;  // exponent of the smallest normal number
  double maxFinite;
  bool hasInfinity; // false: overflow and Inf map to NaN (float8 E4M3)
  int exponentBits;
  int mantissaBits; // stored fraction bits (precision - 1)
  int bias;
};

// OCP 8-bit floating point (E4M3): max 1.75 * 2^8 = 448; the all-ones
// exponent is still a normal binade, except S.1111.111, which is NaN.
inline constexpr Format kFloat8 = {4, -6, 448.0, false, 4, 3, 7};
inline constexpr Format kFloat16 = {11, -14, 65504.0, true, 5, 10, 15};
inline constexpr Format kFloat32 = {24, -126, static_cast<double>(FLT_MAX), true, 8, 23, 127};

// x rounded to the nearest value of format f (ties to even; overflow gives
// +/-Inf, or NaN where the format has no infinity).
inline double roundTo(const Format &f, double x) {
  if (std::isnan(x))
    return x;
  if (std::isinf(x))
    return f.hasInfinity ? x : std::nan("");
  if (x == 0.0)
    return x; // keeps the sign of zero
  // The spacing of representable values around x: one unit in the last
  // place of x's binade, or of the smallest normal binade for subnormals.
  int e = std::ilogb(x);
  if (e < f.minExponent)
    e = f.minExponent;
  const double quantum = std::ldexp(1.0, e - (f.precision - 1));
  // x / quantum is exact (a power-of-two scaling); nearbyint rounds to
  // nearest, ties to even, in the default rounding mode.
  const double r = std::nearbyint(x / quantum) * quantum;
  if (std::fabs(r) > f.maxFinite)
    return f.hasInfinity ? std::copysign(HUGE_VAL, x) : std::nan("");
  return r;
}

// The bit pattern of an exactly representable value of a narrow format
// (float16 / float8; not float32 - see encodeFloatBits()).
inline uint32_t encodeBits(const Format &f, double x) {
  const uint32_t sign = std::signbit(x) ? 1u : 0u;
  const uint32_t signBit = sign << (f.exponentBits + f.mantissaBits);
  const uint32_t expAllOnes = (1u << f.exponentBits) - 1u;
  const uint32_t mantAllOnes = (1u << f.mantissaBits) - 1u;
  if (std::isnan(x)) {
    // float16: quiet NaN; float8 E4M3: S.1111.111.
    return f.hasInfinity ? (signBit | (expAllOnes << f.mantissaBits) | (1u << (f.mantissaBits - 1)))
                         : (signBit | (expAllOnes << f.mantissaBits) | mantAllOnes);
  }
  if (std::isinf(x))
    return signBit | (expAllOnes << f.mantissaBits); // float16 only (float8 never holds Inf)
  const double a = std::fabs(x);
  if (a == 0.0)
    return signBit;
  const int e = std::ilogb(a);
  if (e < f.minExponent) {
    // Subnormal: exponent field 0, fraction = a / 2^(minExponent - mantissaBits).
    const uint32_t mant = static_cast<uint32_t>(std::ldexp(a, f.mantissaBits - f.minExponent));
    return signBit | mant;
  }
  const uint32_t exp = static_cast<uint32_t>(e + f.bias);
  const uint32_t mant = static_cast<uint32_t>((std::ldexp(a, -e) - 1.0) * std::ldexp(1.0, f.mantissaBits));
  return signBit | (exp << f.mantissaBits) | mant;
}

// The value of a bit pattern of a narrow format.
inline double decodeBits(const Format &f, uint32_t bits) {
  const uint32_t mantAllOnes = (1u << f.mantissaBits) - 1u;
  const uint32_t expAllOnes = (1u << f.exponentBits) - 1u;
  const bool negative = (bits >> (f.exponentBits + f.mantissaBits)) & 1u;
  const uint32_t exp = (bits >> f.mantissaBits) & expAllOnes;
  const uint32_t mant = bits & mantAllOnes;
  double value;
  if (f.hasInfinity && exp == expAllOnes) {
    value = mant == 0 ? HUGE_VAL : std::nan("");
  } else if (!f.hasInfinity && exp == expAllOnes && mant == mantAllOnes) {
    value = std::nan("");
  } else if (exp == 0) {
    value = std::ldexp(static_cast<double>(mant), f.minExponent - f.mantissaBits);
  } else {
    value = std::ldexp(1.0 + std::ldexp(static_cast<double>(mant), -f.mantissaBits),
                       static_cast<int>(exp) - f.bias);
  }
  return negative ? -value : value;
}

// Every pattern decoded once (function-local static: thread-safe start-up).
// Values are kept as floats: every float16 / float8 value is exact in one.
// The tables are never freed: the autosave thread may still read them while
// the process exits, after static objects made later than the DataEngine
// would already be destroyed (a crash seen 2026-11-21 with a std::vector).
inline const float *halfTable() {
  static const float *const table = [] {
    float *t = new float[65536];
    for (uint32_t b = 0; b < 65536; b++)
      t[b] = static_cast<float>(decodeBits(kFloat16, b));
    return t;
  }();
  return table;
}
inline const float *e4m3Table() {
  static const float *const table = [] {
    float *t = new float[256];
    for (uint32_t b = 0; b < 256; b++)
      t[b] = static_cast<float>(decodeBits(kFloat8, b));
    return t;
  }();
  return table;
}

/* ---- fast rounding straight to the bits (2026-11-21) ----

   encodeBits(f, roundTo(f, x)) in a few integer operations on x's bits:
   round to nearest, ties to even; overflow to +/-Inf (float16) or NaN
   (float8); NaN to the format's one NaN with x's sign; signed zeros kept.
   Bit for bit the same as the generic pair for every double (checked over
   every boundary of both formats and on 10^9 random doubles,
   src/test/narrow_float_check.cpp, 2026-11-21: ALL PASS). The same check
   shows storeF32's hardware conversion equals roundTo(kFloat32, x). */

// Rounds the significand `m` (implicit bit included) right by `shift` bits,
// ties to even. shift >= 1.
inline uint64_t roundShift(uint64_t m, int shift) {
  if (shift >= 64)
    return 0; // below half of the smallest step: always rounds to 0 (m < 2^53)
  const uint64_t kept = m >> shift;
  const uint64_t rest = m & ((uint64_t(1) << shift) - 1);
  const uint64_t half = uint64_t(1) << (shift - 1);
  return kept + ((rest > half || (rest == half && (kept & 1))) ? 1 : 0);
}

inline uint16_t halfBits(double x) {
  uint64_t b;
  std::memcpy(&b, &x, 8);
  const uint16_t sign = static_cast<uint16_t>((b >> 48) & 0x8000);
  const uint64_t a = b & 0x7FFFFFFFFFFFFFFFull;
  if (a >= 0x7FF0000000000000ull) // Inf / NaN
    return sign | (a == 0x7FF0000000000000ull ? 0x7C00 : 0x7E00);
  const int e = static_cast<int>(a >> 52) - 1023;
  if (e > 15)
    return sign | 0x7C00;
  const uint64_t m = (a & 0xFFFFFFFFFFFFFull) | (a >> 52 ? 0x10000000000000ull : 0);
  if (e >= -14) {
    // Normal: exponent and 10 fraction bits; a carry out of the fraction
    // steps the exponent (and past 2^15 gives Inf), as IEEE rounding does.
    const uint64_t r = roundShift(m, 42) + (static_cast<uint64_t>(e + 15) << 10) - 0x400;
    return sign | static_cast<uint16_t>(r >= 0x7C00 ? 0x7C00 : r);
  }
  // Subnormal: units of 2^-24.
  return sign | static_cast<uint16_t>(roundShift(m, 42 + (-14 - e)));
}

inline uint8_t e4m3Bits(double x) {
  uint64_t b;
  std::memcpy(&b, &x, 8);
  const uint8_t sign = static_cast<uint8_t>((b >> 56) & 0x80);
  const uint64_t a = b & 0x7FFFFFFFFFFFFFFFull;
  // E4M3 has no infinity. A NaN keeps its sign; Inf and overflow become the
  // POSITIVE NaN (roundTo() gives std::nan("") for them).
  if (a > 0x7FF0000000000000ull)
    return sign | 0x7F;
  if (a == 0x7FF0000000000000ull)
    return 0x7F;
  const int e = static_cast<int>(a >> 52) - 1023;
  if (e > 8)
    return 0x7F;
  const uint64_t m = (a & 0xFFFFFFFFFFFFFull) | (a >> 52 ? 0x10000000000000ull : 0);
  if (e >= -6) {
    const uint64_t r = roundShift(m, 49) + (static_cast<uint64_t>(e + 7) << 3) - 0x8;
    return r >= 0x7F ? uint8_t(0x7F) : static_cast<uint8_t>(sign | r); // past 448: NaN
  }
  return sign | static_cast<uint8_t>(roundShift(m, 49 + (-6 - e))); // units of 2^-9
}

/* ---- typed-tensor storage: float32 4 bytes, float16 2, float8 1 ---- */

inline double loadF32(const uint8_t *p) {
  float v;
  std::memcpy(&v, p, 4);
  return v;
}
inline double loadF16(const uint8_t *p) {
  uint16_t b;
  std::memcpy(&b, p, 2);
  return halfTable()[b];
}
inline double loadF8(const uint8_t *p) { return e4m3Table()[*p]; }

inline void storeF32(uint8_t *p, double x) {
  const float v = static_cast<float>(x); // round to nearest, ties to even
  std::memcpy(p, &v, 4);
}
inline void storeF16(uint8_t *p, double x) {
  const uint16_t b = halfBits(x);
  std::memcpy(p, &b, 2);
}
inline void storeF8(uint8_t *p, double x) { *p = e4m3Bits(x); }

} // namespace ncfloat
