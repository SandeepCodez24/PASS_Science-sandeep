// Units on numbers AND on arrays / matrices, through operators and built-in
// functions (2026-11-18).
//
// A value's unit is three exponents over length, time and mass (Value::dimL /
// dimT / dimM; a packed array or matrix keeps one unit for all its elements -
// [1*m, 2*s] is refused). Before this file only single numbers kept their
// unit through + - * / ^ with whole exponents: a matrix lost it in its first
// operation ([1, 2] * m was a plain [1, 2]), most built-ins dropped it
// (abs(-3 m) was 3, sqrt(4 m^2) was 2) and sin / exp / log took a length as
// if it were a plain number.
//
// The rules, the same for a number and for a matrix:
//   + - and comparisons   both sides need the same unit; the result keeps it
//   * /                   the units multiply / divide (m * m = m^2)
//   ^ p                   the unit to the power p - it must come out whole
//                         ((4 m^2)^0.5 = 2 m; (4 m)^0.5 is refused)
//   abs round sum max ... the result has the argument's unit (unitKeeping)
//   var pvar              the unit squared;   prod  the unit ^ count
//   sqrt cbrt sqr cube    half / third / twice / three times the exponents
//   dot cross kron        the two units multiplied
//   sin exp log ...       need a value without a unit (unitless)
//   atan2(y, x)           y and x in the same unit; the angle has none
// Any other function sees the values as before.
#ifndef NC_UNITS_H
#define NC_UNITS_H

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "value.h"

namespace nc {
namespace units {

struct Dim {
  int l = 0, t = 0, m = 0;
  bool zero() const { return l == 0 && t == 0 && m == 0; }
  bool operator==(const Dim &o) const { return l == o.l && t == o.t && m == o.m; }
  bool operator!=(const Dim &o) const { return !(*this == o); }
};

inline Dim unitOf(const Value &v) {
  int16_t l, t, m;
  v.unitDims(l, t, m);
  return {l, t, m};
}

// v without its unit (a copy).
inline Value stripped(const Value &v) {
  if (!v.hasUnit())
    return v;
  Value out = v;
  out.setUnitDims(0, 0, 0);
  return out;
}

// Gives a number or packed array / matrix result the unit d. False (with
// `err`) when an exponent does not fit the unit storage.
bool attach(Value &v, const Dim &d, std::string &err);

// "m", "m/s^2", "kg*m^2/s^2", "1/s" - as numbers print it.
std::string text(const Dim &d);

enum class Call { PassThrough, Done, Refused };

// A built-in called with at least one argument that has a unit: applies the
// rules above. `call` runs the function on unit-free copies of the
// arguments. Refused: the error has been printed.
// argNames: the names of named inputs (empty for one given in order), or null.
Call builtinCall(const std::string &name, const std::vector<Value> &args, Value &out,
                 const std::function<Value(const std::vector<Value> &)> &call,
                 const std::vector<std::string> *argNames = nullptr);

// True if any argument has a unit (one check per argument).
inline bool anyUnit(const std::vector<Value> &args) {
  for (const Value &a : args)
    if (a.hasUnit())
      return true;
  return false;
}

} // namespace units
} // namespace nc

#endif // NC_UNITS_H
