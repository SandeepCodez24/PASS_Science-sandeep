#pragma once

#include <string>
#include <vector>

#include "value.h"

// Print a Value to stdout. Implemented in output.cpp.
//
// With a name, the value is shown MATLAB "format loose" style:
//
//   (blank line)            <- only before the first block of a statement
//   name =
//   (blank line)
//       value / grid rows   <- indented 4 spaces
//   (blank line)
//
// Without a name, the bare value is printed on its own line.
void printValue(const std::string &name, const Value &v);

// Start a fresh display group: the next named printValue() opens with a
// blank line again. Called by the REPL before every statement and after any
// plain output (publish/print) so a block is always separated from text
// above it by exactly one blank line.
void resetDisplaySpacing();

// Renders a Value the same way printValue() would (number/array/matrix/dict
// formatting), but as a plain string with no trailing newline and no "name ="
// prefix. Text values are rendered unquoted (matches printValue's isText
// branch), not the quoted form print()/publish() uses for text arguments.
//
// A matrix renders as the MATLAB-style grid (one line per row, columns
// right-aligned, no brackets) at the top level, and in the compact
// declaration notation [1,2;3,4] when it sits inside an array, dict or
// object.
std::string valueToString(const Value &v);

// Same, but a matrix is always the one-line notation [1,2;3,4] - for str()
// and anywhere text must stay on one line.
std::string valueToCompactString(const Value &v);

// The two matrix forms on their own (v must be a matrix).
std::string matrixGrid(const Value &v);
std::string matrixCompact(const Value &v);

std::string formatNumber(double value);
// A complex number as "3+4i" / "3-4i", each part formatted by formatNumber().
std::string formatComplex(double re, double im);
