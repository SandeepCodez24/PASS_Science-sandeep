#pragma once

#include <string>
#include <vector>

#include "value.h"

// Print a Value to stdout. Implemented in output.cpp.
void printValue(const std::string &name, const Value &v);

// Renders a Value the same way printValue() would (number/array/matrix/dict
// formatting), but as a plain string with no trailing newline and no "name ="
// prefix. Text values are rendered unquoted (matches printValue's isText
// branch), not the quoted form print()/publish() uses for text arguments.
std::string valueToString(const Value &v);

std::string formatNumber(double value);
