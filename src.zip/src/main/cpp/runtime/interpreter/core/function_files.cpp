// Function files: where to look. See function_files.h.
#include "function_files.h"

#include <atomic>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <mutex>
#include <system_error>

#if !defined(_WIN32)
#include <pwd.h>
#include <unistd.h>
#endif

namespace nc {
namespace fnfiles {

namespace fs = std::filesystem;

namespace {

std::mutex &providerMutex() {
  static std::mutex m;
  return m;
}

FolderProvider &providerSlot() {
  static FolderProvider p;
  return p;
}

std::string envText(const char *name) {
#ifdef _WIN32
  // _wgetenv: the folder may hold any character (a user name in Tamil, ...).
  std::wstring wname;
  for (const char *c = name; *c; ++c)
    wname.push_back(static_cast<wchar_t>(*c));
  wchar_t *w = nullptr;
  size_t len = 0;
  if (_wdupenv_s(&w, &len, wname.c_str()) != 0 || !w)
    return std::string();
  std::string out = *w ? fs::path(w).u8string() : std::string();
  std::free(w);
  return out;
#else
  const char *v = std::getenv(name);
  return v ? std::string(v) : std::string();
#endif
}

// What Java's System.getProperty("user.home") gives, so the IDE (which
// writes the library) and nc.exe (which reads it) agree on every OS.
fs::path homeFolder() {
#ifdef _WIN32
  std::string h = envText("USERPROFILE");
  if (h.empty()) {
    const std::string drive = envText("HOMEDRIVE"), path = envText("HOMEPATH");
    if (!drive.empty() && !path.empty())
      h = drive + path;
  }
  return h.empty() ? fs::path() : fs::u8path(h);
#else
  std::string h = envText("HOME");
  if (h.empty()) {
    if (const passwd *pw = getpwuid(getuid()))
      if (pw->pw_dir)
        h = pw->pw_dir;
  }
  return h.empty() ? fs::path() : fs::path(h);
#endif
}

bool validName(const std::string &name) {
  if (name.empty() || name == "." || name == "..")
    return false;
  for (unsigned char c : name)
    if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' ||
        c == '>' || c == '|' || c < 0x20)
      return false;
  return true;
}

// Same folder? (Compared after making both absolute and normal.)
std::string folderKey(const fs::path &p) {
  std::error_code ec;
  fs::path a = fs::absolute(p, ec);
  if (ec)
    a = p;
  std::string k = a.lexically_normal().generic_u8string();
  while (k.size() > 1 && k.back() == '/')
    k.pop_back();
#ifdef _WIN32
  for (char &c : k)
    if (c >= 'A' && c <= 'Z')
      c = static_cast<char>(c - 'A' + 'a');
#endif
  return k;
}

// The file exists as a regular file AND its name on disk is exactly
// `fileName`: Windows and macOS find "Process_A.nc" for "process_a.nc",
// and NC names are case-sensitive.
bool existsExactly(const fs::path &folder, const std::string &fileName, fs::path &out) {
  std::error_code ec;
  const fs::path candidate = folder / fs::u8path(fileName);
  if (!fs::is_regular_file(candidate, ec) || ec)
    return false;
#if defined(_WIN32) || defined(__APPLE__)
  // Rare path (only for a name that is neither a function of the script nor
  // a built-in): reading the folder's entries is fine here.
  bool exact = false;
  for (fs::directory_iterator it(folder, fs::directory_options::skip_permission_denied, ec), end;
       !ec && it != end; it.increment(ec)) {
    if (it->path().filename().u8string() == fileName) {
      exact = true;
      break;
    }
  }
  if (!exact)
    return false;
#endif
  out = candidate;
  return true;
}

// A NetCDF data file is also a ".nc" file. Only text is NC code: a file that
// starts like NetCDF classic ("CDF" 1/2/5) or NetCDF-4 / HDF5, holds a NUL
// byte in its first 4 KB, or is bigger than any script (64 MB) is never read
// as one - so a data file time.nc beside a script costs one small read, not
// a whole read and parse on every time(...) call.
bool looksLikeCode(const fs::path &p) {
  std::error_code ec;
  const auto size = fs::file_size(p, ec);
  if (ec || size > (64ull << 20))
    return false;
  std::ifstream in(p, std::ios::binary);
  if (!in)
    return false;
  char head[4096];
  in.read(head, sizeof head);
  const std::streamsize n = in.gcount();
  if (n >= 4 && head[0] == 'C' && head[1] == 'D' && head[2] == 'F' &&
      (head[3] == '\x01' || head[3] == '\x02' || head[3] == '\x05'))
    return false;
  if (n >= 8 && std::memcmp(head, "\x89HDF\r\n\x1a\n", 8) == 0)
    return false;
  for (std::streamsize i = 0; i < n; i++)
    if (head[i] == '\0')
      return false;
  return true;
}

} // namespace

namespace {
std::atomic<unsigned long long> &generationSlot() {
  static std::atomic<unsigned long long> g{0};
  return g;
}
} // namespace

void foldersChanged() { generationSlot().fetch_add(1, std::memory_order_relaxed); }
unsigned long long foldersGeneration() { return generationSlot().load(std::memory_order_relaxed); }

void setFolderProvider(FolderProvider provider) {
  {
    std::lock_guard<std::mutex> lock(providerMutex());
    providerSlot() = std::move(provider);
  }
  foldersChanged();
}

fs::path libraryFolder() {
  const std::string over = envText("NC_FUNCTION_LIBRARY");
  if (!over.empty())
    return fs::u8path(over);
  const fs::path home = homeFolder();
  if (home.empty())
    return fs::path();
  return home / ".neuralcode" / "process_functions";
}

std::vector<fs::path> searchFolders() {
  std::vector<fs::path> raw;
  {
    std::lock_guard<std::mutex> lock(providerMutex());
    if (providerSlot())
      raw = providerSlot()();
  }
  if (raw.empty()) {
    std::error_code ec;
    fs::path cwd = fs::current_path(ec);
    if (!ec)
      raw.push_back(cwd);
  }
  const fs::path lib = libraryFolder();
  if (!lib.empty())
    raw.push_back(lib);

  std::vector<fs::path> out;
  std::vector<std::string> seen;
  for (const fs::path &p : raw) {
    if (p.empty())
      continue;
    const std::string k = folderKey(p);
    bool dup = false;
    for (const std::string &s : seen)
      dup = dup || s == k;
    if (dup)
      continue;
    seen.push_back(k);
    out.push_back(p);
  }
  return out;
}

std::optional<fs::path> find(const std::string &name) {
  if (!validName(name))
    return std::nullopt;
  const std::string fileName = name + ".nc";
  for (const fs::path &folder : searchFolders()) {
    fs::path hit;
    if (existsExactly(folder, fileName, hit))
      return looksLikeCode(hit) ? std::optional<fs::path>(hit) : std::nullopt; // a data file: no code here
  }
  return std::nullopt;
}

} // namespace fnfiles
} // namespace nc
