#pragma once

#include <istream>
#include <string>

// Joins a raw source/input line with however many following lines are
// chained onto it via a trailing "~~" line-continuation marker. Leading
// whitespace on each continuation line is stripped before joining.
inline std::string readLogicalLine(std::istream &in, std::string firstLine) {
  auto rtrim = [](const std::string &s) -> std::string {
    size_t e = s.find_last_not_of(" \t\r\n");
    return (e == std::string::npos) ? std::string() : s.substr(0, e + 1);
  };
  auto ltrim = [](const std::string &s) -> std::string {
    size_t b = s.find_first_not_of(" \t\r\n");
    return (b == std::string::npos) ? std::string() : s.substr(b);
  };

  std::string line = firstLine;
  std::string trimmed = rtrim(line);

  while (trimmed.size() >= 2 && trimmed.substr(trimmed.size() - 2) == "~~") {
    line = rtrim(trimmed.substr(0, trimmed.size() - 2));

    std::string nextLine;
    if (!std::getline(in, nextLine))
      break;

    line += " " + ltrim(nextLine);
    trimmed = rtrim(line);
  }

  return line;
}
