#pragma once
#include "value.h"
#include <complex>
#include <functional>

// Shared elementwise-broadcast helpers (NumPy/SciPy Parity Roadmap §4.1).
//
// Every scalar math builtin (sin_op, sqrt_op, exp_op, ...) used to read
// `.number` directly and ignore isArray/isMatrix entirely - a silent-wrong-
// answer bug, not a missing feature: sin([0,1,2]) returned sin(0) (0.number
// on an array-flagged Value defaults to 0), not an array. mapElementwise/
// zipElementwise are the single, reusable "apply this scalar function
// elementwise, preserving array/matrix shape" utility every scalar op
// should route through instead of touching .number directly - fixing the
// bug once, centrally, rather than once per function (and per future
// function, forever).

// Set true at the start of every mapElementwise()/zipElementwise() call,
// false only when zipElementwise() rejects its inputs (mismatched array
// length/matrix dimensions, or a genuinely incompatible operand shape - see
// its own comment). Same "global out-of-band status flag checked a few
// frames up the call stack" convention builtins.h's g_lastBuiltinFound
// already uses for the same reason: these are plain, reusable free
// functions with no Parser access of their own, so they can't set
// evaluationSucceeded_ directly - callers that need to know (Parser::
// evaluateBinaryOpValues, parser_expression.cpp) check this right after
// calling add()/sub()/.../ any arithmetic.cpp function that routes through
// here. Before this flag existed, a shape/type mismatch printed its error
// message to stderr but the caller had no way to tell "this failed" from
// "this genuinely computed 0" - the failed expression's result silently
// became a normal, further-usable Value(0) instead of aborting the
// statement the way every other invalid-operation error in this codebase
// does (dimension mismatches, text arithmetic, ...).
extern bool g_lastElementwiseOk;

// Applies fn to every scalar element; preserves array/matrix shape.
// Scalar input -> scalar output, unchanged from a plain fn(a.number) call.
Value mapElementwise(const Value &a, const std::function<double(double)> &fn);

// Applies fn to corresponding element pairs (for two-argument ufuncs like
// arctan2/hypot/maximum). Matrix+matrix or array+array must share the same
// shape (mismatched shapes fall back to Value(0) with g_lastElementwiseOk
// set false, mirroring this codebase's existing "print an error, return 0"
// convention for shape mismatches - see mul()'s matrix-dimension check in
// arithmetic.cpp). Matrix/array+scalar broadcasts the scalar across every
// element, either operand order - but only when the "scalar" side is
// actually a plain scalar (not itself an array/matrix/text/dict/object of
// the WRONG shape to combine with the other side); anything else is the
// same kind of invalid-operand-shape failure as a length/dimension
// mismatch, not silently treated as the number 0.
Value zipElementwise(const Value &a, const Value &b,
                      const std::function<double(double, double)> &fn);

// Complex counterparts of the two above: same shape rules, same broadcasting
// of a scalar over an array/matrix, same error messages. Operands may be any
// mix of real and complex. A result whose imaginary parts are all exactly
// zero comes back as an ordinary real number/array/matrix.
using Cplx = std::complex<double>;

Value mapElementwiseC(const Value &a, const std::function<Cplx(Cplx)> &fn);

Value zipElementwiseC(const Value &a, const Value &b,
                       const std::function<Cplx(Cplx, Cplx)> &fn);

// For a function whose real form is undefined on part of the real line
// (sqrt and log of a negative number, inv_sin outside [-1, 1], ...).
//
// `a` is real. If no element is outside the real domain, this is exactly
// mapElementwise(a, realFn) - same code path, same bits. If any element is,
// the whole value goes through complexFn instead, so that element gets its
// complex answer (sqrt(-4) is 2i) and the result is a complex array; the
// other elements keep their real values.
//
// realFn and outsideRealDomain must be PURE (see mapElementwisePure below):
// the all-real case runs realFn on several threads at once.
Value mapElementwisePromoting(const Value &a, const std::function<double(double)> &realFn,
                               bool (*outsideRealDomain)(double),
                               const std::function<Cplx(Cplx)> &complexFn);

/* ================= MULTICORE FAST PATHS (nc::par) =================

   mapElementwisePure / zipElementwisePure behave exactly like
   mapElementwise / zipElementwise above - same shapes, same broadcasting,
   same error messages, same bits - and add two things on packed (all
   numeric) data:
     - fn is called directly (a template, not one std::function call per
       element), and
     - large arrays are spread over the CPU cores with nc::par::forBlocks.
   Each result element depends only on the same element(s) of the input, so
   the result is identical for every thread count.

   ONLY for a PURE fn: a function of its arguments alone. No captured state
   that it changes, no printing, no errors, no random numbers - it runs on
   several threads at once, in no particular order. Anything else keeps
   using the std::function versions, which stay serial (decision 4 of
   docs/Multicore_Multithread_Architecture.md: serial unless declared).

   Cost (nc::par::Cost): ns per element on one core, measured once. Use
   kElementwiseArith for + - * / and kElementwiseMath for sin, exp, ...
   If Stop is pressed mid-way, the result is given up (g_lastElementwiseOk
   is false and nothing is printed), so the statement does not complete. */

#include "parallel/par.h"

inline constexpr nc::par::Cost kElementwiseArith = nc::par::stream(1.1); // add: memory-bound
inline constexpr nc::par::Cost kElementwiseMath = nc::par::compute(6.0); // sin ~5.8 ns, exp ~3.7

namespace ncew_detail {
template <class Fn>
bool parMap(const double *in, double *out, size_t n, Fn &fn, nc::par::Cost cost, const char *label) {
  return nc::par::forBlocks(n, cost, label, [&](size_t begin, size_t end) {
           for (size_t k = begin; k < end; k++)
             out[k] = fn(in[k]);
         }) == nc::par::Outcome::Done;
}
template <class Fn>
bool parZip(const double *a, const double *b, double *out, size_t n, Fn &fn, nc::par::Cost cost,
            const char *label) {
  return nc::par::forBlocks(n, cost, label, [&](size_t begin, size_t end) {
           for (size_t k = begin; k < end; k++)
             out[k] = fn(a[k], b[k]);
         }) == nc::par::Outcome::Done;
}
// Packed container `c` with a scalar `s` on the left or right.
template <class Fn>
bool parScalar(const Value &c, double s, bool containerLeft, Fn &fn, nc::par::Cost cost,
               const char *label, Value &result) {
  return c.mapPackedBuffer(
      [&](const double *in, double *out, size_t n) {
        if (containerLeft) {
          auto g = [&](double x) { return fn(x, s); };
          return parMap(in, out, n, g, cost, label);
        }
        auto g = [&](double x) { return fn(s, x); };
        return parMap(in, out, n, g, cost, label);
      },
      result);
}
inline bool plainScalar(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef;
}
} // namespace ncew_detail

template <class Fn>
Value mapElementwisePure(const Value &a, Fn fn, nc::par::Cost cost = kElementwiseMath,
                         const char *label = nullptr) {
  if ((a.isMatrix || a.isArray) && a.isPacked()) {
    g_lastElementwiseOk = true;
    Value result;
    if (!a.mapPackedBuffer(
            [&](const double *in, double *out, size_t n) {
              return ncew_detail::parMap(in, out, n, fn, cost, label);
            },
            result)) {
      g_lastElementwiseOk = false; // Stop pressed: give the result up
      return Value(0);
    }
    return result;
  }
  return mapElementwise(a, std::function<double(double)>(fn));
}

template <class Fn>
Value zipElementwisePure(const Value &a, const Value &b, Fn fn, nc::par::Cost cost = kElementwiseArith,
                         const char *label = nullptr) {
  const bool aBox = a.isMatrix || a.isArray, bBox = b.isMatrix || b.isArray;
  // The fast cases only; every check and every other case stays in
  // zipElementwise(), so error messages cannot drift apart.
  bool fast = false;
  if (aBox && bBox)
    fast = a.isMatrix == b.isMatrix && a.sameShapeAs(b);
  else if (aBox != bBox) {
    const Value &c = aBox ? a : b;
    const Value &s = aBox ? b : a;
    fast = c.isPacked() && ncew_detail::plainScalar(s) && !s.isComplex;
  }
  if (!fast)
    return zipElementwise(a, b, std::function<double(double, double)>(fn));

  g_lastElementwiseOk = true;
  Value result;
  bool done;
  if (aBox && bBox) {
    done = a.zipPackedBuffer(
        b,
        [&](const double *x, const double *y, double *out, size_t n) {
          return ncew_detail::parZip(x, y, out, n, fn, cost, label);
        },
        result);
  } else {
    done = ncew_detail::parScalar(aBox ? a : b, aBox ? b.number : a.number, aBox, fn, cost, label,
                                  result);
  }
  if (!done) {
    g_lastElementwiseOk = false; // Stop pressed: give the result up
    return Value(0);
  }
  return result;
}
