#pragma once
#include "value.h"
#include <complex>
#include <functional>

// Shared elementwise-broadcast helpers (NumPy/SciPy Parity Roadmap §4.1).
//
// Every scalar math builtin (sin_op, sqrt_op, exp_op, ...) used to read
// `.number` directly and ignore isArray/isMatrix entirely - a silent-wrong-
// answer bug, not a missing feature: sin([0,1,2]) returned sin(0) (0.number
// on an array-flagged Value defaults to 0), not an array. mapElementwise/
// zipElementwise are the single, reusable "apply this scalar function
// elementwise, preserving array/matrix shape" utility every scalar op
// should route through instead of touching .number directly - fixing the
// bug once, centrally, rather than once per function (and per future
// function, forever).

// Set true at the start of every mapElementwise()/zipElementwise() call,
// false only when zipElementwise() rejects its inputs (mismatched array
// length/matrix dimensions, or a genuinely incompatible operand shape - see
// its own comment). Same "global out-of-band status flag checked a few
// frames up the call stack" convention builtins.h's g_lastBuiltinFound
// already uses for the same reason: these are plain, reusable free
// functions with no Parser access of their own, so they can't set
// evaluationSucceeded_ directly - callers that need to know (Parser::
// evaluateBinaryOpValues, parser_expression.cpp) check this right after
// calling add()/sub()/.../ any arithmetic.cpp function that routes through
// here. Before this flag existed, a shape/type mismatch printed its error
// message to stderr but the caller had no way to tell "this failed" from
// "this genuinely computed 0" - the failed expression's result silently
// became a normal, further-usable Value(0) instead of aborting the
// statement the way every other invalid-operation error in this codebase
// does (dimension mismatches, text arithmetic, ...).
extern bool g_lastElementwiseOk;

// Applies fn to every scalar element; preserves array/matrix shape.
// Scalar input -> scalar output, unchanged from a plain fn(a.number) call.
Value mapElementwise(const Value &a, const std::function<double(double)> &fn);

// Applies fn to corresponding element pairs (for two-argument ufuncs like
// arctan2/hypot/maximum). Matrix+matrix or array+array must share the same
// shape (mismatched shapes fall back to Value(0) with g_lastElementwiseOk
// set false, mirroring this codebase's existing "print an error, return 0"
// convention for shape mismatches - see mul()'s matrix-dimension check in
// arithmetic.cpp). Matrix/array+scalar broadcasts the scalar across every
// element, either operand order - but only when the "scalar" side is
// actually a plain scalar (not itself an array/matrix/text/dict/object of
// the WRONG shape to combine with the other side); anything else is the
// same kind of invalid-operand-shape failure as a length/dimension
// mismatch, not silently treated as the number 0.
Value zipElementwise(const Value &a, const Value &b,
                      const std::function<double(double, double)> &fn);

// Complex counterparts of the two above: same shape rules, same broadcasting
// of a scalar over an array/matrix, same error messages. Operands may be any
// mix of real and complex. A result whose imaginary parts are all exactly
// zero comes back as an ordinary real number/array/matrix.
using Cplx = std::complex<double>;

Value mapElementwiseC(const Value &a, const std::function<Cplx(Cplx)> &fn);

Value zipElementwiseC(const Value &a, const Value &b,
                       const std::function<Cplx(Cplx, Cplx)> &fn);

// For a function whose real form is undefined on part of the real line
// (sqrt and log of a negative number, inv_sin outside [-1, 1], ...).
//
// `a` is real. If no element is outside the real domain, this is exactly
// mapElementwise(a, realFn) - same code path, same bits. If any element is,
// the whole value goes through complexFn instead, so that element gets its
// complex answer (sqrt(-4) is 2i) and the result is a complex array; the
// other elements keep their real values.
Value mapElementwisePromoting(const Value &a, const std::function<double(double)> &realFn,
                               bool (*outsideRealDomain)(double),
                               const std::function<Cplx(Cplx)> &complexFn);
