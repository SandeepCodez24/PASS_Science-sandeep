#ifndef SCRIPT_MANAGER_H
#define SCRIPT_MANAGER_H

#include <filesystem>
#include <map>
#include <optional>
#include <string>
#include <vector>

// ScriptManager is one class whose implementation is split across three
// files by responsibility (the class itself is not split - C++ has no
// partial-class mechanism, so the declaration stays in this one header):
//   SM_main.cpp     - construction/init and the public entry point that
//                      ties the two stages together (tryExecuteInputAsFile)
//   SM_stage_01.cpp - workspace management (MATLAB-like cwd/path/which,
//                      the .nc file index and its on-disk cache)
//   SM_stage_02.cpp - the line-by-line execution driver (executeFile)
class ScriptManager {
public:
  static constexpr size_t MAX_SCRIPT_DEPTH = 100;

  ScriptManager(const std::filesystem::path &applicationDirectory,
                const std::filesystem::path &launchWorkingDirectory);

  bool init();

  // ---- SM_main: public entry point (glue between the two stages) ----
  bool tryExecuteInputAsFile(const std::string &rawInput);

  // ---- SM_stage_02: line-by-line execution driver ----
  void executeFile(const std::string &absolutePath);

  // ---- SM_stage_01: workspace management ----
  std::optional<std::string>
  resolveFilePath(const std::string &normalizedInput);
  std::vector<std::string> resolveAllFilesForStem(const std::string &stemKey);
  void addPath(const std::string &path);
  void removePath(const std::string &path);
  void rehash();
  void saveSearchPaths();
  void persistCurrentDirectory();
  void printPath() const;
  void printPwd() const;
  void which(const std::string &name);
  void whichAll(const std::string &name);
  std::filesystem::path getWorkspaceDirectory() const;

  // MATLAB-like current folder/workspace behavior
  void setWorkspaceDirectory(const std::filesystem::path &path);

private:
  struct ExecutionFrame {
    std::filesystem::path file;
    std::filesystem::path directory;
  };

  std::filesystem::path applicationDirectory_;
  std::filesystem::path launchWorkingDirectory_;
  std::filesystem::path workspaceDirectory_;
  std::filesystem::path searchPathsFile_;
  std::filesystem::path cacheFile_;

  std::vector<std::string> searchPaths_;
  std::vector<std::string> envSearchPaths_;
  std::map<std::string, std::vector<std::string>> ncFileIndex_;
  std::vector<ExecutionFrame> executionStack_;
  std::vector<std::string> preservedSearchPathLines_;

  static const std::vector<std::string> heavyDirectoryNames_;

  // ---- SM_stage_01: path/string utilities ----
  static std::string normalizeStem(const std::string &raw);
  static std::string toLower(std::string s);
  static std::filesystem::path normalizePath(const std::filesystem::path &path);
  static std::vector<std::string> splitPathList(const std::string &paths);
  static bool isEnvPathSeparator(char ch);
  static bool shouldSkipDirectory(const std::filesystem::path &dir);

  bool isRegularFile(const std::filesystem::path &path) const;

  // ---- SM_stage_02: execution-stack helpers ----
  // getCurrentExecutionDirectory() is the one real coupling point between
  // the two stages: SM_stage_01's resolveFilePath() needs to know the
  // directory of the currently-executing script (SM_stage_02 state) to
  // resolve relative paths correctly during nested script calls.
  bool pathsReferToSameFile(const std::filesystem::path &a,
                            const std::filesystem::path &b) const;
  std::filesystem::path getCurrentExecutionDirectory() const;

  // ---- SM_stage_01: workspace/search-path management ----
  bool registerSearchPath(const std::filesystem::path &path);
  void registerEnvSearchPath(const std::filesystem::path &path);
  void loadPersistentSearchPaths();
  bool loadCachedNcFileIndex();
  void saveCachedNcFileIndex();
  std::string computeSearchPathSignature() const;
  void buildNcFileIndex();
  void discoverNcFilesInDirectory(const std::filesystem::path &dirPath);
  void indexNcFile(const std::filesystem::path &filePath);
  std::optional<std::string> findNcFileByStem(const std::string &stemKey);
  std::vector<std::string> findNcFilesByStem(const std::string &stemKey);
  void loadNcPathEnv();
};

#endif
