// Stage 1: workspace management - MATLAB-like current-folder/search-path
// behavior, the .nc file index, and its on-disk cache.
#include "SM_main.h"

#ifdef _WIN32
#include <cstdlib>
#endif

#include <algorithm>
#include <cctype>
#include <fstream>
#include <functional>
#include <iostream>
#include <sstream>

const std::vector<std::string> ScriptManager::heavyDirectoryNames_ = {
    ".git",    ".gitlab",      ".github", "build", "bin",  "obj", "Debug",
    "Release", "node_modules", ".vscode", ".idea", "dist", "out", "target"};

static std::string trimWhitespace(const std::string &value) {
  size_t start = 0;
  size_t end = value.size();
  while (start < end && std::isspace(static_cast<unsigned char>(value[start])))
    ++start;
  while (end > start &&
         std::isspace(static_cast<unsigned char>(value[end - 1])))
    --end;
  return value.substr(start, end - start);
}

std::string ScriptManager::toLower(std::string s) {
  for (char &ch : s)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  return s;
}

std::filesystem::path
ScriptManager::normalizePath(const std::filesystem::path &path) {
  if (path.empty())
    return {};

  std::error_code ec;
  auto absolutePath = std::filesystem::absolute(path, ec);
  if (ec)
    absolutePath = std::filesystem::absolute(path);
  return absolutePath.lexically_normal();
}

std::string ScriptManager::normalizeStem(const std::string &raw) {
  std::filesystem::path p(raw);
  std::string stem = p.stem().string();
  return toLower(stem);
}

bool ScriptManager::isEnvPathSeparator(char ch) {
#ifdef _WIN32
  return ch == ';';
#else
  return ch == ':';
#endif
}

std::vector<std::string>
ScriptManager::splitPathList(const std::string &paths) {
  std::vector<std::string> result;
  std::string current;
  for (char ch : paths) {
    if (isEnvPathSeparator(ch)) {
      if (!current.empty()) {
        result.push_back(current);
        current.clear();
      }
      continue;
    }
    current.push_back(ch);
  }
  if (!current.empty())
    result.push_back(current);
  return result;
}

bool ScriptManager::shouldSkipDirectory(const std::filesystem::path &dir) {
  std::string name = toLower(dir.filename().string());
  return std::find(heavyDirectoryNames_.begin(), heavyDirectoryNames_.end(),
                   name) != heavyDirectoryNames_.end();
}

bool ScriptManager::isRegularFile(const std::filesystem::path &path) const {
  std::error_code ec;
  return std::filesystem::exists(path, ec) &&
         std::filesystem::is_regular_file(path, ec);
}

bool ScriptManager::registerSearchPath(const std::filesystem::path &path) {
  std::filesystem::path normalized = normalizePath(path);
  if (normalized.empty())
    return false;

  std::string normalizedString = normalized.string();
  if (std::find(searchPaths_.begin(), searchPaths_.end(), normalizedString) ==
      searchPaths_.end()) {
    searchPaths_.push_back(normalizedString);
    return true;
  }
  return false;
}

void ScriptManager::registerEnvSearchPath(const std::filesystem::path &path) {
  std::filesystem::path normalized = normalizePath(path);
  if (normalized.empty())
    return;

  std::string normalizedString = normalized.string();
  if (std::find(searchPaths_.begin(), searchPaths_.end(), normalizedString) !=
      searchPaths_.end())
    return;
  if (std::find(envSearchPaths_.begin(), envSearchPaths_.end(),
                normalizedString) == envSearchPaths_.end()) {
    envSearchPaths_.push_back(normalizedString);
  }
}

void ScriptManager::loadPersistentSearchPaths() {
  preservedSearchPathLines_.clear();
  searchPaths_.clear();

  std::error_code ec;
  if (!std::filesystem::exists(searchPathsFile_, ec))
    return;

  std::ifstream in(searchPathsFile_.string());
  if (!in.is_open())
    return;

  std::string line;
  while (std::getline(in, line)) {
    std::string trimmed = trimWhitespace(line);
    if (trimmed.empty()) {
      preservedSearchPathLines_.push_back("");
      continue;
    }

    if (trimmed.front() == '#') {
      preservedSearchPathLines_.push_back(line);
      continue;
    }

    registerSearchPath(std::filesystem::path(trimmed));
  }
}

bool ScriptManager::loadCachedNcFileIndex() {
  ncFileIndex_.clear();

  std::error_code ec;
  if (!std::filesystem::exists(cacheFile_, ec))
    return false;

  std::ifstream in(cacheFile_.string());
  if (!in.is_open())
    return false;

  std::string line;
  std::string cachedSignature;
  std::map<std::string, std::vector<std::string>> index;

  while (std::getline(in, line)) {
    if (line.empty())
      continue;

    if (line.rfind("# signature:", 0) == 0) {
      cachedSignature = line.substr(12);
      continue;
    }

    auto tab = line.find('\t');
    if (tab == std::string::npos)
      continue;

    std::string stem = line.substr(0, tab);
    std::string path = line.substr(tab + 1);
    if (stem.empty() || path.empty())
      continue;

    std::filesystem::path candidate = normalizePath(path);
    if (!isRegularFile(candidate))
      continue;

    std::string absolutePath = candidate.string();
    auto &files = index[stem];
    if (std::find(files.begin(), files.end(), absolutePath) == files.end())
      files.push_back(absolutePath);
  }

  if (cachedSignature.empty() ||
      cachedSignature != computeSearchPathSignature())
    return false;

  ncFileIndex_ = std::move(index);
  return !ncFileIndex_.empty();
}

std::string ScriptManager::computeSearchPathSignature() const {
  std::vector<std::string> normalized;
  for (const auto &root : searchPaths_) {
    std::filesystem::path absRoot = normalizePath(root);
    if (!absRoot.empty())
      normalized.push_back(absRoot.string());
  }
  for (const auto &root : envSearchPaths_) {
    std::filesystem::path absRoot = normalizePath(root);
    if (!absRoot.empty())
      normalized.push_back(absRoot.string());
  }

  std::sort(normalized.begin(), normalized.end());
  std::ostringstream builder;
  for (const auto &entry : normalized)
    builder << entry << "\n";
  return std::to_string(std::hash<std::string>{}(builder.str()));
}

void ScriptManager::saveCachedNcFileIndex() {
  std::filesystem::path directory = cacheFile_.parent_path();
  std::error_code ec;
  if (!directory.empty())
    std::filesystem::create_directories(directory, ec);

  std::ofstream out(cacheFile_.string(), std::ios::trunc);
  if (!out.is_open())
    return;

  out << "# signature:" << computeSearchPathSignature() << "\n";
  for (const auto &entry : ncFileIndex_) {
    for (const auto &path : entry.second)
      out << entry.first << '\t' << path << "\n";
  }
}

void ScriptManager::saveSearchPaths() {
  std::error_code ec;
  std::filesystem::create_directories(searchPathsFile_.parent_path(), ec);

  std::filesystem::path tempFile = searchPathsFile_;
  tempFile += ".tmp";

  std::ofstream out(tempFile.string(), std::ios::trunc);
  if (!out.is_open())
    return;

  for (const auto &line : preservedSearchPathLines_)
    out << line << "\n";

  for (const auto &path : searchPaths_)
    out << path << "\n";

  out.flush();
  if (!out)
    return;

  std::filesystem::rename(tempFile, searchPathsFile_, ec);
  if (ec) {
    std::filesystem::remove(searchPathsFile_, ec);
    std::filesystem::rename(tempFile, searchPathsFile_, ec);
  }
}

void ScriptManager::buildNcFileIndex() {
  ncFileIndex_.clear();

  std::vector<std::filesystem::path> roots;
  std::vector<std::string> observed;

  auto addRoot = [&](const std::filesystem::path &root) {
    std::filesystem::path normalized = normalizePath(root);
    if (normalized.empty())
      return;

    std::string normalizedString = normalized.string();
    if (std::find(observed.begin(), observed.end(), normalizedString) !=
        observed.end())
      return;

    observed.push_back(normalizedString);
    roots.push_back(normalized);
  };

  addRoot(workspaceDirectory_);
  for (const auto &path : searchPaths_)
    addRoot(path);
  for (const auto &path : envSearchPaths_)
    addRoot(path);

  std::error_code ec;
  for (const auto &root : roots) {
    if (!std::filesystem::exists(root, ec) ||
        !std::filesystem::is_directory(root, ec))
      continue;
    discoverNcFilesInDirectory(root);
  }
}

void ScriptManager::discoverNcFilesInDirectory(
    const std::filesystem::path &dirPath) {
  std::error_code ec;
  if (dirPath.empty())
    return;

  std::filesystem::path absDir = normalizePath(dirPath);
  if (absDir.empty() || !std::filesystem::exists(absDir, ec) ||
      !std::filesystem::is_directory(absDir, ec))
    return;

  try {
    std::vector<std::filesystem::path> foundFiles;
    for (auto it = std::filesystem::recursive_directory_iterator(
             absDir, std::filesystem::directory_options::skip_permission_denied,
             ec);
         it != std::filesystem::recursive_directory_iterator(); ++it) {
      if (ec)
        break;

      const auto &entry = *it;
      if (entry.is_directory(ec)) {
        if (shouldSkipDirectory(entry.path())) {
          it.disable_recursion_pending();
          continue;
        }
      }

      if (!entry.is_regular_file(ec))
        continue;
      if (entry.path().extension() == ".nc")
        foundFiles.push_back(entry.path());
    }

    std::sort(
        foundFiles.begin(), foundFiles.end(),
        [](const std::filesystem::path &a, const std::filesystem::path &b) {
          return a.lexically_normal().string() < b.lexically_normal().string();
        });

    for (const auto &path : foundFiles)
      indexNcFile(path);
  } catch (const std::exception &) {
    // best-effort indexing: ignore errors
  }
}

void ScriptManager::indexNcFile(const std::filesystem::path &filePath) {
  std::error_code ec;
  if (!std::filesystem::exists(filePath, ec) ||
      !std::filesystem::is_regular_file(filePath, ec))
    return;
  if (filePath.extension() != ".nc")
    return;

  std::filesystem::path absPath = normalizePath(filePath);
  if (absPath.empty())
    return;

  std::string stem = normalizeStem(absPath.filename().string());
  if (stem.empty())
    return;

  std::string pathText = absPath.string();
  auto &entries = ncFileIndex_[stem];
  if (std::find(entries.begin(), entries.end(), pathText) == entries.end())
    entries.push_back(pathText);
}

std::optional<std::string>
ScriptManager::findNcFileByStem(const std::string &stemKey) {
  if (stemKey.empty())
    return std::nullopt;

  auto it = ncFileIndex_.find(stemKey);
  if (it == ncFileIndex_.end())
    return std::nullopt;

  auto &paths = it->second;
  for (auto current = paths.begin(); current != paths.end();) {
    if (!isRegularFile(*current))
      current = paths.erase(current);
    else
      ++current;
  }

  if (paths.empty()) {
    ncFileIndex_.erase(it);
    return std::nullopt;
  }

  return paths.front();
}

std::vector<std::string>
ScriptManager::findNcFilesByStem(const std::string &stemKey) {
  std::vector<std::string> result;
  if (stemKey.empty())
    return result;

  auto it = ncFileIndex_.find(stemKey);
  if (it == ncFileIndex_.end())
    return result;

  auto &paths = it->second;
  for (auto current = paths.begin(); current != paths.end();) {
    if (!isRegularFile(*current))
      current = paths.erase(current);
    else
      ++current;
  }

  if (paths.empty()) {
    ncFileIndex_.erase(it);
    return result;
  }

  return paths;
}

// getCurrentExecutionDirectory() (SM_stage_02.cpp) is called from here -
// see the header comment for why that cross-stage call exists.
std::optional<std::string>
ScriptManager::resolveFilePath(const std::string &normalizedInput) {
  if (normalizedInput.empty())
    return std::nullopt;

  auto toAbs = [](const std::filesystem::path &p) -> std::string {
    return std::filesystem::absolute(p).lexically_normal().string();
  };

  std::filesystem::path inputPath(normalizedInput);
  bool hasDirectory = inputPath.has_parent_path();

  std::filesystem::path currentDir = getCurrentExecutionDirectory();
  std::filesystem::path workspaceDir = workspaceDirectory_;

  std::filesystem::path ncCandidate = inputPath;
  if (ncCandidate.extension() != ".nc")
    ncCandidate.replace_extension(".nc");

  // Only .nc scripts are runnable. An explicit non-.nc extension (e.g. a
  // leftover .upi path) must never resolve via the literal-input match
  // below - it may still resolve via ncCandidate if a same-stem .nc file
  // exists alongside it.
  bool inputHasAcceptableExtension =
      inputPath.extension().empty() || inputPath.extension() == ".nc";

  auto tryResolve =
      [&](const std::filesystem::path &base) -> std::optional<std::string> {
    if (base.empty())
      return std::nullopt;
    if (inputHasAcceptableExtension && isRegularFile(base / inputPath))
      return toAbs(base / inputPath);
    if (isRegularFile(base / ncCandidate))
      return toAbs(base / ncCandidate);
    return std::nullopt;
  };

  if (inputPath.is_absolute()) {
    if (inputHasAcceptableExtension && isRegularFile(inputPath))
      return toAbs(inputPath);
    if (isRegularFile(ncCandidate))
      return toAbs(ncCandidate);
    return std::nullopt;
  }

  if (auto resolved = tryResolve(currentDir))
    return resolved;
  if (auto resolved = tryResolve(workspaceDir))
    return resolved;

  for (const auto &root : searchPaths_) {
    std::filesystem::path rootPath(root);
    if (rootPath.empty())
      continue;
    std::error_code ec;
    auto absRoot = std::filesystem::absolute(rootPath, ec).lexically_normal();
    if (ec || absRoot == currentDir || absRoot == workspaceDir)
      continue;
    if (auto resolved = tryResolve(absRoot))
      return resolved;
  }

  for (const auto &root : envSearchPaths_) {
    std::filesystem::path rootPath(root);
    if (rootPath.empty())
      continue;
    std::error_code ec;
    auto absRoot = std::filesystem::absolute(rootPath, ec).lexically_normal();
    if (ec || absRoot == currentDir || absRoot == workspaceDir)
      continue;
    if (auto resolved = tryResolve(absRoot))
      return resolved;
  }

  if (!hasDirectory) {
    std::string stemKey = normalizeStem(inputPath.filename().string());
    if (!stemKey.empty()) {
      if (auto cached = findNcFileByStem(stemKey))
        return cached;

      buildNcFileIndex();
      saveCachedNcFileIndex();
      if (auto cached = findNcFileByStem(stemKey))
        return cached;
    }
  }

  return std::nullopt;
}

void ScriptManager::addPath(const std::string &path) {
  if (path.empty())
    return;

  bool added = registerSearchPath(std::filesystem::path(path));
  if (!added)
    return;

  discoverNcFilesInDirectory(std::filesystem::path(path));
  saveCachedNcFileIndex();
  saveSearchPaths();
}

void ScriptManager::removePath(const std::string &path) {
  if (path.empty())
    return;

  std::filesystem::path normalized = normalizePath(std::filesystem::path(path));
  if (normalized.empty())
    return;

  std::string normalizedString = normalized.string();
  auto it =
      std::remove(searchPaths_.begin(), searchPaths_.end(), normalizedString);
  if (it != searchPaths_.end())
    searchPaths_.erase(it, searchPaths_.end());

  saveSearchPaths();
  buildNcFileIndex();
  saveCachedNcFileIndex();
}

void ScriptManager::rehash() {
  buildNcFileIndex();
  saveCachedNcFileIndex();
}

void ScriptManager::persistCurrentDirectory() {
  if (registerSearchPath(workspaceDirectory_))
    saveSearchPaths();
}

void ScriptManager::printPath() const {
  std::cout << workspaceDirectory_.string() << "\n";
  for (const auto &path : searchPaths_) {
    if (path == workspaceDirectory_.string())
      continue;
    std::cout << path << "\n";
  }
  for (const auto &path : envSearchPaths_)
    std::cout << path << "\n";
}

void ScriptManager::printPwd() const {
  std::cout << workspaceDirectory_.string() << "\n";
}

std::filesystem::path ScriptManager::getWorkspaceDirectory() const {
  return workspaceDirectory_;
}

void ScriptManager::setWorkspaceDirectory(const std::filesystem::path &path) {
  std::filesystem::path normalized = normalizePath(path);
  if (normalized.empty())
    return;

  workspaceDirectory_ = normalized;

  // Ensure workspace folder is part of search roots
  bool added = registerSearchPath(workspaceDirectory_);
  (void)added;

  // Rebuild index and persist cache
  buildNcFileIndex();
  saveCachedNcFileIndex();

  // Persist updated search paths (while keeping preserved lines)
  saveSearchPaths();
}

std::vector<std::string>
ScriptManager::resolveAllFilesForStem(const std::string &stemKey) {
  return findNcFilesByStem(stemKey);
}

void ScriptManager::which(const std::string &name) {
  std::string normalized = trimWhitespace(name);
  if (normalized.empty()) {
    std::cout << name << " not found\n";
    return;
  }

  auto resolved = resolveFilePath(normalized);
  if (resolved)
    std::cout << normalized << " => " << *resolved << "\n";
  else
    std::cout << normalized << " not found\n";
}

void ScriptManager::whichAll(const std::string &name) {
  std::string normalized = trimWhitespace(name);
  if (normalized.empty()) {
    std::cout << name << " not found\n";
    return;
  }

  std::filesystem::path query(normalized);
  std::vector<std::string> matches;

  if (query.has_parent_path() || query.extension() == ".nc") {
    auto resolved = resolveFilePath(normalized);
    if (resolved)
      matches.push_back(*resolved);
  } else {
    std::string stemKey = normalizeStem(query.filename().string());
    matches = resolveAllFilesForStem(stemKey);
  }

  if (matches.empty()) {
    std::cout << normalized << " not found\n";
    return;
  }

  if (matches.size() == 1) {
    std::cout << matches.front() << "\n";
    return;
  }

  for (size_t index = 0; index < matches.size(); ++index)
    std::cout << (index + 1) << ". " << matches[index] << "\n";
}

void ScriptManager::loadNcPathEnv() {
  char *envValue = nullptr;
  size_t len = 0;
  if (_dupenv_s(&envValue, &len, "NC_PATH") == 0 && envValue != nullptr) {
    std::string env(envValue);
    free(envValue);
    for (const auto &entry : splitPathList(env))
      registerEnvSearchPath(std::filesystem::path(entry));
  }
}
