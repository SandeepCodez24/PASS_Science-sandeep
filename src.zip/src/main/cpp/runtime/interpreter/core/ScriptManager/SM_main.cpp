#include "SM_main.h"

#include <cctype>
#include <functional>
#include <sstream>

ScriptManager::ScriptManager(
    const std::filesystem::path &applicationDirectory,
    const std::filesystem::path &launchWorkingDirectory)
    : applicationDirectory_(normalizePath(applicationDirectory)),
      launchWorkingDirectory_(normalizePath(launchWorkingDirectory)),
      workspaceDirectory_(normalizePath(launchWorkingDirectory_)) {
  if (applicationDirectory_.empty())
    applicationDirectory_ = std::filesystem::current_path();

  searchPathsFile_ = applicationDirectory_ / "search_paths.txt";

  std::hash<std::string> hasher;
  std::ostringstream name;
  name << "nc_index_cache_" << std::hex
       << hasher(launchWorkingDirectory_.string()) << ".txt";
  cacheFile_ = applicationDirectory_ / name.str();
}

bool ScriptManager::init() {
  loadPersistentSearchPaths();
  bool workspaceAdded = registerSearchPath(workspaceDirectory_);
  loadNcPathEnv();

  bool loadedFromCache = loadCachedNcFileIndex();
  if (!loadedFromCache) {
    buildNcFileIndex();
    saveCachedNcFileIndex();
  }

  if (workspaceAdded)
    saveSearchPaths();

  return true;
}

// Public entry point tying the two stages together: resolve the input to a
// concrete .nc path (stage 1), then run it (stage 2).
bool ScriptManager::tryExecuteInputAsFile(const std::string &rawInput) {
  if (rawInput.empty())
    return false;

  // Trim
  auto trim = [](const std::string &s) -> std::string {
    size_t start = 0;
    size_t end = s.size();
    while (start < end && std::isspace(static_cast<unsigned char>(s[start])))
      ++start;
    while (end > start && std::isspace(static_cast<unsigned char>(s[end - 1])))
      --end;
    return s.substr(start, end - start);
  };

  std::string input = trim(rawInput);
  if (input.empty())
    return false;

  // Normalize optional quotes
  if (input.size() >= 2) {
    char first = input.front();
    char last = input.back();
    if ((first == '"' && last == '"') || (first == '\'' && last == '\'')) {
      input = input.substr(1, input.size() - 2);
      input = trim(input);
      if (input.empty())
        return false;
    }
  }

  auto resolved = resolveFilePath(input);
  if (!resolved)
    return false;

  executeFile(*resolved);
  return true;
}
