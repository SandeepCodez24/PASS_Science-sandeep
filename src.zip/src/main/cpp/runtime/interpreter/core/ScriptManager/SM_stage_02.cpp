// Stage 2: line-by-line execution driver. Reads a resolved .nc file and
// drives the Lexer/Parser over it, including if/for/while block
// accumulation.
#include "SM_main.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>

#include "lexer.h"
#include "parser.h"
#include "line_continuation.h"

bool ScriptManager::pathsReferToSameFile(const std::filesystem::path &a,
                                         const std::filesystem::path &b) const {
  std::error_code ec;
  if (std::filesystem::equivalent(a, b, ec))
    return true;

  return normalizePath(a) == normalizePath(b);
}

// Reads executionStack_ - see the header comment on this method for why
// SM_stage_01's resolveFilePath() also calls it.
std::filesystem::path ScriptManager::getCurrentExecutionDirectory() const {
  if (!executionStack_.empty())
    return executionStack_.back().directory;
  return std::filesystem::current_path();
}

void ScriptManager::executeFile(const std::string &absolutePath) {
  if (absolutePath.empty()) {
    std::cerr << "Error: empty path\n";
    return;
  }

  std::filesystem::path filePath =
      normalizePath(std::filesystem::path(absolutePath));
  if (!isRegularFile(filePath)) {
    std::cerr << "Error: file not found: " << absolutePath << "\n";
    return;
  }
  // the MAX_SCRIPT_DEPTH is 100, for now, it is hardcoded.
  if (executionStack_.size() >= MAX_SCRIPT_DEPTH) {
    std::cerr << "Maximum script execution depth exceeded\n";
    return;
  }

  if (std::any_of(executionStack_.begin(), executionStack_.end(),
                  [&](const ExecutionFrame &frame) {
                    return pathsReferToSameFile(frame.file, filePath);
                  })) {
    std::cerr << "Recursive execution detected\n";
    return;
  }

  std::ifstream file(filePath.string());
  if (!file.is_open()) {
    std::cerr << "Error: failed to open file: " << absolutePath << "\n";
    return;
  }

  Parser parser;
  std::filesystem::path fileDir = normalizePath(filePath.parent_path());

  bool added = registerSearchPath(fileDir);
  if (added) {
    discoverNcFilesInDirectory(fileDir);
    saveCachedNcFileIndex();
    saveSearchPaths();
  }
  // pushing the execution frame to the stack
  executionStack_.push_back(ExecutionFrame{filePath, fileDir});
  auto popFrame = [&]() {
    if (!executionStack_.empty())
      executionStack_.pop_back();
  };

  try {
    // ---- Buffer every logical line up front ----
    // Needed so the function pre-scan below (pass 1) can register a
    // function's definition before pass 2 reaches a call site that appears
    // earlier in the file — plain streaming line-by-line (the old approach)
    // can't look ahead like that. readLogicalLine's '~~' continuation-line
    // merging behaves identically either way since it still reads directly
    // off the same `file` stream per call.
    std::vector<std::string> allLines;
    {
      std::string rawLine;
      while (std::getline(file, rawLine)) {
        rawLine = readLogicalLine(file, rawLine);
        allLines.push_back(rawLine);
      }
    }

    bool anyRun = false;

    auto trimLine = [](const std::string &s) -> std::string {
      size_t a = s.find_first_not_of(" \t\r\n");
      if (a == std::string::npos) return std::string();
      size_t b = s.find_last_not_of(" \t\r\n");
      return s.substr(a, b - a + 1);
    };
    auto toLowerStr = [](std::string s) -> std::string {
      for (char &ch : s) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
      return s;
    };

    // ---- Pass 1: pre-register every top-level function/class definition ----
    // Lets a call forward-reference a function or class whose
    // 'function...fnend' / 'class...csend' block appears later in the file
    // (matches how MATLAB script-local functions behave) — the common
    // "helper functions at the bottom of the file" style. Drives the exact
    // same accumulation APIs (feedFunctionLine/isFunctionTerm/
    // executeFunctionDefEnd, feedClassLine/isClassTerm/executeClassDefEnd)
    // the live per-line dispatch in pass 2 used before functions/classes
    // moved to this pre-scan; the only difference is entering accumulation
    // mode is triggered here by a raw "starts with 'function'/'class'" line
    // check instead of the live dispatch's tokenize-and-parse, since
    // actually parsing/executing every other line here too would run the
    // whole script twice. Registering a function or class has no side
    // effects on `memory`/variables.txt, so this pass is safe to run before
    // the real execution in pass 2. A class body is itself scanned for
    // nested 'function...fnend' method blocks by executeClassDefEnd() once
    // its own 'csend' closes it — that's a separate concern from this
    // top-level scan and doesn't need anything extra here, since 'fnend'
    // and 'csend' are distinct keywords with no terminator collision.
    // Nested function/class definitions (inside an if/for/while body)
    // aren't a supported construct, so this intentionally doesn't try to
    // track if/for/while accumulation depth here — only a genuine
    // top-level header is ever recognized, same as the old single-pass
    // dispatch already assumed implicitly.
    std::vector<bool> isDefinitionLine(allLines.size(), false);
    for (size_t li = 0; li < allLines.size(); li++) {
      std::string trimmed = trimLine(allLines[li]);
      if (trimmed.empty())
        continue;
      std::string lower = toLowerStr(trimmed);

      bool isFunctionHeader = lower.rfind("function", 0) == 0 &&
          (lower.size() == 8 || std::isspace((unsigned char)lower[8]));
      bool isClassHeader = lower.rfind("class", 0) == 0 &&
          (lower.size() == 5 || std::isspace((unsigned char)lower[5]));
      // `abstract class ...` / `reversible class ...` — ABSTRACT and
      // REVERSIBLE both also start class accumulation on their own (see
      // parseStatement()'s CLASS branch, which now also fires on either
      // token, in any order/combination before the mandatory CLASS), so
      // both need to be recognized here as definition headers too.
      bool isAbstractClassHeader = lower.rfind("abstract", 0) == 0 &&
          (lower.size() == 8 || std::isspace((unsigned char)lower[8]));
      bool isReversibleClassHeader = lower.rfind("reversible", 0) == 0 &&
          (lower.size() == 10 || std::isspace((unsigned char)lower[10]));
      if (!isFunctionHeader && !isClassHeader && !isAbstractClassHeader && !isReversibleClassHeader)
        continue;

      isDefinitionLine[li] = true;
      Lexer headerLex(allLines[li]);
      auto headerToks = headerLex.tokenize();
      parser.setTokens(headerToks);
      parser.parse(); // sets inFunctionBlock_/functionHeader_ or inClassBlock_/classHeader_ only

      size_t bi = li + 1;
      if (isFunctionHeader) {
        while (bi < allLines.size() && parser.inFunctionBlock()) {
          isDefinitionLine[bi] = true;
          std::string bLower = toLowerStr(trimLine(allLines[bi]));
          if (Parser::isFunctionTerm(bLower)) {
            parser.executeFunctionDefEnd();
          } else {
            parser.feedFunctionLine(allLines[bi]);
          }
          bi++;
        }
      } else {
        while (bi < allLines.size() && parser.inClassBlock()) {
          isDefinitionLine[bi] = true;
          std::string bLower = toLowerStr(trimLine(allLines[bi]));
          if (Parser::isClassTerm(bLower)) {
            parser.executeClassDefEnd();
          } else {
            parser.feedClassLine(allLines[bi]);
          }
          bi++;
        }
      }
      li = bi - 1; // outer loop's li++ resumes right after this block
    }

    if (parser.inFunctionBlock()) {
      std::cerr << "✖ Syntax Error: unclosed function definition (expected 'fnend')\n";
      popFrame();
      return;
    }
    if (parser.inClassBlock()) {
      std::cerr << "✖ Syntax Error: unclosed class definition (expected 'csend')\n";
      popFrame();
      return;
    }

    // ---- Pass 2: execute every remaining line in order ----
    // Same-type nesting depth while accumulating a top-level if/for/while
    // block: a nested block of the *same* type shares its terminator
    // keyword with the outer one (e.g. a nested 'for' also closes on
    // 'fend'), so a flat "first terminator wins" scan would stop the outer
    // block's body capture at the inner block's terminator. These counters
    // make each accumulation mode nesting-aware for its own type, mirroring
    // the depth tracking executeBlockLines() already does for its re-scans.
    // Different-type nesting (if-in-for, for-in-while, ...) never needed
    // this since their terminator keywords don't collide.
    int ifDepth = 0;
    int forDepth = 0;
    int whileDepth = 0;

    for (size_t li = 0; li < allLines.size(); li++) {
      if (isDefinitionLine[li])
        continue; // already consumed by pass 1

      const std::string &line = allLines[li];
      if (line.find_first_not_of(" \t\r\n") == std::string::npos)
        continue;

      anyRun = true;

      // ---- If-block accumulation mode ----
      if (parser.inIfBlock()) {
        std::string trimmed = line;
        size_t s = trimmed.find_first_not_of(" \t\r\n");
        if (s != std::string::npos) trimmed = trimmed.substr(s);
        size_t e = trimmed.find_last_not_of(" \t\r\n");
        if (e != std::string::npos) trimmed = trimmed.substr(0, e + 1);

        std::string lower = trimmed;
        for (char &ch : lower)
          ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

        bool isNestedIfHeader = lower.rfind("if", 0) == 0 &&
            (lower.size() == 2 || std::isspace((unsigned char)lower[2]) || lower[2] == '(');

        if (isNestedIfHeader) {
          ifDepth++;
          parser.feedIfLine(line);
        } else if (ifDepth == 0 && (lower == "else" || lower == "else:")) {
          parser.setElseBranch();
        } else if (ifDepth == 0 && lower.rfind("elseif", 0) == 0 &&
                   (lower.size() == 6 || std::isspace((unsigned char)lower[6]))) {
          parser.setElseifBranch(trimmed);
        } else if (Parser::isIfTerm(lower)) {
          if (ifDepth > 0) {
            ifDepth--;
            parser.feedIfLine(line);
          } else {
            parser.executeIfBlock();
            // A top-level `return;`/failed require-ensure inside this if
            // must stop the script here, same as the normal-line case below.
            if (parser.consumeTopLevelStopSignal())
              break;
          }
        } else {
          parser.feedIfLine(line);
        }
        continue;
      }

      // ---- For-loop block accumulation mode ----
      if (parser.inForBlock()) {
        // Check if this line is a for-block terminator
        std::string trimmed = line;
        size_t s = trimmed.find_first_not_of(" \t\r\n");
        if (s != std::string::npos) trimmed = trimmed.substr(s);
        size_t e = trimmed.find_last_not_of(" \t\r\n");
        if (e != std::string::npos) trimmed = trimmed.substr(0, e + 1);

        // Convert to lower for keyword check
        std::string lower = trimmed;
        for (char &ch : lower)
          ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

        bool isNestedForHeader = lower.rfind("for", 0) == 0 &&
            (lower.size() == 3 || std::isspace((unsigned char)lower[3]));

        if (isNestedForHeader) {
          forDepth++;
          parser.feedForLine(line);
        } else if (Parser::isForTerm(lower)) {
          if (forDepth > 0) {
            forDepth--;
            parser.feedForLine(line);
          } else {
            parser.executeForBlock();
            if (parser.consumeTopLevelStopSignal())
              break;
          }
        } else {
          parser.feedForLine(line);
        }
        continue;
      }

      // ---- While-loop block accumulation mode ----
      if (parser.inWhileBlock()) {
        std::string trimmed = line;
        size_t s = trimmed.find_first_not_of(" \t\r\n");
        if (s != std::string::npos) trimmed = trimmed.substr(s);
        size_t e = trimmed.find_last_not_of(" \t\r\n");
        if (e != std::string::npos) trimmed = trimmed.substr(0, e + 1);

        std::string lower = trimmed;
        for (char &ch : lower)
          ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

        bool isNestedWhileHeader = lower.rfind("while", 0) == 0 &&
            (lower.size() == 5 || std::isspace((unsigned char)lower[5]) || lower[5] == '(');

        if (isNestedWhileHeader) {
          whileDepth++;
          parser.feedWhileLine(line);
        } else if (Parser::isWhileTerm(lower)) {
          if (whileDepth > 0) {
            whileDepth--;
            parser.feedWhileLine(line);
          } else {
            parser.executeWhileBlock();
            if (parser.consumeTopLevelStopSignal())
              break;
          }
        } else {
          parser.feedWhileLine(line);
        }
        continue;
      }

      // No function-block accumulation branch here — pass 1 above already
      // consumed and registered every top-level function definition, so a
      // 'function' header line can never reach this dispatch in pass 2.

      // ---- Normal single-line execution ----
      Lexer lexer(line);
      auto tokens = lexer.tokenize();

      if (tokens.size() <= 1)
        continue;

      parser.setTokens(tokens);
      parser.parse();

      // After parsing, parser may have entered for-block mode
      // (header line was "for i = [0:5]") — loop will accumulate body next

      // A top-level `return;` (or a failed `require`/`ensure`) stops the
      // rest of this script — must be checked (and cleared) after every
      // top-level line regardless, or a stale signal would corrupt the
      // first-iteration check of a later, unrelated for/while loop.
      if (parser.consumeTopLevelStopSignal())
        break;
    }

    if (parser.inIfBlock()) {
      std::cerr << "✖ Syntax Error: unclosed 'if' statement (expected 'end', 'endif', or 'iend')\n";
    }
    if (parser.inForBlock()) {
      std::cerr << "✖ Syntax Error: unclosed 'for' loop (expected 'loop end', 'endfor', or 'fend')\n";
    }
    // (no inFunctionBlock() check here — pass 1 above already checked and
    // would have returned early on an unclosed function definition)
    if (parser.inWhileBlock()) {
      std::cerr << "✖ Syntax Error: unclosed 'while' loop (expected 'loop end', 'endwhile', 'end', or 'wend')\n";
    }

    (void)anyRun;
  } catch (const std::exception &e) {
    std::cerr << "Runtime error in " << filePath.string() << ": " << e.what()
              << "\n";
  }

  popFrame();
}
