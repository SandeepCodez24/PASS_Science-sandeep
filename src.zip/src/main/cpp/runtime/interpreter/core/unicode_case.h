// Upper / lower case for UTF-8 text (2026-11-18).
//
// lower(), upper() and swapcase() used to change ASCII letters only, so
// lower("ΑΒΓ") and upper("é") came back unchanged. This maps the cased
// letters of the scripts NC text is written in: Basic Latin, Latin-1,
// Latin Extended-A, Latin Extended Additional (Vietnamese), Greek (with the
// final sigma), Cyrillic, Armenian and full-width Latin. Scripts without
// case (Tamil, Devanagari, CJK ...) pass through unchanged, as does any
// byte sequence that is not valid UTF-8.
//
// One-to-one mappings, except ß, whose upper case is "SS" (as in Python).
#ifndef NC_UNICODE_CASE_H
#define NC_UNICODE_CASE_H

#include <cstdint>
#include <string>
#include <vector>

namespace nc {
namespace textcase {

// Upper-case partner of a lower-case letter, or 0.
inline uint32_t upperOf(uint32_t c) {
  if (c >= 'a' && c <= 'z') return c - 0x20;
  if (c >= 0xE0 && c <= 0xFE && c != 0xF7) return c - 0x20; // à..þ (not ÷)
  if (c == 0xFF) return 0x178;                              // ÿ -> Ÿ
  if (c >= 0x100 && c <= 0x17F) {                           // Latin Extended-A
    if (c == 0x131) return 'I';                             // dotless ı
    if (c == 0x17F) return 'S';                             // long s
    if ((c >= 0x101 && c <= 0x12F) || (c >= 0x133 && c <= 0x137) || (c >= 0x14B && c <= 0x177))
      return (c & 1) ? c - 1 : 0;
    if ((c >= 0x13A && c <= 0x148) || (c >= 0x17A && c <= 0x17E))
      return (c & 1) ? 0 : c - 1;
    return 0;
  }
  if (c >= 0x3B1 && c <= 0x3C9) return c == 0x3C2 ? 0x3A3 : c - 0x20; // α..ω, ς -> Σ
  if (c == 0x3AC) return 0x386;
  if (c >= 0x3AD && c <= 0x3AF) return c - 0x25;
  if (c == 0x3CC) return 0x38C;
  if (c == 0x3CD || c == 0x3CE) return c - 0x3F;
  if (c >= 0x430 && c <= 0x44F) return c - 0x20; // а..я
  if (c >= 0x450 && c <= 0x45F) return c - 0x50; // ѐ..џ
  if ((c >= 0x461 && c <= 0x481) || (c >= 0x48B && c <= 0x4BF) || (c >= 0x4D1 && c <= 0x4FF))
    return (c & 1) ? c - 1 : 0;
  if (c >= 0x561 && c <= 0x586) return c - 0x30; // Armenian
  if ((c >= 0x1E01 && c <= 0x1E95) || (c >= 0x1EA1 && c <= 0x1EFF))
    return (c & 1) ? c - 1 : 0;
  if (c >= 0xFF41 && c <= 0xFF5A) return c - 0x20; // full-width a..z
  return 0;
}

// Lower-case partner of an upper-case letter, or 0.
inline uint32_t lowerOf(uint32_t c) {
  if (c >= 'A' && c <= 'Z') return c + 0x20;
  if (c >= 0xC0 && c <= 0xDE && c != 0xD7) return c + 0x20; // À..Þ (not ×)
  if (c == 0x178) return 0xFF;
  if (c >= 0x100 && c <= 0x17F) {
    if (c == 0x130) return 'i'; // İ
    if ((c >= 0x100 && c <= 0x12E) || (c >= 0x132 && c <= 0x136) || (c >= 0x14A && c <= 0x176))
      return (c & 1) ? 0 : c + 1;
    if ((c >= 0x139 && c <= 0x147) || (c >= 0x179 && c <= 0x17D))
      return (c & 1) ? c + 1 : 0;
    return 0;
  }
  if (c >= 0x391 && c <= 0x3A9 && c != 0x3A2) return c + 0x20; // Α..Ω
  if (c == 0x386) return 0x3AC;
  if (c >= 0x388 && c <= 0x38A) return c + 0x25;
  if (c == 0x38C) return 0x3CC;
  if (c == 0x38E || c == 0x38F) return c + 0x3F;
  if (c >= 0x410 && c <= 0x42F) return c + 0x20;
  if (c >= 0x400 && c <= 0x40F) return c + 0x50;
  if ((c >= 0x460 && c <= 0x480) || (c >= 0x48A && c <= 0x4BE) || (c >= 0x4D0 && c <= 0x4FE))
    return (c & 1) ? 0 : c + 1;
  if (c >= 0x531 && c <= 0x556) return c + 0x30;
  if ((c >= 0x1E00 && c <= 0x1E94) || (c >= 0x1EA0 && c <= 0x1EFE))
    return (c & 1) ? 0 : c + 1;
  if (c >= 0xFF21 && c <= 0xFF3A) return c + 0x20;
  return 0;
}

inline bool isCased(uint32_t c) { return upperOf(c) || lowerOf(c) || c == 0xDF; }

// UTF-8 -> code points. False if `s` is not valid UTF-8.
inline bool decodeUtf8(const std::string &s, std::vector<uint32_t> &out) {
  out.clear();
  for (size_t i = 0; i < s.size();) {
    const unsigned char b = static_cast<unsigned char>(s[i]);
    int n = b < 0x80 ? 1 : (b >> 5) == 6 ? 2 : (b >> 4) == 14 ? 3 : (b >> 3) == 30 ? 4 : 0;
    if (n == 0 || i + n > s.size()) return false;
    uint32_t c = n == 1 ? b : n == 2 ? (b & 0x1F) : n == 3 ? (b & 0x0F) : (b & 0x07);
    for (int k = 1; k < n; k++) {
      const unsigned char x = static_cast<unsigned char>(s[i + k]);
      if ((x >> 6) != 2) return false;
      c = (c << 6) | (x & 0x3F);
    }
    out.push_back(c);
    i += static_cast<size_t>(n);
  }
  return true;
}

inline void appendUtf8(std::string &s, uint32_t c) {
  if (c < 0x80) {
    s.push_back(static_cast<char>(c));
  } else if (c < 0x800) {
    s.push_back(static_cast<char>(0xC0 | (c >> 6)));
    s.push_back(static_cast<char>(0x80 | (c & 0x3F)));
  } else if (c < 0x10000) {
    s.push_back(static_cast<char>(0xE0 | (c >> 12)));
    s.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F)));
    s.push_back(static_cast<char>(0x80 | (c & 0x3F)));
  } else {
    s.push_back(static_cast<char>(0xF0 | (c >> 18)));
    s.push_back(static_cast<char>(0x80 | ((c >> 12) & 0x3F)));
    s.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F)));
    s.push_back(static_cast<char>(0x80 | (c & 0x3F)));
  }
}

// mode 0: lower case, 1: upper case, 2: swap.
inline std::string changeCase(const std::string &s, int mode) {
  std::vector<uint32_t> cps;
  if (!decodeUtf8(s, cps)) { // not UTF-8: ASCII letters only, bytes kept
    std::string r = s;
    for (char &ch : r) {
      const unsigned char c = static_cast<unsigned char>(ch);
      if (c < 0x80) {
        const uint32_t up = upperOf(c), lo = lowerOf(c);
        if ((mode == 1 || mode == 2) && up) ch = static_cast<char>(up);
        else if ((mode == 0 || mode == 2) && lo) ch = static_cast<char>(lo);
      }
    }
    return r;
  }
  std::string out;
  out.reserve(s.size());
  for (size_t i = 0; i < cps.size(); i++) {
    const uint32_t c = cps[i];
    const uint32_t up = upperOf(c), lo = lowerOf(c);
    const bool toUpper = mode == 1 || (mode == 2 && up);
    const bool toLower = mode == 0 || (mode == 2 && lo);
    if (toUpper && c == 0xDF) { // ß -> SS
      out += "SS";
    } else if (toUpper && up) {
      appendUtf8(out, up);
    } else if (toLower && c == 0x3A3) {
      // Σ: final ς at the end of a word (a cased letter before it, none after)
      const bool before = i > 0 && isCased(cps[i - 1]);
      const bool after = i + 1 < cps.size() && isCased(cps[i + 1]);
      appendUtf8(out, before && !after ? 0x3C2 : 0x3C3);
    } else if (toLower && lo) {
      appendUtf8(out, lo);
    } else {
      appendUtf8(out, c);
    }
  }
  return out;
}

} // namespace textcase
} // namespace nc

#endif // NC_UNICODE_CASE_H
