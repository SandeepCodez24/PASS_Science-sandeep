#ifndef LINENOISE_H
#define LINENOISE_H
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct linenoiseCompletions {
    size_t len;
    char **cvec;
} linenoiseCompletions;

typedef void(linenoiseCompletionCallback)(const char *, linenoiseCompletions *);

void linenoiseSetCompletionCallback(linenoiseCompletionCallback *);
void linenoiseAddCompletion(linenoiseCompletions *, const char *);

char *linenoise(const char *prompt);
void linenoiseFree(void *ptr);
int linenoiseHistoryAdd(const char *line);

#ifdef __cplusplus
}
#endif

#endif