#include "linenoise.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static linenoiseCompletionCallback *completionCallback = NULL;

void linenoiseSetCompletionCallback(linenoiseCompletionCallback *fn) {
    completionCallback = fn;
}

void linenoiseAddCompletion(linenoiseCompletions *lc, const char *str) {
    lc->cvec = (char**)realloc(lc->cvec, sizeof(char*) * (lc->len + 1));
    lc->cvec[lc->len] = strdup(str);
    lc->len++;
}

static void showCompletions(const char *buf) {

    linenoiseCompletions lc = {0,NULL};

    if(completionCallback)
        completionCallback(buf,&lc);

    if(lc.len==0)
        return;

    printf("\n");

    for(size_t i=0;i<lc.len;i++)
        printf("%s\n",lc.cvec[i]);

    printf("> %s",buf);
    fflush(stdout);
}

char *linenoise(const char *prompt)
{
    static char buffer[1024];
    int len = 0;

    printf("%s",prompt);
    fflush(stdout);

    while(1)
    {
        int c = getchar();

        if(c=='\n')
        {
            buffer[len]='\0';
            printf("\n");
            return strdup(buffer);
        }

        if(c=='\t' || c==' ')
        {
            buffer[len]='\0';
            showCompletions(buffer);
            continue;
        }

        if(len < sizeof(buffer)-1)
        {
            buffer[len++]=c;
            putchar(c);
            fflush(stdout);
        }
    }
}

void linenoiseFree(void *ptr) {
    free(ptr);
}

int linenoiseHistoryAdd(const char *line) {
    return 1;
}