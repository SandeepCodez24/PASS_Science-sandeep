// Units through built-in functions - see units.h.
#include "units.h"

#include <cmath>
#include <iostream>
#include <limits>
#include <sstream>
#include <unordered_set>

namespace nc {
namespace units {

namespace {

bool fits(int x) {
  return x >= std::numeric_limits<int16_t>::min() && x <= std::numeric_limits<int16_t>::max();
}

// Elements in an argument (prod: the unit to that power).
size_t elementCount(const Value &v) {
  if (v.isND())
    return v.ndCount();
  if (v.isMatrix)
    return v.rows() * v.cols();
  if (v.isArray)
    return v.length();
  return 1;
}

std::string unitName(const Dim &d) { return d.zero() ? std::string("no unit") : text(d); }

void report(const std::string &message) { std::cerr << "Error: " << message << "\n"; }

// The result unit when every exponent is multiplied by p (a whole result is
// required). False with the error printed.
bool scaled(const std::string &what, const Dim &u, double p, Dim &out) {
  const double l = u.l * p, t = u.t * p, m = u.m * p;
  auto whole = [](double x) { return std::fabs(x - std::round(x)) < 1e-9; };
  if (!whole(l) || !whole(t) || !whole(m)) {
    std::ostringstream ss;
    ss << what << " of a value in " << text(u) << " has no unit with whole exponents (" << text(u) << "^" << p
       << ") - units take whole exponents only";
    report(ss.str());
    return false;
  }
  out = {static_cast<int>(std::lround(l)), static_cast<int>(std::lround(t)), static_cast<int>(std::lround(m))};
  return true;
}

enum class Kind { Other, Keep, Square, Root2, Root3, Pow2, Pow3, Prod, Product2, Unitless, Ratio };

Kind kindOf(const std::string &name) {
  static const std::unordered_set<std::string> keep = {
      "abs", "absolute", "fabs", "round", "floor", "ceil", "fix", "trunc", "rint",
      "sort", "sort_asc", "sort_desc", "flip", "fliplr", "flipud", "rot90", "reshape", "transpose",
      "unique", "max", "min", "maximum", "minimum", "nan_max", "nan_min", "sum", "nan_sum",
      "cumsum", "nan_cumsum", "cumulative_sum", "mean", "nan_mean", "average", "median",
      "nan_median", "mode", "trim_mean", "range", "ptp", "sd", "psd", "std", "nan_sd",
      "std_error", "iqr", "mad", "percentile", "nan_percentile", "quantile", "nan_quantile",
      "norm", "l2norm", "hypot", "clip", "real", "imag", "conj", "conjugate", "diff",
      "cummax", "cummin", "repeat", "tile", "concat", "hstack", "vstack", "row_stack",
      "column_stack", "stack", "take", "roll", "negative", "positive"};
  static const std::unordered_set<std::string> square = {"var", "pvar", "nan_var", "variance"};
  static const std::unordered_set<std::string> product2 = {"dot", "vdot", "inner", "cross", "kron",
                                                           "outer", "matmul", "mtimes"};
  static const std::unordered_set<std::string> unitless = {
      "sin", "cos", "tan", "cot", "sec", "cosec", "csc", "arcsin", "arccos", "arctan", "asin",
      "acos", "atan", "sinh", "cosh", "tanh", "coth", "sech", "csch", "cosech", "arcsinh",
      "arccosh", "arctanh", "asinh", "acosh", "atanh", "exp", "exp2", "expm1", "log", "ln",
      "log10", "log2", "log1p", "gamma", "lgamma", "erf", "erfc", "factorial", "sigmoid",
      "deg2rad", "rad2deg", "degrees", "radians", "sinc"};
  if (keep.count(name)) return Kind::Keep;
  if (square.count(name)) return Kind::Square;
  if (name == "sqrt") return Kind::Root2;
  if (name == "cbrt") return Kind::Root3;
  if (name == "sqr" || name == "square") return Kind::Pow2;
  if (name == "cube") return Kind::Pow3;
  if (name == "prod" || name == "nan_prod") return Kind::Prod;
  if (product2.count(name)) return Kind::Product2;
  if (unitless.count(name)) return Kind::Unitless;
  if (name.rfind("logb", 0) == 0) return Kind::Unitless;
  if (name == "atan2" || name == "arctan2") return Kind::Ratio;
  return Kind::Other;
}

} // namespace

std::string text(const Dim &d) {
  auto part = [](std::vector<std::string> &parts, const char *symbol, int exp) {
    if (exp == 0) return;
    parts.push_back(exp == 1 ? symbol : (std::string(symbol) + "^" + std::to_string(exp)));
  };
  std::vector<std::string> num, den;
  auto classify = [&](const char *symbol, int exp) {
    if (exp > 0) part(num, symbol, exp);
    else if (exp < 0) part(den, symbol, -exp);
  };
  classify("m", d.l);
  classify("s", d.t);
  classify("kg", d.m);
  std::string s;
  for (size_t i = 0; i < num.size(); i++) s += (i ? "*" : "") + num[i];
  if (num.empty()) s = "1";
  if (!den.empty()) {
    s += "/";
    for (size_t i = 0; i < den.size(); i++) s += (i ? "*" : "") + den[i];
  }
  return s;
}

bool attach(Value &v, const Dim &d, std::string &err) {
  if (!fits(d.l) || !fits(d.t) || !fits(d.m)) {
    err = "the unit exponents are too large";
    return false;
  }
  v.setUnitDims(static_cast<int16_t>(d.l), static_cast<int16_t>(d.t), static_cast<int16_t>(d.m));
  return true;
}

Call builtinCall(const std::string &name, const std::vector<Value> &args, Value &out,
                 const std::function<Value(const std::vector<Value> &)> &call,
                 const std::vector<std::string> *argNames) {
  const Kind kind = kindOf(name);
  if (kind == Kind::Other)
    return Call::PassThrough;

  // The unit of the first argument that has one, and whether all agree.
  Dim u;
  bool found = false, agree = true;
  for (const Value &a : args) {
    if (!a.hasUnit())
      continue;
    const Dim d = unitOf(a);
    if (!found) {
      u = d;
      found = true;
    } else if (d != u) {
      agree = false;
    }
  }
  const Dim first = args.empty() ? Dim{} : unitOf(args[0]);

  Dim result;
  switch (kind) {
  case Kind::Unitless:
    report(name + " needs a value without a unit - this one is in " + text(u) +
           " (divide by a unit first, e.g. x / " + text(u) + ")");
    return Call::Refused;
  case Kind::Ratio:
    if (args.size() < 2 || unitOf(args[0]) != unitOf(args[1])) {
      report(name + "(y, x) needs y and x in the same unit - got " + unitName(unitOf(args[0])) + " and " +
             unitName(args.size() > 1 ? unitOf(args[1]) : Dim{}));
      return Call::Refused;
    }
    result = Dim{};
    break;
  case Kind::Keep: {
    // Which inputs are quantities that must share the first one's unit:
    //  - max / min / hypot / clip: every value given in order (max(3 m, 2)
    //    compares a length with a plain number - refused);
    //  - concat and the stacking functions: every array / matrix (a single
    //    number there is an axis);
    //  - anything else: only inputs that have a unit (digits, counts,
    //    percentages and shapes after the first input have none).
    // Inputs given by name (axis=0, q=50) are never quantities.
    static const std::unordered_set<std::string> allValues = {"max", "min", "maximum", "minimum",
                                                              "hypot", "clip"};
    static const std::unordered_set<std::string> allContainers = {"concat", "hstack", "vstack", "row_stack",
                                                                  "column_stack", "stack"};
    bool ok = true;
    std::string units;
    for (size_t i = 0; i < args.size(); i++) {
      const Value &a = args[i];
      const bool named = argNames && i < argNames->size() && !(*argNames)[i].empty();
      if (named || a.isText || a.isDict || a.isObject || a.isFunctionRef)
        continue;
      bool quantity = i == 0 || a.hasUnit();
      if (allValues.count(name))
        quantity = true;
      else if (allContainers.count(name) && (a.isArray || a.isMatrix))
        quantity = true;
      if (!quantity)
        continue;
      units += (units.empty() ? "" : ", ") + unitName(unitOf(a));
      if (unitOf(a) != u)
        ok = false;
    }
    if (!ok) {
      report(name + ": the values have different units (" + units + ")");
      return Call::Refused;
    }
    result = u;
    break;
  }
  case Kind::Square:
    if (first != u || !agree) {
      report(name + " takes one quantity - its other inputs have no unit");
      return Call::Refused;
    }
    result = {2 * u.l, 2 * u.t, 2 * u.m};
    break;
  case Kind::Root2:
    if (!scaled(name, u, 0.5, result)) return Call::Refused;
    break;
  case Kind::Root3:
    if (!scaled(name, u, 1.0 / 3.0, result)) return Call::Refused;
    break;
  case Kind::Pow2:
    result = {2 * u.l, 2 * u.t, 2 * u.m};
    break;
  case Kind::Pow3:
    result = {3 * u.l, 3 * u.t, 3 * u.m};
    break;
  case Kind::Prod: {
    if (args.size() != 1) {
      report(name + " of values with a unit takes the values alone (the unit of the result depends on how many are multiplied)");
      return Call::Refused;
    }
    const double n = static_cast<double>(elementCount(args[0]));
    if (!scaled(name, u, n, result)) return Call::Refused;
    break;
  }
  case Kind::Product2: {
    Dim a = args.size() > 0 ? unitOf(args[0]) : Dim{}, b = args.size() > 1 ? unitOf(args[1]) : Dim{};
    result = {a.l + b.l, a.t + b.t, a.m + b.m};
    break;
  }
  case Kind::Other:
    return Call::PassThrough;
  }

  std::vector<Value> plain;
  plain.reserve(args.size());
  for (const Value &a : args)
    plain.push_back(stripped(a));
  out = call(plain);
  // A failed call has printed its own error; the caller checks its flags.
  if (out.isText || out.isDict || out.isObject || out.isBool())
    return Call::Done;
  std::string err;
  if (!attach(out, result, err)) {
    report(name + ": " + err);
    return Call::Refused;
  }
  return Call::Done;
}

} // namespace units
} // namespace nc
