#pragma once

// Reading the elements of a packed tensor by storage index without building
// anything (2026-11-20, docs/Java_Speed_CPP_Asks.md "C++ session record"):
//
//   - a lazy range (NumTensor::pending) is read from its rule, so a cast or
//     a Variable Explorer window over [-pi:1e-8:pi] never builds its 5 GB;
//   - a typed tensor (int8 ... uint64, bool, float32/16/8) is read straight
//     from its raw bytes, integers with their exact bits;
//   - no Value is made per element (32 bytes each: 628 million of them were
//     20 GB, which is what made float16(A) on a 1 x 628318531 row page the
//     machine to death).
//
// Thread safety: every reader method is const and touches only memory that
// does not change while the reader lives, so nc::par blocks may share one.

#include <cstdint>
#include <cstring>
#include <vector>

#include "value.h"

namespace ncpacked {

// Element k of a typed buffer: its exact integer bits (integers and bools)
// and its value as a double (every type). Same decoding as Value::typedBits().
inline void typedElement(ElemType t, const uint8_t *raw, size_t k, int64_t &bits, double &x) {
  const uint8_t *p = raw + k * elemTypeBytes(t);
  switch (t) {
  case ElemType::I8: { int8_t v; std::memcpy(&v, p, 1); bits = v; x = v; return; }
  case ElemType::I16: { int16_t v; std::memcpy(&v, p, 2); bits = v; x = v; return; }
  case ElemType::I32: { int32_t v; std::memcpy(&v, p, 4); bits = v; x = v; return; }
  case ElemType::I64: { int64_t v; std::memcpy(&v, p, 8); bits = v; x = static_cast<double>(v); return; }
  case ElemType::U8: { bits = *p; x = *p; return; }
  case ElemType::U16: { uint16_t v; std::memcpy(&v, p, 2); bits = v; x = v; return; }
  case ElemType::U32: { uint32_t v; std::memcpy(&v, p, 4); bits = v; x = v; return; }
  case ElemType::U64: { uint64_t v; std::memcpy(&v, p, 8); bits = static_cast<int64_t>(v); x = static_cast<double>(v); return; }
  case ElemType::F32: bits = 0; x = ncfloat::loadF32(p); return;
  case ElemType::F16: bits = 0; x = ncfloat::loadF16(p); return;
  case ElemType::F8: bits = 0; x = ncfloat::loadF8(p); return;
  case ElemType::Bool: { bits = *p != 0; x = *p != 0 ? 1.0 : 0.0; return; }
  case ElemType::F64: break;
  }
  bits = 0;
  x = 0;
}

inline bool isIntElem(ElemType t) {
  return t == ElemType::I8 || t == ElemType::I16 || t == ElemType::I32 || t == ElemType::I64 ||
         t == ElemType::U8 || t == ElemType::U16 || t == ElemType::U32 || t == ElemType::U64;
}
inline bool isUnsignedElem(ElemType t) {
  return t == ElemType::U8 || t == ElemType::U16 || t == ElemType::U32 || t == ElemType::U64;
}

// A REAL packed tensor of any rank: float64 (lazy or built) or typed.
// open() is false for anything else: cells, columnar tables, complex, empty.
class RealReader {
public:
  bool open(const Value &v) {
    if (!(v.isArray || v.isMatrix))
      return false;
    if (v.isPacked()) {
      etype_ = ElemType::F64;
      lazy_ = v.lazyTensor(); // a range, maybe with an arithmetic chain (2026-11-21)
      buf_ = lazy_ ? nullptr : v.packedData(); // already built: no work
    } else if (v.isTypedPacked()) {
      etype_ = v.elemType();
      raw_ = v.typedData();
    } else {
      return false;
    }
    shape_ = &v.tensorShape();
    count_ = 1;
    for (size_t d : *shape_)
      count_ *= d;
    v.unitDims(dimL_, dimT_, dimM_);
    return count_ > 0;
  }

  ElemType etype() const { return etype_; }
  bool typed() const { return etype_ != ElemType::F64; }
  size_t count() const { return count_; }
  const std::vector<size_t> &shape() const { return *shape_; }
  int16_t dimL() const { return dimL_; }
  int16_t dimT() const { return dimT_; }
  int16_t dimM() const { return dimM_; }

  // Element k (storage order) as a double.
  double at(size_t k) const {
    if (etype_ == ElemType::F64)
      return lazy_ ? lazy_->lazyValue(k) : buf_[k];
    int64_t bits;
    double x;
    typedElement(etype_, raw_, k, bits, x);
    return x;
  }
  // Typed only: element k's exact bits and value.
  void bitsAt(size_t k, int64_t &bits, double &x) const { typedElement(etype_, raw_, k, bits, x); }

private:
  ElemType etype_ = ElemType::F64;
  const NumTensor *lazy_ = nullptr; // never changes while lazy, even if built meanwhile
  const double *buf_ = nullptr;
  const uint8_t *raw_ = nullptr;
  const std::vector<size_t> *shape_ = nullptr;
  size_t count_ = 0;
  int16_t dimL_ = 0, dimT_ = 0, dimM_ = 0;
};

} // namespace ncpacked
