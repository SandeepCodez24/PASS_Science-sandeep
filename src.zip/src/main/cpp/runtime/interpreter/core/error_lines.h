#pragma once

// Counts the error lines written to std::cerr.
//
// An error stops the script (Parser::errorAbort_), which needs to know that
// a statement failed. Most code says so through evaluationSucceeded_ or one
// of the per-domain flags (g_lastBuiltinFound, g_lastDcOk, ...), but some
// builtins only print their message and return 0 - and that 0 then flowed on
// into the rest of the script as if it were a real result. Every error
// message starts with "Error" or "✖" (a categorised "✖ Syntax Error ..."),
// so counting those lines catches every one of them: a statement or builtin
// call during which the count went up has failed, whatever flags it set.
//
// install() wraps std::cerr's buffer once, at start-up (main.cpp). Text still
// goes to the original buffer unchanged; only the count is added. Before
// install() is called, count() simply stays 0.
//
// Capture (2026-11-09, try ... except ... tend): while a `try` body runs,
// beginCapture() holds back the ERROR lines written to std::cerr instead of
// printing them, so an error the try block handles never reaches the screen.
// Every other line (a warning, a report) still goes straight through. The
// count goes up exactly as before - that is how the statement that failed
// knows it failed. endCapture() then either forgives the held-back lines
// (the error was handled: the count goes back to where the capture began,
// so the statement around the try block does not fail) or lets them through
// unchanged (nobody handled it). Captures nest: an inner try's unhandled
// lines go to the outer try's capture. With no capture active, nothing here
// changes how std::cerr behaves.

#include <iostream>
#include <streambuf>
#include <string>
#include <vector>

namespace nc {
namespace errorlines {

class CountingBuf : public std::streambuf {
public:
  explicit CountingBuf(std::streambuf *dest) : dest_(dest) {}
  unsigned long count() const { return count_; }

  /* ---- capture (see the comment at the top of this file) ---- */

  void beginCapture() {
    flushLine(); // a half-written line belongs to whoever wrote it before
    heldLast_ = false;
    frames_.push_back(Frame{count_, std::string()});
  }
  // The error lines held back by the innermost capture so far.
  const std::string &capturedText() const {
    static const std::string kNone;
    return frames_.empty() ? kNone : frames_.back().text;
  }
  // Ends the innermost capture. handled: the held-back lines are dropped and
  // the count returns to where the capture began. Otherwise they are written
  // on (to the enclosing capture, or the screen) and stay counted.
  void endCapture(bool handled) {
    if (frames_.empty())
      return;
    flushLine();
    Frame frame = frames_.back();
    frames_.pop_back();
    if (handled)
      count_ = frame.countAtStart;
    else
      emit(frame.text);
  }
  bool capturing() const { return !frames_.empty(); }

protected:
  int overflow(int ch) override {
    if (ch == traits_type::eof())
      return traits_type::not_eof(ch);
    if (!frames_.empty()) {
      captureChar(static_cast<char>(ch));
      return ch;
    }
    track(static_cast<char>(ch));
    return dest_->sputc(static_cast<char>(ch));
  }
  std::streamsize xsputn(const char *s, std::streamsize n) override {
    if (!frames_.empty()) {
      for (std::streamsize i = 0; i < n; i++)
        captureChar(s[i]);
      return n;
    }
    for (std::streamsize i = 0; i < n; i++)
      track(s[i]);
    return dest_->sputn(s, n);
  }
  int sync() override { return dest_->pubsync(); }

private:
  struct Frame {
    unsigned long countAtStart;
    std::string text; // the error lines held back so far
  };

  // Capture mode: whole lines are collected, then sent on (not an error) or
  // held back (an error line - track() counted it - or an indented line
  // straight after one, such as "  caused by: ...", which belongs to it).
  void captureChar(char c) {
    const unsigned long before = count_;
    track(c);
    if (count_ != before)
      lineIsError_ = true;
    line_ += c;
    if (c == '\n')
      flushLine();
  }
  void flushLine() {
    if (line_.empty())
      return;
    const bool continues = heldLast_ && (line_[0] == ' ' || line_[0] == '\t');
    if ((lineIsError_ || continues) && !frames_.empty()) {
      frames_.back().text += line_;
      heldLast_ = true;
    } else {
      dest_->sputn(line_.data(), static_cast<std::streamsize>(line_.size()));
      heldLast_ = false;
    }
    line_.clear();
    lineIsError_ = false;
  }
  // Text already counted, passed on without counting it again.
  void emit(const std::string &text) {
    if (text.empty())
      return;
    if (!frames_.empty())
      frames_.back().text += text;
    else
      dest_->sputn(text.data(), static_cast<std::streamsize>(text.size()));
  }

  std::vector<Frame> frames_;
  std::string line_;
  bool lineIsError_ = false;
  bool heldLast_ = false; // the last finished line was held back

  // Looks at the start of each line only: leading spaces skipped, then
  // "Error" or the UTF-8 bytes of "✖" (E2 9C 96).
  void track(char c) {
    if (c == '\n') {
      start_.clear();
      decided_ = false;
      return;
    }
    if (decided_)
      return;
    if (start_.empty() && (c == ' ' || c == '\t'))
      return;
    start_ += c;
    static const std::string kError = "Error";
    static const std::string kCross = "\xE2\x9C\x96";
    for (const std::string *word : {&kError, &kCross}) {
      if (start_.size() <= word->size() && word->compare(0, start_.size(), start_) == 0) {
        if (start_.size() == word->size()) {
          count_++;
          decided_ = true;
        }
        return; // still a possible match
      }
    }
    decided_ = true; // neither word: not an error line
  }

  std::streambuf *dest_;
  std::string start_;
  bool decided_ = false;
  unsigned long count_ = 0;
};

inline CountingBuf *&installed() {
  static CountingBuf *buf = nullptr;
  return buf;
}

// Wraps std::cerr (once; later calls do nothing).
inline void install() {
  if (installed())
    return;
  static CountingBuf buf(std::cerr.rdbuf());
  std::cerr.rdbuf(&buf);
  installed() = &buf;
}

// Error lines written so far (0 until install()).
inline unsigned long count() { return installed() ? installed()->count() : 0; }

// Capture for a try block (see the comment at the top of this file). Without
// install() there is nothing to capture: the error lines are simply printed.
inline void beginCapture() {
  if (installed())
    installed()->beginCapture();
}
inline std::string capturedText() {
  return installed() ? installed()->capturedText() : std::string();
}
inline void endCapture(bool handled) {
  if (installed())
    installed()->endCapture(handled);
}

// Set when a script was refused for syntax errors or stopped on an error
// ("the script was not run" / "the script stopped here"). `nc.exe file.nc`
// then exits with code 1 instead of 0 (2026-11-18), so a batch run or CI job
// can tell a failed script from a finished one.
inline bool &scriptFailed() {
  static bool failed = false;
  return failed;
}

} // namespace errorlines
} // namespace nc
