/* ================= PRINT ================= */

#include <algorithm>
#include <cmath>
#include <complex>
#include <iostream>
#include <sstream>
#include <vector>

#include "output.h"

static std::string render(const Value &v, bool nested);

namespace {

// One matrix cell as text. `decimals` >= 0 forces that many decimals on a
// real, finite, non-scientific number so a column of 0.5 / 1 / 2.25 lines
// up as 0.50 / 1.00 / 2.25 (MATLAB shows every number of a matrix with the
// same number of decimals); -1 leaves formatNumber() as it is.
std::string cellText(const Value &m, size_t r, size_t c, int decimals) {
  if (!m.isPacked() && !m.isPackedComplex()) {
    Value cell = m.at(r, c);
    if (cell.isBool() || cell.isInt() || cell.isText || cell.isArray || cell.isMatrix ||
        cell.isDict || cell.isObject || cell.isFunctionRef)
      return render(cell, true);
  }
  const std::complex<double> z = m.cnumAt(r, c);
  if (z.imag() != 0.0)
    return formatComplex(z.real(), z.imag());
  const double x = z.real();
  if (decimals > 0 && std::isfinite(x) && x != 0.0 && std::abs(x) >= 1e-4 &&
      std::abs(x) <= 1e6) {
    std::ostringstream ss;
    ss.setf(std::ios::fixed);
    ss.precision(decimals);
    ss << x;
    return ss.str();
  }
  return formatNumber(x);
}

// Decimals used by formatNumber() for x (0 for whole numbers, -1 when it
// would print in scientific notation, NaN or Inf).
int decimalsOf(double x) {
  const std::string t = formatNumber(x);
  if (t.find_first_of("eni") != std::string::npos) // 1e-05, nan, inf
    return -1;
  const size_t dot = t.find('.');
  return dot == std::string::npos ? 0 : static_cast<int>(t.size() - dot - 1);
}

} // namespace

// [1,2;3,4] - the declaration notation, on one line (used inside dicts,
// arrays and str()).
std::string matrixCompact(const Value &v) {
  if (v.rows() == 0)
    return "[]";
  std::ostringstream ss;
  ss << "[";
  for (size_t r = 0; r < v.rows(); r++) {
    if (r > 0)
      ss << ";";
    for (size_t c = 0; c < v.rowLength(r); c++) {
      if (c > 0)
        ss << ",";
      ss << cellText(v, r, c, -1);
    }
  }
  ss << "]";
  return ss.str();
}

// MATLAB-style display: one line per row, every column right-aligned to
// one common width, no brackets or commas. When any element has a fraction,
// every real element shows the same number of decimals - at most 4, like
// MATLAB's default "format short" (full precision stays in the value; print
// a single element to see more digits).
std::string matrixGrid(const Value &v) {
  if (v.rows() == 0)
    return "[]";
  const size_t R = v.rows();

  int decimals = 0;
  bool scientific = false;
  for (size_t r = 0; r < R && !scientific; r++)
    for (size_t c = 0; c < v.rowLength(r); c++) {
      const std::complex<double> z = v.cnumAt(r, c);
      if (z.imag() != 0.0)
        continue;
      const int d = decimalsOf(z.real());
      if (d < 0 && std::isfinite(z.real()))
        scientific = true;
      decimals = std::max(decimals, d);
    }
  if (scientific)
    decimals = -1;
  else
    decimals = std::min(decimals, 4);

  std::vector<std::vector<std::string>> text(R);
  size_t width = 0;
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < v.rowLength(r); c++) {
      text[r].push_back(cellText(v, r, c, decimals));
      width = std::max(width, text[r].back().size());
    }

  std::ostringstream ss;
  for (size_t r = 0; r < R; r++) {
    if (r > 0)
      ss << "\n";
    for (size_t c = 0; c < text[r].size(); c++)
      ss << "    " << std::string(width - text[r][c].size(), ' ') << text[r][c];
  }
  return ss.str();
}

std::string valueToString(const Value &v) { return render(v, false); }

std::string valueToCompactString(const Value &v) { return render(v, true); }

static std::string render(const Value &v, bool nested) {
  if (v.isText)
    return v.text();

  if (v.isObject) {
    std::ostringstream ss;
    ss << v.className() << "{";
    size_t i = 0;
    for (const auto &kv : v.dict()) {
      ss << kv.first << ": ";
      // Recurse instead of special-casing isText/number here - same fix
      // as the isArray branch below: a field can itself be an
      // array/matrix/dict, and reading .number directly used to
      // silently default to 0 for any non-scalar field.
      ss << render(kv.second, true);
      if (i < v.dict().size() - 1)
        ss << ", ";
      i++;
    }
    ss << "}";
    return ss.str();
  }

  if (v.isDict) {
    std::ostringstream ss;
    ss << "{";
    size_t i = 0;
    for (const auto &kv : v.dict()) {
      ss << kv.first << ": ";
      ss << render(kv.second, true);
      if (i < v.dict().size() - 1)
        ss << ", ";
      i++;
    }
    ss << "}";
    return ss.str();
  }

  if (v.isMatrix)
    return nested ? matrixCompact(v) : matrixGrid(v);

  if (v.isArray) {
    std::ostringstream ss;
    ss << "[";

    for (size_t i = 0; i < v.length(); i++) {
      // Recurse instead of special-casing isText/number here: an element
      // can itself be an array/matrix/dict (e.g. onlyRows()/onlyCols()
      // return an array of arrays) - reading its .number directly, as
      // this used to, silently defaults to 0 for any non-scalar element
      // instead of rendering its actual contents.
      ss << render(v.at(i), true);
      if (i < v.length() - 1)
        ss << ",";
    }

    ss << "]";
    return ss.str();
  }

  // Dimensional Integrity: append a compact unit suffix (e.g. "m/s",
  // "m/s^2", "kg*m/s^2") when the value carries a non-zero dimension —
  // every pre-existing numeric value has dimL=dimT=dimM=0 (unitless), so
  // this is purely additive and doesn't change output for anything that
  // predates this pillar. Built generically from the exponents rather than
  // a curated name table (e.g. doesn't special-case printing dimM=1,dimL=1,
  // dimT=-2 back out as "N") — correct and readable, just not the
  // prettiest possible spelling.
  if (v.isBool())
    return v.number != 0.0 ? "true" : "false";

  // An integer prints its exact digits (int64 beyond 2^53 included).
  std::string numStr = v.isInt() ? v.intText()
                       : v.isComplex ? formatComplex(v.number, v.imag)
                                     : formatNumber(v.number);
  if (v.dimL == 0 && v.dimT == 0 && v.dimM == 0)
    return numStr;

  auto appendDim = [](std::vector<std::string> &parts, const char *symbol, int exp) {
    if (exp == 0) return;
    parts.push_back(exp == 1 ? symbol : (std::string(symbol) + "^" + std::to_string(exp)));
  };
  std::vector<std::string> numerator, denominator;
  auto classify = [&](const char *symbol, int exp) {
    if (exp > 0) appendDim(numerator, symbol, exp);
    else if (exp < 0) appendDim(denominator, symbol, -exp);
  };
  classify("m", v.dimL);
  classify("s", v.dimT);
  classify("kg", v.dimM);

  std::ostringstream unitSs;
  for (size_t i = 0; i < numerator.size(); i++) {
    if (i > 0) unitSs << "*";
    unitSs << numerator[i];
  }
  if (numerator.empty())
    unitSs << "1";
  if (!denominator.empty()) {
    unitSs << "/";
    for (size_t i = 0; i < denominator.size(); i++) {
      if (i > 0) unitSs << "*";
      unitSs << denominator[i];
    }
  }

  return numStr + " " + unitSs.str();
}

/* ================= AUTO-DISPLAY (MATLAB "format loose") ================= */

namespace {

// True once a display block has been printed since the last
// resetDisplaySpacing(). A block ends with a blank line, so the next block
// must not add another one in front of itself - two displays in a row are
// separated by exactly one blank line, never two.
bool g_blockOpen = false;

// Every line of `text` indented by four spaces (the matrix grid's own
// left margin, so scalars, text and grids line up the same way).
std::string indented(const std::string &text) {
  std::string out;
  out.reserve(text.size() + 8);
  out += "    ";
  for (char ch : text) {
    out += ch;
    if (ch == '\n')
      out += "    ";
  }
  return out;
}

} // namespace

void resetDisplaySpacing() { g_blockOpen = false; }

void printValue(const std::string &name, const Value &v) {
  // No name: a bare value, as before (no header, no blank lines).
  if (name.empty()) {
    if (v.isMatrix && v.rows() > 0)
      std::cout << matrixGrid(v) << "\n" << std::endl;
    else
      std::cout << valueToString(v) << std::endl;
    g_blockOpen = false;
    return;
  }

  // A named value is shown the MATLAB way ("format loose"), whatever it is:
  //
  //   >> A = [1,2;3,4]
  //                          <- blank line (only before the first block)
  //   A =
  //
  //        1     2
  //        3     4
  //                          <- blank line
  //   >>
  //
  // The leading blank line separates the block from the command echoed
  // above it; the trailing one separates it from the next prompt (or the
  // next block).
  std::ostringstream block;
  if (!g_blockOpen)
    block << "\n";
  block << name << " =\n";
  if (v.isMatrix && v.rows() > 0)
    block << matrixGrid(v);
  else
    block << indented(valueToString(v));
  block << "\n\n";
  std::cout << block.str() << std::flush;
  g_blockOpen = true;
}

/* ================= FORMAT ================= */
std::string formatComplex(double re, double im) {
  // The sign sits between the parts, so the imaginary part itself is
  // printed unsigned ("3-4i", not "3+-4i").
  return formatNumber(re) + (std::signbit(im) ? "-" : "+") + formatNumber(std::fabs(im)) + "i";
}

std::string formatNumber(double value) {
  // Was snapping ANY value below 1e-10 in magnitude to exactly 0 -
  // presumably meant to clean up float noise from cancellation (e.g.
  // sin(pi) landing on ~1.2246e-16 instead of an exact 0), but an
  // ABSOLUTE magnitude threshold can't coexist with a language whose own
  // built-in physical constants span from ~6e23 (avogadro) down to
  // ~6.6e-34 (planck's constant, h) - any threshold aggressive enough to
  // catch that kind of float noise is, by construction, also small enough
  // to swallow a legitimate constant far tinier than the noise itself.
  // Confirmed by direct testing: this constants file's OWN h and
  // grav_const (6.674e-11) both silently printed as "0" instead of their
  // real values - not a display quirk, a completely wrong answer,
  // reproducible for any genuinely tiny result in ANY domain, since this
  // is the shared number-formatting function every printed Value routes
  // through. No magnitude threshold can be both "aggressive enough to
  // hide float noise" and "loose enough to show every legitimate tiny
  // value" for a language with this dynamic range - so this now only
  // treats an EXACT zero (the case a subtraction that mathematically
  // cancels completely, or a literal 0, actually produces) as "0";
  // genuinely near-zero-but-nonzero results now print in scientific
  // notation like every other tiny value, instead of being silently
  // discarded.
  // NaN and the infinities print as the names NC accepts back as input
  // (`nan`, `inf`, `-inf`). Streaming them directly is platform-dependent:
  // the MSVC runtime this project links on Windows can print 0/0 as
  // "-nan(ind)" and infinity as "inf" or "1.#INF".
  if (std::isnan(value))
    return "nan";
  if (std::isinf(value))
    return value > 0 ? "inf" : "-inf";

  std::ostringstream ss;

  if (value == 0) {
    ss << "0";
    return ss.str();
  }

  if (std::abs(value) < 1e-4 || std::abs(value) > 1e6)
    ss << std::scientific << value;
  else
    ss << std::fixed << value;

  std::string s = ss.str();

  if (s.find('e') == std::string::npos) {
    while (!s.empty() && s.back() == '0')
      s.pop_back();

    if (!s.empty() && s.back() == '.')
      s.pop_back();
  }

  return s;
}
