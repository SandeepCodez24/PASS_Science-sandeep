/* ================= PRINT ================= */

#include <cmath>
#include <iostream>
#include <sstream>

#include "output.h"

std::string valueToString(const Value &v) {
  if (v.isText)
    return v.text;

  if (v.isObject) {
    std::ostringstream ss;
    ss << v.className << "{";
    size_t i = 0;
    for (const auto &kv : v.dictMap) {
      ss << kv.first << ": ";
      if (kv.second.isText)
        ss << kv.second.text;
      else
        ss << formatNumber(kv.second.number);
      if (i < v.dictMap.size() - 1)
        ss << ", ";
      i++;
    }
    ss << "}";
    return ss.str();
  }

  if (v.isDict) {
    std::ostringstream ss;
    ss << "{";
    size_t i = 0;
    for (const auto &kv : v.dictMap) {
      ss << kv.first << ": ";
      if (kv.second.isText)
        ss << kv.second.text;
      else
        ss << formatNumber(kv.second.number);
      if (i < v.dictMap.size() - 1)
        ss << ", ";
      i++;
    }
    ss << "}";
    return ss.str();
  }

  if (v.isMatrix) {
    std::ostringstream ss;
    ss << "[\n";

    for (size_t i = 0; i < v.matrix.size(); i++) {
      ss << "  [";

      for (size_t j = 0; j < v.matrix[i].size(); j++) {
        ss << formatNumber(v.matrix[i][j].number);
        if (j < v.matrix[i].size() - 1)
          ss << ",";
      }

      ss << "]";
      if (i < v.matrix.size() - 1)
        ss << ",";

      ss << "\n";
    }

    ss << "]";
    return ss.str();
  }

  if (v.isArray) {
    std::ostringstream ss;
    ss << "[";

    for (size_t i = 0; i < v.array.size(); i++) {
      if (v.array[i].isText)
        ss << v.array[i].text;
      else
        ss << formatNumber(v.array[i].number);
      if (i < v.array.size() - 1)
        ss << ",";
    }

    ss << "]";
    return ss.str();
  }

  // Dimensional Integrity: append a compact unit suffix (e.g. "m/s",
  // "m/s^2", "kg*m/s^2") when the value carries a non-zero dimension —
  // every pre-existing numeric value has dimL=dimT=dimM=0 (unitless), so
  // this is purely additive and doesn't change output for anything that
  // predates this pillar. Built generically from the exponents rather than
  // a curated name table (e.g. doesn't special-case printing dimM=1,dimL=1,
  // dimT=-2 back out as "N") — correct and readable, just not the
  // prettiest possible spelling.
  std::string numStr = formatNumber(v.number);
  if (v.dimL == 0 && v.dimT == 0 && v.dimM == 0)
    return numStr;

  auto appendDim = [](std::vector<std::string> &parts, const char *symbol, int exp) {
    if (exp == 0) return;
    parts.push_back(exp == 1 ? symbol : (std::string(symbol) + "^" + std::to_string(exp)));
  };
  std::vector<std::string> numerator, denominator;
  auto classify = [&](const char *symbol, int exp) {
    if (exp > 0) appendDim(numerator, symbol, exp);
    else if (exp < 0) appendDim(denominator, symbol, -exp);
  };
  classify("m", v.dimL);
  classify("s", v.dimT);
  classify("kg", v.dimM);

  std::ostringstream unitSs;
  for (size_t i = 0; i < numerator.size(); i++) {
    if (i > 0) unitSs << "*";
    unitSs << numerator[i];
  }
  if (numerator.empty())
    unitSs << "1";
  if (!denominator.empty()) {
    unitSs << "/";
    for (size_t i = 0; i < denominator.size(); i++) {
      if (i > 0) unitSs << "*";
      unitSs << denominator[i];
    }
  }

  return numStr + " " + unitSs.str();
}

void printValue(const std::string &name, const Value &v) {
  if (!name.empty()) {
    std::cout << name << " = ";
  }

  std::cout << valueToString(v) << std::endl;
}

/* ================= FORMAT ================= */
std::string formatNumber(double value) {
  // Fix floating errors and scientific zero
  if (std::abs(value) < 1e-10)
    value = 0;

  std::ostringstream ss;

  if (value == 0) {
    ss << "0";
    return ss.str();
  }

  if (std::abs(value) < 1e-4 || std::abs(value) > 1e6)
    ss << std::scientific << value;
  else
    ss << std::fixed << value;

  std::string s = ss.str();

  if (s.find('e') == std::string::npos) {
    while (!s.empty() && s.back() == '0')
      s.pop_back();

    if (!s.empty() && s.back() == '.')
      s.pop_back();
  }

  return s;
}
