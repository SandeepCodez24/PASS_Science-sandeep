/* ================= PRINT ================= */

#include <algorithm>
#include <charconv>
#include <cmath>
#include <complex>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <vector>

#include "output.h"
#include "units.h"
#include "../ops/matrix/nd_array.h"
#include "../Numpy/numpy_poly1d.h"
#include "../ops/time/time.h"
#include "../../execution/Interrupt.h"
#include "governor.h"
#include "par.h"

// formatNumber() with or without the R4 widening (full precision for a value
// that would otherwise read as a whole number); grid cells go without.
static std::string formatNumberImpl(double value, bool fullWhenHidden);

// x with `precision` decimals, fixed or scientific - the very text an
// ostream with std::fixed / std::scientific gives (both are printf's %f /
// %e: exact decimal expansion, at least two exponent digits), through
// std::to_chars (2026-11-23). An ostringstream takes the global locale lock
// on every construction: 28 threads formatting a big matrix for print_all()
// ran 5x SLOWER than one. NaN and infinity never get here (formatNumberImpl
// handles them first).
static std::string fixedText(double x, int precision) {
  char buf[512];
  const auto r = std::to_chars(buf, buf + sizeof buf, x, std::chars_format::fixed, precision);
  return std::string(buf, r.ptr);
}
static std::string scientificText(double x, int precision) {
  char buf[64];
  const auto r = std::to_chars(buf, buf + sizeof buf, x, std::chars_format::scientific, precision);
  return std::string(buf, r.ptr);
}

// Numbers this large or larger print in scientific notation (below it, in
// full). Every whole number below 1e15 is exactly representable.
static const double kFixedLimit = 1e15;

// Decimals shown for a number that is not whole - precision(n).
static int g_displayDecimals = 6;

int displayDecimals() { return g_displayDecimals; }

void setDisplayDecimals(int decimals) {
  g_displayDecimals = std::max(0, std::min(decimals, 15));
}

static std::string render(const Value &v, bool nested);

namespace {

// One matrix cell as text. `decimals` >= 0 forces that many decimals on a
// real, finite, non-scientific number so a column of 0.5 / 1 / 2.25 lines
// up as 0.50 / 1.00 / 2.25 (MATLAB shows every number of a matrix with the
// same number of decimals); -1 leaves formatNumber() as it is.
std::string cellText(const Value &m, size_t r, size_t c, int decimals) {
  if (!m.isPacked() && !m.isPackedComplex()) {
    Value cell = m.at(r, c);
    if (cell.isBool() || cell.isInt() || cell.isTime() || cell.isText || cell.isArray ||
        cell.isMatrix || cell.isDict || cell.isObject || cell.isFunctionRef)
      return render(cell, true);
  }
  const std::complex<double> z = m.cnumAt(r, c);
  if (z.imag() != 0.0)
    return formatComplex(z.real(), z.imag());
  const double x = z.real();
  if (decimals > 0 && std::isfinite(x) && x != 0.0 && std::abs(x) >= 1e-4 &&
      std::abs(x) < kFixedLimit)
    return fixedText(x, decimals);
  return formatNumberImpl(x, false); // a grid cell: no R4 widening
}

// R4 (2026-10-27): the fewest decimals (up to 17) that print x so it reads
// back as exactly x - 1.0000000000000002, 0.9999999999999999.
int roundTripDecimals(double x) {
  for (int d = 1; d <= 17; d++) {
    if (std::strtod(fixedText(x, d).c_str(), nullptr) == x)
      return d;
  }
  return 17;
}

// True when `text` (a fixed-point rendering of x) reads as a whole number
// although x is not one - the short display would hide that x differs from
// that whole number (nextafter(1, 2) shown as "1").
bool looksWholeButIsNot(const std::string &text, double x) {
  if (!std::isfinite(x) || x == std::trunc(x))
    return false;
  const double shown = std::strtod(text.c_str(), nullptr);
  return shown == std::trunc(shown);
}

// Decimals used by formatNumber() for x (0 for whole numbers, -1 when it
// would print in scientific notation, NaN or Inf).
int decimalsOf(double x) {
  // With the R4 widening: a cell that is not whole but would read as whole
  // (1.0000001) still counts as having decimals, so the grid shows 1.0000.
  const std::string t = formatNumberImpl(x, true);
  if (t.find_first_of("eni") != std::string::npos) // 1e-05, nan, inf
    return -1;
  const size_t dot = t.find('.');
  return dot == std::string::npos ? 0 : static_cast<int>(t.size() - dot - 1);
}

// Characters per output line; 0 until first asked for (see displayWidth()).
size_t g_displayWidth = 0;

// "1,2;3,4" - the rows of a 2-D matrix in the declaration notation, no
// brackets.
std::string compactRows(const Value &v) {
  std::ostringstream ss;
  for (size_t r = 0; r < v.rows(); r++) {
    if (r > 0)
      ss << ";";
    for (size_t c = 0; c < v.rowLength(r); c++) {
      if (c > 0)
        ss << ",";
      ss << cellText(v, r, c, -1);
    }
  }
  return ss.str();
}

// [1,2;3,4 ;; 5,6;7,8] style one-line notation of an N-D matrix: the pages
// in storage order, joined by as many semicolons as the axis that changes
// between them needs (';;' for axis -3, ';;;' for axis -4 ...). If no
// separator says how many axes there are (a leading size of 1), a trailing
// one does: a 1x2x2 matrix is [1,2;3,4;;]. Pasting it back gives the same
// matrix.
std::string compactND(const Value &v) {
  const nd::Shape &s = v.ndShape();
  const size_t n = s.size();
  const size_t pageSize = s[n - 2] * s[n - 1];
  if (pageSize == 0 || v.ndCount() == 0)
    return "[]";
  const size_t pages = v.ndCount() / pageSize;
  std::ostringstream ss;
  ss << "[";
  size_t widest = 1;
  std::vector<size_t> prev;
  for (size_t p = 0; p < pages; p++) {
    const std::vector<size_t> lead = nd::pageIndex(s, p);
    if (p > 0) {
      size_t changed = 0;
      while (changed < lead.size() && lead[changed] == prev[changed])
        changed++;
      const size_t level = (n - 1) - changed;
      widest = std::max(widest, level);
      ss << std::string(level, ';');
    }
    ss << compactRows(nd::page(v, p));
    prev = lead;
  }
  if (widest < n - 1)
    ss << std::string(n - 1, ';');
  ss << "]";
  return ss.str();
}

// The column-paged grid of one 2-D matrix whose cell texts are ready.
std::string pagedGrid(const std::vector<std::vector<std::string>> &text, size_t width) {
  size_t C = 0;
  for (const auto &row : text)
    C = std::max(C, row.size());
  const size_t field = 4 + width; // "    " + right-aligned cell
  const size_t perChunk = std::max<size_t>(1, displayWidth() / field);

  auto rowsOf = [&](size_t from, size_t to) {
    std::ostringstream ss;
    for (size_t r = 0; r < text.size(); r++) {
      if (r > 0)
        ss << "\n";
      for (size_t c = from; c < to && c < text[r].size(); c++)
        ss << "    " << std::string(width - text[r][c].size(), ' ') << text[r][c];
    }
    return ss.str();
  };

  if (C <= perChunk)
    return rowsOf(0, C);

  // Too wide for one line: MATLAB-style column groups, each under a
  // "Columns a through b" header (0-based, the way NC indexes them). A
  // blank line goes before every header, the first one included, so the
  // groups stand apart from the "A =" line above them.
  std::ostringstream ss;
  for (size_t from = 0; from < C; from += perChunk) {
    const size_t to = std::min(C, from + perChunk);
    ss << (from > 0 ? "\n\n" : "\n");
    if (to - from == 1)
      ss << "  Column " << from << "\n\n";
    else
      ss << "  Columns " << from << " through " << (to - 1) << "\n\n";
    ss << rowsOf(from, to);
  }
  return ss.str();
}

// "B[0,:,:]" - the label of page `p` of an N-D matrix named `name`.
std::string pageLabel(const std::string &name, const nd::Shape &s, size_t p) {
  std::ostringstream ss;
  ss << name << "[";
  for (size_t i : nd::pageIndex(s, p))
    ss << i << ",";
  ss << ":,:]";
  return ss.str();
}

} // namespace

// NC_DISPLAY_WIDTH as a number, or 0 when it is not set. getenv() is flagged
// as unsafe by the MSVC runtime (C4996); _dupenv_s() is its replacement and
// hands back a heap copy that must be freed - same as main.cpp does for
// NC_IDE_PROMPT.
static long displayWidthFromEnvironment() {
#ifdef _WIN32
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, "NC_DISPLAY_WIDTH") != 0 || buffer == nullptr)
    return 0;
  const long w = std::strtol(buffer, nullptr, 10);
  std::free(buffer);
  return w;
#else
  const char *value = std::getenv("NC_DISPLAY_WIDTH");
  return value ? std::strtol(value, nullptr, 10) : 0;
#endif
}

size_t displayWidth() {
  if (g_displayWidth == 0) {
    const long w = displayWidthFromEnvironment();
    g_displayWidth = w > 0 ? static_cast<size_t>(w) : 80;
    g_displayWidth = std::max<size_t>(g_displayWidth, 20);
  }
  return g_displayWidth;
}

void setDisplayWidth(size_t chars) {
  g_displayWidth = chars == 0 ? 0 : std::max<size_t>(chars, 20);
}

// [1,2;3,4] - the declaration notation, on one line (used inside dicts,
// arrays and str()).
std::string matrixCompact(const Value &v) {
  if (v.isND())
    return compactND(v);
  if (v.rows() == 0)
    return "[]";
  std::ostringstream ss;
  ss << "[";
  for (size_t r = 0; r < v.rows(); r++) {
    if (r > 0)
      ss << ";";
    for (size_t c = 0; c < v.rowLength(r); c++) {
      if (c > 0)
        ss << ",";
      ss << cellText(v, r, c, -1);
    }
  }
  ss << "]";
  // A matrix with a unit (core/units.h): [1,2,3] m
  if (v.hasUnit())
    ss << " " << nc::units::text(nc::units::unitOf(v));
  return ss.str();
}

// MATLAB-style display: one line per row, every column right-aligned to
// one common width, no brackets or commas. When any element has a fraction,
// every real element shows the same number of decimals - at most 4, like
// MATLAB's default "format short" (full precision stays in the value; print
// a single element to see more digits).
std::string matrixGrid(const Value &v) {
  if (v.isND())
    return matrixGridND(v, "");
  if (v.rows() == 0)
    return "[]";
  const size_t R = v.rows();

  int decimals = 0;
  bool scientific = false;
  for (size_t r = 0; r < R && !scientific; r++)
    for (size_t c = 0; c < v.rowLength(r); c++) {
      const std::complex<double> z = v.cnumAt(r, c);
      if (z.imag() != 0.0)
        continue;
      const int d = decimalsOf(z.real());
      if (d < 0 && std::isfinite(z.real()))
        scientific = true;
      decimals = std::max(decimals, d);
    }
  if (scientific)
    decimals = -1;
  else
    decimals = std::min(decimals, 4);

  std::vector<std::vector<std::string>> text(R);
  size_t width = 0;
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < v.rowLength(r); c++) {
      text[r].push_back(cellText(v, r, c, decimals));
      width = std::max(width, text[r].back().size());
    }

  // Wider than the Command Window: shown in column groups (pagedGrid()).
  // A matrix with a unit (core/units.h) says so under the grid.
  if (v.hasUnit())
    return pagedGrid(text, width) + "\n    (unit: " + nc::units::text(nc::units::unitOf(v)) + ")";
  return pagedGrid(text, width);
}

std::string matrixGridND(const Value &v, const std::string &name) {
  const nd::Shape &s = v.ndShape();
  const size_t pageSize = s[s.size() - 2] * s[s.size() - 1];
  if (pageSize == 0 || v.ndCount() == 0)
    return "[] (empty " + nd::shapeText(s) + ")";
  const size_t pages = v.ndCount() / pageSize;
  std::ostringstream ss;
  for (size_t p = 0; p < pages; p++) {
    if (p > 0)
      ss << "\n\n";
    // Laid out like a named 2-D matrix: "B[0,:,:] =" and the grid under it.
    ss << pageLabel(name, s, p) << " =\n" << matrixGrid(nd::page(v, p));
  }
  return ss.str();
}

std::string valueToString(const Value &v) { return render(v, false); }

std::string valueToCompactString(const Value &v) { return render(v, true); }

static std::string render(const Value &v, bool nested) {
  if (v.isText)
    return v.text();

  // A function reference prints as written: @square, or the text of an
  // anonymous function, @(x) x * 2. It used to print as 0.
  if (v.isFunctionRef)
    return functionRefText(v.funcRefName());

  // A poly1d (Numpy/numpy_poly1d.h) prints as the polynomial itself.
  if (nc::numpy::isPoly1d(v))
    return nc::numpy::poly1dText(v);

  if (v.isObject) {
    std::ostringstream ss;
    ss << v.className() << "{";
    // Fields in the order they were set (displayKeys(): the order hint kept
    // by setKeyOrdered(), else the hash table's order) - 2026-11-18.
    const std::vector<std::string> keys = v.displayKeys();
    for (size_t i = 0; i < keys.size(); i++) {
      ss << keys[i] << ": ";
      // Recurse instead of special-casing isText/number here - same fix
      // as the isArray branch below: a field can itself be an
      // array/matrix/dict, and reading .number directly used to
      // silently default to 0 for any non-scalar field.
      ss << render(v.dict().at(keys[i]), true);
      if (i + 1 < keys.size())
        ss << ", ";
    }
    ss << "}";
    return ss.str();
  }

  if (v.isDict) {
    std::ostringstream ss;
    ss << "{";
    // dict(A=, B=), d[k] = v, a loaded .ndat: the order given; else as stored.
    const std::vector<std::string> keys = v.displayKeys();
    for (size_t i = 0; i < keys.size(); i++) {
      ss << keys[i] << ": ";
      ss << render(v.dict().at(keys[i]), true);
      if (i + 1 < keys.size())
        ss << ", ";
    }
    ss << "}";
    return ss.str();
  }

  if (v.isMatrix)
    return nested ? matrixCompact(v) : matrixGrid(v);

  if (v.isArray) {
    std::ostringstream ss;
    ss << "[";

    for (size_t i = 0; i < v.length(); i++) {
      // Recurse instead of special-casing isText/number here: an element
      // can itself be an array/matrix/dict (e.g. onlyRows()/onlyCols()
      // return an array of arrays) - reading its .number directly, as
      // this used to, silently defaults to 0 for any non-scalar element
      // instead of rendering its actual contents.
      ss << render(v.at(i), true);
      if (i < v.length() - 1)
        ss << ",";
    }

    ss << "]";
    if (v.hasUnit())
      ss << " " << nc::units::text(nc::units::unitOf(v));
    return ss.str();
  }

  // Dimensional Integrity: append a compact unit suffix (e.g. "m/s",
  // "m/s^2", "kg*m/s^2") when the value carries a non-zero dimension —
  // every pre-existing numeric value has dimL=dimT=dimM=0 (unitless), so
  // this is purely additive and doesn't change output for anything that
  // predates this pillar. Built generically from the exponents rather than
  // a curated name table (e.g. doesn't special-case printing dimM=1,dimL=1,
  // dimT=-2 back out as "N") — correct and readable, just not the
  // prettiest possible spelling.
  if (v.isBool())
    return v.number != 0.0 ? "true" : "false";

  // A timestamp prints as local date and time, a duration as hh:mm:ss
  // (ops/time/time.h).
  if (v.isTime())
    return nctime::displayText(v);

  // An integer prints its exact digits (int64 beyond 2^53 included).
  std::string numStr = v.isInt() ? v.intText()
                       : v.isComplex ? formatComplex(v.number, v.imag)
                                     : formatNumber(v.number);
  if (v.dimL == 0 && v.dimT == 0 && v.dimM == 0)
    return numStr;

  auto appendDim = [](std::vector<std::string> &parts, const char *symbol, int exp) {
    if (exp == 0) return;
    parts.push_back(exp == 1 ? symbol : (std::string(symbol) + "^" + std::to_string(exp)));
  };
  std::vector<std::string> numerator, denominator;
  auto classify = [&](const char *symbol, int exp) {
    if (exp > 0) appendDim(numerator, symbol, exp);
    else if (exp < 0) appendDim(denominator, symbol, -exp);
  };
  classify("m", v.dimL);
  classify("s", v.dimT);
  classify("kg", v.dimM);

  std::ostringstream unitSs;
  for (size_t i = 0; i < numerator.size(); i++) {
    if (i > 0) unitSs << "*";
    unitSs << numerator[i];
  }
  if (numerator.empty())
    unitSs << "1";
  if (!denominator.empty()) {
    unitSs << "/";
    for (size_t i = 0; i < denominator.size(); i++) {
      if (i > 0) unitSs << "*";
      unitSs << denominator[i];
    }
  }

  return numStr + " " + unitSs.str();
}

/* ================= AUTO-DISPLAY (MATLAB "format loose") ================= */

namespace {

// True once a display block has been printed since the last
// resetDisplaySpacing(). A block ends with a blank line, so the next block
// must not add another one in front of itself - two displays in a row are
// separated by exactly one blank line, never two.
bool g_blockOpen = false;

// Every line of `text` indented by four spaces (the matrix grid's own
// left margin, so scalars, text and grids line up the same way).
std::string indented(const std::string &text) {
  std::string out;
  out.reserve(text.size() + 8);
  out += "    ";
  for (char ch : text) {
    out += ch;
    if (ch == '\n')
      out += "    ";
  }
  return out;
}

} // namespace

void resetDisplaySpacing() { g_blockOpen = false; }

/* ================= BIG VALUES (2026-11-23, decision D2) =================

   docs/Large_Data_Design.md section 6. Before, every echo built one string
   per element and the whole block before printing anything: 62.8 M
   elements took 100 s and 1.74 GB of text, 628 M never finished, and the
   IDE then had to swallow it all. Now:
     - a value of more than kSummaryAbove elements is shown as a summary -
       its size, its first and last rows / columns, and how to see the rest;
     - print_all(A) writes every value, column group by column group, as it
       goes (formatted on several cores, a batch at a time): the first line
       appears at once, Stop works between batches, memory stays small. Its
       text is byte for byte what `print(A)` printed before.
   Values up to kSummaryAbove elements print exactly as before. */

namespace {

constexpr uint64_t kSummaryAbove = 10000;
constexpr size_t kEdgeRows = 3; // rows shown at each end of a summary
constexpr size_t kEdgeCols = 4; // columns shown at each end

uint64_t displayCount(const Value &v) {
  if (v.isMatrix)
    return v.isND() ? static_cast<uint64_t>(v.ndCount())
                    : static_cast<uint64_t>(v.rows()) * static_cast<uint64_t>(v.cols());
  if (v.isArray)
    return v.length();
  return 0;
}

bool summarised(const Value &v) { return (v.isMatrix || v.isArray) && displayCount(v) > kSummaryAbove; }

// "1x6,283,185,308 double (a rule - 46.8 GB if stored)"
std::string sizeLine(const Value &v) {
  std::string dims;
  if (v.isMatrix && v.isND()) {
    for (size_t d : v.ndShape())
      dims += (dims.empty() ? "" : "x") + nc::mem::countText(d);
  } else if (v.isMatrix) {
    dims = nc::mem::countText(v.rows()) + "x" + nc::mem::countText(v.cols());
  } else {
    dims = nc::mem::countText(v.length()) + "-element";
  }
  const uint64_t n = displayCount(v);
  std::string type = v.isArray ? "array" : "matrix";
  std::string bytes;
  if (v.lazyTensor()) {
    type = "double";
    bytes = " (a rule - " + nc::mem::bytesText(n * 8) + " if stored)";
  } else if (v.isTypedPacked()) {
    type = elemTypeName(v.elemType());
    bytes = " (" + nc::mem::bytesText(n * elemTypeBytes(v.elemType())) + ")";
  } else if (v.isPackedComplex()) {
    type = "complex double";
    bytes = " (" + nc::mem::bytesText(n * 16) + ")";
  } else if (v.isPacked()) {
    type = "double";
    bytes = " (" + nc::mem::bytesText(n * 8) + ")";
  }
  return dims + " " + type + bytes;
}

// The positions shown at one edge of a summary: 0..edge-1, SIZE_MAX (the
// "..." gap), n-edge..n-1 - or all of 0..n-1 when that is short.
std::vector<size_t> edgePositions(size_t n, size_t edge) {
  std::vector<size_t> out;
  if (n <= 2 * edge) {
    for (size_t i = 0; i < n; i++)
      out.push_back(i);
    return out;
  }
  for (size_t i = 0; i < edge; i++)
    out.push_back(i);
  out.push_back(SIZE_MAX);
  for (size_t i = n - edge; i < n; i++)
    out.push_back(i);
  return out;
}

// The summary grid of a 2-D matrix: the corner cells, "..." between, laid
// out like matrixGrid() (same decimals rule, over the cells shown).
std::string summaryGrid(const Value &v, uint64_t &shown) {
  const std::vector<size_t> rows = edgePositions(v.rows(), kEdgeRows);
  const std::vector<size_t> cols = edgePositions(v.cols(), kEdgeCols);
  int decimals = 0;
  bool scientific = false;
  for (size_t r : rows)
    for (size_t c : cols) {
      if (r == SIZE_MAX || c == SIZE_MAX || c >= v.rowLength(r))
        continue;
      const std::complex<double> z = v.cnumAt(r, c);
      if (z.imag() != 0.0)
        continue;
      const int d = decimalsOf(z.real());
      if (d < 0 && std::isfinite(z.real()))
        scientific = true;
      decimals = std::max(decimals, d);
    }
  decimals = scientific ? -1 : std::min(decimals, 4);

  std::vector<std::vector<std::string>> text;
  size_t width = 3; // "..."
  shown = 0;
  for (size_t r : rows) {
    std::vector<std::string> line;
    for (size_t c : cols) {
      if (r == SIZE_MAX || c == SIZE_MAX || c >= v.rowLength(r)) {
        line.push_back(c < SIZE_MAX && r < SIZE_MAX ? "" : "...");
        continue;
      }
      line.push_back(cellText(v, r, c, decimals));
      width = std::max(width, line.back().size());
      shown++;
    }
    text.push_back(std::move(line));
  }
  std::ostringstream ss;
  for (size_t i = 0; i < text.size(); i++) {
    if (i > 0)
      ss << "\n";
    for (const std::string &cell : text[i])
      ss << "    " << std::string(width - cell.size(), ' ') << cell;
  }
  if (v.hasUnit())
    ss << "\n    (unit: " << nc::units::text(nc::units::unitOf(v)) << ")";
  return ss.str();
}

// The whole summary body (without a "name =" line).
std::string summaryBody(const Value &v, const std::string &name) {
  std::ostringstream ss;
  ss << "    " << sizeLine(v) << "\n\n";
  uint64_t shown = 0;
  if (v.isMatrix && !v.isND()) {
    ss << summaryGrid(v, shown) << "\n\n";
  } else if (v.isArray) {
    ss << "    [";
    const std::vector<size_t> at = edgePositions(v.length(), kEdgeCols);
    for (size_t i = 0; i < at.size(); i++) {
      if (i > 0)
        ss << ", ";
      if (at[i] == SIZE_MAX) {
        ss << "...";
      } else {
        ss << render(v.at(at[i]), true);
        shown++;
      }
    }
    ss << "]\n\n";
  }
  const uint64_t hidden = displayCount(v) - shown;
  const std::string who = name.empty() ? "the value" : name;
  ss << "    (" << nc::mem::countText(hidden) << " more values not shown - open " << who
     << " in the Variable viewer, or print_all(" << (name.empty() ? "x" : name)
     << ") to print every value)";
  return ss.str();
}

} // namespace

bool displayIsSummary(const Value &v) { return summarised(v); }

std::string printText(const Value &v) { return summarised(v) ? summaryBody(v, "") : valueToString(v); }

/* ---- print_all: every value, streamed ---- */

namespace {

// matrixGrid()'s decimals rule over every element, on several cores for a
// packed matrix. Returns -1 for "scientific", else 0..4.
int gridDecimals(const Value &v, bool parallel) {
  const size_t R = v.rows();
  struct Acc {
    int decimals = 0;
    bool scientific = false;
  };
  auto scan = [&](size_t begin, size_t end) {
    Acc a;
    const size_t C = v.cols();
    for (size_t k = begin; k < end; k++) {
      const size_t r = parallel ? k / C : k;
      const size_t c0 = parallel ? k % C : 0;
      const size_t c1 = parallel ? c0 + 1 : v.rowLength(r);
      for (size_t c = c0; c < c1; c++) {
        const std::complex<double> z = v.cnumAt(r, c);
        if (z.imag() != 0.0)
          continue;
        const int d = decimalsOf(z.real());
        if (d < 0 && std::isfinite(z.real()))
          a.scientific = true;
        a.decimals = std::max(a.decimals, d);
      }
    }
    return a;
  };
  Acc all;
  if (parallel) {
    nc::par::reduceBlocks(
        R * v.cols(), nc::par::compute(300.0), "print", Acc{}, scan,
        [](Acc x, const Acc &y) {
          x.decimals = std::max(x.decimals, y.decimals);
          x.scientific = x.scientific || y.scientific;
          return x;
        },
        all);
  } else {
    all = scan(0, R);
  }
  return all.scientific ? -1 : std::min(all.decimals, 4);
}

size_t gridWidth(const Value &v, int decimals, bool parallel) {
  const size_t R = v.rows();
  auto scan = [&](size_t begin, size_t end) {
    size_t w = 0;
    const size_t C = v.cols();
    for (size_t k = begin; k < end; k++) {
      const size_t r = parallel ? k / C : k;
      const size_t c0 = parallel ? k % C : 0;
      const size_t c1 = parallel ? c0 + 1 : v.rowLength(r);
      for (size_t c = c0; c < c1; c++)
        w = std::max(w, cellText(v, r, c, decimals).size());
    }
    return w;
  };
  size_t width = 0;
  if (parallel)
    nc::par::reduceBlocks(
        R * v.cols(), nc::par::compute(300.0), "print", size_t(0), scan,
        [](size_t a, size_t b) { return std::max(a, b); }, width);
  else
    width = scan(0, R);
  return width;
}

} // namespace

bool printAll(const Value &v) {
  // Only a 2-D matrix (a 1xN range included) is streamed; anything else
  // prints as print(A) does.
  if (!v.isMatrix || v.isND() || v.rows() == 0) {
    std::cout << valueToString(v) << std::endl;
    return true;
  }
  const bool parallel = v.isPacked() || v.isPackedComplex() || v.isTypedPacked();
  const int decimals = gridDecimals(v, parallel);
  if (nc::Interrupt::poll())
    return false;
  const size_t width = gridWidth(v, decimals, parallel);
  if (nc::Interrupt::poll())
    return false;

  const size_t R = v.rows();
  size_t C = 0;
  if (parallel)
    C = v.cols();
  else
    for (size_t r = 0; r < R; r++)
      C = std::max(C, v.rowLength(r));
  const size_t field = 4 + width;
  const size_t perChunk = std::max<size_t>(1, displayWidth() / field);
  const bool paged = C > perChunk;
  const size_t groups = paged ? (C + perChunk - 1) / perChunk : 1;

  // A segment: rows [r0, r1) of column group g. Its text is exactly the
  // part of pagedGrid()'s output it stands for.
  struct Segment {
    size_t g, r0, r1;
  };
  const size_t cellsPerGroupRow = paged ? perChunk : std::max<size_t>(C, 1);
  const size_t rowsPerSegment = std::max<size_t>(1, (size_t(1) << 16) / cellsPerGroupRow);
  auto segmentText = [&](const Segment &s) {
    const size_t from = s.g * perChunk;
    const size_t to = paged ? std::min(C, from + perChunk) : C;
    std::string out;
    if (s.r0 == 0) {
      if (paged) {
        out += s.g > 0 ? "\n\n" : "\n";
        if (to - from == 1)
          out += "  Column " + std::to_string(from) + "\n\n";
        else
          out += "  Columns " + std::to_string(from) + " through " + std::to_string(to - 1) + "\n\n";
      }
    } else {
      out += "\n";
    }
    for (size_t r = s.r0; r < s.r1; r++) {
      if (r > s.r0)
        out += "\n";
      const size_t len = std::min(to, v.rowLength(r));
      for (size_t c = from; c < len; c++) {
        const std::string t = cellText(v, r, c, decimals);
        out += "    ";
        out.append(width - t.size(), ' ');
        out += t;
      }
    }
    return out;
  };

  std::vector<Segment> batch;
  std::vector<std::string> texts;
  size_t batchCells = 0, cellsDone = 0;
  const size_t totalCells = R * std::max<size_t>(C, 1);
  nc::par::SerialProgress progress("print", totalCells);
  auto flush = [&]() -> bool {
    texts.assign(batch.size(), std::string());
    if (parallel && batch.size() > 1) {
      nc::par::forBlocks(batch.size(), nc::par::compute(20000.0), "print",
                         [&](size_t b, size_t e) {
                           for (size_t i = b; i < e; i++)
                             texts[i] = segmentText(batch[i]);
                         });
    } else {
      for (size_t i = 0; i < batch.size(); i++)
        texts[i] = segmentText(batch[i]);
    }
    for (const std::string &t : texts)
      std::cout << t;
    std::cout << std::flush;
    cellsDone += batchCells;
    progress.at(cellsDone);
    batch.clear();
    batchCells = 0;
    return !nc::Interrupt::poll();
  };
  for (size_t g = 0; g < groups; g++) {
    for (size_t r0 = 0; r0 < R; r0 += rowsPerSegment) {
      const size_t r1 = std::min(R, r0 + rowsPerSegment);
      batch.push_back({g, r0, r1});
      batchCells += (r1 - r0) * cellsPerGroupRow;
      if (batchCells >= (size_t(1) << 22) && !flush()) {
        std::cout << std::endl;
        return false;
      }
    }
  }
  if (!batch.empty() && !flush()) {
    std::cout << std::endl;
    return false;
  }
  if (v.hasUnit())
    std::cout << "\n    (unit: " << nc::units::text(nc::units::unitOf(v)) << ")";
  std::cout << std::endl;
  return true;
}

void printValue(const std::string &name, const Value &v) {
  // A big matrix or array: a summary, never the whole text (D2).
  if (summarised(v)) {
    std::ostringstream block;
    if (name.empty()) {
      block << summaryBody(v, name) << "\n\n";
      g_blockOpen = false;
    } else {
      if (!g_blockOpen)
        block << "\n";
      block << name << " =\n\n" << summaryBody(v, name) << "\n\n";
      g_blockOpen = true;
    }
    std::cout << block.str() << std::flush;
    return;
  }

  // An N-D matrix: one block per 2-D page, each headed like MATLAB's
  // "B(:,:,1) =" but in NC's own indexing - "B[0,:,:] =".
  if (v.isND()) {
    std::ostringstream block;
    if (!name.empty() && !g_blockOpen)
      block << "\n";
    block << matrixGridND(v, name) << "\n\n";
    std::cout << block.str() << std::flush;
    g_blockOpen = !name.empty();
    return;
  }

  // No name: a bare value, as before (no header, no blank lines).
  if (name.empty()) {
    if (v.isMatrix && v.rows() > 0)
      std::cout << matrixGrid(v) << "\n" << std::endl;
    else
      std::cout << valueToString(v) << std::endl;
    g_blockOpen = false;
    return;
  }

  // A named value is shown the MATLAB way ("format loose"), whatever it is:
  //
  //   >> A = [1,2;3,4]
  //                          <- blank line (only before the first block)
  //   A =
  //
  //        1     2
  //        3     4
  //                          <- blank line
  //   >>
  //
  // The leading blank line separates the block from the command echoed
  // above it; the trailing one separates it from the next prompt (or the
  // next block).
  std::ostringstream block;
  if (!g_blockOpen)
    block << "\n";
  block << name << " =\n";
  if (v.isMatrix && v.rows() > 0)
    block << matrixGrid(v);
  else
    block << indented(valueToString(v));
  block << "\n\n";
  std::cout << block.str() << std::flush;
  g_blockOpen = true;
}

void printDisplayBlock(const std::string &title, const std::string &text) {
  // Same "format loose" spacing as a named printValue() block.
  std::ostringstream block;
  if (!g_blockOpen)
    block << "\n";
  block << title << " =\n\n" << text << "\n\n";
  std::cout << block.str() << std::flush;
  g_blockOpen = true;
}

/* ================= FORMAT ================= */
std::string formatComplex(double re, double im) {
  // The sign sits between the parts, so the imaginary part itself is
  // printed unsigned ("3-4i", not "3+-4i").
  return formatNumber(re) + (std::signbit(im) ? "-" : "+") + formatNumber(std::fabs(im)) + "i";
}

std::string formatNumber(double value) { return formatNumberImpl(value, true); }

static std::string formatNumberImpl(double value, bool fullWhenHidden) {
  // Was snapping ANY value below 1e-10 in magnitude to exactly 0 -
  // presumably meant to clean up float noise from cancellation (e.g.
  // sin(pi) landing on ~1.2246e-16 instead of an exact 0), but an
  // ABSOLUTE magnitude threshold can't coexist with a language whose own
  // built-in physical constants span from ~6e23 (avogadro) down to
  // ~6.6e-34 (planck's constant, h) - any threshold aggressive enough to
  // catch that kind of float noise is, by construction, also small enough
  // to swallow a legitimate constant far tinier than the noise itself.
  // Confirmed by direct testing: this constants file's OWN h and
  // grav_const (6.674e-11) both silently printed as "0" instead of their
  // real values - not a display quirk, a completely wrong answer,
  // reproducible for any genuinely tiny result in ANY domain, since this
  // is the shared number-formatting function every printed Value routes
  // through. No magnitude threshold can be both "aggressive enough to
  // hide float noise" and "loose enough to show every legitimate tiny
  // value" for a language with this dynamic range - so this now only
  // treats an EXACT zero (the case a subtraction that mathematically
  // cancels completely, or a literal 0, actually produces) as "0";
  // genuinely near-zero-but-nonzero results now print in scientific
  // notation like every other tiny value, instead of being silently
  // discarded.
  // NaN and the infinities print as the names NC accepts back as input
  // (`nan`, `inf`, `-inf`). Streaming them directly is platform-dependent:
  // the MSVC runtime this project links on Windows can print 0/0 as
  // "-nan(ind)" and infinity as "inf" or "1.#INF".
  if (std::isnan(value))
    return "nan";
  if (std::isinf(value))
    return value > 0 ? "inf" : "-inf";

  if (value == 0)
    return "0";

  // Up to 1e15 a number is written out in full: whole numbers keep every
  // digit (3628800, not the 3.628800e+06 every value above 1e6 used to
  // get), others show displayDecimals() decimals (6 unless precision(n)
  // changed it). Below 1e-4 and from 1e15 on, scientific notation.
  std::string s;
  if (std::abs(value) < 1e-4 || std::abs(value) >= kFixedLimit) {
    s = scientificText(value, displayDecimals());
  } else {
    // A double holds about 15 significant digits; decimals past that are
    // binary noise (123456789012345.671875), so a big number shows fewer.
    const int intDigits =
        std::abs(value) >= 1 ? static_cast<int>(std::floor(std::log10(std::abs(value)))) + 1 : 0;
    s = fixedText(value, std::max(0, std::min(displayDecimals(), 15 - intDigits)));
  }

  // (Only trailing decimals are trimmed: with 0 decimals there is no '.',
  // and 3628800 must keep its zeros.)
  if (s.find('e') == std::string::npos && s.find('.') != std::string::npos) {
    while (!s.empty() && s.back() == '0')
      s.pop_back();

    if (!s.empty() && s.back() == '.')
      s.pop_back();

    // R4 (2026-10-27): a single value that is not whole but would print as
    // a whole number (nextafter(1, 2) = 1.0000000000000002 shown as "1") is
    // shown at full precision, as NumPy prints a scalar. Every other value
    // keeps the short form, and so do grids (NumPy prints arrays at a fixed
    // precision too: np.roots([1, -3, 2]) shows [2., 1.]).
    if (fullWhenHidden && looksWholeButIsNot(s, value)) {
      s = fixedText(value, roundTripDecimals(value));
      while (s.back() == '0')
        s.pop_back();
    }
  }

  return s;
}
