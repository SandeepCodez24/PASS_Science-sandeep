/* ================= PRINT ================= */

#include <cmath>
#include <iostream>
#include <sstream>

#include "output.h"

std::string valueToString(const Value &v) {
  if (v.isText)
    return v.text();

  if (v.isObject) {
    std::ostringstream ss;
    ss << v.className() << "{";
    size_t i = 0;
    for (const auto &kv : v.dict()) {
      ss << kv.first << ": ";
      // Recurse instead of special-casing isText/number here - same fix
      // as the isArray branch below: a field can itself be an
      // array/matrix/dict, and reading .number directly used to
      // silently default to 0 for any non-scalar field.
      ss << valueToString(kv.second);
      if (i < v.dict().size() - 1)
        ss << ", ";
      i++;
    }
    ss << "}";
    return ss.str();
  }

  if (v.isDict) {
    std::ostringstream ss;
    ss << "{";
    size_t i = 0;
    for (const auto &kv : v.dict()) {
      ss << kv.first << ": ";
      ss << valueToString(kv.second);
      if (i < v.dict().size() - 1)
        ss << ", ";
      i++;
    }
    ss << "}";
    return ss.str();
  }

  if (v.isMatrix) {
    std::ostringstream ss;
    ss << "[\n";

    // A complex cell prints both parts; a real matrix takes the same
    // formatNumber() route it always has.
    const bool hasComplexCells = v.hasComplex();

    for (size_t i = 0; i < v.rows(); i++) {
      ss << "  [";

      for (size_t j = 0; j < v.rowLength(i); j++) {
        std::complex<double> cell = hasComplexCells ? v.cnumAt(i, j) : std::complex<double>();
        if (cell.imag() != 0.0)
          ss << formatComplex(cell.real(), cell.imag());
        else
          ss << formatNumber(v.numAt(i, j));
        if (j < v.rowLength(i) - 1)
          ss << ",";
      }

      ss << "]";
      if (i < v.rows() - 1)
        ss << ",";

      ss << "\n";
    }

    ss << "]";
    return ss.str();
  }

  if (v.isArray) {
    std::ostringstream ss;
    ss << "[";

    for (size_t i = 0; i < v.length(); i++) {
      // Recurse instead of special-casing isText/number here: an element
      // can itself be an array/matrix/dict (e.g. onlyRows()/onlyCols()
      // return an array of arrays) - reading its .number directly, as
      // this used to, silently defaults to 0 for any non-scalar element
      // instead of rendering its actual contents.
      ss << valueToString(v.at(i));
      if (i < v.length() - 1)
        ss << ",";
    }

    ss << "]";
    return ss.str();
  }

  // Dimensional Integrity: append a compact unit suffix (e.g. "m/s",
  // "m/s^2", "kg*m/s^2") when the value carries a non-zero dimension —
  // every pre-existing numeric value has dimL=dimT=dimM=0 (unitless), so
  // this is purely additive and doesn't change output for anything that
  // predates this pillar. Built generically from the exponents rather than
  // a curated name table (e.g. doesn't special-case printing dimM=1,dimL=1,
  // dimT=-2 back out as "N") — correct and readable, just not the
  // prettiest possible spelling.
  std::string numStr = v.isComplex ? formatComplex(v.number, v.imag) : formatNumber(v.number);
  if (v.dimL == 0 && v.dimT == 0 && v.dimM == 0)
    return numStr;

  auto appendDim = [](std::vector<std::string> &parts, const char *symbol, int exp) {
    if (exp == 0) return;
    parts.push_back(exp == 1 ? symbol : (std::string(symbol) + "^" + std::to_string(exp)));
  };
  std::vector<std::string> numerator, denominator;
  auto classify = [&](const char *symbol, int exp) {
    if (exp > 0) appendDim(numerator, symbol, exp);
    else if (exp < 0) appendDim(denominator, symbol, -exp);
  };
  classify("m", v.dimL);
  classify("s", v.dimT);
  classify("kg", v.dimM);

  std::ostringstream unitSs;
  for (size_t i = 0; i < numerator.size(); i++) {
    if (i > 0) unitSs << "*";
    unitSs << numerator[i];
  }
  if (numerator.empty())
    unitSs << "1";
  if (!denominator.empty()) {
    unitSs << "/";
    for (size_t i = 0; i < denominator.size(); i++) {
      if (i > 0) unitSs << "*";
      unitSs << denominator[i];
    }
  }

  return numStr + " " + unitSs.str();
}

void printValue(const std::string &name, const Value &v) {
  if (!name.empty()) {
    std::cout << name << " = ";
  }

  std::cout << valueToString(v) << std::endl;
}

/* ================= FORMAT ================= */
std::string formatComplex(double re, double im) {
  // The sign sits between the parts, so the imaginary part itself is
  // printed unsigned ("3-4i", not "3+-4i").
  return formatNumber(re) + (std::signbit(im) ? "-" : "+") + formatNumber(std::fabs(im)) + "i";
}

std::string formatNumber(double value) {
  // Was snapping ANY value below 1e-10 in magnitude to exactly 0 -
  // presumably meant to clean up float noise from cancellation (e.g.
  // sin(pi) landing on ~1.2246e-16 instead of an exact 0), but an
  // ABSOLUTE magnitude threshold can't coexist with a language whose own
  // built-in physical constants span from ~6e23 (avogadro) down to
  // ~6.6e-34 (planck's constant, h) - any threshold aggressive enough to
  // catch that kind of float noise is, by construction, also small enough
  // to swallow a legitimate constant far tinier than the noise itself.
  // Confirmed by direct testing: this constants file's OWN h and
  // grav_const (6.674e-11) both silently printed as "0" instead of their
  // real values - not a display quirk, a completely wrong answer,
  // reproducible for any genuinely tiny result in ANY domain, since this
  // is the shared number-formatting function every printed Value routes
  // through. No magnitude threshold can be both "aggressive enough to
  // hide float noise" and "loose enough to show every legitimate tiny
  // value" for a language with this dynamic range - so this now only
  // treats an EXACT zero (the case a subtraction that mathematically
  // cancels completely, or a literal 0, actually produces) as "0";
  // genuinely near-zero-but-nonzero results now print in scientific
  // notation like every other tiny value, instead of being silently
  // discarded.
  std::ostringstream ss;

  if (value == 0) {
    ss << "0";
    return ss.str();
  }

  if (std::abs(value) < 1e-4 || std::abs(value) > 1e6)
    ss << std::scientific << value;
  else
    ss << std::fixed << value;

  std::string s = ss.str();

  if (s.find('e') == std::string::npos) {
    while (!s.empty() && s.back() == '0')
      s.pop_back();

    if (!s.empty() && s.back() == '.')
      s.pop_back();
  }

  return s;
}
