#include "elementwise.h"
#include "../ops/arithmetic/arithmetic.h" // tryCoerceTextToNumber
#include <iostream>

bool g_lastElementwiseOk = true;

namespace {
// A "plain scalar" for broadcasting purposes: not itself a container or a
// non-numeric kind. Used to reject e.g. `[1,2,3] + [[1,2],[3,4]]` (array +
// matrix) instead of silently reading the array's .number (0, since arrays
// don't set it) as if it were the scalar 0 - the array side used to vanish
// entirely, so the matrix came back completely unchanged with no error.
bool isBroadcastableScalar(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject;
}

// A dec2frac()/deci2frac() result is a "num/denom" TEXT Value that is only
// the human-readable display of a real number (see tryCoerceTextToNumber in
// arithmetic.cpp). Reads such a value as the number it stands for, so the
// scalar math builtins accept it the same way +,-,*,/,%,//,^ and '!' already
// do. Deliberately limited to text containing '/': any other text ("abc",
// "5.7") is still rejected by the guard below, so this only widens what is
// accepted for fractions and does not reopen the silent-0 bug for strings.
bool fractionTextToNumber(const Value &v, double &out) {
  return v.isText && v.text().find('/') != std::string::npos && tryCoerceTextToNumber(v, out);
}

// An element's numeric value: its coerced fraction if it is fraction text,
// otherwise its plain .number (unchanged behavior).
double elementNumber(const Value &v) {
  double d;
  return fractionTextToNumber(v, d) ? d : v.number;
}
} // namespace

Value mapElementwise(const Value &a, const std::function<double(double)> &fn) {
  g_lastElementwiseOk = true;
  // All-numeric array/matrix: run fn straight over the flat buffer.
  if ((a.isMatrix || a.isArray) && a.isPacked())
    return a.mapPacked(fn);

  if (a.isMatrix) {
    Value result = a;
    result.transformElems(
        [&fn](const Value &cell) { return Value(fn(elementNumber(cell))); });
    return result;
  }

  if (a.isArray) {
    Value result = a;
    result.transformElems(
        [&fn](const Value &elem) { return Value(fn(elementNumber(elem))); });
    return result;
  }

  // Was falling straight through to `fn(a.number)` for ANY remaining kind
  // of Value - including text and dict, whose `.number` defaults to 0 -
  // with no check at all, unlike zipElementwise() just below (which
  // already guards its own non-matrix side via isBroadcastableScalar()).
  // Every scalar builtin that routes through here (int()/round()/
  // rad2dec()/dec2rad() in dc.cpp, sin()/sqrt()/... in trigonometric.cpp/
  // arithmetic.cpp) silently returned 0 for text/dict input with zero
  // diagnostic - confirmed by direct testing (int("5.7") -> 0,
  // sin("abc") -> 0). Fixing it once here, centrally, closes it for every
  // caller at once, the same reasoning this file's own top comment already
  // gives for mapElementwise/zipElementwise existing in the first place.
  double fracValue;
  if (fractionTextToNumber(a, fracValue))
    return Value(fn(fracValue));

  if (!isBroadcastableScalar(a)) {
    std::cerr << "Error: expected a number, array, or matrix, not a "
              << (a.isText ? "string" : a.isDict ? "dict" : "object") << "\n";
    g_lastElementwiseOk = false;
    return Value(0);
  }

  return Value(fn(a.number));
}

/* ================= COMPLEX ================= */

namespace {
Cplx scalarC(const Value &v) { return Cplx(v.number, v.isComplex ? v.imag : 0.0); }

Value scalarResultC(Cplx z) {
  return z.imag() == 0.0 ? Value(z.real() + 0.0) : Value::complexNumber(z.real() + 0.0, z.imag());
}

// Every element of an array (in order) or matrix (column-major; an N-D
// matrix in its storage order) as a complex number. False for a matrix whose
// rows differ in length.
bool readElemsC(const Value &v, std::vector<Cplx> &out) {
  if (v.isND()) {
    const size_t n = v.ndCount();
    out.resize(n);
    for (size_t k = 0; k < n; k++)
      out[k] = v.ndCnumAt(k);
    return true;
  }
  if (v.isMatrix) {
    size_t rows = v.rows(), cols = v.cols();
    if (v.isPackedComplex()) {
      out.assign(v.packedComplexData(), v.packedComplexData() + rows * cols);
      return true;
    }
    out.resize(rows * cols);
    for (size_t r = 0; r < rows; r++) {
      if (v.rowLength(r) != cols)
        return false;
      for (size_t c = 0; c < cols; c++)
        out[c * rows + r] = v.cnumAt(r, c);
    }
    return true;
  }
  size_t n = v.length();
  if (v.isPackedComplex()) {
    out.assign(v.packedComplexData(), v.packedComplexData() + n);
    return true;
  }
  out.resize(n);
  for (size_t i = 0; i < n; i++)
    out[i] = v.cnumAt(i);
  return true;
}

// An array/matrix shaped like `like` holding `elems` (same order as
// readElemsC), unitless, narrowed to real when nothing imaginary is left.
Value containerResultC(const Value &like, const std::vector<Cplx> &elems) {
  if (elems.empty())
    return like;
  if (like.isND()) {
    std::vector<double> buf(2 * elems.size());
    for (size_t k = 0; k < elems.size(); k++) {
      buf[2 * k] = elems[k].real();
      buf[2 * k + 1] = elems[k].imag();
    }
    Value result = Value::ndPacked(like.ndShape(), std::move(buf), true);
    result.narrowIfReal();
    return result;
  }
  Value result = like.isMatrix
                     ? Value::packedComplexMatrix(elems.data(), like.rows(), like.cols())
                     : Value::packedComplexArray(elems.data(), elems.size());
  result.narrowIfReal();
  return result;
}

Value failC(const char *message) {
  std::cerr << message;
  g_lastElementwiseOk = false;
  return Value(0);
}
} // namespace

Value mapElementwiseC(const Value &a, const std::function<Cplx(Cplx)> &fn) {
  g_lastElementwiseOk = true;
  if (a.isMatrix || a.isArray) {
    std::vector<Cplx> elems;
    if (!readElemsC(a, elems))
      return failC("Error: mismatched matrix dimensions in elementwise operation\n");
    for (Cplx &z : elems)
      z = fn(z);
    return containerResultC(a, elems);
  }
  if (!isBroadcastableScalar(a)) {
    std::cerr << "Error: expected a number, array, or matrix, not a "
              << (a.isText ? "string" : a.isDict ? "dict" : "object") << "\n";
    g_lastElementwiseOk = false;
    return Value(0);
  }
  return scalarResultC(fn(scalarC(a)));
}

Value mapElementwisePromoting(const Value &a, const std::function<double(double)> &realFn,
                               bool (*outsideRealDomain)(double),
                               const std::function<Cplx(Cplx)> &complexFn) {
  // Does any element fall outside the real domain?
  bool promote = false;
  if ((a.isArray || a.isMatrix) && a.isPacked()) {
    const size_t n = a.isND() ? a.ndCount() : a.isMatrix ? a.rows() * a.cols() : a.length();
    const double *data = a.packedData();
    // A yes/no over every element: on several cores when large (the
    // answer cannot depend on the order the blocks are looked at).
    const nc::par::Outcome r = nc::par::reduceBlocks(
        n, nc::par::reduce(1.0), "domain check", false,
        [&](size_t begin, size_t end) {
          for (size_t k = begin; k < end; k++)
            if (outsideRealDomain(data[k]))
              return true;
          return false;
        },
        [](bool acc, bool part) { return acc || part; }, promote);
    if (r != nc::par::Outcome::Done) {
      g_lastElementwiseOk = false; // Stop pressed
      return Value(0);
    }
  } else if (a.isArray) {
    for (size_t i = 0; i < a.length() && !promote; i++)
      promote = outsideRealDomain(elementNumber(a.at(i)));
  } else if (a.isND()) {
    for (size_t k = 0; k < a.ndCount() && !promote; k++)
      promote = outsideRealDomain(elementNumber(a.ndAt(k)));
  } else if (a.isMatrix) {
    for (size_t r = 0; r < a.rows() && !promote; r++)
      for (size_t c = 0; c < a.rowLength(r) && !promote; c++)
        promote = outsideRealDomain(elementNumber(a.at(r, c)));
  } else {
    double fracValue;
    if (fractionTextToNumber(a, fracValue))
      promote = outsideRealDomain(fracValue);
    else if (isBroadcastableScalar(a))
      promote = outsideRealDomain(a.number);
  }

  // Every caller passes a pure realFn (sqrt, log, inv_sin ...; see the
  // header), so the common all-real case may use the multicore path.
  if (!promote)
    return mapElementwisePure(a, [&realFn](double x) { return realFn(x); });

  // Elements that ARE inside the real domain still get realFn, so they come
  // out bit-for-bit what they would be without a promoted neighbour.
  auto perElement = [&](Cplx z) {
    if (z.imag() == 0.0 && !outsideRealDomain(z.real()))
      return Cplx(realFn(z.real()), 0.0);
    return complexFn(z);
  };

  // Fraction text ("-1/2") is read as its number, as mapElementwise() does.
  double fracValue;
  if (fractionTextToNumber(a, fracValue))
    return mapElementwiseC(Value(fracValue), perElement);
  if ((a.isArray || a.isMatrix) && !a.isPacked()) {
    Value numbers = a;
    numbers.transformElems([](const Value &elem) { return Value(elementNumber(elem)); });
    return mapElementwiseC(numbers, perElement);
  }
  return mapElementwiseC(a, perElement);
}

Value zipElementwiseC(const Value &a, const Value &b,
                       const std::function<Cplx(Cplx, Cplx)> &fn) {
  g_lastElementwiseOk = true;
  const bool aContainer = a.isMatrix || a.isArray;
  const bool bContainer = b.isMatrix || b.isArray;

  if (!aContainer && !bContainer)
    return scalarResultC(fn(scalarC(a), scalarC(b)));

  if (aContainer && bContainer) {
    // Same pairing rules as zipElementwise(): matrix with matrix, array with
    // array, and never one with the other.
    if (a.isMatrix != b.isMatrix)
      return failC("Error: cannot combine a matrix with an array in an elementwise operation\n");
    if ((a.isND() || b.isND()) && (!a.isND() || !b.isND() || a.ndShape() != b.ndShape()))
      return failC("Error: mismatched matrix dimensions in elementwise operation\n");
    if (a.isMatrix && (a.rows() != b.rows() || (a.rows() != 0 && a.cols() != b.cols())))
      return failC("Error: mismatched matrix dimensions in elementwise operation\n");
    if (a.isArray && a.length() != b.length())
      return failC("Error: mismatched array lengths in elementwise operation\n");
    std::vector<Cplx> x, y;
    if (!readElemsC(a, x) || !readElemsC(b, y))
      return failC("Error: mismatched matrix dimensions in elementwise operation\n");
    for (size_t k = 0; k < x.size(); k++)
      x[k] = fn(x[k], y[k]);
    return containerResultC(a, x);
  }

  // One container and one scalar, which is broadcast over every element.
  const Value &container = aContainer ? a : b;
  const Value &other = aContainer ? b : a;
  if (!isBroadcastableScalar(other)) {
    return failC(container.isMatrix
                     ? "Error: cannot combine a matrix with a non-scalar value in an "
                       "elementwise operation\n"
                     : "Error: cannot combine an array with a non-scalar value in an "
                       "elementwise operation\n");
  }
  std::vector<Cplx> elems;
  if (!readElemsC(container, elems))
    return failC("Error: mismatched matrix dimensions in elementwise operation\n");
  const Cplx s = scalarC(other);
  for (Cplx &z : elems)
    z = aContainer ? fn(z, s) : fn(s, z);
  return containerResultC(container, elems);
}

Value zipElementwise(const Value &a, const Value &b,
                      const std::function<double(double, double)> &fn) {
  g_lastElementwiseOk = true;
  // An N-D matrix: with one of the same shape, or with a single value.
  if (a.isND() || b.isND()) {
    const bool aContainer = a.isMatrix || a.isArray, bContainer = b.isMatrix || b.isArray;
    if (aContainer && bContainer) {
      if (!a.isND() || !b.isND() || a.ndShape() != b.ndShape()) {
        std::cerr << "Error: mismatched matrix dimensions in elementwise operation\n";
        g_lastElementwiseOk = false;
        return Value(0);
      }
      if (a.sameShapeAs(b))
        return a.zipPacked(b, fn);
      Value result = a;
      for (size_t k = 0; k < a.ndCount(); k++)
        result.ndSetAt(k, Value(fn(a.ndNumAt(k), b.ndNumAt(k))));
      return result;
    }
    const Value &mat = aContainer ? a : b;
    const Value &other = aContainer ? b : a;
    if (!isBroadcastableScalar(other)) {
      std::cerr << "Error: cannot combine a matrix with a non-scalar value in an elementwise "
                   "operation\n";
      g_lastElementwiseOk = false;
      return Value(0);
    }
    const double scalar = other.number;
    if (mat.isPacked())
      return mat.mapPacked([&](double x) { return aContainer ? fn(x, scalar) : fn(scalar, x); });
    Value result = mat;
    result.transformElems([&](const Value &cell) {
      return Value(aContainer ? fn(cell.number, scalar) : fn(scalar, cell.number));
    });
    return result;
  }
  if (a.isMatrix || b.isMatrix) {
    if (a.isMatrix && b.isMatrix) {
      if (a.rows() != b.rows() ||
          (a.rows() != 0 && a.cols() != b.cols())) {
        std::cerr << "Error: mismatched matrix dimensions in elementwise operation\n";
        g_lastElementwiseOk = false;
        return Value(0);
      }
      if (a.sameShapeAs(b))
        return a.zipPacked(b, fn);
      Value result = a;
      for (size_t r = 0; r < result.rows(); r++)
        for (size_t c = 0; c < result.rowLength(r); c++)
          result.setAt(r, c, Value(fn(a.numAt(r, c), b.numAt(r, c))));
      return result;
    }

    // One side is a matrix; the other must be a genuine plain scalar to
    // broadcast - anything else (an array, text, a dict/object) is just as
    // invalid a combination as mismatched matrix dimensions above, not a
    // silent "treat it as 0" case (see isBroadcastableScalar()'s comment).
    const Value &nonMatrixSide = a.isMatrix ? b : a;
    if (!isBroadcastableScalar(nonMatrixSide)) {
      std::cerr << "Error: cannot combine a matrix with "
                << (nonMatrixSide.isArray ? "an array" : "a non-scalar value")
                << " in an elementwise operation\n";
      g_lastElementwiseOk = false;
      return Value(0);
    }

    const Value &mat = a.isMatrix ? a : b;
    double scalar = a.isMatrix ? b.number : a.number;
    bool matrixIsLeft = a.isMatrix;
    if (mat.isPacked())
      return mat.mapPacked(
          [&](double x) { return matrixIsLeft ? fn(x, scalar) : fn(scalar, x); });
    Value result = mat;
    result.transformElems([&](const Value &cell) {
      return Value(matrixIsLeft ? fn(cell.number, scalar) : fn(scalar, cell.number));
    });
    return result;
  }

  if (a.isArray || b.isArray) {
    if (a.isArray && b.isArray) {
      if (a.length() != b.length()) {
        std::cerr << "Error: mismatched array lengths in elementwise operation\n";
        g_lastElementwiseOk = false;
        return Value(0);
      }
      if (a.sameShapeAs(b))
        return a.zipPacked(b, fn);
      Value result = a;
      for (size_t i = 0; i < result.length(); i++)
        result.setAt(i, Value(fn(a.numAt(i), b.numAt(i))));
      return result;
    }

    // Same reasoning as the matrix case above - the matrix branch already
    // excludes an array ever reaching here paired with an actual matrix, so
    // the only remaining invalid pairing is array + (text/dict/object).
    const Value &nonArraySide = a.isArray ? b : a;
    if (!isBroadcastableScalar(nonArraySide)) {
      std::cerr << "Error: cannot combine an array with a non-scalar value in an "
                   "elementwise operation\n";
      g_lastElementwiseOk = false;
      return Value(0);
    }

    const Value &arr = a.isArray ? a : b;
    double scalar = a.isArray ? b.number : a.number;
    bool arrayIsLeft = a.isArray;
    if (arr.isPacked())
      return arr.mapPacked(
          [&](double x) { return arrayIsLeft ? fn(x, scalar) : fn(scalar, x); });
    Value result = arr;
    result.transformElems([&](const Value &elem) {
      return Value(arrayIsLeft ? fn(elem.number, scalar) : fn(scalar, elem.number));
    });
    return result;
  }

  return Value(fn(a.number, b.number));
}
