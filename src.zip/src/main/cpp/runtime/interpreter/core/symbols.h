#pragma once

#include <string>
#include <unordered_map>

/* SYMBOL TABLE */

static std::unordered_map<std::string,std::string> symbol_table =
{
    {"pi","π"},
    {"sigma","σ"},
    {"alpha","α"},
    {"beta","β"},
    {"gamma","γ"},
    {"theta","θ"},
    {"lambda","λ"},
    {"mu","μ"},
    {"omega","ω"},
    {"delta","δ"},
    {"phi","φ"},
    {"rho","ρ"},
    {"tau","τ"},
    {"eta","η"}
};

/* SYMBOL CONVERSION */

inline std::string getSymbol(const std::string& name)
{
    auto it = symbol_table.find(name);

    if(it != symbol_table.end())
        return it->second;
    return name;
}