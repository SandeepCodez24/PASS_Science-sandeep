#pragma once
// runtime/interpreter/core/range_spec.h
//
// The ONE definition of what a range literal holds (2026-11-20,
// docs/design_fix_1_4.md section 2). Used by:
//   - the tree-walker's RangeLiteral ([a:b], [a:s:b], (a:b], [a:b) ...),
//     parser_factor.cpp, which now writes the values straight into a packed
//     buffer, several cores at once for a long range;
//   - the tree-walker's `for i = <range>` (parser_exec_stmt.cpp), which no
//     longer builds the range at all - it computes each value as it goes;
//   - the JIT's compiled for-range loop, through nc_bridge_range_iteration_
//     count() and nc_bridge_range_value() (value_bridge.cpp), so compiled
//     and interpreted loops see the same numbers, bit for bit.
//
// Rule (MATLAB / NumPy style):
//   first   = start, or start + step after a '(' left bracket
//   element k = first + k * step        (never a running sum: no drift)
//   count   = how many k >= 0 keep the element on the near side of `end`:
//               ']'  k <= q + tol      q = (end - first) / step
//               ')'  k <  q - tol
//             tol = 1e-10 of a step, raised to 4 ulps of the larger of
//             |first| and |end| when that is bigger, so a range whose end is
//             a whole number of steps away keeps (']') or drops (')') it
//             despite rounding in q - [0:0.1:0.3] has 4 elements, [0:0.1:0.3)
//             has 3.
//   With ']' and the end reached within tol, the last element IS `end`
//   ([0:0.1:0.3] ends in 0.3, not 0.30000000000000004).
//
// Before 2026-11-20 the values were a running sum (v += step) with an
// absolute 1e-9 tolerance on the end: 62.8 M steps of 1e-7 drifted by 3e-9,
// and a step below 1e-9 took extra elements past the end.

#include <cmath>
#include <cstdint>
#include <limits>

namespace ncrange {

// Ranges longer than this are refused (more than any memory holds as
// doubles; also the limit of exact integer counting in a double).
constexpr double kMaxCount = 9007199254740992.0; // 2^53

struct Spec {
  double first = 0;    // the first element
  double step = 1;     // non-zero
  double end = 0;      // the bound as written
  bool closed = true;  // ']' (end may be included) vs ')'
  int64_t count = 0;   // number of elements; -1: unbounded / not a number
  bool snapLast = false; // last element is exactly `end`
};

// start, step, end as written; leftBracket '[' or '(', rightBracket ']' or ')'.
// step must already be known non-zero (the callers report a zero step).
inline Spec make(double start, double step, double end, char leftBracket, char rightBracket) {
  Spec s;
  s.step = step;
  s.end = end;
  s.closed = rightBracket != ')';
  s.first = leftBracket == '(' ? start + step : start;
  const double q = (end - s.first) / step;
  if (std::isnan(q)) {
    s.count = 0; // a NaN anywhere: nothing satisfies the comparison
    return s;
  }
  if (std::isinf(q) || std::fabs(q) >= kMaxCount) {
    s.count = q < 0 ? 0 : -1;
    return s;
  }
  const double eps = std::numeric_limits<double>::epsilon();
  const double tol =
      std::fmax(1e-10, 4 * eps * std::fmax(std::fabs(s.first), std::fabs(end)) / std::fabs(step));
  if (s.closed) {
    const double top = std::floor(q + tol);
    s.count = top < 0 ? 0 : static_cast<int64_t>(top) + 1;
    s.snapLast = s.count > 0 && std::fabs(q - static_cast<double>(s.count - 1)) <= tol;
  } else {
    const double top = std::ceil(q - tol);
    s.count = top < 0 ? 0 : static_cast<int64_t>(top);
  }
  return s;
}

// Element k (0 <= k < count). No fused multiply-add, on any CPU baseline:
// the JIT calls this same function, and the values must not depend on how
// either side was compiled.
inline double valueAt(const Spec &s, int64_t k) {
#if defined(__clang__)
#pragma clang fp contract(off) // scoped to this function body
#endif
  if (s.snapLast && k == s.count - 1)
    return s.end;
  const double offset = static_cast<double>(k) * s.step;
  return s.first + offset;
}

} // namespace ncrange
