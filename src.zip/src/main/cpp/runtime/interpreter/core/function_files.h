// Function files (2026-11-17, docs/Process_Window_CPP.md P1).
//
// A call that names no function of the running script and no built-in looks
// for <name>.nc, in this order:
//   (a) the folder of the script that is running,
//   (b) the current folder,
//   (c) the addpath folders, in order,
//   (d) the personal function library, always - so a function saved there
//       (the Process Data window's "Set as a Function") works from every
//       project, the Command Window and a plain terminal alike:
//         Windows        %USERPROFILE%\.neuralcode\process_functions\
//         macOS / Linux  $HOME/.neuralcode/process_functions/
//       NC_FUNCTION_LIBRARY, when set, names another folder (tests).
//
// The file's FIRST function must have the file's name (exactly, case
// included, on every OS): it is the one called. The functions after it are
// its helpers, visible only to the functions of that file. Anything else in
// the file except comments is refused. Parsing and registering is the
// Parser's part (parser_function_files.cpp); this module only knows where
// to look, with no Parser in sight, so ScriptManager can feed it folders.
#ifndef NC_FUNCTION_FILES_H
#define NC_FUNCTION_FILES_H

#include <filesystem>
#include <functional>
#include <optional>
#include <string>
#include <vector>

namespace nc {
namespace fnfiles {

// The folders (a)-(c) above, in order. Set once by main.cpp from its
// ScriptManager; without a provider (the parity harness, tests) only the
// current folder is searched before the library.
using FolderProvider = std::function<std::vector<std::filesystem::path>()>;
void setFolderProvider(FolderProvider provider);

// Bumped whenever the folders above may have changed (a script by name
// starts or ends, the current folder or the path changes): the Parser's
// "not found" caches are dropped when it moves, so a name missed in one
// folder is looked up again in the next. One atomic read per check.
void foldersChanged();
unsigned long long foldersGeneration();

// The personal library folder (it may not exist).
std::filesystem::path libraryFolder();

// Every folder searched, in order, duplicates removed, the library last.
std::vector<std::filesystem::path> searchFolders();

// The file for `name`: the first <folder>/<name>.nc that exists as a regular
// file whose name matches exactly (case included, also on a case-insensitive
// file system). Empty when there is none, or when `name` cannot be a file
// name (empty, a path separator, a dot ...).
std::optional<std::filesystem::path> find(const std::string &name);

} // namespace fnfiles
} // namespace nc

#endif // NC_FUNCTION_FILES_H
