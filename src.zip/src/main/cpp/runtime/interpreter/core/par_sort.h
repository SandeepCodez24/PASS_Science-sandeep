#pragma once
// runtime/interpreter/core/par_sort.h
//
// A stable sort on several cores (2026-11-20). A stable sort's result is
// fully determined by the input and the comparison, so this gives exactly
// what one std::stable_sort gives - only faster: fixed-size runs are sorted
// at the same time, then neighbouring runs are merged pairwise (in order,
// so equal elements keep their order), each round's merges at the same time.

#include <algorithm>
#include <cstddef>
#include <vector>

#include "parallel/par.h"
#include "value.h"

namespace ncsort {

// Below this many elements one std::stable_sort is used.
constexpr size_t kParallelFrom = 1u << 16;
constexpr size_t kRun = 1u << 15; // elements per first-round run

template <class T, class Less> void stableSort(T *first, T *last, Less less) {
  const size_t n = static_cast<size_t>(last - first);
  if (n < kParallelFrom) {
    std::stable_sort(first, last, less);
    return;
  }
  const size_t runs = (n + kRun - 1) / kRun;
  auto sortRun = [&](size_t r) {
    T *b = first + r * kRun;
    std::stable_sort(b, std::min(b + kRun, last), less);
  };
  if (nc::par::tasks(runs, 2000000.0, "sort", sortRun) != nc::par::Outcome::Done)
    for (size_t r = 0; r < runs; r++) // a Stop cut it short: finish here (same result)
      sortRun(r);
  for (size_t width = kRun; width < n; width *= 2) {
    const size_t pairs = (n + 2 * width - 1) / (2 * width);
    auto mergePair = [&](size_t p) {
      T *b = first + p * 2 * width;
      if (static_cast<size_t>(last - b) <= width)
        return; // a lone run at the end
      T *mid = b + width;
      T *e = std::min(b + 2 * width, last);
      std::inplace_merge(b, mid, e, less);
    };
    if (nc::par::tasks(pairs, static_cast<double>(width) * 4.0, "sort", mergePair) !=
        nc::par::Outcome::Done) {
      // Stop: the merges of this round may be half done; redo the whole
      // sort serially so the result is still exactly right.
      std::stable_sort(first, last, less);
      return;
    }
  }
}

/* ---- external stable sort (2026-11-23, Phase 3, docs/Large_Data_Design.md 18) ----

   For data larger than memory: the n input elements (read(first, m, out)
   gives elements first .. first+m-1, from any thread) are sorted chunk by
   chunk in RAM (stableSort above), each sorted chunk ("run") is written to
   `runs` - an nc::F64Buf, so on disk when it does not fit - and then all
   runs are merged at once into `out` (also on disk when needed): the output
   is cut into segments at sampled values, each run's part of a segment is
   found by binary search (lower_bound: elements equal to a cut value all go
   right of it, in every run), and the segments are merged at the same time
   on several cores, ties taken in run order. A stable sort's result is
   fully determined by the input and the comparison, so this is exactly
   what stableSort / std::stable_sort give - -0 and +0 keep their order.

   reject(x): true stops the sort (*rejected = true) - sort() refuses NaN on
   this path. Returns false when Stop was pressed or something was rejected.
   `chunk`: elements sorted in RAM at a time (the caller sizes it to the
   free memory). */
template <class Read, class Less, class Reject>
bool externalSort(size_t n, Read read, Less less, Reject reject, size_t chunk, nc::F64Buf &out,
                  bool &rejected) {
  rejected = false;
  chunk = std::max<size_t>(1, std::min(chunk, n));
  const size_t chunks = (n + chunk - 1) / chunk;
  nc::F64Buf runs(n); // RAM, or a file on disk (nc::mem::bufferAllocate)
  nc::par::SerialProgress progress("sort", chunks + 1);
  {
    nc::F64Buf tmp(chunk);
    for (size_t c = 0; c < chunks; c++) {
      progress.at(c);
      const size_t b = c * chunk, m = std::min(chunk, n - b);
      double *t = tmp.data();
      if (nc::par::forBlocks(m, nc::par::stream(3.0), "sort", [&](size_t x, size_t y) {
            read(b + x, y - x, t + x);
          }) != nc::par::Outcome::Done)
        return false;
      bool bad = false;
      nc::par::reduceBlocks(
          m, nc::par::reduce(1.0), "sort", false,
          [&](size_t x, size_t y) {
            for (size_t i = x; i < y; i++)
              if (reject(t[i]))
                return true;
            return false;
          },
          [](bool acc, bool part) { return acc || part; }, bad);
      if (bad) {
        rejected = true;
        return false;
      }
      stableSort(t, t + m, less);
      double *dst = runs.data() + b;
      if (nc::par::forBlocks(m, nc::par::stream(1.0), "sort", [&](size_t x, size_t y) {
            std::copy(t + x, t + y, dst + x);
          }) != nc::par::Outcome::Done)
        return false;
    }
  }
  // Cut values: evenly spaced samples of every run, sorted.
  const size_t parts = static_cast<size_t>(std::max(1, nc::par::threadCount())) * 4;
  std::vector<double> samples;
  for (size_t c = 0; c < chunks; c++) {
    const size_t b = c * chunk, m = std::min(chunk, n - b);
    for (size_t k = 1; k < parts; k++)
      samples.push_back(runs[b + m * k / parts]);
  }
  std::stable_sort(samples.begin(), samples.end(), less);
  std::vector<double> cuts;
  for (size_t j = 1; j < parts && !samples.empty(); j++)
    cuts.push_back(samples[samples.size() * j / parts]);
  const size_t segs = cuts.size() + 1;
  // bound[j][c]: where segment j starts in run c.
  std::vector<std::vector<size_t>> bound(segs + 1, std::vector<size_t>(chunks));
  for (size_t c = 0; c < chunks; c++) {
    const size_t b = c * chunk, e = std::min(n, b + chunk);
    bound[0][c] = b;
    bound[segs][c] = e;
    for (size_t j = 1; j < segs; j++)
      bound[j][c] = static_cast<size_t>(
          std::lower_bound(runs.data() + bound[j - 1][c], runs.data() + e, cuts[j - 1], less) - runs.data());
  }
  std::vector<size_t> offset(segs + 1, 0);
  for (size_t j = 0; j < segs; j++) {
    size_t len = 0;
    for (size_t c = 0; c < chunks; c++)
      len += bound[j + 1][c] - bound[j][c];
    offset[j + 1] = offset[j] + len;
  }
  out = nc::F64Buf(n); // RAM, or disk
  const double *r = runs.data();
  double *o = out.data();
  auto mergeSegment = [&](size_t j) {
    std::vector<size_t> at(chunks), end(chunks);
    for (size_t c = 0; c < chunks; c++) {
      at[c] = bound[j][c];
      end[c] = bound[j + 1][c];
    }
    // Run c's head comes before run d's: smaller, or equal and an earlier
    // run (ties in run order - the stable order).
    auto before = [&](size_t c, size_t d) {
      const double x = r[at[c]], y = r[at[d]];
      return less(x, y) || (!less(y, x) && c < d);
    };
    if (chunks <= 8) {
      for (size_t w = offset[j]; w < offset[j + 1]; w++) {
        size_t best = chunks;
        for (size_t c = 0; c < chunks; c++)
          if (at[c] < end[c] && (best == chunks || less(r[at[c]], r[at[best]])))
            best = c; // strictly smaller only: ties stay with the earlier run
        o[w] = r[at[best]++];
      }
      return;
    }
    // Many runs (little free memory, small chunks): a binary min-heap of
    // the runs that still have elements, log(runs) per element.
    std::vector<size_t> heap;
    for (size_t c = 0; c < chunks; c++)
      if (at[c] < end[c])
        heap.push_back(c);
    auto siftDown = [&](size_t i) {
      const size_t h = heap.size();
      while (true) {
        size_t m = i;
        const size_t a = 2 * i + 1, b = 2 * i + 2;
        if (a < h && before(heap[a], heap[m]))
          m = a;
        if (b < h && before(heap[b], heap[m]))
          m = b;
        if (m == i)
          return;
        std::swap(heap[i], heap[m]);
        i = m;
      }
    };
    for (size_t i = heap.size() / 2; i-- > 0;)
      siftDown(i);
    for (size_t w = offset[j]; w < offset[j + 1]; w++) {
      const size_t c = heap[0];
      o[w] = r[at[c]++];
      if (at[c] == end[c]) {
        heap[0] = heap.back();
        heap.pop_back();
      }
      if (!heap.empty())
        siftDown(0);
    }
  };
  progress.at(chunks);
  if (nc::par::tasks(segs, static_cast<double>(n / segs) * 10.0, "sort merge", mergeSegment) !=
      nc::par::Outcome::Done)
    return false;
  return true;
}

} // namespace ncsort
