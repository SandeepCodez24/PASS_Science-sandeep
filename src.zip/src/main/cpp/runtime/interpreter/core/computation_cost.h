#pragma once

// How many elementary operations ("computations") an operator or a builtin
// call counts as, for the IDE's "No. of Computation" (runtime/execution/
// analysis/analysis.h). An estimate, by design cheap to compute (no walk
// over the data, only sizes):
//
//   element count of a value  number/bool/text: 1; array: its length;
//                             matrix: rows*cols; N-D: all elements;
//                             dict: its entries
//   a + b, a .* b, sin(x) ... the larger element count of the operands
//   A * B (both matrices)     m*k*n  (the multiply-adds of the product)
//   inv, det, solve, svd, qr, eig ... of an n x n matrix: n^3
//   any other builtin         max(elements in, elements out), at least 1
//                             (sum(A) reads all of A; zeros(1000, 1000)
//                             writes a million)
//
// The order of growth only needs the count to be proportional to the real
// work, which these rules are; the absolute numbers are estimates.

#include <algorithm>
#include <cstdint>
#include <string>
#include <vector>

#include "value.h"

namespace nc::analysis {

inline uint64_t elementCount(const Value &v) {
  if (v.isND())
    return std::max<uint64_t>(1, v.ndCount());
  if (v.isMatrix) {
    const uint64_t r = v.rows();
    return std::max<uint64_t>(1, r * (r ? v.cols() : 0));
  }
  if (v.isArray)
    return std::max<uint64_t>(1, v.length());
  if (v.isDict)
    return std::max<uint64_t>(1, v.dict().size());
  return 1;
}

inline uint64_t binaryOpCost(const std::string &op, const Value &a, const Value &b) {
  if (op == "*" && a.isMatrix && b.isMatrix && !a.isND() && !b.isND()) {
    const uint64_t m = a.rows(), k = m ? a.cols() : 0, n = b.rows() ? b.cols() : 0;
    return std::max<uint64_t>(1, m * k * n);
  }
  return std::max(elementCount(a), elementCount(b));
}

// Decompositions and solvers: about n^3 for an n x n input.
inline bool isCubicBuiltin(const std::string &name) {
  static const char *const kCubic[] = {
      "inv",    "det",      "solve",   "lstsq",   "pinv",     "pseudo_inverse", "svd",   "svdvals",
      "qr",     "eig",      "eigh",    "eigvals", "eigvalsh", "cholesky",       "lu",    "rank",
      "cond",   "expm",     "logm",    "sqrtm",   "null_space", "orth",         "adj",   "matrix_power",
      "tensorinv", "tensorsolve", "lu_factor", "lu_solve", "schur", "hessenberg", "polar", "funm"};
  for (const char *c : kCubic)
    if (name == c)
      return true;
  return false;
}

inline uint64_t builtinCost(const std::string &name, const std::vector<Value> &args, const Value &result) {
  if (!args.empty() && args[0].isMatrix && !args[0].isND() && isCubicBuiltin(name)) {
    const uint64_t r = args[0].rows(), c = r ? args[0].cols() : 0, n = std::max(r, c);
    return std::max<uint64_t>(1, n * n * n);
  }
  uint64_t in = 0;
  for (const Value &a : args)
    in += elementCount(a);
  return std::max<uint64_t>(1, std::max(in, elementCount(result)));
}

} // namespace nc::analysis
