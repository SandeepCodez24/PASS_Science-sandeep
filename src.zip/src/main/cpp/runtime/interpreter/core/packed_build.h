#pragma once
// runtime/interpreter/core/packed_build.h
//
// Fast paths between NC values and plain double buffers (2026-11-20,
// docs/design_fix_1_4.md section 2).
//
// The NumPy / SciPy helpers used to read every input element as its own
// Value (v.at(r, c), v.elems()) and to build every result as one Value per
// number, which the Value constructor then packed back into a flat buffer.
// That round trip cost 150 - 900 ns per element (a 32-byte Value, often a
// heap Box, per number, twice). These helpers do the same conversions
// straight on the packed buffer.
//
// Every function here gives EXACTLY the value the old element-by-element
// path gave (same shape, same unit, same storage order, same NaN payloads);
// each returns false / is not used where the old path would have done
// something else (text, ints, units on mixed cells, ragged rows, N-D ...),
// so callers keep their old code as the fallback.
//
// Orders: "row-major" = the last index fastest (how the helpers' callers
// read a matrix: row by row). A packed 2-D buffer is column-major.

#include <complex>
#include <cstddef>
#include <cstring>
#include <vector>

#include "parallel/par.h"
#include "value.h"

namespace ncpack {

// Below this many elements a transpose is done on one thread.
constexpr size_t kParallelTranspose = 1u << 16;

// out[r * C + c] = in[c * R + r] for an R x C column-major `in` (or the
// other way round with transposeTo(): the same loop, roles swapped). One
// row or one column needs no reordering at all.
template <class T>
inline void columnToRowMajor(const T *in, size_t R, size_t C, T *out) {
  const size_t n = R * C;
  if (R == 1 || C == 1) {
    std::memcpy(out, in, n * sizeof(T));
    return;
  }
  auto body = [&](size_t b, size_t e) {
    for (size_t r = b; r < e; r++)
      for (size_t c = 0; c < C; c++)
        out[r * C + c] = in[c * R + r];
  };
  if (n < kParallelTranspose ||
      nc::par::forBlocks(R, nc::par::stream(0.6 * static_cast<double>(C)), "transpose", body) !=
          nc::par::Outcome::Done)
    body(0, R); // small, or a Stop cut the parallel copy short: finish it here
}

template <class T>
inline void rowToColumnMajor(const T *in, size_t R, size_t C, T *out) {
  const size_t n = R * C;
  if (R == 1 || C == 1) {
    std::memcpy(out, in, n * sizeof(T));
    return;
  }
  auto body = [&](size_t b, size_t e) {
    for (size_t c = b; c < e; c++)
      for (size_t r = 0; r < R; r++)
        out[c * R + r] = in[r * C + c];
  };
  if (n < kParallelTranspose ||
      nc::par::forBlocks(C, nc::par::stream(0.6 * static_cast<double>(R)), "transpose", body) !=
          nc::par::Outcome::Done)
    body(0, C);
}

/* ---------------------------------------------------------------- reading */

// A packed real (float64) array or 2-D matrix: its numbers in row-major
// order - what reading v.at(i) / v.at(r, c) element by element and taking
// .number gave. False (out untouched) for anything else: cells, typed
// (int / bool / float32 ...) tensors, complex, N-D.
inline bool readRowMajor(const Value &v, std::vector<double> &out) {
  if (!v.isPacked() || v.isND())
    return false;
  if (v.isArray && v.tensorShape().size() == 1) {
    const size_t n = v.length();
    out.resize(n);
    if (n)
      std::memcpy(out.data(), v.packedData(), n * sizeof(double));
    return true;
  }
  if (v.isMatrix && v.tensorShape().size() == 2) {
    const size_t R = v.rows(), C = v.cols();
    out.resize(R * C);
    if (R * C)
      columnToRowMajor(v.packedData(), R, C, out.data());
    return true;
  }
  return false;
}

// Any packed float64 value - array, 2-D or N-D matrix - as numbers in
// row-major order of nd::shapeOf(v) (2-D pages, column-major inside a page,
// pages in row-major order of the leading axes; see nd_array.h). False for
// anything that is not packed float64.
inline bool readRowMajorAnyRank(const Value &v, std::vector<double> &out) {
  if (!v.isPacked())
    return false;
  if (!v.isND())
    return readRowMajor(v, out);
  const std::vector<size_t> &shape = v.tensorShape();
  const size_t R = shape[shape.size() - 2], C = shape[shape.size() - 1];
  const size_t n = v.tensorCount(), page = R * C;
  out.resize(n);
  for (size_t p = 0; page && p < n / page; p++)
    columnToRowMajor(v.packedData() + p * page, R, C, out.data() + p * page);
  return true;
}

// As readRowMajor(), as complex numbers: a packed real value gives imaginary
// parts 0, a packed complex one its own (what v.cnumAt() gave).
inline bool readRowMajorComplex(const Value &v, std::vector<std::complex<double>> &out) {
  if (v.isND())
    return false;
  if (v.isPacked()) {
    std::vector<double> re;
    if (!readRowMajor(v, re))
      return false;
    out.resize(re.size());
    for (size_t k = 0; k < re.size(); k++)
      out[k] = std::complex<double>(re[k], 0.0);
    return true;
  }
  if (!v.isPackedComplex() || v.isTypedPacked())
    return false;
  const std::complex<double> *data = v.packedComplexData();
  if (v.isArray && v.tensorShape().size() == 1) {
    out.assign(data, data + v.length());
    return true;
  }
  if (v.isMatrix && v.tensorShape().size() == 2) {
    const size_t R = v.rows(), C = v.cols();
    out.resize(R * C);
    if (R * C)
      columnToRowMajor(data, R, C, out.data());
    return true;
  }
  return false;
}

/* --------------------------------------------------------------- building */

// The unitless packed R x C matrix holding `rowMajor` (R, C > 0) - what
// Value(std::vector<std::vector<Value>>) of plain Value(d) cells gave.
inline Value matrixFromRowMajor(const double *rowMajor, size_t R, size_t C) {
  nc::F64Buf buf(R * C);
  rowToColumnMajor(rowMajor, R, C, buf.data());
  return Value::ndPacked({R, C}, std::move(buf), false);
}

// As above for complex cells. Every cell Value::complexNumber() made a
// complex tensor even where an imaginary part is 0, and so does this.
inline Value complexMatrixFromRowMajor(const std::complex<double> *rowMajor, size_t R, size_t C) {
  std::vector<std::complex<double>> colMajor(R * C);
  rowToColumnMajor(rowMajor, R, C, colMajor.data());
  nc::F64Buf buf(2 * R * C);
  std::memcpy(buf.data(), colMajor.data(), buf.size() * sizeof(double));
  return Value::ndPacked({R, C}, std::move(buf), true);
}

// A matrix of `shape` (rank >= 2, no zero axis) from plain numbers in
// row-major order - what nd::buildRowMajor() of Value(d) cells gave.
inline Value fromRowMajorShape(const std::vector<size_t> &shape, const std::vector<double> &x) {
  const size_t rank = shape.size();
  const size_t R = shape[rank - 2], C = shape[rank - 1];
  const size_t page = R * C;
  const size_t pages = page ? x.size() / page : 0;
  nc::F64Buf buf(x.size());
  for (size_t p = 0; p < pages; p++)
    rowToColumnMajor(x.data() + p * page, R, C, buf.data() + p * page);
  return Value::ndPacked(shape, std::move(buf), false);
}

} // namespace ncpack
