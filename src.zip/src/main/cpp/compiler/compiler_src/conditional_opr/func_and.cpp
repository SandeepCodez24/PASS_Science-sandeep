#include "conditional_opr.h"

/* ================= AND ================= */

Value logical_and(Value a, Value b) { return Value(a.number && b.number); }
