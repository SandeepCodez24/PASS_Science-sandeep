#include "conditional_opr.h"

/* ================= AND ================= */

// Was `a.number && b.number` - .number defaults to 0 for text/array/
// matrix/dict, so and("hello","hello") silently returned false while
// `if ("hello")` correctly took the true branch. Now uses the same
// truthiness the language's own if/while statements use.
Value logical_and(Value a, Value b) {
  return Value(valueIsTruthy(a) && valueIsTruthy(b) ? 1.0 : 0.0);
}
