#include "conditional_opr.h"

/* ================= EQUAL TO (==) ================= */

// Was `a.number == b.number`, which compared the unused numeric slot of
// every non-numeric Value — so any two strings/arrays/matrices/dicts came
// out equal. Now delegates to the shared structural comparison.
Value logical_eq(Value a, Value b) {
  return Value(valuesDeepEqual(a, b) ? 1.0 : 0.0);
}
