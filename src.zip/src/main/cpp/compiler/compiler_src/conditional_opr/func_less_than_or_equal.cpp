#include "conditional_opr.h"

/* ================= LESS THAN OR EQUAL (<=) ================= */

Value logical_lte(Value a, Value b) {
  return Value(valueOrderCompare(a, b) <= 0 ? 1.0 : 0.0);
}
