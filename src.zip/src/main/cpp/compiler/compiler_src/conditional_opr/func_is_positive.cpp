#include "conditional_opr.h"

/* ================= IS POSITIVE ================= */

Value is_positive(Value a) { return Value(a.number > 0); }
