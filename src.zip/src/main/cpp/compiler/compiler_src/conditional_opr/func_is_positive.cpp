#include "conditional_opr.h"
#include <iostream>

/* ================= IS POSITIVE ================= */

// Same numeric-only fix as is_zero() - see its comment.
Value is_positive(Value a) {
  if (valueKindOf(a) != VK_NUMBER) {
    std::cerr << "Error: is_positive expects a number, not a " << valueKindName(a) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }
  return Value(a.number > 0 ? 1.0 : 0.0);
}
