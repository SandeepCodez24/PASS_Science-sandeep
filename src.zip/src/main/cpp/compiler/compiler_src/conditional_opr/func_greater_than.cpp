#include "conditional_opr.h"
#include <iostream>

/* ================= GREATER THAN (>) ================= */

// Same non-orderable-input gap as logical_lt() - see its comment.
Value logical_gt(Value a, Value b) {
  if (!valueIsOrderable(a) || !valueIsOrderable(b) || valueKindOf(a) != valueKindOf(b)) {
    std::cerr << "Error: cannot order-compare " << valueKindName(a) << " with "
              << valueKindName(b) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }
  // IEEE-754: any ordering comparison with a NaN operand is false.
  if (valuesUnordered(a, b))
    return Value(0);
  return Value(valueOrderCompare(a, b) > 0 ? 1.0 : 0.0);
}
