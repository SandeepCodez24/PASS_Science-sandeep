#include "conditional_opr.h"

/* ================= GREATER THAN (>) ================= */

Value logical_gt(Value a, Value b) {
  return Value(valueOrderCompare(a, b) > 0 ? 1.0 : 0.0);
}
