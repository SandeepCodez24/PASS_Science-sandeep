#include "conditional_opr.h"

/* ================= IS EMPTY ================= */

// Was array-only - an empty string ("") or an empty dict ({}) weren't
// recognized as empty at all (is_empty("") silently returned false)
// despite the name implying general emptiness-checking. A number or an
// object instance has no empty/non-empty notion, same as valueIsTruthy()'s
// own convention for those two kinds.
Value is_empty(Value a)
{
    switch (valueKindOf(a)) {
    case VK_TEXT:
        return Value(a.text().empty() ? 1.0 : 0.0);
    case VK_ARRAY:
        return Value(a.length() == 0 ? 1.0 : 0.0);
    case VK_MATRIX:
        return Value(a.rows() == 0 ? 1.0 : 0.0);
    case VK_DICT:
        return Value(a.dict().empty() ? 1.0 : 0.0);
    default:
        return Value(0);
    }
}
