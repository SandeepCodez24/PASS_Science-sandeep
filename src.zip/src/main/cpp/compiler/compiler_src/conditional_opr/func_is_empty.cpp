#include "conditional_opr.h"

/* ================= IS EMPTY ================= */

Value is_empty(Value a)
{
    if (a.isArray && a.array.empty())
        return Value(1);

    return Value(0);
}
