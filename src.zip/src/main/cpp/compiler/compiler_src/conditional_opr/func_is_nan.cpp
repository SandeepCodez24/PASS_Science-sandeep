#include "conditional_opr.h"
#include <cmath>
#include <iostream>

/* ================= IS NAN ================= */

// Was reading a.number unconditionally - harmless in practice today (a
// non-number's .number defaults to 0, and 0 genuinely isn't NaN, so the
// answer happened to come out right by coincidence) but inconsistent with
// its siblings is_zero()/is_positive()/is_negative(), which now require an
// actual number rather than silently coercing. Matches them for the same
// reason: "is this NaN" isn't a meaningful question for a string/array/
// matrix/dict any more than "is this positive" was.
Value is_nan(Value a)
{
    if (valueKindOf(a) != VK_NUMBER) {
        std::cerr << "Error: is_nan expects a number, not a " << valueKindName(a) << "\n";
        g_lastConditionalOk = false;
        return Value(0);
    }
    // A complex number is NaN when either part is.
    if (std::isnan(a.number) || (a.isComplex && std::isnan(a.imag)))
        return Value(1);

    return Value(0);
}
