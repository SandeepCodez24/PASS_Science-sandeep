#include "conditional_opr.h"
#include <cmath>

/* ================= IS NAN ================= */

Value is_nan(Value a)
{
    if (std::isnan(a.number))
        return Value(1);

    return Value(0);
}
