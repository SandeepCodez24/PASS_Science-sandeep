#pragma once

#include "../../../runtime/interpreter/core/value.h"

#include <string>
#include <vector>

// Dispatcher for conditional builtins
Value conditionalBuiltin(const std::string &name,
                         const std::vector<Value> &args);
