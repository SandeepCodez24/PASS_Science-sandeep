#include "conditional_opr.h"

/* ================= LESS THAN (<) ================= */

// Numbers compare numerically, strings lexicographically. Non-orderable
// kinds (array/matrix/dict/object) are rejected by parseComparison()
// before reaching here.
Value logical_lt(Value a, Value b) {
  return Value(valueOrderCompare(a, b) < 0 ? 1.0 : 0.0);
}
