#pragma once

// Declarations for NC conditional/logical operator functions.
// Each function's implementation lives in its own func_<operator-name>.cpp
// file in this folder. Migrated from:
//   - runtime/interpreter/ops/conditional/conditional.cpp
//   - runtime/interpreter/ops/logical/logical.cpp

#include "../../../runtime/interpreter/core/value.h"

/* ================= VALUE COMPARISON CORE ================= */

// Implemented in value_compare.cpp. Shared by every comparison operator so
// they all agree on what "same value" means, instead of each one falling
// back to Value::number (which is 0 for strings, arrays, matrices, dicts
// and objects alike — the cause of "str" == "str2" reporting true).

enum ValueKind { VK_NUMBER, VK_TEXT, VK_ARRAY, VK_MATRIX, VK_DICT, VK_OBJECT };

ValueKind valueKindOf(const Value &v);
const char *valueKindName(const Value &v);

// Structural equality: recurses into arrays, matrices, dicts and object
// fields. Values of different kinds are never equal.
bool valuesDeepEqual(const Value &a, const Value &b);

// Only numbers and strings can be ordered (<, >, <=, >=).
bool valueIsOrderable(const Value &v);

// -1 / 0 / +1. Caller must have checked valueIsOrderable() on both sides
// and that they are the same kind.
int valueOrderCompare(const Value &a, const Value &b);

// True when a and b are numbers and at least one is NaN. IEEE-754: every
// ordering comparison (<, <=, >, >=) involving NaN is false, but
// valueOrderCompare() has no "unordered" result (it falls through to +1),
// so the four ordering operators must check this first.
bool valuesUnordered(const Value &a, const Value &b);

// The single definition of "truthy" for the whole language: what an `if`/
// `while` condition means, AND what and()/or()/not()/nand()/nor()/cond_if()/
// bool() below mean by their arguments. Before this existed, parser_
// exec_stmt.cpp had its own private `truthy()` (text: non-empty; anything
// else: number != 0) while every one of those logical_*/cond_if functions
// read `.number` directly instead - so the SAME value disagreed with
// itself depending on which of the two systems evaluated it: and("hello",
// "hello") returned false (a non-empty string's .number defaults to 0),
// while `if ("hello") ...` correctly took the true branch. Confirmed by
// direct testing. This is now the one place that decides, and parser_
// exec_stmt.cpp's truthy() delegates to it (see that file). Also closes a
// second, quieter gap neither version handled: an array/matrix/dict fell
// through the old logic to a bare `.number != 0` (always false, since
// containers never set that field) with no consideration for whether the
// container was empty or not - non-empty is now truthy, matching every
// other container operation's own "empty means false-ish" convention
// (is_empty(), for one).
bool valueIsTruthy(const Value &v);

// Same "global out-of-band status flag" convention as statistics.h's
// g_lastStatsOk / vector.h's g_lastVectorOk / geometric.h's
// g_lastGeometricOk / dc.h's g_lastDcOk. Reset once per top-level
// dispatch call in conditional_builtin.cpp AND in logical_builtin.cpp
// (two independent dispatch entry points into this one domain, neither
// ever calls into the other, so resetting in both is safe - no
// clobbering risk). Set false on an arity mismatch, an unknown function
// name, or a non-orderable/mismatched-kind pair passed to lt()/gt()/
// le()/ge() as direct function calls (the `<`/`>`/`<=`/`>=` OPERATOR
// syntax already validates this in parser_expression.cpp's
// evaluateComparisonValues() before ever reaching logical_lt/gt/lte/gte -
// but calling them AS FUNCTIONS, e.g. `lt([1,2],[3,4])`, bypassed that
// check entirely and silently returned a meaningless answer instead of
// the same "Error: cannot order-compare X with Y" the operator form
// gives. Confirmed by direct testing.
extern bool g_lastConditionalOk;

/* ================= CONDITIONAL ================= */

Value cond_if(Value cond, Value a, Value b);
Value is_empty(Value a);
Value is_nan(Value a);

/* ================= LOGICAL: BOOLEAN ================= */

Value logical_and(Value a, Value b);
Value logical_or(Value a, Value b);
Value logical_not(Value a);
Value logical_nand(Value a, Value b);
Value logical_nor(Value a, Value b);
Value logical_is_in(Value elem, Value container);
Value logical_is_not_in(Value elem, Value container);

/* ================= LOGICAL: COMPARISON ================= */

Value logical_eq(Value a, Value b);
Value logical_neq(Value a, Value b);
Value logical_lt(Value a, Value b);
Value logical_gt(Value a, Value b);
Value logical_lte(Value a, Value b);
Value logical_gte(Value a, Value b);

/* ================= LOGICAL: PREDICATES ================= */

Value is_true(Value a);
Value is_false(Value a);
Value is_zero(Value a);
Value is_positive(Value a);
Value is_negative(Value a);
