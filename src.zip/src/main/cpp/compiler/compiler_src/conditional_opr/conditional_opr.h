#pragma once

// Declarations for NC conditional/logical operator functions.
// Each function's implementation lives in its own func_<operator-name>.cpp
// file in this folder. Migrated from:
//   - runtime/interpreter/ops/conditional/conditional.cpp
//   - runtime/interpreter/ops/logical/logical.cpp

#include "../../../runtime/interpreter/core/value.h"

/* ================= VALUE COMPARISON CORE ================= */

// Implemented in value_compare.cpp. Shared by every comparison operator so
// they all agree on what "same value" means, instead of each one falling
// back to Value::number (which is 0 for strings, arrays, matrices, dicts
// and objects alike — the cause of "str" == "str2" reporting true).

enum ValueKind { VK_NUMBER, VK_TEXT, VK_ARRAY, VK_MATRIX, VK_DICT, VK_OBJECT };

ValueKind valueKindOf(const Value &v);
const char *valueKindName(const Value &v);

// Structural equality: recurses into arrays, matrices, dicts and object
// fields. Values of different kinds are never equal.
bool valuesDeepEqual(const Value &a, const Value &b);

// Only numbers and strings can be ordered (<, >, <=, >=).
bool valueIsOrderable(const Value &v);

// -1 / 0 / +1. Caller must have checked valueIsOrderable() on both sides
// and that they are the same kind.
int valueOrderCompare(const Value &a, const Value &b);

/* ================= CONDITIONAL ================= */

Value cond_if(Value cond, Value a, Value b);
Value is_empty(Value a);
Value is_nan(Value a);

/* ================= LOGICAL: BOOLEAN ================= */

Value logical_and(Value a, Value b);
Value logical_or(Value a, Value b);
Value logical_not(Value a);
Value logical_nand(Value a, Value b);
Value logical_nor(Value a, Value b);
Value logical_is_in(Value elem, Value container);
Value logical_is_not_in(Value elem, Value container);

/* ================= LOGICAL: COMPARISON ================= */

Value logical_eq(Value a, Value b);
Value logical_neq(Value a, Value b);
Value logical_lt(Value a, Value b);
Value logical_gt(Value a, Value b);
Value logical_lte(Value a, Value b);
Value logical_gte(Value a, Value b);

/* ================= LOGICAL: PREDICATES ================= */

Value is_true(Value a);
Value is_false(Value a);
Value is_zero(Value a);
Value is_positive(Value a);
Value is_negative(Value a);
