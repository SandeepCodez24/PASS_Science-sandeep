#include "conditional_opr.h"

/* ================= IS FALSE ================= */

Value is_false(Value a) { return Value(a.number == 0); }
