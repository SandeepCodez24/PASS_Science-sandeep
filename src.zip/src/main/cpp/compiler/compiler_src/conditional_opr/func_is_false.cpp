#include "conditional_opr.h"

/* ================= IS FALSE ================= */

// Same truthiness fix as is_true() - see its comment.
Value is_false(Value a) { return Value(valueIsTruthy(a) ? 0.0 : 1.0); }
