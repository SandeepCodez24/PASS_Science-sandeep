#include "conditional_opr.h"

/* ================= NAND ================= */

// Same truthiness fix as logical_and() - see its comment.
Value logical_nand(Value a, Value b) {
  return Value((valueIsTruthy(a) && valueIsTruthy(b)) ? 0.0 : 1.0);
}
