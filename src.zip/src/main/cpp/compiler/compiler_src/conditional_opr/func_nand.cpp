#include "conditional_opr.h"

/* ================= NAND ================= */

Value logical_nand(Value a, Value b) { return Value(!(a.number && b.number)); }
