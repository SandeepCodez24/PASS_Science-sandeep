#include "conditional_opr.h"

/* ================= IS TRUE ================= */

// Was `a.number != 0` - same truthiness disagreement as logical_and() et
// al. (see its comment): is_true("hello") silently returned false for a
// non-empty string. Now uses the same truthiness as if/while/and/or.
Value is_true(Value a) { return Value(valueIsTruthy(a) ? 1.0 : 0.0); }
