#include "conditional_opr.h"

/* ================= IS TRUE ================= */

Value is_true(Value a) { return Value(a.number != 0); }
