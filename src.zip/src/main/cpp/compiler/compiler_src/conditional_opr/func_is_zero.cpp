#include "conditional_opr.h"
#include <iostream>

/* ================= IS ZERO ================= */

// "Zero" is a numeric concept, not a truthiness one (unlike is_true/
// is_false) - was `a.number == 0`, so a non-number's .number defaulting
// to 0 made is_zero("hello") silently return true. Confirmed by direct
// testing. Requires an actual number instead of guessing.
Value is_zero(Value a) {
  if (valueKindOf(a) != VK_NUMBER) {
    std::cerr << "Error: is_zero expects a number, not a " << valueKindName(a) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }
  // A complex number is zero only when both parts are.
  return Value((a.number == 0 && (!a.isComplex || a.imag == 0)) ? 1.0 : 0.0);
}
