#include "conditional_opr.h"

/* ================= IS ZERO ================= */

Value is_zero(Value a) { return Value(a.number == 0); }
