#include "conditional_opr.h"

/* ================= NOT EQUAL TO (!=) ================= */

// Exact negation of logical_eq — see the note there on why comparing
// Value::number alone was wrong.
Value logical_neq(Value a, Value b) {
  return Value(valuesDeepEqual(a, b) ? 0.0 : 1.0);
}
