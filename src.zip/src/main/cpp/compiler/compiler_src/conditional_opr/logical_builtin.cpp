#include "logical_builtin.h"
#include "conditional_opr.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

// Note: logical operators are exposed via functions prefixed with
// logical_* and is_* declared in conditional_opr.h.

static inline bool require_arity(const std::string &fn, size_t needed,
                                 const std::vector<Value> &args) {
  if (args.size() != needed) {
    std::cerr << "Error: Function '" << fn << "' expects " << needed
              << " args, got " << args.size() << "\n";
    g_lastConditionalOk = false;
    return false;
  }
  return true;
}

Value logicalBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= COMPARISON OPS ================= */

      {"eq",
       [](const auto &a) {
         if (!require_arity("eq", 2, a))
           return Value();
         return logical_eq(a[0], a[1]);
       }},
      {"ne",
       [](const auto &a) {
         if (!require_arity("ne", 2, a))
           return Value();
         return logical_neq(a[0], a[1]);
       }},
      {"lt",
       [](const auto &a) {
         if (!require_arity("lt", 2, a))
           return Value();
         return logical_lt(a[0], a[1]);
       }},
      {"gt",
       [](const auto &a) {
         if (!require_arity("gt", 2, a))
           return Value();
         return logical_gt(a[0], a[1]);
       }},
      {"le",
       [](const auto &a) {
         if (!require_arity("le", 2, a))
           return Value();
         return logical_lte(a[0], a[1]);
       }},
      {"ge",
       [](const auto &a) {
         if (!require_arity("ge", 2, a))
           return Value();
         return logical_gte(a[0], a[1]);
       }},

      /* ================= BOOLEAN OPS ================= */

      {"and",
       [](const auto &a) {
         if (!require_arity("and", 2, a))
           return Value();
         return logical_and(a[0], a[1]);
       }},
      {"or",
       [](const auto &a) {
         if (!require_arity("or", 2, a))
           return Value();
         return logical_or(a[0], a[1]);
       }},
      {"not",
       [](const auto &a) {
         if (!require_arity("not", 1, a))
           return Value();
         return logical_not(a[0]);
       }},

      /* ================= UTILITIES ================= */

      {"bool",
       [](const auto &a) {
         if (!require_arity("bool", 1, a))
           return Value();
         // Was `a[0].number != 0 ? 1 : 0` inline instead of delegating -
         // the same truthiness disagreement as logical_and() et al. (see
         // its comment) duplicated here separately. Delegates to is_true()
         // now so there's exactly one definition of "truthy" involved.
         return is_true(a[0]);
       }},

      {"is_true",
       [](const auto &a) {
         if (!require_arity("is_true", 1, a))
           return Value();
         return is_true(a[0]);
       }},
      {"is_false",
       [](const auto &a) {
         if (!require_arity("is_false", 1, a))
           return Value();
         return is_false(a[0]);
       }},

      /* ================= CONDITIONAL HELPERS ================= */

      {"is_zero",
       [](const auto &a) {
         if (!require_arity("is_zero", 1, a))
           return Value();
         return is_zero(a[0]);
       }},
      {"is_positive",
       [](const auto &a) {
         if (!require_arity("is_positive", 1, a))
           return Value();
         return is_positive(a[0]);
       }},
      {"is_negative",
       [](const auto &a) {
         if (!require_arity("is_negative", 1, a))
           return Value();
         return is_negative(a[0]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass) - see matrix_builtin.cpp for
  // the first fix of this kind and the full reasoning.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown logical function '" << name << "'\n";
    g_lastConditionalOk = false;
    return Value();
  }

  // Reset here, once per top-level dispatch call - matches the
  // statistics.cpp/geometric_builtin.cpp/dc_builtin.cpp precedent.
  g_lastConditionalOk = true;

  return it->second(args);
}
