#include "logical_builtin.h"
#include "conditional_opr.h"

#include <functional>
#include <iostream>
#include <unordered_map>

// Note: logical operators are exposed via functions prefixed with
// logical_* and is_* declared in conditional_opr.h.

static inline bool require_arity(const std::string &fn, size_t needed,
                                 const std::vector<Value> &args) {
  if (args.size() != needed) {
    std::cerr << "Error: Function '" << fn << "' expects " << needed
              << " args, got " << args.size() << "\n";
    return false;
  }
  return true;
}

Value logicalBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= COMPARISON OPS ================= */

      {"eq",
       [&](const auto &a) {
         if (!require_arity("eq", 2, a))
           return Value();
         return logical_eq(a[0], a[1]);
       }},
      {"ne",
       [&](const auto &a) {
         if (!require_arity("ne", 2, a))
           return Value();
         return logical_neq(a[0], a[1]);
       }},
      {"lt",
       [&](const auto &a) {
         if (!require_arity("lt", 2, a))
           return Value();
         return logical_lt(a[0], a[1]);
       }},
      {"gt",
       [&](const auto &a) {
         if (!require_arity("gt", 2, a))
           return Value();
         return logical_gt(a[0], a[1]);
       }},
      {"le",
       [&](const auto &a) {
         if (!require_arity("le", 2, a))
           return Value();
         return logical_lte(a[0], a[1]);
       }},
      {"ge",
       [&](const auto &a) {
         if (!require_arity("ge", 2, a))
           return Value();
         return logical_gte(a[0], a[1]);
       }},

      /* ================= BOOLEAN OPS ================= */

      {"and",
       [&](const auto &a) {
         if (!require_arity("and", 2, a))
           return Value();
         return logical_and(a[0], a[1]);
       }},
      {"or",
       [&](const auto &a) {
         if (!require_arity("or", 2, a))
           return Value();
         return logical_or(a[0], a[1]);
       }},
      {"not",
       [&](const auto &a) {
         if (!require_arity("not", 1, a))
           return Value();
         return logical_not(a[0]);
       }},

      /* ================= UTILITIES ================= */

      {"bool",
       [&](const auto &a) {
         if (!require_arity("bool", 1, a))
           return Value();
         return Value(a[0].number != 0 ? 1 : 0);
       }},

      {"is_true",
       [&](const auto &a) {
         if (!require_arity("is_true", 1, a))
           return Value();
         return is_true(a[0]);
       }},
      {"is_false",
       [&](const auto &a) {
         if (!require_arity("is_false", 1, a))
           return Value();
         return is_false(a[0]);
       }},

      /* ================= CONDITIONAL HELPERS ================= */

      {"is_zero",
       [&](const auto &a) {
         if (!require_arity("is_zero", 1, a))
           return Value();
         return is_zero(a[0]);
       }},
      {"is_positive",
       [&](const auto &a) {
         if (!require_arity("is_positive", 1, a))
           return Value();
         return is_positive(a[0]);
       }},
      {"is_negative",
       [&](const auto &a) {
         if (!require_arity("is_negative", 1, a))
           return Value();
         return is_negative(a[0]);
       }},
  };

  auto it = table.find(name);
  if (it == table.end()) {
    std::cerr << "Error: Unknown logical function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}
