#include "conditional_opr.h"

/* ================= IF ================= */

// Was `cond.number != 0` - disagreed with the language's own `if`
// statement for text/array/matrix/dict conditions (cond.number defaults
// to 0 for all of them). Now uses the same truthiness as if/while.
Value cond_if(Value cond, Value a, Value b)
{
    if (valueIsTruthy(cond))
        return a;

    return b;
}
