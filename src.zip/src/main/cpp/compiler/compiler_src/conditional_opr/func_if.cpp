#include "conditional_opr.h"

/* ================= IF ================= */

Value cond_if(Value cond, Value a, Value b)
{
    if (cond.number != 0)
        return a;

    return b;
}
