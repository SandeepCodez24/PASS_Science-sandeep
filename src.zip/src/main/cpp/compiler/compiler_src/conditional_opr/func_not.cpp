#include "conditional_opr.h"

/* ================= NOT ================= */

// Same truthiness fix as logical_and() - see its comment.
Value logical_not(Value a) { return Value(valueIsTruthy(a) ? 0.0 : 1.0); }
