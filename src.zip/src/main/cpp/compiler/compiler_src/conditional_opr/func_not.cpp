#include "conditional_opr.h"

/* ================= NOT ================= */

Value logical_not(Value a) { return Value(a.number == 0 ? 1 : 0); }
