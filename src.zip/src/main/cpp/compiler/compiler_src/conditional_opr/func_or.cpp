#include "conditional_opr.h"

/* ================= OR ================= */

// Same truthiness fix as logical_and() - see its comment.
Value logical_or(Value a, Value b) {
  return Value(valueIsTruthy(a) || valueIsTruthy(b) ? 1.0 : 0.0);
}
