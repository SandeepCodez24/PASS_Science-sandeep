#include "conditional_opr.h"

/* ================= OR ================= */

Value logical_or(Value a, Value b) { return Value(a.number || b.number); }
