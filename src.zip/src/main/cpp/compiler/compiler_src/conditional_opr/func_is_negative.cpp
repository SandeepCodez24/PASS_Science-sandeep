#include "conditional_opr.h"

/* ================= IS NEGATIVE ================= */

Value is_negative(Value a) { return Value(a.number < 0); }
