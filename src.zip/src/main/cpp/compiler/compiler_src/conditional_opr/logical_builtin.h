#pragma once

#include "../../../runtime/interpreter/core/value.h"

#include <string>
#include <vector>

// Dispatcher for logical builtins
Value logicalBuiltin(const std::string &name, const std::vector<Value> &args);
