#include "conditional_opr.h"

/* ================= GREATER THAN OR EQUAL (>=) ================= */

Value logical_gte(Value a, Value b) {
  return Value(valueOrderCompare(a, b) >= 0 ? 1.0 : 0.0);
}
