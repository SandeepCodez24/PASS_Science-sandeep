#include "conditional_opr.h"

/* ================= IS_IN ================= */

// Previously carried a private `valuesEqual` that only special-cased text
// and otherwise fell back to Value::number, so `[[1,2]] is_in list` matched
// any matrix in the list. It now shares valuesDeepEqual() with ==/!=, so
// membership and equality can never disagree.
Value logical_is_in(Value elem, Value container) {
  if (!container.isArray)
    return Value(0);

  for (const Value &item : container.array) {
    if (valuesDeepEqual(elem, item))
      return Value(1);
  }

  return Value(0);
}
