#include "conditional_opr.h"
#include <iostream>

/* ================= IS_IN ================= */

// Previously carried a private `valuesEqual` that only special-cased text
// and otherwise fell back to Value::number, so `[[1,2]] is_in list` matched
// any matrix in the list. It now shares valuesDeepEqual() with ==/!=, so
// membership and equality can never disagree.
//
// A non-array container used to silently answer "not found" - the same
// answer a genuine, correctly-checked non-membership gives - instead of
// rejecting a container that isn't actually a collection at all (a plain
// number, string, matrix, or dict has no "elements" to search the way an
// array does).
Value logical_is_in(Value elem, Value container) {
  if (!container.isArray) {
    std::cerr << "Error: is_in's container must be an array, not a "
              << valueKindName(container) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }

  for (const Value &item : container.elems()) {
    if (valuesDeepEqual(elem, item))
      return Value(1);
  }

  return Value(0);
}
