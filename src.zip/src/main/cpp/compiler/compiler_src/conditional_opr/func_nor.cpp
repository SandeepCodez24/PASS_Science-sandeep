#include "conditional_opr.h"

/* ================= NOR ================= */

Value logical_nor(Value a, Value b) { return Value(!(a.number || b.number)); }
