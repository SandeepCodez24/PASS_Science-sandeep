#include "conditional_opr.h"

/* ================= IS_NOT_IN ================= */

// Exact negation of logical_is_in — see the note there on the removed
// private valuesEqual helper.
Value logical_is_not_in(Value elem, Value container) {
  if (!container.isArray)
    return Value(1);

  for (const Value &item : container.array) {
    if (valuesDeepEqual(elem, item))
      return Value(0);
  }

  return Value(1);
}
