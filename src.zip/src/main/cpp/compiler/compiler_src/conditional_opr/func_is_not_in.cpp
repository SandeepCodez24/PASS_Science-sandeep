#include "conditional_opr.h"
#include <iostream>

/* ================= IS_NOT_IN ================= */

// Exact negation of logical_is_in — see the note there on the removed
// private valuesEqual helper and on the non-array-container validation
// added here to match.
Value logical_is_not_in(Value elem, Value container) {
  if (!container.isArray) {
    std::cerr << "Error: is_not_in's container must be an array, not a "
              << valueKindName(container) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }

  for (const Value &item : container.elems()) {
    if (valuesDeepEqual(elem, item))
      return Value(0);
  }

  return Value(1);
}
