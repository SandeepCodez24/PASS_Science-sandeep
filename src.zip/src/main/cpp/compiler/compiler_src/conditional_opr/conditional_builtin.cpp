#include "conditional_builtin.h"
#include "conditional_opr.h"

#include <functional>
#include <iostream>
#include <unordered_map>

Value conditionalBuiltin(const std::string &name,
                         const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  auto require_arity = [&](const std::string &fn, size_t needed) -> bool {
    if (args.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << args.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* IF */

      {"If",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("If", 3))
           return Value();
         return cond_if(a[0], a[1], a[2]);
       }},

      {"if",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("if", 3))
           return Value();
         return cond_if(a[0], a[1], a[2]);
       }},

      /* IS EMPTY */

      {"Isempty",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Isempty", 1))
           return Value();
         return is_empty(a[0]);
       }},

      {"isempty",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("isempty", 1))
           return Value();
         return is_empty(a[0]);
       }},

      {"is_empty",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("is_empty", 1))
           return Value();
         return is_empty(a[0]);
       }},

      /* IS NAN */

      {"Isnan",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("Isnan", 1))
           return Value();
         return is_nan(a[0]);
       }},

      {"isnan",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("isnan", 1))
           return Value();
         return is_nan(a[0]);
       }},

      {"is_nan",
       [&](const std::vector<Value> &a) -> Value {
         if (!require_arity("is_nan", 1))
           return Value();
         return is_nan(a[0]);
       }},
  };

  auto it = table.find(name);

  if (it == table.end()) {
    std::cerr << "Error: Unknown conditional function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}
