#include "conditional_builtin.h"
#include "conditional_opr.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

// A free function taking `args` explicitly, not a per-call lambda capturing
// it by reference - `table` below is a function-local `static`, built only
// on the *first* call, so any `[&]` capture inside it that reached a
// per-call local (like an `args`-capturing `require_arity` lambda would)
// stays bound to that first call's already-destroyed stack frame on every
// subsequent call, silently reading whatever now occupies that memory.
// (Confirmed by reproduction: this used to be exactly that dangling-
// reference lambda, and printed a different garbage "got N args" value on
// each run once a script exercised the arity-mismatch path more than once
// per process.) logical_builtin.cpp's require_arity already uses this
// correct, capture-free shape - mirrored here.
static inline bool require_arity(const std::string &fn, size_t needed,
                                 const std::vector<Value> &args) {
  if (args.size() != needed) {
    std::cerr << "Error: Function '" << fn << "' expects " << needed
              << " args, got " << args.size() << "\n";
    g_lastConditionalOk = false;
    return false;
  }
  return true;
}

Value conditionalBuiltin(const std::string &name,
                         const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  static const std::unordered_map<std::string, Fn> table = {

      /* IF */

      // "If" (capitalized) removed 2026-09-16: it was a manual duplicate
      // registered purely to work around this table's lookup not being
      // case-insensitive - now that the lookup itself lowercases (see the
      // fix at this function's tail), "if" below already handles every
      // casing and the duplicate is redundant.
      {"if",
       [](const std::vector<Value> &a) -> Value {
         if (!require_arity("if", 3, a))
           return Value();
         return cond_if(a[0], a[1], a[2]);
       }},

      /* IS EMPTY */

      {"isempty",
       [](const std::vector<Value> &a) -> Value {
         if (!require_arity("isempty", 1, a))
           return Value();
         return is_empty(a[0]);
       }},

      {"is_empty",
       [](const std::vector<Value> &a) -> Value {
         if (!require_arity("is_empty", 1, a))
           return Value();
         return is_empty(a[0]);
       }},

      /* IS NAN */

      {"isnan",
       [](const std::vector<Value> &a) -> Value {
         if (!require_arity("isnan", 1, a))
           return Value();
         return is_nan(a[0]);
       }},

      {"is_nan",
       [](const std::vector<Value> &a) -> Value {
         if (!require_arity("is_nan", 1, a))
           return Value();
         return is_nan(a[0]);
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16, same fix applied across
  // every inner dispatch table this pass) - see matrix_builtin.cpp for
  // the first fix of this kind and the full reasoning. This is also what
  // makes the "If"/"if" duplicate above redundant now.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  auto it = table.find(key);

  if (it == table.end()) {
    std::cerr << "Error: Unknown conditional function '" << name << "'\n";
    g_lastConditionalOk = false;
    return Value();
  }

  // Reset here, once per top-level dispatch call - matches the
  // statistics.cpp/geometric_builtin.cpp/dc_builtin.cpp precedent.
  // logicalBuiltin() (logical_builtin.cpp) does the same reset
  // independently - the two dispatchers never call into each other, so
  // there's no clobbering risk.
  g_lastConditionalOk = true;

  return it->second(args);
}
