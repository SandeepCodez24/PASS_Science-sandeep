#include "conditional_opr.h"

/* ================= VALUE COMPARISON CORE =================
 *
 * Every comparison operator (==, !=, <, >, <=, >=) used to compare only
 * `Value::number`. That field is 0 for EVERY non-numeric Value — a string
 * keeps its content in `text`, an array in `array`, a matrix in `matrix`,
 * a dict/object in `dictMap` — so `"str" == "str2"` was really `0 == 0`
 * and reported true, as did comparing any two arrays, matrices or dicts.
 * The operators were effectively answering "are these both non-numbers?"
 * instead of "do these hold the same value".
 *
 * These helpers are the single place where "same value" and "orderable"
 * are defined, so all six operators (plus is_in/is_not_in) agree.
 */

/* The variant a Value currently holds. Two Values of different kinds are
 * never equal and can never be ordered against each other. */
ValueKind valueKindOf(const Value &v) {
  if (v.isObject)
    return VK_OBJECT;
  if (v.isDict)
    return VK_DICT;
  if (v.isMatrix)
    return VK_MATRIX;
  if (v.isArray)
    return VK_ARRAY;
  if (v.isText)
    return VK_TEXT;
  return VK_NUMBER;
}

const char *valueKindName(const Value &v) {
  switch (valueKindOf(v)) {
  case VK_OBJECT:
    return "object";
  case VK_DICT:
    return "dict";
  case VK_MATRIX:
    return "matrix";
  case VK_ARRAY:
    return "array";
  case VK_TEXT:
    return "string";
  default:
    return "number";
  }
}

/* Structural ("deep") equality — recurses through arrays, matrices, dicts
 * and object fields so equality reflects the values actually held, not the
 * unused `number` slot that every container leaves at 0. */
bool valuesDeepEqual(const Value &a, const Value &b) {
  ValueKind ka = valueKindOf(a);
  ValueKind kb = valueKindOf(b);

  // A string is never equal to a number, an array never equal to a dict,
  // and so on. Not an error — "are these equal?" has the answer "no".
  if (ka != kb)
    return false;

  switch (ka) {
  case VK_NUMBER:
    return a.number == b.number;

  case VK_TEXT:
    return a.text == b.text;

  case VK_ARRAY: {
    if (a.array.size() != b.array.size())
      return false;
    for (size_t i = 0; i < a.array.size(); i++) {
      if (!valuesDeepEqual(a.array[i], b.array[i]))
        return false;
    }
    return true;
  }

  case VK_MATRIX: {
    if (a.matrix.size() != b.matrix.size())
      return false;
    for (size_t r = 0; r < a.matrix.size(); r++) {
      if (a.matrix[r].size() != b.matrix[r].size())
        return false;
      for (size_t c = 0; c < a.matrix[r].size(); c++) {
        if (!valuesDeepEqual(a.matrix[r][c], b.matrix[r][c]))
          return false;
      }
    }
    return true;
  }

  case VK_OBJECT:
    // Two instances of different classes are different values even if
    // their fields happen to line up.
    if (a.className != b.className)
      return false;
    // fall through — an object's fields live in dictMap, same as a dict's
    [[fallthrough]];

  case VK_DICT: {
    if (a.dictMap.size() != b.dictMap.size())
      return false;
    for (const auto &entry : a.dictMap) {
      auto it = b.dictMap.find(entry.first);
      if (it == b.dictMap.end())
        return false;
      if (!valuesDeepEqual(entry.second, it->second))
        return false;
    }
    return true;
  }
  }

  return false;
}

/* Only numbers and strings have a meaningful ordering. Ordering two
 * matrices or two dicts is not a smaller-or-larger question, so the parser
 * rejects it rather than silently answering with the 0-vs-0 comparison
 * that produced the original bug. */
bool valueIsOrderable(const Value &v) {
  ValueKind k = valueKindOf(v);
  return k == VK_NUMBER || k == VK_TEXT;
}

/* -1 / 0 / +1, for the four ordering operators. Only ever called after
 * parseComparison() has confirmed both sides are orderable and of the same
 * kind. */
int valueOrderCompare(const Value &a, const Value &b) {
  if (valueKindOf(a) == VK_TEXT) {
    if (a.text < b.text)
      return -1;
    return (a.text == b.text) ? 0 : 1;
  }

  if (a.number < b.number)
    return -1;
  return (a.number == b.number) ? 0 : 1;
}
