// The Process Data window's native ops - see process_runner.h.
#include "process_runner.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <sstream>

#include "core/error_lines.h"
#include "elementwise.h"
#include "../../runtime/memory/governor.h"
#include <stdexcept>
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "../../runtime/data/DataSupport/JsonWriter.h"
#include "../../runtime/data/DataSupport/ValueJson.h"
#include "../../runtime/execution/Interrupt.h"
#include "../../runtime/execution/parallel/par.h"
#include "../../runtime/interpreter/Numpy/importing_data/io_ide_api.h"
#include "../../runtime/interpreter/Numpy/importing_data/io_tree.h"
#include "../../runtime/interpreter/ops/process/process_table.h"
#include "lexer/identifier_rules.h"

namespace nc {
namespace process {

namespace {

using Clock = std::chrono::steady_clock;

double secondsSince(Clock::time_point t0) {
  return std::chrono::duration<double>(Clock::now() - t0).count();
}

void head(ncdata::JsonWriter &j, const std::string &type, const std::string &id) {
  j.beginObject();
  j.key("v").integer(1);
  j.key("type").string(type);
  j.key("id").string(id);
}

void answerError(const std::string &id, const std::string &op, const std::string &error) {
  ncdata::JsonWriter j;
  head(j, "io", id);
  j.key("op").string(op);
  j.key("ok").boolean(false);
  j.key("error").string(error);
  j.endObject();
  nc::io::ide::sendProtocolLine("@IO", j.str());
}

std::string textOf(const nc::io::TreeNode &req, const char *key) {
  const nc::io::TreeNode *n = req.find(key);
  if (!n)
    return "";
  if (n->type == nc::io::TreeNode::String)
    return n->str;
  if (n->type == nc::io::TreeNode::Number) {
    std::ostringstream s;
    s << n->num;
    return s.str();
  }
  return "";
}

double numberOf(const nc::io::TreeNode &req, const char *key, double fallback) {
  const nc::io::TreeNode *n = req.find(key);
  return n && n->type == nc::io::TreeNode::Number ? n->num : fallback;
}

// The error lines captured while something ran, without "Error: ".
std::vector<std::string> errorLinesOf(const std::string &text) {
  std::vector<std::string> out;
  std::string line;
  std::istringstream in(text);
  while (std::getline(in, line)) {
    while (!line.empty() && (line.back() == '\r' || line.back() == ' '))
      line.pop_back();
    if (line.empty())
      continue;
    if (line.rfind("Error: ", 0) == 0)
      line = line.substr(7);
    out.push_back(line);
  }
  return out;
}

// "✖ Syntax Error (line 2, col 13): message" -> 2, 13, message.
void splitSyntaxError(const std::string &line, long &ln, long &col, std::string &message) {
  ln = 0;
  col = 0;
  message = line;
  const size_t at = line.find("(line ");
  if (at == std::string::npos)
    return;
  ln = std::strtol(line.c_str() + at + 6, nullptr, 10);
  const size_t c = line.find("col ", at);
  const size_t close = line.find(')', at);
  if (c != std::string::npos && (close == std::string::npos || c < close))
    col = std::strtol(line.c_str() + c + 4, nullptr, 10);
  if (close != std::string::npos) {
    size_t m = close + 1;
    while (m < line.size() && (line[m] == ':' || line[m] == ' '))
      m++;
    message = line.substr(m);
  }
}

struct Parsed {
  bool ok = true;
  std::vector<std::string> errors; // as printed (one per line)
  Program program;
};

// Parses NC text with a Parser of its own (the REPL's may be busy), the
// syntax errors held back from the screen.
Parsed parseQuietly(const std::string &text) {
  Parsed p;
  nc::errorlines::beginCapture();
  {
    Lexer lexer(text);
    std::vector<Token> tokens = lexer.tokenize();
    Parser scratch;
    p.program = scratch.parseProgram(tokens);
    p.ok = lexer.errorCount() == 0 && scratch.syntaxErrorCount_ == 0;
  }
  const std::string captured = nc::errorlines::capturedText();
  nc::errorlines::endCapture(/*handled=*/true);
  for (std::string &l : errorLinesOf(captured))
    if (l.find("the script was not run") == std::string::npos)
      p.errors.push_back(std::move(l));
  if (!p.ok && p.errors.empty())
    p.errors.push_back("the code has a syntax error");
  return p;
}

// Functions put into the REPL's table for one request and taken out again;
// a function of the same name that was there before comes back.
class TableGuard {
public:
  explicit TableGuard(Parser &p) : p_(p) {}
  ~TableGuard() {
    for (const std::string &n : added_)
      p_.functionTable_.erase(n);
    for (auto &s : saved_)
      p_.functionTable_[s.first] = std::move(s.second);
  }
  void registerFrom(const Stmt &stmt) {
    if (std::find(added_.begin(), added_.end(), stmt.name) == added_.end()) {
      auto it = p_.functionTable_.find(stmt.name);
      if (it != p_.functionTable_.end()) {
        saved_.emplace_back(stmt.name, std::move(it->second));
        p_.functionTable_.erase(it);
      }
      added_.push_back(stmt.name);
    }
    p_.registerFunctionDeclStmt(stmt, /*fromFunctionFile=*/true);
  }

private:
  Parser &p_;
  std::vector<std::string> added_;
  std::vector<std::pair<std::string, std::vector<Parser::FunctionDef>>> saved_;
};

struct Step {
  long index = 0;
  std::string filter, code, on, table;
  std::vector<std::string> columns;
  std::string fn;  // its function's name
  long codeLines = 0;
  std::string parseError; // the code does not parse: why, and where
  long parseLine = 0;
};

constexpr long kHeaderLines = 2; // "function Y = ...(X, nc__y, target):" and "Y = nc__y;"

struct Outcome {
  bool ok = true;
  std::string error;
  long line = 0;
};

// One call of a step's function on one value.
Outcome callStep(Parser &parser, const Step &s, const Value &x, Value &y, const Value &target, bool quiet) {
  Outcome o;
  const unsigned long before = nc::errorlines::count();
  nc::errorlines::beginCapture();
  parser.evaluationSucceeded_ = true;
  parser.clearErrorAbort();
  bool found = false;
  Value result;
  try {
    result = parser.callUserFunction(s.fn, {x, y, target}, found);
  } catch (const std::bad_alloc &e) { // outside any statement of the step
    std::cerr << "Error: " << nc::mem::outOfMemoryText(e) << "\n";
    parser.evaluationSucceeded_ = false;
  } catch (const std::length_error &e) {
    std::cerr << "Error: " << nc::mem::outOfMemoryText(e) << "\n";
    parser.evaluationSucceeded_ = false;
  }
  const bool stopped = nc::Interrupt::requested();
  o.ok = found && parser.evaluationSucceeded_ && !parser.errorAbort_ &&
         nc::errorlines::count() == before && !stopped;
  if (!o.ok && parser.errorLine_ > static_cast<size_t>(kHeaderLines) &&
      parser.errorLine_ <= static_cast<size_t>(kHeaderLines + s.codeLines))
    o.line = static_cast<long>(parser.errorLine_) - kHeaderLines;
  parser.clearErrorAbort();
  parser.evaluationSucceeded_ = true;
  const std::vector<std::string> lines = errorLinesOf(nc::errorlines::capturedText());
  // check: the events carry the error, nothing is printed. run: printed in
  // the Command Window, as any command's error.
  nc::errorlines::endCapture(/*handled=*/quiet);
  if (o.ok) {
    y = std::move(result);
    return o;
  }
  for (const std::string &l : lines)
    if (l.find("the script stopped here") == std::string::npos) {
      o.error = l;
      break;
    }
  if (o.error.empty())
    o.error = stopped ? "stopped" : "the step failed";
  return o;
}

bool isTextColumn(const Value &col) {
  if (!(col.isArray || col.isMatrix))
    return col.isText;
  const size_t n = col.isArray ? col.length() : col.rows() * (col.rows() ? col.cols() : 0);
  bool any = false;
  for (size_t k = 0; k < n; k++) {
    const Value c = col.isArray ? col.at(k) : col.at(k / col.cols(), k % col.cols());
    if (c.isText) {
      any = true;
      break;
    }
  }
  return any;
}

// The first `n` rows of a matrix (check with "sample"); of a vector - a
// 1-D array or a 1 x N row, where rows say nothing - its first `n` elements
// (2026-11-20: Check Flow on a 1 x 628318531 row used to run on all of it).
// A lazy range is read from its rule, not built.
Value firstRows(const Value &v, size_t n) {
  const bool row = (v.isArray || (v.isMatrix && !v.isND() && v.rows() == 1));
  if (row) {
    const size_t len = v.isArray ? v.length() : v.cols();
    if (len <= n)
      return v;
    if (v.isPacked()) {
      std::vector<double> head(n);
      for (size_t c = 0; c < n; c++)
        head[c] = v.isArray ? v.numAt(c) : v.numAt(0, c);
      Value cut = v.isArray ? Value::packedArray(head.data(), n) : Value::packedMatrix(head.data(), 1, n);
      int16_t l, t, m;
      v.unitDims(l, t, m);
      cut.setUnitDims(l, t, m);
      return cut;
    }
    std::vector<Value> cells;
    cells.reserve(n);
    for (size_t c = 0; c < n; c++)
      cells.push_back(v.isArray ? v.at(c) : v.at(0, c));
    if (v.isArray)
      return Value(std::move(cells));
    std::vector<std::vector<Value>> one;
    one.push_back(std::move(cells));
    return Value(std::move(one));
  }
  if (!v.isMatrix || v.isND() || v.rows() <= n)
    return v;
  const size_t C = v.cols();
  if (v.isPacked()) {
    std::vector<double> colMajor(n * C);
    for (size_t c = 0; c < C; c++)
      for (size_t r = 0; r < n; r++)
        colMajor[c * n + r] = v.numAt(r, c);
    return Value::packedMatrix(colMajor.data(), n, C);
  }
  std::vector<std::vector<Value>> rows;
  rows.reserve(n);
  for (size_t r = 0; r < n; r++)
    rows.push_back(v.row(r));
  return Value(std::move(rows));
}

// class / size of a value for the window; a table's size is rows x columns.
void writeShape(ncdata::JsonWriter &j, const Value &v) {
  const ncdata::VariableSummary sum = ncdata::summarizeVariable("Y", v, 0);
  j.key("class").string(sum.cls);
  if (nc::ops::process::isTableObject(v)) {
    std::vector<std::string> names;
    std::vector<Value> cols;
    std::string err;
    nc::ops::process::tableColumns(v, names, cols, err);
    j.key("size").string(std::to_string(nc::ops::process::tableRowCount(v)) + "x" +
                         std::to_string(names.size()));
    j.key("table").boolean(true);
  } else {
    j.key("size").string(sum.size);
  }
}

// Progress inside a step (2026-11-20): a long multicore kernel of the step
// (float16 of 628 million elements, a sort, an FFT ...) reports how far it
// is through nc::par's progress sink, at most ten times a second:
//   {"kind":"step_progress","index":1,"filter":"casting","label":"float16",
//    "done":412,"total":1000,"fraction":0.412}
// "label" names the kernel; a step may run several, each from 0 to 1.
// Serial work in a step sends none (the step's own "step" event still ends it).
struct StepProgress {
  std::string id;
  const Step *step = nullptr;
};

void sendStepProgress(void *ctx, const char *label, size_t done, size_t total) {
  const StepProgress &p = *static_cast<const StepProgress *>(ctx);
  if (!p.step)
    return;
  // A for loop of the step's code says its line in the step function; the
  // window shows the step's own lines (the function adds kHeaderLines).
  std::string text = label ? label : "";
  static const std::string kLoop = "for loop (line ";
  if (text.rfind(kLoop, 0) == 0) {
    const long line = std::strtol(text.c_str() + kLoop.size(), nullptr, 10);
    if (line > kHeaderLines)
      text = kLoop + std::to_string(line - kHeaderLines) + ")";
  }
  ncdata::JsonWriter j;
  head(j, "ioev", p.id);
  j.key("kind").string("step_progress");
  j.key("index").integer(p.step->index);
  j.key("filter").string(p.step->filter);
  j.key("label").string(text);
  j.key("done").unsignedInteger(done);
  j.key("total").unsignedInteger(total);
  j.key("fraction").number(total ? static_cast<double>(done) / static_cast<double>(total) : 1.0);
  j.endObject();
  nc::io::ide::sendProtocolLine("@IOEV", j.str());
}

void sendStepEvent(const std::string &id, const Step &s, const Outcome &o, const Value *y,
                   double seconds) {
  ncdata::JsonWriter j;
  head(j, "ioev", id);
  j.key("kind").string("step");
  j.key("index").integer(s.index);
  j.key("filter").string(s.filter);
  j.key("ok").boolean(o.ok);
  if (o.ok && y) {
    writeShape(j, *y);
  } else {
    j.key("error").string(o.error);
    if (o.line > 0)
      j.key("line").integer(o.line);
  }
  j.key("seconds").number(seconds);
  j.endObject();
  nc::io::ide::sendProtocolLine("@IOEV", j.str());
}

// ---- op:"process" -----------------------------------------------------------

// ---- the plan of a flow on the full data (2026-11-23, Phase 2) --------------
//
// docs/Large_Data_Design.md section 5.1. Check Flow runs the steps on a
// sample; the plan scales that to the whole data before Process Data runs:
//   - which steps stay a RULE on big data (computed when used, no memory):
//     found by running the flow once on a small rule with every element-wise
//     result forced lazy (ncew_detail::ForceLazyScope) - a step whose result
//     is still a rule is element-wise all through;
//   - the memory a stored step needs: the data (X, held anyway) + the step's
//     input + its output (sizes from the sample, scaled);
//   - the time of the stored steps (sample time, scaled; rules take theirs
//     where they are used);
//   - the verdict: does the extra memory fit the governor's budget now?

uint64_t elementsOf(const Value &v) {
  if (v.isArray || v.isMatrix) {
    if (v.isPacked())
      return v.packedSize();
    if (v.isTypedPacked() || v.isPackedComplex())
      return v.tensorCount();
    if (v.isND())
      return v.ndCount();
    return v.isArray ? v.length() : static_cast<uint64_t>(v.rows()) * v.cols();
  }
  return 1;
}
uint64_t bytesPerElement(const Value &v) {
  if (v.isTypedPacked())
    return elemTypeBytes(v.elemType());
  if (v.isPackedComplex())
    return 16;
  if (v.isPacked())
    return 8;
  return 32; // general cells
}

struct StepRecord {
  uint64_t inElems = 0, outElems = 0;
  double seconds = 0;
  bool ran = false;
};

void writePlan(ncdata::JsonWriter &j, const Value &data, const std::vector<Step> &steps,
               const std::vector<StepRecord> &rec, const std::vector<bool> &rule) {
  const uint64_t fullN = elementsOf(data);
  const uint64_t perElem = bytesPerElement(data);
  const uint64_t xBytes = data.lazyTensor() ? 0 : fullN * perElem;
  uint64_t yBytes = 0; // stored Y beyond X
  uint64_t cur = fullN;
  uint64_t peakExtra = 0;
  long worst = 0;
  double secs = 0;
  std::vector<long> rules;
  for (size_t i = 0; i < steps.size() && i < rec.size() && rec[i].ran; i++) {
    uint64_t out = cur;
    if (rec[i].outElems != rec[i].inElems && rec[i].inElems > 0)
      out = std::min<uint64_t>(cur, static_cast<uint64_t>(static_cast<double>(rec[i].outElems) *
                                                         static_cast<double>(cur) /
                                                         static_cast<double>(rec[i].inElems) + 0.5));
    const double scale = rec[i].inElems > 0 ? static_cast<double>(cur) / static_cast<double>(rec[i].inElems) : 1.0;
    const bool asRule = i < rule.size() && rule[i] && out == cur && ncew_detail::preferLazy(cur);
    if (asRule) {
      rules.push_back(steps[i].index); // a rule over the step's input: nothing new is stored
    } else {
      const uint64_t outBytes = out * 8u;
      const uint64_t extra = yBytes + outBytes; // the step's input and output beside X
      if (extra > peakExtra) {
        peakExtra = extra;
        worst = steps[i].index;
      }
      yBytes = outBytes;
      secs += rec[i].seconds * scale;
    }
    cur = out;
  }
  nc::mem::Budget b;
  const bool fitsRam = nc::mem::fits(peakExtra, &b);
  // Phase 3: what RAM cannot hold may go to the disk tier - tensor buffers
  // (element-wise results, materialize) and the external sort / unique.
  const uint64_t diskRoom = nc::mem::spillRoom();
  const bool onDisk = !fitsRam && b.enforced && b.known && peakExtra <= diskRoom;
  const bool fits = fitsRam || onDisk;
  std::string summary = "Full data (" + nc::mem::countText(fullN) + " elements): ";
  if (!rules.empty()) {
    std::string list;
    for (size_t k = 0; k < rules.size(); k++)
      list += (k ? ", " : "") + std::to_string(rules[k]);
    summary += (rules.size() == 1 ? "step " + list + " stays a rule" : "steps " + list + " stay rules") +
               " (computed when used); ";
  }
  char t[64];
  std::snprintf(t, sizeof t, "%.1f s", secs);
  if (fits && peakExtra == 0) {
    summary += "needs no extra memory.";
  } else if (onDisk) {
    summary += "step " + std::to_string(worst) + " needs " + nc::mem::bytesText(peakExtra) +
               " more memory; RAM has " + nc::mem::bytesText(b.available) + " free, so it will use the disk (" +
               nc::mem::bytesText(diskRoom) + " free there) - slower; element-wise steps, sort and unique "
               "can, other functions stop with the sizes; about " + t + " plus the disk time.";
  } else if (fits) {
    summary += "needs " + nc::mem::bytesText(peakExtra) + " more memory at most (" +
               nc::mem::bytesText(b.available) + " free); about " + t + ".";
  } else {
    summary += "step " + std::to_string(worst) + " needs " + nc::mem::bytesText(peakExtra) +
               " more memory; " + nc::mem::bytesText(b.available) + " is free and NC may use up to " +
               nc::mem::bytesText(b.cap) + ", and the disk has " + nc::mem::bytesText(diskRoom) +
               " to spare. Use fewer rows, float32, or steps that work element by element.";
  }
  j.key("plan").beginObject();
  j.key("elements").unsignedInteger(fullN);
  j.key("fits").boolean(fits);
  j.key("disk").boolean(onDisk);
  j.key("disk_free_bytes").unsignedInteger(diskRoom);
  j.key("data_bytes").unsignedInteger(xBytes);
  j.key("extra_bytes").unsignedInteger(peakExtra);
  j.key("worst_step").integer(worst);
  j.key("budget_bytes").unsignedInteger(b.cap);
  j.key("free_bytes").unsignedInteger(b.available);
  j.key("seconds").number(secs);
  j.key("rules").beginArray();
  for (long r : rules)
    j.integer(r);
  j.endArray();
  j.key("summary").string(summary);
  j.endObject();
}

void runProcess(Parser &parser, const std::string &id, const nc::io::TreeNode &req) {
  const Clock::time_point t0 = Clock::now();
  const std::string mode = textOf(req, "mode");
  const std::string dataName = textOf(req, "data");
  const std::string targetName = textOf(req, "target");
  const std::string outName = textOf(req, "out");
  const std::string helpers = textOf(req, "helpers");
  const double sample = numberOf(req, "sample", 0);
  if (mode != "check" && mode != "run")
    return answerError(id, "process", "mode must be \"check\" or \"run\"");
  auto &globals = parser.globalMemory();
  auto dataIt = globals.find(dataName);
  if (dataName.empty() || dataIt == globals.end())
    return answerError(id, "process", "no variable '" + dataName + "' in the workspace");
  Value target(0.0);
  if (!targetName.empty()) {
    auto t = globals.find(targetName);
    if (t == globals.end())
      return answerError(id, "process", "no target variable '" + targetName + "' in the workspace");
    target = t->second;
  }
  if (mode == "run") {
    std::string why;
    if (outName.empty() || !ncident::validateName(outName, why))
      return answerError(id, "process", "the output name '" + outName + "' is not a valid NC name" +
                                            (why.empty() ? "" : ": " + why));
  }

  // The steps.
  std::vector<Step> steps;
  const nc::io::TreeNode *list = req.find("steps");
  if (!list || list->type != nc::io::TreeNode::Array || list->items.empty())
    return answerError(id, "process", "there are no steps");
  bool hasShape = false;
  for (size_t i = 0; i < list->items.size(); i++) {
    const nc::io::TreeNode &n = list->items[i];
    if (n.type != nc::io::TreeNode::Object)
      return answerError(id, "process", "step " + std::to_string(i + 1) + " is not an object");
    Step s;
    s.index = static_cast<long>(numberOf(n, "index", static_cast<double>(i + 1)));
    s.filter = textOf(n, "filter");
    s.code = textOf(n, "code");
    s.on = textOf(n, "on");
    s.table = textOf(n, "table");
    if (const nc::io::TreeNode *cols = n.find("columns"))
      for (const auto &c : cols->items)
        if (c.type == nc::io::TreeNode::String)
          s.columns.push_back(c.str);
    hasShape = hasShape || s.filter == "shape";
    steps.push_back(std::move(s));
  }

  TableGuard guard(parser);
  // The Custom filter's helper functions.
  if (!helpers.empty()) {
    Parsed h = parseQuietly(helpers);
    if (!h.ok)
      return answerError(id, "process", "the custom functions do not parse: " + h.errors.front());
    for (const auto &stmt : h.program.statements)
      if (stmt->kind == StmtKind::FunctionDecl)
        guard.registerFrom(*stmt);
  }

  // Each step as its own function: Y = step(X, Y, target).
  static unsigned long runCounter = 0;
  const std::string prefix = "nc__process_" + std::to_string(++runCounter) + "_step_";
  for (Step &s : steps) {
    s.fn = prefix + std::to_string(s.index);
    std::string body;
    std::istringstream in(s.code);
    std::string line;
    while (std::getline(in, line)) {
      if (!line.empty() && line.back() == '\r')
        line.pop_back();
      body += (line.empty() ? "" : "   " + line) + "\n";
      s.codeLines++;
    }
    const std::string src = "function Y = " + s.fn + "(X, nc__y, target):\n   Y = nc__y;\n" + body + "fnend\n";
    Parsed p = parseQuietly(src);
    if (!p.ok) {
      // A step that does not parse: reported as that step's failure.
      long ln = 0, col = 0;
      splitSyntaxError(p.errors.front(), ln, col, s.parseError);
      s.parseLine = ln > kHeaderLines ? ln - kHeaderLines : 0;
      s.fn.clear();
      continue;
    }
    for (const auto &stmt : p.program.statements)
      if (stmt->kind == StmtKind::FunctionDecl)
        guard.registerFrom(*stmt);
  }

  // The data: a copy-on-write view (copying a packed Value shares its
  // buffer until someone writes).
  const bool quiet = mode == "check";
  Value x = dataIt->second;
  const Value fullData = x; // shared; the plan's size and kind
  const bool table = nc::ops::process::isTableObject(x);
  if (x.isObject && !table)
    return answerError(id, "process", "'" + dataName + "' is a " + x.className() +
                                          " - the steps work on values and loaded tables");
  if (mode == "check" && sample >= 1 && !hasShape) {
    const size_t n = static_cast<size_t>(sample);
    if (table) {
      if (nc::ops::process::tableRowCount(x) > n) {
        std::vector<size_t> keep(n);
        for (size_t r = 0; r < n; r++)
          keep[r] = r;
        Value cut;
        std::string err;
        if (nc::ops::process::tableTakeRows(x, keep, cut, err))
          x = cut;
      }
    } else {
      x = firstRows(x, n);
    }
  }
  Value y = x;
  std::vector<StepRecord> records(steps.size());

  long stoppedAt = 0;
  bool cancelled = false;
  std::string firstError;
  StepProgress progress{id, nullptr};
  nc::par::ProgressScope progressScope(&sendStepProgress, &progress);
  nc::par::loopResetForCommand(); // a step's for loops report from here
  for (const Step &s : steps) {
    if (nc::Interrupt::requested() || nc::Interrupt::pollNow()) {
      cancelled = true;
      stoppedAt = s.index;
      break;
    }
    progress.step = &s;
    const Clock::time_point ts = Clock::now();
    Outcome o;
    if (s.fn.empty()) { // did not parse
      o.ok = false;
      o.error = s.parseError;
      o.line = s.parseLine;
      if (!quiet)
        std::cerr << "Error: step " << s.index << ": " << o.error << "\n";
    } else if (table && nc::ops::process::isTableObject(y) && s.table != "whole") {
      // P6: every (chosen) column on its own.
      std::vector<std::string> names, xNames;
      std::vector<Value> cols, xCols;
      std::string err;
      if (!nc::ops::process::tableColumns(y, names, cols, err)) {
        o.ok = false;
        o.error = err;
      } else {
        nc::ops::process::tableColumns(x, xNames, xCols, err);
        // Column by column: "step_progress" with label "columns", done =
        // columns finished (2026-11-21). A long kernel inside one column
        // reports under its own label meanwhile.
        nc::par::SerialProgress columnsDone("columns", cols.size());
        for (size_t c = 0; c < cols.size() && o.ok; c++) {
          columnsDone.at(c);
          if (!s.columns.empty() &&
              std::find(s.columns.begin(), s.columns.end(), names[c]) == s.columns.end())
            continue;
          const bool text = isTextColumn(cols[c]);
          if ((s.on == "text" && !text) || (s.on == "numbers" && text))
            continue;
          Value xc = cols[c];
          for (size_t k = 0; k < xNames.size(); k++)
            if (xNames[k] == names[c])
              xc = xCols[k];
          Outcome co = callStep(parser, s, xc, cols[c], target, quiet);
          if (!co.ok) {
            o = co;
            o.error = "column '" + names[c] + "': " + co.error;
          }
        }
        if (o.ok) {
          Value rebuilt;
          if (!nc::ops::process::tableFromColumns(y, names, cols, rebuilt, err)) {
            o.ok = false;
            o.error = err;
            if (!quiet)
              std::cerr << "Error: step " << s.index << ": " << err << "\n";
          } else {
            y = std::move(rebuilt);
          }
        }
      }
    } else {
      o = callStep(parser, s, x, y, target, quiet);
    }
    progress.step = nullptr; // the step's own event closes it
    {
      const size_t at = static_cast<size_t>(&s - steps.data());
      records[at].seconds = secondsSince(ts);
      records[at].ran = o.ok;
      records[at].outElems = o.ok ? elementsOf(y) : 0;
      records[at].inElems = at == 0 ? elementsOf(x) : records[at - 1].outElems;
    }
    sendStepEvent(id, s, o, o.ok ? &y : nullptr, secondsSince(ts));
    if (!o.ok) {
      stoppedAt = s.index;
      firstError = o.error;
      cancelled = o.error == "stopped";
      break;
    }
  }

  const bool ok = stoppedAt == 0 && !cancelled;
  if (ok && mode == "run") {
    auto &g = parser.globalMemory();
    if (!g.count(outName))
      parser.globalInsertionOrder().push_back(outName);
    g[outName] = y;
  }

  ncdata::JsonWriter j;
  head(j, "io", id);
  j.key("op").string("process");
  j.key("ok").boolean(ok);
  j.key("mode").string(mode);
  j.key("stopped_at").integer(stoppedAt);
  j.key("cancelled").boolean(cancelled);
  j.key("seconds").number(secondsSince(t0));
  j.key("sampled").boolean(mode == "check" && sample >= 1 && !hasShape);
  if (ok) {
    writeShape(j, y);
    if (mode == "run")
      j.key("out").string(outName);
  }
  // Check Flow of numbers (not a table): the plan for the full data.
  if (ok && mode == "check" && !table && (fullData.isArray || fullData.isMatrix) &&
      (fullData.isPacked() || fullData.isTypedPacked())) {
    std::vector<bool> rule(steps.size(), false);
    {
      // The probe: the flow once on a small rule, every element-wise result
      // forced lazy, quiet. A step still giving a rule is element-wise.
      ncew_detail::ForceLazyScope force;
      const ncrange::Spec spec = ncrange::make(1e-6, (1.0 - 2e-6) / 69999.0, 1.0 - 1e-6, '[', ']');
      const Value probe = Value::lazyRow(spec);
      Value py = probe;
      for (size_t i = 0; i < steps.size(); i++) {
        if (steps[i].fn.empty())
          break;
        const Outcome po = callStep(parser, steps[i], probe, py, target, /*quiet=*/true);
        if (!po.ok)
          break;
        rule[i] = py.lazyTensor() != nullptr;
      }
    }
    writePlan(j, fullData, steps, records, rule);
  }
  j.key("error").string(cancelled ? std::string("cancelled") : firstError);
  j.endObject();
  nc::io::ide::sendProtocolLine("@IO", j.str());
}

// ---- op:"check" ----------------------------------------------------------------

void runCheck(const std::string &id, const nc::io::TreeNode &req) {
  const std::string code = textOf(req, "code");
  Parsed p = parseQuietly(code);
  ncdata::JsonWriter j;
  head(j, "io", id);
  j.key("op").string("check");
  j.key("ok").boolean(true);
  j.key("valid").boolean(p.ok);
  j.key("errors").beginArray();
  if (!p.ok) {
    for (const std::string &e : p.errors) {
      long ln = 0, col = 0;
      std::string message;
      splitSyntaxError(e, ln, col, message);
      j.beginObject();
      j.key("line").integer(ln);
      j.key("col").integer(col);
      j.key("message").string(message);
      j.endObject();
    }
  }
  j.endArray();
  j.endObject();
  nc::io::ide::sendProtocolLine("@IO", j.str());
}

} // namespace

void handleRequest(Parser &parser, const std::string &kind, const std::string &id,
                   const std::string &json) {
  nc::io::TreeNode req;
  std::string err;
  if (!nc::io::parseJson(json, false, req, err) || req.type != nc::io::TreeNode::Object)
    return answerError(id, kind, "the request is not a JSON object: " + err);
  // A failed allocation in the runner itself (2026-11-23): the flow ends with
  // an error answer, nc.exe stays up, the workspace keeps what it had.
  try {
    if (kind == "check")
      return runCheck(id, req);
    return runProcess(parser, id, req);
  } catch (const std::bad_alloc &e) {
    answerError(id, kind, nc::mem::outOfMemoryText(e));
  } catch (const std::length_error &e) {
    answerError(id, kind, nc::mem::outOfMemoryText(e));
  }
}

} // namespace process
} // namespace nc
