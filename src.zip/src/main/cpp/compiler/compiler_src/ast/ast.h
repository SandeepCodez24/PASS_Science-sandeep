#pragma once
#include <cstddef>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

// Maximum number of iterations a single execution of a `while` statement may
// run before it is stopped with a runtime error. Shared by BOTH execution
// paths - the tree-walking interpreter (parser_exec_stmt.cpp's While case)
// and the LLVM JIT (codegen.cpp's While case, via nc_bridge_report_while_limit)
// - so a loop behaves the same whichever path runs it. Raised from 100,000 to
// 200,000 on request.
constexpr int kMaxWhileIterations = 200000;

// The exact runtime-error text for exceeding kMaxWhileIterations (number
// printed with thousands separators, e.g. "200,000").
inline std::string whileLimitErrorText() {
  std::string n = std::to_string(kMaxWhileIterations);
  for (int i = static_cast<int>(n.size()) - 3; i > 0; i -= 3)
    n.insert(static_cast<std::size_t>(i), ",");
  return "✖ Runtime Error: Maximum while loop iteration limit (" + n + ") exceeded\n";
}

// AST node types for NC (Phase 1 of the AST-rewrite roadmap - see
// docs/Cross_Platform_CMake_Build_Change_Report.md's companion planning
// discussion). These are the tree the parser builds instead of computing a
// Value directly while parsing; a separate evaluator walks the result.
//
// Design: one tagged struct per node category (Expr, Stmt), fields reused
// across kinds - not a virtual-dispatch class hierarchy. This mirrors the
// existing Value struct's own style (runtime/interpreter/core/value.h:
// isText/isArray/isMatrix/isDict flags over shared storage) rather than
// introducing a second, different idiom into the codebase. It also sidesteps
// incomplete-type ordering headaches: Expr only ever contains Expr, and Stmt
// only ever contains Expr and Stmt, so nothing needs a forward declaration
// beyond the struct itself.
//
// `children` on Expr is a generic operand/argument list whose meaning
// depends on `kind` (documented per kind below) - e.g. BinaryOp's two
// operands, a Call's arguments, an ArrayLiteral's elements. This keeps
// operator/call-like variants (the majority) from each needing their own
// named fields, the same trade Value makes for array/matrix/dict. The one
// shape that doesn't fit a flat operand list - RangeLiteral's start/stop/
// optional-step - gets its own named fields instead of overloading
// `children`, rather than forcing a 2-or-3-element convention onto callers.
//
// Deliberately no Value dependency anywhere in this file: every Expr is
// built by pure syntax, with zero memory/constant/function-table lookups at
// parse time (an earlier revision of parser_factor.cpp's IDENT handling did
// resolve a few things eagerly during parsing - a bare zero-arg function
// call, a dict builtin's implicit receiver-as-arg0 - each wrapped in a
// since-removed PrecomputedValue node; both moved into evaluateExpr()
// instead, since parsing a whole file or function body once and evaluating
// it many times - the point of this phase - requires every value-dependent
// decision to happen at evaluate time, never at parse time).

enum class ExprKind {
    NumberLiteral,   // number
    StringLiteral,   // text
    Identifier,      // text = variable name. Always evaluated by a fresh
                     // lookup at evaluate time (memory, then constants, then
                     // unit constants) - deliberately never caches a
                     // resolved Value on the node itself, so a tree built
                     // once and evaluated many times (a function body, a
                     // loop body) sees each execution's actual current
                     // value rather than whatever the name meant when the
                     // tree was built. MethodCall/FieldAccess/Index's
                     // receiver is always one of these when the receiver is
                     // a bare identifier (the only shape this grammar
                     // supports); `text` (the name) doubles as the target
                     // for a mutation write-back (memory[name] = ...) in
                     // those cases.
    ArrayLiteral,    // children = elements
    MatrixLiteral,   // children = rows, each row itself an ArrayLiteral Expr
    RangeLiteral,    // rangeStart, rangeStop, rangeStep (rangeStep may be null
                     // => step 1); text = 2 chars, left+right bracket
                     // ('['/'(' then ']'/')'), for inclusive/exclusive ends
    UnaryOp,         // text = operator ("-", "!"); children[0] = operand
    AbsOrNorm,       // |x| - children[0] = operand
    BinaryOp,        // text = operator ("+","-","*","/","%","//","^"); children[0], children[1]
    Comparison,      // text = operator ("==","!=","<",">","<=",">="); children[0], children[1]
    LogicalOp,       // text = operator ("&&","||","nand","nor"); children[0], children[1]
    Call,            // text = callee name (builtin, user function, or ClassName(...) constructor
                     // call - which one is a resolution-time question, not a parse-time one);
                     // children = arguments
    MethodCall,      // text = method name; children[0] = receiver, children[1..] = arguments
    FieldAccess,     // text = field name; children[0] = receiver
    Index,           // children[0] = container, children[1..] = key/index expressions
                     // (one Index node per bracket group - A[row][col] is
                     // Index(Index(A, [row]), [col]), same as the source syntax)
    ParentCall,      // parent(args) - children = arguments
    FunctionRef,     // @name - text = function name. A first-class reference
                     // to a user-defined function, NOT a call - the only way
                     // to pass a function itself into another function (e.g.
                     // `grad(@f, [1,2,3])`), since a bare `f` (no `@`) either
                     // eagerly calls a zero-arg overload or fails ("Unknown
                     // constant"). Resolved against functionTable_ at
                     // evaluate time (same deferred-resolution principle as
                     // Identifier above - never resolved at parse time,
                     // since a forward-referenced function must still work).
                     // MATLAB-style syntax choice (this language's own
                     // "MATLAB-like" self-description) deliberately reusing
                     // the otherwise-unused-in-expression-position AT token
                     // (previously only consumed inside a class header's
                     // `@rate(...)` - a completely separate parse path, so
                     // no collision).
    Wildcard,        // bare ':' used as one key inside an Index bracket
                     // group, meaning "every element along this dimension"
                     // (A[n,:] selects/assigns row n, A[:,n] column n). Only
                     // meaningful as a direct key of an Index node; no
                     // fields used.
};

struct Expr {
    ExprKind kind;

    double number = 0;
    std::string text;

    // NumberLiteral only: an imaginary literal (`3i`), i.e. `number`
    // imaginary units rather than the real number `number`.
    bool imaginary = false;

    std::vector<std::unique_ptr<Expr>> children;

    // RangeLiteral only.
    std::unique_ptr<Expr> rangeStart;
    std::unique_ptr<Expr> rangeStop;
    std::unique_ptr<Expr> rangeStep;

    // Phase 6 (slot-indexed scope resolution): resolveFunctionSlots()
    // (parser_resolve.cpp) stamps this on an Identifier node with the
    // variable's fixed index into the active call frame's `slots_` vector,
    // once it's determined the whole function/method body never needs
    // dynamic string-keyed lookup for that name - or on a FieldAccess node
    // (its own `text` doubling as a plain variable name for the
    // elementwise-dot-operator fallback in evaluateExpr(), see that case).
    // -1 (the default, and the only value ever seen outside a resolved
    // function/method body) means "not resolved - use the existing
    // `memory` string-keyed path", which is always correct, just not fast;
    // resolution is a pure optimization; a script's own observable
    // behavior never depends on whether a read is slotted.
    int slot = -1;
};

enum class StmtKind {
    ExprStmt,      // expr
    Assign,        // targets (size 1 for a plain assignment, >1 for
                   // multi-output (A,B) = f(...)); value. Each target is
                   // whatever expression the assigned-to location parses as
                   // (Identifier, FieldAccess, or Index for
                   // A[row][col] = v / A['key'] = v).
    If,            // condition, body (then-branch), elseifBranches, elseBody
    For,           // loopVar, iterable (a RangeLiteral for `for i = [a:b]`,
                   // any other expr for `for x in collection`), body
    While,         // condition, body
    Break,
    Continue,
    Return,
    Require,       // condition, conditionText = raw source text of the
                   // condition (kept only for the "precondition failed:
                   // <text>" message, built in parser_program.cpp's
                   // parseStmtNode())
    Ensure,        // same shape as Require
    FunctionDecl,  // name, inputNames, outputNames, body
    ClassDecl,     // name, parentClassName, isAbstract, isReversible,
                   // hasRate, rateHz, restrictedFields, methods (each a
                   // FunctionDecl-kind Stmt; the constructor is the one
                   // named "base", same convention as today's ClassDef)
    Publish,       // print/publish (synonyms - identical behavior): publishArgs;
                   // always prints and never updates `ans`, regardless of a
                   // trailing ';' (suppressOutput is meaningless for this kind)
    ClearMemory,   // new/clear/cls (synonyms - identical behavior): name holds
                   // which spelling was used, informational only
};

struct Stmt {
    StmtKind kind;

    // 1-based source line this statement's first token came from (see
    // Token::line, token.h). Populated by makeStmt() (parser_program.cpp)
    // at construction time; used by the step-into debug pause hook
    // (executeStmtList, parser_exec_stmt.cpp) to report "@STEPAT <line>"
    // to the Java IDE. 0 means unset/unknown.
    size_t line = 0;

    // Set once a semicolon is actually consumed after this statement;
    // false means the language's MATLAB-style auto-echo-on-no-semicolon
    // behavior applies when this statement runs (see printValue() call
    // sites in parser_exec_stmt.cpp) - surface syntax the evaluator can't
    // recover from the parsed value alone, so it has to survive into the tree.
    bool suppressOutput = false;

    // ExprStmt
    std::unique_ptr<Expr> expr;

    // Assign
    std::vector<std::unique_ptr<Expr>> targets;
    std::unique_ptr<Expr> value;

    // If / For / While condition (If, While) or iterable (For)
    std::unique_ptr<Expr> condition;
    std::string loopVar;         // For only
    int loopVarSlot = -1;        // For only - see Expr::slot's comment
    std::unique_ptr<Expr> iterable; // For only

    // Body shared by If (then-branch), For, While, FunctionDecl.
    std::vector<std::unique_ptr<Stmt>> body;
    std::vector<std::pair<std::unique_ptr<Expr>, std::vector<std::unique_ptr<Stmt>>>> elseifBranches;
    std::vector<std::unique_ptr<Stmt>> elseBody;

    // Require / Ensure
    std::string conditionText;

    // FunctionDecl
    std::string name;
    std::vector<std::string> inputNames;
    std::vector<std::string> outputNames;

    // ClassDecl
    std::string parentClassName;
    bool isAbstract = false;
    bool isReversible = false;
    bool hasRate = false;
    double rateHz = 0.0;
    std::unordered_map<std::string, bool> restrictedFields; // true = protected, false = private
    std::vector<std::unique_ptr<Stmt>> methods; // each a FunctionDecl-kind Stmt
    // Set when a method header inside this class failed to parse (or was
    // rejected as a required-but-missing body) - the old text-based
    // executeClassDefEnd() aborts registering the WHOLE class the moment
    // any one method is malformed, rather than partially registering it.
    // registerClassDeclStmt() must skip classTable_ registration when this
    // is set, matching that behavior.
    bool classRegistrationFailed = false;

    // Publish
    std::vector<std::unique_ptr<Expr>> publishArgs;
};

struct Program {
    std::vector<std::unique_ptr<Stmt>> statements;
};
