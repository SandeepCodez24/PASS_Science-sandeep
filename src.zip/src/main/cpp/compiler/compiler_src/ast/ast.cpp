#include "ast.h"

// Phase 1 has nothing to implement yet - this translation unit exists only
// so the CMake build actually compiles ast.h (constructing one of every
// field shape, including the self-recursive unique_ptr members) rather than
// the header sitting untouched and unverified until some later phase
// #includes it for the first time.
namespace {

std::unique_ptr<Expr> makeNumber(double n) {
    auto e = std::make_unique<Expr>();
    e->kind = ExprKind::NumberLiteral;
    e->number = n;
    return e;
}

[[maybe_unused]] std::unique_ptr<Stmt> buildSampleProgramForCompileCheck() {
    // if x > 1: y = x + [1, 2]; iend
    auto cond = std::make_unique<Expr>();
    cond->kind = ExprKind::Comparison;
    cond->text = ">";
    cond->children.push_back(makeNumber(0));
    cond->children.push_back(makeNumber(1));

    auto arrayLit = std::make_unique<Expr>();
    arrayLit->kind = ExprKind::ArrayLiteral;
    arrayLit->children.push_back(makeNumber(1));
    arrayLit->children.push_back(makeNumber(2));

    auto sum = std::make_unique<Expr>();
    sum->kind = ExprKind::BinaryOp;
    sum->text = "+";
    sum->children.push_back(makeNumber(0));
    sum->children.push_back(std::move(arrayLit));

    auto target = std::make_unique<Expr>();
    target->kind = ExprKind::Identifier;
    target->text = "y";

    auto assign = std::make_unique<Stmt>();
    assign->kind = StmtKind::Assign;
    assign->targets.push_back(std::move(target));
    assign->value = std::move(sum);

    auto ifStmt = std::make_unique<Stmt>();
    ifStmt->kind = StmtKind::If;
    ifStmt->condition = std::move(cond);
    ifStmt->body.push_back(std::move(assign));

    auto range = std::make_unique<Expr>();
    range->kind = ExprKind::RangeLiteral;
    range->rangeStart = makeNumber(1);
    range->rangeStop = makeNumber(5);

    auto forStmt = std::make_unique<Stmt>();
    forStmt->kind = StmtKind::For;
    forStmt->loopVar = "i";
    forStmt->iterable = std::move(range);
    forStmt->body.push_back(std::move(ifStmt));

    // function describe(): for i = [1:5]: ... iend fend fnend
    auto method = std::make_unique<Stmt>();
    method->kind = StmtKind::FunctionDecl;
    method->name = "describe";
    method->body.push_back(std::move(forStmt));

    auto classDecl = std::make_unique<Stmt>();
    classDecl->kind = StmtKind::ClassDecl;
    classDecl->name = "Shape";
    classDecl->restrictedFields["label"] = false;
    classDecl->methods.push_back(std::move(method));

    Program program;
    program.statements.push_back(std::move(classDecl));
    return std::move(program.statements.front());
}

} // namespace
