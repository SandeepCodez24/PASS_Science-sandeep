#include "jit_engine.h"

#include "codegen.h"

#include "../ast/ast.h"
#include "../parser/parser.h"

#include "llvm/ExecutionEngine/Orc/LLJIT.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/Support/TargetSelect.h"

#include <mutex>
#include <string>

namespace {

// InitializeNativeTarget*() must run exactly once per process, no matter
// how many JitEngine instances get constructed.
void ensureNativeTargetInitialized() {
  static std::once_flag flag;
  std::call_once(flag, [] {
    llvm::InitializeNativeTarget();
    llvm::InitializeNativeTargetAsmPrinter();
    llvm::InitializeNativeTargetAsmParser();
  });
}

} // namespace

JitEngine::JitEngine() {
  ensureNativeTargetInitialized();
  jit_ = llvm::cantFail(llvm::orc::LLJITBuilder().create());
  // Bridge functions (nc_bridge_*, defined in value_bridge.cpp) are linked
  // directly into whatever process embeds this engine - resolve JIT'd
  // calls to them against this process's own symbols rather than trying to
  // load them from a separate module.
  jit_->getMainJITDylib().addGenerator(llvm::cantFail(
      llvm::orc::DynamicLibrarySearchGenerator::GetForCurrentProcess(
          jit_->getDataLayout().getGlobalPrefix())));
}

// Defined here (not defaulted in the header) because llvm::orc::LLJIT is
// only forward-declared there - see jit_engine.h's comment.
JitEngine::~JitEngine() = default;

bool JitEngine::runStmt(const Stmt *stmt, Parser &parser) {
  // Native ClassDecl/FunctionDecl compilation (CodeGen::compileClassConstructor/
  // compileInstanceMethod/the StmtKind::FunctionDecl case) only ever
  // populates CodeGen's OWN compile-time registries (classCtorArity_/
  // functionArity_/instanceMethods_, carried forward via knownClasses_/
  // knownFunctions_/knownMethods_ below) - it never touches the tree-
  // walker's classTable_/functionTable_ at all. Those still matter even
  // for a natively-compiled class/function: checkFieldAccess() (called
  // from nc_bridge_field_get/set now) walks classTable_ to find a field's
  // declared visibility, and nc_bridge_call_dynamic's hasClass()/
  // hasFunction() tiers need it for anything JIT doesn't natively resolve.
  // ScriptManager::executeFile()'s Pass 1 (registerTopLevelDecls(), for
  // forward-reference support) already does this for whole-file execution,
  // but the REPL and any other single-statement-at-a-time caller of this
  // very method does not - so this happens here too, unconditionally,
  // regardless of whether native compilation below also succeeds.
  // registerOverload() (parser_exec_stmt.cpp) replaces an existing
  // overload of the same arity in place, so calling this a second time
  // (e.g. once here, once via a caller's own Pass 1) is a harmless no-op,
  // not a correctness risk. Found via real corpus testing that this
  // harness's OWN direct-statement-loop tests don't reach, but a real REPL
  // session would: a private field, once natively compiled without this,
  // was silently readable from outside its class because checkFieldAccess()
  // found nothing in an empty classTable_ and defaulted to "public".
  if (stmt->kind == StmtKind::ClassDecl)
    parser.registerClassDeclStmt(*stmt);
  else if (stmt->kind == StmtKind::FunctionDecl)
    parser.registerFunctionDeclStmt(*stmt);

  // Unique per call, for this engine's whole lifetime - LLJIT sessions
  // reject a second definition of the same symbol, and this engine is
  // meant to compile many statements over its life, one entry function
  // each.
  std::string entryName = "nc_jit_entry_" + std::to_string(callCounter_++);

  // One fresh LLVMContext per compiled statement (not shared across calls)
  // - IR modules built in different contexts are still addable to the same
  // LLJIT session as separate ThreadSafeModules, which is exactly what
  // happens below. Simpler and safer than trying to share one context
  // across many independently-compiled modules; the tradeoff is a small,
  // unbounded number of live LLVMContexts accumulating for as long as this
  // engine lives (each one small - one function's worth of IR) - fine for
  // this step, revisit if a long-running engine's memory footprint ever
  // matters.
  auto llvmCtx = std::make_unique<llvm::LLVMContext>();
  CodeGen cg(*llvmCtx, "nc_jit_module_" + entryName);
  // Carry forward every user function a PREVIOUS runStmt() call defined -
  // required for a Call in this statement to invoke a function whose
  // FunctionDecl was compiled (and already added to this same persistent
  // JIT session) by an earlier, separate call. See codegen.h's "Recursion
  // and calls across separate compile calls" and this header's own
  // comment on knownFunctions_.
  cg.seedKnownFunctions(knownFunctions_);
  // Same carry-forward, for classes/instance methods - see this header's
  // own comment on knownClasses_/knownMethods_.
  cg.seedKnownClasses(knownClasses_);
  cg.seedKnownMethods(knownMethods_);
  // Same carry-forward, for cross-class method-name collision tracking -
  // see jit_engine.h's own comment on methodNameOwners_/ambiguousMethods_
  // and codegen.h's seedMethodNameOwnership() for the full mechanism.
  cg.seedMethodNameOwnership(methodNameOwners_, ambiguousMethods_);
  auto module = cg.compileStatements({stmt}, entryName);

  // Unlike newlyDefinedFunctions()/newlyDefinedClasses()/newlyDefinedMethods()
  // below, this carry-forward happens BEFORE the `!module` bailout, not
  // after: registerMethodNamesForCollisionCheck() (codegen.cpp) runs as the
  // very first thing in StmtKind::ClassDecl, unconditionally, specifically
  // so a class this slice goes on to REJECT (inheritance/abstract/
  // reversible/@rate - see codegen.h's own comment) still has its method
  // names seen. A rejected ClassDecl is exactly a case where `module` ends
  // up null (ok_ = false from that same rejection) - carrying this forward
  // only on success would mean it's never carried forward for the one case
  // that matters most (e.g. `class Dog(Animal): function s=speak(): ...`
  // being rejected is precisely when "speak" needs to be marked ambiguous
  // against a plain, natively-compiled Animal that also defines it).
  methodNameOwners_ = cg.methodNameOwnersAfterCompile();
  ambiguousMethods_ = cg.ambiguousMethodNamesAfterCompile();

  if (!module)
    return false; // unsupported node - CodeGen already logged why

  llvm::orc::ThreadSafeModule tsm(std::move(module),
                                   llvm::orc::ThreadSafeContext(std::move(llvmCtx)));
  if (auto err = jit_->addIRModule(std::move(tsm))) {
    llvm::consumeError(std::move(err));
    return false;
  }

  // Whatever FunctionDecl(s)/ClassDecl(s) this statement just defined are
  // now real, linked-in symbols in the JIT session - remember them so a
  // LATER runStmt() call's Call/MethodCall can resolve them too.
  for (const auto &fn : cg.newlyDefinedFunctions())
    knownFunctions_.push_back(fn);
  for (const auto &cls : cg.newlyDefinedClasses())
    knownClasses_.push_back(cls);
  for (const auto &m : cg.newlyDefinedMethods())
    knownMethods_.push_back(m);

  auto symOrErr = jit_->lookup(entryName);
  if (!symOrErr) {
    llvm::consumeError(symOrErr.takeError());
    return false;
  }

  auto fn = symOrErr->toPtr<void (*)(void *)>();
  fn(static_cast<void *>(&parser));
  return true;
}
