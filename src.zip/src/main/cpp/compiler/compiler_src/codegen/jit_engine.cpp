#include "jit_engine.h"

#include "codegen.h"

#include "../ast/ast.h"
#include "../parser/parser.h"
#include "../../../runtime/execution/parallel/par.h"
#include "../../../runtime/interpreter/codegen_bridge/value_bridge.h"

#include "llvm/ExecutionEngine/Orc/AbsoluteSymbols.h"
#include "llvm/ExecutionEngine/Orc/LLJIT.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/Support/TargetSelect.h"

#include <algorithm>
#include <mutex>
#include <string>

namespace {

// Every extern "C" function in value_bridge.h, by name and address.
//
// JIT'd code calls these by name. They used to be found only through
// DynamicLibrarySearchGenerator::GetForCurrentProcess, which on Windows
// asks GetProcAddress - and that only sees functions the .exe EXPORTS.
// nc.exe exports none, so every compiled statement failed with
// "JIT session error: Symbols not found: [ nc_bridge_... ]" (on Linux the
// same happens without -rdynamic). Registering the addresses directly
// works the same on every OS and needs no linker/export settings.
//
// When a function is added to value_bridge.h, add it here too. A missing
// entry shows up as that "Symbols not found" error, and the parity harness
// (runBridgeSymbolListCase) compares this list with the header.
struct BridgeSymbol {
  const char *name;
  void *address;
};

#define NC_BRIDGE_SYMBOL(fn) BridgeSymbol{#fn, reinterpret_cast<void *>(&fn)}

const BridgeSymbol kBridgeSymbols[] = {
    NC_BRIDGE_SYMBOL(nc_bridge_abs_or_norm),
    NC_BRIDGE_SYMBOL(nc_bridge_abs_or_norm_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_add),
    NC_BRIDGE_SYMBOL(nc_bridge_analysis_loop_begin),
    NC_BRIDGE_SYMBOL(nc_bridge_analysis_loop_depth),
    NC_BRIDGE_SYMBOL(nc_bridge_analysis_loop_end),
    NC_BRIDGE_SYMBOL(nc_bridge_analysis_loop_iteration),
    NC_BRIDGE_SYMBOL(nc_bridge_analysis_scalar_op),
    NC_BRIDGE_SYMBOL(nc_bridge_analysis_statement),
    NC_BRIDGE_SYMBOL(nc_bridge_array_from_elements),
    NC_BRIDGE_SYMBOL(nc_bridge_binary_op_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_call_dynamic),
    NC_BRIDGE_SYMBOL(nc_bridge_clear_memory),
    NC_BRIDGE_SYMBOL(nc_bridge_comparison_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_div),
    NC_BRIDGE_SYMBOL(nc_bridge_eq),
    NC_BRIDGE_SYMBOL(nc_bridge_factorial),
    NC_BRIDGE_SYMBOL(nc_bridge_field_get),
    NC_BRIDGE_SYMBOL(nc_bridge_field_set),
    NC_BRIDGE_SYMBOL(nc_bridge_floordiv),
    NC_BRIDGE_SYMBOL(nc_bridge_get_evaluation_succeeded),
    NC_BRIDGE_SYMBOL(nc_bridge_get_number),
    NC_BRIDGE_SYMBOL(nc_bridge_gt),
    NC_BRIDGE_SYMBOL(nc_bridge_gte),
    NC_BRIDGE_SYMBOL(nc_bridge_index_get),
    NC_BRIDGE_SYMBOL(nc_bridge_index_get_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_index_set),
    NC_BRIDGE_SYMBOL(nc_bridge_logical_and),
    NC_BRIDGE_SYMBOL(nc_bridge_logical_nand),
    NC_BRIDGE_SYMBOL(nc_bridge_logical_nor),
    NC_BRIDGE_SYMBOL(nc_bridge_logical_or),
    NC_BRIDGE_SYMBOL(nc_bridge_lt),
    NC_BRIDGE_SYMBOL(nc_bridge_lte),
    NC_BRIDGE_SYMBOL(nc_bridge_matrix_build_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_matrix_from_rows),
    NC_BRIDGE_SYMBOL(nc_bridge_mod),
    NC_BRIDGE_SYMBOL(nc_bridge_mul),
    NC_BRIDGE_SYMBOL(nc_bridge_neg),
    NC_BRIDGE_SYMBOL(nc_bridge_neg_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_not_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_factorial_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_neq),
    NC_BRIDGE_SYMBOL(nc_bridge_not),
    NC_BRIDGE_SYMBOL(nc_bridge_poll_interrupt),
    NC_BRIDGE_SYMBOL(nc_bridge_pop_defining_class),
    NC_BRIDGE_SYMBOL(nc_bridge_pop_scope),
    NC_BRIDGE_SYMBOL(nc_bridge_pow),
    NC_BRIDGE_SYMBOL(nc_bridge_print_value),
    NC_BRIDGE_SYMBOL(nc_bridge_publish),
    NC_BRIDGE_SYMBOL(nc_bridge_push_defining_class),
    NC_BRIDGE_SYMBOL(nc_bridge_push_scope),
    NC_BRIDGE_SYMBOL(nc_bridge_range_iteration_count),
    NC_BRIDGE_SYMBOL(nc_bridge_range_should_continue),
    NC_BRIDGE_SYMBOL(nc_bridge_range_value),
    NC_BRIDGE_SYMBOL(nc_bridge_read_declared_output),
    NC_BRIDGE_SYMBOL(nc_bridge_report_condition_failure),
    NC_BRIDGE_SYMBOL(nc_bridge_report_endless_range),
    NC_BRIDGE_SYMBOL(nc_bridge_report_index_set_failure),
    NC_BRIDGE_SYMBOL(nc_bridge_report_while_limit),
    NC_BRIDGE_SYMBOL(nc_bridge_report_zero_range_step),
    NC_BRIDGE_SYMBOL(nc_bridge_reset_evaluation_succeeded),
    NC_BRIDGE_SYMBOL(nc_bridge_save_to_file),
    NC_BRIDGE_SYMBOL(nc_bridge_signal_top_level_return),
    NC_BRIDGE_SYMBOL(nc_bridge_sub),
    NC_BRIDGE_SYMBOL(nc_bridge_transpose_checked),
    NC_BRIDGE_SYMBOL(nc_bridge_truthy),
    NC_BRIDGE_SYMBOL(nc_bridge_value_create),
    NC_BRIDGE_SYMBOL(nc_bridge_value_destroy),
    NC_BRIDGE_SYMBOL(nc_bridge_value_is_plain_number),
    NC_BRIDGE_SYMBOL(nc_bridge_value_set_bool),
    NC_BRIDGE_SYMBOL(nc_bridge_value_set_imaginary),
    NC_BRIDGE_SYMBOL(nc_bridge_value_set_number),
    NC_BRIDGE_SYMBOL(nc_bridge_value_set_object),
    NC_BRIDGE_SYMBOL(nc_bridge_value_set_text),
    NC_BRIDGE_SYMBOL(nc_bridge_var_read),
    NC_BRIDGE_SYMBOL(nc_bridge_var_write),
};

#undef NC_BRIDGE_SYMBOL

// InitializeNativeTarget*() must run exactly once per process, no matter
// how many JitEngine instances get constructed.
void ensureNativeTargetInitialized() {
  static std::once_flag flag;
  std::call_once(flag, [] {
    llvm::InitializeNativeTarget();
    llvm::InitializeNativeTargetAsmPrinter();
    llvm::InitializeNativeTargetAsmParser();
  });
}

} // namespace

JitEngine::JitEngine() {
  ensureNativeTargetInitialized();
  jit_ = llvm::cantFail(llvm::orc::LLJITBuilder().create());
  // Bridge functions (nc_bridge_*, defined in value_bridge.cpp) are linked
  // directly into whatever process embeds this engine. Register each one by
  // address (see kBridgeSymbols above) - this is what makes them findable
  // on Windows, where the .exe exports nothing.
  llvm::orc::SymbolMap bridge;
  for (const BridgeSymbol &sym : kBridgeSymbols)
    bridge[jit_->mangleAndIntern(sym.name)] = llvm::orc::ExecutorSymbolDef(
        llvm::orc::ExecutorAddr::fromPtr(sym.address),
        llvm::JITSymbolFlags::Exported | llvm::JITSymbolFlags::Callable);
  llvm::cantFail(jit_->getMainJITDylib().define(llvm::orc::absoluteSymbols(std::move(bridge))));
  // Anything else JIT'd code may reference from this process (none today)
  // is still searched for in the process itself, as before.
  jit_->getMainJITDylib().addGenerator(llvm::cantFail(
      llvm::orc::DynamicLibrarySearchGenerator::GetForCurrentProcess(
          jit_->getDataLayout().getGlobalPrefix())));
}

// Defined here (not defaulted in the header) because llvm::orc::LLJIT is
// only forward-declared there - see jit_engine.h's comment.
JitEngine::~JitEngine() = default;

std::vector<std::string> JitEngine::registeredBridgeSymbols() {
  std::vector<std::string> names;
  for (const BridgeSymbol &sym : kBridgeSymbols)
    names.emplace_back(sym.name);
  return names;
}

bool JitEngine::runStmt(const Stmt *stmt, Parser &parser) {
  // Compiled code runs on the interpreter thread only (multicore rule 1 -
  // value_bridge.h): it replaces the tree-walker, not the threading model.
  // Debug builds stop here if this is ever reached from a worker thread.
  nc::par::assertInterpreterThread("JitEngine::runStmt");

  // Native ClassDecl/FunctionDecl compilation (CodeGen::compileClassConstructor/
  // compileInstanceMethod/the StmtKind::FunctionDecl case) only ever
  // populates CodeGen's OWN compile-time registries (classCtorArity_/
  // functionArity_/instanceMethods_, carried forward via knownClasses_/
  // knownFunctions_/knownMethods_ below) - it never touches the tree-
  // walker's classTable_/functionTable_ at all. Those still matter even
  // for a natively-compiled class/function: checkFieldAccess() (called
  // from nc_bridge_field_get/set now) walks classTable_ to find a field's
  // declared visibility, and nc_bridge_call_dynamic's hasClass()/
  // hasFunction() tiers need it for anything JIT doesn't natively resolve.
  // ScriptManager::executeFile()'s Pass 1 (registerTopLevelDecls(), for
  // forward-reference support) already does this for whole-file execution,
  // but the REPL and any other single-statement-at-a-time caller of this
  // very method does not - so this happens here too, unconditionally,
  // regardless of whether native compilation below also succeeds.
  // registerOverload() (parser_exec_stmt.cpp) replaces an existing
  // overload of the same arity in place, so calling this a second time
  // (e.g. once here, once via a caller's own Pass 1) is a harmless no-op,
  // not a correctness risk. Found via real corpus testing that this
  // harness's OWN direct-statement-loop tests don't reach, but a real REPL
  // session would: a private field, once natively compiled without this,
  // was silently readable from outside its class because checkFieldAccess()
  // found nothing in an empty classTable_ and defaulted to "public".
  if (stmt->kind == StmtKind::ClassDecl)
    parser.registerClassDeclStmt(*stmt);
  else if (stmt->kind == StmtKind::FunctionDecl)
    parser.registerFunctionDeclStmt(*stmt);

  // Unique per call, for this engine's whole lifetime - LLJIT sessions
  // reject a second definition of the same symbol, and this engine is
  // meant to compile many statements over its life, one entry function
  // each.
  std::string entryName = "nc_jit_entry_" + std::to_string(callCounter_++);

  // One fresh LLVMContext per compiled statement (not shared across calls)
  // - IR modules built in different contexts are still addable to the same
  // LLJIT session as separate ThreadSafeModules, which is exactly what
  // happens below. Simpler and safer than trying to share one context
  // across many independently-compiled modules; the tradeoff is a small,
  // unbounded number of live LLVMContexts accumulating for as long as this
  // engine lives (each one small - one function's worth of IR) - fine for
  // this step, revisit if a long-running engine's memory footprint ever
  // matters.
  auto llvmCtx = std::make_unique<llvm::LLVMContext>();
  CodeGen cg(*llvmCtx, "nc_jit_module_" + entryName);
  // Carry forward every user function a PREVIOUS runStmt() call defined -
  // required for a Call in this statement to invoke a function whose
  // FunctionDecl was compiled (and already added to this same persistent
  // JIT session) by an earlier, separate call. See codegen.h's "Recursion
  // and calls across separate compile calls" and this header's own
  // comment on knownFunctions_.
  cg.seedKnownFunctions(knownFunctions_);
  // Same carry-forward, for classes/instance methods - see this header's
  // own comment on knownClasses_/knownMethods_.
  cg.seedKnownClasses(knownClasses_);
  cg.seedKnownMethods(knownMethods_);
  // Same carry-forward, for cross-class method-name collision tracking -
  // see jit_engine.h's own comment on methodNameOwners_/ambiguousMethods_
  // and codegen.h's seedMethodNameOwnership() for the full mechanism.
  cg.seedMethodNameOwnership(methodNameOwners_, ambiguousMethods_);
  auto module = cg.compileStatements({stmt}, entryName);

  // Unlike newlyDefinedFunctions()/newlyDefinedClasses()/newlyDefinedMethods()
  // below, this carry-forward happens BEFORE the `!module` bailout, not
  // after: registerMethodNamesForCollisionCheck() (codegen.cpp) runs as the
  // very first thing in StmtKind::ClassDecl, unconditionally, specifically
  // so a class this slice goes on to REJECT (inheritance/abstract/
  // reversible/@rate - see codegen.h's own comment) still has its method
  // names seen. A rejected ClassDecl is exactly a case where `module` ends
  // up null (ok_ = false from that same rejection) - carrying this forward
  // only on success would mean it's never carried forward for the one case
  // that matters most (e.g. `class Dog(Animal): function s=speak(): ...`
  // being rejected is precisely when "speak" needs to be marked ambiguous
  // against a plain, natively-compiled Animal that also defines it).
  methodNameOwners_ = cg.methodNameOwnersAfterCompile();
  ambiguousMethods_ = cg.ambiguousMethodNamesAfterCompile();

  if (!module) {
    // A function/class this statement (re)defines that could not be
    // compiled - one with default values, say - is now only the
    // tree-walker's (registered above). Forget any earlier native version
    // of that name, or later compiled calls would keep running the old
    // code with the old inputs.
    if (stmt->kind == StmtKind::FunctionDecl) {
      knownFunctions_.erase(std::remove_if(knownFunctions_.begin(), knownFunctions_.end(),
                                           [&](const auto &f) {
                                             return std::get<0>(f) == stmt->name;
                                           }),
                            knownFunctions_.end());
    } else if (stmt->kind == StmtKind::ClassDecl) {
      knownClasses_.erase(std::remove_if(knownClasses_.begin(), knownClasses_.end(),
                                         [&](const auto &c) {
                                           return std::get<0>(c) == stmt->name;
                                         }),
                          knownClasses_.end());
      const std::string prefix = stmt->name + "__"; // CodeGen's method symbol names
      knownMethods_.erase(std::remove_if(knownMethods_.begin(), knownMethods_.end(),
                                         [&](const auto &m) {
                                           return std::get<1>(m).rfind(prefix, 0) == 0;
                                         }),
                          knownMethods_.end());
    }
    return false; // unsupported node - CodeGen already logged why
  }

  llvm::orc::ThreadSafeModule tsm(std::move(module),
                                   llvm::orc::ThreadSafeContext(std::move(llvmCtx)));
  if (auto err = jit_->addIRModule(std::move(tsm))) {
    llvm::consumeError(std::move(err));
    return false;
  }

  // Whatever FunctionDecl(s)/ClassDecl(s) this statement just defined are
  // now real, linked-in symbols in the JIT session - remember them so a
  // LATER runStmt() call's Call/MethodCall can resolve them too.
  for (const auto &fn : cg.newlyDefinedFunctions())
    knownFunctions_.push_back(fn);
  for (const auto &cls : cg.newlyDefinedClasses())
    knownClasses_.push_back(cls);
  for (const auto &m : cg.newlyDefinedMethods())
    knownMethods_.push_back(m);

  auto symOrErr = jit_->lookup(entryName);
  if (!symOrErr) {
    llvm::consumeError(symOrErr.takeError());
    return false;
  }

  auto fn = symOrErr->toPtr<void (*)(void *)>();
  fn(static_cast<void *>(&parser));
  return true;
}
