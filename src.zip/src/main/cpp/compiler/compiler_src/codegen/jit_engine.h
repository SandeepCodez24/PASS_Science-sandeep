#pragma once

// Step 4 of the LLVM codegen/JIT/AOT roadmap: a persistent, reusable JIT
// engine built on top of CodeGen (codegen.h) and the value_bridge ABI
// (runtime/interpreter/codegen_bridge/value_bridge.h).
//
// Step 3's own verification spun up a fresh LLJIT per test case - fine for
// a one-off parity check, not a real component. JitEngine is that real
// component: one LLJIT session lives for the engine's whole lifetime, and
// runStmt() can be called repeatedly against it, each call compiling one
// more statement into a freshly-named entry function added to the same
// running session.
//
// The property this exists to prove (see compiler/tests/parity_harness.cpp
// for the actual demonstration): a JIT'd statement run through this engine
// and a tree-walked statement run through Parser::executeStmt() can operate
// on the SAME live Parser instance - the same `memory` map / slot-indexed
// call frame - without diverging. runStmt()'s `parser` argument's address
// becomes the NCContext every variable read/write in the generated code
// threads through, so a JIT'd write is immediately visible to a subsequent
// tree-walked read on that same Parser, and vice versa.
//
// Scope boundary: this is the standalone engine only. It is deliberately
// NOT wired into main.cpp's live REPL loop - which statements should go
// through JIT vs. tree-walker is dispatch policy that hasn't been decided,
// and touching the live REPL is its own separate future task.
//
// User-defined functions (added alongside CodeGen's FunctionDecl/Call
// support): each runStmt() call compiles its one statement with a fresh
// CodeGen instance (see codegen.h's "Recursion and calls across separate
// compile calls"), so a FunctionDecl compiled in one call and invoked by a
// Call (or multi-target Assign) compiled in a later call need this engine
// to carry the function name/parameter-count/output-count registry
// forward itself - CodeGen only tracks it per-instance. knownFunctions_ is
// that registry: seeded into each new CodeGen before compiling, appended
// to from whatever that compile newly defined, for the engine's whole
// lifetime. Deliberately NOT std::vector<CodeGen::FunctionSignature> or
// similar here - that would pull codegen.h (and therefore real LLVM
// headers) into this otherwise-lightweight public header just for a
// three-field tuple, so a plain (name, paramCount, outputCount) tuple is
// used instead; jit_engine.cpp converts as needed.
//
// Classes: the exact same carry-forward problem, twice more - a ClassDecl
// compiled in one runStmt() call needs its constructor callable (and its
// instance method(s) callable) from a Call/MethodCall compiled in a later
// call. knownClasses_ (name, ctor paramCount) and knownMethods_ (method
// name, mangled llvm::Function name, paramCount) are seeded/appended
// exactly like knownFunctions_, same reasoning throughout.

#include <cstdint>
#include <memory>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace llvm {
namespace orc {
class LLJIT;
} // namespace orc
} // namespace llvm

struct Stmt;
class Parser;

class JitEngine {
public:
  JitEngine();
  ~JitEngine();

  JitEngine(const JitEngine &) = delete;
  JitEngine &operator=(const JitEngine &) = delete;

  // Compiles `stmt` (a single, borrowed AST node - see CodeGen::
  // compileStatements()'s comment for why this takes a raw pointer rather
  // than an owning Program) and JIT-executes it against `parser`: the
  // generated code's NCContext argument is &parser, so any variable read
  // it does resolves against parser's real `memory`/slot state, and any
  // write lands there too - the same state Parser::executeStmt() itself
  // would read/write. Returns false if CodeGen rejected the statement
  // (unsupported node - see codegen.h's own scope comment for the current
  // full coverage list) or if the JIT itself failed to add/resolve the
  // module; true if it ran.
  bool runStmt(const Stmt *stmt, Parser &parser);

private:
  std::unique_ptr<llvm::orc::LLJIT> jit_;
  std::uint64_t callCounter_ = 0; // entry-function name uniquer across this engine's lifetime
  std::vector<std::tuple<std::string, unsigned, unsigned>> knownFunctions_; // (name, paramCount, outputCount), across every runStmt() call so far
  std::vector<std::tuple<std::string, unsigned>> knownClasses_; // (className, ctorParamCount)
  std::vector<std::tuple<std::string, std::string, unsigned>> knownMethods_; // (methodName, mangledFnName, paramCount)
  // Cross-class method-name collision tracking, carried forward exactly
  // like knownClasses_/knownMethods_ above (Animal and Dog - see
  // codegen.h's own comment on this - can easily be declared in separate
  // top-level statements, each compiled by a separate CodeGen instance).
  // Both grow monotonically (an owner is only ever recorded once per name;
  // ambiguousMethods_ only ever gains entries), so replacing the whole map/
  // set with each compile's resulting state (rather than appending, the
  // knownX_ pattern) is safe and simpler - see runStmt()'s own comment.
  std::unordered_map<std::string, std::string> methodNameOwners_;
  std::unordered_set<std::string> ambiguousMethods_;
};
