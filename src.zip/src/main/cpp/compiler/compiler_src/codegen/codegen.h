#pragma once

// Step 3 of the LLVM codegen/JIT/AOT roadmap: an AST -> LLVM IR visitor.
//
// Mirrors Parser::evaluateExpr()/executeStmt()'s switch-over-ExprKind/
// StmtKind coverage pattern (compiler_src/parser/parser_factor.cpp,
// parser_exec_stmt.cpp) - same shape, different output: an llvm::Value*
// (always a `ptr` to a heap-allocated NC Value, never real IR arithmetic)
// instead of an actual NC Value. Per the decided "bridge everything"
// codegen strategy, this visitor does not reimplement any operator
// semantics - every AST node it covers becomes IR that `call`s one of the
// nc_bridge_* functions declared in runtime/interpreter/codegen_bridge/
// value_bridge.h.
//
// Deliberately NOT included here: value_bridge.h itself, or the NC Value
// struct (runtime/interpreter/core/value.h). This file only needs to know
// the bridge functions' *names* and LLVM-level signatures (every operand/
// result is an opaque `ptr` from IR's point of view) to declare and call
// them - it never touches a real Value. This also sidesteps a genuine name
// collision: NC's own `Value` struct and `llvm::Value` (IR values) would
// otherwise clash in the same translation unit. The tradeoff: the exact
// function names/argument counts below must be kept in sync with
// value_bridge.h by hand - there is no compiler-enforced link between the
// two. See codegen.cpp's top comment for the exact signature table this
// relies on.
//
// Scope (matches value_bridge.h's own "smallest correct slice" exactly -
// nothing here goes further than what the bridge already covers):
//   ExprKind:  NumberLiteral, StringLiteral, Identifier, ArrayLiteral,
//              MatrixLiteral (straightforward 2D only), Index (READ -
//              concrete keys only, no Wildcard/':' row-column slicing;
//              matrix 1-key row-select, matrix 2-key element, array 1-key
//              element, dict 1-key lookup - see the "Array/matrix/dict"
//              section below for why per-element read is in scope at
//              all), BinaryOp (7 ops), UnaryOp (2 ops), Comparison
//              (6 ops), LogicalOp (4 ops), AbsOrNorm, Call (ONLY against a
//              previously-compiled user function - see below; builtins
//              and class-constructor calls, both real possibilities for
//              ExprKind::Call per ast.h's own comment on it, are out of
//              scope and rejected cleanly).
//   StmtKind:  ExprStmt, Assign (Identifier target(s), OR a single Index
//              target with concrete keys - "A[i]=v"/"A[row][col]=v"/
//              "A[row,col]=v"/"A['key']=v", no Wildcard slicing, no
//              multi-target Index; multi-target "(A,B) = f(...)" also
//              covered, Identifier targets only), Publish (single
//              argument only), If (with elseif/else chains), While, For
//              (ONLY when the iterable is a RangeLiteral - "for i =
//              [a:b]"/"for i = [a:b:step]"; "for x in <collection>" is
//              still out of scope, rejected the same way any other
//              unsupported node is - see ast.h's own comment on
//              StmtKind::For for that distinction), Break, Continue,
//              Return, FunctionDecl (scalar parameters and return value(s)
//              only, matching everything else covered so far - any number
//              of declared outputs now, not just one - see below).
// ExprKind::FieldAccess (object receiver only - not the elementwise-dot-
// operator fallback evaluateExpr() also handles for a non-object
// receiver) and ExprKind::MethodCall (one instance method, no dict-
// builtin-method fallback) are now covered too - see the "Classes"
// section below.
// StmtKind::ClassDecl is covered for the single narrowest case: a plain,
// non-abstract, non-reversible, no-@rate, no-inheritance class with a
// `base` constructor and any number of other single-output instance
// methods (deliberately narrower than FunctionDecl's "any number of
// declared outputs" - see the "Classes" section for why).
// Explicitly out of scope: whole-collection builtins (transpose, det,
// ... - unrelated, separate future work), the dict-builtin-method
// fallback (A.keys()/A.values()/...), inheritance (parentClassName set),
// isAbstract/isReversible/hasRate/units, restrictedFields enforcement,
// the reserved .lineage()/.rewind()/.tick() calls, multi-output instance
// methods, wildcard row/column slicing, and any wiring into main.cpp's
// live REPL loop - all separate, later work (or, for several of the
// class ones, not work at all without touching more of the tree-walker's
// class machinery than this slice's scope allows - see "Classes" below).
//
// Control flow is real IR, not a bridge call: If/While/For become actual
// basic blocks and branches, and Break/Continue are `br` instructions to
// the enclosing loop's exit/continue blocks - notably simpler than the
// tree-walker's own loopSignal_/loopDepth_ signal-propagation mechanism
// for the same thing (see codegenStmtList()'s comment for the one bit of
// bookkeeping this does need: never emitting IR after a block's
// terminator). One exception crosses into the bridge regardless: deciding
// whether a condition Value is truthy, and deciding whether a range loop
// should keep iterating, both reuse existing tree-walker logic that isn't
// exposed as a reusable free function anywhere - see value_bridge.h's
// nc_bridge_truthy()/nc_bridge_range_should_continue() for why those two
// specifically needed new bridge entries.
//
// Multi-output functions/assignment ("(A,B) = f(...)"): investigated the
// same way, against Parser::callUserFunctionMulti() and
// executeAssignStmt()'s targets.size() >= 2 branch (parser_function.cpp,
// parser_exec_stmt.cpp). invokeFunctionBody() already extracts EVERY
// declared output into outScope regardless of how many there are -
// callUserFunction() (single-output) just happens to only ever read
// outputNames[0] back out of it; callUserFunctionMulti() reads all of
// them, and executeAssignStmt() varSet()s each target from the
// corresponding result, positionally, by index. Nothing there needed a
// new bridge function either: it's the same varGet/varSet(slot=-1, name)
// path multi-output extraction/binding already uses. Codegen's shape
// mirrors this exactly - a compiled FunctionDecl gets one trailing `ptr
// out` parameter per outputNames entry (not always exactly one), and a
// multi-target Assign (targets.size() > 1) is its own codegen path,
// parallel to plain Call - not routed through codegenExpr(), which can
// only ever hand back one llvm::Value* - that emits a call with multiple
// trailing out-pointers and nc_bridge_var_write()s each target from its
// corresponding one, index-for-index, exactly like executeAssignStmt()
// does. A function's declared outputCount is tracked alongside its
// paramCount in functionArity_/seedKnownFunctions()/
// newlyDefinedFunctions() (widened from arity-only) so both call shapes -
// single-value Call and multi-target Assign - can validate against it.
// One deliberate, documented divergence: the tree-walker's single-output
// callUserFunction() will silently call a MULTI-output function and just
// use its first declared output (no arity check there at all); this
// codegen path instead rejects that (ok_ = false) - the multi-output-
// called-as-single-value combination isn't exercised by anything this
// project actually needs, so matching that permissiveness wasn't worth a
// bespoke bridge/IR path for.
//
// User-defined functions: each compiled FunctionDecl becomes a real,
// standalone `llvm::Function` in the module - `void @name(ptr ctx, ptr
// param0, ..., ptr out0, ..., ptr out<m-1>)` - never inlined, called via a
// genuine `call` instruction from Call's/multi-target Assign's codegen.
// This is what makes recursion "just work": every call, however deeply
// nested, is a real native call with its own machine stack frame.
// Investigated directly against the source rather than assumed (see
// codegen.cpp's StmtKind::FunctionDecl comment for the findings):
// Parser::invokeFunctionBody() (parser_function.cpp) gives each
// call a fresh local scope purely by save/clear/restore of Parser's own
// `memory`/`insertionOrder` fields (plus other fields - slots_, loop
// state, `ans`/`base` bookkeeping - that codegen'd functions never touch,
// since Phase 6 slot resolution never runs on a codegen'd AST, so every
// variable access here is always the name-keyed `memory` path). Existing
// nc_bridge_var_read/var_write already operate on whatever `memory`
// currently is - confirmed by reading varGet/varSet/varExists directly,
// not assumed - so those needed no changes. What generated IR lacks is
// invokeFunctionBody()'s C++-call-stack-backed save/restore mechanism;
// value_bridge.h's new nc_bridge_push_scope()/nc_bridge_pop_scope() supply
// an equivalent (a bridge-side stack keyed by Parser*, since parser.h
// itself stays untouched). `Return` (StmtKind::Return) mirrors the tree-
// walker's own surprisingly simple mechanism once investigated: it carries
// no expression at all (ast.h's Stmt has none for it) - it's a bare "stop
// running this body now" signal, and the actual return value is whatever
// the declared output name holds afterward. Codegen's equivalent: Return
// is a `br` straight to the compiled function's epilogue block (which
// reads the output, pops the scope, and returns) - the same pattern
// Break/Continue already use for their loop targets, just one level up.
//
// Recursion and calls across separate compile calls: a compiled
// function's *definition* only lives in the Module it was compiled into,
// but ExprKind::Call only needs that function's *name and parameter
// count* to declare-and-call it (module_->getOrInsertFunction() with a
// matching signature) - LLVM/ORC resolves the actual call against
// whichever module defined that symbol, the same mechanism every
// nc_bridge_* declaration already relies on. seedKnownFunctions()/
// newlyDefinedFunctions() below exist so a caller (JitEngine) that
// compiles one statement per call can carry that name/arity registry
// forward across calls - required for a FunctionDecl compiled in one call
// to be callable from a Call compiled in a later, separate call.
//
// Array/matrix/dict: investigated three specific questions directly
// against the source before designing anything (see value_bridge.h's own
// "Array/matrix/dict/text helpers" section for the full findings) -
// ArrayLiteral/MatrixLiteral construction is unsurprising (evaluate each
// element/row once, collect); there is NO dict literal syntax, a dict
// only ever comes into existence via auto-vivifying index-assign; and
// CLAUDE.md's documented "no working per-element array/matrix read" gap
// turned out to be STALE against the current evaluateExpr() Index case -
// it works today, confirmed by reading the code, not assumed. Codegen's
// design follows directly from that: since the tree-walker's Index
// handling branches on the RECEIVER'S RUNTIME TYPE (isMatrix/isArray/
// isDict) - something codegen can never know at compile time, unlike
// every prior step's purely AST-shape-driven dispatch - that branching
// has to live in the bridge (nc_bridge_index_get/set), not as compile-
// time-chosen IR. A chained read like A[row][col] needs no special
// codegen case at all: it's Index(Index(A,[row]),[col]) in the AST
// (ast.h), and codegenExpr's own ordinary recursion evaluates the inner
// Index first (a matrix, 1-key call - returns a row, array-valued) then
// the outer one (that array, 1-key call - returns the element), exactly
// mirroring evaluateExpr()'s own recursive structure. Chained WRITE
// (A[row][col]=v) does need a special case, because the tree-walker's
// executeIndexAssign() has one too - see codegenStmt's StmtKind::Assign
// comment for why naive read-style decomposition would silently write
// into a copy instead of the real matrix. Wildcard (':') row/column
// slicing is out of scope for this slice - rejected at compile time
// wherever a Wildcard key appears, never reaching the bridge at all.
//
// Classes: investigated directly against parser_class.cpp (the real
// class-call machinery) before designing anything, four specific
// questions -
//   1. Construction disambiguation: evaluateExpr()'s ExprKind::Call case
//      (parser_factor.cpp) checks classTable_.count(name) BEFORE
//      functionTable_ before builtins - a class name always wins a
//      collision. Codegen mirrors this: a class-name registry is checked
//      first in Call's codegen, ahead of the existing function registry.
//   2. The constructor really is just a method named "base" (value.h's
//      comment confirmed) - registered and invoked through the exact same
//      invokeFunctionBody() machinery as any other method/function; the
//      only difference is a fresh `Value{isObject=true, className}` is
//      seeded into the callee's scope as `base` before the body runs
//      (via the same selfValue mechanism callInstanceMethod() also uses -
//      see point 4), and the whole mutated `base` (not a named output) is
//      what's read back out afterward.
//   3. Fields live in the SAME `dictMap` field a dict does (value.h's
//      comment confirmed) - but `isObject`/`isDict` are separate,
//      mutually-exclusive flags, so the existing nc_bridge_index_get/set
//      (which check isDict) do NOT apply to objects; new nc_bridge_
//      field_get/set were needed (value_bridge.h has the details). Field
//      access also differs structurally from Index: the field name
//      (Expr::text on a FieldAccess node) is always compile-time-known,
//      never a runtime-evaluated key - no key-array marshaling needed.
//   4. MethodCall/FieldAccess resolve which class via the RECEIVER'S
//      RUNTIME className (evaluateExpr()'s MethodCall case,
//      parser_factor.cpp) - unknowable at codegen time, same fundamental
//      issue Index's array-vs-matrix-vs-dict dispatch had. The receiver
//      (`this`) is passed into a method body exactly like a constructor's
//      fresh instance: seeded as `base` via the same var_write mechanism
//      params use, and the body's own field reads/writes
//      (FieldAccess on the Identifier "base") are ordinary FieldAccess
//      codegen, no special-casing needed inside a method body.
//
// Given (4), and given this slice's scope is deliberately "a single
// class, no inheritance" (multiple/ambiguous classes, dynamic dispatch,
// and vtables are all explicitly NOT being built here), MethodCall
// codegen uses one flat, global method-name registry rather than a real
// per-class method table: it is only correct when method names don't
// collide across DIFFERENT compiled classes, which the "single class"
// scope guarantees by construction. This is the one place this slice
// takes a real shortcut rather than a faithfully-narrowed mechanism -
// flagged here explicitly rather than left implicit, since a future step
// adding a second class or inheritance will need to replace this with
// real per-class resolution, not just widen it.
//
// A compiled class's constructor is a real `llvm::Function` with the
// EXACT SAME signature shape as a single-output FunctionDecl
// (userFunctionType(paramCount, 1) - conceptually "one output: the
// constructed instance"), reused as-is - no new function-type shape
// needed for it. An instance method needs one signature shape existing
// functions don't have, though: `void(ptr ctx, ptr self, ptr param0,
// ..., ptr selfOut, ptr methodOut)` - `self`/`selfOut` carry the receiver
// in and the (possibly field-mutated) receiver back out, mirroring
// evaluateExpr()'s MethodCall case writing `varSet(receiverNode->slot,
// name, selfAfter)` after every call regardless of whether anything
// actually changed - see instanceMethodType(). This slice requires
// exactly one declared output per instance method (narrower than
// FunctionDecl's "any number ≥1", matching the coordinator's own scoping
// example of "reads a field and returns a scalar") - void and multi-
// output instance methods are out of scope.
//
// Native-scalar performance path: every prior step's arithmetic/
// comparison codegen was correct but slow by design - a heap alloc
// (nc_bridge_value_create) and a full C-ABI bridge call (dimension checks
// and all) per operation, where a native `fadd`/`fcmp` in registers would
// do. That gap is the entire performance rationale for this whole LLVM
// effort, and until this task nothing had actually closed it. The
// correctness hazard: a BinaryOp/Comparison's operand is NOT guaranteed
// to be a plain number just because it flows through that node - it can
// be a matrix (add()/sub()/div_op() all branch on isMatrix - see
// arithmetic.cpp) or carry units (Value::dimL/dimT/dimM, value.h). Worth
// noting from reading add()/sub()/mul()/div_op() directly: NONE of them
// explicitly guard against isArray/isText/isDict/isObject either - only
// isMatrix gets special-cased, everything else falls through to reading
// `.number` directly (correct only for an actual plain number). So the
// guard here (nc_bridge_value_is_plain_number()) is deliberately the
// FULL conservative check - not merely "isn't a matrix" - to guarantee
// the fast path is taken only when it's byte-for-byte equivalent to
// today's bridge call, for every operand shape that can reach it, not
// just the matrix case that happens to be explicitly handled.
//
// NaN note: valueOrderCompare() (value_compare.cpp) has no "unordered"
// result - for a NaN operand it falls through to +1 - so logical_gt()/
// logical_gte() used to evaluate true for any NaN. All four ordering
// operators now check valuesUnordered() first and return false (IEEE-754).
// The fast path matches: every ordering comparison uses an ORDERED fcmp
// predicate (olt/ole/ogt/oge - false for NaN) - see
// codegenNativeComparison(). compiler/tests/parity_harness.cpp's NaN
// comparison case checks tree-walker and JIT agree.
//
// Design: evaluate both operands as today (still heap-allocated Value*s -
// unboxing across the WHOLE expression tree, or keeping a loop-carried
// scalar unboxed across iterations, is real SSA/phi architectural work
// explicitly out of scope for this slice), then branch at IR level on
// nc_bridge_value_is_plain_number() for both - true on both: extract
// native doubles (nc_bridge_get_number, already existed), compute via a
// real IR instruction/intrinsic, box the result back into a fresh Value
// via nc_bridge_value_set_number (already existed); false on either:
// call the exact same generic bridge function used before this task,
// unchanged. Both paths converge on one `out` Value* allocated before the
// branch - no PHI node needed, since it's the pointer itself (not what it
// points to) that's identical on both incoming edges. Applied to
// BinaryOp's 6 non-power operators (+,-,*,/,%,//) and all 6 Comparison
// operators; `^` (power) is deliberately excluded - its native lowering
// needs an intrinsic call anyway (no real `fadd`-style win over just
// calling the bridge) plus dimension-exponent multiplication logic to
// replicate correctly, so it wasn't a "falls out cheaply" case per the
// task's own scope note. LogicalOp/UnaryOp/AbsOrNorm are unchanged from
// before this task, same reasoning - see their own codegenExpr cases.
//
// A CodeGen instance is single-use: construct one, call compileProgram()
// once, and its Module ownership transfers to the caller. Not a persistent
// engine - matches how minimal this step's JIT setup is meant to be.

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"

#include <functional>
#include <memory>
#include <string>
#include <tuple>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

struct Expr;
struct Stmt;
struct Program;

class CodeGen {
public:
  CodeGen(llvm::LLVMContext &context, const std::string &moduleName);

  // Compiles every top-level statement in `prog.statements` into one
  // generated function named `entryName`, with signature `void(ptr ctx)`.
  // `ctx` is the NCContext (a live Parser*, opaque to generated IR) every
  // variable read/write call in the generated code threads through -
  // pure-operator calls (arithmetic/comparison/logical/abs) ignore it,
  // exactly matching value_bridge.h's documented convention. Returns the
  // built module (ownership transferred to the caller) - null if codegen
  // hit an unsupported node (see codegenExpr/codegenStmt). Thin wrapper
  // around compileStatements() below.
  std::unique_ptr<llvm::Module> compileProgram(const Program &prog,
                                                const std::string &entryName = "nc_entry");

  // Same as compileProgram(), but takes a list of borrowed Stmt pointers
  // instead of an owning Program. Added for Step 4 (JitEngine): a reusable
  // engine's runStmt(const Stmt*, Parser&) receives a single statement it
  // does not own (e.g. one node out of a Parser-owned tree that must
  // outlive the call) - there is no Program to hand compileProgram, and
  // building one would require moving a unique_ptr out of a tree the
  // caller still needs. codegenStmt() already only ever needed a raw
  // `const Stmt*` internally, so this is a genuine, additive gap in the
  // original Step 3 API, not a redesign - compileProgram() now just builds
  // this same pointer list from `prog.statements` and delegates.
  std::unique_ptr<llvm::Module> compileStatements(const std::vector<const Stmt *> &stmts,
                                                   const std::string &entryName = "nc_entry");

  // Pre-populates this instance's function-name registry with functions
  // compiled by a PREVIOUS, separate CodeGen instance - (name, parameter
  // count, declared output count), a plain tuple rather than a nested
  // CodeGen::-scoped struct so this header's public surface stays usable
  // without pulling codegen.h (and therefore real LLVM headers) into a
  // caller that only needs this signature (jit_engine.h avoids that on
  // purpose - see its own comment on knownFunctions_) - so a Call or
  // multi-target Assign in this compile can invoke them (see the class
  // comment's "Recursion and calls across separate compile calls"
  // section). Call before compileProgram()/compileStatements(). Not
  // needed for calls to a function defined in THIS SAME compile (those
  // resolve automatically - see StmtKind::FunctionDecl in codegen.cpp).
  void seedKnownFunctions(const std::vector<std::tuple<std::string, unsigned, unsigned>> &known);

  // Every function actually DEFINED (not just seeded) during the most
  // recent compileProgram()/compileStatements() call - a caller (JitEngine)
  // should append these to whatever it passes to future seedKnownFunctions()
  // calls, so later compiles can call functions defined here.
  const std::vector<std::tuple<std::string, unsigned, unsigned>> &newlyDefinedFunctions() const {
    return newlyDefinedFunctions_;
  }

  // Same cross-compile carry-forward mechanism as seedKnownFunctions(),
  // for classes: (className, constructor parameter count). Consulted by
  // ExprKind::Call ahead of the function registry, matching the tree-
  // walker's own class-wins-on-collision precedence (see the class
  // comment's "Classes" section, point 1).
  void seedKnownClasses(const std::vector<std::tuple<std::string, unsigned>> &known);
  const std::vector<std::tuple<std::string, unsigned>> &newlyDefinedClasses() const {
    return newlyDefinedClasses_;
  }

  // Same mechanism again, for instance methods: (method name, mangled
  // llvm::Function name, parameter count). Flat/global by method name
  // only, not per-class - see the class comment's explicit note on why
  // that's only correct given this slice's "single class" scope.
  void seedKnownMethods(const std::vector<std::tuple<std::string, std::string, unsigned>> &known);
  const std::vector<std::tuple<std::string, std::string, unsigned>> &newlyDefinedMethods() const {
    return newlyDefinedMethods_;
  }

  // Cross-class method-name collision tracking - a real correctness gap
  // found via direct testing, distinct from (and more severe than) the
  // "single class" shortcut instanceMethods_ itself already documents:
  // instanceMethods_ is flat/global BY METHOD NAME ONLY, with no per-class
  // ownership at all, so if a class using inheritance (parentClassName set
  // - always rejected for native compilation, see StmtKind::ClassDecl) and
  // a plain, natively-compiled class both declare a same-named, same-arity
  // method (e.g. both `Animal` and `class Dog(Animal)` define `speak()`),
  // the REJECTED class's method never touches instanceMethods_ at all -
  // only the accepted one's does - so instanceMethods_ ends up with
  // exactly one, seemingly-unambiguous entry for "speak" even though two
  // DIFFERENT classes define it. A later `d.speak()` on an actual `Dog`
  // instance then silently calls Animal's compiled implementation instead
  // of Dog's override, with no error, no fallback, no per-class check at
  // all (confirmed by direct repro - `d.speak()` returned Animal's value,
  // not Dog's, even though `d`'s runtime className was correctly "Dog").
  // The fix: scan EVERY ClassDecl's method names (regardless of whether
  // that class ends up natively compiled or rejected/falls back to the
  // tree-walker - see the call site in StmtKind::ClassDecl) and track which
  // class first claimed each name; a name claimed by more than one class
  // becomes permanently "ambiguous" and MethodCall codegen refuses
  // (ok_ = false, falls back to the tree-walker for that whole statement)
  // to natively dispatch it ever again, rather than risk the wrong
  // class's implementation running. Both maps are monotonically-growing
  // (never shrink) and carried forward across JitEngine::runStmt() calls
  // exactly like knownClasses_/knownMethods_ above, since Animal and Dog
  // can easily be declared in separate top-level statements compiled by
  // separate CodeGen instances.
  void seedMethodNameOwnership(const std::unordered_map<std::string, std::string> &owners,
                                const std::unordered_set<std::string> &ambiguousNames);
  const std::unordered_map<std::string, std::string> &methodNameOwnersAfterCompile() const {
    return methodNameOwners_;
  }
  const std::unordered_set<std::string> &ambiguousMethodNamesAfterCompile() const {
    return ambiguousMethodNames_;
  }

private:
  llvm::LLVMContext &context_;
  std::unique_ptr<llvm::Module> module_;
  llvm::IRBuilder<> builder_;
  llvm::Argument *ctxArg_ = nullptr; // the `ptr %ctx` argument of the entry function being built
  bool ok_ = true; // set false the first time an out-of-scope node is hit

  // The enclosing loop(s)' targets for Break/Continue, innermost last.
  // While pushes {condBB, exitBB}; For pushes {incrBB, exitBB} (continue
  // must still run the increment before re-checking the condition, same
  // as a C-style for-loop). codegenStmt's Break/Continue cases just `br`
  // to .back()'s target and set ok_=false if the stack is empty (mirrors
  // the tree-walker's own "used outside a loop" rejection).
  struct LoopTargets {
    llvm::BasicBlock *continueTarget;
    llvm::BasicBlock *breakTarget;
  };
  std::vector<LoopTargets> loopStack_;

  // The compiled function whose body is currently being built (its
  // epilogue block - reads the output, pops the scope, `ret void`) is what
  // Return branches to. The outermost per-call entry function
  // (compileStatements) sets this too, before processing top-level
  // statements, so a top-level `return;` (valid in the tree-walker -
  // Parser::consumeTopLevelStopSignal()'s whole reason for existing) works
  // the same way rather than needing special-casing. NC forbids nested
  // FunctionDecl, so one field suffices - no stack needed.
  llvm::BasicBlock *currentFunctionEpilogue_ = nullptr;

  // True while compiling a user FunctionDecl/constructor/instance method
  // body (false for the outermost per-call entry itself). Gates whether
  // Return/a failed Require/Ensure also signals Parser::loopSignal_ (see
  // StmtKind::Return/Require/Ensure below and nc_bridge_signal_top_level_
  // return's comment) - that signal only means anything at the genuine
  // top level (consumeTopLevelStopSignal(), checked by main.cpp's REPL loop
  // and ScriptManager::executeFile()'s JIT-aware Pass 2); inside a user
  // function/method body, LLVM's own call/return mechanism already unwinds
  // correctly via the branch-to-this-body's-own-epilogue that Return/
  // Require/Ensure already emit regardless of this flag, so setting
  // loopSignal_ there too would do nothing useful and - worse - would leak
  // past the call with no code to reset it (invokeFunctionBody()'s tree-
  // walker equivalent explicitly saves/resets/restores loopSignal_ around
  // every call for exactly this reason; a JIT-compiled function call has no
  // such save/restore since it never touches loopSignal_ at all otherwise).
  bool inUserFunctionBody_ = false;

  // name -> (parameter count, declared output count), for every function
  // callable from IR built by this instance - either seeded (defined by a
  // previous, separate CodeGen instance) or defined here
  // (StmtKind::FunctionDecl). Consulted by ExprKind::Call and multi-target
  // Assign to validate the callee exists and its arg/output count
  // matches, and to reconstruct the matching declareFn() signature at the
  // call site (see the class comment's "Recursion and calls across
  // separate compile calls" section for why only name+counts is needed,
  // never the original llvm::Function*/Module).
  struct FunctionSignature {
    unsigned paramCount;
    unsigned outputCount;
  };
  std::unordered_map<std::string, FunctionSignature> functionArity_;
  // Subset of the above actually DEFINED during this instance's compile
  // (not just seeded) - what newlyDefinedFunctions() returns.
  std::vector<std::tuple<std::string, unsigned, unsigned>> newlyDefinedFunctions_;

  // className -> constructor parameter count. Checked BEFORE
  // functionArity_ in Call's codegen - see the class comment's "Classes"
  // section, point 1.
  std::unordered_map<std::string, unsigned> classCtorArity_;
  std::vector<std::tuple<std::string, unsigned>> newlyDefinedClasses_;

  // method name -> (mangled llvm::Function name, parameter count). Flat/
  // global, not per-class - see the class comment's explicit note on the
  // shortcut this represents and why it's only valid given this slice's
  // "single class" scope.
  struct MethodSignature {
    std::string mangledName;
    unsigned paramCount;
  };
  std::unordered_map<std::string, MethodSignature> instanceMethods_;
  std::vector<std::tuple<std::string, std::string, unsigned>> newlyDefinedMethods_;

  // See seedMethodNameOwnership()'s comment above - name -> the first
  // class that declared it; a name landing in ambiguousMethodNames_ means
  // two or more DIFFERENT classes declared it, so MethodCall codegen must
  // never natively dispatch it.
  std::unordered_map<std::string, std::string> methodNameOwners_;
  std::unordered_set<std::string> ambiguousMethodNames_;
  // Scans every method name in `classDecl` (skipping "base", the
  // constructor - never registered in instanceMethods_/dispatched via
  // MethodCall in the first place, so it can't suffer this collision) and
  // updates methodNameOwners_/ambiguousMethodNames_ accordingly. Called
  // unconditionally at the top of StmtKind::ClassDecl, BEFORE the
  // inheritance/abstract/reversible/@rate rejection check - a rejected
  // class's method names must still be scanned, since they're exactly the
  // ones that would otherwise go undetected (see the class comment above).
  void registerMethodNamesForCollisionCheck(const Stmt *classDecl);

  llvm::PointerType *ptrTy();
  llvm::FunctionCallee declareFn(const std::string &name, llvm::Type *retTy,
                                  llvm::ArrayRef<llvm::Type *> argTys);

  // One declareFn() wrapper per bridge call shape (see codegen.cpp for the
  // full name table). `binaryBridge`/`unaryBridge` are parameterized by
  // bridge function name since ~15 different bridge functions share the
  // same (ptr,ptr,ptr)->i32 / (ptr,ptr)->i32 shape.
  llvm::FunctionCallee valueCreateFn();
  llvm::FunctionCallee valueDestroyFn();
  llvm::FunctionCallee valueSetNumberFn();
  llvm::FunctionCallee valueSetImaginaryFn();
  llvm::FunctionCallee binaryBridgeFn(const std::string &bridgeName);
  llvm::FunctionCallee unaryBridgeFn(const std::string &bridgeName);
  // nc_bridge_binary_op_checked/nc_bridge_comparison_checked: (ptr ctx, ptr
  // opText, ptr a, ptr b, ptr out) -> i32. Used instead of binaryBridgeFn()
  // for every BinaryOp/Comparison slow-path call (both inside
  // codegenScalarFastPath()'s slow branch and the always-bridge "^" case) -
  // see their own value_bridge.h comment for why: unlike the plain
  // nc_bridge_add()-style calls binaryBridgeFn() declares, these actually
  // surface a dimension/type-check failure into Parser::evaluationSucceeded_
  // (with the exact same error message the tree-walker would print) rather
  // than letting codegen silently discard that status the way it used to.
  llvm::FunctionCallee checkedBinaryOpFn();
  llvm::FunctionCallee checkedComparisonFn();
  llvm::FunctionCallee varReadFn();
  llvm::FunctionCallee varWriteFn();
  llvm::FunctionCallee readDeclaredOutputFn(); // nc_bridge_read_declared_output: (ptr, ptr, ptr, i32, ptr) -> i32
  llvm::FunctionCallee publishFn();
  llvm::FunctionCallee printValueFn();            // nc_bridge_print_value: (ptr, ptr) -> void
  llvm::FunctionCallee truthyFn();               // nc_bridge_truthy: (ptr) -> i32
  llvm::FunctionCallee getNumberFn();             // nc_bridge_get_number: (ptr) -> double
  llvm::FunctionCallee rangeShouldContinueFn();   // nc_bridge_range_should_continue: (double,double,double,i32) -> i32
  llvm::FunctionCallee pushScopeFn();             // nc_bridge_push_scope: (ptr) -> i32
  llvm::FunctionCallee popScopeFn();              // nc_bridge_pop_scope: (ptr) -> i32
  llvm::FunctionCallee pushDefiningClassFn();     // nc_bridge_push_defining_class: (ptr, ptr) -> void
  llvm::FunctionCallee popDefiningClassFn();      // nc_bridge_pop_defining_class: (ptr) -> void
  llvm::FunctionCallee valueSetTextFn();          // nc_bridge_value_set_text: (ptr, ptr) -> void
  llvm::FunctionCallee arrayFromElementsFn();     // nc_bridge_array_from_elements: (ptr, i32, ptr) -> void
  llvm::FunctionCallee matrixFromRowsFn();        // nc_bridge_matrix_from_rows: (ptr, i32, ptr) -> void
  llvm::FunctionCallee indexGetFn();              // nc_bridge_index_get: (ptr, ptr, i32, ptr) -> i32
  llvm::FunctionCallee indexSetFn();              // nc_bridge_index_set: (ptr, ptr, i32, ptr, i32, ptr) -> i32
  llvm::FunctionCallee valueSetObjectFn();        // nc_bridge_value_set_object: (ptr, ptr) -> void
  llvm::FunctionCallee fieldGetFn();              // nc_bridge_field_get: (ptr, ptr, ptr, i32, ptr) -> i32
  llvm::FunctionCallee fieldSetFn();              // nc_bridge_field_set: (ptr, ptr, i32, ptr, ptr) -> i32
  llvm::FunctionCallee isPlainNumberFn();          // nc_bridge_value_is_plain_number: (ptr) -> i32
  llvm::FunctionCallee callDynamicFn();            // nc_bridge_call_dynamic: (ptr, ptr, ptr, i32, ptr) -> i32
  llvm::FunctionCallee reportConditionFailureFn(); // nc_bridge_report_condition_failure: (ptr, i32, ptr) -> void
  llvm::FunctionCallee reportWhileLimitFn();       // nc_bridge_report_while_limit: (ptr) -> void
  llvm::FunctionCallee clearMemoryFn();            // nc_bridge_clear_memory: (ptr) -> void
  llvm::FunctionCallee saveToFileFn();             // nc_bridge_save_to_file: (ptr) -> void
  llvm::FunctionCallee resetEvaluationSucceededFn(); // nc_bridge_reset_evaluation_succeeded: (ptr) -> void
  llvm::FunctionCallee getEvaluationSucceededFn();   // nc_bridge_get_evaluation_succeeded: (ptr) -> i32
  llvm::FunctionCallee signalTopLevelReturnFn();   // nc_bridge_signal_top_level_return: (ptr) -> void
  llvm::FunctionCallee reportIndexSetFailureFn();  // nc_bridge_report_index_set_failure: (ptr, ptr) -> void

  // Returns the native (llvm::Value* doubles in, llvm::Value* double out)
  // computer for BinaryOp operator `op`, or an empty std::function if none
  // exists (only "^"/"." - see the class comment's "Native-scalar
  // performance path" section for why). Doesn't touch dimension fields -
  // the fast path only ever runs when both operands are confirmed
  // unitless, so the result is always unitless too, matching a freshly
  // nc_bridge_value_create()'d Value's own zero-initialized dims.
  std::function<llvm::Value *(llvm::Value *, llvm::Value *)> codegenNativeBinaryOp(const std::string &op);

  // Same idea for Comparison - ordering operators use ORDERED fcmp
  // predicates so any NaN operand gives false (see the NaN note in the
  // class comment above). Always returns a real
  // function (all 6 Comparison operators are fast-pathable).
  std::function<llvm::Value *(llvm::Value *, llvm::Value *)> codegenNativeComparison(const std::string &op);

  // The shared fast/slow branch-and-merge structure BinaryOp and
  // Comparison both use: guards `lhs`/`rhs` via nc_bridge_value_is_plain_
  // number(), computes via `nativeCompute` on the fast path or calls the
  // checked bridge (checkedBinaryOpFn()/checkedComparisonFn(), selected by
  // `isComparison`, passing `opText` as the NC operator's own text, e.g.
  // "+"/"<" - NOT a bridge function name, unlike the old slowBridgeName
  // parameter this replaced) on the slow path, and returns one `out` Value*
  // valid on both incoming edges - no PHI needed (see the class comment).
  // Does NOT destroy `lhs`/`rhs` - same convention as codegenExpr's other
  // cases, the caller does that once after this returns.
  llvm::Value *codegenScalarFastPath(llvm::Value *lhs, llvm::Value *rhs, const std::string &opText,
                                      bool isComparison,
                                      const std::function<llvm::Value *(llvm::Value *, llvm::Value *)> &nativeCompute);

  // The LLVM signature every compiled NC function (and every call site
  // invoking one) shares: `void(ptr ctx, ptr param0, ..., ptr param<n-1>,
  // ptr out0, ..., ptr out<m-1>)`. Used both by StmtKind::FunctionDecl (to
  // create the real llvm::Function) and by ExprKind::Call/multi-target
  // Assign (to declareFn() a matching reference to it, possibly defined in
  // a different module - see the class comment). A class constructor also
  // uses this exact shape with outputCount=1 - see the class comment's
  // "Classes" section.
  llvm::FunctionType *userFunctionType(unsigned paramCount, unsigned outputCount);

  // The LLVM signature every compiled instance method (and every
  // MethodCall site invoking one) shares: `void(ptr ctx, ptr self, ptr
  // param0, ..., ptr param<n-1>, ptr selfOut, ptr methodOut)` - see the
  // class comment's "Classes" section for why self needs both an in and
  // an out slot.
  llvm::FunctionType *instanceMethodType(unsigned paramCount);

  llvm::Value *newValueSlot();                    // call nc_bridge_value_create()
  void destroyValueSlot(llvm::Value *slot);        // call nc_bridge_value_destroy(slot)
  llvm::Value *nameOrNullPtr(int slot, const std::string &name); // GlobalString(name) if slot==-1, else null ptr

  // Spills `ptrs` into a fresh stack buffer (`alloca [N x ptr]`, each
  // element stored in turn) and returns the buffer, usable directly as a
  // `const Value *const *`-shaped call argument - the marshaling every
  // variable-length bridge call here needs (array/matrix construction,
  // Index's key list), since a single LLVM call instruction can't take a
  // dynamically-sized argument list itself.
  llvm::Value *buildPointerArray(const std::vector<llvm::Value *> &ptrs);

  // Evaluates each element Expr in `elems`, in order, and calls
  // nc_bridge_array_from_elements() to build an array-valued Value from
  // them - shared by ExprKind::ArrayLiteral's own codegen and by
  // MatrixLiteral's per-row construction (each row is itself built this
  // same way - see codegen.cpp's StmtKind::... no, ExprKind::MatrixLiteral
  // comment for why that's a different construction path than
  // evaluateExpr() takes but an identical result). Destroys each element
  // temporary after the bridge call copies it in. Returns the new array
  // Value* (caller-owned, like every other codegenExpr result).
  llvm::Value *codegenArrayFromExprs(const std::vector<std::unique_ptr<Expr>> &elems);

  // Emits a generic dynamic-dispatch call for `node` (an ExprKind::Call
  // whose name is neither a known-natively-compiled class constructor nor
  // a known-natively-compiled user-defined function - see codegenExpr's
  // ExprKind::Call case): evaluates every argument, in order, builds the
  // `Value**` argv nc_bridge_call_dynamic() expects (via buildPointerArray(),
  // same marshaling every other variable-length bridge call here uses), and
  // emits the call (passing ctxArg_ - unlike the old builtin-only version,
  // this one needs Parser access for the class/function tiers). Returns the
  // call's `out` Value* (caller-owned, like every other codegenExpr result -
  // the caller destroys it once consumed). Whether `name` was actually
  // recognized (by any of the three tiers - see value_bridge.h) can only be
  // known once this call actually runs (no static name table exists at
  // codegen time for tiers 1/2 the way classCtorArity_/functionArity_ do for
  // the natively-compiled fast path) - callers that need to know pass a
  // non-null `outFoundFlag`, which receives an `i1` (true = found) ready for
  // CreateCondBr; callers that don't care (this is most callers - see
  // codegen.h's class-comment precedent of not checking other bridge calls'
  // error codes either) pass nullptr.
  llvm::Value *codegenBuiltinCall(const Expr *node, llvm::Value **outFoundFlag);

  // Same shape as codegenBuiltinCall() above, for ExprKind::FieldAccess -
  // see its own comment for why this needs a found-flag now too.
  llvm::Value *codegenFieldAccess(const Expr *node, llvm::Value **outFoundFlag);

  // Compiles `ctorStmt` (the "base"-named method Stmt inside `classDecl`)
  // into a real llvm::Function - structurally the same save/push_scope/
  // bind/body/epilogue/pop_scope/restore shape as StmtKind::FunctionDecl's
  // own inline handling, with one difference: `base` (a fresh isObject
  // Value for this class) is seeded into the scope before parameters are
  // bound, and it - not a named output - is what's read back out at the
  // end. Kept as its own function rather than sharing FunctionDecl's
  // inline code via a generalized helper - the two are similar but not
  // identical, and this slice would rather risk a little duplication than
  // a risky refactor of the already-working function-call path.
  void compileClassConstructor(const Stmt *classDecl, const Stmt *ctorStmt);

  // Compiles `methodStmt` (one non-"base" method Stmt inside `classDecl`)
  // into a real llvm::Function using instanceMethodType()'s signature -
  // same shape as compileClassConstructor(), except the receiver comes in
  // as a parameter (seeded as `base`) rather than being freshly
  // constructed, and exactly one declared output is required (see the
  // class comment). Registers the result in instanceMethods_/
  // newlyDefinedMethods_.
  void compileInstanceMethod(const Stmt *classDecl, const Stmt *methodStmt);

  // MATLAB-style auto-echo: mirrors printValue(name, v) (runtime/
  // interpreter/core/output.cpp), called by every executeAssignStmt()/
  // executeStmt() branch when `!stmt->suppressOutput` (no trailing ';').
  // A REAL gap this closes - see value_bridge.h's nc_bridge_print_value
  // comment for how this went undetected until real corpus scripts (not
  // just the parity harness, which suppresses output almost everywhere)
  // exposed it. `name` empty mirrors a bare ExprStmt's printValue("", v).
  // Does not destroy `valueSlot` - caller still owns it exactly as before
  // this call existed.
  void emitAutoEcho(bool suppressOutput, const std::string &name, llvm::Value *valueSlot);

  // Emits a call to nc_bridge_truthy() on `condExprNode`'s codegen'd
  // result, destroys the temporary, and returns an `i1` ready for
  // CreateCondBr - the one piece of logic If/While/For's condition
  // handling all share.
  llvm::Value *codegenTruthyCondition(const Expr *condExprNode);

  // Emits IR for one Expr; returns a `ptr` to a freshly nc_bridge_value_
  // create()'d Value holding the node's result. The caller is responsible
  // for destroying it once consumed (every call site here does so
  // immediately after use - see codegen.cpp).
  llvm::Value *codegenExpr(const Expr *node);
  void codegenStmt(const Stmt *stmt);

  // Walks a statement list (an If branch body, a loop body, ...) emitting
  // each one in turn. The one bit of bookkeeping plain codegenStmt() calls
  // in a loop wouldn't get right: once a statement terminates the current
  // basic block early (Break/Continue - both end in a `br`), IR forbids
  // adding more instructions to that same block, so anything textually
  // after it in the same body (unreachable, but still needs to go
  // somewhere) gets a fresh block to land in instead.
  void codegenStmtList(const std::vector<std::unique_ptr<Stmt>> &stmts);

  // If the current insertion block has no terminator yet, adds `br
  // fallthrough`. Used at the end of If branch bodies (-> merge block) and
  // loop bodies (-> condition/increment block) - covers both the normal
  // "body ran off the end" case and the "body ended in a dead block after
  // a break/continue" case identically, since both just need some
  // terminator to keep the IR well-formed.
  void ensureTerminator(llvm::BasicBlock *fallthrough);
};
