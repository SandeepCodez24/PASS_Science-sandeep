#include "codegen.h"

#include "../ast/ast.h"
#include "../../../runtime/interpreter/core/function_files.h"

#include "llvm/IR/Function.h"
#include "llvm/IR/Intrinsics.h"
#include "llvm/IR/Verifier.h"
#include "llvm/Support/raw_ostream.h"

using llvm::ArrayRef;
using llvm::BasicBlock;
using llvm::ConstantFP;
using llvm::ConstantPointerNull;
using llvm::Function;
using llvm::FunctionCallee;
using llvm::FunctionType;
using llvm::PointerType;
using llvm::Type;

// Bridge function name table this file relies on - must stay in sync with
// runtime/interpreter/codegen_bridge/value_bridge.h by hand (see codegen.h's
// top comment for why this isn't compiler-checked). Every entry below is
// `(ptr, ptr, ptr) -> i32` for binary ops, `(ptr, ptr) -> i32` for unary,
// `() -> ptr` / `(ptr) -> void` / `(ptr, double) -> void` for the value
// lifetime helpers, `(ptr, ptr, i32, ptr) -> i32` for var read/write,
// `(ptr) -> i32` for publish, `(ptr) -> i32` for truthy, `(ptr) -> double`
// for get_number, `(double, double, double, i32) -> i32` for
// range_should_continue, and `(ptr) -> i32` for both push_scope and
// pop_scope (see truthyFn()/getNumberFn()/rangeShouldContinueFn()/
// pushScopeFn()/popScopeFn() below). Every compiled user function itself
// (StmtKind::FunctionDecl) and every Call/multi-target Assign invoking one
// shares one more shape, not a bridge function but built the same
// declare-by-signature way - see userFunctionType(): `(ptr ctx, ptr
// param0, ..., ptr out0, ..., ptr out<m-1>) -> void`. `(ptr, ptr) -> void`
// for value_set_object, `(ptr, ptr, ptr) -> i32` for field_get, `(ptr,
// ptr, i32, ptr, ptr) -> i32` for field_set (see valueSetObjectFn()/
// fieldGetFn()/fieldSetFn() below); a compiled instance method shares yet
// another declare-by-signature shape - see instanceMethodType().

namespace {

// Call shapes only the tree-walker implements, so a statement holding one
// is never compiled - it falls back to executeStmt(), the same way every
// other unsupported node does:
//   * named values in a call - F(x1=10, 15), obj.m(k=2), parent(h=1, w).
//     Native calls pass values strictly by position; compiling one of
//     these would silently hand the values to the wrong inputs.
//   * ClassName.base / obj.info ... - the reserved introspection after a
//     dot (Parser::tryClassIntrospection), which reads class tables the
//     compiled code has no view of.
// Defaults need no check here: a FunctionDecl/ClassDecl with defaults is
// never compiled (see their cases), so a call to it is never a native
// call - it goes through nc_bridge_call_dynamic -> callUserFunction() /
// callClassConstructor(), which fill the defaults in.
bool exprNeedsTreeWalker(const Expr *e) {
  if (!e)
    return false;
  if (e->hasNamedArgs())
    return true;
  if ((e->kind == ExprKind::FieldAccess || e->kind == ExprKind::MethodCall) &&
      (e->text == "base" || e->text == "info"))
    return true;
  // A big literal ([2.0, 1.99-0.001i, ...] with thousands of values, as test
  // scripts and generated code write them): every element becomes its own
  // bridge calls in the IR, and LLVM then needs minutes (a 10 000-value
  // literal: over 2 min vs 0.5 s in the tree-walker). The tree-walker builds
  // it in one go.
  if (e->kind == ExprKind::MatrixLiteral || e->kind == ExprKind::ArrayLiteral) {
    size_t count = 0;
    for (const auto &c : e->children)
      count += (e->kind == ExprKind::MatrixLiteral && c) ? c->children.size() : 1;
    if (count > 1024)
      return true;
  }
  // school.f(x) / school.f on a module file (M1, parser_function_files.cpp):
  // only the tree-walker knows modules - compiled code would read `school`
  // as a variable.
  if ((e->kind == ExprKind::FieldAccess || e->kind == ExprKind::MethodCall) && !e->children.empty() &&
      e->children[0] && e->children[0]->kind == ExprKind::Identifier &&
      nc::fnfiles::find(e->children[0]->text))
    return true;
  // @(x) body (Parser::makeAnonymousFunction() registers and captures), and
  // f(x)[i] - an index on a call's result (2026-10).
  if (e->kind == ExprKind::AnonymousFunction)
    return true;
  if (e->kind == ExprKind::Index && !e->children.empty() && e->children[0] &&
      e->children[0]->kind != ExprKind::Identifier && e->children[0]->kind != ExprKind::Index)
    return true;
  for (const auto &c : e->children)
    if (exprNeedsTreeWalker(c.get()))
      return true;
  return exprNeedsTreeWalker(e->rangeStart.get()) || exprNeedsTreeWalker(e->rangeStop.get()) ||
         exprNeedsTreeWalker(e->rangeStep.get());
}

// The statement's own expressions (not its nested bodies - each nested
// statement comes through codegenStmt() itself).
bool stmtNeedsTreeWalker(const Stmt *s) {
  // `return value;` sets the function's output (executeStmt()) - the
  // compiled Return case does not. (A require/ensure message used to be
  // sent here too; nc_bridge_report_condition_failure prints it now.)
  if (s->kind == StmtKind::Return && s->value)
    return true;
  // M ,= X / M ;= X - executeExtendAssign() only.
  if (s->kind == StmtKind::Assign && s->extendDir != 0)
    return true;
  if (exprNeedsTreeWalker(s->expr.get()) || exprNeedsTreeWalker(s->value.get()) ||
      exprNeedsTreeWalker(s->condition.get()) || exprNeedsTreeWalker(s->iterable.get()))
    return true;
  for (const auto &t : s->targets)
    if (exprNeedsTreeWalker(t.get()))
      return true;
  for (const auto &branch : s->elseifBranches)
    if (exprNeedsTreeWalker(branch.first.get()))
      return true;
  for (const auto &p : s->publishArgs)
    if (exprNeedsTreeWalker(p.get()))
      return true;
  return false;
}

const char *binaryOpBridgeName(const std::string &op) {
  if (op == "+") return "nc_bridge_add";
  if (op == "-") return "nc_bridge_sub";
  if (op == "*") return "nc_bridge_mul";
  if (op == "/") return "nc_bridge_div";
  if (op == "%") return "nc_bridge_mod";
  if (op == "//") return "nc_bridge_floordiv";
  if (op == "^") return "nc_bridge_pow";
  // Element-wise matrix operators: no native fast path - always the checked
  // bridge (nc_bridge_binary_op_checked), which runs the tree-walker's own
  // evaluateBinaryOpValues(). The name here only marks them as supported.
  if (op == "*." || op == "/." || op == "^.") return "nc_bridge_binary_op_checked";
  return nullptr;
}

const char *comparisonBridgeName(const std::string &op) {
  if (op == "==") return "nc_bridge_eq";
  if (op == "!=") return "nc_bridge_neq";
  if (op == "<") return "nc_bridge_lt";
  if (op == ">") return "nc_bridge_gt";
  if (op == "<=") return "nc_bridge_lte";
  if (op == ">=") return "nc_bridge_gte";
  return nullptr; // is_in/is_not_in - out of scope
}

const char *logicalOpBridgeName(const std::string &op) {
  // AST text is always the word form ("nand"/"nor"), even though the
  // lexed surface syntax is symbolic ("!&"/"!|") - see
  // parser_expression.cpp's makeBinary() calls and ast.h's LogicalOp
  // comment. Match on the AST's text field, not source spelling.
  if (op == "&&") return "nc_bridge_logical_and";
  if (op == "||") return "nc_bridge_logical_or";
  if (op == "nand") return "nc_bridge_logical_nand";
  if (op == "nor") return "nc_bridge_logical_nor";
  return nullptr;
}

} // namespace

CodeGen::CodeGen(llvm::LLVMContext &context, const std::string &moduleName)
    : context_(context), module_(std::make_unique<llvm::Module>(moduleName, context)),
      builder_(context) {}

PointerType *CodeGen::ptrTy() { return PointerType::get(context_, 0); }

FunctionCallee CodeGen::declareFn(const std::string &name, Type *retTy,
                                   ArrayRef<Type *> argTys) {
  FunctionType *fty = FunctionType::get(retTy, argTys, /*isVarArg=*/false);
  return module_->getOrInsertFunction(name, fty);
}

FunctionCallee CodeGen::valueCreateFn() {
  return declareFn("nc_bridge_value_create", ptrTy(), {});
}

FunctionCallee CodeGen::valueDestroyFn() {
  return declareFn("nc_bridge_value_destroy", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::valueSetNumberFn() {
  return declareFn("nc_bridge_value_set_number", Type::getVoidTy(context_),
                    {ptrTy(), Type::getDoubleTy(context_)});
}

FunctionCallee CodeGen::valueSetImaginaryFn() {
  return declareFn("nc_bridge_value_set_imaginary", Type::getVoidTy(context_),
                    {ptrTy(), Type::getDoubleTy(context_)});
}

FunctionCallee CodeGen::binaryBridgeFn(const std::string &bridgeName) {
  return declareFn(bridgeName, Type::getInt32Ty(context_), {ptrTy(), ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::checkedBinaryOpFn() {
  return declareFn("nc_bridge_binary_op_checked", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), ptrTy(), ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::checkedComparisonFn() {
  return declareFn("nc_bridge_comparison_checked", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), ptrTy(), ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::unaryBridgeFn(const std::string &bridgeName) {
  return declareFn(bridgeName, Type::getInt32Ty(context_), {ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::varReadFn() {
  return declareFn("nc_bridge_var_read", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::varWriteFn() {
  return declareFn("nc_bridge_var_write", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::readDeclaredOutputFn() {
  return declareFn("nc_bridge_read_declared_output", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::publishFn() {
  return declareFn("nc_bridge_publish", Type::getInt32Ty(context_), {ptrTy()});
}

FunctionCallee CodeGen::printValueFn() {
  return declareFn("nc_bridge_print_value", Type::getVoidTy(context_), {ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::truthyFn() {
  return declareFn("nc_bridge_truthy", Type::getInt32Ty(context_), {ptrTy()});
}

FunctionCallee CodeGen::getNumberFn() {
  return declareFn("nc_bridge_get_number", Type::getDoubleTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::rangeShouldContinueFn() {
  Type *dbl = Type::getDoubleTy(context_);
  return declareFn("nc_bridge_range_should_continue", Type::getInt32Ty(context_),
                    {dbl, dbl, dbl, Type::getInt32Ty(context_)});
}

FunctionCallee CodeGen::pushScopeFn() {
  return declareFn("nc_bridge_push_scope", Type::getInt32Ty(context_), {ptrTy()});
}

FunctionCallee CodeGen::popScopeFn() {
  return declareFn("nc_bridge_pop_scope", Type::getInt32Ty(context_), {ptrTy()});
}

FunctionCallee CodeGen::pushDefiningClassFn() {
  return declareFn("nc_bridge_push_defining_class", Type::getVoidTy(context_), {ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::popDefiningClassFn() {
  return declareFn("nc_bridge_pop_defining_class", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::valueSetTextFn() {
  return declareFn("nc_bridge_value_set_text", Type::getVoidTy(context_), {ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::arrayFromElementsFn() {
  return declareFn("nc_bridge_array_from_elements", Type::getVoidTy(context_),
                    {ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

// Matrix literal with MATLAB-style concatenation and shape checks:
// nc_bridge_matrix_build_checked(ctx, rows, count, out) -> i32.
FunctionCallee CodeGen::matrixFromRowsFn() {
  return declareFn("nc_bridge_matrix_build_checked", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

// nc_bridge_index_get_checked(ctx, name, receiver, keys, keyCount, out) -> i32:
// reports its own error and marks the statement failed.
FunctionCallee CodeGen::indexGetFn() {
  return declareFn("nc_bridge_index_get_checked", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::indexSetFn() {
  return declareFn("nc_bridge_index_set", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy(),
                     Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::valueSetObjectFn() {
  return declareFn("nc_bridge_value_set_object", Type::getVoidTy(context_), {ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::fieldGetFn() {
  return declareFn("nc_bridge_field_get", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::fieldSetFn() {
  return declareFn("nc_bridge_field_set", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::isPlainNumberFn() {
  return declareFn("nc_bridge_value_is_plain_number", Type::getInt32Ty(context_), {ptrTy()});
}

FunctionCallee CodeGen::callDynamicFn() {
  return declareFn("nc_bridge_call_dynamic", Type::getInt32Ty(context_),
                    {ptrTy(), ptrTy(), ptrTy(), Type::getInt32Ty(context_), ptrTy()});
}

FunctionCallee CodeGen::reportConditionFailureFn() {
  return declareFn("nc_bridge_report_condition_failure", Type::getVoidTy(context_),
                    {ptrTy(), Type::getInt32Ty(context_), ptrTy(), ptrTy(), Type::getInt32Ty(context_)});
}

FunctionCallee CodeGen::reportWhileLimitFn() {
  return declareFn("nc_bridge_report_while_limit", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::clearMemoryFn() {
  return declareFn("nc_bridge_clear_memory", Type::getVoidTy(context_), {ptrTy()});
}

// No longer called: variables.txt is gone, and the workspace is persisted
// only on request (save_workspace()) plus the DataEngine autosave between
// commands. Kept because codegen.h still declares it.
FunctionCallee CodeGen::saveToFileFn() {
  return declareFn("nc_bridge_save_to_file", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::resetEvaluationSucceededFn() {
  return declareFn("nc_bridge_reset_evaluation_succeeded", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::getEvaluationSucceededFn() {
  return declareFn("nc_bridge_get_evaluation_succeeded", Type::getInt32Ty(context_), {ptrTy()});
}

FunctionCallee CodeGen::signalTopLevelReturnFn() {
  return declareFn("nc_bridge_signal_top_level_return", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::reportIndexSetFailureFn() {
  return declareFn("nc_bridge_report_index_set_failure", Type::getVoidTy(context_), {ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::analysisStatementFn() {
  return declareFn("nc_bridge_analysis_statement", Type::getVoidTy(context_), {});
}

FunctionCallee CodeGen::analysisScalarOpFn() {
  return declareFn("nc_bridge_analysis_scalar_op", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::analysisLoopBeginFn() {
  return declareFn("nc_bridge_analysis_loop_begin", Type::getInt32Ty(context_),
                   {Type::getInt32Ty(context_), Type::getInt32Ty(context_), Type::getInt64Ty(context_)});
}

FunctionCallee CodeGen::analysisLoopIterationFn() {
  return declareFn("nc_bridge_analysis_loop_iteration", Type::getVoidTy(context_), {});
}

FunctionCallee CodeGen::analysisLoopEndFn() {
  return declareFn("nc_bridge_analysis_loop_end", Type::getVoidTy(context_), {Type::getInt32Ty(context_)});
}

FunctionCallee CodeGen::analysisLoopDepthFn() {
  return declareFn("nc_bridge_analysis_loop_depth", Type::getInt32Ty(context_), {});
}

FunctionCallee CodeGen::rangeIterationCountFn() {
  Type *d = Type::getDoubleTy(context_);
  return declareFn("nc_bridge_range_iteration_count", Type::getInt64Ty(context_),
                   {d, d, d, Type::getInt32Ty(context_)});
}

FunctionCallee CodeGen::absOrNormCheckedFn() {
  return declareFn("nc_bridge_abs_or_norm_checked", Type::getInt32Ty(context_), {ptrTy(), ptrTy(), ptrTy()});
}

FunctionCallee CodeGen::reportZeroRangeStepFn() {
  return declareFn("nc_bridge_report_zero_range_step", Type::getVoidTy(context_), {ptrTy()});
}

FunctionCallee CodeGen::rangeValueFn() {
  Type *d = Type::getDoubleTy(context_);
  return declareFn("nc_bridge_range_value", d, {d, d, d, Type::getInt32Ty(context_), Type::getInt64Ty(context_)});
}

FunctionCallee CodeGen::reportEndlessRangeFn() {
  return declareFn("nc_bridge_report_endless_range", Type::getVoidTy(context_), {ptrTy()});
}

llvm::Value *CodeGen::emitAnalysisFrameEnter() {
  return builder_.CreateCall(analysisLoopDepthFn(), {}, "loop.depth");
}

void CodeGen::emitAnalysisFrameExit(llvm::Value *depthOnEntry) {
  builder_.CreateCall(analysisLoopEndFn(), {depthOnEntry});
}

FunctionType *CodeGen::userFunctionType(unsigned paramCount, unsigned outputCount) {
  std::vector<Type *> paramTys;
  paramTys.push_back(ptrTy()); // ctx
  for (unsigned i = 0; i < paramCount; ++i)
    paramTys.push_back(ptrTy());
  for (unsigned i = 0; i < outputCount; ++i)
    paramTys.push_back(ptrTy()); // out0..out<m-1>
  return FunctionType::get(Type::getVoidTy(context_), paramTys, false);
}

FunctionType *CodeGen::instanceMethodType(unsigned paramCount) {
  std::vector<Type *> paramTys;
  paramTys.push_back(ptrTy()); // ctx
  paramTys.push_back(ptrTy()); // self (in)
  for (unsigned i = 0; i < paramCount; ++i)
    paramTys.push_back(ptrTy());
  paramTys.push_back(ptrTy()); // selfOut
  paramTys.push_back(ptrTy()); // methodOut
  return FunctionType::get(Type::getVoidTy(context_), paramTys, false);
}

llvm::Value *CodeGen::newValueSlot() {
  return builder_.CreateCall(valueCreateFn(), {}, "vslot");
}

void CodeGen::destroyValueSlot(llvm::Value *slot) {
  builder_.CreateCall(valueDestroyFn(), {slot});
}

llvm::Value *CodeGen::nameOrNullPtr(int slot, const std::string &name) {
  // Mirrors value_bridge.h's documented nc_bridge_var_read/write
  // convention exactly: slot >= 0 means the name argument is unused
  // downstream (varGet/varExists dispatch on slot alone in that case), so
  // NULL is passed rather than a wasted global string constant.
  if (slot >= 0)
    return ConstantPointerNull::get(ptrTy());
  // CreateGlobalString() (not ...Ptr - removed in this LLVM version) returns
  // a GlobalVariable*, which under opaque pointers already IS a `ptr` value
  // usable directly as a call argument - no separate "take its address" step.
  return builder_.CreateGlobalString(name);
}

llvm::Value *CodeGen::buildPointerArray(const std::vector<llvm::Value *> &ptrs) {
  llvm::ArrayType *arrTy = llvm::ArrayType::get(ptrTy(), ptrs.size());
  llvm::Value *buf = builder_.CreateAlloca(arrTy, nullptr, "ptrbuf");
  for (std::size_t i = 0; i < ptrs.size(); ++i) {
    llvm::Value *slot = builder_.CreateConstGEP2_32(arrTy, buf, 0, static_cast<unsigned>(i));
    builder_.CreateStore(ptrs[i], slot);
  }
  // `buf` (a `ptr` to `[N x ptr]`) is already usable directly as a `ptr`
  // call argument under opaque pointers - no bitcast/decay step needed.
  return buf;
}

llvm::Value *CodeGen::codegenFieldAccess(const Expr *node, llvm::Value **outFoundFlag) {
  // Object field read AND the elementwise-dot-operator fallback for a
  // non-object receiver (`A.B` meaning element-wise matrix multiply when A
  // isn't an object) - both handled inside nc_bridge_field_get() now,
  // since which one applies depends on the receiver's runtime type, not
  // knowable at compile time (same principle as Index). `node->slot` is
  // passed through for the fallback's readVariableOrConstant() call
  // (mirrors nc_bridge_var_read's slot usage) - meaningless for the
  // object-field-read case, which ignores it. Extracted into its own
  // helper (same shape as codegenBuiltinCall) once nc_bridge_field_get()
  // started actually rejecting private/protected reads (checkFieldAccess())
  // - a caller that needs to know now can, via `outFoundFlag`; a bare
  // expression-context read (outFoundFlag == nullptr) still just returns
  // whatever's in `out` either way, same "unchecked bridge status"
  // precedent as before this task everywhere else.
  llvm::Value *receiver = codegenExpr(node->children[0].get());
  llvm::Value *namePtr = builder_.CreateGlobalString(node->text);
  llvm::Value *out = newValueSlot();
  llvm::Value *statusI32 = builder_.CreateCall(
      fieldGetFn(), {ctxArg_, receiver, namePtr, builder_.getInt32(node->slot), out});
  destroyValueSlot(receiver);

  if (outFoundFlag)
    *outFoundFlag = builder_.CreateICmpEQ(statusI32, builder_.getInt32(0), "field.found");

  return out;
}

llvm::Value *CodeGen::codegenBuiltinCall(const Expr *node, llvm::Value **outFoundFlag) {
  std::vector<llvm::Value *> argSlots;
  argSlots.reserve(node->children.size());
  for (const auto &argExpr : node->children)
    argSlots.push_back(codegenExpr(argExpr.get()));

  llvm::Value *namePtr = builder_.CreateGlobalString(node->text);
  llvm::Value *argvBuf = buildPointerArray(argSlots);
  llvm::Value *out = newValueSlot();
  llvm::Value *statusI32 = builder_.CreateCall(
      callDynamicFn(),
      {ctxArg_, namePtr, argvBuf, builder_.getInt32(static_cast<int>(argSlots.size())), out});

  for (llvm::Value *a : argSlots)
    destroyValueSlot(a);

  if (outFoundFlag)
    // nc_bridge_call_dynamic() returns 0 on success (name recognized by any
    // of its three tiers) - same "0 = success" convention as every other
    // int-returning bridge function.
    *outFoundFlag = builder_.CreateICmpEQ(statusI32, builder_.getInt32(0), "dyncall.found");

  return out;
}

llvm::Value *CodeGen::codegenArrayFromExprs(const std::vector<std::unique_ptr<Expr>> &elems) {
  std::vector<llvm::Value *> elemSlots;
  elemSlots.reserve(elems.size());
  for (const auto &e : elems)
    elemSlots.push_back(codegenExpr(e.get()));

  llvm::Value *buf = buildPointerArray(elemSlots);
  llvm::Value *out = newValueSlot();
  builder_.CreateCall(arrayFromElementsFn(), {buf, builder_.getInt32(static_cast<int>(elemSlots.size())), out});

  for (llvm::Value *e : elemSlots)
    destroyValueSlot(e);
  return out;
}

void CodeGen::emitAutoEcho(bool suppressOutput, const std::string &name, llvm::Value *valueSlot) {
  if (suppressOutput)
    return;
  llvm::Value *namePtr = builder_.CreateGlobalString(name);
  builder_.CreateCall(printValueFn(), {namePtr, valueSlot});
}

llvm::Value *CodeGen::codegenTruthyCondition(const Expr *condExprNode) {
  llvm::Value *condV = codegenExpr(condExprNode);
  llvm::Value *truthyI32 = builder_.CreateCall(truthyFn(), {condV});
  destroyValueSlot(condV);
  return builder_.CreateICmpNE(truthyI32, builder_.getInt32(0), "truthy");
}

std::function<llvm::Value *(llvm::Value *, llvm::Value *)> CodeGen::codegenNativeBinaryOp(const std::string &op) {
  if (op == "+")
    return [this](llvm::Value *l, llvm::Value *r) { return builder_.CreateFAdd(l, r); };
  if (op == "-")
    return [this](llvm::Value *l, llvm::Value *r) { return builder_.CreateFSub(l, r); };
  if (op == "*")
    return [this](llvm::Value *l, llvm::Value *r) { return builder_.CreateFMul(l, r); };
  if (op == "/")
    return [this](llvm::Value *l, llvm::Value *r) { return builder_.CreateFDiv(l, r); };
  if (op == "%")
    // llvm's `frem` is specified as equivalent to the C library fmod() -
    // matches mod_op()'s std::fmod(a.number, b.number) exactly.
    return [this](llvm::Value *l, llvm::Value *r) { return builder_.CreateFRem(l, r); };
  if (op == "//")
    // Matches floor_div() (arithmetic.cpp) exactly: truncated division,
    // std::trunc(v.number / r.number) + 0.0 - plain division (never guarded
    // against r==0, IEEE-754 already gives the right signed-Infinity/NaN),
    // rounded toward zero, and a -0 result turned into 0.
    return [this](llvm::Value *l, llvm::Value *r) {
      llvm::Value *d = builder_.CreateFDiv(l, r);
      llvm::Value *t = builder_.CreateUnaryIntrinsic(llvm::Intrinsic::trunc, d);
      return builder_.CreateFAdd(t, ConstantFP::get(Type::getDoubleTy(context_), 0.0));
    };
  // "^" (power) and "." (elementwise matrix - never reaches here, "." isn't
  // even a valid BinaryOp fast-path candidate since matrix operands always
  // fail the plain-number guard anyway) - no native computer; caller falls
  // back to the bridge unconditionally. See codegen.h for why "^" isn't
  // worth fast-pathing.
  return nullptr;
}

std::function<llvm::Value *(llvm::Value *, llvm::Value *)> CodeGen::codegenNativeComparison(const std::string &op) {
  llvm::CmpInst::Predicate pred;
  if (op == "==")
    pred = llvm::CmpInst::FCMP_OEQ;
  else if (op == "!=")
    // UNORDERED-or-not-equal: matches logical_neq()'s valuesDeepEqual()-
    // based definition, which is true for ANY NaN operand (NaN is never
    // deep-equal to anything, including itself).
    pred = llvm::CmpInst::FCMP_UNE;
  else if (op == "<")
    pred = llvm::CmpInst::FCMP_OLT;
  else if (op == ">")
    // ORDERED: false for any NaN operand (IEEE-754), matching logical_gt()
    // which checks valuesUnordered() before valueOrderCompare().
    pred = llvm::CmpInst::FCMP_OGT;
  else if (op == "<=")
    pred = llvm::CmpInst::FCMP_OLE;
  else if (op == ">=")
    pred = llvm::CmpInst::FCMP_OGE;
  else
    return nullptr; // is_in/is_not_in - never reach here as Comparison text

  return [this, pred](llvm::Value *l, llvm::Value *r) {
    llvm::Value *cmp = builder_.CreateFCmp(pred, l, r);
    return builder_.CreateSelect(cmp, ConstantFP::get(Type::getDoubleTy(context_), 1.0),
                                  ConstantFP::get(Type::getDoubleTy(context_), 0.0));
  };
}

llvm::Value *CodeGen::codegenScalarFastPath(
    llvm::Value *lhs, llvm::Value *rhs, const std::string &opText, bool isComparison,
    const std::function<llvm::Value *(llvm::Value *, llvm::Value *)> &nativeCompute) {
  llvm::Value *out = newValueSlot();

  llvm::Value *lhsPlainI32 = builder_.CreateCall(isPlainNumberFn(), {lhs});
  llvm::Value *rhsPlainI32 = builder_.CreateCall(isPlainNumberFn(), {rhs});
  llvm::Value *lhsPlain = builder_.CreateICmpNE(lhsPlainI32, builder_.getInt32(0));
  llvm::Value *rhsPlain = builder_.CreateICmpNE(rhsPlainI32, builder_.getInt32(0));
  llvm::Value *bothPlain = builder_.CreateAnd(lhsPlain, rhsPlain, "both_plain");

  Function *fn = builder_.GetInsertBlock()->getParent();
  BasicBlock *fastBB = BasicBlock::Create(context_, "scalar_fast", fn);
  BasicBlock *slowBB = BasicBlock::Create(context_, "scalar_slow", fn);
  BasicBlock *mergeBB = BasicBlock::Create(context_, "scalar_merge", fn);
  builder_.CreateCondBr(bothPlain, fastBB, slowBB);

  builder_.SetInsertPoint(fastBB);
  // The Analysis box: the computation evaluateBinaryOpValues() would count
  // for this operator (comparisons count nothing there, so nothing here).
  if (!isComparison)
    builder_.CreateCall(analysisScalarOpFn(), {builder_.CreateGlobalString(opText)});
  llvm::Value *lhsNum = builder_.CreateCall(getNumberFn(), {lhs});
  llvm::Value *rhsNum = builder_.CreateCall(getNumberFn(), {rhs});
  llvm::Value *resultNum = nativeCompute(lhsNum, rhsNum);
  if (isComparison) {
    // A comparison yields a bool Value (true/false), exactly like
    // Parser::evaluateComparisonValues() - not the float64 1/0.
    llvm::Value *asI32 = builder_.CreateFPToSI(resultNum, Type::getInt32Ty(context_));
    builder_.CreateCall(declareFn("nc_bridge_value_set_bool", Type::getVoidTy(context_),
                                  {ptrTy(), Type::getInt32Ty(context_)}),
                        {out, asI32});
  } else {
    builder_.CreateCall(valueSetNumberFn(), {out, resultNum});
  }
  builder_.CreateBr(mergeBB);

  // Both operands are only guaranteed plain (unitless, non-text, non-
  // matrix/array/dict/object) here BY CONSTRUCTION of the fast branch above
  // - the "both_plain" check just failed, so at least one operand carries
  // units, is text, or is a compound value. That means the fast path itself
  // can never hit a dimension/type-check failure (both dims are trivially
  // 0), but this slow branch absolutely can (e.g. `5*m + 3*kg`, `"a"+"b"`,
  // `"abc" < 5`) - it calls the checked bridge (not the old, un-checked
  // per-operator one) specifically so that failure is actually surfaced
  // into Parser::evaluationSucceeded_ with the tree-walker's own error
  // message, instead of silently producing whatever nc_bridge_value_
  // create()'s zero-initialized `out` happens to be - see value_bridge.h's
  // nc_bridge_binary_op_checked/nc_bridge_comparison_checked comment for
  // the full history of the bug this closes.
  builder_.SetInsertPoint(slowBB);
  llvm::Value *opPtr = builder_.CreateGlobalString(opText);
  FunctionCallee checkedFn = isComparison ? checkedComparisonFn() : checkedBinaryOpFn();
  builder_.CreateCall(checkedFn, {ctxArg_, opPtr, lhs, rhs, out});
  builder_.CreateBr(mergeBB);

  builder_.SetInsertPoint(mergeBB);
  return out;
}

void CodeGen::ensureTerminator(BasicBlock *fallthrough) {
  // hasTerminator(), not getTerminator() - getTerminator() asserts if the
  // block doesn't have one yet (including a still-empty block), which is
  // exactly the case being checked for here.
  if (!builder_.GetInsertBlock()->hasTerminator())
    builder_.CreateBr(fallthrough);
}

void CodeGen::codegenStmtList(const std::vector<std::unique_ptr<Stmt>> &stmts) {
  for (const auto &stmt : stmts) {
    codegenStmt(stmt.get());
    if (builder_.GetInsertBlock()->hasTerminator()) {
      // `stmt` already closed this block (Break/Continue). Anything after
      // it in this list is unreachable, but IR still forbids inserting
      // into an already-terminated block - give it a fresh one to land in.
      // Whatever real control-flow this body is part of (an If merge
      // point, a loop's condition/increment block) is wired up by the
      // caller once codegenStmtList() returns, via ensureTerminator() -
      // this dead block just needs to not corrupt the terminated one.
      Function *fn = builder_.GetInsertBlock()->getParent();
      BasicBlock *dead = BasicBlock::Create(context_, "dead", fn);
      builder_.SetInsertPoint(dead);
    }
  }
}

llvm::Value *CodeGen::codegenExpr(const Expr *node) {
  // A null node means the parser already reported a syntax error for this
  // sub-expression (e.g. `b = 5*+6;`) but kept the statement in the tree.
  // Mirror Parser::evaluateExpr()'s null handling (yield 0) instead of
  // dereferencing null, so a syntax error can never crash the JIT path.
  if (!node) {
    llvm::Value *slot = newValueSlot();
    builder_.CreateCall(valueSetNumberFn(),
                         {slot, ConstantFP::get(Type::getDoubleTy(context_), 0.0)});
    return slot;
  }
  switch (node->kind) {
  case ExprKind::NumberLiteral: {
    llvm::Value *slot = newValueSlot();
    // `true` / `false` - a real bool Value, same as evaluateExpr().
    if (node->isBool) {
      builder_.CreateCall(declareFn("nc_bridge_value_set_bool", Type::getVoidTy(context_),
                                    {ptrTy(), Type::getInt32Ty(context_)}),
                          {slot, llvm::ConstantInt::get(Type::getInt32Ty(context_),
                                                  node->number != 0.0 ? 1 : 0)});
      return slot;
    }
    // An imaginary literal (`3i`) - see Expr::imaginary.
    builder_.CreateCall(node->imaginary ? valueSetImaginaryFn() : valueSetNumberFn(),
                         {slot, ConstantFP::get(Type::getDoubleTy(context_), node->number)});
    return slot;
  }

  case ExprKind::StringLiteral: {
    llvm::Value *slot = newValueSlot();
    llvm::Value *textPtr = builder_.CreateGlobalString(node->text);
    builder_.CreateCall(valueSetTextFn(), {slot, textPtr});
    return slot;
  }

  case ExprKind::ArrayLiteral:
    return codegenArrayFromExprs(node->children);

  case ExprKind::MatrixLiteral: {
    // An N-D literal (';;' or more between rows) is left to the tree-walker
    // (evaluateExpr()'s MatrixLiteral case builds it with matBuildND()).
    for (int level : node->sepLevels) {
      if (level >= 2) {
        ok_ = false;
        return newValueSlot();
      }
    }
    // Mirrors evaluateExpr()'s ExprKind::MatrixLiteral case: each row
    // (itself an ArrayLiteral Expr, per ast.h) built from ITS OWN
    // children directly - not by recursing through codegenExpr() on the
    // row Expr, which would go through the generic ArrayLiteral case
    // above and land at the same place anyway, but this matches the
    // tree-walker's own structure more directly (it never calls
    // evaluateExpr() on a row node either, just walks rowNode->children).
    std::vector<llvm::Value *> rowSlots;
    rowSlots.reserve(node->children.size());
    for (const auto &rowNode : node->children)
      rowSlots.push_back(codegenArrayFromExprs(rowNode->children));

    llvm::Value *buf = buildPointerArray(rowSlots);
    llvm::Value *out = newValueSlot();
    builder_.CreateCall(matrixFromRowsFn(),
                         {ctxArg_, buf, builder_.getInt32(static_cast<int>(rowSlots.size())), out});

    for (llvm::Value *r : rowSlots)
      destroyValueSlot(r);
    return out;
  }

  case ExprKind::Index: {
    // Ordinary recursion: if the receiver is itself an Index node (a
    // chained A[row][col] read), this call evaluates it first - exactly
    // mirroring evaluateExpr()'s own `Value v = evaluateExpr(receiverNode);`
    // first step. See codegen.h's "Array/matrix/dict" section for why
    // that alone is enough to make chained reads work with no special
    // case here.
    llvm::Value *receiver = codegenExpr(node->children[0].get());

    // A Wildcard (':') key has no codegenExpr() case (it's only meaningful
    // here, never a value-producing expression on its own) - marshaled as a
    // null pointer in that key slot instead of evaluating it. nc_bridge_
    // index_get() recognizes a null key as a Wildcard - see its own comment
    // for the row/column-slice/whole-container shapes this enables.
    std::vector<llvm::Value *> keySlots;
    keySlots.reserve(node->children.size() - 1);
    for (std::size_t i = 1; i < node->children.size(); ++i) {
      if (node->children[i]->kind == ExprKind::Wildcard)
        keySlots.push_back(ConstantPointerNull::get(ptrTy()));
      else
        keySlots.push_back(codegenExpr(node->children[i].get()));
    }

    llvm::Value *keysBuf = buildPointerArray(keySlots);
    llvm::Value *out = newValueSlot();
    // Return status intentionally unchecked - matches this project's
    // established convention for bridge error codes elsewhere (e.g.
    // BinaryOp's dimension-guard rc) of not building branching IR around
    // them at this scope.
    const Expr *receiverNode = node->children[0].get();
    llvm::Value *receiverName = builder_.CreateGlobalString(
        receiverNode->kind == ExprKind::Identifier ? receiverNode->text : std::string());
    builder_.CreateCall(indexGetFn(), {ctxArg_, receiverName, receiver, keysBuf,
                                       builder_.getInt32(static_cast<int>(keySlots.size())), out});

    destroyValueSlot(receiver);
    for (llvm::Value *k : keySlots)
      destroyValueSlot(k);
    return out;
  }

  case ExprKind::Identifier: {
    llvm::Value *slot = newValueSlot();
    llvm::Value *namePtr = nameOrNullPtr(node->slot, node->text);
    llvm::Value *slotIdx = builder_.getInt32(node->slot);
    builder_.CreateCall(varReadFn(), {ctxArg_, namePtr, slotIdx, slot});
    return slot;
  }

  case ExprKind::UnaryOp: {
    // Three possible texts (ast.h's own comment on UnaryOp only lists two -
    // stale, see the postfix "!" fix below): "!" (logical not), "!post"
    // (postfix factorial, e.g. `5!`), else "-" (negation). Matching against
    // "!" alone and treating everything else as "-" used to silently
    // miscompute "!post" as negation instead of factorial - see
    // nc_bridge_factorial's comment.
    llvm::Value *inner = codegenExpr(node->children[0].get());
    llvm::Value *out = newValueSlot();
    if (node->text == "'") {
      // Postfix transpose A' - same matTransposeValue() the tree-walker uses.
      builder_.CreateCall(declareFn("nc_bridge_transpose_checked", Type::getInt32Ty(context_),
                                    {ptrTy(), ptrTy(), ptrTy()}),
                          {ctxArg_, inner, out});
      destroyValueSlot(inner);
      return out;
    }
    if (node->text != "!" && node->text != "!post") {
      // "-": the checked form, which fails the statement when an integer
      // has no negation in its type (-int8(-128)), as the tree-walker does.
      builder_.CreateCall(declareFn("nc_bridge_neg_checked", Type::getInt32Ty(context_),
                                    {ptrTy(), ptrTy(), ptrTy()}),
                          {ctxArg_, inner, out});
      destroyValueSlot(inner);
      return out;
    }
    // The checked forms (nc_bridge_neg_checked's pattern): a refused operand
    // ("5"!, an N-D matrix) fails the statement instead of storing 0.
    const char *bridgeName = (node->text == "!") ? "nc_bridge_not_checked" : "nc_bridge_factorial_checked";
    builder_.CreateCall(declareFn(bridgeName, Type::getInt32Ty(context_), {ptrTy(), ptrTy(), ptrTy()}),
                        {ctxArg_, inner, out});
    destroyValueSlot(inner);
    return out;
  }

  case ExprKind::AbsOrNorm: {
    llvm::Value *inner = codegenExpr(node->children[0].get());
    llvm::Value *out = newValueSlot();
    // The checked form: a failure (or Stop inside its kernel) fails the
    // statement, so no result is stored - as in the tree-walker.
    builder_.CreateCall(absOrNormCheckedFn(), {ctxArg_, inner, out});
    destroyValueSlot(inner);
    return out;
  }

  case ExprKind::BinaryOp:
  case ExprKind::Comparison: {
    // Native-scalar performance path: if a native (llvm::Value*, llvm::
    // Value*) -> llvm::Value* computer exists for this operator, take the
    // fast/slow split (codegenScalarFastPath() - both operands guarded at
    // runtime, since a BinaryOp/Comparison's operand kind is never known
    // at compile time); otherwise ("^" and "." for BinaryOp - see
    // codegenNativeBinaryOp()'s own comment) always call the bridge, byte-
    // for-byte the same as before this task.
    const char *bridgeName = (node->kind == ExprKind::BinaryOp) ? binaryOpBridgeName(node->text)
                                                                 : comparisonBridgeName(node->text);
    llvm::Value *lhs = codegenExpr(node->children[0].get());
    llvm::Value *rhs = codegenExpr(node->children[1].get());

    if (!bridgeName) {
      // Out of scope for this slice (e.g. "." elementwise, is_in/is_not_in).
      ok_ = false;
      llvm::Value *out = newValueSlot();
      destroyValueSlot(lhs);
      destroyValueSlot(rhs);
      return out;
    }

    std::function<llvm::Value *(llvm::Value *, llvm::Value *)> nativeCompute =
        (node->kind == ExprKind::BinaryOp) ? codegenNativeBinaryOp(node->text)
                                            : codegenNativeComparison(node->text);

    bool isComparison = (node->kind == ExprKind::Comparison);
    llvm::Value *out;
    if (nativeCompute) {
      out = codegenScalarFastPath(lhs, rhs, node->text, isComparison, nativeCompute);
    } else {
      // "^" (power) - deliberately always the bridge call, never fast-
      // pathed; see codegenNativeBinaryOp()'s comment for why. Uses the
      // checked bridge too (not the old, un-checked binaryBridgeFn(name)) -
      // `2^"a"` needs the same text-arithmetic rejection every other
      // operator here gets, and previously silently didn't.
      out = newValueSlot();
      llvm::Value *opPtr = builder_.CreateGlobalString(node->text);
      FunctionCallee checkedFn = isComparison ? checkedComparisonFn() : checkedBinaryOpFn();
      builder_.CreateCall(checkedFn, {ctxArg_, opPtr, lhs, rhs, out});
    }
    destroyValueSlot(lhs);
    destroyValueSlot(rhs);
    return out;
  }

  case ExprKind::LogicalOp: {
    // Not fast-pathed this slice - see codegen.h's "Native-scalar
    // performance path" section for why (LogicalOp's operands are
    // truthiness-tested, not guaranteed-numeric, so the same simple
    // "extract .number, compute natively" pattern doesn't apply as
    // directly; explicitly allowed to skip per the task's own scope).
    // Unchanged from before this task.
    const char *bridgeName = logicalOpBridgeName(node->text);
    llvm::Value *lhs = codegenExpr(node->children[0].get());
    llvm::Value *rhs = codegenExpr(node->children[1].get());
    llvm::Value *out = newValueSlot();
    if (!bridgeName) {
      ok_ = false;
    } else {
      builder_.CreateCall(binaryBridgeFn(bridgeName), {lhs, rhs, out});
    }
    destroyValueSlot(lhs);
    destroyValueSlot(rhs);
    return out;
  }

  case ExprKind::Call: {
    // A call whose name is also a local of this function may be P(x) on a
    // poly1d held in that local (parser_factor.cpp) - the bridge cannot see
    // slotted locals, so the tree-walker runs it.
    if (node->slot >= 0) {
      ok_ = false;
      return newValueSlot();
    }
    // Class construction is checked FIRST, ahead of the user-function
    // registry - mirrors evaluateExpr()'s own classTable_-before-
    // functionTable_-before-builtins precedence exactly (see the class
    // comment's "Classes" section, point 1). A constructor call uses the
    // EXACT SAME shape as a single-output function call - see
    // compileClassConstructor()'s comment for why.
    auto classIt = classCtorArity_.find(node->text);
    if (classIt != classCtorArity_.end()) {
      if (classIt->second != node->children.size()) {
        ok_ = false;
        return newValueSlot();
      }
      std::vector<llvm::Value *> ctorArgSlots;
      ctorArgSlots.reserve(node->children.size());
      for (const auto &argExpr : node->children)
        ctorArgSlots.push_back(codegenExpr(argExpr.get()));

      llvm::Value *instanceSlot = newValueSlot();
      std::vector<llvm::Value *> ctorCallArgs;
      ctorCallArgs.reserve(ctorArgSlots.size() + 2);
      ctorCallArgs.push_back(ctxArg_);
      ctorCallArgs.insert(ctorCallArgs.end(), ctorArgSlots.begin(), ctorArgSlots.end());
      ctorCallArgs.push_back(instanceSlot);

      FunctionCallee ctorCallee = module_->getOrInsertFunction(
          node->text, userFunctionType(classIt->second, 1));
      builder_.CreateCall(ctorCallee, ctorCallArgs);

      for (llvm::Value *a : ctorArgSlots)
        destroyValueSlot(a);
      return instanceSlot;
    }

    // Resolves against a previously-compiled/seeded user function - see
    // functionArity_'s comment. A name PRESENT in functionArity_ always
    // wins here, matching evaluateExpr()'s own precedence exactly
    // (parser_factor.cpp: `if (functionTable_.count(name)) { ...; return
    // result; }` - unconditional on args actually matching an overload,
    // never falling through to callBuiltin() just because the call site's
    // arg count happens to mismatch). So an arity mismatch against a KNOWN
    // user function still rejects at compile time (ok_ = false, same as
    // before this task) rather than being reinterpreted as a builtin call -
    // only a name functionArity_ has never heard of at all falls through to
    // the generic builtin dispatch below. Also requires outputCount==1: a
    // value-producing expression can only ever hand back one llvm::Value*,
    // unlike the tree-walker's callUserFunction(), which will silently call
    // a multi-output function and just use its first output - see the class
    // comment's "Multi-output functions" section for why that permissiveness
    // isn't replicated here. A multi-output function is only callable via
    // multi-target Assign (see StmtKind::Assign below).
    auto it = functionArity_.find(node->text);
    if (it != functionArity_.end()) {
      if (it->second.paramCount != node->children.size() || it->second.outputCount != 1) {
        ok_ = false;
        return newValueSlot();
      }
      std::vector<llvm::Value *> argSlots;
      argSlots.reserve(node->children.size());
      for (const auto &argExpr : node->children)
        argSlots.push_back(codegenExpr(argExpr.get()));

      llvm::Value *outSlot = newValueSlot();
      std::vector<llvm::Value *> callArgs;
      callArgs.reserve(argSlots.size() + 2);
      callArgs.push_back(ctxArg_);
      callArgs.insert(callArgs.end(), argSlots.begin(), argSlots.end());
      callArgs.push_back(outSlot);

      FunctionCallee callee =
          module_->getOrInsertFunction(node->text, userFunctionType(it->second.paramCount, 1));
      builder_.CreateCall(callee, callArgs);

      for (llvm::Value *a : argSlots)
        destroyValueSlot(a);
      return outSlot;
    }

    // Generic dynamic dispatch: node->text is neither a NATIVELY-COMPILED
    // class constructor nor a NATIVELY-COMPILED user-defined function -
    // could still be a real class/function the tree-walker knows about but
    // CodeGen never compiled (inheritance/abstract/reversible/@rate, or
    // simply defined before JIT ran that statement), or one of the ~100+
    // registered builtins (sin, sqrt, transpose, det, sum, mean, ...), or,
    // symmetrically, any genuinely unknown name - mirrors evaluateExpr()'s
    // own final fallthrough exactly (parser_factor.cpp: classTable_ ->
    // functionTable_ -> callBuiltin()), just resolved at run time instead of
    // compile time for this tier. Unlike the two branches above, whether
    // `node->text` is actually registered can't be checked here at compile
    // time (no static name table exists here the way classCtorArity_/
    // functionArity_ do) - so this no longer rejects with ok_ = false the
    // way it used to; nc_bridge_call_dynamic() calls the tree-walker's own
    // callClassConstructor()/callUserFunction()/callBuiltin() directly, so
    // an unrecognized name still prints the identical "Error: Unknown
    // function '<name>'" stderr line and yields the identical Value(0)
    // result, discovered at JIT run
    // time instead of compile time. The found/not-found bool itself is
    // deliberately ignored in this general expression-context path (same
    // precedent as every other bridge call's error code going unchecked
    // here, e.g. nc_bridge_add()'s dimension-mismatch return) - the one
    // place that DOES check it is StmtKind::Assign's Identifier-target
    // case, since that's the one spot a wrong Value would otherwise get
    // written into a variable the tree-walker would have left untouched.
    return codegenBuiltinCall(node, /*outFoundFlag=*/nullptr);
  }

  case ExprKind::FieldAccess:
    return codegenFieldAccess(node, /*outFoundFlag=*/nullptr);

  case ExprKind::MethodCall: {
    // Receiver must be a bare Identifier - same assumption evaluateExpr()
    // itself makes (ast.h's Identifier note; MethodCall's own comment in
    // parser_factor.cpp: "a receiver is always a bare identifier here").
    // The dict-builtin-method fallback (A.keys(), ...) is out of scope -
    // this only ever compiles an instance method call.
    const Expr *receiverNode = node->children[0].get();
    if (receiverNode->kind != ExprKind::Identifier) {
      ok_ = false;
      return newValueSlot();
    }
    // Checked BEFORE the instanceMethods_ lookup below, not after - see
    // methodNameOwners_/ambiguousMethodNames_'s class-comment for why a
    // name landing here can never be natively dispatched safely: it means
    // two or more DIFFERENT classes declare a same-named method, so
    // instanceMethods_'s flat/global-by-name entry for it (if any) might
    // belong to the WRONG one relative to this receiver's actual runtime
    // class - falling back to the tree-walker (which resolves via the
    // receiver's real className) is the only safe option, not "pick
    // whichever one happened to compile".
    if (ambiguousMethodNames_.count(node->text)) {
      ok_ = false;
      return newValueSlot();
    }
    auto it = instanceMethods_.find(node->text);
    if (it == instanceMethods_.end() || it->second.paramCount != node->children.size() - 1) {
      ok_ = false;
      return newValueSlot();
    }

    llvm::Value *selfBefore = codegenExpr(receiverNode);

    std::vector<llvm::Value *> argSlots;
    argSlots.reserve(node->children.size() - 1);
    for (std::size_t i = 1; i < node->children.size(); ++i)
      argSlots.push_back(codegenExpr(node->children[i].get()));

    llvm::Value *selfAfter = newValueSlot();
    llvm::Value *methodOut = newValueSlot();
    std::vector<llvm::Value *> callArgs;
    callArgs.reserve(argSlots.size() + 4);
    callArgs.push_back(ctxArg_);
    callArgs.push_back(selfBefore);
    callArgs.insert(callArgs.end(), argSlots.begin(), argSlots.end());
    callArgs.push_back(selfAfter);
    callArgs.push_back(methodOut);

    FunctionCallee callee =
        module_->getOrInsertFunction(it->second.mangledName, instanceMethodType(it->second.paramCount));
    builder_.CreateCall(callee, callArgs);

    destroyValueSlot(selfBefore);
    for (llvm::Value *a : argSlots)
      destroyValueSlot(a);

    // Persist any base.field mutations back into the receiver variable -
    // mirrors evaluateExpr()'s own unconditional varSet(receiverNode->
    // slot, name, selfAfter) after every instance method call.
    llvm::Value *namePtr = nameOrNullPtr(receiverNode->slot, receiverNode->text);
    llvm::Value *slotIdx = builder_.getInt32(receiverNode->slot);
    builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, selfAfter});
    destroyValueSlot(selfAfter);

    return methodOut;
  }

  default:
    // Everything else (RangeLiteral - only meaningful as a For iterable,
    // handled structurally there, not as a general expression; ParentCall;
    // bare Wildcard outside an Index key list) is explicitly out of scope.
    // Return an empty slot so the IR stays well-formed; compileProgram()/
    // compileStatements() reports failure via ok_.
    ok_ = false;
    return newValueSlot();
  }
}

void CodeGen::codegenStmt(const Stmt *stmt) {
  if (stmtNeedsTreeWalker(stmt)) {
    ok_ = false; // see exprNeedsTreeWalker()
    return;
  }
  // The Analysis box's statement count - executeStmt()'s statement(), once
  // per execution of every statement at any depth. A FunctionDecl/ClassDecl
  // (top level only) is counted by the caller instead (main.cpp), because a
  // script's executeProgram() never executes - so never counts - them.
  if (stmt->kind != StmtKind::FunctionDecl && stmt->kind != StmtKind::ClassDecl)
    builder_.CreateCall(analysisStatementFn(), {});
  switch (stmt->kind) {
  case StmtKind::ExprStmt: {
    // save_workspace()/load_workspace() as a statement: left to the
    // tree-walker, which prints their report but neither echoes their
    // result nor stores it in `ans` (executeStmt()'s ExprStmt case). Same for
    // print_all() (2026-11-23): it prints the value itself, its `true` is
    // not echoed (the JIT echoed "ans = true" after the full text).
    if (stmt->expr && stmt->expr->kind == ExprKind::Call &&
        (stmt->expr->text == "save_workspace" || stmt->expr->text == "load_workspace" ||
         stmt->expr->text == "print_all")) {
      ok_ = false;
      return;
    }
    // Mirrors executeStmt()'s own ExprKind::ExprStmt case, MATLAB style:
    // an expression whose value is not assigned to anything is stored in
    // `ans` (with or without a trailing ';') and, unless suppressed, shown
    // as "ans = ...". Both are gated on success like an assignment's
    // (Assign case below): a failed builtin such as `zeros(2.5)` or
    // `nexus(3, [5,1])` prints its error and neither touches `ans` nor
    // echoes anything - it used to echo a 0.
    //
    // `ans` is written by name (slot -1): at top level that is exactly the
    // tree-walker's setAns(); inside a natively compiled function the
    // bridge's own call frame (nc_bridge_push_scope) holds it, so it stays
    // local to that call like MATLAB's per-workspace `ans`.
    const Expr *e = stmt->expr.get();
    const bool isGenericBuiltinCall = e && e->kind == ExprKind::Call &&
                                      !classCtorArity_.count(e->text) &&
                                      !functionArity_.count(e->text);
    llvm::Value *foundFlag = nullptr;
    llvm::Value *v = isGenericBuiltinCall ? codegenBuiltinCall(e, &foundFlag) : codegenExpr(e);
    {
      llvm::Value *exprOk =
          foundFlag ? foundFlag
                    : builder_.CreateICmpEQ(
                          builder_.CreateCall(getEvaluationSucceededFn(), {ctxArg_}),
                          builder_.getInt32(0), "expr.ok");
      Function *fn = builder_.GetInsertBlock()->getParent();
      BasicBlock *ansBB = BasicBlock::Create(context_, "expr_ans", fn);
      BasicBlock *contBB = BasicBlock::Create(context_, "expr_cont", fn);
      builder_.CreateCondBr(exprOk, ansBB, contBB);
      builder_.SetInsertPoint(ansBB);
      llvm::Value *ansName = builder_.CreateGlobalString("ans");
      builder_.CreateCall(varWriteFn(), {ctxArg_, ansName, builder_.getInt32(-1), v});
      emitAutoEcho(stmt->suppressOutput, "ans", v);
      builder_.CreateBr(contBB);
      builder_.SetInsertPoint(contBB);
    }
    destroyValueSlot(v);
    return;
  }

  case StmtKind::Assign: {
    if (stmt->targets.size() >= 2) {
      // Only [A, B] = f(...) with a natively compiled
      // function is compiled here. A list of variables with rows
      // ([a, b; c, d] = M), a '~' placeholder, deal(...), or any right side
      // that is split into values goes to the tree-walker
      // (executeTargetListAssign(), parser_exec_stmt.cpp).
      if (stmt->targetRows > 1) {
        ok_ = false;
        return;
      }
      for (const auto &t : stmt->targets) {
        if (t->kind == ExprKind::Identifier && t->text == "~") {
          ok_ = false;
          return;
        }
      }
      // Multi-output call: [A,B] = f(...) - mirrors executeAssignStmt()'s
      // own targets.size() >= 2 branch (parser_exec_stmt.cpp) exactly:
      // stmt->value must be a Call (the tree-walker doesn't even check
      // this - it just reads call->text/children off stmt->value.get()
      // unconditionally - checked here explicitly instead, rejecting
      // cleanly rather than mirroring that assumption), every target must
      // be a bare Identifier (A[i]/obj.field multi-target stays out of
      // scope, same as the single-target case above), and the callee's
      // declared output count must match targets.size() exactly (the
      // tree-walker's callUserFunctionMulti() enforces the same check).
      if (stmt->value->kind != ExprKind::Call) {
        ok_ = false;
        return;
      }
      const Expr *call = stmt->value.get();
      auto it = functionArity_.find(call->text);
      if (it == functionArity_.end() || it->second.paramCount != call->children.size() ||
          it->second.outputCount != stmt->targets.size()) {
        ok_ = false;
        return;
      }
      for (const auto &t : stmt->targets) {
        if (t->kind != ExprKind::Identifier) {
          ok_ = false;
          return;
        }
      }

      std::vector<llvm::Value *> argSlots;
      argSlots.reserve(call->children.size());
      for (const auto &argExpr : call->children)
        argSlots.push_back(codegenExpr(argExpr.get()));

      std::vector<llvm::Value *> outSlots;
      outSlots.reserve(stmt->targets.size());
      for (std::size_t i = 0; i < stmt->targets.size(); ++i)
        outSlots.push_back(newValueSlot());

      std::vector<llvm::Value *> callArgs;
      callArgs.reserve(argSlots.size() + outSlots.size() + 1);
      callArgs.push_back(ctxArg_);
      callArgs.insert(callArgs.end(), argSlots.begin(), argSlots.end());
      callArgs.insert(callArgs.end(), outSlots.begin(), outSlots.end());

      FunctionCallee callee = module_->getOrInsertFunction(
          call->text, userFunctionType(it->second.paramCount, it->second.outputCount));
      builder_.CreateCall(callee, callArgs);

      for (llvm::Value *a : argSlots)
        destroyValueSlot(a);

      // Bind each target from its corresponding output, positionally, by
      // index - exactly like executeAssignStmt()'s own for-loop - but only
      // if the call didn't fail partway through (a require/ensure inside
      // it) - mirrors executeAssignStmt()'s multi-output path checking
      // evaluationSucceeded_ before its own binding loop. See
      // nc_bridge_report_condition_failure's comment for the full mechanism.
      llvm::Value *callOk = builder_.CreateICmpEQ(
          builder_.CreateCall(getEvaluationSucceededFn(), {ctxArg_}), builder_.getInt32(0), "call.ok");
      Function *fn = builder_.GetInsertBlock()->getParent();
      BasicBlock *bindBB = BasicBlock::Create(context_, "multiret_bind", fn);
      BasicBlock *skipBB = BasicBlock::Create(context_, "multiret_skip", fn);
      BasicBlock *contBB = BasicBlock::Create(context_, "multiret_cont", fn);
      builder_.CreateCondBr(callOk, bindBB, skipBB);

      builder_.SetInsertPoint(bindBB);
      for (std::size_t i = 0; i < stmt->targets.size(); ++i) {
        const Expr *target = stmt->targets[i].get();
        llvm::Value *namePtr = nameOrNullPtr(target->slot, target->text);
        llvm::Value *slotIdx = builder_.getInt32(target->slot);
        builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, outSlots[i]});
      }
      for (std::size_t i = 0; i < stmt->targets.size(); ++i)
        emitAutoEcho(stmt->suppressOutput, stmt->targets[i]->text, outSlots[i]);
      builder_.CreateBr(contBB);

      builder_.SetInsertPoint(skipBB);
      builder_.CreateBr(contBB);

      builder_.SetInsertPoint(contBB);
      for (llvm::Value *o : outSlots)
        destroyValueSlot(o);
      return;
    }

    if (stmt->targets.size() != 1) {
      ok_ = false;
      return;
    }
    const Expr *target = stmt->targets[0].get();

    if (target->kind == ExprKind::Identifier) {
      llvm::Value *namePtr = nameOrNullPtr(target->slot, target->text);
      llvm::Value *slotIdx = builder_.getInt32(target->slot);

      // A bare Call whose name resolves to neither a natively-compiled class
      // constructor nor a natively-compiled user function (see ExprKind::
      // Call's own codegen) can only be confirmed to exist once
      // nc_bridge_call_dynamic() actually runs - mirrors executeAssignStmt()'s
      // real single-target path exactly (parser_exec_stmt.cpp): `Value val =
      // evaluateExpr(...); if (!evaluationSucceeded_) return;` BEFORE the
      // varSet(), so an unrecognized-name RHS never reaches the target
      // variable there. Every other RHS shape here is assumed to always
      // succeed once it compiles (same long-standing precedent as this
      // file's other unchecked bridge error codes) - this is the one gap
      // that's actually closed, since it's the one the parity harness's
      // unknown-function case exercises: without this branch, `r =
      // nonexistent_fn(1);` would leave the JIT's `r` bound to Value(0)
      // while the tree-walker leaves `r` completely unset - a real,
      // observable divergence a later `r` read would expose.
      bool isGenericBuiltinCall = stmt->value->kind == ExprKind::Call &&
                                   !classCtorArity_.count(stmt->value->text) &&
                                   !functionArity_.count(stmt->value->text);

      if (isGenericBuiltinCall) {
        llvm::Value *foundFlag = nullptr;
        llvm::Value *rhs = codegenBuiltinCall(stmt->value.get(), &foundFlag);

        Function *fn = builder_.GetInsertBlock()->getParent();
        BasicBlock *writeBB = BasicBlock::Create(context_, "builtin_write", fn);
        BasicBlock *contBB = BasicBlock::Create(context_, "builtin_cont", fn);
        builder_.CreateCondBr(foundFlag, writeBB, contBB);

        builder_.SetInsertPoint(writeBB);
        builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, rhs});
        // Only echo on the branch where the write actually happened -
        // mirrors executeAssignStmt()'s own "assign, THEN print" order,
        // which an unrecognized-name RHS never reaches at all.
        emitAutoEcho(stmt->suppressOutput, target->text, rhs);
        builder_.CreateBr(contBB);

        builder_.SetInsertPoint(contBB);
        destroyValueSlot(rhs);
        return;
      }

      // A FieldAccess RHS (obj.field, or the elementwise-dot fallback) can
      // be denied by checkFieldAccess() inside nc_bridge_field_get() (a
      // private/protected field read from outside the declaring class) -
      // same found-flag gating as the generic builtin call above, via
      // codegenFieldAccess()'s own outFoundFlag. Found via real corpus
      // testing (Testing_Files/t29_encapsulation.nc, outside this harness):
      // without this, a denied read still wrote nc_bridge_field_get()'s
      // untouched (zero-initialized) `out` slot into the target variable,
      // where the tree-walker leaves it completely unset.
      if (stmt->value->kind == ExprKind::FieldAccess) {
        llvm::Value *foundFlag = nullptr;
        llvm::Value *rhs = codegenFieldAccess(stmt->value.get(), &foundFlag);

        Function *fn = builder_.GetInsertBlock()->getParent();
        BasicBlock *writeBB = BasicBlock::Create(context_, "field_read_write", fn);
        BasicBlock *contBB = BasicBlock::Create(context_, "field_read_cont", fn);
        builder_.CreateCondBr(foundFlag, writeBB, contBB);

        builder_.SetInsertPoint(writeBB);
        builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, rhs});
        emitAutoEcho(stmt->suppressOutput, target->text, rhs);
        builder_.CreateBr(contBB);

        builder_.SetInsertPoint(contBB);
        destroyValueSlot(rhs);
        return;
      }

      // A natively-compiled function/constructor/instance-method call (the
      // only other ExprKind::Call/MethodCall shapes besides the generic
      // dynamic-dispatch one above) can still fail PARTWAY THROUGH - a
      // require/ensure inside its body - even though it compiles and runs
      // successfully as IR; unlike the generic dispatch path, there's no
      // found-flag for this (the native ABI is void-returning), so this
      // checks nc_bridge_get_evaluation_succeeded() instead, same
      // principle. See nc_bridge_report_condition_failure's comment for
      // the full mechanism and why this was a real, separate bug from the
      // generic-dispatch one above (found via real corpus testing, not the
      // parity harness - Testing_Files/t36_verification_loop_abort.nc for
      // the function case, t35_verification.nc for the method case).
      // MethodCall's own codegen already unconditionally writes the
      // (possibly field-mutated) receiver back before returning - correct
      // as-is, matches callInstanceMethod()'s own unconditional
      // varSet(receiverNode->slot, ...) once `found` is true (parser_
      // factor.cpp) - only the RESULT bound here needs gating.
      bool isNativeCall = (stmt->value->kind == ExprKind::Call &&
                            (classCtorArity_.count(stmt->value->text) ||
                             functionArity_.count(stmt->value->text))) ||
                           (stmt->value->kind == ExprKind::MethodCall &&
                            instanceMethods_.count(stmt->value->text));

      llvm::Value *rhs = codegenExpr(stmt->value.get());

      if (isNativeCall) {
        llvm::Value *callOk = builder_.CreateICmpEQ(
            builder_.CreateCall(getEvaluationSucceededFn(), {ctxArg_}), builder_.getInt32(0), "call.ok");
        Function *fn = builder_.GetInsertBlock()->getParent();
        BasicBlock *writeBB = BasicBlock::Create(context_, "native_write", fn);
        BasicBlock *contBB = BasicBlock::Create(context_, "native_cont", fn);
        builder_.CreateCondBr(callOk, writeBB, contBB);

        builder_.SetInsertPoint(writeBB);
        builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, rhs});
        emitAutoEcho(stmt->suppressOutput, target->text, rhs);
        builder_.CreateBr(contBB);

        builder_.SetInsertPoint(contBB);
        destroyValueSlot(rhs);
        return;
      }

      // Was unconditional here - "every other RHS shape... assumed to
      // always succeed once it compiles" (see the comment above
      // isGenericBuiltinCall). False for a BinaryOp/Comparison whose
      // dimension/type check fails (e.g. `x = 5*m + 3*kg;`, `x = "a"+"b";`)
      // now that the checked bridge (codegenScalarFastPath()'s comment)
      // actually sets Parser::evaluationSucceeded_ on that failure - without
      // this gate, `x` still got written to (and echoed) with whatever
      // nc_bridge_value_create()'s zero-initialized `out` happened to be,
      // instead of staying unassigned like executeAssignStmt()'s own
      // `if (!evaluationSucceeded_) return;` guard (parser_exec_stmt.cpp)
      // leaves it in the tree-walker.
      llvm::Value *rhsOk = builder_.CreateICmpEQ(
          builder_.CreateCall(getEvaluationSucceededFn(), {ctxArg_}), builder_.getInt32(0), "rhs.ok");
      Function *fn2 = builder_.GetInsertBlock()->getParent();
      BasicBlock *writeBB2 = BasicBlock::Create(context_, "assign_write", fn2);
      BasicBlock *contBB2 = BasicBlock::Create(context_, "assign_cont", fn2);
      builder_.CreateCondBr(rhsOk, writeBB2, contBB2);

      builder_.SetInsertPoint(writeBB2);
      builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, rhs});
      emitAutoEcho(stmt->suppressOutput, target->text, rhs);
      builder_.CreateBr(contBB2);

      builder_.SetInsertPoint(contBB2);
      destroyValueSlot(rhs);
      return;
    }

    if (target->kind == ExprKind::Index) {
      // Mirrors executeIndexAssign() (parser_exec_stmt.cpp).
      const Expr *base = target->children[0].get();
      const Expr *innerBase = nullptr;
      std::vector<const Expr *> keyExprs;

      if (base->kind == ExprKind::Index) {
        // Chained A[row][col] = v. executeIndexAssign() special-cases
        // this shape directly rather than decomposing it the way a READ
        // would (evaluate A[row], then index-write into THAT) - naive
        // decomposition would write into a COPY of the selected row
        // (evaluateExpr()'s matrix row-select returns Value(v.matrix[row]),
        // a new Value, not a reference), silently failing to mutate the
        // real matrix. Flattened here into the same 2-key call
        // nc_bridge_index_set() uses for comma-form A[row,col]=v - see
        // value_bridge.h's own note that both forms are one call. Unlike
        // the comma form below, the CHAINED bracket form has no wildcard
        // meaning in the tree-walker at all (executeIndexAssign()'s
        // chained-base branch evaluates both keys directly, no Wildcard
        // check) - reject cleanly if either key here is one, same as
        // before this task.
        if (target->children.size() != 2 || base->children.size() != 2 ||
            base->children[0]->kind != ExprKind::Identifier ||
            base->children[1]->kind == ExprKind::Wildcard ||
            target->children[1]->kind == ExprKind::Wildcard) {
          ok_ = false;
          return;
        }
        innerBase = base->children[0].get();
        keyExprs = {base->children[1].get(), target->children[1].get()};
      } else if (base->kind == ExprKind::Identifier) {
        innerBase = base;
        for (std::size_t i = 1; i < target->children.size(); ++i)
          keyExprs.push_back(target->children[i].get());
      } else {
        ok_ = false;
        return;
      }

      // Evaluation order matches executeAssignStmt()'s single-target path:
      // the RHS is evaluated before executeIndexAssign() (and therefore
      // before its own key evaluation) runs.
      llvm::Value *rhs = codegenExpr(stmt->value.get());

      // Same null-pointer-for-Wildcard marshaling as the read side
      // (ExprKind::Index above) - only reachable here via the comma-form
      // (plain-identifier-base) branch, since the chained-base branch above
      // already rejected any Wildcard key at compile time.
      std::vector<llvm::Value *> keySlots;
      keySlots.reserve(keyExprs.size());
      for (const Expr *k : keyExprs) {
        if (k->kind == ExprKind::Wildcard)
          keySlots.push_back(ConstantPointerNull::get(ptrTy()));
        else
          keySlots.push_back(codegenExpr(k));
      }

      llvm::Value *keysBuf = buildPointerArray(keySlots);
      llvm::Value *namePtr = nameOrNullPtr(innerBase->slot, innerBase->text);
      llvm::Value *statusI32 = builder_.CreateCall(
          indexSetFn(), {ctxArg_, namePtr, builder_.getInt32(innerBase->slot), keysBuf,
                          builder_.getInt32(static_cast<int>(keySlots.size())), rhs});

      destroyValueSlot(rhs);
      for (llvm::Value *k : keySlots)
        destroyValueSlot(k);

      // Branch on the write's status regardless of suppressOutput: on
      // success, auto-echo (unless suppressed) prints the WHOLE base
      // container after the write, mirroring executeIndexAssign()'s own
      // printValue(name, varGet(slot,name)) at the end of every one of its
      // success branches; on failure, report it - previously this only
      // gated the echo and silently did nothing else on failure (e.g. `arr[
      // -1] = 99;` left the array untouched, correctly, but with no error
      // message and no evaluationSucceeded_ = false at all, unlike the
      // tree-walker, which always prints "Error: array/matrix index out of
      // range for '<name>'" and sets evaluationSucceeded_ = false - see
      // nc_bridge_report_index_set_failure's own comment for why this
      // reports one general message rather than replicating every exact
      // wording).
      {
        Function *fn = builder_.GetInsertBlock()->getParent();
        BasicBlock *okBB = BasicBlock::Create(context_, "index_ok", fn);
        BasicBlock *failBB = BasicBlock::Create(context_, "index_fail", fn);
        BasicBlock *contBB = BasicBlock::Create(context_, "index_cont", fn);
        llvm::Value *ok = builder_.CreateICmpEQ(statusI32, builder_.getInt32(0), "index.ok");
        builder_.CreateCondBr(ok, okBB, failBB);

        builder_.SetInsertPoint(okBB);
        if (!stmt->suppressOutput) {
          llvm::Value *wholeVal = newValueSlot();
          llvm::Value *namePtr2 = nameOrNullPtr(innerBase->slot, innerBase->text);
          builder_.CreateCall(varReadFn(),
                               {ctxArg_, namePtr2, builder_.getInt32(innerBase->slot), wholeVal});
          emitAutoEcho(false, innerBase->text, wholeVal);
          destroyValueSlot(wholeVal);
        }
        builder_.CreateBr(contBB);

        builder_.SetInsertPoint(failBB);
        llvm::Value *namePtr3 = nameOrNullPtr(innerBase->slot, innerBase->text);
        builder_.CreateCall(reportIndexSetFailureFn(), {ctxArg_, namePtr3});
        builder_.CreateBr(contBB);

        builder_.SetInsertPoint(contBB);
      }
      return;
    }

    if (target->kind == ExprKind::FieldAccess) {
      // obj.field = v - mirrors executeAssignStmt()'s ExprKind::FieldAccess
      // target case (parser_exec_stmt.cpp): requires a bare-Identifier
      // base (same assumption the tree-walker itself documents - "always
      // a bare identifier"), no auto-vivification (nc_bridge_field_set
      // rejects a base that isn't already an object). checkFieldAccess()
      // enforcement not replicated - see value_bridge.h's note.
      const Expr *base = target->children[0].get();
      if (base->kind != ExprKind::Identifier) {
        ok_ = false;
        return;
      }
      llvm::Value *rhs = codegenExpr(stmt->value.get());
      llvm::Value *fieldNamePtr = builder_.CreateGlobalString(target->text);
      llvm::Value *namePtr = nameOrNullPtr(base->slot, base->text);
      llvm::Value *statusI32 = builder_.CreateCall(
          fieldSetFn(), {ctxArg_, namePtr, builder_.getInt32(base->slot), fieldNamePtr, rhs});

      // Mirrors executeAssignStmt()'s ExprKind::FieldAccess case: prints the
      // ASSIGNED VALUE itself under the base object's name (not the whole
      // object - deliberately different from the Index-target case above),
      // and only when checkFieldAccess() actually allowed the write. This
      // codegen path doesn't replicate checkFieldAccess() (already a known,
      // separately-flagged gap - see value_bridge.h), but it DOES already
      // reject a base that isn't an object/doesn't exist (nc_bridge_
      // field_set's own status code) - gating on that same status at least
      // keeps a genuinely-failed write silent, same principle as Index above.
      if (!stmt->suppressOutput) {
        Function *fn = builder_.GetInsertBlock()->getParent();
        BasicBlock *echoBB = BasicBlock::Create(context_, "field_echo", fn);
        BasicBlock *contBB = BasicBlock::Create(context_, "field_cont", fn);
        llvm::Value *ok = builder_.CreateICmpEQ(statusI32, builder_.getInt32(0), "field.ok");
        builder_.CreateCondBr(ok, echoBB, contBB);

        builder_.SetInsertPoint(echoBB);
        emitAutoEcho(false, base->text, rhs);
        builder_.CreateBr(contBB);

        builder_.SetInsertPoint(contBB);
      }
      destroyValueSlot(rhs);
      return;
    }

    ok_ = false;
    return;
  }

  case StmtKind::Publish: {
    if (stmt->publishArgs.size() != 1) {
      // Multi-argument publish - out of scope (matches value_bridge.h's
      // nc_bridge_publish, which is single-value only).
      ok_ = false;
      return;
    }
    llvm::Value *v = codegenExpr(stmt->publishArgs[0].get());
    // Mirrors executeStmt()'s own StmtKind::Publish case exactly: "if
    // (evaluationSucceeded_) { ...print... }". Previously unconditional -
    // a real gap once the checked BinaryOp/Comparison bridge (see
    // codegenScalarFastPath()'s comment) started actually setting
    // evaluationSucceeded_ = false on a dimension/type-check failure: even
    // with that fix, `publish((5*m) > (3*kg));` still printed a bogus `0`
    // here unconditionally, right after the correct error message, instead
    // of staying silent like the tree-walker does on the same failure.
    llvm::Value *ok = builder_.CreateICmpEQ(
        builder_.CreateCall(getEvaluationSucceededFn(), {ctxArg_}), builder_.getInt32(0), "publish.ok");
    Function *fn = builder_.GetInsertBlock()->getParent();
    BasicBlock *printBB = BasicBlock::Create(context_, "publish_print", fn);
    BasicBlock *contBB = BasicBlock::Create(context_, "publish_cont", fn);
    builder_.CreateCondBr(ok, printBB, contBB);

    builder_.SetInsertPoint(printBB);
    builder_.CreateCall(publishFn(), {v});
    builder_.CreateBr(contBB);

    builder_.SetInsertPoint(contBB);
    destroyValueSlot(v);
    return;
  }

  case StmtKind::If: {
    Function *fn = builder_.GetInsertBlock()->getParent();
    BasicBlock *mergeBB = BasicBlock::Create(context_, "if_merge", fn);

    // (condition, body) pairs to check in order: the main `if`, then each
    // `elseif` - exactly the tree-walker's own sequential, short-
    // circuiting evaluation (executeStmt's StmtKind::If case), so only one
    // branch's body ever runs.
    std::vector<std::pair<const Expr *, const std::vector<std::unique_ptr<Stmt>> *>> branches;
    branches.emplace_back(stmt->condition.get(), &stmt->body);
    for (const auto &eb : stmt->elseifBranches)
      branches.emplace_back(eb.first.get(), &eb.second);

    for (std::size_t i = 0; i < branches.size(); ++i) {
      bool isLast = (i + 1 == branches.size());
      bool hasElse = !stmt->elseBody.empty();

      llvm::Value *isTrue = codegenTruthyCondition(branches[i].first);

      BasicBlock *bodyBB = BasicBlock::Create(context_, "if_body", fn);
      BasicBlock *falseTarget = !isLast   ? BasicBlock::Create(context_, "if_check", fn)
                                 : hasElse ? BasicBlock::Create(context_, "if_else", fn)
                                           : mergeBB;
      builder_.CreateCondBr(isTrue, bodyBB, falseTarget);

      builder_.SetInsertPoint(bodyBB);
      codegenStmtList(*branches[i].second);
      ensureTerminator(mergeBB);

      builder_.SetInsertPoint(falseTarget);
      if (isLast && falseTarget != mergeBB) {
        // The else branch - emit it now, right here, then this If
        // statement is done.
        codegenStmtList(stmt->elseBody);
        ensureTerminator(mergeBB);
        builder_.SetInsertPoint(mergeBB);
      }
      // Otherwise falseTarget is either mergeBB (no else - this If
      // statement is done, insertion point already correct) or the next
      // elseif's check block (loop continues, insertion point already
      // there for it to build into).
    }
    return;
  }

  case StmtKind::While: {
    Function *fn = builder_.GetInsertBlock()->getParent();
    BasicBlock *condBB = BasicBlock::Create(context_, "while_cond", fn);
    BasicBlock *bodyBB = BasicBlock::Create(context_, "while_body", fn);
    BasicBlock *exitBB = BasicBlock::Create(context_, "while_exit", fn);
    BasicBlock *capBB = BasicBlock::Create(context_, "while_cap_check", fn);
    BasicBlock *capFailBB = BasicBlock::Create(context_, "while_cap_fail", fn);

    // Per-execution iteration counter, mirroring the tree-walker's local
    // `iterationCount` (parser_exec_stmt.cpp's While case): reset to 0 each
    // time this statement starts, so a nested while restarts its own count
    // on every entry. The alloca lives in the function's ENTRY block, not
    // here - an alloca executed inside a loop grows the stack on every
    // execution, which a deeply nested while would turn into a stack leak.
    llvm::IRBuilder<> entryBuilder(&fn->getEntryBlock(), fn->getEntryBlock().begin());
    llvm::Value *iters = entryBuilder.CreateAlloca(builder_.getInt32Ty(), nullptr, "while_iters");
    builder_.CreateStore(builder_.getInt32(0), iters);

    // The Analysis box: the tree-walker's LoopScope(line, false, -1),
    // opened before the first condition test and closed in exitBB - which
    // every way out of this loop (condition false, break, the iteration
    // cap, Stop) goes through. A `return` inside the body is closed by the
    // enclosing function's epilogue (emitAnalysisFrameExit()).
    llvm::Value *whileLoopToken = builder_.CreateCall(
        analysisLoopBeginFn(),
        {builder_.getInt32(static_cast<int>(stmt->line)), builder_.getInt32(0), builder_.getInt64(-1)},
        "while.analysis");

    builder_.CreateBr(condBB);

    builder_.SetInsertPoint(condBB);
    llvm::Value *isTrue = codegenTruthyCondition(stmt->condition.get());
    builder_.CreateCondBr(isTrue, capBB, exitBB);

    // Same order as the interpreter: the condition was true, so count this
    // iteration and stop (with the shared runtime error) once the count
    // exceeds kMaxWhileIterations (ast.h) - BEFORE running the body.
    builder_.SetInsertPoint(capBB);
    builder_.CreateCall(analysisLoopIterationFn(), {}); // analysisLoop.iteration()
    llvm::Value *curIters = builder_.CreateLoad(builder_.getInt32Ty(), iters, "iters");
    llvm::Value *nextIters = builder_.CreateAdd(curIters, builder_.getInt32(1), "iters.next");
    builder_.CreateStore(nextIters, iters);
    llvm::Value *overLimit =
        builder_.CreateICmpSGT(nextIters, builder_.getInt32(kMaxWhileIterations), "while.over");
    // Stop pressed in the IDE (runtime/execution/Interrupt.h): checked once
    // per iteration, before the body - the loop just exits.
    BasicBlock *whilePollBB = BasicBlock::Create(context_, "while_poll", fn);
    builder_.CreateCondBr(overLimit, capFailBB, whilePollBB);
    builder_.SetInsertPoint(whilePollBB);
    llvm::Value *whileStop = builder_.CreateCall(
        declareFn("nc_bridge_poll_interrupt", Type::getInt32Ty(context_), {ptrTy()}), {ctxArg_});
    builder_.CreateCondBr(builder_.CreateICmpNE(whileStop, builder_.getInt32(0), "while.stop"),
                          exitBB, bodyBB);

    builder_.SetInsertPoint(capFailBB);
    builder_.CreateCall(reportWhileLimitFn(), {ctxArg_});
    builder_.CreateBr(exitBB);

    builder_.SetInsertPoint(bodyBB);
    loopStack_.push_back({condBB, exitBB});
    codegenStmtList(stmt->body);
    loopStack_.pop_back();
    ensureTerminator(condBB);

    builder_.SetInsertPoint(exitBB);
    builder_.CreateCall(analysisLoopEndFn(), {whileLoopToken});
    return;
  }

  case StmtKind::For: {
    // Scoped to ONLY the RangeLiteral iterable case - "for i = [a:b]" /
    // "for i = [a:b:step]". The general "for x in <collection>" case
    // (ast.h's own comment on StmtKind::For calls this out as a distinct
    // shape - "any other expr for `for x in collection`") needs array/
    // matrix/dict support that's explicitly still out of scope; rejected
    // cleanly here rather than mishandled.
    if (!stmt->iterable || stmt->iterable->kind != ExprKind::RangeLiteral) {
      ok_ = false;
      return;
    }
    const Expr *range = stmt->iterable.get();
    // Bracket chars decide inclusivity/exclusivity and are baked into the
    // AST node's own text at parse time (ast.h's RangeLiteral comment) -
    // known here at codegen time, not something generated IR needs to
    // decide at runtime. Matches evaluateExpr()'s RangeLiteral case and
    // generateRange()'s own defaulting exactly (parser_factor.cpp,
    // parser_block_exec.cpp).
    char leftBracket = range->text.size() > 0 ? range->text[0] : '[';
    char rightBracket = range->text.size() > 1 ? range->text[1] : ']';
    bool leftExclusive = (leftBracket == '(');
    bool rightInclusive = (rightBracket == ']');

    // start/stop/step are each arbitrary expressions (a literal, a
    // variable, ...) - evaluated once, through the normal expression
    // codegen path, exactly like evaluateExpr()'s RangeLiteral case does
    // (never re-evaluated per iteration). nc_bridge_get_number() pulls the
    // native double out of each result Value so the loop itself can run as
    // a real counter instead of crossing the bridge every iteration.
    llvm::Value *startV = codegenExpr(range->rangeStart.get());
    llvm::Value *startNum = builder_.CreateCall(getNumberFn(), {startV});
    destroyValueSlot(startV);

    llvm::Value *stepNum;
    if (range->rangeStep) {
      llvm::Value *stepV = codegenExpr(range->rangeStep.get());
      stepNum = builder_.CreateCall(getNumberFn(), {stepV});
      destroyValueSlot(stepV);
    } else {
      stepNum = ConstantFP::get(Type::getDoubleTy(context_), 1.0);
    }

    llvm::Value *stopV = codegenExpr(range->rangeStop.get());
    llvm::Value *endNum = builder_.CreateCall(getNumberFn(), {stopV});
    destroyValueSlot(stopV);

    Function *fn = builder_.GetInsertBlock()->getParent();

    // Step zero: the tree-walker's RangeLiteral reports "range literal step
    // cannot be zero" (after evaluating start, step and stop, as above) and
    // the For statement returns without running its body. Only a written
    // step can be zero - the default step is the constant 1.
    BasicBlock *forDoneBB = nullptr;
    if (range->rangeStep) {
      BasicBlock *zeroStepBB = BasicBlock::Create(context_, "for_zero_step", fn);
      BasicBlock *setupBB = BasicBlock::Create(context_, "for_setup", fn);
      forDoneBB = BasicBlock::Create(context_, "for_done", fn);
      llvm::Value *stepIsZero = builder_.CreateFCmp(llvm::CmpInst::FCMP_OEQ, stepNum,
                                                    ConstantFP::get(Type::getDoubleTy(context_), 0.0),
                                                    "for.step0");
      builder_.CreateCondBr(stepIsZero, zeroStepBB, setupBB);
      builder_.SetInsertPoint(zeroStepBB);
      builder_.CreateCall(reportZeroRangeStepFn(), {ctxArg_});
      builder_.CreateBr(forDoneBB);
      builder_.SetInsertPoint(setupBB);
    }

    llvm::Value *initVal = leftExclusive ? builder_.CreateFAdd(startNum, stepNum) : startNum;
    llvm::Value *rightIncl = builder_.getInt32(rightInclusive ? 1 : 0);

    // Since 2026-11-20 the loop counts k = 0 .. count-1 and takes value k
    // from nc_bridge_range_value() - core/range_spec.h, the same count and
    // the same numbers as the tree-walker's For case (first + k*step, no
    // running sum). The count is known before the first iteration.
    llvm::Value *forTotal = builder_.CreateCall(rangeIterationCountFn(), {initVal, stepNum, endNum, rightIncl},
                                                "for.total");

    // An endless range ([1:inf]): the tree-walker's error, and no loop.
    if (!forDoneBB)
      forDoneBB = BasicBlock::Create(context_, "for_done", fn);
    BasicBlock *endlessBB = BasicBlock::Create(context_, "for_endless", fn);
    BasicBlock *loopSetupBB = BasicBlock::Create(context_, "for_loop_setup", fn);
    builder_.CreateCondBr(builder_.CreateICmpSLT(forTotal, builder_.getInt64(0), "for.endless"), endlessBB,
                          loopSetupBB);
    builder_.SetInsertPoint(endlessBB);
    builder_.CreateCall(reportEndlessRangeFn(), {ctxArg_});
    builder_.CreateBr(forDoneBB);
    builder_.SetInsertPoint(loopSetupBB);

    // The index lives in the function's ENTRY block, like the While case's
    // iteration counter: an alloca executed every time this statement runs
    // (e.g. a for inside another loop) would grow the stack on every run.
    // The store below still re-initialises it each time.
    llvm::IRBuilder<> entryBuilder(&fn->getEntryBlock(), fn->getEntryBlock().begin());
    llvm::Value *counter = entryBuilder.CreateAlloca(Type::getInt64Ty(context_), nullptr, "for_index");
    builder_.CreateStore(builder_.getInt64(0), counter);

    BasicBlock *condBB = BasicBlock::Create(context_, "for_cond", fn);
    BasicBlock *bodyBB = BasicBlock::Create(context_, "for_body", fn);
    BasicBlock *incrBB = BasicBlock::Create(context_, "for_incr", fn);
    BasicBlock *exitBB = BasicBlock::Create(context_, "for_exit", fn);

    // The Analysis box: the tree-walker's LoopScope(line, true, <range
    // length>), opened once the range is known and closed in exitBB (every
    // way out but `return`, which the function epilogue closes).
    llvm::Value *forLoopToken = builder_.CreateCall(
        analysisLoopBeginFn(),
        {builder_.getInt32(static_cast<int>(stmt->line)), builder_.getInt32(1), forTotal}, "for.analysis");

    builder_.CreateBr(condBB);

    builder_.SetInsertPoint(condBB);
    llvm::Value *curForCond = builder_.CreateLoad(Type::getInt64Ty(context_), counter, "cur");
    llvm::Value *isTrue = builder_.CreateICmpSLT(curForCond, forTotal, "for_continue");
    // Stop pressed in the IDE: checked once per iteration, before the body.
    BasicBlock *forPollBB = BasicBlock::Create(context_, "for_poll", fn);
    builder_.CreateCondBr(isTrue, forPollBB, exitBB);
    builder_.SetInsertPoint(forPollBB);
    llvm::Value *forStop = builder_.CreateCall(
        declareFn("nc_bridge_poll_interrupt", Type::getInt32Ty(context_), {ptrTy()}), {ctxArg_});
    builder_.CreateCondBr(builder_.CreateICmpNE(forStop, builder_.getInt32(0), "for.stop"), exitBB,
                          bodyBB);

    builder_.SetInsertPoint(bodyBB);
    builder_.CreateCall(analysisLoopIterationFn(), {}); // analysisLoop.iteration(), before the loop variable is set
    llvm::Value *curIndex = builder_.CreateLoad(Type::getInt64Ty(context_), counter, "cur");
    llvm::Value *curForBody =
        builder_.CreateCall(rangeValueFn(), {initVal, stepNum, endNum, rightIncl, curIndex}, "for.value");
    llvm::Value *loopVarVal = newValueSlot();
    builder_.CreateCall(valueSetNumberFn(), {loopVarVal, curForBody});
    llvm::Value *namePtr = nameOrNullPtr(stmt->loopVarSlot, stmt->loopVar);
    llvm::Value *slotIdx = builder_.getInt32(stmt->loopVarSlot);
    builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, slotIdx, loopVarVal});
    destroyValueSlot(loopVarVal);

    loopStack_.push_back({incrBB, exitBB});
    codegenStmtList(stmt->body);
    loopStack_.pop_back();
    ensureTerminator(incrBB);

    builder_.SetInsertPoint(incrBB);
    llvm::Value *curForIncr = builder_.CreateLoad(Type::getInt64Ty(context_), counter, "cur");
    llvm::Value *nextIndex = builder_.CreateAdd(curForIncr, builder_.getInt64(1), "next");
    builder_.CreateStore(nextIndex, counter);
    builder_.CreateBr(condBB);

    builder_.SetInsertPoint(exitBB);
    builder_.CreateCall(analysisLoopEndFn(), {forLoopToken});
    // Joins the step-zero and endless-range paths, which skipped the loop.
    builder_.CreateBr(forDoneBB);
    builder_.SetInsertPoint(forDoneBB);
    return;
  }

  case StmtKind::Break: {
    if (loopStack_.empty()) {
      // Mirrors executeStmt()'s own rejection: "'break' used outside of a loop".
      ok_ = false;
      return;
    }
    builder_.CreateBr(loopStack_.back().breakTarget);
    return;
  }

  case StmtKind::Continue: {
    if (loopStack_.empty()) {
      ok_ = false;
      return;
    }
    builder_.CreateBr(loopStack_.back().continueTarget);
    return;
  }

  case StmtKind::Return: {
    // Mirrors the tree-walker's own mechanism once investigated: Return
    // carries no expression at all (executeStmt's StmtKind::Return case is
    // just `loopSignal_ = LoopSignal::Return;`) - it's a bare "stop
    // running this body now" signal. The actual return value is whatever
    // the function's declared output name holds afterward, extracted in
    // the epilogue below - so Return itself is just a `br` there, exactly
    // like Break/Continue branch to their loop's targets.
    if (!currentFunctionEpilogue_) {
      // Shouldn't happen - compileStatements()/FunctionDecl always set one
      // - but reject cleanly rather than dereference null if it somehow did.
      ok_ = false;
      return;
    }
    // A top-level `return;` also needs Parser::loopSignal_ set so a caller's
    // consumeTopLevelStopSignal() check sees it and stops the rest of the
    // script - see nc_bridge_signal_top_level_return's comment for why this
    // is gated on !inUserFunctionBody_ (inside a user function/method body,
    // the `br` above already fully handles "stop this body", and touching
    // loopSignal_ there would incorrectly leak past the call).
    if (!inUserFunctionBody_)
      builder_.CreateCall(signalTopLevelReturnFn(), {ctxArg_});
    builder_.CreateBr(currentFunctionEpilogue_);
    return;
  }

  case StmtKind::FunctionDecl: {
    // Default values (F(a, b=2)) are filled in by the tree-walker's
    // invokeFunctionBody(); a native function takes exactly paramCount
    // values. Not compiled, so every call to it reaches the tree-walker
    // (directly, or through nc_bridge_call_dynamic).
    if (stmt->hasDefaults()) {
      ok_ = false;
      return;
    }
    if (stmt->outputNames.empty()) {
      // Void (no declared output) is out of scope for this slice - one or
      // more declared outputs required. (Any number is fine now - see the
      // class comment's "Multi-output functions" section; this used to
      // require exactly one.)
      ok_ = false;
      return;
    }
    unsigned paramCount = static_cast<unsigned>(stmt->inputNames.size());
    unsigned outputCount = static_cast<unsigned>(stmt->outputNames.size());
    FunctionType *fnTy = userFunctionType(paramCount, outputCount);
    Function *userFn = Function::Create(fnTy, Function::ExternalLinkage, stmt->name, module_.get());

    // Registered BEFORE compiling the body - a recursive call to this same
    // function inside its own body must already resolve stmt->name (see
    // ExprKind::Call). Also recorded as newly defined here so a caller
    // (JitEngine) persisting functionArity_ across separate compiles knows
    // to carry this one forward too.
    functionArity_[stmt->name] = {paramCount, outputCount};
    newlyDefinedFunctions_.emplace_back(stmt->name, paramCount, outputCount);

    // Compiling this function's body happens while builder_ may currently
    // be in the middle of building another function (the top-level entry,
    // or - NC forbids nested FunctionDecl, so this is defense-in-depth,
    // not a real case - an enclosing one). Save/restore every bit of
    // per-function state this visitor tracks, same principle as
    // codegenStmtList's dead-block handling: never let building one
    // function corrupt whatever was being built around it.
    BasicBlock *savedInsertBlock = builder_.GetInsertBlock();
    llvm::Argument *savedCtxArg = ctxArg_;
    BasicBlock *savedEpilogue = currentFunctionEpilogue_;
    std::vector<LoopTargets> savedLoopStack = std::move(loopStack_);
    loopStack_.clear(); // a function body starts with no enclosing loop of its own
    bool savedInUserFunctionBody = inUserFunctionBody_;
    inUserFunctionBody_ = true;

    BasicBlock *entryBB = BasicBlock::Create(context_, "entry", userFn);
    BasicBlock *epilogueBB = BasicBlock::Create(context_, "epilogue", userFn);
    builder_.SetInsertPoint(entryBB);
    ctxArg_ = userFn->getArg(0);
    ctxArg_->setName("ctx");

    // Fresh local scope (nc_bridge_push_scope - see value_bridge.h), then
    // bind each parameter into it by name (slot -1 always - this AST was
    // never run through Phase 6 slot resolution, so every variable access
    // in this body is the name-keyed `memory` path; see nc_bridge_var_
    // read/write's existing behavior, unchanged and reused as-is).
    builder_.CreateCall(pushScopeFn(), {ctxArg_});
    llvm::Value *fnLoopDepth = emitAnalysisFrameEnter();
    for (unsigned i = 0; i < paramCount; ++i) {
      llvm::Value *paramArg = userFn->getArg(1 + i);
      paramArg->setName(stmt->inputNames[i]);
      llvm::Value *namePtr = builder_.CreateGlobalString(stmt->inputNames[i]);
      builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, builder_.getInt32(-1), paramArg});
    }

    currentFunctionEpilogue_ = epilogueBB;
    codegenStmtList(stmt->body);
    ensureTerminator(epilogueBB);

    builder_.SetInsertPoint(epilogueBB);
    emitAnalysisFrameExit(fnLoopDepth); // a `return` from inside a loop
    // Read each declared output back out of the (about to be torn down)
    // local scope directly into its corresponding caller-supplied `out`
    // pointer, THEN pop the scope - order matters, the outputs live in the
    // scope being discarded. Mirrors invokeFunctionBody()'s own loop
    // (parser_function.cpp), which extracts every declared output the same
    // way regardless of how many there are - single-output
    // (callUserFunction) and multi-output (callUserFunctionMulti) both read
    // from what it already built, including the exact "output not assigned"
    // error and evaluationSucceeded_ = false when the body never assigned
    // one - see nc_bridge_read_declared_output's comment.
    llvm::Value *ownerNamePtr = builder_.CreateGlobalString(stmt->name);
    for (unsigned i = 0; i < outputCount; ++i) {
      llvm::Value *outNamePtr = builder_.CreateGlobalString(stmt->outputNames[i]);
      llvm::Value *outArgPtr = userFn->getArg(1 + paramCount + i);
      builder_.CreateCall(readDeclaredOutputFn(),
                           {ctxArg_, outNamePtr, ownerNamePtr, builder_.getInt32(0), outArgPtr});
    }
    builder_.CreateCall(popScopeFn(), {ctxArg_});
    builder_.CreateRetVoid();

    std::string err;
    llvm::raw_string_ostream os(err);
    if (llvm::verifyFunction(*userFn, &os)) {
      llvm::errs() << "CodeGen: function verification failed for '" << stmt->name << "': " << os.str() << "\n";
      ok_ = false;
    }

    // Restore whatever was being built before this FunctionDecl.
    ctxArg_ = savedCtxArg;
    currentFunctionEpilogue_ = savedEpilogue;
    loopStack_ = std::move(savedLoopStack);
    inUserFunctionBody_ = savedInUserFunctionBody;
    builder_.SetInsertPoint(savedInsertBlock);
    return;
  }

  case StmtKind::ClassDecl: {
    // Deliberately the narrowest possible slice for NATIVE compilation -
    // see the class comment's "Classes" section. Inheritance/abstract/
    // reversible/@rate are still out of scope for compiling the class
    // itself (this statement just isn't natively compiled - it falls back
    // to the tree-walker's real registerClassDeclStmt() instead, so the
    // class ends up correctly registered either way); ExprKind::Call's
    // generic dynamic-dispatch tier (nc_bridge_call_dynamic ->
    // callClassConstructor()) is what makes LATER statements that
    // construct/use one of these classes still JIT-accelerated - see
    // value_bridge.h's "Dynamic call dispatch" section.
    // Unconditional, even for a class this slice goes on to reject for
    // native compilation - see registerMethodNamesForCollisionCheck()'s own
    // comment (and the class-wide comment on methodNameOwners_/
    // ambiguousMethodNames_) for why a REJECTED class's method names still
    // need to be seen here.
    registerMethodNamesForCollisionCheck(stmt);

    if (!stmt->parentClassName.empty() || stmt->isAbstract || stmt->isReversible || stmt->hasRate) {
      ok_ = false;
      return;
    }
    // A constructor or method with default values - see FunctionDecl.
    for (const auto &m : stmt->methods) {
      if (m->hasDefaults()) {
        ok_ = false;
        return;
      }
    }

    const Stmt *ctorStmt = nullptr;
    std::vector<const Stmt *> otherMethods;
    for (const auto &m : stmt->methods) {
      if (m->name == "base")
        ctorStmt = m.get();
      else
        otherMethods.push_back(m.get());
    }
    if (!ctorStmt) {
      // No constructor - callClassConstructor() itself treats this as an
      // error ("missing 'function base(...)'"), not a valid no-op class.
      ok_ = false;
      return;
    }

    // Registered BEFORE compiling any bodies - same reasoning as
    // FunctionDecl: nothing in this slice's methods can call back into
    // the constructor or a sibling method the way a recursive function
    // could, but registering first keeps the ordering consistent and
    // costs nothing.
    unsigned ctorParamCount = static_cast<unsigned>(ctorStmt->inputNames.size());
    classCtorArity_[stmt->name] = ctorParamCount;
    newlyDefinedClasses_.emplace_back(stmt->name, ctorParamCount);

    compileClassConstructor(stmt, ctorStmt);
    for (const Stmt *m : otherMethods)
      compileInstanceMethod(stmt, m);
    return;
  }

  case StmtKind::Require:
  case StmtKind::Ensure: {
    // Mirrors executeStmt()'s StmtKind::Require/Ensure case exactly
    // (parser_exec_stmt.cpp): on a false condition, print the precondition/
    // postcondition-failed message and stop running this body right here -
    // the tree-walker does that via `loopSignal_ = LoopSignal::Return;`,
    // which is exactly what a `br` to the enclosing function's epilogue
    // already means for StmtKind::Return above, so this reuses that same
    // branch target rather than needing its own control-flow state. (The
    // tree-walker's "condition itself failed to evaluate" early-return
    // isn't tracked here - no codegen'd expression tracks evaluationSucceeded_
    // at all, the same pre-existing gap every other bridge call already has.)
    bool isRequire = (stmt->kind == StmtKind::Require);
    llvm::Value *isTrue = codegenTruthyCondition(stmt->condition.get());

    Function *fn = builder_.GetInsertBlock()->getParent();
    BasicBlock *failBB = BasicBlock::Create(context_, isRequire ? "require_fail" : "ensure_fail", fn);
    BasicBlock *okBB = BasicBlock::Create(context_, isRequire ? "require_ok" : "ensure_ok", fn);
    builder_.CreateCondBr(isTrue, okBB, failBB);

    builder_.SetInsertPoint(failBB);
    llvm::Value *textPtr = builder_.CreateGlobalString(stmt->conditionText);
    llvm::Value *messagePtr = builder_.CreateGlobalString(stmt->contractMessage);
    builder_.CreateCall(reportConditionFailureFn(),
                        {ctxArg_, builder_.getInt32(isRequire ? 1 : 0), textPtr, messagePtr,
                         builder_.getInt32(static_cast<int32_t>(stmt->line))});
    // Same top-level-only loopSignal_ signal as StmtKind::Return above - a
    // failed top-level require/ensure must also stop the rest of the script.
    if (!inUserFunctionBody_)
      builder_.CreateCall(signalTopLevelReturnFn(), {ctxArg_});
    if (!currentFunctionEpilogue_) {
      // Shouldn't happen - compileStatements()/FunctionDecl always set one,
      // same guarantee StmtKind::Return relies on.
      ok_ = false;
      return;
    }
    builder_.CreateBr(currentFunctionEpilogue_);

    builder_.SetInsertPoint(okBB);
    return;
  }

  case StmtKind::ClearMemory: {
    builder_.CreateCall(clearMemoryFn(), {ctxArg_});
    return;
  }

  default:
    ok_ = false;
    return;
  }
}

void CodeGen::compileClassConstructor(const Stmt *classDecl, const Stmt *ctorStmt) {
  unsigned paramCount = static_cast<unsigned>(ctorStmt->inputNames.size());
  // Same signature shape as a single-output FunctionDecl, named directly
  // after the class itself (not mangled - a class has exactly one
  // constructor in this slice, no overloading) - matches ExprKind::Call's
  // construction call site, which declares/calls this same symbol name.
  FunctionType *fnTy = userFunctionType(paramCount, 1);
  Function *ctorFn = Function::Create(fnTy, Function::ExternalLinkage, classDecl->name, module_.get());

  BasicBlock *savedInsertBlock = builder_.GetInsertBlock();
  llvm::Argument *savedCtxArg = ctxArg_;
  BasicBlock *savedEpilogue = currentFunctionEpilogue_;
  std::vector<LoopTargets> savedLoopStack = std::move(loopStack_);
  loopStack_.clear();
  bool savedInUserFunctionBody = inUserFunctionBody_;
  inUserFunctionBody_ = true;

  BasicBlock *entryBB = BasicBlock::Create(context_, "entry", ctorFn);
  BasicBlock *epilogueBB = BasicBlock::Create(context_, "epilogue", ctorFn);
  builder_.SetInsertPoint(entryBB);
  ctxArg_ = ctorFn->getArg(0);
  ctxArg_->setName("ctx");

  builder_.CreateCall(pushScopeFn(), {ctxArg_});
  llvm::Value *ctorLoopDepth = emitAnalysisFrameEnter();
  llvm::Value *classNamePtr = builder_.CreateGlobalString(classDecl->name);
  // Mirrors invokeFunctionBody()'s `definingClassName` seeding
  // currentDefiningClass_ for the constructor call's own duration - see
  // nc_bridge_push_defining_class's comment. Popped in the epilogue below.
  builder_.CreateCall(pushDefiningClassFn(), {ctxArg_, classNamePtr});

  // Seed a fresh object instance as `base`, BEFORE binding parameters -
  // mirrors callClassConstructor()'s `freshInstance` (parser_class.cpp).
  llvm::Value *freshInstance = newValueSlot();
  builder_.CreateCall(valueSetObjectFn(), {freshInstance, classNamePtr});
  llvm::Value *baseNamePtr = builder_.CreateGlobalString(std::string("base"));
  builder_.CreateCall(varWriteFn(), {ctxArg_, baseNamePtr, builder_.getInt32(-1), freshInstance});
  destroyValueSlot(freshInstance);

  for (unsigned i = 0; i < paramCount; ++i) {
    llvm::Value *paramArg = ctorFn->getArg(1 + i);
    paramArg->setName(ctorStmt->inputNames[i]);
    llvm::Value *namePtr = builder_.CreateGlobalString(ctorStmt->inputNames[i]);
    builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, builder_.getInt32(-1), paramArg});
  }

  currentFunctionEpilogue_ = epilogueBB;
  codegenStmtList(ctorStmt->body);
  ensureTerminator(epilogueBB);

  builder_.SetInsertPoint(epilogueBB);
  emitAnalysisFrameExit(ctorLoopDepth); // a `return` from inside a loop
  // The constructed instance is whatever `base` holds afterward - not a
  // named output (a constructor declares none) - mirrors
  // callClassConstructor() reading outScope["base"] back out.
  llvm::Value *outBaseNamePtr = builder_.CreateGlobalString(std::string("base"));
  llvm::Value *outArgPtr = ctorFn->getArg(1 + paramCount);
  builder_.CreateCall(varReadFn(), {ctxArg_, outBaseNamePtr, builder_.getInt32(-1), outArgPtr});
  builder_.CreateCall(popDefiningClassFn(), {ctxArg_});
  builder_.CreateCall(popScopeFn(), {ctxArg_});
  builder_.CreateRetVoid();

  std::string err;
  llvm::raw_string_ostream os(err);
  if (llvm::verifyFunction(*ctorFn, &os)) {
    llvm::errs() << "CodeGen: function verification failed for constructor '" << classDecl->name
                 << "': " << os.str() << "\n";
    ok_ = false;
  }

  ctxArg_ = savedCtxArg;
  currentFunctionEpilogue_ = savedEpilogue;
  loopStack_ = std::move(savedLoopStack);
  inUserFunctionBody_ = savedInUserFunctionBody;
  builder_.SetInsertPoint(savedInsertBlock);
}

void CodeGen::compileInstanceMethod(const Stmt *classDecl, const Stmt *methodStmt) {
  if (methodStmt->outputNames.size() != 1) {
    // Void / multi-output instance methods are out of scope for this
    // slice - see the class comment's "Classes" section.
    ok_ = false;
    return;
  }
  unsigned paramCount = static_cast<unsigned>(methodStmt->inputNames.size());
  std::string mangledName = classDecl->name + "__" + methodStmt->name;
  FunctionType *fnTy = instanceMethodType(paramCount);
  Function *methodFn = Function::Create(fnTy, Function::ExternalLinkage, mangledName, module_.get());

  instanceMethods_[methodStmt->name] = {mangledName, paramCount};
  newlyDefinedMethods_.emplace_back(methodStmt->name, mangledName, paramCount);

  BasicBlock *savedInsertBlock = builder_.GetInsertBlock();
  llvm::Argument *savedCtxArg = ctxArg_;
  BasicBlock *savedEpilogue = currentFunctionEpilogue_;
  std::vector<LoopTargets> savedLoopStack = std::move(loopStack_);
  loopStack_.clear();
  bool savedInUserFunctionBody = inUserFunctionBody_;
  inUserFunctionBody_ = true;

  BasicBlock *entryBB = BasicBlock::Create(context_, "entry", methodFn);
  BasicBlock *epilogueBB = BasicBlock::Create(context_, "epilogue", methodFn);
  builder_.SetInsertPoint(entryBB);
  ctxArg_ = methodFn->getArg(0);
  ctxArg_->setName("ctx");

  builder_.CreateCall(pushScopeFn(), {ctxArg_});
  llvm::Value *methodLoopDepth = emitAnalysisFrameEnter();
  // Mirrors invokeFunctionBody()'s `definingClassName` seeding
  // currentDefiningClass_ for this method call's own duration - see
  // nc_bridge_push_defining_class's comment. Popped in the epilogue below.
  llvm::Value *methodClassNamePtr = builder_.CreateGlobalString(classDecl->name);
  builder_.CreateCall(pushDefiningClassFn(), {ctxArg_, methodClassNamePtr});

  // Bind the receiver (`self`, arg 1) as `base` - mirrors
  // invokeFunctionBody() seeding `base` from selfValue in
  // callInstanceMethod() (parser_class.cpp).
  llvm::Value *selfArg = methodFn->getArg(1);
  llvm::Value *baseNamePtr = builder_.CreateGlobalString(std::string("base"));
  builder_.CreateCall(varWriteFn(), {ctxArg_, baseNamePtr, builder_.getInt32(-1), selfArg});

  for (unsigned i = 0; i < paramCount; ++i) {
    llvm::Value *paramArg = methodFn->getArg(2 + i);
    paramArg->setName(methodStmt->inputNames[i]);
    llvm::Value *namePtr = builder_.CreateGlobalString(methodStmt->inputNames[i]);
    builder_.CreateCall(varWriteFn(), {ctxArg_, namePtr, builder_.getInt32(-1), paramArg});
  }

  currentFunctionEpilogue_ = epilogueBB;
  codegenStmtList(methodStmt->body);
  ensureTerminator(epilogueBB);

  builder_.SetInsertPoint(epilogueBB);
  emitAnalysisFrameExit(methodLoopDepth); // a `return` from inside a loop
  // Same order as evaluateExpr()'s MethodCall case: the (possibly field-
  // mutated) receiver is read back first, then the declared output -
  // both still live in the scope about to be popped.
  llvm::Value *outBaseNamePtr = builder_.CreateGlobalString(std::string("base"));
  llvm::Value *selfOutArgPtr = methodFn->getArg(2 + paramCount);
  builder_.CreateCall(varReadFn(), {ctxArg_, outBaseNamePtr, builder_.getInt32(-1), selfOutArgPtr});

  // Declared-output read uses nc_bridge_read_declared_output (not
  // varReadFn like `base` above) - see its comment and FunctionDecl's own
  // epilogue for why; `methodName` here (not the mangled symbol name) is
  // what callInstanceMethod()'s own "not assigned in method '<name>'"
  // error uses (parser_class.cpp).
  llvm::Value *outNamePtr = builder_.CreateGlobalString(methodStmt->outputNames[0]);
  llvm::Value *methodNamePtr = builder_.CreateGlobalString(methodStmt->name);
  llvm::Value *methodOutArgPtr = methodFn->getArg(2 + paramCount + 1);
  builder_.CreateCall(readDeclaredOutputFn(),
                       {ctxArg_, outNamePtr, methodNamePtr, builder_.getInt32(1), methodOutArgPtr});

  builder_.CreateCall(popDefiningClassFn(), {ctxArg_});
  builder_.CreateCall(popScopeFn(), {ctxArg_});
  builder_.CreateRetVoid();

  std::string err;
  llvm::raw_string_ostream os(err);
  if (llvm::verifyFunction(*methodFn, &os)) {
    llvm::errs() << "CodeGen: function verification failed for method '" << mangledName
                 << "': " << os.str() << "\n";
    ok_ = false;
  }

  ctxArg_ = savedCtxArg;
  currentFunctionEpilogue_ = savedEpilogue;
  loopStack_ = std::move(savedLoopStack);
  inUserFunctionBody_ = savedInUserFunctionBody;
  builder_.SetInsertPoint(savedInsertBlock);
}

std::unique_ptr<llvm::Module> CodeGen::compileProgram(const Program &prog,
                                                        const std::string &entryName) {
  std::vector<const Stmt *> stmts;
  stmts.reserve(prog.statements.size());
  for (const auto &stmt : prog.statements)
    stmts.push_back(stmt.get());
  return compileStatements(stmts, entryName);
}

std::unique_ptr<llvm::Module> CodeGen::compileStatements(const std::vector<const Stmt *> &stmts,
                                                           const std::string &entryName) {
  FunctionType *fnTy = FunctionType::get(Type::getVoidTy(context_), {ptrTy()}, false);
  Function *fn = Function::Create(fnTy, Function::ExternalLinkage, entryName, module_.get());
  ctxArg_ = fn->getArg(0);
  ctxArg_->setName("ctx");

  BasicBlock *bb = BasicBlock::Create(context_, "entry", fn);
  // The top-level entry function gets an epilogue too, exactly like a
  // compiled FunctionDecl's own body does (see StmtKind::FunctionDecl) -
  // so a bare top-level `return;` (valid in the tree-walker - see
  // Parser::consumeTopLevelStopSignal()'s own doc comment) works the same
  // way, a `br` to here, rather than needing separate handling.
  BasicBlock *epilogueBB = BasicBlock::Create(context_, "epilogue", fn);
  builder_.SetInsertPoint(bb);
  currentFunctionEpilogue_ = epilogueBB;

  // Mirrors executeStmt()'s own `evaluationSucceeded_ = true;` reset at the
  // top of every TOP-LEVEL statement dispatch (once per compiled entry here,
  // matching runStmt()'s one-statement-per-call granularity) - never
  // repeated inside a compiled FunctionDecl/constructor/method body, which
  // must inherit whatever's already current, exactly like invokeFunctionBody()
  // never resetting it either. See nc_bridge_reset_evaluation_succeeded's
  // comment for why this is needed at all.
  builder_.CreateCall(resetEvaluationSucceededFn(), {ctxArg_});
  llvm::Value *entryLoopDepth = emitAnalysisFrameEnter();

  for (const Stmt *stmt : stmts) {
    codegenStmt(stmt);
    if (builder_.GetInsertBlock()->hasTerminator()) {
      // Same reasoning as codegenStmtList() - a top-level `return;` (or,
      // now that FunctionDecl exists, a top-level statement that happens
      // to end in one, though that shouldn't occur in practice) closes
      // this block; anything after it in `stmts` needs a fresh block to
      // land in rather than corrupting the terminated one. Container
      // shape here (vector<const Stmt*>, not vector<unique_ptr<Stmt>>) is
      // why this isn't just a codegenStmtList() call - see
      // compileStatements()'s own doc comment.
      Function *containingFn = builder_.GetInsertBlock()->getParent();
      BasicBlock *dead = BasicBlock::Create(context_, "dead", containingFn);
      builder_.SetInsertPoint(dead);
    }
  }

  ensureTerminator(epilogueBB);
  builder_.SetInsertPoint(epilogueBB);
  emitAnalysisFrameExit(entryLoopDepth); // a top-level `return;` inside a loop
  builder_.CreateRetVoid();

  std::string err;
  llvm::raw_string_ostream os(err);
  bool broken = llvm::verifyFunction(*fn, &os);
  if (broken) {
    llvm::errs() << "CodeGen: function verification failed for '" << entryName << "': " << os.str() << "\n";
    ok_ = false;
  }

  if (!ok_)
    return nullptr;

  return std::move(module_);
}

void CodeGen::seedKnownFunctions(const std::vector<std::tuple<std::string, unsigned, unsigned>> &known) {
  for (const auto &entry : known)
    functionArity_[std::get<0>(entry)] = {std::get<1>(entry), std::get<2>(entry)};
}

void CodeGen::seedKnownClasses(const std::vector<std::tuple<std::string, unsigned>> &known) {
  for (const auto &entry : known)
    classCtorArity_[std::get<0>(entry)] = std::get<1>(entry);
}

void CodeGen::seedKnownMethods(const std::vector<std::tuple<std::string, std::string, unsigned>> &known) {
  for (const auto &entry : known)
    instanceMethods_[std::get<0>(entry)] = {std::get<1>(entry), std::get<2>(entry)};
}

void CodeGen::seedMethodNameOwnership(const std::unordered_map<std::string, std::string> &owners,
                                       const std::unordered_set<std::string> &ambiguousNames) {
  methodNameOwners_ = owners;
  ambiguousMethodNames_ = ambiguousNames;
}

void CodeGen::registerMethodNamesForCollisionCheck(const Stmt *classDecl) {
  for (const auto &m : classDecl->methods) {
    if (m->name == "base")
      continue; // the constructor - never dispatched via MethodCall/instanceMethods_
    auto it = methodNameOwners_.find(m->name);
    if (it == methodNameOwners_.end()) {
      methodNameOwners_[m->name] = classDecl->name;
    } else if (it->second != classDecl->name) {
      ambiguousMethodNames_.insert(m->name);
    }
  }
}
