#include <filesystem>
#include <iostream>
#include <sstream>
#include <string>

#include "core/ScriptManager/SM_main.h"
#include "core/line_continuation.h"
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "../../runtime/data/DataEngine.h"
#include "../../runtime/execution/Interrupt.h"

#ifdef NC_HAS_JIT
#include "codegen/jit_engine.h"
#endif

static std::string normalizeInput(const std::string &raw)
{
  size_t start = 0;
  size_t end = raw.size();
  while (start < end && std::isspace(static_cast<unsigned char>(raw[start])))
    ++start;
  while (end > start && std::isspace(static_cast<unsigned char>(raw[end - 1])))
    --end;
  std::string s = raw.substr(start, end - start);
  bool looksLikeWindowsDrive =
      (s.size() >= 2 && std::isalpha(static_cast<unsigned char>(s[0])) &&
       s[1] == ':');
  bool surroundedByQuotes =
      (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                         (s.front() == '\'' && s.back() == '\'')));
  if (surroundedByQuotes)
  {
    if (!looksLikeWindowsDrive || (s.size() >= 3))
      s = s.substr(1, s.size() - 2);
  }
  return s;
}

static std::string stripQuotes(std::string s)
{
  if (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                        (s.front() == '\'' && s.back() == '\'')))
  {
    return s.substr(1, s.size() - 2);
  }
  return s;
}

void showSuggestions(const std::string &input) { (void)input; }

static bool isEmptyLine(const std::string &s)
{
  return s.find_first_not_of(" \t\r\n") == std::string::npos;
}

static std::string trimSpaces(const std::string &s)
{
  size_t start = s.find_first_not_of(" \t\r\n");
  if (start == std::string::npos)
    return "";
  size_t end = s.find_last_not_of(" \t\r\n");
  return s.substr(start, end - start + 1);
}

int main(int argc, char *argv[])
{
  Parser parser;

  // ---- Data layer + cooperative Stop (runtime/data, runtime/execution) ----
  // NC_SESSION_DIR is set by the IDE: it switches on the JSON workspace
  // channel and the session autosave, and is where the IDE drops
  // interrupt.flag to stop a running command.
  ncdata::DataEngine &dataEngine = ncdata::DataEngine::instance();
  dataEngine.configureFromEnvironment();
  nc::Interrupt::configure(dataEngine.sessionDir().u8string());

#ifdef NC_HAS_JIT
  // JIT dispatch state. On by default (Phase D of the codegen/JIT roadmap -
  // flipped once real corpus testing, not just the parity harness, showed
  // it byte-for-byte matching the tree-walker across every script except
  // two pre-existing, JIT-unrelated dict-iteration-order-nondeterminism
  // cases). The tree-walker is still the correct baseline and the
  // guaranteed fallback for anything JIT can't handle (per-statement,
  // automatic) or anything it gets wrong - toggle back with "@cmd jit off"
  // at any time; "@cmd jit on" re-enables it.
  bool jitEnabled = true;
  std::unique_ptr<JitEngine> jitEngine = std::make_unique<JitEngine>();
#endif
  std::filesystem::path launchWorkingDirectory =
      std::filesystem::current_path();
  std::filesystem::path applicationDirectory;
  if (argc > 0 && argv[0] != nullptr)
  {
    std::filesystem::path executablePath =
        std::filesystem::absolute(argv[0]).lexically_normal();
    applicationDirectory = executablePath.parent_path();
  }

  ScriptManager manager(applicationDirectory, launchWorkingDirectory);
  manager.init();
  // A script run by name works on this REPL's workspace directly (it used
  // to go through variables.txt).
  manager.setWorkspaceParser(&parser);

  // The IDE restarting nc.exe (Stop that had to kill, a removed path
  // folder, a crash) asks for the previous workspace back with NC_RESTORE=1.
  dataEngine.restoreSessionIfRequested(parser.memory, parser.insertionOrder);
#ifdef NC_HAS_JIT
  // Script-by-name execution (ScriptManager::executeFile()) picks up the
  // same default-on state as the REPL loop below - see setJitEngine()'s
  // own comment.
  manager.setJitEngine(jitEnabled, jitEngine.get());
#endif

  if (argc > 1)
  {
    std::ostringstream argBuilder;
    for (int i = 1; i < argc; ++i)
    {
      if (i > 1)
        argBuilder << ' ';
      argBuilder << argv[i];
    }
    std::string rawArg = argBuilder.str();
    if (manager.tryExecuteInputAsFile(rawArg))
    {
      return 0;
    }
    std::cerr << "Error: Failed to execute file: " << rawArg << std::endl;
    return 1;
  }

  std::cin.clear();

  // ---- Multi-line construct buffering ----
  // The REPL reads one line at a time from stdin, but an if/for/while/
  // function/class can span many lines/prompts. Rather than the Parser
  // itself tracking "which raw-text block am I accumulating" (the old
  // pendingXBlock_/inXBlock_ state machine, retired along with
  // ScriptManager's own equivalent in SM_stage_02.cpp - see parseProgram()/
  // parseStmtNode() in parser_program.cpp), this loop only needs to decide
  // *when* a complete statement's text has been typed. Once it has, the
  // whole thing is lexed and parsed as one token stream via
  // parser.parseStmtNode() - exactly like every other statement, whether
  // it came from a file or the REPL - which is what actually handles
  // nested if/for/while and elseif/else (no special-casing needed for
  // those here: they're just more lines of body text until the construct's
  // own terminator keyword appears).
  enum class ReplBlockKind { None, If, For, While, Function, Class };
  ReplBlockKind replMode = ReplBlockKind::None;
  std::string replBuffer;
  // Same-type nesting depth: a nested if/for/while shares its terminator
  // keyword with the outer one, so a flat "first terminator wins" scan
  // would stop the outer construct's text capture at the inner one's
  // terminator. Function/class don't need this - they can't nest.
  int replIfDepth = 0;
  int replForDepth = 0;
  int replWhileDepth = 0;

  auto toLowerStr = [](std::string s) {
    for (char &ch : s)
      ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    return s;
  };

  // Lexes and runs one complete statement's worth of accumulated text as a
  // single top-level unit - the REPL's equivalent of one Program statement.
  auto runReplStatement = [&](const std::string &text)
  {
    Lexer lex(text);
    auto toks = lex.tokenize();
    parser.setTokens(toks);
    auto stmt = parser.parseStmtNode();
    if (stmt)
    {
      bool jitRan = false;
#ifdef NC_HAS_JIT
      // Step-into pausing (pauseForStep(), parser_exec_stmt.cpp) only exists
      // in the tree-walking evaluator - codegen's own For/While handling
      // (codegen.cpp) has no pause hook, so a JIT'd loop would silently run
      // to completion and skip every @STEPAT. Force the tree-walker while a
      // step-into session is armed.
      if (jitEnabled && jitEngine && !parser.isDebugStepMode())
        jitRan = jitEngine->runStmt(stmt.get(), parser);
#endif
      if (!jitRan)
        parser.executeStmt(stmt.get());
    }
    parser.consumeTopLevelStopSignal();
  };

  while (true)
  {
    // ---- Between commands: the only moment the workspace is complete ----
    if (nc::Interrupt::requested())
    {
      std::cout << "Execution interrupted by user." << std::endl;
      parser.setDebugStepMode(false);
    }
    // A stop request belongs to the command it interrupted; clear it (and
    // any flag file left behind) before the next one. A flag the IDE
    // creates after this point is for the command about to be read.
    nc::Interrupt::clear();
    // The IDE's variable list: one @WS line when anything changed. Not
    // while a multi-line construct is still being typed (nothing ran).
    if (replMode == ReplBlockKind::None)
      dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder());

    std::string input;
    std::cout << ">> " << std::flush;
    if (!std::getline(std::cin, input))
    {
      std::cout << "\n";
      break;
    }
    input = readLogicalLine(std::cin, input);
    if (isEmptyLine(input))
      continue;
    std::string trimmedInput = normalizeInput(input);
    if (trimmedInput.empty())
      continue;

    // --------- Already inside a multi-line construct ---------
    if (replMode != ReplBlockKind::None)
    {
      replBuffer += input;
      replBuffer += "\n";
      std::string lower = toLowerStr(trimmedInput);

      switch (replMode)
      {
      case ReplBlockKind::If:
      {
        bool isNestedIfHeader = lower.rfind("if", 0) == 0 &&
            (lower.size() == 2 || std::isspace((unsigned char)lower[2]) || lower[2] == '(');
        if (isNestedIfHeader)
          replIfDepth++;
        else if (Parser::isIfTerm(lower))
        {
          if (replIfDepth > 0)
            replIfDepth--;
          else
          {
            runReplStatement(replBuffer);
            replMode = ReplBlockKind::None;
            replBuffer.clear();
          }
        }
        break;
      }
      case ReplBlockKind::For:
      {
        bool isNestedForHeader = lower.rfind("for", 0) == 0 &&
            (lower.size() == 3 || std::isspace((unsigned char)lower[3]));
        if (isNestedForHeader)
          replForDepth++;
        else if (Parser::isForTerm(lower))
        {
          if (replForDepth > 0)
            replForDepth--;
          else
          {
            runReplStatement(replBuffer);
            replMode = ReplBlockKind::None;
            replBuffer.clear();
          }
        }
        break;
      }
      case ReplBlockKind::While:
      {
        bool isNestedWhileHeader = lower.rfind("while", 0) == 0 &&
            (lower.size() == 5 || std::isspace((unsigned char)lower[5]) || lower[5] == '(');
        if (isNestedWhileHeader)
          replWhileDepth++;
        else if (Parser::isWhileTerm(lower))
        {
          if (replWhileDepth > 0)
            replWhileDepth--;
          else
          {
            runReplStatement(replBuffer);
            replMode = ReplBlockKind::None;
            replBuffer.clear();
          }
        }
        break;
      }
      case ReplBlockKind::Function:
        if (Parser::isFunctionTerm(lower))
        {
          runReplStatement(replBuffer);
          replMode = ReplBlockKind::None;
          replBuffer.clear();
        }
        break;
      case ReplBlockKind::Class:
        if (Parser::isClassTerm(lower))
        {
          runReplStatement(replBuffer);
          replMode = ReplBlockKind::None;
          replBuffer.clear();
        }
        break;
      case ReplBlockKind::None:
        break; // unreachable (outer if excludes this)
      }
      continue;
    }

    // --------- Internal command isolation (IDE hook) ---------
    // IDE sends commands using: @cmd setpwd "..."
    if (trimmedInput.rfind("@cmd ", 0) == 0)
    {
      std::string cmd = trimmedInput.substr(5);
      if (cmd.rfind("setpwd ", 0) == 0)
      {
        std::string path = cmd.substr(7);
        path = stripQuotes(path);
        manager.setWorkspaceDirectory(std::filesystem::u8path(path));
        // Relative save_workspace()/load_workspace() paths follow it.
        dataEngine.setCurrentFolder(std::filesystem::u8path(path));
      }
      // ============================================================
      // Workspace channel (runtime/data/WS_PROTOCOL.md).
      //   wsnow (old name: syncws) - send @WS now, changed or not.
      //   getvar <name>            - send @VAR with that variable's full
      //                              value.
      //   clearvar <name>          - remove one global variable (the
      //                              IDE's "clear name").
      // ============================================================
      else if (cmd == "wsnow" || cmd == "syncws")
      {
        dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder(),
                                          /*force=*/true);
      }
      else if (cmd.rfind("getvar ", 0) == 0)
      {
        dataEngine.emitVariable(stripQuotes(trimSpaces(cmd.substr(7))), parser.globalMemory());
      }
      else if (cmd.rfind("clearvar ", 0) == 0)
      {
        parser.removeGlobalVariable(stripQuotes(trimSpaces(cmd.substr(9))));
      }
#ifdef NC_HAS_JIT
      // ============================================================
      // JIT dispatch toggle. On by default (see jitEnabled's own comment
      // above) - the tree-walker remains the always-correct fallback. JIT
      // is strictly an accelerant: either fully applied per statement or
      // not applied at all, never partially. Unsupported statements fall
      // back silently.
      // ============================================================
      else if (cmd == "jit on")
      {
        jitEnabled = true;
        // Script-by-name execution (ScriptManager::executeFile(), a
        // completely separate code path from this REPL loop) has no way to
        // type "@cmd jit on" itself - keep it in sync with this same
        // session-wide toggle instead of leaving it permanently off. See
        // SM_main.h's setJitEngine() comment.
        manager.setJitEngine(jitEnabled, jitEngine.get());
        std::cout << "JIT dispatch enabled." << std::endl;
      }
      else if (cmd == "jit off")
      {
        jitEnabled = false;
        manager.setJitEngine(jitEnabled, jitEngine.get());
        std::cout << "JIT dispatch disabled." << std::endl;
      }
      else if (cmd == "jit status")
      {
        std::cout << "JIT dispatch: " << (jitEnabled ? "on" : "off") << std::endl;
      }
#endif
      // ============================================================
      // NEW (Step feature): completion sentinel. The Java IDE sends this
      // as the line immediately after a "step unit"'s real content; since
      // stdin is a single ordered stream consumed by this one loop, this
      // marker can only reach stdout after everything sent before it has
      // actually finished executing. Java's stdout reader watches for
      // "@STEPMARK <token>" to know precisely when that step is done.
      // ============================================================
      else if (cmd.rfind("stepmark ", 0) == 0)
      {
        std::string token = cmd.substr(9);
        while (!token.empty() && std::isspace(static_cast<unsigned char>(token.back())))
          token.pop_back();
        std::cout << "@STEPMARK " << token << std::endl;
      }
      // ============================================================
      // NEW (Step-into feature): the Java IDE sends "@cmd stepinto"
      // immediately before a block Unit's source lines (a for/while/if/
      // function/class header + body). It arms debugStepMode_ on the one
      // persistent `parser` instance, so executeStmtList() (parser_exec_
      // stmt.cpp) pauses after each statement it executes - including each
      // loop iteration - printing "@STEPAT <line>" and blocking on stdin
      // for "@cmd stepnext"/"@cmd stepdone" (see pauseForStep() there).
      // "@cmd stepdone" here (sent when idle, not while paused) is a plain
      // safety valve to force pausing back off if the IDE ever needs to.
      // ============================================================
      else if (cmd == "stepinto")
      {
        parser.setDebugStepMode(true);
      }
      else if (cmd == "stepdone")
      {
        parser.setDebugStepMode(false);
      }
      continue;
    }

    // --------- Builtins / interpreter commands ---------
    if (trimmedInput == "exit")
      break;
    // clear: empty the workspace. clear <name>: remove one variable.
    // cls / clc: screen only - nothing to do here (the IDE clears its own
    // screen and never sends these).
    if (trimmedInput == "clear")
    {
      parser.clearGlobalWorkspace();
      continue;
    }
    if (trimmedInput.rfind("clear ", 0) == 0)
    {
      std::string name = stripQuotes(trimSpaces(trimmedInput.substr(6)));
      if (!name.empty() && name.back() == ';')
        name = trimSpaces(name.substr(0, name.size() - 1));
      if (!parser.removeGlobalVariable(name))
        std::cerr << "clear: '" << name << "' is not in the workspace." << std::endl;
      continue;
    }
    if (trimmedInput == "cls" || trimmedInput == "clc")
      continue;
    if (trimmedInput.rfind("addpath ", 0) == 0)
    {
      std::string path = trimmedInput.substr(8);
      path = stripQuotes(path);
      manager.addPath(path);
      continue;
    }
    if (trimmedInput.rfind("rmpath ", 0) == 0)
    {
      std::string path = trimmedInput.substr(7);
      path = stripQuotes(path);
      manager.removePath(path);
      continue;
    }
    if (trimmedInput == "rehash" || trimmedInput == "reindex")
    {
      manager.rehash();
      std::cout << "Rehashed script cache\n";
      continue;
    }
    if (trimmedInput == "path")
    {
      manager.printPath();
      continue;
    }
    if (trimmedInput == "pwd")
    {
      manager.printPwd();
      continue;
    }
    if (trimmedInput.rfind("whichall ", 0) == 0)
    {
      manager.whichAll(trimmedInput.substr(9));
      continue;
    }
    if (trimmedInput.rfind("which ", 0) == 0)
    {
      std::string argument = trimmedInput.substr(6);
      if (argument.rfind("-all ", 0) == 0)
        manager.whichAll(argument.substr(5));
      else
        manager.which(argument);
      continue;
    }

    // --------- Script name execution by workspace search ---------
    // The script shares this REPL's workspace (ScriptManager::
    // setWorkspaceParser above): its variables are simply here afterwards.
    if (manager.tryExecuteInputAsFile(trimmedInput))
      continue;

    // --------- Normal expression execution / multi-line construct entry ---------
    showSuggestions(input);
    Lexer lexer(trimmedInput);
    auto tokens = lexer.tokenize();
    if (tokens.empty() || tokens[0].type == END)
      continue; // comment-only line - nothing to do

    // A line starting with one of these opens a construct that (almost
    // always) spans further lines/prompts - buffer it instead of trying to
    // parse it as one complete statement right away. The header line's
    // full text still needs to end up in the buffer (parseIfStmtNode() etc.
    // parse header and body from one continuous token stream), so it's
    // added here exactly like every subsequent line is added above.
    TokenType first = tokens[0].type;
    if (first == IF || first == FOR || first == WHILE || first == FUNCTION ||
        first == CLASS || first == ABSTRACT || first == REVERSIBLE)
    {
      replBuffer = input;
      replBuffer += "\n";
      if (first == IF) { replMode = ReplBlockKind::If; replIfDepth = 0; }
      else if (first == FOR) { replMode = ReplBlockKind::For; replForDepth = 0; }
      else if (first == WHILE) { replMode = ReplBlockKind::While; replWhileDepth = 0; }
      else if (first == FUNCTION) { replMode = ReplBlockKind::Function; }
      else { replMode = ReplBlockKind::Class; }
      continue;
    }

    parser.setTokens(tokens);
    auto stmt = parser.parseStmtNode();
    if (stmt)
    {
      bool jitRan = false;
#ifdef NC_HAS_JIT
      if (jitEnabled && jitEngine && !parser.isDebugStepMode())
        jitRan = jitEngine->runStmt(stmt.get(), parser);
#endif
      if (!jitRan)
        parser.executeStmt(stmt.get());
    }
    // The IDE hears about the updated workspace from the @WS line sent just
    // before the next prompt (top of this loop).
    parser.consumeTopLevelStopSignal();
  }
  return 0;
}
