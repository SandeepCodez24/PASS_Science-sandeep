#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "core/ScriptManager/SM_main.h"
#include "core/function_files.h"
#include "process_runner.h"
#include "core/line_continuation.h"
#include "core/output.h"
#include "core/error_lines.h"
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "../../runtime/data/DataEngine.h"
#include "../../runtime/data/DataSupport/JsonWriter.h"
#include "../../runtime/interpreter/Numpy/importing_data/io_ide_api.h"
#include "../../runtime/execution/Interrupt.h"
#include "../../runtime/execution/crash_report.h"
#include "../../runtime/memory/governor.h"
#include "../../runtime/execution/parallel/par.h"
#include "../../runtime/execution/parallel/par_monitor.h"
#include "../../runtime/execution/parallel/sys_cpu.h"
#include "../../runtime/execution/analysis/analysis.h"

#ifdef NC_HAS_JIT
#include "codegen/jit_engine.h"
#endif

// =====================================================================
// IDE prompt protocol (runtime/data/WS_PROTOCOL.md, "Prompt protocol")
// =====================================================================
// Started by the IDE with NC_IDE_PROMPT=1, the interpreter never prints the
// ">> " prompt as text. The IDE paints its own prompt, so a ">> " printed by
// a script can never be mistaken for one. Instead it sends two protocol lines
// (ASCII Record Separator 0x1E, keyword, '\n'), which the IDE takes out of the
// output stream before anything is shown:
//
//   @PROMPT        the REPL is back at the top of its loop, about to read a
//                  line. Sent once per line read, internal commands included.
//   @READY <id>    answer to "@cmd ready <id>". Since stdin is one ordered
//                  stream, it can only be written after everything sent before
//                  it has finished; the IDE sends one after every command, so
//                  it marks that command's end exactly, however many lines the
//                  command had and whatever it printed.
//
// In a plain terminal (no NC_IDE_PROMPT) the ">> " prompt is printed as
// before.
static bool ideProtocolEnabled()
{
#ifdef _WIN32
  // getenv() is flagged as unsafe by the MSVC runtime (C4996); _dupenv_s()
  // is its safe replacement and hands back a heap copy we must free.
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, "NC_IDE_PROMPT") != 0 || buffer == nullptr)
    return false;
  const bool enabled = std::string(buffer) == "1";
  std::free(buffer);
  return enabled;
#else
  const char *value = std::getenv("NC_IDE_PROMPT");
  return value != nullptr && std::string(value) == "1";
#endif
}

static void emitProtocolLine(const std::string &line)
{
  std::cout << '\x1E' << line << '\n' << std::flush;
}

// "@PROGRESS {"v":1,"type":"progress","label":"for loop (line 3)","done":412,
// "total":1000,"fraction":0.412}" - the progress of a Command Window command
// (nc::par progress sink, "@cmd progress on", 2026-11-21). Interpreter
// thread; at most ten lines a second.
static void commandProgressLine(void *, const char *label, size_t done, size_t total)
{
  ncdata::JsonWriter j;
  j.beginObject();
  j.key("v").integer(1);
  j.key("type").string("progress");
  j.key("label").string(label ? label : "");
  j.key("done").unsignedInteger(done);
  j.key("total").unsignedInteger(total);
  j.key("fraction").number(total ? static_cast<double>(done) / static_cast<double>(total) : 1.0);
  j.endObject();
  emitProtocolLine("@PROGRESS " + j.str());
}

static std::string normalizeInput(const std::string &raw)
{
  size_t start = 0;
  size_t end = raw.size();
  while (start < end && std::isspace(static_cast<unsigned char>(raw[start])))
    ++start;
  while (end > start && std::isspace(static_cast<unsigned char>(raw[end - 1])))
    --end;
  std::string s = raw.substr(start, end - start);
  bool looksLikeWindowsDrive =
      (s.size() >= 2 && std::isalpha(static_cast<unsigned char>(s[0])) &&
       s[1] == ':');
  bool surroundedByQuotes =
      (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                         (s.front() == '\'' && s.back() == '\'')));
  if (surroundedByQuotes)
  {
    if (!looksLikeWindowsDrive || (s.size() >= 3))
      s = s.substr(1, s.size() - 2);
  }
  return s;
}

static std::string stripQuotes(std::string s)
{
  if (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                        (s.front() == '\'' && s.back() == '\'')))
  {
    return s.substr(1, s.size() - 2);
  }
  return s;
}

void showSuggestions(const std::string &input) { (void)input; }

static bool isEmptyLine(const std::string &s)
{
  return s.find_first_not_of(" \t\r\n") == std::string::npos;
}

static std::string trimSpaces(const std::string &s)
{
  size_t start = s.find_first_not_of(" \t\r\n");
  if (start == std::string::npos)
    return "";
  size_t end = s.find_last_not_of(" \t\r\n");
  return s.substr(start, end - start + 1);
}

int main(int argc, char *argv[])
{
  // Multicore runtime: thread count (NC_THREADS), backend, and this thread
  // becomes "the interpreter thread" (runtime/execution/parallel/par.h).
  nc::par::initialize();
  // Big fresh buffers are faulted in on several cores (memory/governor.h).
  nc::mem::enablePrefault(true);
  // Count error lines on stderr - an error stops the script (error_lines.h).
  nc::errorlines::install();
  Parser parser;
  const bool ideProtocol = ideProtocolEnabled();

  // ---- Data layer + cooperative Stop (runtime/data, runtime/execution) ----
  // NC_SESSION_DIR is set by the IDE: it switches on the JSON workspace
  // channel and the session autosave, and is where the IDE drops
  // interrupt.flag to stop a running command.
  ncdata::DataEngine &dataEngine = ncdata::DataEngine::instance();
  dataEngine.configureFromEnvironment();
  nc::Interrupt::configure(dataEngine.sessionDir().u8string());
  // A crash says why: stderr, an @FATAL line, <session>/fatal.json
  // (runtime/execution/crash_report.h).
  nc::crash::install(dataEngine.sessionDir().u8string(), ideProtocol);
  // The disk tier's files go to the session folder (else the temp folder).
  if (!dataEngine.sessionDir().empty())
    nc::mem::setSpillDir(dataEngine.sessionDir().u8string());
  // The IDE's CPU core / thread monitor: available in IDE mode only, and
  // idle until the IDE sends "@cmd parmon on" (par_monitor.h).
  nc::par::monitor::configure(dataEngine.sessionDir().u8string());
  // Its memory strip shows the governor's numbers (Phase 5,
  // docs/Large_Data_Design.md section 20).
  nc::par::monitor::setMemorySource([](nc::par::monitor::MemoryReading &out) {
    const nc::mem::Budget b = nc::mem::budget();
    if (!b.known)
      return false;
    nc::par::sys::MemoryInfo info;
    out.peak = nc::par::sys::memoryInfo(info) ? info.peak : 0;
    out.used = b.used;
    out.available = b.available;
    out.total = b.effective;
    out.budget = b.cap;
    out.percent = b.percent;
    out.enforced = b.enforced;
    out.diskUsed = nc::mem::spillBytes();
    out.diskRoom = nc::mem::spillRoom();
    return true;
  });
  // The IDE's Analysis box (No. of Computation / Execution Time): IDE mode
  // only, idle until "@cmd analysis computations on" or "... time on".
  nc::analysis::configure(dataEngine.sessionDir().u8string());
  bool commandRunning = false; // for the monitor's command brackets

#ifdef NC_HAS_JIT
  // JIT dispatch state. On by default (Phase D of the codegen/JIT roadmap -
  // flipped once real corpus testing, not just the parity harness, showed
  // it byte-for-byte matching the tree-walker across every script except
  // two pre-existing, JIT-unrelated dict-iteration-order-nondeterminism
  // cases). The tree-walker is still the correct baseline and the
  // guaranteed fallback for anything JIT can't handle (per-statement,
  // automatic) or anything it gets wrong - toggle back with "@cmd jit off"
  // at any time; "@cmd jit on" re-enables it.
  bool jitEnabled = true;
  std::unique_ptr<JitEngine> jitEngine = std::make_unique<JitEngine>();
#endif
  std::filesystem::path launchWorkingDirectory =
      std::filesystem::current_path();
  std::filesystem::path applicationDirectory;
  if (argc > 0 && argv[0] != nullptr)
  {
    std::filesystem::path executablePath =
        std::filesystem::absolute(argv[0]).lexically_normal();
    applicationDirectory = executablePath.parent_path();
  }

  ScriptManager manager(applicationDirectory, launchWorkingDirectory);
  manager.init();
  // A script run by name works on this REPL's workspace directly (it used
  // to go through variables.txt).
  manager.setWorkspaceParser(&parser);
  // Function files (<name>.nc called as name(...)): the running script's
  // folder, the current folder and the addpath folders, then the personal
  // library (core/function_files.h).
  nc::fnfiles::setFolderProvider([&manager]() { return manager.functionSearchFolders(); });

  // The IDE restarting nc.exe (Stop that had to kill, a removed path
  // folder, a crash) asks for the previous workspace back with NC_RESTORE=1.
  dataEngine.restoreSessionIfRequested(parser.memory, parser.insertionOrder);
#ifdef NC_HAS_JIT
  // Script-by-name execution (ScriptManager::executeFile()) picks up the
  // same default-on state as the REPL loop below - see setJitEngine()'s
  // own comment.
  manager.setJitEngine(jitEnabled, jitEngine.get());
#endif

  if (argc > 1)
  {
    std::ostringstream argBuilder;
    for (int i = 1; i < argc; ++i)
    {
      if (i > 1)
        argBuilder << ' ';
      argBuilder << argv[i];
    }
    std::string rawArg = argBuilder.str();
    if (manager.tryExecuteInputAsFile(rawArg))
    {
      // 1 when the script was refused for syntax errors or stopped on an
      // error (2026-11-18 - it used to be 0 either way).
      return nc::errorlines::scriptFailed() ? 1 : 0;
    }
    std::cerr << "Error: Failed to execute file: " << rawArg << std::endl;
    return 1;
  }

  std::cin.clear();

  // IDE mode: what this nc.exe is, before the first prompt (2026-11-20,
  // docs/Java_Speed_CPP_Asks.md V2) - the build, and the capabilities the
  // IDE may use without probing ("getvar-window": windowed getvar;
  // "process-progress": "step_progress" events from op:"process";
  // "command-progress": "@cmd progress on" gives @PROGRESS lines).
  if (dataEngine.ideMode())
    dataEngine.emitHello(nc::par::buildType());

  // ---- Multi-line construct buffering ----
  // The REPL reads one line at a time from stdin, but an if/for/while/
  // function/class can span many lines/prompts. Rather than the Parser
  // itself tracking "which raw-text block am I accumulating" (the old
  // pendingXBlock_/inXBlock_ state machine, retired along with
  // ScriptManager's own equivalent in SM_stage_02.cpp - see parseProgram()/
  // parseStmtNode() in parser_program.cpp), this loop only needs to decide
  // *when* a complete statement's text has been typed. Once it has, the
  // whole thing is lexed and parsed as one token stream via
  // parser.parseStmtNode() - exactly like every other statement, whether
  // it came from a file or the REPL - which is what actually handles
  // nested if/for/while and elseif/else (no special-casing needed for
  // those here: they're just more lines of body text until the construct's
  // own terminator keyword appears).
  enum class ReplBlockKind { None, If, For, While, Function, Class, Try };
  ReplBlockKind replMode = ReplBlockKind::None;
  std::string replBuffer;
  // Same-type nesting depth: a nested if/for/while shares its terminator
  // keyword with the outer one, so a flat "first terminator wins" scan
  // would stop the outer construct's text capture at the inner one's
  // terminator. Function/class don't need this - they can't nest.
  int replIfDepth = 0;
  int replForDepth = 0;
  int replWhileDepth = 0;
  int replTryDepth = 0; // try: ... tend (2026-11-09)

  auto discardReplBlock = [&]()
  {
    replMode = ReplBlockKind::None;
    replBuffer.clear();
    replIfDepth = 0;
    replForDepth = 0;
    replWhileDepth = 0;
    replTryDepth = 0;
  };

  // `try:` opening a line (`try` is a context word: only with its ':').
  auto isTryHeaderLine = [](const std::string &lower)
  {
    if (lower.rfind("try", 0) != 0)
      return false;
    size_t i = 3;
    while (i < lower.size() && (lower[i] == ' ' || lower[i] == '\t'))
      i++;
    return i < lower.size() && lower[i] == ':';
  };

  auto toLowerStr = [](std::string s) {
    for (char &ch : s)
      ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    return s;
  };

  // Runs EVERY statement in one lexed line / block, in order:
  // `A[1,2] = 99; A[2,1] = 99;` is two statements. (Before 2026-10 only the
  // first statement of a line ran - everything after its ';' was silently
  // dropped.) Stops early on a top-level `return;`, a failed require/ensure,
  // an error (Parser::errorAbort_), or Stop.
  //
  // The whole command is parsed first: one with a syntax error does not run
  // at all - not even the statements before the bad one (`a = 1; b = (2;`
  // assigns nothing), the same rule a script follows. Parsing has no side
  // effects, and a function's body is copied when it is registered, so the
  // Program can go once the command has run.
  auto runAllStatements = [&](const std::vector<Token> &toks)
  {
    // Function files saved or changed since the last command are read
    // again on their next call (Parser::refreshFunctionFiles()).
    parser.refreshFunctionFiles();
    const int errsBefore = parser.syntaxErrorCount_;
    Program program = parser.parseProgram(toks);
    if (parser.syntaxErrorCount_ != errsBefore)
      return;
    if (parser.checkExceptTypes(program) > 0) // unknown type after `except`
      return;
    parser.clearErrorAbort();
    size_t position = 0;
    for (const auto &stmtPtr : program.statements)
    {
      Stmt *stmt = stmtPtr.get();
      const unsigned long errorsBefore = nc::errorlines::count();
      // Statement history of the Analysis box (level 0: typed at the prompt).
      nc::analysis::TopLevelScope analysisScope(0, static_cast<int>(stmt->line), stmtKindName(stmt->kind),
                                                position++, program.statements.size());
      {
        bool jitRan = false;
#ifdef NC_HAS_JIT
        // Step-into pausing (pauseForStep(), parser_exec_stmt.cpp) only exists
        // in the tree-walking evaluator - codegen's own For/While handling
        // (codegen.cpp) has no pause hook, so a JIT'd loop would silently run
        // to completion and skip every @STEPAT. Force the tree-walker while a
        // step-into session is armed.
        //
        // A bare expression whose value is displayed (`3 + 4`, `x`, `f(2)`
        // with no semicolon) also goes to the tree-walker: its MATLAB-style
        // "ans =" display lives in executeStmt(), and an expression costs
        // nothing to interpret. Loops, functions, classes and assignments
        // still take the JIT.
        //
        // The Analysis toggles (No. of Computation / Execution Time) no
        // longer force the tree-walker (2026-11-09): compiled code calls the
        // same hooks - statement count, loop begin / iteration / end, the
        // computations of each operator (value_bridge.h, "Multicore and
        // Analysis rules for compiled code"). Both paths reach the same
        // callBuiltin() kernels, so multicore (nc::par) and the CPU monitor
        // work identically either way.
        const bool displaysAns =
            stmt->kind == StmtKind::ExprStmt && !stmt->suppressOutput;
        if (jitEnabled && jitEngine && !parser.isDebugStepMode() && !displaysAns) {
          jitRan = jitEngine->runStmt(stmt, parser);
          // executeStmt() counts a declaration it runs here; compiled code
          // leaves that one count to its caller (codegen.cpp's codegenStmt).
          if (jitRan && (stmt->kind == StmtKind::FunctionDecl || stmt->kind == StmtKind::ClassDecl))
            nc::analysis::statement();
        }
#endif
        if (!jitRan)
          parser.executeStmt(stmt);
      }
      parser.noteStatementResult(stmt->line, errorsBefore);
      const bool failed = parser.errorAbort_;
      parser.clearErrorAbort();
      // The IDE hears about the updated workspace from the @WS line sent
      // just before the next prompt (top of the REPL loop).
      if (parser.consumeTopLevelStopSignal() || failed || nc::Interrupt::requested())
        break;
    }
  };

  // Lexes and runs one complete multi-line construct's accumulated text.
  auto runReplStatement = [&](const std::string &text)
  {
    Lexer lex(text);
    auto toks = lex.tokenize();
    // A lexical error ("unexpected character") is a syntax error too: the
    // construct does not run, as with any other syntax error.
    if (lex.errorCount() > 0)
      return;
    runAllStatements(toks);
  };

  while (true)
  {
    // ---- Between commands: the only moment the workspace is complete ----
    // A multi-line construct (for ... fend) is one command: it ends when the
    // construct is complete and has run, not after each of its lines.
    if (commandRunning && replMode == ReplBlockKind::None)
    {
      nc::par::monitor::commandFinished();
      nc::analysis::commandFinished(nc::Interrupt::requested());
      commandRunning = false;
    }
    if (nc::Interrupt::requested())
    {
      std::cout << "Execution interrupted by user." << std::endl;
      parser.setDebugStepMode(false);
    }
    // A stop request belongs to the command it interrupted; clear it (and
    // any flag file left behind) before the next one. A flag the IDE
    // creates after this point is for the command about to be read.
    nc::Interrupt::clear();
    // The IDE's variable list: one @WS line when anything changed. Not
    // while a multi-line construct is still being typed (nothing ran).
    if (replMode == ReplBlockKind::None)
      dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder());
    // The CPU monitor's summary of the command that just ended: one
    // "@PARMON" line, only while the IDE's panel is open and only for a
    // command that used threads or ran for a while (par_monitor.h).
    {
      const std::string summary = nc::par::monitor::takeCommandSummary();
      if (!summary.empty())
        emitProtocolLine("@PARMON " + summary);
      // The Analysis box's summary of the same command (analysis.h).
      const std::string analysis = nc::analysis::takeCommandSummary();
      if (!analysis.empty())
        emitProtocolLine("@ANALYSIS " + analysis);
    }

    // Every command starts a fresh display group: its first "name =" block
    // opens with a blank line under the echoed command (MATLAB loose).
    resetDisplaySpacing();

    std::string input;
    if (ideProtocol)
      emitProtocolLine("@PROMPT");
    else
      std::cout << ">> " << std::flush;
    if (!std::getline(std::cin, input))
    {
      if (!ideProtocol)
        std::cout << "\n";
      break;
    }
    input = readLogicalLine(std::cin, input);
    if (isEmptyLine(input))
      continue;
    std::string trimmedInput = normalizeInput(input);
    if (trimmedInput.empty())
      continue;

    // --------- Internal command isolation (IDE hook) ---------
    // Handled BEFORE the multi-line buffer below: an IDE command is never
    // part of a block, and appending one to a half-read block (the old
    // order) corrupted the block and swallowed the command.
    // IDE sends commands using: @cmd setpwd "..."
    if (trimmedInput.rfind("@cmd ", 0) == 0)
    {
      std::string cmd = trimmedInput.substr(5);
      if (cmd.rfind("setpwd ", 0) == 0)
      {
        std::string path = cmd.substr(7);
        path = stripQuotes(path);
        manager.setWorkspaceDirectory(std::filesystem::u8path(path));
        // Relative save_workspace()/load_workspace() paths follow it.
        dataEngine.setCurrentFolder(std::filesystem::u8path(path));
      }
      // ============================================================
      // Command Window width: "@cmd width <characters>". A matrix wider
      // than this is printed in column groups ("Columns 0 through 12"),
      // the way MATLAB does (output.cpp, matrixGrid()). The IDE should
      // send it once at start-up and again whenever the Command Window is
      // resized: visible width in pixels / width of one character of its
      // monospace font. Without it the width is NC_DISPLAY_WIDTH, or 80.
      // ============================================================
      else if (cmd.rfind("width ", 0) == 0)
      {
        const long width = std::strtol(trimSpaces(cmd.substr(6)).c_str(), nullptr, 10);
        if (width > 0)
          setDisplayWidth(static_cast<size_t>(width));
      }
      // ============================================================
      // Prompt protocol: the end of a command. The IDE sends
      // "@cmd ready <id>" after every command's lines; reading it means
      // everything before it has run, so the answer marks the command's
      // end exactly. If a multi-line construct is still open here, the
      // IDE thought the input complete and this loop did not (a header
      // without its terminator, say): the construct can never finish, so
      // it is dropped with an error instead of waiting for ever.
      // ============================================================
      else if (cmd == "ready" || cmd.rfind("ready ", 0) == 0)
      {
        if (replMode != ReplBlockKind::None)
        {
          std::cout << "Error: the multi-line construct was not complete and has been discarded."
                    << std::endl;
          discardReplBlock();
        }
        std::string token = cmd.size() > 5 ? trimSpaces(cmd.substr(5)) : std::string();
        emitProtocolLine(token.empty() ? std::string("@READY") : "@READY " + token);
      }
      // ============================================================
      // Workspace channel (runtime/data/WS_PROTOCOL.md).
      //   wsnow (old name: syncws) - send @WS now, changed or not.
      //   getvar <name>            - send @VAR with that variable's full
      //                              value.
      //   clearvar <name>          - remove one global variable (the
      //                              IDE's "clear name").
      // ============================================================
      else if (cmd == "wsnow" || cmd == "syncws")
      {
        dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder(),
                                          /*force=*/true);
      }
      else if (cmd.rfind("getvar ", 0) == 0)
      {
        // "getvar <name> <r0> <r1> <c0> <c1> [<p0> ...]" is a window
        // (V1): a name never contains a space, so the one-token form keeps
        // its meaning. Numbers: 0-based, end exclusive, page keys last.
        const std::string rest = trimSpaces(cmd.substr(7));
        std::vector<std::string> tokens;
        {
          std::istringstream split(rest);
          std::string token;
          while (split >> token)
            tokens.push_back(token);
        }
        std::vector<std::size_t> numbers;
        bool allNumbers = tokens.size() >= 5;
        for (size_t i = 1; allNumbers && i < tokens.size(); i++)
        {
          const std::string &t = tokens[i];
          if (t.empty() || t.find_first_not_of("0123456789") != std::string::npos || t.size() > 19)
            allNumbers = false;
          else
            numbers.push_back(static_cast<std::size_t>(std::strtoull(t.c_str(), nullptr, 10)));
        }
        if (allNumbers)
        {
          std::vector<std::size_t> page(numbers.begin() + 4, numbers.end());
          dataEngine.emitVariableWindow(stripQuotes(tokens[0]), parser.globalMemory(), numbers[0],
                                        numbers[1], numbers[2], numbers[3], page);
        }
        else
        {
          dataEngine.emitVariable(stripQuotes(rest), parser.globalMemory());
        }
      }
      else if (cmd.rfind("clearvar ", 0) == 0)
      {
        parser.removeGlobalVariable(stripQuotes(trimSpaces(cmd.substr(9))));
      }
      // ============================================================
      // Import / Process / Export windows: "@cmd io <json>"
      // (Numpy/importing_data/io_ide_api.h,
      // docs/Import_Window.md). Answers with one
      // "@IO" line. A "run" request is executed here exactly like a typed
      // command, then the workspace (@WS) and the run's @IO answer follow.
      // ============================================================
      else if (cmd.rfind("io ", 0) == 0)
      {
        nc::io::ide::RunRequest run;
        nc::io::ide::handleCommand(cmd.substr(3), parser.globalMemory(), run);
        if (!run.kind.empty())
        {
          // op:"process" / op:"check" - the Process Data window
          // (process_runner.h). A run that made its output variable shows it
          // in the Variable Explorer straight away.
          parser.refreshFunctionFiles();
          nc::process::handleRequest(parser, run.kind, run.id, run.json);
          dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder());
        }
        else if (!run.code.empty())
        {
          nc::io::ide::RunScope scope(run);
          runReplStatement(run.code);
          dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder());
          scope.finish(parser.globalMemory());
        }
      }
#ifdef NC_HAS_JIT
      // ============================================================
      // JIT dispatch toggle. On by default (see jitEnabled's own comment
      // above) - the tree-walker remains the always-correct fallback. JIT
      // is strictly an accelerant: either fully applied per statement or
      // not applied at all, never partially. Unsupported statements fall
      // back silently.
      // ============================================================
      else if (cmd == "jit on")
      {
        jitEnabled = true;
        // Script-by-name execution (ScriptManager::executeFile(), a
        // completely separate code path from this REPL loop) has no way to
        // type "@cmd jit on" itself - keep it in sync with this same
        // session-wide toggle instead of leaving it permanently off. See
        // SM_main.h's setJitEngine() comment.
        manager.setJitEngine(jitEnabled, jitEngine.get());
        std::cout << "JIT dispatch enabled." << std::endl;
      }
      else if (cmd == "jit off")
      {
        jitEnabled = false;
        manager.setJitEngine(jitEnabled, jitEngine.get());
        std::cout << "JIT dispatch disabled." << std::endl;
      }
      else if (cmd == "jit status")
      {
        std::cout << "JIT dispatch: " << (jitEnabled ? "on" : "off") << std::endl;
      }
#endif
      // ============================================================
      // Step feature: completion sentinel (kept for older IDEs; the
      // prompt protocol's "@cmd ready" does the same job now).
      // ============================================================
      else if (cmd.rfind("stepmark ", 0) == 0)
      {
        std::string token = cmd.substr(9);
        while (!token.empty() && std::isspace(static_cast<unsigned char>(token.back())))
          token.pop_back();
        std::cout << "@STEPMARK " << token << std::endl;
      }
      // ============================================================
      // Step-into feature: the Java IDE sends "@cmd stepinto"
      // immediately before a block Unit's source lines (a for/while/if/
      // function/class header + body). It arms debugStepMode_ on the one
      // persistent `parser` instance, so executeStmtList() (parser_exec_
      // stmt.cpp) pauses after each statement it executes - including each
      // loop iteration - printing "@STEPAT <line>" and blocking on stdin
      // for "@cmd stepnext"/"@cmd stepdone" (see pauseForStep() there).
      // "@cmd stepdone" here (sent when idle, not while paused) is a plain
      // safety valve to force pausing back off if the IDE ever needs to.
      // ============================================================
      else if (cmd == "stepinto")
      {
        parser.setDebugStepMode(true);
      }
      else if (cmd == "stepdone")
      {
        parser.setDebugStepMode(false);
      }
      // ============================================================
      // CPU core / thread monitor (runtime/execution/parallel/
      // par_monitor.h, docs/Parallel_Monitor_Java_Handover.md).
      //   parmon on | off        the IDE's panel opened / closed
      //   parmon interval <ms>   live snapshot period, 100..5000 (250)
      //   parmon snapshot        one "@PARMON" snapshot line now
      // ============================================================
      else if (cmd == "parmon on")
      {
        nc::par::monitor::setEnabled(true);
      }
      else if (cmd == "parmon off")
      {
        nc::par::monitor::setEnabled(false);
      }
      else if (cmd.rfind("parmon interval ", 0) == 0)
      {
        const long ms = std::strtol(trimSpaces(cmd.substr(16)).c_str(), nullptr, 10);
        if (ms > 0)
          nc::par::monitor::setIntervalMs(static_cast<int>(ms));
      }
      else if (cmd == "parmon snapshot")
      {
        emitProtocolLine("@PARMON " + nc::par::monitor::snapshotNow());
      }
      // ============================================================
      // Analysis box (runtime/execution/analysis/analysis.h,
      // docs/Analysis_Section_Java_Handover.md).
      //   analysis computations on | off   "No. of Computation" toggle
      //   analysis time on | off           "Execution Time" toggle
      //   analysis interval <ms>           live file period, 250..5000 (1000)
      // ============================================================
      else if (cmd == "analysis computations on" || cmd == "analysis computations off")
      {
        nc::analysis::setComputationsEnabled(cmd.back() == 'n');
      }
      else if (cmd == "analysis time on" || cmd == "analysis time off")
      {
        nc::analysis::setTimingEnabled(cmd.back() == 'n');
      }
      else if (cmd.rfind("analysis interval ", 0) == 0)
      {
        const long ms = std::strtol(trimSpaces(cmd.substr(18)).c_str(), nullptr, 10);
        if (ms > 0)
          nc::analysis::setIntervalMs(static_cast<int>(ms));
      }
      // ============================================================
      // Progress of Command Window commands (2026-11-21): "@cmd progress
      // on" makes long work report "@PROGRESS {json}" lines - a script's
      // for loops, multicore kernels, long serial loops (nc::par progress
      // sink). Off at startup; the Process / Import / Export windows
      // report through their own @IOEV events whatever this says.
      // ============================================================
      else if (cmd == "progress on" || cmd == "progress off")
      {
        nc::par::setProgressSink(cmd == "progress on" ? &commandProgressLine : nullptr, nullptr);
      }
      continue;
    }

    // A real command (or one line of a multi-line construct) starts here:
    // the CPU monitor samples only between this and the next prompt.
    if (!commandRunning)
    {
      nc::par::monitor::commandStarted();
      nc::analysis::commandStarted();
      nc::par::loopResetForCommand();
      resetBuiltinStatusFlags(); // a JIT-run command starts clean too
      commandRunning = true;
    }
    nc::crash::noteCommand(input); // named in a crash report, if one comes

    // --------- Already inside a multi-line construct ---------
    if (replMode != ReplBlockKind::None)
    {
      replBuffer += input;
      replBuffer += "\n";
      std::string lower = toLowerStr(trimmedInput);

      switch (replMode)
      {
      case ReplBlockKind::If:
      {
        bool isNestedIfHeader = lower.rfind("if", 0) == 0 &&
            (lower.size() == 2 || std::isspace((unsigned char)lower[2]) || lower[2] == '(');
        if (isNestedIfHeader)
          replIfDepth++;
        else if (Parser::isIfTerm(lower))
        {
          if (replIfDepth > 0)
            replIfDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      }
      case ReplBlockKind::For:
      {
        bool isNestedForHeader = lower.rfind("for", 0) == 0 &&
            (lower.size() == 3 || std::isspace((unsigned char)lower[3]));
        if (isNestedForHeader)
          replForDepth++;
        else if (Parser::isForTerm(lower))
        {
          if (replForDepth > 0)
            replForDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      }
      case ReplBlockKind::While:
      {
        bool isNestedWhileHeader = lower.rfind("while", 0) == 0 &&
            (lower.size() == 5 || std::isspace((unsigned char)lower[5]) || lower[5] == '(');
        if (isNestedWhileHeader)
          replWhileDepth++;
        else if (Parser::isWhileTerm(lower))
        {
          if (replWhileDepth > 0)
            replWhileDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      }
      case ReplBlockKind::Function:
        if (Parser::isFunctionTerm(lower))
        {
          std::string block = replBuffer;
          discardReplBlock();
          runReplStatement(block);
        }
        break;
      case ReplBlockKind::Class:
        if (Parser::isClassTerm(lower))
        {
          std::string block = replBuffer;
          discardReplBlock();
          runReplStatement(block);
        }
        break;
      case ReplBlockKind::Try:
        if (isTryHeaderLine(lower))
          replTryDepth++;
        else if (Parser::isTryTerm(lower))
        {
          if (replTryDepth > 0)
            replTryDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      case ReplBlockKind::None:
        break; // unreachable (outer if excludes this)
      }
      continue;
    }

    // --------- Builtins / interpreter commands ---------
    if (trimmedInput == "exit")
      break;
    // clear: empty the workspace. clear <name>: remove one variable.
    // cls / clc: screen only - nothing to do here (the IDE clears its own
    // screen and never sends these).
    if (trimmedInput == "clear")
    {
      parser.clearGlobalWorkspace();
      continue;
    }
    if (trimmedInput.rfind("clear ", 0) == 0)
    {
      std::string name = stripQuotes(trimSpaces(trimmedInput.substr(6)));
      if (!name.empty() && name.back() == ';')
        name = trimSpaces(name.substr(0, name.size() - 1));
      if (!parser.removeGlobalVariable(name))
        std::cerr << "clear: '" << name << "' is not in the workspace." << std::endl;
      continue;
    }
    if (trimmedInput == "cls" || trimmedInput == "clc")
      continue;
    if (trimmedInput.rfind("addpath ", 0) == 0)
    {
      std::string path = trimmedInput.substr(8);
      path = stripQuotes(path);
      manager.addPath(path);
      continue;
    }
    if (trimmedInput.rfind("rmpath ", 0) == 0)
    {
      std::string path = trimmedInput.substr(7);
      path = stripQuotes(path);
      manager.removePath(path);
      continue;
    }
    if (trimmedInput == "rehash" || trimmedInput == "reindex")
    {
      manager.rehash();
      std::cout << "Rehashed script cache\n";
      continue;
    }
    if (trimmedInput == "path")
    {
      manager.printPath();
      continue;
    }
    if (trimmedInput == "pwd")
    {
      manager.printPwd();
      continue;
    }
    if (trimmedInput.rfind("whichall ", 0) == 0)
    {
      manager.whichAll(trimmedInput.substr(9));
      continue;
    }
    if (trimmedInput.rfind("which ", 0) == 0)
    {
      std::string argument = trimmedInput.substr(6);
      if (argument.rfind("-all ", 0) == 0)
        manager.whichAll(argument.substr(5));
      else
        manager.which(argument);
      continue;
    }

    // --------- Script name execution by workspace search ---------
    // The script shares this REPL's workspace (ScriptManager::
    // setWorkspaceParser above): its variables are simply here afterwards.
    if (manager.tryExecuteInputAsFile(trimmedInput))
      continue;

    // --------- Normal expression execution / multi-line construct entry ---------
    showSuggestions(input);
    Lexer lexer(trimmedInput);
    auto tokens = lexer.tokenize();
    if (tokens.empty() || tokens[0].type == END)
      continue; // comment-only line - nothing to do

    // A line starting with one of these opens a construct that (almost
    // always) spans further lines/prompts - buffer it instead of trying to
    // parse it as one complete statement right away. The header line's
    // full text still needs to end up in the buffer (parseIfStmtNode() etc.
    // parse header and body from one continuous token stream), so it's
    // added here exactly like every subsequent line is added above.
    TokenType first = tokens[0].type;
    if (first == IF || first == FOR || first == WHILE || first == FUNCTION ||
        first == CLASS || first == ABSTRACT || first == REVERSIBLE)
    {
      replBuffer = input;
      replBuffer += "\n";
      if (first == IF) { replMode = ReplBlockKind::If; replIfDepth = 0; }
      else if (first == FOR) { replMode = ReplBlockKind::For; replForDepth = 0; }
      else if (first == WHILE) { replMode = ReplBlockKind::While; replWhileDepth = 0; }
      else if (first == FUNCTION) { replMode = ReplBlockKind::Function; }
      else { replMode = ReplBlockKind::Class; }
      continue;
    }
    // try: ... tend - `try` is a name token, so it is recognised by its ':'.
    if (first == IDENT && tokens[0].text == "try" && tokens.size() > 1 && tokens[1].type == COLON)
    {
      replBuffer = input;
      replBuffer += "\n";
      replMode = ReplBlockKind::Try;
      replTryDepth = 0;
      continue;
    }

    if (lexer.errorCount() > 0)
      continue; // a lexical error (already reported): the command does not run
    runAllStatements(tokens);
  }
  return 0;
}
