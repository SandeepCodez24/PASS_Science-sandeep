// Small free helper shared by the dict-key assignment/read paths
// (parser_exec_stmt.cpp, parser_factor.cpp). The old per-line statement
// dispatcher that used to live in this file (parseStatement()) was retired
// once both ScriptManager::executeFile() and main.cpp's REPL moved to the
// real recursive-descent parser (parser_program.cpp) and tree-walking
// evaluator (parser_exec_stmt.cpp) - see docs/AST.txt.
#include "parser.h"
#include "parser_internal.h"

#include "output.h"

// Dict keys are always stored/looked-up as strings: text values use their
// text as-is, numeric values are formatted the same way printed output is.
std::string dictKeyOf(const Value &key) {
  return key.isText ? key.text() : formatNumber(key.number);
}
