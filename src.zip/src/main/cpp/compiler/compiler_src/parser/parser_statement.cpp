// Statement dispatch: what a single top-level line does (if/for/while
// header capture, new/clear, print/publish, assignment incl. dict-key
// assignment, and the fallback expression-statement / `ans` update).
#include "parser.h"
#include "parser_internal.h"

#include <cctype>
#include <fstream>
#include <iostream>

#include "output.h"

// Dict keys are always stored/looked-up as strings: text values use their
// text as-is, numeric values are formatted the same way printed output is.
std::string dictKeyOf(const Value &key) {
  return key.isText ? key.text : formatNumber(key.number);
}

/* ================= STATEMENT ================= */

Value Parser::parseStatement() {
  // MATLAB-style gating for ans auto-display/update.
  // Must become false on any evaluation error.
  evaluationSucceeded_ = true;

  /* ================= IF ================= */

  if (current().type == IF || current().type == ELSEIF) {
    advance(); // consume IF/ELSEIF

    bool negate = false;
    if (current().type == IDENT) {
      std::string t = current().text;
      for (char &ch : t) ch = static_cast<char>(std::tolower((unsigned char)ch));
      if (t == "not") {
        negate = true;
        advance();
      }
    }

    Value cond = parseOr();
    bool condBool = false;
    if (cond.isText) condBool = !cond.text.empty();
    else condBool = (cond.number != 0.0);
    if (negate) condBool = !condBool;

    ifConditionResult_ = condBool;
    inIfBlock_ = true;
    inElseBranch_ = false;
    pendingIfTrueBlock_.clear();
    pendingIfFalseBlock_.clear();

    if (current().type == SEMICOLON)
      advance();

    return Value(0);
  }

  /* ================= FOR ================= */

  if (current().type == FOR) {
    // Reconstruct the header line from the remaining tokens
    forHeader_.clear();
    for (size_t i = pos; i < tokens.size(); i++) {
      if (tokens[i].type == END) break;
      if (i > pos) forHeader_ += " ";
      forHeader_ += tokens[i].text;
    }
    inForBlock_ = true;
    pendingForBlock_.clear();
    return Value(0);
  }

  /* ================= WHILE ================= */

  if (current().type == WHILE) {
    whileHeader_.clear();
    for (size_t i = pos; i < tokens.size(); i++) {
      if (tokens[i].type == END) break;
      if (i > pos) whileHeader_ += " ";
      whileHeader_ += tokens[i].text;
    }
    inWhileBlock_ = true;
    pendingWhileBlock_.clear();
    return Value(0);
  }

  /* ================= BREAK / CONTINUE ================= */

  if (current().type == BREAK || current().type == CONTINUE) {
    bool isBreak = (current().type == BREAK);
    advance();

    if (current().type == SEMICOLON)
      advance();

    if (loopDepth_ <= 0) {
      std::cerr << "Error: '" << (isBreak ? "break" : "continue")
                << "' used outside of a loop\n";
      evaluationSucceeded_ = false;
    } else {
      loopSignal_ = isBreak ? LoopSignal::Break : LoopSignal::Continue;
    }

    return Value(0);
  }

  /* ================= RETURN ================= */

  if (current().type == RETURN) {
    advance();

    if (current().type == SEMICOLON)
      advance();

    // Valid anywhere (top-level script or function body) — inside a
    // function it's consumed by the call boundary; at true top level it
    // just stops the rest of that file's execution, same as MATLAB scripts.
    loopSignal_ = LoopSignal::Return;

    return Value(0);
  }

  /* ================= REQUIRE / ENSURE ================= */

  if (current().type == REQUIRE || current().type == ENSURE) {
    bool isRequire = (current().type == REQUIRE);
    advance();

    // Capture the condition's raw source text before consuming it, purely
    // for a readable contract-violation message.
    std::string condText;
    for (size_t i = pos; i < tokens.size(); i++) {
      if (tokens[i].type == SEMICOLON || tokens[i].type == END) break;
      if (i > pos) condText += " ";
      condText += tokens[i].text;
    }

    Value cond = parseOr();

    if (current().type == SEMICOLON)
      advance();

    if (!evaluationSucceeded_) {
      // The condition expression itself failed to evaluate (e.g. an
      // unknown variable) — that error already printed; this isn't a
      // genuine contract violation, so don't also claim it is.
      return Value(0);
    }

    bool condBool = cond.isText ? !cond.text.empty() : (cond.number != 0.0);
    if (!condBool) {
      std::cerr << "Error: " << (isRequire ? "precondition" : "postcondition")
                << " failed: " << condText << "\n";
      evaluationSucceeded_ = false;
      // Abort here exactly like an early `return;` — reuses the same
      // signal/propagation machinery (executeBlockLines stops the current
      // block, executeForBlock/executeWhileBlock stop their loop without
      // clearing it, invokeFunctionBody consumes it at the call boundary,
      // and a top-level violation stops the script via
      // consumeTopLevelStopSignal()). A violated contract means this code
      // path is broken; there's nothing sensible left to keep running.
      loopSignal_ = LoopSignal::Return;
    }

    return Value(0);
  }

  /* ================= FUNCTION ================= */

  if (current().type == FUNCTION) {
    // Reconstruct the header line from the remaining tokens, exactly like
    // FOR/WHILE below — re-lexed and parsed later by executeFunctionDefEnd()
    // when 'fnend' closes the block.
    functionHeader_.clear();
    for (size_t i = pos; i < tokens.size(); i++) {
      if (tokens[i].type == END) break;
      if (i > pos) functionHeader_ += " ";
      functionHeader_ += tokens[i].text;
    }
    inFunctionBlock_ = true;
    pendingFunctionBlock_.clear();
    return Value(0);
  }

  /* ================= CLASS (and ABSTRACT/REVERSIBLE CLASS) ================= */

  if (current().type == CLASS || current().type == ABSTRACT || current().type == REVERSIBLE) {
    // Same header-reconstruction technique as FUNCTION above — re-lexed and
    // parsed later by executeClassDefEnd() when 'csend' closes the block.
    classHeader_.clear();
    for (size_t i = pos; i < tokens.size(); i++) {
      if (tokens[i].type == END) break;
      if (i > pos) classHeader_ += " ";
      classHeader_ += tokens[i].text;
    }
    inClassBlock_ = true;
    pendingClassBlock_.clear();
    return Value(0);
  }

  /* ================= NEW ================= */

  if (current().type == IDENT && current().text == "new") {
    advance();

    memory.clear();
    insertionOrder.clear();

    std::ofstream file("variables.txt", std::ios::trunc);
    file << "NAME        TYPE        VALUE\n";
    file << "-----------------------------------------\n";

    return Value(0);
  }

  /* ================= CLEAR ================= */

  if (current().type == IDENT && current().text == "clear") {
    advance();

    memory.clear();
    insertionOrder.clear();

    std::ofstream file("variables.txt", std::ios::trunc);
    file << "NAME        TYPE        VALUE\n";
    file << "-----------------------------------------\n";

    if (current().type == SEMICOLON)
      advance();

    return Value(0);
  }

  /* ================= PRINT / PUBLISH ================= */

  if (current().type == PRINT || current().type == PUBLISH) {
    advance();

    if (current().type != LPAREN) {
      std::cerr << "Error: expected '(' after print/publish\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    advance(); // (

    std::vector<Value> args;
    args.push_back(parseOr());
    while (current().type == COMMA) {
      advance();
      args.push_back(parseOr());
    }

    if (current().type == RPAREN)
      advance();
    else {
      std::cerr << "Error: expected ')' after print/publish\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    // print/publish always display output and ignore semicolon
    if (current().type == SEMICOLON)
      advance();

    if (evaluationSucceeded_) {
      for (size_t i = 0; i < args.size(); i++) {
        const Value &v = args[i];
        if (v.isText)
          std::cout << "\"" << v.text << "\"";
        else
          std::cout << valueToString(v);
        if (i + 1 < args.size())
          std::cout << " ";
      }
      std::cout << std::endl;
    }

    // Rule: print/publish do NOT update ans.
    return Value(0);
  }

  /* ================= ASSIGNMENT ================= */

  if (current().type == IDENT) {
    std::string name = current().text;
    size_t identPos = pos;
    advance();

    /* dict key assignment: A['key'] = value  or  A['k1','k2'] = [v1,v2] */
    if (current().type == LBRACKET) {
      advance(); // consume '['

      std::vector<Value> keys;
      keys.push_back(parseOr());
      while (current().type == COMMA) {
        advance();
        keys.push_back(parseOr());
      }

      bool closedOk = (current().type == RBRACKET);
      if (closedOk)
        advance();

      /* matrix element assignment: A[row][col] = value */
      if (closedOk && keys.size() == 1 && current().type == LBRACKET
          && memory.count(name) && memory[name].isMatrix) {
        size_t secondBracketPos = pos;
        advance(); // consume second '['

        Value colKey = parseOr();
        bool colClosedOk = (current().type == RBRACKET);
        if (colClosedOk)
          advance();

        if (colClosedOk && current().type == ASSIGN) {
          advance(); // consume '='

          Value val = parseOr();

          bool hadSemicolon = (current().type == SEMICOLON);
          if (hadSemicolon)
            advance();

          if (evaluationSucceeded_) {
            int row = static_cast<int>(keys[0].number);
            int col = static_cast<int>(colKey.number);

            if (row < 0 || static_cast<size_t>(row) >= memory[name].matrix.size() ||
                col < 0 || static_cast<size_t>(col) >= memory[name].matrix[row].size()) {
              std::cerr << "Error: matrix index out of range for '" << name << "'\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }

            memory[name].matrix[row][col] = val;
            saveToFile();

            if (!memory.count("ans"))
              insertionOrder.push_back("ans");
            memory["ans"] = val;
            saveToFile();

            // Auto-print (no trailing ';') shows the whole updated matrix,
            // not just the assigned element — printing `name = val` here
            // would misleadingly claim the matrix variable itself now
            // equals the scalar RHS.
            if (!hadSemicolon)
              printValue(name, memory[name]);
          }

          return val;
        }

        // Not `A[row][col] = value` after all (e.g. a bare double-index
        // read) — rewind to just past the first ']' so the single-bracket
        // paths below (or the normal expression fallback) can reparse it.
        pos = secondBracketPos;
      }

      if (closedOk && current().type == ASSIGN) {
        advance();

        Value val = parseOr();

        bool hadSemicolon = (current().type == SEMICOLON);
        if (hadSemicolon)
          advance();

        if (evaluationSucceeded_) {
          /* array element assignment: A[i] = value */
          if (memory.count(name) && memory[name].isArray && keys.size() == 1) {
            int idx = static_cast<int>(keys[0].number);
            if (idx < 0 || static_cast<size_t>(idx) >= memory[name].array.size()) {
              std::cerr << "Error: array index out of range for '" << name << "'\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }

            memory[name].array[idx] = val;
            saveToFile();

            if (!memory.count("ans"))
              insertionOrder.push_back("ans");
            memory["ans"] = val;
            saveToFile();

            // Auto-print (no trailing ';') shows the whole updated array,
            // not just the assigned element — see the matching comment on
            // the matrix-element branch above.
            if (!hadSemicolon)
              printValue(name, memory[name]);

            return val;
          }

          if (!memory.count(name)) {
            insertionOrder.push_back(name);
            memory[name] = Value(std::unordered_map<std::string, Value>());
          } else if (!memory[name].isDict) {
            std::cerr << "Error: '" << name << "' is not a dict\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }

          if (keys.size() == 1) {
            memory[name].dictMap[dictKeyOf(keys[0])] = val;
          } else {
            if (!val.isArray || val.array.size() != keys.size()) {
              std::cerr << "Error: multi-key dict assignment expects an array of "
                        << keys.size() << " values\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }
            for (size_t i = 0; i < keys.size(); i++)
              memory[name].dictMap[dictKeyOf(keys[i])] = val.array[i];
          }

          saveToFile();

          if (!memory.count("ans"))
            insertionOrder.push_back("ans");
          memory["ans"] = val;
          saveToFile();

          if (!hadSemicolon)
            printValue(name, val);
        }

        return val;
      }

      // Not a dict-key assignment (e.g. a bare read like `A['key'];`) —
      // rewind fully to the identifier and let the normal expression path
      // (parseFactor's LBRACKET read-index) handle it.
      pos = identPos;
    } else if (current().type == DOT) {
      /* object field assignment: obj.field = value; */
      advance(); // consume '.'

      bool matched = false;
      if (current().type == IDENT) {
        std::string fieldName = current().text;
        advance();

        if (current().type == ASSIGN) {
          matched = true;
          advance();

          Value val = parseOr();

          bool hadSemicolon = (current().type == SEMICOLON);
          if (hadSemicolon)
            advance();

          if (evaluationSucceeded_) {
            if (!memory.count(name)) {
              std::cerr << "Error: '" << name << "' is not defined\n";
              evaluationSucceeded_ = false;
            } else if (!memory[name].isObject) {
              std::cerr << "Error: '" << name << "' is not an object\n";
              evaluationSucceeded_ = false;
            } else if (checkFieldAccess(memory[name].className, fieldName)) {
              memory[name].dictMap[fieldName] = val;

              if (!memory.count("ans"))
                insertionOrder.push_back("ans");
              memory["ans"] = val;
              saveToFile();

              if (!hadSemicolon)
                printValue(name, val);
            }
          }

          return val;
        }
      }

      // Not a field assignment (e.g. `obj.Method(args);` or `obj.field;` —
      // a method call or bare field read) — rewind fully to the identifier
      // and let the normal expression path (parseFactor's DOT handling)
      // take it.
      if (!matched)
        pos = identPos;
    } else if (current().type == ASSIGN) {
      advance();

      Value val = parseOr();

      bool hadSemicolon = (current().type == SEMICOLON);
      if (hadSemicolon) {
        advance();
      }

      if (evaluationSucceeded_) {
        if (!memory.count(name))
          insertionOrder.push_back(name);

        memory[name] = val;
        saveToFile();

        if (!memory.count("ans"))
          insertionOrder.push_back("ans");
        memory["ans"] = val;
        saveToFile();

        if (!hadSemicolon)
          printValue(name, val);
      }

      return val;
    } else {
      pos = identPos; // restore identifier
    }
  }

  /* ================= MULTI-OUTPUT FUNCTION CALL: (B1,B2) = name(args) ================= */

  if (current().type == LPAREN) {
    size_t savedPos = pos;
    advance(); // consume '('

    std::vector<std::string> outNames;
    bool validList = (current().type == IDENT);
    if (validList) {
      outNames.push_back(current().text);
      advance();
      while (current().type == COMMA) {
        advance();
        if (current().type != IDENT) { validList = false; break; }
        outNames.push_back(current().text);
        advance();
      }
    }

    bool matched = false;
    if (validList && current().type == RPAREN) {
      advance(); // ')'
      if (outNames.size() >= 2 && current().type == ASSIGN) {
        advance(); // '='
        if (current().type == IDENT) {
          std::string funcName = current().text;
          advance();
          if (current().type == LPAREN) {
            advance();

            std::vector<Value> args;
            while (current().type != RPAREN && current().type != END) {
              args.push_back(parseOr());
              if (current().type == COMMA)
                advance();
              else
                break;
            }

            if (current().type == RPAREN)
              advance();
            bool hadSemicolon = (current().type == SEMICOLON);
            if (hadSemicolon)
              advance();

            matched = true;

            bool found = false;
            std::vector<Value> results =
                callUserFunctionMulti(funcName, args, outNames.size(), found);

            if (!found) {
              std::cerr << "Error: Unknown function '" << funcName << "'\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }

            if (evaluationSucceeded_) {
              for (size_t k = 0; k < outNames.size() && k < results.size(); k++) {
                if (!memory.count(outNames[k]))
                  insertionOrder.push_back(outNames[k]);
                memory[outNames[k]] = results[k];
              }
              saveToFile();

              if (!hadSemicolon) {
                for (size_t k = 0; k < outNames.size() && k < results.size(); k++)
                  printValue(outNames[k], results[k]);
              }
            }

            return results.empty() ? Value(0) : results[0];
          }
        }
      }
    }

    if (!matched)
      pos = savedPos; // not this shape — rewind and fall through
  }

  /* ================= NORMAL EXPRESSION ================= */

  Value v = parseOr();

  bool hadSemicolon = (current().type == SEMICOLON);
  if (hadSemicolon) {
    advance();
  }

  if (evaluationSucceeded_) {
    if (!memory.count("ans"))
      insertionOrder.push_back("ans");
    memory["ans"] = v;
    saveToFile();

    if (!hadSemicolon)
      printValue("", v);
  }

  return v;
}
