// Expression grammar: the precedence-climbing chain from logical operators
// down to arithmetic (parseFactor, the leaf/base case, lives in
// parser_factor.cpp).
#include "parser.h"

#include <cmath>
#include <iostream>

#include "../conditional_opr/conditional_opr.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/matrix/matrix.h"

/* ================= LOGICAL ================= */

Value Parser::parseOr() {
  Value v = parseAnd();

  while (current().type == OR || current().type == NOR) {
    TokenType op = current().type;
    advance();
    Value r = parseAnd();
    v = (op == OR) ? logical_or(v, r) : logical_nor(v, r);
  }

  return v;
}

Value Parser::parseAnd() {
  Value v = parseComparison();

  while (current().type == AND || current().type == NAND) {
    TokenType op = current().type;
    advance();
    Value r = parseComparison();
    v = (op == AND) ? logical_and(v, r) : logical_nand(v, r);
  }

  return v;
}

Value Parser::parseComparison() {
  Value v = parseExpression();

  while (current().type == EQ || current().type == NEQ ||
         current().type == LT || current().type == GT ||
         current().type == LTE || current().type == GTE ||
         current().type == IS_IN || current().type == IS_NOT_IN) {
    TokenType op = current().type;
    advance();

    Value r = parseExpression();

    // Dimensional Integrity: comparing across incompatible dimensions is as
    // meaningless as adding them. Doesn't apply to is_in/is_not_in (r is a
    // collection there, not a comparable scalar).
    if (op != IS_IN && op != IS_NOT_IN &&
        (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM)) {
      std::cerr << "Error: incompatible units in comparison\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    // Ordering (<, >, <=, >=) is only meaningful for numbers and strings,
    // and only between two values of the same kind. Rejected here rather
    // than inside logical_lt()/etc. for the same reason as the unit check
    // above: only Parser members have evaluationSucceeded_/std::cerr to
    // report it. Previously these fell through to a Value::number
    // comparison, which is 0 for every array/matrix/dict/object and so
    // silently answered "equal" for values that were never comparable.
    // == and != are deliberately NOT restricted - asking whether a string
    // equals a number is a fair question whose answer is simply "no".
    if (op == LT || op == GT || op == LTE || op == GTE) {
      if (!valueIsOrderable(v) || !valueIsOrderable(r) ||
          valueKindOf(v) != valueKindOf(r)) {
        std::cerr << "Error: cannot order-compare " << valueKindName(v)
                  << " with " << valueKindName(r) << "\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
    }

    if (op == EQ)
      v = logical_eq(v, r);
    else if (op == NEQ)
      v = logical_neq(v, r);
    else if (op == LT)
      v = logical_lt(v, r);
    else if (op == GT)
      v = logical_gt(v, r);
    else if (op == LTE)
      v = logical_lte(v, r);
    else if (op == GTE)
      v = logical_gte(v, r);
    else if (op == IS_IN)
      v = logical_is_in(v, r);
    else if (op == IS_NOT_IN)
      v = logical_is_not_in(v, r);
  }

  return v;
}

/* ================= ARITHMETIC ================= */

Value Parser::parseExpression() {
  Value v = parseTerm();

  while (current().type == PLUS || current().type == MINUS) {
    TokenType op = current().type;
    advance();

    Value r = parseTerm();

    // Dimensional Integrity: +/- require the same physical dimension on
    // both sides (m + kg is meaningless) — checked here, not inside
    // add()/sub() (arithmetic.cpp), since only Parser members have
    // evaluationSucceeded_/std::cerr to report it clearly. * and / don't
    // need this check — any two dimensions combine into a valid result, so
    // there's no incompatible case to reject for them.
    if (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM) {
      std::cerr << "Error: incompatible units in '" << (op == PLUS ? "+" : "-") << "'\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    if (op == PLUS)
      v = add(v, r);
    else
      v = sub(v, r);
  }

  return v;
}

Value Parser::parseTerm() {
  Value v = parsePower();

  while (current().type == MUL || current().type == DIV ||
         current().type == MOD || current().type == QUOT ||
         current().type == DOT) {
    TokenType op = current().type;
    advance();

    Value r = parsePower();

    if (op == MUL)
      v = mul(v, r);
    else if (op == DIV)
      v = div_op(v, r);
    else if (op == MOD)
      v = mod_op(v, r);
    else if (op == QUOT) {
      if (r.number == 0)
        v = Value(0);
      else
        v = Value(std::floor(v.number / r.number));
    } else if (op == DOT) {
      // Element-wise matrix operator: M . N
      if (v.isMatrix && r.isMatrix) {
        v = ElementWise(v, r);
      } else {
        std::cerr << "Error: Dot operator requires two matrices\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
    }
  }

  return v;
}

Value Parser::parsePower() {
  Value left = parseFactor();

  if (current().type == POW) {
    advance();

    Value right = parsePower();

    return power(left, right);
  }

  return left;
}
