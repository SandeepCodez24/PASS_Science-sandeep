// Expression grammar: the precedence-climbing chain from logical operators
// down to arithmetic (parseFactor, the leaf/base case, lives in
// parser_factor.cpp).
//
// Phase 2 (AST rewrite roadmap): each parseX() is now a thin "build then
// evaluate immediately" wrapper around a parseXNode() that builds an Expr
// tree (see ast.h) instead of computing a Value inline. Unlike
// parseFactorNode()'s IDENT branch, nothing in this file is context-
// sensitive on operand values - which tokens form an expression is decided
// purely by operator token types, so parseXNode() has zero side effects and
// evaluateBinaryOp()/evaluateComparison()/evaluateLogicalOp() carry
// everything that used to run inline (dimension checks, orderability
// checks, error reporting, applying the operator). parser_factor.cpp's own
// sub-expression calls (function arguments, array elements, range bounds,
// ...) call parseOrNode() here directly, building real subtrees rather than
// evaluating eagerly - see parser_factor.cpp for those call sites.
#include "parser.h"

#include <cmath>
#include <iostream>

#include "../conditional_opr/conditional_opr.h"
#include "../core/elementwise.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/matrix/matrix.h"

namespace {
std::unique_ptr<Expr> makeBinary(ExprKind kind, std::string op,
                                  std::unique_ptr<Expr> left,
                                  std::unique_ptr<Expr> right) {
  auto node = std::make_unique<Expr>();
  node->kind = kind;
  node->text = std::move(op);
  node->children.push_back(std::move(left));
  node->children.push_back(std::move(right));
  return node;
}
} // namespace

/* ================= LOGICAL ================= */

std::unique_ptr<Expr> Parser::parseOrNode() {
  auto left = parseAndNode();

  while (current().type == OR || current().type == NOR) {
    TokenType op = current().type;
    advance();
    auto right = parseAndNode();
    left = makeBinary(ExprKind::LogicalOp, (op == OR) ? "||" : "nor",
                       std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

std::unique_ptr<Expr> Parser::parseAndNode() {
  auto left = parseComparisonNode();

  while (current().type == AND || current().type == NAND) {
    TokenType op = current().type;
    advance();
    auto right = parseComparisonNode();
    left = makeBinary(ExprKind::LogicalOp, (op == AND) ? "&&" : "nand",
                       std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

std::unique_ptr<Expr> Parser::parseComparisonNode() {
  auto left = parseExpressionNode();

  while (current().type == EQ || current().type == NEQ ||
         current().type == LT || current().type == GT ||
         current().type == LTE || current().type == GTE ||
         current().type == IS_IN || current().type == IS_NOT_IN) {
    TokenType op = current().type;
    advance();
    auto right = parseExpressionNode();

    std::string opText;
    switch (op) {
      case EQ: opText = "=="; break;
      case NEQ: opText = "!="; break;
      case LT: opText = "<"; break;
      case GT: opText = ">"; break;
      case LTE: opText = "<="; break;
      case GTE: opText = ">="; break;
      case IS_IN: opText = "is_in"; break;
      case IS_NOT_IN: opText = "is_not_in"; break;
      default: break; // unreachable - op is one of the 8 checked above
    }
    left = makeBinary(ExprKind::Comparison, opText, std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

/* ================= ARITHMETIC ================= */

std::unique_ptr<Expr> Parser::parseExpressionNode() {
  auto left = parseTermNode();

  while (current().type == PLUS || current().type == MINUS) {
    TokenType op = current().type;
    advance();
    auto right = parseTermNode();
    left = makeBinary(ExprKind::BinaryOp, (op == PLUS) ? "+" : "-",
                       std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

std::unique_ptr<Expr> Parser::parseTermNode() {
  auto left = parseUnaryNode();

  while (current().type == MUL || current().type == DIV ||
         current().type == MOD || current().type == QUOT ||
         current().type == DOT) {
    TokenType op = current().type;
    advance();
    auto right = parseUnaryNode();

    std::string opText;
    switch (op) {
      case MUL: opText = "*"; break;
      case DIV: opText = "/"; break;
      case MOD: opText = "%"; break;
      case QUOT: opText = "//"; break;
      case DOT: opText = "."; break; // element-wise matrix operator: M . N
      default: break; // unreachable - op is one of the 5 checked above
    }
    left = makeBinary(ExprKind::BinaryOp, opText, std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

// Prefix +/-, sitting between parseTermNode() and parsePowerNode() so that
// unary minus binds LOOSER than '^': -2^2 must parse as -(2^2) (== -4), not
// (-2)^2 (== 4) - the standard mathematical convention (and Python's,
// MATLAB's, ...). The operand recurses back into parseUnaryNode() rather
// than calling parsePowerNode() directly so a chain like `- -5` or a
// negative exponent's own sign (`2^-3`, via parsePowerNode()'s own call
// into this function below) still works.
std::unique_ptr<Expr> Parser::parseUnaryNode() {
  if (current().type == PLUS) {
    // Unary plus is the identity (+x == x) - just discard it and keep
    // parsing at this same precedence level.
    advance();
    return parseUnaryNode();
  }

  if (current().type == MINUS) {
    advance();
    auto inner = parseUnaryNode();
    if (!inner)
      return nullptr;
    auto node = std::make_unique<Expr>();
    node->kind = ExprKind::UnaryOp;
    node->text = "-";
    node->children.push_back(std::move(inner));
    return node;
  }

  return parsePowerNode();
}

std::unique_ptr<Expr> Parser::parsePowerNode() {
  auto left = parseFactorNode();

  if (current().type == POW) {
    advance();
    // The exponent's own recursion goes through parseUnaryNode(), not
    // parsePowerNode() directly, so a negative exponent (`2^-3`) still
    // parses - right-associative either way (`2^3^2` == `2^(3^2)`), since
    // parseUnaryNode() falls straight through to parsePowerNode() when
    // there's no sign to consume.
    auto right = parseUnaryNode();
    if (!left || !right)
      return nullptr;
    return makeBinary(ExprKind::BinaryOp, "^", std::move(left), std::move(right));
  }

  return left;
}

/* ================= EVALUATION ================= */

Value Parser::evaluateLogicalOp(const Expr *node) {
  Value v = evaluateExpr(node->children[0].get());
  Value r = evaluateExpr(node->children[1].get());
  const std::string &op = node->text;

  if (op == "||") return logical_or(v, r);
  if (op == "nor") return logical_nor(v, r);
  if (op == "&&") return logical_and(v, r);
  return logical_nand(v, r); // "nand"
}

Value Parser::evaluateComparison(const Expr *node) {
  Value v = evaluateExpr(node->children[0].get());
  Value r = evaluateExpr(node->children[1].get());
  return evaluateComparisonValues(node->text, v, r);
}

// Extracted from evaluateComparison() so the codegen/JIT bridge
// (nc_bridge_comparison_checked, codegen_bridge/value_bridge.cpp) can run
// this exact same dimension/orderability-checked logic - byte-identical
// error messages included - against two already-evaluated Values, instead
// of the JIT path silently skipping these checks entirely (found via real
// corpus testing: a JIT-compiled `(5*m) > (3*kg)` used to just return a
// wrong answer with no error at all, since the bridge functions this used
// to call directly - nc_bridge_gt/lt/... - do their own dimsMatch()/
// orderable() checks internally, but the codegen that called them never
// checked or surfaced their failure return code).
Value Parser::evaluateComparisonValues(const std::string &op, Value v, Value r) {
  // Reset before dispatching below - without this, a stale `false` left by
  // an EARLIER, unrelated comparison elsewhere in the script would
  // incorrectly mark this completely valid one as failed too (the exact
  // "stale cross-statement flag leak" class of bug found and fixed in
  // vector.cpp's divergence() earlier this session).
  g_lastConditionalOk = true;

  // Dimensional Integrity: comparing across incompatible dimensions is as
  // meaningless as adding them. Doesn't apply to is_in/is_not_in (r is a
  // collection there, not a comparable scalar).
  if (op != "is_in" && op != "is_not_in" &&
      (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM)) {
    std::cerr << "Error: incompatible units in comparison\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Ordering (<, >, <=, >=) is only meaningful for numbers and strings, and
  // only between two values of the same kind. == and != are deliberately
  // NOT restricted - asking whether a string equals a number is a fair
  // question whose answer is simply "no".
  if (op == "<" || op == ">" || op == "<=" || op == ">=") {
    if (!valueIsOrderable(v) || !valueIsOrderable(r) ||
        valueKindOf(v) != valueKindOf(r)) {
      std::cerr << "Error: cannot order-compare " << valueKindName(v)
                << " with " << valueKindName(r) << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
  }

  Value result;
  if (op == "==") result = logical_eq(v, r);
  else if (op == "!=") result = logical_neq(v, r);
  else if (op == "<") result = logical_lt(v, r);
  else if (op == ">") result = logical_gt(v, r);
  else if (op == "<=") result = logical_lte(v, r);
  else if (op == ">=") result = logical_gte(v, r);
  else if (op == "is_in") result = logical_is_in(v, r);
  else result = logical_is_not_in(v, r); // "is_not_in"

  // g_lastConditionalOk: see conditional_opr.h's own comment - is_in/
  // is_not_in can reject a non-array container (and lt/gt/le/ge can
  // reject a non-orderable/mismatched-kind pair, though the checks just
  // above already filter those out before reaching here) without this
  // function's own dimension/orderability checks having caught it.
  if (!g_lastConditionalOk)
    evaluationSucceeded_ = false;

  return result;
}

Value Parser::evaluateBinaryOp(const Expr *node) {
  Value v = evaluateExpr(node->children[0].get());
  Value r = evaluateExpr(node->children[1].get());
  return evaluateBinaryOpValues(node->text, v, r);
}

// Extracted from evaluateBinaryOp() for the same reason as
// evaluateComparisonValues() above - lets the JIT bridge
// (nc_bridge_binary_op_checked) run the identical text-coercion/dimension-
// checked logic against two already-evaluated Values, instead of silently
// bypassing it (the JIT-path bug this closes: `5*m + 3*kg` or `"a"+"b"`
// used to silently produce a plausible-looking 0 under JIT with no error at
// all, while the tree-walker always correctly rejected them).
Value Parser::evaluateBinaryOpValues(const std::string &op, Value v, Value r) {
  // None of +,-,*,/,%,//,^ have a defined meaning for arbitrary text (NC
  // has no string concatenation/repetition operator) - add/sub/mul/
  // div_op/etc. in arithmetic.cpp don't check isText at all, so a text
  // operand used to silently fall through to reading its .number (0 for
  // any text Value), giving a plausible-looking but meaningless answer
  // instead of an error - e.g. "a"+"b" silently gave 0. Text that's
  // actually a dec2frac()-style "num/denom" fraction (or a plain decimal
  // written as text) is auto-coerced to its numeric value first, so
  // dec2frac(x)+1 or similar just works, the same way Python's Fraction/
  // Julia's Rational stay usable in further math despite printing as
  // text. Genuinely non-numeric text ("a"+"b") is still rejected.
  if (op == "+" || op == "-" || op == "*" || op == "/" || op == "%" ||
      op == "//" || op == "^") {
    bool vOk = true, rOk = true;
    if (v.isText) {
      double d;
      if ((vOk = tryCoerceTextToNumber(v, d)))
        v = Value(d);
    }
    if (r.isText) {
      double d;
      if ((rOk = tryCoerceTextToNumber(r, d)))
        r = Value(d);
    }
    if (!vOk || !rOk) {
      std::cerr << "Error: '" << op << "' has no meaning for text\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
  }

  // add()/sub()/mul()/div_op()/mod_op()/floor_div()/power() all route
  // array/matrix operands through zipElementwise() (elementwise.cpp), which
  // rejects a mismatched shape or an invalid operand kind (e.g. an array
  // combined with a matrix) by printing its own error and setting
  // g_lastElementwiseOk = false - checked here, right after the call,
  // because those are plain free functions with no Parser access of their
  // own to set evaluationSucceeded_ directly. Before this check existed,
  // that failure was invisible to the caller: the expression silently
  // became Value(0) and the enclosing statement (e.g. `x = a + b;`)
  // succeeded anyway, unlike every other invalid-operation error here
  // (dimension mismatches, text arithmetic, ...), which correctly aborts.
  if (op == "+" || op == "-") {
    // Dimensional Integrity: +/- require the same physical dimension on
    // both sides (m + kg is meaningless) — * and / don't need this check;
    // any two dimensions combine into a valid result.
    if (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM) {
      std::cerr << "Error: incompatible units in '" << op << "'\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    Value result = (op == "+") ? add(v, r) : sub(v, r);
    if (!g_lastElementwiseOk) {
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return result;
  }

  if (op == "*" || op == "/" || op == "%" || op == "//" || op == "^") {
    Value result;
    if (op == "*") result = mul(v, r);
    else if (op == "/") result = div_op(v, r);
    else if (op == "%") result = mod_op(v, r);
    else if (op == "//") result = floor_div(v, r);
    else result = power(v, r);
    if (!g_lastElementwiseOk) {
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return result;
  }

  // "." - element-wise matrix operator: M . N
  if (v.isMatrix && r.isMatrix)
    return ElementWise(v, r);

  std::cerr << "Error: Dot operator requires two matrices\n";
  evaluationSucceeded_ = false;
  return Value(0);
}
