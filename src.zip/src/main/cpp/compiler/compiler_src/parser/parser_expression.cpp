// Expression grammar: the precedence-climbing chain from logical operators
// down to arithmetic (parseFactor, the leaf/base case, lives in
// parser_factor.cpp).
//
// Phase 2 (AST rewrite roadmap): each parseX() is now a thin "build then
// evaluate immediately" wrapper around a parseXNode() that builds an Expr
// tree (see ast.h) instead of computing a Value inline. Unlike
// parseFactorNode()'s IDENT branch, nothing in this file is context-
// sensitive on operand values - which tokens form an expression is decided
// purely by operator token types, so parseXNode() has zero side effects and
// evaluateBinaryOp()/evaluateComparison()/evaluateLogicalOp() carry
// everything that used to run inline (dimension checks, orderability
// checks, error reporting, applying the operator). parser_factor.cpp's own
// sub-expression calls (function arguments, array elements, range bounds,
// ...) call parseOrNode() here directly, building real subtrees rather than
// evaluating eagerly - see parser_factor.cpp for those call sites.
#include "parser.h"

#include <cmath>
#include <iostream>
#include <sstream>

#include "../conditional_opr/conditional_opr.h"
#include "../core/elementwise.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/floating/floating.h"
#include "../ops/integer/integer.h"
#include "../builtins/builtins.h"
#include "../ops/matrix/matrix.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/matrix/matrix_ops.h"
#include "../ops/time/time.h"
#include "output.h"
#include "../core/computation_cost.h"
#include "../core/units.h"
#include "../../../runtime/execution/analysis/analysis.h"

namespace {
std::unique_ptr<Expr> makeBinary(ExprKind kind, std::string op,
                                  std::unique_ptr<Expr> left,
                                  std::unique_ptr<Expr> right) {
  auto node = std::make_unique<Expr>();
  node->kind = kind;
  node->text = std::move(op);
  node->children.push_back(std::move(left));
  node->children.push_back(std::move(right));
  return node;
}

/* ---- text never stands in for a number (2026-10-28) ----
   Arithmetic between text and a number is an error: "5" + 1 is neither 6
   nor "51". Only text + text has a meaning (it joins: "5" + "1" is "51").
   A bool still counts as 1 / 0, so 1 + (1 == 1) is 2. The message follows
   the LEFT value - the base of the operation - and says how to get either
   reading. */

// A single value as NC source ("5", 2.5, true), or `fallback` for anything
// that is not a single number / bool / text.
std::string operandSource(const Value &v, const char *fallback) {
  if (v.isText)
    return "\"" + v.text() + "\"";
  if (v.isArray || v.isMatrix || v.isDict || v.isObject || v.isFunctionRef || v.isComplex)
    return fallback;
  if (v.isBool())
    return v.number != 0 ? "true" : "false";
  return formatNumber(v.number);
}

const char *operandKind(const Value &v) {
  if (v.isText)
    return "text";
  if (v.isArray || v.isMatrix)
    return "a matrix";
  if (v.isBool())
    return "a bool";
  return "a number";
}

std::string textOperandError(const std::string &op, const Value &v, const Value &r) {
  const std::string a = operandSource(v, "A"), b = operandSource(r, "B");
  if (v.isText && r.isText) // any operator but '+'
    return "'" + op + "' is not defined for text - only '+' joins text (" + a + " + " + b + ")";
  if (op == "+" && v.isText) {
    std::string msg = std::string("'+' cannot combine text with ") + operandKind(r) +
                      " - the left value is text, so '+' joins text: write " + a + " + str(" +
                      b + ")";
    double d;
    if (tryCoerceTextToNumber(v, d))
      msg += ", or float(" + a + ") + " + b + " to add the numbers";
    return msg;
  }
  if (op == "+") {
    std::string msg = std::string("'+' cannot combine ") + operandKind(v) +
                      " with text - the left value is " + (v.isBool() ? "a bool" : "numeric") +
                      ", so '+' adds numbers: convert the text first, e.g. " + a + " + float(" +
                      b + ")";
    if (!v.isArray && !v.isMatrix)
      msg += ", or join as text with str(" + a + ") + " + b;
    return msg;
  }
  const Value &text = v.isText ? v : r;
  const std::string converted = v.isText ? "float(" + a + ") " + op + " " + b
                                         : a + " " + op + " float(" + b + ")";
  double d;
  if (tryCoerceTextToNumber(text, d))
    return "'" + op + "' is not defined for text - convert it first, e.g. " + converted;
  return "'" + op + "' is not defined for text - " + operandSource(text, "the text") +
         " is not a number";
}
} // namespace

/* ================= LOGICAL ================= */

std::unique_ptr<Expr> Parser::parseOrNode() {
  auto left = parseAndNode();

  while (current().type == OR || current().type == NOR) {
    TokenType op = current().type;
    advance();
    auto right = parseAndNode();
    left = makeBinary(ExprKind::LogicalOp, (op == OR) ? "||" : "nor",
                       std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

std::unique_ptr<Expr> Parser::parseAndNode() {
  auto left = parseComparisonNode();

  while (current().type == AND || current().type == NAND) {
    TokenType op = current().type;
    advance();
    auto right = parseComparisonNode();
    left = makeBinary(ExprKind::LogicalOp, (op == AND) ? "&&" : "nand",
                       std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

std::unique_ptr<Expr> Parser::parseComparisonNode() {
  auto left = parseExpressionNode();

  // `x not in A`: two words, read as one operator. `not` is a plain name to
  // the lexer, so it only means this when `in` follows it directly.
  auto atNotIn = [&]() {
    if (current().type != IDENT || pos + 1 >= tokens.size() || tokens[pos + 1].type != IN)
      return false;
    std::string word = current().text;
    for (char &ch : word)
      ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    return word == "not";
  };

  while (current().type == EQ || current().type == NEQ ||
         current().type == LT || current().type == GT ||
         current().type == LTE || current().type == GTE ||
         current().type == IS_IN || current().type == IS_NOT_IN ||
         current().type == IN || atNotIn()) {
    TokenType op = current().type;
    if (op == IDENT) { // `not in`
      advance();
      op = IS_NOT_IN;
    } else if (op == IN) {
      op = IS_IN;
    }
    advance();
    auto right = parseExpressionNode();

    std::string opText;
    switch (op) {
      case EQ: opText = "=="; break;
      case NEQ: opText = "!="; break;
      case LT: opText = "<"; break;
      case GT: opText = ">"; break;
      case LTE: opText = "<="; break;
      case GTE: opText = ">="; break;
      case IS_IN: opText = "is_in"; break;
      case IS_NOT_IN: opText = "is_not_in"; break;
      default: break; // unreachable - op is one of the 8 checked above
    }
    left = makeBinary(ExprKind::Comparison, opText, std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

/* ================= ARITHMETIC ================= */

std::unique_ptr<Expr> Parser::parseExpressionNode() {
  auto left = parseTermNode();

  while (current().type == PLUS || current().type == MINUS) {
    TokenType op = current().type;
    advance();
    auto right = parseTermNode();
    left = makeBinary(ExprKind::BinaryOp, (op == PLUS) ? "+" : "-",
                       std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

std::unique_ptr<Expr> Parser::parseTermNode() {
  auto left = parseUnaryNode();

  while (current().type == MUL || current().type == DIV ||
         current().type == MOD || current().type == QUOT ||
         current().type == MUL_EW || current().type == DIV_EW ||
         current().type == DOT) {
    TokenType op = current().type;
    const Token opTok = current();
    advance();

    // The old element-wise dot operator (M . N) was replaced by M *. N.
    if (op == DOT) {
      std::cerr << "✖ Syntax Error";
      if (opTok.line)
        std::cerr << " (line " << opTok.line << ", col " << opTok.col << ")";
      std::cerr << ": '.' is not an arithmetic operator - for element-wise multiplication "
                   "write A*.B\n";
      syntaxErrorCount_++;
      evaluationSucceeded_ = false;
      return nullptr;
    }

    auto right = parseUnaryNode();

    std::string opText;
    switch (op) {
      case MUL: opText = "*"; break;
      case DIV: opText = "/"; break;
      case MOD: opText = "%"; break;
      case QUOT: opText = "//"; break;
      case MUL_EW: opText = "*."; break; // element-wise product
      case DIV_EW: opText = "/."; break; // element-wise quotient
      default: break; // unreachable - op is one of those checked above
    }
    left = makeBinary(ExprKind::BinaryOp, opText, std::move(left), std::move(right));
    if (!left)
      return nullptr;
  }

  return left;
}

// Prefix +/-, sitting between parseTermNode() and parsePowerNode() so that
// unary minus binds LOOSER than '^': -2^2 must parse as -(2^2) (== -4), not
// (-2)^2 (== 4) - the standard mathematical convention (and Python's,
// MATLAB's, ...). The operand recurses back into parseUnaryNode() rather
// than calling parsePowerNode() directly so a chain like `- -5` or a
// negative exponent's own sign (`2^-3`, via parsePowerNode()'s own call
// into this function below) still works.
std::unique_ptr<Expr> Parser::parseUnaryNode() {
  if (current().type == PLUS) {
    // Unary plus is the identity (+x == x) - just discard it and keep
    // parsing at this same precedence level.
    advance();
    return parseUnaryNode();
  }

  if (current().type == MINUS) {
    advance();
    auto inner = parseUnaryNode();
    if (!inner)
      return nullptr;
    auto node = std::make_unique<Expr>();
    node->kind = ExprKind::UnaryOp;
    node->text = "-";
    node->children.push_back(std::move(inner));
    return node;
  }

  return parsePowerNode();
}

std::unique_ptr<Expr> Parser::parsePowerNode() {
  auto left = parseFactorNode();

  if (current().type == POW || current().type == POW_EW) {
    const bool elementwise = (current().type == POW_EW);
    advance();
    // The exponent's own recursion goes through parseUnaryNode(), not
    // parsePowerNode() directly, so a negative exponent (`2^-3`) still
    // parses - right-associative either way (`2^3^2` == `2^(3^2)`), since
    // parseUnaryNode() falls straight through to parsePowerNode() when
    // there's no sign to consume.
    auto right = parseUnaryNode();
    if (!left || !right)
      return nullptr;
    return makeBinary(ExprKind::BinaryOp, elementwise ? "^." : "^", std::move(left),
                      std::move(right));
  }

  return left;
}

/* ================= EVALUATION ================= */

Value Parser::evaluateLogicalOp(const Expr *node) {
  Value v = evaluateExpr(node->children[0].get());
  Value r = evaluateExpr(node->children[1].get());
  const std::string &op = node->text;

  if (v.isND() || r.isND()) {
    std::cerr << "Error: '" << op << "' is not supported for N-D matrices yet\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // A real bool, not the float64 1/0 the logical_* helpers compute.
  if (op == "||") return toBoolResult(logical_or(v, r));
  if (op == "nor") return toBoolResult(logical_nor(v, r));
  if (op == "&&") return toBoolResult(logical_and(v, r));
  return toBoolResult(logical_nand(v, r)); // "nand"
}

Value Parser::evaluateComparison(const Expr *node) {
  Value v = evaluateExpr(node->children[0].get());
  Value r = evaluateExpr(node->children[1].get());
  return evaluateComparisonValues(node->text, v, r);
}

// Extracted from evaluateComparison() so the codegen/JIT bridge
// (nc_bridge_comparison_checked, codegen_bridge/value_bridge.cpp) can run
// this exact same dimension/orderability-checked logic - byte-identical
// error messages included - against two already-evaluated Values, instead
// of the JIT path silently skipping these checks entirely (found via real
// corpus testing: a JIT-compiled `(5*m) > (3*kg)` used to just return a
// wrong answer with no error at all, since the bridge functions this used
// to call directly - nc_bridge_gt/lt/... - do their own dimsMatch()/
// orderable() checks internally, but the codegen that called them never
// checked or surfaced their failure return code).
Value Parser::evaluateComparisonValues(const std::string &op, Value v, Value r) {
  // Reset before dispatching below - without this, a stale `false` left by
  // an EARLIER, unrelated comparison elsewhere in the script would
  // incorrectly mark this completely valid one as failed too (the exact
  // "stale cross-statement flag leak" class of bug found and fixed in
  // vector.cpp's divergence() earlier this session).
  g_lastConditionalOk = true;

  // Membership (in / not in / is_in / is_not_in) looks for the left value
  // among the elements of the right one, so none of the element-by-element
  // rules below apply to it - they rejected a container written [1,2,3]
  // once that became a matrix.
  if (op == "is_in" || op == "is_not_in") {
    Value found = op == "is_in" ? logical_is_in(v, r) : logical_is_not_in(v, r);
    if (!g_lastConditionalOk) {
      evaluationSucceeded_ = false;
      return found;
    }
    return toBoolResult(found);
  }

  // Timestamps / durations (ops/time/): compared only with their own type.
  {
    Value timeResult;
    std::string timeErr;
    switch (nctime::timeCompare(op, v, r, timeResult, timeErr)) {
    case nctime::TimeOpResult::Ok:
      return timeResult;
    case nctime::TimeOpResult::Error:
      nctime::reportTimeError(timeErr);
      evaluationSucceeded_ = false;
      return Value(0);
    case nctime::TimeOpResult::NotTime:
      break;
    }
  }

  // An N-D matrix on either side: compared element by element against a
  // single value, or as a whole against a matrix of the same shape - the
  // same rules as for 2-D matrices below.
  if (v.isND() || r.isND()) {
    Value out;
    std::string err;
    if (!ndCompare(op, v, r, out, err)) {
      std::cerr << "Error: " << err << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return out;
  }

  // An array or matrix on either side (A > 2, A == B, ...): element by
  // element against a single value, or one true/false for two same-size
  // containers - see compareContainers() (conditional_opr.h) for the rules.
  // Checked first because the unit check and the "only numbers and text can
  // be ordered" check below are scalar rules; compareContainers() applies
  // both of them per element instead. JIT-compiled comparisons reach this
  // same code through nc_bridge_comparison_checked().
  {
    Value containerResult;
    std::string containerErr;
    switch (compareContainers(op, v, r, containerResult, containerErr)) {
    case ContainerCompare::Ok:
      return containerResult;
    case ContainerCompare::Error:
      std::cerr << "Error: " << containerErr << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    case ContainerCompare::NotApplicable:
      break;
    }
  }

  // Dimensional Integrity: comparing across incompatible dimensions is as
  // meaningless as adding them.
  if (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM) {
    std::cerr << "Error: incompatible units in comparison\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Text is never read as a number (2026-10-28, same rule as arithmetic):
  // "5" == 5 is false, and "5" < 5 is refused just below as an
  // order-comparison between two kinds.

  // Ordering (<, >, <=, >=) is only meaningful for numbers and strings, and
  // only between two values of the same kind. == and != are deliberately
  // NOT restricted - asking whether a string equals a number is a fair
  // question whose answer is simply "no".
  if (op == "<" || op == ">" || op == "<=" || op == ">=") {
    if (!valueIsOrderable(v) || !valueIsOrderable(r) ||
        valueKindOf(v) != valueKindOf(r)) {
      std::cerr << "Error: cannot order-compare " << valueKindName(v)
                << " with " << valueKindName(r) << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
  }

  Value result;
  if (op == "==") result = logical_eq(v, r);
  else if (op == "!=") result = logical_neq(v, r);
  else if (op == "<") result = logical_lt(v, r);
  else if (op == ">") result = logical_gt(v, r);
  else if (op == "<=") result = logical_lte(v, r);
  else result = logical_gte(v, r); // ">="

  // g_lastConditionalOk: see conditional_opr.h's own comment - lt/gt/le/ge
  // can reject a non-orderable/mismatched-kind pair, though the checks just
  // above already filter those out before reaching here.
  if (!g_lastConditionalOk) {
    evaluationSucceeded_ = false;
    return result;
  }

  // A comparison yields a real bool (true/false), not the float64 1/0.
  return toBoolResult(result);
}

Value Parser::evaluateBinaryOp(const Expr *node) {
  Value v = evaluateExpr(node->children[0].get());
  Value r = evaluateExpr(node->children[1].get());
  return evaluateBinaryOpValues(node->text, v, r);
}

// Extracted from evaluateBinaryOp() for the same reason as
// evaluateComparisonValues() above - lets the JIT bridge
// (nc_bridge_binary_op_checked) run the identical text-coercion/dimension-
// checked logic against two already-evaluated Values, instead of silently
// bypassing it (the JIT-path bug this closes: `5*m + 3*kg` or `"a"+"b"`
// used to silently produce a plausible-looking 0 under JIT with no error at
// all, while the tree-walker always correctly rejected them).
Value Parser::evaluateBinaryOpValues(const std::string &op, Value v, Value r) {
  // The IDE's Analysis box: computations of this operator, and the time
  // profile's "running now". One bool test when the Analysis box is off.
  nc::analysis::OpScope analysisOp(op);
  if (analysisOp.on())
    analysisOp.computations(nc::analysis::binaryOpCost(op, v, r));
  // None of +,-,*,/,%,//,^ have a defined meaning for arbitrary text (NC
  // has no string concatenation/repetition operator) - add/sub/mul/
  // div_op/etc. in arithmetic.cpp don't check isText at all, so a text
  // operand used to silently fall through to reading its .number (0 for
  // any text Value), giving a plausible-looking but meaningless answer
  // instead of an error - e.g. "a"+"b" silently gave 0. Text that's
  // actually a dec2frac()-style "num/denom" fraction (or a plain decimal
  // written as text) is auto-coerced to its numeric value first, so
  // dec2frac(x)+1 or similar just works, the same way Python's Fraction/
  // Julia's Rational stay usable in further math despite printing as
  // text. Genuinely non-numeric text ("a"+"b") is still rejected.
  // Text + text joins them: "a" + "b" is "ab" (and "5" + "1" is "51" - both
  // sides are text). Text meeting a number is read as the number it holds,
  // below.
  // Timestamps / durations (ops/time/): t2 - t1, t + d, d * k, d1 / d2 ...
  {
    Value timeResult;
    std::string timeErr;
    switch (nctime::timeBinaryOp(op, v, r, timeResult, timeErr)) {
    case nctime::TimeOpResult::Ok:
      return timeResult;
    case nctime::TimeOpResult::Error:
      nctime::reportTimeError(timeErr);
      evaluationSucceeded_ = false;
      return Value(0);
    case nctime::TimeOpResult::NotTime:
      break;
    }
  }

  if (op == "+" && v.isText && r.isText)
    return Value(v.text() + r.text());

  // Text never stands in for a number (2026-10-28): "5" + 1 used to be 6
  // (the text was read as the number it holds). See textOperandError().
  if ((v.isText || r.isText) &&
      (op == "+" || op == "-" || op == "*" || op == "/" || op == "%" || op == "//" ||
       op == "^" || op == "*." || op == "/." || op == "^.")) {
    std::cerr << "Error: " << textOperandError(op, v, r) << "\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Units on arrays / matrices, and powers of a number with a unit
  // (core/units.h, 2026-11-18). The operation runs on unit-free copies
  // (which skip this block) and the result gets the unit the rules give:
  // + - % need one unit on both sides, * / combine them, ^ p multiplies the
  // exponents by p (whole results only). Numbers without matrices keep the
  // scalar unit code further down; it already handles + - * / and whole ^.
  {
    using nc::units::Dim;
    const Dim dv = nc::units::unitOf(v), dr = nc::units::unitOf(r);
    const bool container = v.isArray || v.isMatrix || r.isArray || r.isMatrix;
    const bool power = op == "^" || op == "^.";
    if ((!dv.zero() || !dr.zero()) && (container || power)) {
      auto fail = [&](const std::string &message) {
        std::cerr << "Error: " << message << "\n";
        evaluationSucceeded_ = false;
        return Value(0);
      };
      Dim res;
      bool known = true;
      if (op == "+" || op == "-" || op == "%") {
        if (dv != dr)
          return fail("incompatible units in '" + op + "' (" + (dv.zero() ? "no unit" : nc::units::text(dv)) +
                      " and " + (dr.zero() ? "no unit" : nc::units::text(dr)) + ")");
        res = dv;
      } else if (op == "*" || op == "*.") {
        res = {dv.l + dr.l, dv.t + dr.t, dv.m + dr.m};
      } else if (op == "/" || op == "/." || op == "//") {
        res = {dv.l - dr.l, dv.t - dr.t, dv.m - dr.m};
      } else if (power) {
        if (!dr.zero())
          return fail("an exponent cannot have a unit (" + nc::units::text(dr) + ")");
        Value p = r;
        if ((p.isArray || p.isMatrix) && p.length() + p.rows() * p.cols() > 0 && !p.isND() &&
            ((p.isArray && p.length() == 1) || (p.isMatrix && p.rows() == 1 && p.cols() == 1)))
          p = p.isArray ? p.at(0) : p.at(0, 0);
        if (p.isArray || p.isMatrix || p.isText || p.isComplex)
          return fail("a value with a unit (" + nc::units::text(dv) +
                      ") takes one real exponent - element-wise exponents would give each element its own unit");
        const double e = p.number;
        const double l = dv.l * e, t = dv.t * e, m = dv.m * e;
        auto whole = [](double x) { return std::isfinite(x) && std::fabs(x - std::round(x)) < 1e-9; };
        if (!whole(l) || !whole(t) || !whole(m)) {
          std::ostringstream ss;
          ss << "(" << nc::units::text(dv) << ")^" << e << " has no unit with whole exponents - units take whole exponents only";
          return fail(ss.str());
        }
        res = {static_cast<int>(std::lround(l)), static_cast<int>(std::lround(t)), static_cast<int>(std::lround(m))};
      } else {
        known = false; // other operators: as before
      }
      if (known) {
        Value out = evaluateBinaryOpValues(op, nc::units::stripped(v), nc::units::stripped(r));
        if (!evaluationSucceeded_)
          return out;
        std::string err;
        if (!nc::units::attach(out, res, err))
          return fail(err);
        return out;
      }
    }
  }

  // Arrays / matrices of typed elements (uint8, int16, bool, float32 ...):
  // the scalar rules per element (R9, parser_typed_ops.cpp).
  {
    Value typedOut;
    if (typedBinaryOp(op, v, r, typedOut))
      return typedOut;
  }

  // Lazy arithmetic (2026-11-21): a lazy range (A = [-pi:1e-8:pi], or one
  // already carrying a chain) with a plain number stays lazy - A*1000 is a
  // rule, not 5 GB. Element k is computed by the very double operation the
  // eager kernels below do (NumTensor::lazyValue), so every element is the
  // same, bit for bit, whenever it is read or built. Anything else - units,
  // typed or complex numbers, c / A with '/' (an error below) - goes on as
  // before. (Only looked at when a side is an array / matrix: number op
  // number, the hot case of scalar loops, skips it with two flag tests.)
  if (v.isArray || v.isMatrix || r.isArray || r.isMatrix) {
    auto plainNumber = [](const Value &x) {
      return !x.isArray && !x.isMatrix && !x.isText && !x.isDict && !x.isObject && !x.isFunctionRef &&
             !x.isComplex && !x.isTime() && Value::scalarElemType(x) == ElemType::F64 && x.dimL == 0 &&
             x.dimT == 0 && x.dimM == 0;
    };
    using K = NumTensor::LazyOpKind;
    Value lazyOut;
    // A big STORED operand is taken as a lazy view of itself (2026-11-23,
    // Phase 2): S*2 + 1 of a 5 GB S is one rule over S, not two 5 GB
    // temporaries - only when the result would be too big to store
    // comfortably (ncew_detail::preferLazy); otherwise as before.
    Value vView, rView;
    const bool vScalar = plainNumber(r), rScalar = plainNumber(v);
    const Value &vSide = !v.lazyTensor() && vScalar && ncew_detail::lazyOperand(v, vView) ? vView : v;
    const Value &rSide = !r.lazyTensor() && rScalar && ncew_detail::lazyOperand(r, rView) ? rView : r;
    const bool vLazy = vSide.lazyTensor() && !vSide.isND() && vScalar;
    const bool rLazy = rSide.lazyTensor() && !rSide.isND() && rScalar;
    if (vLazy) {
      const double c = r.number;
      const bool done = op == "+"                ? vSide.withLazyOp(K::Add, c, lazyOut)
                        : op == "-"              ? vSide.withLazyOp(K::Sub, c, lazyOut)
                        : op == "*" || op == "*." ? vSide.withLazyOp(K::Mul, c, lazyOut)
                        : op == "/" || op == "/." ? vSide.withLazyOp(K::Div, c, lazyOut)
                                                  : false;
      if (done)
        return lazyOut;
    } else if (rLazy) {
      const double c = v.number;
      // c + x and c * x are x + c and x * c exactly (IEEE + and * commute).
      const bool done = op == "+"   ? rSide.withLazyOp(K::Add, c, lazyOut)
                        : op == "-"  ? rSide.withLazyOp(K::RSub, c, lazyOut)
                        : op == "*" || op == "*." ? rSide.withLazyOp(K::Mul, c, lazyOut)
                        : op == "/." ? rSide.withLazyOp(K::RDiv, c, lazyOut)
                                     : false;
      if (done)
        return lazyOut;
    }
  }

  // An N-D matrix on either side: element-wise arithmetic (ops/matrix/
  // matrix_index.h, ndBinaryOp) - the matrix product and power are 2-D only.
  if (v.isND() || r.isND()) {
    Value out;
    std::string err;
    if (!ndBinaryOp(op, v, r, out, err)) {
      std::cerr << "Error: " << err << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return out;
  }

  // Every operator below reports a rejected operand through
  // g_lastElementwiseOk, but not every path through them sets it back to
  // true (the plain scalar paths of add()/sub()/... never touch it) - so a
  // `false` left by an earlier, unrelated failure would make this valid
  // operation fail silently. Start each operation clean.
  g_lastElementwiseOk = true;

  // ---- Matrix-centred operators (ops/matrix/matrix_ops.h) ----------------
  // A 1-D array (e.g. from space()) meeting a matrix takes part as a row
  // (or as a column, next to a column vector).
  if (v.isArray && r.isMatrix)
    v = matArrayAsMatrix(v, r.rows() > 1 && r.cols() == 1);
  else if (r.isArray && v.isMatrix)
    r = matArrayAsMatrix(r, v.rows() > 1 && v.cols() == 1);

  // Element-wise operators. Without a matrix they mean exactly the plain
  // operator (x*.y == x*y for numbers and 1-D arrays).
  if (op == "*." || op == "/." || op == "^.") {
    if (!v.isMatrix && !r.isMatrix) {
      if (op == "^.")
        return evaluateBinaryOpValues("^", v, r); // numbers and 1-D arrays
      return evaluateBinaryOpValues(op == "*." ? "*" : "/", v, r);
    }
    if (op == "^.") {
      // power(A, n) is the one element-wise power implementation.
      Value result = callBuiltin("power", {v, r});
      if (!g_lastBuiltinFound || !g_lastElementwiseOk) {
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return result;
    }
  }

  if (v.isMatrix || r.isMatrix) {
    Value matResult;
    std::string matErr;
    switch (matrixBinaryOp(op, v, r, matResult, matErr)) {
    case MatOpStatus::Ok:
      if (!g_lastElementwiseOk) {
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return matResult;
    case MatOpStatus::Error:
      std::cerr << "Error: " << matErr << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    case MatOpStatus::NotHandled:
      break; // shapes checked - the general implementation below does it
    }
  }

  // float8/16/32 (ops/floating/floating.h): computed as ordinary float64
  // below, then the single-number result is rounded to the operands'
  // format (the wider one if both are typed; a plain number, integer or
  // bool on the other side does not widen it).
  {
    FloatType floatResult = binaryResultFloatType(v, r);
    if (floatResult != FloatType::Float64) {
      v.dropScalarType();
      r.dropScalarType();
      Value plain = evaluateBinaryOpValues(op, v, r);
      return evaluationSucceeded_ ? applyFloatType(plain, floatResult) : plain;
    }
  }

  // Fixed-width integers (ops/integer/integer.h): integer op integer is
  // computed exactly here, with overflow, mixed-type and zero-divisor
  // errors. Otherwise any bool / integer operand takes part as the float64
  // it mirrors - int op float is float, and true + 1 is 2.
  {
    Value intResult;
    std::string intErr;
    switch (integerBinaryOp(op, v, r, intResult, intErr)) {
    case IntOpResult::Ok:
      if ((op == "+" || op == "-") &&
          (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM)) {
        std::cerr << "Error: incompatible units in '" << op << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return intResult;
    case IntOpResult::Error:
      std::cerr << "Error: " << intErr << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    case IntOpResult::NotApplicable:
      break;
    }
    v.dropScalarType();
    r.dropScalarType();
  }

  // add()/sub()/mul()/div_op()/mod_op()/floor_div()/power() all route
  // array/matrix operands through zipElementwise() (elementwise.cpp), which
  // rejects a mismatched shape or an invalid operand kind (e.g. an array
  // combined with a matrix) by printing its own error and setting
  // g_lastElementwiseOk = false - checked here, right after the call,
  // because those are plain free functions with no Parser access of their
  // own to set evaluationSucceeded_ directly. Before this check existed,
  // that failure was invisible to the caller: the expression silently
  // became Value(0) and the enclosing statement (e.g. `x = a + b;`)
  // succeeded anyway, unlike every other invalid-operation error here
  // (dimension mismatches, text arithmetic, ...), which correctly aborts.
  if (op == "+" || op == "-") {
    // Dimensional Integrity: +/- require the same physical dimension on
    // both sides (m + kg is meaningless) — * and / don't need this check;
    // any two dimensions combine into a valid result.
    if (v.dimL != r.dimL || v.dimT != r.dimT || v.dimM != r.dimM) {
      std::cerr << "Error: incompatible units in '" << op << "'\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    Value result = (op == "+") ? add(v, r) : sub(v, r);
    if (!g_lastElementwiseOk) {
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return result;
  }

  if (op == "*" || op == "/" || op == "%" || op == "//" || op == "^") {
    Value result;
    if (op == "*") result = mul(v, r);
    else if (op == "/") result = div_op(v, r);
    else if (op == "%") result = mod_op(v, r);
    else if (op == "//") result = floor_div(v, r);
    else result = power(v, r);
    if (!g_lastElementwiseOk) {
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return result;
  }

  std::cerr << "Error: unknown operator '" << op << "'\n";
  evaluationSucceeded_ = false;
  return Value(0);
}
