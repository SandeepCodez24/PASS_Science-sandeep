// Phase 6 (slot-indexed scope resolution): the runtime read/write side of a
// resolved variable access - see parser_resolve.cpp for how `slot` gets
// computed, and each method's own declaration comment in parser.h for the
// exact contract. Every one of these takes the `slot` a call site's Expr/
// Stmt node was already stamped with by resolveFunctionSlots() (or -1, for
// anything never resolved - global/top-level code, an excluded name, or a
// constant read) and branches to slots_/slotAssigned_ or `memory` - the
// single place that decision happens, so no call site needs its own `if`.
#include "parser.h"

bool Parser::varExists(int slot, const std::string &name) const {
  if (slot >= 0)
    return slotAssigned_[slot];
  return memory.count(name) != 0;
}

Value Parser::varGet(int slot, const std::string &name) const {
  if (slot >= 0)
    return slots_[slot];
  auto it = memory.find(name);
  return it != memory.end() ? it->second : Value();
}

Value &Parser::varRef(int slot, const std::string &name) {
  if (slot >= 0)
    return slots_[slot];
  return memory[name];
}

void Parser::varSet(int slot, const std::string &name, Value v) {
  if (slot >= 0) {
    slots_[slot] = std::move(v);
    slotAssigned_[slot] = true;
    return;
  }
  if (!memory.count(name))
    insertionOrder.push_back(name);
  memory[name] = std::move(v);
}

void Parser::setAns(const Value &v) {
  varSet(currentAnsSlot_, "ans", v);
  if (currentAnsSlot_ < 0)
    saveToFile();
}
