// Range generation. The one place both a `for i = [a:b]` loop header and a
// general-expression range literal ([start:end], [start:step:end]) actually
// materialize their sequence: both parse to the same RangeLiteral Expr kind
// (ast.h), evaluated by evaluateExpr()'s RangeLiteral case in
// parser_factor.cpp, which calls this - executeStmt()'s For case
// (parser_exec_stmt.cpp) just evaluates stmt->iterable like any other Expr
// and iterates whatever Value.array comes back, with no range-specific code
// of its own.
#include "parser.h"
#include "parser_internal.h"

/* ================= RANGE GENERATION ================= */

// leftBracket is '[' (inclusive start) or '(' (exclusive start);
// rightBracket is ']' (inclusive end) or ')' (exclusive end).
std::vector<double> generateRange(double start, double step, double end,
                                   char leftBracket, char rightBracket) {
  std::vector<double> result;
  if (step == 0.0)
    return result;

  double v = start;
  if (leftBracket == '(')
    v = start + step;

  auto shouldContinue = [&](double val) -> bool {
    if (step > 0)
      return (rightBracket == ']') ? (val <= end + 1e-9) : (val < end - 1e-9);
    else
      return (rightBracket == ']') ? (val >= end - 1e-9) : (val > end + 1e-9);
  };

  while (shouldContinue(v)) {
    result.push_back(v);
    v += step;
  }

  return result;
}
