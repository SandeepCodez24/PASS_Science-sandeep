// Range literals. Both a `for i = [a:b]` loop header and a general-
// expression range literal ([start:end], [start:step:end]) parse to the same
// RangeLiteral Expr kind (ast.h). Since 2026-11-20 their values follow one
// rule, core/range_spec.h: evaluateRangeSpec() below reads the bounds, then
// evaluateExpr()'s RangeLiteral case (parser_factor.cpp) writes the values
// into a packed buffer, and executeStmt()'s For case (parser_exec_stmt.cpp)
// walks them one at a time without building the range at all.
#include "parser.h"
#include "parser_internal.h"

#include <iostream>

/* ================= RANGE GENERATION ================= */

// leftBracket is '[' (inclusive start) or '(' (exclusive start);
// rightBracket is ']' (inclusive end) or ')' (exclusive end).
// Since 2026-11-20 the rule lives in core/range_spec.h (element k =
// first + k*step, count fixed up front); this is that rule as a vector, for
// any code that still wants the values listed. Empty for a zero step or an
// endless range.
std::vector<double> generateRange(double start, double step, double end,
                                   char leftBracket, char rightBracket) {
  std::vector<double> result;
  if (step == 0.0)
    return result;
  const ncrange::Spec spec = ncrange::make(start, step, end, leftBracket, rightBracket);
  if (spec.count <= 0)
    return result;
  result.resize(static_cast<size_t>(spec.count));
  for (int64_t k = 0; k < spec.count; k++)
    result[static_cast<size_t>(k)] = ncrange::valueAt(spec, k);
  return result;
}

bool Parser::evaluateRangeSpec(const Expr *node, ncrange::Spec &out) {
  const char leftBracket = node->text.size() > 0 ? node->text[0] : '[';
  const char rightBracket = node->text.size() > 1 ? node->text[1] : ']';

  // Same order as always: start, then step (when written), then stop.
  const double start = evaluateExpr(node->rangeStart.get()).number;
  double step = 1.0;
  if (node->rangeStep)
    step = evaluateExpr(node->rangeStep.get()).number;
  const double end = evaluateExpr(node->rangeStop.get()).number;

  if (step == 0.0) {
    std::cerr << "Error: range literal step cannot be zero\n";
    evaluationSucceeded_ = false;
    return false;
  }
  out = ncrange::make(start, step, end, leftBracket, rightBracket);
  if (out.count < 0) {
    std::cerr << "Error: range literal has no end - it would hold more than 2^53 elements\n";
    evaluationSucceeded_ = false;
    return false;
  }
  return true;
}
