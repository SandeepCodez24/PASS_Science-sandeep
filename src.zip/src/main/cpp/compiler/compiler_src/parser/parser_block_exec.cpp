// Block execution: given an already-captured header + accumulated body
// text (from ScriptManager/SM_stage_02.cpp's line-by-line accumulation, or
// from parser_block_scan.cpp's nested-block scan), actually run it.
// Finding nested block *boundaries* within a flat line list is a separate
// concern - see executeBlockLines() in parser_block_scan.cpp.
#include "parser.h"
#include "parser_internal.h"

#include <cctype>
#include <iostream>
#include <sstream>

#include "lexer.h"

/* ================= RANGE GENERATION ================= */

// Shared by for-loop headers (executeForBlock) and general-expression range
// literals ([start:end], [start:step:end]) in parseFactor. leftBracket is
// '[' (inclusive start) or '(' (exclusive start); rightBracket is ']'
// (inclusive end) or ')' (exclusive end).
std::vector<double> generateRange(double start, double step, double end,
                                   char leftBracket, char rightBracket) {
  std::vector<double> result;
  if (step == 0.0)
    return result;

  double v = start;
  if (leftBracket == '(')
    v = start + step;

  auto shouldContinue = [&](double val) -> bool {
    if (step > 0)
      return (rightBracket == ']') ? (val <= end + 1e-9) : (val < end - 1e-9);
    else
      return (rightBracket == ']') ? (val >= end - 1e-9) : (val > end + 1e-9);
  };

  while (shouldContinue(v)) {
    result.push_back(v);
    v += step;
  }

  return result;
}

/* ================= FOR LOOP ENTRY ================= */

// Called by ScriptManager once it has collected the full block (header + body).
// pendingForBlock_ has the body lines; forHeader_ has the "for ..." header.
Value Parser::executeForBlock() {
  inForBlock_ = false;

  // ---- Parse header tokens ----
  // Uses the Parser's own shared token cursor (setTokens/current/advance),
  // not a separate local one, so range bounds in Form B below can be parsed
  // via parseOr() — full expressions (variables, arithmetic, ...), not just
  // numeric literals. Safe to reuse the shared cursor here: header parsing
  // always fully completes before executeBlockLines() below re-points it at
  // each body line anyway.
  Lexer headerLex(forHeader_);
  auto headerToks = headerLex.tokenize();
  // headerToks layout: FOR  IDENT  ASSIGN  ... COLON ...   END
  //                or: FOR  IDENT  IN  IDENT   END
  setTokens(headerToks);

  if (current().type != FOR) {
    std::cerr << "Error: expected 'for' keyword\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }
  advance(); // consume FOR

  if (current().type != IDENT) {
    std::cerr << "Error: expected variable name after 'for'\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }
  std::string loopVar = current().text;
  advance(); // consume IDENT

  // ---- Form A: for x in arr ----
  if (current().type == IN) {
    advance(); // consume IN
    std::string arrName = current().text;
    advance();

    Value arrVal;
    if (memory.count(arrName))
      arrVal = memory[arrName];
    else {
      std::cerr << "Error: variable '" << arrName << "' not found for for-in loop\n";
      pendingForBlock_.clear();
      forHeader_.clear();
      return Value(0);
    }

    // Collect body lines once for block execution
    std::vector<std::string> bodyLines;
    std::istringstream bodyStream(pendingForBlock_);
    std::string bodyLine;
    while (std::getline(bodyStream, bodyLine)) {
      bodyLines.push_back(bodyLine);
    }

    // Execute body for each element
    loopDepth_++;
    if (arrVal.isArray) {
      for (const Value &elem : arrVal.array) {
        memory[loopVar] = elem;
        executeBlockLines(bodyLines);
        if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
        if (loopSignal_ == LoopSignal::Return) break; // propagate to the call boundary, don't clear
        if (loopSignal_ == LoopSignal::Continue) { loopSignal_ = LoopSignal::None; }
      }
    } else {
      // Single value treated as 1-element iteration
      memory[loopVar] = arrVal;
      executeBlockLines(bodyLines);
      if (loopSignal_ == LoopSignal::Break || loopSignal_ == LoopSignal::Continue)
        loopSignal_ = LoopSignal::None;
    }
    loopDepth_--;

    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }

  // ---- Form B: for i = [start:end] / (start:end) / [start:step:end] ----
  if (current().type != ASSIGN) {
    std::cerr << "Error: expected '=' or 'in' after loop variable\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }
  advance(); // consume ASSIGN

  // read left bracket: '[' or '('
  char leftBracket = '[';
  if (current().type == LBRACKET) { leftBracket = '['; advance(); }
  else if (current().type == LPAREN) { leftBracket = '('; advance(); }
  else {
    std::cerr << "Error: expected '[' or '(' in for range\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }

  // read start — a full expression (numeric literal, variable, arithmetic,
  // ...) via parseOr(), not just a bare NUMBER token, so `for i = [1:N]:`
  // works with N a variable. parseOr() naturally stops at the ':' below
  // since COLON isn't part of expression grammar.
  Value startResult = parseOr();
  if (!evaluationSucceeded_) {
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0); // parseOr() already printed the specific error
  }
  double start = startResult.number;

  if (current().type != COLON) {
    std::cerr << "Error: expected ':' in for range\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }
  advance(); // consume first COLON

  // Peek: could be [start:end] or [start:step:end]
  Value secondResult = parseOr();
  if (!evaluationSucceeded_) {
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }
  double second = secondResult.number;

  double step = 1.0;
  double end  = second;

  if (current().type == COLON) {
    // 3-term: [start:step:end] — second is actually step
    advance(); // consume second COLON
    step = second;

    Value endResult = parseOr();
    if (!evaluationSucceeded_) {
      pendingForBlock_.clear();
      forHeader_.clear();
      return Value(0);
    }
    end = endResult.number;
  }

  // read right bracket: ']' or ')'
  char rightBracket = ']';
  if (current().type == RBRACKET) { rightBracket = ']'; advance(); }
  else if (current().type == RPAREN) { rightBracket = ')'; advance(); }
  else {
    std::cerr << "Error: expected ']' or ')' to close for range\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }

  if (step == 0.0) {
    std::cerr << "Error: for loop step cannot be zero\n";
    pendingForBlock_.clear();
    forHeader_.clear();
    return Value(0);
  }

  std::vector<std::string> bodyLines;
  std::istringstream bodyStream(pendingForBlock_);
  std::string bodyLine;
  while (std::getline(bodyStream, bodyLine)) {
    bodyLines.push_back(bodyLine);
  }

  loopDepth_++;
  for (double v : generateRange(start, step, end, leftBracket, rightBracket)) {
    memory[loopVar] = Value(v);
    executeBlockLines(bodyLines);
    if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
    if (loopSignal_ == LoopSignal::Return) break; // propagate to the call boundary, don't clear
    if (loopSignal_ == LoopSignal::Continue) { loopSignal_ = LoopSignal::None; }
  }
  loopDepth_--;

  pendingForBlock_.clear();
  forHeader_.clear();
  saveToFile();
  return Value(0);
}

/* ================= IF LOOP ENTRY ================= */

Value Parser::executeIfBlock() {
  inIfBlock_ = false;
  inElseBranch_ = false;
  inElseifBranch_ = false;

  // Capture copies before any nested parseStatement() call (used below to
  // evaluate elseif conditions) can clear the pending* members as a side
  // effect of re-entering the IF/ELSEIF branch.
  std::string trueBlock = pendingIfTrueBlock_;
  std::string falseBlock = pendingIfFalseBlock_;
  auto elseifBranches = pendingElseifBranches_;

  std::string targetBlock;
  bool matched = ifConditionResult_;

  if (matched) {
    targetBlock = trueBlock;
  } else {
    for (auto &branch : elseifBranches) {
      Lexer condLex(branch.first);
      auto condToks = condLex.tokenize();
      if (!condToks.empty() && condToks[0].type == ELSEIF) {
        setTokens(condToks);
        parseStatement();       // reuses IF/ELSEIF condition evaluation
        bool branchResult = ifConditionResult_;
        inIfBlock_ = false;     // undo the side effect parseStatement() set
        if (branchResult) {
          targetBlock = branch.second;
          matched = true;
          break;
        }
      }
    }
    if (!matched)
      targetBlock = falseBlock;
  }

  if (!targetBlock.empty()) {
    std::vector<std::string> bodyLines;
    std::istringstream bodyStream(targetBlock);
    std::string bodyLine;
    while (std::getline(bodyStream, bodyLine)) {
      bodyLines.push_back(bodyLine);
    }
    executeBlockLines(bodyLines);
  }

  pendingIfTrueBlock_.clear();
  pendingIfFalseBlock_.clear();
  pendingElseifBranches_.clear();
  return Value(0);
}

/* ================= WHILE LOOP ENTRY ================= */

Value Parser::executeWhileBlock() {
  inWhileBlock_ = false;

  std::string condExpr = whileHeader_;
  size_t wPos = condExpr.find("while");
  if (wPos != std::string::npos) {
    condExpr = condExpr.substr(wPos + 5);
  }
  size_t s = condExpr.find_first_not_of(" \t\r\n");
  if (s != std::string::npos) condExpr = condExpr.substr(s);
  size_t e = condExpr.find_last_not_of(" \t\r\n");
  if (e != std::string::npos) condExpr = condExpr.substr(0, e + 1);

  bool negateWhile = false;
  {
    std::string lowerCond = condExpr;
    for (char &ch : lowerCond) ch = static_cast<char>(std::tolower((unsigned char)ch));
    if (lowerCond.rfind("not", 0) == 0 &&
        (lowerCond.size() == 3 || std::isspace((unsigned char)lowerCond[3]))) {
      negateWhile = true;
      condExpr = condExpr.substr(3);
      size_t ns = condExpr.find_first_not_of(" \t\r\n");
      condExpr = (ns != std::string::npos) ? condExpr.substr(ns) : std::string();
    }
  }

  std::vector<std::string> bodyLines;
  std::istringstream bodyStream(pendingWhileBlock_);
  std::string bodyLine;
  while (std::getline(bodyStream, bodyLine)) {
    bodyLines.push_back(bodyLine);
  }

  Lexer condLex(condExpr);
  auto condToks = condLex.tokenize();

  int iterationCount = 0;
  const int MAX_ITERATIONS = 100000;

  auto evalCond = [&]() -> bool {
    if (condToks.empty()) return false;
    setTokens(condToks);
    Value res = parseOr();
    bool b = res.isText ? !res.text.empty() : (res.number != 0.0);
    return negateWhile ? !b : b;
  };

  loopDepth_++;
  while (evalCond()) {
    iterationCount++;
    if (iterationCount > MAX_ITERATIONS) {
      std::cerr << "✖ Runtime Error: Maximum while loop iteration limit (100,000) exceeded\n";
      evaluationSucceeded_ = false;
      break;
    }
    executeBlockLines(bodyLines);
    if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
    if (loopSignal_ == LoopSignal::Return) break; // propagate to the call boundary, don't clear
    if (loopSignal_ == LoopSignal::Continue) { loopSignal_ = LoopSignal::None; }
  }
  loopDepth_--;

  pendingWhileBlock_.clear();
  whileHeader_.clear();
  saveToFile();
  return Value(0);
}
