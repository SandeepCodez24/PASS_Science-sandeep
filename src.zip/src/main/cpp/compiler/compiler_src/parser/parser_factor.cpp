// parseFactor(): the grammar's leaf/base case - literals, unary/prefix/
// postfix operators, array/matrix/range literals, and identifier handling
// (function calls, variable/constant lookup, dict methods and key read,
// array/matrix indexing).
//
// Phase 2/3 (AST rewrite roadmap): split into parseFactorNode() (builds an
// Expr tree - see ast.h) and evaluateExpr() (does what parseFactor() used
// to do inline while parsing: memory access, function/method calls, error
// reporting). Parser::parseFactor() is a thin "build then evaluate
// immediately" wrapper for existing eager callers; Phase 3's Program parser
// (parser_program.cpp) instead builds a tree once, up front, and hands it
// to a separate evaluator to run later - possibly many times, e.g. once per
// loop iteration or function call.
//
// That reuse requirement is why parseFactorNode() does zero memory/constant/
// function-table lookups anywhere, even though the original single-pass
// grammar was genuinely context-sensitive on runtime values - e.g. whether
// `A.field` means object field access or the elementwise dot operator
// depends on A's actual type. Baking that decision into parse-time token
// consumption (as the original did, and an earlier revision of this file
// briefly did too) would freeze the answer as of whenever the tree was
// built, wrong for any later re-evaluation where A's type has changed.
// Every such decision - which branch a DOT expression is, whether a bare
// identifier is a variable, a constant, or a zero-arg function call - is
// made in evaluateExpr() instead, using values as they actually are at each
// evaluation. See ast.h's Identifier note and evaluateExpr()'s FieldAccess/
// MethodCall cases for the specifics, including the one deliberate grammar
// simplification this required (documented at the IDENT branch below).
#include "parser.h"
#include "parser_internal.h"

#include <cctype>
#include <cmath>
#include <iostream>
#include <limits>

#include "../builtins/builtins.h"
#include "../builtins/constants_builtin.h"
#include "../conditional_opr/conditional_opr.h"
#include "../core/elementwise.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/dc/dc.h"
#include "../ops/geometric/geometric.h"
#include "../ops/matrix/matrix.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/vector/vector.h"

/* ================= FACTOR ================= */

static bool resolveConstantValue(const std::string &name, double &out) {
  return tryResolveConstantValue(name, out);
}

// Dimensional Integrity: unit constants — resolved like any other constant
// (pi, e, ...) but returning a Value(1.0) tagged with a physical dimension
// instead of a plain number. Composed via ordinary arithmetic rather than a
// dedicated literal: `v * m/s` (not `v<m/s>` from the design doc — that
// syntax collides with the existing `<`/`>` comparison tokens used
// pervasively elsewhere in this language, so it was deliberately not
// implemented as written). Checked only as a fallback after normal
// variable/constant lookup fails, so assigning to a variable named e.g.
// `s` shadows the unit meaning for that name, same precedence as any other
// constant.
static bool tryResolveUnitConstant(const std::string &name, Value &out) {
  int dimL = 0, dimT = 0, dimM = 0;
  if (name == "m") { dimL = 1; }
  else if (name == "s") { dimT = 1; }
  else if (name == "kg") { dimM = 1; }
  else if (name == "N") { dimM = 1; dimL = 1; dimT = -2; }   // force = kg*m/s^2
  else if (name == "Pa") { dimM = 1; dimL = -1; dimT = -2; } // pressure = N/m^2
  else return false;

  out = Value(1.0);
  out.dimL = dimL;
  out.dimT = dimT;
  out.dimM = dimM;
  return true;
}

namespace {

std::unique_ptr<Expr> makeExpr(ExprKind kind) {
  auto node = std::make_unique<Expr>();
  node->kind = kind;
  return node;
}

// Wraps `inner` in a postfix "!" (factorial) UnaryOp node, once per '!' in a
// row - e.g. `5!!` is Factorial(Factorial(5)), matching the while-loop
// chaining both NUMBER and bare-identifier factors did inline before.
std::unique_ptr<Expr> wrapPostfixFactorial(std::unique_ptr<Expr> inner) {
  auto node = makeExpr(ExprKind::UnaryOp);
  node->text = "!post";
  node->children.push_back(std::move(inner));
  return node;
}

} // namespace

std::unique_ptr<Expr> Parser::parseIndexKeyNode() {
  if (current().type == COLON) {
    advance();
    return makeExpr(ExprKind::Wildcard);
  }
  return parseOrNode();
}

bool Parser::requireClosing(TokenType closeType, const Token &openTok) {
  if (current().type == closeType) {
    advance();
    return true;
  }
  const char *closeText = closeType == RPAREN ? ")" : "]";
  const Token &bad = current();
  std::cerr << "✖ Syntax Error";
  if (openTok.line)
    std::cerr << " (line " << openTok.line << ", col " << openTok.col << ")";
  std::cerr << ": '" << openTok.text << "' was never closed";
  if (bad.type != END && bad.type != SEMICOLON)
    std::cerr << " - expected '" << closeText << "' but found '" << bad.text << "'";
  std::cerr << "\n";
  syntaxErrorCount_++;
  evaluationSucceeded_ = false;
  return false;
}

// Postfix factorial applies to ANY parsed factor - (a+b)!, f(x)!, A[0]!,
// |x|!, [..]! - not just a bare number/identifier. The atom parser's own
// inline '!' loops (NUMBER / IDENT) still run first; this catches the rest.
std::unique_ptr<Expr> Parser::parseFactorNode() {
  auto node = parseFactorAtomNode();
  if (!node)
    return nullptr;
  while (current().type == FACT) {
    advance();
    node = wrapPostfixFactorial(std::move(node));
  }
  return node;
}

std::unique_ptr<Expr> Parser::parseFactorAtomNode() {
  // @name - a first-class function reference (see ast.h's FunctionRef
  // comment). No collision with the class-header `@rate(...)` syntax -
  // that AT is consumed entirely inside parseClassDeclNode(), a completely
  // separate parse path that never reaches here.
  if (current().type == AT) {
    advance();
    if (current().type != IDENT) {
      std::cerr << "✖ Syntax Error";
      if (current().line)
        std::cerr << " (line " << current().line << ", col " << current().col << ")";
      std::cerr << ": expected a function name after '@'\n";
      syntaxErrorCount_++;
      evaluationSucceeded_ = false;
      return nullptr;
    }
    auto node = makeExpr(ExprKind::FunctionRef);
    node->text = current().text;
    advance();
    return node;
  }

  if (current().type == STRING) {
    auto node = makeExpr(ExprKind::StringLiteral);
    node->text = current().text;
    advance();
    return node;
  }

  if (current().type == FACT) {
    // Bare '!' in prefix position (nothing parsed yet this factor) means
    // logical NOT, e.g. `!(a == c)`. Postfix '!' (factorial, e.g. `5!`) is
    // handled separately below/after a value has already been parsed.
    advance();
    auto inner = parseFactorNode();
    if (!inner)
      return nullptr;
    auto node = makeExpr(ExprKind::UnaryOp);
    node->text = "!";
    node->children.push_back(std::move(inner));
    return node;
  }

  // Unary +/- used to be handled here, but that made them bind TIGHTER than
  // '^' (e.g. `-2^2` parsed as `(-2)^2` == 4, instead of the standard
  // `-(2^2)` == -4) - parseFactorNode() is '^'s own base-case operand, so
  // consuming a leading sign at this level meant the sign was already
  // "inside" the base before '^' ever got a chance to bind. They're now
  // handled one level up, in parseUnaryNode() (parser_expression.cpp),
  // which sits between parseTermNode() and parsePowerNode() specifically so
  // exponentiation binds tighter than a leading sign.

  if (current().type == NUMBER) {
    auto node = makeExpr(ExprKind::NumberLiteral);
    node->number = std::stod(current().text);
    node->imaginary = current().imaginary;
    advance();

    while (current().type == FACT) {
      advance();
      node = wrapPostfixFactorial(std::move(node));
    }

    return node;
  }

  // |expr| — absolute value (scalar), vector norm/magnitude (array), or
  // matrix determinant (matrix), matching the standard overloaded meaning
  // of pipe-bar notation in mathematics.
  if (current().type == PIPE) {
    advance();

    auto inner = parseOrNode();
    if (!inner)
      return nullptr;

    if (current().type != PIPE) {
      std::cerr << "Error: expected closing '|' in absolute value/norm/"
                   "determinant expression\n";
      syntaxErrorCount_++;
      evaluationSucceeded_ = false;
      return nullptr;
    }
    advance(); // consume closing '|'

    auto node = makeExpr(ExprKind::AbsOrNorm);
    node->children.push_back(std::move(inner));
    return node;
  }

  /* array / matrix / range literals, and parenthesized grouping */
  if (current().type == LBRACKET || current().type == LPAREN) {
    char leftBracket = (current().type == LBRACKET) ? '[' : '(';
    const Token openTok = current();
    advance();

    // Range literal: [start:end] or [start:step:end] — see the scan-ahead
    // comment this used to carry in the pre-Phase-2 version; unchanged.
    {
      bool isRangeLiteral = false;
      int depth = 0;
      for (size_t sp = pos; sp < tokens.size(); sp++) {
        TokenType t = tokens[sp].type;
        if (t == LBRACKET || t == LPAREN) {
          depth++;
        } else if (t == RBRACKET || t == RPAREN) {
          if (depth == 0) break;
          depth--;
        } else if (depth == 0 && t == COMMA) {
          break;
        } else if (depth == 0 && t == COLON) {
          isRangeLiteral = true;
          break;
        } else if (t == END) {
          break;
        }
      }

      if (isRangeLiteral) {
        auto startNode = parseOrNode();
        if (!startNode)
          return nullptr; // already printed the specific error

        if (current().type != COLON) {
          std::cerr << "Error: expected ':' in range literal\n";
          evaluationSucceeded_ = false;
          return nullptr;
        }
        advance(); // consume ':'

        auto secondNode = parseOrNode();
        if (!secondNode)
          return nullptr;

        std::unique_ptr<Expr> thirdNode;
        bool hasThird = false;

        if (current().type == COLON) {
          advance();
          thirdNode = parseOrNode();
          if (!thirdNode)
            return nullptr;
          hasThird = true;
        }

        char rightBracket = ']';
        if (current().type == RBRACKET) { rightBracket = ']'; advance(); }
        else if (current().type == RPAREN) { rightBracket = ')'; advance(); }
        else {
          std::cerr << "Error: expected ']' or ')' to close range literal\n";
          evaluationSucceeded_ = false;
          return nullptr;
        }

        auto node = makeExpr(ExprKind::RangeLiteral);
        node->text = std::string() + leftBracket + rightBracket;
        node->rangeStart = std::move(startNode);
        if (hasThird) {
          node->rangeStep = std::move(secondNode);
          node->rangeStop = std::move(thirdNode);
        } else {
          node->rangeStop = std::move(secondNode);
        }
        return node;
      }
    }

    // Not a range literal. A '(' here is a parenthesized grouping
    // expression, e.g. (1 + 2) * 3 — not an array/matrix literal, which is
    // '['-only. Grouping doesn't need its own node - just the inner subtree.
    if (leftBracket == '(') {
      if (current().type == RPAREN) {
        std::cerr << "✖ Syntax Error";
        if (openTok.line)
          std::cerr << " (line " << openTok.line << ", col " << openTok.col << ")";
        std::cerr << ": empty parentheses '()' - an expression is required "
                     "inside\n";
        advance(); // consume ')' so recovery resumes after the group
        syntaxErrorCount_++;
        evaluationSucceeded_ = false;
        return nullptr;
      }
      auto inner = parseOrNode();
      if (!inner)
        return nullptr;
      if (!requireClosing(RPAREN, openTok))
        return nullptr;
      return inner;
    }

    std::vector<std::unique_ptr<Expr>> arrElems;
    std::vector<std::unique_ptr<Expr>> matRows; // each entry an ArrayLiteral (one row)
    bool isMatrix = false;

    while (current().type != RBRACKET && current().type != END &&
           current().type != SEMICOLON) {
      if (current().type == LBRACKET) {
        isMatrix = true;
        const Token rowOpen = current();
        advance();

        auto rowNode = makeExpr(ExprKind::ArrayLiteral);

        while (current().type != RBRACKET && current().type != END &&
               current().type != SEMICOLON) {
          auto elem = parseOrNode();
          if (!elem)
            return nullptr;
          rowNode->children.push_back(std::move(elem));

          if (current().type == COMMA)
            advance();
          else
            break;
        }

        if (rowNode->children.empty()) {
          if (current().type == RBRACKET)
            advance();
          std::cerr << "Error: Empty row in matrix literal\n";
          syntaxErrorCount_++;
          evaluationSucceeded_ = false;
          return nullptr;
        }

        if (!requireClosing(RBRACKET, rowOpen))
          return nullptr;

        if (!matRows.empty() && rowNode->children.size() != matRows[0]->children.size()) {
          std::cerr << "Error: Jagged matrix literal (row length mismatch)\n";
          evaluationSucceeded_ = false;
          return nullptr;
        }

        matRows.push_back(std::move(rowNode));
      } else {
        auto elem = parseOrNode();
        if (!elem)
          return nullptr;
        arrElems.push_back(std::move(elem));
      }

      if (current().type == COMMA)
        advance();
    }

    if (!requireClosing(RBRACKET, openTok))
      return nullptr;

    if (isMatrix) {
      if (!matRows.empty()) {
        const size_t cols = matRows[0]->children.size();
        if (cols == 0) {
          std::cerr << "Error: Matrix literal with zero columns\n";
          evaluationSucceeded_ = false;
          return nullptr;
        }
        for (const auto &row : matRows) {
          if (row->children.size() != cols) {
            std::cerr << "Error: Jagged matrix literal (row length mismatch)\n";
            evaluationSucceeded_ = false;
            return nullptr;
          }
        }
      }
      auto node = makeExpr(ExprKind::MatrixLiteral);
      node->children = std::move(matRows);
      return node;
    }

    auto node = makeExpr(ExprKind::ArrayLiteral);
    node->children = std::move(arrElems);
    return node;
  }

  if (current().type == IDENT) {
    std::string name = current().text;
    advance();

    /* function call */
    if (current().type == LPAREN) {
      const Token callOpen = current();
      advance();

      // "dict" accepts a ':' as sugar for ',' between its two constructor
      // args: dict(keysArr: valsArr) as well as dict(keysArr, valsArr).
      std::string nameLower = name;
      for (char &ch : nameLower) ch = static_cast<char>(std::tolower((unsigned char)ch));
      bool isDictCall = (nameLower == "dict");

      std::vector<std::unique_ptr<Expr>> args;
      while (current().type != RPAREN && current().type != END &&
             current().type != SEMICOLON) {
        auto argNode = parseOrNode();
        if (!argNode)
          return nullptr;
        args.push_back(std::move(argNode));
        if (current().type == COMMA)
          advance();
        else if (isDictCall && current().type == COLON)
          advance();
        else
          break;
      }

      if (!requireClosing(RPAREN, callOpen))
        return nullptr;

      // parent(args) — reserved call name (not a token, same precedent as
      // `new`/`clear`); always wins over a same-named class/function/
      // builtin, exactly like before.
      ExprKind kind = (name == "parent") ? ExprKind::ParentCall : ExprKind::Call;
      auto node = makeExpr(kind);
      node->text = name;
      node->children = std::move(args);
      return node;
    }

    // Everything below is purely syntax-driven - no memory/constant/
    // function-table lookup happens anywhere in this function. Which of
    // "field access" vs "elementwise dot operator" vs "dict method call"
    // vs "object method call" applies for a given DOT is a question about
    // the receiver's *runtime* value, which isn't known yet at parse time
    // for a tree that may be built once and evaluated many times (a
    // function body, a loop body - Phase 3). Every such decision is made in
    // evaluateExpr() instead, using the receiver's actual value at each
    // evaluation. This does mean one deliberate grammar simplification
    // relative to the original single-pass version: `obj.field` (no
    // trailing '(') now always binds at the factor level (tight, like
    // field/member access in most languages), rather than only doing so
    // when the receiver happened to already be a resolved object at parse
    // time and otherwise falling through to be re-parsed one precedence
    // level up as the elementwise dot operator's right-hand side. The two
    // give the same result whenever the dot-expression is a term by itself
    // (by far the common case - verified against every matrix/dot script in
    // the golden corpus); they can only disagree inside a larger arithmetic
    // expression when the receiver *isn't* an object AND the right-hand
    // name also happens to be a variable - an obscure combination not
    // exercised by any script this session has access to.
    auto identNode = makeExpr(ExprKind::Identifier);
    identNode->text = name;

    /* obj.field (bare dot-access, no trailing '(') or the elementwise dot
       operator misapplied to a non-object - evaluateExpr() tells them
       apart using the receiver's actual value. */
    if (current().type == DOT && pos + 1 < tokens.size() &&
        tokens[pos + 1].type == IDENT &&
        !(pos + 2 < tokens.size() && tokens[pos + 2].type == LPAREN)) {
      advance(); // consume '.'
      std::string fieldName = current().text;
      advance(); // consume field name

      auto node = makeExpr(ExprKind::FieldAccess);
      node->text = fieldName;
      node->children.push_back(std::move(identNode));
      return node;
    }

    /* dict method call: A.keys(), A.values(), A.size(), A.match_key(k)
       object method call: obj.Method(args) — including the reserved
       obj.lineage()/obj.rewind([n])/obj.tick(t), which all share this exact
       token shape (DOT IDENT LPAREN ... RPAREN) and only differ in which
       runtime dispatch fires — a decision made in evaluateExpr(). A dict
       builtin call's implicit "receiver as arg 0" is also decided there
       now, for the same reason. */
    if (current().type == DOT && pos + 2 < tokens.size() &&
        tokens[pos + 1].type == IDENT && tokens[pos + 2].type == LPAREN) {
      advance(); // consume '.'
      std::string method = current().text;
      advance(); // consume method name
      const Token methodOpen = current();
      advance(); // consume '('

      std::vector<std::unique_ptr<Expr>> args;
      while (current().type != RPAREN && current().type != END &&
             current().type != SEMICOLON) {
        auto argNode = parseOrNode();
        if (!argNode)
          return nullptr;
        args.push_back(std::move(argNode));
        if (current().type == COMMA)
          advance();
        else
          break;
      }

      if (!requireClosing(RPAREN, methodOpen))
        return nullptr;

      auto node = makeExpr(ExprKind::MethodCall);
      node->text = method;
      node->children.push_back(std::move(identNode)); // receiver, always children[0]
      for (auto &a : args)
        node->children.push_back(std::move(a));
      return node;
    }

    /* dict key / array element / matrix element or row-col slice read:
       A['key'], A[i], A[row,col], A[n,:], A[:,n], A[row][col] (chained -
       one Index node per bracket group, each one possibly holding several
       comma-separated keys - see ast.h's Index comment). Which one a given
       shape means (dict vs array vs matrix, and whether a key is a plain
       index or a Wildcard ':') is entirely an evaluateExpr()-time decision,
       same reasoning as everywhere else in this function - see file header. */
    if (current().type == LBRACKET) {
      auto node = std::move(identNode);
      while (current().type == LBRACKET) {
        advance();

        std::vector<std::unique_ptr<Expr>> keys;
        keys.push_back(parseIndexKeyNode());
        while (current().type == COMMA) {
          advance();
          keys.push_back(parseIndexKeyNode());
        }

        if (current().type == RBRACKET)
          advance();
        else {
          std::cerr << "Error: expected ']' after index\n";
          syntaxErrorCount_++;
          evaluationSucceeded_ = false;
          return nullptr;
        }

        auto idxNode = makeExpr(ExprKind::Index);
        idxNode->children.push_back(std::move(node));
        for (auto &k : keys)
          idxNode->children.push_back(std::move(k));
        node = std::move(idxNode);
      }
      return node;
    }

    // NOTE: the pre-Phase-2 version had a further `current().type == LPAREN`
    // branch here for reading an array/matrix element by call syntax
    // (`arr(i)`, `mat(i)(j)`). It was unreachable dead code even then: any
    // `IDENT(` is already intercepted by the function-call branch at the
    // very top of this IDENT case, immediately after the identifier is
    // read, before variable lookup ever runs — so control can never reach
    // this point with current().type == LPAREN. Preserved as a documented
    // no-op rather than replicated, since replicating unreachable code adds
    // risk with zero behavioral effect either way. (This matches the known
    // language quirk that `arr(0)` parses as a function call, not element
    // access — see CLAUDE.md.)

    // Bare identifier reference — wrap any postfix factorial chain.
    auto node = std::move(identNode);
    while (current().type == FACT) {
      advance();
      node = wrapPostfixFactorial(std::move(node));
    }
    return node;
  }

  // Nothing above matched: a value (number, name, '(', '[', '|', string, or a
  // unary '-'/'!') was required here and something else was found. Say so
  // loudly - this used to fail silently, so `5*+6` just printed nothing.
  {
    const Token &bad = current();
    auto isBinaryOp = [](TokenType t) {
      return t == PLUS || t == MINUS || t == MUL || t == DIV || t == MOD ||
             t == QUOT || t == POW || t == DOT;
    };
    std::cerr << "✖ Syntax Error";
    if (bad.line)
      std::cerr << " (line " << bad.line << ", col " << bad.col << ")";
    std::cerr << ": ";
    if (bad.type == END || bad.type == SEMICOLON)
      std::cerr << "expression ended unexpectedly - a value is required here";
    else
      std::cerr << "unexpected '" << bad.text << "' - a value is required here";
    if (pos > 0 && isBinaryOp(tokens[pos - 1].type) && isBinaryOp(bad.type))
      std::cerr << " ('" << bad.text << "' cannot directly follow '"
                << tokens[pos - 1].text << "')";
    else if (pos > 0 && isBinaryOp(tokens[pos - 1].type))
      std::cerr << " (operator '" << tokens[pos - 1].text
                << "' is missing its right-hand operand)";
    std::cerr << "\n";
  }
  syntaxErrorCount_++;
  evaluationSucceeded_ = false;
  return nullptr;
}

// A bare identifier read: a resolved local/global variable, else a named
// constant, else a unit constant, else a bare no-parens call of a
// zero-input overload (e.g. `foo;` for `function foo`/`function B = foo()`),
// else "Unknown constant". Shared by evaluateExpr()'s Identifier case and
// the FieldAccess elementwise-dot-operator fallback below, both of which
// need to resolve a plain variable name the same way.
Value Parser::readVariableOrConstant(const std::string &name, int slot) {
  if (varExists(slot, name))
    return varGet(slot, name);

  double cval = 0.0;
  Value unitVal;
  if (resolveConstantValue(name, cval))
    return Value(cval);
  if (tryResolveUnitConstant(name, unitVal))
    return unitVal;

  // Bare no-parens call of a no-input overload, e.g. `foo;` or
  // `B = foo;` for `function foo` / `function B = foo()`.
  if (functionTable_.count(name) && findOverload(functionTable_[name], 0)) {
    bool found = false;
    Value result = callUserFunction(name, {}, found);
    if (!found)
      evaluationSucceeded_ = false;
    return result;
  }

  std::cerr << "Error: Unknown constant '" << name << "'\n";
  evaluationSucceeded_ = false;
  return Value(0);
}

// feval/grad/taylor_series/green_integral - all four need to call a
// user-supplied function reference (@name) repeatedly with different
// arguments, so they can't be plain free functions in ops/calculus/
// calculus.cpp (no Parser access there - see calculus.h's comment). They
// used to live inline in evaluateExpr()'s ExprKind::Call case, but that
// meant nc_bridge_call_dynamic() (value_bridge.cpp) - the JIT dynamic-
// dispatch path used whenever a call's name isn't statically known to be
// a compiled class/function - could never reach them: it only tries
// classTable_ -> functionTable_ -> callBuiltin(), never evaluateExpr()
// itself. A real bug found via direct testing: `grad(@f, [1,2,3])`
// worked fine under JIT (the literal `@f` argument is itself an
// unsupported codegen expression kind, forcing the WHOLE statement to
// fall back to the tree-walker, accidentally routing around the gap) but
// `fr = @f; grad(fr, [1,2,3]);` - or anything else where the function-
// reference argument is itself a codegen-compilable expression, e.g. a
// plain variable or an array index - compiled "successfully" as a
// generic dynamic-dispatch call and then failed at runtime with "Unknown
// function 'grad'", since nc_bridge_call_dynamic() never knew this name
// was reserved. Extracting this into one shared method that BOTH
// evaluateExpr() and nc_bridge_call_dynamic() call closes that gap for
// every call shape, not just the ones that happen to force a full
// tree-walker fallback some other way.
//
// Sets `handled` true (and returns the real result, with
// evaluationSucceeded_ already updated as needed) iff `name` was one of
// these four reserved names; false (result unused) otherwise, so the
// caller continues with its own normal class/function/builtin
// resolution.
Value Parser::tryReservedFunctionValueCall(const std::string &name, const std::vector<Value> &args,
                                            bool &handled) {
  handled = true;

  // feval(@f, arg1, arg2, ...) — invokes a function reference (see
  // ast.h's FunctionRef comment) with the given arguments. Reserved, same
  // precedent as "parent"/"new"/"clear" being fully reserved words
  // elsewhere in this language - this is the ONLY way to actually call a
  // value obtained via `@name` (there's no `fref(args)` call syntax; the
  // parser always treats IDENT( as a direct call-by-name, so a stored
  // reference needs an explicit "call this" builtin instead).
  if (name == "feval") {
    if (args.empty() || !args[0].isFunctionRef) {
      std::cerr << "Error: feval's first argument must be a function "
                   "reference (e.g. @funcname)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    std::vector<Value> callArgs(args.begin() + 1, args.end());
    bool found = false;
    Value result = callUserFunction(args[0].funcRefName(), callArgs, found);
    if (!found) {
      std::cerr << "Error: Unknown function '" << args[0].funcRefName() << "'\n";
      evaluationSucceeded_ = false;
    }
    return result;
  }

  // grad(@f, point[, h]) — numerical gradient of f at `point` (an
  // array [x1,...,xn]) via central difference on each dimension:
  // df/dxi ~= (f(...,xi+h,...) - f(...,xi-h,...)) / 2h. `f` must take
  // exactly `point.size()` separate scalar arguments (not one array
  // argument - sidesteps this language's own per-element array READ
  // gap entirely, since each perturbed coordinate is built and passed
  // positionally from C++, never read back out of an NC array by
  // index). Replaces the old grad() builtin (ops/calculus/calculus.cpp),
  // which was a pure no-op identity function - see its own comment for
  // why real calculus.cpp free functions can't do this at all (no
  // Parser access to call the user's function repeatedly).
  if (name == "grad") {
    if (args.size() < 2 || args.size() > 3 || !args[0].isFunctionRef || !args[1].isArray) {
      std::cerr << "Error: grad expects (function reference, point array[, step "
                   "size]), e.g. grad(@f, [1,2,3])\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    double h = (args.size() == 3) ? args[2].number : 1e-5;
    if (!(h > 0)) {
      std::cerr << "Error: grad's step size must be a positive number\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &fname = args[0].funcRefName();
    const std::vector<Value> point = args[1].elems();
    if (point.empty()) {
      std::cerr << "Error: grad's point array must not be empty\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    std::vector<Value> partials;
    partials.reserve(point.size());
    for (size_t i = 0; i < point.size(); i++) {
      std::vector<Value> argsPlus = point;
      std::vector<Value> argsMinus = point;
      argsPlus[i] = Value(point[i].number + h);
      argsMinus[i] = Value(point[i].number - h);
      bool foundPlus = false, foundMinus = false;
      Value fPlus = callUserFunction(fname, argsPlus, foundPlus);
      Value fMinus = callUserFunction(fname, argsMinus, foundMinus);
      if (!foundPlus || !foundMinus) {
        std::cerr << "Error: Unknown function '" << fname << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      if (!evaluationSucceeded_)
        return Value(0); // an arity mismatch/require failure already reported itself
      partials.push_back(Value((fPlus.number - fMinus.number) / (2.0 * h)));
    }
    return Value(partials);
  }

  // taylor_series(@f, x0, x, n) — the degree-(n-1) Taylor polynomial of
  // f centered at x0, evaluated at x:
  //   sum_{k=0}^{n-1} f^(k)(x0)/k! * (x-x0)^k
  // Each derivative f^(k)(x0) is estimated via the standard (2k+1)-
  // point central-difference stencil: f^(k)(x0) ~= (1/h^k) *
  // sum_{j=0}^{k} (-1)^j C(k,j) f(x0 + (k/2-j)h). Replaces the old
  // taylor_series() builtin (ops/calculus/calculus.cpp), which was
  // hardcoded to ONLY ever compute e^x's own Maclaurin series
  // regardless of what a caller might have wanted - see its own
  // comment.
  //
  // Step size is DERIVED PER ORDER, not a single fixed/user-supplied h -
  // a real numerical bug found via direct testing of the first cut of
  // this feature (which took one fixed h=1e-3 for every order): the
  // stencil divides by h^k, so an h that's fine for k=1-3 becomes
  // catastrophic by k=7-9 (h^9 = 1e-27, amplifying ordinary double-
  // precision rounding noise in the sampled f(x) values by a factor of
  // roughly 1e43) - confirmed empirically, e^x's own series at 10 terms
  // came back as -4.4e7 instead of e = 2.71828. The standard remedy: the
  // OPTIMAL step for a k-th-order central difference scales like
  // eps^(1/(k+2)) (eps = double machine epsilon) - LARGER for higher k,
  // trading a bit of truncation error for a lot less rounding-error
  // amplification. Capped at 10 terms (max 9th derivative) regardless:
  // even with the adaptive step, central-difference stencils accumulate
  // real cancellation from their alternating binomial sum at high order -
  // beyond roughly order 8-9 in double precision the result stops
  // meaningfully improving, so this fails loudly past that point instead
  // of quietly returning a number that looks precise but isn't.
  if (name == "taylor_series") {
    if (args.size() != 4 || !args[0].isFunctionRef) {
      std::cerr << "Error: taylor_series expects (function reference, center x0, "
                   "evaluation point x, term count), e.g. "
                   "taylor_series(@f, 0, 1, 6)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &fname = args[0].funcRefName();
    double x0 = args[1].number;
    double x = args[2].number;
    int n = static_cast<int>(args[3].number);
    if (n < 1 || n > 10) {
      std::cerr << "Error: taylor_series's term count must be between 1 and 10 "
                   "(higher-order central-difference derivatives lose too much "
                   "precision to double-precision cancellation to be trustworthy)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    auto evalF = [&](double at, bool &ok) -> double {
      bool found = false;
      Value r = callUserFunction(fname, {Value(at)}, found);
      if (!found) {
        std::cerr << "Error: Unknown function '" << fname << "'\n";
        evaluationSucceeded_ = false;
        ok = false;
        return 0.0;
      }
      if (!evaluationSucceeded_) {
        ok = false;
        return 0.0;
      }
      return r.number;
    };

    double sum = 0.0;
    double dx = x - x0;
    double dxPow = 1.0; // (x-x0)^k, built incrementally
    double factorial = 1.0;
    bool ok = true;

    for (int k = 0; k < n && ok; k++) {
      double deriv;
      if (k == 0) {
        deriv = evalF(x0, ok);
      } else {
        // Order-adaptive step size - see the comment above this whole
        // block for why a single fixed h across every order is wrong.
        double hk = std::pow(std::numeric_limits<double>::epsilon(), 1.0 / (k + 2));
        // Binomial-coefficient central-difference stencil for the
        // k-th derivative, computed with integer binomial
        // coefficients (exact for k <= 10, well within double range).
        double stencilSum = 0.0;
        long long binom = 1; // C(k,0)
        for (int j = 0; j <= k && ok; j++) {
          double sample = evalF(x0 + (k / 2.0 - j) * hk, ok);
          double sign = (j % 2 == 0) ? 1.0 : -1.0;
          stencilSum += sign * static_cast<double>(binom) * sample;
          // C(k,j+1) = C(k,j) * (k-j) / (j+1)
          binom = binom * (k - j) / (j + 1);
        }
        deriv = stencilSum / std::pow(hk, k);
      }
      if (!ok)
        break;
      if (k > 0) {
        dxPow *= dx;
        factorial *= k;
      }
      sum += deriv / factorial * dxPow;
    }
    if (!ok)
      return Value(0);
    return Value(sum);
  }

  // green_integral(@P, @Q, x0, x1, y0, y1[, n]) — Green's theorem as
  // an actual double integral over the axis-aligned rectangle
  // [x0,x1]x[y0,y1]:
  //   oint(P dx + Q dy) = doubleintegral_R (dQ/dx - dP/dy) dA
  // P and Q are function references taking two scalar arguments (x,y).
  // Replaces the old green_integral() builtin (ops/calculus/
  // calculus.cpp), which just computed Q-P from two RAW SCALAR
  // samples with no derivative, no region, and no integration at all -
  // there was no mathematical justification for that number
  // approximating anything (see its own comment for the full history).
  // This version actually differentiates (central difference, first
  // order - numerically robust, no adaptive-step machinery needed
  // unlike taylor_series's higher-order derivatives above) and
  // integrates (composite 2D Simpson's rule over an n x n grid, n
  // even) over a real region - restricted to an axis-aligned rectangle
  // rather than an arbitrary closed curve, a deliberate scope
  // narrowing: a general parametrized-boundary version needs the
  // caller to supply a curve (x(t),y(t)), a materially bigger design
  // this pass doesn't attempt.
  if (name == "green_integral") {
    if (args.size() < 6 || args.size() > 7 || !args[0].isFunctionRef ||
        !args[1].isFunctionRef) {
      std::cerr << "Error: green_integral expects (P reference, Q reference, x0, x1, "
                   "y0, y1[, grid intervals]), e.g. green_integral(@P, @Q, 0, 2, 0, 3)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &pname = args[0].funcRefName();
    const std::string &qname = args[1].funcRefName();
    double x0 = args[2].number, x1 = args[3].number;
    double y0 = args[4].number, y1 = args[5].number;
    int n = (args.size() == 7) ? static_cast<int>(args[6].number) : 20;
    if (!(x1 > x0) || !(y1 > y0)) {
      std::cerr << "Error: green_integral requires x1 > x0 and y1 > y0\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    if (n < 2 || n % 2 != 0) {
      std::cerr << "Error: green_integral's grid interval count must be a positive "
                   "even integer (composite Simpson's rule requires it)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    auto evalXY = [&](const std::string &fn, double xx, double yy, bool &ok) -> double {
      bool found = false;
      Value r = callUserFunction(fn, {Value(xx), Value(yy)}, found);
      if (!found) {
        std::cerr << "Error: Unknown function '" << fn << "'\n";
        evaluationSucceeded_ = false;
        ok = false;
        return 0.0;
      }
      if (!evaluationSucceeded_) {
        ok = false;
        return 0.0;
      }
      return r.number;
    };

    const double hd = 1e-5; // first-derivative step - robust at this order, no adaptation needed
    const double hx = (x1 - x0) / n;
    const double hy = (y1 - y0) / n;
    double integral = 0.0;
    bool ok = true;

    for (int i = 0; i <= n && ok; i++) {
      double xi = x0 + i * hx;
      double wx = (i == 0 || i == n) ? 1.0 : ((i % 2 == 1) ? 4.0 : 2.0);
      for (int j = 0; j <= n && ok; j++) {
        double yj = y0 + j * hy;
        double wy = (j == 0 || j == n) ? 1.0 : ((j % 2 == 1) ? 4.0 : 2.0);

        double dQdx = (evalXY(qname, xi + hd, yj, ok) - evalXY(qname, xi - hd, yj, ok)) /
                      (2.0 * hd);
        double dPdy = (evalXY(pname, xi, yj + hd, ok) - evalXY(pname, xi, yj - hd, ok)) /
                      (2.0 * hd);
        integral += wx * wy * (dQdx - dPdy);
      }
    }
    if (!ok)
      return Value(0);
    integral *= (hx / 3.0) * (hy / 3.0);
    return Value(integral);
  }

  // divergence(@F, point) / curl(@F, point) - the REAL vector-calculus
  // field operators (div F = sum_i dFi/dxi; curl F, 3D only), replacing
  // the pre-existing "divergence"/"curl" builtins (ops/vector/vector.cpp),
  // which - despite the same names - are NOT those operators at all: they
  // just sum/cyclic-difference a single constant vector's own components,
  // something their own code comments already flagged as a name-vs-math
  // mismatch pending exactly this kind of function-reference support. Only
  // intercepted here when the FIRST argument is actually a function
  // reference (`args[0].isFunctionRef`) - a plain array first argument
  // (the old calling convention) falls through unhandled, past this whole
  // method, to the pre-existing vectorBuiltin dispatch, so existing
  // scripts using the old single-vector form keep working unchanged. `F`
  // takes point.size() separate scalar arguments and returns an array of
  // the same size [F1,...,Fn] (the field's value at that point) - same
  // "separate scalar args, not one array arg" convention as grad() above,
  // for the same reason (sidesteps this language's array-read gap
  // entirely).
  if (name == "divergence" && !args.empty() && args[0].isFunctionRef) {
    if (args.size() != 2 || !args[1].isArray || args[1].length() == 0) {
      std::cerr << "Error: divergence expects (field reference, point array), e.g. "
                   "divergence(@F, [1,2,3])\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &fname = args[0].funcRefName();
    const std::vector<Value> point = args[1].elems();
    const double h = 1e-5;
    double sum = 0.0;
    for (size_t i = 0; i < point.size(); i++) {
      std::vector<Value> plus = point, minus = point;
      plus[i] = Value(point[i].number + h);
      minus[i] = Value(point[i].number - h);
      bool foundPlus = false, foundMinus = false;
      Value fPlus = callUserFunction(fname, plus, foundPlus);
      Value fMinus = callUserFunction(fname, minus, foundMinus);
      if (!foundPlus || !foundMinus) {
        std::cerr << "Error: Unknown function '" << fname << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      if (!evaluationSucceeded_)
        return Value(0);
      if (!fPlus.isArray || !fMinus.isArray || fPlus.length() != point.size() ||
          fMinus.length() != point.size()) {
        std::cerr << "Error: divergence's field function must return an array of "
                  << point.size() << " value(s), matching the point's dimensionality\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      // dFi/dxi: only the i-th COMPONENT of F's output, from perturbing
      // only the i-th coordinate of the input - this is exactly the
      // definition of divergence (the trace of F's Jacobian), not a full
      // Jacobian computation.
      sum += (fPlus.numAt(i) - fMinus.numAt(i)) / (2.0 * h);
    }
    return Value(sum);
  }

  if (name == "curl" && !args.empty() && args[0].isFunctionRef) {
    if (args.size() != 2 || !args[1].isArray || args[1].length() != 3) {
      std::cerr << "Error: curl expects (field reference, 3-element point array), e.g. "
                   "curl(@F, [1,2,3]) - curl is only defined in 3D\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &fname = args[0].funcRefName();
    const std::vector<Value> point = args[1].elems();
    const double h = 1e-5;

    // Evaluates F at `point` with coordinate `axis` (0=x,1=y,2=z) perturbed
    // by `delta`, returning component `component` of F's array result.
    bool ok = true;
    auto sample = [&](int axis, double delta, int component) -> double {
      std::vector<Value> p = point;
      p[axis] = Value(point[axis].number + delta);
      bool found = false;
      Value r = callUserFunction(fname, p, found);
      if (!found) {
        std::cerr << "Error: Unknown function '" << fname << "'\n";
        evaluationSucceeded_ = false;
        ok = false;
        return 0.0;
      }
      if (!evaluationSucceeded_) {
        ok = false;
        return 0.0;
      }
      if (!r.isArray || r.length() != 3) {
        std::cerr << "Error: curl's field function must return a 3-element array\n";
        evaluationSucceeded_ = false;
        ok = false;
        return 0.0;
      }
      return r.numAt(component);
    };

    // curl F = [dFz/dy - dFy/dz, dFx/dz - dFz/dx, dFy/dx - dFx/dy]
    double dFzdy = (sample(1, h, 2) - sample(1, -h, 2)) / (2.0 * h);
    double dFydz = ok ? (sample(2, h, 1) - sample(2, -h, 1)) / (2.0 * h) : 0.0;
    double dFxdz = ok ? (sample(2, h, 0) - sample(2, -h, 0)) / (2.0 * h) : 0.0;
    double dFzdx = ok ? (sample(0, h, 2) - sample(0, -h, 2)) / (2.0 * h) : 0.0;
    double dFydx = ok ? (sample(0, h, 1) - sample(0, -h, 1)) / (2.0 * h) : 0.0;
    double dFxdy = ok ? (sample(1, h, 0) - sample(1, -h, 0)) / (2.0 * h) : 0.0;
    if (!ok)
      return Value(0);

    std::vector<Value> curlResult;
    curlResult.push_back(Value(dFzdy - dFydz));
    curlResult.push_back(Value(dFxdz - dFzdx));
    curlResult.push_back(Value(dFydx - dFxdy));
    return Value(curlResult);
  }

  handled = false;
  return Value(0);
}

Value Parser::evaluateExpr(const Expr *node) {
  if (!node) {
    evaluationSucceeded_ = false;
    return Value(0);
  }

  switch (node->kind) {
    case ExprKind::Identifier:
      return readVariableOrConstant(node->text, node->slot);

    case ExprKind::NumberLiteral:
      return node->imaginary ? Value::complexNumber(0.0, node->number) : Value(node->number);

    case ExprKind::StringLiteral:
      return Value(node->text);

    case ExprKind::FunctionRef: {
      // Resolved against functionTable_ at evaluate time, never at parse
      // time - same forward-reference guarantee every other name lookup in
      // this language already has (a function declared later in the same
      // file is still a valid @-reference here, exactly like calling it
      // directly already works before this feature existed).
      if (!hasFunction(node->text)) {
        std::cerr << "Error: Unknown function '" << node->text << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      Value ref;
      ref.isFunctionRef = true;
      ref.funcRefNameMut() = node->text;
      return ref;
    }

    case ExprKind::Wildcard:
      // Only meaningful as a raw Index key, inspected directly by kind in
      // the Index case below and in executeIndexAssign() - never expected
      // to reach the generic evaluator itself (e.g. a bare `:` used
      // somewhere other than inside A[...]).
      std::cerr << "Error: ':' is only valid inside an index, e.g. A[n,:]\n";
      evaluationSucceeded_ = false;
      return Value(0);

    case ExprKind::UnaryOp: {
      Value inner = evaluateExpr(node->children[0].get());

      if (node->text == "!")
        return logical_not(inner);

      if (node->text == "!post") {
        // Factorial is only mathematically meaningful for a plain,
        // dimensionless number (or array/matrix thereof) - not a
        // unit-bearing quantity like `(5*m)!`, and not arbitrary text.
        // Text that's actually a dec2frac()-style "num/denom" fraction
        // (or a plain decimal written as text) is auto-coerced to its
        // numeric value first - factorial() itself still only ever sees a
        // real number, exactly as before, but `deci2frac(x)!` now works
        // instead of erroring, matching Python's Fraction staying usable
        // in further math despite printing as text. Genuinely non-numeric
        // text ("abc"!) is still rejected.
        if (inner.isText) {
          double d;
          if (!tryCoerceTextToNumber(inner, d)) {
            std::cerr << "Error: '!' (factorial) requires a number, not text\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
          inner = Value(d);
        }
        if (inner.hasComplex()) {
          std::cerr << "Error: '!' (factorial) is not defined for complex numbers\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (inner.dimL != 0 || inner.dimT != 0 || inner.dimM != 0) {
          std::cerr << "Error: '!' (factorial) requires a dimensionless "
                        "value\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return factorial(inner);
      }

      // "-"
      // A dec2frac()-style "num/denom" text operand is negated as the number
      // it stands for (same coercion the binary operators apply); before this
      // `-F` read the text Value's .number (0) and silently returned 0.
      if (inner.isText && inner.text().find('/') != std::string::npos) {
        double d;
        if (tryCoerceTextToNumber(inner, d))
          inner = Value(d);
      }
      // Arrays/matrices elementwise, numbers (real or complex) with their
      // unit preserved - shared with the JIT's nc_bridge_neg().
      return negate_op(inner);
    }

    case ExprKind::AbsOrNorm: {
      Value inner = evaluateExpr(node->children[0].get());
      // Shared with the JIT's nc_bridge_abs_or_norm().
      bool absOk = true;
      Value result = abs_or_norm(inner, absOk);
      if (!absOk)
        evaluationSucceeded_ = false;
      return result;
    }

    case ExprKind::RangeLiteral: {
      char leftBracket = node->text.size() > 0 ? node->text[0] : '[';
      char rightBracket = node->text.size() > 1 ? node->text[1] : ']';

      double start = evaluateExpr(node->rangeStart.get()).number;
      double step = 1.0;
      double end;
      if (node->rangeStep) {
        step = evaluateExpr(node->rangeStep.get()).number;
        end = evaluateExpr(node->rangeStop.get()).number;
      } else {
        end = evaluateExpr(node->rangeStop.get()).number;
      }

      if (step == 0.0) {
        std::cerr << "Error: range literal step cannot be zero\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      std::vector<Value> rangeArr;
      for (double rv : generateRange(start, step, end, leftBracket, rightBracket))
        rangeArr.push_back(Value(rv));
      return Value(rangeArr);
    }

    case ExprKind::ArrayLiteral: {
      std::vector<Value> arr;
      for (auto &child : node->children)
        arr.push_back(evaluateExpr(child.get()));
      return Value(arr);
    }

    case ExprKind::MatrixLiteral: {
      std::vector<std::vector<Value>> mat;
      for (auto &rowNode : node->children) {
        std::vector<Value> row;
        for (auto &cell : rowNode->children)
          row.push_back(evaluateExpr(cell.get()));
        mat.push_back(std::move(row));
      }
      return Value(mat);
    }

    case ExprKind::ParentCall: {
      std::vector<Value> args;
      for (auto &c : node->children)
        args.push_back(evaluateExpr(c.get()));
      return callParentConstructor(args);
    }

    case ExprKind::Call: {
      std::vector<Value> args;
      for (auto &c : node->children)
        args.push_back(evaluateExpr(c.get()));

      const std::string &name = node->text;

      // feval/grad/taylor_series/green_integral - see
      // tryReservedFunctionValueCall()'s own comment (below, right before
      // evaluateExpr()) for why these live in a shared method instead of
      // inline here: nc_bridge_call_dynamic() (value_bridge.cpp) needs to
      // reach this exact same logic too, for the JIT dynamic-dispatch path.
      {
        bool handledReserved = false;
        Value reservedResult = tryReservedFunctionValueCall(name, args, handledReserved);
        if (handledReserved)
          return reservedResult;
      }

      // Instantiation: ClassName(args) — checked ahead of functions/builtins
      // so a class name always wins on a collision (most specific match).
      if (classTable_.count(name)) {
        bool found = false;
        Value result = callClassConstructor(name, args, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      }

      // User-defined functions shadow builtins of the same name.
      if (functionTable_.count(name)) {
        bool found = false;
        Value result = callUserFunction(name, args, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      }

      Value result = callBuiltin(name, args);
      // g_lastVectorOk: a vector-domain builtin (dot/angle/proj/orthogonal/
      // eigen_value/...) can be genuinely FOUND (g_lastBuiltinFound stays
      // true) yet still reject its actual arguments as invalid (wrong
      // shape, mismatched lengths, ...) - see vector.h's own comment on
      // this flag for the crashes it replaces.
      if (!g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk || !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk)
        evaluationSucceeded_ = false;
      return result;
    }

    case ExprKind::FieldAccess: {
      Value receiver = evaluateExpr(node->children[0].get());

      if (!receiver.isObject) {
        // Not an object: parser_factor.cpp always builds this same
        // FieldAccess shape for a bare `X.Y` regardless of X's type (that
        // isn't known until now) - so this is actually the elementwise dot
        // operator, with `text` naming an ordinary variable for the
        // right-hand operand. Matches the original single-pass grammar's
        // fallback (parseTerm()'s DOT-operator handling) for this case.
        // node->slot (stamped by resolveFunctionSlots() the same way an
        // Identifier node's is) lets this resolve through the fast slot
        // path too when `text` names a local, instead of always falling
        // back to `memory`.
        Value rhs = readVariableOrConstant(node->text, node->slot);

        if (receiver.isMatrix && rhs.isMatrix)
          return ElementWise(receiver, rhs);

        std::cerr << "Error: Dot operator requires two matrices\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (!checkFieldAccess(receiver.className(), node->text))
        return Value(0);

      auto fit = receiver.dict().find(node->text);
      if (fit == receiver.dict().end()) {
        std::cerr << "Error: '" << receiver.className() << "' has no field '" << node->text << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return fit->second;
    }

    case ExprKind::MethodCall: {
      const Expr *receiverNode = node->children[0].get();
      Value v = evaluateExpr(receiverNode);
      // Only meaningful when receiverNode->kind == Identifier, same as the
      // pre-Phase-2 version (a receiver is always a bare identifier here —
      // see ast.h's Identifier note).
      const std::string &name = receiverNode->text;

      std::vector<Value> args;
      // Dict builtins take the receiver as arg 0; object methods don't
      // (it's `base`, not a positional arg) - decided here rather than at
      // parse time since it depends on the receiver's actual value.
      if (!v.isObject)
        args.push_back(v);
      for (size_t i = 1; i < node->children.size(); i++)
        args.push_back(evaluateExpr(node->children[i].get()));

      const std::string &method = node->text;

      /* reserved: obj.lineage() — Traceability */
      if (v.isObject && method == "lineage") {
        std::vector<Value> entries;
        for (const auto &entry : v.lineage())
          entries.push_back(Value(entry));
        return Value(entries);
      }

      /* reserved: obj.rewind() / obj.rewind(n) — Reversibility */
      if (v.isObject && method == "rewind") {
        if (!classTable_.count(v.className()) || !classTable_[v.className()].isReversible) {
          std::cerr << "Error: class '" << v.className()
                    << "' is not reversible (declare it 'reversible class " << v.className()
                    << "(...)')\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (v.snapshots().empty()) {
          std::cerr << "Error: '" << name << "' has no reversibility history to rewind to\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        size_t targetIndex = 0; // no-arg: all the way back to right after init
        if (!args.empty()) {
          long steps = static_cast<long>(args[0].number);
          if (steps < 0) steps = 0;
          long idx = static_cast<long>(v.snapshots().size()) - 1 - steps;
          targetIndex = static_cast<size_t>(idx < 0 ? 0 : idx);
        }

        Value restored = v;
        restored.dictMut() = v.snapshots()[targetIndex];
        restored.lineageMut().resize(targetIndex + 1);
        restored.snapshotsMut().resize(targetIndex + 1);

        varSet(receiverNode->slot, name, restored);
        // Every other mutating method in this feature set is written
        // `x = x.method();` (e.g. `c = c.inc();`), since a method's declared
        // output is `base` itself. Returning Value(0) here instead of
        // `restored` made that same, otherwise-universal idiom silently
        // destroy the object: `c = c.rewind();` would overwrite the
        // just-restored `c` (already correctly written above) with a bare
        // 0. Returning `restored` makes both `c.rewind();` and
        // `c = c.rewind();` do the same, correct thing.
        return restored;
      }

      /* reserved: obj.tick(currentTime) — Temporal Determinism */
      if (v.isObject && method == "tick") {
        double rateHz = 0.0;
        if (!findRateInChain(v.className(), rateHz)) {
          std::cerr << "Error: class '" << v.className()
                    << "' has no '@rate(...)' — not temporally scheduled\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (args.empty()) {
          std::cerr << "Error: '.tick(currentTime)' requires the current simulated time as an "
                       "argument\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        double currentTime = args[0].number;
        double period = 1.0 / rateHz;
        bool due = (v.lastTickTime() < 0.0) || (currentTime - v.lastTickTime() + 1e-9 >= period);
        if (!due)
          return Value(0); // too early — skipped, instance left unchanged

        bool found = false;
        Value selfAfter;
        callInstanceMethod(v, "step", {}, selfAfter, found);
        if (!found) {
          std::cerr << "Error: class '" << v.className() << "' has no step() method to run on tick\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (!evaluationSucceeded_)
          return Value(0); // step() itself failed — don't pretend the tick succeeded

        selfAfter.lastTickTimeMut() = currentTime;
        varSet(receiverNode->slot, name, selfAfter);
        return Value(1);
      }

      /* object method call: obj.Method(args) — mutations to base.field
         inside the method are written back to the receiver's storage. */
      if (v.isObject) {
        bool found = false;
        Value selfAfter;
        Value result = callInstanceMethod(v, method, args, selfAfter, found);
        if (!found) {
          std::cerr << "Error: class '" << v.className() << "' has no method '" << method << "'\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        varSet(receiverNode->slot, name, selfAfter); // persist any base.field mutations
        return result;
      }

      /* dict builtin method call: A.keys(), A.values(), A.size(), ... */
      Value result = callBuiltin(method, args);
      if (!g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk || !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk)
        evaluationSucceeded_ = false;
      return result;
    }

    case ExprKind::Index: {
      const Expr *receiverNode = node->children[0].get();
      Value v = evaluateExpr(receiverNode);
      const std::string &name = receiverNode->text;
      size_t numKeys = node->children.size() - 1;

      /* Matrix: A[row] (chained A[row][col] evaluates this first, then
         indexes the returned row array), A[row,col], A[n,:], A[:,n]. Which
         shape applies is decided by numKeys and whether a key is a
         Wildcard (bare ':') - see ast.h. */
      if (v.isMatrix) {
        if (numKeys == 1) {
          const Expr *k0 = node->children[1].get();
          if (k0->kind == ExprKind::Wildcard)
            return v;
          Value rowVal = evaluateExpr(k0);
          int row = static_cast<int>(rowVal.number);
          if (row < 0 || static_cast<size_t>(row) >= v.rows()) {
            std::cerr << "Error: matrix index out of range for '" << name << "'\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
          return Value(v.row(row));
        }

        if (numKeys == 2) {
          const Expr *k0 = node->children[1].get();
          const Expr *k1 = node->children[2].get();
          bool wildRow = (k0->kind == ExprKind::Wildcard);
          bool wildCol = (k1->kind == ExprKind::Wildcard);

          if (wildRow && wildCol)
            return v;

          if (wildRow) {
            // A[:,col] - whole column, top to bottom.
            Value colVal = evaluateExpr(k1);
            int col = static_cast<int>(colVal.number);
            if (col < 0 || v.rows() == 0 || static_cast<size_t>(col) >= v.cols()) {
              std::cerr << "Error: matrix column out of range for '" << name << "'\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }
            std::vector<Value> colVec;
            for (size_t r = 0; r < v.rows(); r++)
              colVec.push_back(v.at(r, col));
            return Value(colVec);
          }

          if (wildCol) {
            // A[row,:] - whole row.
            Value rowVal = evaluateExpr(k0);
            int row = static_cast<int>(rowVal.number);
            if (row < 0 || static_cast<size_t>(row) >= v.rows()) {
              std::cerr << "Error: matrix row out of range for '" << name << "'\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }
            return Value(v.row(row));
          }

          // A[row,col] - single element (comma form, same result as the
          // chained A[row][col] form).
          Value rowVal = evaluateExpr(k0);
          Value colVal = evaluateExpr(k1);
          int row = static_cast<int>(rowVal.number);
          int col = static_cast<int>(colVal.number);
          if (row < 0 || static_cast<size_t>(row) >= v.rows() ||
              col < 0 || static_cast<size_t>(col) >= v.rowLength(row)) {
            std::cerr << "Error: matrix index out of range for '" << name << "'\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
          return v.at(row, col);
        }

        std::cerr << "Error: matrix '" << name << "' does not support " << numKeys
                   << "-key indexing\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      /* Array: A[i] (also the second half of a chained A[row][col] read,
         once the row-select above has already turned the receiver into an
         array). */
      if (v.isArray) {
        if (numKeys != 1) {
          std::cerr << "Error: array '" << name << "' indexing takes exactly one key\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        const Expr *k0 = node->children[1].get();
        if (k0->kind == ExprKind::Wildcard)
          return v;
        Value idxVal = evaluateExpr(k0);
        int idx = static_cast<int>(idxVal.number);
        if (idx < 0 || static_cast<size_t>(idx) >= v.length()) {
          std::cerr << "Error: array index out of range for '" << name << "'\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return v.at(idx);
      }

      if (!v.isDict) {
        std::cerr << "Error: '" << name << "' is not a dict\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (numKeys != 1) {
        std::cerr << "Error: dict '" << name << "' read takes exactly one key\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      Value key = evaluateExpr(node->children[1].get());
      std::string k = dictKeyOf(key);
      auto dictIt = v.dict().find(k);
      if (dictIt == v.dict().end()) {
        std::cerr << "Error: dict key '" << k << "' not found in '" << name << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return dictIt->second;
    }

    // Produced by the outer precedence chain (parser_expression.cpp), which
    // also owns the evaluation logic for these three kinds.
    case ExprKind::BinaryOp:
      return evaluateBinaryOp(node);
    case ExprKind::Comparison:
      return evaluateComparison(node);
    case ExprKind::LogicalOp:
      return evaluateLogicalOp(node);
  }

  evaluationSucceeded_ = false;
  return Value(0);
}
