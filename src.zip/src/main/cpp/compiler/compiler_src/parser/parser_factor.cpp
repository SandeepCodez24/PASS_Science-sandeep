// parseFactor(): the grammar's leaf/base case - literals, unary/prefix/
// postfix operators, array/matrix/range literals, and identifier handling
// (function calls, variable/constant lookup, dict methods and key read,
// array/matrix indexing).
#include "parser.h"
#include "parser_internal.h"

#include <cctype>
#include <iostream>

#include "../builtins/builtins.h"
#include "../builtins/constants_builtin.h"
#include "../conditional_opr/conditional_opr.h"
#include "../ops/arithmetic/arithmetic.h"

/* ================= FACTOR ================= */

static bool resolveConstantValue(const std::string &name, double &out) {
  return tryResolveConstantValue(name, out);
}

// Dimensional Integrity: unit constants — resolved like any other constant
// (pi, e, ...) but returning a Value(1.0) tagged with a physical dimension
// instead of a plain number. Composed via ordinary arithmetic rather than a
// dedicated literal: `v * m/s` (not `v<m/s>` from the design doc — that
// syntax collides with the existing `<`/`>` comparison tokens used
// pervasively elsewhere in this language, so it was deliberately not
// implemented as written). Checked only as a fallback after normal
// variable/constant lookup fails, so assigning to a variable named e.g.
// `s` shadows the unit meaning for that name, same precedence as any other
// constant.
static bool tryResolveUnitConstant(const std::string &name, Value &out) {
  int dimL = 0, dimT = 0, dimM = 0;
  if (name == "m") { dimL = 1; }
  else if (name == "s") { dimT = 1; }
  else if (name == "kg") { dimM = 1; }
  else if (name == "N") { dimM = 1; dimL = 1; dimT = -2; }   // force = kg*m/s^2
  else if (name == "Pa") { dimM = 1; dimL = -1; dimT = -2; } // pressure = N/m^2
  else return false;

  out = Value(1.0);
  out.dimL = dimL;
  out.dimT = dimT;
  out.dimM = dimM;
  return true;
}

Value Parser::parseFactor() {
  Value v;

  if (current().type == STRING) {
    v = Value(current().text);
    advance();
    return v;
  }

  if (current().type == FACT) {
    // Bare '!' in prefix position (nothing parsed yet this factor) means
    // logical NOT, e.g. `!(a == c)`. Postfix '!' (factorial, e.g. `5!`) is
    // handled separately below/after a value has already been parsed.
    advance();
    Value inner = parseFactor();
    return logical_not(inner);
  }

  if (current().type == MINUS) {
    advance();

    Value inner = parseFactor();

    if (inner.isArray) {
      for (auto &x : inner.array)
        x.number = -x.number;
      return inner;
    }

    if (inner.isMatrix) {
      for (auto &row : inner.matrix)
        for (auto &x : row)
          x.number = -x.number;
      return inner;
    }

    // Dimensional Integrity: preserve the operand's unit through negation
    // (-v where v is a velocity is still a velocity).
    Value negated(-inner.number);
    negated.dimL = inner.dimL;
    negated.dimT = inner.dimT;
    negated.dimM = inner.dimM;
    return negated;
  }

  if (current().type == NUMBER) {
    v = Value(std::stod(current().text));
    advance();

    while (current().type == FACT) {
      advance();
      v = factorial(v);
    }

    return v;
  }

  if (current().type == LPAREN) {
    advance();
    v = parseOr();
    if (current().type == RPAREN)
      advance();
    return v;
  }

  /* array / matrix literals */
  if (current().type == LBRACKET) {
    advance();

    // Range literal: [start:end] or [start:step:end], with an optional
    // exclusive-end ')' close (e.g. [1:5)). start/step/end can be any
    // expression now (numeric literal, variable, arithmetic, ...), not just
    // a bare number, so detecting "is this a range literal at all" can't
    // just peek one token for NUMBER+COLON anymore. Instead, scan ahead
    // (token types only, no evaluation — so no risk of double-running a
    // side-effecting expression like a function call) for a top-level ':'
    // before the matching close bracket or a top-level ',' (which would
    // mean this is a plain array/matrix literal instead).
    {
      bool isRangeLiteral = false;
      int depth = 0;
      for (size_t sp = pos; sp < tokens.size(); sp++) {
        TokenType t = tokens[sp].type;
        if (t == LBRACKET || t == LPAREN) {
          depth++;
        } else if (t == RBRACKET || t == RPAREN) {
          if (depth == 0) break;
          depth--;
        } else if (depth == 0 && t == COMMA) {
          break;
        } else if (depth == 0 && t == COLON) {
          isRangeLiteral = true;
          break;
        } else if (t == END) {
          break;
        }
      }

      if (isRangeLiteral) {
        Value startResult = parseOr();
        if (!evaluationSucceeded_)
          return Value(0); // parseOr() already printed the specific error
        double startVal = startResult.number;

        if (current().type != COLON) {
          std::cerr << "Error: expected ':' in range literal\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        advance(); // consume ':'

        Value secondResult = parseOr();
        if (!evaluationSucceeded_)
          return Value(0);
        double second = secondResult.number;

        double step = 1.0;
        double endVal = second;

        if (current().type == COLON) {
          advance();
          step = second;

          Value endResult = parseOr();
          if (!evaluationSucceeded_)
            return Value(0);
          endVal = endResult.number;
        }

        char rightBracket = ']';
        if (current().type == RBRACKET) { rightBracket = ']'; advance(); }
        else if (current().type == RPAREN) { rightBracket = ')'; advance(); }
        else {
          std::cerr << "Error: expected ']' or ')' to close range literal\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        if (step == 0.0) {
          std::cerr << "Error: range literal step cannot be zero\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        std::vector<Value> rangeArr;
        for (double rv : generateRange(startVal, step, endVal, '[', rightBracket))
          rangeArr.push_back(Value(rv));

        return Value(rangeArr);
      }
    }

    std::vector<Value> arr;
    std::vector<std::vector<Value>> mat;
    bool isMatrix = false;

    while (current().type != RBRACKET && current().type != END) {
      if (current().type == LBRACKET) {
        isMatrix = true;
        advance();

        std::vector<Value> row;

        while (current().type != RBRACKET && current().type != END) {
          Value val = parseOr();
          row.push_back(val);

          if (current().type == COMMA)
            advance();
          else
            break;
        }

        if (current().type == RBRACKET)
          advance();

        if (row.empty()) {
          std::cerr << "Error: Empty row in matrix literal\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        if (!mat.empty() && row.size() != mat[0].size()) {
          std::cerr << "Error: Jagged matrix literal (row length mismatch)\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        mat.push_back(std::move(row));
      } else {
        Value val = parseOr();
        arr.push_back(val);
      }

      if (current().type == COMMA)
        advance();
    }

    if (current().type == RBRACKET)
      advance();

    if (isMatrix) {
      if (!mat.empty()) {
        const size_t cols = mat[0].size();
        if (cols == 0) {
          std::cerr << "Error: Matrix literal with zero columns\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        for (const auto &row : mat) {
          if (row.size() != cols) {
            std::cerr << "Error: Jagged matrix literal (row length mismatch)\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
        }
      }
      return Value(mat);
    }

    return Value(arr);
  }

  if (current().type == IDENT) {
    std::string name = current().text;
    advance();

    /* function call */
    if (current().type == LPAREN) {
      advance();

      // "dict" accepts a ':' as sugar for ',' between its two constructor
      // args: dict(keysArr: valsArr) as well as dict(keysArr, valsArr).
      std::string nameLower = name;
      for (char &ch : nameLower) ch = static_cast<char>(std::tolower((unsigned char)ch));
      bool isDictCall = (nameLower == "dict");

      std::vector<Value> args;
      while (current().type != RPAREN && current().type != END) {
        args.push_back(parseOr());
        if (current().type == COMMA)
          advance();
        else if (isDictCall && current().type == COLON)
          advance();
        else
          break;
      }

      if (current().type == RPAREN)
        advance();

      // parent(args) — reserved call name (not a token, same precedent as
      // `new`/`clear`), chains into the current method/constructor's
      // defining class's parent constructor. Checked first since it's
      // never a real class/function/builtin name.
      if (name == "parent") {
        return callParentConstructor(args);
      }

      // Instantiation: ClassName(args) — checked ahead of functions/builtins
      // so a class name always wins on a collision (most specific match).
      if (classTable_.count(name)) {
        bool found = false;
        Value result = callClassConstructor(name, args, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      }

      // User-defined functions shadow builtins of the same name.
      if (functionTable_.count(name)) {
        bool found = false;
        Value result = callUserFunction(name, args, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      }

      Value result = callBuiltin(name, args);
      if (!g_lastBuiltinFound)
        evaluationSucceeded_ = false;

      return result;
    }

    /* variable lookup */
    if (memory.count(name)) {
      v = memory[name];
    } else {
      // Constants: resolved directly (case-insensitive + alias-safe)
      double cval = 0.0;
      Value unitVal;
      if (resolveConstantValue(name, cval)) {
        v = Value(cval);
      } else if (tryResolveUnitConstant(name, unitVal)) {
        v = unitVal;
      } else if (functionTable_.count(name) && findOverload(functionTable_[name], 0)) {
        // Bare no-parens call of a no-input overload, e.g. `foo;` or
        // `B = foo;` for `function foo` / `function B = foo()`.
        // functionTable_[name] may hold other overloads too (polymorphism)
        // — this only fires when a zero-arg one specifically exists.
        bool found = false;
        Value result = callUserFunction(name, {}, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      } else {
        std::cerr << "Error: Unknown constant '" << name << "'\n";
        evaluationSucceeded_ = false;
        return Value();
      }
    }

    /* object field read: obj.field — a bare dot-access with no trailing
       '(', so it can't be a method call. Must be checked ahead of the
       method-call branch below (and of the general DOT/matrix-elementwise-
       multiply operator further up the precedence chain, which is what a
       bare object.field would otherwise silently fall through to and
       misparse as `object . field` matrix multiplication). */
    if (v.isObject && current().type == DOT && pos + 1 < tokens.size() &&
        tokens[pos + 1].type == IDENT &&
        !(pos + 2 < tokens.size() && tokens[pos + 2].type == LPAREN)) {
      advance(); // consume '.'
      std::string fieldName = current().text;
      advance(); // consume field name

      if (!checkFieldAccess(v.className, fieldName))
        return Value(0);

      auto fit = v.dictMap.find(fieldName);
      if (fit == v.dictMap.end()) {
        std::cerr << "Error: '" << v.className << "' has no field '" << fieldName << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return fit->second;
    }

    /* reserved object method: obj.lineage() — Traceability. Always
       available on any instance, auto-maintained by
       callClassConstructor/callInstanceMethod (parser_class.cpp); checked
       ahead of the general method-call dispatch below so a user-defined
       class method can never shadow it. Returns the instance's history as
       an array of text entries, e.g. ["init(23.5)", "Scale(2) -> 47"]. */
    if (v.isObject && current().type == DOT && pos + 2 < tokens.size() &&
        tokens[pos + 1].type == IDENT && tokens[pos + 1].text == "lineage" &&
        tokens[pos + 2].type == LPAREN) {
      advance(); // consume '.'
      advance(); // consume 'lineage'
      advance(); // consume '('
      if (current().type == RPAREN)
        advance();

      std::vector<Value> entries;
      for (const auto &entry : v.lineage)
        entries.push_back(Value(entry));
      return Value(entries);
    }

    /* reserved object method: obj.rewind() / obj.rewind(n) — Reversibility
       (opt-in, `reversible class Name(...)` only). No-arg form restores
       the instance's fields to right after construction; obj.rewind(n)
       undoes the n most recent method calls instead. Rewinding truncates
       the instance's own lineage/snapshots to the restored point — like a
       standard undo stack, a fresh method call after rewinding starts a new
       history from there rather than appending after the discarded
       "future". Writes the restored instance back into memory[name], same
       write-back path as an ordinary mutating method call. */
    if (v.isObject && current().type == DOT && pos + 2 < tokens.size() &&
        tokens[pos + 1].type == IDENT && tokens[pos + 1].text == "rewind" &&
        tokens[pos + 2].type == LPAREN) {
      advance(); // consume '.'
      advance(); // consume 'rewind'
      advance(); // consume '('

      std::vector<Value> rewindArgs;
      while (current().type != RPAREN && current().type != END) {
        rewindArgs.push_back(parseOr());
        if (current().type == COMMA)
          advance();
        else
          break;
      }
      if (current().type == RPAREN)
        advance();

      if (!classTable_.count(v.className) || !classTable_[v.className].isReversible) {
        std::cerr << "Error: class '" << v.className
                  << "' is not reversible (declare it 'reversible class " << v.className
                  << "(...)')\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (v.snapshots.empty()) {
        std::cerr << "Error: '" << name << "' has no reversibility history to rewind to\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      size_t targetIndex = 0; // no-arg: all the way back to right after init
      if (!rewindArgs.empty()) {
        long steps = static_cast<long>(rewindArgs[0].number);
        if (steps < 0) steps = 0;
        long idx = static_cast<long>(v.snapshots.size()) - 1 - steps;
        targetIndex = static_cast<size_t>(idx < 0 ? 0 : idx);
      }

      Value restored = v;
      restored.dictMap = v.snapshots[targetIndex];
      restored.lineage.resize(targetIndex + 1);
      restored.snapshots.resize(targetIndex + 1);

      memory[name] = restored;
      return Value(0);
    }

    /* reserved object method: obj.tick(currentTime) — Temporal Determinism
       (opt-in via '@rate(...)' on the class). This interpreter has no real
       scheduler — the caller drives simulated time explicitly. Only
       actually runs the class's step() method (via the ordinary
       callInstanceMethod path, so it gets full override resolution,
       lineage logging, and reversibility snapshotting for free) when
       enough simulated time has passed since this instance's last tick, per
       its configured rate. Returns 1 if step() ran, 0 if this call was too
       early and got skipped (the instance is left completely unchanged in
       that case — no write-back, since nothing happened). */
    if (v.isObject && current().type == DOT && pos + 2 < tokens.size() &&
        tokens[pos + 1].type == IDENT && tokens[pos + 1].text == "tick" &&
        tokens[pos + 2].type == LPAREN) {
      advance(); // consume '.'
      advance(); // consume 'tick'
      advance(); // consume '('

      std::vector<Value> tickArgs;
      while (current().type != RPAREN && current().type != END) {
        tickArgs.push_back(parseOr());
        if (current().type == COMMA)
          advance();
        else
          break;
      }
      if (current().type == RPAREN)
        advance();

      double rateHz = 0.0;
      if (!findRateInChain(v.className, rateHz)) {
        std::cerr << "Error: class '" << v.className
                  << "' has no '@rate(...)' — not temporally scheduled\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      if (tickArgs.empty()) {
        std::cerr << "Error: '.tick(currentTime)' requires the current simulated time as an "
                     "argument\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      double currentTime = tickArgs[0].number;
      double period = 1.0 / rateHz;
      bool due = (v.lastTickTime < 0.0) || (currentTime - v.lastTickTime + 1e-9 >= period);
      if (!due)
        return Value(0); // too early — skipped, instance left unchanged

      bool found = false;
      Value selfAfter;
      callInstanceMethod(v, "step", {}, selfAfter, found);
      if (!found) {
        std::cerr << "Error: class '" << v.className << "' has no step() method to run on tick\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      if (!evaluationSucceeded_)
        return Value(0); // step() itself failed — don't pretend the tick succeeded

      selfAfter.lastTickTime = currentTime;
      memory[name] = selfAfter;
      return Value(1);
    }

    /* dict method call: A.keys(), A.values(), A.size(), A.match_key(k)
       object method call: obj.Method(args) — mutations to base.field
       inside the method are written back to memory[name] so they persist
       across future calls on the same instance. */
    if (current().type == DOT && pos + 2 < tokens.size() &&
        tokens[pos + 1].type == IDENT && tokens[pos + 2].type == LPAREN) {
      advance(); // consume '.'
      std::string method = current().text;
      advance(); // consume method name
      advance(); // consume '('

      std::vector<Value> args;
      if (!v.isObject)
        args.push_back(v); // dict builtins take the receiver as arg 0; object methods don't (it's `base`, not a positional arg)
      while (current().type != RPAREN && current().type != END) {
        args.push_back(parseOr());
        if (current().type == COMMA)
          advance();
        else
          break;
      }

      if (current().type == RPAREN)
        advance();

      if (v.isObject) {
        bool found = false;
        Value selfAfter;
        Value result = callInstanceMethod(v, method, args, selfAfter, found);
        if (!found) {
          std::cerr << "Error: class '" << v.className << "' has no method '" << method << "'\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        memory[name] = selfAfter; // persist any base.field mutations
        return result;
      }

      Value result = callBuiltin(method, args);
      if (!g_lastBuiltinFound)
        evaluationSucceeded_ = false;

      return result;
    }

    /* dict key read: A['key'] */
    if (current().type == LBRACKET) {
      advance();
      Value key = parseOr();

      if (current().type == RBRACKET)
        advance();
      else {
        std::cerr << "Error: expected ']' after dict key\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (!v.isDict) {
        std::cerr << "Error: '" << name << "' is not a dict\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      std::string k = dictKeyOf(key);
      auto dictIt = v.dictMap.find(k);
      if (dictIt == v.dictMap.end()) {
        std::cerr << "Error: dict key '" << k << "' not found in '" << name << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      return dictIt->second;
    }

    /* indexing */
    if (current().type == LPAREN) {
      advance();
      Value idx = parseOr();

      if (current().type == RPAREN)
        advance();

      int i = static_cast<int>(idx.number);

      if (v.isArray) {
        if (i >= 0 && static_cast<size_t>(i) < v.array.size())
          return v.array[i];

        std::cerr << "Array index out of range\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (v.isMatrix) {
        if (current().type == LPAREN) {
          advance();
          Value colVal = parseOr();
          if (current().type == RPAREN)
            advance();

          int row = static_cast<int>(idx.number);
          int col = static_cast<int>(colVal.number);

          if (row >= 0 && static_cast<size_t>(row) < v.matrix.size() &&
              col >= 0 && static_cast<size_t>(col) < v.matrix[row].size()) {
            return v.matrix[row][col];
          }

          std::cerr << "Matrix index out of range\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
      }
    }

    // factorial chaining after variable/constant
    while (current().type == FACT) {
      advance();
      v = factorial(v);
    }

    return v;
  }

  evaluationSucceeded_ = false;
  return Value(0);
}
