// parseFactor(): the grammar's leaf/base case - literals, unary/prefix/
// postfix operators, array/matrix/range literals, and identifier handling
// (function calls, variable/constant lookup, dict methods and key read,
// array/matrix indexing).
//
// Phase 2/3 (AST rewrite roadmap): split into parseFactorNode() (builds an
// Expr tree - see ast.h) and evaluateExpr() (does what parseFactor() used
// to do inline while parsing: memory access, function/method calls, error
// reporting). Parser::parseFactor() is a thin "build then evaluate
// immediately" wrapper for existing eager callers; Phase 3's Program parser
// (parser_program.cpp) instead builds a tree once, up front, and hands it
// to a separate evaluator to run later - possibly many times, e.g. once per
// loop iteration or function call.
//
// That reuse requirement is why parseFactorNode() does zero memory/constant/
// function-table lookups anywhere, even though the original single-pass
// grammar was genuinely context-sensitive on runtime values - e.g. whether
// `A.field` means object field access or the elementwise dot operator
// depends on A's actual type. Baking that decision into parse-time token
// consumption (as the original did, and an earlier revision of this file
// briefly did too) would freeze the answer as of whenever the tree was
// built, wrong for any later re-evaluation where A's type has changed.
// Every such decision - which branch a DOT expression is, whether a bare
// identifier is a variable, a constant, or a zero-arg function call - is
// made in evaluateExpr() instead, using values as they actually are at each
// evaluation. See ast.h's Identifier note and evaluateExpr()'s FieldAccess/
// MethodCall cases for the specifics, including the one deliberate grammar
// simplification this required (documented at the IDENT branch below).
#include "parser.h"
#include "parser_internal.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iostream>
#include <limits>

#include "../../../runtime/data/DataEngine.h"
#include "../../../runtime/interpreter/Numpy/importing_data/io_ndat.h"
#include "../builtins/builtins.h"
#include "../../../runtime/execution/parallel/par.h"
#include "../builtins/constants_builtin.h"
#include "../conditional_opr/conditional_opr.h"
#include "../core/elementwise.h"
#include "../ops/arithmetic/arithmetic.h"
#include "../ops/dc/dc.h"
#include "../ops/geometric/geometric.h"
#include "../ops/matrix/matrix.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/time/time.h"
#include "../ops/vector/vector.h"
#include "../Numpy/numpy_main.h"
#include "../Numpy/numpy_poly1d.h"
#include "../Scipy/scipy_main.h"

/* ================= FACTOR ================= */

static bool resolveConstantValue(const std::string &name, double &out) {
  return tryResolveConstantValue(name, out) || nc::scipy::tryConstant(name, out);
}

// Lets SciPy-style kernels call an NC function by name (scipy_main.h).
static bool scipyCallback(void *host, const Value &fnRef, const std::vector<Value> &args,
                          Value &out) {
  Parser *parser = static_cast<Parser *>(host);
  const unsigned long errorsBefore = nc::errorlines::count();
  out = parser->callFunctionValue(fnRef, args);
  return parser->evaluationSucceeded_ && nc::errorlines::count() == errorsBefore;
}

int Parser::userFunctionInputCount(const std::string &name) const {
  auto it = functionTable_.find(name);
  return it == functionTable_.end() || it->second.empty() ? -1 : static_cast<int>(it->second.front().inputNames.size());
}

void Parser::bindScipyCallbacks() {
  nc::scipy::setCallbackHost(this, scipyCallback, [](void *host, const std::string &name) {
    return static_cast<Parser *>(host)->userFunctionInputCount(name);
  });
}

// Dimensional Integrity: unit constants — resolved like any other constant
// (pi, e, ...) but returning a Value(1.0) tagged with a physical dimension
// instead of a plain number. Composed via ordinary arithmetic rather than a
// dedicated literal: `v * m/s` (not `v<m/s>` from the design doc — that
// syntax collides with the existing `<`/`>` comparison tokens used
// pervasively elsewhere in this language, so it was deliberately not
// implemented as written). Checked only as a fallback after normal
// variable/constant lookup fails, so assigning to a variable named e.g.
// `s` shadows the unit meaning for that name, same precedence as any other
// constant.
static bool tryResolveUnitConstant(const std::string &name, Value &out) {
  int dimL = 0, dimT = 0, dimM = 0;
  if (name == "m") { dimL = 1; }
  else if (name == "s") { dimT = 1; }
  else if (name == "kg") { dimM = 1; }
  else if (name == "N") { dimM = 1; dimL = 1; dimT = -2; }   // force = kg*m/s^2
  else if (name == "Pa") { dimM = 1; dimL = -1; dimT = -2; } // pressure = N/m^2
  else return false;

  out = Value(1.0);
  out.dimL = dimL;
  out.dimT = dimT;
  out.dimM = dimM;
  return true;
}

namespace {

std::unique_ptr<Expr> makeExpr(ExprKind kind) {
  auto node = std::make_unique<Expr>();
  node->kind = kind;
  return node;
}

// Text split into characters (UTF-8 code points), for s[i]: "π" is one.
std::vector<std::string> utf8Characters(const std::string &s) {
  std::vector<std::string> out;
  for (size_t i = 0; i < s.size();) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
    len = std::min(len, s.size() - i);
    out.push_back(s.substr(i, len));
    i += len;
  }
  return out;
}

// Wraps `inner` in a postfix "!" (factorial) UnaryOp node, once per '!' in a
// row - e.g. `5!!` is Factorial(Factorial(5)), matching the while-loop
// chaining both NUMBER and bare-identifier factors did inline before.
std::unique_ptr<Expr> wrapPostfixFactorial(std::unique_ptr<Expr> inner) {
  auto node = makeExpr(ExprKind::UnaryOp);
  node->text = "!post";
  node->children.push_back(std::move(inner));
  return node;
}

} // namespace

// One key inside A[ ... ]. Shapes:
//   (nothing)        A[m,]  A[,n]  -> Wildcard (a whole row / column)
//   :                A[:,n]        -> Wildcard
//   expr             A[2]
//   a:b  a:  :b      A[2:5]  A[5:]  A[:3]          -> Slice
//   a:s:b  ::        A[0:2:8]  A[::]  A[::-1]      -> Slice (start:step:stop)
// Any part of a slice may be left out (an open end). A slice with every part
// left out is just a Wildcard.
bool Parser::parsePostfixChain(std::unique_ptr<Expr> &node, size_t line) {
  for (;;) {
    const bool dotName = current().type == DOT && pos + 1 < tokens.size() &&
                         tokens[pos + 1].type == IDENT;
    if (dotName && !(pos + 2 < tokens.size() && tokens[pos + 2].type == LPAREN)) {
      advance(); // '.'
      auto field = makeExpr(ExprKind::FieldAccess);
      field->text = current().text;
      advance(); // field name
      field->children.push_back(std::move(node));
      node = std::move(field);
      continue;
    }
    if (dotName) {
      advance(); // '.'
      std::string method = current().text;
      advance(); // method name
      const Token methodOpen = current();
      advance(); // '('
      std::vector<std::unique_ptr<Expr>> args;
      std::vector<std::string> argNames;
      if (!parseCallArgs(args, argNames, /*colonSeparates=*/false))
        return false;
      if (!requireClosing(RPAREN, methodOpen))
        return false;
      auto call = makeExpr(ExprKind::MethodCall);
      call->text = method;
      call->children.push_back(std::move(node)); // receiver, always children[0]
      for (auto &a : args)
        call->children.push_back(std::move(a));
      call->argNames = std::move(argNames); // argNames[i] names children[i + 1]
      node = std::move(call);
      continue;
    }
    if (current().type == LBRACKET && (line == 0 || current().line == line)) {
      const Token indexOpen = current();
      advance();
      auto idx = makeExpr(ExprKind::Index);
      idx->children.push_back(std::move(node));
      idx->children.push_back(parseIndexKeyNode());
      while (current().type == COMMA) {
        advance();
        idx->children.push_back(parseIndexKeyNode());
      }
      for (const auto &k : idx->children)
        if (!k)
          return false; // a key already reported its error
      if (!requireClosing(RBRACKET, indexOpen))
        return false;
      node = std::move(idx);
      continue;
    }
    return true;
  }
}

std::unique_ptr<Expr> Parser::parseIndexKeyNode() {
  auto endsKey = [this]() {
    TokenType t = current().type;
    return t == COMMA || t == RBRACKET || t == END || t == SEMICOLON;
  };
  if (endsKey())
    return makeExpr(ExprKind::Wildcard); // A[m,] / A[,n]

  std::unique_ptr<Expr> first;
  if (current().type != COLON) {
    first = parseOrNode();
    if (!first)
      return nullptr;
    if (current().type != COLON)
      return first; // a plain index
  }

  advance(); // first ':'
  std::unique_ptr<Expr> second;
  if (!endsKey() && current().type != COLON) {
    second = parseOrNode();
    if (!second)
      return nullptr;
  }

  std::unique_ptr<Expr> third;
  bool hasStep = false;
  if (current().type == COLON) {
    advance(); // second ':' - start:step:stop
    hasStep = true;
    if (!endsKey()) {
      third = parseOrNode();
      if (!third)
        return nullptr;
    }
  }

  if (!first && !second && !third)
    return makeExpr(ExprKind::Wildcard); // ':' or '::'

  auto node = makeExpr(ExprKind::Slice);
  node->rangeStart = std::move(first);
  if (hasStep) {
    node->rangeStep = std::move(second);
    node->rangeStop = std::move(third);
  } else {
    node->rangeStop = std::move(second);
  }
  return node;
}

// Index keys of an Index node (children[firstKey..]) evaluated into the
// shared matrix-indexing form (ops/matrix/matrix_index.h). False, with
// `err` set, if a key is not a whole number / slice.
bool Parser::evaluateIndexKeys(const std::vector<const Expr *> &keyNodes,
                               std::vector<MatIndexKey> &keys, std::string &err) {
  keys.clear();
  auto readNumber = [&](const Expr *e, double &out) -> bool {
    Value v = evaluateExpr(e);
    if (!evaluationSucceeded_) {
      err.clear(); // the evaluation already reported its own error
      return false;
    }
    if (v.isMatrix && v.rows() == 1 && v.cols() == 1)
      v = v.at(0, 0);
    if (v.isText || v.isArray || v.isMatrix || v.isDict || v.isObject || v.isFunctionRef ||
        v.hasComplex()) {
      err = "an index must be a whole number or a range like 2:5 - got a value of shape " +
            matShapeText(v);
      return false;
    }
    out = v.number;
    return true;
  };

  for (const Expr *k : keyNodes) {
    MatIndexKey key;
    if (k->kind == ExprKind::Wildcard) {
      key.kind = MatIndexKey::All;
    } else if (k->kind == ExprKind::Slice) {
      key.kind = MatIndexKey::Range;
      if (k->rangeStart) {
        key.hasStart = true;
        if (!readNumber(k->rangeStart.get(), key.start))
          return false;
      }
      if (k->rangeStep) {
        key.hasStep = true;
        if (!readNumber(k->rangeStep.get(), key.step))
          return false;
      }
      if (k->rangeStop) {
        key.hasStop = true;
        if (!readNumber(k->rangeStop.get(), key.stop))
          return false;
      }
    } else {
      key.kind = MatIndexKey::Scalar;
      if (!readNumber(k, key.scalar))
        return false;
    }
    keys.push_back(key);
  }
  return true;
}

bool Parser::reportMisplacedExtend(const Token &tok) {
  if (tok.type != COMMA_ASSIGN && tok.type != SEMI_ASSIGN)
    return false;
  std::cerr << "✖ Syntax Error";
  if (tok.line)
    std::cerr << " (line " << tok.line << ", col " << tok.col << ")";
  std::cerr << ": '" << tok.text << "' is only allowed as an assignment operator - write it "
            << "as a statement of its own, e.g. M " << tok.text << " X\n";
  syntaxErrorCount_++;
  evaluationSucceeded_ = false;
  return true;
}

bool Parser::requireClosing(TokenType closeType, const Token &openTok) {
  if (current().type == closeType) {
    advance();
    return true;
  }
  if (reportMisplacedExtend(current()))
    return false;
  const char *closeText = closeType == RPAREN ? ")" : "]";
  const Token &bad = current();
  std::cerr << "✖ Syntax Error";
  if (openTok.line)
    std::cerr << " (line " << openTok.line << ", col " << openTok.col << ")";
  std::cerr << ": '" << openTok.text << "' was never closed";
  if (bad.type != END && bad.type != SEMICOLON)
    std::cerr << " - expected '" << closeText << "' but found '" << bad.text << "'";
  std::cerr << "\n";
  syntaxErrorCount_++;
  evaluationSucceeded_ = false;
  return false;
}

// Postfix factorial applies to ANY parsed factor - (a+b)!, f(x)!, A[0]!,
// |x|!, [..]! - not just a bare number/identifier. The atom parser's own
// inline '!' loops (NUMBER / IDENT) still run first; this catches the rest.
std::unique_ptr<Expr> Parser::parseFactorNode() {
  auto node = parseFactorAtomNode();
  if (!node)
    return nullptr;
  // Postfix operators, applied left to right: factorial '!' and transpose
  // "'" (A', A'', (A*B)', A[0,:]', x!').
  while (current().type == FACT || current().type == TRANSPOSE) {
    if (current().type == FACT) {
      advance();
      node = wrapPostfixFactorial(std::move(node));
    } else {
      advance();
      auto t = makeExpr(ExprKind::UnaryOp);
      t->text = "'";
      t->children.push_back(std::move(node));
      node = std::move(t);
    }
  }
  return node;
}

std::unique_ptr<Expr> Parser::parseFactorAtomNode() {
  // @name - a first-class function reference (see ast.h's FunctionRef
  // comment). No collision with the class-header `@rate(...)` syntax -
  // that AT is consumed entirely inside parseClassDeclNode(), a completely
  // separate parse path that never reaches here.
  if (current().type == AT) {
    advance();
    // @(x, y) body - an anonymous function.
    if (current().type == LPAREN) {
      const Token openTok = current();
      advance();
      auto node = makeExpr(ExprKind::AnonymousFunction);
      while (current().type != RPAREN) {
        if (current().type != IDENT) {
          std::cerr << "✖ Syntax Error";
          if (current().line)
            std::cerr << " (line " << current().line << ", col " << current().col << ")";
          std::cerr << ": an anonymous function lists input names, e.g. @(x, y) x + y\n";
          syntaxErrorCount_++;
          evaluationSucceeded_ = false;
          return nullptr;
        }
        node->argNames.push_back(current().text);
        advance();
        if (current().type == COMMA)
          advance();
        else if (current().type != RPAREN) {
          requireClosing(RPAREN, openTok); // reports the error
          return nullptr;
        }
      }
      advance(); // ')'
      const size_t bodyStart = pos;
      auto body = parseOrNode();
      if (!body)
        return nullptr;
      std::string text = "@(";
      for (size_t i = 0; i < node->argNames.size(); i++)
        text += (i ? ", " : "") + node->argNames[i];
      node->text = text + ") " + tokensToSource(tokens, bodyStart, pos);
      node->children.push_back(std::move(body));
      return node;
    }
    if (current().type != IDENT) {
      std::cerr << "✖ Syntax Error";
      if (current().line)
        std::cerr << " (line " << current().line << ", col " << current().col << ")";
      std::cerr << ": expected a function name after '@'\n";
      syntaxErrorCount_++;
      evaluationSucceeded_ = false;
      return nullptr;
    }
    auto node = makeExpr(ExprKind::FunctionRef);
    node->text = current().text;
    advance();
    return node;
  }

  if (current().type == STRING) {
    auto node = makeExpr(ExprKind::StringLiteral);
    node->text = current().text;
    advance();
    return node;
  }

  if (current().type == FACT) {
    // Bare '!' in prefix position (nothing parsed yet this factor) means
    // logical NOT, e.g. `!(a == c)`. Postfix '!' (factorial, e.g. `5!`) is
    // handled separately below/after a value has already been parsed.
    advance();
    auto inner = parseFactorNode();
    if (!inner)
      return nullptr;
    auto node = makeExpr(ExprKind::UnaryOp);
    node->text = "!";
    node->children.push_back(std::move(inner));
    return node;
  }

  // Unary +/- used to be handled here, but that made them bind TIGHTER than
  // '^' (e.g. `-2^2` parsed as `(-2)^2` == 4, instead of the standard
  // `-(2^2)` == -4) - parseFactorNode() is '^'s own base-case operand, so
  // consuming a leading sign at this level meant the sign was already
  // "inside" the base before '^' ever got a chance to bind. They're now
  // handled one level up, in parseUnaryNode() (parser_expression.cpp),
  // which sits between parseTermNode() and parsePowerNode() specifically so
  // exponentiation binds tighter than a leading sign.

  if (current().type == NUMBER) {
    auto node = makeExpr(ExprKind::NumberLiteral);
    node->number = std::stod(current().text);
    node->imaginary = current().imaginary;
    node->isBool = current().isBool;
    advance();

    while (current().type == FACT) {
      advance();
      node = wrapPostfixFactorial(std::move(node));
    }

    return node;
  }

  // |expr| — absolute value (scalar), vector norm/magnitude (array), or
  // matrix determinant (matrix), matching the standard overloaded meaning
  // of pipe-bar notation in mathematics.
  if (current().type == PIPE) {
    advance();

    auto inner = parseOrNode();
    if (!inner)
      return nullptr;

    if (current().type != PIPE) {
      std::cerr << "Error: expected closing '|' in absolute value/norm/"
                   "determinant expression\n";
      syntaxErrorCount_++;
      evaluationSucceeded_ = false;
      return nullptr;
    }
    advance(); // consume closing '|'

    auto node = makeExpr(ExprKind::AbsOrNorm);
    node->children.push_back(std::move(inner));
    return node;
  }

  /* array / matrix / range literals, and parenthesized grouping */
  if (current().type == LBRACKET || current().type == LPAREN) {
    char leftBracket = (current().type == LBRACKET) ? '[' : '(';
    const Token openTok = current();
    advance();

    // Range literal: [start:end] or [start:step:end] — see the scan-ahead
    // comment this used to carry in the pre-Phase-2 version; unchanged.
    {
      bool isRangeLiteral = false;
      int depth = 0;
      for (size_t sp = pos; sp < tokens.size(); sp++) {
        TokenType t = tokens[sp].type;
        if (t == LBRACKET || t == LPAREN) {
          depth++;
        } else if (t == RBRACKET || t == RPAREN) {
          if (depth == 0) break;
          depth--;
        } else if (depth == 0 && (t == COMMA || t == SEMICOLON)) {
          break;
        } else if (depth == 0 && t == COLON) {
          isRangeLiteral = true;
          break;
        } else if (t == END) {
          break;
        }
      }

      if (isRangeLiteral) {
        auto startNode = parseOrNode();
        if (!startNode)
          return nullptr; // already printed the specific error

        if (current().type != COLON) {
          std::cerr << "Error: expected ':' in range literal\n";
          evaluationSucceeded_ = false;
          return nullptr;
        }
        advance(); // consume ':'

        auto secondNode = parseOrNode();
        if (!secondNode)
          return nullptr;

        std::unique_ptr<Expr> thirdNode;
        bool hasThird = false;

        if (current().type == COLON) {
          advance();
          thirdNode = parseOrNode();
          if (!thirdNode)
            return nullptr;
          hasThird = true;
        }

        char rightBracket = ']';
        if (current().type == RBRACKET) { rightBracket = ']'; advance(); }
        else if (current().type == RPAREN) { rightBracket = ')'; advance(); }
        else {
          std::cerr << "Error: expected ']' or ')' to close range literal\n";
          evaluationSucceeded_ = false;
          return nullptr;
        }

        auto node = makeExpr(ExprKind::RangeLiteral);
        node->text = std::string() + leftBracket + rightBracket;
        node->rangeStart = std::move(startNode);
        if (hasThird) {
          node->rangeStep = std::move(secondNode);
          node->rangeStop = std::move(thirdNode);
        } else {
          node->rangeStop = std::move(secondNode);
        }
        return node;
      }
    }

    // Not a range literal. A '(' here is a parenthesized grouping
    // expression, e.g. (1 + 2) * 3 — not an array/matrix literal, which is
    // '['-only. Grouping doesn't need its own node - just the inner subtree.
    if (leftBracket == '(') {
      if (current().type == RPAREN) {
        std::cerr << "✖ Syntax Error";
        if (openTok.line)
          std::cerr << " (line " << openTok.line << ", col " << openTok.col << ")";
        std::cerr << ": empty parentheses '()' - an expression is required "
                     "inside\n";
        advance(); // consume ')' so recovery resumes after the group
        syntaxErrorCount_++;
        evaluationSucceeded_ = false;
        return nullptr;
      }
      auto inner = parseOrNode();
      if (!inner)
        return nullptr;
      if (!requireClosing(RPAREN, openTok))
        return nullptr;
      return inner;
    }

    // Matrix literal (MATLAB style): ',' separates the values in a row and
    // ';' ends a row - [1,2,3;4,5,6] is 2x3, [1,2,3] is 1x3, [1;2;3] is 3x1,
    // [] is empty. A value may itself be a matrix, which concatenates:
    // [A, B] side by side, [A; B] stacked (checked when evaluated).
    // More semicolons add dimensions: ';;' separates the 2-D blocks of a
    // 3-D matrix, ';;;' the 3-D blocks of a 4-D one - [1,2;3,4 ;; 5,6;7,8]
    // is 2x2x2. The lexer hands a run of semicolons over as ONE token whose
    // text is the run, so its length is the level.
    auto syntaxError = [&](const Token &at, const std::string &msg) {
      std::cerr << "✖ Syntax Error";
      if (at.line)
        std::cerr << " (line " << at.line << ", col " << at.col << ")";
      std::cerr << ": " << msg << "\n";
      syntaxErrorCount_++;
      evaluationSucceeded_ = false;
    };

    std::vector<std::unique_ptr<Expr>> matRows;
    std::vector<int> sepLevels; // separator after each row (see ast.h)
    auto curRow = makeExpr(ExprKind::ArrayLiteral);
    bool sawSemicolon = false;
    bool allCellsAreBracketLiterals = true; // old [[1,2],[3,4]] detection
    size_t cellCount = 0;

    while (current().type != RBRACKET && current().type != END) {
      if (current().type == SEMICOLON) {
        const Token semi = current();
        const int level = static_cast<int>(semi.text.size() > 1 ? semi.text.size() : 1);
        sawSemicolon = true;
        advance();
        if (curRow->children.empty()) {
          if (matRows.empty())
            syntaxError(semi, "a matrix literal cannot start with '" + semi.text +
                                  "' - write the first value first, e.g. [1,2;3,4]");
          else
            syntaxError(semi, "matrix literal has an empty row - two separators in a row. To "
                              "separate the 2-D blocks of an N-D matrix write ';;' with no "
                              "space, e.g. [1,2;3,4 ;; 5,6;7,8]");
          return nullptr;
        }
        matRows.push_back(std::move(curRow));
        sepLevels.push_back(level);
        curRow = makeExpr(ExprKind::ArrayLiteral);
        continue;
      }
      if (current().type == COMMA) {
        syntaxError(current(), "matrix literal has an empty value - two ',' in a row, or a ',' "
                               "right after '[' or ';'");
        return nullptr;
      }

      const bool startsWithBracket = (current().type == LBRACKET);
      auto elem = parseOrNode();
      if (!elem)
        return nullptr;
      if (!(startsWithBracket && (elem->kind == ExprKind::MatrixLiteral ||
                                  elem->kind == ExprKind::RangeLiteral)))
        allCellsAreBracketLiterals = false;
      curRow->children.push_back(std::move(elem));
      cellCount++;

      if (current().type == COMMA) {
        advance();
        continue;
      }
      if (current().type == SEMICOLON || current().type == RBRACKET || current().type == END)
        continue;
      if (reportMisplacedExtend(current()))
        return nullptr;
      syntaxError(current(), "unexpected '" + current().text +
                                 "' in matrix literal - separate values with ',' and rows "
                                 "with ';', e.g. [1,2,3;4,5,6]");
      return nullptr;
    }

    if (!requireClosing(RBRACKET, openTok))
      return nullptr;
    if (!curRow->children.empty()) {
      matRows.push_back(std::move(curRow));
      sepLevels.push_back(0);
    }

    if (!sawSemicolon && cellCount > 0 && allCellsAreBracketLiterals) {
      syntaxError(openTok, "nested-list matrices like [[1,2],[3,4]] are no longer supported - "
                           "write [1,2;3,4] (',' between values, ';' between rows)");
      return nullptr;
    }

    auto node = makeExpr(ExprKind::MatrixLiteral);
    node->children = std::move(matRows);
    node->sepLevels = std::move(sepLevels);
    return node;
  }

  if (current().type == IDENT) {
    std::string name = current().text;
    const size_t nameLine = current().line;
    advance();

    /* function call */
    if (current().type == LPAREN) {
      const Token callOpen = current();
      advance();

      // "dict" accepts a ':' as sugar for ',' between its two constructor
      // args: dict(keysArr: valsArr) as well as dict(keysArr, valsArr).
      std::string nameLower = name;
      for (char &ch : nameLower) ch = static_cast<char>(std::tolower((unsigned char)ch));
      bool isDictCall = (nameLower == "dict");

      // Each argument is a plain value or `name = value` (Add(x1=10, 15)).
      std::vector<std::unique_ptr<Expr>> args;
      std::vector<std::string> argNames;
      if (!parseCallArgs(args, argNames, /*colonSeparates=*/isDictCall))
        return nullptr;

      if (!requireClosing(RPAREN, callOpen))
        return nullptr;

      // parent(args) — reserved call name (not a token, same precedent as
      // `new`/`clear`); always wins over a same-named class/function/
      // builtin, exactly like before.
      ExprKind kind = (name == "parent") ? ExprKind::ParentCall : ExprKind::Call;
      auto node = makeExpr(kind);
      node->text = name;
      node->children = std::move(args);
      node->argNames = std::move(argNames);

      // f(x)[i] - the result indexed straight away (keys(d)[0], size(A)[1]),
      // and f(x).field / f(x).method() (load_json(f).keys()). They used to
      // need a temporary variable. Same-line rule as A[i] below.
      std::unique_ptr<Expr> chained = std::move(node);
      if (!parsePostfixChain(chained, nameLine))
        return nullptr;
      return chained;
    }

    // Everything below is purely syntax-driven - no memory/constant/
    // function-table lookup happens anywhere in this function. Which of
    // "field access" vs "elementwise dot operator" vs "dict method call"
    // vs "object method call" applies for a given DOT is a question about
    // the receiver's *runtime* value, which isn't known yet at parse time
    // for a tree that may be built once and evaluated many times (a
    // function body, a loop body - Phase 3). Every such decision is made in
    // evaluateExpr() instead, using the receiver's actual value at each
    // evaluation. This does mean one deliberate grammar simplification
    // relative to the original single-pass version: `obj.field` (no
    // trailing '(') now always binds at the factor level (tight, like
    // field/member access in most languages), rather than only doing so
    // when the receiver happened to already be a resolved object at parse
    // time and otherwise falling through to be re-parsed one precedence
    // level up as the elementwise dot operator's right-hand side. The two
    // give the same result whenever the dot-expression is a term by itself
    // (by far the common case - verified against every matrix/dot script in
    // the golden corpus); they can only disagree inside a larger arithmetic
    // expression when the receiver *isn't* an object AND the right-hand
    // name also happens to be a variable - an obscure combination not
    // exercised by any script this session has access to.
    auto identNode = makeExpr(ExprKind::Identifier);
    identNode->text = name;

    /* Postfix chain after a name, any order and any depth (2026-10-28):
         obj.field          bare dot-access (no trailing '('), or the
                            elementwise dot operator misapplied to a
                            non-object - evaluateExpr() tells them apart
         A.keys(), obj.M()  dict builtin / object method call, including the
                            reserved obj.lineage()/rewind()/tick()
         A[i], A[r,c]       dict key / element / slice read, one Index node
                            per bracket group (see ast.h's Index comment)
       chained as D.ABC.cols, D.axes[0].lines[0].x, D.t.filter(s).limit(9).
       Each link wraps the previous node as its children[0]; a single link
       builds exactly the node it always did. Only a '[' on the SAME line
       indexes: a statement that ends without ';' is never glued to a next
       line starting with '[' ([a, b] = ..., [1,2;3,4] ...). */
    {
      std::unique_ptr<Expr> node = std::move(identNode);
      if (!parsePostfixChain(node, nameLine))
        return nullptr;
      if (node->kind != ExprKind::Identifier)
        return node;
      identNode = std::move(node);
    }

    // NOTE: the pre-Phase-2 version had a further `current().type == LPAREN`
    // branch here for reading an array/matrix element by call syntax
    // (`arr(i)`, `mat(i)(j)`). It was unreachable dead code even then: any
    // `IDENT(` is already intercepted by the function-call branch at the
    // very top of this IDENT case, immediately after the identifier is
    // read, before variable lookup ever runs — so control can never reach
    // this point with current().type == LPAREN. Preserved as a documented
    // no-op rather than replicated, since replicating unreachable code adds
    // risk with zero behavioral effect either way. (This matches the known
    // language quirk that `arr(0)` parses as a function call, not element
    // access — see CLAUDE.md.)

    // Bare identifier reference — wrap any postfix factorial chain.
    auto node = std::move(identNode);
    while (current().type == FACT) {
      advance();
      node = wrapPostfixFactorial(std::move(node));
    }
    return node;
  }

  // Nothing above matched: a value (number, name, '(', '[', '|', string, or a
  // unary '-'/'!') was required here and something else was found. Say so
  // loudly - this used to fail silently, so `5*+6` just printed nothing.
  {
    const Token &bad = current();
    auto isBinaryOp = [](TokenType t) {
      return t == PLUS || t == MINUS || t == MUL || t == DIV || t == MOD ||
             t == QUOT || t == POW || t == DOT;
    };
    std::cerr << "✖ Syntax Error";
    if (bad.line)
      std::cerr << " (line " << bad.line << ", col " << bad.col << ")";
    std::cerr << ": ";
    if (bad.type == END || bad.type == SEMICOLON)
      std::cerr << "expression ended unexpectedly - a value is required here";
    else
      std::cerr << "unexpected '" << bad.text << "' - a value is required here";
    if (pos > 0 && isBinaryOp(tokens[pos - 1].type) && isBinaryOp(bad.type))
      std::cerr << " ('" << bad.text << "' cannot directly follow '"
                << tokens[pos - 1].text << "')";
    else if (pos > 0 && isBinaryOp(tokens[pos - 1].type))
      std::cerr << " (operator '" << tokens[pos - 1].text
                << "' is missing its right-hand operand)";
    std::cerr << "\n";
  }
  syntaxErrorCount_++;
  evaluationSucceeded_ = false;
  return nullptr;
}

// A bare identifier read: a resolved local/global variable, else a named
// constant, else a unit constant, else a bare no-parens call of a
// zero-input overload (e.g. `foo;` for `function foo`/`function B = foo()`),
// else "Undefined variable". Shared by evaluateExpr()'s Identifier case and
// the FieldAccess elementwise-dot-operator fallback below, both of which
// need to resolve a plain variable name the same way.
Value Parser::readVariableOrConstant(const std::string &name, int slot) {
  if (varExists(slot, name))
    return varGet(slot, name);

  double cval = 0.0;
  Value unitVal;
  if (resolveConstantValue(name, cval))
    return Value(cval);
  if (tryResolveUnitConstant(name, unitVal))
    return unitVal;

  // Bare no-parens call of a no-input overload, e.g. `foo;` or
  // `B = foo;` for `function foo` / `function B = foo()`.
  if (functionTable_.count(name) && findOverload(functionTable_[name], 0)) {
    bool found = false;
    Value result = callUserFunction(name, {}, found);
    if (!found)
      evaluationSucceeded_ = false;
    return result;
  }

  // A name that was never assigned (it used to say "Unknown constant",
  // which pointed at the wrong thing).
  std::cerr << "Error: Undefined variable '" << name << "'\n";
  evaluationSucceeded_ = false;
  return Value(0);
}

// feval/grad/taylor_series/green_integral - all four need to call a
// user-supplied function reference (@name) repeatedly with different
// arguments, so they can't be plain free functions in ops/calculus/
// calculus.cpp (no Parser access there - see calculus.h's comment). They
// used to live inline in evaluateExpr()'s ExprKind::Call case, but that
// meant nc_bridge_call_dynamic() (value_bridge.cpp) - the JIT dynamic-
// dispatch path used whenever a call's name isn't statically known to be
// a compiled class/function - could never reach them: it only tries
// classTable_ -> functionTable_ -> callBuiltin(), never evaluateExpr()
// itself. A real bug found via direct testing: `grad(@f, [1,2,3])`
// worked fine under JIT (the literal `@f` argument is itself an
// unsupported codegen expression kind, forcing the WHOLE statement to
// fall back to the tree-walker, accidentally routing around the gap) but
// `fr = @f; grad(fr, [1,2,3]);` - or anything else where the function-
// reference argument is itself a codegen-compilable expression, e.g. a
// plain variable or an array index - compiled "successfully" as a
// generic dynamic-dispatch call and then failed at runtime with "Unknown
// function 'grad'", since nc_bridge_call_dynamic() never knew this name
// was reserved. Extracting this into one shared method that BOTH
// evaluateExpr() and nc_bridge_call_dynamic() call closes that gap for
// every call shape, not just the ones that happen to force a full
// tree-walker fallback some other way.
//
// Sets `handled` true (and returns the real result, with
// evaluationSucceeded_ already updated as needed) iff `name` was one of
// these four reserved names; false (result unused) otherwise, so the
// caller continues with its own normal class/function/builtin
// resolution.
Value Parser::tryReservedFunctionValueCall(const std::string &name, const std::vector<Value> &args,
                                            bool &handled) {
  handled = true;

  // save_workspace([path]) / load_workspace([path]) - the .ndat
  // persistence (runtime/data/DataEngine.h). Reserved here, not in
  // callBuiltin(), because they act on the Parser's GLOBAL workspace -
  // even when called inside a function, where `memory` is the call's
  // locals. Default path: workspace.ndat in the current folder; a relative
  // path is taken from the current folder; ".ndat" is added when the name
  // has no extension. Each prints a one-line report and yields true.
  if (ncdata::DataEngine::isWorkspaceCommand(name)) {
    const bool isSave = (name == "save_workspace");
    if (args.size() > 1 || (args.size() == 1 && !args[0].isText)) {
      std::cerr << "Error: " << name << " expects no arguments or one file name in quotes, e.g. "
                << name << "(\"results.ndat\")\n";
      evaluationSucceeded_ = false;
      return Value::boolean(false);
    }
    const std::string userPath = args.empty() ? std::string() : args[0].text();
    ncdata::DataEngine &engine = ncdata::DataEngine::instance();
    ncdata::WorkspaceIoResult io =
        isSave ? engine.saveWorkspace(globalMemory(), globalInsertionOrder(), userPath)
               : engine.loadWorkspace(userPath, globalMemory(), globalInsertionOrder());
    if (!io.ok) {
      std::cerr << "Error: " << io.message << "\n";
      evaluationSucceeded_ = false;
      return Value::boolean(false);
    }
    std::cout << io.message << std::endl;
    return Value::boolean(true);
  }

  // save(file) with no data: the whole GLOBAL workspace (like save_workspace,
  // but through save(): an .ndat bundle that stores each variable in the
  // encoding that suits it - Numpy/importing_data/io_ndat.cpp). save is for
  // .ndat files only; save(file, data) is an ordinary builtin.
  if (name == "save" && args.size() == 1 && args[0].isText && !hasFunction("save")) {
    if (!nc::io::isNdatPath(args[0].text())) {
      std::cerr << "Error: save is for NC data files (.ndat) - give a name without an extension "
                   "or ending in .ndat (other formats have their own save_ functions)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    nc::io::NamedEntries entries;
    std::unordered_map<std::string, bool> seen;
    for (const std::string &n : globalInsertionOrder()) {
      auto it = globalMemory().find(n);
      if (it != globalMemory().end() && !seen[n]) {
        seen[n] = true;
        entries.push_back({n, it->second});
      }
    }
    double bytes = 0;
    std::string err;
    std::filesystem::path written;
    if (!nc::io::saveNdatEntries(args[0].text(), ncdata::bundle::Root::Workspace, entries, "auto",
                                 bytes, err, &written)) {
      std::cerr << "Error: save: " << err << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    std::cout << "Saved " << entries.size() << (entries.size() == 1 ? " variable" : " variables")
              << " to " << written.u8string() << std::endl;
    return Value(bytes);
  }

  // deal(v) - the value itself. Its real use is on the right of a list of
  // variables: [a, b, c] = deal(0) gives every name 0, and
  // [a, b] = deal(x, y) gives each name its own value (executeAssignStmt(),
  // parser_exec_stmt.cpp). Anywhere else it takes exactly one value.
  if (name == "deal" && !hasFunction("deal")) {
    if (args.size() != 1) {
      std::cerr << "Error: deal(" << (args.empty() ? "" : "a, b, ...")
                << ") with " << args.size()
                << " values only works on the right of a list of variables, e.g. "
                   "[x, y] = deal(1, 2)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    return args[0];
  }

  // feval(@f, arg1, arg2, ...) — invokes a function reference (see
  // ast.h's FunctionRef comment) with the given arguments. Reserved, same
  // precedent as "parent"/"new"/"clear" being fully reserved words
  // elsewhere in this language - this is the ONLY way to actually call a
  // value obtained via `@name` (there's no `fref(args)` call syntax; the
  // parser always treats IDENT( as a direct call-by-name, so a stored
  // reference needs an explicit "call this" builtin instead).
  if (name == "feval") {
    if (args.empty() || !args[0].isFunctionRef) {
      std::cerr << "Error: feval's first argument must be a function "
                   "reference (e.g. @funcname)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    std::vector<Value> callArgs(args.begin() + 1, args.end());
    return callFunctionValue(args[0], callArgs);
  }

  // grad(@f, point[, h]) — numerical gradient of f at `point` (an
  // array [x1,...,xn]) via central difference on each dimension:
  // df/dxi ~= (f(...,xi+h,...) - f(...,xi-h,...)) / 2h. `f` must take
  // exactly `point.size()` separate scalar arguments (not one array
  // argument - sidesteps this language's own per-element array READ
  // gap entirely, since each perturbed coordinate is built and passed
  // positionally from C++, never read back out of an NC array by
  // index). Replaces the old grad() builtin (ops/calculus/calculus.cpp),
  // which was a pure no-op identity function - see its own comment for
  // why real calculus.cpp free functions can't do this at all (no
  // Parser access to call the user's function repeatedly).
  // grad(Z) / grad(Y, h) of sampled data has no function reference: it is
  // the ops registry's grid form (ops/calculus/calculus_builtin.cpp), so
  // the call goes on to callBuiltin() like any builtin.
  if (name == "grad" && !(args.size() >= 1 && args[0].isFunctionRef) && !hasFunction("grad")) {
    handled = false;
    return Value(0);
  }
  if (name == "grad") {
    // A point written [1,2,3] is a 1x3 matrix now - take its elements.
    const Value gradPoint = args.size() >= 2 ? matVectorAsArray(args[1]) : Value(0);
    if (args.size() < 2 || args.size() > 3 || !args[0].isFunctionRef || !gradPoint.isArray) {
      std::cerr << "Error: grad expects (function reference, point array[, step "
                   "size]), e.g. grad(@f, [1,2,3])\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    double h = (args.size() == 3) ? args[2].number : 1e-5;
    if (!(h > 0)) {
      std::cerr << "Error: grad's step size must be a positive number\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &fname = args[0].funcRefName();
    const std::vector<Value> point = gradPoint.elems();
    if (point.empty()) {
      std::cerr << "Error: grad's point array must not be empty\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    std::vector<Value> partials;
    partials.reserve(point.size());
    for (size_t i = 0; i < point.size(); i++) {
      std::vector<Value> argsPlus = point;
      std::vector<Value> argsMinus = point;
      argsPlus[i] = Value(point[i].number + h);
      argsMinus[i] = Value(point[i].number - h);
      bool foundPlus = false, foundMinus = false;
      Value fPlus = callUserFunction(fname, argsPlus, foundPlus);
      Value fMinus = callUserFunction(fname, argsMinus, foundMinus);
      if (!foundPlus || !foundMinus) {
        std::cerr << "Error: Unknown function '" << fname << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      if (!evaluationSucceeded_)
        return Value(0); // an arity mismatch/require failure already reported itself
      partials.push_back(Value((fPlus.number - fMinus.number) / (2.0 * h)));
    }
    return Value(partials);
  }

  // taylor_series(@f, x0, x, n) — the degree-(n-1) Taylor polynomial of
  // f centered at x0, evaluated at x:
  //   sum_{k=0}^{n-1} f^(k)(x0)/k! * (x-x0)^k
  // Each derivative f^(k)(x0) is estimated via the standard (2k+1)-
  // point central-difference stencil: f^(k)(x0) ~= (1/h^k) *
  // sum_{j=0}^{k} (-1)^j C(k,j) f(x0 + (k/2-j)h). Replaces the old
  // taylor_series() builtin (ops/calculus/calculus.cpp), which was
  // hardcoded to ONLY ever compute e^x's own Maclaurin series
  // regardless of what a caller might have wanted - see its own
  // comment.
  //
  // Step size is DERIVED PER ORDER, not a single fixed/user-supplied h -
  // a real numerical bug found via direct testing of the first cut of
  // this feature (which took one fixed h=1e-3 for every order): the
  // stencil divides by h^k, so an h that's fine for k=1-3 becomes
  // catastrophic by k=7-9 (h^9 = 1e-27, amplifying ordinary double-
  // precision rounding noise in the sampled f(x) values by a factor of
  // roughly 1e43) - confirmed empirically, e^x's own series at 10 terms
  // came back as -4.4e7 instead of e = 2.71828. The standard remedy: the
  // OPTIMAL step for a k-th-order central difference scales like
  // eps^(1/(k+2)) (eps = double machine epsilon) - LARGER for higher k,
  // trading a bit of truncation error for a lot less rounding-error
  // amplification. Capped at 10 terms (max 9th derivative) regardless:
  // even with the adaptive step, central-difference stencils accumulate
  // real cancellation from their alternating binomial sum at high order -
  // beyond roughly order 8-9 in double precision the result stops
  // meaningfully improving, so this fails loudly past that point instead
  // of quietly returning a number that looks precise but isn't.
  if (name == "taylor_series") {
    if (args.size() != 4 || !args[0].isFunctionRef) {
      std::cerr << "Error: taylor_series expects (function reference, center x0, "
                   "evaluation point x, term count), e.g. "
                   "taylor_series(@f, 0, 1, 6)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &fname = args[0].funcRefName();
    double x0 = args[1].number;
    double x = args[2].number;
    int n = static_cast<int>(args[3].number);
    if (n < 1 || n > 10) {
      std::cerr << "Error: taylor_series's term count must be between 1 and 10 "
                   "(higher-order central-difference derivatives lose too much "
                   "precision to double-precision cancellation to be trustworthy)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    auto evalF = [&](double at, bool &ok) -> double {
      bool found = false;
      Value r = callUserFunction(fname, {Value(at)}, found);
      if (!found) {
        std::cerr << "Error: Unknown function '" << fname << "'\n";
        evaluationSucceeded_ = false;
        ok = false;
        return 0.0;
      }
      if (!evaluationSucceeded_) {
        ok = false;
        return 0.0;
      }
      return r.number;
    };

    double sum = 0.0;
    double dx = x - x0;
    double dxPow = 1.0; // (x-x0)^k, built incrementally
    double factorial = 1.0;
    bool ok = true;

    for (int k = 0; k < n && ok; k++) {
      double deriv;
      if (k == 0) {
        deriv = evalF(x0, ok);
      } else {
        // Order-adaptive step size - see the comment above this whole
        // block for why a single fixed h across every order is wrong.
        double hk = std::pow(std::numeric_limits<double>::epsilon(), 1.0 / (k + 2));
        // Binomial-coefficient central-difference stencil for the
        // k-th derivative, computed with integer binomial
        // coefficients (exact for k <= 10, well within double range).
        double stencilSum = 0.0;
        long long binom = 1; // C(k,0)
        for (int j = 0; j <= k && ok; j++) {
          double sample = evalF(x0 + (k / 2.0 - j) * hk, ok);
          double sign = (j % 2 == 0) ? 1.0 : -1.0;
          stencilSum += sign * static_cast<double>(binom) * sample;
          // C(k,j+1) = C(k,j) * (k-j) / (j+1)
          binom = binom * (k - j) / (j + 1);
        }
        deriv = stencilSum / std::pow(hk, k);
      }
      if (!ok)
        break;
      if (k > 0) {
        dxPow *= dx;
        factorial *= k;
      }
      sum += deriv / factorial * dxPow;
    }
    if (!ok)
      return Value(0);
    return Value(sum);
  }

  // green_integral(@P, @Q, x0, x1, y0, y1[, n]) — Green's theorem as
  // an actual double integral over the axis-aligned rectangle
  // [x0,x1]x[y0,y1]:
  //   oint(P dx + Q dy) = doubleintegral_R (dQ/dx - dP/dy) dA
  // P and Q are function references taking two scalar arguments (x,y).
  // Replaces the old green_integral() builtin (ops/calculus/
  // calculus.cpp), which just computed Q-P from two RAW SCALAR
  // samples with no derivative, no region, and no integration at all -
  // there was no mathematical justification for that number
  // approximating anything (see its own comment for the full history).
  // This version actually differentiates (central difference, first
  // order - numerically robust, no adaptive-step machinery needed
  // unlike taylor_series's higher-order derivatives above) and
  // integrates (composite 2D Simpson's rule over an n x n grid, n
  // even) over a real region - restricted to an axis-aligned rectangle
  // rather than an arbitrary closed curve, a deliberate scope
  // narrowing: a general parametrized-boundary version needs the
  // caller to supply a curve (x(t),y(t)), a materially bigger design
  // this pass doesn't attempt.
  // green_integral(P, Q[, dx, dy]) of sampled grids: the ops registry's grid
  // form (same reason as grad above).
  if (name == "green_integral" && !(args.size() >= 1 && args[0].isFunctionRef) &&
      !hasFunction("green_integral")) {
    handled = false;
    return Value(0);
  }
  if (name == "green_integral") {
    if (args.size() < 6 || args.size() > 7 || !args[0].isFunctionRef ||
        !args[1].isFunctionRef) {
      std::cerr << "Error: green_integral expects (P reference, Q reference, x0, x1, "
                   "y0, y1[, grid intervals]), e.g. green_integral(@P, @Q, 0, 2, 0, 3)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const std::string &pname = args[0].funcRefName();
    const std::string &qname = args[1].funcRefName();
    double x0 = args[2].number, x1 = args[3].number;
    double y0 = args[4].number, y1 = args[5].number;
    int n = (args.size() == 7) ? static_cast<int>(args[6].number) : 20;
    if (!(x1 > x0) || !(y1 > y0)) {
      std::cerr << "Error: green_integral requires x1 > x0 and y1 > y0\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    if (n < 2 || n % 2 != 0) {
      std::cerr << "Error: green_integral's grid interval count must be a positive "
                   "even integer (composite Simpson's rule requires it)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }

    auto evalXY = [&](const std::string &fn, double xx, double yy, bool &ok) -> double {
      bool found = false;
      Value r = callUserFunction(fn, {Value(xx), Value(yy)}, found);
      if (!found) {
        std::cerr << "Error: Unknown function '" << fn << "'\n";
        evaluationSucceeded_ = false;
        ok = false;
        return 0.0;
      }
      if (!evaluationSucceeded_) {
        ok = false;
        return 0.0;
      }
      return r.number;
    };

    const double hd = 1e-5; // first-derivative step - robust at this order, no adaptation needed
    const double hx = (x1 - x0) / n;
    const double hy = (y1 - y0) / n;
    double integral = 0.0;
    bool ok = true;

    for (int i = 0; i <= n && ok; i++) {
      double xi = x0 + i * hx;
      double wx = (i == 0 || i == n) ? 1.0 : ((i % 2 == 1) ? 4.0 : 2.0);
      for (int j = 0; j <= n && ok; j++) {
        double yj = y0 + j * hy;
        double wy = (j == 0 || j == n) ? 1.0 : ((j % 2 == 1) ? 4.0 : 2.0);

        double dQdx = (evalXY(qname, xi + hd, yj, ok) - evalXY(qname, xi - hd, yj, ok)) /
                      (2.0 * hd);
        double dPdy = (evalXY(pname, xi, yj + hd, ok) - evalXY(pname, xi, yj - hd, ok)) /
                      (2.0 * hd);
        integral += wx * wy * (dQdx - dPdy);
      }
    }
    if (!ok)
      return Value(0);
    integral *= (hx / 3.0) * (hy / 3.0);
    return Value(integral);
  }

  // divergence(@F, point) / curl(@F, point) used to be computed here. Moved
  // on 2026-11-04 to the ops registry (ops/calculus/calculus_fields.cpp),
  // which also takes 2-D fields, fields returned as [a, b, c] matrices (this
  // copy refused those since vectors became 1 x n matrices in 2026-10) and
  // the grid forms; both names now reach it through callBuiltin().

  handled = false;
  return Value(0);
}

// True if the builtin call that just returned reported a problem through any
// of the per-domain flags.
static bool lastBuiltinCallFailed() {
  return !g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk ||
         !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk;
}

Value Parser::callFunctionValue(const Value &ref, const std::vector<Value> &args,
                                const std::vector<std::string> &argNames) {
  // A user-function callback (quad, minimize, ...) runs the Parser, which is
  // single-threaded: it must never be reached from inside an nc::par block.
  nc::par::assertInterpreterThread("a user-function callback");
  const std::string &fname = ref.funcRefName();
  if (functionTable_.count(fname)) {
    bool found = false;
    Value result = callUserFunction(fname, args, found, argNames);
    if (!found)
      evaluationSucceeded_ = false;
    return result;
  }
  if (builtinExists(fname)) {
    std::string ndErr;
    if (!ndBuiltinGuard(fname, args, ndErr)) {
      std::cerr << "Error: " << ndErr << "\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    const unsigned long errorsBefore = nc::errorlines::count();
    Value result = argNames.empty() ? callBuiltin(fname, args)
                                    : callBuiltinNamed(fname, args, argNames);
    if (nc::errorlines::count() != errorsBefore || lastBuiltinCallFailed())
      evaluationSucceeded_ = false;
    return result;
  }
  std::cerr << "Error: Unknown function '" << functionRefText(fname) << "'\n";
  evaluationSucceeded_ = false;
  return Value(0);
}

// @(x, y) body. The body becomes a one-statement function, `result = body`,
// registered under the source text plus a number (see functionRefText()).
// Names in the body that are not inputs take the values they have here and
// now (MATLAB's rule): a = 2; f = @(x) a * x; a = 5; f(1) is 2. Evaluating
// the same @(...) again with the same captured values (a loop) reuses the
// function instead of registering another one.
Value Parser::makeAnonymousFunction(const Expr *node) {
  const Expr *body = node->children[0].get();
  const std::vector<std::string> &inputs = node->argNames;
  static const std::string kResult = "anonymous result";

  // The captured values: every name the body reads that is not an input
  // and is a variable here.
  std::vector<std::pair<std::string, Value>> captured;
  std::function<void(const Expr *)> collect = [&](const Expr *e) {
    if (!e)
      return;
    if ((e->kind == ExprKind::Identifier || e->kind == ExprKind::Call) &&
        std::find(inputs.begin(), inputs.end(), e->text) == inputs.end() &&
        varExists(e->slot, e->text)) {
      bool seen = false;
      for (const auto &c : captured)
        seen = seen || c.first == e->text;
      if (!seen)
        captured.emplace_back(e->text, varGet(e->slot, e->text));
    }
    if (e->kind == ExprKind::AnonymousFunction)
      return; // a nested @(...) captures for itself when it is evaluated
    for (const auto &c : e->children)
      collect(c.get());
    collect(e->rangeStart.get());
    collect(e->rangeStop.get());
    collect(e->rangeStep.get());
  };
  collect(body);

  Value ref;
  ref.isFunctionRef = true;

  // (The text is compared too: a REPL command's tree is freed once it has
  // run, so another @(...) can later sit at the same address.)
  const std::string prefix = node->text + kAnonymousSeparator;
  for (const std::string &existing : anonymousNames_[node]) {
    auto it = functionTable_.find(existing);
    if (it == functionTable_.end() || it->second.empty() ||
        existing.compare(0, prefix.size(), prefix) != 0)
      continue;
    const auto &prev = it->second[0].captured;
    bool same = prev.size() == captured.size();
    for (size_t i = 0; same && i < prev.size(); i++)
      same = prev[i].first == captured[i].first &&
             valuesDeepEqual(prev[i].second, captured[i].second);
    if (same) {
      ref.funcRefNameMut() = existing;
      return ref;
    }
  }

  FunctionDef def;
  def.inputNames = inputs;
  def.outputNames = {kResult};
  auto assign = std::make_unique<Stmt>();
  assign->kind = StmtKind::Assign;
  assign->suppressOutput = true;
  auto target = std::make_unique<Expr>();
  target->kind = ExprKind::Identifier;
  target->text = kResult;
  assign->targets.push_back(std::move(target));
  assign->value = cloneExprTree(body);
  def.body.push_back(std::move(assign));
  def.captured = std::move(captured);
  resolveFunctionSlots(def, /*hasBase=*/false);

  const std::string name =
      node->text + kAnonymousSeparator + std::to_string(++anonymousCounter_);
  registerOverload(functionTable_, name, std::move(def));
  anonymousNames_[node].push_back(name);
  ref.funcRefNameMut() = name;
  return ref;
}

Value Parser::evaluateExpr(const Expr *node) {
  if (!node) {
    evaluationSucceeded_ = false;
    return Value(0);
  }

  switch (node->kind) {
    case ExprKind::Identifier:
      return readVariableOrConstant(node->text, node->slot);

    case ExprKind::NumberLiteral:
      if (node->isBool)
        return Value::boolean(node->number != 0.0);
      return node->imaginary ? Value::complexNumber(0.0, node->number) : Value(node->number);

    case ExprKind::StringLiteral:
      return Value(node->text);

    case ExprKind::FunctionRef: {
      // Resolved against functionTable_ at evaluate time, never at parse
      // time - same forward-reference guarantee every other name lookup in
      // this language already has (a function declared later in the same
      // file is still a valid @-reference here, exactly like calling it
      // directly already works before this feature existed).
      // A builtin can be referenced too (@sqrt); it used to be "Unknown
      // function".
      if (!hasFunction(node->text) && !builtinExists(node->text)) {
        std::cerr << "Error: Unknown function '" << node->text << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      Value ref;
      ref.isFunctionRef = true;
      ref.funcRefNameMut() = node->text;
      return ref;
    }

    case ExprKind::AnonymousFunction:
      return makeAnonymousFunction(node);

    case ExprKind::Wildcard:
    case ExprKind::Slice:
      // Only meaningful as a raw Index key, inspected directly by kind in
      // the Index case below and in executeIndexAssign() - never expected
      // to reach the generic evaluator itself (e.g. a bare `:` used
      // somewhere other than inside A[...]).
      std::cerr << "Error: ':' is only valid inside an index, e.g. A[n,:] or A[2:5,0]\n";
      evaluationSucceeded_ = false;
      return Value(0);

    case ExprKind::UnaryOp: {
      Value inner = evaluateExpr(node->children[0].get());

      // An N-D matrix: negation works element by element; '!', transpose
      // and factorial are not defined for it yet.
      if (inner.isND()) {
        if (!evaluationSucceeded_)
          return Value(0);
        if (node->text == "-") {
          Value out;
          std::string err;
          g_lastElementwiseOk = true;
          if (!ndNegate(inner, out, err)) {
            std::cerr << "Error: " << err << "\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
          if (!g_lastElementwiseOk) { // Stop pressed in the multicore kernel
            evaluationSucceeded_ = false;
            return Value(0);
          }
          return out;
        }
        const char *what = node->text == "'" ? "' (transpose) is defined for 2-D matrices - "
                                               "transpose a 2-D slab such as B[0]'"
                           : node->text == "!" ? "'!' (not) is not supported for N-D matrices yet"
                                               : "'!' (factorial) is not supported for N-D "
                                                 "matrices yet";
        std::cerr << "Error: " << what << " (got a " << matShapeText(inner) << " matrix)\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (node->text == "!")
        return toBoolResult(logical_not(inner));

      // Postfix transpose A' - same result as transpose(A); a number stays
      // itself. Not conjugating: use conj(A)' for the conjugate transpose.
      if (node->text == "'") {
        if (!evaluationSucceeded_)
          return Value(0);
        if (inner.isDict || inner.isObject || inner.isFunctionRef) {
          std::cerr << "Error: ' (transpose) needs a number or a matrix\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return matTransposeValue(inner);
      }

      if (node->text == "!post") {
        // Factorial is only mathematically meaningful for a plain,
        // dimensionless number (or array/matrix thereof) - not a
        // unit-bearing quantity like `(5*m)!`, and not text: text is never
        // read as a number (2026-10-28 - "5"! used to be 120).
        if (nctime::containsTime(inner)) {
          nctime::reportTimeError("operator '!' is not defined for timestamps and durations");
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (inner.isText) {
          std::cerr << "Error: '!' (factorial) requires a number, not text - convert it "
                       "first, e.g. float(\""
                    << inner.text() << "\")!\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (inner.hasComplex()) {
          std::cerr << "Error: '!' (factorial) is not defined for complex numbers\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (inner.dimL != 0 || inner.dimT != 0 || inner.dimM != 0) {
          std::cerr << "Error: '!' (factorial) requires a dimensionless "
                        "value\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return factorial(inner);
      }

      // "-"
      // -d of a duration (or a matrix of them); -t is an error.
      if (nctime::containsTime(inner)) {
        Value out;
        std::string err;
        if (!nctime::timeNegate(inner, out, err)) {
          nctime::reportTimeError(err);
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return out;
      }
      // Text is never read as a number (2026-10-28): -"5" used to be -5
      // for fraction text and a silent 0 for any other text.
      if (inner.isText) {
        std::cerr << "Error: '-' (negation) is not defined for text - convert it first, "
                     "e.g. -float(\""
                  << inner.text() << "\")\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      // Arrays/matrices elementwise, numbers (real or complex) with their
      // unit preserved - shared with the JIT's nc_bridge_neg_checked().
      // An integer that has no negation in its type (-int8(-128)) is
      // reported through g_lastElementwiseOk.
      Value negated = negate_op(inner);
      if (!g_lastElementwiseOk)
        evaluationSucceeded_ = false;
      return negated;
    }

    case ExprKind::AbsOrNorm: {
      Value inner = evaluateExpr(node->children[0].get());
      // |d| of a duration (or a matrix of them): element by element.
      if (nctime::containsTime(inner)) {
        Value out;
        std::string err;
        if (!nctime::timeAbs(inner, out, err)) {
          nctime::reportTimeError(err);
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return out;
      }
      if (inner.isND()) {
        std::cerr << "Error: |B| (absolute value / norm / determinant) is not supported for a "
                  << matShapeText(inner) << " matrix - apply it to a 2-D slab such as |B[0]|\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      // |v| of a row/column vector is its length (norm), like a 1-D array;
      // |A| of any other matrix is the determinant.
      if (matIsVectorShape(inner) && inner.rows() * inner.cols() > 1)
        inner = matVectorAsArray(inner);
      // Shared with the JIT's nc_bridge_abs_or_norm().
      bool absOk = true;
      Value result = abs_or_norm(inner, absOk);
      if (!absOk)
        evaluationSucceeded_ = false;
      return result;
    }

    case ExprKind::RangeLiteral: {
      char leftBracket = node->text.size() > 0 ? node->text[0] : '[';
      char rightBracket = node->text.size() > 1 ? node->text[1] : ']';

      double start = evaluateExpr(node->rangeStart.get()).number;
      double step = 1.0;
      double end;
      if (node->rangeStep) {
        step = evaluateExpr(node->rangeStep.get()).number;
        end = evaluateExpr(node->rangeStop.get()).number;
      } else {
        end = evaluateExpr(node->rangeStop.get()).number;
      }

      if (step == 0.0) {
        std::cerr << "Error: range literal step cannot be zero\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      // [a:b] / [a:s:b] is a 1xN row vector, the same as writing the
      // values out with commas (MATLAB). For-loops iterate it element by
      // element.
      std::vector<Value> rangeArr;
      for (double rv : generateRange(start, step, end, leftBracket, rightBracket))
        rangeArr.push_back(Value(rv));
      return matArrayAsMatrix(Value(rangeArr), false);
    }

    case ExprKind::ArrayLiteral: {
      std::vector<Value> arr;
      for (auto &child : node->children)
        arr.push_back(evaluateExpr(child.get()));
      return Value(arr);
    }

    case ExprKind::MatrixLiteral: {
      std::vector<std::vector<Value>> cells;
      for (auto &rowNode : node->children) {
        std::vector<Value> row;
        for (auto &cell : rowNode->children)
          row.push_back(evaluateExpr(cell.get()));
        cells.push_back(std::move(row));
      }
      if (!evaluationSucceeded_)
        return Value(0);
      // An N-D literal (';;' or more somewhere): the N-D builder. The JIT
      // never compiles one of these (codegen.cpp falls back to here).
      bool isNDLiteral = false;
      for (int level : node->sepLevels)
        isNDLiteral = isNDLiteral || level >= 2;
      Value mat;
      std::string err;
      if (isNDLiteral) {
        if (!matBuildND(cells, node->sepLevels, mat, err)) {
          std::cerr << "Error: " << err << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return mat;
      }
      // Shared with the JIT (nc_bridge_matrix_build_checked).
      if (!matBuildFromCells(cells, mat, err)) {
        std::cerr << "Error: " << err << "\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return mat;
    }

    case ExprKind::ParentCall: {
      std::vector<Value> args;
      for (auto &c : node->children)
        args.push_back(evaluateExpr(c.get()));
      return callParentConstructor(args, node->argNames);
    }

    case ExprKind::Call: {
      std::vector<Value> args;
      for (auto &c : node->children)
        args.push_back(evaluateExpr(c.get()));
      // An argument that failed (already reported) must not reach the
      // function as a 0.
      if (!evaluationSucceeded_)
        return Value(0);

      const std::string &name = node->text;

      // f(x) where the variable f holds a function reference (f = @square,
      // f = @(x) x * 2): calls it. It used to look for a function named f.
      if (varExists(node->slot, name) && varGet(node->slot, name).isFunctionRef)
        return callFunctionValue(varGet(node->slot, name), args, node->argNames);

      // P(x) where the variable P holds a poly1d (Numpy/numpy_poly1d.h):
      // the polynomial at x. A variable holding a poly1d wins over a
      // function of the same name, as the latest meaning of a name does in
      // NumPy. node->slot is stamped by resolveFunctionSlots() when P is a
      // local of the enclosing function.
      if (varExists(node->slot, name)) {
        const Value callee = varGet(node->slot, name);
        if (nc::numpy::isPoly1d(callee)) {
          if (args.size() != 1 || node->hasNamedArgs()) {
            std::cerr << "Error: " << name
                      << " is a poly1d: it takes one value in order, e.g. " << name << "(2)\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
          Value out;
          std::string err;
          if (!nc::numpy::poly1dCall(callee, args[0], out, err)) {
            std::cerr << "Error: " << name << ": " << err << "\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
          return out;
        }
      }

      // Named values (F(x1=10, 15)): functions and classes the script
      // defines, then builtins that have a parameter line.
      if (node->hasNamedArgs()) {
        if (classTable_.count(name)) {
          bool found = false;
          Value result = callClassConstructor(name, args, found, node->argNames);
          if (!found)
            evaluationSucceeded_ = false;
          return result;
        }
        if (functionTable_.count(name)) {
          bool found = false;
          Value result = callUserFunction(name, args, found, node->argNames);
          if (!found)
            evaluationSucceeded_ = false;
          return result;
        }
        // The parser's own calls (feval, grad, deal, save_workspace, ...)
        // take their values in order.
        if (name == "deal" || name == "feval" || name == "grad" || name == "taylor_series" ||
            name == "green_integral" || ncdata::DataEngine::isWorkspaceCommand(name)) {
          std::cerr << "Error: " << name << ": its values cannot be named - give them in order\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        // A builtin: named values work for those with a parameter line
        // (builtins.h, callBuiltinNamed()).
        std::string ndErr;
        if (!ndBuiltinGuard(name, args, ndErr)) {
          std::cerr << "Error: " << ndErr << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        const unsigned long errorsBefore = nc::errorlines::count();
        Value result = callBuiltinNamed(name, args, node->argNames);
        if (nc::errorlines::count() != errorsBefore || !g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk ||
            !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk)
          evaluationSucceeded_ = false;
        return result;
      }

      // feval/grad/taylor_series/green_integral - see
      // tryReservedFunctionValueCall()'s own comment (below, right before
      // evaluateExpr()) for why these live in a shared method instead of
      // inline here: nc_bridge_call_dynamic() (value_bridge.cpp) needs to
      // reach this exact same logic too, for the JIT dynamic-dispatch path.
      {
        bool handledReserved = false;
        Value reservedResult = tryReservedFunctionValueCall(name, args, handledReserved);
        if (handledReserved)
          return reservedResult;
      }

      // Instantiation: ClassName(args) — checked ahead of functions/builtins
      // so a class name always wins on a collision (most specific match).
      if (classTable_.count(name)) {
        bool found = false;
        Value result = callClassConstructor(name, args, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      }

      // User-defined functions shadow builtins of the same name.
      if (functionTable_.count(name)) {
        bool found = false;
        Value result = callUserFunction(name, args, found);
        if (!found)
          evaluationSucceeded_ = false;
        return result;
      }

      // A builtin that only understands 2-D matrices never sees an N-D one.
      {
        std::string ndErr;
        if (!ndBuiltinGuard(name, args, ndErr)) {
          std::cerr << "Error: " << ndErr << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
      }

      const unsigned long errorsBefore = nc::errorlines::count();
      Value result = callBuiltin(name, args);
      // An error line printed by the builtin is a failure too (error_lines.h).
      if (nc::errorlines::count() != errorsBefore)
        evaluationSucceeded_ = false;
      // g_lastVectorOk: a vector-domain builtin (dot/angle/proj/orthogonal/
      // eigen_value/...) can be genuinely FOUND (g_lastBuiltinFound stays
      // true) yet still reject its actual arguments as invalid (wrong
      // shape, mismatched lengths, ...) - see vector.h's own comment on
      // this flag for the crashes it replaces.
      if (!g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk || !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk)
        evaluationSucceeded_ = false;
      return result;
    }

    case ExprKind::FieldAccess: {
      // ClassName.base / ClassName.info / obj.base / obj.info.
      {
        Value introspected;
        bool isInfo = false;
        if (tryClassIntrospection(node, introspected, isInfo))
          return introspected;
      }

      Value receiver = evaluateExpr(node->children[0].get());

      // d.key reads a dict entry, like d["key"] (2026-10-28): loaded data
      // carries dicts (D.meta.author, info.schema.Temp, D.exif.Model).
      if (receiver.isDict && !receiver.isObject) {
        auto it = receiver.dict().find(node->text);
        if (it == receiver.dict().end()) {
          std::string keys;
          for (const auto &kv : receiver.dict())
            keys += (keys.empty() ? "" : ", ") + kv.first;
          std::cerr << "Error: the dict has no key '" << node->text << "' (keys: " << keys << ")\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return it->second;
      }

      if (!receiver.isObject) {
        // Not an object: parser_factor.cpp always builds this same
        // FieldAccess shape for a bare `X.Y` regardless of X's type (that
        // isn't known until now) - so this is actually the elementwise dot
        // operator, with `text` naming an ordinary variable for the
        // right-hand operand. Matches the original single-pass grammar's
        // fallback (parseTerm()'s DOT-operator handling) for this case.
        // node->slot (stamped by resolveFunctionSlots() the same way an
        // Identifier node's is) lets this resolve through the fast slot
        // path too when `text` names a local, instead of always falling
        // back to `memory`.
        // The old element-wise dot operator `A.B` was replaced by A*.B
        // (2026-10); say so instead of guessing.
        // Same text as the JIT's nc_bridge_field_get().
        std::cerr << "Error: '." << node->text
                  << "' - '.' reads a field of an object, and the value on its left is "
                  << (receiver.isMatrix ? "a matrix" : "not an object")
                  << ". For element-wise multiplication use *. (e.g. A*.B)\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (!checkFieldAccess(receiver.className(), node->text))
        return Value(0);

      auto fit = receiver.dict().find(node->text);
      if (fit == receiver.dict().end()) {
        std::cerr << "Error: '" << receiver.className() << "' has no field '" << node->text << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return fit->second;
    }

    case ExprKind::MethodCall: {
      // ClassName.info() / obj.base() - the same as without brackets.
      {
        Value introspected;
        bool isInfo = false;
        if (tryClassIntrospection(node, introspected, isInfo))
          return introspected;
      }

      const Expr *receiverNode = node->children[0].get();
      Value v = evaluateExpr(receiverNode);
      // Only meaningful when receiverNode->kind == Identifier, same as the
      // pre-Phase-2 version (a receiver is always a bare identifier here —
      // see ast.h's Identifier note).
      const std::string &name = receiverNode->text;

      std::vector<Value> args;
      // Dict builtins take the receiver as arg 0; object methods don't
      // (it's `base`, not a positional arg) - decided here rather than at
      // parse time since it depends on the receiver's actual value.
      if (!v.isObject)
        args.push_back(v);
      for (size_t i = 1; i < node->children.size(); i++)
        args.push_back(evaluateExpr(node->children[i].get()));

      const std::string &method = node->text;

      // An object the runtime built (load_xlsx(...), load_json(...) - its
      // class is no NC class): D.method(a, b) is the builtin method(D, a, b),
      // names allowed as in any builtin call (D.sel(lat=13.08)). The builtin
      // "<Class>.<method>" (NcSheet.cell) is preferred when one exists, so an
      // object's methods never collide with core builtins (keys, filter...).
      // A chained receiver (D.ABC.cell("B4")) is never written back - it
      // names no variable. (2026-10-28)
      if (v.isObject && !classTable_.count(v.className()) && method != "lineage") {
        const std::string qualified = v.className() + "." + method;
        const std::string &target = nc::numpy::isNumpyFunction(qualified) ? qualified : method;
        if (&target == &method && !builtinExists(method)) {
          std::cerr << "Error: '" << v.className() << "' has no method '" << method << "'\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        args.insert(args.begin(), v);
        std::vector<std::string> names;
        if (node->hasNamedArgs()) {
          names.push_back("");
          names.insert(names.end(), node->argNames.begin(), node->argNames.end());
        }
        const unsigned long errorsBefore = nc::errorlines::count();
        Value result = names.empty() ? callBuiltin(target, args) : callBuiltinNamed(target, args, names);
        if (!g_lastBuiltinFound && nc::errorlines::count() == errorsBefore)
          std::cerr << "Error: '" << v.className() << "' has no method '" << method << "'\n";
        if (nc::errorlines::count() != errorsBefore || !g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk ||
            !g_lastGeometricOk || !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk)
          evaluationSucceeded_ = false;
        return result;
      }
      // Only a bare variable receiver is written back after a method call.
      const bool writeBack = receiverNode->kind == ExprKind::Identifier;

      // Named values only mean something for a method the class defines.
      if (node->hasNamedArgs() && !v.isObject) {
        std::cerr << "Error: '" << name << "' is not an object, so '." << method
                  << "(...)' is a built-in, whose values cannot be named - give them in order\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      if (node->hasNamedArgs() && (method == "lineage" || method == "rewind" || method == "tick")) {
        std::cerr << "Error: '." << method
                  << "(...)' is built in, so its values cannot be named - give them in order\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      /* reserved: obj.lineage() — Traceability */
      if (v.isObject && method == "lineage") {
        std::vector<Value> entries;
        for (const auto &entry : v.lineage())
          entries.push_back(Value(entry));
        return Value(entries);
      }

      /* reserved: obj.rewind() / obj.rewind(n) — Reversibility */
      if (v.isObject && method == "rewind") {
        if (!classTable_.count(v.className()) || !classTable_[v.className()].isReversible) {
          std::cerr << "Error: class '" << v.className()
                    << "' is not reversible (declare it 'reversible class " << v.className()
                    << "(...)')\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (v.snapshots().empty()) {
          std::cerr << "Error: '" << name << "' has no reversibility history to rewind to\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        size_t targetIndex = 0; // no-arg: all the way back to right after init
        if (!args.empty()) {
          long steps = static_cast<long>(args[0].number);
          if (steps < 0) steps = 0;
          long idx = static_cast<long>(v.snapshots().size()) - 1 - steps;
          targetIndex = static_cast<size_t>(idx < 0 ? 0 : idx);
        }

        Value restored = v;
        restored.dictMut() = v.snapshots()[targetIndex];
        restored.lineageMut().resize(targetIndex + 1);
        restored.snapshotsMut().resize(targetIndex + 1);

        if (writeBack)
          varSet(receiverNode->slot, name, restored);
        // Every other mutating method in this feature set is written
        // `x = x.method();` (e.g. `c = c.inc();`), since a method's declared
        // output is `base` itself. Returning Value(0) here instead of
        // `restored` made that same, otherwise-universal idiom silently
        // destroy the object: `c = c.rewind();` would overwrite the
        // just-restored `c` (already correctly written above) with a bare
        // 0. Returning `restored` makes both `c.rewind();` and
        // `c = c.rewind();` do the same, correct thing.
        return restored;
      }

      /* reserved: obj.tick(currentTime) — Temporal Determinism */
      if (v.isObject && method == "tick") {
        double rateHz = 0.0;
        if (!findRateInChain(v.className(), rateHz)) {
          std::cerr << "Error: class '" << v.className()
                    << "' has no '@rate(...)' — not temporally scheduled\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (args.empty()) {
          std::cerr << "Error: '.tick(currentTime)' requires the current simulated time as an "
                       "argument\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }

        double currentTime = args[0].number;
        double period = 1.0 / rateHz;
        bool due = (v.lastTickTime() < 0.0) || (currentTime - v.lastTickTime() + 1e-9 >= period);
        if (!due)
          return Value(0); // too early — skipped, instance left unchanged

        bool found = false;
        Value selfAfter;
        callInstanceMethod(v, "step", {}, selfAfter, found);
        if (!found) {
          std::cerr << "Error: class '" << v.className() << "' has no step() method to run on tick\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (!evaluationSucceeded_)
          return Value(0); // step() itself failed — don't pretend the tick succeeded

        selfAfter.lastTickTimeMut() = currentTime;
        if (writeBack)
          varSet(receiverNode->slot, name, selfAfter);
        return Value(1);
      }

      /* object method call: obj.Method(args) — mutations to base.field
         inside the method are written back to the receiver's storage. */
      if (v.isObject) {
        bool found = false;
        Value selfAfter;
        Value result = callInstanceMethod(v, method, args, selfAfter, found, node->argNames);
        if (!found) {
          std::cerr << "Error: class '" << v.className() << "' has no method '" << method << "'\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (writeBack)
          varSet(receiverNode->slot, name, selfAfter); // persist any base.field mutations
        return result;
      }

      /* dict builtin method call: A.keys(), A.values(), A.size(), ... */
      {
        std::string ndErr;
        if (!ndBuiltinGuard(method, args, ndErr)) {
          std::cerr << "Error: " << ndErr << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
      }
      const unsigned long errorsBefore = nc::errorlines::count();
      Value result = callBuiltin(method, args);
      if (nc::errorlines::count() != errorsBefore || !g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk || !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk)
        evaluationSucceeded_ = false;
      return result;
    }

    case ExprKind::Index: {
      const Expr *receiverNode = node->children[0].get();
      Value v = evaluateExpr(receiverNode);
      const std::string &name = receiverNode->text;
      size_t numKeys = node->children.size() - 1;

      /* Matrix / array: A[m,n], A[m,:], A[:,n], A[a:b,c:d], A[0:2:8],
         A[-1], A[::] ... - see ops/matrix/matrix_index.h for every rule.
         The same function serves the JIT (nc_bridge_index_get_checked), so
         both paths agree on results and error messages. */
      if (v.isMatrix || v.isArray) {
        std::vector<const Expr *> keyNodes;
        for (size_t i = 1; i < node->children.size(); i++)
          keyNodes.push_back(node->children[i].get());
        std::vector<MatIndexKey> keys;
        std::string err;
        Value out;
        if (!evaluateIndexKeys(keyNodes, keys, err) || !matIndexGet(v, keys, name, out, err)) {
          if (!err.empty())
            std::cerr << "Error: " << err << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return out;
      }

      // P[k] on a poly1d: the coefficient of x^k (Numpy/numpy_poly1d.h).
      if (nc::numpy::isPoly1d(v)) {
        if (numKeys != 1 || node->children[1]->kind == ExprKind::Wildcard ||
            node->children[1]->kind == ExprKind::Slice) {
          std::cerr << "Error: " << name << "[k] on a poly1d takes one whole number k\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        Value out;
        std::string err;
        if (!nc::numpy::poly1dCoefficientOf(v, evaluateExpr(node->children[1].get()), out, err)) {
          std::cerr << "Error: " << err << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        return out;
      }

      // s[i] / s[a:b] on text: a character / a piece of the text, by the
      // same index rules as a vector (0-based, -1 from the end, slices
      // inclusive). It used to say "'s' is not a dict" (and before that,
      // silently gave 0).
      if (v.isText) {
        if (!evaluationSucceeded_)
          return Value(0);
        if (numKeys != 1) {
          std::cerr << "Error: text takes one index - " << name << "[i] or " << name
                    << "[a:b]\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        std::vector<Value> chars;
        for (const std::string &ch : utf8Characters(v.text()))
          chars.push_back(Value(ch));
        std::vector<MatIndexKey> keys;
        std::string err;
        Value out;
        if (!evaluateIndexKeys({node->children[1].get()}, keys, err) ||
            !matIndexGet(Value(std::move(chars)), keys, name, out, err)) {
          const size_t elementsAt = err.find(" elements");
          if (elementsAt != std::string::npos)
            err.replace(elementsAt, 9, " characters");
          if (!err.empty())
            std::cerr << "Error: " << err << "\n";
          evaluationSucceeded_ = false;
          return Value(0);
        }
        if (out.isText)
          return out;
        std::string joined;
        for (const Value &ch : matVectorAsArray(out).elems())
          joined += ch.text();
        return Value(joined);
      }

      if (!v.isDict) {
        if (evaluationSucceeded_)
          std::cerr << "Error: '" << name << "' is a " << valueKindName(v)
                    << " and cannot be indexed - only matrices, arrays, text and dicts can\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      if (numKeys != 1 || node->children[1]->kind == ExprKind::Wildcard ||
          node->children[1]->kind == ExprKind::Slice) {
        std::cerr << "Error: dict '" << name << "' read takes exactly one key\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      Value key = evaluateExpr(node->children[1].get());
      std::string k = dictKeyOf(key);
      auto dictIt = v.dict().find(k);
      if (dictIt == v.dict().end()) {
        std::cerr << "Error: dict key '" << k << "' not found in '" << name << "'\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }
      return dictIt->second;
    }

    // Produced by the outer precedence chain (parser_expression.cpp), which
    // also owns the evaluation logic for these three kinds.
    case ExprKind::BinaryOp:
      return evaluateBinaryOp(node);
    case ExprKind::Comparison:
      return evaluateComparison(node);
    case ExprKind::LogicalOp:
      return evaluateLogicalOp(node);
  }

  evaluationSucceeded_ = false;
  return Value(0);
}
