// Phase 3 (AST rewrite roadmap, expanded scope): a real recursive-descent
// statement/block parser. Builds Stmt trees (ast.h) for an entire token
// stream - a whole file, or a whole function/method body - with block
// nesting handled by ordinary recursion instead of the raw-text
// accumulation + keyword-rescanning that ScriptManager (top-level) and
// executeBlockLines() (nested blocks, function/method bodies) do today.
//
// Step 2 of the phase: this file only builds trees. Nothing here touches
// `memory`, `functionTable_`, `classTable_`, or prints anything - that's
// the Step 3 evaluator's job (executeProgram()/executeStmt(), a separate
// file), which walks the Program this produces. See ast.h's Stmt/StmtKind
// for the node shapes being built.
#include "parser.h"
#include "parser_internal.h"

#include <cctype>
#include <iostream>

namespace {
std::string lowerOf(const Token &t) {
  std::string s = t.text;
  for (char &ch : s) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  return s;
}

std::unique_ptr<Expr> makeIdentifier(const std::string &name) {
  auto e = std::make_unique<Expr>();
  e->kind = ExprKind::Identifier;
  e->text = name;
  return e;
}

std::unique_ptr<Stmt> makeStmt(StmtKind kind, size_t line) {
  auto s = std::make_unique<Stmt>();
  s->kind = kind;
  s->line = line;
  return s;
}
} // namespace

/* ================= ENTRY POINT ================= */

Program Parser::parseProgram(const std::vector<Token> &fileTokens) {
  setTokens(fileTokens);

  Program program;
  while (current().type != END) {
    size_t before = pos;
    auto stmt = parseStmtNode();
    if (stmt)
      program.statements.push_back(std::move(stmt));
    if (pos == before)
      break; // no progress on unrecognized input - avoid looping forever
  }
  return program;
}

std::vector<std::unique_ptr<Stmt>>
Parser::parseStmtsUntil(const std::function<bool()> &isBoundary) {
  std::vector<std::unique_ptr<Stmt>> stmts;
  while (current().type != END && !isBoundary()) {
    size_t before = pos;
    auto stmt = parseStmtNode();
    if (stmt)
      stmts.push_back(std::move(stmt));
    if (pos == before)
      break;
  }
  return stmts;
}

/* ================= STATEMENT DISPATCH ================= */

// Error recovery for simple statements. If the expression parser reported a
// syntax error while building this statement, drop it (never execute a
// half-built tree - it used to assign a bogus value, or crash the JIT) and
// skip to just past the next ';' (or the end of the line / input). Compound
// statements (if/for/while/function/class) are left alone: their nested
// statements recover individually, and discarding the whole block because
// one inner line was bad would hide every other error inside it.
std::unique_ptr<Stmt> Parser::parseStmtNode() {
  const int errsBefore = syntaxErrorCount_;
  const size_t startLine = current().line;
  auto stmt = parseStmtNodeImpl();
  if (!stmt)
    return stmt;

  switch (stmt->kind) {
  case StmtKind::ExprStmt:
  case StmtKind::Assign:
  case StmtKind::Publish:
  case StmtKind::Return:
  case StmtKind::Require:
  case StmtKind::Ensure:
    break;
  default:
    return stmt;
  }

  // Two values side by side with no operator between them (`5 6`, `x y`,
  // `2 "a"`): the statement parser used to stop after the first value and
  // silently run the second as a separate statement. A new statement on the
  // same line is only legitimate right after a ';' (already consumed, so the
  // previous token is then SEMICOLON).
  if (syntaxErrorCount_ == errsBefore && pos > 0 && startLine != 0 &&
      tokens[pos - 1].type != SEMICOLON && current().line == tokens[pos - 1].line &&
      (current().type == NUMBER || current().type == IDENT ||
       current().type == STRING || current().type == LPAREN ||
       current().type == LBRACKET)) {
    std::cerr << "✖ Syntax Error (line " << current().line << ", col "
              << current().col << "): unexpected '" << current().text
              << "' - two values cannot sit next to each other; an operator "
                 "(+, -, *, /, ^, ...) or ';' is missing after '"
              << tokens[pos - 1].text << "'\n";
    syntaxErrorCount_++;
    evaluationSucceeded_ = false;
  }

  // A closer with no opener (`6)`, `(1+2))`, `[1]]`): the statement parser
  // stopped at it, so the statement before it would run - Python rejects the
  // whole line instead.
  if (syntaxErrorCount_ == errsBefore && startLine != 0 &&
      (current().type == RPAREN || current().type == RBRACKET) &&
      current().line == startLine) {
    std::cerr << "✖ Syntax Error (line " << current().line << ", col "
              << current().col << "): unmatched '" << current().text
              << "' - it has no matching opening bracket\n";
    syntaxErrorCount_++;
    evaluationSucceeded_ = false;
  }

  if (syntaxErrorCount_ == errsBefore)
    return stmt;

  while (current().type != END && current().type != SEMICOLON &&
         !(startLine != 0 && current().line != startLine))
    advance();
  if (current().type == SEMICOLON)
    advance();
  return nullptr;
}

std::unique_ptr<Stmt> Parser::parseStmtNodeImpl() {
  if (current().type == IF)
    return parseIfStmtNode();

  if (current().type == FOR)
    return parseForStmtNode();

  if (current().type == WHILE)
    return parseWhileStmtNode();

  if (current().type == BREAK || current().type == CONTINUE) {
    auto stmt = makeStmt(current().type == BREAK ? StmtKind::Break : StmtKind::Continue, current().line);
    advance();
    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == RETURN) {
    auto stmt = makeStmt(StmtKind::Return, current().line);
    advance();
    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == REQUIRE || current().type == ENSURE) {
    bool isRequire = (current().type == REQUIRE);
    advance();

    // Raw source text of the condition, purely for the contract-violation
    // message - matches parseStatement()'s condText exactly.
    std::string condText;
    for (size_t i = pos; i < tokens.size(); i++) {
      if (tokens[i].type == SEMICOLON || tokens[i].type == END) break;
      if (i > pos) condText += " ";
      condText += tokens[i].text;
    }

    auto stmt = makeStmt(isRequire ? StmtKind::Require : StmtKind::Ensure, current().line);
    stmt->condition = parseOrNode();
    stmt->conditionText = condText;

    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == FUNCTION)
    return parseFunctionDeclNode();

  if (current().type == CLASS || current().type == ABSTRACT || current().type == REVERSIBLE)
    return parseClassDeclNode();

  if (current().type == IDENT && (current().text == "new" || current().text == "clear" || current().text == "cls")) {
    auto stmt = makeStmt(StmtKind::ClearMemory, current().line);
    stmt->name = current().text;
    advance();
    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == PRINT || current().type == PUBLISH)
    return parsePublishStmtNode();

  return parseAssignOrExprStmtNode();
}

/* ================= CONDITION HEADER (if/elseif/while) ================= */

std::unique_ptr<Expr> Parser::parseConditionHeader() {
  bool negate = false;
  if (current().type == IDENT) {
    std::string t = current().text;
    for (char &ch : t) ch = static_cast<char>(std::tolower((unsigned char)ch));
    if (t == "not") {
      negate = true;
      advance();
    }
  }

  auto cond = parseOrNode();

  if (negate) {
    auto notNode = std::make_unique<Expr>();
    notNode->kind = ExprKind::UnaryOp;
    notNode->text = "!";
    notNode->children.push_back(std::move(cond));
    cond = std::move(notNode);
  }

  // Trailing ':' is optional and unchecked here (unlike function/class
  // headers, which require and validate one) - consume it if present.
  if (current().type == COLON)
    advance();

  return cond;
}

/* ================= IF ================= */

std::unique_ptr<Stmt> Parser::parseIfStmtNode() {
  size_t headerCol = current().col;
  advance(); // consume IF

  auto stmt = makeStmt(StmtKind::If, current().line);
  stmt->condition = parseConditionHeader();

  auto isIfBoundary = [&]() -> bool {
    if (current().type == ELSEIF || current().type == ELSE)
      return true;
    return current().type == IDENT && Parser::isIfTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isIfBoundary);

  while (current().type == ELSEIF) {
    advance();
    auto cond = parseConditionHeader();
    auto branchBody = parseStmtsUntil(isIfBoundary);
    stmt->elseifBranches.emplace_back(std::move(cond), std::move(branchBody));
  }

  if (current().type == ELSE) {
    size_t elseCol = current().col;
    advance();
    if (current().type == COLON)
      advance();
    if (elseCol != headerCol) {
      std::cerr << "✖ Indentation Error: 'else' line (indentation " << (elseCol - 1)
                << ") is unaligned with matching 'if' line (indentation " << (headerCol - 1)
                << ")\n";
      evaluationSucceeded_ = false;
    }
    stmt->elseBody = parseStmtsUntil(isIfBoundary);
  }

  if (current().type == IDENT && Parser::isIfTerm(lowerOf(current()))) {
    if (current().col != headerCol) {
      std::cerr << "✖ Indentation Error: '" << current().text << "' line (indentation "
                << (current().col - 1) << ") is unaligned with matching 'if' line (indentation "
                << (headerCol - 1) << ")\n";
      evaluationSucceeded_ = false;
    }
    advance();
  } else {
    std::cerr << "✖ Syntax Error: unclosed 'if' statement (expected 'iend')\n";
    evaluationSucceeded_ = false;
  }

  return stmt;
}

/* ================= FOR ================= */

std::unique_ptr<Stmt> Parser::parseForStmtNode() {
  advance(); // consume FOR

  auto stmt = makeStmt(StmtKind::For, current().line);

  if (current().type != IDENT) {
    std::cerr << "Error: expected variable name after 'for'\n";
    evaluationSucceeded_ = false;
    return stmt;
  }
  stmt->loopVar = current().text;
  advance();

  if (current().type == IN) {
    advance();
    // Matches executeForBlock()'s Form A exactly: takes whatever the next
    // token's text is with no type check, so a malformed `for x in <not
    // an identifier>` fails later with "not found for for-in loop"
    // (evaluateStmt, Phase 3 Step 3) rather than a parse-time error here.
    stmt->iterable = makeIdentifier(current().text);
    advance();
  } else if (current().type == ASSIGN) {
    advance();
    // The range/collection expression, e.g. [1:N], [1:2:N], or any other
    // array-valued expression - parseOrNode() already builds RangeLiteral
    // nodes for the bracketed [a:b]/[a:b:c] shape (parser_factor.cpp).
    stmt->iterable = parseOrNode();
  } else {
    std::cerr << "Error: expected '=' or 'in' after loop variable\n";
    evaluationSucceeded_ = false;
    return stmt;
  }

  if (current().type == COLON)
    advance();
  if (current().type == SEMICOLON)
    advance();

  auto isForBoundary = [&]() -> bool {
    return current().type == IDENT && Parser::isForTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isForBoundary);

  if (current().type == IDENT && Parser::isForTerm(lowerOf(current()))) {
    advance();
  } else {
    std::cerr << "✖ Syntax Error: unclosed 'for' loop (expected 'fend')\n";
    evaluationSucceeded_ = false;
  }

  return stmt;
}

/* ================= WHILE ================= */

std::unique_ptr<Stmt> Parser::parseWhileStmtNode() {
  size_t headerCol = current().col;
  advance(); // consume WHILE

  auto stmt = makeStmt(StmtKind::While, current().line);
  stmt->condition = parseConditionHeader();
  if (current().type == SEMICOLON)
    advance();

  auto isWhileBoundary = [&]() -> bool {
    return current().type == IDENT && Parser::isWhileTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isWhileBoundary);

  if (current().type == IDENT && Parser::isWhileTerm(lowerOf(current()))) {
    if (current().col != headerCol) {
      std::cerr << "✖ Indentation Error: '" << current().text << "' line (indentation "
                << (current().col - 1) << ") is unaligned with matching 'while' line (indentation "
                << (headerCol - 1) << ")\n";
      evaluationSucceeded_ = false;
    }
    advance();
  } else {
    std::cerr << "✖ Syntax Error: unclosed 'while' loop (expected 'wend')\n";
    evaluationSucceeded_ = false;
  }

  return stmt;
}

/* ================= PUBLISH / PRINT ================= */

std::unique_ptr<Stmt> Parser::parsePublishStmtNode() {
  advance(); // consume PRINT/PUBLISH

  auto stmt = makeStmt(StmtKind::Publish, current().line);

  if (current().type != LPAREN) {
    std::cerr << "Error: expected '(' after print/publish\n";
    evaluationSucceeded_ = false;
    return stmt;
  }
  advance();

  stmt->publishArgs.push_back(parseOrNode());
  while (current().type == COMMA) {
    advance();
    stmt->publishArgs.push_back(parseOrNode());
  }

  if (current().type == RPAREN) {
    advance();
  } else {
    std::cerr << "Error: expected ')' after print/publish\n";
    evaluationSucceeded_ = false;
    return stmt;
  }

  // print/publish always display output and ignore semicolon.
  if (current().type == SEMICOLON)
    advance();

  return stmt;
}

/* ================= FUNCTION DECLARATION ================= */

// Parses the 4 declaration shapes - "(B1,B2) = name(...)", "B = name(...)",
// "name(...)", bare "name" - directly from the shared token stream, unlike
// today's parseFunctionHeader() (parser_function.cpp) which re-lexes a
// captured header string. Same grammar, same required trailing ':', same
// error messages; only the token source differs.
std::unique_ptr<Stmt> Parser::parseFunctionDeclNode() {
  advance(); // consume FUNCTION

  auto stmt = makeStmt(StmtKind::FunctionDecl, current().line);

  // On a malformed header, the original per-line dispatch naturally
  // discards the rest of this block: each subsequent line got its own
  // fresh token stream regardless of what the header parse consumed, so a
  // botched header only ever broke *that* definition (see the golden
  // corpus's t21_functions.nc, whose baseline has a malformed-header error
  // for one function immediately followed by every *other*, unrelated
  // top-level statement running normally). Parsing the whole file as one
  // token stream has no such free reset point - without skipping forward
  // to this function's own 'fnend' here, the rest of the file would be
  // parsed starting from wherever the header parse happened to give up,
  // corrupting everything that follows. Every fail() call below relies on
  // this.
  auto fail = [&](const std::string &msg) {
    std::cerr << "Error: " << msg << "\n";
    evaluationSucceeded_ = false;
    while (current().type != END &&
           !(current().type == IDENT && Parser::isFunctionTerm(lowerOf(current()))))
      advance();
    if (current().type != END)
      advance(); // consume 'fnend' itself
  };

  std::string funcName;

  if (current().type == LPAREN) {
    advance();
    if (current().type != IDENT) { fail("expected output variable name in function header"); return stmt; }
    stmt->outputNames.push_back(current().text);
    advance();
    while (current().type == COMMA) {
      advance();
      if (current().type != IDENT) { fail("expected output variable name in function header"); return stmt; }
      stmt->outputNames.push_back(current().text);
      advance();
    }
    if (current().type != RPAREN) { fail("expected ')' after output list in function header"); return stmt; }
    advance();
    if (current().type != ASSIGN) { fail("expected '=' after output list in function header"); return stmt; }
    advance();
    if (current().type != IDENT) { fail("expected function name in function header"); return stmt; }
    funcName = current().text;
    advance();
  } else if (current().type == IDENT) {
    std::string firstIdent = current().text;
    advance();
    if (current().type == ASSIGN) {
      stmt->outputNames.push_back(firstIdent);
      advance();
      if (current().type != IDENT) { fail("expected function name in function header"); return stmt; }
      funcName = current().text;
      advance();
    } else {
      funcName = firstIdent;
    }
  } else {
    fail("expected function name or output list after 'function'");
    return stmt;
  }

  if (current().type == LPAREN) {
    advance();
    if (current().type == IDENT) {
      stmt->inputNames.push_back(current().text);
      advance();
      while (current().type == COMMA) {
        advance();
        if (current().type != IDENT) { fail("expected input parameter name in function header"); return stmt; }
        stmt->inputNames.push_back(current().text);
        advance();
      }
    }
    if (current().type != RPAREN) { fail("expected ')' to close input list in function header"); return stmt; }
    advance();
  }
  // else: bare "function foo" with no parens - no declared inputs.

  if (current().type != COLON) {
    fail("expected ':' at the end of the function header");
    return stmt;
  }
  advance();

  stmt->name = funcName;

  auto isFunctionBoundary = [&]() -> bool {
    return current().type == IDENT && Parser::isFunctionTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isFunctionBoundary);

  if (current().type == IDENT && Parser::isFunctionTerm(lowerOf(current()))) {
    advance();
  } else {
    std::cerr << "✖ Syntax Error: unclosed function definition (expected 'fnend')\n";
    evaluationSucceeded_ = false;
  }

  return stmt;
}

/* ================= CLASS DECLARATION ================= */

// A class body is not a general statement list - only visibility
// declarations ('private'/'protected' field lists) and nested
// 'function...fnend' methods are allowed, matching executeClassDefEnd()'s
// grammar exactly (parser_class.cpp).
std::unique_ptr<Stmt> Parser::parseClassDeclNode() {
  auto stmt = makeStmt(StmtKind::ClassDecl, current().line);

  // See parseFunctionDeclNode()'s identical fail() for why skipping to this
  // construct's own terminator (here, 'csend') on error is necessary now
  // that the whole file is one token stream rather than independently
  // reset per line.
  auto fail = [&](const std::string &msg) {
    std::cerr << "Error: " << msg << "\n";
    evaluationSucceeded_ = false;
    stmt->classRegistrationFailed = true;
    while (current().type != END &&
           !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
      advance();
    if (current().type != END)
      advance(); // consume 'csend' itself
  };

  while (current().type == ABSTRACT || current().type == REVERSIBLE) {
    if (current().type == ABSTRACT) stmt->isAbstract = true;
    else stmt->isReversible = true;
    advance();
  }

  if (current().type != CLASS) { fail("expected 'class' keyword"); return stmt; }
  advance();

  if (current().type != IDENT) { fail("expected class name after 'class'"); return stmt; }
  stmt->name = current().text;
  advance();

  if (current().type != LPAREN) { fail("expected '(' after class name"); return stmt; }
  advance();

  if (current().type == IDENT) {
    stmt->parentClassName = current().text;
    advance();
  }

  if (current().type != RPAREN) {
    fail("expected ')' after class header (only a single optional parent class name is "
         "supported inside the parens)");
    return stmt;
  }
  advance();

  if (current().type == AT) {
    advance();
    if (current().type != IDENT || current().text != "rate") { fail("expected 'rate' after '@'"); return stmt; }
    advance();
    if (current().type != LPAREN) { fail("expected '(' after '@rate'"); return stmt; }
    advance();
    if (current().type != NUMBER) { fail("expected a numeric rate inside '@rate(...)'"); return stmt; }
    stmt->rateHz = std::stod(current().text);
    advance();
    if (current().type == IDENT)
      advance(); // optional unit suffix, e.g. "Hz" - accepted, not converted
    if (current().type != RPAREN) { fail("expected ')' to close '@rate(...)'"); return stmt; }
    advance();
    if (stmt->rateHz <= 0.0) { fail("'@rate(...)' must be a positive number"); return stmt; }
    stmt->hasRate = true;
  }

  // A colon here is optional in the original grammar - executeClassDefEnd()
  // re-lexes classHeader_ but never validates or requires what (if
  // anything) follows the header's ')'/'@rate(...)', so a trailing ':' is
  // silently tolerated (some class-declaring test scripts, e.g.
  // t38_reversibility.nc/t39_temporal_determinism.nc, write one; others
  // don't). Consume it here if present so it doesn't leak into the
  // body-parsing loop below as a stray, unrecognized token.
  if (current().type == COLON)
    advance();

  while (true) {
    if (current().type == IDENT && Parser::isClassTerm(lowerOf(current())))
      break;
    if (current().type == END)
      break;

    if (current().type == PRIVATE || current().type == PROTECTED) {
      bool isProtected = (current().type == PROTECTED);
      advance();
      if (current().type != IDENT) {
        fail(std::string("expected a field name after '") + (isProtected ? "protected" : "private") +
             "' in class '" + stmt->name + "'");
        return stmt;
      }
      stmt->restrictedFields[current().text] = isProtected;
      advance();
      while (current().type == COMMA) {
        advance();
        if (current().type != IDENT) {
          fail("expected a field name after ',' in class '" + stmt->name + "'");
          return stmt;
        }
        stmt->restrictedFields[current().text] = isProtected;
        advance();
      }
      if (current().type == SEMICOLON)
        advance();
      continue;
    }

    if (current().type == FUNCTION) {
      auto method = parseFunctionDeclNode();

      // An empty name means the header itself failed to parse (e.g.
      // missing the required trailing ':') - parseFunctionDeclNode()'s own
      // fail() already printed that error and skipped to 'fnend'. Treat
      // this exactly like the old executeClassDefEnd(): abort the whole
      // class's registration (do not also raise the separate "has no
      // body" error below, which would otherwise double-report the same
      // failure), and resync to *this class's* own terminator so tokens
      // after 'csend' don't get misparsed as top-level statements.
      if (method->name.empty()) {
        stmt->classRegistrationFailed = true;
        while (current().type != END &&
               !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
          advance();
        if (current().type != END)
          advance(); // consume 'csend'
        return stmt;
      }

      if (!stmt->isAbstract && method->body.empty()) {
        std::cerr << "Error: method '" << method->name << "' in non-abstract class '"
                  << stmt->name << "' has no body (mark '" << stmt->name
                  << "' abstract, or implement the method)\n";
        evaluationSucceeded_ = false;
        stmt->classRegistrationFailed = true;
        while (current().type != END &&
               !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
          advance();
        if (current().type != END)
          advance(); // consume 'csend'
        return stmt;
      }
      stmt->methods.push_back(std::move(method));
      continue;
    }

    fail("expected a method ('function ...') or a visibility declaration "
         "('private'/'protected') inside class '" + stmt->name + "', got: " + current().text);
    return stmt;
  }

  if (current().type == IDENT && Parser::isClassTerm(lowerOf(current()))) {
    advance();
  } else {
    // Reached END without finding 'csend' - matches the exact wording
    // SM_stage_02.cpp's pass-1 completion check uses today (not fail()'s
    // "Error: " prefix, which is for a malformed *interior* construct, not
    // running off the end of the file entirely).
    std::cerr << "✖ Syntax Error: unclosed class definition (expected 'csend')\n";
    evaluationSucceeded_ = false;
    stmt->classRegistrationFailed = true;
  }

  return stmt;
}

/* ================= ASSIGNMENT / EXPRESSION STATEMENT ================= */

std::unique_ptr<Stmt> Parser::parseAssignOrExprStmtNode() {
  if (current().type == IDENT) {
    std::string name = current().text;
    size_t identPos = pos;
    advance();

    /* dict key / matrix element / array element assignment: A[...] = ... */
    if (current().type == LBRACKET) {
      advance();

      std::vector<std::unique_ptr<Expr>> keys;
      keys.push_back(parseIndexKeyNode());
      while (current().type == COMMA) {
        advance();
        keys.push_back(parseIndexKeyNode());
      }

      bool closedOk = (current().type == RBRACKET);
      if (closedOk)
        advance();

      /* A[row][col] = value */
      if (closedOk && keys.size() == 1 && current().type == LBRACKET) {
        size_t secondBracketPos = pos;
        advance();
        auto colKey = parseOrNode();
        bool colClosedOk = (current().type == RBRACKET);
        if (colClosedOk)
          advance();

        if (colClosedOk && current().type == ASSIGN) {
          advance();
          auto stmt = makeStmt(StmtKind::Assign, current().line);
          auto rowIndex = std::make_unique<Expr>();
          rowIndex->kind = ExprKind::Index;
          rowIndex->children.push_back(makeIdentifier(name));
          rowIndex->children.push_back(std::move(keys[0]));

          auto colIndex = std::make_unique<Expr>();
          colIndex->kind = ExprKind::Index;
          colIndex->children.push_back(std::move(rowIndex));
          colIndex->children.push_back(std::move(colKey));

          stmt->targets.push_back(std::move(colIndex));
          stmt->value = parseOrNode();
          stmt->suppressOutput = (current().type == SEMICOLON);
          if (stmt->suppressOutput) advance();
          return stmt;
        }

        // Not A[row][col] = value after all - rewind to just past the
        // first ']' so the single-bracket paths below can reparse it.
        pos = secondBracketPos;
      }

      if (closedOk && current().type == ASSIGN) {
        advance();
        auto stmt = makeStmt(StmtKind::Assign, current().line);

        auto index = std::make_unique<Expr>();
        index->kind = ExprKind::Index;
        index->children.push_back(makeIdentifier(name));
        for (auto &k : keys)
          index->children.push_back(std::move(k));

        stmt->targets.push_back(std::move(index));
        stmt->value = parseOrNode();
        stmt->suppressOutput = (current().type == SEMICOLON);
        if (stmt->suppressOutput) advance();
        return stmt;
      }

      // Not an assignment (e.g. a bare read like `A['key'];`) - rewind
      // fully to the identifier and let the expression fallback below
      // (parseFactorNode's LBRACKET read-index) handle it.
      pos = identPos;
    } else if (current().type == DOT) {
      /* object field assignment: obj.field = value; */
      advance();

      if (current().type == IDENT) {
        std::string fieldName = current().text;
        advance();

        if (current().type == ASSIGN) {
          advance();
          auto stmt = makeStmt(StmtKind::Assign, current().line);

          auto field = std::make_unique<Expr>();
          field->kind = ExprKind::FieldAccess;
          field->text = fieldName;
          field->children.push_back(makeIdentifier(name));

          stmt->targets.push_back(std::move(field));
          stmt->value = parseOrNode();
          stmt->suppressOutput = (current().type == SEMICOLON);
          if (stmt->suppressOutput) advance();
          return stmt;
        }
      }
      // Not a field assignment (e.g. `obj.Method(args);` or `obj.field;` -
      // a method call or bare field read) - rewind fully to the identifier
      // and let the expression fallback (parseFactorNode's DOT handling)
      // take it, exactly like today's parseStatement().
      pos = identPos;
    } else if (current().type == ASSIGN) {
      advance();
      auto stmt = makeStmt(StmtKind::Assign, current().line);
      stmt->targets.push_back(makeIdentifier(name));
      stmt->value = parseOrNode();
      stmt->suppressOutput = (current().type == SEMICOLON);
      if (stmt->suppressOutput) advance();
      return stmt;
    } else {
      pos = identPos; // restore identifier
    }
  }

  /* multi-output function call: (B1,B2) = name(args) */
  if (current().type == LPAREN) {
    size_t savedPos = pos;
    advance();

    std::vector<std::string> outNames;
    bool validList = (current().type == IDENT);
    if (validList) {
      outNames.push_back(current().text);
      advance();
      while (current().type == COMMA) {
        advance();
        if (current().type != IDENT) { validList = false; break; }
        outNames.push_back(current().text);
        advance();
      }
    }

    if (validList && current().type == RPAREN) {
      size_t afterOutList = pos;
      advance();

      // A single name in parens - `(A) = expr;` - isn't the multi-output
      // call shape below (that requires >=2 names, since a single output
      // already has its own plain-assignment syntax). Previously this fell
      // through untouched: the parens got parsed as their own auto-printing
      // expression statement (since the leftover '=' isn't a semicolon),
      // producing a spurious "Unknown constant 'A'" from that phantom
      // statement in addition to whatever the real, still-unparsed
      // "= expr;" went on to do. Treat it as a plain assignment to that one
      // name instead - `(A) = expr;` and `A = expr;` should mean the same
      // thing, and this also lets the RHS be any expression, not just a
      // bare function call the way the >=2-name shape below requires.
      if (outNames.size() == 1 && current().type == ASSIGN) {
        advance();
        auto stmt = makeStmt(StmtKind::Assign, current().line);
        stmt->targets.push_back(makeIdentifier(outNames[0]));
        stmt->value = parseOrNode();
        stmt->suppressOutput = (current().type == SEMICOLON);
        if (stmt->suppressOutput) advance();
        return stmt;
      }

      if (outNames.size() >= 2 && current().type == ASSIGN) {
        advance();
        if (current().type == IDENT) {
          std::string funcName = current().text;
          size_t afterFuncName = pos;
          advance();
          if (current().type == LPAREN) {
            advance();

            auto call = std::make_unique<Expr>();
            call->kind = ExprKind::Call;
            call->text = funcName;
            while (current().type != RPAREN && current().type != END) {
              call->children.push_back(parseOrNode());
              if (current().type == COMMA) advance();
              else break;
            }
            if (current().type == RPAREN) advance();

            auto stmt = makeStmt(StmtKind::Assign, current().line);
            for (auto &n : outNames)
              stmt->targets.push_back(makeIdentifier(n));
            stmt->value = std::move(call);
            stmt->suppressOutput = (current().type == SEMICOLON);
            if (stmt->suppressOutput) advance();
            return stmt;
          }
          pos = afterFuncName;
        }
      }
      pos = afterOutList;
    }
    pos = savedPos; // not this shape - rewind and fall through
  }

  /* plain expression statement (also updates `ans`) */
  auto stmt = makeStmt(StmtKind::ExprStmt, current().line);
  stmt->expr = parseOrNode();
  stmt->suppressOutput = (current().type == SEMICOLON);
  if (stmt->suppressOutput) advance();
  return stmt;
}
