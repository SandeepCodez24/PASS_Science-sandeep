// Function definitions: registering a `function ... fnend` block (does NOT
// execute it - see executeFunctionDefEnd()) and invoking a registered
// function by name (callUserFunction/callUserFunctionMulti), including the
// shared local-scope save/swap/restore core (invokeFunctionBody). Running
// an already-bounded block is otherwise the concern of parser_block_exec.cpp
// (if/for/while) - this file is the function equivalent.
#include "parser.h"

#include <iostream>
#include <sstream>

#include "lexer.h"

/* ================= TERMINATOR ================= */

bool Parser::isFunctionTerm(const std::string &lower) {
  return lower == "fnend";
}

/* ================= HEADER PARSING (shared with class methods) ================= */

// Parses the 4 declaration shapes into outName/outDef (bodyLines left
// empty — the caller attaches those, since a plain function's body comes
// from pendingFunctionBlock_ but a class method's comes from a sub-range of
// the class body scan in parser_class.cpp). Prints its own error and
// returns false on a malformed header; does NOT touch any accumulation
// state (pendingFunctionBlock_/functionHeader_/pendingClassBlock_/
// classHeader_) — that's each caller's own responsibility.
bool Parser::parseFunctionHeader(const std::string &headerLine, std::string &outName,
                                  FunctionDef &outDef) {
  Lexer headerLex(headerLine);
  auto headerToks = headerLex.tokenize();

  size_t hp = 0;
  auto hcur = [&]() -> Token {
    return hp < headerToks.size() ? headerToks[hp] : Token{END, ""};
  };
  auto hadv = [&]() { if (hp < headerToks.size()) hp++; };

  auto fail = [&](const std::string &msg) -> bool {
    std::cerr << "Error: " << msg << "\n";
    return false;
  };

  if (hcur().type != FUNCTION)
    return fail("expected 'function' keyword");
  hadv();

  std::vector<std::string> outputNames;
  std::string funcName;

  if (hcur().type == LPAREN) {
    // (B1, B2) = name(...)  — parenthesized output list, 2+ names.
    hadv();
    if (hcur().type != IDENT)
      return fail("expected output variable name in function header");
    outputNames.push_back(hcur().text);
    hadv();
    while (hcur().type == COMMA) {
      hadv();
      if (hcur().type != IDENT)
        return fail("expected output variable name in function header");
      outputNames.push_back(hcur().text);
      hadv();
    }
    if (hcur().type != RPAREN)
      return fail("expected ')' after output list in function header");
    hadv();
    if (hcur().type != ASSIGN)
      return fail("expected '=' after output list in function header");
    hadv();
    if (hcur().type != IDENT)
      return fail("expected function name in function header");
    funcName = hcur().text;
    hadv();
  } else if (hcur().type == IDENT) {
    // Either "IDENT = name(...)" (single output) or "name(...)"/"name"
    // (no output) — only known after peeking one token past it.
    std::string firstIdent = hcur().text;
    hadv();
    if (hcur().type == ASSIGN) {
      outputNames.push_back(firstIdent);
      hadv();
      if (hcur().type != IDENT)
        return fail("expected function name in function header");
      funcName = hcur().text;
      hadv();
    } else {
      funcName = firstIdent;
    }
  } else {
    return fail("expected function name or output list after 'function'");
  }

  std::vector<std::string> inputNames;
  if (hcur().type == LPAREN) {
    hadv();
    if (hcur().type == IDENT) {
      inputNames.push_back(hcur().text);
      hadv();
      while (hcur().type == COMMA) {
        hadv();
        if (hcur().type != IDENT)
          return fail("expected input parameter name in function header");
        inputNames.push_back(hcur().text);
        hadv();
      }
    }
    if (hcur().type != RPAREN)
      return fail("expected ')' to close input list in function header");
    hadv();
  }
  // else: bare "function foo" with no parens at all — no declared inputs.

  outName = funcName;
  outDef.inputNames = std::move(inputNames);
  outDef.outputNames = std::move(outputNames);
  outDef.bodyLines.clear();
  return true;
}

/* ================= DEFINITION: register (don't run) ================= */

Value Parser::executeFunctionDefEnd() {
  inFunctionBlock_ = false;

  std::string funcName;
  FunctionDef def;
  if (!parseFunctionHeader(functionHeader_, funcName, def)) {
    pendingFunctionBlock_.clear();
    functionHeader_.clear();
    return Value(0);
  }

  std::vector<std::string> bodyLines;
  std::istringstream bodyStream(pendingFunctionBlock_);
  std::string bodyLine;
  while (std::getline(bodyStream, bodyLine))
    bodyLines.push_back(bodyLine);
  def.bodyLines = std::move(bodyLines);

  registerOverload(functionTable_, funcName, std::move(def));

  pendingFunctionBlock_.clear();
  functionHeader_.clear();
  return Value(0);
}

/* ================= POLYMORPHISM (overloading) ================= */

void Parser::registerOverload(std::unordered_map<std::string, std::vector<FunctionDef>> &table,
                               const std::string &name, FunctionDef def) {
  auto &overloads = table[name];
  for (auto &existing : overloads) {
    if (existing.inputNames.size() == def.inputNames.size()) {
      existing = std::move(def); // redefinition of the same arity
      return;
    }
  }
  overloads.push_back(std::move(def));
}

const Parser::FunctionDef *Parser::findOverload(const std::vector<FunctionDef> &overloads,
                                                  size_t argCount) {
  for (const auto &def : overloads) {
    if (def.inputNames.size() == argCount)
      return &def;
  }
  return nullptr;
}

/* ================= INVOCATION ================= */

bool Parser::invokeFunctionBody(const FunctionDef &def, const std::vector<Value> &args,
                                 std::unordered_map<std::string, Value> &outScope,
                                 const Value *selfValue,
                                 const std::string &definingClassName) {
  if (args.size() != def.inputNames.size()) {
    std::cerr << "Error: function expects " << def.inputNames.size()
              << " argument(s), got " << args.size() << "\n";
    evaluationSucceeded_ = false;
    return false;
  }

  // Swap in a fresh local scope and reset loop state so recursion and
  // nested loops/break/continue/return never leak across the call boundary
  // in either direction.
  auto savedMemory = std::move(memory);
  auto savedInsertionOrder = std::move(insertionOrder);
  int savedLoopDepth = loopDepth_;
  LoopSignal savedLoopSignal = loopSignal_;
  std::string savedDefiningClass = std::move(currentDefiningClass_);

  memory.clear();
  insertionOrder.clear();
  loopDepth_ = 0;
  loopSignal_ = LoopSignal::None;
  currentDefiningClass_ = definingClassName;

  // A method/constructor call seeds `base` (the current instance) before
  // the body runs, so it can read base.field and mutate it — the caller
  // reads the mutated value back out of outScope["base"] afterward. A plain
  // function call passes selfValue == nullptr and skips this entirely.
  if (selfValue) {
    memory["base"] = *selfValue;
  }

  for (size_t i = 0; i < def.inputNames.size(); i++) {
    memory[def.inputNames[i]] = args[i];
    insertionOrder.push_back(def.inputNames[i]);
  }

  // executeBlockLines() below calls setTokens() per body line, which
  // overwrites the shared tokens/pos cursor — if this call happened mid-way
  // through parsing an *outer* expression (e.g. a call nested inside
  // another call's argument list, like `publish("x:", square(5))`), that
  // outer parse's cursor would otherwise be silently clobbered and corrupt
  // the rest of the outer parse once this call returns. Save/restore it
  // around the body run, exactly like memory/loop state above.
  auto savedTokens = std::move(tokens);
  size_t savedPos = pos;

  suppressPersistence_++;
  executeBlockLines(def.bodyLines);
  suppressPersistence_--;

  tokens = std::move(savedTokens);
  pos = savedPos;

  // Whatever's left here (None, or Return from an early exit) is fully
  // consumed by this call — it must never bubble into the caller.
  loopSignal_ = LoopSignal::None;

  outScope = memory;

  memory = std::move(savedMemory);
  insertionOrder = std::move(savedInsertionOrder);
  loopDepth_ = savedLoopDepth;
  loopSignal_ = savedLoopSignal;
  currentDefiningClass_ = std::move(savedDefiningClass);

  return true;
}

Value Parser::callUserFunction(const std::string &name, const std::vector<Value> &args,
                                bool &found) {
  auto it = functionTable_.find(name);
  if (it == functionTable_.end()) {
    found = false;
    return Value(0);
  }
  found = true;

  const FunctionDef *defPtr = findOverload(it->second, args.size());
  if (!defPtr) {
    std::cerr << "Error: no overload of function '" << name << "' takes " << args.size()
              << " argument(s)\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  const FunctionDef &def = *defPtr;

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope))
    return Value(0);

  if (def.outputNames.empty())
    return Value(0); // void function used where a value was expected

  const std::string &outName = def.outputNames[0];
  auto oit = outScope.find(outName);
  if (oit == outScope.end()) {
    std::cerr << "Error: output '" << outName << "' not assigned in function '" << name << "'\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  return oit->second;
}

std::vector<Value> Parser::callUserFunctionMulti(const std::string &name,
                                                   const std::vector<Value> &args,
                                                   size_t expectedOutputs, bool &found) {
  auto it = functionTable_.find(name);
  if (it == functionTable_.end()) {
    found = false;
    return {};
  }
  found = true;

  const FunctionDef *defPtr = findOverload(it->second, args.size());
  if (!defPtr) {
    std::cerr << "Error: no overload of function '" << name << "' takes " << args.size()
              << " argument(s)\n";
    evaluationSucceeded_ = false;
    return {};
  }
  const FunctionDef &def = *defPtr;

  if (def.outputNames.size() != expectedOutputs) {
    std::cerr << "Error: function '" << name << "' declares " << def.outputNames.size()
              << " output(s), call expects " << expectedOutputs << "\n";
    evaluationSucceeded_ = false;
    return {};
  }

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope))
    return {};

  std::vector<Value> results;
  for (const auto &outName : def.outputNames) {
    auto oit = outScope.find(outName);
    if (oit == outScope.end()) {
      std::cerr << "Error: output '" << outName << "' not assigned in function '" << name << "'\n";
      evaluationSucceeded_ = false;
      return {};
    }
    results.push_back(oit->second);
  }
  return results;
}
