// Function definitions: invoking a registered function by name
// (callUserFunction/callUserFunctionMulti), including the shared
// local-scope save/swap/restore core (invokeFunctionBody). Registering a
// `function ... fnend` block (building its FunctionDef and Stmt-tree body)
// is parser_program.cpp's parseFunctionDeclNode() plus
// registerFunctionDeclStmt() in parser_exec_stmt.cpp - this file only
// covers what happens once a function is already registered.
#include "parser.h"

#include <iostream>

/* ================= TERMINATOR ================= */

bool Parser::isFunctionTerm(const std::string &lower) {
  return lower == "fnend";
}

/* ================= POLYMORPHISM (overloading) ================= */

void Parser::registerOverload(std::unordered_map<std::string, std::vector<FunctionDef>> &table,
                               const std::string &name, FunctionDef def) {
  auto &overloads = table[name];
  for (auto &existing : overloads) {
    if (existing.inputNames.size() == def.inputNames.size()) {
      existing = std::move(def); // redefinition of the same arity
      return;
    }
  }
  overloads.push_back(std::move(def));
}

const Parser::FunctionDef *Parser::findOverload(const std::vector<FunctionDef> &overloads,
                                                  size_t argCount) {
  for (const auto &def : overloads) {
    if (def.inputNames.size() == argCount)
      return &def;
  }
  return nullptr;
}

/* ================= INVOCATION ================= */

bool Parser::invokeFunctionBody(const FunctionDef &def, const std::vector<Value> &args,
                                 std::unordered_map<std::string, Value> &outScope,
                                 const Value *selfValue,
                                 const std::string &definingClassName) {
  if (args.size() != def.inputNames.size()) {
    std::cerr << "Error: function expects " << def.inputNames.size()
              << " argument(s), got " << args.size() << "\n";
    evaluationSucceeded_ = false;
    return false;
  }

  // Swap in a fresh local scope - both the string-keyed `memory` fallback
  // and the slot-indexed frame (slots_/slotAssigned_, sized to whatever
  // resolveFunctionSlots() determined this function/method needs - see
  // Expr::slot's comment for why every name it will ever locally assign is
  // knowable ahead of time) - and reset loop state, so recursion and
  // nested loops/break/continue/return never leak across the call boundary
  // in either direction.
  auto savedMemory = std::move(memory);
  auto savedInsertionOrder = std::move(insertionOrder);
  auto savedSlots = std::move(slots_);
  auto savedSlotAssigned = std::move(slotAssigned_);
  int savedLoopDepth = loopDepth_;
  LoopSignal savedLoopSignal = loopSignal_;
  std::string savedDefiningClass = std::move(currentDefiningClass_);
  int savedAnsSlot = currentAnsSlot_;
  int savedBaseSlot = currentBaseSlot_;

  memory.clear();
  insertionOrder.clear();
  slots_.assign(def.slotCount, Value());
  slotAssigned_.assign(def.slotCount, false);
  loopDepth_ = 0;
  loopSignal_ = LoopSignal::None;
  currentDefiningClass_ = definingClassName;
  currentAnsSlot_ = def.ansSlot;
  currentBaseSlot_ = def.baseSlot;

  // A method/constructor call seeds `base` (the current instance) before
  // the body runs, so it can read base.field and mutate it — the caller
  // reads the mutated value back out of outScope["base"] afterward. A plain
  // function call passes selfValue == nullptr and skips this entirely.
  // def.baseSlot is always >=0 here: every caller that passes a non-null
  // selfValue only ever does so for a method/constructor call, and every
  // method/constructor is registered via registerClassDeclStmt(), which
  // always resolves with hasBase=true.
  if (selfValue) {
    varSet(def.baseSlot, "base", *selfValue);
  }

  for (size_t i = 0; i < def.inputNames.size(); i++) {
    varSet(def.inputSlots[i], def.inputNames[i], args[i]);
  }

  // executeStmtList() below walks an already-parsed Stmt tree - it never
  // calls setTokens() or otherwise touches the shared token cursor, unlike
  // the pre-Phase-3 executeBlockLines() this replaced (which re-lexed each
  // body line on every single call). Save/restore kept anyway as cheap
  // defense-in-depth matching memory/loop state above, in case this ever
  // runs mid-way through parsing an outer expression (e.g. nested inside
  // another call's argument list, like `publish("x:", square(5))`).
  auto savedTokens = std::move(tokens);
  size_t savedPos = pos;

  suppressPersistence_++;
  executeStmtList(def.body);
  suppressPersistence_--;

  tokens = std::move(savedTokens);
  pos = savedPos;

  // Whatever's left here (None, or Return from an early exit) is fully
  // consumed by this call — it must never bubble into the caller.
  loopSignal_ = LoopSignal::None;

  // Pull out only what a caller ever actually reads from outScope -
  // declared outputs, plus `base` for a method/constructor (confirmed the
  // only two things any call site looks up) - before this frame is torn
  // down. Preserves the exact existing contract (outScope.find(name) ==
  // outScope.end() means "never assigned") regardless of whether a given
  // name ended up slotted or fell back to `memory`; also avoids a full
  // frame copy on every single call, which the old outScope = memory; did.
  outScope.clear();
  for (size_t i = 0; i < def.outputNames.size(); i++) {
    int slot = def.outputSlots[i];
    const std::string &outName = def.outputNames[i];
    if (varExists(slot, outName))
      outScope[outName] = varGet(slot, outName);
  }
  if (def.baseSlot >= 0 && varExists(def.baseSlot, "base"))
    outScope["base"] = varGet(def.baseSlot, "base");

  memory = std::move(savedMemory);
  insertionOrder = std::move(savedInsertionOrder);
  slots_ = std::move(savedSlots);
  slotAssigned_ = std::move(savedSlotAssigned);
  loopDepth_ = savedLoopDepth;
  loopSignal_ = savedLoopSignal;
  currentDefiningClass_ = std::move(savedDefiningClass);
  currentAnsSlot_ = savedAnsSlot;
  currentBaseSlot_ = savedBaseSlot;

  return true;
}

Value Parser::callUserFunction(const std::string &name, const std::vector<Value> &args,
                                bool &found) {
  auto it = functionTable_.find(name);
  if (it == functionTable_.end()) {
    found = false;
    return Value(0);
  }
  found = true;

  const FunctionDef *defPtr = findOverload(it->second, args.size());
  if (!defPtr) {
    std::cerr << "Error: no overload of function '" << name << "' takes " << args.size()
              << " argument(s)\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  const FunctionDef &def = *defPtr;

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope))
    return Value(0);

  if (def.outputNames.empty())
    return Value(0); // void function used where a value was expected

  const std::string &outName = def.outputNames[0];
  auto oit = outScope.find(outName);
  if (oit == outScope.end()) {
    std::cerr << "Error: output '" << outName << "' not assigned in function '" << name << "'\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  return oit->second;
}

std::vector<Value> Parser::callUserFunctionMulti(const std::string &name,
                                                   const std::vector<Value> &args,
                                                   size_t expectedOutputs, bool &found) {
  auto it = functionTable_.find(name);
  if (it == functionTable_.end()) {
    found = false;
    return {};
  }
  found = true;

  const FunctionDef *defPtr = findOverload(it->second, args.size());
  if (!defPtr) {
    std::cerr << "Error: no overload of function '" << name << "' takes " << args.size()
              << " argument(s)\n";
    evaluationSucceeded_ = false;
    return {};
  }
  const FunctionDef &def = *defPtr;

  if (def.outputNames.size() != expectedOutputs) {
    std::cerr << "Error: function '" << name << "' declares " << def.outputNames.size()
              << " output(s), call expects " << expectedOutputs << "\n";
    evaluationSucceeded_ = false;
    return {};
  }

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope))
    return {};

  std::vector<Value> results;
  for (const auto &outName : def.outputNames) {
    auto oit = outScope.find(outName);
    if (oit == outScope.end()) {
      std::cerr << "Error: output '" << outName << "' not assigned in function '" << name << "'\n";
      evaluationSucceeded_ = false;
      return {};
    }
    results.push_back(oit->second);
  }
  return results;
}
