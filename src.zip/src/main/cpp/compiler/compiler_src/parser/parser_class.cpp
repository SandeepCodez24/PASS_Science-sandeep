// Class definitions: invoking a class's constructor (instantiation) or an
// instance method by name, and resolving inheritance chains. Registering a
// `class ... csend` block (building its ClassDef, including each nested
// `function...fnend` method's FunctionDef/Stmt-tree body) is
// parser_program.cpp's parseClassDeclNode() plus registerClassDeclStmt() in
// parser_exec_stmt.cpp - this file only covers what happens once a class is
// already registered. The constructor is just a method under the reserved
// name "base" with no declared output — see callClassConstructor() for how
// its mutated `base` scope becomes the new instance.
#include "parser.h"

#include <iostream>

#include "output.h"

namespace {
// A method/constructor overload with no real body (fnend immediately after
// the header, or only blank lines in between) is a required-override
// contract — only meaningful inside an `abstract class`. Used both to
// validate a non-abstract class's own methods at registration time and to
// check whether a concrete subclass actually implemented an inherited
// abstract contract (validateConcreteInstantiation). Trivial now that a
// body is a parsed Stmt list rather than raw text lines - blank/whitespace
// lines never produced a Stmt in the first place, so "no real body" is
// exactly "no statements".
bool isBodyEmpty(const std::vector<std::unique_ptr<Stmt>> &body) {
  return body.empty();
}
// Traceability: comma-joined, human-readable rendering of a call's
// arguments, used to build lineage entries like "Scale(2)" / "init(23.5)".
std::string formatArgs(const std::vector<Value> &args) {
  std::string out;
  for (size_t i = 0; i < args.size(); i++) {
    if (i > 0) out += ", ";
    out += valueToString(args[i]);
  }
  return out;
}
} // namespace

/* ================= TERMINATOR ================= */

bool Parser::isClassTerm(const std::string &lower) {
  return lower == "csend";
}

/* ================= INHERITANCE RESOLUTION ================= */

const Parser::FunctionDef *
Parser::findMethodInChain(const std::string &className, const std::string &methodName,
                           size_t argCount, std::string &outDefiningClass) {
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return nullptr; // dangling/unregistered class name in the chain
    auto methodIt = classIt->second.methods.find(methodName);
    if (methodIt != classIt->second.methods.end()) {
      const FunctionDef *defPtr = findOverload(methodIt->second, argCount);
      if (defPtr) {
        outDefiningClass = cur;
        return defPtr;
      }
      // Name exists at this level but not with this arity — keep walking
      // up in case an ancestor has the matching overload, rather than
      // stopping just because the name was present here.
    }
    cur = classIt->second.parentClassName;
  }
  return nullptr;
}

bool Parser::methodNameExistsInChain(const std::string &className, const std::string &methodName) {
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false;
    if (classIt->second.methods.count(methodName))
      return true;
    cur = classIt->second.parentClassName;
  }
  return false;
}

bool Parser::isClassOrSubclassOf(const std::string &candidate, const std::string &ancestor) {
  std::string cur = candidate;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    if (cur == ancestor)
      return true;
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false;
    cur = classIt->second.parentClassName;
  }
  return false;
}

bool Parser::findRateInChain(const std::string &className, double &outRateHz) {
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false;
    if (classIt->second.hasRate) {
      outRateHz = classIt->second.rateHz;
      return true;
    }
    cur = classIt->second.parentClassName;
  }
  return false;
}

Value Parser::callParentConstructor(const std::vector<Value> &args) {
  if (currentDefiningClass_.empty()) {
    std::cerr << "Error: 'parent(...)' used outside a class method\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  auto classIt = classTable_.find(currentDefiningClass_);
  if (classIt == classTable_.end() || classIt->second.parentClassName.empty()) {
    std::cerr << "Error: class '" << currentDefiningClass_ << "' has no parent class\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  std::string parentClass = classIt->second.parentClassName;

  std::string definingClass;
  const FunctionDef *ctorDef = findMethodInChain(parentClass, "base", args.size(), definingClass);
  if (!ctorDef) {
    if (methodNameExistsInChain(parentClass, "base")) {
      std::cerr << "Error: no constructor of parent class '" << parentClass << "' takes "
                << args.size() << " argument(s)\n";
    } else {
      std::cerr << "Error: parent class '" << parentClass << "' has no constructor\n";
    }
    evaluationSucceeded_ = false;
    return Value(0);
  }

  if (!varExists(currentBaseSlot_, "base") || !varGet(currentBaseSlot_, "base").isObject) {
    // Defensive — parent(...) only makes sense while base is being built.
    std::cerr << "Error: 'parent(...)' used outside a constructor\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Run the parent's constructor against the CURRENT, already-partially-
  // built base (not a fresh instance) — this is what makes it "chain into"
  // rather than "replace". Note: invokeFunctionBody() below swaps in the
  // parent constructor's own frame (its own currentBaseSlot_ etc.) for the
  // duration of that call and restores this (the child constructor's)
  // frame before returning - currentBaseSlot_ here always refers to *this*
  // constructor's own base, both before and after the call.
  Value selfValue = varGet(currentBaseSlot_, "base");
  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(*ctorDef, args, outScope, &selfValue, definingClass))
    return Value(0);

  auto baseIt = outScope.find("base");
  if (baseIt != outScope.end())
    varSet(currentBaseSlot_, "base", baseIt->second);

  return Value(0);
}

/* ================= ABSTRACTION ================= */

bool Parser::validateConcreteInstantiation(const std::string &className) {
  auto classIt = classTable_.find(className);
  if (classIt == classTable_.end())
    return true; // caller already checked existence

  if (classIt->second.isAbstract) {
    std::cerr << "Error: cannot instantiate abstract class '" << className << "'\n";
    evaluationSucceeded_ = false;
    return false;
  }

  // Walk className's own chain looking for abstract ancestors, and check
  // each of their bodyless (required-override) method/constructor
  // contracts is actually satisfied by a real implementation somewhere in
  // className's resolvable chain.
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto curIt = classTable_.find(cur);
    if (curIt == classTable_.end())
      break;

    if (curIt->second.isAbstract) {
      for (const auto &entry : curIt->second.methods) {
        const std::string &methodName = entry.first;
        for (const auto &overload : entry.second) {
          if (!isBodyEmpty(overload.body))
            continue; // this overload already has a real implementation

          size_t arity = overload.inputNames.size();
          std::string resolvedClass;
          const FunctionDef *resolved =
              findMethodInChain(className, methodName, arity, resolvedClass);
          bool implemented = resolved && !isBodyEmpty(resolved->body);
          if (!implemented) {
            std::cerr << "Error: class '" << className << "' must implement abstract method '"
                      << methodName << "' (inherited from '" << cur << "')\n";
            evaluationSucceeded_ = false;
            return false;
          }
        }
      }
    }

    cur = curIt->second.parentClassName;
  }

  return true;
}

/* ================= INVOCATION ================= */

Value Parser::callClassConstructor(const std::string &className, const std::vector<Value> &args,
                                    bool &found) {
  if (!classTable_.count(className)) {
    found = false;
    return Value(0);
  }
  found = true;

  if (!validateConcreteInstantiation(className))
    return Value(0);

  std::string definingClass;
  const FunctionDef *ctorDef = findMethodInChain(className, "base", args.size(), definingClass);
  if (!ctorDef) {
    if (methodNameExistsInChain(className, "base")) {
      std::cerr << "Error: no constructor of class '" << className << "' takes " << args.size()
                << " argument(s)\n";
    } else {
      std::cerr << "Error: class '" << className
                << "' has no constructor (missing 'function base(...)')\n";
    }
    evaluationSucceeded_ = false;
    return Value(0);
  }

  Value freshInstance;
  freshInstance.isObject = true;
  freshInstance.classNameMut() = className; // dynamic type stays the instantiated class

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(*ctorDef, args, outScope, &freshInstance, definingClass))
    return Value(0);

  auto baseIt = outScope.find("base");
  Value result = (baseIt != outScope.end()) ? baseIt->second : freshInstance;

  // Traceability: one "init(...)" entry per instantiation.
  result.lineageMut().push_back("init(" + formatArgs(args) + ")");

  // Reversibility (opt-in): the first snapshot, so .rewind() with no
  // history-since-init still has something to restore to.
  if (classTable_[className].isReversible)
    result.snapshotsMut().push_back(result.dict());

  return result;
}

Value Parser::callInstanceMethod(const Value &selfBefore, const std::string &methodName,
                                  const std::vector<Value> &args, Value &outSelfAfter,
                                  bool &found) {
  outSelfAfter = selfBefore;

  std::string definingClass;
  const FunctionDef *def =
      findMethodInChain(selfBefore.className(), methodName, args.size(), definingClass);
  if (!def) {
    // Distinguish "no such method" (found=false, caller prints its own
    // "class has no method" error) from "method exists but not with this
    // arity" (print the more specific error here and set found=true so the
    // caller's generic fallback doesn't also fire).
    found = methodNameExistsInChain(selfBefore.className(), methodName);
    if (found) {
      std::cerr << "Error: no overload of method '" << methodName << "' on class '"
                << selfBefore.className() << "' takes " << args.size() << " argument(s)\n";
      evaluationSucceeded_ = false;
    }
    return Value(0);
  }
  found = true;

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(*def, args, outScope, &selfBefore, definingClass))
    return Value(0);

  auto baseIt = outScope.find("base");
  if (baseIt != outScope.end())
    outSelfAfter = baseIt->second;

  if (def->outputNames.empty()) {
    // Traceability: void method call, no "-> result" suffix.
    outSelfAfter.lineageMut().push_back(methodName + "(" + formatArgs(args) + ")");
    // Reversibility (opt-in): one snapshot per lineage entry, same index.
    if (classTable_[outSelfAfter.className()].isReversible)
      outSelfAfter.snapshotsMut().push_back(outSelfAfter.dict());
    return Value(0);
  }

  const std::string &outName = def->outputNames[0];
  auto oit = outScope.find(outName);
  if (oit == outScope.end()) {
    std::cerr << "Error: output '" << outName << "' not assigned in method '" << methodName
              << "'\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Traceability: one entry per successful method call, including its
  // result — this is deliberately logged on `outSelfAfter` (the instance
  // the call ran against), not on whatever Value the method happens to
  // return, since those are two different things (e.g. a method can return
  // a plain number while still being "an operation performed on this
  // object").
  outSelfAfter.lineageMut().push_back(methodName + "(" + formatArgs(args) +
                                  ") -> " + valueToString(oit->second));
  if (classTable_[outSelfAfter.className()].isReversible)
    outSelfAfter.snapshotsMut().push_back(outSelfAfter.dict());

  return oit->second;
}

/* ================= ENCAPSULATION ================= */

bool Parser::checkFieldAccess(const std::string &className, const std::string &fieldName) {
  // Find where fieldName's visibility was declared — may be an ancestor of
  // className, since fields are inherited implicitly (whatever constructor
  // in the chain sets them) even though visibility is declared once, at
  // whichever class actually introduced the field.
  std::string declaringClass;
  bool isProtected = false;
  bool restricted = false;
  {
    std::string cur = className;
    int guard = 0;
    while (!cur.empty() && guard++ < 64) {
      auto classIt = classTable_.find(cur);
      if (classIt == classTable_.end())
        break;
      auto visIt = classIt->second.restrictedFields.find(fieldName);
      if (visIt != classIt->second.restrictedFields.end()) {
        declaringClass = cur;
        isProtected = visIt->second;
        restricted = true;
        break;
      }
      cur = classIt->second.parentClassName;
    }
  }

  if (!restricted)
    return true; // never declared private/protected — public by default

  // private: only the exact declaring class's own methods.
  // protected: the declaring class's own methods, or any subclass's.
  bool selfAccess = !currentDefiningClass_.empty() &&
                     (isProtected ? isClassOrSubclassOf(currentDefiningClass_, declaringClass)
                                  : (currentDefiningClass_ == declaringClass));
  if (selfAccess)
    return true;

  std::cerr << "Error: field '" << fieldName << "' is "
            << (isProtected ? "protected" : "private") << " in class '" << declaringClass
            << "'\n";
  evaluationSucceeded_ = false;
  return false;
}
