// Class definitions: registering a `class ... csend` block (does NOT
// execute it, same as functions) and invoking a class's constructor
// (instantiation) or an instance method by name. A class body is a
// sequence of nested `function...fnend` method blocks accumulated as flat
// text by feedClassLine(); executeClassDefEnd() is what scans that text for
// each method's boundaries and registers them via the shared
// parseFunctionHeader() (parser_function.cpp). The constructor is just a
// method under the reserved name "base" with no declared output — see
// callClassConstructor() for how its mutated `base` scope becomes the new
// instance.
#include "parser.h"

#include <cctype>
#include <iostream>
#include <sstream>

#include "lexer.h"
#include "output.h"

namespace {
std::string trimLine(const std::string &s) {
  size_t a = s.find_first_not_of(" \t\r\n");
  if (a == std::string::npos) return std::string();
  size_t b = s.find_last_not_of(" \t\r\n");
  return s.substr(a, b - a + 1);
}
std::string toLowerStr(std::string s) {
  for (char &ch : s) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  return s;
}
// A method/constructor overload with no real body (fnend immediately after
// the header, or only blank lines in between) is a required-override
// contract — only meaningful inside an `abstract class`. Used both to
// validate a non-abstract class's own methods at registration time and to
// check whether a concrete subclass actually implemented an inherited
// abstract contract (validateConcreteInstantiation).
bool isBodyEmpty(const std::vector<std::string> &bodyLines) {
  for (const auto &line : bodyLines) {
    if (!trimLine(line).empty())
      return false;
  }
  return true;
}
// Traceability: comma-joined, human-readable rendering of a call's
// arguments, used to build lineage entries like "Scale(2)" / "init(23.5)".
std::string formatArgs(const std::vector<Value> &args) {
  std::string out;
  for (size_t i = 0; i < args.size(); i++) {
    if (i > 0) out += ", ";
    out += valueToString(args[i]);
  }
  return out;
}
} // namespace

/* ================= TERMINATOR ================= */

bool Parser::isClassTerm(const std::string &lower) {
  return lower == "csend";
}

/* ================= DEFINITION: register (don't run) ================= */

Value Parser::executeClassDefEnd() {
  inClassBlock_ = false;

  Lexer headerLex(classHeader_);
  auto headerToks = headerLex.tokenize();
  setTokens(headerToks);

  auto fail = [&](const std::string &msg) -> Value {
    std::cerr << "Error: " << msg << "\n";
    pendingClassBlock_.clear();
    classHeader_.clear();
    return Value(0);
  };

  // ABSTRACT/REVERSIBLE are independent modifiers, allowed in either order
  // before the mandatory CLASS token (each optional; `abstract reversible
  // class` and `reversible abstract class` both work).
  bool isAbstract = false;
  bool isReversible = false;
  while (current().type == ABSTRACT || current().type == REVERSIBLE) {
    if (current().type == ABSTRACT) isAbstract = true;
    else isReversible = true;
    advance();
  }

  if (current().type != CLASS)
    return fail("expected 'class' keyword");
  advance();

  if (current().type != IDENT)
    return fail("expected class name after 'class'");
  std::string className = current().text;
  advance();

  if (current().type != LPAREN)
    return fail("expected '(' after class name");
  advance();

  // Optional single parent class name: class Child(Parent). Only stored
  // here, never resolved — Parent may legally be defined later in the file
  // (findMethodInChain/isClassOrSubclassOf resolve it lazily at call time).
  std::string parentClassName;
  if (current().type == IDENT) {
    parentClassName = current().text;
    advance();
  }

  if (current().type != RPAREN)
    return fail("expected ')' after class header (only a single optional parent class name is "
                "supported inside the parens)");
  advance();

  // Optional Temporal Determinism annotation: @rate(500Hz) or @rate(500) —
  // "rate" is matched by text, not reserved as a keyword, since it's only
  // meaningful in this one exact position (same precedent as `new`/
  // `clear`/`parent`). The unit suffix (e.g. "Hz") is accepted but ignored
  // beyond validating it's an identifier — no unit system exists in this
  // language to convert anything else against.
  bool hasRate = false;
  double rateHz = 0.0;
  if (current().type == AT) {
    advance();
    if (current().type != IDENT || current().text != "rate")
      return fail("expected 'rate' after '@'");
    advance();
    if (current().type != LPAREN)
      return fail("expected '(' after '@rate'");
    advance();
    if (current().type != NUMBER)
      return fail("expected a numeric rate inside '@rate(...)'");
    rateHz = std::stod(current().text);
    advance();
    if (current().type == IDENT)
      advance(); // optional unit suffix, e.g. "Hz" — accepted, not converted
    if (current().type != RPAREN)
      return fail("expected ')' to close '@rate(...)'");
    advance();
    if (rateHz <= 0.0)
      return fail("'@rate(...)' must be a positive number");
    hasRate = true;
  }

  std::vector<std::string> bodyLines;
  std::istringstream bodyStream(pendingClassBlock_);
  std::string bodyLine;
  while (std::getline(bodyStream, bodyLine))
    bodyLines.push_back(bodyLine);

  ClassDef def;

  for (size_t li = 0; li < bodyLines.size(); li++) {
    std::string trimmed = trimLine(bodyLines[li]);
    if (trimmed.empty())
      continue;
    std::string lower = toLowerStr(trimmed);

    bool isHeader = lower.rfind("function", 0) == 0 &&
        (lower.size() == 8 || std::isspace((unsigned char)lower[8]));

    bool isPrivateDecl = lower.rfind("private", 0) == 0 &&
        (lower.size() == 7 || std::isspace((unsigned char)lower[7]));
    bool isProtectedDecl = lower.rfind("protected", 0) == 0 &&
        (lower.size() == 9 || std::isspace((unsigned char)lower[9]));

    if (isPrivateDecl || isProtectedDecl) {
      // "private mean, median, std;" / "protected count;" — a pure
      // visibility annotation on field names, not a body block, so this
      // consumes only the one line, no nested boundary scan needed.
      Lexer declLex(trimmed);
      auto declToks = declLex.tokenize();
      size_t dp = 0;
      auto dcur = [&]() -> Token {
        return dp < declToks.size() ? declToks[dp] : Token{END, ""};
      };
      auto dadv = [&]() { if (dp < declToks.size()) dp++; };

      dadv(); // consume PRIVATE/PROTECTED
      if (dcur().type != IDENT) {
        std::cerr << "Error: expected a field name after '"
                  << (isPrivateDecl ? "private" : "protected") << "' in class '" << className
                  << "'\n";
        pendingClassBlock_.clear();
        classHeader_.clear();
        return Value(0);
      }
      def.restrictedFields[dcur().text] = isProtectedDecl;
      dadv();
      while (dcur().type == COMMA) {
        dadv();
        if (dcur().type != IDENT) {
          std::cerr << "Error: expected a field name after ',' in class '" << className << "'\n";
          pendingClassBlock_.clear();
          classHeader_.clear();
          return Value(0);
        }
        def.restrictedFields[dcur().text] = isProtectedDecl;
        dadv();
      }
      continue;
    }

    if (!isHeader) {
      std::cerr << "Error: expected a method ('function ...') or a visibility declaration "
                   "('private'/'protected') inside class '"
                << className << "', got: " << trimmed << "\n";
      pendingClassBlock_.clear();
      classHeader_.clear();
      return Value(0);
    }

    std::string methodHeaderLine = trimmed;
    std::vector<std::string> methodBodyLines;
    size_t bi = li + 1;
    bool closed = false;
    while (bi < bodyLines.size()) {
      std::string bLower = toLowerStr(trimLine(bodyLines[bi]));
      if (Parser::isFunctionTerm(bLower)) {
        closed = true;
        bi++;
        break;
      }
      methodBodyLines.push_back(bodyLines[bi]);
      bi++;
    }
    li = bi - 1;

    if (!closed) {
      std::cerr << "Error: unclosed method definition inside class '" << className
                << "' (expected 'fnend')\n";
      pendingClassBlock_.clear();
      classHeader_.clear();
      return Value(0);
    }

    std::string methodName;
    FunctionDef methodDef;
    if (!parseFunctionHeader(methodHeaderLine, methodName, methodDef)) {
      pendingClassBlock_.clear();
      classHeader_.clear();
      return Value(0);
    }
    methodDef.bodyLines = std::move(methodBodyLines);

    if (!isAbstract && isBodyEmpty(methodDef.bodyLines)) {
      std::cerr << "Error: method '" << methodName << "' in non-abstract class '" << className
                << "' has no body (mark '" << className
                << "' abstract, or implement the method)\n";
      pendingClassBlock_.clear();
      classHeader_.clear();
      return Value(0);
    }

    registerOverload(def.methods, methodName, std::move(methodDef));
  }

  def.parentClassName = parentClassName;
  def.isAbstract = isAbstract;
  def.isReversible = isReversible;
  def.hasRate = hasRate;
  def.rateHz = rateHz;
  classTable_[className] = std::move(def);

  pendingClassBlock_.clear();
  classHeader_.clear();
  return Value(0);
}

/* ================= INHERITANCE RESOLUTION ================= */

bool Parser::findMethodInChain(const std::string &className, const std::string &methodName,
                                size_t argCount, std::string &outDefiningClass,
                                FunctionDef &outDef) {
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false; // dangling/unregistered class name in the chain
    auto methodIt = classIt->second.methods.find(methodName);
    if (methodIt != classIt->second.methods.end()) {
      const FunctionDef *defPtr = findOverload(methodIt->second, argCount);
      if (defPtr) {
        outDefiningClass = cur;
        outDef = *defPtr;
        return true;
      }
      // Name exists at this level but not with this arity — keep walking
      // up in case an ancestor has the matching overload, rather than
      // stopping just because the name was present here.
    }
    cur = classIt->second.parentClassName;
  }
  return false;
}

bool Parser::methodNameExistsInChain(const std::string &className, const std::string &methodName) {
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false;
    if (classIt->second.methods.count(methodName))
      return true;
    cur = classIt->second.parentClassName;
  }
  return false;
}

bool Parser::isClassOrSubclassOf(const std::string &candidate, const std::string &ancestor) {
  std::string cur = candidate;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    if (cur == ancestor)
      return true;
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false;
    cur = classIt->second.parentClassName;
  }
  return false;
}

bool Parser::findRateInChain(const std::string &className, double &outRateHz) {
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      return false;
    if (classIt->second.hasRate) {
      outRateHz = classIt->second.rateHz;
      return true;
    }
    cur = classIt->second.parentClassName;
  }
  return false;
}

Value Parser::callParentConstructor(const std::vector<Value> &args) {
  if (currentDefiningClass_.empty()) {
    std::cerr << "Error: 'parent(...)' used outside a class method\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  auto classIt = classTable_.find(currentDefiningClass_);
  if (classIt == classTable_.end() || classIt->second.parentClassName.empty()) {
    std::cerr << "Error: class '" << currentDefiningClass_ << "' has no parent class\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  std::string parentClass = classIt->second.parentClassName;

  std::string definingClass;
  FunctionDef ctorDef;
  if (!findMethodInChain(parentClass, "base", args.size(), definingClass, ctorDef)) {
    if (methodNameExistsInChain(parentClass, "base")) {
      std::cerr << "Error: no constructor of parent class '" << parentClass << "' takes "
                << args.size() << " argument(s)\n";
    } else {
      std::cerr << "Error: parent class '" << parentClass << "' has no constructor\n";
    }
    evaluationSucceeded_ = false;
    return Value(0);
  }

  if (!memory.count("base") || !memory["base"].isObject) {
    // Defensive — parent(...) only makes sense while base is being built.
    std::cerr << "Error: 'parent(...)' used outside a constructor\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Run the parent's constructor against the CURRENT, already-partially-
  // built base (not a fresh instance) — this is what makes it "chain into"
  // rather than "replace".
  Value selfValue = memory["base"];
  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(ctorDef, args, outScope, &selfValue, definingClass))
    return Value(0);

  auto baseIt = outScope.find("base");
  if (baseIt != outScope.end())
    memory["base"] = baseIt->second;

  return Value(0);
}

/* ================= ABSTRACTION ================= */

bool Parser::validateConcreteInstantiation(const std::string &className) {
  auto classIt = classTable_.find(className);
  if (classIt == classTable_.end())
    return true; // caller already checked existence

  if (classIt->second.isAbstract) {
    std::cerr << "Error: cannot instantiate abstract class '" << className << "'\n";
    evaluationSucceeded_ = false;
    return false;
  }

  // Walk className's own chain looking for abstract ancestors, and check
  // each of their bodyless (required-override) method/constructor
  // contracts is actually satisfied by a real implementation somewhere in
  // className's resolvable chain.
  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto curIt = classTable_.find(cur);
    if (curIt == classTable_.end())
      break;

    if (curIt->second.isAbstract) {
      for (const auto &entry : curIt->second.methods) {
        const std::string &methodName = entry.first;
        for (const auto &overload : entry.second) {
          if (!isBodyEmpty(overload.bodyLines))
            continue; // this overload already has a real implementation

          size_t arity = overload.inputNames.size();
          std::string resolvedClass;
          FunctionDef resolved;
          bool implemented = findMethodInChain(className, methodName, arity, resolvedClass,
                                                resolved) &&
                              !isBodyEmpty(resolved.bodyLines);
          if (!implemented) {
            std::cerr << "Error: class '" << className << "' must implement abstract method '"
                      << methodName << "' (inherited from '" << cur << "')\n";
            evaluationSucceeded_ = false;
            return false;
          }
        }
      }
    }

    cur = curIt->second.parentClassName;
  }

  return true;
}

/* ================= INVOCATION ================= */

Value Parser::callClassConstructor(const std::string &className, const std::vector<Value> &args,
                                    bool &found) {
  if (!classTable_.count(className)) {
    found = false;
    return Value(0);
  }
  found = true;

  if (!validateConcreteInstantiation(className))
    return Value(0);

  std::string definingClass;
  FunctionDef ctorDef;
  if (!findMethodInChain(className, "base", args.size(), definingClass, ctorDef)) {
    if (methodNameExistsInChain(className, "base")) {
      std::cerr << "Error: no constructor of class '" << className << "' takes " << args.size()
                << " argument(s)\n";
    } else {
      std::cerr << "Error: class '" << className
                << "' has no constructor (missing 'function base(...)')\n";
    }
    evaluationSucceeded_ = false;
    return Value(0);
  }

  Value freshInstance;
  freshInstance.isObject = true;
  freshInstance.className = className; // dynamic type stays the instantiated class

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(ctorDef, args, outScope, &freshInstance, definingClass))
    return Value(0);

  auto baseIt = outScope.find("base");
  Value result = (baseIt != outScope.end()) ? baseIt->second : freshInstance;

  // Traceability: one "init(...)" entry per instantiation.
  result.lineage.push_back("init(" + formatArgs(args) + ")");

  // Reversibility (opt-in): the first snapshot, so .rewind() with no
  // history-since-init still has something to restore to.
  if (classTable_[className].isReversible)
    result.snapshots.push_back(result.dictMap);

  return result;
}

Value Parser::callInstanceMethod(const Value &selfBefore, const std::string &methodName,
                                  const std::vector<Value> &args, Value &outSelfAfter,
                                  bool &found) {
  outSelfAfter = selfBefore;

  std::string definingClass;
  FunctionDef def;
  if (!findMethodInChain(selfBefore.className, methodName, args.size(), definingClass, def)) {
    // Distinguish "no such method" (found=false, caller prints its own
    // "class has no method" error) from "method exists but not with this
    // arity" (print the more specific error here and set found=true so the
    // caller's generic fallback doesn't also fire).
    found = methodNameExistsInChain(selfBefore.className, methodName);
    if (found) {
      std::cerr << "Error: no overload of method '" << methodName << "' on class '"
                << selfBefore.className << "' takes " << args.size() << " argument(s)\n";
      evaluationSucceeded_ = false;
    }
    return Value(0);
  }
  found = true;

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope, &selfBefore, definingClass))
    return Value(0);

  auto baseIt = outScope.find("base");
  if (baseIt != outScope.end())
    outSelfAfter = baseIt->second;

  if (def.outputNames.empty()) {
    // Traceability: void method call, no "-> result" suffix.
    outSelfAfter.lineage.push_back(methodName + "(" + formatArgs(args) + ")");
    // Reversibility (opt-in): one snapshot per lineage entry, same index.
    if (classTable_[outSelfAfter.className].isReversible)
      outSelfAfter.snapshots.push_back(outSelfAfter.dictMap);
    return Value(0);
  }

  const std::string &outName = def.outputNames[0];
  auto oit = outScope.find(outName);
  if (oit == outScope.end()) {
    std::cerr << "Error: output '" << outName << "' not assigned in method '" << methodName
              << "'\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }

  // Traceability: one entry per successful method call, including its
  // result — this is deliberately logged on `outSelfAfter` (the instance
  // the call ran against), not on whatever Value the method happens to
  // return, since those are two different things (e.g. a method can return
  // a plain number while still being "an operation performed on this
  // object").
  outSelfAfter.lineage.push_back(methodName + "(" + formatArgs(args) +
                                  ") -> " + valueToString(oit->second));
  if (classTable_[outSelfAfter.className].isReversible)
    outSelfAfter.snapshots.push_back(outSelfAfter.dictMap);

  return oit->second;
}

/* ================= ENCAPSULATION ================= */

bool Parser::checkFieldAccess(const std::string &className, const std::string &fieldName) {
  // Find where fieldName's visibility was declared — may be an ancestor of
  // className, since fields are inherited implicitly (whatever constructor
  // in the chain sets them) even though visibility is declared once, at
  // whichever class actually introduced the field.
  std::string declaringClass;
  bool isProtected = false;
  bool restricted = false;
  {
    std::string cur = className;
    int guard = 0;
    while (!cur.empty() && guard++ < 64) {
      auto classIt = classTable_.find(cur);
      if (classIt == classTable_.end())
        break;
      auto visIt = classIt->second.restrictedFields.find(fieldName);
      if (visIt != classIt->second.restrictedFields.end()) {
        declaringClass = cur;
        isProtected = visIt->second;
        restricted = true;
        break;
      }
      cur = classIt->second.parentClassName;
    }
  }

  if (!restricted)
    return true; // never declared private/protected — public by default

  // private: only the exact declaring class's own methods.
  // protected: the declaring class's own methods, or any subclass's.
  bool selfAccess = !currentDefiningClass_.empty() &&
                     (isProtected ? isClassOrSubclassOf(currentDefiningClass_, declaringClass)
                                  : (currentDefiningClass_ == declaringClass));
  if (selfAccess)
    return true;

  std::cerr << "Error: field '" << fieldName << "' is "
            << (isProtected ? "protected" : "private") << " in class '" << declaringClass
            << "'\n";
  evaluationSucceeded_ = false;
  return false;
}
