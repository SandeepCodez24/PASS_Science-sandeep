#pragma once

#include <string>
#include <vector>

#include "value.h"

// Helpers shared across the Parser's implementation files. Not part of the
// public Parser API - only parser_*.cpp files should include this.

// Shared by executeForBlock() (parser_block_exec.cpp, the defining owner)
// and parseFactor()'s range literals (parser_factor.cpp). leftBracket is
// '[' (inclusive start) or '(' (exclusive start); rightBracket is ']'
// (inclusive end) or ')' (exclusive end).
std::vector<double> generateRange(double start, double step, double end,
                                   char leftBracket, char rightBracket);

// Dict keys are always stored/looked-up as strings: text values use their
// text as-is, numeric values are formatted the same way printed output is.
// Shared by parseStatement()'s dict assignment (parser_statement.cpp, the
// defining owner) and parseFactor()'s dict key read (parser_factor.cpp).
std::string dictKeyOf(const Value &key);
