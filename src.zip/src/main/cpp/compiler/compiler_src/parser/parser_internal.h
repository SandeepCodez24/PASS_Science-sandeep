#pragma once

#include <string>
#include <vector>

#include "parser.h"
#include "value.h"

// Helpers shared across the Parser's implementation files. Not part of the
// public Parser API - only parser_*.cpp files should include this.

// Suppresses Parser::saveToFile() for its lifetime by holding
// suppressPersistence_ incremented. A loop body runs many iterations of
// assignments that would otherwise each trigger a full variables.txt
// rewrite (see saveToFile() in variable_store.cpp - it's a full rewrite of
// every variable on every call, not an incremental append), which made sys
// time dominate wall-clock time for any top-level loop with real iteration
// counts. Suppressing for the whole loop and relying on one saveToFile()
// call once the loop finishes cuts that from O(iterations) disk rewrites
// down to 1 - the same trade a function call's body already makes for its
// own locals (see invokeFunctionBody in parser_function.cpp). RAII rather
// than a bare increment/decrement so an early return from anywhere inside
// the guarded scope can never leak the suppression. Used by the
// tree-walking evaluator's For/While handling (parser_exec_stmt.cpp).
struct PersistenceSuppressor {
  Parser &parser;
  explicit PersistenceSuppressor(Parser &p) : parser(p) { parser.suppressPersistence_++; }
  ~PersistenceSuppressor() { parser.suppressPersistence_--; }
};

// Shared by parser_exec_stmt.cpp's For-statement evaluation (defined in
// parser_block_exec.cpp) and parseFactor()'s range literals
// (parser_factor.cpp). leftBracket is '[' (inclusive start) or '('
// (exclusive start); rightBracket is ']' (inclusive end) or ')' (exclusive
// end).
std::vector<double> generateRange(double start, double step, double end,
                                   char leftBracket, char rightBracket);

// Dict keys are always stored/looked-up as strings: text values use their
// text as-is, numeric values are formatted the same way printed output is.
// Shared by the dict-key assignment/read paths (parser_exec_stmt.cpp,
// parser_factor.cpp; defined in parser_statement.cpp).
std::string dictKeyOf(const Value &key);
