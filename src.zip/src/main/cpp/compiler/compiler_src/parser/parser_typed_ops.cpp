// R9 (2026-11-14): binary operators on arrays / matrices that hold typed
// elements (int8 ... uint64, bool, float32/16/8 - see NumTensor in
// core/value.h).
//
// The rule is simple: an element-wise result is exactly what the scalar
// operator gives for each pair of elements (ops/integer/integer.h,
// ops/floating/floating.h). So uint8 + uint8 stays uint8 and an overflow is
// an error, uint8 + int16 is an error, int + float64 / bool is float64,
// int / int is float64, float32 with anything but a wider float stays
// float32. The result packs into a typed tensor again when its elements
// share one type.
//
// Three ways to get there, all giving the scalar operator's result:
//   * widen: when the scalar rule computes in float64 anyway (int with
//     float64 or bool, bool with anything, `/`), the typed side becomes a
//     plain float64 tensor and the existing fast path runs; float32/16/8
//     results are rounded to their format afterwards, as the scalar path
//     does;
//   * a native kernel for + - * of one integer type (overflow checked per
//     element; the element that overflows is handed to the scalar operator
//     to print the exact error);
//   * otherwise the scalar operator element by element (// % ^, mixed cells,
//     units, the matrix product of integers).
#include "parser.h"

#include <cstring>
#include <iostream>

#include "parallel/par.h"
#include "../ops/floating/floating.h"
#include "../ops/integer/integer.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/matrix/matrix_ops.h"

#include <limits>

namespace {

bool container(const Value &v) { return v.isArray || v.isMatrix; }

size_t elemCount(const Value &v)
{
    if (v.isND())
        return v.ndCount();
    if (v.isArray)
        return v.length();
    return v.rows() * v.cols();
}

// Element k: array order; a 2-D matrix row by row; an N-D matrix in storage order.
Value elemAt(const Value &v, size_t k)
{
    if (v.isND())
        return v.ndAt(k);
    if (v.isArray)
        return v.at(k);
    const size_t c = v.cols();
    return v.at(k / c, k % c);
}

// Typed elements: a typed tensor, or cells with at least one typed scalar.
bool hasTypedElems(const Value &v)
{
    if (!container(v))
        return false;
    if (v.isTypedPacked())
        return true;
    if (v.isPacked() || v.isPackedComplex())
        return false;
    const size_t n = elemCount(v);
    for (size_t k = 0; k < n; k++)
        if (Value::scalarElemType(elemAt(v, k)) != ElemType::F64)
            return true;
    return false;
}

// The one element type of a container / scalar; `uniform` false for cells
// (their elements may differ).
ElemType kindOf(const Value &v, bool &uniform)
{
    uniform = true;
    if (!container(v))
        return Value::scalarElemType(v);
    if (v.isTypedPacked())
        return v.elemType();
    if (v.isPacked() || v.isPackedComplex())
        return ElemType::F64;
    uniform = false;
    return ElemType::F64;
}

bool isIntKind(ElemType t) { return t >= ElemType::I8 && t <= ElemType::U64; }
bool isFloatKind(ElemType t) { return t == ElemType::F32 || t == ElemType::F16 || t == ElemType::F8; }

// A typed tensor as the plain float64 tensor of the same values (what the
// scalar rule computes with); anything else as it is.
Value widen(const Value &v)
{
    if (!container(v)) {
        Value s = v;
        s.dropScalarType();
        return s;
    }
    if (!v.isTypedPacked())
        return v;
    const size_t n = v.tensorCount();
    nc::F64Buf buf(n); // every element written (the plan cannot stop)
    // Several cores (2026-11-21): each element on its own, same values. Stop
    // is ignored here (a half-widened operand cannot be used) - the
    // statement stops right after.
    nc::par::Plan plan = nc::par::plan(n, nc::par::stream(1.5));
    plan.stoppable = false;
    double *dst = buf.data();
    nc::par::forPlan(plan, nc::par::Kind::Stream, "widen", [&](size_t b, size_t e) {
        for (size_t k = b; k < e; k++)
            dst[k] = v.typedNumAt(k);
    });
    // same shape and unit, float64 buffer (ndPacked takes any shape)
    Value out = Value::ndPacked(v.tensorShape(), std::move(buf), false, v.tensorDimL(), v.tensorDimT(),
                                v.tensorDimM());
    if (v.tensorShape().size() == 1) {
        out.isMatrix = false;
        out.isArray = true;
    }
    return out;
}

// Rounds every element of a float64 result to float type `t` (the scalar
// path's applyFloatType, element by element), giving typed elements.
Value roundTo(const Value &v, FloatType t)
{
    if (!container(v))
        return applyFloatType(v, t);
    const ElemType et = t == FloatType::Float32 ? ElemType::F32 : t == FloatType::Float16 ? ElemType::F16 : ElemType::F8;
    if (v.isPacked()) { // the usual case: float64 buffer -> typed float tensor
        const std::vector<size_t> &shape = v.ndShape().empty() ? v.tensorShape() : v.ndShape();
        size_t n = 1;
        for (size_t d : shape)
            n *= d;
        // float32: 4-byte floats; float16 / float8: their own 2- / 1-byte
        // bits (core/narrow_float.h, 2026-11-21)
        const size_t w = elemTypeBytes(et);
        std::vector<uint8_t> raw(n * w);
        const double *src = v.packedData();
        uint8_t *dst = raw.data();
        // Several cores (2026-11-21), each element on its own: same bits.
        nc::par::Plan plan = nc::par::plan(n, nc::par::compute(15.0));
        plan.stoppable = false; // a half-rounded result cannot be handed back
        nc::par::forPlan(plan, nc::par::Kind::Compute, floatTypeName(t), [&](size_t b, size_t e) {
            for (size_t k = b; k < e; k++) {
                // The store rounds (ties to even) exactly as roundToFloatType()
                // does - src/test/narrow_float_check.cpp.
                const double x = src[k];
                if (et == ElemType::F16)
                    ncfloat::storeF16(dst + 2 * k, x);
                else if (et == ElemType::F8)
                    ncfloat::storeF8(dst + k, x);
                else
                    ncfloat::storeF32(dst + 4 * k, x);
            }
        });
        return Value::typedTensor(et, shape, std::move(raw), v.tensorDimL(), v.tensorDimT(), v.tensorDimM());
    }
    Value out = v; // cells: each real element rounded and tagged
    out.transformElems([&](const Value &e) { return applyFloatType(e, t); });
    return out;
}

// Exact integer kernel for + - * of one integer type. Returns false at the
// first element whose result leaves the type (`bad` = its index).
template <typename T, typename W>
bool intKernel(char op, const uint8_t *a, bool aScalar, const uint8_t *b, bool bScalar, uint8_t *out, size_t n,
               size_t &bad)
{
    const T lo = std::numeric_limits<T>::min(), hi = std::numeric_limits<T>::max();
    for (size_t k = 0; k < n; k++) {
        T x, y;
        std::memcpy(&x, a + (aScalar ? 0 : k * sizeof(T)), sizeof(T));
        std::memcpy(&y, b + (bScalar ? 0 : k * sizeof(T)), sizeof(T));
        T r;
        if constexpr (sizeof(T) < 8) {
            const W wx = static_cast<W>(x), wy = static_cast<W>(y);
            const W w = op == '+' ? wx + wy : op == '-' ? wx - wy : wx * wy;
            if (w < static_cast<W>(lo) || w > static_cast<W>(hi)) {
                bad = k;
                return false;
            }
            r = static_cast<T>(w);
        } else {
            const bool overflow = op == '+'   ? __builtin_add_overflow(x, y, &r)
                                  : op == '-' ? __builtin_sub_overflow(x, y, &r)
                                              : __builtin_mul_overflow(x, y, &r);
            if (overflow) {
                bad = k;
                return false;
            }
        }
        std::memcpy(out + k * sizeof(T), &r, sizeof(T));
    }
    return true;
}

// The raw bytes of a typed scalar of element type t (for broadcasting).
std::vector<uint8_t> scalarBytes(const Value &s, ElemType t)
{
    std::vector<uint8_t> raw(elemTypeBytes(t));
    Value tmp = Value::typedTensor(t, {1}, raw);
    tmp.setAt(0, s);
    std::memcpy(raw.data(), tmp.typedData(), raw.size());
    return raw;
}

} // namespace

bool Parser::typedBinaryOp(const std::string &opIn, const Value &vIn, const Value &rIn, Value &out)
{
    if (!hasTypedElems(vIn) && !hasTypedElems(rIn))
        return false;
    static const char *const kOps[] = {"+", "-", "*", "/", "%", "//", "^", "*.", "/.", "^."};
    bool known = false;
    for (const char *o : kOps)
        known = known || opIn == o;
    if (!known)
        return false;

    Value v = vIn, r = rIn;
    // a 1-D array meeting a matrix takes part as a row / column (as below
    // in evaluateBinaryOpValues)
    if (v.isArray && r.isMatrix && !r.isND())
        v = matArrayAsMatrix(v, r.rows() > 1 && r.cols() == 1);
    else if (r.isArray && v.isMatrix && !v.isND())
        r = matArrayAsMatrix(r, v.rows() > 1 && v.cols() == 1);

    // `*` `/` `^` between two 2-D matrices (or matrix ^ number) are the
    // matrix product / division / power, not element-wise.
    const bool matrixOp = (opIn == "*" && v.isMatrix && r.isMatrix && !v.isND() && !r.isND()) ||
                          (opIn == "/" && r.isMatrix && !r.isND()) || (opIn == "^" && v.isMatrix && !v.isND());
    const std::string op = opIn == "*." ? "*" : opIn == "/." ? "/" : opIn == "^." ? "^" : opIn;

    bool ua, ub;
    const ElemType ka = kindOf(v, ua), kb = kindOf(r, ub);

    // ---- float32 / 16 / 8 involved: compute as float64, round (the scalar rule)
    if (ua && ub && (isFloatKind(ka) || isFloatKind(kb))) {
        const Value sa = container(v) ? (elemCount(v) ? elemAt(v, 0) : Value(0.0)) : v;
        const Value sb = container(r) ? (elemCount(r) ? elemAt(r, 0) : Value(0.0)) : r;
        const FloatType ft = binaryResultFloatType(sa, sb);
        if (ft != FloatType::Float64) {
            Value plain = evaluateBinaryOpValues(opIn, widen(v), widen(r));
            out = evaluationSucceeded_ ? roundTo(plain, ft) : plain;
            return true;
        }
    }

    // ---- the matrix product of two matrices of one integer type: exact,
    //      element by element through the scalar operators
    if (matrixOp && opIn == "*" && ua && ub && isIntKind(ka) && ka == kb) {
        const size_t n = v.rows(), m = v.cols(), p = r.cols();
        if (m != r.rows()) {
            out = evaluateBinaryOpValues(opIn, widen(v), widen(r)); // the usual dimension error
            return true;
        }
        std::vector<std::vector<Value>> grid(n, std::vector<Value>(p));
        for (size_t i = 0; i < n; i++)
            for (size_t j = 0; j < p; j++) {
                Value acc;
                for (size_t k = 0; k < m; k++) {
                    Value prod = evaluateBinaryOpValues("*", v.at(i, k), r.at(k, j));
                    if (!evaluationSucceeded_) {
                        out = Value(0);
                        return true;
                    }
                    acc = k == 0 ? prod : evaluateBinaryOpValues("+", acc, prod);
                    if (!evaluationSucceeded_) {
                        out = Value(0);
                        return true;
                    }
                }
                grid[i][j] = m == 0 ? Value::typedScalar(ka, 0, 0.0) : acc;
            }
        out = Value(std::move(grid));
        return true;
    }

    // ---- the scalar rule computes in float64: widen and use the fast path
    if (ua && ub) {
        const bool intPair = isIntKind(ka) && isIntKind(kb);
        const bool sameInt = intPair && ka == kb;
        const bool mixedInt = intPair && ka != kb;
        if (matrixOp || (!intPair && !mixedInt) || (sameInt && op == "/")) {
            // int with float64 / bool, bool with anything, int / int,
            // matrix division / power: float64
            if (!mixedInt) {
                out = evaluateBinaryOpValues(opIn, widen(v), widen(r));
                return true;
            }
        }
        // ---- one integer type, + - *: native kernel
        const bool noUnits = (!container(v) ? (v.dimL | v.dimT | v.dimM) == 0
                                            : (v.tensorDimL() | v.tensorDimT() | v.tensorDimM()) == 0) &&
                             (!container(r) ? (r.dimL | r.dimT | r.dimM) == 0
                                            : (r.tensorDimL() | r.tensorDimT() | r.tensorDimM()) == 0);
        if (sameInt && noUnits && (op == "+" || op == "-" || op == "*")) {
            const bool vc = container(v), rc = container(r);
            const Value &shapeOf = vc ? v : r;
            if (vc && rc && v.tensorShape() != r.tensorShape()) {
                // shapes differ: let the scalar loop below report it
            } else {
                const size_t n = shapeOf.tensorCount();
                const std::vector<uint8_t> sa = vc ? std::vector<uint8_t>() : scalarBytes(v, ka);
                const std::vector<uint8_t> sb = rc ? std::vector<uint8_t>() : scalarBytes(r, kb);
                const uint8_t *pa = vc ? v.typedData() : sa.data();
                const uint8_t *pb = rc ? r.typedData() : sb.data();
                std::vector<uint8_t> raw(n * elemTypeBytes(ka));
                size_t bad = 0;
                bool ok = true;
                const char c = op[0];
                switch (ka) {
                case ElemType::I8: ok = intKernel<int8_t, int32_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::I16: ok = intKernel<int16_t, int32_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::I32: ok = intKernel<int32_t, int64_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::I64: ok = intKernel<int64_t, int64_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::U8: ok = intKernel<uint8_t, int32_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::U16: ok = intKernel<uint16_t, int32_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::U32: ok = intKernel<uint32_t, int64_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                case ElemType::U64: ok = intKernel<uint64_t, uint64_t>(c, pa, !vc, pb, !rc, raw.data(), n, bad); break;
                default: break;
                }
                if (!ok) {
                    // the scalar operator prints the exact overflow error for
                    // the first element that overflows (`bad`, storage order)
                    auto storageElem = [&](const Value &c) {
                        if (c.isND())
                            return c.ndAt(bad);
                        if (c.isArray)
                            return c.at(bad);
                        return c.at(bad % c.rows(), bad / c.rows());
                    };
                    evaluateBinaryOpValues(op, vc ? storageElem(v) : v, rc ? storageElem(r) : r);
                    evaluationSucceeded_ = false;
                    out = Value(0);
                    return true;
                }
                out = Value::typedTensor(ka, shapeOf.tensorShape(), std::move(raw));
                return true;
            }
        }
    }

    // ---- element by element through the scalar operator
    const bool vc = container(v), rc = container(r);
    if (vc && rc) {
        const bool same = v.isND() || r.isND()
                              ? (v.isND() && r.isND() && v.ndShape() == r.ndShape())
                          : v.isArray != r.isArray ? false
                          : v.isArray            ? v.length() == r.length()
                                                 : (v.rows() == r.rows() && (v.rows() == 0 || v.cols() == r.cols()));
        if (!same) {
            std::cerr << "Error: "
                      << (v.isArray && r.isArray ? "mismatched array lengths in elementwise operation"
                                                 : "mismatched matrix dimensions in elementwise operation")
                      << "\n";
            evaluationSucceeded_ = false;
            out = Value(0);
            return true;
        }
    }
    const Value &shape = vc ? v : r;
    const size_t n = elemCount(shape);
    std::vector<Value> cells;
    cells.reserve(n);
    nc::par::SerialProgress progress(nullptr, n); // the operator's progress (2026-11-21)
    for (size_t k = 0; k < n; k++) {
        Value e = evaluateBinaryOpValues(op, vc ? elemAt(v, k) : v, rc ? elemAt(r, k) : r);
        if (!evaluationSucceeded_) {
            out = Value(0);
            return true;
        }
        cells.push_back(std::move(e));
        progress.tick(k);
    }
    if (shape.isND()) {
        // elemAt walks storage order for N-D
        out = Value::ndFromCells(shape.ndShape(), std::move(cells));
    } else if (shape.isArray) {
        out = Value(std::move(cells));
    } else {
        const size_t rows = shape.rows(), cols = shape.cols();
        std::vector<std::vector<Value>> grid(rows);
        for (size_t i = 0; i < rows; i++)
            grid[i].assign(std::make_move_iterator(cells.begin() + static_cast<std::ptrdiff_t>(i * cols)),
                           std::make_move_iterator(cells.begin() + static_cast<std::ptrdiff_t>((i + 1) * cols)));
        out = Value(std::move(grid));
    }
    return true;
}
