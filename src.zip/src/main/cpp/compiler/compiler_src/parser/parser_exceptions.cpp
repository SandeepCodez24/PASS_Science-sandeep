// Errors and assertions (2026-11-09): try ... except ... success ... always
// ... tend, escalate, the built-in exception types, warnings, the trace
// functions and the assert_* unit-test functions. Parsing lives with the
// other statements in parser_program.cpp (parseTryStmtNode(),
// parseEscalateStmtNode(), parseAssertStmtNode()); this file is what they
// do when they run.
//
// HOW AN ERROR IS CAUGHT
//   nc.exe has no C++ exceptions for script errors: a failing statement
//   prints its message to std::cerr and the script unwinds (Parser::
//   errorAbort_, parser.h). A try block therefore works with that same
//   mechanism:
//     1. while the try body runs, nc::errorlines holds back the error lines
//        written to std::cerr (error_lines.h, beginCapture());
//     2. when the body stopped on an error, the held-back text tells what
//        went wrong. An error raised by `escalate` (or by an assert_*
//        function) is remembered exactly (pendingException_); any other
//        error is given the closest kind from its wording
//        (exceptionKindOfMessage() below);
//     3. the first except block whose type fits handles it: the held-back
//        lines are dropped, the unwind is cancelled and the block runs.
//        When none fits, the lines are printed as they would have been
//        without the try block and the unwind goes on.
//   Stop in the IDE is never caught.
//
// AN EXCEPTION VALUE is a dict {type, message, line, cause}: type is its
// kind as text ("ValueError"), line the source line it was raised on (0
// before it is raised), cause the exception it was escalated `because` of
// (an empty dict when there is none). An object (a class instance) can be
// escalated too: its class name is the type, its `message` field the
// message, and the object itself rides along as the `value` key.
//
// THE TYPES and what each one handles in `except T`:
//   Exception             every error
//   ValueError, TypeError, KeyError, IndexError, AttributeError,
//   MissingResourceError, RuntimeError, AssertionError
//                         that kind
//   NotImplemented        that kind; RuntimeError handles it too
//   UserWarning, LegacyWarning
//                         warnings; they become errors only when escalated
//   a class name          an escalated object of that class or a subclass
// There is no ZeroDivisionError: division by zero follows IEEE 754 (inf,
// nan) and is not an error in NC.
#include "parser.h"
#include "parser_internal.h"

#include <algorithm>
#include <cmath>
#include <cctype>
#include <functional>
#include <iostream>
#include <regex>
#include <unordered_map>
#include <unordered_set>

#include "../../../runtime/execution/Interrupt.h"
#include "../builtins/builtins.h"
#include "../conditional_opr/conditional_opr.h"
#include "../core/elementwise.h"
#include "../ops/dc/dc.h"
#include "../ops/geometric/geometric.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/matrix/nd_array.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/vector/vector.h"
#include "output.h"

namespace {

using Dict = std::unordered_map<std::string, Value>;

// The builtins' "last call failed" flags (g_lastDcOk, g_lastStatsOk ...) are
// global, and not every builtin resets every flag before it runs. Before
// try blocks a failed builtin always stopped the script, so a flag left
// false was never seen again; once an error is HANDLED the script goes on,
// and the next, unrelated builtin call would read that stale false as its
// own failure. Called whenever an error is handled.
void clearBuiltinStatusFlags() {
  g_lastBuiltinFound = true;
  g_lastVectorOk = true;
  g_lastStatsOk = true;
  g_lastGeometricOk = true;
  g_lastDcOk = true;
  g_lastElementwiseOk = true;
  g_lastConditionalOk = true;
  g_lastPlotOk = true;
}

/* ================= THE TYPES ================= */

const char *const kExceptionTypes[] = {
    "Exception",      "ValueError",           "TypeError",      "KeyError",
    "IndexError",     "AttributeError",       "MissingResourceError",
    "NotImplemented", "RuntimeError",         "AssertionError", "UserWarning",
    "LegacyWarning"};

bool isBuiltinExceptionType(const std::string &name) {
  for (const char *t : kExceptionTypes)
    if (name == t)
      return true;
  return false;
}

bool isWarningType(const std::string &name) {
  return name == "UserWarning" || name == "LegacyWarning";
}

// The type a built-in type belongs to ("" above Exception).
std::string builtinParentType(const std::string &type) {
  if (type == "Exception")
    return "";
  if (type == "NotImplemented")
    return "RuntimeError";
  return "Exception";
}

std::string typeList() {
  std::string list;
  for (const char *t : kExceptionTypes)
    list += std::string(list.empty() ? "" : ", ") + t;
  return list;
}

/* ================= EXCEPTION VALUES ================= */

Value makeException(const std::string &type, const std::string &message, size_t line = 0,
                    const Value &cause = Value(Dict())) {
  Dict d;
  d["type"] = Value(type);
  d["message"] = Value(message);
  d["line"] = Value(static_cast<double>(line));
  d["cause"] = cause;
  return Value(d);
}

// A dict with a text `type` and a text `message`.
bool isExceptionValue(const Value &v) {
  if (!v.isDict || v.isObject)
    return false;
  auto t = v.dict().find("type");
  auto m = v.dict().find("message");
  return t != v.dict().end() && t->second.isText && m != v.dict().end() && m->second.isText;
}

std::string fieldText(const Value &exc, const char *key) {
  auto it = exc.dict().find(key);
  return it != exc.dict().end() && it->second.isText ? it->second.text() : std::string();
}

size_t fieldLine(const Value &exc) {
  auto it = exc.dict().find("line");
  return it != exc.dict().end() && !it->second.isText && it->second.number > 0
             ? static_cast<size_t>(it->second.number)
             : 0;
}

void setLine(Value &exc, size_t line) { exc.dictMut()["line"] = Value(static_cast<double>(line)); }

// "ValueError: bad input", or just "ValueError" when there is no message.
std::string describe(const Value &exc) {
  const std::string type = fieldText(exc, "type");
  const std::string message = fieldText(exc, "message");
  return message.empty() ? type : type + ": " + message;
}

// The exception and every cause under it, one per line:
//   ValueError: bad input (line 12)
//     caused by: KeyError: no key 'x' (line 4)
std::string traceText(const Value &exc) {
  std::string out;
  const Value *cur = &exc;
  for (int depth = 0; cur && isExceptionValue(*cur) && depth < 32; depth++) {
    if (depth > 0)
      out += "\n  caused by: ";
    out += describe(*cur);
    if (fieldLine(*cur) > 0)
      out += " (line " + std::to_string(fieldLine(*cur)) + ")";
    auto it = cur->dict().find("cause");
    cur = it != cur->dict().end() ? &it->second : nullptr;
  }
  return out;
}

// What escalate / warn accept as an exception: an exception value, text
// (an Exception with that message) or an object (its class is the type).
bool toException(const Value &v, Value &out) {
  if (isExceptionValue(v)) {
    out = v;
    if (!out.dict().count("line"))
      setLine(out, 0);
    if (!out.dict().count("cause"))
      out.dictMut()["cause"] = Value(Dict());
    return true;
  }
  if (v.isText) {
    out = makeException("Exception", v.text());
    return true;
  }
  if (v.isObject) {
    auto m = v.dict().find("message");
    out = makeException(v.className(), m != v.dict().end() && m->second.isText ? m->second.text()
                                                                             : std::string());
    out.dictMut()["value"] = v;
    return true;
  }
  return false;
}

/* ================= READING A PRINTED ERROR ================= */

std::string lowerText(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}

// `message` with its quoted parts removed: "Undefined variable 'assert_count'"
// -> "Undefined variable ". A ' opens a quote only after a non-letter, and
// closes only before one, so the ' in "can't" or "doesn't" is kept.
std::string withoutQuotedText(const std::string &message) {
  auto isWordChar = [](char c) {
    return std::isalnum(static_cast<unsigned char>(c)) != 0 || c == '_';
  };
  std::string out;
  out.reserve(message.size());
  for (size_t i = 0; i < message.size(); ++i) {
    const char c = message[i];
    if (c == '"') {
      size_t close = message.find('"', i + 1);
      if (close != std::string::npos) {
        i = close;
        continue;
      }
    } else if (c == '\'' && (i == 0 || !isWordChar(message[i - 1]))) {
      size_t close = i + 1;
      while ((close = message.find('\'', close)) != std::string::npos &&
             close + 1 < message.size() && isWordChar(message[close + 1]))
        ++close;
      if (close != std::string::npos) {
        i = close;
        continue;
      }
    }
    out += c;
  }
  return out;
}

// The first error line of `text`, without its "Error: " / "✖ Runtime Error
// (line 3): " opening.
std::string firstErrorMessage(const std::string &text) {
  std::string line = text.substr(0, text.find('\n'));
  if (!line.empty() && line.back() == '\r')
    line.pop_back();
  size_t start = line.find_first_not_of(" \t");
  line = start == std::string::npos ? std::string() : line.substr(start);
  static const std::string kCross = "\xE2\x9C\x96";
  if (line.compare(0, kCross.size(), kCross) == 0) {
    // "✖ Runtime Error: ...", "✖ Syntax Error (line 3, col 4): ..."
    size_t colon = line.find(": ");
    line = colon == std::string::npos ? line.substr(kCross.size()) : line.substr(colon + 2);
  } else if (line.compare(0, 6, "Error:") == 0) {
    line = line.substr(6);
  }
  start = line.find_first_not_of(" \t");
  return start == std::string::npos ? std::string() : line.substr(start);
}

// The kind of error a message describes, read from its wording. Used for
// errors that were not raised with `escalate` - the messages of nc.exe's own
// statements and functions. A message that starts with a type name
// ("ValueError: ...") is of that type.
std::string exceptionKindOfMessage(const std::string &message, std::string &rest) {
  rest = message;
  size_t colon = message.find(": ");
  if (colon != std::string::npos && isBuiltinExceptionType(message.substr(0, colon))) {
    rest = message.substr(colon + 2);
    return message.substr(0, colon);
  }
  if (isBuiltinExceptionType(message)) { // "AssertionError" with no message
    rest.clear();
    return message;
  }

  // Only nc.exe's own wording counts: the quoted parts ('x', "file.csv")
  // are the user's names, keys and texts, and are left out of the tests.
  const std::string m = lowerText(withoutQuotedText(message));
  auto has = [&](const char *w) { return m.find(w) != std::string::npos; };
  if (has("assertion failed") || has("precondition failed") || has("postcondition failed"))
    return "AssertionError";
  if (has("not available yet") || has("not implemented") || has("not supported yet"))
    return "NotImplemented";
  if (has("no key") || has("key not found") || has("unknown key") || has("missing key") ||
      (has("dict key") && has("not found")))
    return "KeyError";
  if (has("file not found") || has("no such file") || has("cannot open") ||
      has("could not open") || has("folder does not exist") || has("file does not exist") ||
      has("path does not exist") || has("directory does not exist"))
    return "MissingResourceError";
  if (has("out of range") || has("out of bounds") || has("numbered from") || has("index"))
    return "IndexError";
  if (has("has no field") || has("no field") || has("has no method") || has("no method") ||
      has("not an object") || has("is private") || has("is protected") || has("attribute"))
    return "AttributeError";
  if (has("type") || has("cannot be compared") || has("cannot order-compare") ||
      has("not a number") || has("must be text") || has("expects text") ||
      has("is not a matrix") || has("is not a function") || has("not callable") ||
      has("function reference") || has("cannot combine") || has("expected a number") ||
      has("not a string"))
    return "TypeError";
  if (has("must be") || has("mismatch") || has("invalid") || has("expects") ||
      has("same size") || has("could not parse") || has("cannot parse") ||
      has("singular") || has("should be") || has("dimension") || has("shape") || has("negative") ||
      has("positive") || has("empty") || has("not a valid") || has("does not exist"))
    return "ValueError";
  return "RuntimeError";
}

/* ================= SHOWING VALUES IN A MESSAGE ================= */

// One line, at most ~60 characters: 3, "car", [1,2;3,4], 10x10 matrix ...
std::string shortText(const Value &v) {
  if (v.isText)
    return "\"" + v.text() + "\"";
  if (v.isFunctionRef)
    return "@" + v.funcRefName();
  std::string s = valueToCompactString(v);
  if (s.size() <= 60)
    return s;
  if (v.isMatrix || v.isArray)
    return matShapeText(v) + " matrix";
  if (v.isObject)
    return v.className() + " object";
  if (v.isDict)
    return "dict with " + std::to_string(v.dict().size()) + " keys";
  return s.substr(0, 57) + "...";
}

/* ================= TYPE NAMES (assert_type) ================= */

std::string intName(IntType t) {
  switch (t) {
  case IntType::Int8: return "int8";
  case IntType::Int16: return "int16";
  case IntType::Int32: return "int32";
  case IntType::Int64: return "int64";
  case IntType::UInt8: return "uint8";
  case IntType::UInt16: return "uint16";
  case IntType::UInt32: return "uint32";
  case IntType::UInt64: return "uint64";
  case IntType::None: break;
  }
  return "int64";
}

// The same words as ClassName.base and the conversion functions.
std::string typeNameOf(const Value &v) {
  if (v.isObject)
    return v.className();
  if (v.isFunctionRef)
    return "function";
  if (v.isDict)
    return "dict";
  if (v.isText)
    return "string";
  if (v.isMatrix)
    return "matrix";
  if (v.isArray)
    return "array";
  if (v.isComplex)
    return "complex";
  if (v.isTimestamp())
    return "timestamp";
  if (v.isDuration())
    return "duration";
  if (v.isBool())
    return "bool";
  if (v.isInt())
    return intName(v.intType());
  switch (v.floatType()) {
  case FloatType::Float8: return "float8";
  case FloatType::Float16: return "float16";
  case FloatType::Float32: return "float32";
  case FloatType::Float64: break;
  }
  return "float64";
}

bool isPlainNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef;
}

// The type words assert_type knows besides class names.
const char *const kTypeWords[] = {
    "float64", "float32", "float16", "float8", "int8",     "int16",    "int32",   "int64",
    "uint8",   "uint16",  "uint32",  "uint64", "bool",     "complex",  "string",  "text",
    "matrix",  "array",   "dict",    "function", "object", "number",   "integer", "float",
    "timestamp", "duration", "exception"};

bool isTypeWord(const std::string &w) {
  for (const char *t : kTypeWords)
    if (w == t)
      return true;
  return false;
}

/* ================= TEXT HELPERS ================= */

// The characters of a UTF-8 text, one per element (assert_elements_eq).
std::vector<Value> utf8Characters(const std::string &s) {
  std::vector<Value> out;
  for (size_t i = 0; i < s.size();) {
    unsigned char c = static_cast<unsigned char>(s[i]);
    size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
    out.push_back(Value(s.substr(i, len)));
    i += len;
  }
  return out;
}

} // namespace

void resetBuiltinStatusFlags() { clearBuiltinStatusFlags(); }

/* ================= NAMES ================= */

bool Parser::isExceptionFunctionName(const std::string &name, size_t argCount) {
  // Asked on EVERY function call (2026-11-21: the ~40 string comparisons
  // here were a third of a builtin call's cost): one hash lookup.
  static const std::unordered_set<std::string> kNames = [] {
    std::unordered_set<std::string> s = {
        "warn",           "publish_trace",  "inspect_fail",    "assert",
        "assert_eq",      "assert_neq",     "assert_true",     "assert_false",
        "assert_same",    "assert_not_same", "assert_null",    "assert_not_null",
        "assert_contains", "assert_excludes", "assert_type",   "assert_not_type",
        "assert_fail",    "assert_fail_match", "assert_warn",  "assert_gt",
        "assert_gte",     "assert_lt",      "assert_lte",      "assert_match",
        "assert_not_match", "assert_elements_eq"};
    for (const char *t : kExceptionTypes)
      s.insert(t);
    return s;
  }();
  // trace() is the trace of the last error; trace(A) stays the matrix trace.
  if (name == "trace")
    return argCount == 0;
  return kNames.count(name) != 0;
}

bool Parser::exceptionTypeValue(const std::string &name, Value &out) {
  if (!isBuiltinExceptionType(name))
    return false;
  out = makeException(name, "");
  return true;
}

/* ================= except types, before the run ================= */

int Parser::checkExceptTypes(const Program &program) {
  // The classes this program declares, at any depth: all of them are
  // registered before a statement runs, so any may follow `except`.
  std::unordered_set<std::string> ownClasses;
  std::vector<const Stmt *> tries;
  std::function<void(const std::vector<std::unique_ptr<Stmt>> &)> walk =
      [&](const std::vector<std::unique_ptr<Stmt>> &stmts) {
        for (const auto &sp : stmts) {
          const Stmt *s = sp.get();
          if (!s)
            continue;
          if (s->kind == StmtKind::ClassDecl && !s->classRegistrationFailed)
            ownClasses.insert(s->name);
          if (s->kind == StmtKind::Try)
            tries.push_back(s);
          walk(s->body);
          for (const auto &branch : s->elseifBranches)
            walk(branch.second);
          walk(s->elseBody);
          walk(s->methods); // each a FunctionDecl - its body is walked in turn
          for (const auto &clause : s->exceptBodies)
            walk(clause);
          walk(s->successBody);
          walk(s->alwaysBody);
        }
      };
  walk(program.statements);

  int reported = 0;
  for (const Stmt *s : tries) {
    for (size_t i = 0; i < s->exceptTypes.size(); i++) {
      for (const std::string &t : s->exceptTypes[i]) {
        if (isBuiltinExceptionType(t) || ownClasses.count(t) || hasClass(t))
          continue;
        // A class file of that name (it registers the class) - the same
        // lookup a call T(...) makes.
        loadFunctionFile(t);
        if (hasClass(t))
          continue;
        const size_t line = i < s->exceptLines.size() ? s->exceptLines[i] : 0;
        std::cerr << "\xE2\x9C\x96 Syntax Error";
        if (line)
          std::cerr << " (line " << line << ")";
        std::cerr << ": '" << t << "' is not an exception type - use "
                  << typeList() << ", or a class the script defines\n";
        syntaxErrorCount_++;
        reported++;
      }
    }
  }
  if (reported)
    evaluationSucceeded_ = false;
  return reported;
}

/* ================= try ... tend ================= */

void Parser::executeTryStmt(const Stmt *stmt) {
  // Every type named after `except` must exist - a misspelt one would
  // otherwise never handle anything, silently.
  for (size_t i = 0; i < stmt->exceptTypes.size(); i++) {
    for (const std::string &t : stmt->exceptTypes[i]) {
      if (!isBuiltinExceptionType(t) && !hasClass(t)) {
        std::cerr << "Error: TypeError: '" << t << "' (except, line " << stmt->exceptLines[i]
                  << ") is not an exception type - use " << typeList()
                  << ", or a class the script defines\n";
        pendingException_ = makeException("TypeError", "'" + t + "' is not an exception type");
        hasPendingException_ = true;
        evaluationSucceeded_ = false;
        // "✖ Runtime Error (line N)" names the except line, as the message
        // does - not the try line (noteStatementResult() keeps the first
        // line set).
        if (!errorAbort_) {
          errorAbort_ = true;
          errorLine_ = stmt->exceptLines[i];
          loopSignal_ = LoopSignal::Return;
        }
        return;
      }
    }
  }

  // Runs the always block, if there is one. Whatever is on its way out -
  // a break/continue/return, or an error nobody handled - waits while it
  // runs, then goes on; an error or return inside the always block itself
  // takes its place.
  auto runAlways = [&]() {
    if (!stmt->hasAlways)
      return;
    const LoopSignal parkedSignal = loopSignal_;
    const bool parkedAbort = errorAbort_;
    const size_t parkedLine = errorLine_;
    const Value parkedPending = pendingException_;
    const bool parkedHasPending = hasPendingException_;
    loopSignal_ = LoopSignal::None;
    clearErrorAbort();
    evaluationSucceeded_ = true;
    executeStmtList(stmt->alwaysBody);
    if (errorAbort_ || loopSignal_ != LoopSignal::None || nc::Interrupt::requested())
      return;
    loopSignal_ = parkedSignal;
    pendingException_ = parkedPending;
    hasPendingException_ = parkedHasPending;
    if (parkedAbort) {
      errorAbort_ = true;
      errorLine_ = parkedLine;
      evaluationSucceeded_ = false;
    }
  };

  // ---- the body, its error lines held back ----
  hasPendingException_ = false;
  const unsigned long countBefore = nc::errorlines::count();
  nc::errorlines::beginCapture();
  executeStmtList(stmt->body);
  const bool failed = errorAbort_ || nc::errorlines::count() != countBefore;

  if (nc::Interrupt::requested()) { // Stop is never caught
    nc::errorlines::endCapture(false);
    return;
  }

  if (!failed) {
    nc::errorlines::endCapture(false); // nothing was held back
    if (loopSignal_ == LoopSignal::None && stmt->hasSuccess)
      executeStmtList(stmt->successBody);
    runAlways();
    return;
  }

  // ---- what went wrong ----
  Value exc;
  if (hasPendingException_) {
    exc = pendingException_;
  } else {
    std::string message;
    const std::string kind =
        exceptionKindOfMessage(firstErrorMessage(nc::errorlines::capturedText()), message);
    exc = makeException(kind, message);
  }
  if (fieldLine(exc) == 0)
    setLine(exc, errorLine_ > 0 ? errorLine_ : stmt->line);
  hasPendingException_ = false;

  // ---- the first except block that fits ----
  const std::string excType = fieldText(exc, "type");
  auto fits = [&](const std::string &wanted) {
    if (wanted == "Exception")
      return true;
    for (std::string t = excType; !t.empty(); t = isBuiltinExceptionType(t) ? builtinParentType(t) : "")
      if (t == wanted)
        return true;
    return hasClass(excType) && isClassOrSubclassOf(excType, wanted);
  };
  size_t chosen = stmt->exceptTypes.size();
  for (size_t i = 0; i < stmt->exceptTypes.size() && chosen == stmt->exceptTypes.size(); i++) {
    if (stmt->exceptTypes[i].empty())
      chosen = i; // bare except: everything
    for (const std::string &t : stmt->exceptTypes[i])
      if (fits(t))
        chosen = i;
  }

  if (chosen < stmt->exceptTypes.size()) {
    // Handled: the held-back lines are dropped and the unwind stops here.
    nc::errorlines::endCapture(true);
    clearBuiltinStatusFlags();
    clearErrorAbort();
    loopSignal_ = LoopSignal::None;
    evaluationSucceeded_ = true;
    lastException_ = exc;
    hasLastException_ = true;
    if (!stmt->exceptVars[chosen].empty())
      varSet(stmt->exceptVarSlots[chosen], stmt->exceptVars[chosen], exc);
    handlingStack_.push_back(exc);
    executeStmtList(stmt->exceptBodies[chosen]);
    handlingStack_.pop_back();
    runAlways();
    return;
  }

  // ---- nobody handles it: the always block runs, then the error goes on ----
  if (stmt->hasAlways) {
    const std::string held = nc::errorlines::capturedText();
    const size_t line = errorLine_;
    nc::errorlines::endCapture(true);
    clearBuiltinStatusFlags();
    loopSignal_ = LoopSignal::None;
    clearErrorAbort();
    evaluationSucceeded_ = true;
    executeStmtList(stmt->alwaysBody);
    if (errorAbort_ || loopSignal_ != LoopSignal::None || nc::Interrupt::requested())
      return; // the always block's own error / return takes its place
    std::cerr << held; // printed (and counted) now, after the always block
    errorAbort_ = true;
    errorLine_ = line;
    loopSignal_ = LoopSignal::Return;
    evaluationSucceeded_ = false;
  } else {
    nc::errorlines::endCapture(false);
  }
  // An enclosing try block sees the same exception.
  pendingException_ = exc;
  hasPendingException_ = true;
}

/* ================= escalate ================= */

void Parser::executeEscalateStmt(const Stmt *stmt) {
  Value exc;
  if (!stmt->value) {
    if (handlingStack_.empty()) {
      std::cerr << "Error: RuntimeError: 'escalate;' with nothing after it raises again the "
                   "error an except block is handling - there is none here (write e.g. "
                   "escalate ValueError(\"...\");)\n";
      pendingException_ = makeException("RuntimeError", "no error is being handled");
      hasPendingException_ = true;
      evaluationSucceeded_ = false;
      return;
    }
    exc = handlingStack_.back();
  } else {
    Value v = evaluateExpr(stmt->value.get());
    if (!evaluationSucceeded_)
      return;
    if (!toException(v, exc)) {
      std::cerr << "Error: TypeError: escalate takes an exception (ValueError(\"...\")), a "
                   "message in quotes or an object - got "
                << shortText(v) << "\n";
      pendingException_ = makeException("TypeError", "escalate takes an exception");
      hasPendingException_ = true;
      evaluationSucceeded_ = false;
      return;
    }
  }

  if (stmt->cause) {
    Value c = evaluateExpr(stmt->cause.get());
    if (!evaluationSucceeded_)
      return;
    Value causeExc;
    if (!toException(c, causeExc)) {
      std::cerr << "Error: TypeError: the cause after 'because' must be an exception (the name "
                   "after 'as' in an except block) - got "
                << shortText(c) << "\n";
      pendingException_ = makeException("TypeError", "the cause must be an exception");
      hasPendingException_ = true;
      evaluationSucceeded_ = false;
      return;
    }
    exc.dictMut()["cause"] = causeExc;
  }

  if (fieldLine(exc) == 0)
    setLine(exc, stmt->line);

  // The error line, then one line per cause (not error lines themselves).
  const std::string text = traceText(exc);
  std::cerr << "Error: " << text << "\n";
  pendingException_ = exc;
  hasPendingException_ = true;
  evaluationSucceeded_ = false;
}

/* ================= THE FUNCTIONS ================= */

Value Parser::tryExceptionCall(const std::string &name, const std::vector<Value> &args,
                               bool &handled) {
  handled = false;
  if (!isExceptionFunctionName(name, args.size()) || hasFunction(name) || hasClass(name))
    return Value(0);
  handled = true;

  // Raises an error of `type` from inside one of these functions.
  auto raise = [&](const std::string &type, const std::string &message) {
    std::cerr << "Error: " << type << ": " << message << "\n";
    pendingException_ = makeException(type, message);
    hasPendingException_ = true;
    evaluationSucceeded_ = false;
    return Value::boolean(false);
  };
  auto usage = [&](const std::string &text) { return raise("TypeError", name + ": " + text); };

  // A trailing message in quotes after `required` values.
  std::string userMessage;
  auto takeMessage = [&](size_t required, const char *shape) -> bool {
    if (args.size() == required)
      return true;
    if (args.size() == required + 1 && args.back().isText) {
      userMessage = args.back().text();
      return true;
    }
    usage(std::string("takes ") + shape + " and an optional message in quotes, got " +
          std::to_string(args.size()) + (args.size() == 1 ? " value" : " values"));
    return false;
  };
  auto failAssert = [&](const std::string &detail) {
    return raise("AssertionError", userMessage.empty() ? detail : detail + " - " + userMessage);
  };

  /* ---- the types: ValueError("..."), ... ---- */
  if (isBuiltinExceptionType(name)) {
    if (args.size() > 1)
      return usage("takes one message, e.g. " + name + "(\"what went wrong\")");
    std::string message;
    if (args.size() == 1)
      message = args[0].isText ? args[0].text() : valueToCompactString(args[0]);
    return makeException(name, message);
  }

  /* ---- warnings ---- */
  if (name == "warn") {
    // warn("text"), warn("text", LegacyWarning), warn(LegacyWarning("text"))
    if (args.empty() || args.size() > 2)
      return usage("takes a message and an optional warning type, e.g. warn(\"old\", "
                   "LegacyWarning)");
    Value w;
    if (args[0].isText) {
      w = makeException("UserWarning", args[0].text());
    } else if (isExceptionValue(args[0])) {
      w = args[0];
    } else {
      return usage("the message must be text in quotes (or a warning such as "
                   "LegacyWarning(\"...\")), got " + shortText(args[0]));
    }
    if (args.size() == 2) {
      std::string type = args[1].isText ? args[1].text()
                         : isExceptionValue(args[1]) ? fieldText(args[1], "type")
                                                     : std::string();
      if (!isWarningType(type))
        return usage("the warning type must be UserWarning or LegacyWarning, got " +
                     shortText(args[1]));
      w.dictMut()["type"] = Value(type);
    }
    if (!isWarningType(fieldText(w, "type")))
      return usage("warns with a UserWarning or a LegacyWarning, not a " + fieldText(w, "type") +
                   " - escalate raises errors");
    if (quietWarnings_ > 0)
      warningLog_.push_back(w); // assert_warn is watching
    else
      std::cerr << "Warning: " << describe(w) << "\n";
    return Value::boolean(true);
  }

  /* ---- the last error ---- */
  // The error being handled (inside an except block), else the most recent
  // one a try block handled.
  const Value *current = !handlingStack_.empty() ? &handlingStack_.back()
                         : hasLastException_     ? &lastException_
                                                 : nullptr;
  if (name == "trace" || name == "publish_trace" || name == "inspect_fail") {
    if (!args.empty())
      return usage("takes no values - write " + name + "()");
    if (name == "inspect_fail")
      return current ? *current : Value(Dict());
    const std::string text = current ? traceText(*current) : std::string();
    if (name == "trace")
      return Value(text);
    std::cout << (current ? text : std::string("No error has been handled yet.")) << std::endl;
    resetDisplaySpacing();
    return Value::boolean(true);
  }

  /* ---- assert ---- */
  if (name == "assert") {
    // assert(cond) / assert(cond, "message"); the statement form
    // `assert cond, "message";` comes here too (parseAssertStmtNode()).
    if (args.empty() || args.size() > 2 || (args.size() == 2 && !args[1].isText))
      return usage("takes a condition and an optional message in quotes, e.g. assert(x > 0, "
                   "\"x must be positive\")");
    if (valueIsTruthy(args[0]))
      return Value::boolean(true);
    return raise("AssertionError", args.size() == 2 ? args[1].text() : "assertion failed");
  }

  /* ---- assert_eq ... assert_elements_eq ---- */
  if (name == "assert_eq" || name == "assert_neq") {
    if (!takeMessage(2, "two values"))
      return Value::boolean(false);
    const bool equal = valuesDeepEqual(args[0], args[1]);
    if (equal == (name == "assert_eq"))
      return Value::boolean(true);
    return failAssert(shortText(args[0]) + (equal ? " == " : " != ") + shortText(args[1]));
  }

  if (name == "assert_true" || name == "assert_false") {
    if (!takeMessage(1, "one value"))
      return Value::boolean(false);
    const bool wantTrue = (name == "assert_true");
    if (valueIsTruthy(args[0]) == wantTrue)
      return Value::boolean(true);
    return failAssert(shortText(args[0]) + " is not " + (wantTrue ? "true" : "false"));
  }

  if (name == "assert_same" || name == "assert_not_same") {
    // NC values have no identity of their own: the same value of the same
    // type (int32(5) and 5 are equal but not the same).
    if (!takeMessage(2, "two values"))
      return Value::boolean(false);
    const bool same =
        typeNameOf(args[0]) == typeNameOf(args[1]) && valuesDeepEqual(args[0], args[1]);
    if (same == (name == "assert_same"))
      return Value::boolean(true);
    return failAssert(shortText(args[0]) + " (" + typeNameOf(args[0]) + ") is " +
                      (same ? "" : "not ") + "the same as " + shortText(args[1]) + " (" +
                      typeNameOf(args[1]) + ")");
  }

  if (name == "assert_null" || name == "assert_not_null") {
    // NC has no None: null is the empty value - [], "" or an empty dict.
    if (!takeMessage(1, "one value"))
      return Value::boolean(false);
    const bool isNull = valueIsTruthy(is_empty(args[0]));
    if (isNull == (name == "assert_null"))
      return Value::boolean(true);
    return failAssert(shortText(args[0]) + (isNull ? " is empty" : " is not empty ([], \"\" or {})"));
  }

  if (name == "assert_contains" || name == "assert_excludes") {
    // assert_contains(container, item) - the same rules as `item in container`.
    if (!takeMessage(2, "a container and an item"))
      return Value::boolean(false);
    g_lastConditionalOk = true;
    const bool inside = valueIsTruthy(logical_is_in(args[1], args[0]));
    const bool searchable = g_lastConditionalOk;
    // The flag is global and read after later builtin calls too: leave it
    // set, the failure is reported here through evaluationSucceeded_.
    g_lastConditionalOk = true;
    if (!searchable) {
      evaluationSucceeded_ = false; // logical_is_in() printed why
      return Value::boolean(false);
    }
    if (inside == (name == "assert_contains"))
      return Value::boolean(true);
    return failAssert(shortText(args[1]) + (inside ? " is in " : " is not in ") +
                      shortText(args[0]));
  }

  if (name == "assert_type" || name == "assert_not_type") {
    // assert_type(x, "matrix") / assert_type(obj, "ClassName") /
    // assert_type(err, ValueError)
    if (!takeMessage(2, "a value and a type"))
      return Value::boolean(false);
    const Value &x = args[0];
    bool is = false;
    std::string wanted;
    if (isExceptionValue(args[1]) && fieldText(args[1], "message").empty()) {
      wanted = fieldText(args[1], "type");
      if (isExceptionValue(x)) {
        const std::string xt = fieldText(x, "type");
        is = wanted == "Exception";
        for (std::string t = xt; !t.empty() && !is;
             t = isBuiltinExceptionType(t) ? builtinParentType(t) : "")
          is = (t == wanted);
        is = is || (hasClass(xt) && isClassOrSubclassOf(xt, wanted));
      }
    } else if (args[1].isText) {
      wanted = args[1].text();
      if (!isTypeWord(wanted) && !hasClass(wanted))
        return usage("unknown type \"" + wanted + "\" - use float64, int32, bool, complex, "
                     "string, matrix, array, dict, function, object, number, integer, float, "
                     "exception or a class name");
      const std::string actual = typeNameOf(x);
      if (wanted == "text")
        is = x.isText;
      else if (wanted == "number")
        is = isPlainNumber(x) && !x.isTimestamp() && !x.isDuration();
      else if (wanted == "integer")
        is = isPlainNumber(x) && x.isInt();
      else if (wanted == "float")
        is = isPlainNumber(x) && !x.isInt() && !x.isBool() && !x.isComplex &&
             !x.isTimestamp() && !x.isDuration();
      else if (wanted == "object")
        is = x.isObject;
      else if (wanted == "exception")
        is = isExceptionValue(x);
      else if (x.isObject && hasClass(wanted))
        is = isClassOrSubclassOf(x.className(), wanted);
      else if ((x.isArray || x.isMatrix) && x.isTypedPacked() && wanted == elemTypeName(x.elemType()))
        is = true; // a typed array / matrix (R9): every element is a `wanted`
      else
        is = (actual == wanted);
    } else {
      return usage("the type is a name in quotes (\"matrix\", \"ClassName\") or an exception "
                   "type (ValueError), got " + shortText(args[1]));
    }
    if (is == (name == "assert_type"))
      return Value::boolean(true);
    return failAssert(shortText(x) + " (" + typeNameOf(x) + ") is " + (is ? "" : "not ") + "a " +
                      wanted);
  }

  if (name == "assert_gt" || name == "assert_gte" || name == "assert_lt" ||
      name == "assert_lte") {
    if (!takeMessage(2, "two values"))
      return Value::boolean(false);
    const std::string op = name == "assert_gt" ? ">" : name == "assert_gte" ? ">=" : name == "assert_lt" ? "<" : "<=";
    Value r = evaluateComparisonValues(op, args[0], args[1]);
    if (!evaluationSucceeded_)
      return Value::boolean(false); // not comparable - already reported
    if (valueIsTruthy(r))
      return Value::boolean(true);
    return failAssert("not " + shortText(args[0]) + " " + op + " " + shortText(args[1]));
  }

  if (name == "assert_match" || name == "assert_not_match") {
    // assert_match(text, pattern): the pattern (a regular expression) is
    // found somewhere in the text.
    if (!takeMessage(2, "a text and a pattern"))
      return Value::boolean(false);
    if (!args[0].isText || !args[1].isText)
      return usage("takes a text and a pattern, both in quotes");
    bool found = false;
    try {
      found = std::regex_search(args[0].text(), std::regex(args[1].text()));
    } catch (const std::regex_error &) {
      return raise("ValueError", name + ": \"" + args[1].text() + "\" is not a valid pattern");
    }
    if (found == (name == "assert_match"))
      return Value::boolean(true);
    return failAssert("pattern \"" + args[1].text() + "\" " + (found ? "found" : "not found") +
                      " in " + shortText(args[0]));
  }

  if (name == "assert_elements_eq") {
    // The same elements, in any order, each as many times.
    if (!takeMessage(2, "two values"))
      return Value::boolean(false);
    // Two packed float64 values (2026-11-20): sorted copies compared in
    // order - O(n log n); the pair-by-pair matching below is O(n^2) (about
    // 100 s for 400,000 elements). Same verdict: valuesDeepEqual() compares
    // numbers with ==, so a NaN matches nothing and -0 matches 0.
    if (args[0].isPacked() && args[1].isPacked()) {
      std::vector<double> x(args[0].packedData(), args[0].packedData() + args[0].packedSize());
      std::vector<double> y(args[1].packedData(), args[1].packedData() + args[1].packedSize());
      bool same = x.size() == y.size();
      for (std::vector<double> *side : {&x, &y})
        for (double &d : *side) {
          if (std::isnan(d))
            same = false;
          d += 0.0; // -0 -> 0
        }
      if (same) {
        std::sort(x.begin(), x.end());
        std::sort(y.begin(), y.end());
        same = x == y;
      }
      if (same)
        return Value::boolean(true);
      return failAssert("the elements of " + shortText(args[0]) + " and " + shortText(args[1]) +
                        " differ");
    }
    auto elementsOf = [](const Value &v, std::vector<Value> &out) {
      if (v.isMatrix)
        out = nd::rowMajorCells(v);
      else if (v.isArray)
        out = v.elems();
      else if (v.isText)
        out = utf8Characters(v.text());
      else if (v.isDict && !v.isObject)
        for (const auto &kv : v.dict())
          out.push_back(Value(kv.first));
      else
        return false;
      return true;
    };
    std::vector<Value> a, b;
    if (!elementsOf(args[0], a) || !elementsOf(args[1], b))
      return usage("compares the elements of two matrices, texts or dicts");
    bool same = a.size() == b.size();
    std::vector<bool> used(b.size(), false);
    for (size_t i = 0; same && i < a.size(); i++) {
      bool matched = false;
      for (size_t j = 0; j < b.size() && !matched; j++)
        if (!used[j] && valuesDeepEqual(a[i], b[j]))
          matched = used[j] = true;
      same = matched;
    }
    if (same)
      return Value::boolean(true);
    return failAssert("the elements of " + shortText(args[0]) + " and " + shortText(args[1]) +
                      " differ");
  }

  /* ---- assert_fail / assert_fail_match / assert_warn: they call a function ---- */
  // assert_fail([type,] @f, values...)
  // assert_fail_match([type,] "pattern", @f, values...)
  // assert_warn([type,] @f, values...)
  size_t fnAt = 0;
  while (fnAt < args.size() && !args[fnAt].isFunctionRef)
    fnAt++;
  const size_t before = (name == "assert_fail_match") ? 1 : 0; // the pattern
  if (fnAt == args.size() || fnAt < before || fnAt > before + 1)
    return usage(name == "assert_fail_match"
                     ? "takes an optional type, a pattern in quotes, a function (@f) and its "
                       "values, e.g. assert_fail_match(ValueError, \"negative\", @f, -1)"
                     : "takes an optional type, a function (@f) and its values, e.g. " + name +
                           "(" + (name == "assert_warn" ? "LegacyWarning" : "ValueError") +
                           ", @f, 2)");
  std::string wantType;
  if (fnAt > before) {
    const Value &t = args[0];
    wantType = t.isText ? t.text() : isExceptionValue(t) ? fieldText(t, "type") : std::string();
    if (!isBuiltinExceptionType(wantType) && !hasClass(wantType))
      return usage("the first value must be an exception type such as ValueError, got " +
                   shortText(t));
  }
  std::string pattern;
  if (name == "assert_fail_match") {
    if (!args[fnAt - 1].isText)
      return usage("the pattern before the function must be text in quotes");
    pattern = args[fnAt - 1].text();
  }
  const Value fn = args[fnAt];
  const std::vector<Value> callArgs(args.begin() + static_cast<std::ptrdiff_t>(fnAt) + 1, args.end());
  const std::string callText = "@" + fn.funcRefName() + "(" +
                               std::to_string(callArgs.size()) +
                               (callArgs.size() == 1 ? " value)" : " values)");
  auto typeFits = [&](const std::string &got) {
    if (wantType.empty() || wantType == "Exception")
      return true;
    for (std::string t = got; !t.empty(); t = isBuiltinExceptionType(t) ? builtinParentType(t) : "")
      if (t == wantType)
        return true;
    return hasClass(got) && isClassOrSubclassOf(got, wantType);
  };

  if (name == "assert_warn") {
    const size_t logBefore = warningLog_.size();
    quietWarnings_++;
    callFunctionValue(fn, callArgs);
    quietWarnings_--;
    std::vector<Value> seen(warningLog_.begin() + static_cast<std::ptrdiff_t>(logBefore), warningLog_.end());
    if (quietWarnings_ == 0)
      warningLog_.clear();
    if (!evaluationSucceeded_ || errorAbort_)
      return Value::boolean(false); // the function failed - its error goes on
    if (seen.empty())
      return raise("AssertionError", callText + " gave no warning");
    for (const Value &w : seen)
      if (typeFits(fieldText(w, "type")))
        return Value::boolean(true);
    return raise("AssertionError", callText + " warned " + describe(seen.front()) + ", not a " +
                                       wantType);
  }

  // assert_fail / assert_fail_match: the call must fail. Its error is held
  // back and handled here, exactly like a try block would.
  hasPendingException_ = false;
  const unsigned long countBefore = nc::errorlines::count();
  nc::errorlines::beginCapture();
  callFunctionValue(fn, callArgs);
  const bool failed =
      !evaluationSucceeded_ || errorAbort_ || nc::errorlines::count() != countBefore;
  if (nc::Interrupt::requested()) {
    nc::errorlines::endCapture(false);
    return Value::boolean(false);
  }
  if (!failed) {
    nc::errorlines::endCapture(false);
    return raise("AssertionError", callText + " raised no error");
  }
  Value exc;
  if (hasPendingException_) {
    exc = pendingException_;
  } else {
    std::string message;
    const std::string kind =
        exceptionKindOfMessage(firstErrorMessage(nc::errorlines::capturedText()), message);
    exc = makeException(kind, message);
  }
  nc::errorlines::endCapture(true);
  clearBuiltinStatusFlags();
  clearErrorAbort();
  evaluationSucceeded_ = true;
  hasPendingException_ = false;
  lastException_ = exc; // inspect_fail() / trace() can look at it afterwards
  hasLastException_ = true;

  if (!typeFits(fieldText(exc, "type")))
    return raise("AssertionError", callText + " raised " + describe(exc) + ", not a " + wantType);
  if (name == "assert_fail_match") {
    bool found = false;
    try {
      found = std::regex_search(fieldText(exc, "message"), std::regex(pattern));
    } catch (const std::regex_error &) {
      return raise("ValueError", name + ": \"" + pattern + "\" is not a valid pattern");
    }
    if (!found)
      return raise("AssertionError", "pattern \"" + pattern + "\" not found in the error " +
                                         describe(exc));
  }
  return Value::boolean(true);
}
