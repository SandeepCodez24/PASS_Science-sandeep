// Function files, class files and modules.
//
// docs/Process_Window_CPP.md P1 (2026-11-17) and
// docs/Export_Process_Modules_CPP.md M1-M4 (2026-11-18).
//
// FUNCTION FILE  FUNC123.nc holding only functions, the first one named
//                FUNC123: any script calls FUNC123(x).
// CLASS FILE     Robot.nc holding only `class Robot(...)`: Robot(1500).
// MODULE         any .nc file with functions or classes at its top level:
//                school.func1(x), school.Pupil("Ana"), school.func1 (a
//                function handle). Only the definitions are loaded - the
//                file's top-level statements never run on a module call
//                (user decision 2026-11-18; they run with `school;`).
//
// Name order for a call N(...) (user decision 2026-11-18):
//   1. a function or class of the running script;
//   2. a function file or class file whose name is EXACTLY N (case
//      included) - also when a built-in has that name: mean.nc is what
//      mean(...) calls in its folder;
//   3. the built-ins, matched exactly too: Sum(...) never reaches sum
//      (builtinCaseMismatch()).
// Where files are found (runtime/interpreter/core/function_files.h): the
// running script's folder, the current folder, the addpath folders.
//
// Loading = parsing the file and registering its functions / classes into
// this Parser's tables, so every existing call path (positional, named
// values, several outputs, @name, feval, the JIT's dynamic dispatch) works
// on them unchanged:
//   - a function file's helpers (the functions after the first) are
//     registered as "<file>/<helper>", and every use of a helper's name
//     inside the file is renamed to that, so they stay private;
//   - a module's functions and classes are registered as "<file>.<name>",
//     and the file's calls to them are renamed likewise, so func2 still
//     calls func1 by its plain name;
//   - a file is parsed once and again when it changes or another folder's
//     file comes first (checked once per command - refreshFunctionFiles());
//   - a function or class of the running script always wins: defining one
//     of the same name drops the file's version (forgetFunctionFile()).
#include "parser.h"
#include "parser_internal.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <sstream>
#include <system_error>

#include "../../../runtime/data/DataEngine.h"
#include "../../../runtime/interpreter/core/function_files.h"
#include "../../../runtime/interpreter/core/line_continuation.h"
#include "../builtins/builtins.h"
#include "../ops/collections/nullset_builtin.h"
#include "lexer.h"

namespace fs = std::filesystem;

namespace {

// Names the parser answers itself (parser_factor.cpp,
// tryReservedFunctionValueCall()): never looked up as files, so a stray
// feval.nc cannot change what feval() means.
bool parserOwnsName(const std::string &name) {
  return name == "feval" || name == "deal" || name == "save" || name == "grad" ||
         name == "taylor_series" || name == "green_integral" ||
         Parser::isExceptionFunctionName(name, 1) || ncdata::DataEngine::isWorkspaceCommand(name) ||
         ncnullset::findByFunction(name) != nullptr;
}

std::string readWholeFile(const fs::path &path, bool &ok) {
  std::ifstream in(path, std::ios::binary);
  ok = in.is_open();
  if (!ok)
    return std::string();
  // As ScriptManager::executeFile() reads a script: '~~' continuation lines
  // are merged, and each merged line leaves an empty one behind so every
  // token keeps its real line number.
  std::string whole, raw;
  while (std::getline(in, raw)) {
    if (!raw.empty() && raw.back() == '\r')
      raw.pop_back();
    size_t joined = 0;
    whole += readLogicalLine(in, raw, &joined);
    whole.append(1 + joined, '\n');
  }
  // A UTF-8 byte-order mark (Notepad) is not part of the code.
  if (whole.size() >= 3 && static_cast<unsigned char>(whole[0]) == 0xEF &&
      static_cast<unsigned char>(whole[1]) == 0xBB && static_cast<unsigned char>(whole[2]) == 0xBF)
    whole.erase(0, 3);
  return whole;
}

// Holds back what is written to std::cerr while it lives (lexing and
// parsing a file print their own errors). release() writes it out after
// all; otherwise it is dropped - a file passed over for a built-in's name
// must not print anything (an error line fails the statement).
class CerrHold {
public:
  CerrHold() : old_(std::cerr.rdbuf(held_.rdbuf())) {}
  ~CerrHold() { restore(); }
  std::string text() const { return held_.str(); }
  void release() {
    restore();
    const std::string t = held_.str();
    held_.str(std::string());
    if (!t.empty())
      std::cerr << t;
  }

private:
  void restore() {
    if (old_) {
      std::cerr.rdbuf(old_);
      old_ = nullptr;
    }
  }
  std::ostringstream held_;
  std::streambuf *old_;
};

// The first "line N" in a syntax error message, or 0.
size_t firstErrorLine(const std::string &messages) {
  const size_t at = messages.find("line ");
  if (at == std::string::npos)
    return 0;
  size_t n = 0, i = at + 5;
  while (i < messages.size() && std::isdigit(static_cast<unsigned char>(messages[i])))
    n = n * 10 + static_cast<size_t>(messages[i++] - '0');
  return n;
}

struct ParsedFile {
  std::vector<Token> tokens;
  Program program;
  bool ok = false;
  std::string messages; // the lexer's / parser's own error lines
  size_t errorLine = 0;
};

// Lexes and parses `source` with a separate Parser (the caller may be in the
// middle of evaluating an expression), holding back its error lines.
ParsedFile parseFile(const std::string &source) {
  ParsedFile out;
  CerrHold hold;
  Lexer lexer(source);
  out.tokens = lexer.tokenize();
  if (lexer.errorCount() == 0) {
    Parser probe;
    out.program = probe.parseProgram(out.tokens);
    out.ok = probe.syntaxErrorCount_ == 0;
  }
  out.messages = hold.text();
  out.errorLine = firstErrorLine(out.messages);
  return out;
}

std::string shownName(const fs::path &path) { return path.filename().u8string(); }

std::string lowerText(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}

bool isClassEndToken(const Token &t) { return lowerText(t.text) == "csend"; }

// Module renaming: the tokens that name one of the module's own functions or
// classes in a CALL position become "<module>.<name>":
//   f(...)              a call (also the declaration `function y = f(...)`
//                       and `class C(...)`)
//   @f                  a function handle
//   class K(C)          the parent of a class
// but never x.f / x.f(...) (a field or a method), and never the name of a
// method declared inside a class (`function y = f(...)` within class ...
// csend), which stays the method's own name.
void renameModuleMembers(std::vector<Token> &tokens, const std::string &module,
                         const std::vector<std::string> &members) {
  std::unordered_set<std::string> own(members.begin(), members.end());
  bool inClass = false;
  size_t lastFunction = std::string::npos;
  for (size_t i = 0; i < tokens.size(); i++) {
    Token &t = tokens[i];
    if (t.type == CLASS) {
      inClass = true;
    } else if (inClass && isClassEndToken(t)) {
      inClass = false;
    } else if (t.type == FUNCTION) {
      lastFunction = i;
    }
    if (t.type != IDENT || !own.count(t.text))
      continue;
    const Token *prev = i > 0 ? &tokens[i - 1] : nullptr;
    const Token *next = i + 1 < tokens.size() ? &tokens[i + 1] : nullptr;
    if (prev && prev->type == DOT)
      continue;
    bool rename = false;
    if (prev && prev->type == AT) {
      rename = true;
    } else if (next && next->type == LPAREN) {
      bool methodHeader = false;
      if (inClass && lastFunction != std::string::npos && tokens[lastFunction].line == t.line) {
        methodHeader = true;
        for (size_t k = lastFunction + 1; k < i; k++)
          methodHeader = methodHeader && tokens[k].type != LPAREN;
      }
      rename = !methodHeader;
    } else if (i >= 3 && tokens[i - 1].type == LPAREN && tokens[i - 2].type == IDENT &&
               tokens[i - 3].type == CLASS) {
      rename = true; // class K(C): the parent
    }
    if (rename)
      t.text = module + "." + t.text;
  }
}

// What kind of file a parsed program is (as ScriptShape.java on the Java side).
enum class FileKind { FunctionFile, ClassFile, Other };

FileKind kindOf(const Program &program, const std::string &name) {
  if (program.statements.empty())
    return FileKind::Other;
  bool allFunctions = true;
  for (const auto &s : program.statements)
    allFunctions = allFunctions && s->kind == StmtKind::FunctionDecl;
  if (allFunctions && program.statements[0]->name == name)
    return FileKind::FunctionFile;
  if (program.statements.size() == 1 && program.statements[0]->kind == StmtKind::ClassDecl &&
      program.statements[0]->name == name)
    return FileKind::ClassFile;
  return FileKind::Other;
}

} // namespace

/* ================= refresh / forget ================= */

void Parser::syncMissCaches() {
  const unsigned long long now = nc::fnfiles::foldersGeneration();
  if (now == missGeneration_)
    return;
  // Other folders now: names not found before may be found. (Loaded files
  // stay until the next command - one may be running right now.)
  missGeneration_ = now;
  functionFileMisses_.clear();
  moduleMisses_.clear();
}

void Parser::refreshFunctionFiles() {
  // Names that were not found are looked up again from the next command on
  // (a file may have been saved meanwhile).
  functionFileMisses_.clear();
  moduleMisses_.clear();
  // A loaded file is dropped when it changed, went away, or is no longer
  // the one the search finds first (the current folder changed).
  auto stillCurrent = [](const std::string &name, const fs::path &path,
                         const fs::file_time_type &modified) {
    std::error_code ec;
    const fs::file_time_type now = fs::last_write_time(path, ec);
    if (ec || now != modified)
      return false;
    const std::optional<fs::path> first = nc::fnfiles::find(name);
    return first && fs::equivalent(*first, path, ec) && !ec;
  };
  std::vector<std::string> stale;
  for (const auto &kv : functionFiles_)
    if (!stillCurrent(kv.first, kv.second.path, kv.second.modified))
      stale.push_back(kv.first);
  for (const std::string &name : stale)
    forgetFunctionFile(name);
  stale.clear();
  for (const auto &kv : modules_)
    if (!stillCurrent(kv.first, kv.second.path, kv.second.modified))
      stale.push_back(kv.first);
  for (const std::string &name : stale)
    forgetModule(name);
}

void Parser::forgetFunctionFile(const std::string &name) {
  auto it = functionFiles_.find(name);
  if (it == functionFiles_.end())
    return;
  for (const std::string &registered : it->second.registered)
    functionTable_.erase(registered);
  for (const std::string &registered : it->second.registeredClasses)
    classTable_.erase(registered);
  functionFiles_.erase(it);
}

void Parser::forgetModule(const std::string &name) {
  auto it = modules_.find(name);
  if (it == modules_.end())
    return;
  for (const std::string &registered : it->second.registered)
    functionTable_.erase(registered);
  for (const std::string &registered : it->second.registeredClasses)
    classTable_.erase(registered);
  modules_.erase(it);
}

/* ================= function files and class files ================= */

bool Parser::loadFunctionFile(const std::string &name) {
  if (functionTable_.count(name))
    return true;
  if (classTable_.count(name))
    return false;
  // Reached for every call of a built-in (sin(x) in a loop): the parser's
  // own names are one hash lookup from then on, other names one per command.
  if (notFunctionFileNames_.count(name))
    return false;
  // Looked for already during this command (same folders) - asked before
  // parserOwnsName(), whose name never gets here (2026-11-21: that check ran
  // on every call of a builtin).
  syncMissCaches();
  if (functionFileMisses_.count(name))
    return false;
  if (name.empty() || parserOwnsName(name)) {
    notFunctionFileNames_.insert(name);
    return false;
  }

  // "school.f": a module's function whose module was dropped since (the
  // file changed) - load the module again.
  const size_t dot = name.find('.');
  if (dot != std::string::npos) {
    functionFileMisses_.insert(name);
    bool refused = false;
    if (dot > 0 && loadModule(name.substr(0, dot), refused))
      return functionTable_.count(name) != 0;
    return false;
  }

  const std::optional<fs::path> found = nc::fnfiles::find(name);
  if (!found) {
    functionFileMisses_.insert(name);
    return false;
  }
  // A built-in's name: the file wins only when it is a function file or a
  // class file. Anything else (a script called plot.nc, a file with errors)
  // is passed over without a word and the built-in runs.
  const bool builtinName = builtinExists(name);
  const fs::path &path = *found;
  const std::string shown = fs::path(path).make_preferred().u8string();
  std::error_code ec;
  const fs::file_time_type modified = fs::last_write_time(path, ec);
  if (builtinName && !ec) {
    // passed over before and unchanged since: no need to parse it again
    auto seen = passedOverFiles_.find(name);
    if (seen != passedOverFiles_.end() && seen->second.first == path && seen->second.second == modified) {
      functionFileMisses_.insert(name);
      return false;
    }
  }
  auto refuseWith = [&](const std::string &message, const std::string &held) {
    functionFileMisses_.insert(name);
    if (builtinName && !ec)
      passedOverFiles_[name] = {path, modified};
    if (!builtinName) {
      std::cerr << "Error: " << message << "\n";
      if (!held.empty())
        std::cerr << held;
    }
    return false;
  };
  auto refuse = [&](const std::string &why, const std::string &held = std::string()) {
    return refuseWith("function file " + shown + ": " + why, held);
  };

  bool readOk = false;
  const std::string source = readWholeFile(path, readOk);
  if (!readOk || ec)
    return refuse("it cannot be read");

  ParsedFile parsed = parseFile(source);
  if (!parsed.ok)
    return refuse("it has syntax errors (below) - '" + name + "' was not loaded", parsed.messages);

  const FileKind kind = kindOf(parsed.program, name);

  // M2: a class file. Its parents load the same way when it is used
  // (loadClassChain()).
  if (kind == FileKind::ClassFile) {
    registerClassDeclStmt(*parsed.program.statements[0], /*fromFunctionFile=*/true);
    if (!classTable_.count(name))
      return refuse("class '" + name + "' could not be loaded");
    LoadedFunctionFile entry;
    entry.path = path;
    entry.modified = modified;
    entry.registeredClasses.push_back(name);
    functionFiles_[name] = std::move(entry);
    return false; // a class now, not a function
  }

  if (kind != FileKind::FunctionFile) {
    const auto &statements = parsed.program.statements;
    if (statements.empty())
      return refuse("it defines no function - its first function must be '" + name + "'");
    if (statements[0]->kind == StmtKind::ClassDecl && statements[0]->name == name) {
      // class Robot(...) ... csend, then more.
      return refuseWith(shownName(path) + " is not a class file: line " +
                            std::to_string(statements[1]->line) +
                            " has code outside the class - '" + name + "' was not loaded",
                        std::string());
    }
    for (const auto &stmt : statements)
      if (stmt->kind != StmtKind::FunctionDecl)
        return refuse("line " + std::to_string(stmt->line) +
                      ": a function file holds functions and comments only - '" + name +
                      "' was not loaded");
    return refuse("its first function is '" + statements[0]->name +
                  "' - a function file's first function has the file's name ('" + name + "')");
  }

  // The helpers: every token naming one becomes "<file>/<helper>".
  std::vector<std::string> declared;
  for (const auto &stmt : parsed.program.statements)
    declared.push_back(stmt->name);
  std::unordered_map<std::string, std::string> renamed;
  for (size_t i = 1; i < declared.size(); i++)
    if (declared[i] != name)
      renamed[declared[i]] = name + "/" + declared[i];
  Program program;
  if (renamed.empty()) {
    program = std::move(parsed.program);
  } else {
    for (Token &t : parsed.tokens)
      if (t.type == IDENT) {
        auto r = renamed.find(t.text);
        if (r != renamed.end())
          t.text = r->second;
      }
    std::string held;
    int errors = 0;
    {
      CerrHold hold;
      Parser builder;
      program = builder.parseProgram(parsed.tokens);
      errors = builder.syntaxErrorCount_;
      held = hold.text();
    }
    if (errors > 0)
      return refuse("it has syntax errors (below) - '" + name + "' was not loaded", held);
  }

  LoadedFunctionFile entry;
  entry.path = path;
  entry.modified = modified;
  for (const auto &stmt : program.statements) {
    if (stmt->kind != StmtKind::FunctionDecl)
      continue;
    // A helper with the name of a function of the running script stays the
    // file's own (it is registered under its "<file>/" name), so nothing
    // the script defined is replaced here.
    registerFunctionDeclStmt(*stmt, /*fromFunctionFile=*/true);
    if (std::find(entry.registered.begin(), entry.registered.end(), stmt->name) ==
        entry.registered.end())
      entry.registered.push_back(stmt->name);
  }
  functionFiles_[name] = std::move(entry);
  return functionTable_.count(name) != 0;
}

void Parser::loadClassChain(const std::string &className) {
  std::string current = className;
  for (int depth = 0; depth < 64; depth++) {
    auto it = classTable_.find(current);
    if (it == classTable_.end())
      return;
    const std::string parent = it->second.parentClassName; // copy: the table may grow
    if (parent.empty())
      return;
    if (!classTable_.count(parent) && !functionTable_.count(parent))
      loadFunctionFile(parent);
    current = parent;
  }
}

/* ================= M3: built-ins by their exact name ================= */

bool Parser::builtinCaseMismatch(const std::string &name) {
  if (name.empty() || name.find('.') != std::string::npos || name.find('/') != std::string::npos)
    return false;
  // Every built-in by the spelling it is registered under.
  static const std::unordered_set<std::string> exact = [] {
    std::unordered_set<std::string> s;
    for (std::string &n : allBuiltinNames())
      s.insert(std::move(n));
    return s;
  }();
  if (exact.count(name))
    return false;
  // logb2, logb10 ...: a family, not a table entry (lower case only).
  if (name.size() > 4 && name.compare(0, 4, "logb") == 0 &&
      std::all_of(name.begin() + 4, name.end(), [](unsigned char c) { return std::isdigit(c) != 0; }))
    return false;
  if (!builtinExists(name))
    return false; // no built-in at all: the built-in call reports it as before
  // Only the letter case differs: name the built-in the user may have meant.
  const std::string lower = lowerText(name);
  std::string meant;
  for (const std::string &n : exact)
    if (lowerText(n) == lower && (meant.empty() || n < meant))
      meant = n;
  std::cerr << "Error: Unknown function '" << name << "'";
  if (!meant.empty())
    std::cerr << " (did you mean the built-in " << meant << "?)";
  std::cerr << "\n";
  evaluationSucceeded_ = false;
  return true;
}

/* ================= M1: modules ================= */

const Parser::LoadedModule *Parser::loadModule(const std::string &name, bool &refused) {
  refused = false;
  auto loaded = modules_.find(name);
  if (loaded != modules_.end())
    return &loaded->second;
  syncMissCaches();
  auto missed = moduleMisses_.find(name);
  if (missed != moduleMisses_.end()) {
    refused = missed->second;
    return nullptr;
  }
  if (name.empty() || name.find('.') != std::string::npos) {
    moduleMisses_[name] = false;
    return nullptr;
  }
  const std::optional<fs::path> found = nc::fnfiles::find(name);
  if (!found) {
    moduleMisses_[name] = false;
    return nullptr;
  }
  const fs::path &path = *found;
  const std::string file = shownName(path);
  auto refuse = [&](const std::string &message, const std::string &held = std::string()) {
    // the reason first (it is what a try block's e.message reads), then
    // the parser's own lines
    std::cerr << "Error: " << message << "\n";
    if (!held.empty())
      std::cerr << held;
    moduleMisses_[name] = true;
    refused = true;
    evaluationSucceeded_ = false;
    return static_cast<const LoadedModule *>(nullptr);
  };

  std::error_code ec;
  const fs::file_time_type modified = fs::last_write_time(path, ec);
  bool readOk = false;
  const std::string source = readWholeFile(path, readOk);
  if (!readOk || ec)
    return refuse(file + " cannot be read - nothing was loaded");

  ParsedFile parsed = parseFile(source);
  if (!parsed.ok)
    return refuse(file + " has syntax errors" +
                      (parsed.errorLine ? " (line " + std::to_string(parsed.errorLine) + ")"
                                        : std::string(" (above)")) +
                      " - nothing was loaded",
                  parsed.messages);

  switch (kindOf(parsed.program, name)) {
  case FileKind::FunctionFile:
    return refuse(file + " is a function file - call it as " + name + "(...)");
  case FileKind::ClassFile:
    // Robot.info / Robot.method(...) on a class file: no module - load the
    // class, and the caller goes on with it as with any class.
    moduleMisses_[name] = false;
    loadFunctionFile(name);
    return nullptr;
  case FileKind::Other:
    break;
  }

  // The top-level definitions, in file order. Statements are left alone:
  // they never run on a module call.
  std::vector<std::string> members;
  for (const auto &stmt : parsed.program.statements) {
    if (stmt->kind != StmtKind::FunctionDecl && stmt->kind != StmtKind::ClassDecl)
      continue;
    if (std::find(members.begin(), members.end(), stmt->name) == members.end())
      members.push_back(stmt->name);
  }
  if (members.empty())
    return refuse(file + " has no function or class - run it with " + name + ";");

  renameModuleMembers(parsed.tokens, name, members);
  Program program;
  {
    std::string held;
    int errors = 0;
    {
      CerrHold hold;
      Parser builder;
      program = builder.parseProgram(parsed.tokens);
      errors = builder.syntaxErrorCount_;
      held = hold.text();
    }
    if (errors > 0)
      return refuse(file + " has syntax errors (line " + std::to_string(firstErrorLine(held)) +
                        ") - nothing was loaded",
                    held);
  }

  LoadedModule entry;
  entry.path = path;
  entry.modified = modified;
  entry.members = members;
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl) {
      registerFunctionDeclStmt(*stmt, /*fromFunctionFile=*/true);
      if (std::find(entry.registered.begin(), entry.registered.end(), stmt->name) ==
          entry.registered.end())
        entry.registered.push_back(stmt->name);
    } else if (stmt->kind == StmtKind::ClassDecl) {
      registerClassDeclStmt(*stmt, /*fromFunctionFile=*/true);
      if (classTable_.count(stmt->name))
        entry.registeredClasses.push_back(stmt->name);
    }
  }
  return &(modules_[name] = std::move(entry));
}

Value Parser::callModuleMember(const std::string &receiver, const std::string &member,
                               const std::vector<Value> &args,
                               const std::vector<std::string> &argNames, bool asCall,
                               bool &handled) {
  bool refused = false;
  const LoadedModule *module = loadModule(receiver, refused);
  handled = module != nullptr || refused;
  if (!module) {
    if (refused)
      evaluationSucceeded_ = false;
    return Value(0);
  }
  const std::string qualified = receiver + "." + member;

  if (classTable_.count(qualified)) {
    if (!asCall) {
      std::cerr << "Error: " << qualified << " is a class - make one with " << qualified
                << "(...)\n";
      evaluationSucceeded_ = false;
      return Value(0);
    }
    bool found = false;
    Value result = callClassConstructor(qualified, args, found, argNames);
    if (!found)
      evaluationSucceeded_ = false;
    return result;
  }

  if (functionTable_.count(qualified)) {
    if (!asCall) { // school.f: a handle, as @f
      Value ref;
      ref.isFunctionRef = true;
      ref.funcRefNameMut() = qualified;
      return ref;
    }
    bool found = false;
    Value result = callUserFunction(qualified, args, found, argNames);
    if (!found)
      evaluationSucceeded_ = false;
    return result;
  }

  std::string list;
  for (const std::string &m : module->members)
    list += (list.empty() ? "" : ", ") + m;
  std::cerr << "Error: " << shownName(module->path) << " has no function or class '" << member
            << "' - it has " << list << "\n";
  evaluationSucceeded_ = false;
  return Value(0);
}
