#pragma once

#include <functional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "ast.h"
#include "error_lines.h"
#include "token.h"
#include "value.h"

struct MatIndexKey; // ops/matrix/matrix_index.h

class Parser {
public:
  Parser();

  void setTokens(const std::vector<Token> &t);

  // Block-terminator recognition, shared by ScriptManager/SM_stage_02.cpp
  // and main.cpp's REPL loop (which use them to know when a multi-line
  // if/for/while/function/class construct's text is complete) and by
  // parser_program.cpp's own header/body-boundary parsing, so the accepted
  // keyword sets can't drift out of sync between call sites. `lower` must
  // already be trimmed and lower-cased.
  static bool isIfTerm(const std::string &lower);
  static bool isForTerm(const std::string &lower);
  static bool isWhileTerm(const std::string &lower);
  static bool isFunctionTerm(const std::string &lower);
  static bool isClassTerm(const std::string &lower);

  // True (and clears the signal) if a top-level `return;` — or, now, a
  // failed `require`/`ensure` — asked execution to stop here. Inside a
  // function/method/loop body this is already fully handled by
  // executeStmtList()/invokeFunctionBody(); this accessor exists
  // specifically for the *outermost* script/REPL scope, which those never
  // reach (top-level statements are dispatched directly by
  // ScriptManager::executeFile()'s executeProgram() call or main.cpp's REPL
  // loop). Must be called after every top-level statement regardless of
  // whether the caller acts on a true result, since leaving a stale signal
  // set would corrupt a later, unrelated for/while loop's first-iteration
  // check.
  bool consumeTopLevelStopSignal() {
    bool stop = (loopSignal_ != LoopSignal::None);
    loopSignal_ = LoopSignal::None;
    return stop;
  }

public:
  std::vector<Token> tokens;

  size_t pos = 0;

  std::unordered_map<std::string, Value> memory;

  std::vector<std::string> insertionOrder;

  // Phase 6 (slot-indexed scope resolution): the active function/method
  // call frame, swapped in/out by invokeFunctionBody() exactly like
  // memory/insertionOrder above. `slots_[i]` holds the Value for whichever
  // variable resolveFunctionSlots() (parser_resolve.cpp) assigned index i
  // to in the function currently executing; `slotAssigned_[i]` tracks
  // whether that slot has actually been written yet this call (a freshly
  // -resized vector's elements are default-constructed regardless of
  // whether anything ever assigns them, unlike `memory`'s `.count()`,
  // which existing code relies on as an "already assigned" signal in
  // several places - e.g. the "output not assigned" error, or "does this
  // dict already exist" checks - so this parallel vector preserves that
  // exact semantic for slotted variables). Both are empty/unused outside
  // the dynamic extent of an invokeFunctionBody() call (top-level script
  // execution and the REPL never touch them - see currentAnsSlot_ below).
  std::vector<Value> slots_;
  std::vector<bool> slotAssigned_;

  // >=0 only for the duration of a function/method call whose FunctionDef
  // was successfully resolved (see resolveFunctionSlots()); -1 (the
  // permanent value at top level/in the REPL) is what makes "global scope
  // never gets slotted" require no special-casing anywhere in executeStmt()/
  // evaluateExpr() - every var*()/setAns() call site just checks this the
  // same way it checks any other node's resolved slot. Saved/set/restored
  // by invokeFunctionBody() exactly like currentDefiningClass_ below.
  int currentAnsSlot_ = -1;
  int currentBaseSlot_ = -1;

  // MATLAB-style `ans` update policy: only update on successful expression
  // evaluation. This flag is set to false inside parseFactor() error paths.
  bool evaluationSucceeded_ = true;
  // Bumped every time the expression parser reports a syntax error (see
  // parseFactorAtomNode's fallthrough). parseStmtNode() compares it before/
  // after a simple statement to decide whether to discard that statement and
  // resynchronize at the next ';' instead of executing a half-built tree.
  int syntaxErrorCount_ = 0;

  // break/continue/return: loopDepth_ tracks how many enclosing for/while
  // loops are currently executing (incremented/decremented around each
  // loop's iteration phase in executeStmt()'s For/While cases), so
  // executeStmt()'s Break/Continue case can reject one with no enclosing
  // loop instead of needing leak-detection after the fact (return isn't
  // gated by this — it's valid anywhere in a function body). loopSignal_
  // carries the request up through executeStmtList() (which stops
  // processing the current list and returns as soon as it's set) until the
  // nearest enclosing For/While iteration in executeStmt() consumes and
  // clears Break/Continue, or the enclosing function call consumes Return
  // (see callUserFunction/callUserFunctionMulti in parser_function.cpp).
  enum class LoopSignal { None, Break, Continue, Return };
  LoopSignal loopSignal_ = LoopSignal::None;
  int loopDepth_ = 0;

  // An error stops the script. Before 2026-10 a failed statement printed its
  // error and the script carried on with a 0 in place of the bad value, so
  // `print(foo(1)); print("still running");` printed both lines and a typo
  // could give a wrong result with the error scrolled out of sight.
  // executeStmtList() sets this when a statement ends with
  // evaluationSucceeded_ false, then unwinds exactly like Stop in the IDE:
  // every enclosing statement list returns, loops break, and
  // invokeFunctionBody() fails the call quietly (no follow-on "output not
  // assigned" error). executeProgram() / the REPL clear it before the next
  // top-level statement. errorLine_ is the line of the statement that failed
  // first (0 when unknown).
  bool errorAbort_ = false;
  size_t errorLine_ = 0;
  // Called after a statement ran: starts the unwind if it failed - it ended
  // with evaluationSucceeded_ false, or printed an error line while it ran
  // (`errorsBefore` = nc::errorlines::count() just before it; see
  // error_lines.h for why both are needed).
  void noteStatementResult(size_t line, unsigned long errorsBefore) {
    if (nc::errorlines::count() != errorsBefore)
      evaluationSucceeded_ = false;
    if (!evaluationSucceeded_ && !errorAbort_) {
      errorAbort_ = true;
      errorLine_ = line;
    }
    if (errorAbort_)
      loopSignal_ = LoopSignal::Return;
  }
  void clearErrorAbort() {
    errorAbort_ = false;
    errorLine_ = 0;
  }

  // The output names of the function/method whose body is running (empty at
  // top level) - what `return value;` assigns to. Saved/set/restored by
  // invokeFunctionBody() like currentDefiningClass_.
  const std::vector<std::string> *currentOutputNames_ = nullptr;
  const std::vector<int> *currentOutputSlots_ = nullptr;

  // Step-into debugging (see main.cpp's "@cmd stepinto"/"stepnext"
  // handling). When true, executeStmtList() (parser_exec_stmt.cpp) pauses
  // after every statement - including each loop iteration, since For/While
  // bodies are just nested calls to executeStmtList() - by printing
  // "@STEPAT <line>" and blocking on stdin for the next "@cmd stepnext" (or
  // "@cmd stepdone" to stop pausing for the remainder of this run). Off by
  // default so plain Run/REPL execution is completely unaffected.
  bool debugStepMode_ = false;

  struct FunctionDef {
    std::vector<std::string> inputNames;
    std::vector<std::string> outputNames; // empty = no declared output

    // Default values, parallel to inputNames (null = the input has no
    // default and must be given) - cloned from the FunctionDecl's own
    // Stmt::inputDefaults. EMPTY when no input has one. Evaluated by
    // invokeFunctionBody() at call time, in the called function's scope,
    // after the caller's values are bound; resolveFunctionSlots() stamps
    // their identifiers like any read in the body, so `b = a*2` reads `a`.
    std::vector<std::unique_ptr<Expr>> inputDefaults;
    // Source text of each default (for .info and error messages), "" where
    // there is none. Same length as inputDefaults.
    std::vector<std::string> inputDefaultTexts;
    bool hasDefault(size_t i) const { return i < inputDefaults.size() && inputDefaults[i]; }

    // Parsed once at registration time (registerFunctionDeclStmt()/
    // registerClassDeclStmt() in parser_exec_stmt.cpp, which deep-clone an
    // already-parsed FunctionDecl/ClassDecl Stmt's body via cloneStmt()),
    // then walked by executeStmtList() on every call (invokeFunctionBody())
    // - not re-lexed per call the way the pre-Phase-3 bodyLines (raw text)
    // representation was. Not copyable (unique_ptr members): FunctionDef
    // itself is therefore move-only now - see findMethodInChain's pointer-
    // returning signature below, which exists specifically so resolving a
    // method never needs to copy one of these out of the table.
    std::vector<std::unique_ptr<Stmt>> body;

    // Phase 6 (slot-indexed scope resolution): computed once by
    // resolveFunctionSlots() (parser_resolve.cpp), called right after body
    // is set, from registerFunctionDeclStmt()/registerClassDeclStmt(). Every
    // call to this function/method resizes Parser::slots_/slotAssigned_ to
    // slotCount instead of touching `memory` by name for anything resolved
    // to a slot - see Expr::slot's comment for what "resolved" means and
    // why an unresolved (-1) name is always still correct.
    int slotCount = 0;
    // Parallel to inputNames. Almost always slots 0..k-1 in order, but not
    // assumed to be - a parameter name that's *also* reassigned via a
    // multi-output call `[A,B] = f(...)` somewhere in this same body would
    // otherwise desync (reads/other assignments of that name resolve
    // through slotOf to a real slot, while the multi-output write always
    // targets `memory` - see resolveFunctionSlots()'s Pass A) - so an input
    // whose name lands in that pass's exclusion set gets -1 here instead of
    // a raw positional index, and invokeFunctionBody() seeds it into
    // `memory` like any other unresolved variable. A deliberately pathological
    // edge case, but a silent-corruption one if left unhandled, not just a
    // missed optimization - so it's handled exactly like every other name.
    std::vector<int> inputSlots;
    std::vector<int> outputSlots; // parallel to outputNames; -1 = that
                                   // output stays on the `memory` fallback
                                   // (e.g. also reassigned via a
                                   // multi-output call somewhere in this
                                   // same body - see resolveFunctionSlots())
    int baseSlot = -1; // -1 for a plain function; >=0 for a method/ctor
    int ansSlot = -1;  // always >=0 once resolved

    // Anonymous functions only (@(x) a*x): the free names of the body and
    // the values they had where the function was written, seeded into the
    // call's scope by invokeFunctionBody(). Empty for a named function.
    std::vector<std::pair<std::string, Value>> captured;
  };
  // Polymorphism (overloading): each name maps to every declared arity of
  // it, e.g. two `function B = combine(...)` with different input counts.
  // Resolved at call time by which versions the call can be bound to
  // (resolveOverload) — this language has no parameter type annotations,
  // so the inputs' names, count and defaults are the only axes overload
  // resolution can go on.
  std::unordered_map<std::string, std::vector<FunctionDef>> functionTable_;

  /* ---- Matching a call's values to a function's inputs ----
     (parser_args.cpp; the rule itself is runtime/interpreter/core/
     arg_binding.h, shared with the built-in functions)

     A call gives values, each either plain (`F(1, 2)`) or named
     (`F(b=2, 1)`). They are matched to the inputs in two passes:
       1. every named value goes to the input of that name;
       2. the plain values, in the order written, fill the inputs that are
          still open, left to right - wherever in the call they appear, so
          F(A2=10, A4=15, 1, 2, 3) on F(A1..A5) gives A1=1, A3=2, A5=3, and
          F(1, A1=5) gives A1=5, A2=1.
     Any input still open then takes its default; one with no default is
     an error. So are: a name the function has no input for, the same input
     given twice, and more plain values than open inputs. */

  // One call's values matched to one FunctionDef: for every input, the
  // index of the call value it takes, or -1 when it takes its default.
  struct ArgBinding {
    std::vector<int> sourceOf;
    size_t defaultsUsed = 0;
  };

  // Matches a call of `argCount` values named by `argNames` (empty = all
  // plain; otherwise one entry per value, "" for a plain one) to `def`.
  // False with `why` set (a sentence without "Error:") if it cannot.
  static bool planBinding(const FunctionDef &def, size_t argCount,
                          const std::vector<std::string> &argNames, ArgBinding &out,
                          std::string &why);

  // Picks the version of an overloaded function/method that the call
  // binds to: among the versions it can be bound to, the one that needs
  // the fewest defaults. Two versions tied for fewest is an "ambiguous
  // call" error. Returns null with `err` set (a full sentence naming
  // `label`, e.g. "function 'F'") when nothing fits; `sigName` is the name
  // used when listing the versions. `outBinding` (optional) receives the
  // winning binding.
  static const FunctionDef *resolveOverload(const std::vector<FunctionDef> &overloads,
                                            const std::string &label,
                                            const std::string &sigName, size_t argCount,
                                            const std::vector<std::string> &argNames,
                                            std::string &err, ArgBinding *outBinding = nullptr,
                                            bool *outAmbiguous = nullptr);

  // "[q, r] = divmod(a, b=2)" - a version's header as the user wrote it.
  static std::string signatureText(const std::string &name, const FunctionDef &def);

  // The shared empty argNames ("every value is plain").
  static const std::vector<std::string> &noArgNames();

  // Parses a call's argument list, up to (not including) the closing ')'.
  // Each argument is an expression or `name = expression`; argNames gets
  // one entry per argument ("" for a plain one) and is cleared again when
  // none has a name. `colonSeparates`: also accept ':' between arguments
  // (dict(keys: values)). False after a syntax error (already reported).
  bool parseCallArgs(std::vector<std::unique_ptr<Expr>> &args,
                     std::vector<std::string> &argNames, bool colonSeparates);

  // Registers `def` under `name` in `table`: replaces an existing overload
  // of the same arity in place (redefinition), otherwise appends a new one.
  // Shared by registerFunctionDeclStmt() (functionTable_) and
  // registerClassDeclStmt() (a ClassDef's methods map), both in
  // parser_exec_stmt.cpp.
  void registerOverload(
      std::unordered_map<std::string, std::vector<FunctionDef>> &table,
      const std::string &name, FunctionDef def);

  // The version in `overloads` that `argCount` plain values bind to (see
  // resolveOverload - defaults count, so F(a, b=2) takes 1 or 2), or
  // nullptr if none does or the call is ambiguous. Prints nothing. Used by
  // the bare-no-parens-call fallback in parser_factor.cpp (which looks for
  // a version callable with no values at all).
  static const FunctionDef *
  findOverload(const std::vector<FunctionDef> &overloads, size_t argCount);

  // Retired with variables.txt: nothing reads it any more. Kept only so
  // PersistenceSuppressor (parser_internal.h) and any parser file outside
  // this change that still touches it keep compiling.
  int suppressPersistence_ = 0;

  /* ---- The global workspace, from anywhere ----
     A function/method call moves the caller's `memory` aside and runs on a
     fresh local map (invokeFunctionBody(), and nc_bridge_push_scope() for
     JIT-compiled calls). Code that must act on the GLOBAL workspace even
     from inside a call - save_workspace()/load_workspace(), the IDE's
     variable list while a step pause sits inside a function - reaches it
     through these. */

  // Number of function/method call frames currently active (0 at top level).
  int scopeDepth_ = 0;

  // While scopeDepth_ > 0: where the outermost call moved the global
  // `memory` / `insertionOrder` to. Null at top level.
  std::unordered_map<std::string, Value> *globalMemoryRef_ = nullptr;
  std::vector<std::string> *globalOrderRef_ = nullptr;

  // Called by every scope switch, right after the caller's memory/
  // insertionOrder have been moved to `savedMemory`/`savedOrder` (which
  // must stay at the same address until the matching leaveLocalScope()).
  void enterLocalScope(std::unordered_map<std::string, Value> *savedMemory,
                       std::vector<std::string> *savedOrder);
  void leaveLocalScope();

  std::unordered_map<std::string, Value> &globalMemory() {
    return scopeDepth_ > 0 && globalMemoryRef_ ? *globalMemoryRef_ : memory;
  }
  std::vector<std::string> &globalInsertionOrder() {
    return scopeDepth_ > 0 && globalOrderRef_ ? *globalOrderRef_ : insertionOrder;
  }

  // Empties the global workspace (the IDE's `clear`).
  void clearGlobalWorkspace();

  // Removes one global variable (the IDE's `clear name`). False if there
  // was no such variable.
  bool removeGlobalVariable(const std::string &name);

  // The class whose own `methods` map the currently-running method/
  // constructor body was found in (via findMethodInChain, parser_class.cpp)
  // — empty when not currently running as any class's method (e.g. a plain
  // function call, or top-level script code). See invokeFunctionBody's
  // comment above for why this is distinct from `base`'s className.
  std::string currentDefiningClass_;

  // Shared invocation core for callUserFunction/callUserFunctionMulti
  // (parser_function.cpp) and the class-call machinery (parser_class.cpp):
  // binds args into a fresh local scope, runs the body, and returns that
  // scope's final memory map for the caller to pull the declared output
  // name(s) (and, for a method/constructor call, the mutated `base`) out
  // of. Swaps `memory`/loop state/tokens+pos out and back in around the
  // call so recursion, nested loops/break/continue, and a call nested
  // inside another call's argument list all work correctly and never leak
  // across the call boundary. `selfValue`, when non-null, seeds `base` in
  // the fresh local scope before the body runs — this is the only
  // difference between a plain function call and a method/constructor call.
  // `definingClassName`, when non-empty, sets currentDefiningClass_ for the
  // duration of the call — the class whose *own* methods map the running
  // code was actually found in via findMethodInChain(), as opposed to
  // `base`'s className (the instance's dynamic type) — these diverge under
  // inheritance (e.g. a Base-defined method running because a Derived
  // instance called it without overriding it). This is what parent(...)
  // resolves relative to and what checkFieldAccess() bases private/
  // protected enforcement on.
  //
  // `args` are the call's values in the order written and `argNames` their
  // names (see planBinding()); every input not given takes its default,
  // evaluated here in the new scope after the given values are bound.
  bool invokeFunctionBody(const FunctionDef &def,
                          const std::vector<Value> &args,
                          std::unordered_map<std::string, Value> &outScope,
                          const Value *selfValue = nullptr,
                          const std::string &definingClassName = std::string(),
                          const std::vector<std::string> &argNames = noArgNames());

  // Single-output/void call path (parser_factor.cpp: IDENT(...) and bare
  // no-input-no-output IDENT). `found` is false iff `name` isn't a
  // registered user function at all (caller falls back to callBuiltin()).
  // `argNames`: see planBinding().
  Value callUserFunction(const std::string &name,
                         const std::vector<Value> &args, bool &found,
                         const std::vector<std::string> &argNames = noArgNames());

  // Multi-output call path (parser_exec_stmt.cpp: (B1,B2) = name(...)).
  std::vector<Value> callUserFunctionMulti(const std::string &name,
                                           const std::vector<Value> &args,
                                           size_t expectedOutputs, bool &found,
                                           const std::vector<std::string> &argNames = noArgNames());

  struct ClassDef {
    // Includes the constructor under the reserved name "base" — a
    // constructor is just a method with no declared output whose mutated
    // `base` scope IS the newly-created instance (see callClassConstructor
    // in parser_class.cpp). Each name maps to every declared arity of it
    // (overloading — see functionTable_'s comment above; methods and
    // constructors get this "for free" via the same registerOverload/
    // findOverload machinery).
    std::unordered_map<std::string, std::vector<FunctionDef>> methods;
    // Method names in the order they were declared (each once) - `methods`
    // itself is unordered. Used by ClassName.info to list them in order.
    std::vector<std::string> methodOrder;

    // Encapsulation: fields declared `private`/`protected` (e.g.
    // `private mean, std;`). Presence in this map means the field is
    // restricted; the bool distinguishes protected(true)/private(false) for
    // when inheritance eventually gives them different meaning — for now
    // both are enforced identically (see the access checks in
    // parser_factor.cpp/parser_exec_stmt.cpp). A field never mentioned here
    // is public, matching the class skeleton's original all-public behavior.
    std::unordered_map<std::string, bool> restrictedFields;

    // Inheritance: `class Child(Parent)` — empty means no parent. Only ever
    // *stored* here, never resolved at registration time, so a parent class
    // may legally be defined later in the file (same forward-reference
    // guarantee functions/classes already have) — resolution happens lazily
    // via findMethodInChain()/isClassOrSubclassOf() at actual call time.
    std::string parentClassName;

    // Abstraction: `abstract class Name(...)`. An abstract class can't be
    // instantiated directly; a method/constructor overload declared with no
    // body (fnend immediately after the header) inside it is a required-
    // override contract — see validateConcreteInstantiation().
    bool isAbstract = false;

    // Reversibility: `reversible class Name(...)`. Opt-in per the design
    // doc's own recommendation (full snapshotting has real memory/perf
    // cost) — only instances of a class marked this way get a field-state
    // snapshot pushed to Value::snapshots on construction/each method call,
    // enabling `.rewind()`. A non-reversible class's instances never pay
    // that cost.
    bool isReversible = false;

    // Temporal Determinism: `class Name() @rate(500Hz) ... csend`. Purely
    // metadata — this interpreter has no real scheduler/dataflow engine (the
    // design doc itself says this pillar "should land alongside the
    // multi-rate scheduler work, not before it"), so honoring it is scoped
    // to what's actually achievable here: the reserved `.tick(currentTime)`
    // call (parser_factor.cpp) only actually runs the class's `step()`
    // method when enough simulated time has passed since the instance's
    // last tick, per this rate. No implicit/automatic scheduling of any
    // kind — the caller drives simulated time explicitly.
    bool hasRate = false;
    double rateHz = 0.0;
  };
  std::unordered_map<std::string, ClassDef> classTable_;

  // Walks className's chain looking for the nearest class (className itself
  // or an ancestor) with its own `@rate(...)` — same inheritance semantics
  // as everything else in this feature set (a subclass with no rate of its
  // own inherits its ancestor's). False if no class in the chain has one.
  bool findRateInChain(const std::string &className, double &outRateHz);

  // Called by callClassConstructor() before actually instantiating
  // `className`. Returns false (having already printed the specific error
  // and set evaluationSucceeded_) if `className` itself is abstract, or if
  // any abstract ancestor's bodyless method/constructor contract isn't
  // satisfied by a real (non-empty-body) implementation somewhere in
  // className's own resolvable chain — checked here, at instantiation time,
  // rather than at className's own registration time, because (matching
  // every other resolution in this feature set) a forward-referenced
  // abstract ancestor might not even be registered yet when className
  // itself is registered.
  bool validateConcreteInstantiation(const std::string &className);

  // Walks className's own chain (className, then its parent, then its
  // parent's parent, ...) looking for an overload of methodName matching
  // argCount — checking a class's own methods before its parent's is what
  // makes override "just work" with no special-casing (a class's own
  // matching-arity overload wins even if an ancestor also has one; if only
  // the *name* exists at this level but not that arity, the walk continues
  // up rather than stopping, so an ancestor's differently-sized overload is
  // still reachable). Returns a pointer to the FunctionDef inside
  // classTable_ (nullptr if no matching overload exists anywhere in the
  // chain, including if the chain dangles on a parent class name that was
  // never actually registered) and, via outDefiningClass, which class it
  // was actually found in (see invokeFunctionBody's comment for why that
  // matters). Pointer rather than an output copy because FunctionDef holds
  // its body as a Stmt tree (unique_ptr members) and so isn't copyable;
  // callers use the pointer immediately (an invokeFunctionBody() call, at
  // most a few statements away), the same lifetime discipline
  // findOverload()'s own pointer return already relies on.
  const FunctionDef *findMethodInChain(const std::string &className,
                                       const std::string &methodName, size_t argCount,
                                       std::string &outDefiningClass);
  // The same walk for a call that may use named values and defaults: at
  // each class, resolveOverload() picks among that class's own versions;
  // the first class with a version that fits wins (so an override still
  // wins over the parent). Null with `err` set when nothing in the chain
  // fits - the most specific reason found, from the class nearest to
  // className. `label` names the method in that message.
  const FunctionDef *findMethodInChain(const std::string &className,
                                       const std::string &methodName, size_t argCount,
                                       const std::vector<std::string> &argNames,
                                       const std::string &label,
                                       std::string &outDefiningClass, std::string &err);

  // True if methodName exists *by name* anywhere in className's chain,
  // regardless of arity — used only to produce a more precise error
  // ("no overload takes N arguments" vs. "no such method") when
  // findMethodInChain fails.
  bool methodNameExistsInChain(const std::string &className,
                               const std::string &methodName);

  // True if `candidate` IS `ancestor` or inherits from it (directly or
  // transitively) — the basis for `protected` reaching into subclasses (see
  // checkFieldAccess).
  bool isClassOrSubclassOf(const std::string &candidate,
                           const std::string &ancestor);

  // `parent(args)` — chains into the parent (relative to
  // currentDefiningClass_) class's constructor, running it against the
  // *current*, already-partially-built `base` (not a fresh instance) and
  // merging the result back into memory["base"]. Reserved call name,
  // intercepted by text in parser_factor.cpp's IDENT(...) branch rather
  // than being a token (same precedent as `new`/`clear`).
  Value callParentConstructor(const std::vector<Value> &args,
                              const std::vector<std::string> &argNames = noArgNames());

  // Constructor call — `ClassName(args)` in an expression position
  // (parser_factor.cpp). Seeds a fresh empty object as `base` (className
  // set to the class actually being instantiated — the dynamic type stays
  // fixed even when the constructor that runs was found higher up the
  // chain), runs the constructor body, and returns the mutated `base` as
  // the new instance. `found` is false iff `className` isn't a registered
  // class at all.
  Value callClassConstructor(const std::string &className,
                             const std::vector<Value> &args, bool &found,
                             const std::vector<std::string> &argNames = noArgNames());

  // Encapsulation check, shared by the object field-read branch
  // (parser_factor.cpp) and the field-assignment branch
  // (parser_exec_stmt.cpp). Returns true if accessing `fieldName` on an
  // instance of `className` is allowed from the current execution context;
  // otherwise prints the "field is private/protected" error, sets
  // evaluationSucceeded_ = false, and returns false. A field never declared
  // private/protected is always allowed (the default, backward-compatible
  // case). "Current context" is self-access if `base` is bound to an
  // instance of the *same* class right now — true both for base.field
  // itself and, incidentally, another same-class instance's field read
  // from inside a method (e.g. `other.field` where other is a same-class
  // argument) — not just the literal identifier `base`.
  bool checkFieldAccess(const std::string &className,
                        const std::string &fieldName);
  // The same rule as checkFieldAccess(), as a plain question: prints
  // nothing and leaves evaluationSucceeded_ alone. Used to leave private/
  // protected fields out of ClassName.base / obj.base outside the class.
  bool fieldVisibleHere(const std::string &className, const std::string &fieldName);

  /* ---- Class introspection: .base and .info (parser_class_info.cpp) ----

       ClassName.base  {field: type} - every field the constructor sets
                       (base.x = ...), with its type ("float64", "string",
                       "bool", "int32", "matrix", "dict", a class name ...)
                       worked out from the constructor's code; "any" when
                       it depends on a value the caller must pass.
       obj.base        {field: value} - the instance's actual fields.
       ClassName.info  {class, parent, count, functions} - every function
                       callable on the class: its own and inherited methods
                       and constructors, each overload listed separately.
                       Typed without ';' it is shown as a table.
       obj.info        the same as ClassName.info for obj's class.

     `base` and `info` are reserved after a dot: an object never has a
     field of either name. A variable named like the class still wins
     (ClassName is only taken as the class when no variable has that name).
     Both also work with empty brackets: ClassName.info(). */

  // ClassName.base / ClassName.info.
  Value classBaseTypes(const std::string &className);
  Value classInfo(const std::string &className);
  // obj.base - the fields this code may see, with their values.
  Value instanceBaseValues(const Value &obj);
  // Shows a classInfo() result as a table under "title =" (what
  // `ClassName.info` with no ';' prints instead of the raw dict).
  void printClassInfo(const std::string &title, const Value &info);
  // If `node` is X.base / X.info / X.base() / X.info() on a class name or
  // an object, evaluates it into `out` and returns true. `isInfo` tells
  // which one it was.
  bool tryClassIntrospection(const Expr *node, Value &out, bool &isInfo);
  // True when `name` is reserved after a dot (base, info).
  static bool isIntrospectionName(const std::string &name) {
    return name == "base" || name == "info";
  }

  // Instance method call — `obj.Method(args)` (parser_factor.cpp, when the
  // receiver is an object). Runs with `base` seeded to `selfBefore`; returns
  // the method's declared output (or Value(0) if void) as the call result,
  // and separately hands back the mutated instance via `outSelfAfter` so the
  // caller can write it back into the variable that held the receiver —
  // mutating a method's `base.field` must persist across future calls on
  // the same instance. `found` is false iff the class has no such method.
  Value callInstanceMethod(const Value &selfBefore,
                           const std::string &methodName,
                           const std::vector<Value> &args, Value &outSelfAfter,
                           bool &found,
                           const std::vector<std::string> &argNames = noArgNames());

  // Existence checks for classTable_/functionTable_ (both private) - added
  // for the codegen bridge (nc_bridge_call_dynamic, codegen_bridge/
  // value_bridge.cpp): CodeGen's own classCtorArity_/functionArity_ only
  // ever learn about a class/function it compiled itself (see JitEngine's
  // knownClasses_/knownFunctions_ comment), so one defined purely via the
  // tree-walker (e.g. before "@cmd jit on", or ever - a script that never
  // toggles JIT on for that particular statement) is otherwise invisible to
  // it. These let the bridge fall back to the real classTable_/
  // functionTable_ - and therefore to the real callClassConstructor()/
  // callUserFunction(), inheritance/abstract/reversible/@rate included -
  // instead of wrongly treating the name as an unknown builtin.
  bool hasClass(const std::string &name) const { return classTable_.count(name) != 0; }
  bool hasFunction(const std::string &name) const { return functionTable_.count(name) != 0; }

  // Extracted from executeStmt()'s StmtKind::ClearMemory case so the
  // codegen bridge (nc_bridge_clear_memory) can call the exact same logic
  // instead of reimplementing it. Clears the CURRENT scope's variables
  // (the global workspace at top level).
  void clearMemory();

  // Old name of clearMemory(), from when it also rewrote variables.txt.
  void clearMemoryAndPersist() { clearMemory(); }

  // Sets loopSignal_ to Return, exactly what a bare top-level `return;` or
  // a failed top-level `require`/`ensure` already does in executeStmt() -
  // exposed for the codegen bridge (nc_bridge_signal_top_level_return,
  // codegen_bridge/value_bridge.cpp), called ONLY when CodeGen is compiling
  // the genuine outermost entry, never a user function/method body (see
  // codegen.h's inUserFunctionBody_ comment for why the distinction
  // matters). consumeTopLevelStopSignal() (above) is what a caller reads
  // this back through.
  void signalTopLevelReturn() { loopSignal_ = LoopSignal::Return; }

  // Turns step-into pausing on/off (see debugStepMode_'s comment above).
  // Called from main.cpp's "@cmd stepinto"/"@cmd stepdone" handling.
  void setDebugStepMode(bool on) { debugStepMode_ = on; }
  bool isDebugStepMode() const { return debugStepMode_; }

  Token current();

  void advance();

  // variables.txt is gone: the workspace now lives only in `memory`, goes
  // to the IDE over the JSON channel (runtime/data/DataEngine.h) and to
  // disk only through save_workspace() / the session autosave. This stays
  // as a no-op so callers in parser files outside this change compile.
  void saveToFile() {}

  // Expression precedence-climbing chain: each parseXNode() consumes
  // tokens and builds a tree with no side effects at all (which operator
  // tokens appear is decided purely by the token stream, never by operand
  // values, unlike parseFactorNode()'s IDENT branch has to be careful about
  // - see its own comments). evaluateExpr() (and the two helpers it
  // delegates to for this layer's node kinds, in parser_expression.cpp) is
  // the sole place that actually touches `memory`, applies an operator, or
  // reports a dimension/orderability/type error - the single source of
  // truth for what a built expression tree means, whether it came from a
  // file, the REPL, or a function/method body.
  std::unique_ptr<Expr> parseOrNode();
  std::unique_ptr<Expr> parseAndNode();
  std::unique_ptr<Expr> parseComparisonNode();
  std::unique_ptr<Expr> parseExpressionNode();
  std::unique_ptr<Expr> parseTermNode();
  // Prefix +/- : sits between term (*,/, ...) and power (^) so that unary
  // minus binds LOOSER than exponentiation, matching standard mathematical
  // convention (and every mainstream language's) - -2^2 == -4, not 4.
  std::unique_ptr<Expr> parseUnaryNode();
  std::unique_ptr<Expr> parsePowerNode();
  // Consumes the `closeType` token that must end a bracketed construct opened
  // by `openTok`, or (like Python's "'(' was never closed") reports a syntax
  // error naming the opener's position, bumps syntaxErrorCount_, and
  // returns false so the caller can abandon the expression.
  bool requireClosing(TokenType closeType, const Token &openTok);
  // If `tok` is ',=' or ';=' (allowed only as `name ,= value` statements),
  // reports that as a syntax error and returns true; false otherwise.
  bool reportMisplacedExtend(const Token &tok);
  std::unique_ptr<Expr> parseFactorNode();     // atom + postfix '!' chain
  std::unique_ptr<Expr> parseFactorAtomNode(); // the atom itself

  // One key inside an Index bracket group: a bare ':' becomes a Wildcard
  // node (see ast.h), anything else is an ordinary expression. Shared by
  // parseFactorNode()'s read-side A[...] parsing and
  // parseAssignOrExprStmtNode()'s write-side A[...] = ... parsing so both
  // sides accept the same key shapes (parser_factor.cpp).
  std::unique_ptr<Expr> parseIndexKeyNode();

  // Wraps `node` in every postfix link that follows it: .field, .method(...)
  // and [keys] (same line as `line` only), any order and depth - D.ABC.cols,
  // D.axes[0].lines[0].x. False after reporting a syntax error
  // (parser_factor.cpp).
  bool parsePostfixChain(std::unique_ptr<Expr> &node, size_t line);

  // Evaluates Index keys (plain index / Wildcard / Slice nodes) into the
  // shared matrix-indexing form (ops/matrix/matrix_index.h) - used by both
  // the Index read (parser_factor.cpp) and executeIndexAssign(). False with
  // `err` set (or empty, when a key's own evaluation already reported its
  // error) if a key is not a whole number or a range.
  bool evaluateIndexKeys(const std::vector<const Expr *> &keyNodes,
                         std::vector<MatIndexKey> &keys, std::string &err);

  Value evaluateExpr(const Expr *node);
  // A bare identifier read: resolved local/global -> named constant -> unit
  // constant -> zero-arg function call -> "Unknown constant". Shared by
  // evaluateExpr()'s Identifier case and the FieldAccess elementwise-dot
  // fallback (both name an ordinary variable the same way); `slot` is
  // whatever the corresponding Expr node was resolved to (see Expr::slot).
  Value readVariableOrConstant(const std::string &name, int slot);
  Value evaluateBinaryOp(const Expr *node);
  // feval/grad/taylor_series/green_integral - a reserved-name call whose
  // implementation needs to call a user-supplied function reference
  // (@name) repeatedly. Shared by evaluateExpr()'s ExprKind::Call case and
  // the JIT dynamic-dispatch bridge (nc_bridge_call_dynamic,
  // codegen_bridge/value_bridge.cpp) - see parser_factor.cpp's own comment
  // on this method for why both need it. Sets `handled` true iff `name`
  // was one of these four; the returned Value is only meaningful then.
  Value tryReservedFunctionValueCall(const std::string &name, const std::vector<Value> &args,
                                      bool &handled);
  // Calls the function a reference (`@name`, `@(x) ...`) points at - a
  // function the script defines, an anonymous function, or a builtin
  // (@sqrt). Used by feval(f, ...) and by f(...) when the variable f holds a
  // reference.
  // This Parser answers SciPy kernels that call an NC function by name.
  void bindScipyCallbacks();
  int userFunctionInputCount(const std::string &name) const;
  Value callFunctionValue(const Value &ref, const std::vector<Value> &args,
                          const std::vector<std::string> &argNames = noArgNames());
  // @(x, y) body - registers the anonymous function (once per place it is
  // written and set of captured values) and returns a reference to it.
  Value makeAnonymousFunction(const Expr *node);
  std::unordered_map<const Expr *, std::vector<std::string>> anonymousNames_;
  size_t anonymousCounter_ = 0;
  Value evaluateComparison(const Expr *node);
  Value evaluateLogicalOp(const Expr *node);
  // Value-level cores of evaluateBinaryOp()/evaluateComparison() above -
  // same text-coercion/dimension/orderability checks and error messages,
  // just operating on two already-evaluated Values instead of an Expr's
  // children. Exposed publicly so the codegen/JIT bridge
  // (nc_bridge_binary_op_checked/nc_bridge_comparison_checked,
  // codegen_bridge/value_bridge.cpp) can reuse this exact logic rather than
  // the JIT path silently skipping it (see parser_expression.cpp for the
  // full history of the bug this closes).
  Value evaluateBinaryOpValues(const std::string &op, Value v, Value r);
  Value evaluateComparisonValues(const std::string &op, Value v, Value r);

  // A real recursive-descent statement/block parser: the single parser
  // both ScriptManager::executeFile() (via parseProgram(), for a whole
  // file) and main.cpp's REPL (via parseStmtNode(), for one buffered
  // statement at a time) drive - replacing the old raw-text-accumulation-
  // and-keyword-rescanning each used to do independently. Building the
  // Stmt tree (this layer) has no side effect at all (no memory access, no
  // registration into functionTable_/classTable_, no execution) - only
  // executeProgram()/executeStmt() below, walking the result, does.
  // parseProgram() sets tokens/pos once for the whole file (or a whole
  // function/method body) rather than one-Lexer-call-per-line - nesting
  // depth is handled by ordinary recursion (an if/for/while/function/class
  // header's own body is parsed by recursively calling back into
  // parseStmtNode()), not by a depth counter anywhere.
  Program parseProgram(const std::vector<Token> &fileTokens);
  std::unique_ptr<Stmt> parseStmtNode();     // recovery wrapper
  std::unique_ptr<Stmt> parseStmtNodeImpl(); // the real dispatch

  // Parses statements until `isBoundary()` reports true (checked before
  // each statement, so it fires on a not-yet-consumed terminator/elseif/
  // else keyword) or end of input. `stmt` may be null in the returned list
  // is never the case - a null result from parseStmtNode() means no token
  // was consumed, which the zero-progress guard turns into a stop instead.
  std::vector<std::unique_ptr<Stmt>>
  parseStmtsUntil(const std::function<bool()> &isBoundary);

  std::unique_ptr<Stmt> parseIfStmtNode();
  std::unique_ptr<Stmt> parseForStmtNode();
  std::unique_ptr<Stmt> parseWhileStmtNode();
  std::unique_ptr<Stmt> parseFunctionDeclNode();
  std::unique_ptr<Stmt> parseClassDeclNode();
  std::unique_ptr<Stmt> parsePublishStmtNode();
  // Assignment (incl. dict-key/matrix-element/array-element/object-field
  // variants), list of variables `[A,B] = ...`, and the plain-expression
  // fallback - one function because the shape isn't known until several
  // tokens in and a mismatch means rewinding to try the next one.
  std::unique_ptr<Stmt> parseAssignOrExprStmtNode();
  // [a, b, c] = ... / [a, b; c, d] = ... (a list of variables assigned
  // together) - called by parseAssignOrExprStmtNode() once it has seen the
  // '[' ... ']' '=' shape. See executeAssignStmt() for what it means.
  std::unique_ptr<Stmt> parseTargetListAssign();

  // condition, negated if a bare `not` precedes it (case-insensitive) -
  // shared by if/elseif/while headers. The header must end with ':'
  // (reported as a syntax error naming `keyword` otherwise).
  std::unique_ptr<Expr> parseConditionHeader(const char *keyword);

  // The tree-walking evaluator. Reuses every existing side-effecting
  // primitive (memory, saveToFile(), callBuiltin/callUserFunction/
  // callClassConstructor/callInstanceMethod, loopSignal_/loopDepth_)
  // exactly as they were - only the driving mechanism is "walk an
  // already-built tree" rather than "re-lex text, re-scan for boundaries".
  // executeProgram() drives a whole file (ScriptManager::executeFile());
  // invokeFunctionBody() drives a function/method body's tree on every
  // call; main.cpp's REPL calls executeStmt() directly for one statement.
  void executeProgram(const Program &program);
  // Pass 1 of executeProgram(), pulled out into its own public method so a
  // JIT-aware caller (ScriptManager::executeFile(), when JIT is enabled -
  // see SM_stage_02.cpp) can do its OWN Pass 2 (attempt JitEngine::runStmt()
  // per statement, same fallback-to-executeStmt() pattern main.cpp's REPL
  // loop already uses) while still getting this forward-reference guarantee
  // registering every top-level function/class up front, exactly as
  // executeProgram() itself does (which now just calls this, unchanged
  // behavior). Parser itself stays JIT-agnostic either way - this is pure
  // tree-walker registration, no different from what executeProgram() always
  // did here.
  void registerTopLevelDecls(const Program &program);
  // Runs `stmts` in order, stopping early if loopSignal_ becomes set
  // (break/continue/return).
  void executeStmtList(const std::vector<std::unique_ptr<Stmt>> &stmts);
  void executeStmt(const Stmt *stmt);

  // Builds a runtime FunctionDef/ClassDef directly from an already-parsed
  // FunctionDecl/ClassDecl Stmt (no text, no re-parsing - the Stmt's own
  // fields already hold everything) and registers it into functionTable_/
  // classTable_. Used both for executeProgram()'s forward-reference
  // pre-pass and for executeStmt() encountering one of these inline (e.g.
  // nested inside an if/for/while body - not a construct any script in
  // this codebase's test corpus actually uses, but well-defined here
  // rather than left to misbehave: it registers at the point execution
  // reaches it, same as it would read if you described the behavior in
  // English).
  void registerFunctionDeclStmt(const Stmt &stmt);
  void registerClassDeclStmt(const Stmt &stmt);

  // Phase 6 (slot-indexed scope resolution, parser_resolve.cpp). Walks
  // def.body (already cloned/owned by this FunctionDef) exactly once,
  // stamping a fixed slot index onto every Identifier/FieldAccess Expr and
  // For's loopVar that resolveFunctionSlots() determines is a name this
  // function/method locally assigns somewhere in its own body - and only
  // those; a read of an undeclared name (a constant like `pi`, or a
  // deliberately-excluded one - see FunctionDef::inputSlots' comment) is
  // left at its default -1 and keeps working exactly as before, just
  // without the speedup. `hasBase` is true for every class method
  // (including the constructor, itself just a method named "base") and
  // false for a plain top-level function - it decides whether a slot is
  // reserved for "base" at all. Called once per registration (i.e. once
  // per registerFunctionDeclStmt()/registerClassDeclStmt() call - a
  // redefinition or script rerun simply recomputes cleanly on a fresh
  // FunctionDef, the same way registerOverload() already does).
  void resolveFunctionSlots(FunctionDef &def, bool hasBase);

  // Phase 6 variable-access helpers: `slot` (from the resolved Expr/Stmt
  // node) selects `slots_`/`slotAssigned_` when >=0, else `name` selects
  // the existing `memory` map exactly as before - the single place this
  // branch happens, so no call site needs its own `if`. varRef() is for
  // in-place mutation of an *already-existing* variable's contents (a
  // matrix/array element write, a dict key overwrite, an object field
  // write) - it never marks a slot assigned itself, matching how
  // `memory[name].matrix[r][c] = v` today never re-touches `.count()`
  // either; varSet() is for "this name now holds an entirely new Value"
  // (plain assignment, a freshly-created dict, ans/base updates) and is
  // the only one of these that flips slotAssigned_ true.
  bool varExists(int slot, const std::string &name) const;
  Value varGet(int slot, const std::string &name) const;
  Value &varRef(int slot, const std::string &name);
  void varSet(int slot, const std::string &name, Value v);
  // ans is written on nearly every statement, so it's always resolved to a
  // reserved slot for the duration of a function/method call
  // (currentAnsSlot_) - this wrapper is what keeps every one of those call
  // sites from needing its own currentAnsSlot_ >= 0 check, and matches
  // varSet(-1, ...)'s existing saveToFile()-on-every-write behavior only
  // when actually running at top level (currentAnsSlot_ == -1).
  void setAns(const Value &v);

  // Assign-statement helpers (executeStmt's StmtKind::Assign case), split
  // out given how many target shapes there are. executeIndexAssign covers
  // both A[row][col] = v (target->children[0]->kind == Index) and
  // A[key(,key...)] = v (array element or dict key(s), dispatched on the
  // base identifier's actual current value - same "decided at evaluate
  // time" principle as evaluateExpr's FieldAccess/MethodCall cases).
  void executeAssignStmt(const Stmt *stmt);
  // The list-of-variables part of executeAssignStmt(): [a, b, c] = ...
  void executeTargetListAssign(const Stmt *stmt);
  // The extend part of executeAssignStmt(): M ,= X / M ;= X.
  void executeExtendAssign(const Stmt *stmt);
  // Stores `val` into one assignment target (a name, A[...] or obj.field),
  // exactly as `target = val` would. False if that failed.
  bool assignToTarget(const Expr *target, const Value &val, bool suppressOutput);
  void executeIndexAssign(const Expr *target, const Value &val, bool suppressOutput);
};