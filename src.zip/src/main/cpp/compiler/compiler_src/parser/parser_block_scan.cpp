// Nested-block boundary scan: given a flat list of already-accumulated body
// lines that may themselves contain nested if/for/while, walk them tracking
// depth/indentation to find each nested block's boundaries, then recursively
// dispatch. Running an already-bounded block is a separate concern - see
// executeForBlock/executeIfBlock/executeWhileBlock in parser_block_exec.cpp.
#include "parser.h"

#include <cctype>
#include <iostream>

#include "lexer.h"

/* ================= RECURSIVE BLOCK EXECUTION ================= */

Value Parser::executeBlockLines(const std::vector<std::string> &lines) {
  size_t i = 0;
  while (i < lines.size()) {
    const std::string &line = lines[i];

    size_t firstNonSpace = line.find_first_not_of(" \t\r\n");
    if (firstNonSpace == std::string::npos) {
      i++;
      continue;
    }

    int lineIndent = 0;
    for (size_t col = 0; col < firstNonSpace; col++) {
      if (line[col] == '\t') lineIndent += 4;
      else if (line[col] == ' ') lineIndent += 1;
    }

    std::string trimmed = line.substr(firstNonSpace);
    size_t lastNonSpace = trimmed.find_last_not_of(" \t\r\n");
    if (lastNonSpace != std::string::npos)
      trimmed = trimmed.substr(0, lastNonSpace + 1);

    std::string lowerTrimmed = trimmed;
    for (char &ch : lowerTrimmed)
      ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

    // Check if line is an IF statement
    if (lowerTrimmed.rfind("if", 0) == 0 &&
        (lowerTrimmed.size() == 2 || std::isspace((unsigned char)lowerTrimmed[2]) || lowerTrimmed[2] == '(')) {
      int ifIndent = lineIndent;
      std::string ifHeader = trimmed;

      std::vector<std::string> thenLines;
      std::vector<std::string> elseLines;
      std::vector<std::pair<std::string, std::vector<std::string>>> elseifBranches;
      bool foundElse = false;
      int ifDepth = 1;
      int forDepth = 0;

      auto appendLine = [&](const std::string &l) {
        if (foundElse) elseLines.push_back(l);
        else if (!elseifBranches.empty()) elseifBranches.back().second.push_back(l);
        else thenLines.push_back(l);
      };

      i++;
      while (i < lines.size()) {
        const std::string &subLine = lines[i];
        size_t subFirst = subLine.find_first_not_of(" \t\r\n");
        if (subFirst == std::string::npos) {
          appendLine(subLine);
          i++;
          continue;
        }

        int subIndent = 0;
        for (size_t col = 0; col < subFirst; col++) {
          if (subLine[col] == '\t') subIndent += 4;
          else if (subLine[col] == ' ') subIndent += 1;
        }

        std::string subTrimmed = subLine.substr(subFirst);
        size_t subLast = subTrimmed.find_last_not_of(" \t\r\n");
        if (subLast != std::string::npos)
          subTrimmed = subTrimmed.substr(0, subLast + 1);

        std::string subLower = subTrimmed;
        for (char &ch : subLower)
          ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

        // Track nested 'for' blocks
        if (subLower.rfind("for", 0) == 0 &&
            (subLower.size() == 3 || std::isspace((unsigned char)subLower[3]))) {
          forDepth++;
        } else if (forDepth > 0 && Parser::isForTerm(subLower)) {
          forDepth--;
          appendLine(subLine);
          i++;
          continue;
        }

        if (forDepth == 0) {
          // Track nested 'if' blocks
          if (subLower.rfind("if", 0) == 0 &&
              (subLower.size() == 2 || std::isspace((unsigned char)subLower[2]) || subLower[2] == '(')) {
            ifDepth++;
          } else if (ifDepth == 1 && subLower.rfind("elseif", 0) == 0 &&
                     (subLower.size() == 6 || std::isspace((unsigned char)subLower[6])) &&
                     !foundElse) {
            elseifBranches.push_back({subTrimmed, {}});
            i++;
            continue;
          } else if (ifDepth == 1 && (subLower == "else" || subLower == "else:") && !foundElse) {
            foundElse = true;
            // Strict indentation alignment check for else!
            if (subIndent != ifIndent) {
              std::cerr << "✖ Indentation Error: 'else' line (indentation " << subIndent
                        << ") is unaligned with matching 'if' line (indentation " << ifIndent << ")\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }
            i++;
            continue;
          } else if (Parser::isIfTerm(subLower)) {
            if (ifDepth == 1 && subIndent != ifIndent) {
              std::cerr << "✖ Indentation Error: '" << subTrimmed << "' line (indentation " << subIndent
                        << ") is unaligned with matching 'if' line (indentation " << ifIndent << ")\n";
              evaluationSucceeded_ = false;
              return Value(0);
            }
            ifDepth--;
            if (ifDepth == 0) {
              i++;
              break;
            }
          } else if (ifDepth > 0 && Parser::isForTerm(subLower) && subLower != "end") {
            // Mismatched terminator: a for-terminator encountered while 'if' block is still open!
            std::cerr << "✖ Syntax Error: unclosed 'if' statement (expected 'end', 'endif', or 'iend') before '" << subLower << "'\n";
            evaluationSucceeded_ = false;
            return Value(0);
          }
        }

        appendLine(subLine);
        i++;
      }

      if (ifDepth > 0) {
        std::cerr << "✖ Syntax Error: unclosed 'if' statement (missing 'end', 'endif', or 'iend')\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      // Evaluate IF condition
      Lexer ifLex(ifHeader);
      auto ifToks = ifLex.tokenize();
      if (!ifToks.empty() && ifToks[0].type == IF) {
        setTokens(ifToks);
        parseStatement();
        bool condResult = ifConditionResult_;
        inIfBlock_ = false;

        bool matched = condResult;
        if (matched) {
          executeBlockLines(thenLines);
        } else {
          for (auto &branch : elseifBranches) {
            Lexer elLex(branch.first);
            auto elToks = elLex.tokenize();
            if (!elToks.empty() && elToks[0].type == ELSEIF) {
              setTokens(elToks);
              parseStatement();
              bool branchResult = ifConditionResult_;
              inIfBlock_ = false;
              if (branchResult) {
                executeBlockLines(branch.second);
                matched = true;
                break;
              }
            }
          }
          if (!matched) {
            executeBlockLines(elseLines);
          }
        }
      }
      // break/continue inside a branch bubbles up through the if — an if
      // isn't a loop, so it doesn't consume the signal, just stops
      // processing the rest of this block's lines.
      if (loopSignal_ != LoopSignal::None) return Value(0);
      continue;
    }

    // Check if line is a FOR statement
    if (lowerTrimmed.rfind("for", 0) == 0 &&
        (lowerTrimmed.size() == 3 || std::isspace((unsigned char)lowerTrimmed[3]))) {
      std::string headerLine = trimmed;
      std::vector<std::string> forBodyLines;
      int forDepth = 1;
      int ifDepth = 0;
      i++;

      while (i < lines.size()) {
        const std::string &subLine = lines[i];
        size_t subFirst = subLine.find_first_not_of(" \t\r\n");
        if (subFirst != std::string::npos) {
          std::string subTrimmed = subLine.substr(subFirst);
          size_t subLast = subTrimmed.find_last_not_of(" \t\r\n");
          if (subLast != std::string::npos)
            subTrimmed = subTrimmed.substr(0, subLast + 1);

          std::string subLower = subTrimmed;
          for (char &ch : subLower)
            ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

          if (subLower.rfind("if", 0) == 0 &&
              (subLower.size() == 2 || std::isspace((unsigned char)subLower[2]) || subLower[2] == '(')) {
            ifDepth++;
          } else if (ifDepth > 0 && Parser::isIfTerm(subLower)) {
            ifDepth--;
          } else if (ifDepth == 0) {
            if (subLower.rfind("for", 0) == 0 &&
                (subLower.size() == 3 || std::isspace((unsigned char)subLower[3]))) {
              forDepth++;
            } else if (Parser::isForTerm(subLower)) {
              forDepth--;
              if (forDepth == 0) {
                i++;
                break;
              }
            }
          }
        }
        forBodyLines.push_back(subLine);
        i++;
      }

      std::string oldHeader = forHeader_;
      std::string oldPending = pendingForBlock_;
      bool oldInFor = inForBlock_;

      forHeader_ = headerLine;
      pendingForBlock_.clear();
      for (const auto &fline : forBodyLines) {
        pendingForBlock_ += fline + "\n";
      }

      executeForBlock();

      forHeader_ = oldHeader;
      pendingForBlock_ = oldPending;
      inForBlock_ = oldInFor;
      // executeForBlock() only consumes Break/Continue — a Return (from an
      // explicit `return;`/a failed require/ensure inside this for-loop) is
      // deliberately left set so it keeps propagating past the loop, same
      // as the IF branch above; without this check it would silently stop
      // propagating right here instead of reaching the enclosing function
      // call boundary (or the top-level script stop check).
      if (loopSignal_ != LoopSignal::None) return Value(0);
      continue;
    }

    // Check if line is a WHILE statement
    if (lowerTrimmed.rfind("while", 0) == 0 &&
        (lowerTrimmed.size() == 5 || std::isspace((unsigned char)lowerTrimmed[5]) || lowerTrimmed[5] == '(')) {
      int whileIndent = lineIndent;
      std::string headerLine = trimmed;
      std::vector<std::string> whileBodyLines;
      int whileDepth = 1;
      int ifDepth = 0;
      int forDepth = 0;
      i++;

      while (i < lines.size()) {
        const std::string &subLine = lines[i];
        size_t subFirst = subLine.find_first_not_of(" \t\r\n");
        if (subFirst != std::string::npos) {
          int subIndent = 0;
          for (size_t col = 0; col < subFirst; col++) {
            if (subLine[col] == '\t') subIndent += 4;
            else if (subLine[col] == ' ') subIndent += 1;
          }

          std::string subTrimmed = subLine.substr(subFirst);
          size_t subLast = subTrimmed.find_last_not_of(" \t\r\n");
          if (subLast != std::string::npos)
            subTrimmed = subTrimmed.substr(0, subLast + 1);

          std::string subLower = subTrimmed;
          for (char &ch : subLower)
            ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

          if (subLower.rfind("if", 0) == 0 &&
              (subLower.size() == 2 || std::isspace((unsigned char)subLower[2]) || subLower[2] == '(')) {
            ifDepth++;
          } else if (ifDepth > 0 && Parser::isIfTerm(subLower)) {
            ifDepth--;
          } else if (subLower.rfind("for", 0) == 0 &&
                     (subLower.size() == 3 || std::isspace((unsigned char)subLower[3]))) {
            forDepth++;
          } else if (forDepth > 0 && Parser::isForTerm(subLower)) {
            forDepth--;
          } else if (ifDepth == 0 && forDepth == 0) {
            if (subLower.rfind("while", 0) == 0 &&
                (subLower.size() == 5 || std::isspace((unsigned char)subLower[5]) || subLower[5] == '(')) {
              whileDepth++;
            } else if (Parser::isWhileTerm(subLower)) {
              if (whileDepth == 1 && subIndent != whileIndent) {
                std::cerr << "✖ Indentation Error: '" << subTrimmed << "' line (indentation " << subIndent
                          << ") is unaligned with matching 'while' line (indentation " << whileIndent << ")\n";
                evaluationSucceeded_ = false;
                return Value(0);
              }
              whileDepth--;
              if (whileDepth == 0) {
                i++;
                break;
              }
            }
          }
        }
        whileBodyLines.push_back(subLine);
        i++;
      }

      if (whileDepth > 0) {
        std::cerr << "✖ Syntax Error: unclosed 'while' statement (missing 'loop end', 'endwhile', 'end', or 'wend')\n";
        evaluationSucceeded_ = false;
        return Value(0);
      }

      std::string oldHeader = whileHeader_;
      std::string oldPending = pendingWhileBlock_;
      bool oldInWhile = inWhileBlock_;

      whileHeader_ = headerLine;
      pendingWhileBlock_.clear();
      for (const auto &wline : whileBodyLines) {
        pendingWhileBlock_ += wline + "\n";
      }

      executeWhileBlock();

      whileHeader_ = oldHeader;
      pendingWhileBlock_ = oldPending;
      inWhileBlock_ = oldInWhile;
      // Same reasoning as the FOR branch above — a lingering Return must
      // keep propagating past this while-loop, not stop here.
      if (loopSignal_ != LoopSignal::None) return Value(0);
      continue;
    }

    // Normal line execution
    Lexer bLex(line);
    auto bToks = bLex.tokenize();
    if (bToks.size() > 1) {
      setTokens(bToks);
      parse();
      if (loopSignal_ != LoopSignal::None) return Value(0);
    }
    i++;
  }

  return Value(0);
}
