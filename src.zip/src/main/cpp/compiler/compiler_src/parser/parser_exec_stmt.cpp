// Phase 3 Step 3 (AST rewrite roadmap): the tree-walking statement
// evaluator. Reuses every existing side-effecting primitive unchanged -
// memory, saveToFile(), callBuiltin/callUserFunction/callClassConstructor/
// callInstanceMethod, loopSignal_/loopDepth_ - only the driving mechanism
// changes: walking an already-built Stmt tree instead of re-lexing text and
// re-scanning for block boundaries on every iteration/call. Currently
// reachable via invokeFunctionBody() (parser_function.cpp) for a function/
// method body, and by anything that builds a Program via parseProgram()
// (parser_program.cpp) and calls executeProgram() directly - not yet
// ScriptManager itself (Step 4).
#include "parser.h"
#include "parser_internal.h"

#include <fstream>
#include <iostream>

#include "../builtins/builtins.h"
#include "../conditional_opr/conditional_opr.h"
#include "output.h"

namespace {

// Delegates to the one shared definition of "truthy" (conditional_opr.h's
// valueIsTruthy()) instead of carrying its own separate, divergent copy -
// this file's old private version (text: non-empty; anything else: number
// != 0) disagreed with and()/or()/not()/cond_if() et al., which read
// .number directly with no text/container handling at all: the same
// value was truthy here but falsy there. See valueIsTruthy()'s own
// comment for the full story and how it was confirmed.
bool truthy(const Value &v) {
  return valueIsTruthy(v);
}

std::string trimmed(const std::string &s) {
  size_t start = s.find_first_not_of(" \t\r\n");
  if (start == std::string::npos)
    return "";
  size_t end = s.find_last_not_of(" \t\r\n");
  return s.substr(start, end - start + 1);
}

// Step-into pause: called once per statement from executeStmtList() below
// when debugStepMode_ is on. Reports the statement just executed, then
// blocks on stdin for the Java IDE's next control line - "@cmd stepnext"
// resumes with pausing still on, "@cmd stepdone" resumes with pausing
// turned off for the rest of this run. Any other line is ignored and the
// wait repeats, so accidental stray input can't silently skip a pause.
void pauseForStep(Parser &parser, size_t line) {
  std::cout << "@STEPAT " << line << std::endl;
  std::string input;
  while (std::getline(std::cin, input)) {
    std::string cmd = trimmed(input);
    if (cmd.rfind("@cmd ", 0) == 0)
      cmd = trimmed(cmd.substr(5));
    if (cmd == "stepnext")
      return;
    if (cmd == "stepdone") {
      parser.setDebugStepMode(false);
      return;
    }
    // Unrecognized line while paused: ignore and keep waiting.
  }
}

// Deep-clones an Expr/Stmt subtree. Needed because FunctionDef::body must
// be independently owned (a function can be called long after, and many
// times more than, whatever Program the FunctionDecl Stmt was originally
// parsed as part of) - unique_ptr trees can't be shared, only moved or
// copied, and moving would corrupt the source Program for anyone still
// holding it (e.g. re-registering the same forward-declared function is
// harmless and expected; silently emptying the *source* tree while doing
// so would not be).
std::unique_ptr<Expr> cloneExpr(const Expr *src) {
  if (!src)
    return nullptr;
  auto dst = std::make_unique<Expr>();
  dst->kind = src->kind;
  dst->number = src->number;
  dst->text = src->text;
  for (const auto &c : src->children)
    dst->children.push_back(cloneExpr(c.get()));
  dst->rangeStart = cloneExpr(src->rangeStart.get());
  dst->rangeStop = cloneExpr(src->rangeStop.get());
  dst->rangeStep = cloneExpr(src->rangeStep.get());
  dst->slot = src->slot;
  return dst;
}

std::unique_ptr<Stmt> cloneStmt(const Stmt *src) {
  if (!src)
    return nullptr;
  auto dst = std::make_unique<Stmt>();
  dst->kind = src->kind;
  dst->line = src->line;
  dst->suppressOutput = src->suppressOutput;
  dst->expr = cloneExpr(src->expr.get());
  for (const auto &t : src->targets)
    dst->targets.push_back(cloneExpr(t.get()));
  dst->value = cloneExpr(src->value.get());
  dst->condition = cloneExpr(src->condition.get());
  dst->loopVar = src->loopVar;
  dst->loopVarSlot = src->loopVarSlot;
  dst->iterable = cloneExpr(src->iterable.get());
  for (const auto &s : src->body)
    dst->body.push_back(cloneStmt(s.get()));
  for (const auto &branch : src->elseifBranches) {
    std::vector<std::unique_ptr<Stmt>> body;
    for (const auto &s : branch.second)
      body.push_back(cloneStmt(s.get()));
    dst->elseifBranches.emplace_back(cloneExpr(branch.first.get()), std::move(body));
  }
  for (const auto &s : src->elseBody)
    dst->elseBody.push_back(cloneStmt(s.get()));
  dst->conditionText = src->conditionText;
  dst->name = src->name;
  dst->inputNames = src->inputNames;
  dst->outputNames = src->outputNames;
  dst->parentClassName = src->parentClassName;
  dst->isAbstract = src->isAbstract;
  dst->isReversible = src->isReversible;
  dst->hasRate = src->hasRate;
  dst->rateHz = src->rateHz;
  dst->restrictedFields = src->restrictedFields;
  for (const auto &m : src->methods)
    dst->methods.push_back(cloneStmt(m.get()));
  for (const auto &p : src->publishArgs)
    dst->publishArgs.push_back(cloneExpr(p.get()));
  return dst;
}

} // namespace

/* ================= PROGRAM / FORWARD REFERENCES ================= */

void Parser::registerFunctionDeclStmt(const Stmt &stmt) {
  FunctionDef def;
  def.inputNames = stmt.inputNames;
  def.outputNames = stmt.outputNames;
  for (const auto &bodyStmt : stmt.body)
    def.body.push_back(cloneStmt(bodyStmt.get()));
  resolveFunctionSlots(def, /*hasBase=*/false);
  registerOverload(functionTable_, stmt.name, std::move(def));
}

void Parser::registerClassDeclStmt(const Stmt &stmt) {
  // A malformed method header (or a non-abstract class with an unimplemented
  // method) aborted this class's parse partway through - see
  // parseClassDeclNode(). The old executeClassDefEnd() never adds such a
  // class to classTable_ either, so later uses correctly see "Unknown
  // function/class" rather than a half-registered class.
  if (stmt.classRegistrationFailed)
    return;

  ClassDef def;
  def.parentClassName = stmt.parentClassName;
  def.isAbstract = stmt.isAbstract;
  def.isReversible = stmt.isReversible;
  def.hasRate = stmt.hasRate;
  def.rateHz = stmt.rateHz;
  def.restrictedFields = stmt.restrictedFields;

  for (const auto &methodStmt : stmt.methods) {
    FunctionDef methodDef;
    methodDef.inputNames = methodStmt->inputNames;
    methodDef.outputNames = methodStmt->outputNames;
    for (const auto &bodyStmt : methodStmt->body)
      methodDef.body.push_back(cloneStmt(bodyStmt.get()));
    resolveFunctionSlots(methodDef, /*hasBase=*/true);
    registerOverload(def.methods, methodStmt->name, std::move(methodDef));
  }

  classTable_[stmt.name] = std::move(def);
}

void Parser::registerTopLevelDecls(const Program &program) {
  // Register every top-level function/class definition, so a call can
  // forward-reference one whose declaration appears later in the file -
  // matches ScriptManager's own pre-scan today (SM_stage_02.cpp), but over
  // an already-parsed tree instead of re-lexing raw lines.
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl)
      registerFunctionDeclStmt(*stmt);
    else if (stmt->kind == StmtKind::ClassDecl)
      registerClassDeclStmt(*stmt);
  }
}

void Parser::executeProgram(const Program &program) {
  // Pass 1: see registerTopLevelDecls() above.
  registerTopLevelDecls(program);

  // Pass 2: execute everything else, in order. FunctionDecl/ClassDecl are
  // skipped here - already registered above, and re-registering from the
  // same statement a second time would just be redundant work.
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl || stmt->kind == StmtKind::ClassDecl)
      continue;
    executeStmt(stmt.get());
    if (loopSignal_ != LoopSignal::None) {
      // A top-level `return;` (or a failed require/ensure) stops the rest
      // of the script - matches consumeTopLevelStopSignal()'s caller sites
      // in SM_stage_02.cpp/main.cpp today.
      loopSignal_ = LoopSignal::None;
      break;
    }
  }
}

/* ================= STATEMENT LIST ================= */

void Parser::executeStmtList(const std::vector<std::unique_ptr<Stmt>> &stmts) {
  for (const auto &stmt : stmts) {
    executeStmt(stmt.get());
    if (debugStepMode_)
      pauseForStep(*this, stmt->line);
    if (loopSignal_ != LoopSignal::None)
      return; // break/continue/return - stop processing the rest of this list
  }
}

/* ================= STATEMENT DISPATCH ================= */

void Parser::executeStmt(const Stmt *stmt) {
  if (!stmt)
    return;

  // MATLAB-style gating for ans auto-display/update - matches
  // parseStatement()'s own reset at the top of every statement.
  evaluationSucceeded_ = true;

  switch (stmt->kind) {
    case StmtKind::ExprStmt: {
      Value v = evaluateExpr(stmt->expr.get());
      if (evaluationSucceeded_) {
        setAns(v);
        if (!stmt->suppressOutput)
          printValue("", v);
      }
      return;
    }

    case StmtKind::Assign:
      executeAssignStmt(stmt);
      return;

    case StmtKind::If: {
      if (truthy(evaluateExpr(stmt->condition.get()))) {
        executeStmtList(stmt->body);
        return;
      }
      for (const auto &branch : stmt->elseifBranches) {
        if (truthy(evaluateExpr(branch.first.get()))) {
          executeStmtList(branch.second);
          return;
        }
      }
      executeStmtList(stmt->elseBody);
      return;
    }

    case StmtKind::For: {
      Value iterableVal = evaluateExpr(stmt->iterable.get());
      loopDepth_++;
      {
        PersistenceSuppressor guard(*this);
        if (iterableVal.isArray) {
          for (const Value &elem : iterableVal.elems()) {
            varSet(stmt->loopVarSlot, stmt->loopVar, elem);
            executeStmtList(stmt->body);
            if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
            if (loopSignal_ == LoopSignal::Return) break; // propagate past the loop
            if (loopSignal_ == LoopSignal::Continue) loopSignal_ = LoopSignal::None;
          }
        } else {
          // Single value treated as 1-element iteration (matches Form A's
          // "for x in <non-array>" fallback today).
          varSet(stmt->loopVarSlot, stmt->loopVar, iterableVal);
          executeStmtList(stmt->body);
          if (loopSignal_ == LoopSignal::Break || loopSignal_ == LoopSignal::Continue)
            loopSignal_ = LoopSignal::None;
        }
      }
      loopDepth_--;
      saveToFile();
      return;
    }

    case StmtKind::While: {
      int iterationCount = 0;
      const int MAX_ITERATIONS = kMaxWhileIterations; // shared with the JIT path (ast.h)
      loopDepth_++;
      {
        PersistenceSuppressor guard(*this);
        while (truthy(evaluateExpr(stmt->condition.get()))) {
          iterationCount++;
          if (iterationCount > MAX_ITERATIONS) {
            std::cerr << whileLimitErrorText();
            evaluationSucceeded_ = false;
            break;
          }
          executeStmtList(stmt->body);
          if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
          if (loopSignal_ == LoopSignal::Return) break;
          if (loopSignal_ == LoopSignal::Continue) loopSignal_ = LoopSignal::None;
        }
      }
      loopDepth_--;
      saveToFile();
      return;
    }

    case StmtKind::Break:
    case StmtKind::Continue: {
      bool isBreak = (stmt->kind == StmtKind::Break);
      if (loopDepth_ <= 0) {
        std::cerr << "Error: '" << (isBreak ? "break" : "continue")
                  << "' used outside of a loop\n";
        evaluationSucceeded_ = false;
      } else {
        loopSignal_ = isBreak ? LoopSignal::Break : LoopSignal::Continue;
      }
      return;
    }

    case StmtKind::Return:
      loopSignal_ = LoopSignal::Return;
      return;

    case StmtKind::Require:
    case StmtKind::Ensure: {
      bool isRequire = (stmt->kind == StmtKind::Require);
      Value cond = evaluateExpr(stmt->condition.get());
      if (!evaluationSucceeded_)
        return; // condition itself failed to evaluate - not a genuine violation
      if (!truthy(cond)) {
        std::cerr << "Error: " << (isRequire ? "precondition" : "postcondition")
                  << " failed: " << stmt->conditionText << "\n";
        evaluationSucceeded_ = false;
        loopSignal_ = LoopSignal::Return;
      }
      return;
    }

    case StmtKind::FunctionDecl:
      registerFunctionDeclStmt(*stmt);
      return;

    case StmtKind::ClassDecl:
      registerClassDeclStmt(*stmt);
      return;

    case StmtKind::Publish: {
      std::vector<Value> vals;
      for (const auto &argExpr : stmt->publishArgs)
        vals.push_back(evaluateExpr(argExpr.get()));

      if (evaluationSucceeded_) {
        for (size_t i = 0; i < vals.size(); i++) {
          const Value &v = vals[i];
          if (v.isText)
            std::cout << v.text();
          else
            std::cout << valueToString(v);
          if (i + 1 < vals.size())
            std::cout << " ";
        }
        std::cout << std::endl;
      }
      // print/publish always display output and never update `ans`.
      return;
    }

    case StmtKind::ClearMemory: {
      clearMemoryAndPersist();
      return;
    }
  }
}

void Parser::clearMemoryAndPersist() {
  memory.clear();
  insertionOrder.clear();
  std::ofstream file("variables.txt", std::ios::trunc);
  file << "NAME        TYPE        VALUE\n";
  file << "-----------------------------------------\n";
}

/* ================= ASSIGNMENT ================= */

void Parser::executeAssignStmt(const Stmt *stmt) {
  // Multi-output call: (A,B) = f(...)
  if (stmt->targets.size() >= 2) {
    const Expr *call = stmt->value.get();
    std::vector<Value> args;
    for (const auto &a : call->children)
      args.push_back(evaluateExpr(a.get()));

    bool found = false;
    std::vector<Value> results =
        callUserFunctionMulti(call->text, args, stmt->targets.size(), found);
    if (!found) {
      std::cerr << "Error: Unknown function '" << call->text << "'\n";
      evaluationSucceeded_ = false;
      return;
    }

    if (evaluationSucceeded_) {
      // Multi-output targets are never resolved to a slot (see
      // resolveFunctionSlots()'s Pass A / FunctionDef::inputSlots' comment
      // for why) - varSet(-1, ...) is exactly the old memory[name]=...
      // path, kept as a var*() call purely for uniformity/auditability.
      for (size_t k = 0; k < stmt->targets.size() && k < results.size(); k++)
        varSet(stmt->targets[k]->slot, stmt->targets[k]->text, results[k]);
      saveToFile();

      if (!stmt->suppressOutput) {
        for (size_t k = 0; k < stmt->targets.size() && k < results.size(); k++)
          printValue(stmt->targets[k]->text, results[k]);
      }
    }
    return;
  }

  const Expr *target = stmt->targets[0].get();
  Value val = evaluateExpr(stmt->value.get());
  if (!evaluationSucceeded_)
    return;

  switch (target->kind) {
    case ExprKind::Identifier: {
      const std::string &name = target->text;
      varSet(target->slot, name, val);
      saveToFile();
      setAns(val);

      if (!stmt->suppressOutput)
        printValue(name, val);
      return;
    }

    case ExprKind::FieldAccess: {
      const Expr *baseNode = target->children[0].get(); // always a bare identifier
      const std::string &name = baseNode->text;
      const std::string &fieldName = target->text;

      if (!varExists(baseNode->slot, name)) {
        std::cerr << "Error: '" << name << "' is not defined\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (!varGet(baseNode->slot, name).isObject) {
        std::cerr << "Error: '" << name << "' is not an object\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (checkFieldAccess(varGet(baseNode->slot, name).className(), fieldName)) {
        varRef(baseNode->slot, name).dictMut()[fieldName] = val;
        setAns(val);

        if (!stmt->suppressOutput)
          printValue(name, val);
      }
      return;
    }

    case ExprKind::Index:
      executeIndexAssign(target, val, stmt->suppressOutput);
      return;

    default:
      // Not a shape parser_program.cpp's assignment parsing ever builds -
      // defensive only.
      evaluationSucceeded_ = false;
      return;
  }
}

void Parser::executeIndexAssign(const Expr *target, const Value &val, bool suppressOutput) {
  const Expr *base = target->children[0].get();

  /* A[row][col] = value - nested Index (one node per bracket group). */
  if (base->kind == ExprKind::Index) {
    const Expr *innerBase = base->children[0].get();
    const std::string &name = innerBase->text;
    int slot = innerBase->slot;

    if (!varExists(slot, name) || !varGet(slot, name).isMatrix) {
      // The original grammar could only reach its matrix-element-assign
      // branch when the receiver was *already* known to be a matrix (a
      // parse-time check - see parser_factor.cpp's header comment on why
      // that's no longer possible in general). A non-matrix receiver here
      // is therefore a case the original grammar never actually assigned
      // a defined meaning to; failing cleanly is preferable to guessing.
      std::cerr << "Error: '" << name << "' is not a matrix\n";
      evaluationSucceeded_ = false;
      return;
    }

    Value rowVal = evaluateExpr(base->children[1].get());
    Value colVal = evaluateExpr(target->children[1].get());
    int row = static_cast<int>(rowVal.number);
    int col = static_cast<int>(colVal.number);

    if (row < 0 || static_cast<size_t>(row) >= varGet(slot, name).rows() ||
        col < 0 || static_cast<size_t>(col) >= varGet(slot, name).rowLength(row)) {
      std::cerr << "Error: matrix index out of range for '" << name << "'\n";
      evaluationSucceeded_ = false;
      return;
    }

    varRef(slot, name).setAt(row, col, val);
    saveToFile();
    setAns(val);

    // Auto-print (no trailing ';') shows the whole updated matrix, not just
    // the assigned element.
    if (!suppressOutput)
      printValue(name, varGet(slot, name));
    return;
  }

  /* A[key1(,key2,...)] = value - matrix element/row/column slice, array
     element, or dict key(s). */
  const std::string &name = base->text;
  int slot = base->slot;
  size_t numKeys = target->children.size() - 1;

  /* A[row,col] / A[n,:] / A[:,n] = value - matrix comma form. Checked
     ahead of the generic key-evaluation loop below because a Wildcard
     (':') key has no evaluateExpr() case - it's only meaningful here,
     inspected directly on the Expr node rather than evaluated to a Value. */
  if (numKeys == 2 && varExists(slot, name) && varGet(slot, name).isMatrix) {
    const Expr *k0 = target->children[1].get();
    const Expr *k1 = target->children[2].get();
    bool wildRow = (k0->kind == ExprKind::Wildcard);
    bool wildCol = (k1->kind == ExprKind::Wildcard);

    if (wildRow && wildCol) {
      std::cerr << "Error: matrix '" << name
                << "' assignment needs at least one concrete index (A[:,:] is not supported)\n";
      evaluationSucceeded_ = false;
      return;
    }

    Value &mat = varRef(slot, name);
    size_t nrows = mat.rows();
    size_t ncols = nrows ? mat.cols() : 0;

    if (wildCol) {
      /* A[row,:] = value - replace the whole row. */
      Value rowVal = evaluateExpr(k0);
      int row = static_cast<int>(rowVal.number);
      if (row < 0 || static_cast<size_t>(row) >= nrows) {
        std::cerr << "Error: matrix row out of range for '" << name << "'\n";
        evaluationSucceeded_ = false;
        return;
      }

      std::vector<Value> rowVec;
      if (val.isArray && val.length() == ncols)
        rowVec = val.elems();
      else if (val.isMatrix && val.rows() == 1 && val.cols() == ncols)
        rowVec = val.row(0);
      else {
        std::cerr << "Error: row assignment for '" << name
                  << "' expects an array or 1-row matrix of length " << ncols << "\n";
        evaluationSucceeded_ = false;
        return;
      }

      mat.setRow(row, rowVec);
      saveToFile();
      setAns(val);
      if (!suppressOutput)
        printValue(name, varGet(slot, name));
      return;
    }

    if (wildRow) {
      /* A[:,col] = value - replace the whole column. */
      Value colVal = evaluateExpr(k1);
      int col = static_cast<int>(colVal.number);
      if (col < 0 || static_cast<size_t>(col) >= ncols) {
        std::cerr << "Error: matrix column out of range for '" << name << "'\n";
        evaluationSucceeded_ = false;
        return;
      }

      std::vector<Value> colVec;
      if (val.isArray && val.length() == nrows) {
        colVec = val.elems();
      } else if (val.isMatrix && val.rows() == nrows &&
                 val.rows() != 0 && val.cols() == 1) {
        for (size_t r = 0; r < val.rows(); r++)
          colVec.push_back(val.at(r, 0));
      } else {
        std::cerr << "Error: column assignment for '" << name << "' expects an array or "
                  << nrows << "x1 matrix\n";
        evaluationSucceeded_ = false;
        return;
      }

      for (size_t r = 0; r < nrows; r++)
        mat.setAt(r, col, colVec[r]);
      saveToFile();
      setAns(val);
      if (!suppressOutput)
        printValue(name, varGet(slot, name));
      return;
    }

    /* A[row,col] = value - single element (comma form; same result as the
       nested A[row][col] form above). */
    Value rowVal = evaluateExpr(k0);
    Value colVal = evaluateExpr(k1);
    int row = static_cast<int>(rowVal.number);
    int col = static_cast<int>(colVal.number);
    if (row < 0 || static_cast<size_t>(row) >= nrows ||
        col < 0 || static_cast<size_t>(col) >= mat.rowLength(row)) {
      std::cerr << "Error: matrix index out of range for '" << name << "'\n";
      evaluationSucceeded_ = false;
      return;
    }

    mat.setAt(row, col, val);
    saveToFile();
    setAns(val);
    if (!suppressOutput)
      printValue(name, varGet(slot, name));
    return;
  }

  std::vector<Value> keys;
  for (size_t i = 1; i < target->children.size(); i++)
    keys.push_back(evaluateExpr(target->children[i].get()));

  if (varExists(slot, name) && varGet(slot, name).isArray && keys.size() == 1) {
    int idx = static_cast<int>(keys[0].number);
    if (idx < 0 || static_cast<size_t>(idx) >= varGet(slot, name).length()) {
      std::cerr << "Error: array index out of range for '" << name << "'\n";
      evaluationSucceeded_ = false;
      return;
    }
    varRef(slot, name).setAt(idx, val);
    saveToFile();
    setAns(val);

    // Same "print the whole container" reasoning as the matrix case above.
    if (!suppressOutput)
      printValue(name, varGet(slot, name));
    return;
  }

  if (!varExists(slot, name)) {
    varSet(slot, name, Value(std::unordered_map<std::string, Value>()));
  } else if (!varGet(slot, name).isDict) {
    std::cerr << "Error: '" << name << "' is not a dict\n";
    evaluationSucceeded_ = false;
    return;
  }

  if (keys.size() == 1) {
    varRef(slot, name).dictMut()[dictKeyOf(keys[0])] = val;
  } else {
    if (!val.isArray || val.length() != keys.size()) {
      std::cerr << "Error: multi-key dict assignment expects an array of " << keys.size()
                << " values\n";
      evaluationSucceeded_ = false;
      return;
    }
    for (size_t i = 0; i < keys.size(); i++)
      varRef(slot, name).dictMut()[dictKeyOf(keys[i])] = val.at(i);
  }

  saveToFile();
  setAns(val);

  if (!suppressOutput)
    printValue(name, val);
}
