// Phase 3 Step 3 (AST rewrite roadmap): the tree-walking statement
// evaluator. Reuses every existing side-effecting primitive unchanged -
// memory, callBuiltin/callUserFunction/callClassConstructor/
// callInstanceMethod, loopSignal_/loopDepth_ - only the driving mechanism
// changes: walking an already-built Stmt tree instead of re-lexing text and
// re-scanning for block boundaries on every iteration/call. Currently
// reachable via invokeFunctionBody() (parser_function.cpp) for a function/
// method body, and by anything that builds a Program via parseProgram()
// (parser_program.cpp) and calls executeProgram() directly - not yet
// ScriptManager itself (Step 4).
#include "parser.h"
#include "parser_internal.h"

#include <iostream>

#include "../builtins/builtins.h"
#include "../conditional_opr/conditional_opr.h"
#include "../../../runtime/data/DataEngine.h"
#include "../../../runtime/execution/Interrupt.h"
#include "../../../runtime/execution/analysis/analysis.h"
#include "output.h"
#include "../core/elementwise.h"
#include "../ops/dc/dc.h"
#include "../ops/geometric/geometric.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/plot/plot_builtin.h"
#include "../ops/statistics/statistics.h"
#include "../ops/vector/vector.h"

namespace {

// Delegates to the one shared definition of "truthy" (conditional_opr.h's
// valueIsTruthy()) instead of carrying its own separate, divergent copy -
// this file's old private version (text: non-empty; anything else: number
// != 0) disagreed with and()/or()/not()/cond_if() et al., which read
// .number directly with no text/container handling at all: the same
// value was truthy here but falsy there. See valueIsTruthy()'s own
// comment for the full story and how it was confirmed.
bool truthy(const Value &v) {
  return valueIsTruthy(v);
}

std::string trimmed(const std::string &s) {
  size_t start = s.find_first_not_of(" \t\r\n");
  if (start == std::string::npos)
    return "";
  size_t end = s.find_last_not_of(" \t\r\n");
  return s.substr(start, end - start + 1);
}

// Step-into pause: called once per statement from executeStmtList() below
// when debugStepMode_ is on. Reports the statement just executed, then
// blocks on stdin for the Java IDE's next control line - "@cmd stepnext"
// resumes with pausing still on, "@cmd stepdone" resumes with pausing
// turned off for the rest of this run. Any other line is ignored and the
// wait repeats, so accidental stray input can't silently skip a pause.
void pauseForStep(Parser &parser, size_t line) {
  // The IDE's variable list follows the step: send the global workspace
  // (only if it changed) before announcing the pause.
  ncdata::DataEngine::instance().emitWorkspaceIfChanged(parser.globalMemory(),
                                                        parser.globalInsertionOrder());
  std::cout << "@STEPAT " << line << std::endl;
  std::string input;
  while (std::getline(std::cin, input)) {
    std::string cmd = trimmed(input);
    if (cmd.rfind("@cmd ", 0) == 0)
      cmd = trimmed(cmd.substr(5));
    if (cmd == "stepnext") {
      // Stop pressed while paused: the IDE raises the interrupt flag and
      // then releases the pause; look for the flag right away.
      nc::Interrupt::pollNow();
      return;
    }
    if (cmd == "stepdone") {
      parser.setDebugStepMode(false);
      nc::Interrupt::pollNow();
      return;
    }
    // Unrecognized line while paused: ignore and keep waiting.
  }
}

// Deep-clones an Expr/Stmt subtree. Needed because FunctionDef::body must
// be independently owned (a function can be called long after, and many
// times more than, whatever Program the FunctionDecl Stmt was originally
// parsed as part of) - unique_ptr trees can't be shared, only moved or
// copied, and moving would corrupt the source Program for anyone still
// holding it (e.g. re-registering the same forward-declared function is
// harmless and expected; silently emptying the *source* tree while doing
// so would not be).
std::unique_ptr<Expr> cloneExpr(const Expr *src) {
  if (!src)
    return nullptr;
  auto dst = std::make_unique<Expr>();
  dst->kind = src->kind;
  dst->number = src->number;
  dst->text = src->text;
  // Literal flags: without these a cloned `3i` became the real 3 and a
  // cloned `true` became the float64 1.
  dst->imaginary = src->imaginary;
  dst->isBool = src->isBool;
  dst->sepLevels = src->sepLevels; // N-D matrix literal separators
  for (const auto &c : src->children)
    dst->children.push_back(cloneExpr(c.get()));
  dst->rangeStart = cloneExpr(src->rangeStart.get());
  dst->rangeStop = cloneExpr(src->rangeStop.get());
  dst->rangeStep = cloneExpr(src->rangeStep.get());
  dst->argNames = src->argNames; // named arguments: Add(x1=10, ...)
  dst->slot = src->slot;
  return dst;
}

std::unique_ptr<Stmt> cloneStmt(const Stmt *src) {
  if (!src)
    return nullptr;
  auto dst = std::make_unique<Stmt>();
  dst->kind = src->kind;
  dst->line = src->line;
  dst->suppressOutput = src->suppressOutput;
  dst->expr = cloneExpr(src->expr.get());
  for (const auto &t : src->targets)
    dst->targets.push_back(cloneExpr(t.get()));
  dst->value = cloneExpr(src->value.get());
  dst->targetRows = src->targetRows;
  dst->extendDir = src->extendDir;
  dst->condition = cloneExpr(src->condition.get());
  dst->loopVar = src->loopVar;
  dst->loopVarSlot = src->loopVarSlot;
  dst->iterable = cloneExpr(src->iterable.get());
  for (const auto &s : src->body)
    dst->body.push_back(cloneStmt(s.get()));
  for (const auto &branch : src->elseifBranches) {
    std::vector<std::unique_ptr<Stmt>> body;
    for (const auto &s : branch.second)
      body.push_back(cloneStmt(s.get()));
    dst->elseifBranches.emplace_back(cloneExpr(branch.first.get()), std::move(body));
  }
  for (const auto &s : src->elseBody)
    dst->elseBody.push_back(cloneStmt(s.get()));
  dst->conditionText = src->conditionText;
  dst->contractMessage = src->contractMessage;
  dst->name = src->name;
  dst->inputNames = src->inputNames;
  for (const auto &d : src->inputDefaults) // default values: F(a, b=2)
    dst->inputDefaults.push_back(cloneExpr(d.get()));
  dst->inputDefaultTexts = src->inputDefaultTexts;
  dst->outputNames = src->outputNames;
  dst->parentClassName = src->parentClassName;
  dst->isAbstract = src->isAbstract;
  dst->isReversible = src->isReversible;
  dst->hasRate = src->hasRate;
  dst->rateHz = src->rateHz;
  dst->restrictedFields = src->restrictedFields;
  for (const auto &m : src->methods)
    dst->methods.push_back(cloneStmt(m.get()));
  for (const auto &p : src->publishArgs)
    dst->publishArgs.push_back(cloneExpr(p.get()));
  return dst;
}

// Default values (F(a, b=2)) go with the FunctionDef: a deep copy of each,
// and its source text. Left empty when the header has none.
void copyDefaults(const Stmt &decl, Parser::FunctionDef &def) {
  def.inputDefaults.clear();
  def.inputDefaultTexts.clear();
  if (!decl.hasDefaults())
    return;
  for (const auto &d : decl.inputDefaults)
    def.inputDefaults.push_back(cloneExpr(d.get()));
  def.inputDefaultTexts = decl.inputDefaultTexts;
}

} // namespace

std::unique_ptr<Expr> cloneExprTree(const Expr *src) { return cloneExpr(src); }

/* ================= PROGRAM / FORWARD REFERENCES ================= */

void Parser::registerFunctionDeclStmt(const Stmt &stmt) {
  FunctionDef def;
  def.inputNames = stmt.inputNames;
  def.outputNames = stmt.outputNames;
  copyDefaults(stmt, def);
  for (const auto &bodyStmt : stmt.body)
    def.body.push_back(cloneStmt(bodyStmt.get()));
  resolveFunctionSlots(def, /*hasBase=*/false);
  registerOverload(functionTable_, stmt.name, std::move(def));
}

void Parser::registerClassDeclStmt(const Stmt &stmt) {
  // A malformed method header (or a non-abstract class with an unimplemented
  // method) aborted this class's parse partway through - see
  // parseClassDeclNode(). The old executeClassDefEnd() never adds such a
  // class to classTable_ either, so later uses correctly see "Unknown
  // function/class" rather than a half-registered class.
  if (stmt.classRegistrationFailed)
    return;

  ClassDef def;
  def.parentClassName = stmt.parentClassName;
  def.isAbstract = stmt.isAbstract;
  def.isReversible = stmt.isReversible;
  def.hasRate = stmt.hasRate;
  def.rateHz = stmt.rateHz;
  def.restrictedFields = stmt.restrictedFields;

  for (const auto &methodStmt : stmt.methods) {
    FunctionDef methodDef;
    methodDef.inputNames = methodStmt->inputNames;
    methodDef.outputNames = methodStmt->outputNames;
    copyDefaults(*methodStmt, methodDef);
    for (const auto &bodyStmt : methodStmt->body)
      methodDef.body.push_back(cloneStmt(bodyStmt.get()));
    resolveFunctionSlots(methodDef, /*hasBase=*/true);
    if (!def.methods.count(methodStmt->name))
      def.methodOrder.push_back(methodStmt->name); // declaration order, for .info
    registerOverload(def.methods, methodStmt->name, std::move(methodDef));
  }

  classTable_[stmt.name] = std::move(def);
}

void Parser::registerTopLevelDecls(const Program &program) {
  // Register every top-level function/class definition, so a call can
  // forward-reference one whose declaration appears later in the file -
  // matches ScriptManager's own pre-scan today (SM_stage_02.cpp), but over
  // an already-parsed tree instead of re-lexing raw lines.
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl)
      registerFunctionDeclStmt(*stmt);
    else if (stmt->kind == StmtKind::ClassDecl)
      registerClassDeclStmt(*stmt);
  }
}

void Parser::executeProgram(const Program &program) {
  // Pass 1: see registerTopLevelDecls() above.
  registerTopLevelDecls(program);

  // Pass 2: execute everything else, in order. FunctionDecl/ClassDecl are
  // skipped here - already registered above, and re-registering from the
  // same statement a second time would just be redundant work.
  clearErrorAbort();
  // The IDE's Analysis box: the statements of the OUTERMOST script are its
  // history and its progress in statements (a script run from a script
  // counts inside the statement that ran it).
  static int programDepth = 0;
  struct DepthGuard {
    DepthGuard() { programDepth++; }
    ~DepthGuard() { programDepth--; }
  } depthGuard;
  const int analysisLevel = programDepth == 1 ? 1 : -1;
  size_t executable = 0;
  for (const auto &stmt : program.statements)
    if (stmt->kind != StmtKind::FunctionDecl && stmt->kind != StmtKind::ClassDecl)
      executable++;
  size_t position = 0;
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl || stmt->kind == StmtKind::ClassDecl)
      continue;
    if (nc::Interrupt::poll())
      break; // Stop pressed - reported once by the REPL
    const unsigned long errorsBefore = nc::errorlines::count();
    nc::analysis::TopLevelScope analysisScope(analysisLevel, static_cast<int>(stmt->line),
                                              stmtKindName(stmt->kind), position++, executable);
    executeStmt(stmt.get());
    noteStatementResult(stmt->line, errorsBefore);
    if (errorAbort_) {
      // An error stops the script (see errorAbort_). The error itself has
      // been printed; say where the script stopped.
      if (errorLine_ > 0)
        std::cerr << "✖ Runtime Error (line " << errorLine_
                  << "): the script stopped here because of the error above\n";
      loopSignal_ = LoopSignal::None;
      clearErrorAbort();
      break;
    }
    if (loopSignal_ != LoopSignal::None) {
      // A top-level `return;` (or a failed require/ensure) stops the rest
      // of the script - matches consumeTopLevelStopSignal()'s caller sites
      // in SM_stage_02.cpp/main.cpp today.
      loopSignal_ = LoopSignal::None;
      break;
    }
  }
}

/* ================= STATEMENT LIST ================= */

void Parser::executeStmtList(const std::vector<std::unique_ptr<Stmt>> &stmts) {
  for (const auto &stmt : stmts) {
    // Stop pressed in the IDE: unwind like a `return;` at every level - a
    // loop around this list breaks on Return, and invokeFunctionBody()
    // fails the call. The request stays set (nc::Interrupt is sticky), so
    // each enclosing statement list stops in turn.
    if (nc::Interrupt::poll()) {
      loopSignal_ = LoopSignal::Return;
      return;
    }
    const unsigned long errorsBefore = nc::errorlines::count();
    executeStmt(stmt.get());
    noteStatementResult(stmt->line, errorsBefore); // an error unwinds like a return
    if (debugStepMode_ && !errorAbort_)
      pauseForStep(*this, stmt->line);
    if (loopSignal_ != LoopSignal::None)
      return; // break/continue/return - stop processing the rest of this list
  }
}

/* ================= STATEMENT DISPATCH ================= */

void Parser::executeStmt(const Stmt *stmt) {
  bindScipyCallbacks();
  if (!stmt)
    return;
  nc::analysis::statement(); // the IDE's statement count (one bool test when off)

  // MATLAB-style gating for ans auto-display/update - matches
  // parseStatement()'s own reset at the top of every statement.
  evaluationSucceeded_ = true;

  switch (stmt->kind) {
    case StmtKind::ExprStmt: {
      // ClassName.info typed on its own is shown as a table, not a dict.
      bool isClassInfo = false;
      Value v;
      if (!stmt->expr || !tryClassIntrospection(stmt->expr.get(), v, isClassInfo))
        v = evaluateExpr(stmt->expr.get());
      // save_workspace()/load_workspace() print their own one-line report;
      // their `true` result is neither echoed nor stored in `ans`.
      if (stmt->expr && stmt->expr->kind == ExprKind::Call &&
          ncdata::DataEngine::isWorkspaceCommand(stmt->expr->text))
        return;
      if (evaluationSucceeded_) {
        setAns(v);
        // An unassigned result is shown as `ans`, MATLAB style:
        //   >> 3 + 4
        //
        //   ans =
        //
        //       7
        //
        if (!stmt->suppressOutput) {
          if (isClassInfo)
            printClassInfo(stmt->expr->children[0]->text + ".info", v);
          else
            printValue("ans", v);
        }
      }
      return;
    }

    case StmtKind::Assign:
      executeAssignStmt(stmt);
      return;

    case StmtKind::If: {
      // A condition that fails to evaluate is an error, not "false": it
      // must not fall through to the elseif/else branches.
      const bool ifTrue = truthy(evaluateExpr(stmt->condition.get()));
      if (!evaluationSucceeded_)
        return;
      if (ifTrue) {
        executeStmtList(stmt->body);
        return;
      }
      for (const auto &branch : stmt->elseifBranches) {
        const bool branchTrue = truthy(evaluateExpr(branch.first.get()));
        if (!evaluationSucceeded_)
          return;
        if (branchTrue) {
          executeStmtList(branch.second);
          return;
        }
      }
      executeStmtList(stmt->elseBody);
      return;
    }

    case StmtKind::For: {
      Value iterableVal = evaluateExpr(stmt->iterable.get());
      if (!evaluationSucceeded_)
        return;
      // A vector ([1,2,3], [1:5], a column) runs once per element; any
      // other matrix runs once per row (each a 1xN matrix), matching A[m];
      // an N-D matrix once per slab along its first axis (B[m] again).
      if (iterableVal.isND()) {
        std::vector<Value> items;
        for (size_t m = 0; m < iterableVal.ndShape()[0]; m++) {
          std::vector<MatIndexKey> slabKey(1);
          slabKey[0].kind = MatIndexKey::Scalar;
          slabKey[0].scalar = static_cast<double>(m);
          Value slab;
          std::string err;
          matIndexGet(iterableVal, slabKey, stmt->loopVar, slab, err);
          items.push_back(slab);
        }
        iterableVal = Value(std::move(items));
      } else if (iterableVal.isMatrix) {
        std::vector<Value> items;
        if (matIsVectorShape(iterableVal)) {
          items = matVectorAsArray(iterableVal).elems();
        } else {
          for (size_t r = 0; r < iterableVal.rows(); r++) {
            std::vector<MatIndexKey> rowKey(1);
            rowKey[0].kind = MatIndexKey::Scalar;
            rowKey[0].scalar = static_cast<double>(r);
            Value rowVal;
            std::string err;
            matIndexGet(iterableVal, rowKey, stmt->loopVar, rowVal, err);
            items.push_back(rowVal);
          }
        }
        iterableVal = Value(std::move(items));
      }
      loopDepth_++;
      {
        // Progress and order of growth for the IDE (analysis.h): a for
        // loop knows its iteration count up front.
        nc::analysis::LoopScope analysisLoop(
            static_cast<int>(stmt->line), true,
            iterableVal.isArray ? static_cast<int64_t>(iterableVal.length()) : 1);
        if (iterableVal.isArray) {
          for (const Value &elem : iterableVal.elems()) {
            analysisLoop.iteration();
            varSet(stmt->loopVarSlot, stmt->loopVar, elem);
            executeStmtList(stmt->body);
            if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
            if (loopSignal_ == LoopSignal::Return) break; // propagate past the loop
            if (loopSignal_ == LoopSignal::Continue) loopSignal_ = LoopSignal::None;
          }
        } else {
          // Single value treated as 1-element iteration (matches Form A's
          // "for x in <non-array>" fallback today).
          analysisLoop.iteration();
          varSet(stmt->loopVarSlot, stmt->loopVar, iterableVal);
          executeStmtList(stmt->body);
          if (loopSignal_ == LoopSignal::Break || loopSignal_ == LoopSignal::Continue)
            loopSignal_ = LoopSignal::None;
        }
      }
      loopDepth_--;
      return;
    }

    case StmtKind::While: {
      int iterationCount = 0;
      const int MAX_ITERATIONS = kMaxWhileIterations; // shared with the JIT path (ast.h)
      loopDepth_++;
      {
        nc::analysis::LoopScope analysisLoop(static_cast<int>(stmt->line), false, -1);
        while (truthy(evaluateExpr(stmt->condition.get())) && evaluationSucceeded_) {
          analysisLoop.iteration();
          iterationCount++;
          if (iterationCount > MAX_ITERATIONS) {
            std::cerr << whileLimitErrorText();
            evaluationSucceeded_ = false;
            break;
          }
          executeStmtList(stmt->body);
          if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
          if (loopSignal_ == LoopSignal::Return) break;
          if (loopSignal_ == LoopSignal::Continue) loopSignal_ = LoopSignal::None;
        }
      }
      loopDepth_--;
      return;
    }

    case StmtKind::Break:
    case StmtKind::Continue: {
      bool isBreak = (stmt->kind == StmtKind::Break);
      if (loopDepth_ <= 0) {
        std::cerr << "Error: '" << (isBreak ? "break" : "continue")
                  << "' used outside of a loop\n";
        evaluationSucceeded_ = false;
      } else {
        loopSignal_ = isBreak ? LoopSignal::Break : LoopSignal::Continue;
      }
      return;
    }

    case StmtKind::Return:
      // `return value;` sets the function's (only) output, then returns.
      if (stmt->value) {
        if (!currentOutputNames_ || currentOutputNames_->size() != 1) {
          if (!currentOutputNames_)
            std::cerr << "Error: 'return' with a value can only be used inside a function\n";
          else if (currentOutputNames_->empty())
            std::cerr << "Error: 'return' with a value needs a function with an output, e.g. "
                         "function y = f(x):\n";
          else
            std::cerr << "Error: 'return' with a value works only in a function with one "
                         "output - assign each output, then write 'return;'\n";
          evaluationSucceeded_ = false;
          return;
        }
        Value result = evaluateExpr(stmt->value.get());
        if (!evaluationSucceeded_)
          return;
        varSet((*currentOutputSlots_)[0], (*currentOutputNames_)[0], result);
      }
      loopSignal_ = LoopSignal::Return;
      return;

    case StmtKind::Require:
    case StmtKind::Ensure: {
      bool isRequire = (stmt->kind == StmtKind::Require);
      Value cond = evaluateExpr(stmt->condition.get());
      if (!evaluationSucceeded_)
        return; // condition itself failed to evaluate - not a genuine violation
      if (!truthy(cond)) {
        std::cerr << "Error: " << (isRequire ? "precondition" : "postcondition") << " failed: ";
        if (!stmt->contractMessage.empty())
          std::cerr << stmt->contractMessage << " (" << stmt->conditionText << ")\n";
        else
          std::cerr << stmt->conditionText << "\n";
        evaluationSucceeded_ = false;
        loopSignal_ = LoopSignal::Return;
      }
      return;
    }

    case StmtKind::FunctionDecl:
      registerFunctionDeclStmt(*stmt);
      return;

    case StmtKind::ClassDecl:
      registerClassDeclStmt(*stmt);
      return;

    case StmtKind::Publish: {
      std::vector<Value> vals;
      for (const auto &argExpr : stmt->publishArgs)
        vals.push_back(evaluateExpr(argExpr.get()));

      if (evaluationSucceeded_) {
        for (size_t i = 0; i < vals.size(); i++) {
          const Value &v = vals[i];
          if (v.isText)
            std::cout << v.text();
          else
            std::cout << valueToString(v);
          if (i + 1 < vals.size())
            std::cout << " ";
        }
        std::cout << std::endl;
        // Plain text ends the current display group: a named value shown
        // after it opens with its own blank line again.
        resetDisplaySpacing();
      }
      // print/publish always display output and never update `ans`.
      return;
    }

    case StmtKind::ClearMemory: {
      clearMemory();
      return;
    }
  }
}

void Parser::clearMemory() {
  memory.clear();
  insertionOrder.clear();
}

/* ================= ASSIGNMENT ================= */

void Parser::executeAssignStmt(const Stmt *stmt) {
  // M ,= X / M ;= X
  if (stmt->extendDir != 0) {
    executeExtendAssign(stmt);
    return;
  }
  // A list of variables: [a, b, c] = ..., [Q, R] = qr(A).
  if (stmt->targets.size() >= 2) {
    executeTargetListAssign(stmt);
    return;
  }

  const Expr *target = stmt->targets[0].get();
  Value val = evaluateExpr(stmt->value.get());
  if (!evaluationSucceeded_)
    return;

  switch (target->kind) {
    case ExprKind::Identifier: {
      const std::string &name = target->text;
      // MATLAB: an assignment never touches `ans` - only an unassigned
      // expression (ExprStmt above) does.
      varSet(target->slot, name, val);

      if (!stmt->suppressOutput)
        printValue(name, val);
      return;
    }

    case ExprKind::FieldAccess: {
      const Expr *baseNode = target->children[0].get(); // always a bare identifier
      const std::string &name = baseNode->text;
      const std::string &fieldName = target->text;

      if (!varExists(baseNode->slot, name)) {
        std::cerr << "Error: '" << name << "' is not defined\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (!varGet(baseNode->slot, name).isObject) {
        std::cerr << "Error: '" << name << "' is not an object\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (isIntrospectionName(fieldName)) {
        std::cerr << "Error: '" << fieldName << "' cannot be a field name - after a dot it is "
                  << "reserved (obj.base lists the fields, obj.info the functions)\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (checkFieldAccess(varGet(baseNode->slot, name).className(), fieldName)) {
        varRef(baseNode->slot, name).dictMut()[fieldName] = val;

        if (!stmt->suppressOutput)
          printValue(name, val);
      }
      return;
    }

    case ExprKind::Index:
      executeIndexAssign(target, val, stmt->suppressOutput);
      return;

    default:
      // Not a shape parser_program.cpp's assignment parsing ever builds -
      // defensive only.
      evaluationSucceeded_ = false;
      return;
  }
}

/* ---- extend: M ,= X / M ;= X ----

   M ,= X is M = [M, X] (X goes to the right, adding columns) and M ;= X is
   M = [M; X] (X goes below, adding rows): the result, its element type and
   any type error are exactly those of the matrix literal, because the join
   itself is matBuildFromCells(), the literal's own builder. On top of the
   literal:
     - the value is worked out first, then M is read (so M ,= M doubles M)
     - [] on either side: M ,= [] leaves M as it is, [] ,= X gives X
     - a single value (or any 1x1) is repeated along M: M ,= 0 adds a
       column of zeros, M ;= 9 a row of nines
     - shapes are never transposed to fit; a mismatch is an error that says
       which count differs, with a hint when the transposed value would fit
     - 2-D only; M must already exist (M = [] to start empty).
   Copies are safe: the new matrix replaces M, so B = M; M ,= x leaves B as
   it was. */

namespace {

// Rows and columns of a 2-D value: a single value is 1x1, a 1-D array a
// 1xN row (as the literal treats it), a matrix its own shape.
void extendShape(const Value &v, size_t &rows, size_t &cols) {
  if (v.isMatrix) {
    rows = v.rows();
    cols = v.rows() == 0 ? 0 : v.cols();
  } else if (v.isArray) {
    rows = v.length() == 0 ? 0 : 1;
    cols = v.length();
  } else {
    rows = cols = 1;
  }
}

std::string extendShapeText(size_t rows, size_t cols) {
  return std::to_string(rows) + "x" + std::to_string(cols);
}

// The elements of a vector-shaped value, written as NC source (numbers and
// "text"), or "" when they cannot all be shown that way.
std::vector<std::string> extendCellTexts(const Value &v, size_t rows, size_t cols) {
  std::vector<std::string> out;
  for (size_t r = 0; r < rows; r++)
    for (size_t c = 0; c < cols; c++) {
      Value e = v.isMatrix ? v.at(r, c) : v.isArray ? v.at(r * cols + c) : v;
      if (e.isText)
        out.push_back("\"" + e.text() + "\"");
      else if (!e.isArray && !e.isMatrix && !e.isDict && !e.isObject && !e.isFunctionRef &&
               !e.isComplex)
        out.push_back(e.isBool() ? (e.number != 0 ? "true" : "false") : formatNumber(e.number));
      else
        return {};
    }
  return out;
}

std::string joinTexts(const std::vector<std::string> &parts, const char *sep) {
  std::string s;
  for (size_t i = 0; i < parts.size(); i++)
    s += (i ? sep : "") + parts[i];
  return s;
}

} // namespace

void Parser::executeExtendAssign(const Stmt *stmt) {
  const bool cols = stmt->extendDir == 1; // ,= adds columns; ;= adds rows
  const char *op = cols ? ",=" : ";=";
  const Expr *target = stmt->targets[0].get();
  const std::string &name = target->text;
  auto fail = [&](const std::string &msg) {
    std::cerr << "Error: extend error (" << op << "): " << msg << "\n";
    evaluationSucceeded_ = false;
  };

  Value x = evaluateExpr(stmt->value.get());
  if (!evaluationSucceeded_)
    return;
  if (!varExists(target->slot, name)) {
    fail("variable '" + name + "' is not defined \xE2\x80\x94 initialize it first, e.g. " + name +
         " = []");
    return;
  }
  Value m = varGet(target->slot, name);

  if (m.isND() || x.isND()) {
    fail("only 2-D matrices are supported, got " + matShapeText(m.isND() ? m : x));
    return;
  }

  size_t r = 0, c = 0, p = 0, q = 0;
  extendShape(m, r, c);
  extendShape(x, p, q);

  Value result;
  if (p == 0 || q == 0) {
    result = m; // M ,= [] - nothing to add
  } else {
    // A single value is repeated along the side it is added to.
    if (p == 1 && q == 1 && r > 0 && c > 0) {
      Value s = x.isMatrix ? x.at(0, 0) : x.isArray ? x.at(0) : x;
      if (cols && r > 1) {
        x = Value(std::vector<std::vector<Value>>(r, std::vector<Value>{s}));
        p = r;
      } else if (!cols && c > 1) {
        x = Value(std::vector<std::vector<Value>>{std::vector<Value>(c, s)});
        q = c;
      }
    }
    if (r > 0 && c > 0) {
      const size_t have = cols ? r : c, got = cols ? p : q;
      if (have != got) {
        std::string msg = name + " is " + extendShapeText(r, c) + ", value is " +
                          extendShapeText(p, q) + " \xE2\x80\x94 " +
                          (cols ? "row" : "column") + " count mismatch (" +
                          std::to_string(have) + " vs " + std::to_string(got) + ")";
        const bool transposedFits = cols ? (q == r) : (p == c);
        if (transposedFits) {
          std::vector<std::string> cells;
          if (cols && p == 1)
            cells = extendCellTexts(x, p, q);
          if (!cells.empty() && cells.size() <= 6)
            msg += " \xE2\x80\x94 for a column use [" + joinTexts(cells, "; ") + "] or [" +
                   joinTexts(cells, ", ") + "]'";
          else
            msg += std::string(" \xE2\x80\x94 transpose the value with ' to append it as a ") +
                   (cols ? "column" : "row");
        }
        fail(msg);
        return;
      }
    }
    // The literal's own builder: [M, X] or [M; X].
    std::vector<std::vector<Value>> cells =
        cols ? std::vector<std::vector<Value>>{{m, x}}
             : std::vector<std::vector<Value>>{{m}, {x}};
    std::string err;
    if (!matBuildFromCells(cells, result, err)) {
      fail(err);
      return;
    }
  }

  varSet(target->slot, name, result);
  if (!stmt->suppressOutput)
    printValue(name, result);
}

/* ---- a list of variables: [a, b, c] = ... ----

   Every value is worked out first and only then assigned, so the names
   swap cleanly ([a, b] = [b, a]) and a mistake on the right leaves every
   name as it was. The right side decides how the values are handed out:

     [Q, R] = qr(A)           a function with that many results gives one
                              result per name
     [a, b] = deal(x, y)      deal: one value per name, or deal(x) for all
     [a, b, c] = [1, 2, "car"]
                              a literal shaped exactly like the list: each
                              name gets its own cell, with its own type
                              (a = 1, b = 2, c = "car" - no common type)
     [a, b, c] = v            anything else is evaluated first and split
                              like v[0], v[1], v[2]: the elements of a
                              vector, the rows of a matrix, the slabs of an
                              N-D matrix - their number must match
     [a, b; c, d] = M         a list with rows takes a matrix of exactly
                              that shape, element by element
     [~, i] = max(A)          '~' skips a value
*/

namespace {

std::string countWords(size_t n, const char *one, const char *many) {
  return std::to_string(n) + " " + (n == 1 ? one : many);
}

} // namespace

bool Parser::assignToTarget(const Expr *target, const Value &val, bool suppressOutput) {
  switch (target->kind) {
  case ExprKind::Identifier:
    varSet(target->slot, target->text, val);
    if (!suppressOutput)
      printValue(target->text, val);
    return true;

  case ExprKind::FieldAccess: {
    const Expr *baseNode = target->children[0].get();
    const std::string &name = baseNode->text;
    if (!varExists(baseNode->slot, name)) {
      std::cerr << "Error: '" << name << "' is not defined\n";
      evaluationSucceeded_ = false;
      return false;
    }
    if (!varGet(baseNode->slot, name).isObject) {
      std::cerr << "Error: '" << name << "' is not an object\n";
      evaluationSucceeded_ = false;
      return false;
    }
    if (isIntrospectionName(target->text)) {
      std::cerr << "Error: '" << target->text << "' cannot be a field name - after a dot it is "
                << "reserved (obj.base lists the fields, obj.info the functions)\n";
      evaluationSucceeded_ = false;
      return false;
    }
    if (!checkFieldAccess(varGet(baseNode->slot, name).className(), target->text))
      return false;
    varRef(baseNode->slot, name).dictMut()[target->text] = val;
    if (!suppressOutput)
      printValue(name, val);
    return true;
  }

  case ExprKind::Index:
    executeIndexAssign(target, val, suppressOutput);
    return evaluationSucceeded_;

  default:
    evaluationSucceeded_ = false;
    return false;
  }
}

void Parser::executeTargetListAssign(const Stmt *stmt) {
  const size_t count = stmt->targets.size();
  const size_t rows = stmt->targetRows > 1 ? stmt->targetRows : 1;
  const size_t cols = count / rows;
  const Expr *rhs = stmt->value.get();
  std::vector<Value> values;

  auto fail = [&](const std::string &message) {
    std::cerr << "Error: " << message << "\n";
    evaluationSucceeded_ = false;
  };

  // Splits one value over the list (see the comment above).
  auto split = [&](const Value &v) -> bool {
    if (rows > 1) {
      if (!v.isMatrix || v.isND() || v.rows() != rows || v.cols() != cols) {
        fail("[" + std::to_string(rows) + " rows of " + std::to_string(cols) + " names] = ... needs a " +
             std::to_string(rows) + "x" + std::to_string(cols) + " matrix on the right, got " +
             (v.isMatrix || v.isArray ? "a " + matShapeText(v) + " matrix" : std::string("a single value")));
        return false;
      }
      for (size_t r = 0; r < rows; r++)
        for (size_t c = 0; c < cols; c++)
          values.push_back(v.at(r, c));
      return true;
    }
    size_t available;
    std::string unit;
    if (v.isND()) {
      available = v.ndShape()[0];
      unit = available == 1 ? "slab along its first axis" : "slabs along its first axis";
    } else if (v.isMatrix && matIsVectorShape(v)) {
      available = v.rows() * v.cols();
      unit = available == 1 ? "element" : "elements";
    } else if (v.isMatrix) {
      available = v.rows();
      unit = available == 1 ? "row" : "rows";
    } else if (v.isArray) {
      available = v.length();
      unit = available == 1 ? "element" : "elements";
    } else {
      fail("the right side is a single value, but there are " + std::to_string(count) +
           " names - to give every name the same value write [...] = deal(value)");
      return false;
    }
    if (available != count) {
      fail(countWords(count, "name needs", "names need") + " " + std::to_string(count) +
           " values, but the right side (" + matShapeText(v) + ") has " +
           std::to_string(available) + " " + unit);
      return false;
    }
    for (size_t k = 0; k < count; k++) {
      std::vector<MatIndexKey> key(1);
      key[0].kind = MatIndexKey::Scalar;
      key[0].scalar = static_cast<double>(k);
      Value part;
      std::string err;
      if (!matIndexGet(v, key, "", part, err)) {
        fail(err);
        return false;
      }
      values.push_back(std::move(part));
    }
    return true;
  };

  // A literal shaped exactly like the list: cell by cell.
  auto literalMatches = [&]() {
    if (rhs->kind != ExprKind::MatrixLiteral || rhs->children.size() != rows)
      return false;
    for (int level : rhs->sepLevels)
      if (level >= 2)
        return false;
    for (const auto &row : rhs->children)
      if (row->children.size() != cols)
        return false;
    return true;
  };

  if (rhs->kind == ExprKind::Call && rows == 1) {
    std::vector<Value> args;
    for (const auto &a : rhs->children)
      args.push_back(evaluateExpr(a.get()));
    if (!evaluationSucceeded_)
      return;
    const std::string &name = rhs->text;
    const std::vector<std::string> &argNames = rhs->argNames; // [q, r] = f(b=2, 1)

    // Named values work for functions and classes the script defines and
    // for builtins with a parameter line; the parser's own calls (deal,
    // feval, ...) take their values in order.
    if (rhs->hasNamedArgs() && !hasFunction(name) && !hasClass(name) &&
        (name == "deal" || name == "feval" || name == "grad" || name == "taylor_series" ||
         name == "green_integral" || ncdata::DataEngine::isWorkspaceCommand(name))) {
      fail(name + ": its values cannot be named - give them in order");
      return;
    }

    if (name == "deal" && !hasFunction("deal")) {
      if (args.size() == 1) {
        values.assign(count, args[0]);
      } else if (args.size() == count) {
        values = args;
      } else {
        fail("deal gives one value to every name, or one value each - got " +
             std::to_string(args.size()) + " values for " + std::to_string(count) + " names");
        return;
      }
    } else if (hasFunction(name)) {
      // Which version this call binds to decides whether it has one result
      // (split over the names) or several. A call that fits no version is
      // reported by the call below.
      std::string unused;
      const FunctionDef *def = resolveOverload(functionTable_[name], "", name, args.size(),
                                               argNames, unused);
      if (def && def->outputNames.size() == 1 && count != 1) {
        // One result, split over the names.
        bool found = false;
        Value single = callUserFunction(name, args, found, argNames);
        if (!found || !evaluationSucceeded_ || !split(single))
          return;
      } else {
        bool found = false;
        values = callUserFunctionMulti(name, args, count, found, argNames);
        if (!evaluationSucceeded_)
          return;
      }
    } else if (hasClass(name)) {
      bool found = false;
      Value single = callClassConstructor(name, args, found, argNames);
      if (!found || !evaluationSucceeded_ || !split(single))
        return;
    } else {
      bool handledReserved = false;
      Value reserved = tryReservedFunctionValueCall(name, args, handledReserved);
      if (handledReserved) {
        if (!evaluationSucceeded_ || !split(reserved))
          return;
      } else {
        // A builtin with several results: [U, S, V] = svd(A), [Q, R] = qr(A).
        bool builtinOk = true;
        std::vector<Value> results;
        if (callBuiltinMulti(name, args, count, results, builtinOk, argNames)) {
          if (!builtinOk) {
            evaluationSucceeded_ = false;
            return;
          }
          values = std::move(results);
        } else {
          // Any other builtin: its one result, split over the names.
          std::string ndErr;
          if (!ndBuiltinGuard(name, args, ndErr)) {
            fail(ndErr);
            return;
          }
          Value single = callBuiltinNamed(name, args, argNames);
          if (!g_lastBuiltinFound || !g_lastVectorOk || !g_lastStatsOk || !g_lastGeometricOk ||
              !g_lastDcOk || !g_lastElementwiseOk || !g_lastConditionalOk || !g_lastPlotOk) {
            evaluationSucceeded_ = false;
            return;
          }
          if (!split(single))
            return;
        }
      }
    }
  } else if (literalMatches()) {
    for (const auto &row : rhs->children)
      for (const auto &cell : row->children)
        values.push_back(evaluateExpr(cell.get()));
    if (!evaluationSucceeded_)
      return;
  } else {
    Value v = evaluateExpr(rhs);
    if (!evaluationSucceeded_ || !split(v))
      return;
  }

  if (values.size() != count) {
    fail("the right side gives " + std::to_string(values.size()) + " values for " +
         std::to_string(count) + " names");
    return;
  }

  for (size_t k = 0; k < count; k++) {
    const Expr *target = stmt->targets[k].get();
    if (target->kind == ExprKind::Identifier && target->text == "~")
      continue; // a value nobody wants
    if (!assignToTarget(target, values[k], stmt->suppressOutput))
      return;
  }
}

void Parser::executeIndexAssign(const Expr *target, const Value &val, bool suppressOutput) {
  const Expr *base = target->children[0].get();
  const Expr *innerBase = nullptr;
  std::vector<const Expr *> keyNodes;

  if (base->kind == ExprKind::Index) {
    /* A[row][col] = value - one index per bracket; the same as A[row,col]. */
    innerBase = base->children[0].get();
    if (base->children.size() != 2 || target->children.size() != 2 ||
        innerBase->kind != ExprKind::Identifier) {
      std::cerr << "Error: A[row][col] = value takes one index in each bracket - or write "
                   "A[row,col] = value\n";
      evaluationSucceeded_ = false;
      return;
    }
    if (!varExists(innerBase->slot, innerBase->text) ||
        !varGet(innerBase->slot, innerBase->text).isMatrix) {
      std::cerr << "Error: '" << innerBase->text << "' is not a matrix\n";
      evaluationSucceeded_ = false;
      return;
    }
    keyNodes = {base->children[1].get(), target->children[1].get()};
  } else {
    innerBase = base;
    for (size_t i = 1; i < target->children.size(); i++)
      keyNodes.push_back(target->children[i].get());
  }

  const std::string &name = innerBase->text;
  const int slot = innerBase->slot;
  const bool exists = varExists(slot, name);

  bool anySliceKey = false;
  for (const Expr *k : keyNodes)
    if (k->kind == ExprKind::Wildcard || k->kind == ExprKind::Slice)
      anySliceKey = true;

  std::vector<Value> plainKeys; // evaluated only for the dict decision below
  bool dictPath = exists && varGet(slot, name).isDict;
  bool plainKeysEvaluated = false;
  if (!exists && !anySliceKey) {
    // A new name: text keys make a dict (d['a'] = 1), numbers a matrix
    // (A[2,3] = 7 creates a 3x4 matrix of zeros with that one element).
    for (const Expr *k : keyNodes)
      plainKeys.push_back(evaluateExpr(k));
    if (!evaluationSucceeded_)
      return;
    plainKeysEvaluated = true;
    for (const Value &k : plainKeys)
      if (k.isText)
        dictPath = true;
  }

  if (!dictPath) {
    /* Matrix / array element, row, column or slice - the shared rules in
       ops/matrix/matrix_index.h (also used by the JIT bridge). */
    std::vector<MatIndexKey> keys;
    std::string err;
    if (plainKeysEvaluated) {
      for (const Value &kv : plainKeys) {
        Value k = kv;
        if (k.isMatrix && k.rows() == 1 && k.cols() == 1)
          k = k.at(0, 0);
        if (k.isArray || k.isMatrix || k.isDict || k.isObject || k.isFunctionRef ||
            k.hasComplex()) {
          std::cerr << "Error: an index must be a whole number or a range like 2:5 - got a value "
                       "of shape "
                    << matShapeText(k) << "\n";
          evaluationSucceeded_ = false;
          return;
        }
        MatIndexKey key;
        key.kind = MatIndexKey::Scalar;
        key.scalar = k.number;
        keys.push_back(key);
      }
    } else if (!evaluateIndexKeys(keyNodes, keys, err)) {
      if (!err.empty())
        std::cerr << "Error: " << err << "\n";
      evaluationSucceeded_ = false;
      return;
    }

    bool ok;
    if (exists) {
      ok = matIndexSet(varRef(slot, name), true, keys, val, name, err);
    } else {
      Value created;
      ok = matIndexSet(created, false, keys, val, name, err);
      if (ok)
        varSet(slot, name, created);
    }
    if (!ok) {
      std::cerr << "Error: " << err << "\n";
      evaluationSucceeded_ = false;
      return;
    }
    // Auto-print (no trailing ';') shows the whole updated matrix.
    if (!suppressOutput)
      printValue(name, varGet(slot, name));
    return;
  }

  /* Dict key(s): d['key'] = v, d[k1,k2] = [v1,v2]. */
  if (anySliceKey) {
    std::cerr << "Error: ':' is not a dict key - '" << name << "' is a dict\n";
    evaluationSucceeded_ = false;
    return;
  }
  std::vector<Value> keys;
  if (plainKeysEvaluated) {
    keys = plainKeys;
  } else {
    for (const Expr *k : keyNodes)
      keys.push_back(evaluateExpr(k));
    if (!evaluationSucceeded_)
      return;
  }

  if (!exists)
    varSet(slot, name, Value(std::unordered_map<std::string, Value>()));

  if (keys.size() == 1) {
    varRef(slot, name).dictMut()[dictKeyOf(keys[0])] = val;
  } else {
    Value vals = matVectorAsArray(val);
    if (!vals.isArray || vals.length() != keys.size()) {
      std::cerr << "Error: multi-key dict assignment expects " << keys.size()
                << " values, e.g. " << name << "['a','b'] = [1,2]\n";
      evaluationSucceeded_ = false;
      return;
    }
    for (size_t i = 0; i < keys.size(); i++)
      varRef(slot, name).dictMut()[dictKeyOf(keys[i])] = vals.at(i);
  }

  if (!suppressOutput)
    printValue(name, val);
}
