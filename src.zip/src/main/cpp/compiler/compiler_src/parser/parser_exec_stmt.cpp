// Phase 3 Step 3 (AST rewrite roadmap): the tree-walking statement
// evaluator. Reuses every existing side-effecting primitive unchanged -
// memory, callBuiltin/callUserFunction/callClassConstructor/
// callInstanceMethod, loopSignal_/loopDepth_ - only the driving mechanism
// changes: walking an already-built Stmt tree instead of re-lexing text and
// re-scanning for block boundaries on every iteration/call. Currently
// reachable via invokeFunctionBody() (parser_function.cpp) for a function/
// method body, and by anything that builds a Program via parseProgram()
// (parser_program.cpp) and calls executeProgram() directly - not yet
// ScriptManager itself (Step 4).
#include "parser.h"
#include "parser_internal.h"

#include <iostream>

#include "../builtins/builtins.h"
#include "../conditional_opr/conditional_opr.h"
#include "../../../runtime/data/DataEngine.h"
#include "../../../runtime/execution/Interrupt.h"
#include "output.h"
#include "../ops/matrix/matrix_index.h"

namespace {

// Delegates to the one shared definition of "truthy" (conditional_opr.h's
// valueIsTruthy()) instead of carrying its own separate, divergent copy -
// this file's old private version (text: non-empty; anything else: number
// != 0) disagreed with and()/or()/not()/cond_if() et al., which read
// .number directly with no text/container handling at all: the same
// value was truthy here but falsy there. See valueIsTruthy()'s own
// comment for the full story and how it was confirmed.
bool truthy(const Value &v) {
  return valueIsTruthy(v);
}

std::string trimmed(const std::string &s) {
  size_t start = s.find_first_not_of(" \t\r\n");
  if (start == std::string::npos)
    return "";
  size_t end = s.find_last_not_of(" \t\r\n");
  return s.substr(start, end - start + 1);
}

// Step-into pause: called once per statement from executeStmtList() below
// when debugStepMode_ is on. Reports the statement just executed, then
// blocks on stdin for the Java IDE's next control line - "@cmd stepnext"
// resumes with pausing still on, "@cmd stepdone" resumes with pausing
// turned off for the rest of this run. Any other line is ignored and the
// wait repeats, so accidental stray input can't silently skip a pause.
void pauseForStep(Parser &parser, size_t line) {
  // The IDE's variable list follows the step: send the global workspace
  // (only if it changed) before announcing the pause.
  ncdata::DataEngine::instance().emitWorkspaceIfChanged(parser.globalMemory(),
                                                        parser.globalInsertionOrder());
  std::cout << "@STEPAT " << line << std::endl;
  std::string input;
  while (std::getline(std::cin, input)) {
    std::string cmd = trimmed(input);
    if (cmd.rfind("@cmd ", 0) == 0)
      cmd = trimmed(cmd.substr(5));
    if (cmd == "stepnext") {
      // Stop pressed while paused: the IDE raises the interrupt flag and
      // then releases the pause; look for the flag right away.
      nc::Interrupt::pollNow();
      return;
    }
    if (cmd == "stepdone") {
      parser.setDebugStepMode(false);
      nc::Interrupt::pollNow();
      return;
    }
    // Unrecognized line while paused: ignore and keep waiting.
  }
}

// Deep-clones an Expr/Stmt subtree. Needed because FunctionDef::body must
// be independently owned (a function can be called long after, and many
// times more than, whatever Program the FunctionDecl Stmt was originally
// parsed as part of) - unique_ptr trees can't be shared, only moved or
// copied, and moving would corrupt the source Program for anyone still
// holding it (e.g. re-registering the same forward-declared function is
// harmless and expected; silently emptying the *source* tree while doing
// so would not be).
std::unique_ptr<Expr> cloneExpr(const Expr *src) {
  if (!src)
    return nullptr;
  auto dst = std::make_unique<Expr>();
  dst->kind = src->kind;
  dst->number = src->number;
  dst->text = src->text;
  // Literal flags: without these a cloned `3i` became the real 3 and a
  // cloned `true` became the float64 1.
  dst->imaginary = src->imaginary;
  dst->isBool = src->isBool;
  for (const auto &c : src->children)
    dst->children.push_back(cloneExpr(c.get()));
  dst->rangeStart = cloneExpr(src->rangeStart.get());
  dst->rangeStop = cloneExpr(src->rangeStop.get());
  dst->rangeStep = cloneExpr(src->rangeStep.get());
  dst->slot = src->slot;
  return dst;
}

std::unique_ptr<Stmt> cloneStmt(const Stmt *src) {
  if (!src)
    return nullptr;
  auto dst = std::make_unique<Stmt>();
  dst->kind = src->kind;
  dst->line = src->line;
  dst->suppressOutput = src->suppressOutput;
  dst->expr = cloneExpr(src->expr.get());
  for (const auto &t : src->targets)
    dst->targets.push_back(cloneExpr(t.get()));
  dst->value = cloneExpr(src->value.get());
  dst->condition = cloneExpr(src->condition.get());
  dst->loopVar = src->loopVar;
  dst->loopVarSlot = src->loopVarSlot;
  dst->iterable = cloneExpr(src->iterable.get());
  for (const auto &s : src->body)
    dst->body.push_back(cloneStmt(s.get()));
  for (const auto &branch : src->elseifBranches) {
    std::vector<std::unique_ptr<Stmt>> body;
    for (const auto &s : branch.second)
      body.push_back(cloneStmt(s.get()));
    dst->elseifBranches.emplace_back(cloneExpr(branch.first.get()), std::move(body));
  }
  for (const auto &s : src->elseBody)
    dst->elseBody.push_back(cloneStmt(s.get()));
  dst->conditionText = src->conditionText;
  dst->name = src->name;
  dst->inputNames = src->inputNames;
  dst->outputNames = src->outputNames;
  dst->parentClassName = src->parentClassName;
  dst->isAbstract = src->isAbstract;
  dst->isReversible = src->isReversible;
  dst->hasRate = src->hasRate;
  dst->rateHz = src->rateHz;
  dst->restrictedFields = src->restrictedFields;
  for (const auto &m : src->methods)
    dst->methods.push_back(cloneStmt(m.get()));
  for (const auto &p : src->publishArgs)
    dst->publishArgs.push_back(cloneExpr(p.get()));
  return dst;
}

} // namespace

/* ================= PROGRAM / FORWARD REFERENCES ================= */

void Parser::registerFunctionDeclStmt(const Stmt &stmt) {
  FunctionDef def;
  def.inputNames = stmt.inputNames;
  def.outputNames = stmt.outputNames;
  for (const auto &bodyStmt : stmt.body)
    def.body.push_back(cloneStmt(bodyStmt.get()));
  resolveFunctionSlots(def, /*hasBase=*/false);
  registerOverload(functionTable_, stmt.name, std::move(def));
}

void Parser::registerClassDeclStmt(const Stmt &stmt) {
  // A malformed method header (or a non-abstract class with an unimplemented
  // method) aborted this class's parse partway through - see
  // parseClassDeclNode(). The old executeClassDefEnd() never adds such a
  // class to classTable_ either, so later uses correctly see "Unknown
  // function/class" rather than a half-registered class.
  if (stmt.classRegistrationFailed)
    return;

  ClassDef def;
  def.parentClassName = stmt.parentClassName;
  def.isAbstract = stmt.isAbstract;
  def.isReversible = stmt.isReversible;
  def.hasRate = stmt.hasRate;
  def.rateHz = stmt.rateHz;
  def.restrictedFields = stmt.restrictedFields;

  for (const auto &methodStmt : stmt.methods) {
    FunctionDef methodDef;
    methodDef.inputNames = methodStmt->inputNames;
    methodDef.outputNames = methodStmt->outputNames;
    for (const auto &bodyStmt : methodStmt->body)
      methodDef.body.push_back(cloneStmt(bodyStmt.get()));
    resolveFunctionSlots(methodDef, /*hasBase=*/true);
    registerOverload(def.methods, methodStmt->name, std::move(methodDef));
  }

  classTable_[stmt.name] = std::move(def);
}

void Parser::registerTopLevelDecls(const Program &program) {
  // Register every top-level function/class definition, so a call can
  // forward-reference one whose declaration appears later in the file -
  // matches ScriptManager's own pre-scan today (SM_stage_02.cpp), but over
  // an already-parsed tree instead of re-lexing raw lines.
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl)
      registerFunctionDeclStmt(*stmt);
    else if (stmt->kind == StmtKind::ClassDecl)
      registerClassDeclStmt(*stmt);
  }
}

void Parser::executeProgram(const Program &program) {
  // Pass 1: see registerTopLevelDecls() above.
  registerTopLevelDecls(program);

  // Pass 2: execute everything else, in order. FunctionDecl/ClassDecl are
  // skipped here - already registered above, and re-registering from the
  // same statement a second time would just be redundant work.
  for (const auto &stmt : program.statements) {
    if (stmt->kind == StmtKind::FunctionDecl || stmt->kind == StmtKind::ClassDecl)
      continue;
    if (nc::Interrupt::poll())
      break; // Stop pressed - reported once by the REPL
    executeStmt(stmt.get());
    if (loopSignal_ != LoopSignal::None) {
      // A top-level `return;` (or a failed require/ensure) stops the rest
      // of the script - matches consumeTopLevelStopSignal()'s caller sites
      // in SM_stage_02.cpp/main.cpp today.
      loopSignal_ = LoopSignal::None;
      break;
    }
  }
}

/* ================= STATEMENT LIST ================= */

void Parser::executeStmtList(const std::vector<std::unique_ptr<Stmt>> &stmts) {
  for (const auto &stmt : stmts) {
    // Stop pressed in the IDE: unwind like a `return;` at every level - a
    // loop around this list breaks on Return, and invokeFunctionBody()
    // fails the call. The request stays set (nc::Interrupt is sticky), so
    // each enclosing statement list stops in turn.
    if (nc::Interrupt::poll()) {
      loopSignal_ = LoopSignal::Return;
      return;
    }
    executeStmt(stmt.get());
    if (debugStepMode_)
      pauseForStep(*this, stmt->line);
    if (loopSignal_ != LoopSignal::None)
      return; // break/continue/return - stop processing the rest of this list
  }
}

/* ================= STATEMENT DISPATCH ================= */

void Parser::executeStmt(const Stmt *stmt) {
  if (!stmt)
    return;

  // MATLAB-style gating for ans auto-display/update - matches
  // parseStatement()'s own reset at the top of every statement.
  evaluationSucceeded_ = true;

  switch (stmt->kind) {
    case StmtKind::ExprStmt: {
      Value v = evaluateExpr(stmt->expr.get());
      // save_workspace()/load_workspace() print their own one-line report;
      // their `true` result is neither echoed nor stored in `ans`.
      if (stmt->expr && stmt->expr->kind == ExprKind::Call &&
          ncdata::DataEngine::isWorkspaceCommand(stmt->expr->text))
        return;
      if (evaluationSucceeded_) {
        setAns(v);
        // An unassigned result is shown as `ans`, MATLAB style:
        //   >> 3 + 4
        //
        //   ans =
        //
        //       7
        //
        if (!stmt->suppressOutput)
          printValue("ans", v);
      }
      return;
    }

    case StmtKind::Assign:
      executeAssignStmt(stmt);
      return;

    case StmtKind::If: {
      if (truthy(evaluateExpr(stmt->condition.get()))) {
        executeStmtList(stmt->body);
        return;
      }
      for (const auto &branch : stmt->elseifBranches) {
        if (truthy(evaluateExpr(branch.first.get()))) {
          executeStmtList(branch.second);
          return;
        }
      }
      executeStmtList(stmt->elseBody);
      return;
    }

    case StmtKind::For: {
      Value iterableVal = evaluateExpr(stmt->iterable.get());
      if (!evaluationSucceeded_)
        return;
      // A vector ([1,2,3], [1:5], a column) runs once per element; any
      // other matrix runs once per row (each a 1xN matrix), matching A[m].
      if (iterableVal.isMatrix) {
        std::vector<Value> items;
        if (matIsVectorShape(iterableVal)) {
          items = matVectorAsArray(iterableVal).elems();
        } else {
          for (size_t r = 0; r < iterableVal.rows(); r++) {
            std::vector<MatIndexKey> rowKey(1);
            rowKey[0].kind = MatIndexKey::Scalar;
            rowKey[0].scalar = static_cast<double>(r);
            Value rowVal;
            std::string err;
            matIndexGet(iterableVal, rowKey, stmt->loopVar, rowVal, err);
            items.push_back(rowVal);
          }
        }
        iterableVal = Value(std::move(items));
      }
      loopDepth_++;
      {
        if (iterableVal.isArray) {
          for (const Value &elem : iterableVal.elems()) {
            varSet(stmt->loopVarSlot, stmt->loopVar, elem);
            executeStmtList(stmt->body);
            if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
            if (loopSignal_ == LoopSignal::Return) break; // propagate past the loop
            if (loopSignal_ == LoopSignal::Continue) loopSignal_ = LoopSignal::None;
          }
        } else {
          // Single value treated as 1-element iteration (matches Form A's
          // "for x in <non-array>" fallback today).
          varSet(stmt->loopVarSlot, stmt->loopVar, iterableVal);
          executeStmtList(stmt->body);
          if (loopSignal_ == LoopSignal::Break || loopSignal_ == LoopSignal::Continue)
            loopSignal_ = LoopSignal::None;
        }
      }
      loopDepth_--;
      return;
    }

    case StmtKind::While: {
      int iterationCount = 0;
      const int MAX_ITERATIONS = kMaxWhileIterations; // shared with the JIT path (ast.h)
      loopDepth_++;
      {
        while (truthy(evaluateExpr(stmt->condition.get()))) {
          iterationCount++;
          if (iterationCount > MAX_ITERATIONS) {
            std::cerr << whileLimitErrorText();
            evaluationSucceeded_ = false;
            break;
          }
          executeStmtList(stmt->body);
          if (loopSignal_ == LoopSignal::Break) { loopSignal_ = LoopSignal::None; break; }
          if (loopSignal_ == LoopSignal::Return) break;
          if (loopSignal_ == LoopSignal::Continue) loopSignal_ = LoopSignal::None;
        }
      }
      loopDepth_--;
      return;
    }

    case StmtKind::Break:
    case StmtKind::Continue: {
      bool isBreak = (stmt->kind == StmtKind::Break);
      if (loopDepth_ <= 0) {
        std::cerr << "Error: '" << (isBreak ? "break" : "continue")
                  << "' used outside of a loop\n";
        evaluationSucceeded_ = false;
      } else {
        loopSignal_ = isBreak ? LoopSignal::Break : LoopSignal::Continue;
      }
      return;
    }

    case StmtKind::Return:
      loopSignal_ = LoopSignal::Return;
      return;

    case StmtKind::Require:
    case StmtKind::Ensure: {
      bool isRequire = (stmt->kind == StmtKind::Require);
      Value cond = evaluateExpr(stmt->condition.get());
      if (!evaluationSucceeded_)
        return; // condition itself failed to evaluate - not a genuine violation
      if (!truthy(cond)) {
        std::cerr << "Error: " << (isRequire ? "precondition" : "postcondition")
                  << " failed: " << stmt->conditionText << "\n";
        evaluationSucceeded_ = false;
        loopSignal_ = LoopSignal::Return;
      }
      return;
    }

    case StmtKind::FunctionDecl:
      registerFunctionDeclStmt(*stmt);
      return;

    case StmtKind::ClassDecl:
      registerClassDeclStmt(*stmt);
      return;

    case StmtKind::Publish: {
      std::vector<Value> vals;
      for (const auto &argExpr : stmt->publishArgs)
        vals.push_back(evaluateExpr(argExpr.get()));

      if (evaluationSucceeded_) {
        for (size_t i = 0; i < vals.size(); i++) {
          const Value &v = vals[i];
          if (v.isText)
            std::cout << v.text();
          else
            std::cout << valueToString(v);
          if (i + 1 < vals.size())
            std::cout << " ";
        }
        std::cout << std::endl;
        // Plain text ends the current display group: a named value shown
        // after it opens with its own blank line again.
        resetDisplaySpacing();
      }
      // print/publish always display output and never update `ans`.
      return;
    }

    case StmtKind::ClearMemory: {
      clearMemory();
      return;
    }
  }
}

void Parser::clearMemory() {
  memory.clear();
  insertionOrder.clear();
}

/* ================= ASSIGNMENT ================= */

void Parser::executeAssignStmt(const Stmt *stmt) {
  // Multi-output call: (A,B) = f(...)
  if (stmt->targets.size() >= 2) {
    const Expr *call = stmt->value.get();
    std::vector<Value> args;
    for (const auto &a : call->children)
      args.push_back(evaluateExpr(a.get()));

    if (!evaluationSucceeded_)
      return;

    bool found = false;
    std::vector<Value> results =
        callUserFunctionMulti(call->text, args, stmt->targets.size(), found);
    if (!found) {
      // A builtin with several results: [U, S, V] = svd(A), [Q, R] = qr(A).
      bool builtinOk = true;
      if (callBuiltinMulti(call->text, args, stmt->targets.size(), results, builtinOk)) {
        if (!builtinOk) {
          evaluationSucceeded_ = false;
          return;
        }
      } else {
        std::cerr << "Error: '" << call->text << "' is not a function that returns "
                  << stmt->targets.size() << " values\n";
        evaluationSucceeded_ = false;
        return;
      }
    }

    if (evaluationSucceeded_) {
      // Multi-output targets are never resolved to a slot (see
      // resolveFunctionSlots()'s Pass A / FunctionDef::inputSlots' comment
      // for why) - varSet(-1, ...) is exactly the old memory[name]=...
      // path, kept as a var*() call purely for uniformity/auditability.
      for (size_t k = 0; k < stmt->targets.size() && k < results.size(); k++)
        varSet(stmt->targets[k]->slot, stmt->targets[k]->text, results[k]);

      if (!stmt->suppressOutput) {
        for (size_t k = 0; k < stmt->targets.size() && k < results.size(); k++)
          printValue(stmt->targets[k]->text, results[k]);
      }
    }
    return;
  }

  const Expr *target = stmt->targets[0].get();
  Value val = evaluateExpr(stmt->value.get());
  if (!evaluationSucceeded_)
    return;

  switch (target->kind) {
    case ExprKind::Identifier: {
      const std::string &name = target->text;
      // MATLAB: an assignment never touches `ans` - only an unassigned
      // expression (ExprStmt above) does.
      varSet(target->slot, name, val);

      if (!stmt->suppressOutput)
        printValue(name, val);
      return;
    }

    case ExprKind::FieldAccess: {
      const Expr *baseNode = target->children[0].get(); // always a bare identifier
      const std::string &name = baseNode->text;
      const std::string &fieldName = target->text;

      if (!varExists(baseNode->slot, name)) {
        std::cerr << "Error: '" << name << "' is not defined\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (!varGet(baseNode->slot, name).isObject) {
        std::cerr << "Error: '" << name << "' is not an object\n";
        evaluationSucceeded_ = false;
        return;
      }
      if (checkFieldAccess(varGet(baseNode->slot, name).className(), fieldName)) {
        varRef(baseNode->slot, name).dictMut()[fieldName] = val;

        if (!stmt->suppressOutput)
          printValue(name, val);
      }
      return;
    }

    case ExprKind::Index:
      executeIndexAssign(target, val, stmt->suppressOutput);
      return;

    default:
      // Not a shape parser_program.cpp's assignment parsing ever builds -
      // defensive only.
      evaluationSucceeded_ = false;
      return;
  }
}

void Parser::executeIndexAssign(const Expr *target, const Value &val, bool suppressOutput) {
  const Expr *base = target->children[0].get();
  const Expr *innerBase = nullptr;
  std::vector<const Expr *> keyNodes;

  if (base->kind == ExprKind::Index) {
    /* A[row][col] = value - one index per bracket; the same as A[row,col]. */
    innerBase = base->children[0].get();
    if (base->children.size() != 2 || target->children.size() != 2 ||
        innerBase->kind != ExprKind::Identifier) {
      std::cerr << "Error: A[row][col] = value takes one index in each bracket - or write "
                   "A[row,col] = value\n";
      evaluationSucceeded_ = false;
      return;
    }
    if (!varExists(innerBase->slot, innerBase->text) ||
        !varGet(innerBase->slot, innerBase->text).isMatrix) {
      std::cerr << "Error: '" << innerBase->text << "' is not a matrix\n";
      evaluationSucceeded_ = false;
      return;
    }
    keyNodes = {base->children[1].get(), target->children[1].get()};
  } else {
    innerBase = base;
    for (size_t i = 1; i < target->children.size(); i++)
      keyNodes.push_back(target->children[i].get());
  }

  const std::string &name = innerBase->text;
  const int slot = innerBase->slot;
  const bool exists = varExists(slot, name);

  bool anySliceKey = false;
  for (const Expr *k : keyNodes)
    if (k->kind == ExprKind::Wildcard || k->kind == ExprKind::Slice)
      anySliceKey = true;

  std::vector<Value> plainKeys; // evaluated only for the dict decision below
  bool dictPath = exists && varGet(slot, name).isDict;
  bool plainKeysEvaluated = false;
  if (!exists && !anySliceKey) {
    // A new name: text keys make a dict (d['a'] = 1), numbers a matrix
    // (A[2,3] = 7 creates a 3x4 matrix of zeros with that one element).
    for (const Expr *k : keyNodes)
      plainKeys.push_back(evaluateExpr(k));
    if (!evaluationSucceeded_)
      return;
    plainKeysEvaluated = true;
    for (const Value &k : plainKeys)
      if (k.isText)
        dictPath = true;
  }

  if (!dictPath) {
    /* Matrix / array element, row, column or slice - the shared rules in
       ops/matrix/matrix_index.h (also used by the JIT bridge). */
    std::vector<MatIndexKey> keys;
    std::string err;
    if (plainKeysEvaluated) {
      for (const Value &kv : plainKeys) {
        Value k = kv;
        if (k.isMatrix && k.rows() == 1 && k.cols() == 1)
          k = k.at(0, 0);
        if (k.isArray || k.isMatrix || k.isDict || k.isObject || k.isFunctionRef ||
            k.hasComplex()) {
          std::cerr << "Error: an index must be a whole number or a range like 2:5 - got a value "
                       "of shape "
                    << matShapeText(k) << "\n";
          evaluationSucceeded_ = false;
          return;
        }
        MatIndexKey key;
        key.kind = MatIndexKey::Scalar;
        key.scalar = k.number;
        keys.push_back(key);
      }
    } else if (!evaluateIndexKeys(keyNodes, keys, err)) {
      if (!err.empty())
        std::cerr << "Error: " << err << "\n";
      evaluationSucceeded_ = false;
      return;
    }

    bool ok;
    if (exists) {
      ok = matIndexSet(varRef(slot, name), true, keys, val, name, err);
    } else {
      Value created;
      ok = matIndexSet(created, false, keys, val, name, err);
      if (ok)
        varSet(slot, name, created);
    }
    if (!ok) {
      std::cerr << "Error: " << err << "\n";
      evaluationSucceeded_ = false;
      return;
    }
    // Auto-print (no trailing ';') shows the whole updated matrix.
    if (!suppressOutput)
      printValue(name, varGet(slot, name));
    return;
  }

  /* Dict key(s): d['key'] = v, d[k1,k2] = [v1,v2]. */
  if (anySliceKey) {
    std::cerr << "Error: ':' is not a dict key - '" << name << "' is a dict\n";
    evaluationSucceeded_ = false;
    return;
  }
  std::vector<Value> keys;
  if (plainKeysEvaluated) {
    keys = plainKeys;
  } else {
    for (const Expr *k : keyNodes)
      keys.push_back(evaluateExpr(k));
    if (!evaluationSucceeded_)
      return;
  }

  if (!exists)
    varSet(slot, name, Value(std::unordered_map<std::string, Value>()));

  if (keys.size() == 1) {
    varRef(slot, name).dictMut()[dictKeyOf(keys[0])] = val;
  } else {
    Value vals = matVectorAsArray(val);
    if (!vals.isArray || vals.length() != keys.size()) {
      std::cerr << "Error: multi-key dict assignment expects " << keys.size()
                << " values, e.g. " << name << "['a','b'] = [1,2]\n";
      evaluationSucceeded_ = false;
      return;
    }
    for (size_t i = 0; i < keys.size(); i++)
      varRef(slot, name).dictMut()[dictKeyOf(keys[i])] = vals.at(i);
  }

  if (!suppressOutput)
    printValue(name, val);
}
