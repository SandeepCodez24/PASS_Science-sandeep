// Core: token cursor, construction, and shared small helpers. The rest of
// Parser's implementation is split across sibling files by concern:
//   parser_expression.cpp   parseOr..parsePower precedence-climbing chain
//   parser_factor.cpp       parseFactor() - literals/calls/indexing
//   parser_program.cpp      parseProgram()/parseStmtNode() - the real
//                            recursive-descent statement/block parser,
//                            driven by ScriptManager::executeFile() (a whole
//                            file) and main.cpp's REPL (one statement at a
//                            time)
//   parser_exec_stmt.cpp    executeProgram()/executeStmt() - the tree-
//                            walking evaluator
#include "parser.h"

/* ================= CORE ================= */

Parser::Parser() : pos(0) { loadFromFile(); }

void Parser::setTokens(const std::vector<Token> &t) {
  tokens = t;
  pos = 0;
}

Token Parser::current() {
  if (pos >= tokens.size())
    return {END, ""};

  return tokens[pos];
}

void Parser::advance() {
  if (pos < tokens.size())
    pos++;
}

/* ================= BLOCK TERMINATORS ================= */

bool Parser::isIfTerm(const std::string &lower) {
  return lower == "iend";
}

bool Parser::isForTerm(const std::string &lower) {
  return lower == "fend";
}

bool Parser::isWhileTerm(const std::string &lower) {
  return lower == "wend";
}
