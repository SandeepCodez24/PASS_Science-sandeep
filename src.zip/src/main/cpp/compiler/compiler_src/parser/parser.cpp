// Core: token cursor, construction, and the top-level entry point. The rest
// of Parser's implementation is split across sibling files by concern:
//   parser_statement.cpp    parseStatement() - what a top-level line does
//   parser_expression.cpp   parseOr..parsePower precedence-climbing chain
//   parser_factor.cpp       parseFactor() - literals/calls/indexing
//   parser_block_exec.cpp   executeForBlock/executeIfBlock/executeWhileBlock
//   parser_block_scan.cpp   executeBlockLines() - nested block boundary scan
#include "parser.h"

/* ================= CORE ================= */

Parser::Parser() : pos(0) { loadFromFile(); }

void Parser::setTokens(const std::vector<Token> &t) {
  tokens = t;
  pos = 0;
}

Token Parser::current() {
  if (pos >= tokens.size())
    return {END, ""};

  return tokens[pos];
}

void Parser::advance() {
  if (pos < tokens.size())
    pos++;
}

/* ================= BLOCK TERMINATORS ================= */

bool Parser::isIfTerm(const std::string &lower) {
  return lower == "end" || lower == "endif" || lower == "iend";
}

bool Parser::isForTerm(const std::string &lower) {
  return lower == "loop end" || lower == "endfor" || lower == "end" ||
         lower == "loop" || lower == "fend";
}

bool Parser::isWhileTerm(const std::string &lower) {
  return lower == "loop end" || lower == "endwhile" || lower == "end" ||
         lower == "wend";
}

/* ================= ENTRY ================= */

Value Parser::parse() {
  Value result(0);

  while (current().type != END) {
    size_t before = pos;
    result = parseStatement();

    // Guard against an infinite loop if a statement fails without
    // consuming any tokens (e.g. a stray/unrecognized token).
    if (pos == before)
      break;
  }

  return result;
}
