// Phase 6 (slot-indexed scope resolution): a one-time-per-registration pass
// over an already-parsed function/method body, assigning each locally
// -assigned variable name a fixed integer slot index into the active call
// frame's Parser::slots_ vector, so evaluateExpr()/executeStmt() can read/
// write it by vector index instead of hashing a string on every single
// access - see Expr::slot's comment (ast.h) and resolveFunctionSlots()'s
// own declaration comment (parser.h) for the full picture. This file only
// computes the resolution; parser_locals.cpp is what actually reads/writes
// slots_ at runtime.
#include "parser.h"

#include <functional>
#include <unordered_map>
#include <unordered_set>

namespace {

// Visits every Stmt reachable within one function/method body - recursing
// into If/For/While's nested bodies (this language has no block scoping,
// so there's no scope boundary to stop at) but treating a *nested*
// FunctionDecl/ClassDecl as an opaque leaf: it gets its own independent
// resolveFunctionSlots() call later, at the point executeStmt() registers
// it at runtime (see registerFunctionDeclStmt()/registerClassDeclStmt()) -
// its parameter/local names must never be resolved against, or pollute,
// the outer function's slot layout.
void walkStmts(const std::vector<std::unique_ptr<Stmt>> &stmts,
               const std::function<void(Stmt *)> &visit);

void walkStmt(Stmt *stmt, const std::function<void(Stmt *)> &visit) {
  if (!stmt)
    return;
  visit(stmt);
  if (stmt->kind == StmtKind::FunctionDecl || stmt->kind == StmtKind::ClassDecl)
    return;
  walkStmts(stmt->body, visit);
  for (const auto &branch : stmt->elseifBranches)
    walkStmts(branch.second, visit);
  walkStmts(stmt->elseBody, visit);
}

void walkStmts(const std::vector<std::unique_ptr<Stmt>> &stmts,
               const std::function<void(Stmt *)> &visit) {
  for (const auto &s : stmts)
    walkStmt(s.get(), visit);
}

// Visits every Expr reachable from `expr` (itself included).
void walkExpr(Expr *expr, const std::function<void(Expr *)> &visit) {
  if (!expr)
    return;
  visit(expr);
  for (const auto &c : expr->children)
    walkExpr(c.get(), visit);
  walkExpr(expr->rangeStart.get(), visit);
  walkExpr(expr->rangeStop.get(), visit);
  walkExpr(expr->rangeStep.get(), visit);
}

// Every Expr reachable from one Stmt's own direct fields - deliberately
// does NOT recurse into nested statement lists (body/elseifBranches/
// elseBody); callers combine this with walkStmt(s) to cover a whole tree.
void forEachExprInStmt(Stmt *stmt, const std::function<void(Expr *)> &visit) {
  walkExpr(stmt->expr.get(), visit);
  for (const auto &t : stmt->targets)
    walkExpr(t.get(), visit);
  walkExpr(stmt->value.get(), visit);
  walkExpr(stmt->condition.get(), visit);
  walkExpr(stmt->iterable.get(), visit);
  for (const auto &branch : stmt->elseifBranches)
    walkExpr(branch.first.get(), visit);
  for (const auto &p : stmt->publishArgs)
    walkExpr(p.get(), visit);
}

// The Expr actually being named by a single-target Assign, unwrapped to its
// base identifier - exactly the same shapes executeAssignStmt()/
// executeIndexAssign() (parser_exec_stmt.cpp) already switch on:
// Identifier -> itself; FieldAccess -> its receiver; Index -> its base
// (one more level down for a nested Index, i.e. A[row][col]). Returns
// nullptr for a target shape that names nothing resolvable (defensive
// only - parser_program.cpp's assignment parsing never builds one).
Expr *unwrapAssignBase(Expr *target) {
  switch (target->kind) {
    case ExprKind::Identifier:
      return target;
    case ExprKind::FieldAccess:
      return target->children[0].get();
    case ExprKind::Index: {
      Expr *base = target->children[0].get();
      if (base->kind == ExprKind::Index)
        return base->children[0].get(); // A[row][col]
      return base;                       // A[key] / A[key1,key2,...]
    }
    default:
      return nullptr;
  }
}

} // namespace

void Parser::resolveFunctionSlots(FunctionDef &def, bool hasBase) {
  std::unordered_map<std::string, int> slotOf;
  std::unordered_set<std::string> excluded;
  int nextSlot = 0;

  // Every name found here keeps its slot for the rest of this function's
  // lifetime (until the next redefinition re-runs this whole pass on a
  // fresh FunctionDef) - callers just get back whatever index a name was
  // first assigned, so referencing the same name from multiple statements
  // is naturally consistent regardless of visitation order.
  auto getOrCreate = [&](const std::string &name) -> int {
    if (excluded.count(name))
      return -1;
    auto it = slotOf.find(name);
    if (it != slotOf.end())
      return it->second;
    int s = nextSlot++;
    slotOf[name] = s;
    return s;
  };
  // Unconditionally allocates a fresh slot, bypassing `excluded` entirely -
  // used only for "base"/"ans", interpreter-managed bookkeeping names that
  // are never subject to a script's own multi-output-target naming.
  auto reserve = [&](const std::string &name) -> int {
    int s = nextSlot++;
    slotOf[name] = s;
    return s;
  };

  // ---- Pass A: exclusions ----
  // A name reassigned via multi-output call `(A,B) = f(...)` anywhere in
  // this body must never be slotted, consistently everywhere in the
  // function - not just at that one statement, since the same name could
  // also appear as a plain assignment target on a different path. This
  // must fully complete before Pass B assigns anything, or a name's
  // slot-vs-memory fate could depend on which occurrence the walk reaches
  // first instead of being a single, whole-function decision.
  walkStmts(def.body, [&](Stmt *s) {
    if (s->kind == StmtKind::Assign && s->targets.size() >= 2) {
      for (const auto &t : s->targets)
        excluded.insert(t->text);
    }
  });

  // ---- Pass B: assign slots, stamp write targets ----
  def.inputSlots.clear();
  for (const auto &name : def.inputNames)
    def.inputSlots.push_back(getOrCreate(name));

  if (hasBase)
    def.baseSlot = reserve("base");
  else
    def.baseSlot = -1;
  def.ansSlot = reserve("ans");

  walkStmts(def.body, [&](Stmt *s) {
    if (s->kind == StmtKind::Assign && s->targets.size() == 1) {
      Expr *base = unwrapAssignBase(s->targets[0].get());
      if (base)
        base->slot = getOrCreate(base->text);
    } else if (s->kind == StmtKind::For) {
      s->loopVarSlot = getOrCreate(s->loopVar);
    }
  });

  def.outputSlots.clear();
  for (const auto &name : def.outputNames)
    def.outputSlots.push_back(getOrCreate(name));

  // ---- Pass C: stamp every read ----
  // A name never found above (a constant like `pi`, an excluded name, or
  // simply a typo/undefined variable) stays at its default -1 and falls
  // through to exactly the same memory/constant/unit-constant/zero-arg
  // -function-call chain evaluateExpr() already runs today.
  walkStmts(def.body, [&](Stmt *s) {
    forEachExprInStmt(s, [&](Expr *e) {
      if (e->kind == ExprKind::Identifier || e->kind == ExprKind::FieldAccess) {
        auto it = slotOf.find(e->text);
        e->slot = (it != slotOf.end()) ? it->second : -1;
      }
    });
  });

  def.slotCount = nextSlot;
}
