#ifndef TOKEN_H
#define TOKEN_H

#include <string>

enum TokenType {
  NUMBER,
  IDENT,
  STRING,
  PLUS,
  MINUS,
  MUL,
  DIV,
  MOD,
  QUOT,
  POW,
  FACT,
  ASSIGN,
  LPAREN,
  RPAREN,
  LBRACE,
  RBRACE,
  LBRACKET,
  RBRACKET,
  SEMICOLON,
  COMMA,
  EQ,
  NEQ,
  LT,
  GT,
  LTE,
  GTE,
  AND,
  OR,
  DOT,
  IF,
  ELSE,
  PRINT,
  PUBLISH,
  FOR,
  IN,
  LOOP,
  COLON,
  END,
  WHILE,
  NAND,
  NOR,
  IS_IN,
  IS_NOT_IN,
  ELSEIF,
  BREAK,
  CONTINUE,
  FUNCTION,
  RETURN,
  CLASS,
  PRIVATE,
  PROTECTED,
  ABSTRACT,
  REQUIRE,
  ENSURE,
  REVERSIBLE,
  AT
};

struct Token {
  TokenType type;
  std::string text;
};
#endif