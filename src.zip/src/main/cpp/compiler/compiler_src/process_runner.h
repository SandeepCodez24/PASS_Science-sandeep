// The Process Data window's native ops (2026-11-17, docs/Process_Window_CPP.md):
//
//   P2  @cmd io {"op":"process", "mode":"check"|"run", "data":"A",
//                "target":"y", "out":"A_processed", "helpers":"function ...",
//                "sample":0, "steps":[{"index":1, "filter":"casting",
//                "code":"Y = float32(Y);", "on":"numbers", "table":"columns",
//                "columns":["Temp"]}, ...]}
//       Each step runs as its own function  Y = step(X, Y, target):  its
//       locals are dropped when it ends, X is the data (a copy-on-write view,
//       nothing is copied until a step writes), target the target variable
//       (0 when none). One @IOEV "step" event per step:
//         {"kind":"step","index":1,"ok":true,"class":"float32","size":"200x6","seconds":0.004}
//         {"kind":"step","index":2,"ok":false,"error":"Unknown function 'tril'","line":1}
//       then one @IO answer:
//         {"op":"process","ok":false,"mode":"check","stopped_at":2,"cancelled":false,
//          "seconds":0.05,"class":...,"size":...,"error":...}
//       "check" keeps nothing and prints no error (the events carry them);
//       "run" assigns `out` only when every step passed, and its errors are
//       printed in the Command Window as for any command. Stop (the IDE's
//       interrupt.flag) ends the run between and inside steps.
//       sample > 0 (check only, no Shape step): the first `sample` rows.
//
//   P6  A loaded table (NcTable, NcParquet ... - an object with cols / data)
//       is processed column by column (user decision 2026-11-17): each step
//       runs on every column (Y = that column), the result is a table of the
//       same class with its other fields kept. Per step:
//         "on": "text" | "numbers"  only the columns of that kind (default all)
//         "columns": [names]        only these columns
//         "table": "whole"          the step gets the whole table as Y instead
//                                   (rmmissing(Y), sortrows(Y, "Temp") ...)
//       A per-column step that changes a column's length is an error (rows
//       must go through a whole-table step); one that makes an n x k matrix
//       (onehot) turns the column into k columns name_0 .. name_k-1.
//
//   P4  @cmd io {"op":"check","code":"..."} - parse only, nothing runs:
//         {"op":"check","ok":true,"valid":false,
//          "errors":[{"line":2,"col":11,"message":"..."}]}
#ifndef NC_PROCESS_RUNNER_H
#define NC_PROCESS_RUNNER_H

#include <string>

class Parser;

namespace nc {
namespace process {

// kind: "process" or "check"; json: the whole request.
void handleRequest(Parser &parser, const std::string &kind, const std::string &id,
                   const std::string &json);

} // namespace process
} // namespace nc

#endif // NC_PROCESS_RUNNER_H
