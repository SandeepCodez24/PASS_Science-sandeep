#include "lexer.h"
#include <cctype>

/* ================= CONSTRUCTOR ================= */

Lexer::Lexer(const std::string &src) {
  text = src;
  pos = 0;
}

/* ================= CURRENT CHAR ================= */

char Lexer::current() {
  if (pos >= text.size())
    return '\0';

  return text[pos];
}

/* ================= ADVANCE ================= */

void Lexer::advance() {
  if (pos < text.size())
    pos++;
}

/* ================= TOKENIZE ================= */

std::vector<Token> Lexer::tokenize() {
  std::vector<Token> tokens;

  while (pos < text.size()) {
    char c = current();

    /* WHITESPACE */

    if (std::isspace(c)) {
      advance();
      continue;
    }

    /* STRING */

    if (c == '"') {
      advance();

      std::string str;

      while (current() != '"' && current() != '\0') {
        str += current();
        advance();
      }

      advance();

      tokens.push_back({STRING, str});
      continue;
    }

    /* STRING (single-quoted) */

    if (c == '\'') {
      advance();

      std::string str;

      while (current() != '\'' && current() != '\0') {
        str += current();
        advance();
      }

      advance();

      tokens.push_back({STRING, str});
      continue;
    }

    /* NUMBER */

    // A bare '.' (not followed by a digit) is the DOT operator token,
    // handled further below — only treat '.' as the start of a numeric
    // literal (e.g. ".5") when a digit immediately follows it.
    if (std::isdigit(c) ||
        (c == '.' && pos + 1 < text.size() && std::isdigit(text[pos + 1]))) {
      bool dotSeen = false;
      std::string num;

      while (pos < text.size()) {
        if (std::isdigit(text[pos])) {
          num += text[pos];
          pos++;
        }

        else if (text[pos] == '.') {
          if (dotSeen)
            break;

          dotSeen = true;

          num += '.';
          pos++;
        } else
          break;
      }

      if (pos < text.size() && (text[pos] == 'e' || text[pos] == 'E')) {
        size_t exponentEnd = pos + 1;

        if (exponentEnd < text.size() &&
            (text[exponentEnd] == '+' || text[exponentEnd] == '-')) {
          exponentEnd++;
        }

        size_t exponentDigitsStart = exponentEnd;

        while (exponentEnd < text.size() && std::isdigit(text[exponentEnd])) {
          exponentEnd++;
        }

        if (exponentEnd > exponentDigitsStart) {
          num += text.substr(pos, exponentEnd - pos);
          pos = exponentEnd;
        }
      }

      tokens.push_back({NUMBER, num});
      continue;
    }
    /* IDENTIFIER */

    if (std::isalpha(c) || c == '_') {
      std::string ident;

      while (pos < text.size() &&
             (std::isalnum(text[pos]) || text[pos] == '_')) {
        ident += text[pos];
        pos++;
      }

      if (ident == "true")
        tokens.push_back({NUMBER, "1"});

      else if (ident == "false")
        tokens.push_back({NUMBER, "0"});

      else if (ident == "print")
        tokens.push_back({PRINT, ident});

      else if (ident == "publish")
        tokens.push_back({PUBLISH, ident});

      else if (ident == "for")
        tokens.push_back({FOR, ident});

      else if (ident == "in")
        tokens.push_back({IN, ident});

      else if (ident == "loop")
        tokens.push_back({LOOP, ident});

      else if (ident == "if")
        tokens.push_back({IF, ident});

      else if (ident == "else")
        tokens.push_back({ELSE, ident});

      else if (ident == "while")
        tokens.push_back({WHILE, ident});

      else if (ident == "elseif")
        tokens.push_back({ELSEIF, ident});

      else if (ident == "is_in")
        tokens.push_back({IS_IN, ident});

      else if (ident == "is_not_in")
        tokens.push_back({IS_NOT_IN, ident});

      else if (ident == "break")
        tokens.push_back({BREAK, ident});

      else if (ident == "continue")
        tokens.push_back({CONTINUE, ident});

      else if (ident == "function")
        tokens.push_back({FUNCTION, ident});

      else if (ident == "return")
        tokens.push_back({RETURN, ident});

      else if (ident == "class")
        tokens.push_back({CLASS, ident});

      else if (ident == "private")
        tokens.push_back({PRIVATE, ident});

      else if (ident == "protected")
        tokens.push_back({PROTECTED, ident});

      else if (ident == "abstract")
        tokens.push_back({ABSTRACT, ident});

      else if (ident == "require")
        tokens.push_back({REQUIRE, ident});

      else if (ident == "ensure")
        tokens.push_back({ENSURE, ident});

      else if (ident == "reversible")
        tokens.push_back({REVERSIBLE, ident});

      else
        tokens.push_back({IDENT, ident});

      continue;
    }
    /* OPERATORS */

    if (c == '+') {
      tokens.push_back({PLUS, "+"});
      advance();
      continue;
    }
    if (c == '-') {
      tokens.push_back({MINUS, "-"});
      advance();
      continue;
    }
    if (c == '*') {
      tokens.push_back({MUL, "*"});
      advance();
      continue;
    }
    if (c == '.') {
      tokens.push_back({DOT, "."});
      advance();
      continue;
    }
    if (c == '@') {
      tokens.push_back({AT, "@"});
      advance();
      continue;
    }

    if (c == '/') {
      advance();

      if (current() == '/') {
        advance();
        tokens.push_back({QUOT, "//"});
      } else {
        tokens.push_back({DIV, "/"});
      }

      continue;
    }
    if (c == '^') {
      tokens.push_back({POW, "^"});
      advance();
      continue;
    }
    if (c == '#') {
      while (pos < text.size() && current() != '\n' && current() != '\r') {
        advance();
      }
      continue;
    }

    if (c == '%') {
      if (tokens.empty() || tokens.back().type == END) {
        while (pos < text.size() && current() != '\n' && current() != '\r') {
          advance();
        }
        continue;
      }
      tokens.push_back({MOD, "%"});
      advance();
      continue;
    }

    if (c == '!' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({NEQ, "!="});
      pos += 2;
      continue;
    }
    if (c == '!' && pos + 1 < text.size() && text[pos + 1] == '&') {
      tokens.push_back({NAND, "!&"});
      pos += 2;
      continue;
    }
    if (c == '!' && pos + 1 < text.size() && text[pos + 1] == '|') {
      tokens.push_back({NOR, "!|"});
      pos += 2;
      continue;
    }
    if (c == '!') {
      tokens.push_back({FACT, "!"});
      advance();
      continue;
    }

    if (c == '=' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({EQ, "=="});
      pos += 2;
      continue;
    }

    if (c == '=') {
      tokens.push_back({ASSIGN, "="});
      advance();
      continue;
    }

    if (c == '<' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({LTE, "<="});
      pos += 2;
      continue;
    }

    if (c == '>' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({GTE, ">="});
      pos += 2;
      continue;
    }

    if (c == '<') {
      tokens.push_back({LT, "<"});
      advance();
      continue;
    }
    if (c == '>') {
      tokens.push_back({GT, ">"});
      advance();
      continue;
    }

    if (c == '&' && pos + 1 < text.size() && text[pos + 1] == '&') {
      tokens.push_back({AND, "&&"});
      pos += 2;
      continue;
    }

    if (c == '|' && pos + 1 < text.size() && text[pos + 1] == '|') {
      tokens.push_back({OR, "||"});
      pos += 2;
      continue;
    }

    /* BRACKETS */

    if (c == '(') {
      tokens.push_back({LPAREN, "("});
      advance();
      continue;
    }
    if (c == ')') {
      tokens.push_back({RPAREN, ")"});
      advance();
      continue;
    }

    if (c == '[') {
      tokens.push_back({LBRACKET, "["});
      advance();
      continue;
    }
    if (c == ']') {
      tokens.push_back({RBRACKET, "]"});
      advance();
      continue;
    }

    if (c == '{') {
      tokens.push_back({LBRACE, "{"});
      advance();
      continue;
    }
    if (c == '}') {
      tokens.push_back({RBRACE, "}"});
      advance();
      continue;
    }

    if (c == ';') {
      tokens.push_back({SEMICOLON, ";"});
      advance();
      continue;
    }
    if (c == ',') {
      tokens.push_back({COMMA, ","});
      advance();
      continue;
    }
    if (c == ':') {
      tokens.push_back({COLON, ":"});
      advance();
      continue;
    }

    advance();
  }

  tokens.push_back({END, ""});
  return tokens;
}