#pragma once

#include <string>
#include <vector>
#include "token.h"

class Lexer
{
private:

    std::string text;

    size_t pos = 0;

    char current();

    void advance();

public:

    Lexer(const std::string& input);

    std::vector<Token> tokenize();
};