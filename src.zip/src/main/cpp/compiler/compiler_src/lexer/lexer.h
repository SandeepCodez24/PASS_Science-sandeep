#pragma once

#include <string>
#include <vector>
#include "token.h"

class Lexer
{
private:

    std::string text;

    size_t pos = 0;

    // 1-based; advance() maintains these as it consumes characters.
    size_t line = 1;
    size_t col = 1;

    char current();

    void advance();

public:

    Lexer(const std::string& input);

    std::vector<Token> tokenize();
};