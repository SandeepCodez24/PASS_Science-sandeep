// Unit tests for nc::par (runtime/execution/parallel/). Stand-alone - no
// interpreter - so they are the first thing to run on a new OS or backend:
//
//   cmake --build <build dir> --target nc_par_tests
//   nc_par_tests            (exit code 0 = every test passed)
//
// Build the same tests against each backend (-DNC_PAR_BACKEND=OPENMP,
// STDPOOL, SERIAL); all must pass on all three.

#include "Interrupt.h"
#include "analysis/analysis.h"
#include "par.h"
#include "par_monitor.h"
#include "sys_cpu.h"

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {

int g_failures = 0;
int g_checks = 0;

void check(bool ok, const std::string &what) {
  g_checks++;
  if (!ok) {
    g_failures++;
    std::printf("  FAIL: %s\n", what.c_str());
  }
}

using nc::par::Outcome;

/* ---- plan(): block sizes from the design table (section 4.1) ---- */
void testPlan() {
  std::printf("plan\n");
  check(nc::par::plan(0, nc::par::stream(1.1)).blocks == 0, "n = 0 has no blocks");
  check(nc::par::plan(1000, nc::par::compute(6)).blocks == 1, "small work is one block");
  check(nc::par::plan(100000, nc::par::stream(1.1)).blocks == 1, "110 us of work stays serial");
  check(nc::par::plan(9000000, nc::par::stream(1.1)).blockSize == 32768, "add: 32k blocks");
  check(nc::par::plan(9000000, nc::par::compute(5.8)).blockSize == 8192, "sin: 8k blocks");
  check(nc::par::plan(9000000, nc::par::compute(27.8)).blockSize == 2048, "lgamma: 2k blocks");
  check(nc::par::plan(228000, nc::par::compute(1600)).blockSize == 1024, "format_time: 1024");
  // Blocks never depend on the thread count.
  const int saved = nc::par::threadCount();
  nc::par::setThreadCount(1);
  const nc::par::Plan p1 = nc::par::plan(9000000, nc::par::compute(5.8));
  nc::par::setThreadCount(7);
  const nc::par::Plan p7 = nc::par::plan(9000000, nc::par::compute(5.8));
  nc::par::setThreadCount(saved);
  check(p1.blocks == p7.blocks && p1.blockSize == p7.blockSize, "blocks independent of threads");
  check(p1.threads == 1, "1 thread setting -> serial");
  // Stream work is capped at 8 threads.
  nc::par::setThreadCount(64);
  check(nc::par::plan(90000000, nc::par::stream(1.1)).threads <= 8, "stream cap 8");
  check(nc::par::plan(90000000, nc::par::reduce(0.7)).threads <= 16, "reduce cap 16");
  nc::par::setThreadCount(saved);
}

/* ---- forBlocks covers [0, n) exactly once, at any thread count ---- */
void testCoverage() {
  std::printf("coverage\n");
  const int saved = nc::par::threadCount();
  const size_t sizes[] = {0, 1, 1023, 1024, 1025, 200000, 1000003};
  for (int threads : {1, 2, 3, 8, nc::par::logicalProcessors()}) {
    nc::par::setThreadCount(threads);
    for (size_t n : sizes) {
      std::vector<std::atomic<int>> hits(n);
      const Outcome r = nc::par::forBlocks(n, nc::par::compute(50), "coverage", [&](size_t b, size_t e) {
        for (size_t k = b; k < e; k++)
          hits[k].fetch_add(1);
      });
      bool once = r == Outcome::Done;
      for (size_t k = 0; k < n && once; k++)
        once = hits[k].load() == 1;
      check(once, "every index once: n=" + std::to_string(n) + " threads=" + std::to_string(threads));
    }
  }
  nc::par::setThreadCount(saved);
}

/* ---- reductions are bit-identical for every thread count and order ---- */
double sumWith(const std::vector<double> &x) {
  double out = 0;
  nc::par::reduceBlocks(
      x.size(), nc::par::reduce(0.7), "sum", 0.0,
      [&](size_t b, size_t e) {
        double s = 0;
        for (size_t k = b; k < e; k++)
          s += x[k];
        return s;
      },
      [](double a, double p) { return a + p; }, out);
  return out;
}

void testDeterminism() {
  std::printf("determinism\n");
  std::vector<double> x(3000017);
  for (size_t k = 0; k < x.size(); k++)
    x[k] = std::sin(0.001 * static_cast<double>(k)) * 1e3 + 1.0 / (1.0 + static_cast<double>(k));
  const int saved = nc::par::threadCount();
  nc::par::setThreadCount(1);
  const double reference = sumWith(x);
  for (int threads : {1, 2, 3, 8, nc::par::logicalProcessors()}) {
    nc::par::setThreadCount(threads);
    for (auto order : {nc::par::BlockOrder::Normal, nc::par::BlockOrder::Reverse,
                       nc::par::BlockOrder::Shuffle}) {
      nc::par::setBlockOrder(order, 12345);
      const double s = sumWith(x);
      check(std::memcmp(&s, &reference, sizeof s) == 0,
            "same bits: threads=" + std::to_string(threads) + " order=" +
                std::to_string(static_cast<int>(order)));
    }
  }
  nc::par::setBlockOrder(nc::par::BlockOrder::Normal);
  // Below one block the reduction is the plain left-to-right loop.
  std::vector<double> small(x.begin(), x.begin() + 5000);
  double plain = 0;
  for (double v : small)
    plain += v;
  const double viaPar = sumWith(small);
  check(std::memcmp(&plain, &viaPar, sizeof plain) == 0, "one block == plain loop");
  nc::par::setThreadCount(saved);
}

/* ---- nesting: a region inside a block runs serially ---- */
void testNesting() {
  std::printf("nesting\n");
  std::atomic<int> nestedParallel{0};
  std::atomic<long long> total{0};
  // Only a parallel run opens a region (a serial one is a plain loop).
  const bool outerParallel = nc::par::taskPlan(64, 1e6).threads > 1;
  nc::par::tasks(64, 1e6, "outer", [&](size_t) {
    if (outerParallel && !nc::par::inRegion())
      nestedParallel++;
    if (nc::par::plan(10000000, nc::par::compute(10)).threads != 1)
      nestedParallel++;
    long long local = 0;
    nc::par::forBlocks(100000, nc::par::compute(10), "inner", [&](size_t b, size_t e) {
      local += static_cast<long long>(e - b); // serial: no race on `local`
    });
    total += local;
  });
  check(nestedParallel.load() == 0, "inner plan is serial inside a block");
  check(total.load() == 64LL * 100000, "inner regions ran completely");
  check(!nc::par::inRegion(), "inRegion() false again afterwards");
}

/* ---- errors: lowest item index wins; exceptions are rethrown ---- */
void testErrors() {
  std::printf("errors\n");
  for (int threads : {1, 4, nc::par::logicalProcessors()}) {
    nc::par::setThreadCount(threads);
    nc::par::BlockError err;
    const Outcome r = nc::par::forBlocks(
        2000000, nc::par::compute(20), "errors",
        [&](size_t b, size_t e) {
          for (size_t k = b; k < e; k++)
            if (k == 777777 || k == 1500000 || k == 1999999)
              err.report(k, "bad element " + std::to_string(k));
        },
        &err);
    check(r == Outcome::Failed, "outcome Failed, threads=" + std::to_string(threads));
    check(err.item() == 777777 && err.message() == "bad element 777777",
          "lowest index kept, threads=" + std::to_string(threads));

    bool caught = false;
    try {
      nc::par::forBlocks(2000000, nc::par::compute(20), "throws", [&](size_t b, size_t e) {
        for (size_t k = b; k < e; k++)
          if (k == 123456 || k == 1888888)
            throw std::runtime_error("element " + std::to_string(k));
      });
    } catch (const std::runtime_error &e) {
      caught = std::string(e.what()) == "element 123456";
    }
    check(caught, "lowest-block exception rethrown, threads=" + std::to_string(threads));
  }
  nc::par::setThreadCount(0);
}

/* ---- Stop ends a region between blocks ---- */
void testStop() {
  std::printf("stop\n");
  std::atomic<size_t> done{0};
  const auto start = std::chrono::steady_clock::now();
  const Outcome r = nc::par::forBlocks(400000000, nc::par::compute(5), "stop", [&](size_t b, size_t e) {
    if (b >= 20 * 8192)
      nc::Interrupt::request(); // "Stop pressed" a few blocks in
    volatile double x = 0;
    for (size_t k = b; k < e; k++)
      x = x + 1.0;
    done += e - b;
  });
  const double ms =
      std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
  check(r == Outcome::Stopped, "outcome Stopped");
  check(done.load() < 400000000, "did not finish the work");
  check(ms < 1000, "stopped quickly (" + std::to_string(ms) + " ms)");
  nc::Interrupt::clear();
  const Outcome again = nc::par::forBlocks(1000000, nc::par::compute(5), "after", [](size_t, size_t) {});
  check(again == Outcome::Done, "next region runs normally after clear()");
}

/* ---- OS layer ---- */
void testSystem() {
  std::printf("system (%s, backend %s, %d logical processors)\n", nc::par::sys::osName(),
              nc::par::backendName(), nc::par::logicalProcessors());
  check(nc::par::logicalProcessors() >= 1, "logical processors >= 1");
  std::vector<nc::par::sys::CoreTimes> cores;
  const bool ok = nc::par::sys::coreTimes(cores);
  std::printf("  per-core load: %s (%zu cores)\n", ok ? "available" : "not available", cores.size());
  if (ok)
    check(!cores.empty() && cores[0].total >= cores[0].busy, "core times are sane");
  const uint64_t c0 = nc::par::sys::processCpuNs();
  volatile double x = 0;
  for (int k = 0; k < 50000000; k++)
    x = x + std::sqrt(static_cast<double>(k));
  check(nc::par::sys::processCpuNs() > c0, "process CPU time advances");
}

/* ---- the IDE monitor writes its snapshot and summary ---- */
void testMonitor() {
  std::printf("monitor\n");
  const std::filesystem::path dir =
      std::filesystem::temp_directory_path() / ("nc_par_tests_" + std::to_string(std::rand()));
  std::filesystem::create_directories(dir);
  nc::par::monitor::configure(dir.string());
  nc::par::monitor::setIntervalMs(100);
  nc::par::monitor::setEnabled(true);

  nc::par::monitor::commandStarted();
  const auto until = std::chrono::steady_clock::now() + std::chrono::milliseconds(600);
  while (std::chrono::steady_clock::now() < until)
    nc::par::forBlocks(20000000, nc::par::compute(2), "monitor test", [](size_t b, size_t e) {
      volatile double x = 0;
      for (size_t k = b; k < e; k++)
        x = x + 1.0;
    });
  nc::par::monitor::commandFinished();
  const std::string summary = nc::par::monitor::takeCommandSummary();
  check(summary.find("\"type\":\"parmon_summary\"") != std::string::npos, "summary line produced");
  check(summary.find("\"label\":\"monitor test\"") != std::string::npos, "summary names the kernel");

  std::this_thread::sleep_for(std::chrono::milliseconds(300)); // the final snapshot
  std::ifstream in(dir / "parmon.json");
  std::stringstream text;
  text << in.rdbuf();
  check(text.str().find("\"type\":\"parmon\"") != std::string::npos, "parmon.json written");
  check(text.str().find("\"state\":\"idle\"") != std::string::npos, "last snapshot says idle");

  // A short command leaves no trace.
  nc::par::monitor::commandStarted();
  nc::par::monitor::commandFinished();
  check(nc::par::monitor::takeCommandSummary().empty(), "short serial command: no summary");

  nc::par::monitor::setEnabled(false);
  std::error_code ec;
  std::filesystem::remove_all(dir, ec);
}

/* ---- Analysis box: order of growth and time text ---- */
void testGrowth() {
  std::printf("growth\n");
  struct Case {
    const char *key;
    double (*work)(double);
  };
  const Case cases[] = {
      {"n", [](double k) { return 40.0 * k + 500.0; }},              // setup cost + linear
      {"nlogn", [](double k) { return 7.0 * k * std::log(k) + 3.0 * k; }},
      {"n2", [](double k) { return 0.5 * k * (k + 1) + 10.0 * k; }}, // triangular loop
      {"n2logn", [](double k) { return k * k * std::log(k); }},
      {"n3", [](double k) { return k * k * k / 3.0 + k * k; }},
      {"2n", [](double k) { return std::pow(2.0, k / 4.0) * 100.0; }},
  };
  for (const Case &c : cases) {
    std::vector<double> k, w;
    const double last = std::string(c.key) == "2n" ? 120.0 : 5000.0;
    for (double x = 1, next = 1; x <= last; x++)
      if (x >= next) {
        k.push_back(x);
        // +-1 % deterministic noise
        w.push_back(c.work(x) * (1.0 + 0.01 * std::sin(x * 12.9898)));
        next = std::max(x + 1, std::ceil(x * 1.05));
      }
    const nc::analysis::GrowthFit f = nc::analysis::fitGrowth(k.data(), w.data(), k.size());
    check(f.ok && f.key == c.key,
          std::string("fit ") + c.key + " -> " + (f.ok ? f.key + " (" + f.confidence + ")" : f.reason));
  }
  std::vector<double> few{2, 3, 4}, fw{2, 3, 4};
  check(!nc::analysis::fitGrowth(few.data(), fw.data(), few.size()).ok, "too few iterations: no fit");

  check(nc::analysis::formatDuration(0.35) == "350 ms", "350 ms");
  check(nc::analysis::formatDuration(12.44) == "12.4 s", "12.4 s");
  check(nc::analysis::formatDuration(187.0) == "3 min 07 s", "3 min 07 s");
  check(nc::analysis::formatDuration(3849.0) == "1 h 04 min 09 s", "1 h 04 min 09 s");
}

} // namespace

int main() {
  nc::par::initialize();
  testPlan();
  testCoverage();
  testDeterminism();
  testNesting();
  testErrors();
  testStop();
  testSystem();
  testMonitor();
  testGrowth();
  std::printf("\n%d checks, %d failed\n", g_checks, g_failures);
  return g_failures == 0 ? 0 : 1;
}
