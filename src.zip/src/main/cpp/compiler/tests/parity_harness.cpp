// Step 5 of the LLVM codegen/JIT/AOT roadmap: permanent parity harness.
//
// Unlike the ad hoc /tmp test files used to verify Steps 2 and 3 (correctly
// deleted once those steps were confirmed working), this file is checked-in
// project infrastructure - the ongoing safety net for the codegen/JIT
// effort as a whole. Built as the `nc_parity_tests` CMake target (see
// src/main/cpp/CMakeLists.txt's if(LLVM_FOUND) block) - only exists when
// LLVM is present, same soft-dependency principle as the rest of this work.
//
// For each seeded case, runs an NC script two ways - the real tree-walker
// (Lexer + Parser::parseStmtNode + executeStmt) and the Step 4 JitEngine -
// against separate, freshly-constructed Parser instances, then diffs the
// results: the resulting Value(s) read back afterward (compared via
// valuesDeepEqual(), conditional_opr.h - the same structural-equality
// function NC's own `==` operator is built on, reused here rather than
// re-deriving comparison logic, so this stays correct once
// array/matrix/dict-producing ops eventually get bridged too, not just the
// numbers everything currently in scope produces), and any stdout each run
// produced (for Publish cases).
//
// How to add a case:
//   - Most cases are a short script assigning into `r` - append a
//     {label, script} pair to SIMPLE_CASES.
//   - Cases needing custom setup (multiple statements, control flow,
//     checking printed output, or - like runInterleavingCase() - genuinely
//     mixing JIT and tree-walker calls against ONE shared Parser rather
//     than two separate runs diffed afterward) get their own function;
//     call it from main().
//
// Coverage as of the classes slice: every BinaryOp/UnaryOp/Comparison/
// LogicalOp/AbsOrNorm case, multi-statement variable sharing, Publish,
// If/elseif/else (all branches), While with break, While with continue,
// For-range with and without an explicit step, For-range with break/
// continue, a simple function call, a function using control flow
// internally, a recursive function, a multi-output function + multi-
// target Assign, array literal + index read/write, matrix literal +
// chained/comma-form read/write, dict auto-vivify + read, a plain class
// (constructor + field write, field read, one instance method), and the
// JIT/tree-walker interleaving case.

#include "../compiler_src/ast/ast.h"
#include "../compiler_src/codegen/jit_engine.h"
#include "../compiler_src/conditional_opr/conditional_opr.h"
#include "../compiler_src/lexer/lexer.h"
#include "../compiler_src/parser/parser.h"
#include "output.h" // valueToString() - runtime/interpreter/core, already on the include path
#include "../../runtime/interpreter/core/ScriptManager/SM_main.h"

#include <cstdio>
#include <filesystem>
#include <fstream>

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace {

int failures = 0;

void report(const std::string &label, bool pass, const std::string &detail = "") {
  if (pass) {
    std::cout << "OK   " << label << "\n";
  } else {
    std::cerr << "FAIL " << label << (detail.empty() ? "" : (": " + detail)) << "\n";
    failures++;
  }
}

// Captures everything written to std::cout during fn().
template <typename Fn>
std::string captureStdout(Fn &&fn) {
  std::ostringstream capture;
  std::streambuf *old = std::cout.rdbuf(capture.rdbuf());
  fn();
  std::cout.rdbuf(old);
  return capture.str();
}

// Parses one line into an AST Stmt via a throwaway, dedicated-to-parsing
// Parser (never executed, never shared across calls) - mirrors how the
// real REPL (main.cpp) and Steps 2/3's own tests lex+parse one statement
// at a time. Only suitable for a single, complete, one-line statement -
// see parseScript() below for multi-line constructs (If/While/For), which
// need their whole body tokenized and parsed together.
std::unique_ptr<Stmt> parseLine(const std::string &line) {
  Parser parseOnly;
  Lexer lex(line);
  auto toks = lex.tokenize();
  parseOnly.setTokens(toks);
  return parseOnly.parseStmtNode();
}

// Joins `lines` with '\n' and parses the WHOLE thing as one token stream
// via Parser::parseProgram() - required once control flow is in the mix:
// an If/While/For's header, body, and closing keyword (iend/wend/fend)
// must all come from the same parseStmtNode() call, which needs every one
// of those tokens available up front, not doled out one line at a time
// (that's how main.cpp's own REPL buffers a multi-line construct before
// parsing it - see its ReplBlockKind handling). Also just works for the
// single-line/simple cases (a one-statement "program"), so this is what
// runTreeWalker()/runViaJit() use uniformly now, not just the control-flow
// cases below.
Program parseScript(const std::vector<std::string> &lines) {
  std::string full;
  for (const auto &line : lines) {
    full += line;
    full += "\n";
  }
  Parser parseOnly;
  Lexer lex(full);
  auto toks = lex.tokenize();
  return parseOnly.parseProgram(toks);
}

// Runs `lines` (joined into one script - see parseScript()) through the
// real tree-walker on a fresh Parser; keeps that Parser alive (for reading
// back variables afterward) and captures everything it printed.
struct TreeWalkerRun {
  std::unique_ptr<Parser> parser;
  std::string stdout_;
};

TreeWalkerRun runTreeWalker(const std::vector<std::string> &lines) {
  Program prog = parseScript(lines);
  TreeWalkerRun result;
  result.parser = std::make_unique<Parser>();
  Parser *p = result.parser.get();
  result.stdout_ = captureStdout([&] {
    for (const auto &stmt : prog.statements)
      p->executeStmt(stmt.get());
  });
  return result;
}

// Runs `lines` (joined into one script) through a fresh JitEngine against
// a fresh Parser - one engine per run, one runStmt() call per top-level
// statement (an If/While/For counts as ONE statement here, same as the
// tree-walker sees it - its whole body is compiled into the one entry
// function runStmt() builds for it). `ok` is false if any statement's
// codegen was rejected (out of scope for the current slice).
struct JitRun {
  std::unique_ptr<Parser> parser;
  std::string stdout_;
  bool ok = true;
};

JitRun runViaJit(const std::vector<std::string> &lines) {
  Program prog = parseScript(lines);
  JitRun result;
  result.parser = std::make_unique<Parser>();
  Parser *p = result.parser.get();
  JitEngine engine;
  result.stdout_ = captureStdout([&] {
    for (const auto &stmt : prog.statements)
      if (!engine.runStmt(stmt.get(), *p))
        result.ok = false;
  });
  return result;
}

void checkVar(const std::string &label, TreeWalkerRun &tw, JitRun &jit, const std::string &varName) {
  if (!jit.ok) {
    report(label, false, "JIT run reported an unsupported statement");
    return;
  }
  Value twVal = tw.parser->readVariableOrConstant(varName, -1);
  Value jitVal = jit.parser->readVariableOrConstant(varName, -1);
  report(label, valuesDeepEqual(twVal, jitVal),
         "tree-walker " + varName + "=" + std::to_string(twVal.number) +
             " jit " + varName + "=" + std::to_string(jitVal.number));
}

void checkStdout(const std::string &label, TreeWalkerRun &tw, JitRun &jit) {
  if (!jit.ok) {
    report(label, false, "JIT run reported an unsupported statement");
    return;
  }
  report(label, tw.stdout_ == jit.stdout_,
         "tree-walker printed [" + tw.stdout_ + "] jit printed [" + jit.stdout_ + "]");
}

// ---- Simple cases: one assignment script, read back `r` ----
// Seeded with every case already proved working across Steps 2/3.
struct SimpleCase {
  const char *label;
  const char *script;
};

const SimpleCase SIMPLE_CASES[] = {
    // BinaryOp (7 ops)
    {"add", "r = 7 + 5"},
    {"sub", "r = 7 - 5"},
    {"mul", "r = 7 * 5"},
    {"div", "r = 7 / 5"},
    {"mod", "r = 7 % 5"},
    {"floordiv", "r = 7 // 5"},
    {"pow", "r = 2 ^ 10"},
    // UnaryOp (2 ops) + AbsOrNorm
    {"neg", "r = -9"},
    {"not", "r = !0"},
    {"abs", "r = |-9|"},
    // Comparison (6 ops)
    {"eq", "r = 5 == 5"},
    {"neq", "r = 5 != 3"},
    {"lt", "r = 3 < 5"},
    {"gt", "r = 5 > 3"},
    {"lte", "r = 5 <= 5"},
    {"gte", "r = 5 >= 5"},
    // LogicalOp (4 ops) - real lexed syntax is symbolic (!&/!|), not the
    // English words "nand"/"nor" the AST's own node text happens to use
    // internally (see codegen.cpp's logicalOpBridgeName() comment - a
    // Step 2 test bug once masked this exact distinction).
    {"and", "r = 1 && 0"},
    {"or", "r = 1 || 0"},
    {"nand", "r = 1 !& 0"},
    {"nor", "r = 1 !| 0"},
};

void runSimpleCases() {
  for (const auto &c : SIMPLE_CASES) {
    auto tw = runTreeWalker({c.script});
    auto jit = runViaJit({c.script});
    checkVar(c.label, tw, jit, "r");
  }
}

// ---- Complex numbers: imaginary literals and the complex builtins ----
// The literal has its own path on each side (evaluateExpr()'s
// NumberLiteral case vs codegen's nc_bridge_value_set_imaginary), so it is
// the part most able to drift apart. Compared by printed output AND by
// variable state: checkVar()'s valuesDeepEqual() looks at both parts.
void runComplexLiteralCase() {
  std::vector<std::string> lines = {
      "a = 3i;",          "b = 2.5j;",          "c = 1e3i;",       "z = complex(3, -4);",
      "print(a)",         "print(b)",           "print(c)",        "print(z)",
      "print(real(z))",   "print(imag(z))",     "print(conj(z))",  "print(abs(z))",
      "print(angle(z))",  "print(is_complex(z))", "print(is_real(a))",
      "w = complex([1, 2], [3, 4]);", "print(w)", "print(conj(w))",
      "i = 5;",           "print(3 * i)",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("complex literal: a = 3i", tw, jit, "a");
  checkVar("complex literal: b = 2.5j", tw, jit, "b");
  checkVar("complex literal: c = 1e3i", tw, jit, "c");
  checkVar("complex builtin: z = complex(3, -4)", tw, jit, "z");
  checkVar("complex builtin: w = complex([1, 2], [3, 4])", tw, jit, "w");
  checkStdout("complex literals and builtins: printed output", tw, jit);

  // Guards against both sides agreeing on a wrong answer (a dropped
  // imaginary part prints as "0" on either path).
  report("complex literals and builtins: expected text",
         tw.stdout_.find("0+3i") != std::string::npos &&
             tw.stdout_.find("3-4i") != std::string::npos &&
             tw.stdout_.find("[1+3i,2+4i]") != std::string::npos,
         "tree-walker printed [" + tw.stdout_ + "]");
}

// ---- Complex scalar arithmetic and comparisons ----
// The JIT's native fast path must decline a complex operand and take the
// same checked route the tree-walker uses; a fast path that read only
// `.number` would compute on the real part and still "agree" with nothing.
void runComplexArithmeticCase() {
  std::vector<std::string> lines = {
      "a = 1 + 2i;",      "b = 3 - 4i;",      "s = a + b;",       "d = a - b;",
      "p = a * b;",       "q = a / b;",       "n = -a;",          "sq = 1i * 1i;",
      "pw = a ^ 2;",      "pinv = a ^ -1;",   "pc = a ^ b;",      "back = a * conj(a);",
      "mag = |b|;",       "lt1 = a < b;",     "ge1 = b >= 3;",    "eq1 = a == 1 + 2i;",
      "ne1 = a != b;",    "acc = 0;",
      "for k = [1:4]",    "acc = acc + k * 1i;", "fend",
      "t = 0;",           "if 0 + 1i",        "t = 1;",           "iend",
      "f = 0;",           "if a - a",         "f = 1;",           "iend",
      "print(s)",         "print(d)",         "print(p)",         "print(q)",
      "print(n)",         "print(sq)",        "print(pw)",        "print(pinv)",
      "print(back)",      "print(mag)",       "print(acc)",       "print(-3i)",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  for (const char *name : {"s", "d", "p", "q", "n", "sq", "pw", "pinv", "pc", "back", "mag",
                           "lt1", "ge1", "eq1", "ne1", "acc", "t", "f"})
    checkVar(std::string("complex arithmetic: ") + name, tw, jit, name);
  checkStdout("complex arithmetic: printed output", tw, jit);

  // Both sides agreeing is not enough - pin the actual answers.
  const std::string expected = "4-2i\n-2+6i\n11+2i\n-0.2+0.4i\n-1-2i\n-1\n-3+4i\n"
                               "0.2-0.4i\n5\n5\n0+10i\n0-3i\n";
  report("complex arithmetic: expected text", tw.stdout_ == expected,
         "tree-walker printed [" + tw.stdout_ + "]");
}

// ---- Complex arrays and matrices ----
// Literals, every operator, index read and write (including a write that
// widens a real array), and a result that narrows back to real.
void runComplexContainerCase() {
  std::vector<std::string> lines = {
      "v = [1+2i, 3, 4i];",        "M = [[1i, 2], [3, 4i]];",   "R = [[1, 2], [3, 4]];",
      "vs = v * 2i;",              "va = v + [1, 1, 1];",       "vd = 2 / v;",
      "vp = v ^ 2;",               "vn = -v;",                  "vz = v - v;",
      "mm = M * M;",               "mp = M ^ 2;",               "ma = M + 1i;",
      "mh = M . M;",               "mr = R * M;",               "mt = transpose(M);",
      "mc = conjugate(M);",        "back = M * conjugate(M);",
      "u = [1, 2, 3];",            "u[0] = 1 - 1i;",            "M[0][1] = 5 - 1i;",
      "e1 = v[0];",                "e2 = M[0][1];",             "nrm = |[3i, 4]|;",
      "print(v)",   "print(vs)",   "print(vz)",  "print(mm)",   "print(mh)",
      "print(mt)",  "print(u)",    "print(M)",   "print(e2)",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  for (const char *name : {"v", "M", "vs", "va", "vd", "vp", "vn", "vz", "mm", "mp", "ma", "mh",
                           "mr", "mt", "mc", "back", "u", "e1", "e2", "nrm"})
    checkVar(std::string("complex container: ") + name, tw, jit, name);
  checkStdout("complex container: printed output", tw, jit);

  const std::string expected =
      "[1+2i,3,0+4i]\n[-4+2i,0+6i,-8]\n[0,0,0]\n"
      "[\n  [5,0+10i],\n  [0+15i,-10]\n]\n"
      "[\n  [-1,4],\n  [9,-16]\n]\n"
      "[\n  [0+1i,3],\n  [2,0+4i]\n]\n"
      "[1-1i,2,3]\n"
      "[\n  [0+1i,5-1i],\n  [3,0+4i]\n]\n"
      "5-1i\n";
  report("complex container: expected text", tw.stdout_ == expected,
         "tree-walker printed [" + tw.stdout_ + "]");
}

// ---- Math functions on complex input ----
// Both paths reach these through callBuiltin(), so the point here is the
// pinned answers (sqrt(-4) is 2i since stage 7's promotion; cbrt(-8) stays
// the real root -2). Note complex(-1, 0), not `-1 + 0i`: the
// sum narrows to the real number -1 before log() ever sees it.
void runComplexMathCase() {
  std::vector<std::string> lines = {
      "z = 3 + 4i;",                 "a = sqrt(z);",              "b = sqr(1 + 2i);",
      "c = cube(1i);",               "d = exp(1i);",              "f = log(complex(-1, 0));",
      "g = sqrt(complex(-4, 0));",   "h = sin(1 + 1i);",          "k = inv_sin(complex(2, 0));",
      "l = logb10(100i);",           "m = round(1.26 + 2.74i, 1);", "n = int(1.9 - 2.9i);",
      "o = sqrt([4, 2i, complex(-9, 0)]);", "p = cosh(1i);",     "q = is_zero(0 + 0i);",
      "r = is_zero(1i);",            "s = sqrt(-4);",             "t = cbrt(-8);",
      "u = abs([3 + 4i, 5]);",       "v = imag([[1i, 2], [3, 4i]]);",
      "print(a)",  "print(b)",  "print(c)",  "print(d)",  "print(f)",  "print(g)",
      "print(h)",  "print(k)",  "print(l)",  "print(m)",  "print(n)",  "print(o)",
      "print(q)",  "print(r)",  "print(s)",  "print(t)",  "print(u)",  "print(v)",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  for (const char *name : {"a", "b", "c", "d", "f", "g", "h", "k", "l", "m", "n", "o", "p", "q",
                           "r", "t", "u", "v"})
    checkVar(std::string("complex math: ") + name, tw, jit, name);
  checkStdout("complex math: printed output", tw, jit);

  const std::string expected =
      "2+1i\n-3+4i\n0-1i\n0.540302+0.841471i\n0+3.141593i\n0+2i\n"
      "1.298458+0.634964i\n1.570796+1.316958i\n2+0.682188i\n1.3+2.7i\n1-2i\n"
      "[2,1+1i,0+3i]\n1\n0\n0+2i\n-2\n[5,5]\n[\n  [1,0],\n  [0,4]\n]\n";
  report("complex math: expected text", tw.stdout_ == expected,
         "tree-walker printed [" + tw.stdout_ + "]");
}

// ---- Real inputs promoting to complex ----
// A real number outside a function's real domain gives the complex answer
// (MATLAB's rule); a real number inside it must give exactly what it always
// did. `^` reaches power() through the bridge on the JIT path and directly
// on the tree-walker path, so this is where the two could disagree.
void runComplexPromotionCase() {
  std::vector<std::string> lines = {
      "a = sqrt(-4);",        "b = log(-1);",          "c = logb10(-100);",
      "d = (-8) ^ (1 / 3);",  "f = (-4) ^ 0.5;",       "g = inv_sin(2);",
      "h = inv_cos(2);",      "k = inv_cosec(0.5);",   "l = inv_sec(0.5);",
      "m = sqrt([4, -9]);",   "n = [-8, 8] ^ (1 / 3);",
      "x = -4;",              "y = 0.5;",              "o = x ^ y;",
      "p = sqrt(4);",         "q = cbrt(-8);",         "r = (-2) ^ 3;",
      "s = log(0);",          "t = inv_sin(0.5);",     "u = inv_sec(2);",
      "v = sqrt([4, 9]);",    "w = isnan(sqrt(-4));",  "nn = sqrt(0 / 0);",
      "print(a)",  "print(b)",  "print(c)",  "print(d)",  "print(f)",  "print(g)",
      "print(h)",  "print(k)",  "print(l)",  "print(m)",  "print(n)",  "print(o)",
      "print(p)",  "print(q)",  "print(r)",  "print(s)",  "print(t)",  "print(u)",
      "print(v)",  "print(w)",  "print(nn)",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  for (const char *name : {"a", "b", "c", "d", "f", "g", "h", "k", "l", "m", "n", "o", "p", "q",
                           "r", "s", "t", "u", "v", "w"})
    checkVar(std::string("complex promotion: ") + name, tw, jit, name);
  checkStdout("complex promotion: printed output", tw, jit);

  const std::string expected =
      "0+2i\n0+3.141593i\n2+1.364376i\n1+1.732051i\n0+2i\n1.570796+1.316958i\n"
      "0-1.316958i\n1.570796+1.316958i\n0-1.316958i\n[2,0+3i]\n[1+1.732051i,2]\n0+2i\n"
      "2\n-2\n-8\n-inf\n0.523599\n1.047198\n[2,3]\n0\nnan\n";
  report("complex promotion: expected text", tw.stdout_ == expected,
         "tree-walker printed [" + tw.stdout_ + "]");
}

// ---- Name-resolved variable read/write across multiple statements ----
// (Slot-resolved reads only occur inside a resolved function/method body -
// Phase 6 resolution, parser_resolve.cpp - and FunctionDecl is explicitly
// out of scope for CodeGen/JitEngine so far. Only the name-resolved path
// (Expr::slot == -1) is reachable from top-level scripts like every case
// in this file - see codegen.h/value_bridge.h's own notes on this gap.)
void runMultiStatementCase() {
  std::vector<std::string> lines = {"x = 10", "y = x + 5"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("multi-statement var read/write (y = x + 5)", tw, jit, "y");
}

void runPublishCase() {
  // The trailing `;` on the assignment suppresses its own auto-echo (see
  // runAutoEchoCase() below for that behavior specifically) so this case
  // tests only the explicit Publish path in isolation.
  std::vector<std::string> lines = {"x = 2 + 3 * 4;", "print(x)"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("publish case: x", tw, jit, "x");
  checkStdout("publish case: printed output", tw, jit);
}

// MATLAB-style auto-echo-on-no-semicolon (Stmt::suppressOutput, ast.h) -
// codegen never implemented this for ANY statement shape until a real
// script corpus (Testing_Files/, outside this harness) exposed it: `x = 5
// + 3` with no trailing ';' printed nothing at all via JIT where the tree-
// walker prints "x = 8" - `grep suppressOutput codegen.cpp` returned zero
// hits beforehand. Every pre-existing case above suppresses output with
// ';' (to compare variable STATE via checkVar) or uses an explicit print(),
// so none of them ever exercised this. Covers every Assign target shape
// that has its own printValue() call in executeAssignStmt(): bare
// identifier, array/matrix index write (prints the whole container), and
// object field write (prints the assigned value, not the whole object) -
// plus a bare ExprStmt.
void runAutoEchoCase() {
  std::vector<std::string> lines = {
      "pb_ae_x = 5 + 3",
      "pb_ae_a = [1, 2, 3]",
      "pb_ae_a[1] = 99",
      "class PbAeC():",
      "function base(pb_ae_v):",
      "base.f = pb_ae_v;",
      "fnend",
      "csend",
      "pb_ae_obj = PbAeC(3);",
      "pb_ae_obj.f = 7",
      "9 + 1",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkStdout("auto-echo: identifier/array-index/field-write/bare-expr all match", tw, jit);
}

// ---- Control flow: If/elseif/else, While + break, While + continue,
// For-range (with and without an explicit step), For-range + break/
// continue. Every script below is written with no leading indentation on
// any line, deliberately - parseIfStmtNode()/parseWhileStmtNode() enforce
// that `iend`/`wend`/`elseif`/`else` sit at the exact same column as their
// opening `if`/`while` keyword (parser_program.cpp), and column 1 for
// everything sidesteps that entirely rather than needing to hand-align
// nested constructs correctly.

// Runs a fresh if/elseif/else chain with `x` preset so exactly one branch
// fires, checks `r` picks up that branch's value - called once per branch
// so the chain's full width actually gets exercised, not just whichever
// branch a single run happens to take.
void runIfElseCase() {
  auto testBranch = [](const std::string &label, int xVal) {
    std::vector<std::string> lines = {
        "x = " + std::to_string(xVal) + ";",
        "if x == 1:",
        "r = 100;",
        "elseif x == 2:",
        "r = 200;",
        "else:",
        "r = 300;",
        "iend",
    };
    auto tw = runTreeWalker(lines);
    auto jit = runViaJit(lines);
    checkVar(label, tw, jit, "r");
  };
  testBranch("if/elseif/else: if-branch taken (x=1)", 1);
  testBranch("if/elseif/else: elseif-branch taken (x=2)", 2);
  testBranch("if/elseif/else: else-branch taken (x=3)", 3);
}

// While with a break partway through: i counts 1..6, breaking exactly at
// i==6 (before that iteration's sum update runs), so sum should end up as
// 1+2+3+4+5.
void runWhileBreakCase() {
  std::vector<std::string> lines = {
      "i = 0;",     "sum = 0;", "while i < 100:", "i = i + 1;",
      "if i == 6:", "break",    "iend",           "sum = sum + i;",
      "wend",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("while + break: i", tw, jit, "i");
  checkVar("while + break: sum", tw, jit, "sum");
}

// While with a continue: i counts 1..10, skipping the sum update only on
// the iteration where i==5 (continue jumps straight back to the condition
// check, past that iteration's `sum = sum + i`).
void runWhileContinueCase() {
  std::vector<std::string> lines = {
      "i = 0;",     "sum = 0;", "while i < 10:", "i = i + 1;",
      "if i == 5:", "continue", "iend",          "sum = sum + i;",
      "wend",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("while + continue: i", tw, jit, "i");
  checkVar("while + continue: sum", tw, jit, "sum");
}

// For-range, no explicit step (defaults to 1): i = 1,2,3,4,5.
void runForRangeCase() {
  std::vector<std::string> lines = {
      "sum = 0;",
      "for i = [1:5]:",
      "sum = sum + i;",
      "fend",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("for-range (no step): sum", tw, jit, "sum");
  checkVar("for-range (no step): i after loop", tw, jit, "i");
}

// For-range with an explicit step: NC's 3-part range is [start:step:end]
// (parser_factor.cpp's RangeLiteral parsing - step is the middle part, not
// the last), so [1:2:9] is start=1, step=2, end=9: i = 1,3,5,7,9.
void runForRangeWithStepCase() {
  std::vector<std::string> lines = {
      "sum = 0;",
      "for i = [1:2:9]:",
      "sum = sum + i;",
      "fend",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("for-range (step=2): sum", tw, jit, "sum");
  checkVar("for-range (step=2): i after loop", tw, jit, "i");
}

// For-range with a break and a continue inside it: skip i==3 (continue),
// stop entirely at i==7 (break) - so sum covers 1+2+4+5+6.
void runForRangeBreakContinueCase() {
  std::vector<std::string> lines = {
      "sum = 0;",   "for i = [1:10]:", "if i == 3:", "continue",
      "iend",       "if i == 7:",      "break",      "iend",
      "sum = sum + i;", "fend",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("for-range + break/continue: sum", tw, jit, "sum");
  checkVar("for-range + break/continue: i after loop", tw, jit, "i");
}

// ---- User-defined functions: StmtKind::FunctionDecl / ExprKind::Call.
// Every script below declares its function(s) as separate top-level
// statements from the call site that uses them - runViaJit() parses the
// whole script into one Program and feeds JitEngine one top-level
// statement per runStmt() call (see runViaJit()'s own comment), so a
// FunctionDecl and a later Call to it are deliberately exercised as
// SEPARATE compiles sharing one JitEngine - exactly the cross-module-call
// case codegen.h's "Recursion and calls across separate compile calls"
// section exists for, not just same-compile self-recursion. Flat, no
// indentation, same reasoning as the control-flow scripts above (`fnend`/
// `iend` must column-align with their opener).

// A simple single-output function call.
void runSimpleFunctionCase() {
  std::vector<std::string> lines = {
      "function y = square(x):",
      "y = x * x;",
      "fnend",
      "r = square(6);",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("function call: square(6)", tw, jit, "r");
}

// A function using control flow internally (last step's work exercised
// together with this one) - called with both a negative and a positive
// input so both branches actually run.
void runFunctionWithControlFlowCase() {
  auto testInput = [](const std::string &label, int xVal) {
    std::vector<std::string> lines = {
        "function y = abs_via_if(x):",
        "if x < 0:",
        "y = -x;",
        "else:",
        "y = x;",
        "iend",
        "fnend",
        "r = abs_via_if(" + std::to_string(xVal) + ");",
    };
    auto tw = runTreeWalker(lines);
    auto jit = runViaJit(lines);
    checkVar(label, tw, jit, "r");
  };
  testInput("function + if/else: abs_via_if(-7)", -7);
  testInput("function + if/else: abs_via_if(7)", 7);
}

// Recursion: the sharpest test that function compilation is actually
// correct rather than accidentally correct for straight-line cases -
// every recursive call is a genuine native `call` instruction to the same
// llvm::Function, with its own real stack frame (see codegen.h's "User-
// defined functions" section).
void runRecursiveFunctionCase() {
  auto testInput = [](const std::string &label, int nVal) {
    std::vector<std::string> lines = {
        "function y = factorial(n):",
        "if n <= 1:",
        "y = 1;",
        "else:",
        "y = n * factorial(n - 1);",
        "iend",
        "fnend",
        "r = factorial(" + std::to_string(nVal) + ");",
    };
    auto tw = runTreeWalker(lines);
    auto jit = runViaJit(lines);
    checkVar(label, tw, jit, "r");
  };
  testInput("recursive function: factorial(0)", 0);
  testInput("recursive function: factorial(1)", 1);
  testInput("recursive function: factorial(5)", 5);
}

// Multi-output function + multi-target Assign: "(A,B) = f(...)". Header
// syntax for a multi-output declaration is `function (q, r) = name(...):`
// (parenthesized output list - confirmed against parseFunctionDeclNode(),
// parser_program.cpp), and the call site is `(qq, rr) = name(...)`
// (confirmed against parseAssignOrExprStmtNode()'s own LPAREN-output-list
// branch, same file - it builds the Call Expr and multi-target Assign
// directly, which is also why codegen's multi-target Assign case can
// assume stmt->value is always a Call for this shape). divmod, per the
// coordinator's suggestion - quotient and remainder are cleanly
// independent of each other, so a transcription bug in either the
// signature widening or the positional target binding would show up as a
// wrong value in exactly one of the two, not a coincidentally-right sum.
void runMultiOutputFunctionCase() {
  std::vector<std::string> lines = {
      "function (q, r) = divmod(a, b):",
      "q = a // b;",
      "r = a % b;",
      "fnend",
      "(qq, rr) = divmod(17, 5);",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("multi-output function: divmod(17,5) quotient", tw, jit, "qq");
  checkVar("multi-output function: divmod(17,5) remainder", tw, jit, "rr");
}

// ---- Arrays, matrices, dicts. checkVar()'s existing valuesDeepEqual()-
// based comparison already handles these Value shapes without any harness
// changes - Step 5's original design foresight paying off (its own top
// comment always said this would "stay correct once array/matrix/dict-
// producing ops eventually get bridged too, not just numbers"). Several
// cases compare the WHOLE container variable, not just one extracted
// element - a stronger check than a bridge-side accessor would give,
// since it validates the entire construction/write path in one diff,
// element-by-element, for free.

void runArrayLiteralAndIndexReadCase() {
  std::vector<std::string> lines = {"a = [10, 20, 30];", "r = a[1];"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("array literal + index read: a[1]", tw, jit, "r");
  checkVar("array literal + index read: whole array a", tw, jit, "a");
}

void runArrayIndexWriteCase() {
  std::vector<std::string> lines = {"a = [1, 2, 3];", "a[1] = 99;"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("array index write: whole array a after a[1]=99", tw, jit, "a");
}

void runMatrixLiteralAndChainedReadCase() {
  std::vector<std::string> lines = {"m = [[1, 2], [3, 4]];", "r = m[1][0];"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("matrix literal + chained read: m[1][0]", tw, jit, "r");
  checkVar("matrix literal + chained read: whole matrix m", tw, jit, "m");
}

void runMatrixCommaFormReadCase() {
  std::vector<std::string> lines = {"m = [[1, 2], [3, 4]];", "r = m[1,0];"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("matrix literal + comma-form read: m[1,0]", tw, jit, "r");
}

void runMatrixChainedWriteCase() {
  std::vector<std::string> lines = {"m = [[1, 2], [3, 4]];", "m[1][1] = 88;"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("matrix chained write: whole matrix m after m[1][1]=88", tw, jit, "m");
}

void runMatrixCommaFormWriteCase() {
  std::vector<std::string> lines = {"m = [[1, 2], [3, 4]];", "m[0,1] = 77;"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("matrix comma-form write: whole matrix m after m[0,1]=77", tw, jit, "m");
}

// No dict LITERAL syntax exists (confirmed - ast.h's ExprKind has no
// DictLiteral entry) - a dict only ever comes into existence via auto-
// vivifying index-assign, exactly what this case exercises: `mydict`
// doesn't exist before the first line runs. (Named `mydict`, not the more
// obvious `d` - confirmed empirically, directly against the tree-walker
// REPL, that a bare `d` collides with some other reserved/pre-resolved
// identifier in NC and produces "'d' is not a dict" errors on every line
// regardless of codegen/JIT involvement at all; unrelated to this task,
// just an unlucky variable name to avoid.)
void runDictAutoVivifyCase() {
  std::vector<std::string> lines = {"mydict[\"x\"] = 5;", "mydict[\"y\"] = 10;",
                                     "r = mydict[\"x\"];"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("dict auto-vivify + read: mydict[\"x\"]", tw, jit, "r");
  checkVar("dict auto-vivify + read: whole dict mydict", tw, jit, "mydict");
}

// ---- Classes: the smallest genuinely-correct mechanism - a single, plain
// class (no inheritance/abstract/reversible/@rate), a `base` constructor
// setting two fields, and one instance method reading a field back.
// `class Point():` needs the parens even with no parent class listed
// inside them (confirmed against parseClassDeclNode(), parser_program.cpp
// - required, not optional, unlike the trailing ':'). checkVar()'s
// valuesDeepEqual() comparison (used here to diff the whole constructed
// object, same "stronger than one extracted field" style as the array/
// matrix/dict cases) only ever compares an object's className + dictMap
// (value_compare.cpp) - never lineage/snapshots/etc. - so it stays
// correct even though this codegen slice deliberately never populates
// those (out of scope, see codegen.h's "Classes" section).
void runClassCase() {
  std::vector<std::string> lines = {
      "class Point():",
      "function base(x, y):",
      "base.x = x;",
      "base.y = y;",
      "fnend",
      "function y = getY():",
      "y = base.y;",
      "fnend",
      "csend",
      "p = Point(3, 4);",
      "fx = p.x;",
      "gy = p.getY();",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("class: field read p.x", tw, jit, "fx");
  checkVar("class: instance method p.getY()", tw, jit, "gy");
  checkVar("class: whole constructed object p", tw, jit, "p");
}

// ---- Native-scalar performance path: BinaryOp/Comparison now guard both
// operands at runtime (nc_bridge_value_is_plain_number) and take a native
// fadd/fcmp/etc. path when both are plain unitless numbers, falling
// through to the exact same bridge call as before otherwise. Every
// existing case above already re-proves the fast path matches the tree-
// walker for ordinary scalars (they all still pass unchanged). These
// three specifically target the FALLBACK path and the one genuine hazard
// found while investigating it.
//
// Variable names here are deliberately prefixed `fast_` - this repo's
// working directory has a real, uncommitted variables.txt (the user's own
// accumulated `nc` usage, not test fixtures) that every fresh Parser()
// loads unconditionally via loadFromFile() in its constructor. `m`/`s`/`N`
// (candidate unit-constant names) are already shadowed by pre-existing
// entries there - confirmed by inspection, not assumed, after an unrelated
// short variable name silently picked up stale data during this
// investigation. Doesn't affect correctness of any diff here (tree-walker
// and JIT Parsers both load the same file, so contamination cancels out
// either way), but picking fresh names avoids confusing results.

// BinaryOp between two matrices - both operands fail the plain-number
// guard, so this must take the untouched slow path (nc_bridge_add,
// unchanged since Step 9's array/matrix work). Diffs the whole result
// matrix.
void runFastPathMatrixFallbackCase() {
  std::vector<std::string> lines = {
      "fast_m1 = [[1, 2], [3, 4]];",
      "fast_m2 = [[5, 6], [7, 8]];",
      "fast_r = fast_m1 + fast_m2;",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("fast path fallback: matrix + matrix", tw, jit, "fast_r");
}

// BinaryOp between two unit-tagged numbers (dimL=1 via the `kg` unit
// constant, parser_factor.cpp's tryResolveUnitConstant) - fails the guard
// on the dimension check specifically (both are otherwise plain, in-range
// numbers), so this proves the dimension half of the guard, not just the
// type-flag half the matrix case above already covers.
void runFastPathUnitFallbackCase() {
  std::vector<std::string> lines = {
      "fast_ua = 5 * kg;",
      "fast_ub = 3 * kg;",
      "fast_ur = fast_ua + fast_ub;",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("fast path fallback: unit-tagged (kg) + unit-tagged (kg)", tw, jit, "fast_ur");
}

// NaN comparisons: logical_gt()/logical_gte() used to evaluate true for ANY
// NaN operand (valueOrderCompare() has no "unordered" result). All four
// ordering operators now return false for NaN (IEEE-754). Checks all 6
// Comparison operators agree between tree-walker and JIT fast path
// (codegenNativeComparison() uses ordered fcmp predicates).
void runFastPathNanComparisonCase() {
  std::vector<std::string> lines = {
      "fast_nan = 0 / 0;",
      "fast_gt = fast_nan > 5;",
      "fast_gte = fast_nan >= 5;",
      "fast_lt = fast_nan < 5;",
      "fast_lte = fast_nan <= 5;",
      "fast_eq = fast_nan == 5;",
      "fast_neq = fast_nan != 5;",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("fast path NaN comparison: NaN > 5", tw, jit, "fast_gt");
  checkVar("fast path NaN comparison: NaN >= 5", tw, jit, "fast_gte");
  checkVar("fast path NaN comparison: NaN < 5", tw, jit, "fast_lt");
  checkVar("fast path NaN comparison: NaN <= 5", tw, jit, "fast_lte");
  checkVar("fast path NaN comparison: NaN == 5", tw, jit, "fast_eq");
  checkVar("fast path NaN comparison: NaN != 5", tw, jit, "fast_neq");
}

// Postfix factorial ("!post", e.g. `5!`) - a REAL bug found via real corpus
// testing (Testing_Files/t15_all_primitives.nc, outside this harness):
// UnaryOp codegen matched only "!" (logical not) and treated ANY other
// text as "-" (negation), so `5!` silently computed -5 instead of 120 - see
// nc_bridge_factorial's comment.
void runPostfixFactorialCase() {
  std::vector<std::string> lines = {"r = 5!;"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("postfix factorial: 5!", tw, jit, "r");
}

// Elementwise dot operator on a non-object receiver (`A.B` meaning
// element-wise matrix multiply, distinct from A.B as an object field read)
// - a REAL bug found via real corpus testing (Testing_Files/t14_matrix_dot.
// nc/Matrix_Horizon_Test.nc, outside this harness): ExprKind::FieldAccess
// codegen only ever called nc_bridge_field_get() for the object-receiver
// case; a non-object receiver silently got back a zero Value (nc_bridge_
// field_get's own "not an object" rejection, unchecked by the caller)
// instead of the real element-wise product or a compile-time ok_ = false -
// see nc_bridge_field_get's comment for the fix (folded the fallback
// directly into that same bridge function).
void runElementwiseDotOperatorCase() {
  std::vector<std::string> lines = {
      "pb_dot_a = [[1, 2], [3, 4]];",
      "pb_dot_b = [[5, 6], [7, 8]];",
      "pb_dot_r = pb_dot_a.pb_dot_b;",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("elementwise dot operator: A.B on two matrices", tw, jit, "pb_dot_r");
}

// ---- Builtin dispatch: ExprKind::Call against a name that's neither a
// known class constructor nor a known user function now compiles to a
// generic nc_bridge_call_builtin() call instead of rejecting at compile
// time (codegen.cpp's ExprKind::Call, formerly `ok_ = false` for every
// builtin) - see value_bridge.h/.cpp's nc_bridge_call_builtin() and
// codegen.cpp's codegenBuiltinCall(). One case per builtin category named
// in the task, plus the precedence/shadowing and not-found cases.

// Captures everything written to std::cerr during fn() - added
// specifically for the not-found case below, which needs to verify the
// tree-walker's and JIT's error OUTPUT match byte-for-byte, not just their
// resulting Values (captureStdout() above only ever captures cout, and
// callBuiltin()'s "Unknown function" message goes to cerr).
template <typename Fn>
std::string captureStderr(Fn &&fn) {
  std::ostringstream capture;
  std::streambuf *old = std::cerr.rdbuf(capture.rdbuf());
  fn();
  std::cerr.rdbuf(old);
  return capture.str();
}

void runBuiltinMathCase() {
  std::vector<std::string> lines = {"r = sqrt(81);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: sqrt(81)", tw, jit, "r");
}

void runBuiltinAbsCase() {
  std::vector<std::string> lines = {"r = abs(-15);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: abs(-15)", tw, jit, "r");
}

void runBuiltinTrigCase() {
  std::vector<std::string> lines = {"r = sin(0);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: sin(0)", tw, jit, "r");
}

void runBuiltinMatrixCase() {
  std::vector<std::string> lines = {"m = [[1, 2], [3, 4]];", "r = transpose(m);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: transpose([[1,2],[3,4]])", tw, jit, "r");
}

void runBuiltinDetCase() {
  std::vector<std::string> lines = {"m = [[1, 2], [3, 4]];", "r = det(m);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: det([[1,2],[3,4]])", tw, jit, "r");
}

void runBuiltinStatsCase() {
  std::vector<std::string> lines = {"a = [1, 2, 3, 4, 5];", "r = sum(a);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: sum([1,2,3,4,5])", tw, jit, "r");
}

void runBuiltinMeanCase() {
  std::vector<std::string> lines = {"a = [1, 2, 3, 4, 5];", "r = mean(a);"};
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin: mean([1,2,3,4,5])", tw, jit, "r");
}

// Precedence: classTable_ -> functionTable_ -> callBuiltin() - a
// user-defined function named the same as a real builtin ("sqrt") must
// shadow it, matching evaluateExpr()'s functionTable_-before-callBuiltin()
// check exactly (parser_factor.cpp). If codegen's Call case ever checked
// functionArity_ AFTER falling through to the generic builtin dispatch (or
// not at all), this would silently call the wrong thing - sqrt(9)=3 rather
// than the user function's 9*9=81.
void runBuiltinShadowedByUserFunctionCase() {
  std::vector<std::string> lines = {
      "function y = sqrt(x):",
      "y = x * x;",
      "fnend",
      "r = sqrt(9);",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("builtin shadowed by user function: sqrt(9) == 81, not 3", tw, jit, "r");
}

// Deliberately unknown function name: neither a class, a user function, nor
// a registered builtin. Verifies the not-found path matches the
// tree-walker byte-for-byte on BOTH axes - the stderr error text (both call
// the identical callBuiltin(), so both print the identical "Error: Unknown
// function '<name>'\n") and the resulting Value (`r` stays completely
// UNASSIGNED in both: the tree-walker's executeAssignStmt() never reaches
// varSet() once evaluationSucceeded_ is false, and codegen's matching
// StmtKind::Assign branch (see codegen.cpp's isGenericBuiltinCall handling)
// skips its conditional varWrite the same way when nc_bridge_call_builtin()
// reports not-found - not just "doesn't crash").
void runUnknownFunctionCase() {
  std::vector<std::string> lines = {"r = this_function_does_not_exist(1, 2);"};

  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      engine.runStmt(stmt.get(), jitParser);
  });

  report("unknown function: stderr matches byte-for-byte", twErr == jitErr,
         "tree-walker stderr [" + twErr + "] jit stderr [" + jitErr + "]");

  // Neither Parser ever assigned `r` - readVariableOrConstant() falls back
  // to its own "Unknown constant" path for both, returning Value(0) either
  // way (see parser_factor.cpp) - captured here to keep this check silent
  // rather than printing yet another (matching, but noisy) error pair.
  Value twR, jitR;
  captureStderr([&] { twR = twParser.readVariableOrConstant("r", -1); });
  captureStderr([&] { jitR = jitParser.readVariableOrConstant("r", -1); });
  report("unknown function: r left unassigned in both (Value matches)",
         valuesDeepEqual(twR, jitR));
}

// ---- Step 4's actual reason for existing: JIT'd and tree-walked
// statements interleaved against ONE shared Parser, not two separate runs
// diffed afterward. Tree-walk `a = 5`, JIT `b = a + 1` through the engine
// (proves the JIT side sees a tree-walked write), tree-walk `print(b)`
// (proves the tree-walker sees the JIT's write back), then check both
// variables and the printed output.
void runInterleavingCase() {
  Parser p;
  JitEngine engine;

  // Semicolon suppresses the tree-walker's auto-echo (same reasoning as
  // runPublishCase()) so this step doesn't print anything to real stdout.
  auto stmtA = parseLine("a = 5;");
  p.executeStmt(stmtA.get());

  auto stmtB = parseLine("b = a + 1");
  bool jitOk = engine.runStmt(stmtB.get(), p);

  std::string printed = captureStdout([&] {
    auto stmtPrint = parseLine("print(b)");
    p.executeStmt(stmtPrint.get());
  });

  if (!jitOk) {
    report("interleaving: JIT statement (b = a + 1)", false, "runStmt rejected it");
    return;
  }

  Value a = p.readVariableOrConstant("a", -1);
  Value b = p.readVariableOrConstant("b", -1);
  report("interleaving: a unaffected by the JIT step", a.number == 5.0);
  report("interleaving: b == a + 1 (JIT saw the tree-walker's write)", b.number == 6.0);
  report("interleaving: tree-walker's print sees the JIT's write", printed == "6\n");
}

// ---- Phase B: Require/Ensure, ClearMemory, Wildcard slicing, multi-key
// dict assign, and dynamic dispatch (a class/function defined via the
// tree-walker, never natively compiled by CodeGen, then used via JIT).
// Variable names prefixed `pb_` for the same reason `fast_` was chosen
// above (a stray unprefixed short name can collide with this repo's real,
// uncommitted variables.txt) - and `d`/`mydict` are avoided per
// runDictAutoVivifyCase()'s own comment on `d` specifically.

// Require passing (condition true) inside a function - the ordinary case,
// proving the new StmtKind::Require/Ensure codegen doesn't regress the
// path where nothing fails.
void runRequirePassCase() {
  std::vector<std::string> lines = {
      "function pb_y = pb_req_pass(pb_x):",
      "require pb_x > 0;",
      "pb_y = pb_x * 2;",
      "fnend",
      "pb_r1 = pb_req_pass(5);",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("require: passing precondition, function still returns", tw, jit, "pb_r1");
}

// Ensure passing (condition true) - same shape, the postcondition variant.
void runEnsurePassCase() {
  std::vector<std::string> lines = {
      "function pb_y = pb_ens_pass(pb_x):",
      "pb_y = pb_x * 2;",
      "ensure pb_y > 0;",
      "fnend",
      "pb_r2 = pb_ens_pass(5);",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("ensure: passing postcondition, function still returns", tw, jit, "pb_r2");
}

// Require failing inside a function. Checks the actual Require-specific
// message (the FIRST stderr line) matches byte-for-byte - NOT full stderr
// equality: this script deliberately never assigns pb_y before the failed
// require exits the function, which trips a separate, PRE-EXISTING,
// Require-unrelated divergence (confirmed by reproducing it with a plain
// early `return;` instead of `require` - same result either way): the
// tree-walker's callUserFunction() explicitly detects an unassigned
// declared output and prints "Error: output '<name>' not assigned in
// function '<fname>'", leaving the caller's target variable completely
// unset; codegen's FunctionDecl epilogue has no equivalent check (nc_bridge_
// var_read has no "was this ever written" signal to act on) and silently
// reads back a zero-initialized Value instead. Out of Phase B's scope (a
// FunctionDecl/Return-epilogue gap, not a Require/Ensure one) - flagged,
// not silently absorbed into this test.
void runRequireFailCase() {
  std::vector<std::string> lines = {
      "function pb_y = pb_req_fail(pb_x):",
      "require pb_x > 0;",
      "pb_y = 99;",
      "fnend",
      "pb_r3 = pb_req_fail(-1);",
  };
  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      engine.runStmt(stmt.get(), jitParser);
  });

  auto firstLine = [](const std::string &s) {
    auto pos = s.find('\n');
    return pos == std::string::npos ? s : s.substr(0, pos);
  };
  report("require: failing precondition message matches byte-for-byte",
         firstLine(twErr) == firstLine(jitErr),
         "tree-walker [" + firstLine(twErr) + "] jit [" + firstLine(jitErr) + "]");
}

// Regression coverage for a bug found via real corpus testing (Testing_
// Files/t36_verification_loop_abort.nc, outside this harness), distinct
// from runRequireFailCase() above: THAT case's function is only ever
// called once, via the generic dynamic-dispatch bridge (never natively
// compiled in the same JIT session) - Bug #3's found-vs-evaluationSucceeded_
// fix already covers it. THIS case natively compiles pb_native_req_fail
// first (functionArity_ knows it by the time pb_native_req_result's Assign
// compiles), so the call goes through the NATIVE ABI (a plain `call`, no
// found-flag at all) - a require failing inside a for-loop, inside a
// natively-compiled function, used to leave the caller's target bound to
// whatever partial value the loop reached instead of correctly leaving it
// unassigned like the tree-walker.
void runNativeCallRequireFailureCase() {
  std::vector<std::string> lines = {
      "function pb_y = pb_native_req_fail(pb_n):",
      "pb_y = 0;",
      "for pb_i = [1:pb_n]:",
      "require pb_i <= 3;",
      "pb_y = pb_y + pb_i;",
      "fend",
      "fnend",
      "pb_native_req_result = pb_native_req_fail(10);",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  Value twR, jitR;
  captureStderr([&] { twR = tw.parser->readVariableOrConstant("pb_native_req_result", -1); });
  captureStderr([&] { jitR = jit.parser->readVariableOrConstant("pb_native_req_result", -1); });
  report("native call require failure: pb_native_req_result left unassigned (both sides)",
         valuesDeepEqual(twR, jitR));
}

// Regression coverage for a bug found via real corpus testing (Testing_
// Files/t44_slot_output_not_assigned.nc, outside this harness): once the
// VALUE divergence was fixed (runNativeCallRequireFailureCase() above), the
// STDERR TEXT still differed - the tree-walker's specific "Error: output
// '<name>' not assigned in function '<fname>'" vs. the epilogue's old
// generic nc_bridge_var_read() fallback printing "Error: Unknown constant
// '<name>'" instead. Fixed by nc_bridge_read_declared_output(), a dedicated
// bridge used only in a compiled function/method's epilogue.
void runOutputNotAssignedMessageCase() {
  std::vector<std::string> lines = {
      "function pb_y = pb_noassign(pb_x):",
      "if pb_x > 0:",
      "pb_y = 1;",
      "iend",
      "fnend",
      "pb_noassign_r = pb_noassign(-5);",
  };
  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements) {
      if (!engine.runStmt(stmt.get(), jitParser))
        jitParser.executeStmt(stmt.get());
    }
  });

  report("output not assigned: stderr matches byte-for-byte", twErr == jitErr,
         "tree-walker [" + twErr + "] jit [" + jitErr + "]");
}

// Same bug, the instance-method variant (Testing_Files/t35_verification.nc):
// a require failing before a method's declared output is ever assigned used
// to leave the epilogue's nc_bridge_var_read() falling back to "Unknown
// constant" instead of callInstanceMethod()'s own "not assigned in method"
// message.
void runMethodOutputNotAssignedMessageCase() {
  std::vector<std::string> lines = {
      "class PbNoAssignC():",
      "function base(pb_v):",
      "base.v = pb_v;",
      "fnend",
      "function pb_y = pb_method(pb_t):",
      "require pb_t >= 0;",
      "pb_y = pb_t;",
      "fnend",
      "csend",
      "pb_obj2 = PbNoAssignC(1);",
      "pb_method_r = pb_obj2.pb_method(-1);",
  };
  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements) {
      if (!engine.runStmt(stmt.get(), jitParser))
        jitParser.executeStmt(stmt.get());
    }
  });

  report("method output not assigned: stderr matches byte-for-byte", twErr == jitErr,
         "tree-walker [" + twErr + "] jit [" + jitErr + "]");
}

// Regression coverage for a bug found via real corpus testing (Testing_
// Files/t28_class_errors.nc/t29_encapsulation.nc, outside this harness):
// checkFieldAccess()'s private/protected enforcement was a documented,
// accepted gap - nc_bridge_field_get/set never called it at all, so a
// private field's value was silently readable/writable via JIT from
// OUTSIDE its class. Fixed by threading currentDefiningClass_ through a
// natively-compiled constructor/method call (nc_bridge_push/pop_defining_
// class) and actually calling checkFieldAccess() from nc_bridge_field_get/
// set. Covers BOTH directions: denied from outside (the bug), and still
// ALLOWED from inside the declaring class's own method (checking the fix
// didn't overcorrect into rejecting legitimate self-access).
void runPrivateFieldAccessControlCase() {
  std::vector<std::string> lines = {
      "class PbPrivC():",
      "private pb_secret;",
      "function base(pb_v):",
      "base.pb_secret = pb_v;",
      "fnend",
      "function pb_y = pb_readSelf():",
      "pb_y = base.pb_secret;",
      "fnend",
      "csend",
      "pb_privobj = PbPrivC(42);",
      "pb_inside = pb_privobj.pb_readSelf();",
      "pb_outside = pb_privobj.pb_secret;",
  };
  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements) {
      if (!engine.runStmt(stmt.get(), jitParser))
        jitParser.executeStmt(stmt.get());
    }
  });

  report("private field access: stderr matches byte-for-byte", twErr == jitErr,
         "tree-walker [" + twErr + "] jit [" + jitErr + "]");

  Value twInside = twParser.readVariableOrConstant("pb_inside", -1);
  Value jitInside = jitParser.readVariableOrConstant("pb_inside", -1);
  report("private field access: self-access from inside the class still works",
         valuesDeepEqual(twInside, jitInside) && twInside.number == 42.0);

  Value twOutside, jitOutside;
  captureStderr([&] { twOutside = twParser.readVariableOrConstant("pb_outside", -1); });
  captureStderr([&] { jitOutside = jitParser.readVariableOrConstant("pb_outside", -1); });
  report("private field access: outside read left pb_outside unassigned (both sides)",
         valuesDeepEqual(twOutside, jitOutside));
}

// Regression coverage for a bug found via real corpus testing (Testing_
// Files/t28_class_errors.nc, outside this harness): nc_bridge_field_set()
// correctly rejected a field-write on a non-object base already (so the
// VALUE was already right on both sides) but printed no message at all,
// where the tree-walker prints "Error: '<name>' is not an object".
void runFieldSetNonObjectCase() {
  std::vector<std::string> lines = {"pb_n = 5;", "pb_n.field = 10;"};
  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements) {
      if (!engine.runStmt(stmt.get(), jitParser))
        jitParser.executeStmt(stmt.get());
    }
  });

  report("field set on non-object: stderr matches byte-for-byte", twErr == jitErr,
         "tree-walker [" + twErr + "] jit [" + jitErr + "]");
}

// Wildcard (':') matrix slicing - read side: whole column, whole row.
void runWildcardReadCase() {
  std::vector<std::string> lines = {
      "pb_m = [[1, 2, 3], [4, 5, 6], [7, 8, 9]];",
      "pb_col = pb_m[:,1];",
      "pb_row = pb_m[1,:];",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("wildcard read: pb_m[:,1] (whole column)", tw, jit, "pb_col");
  checkVar("wildcard read: pb_m[1,:] (whole row)", tw, jit, "pb_row");
}

// Wildcard matrix slicing - write side: replace a whole row, then a whole
// column, checking the fully-mutated matrix each time.
void runWildcardWriteCase() {
  std::vector<std::string> lines = {
      "pb_m2 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]];",
      "pb_m2[0,:] = [10, 20, 30];",
      "pb_m2[:,2] = [100, 200, 300];",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("wildcard write: pb_m2 after row + column replace", tw, jit, "pb_m2");
}

// Multi-key dict assignment: A[k1,k2] = [v1,v2] on a not-yet-existing name
// (auto-vivifies a dict, same as the single-key case already covered by
// runDictAutoVivifyCase()).
void runMultiKeyDictAssignCase() {
  std::vector<std::string> lines = {
      "pb_dict[1,2] = [11, 22];",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  checkVar("multi-key dict assign: pb_dict[1,2]=[11,22]", tw, jit, "pb_dict");
}

// ---- Dynamic dispatch: a function/class defined via the real tree-walker
// (executeStmt(), never through engine.runStmt()) is invisible to a fresh
// CodeGen's classCtorArity_/functionArity_ - JitEngine's knownFunctions_/
// knownClasses_ only ever learn about what CodeGen itself compiled. Before
// nc_bridge_call_dynamic()'s hasClass()/hasFunction() tiers, this exact
// scenario silently mis-fired as "Error: Unknown function '<name>'"
// (reproduced against the built `nc` binary before this task) - regression
// coverage. Uses ONE shared Parser: the FunctionDecl/ClassDecl runs via
// executeStmt() directly (mirrors defining something before "@cmd jit on"
// in the real REPL), then the call/construction runs via engine.runStmt().
void runDynamicFunctionDispatchCase() {
  Parser p;
  JitEngine engine;

  // A FunctionDecl's header line alone isn't parseable as ONE statement via
  // parseLine() (its body/fnend haven't been seen yet) - parseScript() (the
  // multi-line/program path) is what every other multi-line case above
  // already uses for this reason.
  Program declProg = parseScript(
      {"function pb_y = pb_dyn_sq(pb_x):", "pb_y = pb_x * pb_x;", "fnend"});
  for (const auto &stmt : declProg.statements)
    p.executeStmt(stmt.get()); // tree-walker only - never touches CodeGen

  auto stmtCall = parseLine("pb_r4 = pb_dyn_sq(6);");
  bool jitOk = engine.runStmt(stmtCall.get(), p);
  if (!jitOk) {
    report("dynamic dispatch: call a tree-walker-only-defined function via JIT", false,
           "runStmt rejected it");
    return;
  }
  Value r = p.readVariableOrConstant("pb_r4", -1);
  report("dynamic dispatch: call a tree-walker-only-defined function via JIT", r.number == 36.0,
         "pb_r4 = " + std::to_string(r.number) + ", expected 36");
}

void runDynamicClassDispatchCase() {
  Parser p;
  JitEngine engine;

  Program declProg = parseScript({
      "class PbDynPoint():",
      "function base(pb_x):",
      "base.px = pb_x;",
      "fnend",
      "csend",
  });
  for (const auto &stmt : declProg.statements)
    p.executeStmt(stmt.get()); // tree-walker only - never touches CodeGen

  auto stmtCall = parseLine("pb_obj = PbDynPoint(7);");
  bool jitOk = engine.runStmt(stmtCall.get(), p);
  if (!jitOk) {
    report("dynamic dispatch: construct a tree-walker-only-defined class via JIT", false,
           "runStmt rejected it");
    return;
  }
  Value obj = p.readVariableOrConstant("pb_obj", -1);
  report("dynamic dispatch: construct a tree-walker-only-defined class via JIT",
         obj.isObject && obj.className() == "PbDynPoint" && obj.dict().count("px") &&
             obj.dict().at("px").number == 7.0,
         "pb_obj = " + valueToString(obj));
}

// Regression coverage for a bug found via real corpus testing (Testing_
// Files/t33_abstraction.nc, outside this harness): nc_bridge_call_dynamic()
// only checked callClassConstructor()'s `found` out-param, not
// evaluationSucceeded_ - so constructing an ABSTRACT class (a name that
// exists in classTable_, so `found` comes back true, but whose
// instantiation callClassConstructor() itself rejects) wrote a bogus Value
// into the target variable via JIT, where the tree-walker correctly leaves
// it completely unassigned.
void runAbstractClassRejectionCase() {
  std::vector<std::string> lines = {
      "abstract class PbAbstractShape():",
      "function base():",
      "base.kind = \"shape\";",
      "fnend",
      "csend",
      "pb_direct = PbAbstractShape();",
  };
  Program prog = parseScript(lines);

  Parser twParser;
  std::string twErr = captureStderr([&] {
    for (const auto &stmt : prog.statements)
      twParser.executeStmt(stmt.get());
  });

  Parser jitParser;
  JitEngine engine;
  std::string jitErr = captureStderr([&] {
    for (const auto &stmt : prog.statements) {
      // The `abstract class` ClassDecl itself is expected to reject at
      // compile time (ok_ = false - codegen never natively compiles an
      // abstract class) - same fallback every real caller (main.cpp,
      // ScriptManager::executeFile()) always has, needed here so the class
      // actually gets registered (via the tree-walker) before the
      // construction attempt on the next line.
      if (!engine.runStmt(stmt.get(), jitParser))
        jitParser.executeStmt(stmt.get());
    }
  });

  report("abstract class rejection: stderr matches byte-for-byte", twErr == jitErr,
         "tree-walker [" + twErr + "] jit [" + jitErr + "]");

  Value twR, jitR;
  captureStderr([&] { twR = twParser.readVariableOrConstant("pb_direct", -1); });
  captureStderr([&] { jitR = jitParser.readVariableOrConstant("pb_direct", -1); });
  report("abstract class rejection: pb_direct left unassigned on both sides",
         valuesDeepEqual(twR, jitR));
}

// ---- Top-level return/require also needs to STOP later statements from
// running - the real behavior main.cpp's REPL loop and ScriptManager::
// executeFile()'s JIT-aware Pass 2 both rely on via consumeTopLevelStopSignal().
// Neither runTreeWalker()/runViaJit() above exercises this (their own loops
// never call consumeTopLevelStopSignal() at all), so this uses the same
// bespoke per-statement pattern as runUnknownFunctionCase()/
// runInterleavingCase(). A REAL, previously-undetected gap: codegen's
// Return/Require/Ensure only ever emitted a `br` to the compiled
// function's own epilogue, never touching Parser::loopSignal_ - which is
// ALL consumeTopLevelStopSignal() actually checks - so a top-level
// `return;` (or a failed top-level require/ensure) had no effect at all
// under JIT, confirmed by direct repro against a real .nc file before this
// was fixed.
void runTopLevelStopSignalCase() {
  std::vector<std::string> lines = {
      "pb_ts_before = 1;",
      "return;",
      "pb_ts_after = 2;",
  };
  Program prog = parseScript(lines);

  Parser twParser;
  for (const auto &stmt : prog.statements) {
    twParser.executeStmt(stmt.get());
    if (twParser.consumeTopLevelStopSignal())
      break;
  }

  Parser jitParser;
  JitEngine engine;
  for (const auto &stmt : prog.statements) {
    engine.runStmt(stmt.get(), jitParser);
    if (jitParser.consumeTopLevelStopSignal())
      break;
  }

  Value twBefore = twParser.readVariableOrConstant("pb_ts_before", -1);
  Value jitBefore = jitParser.readVariableOrConstant("pb_ts_before", -1);
  report("top-level return: statement before it still ran (both sides)",
         valuesDeepEqual(twBefore, jitBefore) && twBefore.number == 1.0);

  Value twAfter, jitAfter;
  captureStderr([&] { twAfter = twParser.readVariableOrConstant("pb_ts_after", -1); });
  captureStderr([&] { jitAfter = jitParser.readVariableOrConstant("pb_ts_after", -1); });
  report("top-level return: statement after it did NOT run (both sides left it unset)",
         valuesDeepEqual(twAfter, jitAfter));
}

// ---- ClearMemory - genuinely destructive (wipes the WHOLE Parser's
// memory, on both sides), so this must run LAST, after every other case
// above has already read back everything it needs. Each side gets its own
// throwaway variable set beforehand so there's no dependency on any
// earlier case's state.
void runClearMemoryCase() {
  std::vector<std::string> lines = {
      "pb_before_clear = 42;",
      "new;",
  };
  auto tw = runTreeWalker(lines);
  auto jit = runViaJit(lines);
  if (!jit.ok) {
    report("clear memory: pb_before_clear gone after 'new'", false,
           "JIT run reported an unsupported statement");
    return;
  }
  Value twVal, jitVal;
  captureStderr([&] { twVal = tw.parser->readVariableOrConstant("pb_before_clear", -1); });
  captureStderr([&] { jitVal = jit.parser->readVariableOrConstant("pb_before_clear", -1); });
  report("clear memory: pb_before_clear gone after 'new' (both sides)",
         valuesDeepEqual(twVal, jitVal));
}

// ---- Phase C: whole-FILE parity via ScriptManager::executeFile() itself -
// the actual code path a running .nc script takes (SM_stage_02.cpp), not
// just JitEngine::runStmt() called directly the way every case above does.
// Exercises what's specific to that path and untested by anything above:
// registerTopLevelDecls() (Pass 1) forward-reference registration ahead of
// a JIT-aware Pass 2 that also attempts to natively compile FunctionDecl/
// ClassDecl (main.cpp's REPL does this too, but per-line, never as a
// pre-registered whole-file batch) - a script here calls a function AND
// constructs a class defined LATER in the same file, which only works
// because Pass 1 already registered both into functionTable_/classTable_
// before Pass 2 (JIT or tree-walker) ever runs a single statement.
void runWholeFileExecutionCase() {
  std::filesystem::path scriptPath =
      std::filesystem::temp_directory_path() / "nc_parity_phase_c_wholefile.nc";
  {
    std::ofstream f(scriptPath);
    f << "pb_wf_total = pb_wf_caller(3);\n"
      << "pb_wf_obj = PbWfLater(9);\n"
      << "function pb_wf_y = pb_wf_caller(pb_wf_x):\n"
      << "pb_wf_y = pb_wf_helper(pb_wf_x) + 1;\n"
      << "fnend\n"
      << "function pb_wf_y = pb_wf_helper(pb_wf_x):\n"
      << "pb_wf_y = pb_wf_x * 2;\n"
      << "fnend\n"
      << "class PbWfLater():\n"
      << "function base(pb_wf_x):\n"
      << "base.v = pb_wf_x;\n"
      << "fnend\n"
      << "csend\n"
      << "print(pb_wf_total);\n"
      << "print(pb_wf_obj);\n";
  }

  // executeFile() builds and executes its OWN internal Parser (see
  // SM_stage_02.cpp) - there's no way to read a variable back out of it
  // afterward, so stdout (the two print() calls at the end of the script)
  // is the only observable signal available here, same reasoning as
  // runPublishCase()'s checkStdout().
  auto runOnce = [&](bool jitOn) -> std::string {
    std::filesystem::path scratchDir = std::filesystem::temp_directory_path();
    ScriptManager manager(scratchDir, scratchDir);
    std::unique_ptr<JitEngine> engine;
    if (jitOn) {
      engine = std::make_unique<JitEngine>();
      manager.setJitEngine(true, engine.get());
    }
    return captureStdout([&] { manager.executeFile(scriptPath.string()); });
  };

  std::string twOut = runOnce(false);
  std::string jitOut = runOnce(true);

  report("whole-file execution: forward-referenced function+class output matches",
         twOut == jitOut, "tree-walker [" + twOut + "] jit [" + jitOut + "]");

  std::filesystem::remove(scriptPath);
}

} // namespace

int main() {
  runSimpleCases();
  runComplexLiteralCase();
  runComplexArithmeticCase();
  runComplexContainerCase();
  runComplexMathCase();
  runComplexPromotionCase();
  runMultiStatementCase();
  runPublishCase();
  runAutoEchoCase();
  runIfElseCase();
  runWhileBreakCase();
  runWhileContinueCase();
  runForRangeCase();
  runForRangeWithStepCase();
  runForRangeBreakContinueCase();
  runSimpleFunctionCase();
  runFunctionWithControlFlowCase();
  runRecursiveFunctionCase();
  runMultiOutputFunctionCase();
  runArrayLiteralAndIndexReadCase();
  runArrayIndexWriteCase();
  runMatrixLiteralAndChainedReadCase();
  runMatrixCommaFormReadCase();
  runMatrixChainedWriteCase();
  runMatrixCommaFormWriteCase();
  runDictAutoVivifyCase();
  runClassCase();
  runFastPathMatrixFallbackCase();
  runFastPathUnitFallbackCase();
  runFastPathNanComparisonCase();
  runPostfixFactorialCase();
  runElementwiseDotOperatorCase();
  runInterleavingCase();
  runBuiltinMathCase();
  runBuiltinAbsCase();
  runBuiltinTrigCase();
  runBuiltinMatrixCase();
  runBuiltinDetCase();
  runBuiltinStatsCase();
  runBuiltinMeanCase();
  runBuiltinShadowedByUserFunctionCase();
  runUnknownFunctionCase();
  runRequirePassCase();
  runEnsurePassCase();
  runRequireFailCase();
  runNativeCallRequireFailureCase();
  runOutputNotAssignedMessageCase();
  runMethodOutputNotAssignedMessageCase();
  runPrivateFieldAccessControlCase();
  runFieldSetNonObjectCase();
  runWildcardReadCase();
  runWildcardWriteCase();
  runMultiKeyDictAssignCase();
  runDynamicFunctionDispatchCase();
  runDynamicClassDispatchCase();
  runAbstractClassRejectionCase();
  runWholeFileExecutionCase();
  runTopLevelStopSignalCase();
  runClearMemoryCase(); // destructive - must stay last

  std::cout << "\n" << (failures == 0 ? "ALL PASS" : ("FAILURES: " + std::to_string(failures))) << "\n";
  return failures == 0 ? 0 : 1;
}
