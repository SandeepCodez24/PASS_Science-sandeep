// Tests of ops/time/time_zone.cpp. It stands alone (no interpreter), so it can
// be built and run on any operating system first when porting:
//
//   cmake --build <build folder> --target nc_time_tests
//   <build folder>/nc_time_tests
//
// With a file argument it also checks the "zone utc offset" and "zone local
// kind first second" lines of a table made by an independent implementation
// (see tools/make_time_zone_oracle.py).
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>

#include "../../runtime/interpreter/ops/time/time_zone.h"

using namespace nctime;

namespace {

int g_failures = 0;
int g_checks = 0;

void check(bool ok, const std::string &what) {
  g_checks++;
  if (!ok) {
    g_failures++;
    std::printf("FAILED: %s\n", what.c_str());
  }
}

int64_t utcSeconds(int64_t y, unsigned mo, unsigned d, int h, int mi = 0, int s = 0) {
  return daysFromCivil(y, mo, d) * 86400 + h * 3600 + mi * 60 + s;
}

void checkOffset(const char *zoneName, int64_t utc, int expected) {
  const TimeZone *zone = findTimeZone(zoneName);
  check(zone != nullptr, std::string("zone exists: ") + zoneName);
  if (zone)
    check(zone->offsetAt(utc) == expected, std::string(zoneName) + " at " + std::to_string(utc) +
                                               ": expected " + std::to_string(expected) + ", got " +
                                               std::to_string(zone->offsetAt(utc)));
}

void checkLocal(const char *zoneName, int64_t local, LocalInfo::Kind kind, int first, int second = 0) {
  const TimeZone *zone = findTimeZone(zoneName);
  check(zone != nullptr, std::string("zone exists: ") + zoneName);
  if (!zone)
    return;
  const LocalInfo info = zone->lookupLocal(local);
  check(info.kind == kind && info.firstOffset == first &&
            (kind == LocalInfo::Kind::Unique || info.secondOffset == second),
        std::string(zoneName) + " local " + std::to_string(local));
}

void testCalendar() {
  check(daysFromCivil(1970, 1, 1) == 0, "day 0");
  check(daysFromCivil(2000, 3, 1) == 11017, "2000-03-01");
  check(daysFromCivil(1600, 2, 29) == -135081, "1600-02-29");
  for (int64_t day = -110000; day <= 110000; day += 13) {
    int64_t y = 0;
    unsigned m = 0, d = 0;
    civilFromDays(day, y, m, d);
    check(daysFromCivil(y, m, d) == day, "calendar round trip");
    check(d >= 1 && d <= lastDayOfMonth(y, m), "day in month");
  }
  check(lastDayOfMonth(2024, 2) == 29 && lastDayOfMonth(2026, 2) == 28, "leap");
  check(lastDayOfMonth(1900, 2) == 28 && lastDayOfMonth(2000, 2) == 29, "century leap");
}

void testOffsets() {
  checkOffset("UTC", utcSeconds(2026, 7, 1, 0), 0);
  checkOffset("Asia/Kolkata", utcSeconds(2026, 7, 1, 0), 19800);
  checkOffset("Asia/Calcutta", utcSeconds(2026, 7, 1, 0), 19800); // a link
  checkOffset("Asia/Kathmandu", utcSeconds(2026, 1, 1, 0), 20700);
  checkOffset("America/New_York", utcSeconds(2026, 1, 15, 0), -18000);
  checkOffset("America/New_York", utcSeconds(2026, 7, 15, 0), -14400);
  // The exact instants of the 2026 changes.
  checkOffset("America/New_York", utcSeconds(2026, 3, 8, 6, 59, 59), -18000);
  checkOffset("America/New_York", utcSeconds(2026, 3, 8, 7), -14400);
  checkOffset("America/New_York", utcSeconds(2026, 11, 1, 5, 59, 59), -14400);
  checkOffset("America/New_York", utcSeconds(2026, 11, 1, 6), -18000);
  checkOffset("Europe/Berlin", utcSeconds(2026, 7, 1, 0), 7200);
  // Far beyond the file's table: only the footer rule can answer.
  checkOffset("America/New_York", utcSeconds(2260, 1, 15, 0), -18000);
  checkOffset("America/New_York", utcSeconds(2260, 7, 15, 0), -14400);
  // Southern hemisphere: the rule's year wraps around.
  checkOffset("Australia/Sydney", utcSeconds(2200, 1, 15, 0), 39600);
  checkOffset("Australia/Sydney", utcSeconds(2200, 7, 15, 0), 36000);
  // Half-hour daylight saving; "negative" daylight saving.
  checkOffset("Australia/Lord_Howe", utcSeconds(2200, 1, 15, 0), 39600);
  checkOffset("Australia/Lord_Howe", utcSeconds(2200, 7, 15, 0), 37800);
  checkOffset("Europe/Dublin", utcSeconds(2200, 1, 15, 0), 0);
  checkOffset("Europe/Dublin", utcSeconds(2200, 7, 15, 0), 3600);
  // The file's last transition may change no offset but still says when the
  // rule starts: Lithuania kept no daylight saving until 2003.
  checkOffset("Europe/Vilnius", utcSeconds(2002, 7, 24, 12), 7200);
  checkOffset("Europe/Vilnius", utcSeconds(2003, 7, 24, 12), 10800);
  // ... and its only transition may be such a marker.
  checkOffset("Antarctica/Troll", utcSeconds(1990, 7, 1, 0), 0);
  checkOffset("Antarctica/Troll", utcSeconds(2010, 7, 1, 0), 7200);
  // History before the first rule: local mean time, to the second.
  checkOffset("Asia/Kolkata", utcSeconds(1800, 1, 1, 0), 21208);
}

void testLocalTimes() {
  using Kind = LocalInfo::Kind;
  checkLocal("America/New_York", utcSeconds(2026, 7, 1, 12), Kind::Unique, -14400);
  checkLocal("America/New_York", utcSeconds(2026, 3, 8, 2, 30), Kind::Gap, -18000, -14400);
  checkLocal("America/New_York", utcSeconds(2026, 3, 8, 1, 59, 59), Kind::Unique, -18000);
  checkLocal("America/New_York", utcSeconds(2026, 3, 8, 3), Kind::Unique, -14400);
  checkLocal("America/New_York", utcSeconds(2026, 11, 1, 1, 30), Kind::Overlap, -14400, -18000);
  checkLocal("America/New_York", utcSeconds(2026, 11, 1, 0, 59, 59), Kind::Unique, -14400);
  checkLocal("America/New_York", utcSeconds(2026, 11, 1, 2), Kind::Unique, -18000);
  checkLocal("America/New_York", utcSeconds(2250, 7, 1, 12), Kind::Unique, -14400);
  checkLocal("Asia/Kolkata", utcSeconds(2026, 7, 1, 12), Kind::Unique, 19800);
  // Samoa skipped the whole of 2011-12-30.
  checkLocal("Pacific/Apia", utcSeconds(2011, 12, 30, 12), Kind::Gap, -36000, 50400);
  const LocalInfo gap = findTimeZone("America/New_York")->lookupLocal(utcSeconds(2026, 3, 8, 2, 30));
  check(gap.transition == utcSeconds(2026, 3, 8, 7), "gap transition");
}

void testPosixRules() {
  TimeZone z;
  check(TimeZone::fromPosixRule("IST-5:30", "x", z) && z.offsetAt(0) == 19800, "fixed rule");
  check(TimeZone::fromPosixRule("<+0330>-3:30", "x", z) && z.offsetAt(0) == 12600, "quoted name");
  check(TimeZone::fromPosixRule("EST5EDT,M3.2.0,M11.1.0", "x", z), "rule with dates");
  check(z.offsetAt(utcSeconds(2030, 1, 1, 0)) == -18000, "rule winter");
  check(z.offsetAt(utcSeconds(2030, 7, 1, 0)) == -14400, "rule summer");
  check(TimeZone::fromPosixRule("AAA3BBB,J60/0,J300/0", "x", z), "Julian rule");
  check(z.offsetAt(utcSeconds(2024, 3, 1, 3)) == -7200, "J60 is March 1 in a leap year");
  check(z.offsetAt(utcSeconds(2024, 2, 29, 12)) == -10800, "before J60");
  // On daylight saving all year: no change, whatever the date.
  check(TimeZone::fromPosixRule("XXX3YYY2,0/0,J365/25", "x", z), "all-year rule");
  check(z.offsetAt(utcSeconds(2030, 7, 1, 0)) == -7200 && z.offsetAt(utcSeconds(2030, 1, 1, 12)) == -7200,
        "all-year offset");
  check(z.lookupLocal(utcSeconds(2031, 1, 1, 0)).kind == LocalInfo::Kind::Unique, "all-year local");
  for (const char *bad : {"", "AB", "EST", "EST5EDT,M3", "EST5EDT,M13.1.0,M1.1.0", "EST5,", "<EST5", "EST5EDT,M3.2.0"})
    check(!TimeZone::fromPosixRule(bad, "x", z), std::string("rejected: ") + bad);
}

void testTzifParsing() {
  TimeZone z;
  const unsigned char junk[] = {'T', 'Z', 'i', 'f', '2', 0, 0, 0};
  check(!TimeZone::fromTzif(junk, sizeof junk, "x", z), "truncated file");
  check(!TimeZone::fromTzif(junk, 0, "x", z), "empty file");
}

void testNames() {
  check(findTimeZone("Not/AZone") == nullptr, "unknown name");
  check(findTimeZone("") == nullptr, "empty name");
  check(findTimeZone("utc") == nullptr, "names are exact");
  // Not IANA names, but accepted since nc relied on ICU.
  check(findTimeZone("IST") && findTimeZone("IST")->offsetAt(0) == 19800, "legacy IST");
  check(findTimeZone("PST") && findTimeZone("PST")->offsetAt(utcSeconds(2026, 1, 1, 0)) == -28800,
        "legacy PST");
  check(findTimeZone("UTC") == findTimeZone("UTC"), "same object every time");
  check(findTimeZone("Asia/Kolkata")->name() == "Asia/Kolkata", "name kept");
  check(localTimeZone() != nullptr, "local zone");
  check(zoneNameFromPath("/var/db/timezone/zoneinfo/Asia/Kolkata") == "Asia/Kolkata", "mac path");
  check(zoneNameFromPath("/usr/share/zoneinfo/UTC") == "UTC", "linux path");
  check(zoneNameFromPath("/etc/localtime").empty(), "no zoneinfo in path");
}

void testOracle(const char *path) {
  std::ifstream file(path);
  check(file.good(), std::string("oracle file ") + path);
  std::string line;
  size_t lines = 0;
  while (std::getline(file, line)) {
    std::istringstream in(line);
    std::string zoneName, what;
    int64_t when = 0;
    in >> what >> zoneName >> when;
    const TimeZone *zone = findTimeZone(zoneName);
    check(zone != nullptr, "oracle zone " + zoneName);
    if (!zone)
      continue;
    lines++;
    if (what == "utc") {
      int expected = 0;
      in >> expected;
      check(zone->offsetAt(when) == expected, line + " got " + std::to_string(zone->offsetAt(when)));
    } else {
      char kind = 0;
      int first = 0, second = 0;
      in >> kind >> first >> second;
      const LocalInfo info = zone->lookupLocal(when);
      const char got = info.kind == LocalInfo::Kind::Unique ? 'U' : info.kind == LocalInfo::Kind::Gap ? 'G' : 'O';
      check(got == kind && info.firstOffset == first && (kind == 'U' || info.secondOffset == second),
            line + " got " + got + " " + std::to_string(info.firstOffset) + " " +
                std::to_string(info.secondOffset));
    }
  }
  std::printf("oracle lines checked: %zu\n", lines);
}

} // namespace

int main(int argc, char **argv) {
  testCalendar();
  testOffsets();
  testLocalTimes();
  testPosixRules();
  testTzifParsing();
  testNames();
  if (argc > 1)
    testOracle(argv[1]);
  std::printf("time zone tests: %d checks, %d failed (database %s, local zone %s)\n", g_checks,
              g_failures, timeZoneDataVersion(), localTimeZone()->name().c_str());
  return g_failures == 0 ? 0 : 1;
}
