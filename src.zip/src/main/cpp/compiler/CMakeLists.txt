# NC compiler frontend (lexer, parser, conditional/logical operators).
# Exposes its sources/includes to the top-level ../CMakeLists.txt, which
# links them into the single `nc` executable together with runtime/CMakeLists.txt.

set(COMPILER_SOURCES
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/main.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/ast/ast.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/lexer/lexer.cpp
    # Name rules: _$ subscript / _@ superscript, allowed characters, NFC.
    # Shared with runtime/data/DataEngine.cpp (load_workspace name check).
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/lexer/identifier_rules.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_statement.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_expression.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_typed_ops.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_factor.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_block_exec.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_function.cpp
    # Function files: <name>.nc on the path / the personal library (P1).
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_function_files.cpp
    # The Process Data window's op:"process" / op:"check" (P2, P4, P6).
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/process_runner.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_class.cpp
    # Defaults in headers, named values in calls, overload choice.
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_args.cpp
    # ClassName.base / ClassName.info / obj.base / obj.info.
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_class_info.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_program.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_exec_stmt.cpp
    # try ... except ... tend, escalate, warn, trace(), assert and assert_*.
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_exceptions.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_resolve.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser/parser_locals.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/value_compare.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/conditional_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/logical_builtin.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_if.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_empty.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_nan.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_and.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_or.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_not.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_nand.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_nor.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_in.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_not_in.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_equal_to.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_not_equal_to.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_less_than.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_greater_than.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_less_than_or_equal.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_greater_than_or_equal.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_true.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_false.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_zero.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_positive.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/conditional_opr/func_is_negative.cpp
    PARENT_SCOPE
)

set(COMPILER_INCLUDE_DIRS
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/lexer
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/parser
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/tokens
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler_src/ast
    PARENT_SCOPE
)
