abstract class Sensor()
    function base()
        base.id = 0;
    fnend

    function output = read()
    fnend

    function Tag = name()
        Tag = "sensor";
    fnend
csend

class TempSensor(Sensor)
    function output = read()
        output = 98.6;
    fnend
csend

t = TempSensor();
publish("concrete-read:", t.read());
publish("concrete-inherited-name:", t.name());

direct = Sensor();
publish("after-direct-abstract-instantiation:", direct);

class Broken(Sensor)
    function Tag = name()
        Tag = "broken-but-no-read-override";
    fnend
csend

bad = Broken();
publish("after-missing-override:", bad);

class MidLevel(Sensor)
csend

mid = MidLevel();
publish("after-midlevel-still-missing-override:", mid);

class FinalImpl(MidLevel)
    function output = read()
        output = 1.5;
    fnend
csend

f = FinalImpl();
publish("multi-level-override-satisfies-contract:", f.read());

class NotAbstract()
    function Z = broken()
    fnend
csend
publish("after-nonabstract-bodyless-registration");

publish("done");
