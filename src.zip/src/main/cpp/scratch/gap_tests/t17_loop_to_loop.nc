i1 = 1;
while i1 <= 2:
    for i2 = [1:2]:
        if i2 == 1:
            publish("while->for->if:", i1, i2);
        else:
            publish("while->for->else:", i1, i2);
        iend
    fend
    i1 = i1 + 1;
wend

for i3 = [1:2]:
    if i3 == 1:
        j = 0;
        while j < 2:
            publish("for->if->while:", i3, j);
            j = j + 1;
        wend
    else:
        publish("for->else:", i3);
    iend
fend
