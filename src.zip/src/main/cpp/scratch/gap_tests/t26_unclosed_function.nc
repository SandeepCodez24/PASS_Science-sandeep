publish("before");

function B = broken(A)
    B = A;
