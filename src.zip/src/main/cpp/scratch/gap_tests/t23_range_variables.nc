function T = sumToN(N)
    T = 0;
    for i = [1:N]:
        T = T + i;
    fend
fnend

r = sumToN(5);
publish("sumToN(5):", r);

lo = 2;
hi = 8;
s2 = 0;
for i = [lo:hi]:
    s2 = s2 + i;
fend
publish("for lo:hi:", s2);

step = 2;
s3 = 0;
for i = [0:step:10]:
    s3 = s3 + i;
fend
publish("for 0:step:10:", s3);

n = 6;
A = [1:n];
publish("range-literal-var:", A);

B = [1:n-1];
publish("range-literal-expr:", B);

start = -3;
C = [start:2];
publish("range-literal-negvar:", C);

negCount = 0;
for i = [-n:0]:
    negCount = negCount + 1;
fend
publish("neg-var-for-count:", negCount);

D = [1,2,3];
publish("plain-array-still-works:", D);

M = [[1,2],[3,4]];
publish("matrix-still-works:", M);
