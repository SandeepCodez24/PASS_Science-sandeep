function B = square(A)
    B = A * A;
fnend

publish("nested-call-test:", square(5));
publish("after");
