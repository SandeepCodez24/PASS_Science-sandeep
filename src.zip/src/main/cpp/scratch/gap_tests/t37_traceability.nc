class Reading()
    function base(value)
        base.value = value;
    fnend

    function Z = Scale(k)
        Z = base.value * k;
    fnend

    function reset()
        base.value = 0;
    fnend
csend

r = Reading(23.5);
scaled = r.Scale(2);
publish("scaled:", scaled);

log1 = r.lineage();
publish("lineage-after-one-call:", log1);

r.reset();
log2 = r.lineage();
publish("lineage-after-void-call:", log2);

r2 = Reading(100);
log3 = r2.lineage();
publish("independent-instance-lineage:", log3);

r2.Scale(3);
r2.Scale(4);
log4 = r2.lineage();
publish("multiple-calls-lineage:", log4);

publish("r-lineage-still-independent:", r.lineage());

publish("done");
