Akey = ['name', 'age', 'blood'];
Bvalue = ['apj', '63', 'A+'];
A = dict(Akey: Bvalue);
Keys = A.keys();
publish(Keys);
Values = A.values();
publish(Values);
L = A.size();
publish(L);
