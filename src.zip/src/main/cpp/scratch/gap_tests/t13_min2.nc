Akey = ["a", "b"];
Bvalue = ["1", "2"];
A = dict(Akey: Bvalue);
publish("before");
A.keys();
publish("after");
