function B = combine(A1, A2)
    B = A1 + A2;
fnend

function B = combine(A1, A2, A3)
    B = A1 + A2 + A3;
fnend

publish("combine-2arg:", combine(1, 2));
publish("combine-3arg:", combine(1, 2, 3));

wrong = combine(1, 2, 3, 4);
publish("after-wrong-arity:", wrong);

class Shape()
    function base(name)
        base.name = name;
    fnend

    function A = Area(side)
        A = side * side;
    fnend

    function A = Area(w, h)
        A = w * h;
    fnend
csend

s = Shape("box");
publish("area-1arg-square:", s.Area(4));
publish("area-2arg-rect:", s.Area(3, 5));

badArea = s.Area(1, 2, 3);
publish("after-method-wrong-arity:", badArea);

class Base2()
    function base(x)
        base.x = x;
    fnend
    function base(x, y)
        base.x = x;
        base.y = y;
    fnend

    function S = Sum()
        S = base.x;
    fnend
csend

b1 = Base2(5);
publish("ctor-overload-1arg:", b1.Sum());

class Child2(Base2)
    function C = ChildOnly()
        C = base.x * 10;
    fnend
csend

c1 = Child2(7);
publish("inherited-ctor-1arg:", c1.ChildOnly());

c2 = Child2(2, 3);
publish("inherited-ctor-2arg-sum:", c2.Sum());

publish("done");
