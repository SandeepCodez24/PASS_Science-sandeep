function B = square(A)
    B = A * A;
fnend

function (S,P) = arithmetics(A1,A2)
    S = A1 + A2;
    P = A1 * A2;
fnend

function B = greet()
    B = "hi";
fnend

function shout(A)
    publish("shouted:", A);
fnend

function nop
    x = 999;
fnend

function F = fact(N)
    if N <= 1:
        F = 1;
    else:
        F1 = fact(N - 1);
        F = N * F1;
    iend
fnend

function T = sumTo(N)
    T = 0;
    for i = [1:N]:
        if i == 4:
            break;
        iend
        T = T + i;
    fend
fnend

function G = guarded(A)
    if A < 0:
        G = -1;
        return;
    iend
    G = A * 2;
fnend

x = 5;
y = square(x);
publish("square:", y);

(sum1, prod1) = arithmetics(3, 4);
publish("arith:", sum1, prod1);

g = greet();
publish("greet:", g);

shout("hello");

nop;
publish("after-nop, x-still:", x);

r = fact(5);
publish("fact5:", r);

s = sumTo(10);
publish("sumTo(break at 4):", s);

g1 = guarded(-5);
publish("guarded(-5):", g1);
g2 = guarded(5);
publish("guarded(5):", g2);

publish("no-leak-check: next line should error, B never existed in caller scope");
B;
