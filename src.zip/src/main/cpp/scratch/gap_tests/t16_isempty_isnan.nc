A = [1,2,3];
B = [];
publish(is_empty(A));
publish(is_empty(B));
x = 0/0;
publish(is_nan(x));
publish(is_nan(5));
