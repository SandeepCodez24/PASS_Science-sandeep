class Base()
    protected count;
    private secret;

    function base(mean, std)
        base.mean = mean;
        base.std = std;
        base.count = 0;
        base.secret = 42;
    fnend

    function Z = PDF(A)
        Z = (A - base.mean) / base.std;
    fnend

    function increment()
        base.count = base.count + 1;
    fnend

    function Tag = Label()
        Tag = "base-label";
    fnend
csend

class Extended(Base)
    function base(mean, std, skew)
        parent(mean, std);
        base.skew = skew;
    fnend

    function Tag = Label()
        Tag = "extended-label";
    fnend

    function C = readParentProtected()
        C = base.count;
    fnend
csend

class NoOwnCtor(Base)
csend

e = Extended(10, 2, 5);
publish("inherited-PDF:", e.PDF(12));

e.increment();
e.increment();
publish("inherited-method-mutation-via-protected:", e.readParentProtected());

publish("override:", e.Label());

b = Base(1, 1);
publish("base-still-own-label:", b.Label());

n = NoOwnCtor(3, 4);
publish("inherited-ctor-PDF:", n.PDF(6));

class BadPrivate(Base)
    function S = readSecret()
        S = base.secret;
    fnend
csend

bp = BadPrivate(0, 1);
leaked = bp.readSecret();
publish("private-should-not-leak:", leaked);

function callParentOutside()
    parent(1, 2);
fnend
callParentOutside();
publish("after-parent-outside-class");

class NoParent()
    function base()
        parent();
    fnend
csend
np = NoParent();
publish("after-parent-no-parent-class");

publish("done");
