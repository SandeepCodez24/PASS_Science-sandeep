function B = square(A)
    B = A * A;
fnend

y = square(1, 2);
publish("after-arg-mismatch:", y);

z = notAFunction(1);
publish("after-unknown:", z);

function B = broken(A)
    x = A;
fnend

w = broken(3);
publish("after-missing-output:", w);
