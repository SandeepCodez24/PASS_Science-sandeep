class Athematic()
    private mean, std;
    protected count;

    function base(mean, std)
        base.mean = mean;
        base.std = std;
        base.count = 0;
        base.label = "public-field";
    fnend

    function Z = PDF(A)
        Z = (A - base.mean) / base.std;
    fnend

    function increment()
        base.count = base.count + 1;
    fnend

    function C = getCount()
        C = base.count;
    fnend

    function Eq = SameMean(other)
        Eq = base.mean == other.mean;
    fnend
csend

a = Athematic(10, 2);
publish("PDF(12)-via-private-fields:", a.PDF(12));

a.increment();
a.increment();
publish("protected-count-via-method:", a.getCount());

b = Athematic(10, 5);
publish("same-class-cross-instance-private-read:", a.SameMean(b));

publish("public-field-from-outside:", a.label);

meanOutside = a.mean;
publish("after-outside-private-read:", meanOutside);

a.mean = 999;
publish("after-outside-private-write:", a.PDF(12));

countOutside = a.count;
publish("after-outside-protected-read:", countOutside);

publish("done");
