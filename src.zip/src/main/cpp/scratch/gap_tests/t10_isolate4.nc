a = 5; b = 7;
if a == b:
    publish("branch1-true");
else:
    publish("branch2-else-fires");
iend
