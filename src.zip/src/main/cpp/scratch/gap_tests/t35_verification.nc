function D = distance(v, a, t)
    require t >= 0;
    D = v * t + 0.5 * a * t * t;
    ensure D >= 0;
fnend

publish("valid-call:", distance(10, 2, 3));

bad1 = distance(10, 2, -1);
publish("after-require-violation:", bad1);

class Motion()
    function base(v, a)
        base.v = v;
        base.a = a;
    fnend

    function D = Distance(t)
        require t >= 0;
        D = base.v * t + 0.5 * base.a * t * t;
        ensure D >= 0;
    fnend
csend

m = Motion(5, 1);
publish("method-valid:", m.Distance(2));

bad2 = m.Distance(-3);
publish("after-method-require-violation:", bad2);

function T = sumPositive(N)
    T = 0;
    for i = [1:N]:
        require i <= 100;
        T = T + i;
    fend
fnend

publish("require-inside-loop-ok:", sumPositive(5));

publish("before-toplevel-require");
require 1 == 2;
publish("after-toplevel-require-should-not-print");
