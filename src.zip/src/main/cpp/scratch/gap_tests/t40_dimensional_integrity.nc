d = 5 * m;
publish("length:", d);

v = 10 * m / s;
publish("velocity:", v);

a = 9.8 * m / s^2;
publish("accel:", a);

f = 2 * kg * (3 * m / s^2);
publish("force-as-kg-m-per-s2:", f);

x = 5 * m + 3 * m;
publish("compatible-add:", x);

t = 3 * s;
dist = v * t;
publish("mul-combine-to-length:", dist);

spd = (10 * m) / (2 * s);
publish("div-combine-to-velocity:", spd);

neg = -(5 * m);
publish("unary-minus-preserves-unit:", neg);

plain = 2 + 3;
publish("plain-arithmetic-unchanged:", plain);

cmpOk = (5 * m) > (3 * m);
publish("compatible-comparison:", cmpOk);

v0 = 5 * m / s;
a0 = 2 * m / s^2;
t0 = 4 * s;
motion = v0 * t0 + 0.5 * a0 * t0^2;
publish("motion-equation:", motion);

s = 100;
publish("shadowed-s-is-plain-number:", s);

y = 5 * m + 3 * kg;
publish("after-incompatible-add:", y);

cmpBad = (5 * m) > (3 * kg);
publish("after-incompatible-comparison:", cmpBad);

publish("done");
