x = NotAClass(1, 2);
publish("after-unknown-class:", x);

class NoCtor()
    function Z = Foo()
        Z = 1;
    fnend
csend

y = NoCtor();
publish("after-no-ctor:", y);

class Simple()
    function base(v)
        base.v = v;
    fnend
csend

s = Simple(5);
w = s.NoSuchMethod();
publish("after-unknown-method:", w);

s2 = Simple(1, 2);
publish("after-ctor-arg-mismatch:", s2);

n = 5;
n.field = 10;
publish("after-dotassign-nonobject:", n);

publish("field-read-on-nonobject-should-fallback-to-dot-operator-error");
