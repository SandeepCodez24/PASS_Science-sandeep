Akey = ["name", "age", "blood"];
Bvalue = ["apj", "63", "A+"];
A = dict(Akey: Bvalue);
publish(A);
Keys = A.keys();
publish(Keys);
