function T = sumUntilBig(N)
    T = 0;
    for i = [1:N]:
        require i <= 3;
        T = T + i;
    fend
    publish("this-should-not-print-if-abort-works");
fnend

result = sumUntilBig(10);
publish("after-loop-abort:", result);
