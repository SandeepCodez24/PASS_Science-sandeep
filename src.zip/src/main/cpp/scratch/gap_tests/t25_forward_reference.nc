x = square(5);
publish("forward-call-before-def:", x);

y = 0;
y = doubled(x);
publish("chained-forward-call:", y);

isEvenResult = isEven(6);
publish("mutual-recursion-isEven(6):", isEvenResult);

isOddResult = isOdd(7);
publish("mutual-recursion-isOdd(7):", isOddResult);

publish("done-with-forward-calls");

function B = square(A)
    B = A * A;
fnend

function B = doubled(A)
    B = A * 2;
fnend

function R = isEven(N)
    if N == 0:
        R = 1;
    else:
        R = isOdd(N - 1);
    iend
fnend

function R = isOdd(N)
    if N == 0:
        R = 0;
    else:
        R = isEven(N - 1);
    iend
fnend
