function nop2
    x = 42;
fnend

function B = greet2()
    B = "hi2";
fnend

function (S,P) = pair(A1,A2)
    S = A1 + A2;
    P = A1 * A2;
fnend

function T = loopContinue(N)
    T = 0;
    for i = [1:N]:
        if i == 3:
            continue;
        iend
        T = T + i;
    fend
fnend

a = nop2;
publish("bare-no-parens-call-ok");

b = greet2();
publish("explicit-parens-call:", b);

c1 = 0;
c1 = 0;
result = 0;
result = loopContinue(5);
publish("continue-inside-function:", result);

(q1, q2, q3) = pair(2, 3);
publish("should-not-print-arity-error-below");
