publish("before");
return;
publish("after-should-not-print-if-return-stops-script");
