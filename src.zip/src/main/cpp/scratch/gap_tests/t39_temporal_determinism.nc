class Controller() @rate(10Hz)
    function base()
        base.ticks = 0;
    fnend

    function step()
        base.ticks = base.ticks + 1;
    fnend

    function T = getTicks()
        T = base.ticks;
    fnend
csend

c = Controller();

r0 = c.tick(0);
publish("t=0-ran:", r0, "ticks:", c.getTicks());

r1 = c.tick(0.05);
publish("t=0.05-ran:", r1, "ticks:", c.getTicks());

r2 = c.tick(0.1);
publish("t=0.1-ran:", r2, "ticks:", c.getTicks());

r3 = c.tick(0.15);
publish("t=0.15-ran:", r3, "ticks:", c.getTicks());

r4 = c.tick(0.2);
publish("t=0.2-ran:", r4, "ticks:", c.getTicks());

class NoRate()
    function base()
        base.x = 0;
    fnend
csend

nr = NoRate();
nr.tick(0);
publish("after-norate-tick-attempt");

class NoStep() @rate(1Hz)
    function base()
        base.y = 0;
    fnend
csend

ns = NoStep();
ns.tick(0);
publish("after-nostep-tick-attempt");

class BaseController() @rate(2Hz)
    function base()
        base.count = 0;
    fnend

    function step()
        base.count = base.count + 1;
    fnend
csend

class ChildController(BaseController)
csend

cc = ChildController();
cc.tick(0);
cc.tick(0.3);
cc.tick(0.6);
publish("inherited-rate-count:", cc.count);

class OverrideController(BaseController)
    function step()
        base.count = base.count + 100;
    fnend
csend

oc = OverrideController();
oc.tick(0);
oc.tick(0.6);
publish("override-step-count:", oc.count);

publish("tick-lineage:", c.lineage());

publish("done");
