for i = [1:5]:
    if i == 3:
        break;
    iend
    publish("for-break:", i);
fend

for i = [1:5]:
    if i == 3:
        continue;
    iend
    publish("for-continue:", i);
fend

j = 0;
while j < 10:
    j = j + 1;
    if j == 4:
        break;
    iend
    publish("while-break:", j);
wend

k = 0;
while k < 5:
    k = k + 1;
    if k == 2:
        continue;
    iend
    publish("while-continue:", k);
wend

for i = [1:3]:
    for j = [1:3]:
        if j == 2:
            break;
        iend
        publish("nested:", i, j);
    fend
fend
