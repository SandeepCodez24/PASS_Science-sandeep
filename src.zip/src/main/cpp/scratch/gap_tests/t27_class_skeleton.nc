class Athematic()
    function base(mean, std)
        base.mean = mean;
        base.std = std;
    fnend

    function Z = PDF(A)
        Z = (A - base.mean) / base.std;
    fnend

    function increment()
        base.mean = base.mean + 1;
    fnend
csend

a = Athematic(10, 2);
publish("a-mean:", a);

z1 = a.PDF(12);
publish("PDF(12):", z1);

a.increment();
z2 = a.PDF(12);
publish("after-increment-PDF(12):", z2);

b = Athematic(0, 1);
zb = b.PDF(2);
publish("independent-instance-b:", zb);
publish("a-still-independent:", a);

r = Reading(23.5);
scaled = r.Scale(2);
publish("scaled:", scaled);

publish("done");

class Reading()
    function base(value)
        base.value = value;
    fnend

    function Z = Scale(k)
        Z = base.value * k;
    fnend
csend
