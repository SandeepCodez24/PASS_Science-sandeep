# Runs every .nc script under scratch/tests/ against nc.exe and diffs its
# stdout against the co-located .expected file. Each script runs against a
# fresh workspace (variables.txt removed first) so tests don't leak state
# into each other.

$repoRoot = Resolve-Path "$PSScriptRoot/../../../.."
$cppDir = Join-Path $repoRoot "src/main/cpp"
$exe = Join-Path $cppDir "nc.exe"
$testsDir = Join-Path $PSScriptRoot "tests"
$varsFile = Join-Path $repoRoot "variables.txt"

if (-not (Test-Path $exe)) {
    Write-Host "nc.exe not found at $exe - build it first with scratch/build_upi.ps1" -ForegroundColor Red
    exit 1
}

$scripts = Get-ChildItem -Path $testsDir -Filter "*.nc" | Sort-Object Name

$passCount = 0
$failCount = 0

foreach ($script in $scripts) {
    $expectedFile = Join-Path $testsDir ($script.BaseName + ".expected")

    if (-not (Test-Path $expectedFile)) {
        Write-Host "SKIP  $($script.Name) (no .expected file)" -ForegroundColor Yellow
        continue
    }

    if (Test-Path $varsFile) {
        Remove-Item $varsFile -Force
    }

    Push-Location $repoRoot
    $actual = & $exe $script.FullName 2>$null | Out-String
    Pop-Location

    $expected = Get-Content -Raw $expectedFile

    # Normalize line endings before comparing.
    $actualNorm = $actual -replace "`r`n", "`n"
    $expectedNorm = $expected -replace "`r`n", "`n"

    if ($actualNorm.TrimEnd("`n") -eq $expectedNorm.TrimEnd("`n")) {
        Write-Host "PASS  $($script.Name)" -ForegroundColor Green
        $passCount++
    } else {
        Write-Host "FAIL  $($script.Name)" -ForegroundColor Red
        Write-Host "  --- expected ---" -ForegroundColor DarkGray
        Write-Host $expectedNorm
        Write-Host "  --- actual ---" -ForegroundColor DarkGray
        Write-Host $actualNorm
        $failCount++
    }
}

if (Test-Path $varsFile) {
    Remove-Item $varsFile -Force
}

Write-Host ""
Write-Host "Summary: $passCount passed, $failCount failed" -ForegroundColor Cyan

if ($failCount -gt 0) {
    exit 1
}
exit 0
