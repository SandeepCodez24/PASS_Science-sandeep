function S = sumRange(lo, hi)
  s2 = 0;
  for i = [lo:hi]:
    s2 = s2 + i;
  fend
  S = s2;
fnend

publish(sumRange(1, 5));
