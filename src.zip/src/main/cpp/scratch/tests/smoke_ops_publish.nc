a = 1
b = 0;
publish(a !& b);
publish(a !| b);
arr = [1,2,3];
publish(2 is_in arr);
publish(5 is_in arr);
publish(5 is_not_in arr);
publish(a, b, "India", a+b);
x = 1; y = 2; z = x + y;
print(z);
