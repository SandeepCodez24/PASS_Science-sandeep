A["name"] = "Alice";
A["age"] = 30;
publish(A["name"]);
publish(A["age"]);

B["a", "b", "c"] = [1, 2, 3];
publish(B["a"]);
publish(B["b"]);
publish(B["c"]);
