a=5;
c=5;
publish(!(a==c));
publish(!(a > c));
publish(5!);
