x = 5;
if x == 1
  print("one");
elseif x == 5
  print("five");
elseif x == 6
  print("six");
else
  print("other");
iend

y = 3;
if y == 1
  print("y-one");
elseif y == 2
  print("y-two");
else
  print("y-other");
end

if not (x == 99)
  print("not-ninety-nine");
iend

i = 0;
while not (i == 3)
  print(i);
  i = i + 1;
wend

for k = [0:2]
  print(k);
fend
