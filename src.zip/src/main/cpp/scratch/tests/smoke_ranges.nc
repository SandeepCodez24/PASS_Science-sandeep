x = [1:5];
publish(x);
y = [0:2:10];
publish(y);
z = [1:5);
publish(z);
m = [[1,2],[3,4]];
publish(m);
