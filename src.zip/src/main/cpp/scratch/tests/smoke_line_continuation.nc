x = 1 + ~~
    2 + ~~
    3;
publish(x);
publish(x, ~~
        "done");
