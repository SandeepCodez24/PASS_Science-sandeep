x = "str"; y = "str2"; z = "str";
print(x == y);
print(x != y);
print(x == z);
print(x < y);

l1 = [1,2,3]; l2 = [4,5,6]; l3 = [1,2,3]; l4 = [1,2];
print(l1 == l2);
print(l1 == l3);
print(l1 == l4);
print(l1 != l2);

m1 = [[1,2],[3,4]]; m2 = [[9,9],[9,9]]; m3 = [[1,2],[3,4]];
print(m1 == m2);
print(m1 == m3);
print(m1 != m2);

d1["k"] = 1;
d2["k"] = 2;
d3["k"] = 1;
print(d1 == d2);
print(d1 == d3);
print(d1 != d2);

print(x == 0);
print(l1 == m1);

print(1.5 == 2.5);
print(1.5 == 1.5);
print(1.5 < 2.5);

print("str" is_in ["a", "str", "b"]);
print("str" is_in ["a", "b"]);
