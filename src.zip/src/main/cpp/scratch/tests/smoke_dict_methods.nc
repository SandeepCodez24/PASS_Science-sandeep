A = dict();
A["name"] = "Alice";
A["age"] = 30;
publish(size(A));
publish(keys(A));
publish(values(A));
publish(match_key(A, "name"));
publish(match_key(A, "zzz"));
