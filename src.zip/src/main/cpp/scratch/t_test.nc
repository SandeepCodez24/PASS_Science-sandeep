x = 5;
print(x);
y = x + 10;
print(y);
