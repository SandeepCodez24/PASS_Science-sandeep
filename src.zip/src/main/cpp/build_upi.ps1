$repoRoot = Resolve-Path "$PSScriptRoot/../../.."
$cppDir = Join-Path $repoRoot "src/main/cpp"
$toolchain = Join-Path $repoRoot "build/toolchain"
$clang = "$toolchain/bin/clang++.exe"

$cppFiles = @(
    "compiler/compiler_src/main.cpp",
    "compiler/compiler_src/lexer/lexer.cpp",
    "compiler/compiler_src/parser/parser.cpp",
    "compiler/compiler_src/parser/parser_statement.cpp",
    "compiler/compiler_src/parser/parser_expression.cpp",
    "compiler/compiler_src/parser/parser_factor.cpp",
    "compiler/compiler_src/parser/parser_block_exec.cpp",
    "compiler/compiler_src/parser/parser_block_scan.cpp",
    "compiler/compiler_src/parser/parser_function.cpp",
    "compiler/compiler_src/parser/parser_class.cpp",
    "runtime/interpreter/core/ScriptManager/SM_main.cpp",
    "runtime/interpreter/core/ScriptManager/SM_stage_01.cpp",
    "runtime/interpreter/core/ScriptManager/SM_stage_02.cpp",
    "runtime/interpreter/builtins/builtins.cpp",
    "runtime/interpreter/core/output.cpp",
    "runtime/interpreter/builtins/constants_builtin.cpp",
    "runtime/interpreter/ops/arithmetic/arithmetic.cpp",
    "runtime/interpreter/ops/arithmetic/arithmetic_builtin.cpp",
    "runtime/interpreter/ops/calculus/calculus.cpp",
    "runtime/interpreter/ops/calculus/calculus_builtin.cpp",
    "runtime/interpreter/ops/dc/dc.cpp",
    "runtime/interpreter/ops/dc/dc_builtin.cpp",
    "runtime/interpreter/ops/geometric/geometric.cpp",
    "runtime/interpreter/ops/geometric/geometric_builtin.cpp",
    "compiler/compiler_src/conditional_opr/value_compare.cpp",
    "compiler/compiler_src/conditional_opr/conditional_builtin.cpp",
    "compiler/compiler_src/conditional_opr/logical_builtin.cpp",
    "compiler/compiler_src/conditional_opr/func_if.cpp",
    "compiler/compiler_src/conditional_opr/func_is_empty.cpp",
    "compiler/compiler_src/conditional_opr/func_is_nan.cpp",
    "compiler/compiler_src/conditional_opr/func_and.cpp",
    "compiler/compiler_src/conditional_opr/func_or.cpp",
    "compiler/compiler_src/conditional_opr/func_not.cpp",
    "compiler/compiler_src/conditional_opr/func_nand.cpp",
    "compiler/compiler_src/conditional_opr/func_nor.cpp",
    "compiler/compiler_src/conditional_opr/func_is_in.cpp",
    "compiler/compiler_src/conditional_opr/func_is_not_in.cpp",
    "compiler/compiler_src/conditional_opr/func_equal_to.cpp",
    "compiler/compiler_src/conditional_opr/func_not_equal_to.cpp",
    "compiler/compiler_src/conditional_opr/func_less_than.cpp",
    "compiler/compiler_src/conditional_opr/func_greater_than.cpp",
    "compiler/compiler_src/conditional_opr/func_less_than_or_equal.cpp",
    "compiler/compiler_src/conditional_opr/func_greater_than_or_equal.cpp",
    "compiler/compiler_src/conditional_opr/func_is_true.cpp",
    "compiler/compiler_src/conditional_opr/func_is_false.cpp",
    "compiler/compiler_src/conditional_opr/func_is_zero.cpp",
    "compiler/compiler_src/conditional_opr/func_is_positive.cpp",
    "compiler/compiler_src/conditional_opr/func_is_negative.cpp",
    "runtime/interpreter/ops/matrix/matrix.cpp",
    "runtime/interpreter/ops/matrix/matrix_arithmetic.cpp",
    "runtime/interpreter/ops/matrix/matrix_builtin.cpp",
    "runtime/interpreter/ops/plot/plot_builtin.cpp",
    "runtime/interpreter/ops/statistics/statistics.cpp",
    "runtime/interpreter/ops/statistics/statistics_builtin.cpp",
    "runtime/interpreter/ops/trigonometric/trigonometric.cpp",
    "runtime/interpreter/ops/trigonometric/trigonometric_builtin.cpp",
    "runtime/interpreter/ops/vector/vector.cpp",
    "runtime/interpreter/ops/vector/vector_builtin.cpp",
    "runtime/memory/store/variable_store.cpp",
    "runtime/memory/symbols/symbol_table.cpp"
) | ForEach-Object { Join-Path $cppDir $_ }

$outputExe = Join-Path $cppDir "nc.exe"

$compileArgs = @(
    "-std=c++17", ## C++ standard version
    "-O2", ## Optimization level
    "-Wall", ## Enable all warnings
    "-Wextra", ## Enable extra warnings
    "-Wno-unused-parameter", ## Disable unused parameter warnings
    "--target=x86_64-w64-mingw32", ## cross platform compilation for windows even though clang itself might be a different host build)
    "-isystem", "$toolchain/include/c++", ## the bundled libstdc++ headers, so it doesn't pull in system/MinGW headers
    "-isystem", "$toolchain/include/c++/x86_64-w64-mingw32", ## the target-specific C++ headers and other target-specific files needed for cross-compilation
    "-isystem", "$toolchain/include/c++/backward", ## backward compatibility headers for C++ code that might use older symbols
    "-isystem", "$toolchain/include", ## general include path for system headers that clang should use
    "-B", "$toolchain/bin", ## tells clang where to find the linker/binutils that match this toolchain
    "-I", "$toolchain/custom_libs/eigen3", ##  the vendored Eigen matrix library headers
    "-I", "$cppDir/runtime/interpreter",
    "-I", "$cppDir/runtime/interpreter/core",
    "-I", "$cppDir/compiler/compiler_src/lexer",
    "-I", "$cppDir/compiler/compiler_src/parser",
    "-I", "$cppDir/compiler/compiler_src/tokens",
    "-I", "$cppDir/runtime/memory/store",
    "-I", "$cppDir/runtime/memory/symbols",
    "-I", "$cppDir/runtime/memory"
) + $cppFiles + @("-o", $outputExe)

Write-Host "Running clang++ compilation..."
& $clang @compileArgs
Write-Host "Compilation finished with exit code: $LASTEXITCODE"
Write-Host "Output: $outputExe"

# nc.exe is a MinGW build and needs these runtime DLLs alongside it to run.
# They live permanently in $cppDir (not regenerated by this script) - warn
# rather than silently produce a broken exe if one goes missing.
foreach ($dll in @("libgcc_s_seh-1.dll", "libstdc++-6.dll", "libwinpthread-1.dll")) {
    $dest = Join-Path $cppDir $dll
    if (-not (Test-Path $dest)) {
        Write-Host "WARNING: $dll missing from $cppDir - nc.exe will fail to launch (STATUS_DLL_NOT_FOUND) until it's restored." -ForegroundColor Yellow
    }
}
