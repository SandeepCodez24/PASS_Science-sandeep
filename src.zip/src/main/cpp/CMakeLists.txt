# Portable, native build for the NC compiler/interpreter (`nc`).
#
# Windows: built with the in-house LLVM 23.1.0 toolchain through
# cmake/clang-windows.cmake (see Building_CPP_LLVM23.txt).
# macOS/Linux: built with the system toolchain.
#
# Configure + build, from the repo root (Windows, VS developer shell):
#   cmake -S src/main/cpp -B build/nc-build -G Ninja --toolchain "$PWD\cmake\clang-windows.cmake" -DCMAKE_BUILD_TYPE=Release
#   cmake --build build/nc-build
# Output binary lands directly in src/main/cpp/ (nc.exe on Windows) - the Java
# side (EditorManager.startUPITerminal, EditorFileRunner.integrateDemoCpp)
# expects it there. Runtime DLLs it needs (libomp.dll, ASan DLL) are copied
# next to it automatically.
#
# ----------------------------------------------------------------------------
# BUILD PROFILES
#   Development repo:  -DCMAKE_BUILD_TYPE=Debug            (default options)
#                      -DCMAKE_BUILD_TYPE=Release          (fast test build)
#                      -DNC_SANITIZE=address               (memory-bug hunting)
#   Release repo:      -DCMAKE_BUILD_TYPE=Release -DNC_LTO=ON
#
# OPTIONS (all can be given as -D<NAME>=<value> when configuring)
#   NC_EIGEN_DIR      folder that contains Eigen/       (default: build/third_party/eigen)
#   NC_OPENMP         multithreading via OpenMP          (default: ON with the LLVM toolchain)
#   NC_CPU_BASELINE   -march value for x86-64            (default: x86-64-v2, runs on any PC
#                                                          of the last ~15 years)
#   NC_LTO            ThinLTO whole-program optimisation (default: OFF; ON for releases)
#   NC_STATIC_CRT     static C runtime, no VC++ DLLs     (default: ON for Release builds)
#   NC_PDB            debug symbols (nc.pdb) in Release  (default: ON; archive, never ship)
#   NC_SANITIZE       "", address, undefined, address;undefined  (default: "", dev only;
#                     use with -DCMAKE_BUILD_TYPE=Release, never Debug)
#   NC_EIGEN_MPL2_ONLY  block Eigen parts that are not MPL2-licensed (default: ON)
#   NC_OUTPUT_DIR     folder nc.exe is written to (default: this folder, where
#                     the IDE looks). Give a sanitizer build its own folder:
#                     -DNC_SANITIZE=address -DNC_OUTPUT_DIR=<repo>/build/nc-asan-bin
# ----------------------------------------------------------------------------

cmake_minimum_required(VERSION 3.15)
# C is enabled alongside CXX solely because LLVMConfig.cmake's own transitive
# find_package(LibEdit) probes via check_include_file(), which requires a C
# compiler to be enabled in this project - no .c sources are actually built.
project(upi_nc CXX C)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()
# -DNDEBUG switches off assert() and Eigen's internal bounds checks in Release.
# Those checks are valuable while developing (Debug builds keep them) but make
# matrix code several times slower.
set(CMAKE_CXX_FLAGS_RELEASE "-O2 -DNDEBUG")

# --- Options ------------------------------------------------------------------
set(_nc_repo_root "${CMAKE_CURRENT_SOURCE_DIR}/../../..")
get_filename_component(_nc_repo_root "${_nc_repo_root}" ABSOLUTE)

set(NC_EIGEN_DIR "${_nc_repo_root}/build/third_party/eigen"
    CACHE PATH "Folder that contains Eigen/ (vendored Eigen 5.0.1)")

# OpenMP: on wherever the compiler can have it. Windows (LLVM toolchain):
# always, libomp.dll ships beside nc.exe. Linux: GCC and Clang both support
# it. macOS: Apple's clang needs Homebrew's libomp (brew install libomp);
# without it nc still builds, on the std::thread pool (NC_PAR_BACKEND).
if(WIN32 AND NC_TOOLCHAIN_ROOT)
    set(_nc_openmp_default ON)
elseif(APPLE)
    execute_process(COMMAND brew --prefix libomp
                    OUTPUT_VARIABLE _nc_brew_libomp OUTPUT_STRIP_TRAILING_WHITESPACE
                    ERROR_QUIET RESULT_VARIABLE _nc_brew_result)
    if(_nc_brew_result EQUAL 0 AND EXISTS "${_nc_brew_libomp}/include/omp.h")
        set(_nc_openmp_default ON)
    else()
        set(_nc_openmp_default OFF)
    endif()
elseif(WIN32)
    set(_nc_openmp_default OFF) # another Windows compiler: opt in explicitly
else()
    set(_nc_openmp_default ON)
endif()
option(NC_OPENMP "Enable OpenMP multithreading" ${_nc_openmp_default})

# nc::par backend (runtime/execution/parallel/par.cpp):
#   AUTO     OPENMP when NC_OPENMP is on and OpenMP was found, else STDPOOL
#   OPENMP   OpenMP threads, shared with Eigen
#   STDPOOL  a std::thread pool - any OS with a C++20 compiler
#   SERIAL   no threads at all
set(NC_PAR_BACKEND "AUTO" CACHE STRING "nc::par backend: AUTO, OPENMP, STDPOOL or SERIAL")
set_property(CACHE NC_PAR_BACKEND PROPERTY STRINGS AUTO OPENMP STDPOOL SERIAL)

set(NC_CPU_BASELINE "x86-64-v2" CACHE STRING "-march value for x86-64 builds (empty = compiler default)")
option(NC_LTO "Enable ThinLTO (release builds)" OFF)

if(CMAKE_BUILD_TYPE STREQUAL "Release")
    set(_nc_static_crt_default ON)
else()
    set(_nc_static_crt_default OFF)
endif()
option(NC_STATIC_CRT "Link the C/C++ runtime statically (Windows)" ${_nc_static_crt_default})
option(NC_PDB "Generate debug symbols (nc.pdb) in Release builds" ON)
set(NC_SANITIZE "" CACHE STRING "Sanitizers: empty, address, undefined or address;undefined")
option(NC_EIGEN_MPL2_ONLY "Refuse Eigen modules that are not MPL2-licensed" ON)

# ASan on Windows needs the release C runtime; a Debug build uses the debug
# runtime (_DEBUG), which cannot be combined with it.
if(NC_SANITIZE MATCHES "address" AND CMAKE_BUILD_TYPE STREQUAL "Debug")
    message(FATAL_ERROR "NC_SANITIZE=address needs -DCMAKE_BUILD_TYPE=Release (debug symbols are added automatically).")
endif()

# Kept for any sub-CMakeLists or old FindEigen3 code that reads it.
# (Eigen 5 still uses the "Eigen3" names for its CMake package and variables.)
set(EIGEN3_INCLUDE_DIR "${NC_EIGEN_DIR}" CACHE PATH "Eigen header directory" FORCE)

# --- Sources ------------------------------------------------------------------
add_subdirectory(compiler)
add_subdirectory(runtime)

add_executable(nc ${COMPILER_SOURCES} ${RUNTIME_SOURCES})
target_include_directories(nc PRIVATE
    ${COMPILER_INCLUDE_DIRS}
    ${RUNTIME_INCLUDE_DIRS}
)
# NC_OUTPUT_DIR (2026-11-20): where nc.exe goes. Default: this folder, where
# the IDE looks. A sanitizer or experiment build sets its own folder so it
# never replaces the nc.exe the IDE runs.
set(NC_OUTPUT_DIR "${CMAKE_CURRENT_SOURCE_DIR}" CACHE PATH "Folder nc.exe is written to")
set_target_properties(nc PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY ${NC_OUTPUT_DIR}
)

# --- Eigen 5.0.1 (header-only, used by the matrix ops) ------------------------
# The vendored copy is preferred so every machine builds with the same version.
# A system install is used only if the vendored copy is missing (macOS/Linux).
set(_nc_eigen_mode "")
if(EXISTS "${NC_EIGEN_DIR}/Eigen/Dense")
    set(_nc_eigen_mode vendored)
else()
    find_package(Eigen3 QUIET NO_MODULE)
    if(Eigen3_FOUND)
        set(_nc_eigen_mode system)
    else()
        message(FATAL_ERROR
            "Eigen not found.\n"
            "Expected the vendored copy at: ${NC_EIGEN_DIR}/Eigen/Dense\n"
            "Windows: place Eigen 5.0.1 in build/third_party/eigen (the folder that contains Eigen/),\n"
            "or pass -DNC_EIGEN_DIR=<folder>. macOS: brew install eigen. Linux: apt install libeigen3-dev.")
    endif()
endif()

# --- Threads, OpenMP and the nc::par backend ----------------------------------
set(THREADS_PREFER_PTHREAD_FLAG ON)
find_package(Threads REQUIRED)

set(_nc_openmp_found OFF)
if(NC_OPENMP)
    if(WIN32 AND NC_TOOLCHAIN_ROOT)
        if(NOT EXISTS "${NC_TOOLCHAIN_ROOT}/lib/libomp.lib")
            message(FATAL_ERROR "NC_OPENMP is on but ${NC_TOOLCHAIN_ROOT}/lib/libomp.lib is missing.")
        endif()
        set(_nc_openmp_found ON)
    else()
        if(APPLE AND _nc_brew_libomp)
            # Apple's clang has no -fopenmp of its own; point FindOpenMP at
            # Homebrew's libomp.
            set(OpenMP_CXX_FLAGS "-Xpreprocessor -fopenmp -I${_nc_brew_libomp}/include")
            set(OpenMP_CXX_LIB_NAMES "omp")
            set(OpenMP_omp_LIBRARY "${_nc_brew_libomp}/lib/libomp.dylib")
        endif()
        find_package(OpenMP COMPONENTS CXX)
        if(OpenMP_CXX_FOUND)
            set(_nc_openmp_found ON)
        else()
            message(WARNING "NC_OPENMP is on but OpenMP was not found - nc::par uses its std::thread pool instead.")
        endif()
    endif()
endif()

string(TOUPPER "${NC_PAR_BACKEND}" _nc_par_backend)
if(_nc_par_backend STREQUAL "AUTO")
    if(_nc_openmp_found)
        set(_nc_par_backend OPENMP)
    else()
        set(_nc_par_backend STDPOOL)
    endif()
elseif(_nc_par_backend STREQUAL "OPENMP" AND NOT _nc_openmp_found)
    message(FATAL_ERROR "NC_PAR_BACKEND=OPENMP needs OpenMP (NC_OPENMP=ON and a compiler/libomp that has it).")
elseif(NOT _nc_par_backend MATCHES "^(OPENMP|STDPOOL|SERIAL)$")
    message(FATAL_ERROR "NC_PAR_BACKEND must be AUTO, OPENMP, STDPOOL or SERIAL (got ${NC_PAR_BACKEND}).")
endif()
# OpenMP and a second thread pool are never combined in one process: each
# would see every core free and they would fight over them. With STDPOOL or
# SERIAL, Eigen runs single-threaded.

# --- Common settings applied to every NC executable ---------------------------
function(nc_configure_target tgt)
    target_compile_options(${tgt} PRIVATE -Wall -Wextra -Wno-unused-parameter)
    # C++20 made u8"..." and path::u8string() char8_t-based; the code base
    # treats UTF-8 as plain std::string throughout, so keep the C++17 meaning.
    target_compile_options(${tgt} PRIVATE -fno-char8_t)

    # Eigen: SYSTEM keeps Eigen's own warnings out of the -Wall output.
    if(_nc_eigen_mode STREQUAL "vendored")
        target_include_directories(${tgt} SYSTEM PRIVATE "${NC_EIGEN_DIR}")
    else()
        target_link_libraries(${tgt} PRIVATE Eigen3::Eigen)
    endif()
    # Safeguard: refuse to compile any Eigen part that is not MPL2-licensed.
    # Eigen 5 has removed all its LGPL code, so this should never trigger; it
    # protects the release if an older or modified Eigen is ever dropped in.
    if(NC_EIGEN_MPL2_ONLY)
        target_compile_definitions(${tgt} PRIVATE EIGEN_MPL2_ONLY)
    endif()

    # CPU baseline (x86-64 only).
    if(NC_CPU_BASELINE AND CMAKE_SYSTEM_PROCESSOR MATCHES "AMD64|x86_64|amd64")
        target_compile_options(${tgt} PRIVATE "-march=${NC_CPU_BASELINE}")
    endif()

    # Threads: nc::par's std::thread pool and the IDE's CPU monitor thread.
    target_link_libraries(${tgt} PRIVATE Threads::Threads)

    # OpenMP. Eigen also uses it to spread large matrix products over all
    # cores, and nc::par shares the same threads.
    if(_nc_par_backend STREQUAL "OPENMP")
        if(WIN32 AND NC_TOOLCHAIN_ROOT)
            # Link the TOOLCHAIN's libomp.lib by its full path. Left to the
            # library search, Visual Studio's lib\x64\libomp.lib could win in
            # some shells, and nc.exe then imported libomp140.x86_64.dll from
            # System32 instead of the libomp.dll shipped beside it.
            target_compile_options(${tgt} PRIVATE -fopenmp)
            target_link_libraries(${tgt} PRIVATE "${NC_TOOLCHAIN_ROOT}/lib/libomp.lib")
            target_link_options(${tgt} PRIVATE "LINKER:/nodefaultlib:libomp140.x86_64.lib"
                                               "LINKER:/nodefaultlib:vcomp.lib")
        else()
            target_link_libraries(${tgt} PRIVATE OpenMP::OpenMP_CXX)
        endif()
        target_compile_definitions(${tgt} PRIVATE NC_PAR_BACKEND_OPENMP=1)
    elseif(_nc_par_backend STREQUAL "STDPOOL")
        target_compile_definitions(${tgt} PRIVATE NC_PAR_BACKEND_STDPOOL=1)
    else()
        target_compile_definitions(${tgt} PRIVATE NC_PAR_BACKEND_SERIAL=1)
    endif()

    # A 256 MB main-thread stack, so deep recursion in an NC script goes far
    # before the stack guard (runtime/execution/stack_guard.h) reports it.
    # Only reserved address space: the pages are committed as they are used.
    # Linux takes the main thread's stack size from `ulimit -s` instead; the
    # guard reads whatever limit is in force.
    if(WIN32)
        target_link_options(${tgt} PRIVATE "LINKER:/STACK:268435456")
    elseif(APPLE)
        target_link_options(${tgt} PRIVATE "LINKER:-stack_size,0x10000000")
    endif()

    # ThinLTO.
    if(NC_LTO)
        target_compile_options(${tgt} PRIVATE -flto=thin)
        target_link_options(${tgt} PRIVATE -flto=thin)
    endif()

    # Debug symbols for Release builds (CodeView -> nc.pdb).
    if(NC_PDB AND CMAKE_BUILD_TYPE STREQUAL "Release" AND WIN32)
        target_compile_options(${tgt} PRIVATE -g -gcodeview)
        target_link_options(${tgt} PRIVATE -g)
    endif()

    # Sanitizers (development only).
    if(NC_SANITIZE)
        string(REPLACE ";" "," _nc_san "${NC_SANITIZE}")
        target_compile_options(${tgt} PRIVATE "-fsanitize=${_nc_san}" -fno-omit-frame-pointer -g)
        target_link_options(${tgt} PRIVATE "-fsanitize=${_nc_san}" -g)
    endif()

    # Windows C runtime selection. ASan requires the release DLL runtime.
    if(WIN32 AND NOT MINGW)
        if(NC_SANITIZE MATCHES "address")
            set_property(TARGET ${tgt} PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreadedDLL")
            # Tell the clang driver too, so it links the matching ASan thunk.
            target_compile_options(${tgt} PRIVATE -fms-runtime-lib=dll)
            target_link_options(${tgt} PRIVATE -fms-runtime-lib=dll)
        elseif(NC_STATIC_CRT)
            set_property(TARGET ${tgt} PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
        else()
            set_property(TARGET ${tgt} PROPERTY MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")
        endif()
    endif()

    # MinGW: static-link the C++/pthread runtime so nc.exe doesn't need
    # libgcc_s_seh-1.dll / libstdc++-6.dll / libwinpthread-1.dll next to it.
    # macOS: nothing extra needed - the system libc++ ships with every Mac.
    if(MINGW)
        target_link_options(${tgt} PRIVATE -static -static-libgcc -static-libstdc++)
    endif()

    # Copy the runtime DLLs this executable needs next to it.
    if(WIN32 AND NC_TOOLCHAIN_ROOT)
        set(_dlls "")
        if(_nc_par_backend STREQUAL "OPENMP")
            list(APPEND _dlls "${NC_TOOLCHAIN_ROOT}/bin/libomp.dll")
        endif()
        if(NC_SANITIZE MATCHES "address")
            # The clang resource folder is named after the major version
            # (lib/clang/23). NC_LLVM_MAJOR was never set before 2026-11-20,
            # so an ASan build could not configure.
            if(NOT NC_LLVM_MAJOR)
                string(REGEX MATCH "^[0-9]+" NC_LLVM_MAJOR "${CMAKE_CXX_COMPILER_VERSION}")
            endif()
            if(NOT EXISTS "${NC_TOOLCHAIN_ROOT}/lib/clang/${NC_LLVM_MAJOR}")
                file(GLOB _nc_clang_dirs LIST_DIRECTORIES true "${NC_TOOLCHAIN_ROOT}/lib/clang/*")
                list(GET _nc_clang_dirs 0 _nc_clang_dir)
                get_filename_component(NC_LLVM_MAJOR "${_nc_clang_dir}" NAME)
            endif()
            list(APPEND _dlls "${NC_TOOLCHAIN_ROOT}/lib/clang/${NC_LLVM_MAJOR}/lib/windows/clang_rt.asan_dynamic-x86_64.dll")
        endif()
        foreach(_dll IN LISTS _dlls)
            if(NOT EXISTS "${_dll}")
                message(FATAL_ERROR "Required runtime file missing from the toolchain: ${_dll}")
            endif()
            add_custom_command(TARGET ${tgt} POST_BUILD
                COMMAND ${CMAKE_COMMAND} -E copy_if_different "${_dll}" "$<TARGET_FILE_DIR:${tgt}>"
                VERBATIM)
        endforeach()

        # Post-build check of the DLLs nc.exe imports: with OpenMP it must
        # be the toolchain's libomp.dll, never Visual Studio's
        # libomp140.x86_64.dll or vcomp. Fails the build otherwise.
        if(EXISTS "${NC_TOOLCHAIN_ROOT}/bin/llvm-readobj.exe")
            add_custom_command(TARGET ${tgt} POST_BUILD
                COMMAND ${CMAKE_COMMAND}
                    "-DREADOBJ=${NC_TOOLCHAIN_ROOT}/bin/llvm-readobj.exe"
                    "-DEXE=$<TARGET_FILE:${tgt}>"
                    "-DBACKEND=${_nc_par_backend}"
                    -P "${CMAKE_CURRENT_SOURCE_DIR}/check_nc_imports.cmake"
                VERBATIM)
        endif()
    endif()
endfunction()

nc_configure_target(nc)

# Time-zone engine tests: stand-alone, the first thing to run on a new OS.
# Not part of the default build: cmake --build <dir> --target nc_time_tests
add_executable(nc_time_tests EXCLUDE_FROM_ALL
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler/tests/time_zone_tests.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/interpreter/ops/time/time_zone.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/interpreter/ops/time/time_zone_data.cpp
)
nc_configure_target(nc_time_tests)

# nc::par tests (multicore library, OS layer, IDE monitor): stand-alone, run
# them on every new OS and for every backend before trusting nc there.
# Not part of the default build: cmake --build <dir> --target nc_par_tests
add_executable(nc_par_tests EXCLUDE_FROM_ALL
    ${CMAKE_CURRENT_SOURCE_DIR}/compiler/tests/par_tests.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution/Interrupt.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution/parallel/par.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution/parallel/par_monitor.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution/parallel/sys_cpu.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution/analysis/analysis.cpp
)
target_include_directories(nc_par_tests PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution
    ${CMAKE_CURRENT_SOURCE_DIR}/runtime/execution/parallel
)
nc_configure_target(nc_par_tests)

# --- LLVM (optional, for now) -------------------------------------------------
# Step 1 of the codegen/JIT/AOT roadmap: make LLVM linkable so future codegen
# work has something to build against. Soft dependency deliberately - no source
# file calls any LLVM API yet, so a missing LLVM must not break the build.
#
# macOS: Homebrew's LLVM is keg-only - query `brew --prefix llvm` and add it
# to CMAKE_PREFIX_PATH before searching.
#
# Windows: needs a real LLVM development package with LLVMConfig.cmake
# (self-built, or the clang+llvm-*-windows-msvc archive if it contains one) -
# pass -DLLVM_DIR=<prefix>/lib/cmake/llvm. The trimmed build/toolchain is NOT
# sufficient: it has no LLVM headers, static libraries or CMake package.
if(APPLE)
    execute_process(
        COMMAND brew --prefix llvm
        OUTPUT_VARIABLE HOMEBREW_LLVM_PREFIX
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )
    if(HOMEBREW_LLVM_PREFIX)
        list(APPEND CMAKE_PREFIX_PATH ${HOMEBREW_LLVM_PREFIX})
    endif()
endif()

find_package(LLVM CONFIG QUIET)
if(LLVM_FOUND)
    message(STATUS "Found LLVM ${LLVM_PACKAGE_VERSION} at ${LLVM_DIR} - building the codegen/JIT visitor against it.")
    # core: IR building. orcjit: the JIT engine (LLJIT). native: the host's
    # codegen backend + asm printer, required for orcjit to produce runnable code.
    llvm_map_components_to_libnames(LLVM_LIBS core orcjit native)
    target_include_directories(nc PRIVATE ${LLVM_INCLUDE_DIRS})
    target_compile_definitions(nc PRIVATE ${LLVM_DEFINITIONS})
    target_compile_definitions(nc PRIVATE NC_HAS_JIT=1)
    target_link_libraries(nc PRIVATE ${LLVM_LIBS})

    # Step 3: the AST -> LLVM IR CodeGen visitor (compiler_src/codegen/).
    # Step 4: JitEngine, the persistent reusable JIT session built on top of it.
    target_sources(nc PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}/compiler/compiler_src/codegen/codegen.cpp
        ${CMAKE_CURRENT_SOURCE_DIR}/compiler/compiler_src/codegen/jit_engine.cpp
    )

    # Step 5: permanent tree-walker-vs-JitEngine parity harness (see
    # compiler/tests/parity_harness.cpp's header comment). Own executable since
    # it needs its own main(); shares every other NC source with `nc`.
    set(NC_TEST_SOURCES ${COMPILER_SOURCES} ${RUNTIME_SOURCES})
    list(REMOVE_ITEM NC_TEST_SOURCES ${CMAKE_CURRENT_SOURCE_DIR}/compiler/compiler_src/main.cpp)
    add_executable(nc_parity_tests
        ${NC_TEST_SOURCES}
        ${CMAKE_CURRENT_SOURCE_DIR}/compiler/compiler_src/codegen/codegen.cpp
        ${CMAKE_CURRENT_SOURCE_DIR}/compiler/compiler_src/codegen/jit_engine.cpp
        ${CMAKE_CURRENT_SOURCE_DIR}/compiler/tests/parity_harness.cpp
    )
    target_include_directories(nc_parity_tests PRIVATE
        ${COMPILER_INCLUDE_DIRS}
        ${RUNTIME_INCLUDE_DIRS}
        ${LLVM_INCLUDE_DIRS}
    )
    target_compile_definitions(nc_parity_tests PRIVATE ${LLVM_DEFINITIONS})
    # Needed for real parity coverage of anything gated on NC_HAS_JIT outside
    # codegen/ itself (e.g. ScriptManager::executeFile()'s JIT-aware Pass 2,
    # SM_stage_02.cpp).
    target_compile_definitions(nc_parity_tests PRIVATE NC_HAS_JIT=1)
    target_link_libraries(nc_parity_tests PRIVATE ${LLVM_LIBS})
    nc_configure_target(nc_parity_tests)
else()
    message(STATUS "LLVM development package not found - fine for now, nothing uses it yet. Needed before codegen/JIT/AOT work starts.")
endif()

# --- Configuration summary ----------------------------------------------------
message(STATUS "nc build type      : ${CMAKE_BUILD_TYPE}")
message(STATUS "nc Eigen           : ${_nc_eigen_mode} (${NC_EIGEN_DIR})")
message(STATUS "nc OpenMP          : ${NC_OPENMP} (found: ${_nc_openmp_found})")
message(STATUS "nc par backend     : ${_nc_par_backend}")
message(STATUS "nc CPU baseline    : ${NC_CPU_BASELINE}")
message(STATUS "nc ThinLTO         : ${NC_LTO}")
message(STATUS "nc static CRT      : ${NC_STATIC_CRT}")
message(STATUS "nc sanitizers      : ${NC_SANITIZE}")
message(STATUS "nc Eigen MPL2 only : ${NC_EIGEN_MPL2_ONLY}")
