# Post-build check (Windows): which DLLs does nc.exe import?
# Run by CMakeLists.txt as:  cmake -DREADOBJ=... -DEXE=... -DBACKEND=... -P check_nc_imports.cmake
#
# With the OpenMP backend nc.exe must import the toolchain's libomp.dll (shipped
# beside it), never Visual Studio's libomp140.x86_64.dll or vcomp*.dll, which a
# user's PC may not have. See docs/Multicore_Multithread_Architecture.md, Phase 0.

execute_process(COMMAND "${READOBJ}" --coff-imports "${EXE}"
                OUTPUT_VARIABLE _out RESULT_VARIABLE _rc ERROR_QUIET)
if(NOT _rc EQUAL 0)
    message(WARNING "check_nc_imports: llvm-readobj failed on ${EXE}; imports not checked.")
    return()
endif()

string(REGEX MATCHALL "Name: [^\r\n]+\\.(dll|DLL)" _names "${_out}")
list(REMOVE_DUPLICATES _names)
string(REPLACE "Name: " "" _names "${_names}")
string(TOLOWER "${_names}" _lower)

if(_lower MATCHES "libomp140|vcomp")
    message(FATAL_ERROR "nc.exe imports the Visual Studio OpenMP runtime (${_names}); it must import libomp.dll.")
endif()
if(BACKEND STREQUAL "OPENMP" AND NOT _lower MATCHES "libomp\\.dll")
    message(FATAL_ERROR "nc.exe was built with the OpenMP backend but does not import libomp.dll (${_names}).")
endif()
# Success is silent: the list is printed only when a check fails above. (A
# Debug build also imports the debug C++ runtime - MSVCP140D, VCRUNTIME140D,
# ucrtbased - which is normal for Debug; Release links it statically.)
# To see the list anyway: cmake -DREADOBJ=... -DEXE=... -DBACKEND=... -DVERBOSE=ON -P check_nc_imports.cmake
if(VERBOSE)
    message(STATUS "nc.exe imports: ${_names}")
endif()
