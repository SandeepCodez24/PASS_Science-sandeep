from gen_tests import T

NC_SETUP = '''sig = sin(space(0,9,10)) + 0.5 * cos(3 * space(0,9,10));
sig8 = [1,5,2,8,3,1,4,9];
img = [1,2,3,4;5,6,7,8;9,10,11,13];
x16 = sin(space(0,15,16) * 2 * pi / 16);
'''

def PY():
    import numpy as np
    t = np.arange(10.)
    from scipy.fftpack import convolve
    return dict(sig=np.sin(t) + 0.5*np.cos(3*t), sig8=np.array([1,5,2,8,3,1,4,9.]),
                img=np.array([[1,2,3,4],[5,6,7,8],[9,10,11,13.]]), x16=np.sin(np.arange(16)*2*np.pi/16),
                om=convolve.init_convolution_kernel(16, lambda k: 1/(1+k*k), d=0, zero_nyquist=0))

ROWS = [
    T('fft(sig)', 'fft.fft(sig)'), T('ifft(sig)', 'fft.ifft(sig)'),
    T('fft(sig, 12)', 'fft.fft(sig, 12)', label='fft_n'), T('fft(sig, 0, "ortho")', 'fft.fft(sig, norm="ortho")', label='fft_ortho'),
    T('ifft(sig, 0, "forward")', 'fft.ifft(sig, norm="forward")', label='ifft_forward'),
    T('fft2(img)', 'fft.fft2(img)'), T('ifft2(img)', 'fft.ifft2(img)'),
    T('fftn(img)', 'fft.fftn(img)'), T('ifftn(img)', 'fft.ifftn(img)'), T('fftn(sig)', 'fft.fftn(sig)', label='fftn_1d'),
    T('rfft(sig)', 'fft.rfft(sig)'), T('irfft(rfft(sig))', 'sig', label='irfft'),
    T('irfft([1,2,3], 5)', 'fft.irfft([1,2,3], 5)', label='irfft_n'),
    T('rfft2(img)', 'fft.rfft2(img)'), T('irfft2(rfft2(img))', 'fft.irfft2(fft.rfft2(img))'),
    T('irfft2(rfft2(img), [3,4])', 'img', label='irfft2_shape'),
    T('rfftn(img)', 'fft.rfftn(img)'), T('irfftn(rfftn(img))', 'fft.irfftn(fft.rfftn(img))'),
    T('hfft([1,2,3])', 'fft.hfft([1,2,3])'), T('ihfft([1.0,2.0,3.0,4.0])', 'fft.ihfft([1,2,3,4.])'),
    T('hfft2(img)', 'fft.hfft2(img)'), T('ihfft2(img)', 'fft.ihfft2(img)'),
    T('hfftn(img)', 'fft.hfftn(img)'), T('ihfftn(img)', 'fft.ihfftn(img)'),
    *[T('dct(sig, %d)' % t, 'fft.dct(sig, %d)' % t, label='dct%d' % t) for t in (1, 2, 3, 4)],
    *[T('dct(sig, %d, "ortho")' % t, 'fft.dct(sig, %d, norm="ortho")' % t, label='dct%d_ortho' % t) for t in (1, 2, 3, 4)],
    *[T('idct(sig, %d)' % t, 'fft.idct(sig, %d)' % t, label='idct%d' % t) for t in (1, 2, 3, 4)],
    *[T('idct(sig, %d, "ortho")' % t, 'fft.idct(sig, %d, norm="ortho")' % t, label='idct%d_ortho' % t) for t in (1, 2, 3, 4)],
    T('dctn(img)', 'fft.dctn(img)'), T('idctn(img)', 'fft.idctn(img)'),
    *[T('dst(sig, %d)' % t, 'fft.dst(sig, %d)' % t, label='dst%d' % t) for t in (1, 2, 3, 4)],
    *[T('dst(sig, %d, "ortho")' % t, 'fft.dst(sig, %d, norm="ortho")' % t, label='dst%d_ortho' % t) for t in (1, 2, 3, 4)],
    *[T('idst(sig, %d)' % t, 'fft.idst(sig, %d)' % t, label='idst%d' % t) for t in (1, 2, 3, 4)],
    *[T('idst(sig, %d, "ortho")' % t, 'fft.idst(sig, %d, norm="ortho")' % t, label='idst%d_ortho' % t) for t in (1, 2, 3, 4)],
    T('dstn(img)', 'fft.dstn(img)'), T('idstn(img)', 'fft.idstn(img)'),
    T('fht(exp(-1 * (space(-2,2,16) ^ 2)), 0.25, 0.0)', 'fft.fht(np.exp(-np.linspace(-2,2,16)**2), 0.25, 0.0)', tol=1e-6),
    T('ifht(ones(1,16), 0.25, 0.0)', 'fft.ifht(np.ones(16), 0.25, 0.0)', tol=1e-6),
    T('fht_offset(0.25, 0.0)', 'fft.fhtoffset(0.25, 0.0)', tol=1e-6),
    T('fftfreq(8, 0.1)', 'fft.fftfreq(8, 0.1)'), T('rfftfreq(8, 0.1)', 'fft.rfftfreq(8, 0.1)'),
    T('fftshift(fftfreq(8, 1))', 'fft.fftshift(fft.fftfreq(8, 1))'), T('ifftshift(fftshift(fftfreq(9, 1)))', 'fft.fftfreq(9, 1)'),
    T('fftshift(img)', 'fft.fftshift(img)', label='fftshift_2d'), T('ifftshift(img)', 'fft.ifftshift(img)', label='ifftshift_2d'),
    T('next_fast_len(1021)', '1024'), T('prev_fast_len(1021)', '1000'),
    T('get_fft_workers()', '1'), T('set_fft_workers(2)', None),
    # legacy FFT
    T('rfft_packed(sig)', 'fftpack.rfft(sig)'), T('irfft_packed(rfft_packed(sig))', 'sig', label='irfft_packed'),
    T('rfft_packed(sig8)', 'fftpack.rfft(sig8)', label='rfft_packed_even'),
    T('fft_diff(x16)', 'fftpack.diff(x16)'), T('fft_diff(x16, 2)', 'fftpack.diff(x16, 2)', label='fft_diff2'),
    T('fft_diff(x16, 1, 4)', 'fftpack.diff(x16, 1, 4)', label='fft_diff_period'),
    T('tilbert(x16, 1.0)', 'fftpack.tilbert(x16, 1.0)'), T('itilbert(x16, 1.0)', 'fftpack.itilbert(x16, 1.0)'),
    T('fft_hilbert(x16)', 'fftpack.hilbert(x16)'), T('fft_ihilbert(x16)', 'fftpack.ihilbert(x16)'),
    T('cs_diff(x16, 1.0, 2.0)', 'fftpack.cs_diff(x16, 1.0, 2.0)'), T('sc_diff(x16, 1.0, 2.0)', 'fftpack.sc_diff(x16, 1.0, 2.0)'),
    T('ss_diff(x16, 1.0, 2.0)', 'fftpack.ss_diff(x16, 1.0, 2.0)'), T('cc_diff(x16, 1.0, 2.0)', 'fftpack.cc_diff(x16, 1.0, 2.0)'),
    T('fft_shift_signal(x16, 0.5)', 'fftpack.shift(x16, 0.5)'),
    T('rfftfreq_packed(8, 0.1)', 'fftpack.rfftfreq(8, 0.1)'),
    T('fft_conv_kernel(16, "lorentz")', 'fftpack.convolve.init_convolution_kernel(16, lambda k: 1/(1+k*k), d=0)/1', setup='function y = lorentz(k):\n  y = 1 / (1 + k * k);\nfnend', tol=1e-9) if False else T('fft_conv_kernel(16, "lorentz")', None, setup='function y = lorentz(k):\n  y = 1 / (1 + k * k);\nfnend'),
    T('fft_convolve(x16, fft_conv_kernel(16, "lorentz"))', 'fftpack.convolve.convolve(x16, fftpack.convolve.init_convolution_kernel(16, lambda k: 1/(1+k*k), d=0, zero_nyquist=0))', setup='function y = lorentz(k):\n  y = 1 / (1 + k * k);\nfnend', tol=1e-6),
    T('fft_convolve_z(x16, om, om)', 'fftpack.convolve.convolve_z(x16, om, om)', setup='function y = lorentz(k):\n  y = 1 / (1 + k * k);\nfnend\nom = fft_conv_kernel(16, "lorentz");', tol=1e-6),
    # signal.fftconvolve shares the name
    T('fft_convolve([1,2,3], [0,1,0.5], "full")', 'signal.fftconvolve([1,2,3.],[0,1,0.5])', label='fft_convolve_signal'),
    T('fft_convolve(sig, [1,1,1], "same")', 'signal.fftconvolve(sig,[1,1,1.],"same")', label='fft_convolve_same'),
    T('fft_convolve(sig, [1,1,1], "valid")', 'signal.fftconvolve(sig,[1,1,1.],"valid")', label='fft_convolve_valid'),
    T('fft_convolve(img, [1,1;1,1], "same")', 'signal.fftconvolve(img,np.ones((2,2)),"same")', label='fft_convolve_2d'),
]
