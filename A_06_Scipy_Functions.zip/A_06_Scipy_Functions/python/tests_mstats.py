"""Section 23 (scipy.stats.mstats) against SciPy. In NC a NaN element is a
masked one: 'mdata' holds two NaN, compared with numpy.ma.masked_invalid."""
import numpy as np
from gen_tests import T

_rng = np.random.default_rng(11)
DATA = np.round(_rng.normal(1.0, 2.0, 25), 3)
DATA2 = np.round(_rng.normal(0.0, 1.0, 18), 3)
MDATA = DATA.copy()
MDATA[[3, 17]] = np.nan
SEAS = np.round(_rng.normal(0, 1, (10, 3)) + np.arange(10)[:, None] * 0.3, 3)


def _arr(v):
    return '[' + ', '.join('(0/0)' if np.isnan(x) else repr(float(x)) for x in v) + ']'


def _mat(m):
    return '[' + '; '.join(', '.join(repr(float(x)) for x in r) for r in m) + ']'


def PY():
    import warnings
    warnings.simplefilter('ignore')
    from scipy.stats import mstats
    ma = np.ma
    return dict(mstats=mstats, ma=ma, data=DATA, data2=DATA2, mdata=ma.masked_invalid(MDATA), seas=SEAS,
                filled=lambda v: np.ma.filled(np.ma.asarray(v, dtype=float), np.nan))


NC_SETUP = '''data = %s;
data2 = %s;
mdata = %s;
seas = %s;
''' % (_arr(DATA), _arr(DATA2), _arr(MDATA), _mat(SEAS))

ROWS = [
    T('pad_to_matrix([1,2,3], [4,5])', 'filled(mstats.argstoarray([1,2,3], [4,5]))'),
    T('count_tied_groups([1,1,2,2,2,3])', '1', field='2'),
    T('count_tied_groups([1,1,2,2,2,3,4,4])', '2', field='2'),
    T('find_repeats([1,1,2,3,3,3])', 'mstats.find_repeats([1,1,2,3,3,3])[0]', field='values'),
    T('find_repeats([1,1,2,3,3,3])', 'mstats.find_repeats([1,1,2,3,3,3])[1]', field='counts'),
    T('trim_mask(space(0, 9, 10), [2, 8])', 'filled(mstats.trima(np.arange(10.), (2, 8)))'),
    T('trim_mask(space(0, 9, 10), [0.1, 0.1], 1)', 'filled(mstats.trimr(np.arange(10.), (0.1, 0.1)))'),
    T('trim_mask(data, [0.1, 0.2], 1)', 'filled(mstats.trim(data, (0.1, 0.2), relative=True))'),
    T('trim_mask(data, [0.1, 0.2], 1, [0, 0])', 'filled(mstats.trim(data, (0.1, 0.2), inclusive=(False, False), relative=True))'),
    T('trim_mask(data, [-1, 2])', 'filled(mstats.trim(data, (-1, 2)))'),
    T('trim_mask_tail(space(0, 9, 10), 0.1, "left")', 'filled(mstats.trimtail(np.arange(10.), 0.1, "left"))'),
    T('trim_mask_tail(data, 0.2, "right")', 'filled(mstats.trimtail(data, 0.2, "right"))'),
    T('nan_trim_var(mdata, [0.1, 0.1])', 'mstats.trimmed_var(mdata, (0.1, 0.1))'),
    T('nan_trim_sd(data, [0.1, 0.2])', 'mstats.trimmed_std(data, (0.1, 0.2))'),
    T('nan_trim_sd(data, [0.1, 0.2], 1)', 'mstats.trimmed_std(data, (0.1, 0.2), ddof=1)'),
    T('nan_trim_sem(data, [0.1, 0.1])', 'mstats.trimmed_stde(data, (0.1, 0.1))'),
    T('trim_mean_ci(data, [0.1, 0.1])', 'mstats.trimmed_mean_ci(data, (0.1, 0.1))'),
    T('trim_mean_ci(data)', 'mstats.trimmed_mean_ci(data)'),
    T('winsorize(space(0, 9, 10), [0.1, 0.1])', 'filled(mstats.winsorize(np.arange(10.), (0.1, 0.1)))'),
    T('winsorize(data, [0.2, 0.1])', 'filled(mstats.winsorize(data, (0.2, 0.1)))'),
    T('mquantiles(mdata, [0.25, 0.5, 0.75])', 'mstats.mquantiles(mdata, [0.25, 0.5, 0.75])'),
    T('mquantiles(data, [0.1, 0.9], 0, 1)', 'mstats.mquantiles(data, [0.1, 0.9], 0, 1)'),
    T('mquantiles_ci(data, [0.25, 0.5])', 'mstats.mquantiles_cimj(data, [0.25, 0.5])[0]', field='low'),
    T('mquantiles_ci(data, [0.25, 0.5])', 'mstats.mquantiles_cimj(data, [0.25, 0.5])[1]', field='high'),
    T('hd_quantiles(mdata, [0.25, 0.5])', 'mstats.hdquantiles(mdata, [0.25, 0.5])'),
    T('hd_quantiles_sd(data, [0.25, 0.5])', 'mstats.hdquantiles_sd(data, [0.25, 0.5])'),
    T('hd_median(data)', 'mstats.hdmedian(data)'),
    T('ideal_fourths(mdata)', 'mstats.idealfourths(mdata)'),
    T('median_ci(data)', 'mstats.median_cihs(data)[0]', field='low'),
    T('median_ci(data, 0.1)', 'mstats.median_cihs(data, 0.1)[1]', field='high'),
    T('mj_ci(data, [0.25, 0.5])', 'mstats.mjci(data, [0.25, 0.5])'),
    T('rsh(data)', 'mstats.rsh(data)'),
    T('rsh(data, [0, 1, 2])', 'mstats.rsh(data, [0, 1, 2])'),
    T('plotting_positions(mdata)', 'filled(mstats.plotting_positions(mdata))'),
    T('plotting_positions(data, 0.5, 0.5)', 'filled(mstats.meppf(data, 0.5, 0.5))'),
    T('compare_medians(data, data2)', 'mstats.compare_medians_ms(data, data2)'),
    T('kendalltau_seasonal(seas)', 'mstats.kendalltau_seasonal(seas)["seasonal tau"]', field='seasonal_tau'),
    T('kendalltau_seasonal(seas)', 'mstats.kendalltau_seasonal(seas)["global tau"]', field='global_tau'),
    T('kendalltau_seasonal(seas)', 'mstats.kendalltau_seasonal(seas)["seasonal p-value"]', field='seasonal_pvalue'),
    T('kendalltau_seasonal(seas)', 'mstats.kendalltau_seasonal(seas)["global p-value (dep)"]', field='global_pvalue_dep'),
    T('kendalltau_seasonal(seas)', 'mstats.kendalltau_seasonal(seas)["chi2 trend"]', field='chi2_trend'),
    T('sen_seasonal_slopes(seas)', 'mstats.sen_seasonal_slopes(seas)[0]', field='intra_slope'),
    T('sen_seasonal_slopes(seas)', 'mstats.sen_seasonal_slopes(seas)[1]', field='inter_slope'),
    T('nan_ttest_1samp(mdata, 0)', 'mstats.ttest_onesamp(mdata, 0)[1]', field='pvalue'),
    T('nan_ks_2samp(mdata, data2)', 'mstats.ks_twosamp(mdata, data2)[1]', field='pvalue'),
    T('nan_kruskal(mdata, data2)', 'mstats.kruskalwallis(mdata, data2)[1]', field='pvalue'),
    T('obrien_transform([1,2,3], [4,5,7])', 'np.asarray(mstats.obrientransform([1,2,3], [4,5,7])).T'),
]
