from gen_tests import T

NC_SETUP = '''S = sparse_csr([4,1,0;1,3,0;0,0,2]);
G = sparse_csr([0,1,4;0,0,2;0,0,0]);
function y = dbl(v):
  y = v * 2;
fnend
function y = mv3(v):
  y = v[0] * [4,1,0] + v[1] * [1,3,0] + v[2] * [0,0,2];
fnend
'''

def PY():
    import numpy as np
    from scipy.sparse import csgraph, linalg as spla
    S = sparse.csr_array([[4.,1,0],[1,3,0],[0,0,2]]) if False else None
    return dict(csgraph=csgraph, spla=spla)

D = 'np.array([[4.,1,0],[1,3,0],[0,0,2]])'
G = 'sparse.csr_array(np.array([[0.,1,4],[0,0,2],[0,0,0]]))'

ROWS = [
    T('sparse_to_dense(S)', D),
    T('sparse_to_dense(sparse_csc([1,0,2;0,0,3]))', '[[1,0,2],[0,0,3]]', label='sparse_csc'),
    T('sparse_to_dense(sparse_coo([1,2,3], [0,0,1], [0,2,2], [2,3]))', '[[1,0,2],[0,0,3]]', label='sparse_coo'),
    T('sparse_to_dense(sparse_coo([1,0;0,2]))', '[[1,0],[0,2]]', label='sparse_coo_dense'),
    T('sparse_to_dense(sparse_bsr(unit_matrix(4), [2,2]))', 'np.eye(4)', label='sparse_bsr'),
    T('sparse_to_dense(sparse_dia([1,2,3], [0], [3,3]))', 'sparse.dia_array(([[1,2,3]],[0]),shape=(3,3)).toarray()', label='sparse_dia'),
    T('sparse_to_dense(sparse_dia([1,2,3;4,5,6], [0,1], [3,3]))', 'sparse.dia_array(([[1,2,3],[4,5,6]],[0,1]),shape=(3,3)).toarray()', label='sparse_dia_2'),
    T('sparse_to_dense(sparse_set(sparse_dok([3,3]), 0, 1, 5))', '[[0,5,0],[0,0,0],[0,0,0]]', label='sparse_dok'),
    T('sparse_to_dense(sparse_set(sparse_lil([3,3]), 1, 2, 7))', '[[0,0,0],[0,0,7],[0,0,0]]', label='sparse_lil'),
    T('is_sparse(S)', '1'), T('is_sparse([1,2])', '0', label='is_sparse_no'),
    T('sparse_to_dense(sparse_diags([1.0,-2.0,1.0], [-1,0,1], [4,4]))', 'sparse.diags_array([1.,-2.,1.],offsets=[-1,0,1],shape=(4,4)).toarray()', label='sparse_diags'),
    T('sparse_to_dense(sparse_eye(3))', 'np.eye(3)', label='sparse_eye'),
    T('sparse_to_dense(sparse_eye(3, 4, 1))', 'np.eye(3,4,1)', label='sparse_eye_k'),
    T('sparse_format(sparse_eye(3, 3, 0, "csr"))', '=csr', label='sparse_eye_format'),
    T('sparse_nnz(sparse_rand(5, 5, 0.3, 1))', '8', label='sparse_rand'),
    T('sparse_to_dense(sparse_block(2, 2, S, 0, 0, S))', 'sparse.block_array([[sparse.csr_array(%s),None],[None,sparse.csr_array(%s)]]).toarray()' % (D, D), label='sparse_block'),
    T('sparse_to_dense(sparse_spdiags([1,2,3,4], 0, 4, 4))', 'sparse.spdiags([1,2,3,4],0,4,4).toarray()', label='sparse_spdiags'),
    T('sparse_to_dense(sparse_kron(S, sparse_eye(2)))', 'np.kron(%s, np.eye(2))' % D, label='sparse_kron'),
    T('sparse_to_dense(sparse_kronsum(S, S))', 'sparse.kronsum(sparse.csr_array(%s),sparse.csr_array(%s)).toarray()' % (D, D), label='sparse_kronsum'),
    T('sparse_to_dense(sparse_block_diag(S, S))', 'sparse.block_diag([%s,%s]).toarray()' % (D, D), label='sparse_block_diag'),
    T('sparse_to_dense(sparse_hstack(S, S))', 'np.hstack([%s,%s])' % (D, D), label='sparse_hstack'),
    T('sparse_to_dense(sparse_vstack(S, S))', 'np.vstack([%s,%s])' % (D, D), label='sparse_vstack'),
    T('sparse_to_dense(sparse_tril(S))', 'np.tril(%s)' % D, label='sparse_tril'),
    T('sparse_to_dense(sparse_triu(S))', 'np.triu(%s)' % D, label='sparse_triu'),
    T('sparse_find(S)', 'sparse.find(sparse.csr_array(%s))[2]' % D, field='values'),
    T('sparse_find(S)', 'sparse.find(sparse.csr_array(%s))[0]' % D, field='rows'),
    T('sparse_to_dense(sparse_transpose(S))', '%s.T' % D, label='sparse_transpose'),
    T('sparse_to_dense(sparse_load("data/nc_sparse_test.ndat"))', D, label='sparse_save_load', setup='sparse_save("data/nc_sparse_test.ndat", S);'),
    T('sparse_format(sparse_csr([4,2;2,3]))', '=csr'), T('sparse_format(sparse_csc([4,2;2,3]))', '=csc', label='sparse_format_csc'),
    T('sparse_format(sparse_bsr([4,2;2,3], [1,1]))', '=bsr', label='sparse_format_bsr'),
    T('sparse_format(sparse_lil([2,2]))', '=lil', label='sparse_format_lil'), T('sparse_format(sparse_dok([2,2]))', '=dok', label='sparse_format_dok'),
    T('sparse_format(sparse_coo([4,2;2,3]))', '=coo', label='sparse_format_coo'),
    T('sparse_format(sparse_dia([1,2], [0], [2,2]))', '=dia', label='sparse_format_dia'),
    T('sparse_format(sparse_convert(S, "csc"))', '=csc', label='sparse_convert'),
    T('sparse_info(S)', '5', field='nnz'), T('sparse_info(S)', 'sparse.csr_array(%s).indptr' % D, field='indptr'),
    T('sparse_mul(S, ones(1,3))', '[5,4,2]', label='sparse_mul'),
    T('sparse_to_dense(sparse_mul(S, S))', '%s @ %s' % (D, D), label='sparse_mul_sparse'),
    T('sparse_sum(S, 0)', '[5,4,2]', label='sparse_sum'), T('sparse_sum(S)', '11', label='sparse_sum_all'),
    T('sparse_max(S)', '4', label='sparse_max'),
    T('sparse_to_dense(sparse_power(S, 2))', '%s**2' % D, label='sparse_power'),
    T('sparse_nnz(sparse_prune(S))', '5', label='sparse_prune'),
    T('sparse_nnz(sparse_sort_indices(S))', '5', label='sparse_sort_indices'),
    T('sparse_nnz(S)', '5'),
    # sparse linear algebra
    T('sparse_mul(linear_operator([3,3], "dbl"), ones(1,3))', '[2,2,2]', label='linear_operator'),
    T('sparse_mul(linear_operator(S), ones(1,3))', '[5,4,2]', label='linear_operator_matrix'),
    T('sparse_to_dense(laplacian_grid([4,4]))', 'spla.LaplacianNd((4,4)).toarray()', label='laplacian_grid'),
    T('sparse_to_dense(laplacian_grid([3], "neumann"))', 'spla.LaplacianNd((3,),boundary_conditions="neumann").toarray()', label='laplacian_grid_neumann'),
    T('sparse_to_dense(laplacian_grid([4], "periodic"))', 'spla.LaplacianNd((4,),boundary_conditions="periodic").toarray()', label='laplacian_grid_periodic'),
    T('sparse_to_dense(sparse_inv(sparse_csc(S)))', 'np.linalg.inv(%s)' % D, label='sparse_inv'),
    T('sparse_norm(S)', 'np.linalg.norm(%s)' % D), T('sparse_norm(S, 1)', '5', label='sparse_norm_1'),
    T('onenorm_est(S)', '5'),
    T('onenorm_est(linear_operator([3,3], "mv3", "mv3"))', '5', label='onenorm_est_operator'),
    T('sparse_solve(sparse_csc(S), ones(1,3))', 'np.linalg.solve(%s, np.ones(3))' % D),
    T('sparse_solve_tri(sparse_tril(S), ones(1,3))', 'np.linalg.solve(np.tril(%s), np.ones(3))' % D),
    T('sparse_is_tri(S)', '0', field='lower'), T('sparse_bandwidth(S)', '1', field='lower'),
    T('sparse_lu_solve(sparse_factorize(sparse_csc(S)), ones(1,3))', 'np.linalg.solve(%s, np.ones(3))' % D, label='sparse_factorize'),
    T('sparse_lu_solve(sparse_lu(sparse_csc(S)), ones(1,3))', 'np.linalg.solve(%s, np.ones(3))' % D, label='sparse_lu'),
    T('sparse_lu_solve(sparse_ilu(sparse_csc(S)), ones(1,3))', 'np.linalg.solve(%s, np.ones(3))' % D, label='sparse_ilu', tol=1e-3),
    *[T('iter_solve(S, ones(1,3), "%s")' % m, 'np.linalg.solve(%s, np.ones(3))' % D, field='x', tol=1e-3, label='iter_solve_' + m)
      for m in ('bicg','bicgstab','cg','cgs','gmres','lgmres','minres','qmr','gcrotmk','tfqmr')],
    T('sparse_lstsq(S, ones(1,3), "lsqr")', 'spla.lsqr(sparse.csr_array(%s), np.ones(3))[0]' % D, field='x', tol=1e-5, label='sparse_lstsq'),
    T('sparse_lstsq(S, ones(1,3), "lsmr")', 'spla.lsmr(sparse.csr_array(%s), np.ones(3))[0]' % D, field='x', tol=1e-5, label='sparse_lstsq_lsmr'),
    T('sparse_eigs(sparse_diags(space(1,10,10), [0], [10,10]), 2)', '[10,9]', field='values', tol=1e-6),
    T('sparse_eigsh(sparse_diags(space(1,10,10), [0], [10,10]), 2)', '[9,10]', field='values', tol=1e-6),
    T('sparse_eigsh(laplacian_grid([40,40]), 3, "LM")', 'np.sort(np.linalg.eigvalsh(spla.LaplacianNd((40,40)).toarray()))[:3]', field='values', tol=1e-5, label='sparse_eigsh_large'),
    T('lobpcg(sparse_diags(space(1,10,10), [0], [10,10]), start2, 0)', '[1,2]', field='values', tol=1e-5,
      setup='nexus_seed(3); start2 = nexus_uniform([10,2]);'),
    T('size(sparse_svds(sparse_rand(10, 8, 0.5, 2), 2)["s"])', '[1,2]', label='sparse_svds'),
    # graphs
    T('graph_components(sparse_csr([0,1,0;1,0,0;0,0,0]))', '2', field='count'),
    T('graph_components(sparse_csr([0,1,0;1,0,0;0,0,0]))', '[0,0,1]', field='labels'),
    T('graph_components(sparse_csr([0,1,0;0,0,1;1,0,0]), 1, "strong")', '1', field='count', label='graph_components_strong'),
    T('graph_laplacian([0,1,1;1,0,1;1,1,0])', '[[2,-1,-1],[-1,2,-1],[-1,-1,2]]'),
    T('graph_laplacian([0,1,1;1,0,1;1,1,0], 1)', 'csgraph.laplacian(np.array([[0.,1,1],[1,0,1],[1,1,0]]),normed=True)', label='graph_laplacian_normed'),
    T('shortest_path(G)', 'csgraph.shortest_path(%s)' % G),
    T('dijkstra(G, 0)', '[0,1,3]'), T('dijkstra(G)', 'csgraph.dijkstra(%s)' % G, label='dijkstra_all'),
    T('floyd_warshall(G)', 'csgraph.floyd_warshall(%s)' % G),
    T('bellman_ford(G)', 'csgraph.bellman_ford(%s)' % G),
    T('johnson(G)', 'csgraph.johnson(%s)' % G),
    T('k_shortest_paths(G, 0, 2, 2)', '[3,4]', field='distances'),
    T('bfs_order(sparse_csr([0,1,1;0,0,1;0,0,0]), 0)', '[0,1,2]', field='order'),
    T('dfs_order(sparse_csr([0,1,1;0,0,1;0,0,0]), 0)', 'csgraph.depth_first_order(sparse.csr_array(np.array([[0.,1,1],[0,0,1],[0,0,0]])),0)[0]', field='order'),
    T('sparse_to_dense(bfs_tree(G, 0))', 'csgraph.breadth_first_tree(%s,0).toarray()' % G, label='bfs_tree'),
    T('sparse_to_dense(dfs_tree(G, 0))', 'csgraph.depth_first_tree(%s,0).toarray()' % G, label='dfs_tree'),
    T('sparse_to_dense(min_spanning_tree(sparse_csr([0,2,5;2,0,1;5,1,0])))', 'csgraph.minimum_spanning_tree(sparse.csr_array(np.array([[0.,2,5],[2,0,1],[5,1,0]]))).toarray()', label='min_spanning_tree'),
    T('reverse_cuthill_mckee(sparse_csr([1,0,1;0,1,0;1,0,1]))', 'csgraph.reverse_cuthill_mckee(sparse.csr_array(np.array([[1,0,1],[0,1,0],[1,0,1]])))'),
    T('max_flow(sparse_csr([0,5,3;0,0,2;0,0,0]), 0, 2)', '5', field='flow_value'),
    T('bipartite_matching(sparse_csr([1,1;1,0]))', 'csgraph.maximum_bipartite_matching(sparse.csr_array(np.array([[1,1],[1,0]])),perm_type="row")', label='bipartite_matching'),
    T('min_weight_matching(sparse_csr([3,1;2,4]))', '[1,0]', field='cols'),
    T('structural_rank(sparse_csr([1,1;0,1]))', '2'),
    T('path_dist_matrix(G, P4)', 'csgraph.construct_dist_matrix(np.array([[0.,1,4],[0,0,2],[0,0,0]]), csgraph.shortest_path(%s,return_predecessors=True)[1])' % G, label='path_dist_matrix',
      setup='P4 = [-1,0,1;-1,-1,1;-1,-1,-1];'),
    T('sparse_to_dense(reconstruct_path(G, [-1,0,1]))', '[[0,1,0],[0,0,2],[0,0,0]]', label='reconstruct_path'),
    T('sparse_to_dense(graph_from_dense([0,2;2,0], 0))', '[[0,2],[2,0]]', label='graph_from_dense'),
    T('graph_to_dense(sparse_csr([0,2;2,0]))', '[[0,2],[2,0]]', label='graph_to_dense'),
    T('graph_to_dense([0,2;2,0], 0/0)', 'np.array([[np.nan,2],[2,np.nan]])', label='graph_to_dense_nan'),
]
