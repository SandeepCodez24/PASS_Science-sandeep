"""Section 25, LAPACK part 5: eigenproblems, Schur forms and their reordering.
Eigenvector signs and phases are arbitrary in LAPACK, so vectors are compared
through abs() or through quantities that do not depend on them."""
import re as _re
from gen_tests import T

NC_SETUP = '''P = [4,2,1;2,5,3;1,3,6];
H = [4,1+1i,0;1-1i,3,2i;0,-2i,5];
G = [2,1,0;1,3,1;0,1,4];
U = [1,2,3;0,4,5;0,0,6];
M = [1,2,3;4,5,6;7,8,10];
function y = posr(wr, wi):
  y = wr > 0;
fnend
function y = posc(w):
  y = real(w) > 0;
fnend
function y = gsel(alpha, beta):
  y = real(alpha / beta) > 2.5;
fnend
'''


def PY():
    import numpy as np
    from scipy.linalg import lapack as L
    P = np.array([[4., 2, 1], [2, 5, 3], [1, 3, 6]])
    H = np.array([[4, 1 + 1j, 0], [1 - 1j, 3, 2j], [0, -2j, 5]])
    G = np.array([[2., 1, 0], [1, 3, 1], [0, 1, 4]])
    U = np.array([[1., 2, 3], [0, 4, 5], [0, 0, 6]])
    M = np.array([[1., 2, 3], [4, 5, 6], [7, 8, 10]])
    return dict(L=L, np=np, P=P, H=H, G=G, U=U, M=M)


ROWS = [
    T('lapack_syev(P)', 'L.dsyev(P)[0]', field='w'),
    T('abs(lapack_syev(P)["v"])', 'np.abs(L.dsyev(P)[1])', label='lapack_syev_v'),
    T('lapack_syev(P, 1, 1)', 'L.dsyev(P, lower=1)[0]', field='w', label='lapack_syev_lower'),
    T('lapack_syevd(P)', 'L.dsyevd(P)[0]', field='w'),
    T('lapack_heev(H)', 'L.zheev(H)[0]', field='w'),
    T('lapack_heevd(H)', 'L.zheevd(H)[0]', field='w'),
    T('lapack_syevr(P)', 'L.dsyevr(P)[0]', field='w'),
    T('lapack_syevr(P, 1, "I", 0, 0, 1, 2, 3)', 'L.dsyevr(P, range="I", il=2, iu=3)[0][:2]', label='lapack_syevr_I',
      setup='') if False else T('lapack_syevr(P, 1, "I", 0, 0, 1, 2, 3)["w"][0:1]', 'L.dsyevr(P, range="I", il=2, iu=3)[0][:2]', label='lapack_syevr_I'),
    T('lapack_syevr(P, 1, "I", 0, 0, 1, 2, 3)', 'L.dsyevr(P, range="I", il=2, iu=3)[2]', field='m', label='lapack_syevr_m'),
    T('lapack_syevx(P, 1, "V", 0, 2, 8)', 'L.dsyevx(P, range="V", vl=2., vu=8.)[2]', field='m'),
    T('lapack_syevx(P, 1, "V", 0, 2, 8)["w"][0:1]', 'L.dsyevx(P, range="V", vl=2., vu=8.)[0][:2]', label='lapack_syevx_w'),
    T('lapack_heevr(H)', 'L.zheevr(H)[0]', field='w'),
    T('lapack_heevx(H, 1, "I", 0, 0, 1, 1, 1)["w"][0]', 'L.zheevx(H, range="I", il=1, iu=1)[0][0]', label='lapack_heevx'),
    T('lapack_sygst(P, lapack_potrf(G)["c"])', 'L.dsygst(P, L.dpotrf(G)[0])[0]', field='c'),
    T('lapack_sygst(P, lapack_potrf(G, 1)["c"], 2, 1)', 'L.dsygst(P, L.dpotrf(G, lower=1)[0], itype=2, lower=1)[0]', field='c', label='lapack_sygst_2l'),
    T('lapack_hegst(H, lapack_potrf(G)["c"])', 'L.zhegst(H, L.dpotrf(G)[0].astype(complex))[0]', field='c'),
    T('lapack_sygv(P, G)', 'L.dsygv(P, G)[0]', field='w'),
    T('abs(lapack_sygv(P, G)["v"])', 'np.abs(L.dsygv(P, G)[1])', label='lapack_sygv_v'),
    T('lapack_sygv(P, G, 2)', 'L.dsygv(P, G, itype=2)[0]', field='w', label='lapack_sygv_2'),
    T('abs(lapack_sygv(P, G, 3, "V", "U")["v"])', 'np.abs(L.dsygv(P, G, itype=3, uplo="U")[1])', label='lapack_sygv_3u'),
    T('lapack_sygvd(P, G)', 'L.dsygvd(P, G)[0]', field='w'),
    T('lapack_sygvx(P, G, 1, "V", "I", "L", 0, 1, 1, 2)["w"][0:1]', 'L.dsygvx(P, G, range="I", il=1, iu=2)[0][:2]', label='lapack_sygvx'),
    T('lapack_hegv(H, G)', 'L.zhegv(H, G.astype(complex))[0]', field='w'),
    T('lapack_hegvd(H, G)', 'L.zhegvd(H, G.astype(complex))[0]', field='w'),
    T('lapack_hegvx(H, G, 1, "V", "A")', 'L.zhegvx(H, G.astype(complex))[2]', field='m'),
    T('lapack_sytrd(P)', 'L.dsytrd(P)[0]', field='c'),
    T('lapack_sytrd(P)', 'L.dsytrd(P)[1]', field='d', label='lapack_sytrd_d'),
    T('lapack_sytrd(P)', 'L.dsytrd(P)[2]', field='e', label='lapack_sytrd_e'),
    T('lapack_sytrd(P)', 'L.dsytrd(P)[3]', field='tau', label='lapack_sytrd_tau'),
    T('lapack_sytrd(P, 1)', 'L.dsytrd(P, lower=1)[0]', field='c', label='lapack_sytrd_lower'),
    T('lapack_hetrd(H)', 'L.zhetrd(H)[0]', field='c'),
    T('lapack_hetrd(H)', 'L.zhetrd(H)[3]', field='tau', label='lapack_hetrd_tau'),
    T('lapack_hetrd(H, 1)', 'L.zhetrd(H, lower=1)[0]', field='c', label='lapack_hetrd_lower'),
    T('lapack_sbev([0,2,3;4,5,6])', 'L.dsbev(np.array([[0.,2,3],[4,5,6]]))[0]', field='w'),
    T('abs(lapack_sbev([0,2,3;4,5,6])["z"])', 'np.abs(L.dsbev(np.array([[0.,2,3],[4,5,6]]))[1])', label='lapack_sbev_z'),
    T('lapack_sbevd([4,5,6;2,3,0], 1, 1)', 'L.dsbevd(np.array([[4.,5,6],[2,3,0]]), lower=1)[0]', field='w'),
    T('lapack_sbevx([0,2,3;4,5,6], 0, 0, 2, 3, 2, 1, 2)', 'L.dsbevx(np.array([[0.,2,3],[4,5,6]]), 0., 0., 2, 3, range=2)[2]', field='m'),
    T('lapack_sbevx([0,2,3;4,5,6], 0, 0, 2, 3, 2, 1, 2)["w"][0:1]', 'L.dsbevx(np.array([[0.,2,3],[4,5,6]]), 0., 0., 2, 3, range=2)[0][:2]', label='lapack_sbevx_w'),
    T('lapack_hbevd([0,1+1i;2,3])', 'L.zhbevd(np.array([[0,1+1j],[2,3]]))[0]', field='w'),
    T('lapack_hbevx([0,1+1i;2,3], 0, 0, 1, 2)', 'L.zhbevx(np.array([[0,1+1j],[2,3]]), 0., 0., 1, 2)[0]', field='w'),
    T('lapack_sterf([2,3,4], [1,1])', 'L.dsterf(np.array([2.,3,4]), np.array([1.,1]))[0]', field='vals'),
    T('lapack_stev([2,3,4], [1,1])', 'L.dstev(np.array([2.,3,4]), np.array([1.,1]))[0]', field='vals'),
    T('abs(lapack_stev([2,3,4], [1,1])["z"])', 'np.abs(L.dstev(np.array([2.,3,4]), np.array([1.,1]))[1])', label='lapack_stev_z'),
    T('lapack_stevd([2,3,4], [1,1])', 'L.dstevd(np.array([2.,3,4]), np.array([1.,1]))[0]', field='vals'),
    T('lapack_stebz([1,2,3], [1,1], 0, 0, 0, 0, 0, 0, "E")', 'L.dstebz(np.array([1.,2,3]), np.array([1.,1]), 0, 0, 0, 0, 0, 0, "E")[1]', field='w'),
    T('lapack_stebz([1,2,3], [1,1], 0, 0, 0, 0, 0, 0, "E")', 'L.dstebz(np.array([1.,2,3]), np.array([1.,1]), 0, 0, 0, 0, 0, 0, "E")[2]', field='iblock'),
    T('lapack_stebz([1,2,3], [1,1], 0, 0, 0, 0, 0, 0, "E")', 'L.dstebz(np.array([1.,2,3]), np.array([1.,1]), 0, 0, 0, 0, 0, 0, "E")[3]', field='isplit'),
    T('lapack_stebz([1,2,3,4], [1,0,1], 2, 0, 0, 2, 3, 0, "B")', 'L.dstebz(np.array([1.,2,3,4]), np.array([1.,0,1]), 2, 0, 0, 2, 3, 0, "B")[1]', field='w', label='lapack_stebz_split'),
    T('lapack_stebz([1,2,3,4], [1,0,1], 2, 0, 0, 2, 3, 0, "B")', 'L.dstebz(np.array([1.,2,3,4]), np.array([1.,0,1]), 2, 0, 0, 2, 3, 0, "B")[2]', field='iblock', label='lapack_stebz_block'),
    T('lapack_stein([1,2,3], [1,1], [0.26794919243112264,3.732050807568877], [1,1,0], [3,0,0])',
      'L.dstein(np.array([1.,2,3]), np.array([1.,1]), np.array([0.26794919243112264,3.732050807568877]), np.array([1,1,0]), np.array([3,0,0]))[0]',
      field='z', tol=1e-6),
    T('lapack_stemr([2,3,4], [1,1,0], 0, 0, 0, 0, 0)["w"]', 'L.dstemr(np.array([2.,3,4]), np.array([1.,1,0]), 0, 0., 0., 0, 0)[1]', label='lapack_stemr'),
    T('lapack_stemr([2,3,4], [1,1,0], 2, 0, 0, 1, 2)', 'L.dstemr(np.array([2.,3,4]), np.array([1.,1,0]), 2, 0., 0., 1, 2)[0]', field='m', label='lapack_stemr_m'),
    T('lapack_gebal([1,100,0;0.01,2,0;3,4,5], 1, 1)', 'L.dgebal(np.array([[1.,100,0],[0.01,2,0],[3,4,5]]), scale=1, permute=1)[0]', field='ba'),
    T('lapack_gebal([1,100,0;0.01,2,0;3,4,5], 1, 1)', 'L.dgebal(np.array([[1.,100,0],[0.01,2,0],[3,4,5]]), scale=1, permute=1)[1]', field='lo'),
    T('lapack_gebal([1,100,0;0.01,2,0;3,4,5], 1, 1)', 'L.dgebal(np.array([[1.,100,0],[0.01,2,0],[3,4,5]]), scale=1, permute=1)[2]', field='hi'),
    T('lapack_gebal([1,100,0;0.01,2,0;3,4,5], 1, 1)', 'L.dgebal(np.array([[1.,100,0],[0.01,2,0],[3,4,5]]), scale=1, permute=1)[3]', field='pivscale'),
    T('lapack_gebal([1,1000,2;0.001,2,3;1,2,3], 1)', 'L.dgebal(np.array([[1.,1000,2],[0.001,2,3],[1,2,3]]), scale=1)[0]', field='ba', label='lapack_gebal_scale'),
    T('lapack_gehrd(M)', 'L.dgehrd(M)[0]', field='ht'),
    T('lapack_gehrd(M)', 'L.dgehrd(M)[1]', field='tau', label='lapack_gehrd_tau'),
    T('lapack_gehrd(H)', 'L.zgehrd(H)[0]', field='ht', label='lapack_gehrd_c'),
    T('lapack_orghr(lapack_gehrd(M)["ht"], lapack_gehrd(M)["tau"])', '(lambda f: L.dorghr(f[0], f[1])[0])(L.dgehrd(M))', field='ht'),
    T('lapack_unghr(lapack_gehrd(H)["ht"], lapack_gehrd(H)["tau"])', '(lambda f: L.zunghr(f[0], f[1])[0])(L.zgehrd(H))', field='ht'),
    T('lapack_geev(U)', 'L.dgeev(U)[0]', field='wr'),
    T('abs(lapack_geev(U)["vr"])', 'np.abs(L.dgeev(U)[3])', label='lapack_geev_vr'),
    T('abs(lapack_geev(U)["vl"])', 'np.abs(L.dgeev(U)[2])', label='lapack_geev_vl'),
    T('lapack_geev([0,-1;1,0])', 'L.dgeev(np.array([[0.,-1],[1,0]]))[1]', field='wi', label='lapack_geev_pair'),
    T('lapack_geev([1,2i;0,3])', 'L.zgeev(np.array([[1,2j],[0,3]]))[0]', field='w', label='lapack_geev_c'),
    T('abs(lapack_geev([1,2i;0,3])["vr"])', 'np.abs(L.zgeev(np.array([[1,2j],[0,3]]))[2])', label='lapack_geev_cvr'),
    T('lapack_gees(0, U)', 'L.dgees(lambda a, b: 0, U)[2]', field='wr'),
    T('lapack_gees("posr", [-1,1,0;0,2,0;0,0,-3], 1, 1)', 'L.dgees(lambda a, b: a > 0, np.array([[-1.,1,0],[0,2,0],[0,0,-3]]), sort_t=1)[1]', field='sdim', label='lapack_gees_sdim'),
    T('lapack_gees("posr", [-1,1,0;0,2,0;0,0,-3], 1, 1)', 'L.dgees(lambda a, b: a > 0, np.array([[-1.,1,0],[0,2,0],[0,0,-3]]), sort_t=1)[2]', field='wr', label='lapack_gees_sorted'),
    T('lapack_gees("posr", [-1,1,0,0;0,-2,0,0;0,0,1,-2;0,0,2,1], 1, 1)', 'L.dgees(lambda a, b: a > 0, np.array([[-1.,1,0,0],[0,-2,0,0],[0,0,1,-2],[0,0,2,1]]), sort_t=1)[2]', field='wr', label='lapack_gees_block'),
    T('lapack_gees("posr", [-1,1,0,0;0,-2,0,0;0,0,1,-2;0,0,2,1], 1, 1)', 'L.dgees(lambda a, b: a > 0, np.array([[-1.,1,0,0],[0,-2,0,0],[0,0,1,-2],[0,0,2,1]]), sort_t=1)[3]', field='wi', label='lapack_gees_block_wi'),
    T('lapack_gees("posc", [-1,1i;0,2], 1, 1)', 'L.zgees(lambda w: w.real > 0, np.array([[-1,1j],[0,2]]), sort_t=1)[2]', field='w', label='lapack_gees_c'),
    T('lapack_gges(0, [1i,2;0,3], [1,1;0,2])', 'L.zgges(lambda a, b: 0, np.array([[1j,2],[0,3]]), np.array([[1.,1],[0,2]]))[3] / L.zgges(lambda a, b: 0, np.array([[1j,2],[0,3]]), np.array([[1.,1],[0,2]]))[4]',
      label='lapack_gges', setup='') if False else T('ggr(lapack_gges(0, [1i,2;0,3], [1,1;0,2]))',
      '(lambda r: r[3] / r[4])(L.zgges(lambda a, b: 0, np.array([[1j,2],[0,3]]), np.array([[1.,1],[0,2]])))', label='lapack_gges',
      setup='function y = ggr(r):\n  y = r["alpha"] /. r["beta"];\nfnend'),
    T('lapack_gges("gsel", [1i,2,0;0,3,1;0,0,4], [1,1,0;0,1,0;0,0,1], 1, 1, 1)', 'L.zgges(lambda a, b: (a / b).real > 2.5, np.array([[1j,2,0],[0,3,1],[0,0,4]]), np.array([[1.,1,0],[0,1,0],[0,0,1]]), sort_t=1)[2]', field='sdim', label='lapack_gges_sdim'),
    T('ggr(lapack_gges("gsel", [1i,2,0;0,3,1;0,0,4], [1,1,0;0,1,0;0,0,1], 1, 1, 1))',
      '(lambda r: r[3] / r[4])(L.zgges(lambda a, b: (a / b).real > 2.5, np.array([[1j,2,0],[0,3,1],[0,0,4]]), np.array([[1.,1,0],[0,1,0],[0,0,1]]), sort_t=1))',
      label='lapack_gges_sorted', setup='function y = ggr(r):\n  y = r["alpha"] /. r["beta"];\nfnend'),
    T('lapack_trexc(U, unit_matrix(3), 1, 3)', 'L.dtrexc(U, np.eye(3), 1, 3)[0]', field='a'),
    T('lapack_trexc(U, unit_matrix(3), 1, 3)', 'L.dtrexc(U, np.eye(3), 1, 3)[1]', field='q', label='lapack_trexc_q'),
    T('lapack_trexc(U, unit_matrix(3), 3, 1)', 'L.dtrexc(U, np.eye(3), 3, 1)[0]', field='a', label='lapack_trexc_up'),
    T('lapack_trexc([1,2i,3;0,4,5;0,0,6i], unit_matrix(3), 1, 2)', 'L.ztrexc(np.array([[1,2j,3],[0,4,5],[0,0,6j]]), np.eye(3, dtype=complex), 1, 2)[0]', field='a', label='lapack_trexc_c'),
    T('lapack_trsen([0,0,1], U, unit_matrix(3))', 'L.dtrsen(np.array([0,0,1]), U, np.eye(3), lwork=10, liwork=10)[0]', field='ts'),
    T('lapack_trsen([0,0,1], U, unit_matrix(3))', 'L.dtrsen(np.array([0,0,1]), U, np.eye(3), lwork=10, liwork=10)[5]', field='s', label='lapack_trsen_s'),
    T('lapack_trsen([0,0,1], U, unit_matrix(3))', 'L.dtrsen(np.array([0,0,1]), U, np.eye(3), lwork=10, liwork=10)[6]', field='sep', label='lapack_trsen_sep', tol=1e-6),
    T('lapack_trsen([0,1,0], [1,2i,3;0,4,5;0,0,6i], unit_matrix(3))', 'L.ztrsen(np.array([0,1,0]), np.array([[1,2j,3],[0,4,5],[0,0,6j]]), np.eye(3, dtype=complex), lwork=10)[2]', field='w', label='lapack_trsen_c'),
    T('lapack_tgexc([1,2;0,3], [1,1;0,2], unit_matrix(2), unit_matrix(2), 1, 2)', 'None', field='a'),
    T('tgr(lapack_tgexc([1,2,1;0,3,1;0,0,5], [1,1,0;0,2,1;0,0,1], unit_matrix(3), unit_matrix(3), 1, 3))',
      '[1.5, 5., 1.]', label='lapack_tgexc_order',
      setup='function y = tgr(r):\n  y = diag(r["a"]) /. diag(r["b"]);\nfnend'),
    T('lapack_tgsen([0,1,1], [1,2,1;0,3,1;0,0,5], [1,1,0;0,2,1;0,0,1], unit_matrix(3), unit_matrix(3))', '2', field='m'),
    T('tsr(lapack_tgsen([0,1,1], [1,2,1;0,3,1;0,0,5], [1,1,0;0,2,1;0,0,1], unit_matrix(3), unit_matrix(3)))',
      '[1.5, 5., 1.]', label='lapack_tgsen_order',
      setup='function y = tsr(r):\n  y = r["alphar"] /. r["beta"];\nfnend'),
    T('lapack_trsyl(U, [2,1;0,3], [1,2;3,4;5,6])', 'L.dtrsyl(U, np.array([[2.,1],[0,3]]), np.array([[1.,2],[3,4],[5,6]]))[0]', field='x'),
    T('lapack_trsyl(U, [2,1;0,3], [1,2;3,4;5,6], "T", "N", -1)', 'L.dtrsyl(U, np.array([[2.,1],[0,3]]), np.array([[1.,2],[3,4],[5,6]]), trana="T", isgn=-1)[0]', field='x', label='lapack_trsyl_t'),
    T('lapack_tgsyl([1,2;0,3], [4,1;0,5], [1,2;3,4], [1,0;0,1], [1,1;0,1], [2,1;1,2])',
      'L.dtgsyl(np.array([[1.,2],[0,3]]), np.array([[4.,1],[0,5]]), np.array([[1.,2],[3,4]]), np.array([[1.,0],[0,1]]), np.array([[1.,1],[0,1]]), np.array([[2.,1],[1,2]]))[0]', field='r'),
    T('lapack_tgsyl([1,2;0,3], [4,1;0,5], [1,2;3,4], [1,0;0,1], [1,1;0,1], [2,1;1,2])',
      'L.dtgsyl(np.array([[1.,2],[0,3]]), np.array([[4.,1],[0,5]]), np.array([[1.,2],[3,4]]), np.array([[1.,0],[0,1]]), np.array([[1.,1],[0,1]]), np.array([[2.,1],[1,2]]))[1]', field='l', label='lapack_tgsyl_l'),
]

for _t in ROWS:
    if isinstance(_t.py, str) and not _t.py.startswith('='):
        _t.py = _re.sub(r'(?<![\w.\'"])(P|H|G|U|M)\b(?!\s*=)', r'\1.copy()', _t.py)
    if _t.py == 'None':
        _t.py = None
