from gen_tests import T

NC_SETUP = '''function y = sq(t):
  y = t ^ 2;
fnend
function y = vecf(t):
  y = [t, t ^ 2];
fnend
function y = f2(y0, x0):
  y = x0 * y0;
fnend
function y = f3(z0, y0, x0):
  y = x0 * y0 * z0;
fnend
function y = fa(a0, c0):
  y = a0 * c0;
fnend
function y = fbox(v):
  y = v[0] ^ 2 + v[1] ^ 2;
fnend
function y = inv_sq(k):
  y = 1 / k ^ 2;
fnend
function du = decay(t, u):
  du = -0.5 * u;
fnend
function du = decay2(u, t):
  du = -0.5 * u;
fnend
function du = osc(t, u):
  du = [u[1], -1 * u[0]];
fnend
function du = stiff(t, u):
  du = -1000 * (u - cos(t));
fnend
function du = rot(t, u):
  du = 1i * u;
fnend
function du = bvp_f(t, u):
  du = [u[1], -1 * u[0]];
fnend
function r = bvp_bc(ua, ub):
  r = [ua[0], ub[0] - 1];
fnend
function y = gaussf(t):
  y = exp(-1 * t ^ 2);
fnend
function y = root_sing(t):
  y = 1 / sqrt(t);
fnend
x = space(0, 10, 11);
y = sin(x);
'''

ROWS = [
    T('integrate("sq", 0, 3)', '9.0', field='value'),
    T('integrate("gaussf", 0, 1/0)', 'integrate.quad(lambda t: np.exp(-t*t), 0, np.inf)[0]', field='value', label='integrate_inf'),
    T('integrate("gaussf", -1/0, 1/0)', 'np.sqrt(np.pi)', field='value', label='integrate_both_inf'),
    T('integrate(@cos, 0, 1)', 'np.sin(1)', field='value', label='integrate_ref'),
    T('integrate_vec("vecf", 0, 1)', '[0.5,1/3]', field='value'),
    T('integrate2("f2", 0, 1, 0, 2)', '1.0', field='value'),
    T('integrate3("f3", 0, 1, 0, 1, 0, 1)', '0.125', field='value'),
    T('integrate_n("fa", [0,1;0,2])', '1.0', field='value'),
    T('integrate_fixed("cos", 0, pi/2, 5)', 'integrate.fixed_quad(np.cos, 0, np.pi/2, n=5)[0]'),
    T('newton_cotes(4, 1)', 'integrate.newton_cotes(4, 1)[0]', field='weights'),
    T('newton_cotes(4, 1)', 'integrate.newton_cotes(4, 1)[1]', field='error', tol=1e-9),
    T('newton_cotes(3, 1)', 'integrate.newton_cotes(3, 1)[1]', field='error', tol=1e-9, label='newton_cotes_odd'),
    T('integrate_qmc("fbox", [0,0], [1,1])', '2/3', field='integral', tol=1e-2),
    T('integrate_tanhsinh("exp", 0, 1)', 'np.e-1', field='integral'),
    T('integrate_tanhsinh("root_sing", 0, 1)', '2.0', field='integral', tol=1e-6, label='integrate_tanhsinh_singular'),
    T('cubature("fbox", [0,0], [1,1])', '2/3', field='estimate'),
    T('lebedev_rule(7)', 'integrate.lebedev_rule(7)[1]', field='weights'),
    T('lebedev_rule(7)', 'integrate.lebedev_rule(7)[0]', field='points'),
    T('nsum("inv_sq", 1, 1/0)', 'np.pi**2/6', field='sum', tol=1e-8),
    T('nsum("inv_sq", 1, 10)', 'sum(1/k**2 for k in range(1,11))', field='sum', label='nsum_finite'),
    T('cumtrapz(y, x, 0)', 'integrate.cumulative_trapezoid(y, x, initial=0)'),
    T('cumtrapz(y)', 'integrate.cumulative_trapezoid(y)', label='cumtrapz_no_x'),
    T('simpson(y, x)', 'integrate.simpson(y, x=x)'),
    T('simpson(y[0:9], x[0:9])', 'integrate.simpson(y[:10], x=x[:10])', label='simpson_even'),
    T('cumsimpson(y, x, 0)', 'integrate.cumulative_simpson(y, x=x, initial=0)'),
    T('cumsimpson(y[0:9], x[0:9], 0)', 'integrate.cumulative_simpson(y[:10], x=x[:10], initial=0)', label='cumsimpson_even'),
    T('romb(sin(space(0, pi, 9)), pi/8)', 'integrate.romb(np.sin(np.linspace(0,np.pi,9)), np.pi/8)'),
    *[T('last_u(ode_solve("decay", [0, 10], [2.0], "%s"))' % m, '2*np.exp(-5)', tol=1e-3, label='ode_' + m,
        setup='function v = last_u(s):\n  u = s["u"];\n  v = u[numel(u)-1];\nfnend') for m in ('RK45', 'RK23', 'DOP853', 'Radau', 'BDF', 'LSODA')],
    *[T('last_u(ode_solve("stiff", [0, 2], [0.0], "%s"))' % m, 'integrate.solve_ivp(lambda t,u: -1000*(u-np.cos(t)), [0,2], [0.], method="Radau", rtol=1e-9, atol=1e-11).y[0,-1]', tol=1e-3, label='ode_stiff_' + m,
        setup='function v = last_u(s):\n  u = s["u"];\n  v = u[numel(u)-1];\nfnend') for m in ('Radau', 'BDF', 'LSODA')],
    T('last_u2(ode_solve("osc", [0, 3], [1.0, 0.0]))', 'np.cos(3)', tol=1e-4, label='ode_system', setup='function v = last_u2(s):\n  u = s["u"];\n  v = u[0, size(u)[1]-1];\nfnend') if False else T('ode_eval(ode_solve("osc", [0, 3], [1.0, 0.0], "RK45", 1), 3)', '[np.cos(3), -np.sin(3)]', tol=1e-4, label='ode_system'),
    T('ode_eval(ode_solve("decay", [0, 5], [1.0], "RK45", 1), 2.5)', 'np.exp(-1.25)', tol=1e-5),
    T('ode_eval(ode_solve("decay", [0, 5], [1.0], "RK45", 1), [1, 2.5])', 'np.exp(-0.5*np.array([1,2.5]))', tol=1e-5, label='ode_eval_many'),
    T('ode_solve("rot", [0, 1], [1.0 + 0i])', None, field='u', label='ode_complex'),
    T('ode_eval(ode_solve("rot", [0, 1], [1.0 + 0i], "RK45", 1), 1)', 'np.exp(1j)', tol=1e-5, label='ode_complex_value'),
    T('odeint("decay2", 2.0, space(0, 10, 5))', 'integrate.odeint(lambda u,t: -0.5*u, 2.0, np.linspace(0,10,5))', tol=1e-5),
    T('bvp_u(bvp_solve("bvp_f", "bvp_bc", space(0, 1, 5), zeros(2, 5)))', 'np.sin(1)/np.sin(1)', tol=1e-5, label='bvp_solve',
      setup='function v = bvp_u(s):\n  u = s["u"];\n  v = u[0, numel(s["t"])-1];\nfnend'),
    T('bvp_u0(bvp_solve("bvp_f", "bvp_bc", space(0, 1, 5), zeros(2, 5)))', '1/np.sin(1)', tol=1e-5, label='bvp_solve_slope',
      setup='function v = bvp_u0(s):\n  u = s["u"];\n  v = u[1, 0];\nfnend'),
]
