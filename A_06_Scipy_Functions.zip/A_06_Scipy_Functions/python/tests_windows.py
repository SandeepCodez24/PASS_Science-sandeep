from gen_tests import T

W = windows = None

def row(nc, py, n=51):
    return [T('%s_win(%d%s)' % (nc, n, py[1]), 'windows.%s(%d%s)' % (py[0], n, py[1])),
            T('%s_win(%d%s)' % (nc, 10, py[1]), 'windows.%s(%d%s)' % (py[0], 10, py[1]), label=nc + '_even'),
            T('%s_win(%d%s, 0)' % (nc, 10, py[1]), 'windows.%s(%d%s, sym=False)' % (py[0], 10, py[1]), label=nc + '_periodic')]

ROWS = []
for nc, py in [('barthann', ('barthann', '')), ('bartlett', ('bartlett', '')), ('blackman', ('blackman', '')),
               ('blackmanharris', ('blackmanharris', '')), ('bohman', ('bohman', '')), ('boxcar', ('boxcar', '')),
               ('chebwin', ('chebwin', ', 100')), ('cosine', ('cosine', '')), ('flattop', ('flattop', '')),
               ('gaussian', ('gaussian', ', 7')), ('general_hamming', ('general_hamming', ', 0.6')),
               ('general_gaussian', ('general_gaussian', ', 1.5, 7')),
               ('hamming', ('hamming', '')), ('hann', ('hann', '')), ('kaiser', ('kaiser', ', 14')),
               ('lanczos', ('lanczos', '')), ('nuttall', ('nuttall', '')), ('parzen', ('parzen', '')),
               ('triang', ('triang', '')), ('tukey', ('tukey', ', 0.5'))]:
    ROWS += row(nc, py)
ROWS += [
    T('general_cosine_win(51, [0.5, 0.5])', 'windows.general_cosine(51, [0.5,0.5])'),
    T('taylor_win(51, 4, 30)', 'windows.taylor(51, 4, 30)'),
    T('taylor_win(10, 4, 30, 0)', 'windows.taylor(10, 4, 30, sym=False)', label='taylor_periodic'),
    T('exponential_win(51, 3.0)', 'windows.exponential(51, tau=3.0)'),
    T('exponential_win(10, 3.0, 2, 0)', 'windows.exponential(10, center=2, tau=3.0, sym=False)', label='exponential_center'),
    T('kbd_win(50, 4)', 'windows.kaiser_bessel_derived(50, 4)'),
    T('dpss_win(51, 2.5)', 'windows.dpss(51, 2.5)', tol=1e-3),
    T('dpss_win(20, 3, 2)', 'windows.dpss(20, 3, 2)', tol=1e-3, label='dpss_many'),
]
