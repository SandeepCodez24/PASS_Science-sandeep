from gen_tests import T

NC_SETUP = '''x = space(0, 10, 11);
function ok = wolfe_ok(x0, p):
  al = line_search("rosen", "rosen_der", x0, p)["alpha"];
  d0 = sum(rosen_der(x0) *. p);
  d1 = sum(rosen_der(x0 + al * p) *. p);
  ok = (rosen(x0 + al * p) <= rosen(x0) + 1e-4 * al * d0) * (abs(d1) <= 0.9 * abs(d0));
fnend
function y = line(t, p1, p2):
  y = p1 * t + p2;
fnend
function y = line_b(beta, t):
  y = beta[0] * t + beta[1];
fnend
function y = fq(t):
  y = (t - 2) ^ 2;
fnend
function y = g2(t):
  y = t ^ 2 - 2;
fnend
function y = dg2(t):
  y = 2 * t;
fnend
function y = sumsq(v):
  y = v[0] ^ 2 + v[1] ^ 2;
fnend
function y = circle(v):
  y = v[0] ^ 2 + v[1] ^ 2;
fnend
function y = bumpy(v):
  y = cos(14.5 * v[0] - 0.3) + (v[0] + 0.2) * v[0];
fnend
function y = brutef(v):
  y = (v[0] - 1) ^ 2 + (v[1] + 2) ^ 2;
fnend
function r = resid(p):
  t = space(0, 10, 11);
  r = p[0] * t + p[1] - (2 * t + 1);
fnend
function r = eqs(v):
  r = [v[0] + 0.5 * (v[0] - v[1]) ^ 3 - 1, 0.5 * (v[1] - v[0]) ^ 3 + v[1]];
fnend
function r = cube8(v):
  r = v ^ 3 - 8;
fnend
function r = cosfix(v):
  r = cos(v) - v;
fnend
'''

MINS = {'BFGS': 1e-4, 'Nelder-Mead': 1e-3, 'Powell': 1e-3, 'CG': 1e-4, 'L-BFGS-B': 1e-3, 'TNC': 1e-3, 'trust-constr': 1e-3, 'SLSQP': 1e-2}
RM = ('hybr', 'lm', 'krylov')

ROWS = [
    *[T('minimize("rosen", [1.3, 0.7], "%s")' % m, '[1,1]', field='x', tol=t, label='minimize_' + m) for m, t in MINS.items() if m != 'SLSQP'],
    T('minimize("rosen", [1.3,0.7], "Newton-CG", 0, 0, "rosen_der")', '[1,1]', field='x', tol=1e-3, label='minimize_Newton-CG'),
    T('minimize("rosen", [1.3,0.7], "trust-constr", 0, 0, "rosen_der", "BFGS")', '[1,1]', field='x', tol=1e-3, label='minimize_hess_BFGS'),
    T('minimize("rosen", [1.3,0.7], "trust-constr", 0, 0, "rosen_der", "SR1")', '[1,1]', field='x', tol=1e-3, label='minimize_hess_SR1'),
    T('minimize("rosen", [1.3,0.7], "L-BFGS-B")', None, field='hess_inv'),
    T('minimize("rosen", [1.5,1.5], "L-BFGS-B", bounds([0,0], [2,2]))', '[1,1]', field='x', tol=1e-3, label='bounds'),
    T('minimize("rosen", [0.5,0.5], "trust-constr", 0, nonlinear_constraint("circle", -1/0, 1))', 'optimize.minimize(optimize.rosen,[0.5,0.5],constraints=optimize.NonlinearConstraint(lambda v:v[0]**2+v[1]**2,-np.inf,1),method="SLSQP").x', field='x', tol=1e-3, label='nonlinear_constraint'),
    T('minimize("rosen", [0.2,0.2], "trust-constr", 0, linear_constraint([1,1], -1/0, 1))', 'optimize.minimize(optimize.rosen,[0.2,0.2],constraints=optimize.LinearConstraint([[1,1]],-np.inf,1),method="SLSQP").x', field='x', tol=1e-3, label='linear_constraint'),
    T('minimize("sumsq", [1,1], "SLSQP", 0, linear_constraint([1,1], 1, 1))', '[0.5,0.5]', field='x', tol=1e-5, label='minimize_SLSQP'),
    T('minimize("sumsq", [1,1], "COBYLA", 0, linear_constraint([1,1], 1, 1))', '[0.5,0.5]', field='x', tol=1e-3, label='minimize_COBYLA'),
    T('minimize_scalar("fq")', '2', field='x', tol=1e-6),
    T('minimize_scalar("cos", [3,4], "bounded")', 'np.pi', field='x', tol=1e-6, label='minimize_scalar_bounded'),
    T('minimize_scalar("fq", 0, "brent")', '2', field='x', tol=1e-6, label='minimize_scalar_brent'),
    T('minimize_scalar("fq", 0, "golden")', '2', field='x', tol=1e-6, label='minimize_scalar_golden'),
    T('show_options("minimize", "nelder-mead")', None),
    T('bracket_min("fq")["fb"] <= bracket_min("fq")["fa"]', '1', label='bracket_min'),
    T('wolfe_ok([1.3,0.7], -1 * rosen_der([1.3,0.7]))', '1', label='line_search'),
    T('basin_hopping("bumpy", [1.0], 20, 1)', '-1.0008761', field='fun', tol=1e-2),
    T('brute_force_min("brutef", [-3,3;-3,3])', '[1,-2]', tol=1e-4),
    T('differential_evolution("rosen", [-2,2;-2,2], 1)', '[1,1]', field='x', tol=1e-3),
    T('shgo("rosen", [-2,2;-2,2])', '[1,1]', field='x', tol=1e-3),
    T('dual_annealing("rosen", [-2,2;-2,2], 1, 100)', '[1,1]', field='x', tol=1e-2),
    T('direct_search("rosen", [-2,2;-2,2])', '[1,1]', field='x', tol=2e-1),
    T('least_squares("resid", [0.0, 0.0])', '[2,1]', field='x', tol=1e-5),
    T('least_squares("resid", [0.0,0.0], 0, "lm")', '[2,1]', field='x', tol=1e-5, label='least_squares_lm'),
    T('least_squares("resid", [0.0,0.0], [0,1.5;0,0.5])', 'optimize.least_squares(lambda p: p[0]*np.arange(11.)+p[1]-(2*np.arange(11.)+1),[0.5,0.2],bounds=([0,0],[1.5,0.5])).x', field='x', tol=1e-4, label='least_squares_bounds'),
    T('nnls([4,2;2,3], [1,2])', '[0,0.61538462]', field='x'),
    T('nnls([1,0;0,1;1,1], [1,-1,0.5])', 'optimize.nnls(np.array([[1,0],[0,1],[1,1.]]),np.array([1,-1,0.5]))[0]', field='x', label='nnls_tall'),
    T('lsq_linear([4,2;2,3], [1,2], [0, 1])', 'optimize.lsq_linear(np.array([[4,2],[2,3.]]),[1,2],bounds=(0,1)).x', field='x', tol=1e-6),
    T('isotonic_regression([1,3,2,4,3,5])', '[1,2.5,2.5,3.5,3.5,5]', field='x'),
    T('isotonic_regression([1,3,2,4,3,5])', 'optimize.isotonic_regression([1,3,2,4,3,5.]).blocks', field='blocks'),
    T('curve_fit("line", x, 2*x + 1, [1.0,1.0])', '[2,1]', field='popt', tol=1e-6),
    *[T('root_scalar("g2", [0, 2], 0, "%s")' % m, 'np.sqrt(2)', field='root', tol=1e-8, label='root_scalar_' + m) for m in ('brentq','brenth','ridder','bisect','toms748')],
    T('root_scalar("g2", [0, 2])', 'np.sqrt(2)', field='root', tol=1e-8),
    T('root_scalar("g2", 0, 1.0, "secant")', 'np.sqrt(2)', field='root', tol=1e-8, label='root_scalar_secant'),
    T('root_scalar("g2", 0, 1.0, "newton", "dg2")', 'np.sqrt(2)', field='root', tol=1e-8, label='root_scalar_newton'),
    T('fixed_point("cos", 0.5)', '0.73908513', tol=1e-6),
    *[T('root("eqs", [0, 0], "%s")' % m, 'optimize.root(lambda v:[v[0]+0.5*(v[0]-v[1])**3-1,0.5*(v[1]-v[0])**3+v[1]],[0,0]).x', field='x', tol=1e-6, label='root_' + m) for m in RM],
    T('root("cube8", [1.5], "broyden1")', '[2]', field='x', tol=1e-6, label='root_broyden1'),
    T('root("cube8", [1.5], "broyden2")', '[2]', field='x', tol=1e-6, label='root_broyden2'),
    T('root("cube8", [1.5], "krylov")', '[2]', field='x', tol=1e-6, label='root_krylov1'),
    T('root("cube8", [1.5], "anderson")', '[2]', field='x', tol=1e-6, label='root_anderson'),
    T('root("cosfix", [0.5], "excitingmixing")', '[0.73908513]', field='x', tol=1e-5, label='root_excitingmixing'),
    T('root("cosfix", [0.5], "linearmixing")', '[0.73908513]', field='x', tol=1e-5, label='root_linearmixing'),
    T('root("cosfix", [0.5], "diagbroyden")', '[0.73908513]', field='x', tol=1e-5, label='root_diagbroyden'),
    T('linprog([-1,-2], [1,1], [4], 0, 0, [0,3;0,3])', '[1,3]', field='x'),
    T('linprog([-1,-2], [1,1], [4], 0, 0, [0,3;0,3])', '-7', field='fun', label='linprog_fun'),
    T('linprog([1,1], 0, 0, [1,2], [3], [0,5;0,5])', 'optimize.linprog([1,1],A_eq=[[1,2]],b_eq=[3],bounds=[(0,5),(0,5)]).x', field='x', label='linprog_eq'),
    T('linprog([-1,-1], [1,-1], [1], 0, 0, [-1/0,1/0;-1/0,1/0])', '3', field='status', label='linprog_unbounded'),
    T('milp([-1,-2], linear_constraint([1,1], -1/0, 4), [1,1], bounds([0,0],[3,3]))', '[1,3]', field='x'),
    T('milp([-1,-1], linear_constraint([2,2], -1/0, 3), [1,1], bounds([0,0],[3,3]))', '-1', field='fun', label='milp_integer'),
    T('assignment([4,1,3;2,0,5;3,2,2])', '[0,1,2]', field='rows'),
    T('assignment([4,1,3;2,0,5;3,2,2])', '[1,0,2]', field='cols'),
    T('assignment([4,1,3;2,0,5;3,2,2], 1)', 'optimize.linear_sum_assignment([[4,1,3],[2,0,5],[3,2,2]],maximize=True)[1]', field='cols', label='assignment_max'),
    T('quadratic_assignment(unit_matrix(3), ones(3,3))', '3', field='fun'),
    T('approx_grad([1.0, 2.0], "rosen")', 'optimize.approx_fprime([1.,2.], optimize.rosen)', tol=1e-4),
    T('check_grad("rosen", "rosen_der", [1.3, 0.7]) < 1e-4', '1', label='check_grad'),
    T('rosen([1.0, 1.0])', '0'), T('rosen([1.3, 0.7, 0.8])', 'optimize.rosen([1.3,0.7,0.8])', label='rosen3'),
    T('rosen_der([1.3, 0.7])', 'optimize.rosen_der([1.3,0.7])'), T('rosen_der([1.3, 0.7, 0.8])', 'optimize.rosen_der([1.3,0.7,0.8])', label='rosen_der3'),
    T('rosen_hess([1.3, 0.7])', 'optimize.rosen_hess([1.3,0.7])'), T('rosen_hess([1.3,0.7,0.8])', 'optimize.rosen_hess([1.3,0.7,0.8])', label='rosen_hess3'),
    T('rosen_hess_prod([1.3, 0.7], [1, 0])', 'optimize.rosen_hess_prod([1.3,0.7],[1,0])'),
    # ODR
    T('odr_fit("line_b", x, 2*x + 1, [1.0, 0.0])', '[2,1]', field='beta', tol=1e-5),
    T('odr_fit("line_b", x, 2*x + 1, [1.0, 0.0], 0.1, 0.2)', '[2,1]', field='beta', tol=1e-5, label='odr_fit_errors'),
    T('odr_fit("linear", x, 2*x + 1, [1.0, 0.0])', '[2,1]', field='beta', tol=1e-5, label='odr_fit_linear'),
    T('odr_fit("poly2", x, x ^ 2)', '[0,0,1]', field='beta', tol=1e-4, label='odr_fit_poly2'),
    T('odr_fit("exponential", x, exp(0.5*x) + 1, [1.0, 0.5])', '[1,0.5]', field='beta', tol=1e-4, label='odr_fit_exponential'),
    T('odr_fit("multilinear", vstack(x, x ^ 2), 1 + 2*x + 3*x^2)', '[1,2,3]', field='beta', tol=1e-4, label='odr_fit_multilinear'),
    T('odr_fit("linear", x, 3*x + 2)', '[3,2]', field='beta', tol=1e-4, label='odr_fit_unilinear'),
    T('odr_fit("quadratic", x, x^2 + 1)', '[1,0,1]', field='beta', tol=1e-4, label='odr_fit_quadratic'),
]
