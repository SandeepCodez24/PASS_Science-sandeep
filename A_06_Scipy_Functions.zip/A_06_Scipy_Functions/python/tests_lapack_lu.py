"""Section 25, LAPACK part 1: LU of general, band and tridiagonal matrices,
triangular solvers, condition numbers, equilibration and norms. Real input is
checked against the d routine, complex input against z."""
import re as _re
from gen_tests import T

NC_SETUP = '''M = [1,2,3;4,5,6;7,8,10];
Z = [2+1i,1;1-1i,3];
R = [1,2;3,4;5,6];
ab = [0,0,0;0,2,6;1,5,10;4,8,0];
dl = [4,8];
d = [1,5,10];
du = [2,6];
'''


def PY():
    import numpy as np
    from scipy.linalg import lapack as L
    M = np.array([[1., 2, 3], [4, 5, 6], [7, 8, 10]])
    Z = np.array([[2 + 1j, 1], [1 - 1j, 3]])
    R = np.array([[1., 2], [3, 4], [5, 6]])
    ab = np.array([[0., 0, 0], [0, 2, 6], [1, 5, 10], [4, 8, 0]])
    dl = np.array([4., 8]); d = np.array([1., 5, 10]); du = np.array([2., 6])
    lu, piv, _ = L.dgetrf(M)
    zlu, zpiv, _ = L.zgetrf(Z)
    t = L.dgttrf(dl, d, du)
    return dict(L=L, np=np, M=M, Z=Z, R=R, ab=ab, dl=dl, d=d, du=du, lu=lu, piv=piv, zlu=zlu, zpiv=zpiv, gt=t)


ROWS = [
    T('lapack_getrf(M)', 'L.dgetrf(M)[0]', field='lu'),
    T('lapack_getrf(M)', 'L.dgetrf(M)[1]', field='piv'),
    T('lapack_getrf(R)', 'L.dgetrf(R)[0]', field='lu', label='lapack_getrf_rect'),
    T('lapack_getrf(Z)', 'L.zgetrf(Z)[0]', field='lu', label='lapack_getrf_c'),
    T('lapack_getrf([1,2;2,4])', 'L.dgetrf(np.array([[1.,2],[2,4]]))[2]', field='info', label='lapack_getrf_singular'),
    T('lapack_gesv(M, [1,2,3])', 'L.dgesv(M, np.array([1.,2,3]))[2]', field='x'),
    T('lapack_gesv(M, unit_matrix(3))', 'L.dgesv(M, np.eye(3))[2]', field='x', label='lapack_gesv_multi'),
    T('lapack_gesv(Z, [1,1i])', 'L.zgesv(Z, np.array([1,1j]))[2]', field='x', label='lapack_gesv_c'),
    T('lapack_getrs(lapack_getrf(M)["lu"], lapack_getrf(M)["piv"], [1,2,3])', 'L.dgetrs(lu, piv, np.array([1.,2,3]))[0]', field='x'),
    T('lapack_getrs(lapack_getrf(M)["lu"], lapack_getrf(M)["piv"], [1,2,3], 1)', 'L.dgetrs(lu, piv, np.array([1.,2,3]), trans=1)[0]', field='x', label='lapack_getrs_t'),
    T('lapack_getrs(lapack_getrf(Z)["lu"], lapack_getrf(Z)["piv"], [1,2], 2)', 'L.zgetrs(zlu, zpiv, np.array([1.,2]), trans=2)[0]', field='x', label='lapack_getrs_h'),
    T('lapack_getri(lapack_getrf(M)["lu"], lapack_getrf(M)["piv"])', 'L.dgetri(lu, piv)[0]', field='inv_a'),
    T('lapack_getri(lapack_getrf(Z)["lu"], lapack_getrf(Z)["piv"])', 'L.zgetri(zlu, zpiv)[0]', field='inv_a', label='lapack_getri_c'),
    T('lapack_getc2(M)', 'L.dgetc2(M)[0]', field='lu'),
    T('lapack_getc2(M)', 'L.dgetc2(M)[1]', field='ipiv'),
    T('lapack_getc2(M)', 'L.dgetc2(M)[2]', field='jpiv'),
    T('lapack_getc2(Z)', 'L.zgetc2(Z)[0]', field='lu', label='lapack_getc2_c'),
    T('lapack_gesc2(lapack_getc2(M)["lu"], [1,2,3], lapack_getc2(M)["ipiv"], lapack_getc2(M)["jpiv"])',
      '(lambda f: L.dgesc2(f[0], np.array([1.,2,3]), f[1], f[2])[0])(L.dgetc2(M))', field='x'),
    T('lapack_gesc2(lapack_getc2(M)["lu"], [1,2,3], lapack_getc2(M)["ipiv"], lapack_getc2(M)["jpiv"])',
      '(lambda f: L.dgesc2(f[0], np.array([1.,2,3]), f[1], f[2])[1])(L.dgetc2(M))', field='scale'),
    T('lapack_gecon(lapack_getrf(M)["lu"], 19)', 'L.dgecon(lu, 19.)[0]', field='rcond'),
    T('lapack_gecon(lapack_getrf(M)["lu"], 23, "I")', 'L.dgecon(lu, 23., norm="I")[0]', field='rcond', label='lapack_gecon_inf'),
    T('lapack_gecon(lapack_getrf(Z)["lu"], 4.5)', 'L.zgecon(zlu, 4.5)[0]', field='rcond', label='lapack_gecon_c'),
    T('lapack_geequ([1,200;0.01,3])', 'L.dgeequ(np.array([[1.,200],[0.01,3]]))[0]', field='r'),
    T('lapack_geequ([1,200;0.01,3])', 'L.dgeequ(np.array([[1.,200],[0.01,3]]))[1]', field='c'),
    T('lapack_geequ([1,200;0.01,3])', 'L.dgeequ(np.array([[1.,200],[0.01,3]]))[2]', field='rowcnd'),
    T('lapack_geequ([1,200;0.01,3])', 'L.dgeequ(np.array([[1.,200],[0.01,3]]))[3]', field='colcnd'),
    T('lapack_geequ(Z)', 'L.zgeequ(Z)[0]', field='r', label='lapack_geequ_c'),
    T('lapack_geequb([1,200;0.01,3])', 'L.dgeequb(np.array([[1.,200],[0.01,3]]))[0]', field='r'),
    T('lapack_geequb([1,200;0.01,3])', 'L.dgeequb(np.array([[1.,200],[0.01,3]]))[1]', field='c'),
    T('lapack_geequb([1,200;0.01,3])', 'L.dgeequb(np.array([[1.,200],[0.01,3]]))[4]', field='amax'),
    T('lapack_gesvx(M, [1,2,3])', 'L.dgesvx(M, np.array([1.,2,3]))[7]', field='x'),
    T('lapack_gesvx(M, [1,2,3])', 'L.dgesvx(M, np.array([1.,2,3]))[8]', field='rcond', tol=1e-6),
    T('lapack_gesvx([1,200;0.01,3], [1,2])', 'L.dgesvx(np.array([[1.,200],[0.01,3]]), np.array([1.,2]))[7]', field='x', label='lapack_gesvx_eq'),
    T('lapack_gesvx([1,200;0.01,3], [1,2])', '=' + 'B', field='equed', label='lapack_gesvx_equed'),
    T('lapack_gesvx(M, [1,2,3], "N", "T")', 'L.dgesvx(M, np.array([1.,2,3]), fact="N", trans="T")[7]', field='x', label='lapack_gesvx_t'),
    T('lapack_gesvx(Z, [1,1i])', 'L.zgesvx(Z, np.array([1,1j]))[7]', field='x', label='lapack_gesvx_c'),
    T('lapack_laswp(M, [2,2])', 'L.dlaswp(M, np.array([2,2]))'),
    T('lapack_laswp(M, [1,2,2], 1, 2)', 'L.dlaswp(M, np.array([1,2,2]), k1=1, k2=2)', label='lapack_laswp_k'),
    T('lapack_lange("1", M)', 'L.dlange("1", M)'),
    T('lapack_lange("I", M)', 'L.dlange("I", M)', label='lapack_lange_i'),
    T('lapack_lange("F", Z)', 'L.zlange("F", Z)', label='lapack_lange_f'),
    T('lapack_lange("M", M)', 'L.dlange("M", M)', label='lapack_lange_m'),
    T('lapack_lantr("1", M)', 'L.dlantr("1", M)'),
    T('lapack_lantr("I", M, "L", "U")', 'L.dlantr("I", M, uplo="L", diag="U")', label='lapack_lantr_lu'),
    T('lapack_langb("1", 1, 1, [0,2,6;1,5,10;4,8,0])', 'L.dlangb("1", 1, 1, np.array([[0.,2,6],[1,5,10],[4,8,0]]))'),
    T('lapack_langb("F", 1, 1, [0,2,6;1,5,10;4,8,0])', 'L.dlangb("F", 1, 1, np.array([[0.,2,6],[1,5,10],[4,8,0]]))', label='lapack_langb_f'),
    T('lapack_gbtrf(ab, 1, 1)', 'L.dgbtrf(ab, 1, 1)[0]', field='lu'),
    T('lapack_gbtrf(ab, 1, 1)', 'L.dgbtrf(ab, 1, 1)[1]', field='ipiv'),
    T('lapack_gbtrs(lapack_gbtrf(ab,1,1)["lu"], 1, 1, [1,2,3], lapack_gbtrf(ab,1,1)["ipiv"])',
      '(lambda f: L.dgbtrs(f[0], 1, 1, np.array([1.,2,3]), f[1])[0])(L.dgbtrf(ab, 1, 1))', field='x'),
    T('lapack_gbtrs(lapack_gbtrf(ab,1,1)["lu"], 1, 1, [1,2,3], lapack_gbtrf(ab,1,1)["ipiv"], 1)',
      '(lambda f: L.dgbtrs(f[0], 1, 1, np.array([1.,2,3]), f[1], trans=1)[0])(L.dgbtrf(ab, 1, 1))', field='x', label='lapack_gbtrs_t'),
    T('lapack_gbsv(1, 1, ab, [1,2,3])', 'L.dgbsv(1, 1, ab, np.array([1.,2,3]))[2]', field='x'),
    T('lapack_gbsv(1, 1, ab, [1,2,3])', 'L.dgbsv(1, 1, ab, np.array([1.,2,3]))[0]', field='lub'),
    T('lapack_gbcon(1, 1, lapack_gbtrf(ab,1,1)["lu"], lapack_gbtrf(ab,1,1)["ipiv"], 16)',
      '(lambda f: L.dgbcon(1, 1, f[0], f[1], 16.)[0])(L.dgbtrf(ab, 1, 1))', field='rcond'),
    T('lapack_gtsv(dl, d, du, [1,2,3])', 'L.dgtsv(dl, d, du, np.array([1.,2,3]))[3]', field='x'),
    T('lapack_gtsv(dl, d, du, [1,2,3])', 'L.dgtsv(dl, d, du, np.array([1.,2,3]))[1]', field='d'),
    T('lapack_gtsv([1+1i,2], [3,1,4], [1,1i], [1,2,3])', 'L.zgtsv(np.array([1+1j,2]), np.array([3.,1,4]), np.array([1,1j]), np.array([1.,2,3]))[3]', field='x', label='lapack_gtsv_c'),
    T('lapack_gttrf(dl, d, du)', 'L.dgttrf(dl, d, du)[0]', field='dl'),
    T('lapack_gttrf(dl, d, du)', 'L.dgttrf(dl, d, du)[1]', field='d'),
    T('lapack_gttrf(dl, d, du)', 'L.dgttrf(dl, d, du)[2]', field='du'),
    T('lapack_gttrf(dl, d, du)', 'L.dgttrf(dl, d, du)[3]', field='du2'),
    T('lapack_gttrf(dl, d, du)', 'L.dgttrf(dl, d, du)[4]', field='ipiv'),
    T('gtf(lapack_gttrf(dl, d, du), [1,2,3], "N")', 'L.dgttrs(*gt[:5], np.array([1.,2,3]))[0]', label='lapack_gttrs',
      setup='function y = gtf(f, b, t):\n  y = lapack_gttrs(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], b, t)["x"];\nfnend'),
    T('gtf(lapack_gttrf(dl, d, du), [1,2,3], "T")', 'L.dgttrs(*gt[:5], np.array([1.,2,3]), trans="T")[0]', label='lapack_gttrs_t',
      setup='function y = gtf(f, b, t):\n  y = lapack_gttrs(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], b, t)["x"];\nfnend'),
    T('gtc(lapack_gttrf(dl, d, du), 16)', 'L.dgtcon(*gt[:5], 16.)[0]', label='lapack_gtcon',
      setup='function y = gtc(f, an):\n  y = lapack_gtcon(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], an)["rcond"];\nfnend'),
    T('lapack_gtsvx(dl, d, du, [1,2,3])', 'L.dgtsvx(dl, d, du, np.array([1.,2,3]))[5]', field='x'),
    T('lapack_gtsvx(dl, d, du, [1,2,3])', 'L.dgtsvx(dl, d, du, np.array([1.,2,3]))[6]', field='rcond'),
    T('lapack_gtsvx(dl, d, du, [1,2,3], "N", "T")', 'L.dgtsvx(dl, d, du, np.array([1.,2,3]), trans="T")[5]', field='x', label='lapack_gtsvx_t'),
    T('lapack_trtri(M)', 'L.dtrtri(M)[0]', field='inv_c'),
    T('lapack_trtri(M, 1, 1)', 'L.dtrtri(M, lower=1, unitdiag=1)[0]', field='inv_c', label='lapack_trtri_lu'),
    T('lapack_trtri(Z, 1)', 'L.ztrtri(Z, lower=1)[0]', field='inv_c', label='lapack_trtri_c'),
    T('lapack_trtrs(M, [1,2,3])', 'L.dtrtrs(M, np.array([1.,2,3]))[0]', field='x'),
    T('lapack_trtrs(M, [1,2,3], 1, 1)', 'L.dtrtrs(M, np.array([1.,2,3]), lower=1, trans=1)[0]', field='x', label='lapack_trtrs_lt'),
    T('lapack_trtrs([1,2;0,0], [1,2])', 'L.dtrtrs(np.array([[1.,2],[0,0]]), np.array([1.,2]))[1]', field='info', label='lapack_trtrs_singular'),
    T('lapack_trcon(M)', 'L.dtrcon(M)[0]', field='rcond'),
    T('lapack_trcon(M, "I", "L")', 'L.dtrcon(M, norm="I", uplo="L")[0]', field='rcond', label='lapack_trcon_li'),
    T('lapack_tbtrs([0,2,6;1,5,10], [1,2,3])', 'L.dtbtrs(np.array([[0.,2,6],[1,5,10]]), np.array([1.,2,3]))[0]', field='x'),
    T('lapack_tbtrs([1,5,10;4,8,0], [1,2,3], "L", "T")', 'L.dtbtrs(np.array([[1.,5,10],[4,8,0]]), np.array([1.,2,3]), uplo="L", trans="T")[0]', field='x', label='lapack_tbtrs_lt'),
    T('lapack_lauum(M)', 'L.dlauum(M)[0]', field='a'),
    T('lapack_lauum(M, 1)', 'L.dlauum(M, lower=1)[0]', field='a', label='lapack_lauum_l'),
    T('lapack_lauum(Z)', 'L.zlauum(Z)[0]', field='a', label='lapack_lauum_c'),
    T('lapack_lamch("E")', 'L.dlamch("E")'),
    T('lapack_lamch("P")', 'L.dlamch("P")', label='lapack_lamch_p'),
    T('lapack_lamch("S")', 'L.dlamch("S")', label='lapack_lamch_s', tol=0),
    T('lapack_lamch("O")', 'L.dlamch("O")', label='lapack_lamch_o'),
    T('lapack_ilaver()', 'L.ilaver()[0]', field='major'),
    T('lapack_ilaver()', 'L.ilaver()[1]', field='minor'),
    # direct calls (the rows above go through small helper functions)
    T('lapack_gttrs(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], [1,2,3])', 'L.dgttrs(*gt[:5], np.array([1.,2,3]))[0]', field='x', label='lapack_gttrs_direct', setup='f = lapack_gttrf(dl, d, du);'),
    T('lapack_gttrs(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], [1,2,3], "T")', 'L.dgttrs(*gt[:5], np.array([1.,2,3]), trans="T")[0]', field='x', label='lapack_gttrs_direct_t', setup='f = lapack_gttrf(dl, d, du);'),
    T('lapack_gtcon(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], 16)', 'L.dgtcon(*gt[:5], 16.)[0]', field='rcond', label='lapack_gtcon_direct', setup='f = lapack_gttrf(dl, d, du);'),
    T('lapack_gtcon(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], 16, "I")', 'L.dgtcon(*gt[:5], 16., norm="I")[0]', field='rcond', label='lapack_gtcon_direct_i', setup='f = lapack_gttrf(dl, d, du);'),
]

# SciPy's LAPACK writes into its inputs; give every row fresh copies.
for _t in ROWS:
    if isinstance(_t.py, str) and not _t.py.startswith('='):
        _t.py = _re.sub(r'(?<![\w.\'"])(M|Z|R|ab|dl|d|du|lu|piv|zlu|zpiv)\b(?!\s*=)', r'\1.copy()', _t.py)
