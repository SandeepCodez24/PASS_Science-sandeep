"""Section 25, LAPACK part 2: positive definite matrices in full, band, packed,
RFP and tridiagonal storage, the pivoted Cholesky, and the storage conversions."""
import re as _re
from gen_tests import T

NC_SETUP = '''P = [4,2,1;2,5,3;1,3,6];
H = [4,1+1i;1-1i,3];
ap = [4,2,5,1,3,6];
apl = [4,2,1,5,3,6];
pb = [0,2,3;4,5,6];
pbl = [4,5,6;2,3,0];
W = [1,2,3,4;5,6,7,8;9,10,11,12;13,14,15,16];
Q = [1,2,3,4,5;6,7,8,9,10;11,12,13,14,15;16,17,18,19,20;21,22,23,24,25];
'''


def PY():
    import numpy as np
    from scipy.linalg import lapack as L
    P = np.array([[4., 2, 1], [2, 5, 3], [1, 3, 6]])
    H = np.array([[4, 1 + 1j], [1 - 1j, 3]])
    ap = np.array([4., 2, 5, 1, 3, 6]); apl = np.array([4., 2, 1, 5, 3, 6])
    pb = np.array([[0., 2, 3], [4, 5, 6]]); pbl = np.array([[4., 5, 6], [2, 3, 0]])
    W = np.arange(1., 17).reshape(4, 4); Q = np.arange(1., 26).reshape(5, 5)
    c = L.dpotrf(P)[0]
    return dict(L=L, np=np, P=P, H=H, ap=ap, apl=apl, pb=pb, pbl=pbl, W=W, Q=Q, c=c)


ROWS = [
    T('lapack_potrf(P)', 'L.dpotrf(P)[0]', field='c'),
    T('lapack_potrf(P, 1)', 'L.dpotrf(P, lower=1)[0]', field='c', label='lapack_potrf_lower'),
    T('lapack_potrf(P, 0, 0)', 'L.dpotrf(P, clean=0)[0]', field='c', label='lapack_potrf_noclean'),
    T('lapack_potrf(H)', 'L.zpotrf(H)[0]', field='c', label='lapack_potrf_c'),
    T('lapack_potrf([1,2;2,1])', 'L.dpotrf(np.array([[1.,2],[2,1]]))[1]', field='info', label='lapack_potrf_notpd'),
    T('lapack_potrs(lapack_potrf(P)["c"], [1,2,3])', 'L.dpotrs(c, np.array([1.,2,3]))[0]', field='x'),
    T('lapack_potrs(lapack_potrf(P, 1)["c"], [1,2,3], 1)', 'L.dpotrs(L.dpotrf(P, lower=1)[0], np.array([1.,2,3]), lower=1)[0]', field='x', label='lapack_potrs_lower'),
    T('lapack_potri(lapack_potrf(P)["c"])', 'L.dpotri(c)[0]', field='inv_a'),
    T('lapack_potri(lapack_potrf(H)["c"])', 'L.zpotri(L.zpotrf(H)[0])[0]', field='inv_a', label='lapack_potri_c'),
    T('lapack_posv(P, [1,2,3])', 'L.dposv(P, np.array([1.,2,3]))[1]', field='x'),
    T('lapack_posv(P, [1,2,3])', 'L.dposv(P, np.array([1.,2,3]))[0]', field='c', label='lapack_posv_c'),
    T('lapack_posv(H, [1,1i], 1)', 'L.zposv(H, np.array([1,1j]), lower=1)[1]', field='x', label='lapack_posv_z'),
    T('lapack_pocon(lapack_potrf(P)["c"], 9)', 'L.dpocon(c, 9.)[0]', field='rcond'),
    T('lapack_posvx(P, [1,2,3])', 'L.dposvx(P, np.array([1.,2,3]))[5]', field='x'),
    T('lapack_posvx(P, [1,2,3])', 'L.dposvx(P, np.array([1.,2,3]))[6]', field='rcond'),
    T('lapack_posvx([100,1;1,0.01], [1,2])', 'L.dposvx(np.array([[100.,1],[1,0.01]]), np.array([1.,2]))[5]', field='x', label='lapack_posvx_eq'),
    T('lapack_posvx([100,1;1,0.01], [1,2])', '=Y', field='equed', label='lapack_posvx_equed'),
    T('lapack_pbtrf(pb)', 'L.dpbtrf(pb)[0]', field='c'),
    T('lapack_pbtrf(pbl, 1)', 'L.dpbtrf(pbl, lower=1)[0]', field='c', label='lapack_pbtrf_lower'),
    T('lapack_pbtrs(lapack_pbtrf(pb)["c"], [1,2,3])', 'L.dpbtrs(L.dpbtrf(pb)[0], np.array([1.,2,3]))[0]', field='x'),
    T('lapack_pbsv(pb, [1,2,3])', 'L.dpbsv(pb, np.array([1.,2,3]))[1]', field='x'),
    T('lapack_pbsv(pbl, [1,2,3], 1)', 'L.dpbsv(pbl, np.array([1.,2,3]), lower=1)[1]', field='x', label='lapack_pbsv_lower'),
    T('lapack_pptrf(3, ap)', 'L.dpptrf(3, ap)[0]', field='ul'),
    T('lapack_pptrf(3, apl, 1)', 'L.dpptrf(3, apl, lower=1)[0]', field='ul', label='lapack_pptrf_lower'),
    T('lapack_pptrs(3, lapack_pptrf(3, ap)["ul"], [1,2,3])', 'L.dpptrs(3, L.dpptrf(3, ap)[0], np.array([1.,2,3]))[0]', field='x'),
    T('lapack_pptri(3, lapack_pptrf(3, ap)["ul"])', 'L.dpptri(3, L.dpptrf(3, ap)[0])[0]', field='uli'),
    T('lapack_ppsv(3, ap, [1,2,3])', 'L.dppsv(3, ap, np.array([1.,2,3]))[0]', field='x'),
    T('lapack_ppcon(3, lapack_pptrf(3, ap)["ul"], 9)', 'L.dppcon(3, L.dpptrf(3, ap)[0], 9.)[0]', field='rcond'),
    T('lapack_pstrf(P)', 'L.dpstrf(P)[0]', field='c'),
    T('lapack_pstrf(P)', 'L.dpstrf(P)[1]', field='piv'),
    T('lapack_pstrf(P, -1, 1)', 'L.dpstrf(P, lower=1)[0]', field='c', label='lapack_pstrf_lower'),
    T('lapack_pstrf([1,1,1;1,1,1;1,1,2])', 'L.dpstrf(np.array([[1.,1,1],[1,1,1],[1,1,2]]))[2]', field='rank_c', label='lapack_pstrf_rank'),
    T('lapack_pstrf(H)', 'L.zpstrf(H)[0]', field='c', label='lapack_pstrf_c'),
    T('lapack_pstf2(P)', 'L.dpstf2(P)[0]', field='c'),
    T('lapack_pstf2(P)', 'L.dpstf2(P)[1]', field='piv'),
    T('lapack_pttrf([4,5,6], [1,2])', 'L.dpttrf(np.array([4.,5,6]), np.array([1.,2]))[0]', field='d'),
    T('lapack_pttrf([4,5,6], [1,2])', 'L.dpttrf(np.array([4.,5,6]), np.array([1.,2]))[1]', field='e'),
    T('lapack_pttrf([4,5,6], [1+1i,2])', 'L.zpttrf(np.array([4.,5,6]), np.array([1+1j,2]))[1]', field='e', label='lapack_pttrf_c'),
    T('lapack_pttrs([4,4.75,5.157894736842105], [0.25,0.42105263157894735], [1,2,3])', 'L.dpttrs(np.array([4,4.75,5.157894736842105]), np.array([0.25,0.42105263157894735]), np.array([1.,2,3]))[0]', field='x'),
    T('lapack_pttrs([4,4.5], [0.25+0.25i], [1,2])', 'L.zpttrs(np.array([4,4.5]), np.array([0.25+0.25j]), np.array([1.,2]))[0]', field='x', label='lapack_pttrs_c'),
    T('lapack_pttrs([4,4.5], [0.25+0.25i], [1,2], 1)', 'L.zpttrs(np.array([4,4.5]), np.array([0.25+0.25j]), np.array([1.,2]), lower=1)[0]', field='x', label='lapack_pttrs_cl'),
    T('lapack_ptsv([4,5,6], [1,2], [1,2,3])', 'L.dptsv(np.array([4.,5,6]), np.array([1.,2]), np.array([1.,2,3]))[2]', field='x'),
    T('lapack_ptsv([4,5,6], [1+1i,2], [1,2,3])', 'L.zptsv(np.array([4.,5,6]), np.array([1+1j,2]), np.array([1.,2,3]))[2]', field='x', label='lapack_ptsv_c'),
    T('lapack_ptsvx([4,5,6], [1,2], [1,2,3])', 'L.dptsvx(np.array([4.,5,6]), np.array([1.,2]), np.array([1.,2,3]))[2]', field='x'),
    T('lapack_ptsvx([4,5,6], [1,2], [1,2,3])', 'L.dptsvx(np.array([4.,5,6]), np.array([1.,2]), np.array([1.,2,3]))[3]', field='rcond'),
    T('lapack_pteqr([4,5,6], [1,2], unit_matrix(3))', 'L.dpteqr(np.array([4.,5,6]), np.array([1.,2]), np.eye(3))[0]', field='d'),
    T('abs(lapack_pteqr([4,5,6], [1,2], unit_matrix(3), 2)["z"])', 'np.abs(L.dpteqr(np.array([4.,5,6]), np.array([1.,2]), np.eye(3), compute_z=2)[2])', label='lapack_pteqr_z'),
    T('lapack_trttf(W)', 'L.dtrttf(W)[0]', field='arf'),
    T('lapack_trttf(W, "T", "L")', 'L.dtrttf(W, transr="T", uplo="L")[0]', field='arf', label='lapack_trttf_tl'),
    T('lapack_trttf(Q, "N", "L")', 'L.dtrttf(Q, uplo="L")[0]', field='arf', label='lapack_trttf_odd'),
    T('lapack_trttf(H, "C", "U")', 'L.ztrttf(H, transr="C")[0]', field='arf', label='lapack_trttf_c'),
    T('lapack_tfttr(4, lapack_trttf(W)["arf"])', 'L.dtfttr(4, L.dtrttf(W)[0])[0]', field='a'),
    T('lapack_tfttr(5, lapack_trttf(Q, "T", "L")["arf"], "T", "L")', 'L.dtfttr(5, L.dtrttf(Q, transr="T", uplo="L")[0], transr="T", uplo="L")[0]', field='a', label='lapack_tfttr_tl'),
    T('lapack_trttp(W)', 'L.dtrttp(W)[0]', field='ap'),
    T('lapack_trttp(W, "L")', 'L.dtrttp(W, uplo="L")[0]', field='ap', label='lapack_trttp_l'),
    T('lapack_tpttr(3, ap)', 'L.dtpttr(3, ap)[0]', field='a'),
    T('lapack_tpttf(3, ap)', 'L.dtpttf(3, ap)[0]', field='arf'),
    T('lapack_tpttf(3, apl, "T", "L")', 'L.dtpttf(3, apl, transr="T", uplo="L")[0]', field='arf', label='lapack_tpttf_tl'),
    T('lapack_tfttp(3, lapack_tpttf(3, ap)["arf"])', 'L.dtfttp(3, L.dtpttf(3, ap)[0])[0]', field='ap'),
    T('lapack_pftrf(3, lapack_tpttf(3, ap)["arf"])', 'L.dpftrf(3, L.dtpttf(3, ap)[0])[0]', field='achol'),
    T('lapack_pftrf(3, lapack_tpttf(3, apl, "N", "L")["arf"], "N", "L")', 'L.dpftrf(3, L.dtpttf(3, apl, uplo="L")[0], uplo="L")[0]', field='achol', label='lapack_pftrf_l'),
    T('lapack_pftri(3, lapack_pftrf(3, lapack_tpttf(3, ap)["arf"])["achol"])', 'L.dpftri(3, L.dpftrf(3, L.dtpttf(3, ap)[0])[0])[0]', field='ainv'),
    T('lapack_pftrs(3, lapack_pftrf(3, lapack_tpttf(3, ap)["arf"])["achol"], [1,2,3])', 'L.dpftrs(3, L.dpftrf(3, L.dtpttf(3, ap)[0])[0], np.array([[1.],[2],[3]]))[0]', field='x'),
    T('lapack_tfsm(2, lapack_tpttf(3, ap)["arf"], [1,2;3,4;5,6])', 'L.dtfsm(2., L.dtpttf(3, ap)[0], np.array([[1.,2],[3,4],[5,6]]))'),
    T('lapack_tfsm(1, lapack_tpttf(3, ap)["arf"], [1,2,3;4,5,6], "N", "R", "U", "T")', 'L.dtfsm(1., L.dtpttf(3, ap)[0], np.array([[1.,2,3],[4,5,6]]), side="R", trans="T")', label='lapack_tfsm_right'),
    T('lapack_sfrk(3, 2, 1, [1,2;3,4;5,6], 0, [0,0,0,0,0,0])', 'L.dsfrk(3, 2, 1., np.array([[1.,2],[3,4],[5,6]]), 0., np.zeros(6))'),
    T('lapack_sfrk(3, 2, 2, [1,2,3;4,5,6], 1, lapack_tpttf(3, ap)["arf"], "N", "U", "T")', 'L.dsfrk(3, 2, 2., np.array([[1.,2,3],[4,5,6]]), 1., L.dtpttf(3, ap)[0], trans="T")', label='lapack_sfrk_t'),
    T('lapack_hfrk(2, 2, 1, [1,1i;2,3], 0, [0,0,0])', 'L.zhfrk(2, 2, 1., np.array([[1,1j],[2,3]]), 0., np.zeros(3, complex))'),
]

for _t in ROWS:
    if isinstance(_t.py, str) and not _t.py.startswith('='):
        _t.py = _re.sub(r'(?<![\w.\'"])(P|H|ap|apl|pb|pbl|W|Q|c)\b(?!\s*=)', r'\1.copy()', _t.py)
