from gen_tests import T

# Needs the network the first time (nc.exe keeps the files in its cache afterwards).
NC_SETUP = ''

def PY():
    import bz2, io, os, pickle, tempfile, urllib.request
    import numpy as np
    cache = os.path.join(tempfile.gettempdir(), 'nc_scipy_datasets')
    os.makedirs(cache, exist_ok=True)
    def get(name):
        path = os.path.join(cache, name + '.dat')
        if not os.path.exists(path):
            urllib.request.urlretrieve('https://raw.githubusercontent.com/scipy/dataset-%s/main/%s.dat' % (name, name), path)
        return open(path, 'rb').read()
    ascent = np.array(pickle.loads(get('ascent')))
    ecg = (np.load(io.BytesIO(get('ecg')))['ecg'].astype(int) - 1024) / 200.0
    face = np.frombuffer(bz2.decompress(get('face')), dtype='uint8').reshape((768, 1024, 3))
    gray = (0.21 * face[:,:,0] + 0.71 * face[:,:,1] + 0.07 * face[:,:,2]).astype('uint8')
    return dict(np=np, ascent=ascent, ecg=ecg, face=face, gray=gray)

ROWS = [
    T('dataset_ascent()[100:103,200:203]', 'ascent[100:104,200:204]', label='dataset_ascent'),
    T('size(dataset_ascent())', '[512,512]', label='dataset_ascent_size'),
    T('dataset_ecg()[1000:1009]', 'ecg[1000:1010]', label='dataset_ecg'),
    T('numel(dataset_ecg())', 'ecg.size', label='dataset_ecg_size'),
    T('dataset_face(1)[300:302,500:503]', 'gray[300:303,500:504]', label='dataset_face_gray'),
    T('dataset_face()["g"][767,1020:1023]', 'face[767,1020:1024,1]', label='dataset_face'),
    T('dataset_download_all("data/ds_all")', None, label='dataset_download_all'),
    T('dataset_clear_cache(["ascent"])', None, label='dataset_clear_cache'),
]
