# Writes the self-checking test scripts of src/test/scipy from tests_*.py tables.
#
# Every row is T(nc_expression, python_expression): the expected value is computed
# here with real SciPy and written as a literal into the .nc file, so the scripts
# need only nc.exe to run. A row without a Python expression only checks that the
# call runs. Run with a Python that has numpy and scipy:
#     python gen_tests.py               regenerates every .nc file
#     python gen_tests.py --run NCEXE   also runs each row alone and lists failures
import concurrent.futures, importlib, os, re, subprocess, sys, tempfile
import numpy as np, scipy
from scipy import cluster, constants, fft, fftpack, integrate, interpolate, linalg, ndimage, optimize, signal, sparse, spatial
from scipy.signal import windows

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.dirname(HERE)  # the .nc scripts and data/ live one folder up

CHECK = '''# Test helper: compares shape-free values element by element.
function chk(name, got, want, tol):
  g = flatten(got * 1);
  w = flatten(want * 1);
  if numel(g) != numel(w):
    print("FAIL " + name + ": " + str(numel(g)) + " values, expected " + str(numel(w)));
    return;
  iend
  bad = 0;
  for k = [0:numel(g)-1]:
    if isnan(real(w[k])):
      if isnan(real(g[k])) == 0:
        bad = bad + 1;
      iend
    elseif abs(real(w[k])) == inf:
      if real(g[k]) != real(w[k]):
        bad = bad + 1;
      iend
    elseif abs(g[k] - w[k]) > tol * (1 + abs(w[k])):
      bad = bad + 1;
    iend
  fend
  if bad > 0:
    print("FAIL " + name + ": " + str(bad) + " of " + str(numel(g)) + " values differ");
  else:
    print("PASS " + name);
  iend
fnend

function chk_text(name, got, want):
  if got == want:
    print("PASS " + name);
  else:
    print("FAIL " + name + ": got " + str(got) + ", expected " + str(want));
  iend
fnend
'''

def num(v):
    if isinstance(v, (bool, np.bool_)):
        return '1' if v else '0'
    v = complex(v)
    def r(x):
        if np.isnan(x): return '(0/0)'
        if np.isinf(x): return '(1/0)' if x > 0 else '(-1/0)'
        return repr(float(x))
    if v.imag == 0:
        return r(v.real)
    return '%s%s%si' % (r(v.real), '+' if v.imag >= 0 else '-', repr(abs(float(v.imag))))

def literal(v):
    if isinstance(v, (tuple, list)):
        v = np.asarray(v)
    if sparse.issparse(v):
        v = v.toarray()
    if np.isscalar(v) or (isinstance(v, np.ndarray) and v.ndim == 0):
        return num(v)
    v = np.asarray(v)
    if v.ndim > 2:
        v = np.squeeze(v)
        if v.ndim > 2:
            v = v.reshape(-1, v.shape[-1])
    if v.ndim == 0:
        return num(v)
    if v.ndim == 1:
        return '[' + ','.join(num(x) for x in v) + ']'
    return '[' + ';'.join(','.join(num(x) for x in row) for row in v) + ']'

class T:
    def __init__(self, nc, py=None, field=None, tol=1e-7, label=None, setup=''):
        self.nc, self.py, self.field, self.tol, self.setup = nc, py, field, tol, setup
        m = re.match(r'\s*([A-Za-z_]\w*)', nc)
        self.label = label or (m.group(1) if m else nc)
        if field:
            self.label += '.' + field

def env():
    x = np.linspace(0, 10, 11)
    e = dict(np=np, scipy=scipy, cluster=cluster, constants=constants, fft=fft, fftpack=fftpack, integrate=integrate,
             interpolate=interpolate, linalg=linalg, ndimage=ndimage, optimize=optimize, signal=signal, sparse=sparse,
             spatial=spatial, windows=windows, x=x, y=np.sin(x), A=np.array([[4., 2.], [2., 3.]]), b=np.array([1., 2.]),
             S=sparse.csr_array([[4., 1., 0.], [1., 3., 0.], [0., 0., 2.]]), pi=np.pi)
    return e

def statements(t, want):
    lines = []
    if t.setup:
        lines.append(t.setup)
    if want is None:
        if t.field:
            lines.append('r = %s;' % t.nc)
            lines.append('v = r["%s"];' % t.field)
        else:
            lines.append('r = %s;' % t.nc)
        lines.append('print("PASS %s");' % t.label)
    elif isinstance(want, str):
        lines.append('r = %s;' % t.nc)
        got = 'r["%s"]' % t.field if t.field else 'r'
        lines.append('chk_text("%s", %s, "%s");' % (t.label, got, want))
    else:
        lines.append('r = %s;' % t.nc)
        got = 'r["%s"]' % t.field if t.field else 'r'
        lines.append('chk("%s", %s, %s, %g);' % (t.label, got, literal(want), t.tol))
    return lines

def build(mod):
    e = env()
    e.update(getattr(mod, 'PY', lambda: {})())
    rows = []
    for t in mod.ROWS:
        want = None
        if t.py is not None:
            try:
                want = eval(t.py, e) if isinstance(t.py, str) and not t.py.startswith('=') else (t.py[1:] if isinstance(t.py, str) else t.py)
            except Exception as ex:
                raise RuntimeError('row %s: %s' % (t.label, ex))
        rows.append((t, statements(t, want)))
    return rows

def run_one(args):
    nc, preamble, t, lines = args
    with tempfile.NamedTemporaryFile('w', suffix='.nc', delete=False, encoding='utf-8') as f:
        f.write(preamble + '\n' + '\n'.join(lines) + '\n')
        p = f.name
    try:
        r = subprocess.run([nc, p], cwd=OUT, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
        out = (r.stdout + r.stderr).strip()
    except subprocess.TimeoutExpired:
        out = 'TIMEOUT'
    os.unlink(p)
    return t.label, out

def main():
    sys.path.insert(0, HERE)
    only = None
    nc = None
    args = sys.argv[1:]
    if '--run' in args:
        i = args.index('--run')
        nc = args[i + 1]
        del args[i:i + 2]
    if args:
        only = args
    total = bad = 0
    for fn in sorted(os.listdir(HERE)):
        if not (fn.startswith('tests_') and fn.endswith('.py')):
            continue
        name = fn[6:-3]
        if only and name not in only:
            continue
        mod = importlib.import_module(fn[:-3])
        rows = build(mod)
        pre = CHECK + '\n' + getattr(mod, 'NC_SETUP', '')
        with open(os.path.join(OUT, name + '.nc'), 'w', encoding='utf-8', newline='\n') as f:
            f.write('# %s: every function of this section, checked against SciPy %s.\n# Generated by python/gen_tests.py. Run: nc.exe %s.nc\n\n' % (name, scipy.__version__, name))
            f.write(pre + '\n')
            for t, lines in rows:
                f.write('\n'.join(lines) + '\n')
        if nc:
            with concurrent.futures.ThreadPoolExecutor(12) as ex:
                res = list(ex.map(run_one, [(nc, pre, t, lines) for t, lines in rows]))
            for label, out in res:
                total += 1
                ok = 'PASS' in out and 'FAIL' not in out and 'Error' not in out
                if not ok:
                    bad += 1
                    print('[%s] %s: %s' % (name, label, out[:400]))
    if nc:
        print('rows: %d, not passing: %d' % (total, bad))

if __name__ == '__main__':
    main()
