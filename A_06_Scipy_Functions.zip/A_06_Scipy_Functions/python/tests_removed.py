"""Appendix A (removed since SciPy 1.8). The removed functions are not in
SciPy 1.18, so the expected values come from their last source, copied below
(signal.cwt / ricker / morlet / morlet2 / daub / qmf / cascade, misc.derivative
replaced by scipy.differentiate.derivative), or from the replacement SciPy names."""
import numpy as np
from gen_tests import T


def _ricker(points, a):
    A = 2 / (np.sqrt(3 * a) * (np.pi ** 0.25))
    vec = np.arange(0, points) - (points - 1.0) / 2
    return A * (1 - vec ** 2 / a ** 2) * np.exp(-vec ** 2 / (2 * a ** 2))


def _morlet2(M, s, w=5):
    x = np.arange(0, M) - (M - 1.0) / 2
    x = x / s
    return np.exp(1j * w * x) * np.exp(-0.5 * x ** 2) * np.pi ** (-0.25) * np.sqrt(1 / s)


def _cwt(data, wavelet, widths):
    dtype = np.complex128 if wavelet is _morlet2 else np.float64
    out = np.empty((len(widths), len(data)), dtype=dtype)
    for ind, width in enumerate(widths):
        N = np.min([10 * width, len(data)])
        wd = np.conj(wavelet(int(N), width)[::-1])
        out[ind] = np.convolve(data, wd, mode='same')
    return out


def _daub(p):
    from scipy.special import comb
    sqrt = np.sqrt
    if p == 1:
        c = 1 / sqrt(2)
        return np.array([c, c])
    if p == 2:
        f = sqrt(2) / 8
        c = sqrt(3)
        return f * np.array([1 + c, 3 + c, 3 - c, 1 - c])
    if p == 3:
        tmp = 12 * sqrt(10)
        z1 = 1.5 + sqrt(15 + tmp) / 6 - 1j * (sqrt(15) + sqrt(tmp - 15)) / 6
        z1c = np.conj(z1)
        f = sqrt(2) / 8
        d0 = np.real((1 - z1) * (1 - z1c))
        a0 = np.real(z1 * z1c)
        a1 = 2 * np.real(z1)
        return f / d0 * np.array([a0, 3 * a0 - a1, 3 * a0 - 3 * a1 + 1, a0 - 3 * a1 + 3, 3 - a1, 1])
    P = [comb(p - 1 + k, k, exact=1) for k in range(p)][::-1]
    yj = np.roots(P)
    c = np.poly1d([1, 1]) ** p
    q = np.poly1d([1])
    for k in range(p - 1):
        yval = yj[k]
        part = 2 * sqrt(yval * (yval - 1))
        const = 1 - 2 * yval
        z1 = const + part
        if (abs(z1)) < 1:
            z1 = const - part
        q = q * [1, -z1]
    q = c * np.real(q)
    q = q / np.sum(q) * sqrt(2)
    return q.c[::-1]


def _qmf(hk):
    N = len(hk) - 1
    asgn = [{0: 1, 1: -1}[k % 2] for k in range(N + 1)]
    return hk[::-1] * np.array(asgn)


def _cascade(hk, J=7):
    from scipy.linalg import eig
    N = len(hk) - 1
    nn, kk = np.ogrid[:N, :N]
    s2 = np.sqrt(2)
    thk = np.r_[hk, 0]
    gk = _qmf(hk)
    tgk = np.r_[gk, 0]
    indx1 = np.clip(2 * nn - kk, -1, N + 1)
    indx2 = np.clip(2 * nn - kk + 1, -1, N + 1)
    m = np.empty((2, 2, N, N), 'd')
    m[0, 0] = np.take(thk, indx1, 0)
    m[0, 1] = np.take(thk, indx2, 0)
    m[1, 0] = np.take(tgk, indx1, 0)
    m[1, 1] = np.take(tgk, indx2, 0)
    m *= s2
    x = np.arange(0, N * (1 << J), dtype=float) / (1 << J)
    phi = 0 * x
    psi = 0 * x
    lam, v = eig(m[0, 0])
    ind = np.argmin(np.absolute(lam - 1))
    v = np.real(v[:, ind])
    sm = np.sum(v)
    if sm < 0:
        v = -v
        sm = -sm
    bitdic = {'0': v / sm}
    bitdic['1'] = np.dot(m[0, 1], bitdic['0'])
    step = 1 << J
    phi[::step] = bitdic['0']
    phi[(1 << (J - 1))::step] = bitdic['1']
    psi[::step] = np.dot(m[1, 0], bitdic['0'])
    psi[(1 << (J - 1))::step] = np.dot(m[1, 1], bitdic['0'])
    prevkeys = ['1']
    for level in range(2, J + 1):
        newkeys = ['%d%s' % (xx, yy) for xx in [0, 1] for yy in prevkeys]
        fac = 1 << (J - level)
        for key in newkeys:
            num = 0
            for pos in range(level):
                if key[pos] == '1':
                    num += (1 << (level - 1 - pos))
            pastphi = bitdic[key[1:]]
            ii = int(key[0])
            temp = np.dot(m[0, ii], pastphi)
            bitdic[key] = temp
            phi[num * fac::step] = temp
            psi[num * fac::step] = np.dot(m[1, ii], pastphi)
        prevkeys = newkeys
    return x, phi, psi


SIG = np.round(np.sin(np.linspace(0, 6, 40)) + 0.3 * np.cos(np.linspace(0, 23, 40)), 4)


def PY():
    import warnings
    warnings.simplefilter('ignore')
    from scipy import interpolate, linalg, stats, special, differentiate
    return dict(interpolate=interpolate, linalg=linalg, stats=stats, special=special, differentiate=differentiate,
                ricker=_ricker, morlet2=_morlet2, cwt=_cwt, daub=_daub, qmf=_qmf, cascade=_cascade, sig=SIG,
                A6=np.array([[2.041, -2.556, 0.418, -0.568, -0.453, -0.216], [-2.02, -0.232, -0.865, 3.323, 0.226, -0.353], [-0.281, -0.668, -1.055, -0.391, 0.482, -0.239], [0.958, -0.2, 0.024, 1.546, 0.545, -0.505], [-0.183, 0.541, 1.935, -0.27, -0.244, 1.002], [-0.886, -0.292, 0.883, 0.58, 0.092, 0.67]]), B6=np.array([[-2.828, 1.021, -0.96, -1.669, 0.276, 0.701], [-0.445, -1.076, 0.026, -0.053, 1.406, 0.747], [0.194, 1.112, -0.206, -0.926, 0.584, 0.583], [-0.215, -0.783, 0.229, -2.494, 0.69, 0.491], [-1.639, 0.061, -0.964, 0.757, -2.034, -0.914], [0.71, 1.156, -2.158, -0.498, 0.328, -0.609]]), sortedgev=lambda A, B: np.r_[np.sort(linalg.eigvals(A, B).real), np.sort(np.abs(linalg.eigvals(A, B)))])


NC_SETUP = '''sig = [%s];
function r = ratios(g):
  v = (g["alphar"] + g["alphai"] * 1i) /. g["beta"];
  r = [sort(real(v)), sort(abs(v))];
fnend
function r = qzcheck(A, B):
  q = qz(A, B);
  n = size(A)[0];
  Q = q["Q"];
  Z = q["Z"];
  AA = q["AA"];
  BB = q["BB"];
  e1 = max(abs(flatten(Q * AA * transpose(conj(Z)) - A)));
  e2 = max(abs(flatten(Q * BB * transpose(conj(Z)) - B)));
  low = 0;
  for i = [1:n-1]:
    for j = [0:i-1]:
      low = max([low, abs(AA[i, j]), abs(BB[i, j])]);
    fend
  fend
  r = (e1 < 1e-10) * (e2 < 1e-10) * (low < 1e-12);
fnend
A6 = [2.041, -2.556, 0.418, -0.568, -0.453, -0.216; -2.02, -0.232, -0.865, 3.323, 0.226, -0.353; -0.281, -0.668, -1.055, -0.391, 0.482, -0.239; 0.958, -0.2, 0.024, 1.546, 0.545, -0.505; -0.183, 0.541, 1.935, -0.27, -0.244, 1.002; -0.886, -0.292, 0.883, 0.58, 0.092, 0.67];
B6 = [-2.828, 1.021, -0.96, -1.669, 0.276, 0.701; -0.445, -1.076, 0.026, -0.053, 1.406, 0.747; 0.194, 1.112, -0.206, -0.926, 0.584, 0.583; -0.215, -0.783, 0.229, -2.494, 0.69, 0.491; -1.639, 0.061, -0.964, 0.757, -2.034, -0.914; 0.71, 1.156, -2.158, -0.498, 0.328, -0.609];
function r = cube(x):
  r = x^3 - 2*x;
fnend
''' % ', '.join(repr(float(v)) for v in SIG)

ROWS = [
    T('bspline_basis([0,1,2,3], 1.5)', '0.75'),
    T('bspline_basis([-2,-1,0,1,2], 0.5)', 'interpolate.BSpline.basis_element([-2,-1,0,1,2])(0.5)'),
    T('bspline_basis([-1.5,-0.5,0.5,1.5], 0.25)', '0.6875'),
    T('bspline_basis([0,1,3,4,7], [-1, 0.5, 2, 3.5, 6, 8])',
      'np.where((np.array([-1, 0.5, 2, 3.5, 6, 8]) < 0) | (np.array([-1, 0.5, 2, 3.5, 6, 8]) > 7), 0, '
      'interpolate.BSpline.basis_element([0,1,3,4,7])(np.array([-1, 0.5, 2, 3.5, 6, 8])))'),
    T('sort_by_magnitude([3+1i, 1-2i, -0.5])', 'np.array([-0.5, 1-2j, 3+1j])'),
    T('ricker_wavelet([-1, 0, 0.5, 2])', '2/(np.sqrt(3)*np.pi**0.25)*(1-np.array([-1,0,0.5,2.])**2)*np.exp(-np.array([-1,0,0.5,2.])**2/2)'),
    T('ricker_wavelet([-1, 0, 0.5, 2], 1.5)', '2/(np.sqrt(4.5)*np.pi**0.25)*(1-np.array([-1,0,0.5,2.])**2/2.25)*np.exp(-np.array([-1,0,0.5,2.])**2/4.5)'),
    T('morlet2_wavelet([-1, 0, 0.5], 5, 2)', 'np.exp(1j*5*np.array([-1,0,0.5])/2)*np.exp(-0.5*(np.array([-1,0,0.5])/2)**2)*np.pi**-0.25*np.sqrt(0.5)'),
    T('morlet_wavelet([-1, 0, 0.5])', '(np.exp(1j*5*np.array([-1,0,0.5])) - np.exp(-12.5))*np.exp(-0.5*np.array([-1,0,0.5])**2)*np.pi**-0.25'),
    T('cwt(sig, [1, 2, 3.5, 5], "mexh")', 'cwt(sig, ricker, [1, 2, 3.5, 5])'),
    T('cwt(sig, [1, 2.5], "morlet2")', 'cwt(sig, morlet2, [1, 2.5])'),
    T('wavelet_filters("db2")', 'daub(2)'),
    T('wavelet_filters("db3")', 'daub(3)'),
    T('wavelet_filters("db5")', 'daub(5)', tol=1e-9),
    T('wavelet_filters(8)', 'daub(8)', tol=1e-8),
    T('qmf([1,1] / sqrt(2))', 'qmf(np.array([1,1]) / np.sqrt(2))'),
    T('qmf(wavelet_filters("db3"))', 'qmf(daub(3))'),
    T('wavelet_function("db2")', 'cascade(daub(2))[1]', field='phi', tol=1e-9),
    T('wavelet_function("db2")', 'cascade(daub(2))[2]', field='psi', tol=1e-9),
    T('wavelet_function("db3", 5)', 'cascade(daub(3), 5)[1]', field='phi', tol=1e-9),
    T('wavelet_function("db3", 5)', 'cascade(daub(3), 5)[0]', field='x'),
    T('gibrat_pdf(1.0)', 'stats.gibrat.pdf(1.0)'),
    T('unique_counts([1,1,2,3,3,3])', '[1,2,3]', field='values'),
    T('unique_counts([1,1,2,3,3,3])', '[2,1,3]', field='counts'),
    T('median_abs_dev([1,2,3,4,10])', 'stats.median_abs_deviation([1,2,3,4,10])'),
    T('binom_test(7, 10, 0.5)', '0.34375', field='pvalue'),
    T('betainc(2, 3, 0.4)', 'special.betainc(2, 3, 0.4)'),
    T('betaincinv(2, 3, 0.5)', 'special.betaincinv(2, 3, 0.5)'),
    T('tri(3)', 'np.tri(3)'),
    T('tri(3, 4, 1)', 'np.tri(3, 4, 1)'),
    T('tri(4, 3, -1)', 'np.tri(4, 3, -1)'),
    T('ratios(lapack_ggev([4,2;2,3], unit_matrix(2)))', 'sortedgev(np.array([[4,2],[2,3.]]), np.eye(2))', label='lapack_ggev'),
    T('ratios(lapack_ggev([1,2,0;0,3,1;1,0,2], [2,0,0;1,1,0;0,0,3]))',
      'sortedgev(np.array([[1,2,0],[0,3,1],[1,0,2.]]), np.array([[2,0,0],[1,1,0],[0,0,3.]]))', label='lapack_ggev_complex'),
    T('derivative("sin", 1.0)', 'np.cos(1.0)', field='df', tol=1e-9),
    T('derivative("cube", [0.5, 2, -3])', 'differentiate.derivative(lambda x: x**3 - 2*x, [0.5, 2, -3]).df', field='df', tol=1e-9),
    T('derivative("exp", 0.3, 0.1)', 'np.exp(0.3)', field='df', tol=1e-9),
    T('central_diff_weights(3)', '[-0.5, 0, 0.5]'),
    T('central_diff_weights(5, 2)', '[-1/12, 4/3, -5/2, 4/3, -1/12]'),
    T('central_diff_weights(7, 3)', 'np.linalg.inv(np.vander(np.arange(-3, 4.), increasing=True))[3] * 6', tol=1e-9),
    T('assoc_legendre_p_all(2, 1, 0.5 + 0.1i)', 'special.assoc_legendre_p_all(2, 1, 0.5 + 0.1j)[0]', label='assoc_legendre_p_all_complex'),
    T('assoc_legendre_p(3, 2, [0.3 - 0.2i, 1.5 + 0i])', 'special.assoc_legendre_p(3, 2, np.array([0.3 - 0.2j, 1.5 + 0j]))[0]', label='assoc_legendre_p_complex'),
    T('assoc_legendre_p(2, 1, 1.5)', 'special.assoc_legendre_p(2, 1, 1.5)[0]', label='assoc_legendre_p_outside'),
    T('qzcheck([1,2,0;0,3,1;1,0,2], [2,0,0;1,1,0;0,0,3])', '1', label='qz_complex_pair'),
    T('qzcheck([0,-1,0,0;1,0,0,0;0,0,0,-2;0,0,2,0.5], unit_matrix(4))', '1', label='qz_rotations'),
    T('ratios(lapack_ggev([0,-1,0,0;1,0,0,0;0,0,0,-2;0,0,2,0.5], unit_matrix(4)))',
      'sortedgev(np.array([[0,-1,0,0],[1,0,0,0],[0,0,0,-2],[0,0,2,0.5]]), np.eye(4))', label='lapack_ggev_rotations'),
    T('qzcheck([1,2,3,4;2,1,0,1;0,3,1,2;1,1,1,5], [1,2,0,1;0,0,1,0;0,0,1,3;0,0,0,2])', '1', label='qz_singular_B'),
    T('sum(abs(lapack_ggev([1,2,3,4;2,1,0,1;0,3,1,2;1,1,1,5], [1,2,0,1;0,0,1,0;0,0,1,3;0,0,0,2])["beta"]) < 1e-12)',
      'np.sum(np.isinf(linalg.eigvals(np.array([[1,2,3,4],[2,1,0,1],[0,3,1,2],[1,1,1,5.]]), np.array([[1,2,0,1],[0,0,1,0],[0,0,1,3],[0,0,0,2.]]))))',
      label='qz_singular_B_infinite'),
    T('qzcheck(A6, B6)', '1', label='qz_random6'),
    T('ratios(lapack_ggev(A6, B6))', 'sortedgev(A6, B6)', tol=1e-8, label='lapack_ggev_random6'),
    T('mismatch_frac([1,0,1], [1,1,0])', '2/3'),
    T('kulczynski1([1,0,1], [1,1,0])', '0.5'),
    T('mismatch_frac([1,0,1,1;0,0,1,0], [1,1,0,1;1,0,1,0;0,0,1,1])',
      'np.array([[np.mean(np.array(u,bool) != np.array(v,bool)) for v in [[1,1,0,1],[1,0,1,0],[0,0,1,1]]] for u in [[1,0,1,1],[0,0,1,0]]])',
      label='mismatch_frac_pairs'),
    T('kulczynski1([1,0,1,1;0,2,1,0], [1,1,0,1;1,0,1,0])',
      'np.array([[ (lambda a,b: np.sum(a&b)/np.sum(a^b))(np.array(u)!=0, np.array(v)!=0) for v in [[1,1,0,1],[1,0,1,0]]] for u in [[1,0,1,1],[0,2,1,0]]])',
      label='kulczynski1_pairs'),
    T('help("integrate")', None),
]
