import json, os
from gen_tests import T

ROWS = [
    T('constant_value("electron mass")', 'constants.value("electron mass")', tol=1e-12),
    T('constant_unit("electron mass")', '=kg'),
    T('constant_precision("electron mass")', 'constants.precision("electron mass")', tol=1e-12),
    T('numel(constant_find("boltzmann"))', 'len(constants.find("boltzmann"))', label='constant_find'),
    T('constant_info("proton mass")', 'constants.physical_constants["proton mass"][0]', field='value', tol=1e-12),
    T('convert_temp([0,100], "Celsius", "Kelvin")', '[273.15,373.15]'),
    T('convert_temp(32, "Fahrenheit", "Rankine")', 'constants.convert_temperature(32, "Fahrenheit", "Rankine")', label='convert_temp_rankine'),
    T('wavelength2freq(500e-9)', 'constants.lambda2nu(500e-9)', tol=1e-12),
    T('freq2wavelength(6e14)', 'constants.nu2lambda(6e14)', tol=1e-12),
    T('boltzmann', 'constants.Boltzmann', tol=1e-12), T('speed_of_light', 'constants.c', tol=1e-12),
    # a variable with the same name wins over the constant
    T('atm', '5', label='variable_wins', setup='atm = 5;'),
]

# One row per named constant of the mapping tables, with the value SciPy has.
_spec = os.environ.get('NC_SPEC_JSON')
if _spec and os.path.exists(_spec):
    _seen = set()
    for e in json.load(open(_spec, encoding='utf-8')):
        if e['args'].startswith('(constant') and e['nc'].strip() not in _seen:
            n = e['nc'].strip()
            _seen.add(n)
            ROWS.append(T(n + ' * 1', 'constants.' + e['scipy'].replace('constants.', '').strip(), tol=1e-12, label=n))
