from gen_tests import T

NC_SETUP = '''P = [0.1,0.2;0.15,0.82;0.9,0.8;0.92,0.15;0.5,0.1;0.52,0.54;0.2,0.9;0.25,0.35;0.7,0.3;0.6,0.75];
P3 = [1,0,0;0,1,0;0,0,1;-1,0,0;0,-1,0;0,0,-1];
'''

def PY():
    import numpy as np
    from scipy.spatial import distance as dist, transform as tf
    P = np.array([[0.1,0.2],[0.15,0.82],[0.9,0.8],[0.92,0.15],[0.5,0.1],[0.52,0.54],[0.2,0.9],[0.25,0.35],[0.7,0.3],[0.6,0.75]])
    return dict(dist=dist, tf=tf, P=P, KD=spatial_kd(P))

def spatial_kd(P):
    from scipy.spatial import KDTree
    return KDTree(P)

ROWS = [
    T('kdtree_query(kdtree(P), [0.5,0.5], 2)', 'KD.query([0.5,0.5],2)[0]', field='dist'),
    T('kdtree_query(kdtree(P), [0.5,0.5], 2)', 'KD.query([0.5,0.5],2)[1]', field='index'),
    T('kdtree_query(kdtree(P), [0.5,0.5])', 'KD.query([0.5,0.5])[0]', field='dist', label='kdtree'),
    T('kdtree_query(kdtree(P), P[0:1,:], 3)', 'KD.query(P[:2],3)[0]', field='dist', label='kdtree_many'),
    T('kdtree_ball(kdtree(P), [0.5,0.5], 0.3)', 'sorted(KD.query_ball_point([0.5,0.5],0.3))'),
    T('box_volume([0,0], [1,1])', '1'),
    T('dsum(delaunay(P))', 'spatial.Delaunay(P).simplices.shape[0]', label='delaunay', setup='function n = dsum(t):\n  n = size(t["simplices"])[0];\nfnend') if False else T('tri_count(delaunay(P))', 'spatial.Delaunay(P).simplices.shape[0]', label='delaunay', setup='function n = tri_count(t):\n  s = size(t["simplices"]);\n  n = s[0];\nfnend'),
    T('tri_area(delaunay(P))', 'spatial.ConvexHull(P).volume', label='delaunay_covers_hull',
      setup='function s = tri_area(t):\n  q = t["simplices"];\n  p = t["points"];\n  z = size(q);\n  s = 0;\n  for i = [0:z[0]-1]:\n    a = p[q[i,0],:]; b = p[q[i,1],:]; c = p[q[i,2],:];\n    s = s + abs((b[0]-a[0])*(c[1]-a[1]) - (c[0]-a[0])*(b[1]-a[1])) / 2;\n  fend\nfnend'),
    T('tri_count(delaunay([0,0;1,0;2,0;0,1;1,1;2,1;0,2;1,2;2,2]))', '8', label='delaunay_grid', setup='function n = tri_count(t):\n  s = size(t["simplices"]);\n  n = s[0];\nfnend'),
    T('convex_hull(P)', 'spatial.ConvexHull(P).volume', field='volume'),
    T('convex_hull(P)', 'spatial.ConvexHull(P).area', field='area'),
    T('convex_hull(P)', 'np.sort(spatial.ConvexHull(P).vertices)', field='vertices', label='convex_hull_verts') if False else T('sort(convex_hull(P)["vertices"])', 'np.sort(spatial.ConvexHull(P).vertices)', label='convex_hull_verts'),
    T('convex_hull(P3)', 'spatial.ConvexHull(np.array([[1,0,0],[0,1,0],[0,0,1],[-1,0,0],[0,-1,0],[0,0,-1.]])).volume', field='volume', label='convex_hull_3d'),
    T('vor_count(voronoi(P))', 'spatial.Voronoi(P).vertices.shape[0]', label='voronoi', setup='function n = vor_count(v):\n  s = size(v["vertices"]);\n  n = s[0];\nfnend'),
    T('sv_count(spherical_voronoi(P3))', 'spatial.SphericalVoronoi(np.array([[1,0,0],[0,1,0],[0,0,1],[-1,0,0],[0,-1,0],[0,0,-1.]])).vertices.shape[0]', label='spherical_voronoi', setup='function n = sv_count(v):\n  s = size(v["vertices"]);\n  n = s[0];\nfnend'),
    T('sort_rows(halfspace_intersection([-1,0,0;0,-1,0;1,1,-1], [0.2,0.2]))', 'sorted(np.round(spatial.HalfspaceIntersection(np.array([[-1,0,0],[0,-1,0],[1,1,-1.]]),np.array([0.2,0.2])).intersections.sum(axis=1),9))', label='halfspace_intersection', tol=1e-6,
      setup='function s = sort_rows(h):\n  x = h["intersections"];\n  z = size(x);\n  s = [];\n  for i = [0:z[0]-1]:\n    s ,= x[i,0] + x[i,1];\n  fend\n  s = sort(s);\nfnend'),
    T('find_simplex(delaunay([0,0;1,0;0,1;1,1]), [0.2,0.2]) >= 0', '1', label='find_simplex'),
    T('find_simplex(delaunay([0,0;1,0;0,1;1,1]), [5,5])', '-1', label='find_simplex_outside'),
    T('plot_delaunay(delaunay(P))', None), T('plot_convex_hull(convex_hull(P))', None), T('plot_voronoi(voronoi(P))', None),
    T('dist_minkowski([0,0], [3,4], 2)', '5'), T('dist_minkowski_p([0,0], [3,4], 2)', '25'),
    T('dist_minkowski([0,0], [3,4], 3)', 'dist.minkowski([0,0],[3,4],3)', label='dist_minkowski3'),
    T('procrustes_fit(P, P * 2 + 1)', '0', field='disparity'),
    T('procrustes_fit(P, reverse_cols(P))', 'spatial.procrustes(P, P[:,::-1])[2]', field='disparity', label='procrustes_fit_flip', setup='function y = reverse_cols(p):\n  y = [p[:,1], p[:,0]];\nfnend'),
    T('slerp([1,0], [0,1], space(0,1,5))', 'spatial.geometric_slerp([1.,0],[0,1.],np.linspace(0,1,5))'),
    T('pdist(P, "euclidean")', 'dist.pdist(P)'),
    *[T('pdist(P, "%s")' % m, 'dist.pdist(P, "%s")' % m, label='pdist_' + m) for m in ('sqeuclidean','cityblock','chebyshev','braycurtis','canberra','cosine','correlation')],
    T('cdist(P[0:2,:], P[3:9,:], "cityblock")', 'dist.cdist(P[:3],P[3:10],"cityblock")'),
    T('squareform(pdist(P))', 'dist.squareform(dist.pdist(P))'),
    T('squareform(squareform(pdist(P)))', 'dist.pdist(P)', label='squareform_back'),
    T('directed_hausdorff(P[0:4,:], P[5:9,:])', 'dist.directed_hausdorff(P[:5],P[5:10])[0]', field='dist'),
    T('is_valid_dm(squareform(pdist(P)))', '1'), T('is_valid_condensed(pdist(P))', '1'),
    T('dm_count(squareform(pdist(P)))', '10'), T('condensed_count(pdist(P))', '10'),
    *[T('dist_%s(%s, %s)' % (n, u, v), 'dist.%s(%s, %s)' % (n, u, v)) for n, u, v in [
        ('braycurtis','[1,2,3]','[2,2,1]'), ('canberra','[1,2,3]','[2,2,1]'), ('chebyshev','[1,2,3]','[2,2,1]'), ('cityblock','[1,2,3]','[2,2,1]'),
        ('correlation','[1,2,3]','[2,2,1]'), ('cosine','[1,2,3]','[2,2,1]'), ('jensenshannon','[0.5,0.5]','[0.9,0.1]'), ('sqeuclidean','[0,0]','[3,4]'),
        ('hamming','[1,0,1]','[1,1,0]')]],
    T('dist_dice([1,0,1], [1,1,0])', '0.5'), T('dist_jaccard([1,0,1], [1,1,0])', '2/3'),
    T('dist_rogerstanimoto([1,0,1], [1,1,0])', '0.8'), T('dist_russellrao([1,0,1], [1,1,0])', '2/3'),
    T('dist_sokalsneath([1,0,1], [1,1,0])', '0.8'), T('dist_yule([1,0,1,0], [1,1,0,0])', '1'),
    T('dist_mahalanobis([1,0], [0,1], inv([4,2;2,3]))', 'dist.mahalanobis([1,0],[0,1],np.linalg.inv([[4,2],[2,3]]))'),
    T('dist_seuclidean([1,2], [3,5], [1,2])', 'dist.seuclidean([1,2],[3,5],[1,2])'),
    T('rot_apply(rot_from_euler("z", 90, 1), [1,0,0])', '[0,1,0]'),
    T('rot_apply(rot_from_euler("xyz", [10,20,30], 1), [1,2,3])', 'tf.Rotation.from_euler("xyz",[10,20,30],degrees=True).apply([1,2,3])', label='rot_from_euler'),
    T('rot_apply(rot_from_euler("XYZ", [10,20,30], 1), [1,2,3])', 'tf.Rotation.from_euler("XYZ",[10,20,30],degrees=True).apply([1,2,3])', label='rot_from_euler_intrinsic'),
    T('rot_as_matrix(rot_from_quat([0,0,0,1]))', 'np.eye(3)', label='rot_from_quat'),
    T('rot_as_matrix(rot_from_quat([1,2,3,4]))', 'tf.Rotation.from_quat([1,2,3,4]).as_matrix()', label='rot_as_matrix'),
    T('rot_as_euler(rot_from_rotvec([0,0,pi/2]), "xyz", 1)', '[0,0,90]', label='rot_from_rotvec'),
    T('rot_as_euler(rot_from_quat([1,2,3,4]), "zyx", 1)', 'tf.Rotation.from_quat([1,2,3,4]).as_euler("zyx",degrees=True)', label='rot_as_euler'),
    T('rot_as_euler(rot_from_quat([1,2,3,4]), "ZXZ", 1)', 'tf.Rotation.from_quat([1,2,3,4]).as_euler("ZXZ",degrees=True)', label='rot_as_euler_proper'),
    T('rot_random(3, 1)', None, field='quat'),
    T('rot_as_euler(rot_slerp([0,1], rot_from_euler("z", [0,90], 1), [0.5]), "xyz", 1)', '[0,0,45]', label='rot_slerp'),
    T('rot_as_euler(rot_spline([0,1,2], rot_from_euler("z", [0,45,90], 1), [0.5,1.5]), "xyz", 1)', '[0,0,22.5,0,0,67.5]', label='rot_spline'),
    T('rigid_apply(rigid_transform([1,2,3], rot_identity()), [0,0,0])', '[1,2,3]', label='rigid_transform'),
    T('rigid_apply(rigid_transform([1,2,3], rot_from_euler("z", 90, 1)), [1,0,0])', '[1,3,3]', label='rigid_apply'),
]
