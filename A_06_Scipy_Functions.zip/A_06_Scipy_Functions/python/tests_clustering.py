from gen_tests import T

NC_SETUP = '''P = [0.1,0.2;0.15,0.22;0.9,0.8;0.92,0.85;0.5,0.1;0.52,0.14;0.2,0.9;0.25,0.95;0.7,0.3;0.6,0.75];
'''

def best_leaf_cost(Z, P):
    # The true optimum: every order the tree allows (SciPy's own answer is not always this low).
    import itertools, numpy as np
    n = len(Z) + 1
    def orders(node):
        if node < n:
            return [[node]]
        l, r = int(Z[node-n,0]), int(Z[node-n,1])
        out = []
        for a in orders(l):
            for b in orders(r):
                out += [a + b, b + a]
        return out
    best = min(orders(2*n-2), key=lambda o: sum(np.linalg.norm(P[o[i]]-P[o[i+1]]) for i in range(n-1)))
    return sum(np.linalg.norm(P[best[i]]-P[best[i+1]]) for i in range(n-1))

def PY():
    import numpy as np
    from scipy.cluster import hierarchy as H
    from scipy.spatial.distance import pdist
    P = np.array([[0.1,0.2],[0.15,0.22],[0.9,0.8],[0.92,0.85],[0.5,0.1],[0.52,0.14],[0.2,0.9],[0.25,0.95],[0.7,0.3],[0.6,0.75]])
    return dict(best_leaf_cost=best_leaf_cost, H=H, pdist=pdist, P=P, vq=__import__('scipy.cluster.vq', fromlist=['vq']))

ROWS = [
    T('whiten(P)', 'vq.whiten(P)'),
    T('kmeans(whiten(P), 3, 0)', None, field='centroids'),
    T('size(kmeans2(P, 3, 0)["labels"])', '[1,10]', label='kmeans2'),
    T('assign_clusters(P, P[0:2,:])', 'vq.vq(P, P[:3])[0]', field='labels'),
    T('assign_clusters(P, P[0:2,:])', 'vq.vq(P, P[:3])[1]', field='dist'),
    *[T('linkage(P, "%s")' % m, 'H.linkage(P, "%s")' % m, label='linkage_' + m) for m in ('single','complete','average','weighted','centroid','median','ward')],
    T('linkage_single(cond)', 'H.single(pdist(P))', setup='cond = [%s];' % 'COND'),
    T('linkage_complete(cond)', 'H.complete(pdist(P))', setup='cond = [COND];'),
    T('linkage_average(cond)', 'H.average(pdist(P))', setup='cond = [COND];'),
    T('linkage_weighted(cond)', 'H.weighted(pdist(P))', setup='cond = [COND];'),
    T('linkage_centroid(P)', 'H.centroid(P)'), T('linkage_median(P)', 'H.median(P)'), T('linkage_ward(P)', 'H.ward(P)'),
    T('fcluster(linkage_ward(P), 3, "maxclust")', 'H.fcluster(H.ward(P), 3, "maxclust")'),
    T('fcluster(linkage_ward(P), 0.5, "distance")', 'H.fcluster(H.ward(P), 0.5, "distance")', label='fcluster_distance'),
    T('fcluster(linkage_ward(P), 1.0, "inconsistent")', 'H.fcluster(H.ward(P), 1.0, "inconsistent")', label='fcluster_inconsistent'),
    T('fcluster_data(P, 1.0)', 'H.fclusterdata(P, 1.0, method="single")'),
    T('cluster_leaders(linkage_ward(P), fcluster(linkage_ward(P), 3, "maxclust"))', 'np.sort(H.leaders(H.ward(P), H.fcluster(H.ward(P), 3, "maxclust"))[0])', field=None, label='cluster_leaders') if False else T('cluster_leaders(linkage_ward(P), fcluster(linkage_ward(P), 3, "maxclust"))', 'H.leaders(H.ward(P), H.fcluster(H.ward(P), 3, "maxclust"))[1]', field='ids'),
    T('cut_tree(linkage_ward(P), [2,3])', 'H.cut_tree(H.ward(P), [2,3])'),
    T('cophenet(linkage_ward(P), cond)', 'H.cophenet(H.ward(P), pdist(P))[0]', field='c', setup='cond = [COND];'),
    T('cophenet(linkage_ward(P), cond)', 'H.cophenet(H.ward(P), pdist(P))[1]', field='coph_dists', setup='cond = [COND];'),
    T('inconsistent(linkage_ward(P))', 'H.inconsistent(H.ward(P))'),
    T('max_inconsistent(linkage_ward(P), inconsistent(linkage_ward(P)))', 'H.maxinconsts(H.ward(P), H.inconsistent(H.ward(P)))'),
    T('max_dists(linkage_ward(P))', 'H.maxdists(H.ward(P))'),
    T('max_rstat(linkage_ward(P), inconsistent(linkage_ward(P)), 3)', 'H.maxRstat(H.ward(P), H.inconsistent(H.ward(P)), 3)'),
    T('to_mlab_linkage(linkage_ward(P))', 'H.to_mlab_linkage(H.ward(P))'),
    T('from_mlab_linkage(to_mlab_linkage(linkage_ward(P)))', 'H.ward(P)'),
    T('dendrogram(linkage_ward(P), 1)', None, field='leaves'),
    T('set_link_colors(["m","c","y"])', None),
    T('leaves_list(linkage_ward(P))', 'H.leaves_list(H.ward(P))'),
    T('leaf_cost(leaves_list(optimal_leaf_order(linkage_ward(P), P)), P)', 'best_leaf_cost(H.ward(P), P)', label='optimal_leaf_order',
      setup='function c = leaf_cost(o, P):\n  c = 0;\n  for k = [0:numel(o)-2]:\n    d = P[o[k],:] - P[o[k+1],:];\n    c = c + sqrt(d[0]^2 + d[1]^2);\n  fend\nfnend'),
    T('to_tree(linkage_ward(P))', '18', field='id'),
    T('is_valid_linkage(linkage_ward(P))', '1'),
    T('is_valid_inconsistency(inconsistent(linkage_ward(P)))', '1'),
    T('is_monotonic(linkage_ward(P))', '1'),
    T('is_isomorphic([1,1,2], [3,3,1])', '1'), T('is_isomorphic([1,1,2], [3,1,1])', '0', label='is_isomorphic_no'),
    T('linkage_corresponds(linkage_ward(P), cond)', '1', setup='cond = [COND];'),
    T('linkage_count(linkage_ward(P))', '10'),
    T('ds_connected(ds_merge(disjoint_set([1,2,3,4]), 1, 2), 1, 2)', '1', label='disjoint_set'),
    T('ds_connected(ds_merge(disjoint_set([1,2,3,4]), 1, 2), 1, 3)', '0', label='ds_merge'),
    T('ds_connected(disjoint_set([1,2,3,4]), 1, 2)', '0', label='ds_connected'),
]

import numpy as _np
from scipy.spatial.distance import pdist as _pd
_P = _np.array([[0.1,0.2],[0.15,0.22],[0.9,0.8],[0.92,0.85],[0.5,0.1],[0.52,0.14],[0.2,0.9],[0.25,0.95],[0.7,0.3],[0.6,0.75]])
_cond = ','.join(repr(float(v)) for v in _pd(_P))
for _t in ROWS:
    _t.setup = _t.setup.replace('COND', _cond).replace('[%s]' % 'COND', '[%s]' % _cond)
