﻿"""Section 25, BLAS part (scipy.linalg.blas). One NC name covers the s/d/c/z
routines: real input is checked against the d routine, complex input against z."""
from gen_tests import T

NC_SETUP = '''A = [4,2;2,3];
M = [1,2,3;4,5,6;7,8,10];
Z = [2,1+1i;1-1i,3];
x = [1,-2,3];
y = [4,5,-6];
zx = [1+2i,3-1i];
zy = [2-1i,1+1i];
'''


def PY():
    import numpy as np
    from scipy.linalg import blas as B, lapack as L
    M = np.array([[1., 2, 3], [4, 5, 6], [7, 8, 10]])
    Z = np.array([[2, 1 + 1j], [1 - 1j, 3]])
    x = np.array([1., -2, 3])
    y = np.array([4., 5, -6])
    zx = np.array([1 + 2j, 3 - 1j])
    zy = np.array([2 - 1j, 1 + 1j])
    ab = np.array([[0., 2, 6], [1, 5, 10], [4, 8, 0]])  # band of M-like tridiagonal, kl=ku=1
    return dict(B=B, L=L, M=M, Z=Z, x=x, y=y, zx=zx, zy=zy, ab=ab, np=np)


ROWS = [
    # level 1
    T('blas_asum(x)', 'B.dasum(x)'),
    T('blas_asum(zx)', 'B.dzasum(zx)', label='blas_asum_c'),
    T('blas_axpy(x, y, 0, 2)', 'B.daxpy(x, y, a=2)'),
    T('blas_axpy(zx, zy, 2, 1i)', 'B.zaxpy(zx, zy, a=1j)', label='blas_axpy_c'),
    T('blas_axpy([1,2,3,4], [1,1,1,1], 2, 1, 0, 2, 1, 1)', 'B.daxpy(np.array([1.,2,3,4]), np.ones(4), n=2, a=1, offx=0, incx=2, offy=1, incy=1)', label='blas_axpy_stride'),
    T('blas_copy(x, [0,0,0])', 'B.dcopy(x, np.zeros(3))'),
    T('blas_copy([1,2,3], [0,0,0,0,0,0], 3, 0, 1, 0, 2)', 'B.dcopy(np.array([1.,2,3]), np.zeros(6), n=3, incy=2)', label='blas_copy_stride'),
    T('blas_dot(x, y)', 'B.ddot(x, y)'),
    T('blas_dotu(zx, zy)', 'B.zdotu(zx, zy)'),
    T('blas_dotc(zx, zy)', 'B.zdotc(zx, zy)'),
    T('blas_iamax(x)', 'B.idamax(x)'),
    T('blas_iamax([1, 3+4i, 5])', 'B.izamax(np.array([1, 3+4j, 5]))', label='blas_iamax_c'),
    T('blas_nrm2(x)', 'B.dnrm2(x)'),
    T('blas_nrm2(zx)', 'B.dznrm2(zx)', label='blas_nrm2_c'),
    T('blas_rot(x, y, 0.6, 0.8)', 'B.drot(x, y, 0.6, 0.8)[0]', field='x'),
    T('blas_rot(x, y, 0.6, 0.8)', 'B.drot(x, y, 0.6, 0.8)[1]', field='y'),
    T('blas_rot(zx, zy, 0.6, 0.8i)', 'L.zrot(zx, zy, 0.6, 0.8j)[1]', field='y', label='blas_rot_c'),
    T('blas_rotg(3, 4)', 'B.drotg(3., 4.)[0]', field='c'),
    T('blas_rotg(3, 4)', 'B.drotg(3., 4.)[1]', field='s'),
    T('blas_rotg(-3, 4)', 'B.drotg(-3., 4.)[1]', field='s', label='blas_rotg_neg'),
    T('blas_rotg(1+1i, 2)', 'B.zrotg(1+1j, 2+0j)[0]', field='c', label='blas_rotg_c'),
    T('blas_rotg(1+1i, 2)', 'B.zrotg(1+1j, 2+0j)[1]', field='s', label='blas_rotg_cs'),
    T('blas_rotm(x, y, [-1, 1, 2, 3, 4])', 'B.drotm(x, y, np.array([-1., 1, 2, 3, 4]))[0]', field='x'),
    T('blas_rotm(x, y, [0, 9, 2, 3, 9])', 'B.drotm(x, y, np.array([0., 9, 2, 3, 9]))[1]', field='y', label='blas_rotm_0'),
    T('blas_rotm(x, y, [1, 2, 9, 9, 3])', 'B.drotm(x, y, np.array([1., 2, 9, 9, 3]))[1]', field='y', label='blas_rotm_1'),
    T('blas_rotmg(1, 2, 3, 4)', 'B.drotmg(1., 2., 3., 4.)'),
    T('blas_rotmg(2, 1, 4, 1)', 'B.drotmg(2., 1., 4., 1.)', label='blas_rotmg_0'),
    T('blas_scal(2, x)', 'B.dscal(2., x)'),
    T('blas_scal(1i, zx)', 'B.zscal(1j, zx)', label='blas_scal_c'),
    T('blas_scal(3, zx)', 'B.zdscal(3., zx)', label='blas_scal_zd'),
    T('blas_swap(x, y)', 'B.dswap(x, y)[0]', field='x'),
    T('blas_swap(x, y)', 'B.dswap(x, y)[1]', field='y'),
    # level 2
    T('blas_gemv(2, M, x)', 'B.dgemv(2., M, x)'),
    T('blas_gemv(1, M, x, 3, y, 0, 1, 0, 1, 1)', 'B.dgemv(1., M, x, beta=3., y=y, trans=1)', label='blas_gemv_t'),
    T('blas_gemv(1, Z, zx, 0, 0, 0, 1, 0, 1, 2)', 'B.zgemv(1., Z, zx, trans=2)', label='blas_gemv_h'),
    T('blas_gbmv(3, 3, 1, 1, 1, [0,2,6;1,5,10;4,8,0], x)', 'B.dgbmv(3, 3, 1, 1, 1., ab, x)'),
    T('blas_gbmv(3, 3, 1, 1, 2, [0,2,6;1,5,10;4,8,0], x, 1, 0, 1, y, 1, 0, 1)', 'B.dgbmv(3, 3, 1, 1, 2., ab, x, beta=1., y=y, trans=1)', label='blas_gbmv_t'),
    T('blas_ger(2, x, y)', 'B.dger(2., x, y)'),
    T('blas_ger(1, x, y, 1, 1, M)', 'B.dger(1., x, y, a=M)', label='blas_ger_a'),
    T('blas_geru(1i, zx, zy)', 'B.zgeru(1j, zx, zy)'),
    T('blas_gerc(1i, zx, zy)', 'B.zgerc(1j, zx, zy)'),
    T('blas_symv(1, [4,1,2;1,5,3;2,3,6], x)', 'B.dsymv(1., np.array([[4.,1,2],[1,5,3],[2,3,6]]), x)'),
    T('blas_symv(1, [4,9,9;1,5,9;2,3,6], x, 0, 0, 0, 1, 0, 1, 1)', 'B.dsymv(1., np.array([[4.,9,9],[1,5,9],[2,3,6]]), x, lower=1)', label='blas_symv_lower'),
    T('blas_hemv(1, Z, zx)', 'B.zhemv(1., Z, zx)'),
    T('blas_sbmv(1, 1, [0,2,6;1,5,10], x)', 'B.dsbmv(1, 1., np.array([[0.,2,6],[1,5,10]]), x)'),
    T('blas_sbmv(1, 1, [1,5,10;2,6,0], x, 1, 0, 0, 0, 1, 0, 1)', 'B.dsbmv(1, 1., np.array([[1.,5,10],[2,6,0]]), x, lower=1)', label='blas_sbmv_lower'),
    T('blas_hbmv(1, 1, [0,1+1i;2,3], zx)', 'B.zhbmv(1, 1., np.array([[0,1+1j],[2,3]]), zx)'),
    T('blas_spmv(3, 1, [1,2,3,4,5,6], x)', 'B.dspmv(3, 1., np.array([1.,2,3,4,5,6]), x)'),
    T('blas_spmv(3, 1, [1,2,3,4,5,6], x, 1, 0, 0, 0, 1, 0, 1)', 'B.dspmv(3, 1., np.array([1.,2,3,4,5,6]), x, lower=1)', label='blas_spmv_lower'),
    T('blas_hpmv(2, 1, [2, 1+1i, 3], zx)', 'B.zhpmv(2, 1., np.array([2, 1+1j, 3]), zx)'),
    T('blas_syr(1, x)', 'B.dsyr(1., x)'),
    T('blas_syr(2, x, 1)', 'B.dsyr(2., x, lower=1)', label='blas_syr_lower'),
    T('blas_her(1, zx)', 'B.zher(1., zx)'),
    T('blas_syr2(1, x, y)', 'B.dsyr2(1., x, y)'),
    T('blas_her2(1i, zx, zy)', 'B.zher2(1j, zx, zy)'),
    T('blas_spr(3, 1, x, [1,2,3,4,5,6])', 'B.dspr(3, 1., x, np.array([1.,2,3,4,5,6]))'),
    T('blas_spr2(3, 1, x, y, [1,2,3,4,5,6])', 'B.dspr2(3, 1., x, y, np.array([1.,2,3,4,5,6]))'),
    T('blas_hpr(2, 1, zx, [2, 1+1i, 3])', 'B.zhpr(2, 1., zx, np.array([2, 1+1j, 3]))'),
    T('blas_hpr2(2, 1i, zx, zy, [2, 1+1i, 3])', 'B.zhpr2(2, 1j, zx, zy, np.array([2, 1+1j, 3]))'),
    T('blas_trmv(M, x)', 'B.dtrmv(M, x)'),
    T('blas_trmv(M, x, 0, 1, 1, 1, 1)', 'B.dtrmv(M, x, lower=1, trans=1, diag=1)', label='blas_trmv_opts'),
    T('blas_trsv(M, x)', 'B.dtrsv(M, x)'),
    T('blas_trsv(M, x, 1, 0, 1, 2)', 'B.dtrsv(M, x, lower=1, trans=2)', label='blas_trsv_opts'),
    T('blas_tbmv(1, [0,2,6;1,5,10], x)', 'B.dtbmv(1, np.array([[0.,2,6],[1,5,10]]), x)'),
    T('blas_tbsv(1, [0,2,6;1,5,10], x)', 'B.dtbsv(1, np.array([[0.,2,6],[1,5,10]]), x)'),
    T('blas_tbsv(1, [1,5,10;4,8,0], x, 1, 0, 1)', 'B.dtbsv(1, np.array([[1.,5,10],[4,8,0]]), x, lower=1)', label='blas_tbsv_lower'),
    T('blas_tpmv(3, [1,2,3,4,5,6], x)', 'B.dtpmv(3, np.array([1.,2,3,4,5,6]), x)'),
    T('blas_tpsv(3, [1,2,3,4,5,6], x)', 'B.dtpsv(3, np.array([1.,2,3,4,5,6]), x)'),
    T('blas_tpsv(3, [1,2,3,4,5,6], x, 1, 0, 1, 1)', 'B.dtpsv(3, np.array([1.,2,3,4,5,6]), x, lower=1, trans=1)', label='blas_tpsv_lower'),
    # level 3
    T('blas_gemm(1, M, M)', 'B.dgemm(1., M, M)'),
    T('blas_gemm(2, M, M, 1, M, 1, 0)', 'B.dgemm(2., M, M, beta=1., c=M, trans_a=1)', label='blas_gemm_t'),
    T('blas_gemm(1, Z, Z, 0, 0, 2, 1)', 'B.zgemm(1., Z, Z, trans_a=2, trans_b=1)', label='blas_gemm_c'),
    T('blas_symm(1, [4,1;9,5], [1,2,3;4,5,6])', 'B.dsymm(1., np.array([[4.,1],[9,5]]), np.array([[1.,2,3],[4,5,6]]))'),
    T('blas_symm(1, [4,1,0;9,5,0;1,2,3], [1,2,3;4,5,6], 0, 0, 1, 1)', 'B.dsymm(1., np.array([[4.,1,0],[9,5,0],[1,2,3]]), np.array([[1.,2,3],[4,5,6]]), side=1, lower=1)', label='blas_symm_right'),
    T('blas_hemm(1, Z, [1,2;3,4])', 'B.zhemm(1., Z, np.array([[1.,2],[3,4]]))'),
    T('blas_syrk(1, [1,2,3;4,5,6])', 'B.dsyrk(1., np.array([[1.,2,3],[4,5,6]]))'),
    T('blas_syrk(1, [1,2,3;4,5,6], 0, 0, 1, 1)', 'B.dsyrk(1., np.array([[1.,2,3],[4,5,6]]), trans=1, lower=1)', label='blas_syrk_t'),
    T('blas_herk(1, Z)', 'B.zherk(1., Z)'),
    T('blas_herk(1, Z, 0, 0, 2)', 'B.zherk(1., Z, trans=2)', label='blas_herk_c'),
    T('blas_syr2k(1, [1,2,3;4,5,6], [1,0,1;0,1,1])', 'B.dsyr2k(1., np.array([[1.,2,3],[4,5,6]]), np.array([[1.,0,1],[0,1,1]]))'),
    T('blas_her2k(1i, Z, [1,2;3,4])', 'B.zher2k(1j, Z, np.array([[1.,2],[3,4]]))'),
    T('blas_trmm(1, M, M)', 'B.dtrmm(1., M, M)'),
    T('blas_trmm(2, M, M, 1, 1, 1, 1)', 'B.dtrmm(2., M, M, side=1, lower=1, trans_a=1, diag=1)', label='blas_trmm_opts'),
    T('blas_trsm(1, M, M)', 'B.dtrsm(1., M, M)'),
    T('blas_trsm(1, M, [1,2,3;4,5,6], 1, 1, 1)', 'B.dtrsm(1., M, np.array([[1.,2,3],[4,5,6]]), side=1, lower=1, trans_a=1)', label='blas_trsm_right'),
    T('blas_trsm(1, Z, [1,2;3,4], 1, 0, 2)', 'B.ztrsm(1., Z, np.array([[1.,2],[3,4]]), side=1, trans_a=2)', label='blas_trsm_c'),
]

# SciPy's BLAS writes into its inputs (overwrite semantics); give every row
# fresh copies of the shared arrays.
import re as _re
for _t in ROWS:
    if isinstance(_t.py, str):
        _t.py = _re.sub(r'(?<![\w.])(x|y|zx|zy|M|Z|ab)\b(?!\s*=)', r'\1.copy()', _t.py)
