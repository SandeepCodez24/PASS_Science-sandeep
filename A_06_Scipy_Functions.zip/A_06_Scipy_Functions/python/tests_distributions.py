"""Section 22: every distribution family against scipy.stats.

For each family the shape parameters come from its spec Example; pdf/pmf, cdf
and sf are checked at the example's point (or at the median when the example
is a ppf), ppf at three probabilities, and rvs for its length and range."""
import json, os, re
from gen_tests import T

HERE = os.path.dirname(os.path.abspath(__file__))
SPEC = json.load(open(os.path.join(HERE, 'tools', 'spec1234.json'), encoding='utf-8'))

# Families whose spec Example only draws random numbers: shapes chosen here.
SHAPES = {'bernoulli': [0.3], 'uniform': [], 'poisson_binom': None}
TOL = {'kstwobign': 1e-7, 'levy_stable': 1e-5, 'studentized_range': 1e-6, 'landau': 1e-7, 'kstwo': 1e-6, 'genhyperbolic': 1e-7,
       'nchypergeom_wallenius': 1e-7, 'irwinhall': 1e-9}


def PY():
    import warnings
    warnings.simplefilter('ignore')
    from scipy import stats
    return dict(stats=stats)


def fmt(v):
    return repr(float(v))


ROWS = []
for e in SPEC:
    if e['phase'] != 4 or not e['section'].startswith('22'):
        continue
    sname = e['scipy'].split('.')[-1].strip()
    ex = e['example'].split('\n')[0]
    m = re.match(r'\w+\s*=\s*(\w+)_(pdf|pmf|cdf|sf|ppf|rvs)\((.*)\);$', ex)
    if not m:
        continue
    name, op, args = m.group(1), m.group(2), [a.strip() for a in m.group(3).split(',')]
    if name == 'poisson_binom':
        continue
    import scipy.stats as st
    dist = getattr(st, sname)
    disc = hasattr(dist, 'pmf')
    ns = dist.numargs
    if name in SHAPES:
        shapes = SHAPES[name]
        x0 = None
    else:
        shapes = [float(a) for a in args[1:1 + ns]]
        x0 = float(args[0])
        if op == 'ppf':
            x0 = None
    if x0 is None:
        x0 = float(dist.ppf(0.5, *shapes))
    sh = ''.join(', ' + fmt(s) for s in shapes)
    shp = ''.join(', ' + fmt(s) for s in shapes)
    tol = TOL.get(name, 1e-8)
    dens = 'pmf' if disc else 'pdf'
    ROWS.append(T('%s_%s(%s%s)' % (name, dens, fmt(x0), sh), 'stats.%s.%s(%s%s)' % (sname, dens, fmt(x0), shp), tol=tol))
    ROWS.append(T('%s_cdf(%s%s)' % (name, fmt(x0), sh), 'stats.%s.cdf(%s%s)' % (sname, fmt(x0), shp), tol=tol))
    ROWS.append(T('%s_sf(%s%s)' % (name, fmt(x0), sh), 'stats.%s.sf(%s%s)' % (sname, fmt(x0), shp), tol=tol))
    ROWS.append(T('%s_ppf([0.1, 0.5, 0.9]%s)' % (name, sh), 'stats.%s.ppf([0.1, 0.5, 0.9]%s)' % (sname, shp),
                  tol=max(tol, 1e-7)))
    import numpy as np
    if not np.all(dist._argcheck(*shapes)):
        continue  # the spec example uses invalid shapes (SciPy gives NaN): no draws to check
    # rvs: n values inside the support
    lo, hi = dist.support(*shapes)
    ROWS.append(T('rcheck(%s_rvs(%s%s), %s, %s)' % (name, ', '.join(fmt(s) for s in shapes) + (', ' if shapes else ''), '200',
                                                   '(-1/0)' if lo == -float('inf') else fmt(lo),
                                                   '(1/0)' if hi == float('inf') else fmt(hi)),
                  '1', label=name + '_rvs'))

NC_SETUP = '''function r = rcheck(v, lo, hi):
  r = (numel(v) == 200) * (min(v) >= lo) * (max(v) <= hi);
fnend
'''

ROWS += [
    # loc and scale
    T('norm_pdf([0.3, 2], 1, 2)', 'stats.norm.pdf([0.3, 2], 1, 2)', label='norm_loc_scale'),
    T('gamma_ppf(0.3, 2.5, 1, 3)', 'stats.gamma.ppf(0.3, 2.5, 1, 3)', label='gamma_loc_scale'),
    T('poisson_pmf(5, 3, 2)', 'stats.poisson.pmf(5, 3, 2)', label='poisson_loc'),
    T('binom_cdf([0, 3, 9, 10], 10, 0.3)', 'stats.binom.cdf([0, 3, 9, 10], 10, 0.3)', label='binom_cdf_array'),
    T('t_cdf([-40, -2, 0.5, 30], 3)', 'stats.t.cdf([-40, -2, 0.5, 30], 3)', label='t_cdf_tails'),
    T('norm_sf(10)', 'stats.norm.sf(10)', tol=1e-14, label='norm_sf_tail'),
    T('beta_ppf(1e-10, 2, 3)', 'stats.beta.ppf(1e-10, 2, 3)', tol=1e-10, label='beta_ppf_tail'),
    T('expon_pdf(-1)', '0', label='expon_outside'),
    T('norm_pdf(0, 0, -1)', 'float("nan")', label='norm_bad_scale'),
    T('gamma_pdf(1, -2)', 'float("nan")', label='gamma_bad_shape'),
    # poisson_binom (array shape)
    T('poisson_binom_pmf([0,1,2,3,4], [0.1, 0.6, 0.7, 0.8])', 'stats.poisson_binom.pmf([0,1,2,3,4], [0.1, 0.6, 0.7, 0.8])'),
    T('poisson_binom_cdf(2, [0.1, 0.6, 0.7, 0.8])', 'stats.poisson_binom.cdf(2, [0.1, 0.6, 0.7, 0.8])'),
    T('poisson_binom_sf(2, [0.1, 0.6, 0.7, 0.8])', 'stats.poisson_binom.sf(2, [0.1, 0.6, 0.7, 0.8])'),
    T('poisson_binom_ppf(0.5, [0.1, 0.6, 0.7, 0.8])', 'stats.poisson_binom.ppf(0.5, [0.1, 0.6, 0.7, 0.8])'),
    T('numel(poisson_binom_rvs([0.1, 0.6], 7))', '7', label='poisson_binom_rvs'),
]
