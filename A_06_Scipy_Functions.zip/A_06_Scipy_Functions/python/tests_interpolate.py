from gen_tests import T

NC_SETUP = '''x = space(0, 10, 11);
y = sin(x);
xq = [2.5, 3.5, 7.25];
g = space(0,1,5);
g6 = space(0,1,6);
function z = outer_add(u, v):
  z = zeros(numel(u), numel(v));
  for i = [0:numel(u)-1]:
    for j = [0:numel(v)-1]:
      z[i,j] = u[i] + v[j];
    fend
  fend
fnend
P = [0.1,0.2;0.15,0.82;0.9,0.8;0.92,0.15;0.5,0.1;0.52,0.54;0.2,0.9;0.25,0.35;0.7,0.3;0.6,0.75];
P_sum = P[:,0] * 1 + P[:,1] * 2;
Q = zeros(25,2);
for i = [0:4]:
  for j = [0:4]:
    Q[i*5+j,0] = i / 4;
    Q[i*5+j,1] = j / 4;
  fend
fend
Q_sum = Q[:,0] + Q[:,1];
'''

def PY():
    import numpy as np
    P = np.array([[0.1,0.2],[0.15,0.82],[0.9,0.8],[0.92,0.15],[0.5,0.1],[0.52,0.54],[0.2,0.9],[0.25,0.35],[0.7,0.3],[0.6,0.75]])
    return dict(xq=np.array([2.5,3.5,7.25]), P=P, P_sum=P[:,0]+2*P[:,1], I=interpolate_mod())

def interpolate_mod():
    import scipy.interpolate as I
    return I

ROWS = [
    *[T('interp1d(x, y, xq, "%s")' % k, 'I.interp1d(x, y, kind="%s")(xq)' % k, label='interp1d_' + k) for k in ('linear','nearest','quadratic','cubic')],
    T('spline_interp(x, y, xq, 3)', 'I.make_interp_spline(x, y, 3)(xq)'),
    T('spline_interp(x, y, xq, 2)', 'I.make_interp_spline(x, y, 2)(xq)', label='spline_interp2'),
    T('spline_interp(x, y, xq, 5)', 'I.make_interp_spline(x, y, 5)(xq)', label='spline_interp5'),
    *[T('cubic_spline(x, y, xq, "%s")' % b, 'I.CubicSpline(x, y, bc_type="%s")(xq)' % b, label='cubic_spline_' + b) for b in ('not-a-knot','natural','clamped')],
    T('cubic_spline(x, cos(x * 2 * pi / 10), xq, "periodic")', 'I.CubicSpline(x, np.cos(x*2*np.pi/10), bc_type="periodic")(xq)', label='cubic_spline_periodic'),
    T('pchip(x, y, xq)', 'I.PchipInterpolator(x, y)(xq)'), T('akima(x, y, xq)', 'I.Akima1DInterpolator(x, y)(xq)'),
    T('hermite_spline(x, y, cos(x), xq)', 'I.CubicHermiteSpline(x, y, np.cos(x))(xq)'),
    T('barycentric_interp(x[0:4], y[0:4], 2.5)', 'I.barycentric_interpolate(x[:5], y[:5], 2.5)'),
    T('krogh_interp(x[0:4], y[0:4], 2.5)', 'I.krogh_interpolate(x[:5], y[:5], 2.5)'),
    T('krogh_interp([0,0,1], [1,2,3], 0.5)', 'I.krogh_interpolate([0,0,1], [1,2,3], 0.5)', label='krogh_derivative'),
    T('floater_hormann(x, y, xq, 3)', 'I.FloaterHormannInterpolator(x, y, d=3)(xq)'),
    T('aaa_interp(x, y, xq)', 'I.AAA(x, y)(xq).real', tol=1e-4),
    T('ppoly_eval([1.0;0.0], [0,1], 0.5)', '0.5'),
    T('bpoly_eval([1.0;2.0;3.0], [0,1], 0.5)', '2'),
    T('ndppoly_eval([0,1;1,0], [0,1;0,1], [0.5,0.5])', '[1.0]'),
    T('bspline_eval([0,0,0,0,1,1,1,1], [1,2,3,4], 3, 0.5)', '2.5'),
    T('splev(xq, lsq_spline(x, y, [0,0,0,0,5,10,10,10,10], 3))', 'I.make_lsq_spline(x, y, [0,0,0,0,5,10,10,10,10], 3)(xq)', label='lsq_spline'),
    T('smoothing_spline(x, y, 2.5)', 'I.make_smoothing_spline(x, y)(2.5)', tol=5e-2),
    T('smoothing_spline(x, y, xq, 1.0)', 'I.make_smoothing_spline(x, y, lam=1.0)(xq)', label='smoothing_spline_lam', tol=1e-3),
    T('sum_sq(y, splev(x, spline_fit(x, y, 0.1)))', '0.1', label='spline_fit', tol=2e-2, setup='function s = sum_sq(a, b):\n  d = a - b;\n  s = sum(d *. d);\nfnend'),
    T('numel(spline_fit_curve([cos(x);sin(x)], 0.1)["u"])', '11', label='spline_fit_curve'),
    T('spline_knots(x, y, 0.1)', None),
    T('ndbspline_eval([0,0,1,1;0,0,1,1], [0,1;2,3], 1, [0.5,0.5])', '[1.5]'),
    T('splev(xq, splrep(x, y))', 'I.splev(xq, I.splrep(x, y))', label='splrep'),
    T('splev(xq, splrep(x, y, 2))', 'I.splev(xq, I.splrep(x, y, k=2))', label='splrep_k2', tol=1e-2),
    T('splev(xq, splrep(x, y), 1)', 'I.splev(xq, I.splrep(x, y), der=1)', label='splev'),
    T('splint(0, 3, splrep(x, y))', 'I.splint(0, 3, I.splrep(x, y))'),
    T('sproot(splrep(x, y))', 'I.sproot(I.splrep(x, y))', tol=1e-6),
    T('spalde(2.5, splrep(x, y))', 'I.spalde(2.5, I.splrep(x, y))'),
    T('splev(xq, splder(splrep(x, y)))', 'I.splev(xq, I.splder(I.splrep(x, y)))', label='splder'),
    T('splev(xq, splantider(splrep(x, y))) - splev(0, splantider(splrep(x, y)))', 'I.splev(xq, I.splantider(I.splrep(x, y))) - I.splev(0, I.splantider(I.splrep(x, y)))', label='splantider'),
    T('splev(xq, spline_insert_knot(2.5, splrep(x, y)))', 'I.splev(xq, I.splrep(x, y))', label='spline_insert_knot'),
    T('numel(splprep([cos(x);sin(x)], 0)["u"])', '11', label='splprep'),
    T('uni_spline(x, y, 2.5, 0)', 'I.InterpolatedUnivariateSpline(x, y)(2.5)', label='uni_spline_exact'),
    T('uni_spline(x, y, 2.5, 0.5)', None, label='uni_spline'),
    T('lsq_uni_spline(x, y, [3,6], 2.5)', 'I.LSQUnivariateSpline(x, y, [3,6])(2.5)'),
    T('griddata(P, P_sum, [0.5,0.5], "linear")', 'I.griddata(P, P_sum, [[0.5,0.5]], "linear")'),
    T('griddata(P, P_sum, [0.5,0.5], "nearest")', 'I.griddata(P, P_sum, [[0.5,0.5]], "nearest")', label='griddata_nearest'),
    T('griddata(P, P_sum, [0.5,0.5], "cubic")', '[1.5]', label='griddata_cubic', tol=1e-3),
    T('rbf_interp(P, P_sum, [0.5,0.5])', 'I.RBFInterpolator(P, P_sum)([[0.5,0.5]])'),
    T('rbf_interp(P, sin(P_sum), [0.5,0.5;0.3,0.4])', 'I.RBFInterpolator(P, np.sin(P_sum))([[0.5,0.5],[0.3,0.4]])', label='rbf_interp_2'),
    T('rbf_interp(P, sin(P_sum), [0.5,0.5], "cubic")', 'I.RBFInterpolator(P, np.sin(P_sum), kernel="cubic")([[0.5,0.5]])', label='rbf_interp_cubic'),
    T('grid_interp([g, g], outer_add(g, g), [0.5,0.25])', '[0.75]'),
    T('grid_interp([g, g], outer_add(g, g), [0.5,0.25], "nearest")', '[0.75]', label='grid_interp_nearest'),
    T('rect_bispline(g6, g6, outer_add(g6, g6), 0.5, 0.5)', '1'),
    T('bisplev(0.5, 0.5, smooth_bispline(Q[:,0], Q[:,1], Q_sum, 1, 1))', '1', label='smooth_bispline'),
    T('bisplev(0.5, 0.5, lsq_bispline(Q[:,0], Q[:,1], Q_sum, [0.5], [0.5], 1, 1))', '1', label='lsq_bispline'),
    T('bisplev(0.25, 0.5, bisplrep(Q[:,0], Q[:,1], Q_sum, 1, 1))', '0.75', label='bisplrep'),
    T('bisplev(0.25, 0.5, bisplrep(Q[:,0], Q[:,1], Q_sum, 1, 1))', '0.75', label='bisplev'),
    T('bisplev(0.5, 1.0, sphere_grid_spline(space(0.2,3,8), space(0.1,6,8), ones(8, 8)))', '1', label='sphere_grid_spline'),
    T('bisplev(0.25, 0.5, sphere_smooth_spline(Q[:,0], Q[:,1], Q_sum, 0))', '0.75', label='sphere_smooth_spline'),
    T('bisplev(0.25, 0.5, sphere_lsq_spline(Q[:,0] + 0.1, Q[:,1] + 0.1, ones(1,25), [1.0], [2.0]))', '1', label='sphere_lsq_spline'),
    T('lagrange([0,1,2], [1,3,7])', '[1,1,1]'),
    T('taylor_poly("sin", 0, 3, 1)', 'I.approximate_taylor_polynomial(np.sin, 0, 3, 1).coeffs', tol=1e-6),
    T('pade([1, 1, 1/2, 1/6, 1/24], 2)', 'I.pade([1,1,1/2,1/6,1/24],2)[0].coeffs', field='p'),
    T('pade([1, 1, 1/2, 1/6, 1/24], 2)', 'I.pade([1,1,1/2,1/6,1/24],2)[1].coeffs', field='q'),
]
