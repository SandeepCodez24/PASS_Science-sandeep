from gen_tests import T

NC_SETUP = '''function y = fj(v):
  y = [v[0]^2, v[0]*v[1]];
fnend
function y = fh(v):
  y = v[0]^2 * v[1];
fnend
function y = fe(v):
  y = exp(v[0]) * sin(v[1]);
fnend
function y = fe3(v):
  y = [sin(v[0]) + v[1]^3, v[2] * v[0], exp(v[1])];
fnend
'''

def PY():
    import numpy as np
    from scipy.differentiate import jacobian, hessian
    return dict(np=np, jacobian=jacobian, hessian=hessian)

ROWS = [
    T('jacobian("fj", [1.0, 2.0])', '[[2,0],[2,1]]', field='df', tol=1e-7),
    T('jacobian("fe3", [0.5, 1.5, 2.0])', 'jacobian(lambda v: np.array([np.sin(v[0])+v[1]**3, v[2]*v[0], np.exp(v[1])]), np.array([0.5,1.5,2.0])).df', field='df', tol=1e-7, label='jacobian_3'),
    T('jacobian("fj", [1.0, 2.0])["success"]', '1', label='jacobian_success'),
    T('hessian("fh", [1.0, 2.0])', '[[4,2],[2,0]]', field='ddf', tol=1e-6),
    T('hessian("fe", [0.5, 1.0])', 'hessian(lambda v: np.exp(v[0])*np.sin(v[1]), np.array([0.5,1.0])).ddf', field='ddf', tol=1e-6, label='hessian_exp'),
]
