from gen_tests import T

NC_SETUP = '''img = outer(sin(space(0, 3, 12)), cos(space(0, 2, 12))) + 0.1 * outer(cos(space(0, 9, 12)), sin(space(0, 7, 12)));
sig = sin(space(0, 9, 40));
F = fft2(img);
M = [0,0,1,1,0,0;0,1,1,1,0,1;0,0,0,0,0,1;1,1,0,0,1,1;1,1,0,1,0,1;0,0,0,1,1,1];
H = [1,1,1,1,1;1,0,0,0,1;1,0,0,0,1;1,0,0,0,1;1,1,1,1,1];
lbl = img_label(img > 0.4)["labels"];
ramp = [9,9,9,9,9,9;9,1,2,3,4,9;9,1,8,8,4,9;9,1,2,8,4,9;9,1,2,3,4,9;9,9,9,9,9,9];
mk = zeros(6,6);
mk[1,1] = 1;
mk[4,4] = 2;
function y = shift_half(p):
  y = [p[0] + 0.5, p[1] - 0.5];
fnend
function y = psd(v):
  y = sum(v *. v);
fnend
function y = line_up(v):
  y = v[1:numel(v)-2] * 2;
fnend
function y = mean_rows(w):
  y = sum(transpose(w)) / 9;
fnend
function y = d2(m, axis):
  y = img_correlate1d(m, [1,-2,1], axis);
fnend
'''

def PY():
    import numpy as np
    from scipy import ndimage as nd, fft as sf
    a = np.outer
    s = np.sin; c = np.cos; L = np.linspace
    img = a(s(L(0,3,12)), c(L(0,2,12))) + 0.1 * a(c(L(0,9,12)), s(L(0,7,12)))
    sig = s(L(0,9,40))
    M = np.array([[0,0,1,1,0,0],[0,1,1,1,0,1],[0,0,0,0,0,1],[1,1,0,0,1,1],[1,1,0,1,0,1],[0,0,0,1,1,1]]).astype(bool)
    H = np.array([[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1]]).astype(bool)
    lbl = nd.label(img > 0.4)[0]
    ramp = np.array([[9,9,9,9,9,9],[9,1,2,3,4,9],[9,1,8,8,4,9],[9,1,2,8,4,9],[9,1,2,3,4,9],[9,9,9,9,9,9]], dtype=np.uint8)
    mk = np.zeros((6,6), dtype=np.int16); mk[1,1] = 1; mk[4,4] = 2
    return dict(np=np, nd=nd, img=img, sig=sig, M=M, H=H, lbl=lbl, ramp=ramp, mk=mk, F=sf.fft2(img), sf=sf)

K3 = 'np.ones((3,3))'
MODES = ('reflect','constant','nearest','mirror','wrap')

ROWS = [
    T('img_convolve(img, ones(3,3) / 9)', 'nd.convolve(img, np.ones((3,3))/9)'),
    T('img_convolve(img, [1,2;3,4])', 'nd.convolve(img, np.array([[1,2],[3,4.]]))', label='img_convolve_even'),
    *[T('img_convolve(img, [1,2,3;4,5,6;7,8,0], "%s")' % m, 'nd.convolve(img, np.array([[1,2,3],[4,5,6],[7,8,0.]]), mode="%s")' % m, label='img_convolve_' + m) for m in MODES],
    T('img_convolve1d(sig, [1,2,1])', 'nd.convolve1d(sig, [1,2,1])'),
    T('img_convolve1d(img, [1,2,3,4], 0)', 'nd.convolve1d(img, [1,2,3,4], axis=0)', label='img_convolve1d_axis'),
    T('img_correlate(img, ones(3,3))', 'nd.correlate(img, np.ones((3,3)))'),
    T('img_correlate(img, [1,2;3,4])', 'nd.correlate(img, np.array([[1,2],[3,4.]]))', label='img_correlate_even'),
    T('img_correlate1d(sig, [1,0,-1])', 'nd.correlate1d(sig, [1,0,-1])'),
    T('img_correlate1d(img, [1,2,3,4], 1, "wrap")', 'nd.correlate1d(img, [1,2,3,4], axis=1, mode="wrap")', label='img_correlate1d_wrap'),
    T('gaussian_filter(img, 1)', 'nd.gaussian_filter(img, 1)'),
    T('gaussian_filter(img, [1,2])', 'nd.gaussian_filter(img, [1,2])', label='gaussian_filter_axes'),
    T('gaussian_filter1d(sig, 3)', 'nd.gaussian_filter1d(sig, 3)'),
    T('gaussian_filter1d(img, 1.5, 0, 1)', 'nd.gaussian_filter1d(img, 1.5, axis=0, order=1)', label='gaussian_filter1d_order'),
    T('gaussian_filter1d(sig, 2, -1, 3, "nearest")', 'nd.gaussian_filter1d(sig, 2, order=3, mode="nearest")', label='gaussian_filter1d_o3'),
    T('gaussian_gradient(img, 1)', 'nd.gaussian_gradient_magnitude(img, 1)'),
    T('gaussian_laplace(img, 1)', 'nd.gaussian_laplace(img, 1)'),
    T('img_generic_filter(img, "psd", 3)', 'nd.generic_filter(img, lambda v: np.sum(v*v), 3)'),
    T('img_generic_filter1d(sig, "line_up", 3)', 'nd.generic_filter1d(sig, lambda i,o: o.__setitem__(slice(None), i[1:-1]*2), 3)'),
    T('img_vector_filter(img, "mean_rows", 3)', 'nd.vectorized_filter(img, lambda w, axis: np.mean(w, axis=axis), size=3)', label='img_vector_filter'),
    T('img_generic_gradient(img, "sobel")', 'nd.generic_gradient_magnitude(img, nd.sobel)'),
    T('img_generic_laplace(img, "d2")', 'nd.generic_laplace(img, lambda m, axis, output, mode, cval: nd.correlate1d(m, [1,-2,1], axis, output, mode, cval))'),
    T('img_laplace(img)', 'nd.laplace(img)'),
    T('max_filter(img, 3)', 'nd.maximum_filter(img, 3)'),
    T('max_filter(img, 4)', 'nd.maximum_filter(img, 4)', label='max_filter_even'),
    T('max_filter1d(sig, 5)', 'nd.maximum_filter1d(sig, 5)'),
    T('min_filter(img, 3)', 'nd.minimum_filter(img, 3)'),
    T('min_filter1d(sig, 5)', 'nd.minimum_filter1d(sig, 5)'),
    T('median_filter(img, 3)', 'nd.median_filter(img, 3)'),
    T('percentile_filter(img, 75, 3)', 'nd.percentile_filter(img, 75, 3)'),
    T('rank_filter(img, 2, 3)', 'nd.rank_filter(img, 2, 3)'),
    T('prewitt(img, 0)', 'nd.prewitt(img, 0)'),
    T('sobel(img, 1)', 'nd.sobel(img, 1)'),
    T('uniform_filter(img, 3)', 'nd.uniform_filter(img, 3)'),
    T('uniform_filter(img, 4)', 'nd.uniform_filter(img, 4)', label='uniform_filter_even'),
    T('uniform_filter1d(sig, 5)', 'nd.uniform_filter1d(sig, 5)'),
    T('fourier_ellipsoid(F, 2)', 'nd.fourier_ellipsoid(F, 2)', tol=1e-6),
    T('fourier_gaussian(F, 1)', 'nd.fourier_gaussian(F, 1)'),
    T('fourier_shift(F, 2)', 'nd.fourier_shift(F, 2)'),
    T('fourier_shift(F, [1,2.5])', 'nd.fourier_shift(F, [1,2.5])', label='fourier_shift_axes'),
    T('fourier_uniform(F, 3)', 'nd.fourier_uniform(F, 3)'),
    T('fourier_gaussian(rfft2(img), 1, 12)', 'nd.fourier_gaussian(sf.rfft2(img), 1, n=12)', label='fourier_gaussian_real'),
    T('affine_transform(img, [1,0.2;0,1])', 'nd.affine_transform(img, np.array([[1,0.2],[0,1]]))'),
    T('affine_transform(img, [1,0.2;0,1], [0.5,1], 1)', 'nd.affine_transform(img, np.array([[1,0.2],[0,1]]), offset=[0.5,1], order=1)', label='affine_transform_order1'),
    *[T('affine_transform(img, [0.9,0.1;-0.1,1.1], [1,-1], 3, "%s")' % m, 'nd.affine_transform(img, np.array([[0.9,0.1],[-0.1,1.1]]), offset=[1,-1], order=3, mode="%s")' % m, label='affine_transform_' + m) for m in MODES],
    T('geometric_transform(img, "shift_half")', 'nd.geometric_transform(img, lambda p: (p[0]+0.5, p[1]-0.5))'),
    T('map_coordinates(img, [0.5,2.5;1.5,3.5], 1)', 'nd.map_coordinates(img, [[0.5,2.5],[1.5,3.5]], order=1)'),
    *[T('map_coordinates(img, [0.5,2.5,5.5;1.5,3.5,6.25], %d)' % o, 'nd.map_coordinates(img, [[0.5,2.5,5.5],[1.5,3.5,6.25]], order=%d)' % o, label='map_coordinates_o%d' % o) for o in (0,2,3,4,5)],
    T('img_rotate(img, 45, 0)', 'nd.rotate(img, 45, reshape=False)'),
    T('img_rotate(img, 30)', 'nd.rotate(img, 30)', label='img_rotate_reshape'),
    T('img_rotate(img, 90, 1, 1)', 'nd.rotate(img, 90, reshape=True, order=1)', label='img_rotate_90'),
    T('img_shift(img, [1.5, -2])', 'nd.shift(img, [1.5,-2])'),
    T('img_shift(img, [1.5, -2], 1)', 'nd.shift(img, [1.5,-2], order=1)', label='img_shift_order1'),
    T('img_zoom(img, 2)', 'nd.zoom(img, 2)'),
    T('img_zoom(img, [0.5,1.5], 1)', 'nd.zoom(img, [0.5,1.5], order=1)', label='img_zoom_axes'),
    *[T('spline_filter(img, %d)' % o, 'nd.spline_filter(img, %d)' % o, label='spline_filter_o%d' % o) for o in (2,3,4,5)],
    T('spline_filter(img, 3)', 'nd.spline_filter(img, 3)'),
    T('spline_filter1d(img, 3, 0)', 'nd.spline_filter1d(img, 3, 0)'),
    T('img_label(M)', 'nd.label(M)[0]', field='labels'),
    T('img_label(M)', 'nd.label(M)[1]', field='count', label='img_label_count'),
    T('img_label(M, ones(3,3))', 'nd.label(M, np.ones((3,3)))[0]', field='labels', label='img_label_struct'),
    T('find_objects(lbl)', '[[s.start for s in o][0:1] + [o[0].stop, o[1].start, o[1].stop] for o in nd.find_objects(lbl)]'),
    T('value_indices([1,1;2,0])["1"]', 'nd.value_indices(np.array([[1,1],[2,0]]))[1][1]', field='cols'),
    T('labeled_apply(img, lbl, [1,2], "sum", 0)', 'nd.labeled_comprehension(img, lbl, [1,2], np.sum, float, 0)'),
    T('center_of_mass(img)', 'nd.center_of_mass(img)'),
    T('center_of_mass(img, lbl, [1,2])', 'nd.center_of_mass(img, lbl, [1,2])', label='center_of_mass_lbl'),
    T('img_extrema(img)', 'nd.extrema(img)[1]', field='max'),
    T('img_extrema(img)', 'nd.extrema(img)[2]', field='min_pos', label='img_extrema_pos'),
    T('img_histogram(img, 0, 1, 5)', 'nd.histogram(img, 0, 1, 5)'),
    T('img_argmax(img)', 'nd.maximum_position(img)'),
    T('img_argmin(img)', 'nd.minimum_position(img)'),
    T('img_argmax(img, lbl, [1,2])', 'nd.maximum_position(img, lbl, [1,2])', label='img_argmax_lbl'),
    T('img_sum(img, lbl, [1,2])', 'nd.sum_labels(img, lbl, [1,2])'),
    T('watershed(ramp, mk)', 'nd.watershed_ift(ramp, mk)'),
    T('binary_closing(M)', 'nd.binary_closing(M)'),
    T('binary_dilation(M)', 'nd.binary_dilation(M)'),
    T('binary_dilation(M, ones(3,3), 2)', 'nd.binary_dilation(M, np.ones((3,3)), 2)', label='binary_dilation_iter'),
    T('binary_erosion(M)', 'nd.binary_erosion(M)'),
    T('binary_erosion(M, ones(2,2))', 'nd.binary_erosion(M, np.ones((2,2)))', label='binary_erosion_even'),
    T('binary_dilation(M, ones(2,2))', 'nd.binary_dilation(M, np.ones((2,2)))', label='binary_dilation_even'),
    T('binary_fill_holes(H)', 'nd.binary_fill_holes(H)'),
    T('binary_hit_or_miss(M)', 'nd.binary_hit_or_miss(M)'),
    T('binary_hit_or_miss(M, [0,1,0;1,1,1;0,1,0], [1,0,1;0,0,0;1,0,1])', 'nd.binary_hit_or_miss(M, np.array([[0,1,0],[1,1,1],[0,1,0]]), np.array([[1,0,1],[0,0,0],[1,0,1]]))', label='binary_hit_or_miss_2'),
    T('binary_opening(M)', 'nd.binary_opening(M)'),
    T('binary_propagation(img > 0.9, img > 0.3)', 'nd.binary_propagation(img > 0.9, mask=img > 0.3)'),
    T('black_tophat(img, 3)', 'nd.black_tophat(img, 3)'),
    T('white_tophat(img, 3)', 'nd.white_tophat(img, 3)'),
    T('distance_bf(M)', 'nd.distance_transform_bf(M)'),
    T('distance_bf(M, "taxicab")', 'nd.distance_transform_bf(M, "taxicab")', label='distance_bf_taxicab'),
    T('distance_cdt(M)', 'nd.distance_transform_cdt(M)'),
    T('distance_cdt(M, "taxicab")', 'nd.distance_transform_cdt(M, "taxicab")', label='distance_cdt_taxicab'),
    T('distance_edt(M)', 'nd.distance_transform_edt(M)'),
    T('distance_edt(M, [2,1])', 'nd.distance_transform_edt(M, sampling=[2,1])', label='distance_edt_sampling'),
    T('binary_structure(2, 1)', 'nd.generate_binary_structure(2, 1)'),
    T('binary_structure(2, 2)', 'nd.generate_binary_structure(2, 2)', label='binary_structure_2'),
    T('iterate_structure(binary_structure(2, 1), 2)', 'nd.iterate_structure(nd.generate_binary_structure(2, 1), 2)'),
    T('grey_closing(img, 3)', 'nd.grey_closing(img, 3)'),
    T('grey_dilation(img, 3)', 'nd.grey_dilation(img, 3)'),
    T('grey_dilation(img, 4)', 'nd.grey_dilation(img, 4)', label='grey_dilation_even'),
    T('grey_erosion(img, 3)', 'nd.grey_erosion(img, 3)'),
    T('grey_opening(img, 3)', 'nd.grey_opening(img, 3)'),
    T('morph_gradient(img, 3)', 'nd.morphological_gradient(img, 3)'),
    T('morph_laplace(img, 3)', 'nd.morphological_laplace(img, 3)'),
]
