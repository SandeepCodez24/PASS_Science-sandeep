"""Section 21 (scipy.stats statistics, distribution values, multivariate, QMC,
samplers) against SciPy. Rows that depend on random numbers only check that
the call runs, or a property that holds for every draw."""
import numpy as np
from gen_tests import T

_rng = np.random.default_rng(7)
DATA = np.round(_rng.normal(0.3, 1.0, 20), 4)
DATA2 = np.round(_rng.normal(0.0, 1.5, 20), 4)
DATA3 = DATA2[:15]
POS = np.round(np.exp(DATA), 4)


def _arr(v):
    return '[' + ', '.join(repr(float(x)) for x in v) + ']'


def PY():
    import warnings
    warnings.simplefilter('ignore')
    from scipy import stats
    from scipy.stats import qmc
    return dict(stats=stats, qmc=qmc, data=DATA, data2=DATA2, data3=DATA3, pos=POS)


NC_SETUP = '''x = space(0, 10, 11);
y = sin(x);
data = %s;
data2 = %s;
data3 = %s;
pos = %s;
function r = mean_diff(a, b):
  r = mean(a) - mean(b);
fnend
function r = bell(x):
  r = exp(-x^2/2) / sqrt(2*pi);
fnend
function r = dbell(x):
  r = -x * exp(-x^2/2) / sqrt(2*pi);
fnend
function r = gen(n):
  r = norm_rvs(0, 1, n);
fnend
function r = model(X):
  r = X[0,:] + 2 * X[1,:];
fnend
function r = colsum2(T):
  r = T[0,:] + T[1,:];
fnend
function r = ncmean(v):
  r = mean(v);
fnend
function r = inside(v, lo, hi):
  r = (min(v) >= lo) * (max(v) <= hi);
fnend
function r = isorth(Q):
  n = size(Q)[0];
  r = max(abs(flatten(Q * transpose(Q) - unit_matrix(n)))) < 1e-10;
fnend
''' % (_arr(DATA), _arr(DATA2), _arr(DATA3), _arr(POS))

ROWS = [
    # ---- descriptive ----
    T('describe(data)', 'stats.describe(data).nobs', field='nobs'),
    T('describe(data)', 'stats.describe(data).minmax', field='minmax'),
    T('describe(data)', 'stats.describe(data).mean', field='mean'),
    T('describe(data)', 'stats.describe(data).variance', field='variance'),
    T('describe(data)', 'stats.describe(data).skewness', field='skewness'),
    T('describe(data)', 'stats.describe(data).kurtosis', field='kurtosis'),
    T('power_mean([1,2,4], 2)', 'stats.pmean([1,2,4], 2)'),
    T('power_mean(pos, -1.5)', 'stats.pmean(pos, -1.5)'),
    T('moment(data, 3)', 'stats.moment(data, 3)'),
    T('lmoment(data)', 'stats.lmoment(data)'),
    T('expectile(data, 0.8)', 'stats.expectile(data, 0.8)'),
    T('kstat(data, 2)', 'stats.kstat(data, 2)'),
    T('kstat(data, 4)', 'stats.kstat(data, 4)'),
    T('kstat_var(data, 2)', 'stats.kstatvar(data, 2)'),
    T('trimmed_mean(data, [-1, 1])', 'stats.tmean(data, (-1, 1))'),
    T('trimmed_var(data, [-1, 1])', 'stats.tvar(data, (-1, 1))'),
    T('trimmed_min(data, -1)', 'stats.tmin(data, -1)'),
    T('trimmed_max(data, 1)', 'stats.tmax(data, 1)'),
    T('trimmed_sd(data, [-1, 1])', 'stats.tstd(data, (-1, 1))'),
    T('trimmed_sem(data, [-1, 1])', 'stats.tsem(data, (-1, 1))'),
    T('rank_data([40,10,30,10])', 'stats.rankdata([40,10,30,10])'),
    T('rank_data([40,10,30,10], "dense")', 'stats.rankdata([40,10,30,10], "dense")'),
    T('tie_correct(rank_data([40,10,30,10]))', 'stats.tiecorrect(stats.rankdata([40,10,30,10]))'),
    T('geo_sd([1,2,4,8])', 'stats.gstd([1,2,4,8])'),
    T('geo_zscore([1,2,4,8])', 'stats.gzscore([1,2,4,8])'),
    T('zmap([0.5, 1.0], data)', 'stats.zmap([0.5, 1.0], data)'),
    T('entropy([0.5,0.5], 0, 2)', 'stats.entropy([0.5,0.5], base=2)'),
    T('entropy([0.2,0.8], [0.5,0.5])', 'stats.entropy([0.2,0.8], [0.5,0.5])'),
    T('differential_entropy(data)', 'stats.differential_entropy(data)'),
    T('differential_entropy(data, 0, "ebrahimi")', 'stats.differential_entropy(data, method="ebrahimi")'),
    T('median_abs_dev(data)', 'stats.median_abs_deviation(data)'),
    T('cum_freq(data, 5)', 'stats.cumfreq(data, 5).cumcount', field='cumcount'),
    T('cum_freq(data, 5)', 'stats.cumfreq(data, 5).lowerlimit', field='lowerlimit'),
    T('cum_freq(data, 5)', 'stats.cumfreq(data, 5).binsize', field='binsize'),
    T('rel_freq(data, 5)', 'stats.relfreq(data, 5).frequency', field='frequency'),
    T('percentile_of_score([1,2,3,4], 3)', 'stats.percentileofscore([1,2,3,4], 3)'),
    T('binned_stat(x, y, "mean", 3)', 'stats.binned_statistic(x, y, "mean", 3).statistic', field='statistic'),
    T('binned_stat(x, y, "mean", 3)', 'stats.binned_statistic(x, y, "mean", 3).bin_edges', field='bin_edges'),
    T('binned_stat(x, y, "mean", 3)', 'stats.binned_statistic(x, y, "mean", 3).binnumber', field='binnumber'),
    T('binned_stat2d(x, y, x, "count", 2)', 'stats.binned_statistic_2d(x, y, x, "count", 2).statistic', field='statistic'),
    T('obrien_transform([1,2,3], [4,5,7])', 'stats.obrientransform([1,2,3], [4,5,7])'),
    T('sigma_clip(data, 2, 2)', 'stats.sigmaclip(data, 2, 2).clipped', field='clipped'),
    T('sigma_clip(data, 2, 2)', 'stats.sigmaclip(data, 2, 2).lower', field='lower'),
    T('trim_both(data, 0.1)', 'np.sort(stats.trimboth(data, 0.1))'),
    T('trim_one(space(0, 9, 10), 0.1, "left")', 'stats.trim1(np.arange(10.), 0.1, "left")'),
    T('boxcox_fit(pos)', 'stats.boxcox(pos)[1]', field='lambda', tol=1e-5),
    T('boxcox_fit(pos)', 'stats.boxcox(pos)[0]', field='data', tol=1e-5),
    T('boxcox_normmax(pos)', 'stats.boxcox_normmax(pos)', tol=1e-5),
    T('boxcox_llf(0.5, pos)', 'stats.boxcox_llf(0.5, pos)'),
    T('yeojohnson_fit(data)', 'stats.yeojohnson(data)[1]', field='lambda', tol=1e-5),
    T('yeojohnson_normmax(data)', 'stats.yeojohnson_normmax(data)', tol=1e-5),
    T('yeojohnson_llf(0.5, data)', 'stats.yeojohnson_llf(0.5, data)'),
    T('ppcc_max(data)', 'stats.ppcc_max(data)', tol=1e-4),
    T('prob_plot(data)', 'stats.probplot(data)[0][0]', field='osm'),
    T('prob_plot(data)', 'stats.probplot(data)[1][0]', field='slope'),
    T('prob_plot(data)', 'stats.probplot(data)[1][2]', field='r'),
    T('circ_mean([0.1, 2*pi - 0.1, 0.5])', 'stats.circmean([0.1, 2*np.pi - 0.1, 0.5])'),
    T('circ_var([0.1, 2*pi - 0.1, 0.5])', 'stats.circvar([0.1, 2*np.pi - 0.1, 0.5])'),
    T('circ_sd([0.1, 2*pi - 0.1, 0.5])', 'stats.circstd([0.1, 2*np.pi - 0.1, 0.5])'),
    T('directional_stats([1,0;0.9,0.1])', 'stats.directional_stats(np.array([[1,0],[0.9,0.1]])).mean_direction', field='mean_direction'),
    T('wasserstein(data, data2)', 'stats.wasserstein_distance(data, data2)'),
    T('energy_distance(data, data2)', 'stats.energy_distance(data, data2)'),
    T('gaussian_kde(data, [0.0, 1.0])', 'stats.gaussian_kde(data)([0.0, 1.0])'),
    T('margins([1,2;3,4])', 'stats.contingency.margins(np.array([[1,2],[3,4]]))[0]', field='rows'),
    T('expected_freq([10,20;20,10])', 'stats.contingency.expected_freq(np.array([[10,20],[20,10]]))'),
    T('association([10,20;25,10], "cramer")', 'stats.contingency.association(np.array([[10,20],[25,10]]), "cramer")'),
    T('relative_risk(8, 10, 1, 6)', 'stats.contingency.relative_risk(8, 10, 1, 6).relative_risk', field='relative_risk'),
    # ---- correlation ----
    T('pearsonr(data, data2)', 'stats.pearsonr(data, data2).statistic', field='statistic'),
    T('pearsonr(data, data2)', 'stats.pearsonr(data, data2).pvalue', field='pvalue'),
    T('spearmanr(data, data2)', 'stats.spearmanr(data, data2).statistic', field='statistic'),
    T('spearmanr(data, data2)', 'stats.spearmanr(data, data2).pvalue', field='pvalue'),
    T('kendalltau(data, data2)', 'stats.kendalltau(data, data2).statistic', field='statistic'),
    T('kendalltau(data, data2)', 'stats.kendalltau(data, data2).pvalue', field='pvalue'),
    T('weighted_tau(data, data2)', 'stats.weightedtau(data, data2).statistic', field='statistic'),
    T('somers_d(data, data2)', 'stats.somersd(data, data2).statistic', field='statistic'),
    T('somers_d(data, data2)', 'stats.somersd(data, data2).pvalue', field='pvalue', tol=1e-6),
    T('point_biserial([0,0,1,1,0,1], [1.0,2.0,3.0,4.0,2.5,3.5])', 'stats.pointbiserialr([0,0,1,1,0,1], [1.0,2.0,3.0,4.0,2.5,3.5]).pvalue', field='pvalue'),
    T('chatterjee_xi(data, data2)', 'stats.chatterjeexi(data, data2).statistic', field='statistic'),
    T('chatterjee_xi(data, data2)', 'stats.chatterjeexi(data, data2).pvalue', field='pvalue'),
    T('theil_slopes(2*x + 1 + y, x)', 'stats.theilslopes(2*x + 1 + y, x).slope', field='slope'),
    T('theil_slopes(2*x + 1 + y, x)', 'stats.theilslopes(2*x + 1 + y, x).low_slope', field='low_slope'),
    T('siegel_slopes(2*x + 1 + y, x)', 'stats.siegelslopes(2*x + 1 + y, x).slope', field='slope'),
    T('mgc_test(x, x ^. 2, 10, 1)', 'stats.multiscale_graphcorr(x, x ** 2, reps=10).statistic', field='statistic'),
    T('mgc_test(data, data2, 5, 1)', 'stats.multiscale_graphcorr(data, data2, reps=5).statistic', field='statistic'),
    # ---- one- and two-sample tests ----
    T('ttest_1samp(data, 0)', 'stats.ttest_1samp(data, 0).pvalue', field='pvalue'),
    T('ttest_ind(data, data3)', 'stats.ttest_ind(data, data3).pvalue', field='pvalue'),
    T('ttest_from_stats(0, 1, 30, 0.5, 1, 30)', 'stats.ttest_ind_from_stats(0, 1, 30, 0.5, 1, 30).pvalue', field='pvalue'),
    T('ttest_rel(data, data2)', 'stats.ttest_rel(data, data2).pvalue', field='pvalue'),
    T('binom_test(7, 10, 0.5)', 'stats.binomtest(7, 10, 0.5).pvalue', field='pvalue'),
    T('quantile_test(data, 0, 0.5)', 'stats.quantile_test(data, q=0, p=0.5).pvalue', field='pvalue'),
    T('skew_test(data)', 'stats.skewtest(data).pvalue', field='pvalue'),
    T('kurtosis_test(data)', 'stats.kurtosistest(data).pvalue', field='pvalue'),
    T('normal_test(data)', 'stats.normaltest(data).pvalue', field='pvalue'),
    T('jarque_bera(data)', 'stats.jarque_bera(data).pvalue', field='pvalue'),
    T('shapiro(data)', 'stats.shapiro(data).statistic', field='statistic', tol=1e-6),
    T('shapiro(data)', 'stats.shapiro(data).pvalue', field='pvalue', tol=1e-6),
    T('anderson(data, "norm")', 'stats.anderson(data, "norm").statistic', field='statistic'),
    T('cramer_vonmises(data, "norm")', 'stats.cramervonmises(data, "norm").statistic', field='statistic'),
    T('cramer_vonmises(data, "norm")', 'stats.cramervonmises(data, "norm").pvalue', field='pvalue', tol=1e-6),
    T('ks_1samp(data, "norm_cdf")', 'stats.ks_1samp(data, stats.norm.cdf).pvalue', field='pvalue'),
    T('ks_1samp(data, "gamma", 2)', 'stats.ks_1samp(data, stats.gamma(2).cdf).statistic', field='statistic'),
    T('ks_test(data, "norm")', 'stats.kstest(data, "norm").pvalue', field='pvalue'),
    T('ks_test(data, data3)', 'stats.kstest(data, data3).pvalue', field='pvalue'),
    T('power_divergence([16,18,16,14,12,12], 0, "log-likelihood")', 'stats.power_divergence([16,18,16,14,12,12], lambda_="log-likelihood").statistic', field='statistic'),
    T('power_divergence([16,18,16,14,12,12], 0, "log-likelihood")', 'stats.power_divergence([16,18,16,14,12,12], lambda_="log-likelihood").pvalue', field='pvalue'),
    T('mann_whitney(data, data3)', 'stats.mannwhitneyu(data, data3).pvalue', field='pvalue'),
    T('wilcoxon(data - data2)', 'stats.wilcoxon(data - data2).pvalue', field='pvalue'),
    T('rank_sums(data, data3)', 'stats.ranksums(data, data3).pvalue', field='pvalue'),
    T('brunner_munzel(data, data3)', 'stats.brunnermunzel(data, data3).pvalue', field='pvalue'),
    T('ks_2samp(data, data3)', 'stats.ks_2samp(data, data3).pvalue', field='pvalue'),
    T('cramer_vonmises_2samp(data, data3)', 'stats.cramervonmises_2samp(data, data3).pvalue', field='pvalue', tol=1e-6),
    T('epps_singleton(data, data3)', 'stats.epps_singleton_2samp(data, data3).pvalue', field='pvalue', tol=1e-6),
    T('ansari(data, data3)', 'stats.ansari(data, data3).pvalue', field='pvalue'),
    T('mood_test(data, data3)', 'stats.mood(data, data3).pvalue', field='pvalue'),
    T('bws_test(data, data3)', 'stats.bws_test(data, data3).statistic', field='statistic'),
    T('poisson_means_test(10, 100, 15, 100)', 'stats.poisson_means_test(10, 100, 15, 100).pvalue', field='pvalue', tol=1e-6),
    T('barnard_exact([7,12;8,3])', 'stats.barnard_exact(np.array([[7,12],[8,3]])).pvalue', field='pvalue', tol=1e-6),
    T('boschloo_exact([7,12;8,3])', 'stats.boschloo_exact(np.array([[7,12],[8,3]])).pvalue', field='pvalue', tol=1e-6),
    T('fisher_exact([8,2;1,5])', 'stats.fisher_exact(np.array([[8,2],[1,5]])).pvalue', field='pvalue'),
    T('odds_ratio([8,2;1,5])', 'stats.contingency.odds_ratio(np.array([[8,2],[1,5]])).statistic', field='statistic', tol=1e-6),
    # ---- k-sample tests ----
    T('anova_oneway(data, data3, data + 1)', 'stats.f_oneway(data, data3, data + 1).pvalue', field='pvalue'),
    T('tukey_hsd(data, data3, data + 1)', 'stats.tukey_hsd(data, data3, data + 1).statistic', field='statistic'),
    T('tukey_hsd(data, data3, data + 1)', 'stats.tukey_hsd(data, data3, data + 1).pvalue', field='pvalue', tol=1e-5),
    T('dunnett(data3, data + 1, data)', 'stats.dunnett(data3, data + 1, control=data).statistic', field='statistic'),
    T('dunnett(data3, data + 1, data)', 'stats.dunnett(data3, data + 1, control=data).pvalue', field='pvalue', tol=1e-4),
    T('kruskal(data, data3)', 'stats.kruskal(data, data3).pvalue', field='pvalue'),
    T('alexander_govern(data, data3)', 'stats.alexandergovern(data, data3).pvalue', field='pvalue'),
    T('fligner(data, data3)', 'stats.fligner(data, data3).pvalue', field='pvalue'),
    T('levene(data, data3)', 'stats.levene(data, data3).pvalue', field='pvalue'),
    T('levene(data, data3, "mean")', 'stats.levene(data, data3, center="mean").pvalue', field='pvalue'),
    T('bartlett(data, data3)', 'stats.bartlett(data, data3).pvalue', field='pvalue'),
    T('median_test(data, data3)', 'stats.median_test(data, data3).pvalue', field='pvalue'),
    T('median_test(data, data3)', 'stats.median_test(data, data3).table', field='table'),
    T('friedman(data, data2, data + 1)', 'stats.friedmanchisquare(data, data2, data + 1).pvalue', field='pvalue'),
    T('anderson_ksamp(data, data3)', 'stats.anderson_ksamp([data, data3]).statistic', field='statistic'),
    T('anderson_ksamp(data, data3)', 'stats.anderson_ksamp([data, data3]).pvalue', field='pvalue', tol=1e-6),
    T('page_trend_test([1,2,3;2,1,3;1,3,2;1,2,3;3,1,2])', 'stats.page_trend_test(np.array([[1,2,3],[2,1,3],[1,3,2],[1,2,3],[3,1,2]])).pvalue', field='pvalue'),
    T('page_trend_test([1,2,3;2,1,3;1,3,2;1,2,3;3,1,2])', 'stats.page_trend_test(np.array([[1,2,3],[2,1,3],[1,3,2],[1,2,3],[3,1,2]])).statistic', field='statistic'),
    T('logrank(censored_data([1,3,5], [6]), censored_data([2,4], [7,8]))',
      'stats.logrank(stats.CensoredData([1,3,5], right=[6]), stats.CensoredData([2,4], right=[7,8])).pvalue', field='pvalue'),
    T('chi2_contingency([10,20;20,10])', 'stats.chi2_contingency(np.array([[10,20],[20,10]])).statistic', field='statistic'),
    T('chi2_contingency([10,20;20,10])', 'stats.chi2_contingency(np.array([[10,20],[20,10]])).pvalue', field='pvalue'),
    T('chi2_contingency([10,20,5;20,10,9])', 'stats.chi2_contingency(np.array([[10,20,5],[20,10,9]])).pvalue', field='pvalue'),
    T('combine_pvalues([0.01, 0.2, 0.3])', 'stats.combine_pvalues([0.01, 0.2, 0.3]).pvalue', field='pvalue'),
    T('combine_pvalues([0.01, 0.2, 0.3], "stouffer")', 'stats.combine_pvalues([0.01, 0.2, 0.3], "stouffer").pvalue', field='pvalue'),
    T('combine_pvalues([0.01, 0.2, 0.3], "pearson")', 'stats.combine_pvalues([0.01, 0.2, 0.3], "pearson").pvalue', field='pvalue'),
    T('combine_pvalues([0.01, 0.2, 0.3], "tippett")', 'stats.combine_pvalues([0.01, 0.2, 0.3], "tippett").pvalue', field='pvalue'),
    T('combine_pvalues([0.01, 0.2, 0.3], "mudholkar_george")', 'stats.combine_pvalues([0.01, 0.2, 0.3], "mudholkar_george").pvalue', field='pvalue'),
    T('fdr_adjust([0.01,0.02,0.2,0.5])', 'stats.false_discovery_control([0.01,0.02,0.2,0.5])'),
    T('fdr_adjust([0.01,0.02,0.2,0.5], "by")', 'stats.false_discovery_control([0.01,0.02,0.2,0.5], method="by")'),
    T('goodness_of_fit("norm", data, 19)', 'stats.goodness_of_fit(stats.norm, data, n_mc_samples=19).statistic', field='statistic', tol=1e-5),
    # ---- resampling (random: statistic or structure only) ----
    T('monte_carlo_test(data, "norm", "ncmean", 99)', 'np.mean(data)', field='statistic'),
    T('numel(monte_carlo_test(data, "gen", "ncmean", 20)["null_distribution"])', '20', label='monte_carlo_test.null'),
    T('permutation_test(data[0:4], data[5:8], "mean_diff", 1000)',
      'stats.permutation_test((data[0:5], data[5:9]), lambda a, b: np.mean(a) - np.mean(b), n_resamples=1000).pvalue', field='pvalue',
      label='permutation_test_exact'),
    T('permutation_test(data, data2, "mean_diff", 99)', 'np.mean(data) - np.mean(data2)', field='statistic'),
    T('numel(bootstrap(data, "ncmean", 200)["confidence_interval"])', '2', label='bootstrap'),
    T('bootstrap(data, "ncmean", 200, 0.9, "percentile")', None, field='standard_error'),
    T('test_power("ttest_ind", ["norm","norm"], [20,20], 50)', None, field='power'),
    T('sobol_indices("model", 256, ["uniform","uniform"])', None, field='first_order'),
    # ---- distribution values ----
    T('dist_cdf(normal_dist(0, 1), 1.96)', 'stats.norm.cdf(1.96)'),
    T('dist_mean(uniform_dist(0, 1))', '0.5'),
    T('dist_pdf(logistic_dist(), 0.0)', '0.25'),
    T('dist_pmf(binomial_dist(10, 0.5), 5)', 'stats.binom.pmf(5, 10, 0.5)'),
    T('dist_pdf(mixture_dist(normal_dist(-2,1), normal_dist(2,1), [0.5,0.5]), 0.0)', 'stats.norm.pdf(2)', label='mixture_dist'),
    T('dist_var(mixture_dist(normal_dist(-2,1), normal_dist(2,3), [0.3,0.7]))',
      'stats.Mixture([stats.Normal(mu=-2,sigma=1), stats.Normal(mu=2,sigma=3)], weights=[0.3,0.7]).variance()', label='mixture_dist.var'),
    T('dist_mean(order_stat_dist(normal_dist(0,1), 2, 5))', 'stats.order_statistic(stats.Normal(), r=2, n=5).mean()', tol=1e-8),
    T('dist_mean(truncate_dist(normal_dist(0,1), 0))', 'stats.truncnorm.mean(0, np.inf)'),
    T('dist_mean(abs_dist(normal_dist(0,1)))', 'np.sqrt(2/np.pi)'),
    T('dist_median(exp_dist(normal_dist(0,1)))', '1'),
    T('dist_mean(exp_dist(normal_dist(0,1)))', 'np.exp(0.5)', tol=1e-8),
    T('dist_mean(log_dist(uniform_dist(1, 2)))', '2*np.log(2) - 1'),
    T('dist_cdf(custom_dist("bell"), 0)', '0.5'),
    T('dist_ppf(custom_dist("bell"), 0.975)', 'stats.norm.ppf(0.975)', tol=1e-8),
    T('dist_mean(custom_discrete_dist([1,2,3,4,5,6], ones(1, 6) / 6))', '3.5'),
    T('dist_cdf(custom_discrete_dist([1,2,3,4,5,6], ones(1, 6) / 6), 2.5)', '1/3'),
    T('dist_cdf(hist_dist([1,2,1], [0,1,2,3]), 1.5)', 'stats.rv_histogram(([1,2,1],[0,1,2,3])).cdf(1.5)'),
    T('dist_var(hist_dist([1,2,1], [0,1,2,3]))', 'stats.rv_histogram(([1,2,1],[0,1,2,3])).var()'),
    T('dist_cdf(make_dist("norm"), 0.0)', '0.5'),
    T('dist_sf(make_dist("gamma", dict(["a", "scale"], [2, 3])), 4)', 'stats.gamma.sf(4, 2, scale=3)'),
    T('dist_std(make_dist("t", dict(["df"], [5])))', 'stats.t.std(5)'),
    T('inside(dist_rvs(normal_dist(0,1), 50), -10, 10)', '1', label='dist_rvs'),
    T('mvs_dist(data)["mean"]["shapes"]', '[19]', label='mvs_dist'),
    T('dist_mean(mvs_dist(data)["var"])', 'stats.mvsdist(data)[1].mean()', label='mvs_dist.var'),
    T('bayes_mvs(data, 0.9)["mean"]["minmax"]', 'stats.bayes_mvs(data, 0.9)[0].minmax', label='bayes_mvs.mean'),
    T('bayes_mvs(data, 0.9)["var"]["minmax"]', 'stats.bayes_mvs(data, 0.9)[1].minmax', label='bayes_mvs.var'),
    T('bayes_mvs(data, 0.9)["std"]["statistic"]', 'stats.bayes_mvs(data, 0.9)[2].statistic', label='bayes_mvs.std'),
    T('dist_fit("norm", data, dict(["loc","scale"], [-5,5;0.1,5]))', '[np.mean(data), np.std(data)]', field='params', tol=1e-6),
    T('censored_data([1.0, 2.0], [3.0])', '[3.0]', field='right'),
    T('cov_diagonal([1.0, 2.0])', 'np.diag([1.0, 2.0])'),
    # ---- multivariate ----
    T('mvnormal_pdf([0,0], [0,0], unit_matrix(2))', 'stats.multivariate_normal.pdf([0,0], [0,0], np.eye(2))'),
    T('mvnormal_pdf([0.3,-1], [0,1], [2,0.5;0.5,1])', 'stats.multivariate_normal.pdf([0.3,-1], [0,1], [[2,0.5],[0.5,1]])'),
    T('mvnormal_pdf([0.3,-1], [0,1], cov_diagonal([1.0, 2.0]))', 'stats.multivariate_normal.pdf([0.3,-1], [0,1], np.diag([1.0, 2.0]))'),
    T('mvt_pdf([0,0], [0,0], unit_matrix(2), 5)', 'stats.multivariate_t.pdf([0,0], [0,0], np.eye(2), 5)'),
    T('mvt_pdf([0.3,-1], [0,1], [2,0.5;0.5,1], 3.5)', 'stats.multivariate_t.pdf([0.3,-1], [0,1], [[2,0.5],[0.5,1]], 3.5)'),
    T('dirichlet_pdf([0.2,0.3,0.5], [1,2,3])', 'stats.dirichlet.pdf([0.2,0.3,0.5], [1,2,3])'),
    T('dirichlet_multinomial_pmf([2,3,5], [1,2,3], 10)', 'stats.dirichlet_multinomial.pmf([2,3,5], [1,2,3], 10)'),
    T('multinomial_pmf([3,4], 7, [0.4,0.6])', 'stats.multinomial.pmf([3,4], 7, [0.4,0.6])'),
    T('mv_hypergeom_pmf([1,2], [5,5], 3)', 'stats.multivariate_hypergeom.pmf([1,2], [5,5], 3)'),
    T('normal_inv_gamma_pdf(0.5, 1.0, 0, 1, 2, 1)', 'stats.normal_inverse_gamma.pdf(0.5, 1.0, 0, 1, 2, 1)'),
    T('vonmises_fisher_pdf([1,0,0], [1,0,0], 5)', 'stats.vonmises_fisher.pdf([1,0,0], [1,0,0], 5)'),
    T('vonmises_fisher_pdf([0.6,0.8,0,0], [1,0,0,0], 2.5)', 'stats.vonmises_fisher.pdf([0.6,0.8,0,0], [1,0,0,0], 2.5)'),
    T('size(matrix_normal_rvs(zeros(2,3), unit_matrix(2), unit_matrix(3)))', '[2, 3]', label='matrix_normal_rvs'),
    T('size(matrix_t_rvs(zeros(2,2), unit_matrix(2), unit_matrix(2), 5))', '[2, 2]', label='matrix_t_rvs'),
    T('size(wishart_rvs(3, unit_matrix(2)))', '[2, 2]', label='wishart_rvs'),
    T('size(invwishart_rvs(4, unit_matrix(2)))', '[2, 2]', label='invwishart_rvs'),
    T('isorth(rand_orthogonal(4))', '1', label='rand_orthogonal'),
    T('det(rand_rotation(3))', '1', label='rand_rotation'),
    T('size(rand_unitary(3))', '[3, 3]', label='rand_unitary'),
    T('diag(rand_correlation([0.5, 1.5, 1.0]))', '[1, 1, 1]', label='rand_correlation'),
    T('colsum2(rand_table([3,2], [2,3]))', '[2, 3]', label='rand_table'),
    T('sum(rand_direction(3) ^. 2)', '1', label='rand_direction'),
    # ---- QMC ----
    T('sobol_sample(2, 3)', 'qmc.Sobol(2, scramble=False).random_base2(3)'),
    T('sobol_sample(7, 4)', 'qmc.Sobol(7, scramble=False).random_base2(4)'),
    T('halton_sample(3, 8)', 'qmc.Halton(3, scramble=False).random(8)'),
    T('size(latin_hypercube(2, 8))', '[8, 2]', label='latin_hypercube'),
    T('size(poisson_disk(2, 0.2, 8))[1]', '2', label='poisson_disk'),
    T('sum(flatten(multinomial_qmc([0.2,0.3,0.5], 10, 2)))', '20', label='multinomial_qmc'),
    T('size(mvnormal_qmc([0,0], unit_matrix(2), 4))', '[4, 2]', label='mvnormal_qmc'),
    T('discrepancy(halton_sample(2, 16))', 'qmc.discrepancy(qmc.Halton(2, scramble=False).random(16))'),
    T('discrepancy(halton_sample(2, 16), "WD")', 'qmc.discrepancy(qmc.Halton(2, scramble=False).random(16), method="WD")'),
    T('discrepancy(halton_sample(2, 16), "MD")', 'qmc.discrepancy(qmc.Halton(2, scramble=False).random(16), method="MD")'),
    T('discrepancy(halton_sample(2, 16), "L2-star")', 'qmc.discrepancy(qmc.Halton(2, scramble=False).random(16), method="L2-star")'),
    T('geometric_discrepancy(halton_sample(2, 16))', 'qmc.geometric_discrepancy(qmc.Halton(2, scramble=False).random(16))'),
    T('geometric_discrepancy(halton_sample(2, 16), "mst")', 'qmc.geometric_discrepancy(qmc.Halton(2, scramble=False).random(16), method="mst")'),
    T('update_discrepancy([0.5,0.5], halton_sample(2, 8), discrepancy(halton_sample(2, 8)))',
      'qmc.update_discrepancy([0.5,0.5], qmc.Halton(2, scramble=False).random(8), qmc.discrepancy(qmc.Halton(2, scramble=False).random(8)))'),
    T('qmc_scale(halton_sample(2, 4), [0,10], [1,20])', 'qmc.scale(qmc.Halton(2, scramble=False).random(4), [0,10], [1,20])'),
    # ---- samplers ----
    T('numel(sample_inverse_poly("norm", 5))', '5', label='sample_inverse_poly'),
    T('numel(sample_inverse_hermite(normal_dist(2, 3), 5))', '5', label='sample_inverse_hermite'),
    T('numel(sample_fast_inverse("norm", 5))', '5', label='sample_fast_inverse'),
    T('numel(sample_tdr("bell", "dbell", 5))', '5', label='sample_tdr'),
    T('abs(mean(sample_tdr("bell", "dbell", 4000))) < 0.1', '1', label='sample_tdr.mean'),
    T('numel(sample_ratio_uniforms("bell", 0, 1, 5))', '5', label='sample_ratio_uniforms_simple'),
    T('numel(sample_ratio_uniforms("bell", 0.64, -0.86, 0.86, 5))', '5', label='sample_ratio_uniforms'),
    T('inside(sample_discrete_alias([0.2,0.3,0.5], 50), 0, 2)', '1', label='sample_discrete_alias'),
    T('inside(sample_discrete_guide([0.2,0.3,0.5], 50), 0, 2)', '1', label='sample_discrete_guide'),
    T('abs(mean(sample_discrete_alias([0.2,0.3,0.5], 20000)) - 1.3) < 0.03', '1', label='sample_discrete_alias.mean'),
    T('abs(mean(sample_discrete_guide([0.2,0.3,0.5], 20000)) - 1.3) < 0.03', '1', label='sample_discrete_guide.mean'),
    # functions that had no row before the phase 5 example work
    T('binned_stat_dd([0.1,0.2;0.6,0.7;0.3,0.9;0.8,0.1], [1,2,3,4], "mean", 2)', 'stats.binned_statistic_dd(np.array([[0.1,0.2],[0.6,0.7],[0.3,0.9],[0.8,0.1]]), [1,2,3,4], "mean", 2).statistic', field='statistic'),
    T('binned_stat_dd([0.1,0.2;0.6,0.7;0.3,0.9;0.8,0.1], 0, "count", 2)', 'stats.binned_statistic_dd(np.array([[0.1,0.2],[0.6,0.7],[0.3,0.9],[0.8,0.1]]), None, "count", 2).statistic', field='statistic', label='binned_stat_dd_count'),
    T('boxcox_normplot(pos, -1, 1, 3)', 'stats.boxcox_normplot(pos, -1, 1, N=3)[1]', field='ppcc'),
    T('yeojohnson_normplot(data, -1, 1, 3)', 'stats.yeojohnson_normplot(data, -1, 1, N=3)[1]', field='ppcc'),
    T('ppcc_plot(pos, 1, 3, "tukeylambda", 3)', 'stats.ppcc_plot(pos, 1, 3, "tukeylambda", N=3)[1]', field='ppcc'),
    T('crosstab([1,2,1,2,1], [3,3,4,4,4])', 'stats.contingency.crosstab([1,2,1,2,1], [3,3,4,4,4]).count', field='count'),
    T('ecdf(data, [0.0, 1.0])', 'stats.ecdf(data).cdf.evaluate([0.0, 1.0])'),
    T('ecdf(data)', 'stats.ecdf(data).cdf.probabilities', field='probabilities'),
    T('estimated_cdf(data, [-3.0, 0.0, 1.0, 5.0])', 'stats.estimated_cdf(data, [-3.0, 0.0, 1.0, 5.0])'),
    T('estimated_cdf(data, [0.0, 1.0], "inverted_cdf")', 'stats.estimated_cdf(data, [0.0, 1.0], method="inverted_cdf")', label='estimated_cdf_inverted'),
    T('estimated_cdf(data, [0.0, 1.0], "hazen")', 'stats.estimated_cdf(data, [0.0, 1.0], method="hazen")', label='estimated_cdf_hazen'),
    T('spearman_rho(data, data2)', 'stats.spearmanrho(data, data2).statistic', field='statistic'),
    T('spearman_rho(data, data2, "less")', 'stats.spearmanrho(data, data2, alternative="less").pvalue', field='pvalue', label='spearman_rho_less'),
    T('wasserstein_nd([0,0;1,1;2,0], [0,1;1,0;2,2])', 'stats.wasserstein_distance_nd([[0,0],[1,1],[2,0]], [[0,1],[1,0],[2,2]])'),
    T('pearsonr_ci(data, data2, "bootstrap", 99)', None, field='low'),
]
