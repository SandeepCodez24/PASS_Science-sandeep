from gen_tests import T

# Wider coverage of section 20 than the spec examples: arrays over large ranges,
# complex input and edge values. The distributions (section 22) rest on these kernels.


def PY():
    import warnings
    warnings.simplefilter('ignore')
    return {}


XA = '[0.001,0.1,0.5,1,2.5,7,15,40,120]'
VA = '[0,1,2.5,-1.5,30,0.3,5,100,0]'
XP = '[0.001,0.1,0.5,1,2.5,7,15,40,120]'
VP = '[0,1,2.5,-1.5,30,0.3,5,100,0]'


def bessel(name):
    return T('%s(%s, %s)' % (name, VA, XA), 'scipy.special.%s(%s, %s)' % (name, VP, XP), tol=1e-10, label=name + '_range')


ROWS = [
    T('gamma([-2.5,-0.5,0.1,1.5,10,50,170.5])', 'scipy.special.gamma([-2.5,-0.5,0.1,1.5,10,50,170.5])', tol=1e-12, label='gamma_range'),
    T('gamma([1+2i, -0.5+0.3i, 3.2-4i])', 'scipy.special.gamma([1+2j,-0.5+0.3j,3.2-4j])', tol=1e-12, label='gamma_complex'),
    T('loggamma([1+2i, -3.5+0.3i, 30-40i])', 'scipy.special.loggamma([1+2j,-3.5+0.3j,30-40j])', tol=1e-12, label='loggamma_complex'),
    T('gammaln([-2.5,0.001,3.5,1e5])', 'scipy.special.gammaln([-2.5,0.001,3.5,1e5])', tol=1e-12, label='gammaln_range'),
    T('digamma([-2.5,0.001,1.4616,7,1e4])', 'scipy.special.digamma([-2.5,0.001,1.4616,7,1e4])', tol=1e-10, label='digamma_range'),
    T('digamma(1+2i)', 'scipy.special.digamma(1+2j)', tol=1e-12, label='digamma_complex'),
    T('polygamma([1,2,3], [0.5,4,-1.5])', 'scipy.special.polygamma([1,2,3],[0.5,4,-1.5])', tol=1e-10, label='polygamma_range'),
    T('zeta([0.5,1.5,3,-3,-2.5])', 'scipy.special.zeta([0.5,1.5,3,-3,-2.5])', tol=1e-10, label='zeta_riemann'),
    T('zeta([2,3.5], [0.3,7])', 'scipy.special.zeta([2,3.5],[0.3,7])', tol=1e-12, label='zeta_hurwitz'),
    T('zetac([0.5,2,10,60])', 'scipy.special.zetac([0.5,2,10,60])', tol=1e-10, label='zetac_range'),
    T('beta([0.5,30,1e-3], [2,40,5])', 'scipy.special.beta([0.5,30,1e-3],[2,40,5])', tol=1e-11, label='beta_range'),
    T('betaln([1e7,0.5], [2.5,1e-3])', 'scipy.special.betaln([1e7,0.5],[2.5,1e-3])', tol=1e-11, label='betaln_range'),
    T('binom([10.5,-3.5,100], [3,2,50])', 'scipy.special.binom([10.5,-3.5,100],[3,2,50])', tol=1e-11, label='binom_range'),
    T('poch([2.5,-3.5,10], [3.2,2,-2.5])', 'scipy.special.poch([2.5,-3.5,10],[3.2,2,-2.5])', tol=1e-11, label='poch_range'),
    T('gammainc([0.5,5,50,500,1e4], [0.1,6,45,520,1e4])', 'scipy.special.gammainc([0.5,5,50,500,1e4],[0.1,6,45,520,1e4])', tol=1e-11, label='gammainc_range'),
    T('gammaincc([0.5,5,50,500,1e4], [0.1,6,45,520,1.02e4])', 'scipy.special.gammaincc([0.5,5,50,500,1e4],[0.1,6,45,520,1.02e4])', tol=1e-10, label='gammaincc_range'),
    T('gammaincinv([0.1,2,50,800], [1e-10,0.3,0.5,0.999])', 'scipy.special.gammaincinv([0.1,2,50,800],[1e-10,0.3,0.5,0.999])', tol=1e-10, label='gammaincinv_range'),
    T('gammainccinv([0.1,2,50], [1e-12,0.7,0.01])', 'scipy.special.gammainccinv([0.1,2,50],[1e-12,0.7,0.01])', tol=1e-10, label='gammainccinv_range'),
    T('betainc([0.5,5,200,2000,0.1], [0.5,3,300,1500,20], [0.2,0.9,0.4,0.57,1e-5])', 'scipy.special.betainc([0.5,5,200,2000,0.1],[0.5,3,300,1500,20],[0.2,0.9,0.4,0.57,1e-5])', tol=1e-10, label='betainc_range'),
    T('betaincinv([0.5,5,200,0.1], [0.5,3,300,20], [1e-8,0.95,0.5,0.3])', 'scipy.special.betaincinv([0.5,5,200,0.1],[0.5,3,300,20],[1e-8,0.95,0.5,0.3])', tol=1e-10, label='betaincinv_range'),
    T('erf([-3,0.01,0.5,2,6])', 'scipy.special.erf([-3,0.01,0.5,2,6])', tol=1e-14, label='erf_range'),
    T('erf([1+1i, 0.1-2i, 3+0.5i])', 'scipy.special.erf([1+1j,0.1-2j,3+0.5j])', tol=1e-12, label='erf_complex'),
    T('erfc([1+1i, -2+0.5i, 4-1i])', 'scipy.special.erfc([1+1j,-2+0.5j,4-1j])', tol=1e-12, label='erfc_complex'),
    T('erfcx([-5,0.5,3,30,1e4])', 'scipy.special.erfcx([-5,0.5,3,30,1e4])', tol=1e-13, label='erfcx_range'),
    T('wofz([1+1i, 0.5-0.3i, 5+0.1i, -3+2i])', 'scipy.special.wofz([1+1j,0.5-0.3j,5+0.1j,-3+2j])', tol=1e-12, label='wofz_complex'),
    T('dawsn([-1,0.01,3,20])', 'scipy.special.dawsn([-1,0.01,3,20])', tol=1e-13, label='dawsn_range'),
    T('erfinv([-0.999999,-0.3,1e-10,0.7])', 'scipy.special.erfinv([-0.999999,-0.3,1e-10,0.7])', tol=1e-12, label='erfinv_range'),
    T('ndtri([1e-300,1e-10,0.3,0.999999])', 'scipy.special.ndtri([1e-300,1e-10,0.3,0.999999])', tol=1e-12, label='ndtri_range'),
    T('log_ndtr([-40,-5,0,5,40])', 'scipy.special.log_ndtr([-40,-5,0,5,40])', tol=1e-12, label='log_ndtr_range'),
    T('ndtri_exp([-1000,-50,-0.5,-1e-10])', 'scipy.special.ndtri_exp([-1000,-50,-0.5,-1e-10])', tol=1e-11, label='ndtri_exp_range'),
    T('owens_t([0.5,3,-1], [0.3,5,-2])', 'scipy.special.owens_t([0.5,3,-1],[0.3,5,-2])', tol=1e-11, label='owens_t_range'),
    T('expi([-3,0.5,30,100])', 'scipy.special.expi([-3,0.5,30,100])', tol=1e-12, label='expi_range'),
    T('expn([0,1,3,10], [0.5,2,0.1,30])', 'scipy.special.expn([0,1,3,10],[0.5,2,0.1,30])', tol=1e-12, label='expn_range'),
    T('sici(-3)', 'scipy.special.sici(-3.0)[1]', field='ci', label='sici_negative'),
    T('shichi(25)', 'scipy.special.shichi(25.0)[1]', field='chi', tol=1e-12, label='shichi_large'),
    T('fresnel(7.5)', 'scipy.special.fresnel(7.5)[0]', field='S', tol=1e-12, label='fresnel_large'),
    T('spence([0,0.2,1.5,4])', 'scipy.special.spence([0,0.2,1.5,4])', tol=1e-12, label='spence_range'),
    T('spence(1+2i)', 'scipy.special.spence(1+2j)', tol=1e-12, label='spence_complex'),
    T('lambertw(-0.2, -1)', 'scipy.special.lambertw(-0.2,-1)', tol=1e-12, label='lambertw_branch'),
    T('lambertw(2+3i)', 'scipy.special.lambertw(2+3j)', tol=1e-12, label='lambertw_complex'),
    T('wrightomega([-50,-1,3,1e3])', 'scipy.special.wrightomega([-50,-1,3,1e3])', tol=1e-12, label='wrightomega_range'),
    T('kolmogorov([0.2,0.8,1.5,3])', 'scipy.special.kolmogorov([0.2,0.8,1.5,3])', tol=1e-12, label='kolmogorov_range'),
    T('smirnov([5,50,500], [0.1,0.2,0.05])', 'scipy.special.smirnov([5,50,500],[0.1,0.2,0.05])', tol=1e-10, label='smirnov_range'),
    bessel('jv'), bessel('yv'), bessel('iv'), bessel('kv'),
    T('ive([0.5,3], [700,1e4])', 'scipy.special.ive([0.5,3],[700,1e4])', tol=1e-11, label='ive_large'),
    T('jv([0,1.5,3], [1+2i, -2+0.5i, 10-1i])', 'scipy.special.jv([0,1.5,3],[1+2j,-2+0.5j,10-1j])', tol=1e-10, label='jv_complex'),
    T('yv([0,1.5,3], [1+2i, -2+0.5i, 10-1i])', 'scipy.special.yv([0,1.5,3],[1+2j,-2+0.5j,10-1j])', tol=1e-10, label='yv_complex'),
    T('kv([0,1.5,3], [1+2i, -2+0.5i, 10-1i])', 'scipy.special.kv([0,1.5,3],[1+2j,-2+0.5j,10-1j])', tol=1e-10, label='kv_complex'),
    T('iv([0,1.5,3], [1+2i, -2+0.5i, 10-1i])', 'scipy.special.iv([0,1.5,3],[1+2j,-2+0.5j,10-1j])', tol=1e-10, label='iv_complex'),
    T('hankel1(1.5, [-2, 3+1i])', 'scipy.special.hankel1(1.5,[-2,3+1j])', tol=1e-10, label='hankel1_complex'),
    T('airy(-10)', 'scipy.special.airy(-10.0)[0]', field='Ai', tol=1e-10, label='airy_negative'),
    T('airy(8)', 'scipy.special.airy(8.0)[3]', field='Bip', tol=1e-10, label='airy_large'),
    T('struve([0,1,-1.5], [15,40,3])', 'scipy.special.struve([0,1,-1.5],[15,40,3])', tol=1e-9, label='struve_range'),
    T('modstruve([-0.5,2], [50,12])', 'scipy.special.modstruve([-0.5,2],[50,12])', tol=1e-10, label='modstruve_range'),
    T('kelvin(20)', 'scipy.special.kelvin(20.0)[0]', field='Be', tol=1e-9, label='kelvin_large'),
    T('ker([5,15])', 'scipy.special.ker([5,15])', tol=1e-9, label='ker_range'),
    T('spherical_jn([0,3,10], [0.01,5,2])', 'scipy.special.spherical_jn([0,3,10],[0.01,5,2])', tol=1e-11, label='spherical_jn_range'),
    T('spherical_kn(1, -2.0)', 'scipy.special.spherical_kn(1,-2.0)', label='spherical_kn_negative'),
    T('jn_zeros(5, 4)', 'scipy.special.jn_zeros(5,4)', tol=1e-12, label='jn_zeros_order5'),
    T('jnjnp_zeros(6)', 'scipy.special.jnjnp_zeros(6)[1]', field='n', label='jnjnp_zeros_n'),
    T('jnjnp_zeros(6)', 'scipy.special.jnjnp_zeros(6)[2]', field='m', label='jnjnp_zeros_m'),
    T('ellipkinc([0.5,4,-2], [0.9,0.3,-1.5])', 'scipy.special.ellipkinc([0.5,4,-2],[0.9,0.3,-1.5])', tol=1e-12, label='ellipkinc_range'),
    T('ellipk([-10,0.999999,0])', 'scipy.special.ellipk([-10,0.999999,0])', tol=1e-12, label='ellipk_range'),
    T('ellipj(7, 0.99)', 'scipy.special.ellipj(7,0.99)[2]', field='dn', tol=1e-10, label='ellipj_dn'),
    T('hyp2f1([1,0.5,2.5,-3], [2,0.5,1.5,1], [3,1.5,3.5,2.5], [0.95,-5,0.99,0.7])', 'scipy.special.hyp2f1([1,0.5,2.5,-3],[2,0.5,1.5,1],[3,1.5,3.5,2.5],[0.95,-5,0.99,0.7])', tol=1e-9, label='hyp2f1_range'),
    T('hyp1f1([2,-1.5,0.5], [5,3,0.3], [-20,8,100])', 'scipy.special.hyp1f1([2,-1.5,0.5],[5,3,0.3],[-20,8,100])', tol=1e-9, label='hyp1f1_range'),
    T('hyperu([0.5,3,-2], [1.5,0.2,1], [3,0.1,4])', 'scipy.special.hyperu([0.5,3,-2],[1.5,0.2,1],[3,0.1,4])', tol=1e-9, label='hyperu_range'),
    T('hyp0f1([0.5,3], [-30,20])', 'scipy.special.hyp0f1([0.5,3],[-30,20])', tol=1e-10, label='hyp0f1_range'),
    T('stdtr([1,5,50], [-3,0.7,2])', 'scipy.special.stdtr([1,5,50],[-3,0.7,2])', tol=1e-12, label='stdtr_range'),
    T('stdtrit([1,5,50], [0.01,0.7,0.999])', 'scipy.special.stdtrit([1,5,50],[0.01,0.7,0.999])', tol=1e-10, label='stdtrit_range'),
    T('nctdtr([3,20], [-1,4], [0.5,5])', 'scipy.special.nctdtr([3,20],[-1,4],[0.5,5])', tol=1e-10, label='nctdtr_range'),
    T('chndtr([3,50], [4,10], [2,30])', 'scipy.special.chndtr([3,50],[4,10],[2,30])', tol=1e-11, label='chndtr_range'),
    T('ncfdtr([3,10], [7,20], [2,15], [1.5,4])', 'scipy.special.ncfdtr([3,10],[7,20],[2,15],[1.5,4])', tol=1e-11, label='ncfdtr_range'),
    T('fdtri([1,10,50], [3,40,5], [0.001,0.5,0.999])', 'scipy.special.fdtri([1,10,50],[3,40,5],[0.001,0.5,0.999])', tol=1e-10, label='fdtri_range'),
    T('bdtrik([0.3,0.9], [10,50], [0.5,0.2])', 'scipy.special.bdtrik([0.3,0.9],[10,50],[0.5,0.2])', tol=1e-9, label='bdtrik_range'),
    T('eval_jacobi([3,10], [0.5,2], [-0.5,1], [0.3,-0.8])', 'scipy.special.eval_jacobi([3,10],[0.5,2],[-0.5,1],[0.3,-0.8])', tol=1e-11, label='eval_jacobi_range'),
    T('eval_legendre([2.5,30], [0.3,0.9])', 'scipy.special.eval_legendre([2.5,30],[0.3,0.9])', tol=1e-11, label='eval_legendre_range'),
    T('roots_legendre(20)', 'scipy.special.roots_legendre(20)[1]', field='weights', tol=1e-12, label='roots_legendre_20'),
    T('roots_hermite(30)', 'scipy.special.roots_hermite(30)[0]', field='nodes', tol=1e-11, label='roots_hermite_30'),
    T('roots_jacobi(7, -0.5, 2.5)', 'scipy.special.roots_jacobi(7,-0.5,2.5)[1]', field='weights', tol=1e-11, label='roots_jacobi_7'),
    T('roots_genlaguerre(6, -0.5)', 'scipy.special.roots_genlaguerre(6,-0.5)[0]', field='nodes', tol=1e-11, label='roots_genlaguerre_6'),
    T('lpmv([0,1,3], [2.5,4,3.3], [0.2,-0.7,0.95])', 'scipy.special.lpmv([0,1,3],[2.5,4,3.3],[0.2,-0.7,0.95])', tol=1e-10, label='lpmv_range'),
    T('mathieu_a([0,5,10], [1,15,25])', 'scipy.special.mathieu_a([0,5,10],[1,15,25])', tol=1e-10, label='mathieu_a_range'),
    T('mathieu_b([1,4], [30,0.5])', 'scipy.special.mathieu_b([1,4],[30,0.5])', tol=1e-10, label='mathieu_b_range'),
    T('mathieu_modcem1(1, 5, 0.5)', 'scipy.special.mathieu_modcem1(1,5,0.5)[0]', field='y', tol=1e-8, label='mathieu_modcem1_m1'),
    T('mathieu_modsem2(1, 5, 0.5)', 'scipy.special.mathieu_modsem2(1,5,0.5)[1]', field='yp', tol=1e-8, label='mathieu_modsem2_m1'),
    T('pbdv([2.5,-1.5], [-3.0,2.0])', 'scipy.special.pbdv([2.5,-1.5],[-3.0,2.0])[0]', field='d', tol=1e-9, label='pbdv_range'),
    T('legendre_p(2, [0.1,0.5], 1)', 'scipy.special.legendre_p(2,np.array([0.1,0.5]),diff_n=1)', tol=1e-12, label='legendre_p_array'),
    T('assoc_legendre_p_all(3, 2, 0.4)', 'scipy.special.assoc_legendre_p_all(3,2,0.4)', tol=1e-12, label='assoc_legendre_p_all_3_2'),
    T('softmax([1,2;3,4], 0)', 'scipy.special.softmax(np.array([[1.,2],[3,4]]),axis=0)', tol=1e-14, label='softmax_axis'),
    T('logsumexp([1,2,3], "all", [1,2,3])', 'scipy.special.logsumexp([1.,2,3],b=[1,2,3])', tol=1e-14, label='logsumexp_weights'),
    T('logsumexp([1,2;3,4], 1)', 'scipy.special.logsumexp(np.array([[1.,2],[3,4]]),axis=1)', tol=1e-14, label='logsumexp_axis'),
    T('comb(10, 3, 1)', '120', label='comb_exact'),
    T('stirling2(10, 3)', '9330', label='stirling2_10'),
    T('euler_numbers(10)', 'scipy.special.euler(10)', label='euler_10'),
    # SciPy's own B4 is off by 2e-12; the exact numbers are B0..B10
    T('bernoulli(10)', '[1, -1/2, 1/6, 0, -1/30, 0, 1/42, 0, -1/30, 0, 5/66]', tol=1e-14, label='bernoulli_10'),
]
