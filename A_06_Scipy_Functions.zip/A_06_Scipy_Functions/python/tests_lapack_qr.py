"""Section 25, LAPACK part 4: QR, RQ and RZ factorisations, forming and
applying their Q, reflectors and rotations, and the least-squares drivers."""
import re as _re
from gen_tests import T

NC_SETUP = '''M = [1,2,3;4,5,6;7,8,10];
R = [1,2;3,4;5,6];
W = [1,2,3;4,5,6];
Z = [1+1i,2;3,4-1i;5i,6];
'''


def PY():
    import numpy as np
    from scipy.linalg import lapack as L
    M = np.array([[1., 2, 3], [4, 5, 6], [7, 8, 10]])
    R = np.array([[1., 2], [3, 4], [5, 6]])
    W = np.array([[1., 2, 3], [4, 5, 6]])
    Z = np.array([[1 + 1j, 2], [3, 4 - 1j], [5j, 6]])
    return dict(L=L, np=np, M=M, R=R, W=W, Z=Z)


ROWS = [
    T('lapack_geqrf(M)', 'L.dgeqrf(M)[0]', field='qr'),
    T('lapack_geqrf(M)', 'L.dgeqrf(M)[1]', field='tau'),
    T('lapack_geqrf(R)', 'L.dgeqrf(R)[0]', field='qr', label='lapack_geqrf_tall'),
    T('lapack_geqrf(W)', 'L.dgeqrf(W)[0]', field='qr', label='lapack_geqrf_wide'),
    T('lapack_geqrf(Z)', 'L.zgeqrf(Z)[0]', field='qr', label='lapack_geqrf_c'),
    T('lapack_geqrf(Z)', 'L.zgeqrf(Z)[1]', field='tau', label='lapack_geqrf_ctau'),
    T('lapack_geqrfp(M)', 'L.dgeqrfp(M)[0]', field='qr'),
    T('lapack_geqrfp(M)', 'L.dgeqrfp(M)[1]', field='tau', label='lapack_geqrfp_tau'),
    T('lapack_geqrfp(Z)', 'L.zgeqrfp(Z)[0]', field='qr', label='lapack_geqrfp_c'),
    T('lapack_geqp3(M)', 'L.dgeqp3(M)[0]', field='qr'),
    T('lapack_geqp3(M)', 'L.dgeqp3(M)[1]', field='jpvt'),
    T('lapack_geqp3(M)', 'L.dgeqp3(M)[2]', field='tau', label='lapack_geqp3_tau'),
    T('lapack_geqp3(Z)', 'L.zgeqp3(Z)[0]', field='qr', label='lapack_geqp3_c'),
    T('lapack_geqrt(2, M)', 'L.dgeqrt(2, M)[0]', field='a'),
    T('lapack_geqrt(2, M)', 'L.dgeqrt(2, M)[1]', field='t'),
    T('lapack_geqrt(1, R)', 'L.dgeqrt(1, R)[1]', field='t', label='lapack_geqrt_nb1'),
    T('lapack_geqrt(2, Z)', 'L.zgeqrt(2, Z)[1]', field='t', label='lapack_geqrt_c'),
    T('lapack_gemqrt(lapack_geqrt(2, M)["a"], lapack_geqrt(2, M)["t"], [1,2;3,4;5,6])',
      '(lambda f: L.dgemqrt(f[0], f[1], np.array([[1.,2],[3,4],[5,6]]))[0])(L.dgeqrt(2, M))', field='c'),
    T('lapack_gemqrt(lapack_geqrt(2, M)["a"], lapack_geqrt(2, M)["t"], [1,2,3;4,5,6], "R", "T")',
      '(lambda f: L.dgemqrt(f[0], f[1], np.array([[1.,2,3],[4,5,6]]), side="R", trans="T")[0])(L.dgeqrt(2, M))', field='c', label='lapack_gemqrt_rt'),
    T('lapack_gerqf(M)', 'L.dgerqf(M)[0]', field='qr'),
    T('lapack_gerqf(M)', 'L.dgerqf(M)[1]', field='tau'),
    T('lapack_gerqf(W)', 'L.dgerqf(W)[0]', field='qr', label='lapack_gerqf_wide'),
    T('lapack_gerqf(R)', 'L.dgerqf(R)[0]', field='qr', label='lapack_gerqf_tall'),
    T('lapack_gerqf(Z)', 'L.zgerqf(Z)[0]', field='qr', label='lapack_gerqf_c'),
    T('lapack_orgqr(lapack_geqrf(R)["qr"], lapack_geqrf(R)["tau"])', '(lambda f: L.dorgqr(f[0], f[1])[0])(L.dgeqrf(R))', field='q'),
    T('lapack_orgqr(lapack_geqrf(M)["qr"], lapack_geqrf(M)["tau"])', '(lambda f: L.dorgqr(f[0], f[1])[0])(L.dgeqrf(M))', field='q', label='lapack_orgqr_sq'),
    T('lapack_ungqr(lapack_geqrf(Z)["qr"], lapack_geqrf(Z)["tau"])', '(lambda f: L.zungqr(f[0], f[1])[0])(L.zgeqrf(Z))', field='q'),
    T('lapack_orgrq(lapack_gerqf(W)["qr"], lapack_gerqf(W)["tau"])', '(lambda f: L.dorgrq(f[0], f[1])[0])(L.dgerqf(W))', field='q'),
    T('lapack_orgrq(lapack_gerqf(M)["qr"], lapack_gerqf(M)["tau"])', '(lambda f: L.dorgrq(f[0], f[1])[0])(L.dgerqf(M))', field='q', label='lapack_orgrq_sq'),
    T('lapack_ungrq(lapack_gerqf([1+1i,2,3;4,5-2i,6])["qr"], lapack_gerqf([1+1i,2,3;4,5-2i,6])["tau"])',
      '(lambda f: L.zungrq(f[0], f[1])[0])(L.zgerqf(np.array([[1+1j,2,3],[4,5-2j,6]])))', field='q'),
    T('lapack_ormqr("L", "T", lapack_geqrf(R)["qr"], lapack_geqrf(R)["tau"], [1,2;3,4;5,6], 10)',
      '(lambda f: L.dormqr("L", "T", f[0], f[1], np.array([[1.,2],[3,4],[5,6]]), 10)[0])(L.dgeqrf(R))', field='cq'),
    T('lapack_ormqr("R", "N", lapack_geqrf(R)["qr"], lapack_geqrf(R)["tau"], [1,2,3;4,5,6], 10)',
      '(lambda f: L.dormqr("R", "N", f[0], f[1], np.array([[1.,2,3],[4,5,6]]), 10)[0])(L.dgeqrf(R))', field='cq', label='lapack_ormqr_rn'),
    T('lapack_unmqr("L", "C", lapack_geqrf(Z)["qr"], lapack_geqrf(Z)["tau"], [1,2;3,4;5,6], 10)',
      '(lambda f: L.zunmqr("L", "C", f[0], f[1], np.array([[1.,2],[3,4],[5,6]]), 10)[0])(L.zgeqrf(Z))', field='cq'),
    T('lapack_tzrzf(W)', 'L.dtzrzf(W)[0]', field='rz'),
    T('lapack_tzrzf(W)', 'L.dtzrzf(W)[1]', field='tau'),
    T('lapack_tzrzf([1+1i,2,3;0,5-2i,6])', 'L.ztzrzf(np.array([[1+1j,2,3],[0,5-2j,6]]))[0]', field='rz', label='lapack_tzrzf_c'),
    T('lapack_tzrzf([1+1i,2,3;0,5-2i,6])', 'L.ztzrzf(np.array([[1+1j,2,3],[0,5-2j,6]]))[1]', field='tau', label='lapack_tzrzf_ctau'),
    T('lapack_ormrz(lapack_tzrzf(W)["rz"], lapack_tzrzf(W)["tau"], [1,2;3,4;5,6])',
      '(lambda f: L.dormrz(f[0], f[1], np.array([[1.,2],[3,4],[5,6]]))[0])(L.dtzrzf(W))', field='cq'),
    T('lapack_ormrz(lapack_tzrzf(W)["rz"], lapack_tzrzf(W)["tau"], [1,2,3;4,5,6], "R", "T")',
      '(lambda f: L.dormrz(f[0], f[1], np.array([[1.,2,3],[4,5,6]]), side="R", trans="T")[0])(L.dtzrzf(W))', field='cq', label='lapack_ormrz_rt'),
    T('lapack_unmrz(lapack_tzrzf([1+1i,2,3;0,5-2i,6])["rz"], lapack_tzrzf([1+1i,2,3;0,5-2i,6])["tau"], [1,2;3,4;5,6], "L", "C")',
      '(lambda f: L.zunmrz(f[0], f[1], np.array([[1.,2],[3,4],[5,6]]), side="L", trans="C")[0])(L.ztzrzf(np.array([[1+1j,2,3],[0,5-2j,6]])))', field='cq'),
    T('lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9])', 'L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]]))[0]', field='a'),
    T('lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9])', 'L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]]))[1]', field='b'),
    T('lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9])', 'L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]]))[2]', field='t'),
    T('lapack_tpqrt(2, 1, [1,2;0,3], [4,5;0,7])', 'L.dtpqrt(2, 1, np.array([[1.,2],[0,3]]), np.array([[4.,5],[0,7]]))[2]', field='t', label='lapack_tpqrt_pent'),
    T('lapack_tpqrt(2, 1, [1,2;0,3], [4,5;0,7])', 'L.dtpqrt(2, 1, np.array([[1.,2],[0,3]]), np.array([[4.,5],[0,7]]))[0]', field='a', label='lapack_tpqrt_penta'),
    T('tpm(lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9]))',
      '(lambda f: L.dtpmqrt(0, f[1], f[2], np.array([[1.,0],[0,1]]), np.array([[1.,2],[3,4],[5,6]]), trans="T")[1])(L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]])))',
      label='lapack_tpmqrt', setup='function y = tpm(f):\n  y = lapack_tpmqrt(0, f["b"], f["t"], [1,0;0,1], [1,2;3,4;5,6], "L", "T")["b"];\nfnend'),
    T('lapack_larf([1,0.5,0.25], 1.2, M, [0,0,0])', 'L.dlarf(np.array([1,0.5,0.25]), 1.2, M, np.zeros(3))'),
    T('lapack_larf([1,0.5,0.25], 1.2, M, [0,0,0], "R")', 'L.dlarf(np.array([1,0.5,0.25]), 1.2, M, np.zeros(3), side="R")', label='lapack_larf_r'),
    T('lapack_larfg(3, 4, [1,2])', 'L.dlarfg(3, 4., np.array([1.,2]))[0]', field='alpha'),
    T('lapack_larfg(3, 4, [1,2])', 'L.dlarfg(3, 4., np.array([1.,2]))[1]', field='x'),
    T('lapack_larfg(3, 4, [1,2])', 'L.dlarfg(3, 4., np.array([1.,2]))[2]', field='tau'),
    T('lapack_larfg(3, 1+2i, [1i,2])', 'L.zlarfg(3, 1+2j, np.array([1j,2]))[2]', field='tau', label='lapack_larfg_c'),
    T('lapack_lartg(3, 4)', 'L.dlartg(3., 4.)[0]', field='cs'),
    T('lapack_lartg(-3, 4)', 'L.dlartg(-3., 4.)[1]', field='sn', label='lapack_lartg_neg'),
    T('lapack_lartg(-3, 4)', 'L.dlartg(-3., 4.)[2]', field='r', label='lapack_lartg_r'),
    T('lapack_lartg(1+1i, 2-1i)', 'L.zlartg(1+1j, 2-1j)[1]', field='sn', label='lapack_lartg_c'),
    T('lapack_lartg(1+1i, 2-1i)', 'L.zlartg(1+1j, 2-1j)[2]', field='r', label='lapack_lartg_cr'),
    T('lapack_rot([1,2,3], [4,5,6], 0.6, 0.8)', 'L.zrot(np.array([1.,2,3]), np.array([4.,5,6]), 0.6, 0.8)[1].real', field='y'),
    T('lapack_rot([1i,2,3], [4,5,6], 0.6, 0.8i)', 'L.zrot(np.array([1j,2,3]), np.array([4.,5,6]), 0.6, 0.8j)[1]', field='y', label='lapack_rot_c'),
    T('lapack_gels(R, [1,2,3])', 'L.dgels(R, np.array([1.,2,3]))[1]', field='x'),
    T('lapack_gels(R, [1,2,3])', 'L.dgels(R, np.array([1.,2,3]))[0]', field='lqr', label='lapack_gels_qr'),
    T('lapack_gels(W, [1,2,0])', 'L.dgels(W, np.array([1.,2,0]))[1]', field='x', label='lapack_gels_wide'),
    T('lapack_gels(W, [1,2,0])', 'L.dgels(W, np.array([1.,2,0]))[0]', field='lqr', label='lapack_gels_lq'),
    T('lapack_gels(R, [1,2,0], "T")', 'L.dgels(R, np.array([1.,2,0]), trans="T")[1]', field='x', label='lapack_gels_t'),
    T('lapack_gels(W, [1,2,3], "T")', 'L.dgels(W, np.array([1.,2,3]), trans="T")[1]', field='x', label='lapack_gels_wt'),
    T('lapack_gels(Z, [1,2,3])', 'L.zgels(Z, np.array([1.,2,3]))[1]', field='x', label='lapack_gels_c'),
    T('lapack_gelss(W, [1,2,0])', 'L.dgelss(W, np.array([1.,2,0]))[1]', field='x'),
    T('lapack_gelss(W, [1,2,0])', 'L.dgelss(W, np.array([1.,2,0]))[2]', field='s'),
    T('lapack_gelss(R, [1,2,3])["x"][0:1]', 'L.dgelss(R, np.array([1.,2,3]))[1][:2]', label='lapack_gelss_tall'),
    T('lapack_gelss([1,1;1,1;1,1], [1,2,3])', 'L.dgelss(np.array([[1.,1],[1,1],[1,1]]), np.array([1.,2,3]))[3]', field='rank', label='lapack_gelss_rank'),
    T('lapack_gelsd(W, [1,2,0], 1000, 1000)', 'L.dgelsd(W, np.array([1.,2,0]), 1000, 1000)[0]', field='x'),
    T('lapack_gelsd(R, [1,2,3], 1000, 1000)["x"][0:1]', 'L.dgelsd(R, np.array([1.,2,3]), 1000, 1000)[0][:2]', label='lapack_gelsd_tall'),
    T('lapack_gelsd(Z, [1,2,3], 1000, 1000, 1000)["x"][0:1]', 'L.zgelsd(Z, np.array([1.,2,3]), 1000, 1000, 1000)[0][:2]', label='lapack_gelsd_c'),
    T('lapack_gelsy(W, [1,2,0], [0,0,0], 1e-10, 100)', 'L.dgelsy(W, np.array([1.,2,0]), np.zeros(3, np.int32), 1e-10, 100)[1]', field='x'),
    T('lapack_gelsy(W, [1,2,0], [0,0,0], 1e-10, 100)', 'L.dgelsy(W, np.array([1.,2,0]), np.zeros(3, np.int32), 1e-10, 100)[3]', field='rank'),
    T('lapack_gelsy([1,1,2;1,1,3;1,1,4], [1,2,3], [0,0,0], 1e-10, 100)["x"]',
      'L.dgelsy(np.array([[1.,1,2],[1,1,3],[1,1,4]]), np.array([1.,2,3]), np.zeros(3, np.int32), 1e-10, 100)[1]', label='lapack_gelsy_rankdef'),
    T('lapack_gglse([1,2;3,4;5,6], [1,1], [1,2,3], [1])', 'L.dgglse(np.array([[1.,2],[3,4],[5,6]]), np.array([[1.,1]]), np.array([1.,2,3]), np.array([1.]))[3]', field='x'),
    T('lapack_gglse([1,0,1;0,1,1;1,1,0], [1,2,3], [1,2,3], [2])', 'L.dgglse(np.array([[1.,0,1],[0,1,1],[1,1,0]]), np.array([[1.,2,3]]), np.array([1.,2,3]), np.array([2.]))[3]', field='x', label='lapack_gglse_3'),
    # direct calls (the row above goes through a small helper function)
    T('lapack_tpmqrt(0, f["b"], f["t"], [1,0;0,1], [1,2;3,4;5,6])', '(lambda f: L.dtpmqrt(0, f[1], f[2], np.array([[1.,0],[0,1]]), np.array([[1.,2],[3,4],[5,6]]))[1])(L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]])))', field='b', label='lapack_tpmqrt_direct', setup='f = lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9]);'),
    T('lapack_tpmqrt(0, f["b"], f["t"], [1,0;0,1], [1,2;3,4;5,6], "L")', '(lambda f: L.dtpmqrt(0, f[1], f[2], np.array([[1.,0],[0,1]]), np.array([[1.,2],[3,4],[5,6]]), side="L")[1])(L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]])))', field='b', label='lapack_tpmqrt_direct_l', setup='f = lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9]);'),
    T('lapack_tpmqrt(0, f["b"], f["t"], [1,0;0,1], [1,2;3,4;5,6], "L", "T")', '(lambda f: L.dtpmqrt(0, f[1], f[2], np.array([[1.,0],[0,1]]), np.array([[1.,2],[3,4],[5,6]]), trans="T")[1])(L.dtpqrt(0, 2, np.array([[1.,2],[0,3]]), np.array([[4.,5],[6,7],[8,9]])))', field='b', label='lapack_tpmqrt_direct_t', setup='f = lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9]);'),
]

for _t in ROWS:
    if isinstance(_t.py, str) and not _t.py.startswith('='):
        _t.py = _re.sub(r'(?<![\w.\'"])(M|R|W|Z)\b(?!\s*=)', r'\1.copy()', _t.py)
