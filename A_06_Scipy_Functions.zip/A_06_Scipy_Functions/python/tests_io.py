from gen_tests import T

# The fixtures in data/ are written by real SciPy when this table is built; the NC
# scripts read them, and write and re-read their own files (one per row: rows run in parallel).
NC_SETUP = '''A = [1,0,2;0,0,3;4,5,0];
function r = rt_mm(p, m):
  mm_write(p, m);
  r = mm_read(p);
fnend
function r = rt_hb(p, m):
  hb_write(p, m);
  r = hb_read(p);
fnend
function r = rt_wav(p, d, f):
  wav_write(p, 8000, d, f);
  r = wav_read(p)["data"];
fnend
function r = rt_cdf(p, d):
  netcdf_write(p, d);
  r = netcdf_read(p);
fnend
function g = one_var(x):
  g = dict(["v"], [1]);
  g["v"] = x;
fnend
function r = rt_f(p, d, t):
  fortran_write(p, d, t);
  r = fortran_read(p, t);
fnend
'''

def PY():
    import os, shutil
    import numpy as np, scipy, scipy.io as sio
    from scipy import sparse
    from scipy.io import wavfile, FortranFile, netcdf_file, arff
    here = os.path.dirname(os.path.abspath(__file__))
    d = os.path.join(os.path.dirname(here), 'data')
    os.makedirs(d, exist_ok=True)
    A = np.array([[1,0,2],[0,0,3],[4,5,0.]])
    B = np.array([[4,1,0],[1,3,0],[0,0,2.]])
    p = lambda n: os.path.join(d, n)
    sio.mmwrite(p('fx_sparse.mtx'), sparse.coo_array(A))
    sio.mmwrite(p('fx_sym.mtx'), sparse.coo_array(B))
    sio.mmwrite(p('fx_dense.mtx'), A)
    sio.hb_write(p('fx.hb'), sparse.csc_array(A))
    sio.savemat(p('fx.mat'), {'a': A, 'b': np.arange(4.0)})
    t = np.arange(32)
    wavfile.write(p('fx_i16.wav'), 8000, (1000*np.sin(t/3)).astype(np.int16))
    wavfile.write(p('fx_f32.wav'), 8000, np.sin(t/3).astype(np.float32))
    wavfile.write(p('fx_u8.wav'), 8000, (100+100*np.sin(t/3)).astype(np.uint8))
    wavfile.write(p('fx_stereo.wav'), 44100, np.stack([t, 2*t], axis=1).astype(np.int32))
    open(p('fx.arff'), 'w').write('''% a comment
@relation demo
@attribute x numeric
@attribute 'y value' real
@attribute kind {red,blue}
@data
1,2.5,red
2,?,blue
% another
3,4.5,'red'
''')
    with netcdf_file(p('fx.cdf'), 'w') as f:
        f.createDimension('t', None)
        f.createDimension('n', 3)
        f.createDimension('m', 2)
        v = f.createVariable('v', 'd', ('n',)); v[:] = [1,2,3]
        w = f.createVariable('w', 'i', ('n','m')); w[:] = [[1,2],[3,4],[5,6]]
        q = f.createVariable('q', 'f', ('t',)); q[:] = [1.5,2.5]
    with FortranFile(p('fx.unf'), 'w') as f:
        f.write_record(np.array([0.0,1.0,2.0]))
        f.write_record(np.array([7,8], dtype=np.int32))
    base = os.path.join(os.path.dirname(sio.__file__), 'tests', 'data')
    for n in ('scalar_byte','scalar_int16','scalar_int32','scalar_float32','scalar_float64','scalar_complex32','scalar_complex64','scalar_string',
              'array_float32_1d','array_float32_2d','array_float32_3d','scalar_heap_pointer','array_float32_pointer_2d','struct_scalars','struct_arrays','scalar_uint16','scalar_uint32','scalar_int64'):
        shutil.copy(os.path.join(base, n + '.sav'), d)
    idl = lambda n: sio.readsav(p(n + '.sav'))
    return dict(np=np, sio=sio, sparse=sparse, wavfile=wavfile, arff=arff, netcdf_file=netcdf_file, FortranFile=FortranFile, p=p, A=A, B=B, t=t, idl=idl)

SAV = [('scalar_byte','i8u'),('scalar_int16','i16s'),('scalar_int32','i32s'),('scalar_float32','f32'),('scalar_float64','f64'),('scalar_complex32','c32'),('scalar_complex64','c64'),
       ('scalar_uint16','i16u'),('scalar_uint32','i32u'),('scalar_int64','i64s'),('array_float32_1d','array1d'),('array_float32_2d','array2d')]

ROWS = [
    T('who_mat("data/fx.mat")[0,0]', '=a', label='who_mat'),
    T('who_mat("data/fx.mat")[0,1]', '=3x3', label='who_mat_shape'),
    T('who_mat("data/fx.mat")[1,2]', '=double', label='who_mat_class'),
    T('mat_version("data/fx.mat")', '[1,0]'),
    T('numel(keys(mat_split_vars("data/fx.mat")))', '2', label='mat_split_vars'),
    *[T('read_idl("data/%s.sav")["%s"]' % (f, v), 'idl("%s").%s' % (f, v), label='read_idl_' + f) for f, v in SAV],
    T('read_idl("data/scalar_string.sav")["s"]', '=The quick brown fox jumps over the lazy python', label='read_idl_string'),
    T('read_idl("data/array_float32_3d.sav")["array3d"][0,0,0]', 'idl("array_float32_3d").array3d[0,0,0]', label='read_idl_3d'),
    T('read_idl("data/scalar_heap_pointer.sav")["c64_pointer1"]', 'idl("scalar_heap_pointer").c64_pointer1', label='read_idl_pointer'),
    T('read_idl("data/array_float32_pointer_2d.sav")["array2d"]', 'idl("array_float32_pointer_2d").array2d.astype(float)', label='read_idl_pointer_2d'),
    T('read_idl("data/struct_scalars.sav")["scalars"]["a"]', 'idl("struct_scalars").scalars.a[0]', label='read_idl_struct'),
    T('read_idl("data/struct_arrays.sav")["arrays"]["a"]', 'idl("struct_arrays").arrays.a[0]', label='read_idl_struct_arrays'),
    T('sparse_to_dense(mm_read("data/fx_sparse.mtx"))', 'A', label='mm_read'),
    T('sparse_to_dense(mm_read("data/fx_sym.mtx"))', 'B', label='mm_read_sym'),
    T('mm_read("data/fx_dense.mtx")', 'A', label='mm_read_dense'),
    T('mm_info("data/fx_sparse.mtx")', 'sio.mminfo(p("fx_sparse.mtx"))[2]', field='entries'),
    T('mm_info("data/fx_sym.mtx")["symmetry"]', '=' + 'symmetric', label='mm_info_symmetry'),
    T('sparse_to_dense(rt_mm("data/out_a.mtx", sparse_csr(A)))', 'A', label='mm_write'),
    T('sparse_to_dense(rt_mm("data/out_b.mtx", sparse_csr([4,1,0;1,3,0;0,0,2])))', 'B', label='mm_write_sym'),
    T('rt_mm("data/out_c.mtx", A)', 'A', label='mm_write_dense'),
    T('sparse_to_dense(hb_read("data/fx.hb"))', 'A', label='hb_read'),
    T('sparse_to_dense(rt_hb("data/out_a.hb", sparse_csc(A)))', 'A', label='hb_write'),
    T('wav_read("data/fx_i16.wav")', 'wavfile.read(p("fx_i16.wav"))[1]', field='data', label='wav_read'),
    T('wav_read("data/fx_i16.wav")', '8000', field='rate', label='wav_read_rate'),
    T('wav_read("data/fx_f32.wav")', 'wavfile.read(p("fx_f32.wav"))[1]', field='data', label='wav_read_f32'),
    T('wav_read("data/fx_u8.wav")', 'wavfile.read(p("fx_u8.wav"))[1]', field='data', label='wav_read_u8'),
    T('wav_read("data/fx_stereo.wav")', 'wavfile.read(p("fx_stereo.wav"))[1]', field='data', label='wav_read_stereo'),
    *[T('rt_wav("data/out_%s.wav", [1,2,3,100], "%s")' % (f, f), '[1,2,3,100]', label='wav_write_' + f) for f in ('uint8','int16','int32','float32','float64')],
    T('load_arff("data/fx.arff")["data"]["x"]', '[1,2,3]', label='load_arff'),
    T('load_arff("data/fx.arff")["data"]["y value"]', '[2.5,float("nan"),4.5]', label='load_arff_missing'),
    T('load_arff("data/fx.arff")["data"]["kind"][0,2]', '=red', label='load_arff_nominal'),
    T('load_arff("data/fx.arff")["meta"]["types"][0,2]', '=nominal', label='load_arff_meta'),
    T('netcdf_read("data/fx.cdf")["v"]', '[1,2,3]', label='netcdf_read'),
    T('netcdf_read("data/fx.cdf")["w"]', '[[1,2],[3,4],[5,6]]', label='netcdf_read_2d'),
    T('netcdf_read("data/fx.cdf")["q"]', '[1.5,2.5]', label='netcdf_read_record'),
    T('rt_cdf("data/out_a.cdf", one_var([1,2,3]))["v"]', '[1,2,3]', label='netcdf_write'),
    T('fortran_read("data/fx.unf")', '[0,1,2]', label='fortran_read'),
    T('fortran_read("data/fx.unf", "int32", 1)', '[7,8]', label='fortran_read_record'),
    T('rt_f("data/out_a.unf", [0.0,1.0,2.0], "float64")', '[0,1,2]', label='fortran_write'),
    T('rt_f("data/out_b.unf", [5,6], "int32")', '[5,6]', label='fortran_write_int'),
    # the writers called directly (the rows above call them inside the round-trip helpers)
    T('mm_write("data/ex_a.mtx", A)', None, label='mm_write_direct'),
    T('hb_write("data/ex_a.hb", sparse_csc(A))', None, label='hb_write_direct'),
    T('wav_write("data/ex_a.wav", 8000, [1,2,3,100])', None, label='wav_write_direct'),
    T('wav_write("data/ex_b.wav", 8000, [1,2,3,100], "int16")', None, label='wav_write_direct_int16'),
    T('netcdf_write("data/ex_a.cdf", one_var([1,2,3]))', None, label='netcdf_write_direct'),
    T('fortran_write("data/ex_a.unf", [0.0,1.0,2.0])', None, label='fortran_write_direct'),
    T('fortran_write("data/ex_b.unf", [5,6], "int32")', None, label='fortran_write_direct_int'),
]
