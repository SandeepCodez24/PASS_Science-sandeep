"""Section 25, LAPACK part 3: symmetric and Hermitian indefinite matrices
(Bunch-Kaufman). The matrices force 2x2 pivot blocks."""
import re as _re
from gen_tests import T

NC_SETUP = '''S = [0,2,3;2,0,6;3,6,1];
S4 = [1,5,2,0;5,0,3,1;2,3,0,4;0,1,4,2];
HZ = [0,1+2i,3;1-2i,0,1i;3,-1i,1];
CS = [1i,2,3;2,0,1+1i;3,1+1i,2];
'''


def PY():
    import numpy as np
    from scipy.linalg import lapack as L
    S = np.array([[0., 2, 3], [2, 0, 6], [3, 6, 1]])
    S4 = np.array([[1., 5, 2, 0], [5, 0, 3, 1], [2, 3, 0, 4], [0, 1, 4, 2]])
    HZ = np.array([[0, 1 + 2j, 3], [1 - 2j, 0, 1j], [3, -1j, 1]])
    CS = np.array([[1j, 2, 3], [2, 0, 1 + 1j], [3, 1 + 1j, 2]])
    return dict(L=L, np=np, S=S, S4=S4, HZ=HZ, CS=CS)


def _f(fn, M, *a, **k):
    return fn(M.copy(), *a, **k)


ROWS = [
    T('lapack_sytrf(S)', 'L.dsytrf(S)[0]', field='ldu'),
    T('lapack_sytrf(S)', 'L.dsytrf(S)[1]', field='ipiv'),
    T('lapack_sytrf(S, 1)', 'L.dsytrf(S, lower=1)[0]', field='ldu', label='lapack_sytrf_lower'),
    T('lapack_sytrf(S, 1)', 'L.dsytrf(S, lower=1)[1]', field='ipiv', label='lapack_sytrf_lower_piv'),
    T('lapack_sytrf(S4)', 'L.dsytrf(S4)[0]', field='ldu', label='lapack_sytrf_4'),
    T('lapack_sytrf(S4, 1)', 'L.dsytrf(S4, lower=1)[0]', field='ldu', label='lapack_sytrf_4l'),
    T('lapack_sytrf(CS)', 'L.zsytrf(CS)[0]', field='ldu', label='lapack_sytrf_c'),
    T('lapack_sytf2(S)', 'L.dsytf2(S)[0]', field='ldu'),
    T('lapack_sytf2(S4, 1)', 'L.dsytf2(S4, lower=1)[1]', field='ipiv', label='lapack_sytf2_lower'),
    T('lapack_hetrf(HZ)', 'L.zhetrf(HZ)[0]', field='ldu'),
    T('lapack_hetrf(HZ)', 'L.zhetrf(HZ)[1]', field='ipiv'),
    T('lapack_hetrf(HZ, 1)', 'L.zhetrf(HZ, lower=1)[0]', field='ldu', label='lapack_hetrf_lower'),
    T('lapack_sytrs(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"], [1,2,3])',
      '(lambda f: L.dsytrs(f[0], f[1], np.array([1.,2,3]))[0])(L.dsytrf(S))', field='x'),
    T('lapack_sytrs(lapack_sytrf(S4, 1)["ldu"], lapack_sytrf(S4, 1)["ipiv"], [1,2,3,4], 1)',
      '(lambda f: L.dsytrs(f[0], f[1], np.array([1.,2,3,4]), lower=1)[0])(L.dsytrf(S4, lower=1))', field='x', label='lapack_sytrs_lower'),
    T('lapack_hetrs(lapack_hetrf(HZ)["ldu"], lapack_hetrf(HZ)["ipiv"], [1,2,3])',
      '(lambda f: L.zhetrs(f[0], f[1], np.array([1.,2,3]))[0])(L.zhetrf(HZ))', field='x'),
    T('lapack_hetrs(lapack_hetrf(HZ, 1)["ldu"], lapack_hetrf(HZ, 1)["ipiv"], [1,2,3], 1)',
      '(lambda f: L.zhetrs(f[0], f[1], np.array([1.,2,3]), lower=1)[0])(L.zhetrf(HZ, lower=1))', field='x', label='lapack_hetrs_lower'),
    T('lapack_sytri(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"])',
      'np.triu((lambda f: L.dsytri(f[0], f[1])[0])(L.dsytrf(S)))', label='lapack_sytri',
      setup='') if False else T('triu_of(lapack_sytri(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"])["inv_a"])',
      'np.triu((lambda f: L.dsytri(f[0], f[1])[0])(L.dsytrf(S)))', label='lapack_sytri',
      setup='function y = triu_of(m):\n  y = upper_triangular(m);\nfnend'),
    T('lapack_hetri(lapack_hetrf(HZ)["ldu"], lapack_hetrf(HZ)["ipiv"])',
      '(lambda f: L.zhetri(f[0], f[1])[0])(L.zhetrf(HZ))', field='inv_a'),
    T('lapack_sycon(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"], 11)',
      '(lambda f: L.dsycon(f[0], f[1], 11.)[0])(L.dsytrf(S))', field='rcond'),
    T('lapack_hecon(lapack_hetrf(HZ)["ldu"], lapack_hetrf(HZ)["ipiv"], 6.5)',
      '(lambda f: L.zhecon(f[0], f[1], 6.5)[0])(L.zhetrf(HZ))', field='rcond'),
    T('lapack_sysv(S, [1,2,3])', 'L.dsysv(S, np.array([1.,2,3]))[2]', field='x'),
    T('lapack_sysv(S4, [1,2,3,4], 0, 1)', 'L.dsysv(S4, np.array([1.,2,3,4]), lower=1)[2]', field='x', label='lapack_sysv_lower'),
    T('lapack_sysv(CS, [1,2,3])', 'L.zsysv(CS, np.array([1.,2,3]))[2]', field='x', label='lapack_sysv_c'),
    T('lapack_hesv(HZ, [1,2,3])', 'L.zhesv(HZ, np.array([1.,2,3]))[2]', field='x'),
    T('lapack_hesv(HZ, [1,2,3])', 'L.zhesv(HZ, np.array([1.,2,3]))[0]', field='uduh', label='lapack_hesv_f'),
    T('lapack_sysvx(S, [1,2,3])', 'L.dsysvx(S, np.array([1.,2,3]))[4]', field='x'),
    T('lapack_sysvx(S, [1,2,3])', 'L.dsysvx(S, np.array([1.,2,3]))[5]', field='rcond'),
    T('lapack_hesvx(HZ, [1,2,3])', 'L.zhesvx(HZ, np.array([1.,2,3]))[2]', field='x'),
    T('lapack_hesvx(HZ, [1,2,3])', 'L.zhesvx(HZ, np.array([1.,2,3]))[3]', field='rcond'),
    T('lapack_syconv(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"])',
      '(lambda f: L.dsyconv(f[0], f[1])[0])(L.dsytrf(S))', field='a'),
    T('lapack_syconv(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"])',
      '(lambda f: L.dsyconv(f[0], f[1])[1])(L.dsytrf(S))', field='e'),
    T('lapack_syconv(lapack_sytrf(S4, 1)["ldu"], lapack_sytrf(S4, 1)["ipiv"], 1)',
      '(lambda f: L.dsyconv(f[0], f[1], lower=1)[0])(L.dsytrf(S4, lower=1))', field='a', label='lapack_syconv_lower'),
    T('lapack_syconv(lapack_syconv(lapack_sytrf(S)["ldu"], lapack_sytrf(S)["ipiv"])["a"], lapack_sytrf(S)["ipiv"], 0, 1)',
      '(lambda f: L.dsyconv(L.dsyconv(f[0].copy(), f[1])[0], f[1], way=1)[0])(L.dsytrf(S))', field='a', label='lapack_syconv_revert'),
    T('lapack_syequb([4,100,1;100,9,2;1,2,0.01])', 'L.dsyequb(np.array([[4.,100,1],[100,9,2],[1,2,0.01]]))[0]', field='s'),
    T('lapack_syequb([4,100,1;100,9,2;1,2,0.01])', 'L.dsyequb(np.array([[4.,100,1],[100,9,2],[1,2,0.01]]))[1]', field='scond'),
    T('lapack_syequb([4,100,1;100,9,2;1,2,0.01], 1)', 'L.dsyequb(np.array([[4.,100,1],[100,9,2],[1,2,0.01]]), lower=1)[0]', field='s', label='lapack_syequb_lower'),
    T('lapack_heequb(HZ)', 'L.zheequb(HZ)[0]', field='s'),
]

for _t in ROWS:
    if isinstance(_t.py, str) and not _t.py.startswith('='):
        _t.py = _re.sub(r'(?<![\w.\'"])(S|S4|HZ|CS)\b(?!\s*=)', r'\1.copy()', _t.py)
