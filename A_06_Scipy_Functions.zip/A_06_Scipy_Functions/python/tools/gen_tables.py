import numpy as np
from scipy.integrate._ivp import dop853_coefficients as D
from scipy.integrate import lebedev_rule
R=r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01\src\main\cpp\runtime\interpreter\Scipy'
L=['// Generated data: the published Dormand-Prince 8(5,3) coefficients and the Lebedev','// quadrature points. Numbers only - do not edit by hand.','#include "io_tables.h"','','namespace nc {','namespace scipy {','']
n=D.N_STAGES
L.append('const double kDopC[%d] = {%s};'%(n+1,', '.join(repr(float(v)) for v in D.C[:n+1])))
L.append('const double kDopB[%d] = {%s};'%(n,', '.join(repr(float(v)) for v in D.B)))
L.append('const double kDopE3[%d] = {%s};'%(n+1,', '.join(repr(float(v)) for v in D.E3)))
L.append('const double kDopE5[%d] = {%s};'%(n+1,', '.join(repr(float(v)) for v in D.E5)))
L.append('const double kDopA[%d][%d] = {'%(n,n))
for i in range(n):
    L.append('    {%s},'%', '.join(repr(float(v)) for v in D.A[i,:n]))
L.append('};')
orders=[3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,35,41]
pts=[];idx=[]
for o in orders:
    x,w=lebedev_rule(o)
    idx.append((o,len(pts),x.shape[1]))
    for i in range(x.shape[1]):
        pts.append((x[0,i],x[1,i],x[2,i],w[i]))
L.append('const LebedevIndex kLebedevIndex[%d] = {%s};'%(len(idx),', '.join('{%d, %d, %d}'%t for t in idx)))
L.append('const int kLebedevCount = %d;'%len(idx))
L.append('const double kLebedevPoints[%d][4] = {'%len(pts))
for p in pts:
    L.append('    {%r, %r, %r, %r},'%tuple(float(v) for v in p))
L+=['};','','} // namespace scipy','} // namespace nc','']
open(R+r'\integration_odes\io_tables.cpp','w',encoding='utf-8',newline='\n').write('\n'.join(L))
print(len(pts))
