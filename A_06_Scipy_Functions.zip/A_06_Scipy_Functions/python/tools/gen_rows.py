"""Drafts test rows (T(nc, python)) from the spec Examples of one phase/section.

Usage: gen_rows.py <spec.json> <phase> <section prefix> <scipy module prefix> > draft.py

Each example 'v = name(args);' becomes T('name(args)', '<module>.<scipyname>(args)'); a
Dict result ('Returns: Dict {a, b}') becomes one row per field with the matching
tuple index. NC literals are turned into Python ones: [a,b;c,d] -> np.array, pi ->
np.pi, 2i -> 2j. The draft is then edited by hand."""
import json, re, sys

spec = json.load(open(sys.argv[1], encoding='utf-8'))
phase, sec, mod = int(sys.argv[2]), sys.argv[3], sys.argv[4]


def py_literal(s):
    s = re.sub(r'(\d(?:\.\d*)?(?:e[-+]?\d+)?)i\b', r'\1j', s)
    s = s.replace('pi', 'np.pi')

    def mat(m):
        body = m.group(1)
        if ';' not in body:
            return '[' + body + ']'
        return 'np.array([' + ','.join('[' + r + ']' for r in body.split(';')) + '])'
    return re.sub(r'\[([^\[\]]*)\]', mat, s)


seen = set()
print('from gen_tests import T\n\nROWS = [')
for e in spec:
    if e['phase'] != phase or not e['section'].startswith(sec):
        continue
    ex = e['example'].split('\n')[0].strip()
    m = re.match(r'\w+\s*=\s*(\w+)\((.*)\);$', ex)
    if not m:
        print('    # %s: %s' % (e['sno'], ex))
        continue
    name, args = m.group(1), m.group(2)
    if (name, args) in seen:
        continue
    seen.add((name, args))
    sname = e['scipy'].split('\n')[0].strip().rstrip('()').split('.')[-1]
    call = '%s.%s(%s)' % (mod, sname, py_literal(args))
    nc = '%s(%s)' % (name, args)
    fields = re.search(r'Returns: Dict \{([^}]*)\}', e['args'])
    if fields:
        for i, f in enumerate(x.strip() for x in fields.group(1).split(',')):
            f = f.split(' ')[0]
            print("    T(%r, %r, field=%r)," % (nc, '%s[%d]' % (call, i), f))
    else:
        print("    T(%r, %r)," % (nc, call))
print(']')
