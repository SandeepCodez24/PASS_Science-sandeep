"""Runs every Example of the spec tables as written, with common variables defined."""
import concurrent.futures, glob, json, os, re, subprocess, sys, tempfile, collections
sys.stdout.reconfigure(encoding='utf-8')
ROOT=r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
NC=ROOT+r'\src\main\cpp\nc.exe'
TESTS=ROOT+r'\src\test\scipy'
sp=sys.argv[1]
spec=json.load(open(os.path.join(sp,'spec12.json'),encoding='utf-8'))
PRE='''t = space(0, 1, 500);
sig = sin(2*pi*5*t) + 0.5*cos(2*pi*30*t);
x = space(0, 10, 11);
y = [0,1,3,2,5,4,1,0,2,7,3,1];
img = outer(hann_win(32), hann_win(32));
M32 = img;
A = [4,1,2;1,3,0;2,0,5];
B = [1,2;3,4;5,6];
b = butter(4, 0.2)["b"];
a = butter(4, 0.2)["a"];
S = sparse_csr(A);
G = sparse_csr([0,1,4;0,0,2;0,0,0]);
P = [0.1,0.2;0.15,0.22;0.9,0.8;0.92,0.85;0.5,0.1;0.52,0.14;0.2,0.9;0.25,0.95;0.7,0.3;0.6,0.75];
Q = P;
lbl = img_label(img > 0.5)["labels"];
markers = lbl;
p = find_peaks(y)["peaks"];
F = fft2(img);
Z = stft(sig, 500, 64)["Zxx"];
function y = f(v):
  y = v;
fnend
function y = d2(m, axis):
  y = img_correlate1d(m, [1,-2,1], axis);
fnend
function y = shift_half(p):
  y = [p[0] + 0.5, p[1] - 0.5];
fnend
function y = psd(v):
  y = sum(v *. v);
fnend
'''
def run(e):
    ex=e['example'].strip()
    if not ex: return e,'NOEX',''
    body='\n'.join(l for l in ex.split('\n'))
    with tempfile.NamedTemporaryFile('w',suffix='.nc',delete=False,encoding='utf-8') as fh:
        fh.write(PRE+body+'\n'); path=fh.name
    try:
        r=subprocess.run([NC,path],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120,cwd=TESTS)
        out=r.stdout+r.stderr
    except subprocess.TimeoutExpired:
        return e,'TIMEOUT',''
    finally:
        os.unlink(path)
    m=[l for l in out.split('\n') if 'Error' in l and 'stopped here' not in l and 'not run' not in l]
    return e,('FAIL' if m else 'OK'),(m[0] if m else '')
with concurrent.futures.ThreadPoolExecutor(8) as ex:
    res=list(ex.map(run,spec))
c=collections.Counter(r[1] for r in res)
print(c)
with open(os.path.join(sp,'spec_fail.txt'),'w',encoding='utf-8') as out:
    for e,st,msg in res:
        if st!='OK':
            out.write('%s|%s|%s|%s|%s\n'%(e['sno'],e['nc'],st,e['example'].replace('\n',' // '),msg[:110]))
# function coverage by the test tables
rows=''
for f in glob.glob(TESTS+r'\python\tests_*.py'):
    rows+=open(f,encoding='utf-8').read()
miss=[]
seen=set()
for e in spec:
    for n in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\(\)',e['nc']):
        if n in seen: continue
        seen.add(n)
        if not re.search(r'\b'+n+r'\s*\(',rows): miss.append(n)
print('not in any test row:',miss)
