import numpy as np, scipy.stats as s, os, sys
p = os.path.join(os.path.dirname(s.__file__), '_sobol_direction_numbers.npz')
d = np.load(p)
D = 1024
poly, vinit = d['poly'][:D], d['vinit'][:D]
out = ['// Generated from SciPy\'s _sobol_direction_numbers.npz (Joe and Kuo, new-joe-kuo-6.21201):',
       '// the primitive polynomials and initial direction numbers of the first %d dimensions.' % D,
       '// Do not edit; regenerate with src/test/scipy/python/tools/gen_sobol.py.',
       '#include <cstdint>', '', 'namespace nc {', 'namespace scipy {', 'namespace st {', '',
       'extern const int kSobolMaxDim = %d;' % D, '', 'extern const std::uint32_t kSobolPoly[%d] = {' % D]
for i in range(0, D, 16):
    out.append('    ' + ', '.join(str(int(v)) for v in poly[i:i+16]) + ',')
out.append('};')
out.append('')
out.append('extern const std::uint32_t kSobolVinit[%d][18] = {' % D)
for row in vinit:
    out.append('    {' + ', '.join(str(int(v)) for v in row) + '},')
out.append('};')
out += ['', '} // namespace st', '} // namespace scipy', '} // namespace nc', '']
open(sys.argv[1], 'w', newline='\n').write('\n'.join(out))
