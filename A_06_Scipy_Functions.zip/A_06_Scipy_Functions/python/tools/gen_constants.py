import json,re,sys
import scipy.constants as C
spec=json.load(open(sys.argv[1],encoding='utf-8'))
R=r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01\src\main\cpp\runtime\interpreter\Scipy\constants'
def q(s):
    s=s.replace('\\','\\\\').replace('"','\\"')
    return '"'+s.encode('ascii','backslashreplace').decode().replace('\\\\u','u').replace('\\u','u')+'"'
L=['// Generated: the CODATA table of scipy.constants.physical_constants (SciPy %s) and'%__import__('scipy').__version__,
   '// the named constants of the mapping tables. Data only - do not edit by hand.',
   '#include "co_table.h"','','namespace nc {','namespace scipy {','',
   'const CodataRow kCodata[] = {']
cur=set(C._codata._current_constants)
for k,(v,u,e) in sorted(C.physical_constants.items()):
    L.append('    {%s, %r, %s, %r, %s},'%(q(k),float(v),q(u),float(e),'true' if k in cur else 'false'))
L+=['};','const size_t kCodataCount = sizeof(kCodata) / sizeof(kCodata[0]);','','const NamedConstant kNamed[] = {']
seen=set()
for e in spec:
    if e['args'].startswith('(constant'):
        nm=e['nc'].strip(); orig=e['scipy'].replace('constants.','').strip()
        if nm in seen: continue
        seen.add(nm)
        v=float(getattr(C,orig))
        unit=re.search(r'Unit:\s*(.*)',e['args']).group(1).strip()
        L.append('    {%s, %r, %s, %s},'%(q(nm),v,q(unit),q('scipy.'+e['scipy'])))
L+=['};','const size_t kNamedCount = sizeof(kNamed) / sizeof(kNamed[0]);','','} // namespace scipy','} // namespace nc','']
open(R+r'\co_table.cpp','w',encoding='utf-8',newline='\n').write('\n'.join(L))
print(len(C.physical_constants),len(seen))
