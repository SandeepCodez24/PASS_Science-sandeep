"""Runs every Example of the phase 3 and 4 spec tables as written, with the variables and
NC functions they assume defined first. Writes spec_fail34.txt (sno|nc|first error) next
to spec1234.json. Usage: spec_run34.py <folder with spec1234.json>"""
import collections, concurrent.futures, json, os, subprocess, sys, tempfile
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
NC = ROOT + r'\src\main\cpp\nc.exe'
TESTS = ROOT + r'\src\test\scipy'

PRE = '''t = space(0, 1, 500);
sig = sin(2*pi*5*t) + 0.5*cos(2*pi*30*t);
x = space(1, 10, 10);
y = [0.5,1.2,3.1,2.2,5.3,4.1,6.2,7.9,8.1,9.7];
data = [0.12,-0.85,1.33,0.41,-0.27,0.96,-1.42,0.58,0.07,1.85,-0.63,0.29,0.74,-0.11,1.02,-0.38,0.45,0.88,-0.95,0.21];
data2 = [0.52,-0.35,1.93,0.11,-0.87,1.46,-0.42,0.98,0.67,1.05,-0.13,0.79,1.24,-0.61,1.52,0.12,0.95,1.38,-0.45,0.71];
mdata = data;
P = [0.1,0.2;0.15,0.22;0.9,0.8;0.92,0.85;0.5,0.1;0.52,0.14;0.2,0.9;0.25,0.95;0.7,0.3;0.6,0.75];
S = halton_sample(2, 8);
g6 = space(0, 1, 6);
function r = bell(v):
  r = exp(-v^2/2) / sqrt(2*pi);
fnend
function r = dbell(v):
  r = -v * exp(-v^2/2) / sqrt(2*pi);
fnend
function r = model(X):
  r = X[0,:] + 2 * X[1,:];
fnend
function r = mean_diff(a, b):
  r = mean(a) - mean(b);
fnend
function r = randn(n):
  r = norm_rvs(0, 1, n);
fnend
function r = f(v):
  r = (v - 2)^2;
fnend
'''


def run(e):
    ex = e['example'].strip()
    if not ex:
        return e, 'NOEX', ''
    with tempfile.NamedTemporaryFile('w', suffix='.nc', delete=False, encoding='utf-8') as fh:
        fh.write(PRE + ex + '\n')
        path = fh.name
    try:
        r = subprocess.run([NC, path], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120, cwd=TESTS)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return e, 'TIMEOUT', ''
    finally:
        os.unlink(path)
    m = [l for l in out.split('\n') if 'Error' in l and 'stopped here' not in l and 'not run' not in l]
    return e, ('FAIL' if m else 'OK'), (m[0] if m else '')


if __name__ == '__main__':
    sp = sys.argv[1]
    spec = [e for e in json.load(open(os.path.join(sp, 'spec1234.json'), encoding='utf-8')) if e['phase'] in (3, 4)]
    with concurrent.futures.ThreadPoolExecutor(8) as ex:
        res = list(ex.map(run, spec))
    print(collections.Counter(r[1] for r in res))
    with open(os.path.join(sp, 'spec_fail34.txt'), 'w', encoding='utf-8') as out:
        for e, st, msg in res:
            if st != 'OK':
                out.write('%s|%s|%s|%s\n' % (e['sno'], e['nc'], st, msg.strip()))
