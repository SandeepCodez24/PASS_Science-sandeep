import zipfile,re,json,sys
import xml.etree.ElementTree as ET
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def celltext(tc):
    out=[]
    for p in tc.iter(W+'p'):
        s=''
        for n in p.iter():
            if n.tag==W+'t': s+=n.text or ''
            elif n.tag==W+'br': s+='\n'
            elif n.tag==W+'tab': s+=' '
        out.append(s)
    return '\n'.join(out).strip()
res=[]
for ph,f in enumerate(sys.argv[2:],1):
    z=zipfile.ZipFile(f); root=ET.fromstring(z.read('word/document.xml'))
    body=root.find(W+'body'); sec=''
    for el in body:
        if el.tag==W+'p':
            t=''.join(x.text or '' for x in el.iter(W+'t')).strip()
            if re.match(r'^\d+\. ',t) or t.startswith('Appendix'): sec=t
        elif el.tag==W+'tbl':
            for tr in el.findall(W+'tr'):
                cells=[celltext(tc) for tc in tr.findall(W+'tc')]
                if len(cells)>=6 and cells[0].isdigit():
                    res.append(dict(phase=ph,section=sec,sno=int(cells[0]),scipy=cells[1],nc=cells[2],desc=cells[3],args=cells[4],example=cells[5]))
json.dump(res,open(sys.argv[1],'w',encoding='utf-8'),ensure_ascii=False,indent=0)
print(len(res))
