"""Print the source of named scipy functions without docstrings: src_of.py module fn fn ..."""
import ast, importlib, sys
sys.stdout.reconfigure(encoding='utf-8')
mod = importlib.import_module(sys.argv[1])
src = open(mod.__file__, encoding='utf-8').read()
tree = ast.parse(src)
want = sys.argv[2:]
def strip(node):
    for n in ast.walk(node):
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.body and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], 'value', None), ast.Constant) and isinstance(n.body[0].value.value, str):
            n.body = n.body[1:] or [ast.Pass()]
    return ast.unparse(node)
def walk(body, prefix=''):
    for n in body:
        if isinstance(n, ast.FunctionDef):
            if n.name in want or prefix + n.name in want:
                print(strip(n)); print()
        elif isinstance(n, ast.ClassDef):
            walk(n.body, n.name + '.')
walk(tree.body)
