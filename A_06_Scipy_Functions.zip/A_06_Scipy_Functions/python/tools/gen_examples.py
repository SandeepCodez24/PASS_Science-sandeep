"""Writes src/test/scipy/examples/phase_<n>/<nn>_<section>.nc: an annotated, runnable
NC example for every SciPy function of nc.exe, with one call for each number of
inputs from the required ones up to all the named optional ones.

Where the calls come from:
  1. the test rows (python/tests_*.py), with the data their table defines;
  2. calls built from those: dropping trailing optional inputs, or adding the
     next optional input with its documented default (front-end documents);
  3. the pop-up example of the front-end documents, for a function without rows.
Every call is run twice in nc.exe (alone, in the example folder); calls that fail
are left out, and the printed result is written below the call as a comment.
Each finished file is run once more as a whole.

Usage: gen_examples.py [section folder ...]   (no names: every section)"""
import concurrent.futures, importlib, json, os, re, subprocess, sys, tempfile

ROOT = r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
TESTS = ROOT + r'\src\test\scipy'
PYDIR = TESTS + r'\python'
NC = ROOT + r'\src\main\cpp\nc.exe'
OUT = TESTS + r'\examples'
DOCS = [ROOT + r'\docs\SciPy_Phase1_2_Frontend_Changes.md', ROOT + r'\docs\SciPy_Phase3_4_Frontend_Changes.md',
        ROOT + r'\docs\SciPy_Phase5_Frontend_Changes.md']
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, PYDIR)

SECTIONS = ['clustering', 'constants', 'datasets', 'differentiation', 'fourier_transforms', 'legacy_fft',
            'integration_odes', 'interpolation', 'input_output', 'linear_algebra', 'image_processing',
            'orthogonal_distance_regression', 'optimization_root_finding', 'signal_processing', 'window_functions',
            'sparse_matrices', 'sparse_linear_algebra', 'graph_routines', 'spatial_algorithms', 'special_functions',
            'statistics', 'probability_distributions', 'masked_array_statistics', 'removed_since_1_8',
            'blas_lapack_wrappers']
TITLES = ['Clustering (scipy.cluster)', 'Physical and mathematical constants (scipy.constants)',
          'Datasets (scipy.datasets)', 'Differentiation (scipy.differentiate)', 'Fourier transforms (scipy.fft)',
          'Legacy FFT (scipy.fftpack)', 'Integration and ODEs (scipy.integrate)', 'Interpolation (scipy.interpolate)',
          'Input / output (scipy.io)', 'Linear algebra (scipy.linalg)', 'Image processing (scipy.ndimage)',
          'Orthogonal distance regression (scipy.odr)', 'Optimization and root finding (scipy.optimize)',
          'Signal processing (scipy.signal)', 'Window functions (scipy.signal.windows)',
          'Sparse matrices (scipy.sparse)', 'Sparse linear algebra (scipy.sparse.linalg)',
          'Graph routines (scipy.sparse.csgraph)', 'Spatial algorithms (scipy.spatial)',
          'Special functions (scipy.special)', 'Statistics (scipy.stats)', 'Probability distributions (scipy.stats)',
          'Masked-array statistics (scipy.stats.mstats)', 'Appendix A: functions removed since SciPy 1.8',
          'Appendix B: low-level BLAS and LAPACK wrappers (scipy.linalg.blas, scipy.linalg.lapack)']
def phase_of(i):  # 0-based section index
    return 1 if i < 10 else 2 if i < 19 else 3 if i == 19 else 4 if i < 24 else 5

def clean(out):
    return '\n'.join(l for l in out.splitlines() if 'already exists as a NumPy function' not in l).strip()

def run(text, cwd, timeout=120, strip=True):
    with tempfile.NamedTemporaryFile('w', suffix='.nc', delete=False, encoding='utf-8', dir=cwd) as f:
        f.write(text)
        p = f.name
    try:
        r = subprocess.run([NC, p], capture_output=True, text=True, encoding='utf-8', errors='replace',
                           timeout=timeout, cwd=cwd)
        out = clean(r.stdout + r.stderr) if strip else '\n'.join(
            l for l in (r.stdout + r.stderr).splitlines() if 'already exists as a NumPy function' not in l)
    except subprocess.TimeoutExpired:
        out = 'TIMEOUT Error'
    os.unlink(p)
    return out

def split_args(s):
    """Top-level comma split of an argument text."""
    out, depth, cur, q = [], 0, '', False
    for ch in s:
        if ch == '"':
            q = not q
        if not q:
            if ch in '([{':
                depth += 1
            elif ch in ')]}':
                depth -= 1
            elif ch == ',' and depth == 0:
                out.append(cur.strip())
                cur = ''
                continue
        cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out

def calls_in(expr, names):
    """(name, call text, argument list) for every call of a registered name in expr."""
    res = []
    for m in re.finditer(r'(?<![\w.])([A-Za-z_]\w*)\(', expr):
        nm = m.group(1)
        if nm not in names:
            continue
        i, depth, q = m.end(), 1, False
        while i < len(expr) and depth:
            ch = expr[i]
            if ch == '"':
                q = not q
            elif not q:
                depth += ch == '('
                depth -= ch == ')'
            i += 1
        if depth:
            continue
        text = expr[m.start():i]
        res.append((nm, text, split_args(text[len(nm) + 1:-1])))
    return res

# ---------------------------------------------------------------- registry
def registry():
    cwd = tempfile.mkdtemp()
    script = ''.join('print("@@%s");\nprint(scipy_functions("%s"));\n' % (s, s) for s in SECTIONS)
    out = run(script, cwd)
    sec, names = None, {}
    for line in out.splitlines():
        if line.startswith('@@'):
            sec = line[2:]
        elif line.startswith('['):
            for n in line.strip('[]').split(','):
                if n:
                    names[n] = sec
    help_out = run(''.join('help("%s");\n' % n for n in names), cwd)
    sig, summ = {}, {}
    cur = None
    for line in help_out.splitlines():
        m = re.match(r'^(\w+)\((.*)\)\s*$', line)
        if m and m.group(1) in names:
            cur = m.group(1)
            sig[cur] = m.group(2)
        elif cur and line.startswith('  ') and not line.strip().startswith('SciPy:') and cur not in summ:
            summ[cur] = line.strip()
    big = ','.join(str(i + 1) for i in range(70))
    def rng(n):
        o = run('r = %s(%s);\n' % (n, big), cwd)
        m = re.search(r'expects (\d+) to (\d+) argument', o) or re.search(r'expects (\d+) argument', o)
        if m:
            return n, (int(m.group(1)), int(m.group(m.lastindex)))
        m = re.search(r'expects at least (\d+) argument', o)
        if m:
            return n, (int(m.group(1)), -1)
        m = re.search(r'expects at least (\d+) argument', run('r = %s();\n' % n, cwd))  # variadic: ask with none
        return n, (int(m.group(1)) if m else 0, -1)
    with concurrent.futures.ThreadPoolExecutor(12) as ex:
        ranges = dict(ex.map(rng, names))
    consts = run('c = scipy_constants();\nprint(c);\n', cwd).strip().strip('[]').split(',')
    return names, sig, summ, ranges, [c for c in consts if c]

# ---------------------------------------------------------------- documents
def docs():
    d = {}
    for f in DOCS:
        cur = None
        for line in open(f, encoding='utf-8'):
            line = line.rstrip('\n').rstrip()
            m = re.match(r'^#### `(\w+)\((.*)\)`', line)
            if m:
                cur = d.setdefault(m.group(1), {})
                continue
            if line.startswith('#'):
                cur = None
                continue
            if cur is None or not line.strip():
                continue
            m = re.match(r'^(Inputs|Returns|Example|Note|SciPy):\s*(.*)$', line)
            if m:
                cur.setdefault(m.group(1), m.group(2).strip())
            else:
                cur.setdefault('desc', line.strip())
    return d

def scipy_defaults(path):
    """param -> NC literal of the default, from the signature of SciPy's own function."""
    import importlib as il, inspect, math
    parts = path.split('\n')[0].split(' / ')
    full = parts[0].replace('()', '').strip()
    mod, _, fn = full.rpartition('.')
    for alt in [a.replace('()', '').strip() for a in parts[1:]]:
        if alt.startswith('d'):  # BLAS / LAPACK: the double-precision routine
            fn = alt
            break
    try:
        obj = getattr(il.import_module('scipy.' + mod), fn)
        sg = inspect.signature(obj)
    except Exception:
        return {}
    res = {}
    for name, prm in sg.parameters.items():
        v = prm.default
        if v is inspect.Parameter.empty or v is None:
            continue
        if isinstance(v, bool):
            res[name] = '1' if v else '0'
        elif isinstance(v, (int, float)) and not (isinstance(v, float) and (math.isnan(v) or math.isinf(v))):
            res[name] = repr(v)
        elif isinstance(v, str):
            res[name] = '"%s"' % v
    return res

def defaults_from(inputs):
    """param -> default literal, from an 'Inputs:' line."""
    res = {}
    for part in re.split(r';\s+', inputs or ''):
        m = re.match(r'^\s*(\w+)\s*:\s*(.*)$', part)
        if not m:
            continue
        dm = re.search(r'default[:\s]+(-?[0-9.]+(?:e-?\d+)?|"[^"]*"|\[[^\]]*\])', m.group(2))
        if dm:
            res[m.group(1)] = dm.group(1)
    return res

# ---------------------------------------------------------------- calls from the test rows
def row_calls(names):
    found = {}
    tables = {}
    for fn in sorted(os.listdir(PYDIR)):
        if not (fn.startswith('tests_') and fn.endswith('.py')):
            continue
        mod = importlib.import_module(fn[:-3])
        tab = fn[6:-3]
        tables[tab] = getattr(mod, 'NC_SETUP', '')
        for t in mod.ROWS:
            for nm, text, args in calls_in(t.nc, names):
                found.setdefault(nm, []).append(dict(text=text, args=args, table=tab, setup=t.setup or ''))
            for nm, text, args in calls_in(t.setup or '', names):  # calls in a row's own setup
                before = t.setup[:t.setup.rfind('\n', 0, t.setup.find(text)) + 1]  # the lines before the call
                found.setdefault(nm, []).append(dict(text=text, args=args, table=tab, setup=before.strip()))
    return found, tables

def fix_paths(s):
    return s.replace('"data/', '"../../data/')

# ---------------------------------------------------------------- variants
def rvs_variants(nm, s, rows):
    """name_rvs(shapes..., [loc, [scale,]] n): loc and scale go before the sample count n."""
    shapes = [p.strip() for p in s.split('[')[0].split(',') if p.strip()]
    opt = re.findall(r'\[(\w+),', s)
    base = min(rows, key=lambda r: len(r['args']))
    vals = base['args'][:len(shapes)]
    out = []
    for j in range(len(opt) + 1):
        args = vals + [{'loc': '0', 'scale': '1'}.get(p, '0') for p in opt[:j]] + ['5']  # 5 draws: short enough to print
        label = 'only the required inputs (5 draws)' if not j else 'with the optional input%s %s' % (
            's' if j > 1 else '', ', '.join(opt[:j]))
        out.append(dict(text='%s(%s)' % (nm, ', '.join(args)), args=args, table=base['table'],
                        setup=base['setup'], origin='built', label=label))
    return out, shapes + opt + ['n']

def variants(nm, sig, ranges, rows, doc):
    lo, hi = ranges.get(nm, (0, -1))
    if nm.endswith('_rvs') and '[' in sig.get(nm, '') and rows:
        out, named = rvs_variants(nm, sig[nm], rows)
        return out, named, lo, hi, False
    params = split_args(sig.get(nm, '')) if sig.get(nm, '').strip() else []
    named = [p.split('=')[0].strip() for p in params if re.match(r'^\w+\s*(=.*)?$', p)]
    sig_dflt = {p.split('=')[0].strip(): p.split('=', 1)[1].strip() for p in params if re.match(r'^\w+\s*=', p)}
    lo, hi = ranges.get(nm, (0, -1))
    variadic = hi == -1 or '...' in sig.get(nm, '')
    top = len(named) if not variadic else max([len(r['args']) for r in rows] + [lo])
    if not variadic and hi >= 0:
        top = min(top, hi)
    top = max(top, lo)
    by_n = {}
    for r in rows:
        k = len(r['args'])
        if lo <= k and (variadic or k <= max(hi, top)):
            by_n.setdefault(k, []).append(r)
    out = []
    for k in sorted(by_n):  # every distinct call of the rows (two at most per count)
        seen = set()
        for r in sorted(by_n[k], key=lambda r: (len(r['setup']), len(r['text']))):
            if r['text'] in seen or len(seen) >= 2:
                continue
            seen.add(r['text'])
            out.append(dict(r, origin='row'))
    if rows and not variadic:
        base = max(rows, key=lambda r: (len(r['args']), -len(r['setup']), -len(r['text'])))
        dflt = dict(SCIPY_DEFAULTS.get(nm, {}))
        dflt.update(defaults_from(doc.get('Inputs', '')))
        dflt.update(sig_dflt)
        for k in range(lo, top + 1):
            if k in by_n:
                continue
            if k < len(base['args']):
                args = base['args'][:k]
            else:
                args = list(base['args'])
                for p in named[len(args):k]:
                    args.append(dflt.get(p, '0'))
            out.append(dict(text='%s(%s)' % (nm, ', '.join(args)), args=args, table=base['table'],
                            setup=base['setup'], origin='built'))
    out.sort(key=lambda v: len(v['args']))
    return out, named, lo, hi, variadic

# ---------------------------------------------------------------- checking
def check(job):
    key, cwd, pre, setup, text = job
    script = (pre + '\n' + setup + '\nprint("@@BEGIN@@");\nr = %s;\nprint(r);\nprint("@@SEP@@");\nr = %s;\nprint(r);\n'
              % (text, text))
    o = run(script, cwd, strip=False)
    ok = '@@SEP@@' in o and 'Error' not in o and 'TIMEOUT' not in o
    first, _, second = o.partition('@@BEGIN@@')[2].partition('@@SEP@@')
    first = '\n'.join(l.rstrip() for l in first.splitlines() if l.strip())
    second = '\n'.join(l.rstrip() for l in second.splitlines() if l.strip())
    return key, ok, first, second

def comment_out(text, random):
    lines = text.splitlines()
    head = '# prints (random numbers, so it changes from run to run):' if random else '# prints:'
    if not lines:
        return ['# prints nothing']
    if len(lines) > 12 or len(text) > 900:
        short = [l if len(l) <= 110 else l[:107] + '...' for l in lines[:4]]
        return [head.replace(':', ' (first lines of a long result):')] + ['#   ' + l for l in short]
    return [head] + ['#   ' + (l if len(l) <= 200 else l[:197] + '...') for l in lines]

def wrap(label, text, width=92):
    words, lines, cur = text.split(' '), [], ''
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur)
            cur = ''
        cur = (cur + ' ' + w).strip()
    if cur:
        lines.append(cur)
    pad = ' ' * len(label)
    return ['#   ' + (label if i == 0 else pad) + l for i, l in enumerate(lines)]

def describe(v, named, lo):
    k = len(v['args'])
    extra = named[lo:k] if k <= len(named) else []
    if k == lo:
        return 'only the required inputs' if lo else 'no inputs'
    if extra and len(extra) == k - lo:
        return 'with the optional input%s %s' % ('s' if len(extra) > 1 else '', ', '.join(extra))
    return 'with %d inputs' % k

SCIPY_DEFAULTS = {}

def main():
    only = sys.argv[1:]
    names, sig, summ, ranges, consts = registry()
    doc = docs()
    rows, tables = row_calls(names)
    spec_all = json.load(open(os.path.join(PYDIR, 'tools', 'spec12345.json'), encoding='utf-8'))
    for e in spec_all:
        for n in re.findall(r'[A-Za-z_]\w*', e['nc']):
            if n in names and n not in SCIPY_DEFAULTS:
                SCIPY_DEFAULTS[n] = scipy_defaults(e['scipy'])
    spec = json.load(open(os.path.join(PYDIR, 'tools', 'spec12.json'), encoding='utf-8'))
    const_desc = {}
    for e in spec:
        if e['args'].startswith('(constant'):
            for n in re.findall(r'[A-Za-z_]\w*', e['nc']):
                const_desc.setdefault(n, e['desc'].replace('\n', ' '))
    report = []
    for si, sec in enumerate(SECTIONS):
        if only and sec not in only:
            continue
        ph = phase_of(si)
        folder = os.path.join(OUT, 'phase_%d' % ph)
        os.makedirs(folder, exist_ok=True)
        fnames = sorted(n for n, s in names.items() if s == sec)
        plan = {}
        jobs = []
        for nm in fnames:
            d = doc.get(nm, {})
            vs, named, lo, hi, variadic = variants(nm, sig, ranges, rows.get(nm, []), d)
            if not vs and d.get('Example'):  # no test row: the pop-up example
                ex = d['Example'].split('`')[0] if d['Example'].count('`') == 0 else d['Example'].split('`')[1]
                stm = [s.strip() for s in ex.split(';') if s.strip()]
                cs = calls_in(stm[-1], {nm}) if stm else []
                if cs:
                    vs = [dict(text=cs[0][1], args=cs[0][2], table=None, setup=';\n'.join(stm[:-1]) + (';' if len(stm) > 1 else ''), origin='doc')]
            plan[nm] = (vs, named, lo, hi, variadic)
            for i, v in enumerate(vs):
                pre = fix_paths(tables.get(v['table'], '')) if v['table'] else ''
                jobs.append(((nm, i), folder, pre, fix_paths(v['setup']), fix_paths(v['text'])))
        with concurrent.futures.ThreadPoolExecutor(12) as ex:
            res = {k: (ok, a, b) for k, ok, a, b in ex.map(check, jobs)}
        # ---- write the file
        L = ['# ' + '=' * 90,
             '# Phase %d, section %d: %s' % (ph, si + 1, TITLES[si]),
             '#',
             '# One block per function. Each block names the function and its inputs, says what it',
             '# returns, and calls it once for each number of inputs: first with the required inputs',
             '# only, then adding the optional inputs one at a time. "0" for an optional input means',
             '# "not given", so a later input can still be passed. The text after "prints:" is what',
             '# nc.exe printed when this file was made.',
             '#',
             '# Run: nc.exe %s (from this folder)' % ('%02d_%s.nc' % (si + 1, sec)),
             '# Generated by src/test/scipy/python/tools/gen_examples.py; do not edit by hand.',
             '# ' + '=' * 90, '']
        cur_table = object()
        kept_total = 0
        missing = []
        order = sorted(fnames, key=lambda n: (next((v['table'] or '' for v in plan[n][0]), ''), n))
        for nm in order:
            vs, named, lo, hi, variadic = plan[nm]
            good = [(i, v) for i, v in enumerate(vs) if res.get((nm, i), (False,))[0]]
            if not good:
                missing.append(nm)
                continue
            d = doc.get(nm, {})
            L += ['# ' + '-' * 90, '# %s(%s)' % (nm, sig.get(nm, ''))]
            L += wrap('', d.get('desc') or summ.get(nm, ''))
            if d.get('Inputs'):
                L += wrap('Inputs : ', d['Inputs'].rstrip('.'))
            rng = ('%d or more' % lo) if hi == -1 else (str(lo) if lo == hi else '%d to %d' % (lo, hi))
            L += ['#   Needs  : %s input%s' % (rng, '' if rng == '1' else 's')]
            if d.get('Returns'):
                L += wrap('Returns: ', d['Returns'].rstrip('.'))
            if d.get('Note'):
                L += wrap('Note   : ', d['Note'])
            if d.get('SciPy'):
                L += wrap('SciPy  : ', d['SciPy'].rstrip('.'))
            L += ['# ' + '-' * 90]
            last_setup = ''
            prev_k = None
            for n_, (i, v) in enumerate(good, 1):
                ok, a, b = res[(nm, i)]
                tab = v['table']
                if tab != cur_table:  # the data of this call's test table
                    cur_table = tab
                    pre = tables.get(tab, '') if tab else ''
                    if pre.strip():
                        L += ['# Data used by the next examples (from the %s tests):' % tab, fix_paths(pre.strip())]
                    last_setup = ''
                same = prev_k == len(v['args'])
                prev_k = len(v['args'])
                L.append('# %d) %s' % (n_, v.get('label') or ('another call with the same number of inputs' if same else describe(v, named, lo))))
                if v['setup'].strip() and v['setup'].strip() != last_setup:
                    L.append(fix_paths(v['setup'].strip()))
                    last_setup = v['setup'].strip()
                L.append('r = %s;' % fix_paths(v['text']))
                big = len(a.splitlines()) > 12 or len(a) > 900
                if not big:
                    L.append('print(r);')
                L += comment_out(a, a != b)
                if big:
                    L.append('# (the result is long, so this file does not print it; add print(r) to see it)')
                kept_total += 1
            L.append('')
        if sec == 'constants':
            L += ['# ' + '-' * 90, '# Named constants: write the name to use the value.', '# ' + '-' * 90]
            cout = run(''.join('print(%s);\n' % c for c in consts), folder).splitlines()
            for c, val in zip(consts, cout):
                if const_desc.get(c):
                    L.append('# ' + const_desc[c])
                L += ['print(%s);' % c, '#   prints: ' + val]
        path = os.path.join(folder, '%02d_%s.nc' % (si + 1, sec))
        open(path, 'w', encoding='utf-8', newline='\n').write('\n'.join(L) + '\n')
        whole = run(open(path, encoding='utf-8').read(), folder, timeout=1800)
        errs = [l for l in whole.splitlines() if 'Error' in l]
        report.append('%s: %d functions, %d calls, %d without a working call %s, whole file: %s'
                      % (sec, len(fnames), kept_total, len(missing), missing[:12], 'OK' if not errs else errs[:3]))
        print(report[-1], flush=True)
    rp = os.path.join(OUT, 'generation_report.txt')  # keep the lines of the sections not run this time
    old = open(rp, encoding='utf-8').read().splitlines() if os.path.exists(rp) else []
    keep = {l.split(':')[0]: l for l in old}
    keep.update({r.split(':')[0]: r for r in report})
    open(rp, 'w', encoding='utf-8').write('\n'.join(keep[s_] for s_ in SECTIONS if s_ in keep) + '\n')

if __name__ == '__main__':
    main()
