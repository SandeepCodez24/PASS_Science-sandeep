# Builds and runs SciPy test tables: .\rt.ps1 signal,image [-w 300] [-n 80]
param([string[]]$names, [int]$w = 300, [int]$n = 80)
$py = "$env:LOCALAPPDATA\miniconda3\python.exe"
$env:PYTHONIOENCODING = "utf-8"
$env:NC_SPEC_JSON = Join-Path $PSScriptRoot "spec12.json"
Set-Location (Join-Path $PSScriptRoot "..\..")
& $py python\gen_tests.py @names --run "..\..\main\cpp\nc.exe" 2>&1 | Select-Object -First $n | ForEach-Object { "$_".Substring(0, [Math]::Min($w, "$_".Length)) }
