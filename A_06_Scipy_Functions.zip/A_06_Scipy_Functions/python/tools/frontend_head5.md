# SciPy Phase 5: Front-End Changes

The back end (`nc.exe`) now has 244 new SciPy functions from phase 5: the low-level BLAS and LAPACK wrappers of Appendix B (`scipy.linalg.blas` and `scipy.linalg.lapack`, S.No 1870 to 2643). The 774 spec rows name one routine per precision (`sgesv`, `dgesv`, `cgesv`, `zgesv`), and NC has one function for all four, so 774 rows give 245 NC names. `lapack_ggev` existed already (phase 4, Appendix A) and was not changed, which leaves 244 new functions. There are no new constants. The Java front end does not know any of these functions yet, so the editor will not suggest or colour them. This document lists what to change. No Java file was changed for this work.

| Area | File | Change |
|---|---|---|
| Syntax checker and signatures | `src/main/resources/language/builtin_signatures.tsv` | Append the rows of [SciPy_Phase5_signatures.tsv](SciPy_Phase5_signatures.tsv) (section `scipy_blas_lapack_wrappers`) |
| Auto-suggestions | `src/main/java/language/syntax/textcolours/library/ScipyFunctions.java` | One `{ signature, description }` entry per function; the box shows the text of section 6 |
| Colour pattern | none beyond the rows above | Functions use `.tc-function-call`; there are no new constants |

Annotated, runnable examples of every function, with every number of inputs, are in `src/test/scipy/examples/phase_5/25_blas_lapack_wrappers.nc` (`nc.exe 25_blas_lapack_wrappers.nc` from that folder).

## 1. Syntax side

The rules of phases 1 to 4 still hold: inputs are positional only (`named = no`), and `0` stands for "not given" when a later input is needed. Phase 5 adds these conventions. The checker must accept all of them.

**Names.** `blas_` + the BLAS name and `lapack_` + the LAPACK name, without the precision letter: `blas_gemm`, `lapack_gesv`, `lapack_syevd_lwork`. The precision comes from the input: real input gives real results, complex input gives complex results. NC computes everything in double precision, so the `s` and `c` routines of SciPy give `d` and `z` results.

**Input order.** Inputs come in SciPy's positional order, including the ones SciPy users seldom set (`lwork`, `overwrite_a` is left out). For example `blas_gemm(alpha, a, b, beta, c, trans_a, trans_b)` and `lapack_syevr(a, compute_v, range, lower, vl, vu, il, iu)`.

**Flags.** Flags are numbers (`lower = 1`, `compute_v = 0`) as in SciPy. Text flags (`uplo`, `trans`, `side`, `norm`, `jobz`, `range`, `transr`, `fact`) accept SciPy's letters (`"L"`, `"N"`, `"T"`, `"C"`); `trans` also accepts `0`, `1`, `2`.

**Results.** A routine with one output returns it. A routine with several outputs returns a Dict whose keys are SciPy's output names, `info` included:

```
r = lapack_gesv([4, 1; 2, 3], [1, 2]);
x = r["x"];
```

**Right-hand sides.** A 1-D `b` is treated as one column, and the solution comes back 1-D, as in SciPy.

**Pivots follow SciPy.** SciPy changes some pivot arrays to 0-based and passes others through raw from LAPACK (1-based). NC does the same, so results can be passed from one routine to the next exactly as in SciPy:

- 0-based: `lapack_getrf`, `lapack_gesv`, `lapack_getc2`, `lapack_gbtrf`, `lapack_gbsv`, `lapack_laswp`, `blas_iamax`, the `lo` and `hi` of `lapack_gebal`, and the `i` of `lapack_lasd4`.
- 1-based: `lapack_gttrf` and its users, the `sytrf` / `hetrf` family (negative for 2x2 blocks), `lapack_geqp3` (`jpvt`), `lapack_pstrf` and `lapack_pstf2` (`piv`), `lapack_stebz` (`iblock`, `isplit`), `lapack_trexc` and `lapack_tgexc` (`ifst`, `ilst`), and `il` / `iu` for range `"I"`.

**Storage formats.** Band matrices (`ab`) use LAPACK band storage, one row per diagonal. Packed triangles (`ap`) hold n*(n+1)/2 values, column by column. RFP arrays (`arf`) use LAPACK's rectangular full packed layout, made by `lapack_trttf`.

**Callbacks.** `lapack_gees` and `lapack_gges` take an NC function as `select` (by name, `"f"`, or by reference, `@f`) when `sort_t` is 1. Pass `0` when `sort_t` is 0. The function receives:

| Routine | Real input | Complex input |
|---|---|---|
| `lapack_gees` | `select(wr, wi)` | `select(w)` |
| `lapack_gges` | `select(alphar, alphai, beta)` | `select(alpha, beta)` |

**Workspace queries.** `lapack_*_lwork` return `{lwork, info}` (or `{lwork, liwork, info}` and similar), with the sizes from the reference LAPACK formulas. Where SciPy has one name for a real and a complex routine with different sizes (`lapack_gesvd_lwork`, `lapack_geqrf_lwork`, ...), a last input `"complex"` gives the complex size.

**`lapack_routine`.** It runs the routine named by its first input: `lapack_routine("gesv", a, b)` is `lapack_gesv(a, b)`, and a SciPy name such as `"dgesv"` works too. Without a name, `lapack_routine(a, b)` solves the generalized symmetric eigenproblem, as the spec example does.

## 2. Auto-suggestion side

This works as in phases 1 to 4. `ScipyFunctions.ENTRIES` holds `{ signature, description }`. Section 6 gives 4 to 6 lines for every function, in this order:

1. What the function is for
2. Its inputs, with SciPy's meaning for each (the spec's "Array" / "Matrix" labels are corrected where SciPy expects a number or a flag)
3. What it returns
4. A working example
5. A note, only where the function has a trap
6. The SciPy originals

## 3. Colour pattern side

Phase 5 adds no new constants and no new colours.

## 4. Spec examples that do not run as written

The phase 5 spec examples are templates, such as `r = blas_axpy(x, y);`, and use variables they do not define (`a`, `b`, `x`, `ipiv`, `ab`, ...). None of them runs on its own. Use the examples of section 6 instead. These spec examples also differ from NC in their inputs:

| In the spec | Write this in NC | Why |
|---|---|---|
| `lapack_gees(dselect, a)` | `lapack_gees(0, a)`, or `lapack_gees("f", a, 1, 1)` with an NC function `f` | `dselect` is not a value; sorting needs `sort_t = 1` |
| `lapack_gges(dselect, a, b)` | `lapack_gges(0, a, b)`, or `lapack_gges("f", a, b, 1, 1, 1)` | as above |
| `lapack_gelsd(a, b, lwork, size_iwork)` | `lapack_gelsd(a, b, lwork, 0, size_iwork)` for real input | NC uses the complex order (`size_rwork` before `size_iwork`) for both; the real routine ignores `size_rwork` |
| `lapack_routine(a, b)` | `lapack_routine("sygv", a, b)`, or keep `(a, b)` | both work; the name form reaches any routine |

## 5. Differences from SciPy and open items

**Names left as they were.** `lapack_ggev` (spec S.No 2112 to 2115) existed already and was not changed. It needs no new row.

**Results that differ from SciPy on purpose.**

- Precision: `s` and `c` routines give double-precision results.
- Condition numbers (`rcond` of `gecon`, `pocon`, `gtcon`, `sycon`, `trcon`, ...) and error bounds (`ferr`, `berr` of the expert drivers) use the exact norm of the inverse where LAPACK estimates it. For small matrices the two agree; for large ones NC's value is the true one.
- Eigenvector signs and phases (`geev`, `syevr`, `stein`, ...) and the signs of SVD and CSD factors can differ from LAPACK, which is free to pick them too.
- `lapack_gges` computes real input in complex arithmetic: `a` and `b` come back complex triangular, not in LAPACK's real 2x2-block form. `alphar`, `alphai` and `beta` are given as for the real routine.
- `lapack_tgexc` and `lapack_tgsen` reject a real pair with 2x2 blocks; give it as complex numbers.
- `lapack_gelsy`: `x`, `j` and `rank` match LAPACK; `v` is NC's column-pivoted QR, not LAPACK's complete orthogonal factorisation.
- `lapack_gelss`: rows of `x` below n hold zeros, not LAPACK's transformed residual.
- `lapack_gejsv`: `workout` reports no scaling.
- `work` outputs are zero arrays of the size LAPACK would use, capped at 2^20 elements; `lwork`, `liwork`, `lrwork` and the `ld*` inputs are accepted and do not change results.
- `lapack_ilaver` reports 3.12.0, the LAPACK version whose behaviour NC follows (`lartg`, `gebal`).
- `lapack_geev_lwork` for large n without vectors gives the reference formula, which can be smaller than OpenBLAS's.

**Test results.** 812 test rows in seven tables (`blas`, `lapack_lu`, `lapack_chol`, `lapack_sym`, `lapack_qr`, `lapack_eig`, `lapack_svd`) compare NC with SciPy 1.x on real and complex input, and all pass. A fuzz run of every function with random and malformed inputs found no crash or hang.
