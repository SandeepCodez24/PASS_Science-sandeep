"""Writes the phase 5 (section 25, BLAS and LAPACK wrappers) front-end files:
  docs/SciPy_Phase5_Frontend_Changes.md   (head from frontend_head5.md + pop-up text)
  docs/SciPy_Phase5_signatures.tsv        (rows for builtin_signatures.tsv)
from the phase 5 spec (spec5.json), the signatures registered in
Scipy/blas_lapack_wrappers/blw_*.cpp and the first test row of each function
in tests_blas.py and tests_lapack_*.py. Usage: gen_frontend_doc5.py <tools folder>"""
import glob, importlib, json, os, re, sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
SRC = ROOT + r'\src\main\cpp\runtime\interpreter\Scipy\blas_lapack_wrappers'
TESTS = ROOT + r'\src\test\scipy'
tools = sys.argv[1]
spec = json.load(open(os.path.join(tools, 'spec5.json'), encoding='utf-8'))

# ---- spec rows grouped by NC name ----
groups = {}
for e in spec:
    nm = e['nc'].replace('()', '').strip()
    g = groups.setdefault(nm, {'desc': e['desc'].replace('\n', ' '), 'scipy': [], 'ret': ''})
    g['scipy'].append(e['scipy'].replace('()', '').replace('linalg.', ''))
    m = re.search(r'Returns:\s*(.*)', e['args'], re.S)
    if m and not g['ret']:
        g['ret'] = ' '.join(m.group(1).split())

# ---- registered signatures, and the group (file) of each ----
sig, fileof = {}, {}
for f in sorted(glob.glob(os.path.join(SRC, 'blw_*.cpp'))):
    s = open(f, encoding='utf-8').read()
    for m in re.finditer(r'(?:SP_ADD|BLW_SY)\("(\w+)", (\d+), (\w+), "([^"]*)"', s):
        sig[m.group(1)] = (int(m.group(2)), m.group(3), m.group(4))
        fileof[m.group(1)] = os.path.basename(f)

GROUPS = [('blw_blas.cpp', 'BLAS: vectors, matrix-vector and matrix-matrix products'),
          ('blw_lu.cpp', 'LAPACK: LU, band, tridiagonal and triangular systems, norms'),
          ('blw_chol.cpp', 'LAPACK: positive definite systems, packed and RFP storage'),
          ('blw_sym.cpp', 'LAPACK: symmetric and Hermitian indefinite systems'),
          ('blw_qr.cpp', 'LAPACK: QR, RQ, RZ, reflectors and least squares'),
          ('blw_eig.cpp', 'LAPACK: eigenvalues and Schur forms'),
          ('blw_svd.cpp', 'LAPACK: SVD and the cosine-sine decomposition'),
          ('blw_lwork.cpp', 'LAPACK: workspace queries and lapack_routine')]

# ---- what each input is (SciPy's meaning; the spec's types are corrected here) ----
P = {
    'a': 'Matrix', 'b': 'Matrix or Array (right-hand side)', 'c': 'Matrix', 'x': 'Array', 'y': 'Array',
    'alpha': 'Scalar', 'beta': 'Scalar, optional (default 0)', 'n': 'Int', 'm': 'Int', 'k': 'Int (band width)',
    'kl': 'Int (sub-diagonals)', 'ku': 'Int (super-diagonals)', 'ab': 'Matrix (LAPACK band storage, one row per diagonal)',
    'ap': 'Array (packed triangle, n*(n+1)/2 values)', 'arf': 'Array (RFP storage, n*(n+1)/2 values)',
    'offx': 'Int, optional (default 0)', 'offy': 'Int, optional (default 0)', 'incx': 'Int, optional (default 1)',
    'incy': 'Int, optional (default 1)', 'incv': 'Int, optional (default 1)', 'off': 'Int, optional (default 0)',
    'inc': 'Int, optional (default 1)', 'lower': '0/1, optional (default 0: upper triangle)',
    'uplo': '"U" or "L", optional', 'trans': '0/1/2 or "N"/"T"/"C", optional (default no transpose)',
    'trans_a': '0/1/2, optional (default 0)', 'trans_b': '0/1/2, optional (default 0)', 'transr': '"N" or "T" ("C" for complex), optional',
    'trana': '"N"/"T"/"C", optional', 'tranb': '"N"/"T"/"C", optional', 'diag': '0/1 or "N"/"U", optional (unit diagonal)',
    'unitdiag': '0/1, optional', 'side': '0/1 or "L"/"R", optional (default left)', 'lu': 'Matrix (LU factors)',
    'piv': 'Array (0-based pivots from the LU factorisation)', 'ipiv': 'Array (pivots of the factorisation)',
    'jpiv': 'Array (0-based column pivots)', 'rhs': 'Array (right-hand side)', 'anorm': 'Float (norm of the original matrix)',
    'norm': '"1", "I", "F" or "M", optional', 'dl': 'Array (sub-diagonal, n-1 values)', 'd': 'Array (diagonal, n values)',
    'du': 'Array (super-diagonal, n-1 values)', 'du2': 'Array (second super-diagonal from lapack_gttrf, n-2 values)',
    'e': 'Array (off-diagonal, n-1 values)', 'tau': 'Array (reflector scalars)', 'v': 'Matrix (reflector vectors)',
    't': 'Matrix (block reflector factors or a Schur form)', 'q': 'Matrix (orthogonal / unitary factor)', 'z': 'Matrix',
    'lwork': 'Int, optional (accepted for SciPy compatibility)', 'liwork': 'Int, optional (accepted, unused)',
    'lrwork': 'Int, optional (accepted, unused)', 'size_iwork': 'Int (accepted, unused)', 'size_rwork': 'Int (accepted, unused)',
    'ldab': 'Int, optional (accepted, unused)', 'lda': 'Int, optional (accepted, unused)', 'ldb': 'Int, optional (accepted, unused)',
    'ldvsl': 'Int, optional (accepted, unused)', 'ldvsr': 'Int, optional (accepted, unused)', 'work': 'Array (accepted, unused)',
    'compute_v': '0/1, optional (default 1: vectors too)', 'compute_vl': '0/1, optional (default 1)', 'compute_vr': '0/1, optional (default 1)',
    'compute_uv': '0/1, optional (default 1)', 'full_matrices': '0/1, optional (default 1)', 'compute_z': '0/1/2, optional (default 0)',
    'compute_u1': '0/1, optional', 'compute_u2': '0/1, optional', 'compute_v1t': '0/1, optional', 'compute_v2t': '0/1, optional',
    'jobz': '"V" or "N", optional (default "V")', 'range': '"A", "V" or "I" (or 0/1/2), optional', 'vl': 'Float (lower bound for range "V")',
    'vu': 'Float (upper bound for range "V")', 'il': 'Int (first index for range "I", 1-based)', 'iu': 'Int (last index for range "I", 1-based)',
    'abstol': 'Float, optional (accepted)', 'mmax': 'Int, optional (columns of z)', 'itype': '1, 2 or 3, optional (default 1)',
    'select': 'NC function name, or Array of 0/1 flags', 'sort_t': '0/1, optional (default 0)', 'select_extra_args': 'accepted, unused',
    'jobvsl': '0/1, optional (default 1)', 'jobvsr': '0/1, optional (default 1)', 'ifst': 'Int (1-based)', 'ilst': 'Int (1-based)',
    'wantq': '0/1, optional (default 1)', 'wantz': '0/1, optional (default 1)', 'ijob': 'Int, optional', 'job': '"N", "E", "V" or "B", optional',
    'isgn': '1 or -1, optional (default 1)', 'scale': '0/1, optional', 'permute': '0/1, optional', 'lo': 'Int, optional (0-based)',
    'hi': 'Int, optional (0-based)', 'nb': 'Int (block size)', 'l': 'Int (rows of the trapezoidal part)', 'nrhs': 'Int',
    'p': 'Int', 'cond': 'Float (singular values below cond * largest count as zero; -1 = machine precision)',
    'jptv': 'Array (0 = free column)', 'fact': '"N", "E" or "F", optional', 'af': 'Matrix (factors, when fact = "F")',
    'equed': 'text, optional', 'r': 'Array (row scalings)', 'factored': '0/1, optional', 'df': 'Array (factored diagonal)',
    'ef': 'Array (factored off-diagonal)', 'dlf': 'Array (factor)', 'duf': 'Array (factor)', 'clean': '0/1, optional (default 1)',
    'tol': 'Float, optional (default -1: automatic)', 'way': '0/1, optional (0: convert, 1: revert)', 'k1': 'Int, optional (0-based)',
    'k2': 'Int, optional (0-based)', 'cmach': 'text ("E", "S", "B", "P", "N", "R", "M", "U", "L", "O")', 'param': 'Array of 5 values',
    'd1': 'Float', 'd2': 'Float', 'x1': 'Float', 'y1': 'Float', 'f': 'Scalar', 'g': 'Scalar', 'i': 'Int', 'rho': 'Float, optional (default 1)',
    'w': 'Array (eigenvalues)', 'iblock': 'Array (block numbers from lapack_stebz)', 'isplit': 'Array (block ends from lapack_stebz)',
    'order': '"E" or "B"', 'joba': 'Int, optional', 'jobu': 'Int, optional', 'jobv': 'Int, optional', 'jobr': 'Int, optional',
    'jobt': 'Int, optional', 'jobp': 'Int, optional', 'x11': 'Matrix', 'x12': 'Matrix', 'x21': 'Matrix', 'x22': 'Matrix',
    'trans_': '', 'signs': '0/1, optional', 's': 'Scalar', 'name or a': 'text (routine name) or Matrix', '...': 'the inputs of that routine',
}
OVR = {  # inputs whose meaning differs in one routine
    ('blas_rot', 'c'): 'Float (cosine)', ('lapack_rot', 'c'): 'Float (cosine)', ('blas_rotg', 'a'): 'Scalar', ('blas_rotg', 'b'): 'Scalar',
    ('blas_scal', 'a'): 'Scalar', ('blas_axpy', 'a'): 'Scalar, optional (default 1)', ('lapack_larf', 'v'): 'Array (reflector vector)',
    ('lapack_larf', 'tau'): 'Scalar', ('lapack_posvx', 's'): 'Array (scalings)', ('lapack_lasd4', 'z'): 'Array',
    ('lapack_tgsyl', 'd'): 'Matrix', ('lapack_tgsyl', 'e'): 'Matrix', ('lapack_tgsyl', 'f'): 'Matrix', ('lapack_gglse', 'c'): 'Array',
    ('lapack_gglse', 'd'): 'Array', ('lapack_pteqr', 'z'): 'Matrix (n x n; ignored when compute_z is 0)', ('lapack_gemqrt', 't'): 'Matrix (nb x k)',
    ('lapack_tpmqrt', 't'): 'Matrix (nb x k)', ('lapack_tpmqrt', 'v'): 'Matrix (reflectors from lapack_tpqrt)', ('lapack_trsen', 't'): 'Matrix (Schur form)',
    ('lapack_trsen_lwork', 't'): 'Matrix (Schur form)', ('lapack_unmqr', 'side'): '"L" or "R"', ('lapack_ormqr', 'side'): '"L" or "R"',
    ('lapack_unmqr', 'trans'): '"N", "T" or "C"', ('lapack_ormqr', 'trans'): '"N", "T"', ('lapack_gees', 'select'): 'NC function name (or 0 when sort_t is 0)',
    ('lapack_gges', 'select'): 'NC function name (or 0 when sort_t is 0)', ('lapack_ger', 'a'): 'Matrix, optional (default zeros)',
    ('blas_ger', 'a'): 'Matrix, optional (default zeros)', ('blas_geru', 'a'): 'Matrix, optional (default zeros)',
    ('blas_gerc', 'a'): 'Matrix, optional (default zeros)', ('blas_her', 'a'): 'Matrix, optional (default zeros)',
    ('blas_syr', 'a'): 'Matrix, optional (default zeros)', ('blas_her2', 'a'): 'Matrix, optional (default zeros)',
    ('blas_syr2', 'a'): 'Matrix, optional (default zeros)', ('blas_her', 'n'): 'Int, optional', ('blas_syr', 'n'): 'Int, optional',
    ('blas_her2', 'n'): 'Int, optional', ('blas_syr2', 'n'): 'Int, optional',
    ('blas_asum', 'n'): 'Int, optional', ('blas_axpy', 'n'): 'Int, optional', ('blas_copy', 'n'): 'Int, optional', ('blas_dot', 'n'): 'Int, optional',
    ('blas_dotc', 'n'): 'Int, optional', ('blas_dotu', 'n'): 'Int, optional', ('blas_iamax', 'n'): 'Int, optional', ('blas_nrm2', 'n'): 'Int, optional',
    ('blas_rot', 'n'): 'Int, optional', ('blas_rotm', 'n'): 'Int, optional', ('blas_scal', 'n'): 'Int, optional', ('blas_swap', 'n'): 'Int, optional',
    ('lapack_rot', 'n'): 'Int, optional', ('blas_gemm', 'c'): 'Matrix, optional', ('blas_symm', 'c'): 'Matrix, optional',
    ('blas_hemm', 'c'): 'Matrix, optional', ('blas_syrk', 'c'): 'Matrix, optional', ('blas_herk', 'c'): 'Matrix, optional',
    ('blas_syr2k', 'c'): 'Matrix, optional', ('blas_her2k', 'c'): 'Matrix, optional', ('blas_gemv', 'y'): 'Array, optional',
    ('blas_gbmv', 'y'): 'Array, optional', ('blas_symv', 'y'): 'Array, optional', ('blas_hemv', 'y'): 'Array, optional',
    ('blas_sbmv', 'y'): 'Array, optional', ('blas_hbmv', 'y'): 'Array, optional', ('blas_spmv', 'y'): 'Array, optional',
    ('blas_hpmv', 'y'): 'Array, optional', ('lapack_gebal', 'scale'): '0/1, optional (default 0)',
    ('lapack_sfrk', 'c'): 'Array (RFP storage)', ('lapack_hfrk', 'c'): 'Array (RFP storage)', ('lapack_tfsm', 'a'): 'Array (RFP storage)',
    ('lapack_pftrf', 'a'): 'Array (RFP storage)', ('lapack_pftri', 'a'): 'Array (RFP storage)', ('lapack_pftrs', 'a'): 'Array (RFP storage)',
    ('lapack_sfrk', 'alpha'): 'Float', ('lapack_hfrk', 'alpha'): 'Float', ('lapack_sfrk', 'beta'): 'Float', ('lapack_hfrk', 'beta'): 'Float',
    ('lapack_ilaver', ''): '',
}

NOTES = {
    'blas_iamax': 'The index is 0-based, as in SciPy.',
    'lapack_getrf': 'piv is 0-based, as SciPy gives it; lapack_getrs and lapack_getri take it unchanged.',
    'lapack_gesv': 'piv is 0-based, as SciPy gives it.',
    'lapack_gbtrf': 'ab needs kl extra rows on top for the fill-in (2*kl+ku+1 rows). ipiv is 0-based.',
    'lapack_gbsv': 'ab needs kl extra rows on top for the fill-in (2*kl+ku+1 rows).',
    'lapack_gttrf': 'ipiv is 1-based (raw LAPACK), as SciPy gives it; lapack_gttrs takes it unchanged.',
    'lapack_sytrf': 'ipiv is 1-based and negative for 2x2 blocks (raw LAPACK), as SciPy gives it.',
    'lapack_hetrf': 'ipiv is 1-based and negative for 2x2 blocks (raw LAPACK), as SciPy gives it.',
    'lapack_sytf2': 'ipiv is 1-based and negative for 2x2 blocks (raw LAPACK).',
    'lapack_geqp3': 'jpvt is 1-based (raw LAPACK), as SciPy gives it.',
    'lapack_pstrf': 'piv is 1-based (raw LAPACK), as SciPy gives it.',
    'lapack_pstf2': 'piv is 1-based (raw LAPACK), as SciPy gives it.',
    'lapack_lasd4': 'i is 0-based, as in SciPy.',
    'lapack_gees': 'select takes (wr, wi) for real input and (w) for complex input.',
    'lapack_gges': 'Real input is computed in complex arithmetic: a and b are complex triangular, not LAPACK\'s real 2x2-block form. select takes (alphar, alphai, beta) for real input and (alpha, beta) for complex input.',
    'lapack_tgexc': 'A real pair with 2x2 blocks must be given as complex numbers.',
    'lapack_tgsen': 'A real pair with 2x2 blocks must be given as complex numbers. pl, pr and dif are computed exactly where LAPACK estimates them.',
    'lapack_geev': 'Eigenvector signs (and phases) are arbitrary in LAPACK too.',
    'lapack_gecon': 'NC computes the norm of the inverse exactly where LAPACK estimates it; for small matrices the two agree.',
    'lapack_routine': 'lapack_routine("gesv", a, b) runs lapack_gesv(a, b); a SciPy name such as "dgesv" works too. Without a name it solves A v = w B v (sygv / hegv).',
    'lapack_gelsy': 'v is NC\'s column-pivoted QR, not LAPACK\'s complete orthogonal factorisation; x, j and rank match.',
    'lapack_gelss': 'Rows of x below n hold zeros, not LAPACK\'s transformed residual.',
    'lapack_orcsd': 'theta is unique; u1, u2, v1t and v2t can differ from LAPACK by signs.',
    'lapack_uncsd': 'theta is unique; u1, u2, v1t and v2t can differ from LAPACK by phases.',
    'lapack_gejsv': 'workout and iworkout report no scaling (workout[0] = workout[1] = 1).',
}

def returns(nm):
    r = groups.get(nm, {}).get('ret', '')
    if nm == 'lapack_routine':
        return 'whatever the named routine returns; Dict {w, v, info} without a name'
    if nm.endswith('_lwork') and 'Dict' in r:
        return r + ' (work as a Float)'
    return r or 'see SciPy'

def inputs(nm):
    mn, mx, params = sig[nm]
    out = []
    for i, p in enumerate([x.strip() for x in params.split(',') if x.strip()]):
        t = OVR.get((nm, p)) or ('Matrix' if p == 'b' and nm.startswith('blas_') else P.get(p, ''))
        if i >= mn and 'optional' not in t and t and p not in ('...',):
            t += ', optional'
        out.append('%s: %s' % (p, t) if t else p)
    if any(v in groups.get(nm, {}).get('desc', '') for v in ()):
        pass
    return '; '.join(out) if out else 'none'

def scipy_names(nm):
    names = groups.get(nm, {}).get('scipy', [])
    if not names:
        return ''
    mod = names[0].split('.')[0]
    short = [n.split('.')[-1] for n in names]
    return '%s.%s' % (mod, ' / '.join(short))

# ---- examples: the first test row of each function, with setup names expanded ----
sys.path.insert(0, TESTS + r'\python')
examples = {}
setup_vars = {}
for mod_name in ['tests_blas', 'tests_lapack_lu', 'tests_lapack_chol', 'tests_lapack_sym', 'tests_lapack_qr', 'tests_lapack_eig', 'tests_lapack_svd']:
    mod = importlib.import_module(mod_name)
    defs = dict(re.findall(r'^(\w+) = (.+);$', getattr(mod, 'NC_SETUP', ''), re.M))
    funcs = re.findall(r'^(function .*?fnend)', getattr(mod, 'NC_SETUP', ''), re.M | re.S)
    for t in mod.ROWS:
        if t.setup:
            continue
        m = re.match(r'\s*(?:abs\()?((?:blas|lapack)_\w+)\(', t.nc)
        if not m or m.group(1) in examples:
            continue
        nm = m.group(1)
        expr = t.nc
        if re.search(r'\b(posr|posc|gsel|csdcheck|ggr|tgr|tsr|gtf|gtc|tpm|triu_of)\(', expr):
            if nm in ('lapack_gees', 'lapack_gges'):
                pass
            else:
                continue
        for _ in range(2):
            expr = re.sub(r'(?<![\w"])([A-Za-z]\w*)\b(?!\s*\()', lambda k: defs.get(k.group(1), k.group(1)), expr)
        need = [f for f in funcs if re.search(r'function \w+ = (\w+)\(', f) and re.search(r'function \w+ = (\w+)\(', f).group(1) in expr]
        examples[nm] = (expr, need)

# Functions whose first row is not a plain call: give a hand-written example.
HAND = {
    'lapack_gees': ('r = lapack_gees("posr", [-1,1,0;0,2,0;0,0,-3], 1, 1);', ['function y = posr(wr, wi):\n  y = wr > 0;\nfnend']),
    'lapack_gges': ('r = lapack_gges(0, [1i,2;0,3], [1,1;0,2]);', []),
    'lapack_gttrs': ('f = lapack_gttrf([4,8], [1,5,10], [2,6]);\nr = lapack_gttrs(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], [1,2,3]);', []),
    'lapack_gtcon': ('f = lapack_gttrf([4,8], [1,5,10], [2,6]);\nr = lapack_gtcon(f["dl"], f["d"], f["du"], f["du2"], f["ipiv"], 16);', []),
    'lapack_tpmqrt': ('f = lapack_tpqrt(0, 2, [1,2;0,3], [4,5;6,7;8,9]);\nr = lapack_tpmqrt(0, f["b"], f["t"], [1,0;0,1], [1,2;3,4;5,6], "L", "T");', []),
    'lapack_tgexc': ('r = lapack_tgexc([1,2,1;0,3,1;0,0,5], [1,1,0;0,2,1;0,0,1], unit_matrix(3), unit_matrix(3), 1, 3);', []),
    'lapack_tgsen': ('r = lapack_tgsen([0,1,1], [1,2,1;0,3,1;0,0,5], [1,1,0;0,2,1;0,0,1], unit_matrix(3), unit_matrix(3));', []),
    'lapack_orcsd': ('q = [0.5,0.5,0.5,0.5;0.5,-0.5,0.5,-0.5;0.5,0.5,-0.5,-0.5;0.5,-0.5,-0.5,0.5];\n'
                     'r = lapack_orcsd(q[0:1,0:1], q[0:1,2:3], q[2:3,0:1], q[2:3,2:3]);', []),
    'lapack_uncsd': ('q = [0.5,0.5i,0.5,0.5i;0.5i,0.5,-0.5i,-0.5;0.5,-0.5i,0.5,-0.5i;-0.5i,0.5,0.5i,-0.5];\n'
                     'r = lapack_uncsd(q[0:1,0:1], q[0:1,2:3], q[2:3,0:1], q[2:3,2:3]);', []),
    'lapack_sytri': ('f = lapack_sytrf([0,2,3;2,0,6;3,6,1]);\nr = lapack_sytri(f["ldu"], f["ipiv"]);', []),
}

def example(nm):
    if nm in HAND:
        return HAND[nm]
    e = examples.get(nm)
    if not e:
        return ('r = %s();' % nm, [])
    expr, need = e
    expr = re.sub(r'^abs\((.*)\)$', r'\1', expr)
    expr = re.sub(r'\["\w+"\]$', '', expr)
    expr = re.sub(r'\["\w+"\]\[[0-9:]+\]$', '', expr)
    return ('r = %s;' % expr, need)

# ---- TSV ----
tsv = ['# Rows to append to src/main/resources/language/builtin_signatures.tsv (same columns: section, name, usage, description, numpy, keyword_only, named).',
       '# Generated from the phase 5 registry (section 25); named = no because SciPy functions take positional inputs only.']
for nm in sorted(sig):
    usage = '%s(%s)' % (nm, sig[nm][2] if nm != 'lapack_routine' else 'name, ...')
    desc = groups.get(nm, {}).get('desc', '')
    tsv.append('scipy_blas_lapack_wrappers\t%s\t%s\tSciPy: %s\t\t\tno' % (nm, usage, desc.rstrip('.')))
open(os.path.join(ROOT, 'docs', 'SciPy_Phase5_signatures.tsv'), 'w', encoding='utf-8', newline='\n').write('\n'.join(tsv) + '\n')

# ---- the document ----
head = open(os.path.join(tools, 'frontend_head5.md'), encoding='utf-8').read()
out = [head.rstrip('\n'), '', '## 6. Pop-up text for each function', '']
for f, title in GROUPS:
    out.append('### %s' % title)
    out.append('')
    for nm in sorted(n for n in sig if fileof[n] == f):
        code, need = example(nm)
        out.append('#### `%s(%s)`' % (nm, sig[nm][2]))
        out.append('')
        desc = groups.get(nm, {}).get('desc', '')
        if nm == 'lapack_routine':
            desc = 'Runs any LAPACK routine of this section by name.'
        ex = code.replace('\n', ' ')
        if need:
            ex += '`, with `' + ' '.join(' '.join(fn.split()) for fn in need)
        block = [desc, 'Inputs: %s.' % inputs(nm), 'Returns: %s.' % returns(nm),
                 'Example: `%s`' % ex]
        if nm in NOTES:
            block.append('Note: %s' % NOTES[nm])
        block.append('SciPy: lapack.<name>, any routine by name.' if nm == 'lapack_routine' else 'SciPy: %s.' % scipy_names(nm))
        out.append('  \n'.join(block))
        out.append('')
open(os.path.join(ROOT, 'docs', 'SciPy_Phase5_Frontend_Changes.md'), 'w', encoding='utf-8', newline='\n').write('\n'.join(out))
print(len(sig), 'functions,', len(examples), 'examples from tests')
