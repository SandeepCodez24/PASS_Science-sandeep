# SciPy Phases 3 and 4: Front-End Changes

The back end (`nc.exe`) now has @@FN@@ new SciPy functions from phases 3 and 4: special functions (section 20), statistics (21), probability distributions (22), masked-array statistics (23) and the replacements for functions removed since SciPy 1.8 (Appendix A). There are no new constants. The Java front end does not know any of these functions yet, so the editor will not suggest or colour them. This document lists what to change. No Java file was changed for this work.

| Area | File | Change |
|---|---|---|
| Syntax checker and signatures | `src/main/resources/language/builtin_signatures.tsv` | Append the rows of [SciPy_Phase3_4_signatures.tsv](SciPy_Phase3_4_signatures.tsv) |
| Auto-suggestions | `src/main/java/language/syntax/textcolours/library/ScipyFunctions.java` | One `{ signature, description }` entry per function; the box shows the text of section 6 |
| Colour pattern | none beyond the rows above | Functions use `.tc-function-call`; there are no new constants |

## 1. Syntax side

The rules of phases 1 and 2 still hold: inputs are positional only (`named = no`), `0` stands for "not given" when a later input is needed, and an input described as `fn` takes an NC function by name (`"f"`) or by reference (`@f`). Phases 3 and 4 add these conventions. The checker must accept all of them.

**Several samples.** NC has no list type, and `[a, b]` joins two arrays into one. Functions that take "a list of Arrays" in SciPy take the samples as separate inputs, or as the rows of one matrix. Shorter rows are padded with NaN, for example with `pad_to_matrix(a, b)`.

```
r = kruskal(data, data2);
r = kruskal([data; data2]);
r = kruskal(pad_to_matrix([1, 2, 3], [4, 5]));
```

This applies to `anova_oneway`, `tukey_hsd`, `dunnett`, `kruskal`, `alexander_govern`, `fligner`, `levene`, `bartlett`, `median_test`, `friedman`, `anderson_ksamp`, `obrien_transform`, `permutation_test`, `bootstrap` and `nan_kruskal`. Some of them take more inputs after the samples:

- `dunnett`: the last sample is the control group.
- `levene`: an optional text input `"median"`, `"mean"` or `"trimmed"` comes last.
- `permutation_test` and `bootstrap`: the statistic function, then the number of resamples.

**Text lists work.** `["norm", "norm"]` is a 1 x 2 text matrix, so text lists such as the generators of `test_power` and the input distributions of `sobol_indices` can be written as in the spec.

**Distributions are Dicts.** `normal_dist`, `uniform_dist`, `logistic_dist`, `binomial_dist`, `make_dist`, `custom_dist`, `custom_discrete_dist`, `hist_dist`, `mixture_dist`, `order_stat_dist`, `truncate_dist`, `abs_dist`, `exp_dist`, `log_dist` and `mvs_dist` return a Dict. The `"dist"` field of the Dict names its kind. Other functions that take a distribution accept the Dict, or the name of a family without shape parameters (`"norm"`). A matrix cannot hold Dicts, so `mixture_dist` takes its components as separate inputs, followed by the weights:

```
X = mixture_dist(normal_dist(-2, 1), normal_dist(2, 1), [0.5, 0.5]);
```

**Ten helper functions that are not in the spec list.** The spec examples call `dist_cdf(X, 0)`, `dist_mean(die)` and similar functions, so the back end provides them: `dist_pdf`, `dist_pmf`, `dist_cdf`, `dist_sf`, `dist_ppf`, `dist_rvs`, `dist_mean`, `dist_var`, `dist_std`, `dist_median`. They have TSV rows and pop-up text like the other functions.

**Distribution families.** Each of the 131 families has five functions: `name_pdf` (or `name_pmf` for a discrete family), `name_cdf`, `name_sf`, `name_ppf` and `name_rvs`. Their inputs are:

- `_pdf`, `_cdf`, `_sf` and `_ppf`: `(x, shapes..., loc, scale)`, where `loc` and `scale` are optional.
- `_rvs`: `(shapes..., [loc, [scale,]] n)`. The sample count `n` is always the last input.

`poisson_binom_*` takes its probabilities as one array.

**NaN means masked.** NC has no masked arrays. In section 23 (`trim_mask`, `winsorize`, `mquantiles`, ...) a NaN element is a masked one. A function that returns data puts NaN where SciPy returns a masked element.

**Functions with two forms.**

| Name | Form 1 | Form 2 |
|---|---|---|
| `sample_ratio_uniforms` | `(pdf, mode, area, n)`: simple ratio of uniforms | `(pdf, umax, vmin, vmax, n[, seed])`: general |
| `trim_mask` | `(data, [lo, hi])`: absolute limits | `(data, [lo, hi], 1)`: fractions |
| `plotting_positions` | `(data)`: alpha = beta = 0.4 | `(data, alpha, beta)` (`meppf` is `(data, 0.5, 0.5)`) |
| `cramer_vonmises_2samp` | `(a, b)`: exact p-value when both samples have 20 or fewer values | `(a, b, "asymptotic")` |

**Random results.** The `_rvs` functions, `dist_rvs`, `rand_*`, `wishart_rvs`, `matrix_normal_rvs` and the resampling tests use NC's random engine, so `nexus_seed(n)` makes their results repeatable. The QMC functions and the samplers also take an optional seed as their last input.

## 2. Auto-suggestion side

This works as in phases 1 and 2. `ScipyFunctions.ENTRIES` holds `{ signature, description }`. Section 6 gives 3 to 6 lines for every function, in this order:

1. What the function is for
2. Its inputs
3. What it returns
4. A working example
5. A note, only where the function has a trap
6. The SciPy original

For distribution families, section 6 gives one block per function: `norm_pdf`, `norm_cdf`, `norm_sf`, `norm_ppf` and `norm_rvs` each get their own block.

## 3. Colour pattern side

Phases 3 and 4 add no new constants and no new colours.

## 4. Spec examples that do not run as written

714 of the 739 phase 3 and 4 spec examples run as written. The other 25 use helpers NC does not have, or the list forms described in section 1. The examples in section 6 are corrected already. Do not copy spec examples into the front end without checking this table.

| In the spec | Write this in NC | Why |
|---|---|---|
| `arange(0, 10, 1)` | `space(0, 9, 10)` | `arange` does not exist |
| `rand(10, 3)` | `nexus_uniform([10, 3])` | `rand` does not exist |
| `full(6, 1/6)` | `ones(1, 6) / 6` | `full` does not exist |
| `col(P, 0)` | `P[:, 0]` | `col` does not exist |
| `slice(P, 0, 5)` | `P[0:4, :]` | `slice` does not exist; NC ranges include the end |
| `outer_add(g6, g6)` | an explicit matrix | `outer_add` does not exist |
| `ones(50)` for a line of 50 | `ones(1, 50)` | `ones(50)` is a 50 x 50 matrix |
| `x ^ 2` on an array | `x ^. 2` | `^` is the matrix power |
| `[data, data2]` as two samples | `data, data2` or `[data; data2]` | `[a, b]` joins the arrays |
| `mixture_dist([d1, d2], w)` | `mixture_dist(d1, d2, w)` | a matrix cannot hold Dicts |
| `"randn"` as a generator | `"norm"`, or an NC function of n | NC has no `randn` |
| `h = histogram(data, 10); h["counts"]` | the counts and edges as arrays | NC's `histogram` does not return a Dict |
| `cdist(u, v, "mismatch_frac")` | `mismatch_frac(u, v)` | the removed metrics are functions of their own; `cdist` is unchanged |

## 5. Differences from SciPy and open items

**Names left as they were.** These 6 spec names already existed in NC and were not changed: `exp1`, `exp10`, `sinc`, `log1p` (section 20), `sign` (section 23) and `kron` (Appendix A). They need no new rows. NC's `exp1` is the NumPy-section function, not SciPy's exponential integral E1. That integral is reachable as `expn(1, x)`. `obrien_transform` appears in both sections 21 and 23. It is one function with one row.

**Results that differ from SciPy on purpose.**

- `obl_rad2` and `obl_rad2_cv`: SciPy's values fail the Wronskian check for some inputs, and NC's values pass it.
- `ncfdtridfd`: the spec example depends on a SciPy precision artefact at very large `dfd`.
- `*_cv` spheroidal and Mathieu functions differ from SciPy when `cv` is not the characteristic value.
- `y0_zeros` ignores its complex flag and returns the real zeros.
- `airy` and `airye` take real input only.
- `levy_stable` agrees with SciPy to about 1e-6.
- `kstwo` uses Stephens' approximation for n > 400.

**Results that depend on random numbers.** These cannot equal SciPy's values: the `_rvs` functions, the samplers, the `rand_*` functions, the resampling tests, the `bws_test` p-value, the permutation p-values of `pearsonr` and `mgc_test`, and `latin_hypercube` and `poisson_disk`. The statistics they compute from the data are exact. `permutation_test` is exact, and so equals SciPy, when there are two samples and all their arrangements fit in the resample count.

**Other limits.**

- `sobol_sample` and `halton_sample` are unscrambled without a seed, which matches SciPy with `scramble=False`. SciPy scrambles by default.
- `wasserstein_nd` needs two point sets of the same size.
- `goodness_of_fit` supports families without shape parameters only.
- `dist_fit` finds the same maximum-likelihood optimum by a different search, so the last digits can differ.
- `lapack_ggev` returns the eigenvalues in a different order and scale from LAPACK. The ratios alpha/beta are correct. The eigenvectors come back as complex columns, not LAPACK's packed real pairs.
- `mismatch_frac` and `kulczynski1` replace the removed `cdist` metrics. Call them directly: two vectors give a number, two matrices give the matrix of all pairs of rows.
- `kendalltau_seasonal` uses underscored keys such as `seasonal_tau` and `global_pvalue_dep`.
- `nan_trim_sem` and `trim_mean_ci` drop NaN values first.

**Change to existing functions (agreed).** The QZ routine behind `qz`, `ordqz` and `lapack_ggev` did not converge for real matrices whose generalized eigenvalues are complex. It now uses Wilkinson shifts, and moves a zero on the diagonal of B to the bottom. Real input with complex eigenvalues now gives a complex triangular result. Real input with real eigenvalues still gives the same results as before. The front end needs no change for this.

## 6. Pop-up text for each function
