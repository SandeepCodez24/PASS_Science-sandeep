import json, os, re, subprocess, sys, tempfile
import numpy as np, scipy.io as sio
from scipy.io import wavfile, netcdf_file, FortranFile
sys.stdout.reconfigure(encoding='utf-8')
ROOT=r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
NC=ROOT+r'\src\main\cpp\nc.exe'
sp=sys.argv[1]
d=tempfile.mkdtemp().replace('\\','/')
script='''
A = [1,0,2;0,0,3;4,5,0];
S = sparse_csr(A);
mm_write("%(d)s/a.mtx", S);
mm_write("%(d)s/b.mtx", sparse_csr([4,1,0;1,3,0;0,0,2]));
mm_write("%(d)s/c.mtx", A);
hb_write("%(d)s/a.hb", S);
wav_write("%(d)s/a.wav", 8000, [1,-2,3,1000]);
wav_write("%(d)s/f.wav", 8000, [0.5,-0.25,0.125]);
wav_write("%(d)s/s.wav", 8000, [1,2;3,4;5,6]);
m = sparse_to_dense(S);
q = load_arff("data/fx.arff");
g = dict(["v"], [1]);
g["v"] = [1,2,3];
g["m"] = A;
netcdf_write("%(d)s/a.cdf", g);
fortran_write("%(d)s/a.unf", [0.5,1.5]);
fortran_write("%(d)s/a.unf", [2,3], "int32", 1);
print(scipy_status());
print(numel(scipy_functions()));
names = scipy_functions();
for k = [0:numel(names)-1]:
  print("NAME " + names[k]);
fend
''' % {'d':d}
f=os.path.join(d,'w.nc'); open(f,'w').write(script)
o=subprocess.run([NC,f],capture_output=True,text=True,encoding='utf-8',errors='replace',cwd=ROOT+r'\src\test\scipy')
out=o.stdout+o.stderr
print(out[:1500] if 'NAME' not in out else out[:out.index('NAME')][:1500])
print('--- SciPy reads the NC files')
A=np.array([[1,0,2],[0,0,3],[4,5,0.]])
print('mm sparse',np.allclose(sio.mmread(d+'/a.mtx').toarray(),A), sio.mminfo(d+'/a.mtx'))
print('mm sym',sio.mminfo(d+'/b.mtx'), sio.mmread(d+'/b.mtx').toarray().tolist())
print('mm dense',np.allclose(sio.mmread(d+'/c.mtx'),A))
print('hb',np.allclose(sio.hb_read(d+'/a.hb').toarray(),A))
print('wav',wavfile.read(d+'/a.wav'),wavfile.read(d+'/f.wav'),wavfile.read(d+'/s.wav'))
with netcdf_file(d+'/a.cdf','r',mmap=False) as n:
    print('cdf',{k:v[:].tolist() for k,v in n.variables.items()})
with FortranFile(d+'/a.unf','r') as u:
    print('unf',u.read_reals(float),u.read_ints(np.int32))
print('--- spec names')
names=set(re.findall(r'NAME (\S+)',out))
print('registered',len(names))
spec=json.load(open(os.path.join(sp,'spec12.json'),encoding='utf-8'))
want={}
for e in spec:
    for m in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\(\)',e['nc']) or re.findall(r'[A-Za-z_][A-Za-z0-9_]*',e['nc'])[:1]:
        want.setdefault(m,[]).append(e['sno'])
print('spec names',len(want))
print('missing from registry:',sorted(n for n in want if n.lower() not in {x.lower() for x in names}))
