# Generates Scipy/scipy_doc_table.cpp: NC name -> summary, SciPy original, from the mapping tables.
import json,re,sys
spec=json.load(open(sys.argv[1],encoding='utf-8'))
out=sys.argv[2]
seen={}
for e in spec:
    for n in re.findall(r'[A-Za-z_][A-Za-z0-9_]*',e['nc']):
        if n not in seen and not e['args'].startswith('(constant'):
            seen[n]=(e['desc'].replace('\n',' '),e['scipy'].split('\n')[0])
# Helpers the phase 4 examples use that are not rows of the mapping tables.
EXTRA={'dist_pdf':'Density of a distribution value at x.','dist_pmf':'Probability of the value k under a discrete distribution value.',
       'dist_cdf':'Cumulative probability of a distribution value at x.','dist_sf':'Survival function (1 - cdf) of a distribution value at x.',
       'dist_ppf':'Quantile (inverse cdf) of a distribution value.','dist_rvs':'Random draws from a distribution value.',
       'dist_mean':'Mean of a distribution value.','dist_var':'Variance of a distribution value.',
       'dist_std':'Standard deviation of a distribution value.','dist_median':'Median of a distribution value.',
       'mismatch_frac':'Fraction of positions where two boolean vectors differ (pairwise for two matrices).',
       'kulczynski1':'Kulczynski 1 dissimilarity of two boolean vectors: both-true count over mismatch count.'}
for n,d in EXTRA.items():
    seen.setdefault(n,(d,'stats distribution method' if n.startswith('dist_') else 'spatial.distance (removed metric)'))
# Plain-ASCII spellings of the characters the mapping tables use. Superscripts
# become ^x and subscripts _x (H¹ᵥ -> H^1_v), Greek letters their names.
ASCII={'–':'-','—':'-','−':'-','≤':'<=','·':'*','×':'x','→':'->','…':'...','°':' deg','⊗':' kron ','≈':'~','∞':'inf',
       '√':'sqrt','∫':'integral','′':"'",'’':"'",'ᴴ':'^H','ᵀ':'^T',
       '⁰':'^0','¹':'^1','²':'^2','³':'^3','⁴':'^4','⁵':'^5','⁶':'^6','⁷':'^7','⁸':'^8','⁹':'^9','⁻':'^-','ᵐ':'^m','ᵖ':'^p',
       '₀':'_0','₁':'_1','₂':'_2','₋':'_-','₊':'_+','ₙ':'_n','ᵥ':'_v',
       'α':'alpha','β':'beta','Γ':'Gamma','λ':'lambda','Λ':'Lambda','π':'pi','φ':'phi','Φ':'Phi','ζ':'zeta','ν':'nu',
       'ψ':'psi','τ':'tau','ε':'epsilon','μ':'mu','Σ':'Sigma','θ':'theta','ρ':'rho','ξ':'xi','ħ':'hbar',
       'å':'a','ö':'o','é':'e','ñ':'n'}
def q(s):
    s=s.replace('\\','\\\\').replace('"','\\"')
    for a,b in ASCII.items():
        s=s.replace(a,b)
    s=s.encode('ascii','replace').decode()
    # '??' followed by one of =/'()!<>- is a trigraph in C++: escape the second '?'
    s=s.replace('??','?\\?')
    return '"'+s+'"'
L=['// Generated from the SciPy-to-NC mapping tables (phases 1-5): one row per NC name.','// Do not edit by hand.','#include "scipy_core.h"','','namespace nc {','namespace scipy {','','namespace {','struct DocRow {','  const char *name, *summary, *original;','};','const DocRow kRows[] = {']
for n in sorted(seen):
    L.append('    {%s, %s, %s},'%(q(n),q(seen[n][0]),q(seen[n][1])))
L+=['};','} // namespace','',
'FunctionSpec makeSpec(const char *name, Section s, int minArgs, int maxArgs, const char *params,',
'                      Impl impl, bool acceptsComplex) {',
'  static const std::unordered_map<std::string, const DocRow *> table = [] {',
'    std::unordered_map<std::string, const DocRow *> t;',
'    for (const DocRow &r : kRows)',
'      t.emplace(r.name, &r);',
'    return t;',
'  }();',
'  FunctionSpec spec;',
'  spec.name = name;',
'  spec.section = s;',
'  spec.minArgs = minArgs;',
'  spec.maxArgs = maxArgs;',
'  spec.signature = std::string(name) + "(" + params + ")";',
'  auto it = table.find(name);',
'  if (it != table.end()) {',
'    spec.summary = it->second->summary;',
'    spec.scipyName = it->second->original;',
'  }',
'  spec.impl = std::move(impl);',
'  spec.acceptsComplex = acceptsComplex;',
'  return spec;',
'}','','} // namespace scipy','} // namespace nc','']
open(out,'w',encoding='utf-8',newline='\n').write('\n'.join(L))
print(len(seen))
