"""Writes docs/SciPy_Phase1_2_Frontend_Changes.md and docs/SciPy_Phase1_2_signatures.tsv
from the spec tables (spec12.json), the registered inputs in the C++ sources, and the
examples that were actually run. Usage: gen_frontend_doc.py <folder with spec12.json, spec_fail.txt>"""
import glob, importlib, json, os, re, sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
SRC = ROOT + r'\src\main\cpp\runtime\interpreter\Scipy'
TESTS = ROOT + r'\src\test\scipy'
sp = sys.argv[1]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
spec = json.load(open(os.path.join(sp, 'spec12.json'), encoding='utf-8'))
failed = {}
for l in open(os.path.join(sp, 'spec_fail.txt'), encoding='utf-8'):
    a = l.split('|')
    failed[a[0]] = a

# ---- inputs from the sources ----
params = {}
for f in glob.glob(SRC + r'\**\*.cpp', recursive=True):
    s = open(f, encoding='utf-8').read()
    joined = s.replace('\\\n', ' ')
    for m in re.finditer(r'SP_ADD\("(\w+)",\s*(\d+),\s*(\d+),\s*"((?:[^"\\]|\\.)*)"\)', joined):
        params[m.group(1)] = (int(m.group(2)), int(m.group(3)), m.group(4).replace('\\"', '"'))
    for m in re.finditer(r'#define (\w+)\((\w+)[^)]*\)((?:[^\n]*\n?)*?)(?=\n#|\n  [A-Z_]+\(|\Z)', joined):
        pass
    for dm in re.finditer(r'#define (\w+)\(([^)]*)\)[^\n]*SP_ADD\((\w+),\s*(\d+),\s*(\d+),\s*"((?:[^"\\]|\\.)*)"\)', joined):
        macro, args, nm, mn, mx, ps = dm.groups()
        idx = [x.strip() for x in args.split(',')].index(nm)
        for inv in re.finditer(r'\b' + macro + r'\(("[^"]*"(?:[^()\n]|\([^()]*\))*)\)', joined):
            first = re.findall(r'"(\w+)"', inv.group(1))
            if first:
                params[first[idx] if idx < len(first) else first[0]] = (int(mn), int(mx), ps.replace('\\"', '"'))

# Names made by macros the pattern above cannot read: ask nc.exe for its usage text.
import subprocess, tempfile
def usage_from_nc(name):
    f = os.path.join(tempfile.mkdtemp(), 'u.nc')
    open(f, 'w').write('r = %s(%s);\n' % (name, ','.join(['1'] * 14)))
    out = subprocess.run([ROOT + r'\src\main\cpp\nc.exe', f], capture_output=True, text=True, encoding='utf-8', errors='replace').stderr
    m = re.search(r'expects (\d+)(?: to (\d+)| or more)?.*?usage: ' + name + r'\((.*)\)', out)
    return m
for e in spec:
    for n in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\(\)', e['nc']):
        if n not in params:
            m = usage_from_nc(n)
            if m:
                params[n] = (int(m.group(1)), int(m.group(2) or m.group(1)), m.group(3))

# ---- examples that ran: the test tables ----
sys.path.insert(0, TESTS + r'\python')
tested = {}
for f in sorted(glob.glob(TESTS + r'\python\tests_*.py')):
    mod = importlib.import_module(os.path.basename(f)[:-3])
    for r in mod.ROWS:
        for n in re.findall(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\(', r.nc):
            tested.setdefault(n, []).append(r.nc)

SECTION_DIR = {}
order, entries = [], {}
const_rows = {}
for e in spec:
    sec = e['section']
    names = re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\(\)', e['nc'])
    if not names:
        n = re.findall(r'[A-Za-z_][A-Za-z0-9_]*', e['nc'])
        if not n:
            continue
        const_rows.setdefault(sec, {}).setdefault(n[0], []).append(e)
        continue
    for n in names:
        entries.setdefault(sec, {}).setdefault(n, []).append(e)
    if sec not in order:
        order.append(sec)
for s in const_rows:
    if s not in order:
        order.insert(0, s)
order.sort(key=lambda s: int(s.split('.')[0]))

EXISTING = {'cholesky', 'convolve', 'correlate', 'load_mat', 'lstsq', 'qr', 'save_mat', 'solve', 'svd', 'trapz'}
BAD_HELPERS = re.compile(r'\b(rand|arange|compare|slice|reverse|col|astype|outer_add|masked_equal)\s*\(|\bones\(\d+\)')

def clean(s):
    return re.sub(r'\s+', ' ', s).strip()

def split_args(a):
    ins, ret = [], ''
    for l in a.split('\n'):
        l = clean(l)
        if not l:
            continue
        if l.lower().startswith('returns:'):
            ret = l[8:].strip()
        elif l != '(no arguments)':
            ins.append(l)
    return ins, ret

def usage(n, es):
    if n in params:
        return '%s(%s)' % (n, params[n][2])
    ins, _ = split_args(es[0]['args'])
    return '%s(%s)' % (n, ', '.join(i.split(':')[0] for i in ins))

def adapt(ex):
    """The spec's helpers rewritten into NC (the table in section 4)."""
    ex = re.sub(r'compare\(([^,]+),\s*"([<>=!]+)",\s*([^)]+)\)', r'\1 \2 \3', ex)
    ex = re.sub(r'\bones\((\d+)\)', r'ones(1, \1)', ex)
    ex = re.sub(r'\bslice\(([^,]+),\s*0,\s*(\d+)\)', lambda m: '%s[0:%d]' % (m.group(1), int(m.group(2)) - 1), ex)
    ex = re.sub(r'\barange\((-?\d+),\s*(-?\d+),\s*1\)', lambda m: 'space(%s, %d, %d)' % (m.group(1), int(m.group(2)) - 1, int(m.group(2)) - int(m.group(1))), ex)
    ex = re.sub(r'\bcol\((\w+),\s*(\d+)\)', r'\1[:, \2]', ex)
    ex = re.sub(r'\brand\((\d+),\s*(\d+)\)', r'nexus_uniform([\1, \2])', ex)
    ex = re.sub(r'\breverse\((\w+)\)', r'\1 * 0.5', ex)
    return ex

_adapted = {}
def adapted_ok(ex):
    if ex in _adapted:
        return _adapted[ex]
    import spec_run_pre
    f = os.path.join(tempfile.mkdtemp(), 'a.nc')
    open(f, 'w', encoding='utf-8').write(spec_run_pre.PRE + ex + '\n')
    r = subprocess.run([ROOT + r'\src\main\cpp\nc.exe', f], capture_output=True, text=True, encoding='utf-8', errors='replace', cwd=TESTS, timeout=120)
    ok = 'Error' not in r.stdout + r.stderr
    _adapted[ex] = ok
    return ok

def example(n, es):
    for e in es:
        ex = e['example'].strip()
        if ex and str(e['sno']) not in failed and not BAD_HELPERS.search(ex):
            return clean(ex.replace('\n', ' ')), True
    for e in es:
        ex = e['example'].strip()
        if not ex:
            continue
        ad = adapt(ex)
        if ad != ex and adapted_ok(ad):
            return clean(ad.replace('\n', ' ')), True
    for r in tested.get(n, []):
        return ('r = %s;' % r), False
    ex = es[0]['example'].strip()
    return clean(ex.replace('\n', ' ')), False

NOTES = {
    'hilbert': 'Two forms: hilbert(n) with one number is the Hilbert matrix; hilbert(data[, n]) is the analytic signal.',
    'fft_convolve': 'Two forms: two equal-length lines and no mode is the periodic fftpack one (kernel from fft_conv_kernel); otherwise the linear one with mode.',
    'stft': 'Two forms: stft(data, window samples, hop, fs) returns the Matrix of ShortTimeFFT; stft(data, fs, nperseg) returns a Dict {f, t, Zxx}.',
    'zoom_fft': 'With three inputs the third is fs: zoom_fft(sig, [0, 50], 500). With four: zoom_fft(data, fn, m, fs).',
    'sparse_block': 'A matrix literal cannot hold objects: write sparse_block(rows, cols, b00, b01, ...) with the blocks row by row, 0 for an empty block.',
    'minimize': 'Inputs after x0 are by position; 0 means "not given": minimize("f", x0, "SLSQP", 0, c). Several constraints: put them in a Dict.',
    'milp': 'Several constraints: put them in a Dict, since a matrix literal cannot hold Dicts.',
    'wav_write': 'NC has no integer dtypes: whole numbers are written as int16 or int32, others as float64; the last input names a format to choose.',
    'find_peaks': '0 means "not given": a height of exactly 0 cannot be asked for by position, give [0, 1/0] instead.',
    'cholesky': 'Already in NC.',
}

def block(n, es):
    usage_line = usage(n, es)
    desc = clean(es[0]['desc'])
    ins, ret = split_args(es[0]['args'])
    lines = [desc if desc.endswith('.') else desc + '.']
    if ins:
        lines.append('Inputs: ' + '; '.join(ins) + '.')
    else:
        lines.append('Inputs: none.')
    if ret:
        lines.append('Returns: ' + ret + '.')
    ex, ran = example(n, es)
    lines.append('Example: `%s`' % ex)
    if n in NOTES:
        lines.append(NOTES[n])
    origin = ', '.join(sorted({clean(e['scipy']) for e in es}))
    lines.append('SciPy: ' + origin + '.')
    assert 3 <= len(lines) <= 6, n
    return usage_line, lines

out = []
tsv = ['# Rows to append to src/main/resources/language/builtin_signatures.tsv (same columns: section, name, usage, description, numpy, keyword_only, named).',
       '# Generated from the SciPy phase 1 and 2 registry; named = no because SciPy functions take positional inputs only.']
java = []
count_fn = count_const = 0
body = []
for sec in order:
    sn = sec.split('.', 1)[1].strip()
    fn = entries.get(sec, {})
    co = const_rows.get(sec, {})
    body.append('\n### %s\n' % sn)
    secKey = re.sub(r'[^a-z0-9]+', '_', re.sub(r'\(.*?\)', '', sn).lower()).strip('_')
    for n in fn:
        if n in EXISTING:
            continue
        u, lines = block(n, fn[n])
        body.append('#### `%s`\n' % u)
        body.extend(l + '  ' for l in lines[:-1])
        body.append(lines[-1] + '\n')
        short = clean(fn[n][0]['desc']).rstrip('.')
        tsv.append('\t'.join(['scipy_' + secKey, n, u, 'SciPy: ' + short, '', '', 'no']))
        java.append('{ "%s", "SciPy: %s" },' % (u.replace('\\', '\\\\').replace('"', '\\"'), short.replace('\\', '\\\\').replace('"', '\\"')))
        count_fn += 1
    if co:
        body.append('\n#### Constants of this section\n')
        body.append('Bare names, used without parentheses: `c = speed_of_light;`\n')
        for n, es in co.items():
            d = clean(es[0]['desc'])
            ex = clean(es[0]['example'].replace('\n', ' '))
            scipy_names = ', '.join(sorted({clean(e['scipy']) for e in es}))
            body.append('**`%s`**  ' % n)
            body.append((d if d.endswith('.') else d + '.') + '  ')
            body.append('Example: `%s`  ' % ex)
            body.append('SciPy: %s.\n' % scipy_names)
            count_const += 1

open(os.path.join(sp, 'body.md'), 'w', encoding='utf-8', newline='\n').write('\n'.join(body))
head = open(os.path.join(sp, 'frontend_head.md'), encoding='utf-8').read()
const_names = sorted({n for c in const_rows.values() for n in c})
head = head.replace('@@FN@@', str(count_fn)).replace('@@CONST@@', str(count_const)).replace('@@CONST_LIST@@', ', '.join('`%s`' % c for c in const_names))
open(ROOT + r'\docs\SciPy_Phase1_2_Frontend_Changes.md', 'w', encoding='utf-8', newline='\n').write(head + '\n'.join(body) + '\n')
open(ROOT + r'\docs\SciPy_Phase1_2_signatures.tsv', 'w', encoding='utf-8', newline='\n').write('\n'.join(tsv) + '\n')
print('functions', count_fn, 'constants', count_const, 'with registry inputs', sum(1 for s in entries.values() for n in s if n in params), 'fallback', [n for s in entries.values() for n in s if n not in params and n not in EXISTING])
