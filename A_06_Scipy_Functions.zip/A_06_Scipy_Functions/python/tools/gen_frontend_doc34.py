"""Writes docs/SciPy_Phase3_4_Frontend_Changes.md and docs/SciPy_Phase3_4_signatures.tsv
from the phase 3 and 4 spec tables (spec1234.json), the usage text the registry reports
(help(name) in nc.exe), the spec examples that ran (spec_fail34.txt from spec_run34.py)
and the test tables. Usage: gen_frontend_doc34.py <folder with spec1234.json,
spec_fail34.txt, frontend_head34.md>"""
import glob, importlib, json, os, re, subprocess, sys, tempfile
sys.stdout.reconfigure(encoding='utf-8')
ROOT = r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
NC = ROOT + r'\src\main\cpp\nc.exe'
TESTS = ROOT + r'\src\test\scipy'
sp = sys.argv[1]
spec = [e for e in json.load(open(os.path.join(sp, 'spec1234.json'), encoding='utf-8')) if e['phase'] in (3, 4)]
failed = {}
for l in open(os.path.join(sp, 'spec_fail34.txt'), encoding='utf-8'):
    a = l.split('|')
    failed[a[0]] = a
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import spec_run34  # noqa: E402  (its PRE: the variables the spec examples assume)

# ---- registered names and their usage text ----
def nc_run(src):
    f = os.path.join(tempfile.mkdtemp(), 'h.nc')
    open(f, 'w', encoding='utf-8').write(src)
    r = subprocess.run([NC, f], capture_output=True, text=True, encoding='utf-8', errors='replace', cwd=TESTS, timeout=600)
    return r.stdout + r.stderr

registered = set(re.findall(r'NAME (\S+)', nc_run('names = scipy_functions();\nfor k = [0:numel(names)-1]:\n  print("NAME " + names[k]);\nfend\n')))

SKIPPED = {'exp1', 'exp10', 'sinc', 'log1p', 'sign', 'kron'}  # NumPy names kept as they are
EXTRA = {  # helpers not in the spec list that the spec examples use
    'dist_pdf': ('Density of a distribution value at x.', 'dist: Dict from normal_dist(), make_dist(), ...; x: Scalar or Array', 'same shape as x', 'p = dist_pdf(normal_dist(0, 1), 0.5);'),
    'dist_pmf': ('Probability of each value k of a discrete distribution value.', 'dist: Dict (e.g. binomial_dist(10, 0.5)); k: Scalar or Array', 'same shape as k', 'p = dist_pmf(binomial_dist(10, 0.5), 5);'),
    'dist_cdf': ('Probability of a value at or below x for a distribution value.', 'dist: Dict; x: Scalar or Array', 'same shape as x', 'c = dist_cdf(normal_dist(0, 1), 1.96);'),
    'dist_sf': ('Probability of a value above x (1 - cdf) for a distribution value.', 'dist: Dict; x: Scalar or Array', 'same shape as x', 's = dist_sf(normal_dist(0, 1), 1.96);'),
    'dist_ppf': ('The value below which a fraction q of a distribution value lies.', 'dist: Dict; q: Scalar or Array (0 to 1)', 'same shape as q', 'v = dist_ppf(normal_dist(0, 1), 0.975);'),
    'dist_rvs': ('Random draws from a distribution value.', 'dist: Dict; n: Int, optional (default 1: one number)', 'Array of n values (a number when n is left out)', 'r = dist_rvs(normal_dist(0, 1), 5);'),
    'dist_mean': ('Mean of a distribution value.', 'dist: Dict', 'Float', 'm = dist_mean(uniform_dist(0, 1));'),
    'dist_var': ('Variance of a distribution value.', 'dist: Dict', 'Float', 'v = dist_var(uniform_dist(0, 1));'),
    'dist_std': ('Standard deviation of a distribution value.', 'dist: Dict', 'Float', 's = dist_std(uniform_dist(0, 1));'),
    'dist_median': ('Median of a distribution value.', 'dist: Dict', 'Float', 'm = dist_median(exp_dist(normal_dist(0, 1)));'),
}
APPENDIX_EXTRA = {  # removed SciPy metrics, callable directly instead of through cdist
    'mismatch_frac': ('Fraction of positions where two boolean vectors differ (nonzero = true); two matrices give every pair of rows.',
                      'u, v: Arrays of Bool (or Matrices, one observation per row)', 'Float, or a Matrix for two matrices',
                      'd = mismatch_frac([1,0,1], [1,1,0]);', 'SciPy: distance.kulsinski() (removed); the replacement the spec names.'),
    'kulczynski1': ('Kulczynski 1 dissimilarity of two boolean vectors: positions true in both, over positions that differ.',
                    'u, v: Arrays of Bool (or Matrices, one observation per row)', 'Float, or a Matrix for two matrices',
                    'd = kulczynski1([1,0,1], [1,1,0]);', 'SciPy: distance.kulczynski1() (removed).'),
}

# ---- examples that ran: the test tables ----
sys.path.insert(0, TESTS + r'\python')
tested = {}
for f in sorted(glob.glob(TESTS + r'\python\tests_*.py')):
    mod = importlib.import_module(os.path.basename(f)[:-3])
    for r in mod.ROWS:
        for n in re.findall(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\(', r.nc):
            tested.setdefault(n, []).append(r.nc)

order, entries = [], {}
for e in spec:
    sec = e['section']
    for n in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\(\)', e['nc']):
        entries.setdefault(sec, {}).setdefault(n, []).append(e)
    if sec not in order:
        order.append(sec)

# names shown in an earlier section, or existing before phase 3 (appendix replacements)
APPENDIX_NEW = {'bspline_basis', 'sort_by_magnitude', 'cwt', 'ricker_wavelet', 'morlet_wavelet', 'morlet2_wavelet', 'wavelet_function',
                'wavelet_filters', 'qmf', 'unique_counts', 'tri', 'lapack_ggev', 'derivative', 'help', 'central_diff_weights'}

all_names = sorted({n for s in entries.values() for n in s if n in registered} | set(EXTRA) | set(APPENDIX_EXTRA))
help_out = nc_run(''.join('help("%s");\n' % n for n in all_names))
usage_of = {}
for line in help_out.split('\n'):
    m = re.match(r'^([a-z_0-9]+)\((.*)\)\s*$', line.strip())
    if m and m.group(1) in all_names:
        usage_of[m.group(1)] = '%s(%s)' % (m.group(1), m.group(2))

def clean(s):
    return re.sub(r'\s+', ' ', s).strip()

def split_args(a):
    ins, ret = [], ''
    for l in a.split('\n'):
        l = clean(l)
        if not l:
            continue
        if l.lower().startswith('returns:'):
            ret = l[8:].strip()
        elif l != '(no arguments)':
            ins.append(l)
    return ins, ret

BAD = re.compile(r'\b(rand|arange|compare|slice|col|full|outer_add)\s*\(|\bones\(\d+\)')

def adapt(ex):
    ex = re.sub(r'\barange\((-?\d+),\s*(-?\d+),\s*1\)', lambda m: 'space(%s, %d, %d)' % (m.group(1), int(m.group(2)) - 1, int(m.group(2)) - int(m.group(1))), ex)
    ex = re.sub(r'\brand\((\d+),\s*(\d+)\)', r'nexus_uniform([\1, \2])', ex)
    ex = re.sub(r'\bfull\((\d+),\s*1/(\d+)\)', r'ones(1, \1) / \2', ex)
    ex = re.sub(r'\bones\((\d+)\)', r'ones(1, \1)', ex)
    ex = re.sub(r'\bcol\((\w+),\s*(\d+)\)', r'\1[:, \2]', ex)
    ex = re.sub(r'\bslice\((\w+),\s*(\d+),\s*(\d+)\)', lambda m: '%s[%d:%d, :]' % (m.group(1), int(m.group(2)), int(m.group(3)) - 1), ex)
    ex = ex.replace('mixture_dist([normal_dist(-2,1), normal_dist(2,1)], [0.5,0.5])', 'mixture_dist(normal_dist(-2,1), normal_dist(2,1), [0.5,0.5])')
    ex = ex.replace('[data, data2]', '[data; data2]').replace('([data],', '(data,')
    return ex

_ok = {}
def runs(ex):
    if ex not in _ok:
        out = nc_run(spec_run34.PRE + ex + '\n')
        _ok[ex] = not any('Error' in l for l in out.split('\n'))
    return _ok[ex]

def first_line(ex):
    return clean(ex.split('\n')[0]) if ex else ''

def example(n, es):
    for e in es:
        ex = e['example'].strip()
        if ex and str(e['sno']) not in failed and not BAD.search(ex) and n in ex:
            return ' '.join(clean(l) for l in ex.split('\n') if l.strip() and not l.strip().startswith('#'))
    for e in es:
        ex = e['example'].strip()
        if ex:
            ad = adapt(ex)
            body = ' '.join(clean(l) for l in ad.split('\n') if l.strip() and not l.strip().startswith('#'))
            if n in body and runs(ad):
                return body
    for r in tested.get(n, []):
        return 'r = %s;' % r
    return first_line(es[0]['example'])

NOTES = {
    'mixture_dist': 'A matrix cannot hold Dicts: give the components as separate inputs, then the weights.',
    'permutation_test': 'Samples as separate arrays or the rows of one matrix ([data; data2]); [data, data2] joins them into one sample.',
    'bootstrap': 'Samples as separate arrays or matrix rows; the statistic is an NC function of the sample(s).',
    'anderson_ksamp': 'Samples as separate arrays or matrix rows ([a; b]); [a, b] joins them into one sample.',
    'test_power': 'Generators: distribution names ("norm") or NC functions of n; the test may return a p-value or a Dict with pvalue.',
    'monte_carlo_test': 'rvs: a distribution name ("norm") or an NC function of n returning n values (NC has no randn).',
    'sobol_sample': 'Without seed the sequence is unscrambled (as SciPy with scramble=False); a seed adds a random digital shift.',
    'halton_sample': 'Without seed the sequence is unscrambled (as SciPy with scramble=False); a seed adds a random shift.',
    'kendalltau_seasonal': 'Dict keys use underscores: seasonal_tau, global_tau, global_tau_alt, seasonal_pvalue, global_pvalue_indep, global_pvalue_dep, chi2_total, chi2_trend.',
    'trim_mask': 'NaN marks a masked (trimmed) value; NaN in limits means no limit on that side.',
    'sample_ratio_uniforms': 'Four inputs (pdf, mode, area, n) is the simple form; five or six (pdf, umax, vmin, vmax, n[, seed]) the general one.',
    'lapack_ggev': 'Eigenvalue order and the scale of alpha and beta may differ from LAPACK; alpha/beta and the vectors match.',
    'dist_fit': 'Bounds: a Dict name -> [low, high] or one matrix row per parameter (shapes, loc, scale); loc and scale without bounds stay 0 and 1.',
    'mvs_dist': 'Returns distribution Dicts: evaluate them with dist_mean(), dist_cdf(), ...',
    'help': 'Prints the usage, summary and SciPy original of a SciPy function.',
    'assoc_legendre_p_all': 'Complex z uses (1 - z^2)^(m/2) on the principal branch; real |x| > 1 gives NaN for m != 0, as SciPy.',
}

FAM_OP = {
    'pdf': 'Probability density of the %s at x.',
    'pmf': 'Probability of the value k under the %s.',
    'cdf': 'Probability of a value at or below x under the %s (cumulative distribution).',
    'sf': 'Probability of a value above x under the %s (1 - cdf, accurate in the far tail).',
    'ppf': 'The value below which a fraction q of the %s lies (inverse cdf).',
    'rvs': 'n random draws from the %s.',
}

def split_top(s):
    """Splits call arguments at the commas outside brackets."""
    out, depth, cur = [], 0, ''
    for ch in s:
        if ch in '([':
            depth += 1
        elif ch in ')]':
            depth -= 1
        if ch == ',' and depth == 0:
            out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def family_blocks(es):
    e = es[0]
    names = re.findall(r'([A-Za-z_][A-Za-z0-9_]*)\(\)', e['nc'])
    what = clean(e['desc']).split(',')[0].split(':')[0].rstrip('.')
    what = what[0].lower() + what[1:] if what[:1].isupper() and not what[1:2].isupper() else what
    ins, ret = split_args(e['args'])
    shape_ins = [i for i in ins[1:] if not i.lower().startswith('loc')]
    m = re.match(r'\w+\s*=\s*\w+_(pdf|pmf|cdf|sf|ppf|rvs)\((.*)\);', e['example'].split('\n')[0])
    args = split_top(m.group(2)) if m else []
    nshape = sum(1 for i in shape_ins if not i.startswith('(no'))
    if m and m.group(1) == 'rvs':  # (shapes..., n): the example has no point to evaluate
        shapes = args[:nshape]
        x0 = '0' if '(Int' in e['args'].split('\n')[0] else '0.5'
    else:
        shapes = args[1:1 + nshape]
        x0 = args[0] if args else '1'
    out = []
    for n in names:
        op = n.rsplit('_', 1)[1]
        lines = [FAM_OP[op] % (what if 'distribution' in what else what + ' distribution')]
        if op == 'rvs':
            lines.append('Inputs: ' + '; '.join(shape_ins + ['loc, scale: Float, optional', 'n: Int (last input)']) + '.')
            lines.append('Returns: Array of n values.')
            ex = 'r = %s(%s);' % (n, ', '.join(shapes + ['5']))
        else:
            first = {'ppf': 'q: Scalar or Array (probabilities)', 'pmf': 'k: Scalar or Array (whole numbers)'}.get(op, 'x: Scalar or Array')
            lines.append('Inputs: ' + '; '.join([first] + [i for i in shape_ins if not i.startswith('(no')] + ['loc, scale: Float, optional']) + '.')
            lines.append('Returns: same shape as the first input.')
            ex = 'v = %s(%s);' % (n, ', '.join(['0.5' if op == 'ppf' else x0] + shapes))
        lines.append('Example: `%s`' % ex)
        lines.append('SciPy: %s.%s.' % (clean(e['scipy']), op))
        out.append((n, lines))
    return out

def block(n, es):
    if n in EXTRA:
        d, i, r, ex = EXTRA[n]
        return [d, 'Inputs: ' + i + '.', 'Returns: ' + r + '.', 'Example: `%s`' % ex, 'SciPy: method of a distribution object (Normal().cdf, ...).']
    desc = clean(es[0]['desc'])
    ins, ret = split_args(es[0]['args'])
    lines = [desc if desc.endswith('.') else desc + '.']
    # NC has no list type: say how the "list" inputs are written
    ins = [i.replace('list of Arrays', 'Arrays (separate inputs, or the rows of one matrix)')
            .replace('list of Dicts', 'Dicts, as separate inputs')
            .replace('list of Strings', 'text list such as ["norm", "norm"]') for i in ins]
    lines.append(('Inputs: ' + '; '.join(ins) + '.') if ins else 'Inputs: none.')
    if ret:
        lines.append('Returns: ' + ret + '.')
    lines.append('Example: `%s`' % example(n, es))
    if n in NOTES:
        lines.append(NOTES[n])
    lines.append('SciPy: ' + ', '.join(sorted({clean(e['scipy']) for e in es})) + '.')
    if len(lines) > 6:  # keep the note, merge inputs and returns
        lines = lines[:1] + [lines[1] + ' Returns: ' + ret + '.'] + lines[3:]
    assert 3 <= len(lines) <= 6, n
    return lines

def secKey(sn):
    return re.sub(r'[^a-z0-9]+', '_', re.sub(r'\(.*?\)', '', sn).lower()).strip('_')

body, tsv = [], ['# Rows to append to src/main/resources/language/builtin_signatures.tsv (same columns: section, name, usage, description, numpy, keyword_only, named).',
                 '# Generated from the SciPy phase 3 and 4 registry; named = no because SciPy functions take positional inputs only.']
shown, count_fn, mapped = set(), 0, []
for sec in order:
    sn = sec.split('.', 1)[1].strip() if sec[0].isdigit() else sec
    key = 'scipy_' + secKey(sn if sec[0].isdigit() else 'removed_since_1_8')
    body.append('\n### %s\n' % sn)
    fams = sec.startswith('22')
    seen_rows = set()
    for n, es in entries.get(sec, {}).items():
        if n in SKIPPED or n in shown:
            continue
        if sec.startswith('Appendix') and n not in APPENDIX_NEW:
            mapped.append((n, es))
            continue
        if n not in registered:
            continue
        if fams:
            if id(es[0]) in seen_rows:
                continue
            seen_rows.add(id(es[0]))
            pairs = family_blocks(es)
        else:
            pairs = [(n, block(n, es))]
        for name, lines in pairs:
            if name in shown:
                continue
            shown.add(name)
            u = usage_of.get(name, name + '()')
            body.append('#### `%s`\n' % u)
            body.extend(l + '  ' for l in lines[:-1])
            body.append(lines[-1] + '\n')
            short = clean(lines[0]).rstrip('.')
            tsv.append('\t'.join([key, name, u, 'SciPy: ' + short, '', '', 'no']))
            count_fn += 1
    if sec.startswith('21'):
        body.append('\n#### Methods of distribution values (not in the spec list; the spec examples use them)\n')
        for n in EXTRA:
            shown.add(n)
            u = usage_of.get(n, n + '()')
            lines = block(n, [])
            body.append('#### `%s`\n' % u)
            body.extend(l + '  ' for l in lines[:-1])
            body.append(lines[-1] + '\n')
            tsv.append('\t'.join(['scipy_statistics', n, u, 'SciPy: ' + lines[0].rstrip('.'), '', '', 'no']))
            count_fn += 1

for n, (d, i, r, ex, src) in APPENDIX_EXTRA.items():
    u = usage_of.get(n, n + '()')
    lines = [d, 'Inputs: ' + i + '.', 'Returns: ' + r + '.', 'Example: `%s`' % ex,
             'Call it directly; cdist does not take NC functions as metrics.', src]
    body.append('#### `%s`\n' % u)
    body.extend(l + '  ' for l in lines[:-1])
    body.append(lines[-1] + '\n')
    tsv.append('\t'.join(['scipy_removed_since_1_8', n, u, 'SciPy: ' + d.split(';')[0].rstrip('.'), '', '', 'no']))
    count_fn += 1
    shown.add(n)

body.append('\n#### Appendix A names that map to functions NC already has\n')
body.append('These need no new rows: the pop-up of the existing function applies.\n')
body.append('| Removed in SciPy | Use in NC |')
body.append('|---|---|')
for n, es in mapped:
    for e in es:
        body.append('| `%s` | `%s` |' % (clean(e['scipy']), n))

head = open(os.path.join(sp, 'frontend_head34.md'), encoding='utf-8').read().replace('@@FN@@', str(count_fn))
open(ROOT + r'\docs\SciPy_Phase3_4_Frontend_Changes.md', 'w', encoding='utf-8', newline='\n').write(head + '\n'.join(body) + '\n')
open(ROOT + r'\docs\SciPy_Phase3_4_signatures.tsv', 'w', encoding='utf-8', newline='\n').write('\n'.join(tsv) + '\n')
missing_usage = [n for n in shown if n not in usage_of]
print('functions', count_fn, 'without registry usage', missing_usage[:20])
