"""Bad and edge inputs for every registered function: nc.exe must answer with an error or a
value, never crash or hang."""
import concurrent.futures, os, re, subprocess, sys, tempfile
sys.stdout.reconfigure(encoding='utf-8')
ROOT=r'D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01'
NC=ROOT+r'\src\main\cpp\nc.exe'
d=tempfile.mkdtemp()
# fuzz.py [section ...] fuzzes only those sections (folder names such as "statistics")
def listed(sec):
    f=os.path.join(d,'n.nc'); open(f,'w').write('names = scipy_functions(%s);\nfor k = [0:numel(names)-1]:\n  print("NAME " + names[k]);\nfend\n' % ('"%s"' % sec if sec else ''))
    return re.findall(r'NAME (\S+)',subprocess.run([NC,f],capture_output=True,text=True,encoding='utf-8',errors='replace').stdout)
names=[n for sec in (sys.argv[1:] or ['']) for n in listed(sec)]
SKIP={'dataset_download_all','dataset_clear_cache','dataset_ascent','dataset_face','dataset_ecg','scipy_status','scipy_functions'}
names=[n for n in names if n not in SKIP]
CASES=['','1','0','-1','"x"','[]','[1,2,3]','[1,2;3,4]','1,1','[1,2,3],[1,2]','[1,2;3,4],[1,2,3]','"x","y"','[1,2,3],1,1','[1,2;3,4],[1,2;3,4],[1,2;3,4]','0/0,1/0','[0/0,1/0,2]','[1,2,3],[4,5,6],[7,8,9],[1,2]','zeros(0,0),1','1000000000']
def run(a):
    n,c=a
    with tempfile.NamedTemporaryFile('w',suffix='.nc',delete=False,encoding='utf-8',dir=d) as fh:
        fh.write('r = %s(%s);\n'%(n,c)); p=fh.name
    try:
        r=subprocess.run([NC,p],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=25,cwd=d)
    except subprocess.TimeoutExpired:
        return n,c,'HANG'
    finally:
        try: os.unlink(p)
        except OSError: pass
    if r.returncode not in (0,1,255) :
        return n,c,'CRASH %d'%r.returncode
    return None
jobs=[(n,c) for n in names for c in CASES]
print(len(names),'functions',len(jobs),'calls')
bad=[]
with concurrent.futures.ThreadPoolExecutor(10) as ex:
    for r in ex.map(run,jobs):
        if r: bad.append(r)
print(len(bad),'bad')
for b in bad[:200]:
    print(b)
