$repo = "D:\My Research Works\PASS Science Works\Main_Repository\Astra_UniPro_01"
& "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\Launch-VsDevShell.ps1" -Arch amd64 -HostArch amd64 -SkipAutomaticLocation 2>$null | Out-Null
$env:NC_TOOLCHAIN_ROOT = "$repo\build\toolchain"
$env:PATH = "$env:NC_TOOLCHAIN_ROOT\bin;$env:PATH"
Set-Location "$repo\build\nc-build-debug"
& ninja.exe -k 0 2>&1 | Select-String -Pattern "error:|FAILED|warning: unused|ninja: |Linking" | Select-Object -First 60 | ForEach-Object { $_.Line }
Write-Output "done"
