"""Variables and helper functions the spec examples assume."""
PRE='''t = space(0, 1, 500);
sig = sin(2*pi*5*t) + 0.5*cos(2*pi*30*t);
x = space(0, 10, 11);
y = [0,1,3,2,5,4,1,0,2,7,3,1];
img = outer(hann_win(32), hann_win(32));
M32 = img;
A = [4,1,2;1,3,0;2,0,5];
B = [1,2;3,4;5,6];
b = butter(4, 0.2)["b"];
a = butter(4, 0.2)["a"];
S = sparse_csr(A);
G = sparse_csr([0,1,4;0,0,2;0,0,0]);
P = [0.1,0.2;0.15,0.22;0.9,0.8;0.92,0.85;0.5,0.1;0.52,0.14;0.2,0.9;0.25,0.95;0.7,0.3;0.6,0.75];
Q = P;
lbl = img_label(img > 0.5)["labels"];
markers = lbl;
p = find_peaks(y)["peaks"];
F = fft2(img);
Z = stft(sig, 500, 64)["Zxx"];
function y = f(v):
  y = v;
fnend
function y = d2(m, axis):
  y = img_correlate1d(m, [1,-2,1], axis);
fnend
function y = shift_half(p):
  y = [p[0] + 0.5, p[1] - 0.5];
fnend
function y = psd(v):
  y = sum(v *. v);
fnend
'''
