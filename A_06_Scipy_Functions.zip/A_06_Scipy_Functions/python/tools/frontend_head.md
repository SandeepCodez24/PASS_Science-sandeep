# SciPy Phases 1 and 2: Front-End Changes

The back end (`nc.exe`) now has @@FN@@ new SciPy functions and @@CONST@@ new constants. The Java front end does not know any of them yet, so the editor will not suggest them, will not colour them, and will report the constants as undefined names. This document lists what to change. No Java file was changed for this work.

| Area | File | Change |
|---|---|---|
| Syntax checker and signatures | `src/main/resources/language/builtin_signatures.tsv` | Append the rows of [SciPy_Phase1_2_signatures.tsv](SciPy_Phase1_2_signatures.tsv) |
| Constants (colour and undefined-name check) | `src/main/java/language/syntax/textcolours/ConstantWords.java` | Add the names in section 3 |
| Auto-suggestions | `src/main/java/language/syntax/textcolours/library/ScipyFunctions.java` | One `{ signature, description }` entry per function; the box shows the text of section 6 |
| Colour pattern | none beyond the two rows above | Functions use `.tc-function-call`, constants use `.tc-constant` |

## 1. Syntax side

**Function names and inputs.** Each row of the TSV gives the name and its usage text. The usage text follows the existing convention: `name` must be given, `name=value` has a default.

**Positional inputs only.** SciPy functions do not take `name=value` inputs, so the last TSV column (`named`) is `no`. The checker should report `butter(4, 0.2, btype="low")` the way it reports other functions with `named = no`.

**`0` means "not given".** To reach a later input, a script writes `0` for the ones it skips:

```
r = minimize("rosen", [0.5, 0.5], "SLSQP", 0, c);
```

The checker must not flag a `0` in these positions as a wrong type.

**Function names as text.** An input described as `fn` accepts an NC function by name (`"f"`) or by reference (`@f`). The name may also be a builtin (`minimize_scalar("cos", [3, 4], "bounded")`). Do not report the text as an unknown string.

**Functions with two forms.** These have one name and two meanings, so the checker should accept both:

| Name | Form 1 | Form 2 |
|---|---|---|
| `hilbert` | `hilbert(n)`: the Hilbert matrix | `hilbert(data[, n])`: the analytic signal |
| `fft_convolve` | `fft_convolve(data, kernel)`: periodic, from fftpack | `fft_convolve(a, b, mode)`: linear, from `signal` |
| `stft` | `stft(data, window, hop, fs)`: returns a Matrix | `stft(data, fs, nperseg)`: returns a Dict |
| `zoom_fft` | `zoom_fft(data, fn, fs)` | `zoom_fft(data, fn, m, fs)` |
| `lti_system` | `lti_system(b, a)` or `(z, p, k)` | `lti_system(A, B, C, D)` |

**Skipped names.** These 10 spec names already existed and were not changed: `cholesky`, `convolve`, `correlate`, `load_mat`, `lstsq`, `qr`, `save_mat`, `solve`, `svd`, `trapz`. They need no new rows. The existing `cholesky` takes one input, so the spec's `cholesky(A, 1)` is an error today.

## 2. Auto-suggestion side

`ScipyFunctions.ENTRIES` holds `{ signature, description }`. Example:

```java
{ "butter(n, Wn, btype=\"low\", output=\"ba\", fs)", "SciPy: Butterworth digital and analog filter design" },
```

Section 6 gives 3 to 6 lines for every function. Each block has this layout, and the box should show the lines in this order:

1. What the function is for
2. Its inputs
3. What it returns
4. A working example
5. A note, only where the function has a trap
6. The SciPy original

The TSV holds the short description for the one-line list; section 6 holds the long text for the pop-up. `ENTRIES` has only two text fields today, so the long text needs a third field or a separate table. That is the one design choice left open for the front end.

## 3. Colour pattern side

**Functions.** No new colour. Names in `ScipyFunctions` already paint as `.tc-function-call`.

**Constants.** Add these to `ConstantWords.WORDS`. They then take the `.tc-constant` colour, and the undefined-name check accepts them. Names are case-sensitive.

@@CONST_LIST@@

**Everyday words in this list.** `day`, `hour`, `minute`, `year`, `inch`, `mile`, `point`, `gram`, `mega` and others are ordinary English words that scripts often use as variables. `nc.exe` only treats them as constants when no variable of that name exists, so `year = 2026` keeps working. `ConstantWords` already handles this: an assigned name takes the variable colour for the whole file. An unassigned typo of a variable name will now be accepted silently if it matches one of these words.

## 4. Spec examples that do not run as written

The spec tables use helpers NC does not have. The back end accepts the corrected form, and the examples in section 6 are already corrected. Do not copy spec examples into the front end without checking this table.

| In the spec | Write this in NC | Why |
|---|---|---|
| `ones(5)` for a line of 5 | `ones(1, 5)` | `ones(5)` is a 5 x 5 matrix |
| `rand(3, 3)` | `nexus_uniform([3, 3])` | `rand` does not exist |
| `arange(0, 16, 1)` | `space(0, 15, 16)` | `arange` does not exist |
| `compare(img, ">", 0.5)` | `img > 0.5` | `compare` does not exist |
| `slice(sig, 0, 64)` | `sig[0:63]` | `slice` does not exist; NC ranges include the end |
| `col(Q, 0)` | `Q[:, 0]` | `col` does not exist |
| `reverse(sig)`, `astype(x, "int16")` | No direct form; NC numbers carry no integer type | `wav_write` takes a format name instead |
| `[S, 0; 0, S]` of sparse matrices | `sparse_block(2, 2, S, 0, 0, S)` | A matrix cannot hold objects |
| `[c1, c2]` of constraints | A Dict holding both | A matrix cannot hold Dicts |
| `dict(["v"], [1, 2, 3])` | `g = dict(["v"], [1]); g["v"] = [1, 2, 3];` | `dict` pairs keys with values one to one |
| `masked_equal(...)` | `graph_from_dense(M, 0)` | NC has no masked arrays |

## 5. Behaviour a user could trip over

- **Bool results are numbers.** `img_label`, the `binary_*` functions and similar return 1 and 0, not true and false.
- **Files come back as Dicts.** `wav_read` returns `{rate, data}`, and the data is raw, not scaled to -1..1 like the existing `load_wav`.
- **The three datasets need the network once.** `dataset_ascent`, `dataset_face` and `dataset_ecg` download on first use and keep the file in `NC_DATASET_DIR`, or in `.nc/datasets` under the home folder. Expect a pause on the first call.
- **NetCDF.** `netcdf_read` handles the classic format only. NetCDF-4 files are HDF5 and go through the existing HDF5 functions.

## 6. Text for every function

Names used in the examples: `sig` is a line of samples, `img` a Matrix, `x` and `y` lines, `A` a Matrix, `S` a Sparse, `P` a Matrix of points, `f` and similar an NC function defined by the script.

