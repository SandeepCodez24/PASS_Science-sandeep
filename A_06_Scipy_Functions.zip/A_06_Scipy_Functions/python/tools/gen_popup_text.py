"""Run from the repository root: python src/test/scipy/python/tools/gen_popup_text.py .
Builds src/main/resources/language/scipy_popup_text.tsv from section 6 of the
three SciPy front-end docs: one row per function, name TAB line TAB line ...

NC is its own language, so the editor never names the libraries it took the
functions from: the "SciPy: module.function()" line of each block is left out,
and the other mentions are reworded by clean() (also used by clean_tsv_descriptions
for the description column of builtin_signatures.tsv)."""
import re, sys, pathlib

# (pattern, replacement), applied in order; the words must be gone afterwards.
REWORD = [
    (r"^Removed quad_explain\(\); in NC use help\(\"integrate\"\)\.?$", "Shows how to call a function of this library."),
    (r"Prints the usage, summary and SciPy original of a SciPy function\.", "Prints the usage and a one-line summary."),
    (r" \((?:deprecated|deprecated name) in SciPy\)", ""),
    (r"^Removed from SciPy; (\w)", lambda m: m.group(1).upper()),
    (r"^Removed [^;]+; in NC use (.+?)(\.?)$", r"Same as \1\2"),
    (r"^Removed [^;]+; (\w)", lambda m: m.group(1).upper()),
    (r"^Legacy ([^;]+); NC uses the same (\S+) function\.", r"Same as \2: \1 (older name)."),
    (r" \(accepted for SciPy compatibility\)", " (accepted, does not change results)"),
    (r", as SciPy gives it", ""),
    (r", as in SciPy\.", "."),
    (r", as SciPy\.", "."),
    (r" \(as SciPy with scramble=False\)", ""),
    (r"a SciPy name such as", "a precision-prefixed name such as"),
    (r"the periodic fftpack one", "the periodic one"),
]
FORBIDDEN = re.compile(r"scipy|numpy|fftpack", re.I)

# A removed name whose NC replacement is the row itself ("Removed find_repeats(); in NC
# use unique_counts()" on unique_counts) gets a purpose line of its own.
SELF = {
    "unique_counts": "Distinct values and how often each occurs.",
    "tri": "Matrix with ones on and below a diagonal, zeros elsewhere.",
    "lapack_ggev": "Generalised eigenvalues and eigenvectors of a matrix pair (A, B).",
    "derivative": "Numerical derivative of a function at a point.",
}


# The distribution families, named as in prose. The docs' first lines of the
# name_pdf / _cdf / ... blocks cut some names short ("on [0", "(biased draws") and
# lower-cased proper names ("gauss", "johnson SB"), so family_line() writes them again.
FAMILY = {
    "alpha": "alpha", "anglit": "anglit", "arcsine": "arcsine", "argus": "ARGUS",
    "bernoulli": "Bernoulli", "beta": "beta", "betabinom": "beta-binomial",
    "betanbinom": "beta-negative-binomial", "betaprime": "beta prime", "binom": "binomial",
    "boltzmann": "Boltzmann (truncated discrete exponential)", "bradford": "Bradford",
    "burr": "Burr (type III)", "burr12": "Burr type XII", "cauchy": "Cauchy", "chi": "chi",
    "chi2": "chi-square", "cosine": "cosine", "crystalball": "Crystal Ball",
    "dgamma": "double gamma", "dlaplace": "discrete Laplacian",
    "dpareto_lognorm": "double Pareto log-normal", "dweibull": "double Weibull",
    "erlang": "Erlang", "expon": "exponential", "exponnorm": "exponentially modified normal",
    "exponpow": "exponential power", "exponweib": "exponentiated Weibull", "f": "F",
    "fatiguelife": "fatigue-life (Birnbaum-Saunders)", "fisk": "Fisk (log-logistic)",
    "foldcauchy": "folded Cauchy", "foldnorm": "folded normal", "gamma": "gamma",
    "gausshyper": "Gauss hypergeometric", "genexpon": "generalised exponential",
    "genextreme": "generalised extreme value", "gengamma": "generalised gamma",
    "genhalflogistic": "generalised half-logistic", "genhyperbolic": "generalised hyperbolic",
    "geninvgauss": "generalised inverse Gaussian", "genlogistic": "generalised logistic",
    "gennorm": "generalised normal", "genpareto": "generalised Pareto", "geom": "geometric",
    "gibrat": "Gibrat", "gompertz": "Gompertz", "gumbel_l": "left-skewed Gumbel",
    "gumbel_r": "right-skewed Gumbel", "halfcauchy": "half-Cauchy",
    "halfgennorm": "half generalised normal", "halflogistic": "half-logistic",
    "halfnorm": "half-normal", "hypergeom": "hypergeometric", "hypsecant": "hyperbolic secant",
    "invgamma": "inverse gamma", "invgauss": "inverse Gaussian", "invweibull": "inverted Weibull",
    "irwinhall": "Irwin-Hall", "jf_skew_t": "Jones-Faddy skew-t", "johnsonsb": "Johnson SB",
    "johnsonsu": "Johnson SU", "kappa3": "kappa 3", "kappa4": "kappa 4",
    "ksone": "one-sided Kolmogorov-Smirnov statistic",
    "kstwo": "two-sided Kolmogorov-Smirnov statistic",
    "kstwobign": "limiting (scaled) Kolmogorov-Smirnov statistic", "landau": "Landau",
    "laplace": "Laplace", "laplace_asymmetric": "asymmetric Laplace", "levy": "Lévy",
    "levy_l": "left-skewed Lévy", "levy_stable": "Lévy stable", "logistic": "logistic",
    "loggamma": "log-gamma", "loglaplace": "log-Laplace", "lognorm": "log-normal",
    "logser": "logarithmic (log-series)", "loguniform": "log-uniform", "lomax": "Lomax",
    "maxwell": "Maxwell-Boltzmann", "mielke": "Mielke Beta-Kappa", "moyal": "Moyal",
    "nakagami": "Nakagami", "nbinom": "negative binomial",
    "nchypergeom_fisher": "Fisher's non-central hypergeometric",
    "nchypergeom_wallenius": "Wallenius' non-central hypergeometric", "ncf": "non-central F",
    "nct": "non-central Student t", "ncx2": "non-central chi-square",
    "nhypergeom": "negative hypergeometric", "norm": "normal (Gaussian)",
    "norminvgauss": "normal-inverse Gaussian", "pareto": "Pareto", "pearson3": "Pearson type III",
    "planck": "Planck (discrete exponential)", "poisson": "Poisson",
    "poisson_binom": "Poisson binomial", "powerlaw": "power-function",
    "powerlognorm": "power log-normal", "powernorm": "power normal", "randint": "discrete uniform",
    "rayleigh": "Rayleigh", "rdist": "R", "recipinvgauss": "reciprocal inverse Gaussian",
    "reciprocal": "reciprocal", "rel_breitwigner": "relativistic Breit-Wigner", "rice": "Rice",
    "semicircular": "Wigner semicircle", "skellam": "Skellam", "skewcauchy": "skewed Cauchy",
    "skewnorm": "skew-normal", "studentized_range": "studentized range", "t": "Student t",
    "trapezoid": "trapezoidal", "triang": "triangular", "truncexpon": "truncated exponential",
    "truncnorm": "truncated normal", "truncpareto": "upper-truncated Pareto",
    "truncweibull_min": "truncated Weibull minimum", "tukeylambda": "Tukey lambda",
    "uniform": "continuous uniform", "vonmises": "von Mises", "vonmises_line": "von Mises (on a line)",
    "wald": "Wald", "weibull_max": "Weibull maximum", "weibull_min": "Weibull minimum",
    "wrapcauchy": "wrapped Cauchy", "yulesimon": "Yule-Simon", "zipf": "Zipf", "zipfian": "Zipfian",
}
FAMILY_TEMPLATE = {
    "pdf": "Probability density of the {} distribution at x.",
    "pmf": "Probability of the value k under the {} distribution.",
    "cdf": "Probability of a value at or below x under the {} distribution (cumulative distribution).",
    "sf": "Probability of a value above x under the {} distribution (1 - CDF, accurate in the far tail).",
    "ppf": "The value below which a fraction q of the {} distribution lies (inverse CDF).",
    "rvs": "Draws n random values from the {} distribution.",
}


def family_line(name):
    """The purpose line of a distribution-family function, or None for any other name."""
    m = re.match(r"^(.+)_(pdf|pmf|cdf|sf|ppf|rvs)$", name or "")
    if not m or m.group(1) not in FAMILY:
        return None
    line = FAMILY_TEMPLATE[m.group(2)].format(FAMILY[m.group(1)])
    # "Fisher's ..." takes no article: "under Fisher's non-central ..."
    return re.sub(r"\bthe (\w+'s? )", r"\1", line)


def clean(text, name=None):
    for pattern, repl in REWORD:
        text = re.sub(pattern, repl, text)
    if name in SELF and text.startswith("Same as " + name + "()"):
        text = SELF[name] if text.endswith(".") else SELF[name].rstrip(".")
    return text


def main(root):
    docs = ["SciPy_Phase1_2_Frontend_Changes.md", "SciPy_Phase3_4_Frontend_Changes.md",
            "SciPy_Phase5_Frontend_Changes.md"]
    head = re.compile(r"^#### `([A-Za-z_][A-Za-z0-9_]*)\(.*`\s*$")
    rows, order = {}, []
    for d in docs:
        text = (root / "docs" / d).read_text(encoding="utf-8").splitlines()
        start = next(i for i, l in enumerate(text) if l.startswith("## 6."))
        name, lines = None, []

        def flush():
            if name and lines:
                if name not in rows:
                    rows[name] = lines[:]
                    order.append(name)
                elif lines != rows[name] and not lines[0].startswith("Same as " + name + "()"):
                    # a second section (hilbert, fft_convolve ...): both blocks; an
                    # older-name block that only points back to the function is left out
                    rows[name] += [""] + lines

        for l in text[start + 1:]:
            m = head.match(l)
            if m or l.startswith("#") or l.startswith("|") or l.startswith("**"):
                flush()
                name, lines = (m.group(1) if m else None), []
                continue
            s = l.strip()
            if name and s and not s.startswith("SciPy:"):
                s = clean(s.replace("`", ""), name)
                if not lines and family_line(name):
                    s = family_line(name)
                assert "\t" not in s, s
                assert not FORBIDDEN.search(s), s
                lines.append(s)
        flush()
    out = root / "src/main/resources/language/scipy_popup_text.tsv"
    with out.open("w", encoding="utf-8", newline="\n") as f:
        f.write("# Pop-up text of the library functions: section 6 of docs/SciPy_Phase1_2_Frontend_Changes.md,\n"
                "# SciPy_Phase3_4_Frontend_Changes.md and SciPy_Phase5_Frontend_Changes.md, one row per function,\n"
                "# made by src/test/scipy/python/tools/gen_popup_text.py (library names left out).\n"
                "# Columns, separated by one TAB: name, then its lines in pop-up order (what it is for, inputs,\n"
                "# returns, example, a note where there is a trap). A name listed in two sections\n"
                "# (hilbert, fft_convolve, fft ...) has both blocks, split by one empty cell.\n")
        for n in order:
            f.write(n + "\t" + "\t".join(rows[n]) + "\n")
    print(len(order), "functions;", "lines per block:", sorted({len(v) for v in rows.values()}),
          "merged:", sum("" in v for v in rows.values()))


def clean_tsv_descriptions(root):
    """Drops the 'SciPy: ' prefix and rewords the description column of the scipy_* rows."""
    path = root / "src/main/resources/language/builtin_signatures.tsv"
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        cells = line.split("\t")
        if len(cells) >= 7 and cells[0].startswith("scipy_"):
            d = clean(re.sub(r"^SciPy: ", "", cells[3]), cells[1])
            if cells[0] == "scipy_probability_distributions" and family_line(cells[1]):
                d = family_line(cells[1]).rstrip(".")
            assert not FORBIDDEN.search(d), d
            cells[3] = d
            line = "\t".join(cells)
        out.append(line)
    path.write_text("\n".join(out) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    root = pathlib.Path(sys.argv[1])
    main(root)
    if "--tsv" in sys.argv:
        clean_tsv_descriptions(root)
