# ------------------------------------------------------------------------------------------
# Error test 1: SciPy functions take their inputs in order only (named = no).
# Open this file in the editor: each call below is marked as a Function Call Error.
# nc.exe stops at the first one with the same words:
#   Error: butter: its values cannot be named yet - give them in order
# Each line shows the working form in the comment after it.
# ------------------------------------------------------------------------------------------
A = [4, 1; 2, 3];
P = [1, 2; 3, 4; 5, 6; 7, 8];

# Signal processing: write butter(4, 0.2, "low")
b = butter(4, 0.2, btype="low");

# Clustering: write kmeans(P, 2)
r = kmeans(data=P, k=2);

# LAPACK: write lapack_gesv(A, [1, 2])
x = lapack_gesv(A, [1, 2], lwork=10);

# Special functions: write comb(10, 3, 1)
c = comb(10, 3, exact=1);
