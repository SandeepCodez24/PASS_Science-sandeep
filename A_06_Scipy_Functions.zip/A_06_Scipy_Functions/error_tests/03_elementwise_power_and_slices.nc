# ------------------------------------------------------------------------------------------
# Error test 3: the element-wise power ^. and slices, as the SciPy examples use them.
# x ^. 2 squares each element (the spec's x ^ 2 is the matrix power). In NC a range
# includes its end, so A[0:0, 0:1] is row 0 - not empty.
# The editor marks the two faulty lines below; the rest is clean.
# ------------------------------------------------------------------------------------------
x = [1, 2, 3];
A = [1, 2; 3, 4];

# Fine: element-wise powers and one-element slices
y = x ^. 2;
z = x^.-1;
w = 4^.5;
r = A[0:0, 0:1];
v = A[1:1, 1];

# Syntax Error: Exponent '^' has no power after it
# nc.exe: expression ended unexpectedly - a value is required here
p = x ^. ;

# Syntax Error: Slice '2:0' is empty: its start must not be larger than its end
# (nc.exe returns an empty matrix here, which is rarely what was meant)
s = x[2:0];
