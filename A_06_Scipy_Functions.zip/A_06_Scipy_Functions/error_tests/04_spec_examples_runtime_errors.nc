# ------------------------------------------------------------------------------------------
# Error test 4: spec examples that do not run as written (section 4 of the SciPy
# front-end docs). The editor does not mark these lines: it does not check
# unknown function names, the number of inputs, or what a matrix holds. nc.exe
# stops at the first one. Run each line on its own to see every message:
#   rand(3, 3)          Error: Unknown function 'rand'
#   arange(0, 16, 1)    Error: Unknown function 'arange'
#   cholesky(A, 1)      Error: cholesky: it takes 1 input, but 2 values were given (usage: cholesky(A))
#   mixture_dist([...]) Error: a matrix cannot hold a dict - its elements are numbers, true/false or text
# The working form is in the comment above each line.
# ------------------------------------------------------------------------------------------
A = [4, 1; 2, 3];

# Write nexus_uniform([3, 3])
r1 = rand(3, 3);

# Write space(0, 15, 16)
r2 = arange(0, 16, 1);

# The existing cholesky takes one input: write cholesky(A)
r3 = cholesky(A, 1);

# A matrix cannot hold Dicts: write mixture_dist(normal_dist(0, 1), normal_dist(1, 1), [0.5, 0.5])
r4 = mixture_dist([normal_dist(0, 1), normal_dist(1, 1)], [0.5, 0.5]);
