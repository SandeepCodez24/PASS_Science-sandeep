# ------------------------------------------------------------------------------------------
# Error test 2: the SciPy constants (speed_of_light, boltzmann, day, ...).
# Constant names are case-sensitive and must be spelled exactly. The editor marks each
# wrong name below as an Undefined Variable Error; nc.exe stops at the first one:
#   Error: Undefined variable 'speed_of_lite'
# The last lines are fine: an everyday word (year, day, point) is an ordinary variable
# once the script assigns it, and arcsec is the arc second bare, the arc secant called.
# ------------------------------------------------------------------------------------------

# A typo: write speed_of_light
c = speed_of_lite;

# Wrong case (SciPy's constants.Boltzmann): write boltzmann
k = Boltzmann;

# Not an NC name (SciPy's constants.zero_Celsius): write zero_celsius
t0 = zero_Celsius;

# Fine: no error on these lines
year = 2026;
next_year = year + 1;
seconds_per_week = 7 * day;
a = arcsec;
b = arcsec(2);
