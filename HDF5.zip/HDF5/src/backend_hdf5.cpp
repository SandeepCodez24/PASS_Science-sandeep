// ============================================================================
//  N-Data - HDF5 canonical backend
//
//  Build with -DNDAT_WITH_HDF5 and link hdf5. Without that flag this file
//  compiles to nothing and make_backend("hdf5") falls back to portable.
//
//  File layout:
//    /                      attrs: ndat_magic, major, minor, min_reader_major
//    /vars/<name>           dense: the dataset itself
//    /vars/<name>/          variant: group with type_codes, child_offsets,
//                                    child_0 .. child_N
//    /__index__/<name>      zero-length dataset carrying explorer attrs only
//
//  The explorer reads /__index__ attributes and never opens /vars.
// ============================================================================
#include "ndat/backend.hpp"

#ifdef NDAT_WITH_HDF5

#include <hdf5.h>
#include <mutex>
#include <shared_mutex>
#include <map>
#include <stdexcept>

namespace ndat {
namespace {

struct Hid {
    hid_t id = H5I_INVALID_HID;
    using Closer = herr_t(*)(hid_t);
    Closer closer = nullptr;
    Hid() = default;
    Hid(hid_t i, Closer c) : id(i), closer(c) {}
    ~Hid() { if (id >= 0 && closer) closer(id); }
    Hid(const Hid&) = delete;
    Hid& operator=(const Hid&) = delete;
    Hid(Hid&& o) noexcept : id(o.id), closer(o.closer) { o.id = H5I_INVALID_HID; }
    operator hid_t() const { return id; }
    bool ok() const { return id >= 0; }
};

void check(herr_t e, const char* what) {
    if (e < 0) throw std::runtime_error(std::string("ndat/hdf5: ") + what);
}

// Map an N-Data TypeId to an HDF5 native type. Emulated/unimplemented types
// are stored as opaque byte blobs with the TypeId recorded in an attribute,
// so an older reader can skip them instead of misreading them.
hid_t h5_type(const DType& d) {
    switch (d.id) {
        case TypeId::Bool:    return H5Tcopy(H5T_NATIVE_UINT8);
        case TypeId::Int8:    return H5Tcopy(H5T_NATIVE_INT8);
        case TypeId::Int16:   return H5Tcopy(H5T_NATIVE_INT16);
        case TypeId::Int32:   return H5Tcopy(H5T_NATIVE_INT32);
        case TypeId::Int64:   return H5Tcopy(H5T_NATIVE_INT64);
        case TypeId::UInt8:   return H5Tcopy(H5T_NATIVE_UINT8);
        case TypeId::UInt16:  return H5Tcopy(H5T_NATIVE_UINT16);
        case TypeId::UInt32:  return H5Tcopy(H5T_NATIVE_UINT32);
        case TypeId::UInt64:  return H5Tcopy(H5T_NATIVE_UINT64);
        case TypeId::Float32: return H5Tcopy(H5T_NATIVE_FLOAT);
        case TypeId::Float64: return H5Tcopy(H5T_NATIVE_DOUBLE);
        case TypeId::Complex128: {
            hid_t t = H5Tcreate(H5T_COMPOUND, 2 * sizeof(double));
            H5Tinsert(t, "r", 0, H5T_NATIVE_DOUBLE);
            H5Tinsert(t, "i", sizeof(double), H5T_NATIVE_DOUBLE);
            return t;
        }
        case TypeId::Complex64: {
            hid_t t = H5Tcreate(H5T_COMPOUND, 2 * sizeof(float));
            H5Tinsert(t, "r", 0, H5T_NATIVE_FLOAT);
            H5Tinsert(t, "i", sizeof(float), H5T_NATIVE_FLOAT);
            return t;
        }
        case TypeId::Utf8: {
            hid_t t = H5Tcopy(H5T_C_S1);
            H5Tset_size(t, H5T_VARIABLE);
            H5Tset_cset(t, H5T_CSET_UTF8);
            return t;
        }
        default: {
            std::size_t w = type_width(d.id);
            if (!w) throw std::runtime_error(
                std::string("ndat/hdf5: type not storable: ") + type_name(d.id));
            return H5Tcreate(H5T_OPAQUE, w);   // int128/float128/reserved
        }
    }
}

void write_attr_u64(hid_t obj, const char* name, std::uint64_t v) {
    Hid sp(H5Screate(H5S_SCALAR), H5Sclose);
    Hid a(H5Acreate2(obj, name, H5T_NATIVE_UINT64, sp, H5P_DEFAULT, H5P_DEFAULT), H5Aclose);
    if (a.ok()) check(H5Awrite(a, H5T_NATIVE_UINT64, &v), "attr write");
}

void write_attr_str(hid_t obj, const char* name, const std::string& v) {
    Hid t(H5Tcopy(H5T_C_S1), H5Tclose);
    H5Tset_size(t, v.size() + 1);
    H5Tset_cset(t, H5T_CSET_UTF8);
    Hid sp(H5Screate(H5S_SCALAR), H5Sclose);
    Hid a(H5Acreate2(obj, name, t, sp, H5P_DEFAULT, H5P_DEFAULT), H5Aclose);
    if (a.ok()) check(H5Awrite(a, t, v.c_str()), "attr write");
}

std::string read_attr_str(hid_t obj, const char* name) {
    if (H5Aexists(obj, name) <= 0) return {};
    Hid a(H5Aopen(obj, name, H5P_DEFAULT), H5Aclose);
    Hid t(H5Aget_type(a), H5Tclose);
    std::size_t n = H5Tget_size(t);
    std::string s(n, '\0');
    H5Aread(a, t, s.data());
    if (!s.empty() && s.back() == '\0') s.pop_back();
    return s;
}

std::uint64_t read_attr_u64(hid_t obj, const char* name) {
    if (H5Aexists(obj, name) <= 0) return 0;
    Hid a(H5Aopen(obj, name, H5P_DEFAULT), H5Aclose);
    std::uint64_t v = 0;
    H5Aread(a, H5T_NATIVE_UINT64, &v);
    return v;
}

// Chunk shape targeting opt.chunk_bytes, clamped to the dataset extents.
std::vector<hsize_t> pick_chunks(const std::vector<hsize_t>& dims,
                                 std::size_t elem_bytes,
                                 std::uint64_t target_bytes) {
    std::vector<hsize_t> ch = dims;
    if (ch.empty()) return ch;
    std::uint64_t target_elems = std::max<std::uint64_t>(1, target_bytes / std::max<std::size_t>(1, elem_bytes));
    // Shrink the slowest-varying dimension first; keep rows contiguous.
    std::uint64_t acc = 1;
    for (std::size_t i = ch.size(); i-- > 0;) {
        if (acc >= target_elems) { ch[i] = 1; continue; }
        std::uint64_t room = target_elems / acc;
        ch[i] = hsize_t(std::max<std::uint64_t>(1, std::min<std::uint64_t>(ch[i], room)));
        acc *= ch[i];
    }
    for (auto& c : ch) if (c == 0) c = 1;
    return ch;
}

// ---------------------------------------------------------------------------
class Hdf5Backend final : public Backend {
public:
    ~Hdf5Backend() override { try { close(); } catch (...) {} }

    void create(const std::string& path, const WriteOptions& opt) override {
        std::unique_lock lk(mu_);
        opt_ = opt;

        Hid fapl(H5Pcreate(H5P_FILE_ACCESS), H5Pclose);
        // Latest format is required for SWMR and for extendible chunked layouts.
        check(H5Pset_libver_bounds(fapl, H5F_LIBVER_LATEST, H5F_LIBVER_LATEST), "libver");

        file_ = H5Fcreate(path.c_str(), H5F_ACC_TRUNC, H5P_DEFAULT, fapl);
        if (file_ < 0) throw std::runtime_error("ndat/hdf5: cannot create " + path);

        write_attr_str(file_, "ndat_magic", "NDAT");
        write_attr_u64(file_, "format_major", kFormatMajor);
        write_attr_u64(file_, "format_minor", kFormatMinor);
        write_attr_u64(file_, "min_reader_major", kMinReaderMajor);
        write_attr_str(file_, "writer_id", hdr_.writer_id);
        write_attr_str(file_, "byte_order", "little");

        Hid g1(H5Gcreate2(file_, "/vars", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT), H5Gclose);
        Hid g2(H5Gcreate2(file_, "/__index__", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT), H5Gclose);

        if (opt.swmr) check(H5Fstart_swmr_write(file_), "start swmr");
        path_ = path;
    }

    void open(const std::string& path, bool read_only) override {
        std::unique_lock lk(mu_);
        Hid fapl(H5Pcreate(H5P_FILE_ACCESS), H5Pclose);
        check(H5Pset_libver_bounds(fapl, H5F_LIBVER_LATEST, H5F_LIBVER_LATEST), "libver");

        unsigned flags = read_only ? (H5F_ACC_RDONLY | H5F_ACC_SWMR_READ) : H5F_ACC_RDWR;
        file_ = H5Fopen(path.c_str(), flags, fapl);
        if (file_ < 0) throw std::runtime_error("ndat/hdf5: cannot open " + path);

        if (read_attr_str(file_, "ndat_magic") != "NDAT")
            throw std::runtime_error("ndat/hdf5: not an .ndat file");

        hdr_.major = std::uint16_t(read_attr_u64(file_, "format_major"));
        hdr_.minor = std::uint16_t(read_attr_u64(file_, "format_minor"));
        hdr_.min_reader_major = std::uint16_t(read_attr_u64(file_, "min_reader_major"));
        hdr_.writer_id = read_attr_str(file_, "writer_id");

        if (hdr_.min_reader_major > kFormatMajor)
            throw std::runtime_error("ndat/hdf5: file requires a newer reader (major " +
                                     std::to_string(hdr_.min_reader_major) + ")");

        path_ = path;
        read_only_ = read_only;
    }

    void close() override {
        std::unique_lock lk(mu_);
        if (file_ >= 0) { H5Fclose(file_); file_ = H5I_INVALID_HID; }
    }

    FileHeader header() const override { std::shared_lock lk(mu_); return hdr_; }

    std::string put(const Variable& v, const WriteOptions& opt) override {
        std::unique_lock lk(mu_);
        if (read_only_) throw std::runtime_error("ndat/hdf5: read-only");
        const std::string dpath = "/vars/" + v.name;

        if (H5Lexists(file_, dpath.c_str(), H5P_DEFAULT) > 0)
            H5Ldelete(file_, dpath.c_str(), H5P_DEFAULT);

        if (v.is_variant()) write_variant(dpath, std::get<VariantArray>(v.payload), opt);
        else                write_dense  (dpath, std::get<Array>(v.payload), opt);

        std::uint64_t rev = ++rev_[v.name];
        write_index(make_index_record(v, dpath, rev));
        return dpath;
    }

    void erase(const std::string& name) override {
        std::unique_lock lk(mu_);
        std::string dp = "/vars/" + name, ip = "/__index__/" + name;
        if (H5Lexists(file_, dp.c_str(), H5P_DEFAULT) > 0) H5Ldelete(file_, dp.c_str(), H5P_DEFAULT);
        if (H5Lexists(file_, ip.c_str(), H5P_DEFAULT) > 0) H5Ldelete(file_, ip.c_str(), H5P_DEFAULT);
        rev_.erase(name);
    }

    std::vector<IndexRecord> index() const override {
        std::shared_lock lk(mu_);
        std::vector<IndexRecord> out;
        Hid g(H5Gopen2(file_, "/__index__", H5P_DEFAULT), H5Gclose);
        if (!g.ok()) return out;
        H5G_info_t info{};
        H5Gget_info(g, &info);
        for (hsize_t i = 0; i < info.nlinks; ++i) {
            char nm[512];
            H5Lget_name_by_idx(g, ".", H5_INDEX_NAME, H5_ITER_INC, i, nm, sizeof(nm), H5P_DEFAULT);
            Hid d(H5Dopen2(g, nm, H5P_DEFAULT), H5Dclose);
            IndexRecord r;
            r.name          = nm;
            r.type_label    = read_attr_str(d, "type");
            r.size_label    = read_attr_str(d, "size");
            r.preview       = read_attr_str(d, "preview");
            r.dataset_path  = read_attr_str(d, "path");
            r.element_count = read_attr_u64(d, "count");
            r.nbytes        = read_attr_u64(d, "nbytes");
            r.revision      = read_attr_u64(d, "revision");
            r.plottable     = read_attr_u64(d, "plottable") != 0;
            out.push_back(std::move(r));
        }
        return out;
    }

    Variable get(const std::string& name) const override {
        std::shared_lock lk(mu_);
        const std::string dp = "/vars/" + name;
        if (H5Lexists(file_, dp.c_str(), H5P_DEFAULT) <= 0)
            throw std::runtime_error("ndat/hdf5: no variable '" + name + "'");
        H5O_info2_t oi{};
        H5Oget_info_by_name3(file_, dp.c_str(), &oi, H5O_INFO_BASIC, H5P_DEFAULT);
        if (oi.type == H5O_TYPE_GROUP)
            throw std::runtime_error("ndat/hdf5: variant read not implemented in v1 skeleton");
        return Variable(name, read_dense(dp));
    }

    Array get_slab(const std::string& name, const Slab& s) const override {
        std::shared_lock lk(mu_);
        const std::string dp = "/vars/" + name;
        Hid d(H5Dopen2(file_, dp.c_str(), H5P_DEFAULT), H5Dclose);
        if (!d.ok()) throw std::runtime_error("ndat/hdf5: no dataset " + dp);

        DType dt(TypeId(read_attr_u64(d, "ndat_type")),
                 std::uint32_t(read_attr_u64(d, "ndat_param")),
                 read_attr_u64(d, "ndat_nullable") != 0);

        Hid fsp(H5Dget_space(d), H5Sclose);
        const int rank = H5Sget_simple_extent_ndims(fsp);
        std::vector<hsize_t> start(s.start.begin(), s.start.end());
        std::vector<hsize_t> count(s.count.begin(), s.count.end());
        if (int(start.size()) != rank) throw std::runtime_error("ndat/hdf5: slab rank mismatch");

        check(H5Sselect_hyperslab(fsp, H5S_SELECT_SET, start.data(), nullptr, count.data(), nullptr),
              "hyperslab");
        Hid msp(H5Screate_simple(rank, count.data(), nullptr), H5Sclose);

        Shape out_shape(std::vector<std::uint64_t>(count.begin(), count.end()));
        Array out(dt, out_shape);
        Hid mt(h5_type(dt), H5Tclose);
        out.values().resize(std::size_t(out_shape.count() * H5Tget_size(mt)));
        check(H5Dread(d, mt, msp, fsp, H5P_DEFAULT, out.values().data()), "slab read");
        return out;
    }

    void flush() override {
        std::unique_lock lk(mu_);
        if (file_ >= 0) H5Fflush(file_, H5F_SCOPE_GLOBAL);
    }

    const char* backend_name() const noexcept override { return "hdf5"; }

private:
    Hid make_dcpl(const std::vector<hsize_t>& dims, std::size_t elem_bytes,
                  const WriteOptions& opt) {
        Hid dcpl(H5Pcreate(H5P_DATASET_CREATE), H5Pclose);
        if (!dims.empty()) {
            auto ch = pick_chunks(dims, elem_bytes, opt.chunk_bytes);
            check(H5Pset_chunk(dcpl, int(ch.size()), ch.data()), "set chunk");
            if (opt.shuffle)  H5Pset_shuffle(dcpl);
            if (opt.zstd_level > 0) H5Pset_deflate(dcpl, unsigned(std::min(opt.zstd_level, 9)));
            if (opt.checksum) H5Pset_fletcher32(dcpl);
        }
        return dcpl;
    }

    void tag_dataset(hid_t d, const DType& dt) {
        write_attr_u64(d, "ndat_type",     std::uint64_t(dt.id));
        write_attr_u64(d, "ndat_param",    dt.param);
        write_attr_u64(d, "ndat_nullable", dt.nullable ? 1 : 0);
        write_attr_str(d, "ndat_type_name", type_name(dt.id));
    }

    void write_dense(const std::string& dpath, const Array& a, const WriteOptions& opt) {
        std::vector<hsize_t> dims(a.shape().dims.begin(), a.shape().dims.end());
        std::vector<hsize_t> maxd(dims.size(), H5S_UNLIMITED);   // extendible

        Hid t(h5_type(a.dtype()), H5Tclose);
        Hid sp = dims.empty() ? Hid(H5Screate(H5S_SCALAR), H5Sclose)
                              : Hid(H5Screate_simple(int(dims.size()), dims.data(), maxd.data()), H5Sclose);
        Hid dcpl = make_dcpl(dims, H5Tget_size(t), opt);

        Hid d(H5Dcreate2(file_, dpath.c_str(), t, sp, H5P_DEFAULT, dcpl, H5P_DEFAULT), H5Dclose);
        if (!d.ok()) throw std::runtime_error("ndat/hdf5: create " + dpath);

        if (a.dtype().id == TypeId::Utf8) {
            std::vector<std::string> tmp;
            std::vector<const char*> ptrs;
            tmp.reserve(a.count()); ptrs.reserve(a.count());
            for (std::uint64_t i = 0; i < a.count(); ++i) tmp.push_back(a.string_at(i));
            for (auto& s : tmp) ptrs.push_back(s.c_str());
            if (!ptrs.empty())
                check(H5Dwrite(d, t, H5S_ALL, H5S_ALL, H5P_DEFAULT, ptrs.data()), "write utf8");
        } else if (!a.values().empty()) {
            check(H5Dwrite(d, t, H5S_ALL, H5S_ALL, H5P_DEFAULT, a.values().data()), "write");
        }

        tag_dataset(d, a.dtype());

        if (a.dtype().nullable && a.validity().size()) {
            hsize_t n = a.validity().bytes().size();
            Hid vsp(H5Screate_simple(1, &n, nullptr), H5Sclose);
            Hid vd(H5Dcreate2(file_, (dpath + "__validity").c_str(), H5T_NATIVE_UINT8,
                              vsp, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT), H5Dclose);
            H5Dwrite(vd, H5T_NATIVE_UINT8, H5S_ALL, H5S_ALL, H5P_DEFAULT,
                     a.validity().bytes().data());
        }
    }

    Array read_dense(const std::string& dpath) const {
        Hid d(H5Dopen2(file_, dpath.c_str(), H5P_DEFAULT), H5Dclose);
        if (!d.ok()) throw std::runtime_error("ndat/hdf5: open " + dpath);

        DType dt(TypeId(read_attr_u64(d, "ndat_type")),
                 std::uint32_t(read_attr_u64(d, "ndat_param")),
                 read_attr_u64(d, "ndat_nullable") != 0);

        Hid sp(H5Dget_space(d), H5Sclose);
        int rank = H5Sget_simple_extent_ndims(sp);
        std::vector<hsize_t> dims(std::max(rank, 0));
        if (rank > 0) H5Sget_simple_extent_dims(sp, dims.data(), nullptr);

        Shape shape(std::vector<std::uint64_t>(dims.begin(), dims.end()));
        Array a(dt, shape);
        Hid t(h5_type(dt), H5Tclose);

        if (dt.id == TypeId::Utf8) {
            std::vector<char*> ptrs(std::size_t(shape.count()), nullptr);
            if (!ptrs.empty())
                check(H5Dread(d, t, H5S_ALL, H5S_ALL, H5P_DEFAULT, ptrs.data()), "read utf8");
            std::vector<std::string> ss;
            ss.reserve(ptrs.size());
            for (auto* p : ptrs) ss.emplace_back(p ? p : "");
            if (!ptrs.empty()) H5Dvlen_reclaim(t, sp, H5P_DEFAULT, ptrs.data());
            return Array::from_strings(ss, shape);
        }

        a.values().resize(std::size_t(shape.count() * H5Tget_size(t)));
        if (!a.values().empty())
            check(H5Dread(d, t, H5S_ALL, H5S_ALL, H5P_DEFAULT, a.values().data()), "read");
        return a;
    }

    void write_variant(const std::string& gpath, const VariantArray& v,
                       const WriteOptions& opt) {
        Hid g(H5Gcreate2(file_, gpath.c_str(), H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT), H5Gclose);
        write_attr_u64(g, "ndat_type",  std::uint64_t(TypeId::Variant));
        write_attr_u64(g, "length",     v.size());
        write_attr_str(g, "layout",     "dense_union");
        write_attr_str(g, "type_label", v.type_label());

        auto write_raw = [&](const char* nm, const void* p, hsize_t n, hid_t ty) {
            if (!n) return;
            Hid sp(H5Screate_simple(1, &n, nullptr), H5Sclose);
            Hid dcpl = make_dcpl({n}, H5Tget_size(ty), opt);
            Hid d(H5Dcreate2(g, nm, ty, sp, H5P_DEFAULT, dcpl, H5P_DEFAULT), H5Dclose);
            H5Dwrite(d, ty, H5S_ALL, H5S_ALL, H5P_DEFAULT, p);
        };
        write_raw("type_codes", v.type_codes().data(),
                  hsize_t(v.type_codes().size()), H5T_NATIVE_UINT8);
        write_raw("child_offsets", v.child_offsets().data(),
                  hsize_t(v.child_offsets().size() / sizeof(std::int64_t)), H5T_NATIVE_INT64);

        for (std::size_t k = 0; k < v.children().size(); ++k)
            write_dense(gpath + "/child_" + std::to_string(k), v.children()[k], opt);
    }

    void write_index(const IndexRecord& r) {
        const std::string ip = "/__index__/" + r.name;
        if (H5Lexists(file_, ip.c_str(), H5P_DEFAULT) > 0)
            H5Ldelete(file_, ip.c_str(), H5P_DEFAULT);

        hsize_t zero = 0;
        Hid sp(H5Screate_simple(1, &zero, nullptr), H5Sclose);
        Hid d(H5Dcreate2(file_, ip.c_str(), H5T_NATIVE_UINT8, sp,
                         H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT), H5Dclose);
        write_attr_str(d, "type",    r.type_label);
        write_attr_str(d, "size",    r.size_label);
        write_attr_str(d, "preview", r.preview);
        write_attr_str(d, "path",    r.dataset_path);
        write_attr_str(d, "container", container_name(r.container));
        write_attr_u64(d, "count",     r.element_count);
        write_attr_u64(d, "nbytes",    r.nbytes);
        write_attr_u64(d, "revision",  r.revision);
        write_attr_u64(d, "plottable", r.plottable ? 1 : 0);
        if (r.stats.valid) {
            write_attr_str(d, "stat_min",  std::to_string(r.stats.min));
            write_attr_str(d, "stat_max",  std::to_string(r.stats.max));
            write_attr_str(d, "stat_mean", std::to_string(r.stats.mean));
        }
    }

    mutable std::shared_mutex            mu_;   // HDF5 C API is not thread-safe
    hid_t                                file_ = H5I_INVALID_HID;
    std::string                          path_;
    bool                                 read_only_ = false;
    FileHeader                           hdr_;
    WriteOptions                         opt_;
    std::map<std::string, std::uint64_t> rev_;
};

} // namespace

std::unique_ptr<Backend> make_hdf5_backend() {
    return std::make_unique<Hdf5Backend>();
}

} // namespace ndat

#else  // !NDAT_WITH_HDF5

#include <memory>
namespace ndat {
std::unique_ptr<Backend> make_hdf5_backend() { return nullptr; }
} // namespace ndat

#endif
