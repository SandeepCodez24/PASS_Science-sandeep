#include "ndat/workspace.hpp"
#include <stdexcept>
#include <cmath>
#include <mutex>
#include <algorithm>

namespace ndat {

std::unique_ptr<Backend> make_portable_backend();
std::unique_ptr<Backend> make_hdf5_backend();

std::unique_ptr<Backend> make_backend(const std::string& kind) {
    if (kind == "hdf5") {
        if (auto b = make_hdf5_backend()) return b;
        return make_portable_backend();   // built without HDF5
    }
    return make_portable_backend();
}

Workspace::Workspace(SessionOptions o) : opt_(std::move(o)) {
    be_ = make_backend(opt_.backend);
    last_flush_ = std::chrono::steady_clock::now();
}

Workspace::~Workspace() { try { close(); } catch (...) {} }

void Workspace::create(const std::string& path) {
    std::unique_lock lk(mu_);
    be_->create(path, opt_.write);
    index_.clear();
    open_ = true;
    last_flush_ = std::chrono::steady_clock::now();
}

void Workspace::open(const std::string& path, bool read_only) {
    std::unique_lock lk(mu_);
    be_->open(path, read_only);
    index_.clear();
    for (auto& r : be_->index()) index_[r.name] = r;
    open_ = true;
}

void Workspace::close() {
    std::unique_lock lk(mu_);
    if (!open_) return;
    be_->flush();
    be_->close();
    index_.clear();
    open_ = false;
}

void Workspace::assign(const std::string& name, Array a) {
    std::unique_lock lk(mu_);
    Variable v(name, std::move(a));
    std::string dp = be_->put(v, opt_.write);
    std::uint64_t rev = index_.count(name) ? index_[name].revision + 1 : 1;
    index_[name] = make_index_record(v, dp, rev);
    ++pending_;
    maybe_flush();
}

void Workspace::assign(const std::string& name, VariantArray va) {
    std::unique_lock lk(mu_);
    Variable v(name, std::move(va));
    std::string dp = be_->put(v, opt_.write);
    std::uint64_t rev = index_.count(name) ? index_[name].revision + 1 : 1;
    index_[name] = make_index_record(v, dp, rev);
    ++pending_;
    maybe_flush();
}

void Workspace::remove(const std::string& name) {
    std::unique_lock lk(mu_);
    be_->erase(name);
    index_.erase(name);
    ++pending_;
    maybe_flush();
}

void Workspace::assign_mixed(const std::string& name,
                             const std::vector<Element>& elems,
                             const Shape& shape) {
    if (shape.count() != elems.size())
        throw std::runtime_error("ndat: element count does not match shape");

    // Step 1: compute the promotion join over all element types.
    std::vector<TypeId> ts;
    ts.reserve(elems.size());
    for (auto& e : elems) ts.push_back(e.is_null ? TypeId::Null : e.type);
    auto joined = promote_all(ts);

    // Step 2a: reconcilable -> one dense homogeneous array at the joined type.
    //          (bool 0 inside a float matrix lands here and becomes float64)
    if (joined && is_numeric(*joined)) {
        TypeId target = *joined;
        // Materialize as the default real unless the join is integral/bool.
        if (is_float(target))   target = TypeId::Float64;
        if (is_complex(target)) target = TypeId::Complex128;

        bool any_null = false;
        for (auto& e : elems) if (e.is_null) { any_null = true; break; }

        Array a(DType(target, 0, any_null), shape);
        if (any_null) a.validity().resize(elems.size(), true);

        for (std::size_t i = 0; i < elems.size(); ++i) {
            const auto& e = elems[i];
            if (e.is_null) a.validity().set(i, false);
            double d = e.is_null ? 0.0 : e.num;
            switch (target) {
                case TypeId::Bool:    { auto b = std::uint8_t(d != 0.0); a.values().append(&b, 1); break; }
                case TypeId::Int64:   { auto x = std::int64_t(d); a.values().append(&x, 8); break; }
                case TypeId::Int32:   { auto x = std::int32_t(d); a.values().append(&x, 4); break; }
                case TypeId::UInt64:  { auto x = std::uint64_t(d); a.values().append(&x, 8); break; }
                case TypeId::Complex128: { double c[2] = {d, 0.0}; a.values().append(c, 16); break; }
                default:              { a.values().append(&d, 8); break; }
            }
        }
        assign(name, std::move(a));
        return;
    }

    // Step 2b: irreconcilable (a string among numbers).
    // Optional guard: above the limit, refuse rather than silently reshape.
    if (opt_.auto_variant_limit && shape.count() > opt_.auto_variant_limit)
        throw std::runtime_error(
            "ndat: mixed assignment to '" + name + "' exceeds auto_variant_limit (" +
            std::to_string(shape.count()) + " elements); cast explicitly");

    // Dense union: only the one odd element costs anything. The numeric
    // payload stays type-pure and GPU-consumable.
    VariantArray va(shape);
    for (auto& e : elems) {
        if (e.is_null)                    { va.push_null(); continue; }
        if (is_text(e.type))              { va.push_string(e.text); continue; }
        switch (e.type) {
            case TypeId::Bool:  va.push(std::uint8_t(e.num != 0.0), TypeId::Bool); break;
            case TypeId::Int64: va.push(std::int64_t(e.num), TypeId::Int64);       break;
            default:            va.push(double(e.num), TypeId::Float64);           break;
        }
    }
    assign(name, std::move(va));
}

void Workspace::checkpoint() {
    std::unique_lock lk(mu_);
    be_->flush();
    pending_ = 0;
    last_flush_ = std::chrono::steady_clock::now();
}

void Workspace::maybe_flush() {
    // Called with the unique lock already held.
    auto now = std::chrono::steady_clock::now();
    auto ms  = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_flush_).count();
    if (pending_ >= opt_.flush_every_n_stmts || ms >= opt_.flush_every_ms) {
        be_->flush();
        pending_ = 0;
        last_flush_ = now;
    }
}

std::vector<IndexRecord> Workspace::explorer_rows() const {
    std::shared_lock lk(mu_);
    std::vector<IndexRecord> out;
    out.reserve(index_.size());
    for (auto& [_, r] : index_) out.push_back(r);
    std::sort(out.begin(), out.end(),
              [](const IndexRecord& a, const IndexRecord& b) { return a.name < b.name; });
    return out;
}

IndexRecord Workspace::describe(const std::string& name) const {
    std::shared_lock lk(mu_);
    auto it = index_.find(name);
    if (it == index_.end()) throw std::runtime_error("ndat: no variable '" + name + "'");
    return it->second;
}

Variable Workspace::fetch(const std::string& name) const {
    std::shared_lock lk(mu_);
    return be_->get(name);
}

Array Workspace::fetch_slab(const std::string& name, const Slab& s) const {
    std::shared_lock lk(mu_);
    return be_->get_slab(name, s);
}

Array Workspace::plot_series(const std::string& name, std::uint64_t max_points) const {
    IndexRecord r = describe(name);
    if (!r.plottable) throw std::runtime_error("ndat: '" + name + "' is not plottable");

    // Read only the leading window; a production build would stride-decimate
    // across chunks instead. The point is that plotting never loads 200 GB.
    std::vector<std::uint64_t> start(r.shape.rank(), 0);
    std::vector<std::uint64_t> count = r.shape.dims;
    if (!count.empty() && count[0] > max_points) count[0] = max_points;
    return fetch_slab(name, Slab{start, count});
}

const char* Workspace::backend_name() const {
    std::shared_lock lk(mu_);
    return be_->backend_name();
}

FileHeader Workspace::header() const {
    std::shared_lock lk(mu_);
    return be_->header();
}

} // namespace ndat
