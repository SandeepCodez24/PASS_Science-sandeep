#include "ndat/variable.hpp"
#include <sstream>
#include <iomanip>
#include <cmath>
#include <limits>

namespace ndat {

const char* container_name(Container c) noexcept {
    switch (c) {
        case Container::Scalar:  return "scalar";
        case Container::List:    return "list";
        case Container::Matrix:  return "matrix";
        case Container::Tensor:  return "tensor";
        case Container::Variant: return "variant";
    }
    return "unknown";
}

namespace {

// Read element i of a dense numeric array as double (preview/stats only).
bool elem_as_double(const Array& a, std::uint64_t i, double& out) {
    const auto* p = a.values().data();
    switch (a.dtype().id) {
        case TypeId::Bool:    out = double(reinterpret_cast<const std::uint8_t*>(p)[i]); return true;
        case TypeId::Int8:    out = double(reinterpret_cast<const std::int8_t*>(p)[i]);  return true;
        case TypeId::Int16:   out = double(reinterpret_cast<const std::int16_t*>(p)[i]); return true;
        case TypeId::Int32:   out = double(reinterpret_cast<const std::int32_t*>(p)[i]); return true;
        case TypeId::Int64:   out = double(reinterpret_cast<const std::int64_t*>(p)[i]); return true;
        case TypeId::UInt8:   out = double(reinterpret_cast<const std::uint8_t*>(p)[i]); return true;
        case TypeId::UInt16:  out = double(reinterpret_cast<const std::uint16_t*>(p)[i]);return true;
        case TypeId::UInt32:  out = double(reinterpret_cast<const std::uint32_t*>(p)[i]);return true;
        case TypeId::UInt64:  out = double(reinterpret_cast<const std::uint64_t*>(p)[i]);return true;
        case TypeId::Float32: out = double(reinterpret_cast<const float*>(p)[i]);        return true;
        case TypeId::Float64: out = reinterpret_cast<const double*>(p)[i];               return true;
        default: return false;
    }
}

std::string fmt(double d) {
    std::ostringstream os;
    if (d == std::floor(d) && std::fabs(d) < 1e15)
        os << std::setprecision(15) << d;
    else
        os << std::setprecision(6) << d;
    return os.str();
}

std::string quote(const std::string& s, std::size_t cap = 24) {
    std::string t = s.size() > cap ? s.substr(0, cap) + "\u2026" : s;
    return "\"" + t + "\"";
}

std::string preview_array(const Array& a, std::size_t cap) {
    const std::uint64_t n = a.count();
    if (n == 0) return "[]";

    std::ostringstream os;
    const bool scalar = a.shape().rank() == 0 || n == 1;
    if (!scalar) os << "[";
    const std::uint64_t show = std::min<std::uint64_t>(n, cap);

    for (std::uint64_t i = 0; i < show; ++i) {
        if (i) os << ", ";
        if (a.dtype().nullable && !a.validity().get(i)) { os << "null"; continue; }
        if (a.dtype().id == TypeId::Utf8) { os << quote(a.string_at(i)); continue; }
        if (a.dtype().id == TypeId::Complex128) {
            const auto* c = a.values().as<double>();
            os << fmt(c[2*i]) << (c[2*i+1] < 0 ? "-" : "+") << fmt(std::fabs(c[2*i+1])) << "i";
            continue;
        }
        if (a.dtype().id == TypeId::Bool) {
            os << (a.values().data()[i] ? "true" : "false");
            continue;
        }
        double d;
        if (elem_as_double(a, i, d)) os << fmt(d);
        else                         os << "<" << type_name(a.dtype().id) << ">";
    }
    if (n > show) os << ", \u2026";
    if (!scalar) os << "]";
    return os.str();
}

Stats stats_array(const Array& a) {
    Stats s;
    if (!is_numeric(a.dtype().id) || is_complex(a.dtype().id)) return s;
    const std::uint64_t n = a.count();
    if (!n) return s;

    double mn = std::numeric_limits<double>::infinity();
    double mx = -mn;
    long double sum = 0.0L;
    std::uint64_t cnt = 0;

    for (std::uint64_t i = 0; i < n; ++i) {
        if (a.dtype().nullable && !a.validity().get(i)) { ++s.null_count; continue; }
        double d;
        if (!elem_as_double(a, i, d)) return s;
        mn = std::min(mn, d);
        mx = std::max(mx, d);
        sum += d;
        ++cnt;
    }
    if (!cnt) return s;
    s.valid = true;
    s.min = mn; s.max = mx; s.mean = double(sum / cnt);
    return s;
}

std::string preview_variant(const VariantArray& v, std::size_t cap) {
    const auto* codes = v.type_codes().data();
    const auto* coffs = v.child_offsets().as<std::int64_t>();
    const std::uint64_t n = v.size();
    if (!n) return "[]";

    std::ostringstream os;
    os << "[";
    const std::uint64_t show = std::min<std::uint64_t>(n, cap);
    for (std::uint64_t i = 0; i < show; ++i) {
        if (i) os << ", ";
        const Array& c = v.children()[codes[i]];
        const std::uint64_t slot = std::uint64_t(coffs[i]);
        if (c.dtype().id == TypeId::Null) { os << "null"; continue; }
        if (c.dtype().id == TypeId::Utf8) { os << quote(c.string_at(slot)); continue; }
        if (c.dtype().id == TypeId::Bool) { os << (c.values().data()[slot] ? "true" : "false"); continue; }
        double d;
        if (elem_as_double(c, slot, d)) os << fmt(d);
        else                            os << "<" << type_name(c.dtype().id) << ">";
    }
    if (n > show) os << ", \u2026";
    os << "]";
    return os.str();
}

} // namespace

IndexRecord make_index_record(const Variable& v,
                              const std::string& dataset_path,
                              std::uint64_t revision,
                              std::size_t preview_elems) {
    IndexRecord r;
    r.name          = v.name;
    r.type_label    = v.type_label();
    r.shape         = v.shape();
    r.size_label    = r.shape.to_string();
    r.container     = v.container();
    r.element_count = r.shape.count();
    r.nbytes        = v.nbytes();
    r.dataset_path  = dataset_path;
    r.revision      = revision;
    r.mtime_unix    = std::chrono::duration_cast<std::chrono::seconds>(
                          std::chrono::system_clock::now().time_since_epoch()).count();

    if (v.is_variant()) {
        const auto& va = std::get<VariantArray>(v.payload);
        r.preview   = preview_variant(va, preview_elems);
        // Plot only if every branch is numeric.
        r.plottable = true;
        for (TypeId t : va.present_types())
            if (!is_numeric(t)) { r.plottable = false; break; }
    } else {
        const auto& a = std::get<Array>(v.payload);
        r.preview   = preview_array(a, preview_elems);
        r.stats     = stats_array(a);
        r.plottable = is_numeric(a.dtype().id) && r.element_count > 0;
        if (a.dtype().nullable) r.stats.null_count = a.validity().null_count();
    }
    return r;
}

} // namespace ndat
