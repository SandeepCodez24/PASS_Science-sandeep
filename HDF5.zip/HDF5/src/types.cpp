#include "ndat/types.hpp"
#include <algorithm>

namespace ndat {

const char* type_name(TypeId t) noexcept {
    switch (t) {
        case TypeId::Null:        return "null";
        case TypeId::Bool:        return "bool";
        case TypeId::Int8:        return "int8";
        case TypeId::Int16:       return "int16";
        case TypeId::Int32:       return "int32";
        case TypeId::Int64:       return "int64";
        case TypeId::Int128:      return "int128";
        case TypeId::Int256:      return "int256";
        case TypeId::UInt8:       return "uint8";
        case TypeId::UInt16:      return "uint16";
        case TypeId::UInt32:      return "uint32";
        case TypeId::UInt64:      return "uint64";
        case TypeId::UInt128:     return "uint128";
        case TypeId::UInt256:     return "uint256";
        case TypeId::Float8E4M3:  return "float8_e4m3";
        case TypeId::Float8E5M2:  return "float8_e5m2";
        case TypeId::Float16:     return "float16";
        case TypeId::BFloat16:    return "bfloat16";
        case TypeId::Float32:     return "float32";
        case TypeId::Float64:     return "float64";
        case TypeId::Float128:    return "float128";
        case TypeId::Float256:    return "float256";
        case TypeId::Complex64:   return "complex64";
        case TypeId::Complex128:  return "complex128";
        case TypeId::Complex256:  return "complex256";
        case TypeId::Utf8:        return "utf8";
        case TypeId::FixedUtf8:   return "fixed_utf8";
        case TypeId::Bytes:       return "bytes";
        case TypeId::Date32:      return "date32";
        case TypeId::Timestamp64: return "timestamp64";
        case TypeId::Duration64:  return "duration64";
        case TypeId::Variant:     return "variant";
    }
    return "unknown";
}

Support support_of(TypeId t) noexcept {
    switch (t) {
        case TypeId::Int256: case TypeId::UInt256:
        case TypeId::Float256: case TypeId::Float8E4M3:
        case TypeId::Float8E5M2: case TypeId::BFloat16:
        case TypeId::Complex256:
            return Support::Unimplemented;          // reserved ids only
        case TypeId::Int128: case TypeId::UInt128:
        case TypeId::Float128: case TypeId::Float16:
            return Support::Emulated;               // software / converted path
        default:
            return Support::Native;
    }
}

std::size_t type_width(TypeId t) noexcept {
    switch (t) {
        case TypeId::Bool: case TypeId::Int8: case TypeId::UInt8:
        case TypeId::Float8E4M3: case TypeId::Float8E5M2:   return 1;
        case TypeId::Int16: case TypeId::UInt16:
        case TypeId::Float16: case TypeId::BFloat16:        return 2;
        case TypeId::Int32: case TypeId::UInt32:
        case TypeId::Float32: case TypeId::Date32:          return 4;
        case TypeId::Int64: case TypeId::UInt64:
        case TypeId::Float64: case TypeId::Timestamp64:
        case TypeId::Duration64: case TypeId::Complex64:    return 8;
        case TypeId::Int128: case TypeId::UInt128:
        case TypeId::Float128: case TypeId::Complex128:     return 16;
        case TypeId::Int256: case TypeId::UInt256:
        case TypeId::Float256: case TypeId::Complex256:     return 32;
        default: return 0;   // variable width or non-storable
    }
}

bool is_bool(TypeId t) noexcept { return t == TypeId::Bool; }

bool is_signed_int(TypeId t) noexcept {
    auto v = static_cast<std::uint16_t>(t);
    return v >= 0x02 && v <= 0x07;
}
bool is_unsigned_int(TypeId t) noexcept {
    auto v = static_cast<std::uint16_t>(t);
    return v >= 0x08 && v <= 0x0D;
}
bool is_integer(TypeId t) noexcept { return is_signed_int(t) || is_unsigned_int(t); }

bool is_float(TypeId t) noexcept {
    auto v = static_cast<std::uint16_t>(t);
    return v >= 0x20 && v <= 0x3F;
}
bool is_complex(TypeId t) noexcept {
    auto v = static_cast<std::uint16_t>(t);
    return v >= 0x40 && v <= 0x5F;
}
bool is_text(TypeId t) noexcept {
    auto v = static_cast<std::uint16_t>(t);
    return v >= 0x60 && v <= 0x7F;
}
bool is_numeric(TypeId t) noexcept {
    return is_bool(t) || is_integer(t) || is_float(t) || is_complex(t);
}

namespace {

// Rank inside each family, used to pick the wider of two same-family types.
int int_rank(TypeId t) noexcept {
    switch (t) {
        case TypeId::Int8:  case TypeId::UInt8:  return 8;
        case TypeId::Int16: case TypeId::UInt16: return 16;
        case TypeId::Int32: case TypeId::UInt32: return 32;
        case TypeId::Int64: case TypeId::UInt64: return 64;
        case TypeId::Int128:case TypeId::UInt128:return 128;
        default: return 256;
    }
}

TypeId signed_of_rank(int r) noexcept {
    if (r <= 8)   return TypeId::Int8;
    if (r <= 16)  return TypeId::Int16;
    if (r <= 32)  return TypeId::Int32;
    if (r <= 64)  return TypeId::Int64;
    if (r <= 128) return TypeId::Int128;
    return TypeId::Int256;
}
TypeId unsigned_of_rank(int r) noexcept {
    if (r <= 8)   return TypeId::UInt8;
    if (r <= 16)  return TypeId::UInt16;
    if (r <= 32)  return TypeId::UInt32;
    if (r <= 64)  return TypeId::UInt64;
    if (r <= 128) return TypeId::UInt128;
    return TypeId::UInt256;
}

int float_rank(TypeId t) noexcept {
    switch (t) {
        case TypeId::Float8E4M3: case TypeId::Float8E5M2: return 8;
        case TypeId::Float16: case TypeId::BFloat16:      return 16;
        case TypeId::Float32:                             return 32;
        case TypeId::Float64:                             return 64;
        case TypeId::Float128:                            return 128;
        default:                                          return 256;
    }
}
TypeId float_of_rank(int r) noexcept {
    if (r <= 16)  return TypeId::Float16;
    if (r <= 32)  return TypeId::Float32;
    if (r <= 64)  return TypeId::Float64;
    if (r <= 128) return TypeId::Float128;
    return TypeId::Float256;
}

TypeId complex_of_rank(int r) noexcept {
    if (r <= 32)  return TypeId::Complex64;
    if (r <= 64)  return TypeId::Complex128;
    return TypeId::Complex256;
}
int complex_rank(TypeId t) noexcept {
    switch (t) {
        case TypeId::Complex64:  return 32;
        case TypeId::Complex128: return 64;
        default:                 return 128;
    }
}

// Family ordering for the lattice climb.
int family(TypeId t) noexcept {
    if (t == TypeId::Null)     return 0;
    if (is_bool(t))            return 1;
    if (is_unsigned_int(t))    return 2;
    if (is_signed_int(t))      return 3;
    if (is_float(t))           return 4;
    if (is_complex(t))         return 5;
    return 9;                  // text / temporal / other
}

} // namespace

std::optional<TypeId> promote(TypeId a, TypeId b) noexcept {
    if (a == b) return a;
    if (a == TypeId::Null) return b;
    if (b == TypeId::Null) return a;

    // Text joins only with identical text kinds; anything else is a Variant job.
    if (is_text(a) || is_text(b)) {
        if (is_text(a) && is_text(b)) return TypeId::Utf8;
        return std::nullopt;
    }
    // Temporal types do not silently become numbers.
    if (!is_numeric(a) || !is_numeric(b)) return std::nullopt;

    const int fa = family(a), fb = family(b);
    const int top = std::max(fa, fb);

    if (top == 1) return TypeId::Bool;

    if (top == 2) {                                   // both unsigned (or bool)
        int r = std::max(is_bool(a) ? 8 : int_rank(a),
                         is_bool(b) ? 8 : int_rank(b));
        return unsigned_of_rank(r);
    }

    if (top == 3) {                                   // signed involved
        int ra = is_bool(a) ? 8 : int_rank(a);
        int rb = is_bool(b) ? 8 : int_rank(b);
        // unsigned N needs signed 2N to stay lossless
        if (is_unsigned_int(a)) ra *= 2;
        if (is_unsigned_int(b)) rb *= 2;
        int r = std::max(ra, rb);
        if (r > 256) return TypeId::Float64;          // overflow escape hatch
        return signed_of_rank(r);
    }

    if (top == 4) {                                   // float wins
        int rf = is_float(a) ? float_rank(a) : float_rank(b);
        TypeId other = is_float(a) ? b : a;
        int ro = is_bool(other) ? 16 : int_rank(other);
        // int64 is not exactly representable in float64, but this is the
        // conventional, documented widening. Recorded in the file as lossy.
        return float_of_rank(std::max(rf, std::min(ro, 64)));
    }

    // top == 5 : complex
    int rc = is_complex(a) ? complex_rank(a) : complex_rank(b);
    TypeId other = is_complex(a) ? b : a;
    int ro = is_float(other) ? float_rank(other)
           : (is_bool(other) ? 16 : std::min(int_rank(other), 64));
    return complex_of_rank(std::max(rc, ro));
}

std::optional<TypeId> promote_all(const std::vector<TypeId>& ts) noexcept {
    TypeId acc = TypeId::Null;
    for (TypeId t : ts) {
        auto r = promote(acc, t);
        if (!r) return std::nullopt;
        acc = *r;
    }
    return acc;
}

std::string DType::to_string() const {
    std::string s = type_name(id);
    if (id == TypeId::FixedUtf8)   s += "(" + std::to_string(param) + ")";
    if (id == TypeId::Timestamp64) {
        static const char* u[] = {"s","ms","us","ns"};
        s += "[" + std::string(u[param & 3]) + "]";
    }
    if (nullable) s += "?";
    return s;
}

} // namespace ndat
