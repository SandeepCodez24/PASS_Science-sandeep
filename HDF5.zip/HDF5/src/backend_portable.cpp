// ============================================================================
//  N-Data - portable backend (no third-party dependencies)
//
//  Append-only chunked log. Used when HDF5 is unavailable, and as the
//  reference implementation of the on-disk semantics: every byte written here
//  has a one-to-one mapping to the HDF5 layout.
//
//  Append-only gives us crash safety and SWMR almost for free: a reader only
//  ever sees records whose length prefix AND trailing checksum are complete.
// ============================================================================
#include "ndat/backend.hpp"

#include <fstream>
#include <map>
#include <mutex>
#include <shared_mutex>
#include <stdexcept>
#include <cstdio>

namespace ndat {
namespace {

constexpr char kRecTag[4] = {'N','D','R','C'};

// ---- little-endian primitive I/O -------------------------------------------
template <class T>
void put_pod(std::string& out, const T& v) {
    static_assert(std::is_trivially_copyable_v<T>);
    out.append(reinterpret_cast<const char*>(&v), sizeof(T));
}
void put_str(std::string& out, const std::string& s) {
    put_pod<std::uint32_t>(out, std::uint32_t(s.size()));
    out.append(s);
}
void put_buf(std::string& out, const Buffer& b) {
    put_pod<std::uint64_t>(out, std::uint64_t(b.size()));
    if (b.size()) out.append(reinterpret_cast<const char*>(b.data()), b.size());
}

struct Cursor {
    const char* p;
    const char* end;
    void need(std::size_t n) const {
        if (std::size_t(end - p) < n) throw std::runtime_error("ndat: truncated record");
    }
    template <class T> T pod() { need(sizeof(T)); T v; std::memcpy(&v, p, sizeof(T)); p += sizeof(T); return v; }
    std::string str() { auto n = pod<std::uint32_t>(); need(n); std::string s(p, n); p += n; return s; }
    void buf(Buffer& b) { auto n = pod<std::uint64_t>(); need(std::size_t(n)); b.resize(std::size_t(n));
                          if (n) std::memcpy(b.data(), p, std::size_t(n));
                          p += n; }
};

std::uint32_t fletcher32(const char* d, std::size_t n) {
    std::uint32_t s1 = 0xFFFF, s2 = 0xFFFF;
    std::size_t words = n / 2;
    const auto* w = reinterpret_cast<const std::uint8_t*>(d);
    for (std::size_t i = 0; i < words; ++i) {
        std::uint32_t v = std::uint32_t(w[2*i]) | (std::uint32_t(w[2*i+1]) << 8);
        s1 += v; s2 += s1;
        s1 = (s1 & 0xFFFF) + (s1 >> 16);
        s2 = (s2 & 0xFFFF) + (s2 >> 16);
    }
    if (n & 1) { s1 += w[n-1]; s2 += s1;
                 s1 = (s1 & 0xFFFF) + (s1 >> 16);
                 s2 = (s2 & 0xFFFF) + (s2 >> 16); }
    return (s2 << 16) | s1;
}

void serialize_dtype(std::string& o, const DType& d) {
    put_pod<std::uint16_t>(o, std::uint16_t(d.id));
    put_pod<std::uint32_t>(o, d.param);
    put_pod<std::uint8_t >(o, d.nullable ? 1 : 0);
}
DType parse_dtype(Cursor& c) {
    DType d;
    d.id       = TypeId(c.pod<std::uint16_t>());
    d.param    = c.pod<std::uint32_t>();
    d.nullable = c.pod<std::uint8_t>() != 0;
    return d;
}

void serialize_shape(std::string& o, const Shape& s) {
    put_pod<std::uint32_t>(o, std::uint32_t(s.dims.size()));
    for (auto d : s.dims) put_pod<std::uint64_t>(o, d);
}
Shape parse_shape(Cursor& c) {
    Shape s;
    auto r = c.pod<std::uint32_t>();
    s.dims.resize(r);
    for (std::uint32_t i = 0; i < r; ++i) s.dims[i] = c.pod<std::uint64_t>();
    return s;
}

void serialize_array(std::string& o, const Array& a) {
    serialize_dtype(o, a.dtype());
    serialize_shape(o, a.shape());
    put_buf(o, a.values());
    put_buf(o, a.offsets());
    put_pod<std::uint64_t>(o, std::uint64_t(a.validity().size()));
    put_buf(o, a.validity().bytes());
}
Array parse_array(Cursor& c) {
    DType d = parse_dtype(c);
    Shape s = parse_shape(c);
    Array a(d, s);
    c.buf(a.values());
    c.buf(a.offsets());
    auto vn = c.pod<std::uint64_t>();
    Buffer vb; c.buf(vb);
    if (vn) { a.validity().resize(std::size_t(vn), true);
              std::memcpy(a.validity().bytes().data(), vb.data(), vb.size()); }
    return a;
}

// ---------------------------------------------------------------------------
class PortableBackend final : public Backend {
public:
    void create(const std::string& path, const WriteOptions& opt) override {
        std::unique_lock lk(mu_);
        path_ = path; opt_ = opt;
        std::ofstream f(path, std::ios::binary | std::ios::trunc);
        if (!f) throw std::runtime_error("ndat: cannot create " + path);
        hdr_.created_unix = std::time(nullptr);
        f.write(kMagic, sizeof(kMagic));
        write_pod(f, hdr_.major);
        write_pod(f, hdr_.minor);
        write_pod(f, hdr_.min_reader_major);
        write_pod(f, hdr_.created_unix);
        std::uint32_t wn = std::uint32_t(hdr_.writer_id.size());
        write_pod(f, wn);
        f.write(hdr_.writer_id.data(), wn);
        f.close();
        index_.clear(); store_.clear(); rev_.clear();
    }

    void open(const std::string& path, bool read_only) override {
        std::unique_lock lk(mu_);
        path_ = path; read_only_ = read_only;
        std::ifstream f(path, std::ios::binary);
        if (!f) throw std::runtime_error("ndat: cannot open " + path);

        char magic[sizeof(kMagic)];
        f.read(magic, sizeof(magic));
        if (std::memcmp(magic, kMagic, sizeof(kMagic)) != 0)
            throw std::runtime_error("ndat: not an .ndat file");

        read_pod(f, hdr_.major);
        read_pod(f, hdr_.minor);
        read_pod(f, hdr_.min_reader_major);
        read_pod(f, hdr_.created_unix);
        std::uint32_t wn = 0; read_pod(f, wn);
        hdr_.writer_id.assign(wn, '\0');
        f.read(hdr_.writer_id.data(), wn);

        // Hard version gate: fail loudly rather than misread bytes.
        if (hdr_.min_reader_major > kFormatMajor)
            throw std::runtime_error("ndat: file requires reader major >= " +
                                     std::to_string(hdr_.min_reader_major));

        index_.clear(); store_.clear(); rev_.clear();
        replay(f);
    }

    void close() override {
        std::unique_lock lk(mu_);
        index_.clear(); store_.clear(); rev_.clear(); path_.clear();
    }

    FileHeader header() const override { std::shared_lock lk(mu_); return hdr_; }

    std::string put(const Variable& v, const WriteOptions& opt) override {
        std::unique_lock lk(mu_);
        if (read_only_) throw std::runtime_error("ndat: file opened read-only");

        std::string body;
        put_str(body, v.name);
        if (v.is_variant()) {
            const auto& va = std::get<VariantArray>(v.payload);
            put_pod<std::uint8_t>(body, 1);
            serialize_shape(body, va.shape());
            put_pod<std::uint64_t>(body, va.size());
            put_buf(body, va.type_codes());
            put_buf(body, va.child_offsets());
            put_pod<std::uint32_t>(body, std::uint32_t(va.children().size()));
            for (const auto& c : va.children()) serialize_array(body, c);
        } else {
            put_pod<std::uint8_t>(body, 0);
            serialize_array(body, std::get<Array>(v.payload));
        }

        std::uint64_t rev = ++rev_[v.name];
        std::string   dpath = "/vars/" + v.name;

        append_record(body, opt);

        store_.insert_or_assign(v.name, v);
        index_[v.name] = make_index_record(v, dpath, rev);
        return dpath;
    }

    void erase(const std::string& name) override {
        std::unique_lock lk(mu_);
        std::string body;
        put_str(body, name);
        put_pod<std::uint8_t>(body, 0xFF);    // tombstone
        append_record(body, opt_);
        store_.erase(name);
        index_.erase(name);
    }

    std::vector<IndexRecord> index() const override {
        std::shared_lock lk(mu_);
        std::vector<IndexRecord> out;
        out.reserve(index_.size());
        for (auto& [_, r] : index_) out.push_back(r);
        return out;
    }

    Variable get(const std::string& name) const override {
        std::shared_lock lk(mu_);
        auto it = store_.find(name);
        if (it == store_.end()) throw std::runtime_error("ndat: no variable '" + name + "'");
        return it->second;
    }

    Array get_slab(const std::string& name, const Slab& s) const override {
        std::shared_lock lk(mu_);
        auto it = store_.find(name);
        if (it == store_.end()) throw std::runtime_error("ndat: no variable '" + name + "'");
        if (it->second.is_variant())
            throw std::runtime_error("ndat: slab read on variant not supported in v1");

        const Array& a = std::get<Array>(it->second.payload);
        const std::size_t w = type_width(a.dtype().id);
        if (!w) throw std::runtime_error("ndat: slab read needs fixed-width dtype");

        const auto& dims = a.shape().dims;
        if (s.start.size() != dims.size() || s.count.size() != dims.size())
            throw std::runtime_error("ndat: slab rank mismatch");

        Shape out_shape(s.count);
        Array out(a.dtype(), out_shape);
        out.values().resize(std::size_t(out_shape.count() * w));

        std::vector<std::uint64_t> at(dims.size(), 0);
        const std::uint64_t n = out_shape.count();
        for (std::uint64_t k = 0; k < n; ++k) {
            std::vector<std::uint64_t> src(dims.size());
            for (std::size_t d = 0; d < dims.size(); ++d) src[d] = s.start[d] + at[d];
            std::uint64_t si = a.shape().index(src);
            std::memcpy(out.values().data() + k * w, a.values().data() + si * w, w);
            for (std::size_t d = dims.size(); d-- > 0;) {
                if (++at[d] < s.count[d]) break;
                at[d] = 0;
            }
        }
        return out;
    }

    void flush() override {
        std::unique_lock lk(mu_);
        // Append-only writes are already durable at record granularity; this is
        // where an fsync would go on a checkpoint boundary.
    }

    const char* backend_name() const noexcept override { return "portable"; }

private:
    template <class T> static void write_pod(std::ostream& o, const T& v) {
        o.write(reinterpret_cast<const char*>(&v), sizeof(T));
    }
    template <class T> static void read_pod(std::istream& i, T& v) {
        i.read(reinterpret_cast<char*>(&v), sizeof(T));
    }

    void append_record(const std::string& body, const WriteOptions& opt) {
        std::ofstream f(path_, std::ios::binary | std::ios::app);
        if (!f) throw std::runtime_error("ndat: cannot append to " + path_);
        std::uint64_t len = body.size();
        std::uint32_t ck  = opt.checksum ? fletcher32(body.data(), body.size()) : 0u;
        f.write(kRecTag, sizeof(kRecTag));
        write_pod(f, len);
        f.write(body.data(), std::streamsize(len));
        write_pod(f, ck);
        f.flush();
    }

    void replay(std::ifstream& f) {
        while (true) {
            char tag[4];
            f.read(tag, 4);
            if (f.gcount() != 4) break;                       // clean EOF
            if (std::memcmp(tag, kRecTag, 4) != 0) break;     // torn tail
            std::uint64_t len = 0;
            read_pod(f, len);
            if (!f) break;
            std::string body(std::size_t(len), '\0');
            f.read(body.data(), std::streamsize(len));
            if (std::uint64_t(f.gcount()) != len) break;      // torn record: stop
            std::uint32_t ck = 0;
            read_pod(f, ck);
            if (!f) break;
            if (ck && ck != fletcher32(body.data(), body.size())) break;  // corrupt: stop

            Cursor c{body.data(), body.data() + body.size()};
            std::string name = c.str();
            auto kind = c.pod<std::uint8_t>();

            if (kind == 0xFF) { store_.erase(name); index_.erase(name); continue; }

            std::uint64_t rev = ++rev_[name];
            std::string dpath = "/vars/" + name;

            if (kind == 0) {
                Variable v(name, parse_array(c));
                index_[name] = make_index_record(v, dpath, rev);
                store_.insert_or_assign(name, std::move(v));
            } else {
                Shape sh = parse_shape(c);
                VariantArray va(sh);
                auto n = c.pod<std::uint64_t>();
                (void)n;
                Buffer codes, coffs; c.buf(codes); c.buf(coffs);
                auto nk = c.pod<std::uint32_t>();
                std::vector<Array> kids;
                for (std::uint32_t k = 0; k < nk; ++k) kids.push_back(parse_array(c));
                va = rebuild_variant(sh, codes, coffs, kids);
                Variable v(name, std::move(va));
                index_[name] = make_index_record(v, dpath, rev);
                store_.insert_or_assign(name, std::move(v));
            }
        }
    }

    // Rebuild a variant by replaying its elements through the public API,
    // which keeps the class invariants intact.
    static VariantArray rebuild_variant(const Shape& sh, const Buffer& codes,
                                        const Buffer& coffs,
                                        const std::vector<Array>& kids) {
        VariantArray va(sh);
        const auto* cd = codes.data();
        const auto* of = coffs.as<std::int64_t>();
        for (std::size_t i = 0; i < codes.size(); ++i) {
            const Array& c = kids[cd[i]];
            const std::uint64_t slot = std::uint64_t(of[i]);
            switch (c.dtype().id) {
                case TypeId::Null:    va.push_null(); break;
                case TypeId::Utf8:    va.push_string(c.string_at(slot)); break;
                case TypeId::Bool:    va.push(c.values().data()[slot], TypeId::Bool); break;
                case TypeId::Int64:   va.push(c.values().as<std::int64_t>()[slot], TypeId::Int64); break;
                case TypeId::Float64: va.push(c.values().as<double>()[slot], TypeId::Float64); break;
                case TypeId::Float32: va.push(c.values().as<float>()[slot], TypeId::Float32); break;
                case TypeId::Int32:   va.push(c.values().as<std::int32_t>()[slot], TypeId::Int32); break;
                default:              va.push_null(); break;
            }
        }
        return va;
    }

    mutable std::shared_mutex                  mu_;
    std::string                                path_;
    bool                                       read_only_ = false;
    FileHeader                                 hdr_;
    WriteOptions                               opt_;
    std::map<std::string, Variable>            store_;
    std::map<std::string, IndexRecord>         index_;
    std::map<std::string, std::uint64_t>       rev_;
};

} // namespace

std::unique_ptr<Backend> make_portable_backend() {
    return std::make_unique<PortableBackend>();
}

} // namespace ndat
