# N-Data (`.ndat`) — v1.0

Workspace storage format and C++ reference implementation for the IDE.
One `.ndat` file = one entire workspace.

## Build

```bash
cmake -B build -DNDAT_WITH_HDF5=ON
cmake --build build
./build/ndat_demo
```

Without HDF5 installed the library still builds and runs — `make_backend("hdf5")`
silently falls back to the dependency-free portable backend, which implements
identical semantics.

## Layout

| File | Purpose |
|---|---|
| `include/ndat/types.hpp` | `TypeId` (stable wire ids), `DType`, promotion lattice |
| `include/ndat/array.hpp` | `Buffer` (256-B aligned), `Bitmap`, `Shape`, `Array`, `VariantArray` |
| `include/ndat/variable.hpp` | `Variable`, `IndexRecord` (the explorer row) |
| `include/ndat/backend.hpp` | Storage backend interface |
| `include/ndat/workspace.hpp` | The API the executor calls |
| `src/backend_hdf5.cpp` | Canonical backend, SWMR, chunked, compressed |
| `src/backend_portable.cpp` | Append-only fallback + reference semantics |

## Design rules encoded in the code

1. **Defaults are `int64` and `float64`.** `float16` is reserved and opt-in only.
2. **`TypeId` values are permanent.** Never renumber, never reuse a retired id. Only append.
3. **Reserved-but-unimplemented types** (`int256`, `float256`, `float8`, `bfloat16`) have ids
   allocated now. `support_of()` reports `Native` / `Emulated` / `Unimplemented` so a reader
   can *skip* a type rather than misread its bytes.
4. **Promotion lattice:** `Null < Bool < UInt < Int < Float < Complex`. Text never joins
   numerics — that pair returns `nullopt`, which routes to a variant.
5. **Mixed containers become a dense-union `VariantArray`**, never a rewrite. A single string
   in a 5×5 float matrix costs one 5-byte child plus two index buffers; the float payload is
   untouched and stays type-pure for GPU kernels.
6. **The explorer never touches the payload.** It reads `IndexRecord` only — name, type label,
   size label, capped preview, byte count, revision, min/max/mean.
7. **Version gate.** `min_reader_major` makes an old IDE fail loudly instead of misreading a
   newer file. Minor bumps stay backward compatible; unknown attributes are preserved on
   round-trip via `IndexRecord::unknown_attrs`.
8. **Big data.** Chunked (4 MB default), extendible dimensions, 64-bit offsets everywhere,
   per-chunk Fletcher32, byte-shuffle + deflate, hyperslab reads via `fetch_slab`.
9. **GPU layout.** SoA only, 256-byte alignment, row-major, little-endian, Arrow-style
   `offsets[] + bytes[]` strings, bool values as `uint8` and null masks as packed bitmaps.
10. **Line-by-line execution does not reopen the file per statement.** The in-memory table is
    source of truth; flush happens on a checkpoint policy (64 statements / 500 ms / explicit).

## Executor usage

```cpp
ndat::SessionOptions so;
so.backend = "hdf5";
ndat::Workspace ws(so);
ws.create("session.ndat");

ws.assign("n",  ndat::Array::from_vector<std::int64_t>({42}, ndat::TypeId::Int64, {}));
ws.assign("pi", ndat::Array::from_vector<double>({3.14159}, ndat::TypeId::Float64, {}));

// Heterogeneous literal: joins if possible, else emits a variant.
std::vector<ndat::Workspace::Element> e = /* ... */;
ws.assign_mixed("M", e, ndat::Shape{5, 5});

ws.checkpoint();
for (auto& row : ws.explorer_rows())
    // row.name / row.preview / row.size_label / row.type_label
```

## Known gaps in v1

- `Hdf5Backend::get()` does not yet reconstruct a `VariantArray` from disk (the writer does
  emit it; the portable backend round-trips it fully).
- `plot_series` reads a leading window; stride-decimation across chunks is the next step.
- `int128` / `float128` are stored as opaque fixed-width blobs — correct on disk, no arithmetic.
- Arrow IPC / Parquet / netCDF exporters are not written yet; they slot in behind `Backend`
  with no change to `Workspace` or any caller.
