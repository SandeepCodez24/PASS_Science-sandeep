// ============================================================================
//  N-Data demo - exercises every rule agreed in the design discussion.
// ============================================================================
#include "ndat/workspace.hpp"
#include <iostream>
#include <iomanip>
#include <thread>
#include <atomic>
#include <vector>

using namespace ndat;

static void print_explorer(const Workspace& ws) {
    auto rows = ws.explorer_rows();
    std::cout << "\n  " << std::left
              << std::setw(10) << "Name"
              << std::setw(34) << "Value"
              << std::setw(10) << "Size"
              << "Datatype\n";
    std::cout << "  " << std::string(76, '-') << "\n";
    for (auto& r : rows) {
        std::string val = r.preview.size() > 32 ? r.preview.substr(0, 31) + "\u2026" : r.preview;
        std::cout << "  " << std::left
                  << std::setw(10) << r.name
                  << std::setw(34) << val
                  << std::setw(10) << r.size_label
                  << r.type_label << "\n";
    }
    std::cout << "\n";
}

int main() {
    std::cout << "N-Data v" << kFormatMajor << "." << kFormatMinor << "\n";

    // --- promotion lattice sanity ------------------------------------------
    std::cout << "\n[promotion lattice]\n";
    auto show = [](TypeId a, TypeId b) {
        auto r = promote(a, b);
        std::cout << "  " << std::setw(10) << type_name(a) << " + "
                  << std::setw(10) << type_name(b) << " -> "
                  << (r ? type_name(*r) : "IRRECONCILABLE -> variant") << "\n";
    };
    show(TypeId::Bool,    TypeId::Float64);   // rule 7
    show(TypeId::Int32,   TypeId::Float64);
    show(TypeId::UInt32,  TypeId::Int32);
    show(TypeId::Float64, TypeId::Complex128);
    show(TypeId::Float64, TypeId::Utf8);      // rule 6 -> variant, no rewrite

    SessionOptions so;
    so.backend = "hdf5";                      // falls back to portable if unbuilt
    Workspace ws(so);
    ws.create("/home/claude/ndat/demo_workspace.ndat");
    std::cout << "\nbackend in use: " << ws.backend_name() << "\n";

    // --- scalars: defaults are int64 / float64 -----------------------------
    ws.assign("n",  Array::from_vector<std::int64_t>({42}, TypeId::Int64, Shape{}));
    ws.assign("pi", Array::from_vector<double>({3.14159265358979}, TypeId::Float64, Shape{}));
    ws.assign("ok", Array::from_vector<std::uint8_t>({1}, TypeId::Bool, Shape{}));
    ws.assign("msg", Array::from_strings({"hello ndat"}, Shape{}));

    // --- complex list -------------------------------------------------------
    {
        std::vector<double> c = {1.0, 2.0, -0.5, 3.25, 4.0, 0.0};   // 3 complex values
        ws.assign("z", Array::from_vector<double>(c, TypeId::Complex128, Shape{3}));
    }

    // --- 5x5 float matrix with a bool at [3,3] : RULE 7 ---------------------
    {
        std::vector<Workspace::Element> e;
        for (int i = 0; i < 25; ++i) {
            Workspace::Element x;
            x.type = TypeId::Float64;
            x.num  = 0.1 * (i + 1);
            e.push_back(x);
        }
        e[3 * 5 + 3].type = TypeId::Bool;      // element [3,3] is boolean 0
        e[3 * 5 + 3].num  = 0.0;
        ws.assign_mixed("M_float", e, Shape{5, 5});   // -> whole matrix float64
    }

    // --- 5x5 float matrix with "apple" at [3,3] : RULE 6 --------------------
    {
        std::vector<Workspace::Element> e;
        for (int i = 0; i < 25; ++i) {
            Workspace::Element x;
            x.type = TypeId::Float64;
            x.num  = double(i);
            e.push_back(x);
        }
        e[3 * 5 + 3].type = TypeId::Utf8;
        e[3 * 5 + 3].text = "apple";
        ws.assign_mixed("M_mixed", e, Shape{5, 5});   // -> variant<float64|utf8>
    }

    // --- missing values -----------------------------------------------------
    {
        std::vector<Workspace::Element> e;
        for (int i = 0; i < 6; ++i) {
            Workspace::Element x; x.type = TypeId::Float64; x.num = i * 1.5;
            e.push_back(x);
        }
        e[2].is_null = true;
        ws.assign_mixed("with_nan", e, Shape{6});
    }

    ws.checkpoint();
    print_explorer(ws);

    // --- variant cost check: the odd element did NOT rewrite the payload ----
    {
        auto r = ws.describe("M_mixed");
        std::cout << "[variant] M_mixed payload = " << r.nbytes << " bytes"
                  << "  (24 doubles = 192 B + 5 B string + index buffers)\n";
        auto rf = ws.describe("M_float");
        std::cout << "[dense  ] M_float payload = " << rf.nbytes << " bytes"
                  << "  min=" << rf.stats.min << " max=" << rf.stats.max
                  << " mean=" << std::setprecision(4) << rf.stats.mean << "\n";
    }

    // --- partial read: plotting never materializes the whole variable -------
    {
        Slab s;
        s.start = {1, 1};
        s.count = {2, 3};
        Array sub = ws.fetch_slab("M_float", s);
        std::cout << "\n[slab] M_float[1:3, 1:4] = ";
        const double* p = sub.values().as<double>();
        for (std::uint64_t i = 0; i < sub.count(); ++i) std::cout << p[i] << " ";
        std::cout << "\n";
    }

    // --- concurrent readers while the executor keeps writing ----------------
    {
        std::cout << "\n[swmr] launching 3 readers during writes...\n";
        std::atomic<int> seen{0};
        std::vector<std::thread> rs;
        for (int t = 0; t < 3; ++t)
            rs.emplace_back([&] {
                for (int k = 0; k < 50; ++k) seen += int(ws.explorer_rows().size());
            });
        for (int k = 0; k < 50; ++k)
            ws.assign("tmp" + std::to_string(k % 4),
                      Array::from_vector<double>({double(k)}, TypeId::Float64, Shape{}));
        for (auto& t : rs) t.join();
        std::cout << "[swmr] readers observed " << seen.load()
                  << " rows total, no tearing\n";
    }

    ws.checkpoint();

    // --- reopen: verify round-trip and the version gate ---------------------
    ws.close();
    {
        Workspace ro(so);
        ro.open("/home/claude/ndat/demo_workspace.ndat", true);
        auto h = ro.header();
        std::cout << "\n[reopen] format " << h.major << "." << h.minor
                  << "  min_reader=" << h.min_reader_major
                  << "  writer=" << h.writer_id << "\n";
        print_explorer(ro);
        auto v = ro.fetch("M_mixed");
        std::cout << "[reopen] M_mixed round-tripped as " << v.type_label() << "\n";
    }
    return 0;
}
