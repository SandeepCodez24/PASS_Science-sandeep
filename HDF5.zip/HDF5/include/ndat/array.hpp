// ============================================================================
//  N-Data - buffers, arrays, variant (tagged union) arrays
//
//  Layout rules (GPU-facing, non-negotiable):
//    * Struct-of-Arrays only. No pointers, no per-element headers.
//    * Every buffer 256-byte aligned (CUDA / HIP transfer alignment).
//    * Row-major, little-endian on disk.
//    * Strings = offsets[] + utf8 bytes[] (Arrow layout), never char*.
//    * Bool values = uint8 (coalesces); validity mask = packed bitmap.
// ============================================================================
#pragma once

#include "ndat/types.hpp"
#include <cstring>
#include <memory>
#include <numeric>
#include <stdexcept>

namespace ndat {

inline constexpr std::size_t kGpuAlign = 256;

// ---------------------------------------------------------------------------
// Aligned, resizable byte buffer.
// ---------------------------------------------------------------------------
class Buffer {
public:
    Buffer() = default;
    explicit Buffer(std::size_t n) { resize(n); }
    ~Buffer() { release(); }

    Buffer(const Buffer& o) { assign(o.data_, o.size_); }
    Buffer& operator=(const Buffer& o) {
        if (this != &o) { release(); assign(o.data_, o.size_); }
        return *this;
    }
    Buffer(Buffer&& o) noexcept
        : data_(o.data_), size_(o.size_), cap_(o.cap_) {
        o.data_ = nullptr; o.size_ = o.cap_ = 0;
    }
    Buffer& operator=(Buffer&& o) noexcept {
        if (this != &o) {
            release();
            data_ = o.data_; size_ = o.size_; cap_ = o.cap_;
            o.data_ = nullptr; o.size_ = o.cap_ = 0;
        }
        return *this;
    }

    void resize(std::size_t n) {
        if (n > cap_) reserve(grow(n));
        size_ = n;
    }
    void reserve(std::size_t n) {
        if (n <= cap_) return;
        std::size_t cap = (n + kGpuAlign - 1) / kGpuAlign * kGpuAlign;
        void* p = alloc(cap);
        if (!p) throw std::bad_alloc();
        if (data_ && size_) std::memcpy(p, data_, size_);
        release();
        data_ = static_cast<std::uint8_t*>(p);
        cap_  = cap;
    }
    void append(const void* src, std::size_t n) {
        std::size_t off = size_;
        resize(size_ + n);
        if (n) std::memcpy(data_ + off, src, n);
    }
    void clear() { size_ = 0; }

    std::uint8_t*       data()       noexcept { return data_; }
    const std::uint8_t* data() const noexcept { return data_; }
    std::size_t         size() const noexcept { return size_; }
    bool                empty()const noexcept { return size_ == 0; }

    template <class T> T*       as()       noexcept { return reinterpret_cast<T*>(data_); }
    template <class T> const T* as() const noexcept { return reinterpret_cast<const T*>(data_); }

private:
    static std::size_t grow(std::size_t n) { return n < 64 ? 64 : n + n / 2; }

    static void* alloc(std::size_t cap) {
#if defined(_MSC_VER)
        return _aligned_malloc(cap, kGpuAlign);
#else
        void* p = nullptr;
        if (posix_memalign(&p, kGpuAlign, cap) != 0) return nullptr;
        return p;
#endif
    }
    void release() {
        if (!data_) return;
#if defined(_MSC_VER)
        _aligned_free(data_);
#else
        free(data_);
#endif
        data_ = nullptr; size_ = cap_ = 0;
    }
    void assign(const std::uint8_t* src, std::size_t n) {
        if (!n) return;
        reserve(n);
        std::memcpy(data_, src, n);
        size_ = n;
    }

    std::uint8_t* data_ = nullptr;
    std::size_t   size_ = 0;
    std::size_t   cap_  = 0;
};

// ---------------------------------------------------------------------------
// Packed validity bitmap (1 = valid, 0 = missing).
// ---------------------------------------------------------------------------
class Bitmap {
public:
    void resize(std::size_t n, bool value = true) {
        n_ = n;
        bits_.resize((n + 7) / 8);
        if (bits_.size()) std::memset(bits_.data(), value ? 0xFF : 0x00, bits_.size());
    }
    void push_back(bool v) {
        std::size_t i = n_++;
        if ((n_ + 7) / 8 > bits_.size()) { bits_.resize((n_ + 7) / 8); bits_.data()[bits_.size()-1] = 0; }
        set(i, v);
    }
    void set(std::size_t i, bool v) {
        auto* b = bits_.data();
        if (v) b[i >> 3] |=  std::uint8_t(1u << (i & 7));
        else   b[i >> 3] &= std::uint8_t(~(1u << (i & 7)));
    }
    bool get(std::size_t i) const {
        return (bits_.data()[i >> 3] >> (i & 7)) & 1u;
    }
    std::size_t   size()  const noexcept { return n_; }
    const Buffer& bytes() const noexcept { return bits_; }
    Buffer&       bytes()       noexcept { return bits_; }
    std::size_t null_count() const {
        std::size_t c = 0;
        for (std::size_t i = 0; i < n_; ++i) if (!get(i)) ++c;
        return c;
    }
private:
    Buffer      bits_;
    std::size_t n_ = 0;
};

// ---------------------------------------------------------------------------
// Shape: row-major, 64-bit extents. rank 0 = scalar, 1 = list, 2 = matrix, n = tensor.
// ---------------------------------------------------------------------------
struct Shape {
    std::vector<std::uint64_t> dims;

    Shape() = default;
    Shape(std::initializer_list<std::uint64_t> d) : dims(d) {}
    explicit Shape(std::vector<std::uint64_t> d) : dims(std::move(d)) {}

    std::size_t   rank()  const noexcept { return dims.size(); }
    std::uint64_t count() const noexcept {
        return std::accumulate(dims.begin(), dims.end(), std::uint64_t{1},
                               std::multiplies<std::uint64_t>());
    }
    // Row-major linear index.
    std::uint64_t index(const std::vector<std::uint64_t>& at) const {
        std::uint64_t idx = 0;
        for (std::size_t i = 0; i < dims.size(); ++i) idx = idx * dims[i] + at[i];
        return idx;
    }
    std::string to_string() const {
        if (dims.empty()) return "1x1";
        std::string s;
        for (std::size_t i = 0; i < dims.size(); ++i) {
            if (i) s += "x";
            s += std::to_string(dims[i]);
        }
        return s;
    }
};

// ---------------------------------------------------------------------------
// Array - one homogeneous dtype over a shape.
//   values : dense element buffer (or offsets target for Utf8)
//   offsets: only for Utf8/Bytes, length count()+1, int64
//   validity: only when dtype.nullable
// ---------------------------------------------------------------------------
class Array {
public:
    Array() = default;
    Array(DType dt, Shape sh) : dtype_(dt), shape_(std::move(sh)) {}

    const DType& dtype() const noexcept { return dtype_; }
    const Shape& shape() const noexcept { return shape_; }
    DType&       dtype()       noexcept { return dtype_; }
    Shape&       shape()       noexcept { return shape_; }

    Buffer&       values()        noexcept { return values_; }
    const Buffer& values()  const noexcept { return values_; }
    Buffer&       offsets()       noexcept { return offsets_; }
    const Buffer& offsets() const noexcept { return offsets_; }
    Bitmap&       validity()      noexcept { return validity_; }
    const Bitmap& validity()const noexcept { return validity_; }

    std::uint64_t count() const noexcept { return shape_.count(); }

    std::uint64_t nbytes() const noexcept {
        return values_.size() + offsets_.size() + validity_.bytes().size();
    }

    // --- typed fill helpers -------------------------------------------------
    template <class T>
    static Array from_vector(const std::vector<T>& v, TypeId id, Shape sh) {
        Array a(DType(id), std::move(sh));
        a.values_.append(v.data(), v.size() * sizeof(T));
        return a;
    }

    static Array from_strings(const std::vector<std::string>& v, Shape sh) {
        Array a(DType(TypeId::Utf8), std::move(sh));
        std::vector<std::int64_t> off;
        off.reserve(v.size() + 1);
        std::int64_t cur = 0;
        off.push_back(0);
        for (auto& s : v) { cur += std::int64_t(s.size()); off.push_back(cur); }
        a.offsets_.append(off.data(), off.size() * sizeof(std::int64_t));
        for (auto& s : v) a.values_.append(s.data(), s.size());
        return a;
    }

    std::string string_at(std::uint64_t i) const {
        const auto* off = offsets_.as<std::int64_t>();
        return std::string(reinterpret_cast<const char*>(values_.data()) + off[i],
                           std::size_t(off[i + 1] - off[i]));
    }

private:
    DType  dtype_;
    Shape  shape_;
    Buffer values_;
    Buffer offsets_;
    Bitmap validity_;
};

// ---------------------------------------------------------------------------
// VariantArray - the answer to "one stray string in a 500 GB matrix".
//
//   type_codes[i] -> which child array element i lives in   (uint8, dense)
//   child_offsets[i] -> slot inside that child              (int64, dense)
//   children[k]   -> a dense homogeneous Array per present type
//
// This is Arrow's dense-union layout. Adding a string to a float matrix costs
// one new child of length 1 plus two small index buffers - NOT a rewrite of
// the float payload. Children stay type-pure, so GPU kernels can run over
// children[float64] untouched and ignore the rest.
// ---------------------------------------------------------------------------
class VariantArray {
public:
    explicit VariantArray(Shape sh) : shape_(std::move(sh)) {}

    const Shape& shape() const noexcept { return shape_; }

    // Register (or find) a child of the given dtype; returns its code.
    std::uint8_t child_code(const DType& dt) {
        for (std::size_t k = 0; k < children_.size(); ++k)
            if (children_[k].dtype() == dt) return std::uint8_t(k);
        if (children_.size() >= 255)
            throw std::runtime_error("ndat: variant exceeds 255 distinct types");
        children_.emplace_back(dt, Shape{0});
        return std::uint8_t(children_.size() - 1);
    }

    // Append a POD element of a concrete type.
    template <class T>
    void push(const T& v, TypeId id) {
        DType dt(id);
        std::uint8_t code = child_code(dt);
        Array& c = children_[code];
        std::uint64_t slot = c.count();
        c.values().append(&v, sizeof(T));
        c.shape().dims = { slot + 1 };
        record(code, slot);
    }

    void push_string(const std::string& s) {
        DType dt(TypeId::Utf8);
        std::uint8_t code = child_code(dt);
        Array& c = children_[code];
        if (c.offsets().empty()) {
            std::int64_t zero = 0;
            c.offsets().append(&zero, sizeof(zero));
        }
        std::uint64_t slot = c.count();
        c.values().append(s.data(), s.size());
        std::int64_t last = c.offsets().as<std::int64_t>()[slot] + std::int64_t(s.size());
        c.offsets().append(&last, sizeof(last));
        c.shape().dims = { slot + 1 };
        record(code, slot);
    }

    void push_null() {
        DType dt(TypeId::Null);
        std::uint8_t code = child_code(dt);
        Array& c = children_[code];
        std::uint64_t slot = c.count();
        c.shape().dims = { slot + 1 };
        record(code, slot);
    }

    std::uint64_t size() const noexcept { return n_; }
    const Buffer& type_codes()    const noexcept { return codes_; }
    const Buffer& child_offsets() const noexcept { return coffs_; }
    const std::vector<Array>& children() const noexcept { return children_; }

    // Distinct dtypes present, for the variable explorer's "Datatype" column.
    std::vector<TypeId> present_types() const {
        std::vector<TypeId> v;
        for (auto& c : children_) v.push_back(c.dtype().id);
        return v;
    }

    // If every element could be represented by one type, report it. This lets
    // the workspace collapse a variant back to a dense array on next write.
    std::optional<TypeId> collapsible_to() const {
        return promote_all(present_types());
    }

    // Human label, e.g. "variant<float64|utf8>"
    std::string type_label() const {
        std::string s = "variant<";
        for (std::size_t k = 0; k < children_.size(); ++k) {
            if (k) s += "|";
            s += children_[k].dtype().to_string();
        }
        return s + ">";
    }

    std::uint64_t nbytes() const {
        std::uint64_t n = codes_.size() + coffs_.size();
        for (auto& c : children_) n += c.nbytes();
        return n;
    }

private:
    void record(std::uint8_t code, std::uint64_t slot) {
        codes_.append(&code, 1);
        std::int64_t s = std::int64_t(slot);
        coffs_.append(&s, sizeof(s));
        ++n_;
    }

    Shape              shape_;
    Buffer             codes_;
    Buffer             coffs_;
    std::vector<Array> children_;
    std::uint64_t      n_ = 0;
};

} // namespace ndat
