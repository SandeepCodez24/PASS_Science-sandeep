// ============================================================================
//  N-Data (.ndat) - logical type system
//  Format spec version 1.0
//
//  RULE: TypeId values are a permanent part of the on-disk format.
//        Never renumber. Never reuse a retired id. Only append.
// ============================================================================
#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include <optional>

namespace ndat {

// ---------------------------------------------------------------------------
// Format version. Minor bump = backward compatible (readers skip unknowns).
// Major bump = incompatible. min_reader_version makes old readers fail loudly.
// ---------------------------------------------------------------------------
inline constexpr std::uint16_t kFormatMajor       = 1;
inline constexpr std::uint16_t kFormatMinor       = 0;
inline constexpr std::uint16_t kMinReaderMajor    = 1;
inline constexpr char          kMagic[8]          = {'N','D','A','T','\0','\r','\n',char(0x1A)};

// ---------------------------------------------------------------------------
// TypeId - stable wire identifiers.
//  0x00        : special
//  0x01-0x1F   : boolean / integers
//  0x20-0x3F   : floats
//  0x40-0x5F   : complex
//  0x60-0x7F   : text / bytes
//  0x80-0x9F   : temporal
//  0xA0-0xBF   : composite (reserved for v2: struct, ragged list, categorical)
// ---------------------------------------------------------------------------
enum class TypeId : std::uint16_t {
    Null        = 0x00,   // all-missing / untyped empty

    Bool        = 0x01,   // stored as uint8 0/1 (GPU-coalescing friendly)

    Int8        = 0x02,
    Int16       = 0x03,
    Int32       = 0x04,
    Int64       = 0x05,   // <-- DEFAULT integer
    Int128      = 0x06,   // optional: software fallback on MSVC
    Int256      = 0x07,   // RESERVED - declared, not implemented in v1

    UInt8       = 0x08,
    UInt16      = 0x09,
    UInt32      = 0x0A,
    UInt64      = 0x0B,
    UInt128     = 0x0C,   // optional
    UInt256     = 0x0D,   // RESERVED

    Float8E4M3  = 0x20,   // RESERVED - ML micro-float, explicit opt-in only
    Float8E5M2  = 0x21,   // RESERVED
    Float16     = 0x22,   // IEEE binary16 - explicit opt-in (GPU tensor paths)
    BFloat16    = 0x23,   // RESERVED
    Float32     = 0x24,
    Float64     = 0x25,   // <-- DEFAULT real
    Float128    = 0x26,   // optional: __float128 / software fallback
    Float256    = 0x27,   // RESERVED

    Complex64   = 0x40,   // 2 x float32
    Complex128  = 0x41,   // 2 x float64  <-- DEFAULT complex
    Complex256  = 0x42,   // RESERVED

    Utf8        = 0x60,   // variable width, Arrow layout: offsets[] + bytes[]
    FixedUtf8   = 0x61,   // fixed width, param = byte length
    Bytes       = 0x62,   // opaque blob

    Date32      = 0x80,   // days since epoch
    Timestamp64 = 0x81,   // param = unit (s/ms/us/ns)
    Duration64  = 0x82,

    Variant     = 0xA0,   // tagged union array (see variant.hpp)
};

// ---------------------------------------------------------------------------
// Capability: is this type readable/writable by THIS build?
// A type may be legal in the format but unimplemented here - we must be able
// to report that instead of silently misreading bytes.
// ---------------------------------------------------------------------------
enum class Support { Native, Emulated, Unimplemented };

Support support_of(TypeId t) noexcept;

const char* type_name(TypeId t) noexcept;

// Byte width of one element, 0 if variable-width or unimplemented.
std::size_t type_width(TypeId t) noexcept;

bool is_bool   (TypeId t) noexcept;
bool is_signed_int(TypeId t) noexcept;
bool is_unsigned_int(TypeId t) noexcept;
bool is_integer(TypeId t) noexcept;
bool is_float  (TypeId t) noexcept;
bool is_complex(TypeId t) noexcept;
bool is_text   (TypeId t) noexcept;
bool is_numeric(TypeId t) noexcept;

// ---------------------------------------------------------------------------
// Promotion lattice:  Null < Bool < Int < UInt-widening < Float < Complex
// Text does NOT join numerics - that pair yields std::nullopt, meaning
// "irreconcilable, use a Variant array". This is the rule that stops a single
// stray string from forcing a 500 GB matrix to be rewritten as UTF-8.
// ---------------------------------------------------------------------------
std::optional<TypeId> promote(TypeId a, TypeId b) noexcept;

// Join over a range; returns nullopt the moment the types are irreconcilable.
std::optional<TypeId> promote_all(const std::vector<TypeId>& ts) noexcept;

// ---------------------------------------------------------------------------
// DType = TypeId + parameters (string width, timestamp unit, ...)
// Self-describing so a future reader can skip what it cannot decode.
// ---------------------------------------------------------------------------
struct DType {
    TypeId        id    = TypeId::Float64;
    std::uint32_t param = 0;       // fixed-string byte width / time unit code
    bool          nullable = false; // carries a validity bitmap

    DType() = default;
    explicit DType(TypeId i, std::uint32_t p = 0, bool n = false)
        : id(i), param(p), nullable(n) {}

    std::string to_string() const;
    bool operator==(const DType& o) const noexcept {
        return id == o.id && param == o.param && nullable == o.nullable;
    }
};

inline constexpr TypeId kDefaultInt     = TypeId::Int64;
inline constexpr TypeId kDefaultReal    = TypeId::Float64;
inline constexpr TypeId kDefaultComplex = TypeId::Complex128;

} // namespace ndat
