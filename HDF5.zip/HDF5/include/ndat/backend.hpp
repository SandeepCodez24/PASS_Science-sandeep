// ============================================================================
//  N-Data - storage backend interface
//
//  N-Data is the LOGICAL spec. HDF5 is backend #1. Arrow IPC / Parquet /
//  netCDF can be added later as exporters without touching this interface
//  or any caller above it.
// ============================================================================
#pragma once

#include "ndat/variable.hpp"
#include <functional>

namespace ndat {

struct WriteOptions {
    std::uint64_t chunk_bytes      = 4ull << 20;  // 4 MB chunks
    int           zstd_level       = 3;           // 0 = off
    bool          shuffle          = true;        // byte-shuffle before compress
    bool          checksum         = true;        // per-chunk Fletcher32
    bool          swmr             = true;        // single-writer/multi-reader
    bool          allow_narrowing  = false;       // only if provably lossless
};

struct FileHeader {
    std::uint16_t major = kFormatMajor;
    std::uint16_t minor = kFormatMinor;
    std::uint16_t min_reader_major = kMinReaderMajor;
    std::string   writer_id = "ndat-cpp/1.0";
    std::int64_t  created_unix = 0;
};

// A slab request: read a hyperslab without materializing the whole dataset.
struct Slab {
    std::vector<std::uint64_t> start;
    std::vector<std::uint64_t> count;
};

class Backend {
public:
    virtual ~Backend() = default;

    virtual void create(const std::string& path, const WriteOptions& opt) = 0;
    virtual void open  (const std::string& path, bool read_only)          = 0;
    virtual void close()                                                  = 0;

    virtual FileHeader header() const = 0;

    // Write (or overwrite) one variable. Returns its dataset path.
    virtual std::string put(const Variable& v, const WriteOptions& opt) = 0;

    virtual void erase(const std::string& name) = 0;

    // Index-only read: cheap, never touches payload.
    virtual std::vector<IndexRecord> index() const = 0;

    // Full materialization - caller is responsible for the memory.
    virtual Variable get(const std::string& name) const = 0;

    // Partial read for big data / plot downsampling.
    virtual Array get_slab(const std::string& name, const Slab& s) const = 0;

    virtual void flush() = 0;

    virtual const char* backend_name() const noexcept = 0;
};

// Factory. kind: "hdf5" (canonical) or "portable" (dependency-free fallback).
std::unique_ptr<Backend> make_backend(const std::string& kind);

} // namespace ndat
