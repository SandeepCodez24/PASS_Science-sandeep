// ============================================================================
//  N-Data - Variable + the explorer index record
//
//  The variable explorer MUST never touch the payload. It reads only
//  IndexRecord, which is a few hundred bytes regardless of whether the
//  variable holds 5 elements or 500 GB.
// ============================================================================
#pragma once

#include "ndat/array.hpp"
#include <variant>
#include <chrono>

namespace ndat {

enum class Container : std::uint8_t {
    Scalar  = 0,
    List    = 1,   // rank 1
    Matrix  = 2,   // rank 2
    Tensor  = 3,   // rank >= 3
    Variant = 4,   // heterogeneous, dense-union layout
};

const char* container_name(Container c) noexcept;

// ---------------------------------------------------------------------------
// Payload: either a dense homogeneous Array or a VariantArray.
// ---------------------------------------------------------------------------
using Payload = std::variant<Array, VariantArray>;

// ---------------------------------------------------------------------------
// Variable - what the executor hands to the workspace.
// ---------------------------------------------------------------------------
struct Variable {
    std::string name;
    Payload     payload;

    Variable(std::string n, Array a)        : name(std::move(n)), payload(std::move(a)) {}
    Variable(std::string n, VariantArray v) : name(std::move(n)), payload(std::move(v)) {}

    bool is_variant() const { return std::holds_alternative<VariantArray>(payload); }

    const Shape& shape() const {
        return is_variant() ? std::get<VariantArray>(payload).shape()
                            : std::get<Array>(payload).shape();
    }
    std::uint64_t nbytes() const {
        return is_variant() ? std::get<VariantArray>(payload).nbytes()
                            : std::get<Array>(payload).nbytes();
    }
    std::string type_label() const {
        return is_variant() ? std::get<VariantArray>(payload).type_label()
                            : std::get<Array>(payload).dtype().to_string();
    }
    Container container() const {
        if (is_variant()) return Container::Variant;
        switch (shape().rank()) {
            case 0:  return Container::Scalar;
            case 1:  return Container::List;
            case 2:  return Container::Matrix;
            default: return Container::Tensor;
        }
    }
};

// ---------------------------------------------------------------------------
// Numeric summary, precomputed at write time so plotting can pick axes limits
// without a full scan of a 200 GB dataset.
// ---------------------------------------------------------------------------
struct Stats {
    bool   valid = false;
    double min   = 0.0;
    double max   = 0.0;
    double mean  = 0.0;
    std::uint64_t null_count = 0;
};

// ---------------------------------------------------------------------------
// IndexRecord - the ONLY thing the variable explorer reads.
// Columns requested: [Name, Value, Size, Datatype].
// ---------------------------------------------------------------------------
struct IndexRecord {
    std::string   name;
    std::string   type_label;      // "float64", "variant<float64|utf8>"
    std::string   size_label;      // "5x5"
    std::string   preview;         // short renderable value, capped
    Container     container   = Container::Scalar;
    Shape         shape;
    std::uint64_t element_count = 0;
    std::uint64_t nbytes        = 0;
    std::string   dataset_path;    // where the payload lives in the backend
    std::uint64_t revision      = 0;   // bumps on every reassignment
    std::int64_t  mtime_unix    = 0;
    Stats         stats;
    bool          plottable     = false;

    // Format-forward-compat: unknown keys a future writer added are kept here
    // verbatim so a round-trip through an older IDE does not destroy them.
    std::vector<std::pair<std::string, std::string>> unknown_attrs;
};

// Build the explorer record from a Variable. previews are capped.
IndexRecord make_index_record(const Variable& v,
                              const std::string& dataset_path,
                              std::uint64_t revision,
                              std::size_t preview_elems = 8);

} // namespace ndat
