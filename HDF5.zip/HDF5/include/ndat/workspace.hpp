// ============================================================================
//  N-Data - Workspace: the API the IDE executor calls.
//
//  Concurrency model (v1): single writer, multiple readers.
//    * One serialized executor thread owns all mutations.
//    * Readers (variable explorer, plot panel) call index()/preview()/get_slab()
//      concurrently under a shared lock.
//    * Line-by-line execution does NOT reopen the file per statement. The
//      in-memory table is source of truth; the backend is flushed on a
//      checkpoint policy (N statements, T milliseconds, or explicit).
// ============================================================================
#pragma once

#include "ndat/backend.hpp"
#include <chrono>
#include <shared_mutex>
#include <unordered_map>

namespace ndat {

struct SessionOptions {
    WriteOptions  write;
    std::string   backend      = "hdf5";   // falls back to "portable"
    std::uint32_t flush_every_n_stmts = 64;
    std::uint32_t flush_every_ms      = 500;
    // Guard from the design discussion: above this element count, an
    // irreconcilable mixed assignment is an error, not a silent 500 GB rewrite.
    std::uint64_t auto_variant_limit  = 0;  // 0 = always variant, never rewrite
};

class Workspace {
public:
    explicit Workspace(SessionOptions o = {});
    ~Workspace();

    void create(const std::string& path);      // new .ndat workspace
    void open  (const std::string& path, bool read_only = false);
    void close();

    // ---- writer side (executor thread only) -------------------------------
    void assign(const std::string& name, Array a);
    void assign(const std::string& name, VariantArray v);
    void remove(const std::string& name);

    // Build a container from heterogeneous elements. This is the entry point
    // for your points 6-8: it computes the promotion join, and if the elements
    // are irreconcilable (a string among floats) it emits a VariantArray
    // instead of rewriting the payload.
    struct Element {
        TypeId      type = TypeId::Float64;
        double      num  = 0.0;
        std::string text;
        bool        is_null = false;
    };
    void assign_mixed(const std::string& name,
                      const std::vector<Element>& elems,
                      const Shape& shape);

    // Explicit checkpoint (end of script, user save, before a long read).
    void checkpoint();

    // ---- reader side (any thread) -----------------------------------------
    std::vector<IndexRecord> explorer_rows() const;   // [Name, Value, Size, Datatype]
    IndexRecord              describe(const std::string& name) const;
    Variable                 fetch(const std::string& name) const;
    Array                    fetch_slab(const std::string& name, const Slab& s) const;

    // Plot helper: never pulls more than max_points from disk.
    Array plot_series(const std::string& name, std::uint64_t max_points = 100000) const;

    const char* backend_name() const;
    FileHeader  header() const;

private:
    void maybe_flush();

    mutable std::shared_mutex           mu_;
    SessionOptions                      opt_;
    std::unique_ptr<Backend>            be_;
    std::unordered_map<std::string, IndexRecord> index_;
    std::uint32_t                       pending_ = 0;
    std::chrono::steady_clock::time_point last_flush_{};
    bool                                open_ = false;
};

} // namespace ndat
