# ==========================================================================================
# 01  save / load / read - NC's own data files (.ndat)
#
#   save(file, data, policy="auto")   write data         (save(file) = the whole workspace)
#   read(file, name="", part="")      get the data back  (one entry, or part of one)
#   load(file)                        open as an object  (D.A, D.B, ... and D.ndat = info)
#   ndat_info(file)                   what a file holds, entry by entry
#   ndat_export(file, name, out)      one entry as its own .h5 / .parquet / .arrow / .csv ...
#
# A name with no extension, or ".ndat", is an NC data bundle. Every entry inside is
# stored the way that suits it best (policy "auto"):
#
#   big numeric matrix / N-D matrix that compresses well  -> HDF5 (chunked, gzip, slices)
#   table with text or true/false columns                  -> Parquet (dictionary + zstd)
#   numeric table                                          -> Arrow IPC (fastest to read)
#   everything else (small data, text, dicts, objects,
#   integer types, complex, timestamps, noise-like data)    -> native NDAT (exact, a copy)
#
# Before writing, each HDF5 / Parquet / Arrow section is checked to read back EXACTLY;
# anything that would not is stored native, so read(save(x)) is always x.
#
# save, load and read are for .ndat files only. Every other format has its own
# functions: save_csv / read_csv / load_csv, save_h5 / read_h5, save_parquet, ...
# (save("t.csv", T) is refused with "for a .csv file use save_csv(...)").
#
# The files are written in the current folder (names start with "ndt_").
# Every check prints PASS or FAIL.
# Run:  nc.exe 01_save_load_read.nc
# ==========================================================================================

function check(label, ok):
   if ok:
      print("PASS  " + label);
   else:
      print("FAIL  " + label);
   iend
fnend

# ==========================================================================================
# 1. One value of any kind comes back exactly
#    save(file, data) stores one entry "data"; read(file) returns the value itself.
# ==========================================================================================
print("---- single values ----");
values = dict();
values["number"] = 3.25;
values["text"] = "Kreyszig, 10th edition";
values["complex"] = 2 - 5i;
values["flag"] = true;
values["small int"] = int8(-7);
values["matrix"] = [1, 2, 3; 4, 5, 6];
values["column"] = [1; 2; 3];
for k = keys(values):
   save("ndt_one", values[k]);
   check(k + " reads back unchanged", read("ndt_one") == values[k]);
fend
N3 = reshape(space(1, 24, 24), [2, 3, 4]);
save("ndt_one", N3);
check("an N-D matrix reads back unchanged", read("ndt_one") == N3);

# ==========================================================================================
# 2. A dict: one entry per key, each stored its own best way
# ==========================================================================================
print("---- a dict of mixed data ----");
run = dict();
run["name"] = "wind tunnel, run 7";
run["smooth"] = reshape(space(0, 1, 120000), [300, 400]);    # compresses well -> hdf5
run["noise"] = nexus_uniform([300, 400]);                    # does not compress -> native
run["settings"] = [0.5, 1.5, 2.5];
bytes = save("ndt_run", run);
print("written:", bytes, "bytes");
info = ndat_info("ndt_run");
E = info["entries"];                     # a table: name, encoding, kind, shape, bytes, note
print(E.name, E.encoding);
# entries are listed in key order: name, noise, settings, smooth
enc = E.encoding;                        # a list of text: enc[0] .. enc[3]
check("only the smooth field is stored as HDF5", enc[3] == "hdf5" && enc[0] == "native" && enc[1] == "native");
check("the whole dict reads back unchanged", read("ndt_run") == run);
check("one entry by name", read("ndt_run", "settings") == [0.5, 1.5, 2.5]);

# ==========================================================================================
# 3. Partial reads
#    read(file, name, "rows, cols") - a slice, NC style 1-based and inclusive
#    (an HDF5 entry reads only the chunks it needs; a native one is cut in memory)
# ==========================================================================================
print("---- slices ----");
S = run["smooth"];
check("slice of the HDF5 entry", read("ndt_run", "smooth", "2:3, 1:4") == S[1:2, 0:3]);
Z = run["noise"];
check("slice of the native entry", read("ndt_run", "noise", "10:12, 5:6") == Z[9:11, 4:5]);

# ==========================================================================================
# 4. Tables
#    - a dict of equal-length columns (each all numbers, all text or all true/false)
#    - the cell matrix read_csv gives, and the table object load_csv gives
#    read(file, name, ["col1", "col2"]) reads only those columns.
# ==========================================================================================
print("---- tables ----");
city = repeat(["north", "south", "east", "west", "centre"], 1000);   # 5000 names
T = dict();
T["station"] = city;
T["temp"] = space(10, 30, 5000);
T["rain"] = space(0, 5, 5000);
save("ndt_table", T);
check("a table with text is stored as Parquet", ndat_info("ndt_table")["entries"].encoding[0] == "parquet");
check("it reads back unchanged", read("ndt_table") == T);
check("one column only: read(file, \"temp\")", read("ndt_table", "temp") == T["temp"]);
N = dict();
N["x"] = space(0, 1, 5000);
N["y"] = space(1, 2, 5000);
save("ndt_numeric", N);
check("a numeric table is stored as Arrow IPC", ndat_info("ndt_numeric")["entries"].encoding[0] == "arrow");
check("it reads back unchanged", read("ndt_numeric") == N);
save_csv("ndt_data.csv", T);             # a CSV file has its own functions
C = read_csv("ndt_data.csv");            # read_csv: a cell matrix
save("ndt_cells", C);
check("read_csv's cell matrix is stored as Parquet", ndat_info("ndt_cells")["entries"].encoding[0] == "parquet");
check("it reads back unchanged", read("ndt_cells") == C);
L = load_csv("ndt_data.csv");            # load_csv: a table object
save("ndt_object", L);
check("load_csv's table object is stored as Parquet", ndat_info("ndt_object")["entries"].encoding[0] == "parquet");
check("it reads back unchanged", read("ndt_object") == L);

# ==========================================================================================
# 5. load(file): an object with one field per entry, plus D.ndat (the ndat_info dict)
# ==========================================================================================
print("---- load ----");
D = load("ndt_run");
check("D.settings", D.settings == run["settings"]);
check("D.name", D.name == run["name"]);
check("D.ndat.version is 2.0", D.ndat["version"] == "2.0");

# ==========================================================================================
# 6. The whole workspace: save(file) with no data, then load_workspace(file) puts every
#    variable back (load(file) would give them as fields of an object instead).
# ==========================================================================================
print("---- workspace ----");
alpha = 41;
beta = "kept";
save("ndt_workspace");
alpha = 0;
beta = "";
load_workspace("ndt_workspace");
check("load_workspace restores the variables", alpha == 41 && beta == "kept");
W = read("ndt_workspace");               # or as a dict of all variables
check("read gives them as a dict", W["alpha"] == 41);

# ==========================================================================================
# 7. Version 1 files (save_workspace) read the same way
# ==========================================================================================
print("---- version 1 files ----");
save_workspace("ndt_v1");
check("read(v1 file, name)", read("ndt_v1", "beta") == "kept");
check("ndat_info says version 1", ndat_info("ndt_v1")["version"] == "1");

# ==========================================================================================
# 8. Named options; other formats use their own functions (save_h5, read_csv, ...)
# ==========================================================================================
print("---- named options and other formats ----");
n = save("ndt_named", N, policy="native");          # the options can be named
check("save(..., policy=\"native\") stores native", ndat_info("ndt_named")["entries"].encoding[0] == "native");
check("read(file, name=\"x\") of a one-dict file gives its key", read("ndt_named", name="x") == N["x"]);
M = reshape(space(1, 12, 12), [3, 4]);
save_h5("ndt_matrix.h5", M);             # other formats: their own functions
check("an HDF5 file is read with read_h5", read_h5("ndt_matrix.h5") == M);

# ==========================================================================================
# 9. ndat_export: one entry as a standalone file. HDF5 / Parquet / Arrow sections are
#    copied byte for byte; anything else is written by that format's save function.
# ==========================================================================================
print("---- ndat_export ----");
ndat_export("ndt_run", "smooth", "ndt_smooth.h5");
check("the exported HDF5 entry reads with read_h5", read_h5("ndt_smooth.h5", "/data") == S);
ndat_export("ndt_table", "data", "ndt_table.parquet");
check("the exported Parquet entry has 5000 rows", load_parquet("ndt_table.parquet").rows == 5000);
ndat_export("ndt_run", "settings", "ndt_settings.json");
J = read_json("ndt_settings.json");            # JSON lists come back as 1-D arrays
check("a native entry is written by save_json", J[0] == 0.5 && J[2] == 2.5);
print("done: 01_save_load_read");
