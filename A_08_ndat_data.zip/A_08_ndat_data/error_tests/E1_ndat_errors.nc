# ========================================================================================
# E1 - error tests: save / load / read and the .ndat functions (01_save_load_read.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error in
# a script, so this file stops at the first block; to see a later block, put # in front
# of the failing lines above it (or run the blocks one by one).
#   expected  - the line nc.exe prints for this call
#   works     - the corrected call
# The setup writes ndt_err.ndat and ndt_err.csv in the current folder.
# ========================================================================================

# ---- setup ----
D = dict();
D["A"] = reshape(space(1, 40000, 40000), [200, 200]);
D["name"] = "run 7";
T = dict();
T["x"] = space(0, 1, 5000);
T["y"] = space(1, 2, 5000);
D["T"] = T;
save("ndt_err", D);
save_csv("ndt_err.csv", T);

# ---- 1 ----
# expected: Error: save: input 'file' was not given and has no default value (usage: save(file, data, policy="auto"))
# works:    n = save("run", D);
n = save();

# ---- 2 ----
# expected: Error: save: the file name must be text in quotes, e.g. save("results", data)
# works:    n = save("run", D);
n = save(5, D);

# ---- 3 ----
# expected: Error: save: the policy must be "auto", "compact", "fast", "native", "hdf5", "parquet" or "arrow" (got "turbo")
# works:    n = save("run", D, "compact");
n = save("run", D, "turbo");

# ---- 4 ----
# expected: Error: save: the policy must be text: "auto", "compact", "fast", "native", "hdf5", "parquet" or "arrow"
# works:    n = save("run", D, "fast");
n = save("run", D, 3);

# ---- 5 ----
# expected: Error: save: it takes 3 inputs, but 4 values were given (usage: save(file, data, policy="auto"))
# works:    n = save("run", D, "auto");
n = save("run", D, "auto", 1);

# ---- 6 ----
# expected: Error: save: there is no input named 'level' - its inputs are file, data, policy (usage: save(file, data, policy="auto"))
# works:    n = save("run", D, policy="compact");
n = save("run", D, level=3);

# ---- 7 ----
# expected: Error: save: save is for NC data files (.ndat) - for a .csv file use save_csv(...)
# works:    n = save_csv("run.csv", T);
n = save("run.csv", T);

# ---- 8 ----
# expected: Error: save: save is for NC data files (.ndat) - give a name without an extension or ending in .ndat
# works:    n = save("run.ndat", D);
n = save("run.xyz", D);

# ---- 9 ----
# expected: Error: save is for NC data files (.ndat) - give a name without an extension or ending in .ndat (other formats have their own save_ functions)
# works:    save("workspace");
save("workspace.mat");

# ---- 10 ----
# expected: Error: read: no such file: <current folder>\no_such_file.ndat
# works:    x = read("ndt_err");
x = read("no_such_file");

# ---- 11 ----
# expected: Error: read: read is for NC data files (.ndat) - for a .csv file use read_csv(...)
# works:    x = read_csv("ndt_err.csv");
x = read("ndt_err.csv");

# ---- 12 ----
# expected: Error: read: no entry 'B' in <current folder>\ndt_err.ndat - it holds A, T, name
# works:    x = read("ndt_err", "A");
x = read("ndt_err", "B");

# ---- 13 ----
# expected: Error: read: the entry name must be text, e.g. read("run.ndat", "A")
# works:    x = read("ndt_err", "A");
x = read("ndt_err", 2);

# ---- 14 ----
# expected: Error: read: entry 'name' is read whole - a part is a slice of a numeric matrix ("1:10, :") or the columns of a table
# works:    x = read("ndt_err", "name");
x = read("ndt_err", "name", "1:2");

# ---- 15 ----
# expected: Error: read: slice "1:500" is outside 1..200
# works:    x = read("ndt_err", "A", "1:5, :");
x = read("ndt_err", "A", "1:500, :");

# ---- 16 ----
# expected: Error: read: a part of tensor 'A' is a slice in quotes, e.g. "1:10, :"
# works:    x = read("ndt_err", "A", "5, :");
x = read("ndt_err", "A", 5);

# ---- 17 ----
# expected: Error: read: table 'T' has no column 'z'
# works:    x = read("ndt_err", "T", "x");
x = read("ndt_err", "T", "z");

# ---- 18 ----
# expected: Error: read: table 'T' has no column '1:5'
# works:    x = read("ndt_err", "T", ["x", "y"]);
x = read("ndt_err", "T", "1:5");

# ---- 19 ----
# expected: Error: load: it takes 1 input, but 2 values were given (usage: load(file))
# works:    L = load("ndt_err");
L = load("ndt_err", "A");

# ---- 20 ----
# expected: Error: load: load is for NC data files (.ndat) - for a .h5 file use load_h5(...)
# works:    L = load_h5("ndt_err.h5");
L = load("ndt_err.h5");

# ---- 21 ----
# expected: Error: ndat_info: <current folder>\ndt_err.csv is not an .ndat file
# works:    i = ndat_info("ndt_err");
i = ndat_info("ndt_err.csv");

# ---- 22 ----
# expected: Error: ndat_export: no entry 'B' in <current folder>\ndt_err.ndat - it holds A, T, name
# works:    e = ndat_export("ndt_err", "A", "A.h5");
e = ndat_export("ndt_err", "B", "B.h5");

# ---- 23 ----
# expected: Error: ndat_export: the entry name and the output file must be text, e.g. ndat_export("run", "A", "A.h5")
# works:    e = ndat_export("ndt_err", "A", "A.h5");
e = ndat_export("ndt_err", "A", 5);

# ---- 24 ----
# expected: Error: ndat_export: cannot write a .xyz file - give the extension of a format with a save_ function (h5, parquet, arrow, csv, json, mat, ...)
# works:    e = ndat_export("ndt_err", "name", "name.json");
e = ndat_export("ndt_err", "name", "name.xyz");
