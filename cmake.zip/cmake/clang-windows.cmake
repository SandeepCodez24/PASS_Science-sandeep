# =============================================================================
#  clang-windows.cmake  —  toolchain file for building nc.exe with the
#  in-house LLVM 21 toolchain (clang++ / lld-link / llvm-ar / ninja).
#
#  Usage (from the repository root, inside a VS 2022 Developer PowerShell):
#     cmake -S src/main/cpp -B build/nc-build -G Ninja `
#           --toolchain cmake/clang-windows.cmake `
#           -DNC_TOOLCHAIN_ROOT="D:/path/to/toolchain" `
#           -DCMAKE_BUILD_TYPE=Release
#
#  NC_TOOLCHAIN_ROOT may also come from the environment variable of the
#  same name. It must point at the folder that contains bin/, lib/,
#  include/ and custom_libs/.
# =============================================================================

# --- Locate the toolchain root ----------------------------------------------
if(NOT NC_TOOLCHAIN_ROOT)
    if(DEFINED ENV{NC_TOOLCHAIN_ROOT})
        set(NC_TOOLCHAIN_ROOT "$ENV{NC_TOOLCHAIN_ROOT}")
    else()
        message(FATAL_ERROR
            "NC_TOOLCHAIN_ROOT is not set. Pass -DNC_TOOLCHAIN_ROOT=<toolchain folder> "
            "or set the NC_TOOLCHAIN_ROOT environment variable.")
    endif()
endif()

file(TO_CMAKE_PATH "${NC_TOOLCHAIN_ROOT}" NC_TOOLCHAIN_ROOT)
set(NC_TOOLCHAIN_ROOT "${NC_TOOLCHAIN_ROOT}" CACHE PATH "Root of the custom LLVM toolchain" FORCE)

# Toolchain files are re-read inside try_compile() projects; forward the root.
list(APPEND CMAKE_TRY_COMPILE_PLATFORM_VARIABLES NC_TOOLCHAIN_ROOT)

set(_nc_bin "${NC_TOOLCHAIN_ROOT}/bin")

foreach(_tool clang.exe clang++.exe lld-link.exe llvm-ar.exe ninja.exe)
    if(NOT EXISTS "${_nc_bin}/${_tool}")
        message(FATAL_ERROR "Toolchain tool not found: ${_nc_bin}/${_tool}")
    endif()
endforeach()

# --- Compilers ----------------------------------------------------------------
# Native Windows build: CMAKE_SYSTEM_NAME is deliberately NOT set, so CMake
# does not switch into cross-compiling mode.
set(CMAKE_C_COMPILER   "${_nc_bin}/clang.exe")
set(CMAKE_CXX_COMPILER "${_nc_bin}/clang++.exe")
set(CMAKE_C_COMPILER_TARGET   x86_64-pc-windows-msvc)
set(CMAKE_CXX_COMPILER_TARGET x86_64-pc-windows-msvc)

# --- Binutils / build tool -------------------------------------------------------
set(CMAKE_AR           "${_nc_bin}/llvm-ar.exe"  CACHE FILEPATH "Archiver"   FORCE)
set(CMAKE_LINKER       "${_nc_bin}/lld-link.exe" CACHE FILEPATH "Linker"     FORCE)
set(CMAKE_MAKE_PROGRAM "${_nc_bin}/ninja.exe"    CACHE FILEPATH "Build tool" FORCE)

# clang++ drives the link step; -fuse-ld=lld makes it call lld-link.exe
# (found next to clang++.exe) instead of Microsoft's link.exe.
#
# -no-canonical-prefixes: by default clang resolves its own location to the
# physical path behind the D: alias (C:\D-Drive\D\...) and launches lld-link
# from there, which Windows refuses ("lld-link: permission denied"). With this
# flag clang keeps the path it was started from (D:\...), so lld-link is
# launched from the same place it runs fine. It must be on the link line too,
# and CMake puts the compile flags on the link line for this compiler.
set(CMAKE_C_FLAGS_INIT   "-no-canonical-prefixes")
set(CMAKE_CXX_FLAGS_INIT "-no-canonical-prefixes")
set(CMAKE_EXE_LINKER_FLAGS_INIT    "-no-canonical-prefixes -fuse-ld=lld")
set(CMAKE_SHARED_LINKER_FLAGS_INIT "-no-canonical-prefixes -fuse-ld=lld")
set(CMAKE_MODULE_LINKER_FLAGS_INIT "-no-canonical-prefixes -fuse-ld=lld")

# --- Bundled libraries ------------------------------------------------------------
# Eigen ships header-only (no Eigen3Config.cmake). These hints serve CMakeLists
# that use EIGEN3_INCLUDE_DIR or an old-style FindEigen3 module.
set(EIGEN3_INCLUDE_DIR "${NC_TOOLCHAIN_ROOT}/custom_libs/eigen3"
    CACHE PATH "Eigen3 header directory (bundled with the toolchain)")
list(APPEND CMAKE_PREFIX_PATH "${NC_TOOLCHAIN_ROOT}/custom_libs/eigen3")

# Optional: make <Eigen/...> visible to every target without touching
# CMakeLists.txt. Enable with -DNC_GLOBAL_EIGEN_INCLUDE=ON only if the
# project's own CMakeLists does not already add the Eigen include path.
option(NC_GLOBAL_EIGEN_INCLUDE "Add bundled Eigen to every target's include path" OFF)
if(NC_GLOBAL_EIGEN_INCLUDE)
    string(APPEND CMAKE_CXX_FLAGS_INIT " -isystem \"${EIGEN3_INCLUDE_DIR}\"")
endif()

# Handy for IDEs/clangd and for checking which compiler was actually used.
set(CMAKE_EXPORT_COMPILE_COMMANDS ON CACHE BOOL "Write compile_commands.json" FORCE)
