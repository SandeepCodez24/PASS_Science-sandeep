reversible class Counter()
    function base(start)
        base.value = start;
    fnend

    function increment()
        base.value = base.value + 1;
    fnend

    function V = get()
        V = base.value;
    fnend
csend

c = Counter(10);
c.increment();
c.increment();
c.increment();
publish("before-rewind:", c.get());

c.rewind();
publish("after-rewind-to-init:", c.get());

c.increment();
c.increment();
c.increment();
c.increment();
publish("before-partial-rewind:", c.get());

c.rewind(2);
publish("after-rewind-2-steps:", c.get());

lineageAfterRewind = c.lineage();
publish("lineage-truncated:", lineageAfterRewind);

c.increment();
publish("fresh-history-after-rewind:", c.get());
publish("fresh-lineage:", c.lineage());

d = Counter(100);
d.increment();
publish("independent-instance-unaffected:", d.get());

class NotReversible():
   function base(v):
      base.v = v;
   fnend
csend

nr = NotReversible(5);
nr.rewind();
publish("after-nonreversible-rewind-attempt");

publish("done");
