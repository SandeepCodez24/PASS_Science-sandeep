######################################################
A = [1,2,3,4,5,6,7,8,9,10];
B = [0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1];
### unit vector 
A1 = unit_vector(A);	\\ --> full Error --> further development
### norm of vector 
B1 = norm(A);	\\ --> full Error --> further development
### direction cosine
C1 = dircos(A); 	\\ --> full Error --> further development
### vector triple product 
D1 = vector_tp(A,A,A);	\\ --> full Error --> further development
### projection of A on B 
E1 = proj(A,B);	\\ --> full Error --> further development
### projection vector 
F1 = proj_vec(A);	\\ --> full Error --> further development
### orthogonal vector 
G1 = orthogonal(A);	\\ --> full Error --> further development
### orthonormal vector 
H1 = orthonormal(A);	\\ --> full Error --> further development
### eigen vector 
I1 = eigen_vector(A);	\\ --> full Error --> further development
### eigen values 
J1 = eigen_value(A);	\\ --> full Error --> further development
### divergence 
k1 = divergence(A);	\\ --> full Error --> further development
### curl 
L1 = curl(A);		\\ --> full Error --> further development
######################################################