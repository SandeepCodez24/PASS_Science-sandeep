#############################################
A = [[2,4,9],[8,6,7],[9,5,9]];
B = [[8,98,625],[18,85,76],[19,35,39]];
C = [[2,4,9,6],[8,6,7,9],[9,5,9,57],[1,2,3,8]];
D = [[2,4,9,6],[8,6,7,9],[9,5,9,57]];
### Rank 
A1 = rank(A);
### Transpose 
B1 = transpose(C);
### conjugate 
C1 = conjugate(C);
### pseudo inverse 
D1 = pseudo_inverse(D);
### Determinant 
E1 = det(C);
### adjoint 
F1 = adj(C);
### hadamard product 
G1 = had_prod(A,B); 
### Inverse 
H1 = inv(C);
### matrix norm 
I1 = norm(C);
### element wise multiplication 
J1 = A.B;  \\ partial error --> further development
### diagonal matrix 
K1 = diag(5);
### upper triangular
L1 = upper_triangular(3);
### Zero matrix 
M1 = zero_matrix(4);
### full rank matrix 
N1 = full_rank_matrix(C);
### singular matrix 
O1 = singular_matrix(C);
### positive definite 
P1 = pd_matrix(C);
### negative definite 
Q1 = nd_matrix(C);
### unit matrix 
R1 = unit_matrix(4);
#############################################
#############################################
\\ publish(A1);
\\ publish(B1);
\\ publish(C1);
\\ publish(D1);
\\ publish(E1);
\\ publish(F1);
\\ publish(G1);
\\ publish(H1);
\\ publish(I1);
\\ publish(J1);
\\ publish(K1);
\\ publish(L1);
\\ publish(M1);
\\ publish(N1);
\\ publish(O1);
\\ publish(P1);
\\ publish(Q1);
\\ publish(R1)
#############################################
#############################################