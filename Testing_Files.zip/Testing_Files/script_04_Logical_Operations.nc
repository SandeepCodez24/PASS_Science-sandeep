A = 1;
B = 1;
C = 2.3;
D = 2.3;
E = 3.2;
F = 2;
##############################
### Print and Publish
publish("You can mention whatever you want..!");
##############################
### if 
if (A==B):
   publish("The 'if' value shold be 1 :",(A==B));
iend
##############################
### for 
α = 0;
for j1 = [1:10]:
   α = α + 1;
fend
publish("The for loop value should be 10 :",α);
##############################
### if not
if not (A==C):
   publish("The 'if not' value shold be 1 :",(A!=C));
iend
##############################
### and 
if (A==B) && (A!=C):
   publish("The '&&' value shold be 1 :",(A==B));
iend
##############################
### or 
if (A==B) || (A==C):
   publish("The '||' value shold be 1 :",(A==B));
iend
##############################
### while 
λ = 0;
while λ <= 99:
   λ = λ + 1;
wend
publish("The while loop should be 100 :",λ); 
##############################
### while not 
τ = 0;
while not (τ==100):
   τ  =τ+1;
wend
publish("The while not loop should be 100 :",τ); 
##############################
#### Equal to
publish("The '==' value should be 1 :",A==B);
##############################
#### Not equal to
publish("The '!=' value should be 1 :",A!=F);     
##############################
### is empty
\\ γ = [];
\\ if is_empty(γ):  \\ --> full Error --> further development
\\    publish("The value should be 1 :",is_empty(γ)); 
\\ iend
##############################
### is Nan
\\ φ = (4/0);
\\ if is_nan(φ):   \\ --> full Error --> further development
\\    publish("The 'nan' value should be 1 :",is_nan(φ));
\\ iend
##############################
### in 
\\ ξ = 51;
\\ GL = [1,2,3,4,5,6,51];
\\ if ξ in GL:      \\ --> full Error --> further development --> "if ξ is_in GL:" is correct. but, 
\\    publish("The 'in' operator value should be 1 :", 51==51);
\\ iend
##############################
### not in 
\\ ψ = 10;
\\ GL2 = [1,2,3,4,5,6,7,8];
\\ if ψ not in GL2:     \\ --> full Error --> further development
\\    publish("The 'not in' operator value should be 1 :", 10==10);
\\ iend
##########################################################
##########################################################