##########################################
### Circle
A1 = char_circle(4);	
### Square
B1 = char_square(4);	
### Triangle 
C1 = char_triangle(3);	
### Rectangle
D1 = char_rectangle(4,1);	
### Pentagon
E1 = char_pentagon(5);
### Hexogen
F1 = char_hexagon(6);	
### Rhombus
G1 = char_rhombus(4,0.5235);	
### Semi circle
H1 = char_semicircle(4);	
### Right Triangle
I1 = char_rtriangle(6,4);	
### polygon
J1 = char_polygon(4,10);	
### Trapezoid
K1 = char_trapezoid(10,6,4);	
### Cube 
L1 = char_cube(4);	
### Sphere
M1 = char_sphere(6);	
### cylinder
N1 = char_cylinder(4,6);	
### cone
O1 = char_cone(4,6);	
### Heptagon
P1 = char_heptagon(8);		
### Nanogon
Q1 = char_nonagon(9);  
### Ellipse 
R1 = char_ellipse(4,1);		
#############################################
 