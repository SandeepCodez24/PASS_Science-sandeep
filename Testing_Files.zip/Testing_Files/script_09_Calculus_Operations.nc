########################################
A = [1,2,3,4,5,6,7,8];
B = [0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1];
C = [0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1];
### Derivative 
A1 = ddt(A,B,C);	\\ --> full Error --> further development
### partial derivative
B1 = pddt(A,B,C);	\\ --> full Error --> further development
### Continuity 
C1 = continuity(A);	\\ --> full Error --> further development
### Gradient 
D1 = grad(A);	\\ --> full Error --> further development
### Curl 
E1 = curl(A);	\\ --> full Error --> further development
### Laplacian 
F1 = laplace(A);	\\ --> full Error --> further development
### Green Theorem
G1 = green_integral(A);	\\ --> full Error --> further development 
### Stokes Theorem 
H1 = stokes_integral(A);   \\ --> full Error --> further development 
### Taylor Series 
I1 = taylor_series(A,B);	\\ --> full Error --> further development
### Radius of convergence 
J1 = rad_of_con(A);	\\ --> full Error --> further development
########################################