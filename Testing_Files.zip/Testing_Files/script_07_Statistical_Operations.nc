################################################
A = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
B = [11,12,13,14,15,16,17,18,19,20,21,22,23,24,25];
### Mean 
A1 = mean(A);		
### median 
B1 = median(A);		
### mode 
C1 = mode(A); 
### geometric mean 
D1 = geo_mean(A);	
### harmonic mean 
E1 = harmo_mean(A);	
### trimmed mean 
F1 = trim_mean(A);	
### variance 
G1 = var(A);	
### Standard Deviation 
H1 = sd(A);	
### Coefficient of Variation 
I1 = coeff_var(A);	
### Skewness 
J1 = skew(A);	
### correlation coefficient
K1 = corr_coeff(A,B);	
### co variance 
L1 = co_var(A,B);	
### least Square Method 
M1 = lsm(A);	
### Null hypothesis
N1 = null_hypo(A);	
### p-value calculation 
O1 = p_val_cal(A);	
### Chi-square  Test 
P1 = chi_test(A,B);	
### normalization 
Q1 = norm(A);	
##########################################################

