for i = [1:10]:
   publish("iteration:", i);
fend

\\ for i = [1:2:100]:
\\    if (i%4) == 0:
\\       publish("iteration:", i);
\\    iend
\\ fend

\\ for i = [1:10]:
\\    if (i%4) != 0:
\\       publish("iteration:", i);
\\    elseif (i%3) == 0:
\\       publish("the multiplies of 3", i);
\\    iend
\\ fend

\\ var = 0;
\\ i = 0;
\\ while i < 10:
\\    i = i + 1;
\\    if (i%5) == 0:
\\       publish("Division of 5:", i);
\\    elseif (i%4) == 0:
\\       publish("Division of 4:", i);
\\    else:
\\       publish("Not divisible by 5 & 4:", i);
\\    iend
\\ wend

i2 = 0;
while not i2 >= 5:
   publish("while not iteration:", i2);
   i2 = i2 + 1;
wend
