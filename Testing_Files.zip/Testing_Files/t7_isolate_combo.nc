a = 5; b = 5; c = 7;
if (a == b)&&(a == c):
   publish("a, b and c are same");
elseif (a == c)||(a == 7):
   publish("a is equal to c or d");
else:
   publish("No condition satisfied");
iend
