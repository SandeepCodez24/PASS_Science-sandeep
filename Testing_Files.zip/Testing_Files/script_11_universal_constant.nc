##################################################
############## Universal Constants ###############
### pi 
𝝅 = 0; \\ partial error --> need to define 
### gravity 
𝒈 = 0;
### Gas constant
𝑹 = 0; 
### Avogadro Number
\\ \con(\
### Plank's Constant 
ℏ = 0;
### Gravitational Constant 
𝒈 = 0; # G 
### Stefan–Boltzmann Constant  
𝑹∞ = 0; 
### Coulomb Constant 
𝒄 = 0;
### Electron Mass 
𝒎ₑ = 0;
### Proton Mass
𝒎ₚ = 0;
### neutron mass 
𝒎ₙ = 0;
### Molar Mass Constant
𝑴 = 0;
### Electron Charge
𝒌ₑ = 0;
### farade constant
𝑭 = 0; 
##################################################



