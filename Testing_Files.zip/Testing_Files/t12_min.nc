Akey = ["a", "b"];
Bvalue = ["1", "2"];
A = dict(Akey: Bvalue);
publish("before");
Keys = A.keys();
publish("after");
A = unit_matrix(5)