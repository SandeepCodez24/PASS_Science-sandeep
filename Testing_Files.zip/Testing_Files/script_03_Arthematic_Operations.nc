A = 1;
B = 2;
C = 3.1;
D = 2.3;
###################################
### Addition
A1 = A+B;
A2 = C+D;
### Subtraction
B1 = A-B;
B2 = C-D;
### multiplication 
C1 = A*B;
C2 = C*D;
### Division 
D1 = A/B;
D2 = C/D;
### square root 
E1 = sqrt(144.0);
E2 = sqrt(2.3);
### cube root 
F1 = cbrt(225.01);
F2 = cbrt(343);
###Square and cube;
G1 = sqr(44);
G2 = cube(7.0);
#### power value 
H1 = 2^4;
H2 = 343^0.333;
H3 = 343^(1/3); 
### factorial
I1 = 5!; 
I2 = 6!;        
### Quotient 
J1 = 5//2;
J2 = 12354//12.34;    
### Remainder
K1 = 5%3;
\\ K2 = 123.35%2.364;       ### --> further development
######################################################
### Logarithmic
L1 = log(1);
L2 = log(2.356);
### Exponential
M1 = e^0;
M2 = e^2.3245;  
### Log base “n” 
N1 = logb2(8);
\\ N2 = logb6(6);  ### --> further development
### Absolute
O1 = |-5|;
O2 = |-2.3|;    ### --> further development
### Fraction to decimal
P1 = frac2deci(1/235);
P2 = frac2deci(1/2);    
### Decimal to fraction
Q1 = deci2frac(0.25);
Q2 = deci2frac(0.534);    
######################################################
######################################################