a = 5; b = 5; c = 7;
if (a == b)&&(a == c):
   publish("branch1");
else:
   publish("branch2-else");
iend
