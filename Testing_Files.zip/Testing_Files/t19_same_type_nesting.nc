for i = [1:2]:
    for j = [1:2]:
        publish("for-for:", i, j);
    fend
fend

a = 0;
while a < 2:
   a = a + 1;
    b = 0;
    while b < 2:
        b = b + 1;
        publish("while-while:", a, b);
    wend
wend

for i = [1:2]:
    if i == 1:
        if i == 1:
            publish("if-if-true:", i);
        iend
    else:
        publish("if-else:", i);
    iend
fend

publish("done");
