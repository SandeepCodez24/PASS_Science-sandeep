##############################################
### sine 
A1 = sin(3.143); 
### Cosine
B1 = cos(0);
### Tangent 
C1 = tan(0.785398);
### Cosecant 
D1 = cosec(0.785398);
### Secant 
E1 = sec(1.44);
### Cotangent 
F1 = cot(0.78);
### inverse sine
G1 = inv_sin(0.1);
### inverse cosine
H1 = inv_cos(0.324); 
### inverse tangent
I1 = inv_tan(0.785398);
### inverse cosecant
J1 = inv_cosec(1.44);  
### inverse secant
K1 = inv_sec(0.785398); 
### inverse cotangent 
L1 = inv_cot(0.24587);  
### hyperbolic sine 
M1 = sinh(3.14245);
### hyperbolic cosine
N1 = cosh(1.552);
### hyperbolic tangent
O1 = tanh(1.000);
### hyperbolic cosecant
P1 = cosech(3.14245);  
### hyperbolic secant
Q1 = sech(3.14245);     
### hyperbolic cotangent 
R1 = coth(0.78);         
#########################################

S1 = A1*B1*C1;
S2 = sin(0.785398)*cos(0.785398); \\ partial error
S3 = A1*B1*C1*D1*E1*F1*G1*H1;



