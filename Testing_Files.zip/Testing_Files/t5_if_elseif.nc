a = 5; b = 5; c = 7;
if a == b:
   publish("both are same");
iend

if a != b:
   publish("both are not same");
iend

A = [1,2,3];
if a is_in A:
   publish("yes..! it is present.");
iend

if a is_not_in A:
   publish("no..! it is not present.");
iend

\\ if a == b:
\\    publish("both are same");
\\ else:
\\    publish("both are not same");
\\ iend

\\ if a == b:
\\    publish("a and b are same");
\\ elseif a == c:
\\    publish("a and c are same");
\\ else:
\\    publish("No matching found..!");
\\ iend

if not (a == c):
   publish("a is not c (if not works)");
iend

\\ if (a == b)&&(a == c):
\\    publish("a, b and c are same");
\\ elseif (a == c)||(a == 7):
\\    publish("a is equal to c or d");
\\ else:
\\    publish("No condition satisfied");
\\ iend
