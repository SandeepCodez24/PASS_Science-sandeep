a = 1; b = 2; c = 3; d = 4; e = 5; f = 6; g = 7; h = 8; y=10; x = 20000; z = 300000; w =2300;
publish(a, b, c, d, e, f, g, h,y,x,z,w);
publish(a, b, c, d, "India", f, g, h);
\\ Motto = "Nature includes everything around us like trees, animals, ~~
\\ rivers, and mountains that is not made by people.";
\\ publish(Motto);
