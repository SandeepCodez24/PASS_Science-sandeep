package ui.editor.step;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import language.folding.FoldingRangeFinder;
import language.folding.FoldingRangeFinder.FoldRange;

/**
 * Splits a script's text into an ordered list of {@link StepUnit}s for the
 * Step feature.
 *
 * <p>
 * One whole block ({@code if}/{@code for}/{@code while}/{@code function}/
 * {@code class}, start-to-terminator) becomes one unit — reusing
 * {@link FoldingRangeFinder} verbatim rather than a second block detector,
 * per the confirmed granularity decision (the interpreter can't pause
 * mid-block, so a block is the smallest steppable unit once it's opened).
 * A plain statement is one unit, extended across {@code ~~}-continued
 * physical lines (matching the interpreter's own {@code readLogicalLine}
 * convention — sending a continued line's pieces as separate steps would
 * leave the REPL blocked mid-statement waiting for the rest). Blank lines
 * and comment-only lines are skipped entirely and never consume a step
 * (comment syntax taken from the authoritative
 * {@code language.syntax.UPITokenMaker.COMMENT_PATTERN}: {@code #...} or a
 * literal two-backslash {@code \\...} prefix).
 */
public final class StepPlanner {

    private StepPlanner() {
        // Utility class
    }

    public static List<StepUnit> plan(String text) {
        List<StepUnit> units = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return units;
        }

        String[] lines = text.split("\\R", -1);
        Map<Integer, FoldRange> rangesByStart = new HashMap<>();
        for (FoldRange range : FoldingRangeFinder.find(text)) {
            rangesByStart.put(range.startLine, range);
        }

        int i = 0;
        while (i < lines.length) {
            String trimmed = lines[i].trim();
            if (trimmed.isEmpty() || isComment(trimmed)) {
                i++;
                continue;
            }

            FoldRange range = rangesByStart.get(i);
            if (range != null) {
                units.add(new StepUnit(range.startLine, range.endLine));
                i = range.endLine + 1;
                continue;
            }

            int start = i;
            int end = i;
            while (endsWithContinuation(lines[end]) && end + 1 < lines.length) {
                end++;
            }
            units.add(new StepUnit(start, end));
            i = end + 1;
        }

        return units;
    }

    private static boolean isComment(String trimmed) {
        return trimmed.startsWith("#") || trimmed.startsWith("\\\\");
    }

    private static boolean endsWithContinuation(String line) {
        return rtrim(line).endsWith("~~");
    }

    private static String rtrim(String s) {
        int end = s.length();
        while (end > 0 && Character.isWhitespace(s.charAt(end - 1))) {
            end--;
        }
        return s.substring(0, end);
    }
}
