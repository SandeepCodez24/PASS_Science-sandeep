package ui.editor.step;

/**
 * One contiguous physical-line range of a script, treated as a single
 * indivisible "step": either a whole block ({@code if}/{@code for}/
 * {@code while}/{@code function}/{@code class}, start-to-terminator) or a
 * single plain statement (possibly spanning several physical lines via
 * {@code ~~} continuation). See {@link StepPlanner}.
 */
public final class StepUnit {

    /** 0-indexed, inclusive. */
    public final int startLine;
    /** 0-indexed, inclusive. */
    public final int endLine;

    public StepUnit(int startLine, int endLine) {
        this.startLine = startLine;
        this.endLine = endLine;
    }

    /** Joins this unit's lines from {@code rawLines} with real newlines. */
    public String extractRaw(String[] rawLines) {
        StringBuilder sb = new StringBuilder();
        for (int i = startLine; i <= endLine && i < rawLines.length; i++) {
            if (i > startLine) {
                sb.append('\n');
            }
            sb.append(rawLines[i]);
        }
        return sb.toString();
    }
}
