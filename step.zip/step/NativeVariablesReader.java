package ui.editor.step;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import ui.ui_functions.Variable;

/**
 * Reads the C++ interpreter's own {@code variables.txt} (format confirmed by
 * reading {@code Parser::saveToFile()}/{@code loadFromFile()} in
 * {@code runtime/memory/store/variable_store.cpp} directly, not guessed)
 * into the same {@link Variable} POJO the Variable Explorer table already
 * displays.
 *
 * <p>
 * Deliberately distinct from {@code IDEVariableService}'s reader, which
 * parses a completely different Java-side {@code .dict} format written by
 * {@code VariableFileWriter} — that format shares nothing with this one.
 *
 * <p>
 * Known, expected gaps (interpreter-side, not fixed here): class instances
 * and function/class definitions are never written to {@code variables.txt}
 * at all ({@code saveToFile()} explicitly skips {@code isObject} values), so
 * they never appear here either. A {@code for} loop's own freshly-introduced
 * iterator variable is also never persisted (written to the interpreter's
 * memory map without a matching insertion-order entry), so it won't appear
 * here unless the same name already existed before the loop.
 */
public final class NativeVariablesReader {

    private NativeVariablesReader() {
        // Utility class
    }

    public static List<Variable> read(Path variablesTxt) {
        List<Variable> result = new ArrayList<>();
        if (variablesTxt == null || !Files.isReadable(variablesTxt)) {
            return result;
        }

        List<String> lines;
        try {
            lines = Files.readAllLines(variablesTxt, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return result;
        }

        for (String rawLine : lines) {
            if (rawLine.isBlank()) {
                continue;
            }
            String line = rawLine.trim();
            if (line.startsWith("NAME") || line.startsWith("---")) {
                continue; // header line / dashed separator, both written unconditionally
            }

            int nameEnd = firstWhitespace(line, 0);
            if (nameEnd < 0) {
                continue;
            }
            int typeStart = skipWhitespace(line, nameEnd);
            int typeEnd = firstWhitespace(line, typeStart);
            if (typeEnd < 0) {
                continue;
            }
            int valueStart = skipWhitespace(line, typeEnd);

            String name = line.substring(0, nameEnd);
            String type = line.substring(typeStart, typeEnd);
            String rawValue = valueStart < line.length() ? line.substring(valueStart) : "";

            Variable v = toVariable(name, type, rawValue);
            if (v != null) {
                result.add(v);
            }
        }

        return result;
    }

    private static Variable toVariable(String name, String type, String rawValue) {
        switch (type) {
            case "NUM":
                return new Variable(name, rawValue, "1", "double");
            case "STR":
                return new Variable(name, rawValue, String.valueOf(rawValue.length()), "string");
            case "ARR": {
                int count = countTopLevelElements(stripOuter(rawValue));
                return new Variable(name, rawValue, String.valueOf(count), "array");
            }
            case "MAT": {
                String inner = stripOuter(rawValue);
                int rows = countChar(inner, '[');
                int cols = rows > 0 ? countTopLevelElements(firstBracketed(inner)) : 0;
                return new Variable(name, rawValue, rows + "x" + cols, "matrix");
            }
            case "DICT": {
                int count = countChar(rawValue, '[');
                return new Variable(name, rawValue, String.valueOf(count), "dict");
            }
            default:
                // Unknown/future type tag from a newer interpreter build — skip rather than guess.
                return null;
        }
    }

    /** Strips one leading '[' and one trailing ']' if present, else returns the input unchanged. */
    private static String stripOuter(String s) {
        if (s.length() >= 2 && s.charAt(0) == '[' && s.charAt(s.length() - 1) == ']') {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    /** The substring between the first '[' and its matching ']' (not included). Empty if none. */
    private static String firstBracketed(String s) {
        int start = s.indexOf('[');
        if (start < 0) {
            return "";
        }
        int end = s.indexOf(']', start + 1);
        return end < 0 ? "" : s.substring(start + 1, end);
    }

    /** Counts comma-separated top-level elements (respecting "quoted" text), 0 for a blank/empty body. */
    private static int countTopLevelElements(String body) {
        if (body.isEmpty()) {
            return 0;
        }
        int commas = 0;
        boolean inQuotes = false;
        for (int i = 0; i < body.length(); i++) {
            char c = body.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                commas++;
            }
        }
        return commas + 1;
    }

    private static int countChar(String s, char target) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == target) {
                count++;
            }
        }
        return count;
    }

    private static int firstWhitespace(String s, int from) {
        for (int i = from; i < s.length(); i++) {
            if (Character.isWhitespace(s.charAt(i))) {
                return i;
            }
        }
        return -1;
    }

    private static int skipWhitespace(String s, int from) {
        int i = from;
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
            i++;
        }
        return i;
    }
}
