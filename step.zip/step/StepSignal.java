package ui.editor.step;

import java.util.concurrent.CompletableFuture;

/**
 * Single-pending-token completion channel between the stdout-reader thread
 * (which sees the interpreter's {@code @STEPMARK <token>} line) and
 * {@link StepController} (which is waiting for exactly one step to finish).
 * Step is one-at-a-time by construction — the button is busy-guarded while a
 * step is in flight — so at most one token is ever pending.
 */
public final class StepSignal {

    private static volatile String pendingToken;
    private static volatile CompletableFuture<Void> pendingFuture;

    private StepSignal() {
        // Utility class
    }

    /** Registers a wait for {@code token}; call this before sending the step's commands. */
    public static synchronized CompletableFuture<Void> awaitToken(String token) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        pendingToken = token;
        pendingFuture = future;
        return future;
    }

    /** Called from the interpreter's stdout-reader thread when {@code @STEPMARK <token>} arrives. */
    public static synchronized void onMarkerReceived(String token) {
        if (pendingFuture != null && token.equals(pendingToken)) {
            CompletableFuture<Void> future = pendingFuture;
            pendingToken = null;
            pendingFuture = null;
            future.complete(null);
        }
    }

    /** Unblocks any in-flight wait early (wired into Stop) instead of leaving the caller to time out. */
    public static synchronized void cancelPending(String reason) {
        if (pendingFuture != null) {
            CompletableFuture<Void> future = pendingFuture;
            pendingToken = null;
            pendingFuture = null;
            future.completeExceptionally(new java.util.concurrent.CancellationException(reason));
        }
    }
}
