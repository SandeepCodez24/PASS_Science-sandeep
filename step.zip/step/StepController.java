package ui.editor.step;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.fxmisc.richtext.CodeArea;

import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import ui.UI_Main;
import ui.editor.EditorErrorHandler;
import ui.editor.EditorFileInfo;
import ui.editor.EditorTextOperations;
import ui.managers.EditorManager;
import ui.managers.LanguageDesignManager;
import ui.ribbon_interface.tool_groups.RibbonAnalysis;
import ui.ui_functions.UI_MainProgramControl;
import ui.ui_functions.Variable;
import language.semantic.SemanticEncoder;

/**
 * Orchestrates the "Step" ribbon button: executes the open .nc script one
 * {@link StepUnit} at a time against the same persistent nc.exe REPL "Run"
 * already drives, using the {@code @cmd stepmark}/{@code @STEPMARK}
 * handshake ({@link StepSignal}) to know precisely when each step finishes,
 * then refreshes the Variable Explorer from the interpreter's real
 * {@code variables.txt} ({@link NativeVariablesReader}) and the current-line
 * gutter highlight.
 */
public final class StepController {

    /** A step can legitimately be a large loop running synchronously in one C++ call. */
    private static final long STEP_TIMEOUT_SECONDS = 30;

    private static volatile boolean busy = false;

    private StepController() {
        // Utility class
    }

    public static void onStepClicked(UI_Main ide, Button stepButton) {
        if (busy) {
            return;
        }

        Tab tab = ide.editorTabs == null ? null : ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab == null) {
            ide.console.appendText("No file open to step through.\n");
            return;
        }

        EditorFileInfo info = tab.getUserData() instanceof EditorFileInfo i ? i : null;
        if (info == null || info.path == null) {
            ide.console.appendText("Cannot step an unsaved file. Please save it once first.\n");
            return;
        }
        if (!"nc".equalsIgnoreCase(info.ext) && !info.path.toString().endsWith(".nc")) {
            ide.console.appendText("Step is only supported for Neural Code (.nc) files.\n");
            return;
        }

        CodeArea editor = EditorTextOperations.getCodeArea(tab);
        if (editor == null) {
            return;
        }
        String text = editor.getText();

        boolean freshSession = !info.stepSessionActive || !text.equals(info.stepSourceSnapshot);
        if (freshSession) {
            startFreshSession(ide, tab, info, text);
        }

        if (info.stepIndex >= info.stepUnits.size()) {
            if (!info.stepEndMessageShown) {
                ide.console.appendText("Step: reached end of file.\n");
                info.stepEndMessageShown = true;
            }
            return;
        }

        runNextUnit(ide, tab, info, editor, text, stepButton);
    }

    private static void startFreshSession(UI_Main ide, Tab tab, EditorFileInfo info, String text) {
        info.stepUnits = StepPlanner.plan(text);
        info.stepIndex = 0;
        info.stepSourceSnapshot = text;
        info.stepSessionActive = true;
        info.stepCurrentUnitStart = -1;
        info.stepCurrentUnitEnd = -1;
        info.stepEndMessageShown = false;

        if (info.path.getParent() != null) {
            EditorManager.sendCommandToTerminal(ide, "@cmd setpwd \"" + info.path.getParent() + "\"");
        }

        if (!ide.isProgramRunning()) {
            EditorManager.startUPITerminal(ide);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ignored) {
            }
        }

        // The interpreter's own existing workspace reset (truncates variables.txt,
        // reloads the live REPL parser) — same command UI_MainProgramControl's
        // existing clear-workspace path already sends, no new reset protocol needed.
        EditorManager.sendCommandToTerminal(ide, "clear");

        UI_MainProgramControl.clearVariableExplorerState(ide);
        RibbonAnalysis.reset();

        CodeArea editor = EditorTextOperations.getCodeArea(tab);
        if (editor != null) {
            EditorErrorHandler.refreshStepHighlight(editor, tab);
        }
    }

    private static void runNextUnit(UI_Main ide, Tab tab, EditorFileInfo info, CodeArea editor,
            String text, Button stepButton) {
        StepUnit unit = info.stepUnits.get(info.stepIndex);
        String raw = unit.extractRaw(text.split("\\R", -1));
        String cleaned = LanguageDesignManager.preprocess(raw);
        String replaced = LanguageDesignManager.applySymbolReplacements(cleaned);
        String payload = SemanticEncoder.encode(replaced);

        busy = true;
        if (stepButton != null) {
            stepButton.setDisable(true);
        }

        String token = "step-" + System.nanoTime();
        CompletableFuture<Void> future = StepSignal.awaitToken(token);

        EditorManager.sendCommandToTerminal(ide, payload);
        EditorManager.sendCommandToTerminal(ide, "@cmd stepmark " + token);

        long startNanos = System.nanoTime();

        future.orTimeout(STEP_TIMEOUT_SECONDS, TimeUnit.SECONDS).whenComplete((v, err) -> Platform.runLater(() -> {
            if (err == null) {
                onStepUnitFinished(ide, tab, info, editor, unit, startNanos, stepButton);
                return;
            }

            if (err instanceof CancellationException) {
                // Stop already reset the session and messaged the user; just release the button.
                busy = false;
                if (stepButton != null) {
                    stepButton.setDisable(false);
                }
                return;
            }

            UI_MainProgramControl.appendErrorText(ide,
                    "✖ Step timed out waiting for the interpreter — it may be stuck mid-block "
                            + "(check for a missing iend/fend/wend/fnend/csend). Click Stop to recover.\n");
            // Deliberately left busy/disabled: the REPL is presumed wedged in block
            // accumulation, so sending another step would just compound the problem.
        }));
    }

    private static void onStepUnitFinished(UI_Main ide, Tab tab, EditorFileInfo info, CodeArea editor,
            StepUnit unit, long startNanos, Button stepButton) {
        info.stepIndex++;
        info.stepCurrentUnitStart = unit.startLine;
        info.stepCurrentUnitEnd = unit.endLine;

        if (editor != null) {
            EditorErrorHandler.refreshStepHighlight(editor, tab);
        }

        Path variablesTxt = Path.of(System.getProperty("user.dir"), "src", "main", "cpp", "variables.txt");
        List<Variable> vars = NativeVariablesReader.read(variablesTxt);
        ide.varTable.getItems().setAll(vars);

        RibbonAnalysis.setComputationCount(info.stepIndex);
        RibbonAnalysis.setExecutionTimeMillis((System.nanoTime() - startNanos) / 1_000_000.0);

        busy = false;
        if (stepButton != null) {
            stepButton.setDisable(false);
        }
    }

    /** Called from EditorFileRunner right after a Run starts — Run mutates the shared workspace. */
    public static void onRunStarted(EditorFileInfo info) {
        if (info == null) {
            return;
        }
        info.stepSessionActive = false;
        info.stepUnits = null;
        info.stepIndex = 0;
        info.stepCurrentUnitStart = -1;
        info.stepCurrentUnitEnd = -1;
        info.stepEndMessageShown = false;
    }

    /** Called from the Stop button — the interpreter process is about to be killed outright. */
    public static void onStop(UI_Main ide) {
        StepSignal.cancelPending("Program stopped.");
        busy = false;

        if (ide.editorTabs == null) {
            return;
        }
        Tab tab = ide.editorTabs.getSelectionModel().getSelectedItem();
        if (tab != null && tab.getUserData() instanceof EditorFileInfo info) {
            onRunStarted(info);
            CodeArea editor = EditorTextOperations.getCodeArea(tab);
            if (editor != null) {
                EditorErrorHandler.refreshStepHighlight(editor, tab);
            }
        }
    }
}
