#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = int(A+C);
A2 = int(A-C); 
A3 = int(A*D);
A4 = int(A/D); 
A5 = int(sqrt(A+E)); 
A6 = int(cbrt(A+D)); 
A7 = int(sqr(A+B)); 
A8 = int(cube(A+B)); 
A9 = int((A+B)^(C+D)); 
A10 = int((P+Q)!); 
A11 = int((A+R)//(A+P)); 
A12 = int((A+R)%(A+P));  
A13 = int(log(A+P)); 
A14 = int(e^(A+B));  
A15 = int(logb4(A+P));  
A16 = int(|A+P/(A+R)|);
#########################################################
#########################################################
publish("Addition             :", int(A+C) ==A1);
publish("Subtraction          :", int(A-C)==A2);
publish("Multiplication       :", int(A*D)==A3);
publish("Division             :", int(A/D)==A4);
publish("Square Root of       :", int(sqrt(A+E))==A5);
publish("Cube Root of         :", int(cbrt(A+D))==A6);
publish("Square of            :", int(sqr(A+B))==A7);
publish("Cube of              :", int(cube(A+B))==A8);
publish("Power                :", int((A+B)^(C+D))==A9);  
publish("Factorial            :", int((P+Q)!) ==A10); 
publish("Quotient Division    :", int((A+R)//(A+P))==A11);
publish("Remainder            :", int((A+R)%(A+P))==A12);
publish("Natural Logarithm    :", int(log(A+P))==A13);
publish("Exponential          :", int(e^(A+B))==A14);   
publish("Logarithm Base 4     :", int(logb4(A+P))==A15);
publish("Modulus              :", int(|A+P/(A+R)|)==A16);
#######################################################
#######################################################