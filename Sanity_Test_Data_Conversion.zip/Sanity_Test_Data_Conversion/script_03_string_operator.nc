#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = str(A+C);
A2 = str(A-C); 
A3 = str(A*D);
A4 = str(A/D); 
A5 = str(sqrt(A+E)); 
A6 = str(cbrt(A+D)); 
A7 = str(sqr(A+B)); 
A8 = str(cube(A+B)); 
A9 = str((A+B)^(C+D)); 
A10 = str((P+Q)!); 
A11 = str((A+R)//(A+P)); 
A12 = str((A+R)%(A+P));  
A13 = str(log(A+P)); 
A14 = str(e^(A+B));  
A15 = str(logb4(A+P));  
A16 = str(|A+P/(A+R)|);
#########################################################
#########################################################
publish("Addition             :", str(A+C) ==A1);
publish("Subtraction          :", str(A-C)==A2);
publish("Multiplication       :", str(A*D)==A3);
publish("Division             :", str(A/D)==A4);
publish("Square Root of       :", str(sqrt(A+E))==A5);
publish("Cube Root of         :", str(cbrt(A+D))==A6);
publish("Square of            :", str(sqr(A+B))==A7);
publish("Cube of              :", str(cube(A+B))==A8);
publish("Power                :", str((A+B)^(C+D))==A9);  
publish("Factorial            :", str((P+Q)!) ==A10); 
publish("Quotient Division    :", str((A+R)//(A+P))==A11);
publish("Remainder            :", str((A+R)%(A+P))==A12);
publish("Natural Logarithm    :", str(log(A+P))==A13);
publish("Exponential          :", str(e^(A+B))==A14);    
publish("Logarithm Base 4     :", str(logb4(A+P))==A15);
publish("Modulus              :", str(|A+P/(A+R)|)==A16);
#######################################################
#######################################################