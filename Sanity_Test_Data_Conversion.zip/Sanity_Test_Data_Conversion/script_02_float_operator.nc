#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = float(A+C);
A2 = float(A-C); 
A3 = float(A*D);
A4 = float(A/D); 
A5 = float(sqrt(A+E)); 
A6 = float(cbrt(A+D)); 
A7 = float(sqr(A+B)); 
A8 = float(cube(A+B)); 
A9 = float((A+B)^(C+D)); 
A10 = float((P+Q)!); 
A11 = float((A+R)//(A+P)); 
A12 = float((A+R)%(A+P));  
A13 = float(log(A+P)); 
A14 = float(e^(A+B));  
A15 = float(logb4(A+P));  
A16 = float(|A+P/(A+R)|);
#########################################################
#########################################################
publish("Addition             :", float(A+C) ==A1);
publish("Subtraction          :", float(A-C)==A2);
publish("Multiplication       :", float(A*D)==A3);
publish("Division             :", float(A/D)==A4);
publish("Square Root of       :", float(sqrt(A+E))==A5);
publish("Cube Root of         :", float(cbrt(A+D))==A6);
publish("Square of            :", float(sqr(A+B))==A7);
publish("Cube of              :", float(cube(A+B))==A8);
publish("Power                :", float((A+B)^(C+D))==A9);  
publish("Factorial            :", float((P+Q)!) ==A10); 
publish("Quotient Division    :", float((A+R)//(A+P))==A11);
publish("Remainder            :", float((A+R)%(A+P))==A12);
publish("Natural Logarithm    :", float(log(A+P))==A13);
publish("Exponential          :", float(e^(A+B))==A14);    
publish("Logarithm Base 4     :", float(logb4(A+P))==A15);
publish("Modulus              :", float(|A+P/(A+R)|)==A16);
#######################################################
#######################################################