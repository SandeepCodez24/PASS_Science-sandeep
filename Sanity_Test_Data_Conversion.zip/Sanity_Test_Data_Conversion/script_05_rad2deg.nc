#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = rad2dec(A+C);
A2 = rad2dec(A-C); 
A3 = rad2dec(A*D);
A4 = rad2dec(A/D); 
A5 = rad2dec(sqrt(A+E)); 
A6 = rad2dec(cbrt(A+D)); 
A7 = rad2dec(sqr(A+B)); 
A8 = rad2dec(cube(A+B)); 
A9 = rad2dec((A+B)^(C+D)); 
A10 = rad2dec((P+Q)!); 
A11 = rad2dec((A+R)//(A+P)); 
A12 = rad2dec((A+R)%(A+P));  
A13 = rad2dec(log(A+P)); 
A14 = rad2dec(e^(A+B));  
A15 = rad2dec(logb4(A+P));  
A16 = rad2dec(|A+P/(A+R)|);
#########################################################
#########################################################
publish("Addition             :", rad2dec(A+C) ==A1);
publish("Subtraction          :", rad2dec(A-C)==A2);
publish("Multiplication       :", rad2dec(A*D)==A3);
publish("Division             :", rad2dec(A/D)==A4);
publish("Square Root of       :", rad2dec(sqrt(A+E))==A5);
publish("Cube Root of         :", rad2dec(cbrt(A+D))==A6);
publish("Square of            :", rad2dec(sqr(A+B))==A7);
publish("Cube of              :", rad2dec(cube(A+B))==A8);
publish("Power                :", rad2dec((A+B)^(C+D))==A9);  
publish("Factorial            :", rad2dec((P+Q)!) ==A10); 
publish("Quotient Division    :", rad2dec((A+R)//(A+P))==A11);
publish("Remainder            :", rad2dec((A+R)%(A+P))==A12);
publish("Natural Logarithm    :", rad2dec(log(A+P))==A13);
publish("Exponential          :", rad2dec(e^(A+B))==A14);    
publish("Logarithm Base 4     :", rad2dec(logb4(A+P))==A15);
publish("Modulus              :", rad2dec(|A+P/(A+R)|)==A16);
#######################################################
#######################################################