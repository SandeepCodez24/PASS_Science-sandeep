#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = round(A+C,3);
A2 = round(A-C,3); 
A3 = round(A*D,3);
A4 = round(A/D,3); 
A5 = round(sqrt(A+E),3); 
A6 = round(cbrt(A+D),3); 
A7 = round(sqr(A+B),3); 
A8 = round(cube(A+B),3); 
A9 = round((A+B)^(C+D),3); 
A10 = round((P+Q)!,3); 
A11 = round((A+R)//(A+P),3); 
A12 = round((A+R)%(A+P),3);  
A13 = round(log(A+P),3); 
A14 = round(e^(A+B),3);  
A15 = round(logb4(A+P),3);  
A16 = round(|A+P/(A+R)|,3);
#########################################################
#########################################################
publish("Addition             :", round(A+C,3) ==A1);
publish("Subtraction          :", round(A-C,3)==A2);
publish("Multiplication       :", round(A*D,3)==A3);
publish("Division             :", round(A/D,3)==A4);
publish("Square Root of       :", round(sqrt(A+E),3)==A5);
publish("Cube Root of         :", round(cbrt(A+D),3)==A6);
publish("Square of            :", round(sqr(A+B),3)==A7);
publish("Cube of              :", round(cube(A+B),3)==A8);
publish("Power                :", round((A+B)^(C+D),3)==A9);  
publish("Factorial            :", round((P+Q)!,3) ==A10); 
publish("Quotient Division    :", round((A+R)//(A+P),3)==A11);
publish("Remainder            :", round((A+R)%(A+P),3)==A12);
publish("Natural Logarithm    :", round(log(A+P),3)==A13);
publish("Exponential          :", round(e^(A+B),3)==A14);    
publish("Logarithm Base 4     :", round(logb4(A+P),3)==A15);
publish("Modulus              :", round(|A+P/(A+R)|,3)==A16);
#######################################################
#######################################################