#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = dec2rad(A+C);
A2 = dec2rad(A-C); 
A3 = dec2rad(A*D);
A4 = dec2rad(A/D); 
A5 = dec2rad(sqrt(A+E)); 
A6 = dec2rad(cbrt(A+D)); 
A7 = dec2rad(sqr(A+B)); 
A8 = dec2rad(cube(A+B)); 
A9 = dec2rad((A+B)^(C+D)); 
A10 = dec2rad((P+Q)!); 
A11 = dec2rad((A+R)//(A+P)); 
A12 = dec2rad((A+R)%(A+P));  
A13 = dec2rad(log(A+P)); 
A14 = dec2rad(e^(A+B));  
A15 = dec2rad(logb4(A+P));  
A16 = dec2rad(|A+P/(A+R)|);
#########################################################
#########################################################
publish("Addition             :", dec2rad(A+C) ==A1);
publish("Subtraction          :", dec2rad(A-C)==A2);
publish("Multiplication       :", dec2rad(A*D)==A3);
publish("Division             :", dec2rad(A/D)==A4);
publish("Square Root of       :", dec2rad(sqrt(A+E))==A5);
publish("Cube Root of         :", dec2rad(cbrt(A+D))==A6);
publish("Square of            :", dec2rad(sqr(A+B))==A7);
publish("Cube of              :", dec2rad(cube(A+B))==A8);
publish("Power                :", dec2rad((A+B)^(C+D))==A9);  
publish("Factorial            :", dec2rad((P+Q)!) ==A10); 
publish("Quotient Division    :", dec2rad((A+R)//(A+P))==A11);
publish("Remainder            :", dec2rad((A+R)%(A+P))==A12);
publish("Natural Logarithm    :", dec2rad(log(A+P))==A13);
publish("Exponential          :", dec2rad(e^(A+B))==A14);    
publish("Logarithm Base 4     :", dec2rad(logb4(A+P))==A15);
publish("Modulus              :", dec2rad(|A+P/(A+R)|)==A16);
#######################################################
#######################################################