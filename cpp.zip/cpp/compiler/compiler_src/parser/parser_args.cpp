// Matching a call's values to a function's inputs: default values in a
// header (function y = F(a, b=2, c="car")), named values in a call
// (F(c="bus", 1)), and choosing between overloads once both exist. See the
// "Matching a call's values" block in parser.h for the rules; this file is
// the only place they are implemented, for plain functions, constructors,
// methods and parent(...) alike.
#include "parser.h"
#include "parser_internal.h"

#include "arg_binding.h"

#include <iostream>

/* ================= SOURCE TEXT OF A DEFAULT ================= */

namespace {

std::string quoted(const std::string &text) {
  std::string out = "\"";
  for (char ch : text) {
    switch (ch) {
    case '"': out += "\\\""; break;
    case '\\': out += "\\\\"; break;
    case '\n': out += "\\n"; break;
    case '\t': out += "\\t"; break;
    case '\r': out += "\\r"; break;
    default: out += ch;
    }
  }
  return out + "\"";
}

} // namespace

std::string tokensToSource(const std::vector<Token> &toks, size_t from, size_t to) {
  std::string out;
  bool prevOpensGroup = true; // nothing written yet: no space
  bool prevIsUnarySign = false;
  TokenType prevType = END;
  for (size_t i = from; i < to && i < toks.size(); i++) {
    const Token &t = toks[i];
    std::string piece;
    if (t.type == STRING)
      piece = quoted(t.text);
    else if (t.type == NUMBER && t.isBool)
      piece = t.text == "1" ? "true" : "false";
    else if (t.type == NUMBER && t.imaginary)
      piece = t.text + "i";
    else
      piece = t.text;

    // Whether the token before this one ends a value (so a '-' here is
    // binary, and a '|' here closes |x|).
    const bool valueBefore = prevType == NUMBER || prevType == IDENT || prevType == STRING ||
                             prevType == RPAREN || prevType == RBRACKET ||
                             prevType == TRANSPOSE || (prevType == PIPE && !prevOpensGroup);
    const bool closingBar = t.type == PIPE && valueBefore;
    const bool closes = t.type == RPAREN || t.type == RBRACKET || t.type == RBRACE ||
                        t.type == COMMA || t.type == SEMICOLON || t.type == COLON ||
                        t.type == TRANSPOSE || closingBar || (t.type == FACT && i > from);
    const bool callOrIndex = (t.type == LPAREN || t.type == LBRACKET) && prevType == IDENT;
    const bool afterDot = prevType == DOT || t.type == DOT;
    if (!out.empty() && !prevOpensGroup && !prevIsUnarySign && !closes && !callOrIndex &&
        !afterDot)
      out += ' ';
    out += piece;

    // A '-' / '+' / '!' with no value before it is a sign: no space after.
    prevIsUnarySign = (t.type == MINUS || t.type == PLUS || t.type == FACT) && !valueBefore;
    prevOpensGroup = t.type == LPAREN || t.type == LBRACKET || t.type == LBRACE ||
                     t.type == AT || (t.type == PIPE && !closingBar);
    prevType = t.type;
  }
  return out;
}

/* ================= PARSING A CALL'S ARGUMENTS ================= */

bool Parser::parseCallArgs(std::vector<std::unique_ptr<Expr>> &args,
                           std::vector<std::string> &argNames, bool colonSeparates) {
  bool anyNamed = false;
  while (current().type != RPAREN && current().type != END && current().type != SEMICOLON) {
    // `name = value`: a name directly followed by a single '='. ('==' is
    // its own token, so F(x == 1) is still a comparison.) Nothing else in
    // an argument list can start this way - a bare assignment is never an
    // expression - so this reading can never take away a valid program.
    std::string argName;
    if (current().type == IDENT && pos + 1 < tokens.size() && tokens[pos + 1].type == ASSIGN) {
      const Token nameTok = current();
      argName = nameTok.text;
      advance(); // the name
      advance(); // '='
      anyNamed = true;
      if (current().type == COMMA || current().type == RPAREN || current().type == END ||
          current().type == SEMICOLON) {
        std::cerr << "✖ Syntax Error";
        if (nameTok.line)
          std::cerr << " (line " << nameTok.line << ", col " << nameTok.col << ")";
        std::cerr << ": '" << argName << " =' needs a value after it\n";
        syntaxErrorCount_++;
        evaluationSucceeded_ = false;
        return false;
      }
    }
    auto argNode = parseOrNode();
    if (!argNode)
      return false;
    args.push_back(std::move(argNode));
    argNames.push_back(argName);
    if (current().type == COMMA)
      advance();
    else if (colonSeparates && current().type == COLON)
      advance();
    else
      break;
  }
  if (!anyNamed)
    argNames.clear(); // all plain: the shape every older call has
  return true;
}

/* ================= BINDING ONE VERSION ================= */

const std::vector<std::string> &Parser::noArgNames() {
  static const std::vector<std::string> empty;
  return empty;
}

// The matching rule itself lives in core/arg_binding.h, shared with the
// built-in functions, so NC functions and built-ins can never disagree on
// it. This only describes an NC function's inputs in that form.
bool Parser::planBinding(const FunctionDef &def, size_t argCount,
                         const std::vector<std::string> &argNames, ArgBinding &out,
                         std::string &why) {
  std::vector<ncargs::Param> params;
  params.reserve(def.inputNames.size());
  for (size_t i = 0; i < def.inputNames.size(); i++)
    params.push_back({def.inputNames[i],
                      def.hasDefault(i) ? ncargs::ParamKind::Defaulted
                                        : ncargs::ParamKind::Required});
  ncargs::Binding binding;
  if (!ncargs::bind(params, argCount, argNames, binding, why))
    return false;
  out.sourceOf = std::move(binding.sourceOf);
  out.defaultsUsed = binding.defaultsUsed;
  return true;
}

/* ================= CHOOSING BETWEEN VERSIONS ================= */

std::string Parser::signatureText(const std::string &name, const FunctionDef &def) {
  std::string out;
  if (def.outputNames.size() == 1) {
    out = def.outputNames[0] + " = ";
  } else if (def.outputNames.size() > 1) {
    out = "[";
    for (size_t i = 0; i < def.outputNames.size(); i++)
      out += (i > 0 ? ", " : "") + def.outputNames[i];
    out += "] = ";
  }
  out += name + "(";
  for (size_t i = 0; i < def.inputNames.size(); i++) {
    if (i > 0)
      out += ", ";
    out += def.inputNames[i];
    if (def.hasDefault(i))
      out += "=" + def.inputDefaultTexts[i];
  }
  return out + ")";
}

const Parser::FunctionDef *Parser::resolveOverload(const std::vector<FunctionDef> &overloads,
                                                   const std::string &label,
                                                   const std::string &sigName, size_t argCount,
                                                   const std::vector<std::string> &argNames,
                                                   std::string &err, ArgBinding *outBinding,
                                                   bool *outAmbiguous) {
  if (outAmbiguous)
    *outAmbiguous = false;
  const FunctionDef *best = nullptr;
  ArgBinding bestBinding;
  std::vector<const FunctionDef *> tied;
  std::string onlyWhy;

  for (const auto &def : overloads) {
    ArgBinding binding;
    std::string why;
    if (!planBinding(def, argCount, argNames, binding, why)) {
      if (overloads.size() == 1)
        onlyWhy = why;
      continue;
    }
    if (!best || binding.defaultsUsed < bestBinding.defaultsUsed) {
      best = &def;
      bestBinding = binding;
      tied.assign(1, &def);
    } else if (binding.defaultsUsed == bestBinding.defaultsUsed) {
      tied.push_back(&def);
    }
  }

  if (best && tied.size() > 1) {
    // Defensive: a binding that succeeds uses (inputs - values given)
    // defaults, and two versions with the same number of inputs cannot
    // both exist (the later one replaces the earlier - registerOverload),
    // so two versions never tie today. Kept so a future rule that lets
    // them coexist reports the clash instead of silently picking one.
    err = "this call to " + label + " fits more than one version equally well: ";
    for (size_t i = 0; i < tied.size(); i++)
      err += (i > 0 ? ", " : "") + signatureText(sigName, *tied[i]);
    err += " - name the inputs, or give more values, to say which one";
    if (outAmbiguous)
      *outAmbiguous = true;
    return nullptr;
  }
  if (!best) {
    if (overloads.size() == 1) {
      err = label + ": " + onlyWhy + " (defined as " + signatureText(sigName, overloads[0]) + ")";
    } else {
      err = "no version of " + label + " fits this call; it has ";
      for (size_t i = 0; i < overloads.size(); i++)
        err += (i > 0 ? ", " : "") + signatureText(sigName, overloads[i]);
    }
    return nullptr;
  }
  if (outBinding)
    *outBinding = bestBinding;
  return best;
}

const Parser::FunctionDef *Parser::findOverload(const std::vector<FunctionDef> &overloads,
                                                size_t argCount) {
  std::string unused;
  return resolveOverload(overloads, "", "", argCount, noArgNames(), unused);
}
