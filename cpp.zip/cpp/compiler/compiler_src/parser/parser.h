#pragma once

#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "token.h"
#include "value.h"

class Parser {
public:
  Parser();

  void setTokens(const std::vector<Token> &t);

  Value parse();

  // Block-terminator recognition, shared by ScriptManager/SM_stage_02.cpp, main.cpp's
  // REPL loop, and executeBlockLines() so the accepted keyword sets can't
  // drift out of sync between the three call sites. `lower` must already be
  // trimmed and lower-cased.
  static bool isIfTerm(const std::string &lower);
  static bool isForTerm(const std::string &lower);
  static bool isWhileTerm(const std::string &lower);

  // For-loop block accumulation: called by ScriptManager to feed body lines
  bool inForBlock() const { return inForBlock_; }
  void feedForLine(const std::string &line) { pendingForBlock_ += line + "\n"; }
  Value executeForBlock();

  // If-statement block accumulation
  bool inIfBlock() const { return inIfBlock_; }
  void feedIfLine(const std::string &line) {
    if (inElseBranch_) pendingIfFalseBlock_ += line + "\n";
    else if (inElseifBranch_ && !pendingElseifBranches_.empty())
      pendingElseifBranches_.back().second += line + "\n";
    else pendingIfTrueBlock_ += line + "\n";
  }
  void setElseBranch() { inElseBranch_ = true; }
  // headerLine is the raw "elseif <cond>" text (original case), re-lexed and
  // evaluated by executeIfBlock() when the true-branch condition is false.
  void setElseifBranch(const std::string &headerLine) {
    pendingElseifBranches_.push_back({headerLine, std::string()});
    inElseifBranch_ = true;
  }
  Value executeIfBlock();

  // While-loop block accumulation
  bool inWhileBlock() const { return inWhileBlock_; }
  void feedWhileLine(const std::string &line) { pendingWhileBlock_ += line + "\n"; }
  Value executeWhileBlock();

  // Function definition block accumulation — registers into functionTable_
  // when the block closes; unlike if/for/while this does NOT execute
  // anything (a function body only runs when called).
  static bool isFunctionTerm(const std::string &lower);
  bool inFunctionBlock() const { return inFunctionBlock_; }
  void feedFunctionLine(const std::string &line) { pendingFunctionBlock_ += line + "\n"; }
  Value executeFunctionDefEnd();

  // Class definition block accumulation — registers into classTable_ when
  // the block closes (never executes anything, same as functions). A class
  // body is itself a sequence of nested `function...fnend` method blocks
  // (one of which, named `base`, is the constructor) — feedClassLine() just
  // accumulates the whole body as flat text; executeClassDefEnd() (in
  // parser_class.cpp) is what scans it for the nested method boundaries.
  static bool isClassTerm(const std::string &lower);
  bool inClassBlock() const { return inClassBlock_; }
  void feedClassLine(const std::string &line) { pendingClassBlock_ += line + "\n"; }
  Value executeClassDefEnd();

  // Recursive block execution helper
  Value executeBlockLines(const std::vector<std::string> &lines);

  // True (and clears the signal) if a top-level `return;` — or, now, a
  // failed `require`/`ensure` — asked execution to stop here. Inside a
  // function/method/loop body this is already fully handled by
  // executeBlockLines()/invokeFunctionBody(); this accessor exists
  // specifically for the *outermost* script/REPL scope, which those never
  // reach (top-level lines are dispatched directly by ScriptManager/
  // main.cpp, not through executeBlockLines). Must be called after every
  // top-level line regardless of whether the caller acts on a true result,
  // since leaving a stale signal set would corrupt a later, unrelated
  // for/while loop's first-iteration check.
  bool consumeTopLevelStopSignal() {
    bool stop = (loopSignal_ != LoopSignal::None);
    loopSignal_ = LoopSignal::None;
    return stop;
  }

private:
  std::vector<Token> tokens;

  size_t pos = 0;

  std::unordered_map<std::string, Value> memory;

  std::vector<std::string> insertionOrder;

  // MATLAB-style `ans` update policy: only update on successful expression
  // evaluation. This flag is set to false inside parseFactor() error paths.
  bool evaluationSucceeded_ = true;

  // For-loop block accumulation state
  bool inForBlock_ = false;
  std::string pendingForBlock_;   // accumulates full for...loop end text
  std::string forHeader_;         // the "for i = [0:5]" header line

  // While-loop block accumulation state
  bool inWhileBlock_ = false;
  std::string pendingWhileBlock_;
  std::string whileHeader_;

  // If-statement block accumulation state
  bool inIfBlock_ = false;
  bool inElseBranch_ = false;
  bool inElseifBranch_ = false;
  bool ifConditionResult_ = false;
  std::string pendingIfTrueBlock_;
  std::string pendingIfFalseBlock_;
  // Each entry: (raw "elseif <cond>" header text, accumulated body text)
  std::vector<std::pair<std::string, std::string>> pendingElseifBranches_;

  // break/continue/return: loopDepth_ tracks how many enclosing for/while
  // loops are currently executing (incremented/decremented around each
  // loop's iteration phase in executeForBlock/executeWhileBlock), so
  // parseStatement() can reject a break/continue with no enclosing loop at
  // parse time instead of needing leak-detection after the fact (return
  // isn't gated by this — it's valid anywhere in a function body). loopSignal_
  // carries the request up through executeBlockLines() (which stops
  // processing the current block and returns as soon as it's set) until the
  // nearest enclosing executeForBlock/executeWhileBlock iteration consumes
  // and clears Break/Continue, or the enclosing function call consumes
  // Return (see callUserFunction/callUserFunctionMulti in parser_function.cpp).
  enum class LoopSignal { None, Break, Continue, Return };
  LoopSignal loopSignal_ = LoopSignal::None;
  int loopDepth_ = 0;

  // Function definition block accumulation state (mirrors for/while above).
  bool inFunctionBlock_ = false;
  std::string pendingFunctionBlock_;
  std::string functionHeader_;   // the "function B = square(A)" header line

  struct FunctionDef {
    std::vector<std::string> inputNames;
    std::vector<std::string> outputNames;  // empty = no declared output
    std::vector<std::string> bodyLines;
  };
  // Polymorphism (overloading): each name maps to every declared arity of
  // it, e.g. two `function B = combine(...)` with different input counts.
  // Resolved by argument count at call time (findOverload) — this language
  // has no parameter type annotations, so arity is the only axis overload
  // resolution can go on.
  std::unordered_map<std::string, std::vector<FunctionDef>> functionTable_;

  // Registers `def` under `name` in `table`: replaces an existing overload
  // of the same arity in place (redefinition), otherwise appends a new one.
  // Shared by executeFunctionDefEnd() (functionTable_) and the class-body
  // method scan in executeClassDefEnd() (a ClassDef's methods map).
  void registerOverload(std::unordered_map<std::string, std::vector<FunctionDef>> &table,
                         const std::string &name, FunctionDef def);

  // Returns the overload in `overloads` whose inputNames.size() == argCount,
  // or nullptr if none matches. Shared by callUserFunction/
  // callUserFunctionMulti and the bare-no-parens-call fallback in
  // parser_factor.cpp (which looks for a zero-arg overload specifically).
  static const FunctionDef *findOverload(const std::vector<FunctionDef> &overloads,
                                          size_t argCount);

  // Parses one "function ..." header line (the 4 declaration shapes — single
  // output, parenthesized multi-output, has-output-no-input, no-output-
  // has-input, and the fully bare no-output-no-input form) into a name and a
  // FunctionDef (bodyLines left empty — the caller attaches those). Shared
  // by executeFunctionDefEnd() (registers into functionTable_) and
  // executeClassDefEnd() (registers into a ClassDef's methods map) so the
  // header grammar lives in exactly one place. Prints its own error and
  // returns false on a malformed header.
  bool parseFunctionHeader(const std::string &headerLine, std::string &outName,
                            FunctionDef &outDef);

  // >0 while executing inside a function/method call's local scope —
  // saveToFile() becomes a no-op so local variables never get written to
  // the persistent global variables.txt mid-call.
  int suppressPersistence_ = 0;

  // The class whose own `methods` map the currently-running method/
  // constructor body was found in (via findMethodInChain, parser_class.cpp)
  // — empty when not currently running as any class's method (e.g. a plain
  // function call, or top-level script code). See invokeFunctionBody's
  // comment above for why this is distinct from `base`'s className.
  std::string currentDefiningClass_;

  // Shared invocation core for callUserFunction/callUserFunctionMulti
  // (parser_function.cpp) and the class-call machinery (parser_class.cpp):
  // binds args into a fresh local scope, runs the body, and returns that
  // scope's final memory map for the caller to pull the declared output
  // name(s) (and, for a method/constructor call, the mutated `base`) out
  // of. Swaps `memory`/loop state/tokens+pos out and back in around the
  // call so recursion, nested loops/break/continue, and a call nested
  // inside another call's argument list all work correctly and never leak
  // across the call boundary. `selfValue`, when non-null, seeds `base` in
  // the fresh local scope before the body runs — this is the only
  // difference between a plain function call and a method/constructor call.
  // `definingClassName`, when non-empty, sets currentDefiningClass_ for the
  // duration of the call — the class whose *own* methods map the running
  // code was actually found in via findMethodInChain(), as opposed to
  // `base`'s className (the instance's dynamic type) — these diverge under
  // inheritance (e.g. a Base-defined method running because a Derived
  // instance called it without overriding it). This is what parent(...)
  // resolves relative to and what checkFieldAccess() bases private/
  // protected enforcement on.
  bool invokeFunctionBody(const FunctionDef &def, const std::vector<Value> &args,
                           std::unordered_map<std::string, Value> &outScope,
                           const Value *selfValue = nullptr,
                           const std::string &definingClassName = std::string());

  // Single-output/void call path (parser_factor.cpp: IDENT(...) and bare
  // no-input-no-output IDENT). `found` is false iff `name` isn't a
  // registered user function at all (caller falls back to callBuiltin()).
  Value callUserFunction(const std::string &name, const std::vector<Value> &args, bool &found);

  // Multi-output call path (parser_statement.cpp: (B1,B2) = name(...)).
  std::vector<Value> callUserFunctionMulti(const std::string &name,
                                            const std::vector<Value> &args,
                                            size_t expectedOutputs, bool &found);

  // Class definition block accumulation state (mirrors function above).
  bool inClassBlock_ = false;
  std::string pendingClassBlock_;
  std::string classHeader_;   // the "class Reading()" header line

  struct ClassDef {
    // Includes the constructor under the reserved name "base" — a
    // constructor is just a method with no declared output whose mutated
    // `base` scope IS the newly-created instance (see callClassConstructor
    // in parser_class.cpp). Each name maps to every declared arity of it
    // (overloading — see functionTable_'s comment above; methods and
    // constructors get this "for free" via the same registerOverload/
    // findOverload machinery).
    std::unordered_map<std::string, std::vector<FunctionDef>> methods;

    // Encapsulation: fields declared `private`/`protected` (e.g.
    // `private mean, std;`). Presence in this map means the field is
    // restricted; the bool distinguishes protected(true)/private(false) for
    // when inheritance eventually gives them different meaning — for now
    // both are enforced identically (see the access checks in
    // parser_factor.cpp/parser_statement.cpp). A field never mentioned here
    // is public, matching the class skeleton's original all-public behavior.
    std::unordered_map<std::string, bool> restrictedFields;

    // Inheritance: `class Child(Parent)` — empty means no parent. Only ever
    // *stored* here, never resolved at registration time, so a parent class
    // may legally be defined later in the file (same forward-reference
    // guarantee functions/classes already have) — resolution happens lazily
    // via findMethodInChain()/isClassOrSubclassOf() at actual call time.
    std::string parentClassName;

    // Abstraction: `abstract class Name(...)`. An abstract class can't be
    // instantiated directly; a method/constructor overload declared with no
    // body (fnend immediately after the header) inside it is a required-
    // override contract — see validateConcreteInstantiation().
    bool isAbstract = false;

    // Reversibility: `reversible class Name(...)`. Opt-in per the design
    // doc's own recommendation (full snapshotting has real memory/perf
    // cost) — only instances of a class marked this way get a field-state
    // snapshot pushed to Value::snapshots on construction/each method call,
    // enabling `.rewind()`. A non-reversible class's instances never pay
    // that cost.
    bool isReversible = false;

    // Temporal Determinism: `class Name() @rate(500Hz) ... csend`. Purely
    // metadata — this interpreter has no real scheduler/dataflow engine (the
    // design doc itself says this pillar "should land alongside the
    // multi-rate scheduler work, not before it"), so honoring it is scoped
    // to what's actually achievable here: the reserved `.tick(currentTime)`
    // call (parser_factor.cpp) only actually runs the class's `step()`
    // method when enough simulated time has passed since the instance's
    // last tick, per this rate. No implicit/automatic scheduling of any
    // kind — the caller drives simulated time explicitly.
    bool hasRate = false;
    double rateHz = 0.0;
  };
  std::unordered_map<std::string, ClassDef> classTable_;

  // Walks className's chain looking for the nearest class (className itself
  // or an ancestor) with its own `@rate(...)` — same inheritance semantics
  // as everything else in this feature set (a subclass with no rate of its
  // own inherits its ancestor's). False if no class in the chain has one.
  bool findRateInChain(const std::string &className, double &outRateHz);

  // Called by callClassConstructor() before actually instantiating
  // `className`. Returns false (having already printed the specific error
  // and set evaluationSucceeded_) if `className` itself is abstract, or if
  // any abstract ancestor's bodyless method/constructor contract isn't
  // satisfied by a real (non-empty-body) implementation somewhere in
  // className's own resolvable chain — checked here, at instantiation time,
  // rather than at className's own registration time, because (matching
  // every other resolution in this feature set) a forward-referenced
  // abstract ancestor might not even be registered yet when className
  // itself is registered.
  bool validateConcreteInstantiation(const std::string &className);

  // Walks className's own chain (className, then its parent, then its
  // parent's parent, ...) looking for an overload of methodName matching
  // argCount — checking a class's own methods before its parent's is what
  // makes override "just work" with no special-casing (a class's own
  // matching-arity overload wins even if an ancestor also has one; if only
  // the *name* exists at this level but not that arity, the walk continues
  // up rather than stopping, so an ancestor's differently-sized overload is
  // still reachable). Returns the class the method was actually found in
  // (outDefiningClass — see invokeFunctionBody's comment for why that
  // matters) and its FunctionDef. False if no matching overload exists
  // anywhere in the chain, including if the chain dangles on a parent class
  // name that was never actually registered.
  bool findMethodInChain(const std::string &className, const std::string &methodName,
                          size_t argCount, std::string &outDefiningClass, FunctionDef &outDef);

  // True if methodName exists *by name* anywhere in className's chain,
  // regardless of arity — used only to produce a more precise error
  // ("no overload takes N arguments" vs. "no such method") when
  // findMethodInChain fails.
  bool methodNameExistsInChain(const std::string &className, const std::string &methodName);

  // True if `candidate` IS `ancestor` or inherits from it (directly or
  // transitively) — the basis for `protected` reaching into subclasses (see
  // checkFieldAccess).
  bool isClassOrSubclassOf(const std::string &candidate, const std::string &ancestor);

  // `parent(args)` — chains into the parent (relative to
  // currentDefiningClass_) class's constructor, running it against the
  // *current*, already-partially-built `base` (not a fresh instance) and
  // merging the result back into memory["base"]. Reserved call name,
  // intercepted by text in parser_factor.cpp's IDENT(...) branch rather
  // than being a token (same precedent as `new`/`clear`).
  Value callParentConstructor(const std::vector<Value> &args);

  // Constructor call — `ClassName(args)` in an expression position
  // (parser_factor.cpp). Seeds a fresh empty object as `base` (className
  // set to the class actually being instantiated — the dynamic type stays
  // fixed even when the constructor that runs was found higher up the
  // chain), runs the constructor body, and returns the mutated `base` as
  // the new instance. `found` is false iff `className` isn't a registered
  // class at all.
  Value callClassConstructor(const std::string &className, const std::vector<Value> &args,
                              bool &found);

  // Encapsulation check, shared by the object field-read branch
  // (parser_factor.cpp) and the field-assignment branch
  // (parser_statement.cpp). Returns true if accessing `fieldName` on an
  // instance of `className` is allowed from the current execution context;
  // otherwise prints the "field is private/protected" error, sets
  // evaluationSucceeded_ = false, and returns false. A field never declared
  // private/protected is always allowed (the default, backward-compatible
  // case). "Current context" is self-access if `base` is bound to an
  // instance of the *same* class right now — true both for base.field
  // itself and, incidentally, another same-class instance's field read
  // from inside a method (e.g. `other.field` where other is a same-class
  // argument) — not just the literal identifier `base`.
  bool checkFieldAccess(const std::string &className, const std::string &fieldName);

  // Instance method call — `obj.Method(args)` (parser_factor.cpp, when the
  // receiver is an object). Runs with `base` seeded to `selfBefore`; returns
  // the method's declared output (or Value(0) if void) as the call result,
  // and separately hands back the mutated instance via `outSelfAfter` so the
  // caller can write it back into the variable that held the receiver —
  // mutating a method's `base.field` must persist across future calls on
  // the same instance. `found` is false iff the class has no such method.
  Value callInstanceMethod(const Value &selfBefore, const std::string &methodName,
                            const std::vector<Value> &args, Value &outSelfAfter, bool &found);

  Token current();

  void advance();

  void loadFromFile();

  void saveToFile();

  Value parseStatement();

  Value parseFor();

  Value parseOr();

  Value parseAnd();

  Value parseComparison();

  Value parseExpression();

  Value parseTerm();

  Value parsePower();

  Value parseFactor();
};