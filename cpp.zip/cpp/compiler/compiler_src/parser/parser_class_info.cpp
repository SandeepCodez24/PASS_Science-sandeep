// Class introspection - the reserved `.base` and `.info` after a dot:
//
//   ClassName.base   {field: type}   what the constructor sets up, with each
//                                    field's type worked out from its code
//   obj.base         {field: value}  an instance's actual fields
//   ClassName.info   {class, parent, count, functions}
//                                    every function callable on the class
//   obj.info         the same as ClassName.info for obj's class
//
// See the "Class introspection" block in parser.h for the full contract.
// Nothing here runs any of the class's own code: ClassName.base reads the
// constructor's statements, it never calls the constructor.
#include "parser.h"

#include <functional>
#include <iostream>
#include <set>
#include <sstream>

#include "../builtins/constants_builtin.h"
#include "output.h"

namespace {

using Dict = std::unordered_map<std::string, Value>;

/* ---- type names ----
   The same words as the conversion functions (int32(x), float32(x),
   string(x), dict(...), bool(x) ...), so a type shown here can be typed
   back in to make a value of it. */

const char *intTypeName(IntType t) {
  switch (t) {
  case IntType::Int8: return "int8";
  case IntType::Int16: return "int16";
  case IntType::Int32: return "int32";
  case IntType::Int64: return "int64";
  case IntType::UInt8: return "uint8";
  case IntType::UInt16: return "uint16";
  case IntType::UInt32: return "uint32";
  case IntType::UInt64: return "uint64";
  case IntType::None: break;
  }
  return "int";
}

std::string valueTypeName(const Value &v) {
  if (v.isObject)
    return v.className();
  if (v.isFunctionRef)
    return "function";
  if (v.isDict)
    return "dict";
  if (v.isText)
    return "string";
  if (v.isMatrix)
    return "matrix";
  if (v.isArray)
    return "array";
  if (v.isComplex)
    return "complex";
  if (v.isBool())
    return "bool";
  if (v.isInt())
    return intTypeName(v.intType());
  switch (v.floatType()) {
  case FloatType::Float8: return "float8";
  case FloatType::Float16: return "float16";
  case FloatType::Float32: return "float32";
  case FloatType::Float64: break;
  }
  return "float64";
}

// A call whose result type is fixed by its name, whatever it is given.
const char *conversionResultType(const std::string &name) {
  static const char *const exact[] = {"int8",   "int16",   "int32",   "int64",  "uint8",
                                      "uint16", "uint32",  "uint64",  "float8", "float16",
                                      "float32", "float64", "bool",   "string", "dict",
                                      "complex"};
  for (const char *t : exact)
    if (name == t)
      return t;
  if (name == "str")
    return "string";
  if (name == "float")
    return "float64";
  return nullptr;
}

// Joins two guesses for the same field: equal stays, "any" absorbs
// everything, different concrete types read "float64 or string".
std::string mergeTypes(const std::string &a, const std::string &b) {
  if (a.empty() || a == b)
    return b;
  if (a == "any" || b == "any")
    return "any";
  std::set<std::string> parts;
  auto split = [&](const std::string &s) {
    size_t start = 0;
    while (true) {
      size_t at = s.find(" or ", start);
      parts.insert(s.substr(start, at == std::string::npos ? std::string::npos : at - start));
      if (at == std::string::npos)
        break;
      start = at + 4;
    }
  };
  split(a);
  split(b);
  std::string out;
  for (const auto &p : parts)
    out += (out.empty() ? "" : " or ") + p;
  return out;
}

Value textArray(const std::vector<std::string> &items) {
  std::vector<Value> out;
  for (const auto &s : items)
    out.emplace_back(s);
  return Value(std::move(out));
}

// Finds a parent(...) call anywhere in an expression tree.
bool containsParentCall(const Expr *e) {
  if (!e)
    return false;
  if (e->kind == ExprKind::ParentCall)
    return true;
  for (const auto &c : e->children)
    if (containsParentCall(c.get()))
      return true;
  return containsParentCall(e->rangeStart.get()) || containsParentCall(e->rangeStop.get()) ||
         containsParentCall(e->rangeStep.get());
}

const Expr *findParentCall(const Expr *e) {
  if (!e)
    return nullptr;
  if (e->kind == ExprKind::ParentCall)
    return e;
  for (const auto &c : e->children)
    if (const Expr *found = findParentCall(c.get()))
      return found;
  return nullptr;
}

} // namespace

/* ================= CONSTANT VALUES ================= */

namespace {

// True when `e` gives the same value wherever and whenever it is
// evaluated: literals, operators, named constants (pi) and the conversion
// functions over those. Only such an expression is evaluated by .base/.info.
bool isConstantExpr(const Expr *e) {
  if (!e)
    return false;
  switch (e->kind) {
  case ExprKind::NumberLiteral:
  case ExprKind::StringLiteral:
    return true;
  case ExprKind::Identifier: {
    double unused = 0;
    return e->slot < 0 && tryResolveConstantValue(e->text, unused);
  }
  case ExprKind::Call:
    if (e->hasNamedArgs() || !conversionResultType(e->text))
      return false;
    break;
  case ExprKind::MatrixLiteral:
  case ExprKind::ArrayLiteral:
  case ExprKind::RangeLiteral:
  case ExprKind::UnaryOp:
  case ExprKind::AbsOrNorm:
  case ExprKind::BinaryOp:
  case ExprKind::Comparison:
  case ExprKind::LogicalOp:
    break;
  default:
    return false;
  }
  for (const auto &c : e->children)
    if (!isConstantExpr(c.get()))
      return false;
  for (const Expr *r : {e->rangeStart.get(), e->rangeStop.get(), e->rangeStep.get()})
    if (r && !isConstantExpr(r))
      return false;
  return true;
}

// Evaluates a constant expression (see isConstantExpr) without letting any
// error it reports (1/"a") reach the Command Window. False if it failed.
bool evaluateQuietly(Parser &parser, const Expr *e, Value &out) {
  std::ostringstream sink;
  std::streambuf *old = std::cerr.rdbuf(sink.rdbuf());
  const bool before = parser.evaluationSucceeded_;
  parser.evaluationSucceeded_ = true;
  out = parser.evaluateExpr(e);
  const bool ok = parser.evaluationSucceeded_;
  parser.evaluationSucceeded_ = before;
  std::cerr.rdbuf(old);
  return ok;
}

} // namespace

/* ================= ClassName.base ================= */

namespace {

// Works out field types from one constructor's statements. `env` holds
// what is known about each local name (its inputs first), so
// `base.x = x` gets x's type.
struct FieldTypeScan {
  Parser &parser;
  std::unordered_map<std::string, std::string> env;
  std::unordered_map<std::string, std::string> &fields;
  const Expr *parentCall = nullptr; // the first parent(...) call seen, if any

  std::string typeOf(const Expr *e) {
    if (!e)
      return "any";
    if (isConstantExpr(e)) {
      Value v;
      return evaluateQuietly(parser, e, v) ? valueTypeName(v) : "any";
    }
    switch (e->kind) {
    case ExprKind::Identifier: {
      auto it = env.find(e->text);
      return it != env.end() ? it->second : "any";
    }
    case ExprKind::StringLiteral:
      return "string";
    case ExprKind::MatrixLiteral:
    case ExprKind::RangeLiteral:
      return "matrix";
    case ExprKind::Comparison:
    case ExprKind::LogicalOp:
      return "bool";
    case ExprKind::Call: {
      if (parser.hasClass(e->text))
        return e->text; // an instance of that class
      const char *t = conversionResultType(e->text);
      return t ? t : "any";
    }
    case ExprKind::UnaryOp: {
      if (e->text == "!")
        return "bool";
      const std::string inner = typeOf(e->children[0].get());
      return e->text == "-" ? inner : "any";
    }
    case ExprKind::BinaryOp: {
      const std::string l = typeOf(e->children[0].get());
      const std::string r = typeOf(e->children[1].get());
      if (l == "float64" && r == "float64")
        return "float64";
      if (e->text == "+" && l == "string" && r == "string")
        return "string";
      return "any";
    }
    default:
      return "any";
    }
  }

  void record(const std::string &field, const std::string &type) {
    auto it = fields.find(field);
    fields[field] = it == fields.end() ? type : mergeTypes(it->second, type);
  }

  void noteParentCalls(const Stmt *s) {
    for (const Expr *e : {s->expr.get(), s->value.get()})
      if (!parentCall && containsParentCall(e))
        parentCall = findParentCall(e);
  }

  void scan(const std::vector<std::unique_ptr<Stmt>> &stmts) {
    for (const auto &stmt : stmts) {
      const Stmt *s = stmt.get();
      noteParentCalls(s);
      if (s->kind == StmtKind::Assign && s->targets.size() == 1) {
        const Expr *t = s->targets[0].get();
        // M ,= X: M's type after the join is not X's type.
        const std::string type = s->extendDir != 0 ? "any" : typeOf(s->value.get());
        if (t->kind == ExprKind::Identifier)
          env[t->text] = type;
        else if (t->kind == ExprKind::FieldAccess && t->children[0]->kind == ExprKind::Identifier &&
                 t->children[0]->text == "base")
          record(t->text, type);
      } else if (s->kind == StmtKind::Assign) {
        for (const auto &t : s->targets) {
          if (t->kind == ExprKind::Identifier)
            env[t->text] = "any";
          else if (t->kind == ExprKind::FieldAccess &&
                   t->children[0]->kind == ExprKind::Identifier &&
                   t->children[0]->text == "base")
            record(t->text, "any");
        }
      } else if (s->kind == StmtKind::For) {
        env[s->loopVar] = "any";
      }
      scan(s->body);
      for (const auto &branch : s->elseifBranches)
        scan(branch.second);
      scan(s->elseBody);
    }
  }
};

} // namespace

Value Parser::classBaseTypes(const std::string &className) {
  std::unordered_map<std::string, std::string> fields;

  // Reads the constructors that `start(...)` can reach: those of the
  // nearest class in its chain that has one (a class without its own
  // constructor uses its parent's). When `call` is set, this is the parent
  // reached through that parent(...) call, made inside a constructor read
  // by `callScan`: only the version the call binds to is read, and each of
  // its inputs takes the type of the value the call passes for it.
  // Otherwise every version is read. Each version's parent(...) call, if
  // any, brings in what the parent's constructor sets.
  std::function<void(const std::string &, const Expr *, FieldTypeScan *, int)> collect =
      [&](const std::string &start, const Expr *call, FieldTypeScan *callScan, int depth) {
        if (depth > 64)
          return; // a cycle in the class chain
        std::string cur = start;
        int guard = 0;
        while (!cur.empty() && guard++ < 64) {
          auto classIt = classTable_.find(cur);
          if (classIt == classTable_.end())
            return;
          auto ctorIt = classIt->second.methods.find("base");
          if (ctorIt == classIt->second.methods.end()) {
            cur = classIt->second.parentClassName;
            continue;
          }
          std::vector<const FunctionDef *> versions;
          ArgBinding binding;
          if (call) {
            std::string unused;
            if (const FunctionDef *d = resolveOverload(ctorIt->second, "", "",
                                                       call->children.size(), call->argNames,
                                                       unused, &binding))
              versions.push_back(d);
          }
          const bool bound = !versions.empty();
          if (!bound)
            for (const auto &ctor : ctorIt->second)
              versions.push_back(&ctor);

          for (const FunctionDef *ctor : versions) {
            FieldTypeScan scan{*this, {}, fields};
            for (size_t i = 0; i < ctor->inputNames.size(); i++) {
              std::string t = "any";
              if (bound && binding.sourceOf[i] >= 0)
                t = callScan->typeOf(call->children[binding.sourceOf[i]].get());
              else if (ctor->hasDefault(i))
                t = scan.typeOf(ctor->inputDefaults[i].get());
              scan.env[ctor->inputNames[i]] = t;
            }
            scan.scan(ctor->body);
            if (scan.parentCall)
              collect(classIt->second.parentClassName, scan.parentCall, &scan, depth + 1);
          }
          return;
        }
      };
  collect(className, nullptr, nullptr, 0);

  Dict out;
  for (const auto &f : fields)
    if (fieldVisibleHere(className, f.first))
      out[f.first] = Value(f.second);
  return Value(out);
}

/* ================= obj.base ================= */

Value Parser::instanceBaseValues(const Value &obj) {
  Dict out;
  for (const auto &kv : obj.dict())
    if (fieldVisibleHere(obj.className(), kv.first))
      out[kv.first] = kv.second;
  return Value(out);
}

/* ================= ClassName.info ================= */

Value Parser::classInfo(const std::string &className) {
  std::vector<Value> functions;
  // (name, number of inputs) already listed from a nearer class: that
  // version is the one a call reaches, the ancestor's is overridden.
  std::set<std::pair<std::string, size_t>> reachable;

  std::string cur = className;
  int guard = 0;
  while (!cur.empty() && guard++ < 64) {
    auto classIt = classTable_.find(cur);
    if (classIt == classTable_.end())
      break;
    const ClassDef &cls = classIt->second;
    for (const auto &methodName : cls.methodOrder) {
      auto methodIt = cls.methods.find(methodName);
      if (methodIt == cls.methods.end())
        continue;
      for (const auto &def : methodIt->second) {
        if (!reachable.insert({methodName, def.inputNames.size()}).second)
          continue; // overridden by a nearer class
        const bool isCtor = methodName == "base";
        Dict entry;
        entry["name"] = Value(methodName);
        entry["kind"] = Value(std::string(isCtor ? "constructor" : "method"));
        entry["from"] = Value(cur);
        entry["inputs"] = textArray(def.inputNames);
        entry["outputs"] = textArray(def.outputNames);
        Dict defaults;
        for (size_t i = 0; i < def.inputNames.size(); i++) {
          if (!def.hasDefault(i))
            continue;
          // A constant default is shown as its value, anything else
          // (b = a*2) as the text written in the header.
          Value v;
          if (isConstantExpr(def.inputDefaults[i].get()) &&
              evaluateQuietly(*this, def.inputDefaults[i].get(), v))
            defaults[def.inputNames[i]] = v;
          else
            defaults[def.inputNames[i]] = Value(def.inputDefaultTexts[i]); // as written
        }
        entry["defaults"] = Value(defaults);
        entry["signature"] = Value(signatureText(isCtor ? cur : methodName, def));
        if (cls.isAbstract && def.body.empty())
          entry["abstract"] = Value::boolean(true);
        functions.emplace_back(entry);
      }
    }
    cur = cls.parentClassName;
  }

  Dict info;
  info["class"] = Value(className);
  info["parent"] = Value(classTable_.count(className) ? classTable_[className].parentClassName
                                                      : std::string());
  info["count"] = Value(static_cast<double>(functions.size()));
  info["functions"] = Value(std::move(functions));
  return Value(info);
}

void Parser::printClassInfo(const std::string &title, const Value &info) {
  auto textOf = [](const Value &d, const char *key) -> std::string {
    auto it = d.dict().find(key);
    if (it == d.dict().end())
      return std::string();
    return it->second.isText ? it->second.text() : valueToString(it->second);
  };
  auto field = [](const Value &d, const char *key) -> Value {
    auto it = d.dict().find(key);
    return it == d.dict().end() ? Value() : it->second;
  };

  const Value functions = field(info, "functions");
  const size_t n = functions.isArray ? functions.length() : 0;

  // Columns: kind | call | outputs | from
  std::vector<std::vector<std::string>> rows;
  rows.push_back({"kind", "call", "outputs", "from"});
  for (size_t i = 0; i < n; i++) {
    const Value f = functions.at(i);
    std::string call = textOf(f, "signature");
    // The signature starts with its outputs ("A = area()"); the table shows
    // those in their own column.
    const size_t eq = call.find(" = ");
    if (eq != std::string::npos && call.find('(') > eq)
      call = call.substr(eq + 3);
    std::string outputs;
    const Value outs = field(f, "outputs");
    for (size_t k = 0; outs.isArray && k < outs.length(); k++)
      outputs += (k > 0 ? ", " : "") + outs.at(k).text();
    std::string kind = textOf(f, "kind");
    if (field(f, "abstract").isBool())
      kind += " (abstract)";
    rows.push_back({kind, call, outputs.empty() ? "-" : outputs, textOf(f, "from")});
  }
  std::vector<size_t> width(4, 0);
  for (const auto &r : rows)
    for (size_t c = 0; c < 4; c++)
      width[c] = std::max(width[c], r[c].size());

  std::ostringstream ss;
  const std::string parent = textOf(info, "parent");
  ss << "    class " << textOf(info, "class");
  if (!parent.empty())
    ss << " (inherits " << parent << ")";
  ss << " - " << n << (n == 1 ? " function" : " functions") << "\n";
  for (size_t r = 0; r < rows.size(); r++) {
    ss << "\n    ";
    std::string line;
    for (size_t c = 0; c < 4; c++) {
      line += rows[r][c];
      if (c < 3)
        line += std::string(width[c] - rows[r][c].size() + 3, ' ');
    }
    while (!line.empty() && line.back() == ' ')
      line.pop_back();
    ss << line;
  }
  printDisplayBlock(title, ss.str());
}

/* ================= DISPATCH ================= */

bool Parser::tryClassIntrospection(const Expr *node, Value &out, bool &isInfo) {
  if (!node || (node->kind != ExprKind::FieldAccess && node->kind != ExprKind::MethodCall) ||
      !isIntrospectionName(node->text) || node->children.empty())
    return false;
  const Expr *receiver = node->children[0].get();
  if (receiver->kind != ExprKind::Identifier)
    return false;
  const std::string &name = receiver->text;

  // What the name in front of the dot is: an object in a variable, or a
  // class (only when no variable has that name).
  std::string className;
  Value object;
  bool isObject = false;
  if (varExists(receiver->slot, name)) {
    object = varGet(receiver->slot, name);
    if (!object.isObject)
      return false; // a plain value: the usual "not an object" error applies
    isObject = true;
    className = object.className();
    // Objects the runtime builds (load_mat(...) -> NcMat) are no NC class:
    // their .info / .base are ordinary fields or methods. (2026-10-28)
    if (!classTable_.count(className))
      return false;
  } else if (classTable_.count(name)) {
    className = name;
  } else {
    return false;
  }

  isInfo = node->text == "info";
  if (node->kind == ExprKind::MethodCall && node->children.size() > 1) {
    std::cerr << "Error: '." << node->text << "' takes no values - write " << name << "."
              << node->text << "\n";
    evaluationSucceeded_ = false;
    out = Value(0);
    return true;
  }

  if (isInfo)
    out = classInfo(className);
  else
    out = isObject ? instanceBaseValues(object) : classBaseTypes(className);
  return true;
}
