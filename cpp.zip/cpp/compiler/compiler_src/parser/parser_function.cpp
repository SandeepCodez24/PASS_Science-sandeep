// Function definitions: invoking a registered function by name
// (callUserFunction/callUserFunctionMulti), including the shared
// local-scope save/swap/restore core (invokeFunctionBody), which also binds
// named values and evaluates default values (the matching rules themselves
// live in parser_args.cpp). Registering a
// `function ... fnend` block (building its FunctionDef and Stmt-tree body)
// is parser_program.cpp's parseFunctionDeclNode() plus
// registerFunctionDeclStmt() in parser_exec_stmt.cpp - this file only
// covers what happens once a function is already registered.
#include "parser.h"

#include "../../../runtime/execution/Interrupt.h"

#include <iostream>

/* ================= TERMINATOR ================= */

bool Parser::isFunctionTerm(const std::string &lower) {
  return lower == "fnend";
}

/* ================= POLYMORPHISM (overloading) ================= */

void Parser::registerOverload(std::unordered_map<std::string, std::vector<FunctionDef>> &table,
                               const std::string &name, FunctionDef def) {
  auto &overloads = table[name];
  for (auto &existing : overloads) {
    if (existing.inputNames.size() == def.inputNames.size()) {
      existing = std::move(def); // redefinition of the same arity
      return;
    }
  }
  overloads.push_back(std::move(def));
}

// findOverload() / resolveOverload(): parser_args.cpp.

/* ================= INVOCATION ================= */

bool Parser::invokeFunctionBody(const FunctionDef &def, const std::vector<Value> &args,
                                 std::unordered_map<std::string, Value> &outScope,
                                 const Value *selfValue,
                                 const std::string &definingClassName,
                                 const std::vector<std::string> &argNames) {
  // Which call value each input takes (or its default). Every caller has
  // already chosen `def` with resolveOverload(), which checked this same
  // binding and reported any problem with the call in its own words - this
  // is only a safety net.
  ArgBinding binding;
  {
    std::string why;
    if (!planBinding(def, args.size(), argNames, binding, why)) {
      std::cerr << "Error: " << why << "\n";
      evaluationSucceeded_ = false;
      return false;
    }
  }

  // Swap in a fresh local scope - both the string-keyed `memory` fallback
  // and the slot-indexed frame (slots_/slotAssigned_, sized to whatever
  // resolveFunctionSlots() determined this function/method needs - see
  // Expr::slot's comment for why every name it will ever locally assign is
  // knowable ahead of time) - and reset loop state, so recursion and
  // nested loops/break/continue/return never leak across the call boundary
  // in either direction.
  auto savedMemory = std::move(memory);
  auto savedInsertionOrder = std::move(insertionOrder);
  auto savedSlots = std::move(slots_);
  auto savedSlotAssigned = std::move(slotAssigned_);
  int savedLoopDepth = loopDepth_;
  LoopSignal savedLoopSignal = loopSignal_;
  std::string savedDefiningClass = std::move(currentDefiningClass_);
  int savedAnsSlot = currentAnsSlot_;
  int savedBaseSlot = currentBaseSlot_;
  const std::vector<std::string> *savedOutputNames = currentOutputNames_;
  const std::vector<int> *savedOutputSlots = currentOutputSlots_;

  memory.clear();
  insertionOrder.clear();
  // The outermost call's saved maps ARE the global workspace for the rest
  // of the call - see Parser::globalMemory().
  enterLocalScope(&savedMemory, &savedInsertionOrder);
  slots_.assign(def.slotCount, Value());
  slotAssigned_.assign(def.slotCount, false);
  loopDepth_ = 0;
  loopSignal_ = LoopSignal::None;
  currentDefiningClass_ = definingClassName;
  currentAnsSlot_ = def.ansSlot;
  currentBaseSlot_ = def.baseSlot;
  currentOutputNames_ = &def.outputNames;
  currentOutputSlots_ = &def.outputSlots;

  // An anonymous function (@(x) a*x) sees the values its free names had
  // where it was written. They are never assigned in its body, so they
  // live in `memory`, not in a slot.
  for (const auto &cap : def.captured) {
    memory[cap.first] = cap.second;
    insertionOrder.push_back(cap.first);
  }

  // A method/constructor call seeds `base` (the current instance) before
  // the body runs, so it can read base.field and mutate it — the caller
  // reads the mutated value back out of outScope["base"] afterward. A plain
  // function call passes selfValue == nullptr and skips this entirely.
  // def.baseSlot is always >=0 here: every caller that passes a non-null
  // selfValue only ever does so for a method/constructor call, and every
  // method/constructor is registered via registerClassDeclStmt(), which
  // always resolves with hasBase=true.
  if (selfValue) {
    varSet(def.baseSlot, "base", *selfValue);
  }

  // The values the caller gave first, then each default in input order -
  // so a default can use any given input, or an earlier default
  // (F(a, b=a*2)). A default is evaluated here, in the function's own
  // fresh scope, every time it is needed.
  for (size_t i = 0; i < def.inputNames.size(); i++) {
    if (binding.sourceOf[i] >= 0)
      varSet(def.inputSlots[i], def.inputNames[i], args[binding.sourceOf[i]]);
  }
  bool defaultsOk = true;
  for (size_t i = 0; i < def.inputNames.size() && defaultsOk; i++) {
    if (binding.sourceOf[i] >= 0)
      continue;
    const bool succeededBefore = evaluationSucceeded_;
    evaluationSucceeded_ = true;
    Value defaultValue = evaluateExpr(def.inputDefaults[i].get());
    if (!evaluationSucceeded_) {
      // evaluateExpr() already said what went wrong inside the default.
      std::cerr << "Error: could not work out the default value of input '"
                << def.inputNames[i] << "' (" << def.inputDefaultTexts[i] << ")\n";
      defaultsOk = false;
    } else {
      evaluationSucceeded_ = succeededBefore;
      varSet(def.inputSlots[i], def.inputNames[i], defaultValue);
    }
  }

  // executeStmtList() below walks an already-parsed Stmt tree - it never
  // calls setTokens() or otherwise touches the shared token cursor, unlike
  // the pre-Phase-3 executeBlockLines() this replaced (which re-lexed each
  // body line on every single call). Save/restore kept anyway as cheap
  // defense-in-depth matching memory/loop state above, in case this ever
  // runs mid-way through parsing an outer expression (e.g. nested inside
  // another call's argument list, like `publish("x:", square(5))`).
  auto savedTokens = std::move(tokens);
  size_t savedPos = pos;

  if (defaultsOk)
    executeStmtList(def.body);

  tokens = std::move(savedTokens);
  pos = savedPos;

  // Whatever's left here (None, or Return from an early exit) is fully
  // consumed by this call — it must never bubble into the caller.
  loopSignal_ = LoopSignal::None;

  // Pull out only what a caller ever actually reads from outScope -
  // declared outputs, plus `base` for a method/constructor (confirmed the
  // only two things any call site looks up) - before this frame is torn
  // down. Preserves the exact existing contract (outScope.find(name) ==
  // outScope.end() means "never assigned") regardless of whether a given
  // name ended up slotted or fell back to `memory`; also avoids a full
  // frame copy on every single call, which the old outScope = memory; did.
  outScope.clear();
  for (size_t i = 0; i < def.outputNames.size(); i++) {
    int slot = def.outputSlots[i];
    const std::string &outName = def.outputNames[i];
    if (varExists(slot, outName))
      outScope[outName] = varGet(slot, outName);
  }
  if (def.baseSlot >= 0 && varExists(def.baseSlot, "base"))
    outScope["base"] = varGet(def.baseSlot, "base");

  if (!defaultsOk)
    outScope.clear(); // the body never ran: the call has no result

  leaveLocalScope();
  memory = std::move(savedMemory);
  insertionOrder = std::move(savedInsertionOrder);
  slots_ = std::move(savedSlots);
  slotAssigned_ = std::move(savedSlotAssigned);
  loopDepth_ = savedLoopDepth;
  loopSignal_ = savedLoopSignal;
  currentDefiningClass_ = std::move(savedDefiningClass);
  currentAnsSlot_ = savedAnsSlot;
  currentBaseSlot_ = savedBaseSlot;
  currentOutputNames_ = savedOutputNames;
  currentOutputSlots_ = savedOutputSlots;

  if (!defaultsOk) {
    evaluationSucceeded_ = false;
    return false;
  }

  // An error inside the body (already printed) stops the script: the call
  // has no result, and failing quietly - no "output not assigned" error -
  // lets the unwind reach the top level, where the script stops once.
  if (errorAbort_) {
    evaluationSucceeded_ = false;
    return false;
  }

  // Stopped by the user (Stop in the IDE) partway through the body: the
  // call has no result. Failing quietly - no "output not assigned" error -
  // lets the interruption unwind to the prompt, where it is reported once.
  if (nc::Interrupt::requested()) {
    evaluationSucceeded_ = false;
    return false;
  }

  return true;
}

Value Parser::callUserFunction(const std::string &name, const std::vector<Value> &args,
                                bool &found, const std::vector<std::string> &argNames) {
  auto it = functionTable_.find(name);
  if (it == functionTable_.end()) {
    found = false;
    return Value(0);
  }
  found = true;

  std::string err;
  const FunctionDef *defPtr = resolveOverload(it->second, "function '" + name + "'", name,
                                              args.size(), argNames, err);
  if (!defPtr) {
    std::cerr << "Error: " << err << "\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  const FunctionDef &def = *defPtr;

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope, nullptr, std::string(), argNames))
    return Value(0);

  if (def.outputNames.empty())
    return Value(0); // void function used where a value was expected

  const std::string &outName = def.outputNames[0];
  auto oit = outScope.find(outName);
  if (oit == outScope.end()) {
    std::cerr << "Error: output '" << outName << "' not assigned in function '" << name << "'\n";
    evaluationSucceeded_ = false;
    return Value(0);
  }
  return oit->second;
}

std::vector<Value> Parser::callUserFunctionMulti(const std::string &name,
                                                   const std::vector<Value> &args,
                                                   size_t expectedOutputs, bool &found,
                                                   const std::vector<std::string> &argNames) {
  auto it = functionTable_.find(name);
  if (it == functionTable_.end()) {
    found = false;
    return {};
  }
  found = true;

  std::string err;
  const FunctionDef *defPtr = resolveOverload(it->second, "function '" + name + "'", name,
                                              args.size(), argNames, err);
  if (!defPtr) {
    std::cerr << "Error: " << err << "\n";
    evaluationSucceeded_ = false;
    return {};
  }
  const FunctionDef &def = *defPtr;

  if (def.outputNames.size() != expectedOutputs) {
    std::cerr << "Error: function '" << name << "' declares " << def.outputNames.size()
              << " output(s), call expects " << expectedOutputs << "\n";
    evaluationSucceeded_ = false;
    return {};
  }

  std::unordered_map<std::string, Value> outScope;
  if (!invokeFunctionBody(def, args, outScope, nullptr, std::string(), argNames))
    return {};

  std::vector<Value> results;
  for (const auto &outName : def.outputNames) {
    auto oit = outScope.find(outName);
    if (oit == outScope.end()) {
      std::cerr << "Error: output '" << outName << "' not assigned in function '" << name << "'\n";
      evaluationSucceeded_ = false;
      return {};
    }
    results.push_back(oit->second);
  }
  return results;
}
