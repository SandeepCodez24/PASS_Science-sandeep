#pragma once

#include <string>
#include <vector>

#include "parser.h"
#include "value.h"

// Helpers shared across the Parser's implementation files. Not part of the
// public Parser API - only parser_*.cpp files should include this.

// Retired along with variables.txt: Parser::saveToFile() is now a no-op,
// so there is nothing left to suppress and the tree-walker no longer uses
// this. Kept only so a parser file outside that change that still names it
// keeps compiling; safe to delete once nothing does.
struct PersistenceSuppressor {
  Parser &parser;
  explicit PersistenceSuppressor(Parser &p) : parser(p) { parser.suppressPersistence_++; }
  ~PersistenceSuppressor() { parser.suppressPersistence_--; }
};

// Shared by parser_exec_stmt.cpp's For-statement evaluation (defined in
// parser_block_exec.cpp) and parseFactor()'s range literals
// (parser_factor.cpp). leftBracket is '[' (inclusive start) or '('
// (exclusive start); rightBracket is ']' (inclusive end) or ')' (exclusive
// end).
std::vector<double> generateRange(double start, double step, double end,
                                   char leftBracket, char rightBracket);

// Dict keys are always stored/looked-up as strings: text values use their
// text as-is, numeric values are formatted the same way printed output is.
// Shared by the dict-key assignment/read paths (parser_exec_stmt.cpp,
// parser_factor.cpp; defined in parser_statement.cpp).
std::string dictKeyOf(const Value &key);

// The source text of tokens [from, to), re-spaced for display:
// `"car"`, `a * 2`, `[1, 2]`, `-1`. Used to keep each input default's text
// for ClassName.info and error messages (parser_args.cpp).
std::string tokensToSource(const std::vector<Token> &toks, size_t from, size_t to);

// A deep copy of an expression tree (parser_exec_stmt.cpp). Used to give an
// anonymous function (@(x) x * 2) a body of its own.
std::unique_ptr<Expr> cloneExprTree(const Expr *src);
