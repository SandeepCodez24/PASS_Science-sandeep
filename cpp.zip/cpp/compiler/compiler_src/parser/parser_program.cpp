// Phase 3 (AST rewrite roadmap, expanded scope): a real recursive-descent
// statement/block parser. Builds Stmt trees (ast.h) for an entire token
// stream - a whole file, or a whole function/method body - with block
// nesting handled by ordinary recursion instead of the raw-text
// accumulation + keyword-rescanning that ScriptManager (top-level) and
// executeBlockLines() (nested blocks, function/method bodies) do today.
//
// Step 2 of the phase: this file only builds trees. Nothing here touches
// `memory`, `functionTable_`, `classTable_`, or prints anything - that's
// the Step 3 evaluator's job (executeProgram()/executeStmt(), a separate
// file), which walks the Program this produces. See ast.h's Stmt/StmtKind
// for the node shapes being built.
#include "parser.h"
#include "parser_internal.h"

#include <cctype>
#include <iostream>

namespace {
std::string lowerOf(const Token &t) {
  std::string s = t.text;
  for (char &ch : s) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  return s;
}

std::unique_ptr<Expr> makeIdentifier(const std::string &name) {
  auto e = std::make_unique<Expr>();
  e->kind = ExprKind::Identifier;
  e->text = name;
  return e;
}

std::unique_ptr<Stmt> makeStmt(StmtKind kind, size_t line) {
  auto s = std::make_unique<Stmt>();
  s->kind = kind;
  s->line = line;
  return s;
}

// Reports a syntax or layout error. Every such error is counted
// (syntaxErrorCount_), because a script with any of them does not run
// (ScriptManager::executeFile(), main.cpp's REPL). `category` is "Syntax"
// or "Indentation".
void reportError(Parser &p, const char *category, size_t line, size_t col,
                 const std::string &msg) {
  std::cerr << "✖ " << category << " Error";
  if (line) {
    std::cerr << " (line " << line;
    if (col)
      std::cerr << ", col " << col;
    std::cerr << ")";
  }
  std::cerr << ": " << msg << "\n";
  p.syntaxErrorCount_++;
  p.evaluationSucceeded_ = false;
}

// The block closers are read as plain names by the lexer, so nothing used
// to stop `iend = 2;` from making a variable of that name.
bool isReservedName(const std::string &lower) {
  return Parser::isIfTerm(lower) || Parser::isForTerm(lower) || Parser::isWhileTerm(lower) ||
         Parser::isFunctionTerm(lower) || Parser::isClassTerm(lower);
}

// A keyword token (if, for, print, return, ...) - its text is a word.
bool isKeywordToken(const Token &t) {
  return t.type != IDENT && t.type != NUMBER && t.type != STRING && !t.text.empty() &&
         std::isalpha(static_cast<unsigned char>(t.text[0]));
}
} // namespace

// A block's body starts on the line after its header: `if x: publish(1); iend`
// is refused, with the message the editor gives (BlockHeaderGrammar.java).
// Called right after the header's ':' has been consumed; the body is still
// parsed afterwards, so this is the only error the line gets.
static void rejectBodyOnHeaderLine(Parser &p, size_t headerLine, const std::string &keyword) {
  const Token next = p.current();
  if (next.type == END || headerLine == 0 || next.line != headerLine)
    return;
  reportError(p, "Syntax", next.line, next.col,
              "the body of '" + keyword +
                  "' goes on the lines below its header, not after the ':' (and its closer on "
                  "a line of its own)");
}

// "'iend' is a keyword ..." when `tok` names a keyword or block closer.
// True (error reported) if it does.
static bool rejectKeywordAsName(Parser &p, const Token &tok, const char *what) {
  if (!(isKeywordToken(tok) || (tok.type == IDENT && isReservedName(lowerOf(tok)))))
    return false;
  reportError(p, "Syntax", tok.line, tok.col,
              "'" + tok.text + "' is a keyword and cannot be used as " + what);
  return true;
}

/* ================= ENTRY POINT ================= */

Program Parser::parseProgram(const std::vector<Token> &fileTokens) {
  setTokens(fileTokens);

  Program program;
  while (current().type != END) {
    size_t before = pos;
    auto stmt = parseStmtNode();
    if (stmt)
      program.statements.push_back(std::move(stmt));
    if (pos == before)
      break; // no progress on unrecognized input - avoid looping forever
  }
  return program;
}

std::vector<std::unique_ptr<Stmt>>
Parser::parseStmtsUntil(const std::function<bool()> &isBoundary) {
  std::vector<std::unique_ptr<Stmt>> stmts;
  while (current().type != END && !isBoundary()) {
    size_t before = pos;
    auto stmt = parseStmtNode();
    if (stmt)
      stmts.push_back(std::move(stmt));
    if (pos == before)
      break;
  }
  return stmts;
}

/* ================= STATEMENT DISPATCH ================= */

// Error recovery for simple statements. If the expression parser reported a
// syntax error while building this statement, drop it (never execute a
// half-built tree - it used to assign a bogus value, or crash the JIT) and
// skip to just past the next ';' (or the end of the line / input). Compound
// statements (if/for/while/function/class) are left alone: their nested
// statements recover individually, and discarding the whole block because
// one inner line was bad would hide every other error inside it.
std::unique_ptr<Stmt> Parser::parseStmtNode() {
  const int errsBefore = syntaxErrorCount_;
  const size_t startLine = current().line;
  auto stmt = parseStmtNodeImpl();
  if (!stmt)
    return stmt;

  switch (stmt->kind) {
  case StmtKind::ExprStmt:
  case StmtKind::Assign:
  case StmtKind::Publish:
  case StmtKind::Return:
  case StmtKind::Require:
  case StmtKind::Ensure:
    break;
  default:
    return stmt;
  }

  // A ',=' / ';=' left over after a statement: it followed something other
  // than a plain name (A[0] ,= 1, obj.f ,= 1, x + 1 ,= 2).
  if (syntaxErrorCount_ == errsBefore && (current().type == COMMA_ASSIGN ||
                                          current().type == SEMI_ASSIGN)) {
    const Token &op = current();
    std::cerr << "✖ Syntax Error";
    if (op.line)
      std::cerr << " (line " << op.line << ", col " << op.col << ")";
    std::cerr << ": '" << op.text << "' extends a variable - the left side must be a plain "
              << "name, e.g. M " << op.text << " X\n";
    syntaxErrorCount_++;
    evaluationSucceeded_ = false;
  }

  // Two values side by side with no operator between them (`5 6`, `x y`,
  // `2 "a"`): the statement parser used to stop after the first value and
  // silently run the second as a separate statement. A new statement on the
  // same line is only legitimate right after a ';' (already consumed, so the
  // previous token is then SEMICOLON).
  if (syntaxErrorCount_ == errsBefore && pos > 0 && startLine != 0 &&
      tokens[pos - 1].type != SEMICOLON && current().line == tokens[pos - 1].line &&
      (current().type == NUMBER || current().type == IDENT ||
       current().type == STRING || current().type == LPAREN ||
       current().type == LBRACKET)) {
    std::cerr << "✖ Syntax Error (line " << current().line << ", col "
              << current().col << "): unexpected '" << current().text
              << "' - two values cannot sit next to each other; an operator "
                 "(+, -, *, /, ^, ...) or ';' is missing after '"
              << tokens[pos - 1].text << "'\n";
    syntaxErrorCount_++;
    evaluationSucceeded_ = false;
  }

  // A closer with no opener (`6)`, `(1+2))`, `[1]]`): the statement parser
  // stopped at it, so the statement before it would run - Python rejects the
  // whole line instead.
  if (syntaxErrorCount_ == errsBefore && startLine != 0 &&
      (current().type == RPAREN || current().type == RBRACKET) &&
      current().line == startLine) {
    std::cerr << "✖ Syntax Error (line " << current().line << ", col "
              << current().col << "): unmatched '" << current().text
              << "' - it has no matching opening bracket\n";
    syntaxErrorCount_++;
    evaluationSucceeded_ = false;
  }

  if (syntaxErrorCount_ == errsBefore)
    return stmt;

  while (current().type != END && current().type != SEMICOLON &&
         !(startLine != 0 && current().line != startLine))
    advance();
  if (current().type == SEMICOLON)
    advance();
  return nullptr;
}

std::unique_ptr<Stmt> Parser::parseStmtNodeImpl() {
  // `if = 2;`, `iend = 2;`, `print = 1;` - a keyword is not a variable.
  if (pos + 1 < tokens.size() && tokens[pos + 1].type == ASSIGN &&
      rejectKeywordAsName(*this, current(), "a variable name")) {
    auto stmt = makeStmt(StmtKind::ExprStmt, current().line);
    advance();
    return stmt; // parseStmtNode() discards it and resynchronizes
  }

  // Other languages' spellings of elseif. Without this, `elif x > 5:` was
  // read as two names side by side ("two values cannot sit next to each
  // other"), which does not say what is wrong.
  if (current().type == IDENT && lowerOf(current()) == "elif") {
    reportError(*this, "Syntax", current().line, current().col,
                "'elif' is not an NC keyword - write 'elseif'");
    auto stmt = makeStmt(StmtKind::ExprStmt, current().line);
    advance();
    return stmt;
  }

  if (current().type == IF)
    return parseIfStmtNode();

  if (current().type == FOR)
    return parseForStmtNode();

  if (current().type == WHILE)
    return parseWhileStmtNode();

  if (current().type == BREAK || current().type == CONTINUE) {
    auto stmt = makeStmt(current().type == BREAK ? StmtKind::Break : StmtKind::Continue, current().line);
    advance();
    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == RETURN) {
    const size_t returnLine = current().line;
    auto stmt = makeStmt(StmtKind::Return, returnLine);
    advance();
    // `return value;` - in a function with one output, sets that output
    // and returns (executeStmt()). A bare `return;` just returns.
    if (current().type != SEMICOLON && current().type != END &&
        !(returnLine != 0 && current().line != returnLine) &&
        !(current().type == IDENT && isReservedName(lowerOf(current())))) {
      stmt->value = parseOrNode();
      if (!stmt->value)
        return stmt; // the expression already reported its error
    }
    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == REQUIRE || current().type == ENSURE) {
    bool isRequire = (current().type == REQUIRE);
    advance();

    auto stmt = makeStmt(isRequire ? StmtKind::Require : StmtKind::Ensure, current().line);
    const size_t condStart = pos;
    stmt->condition = parseOrNode();
    if (!stmt->condition)
      return stmt; // the expression already reported its error
    // The condition as written, for the failure message (it used to be
    // the tokens joined by spaces: `x >= - 40`, `v [ k ] > 0`).
    stmt->conditionText = tokensToSource(tokens, condStart, pos);

    // Optional message: require x > 0, "x must be positive";
    if (current().type == COMMA) {
      advance();
      if (current().type != STRING) {
        reportError(*this, "Syntax", current().line, current().col,
                    std::string("the message after '") + (isRequire ? "require" : "ensure") +
                        " <condition>,' must be text in quotes, e.g. require x > 0, \"x must "
                        "be positive\";");
        return stmt;
      }
      stmt->contractMessage = current().text;
      advance();
    }

    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == FUNCTION)
    return parseFunctionDeclNode();

  if (current().type == CLASS || current().type == ABSTRACT || current().type == REVERSIBLE)
    return parseClassDeclNode();

  if (current().type == IDENT && (current().text == "new" || current().text == "clear" || current().text == "cls")) {
    auto stmt = makeStmt(StmtKind::ClearMemory, current().line);
    stmt->name = current().text;
    advance();
    if (current().type == SEMICOLON) advance();
    return stmt;
  }

  if (current().type == PRINT || current().type == PUBLISH)
    return parsePublishStmtNode();

  return parseAssignOrExprStmtNode();
}

/* ================= CONDITION HEADER (if/elseif/while) ================= */

std::unique_ptr<Expr> Parser::parseConditionHeader(const char *keyword) {
  const Token headerTok = current();
  bool negate = false;
  if (current().type == IDENT) {
    std::string t = current().text;
    for (char &ch : t) ch = static_cast<char>(std::tolower((unsigned char)ch));
    if (t == "not") {
      negate = true;
      advance();
    }
  }

  auto cond = parseOrNode();

  if (negate) {
    auto notNode = std::make_unique<Expr>();
    notNode->kind = ExprKind::UnaryOp;
    notNode->text = "!";
    notNode->children.push_back(std::move(cond));
    cond = std::move(notNode);
  }

  // The header ends with ':', like a function header. It used to be
  // optional here, so `if x == 1` (no colon) ran normally - and so did a
  // condition cut short by a typo, with the rest of the line taken as the
  // body.
  if (current().type == COLON) {
    advance();
    rejectBodyOnHeaderLine(*this, headerTok.line, keyword);
  } else if (cond) {
    const Token &at = current();
    const bool sameLine = at.type != END && at.line == headerTok.line;
    reportError(*this, "Syntax", sameLine ? at.line : headerTok.line, sameLine ? at.col : 0,
                std::string("expected ':' at the end of the '") + keyword + "' line" +
                    (sameLine ? ", found '" + at.text + "'" : ""));
  }

  return cond;
}

/* ================= IF ================= */

// A block keyword (elseif/else/closer) that starts its own line must line up
// with the block's header. One on the header's own line - a one-line block,
// `if x: publish(1); iend` - has already been reported as such
// (rejectBodyOnHeaderLine()), so it is not reported again here.
static void checkAligned(Parser &p, const Token &tok, size_t headerLine, size_t headerCol,
                         const char *headerWord) {
  if (tok.line == headerLine || tok.col == headerCol)
    return;
  reportError(p, "Indentation", tok.line, 0,
              "'" + tok.text + "' line (indentation " + std::to_string(tok.col - 1) +
                  ") is unaligned with matching '" + headerWord + "' line (indentation " +
                  std::to_string(headerCol - 1) + ")");
}

std::unique_ptr<Stmt> Parser::parseIfStmtNode() {
  const size_t headerCol = current().col;
  const size_t headerLine = current().line;
  advance(); // consume IF

  auto stmt = makeStmt(StmtKind::If, current().line);
  stmt->condition = parseConditionHeader("if");

  auto isIfBoundary = [&]() -> bool {
    if (current().type == ELSEIF || current().type == ELSE)
      return true;
    return current().type == IDENT && Parser::isIfTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isIfBoundary);

  // `else if x:` would open a second, nested if that needs its own 'iend'
  // - almost never what was meant. It is reported, then read as the elseif
  // it was meant to be, so the rest of the block gives no follow-on errors.
  auto atElseIf = [&]() {
    return current().type == ELSE && pos + 1 < tokens.size() && tokens[pos + 1].type == IF &&
           tokens[pos + 1].line == current().line;
  };
  while (current().type == ELSEIF || atElseIf()) {
    checkAligned(*this, current(), headerLine, headerCol, "if");
    if (current().type == ELSE) {
      reportError(*this, "Syntax", current().line, current().col,
                  "write 'elseif' (one word), not 'else if'");
      advance();
    }
    advance();
    auto cond = parseConditionHeader("elseif");
    auto branchBody = parseStmtsUntil(isIfBoundary);
    stmt->elseifBranches.emplace_back(std::move(cond), std::move(branchBody));
  }

  if (current().type == ELSE) {
    const Token elseTok = current();
    checkAligned(*this, elseTok, headerLine, headerCol, "if");
    advance();
    if (current().type == COLON) {
      advance();
      rejectBodyOnHeaderLine(*this, elseTok.line, "else");
    } else {
      const bool sameLine = current().type != END && current().line == elseTok.line;
      reportError(*this, "Syntax", elseTok.line, sameLine ? current().col : 0,
                  "expected ':' after 'else'" +
                      (sameLine ? ", found '" + current().text + "'" : std::string()));
    }
    stmt->elseBody = parseStmtsUntil(isIfBoundary);
  }

  if (current().type == IDENT && Parser::isIfTerm(lowerOf(current()))) {
    checkAligned(*this, current(), headerLine, headerCol, "if");
    advance();
  } else {
    reportError(*this, "Syntax", headerLine, 0,
                "unclosed 'if' statement (expected 'iend')");
  }

  return stmt;
}

/* ================= FOR ================= */

std::unique_ptr<Stmt> Parser::parseForStmtNode() {
  const size_t headerCol = current().col;
  const size_t headerLine = current().line;
  advance(); // consume FOR

  auto stmt = makeStmt(StmtKind::For, current().line);

  if (rejectKeywordAsName(*this, current(), "a loop variable")) {
    // Skip the rest of the header so it is not read again as a statement.
    while (current().type != END && current().line == headerLine)
      advance();
    return stmt;
  }
  if (current().type != IDENT) {
    reportError(*this, "Syntax", current().line, current().col,
                "expected variable name after 'for'");
    return stmt;
  }
  stmt->loopVar = current().text;
  advance();

  size_t iterStart = pos;
  if (current().type == IN || current().type == ASSIGN) {
    advance();
    iterStart = pos;
    // The range/collection expression, e.g. [1:N], [1:2:N], A, or any other
    // array-valued expression - parseOrNode() already builds RangeLiteral
    // nodes for the bracketed [a:b]/[a:b:c] shape (parser_factor.cpp).
    // `for x in` used to take only a bare name.
    stmt->iterable = parseOrNode();
    if (!stmt->iterable)
      return stmt; // the expression already reported its error
  } else {
    reportError(*this, "Syntax", current().line, current().col,
                "expected '=' or 'in' after loop variable");
    return stmt;
  }

  if (current().type == COLON) {
    // MATLAB's `for i = 1:3` has no brackets, so `for i = 1:3:` reads as
    // `for i = 1`, then `:`, then a body starting with `3:`. Spot a second
    // ':' after a plain value on the header line and say what to write.
    size_t p = pos + 1;
    bool plainValues = p < tokens.size() && tokens[p].line == current().line;
    bool secondColon = false;
    for (; plainValues && p < tokens.size() && tokens[p].line == current().line; p++) {
      const TokenType t = tokens[p].type;
      if (t == COLON) {
        secondColon = true;
        break;
      }
      if (t != NUMBER && t != IDENT && t != MINUS && t != PLUS && t != MUL && t != DIV)
        plainValues = false;
    }
    if (plainValues && secondColon) {
      reportError(*this, "Syntax", current().line, current().col,
                  "a range in a 'for' header is written in brackets: for " + stmt->loopVar +
                      " = [" + tokensToSource(tokens, iterStart, pos) + ":" +
                      tokensToSource(tokens, pos + 1, p) + "]:");
      pos = p; // the second ':' - read the body and 'fend' as usual
    }
    advance();
    if (!(plainValues && secondColon))
      rejectBodyOnHeaderLine(*this, headerLine, "for");
  } else {
    const bool sameLine = current().type != END && current().line == headerLine;
    reportError(*this, "Syntax", headerLine, sameLine ? current().col : 0,
                "expected ':' at the end of the 'for' line" +
                    (sameLine ? ", found '" + current().text + "'" : std::string()));
  }
  if (current().type == SEMICOLON)
    advance();

  auto isForBoundary = [&]() -> bool {
    return current().type == IDENT && Parser::isForTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isForBoundary);

  if (current().type == IDENT && Parser::isForTerm(lowerOf(current()))) {
    checkAligned(*this, current(), headerLine, headerCol, "for");
    advance();
  } else {
    reportError(*this, "Syntax", headerLine, 0, "unclosed 'for' loop (expected 'fend')");
  }

  return stmt;
}

/* ================= WHILE ================= */

std::unique_ptr<Stmt> Parser::parseWhileStmtNode() {
  const size_t headerCol = current().col;
  const size_t headerLine = current().line;
  advance(); // consume WHILE

  auto stmt = makeStmt(StmtKind::While, current().line);
  stmt->condition = parseConditionHeader("while");
  if (current().type == SEMICOLON)
    advance();

  auto isWhileBoundary = [&]() -> bool {
    return current().type == IDENT && Parser::isWhileTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isWhileBoundary);

  if (current().type == IDENT && Parser::isWhileTerm(lowerOf(current()))) {
    checkAligned(*this, current(), headerLine, headerCol, "while");
    advance();
  } else {
    reportError(*this, "Syntax", headerLine, 0, "unclosed 'while' loop (expected 'wend')");
  }

  return stmt;
}

/* ================= PUBLISH / PRINT ================= */

std::unique_ptr<Stmt> Parser::parsePublishStmtNode() {
  advance(); // consume PRINT/PUBLISH

  auto stmt = makeStmt(StmtKind::Publish, current().line);

  if (current().type != LPAREN) {
    reportError(*this, "Syntax", current().line, current().col,
                "expected '(' after print/publish");
    return stmt;
  }
  advance();

  stmt->publishArgs.push_back(parseOrNode());
  while (current().type == COMMA) {
    advance();
    stmt->publishArgs.push_back(parseOrNode());
  }

  if (current().type == RPAREN) {
    advance();
  } else {
    reportError(*this, "Syntax", current().line, current().col,
                "expected ')' after print/publish");
    return stmt;
  }

  // print/publish always display output and ignore semicolon.
  if (current().type == SEMICOLON)
    advance();

  return stmt;
}

/* ================= FUNCTION DECLARATION ================= */

// Parses the declaration shapes - "[B1,B2] = name(...)", "B = name(...)",
// "name(...)", bare "name" - directly from the shared token stream, unlike
// today's parseFunctionHeader() (parser_function.cpp) which re-lexes a
// captured header string. Same grammar, same required trailing ':', same
// error messages; only the token source differs.
std::unique_ptr<Stmt> Parser::parseFunctionDeclNode() {
  advance(); // consume FUNCTION

  auto stmt = makeStmt(StmtKind::FunctionDecl, current().line);

  // On a malformed header, the original per-line dispatch naturally
  // discards the rest of this block: each subsequent line got its own
  // fresh token stream regardless of what the header parse consumed, so a
  // botched header only ever broke *that* definition (see the golden
  // corpus's t21_functions.nc, whose baseline has a malformed-header error
  // for one function immediately followed by every *other*, unrelated
  // top-level statement running normally). Parsing the whole file as one
  // token stream has no such free reset point - without skipping forward
  // to this function's own 'fnend' here, the rest of the file would be
  // parsed starting from wherever the header parse happened to give up,
  // corrupting everything that follows. Every fail() call below relies on
  // this.
  auto fail = [&](const std::string &msg) {
    reportError(*this, "Syntax", current().line, 0, msg);
    while (current().type != END &&
           !(current().type == IDENT && Parser::isFunctionTerm(lowerOf(current()))))
      advance();
    if (current().type != END)
      advance(); // consume 'fnend' itself
  };

  std::string funcName;

  // Several outputs: function [B1, B2] = name(...). The old round-bracket
  // form, function (B1, B2) = name(...), is an error that says so.
  if (current().type == LPAREN) {
    fail("the outputs of a function are written in square brackets - function [B1, B2] = "
         "name(...), not function (B1, B2) = name(...)");
    return stmt;
  }
  if (current().type == LBRACKET) {
    const TokenType closer = RBRACKET;
    const char *closerText = "']'";
    advance();
    if (current().type != IDENT) { fail("expected output variable name in function header"); return stmt; }
    stmt->outputNames.push_back(current().text);
    advance();
    while (current().type == COMMA) {
      advance();
      if (current().type != IDENT) { fail("expected output variable name in function header"); return stmt; }
      stmt->outputNames.push_back(current().text);
      advance();
    }
    if (current().type != closer) { fail(std::string("expected ") + closerText + " after output list in function header"); return stmt; }
    advance();
    if (current().type != ASSIGN) { fail("expected '=' after output list in function header"); return stmt; }
    advance();
    if (current().type != IDENT) { fail("expected function name in function header"); return stmt; }
    funcName = current().text;
    advance();
  } else if (current().type == IDENT) {
    std::string firstIdent = current().text;
    if (isReservedName(lowerOf(current()))) {
      fail("'" + firstIdent + "' is a keyword and cannot be used as a name in a function header");
      return stmt;
    }
    advance();
    if (current().type == ASSIGN) {
      stmt->outputNames.push_back(firstIdent);
      advance();
      if (current().type != IDENT) { fail("expected function name in function header"); return stmt; }
      funcName = current().text;
      advance();
    } else {
      funcName = firstIdent;
    }
  } else {
    fail("expected function name or output list after 'function'");
    return stmt;
  }

  // One input: `name` or `name = <default expression>` (F(a, b=2, c="car")).
  // A default is any expression; it is evaluated at call time, inside the
  // function, so it may use another input (b=a*2). Defaults may appear in
  // any position (F(a=1, b) is allowed) - see planBinding() for how a
  // call's values are matched to the inputs.
  std::vector<std::unique_ptr<Expr>> defaults;
  std::vector<std::string> defaultTexts;
  auto parseInput = [&]() -> bool {
    if (isKeywordToken(current()) ||
        (current().type == IDENT && isReservedName(lowerOf(current())))) {
      fail("'" + current().text + "' is a keyword and cannot be used as an input name");
      return false;
    }
    if (current().type != IDENT) {
      fail("expected input parameter name in function header");
      return false;
    }
    const std::string inputName = current().text;
    for (const auto &existing : stmt->inputNames) {
      if (existing == inputName) {
        fail("input '" + inputName + "' appears twice in the header of function '" + funcName +
             "'");
        return false;
      }
    }
    stmt->inputNames.push_back(inputName);
    advance();
    if (current().type != ASSIGN) {
      defaults.push_back(nullptr);
      defaultTexts.emplace_back();
      return true;
    }
    advance(); // '='
    if (current().type == COMMA || current().type == RPAREN) {
      fail("input '" + inputName + "' of function '" + funcName +
           "' has '=' but no default value after it");
      return false;
    }
    const size_t defaultStart = pos;
    auto defaultExpr = parseOrNode();
    if (!defaultExpr) {
      fail("the default value of input '" + inputName + "' of function '" + funcName +
           "' is not a valid expression");
      return false;
    }
    defaultTexts.push_back(tokensToSource(tokens, defaultStart, pos));
    defaults.push_back(std::move(defaultExpr));
    return true;
  };

  if (current().type == LPAREN) {
    advance();
    if (current().type != RPAREN) {
      if (!parseInput())
        return stmt;
      while (current().type == COMMA) {
        advance();
        if (!parseInput())
          return stmt;
      }
    }
    if (current().type != RPAREN) { fail("expected ')' to close input list in function header"); return stmt; }
    advance();
  }
  // else: bare "function foo" with no parens - no declared inputs.

  // Stored only when at least one input has a default, so a function
  // without any keeps exactly the shape it always had.
  bool anyDefault = false;
  for (const auto &d : defaults)
    anyDefault = anyDefault || d != nullptr;
  if (anyDefault) {
    stmt->inputDefaults = std::move(defaults);
    stmt->inputDefaultTexts = std::move(defaultTexts);
  }

  if (current().type != COLON) {
    fail("expected ':' at the end of the function header");
    return stmt;
  }
  advance();
  rejectBodyOnHeaderLine(*this, stmt->line, "function");

  stmt->name = funcName;

  auto isFunctionBoundary = [&]() -> bool {
    return current().type == IDENT && Parser::isFunctionTerm(lowerOf(current()));
  };
  stmt->body = parseStmtsUntil(isFunctionBoundary);

  if (current().type == IDENT && Parser::isFunctionTerm(lowerOf(current()))) {
    advance();
  } else {
    reportError(*this, "Syntax", stmt->line, 0,
                "unclosed function definition (expected 'fnend')");
  }

  return stmt;
}

/* ================= CLASS DECLARATION ================= */

// A class body is not a general statement list - only visibility
// declarations ('private'/'protected' field lists) and nested
// 'function...fnend' methods are allowed, matching executeClassDefEnd()'s
// grammar exactly (parser_class.cpp).
std::unique_ptr<Stmt> Parser::parseClassDeclNode() {
  auto stmt = makeStmt(StmtKind::ClassDecl, current().line);

  // See parseFunctionDeclNode()'s identical fail() for why skipping to this
  // construct's own terminator (here, 'csend') on error is necessary now
  // that the whole file is one token stream rather than independently
  // reset per line.
  auto fail = [&](const std::string &msg) {
    reportError(*this, "Syntax", current().line, 0, msg);
    stmt->classRegistrationFailed = true;
    while (current().type != END &&
           !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
      advance();
    if (current().type != END)
      advance(); // consume 'csend' itself
  };

  while (current().type == ABSTRACT || current().type == REVERSIBLE) {
    if (current().type == ABSTRACT) stmt->isAbstract = true;
    else stmt->isReversible = true;
    advance();
  }

  if (current().type != CLASS) { fail("expected 'class' keyword"); return stmt; }
  advance();

  if (current().type != IDENT) { fail("expected class name after 'class'"); return stmt; }
  stmt->name = current().text;
  advance();

  if (current().type != LPAREN) { fail("expected '(' after class name"); return stmt; }
  advance();

  if (current().type == IDENT) {
    stmt->parentClassName = current().text;
    advance();
  }

  if (current().type != RPAREN) {
    fail("expected ')' after class header (only a single optional parent class name is "
         "supported inside the parens)");
    return stmt;
  }
  advance();

  if (current().type == AT) {
    advance();
    if (current().type != IDENT || current().text != "rate") { fail("expected 'rate' after '@'"); return stmt; }
    advance();
    if (current().type != LPAREN) { fail("expected '(' after '@rate'"); return stmt; }
    advance();
    if (current().type != NUMBER) { fail("expected a numeric rate inside '@rate(...)'"); return stmt; }
    stmt->rateHz = std::stod(current().text);
    advance();
    if (current().type == IDENT)
      advance(); // optional unit suffix, e.g. "Hz" - accepted, not converted
    if (current().type != RPAREN) { fail("expected ')' to close '@rate(...)'"); return stmt; }
    advance();
    if (stmt->rateHz <= 0.0) { fail("'@rate(...)' must be a positive number"); return stmt; }
    stmt->hasRate = true;
  }

  // A colon here is optional in the original grammar - executeClassDefEnd()
  // re-lexes classHeader_ but never validates or requires what (if
  // anything) follows the header's ')'/'@rate(...)', so a trailing ':' is
  // silently tolerated (some class-declaring test scripts, e.g.
  // t38_reversibility.nc/t39_temporal_determinism.nc, write one; others
  // don't). Consume it here if present so it doesn't leak into the
  // body-parsing loop below as a stray, unrecognized token.
  if (current().type == COLON)
    advance();

  while (true) {
    if (current().type == IDENT && Parser::isClassTerm(lowerOf(current())))
      break;
    if (current().type == END)
      break;

    if (current().type == PRIVATE || current().type == PROTECTED) {
      bool isProtected = (current().type == PROTECTED);
      advance();
      if (current().type != IDENT) {
        fail(std::string("expected a field name after '") + (isProtected ? "protected" : "private") +
             "' in class '" + stmt->name + "'");
        return stmt;
      }
      stmt->restrictedFields[current().text] = isProtected;
      advance();
      while (current().type == COMMA) {
        advance();
        if (current().type != IDENT) {
          fail("expected a field name after ',' in class '" + stmt->name + "'");
          return stmt;
        }
        stmt->restrictedFields[current().text] = isProtected;
        advance();
      }
      if (current().type == SEMICOLON)
        advance();
      continue;
    }

    if (current().type == FUNCTION) {
      auto method = parseFunctionDeclNode();

      // An empty name means the header itself failed to parse (e.g.
      // missing the required trailing ':') - parseFunctionDeclNode()'s own
      // fail() already printed that error and skipped to 'fnend'. Treat
      // this exactly like the old executeClassDefEnd(): abort the whole
      // class's registration (do not also raise the separate "has no
      // body" error below, which would otherwise double-report the same
      // failure), and resync to *this class's* own terminator so tokens
      // after 'csend' don't get misparsed as top-level statements.
      if (method->name.empty()) {
        stmt->classRegistrationFailed = true;
        while (current().type != END &&
               !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
          advance();
        if (current().type != END)
          advance(); // consume 'csend'
        return stmt;
      }

      // ClassName.info / obj.info list the class's functions; a method of
      // that name could never be called.
      if (method->name == "info") {
        reportError(*this, "Syntax", method->line, 0,
                    "class '" + stmt->name + "' cannot have a method named 'info' - " +
                        stmt->name + ".info is built in (it lists the class's functions)");
        stmt->classRegistrationFailed = true;
        while (current().type != END &&
               !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
          advance();
        if (current().type != END)
          advance(); // consume 'csend'
        return stmt;
      }

      if (!stmt->isAbstract && method->body.empty()) {
        reportError(*this, "Syntax", method->line, 0,
                    "method '" + method->name + "' in non-abstract class '" + stmt->name +
                        "' has no body (mark '" + stmt->name +
                        "' abstract, or implement the method)");
        stmt->classRegistrationFailed = true;
        while (current().type != END &&
               !(current().type == IDENT && Parser::isClassTerm(lowerOf(current()))))
          advance();
        if (current().type != END)
          advance(); // consume 'csend'
        return stmt;
      }
      stmt->methods.push_back(std::move(method));
      continue;
    }

    fail("expected a method ('function ...') or a visibility declaration "
         "('private'/'protected') inside class '" + stmt->name + "', got: " + current().text);
    return stmt;
  }

  if (current().type == IDENT && Parser::isClassTerm(lowerOf(current()))) {
    advance();
  } else {
    // Reached END without finding 'csend' - matches the exact wording
    // SM_stage_02.cpp's pass-1 completion check uses today (not fail()'s
    // "Error: " prefix, which is for a malformed *interior* construct, not
    // running off the end of the file entirely).
    reportError(*this, "Syntax", stmt->line, 0, "unclosed class definition (expected 'csend')");
    stmt->classRegistrationFailed = true;
  }

  return stmt;
}

/* ================= ASSIGNMENT / EXPRESSION STATEMENT ================= */

// [a, b, c] = ... / [a, b; c, d] = ... - see parseAssignOrExprStmtNode().
// The caller has checked that the '[' at the cursor closes with a ']' that
// is followed by '='.
std::unique_ptr<Stmt> Parser::parseTargetListAssign() {
  const Token openTok = current();
  auto stmt = makeStmt(StmtKind::Assign, openTok.line);

  // Reports a syntax error and hands back a statement that parseStmtNode()
  // then discards (it resynchronizes at the next ';' or line).
  auto fail = [&](const Token &at, const std::string &msg) {
    std::cerr << "✖ Syntax Error";
    if (at.line)
      std::cerr << " (line " << at.line << ", col " << at.col << ")";
    std::cerr << ": " << msg << "\n";
    syntaxErrorCount_++;
    evaluationSucceeded_ = false;
    return std::move(stmt);
  };

  // A target is a name, A[...] (any number of bracket groups) or obj.field.
  auto assignable = [](const Expr *e) {
    if (e->kind == ExprKind::Identifier)
      return true;
    if (e->kind == ExprKind::FieldAccess)
      return e->children[0]->kind == ExprKind::Identifier;
    if (e->kind == ExprKind::Index) {
      const Expr *base = e->children[0].get();
      if (base->kind == ExprKind::Index)
        base = base->children[0].get();
      return base->kind == ExprKind::Identifier;
    }
    return false;
  };

  advance(); // '['
  std::vector<size_t> rowLengths(1, 0);
  while (current().type != RBRACKET) {
    const Token at = current();
    if (at.type == TILDE) {
      advance();
      stmt->targets.push_back(makeIdentifier("~"));
    } else if (at.type == IDENT) {
      auto target = parseFactorNode();
      if (!target)
        return fail(at, "could not read the list of variables");
      if (!assignable(target.get()))
        return fail(at, "'" + at.text + "...' cannot be assigned to - a list of variables holds "
                                        "names, A[i], obj.field or ~");
      stmt->targets.push_back(std::move(target));
    } else {
      return fail(at, "expected a name, A[i], obj.field or ~ in the list of variables, found '" +
                          at.text + "'");
    }
    rowLengths.back()++;

    if (current().type == COMMA) {
      advance();
      if (current().type == RBRACKET || current().type == SEMICOLON)
        return fail(current(), "a name is missing after ',' in the list of variables");
    } else if (current().type == SEMICOLON) {
      if (current().text.size() > 1)
        return fail(current(), "'" + current().text +
                                   "' cannot be used in a list of variables - write one ';' "
                                   "between rows, e.g. [a, b; c, d] = M");
      advance();
      rowLengths.push_back(0);
    } else if (current().type != RBRACKET) {
      return fail(current(), "unexpected '" + current().text +
                                 "' in the list of variables - separate names with ',' (and "
                                 "rows with ';')");
    }
  }
  advance(); // ']'
  advance(); // '='

  if (stmt->targets.empty())
    return fail(openTok, "the list of variables is empty - write at least one name, e.g. "
                         "[a, b] = ...");
  for (size_t r = 0; r < rowLengths.size(); r++) {
    if (rowLengths[r] != rowLengths[0] || rowLengths[r] == 0)
      return fail(openTok, "every row of a list of variables needs the same number of names, "
                           "e.g. [a, b; c, d] = M");
  }
  size_t named = 0;
  for (const auto &t : stmt->targets)
    if (!(t->kind == ExprKind::Identifier && t->text == "~"))
      named++;
  if (named == 0)
    return fail(openTok, "every entry of the list is '~' - there is nothing to assign");

  stmt->value = parseOrNode();
  if (!stmt->value)
    return stmt; // the expression already reported its error

  // [a] = expr is just a = expr.
  if (stmt->targets.size() == 1)
    stmt->targetRows = 0;
  else
    stmt->targetRows = rowLengths.size();

  stmt->suppressOutput = (current().type == SEMICOLON);
  if (stmt->suppressOutput)
    advance();
  return stmt;
}

std::unique_ptr<Stmt> Parser::parseAssignOrExprStmtNode() {
  if (current().type == IDENT) {
    std::string name = current().text;
    size_t identPos = pos;
    const size_t nameLine = current().line;
    advance();

    /* dict key / matrix element / array element assignment: A[...] = ...
       (the '[' on the same line as the name - see parseFactorAtomNode()) */
    if (current().type == LBRACKET && (nameLine == 0 || current().line == nameLine)) {
      advance();

      std::vector<std::unique_ptr<Expr>> keys;
      keys.push_back(parseIndexKeyNode());
      while (current().type == COMMA) {
        advance();
        keys.push_back(parseIndexKeyNode());
      }

      bool closedOk = (current().type == RBRACKET);
      if (closedOk)
        advance();

      /* A[row][col] = value */
      if (closedOk && keys.size() == 1 && current().type == LBRACKET) {
        size_t secondBracketPos = pos;
        advance();
        auto colKey = parseOrNode();
        bool colClosedOk = (current().type == RBRACKET);
        if (colClosedOk)
          advance();

        if (colClosedOk && current().type == ASSIGN) {
          advance();
          auto stmt = makeStmt(StmtKind::Assign, current().line);
          auto rowIndex = std::make_unique<Expr>();
          rowIndex->kind = ExprKind::Index;
          rowIndex->children.push_back(makeIdentifier(name));
          rowIndex->children.push_back(std::move(keys[0]));

          auto colIndex = std::make_unique<Expr>();
          colIndex->kind = ExprKind::Index;
          colIndex->children.push_back(std::move(rowIndex));
          colIndex->children.push_back(std::move(colKey));

          stmt->targets.push_back(std::move(colIndex));
          stmt->value = parseOrNode();
          stmt->suppressOutput = (current().type == SEMICOLON);
          if (stmt->suppressOutput) advance();
          return stmt;
        }

        // Not A[row][col] = value after all - rewind to just past the
        // first ']' so the single-bracket paths below can reparse it.
        pos = secondBracketPos;
      }

      if (closedOk && current().type == ASSIGN) {
        advance();
        auto stmt = makeStmt(StmtKind::Assign, current().line);

        auto index = std::make_unique<Expr>();
        index->kind = ExprKind::Index;
        index->children.push_back(makeIdentifier(name));
        for (auto &k : keys)
          index->children.push_back(std::move(k));

        stmt->targets.push_back(std::move(index));
        stmt->value = parseOrNode();
        stmt->suppressOutput = (current().type == SEMICOLON);
        if (stmt->suppressOutput) advance();
        return stmt;
      }

      // Not an assignment (e.g. a bare read like `A['key'];`) - rewind
      // fully to the identifier and let the expression fallback below
      // (parseFactorNode's LBRACKET read-index) handle it.
      pos = identPos;
    } else if (current().type == DOT) {
      /* object field assignment: obj.field = value; */
      advance();

      if (current().type == IDENT) {
        std::string fieldName = current().text;
        advance();

        if (current().type == ASSIGN) {
          advance();
          auto stmt = makeStmt(StmtKind::Assign, current().line);

          auto field = std::make_unique<Expr>();
          field->kind = ExprKind::FieldAccess;
          field->text = fieldName;
          field->children.push_back(makeIdentifier(name));

          stmt->targets.push_back(std::move(field));
          stmt->value = parseOrNode();
          stmt->suppressOutput = (current().type == SEMICOLON);
          if (stmt->suppressOutput) advance();
          return stmt;
        }
      }
      // Not a field assignment (e.g. `obj.Method(args);` or `obj.field;` -
      // a method call or bare field read) - rewind fully to the identifier
      // and let the expression fallback (parseFactorNode's DOT handling)
      // take it, exactly like today's parseStatement().
      pos = identPos;
    } else if (current().type == ASSIGN) {
      advance();
      auto stmt = makeStmt(StmtKind::Assign, current().line);
      stmt->targets.push_back(makeIdentifier(name));
      stmt->value = parseOrNode();
      stmt->suppressOutput = (current().type == SEMICOLON);
      if (stmt->suppressOutput) advance();
      return stmt;
    } else if (current().type == COMMA_ASSIGN || current().type == SEMI_ASSIGN) {
      /* M ,= X (append columns) / M ;= X (append rows) - a plain name
         only, see executeExtendAssign() */
      const int dir = current().type == COMMA_ASSIGN ? 1 : 2;
      advance();
      auto stmt = makeStmt(StmtKind::Assign, current().line);
      stmt->targets.push_back(makeIdentifier(name));
      stmt->extendDir = dir;
      stmt->value = parseOrNode();
      stmt->suppressOutput = (current().type == SEMICOLON);
      if (stmt->suppressOutput) advance();
      return stmt;
    } else {
      pos = identPos; // restore identifier
    }
  }

  /* A list of variables, assigned together:
       [a, b, c] = [1, 2, "car"]     each name gets its own value
       [Q, R] = qr(A)                a function with several results
       [a, b, c] = v                 the elements of a 3-element vector
       [r0, r1] = M                  the rows of a 2-row matrix (M[0], M[1])
       [a, b; c, d] = M              a 2x2 matrix, element by element
       [x, y] = deal(0)              the same value for every name
       [~, i] = max(A)               '~' skips a value
     Recognized when a '[' starting the statement is closed by a ']' that
     is directly followed by '='; anything else ([1,2] + x, [a, b] == c)
     is an ordinary expression. See executeAssignStmt() for the rules. */
  if (current().type == LBRACKET) {
    size_t close = 0;
    bool found = false;
    int depth = 0;
    for (size_t p = pos; p < tokens.size() && tokens[p].type != END; p++) {
      if (tokens[p].type == LBRACKET) {
        depth++;
      } else if (tokens[p].type == RBRACKET && --depth == 0) {
        close = p;
        found = true;
        break;
      }
    }
    if (found && close + 1 < tokens.size() && tokens[close + 1].type == ASSIGN)
      return parseTargetListAssign();
  }

  /* (B1,B2) = ... - the retired round-bracket output list (an error now,
     see below), and (A) = expr, which is just A = expr */
  if (current().type == LPAREN) {
    size_t savedPos = pos;
    advance();

    std::vector<std::string> outNames;
    bool validList = (current().type == IDENT);
    if (validList) {
      outNames.push_back(current().text);
      advance();
      while (current().type == COMMA) {
        advance();
        if (current().type != IDENT) { validList = false; break; }
        outNames.push_back(current().text);
        advance();
      }
    }

    if (validList && current().type == RPAREN) {
      size_t afterOutList = pos;
      advance();

      // A single name in parens - `(A) = expr;` - isn't the multi-output
      // call shape below (that requires >=2 names, since a single output
      // already has its own plain-assignment syntax). Previously this fell
      // through untouched: the parens got parsed as their own auto-printing
      // expression statement (since the leftover '=' isn't a semicolon),
      // producing a spurious "Unknown constant 'A'" from that phantom
      // statement in addition to whatever the real, still-unparsed
      // "= expr;" went on to do. Treat it as a plain assignment to that one
      // name instead - `(A) = expr;` and `A = expr;` should mean the same
      // thing, and this also lets the RHS be any expression, not just a
      // bare function call the way the >=2-name shape below requires.
      if (outNames.size() == 1 && current().type == ASSIGN) {
        advance();
        auto stmt = makeStmt(StmtKind::Assign, current().line);
        stmt->targets.push_back(makeIdentifier(outNames[0]));
        stmt->value = parseOrNode();
        stmt->suppressOutput = (current().type == SEMICOLON);
        if (stmt->suppressOutput) advance();
        return stmt;
      }

      // (A, B) = f(...) - the old way of writing several outputs. NC is
      // matrix-centred, so a list of outputs is written in square brackets
      // like any other list of values: [A, B] = f(...).
      if (outNames.size() >= 2 && current().type == ASSIGN) {
        const Token &open = tokens[savedPos];
        std::cerr << "✖ Syntax Error (line " << open.line << ", col " << open.col
                  << "): several outputs are written in square brackets - [" << outNames[0]
                  << ", " << outNames[1] << (outNames.size() > 2 ? ", ..." : "")
                  << "] = ..., not (" << outNames[0] << ", " << outNames[1]
                  << (outNames.size() > 2 ? ", ..." : "") << ") = ...\n";
        syntaxErrorCount_++;
        evaluationSucceeded_ = false;
        auto stmt = makeStmt(StmtKind::ExprStmt, open.line);
        return stmt; // parseStmtNode() discards it and resynchronizes
      }
      pos = afterOutList;
    }
    pos = savedPos; // not this shape - rewind and fall through
  }

  /* plain expression statement (also updates `ans`) */
  auto stmt = makeStmt(StmtKind::ExprStmt, current().line);
  stmt->expr = parseOrNode();
  stmt->suppressOutput = (current().type == SEMICOLON);
  if (stmt->suppressOutput) advance();
  return stmt;
}
