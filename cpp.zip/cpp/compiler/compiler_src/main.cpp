#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "core/ScriptManager/SM_main.h"
#include "core/line_continuation.h"
#include "core/output.h"
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "../../runtime/data/DataEngine.h"
#include "../../runtime/execution/Interrupt.h"

#ifdef NC_HAS_JIT
#include "codegen/jit_engine.h"
#endif

// =====================================================================
// IDE prompt protocol (runtime/data/WS_PROTOCOL.md, "Prompt protocol")
// =====================================================================
// Started by the IDE with NC_IDE_PROMPT=1, the interpreter never prints the
// ">> " prompt as text. The IDE paints its own prompt, so a ">> " printed by
// a script can never be mistaken for one. Instead it sends two protocol lines
// (ASCII Record Separator 0x1E, keyword, '\n'), which the IDE takes out of the
// output stream before anything is shown:
//
//   @PROMPT        the REPL is back at the top of its loop, about to read a
//                  line. Sent once per line read, internal commands included.
//   @READY <id>    answer to "@cmd ready <id>". Since stdin is one ordered
//                  stream, it can only be written after everything sent before
//                  it has finished; the IDE sends one after every command, so
//                  it marks that command's end exactly, however many lines the
//                  command had and whatever it printed.
//
// In a plain terminal (no NC_IDE_PROMPT) the ">> " prompt is printed as
// before.
static bool ideProtocolEnabled()
{
#ifdef _WIN32
  // getenv() is flagged as unsafe by the MSVC runtime (C4996); _dupenv_s()
  // is its safe replacement and hands back a heap copy we must free.
  char *buffer = nullptr;
  size_t length = 0;
  if (_dupenv_s(&buffer, &length, "NC_IDE_PROMPT") != 0 || buffer == nullptr)
    return false;
  const bool enabled = std::string(buffer) == "1";
  std::free(buffer);
  return enabled;
#else
  const char *value = std::getenv("NC_IDE_PROMPT");
  return value != nullptr && std::string(value) == "1";
#endif
}

static void emitProtocolLine(const std::string &line)
{
  std::cout << '\x1E' << line << '\n' << std::flush;
}

static std::string normalizeInput(const std::string &raw)
{
  size_t start = 0;
  size_t end = raw.size();
  while (start < end && std::isspace(static_cast<unsigned char>(raw[start])))
    ++start;
  while (end > start && std::isspace(static_cast<unsigned char>(raw[end - 1])))
    --end;
  std::string s = raw.substr(start, end - start);
  bool looksLikeWindowsDrive =
      (s.size() >= 2 && std::isalpha(static_cast<unsigned char>(s[0])) &&
       s[1] == ':');
  bool surroundedByQuotes =
      (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                         (s.front() == '\'' && s.back() == '\'')));
  if (surroundedByQuotes)
  {
    if (!looksLikeWindowsDrive || (s.size() >= 3))
      s = s.substr(1, s.size() - 2);
  }
  return s;
}

static std::string stripQuotes(std::string s)
{
  if (s.size() >= 2 && ((s.front() == '"' && s.back() == '"') ||
                        (s.front() == '\'' && s.back() == '\'')))
  {
    return s.substr(1, s.size() - 2);
  }
  return s;
}

void showSuggestions(const std::string &input) { (void)input; }

static bool isEmptyLine(const std::string &s)
{
  return s.find_first_not_of(" \t\r\n") == std::string::npos;
}

static std::string trimSpaces(const std::string &s)
{
  size_t start = s.find_first_not_of(" \t\r\n");
  if (start == std::string::npos)
    return "";
  size_t end = s.find_last_not_of(" \t\r\n");
  return s.substr(start, end - start + 1);
}

int main(int argc, char *argv[])
{
  // Count error lines on stderr - an error stops the script (error_lines.h).
  nc::errorlines::install();
  Parser parser;
  const bool ideProtocol = ideProtocolEnabled();

  // ---- Data layer + cooperative Stop (runtime/data, runtime/execution) ----
  // NC_SESSION_DIR is set by the IDE: it switches on the JSON workspace
  // channel and the session autosave, and is where the IDE drops
  // interrupt.flag to stop a running command.
  ncdata::DataEngine &dataEngine = ncdata::DataEngine::instance();
  dataEngine.configureFromEnvironment();
  nc::Interrupt::configure(dataEngine.sessionDir().u8string());

#ifdef NC_HAS_JIT
  // JIT dispatch state. On by default (Phase D of the codegen/JIT roadmap -
  // flipped once real corpus testing, not just the parity harness, showed
  // it byte-for-byte matching the tree-walker across every script except
  // two pre-existing, JIT-unrelated dict-iteration-order-nondeterminism
  // cases). The tree-walker is still the correct baseline and the
  // guaranteed fallback for anything JIT can't handle (per-statement,
  // automatic) or anything it gets wrong - toggle back with "@cmd jit off"
  // at any time; "@cmd jit on" re-enables it.
  bool jitEnabled = true;
  std::unique_ptr<JitEngine> jitEngine = std::make_unique<JitEngine>();
#endif
  std::filesystem::path launchWorkingDirectory =
      std::filesystem::current_path();
  std::filesystem::path applicationDirectory;
  if (argc > 0 && argv[0] != nullptr)
  {
    std::filesystem::path executablePath =
        std::filesystem::absolute(argv[0]).lexically_normal();
    applicationDirectory = executablePath.parent_path();
  }

  ScriptManager manager(applicationDirectory, launchWorkingDirectory);
  manager.init();
  // A script run by name works on this REPL's workspace directly (it used
  // to go through variables.txt).
  manager.setWorkspaceParser(&parser);

  // The IDE restarting nc.exe (Stop that had to kill, a removed path
  // folder, a crash) asks for the previous workspace back with NC_RESTORE=1.
  dataEngine.restoreSessionIfRequested(parser.memory, parser.insertionOrder);
#ifdef NC_HAS_JIT
  // Script-by-name execution (ScriptManager::executeFile()) picks up the
  // same default-on state as the REPL loop below - see setJitEngine()'s
  // own comment.
  manager.setJitEngine(jitEnabled, jitEngine.get());
#endif

  if (argc > 1)
  {
    std::ostringstream argBuilder;
    for (int i = 1; i < argc; ++i)
    {
      if (i > 1)
        argBuilder << ' ';
      argBuilder << argv[i];
    }
    std::string rawArg = argBuilder.str();
    if (manager.tryExecuteInputAsFile(rawArg))
    {
      return 0;
    }
    std::cerr << "Error: Failed to execute file: " << rawArg << std::endl;
    return 1;
  }

  std::cin.clear();

  // ---- Multi-line construct buffering ----
  // The REPL reads one line at a time from stdin, but an if/for/while/
  // function/class can span many lines/prompts. Rather than the Parser
  // itself tracking "which raw-text block am I accumulating" (the old
  // pendingXBlock_/inXBlock_ state machine, retired along with
  // ScriptManager's own equivalent in SM_stage_02.cpp - see parseProgram()/
  // parseStmtNode() in parser_program.cpp), this loop only needs to decide
  // *when* a complete statement's text has been typed. Once it has, the
  // whole thing is lexed and parsed as one token stream via
  // parser.parseStmtNode() - exactly like every other statement, whether
  // it came from a file or the REPL - which is what actually handles
  // nested if/for/while and elseif/else (no special-casing needed for
  // those here: they're just more lines of body text until the construct's
  // own terminator keyword appears).
  enum class ReplBlockKind { None, If, For, While, Function, Class };
  ReplBlockKind replMode = ReplBlockKind::None;
  std::string replBuffer;
  // Same-type nesting depth: a nested if/for/while shares its terminator
  // keyword with the outer one, so a flat "first terminator wins" scan
  // would stop the outer construct's text capture at the inner one's
  // terminator. Function/class don't need this - they can't nest.
  int replIfDepth = 0;
  int replForDepth = 0;
  int replWhileDepth = 0;

  auto discardReplBlock = [&]()
  {
    replMode = ReplBlockKind::None;
    replBuffer.clear();
    replIfDepth = 0;
    replForDepth = 0;
    replWhileDepth = 0;
  };

  auto toLowerStr = [](std::string s) {
    for (char &ch : s)
      ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    return s;
  };

  // Runs EVERY statement in one lexed line / block, in order:
  // `A[1,2] = 99; A[2,1] = 99;` is two statements. (Before 2026-10 only the
  // first statement of a line ran - everything after its ';' was silently
  // dropped.) Stops early on a top-level `return;`, a failed require/ensure,
  // an error (Parser::errorAbort_), or Stop.
  //
  // The whole command is parsed first: one with a syntax error does not run
  // at all - not even the statements before the bad one (`a = 1; b = (2;`
  // assigns nothing), the same rule a script follows. Parsing has no side
  // effects, and a function's body is copied when it is registered, so the
  // Program can go once the command has run.
  auto runAllStatements = [&](const std::vector<Token> &toks)
  {
    const int errsBefore = parser.syntaxErrorCount_;
    Program program = parser.parseProgram(toks);
    if (parser.syntaxErrorCount_ != errsBefore)
      return;
    parser.clearErrorAbort();
    for (const auto &stmtPtr : program.statements)
    {
      Stmt *stmt = stmtPtr.get();
      const unsigned long errorsBefore = nc::errorlines::count();
      {
        bool jitRan = false;
#ifdef NC_HAS_JIT
        // Step-into pausing (pauseForStep(), parser_exec_stmt.cpp) only exists
        // in the tree-walking evaluator - codegen's own For/While handling
        // (codegen.cpp) has no pause hook, so a JIT'd loop would silently run
        // to completion and skip every @STEPAT. Force the tree-walker while a
        // step-into session is armed.
        //
        // A bare expression whose value is displayed (`3 + 4`, `x`, `f(2)`
        // with no semicolon) also goes to the tree-walker: its MATLAB-style
        // "ans =" display lives in executeStmt(), and an expression costs
        // nothing to interpret. Loops, functions, classes and assignments
        // still take the JIT.
        const bool displaysAns =
            stmt->kind == StmtKind::ExprStmt && !stmt->suppressOutput;
        if (jitEnabled && jitEngine && !parser.isDebugStepMode() && !displaysAns)
          jitRan = jitEngine->runStmt(stmt, parser);
#endif
        if (!jitRan)
          parser.executeStmt(stmt);
      }
      parser.noteStatementResult(stmt->line, errorsBefore);
      const bool failed = parser.errorAbort_;
      parser.clearErrorAbort();
      // The IDE hears about the updated workspace from the @WS line sent
      // just before the next prompt (top of the REPL loop).
      if (parser.consumeTopLevelStopSignal() || failed || nc::Interrupt::requested())
        break;
    }
  };

  // Lexes and runs one complete multi-line construct's accumulated text.
  auto runReplStatement = [&](const std::string &text)
  {
    Lexer lex(text);
    auto toks = lex.tokenize();
    // A lexical error ("unexpected character") is a syntax error too: the
    // construct does not run, as with any other syntax error.
    if (lex.errorCount() > 0)
      return;
    runAllStatements(toks);
  };

  while (true)
  {
    // ---- Between commands: the only moment the workspace is complete ----
    if (nc::Interrupt::requested())
    {
      std::cout << "Execution interrupted by user." << std::endl;
      parser.setDebugStepMode(false);
    }
    // A stop request belongs to the command it interrupted; clear it (and
    // any flag file left behind) before the next one. A flag the IDE
    // creates after this point is for the command about to be read.
    nc::Interrupt::clear();
    // The IDE's variable list: one @WS line when anything changed. Not
    // while a multi-line construct is still being typed (nothing ran).
    if (replMode == ReplBlockKind::None)
      dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder());

    // Every command starts a fresh display group: its first "name =" block
    // opens with a blank line under the echoed command (MATLAB loose).
    resetDisplaySpacing();

    std::string input;
    if (ideProtocol)
      emitProtocolLine("@PROMPT");
    else
      std::cout << ">> " << std::flush;
    if (!std::getline(std::cin, input))
    {
      if (!ideProtocol)
        std::cout << "\n";
      break;
    }
    input = readLogicalLine(std::cin, input);
    if (isEmptyLine(input))
      continue;
    std::string trimmedInput = normalizeInput(input);
    if (trimmedInput.empty())
      continue;

    // --------- Internal command isolation (IDE hook) ---------
    // Handled BEFORE the multi-line buffer below: an IDE command is never
    // part of a block, and appending one to a half-read block (the old
    // order) corrupted the block and swallowed the command.
    // IDE sends commands using: @cmd setpwd "..."
    if (trimmedInput.rfind("@cmd ", 0) == 0)
    {
      std::string cmd = trimmedInput.substr(5);
      if (cmd.rfind("setpwd ", 0) == 0)
      {
        std::string path = cmd.substr(7);
        path = stripQuotes(path);
        manager.setWorkspaceDirectory(std::filesystem::u8path(path));
        // Relative save_workspace()/load_workspace() paths follow it.
        dataEngine.setCurrentFolder(std::filesystem::u8path(path));
      }
      // ============================================================
      // Command Window width: "@cmd width <characters>". A matrix wider
      // than this is printed in column groups ("Columns 0 through 12"),
      // the way MATLAB does (output.cpp, matrixGrid()). The IDE should
      // send it once at start-up and again whenever the Command Window is
      // resized: visible width in pixels / width of one character of its
      // monospace font. Without it the width is NC_DISPLAY_WIDTH, or 80.
      // ============================================================
      else if (cmd.rfind("width ", 0) == 0)
      {
        const long width = std::strtol(trimSpaces(cmd.substr(6)).c_str(), nullptr, 10);
        if (width > 0)
          setDisplayWidth(static_cast<size_t>(width));
      }
      // ============================================================
      // Prompt protocol: the end of a command. The IDE sends
      // "@cmd ready <id>" after every command's lines; reading it means
      // everything before it has run, so the answer marks the command's
      // end exactly. If a multi-line construct is still open here, the
      // IDE thought the input complete and this loop did not (a header
      // without its terminator, say): the construct can never finish, so
      // it is dropped with an error instead of waiting for ever.
      // ============================================================
      else if (cmd == "ready" || cmd.rfind("ready ", 0) == 0)
      {
        if (replMode != ReplBlockKind::None)
        {
          std::cout << "Error: the multi-line construct was not complete and has been discarded."
                    << std::endl;
          discardReplBlock();
        }
        std::string token = cmd.size() > 5 ? trimSpaces(cmd.substr(5)) : std::string();
        emitProtocolLine(token.empty() ? std::string("@READY") : "@READY " + token);
      }
      // ============================================================
      // Workspace channel (runtime/data/WS_PROTOCOL.md).
      //   wsnow (old name: syncws) - send @WS now, changed or not.
      //   getvar <name>            - send @VAR with that variable's full
      //                              value.
      //   clearvar <name>          - remove one global variable (the
      //                              IDE's "clear name").
      // ============================================================
      else if (cmd == "wsnow" || cmd == "syncws")
      {
        dataEngine.emitWorkspaceIfChanged(parser.globalMemory(), parser.globalInsertionOrder(),
                                          /*force=*/true);
      }
      else if (cmd.rfind("getvar ", 0) == 0)
      {
        dataEngine.emitVariable(stripQuotes(trimSpaces(cmd.substr(7))), parser.globalMemory());
      }
      else if (cmd.rfind("clearvar ", 0) == 0)
      {
        parser.removeGlobalVariable(stripQuotes(trimSpaces(cmd.substr(9))));
      }
#ifdef NC_HAS_JIT
      // ============================================================
      // JIT dispatch toggle. On by default (see jitEnabled's own comment
      // above) - the tree-walker remains the always-correct fallback. JIT
      // is strictly an accelerant: either fully applied per statement or
      // not applied at all, never partially. Unsupported statements fall
      // back silently.
      // ============================================================
      else if (cmd == "jit on")
      {
        jitEnabled = true;
        // Script-by-name execution (ScriptManager::executeFile(), a
        // completely separate code path from this REPL loop) has no way to
        // type "@cmd jit on" itself - keep it in sync with this same
        // session-wide toggle instead of leaving it permanently off. See
        // SM_main.h's setJitEngine() comment.
        manager.setJitEngine(jitEnabled, jitEngine.get());
        std::cout << "JIT dispatch enabled." << std::endl;
      }
      else if (cmd == "jit off")
      {
        jitEnabled = false;
        manager.setJitEngine(jitEnabled, jitEngine.get());
        std::cout << "JIT dispatch disabled." << std::endl;
      }
      else if (cmd == "jit status")
      {
        std::cout << "JIT dispatch: " << (jitEnabled ? "on" : "off") << std::endl;
      }
#endif
      // ============================================================
      // Step feature: completion sentinel (kept for older IDEs; the
      // prompt protocol's "@cmd ready" does the same job now).
      // ============================================================
      else if (cmd.rfind("stepmark ", 0) == 0)
      {
        std::string token = cmd.substr(9);
        while (!token.empty() && std::isspace(static_cast<unsigned char>(token.back())))
          token.pop_back();
        std::cout << "@STEPMARK " << token << std::endl;
      }
      // ============================================================
      // Step-into feature: the Java IDE sends "@cmd stepinto"
      // immediately before a block Unit's source lines (a for/while/if/
      // function/class header + body). It arms debugStepMode_ on the one
      // persistent `parser` instance, so executeStmtList() (parser_exec_
      // stmt.cpp) pauses after each statement it executes - including each
      // loop iteration - printing "@STEPAT <line>" and blocking on stdin
      // for "@cmd stepnext"/"@cmd stepdone" (see pauseForStep() there).
      // "@cmd stepdone" here (sent when idle, not while paused) is a plain
      // safety valve to force pausing back off if the IDE ever needs to.
      // ============================================================
      else if (cmd == "stepinto")
      {
        parser.setDebugStepMode(true);
      }
      else if (cmd == "stepdone")
      {
        parser.setDebugStepMode(false);
      }
      continue;
    }

    // --------- Already inside a multi-line construct ---------
    if (replMode != ReplBlockKind::None)
    {
      replBuffer += input;
      replBuffer += "\n";
      std::string lower = toLowerStr(trimmedInput);

      switch (replMode)
      {
      case ReplBlockKind::If:
      {
        bool isNestedIfHeader = lower.rfind("if", 0) == 0 &&
            (lower.size() == 2 || std::isspace((unsigned char)lower[2]) || lower[2] == '(');
        if (isNestedIfHeader)
          replIfDepth++;
        else if (Parser::isIfTerm(lower))
        {
          if (replIfDepth > 0)
            replIfDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      }
      case ReplBlockKind::For:
      {
        bool isNestedForHeader = lower.rfind("for", 0) == 0 &&
            (lower.size() == 3 || std::isspace((unsigned char)lower[3]));
        if (isNestedForHeader)
          replForDepth++;
        else if (Parser::isForTerm(lower))
        {
          if (replForDepth > 0)
            replForDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      }
      case ReplBlockKind::While:
      {
        bool isNestedWhileHeader = lower.rfind("while", 0) == 0 &&
            (lower.size() == 5 || std::isspace((unsigned char)lower[5]) || lower[5] == '(');
        if (isNestedWhileHeader)
          replWhileDepth++;
        else if (Parser::isWhileTerm(lower))
        {
          if (replWhileDepth > 0)
            replWhileDepth--;
          else
          {
            std::string block = replBuffer;
            discardReplBlock();
            runReplStatement(block);
          }
        }
        break;
      }
      case ReplBlockKind::Function:
        if (Parser::isFunctionTerm(lower))
        {
          std::string block = replBuffer;
          discardReplBlock();
          runReplStatement(block);
        }
        break;
      case ReplBlockKind::Class:
        if (Parser::isClassTerm(lower))
        {
          std::string block = replBuffer;
          discardReplBlock();
          runReplStatement(block);
        }
        break;
      case ReplBlockKind::None:
        break; // unreachable (outer if excludes this)
      }
      continue;
    }

    // --------- Builtins / interpreter commands ---------
    if (trimmedInput == "exit")
      break;
    // clear: empty the workspace. clear <name>: remove one variable.
    // cls / clc: screen only - nothing to do here (the IDE clears its own
    // screen and never sends these).
    if (trimmedInput == "clear")
    {
      parser.clearGlobalWorkspace();
      continue;
    }
    if (trimmedInput.rfind("clear ", 0) == 0)
    {
      std::string name = stripQuotes(trimSpaces(trimmedInput.substr(6)));
      if (!name.empty() && name.back() == ';')
        name = trimSpaces(name.substr(0, name.size() - 1));
      if (!parser.removeGlobalVariable(name))
        std::cerr << "clear: '" << name << "' is not in the workspace." << std::endl;
      continue;
    }
    if (trimmedInput == "cls" || trimmedInput == "clc")
      continue;
    if (trimmedInput.rfind("addpath ", 0) == 0)
    {
      std::string path = trimmedInput.substr(8);
      path = stripQuotes(path);
      manager.addPath(path);
      continue;
    }
    if (trimmedInput.rfind("rmpath ", 0) == 0)
    {
      std::string path = trimmedInput.substr(7);
      path = stripQuotes(path);
      manager.removePath(path);
      continue;
    }
    if (trimmedInput == "rehash" || trimmedInput == "reindex")
    {
      manager.rehash();
      std::cout << "Rehashed script cache\n";
      continue;
    }
    if (trimmedInput == "path")
    {
      manager.printPath();
      continue;
    }
    if (trimmedInput == "pwd")
    {
      manager.printPwd();
      continue;
    }
    if (trimmedInput.rfind("whichall ", 0) == 0)
    {
      manager.whichAll(trimmedInput.substr(9));
      continue;
    }
    if (trimmedInput.rfind("which ", 0) == 0)
    {
      std::string argument = trimmedInput.substr(6);
      if (argument.rfind("-all ", 0) == 0)
        manager.whichAll(argument.substr(5));
      else
        manager.which(argument);
      continue;
    }

    // --------- Script name execution by workspace search ---------
    // The script shares this REPL's workspace (ScriptManager::
    // setWorkspaceParser above): its variables are simply here afterwards.
    if (manager.tryExecuteInputAsFile(trimmedInput))
      continue;

    // --------- Normal expression execution / multi-line construct entry ---------
    showSuggestions(input);
    Lexer lexer(trimmedInput);
    auto tokens = lexer.tokenize();
    if (tokens.empty() || tokens[0].type == END)
      continue; // comment-only line - nothing to do

    // A line starting with one of these opens a construct that (almost
    // always) spans further lines/prompts - buffer it instead of trying to
    // parse it as one complete statement right away. The header line's
    // full text still needs to end up in the buffer (parseIfStmtNode() etc.
    // parse header and body from one continuous token stream), so it's
    // added here exactly like every subsequent line is added above.
    TokenType first = tokens[0].type;
    if (first == IF || first == FOR || first == WHILE || first == FUNCTION ||
        first == CLASS || first == ABSTRACT || first == REVERSIBLE)
    {
      replBuffer = input;
      replBuffer += "\n";
      if (first == IF) { replMode = ReplBlockKind::If; replIfDepth = 0; }
      else if (first == FOR) { replMode = ReplBlockKind::For; replForDepth = 0; }
      else if (first == WHILE) { replMode = ReplBlockKind::While; replWhileDepth = 0; }
      else if (first == FUNCTION) { replMode = ReplBlockKind::Function; }
      else { replMode = ReplBlockKind::Class; }
      continue;
    }

    if (lexer.errorCount() > 0)
      continue; // a lexical error (already reported): the command does not run
    runAllStatements(tokens);
  }
  return 0;
}
