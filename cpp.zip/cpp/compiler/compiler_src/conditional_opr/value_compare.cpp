#include "conditional_opr.h"
#include <cmath>
#include <complex>
#include <string>
#include <vector>

#include "../../../runtime/interpreter/ops/integer/integer.h"

bool g_lastConditionalOk = true;

/* ================= VALUE COMPARISON CORE =================
 *
 * Every comparison operator (==, !=, <, >, <=, >=) used to compare only
 * `Value::number`. That field is 0 for EVERY non-numeric Value — a string
 * keeps its content in `text`, an array in `array`, a matrix in `matrix`,
 * a dict/object in `dictMap` — so `"str" == "str2"` was really `0 == 0`
 * and reported true, as did comparing any two arrays, matrices or dicts.
 * The operators were effectively answering "are these both non-numbers?"
 * instead of "do these hold the same value".
 *
 * These helpers are the single place where "same value" and "orderable"
 * are defined, so all six operators (plus is_in/is_not_in) agree.
 */

/* The variant a Value currently holds. Two Values of different kinds are
 * never equal and can never be ordered against each other. */
ValueKind valueKindOf(const Value &v) {
  if (v.isObject)
    return VK_OBJECT;
  if (v.isDict)
    return VK_DICT;
  if (v.isMatrix)
    return VK_MATRIX;
  if (v.isArray)
    return VK_ARRAY;
  if (v.isText)
    return VK_TEXT;
  return VK_NUMBER;
}

const char *valueKindName(const Value &v) {
  switch (valueKindOf(v)) {
  case VK_OBJECT:
    return "object";
  case VK_DICT:
    return "dict";
  case VK_MATRIX:
    return "matrix";
  case VK_ARRAY:
    return "array";
  case VK_TEXT:
    return "string";
  default:
    return "number";
  }
}

/* Structural ("deep") equality — recurses through arrays, matrices, dicts
 * and object fields so equality reflects the values actually held, not the
 * unused `number` slot that every container leaves at 0. */
bool valuesDeepEqual(const Value &a, const Value &b) {
  ValueKind ka = valueKindOf(a);
  ValueKind kb = valueKindOf(b);

  // A string is never equal to a number, an array never equal to a dict,
  // and so on. Not an error — "are these equal?" has the answer "no".
  if (ka != kb)
    return false;

  switch (ka) {
  case VK_NUMBER:
    // Two integers compare exactly (int64 values beyond 2^53 differ even
    // where their float64 mirrors coincide). Anything else compares by
    // number, so int8(5) == 5 and true == 1, as in MATLAB.
    if (a.isInt() && b.isInt())
      return compareIntegers(a, b) == 0;
    // Both parts: a real number is a complex one with imaginary part 0, so
    // 5 equals complex(5, 0) but not 5+2i.
    return a.number == b.number &&
           (a.isComplex ? a.imag : 0.0) == (b.isComplex ? b.imag : 0.0);

  case VK_TEXT:
    return a.text() == b.text();

  case VK_ARRAY: {
    if (a.length() != b.length())
      return false;
    for (size_t i = 0; i < a.length(); i++) {
      if (!valuesDeepEqual(a.at(i), b.at(i)))
        return false;
    }
    return true;
  }

  case VK_MATRIX: {
    if (a.rows() != b.rows())
      return false;
    for (size_t r = 0; r < a.rows(); r++) {
      if (a.rowLength(r) != b.rowLength(r))
        return false;
      for (size_t c = 0; c < a.rowLength(r); c++) {
        if (!valuesDeepEqual(a.at(r, c), b.at(r, c)))
          return false;
      }
    }
    return true;
  }

  case VK_OBJECT:
    // Two instances of different classes are different values even if
    // their fields happen to line up.
    if (a.className() != b.className())
      return false;
    // fall through — an object's fields live in dictMap, same as a dict's
    [[fallthrough]];

  case VK_DICT: {
    if (a.dict().size() != b.dict().size())
      return false;
    for (const auto &entry : a.dict()) {
      auto it = b.dict().find(entry.first);
      if (it == b.dict().end())
        return false;
      if (!valuesDeepEqual(entry.second, it->second))
        return false;
    }
    return true;
  }
  }

  return false;
}

namespace {
// Every element of a non-empty array/matrix is truthy - the MATLAB rule (see
// valueIsTruthy()'s declaration). The packed (all-plain-number) form is read
// straight from its buffer; a complex element counts as true unless both of
// its parts are zero.
bool allElementsTruthy(const Value &v) {
  if (v.isPacked()) {
    const size_t n = v.isMatrix ? v.rows() * v.cols() : v.length();
    const double *data = v.packedData();
    for (size_t k = 0; k < n; k++)
      if (data[k] == 0.0)
        return false;
    return true;
  }
  if (v.isPackedComplex()) {
    const size_t n = v.isMatrix ? v.rows() * v.cols() : v.length();
    const std::complex<double> *data = v.packedComplexData();
    for (size_t k = 0; k < n; k++)
      if (data[k] == std::complex<double>(0.0, 0.0))
        return false;
    return true;
  }
  if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        if (!valueIsTruthy(v.at(r, c)))
          return false;
    return true;
  }
  for (size_t i = 0; i < v.length(); i++)
    if (!valueIsTruthy(v.at(i)))
      return false;
  return true;
}
} // namespace

bool valueIsTruthy(const Value &v) {
  // A function reference always refers to something, like an object. It
  // used to fall through to the number case and read as 0 (false).
  if (v.isFunctionRef)
    return true;
  switch (valueKindOf(v)) {
  case VK_TEXT:
    return !v.text().empty();
  case VK_ARRAY:
    return v.length() != 0 && allElementsTruthy(v);
  case VK_MATRIX:
    return v.rows() != 0 && v.cols() != 0 && allElementsTruthy(v);
  case VK_DICT:
    return !v.dict().empty();
  case VK_OBJECT:
    // An object instance always "exists" - there's no empty/non-empty
    // distinction for one the way there is for a container.
    return true;
  case VK_NUMBER:
  default:
    // A complex number is zero only when both parts are.
    return v.number != 0.0 || (v.isComplex && v.imag != 0.0);
  }
}

/* Only numbers and strings have a meaningful ordering. Ordering two
 * matrices or two dicts is not a smaller-or-larger question, so the parser
 * rejects it rather than silently answering with the 0-vs-0 comparison
 * that produced the original bug. */
bool valueIsOrderable(const Value &v) {
  ValueKind k = valueKindOf(v);
  return k == VK_NUMBER || k == VK_TEXT;
}

/* -1 / 0 / +1, for the four ordering operators. Only ever called after
 * parseComparison() has confirmed both sides are orderable and of the same
 * kind. */
int valueOrderCompare(const Value &a, const Value &b) {
  if (valueKindOf(a) == VK_TEXT) {
    if (a.text() < b.text())
      return -1;
    return (a.text() == b.text()) ? 0 : 1;
  }

  if (a.isInt() && b.isInt())
    return compareIntegers(a, b);

  // Complex numbers are ordered by their real part alone (the MATLAB
  // rule); `number` is the real part, so the imaginary part plays no role.
  if (a.number < b.number)
    return -1;
  return (a.number == b.number) ? 0 : 1;
}

bool valuesUnordered(const Value &a, const Value &b) {
  if (valueKindOf(a) != VK_NUMBER || valueKindOf(b) != VK_NUMBER)
    return false;
  return std::isnan(a.number) || std::isnan(b.number);
}

Value toBoolResult(const Value &v) {
  if (v.isBool())
    return v;
  if (v.isText || v.isArray || v.isMatrix || v.isDict || v.isObject || v.isFunctionRef ||
      v.isComplex)
    return v;
  return Value::boolean(v.number != 0.0);
}

/* ================= CONTAINER COMPARISON =================
 *
 * ==, !=, <, >, <=, >= with an array or matrix on either side. The rules
 * (container vs one value -> true/false per element; two same-size
 * containers -> one true/false; anything else an error) are documented on
 * compareContainers()'s declaration in conditional_opr.h. Called from
 * Parser::evaluateComparisonValues() (parser_expression.cpp) ahead of the
 * scalar checks, which is also the path JIT-compiled comparisons take
 * (nc_bridge_comparison_checked), so both execution paths agree.
 */

namespace {

bool isComparisonOp(const std::string &op) {
  return op == "==" || op == "!=" || op == "<" || op == ">" || op == "<=" || op == ">=";
}

// "a 3x3 matrix", "an array of length 4", "a dict", ... for error messages.
std::string describeForCompare(const Value &v) {
  if (v.isMatrix)
    return "a " + std::to_string(v.rows()) + "x" + std::to_string(v.cols()) + " matrix";
  if (v.isArray)
    return "an array of length " + std::to_string(v.length());
  if (v.isFunctionRef)
    return "a function reference";
  const std::string kind = valueKindName(v);
  return (kind == "array" || kind == "object" ? "an " : "a ") + kind;
}

bool isRectangular(const Value &m) {
  for (size_t r = 0; r < m.rows(); r++)
    if (m.rowLength(r) != m.cols())
      return false;
  return true;
}

// One element pair, with exactly the scalar operator's rules.
bool compareElements(const std::string &op, const Value &x, const Value &y, bool &result,
                     std::string &err) {
  if (x.dimL != y.dimL || x.dimT != y.dimT || x.dimM != y.dimM) {
    err = "incompatible units in comparison";
    return false;
  }
  if (op == "==" || op == "!=") {
    const bool equal = valuesDeepEqual(x, y);
    result = (op == "==") ? equal : !equal;
    return true;
  }
  if (!valueIsOrderable(x) || !valueIsOrderable(y) || valueKindOf(x) != valueKindOf(y)) {
    err = std::string("cannot order-compare ") + valueKindName(x) + " with " + valueKindName(y);
    return false;
  }
  if (valuesUnordered(x, y)) { // NaN: every ordering is false (IEEE-754)
    result = false;
    return true;
  }
  const int c = valueOrderCompare(x, y);
  result = (op == "<") ? c < 0 : (op == ">") ? c > 0 : (op == "<=") ? c <= 0 : c >= 0;
  return true;
}

} // namespace

ContainerCompare compareContainers(const std::string &op, const Value &a, const Value &b,
                                   Value &out, std::string &err) {
  const bool aC = a.isArray || a.isMatrix;
  const bool bC = b.isArray || b.isMatrix;
  if (!isComparisonOp(op) || (!aC && !bC))
    return ContainerCompare::NotApplicable;

  /* ---- two containers: same kind and size -> ONE true/false ---- */
  if (aC && bC) {
    const bool sameKind = a.isMatrix == b.isMatrix;
    bool sameSize = sameKind;
    if (sameKind && a.isMatrix) {
      if (!isRectangular(a) || !isRectangular(b)) {
        err = "cannot compare a matrix whose rows have different lengths";
        return ContainerCompare::Error;
      }
      sameSize = a.rows() == b.rows() && a.cols() == b.cols();
    } else if (sameKind) {
      sameSize = a.length() == b.length();
    }
    if (!sameKind || !sameSize) {
      err = "cannot compare " + describeForCompare(a) + " with " + describeForCompare(b) +
            " - both sides must have the same size, or one side must be a single value";
      return ContainerCompare::Error;
    }

    // `!=` is "not all equal", so it is computed as the negation of `==`.
    const std::string elemOp = (op == "!=") ? "==" : op;
    bool all = true;
    auto visit = [&](const Value &x, const Value &y) -> bool {
      bool r = false;
      if (!compareElements(elemOp, x, y, r, err))
        return false;
      if (!r)
        all = false;
      return true;
    };
    if (a.isMatrix) {
      for (size_t r = 0; r < a.rows(); r++)
        for (size_t c = 0; c < a.cols(); c++)
          if (!visit(a.at(r, c), b.at(r, c)))
            return ContainerCompare::Error;
    } else {
      for (size_t i = 0; i < a.length(); i++)
        if (!visit(a.at(i), b.at(i)))
          return ContainerCompare::Error;
    }
    out = Value::boolean(op == "!=" ? !all : all);
    return ContainerCompare::Ok;
  }

  /* ---- container vs one value -> true/false per element ---- */
  const Value &cont = aC ? a : b;
  const Value &single = aC ? b : a;
  if (single.isDict || single.isObject || single.isFunctionRef) {
    err = "cannot compare " + describeForCompare(a) + " with " + describeForCompare(b);
    return ContainerCompare::Error;
  }

  auto elementResult = [&](const Value &elem, Value &cell) -> bool {
    bool r = false;
    // Keep the operand order: `2 < A` compares 2 with each element.
    if (!compareElements(op, aC ? elem : single, aC ? single : elem, r, err))
      return false;
    cell = Value::boolean(r);
    return true;
  };

  if (cont.isMatrix) {
    if (!isRectangular(cont)) {
      err = "cannot compare a matrix whose rows have different lengths";
      return ContainerCompare::Error;
    }
    std::vector<std::vector<Value>> rows(cont.rows());
    for (size_t r = 0; r < cont.rows(); r++) {
      rows[r].resize(cont.cols());
      for (size_t c = 0; c < cont.cols(); c++)
        if (!elementResult(cont.at(r, c), rows[r][c]))
          return ContainerCompare::Error;
    }
    out = Value(std::move(rows));
    return ContainerCompare::Ok;
  }

  std::vector<Value> elems(cont.length());
  for (size_t i = 0; i < cont.length(); i++)
    if (!elementResult(cont.at(i), elems[i]))
      return ContainerCompare::Error;
  out = Value(std::move(elems));
  return ContainerCompare::Ok;
}
