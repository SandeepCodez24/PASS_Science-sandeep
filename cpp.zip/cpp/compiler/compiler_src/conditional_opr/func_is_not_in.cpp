#include "conditional_opr.h"

/* ================= NOT IN / IS_NOT_IN ================= */

// Exact negation of logical_is_in - see the rules there. A container it
// rejects stays an error here too (g_lastConditionalOk is already false).
Value logical_is_not_in(Value elem, Value container) {
  Value found = logical_is_in(elem, container);
  if (!g_lastConditionalOk)
    return Value(0);
  return Value(found.number != 0.0 ? 0 : 1);
}
