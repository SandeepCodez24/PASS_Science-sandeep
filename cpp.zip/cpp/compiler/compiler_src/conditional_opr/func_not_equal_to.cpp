#include "conditional_opr.h"

/* ================= NOT EQUAL TO (!=) ================= */

Value logical_neq(Value a, Value b) { return Value(a.number != b.number); }
