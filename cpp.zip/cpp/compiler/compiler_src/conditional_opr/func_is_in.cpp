#include "conditional_opr.h"

/* ================= IS_IN ================= */

static bool valuesEqual(const Value &a, const Value &b) {
  if (a.isText && b.isText)
    return a.text == b.text;
  if (a.isText != b.isText)
    return false;
  return a.number == b.number;
}

Value logical_is_in(Value elem, Value container) {
  if (!container.isArray)
    return Value(0);

  for (const Value &item : container.array) {
    if (valuesEqual(elem, item))
      return Value(1);
  }

  return Value(0);
}
