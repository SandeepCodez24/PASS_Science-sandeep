#include "conditional_opr.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/matrix/nd_array.h"
#include "output.h"
#include <iostream>

/* ================= IN / IS_IN ================= */

// `x in A` and `x is_in A` are the same operator; `not in` / `is_not_in` is
// its negation (func_is_not_in.cpp). What the right-hand side can be:
//   matrix (any shape, N-D too) - x is one of its elements, or, for a vector
//                                 x, one of its rows: [3,4] in [1,2;3,4]
//   dict                        - x is one of its keys
//   text                        - x is text found inside it: "ell" in "hello"
// It shares valuesDeepEqual() with ==/!=, so membership and equality can
// never disagree. Anything else (a plain number) has no elements to search
// and is an error, rather than the "not found" a real search can answer.

// A vector `elem` against each row of a 2-D matrix `container`.
static bool holdsAsRow(const Value &elem, const Value &container) {
  if (container.isND() || !matIsVectorShape(elem))
    return false;
  const std::vector<Value> cells = nd::rowMajorCells(elem);
  for (size_t r = 0; r < container.rows(); r++) {
    if (container.rowLength(r) != cells.size())
      continue;
    bool same = true;
    for (size_t c = 0; same && c < cells.size(); c++)
      same = valuesDeepEqual(cells[c], container.at(r, c));
    if (same)
      return true;
  }
  return false;
}

Value logical_is_in(Value elem, Value container) {
  // A dict: is elem one of its keys? (`k in d` - it used to need
  // `k in keys(d)`.) A key is spelled the way dict() spells it.
  if (container.isDict) {
    if (!elem.isText && valueKindOf(elem) != VK_NUMBER) {
      std::cerr << "Error: a dict key is a number or text, not a " << valueKindName(elem)
                << "\n";
      g_lastConditionalOk = false;
      return Value(0);
    }
    const std::string key = elem.isText ? elem.text() : formatNumber(elem.number);
    return Value(container.dict().count(key) ? 1 : 0);
  }

  // Text never stands in for a number, so only text can be inside text.
  if (container.isText)
    return Value(elem.isText && container.text().find(elem.text()) != std::string::npos ? 1 : 0);

  if (container.isMatrix) {
    if (elem.isMatrix || elem.isArray)
      return Value(holdsAsRow(elem, container) ? 1 : 0);
    for (const Value &item : nd::rowMajorCells(container))
      if (valuesDeepEqual(elem, item))
        return Value(1);
    return Value(0);
  }

  if (!container.isArray) {
    std::cerr << "Error: 'in' needs a matrix, a dict or text on its right, not a "
              << valueKindName(container) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }

  for (const Value &item : container.elems()) {
    if (valuesDeepEqual(elem, item))
      return Value(1);
  }

  return Value(0);
}
