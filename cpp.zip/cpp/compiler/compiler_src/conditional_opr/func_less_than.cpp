#include "conditional_opr.h"

/* ================= LESS THAN (<) ================= */

Value logical_lt(Value a, Value b) { return Value(a.number < b.number); }
