#include "conditional_opr.h"
#include <iostream>

/* ================= LESS THAN (<) ================= */

// Numbers compare numerically, strings lexicographically. Non-orderable
// kinds (array/matrix/dict/object) are rejected by parseComparison()
// before reaching here WHEN this is invoked via the `<` operator syntax -
// but logical_builtin.cpp also exposes this as a directly-callable
// function ("lt"), which bypassed that check entirely and silently
// called valueOrderCompare() on non-orderable values instead (confirmed:
// lt([1,2],[3,4]) silently returned 0 with no error). Validating here too
// closes that gap for both call paths, using the exact same check/message
// parser_expression.cpp's evaluateComparisonValues() already uses, so the
// operator and function forms can never disagree.
Value logical_lt(Value a, Value b) {
  if (!valueIsOrderable(a) || !valueIsOrderable(b) || valueKindOf(a) != valueKindOf(b)) {
    std::cerr << "Error: cannot order-compare " << valueKindName(a) << " with "
              << valueKindName(b) << "\n";
    g_lastConditionalOk = false;
    return Value(0);
  }
  // IEEE-754: any ordering comparison with a NaN operand is false.
  if (valuesUnordered(a, b))
    return Value(0);
  return Value(valueOrderCompare(a, b) < 0 ? 1.0 : 0.0);
}
