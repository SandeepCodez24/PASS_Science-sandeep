#include "conditional_opr.h"

/* ================= EQUAL TO (==) ================= */

Value logical_eq(Value a, Value b) { return Value(a.number == b.number); }
