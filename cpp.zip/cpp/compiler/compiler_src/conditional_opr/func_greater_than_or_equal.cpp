#include "conditional_opr.h"

/* ================= GREATER THAN OR EQUAL (>=) ================= */

Value logical_gte(Value a, Value b) { return Value(a.number >= b.number); }
