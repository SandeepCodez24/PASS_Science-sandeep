#include "conditional_opr.h"

/* ================= LESS THAN OR EQUAL (<=) ================= */

Value logical_lte(Value a, Value b) { return Value(a.number <= b.number); }
