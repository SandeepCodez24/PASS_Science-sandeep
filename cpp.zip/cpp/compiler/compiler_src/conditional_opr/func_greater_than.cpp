#include "conditional_opr.h"

/* ================= GREATER THAN (>) ================= */

Value logical_gt(Value a, Value b) { return Value(a.number > b.number); }
