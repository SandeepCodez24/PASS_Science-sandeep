#ifndef TOKEN_H
#define TOKEN_H

#include <string>

enum TokenType {
  NUMBER,
  IDENT,
  STRING,
  PLUS,
  MINUS,
  MUL,
  DIV,
  MOD,
  QUOT,
  POW,
  FACT,
  ASSIGN,
  LPAREN,
  RPAREN,
  LBRACE,
  RBRACE,
  LBRACKET,
  RBRACKET,
  SEMICOLON,
  COMMA,
  EQ,
  NEQ,
  LT,
  GT,
  LTE,
  GTE,
  AND,
  OR,
  DOT,
  IF,
  ELSE,
  PRINT,
  PUBLISH,
  FOR,
  IN,
  LOOP,
  COLON,
  END,
  WHILE,
  NAND,
  NOR,
  IS_IN,
  IS_NOT_IN,
  ELSEIF,
  BREAK,
  CONTINUE,
  FUNCTION,
  RETURN,
  CLASS,
  PRIVATE,
  PROTECTED,
  ABSTRACT,
  REQUIRE,
  ENSURE,
  REVERSIBLE,
  AT,
  // A lone '|', as in |x| (absolute value / vector norm / matrix
  // determinant). Distinct from OR ('||') — see lexer.cpp's '|' handling.
  PIPE,
  // Matrix-centred operators (2026-10):
  //   TRANSPOSE  postfix ' directly after a value: A', (A*B)', A[0,:]'
  //   MUL_EW     *.  element-wise multiply   A*.B
  //   DIV_EW     /.  element-wise divide     A/.B
  //   POW_EW     ^.  element-wise power      A^.2
  // Plain *, / and ^ are the matrix operations.
  TRANSPOSE,
  MUL_EW,
  DIV_EW,
  POW_EW,
  // '~' - a placeholder in a list of variables being assigned, for a value
  // that is not wanted: [~, idx] = max(A). Nothing else uses it yet.
  TILDE,
  // Extend assignment (2026-10-28), statement level only:
  //   COMMA_ASSIGN  ,=   M ,= X  appends X to the right of M  (M = [M, X])
  //   SEMI_ASSIGN   ;=   M ;= X  appends X below M            (M = [M; X])
  // The two characters must touch: `M , = X` is not the operator.
  COMMA_ASSIGN,
  SEMI_ASSIGN
};

struct Token {
  TokenType type;
  std::string text;

  // 1-based source position of this token's first character. Defaulted so
  // every existing 2-field aggregate-init call site (`{TYPE, text}`, still
  // used all over the lexer/parser) keeps compiling unchanged; only the
  // whole-file Program parser (Phase 3) reads these, for indentation-
  // alignment checks that used to re-read raw source lines directly.
  size_t line = 0;
  size_t col = 0;

  // NUMBER only: the literal carried an `i` / `j` suffix (`3i`, `2.5j`),
  // so it denotes that many imaginary units. `text` holds just the digits.
  bool imaginary = false;

  // NUMBER only: the literal was the keyword `true` or `false` (text "1" /
  // "0"). The parser turns it into a real bool Value instead of a float64.
  bool isBool = false;

  // SEMICOLON: `text` holds the whole run of adjacent semicolons - ";" ends
  // a statement or a matrix row, ";;" (only inside [ ]) separates the 2-D
  // blocks of a 3-D matrix, ";;;" those of a 4-D one, and so on. The level
  // is text.size().
};
#endif