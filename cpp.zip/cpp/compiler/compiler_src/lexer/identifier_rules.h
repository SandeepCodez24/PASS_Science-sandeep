#pragma once

// The one definition of a Neural Code name, shared by the lexer (every name
// in a script or a Command Window line) and the data engine (every name in a
// .ndat file being loaded). The Java editor has a twin
// (language.semantic.ScriptedName) built from the same generated tables,
// so both sides accept exactly the same names.
//
//   name       := base [ "_$" part ] [ "_@" part ]
//   base       := start { cont | "_" }          ("_" not followed by $ or @)
//   part       := first { cont | "_" }          ("_" not followed by $ or @)
//   start      := ASCII letter | "_" | a letter of a supported script
//   first      := ASCII letter or digit | a letter of a supported script
//   cont       := start | ASCII digit | a mark or digit of a supported script
//
//   A_$1        A with subscript 1
//   A_@2        A with superscript 2
//   μ_$max_@2   μ with subscript "max" and superscript 2
//
// What can never be in a name, so no name can imitate another:
//   * '$' or '@' anywhere except straight after '_' as the marker;
//   * Unicode subscript/superscript characters (₁, ¹, ᵢ ...);
//   * invisible characters (ZWJ, ZWNJ, zero-width space, BOM ...);
//   * letters that look identical to an ASCII letter (Greek capital A ...);
//   * text that is not in Unicode normal form C.
//
// Live signals ($Sensor1$, @Actuator1@) are not names; the lexer reserves
// them separately.

#include <cstddef>
#include <string>

namespace ncident {

// Kind of one code point inside a name.
enum class CharKind {
  Start,       // may start a name or a script part
  Continue,    // may only continue one (combining mark, script digit)
  NotAllowed,  // refused; see describeRefusal()
};

// Decodes one UTF-8 code point at text[pos]. Sets `len` to its byte length
// (1 for an invalid byte, which yields U+FFFD) and returns it.
char32_t decodeUtf8(const std::string &text, std::size_t pos, std::size_t &len);

// ASCII letters, '_' and ASCII digits are classified here too.
CharKind classify(char32_t cp);

// Why a NotAllowed code point is refused, phrased for the user.
std::string describeRefusal(char32_t cp);

// True when `second` straight after `first` is not in NFC (they compose into
// one character, or two marks are in the wrong order). Fills `why`.
bool breaksNfc(char32_t first, char32_t second, std::string &why);

// True when `cp` on its own is never produced by NFC. Fills `why`.
bool isNonNfc(char32_t cp, std::string &why);

// "U+0393" style label.
std::string codePointLabel(char32_t cp);

// The result of reading one name from source text.
struct NameScan {
  std::size_t end = 0;         // byte index just past the name
  std::size_t codePoints = 0;  // characters read (for column numbers)
  bool hasScripts = false;     // the name has a subscript or a superscript
  std::string error;           // first problem found; empty when the name is valid
  std::size_t errorOffset = 0; // characters from the name's start to that problem
};

// Reads the name starting at text[pos]. The caller has checked that a name
// can start there: an ASCII letter, '_' or a non-ASCII byte. The name ends
// at the first ASCII character that cannot be part of one (an operator, a
// space, a bracket, or a '$' / '@' that does not follow '_'). A refused
// non-ASCII character does not end it: it is kept inside and reported, so a
// faulty name can never quietly turn into a shorter, valid one.
NameScan scanName(const std::string &text, std::size_t pos);

// Checks a complete name (for example one read from a .ndat file). Returns
// true when it is valid; otherwise fills `why` with the first problem.
bool validateName(const std::string &name, std::string &why);

} // namespace ncident
