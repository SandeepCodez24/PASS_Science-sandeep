#pragma once

#include <string>
#include <vector>
#include "token.h"

class Lexer
{
private:

    std::string text;

    size_t pos = 0;

    // 1-based; advance() maintains these as it consumes characters. Columns
    // count characters, not bytes, so a Tamil or Greek name does not push
    // every later column on the line to the right.
    size_t line = 1;
    size_t col = 1;

    // Lexical errors reported so far (see errorCount()).
    int errorCount_ = 0;

    char current();

    void advance();

    // Consumes `bytes` bytes that hold no line break, counting columns by
    // character.
    void advanceBytes(size_t bytes);

    // Prints "✖ Syntax Error (line L, col C): message" and counts it.
    void reportError(size_t errLine, size_t errCol, const std::string &message);

public:

    Lexer(const std::string& input);

    std::vector<Token> tokenize();

    // Number of lexical errors tokenize() reported: an unknown character, an
    // unterminated string, a malformed name (A_$, A_$1_$2, a ZWJ inside a
    // name, ...), a reserved live-signal literal. The caller must not run
    // the tokens when this is not zero -- a lexical error means the tokens
    // no longer say what the user wrote.
    int errorCount() const { return errorCount_; }
};
