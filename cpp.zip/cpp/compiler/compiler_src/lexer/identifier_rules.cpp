#include "identifier_rules.h"

#include <cstdint>
#include <cstdio>

namespace ncident {

namespace {

struct IdentRange {
  char32_t first;
  char32_t last;
  int kind; // 1 = start, 2 = continue only
};

struct ComposePair {
  char32_t first;
  char32_t second;
  char32_t composed;
};

struct MarkClass {
  char32_t mark;
  int ccc;
};

struct Confusable {
  char32_t cp;
  const char *why;
};

#include "identifier_tables.inc"

template <typename T, std::size_t N> constexpr std::size_t countOf(const T (&)[N]) { return N; }

std::string utf8(char32_t cp) {
  std::string out;
  if (cp < 0x80) {
    out += static_cast<char>(cp);
  } else if (cp < 0x800) {
    out += static_cast<char>(0xC0 | (cp >> 6));
    out += static_cast<char>(0x80 | (cp & 0x3F));
  } else if (cp < 0x10000) {
    out += static_cast<char>(0xE0 | (cp >> 12));
    out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
    out += static_cast<char>(0x80 | (cp & 0x3F));
  } else {
    out += static_cast<char>(0xF0 | (cp >> 18));
    out += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
    out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
    out += static_cast<char>(0x80 | (cp & 0x3F));
  }
  return out;
}

int rangeKind(char32_t cp) {
  std::size_t lo = 0;
  std::size_t hi = countOf(kIdentRanges);
  while (lo < hi) {
    std::size_t mid = (lo + hi) / 2;
    if (cp < kIdentRanges[mid].first)
      hi = mid;
    else if (cp > kIdentRanges[mid].last)
      lo = mid + 1;
    else
      return kIdentRanges[mid].kind;
  }
  return 0;
}

int combiningClass(char32_t cp) {
  for (std::size_t i = 0; i < countOf(kMarkClasses); ++i)
    if (kMarkClasses[i].mark == cp)
      return kMarkClasses[i].ccc;
  return 0;
}

bool isInvisible(char32_t cp) {
  return cp == 0x00AD || cp == 0x034F || cp == 0x061C || cp == 0x180E ||
         (cp >= 0x200B && cp <= 0x200F) || (cp >= 0x202A && cp <= 0x202E) ||
         (cp >= 0x2060 && cp <= 0x2064) || (cp >= 0x2066 && cp <= 0x2069) ||
         cp == 0xFEFF || (cp >= 0xFE00 && cp <= 0xFE0F);
}

bool isScriptLookAlike(char32_t cp) {
  return cp == 0x00B2 || cp == 0x00B3 || cp == 0x00B9 ||
         (cp >= 0x2070 && cp <= 0x209F) ||   // superscripts and subscripts block
         (cp >= 0x1D2C && cp <= 0x1D6A) ||   // modifier letters, subscript letters
         (cp >= 0x1D9B && cp <= 0x1DBF) ||   // modifier letter supplement
         (cp >= 0x02B0 && cp <= 0x02B8) ||   // spacing modifier letters (ʰ ʲ ʳ ...)
         (cp >= 0x02E0 && cp <= 0x02E4) || cp == 0x2C7C || cp == 0x2C7D;
}

} // namespace

char32_t decodeUtf8(const std::string &text, std::size_t pos, std::size_t &len) {
  const unsigned char b0 = static_cast<unsigned char>(text[pos]);
  len = 1;
  if (b0 < 0x80)
    return b0;
  int need = 0;
  char32_t cp = 0;
  if ((b0 & 0xE0) == 0xC0) {
    need = 1;
    cp = b0 & 0x1F;
  } else if ((b0 & 0xF0) == 0xE0) {
    need = 2;
    cp = b0 & 0x0F;
  } else if ((b0 & 0xF8) == 0xF0) {
    need = 3;
    cp = b0 & 0x07;
  } else {
    return 0xFFFD;
  }
  for (int i = 1; i <= need; ++i) {
    if (pos + i >= text.size())
      return 0xFFFD;
    const unsigned char b = static_cast<unsigned char>(text[pos + i]);
    if ((b & 0xC0) != 0x80)
      return 0xFFFD;
    cp = (cp << 6) | (b & 0x3F);
  }
  // Overlong forms and surrogates are invalid UTF-8.
  if ((need == 1 && cp < 0x80) || (need == 2 && cp < 0x800) || (need == 3 && cp < 0x10000) ||
      (cp >= 0xD800 && cp <= 0xDFFF) || cp > 0x10FFFF)
    return 0xFFFD;
  len = static_cast<std::size_t>(need) + 1;
  return cp;
}

CharKind classify(char32_t cp) {
  if (cp < 0x80) {
    if ((cp >= 'A' && cp <= 'Z') || (cp >= 'a' && cp <= 'z') || cp == '_')
      return CharKind::Start;
    if (cp >= '0' && cp <= '9')
      return CharKind::Continue;
    return CharKind::NotAllowed;
  }
  switch (rangeKind(cp)) {
  case 1:
    return CharKind::Start;
  case 2:
    return CharKind::Continue;
  default:
    return CharKind::NotAllowed;
  }
}

std::string codePointLabel(char32_t cp) {
  char buf[16];
  std::snprintf(buf, sizeof buf, "U+%04X", static_cast<unsigned>(cp));
  return buf;
}

std::string describeRefusal(char32_t cp) {
  if (cp == 0xFFFD)
    return "the name contains bytes that are not valid UTF-8";
  if (cp == 0x200C || cp == 0x200D)
    return "an invisible joiner (" + codePointLabel(cp) +
           ") cannot be part of a name; it is the old hidden subscript/superscript marker - "
           "retype the name with _$ (subscript) or _@ (superscript)";
  if (isInvisible(cp))
    return "an invisible character (" + codePointLabel(cp) + ") cannot be part of a name";
  if (isScriptLookAlike(cp))
    return "'" + utf8(cp) + "' (" + codePointLabel(cp) +
           ") cannot be part of a name; write a subscript as _$ and a superscript as _@ "
           "(A_$1, A_@2)";
  for (std::size_t i = 0; i < countOf(kConfusables); ++i)
    if (kConfusables[i].cp == cp)
      return "'" + utf8(cp) + "' (" + codePointLabel(cp) + ") cannot be used in a name: " +
             kConfusables[i].why + "; use the Latin letter";
  return "the character '" + utf8(cp) + "' (" + codePointLabel(cp) + ") cannot be used in a name";
}

bool isNonNfc(char32_t cp, std::string &why) {
  for (std::size_t i = 0; i < kNonNfcCount; ++i) {
    if (kNonNfc[i] == cp) {
      why = "'" + utf8(cp) + "' (" + codePointLabel(cp) +
            ") is not in normal form; type the letter and its nukta separately";
      return true;
    }
  }
  return false;
}

bool breaksNfc(char32_t first, char32_t second, std::string &why) {
  for (std::size_t i = 0; i < kComposePairCount; ++i) {
    if (kComposePairs[i].first == first && kComposePairs[i].second == second) {
      why = "'" + utf8(first) + utf8(second) + "' must be written as the single character '" +
            utf8(kComposePairs[i].composed) + "' (" + codePointLabel(kComposePairs[i].composed) + ")";
      return true;
    }
  }
  const int a = combiningClass(first);
  const int b = combiningClass(second);
  if (a > 0 && b > 0 && a > b) {
    why = "the marks " + codePointLabel(first) + " and " + codePointLabel(second) +
          " are in the wrong order";
    return true;
  }
  return false;
}

bool validateName(const std::string &name, std::string &why) {
  if (name.empty()) {
    why = "a name cannot be empty";
    return false;
  }
  NameScan scan = scanName(name, 0);
  if (!scan.error.empty()) {
    why = scan.error;
    return false;
  }
  if (scan.end != name.size()) {
    std::size_t len = 0;
    const char32_t cp = decodeUtf8(name, scan.end, len);
    if (cp == '$' || cp == '@')
      why = std::string("'") + static_cast<char>(cp) +
            "' can only appear in a name as _$ (subscript) or _@ (superscript)";
    else
      why = describeRefusal(cp);
    return false;
  }
  return true;
}

NameScan scanName(const std::string &text, std::size_t pos) {
  enum class Part { Base, Sub, Sup };

  NameScan scan;
  Part part = Part::Base;
  std::size_t partLen = 0; // code points in the current part
  bool seenSub = false;
  bool seenSup = false;
  char32_t prev = 0;

  auto fail = [&](const std::string &message) {
    if (scan.error.empty()) {
      scan.error = message;
      scan.errorOffset = scan.codePoints;
    }
  };
  auto partWord = [&](Part p) { return p == Part::Sub ? "subscript (_$)" : "superscript (_@)"; };

  const std::size_t n = text.size();
  while (pos < n) {
    const char c = text[pos];

    // A marker: '_' directly followed by '$' (subscript) or '@' (superscript).
    if (c == '_' && pos + 1 < n && (text[pos + 1] == '$' || text[pos + 1] == '@')) {
      const bool sub = text[pos + 1] == '$';
      if (part == Part::Base && partLen == 0)
        fail(std::string("a ") + (sub ? "subscript (_$)" : "superscript (_@)") +
             " needs a name in front of it, as in A_$1");
      else if (part != Part::Base && partLen == 0)
        fail(std::string("the ") + partWord(part) + " is empty; write something after the marker");
      if (sub && seenSub)
        fail("a name can have only one subscript (_$)");
      else if (sub && seenSup)
        fail("write the subscript (_$) before the superscript (_@), as in A_$i_@2");
      else if (!sub && seenSup)
        fail("a name can have only one superscript (_@)");
      part = sub ? Part::Sub : Part::Sup;
      (sub ? seenSub : seenSup) = true;
      scan.hasScripts = true;
      partLen = 0;
      prev = 0;
      pos += 2;
      scan.codePoints += 2;
      continue;
    }

    std::size_t len = 1;
    const char32_t cp = decodeUtf8(text, pos, len);
    const CharKind kind = classify(cp);

    if (kind == CharKind::NotAllowed) {
      if (cp < 0x80)
        break; // an operator, a space, a bracket, '$' or '@' on its own: the name ends here
      // A refused non-ASCII character stays inside the name, so a script
      // that uses it fails instead of silently binding a different name.
      fail(describeRefusal(cp));
    } else if (cp == '_') {
      if (part != Part::Base && partLen == 0)
        fail(std::string("a ") + partWord(part) + " must start with a letter or a digit");
    } else {
      const bool asciiDigit = cp >= '0' && cp <= '9';
      if (partLen == 0 && part == Part::Base && kind != CharKind::Start)
        fail("a name must start with a letter or '_'");
      if (partLen == 0 && part != Part::Base && kind != CharKind::Start && !asciiDigit)
        fail(std::string("a ") + partWord(part) + " must start with a letter or a digit");
      std::string why;
      if (isNonNfc(cp, why) || (prev != 0 && breaksNfc(prev, cp, why)))
        fail(why);
    }

    prev = cp;
    pos += len;
    scan.codePoints += 1;
    partLen += 1;
  }

  if (part != Part::Base && partLen == 0)
    fail(std::string("the ") + partWord(part) + " is empty; write something after the marker");

  scan.end = pos;
  return scan;
}

} // namespace ncident
