#include "lexer.h"
#include "identifier_rules.h"
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_set>

/* ================= CONSTRUCTOR ================= */

Lexer::Lexer(const std::string &src) {
  text = src;
  pos = 0;
}

/* ================= CURRENT CHAR ================= */

char Lexer::current() {
  if (pos >= text.size())
    return '\0';

  return text[pos];
}

/* ================= ADVANCE ================= */

void Lexer::advance() {
  if (pos < text.size()) {
    if (text[pos] == '\n') {
      line++;
      col = 1;
    } else if ((static_cast<unsigned char>(text[pos]) & 0xC0) != 0x80) {
      col++; // a UTF-8 continuation byte is part of the character before it
    }
    pos++;
  }
}

void Lexer::advanceBytes(size_t bytes) {
  for (size_t i = 0; i < bytes && pos < text.size(); ++i)
    advance();
}

void Lexer::reportError(size_t errLine, size_t errCol, const std::string &message) {
  std::cerr << "✖ Syntax Error (line " << errLine << ", col " << errCol << "): " << message << "\n";
  errorCount_++;
}

namespace {

// The <cctype> functions take an int that must be EOF or fit in unsigned
// char. A plain char holding a UTF-8 byte (Greek, Tamil, Devanagari ...) is
// negative on Windows, and the debug C runtime stops the program with
// "Debug Assertion Failed: c >= -1 && c <= 255" (isctype.cpp). Names are now
// sent to nc.exe as UTF-8, so every character test in this file goes through
// these ASCII-only helpers or casts to unsigned char first.
inline bool isAsciiDigit(char ch) { return ch >= '0' && ch <= '9'; }
inline bool isAsciiSpace(char ch) {
  return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' || ch == '\v' || ch == '\f';
}

// Characters a live-signal name ($Sensor1$, @Actuator1@) may hold: ASCII
// letters, digits, '_' and any non-ASCII byte (checked properly once
// signals are implemented). The first '$' / '@' after the name closes it.
bool isSignalNameByte(char ch) {
  unsigned char u = static_cast<unsigned char>(ch);
  return std::isalnum(u) || ch == '_' || u >= 0x80;
}

// Byte index just past a signal name starting at `from`.
size_t signalNameEnd(const std::string &text, size_t from) {
  while (from < text.size() && isSignalNameByte(text[from]))
    from++;
  return from;
}

} // namespace

/* ================= TOKENIZE ================= */

std::vector<Token> Lexer::tokenize() {
  std::vector<Token> tokens;

  // --- '|' bar bookkeeping (absolute value / norm / determinant) ----------
  // A lone '|' is an OPENING bar unless the token before it ends an operand
  // (`|x|`, `|P!|`, `|(a)|`, a closing bar), in which case it is a CLOSING
  // bar. `||` is ambiguous - the logical-OR operator, or two bars in a row
  // (`||B||`, `|-|-B||`, `|B + |C||`) - and is settled from the same context
  // (see the '||' branch below). barDepth counts bars currently open in the
  // statement being lexed; it is reset at every statement boundary.
  int barDepth = 0;
  std::unordered_set<size_t> closingBars; // indices into `tokens` of closing PIPEs

  // How many '[' are open. A run of semicolons (';;', ';;;' ...) is an
  // N-D matrix separator and only means something inside [ ].
  int squareDepth = 0;

  // True if the token at `idx` can END an operand: a value, a closing
  // bracket/paren, a closing bar, or a POSTFIX '!' (factorial) - a '!' only
  // counts when what precedes it ends an operand (otherwise it is prefix NOT).
  auto endsOperandAt = [&](size_t idx) -> bool {
    while (true) {
      switch (tokens[idx].type) {
      case NUMBER:
      case IDENT:
      case STRING:
      case RPAREN:
      case RBRACKET:
      case RBRACE:
      case TRANSPOSE:
        return true;
      case PIPE:
        return closingBars.count(idx) > 0;
      case FACT:
        if (idx == 0)
          return false;
        idx--;
        continue;
      default:
        return false;
      }
    }
  };
  auto prevEndsOperand = [&]() { return !tokens.empty() && endsOperandAt(tokens.size() - 1); };

  // True if an operand can START at text[from] after only spaces/tabs. A
  // line break, operator, closer, ';' etc. means no operand follows. A
  // leading '+'/'-' is treated as a following binary operator (`|P!|-1`),
  // not as a sign on a new operand. A '|' counts only if it OPENS an abs -
  // i.e. an operand starts after the bar(s) (`a !| |b|`, `x || |y|`) - so a
  // run of closing bars (`|||)`, `Q!||`) is not mistaken for an operand.
  std::function<bool(size_t)> operandStartsAt = [&](size_t from) -> bool {
    while (from < text.size() && (text[from] == ' ' || text[from] == '\t'))
      from++;
    if (from >= text.size())
      return false;
    unsigned char n = (unsigned char)text[from];
    if (n == '|') {
      while (from < text.size() && text[from] == '|')
        from++;
      return operandStartsAt(from);
    }
    return std::isalnum(n) || n == '_' || n == '(' || n == '[' || n == '!' || n == '"' ||
           n == '\'' || n == '@' || n == '$' || n == '.' || n == '~' || n >= 0x80;
  };

  // Element-wise operators *. /. ^. (two characters). Always read this
  // way: `x^.5` is x element-wise-raised to 5 - write 0.5 for a half.
  auto pushElementwise = [&](TokenType type, const char *op, size_t ln, size_t cl) {
    tokens.push_back({type, op, ln, cl});
    pos += 2;
    col += 2;
  };

  auto pushPipe = [&](bool closing, size_t ln, size_t cl) {
    tokens.push_back({PIPE, "|", ln, cl});
    if (closing) {
      closingBars.insert(tokens.size() - 1);
      if (barDepth > 0)
        barDepth--;
    } else {
      barDepth++;
    }
  };

  while (pos < text.size()) {
    char c = current();
    size_t startLine = line;
    size_t startCol = col;

    /* WHITESPACE */

    if (isAsciiSpace(c)) {
      if (c == '\n')
        barDepth = 0; // bars never span statements; re-sync after a bad line
      advance();
      continue;
    }

    /* TRANSPOSE: a ' written directly after a value (no space between) -
       A', x', (A*B)', A[0,:]', A'' - is the postfix transpose operator.
       Anywhere else (after '=', '(', ',', an operator, a space, or at the
       start of a line) a ' still opens a single-quoted string, so
       x = 'text', print('hi') and f(A, 'name') are unaffected. */

    if (c == '\'' && pos > 0 &&
        !isAsciiSpace(text[pos - 1]) &&
        !tokens.empty() && tokens.back().type != STRING && prevEndsOperand()) {
      tokens.push_back({TRANSPOSE, "'", startLine, startCol});
      advance();
      continue;
    }

    /* STRING (double- or single-quoted, sharing one escape-aware scanner) */

    if (c == '"' || c == '\'') {
      char quoteChar = c;
      advance();

      std::string str;
      bool terminated = false;

      while (true) {
        char ch = current();

        if (ch == quoteChar) {
          advance();
          terminated = true;
          break;
        }

        if (ch == '\0')
          break; // hit EOF before the closing quote

        if (ch == '\\') {
          advance();
          char esc = current();

          // Recognized escapes consume the escaped character too; an
          // unrecognized one (e.g. a bare '\' in a Windows path like
          // "C:\Users") keeps the backslash literally and lets the next
          // loop iteration re-read `esc` as an ordinary character, so it
          // still ends up in the string - just without being "eaten" as
          // part of an escape sequence.
          switch (esc) {
          case '"':
            str += '"';
            advance();
            break;
          case '\'':
            str += '\'';
            advance();
            break;
          case '\\':
            str += '\\';
            advance();
            break;
          case 'n':
            str += '\n';
            advance();
            break;
          case 't':
            str += '\t';
            advance();
            break;
          case 'r':
            str += '\r';
            advance();
            break;
          default:
            str += '\\';
            break;
          }
          continue;
        }

        str += ch;
        advance();
      }

      if (!terminated) {
        reportError(startLine, startCol,
                    std::string("unterminated string literal - missing closing '") + quoteChar + "'");
      }

      tokens.push_back({STRING, str, startLine, startCol});
      continue;
    }

    /* NUMBER */

    // A bare '.' (not followed by a digit) is the DOT operator token,
    // handled further below — only treat '.' as the start of a numeric
    // literal (e.g. ".5") when a digit immediately follows it.
    if (isAsciiDigit(c) ||
        (c == '.' && pos + 1 < text.size() && isAsciiDigit(text[pos + 1]))) {
      bool dotSeen = false;
      std::string num;

      while (pos < text.size()) {
        if (isAsciiDigit(text[pos])) {
          num += text[pos];
          pos++;
          col++;
        }

        else if (text[pos] == '.') {
          if (dotSeen)
            break;

          dotSeen = true;

          num += '.';
          pos++;
          col++;
        } else
          break;
      }

      if (pos < text.size() && (text[pos] == 'e' || text[pos] == 'E')) {
        size_t exponentEnd = pos + 1;

        if (exponentEnd < text.size() &&
            (text[exponentEnd] == '+' || text[exponentEnd] == '-')) {
          exponentEnd++;
        }

        size_t exponentDigitsStart = exponentEnd;

        while (exponentEnd < text.size() && isAsciiDigit(text[exponentEnd])) {
          exponentEnd++;
        }

        if (exponentEnd > exponentDigitsStart) {
          num += text.substr(pos, exponentEnd - pos);
          col += exponentEnd - pos; // none of digits/e/+/- are '\n'
          pos = exponentEnd;
        }
      }

      tokens.push_back({NUMBER, num, startLine, startCol});

      // Imaginary literal: `i` or `j` directly after the digits (`3i`,
      // `2.5j`, `1e3i`). Only when the suffix letter stands alone - `3if`
      // or `3in` is not an imaginary number followed by a name.
      if (pos < text.size() && (text[pos] == 'i' || text[pos] == 'j') &&
          !(pos + 1 < text.size() &&
            (std::isalnum(static_cast<unsigned char>(text[pos + 1])) || text[pos + 1] == '_'))) {
        tokens.back().imaginary = true;
        pos++;
        col++;
      }
      continue;
    }
    /* IDENTIFIER */

    // A name starts with an ASCII letter, '_' or a non-ASCII byte. What a
    // name may hold - and the subscript (_$) / superscript (_@) markers -
    // is decided in one place, identifier_rules.cpp, shared with the .ndat
    // loader; the Java editor has a twin built from the same tables.
    //
    //   A_$1        A with subscript 1          (stored and shown as "A_$1")
    //   A_@2        A with superscript 2
    //   μ_$i_@2     μ with subscript i and superscript 2
    //
    // A name that breaks a rule (A_$ with nothing after it, a ZWJ, '₁', a
    // Greek capital A ...) is reported and still produced as ONE token
    // holding all of its text, so a faulty script can never quietly bind a
    // different, shorter name.
    auto isIdentStart = [](char ch) {
      return std::isalpha(static_cast<unsigned char>(ch)) || ch == '_' ||
             (static_cast<unsigned char>(ch) >= 0x80);
    };

    if (isIdentStart(c)) {
      ncident::NameScan scan = ncident::scanName(text, pos);
      if (!scan.error.empty())
        reportError(startLine, startCol + scan.errorOffset, scan.error);
      std::string ident = text.substr(pos, scan.end - pos);
      advanceBytes(scan.end - pos);

      if (scan.hasScripts) {
        tokens.push_back({IDENT, ident, startLine, startCol});
        continue;
      }

      // true / false stay NUMBER tokens ("1" / "0") so every place that
      // already accepts a numeric literal keeps accepting them, but carry
      // isBool so the parser builds a real bool Value from them.
      if (ident == "true" || ident == "false") {
        tokens.push_back({NUMBER, ident == "true" ? "1" : "0", startLine, startCol});
        tokens.back().isBool = true;
      }

      else if (ident == "print")
        tokens.push_back({PRINT, ident, startLine, startCol});

      else if (ident == "publish")
        tokens.push_back({PUBLISH, ident, startLine, startCol});

      else if (ident == "for")
        tokens.push_back({FOR, ident, startLine, startCol});

      else if (ident == "in")
        tokens.push_back({IN, ident, startLine, startCol});

      else if (ident == "loop")
        tokens.push_back({LOOP, ident, startLine, startCol});

      else if (ident == "if")
        tokens.push_back({IF, ident, startLine, startCol});

      else if (ident == "else")
        tokens.push_back({ELSE, ident, startLine, startCol});

      else if (ident == "while")
        tokens.push_back({WHILE, ident, startLine, startCol});

      else if (ident == "elseif")
        tokens.push_back({ELSEIF, ident, startLine, startCol});

      else if (ident == "is_in")
        tokens.push_back({IS_IN, ident, startLine, startCol});

      else if (ident == "is_not_in")
        tokens.push_back({IS_NOT_IN, ident, startLine, startCol});

      else if (ident == "break")
        tokens.push_back({BREAK, ident, startLine, startCol});

      else if (ident == "continue")
        tokens.push_back({CONTINUE, ident, startLine, startCol});

      else if (ident == "function")
        tokens.push_back({FUNCTION, ident, startLine, startCol});

      else if (ident == "return")
        tokens.push_back({RETURN, ident, startLine, startCol});

      else if (ident == "class")
        tokens.push_back({CLASS, ident, startLine, startCol});

      else if (ident == "private")
        tokens.push_back({PRIVATE, ident, startLine, startCol});

      else if (ident == "protected")
        tokens.push_back({PROTECTED, ident, startLine, startCol});

      else if (ident == "abstract")
        tokens.push_back({ABSTRACT, ident, startLine, startCol});

      else if (ident == "require")
        tokens.push_back({REQUIRE, ident, startLine, startCol});

      else if (ident == "ensure")
        tokens.push_back({ENSURE, ident, startLine, startCol});

      else if (ident == "reversible")
        tokens.push_back({REVERSIBLE, ident, startLine, startCol});

      else
        tokens.push_back({IDENT, ident, startLine, startCol});

      continue;
    }
    /* OPERATORS */

    if (c == '+') {
      tokens.push_back({PLUS, "+", startLine, startCol});
      advance();
      continue;
    }
    if (c == '-') {
      tokens.push_back({MINUS, "-", startLine, startCol});
      advance();
      continue;
    }
    // Element-wise operators: the operator character followed directly by
    // '.' - A*.B, A/.B, A^.2. Always read this way, so `x*.5` is x
    // element-wise-times 5 (write 0.5 with its leading zero for a half).
    if (c == '*') {
      if (pos + 1 < text.size() && text[pos + 1] == '.') {
        pushElementwise(MUL_EW, "*.", startLine, startCol);
        continue;
      }
      tokens.push_back({MUL, "*", startLine, startCol});
      advance();
      continue;
    }
    if (c == '.') {
      tokens.push_back({DOT, ".", startLine, startCol});
      advance();
      continue;
    }
    if (c == '@') {
      // @Actuator1@ - a live actuator signal: reserved, not available yet.
      // A '@' with no closing '@' after a name is the function reference
      // (@sin) or the class rate annotation (@rate(10Hz)), as before.
      size_t nameEnd = signalNameEnd(text, pos + 1);
      if (nameEnd > pos + 1 && nameEnd < text.size() && text[nameEnd] == '@') {
        reportError(startLine, startCol,
                    "live actuator signals (@" + text.substr(pos + 1, nameEnd - pos - 1) +
                        "@) are reserved and not available yet");
        advanceBytes(nameEnd + 1 - pos);
        continue;
      }
      tokens.push_back({AT, "@", startLine, startCol});
      advance();
      continue;
    }

    if (c == '$') {
      // $Sensor1$ - a live sensor signal: reserved, not available yet. Any
      // other '$' is an error: in a name it only ever follows '_' (A_$1),
      // and that case never reaches here.
      size_t nameEnd = signalNameEnd(text, pos + 1);
      if (nameEnd > pos + 1 && nameEnd < text.size() && text[nameEnd] == '$') {
        reportError(startLine, startCol,
                    "live sensor signals ($" + text.substr(pos + 1, nameEnd - pos - 1) +
                        "$) are reserved and not available yet");
        advanceBytes(nameEnd + 1 - pos);
        continue;
      }
      reportError(startLine, startCol,
                  "'$' can only be used as _$ after a name (A_$1 is A with subscript 1), "
                  "or around a sensor signal name ($Sensor1$)");
      advance();
      continue;
    }

    if (c == '/') {
      advance();

      if (current() == '/') {
        advance();
        tokens.push_back({QUOT, "//", startLine, startCol});
      } else if (current() == '.') {
        pos--; // back onto '/', so pushElementwise() consumes "/." itself
        col--;
        pushElementwise(DIV_EW, "/.", startLine, startCol);
      } else {
        tokens.push_back({DIV, "/", startLine, startCol});
      }

      continue;
    }
    if (c == '^') {
      if (pos + 1 < text.size() && text[pos + 1] == '.') {
        pushElementwise(POW_EW, "^.", startLine, startCol);
        continue;
      }
      tokens.push_back({POW, "^", startLine, startCol});
      advance();
      continue;
    }
    // '#' and '\\' both start a comment that runs to the end of the line. The
    // editor has always treated '\\' this way; nc.exe rejected it until
    // 2026-10-30, so a script ran in the IDE but not from the command line.
    // Inside a string it is still an escape (handled by the string scanner).
    if (c == '#' || (c == '\\' && pos + 1 < text.size() && text[pos + 1] == '\\')) {
      while (pos < text.size() && current() != '\n' && current() != '\r') {
        advance();
      }
      continue;
    }

    if (c == '%') {
      // '%' is a full-line comment marker when it's the first thing on its
      // line (nothing lexed yet, or the previous token was on an earlier
      // line) and the modulo operator when it follows a value on the same
      // line (e.g. `10 % 3`). The old guard here compared against the
      // stream-end END token, which is only ever appended once, after this
      // loop finishes - so it could never be true mid-tokenize, making
      // '%' as a comment work only when it was literally the first
      // character of the whole file. Comparing line numbers instead makes
      // every line-leading '%' behave as a comment, not just the first one.
      if (tokens.empty() || tokens.back().line != line) {
        while (pos < text.size() && current() != '\n' && current() != '\r') {
          advance();
        }
        continue;
      }
      tokens.push_back({MOD, "%", startLine, startCol});
      advance();
      continue;
    }

    if (c == '!' && pos + 1 < text.size() && text[pos + 1] == '=') {
      // `!==` (three characters, e.g. `5!==6`) is ambiguous between "!="
      // + a lone trailing '=' and postfix factorial '!' + "==". The first
      // reading is *never* valid - a bare '=' never begins an expression,
      // in any context - while the second is valid whenever '!' follows a
      // value (`5! == 6`). Since matching "!=" greedily here can only ever
      // turn a well-formed expression into a syntax error, never the
      // reverse, prefer splitting as FACT ('!') and letting "==" lex on
      // the next iteration whenever a third '=' follows. Plain two-
      // character `!=` (not-equal) - the overwhelmingly common case - is
      // completely unaffected.
      if (pos + 2 < text.size() && text[pos + 2] == '=') {
        tokens.push_back({FACT, "!", startLine, startCol});
        advance();
        continue;
      }
      tokens.push_back({NEQ, "!=", startLine, startCol});
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }
    if (c == '!' && pos + 1 < text.size() && text[pos + 1] == '&') {
      tokens.push_back({NAND, "!&", startLine, startCol});
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }
    if (c == '!' && pos + 1 < text.size() && text[pos + 1] == '|') {
      // `!|` is ambiguous between the NOR operator (`a !| b`) and postfix
      // factorial followed by the closing bar of an absolute value
      // (`|P!|`). Greedy NOR matching turned the latter into `P nor <nothing>`
      // ("expression ended unexpectedly"). NOR is a binary operator, so it
      // is only valid when an operand starts after the '|' (see
      // operandStartsAt above).
      bool operandFollows = operandStartsAt(pos + 2);
      if (operandFollows) {
        tokens.push_back({NOR, "!|", startLine, startCol});
        pos += 2; // none of these 2-char operators contain '\n'
        col += 2;
        continue;
      }
      tokens.push_back({FACT, "!", startLine, startCol});
      advance(); // the '|' is then lexed as PIPE on the next iteration
      continue;
    }
    if (c == '!') {
      tokens.push_back({FACT, "!", startLine, startCol});
      advance();
      continue;
    }

    if (c == '=' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({EQ, "==", startLine, startCol});
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }

    if (c == '=') {
      tokens.push_back({ASSIGN, "=", startLine, startCol});
      advance();
      continue;
    }

    if (c == '<' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({LTE, "<=", startLine, startCol});
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }

    if (c == '>' && pos + 1 < text.size() && text[pos + 1] == '=') {
      tokens.push_back({GTE, ">=", startLine, startCol});
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }

    if (c == '<') {
      tokens.push_back({LT, "<", startLine, startCol});
      advance();
      continue;
    }
    if (c == '>') {
      tokens.push_back({GT, ">", startLine, startCol});
      advance();
      continue;
    }

    if (c == '&' && pos + 1 < text.size() && text[pos + 1] == '&') {
      tokens.push_back({AND, "&&", startLine, startCol});
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }

    if (c == '|' && pos + 1 < text.size() && text[pos + 1] == '|') {
      // `||` is the logical-OR operator OR two bars side by side - decided
      // from context, using the bar bookkeeping at the top of tokenize():
      //  * nothing before it ends an operand -> OR is impossible here, so it
      //    is two OPENING bars:            `||B||`, `x = ||C|-|X||`
      //  * after an operand, with >= 2 bars open and no operand following ->
      //    two CLOSING bars (the nested abs is ending): `|-|-B||`, `|B+|C||`
      //  * anything else stays the OR operator: `a || b`, `|a| || |b|`,
      //    `|a || b|` (one bar open).
      if (!prevEndsOperand()) {
        pushPipe(false, startLine, startCol);
        pushPipe(false, startLine, startCol + 1);
      } else if (barDepth >= 2 && !operandStartsAt(pos + 2)) {
        pushPipe(true, startLine, startCol);
        pushPipe(true, startLine, startCol + 1);
      } else {
        tokens.push_back({OR, "||", startLine, startCol});
      }
      pos += 2; // none of these 2-char operators contain '\n'
      col += 2;
      continue;
    }

    // A lone '|' — the absolute-value/vector-norm/matrix-determinant
    // grouping delimiter, e.g. |-5|, |v|, |M|. Previously unrecognized
    // entirely: it fell through to the tokenizer's silent-skip default
    // below with no token emitted, so "|-5|" silently lexed as just "-5"
    // (both pipes dropped) instead of applying any absolute-value
    // semantics. See parser_factor.cpp for how PIPE is consumed.
    if (c == '|') {
      pushPipe(prevEndsOperand(), startLine, startCol);
      advance();
      continue;
    }

    /* BRACKETS */

    if (c == '(') {
      tokens.push_back({LPAREN, "(", startLine, startCol});
      advance();
      continue;
    }
    if (c == ')') {
      tokens.push_back({RPAREN, ")", startLine, startCol});
      advance();
      continue;
    }

    if (c == '[') {
      squareDepth++;
      tokens.push_back({LBRACKET, "[", startLine, startCol});
      advance();
      continue;
    }
    if (c == ']') {
      if (squareDepth > 0)
        squareDepth--;
      tokens.push_back({RBRACKET, "]", startLine, startCol});
      advance();
      continue;
    }

    if (c == '{') {
      tokens.push_back({LBRACE, "{", startLine, startCol});
      advance();
      continue;
    }
    if (c == '}') {
      tokens.push_back({RBRACE, "}", startLine, startCol});
      advance();
      continue;
    }

    if (c == ';') {
      // A run of adjacent semicolons is ONE token whose text is the whole
      // run: ";;" separates the 2-D blocks of a 3-D matrix, ";;;" the 3-D
      // blocks of a 4-D one ... (`; ;` with a space is two separate ';').
      size_t run = 0;
      while (pos + run < text.size() && text[pos + run] == ';')
        run++;
      // `;=` (one ';' touching '='): the row-extend operator M ;= X. Not a
      // statement boundary, so barDepth is left alone.
      if (run == 1 && pos + 1 < text.size() && text[pos + 1] == '=') {
        tokens.push_back({SEMI_ASSIGN, ";=", startLine, startCol});
        advanceBytes(2);
        continue;
      }
      if (run > 1 && squareDepth == 0) {
        reportError(startLine, startCol,
                    "'" + std::string(run, ';') +
                        "' is only allowed inside [ ], where it separates the blocks of an "
                        "N-D matrix ([1,2;3,4 ;; 5,6;7,8]) - end a statement with one ';'");
        while (pos < text.size() && text[pos] == ';')
          advance();
        barDepth = 0;
        tokens.push_back({SEMICOLON, ";", startLine, startCol});
        continue;
      }
      barDepth = 0; // statement boundary
      tokens.push_back({SEMICOLON, std::string(run, ';'), startLine, startCol});
      advanceBytes(run);
      continue;
    }
    if (c == ',') {
      // `,=` (touching): the column-extend operator M ,= X.
      if (pos + 1 < text.size() && text[pos + 1] == '=') {
        tokens.push_back({COMMA_ASSIGN, ",=", startLine, startCol});
        advanceBytes(2);
        continue;
      }
      tokens.push_back({COMMA, ",", startLine, startCol});
      advance();
      continue;
    }
    if (c == ':') {
      tokens.push_back({COLON, ":", startLine, startCol});
      advance();
      continue;
    }
    if (c == '~') {
      tokens.push_back({TILDE, "~", startLine, startCol});
      advance();
      continue;
    }

    // Anything reaching here isn't a recognized character in the language.
    // Previously this was silently dropped - no token, no diagnostic - so a
    // stray character (e.g. `~`, `` ` ``, `$`) vanished invisibly and the
    // parser would report a confusing, unrelated error about whatever
    // tokens ended up adjacent instead. Report it directly, then skip past
    // it (rather than aborting) so the rest of a mostly-valid file still
    // lexes and any further problems are reported too.
    {
      size_t len = 1;
      char32_t cp = ncident::decodeUtf8(text, pos, len);
      reportError(startLine, startCol,
                  cp < 0x80 ? std::string("unexpected character '") + c + "'"
                            : "unexpected character " + ncident::codePointLabel(cp));
      advanceBytes(len);
    }
  }

  tokens.push_back({END, "", line, col});
  return tokens;
}