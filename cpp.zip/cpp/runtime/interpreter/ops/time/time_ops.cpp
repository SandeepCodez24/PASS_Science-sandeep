// Operators on timestamps and durations (t = timestamp, d = duration,
// k = number):
//
//   t2 - t1 -> d        t + d, d + t, t - d -> t        d1 + d2, d1 - d2 -> d
//   -d -> d             d * k, k * d, d / k -> d        d1 / d2 -> float64
//   ==  !=  <  <=  >  >=   between two timestamps or two durations -> bool
//
// Everything else is an error: t1 + t2, a plain number with a time value
// (the unit must be written: t + seconds(5)), t * k, d1 * d2, ^, %, //.
// Matrices follow the numeric element-wise rules: equal shapes, or a single
// value against any shape. `*` and `/` between two matrices would be the
// matrix product / division, which has no meaning for time - *. and /. are
// the element-wise forms. A comparison between two matrices gives one
// true/false (every pair holds), against a single value one per element -
// both as for numbers.
#include <cmath>
#include <limits>

#include "../../core/output.h"
#include "time.h"
#include "time_cells.h"

namespace nctime {

namespace {

using cells::Shape;

enum class Kind { Timestamp, Duration, Number, Other };

Kind kindOf(const Value &v) {
  if (v.isTimestamp())
    return Kind::Timestamp;
  if (v.isDuration())
    return Kind::Duration;
  if (!v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef &&
      !v.isComplex)
    return Kind::Number;
  return Kind::Other;
}

// A number as written in a hint: 5, 2.5, int8 values exactly.
std::string formatNumberText(const Value &v) {
  return v.isInt() ? v.intText() : formatNumber(v.number);
}

// "number" reads better than "float64" in "cannot combine timestamp and ...".
std::string kindWord(const Value &v) {
  return kindOf(v) == Kind::Number && !v.isBool() && !v.isInt() ? "number" : typeName(v);
}

/* ---- exact nanosecond arithmetic ---- */

bool addNs(int64_t a, int64_t b, int64_t &out, std::string &err) {
  if (__builtin_add_overflow(a, b, &out)) {
    err = kRangeError;
    return false;
  }
  return true;
}

bool subNs(int64_t a, int64_t b, int64_t &out, std::string &err) {
  if (__builtin_sub_overflow(a, b, &out)) {
    err = kRangeError;
    return false;
  }
  return true;
}

// ns * k rounded to the nearest nanosecond (ties away from zero), exactly:
// k = m * 2^e with an integer m of at most 53 bits, so ns * m fits 128 bits
// and the 2^e scaling is a shift (no 128-bit division, which the MSVC
// target cannot link).
bool mulNs(int64_t ns, double k, int64_t &out, std::string &err) {
  if (!std::isfinite(k)) {
    err = kRangeError;
    return false;
  }
  if (k == 0.0 || ns == 0) {
    out = 0;
    return true;
  }
  int e = 0;
  const double frac = std::frexp(k, &e); // k = frac * 2^e, 0.5 <= |frac| < 1
  const int64_t m = static_cast<int64_t>(std::ldexp(frac, 53));
  int shift = e - 53; // k = m * 2^shift
  __int128 p = static_cast<__int128>(ns) * m;
  const bool negative = p < 0;
  unsigned __int128 a = negative ? static_cast<unsigned __int128>(-p) : static_cast<unsigned __int128>(p);
  if (shift >= 0) {
    if (shift > 63 || (a >> (127 - shift)) != 0) {
      err = kRangeError;
      return false;
    }
    a <<= shift;
  } else if (-shift >= 127) {
    a = 0; // far below half a nanosecond
  } else {
    const unsigned __int128 half = static_cast<unsigned __int128>(1) << (-shift - 1);
    a = (a + half) >> (-shift);
  }
  if (a > static_cast<unsigned __int128>(std::numeric_limits<int64_t>::max()) + (negative ? 1 : 0)) {
    err = kRangeError;
    return false;
  }
  out = negative ? static_cast<int64_t>(-static_cast<__int128>(a)) : static_cast<int64_t>(a);
  return true;
}

// ns / k rounded to the nearest nanosecond. Exact for a whole k; otherwise
// a double estimate refined once against the exact product.
bool divNs(int64_t ns, double k, int64_t &out, std::string &err) {
  if (k == 0.0) {
    err = "division by zero";
    return false;
  }
  if (!std::isfinite(k)) {
    out = 0;
    return true;
  }
  if (k == std::floor(k) && std::fabs(k) < 9.2e18) {
    const int64_t d = static_cast<int64_t>(k);
    if (d == -1) {
      if (ns == std::numeric_limits<int64_t>::min()) {
        err = kRangeError;
        return false;
      }
      out = -ns;
      return true;
    }
    int64_t q = ns / d, r = ns % d;
    // round half away from zero: |2r| >= |d|
    const uint64_t ar = r < 0 ? 0 - static_cast<uint64_t>(r) : static_cast<uint64_t>(r);
    const uint64_t ad = d < 0 ? 0 - static_cast<uint64_t>(d) : static_cast<uint64_t>(d);
    if (ar >= ad - ar)
      q += ((ns < 0) != (d < 0)) ? -1 : 1;
    out = q;
    return true;
  }
  const double est = static_cast<double>(ns) / k;
  if (!(std::fabs(est) < 9.2e18)) {
    err = kRangeError;
    return false;
  }
  int64_t q = std::llround(est), back = 0;
  if (!mulNs(q, k, back, err))
    return false;
  // One correction step from the exact residual (in nanoseconds).
  q += std::llround(static_cast<double>(ns - back) / k);
  out = q;
  return true;
}

/* ---- one element ---- */

bool elementOp(const std::string &op, const Value &x, const Value &y, Value &r,
               std::string &err) {
  const Kind kx = kindOf(x), ky = kindOf(y);
  const bool tx = kx == Kind::Timestamp || kx == Kind::Duration;
  const bool ty = ky == Kind::Timestamp || ky == Kind::Duration;
  if (!tx && !ty) {
    // A matrix holding time values next to plain ones cannot be built, so
    // this is a number pair inside a time operation - refuse it.
    err = "cannot combine " + kindWord(x) + " and " + kindWord(y);
    return false;
  }
  if (kx == Kind::Other || ky == Kind::Other) {
    err = "cannot combine " + typeName(x) + " and " + typeName(y);
    return false;
  }
  if ((kx == Kind::Number || ky == Kind::Number) && (op == "+" || op == "-")) {
    const Value &num = kx == Kind::Number ? x : y;
    const std::string n = num.isBool() ? (num.number != 0 ? "1" : "0") : formatNumberText(num);
    err = "cannot combine " + kindWord(x) + " and " + kindWord(y) + " \xE2\x80\x94 use seconds(" +
          n + "), minutes(" + n + "), hours(" + n + ") or days(" + n + ")";
    return false;
  }
  const Value &numOperand = kx == Kind::Number ? x : y;
  if ((kx == Kind::Number || ky == Kind::Number) &&
      (numOperand.dimL != 0 || numOperand.dimT != 0 || numOperand.dimM != 0)) {
    err = "a duration can only be scaled by a plain number, not one with a unit";
    return false;
  }

  if (op == "+") {
    int64_t ns = 0;
    if (kx == Kind::Timestamp && ky == Kind::Timestamp) {
      err = "cannot add two timestamps \xE2\x80\x94 did you mean t2 - t1?";
      return false;
    }
    if (!addNs(x.timeNs(), y.timeNs(), ns, err))
      return false;
    r = (kx == Kind::Timestamp || ky == Kind::Timestamp) ? Value::timestamp(ns)
                                                          : Value::duration(ns);
    return true;
  }
  if (op == "-") {
    int64_t ns = 0;
    if (kx == Kind::Duration && ky == Kind::Timestamp) {
      err = "cannot subtract a timestamp from a duration \xE2\x80\x94 did you mean t - d?";
      return false;
    }
    if (!subNs(x.timeNs(), y.timeNs(), ns, err))
      return false;
    r = (kx == Kind::Timestamp && ky == Kind::Duration) ? Value::timestamp(ns)
                                                         : Value::duration(ns);
    return true;
  }
  if (kx == Kind::Timestamp || ky == Kind::Timestamp) {
    err = "operator '" + op + "' is not defined for timestamp";
    return false;
  }
  if (op == "*") {
    if (kx == Kind::Duration && ky == Kind::Duration) {
      err = "operator '*' is not defined for duration * duration";
      return false;
    }
    const Value &d = kx == Kind::Duration ? x : y;
    const Value &k = kx == Kind::Duration ? y : x;
    int64_t ns = 0;
    if (!mulNs(d.timeNs(), k.number, ns, err))
      return false;
    r = Value::duration(ns);
    return true;
  }
  if (op == "/") {
    if (kx == Kind::Number) {
      err = "operator '/' is not defined for number / duration";
      return false;
    }
    if (ky == Kind::Duration) {
      if (y.timeNs() == 0) {
        err = "division by zero";
        return false;
      }
      r = Value(static_cast<double>(x.timeNs()) / static_cast<double>(y.timeNs()));
      return true;
    }
    int64_t ns = 0;
    if (!divNs(x.timeNs(), y.number, ns, err))
      return false;
    r = Value::duration(ns);
    return true;
  }
  err = "operator '" + op + "' is not defined for duration";
  return false;
}

// The time type that takes part, for "operator '^' is not defined for ...".
std::string timeSide(const Value &a, const Value &b) {
  std::vector<Value> elems;
  std::string ignored;
  for (const Value *v : {&a, &b}) {
    if (!cells::elementsOf(*v, "", elems, ignored))
      continue;
    for (const Value &e : elems)
      if (e.isTime())
        return typeName(e);
  }
  return "timestamp";
}

bool elementCompare(const std::string &op, const Value &x, const Value &y, bool &result,
                    std::string &err) {
  if (!x.isTime() || !y.isTime() || x.isTimestamp() != y.isTimestamp()) {
    err = "cannot compare " + kindWord(x) + " with " + kindWord(y);
    return false;
  }
  const int64_t a = x.timeNs(), b = y.timeNs();
  if (op == "==") result = a == b;
  else if (op == "!=") result = a != b;
  else if (op == "<") result = a < b;
  else if (op == ">") result = a > b;
  else if (op == "<=") result = a <= b;
  else result = a >= b; // ">="
  return true;
}

} // namespace

TimeOpResult timeBinaryOp(const std::string &opIn, const Value &a, const Value &b, Value &out,
                          std::string &err) {
  if (!containsTime(a) && !containsTime(b))
    return TimeOpResult::NotTime;

  Shape sa, sb;
  if (!cells::shapeOf(a, sa, "'" + opIn + "'", err) ||
      !cells::shapeOf(b, sb, "'" + opIn + "'", err))
    return TimeOpResult::Error;

  if ((opIn == "*" || opIn == "/") && !sa.single() && !sb.single()) {
    err = std::string("matrix ") + (opIn == "*" ? "multiplication" : "division") +
          " is not defined for " + timeSide(a, b) + " \xE2\x80\x94 use " + opIn +
          ". for element by element";
    return TimeOpResult::Error;
  }
  std::string op = opIn;
  if (op == "*.")
    op = "*";
  else if (op == "/.")
    op = "/";
  if (op != "+" && op != "-" && op != "*" && op != "/") {
    err = "operator '" + opIn + "' is not defined for " + timeSide(a, b);
    return TimeOpResult::Error;
  }
  if (!sa.single() && !sb.single() && (sa.rows != sb.rows || sa.cols != sb.cols)) {
    err = "'" + opIn + "' needs two matrices of the same size, got " + cells::shapeText(sa) +
          " and " + cells::shapeText(sb);
    return TimeOpResult::Error;
  }
  const bool ok = cells::mapCells(
      "'" + opIn + "'", {&a, &b},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        return elementOp(op, e[0], e[1], r, er);
      },
      out, err);
  return ok ? TimeOpResult::Ok : TimeOpResult::Error;
}

TimeOpResult timeCompare(const std::string &op, const Value &a, const Value &b, Value &out,
                         std::string &err) {
  if (!containsTime(a) && !containsTime(b))
    return TimeOpResult::NotTime;
  if (op != "==" && op != "!=" && op != "<" && op != ">" && op != "<=" && op != ">=") {
    err = "'" + op + "' is not supported for timestamps and durations";
    return TimeOpResult::Error;
  }
  Shape sa, sb;
  if (!cells::shapeOf(a, sa, "'" + op + "'", err) || !cells::shapeOf(b, sb, "'" + op + "'", err))
    return TimeOpResult::Error;

  // Two matrices: one answer for the whole pair, like numbers.
  if (!sa.single() && !sb.single()) {
    if (sa.rows != sb.rows || sa.cols != sb.cols) {
      err = "cannot compare a " + cells::shapeText(sa) + " matrix with a " +
            cells::shapeText(sb) +
            " matrix - both sides must have the same size, or one side must be a single value";
      return TimeOpResult::Error;
    }
    bool all = true, anyDiffers = false;
    for (size_t k = 0; k < sa.count(); k++) {
      bool r = false;
      const std::string pairOp = (op == "!=") ? "==" : op;
      if (!elementCompare(pairOp, cells::cellOf(a, sa, k), cells::cellOf(b, sb, k), r, err))
        return TimeOpResult::Error;
      all = all && r;
      anyDiffers = anyDiffers || !r;
    }
    out = Value::boolean(op == "!=" ? anyDiffers : all);
    return TimeOpResult::Ok;
  }
  const bool ok = cells::mapCells(
      "'" + op + "'", {&a, &b},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        bool res = false;
        if (!elementCompare(op, e[0], e[1], res, er))
          return false;
        r = Value::boolean(res);
        return true;
      },
      out, err);
  return ok ? TimeOpResult::Ok : TimeOpResult::Error;
}

bool timeNegate(const Value &a, Value &out, std::string &err) {
  return cells::mapCells(
      "'-'", {&a},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!e[0].isDuration()) {
          er = "operator '-' (negation) is not defined for " + typeName(e[0]);
          return false;
        }
        int64_t ns = 0;
        if (!subNs(0, e[0].timeNs(), ns, er))
          return false;
        r = Value::duration(ns);
        return true;
      },
      out, err);
}

bool timeAbs(const Value &a, Value &out, std::string &err) {
  return cells::mapCells(
      "abs", {&a},
      [&](const std::vector<Value> &e, Value &r, std::string &er) {
        if (!e[0].isDuration()) {
          er = "abs expects a duration or numbers, got " + typeName(e[0]);
          return false;
        }
        const int64_t ns = e[0].timeNs();
        if (ns == std::numeric_limits<int64_t>::min()) {
          er = kRangeError;
          return false;
        }
        r = Value::duration(ns < 0 ? -ns : ns);
        return true;
      },
      out, err);
}

} // namespace nctime
