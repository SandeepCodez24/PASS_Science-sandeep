// Date and time for NC: two value types (core/value.h)
//
//   timestamp   a point in time   int64 nanoseconds since 1970-01-01 00:00:00 UTC
//   duration    a length of time  int64 nanoseconds (may be negative)
//
// Every timestamp is stored in UTC. A time zone matters only where a
// timestamp meets calendar parts or text: building one from parts or text,
// reading its parts, and printing it. The zone is the computer's own unless
// a function is given one by name ("UTC", "Asia/Kolkata", "Europe/Berlin").
//
// Time zones come from C++20 <chrono> (std::chrono::locate_zone), which the
// MSVC STL backs with the Windows ICU time-zone database - the same rules
// for every country, with daylight saving, no third-party dependency.
// Leap seconds are ignored (std::chrono::system_clock).
//
// The range of int64 nanoseconds is about 292 years either side of 1970
// (1677-09-21 to 2262-04-11); a result outside it is an error, never a
// silent wrap-around.
//
// Daylight saving: a duration is real elapsed time (t2 - t1 across a
// change of clocks is 23 or 25 hours), days(1) is exactly 24 hours, and a
// local time inside a gap (clocks jump forward) is an error; one inside an
// overlap (clocks fall back) means the EARLIER of the two instants.
#pragma once

#include <chrono>
#include <cstdint>
#include <string>

#include "../../core/value.h"

namespace nctime {

constexpr int64_t kNsPerSecond = 1000000000LL;
constexpr int64_t kNsPerMinute = 60 * kNsPerSecond;
constexpr int64_t kNsPerHour = 60 * kNsPerMinute;
constexpr int64_t kNsPerDay = 24 * kNsPerHour;

// The message for any result outside the int64 nanosecond range.
extern const char *const kRangeError;

// Prints "Error: time error: <message>" - the one way this module reports
// a problem (an "Error" line stops the statement, core/error_lines.h).
void reportTimeError(const std::string &message);

// The time zone called `name`; "" is the computer's own zone. False (with
// `err`) for a name the time-zone database does not know.
bool findZone(const std::string &name, const std::chrono::time_zone *&zone, std::string &err);

// Calendar date and time of day of a timestamp in `zone`.
struct LocalParts {
  int year = 1970;
  unsigned month = 1, day = 1;
  unsigned hour = 0, minute = 0, second = 0;
  int64_t nanos = 0; // within the second, 0 .. 999 999 999
};
LocalParts toLocalParts(int64_t ns, const std::chrono::time_zone *zone);

// The timestamp of a local date and time in `zone`. Every part is checked -
// month 1-12, a day that exists in that month (leap years), hour 0-23,
// minute 0-59, 0 <= second < 60 - nothing rolls over. `second` may have a
// fraction (rounded to the nearest nanosecond).
bool fromLocalParts(double year, double month, double day, double hour, double minute,
                    double second, const std::chrono::time_zone *zone, int64_t &ns,
                    std::string &err);

// The first instant of the local calendar day holding `ns` in `zone` -
// midnight, or the first moment after it where clocks jump forward at
// midnight (a few zones do). False (with `err`) out of range.
bool startOfLocalDay(int64_t ns, const std::chrono::time_zone *zone, int64_t &out,
                     std::string &err);

// Local calendar days as numbers: day 0 is 1970-01-01, day 1 the next ...
// The day of `ns` in `zone`.
int64_t localDayNumber(int64_t ns, const std::chrono::time_zone *zone);
// The first instant of local day `dayNumber` in `zone` (see startOfLocalDay).
bool localDayStart(int64_t dayNumber, const std::chrono::time_zone *zone, int64_t &out,
                   std::string &err);

// ISO 8601 text: "YYYY-MM-DD", "YYYY-MM-DD hh:mm:ss" or "YYYY-MM-DDThh:mm:ss",
// optional ".fff..." (up to 9 digits), optional "Z" or "+hh:mm" / "-hh:mm".
// An offset or Z in the text wins over `zone`.
bool parseTimestamp(const std::string &text, const std::chrono::time_zone *zone, int64_t &ns,
                    std::string &err);

// Text of a timestamp in `zone`, from a pattern: YYYY year, MM month, DD day,
// hh hour (00-23), mm minute, ss second, fff milliseconds; any other
// character is copied as it is.
std::string formatTimestamp(int64_t ns, const std::string &pattern,
                            const std::chrono::time_zone *zone);

// How a timestamp prints (local time): "2026-10-28 14:30:00", with the
// fraction of a second only when it is not zero (".250", or 6 / 9 digits
// when milliseconds are not enough).
std::string displayTimestamp(int64_t ns);

// How a duration prints: "01:30:15", "-01:30:00", "123:00:00", "00:00:01.250"
// - hours at least two digits and never wrapped at 24.
std::string formatDuration(int64_t ns);

// The display text of a timestamp or duration Value.
std::string displayText(const Value &v);

// A value's type for messages: "timestamp", "duration", "float64", "int32",
// "bool", "text", "complex128", "matrix", ...
std::string typeName(const Value &v);

// `n` units (unitNs nanoseconds each) as a duration, rounded to the nearest
// nanosecond. False (with `err`) when n is not finite or out of range.
bool durationFromNumber(double n, int64_t unitNs, int64_t &out, std::string &err);

// True if `v` is a time value or a container holding one.
bool containsTime(const Value &v);

/* ---- operators (time_ops.cpp) ---- */

enum class TimeOpResult {
  NotTime, // neither side holds a time value - the numeric rules apply
  Ok,      // `out` is the result
  Error    // `err` says why (print it with reportTimeError)
};

// a op b for + - * / *. /. (and the refused ^ ^. % //).
TimeOpResult timeBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                          std::string &err);
// a op b for == != < > <= >=.
TimeOpResult timeCompare(const std::string &op, const Value &a, const Value &b, Value &out,
                         std::string &err);
// -a, element by element (durations only).
bool timeNegate(const Value &a, Value &out, std::string &err);
// abs(a) / |a|, element by element (durations only).
bool timeAbs(const Value &a, Value &out, std::string &err);

// The time functions (seconds(), timestamp(), ...), dispatched from
// builtins.cpp's builtinTable.
bool isTimeFunction(const std::string &lowerName);

} // namespace nctime
