// Element-by-element plumbing shared by the time functions and operators
// (time_builtin.cpp, time_ops.cpp). Private to ops/time/.
//
// A time function or operator takes single values, 1-D arrays and 2-D
// matrices. Several inputs must share one shape, or be single values (which
// are repeated) - the same rule as NC's numeric element-wise operators. The
// result has that shape. N-D matrices are refused.
#pragma once

#include <functional>
#include <string>
#include <utility>
#include <vector>

#include "../../core/value.h"

namespace nctime {
namespace cells {

struct Shape {
  int kind = 0; // 0 single value, 1 array, 2 matrix
  size_t rows = 1, cols = 1;
  size_t count() const { return rows * cols; }
  bool single() const { return kind == 0; }
};

inline bool shapeOf(const Value &v, Shape &s, const std::string &fn, std::string &err) {
  if (v.isND()) {
    err = fn + " works on single values, vectors and 2-D matrices, not a " +
          std::to_string(v.ndShape().size()) + "-D matrix";
    return false;
  }
  if (v.isMatrix) {
    s.kind = 2;
    s.rows = v.rows();
    s.cols = v.rows() == 0 ? 0 : v.cols();
  } else if (v.isArray) {
    s.kind = 1;
    s.rows = v.length() == 0 ? 0 : 1;
    s.cols = v.length();
  } else {
    s = Shape{};
  }
  return true;
}

inline std::string shapeText(const Shape &s) {
  return std::to_string(s.rows) + "x" + std::to_string(s.cols);
}

// Element k (row by row) of a value of shape `s`; a single value is itself.
inline Value cellOf(const Value &v, const Shape &s, size_t k) {
  if (s.kind == 0)
    return v;
  if (s.kind == 1)
    return v.at(k);
  return v.at(k / s.cols, k % s.cols);
}

// The shape all `inputs` share (single values aside).
inline bool commonShape(const std::vector<const Value *> &inputs, const std::string &fn,
                        std::vector<Shape> &shapes, Shape &out, std::string &err) {
  shapes.assign(inputs.size(), Shape{});
  out = Shape{};
  for (size_t i = 0; i < inputs.size(); i++) {
    if (!shapeOf(*inputs[i], shapes[i], fn, err))
      return false;
    const Shape &s = shapes[i];
    if (s.kind == 0)
      continue;
    if (out.kind == 0) {
      out = s;
    } else if (s.rows != out.rows || s.cols != out.cols) {
      err = fn + ": the inputs must have the same size, or be single values (got " +
            shapeText(out) + " and " + shapeText(s) + ")";
      return false;
    }
  }
  return true;
}

// A value of shape `s` from its elements, row by row.
inline Value buildLike(const Shape &s, std::vector<Value> cells) {
  if (s.kind == 0)
    return cells.empty() ? Value(0.0) : cells[0];
  if (s.kind == 1)
    return Value(std::move(cells));
  std::vector<std::vector<Value>> rows(s.rows);
  for (size_t r = 0; r < s.rows; r++)
    rows[r].assign(cells.begin() + r * s.cols, cells.begin() + (r + 1) * s.cols);
  return Value(std::move(rows));
}

using CellFn = std::function<bool(const std::vector<Value> &, Value &, std::string &)>;

// fn(elements...) at every position of `inputs`. fn reports its own
// problem through `err` and returns false.
inline bool mapCells(const std::string &fnName, const std::vector<const Value *> &inputs,
                     const CellFn &fn, Value &out, std::string &err) {
  std::vector<Shape> shapes;
  Shape shape;
  if (!commonShape(inputs, fnName, shapes, shape, err))
    return false;
  std::vector<Value> result;
  result.reserve(shape.count());
  std::vector<Value> elems(inputs.size());
  for (size_t k = 0; k < shape.count(); k++) {
    for (size_t i = 0; i < inputs.size(); i++)
      elems[i] = cellOf(*inputs[i], shapes[i], k);
    Value r;
    if (!fn(elems, r, err))
      return false;
    result.push_back(std::move(r));
  }
  out = buildLike(shape, std::move(result));
  return true;
}

// Every element of `v` (row by row); a single value is one element.
inline bool elementsOf(const Value &v, const std::string &fn, std::vector<Value> &out,
                       std::string &err) {
  Shape s;
  if (!shapeOf(v, s, fn, err))
    return false;
  out.clear();
  for (size_t k = 0; k < s.count(); k++)
    out.push_back(cellOf(v, s, k));
  return true;
}

} // namespace cells
} // namespace nctime
