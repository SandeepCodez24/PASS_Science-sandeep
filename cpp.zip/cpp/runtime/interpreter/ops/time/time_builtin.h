#pragma once

#include <string>
#include <vector>

#include "../../core/value.h"

// The time functions (ops/time/time.h): get_timestamp, timestamp,
// to_timestamp, seconds, minutes, hours, days. Every one works element by
// element on a matrix and keeps its shape.
Value timeBuiltin(const std::string &name, const std::vector<Value> &args);

namespace nctime {

// A call to a function that is NOT a time function, with a timestamp or
// duration among its arguments (callBuiltin(), builtins.cpp):
enum class TimeArgs {
  PassThrough, // the function only looks at the shape (size, numel, transpose ...) - run it as usual
  Done,        // handled here (abs of a duration, str of a time value) - `out` is the result
  Refused      // the function would read the value as a number - error printed
};
TimeArgs timeArgsCall(const std::string &lowerName, const std::vector<Value> &args, Value &out);

} // namespace nctime
