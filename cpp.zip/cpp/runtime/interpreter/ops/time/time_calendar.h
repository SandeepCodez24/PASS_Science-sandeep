// Calendar functions on timestamps (time_calendar.cpp). Private to ops/time/;
// reached through timeBuiltin() (time_builtin.cpp). Each reports its own
// problem (reportTimeError) and then returns Value(0).
#pragma once

#include <vector>

#include "../../core/value.h"

namespace nctime {

// date_range(start, stop[, step])
Value dateRange(const std::vector<Value> &args);
// is_busday(t, weekmask, zone[, holidays])
Value isBusday(const std::vector<Value> &args);
// busday_count(begin, end, weekmask, zone[, holidays])
Value busdayCount(const std::vector<Value> &args);
// busday_offset(t, offsets, roll, weekmask, zone[, holidays])
Value busdayOffset(const std::vector<Value> &args);

} // namespace nctime
