#include "time.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <unordered_set>

#include "../../core/output.h"

namespace nctime {

using namespace std::chrono;

const char *const kRangeError =
    "result is out of the supported range (about years 1678\xE2\x80\x93" "2261)";

void reportTimeError(const std::string &message) {
  std::cerr << "Error: time error: " << message << "\n";
}

namespace {

constexpr int64_t kInt64Max = std::numeric_limits<int64_t>::max();
constexpr int64_t kInt64Min = std::numeric_limits<int64_t>::min();

// The en dash used in the "expected 1-12" ranges of the messages.
const char *const kDash = "\xE2\x80\x93";

bool fitsInt64(__int128 x) { return x >= kInt64Min && x <= kInt64Max; }

// Floor division in int64 (128-bit division needs a runtime helper the
// MSVC target does not link).
int64_t floorDiv(int64_t a, int64_t b, int64_t &rem) {
  int64_t q = a / b, r = a % b;
  if (r < 0) {
    q -= 1;
    r += b;
  }
  rem = r;
  return q;
}

std::string numberText(double x) { return formatNumber(x); }

std::string pad(long long v, int width) {
  char buf[32];
  std::snprintf(buf, sizeof buf, "%0*lld", width, v);
  return buf;
}

// ".250", ".250500", ".250500125" - the fewest groups of three digits that
// show the fraction exactly; "" for a whole second.
std::string fractionText(int64_t nanos) {
  if (nanos == 0)
    return "";
  if (nanos % 1000000 == 0)
    return "." + pad(nanos / 1000000, 3);
  if (nanos % 1000 == 0)
    return "." + pad(nanos / 1000, 6);
  return "." + pad(nanos, 9);
}

// A whole number in [lo, hi], or an "invalid <what> ..." message.
bool checkPart(const char *what, double v, long long lo, long long hi, std::string &err) {
  if (!std::isfinite(v) || v != std::floor(v) || v < lo || v > hi) {
    err = std::string("invalid ") + what + " " + numberText(v) + " (expected " +
          (std::isfinite(v) && v != std::floor(v) ? "a whole number " : "") + std::to_string(lo) +
          kDash + std::to_string(hi) + ")";
    return false;
  }
  return true;
}

const time_zone *localZone() {
  static const time_zone *zone = [] {
    try {
      return current_zone();
    } catch (const std::exception &) {
      return locate_zone("UTC");
    }
  }();
  return zone;
}

} // namespace

bool findZone(const std::string &name, const time_zone *&zone, std::string &err) {
  if (name.empty()) {
    zone = localZone();
    return true;
  }
  try {
    zone = locate_zone(name);
    return true;
  } catch (const std::exception &) {
    err = "unknown time zone \"" + name + "\"";
    return false;
  }
}

LocalParts toLocalParts(int64_t ns, const time_zone *zone) {
  const sys_seconds secs = floor<seconds>(sys_time<nanoseconds>{nanoseconds{ns}});
  const int64_t offset = zone->get_info(secs).offset.count(); // |offset| < 1 day
  // UTC day and time of day first, then the zone offset - each step stays
  // inside int64 even at the ends of the range.
  int64_t rem = 0;
  int64_t dayCount = floorDiv(ns, kNsPerDay, rem);
  rem += offset * kNsPerSecond;
  if (rem < 0) {
    rem += kNsPerDay;
    dayCount--;
  } else if (rem >= kNsPerDay) {
    rem -= kNsPerDay;
    dayCount++;
  }
  const year_month_day ymd{sys_days{days{dayCount}}};
  LocalParts p;
  p.year = static_cast<int>(ymd.year());
  p.month = static_cast<unsigned>(ymd.month());
  p.day = static_cast<unsigned>(ymd.day());
  p.hour = static_cast<unsigned>(rem / kNsPerHour);
  rem %= kNsPerHour;
  p.minute = static_cast<unsigned>(rem / kNsPerMinute);
  rem %= kNsPerMinute;
  p.second = static_cast<unsigned>(rem / kNsPerSecond);
  p.nanos = rem % kNsPerSecond;
  return p;
}

bool fromLocalParts(double yearIn, double monthIn, double dayIn, double hourIn, double minuteIn,
                    double secondIn, const time_zone *zone, int64_t &ns, std::string &err) {
  // Years far outside the range are refused before they reach <chrono>,
  // whose year type holds -32767 .. 32767.
  if (!std::isfinite(yearIn) || yearIn != std::floor(yearIn)) {
    err = "invalid year " + numberText(yearIn) + " (expected a whole number)";
    return false;
  }
  if (yearIn < 1000 || yearIn > 9999) {
    err = kRangeError;
    return false;
  }
  if (!checkPart("month", monthIn, 1, 12, err))
    return false;
  const int y = static_cast<int>(yearIn);
  const unsigned mo = static_cast<unsigned>(monthIn);
  const unsigned lastDay =
      static_cast<unsigned>(year_month_day_last{year{y} / month{mo} / last}.day());
  if (!checkPart("day", dayIn, 1, lastDay, err)) {
    // "invalid day 29 for 2026-02 (expected 1-28)"
    err.insert(err.find(" ("), " for " + pad(y, 4) + "-" + pad(mo, 2));
    return false;
  }
  if (!checkPart("hour", hourIn, 0, 23, err) || !checkPart("minute", minuteIn, 0, 59, err))
    return false;
  if (!std::isfinite(secondIn) || secondIn < 0 || secondIn >= 60) {
    err = "invalid second " + numberText(secondIn) + " (expected 0 \xE2\x89\xA4 s < 60)";
    return false;
  }

  const double wholeSec = std::floor(secondIn);
  int64_t fracNs = std::llround((secondIn - wholeSec) * 1e9);
  const local_seconds lsec = local_days{year{y} / month{mo} / day{static_cast<unsigned>(dayIn)}} +
                             hours{static_cast<int>(hourIn)} + minutes{static_cast<int>(minuteIn)} +
                             seconds{static_cast<int>(wholeSec)};
  const local_info info = zone->get_info(lsec);
  if (info.result == local_info::nonexistent) {
    err = pad(static_cast<long long>(hourIn), 2) + ":" + pad(static_cast<long long>(minuteIn), 2) +
          ":" + pad(static_cast<long long>(wholeSec), 2) + " on " + pad(y, 4) + "-" + pad(mo, 2) +
          "-" + pad(static_cast<long long>(dayIn), 2) + " does not exist in time zone \"" +
          std::string(zone->name()) + "\"";
    return false;
  }
  // unique: the one offset; ambiguous (clocks fall back): `first` is the
  // offset before the change, i.e. the EARLIER of the two instants.
  const int64_t offset = info.first.offset.count();
  const __int128 total =
      (static_cast<__int128>(lsec.time_since_epoch().count()) - offset) * kNsPerSecond + fracNs;
  if (!fitsInt64(total)) {
    err = kRangeError;
    return false;
  }
  ns = static_cast<int64_t>(total);
  return true;
}

int64_t localDayNumber(int64_t ns, const time_zone *zone) {
  const LocalParts p = toLocalParts(ns, zone);
  return sys_days{year{p.year} / month{p.month} / day{p.day}}.time_since_epoch().count();
}

bool startOfLocalDay(int64_t ns, const time_zone *zone, int64_t &out, std::string &err) {
  return localDayStart(localDayNumber(ns, zone), zone, out, err);
}

bool localDayStart(int64_t dayNumber, const time_zone *zone, int64_t &out, std::string &err) {
  // Far outside the timestamp range: refused before <chrono> sees it.
  if (dayNumber < -110000 || dayNumber > 110000) {
    err = kRangeError;
    return false;
  }
  const local_seconds midnight{local_days{days{dayNumber}}};
  const local_info info = zone->get_info(midnight);
  int64_t secs = 0;
  if (info.result == local_info::nonexistent)
    secs = info.second.begin.time_since_epoch().count(); // clocks jump over midnight
  else
    secs = midnight.time_since_epoch().count() - info.first.offset.count();
  const __int128 total = static_cast<__int128>(secs) * kNsPerSecond;
  if (!fitsInt64(total)) {
    err = kRangeError;
    return false;
  }
  out = static_cast<int64_t>(total);
  return true;
}

namespace {

bool readDigits(const std::string &s, size_t &pos, size_t count, int &out) {
  if (pos + count > s.size())
    return false;
  int v = 0;
  for (size_t i = 0; i < count; i++) {
    const char c = s[pos + i];
    if (c < '0' || c > '9')
      return false;
    v = v * 10 + (c - '0');
  }
  pos += count;
  out = v;
  return true;
}

} // namespace

bool parseTimestamp(const std::string &textIn, const time_zone *zone, int64_t &ns,
                    std::string &err) {
  // Surrounding spaces are not part of the value.
  size_t b = textIn.find_first_not_of(" \t\r\n");
  size_t e = textIn.find_last_not_of(" \t\r\n");
  const std::string s = b == std::string::npos ? "" : textIn.substr(b, e - b + 1);
  const std::string parseErr = "cannot parse \"" + textIn +
                               "\" as timestamp (expected ISO 8601, e.g. \"2026-10-28 14:30:00\")";

  size_t pos = 0;
  int y = 0, mo = 0, d = 0, h = 0, mi = 0, sec = 0;
  int64_t frac = 0;
  if (!readDigits(s, pos, 4, y) || pos >= s.size() || s[pos++] != '-' ||
      !readDigits(s, pos, 2, mo) || pos >= s.size() || s[pos++] != '-' ||
      !readDigits(s, pos, 2, d)) {
    err = parseErr;
    return false;
  }
  if (pos < s.size() && (s[pos] == 'T' || s[pos] == 't' || s[pos] == ' ')) {
    pos++;
    if (!readDigits(s, pos, 2, h) || pos >= s.size() || s[pos++] != ':' ||
        !readDigits(s, pos, 2, mi)) {
      err = parseErr;
      return false;
    }
    if (pos < s.size() && s[pos] == ':') {
      pos++;
      if (!readDigits(s, pos, 2, sec)) {
        err = parseErr;
        return false;
      }
      if (pos < s.size() && (s[pos] == '.' || s[pos] == ',')) {
        pos++;
        size_t digits = 0;
        while (pos < s.size() && s[pos] >= '0' && s[pos] <= '9') {
          if (digits < 9)
            frac = frac * 10 + (s[pos] - '0');
          digits++;
          pos++;
        }
        if (digits == 0) {
          err = parseErr;
          return false;
        }
        for (size_t k = digits; k < 9; k++)
          frac *= 10;
      }
    }
  }

  // Optional UTC offset: Z, +hh:mm, -hh:mm (also +hhmm, +hh).
  bool hasOffset = false;
  int64_t offsetSec = 0;
  if (pos < s.size() && (s[pos] == 'Z' || s[pos] == 'z')) {
    hasOffset = true;
    pos++;
  } else if (pos < s.size() && (s[pos] == '+' || s[pos] == '-')) {
    const int sign = s[pos] == '-' ? -1 : 1;
    pos++;
    int oh = 0, om = 0;
    if (!readDigits(s, pos, 2, oh)) {
      err = parseErr;
      return false;
    }
    if (pos < s.size() && s[pos] == ':')
      pos++;
    if (pos < s.size() && !readDigits(s, pos, 2, om)) {
      err = parseErr;
      return false;
    }
    if (oh > 23 || om > 59) {
      err = parseErr;
      return false;
    }
    hasOffset = true;
    offsetSec = sign * (oh * 3600LL + om * 60LL);
  }
  if (pos != s.size()) {
    err = parseErr;
    return false;
  }

  // Every field must name a real date and time.
  if (mo < 1 || mo > 12 || d < 1 || h > 23 || mi > 59 || sec > 59 ||
      static_cast<unsigned>(d) >
          static_cast<unsigned>(year_month_day_last{year{y} / month{static_cast<unsigned>(mo)} /
                                                    last}
                                    .day())) {
    err = parseErr;
    return false;
  }

  if (!hasOffset) {
    std::string partErr;
    if (!fromLocalParts(y, mo, d, h, mi, sec, zone, ns, partErr)) {
      err = partErr;
      return false;
    }
    __int128 total = static_cast<__int128>(ns) + frac;
    if (!fitsInt64(total)) {
      err = kRangeError;
      return false;
    }
    ns = static_cast<int64_t>(total);
    return true;
  }
  if (y < 1000) {
    err = kRangeError;
    return false;
  }
  const local_seconds lsec = local_days{year{y} / month{static_cast<unsigned>(mo)} /
                                        day{static_cast<unsigned>(d)}} +
                             hours{h} + minutes{mi} + seconds{sec};
  const __int128 total =
      (static_cast<__int128>(lsec.time_since_epoch().count()) - offsetSec) * kNsPerSecond + frac;
  if (!fitsInt64(total)) {
    err = kRangeError;
    return false;
  }
  ns = static_cast<int64_t>(total);
  return true;
}

std::string formatTimestamp(int64_t ns, const std::string &pattern, const time_zone *zone) {
  const LocalParts p = toLocalParts(ns, zone);
  std::string out;
  for (size_t i = 0; i < pattern.size();) {
    auto at = [&](const char *token) {
      const size_t n = std::char_traits<char>::length(token);
      return pattern.compare(i, n, token) == 0;
    };
    if (at("YYYY")) {
      out += pad(p.year, 4);
      i += 4;
    } else if (at("fff")) {
      out += pad(p.nanos / 1000000, 3);
      i += 3;
    } else if (at("MM")) {
      out += pad(p.month, 2);
      i += 2;
    } else if (at("DD")) {
      out += pad(p.day, 2);
      i += 2;
    } else if (at("hh")) {
      out += pad(p.hour, 2);
      i += 2;
    } else if (at("mm")) {
      out += pad(p.minute, 2);
      i += 2;
    } else if (at("ss")) {
      out += pad(p.second, 2);
      i += 2;
    } else {
      out += pattern[i++];
    }
  }
  return out;
}

std::string displayTimestamp(int64_t ns) {
  const time_zone *zone = localZone();
  const LocalParts p = toLocalParts(ns, zone);
  return formatTimestamp(ns, "YYYY-MM-DD hh:mm:ss", zone) + fractionText(p.nanos);
}

std::string formatDuration(int64_t ns) {
  const uint64_t a = ns < 0 ? 0 - static_cast<uint64_t>(ns) : static_cast<uint64_t>(ns);
  const uint64_t h = a / kNsPerHour;
  const uint64_t m = (a % kNsPerHour) / kNsPerMinute;
  const uint64_t s = (a % kNsPerMinute) / kNsPerSecond;
  const int64_t nanos = static_cast<int64_t>(a % kNsPerSecond);
  return std::string(ns < 0 ? "-" : "") + pad(static_cast<long long>(h), 2) + ":" +
         pad(static_cast<long long>(m), 2) + ":" + pad(static_cast<long long>(s), 2) +
         fractionText(nanos);
}

std::string displayText(const Value &v) {
  if (v.isTimestamp())
    return displayTimestamp(v.timeNs());
  if (v.isDuration())
    return formatDuration(v.timeNs());
  return "";
}

std::string typeName(const Value &v) {
  if (v.isTimestamp())
    return "timestamp";
  if (v.isDuration())
    return "duration";
  if (v.isText)
    return "text";
  if (v.isArray || v.isMatrix)
    return "matrix";
  if (v.isDict)
    return "dict";
  if (v.isObject)
    return "object";
  if (v.isFunctionRef)
    return "function reference";
  if (v.isComplex)
    return "complex128";
  if (v.isBool())
    return "bool";
  switch (v.intType()) {
  case IntType::Int8: return "int8";
  case IntType::Int16: return "int16";
  case IntType::Int32: return "int32";
  case IntType::Int64: return "int64";
  case IntType::UInt8: return "uint8";
  case IntType::UInt16: return "uint16";
  case IntType::UInt32: return "uint32";
  case IntType::UInt64: return "uint64";
  case IntType::None: break;
  }
  switch (v.floatType()) {
  case FloatType::Float8: return "float8";
  case FloatType::Float16: return "float16";
  case FloatType::Float32: return "float32";
  case FloatType::Float64: break;
  }
  return "float64";
}

bool durationFromNumber(double n, int64_t unitNs, int64_t &out, std::string &err) {
  if (!std::isfinite(n)) {
    err = kRangeError;
    return false;
  }
  // Whole part in exact integer arithmetic, fraction rounded separately, so
  // days(100.5) is exact to the nanosecond.
  double whole = 0.0;
  const double frac = std::modf(n, &whole);
  if (std::fabs(whole) >= 9.3e18) {
    err = kRangeError;
    return false;
  }
  int64_t ns = 0;
  if (__builtin_mul_overflow(static_cast<int64_t>(whole), unitNs, &ns) ||
      __builtin_add_overflow(ns, static_cast<int64_t>(std::llround(frac * unitNs)), &ns)) {
    err = kRangeError;
    return false;
  }
  out = ns;
  return true;
}

bool containsTime(const Value &v) {
  if (v.isTime())
    return true;
  if (v.isND()) {
    if (v.isPacked() || v.isPackedComplex())
      return false;
    for (size_t k = 0; k < v.ndCount(); k++)
      if (containsTime(v.ndAt(k)))
        return true;
    return false;
  }
  if (v.isMatrix) {
    if (v.isPacked() || v.isPackedComplex())
      return false;
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        if (containsTime(v.at(r, c)))
          return true;
    return false;
  }
  if (v.isArray) {
    if (v.isPacked() || v.isPackedComplex())
      return false;
    for (size_t i = 0; i < v.length(); i++)
      if (containsTime(v.at(i)))
        return true;
  }
  return false;
}

bool isTimeFunction(const std::string &lowerName) {
  static const std::unordered_set<std::string> names = {
      "get_timestamp", "timestamp",  "to_timestamp", "seconds",    "minutes",
      "hours",         "days",       "today",        "get_time",   "get_date",
      "set_time",      "set_date",   "format_time",  "in_seconds", "in_minutes",
      "in_hours",      "in_days",    "in_hms",       "in_hrs_min_sec",
      "format_duration", "tic", "toc", "date_range", "is_busday", "busday_count",
      "busday_offset"};
  return names.count(lowerName) != 0;
}

} // namespace nctime
