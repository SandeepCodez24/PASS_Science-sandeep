#include "integer.h"

#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>

#include "../arithmetic/arithmetic.h" // tryCoerceTextToNumber

namespace {

// ---------------------------------------------------------------------------
// Wide: one exact integer covering every int8 ... uint64 value, i.e. the
// range -2^64 + 1 ... 2^64 - 1, as a sign and a 64-bit magnitude.
//
// Deliberately NOT __int128: on the clang + lld-link (x86_64-pc-windows-msvc)
// toolchain, 128-bit multiply/divide/convert compile to calls into
// compiler-rt (__divti3, __floattidf, __fixdfti, ...), which that build does
// not link. Everything here is plain 64-bit arithmetic the CPU does
// natively, so it builds the same with clang, MinGW-gcc, gcc and MSVC.
//
// An operation whose exact result leaves that range reports overflow; such a
// result is outside every supported integer type anyway.
// ---------------------------------------------------------------------------
struct Wide
{
    bool neg = false; // never set for zero
    uint64_t mag = 0;

    static Wide fromSigned(int64_t v)
    {
        Wide w;
        w.neg = v < 0;
        // Magnitude without overflow, INT64_MIN included.
        w.mag = w.neg ? static_cast<uint64_t>(-(v + 1)) + 1u : static_cast<uint64_t>(v);
        return w;
    }
    static Wide fromUnsigned(uint64_t v)
    {
        Wide w;
        w.mag = v;
        return w;
    }
    static Wide make(bool negative, uint64_t magnitude)
    {
        Wide w;
        w.mag = magnitude;
        w.neg = negative && magnitude != 0;
        return w;
    }

    Wide negated() const { return make(!neg, mag); }

    double toDouble() const
    {
        double d = static_cast<double>(mag);
        return neg ? -d : d;
    }

    std::string toString() const { return (neg ? "-" : "") + std::to_string(mag); }
};

int compare(const Wide &a, const Wide &b)
{
    if (a.neg != b.neg)
        return a.neg ? -1 : 1;
    if (a.mag == b.mag)
        return 0;
    const bool magLess = a.mag < b.mag;
    // Both negative: the larger magnitude is the smaller number.
    return (magLess != a.neg) ? -1 : 1;
}

// a + b; false on overflow.
bool addWide(const Wide &a, const Wide &b, Wide &out)
{
    if (a.neg == b.neg) {
        uint64_t sum = a.mag + b.mag;
        if (sum < a.mag)
            return false; // magnitude past 2^64 - 1
        out = Wide::make(a.neg, sum);
        return true;
    }
    // Opposite signs: the result takes the sign of the larger magnitude.
    if (a.mag >= b.mag)
        out = Wide::make(a.neg, a.mag - b.mag);
    else
        out = Wide::make(b.neg, b.mag - a.mag);
    return true;
}

bool subWide(const Wide &a, const Wide &b, Wide &out) { return addWide(a, b.negated(), out); }

bool mulWide(const Wide &a, const Wide &b, Wide &out)
{
    if (a.mag != 0 && b.mag > std::numeric_limits<uint64_t>::max() / a.mag)
        return false;
    out = Wide::make(a.neg != b.neg, a.mag * b.mag);
    return true;
}

// Truncated quotient and remainder (C semantics: the remainder has the sign
// of the dividend). `b` must not be zero.
void divModWide(const Wide &a, const Wide &b, Wide &quot, Wide &rem)
{
    quot = Wide::make(a.neg != b.neg, a.mag / b.mag);
    rem = Wide::make(a.neg, a.mag % b.mag);
}

struct Range
{
    Wide lo;
    Wide hi;
};

Range rangeOf(IntType t)
{
    switch (t) {
    case IntType::Int8:
        return {Wide::fromSigned(INT8_MIN), Wide::fromSigned(INT8_MAX)};
    case IntType::Int16:
        return {Wide::fromSigned(INT16_MIN), Wide::fromSigned(INT16_MAX)};
    case IntType::Int32:
        return {Wide::fromSigned(INT32_MIN), Wide::fromSigned(INT32_MAX)};
    case IntType::Int64:
        return {Wide::fromSigned(INT64_MIN), Wide::fromSigned(INT64_MAX)};
    case IntType::UInt8:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT8_MAX)};
    case IntType::UInt16:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT16_MAX)};
    case IntType::UInt32:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT32_MAX)};
    case IntType::UInt64:
        return {Wide::fromUnsigned(0), Wide::fromUnsigned(UINT64_MAX)};
    case IntType::None:
        break;
    }
    return {Wide(), Wide()};
}

bool isUnsignedType(IntType t) { return static_cast<uint8_t>(t) >= static_cast<uint8_t>(IntType::UInt8); }

// A double in error messages: 300, 5.7, 1e+30 (not 300.000000).
std::string numberText(double x)
{
    char buf[32];
    std::snprintf(buf, sizeof buf, "%.15g", x);
    return buf;
}

Wide wideOf(const Value &v)
{
    return v.intIsUnsigned() ? Wide::fromUnsigned(static_cast<uint64_t>(v.intBits()))
                             : Wide::fromSigned(v.intBits());
}

// `w` must already be inside the type's range.
Value makeInt(IntType t, const Wide &w)
{
    if (isUnsignedType(t))
        return Value::integerUnsigned(t, w.mag);
    // In range for a signed type: magnitude <= 2^63, so this is exact
    // (2^63 only when negative, giving INT64_MIN).
    const int64_t v = w.neg ? static_cast<int64_t>(0 - w.mag) : static_cast<int64_t>(w.mag);
    return Value::integerSigned(t, v);
}

void copyUnit(const Value &from, Value &to)
{
    to.dimL = from.dimL;
    to.dimT = from.dimT;
    to.dimM = from.dimM;
}

std::string rangeText(IntType t)
{
    Range r = rangeOf(t);
    return r.lo.toString() + ".." + r.hi.toString();
}

std::string overflowText(IntType t, const std::string &what)
{
    return std::string(intTypeName(t)) + " overflow: " + what + " is outside " + rangeText(t);
}

// Range-checks `w` for type `t`; on failure fills `err` with
// "<type> overflow: <what> = <w> is outside lo..hi".
bool fitsOrError(IntType t, const Wide &w, const std::string &what, std::string &err)
{
    Range r = rangeOf(t);
    if (compare(w, r.lo) >= 0 && compare(w, r.hi) <= 0)
        return true;
    err = overflowText(t, what + " = " + w.toString());
    return false;
}

// Exact parse of optional sign + decimal digits. False for anything else, or
// for a magnitude past 2^64 - 1 (out of every range; reported by the caller
// through the float path).
bool parseIntegerText(const std::string &raw, Wide &out)
{
    size_t b = 0, e = raw.size();
    while (b < e && std::isspace(static_cast<unsigned char>(raw[b])))
        b++;
    while (e > b && std::isspace(static_cast<unsigned char>(raw[e - 1])))
        e--;
    if (b == e)
        return false;
    bool neg = false;
    if (raw[b] == '+' || raw[b] == '-') {
        neg = raw[b] == '-';
        b++;
    }
    if (b == e)
        return false;
    uint64_t mag = 0;
    const uint64_t max = std::numeric_limits<uint64_t>::max();
    for (size_t i = b; i < e; i++) {
        if (!std::isdigit(static_cast<unsigned char>(raw[i])))
            return false;
        const uint64_t digit = static_cast<uint64_t>(raw[i] - '0');
        if (mag > (max - digit) / 10)
            return false;
        mag = mag * 10 + digit;
    }
    out = Wide::make(neg, mag);
    return true;
}

bool castScalar(const Value &v, IntType t, Value &out, std::string &err)
{
    const std::string name = intTypeName(t);
    Wide w;

    if (v.isInt()) {
        w = wideOf(v);
        if (!fitsOrError(t, w, name + "(" + v.intText() + ")", err))
            return false;
    } else if (v.isBool()) {
        w = Wide::fromUnsigned(v.number != 0.0 ? 1 : 0);
    } else if (v.isComplex) {
        err = "cannot convert a complex number to " + name + " (use real() or abs() first)";
        return false;
    } else if (v.isText) {
        if (!parseIntegerText(v.text(), w)) {
            double d;
            if (!tryCoerceTextToNumber(v, d)) {
                err = name + "() could not parse '" + v.text() + "' as a number";
                return false;
            }
            return castScalar(Value(d), t, out, err);
        }
        if (!fitsOrError(t, w, name + "(\"" + v.text() + "\")", err))
            return false;
    } else if (v.isDict || v.isObject || v.isFunctionRef) {
        err = name + "() expects a number, text, or an array/matrix of numbers";
        return false;
    } else {
        const double x = v.number;
        if (std::isnan(x) || std::isinf(x)) {
            err = "cannot convert " + std::string(std::isnan(x) ? "NaN" : "Inf") + " to " + name;
            return false;
        }
        const double tx = std::trunc(x);
        const double mag = std::fabs(tx);
        // 2^64: the first magnitude a uint64 cannot hold (and so no type can).
        if (mag >= 18446744073709551616.0) {
            err = overflowText(t, name + "(" + numberText(x) + ")");
            return false;
        }
        w = Wide::make(tx < 0, static_cast<uint64_t>(mag));
        if (!fitsOrError(t, w, name + "(" + numberText(x) + ")", err))
            return false;
    }

    out = makeInt(t, w);
    copyUnit(v, out);
    return true;
}

// x ^ y for y >= 0, by repeated squaring; false when the result leaves the
// type's range (each step is checked, so nothing ever overflows silently).
bool powerWide(IntType t, const Wide &x, uint64_t y, Wide &out)
{
    const Range r = rangeOf(t);
    auto inRange = [&](const Wide &w) { return compare(w, r.lo) >= 0 && compare(w, r.hi) <= 0; };
    Wide result = Wide::fromUnsigned(1);
    Wide base = x;
    while (y > 0) {
        if (y & 1u) {
            if (!mulWide(result, base, result) || !inRange(result))
                return false;
        }
        y >>= 1;
        if (y > 0) {
            // base is needed again (a later bit is set), so it must stay
            // representable; once |base| > 2^32 its square no longer fits.
            if (!mulWide(base, base, base))
                return false;
        }
    }
    out = result;
    return true;
}

} // namespace

const char *intTypeName(IntType t)
{
    switch (t) {
    case IntType::Int8:
        return "int8";
    case IntType::Int16:
        return "int16";
    case IntType::Int32:
        return "int32";
    case IntType::Int64:
        return "int64";
    case IntType::UInt8:
        return "uint8";
    case IntType::UInt16:
        return "uint16";
    case IntType::UInt32:
        return "uint32";
    case IntType::UInt64:
        return "uint64";
    case IntType::None:
        break;
    }
    return "float64";
}

bool intTypeFromName(const std::string &name, IntType &out)
{
    static const struct
    {
        const char *name;
        IntType type;
    } table[] = {{"int8", IntType::Int8},     {"int16", IntType::Int16},
                 {"int32", IntType::Int32},   {"int64", IntType::Int64},
                 {"uint8", IntType::UInt8},   {"uint16", IntType::UInt16},
                 {"uint32", IntType::UInt32}, {"uint64", IntType::UInt64}};
    for (const auto &entry : table)
        if (name == entry.name) {
            out = entry.type;
            return true;
        }
    return false;
}

bool isReservedWideIntName(const std::string &name)
{
    return name == "int128" || name == "int256" || name == "uint128" || name == "uint256";
}

IntOpResult integerBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                            std::string &err)
{
    // Only integer-with-integer is computed here; anything else involving
    // an integer is float64 math done by the caller.
    if (!a.isInt() || !b.isInt())
        return IntOpResult::NotApplicable;
    if (op != "+" && op != "-" && op != "*" && op != "/" && op != "//" && op != "%" && op != "^")
        return IntOpResult::NotApplicable;

    const IntType t = a.intType();
    if (b.intType() != t) {
        err = std::string("cannot combine ") + intTypeName(t) + " and " +
              intTypeName(b.intType()) + " in '" + op + "' - convert one side first, e.g. " +
              intTypeName(t) + "(x)";
        return IntOpResult::Error;
    }

    const Wide x = wideOf(a), y = wideOf(b);
    const std::string expr = a.intText() + " " + op + " " + b.intText();
    Wide w;

    if (op == "/") {
        // True division is float64 (5/2 is 2.5), the same as for floats.
        out = Value(x.toDouble() / y.toDouble());
        out.dimL = a.dimL - b.dimL;
        out.dimT = a.dimT - b.dimT;
        out.dimM = a.dimM - b.dimM;
        return IntOpResult::Ok;
    }

    if (op == "^") {
        if (y.neg) {
            // A negative power is a fraction: float64, as for 5/2.
            out = Value(std::pow(x.toDouble(), y.toDouble()));
            return IntOpResult::Ok;
        }
        if (!powerWide(t, x, y.mag, w)) {
            err = overflowText(t, expr);
            return IntOpResult::Error;
        }
        out = makeInt(t, w);
        const int p = static_cast<int>(y.mag > 1000 ? 1000 : y.mag);
        out.dimL = static_cast<int16_t>(a.dimL * p);
        out.dimT = static_cast<int16_t>(a.dimT * p);
        out.dimM = static_cast<int16_t>(a.dimM * p);
        return IntOpResult::Ok;
    }

    bool exact = true;
    if (op == "+") {
        exact = addWide(x, y, w);
    } else if (op == "-") {
        exact = subWide(x, y, w);
    } else if (op == "*") {
        exact = mulWide(x, y, w);
    } else { // "//" or "%"
        if (y.mag == 0) {
            err = std::string("integer division by zero in '") + op + "' (" + expr + ")";
            return IntOpResult::Error;
        }
        Wide q, r;
        divModWide(x, y, q, r);
        if (op == "%") {
            // Truncated remainder: same sign as the dividend, the same rule
            // fmod() gives float64 values.
            w = r;
        } else {
            // Truncated division (toward zero), the same rule `//` uses for
            // float64: 7 // -2 is -3, and a == (a // b) * b + a % b.
            w = q;
        }
    }

    if (!exact) {
        err = overflowText(t, expr);
        return IntOpResult::Error;
    }
    if (!fitsOrError(t, w, expr, err))
        return IntOpResult::Error;

    out = makeInt(t, w);
    if (op == "*") {
        out.dimL = a.dimL + b.dimL;
        out.dimT = a.dimT + b.dimT;
        out.dimM = a.dimM + b.dimM;
    } else if (op == "//") {
        out.dimL = a.dimL - b.dimL;
        out.dimT = a.dimT - b.dimT;
        out.dimM = a.dimM - b.dimM;
    } else {
        copyUnit(a, out);
    }
    return IntOpResult::Ok;
}

bool integerNegate(const Value &a, Value &out, std::string &err)
{
    const IntType t = a.intType();
    const Wide w = wideOf(a).negated();
    if (!fitsOrError(t, w, "-(" + a.intText() + ")", err))
        return false;
    out = makeInt(t, w);
    copyUnit(a, out);
    return true;
}

bool castToInteger(const Value &v, IntType t, Value &out, std::string &err)
{
    if (v.isArray) {
        std::vector<Value> cells;
        cells.reserve(v.length());
        for (size_t i = 0; i < v.length(); i++) {
            Value cell;
            if (!castToInteger(v.at(i), t, cell, err))
                return false;
            cells.push_back(std::move(cell));
        }
        out = Value(std::move(cells));
        return true;
    }
    if (v.isMatrix) {
        std::vector<std::vector<Value>> rows;
        rows.reserve(v.rows());
        for (size_t r = 0; r < v.rows(); r++) {
            std::vector<Value> row;
            row.reserve(v.rowLength(r));
            for (size_t c = 0; c < v.rowLength(r); c++) {
                Value cell;
                if (!castToInteger(v.at(r, c), t, cell, err))
                    return false;
                row.push_back(std::move(cell));
            }
            rows.push_back(std::move(row));
        }
        out = Value(std::move(rows));
        return true;
    }
    return castScalar(v, t, out, err);
}

int compareIntegers(const Value &a, const Value &b) { return compare(wideOf(a), wideOf(b)); }
