#pragma once

// Fixed-width integer arithmetic (int8 ... int64, uint8 ... uint64).
//
// float64 is the language's default number. An integer only exists when a
// script asks for one - int(x) (int64), int8(x), uint16(x), ... - and the
// rules for using one are deliberately strict, so a result never silently
// changes meaning:
//
//   * int op int, same type  -> that type, exact. A result outside the
//     type's range is an error (no wrap-around, no saturation).
//   * int op int, different types (int8 + int32) -> an error, as in MATLAB.
//     Convert one side explicitly first.
//   * int op float64 (or bool) -> float64: the integer's value takes part
//     as a double.
//   * int / int -> float64 (5/2 is 2.5). `//` is the integer division,
//     truncated toward zero like C/C++/Java (7 // -2 is -3), and `%` the
//     matching remainder (sign of the dividend, 7 % -2 is 1); both reject a
//     zero divisor.
//   * int ^ negative int -> float64 (2^-1 is 0.5).
//
// int128 / int256 / uint128 / uint256 have reserved .ndat type tags but no
// runtime representation yet; asking for one is an error.

#include <string>

#include "../../core/value.h"

// Outcome of integerBinaryOp().
enum class IntOpResult
{
    NotApplicable, // neither side is an integer: use the float64 path
    Ok,            // `out` holds the result
    Error          // `err` holds the message (no trailing newline)
};

// The type's name as the language spells it ("int8", "uint64", ...).
const char *intTypeName(IntType t);

// "int8" -> IntType::Int8 etc. (lowercase names only). False for any other
// name, including the reserved-but-unsupported int128/int256/uint128/
// uint256.
bool intTypeFromName(const std::string &name, IntType &out);

// True for int128 / int256 / uint128 / uint256 (lowercase).
bool isReservedWideIntName(const std::string &name);

// Applies a binary operator ("+", "-", "*", "/", "//", "%", "^") when at
// least one side is an integer. Integer-with-float64 operands return
// NotApplicable: the caller then computes in float64 (see the rules above).
IntOpResult integerBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                            std::string &err);

// -a for an integer `a`. False (with `err`) when the result does not fit,
// e.g. -int8(-128) or any nonzero unsigned value.
bool integerNegate(const Value &a, Value &out, std::string &err);

// Converts `v` to integer type `t`: a number is truncated toward zero, a
// bool becomes 0/1, numeric text is parsed, and an array or matrix is
// converted element by element (the result holds integer cells). Errors:
// NaN/Inf, a value outside the type's range, complex numbers, dicts,
// objects and non-numeric text. The value's unit is kept.
bool castToInteger(const Value &v, IntType t, Value &out, std::string &err);

// Exact three-way comparison of two integers of any integer types.
int compareIntegers(const Value &a, const Value &b);
