// Sizes, text and collection helpers - see collections_builtin.h for the
// list. Added 2026-10 for the gaps the docs team found: no way to get the
// size of a matrix (size() took only a dict), no sort/append/remove, and no
// text functions at all.
#include "collections_builtin.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iostream>

#include "../../builtins/builtins.h"
#include "../../core/output.h"
#include "../matrix/matrix_index.h"

namespace {

Value fail(const std::string &msg) {
  std::cerr << "Error: " << msg << "\n";
  g_lastBuiltinFound = false;
  return Value(0);
}

bool isPlainNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
         !v.isFunctionRef && !v.isND() && !v.hasComplex();
}

// A whole number argument (an index, a count, a dimension).
bool wholeNumber(const Value &v, long long &out) {
  Value x = v;
  if (x.isMatrix && x.rows() == 1 && x.cols() == 1)
    x = x.at(0, 0);
  if (!isPlainNumber(x) || !std::isfinite(x.number) || x.number != std::floor(x.number))
    return false;
  out = static_cast<long long>(x.number);
  return true;
}

// Text split into characters (UTF-8 code points), so "π" counts as one.
std::vector<std::string> characters(const std::string &s) {
  std::vector<std::string> out;
  for (size_t i = 0; i < s.size();) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xE ? 3 : (c >> 3) == 0x1E ? 4 : 1;
    len = std::min(len, s.size() - i);
    out.push_back(s.substr(i, len));
    i += len;
  }
  return out;
}

// The elements of a vector: an array, or a 1xN / Nx1 matrix (an empty
// matrix has none). `column` / `wasArray` say how to give a result back in
// the same form (fromElements()).
struct VectorForm {
  bool column = false;
  bool wasArray = false;
};

bool vectorElements(const Value &v, std::vector<Value> &out, VectorForm &form) {
  if (v.isArray) {
    out = v.elems();
    form.wasArray = true;
    return true;
  }
  if (v.isMatrix && !v.isND()) {
    if (v.rows() == 0) {
      out.clear();
      return true;
    }
    if (matIsVectorShape(v)) {
      form.column = v.rows() > 1;
      out = matVectorAsArray(v).elems();
      return true;
    }
  }
  return false;
}

Value fromElements(std::vector<Value> elems, const VectorForm &form) {
  if (form.wasArray)
    return Value(std::move(elems));
  if (elems.empty())
    return Value(std::vector<std::vector<Value>>{});
  return matArrayAsMatrix(Value(std::move(elems)), form.column);
}

Value rowOf(std::vector<double> nums) {
  std::vector<Value> row;
  for (double d : nums)
    row.push_back(Value(d));
  return matArrayAsMatrix(Value(std::move(row)), false);
}

// The same dict-key spelling dict() uses (dc_builtin.cpp, dictKeyOf()).
bool dictKey(const Value &k, std::string &out) {
  if (k.isText) {
    out = k.text();
    return true;
  }
  if (!isPlainNumber(k))
    return false;
  out = formatNumber(k.number);
  return true;
}

// An index into n elements: 0..n-1, or -1..-n from the end.
bool resolveIndex(long long idx, size_t n, size_t &out) {
  const long long len = static_cast<long long>(n);
  if (idx < 0)
    idx += len;
  if (idx < 0 || idx >= len)
    return false;
  out = static_cast<size_t>(idx);
  return true;
}

std::string indexRangeText(size_t n) {
  if (n == 0)
    return "it is empty";
  return "valid indexes are 0.." + std::to_string(n - 1) + " (or -1..-" + std::to_string(n) +
         " from the end)";
}

const std::string &textArg(const std::vector<Value> &a, size_t i) { return a[i].text(); }

bool allText(const std::vector<Value> &a, size_t from, size_t to) {
  for (size_t i = from; i < to && i < a.size(); i++)
    if (!a[i].isText)
      return false;
  return true;
}

/* ---- sizes ---- */

Value sizeOf(const std::vector<Value> &a) {
  if (a.empty() || a.size() > 2)
    return fail("size expects (value) or (value, dim), e.g. size(A) or size(A, 0)");
  const Value &v = a[0];
  if (v.isDict || v.isObject) {
    if (a.size() == 2)
      return fail("size(dict) takes no dim - it is the number of entries");
    return Value(static_cast<double>(v.dict().size()));
  }
  std::vector<double> dims;
  if (v.isND()) {
    for (size_t d : v.ndShape())
      dims.push_back(static_cast<double>(d));
  } else if (v.isMatrix) {
    dims = {static_cast<double>(v.rows()), static_cast<double>(v.rows() ? v.cols() : 0)};
  } else if (v.isArray) {
    dims = {1, static_cast<double>(v.length())};
  } else if (v.isText) {
    dims = {1, static_cast<double>(characters(v.text()).size())};
  } else {
    dims = {1, 1};
  }
  if (a.size() == 1)
    return rowOf(dims);
  long long dim = 0;
  if (!wholeNumber(a[1], dim))
    return fail("size's dim must be a whole number (0 = rows, 1 = columns)");
  if (dim < 0)
    dim += static_cast<long long>(dims.size());
  if (dim < 0 || dim >= static_cast<long long>(dims.size()))
    return fail("size's dim must be 0.." + std::to_string(dims.size() - 1) + " for a value of " +
                std::to_string(dims.size()) + " dimensions");
  return Value(dims[static_cast<size_t>(dim)]);
}

Value numelOf(const Value &v) {
  if (v.isDict || v.isObject)
    return Value(static_cast<double>(v.dict().size()));
  if (v.isText)
    return Value(static_cast<double>(characters(v.text()).size()));
  if (v.isND())
    return Value(static_cast<double>(v.ndCount()));
  if (v.isMatrix) {
    size_t n = 0;
    for (size_t r = 0; r < v.rows(); r++)
      n += v.rowLength(r);
    return Value(static_cast<double>(n));
  }
  if (v.isArray)
    return Value(static_cast<double>(v.length()));
  return Value(1.0);
}

Value lengthOf(const Value &v) {
  if (v.isMatrix && !v.isND() && v.rows() > 0)
    return Value(static_cast<double>(std::max(v.rows(), v.cols())));
  if (v.isND()) {
    size_t longest = 0;
    for (size_t d : v.ndShape())
      longest = std::max(longest, d);
    return Value(static_cast<double>(longest));
  }
  return numelOf(v);
}

/* ---- vectors ---- */

Value sortOf(const std::vector<Value> &a) {
  if (a.empty() || a.size() > 2)
    return fail("sort expects (vector) or (vector, \"descend\")");
  bool descend = false;
  if (a.size() == 2) {
    if (!a[1].isText || (a[1].text() != "descend" && a[1].text() != "ascend"))
      return fail("sort's second value must be \"ascend\" or \"descend\"");
    descend = a[1].text() == "descend";
  }
  std::vector<Value> elems;
  VectorForm form;
  if (!vectorElements(a[0], elems, form))
    return fail("sort works on a vector (one row or one column), not a " + matShapeText(a[0]) +
                " value - sort a row with sort(A[r,:])");
  const bool texts = !elems.empty() && elems[0].isText;
  for (const Value &e : elems) {
    if (texts ? !e.isText : !isPlainNumber(e))
      return fail("sort needs all numbers or all text - this vector mixes them (or holds "
                  "complex numbers)");
  }
  auto less = [texts](const Value &x, const Value &y) {
    return texts ? x.text() < y.text() : x.number < y.number;
  };
  if (descend)
    std::stable_sort(elems.begin(), elems.end(),
                     [&](const Value &x, const Value &y) { return less(y, x); });
  else
    std::stable_sort(elems.begin(), elems.end(), less);
  return fromElements(std::move(elems), form);
}

Value appendOf(const std::vector<Value> &a) {
  if (a.size() < 2)
    return fail("append expects (vector, value, ...), e.g. append(a, 4)");
  std::vector<Value> elems;
  VectorForm form;
  if (!vectorElements(a[0], elems, form)) {
    if (a[0].isDict || a[0].isObject || a[0].isMatrix)
      return fail("append works on a vector, not a " + matShapeText(a[0]) +
                  " value - add a dict entry with d[key] = value");
    elems = {a[0]}; // a single value starts a new vector
  }
  for (size_t i = 1; i < a.size(); i++) {
    std::vector<Value> more;
    VectorForm ignored;
    if (vectorElements(a[i], more, ignored))
      elems.insert(elems.end(), more.begin(), more.end());
    else if (a[i].isDict || a[i].isObject || a[i].isMatrix)
      return fail("append can add numbers, text or vectors - not a " + matShapeText(a[i]) +
                  " value");
    else
      elems.push_back(a[i]);
  }
  return fromElements(std::move(elems), form);
}

Value removeOf(const std::vector<Value> &a) {
  if (a.size() != 2)
    return fail("remove expects (dict, key) or (vector, index)");
  if (a[0].isDict) {
    std::string key;
    if (!dictKey(a[1], key))
      return fail("a dict key is a number or text");
    Value out = a[0];
    if (!out.dict().count(key))
      return fail("dict key '" + key + "' not found - nothing to remove");
    out.dictMut().erase(key);
    return out;
  }
  std::vector<Value> elems;
  VectorForm form;
  if (!vectorElements(a[0], elems, form))
    return fail("remove works on a dict or a vector, not a " + matShapeText(a[0]) + " value");
  long long idx = 0;
  size_t at = 0;
  if (!wholeNumber(a[1], idx))
    return fail("remove's index must be a whole number");
  if (!resolveIndex(idx, elems.size(), at))
    return fail("index " + std::to_string(idx) + " is out of range - " +
                indexRangeText(elems.size()));
  elems.erase(elems.begin() + static_cast<std::ptrdiff_t>(at));
  return fromElements(std::move(elems), form);
}

/* ---- text ---- */

Value changeCase(const std::vector<Value> &a, bool toUpper) {
  const char *fn = toUpper ? "upper" : "lower";
  if (a.size() != 1 || !a[0].isText)
    return fail(std::string(fn) + " expects one text value, e.g. " + fn + "(\"abc\")");
  std::string s = a[0].text();
  for (char &ch : s) {
    const unsigned char c = static_cast<unsigned char>(ch);
    if (c < 0x80)
      ch = static_cast<char>(toUpper ? std::toupper(c) : std::tolower(c));
  }
  return Value(s);
}

Value strcatOf(const std::vector<Value> &a) {
  std::string out;
  for (const Value &v : a)
    out += v.isText ? v.text() : valueToCompactString(v);
  return Value(out);
}

Value substrOf(const std::vector<Value> &a) {
  if ((a.size() != 2 && a.size() != 3) || !a[0].isText)
    return fail("substr expects (text, start) or (text, start, count), e.g. substr(\"hello\", 1, 3)");
  const std::vector<std::string> chars = characters(a[0].text());
  long long start = 0, count = 0;
  size_t from = 0;
  if (!wholeNumber(a[1], start))
    return fail("substr's start must be a whole number");
  if (chars.empty() && (start == 0 || start == -1) && a.size() == 2)
    return Value(std::string());
  if (!resolveIndex(start, chars.size(), from))
    return fail("start " + std::to_string(start) + " is out of range - the text has " +
                std::to_string(chars.size()) + " characters, " + indexRangeText(chars.size()));
  size_t n = chars.size() - from;
  if (a.size() == 3) {
    if (!wholeNumber(a[2], count) || count < 0)
      return fail("substr's count must be a whole number, 0 or more");
    if (static_cast<size_t>(count) > n)
      return fail("substr asks for " + std::to_string(count) + " characters from index " +
                  std::to_string(from) + ", but only " + std::to_string(n) + " are left");
    n = static_cast<size_t>(count);
  }
  std::string out;
  for (size_t i = from; i < from + n; i++)
    out += chars[i];
  return Value(out);
}

Value containsOf(const std::vector<Value> &a) {
  if (a.size() != 2 || !allText(a, 0, 2))
    return fail("contains expects two text values, e.g. contains(\"hello\", \"ell\")");
  return Value::boolean(textArg(a, 0).find(textArg(a, 1)) != std::string::npos);
}

Value replaceOf(const std::vector<Value> &a) {
  if (a.size() != 3 || !allText(a, 0, 3))
    return fail("replace expects three text values: (text, old, new)");
  const std::string &from = textArg(a, 1);
  if (from.empty())
    return fail("replace's old text must not be empty");
  std::string s = textArg(a, 0);
  const std::string &to = textArg(a, 2);
  for (size_t at = s.find(from); at != std::string::npos; at = s.find(from, at + to.size()))
    s.replace(at, from.size(), to);
  return Value(s);
}

Value splitOf(const std::vector<Value> &a) {
  if (a.size() != 2 || !allText(a, 0, 2))
    return fail("split expects two text values: (text, separator)");
  const std::string &s = textArg(a, 0);
  const std::string &sep = textArg(a, 1);
  if (sep.empty())
    return fail("split's separator must not be empty");
  std::vector<Value> pieces;
  size_t from = 0;
  for (size_t at = s.find(sep); at != std::string::npos; at = s.find(sep, from)) {
    pieces.push_back(Value(s.substr(from, at - from)));
    from = at + sep.size();
  }
  pieces.push_back(Value(s.substr(from)));
  return Value(std::move(pieces));
}

Value precisionOf(const std::vector<Value> &a) {
  if (a.empty())
    return Value(static_cast<double>(displayDecimals()));
  long long n = 0;
  if (a.size() != 1 || !wholeNumber(a[0], n) || n < 0 || n > 15)
    return fail("precision expects a whole number of decimals from 0 to 15, e.g. precision(10)");
  setDisplayDecimals(static_cast<int>(n));
  return Value(static_cast<double>(n));
}

} // namespace

Value collectionsBuiltin(const std::string &name, const std::vector<Value> &args) {
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

  auto one = [&](const char *fn) {
    if (args.size() == 1)
      return true;
    fail(std::string(fn) + " expects 1 value, got " + std::to_string(args.size()));
    return false;
  };

  if (key == "size") return sizeOf(args);
  if (key == "numel") return one("numel") ? numelOf(args[0]) : Value(0);
  if (key == "length") return one("length") ? lengthOf(args[0]) : Value(0);
  if (key == "sort") return sortOf(args);
  if (key == "append") return appendOf(args);
  if (key == "remove") return removeOf(args);
  if (key == "upper") return changeCase(args, true);
  if (key == "lower") return changeCase(args, false);
  if (key == "strcat") return strcatOf(args);
  if (key == "substr") return substrOf(args);
  if (key == "contains") return containsOf(args);
  if (key == "replace") return replaceOf(args);
  if (key == "split") return splitOf(args);
  if (key == "precision") return precisionOf(args);
  return fail("Unknown function '" + name + "'");
}
