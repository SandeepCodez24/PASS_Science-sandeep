#pragma once

#include <string>
#include <vector>

#include "../../core/value.h"

// Sizes, text and collection helpers (collections_builtin.cpp):
//
//   size(x[, dim])         [rows, cols] of a matrix (dim 0 = rows, 1 = cols);
//                          the number of entries of a dict
//   numel(x)               number of elements (entries of a dict, characters
//                          of text)
//   length(x)              characters of text, elements of a vector, the
//                          longer side of a matrix, entries of a dict
//   sort(v[, "descend"])   a vector of numbers or of text, sorted
//   append(v, x, ...)      v with the values added at the end
//   remove(c, k)           a dict without key k, or a vector without the
//                          element at index k
//   upper(s) / lower(s)    text in upper / lower case
//   strcat(a, b, ...)      the values joined as text (numbers written out)
//   substr(s, start[, n])  n characters from index start (to the end if no n)
//   contains(s, part)      true if part occurs in s
//   replace(s, old, new)   every old in s replaced by new
//   split(s, sep)          the pieces of s between each sep
//   precision([n])         decimals shown for numbers (0..15, default 6);
//                          with no value, the current setting
//
// Each reports a bad call with an "Error: ..." line and returns 0.
Value collectionsBuiltin(const std::string &name, const std::vector<Value> &args);
