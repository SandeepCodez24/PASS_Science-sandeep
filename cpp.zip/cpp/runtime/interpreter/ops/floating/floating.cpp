#include "floating.h"

#include <cfloat>
#include <cmath>
#include <cstring>

#include "../arithmetic/arithmetic.h" // tryCoerceTextToNumber

namespace {

// A binary floating-point format, described the way the rounding and the
// bit codec need it.
struct Format
{
    int precision;   // significand bits, the implicit leading 1 included
    int minExponent; // exponent of the smallest normal number
    double maxFinite;
    bool hasInfinity; // false: overflow and Inf map to NaN (float8 E4M3)
    int exponentBits;
    int mantissaBits; // stored fraction bits (precision - 1)
    int bias;
};

const Format &formatOf(FloatType t)
{
    // OCP 8-bit floating point (E4M3): max 1.75 * 2^8 = 448; the all-ones
    // exponent is still a normal binade, except S.1111.111, which is NaN.
    static const Format kFloat8 = {4, -6, 448.0, false, 4, 3, 7};
    static const Format kFloat16 = {11, -14, 65504.0, true, 5, 10, 15};
    static const Format kFloat32 = {24, -126, static_cast<double>(FLT_MAX), true, 8, 23, 127};
    switch (t) {
    case FloatType::Float8:
        return kFloat8;
    case FloatType::Float16:
        return kFloat16;
    default:
        return kFloat32;
    }
}

Value floatScalar(FloatType t, double x)
{
    return t == FloatType::Float64 ? Value(x) : Value::floating(t, roundToFloatType(t, x));
}

void copyUnit(const Value &from, Value &to)
{
    to.dimL = from.dimL;
    to.dimT = from.dimT;
    to.dimM = from.dimM;
}

bool castScalar(const Value &v, FloatType t, Value &out, std::string &err)
{
    const std::string name = floatTypeName(t);
    if (v.isComplex) {
        if (t == FloatType::Float64) {
            out = v; // a complex number already is two float64 parts
            out.dropScalarType();
            return true;
        }
        err = "cannot convert a complex number to " + name + " (use real() or abs() first)";
        return false;
    }
    if (v.isDict || v.isObject || v.isFunctionRef) {
        err = name + "() expects a number, text, or an array/matrix of numbers";
        return false;
    }
    double x = v.number;
    if (v.isText) {
        if (!tryCoerceTextToNumber(v, x)) {
            err = name + "() could not parse '" + v.text() + "' as a number";
            return false;
        }
    }
    out = floatScalar(t, x);
    if (!v.isText)
        copyUnit(v, out);
    return true;
}

int rank(FloatType t)
{
    switch (t) {
    case FloatType::Float8:
        return 1;
    case FloatType::Float16:
        return 2;
    case FloatType::Float32:
        return 3;
    default:
        return 4;
    }
}

bool isSingleNumber(const Value &v)
{
    return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef;
}

} // namespace

double roundToFloatType(FloatType t, double x)
{
    if (t == FloatType::Float64)
        return x;
    const Format &f = formatOf(t);
    if (std::isnan(x))
        return x;
    if (std::isinf(x))
        return f.hasInfinity ? x : std::nan("");
    if (x == 0.0)
        return x; // keeps the sign of zero
    // The spacing of representable values around x: one unit in the last
    // place of x's binade, or of the smallest normal binade for subnormals.
    int e = std::ilogb(x);
    if (e < f.minExponent)
        e = f.minExponent;
    const double quantum = std::ldexp(1.0, e - (f.precision - 1));
    // x / quantum is exact (a power-of-two scaling); nearbyint rounds to
    // nearest, ties to even, in the default rounding mode.
    const double r = std::nearbyint(x / quantum) * quantum;
    if (std::fabs(r) > f.maxFinite)
        return f.hasInfinity ? std::copysign(HUGE_VAL, x) : std::nan("");
    return r;
}

const char *floatTypeName(FloatType t)
{
    switch (t) {
    case FloatType::Float8:
        return "float8";
    case FloatType::Float16:
        return "float16";
    case FloatType::Float32:
        return "float32";
    case FloatType::Float64:
        break;
    }
    return "float64";
}

bool floatTypeFromName(const std::string &name, FloatType &out)
{
    if (name == "float8")
        out = FloatType::Float8;
    else if (name == "float16")
        out = FloatType::Float16;
    else if (name == "float32")
        out = FloatType::Float32;
    else if (name == "float64")
        out = FloatType::Float64;
    else
        return false;
    return true;
}

bool isReservedWideFloatName(const std::string &name)
{
    return name == "float128" || name == "float256";
}

bool castToFloat(const Value &v, FloatType t, Value &out, std::string &err)
{
    if (v.isArray) {
        std::vector<Value> cells;
        cells.reserve(v.length());
        for (size_t i = 0; i < v.length(); i++) {
            Value cell;
            if (!castToFloat(v.at(i), t, cell, err))
                return false;
            cells.push_back(std::move(cell));
        }
        out = Value(std::move(cells)); // float64 cells pack into a numeric array
        return true;
    }
    if (v.isMatrix) {
        std::vector<std::vector<Value>> rows;
        rows.reserve(v.rows());
        for (size_t r = 0; r < v.rows(); r++) {
            std::vector<Value> row;
            row.reserve(v.rowLength(r));
            for (size_t c = 0; c < v.rowLength(r); c++) {
                Value cell;
                if (!castToFloat(v.at(r, c), t, cell, err))
                    return false;
                row.push_back(std::move(cell));
            }
            rows.push_back(std::move(row));
        }
        out = Value(std::move(rows));
        return true;
    }
    return castScalar(v, t, out, err);
}

FloatType binaryResultFloatType(const Value &a, const Value &b)
{
    if (!isSingleNumber(a) || !isSingleNumber(b))
        return FloatType::Float64;
    const FloatType ta = a.floatType(), tb = b.floatType();
    if (ta == FloatType::Float64)
        return tb;
    if (tb == FloatType::Float64)
        return ta;
    return rank(ta) >= rank(tb) ? ta : tb; // the wider format
}

Value applyFloatType(const Value &result, FloatType t)
{
    if (t == FloatType::Float64 || !isSingleNumber(result) || result.isComplex)
        return result;
    Value out = Value::floating(t, roundToFloatType(t, result.number));
    copyUnit(result, out);
    return out;
}

uint32_t encodeFloatBits(FloatType t, double x)
{
    if (t == FloatType::Float32) {
        const float f = static_cast<float>(x);
        uint32_t bits;
        std::memcpy(&bits, &f, sizeof bits);
        return bits;
    }
    const Format &f = formatOf(t);
    const uint32_t sign = std::signbit(x) ? 1u : 0u;
    const uint32_t signBit = sign << (f.exponentBits + f.mantissaBits);
    const uint32_t expAllOnes = (1u << f.exponentBits) - 1u;
    const uint32_t mantAllOnes = (1u << f.mantissaBits) - 1u;
    if (std::isnan(x)) {
        // float16: quiet NaN; float8 E4M3: S.1111.111.
        return f.hasInfinity ? (signBit | (expAllOnes << f.mantissaBits) | (1u << (f.mantissaBits - 1)))
                             : (signBit | (expAllOnes << f.mantissaBits) | mantAllOnes);
    }
    if (std::isinf(x))
        return signBit | (expAllOnes << f.mantissaBits); // float16 only (float8 never holds Inf)
    const double a = std::fabs(x);
    if (a == 0.0)
        return signBit;
    const int e = std::ilogb(a);
    if (e < f.minExponent) {
        // Subnormal: exponent field 0, fraction = a / 2^(minExponent - mantissaBits).
        const uint32_t mant =
            static_cast<uint32_t>(std::ldexp(a, f.mantissaBits - f.minExponent));
        return signBit | mant;
    }
    const uint32_t exp = static_cast<uint32_t>(e + f.bias);
    const uint32_t mant =
        static_cast<uint32_t>((std::ldexp(a, -e) - 1.0) * std::ldexp(1.0, f.mantissaBits));
    return signBit | (exp << f.mantissaBits) | mant;
}

double decodeFloatBits(FloatType t, uint32_t bits)
{
    if (t == FloatType::Float32) {
        float f;
        std::memcpy(&f, &bits, sizeof f);
        return static_cast<double>(f);
    }
    if (t == FloatType::Float64)
        return 0.0; // not a narrow format; not used
    const Format &f = formatOf(t);
    const uint32_t mantAllOnes = (1u << f.mantissaBits) - 1u;
    const uint32_t expAllOnes = (1u << f.exponentBits) - 1u;
    const bool negative = (bits >> (f.exponentBits + f.mantissaBits)) & 1u;
    const uint32_t exp = (bits >> f.mantissaBits) & expAllOnes;
    const uint32_t mant = bits & mantAllOnes;
    double value;
    if (f.hasInfinity && exp == expAllOnes) {
        value = mant == 0 ? HUGE_VAL : std::nan("");
    } else if (!f.hasInfinity && exp == expAllOnes && mant == mantAllOnes) {
        value = std::nan("");
    } else if (exp == 0) {
        value = std::ldexp(static_cast<double>(mant), f.minExponent - f.mantissaBits);
    } else {
        value = std::ldexp(1.0 + std::ldexp(static_cast<double>(mant), -f.mantissaBits),
                           static_cast<int>(exp) - f.bias);
    }
    return negative ? -value : value;
}
