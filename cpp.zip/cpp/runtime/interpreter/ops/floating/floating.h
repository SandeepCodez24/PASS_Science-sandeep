#pragma once

// Floating-point storage formats: float8, float16, float32 and float64.
//
// float64 (IEEE binary64) is the language's default number and needs no
// declaration. The narrower formats are opt-in, like the integer types:
//
//     a = float32(0.1)      % nearest binary32 value to 0.1
//     h = float16(65519)    % 65504, the largest half value it rounds to
//     q = float8(3.3)       % 3.25 (FP8 E4M3)
//
// Rules (a typed float keeps its format through arithmetic):
//   * Every operation is computed in double precision and the result is
//     rounded to the format (round to nearest, ties to even). For float32
//     and float16 that gives the same answer as computing in the format
//     itself, since double has more than twice their precision.
//   * floatN op float64 / integer / bool -> floatN. A plain number such as
//     the literal 2 does not widen a float32: float32(x) * 2 stays float32.
//   * Two different typed formats -> the wider one (float16 + float32 is
//     float32).
//   * A complex result, or an array/matrix operand, gives float64.
//   * Overflow follows IEEE: +/-Inf for float16/float32. float8 (E4M3) has
//     no infinity: overflow and Inf give NaN.
//
// float128 and float256 have reserved .ndat tags but no runtime support yet;
// asking for one is an error.

#include <cstdint>
#include <string>

#include "../../core/value.h"

// "float8", "float16", "float32", "float64".
const char *floatTypeName(FloatType t);

// "float32" -> FloatType::Float32 etc. (lowercase). False for anything else,
// including the reserved float128 / float256.
bool floatTypeFromName(const std::string &name, FloatType &out);

// True for "float128" / "float256".
bool isReservedWideFloatName(const std::string &name);

// float8(x) ... float64(x): a number is rounded to the format, numeric text
// is parsed, a bool becomes 0/1, an integer its value, and an array or
// matrix is converted element by element (float64 gives an ordinary numeric
// array; the narrower formats give one of typed cells). Errors: dicts,
// objects, non-numeric text, and complex numbers for float8/16/32. The
// unit is kept.
bool castToFloat(const Value &v, FloatType t, Value &out, std::string &err);

// The format a binary operation on `a` and `b` produces under the rules
// above: Float64 unless at least one side is a typed float8/16/32 and both
// sides are single numbers.
FloatType binaryResultFloatType(const Value &a, const Value &b);

// Rounds a real, single-number result to `t` and tags it; anything else
// (complex, array, text, ...) is returned unchanged. Float64 is a no-op.
Value applyFloatType(const Value &result, FloatType t);

// The format's bit pattern of an exactly representable value (as written
// to .ndat): 8 bits for float8, 16 for float16, 32 for float32.
uint32_t encodeFloatBits(FloatType t, double x);

// The value of a bit pattern of format `t`.
double decodeFloatBits(FloatType t, uint32_t bits);
