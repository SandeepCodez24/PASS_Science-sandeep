#pragma once
// runtime/interpreter/ops/matrix/nd_array.h
//
// Small shape helpers shared by everything that handles N-dimensional
// matrices: the matrix code (matrix.cpp), the display (output.cpp), the
// parser's evaluator and the .ndat / JSON writers. Header-only, so adding it
// needs no build-file change.
//
// Everything in NC is a matrix. Seen as a matrix:
//   a single value      shape [1, 1]
//   a 1-D array         shape [1, n]   (a row, as everywhere else)
//   a 2-D matrix        shape [rows, cols]
//   an N-D matrix       shape [d0, ..., d(n-3), rows, cols]
//
// A multi-index lists one position per axis, first axis first. "Row-major
// order" (used for reshape(), for pairing up elements of two values, and in
// the JSON sent to the IDE) runs the LAST index fastest. "Storage order" is
// how the elements sit in memory - see NumTensor in core/value.h: 2-D pages,
// column-major inside a page, pages in row-major order of the leading axes.

#include <complex>
#include <cstddef>
#include <string>
#include <vector>

#include "../../core/value.h"

namespace nd {

using Shape = std::vector<size_t>;

// Shape of any value seen as a matrix (see the table above).
inline Shape shapeOf(const Value &v) {
  if (v.isND())
    return v.ndShape();
  if (v.isMatrix)
    return {v.rows(), v.rows() ? v.cols() : 0};
  if (v.isArray)
    return {1, v.length()};
  return {1, 1};
}

inline size_t countOf(const Shape &s) {
  size_t n = 1;
  for (size_t d : s)
    n *= d;
  return n;
}

// "2x3x4"
inline std::string shapeText(const Shape &s) {
  std::string out;
  for (size_t i = 0; i < s.size(); i++) {
    if (i)
      out += "x";
    out += std::to_string(s[i]);
  }
  return out;
}

// `s` with 1s put in front until it has `rank` axes ([2,3] -> [1,2,3]).
// Prepending 1s never changes the storage order of the elements.
inline Shape withRank(const Shape &s, size_t rank) {
  if (s.size() >= rank)
    return s;
  Shape out(rank - s.size(), 1);
  out.insert(out.end(), s.begin(), s.end());
  return out;
}

// Storage index of multi-index `idx` in a matrix of shape `s` (rank >= 2).
inline size_t storageIndex(const Shape &s, const std::vector<size_t> &idx) {
  const size_t n = s.size();
  const size_t R = s[n - 2], C = s[n - 1];
  size_t page = 0;
  for (size_t i = 0; i + 2 < n; i++)
    page = page * s[i] + idx[i];
  return page * R * C + idx[n - 1] * R + idx[n - 2];
}

// Steps a multi-index through `s` in row-major order (last index fastest).
// Returns false once every position has been visited.
inline bool nextIndex(std::vector<size_t> &idx, const Shape &s) {
  for (size_t i = s.size(); i-- > 0;) {
    if (++idx[i] < s[i])
      return true;
    idx[i] = 0;
  }
  return false;
}

// The element of `v` at multi-index `idx`. `idx` may have MORE axes than
// v's own shape (leading 1s from withRank()); only the last ones are used.
inline Value elementAt(const Value &v, const std::vector<size_t> &idx) {
  const Shape own = shapeOf(v);
  const size_t skip = idx.size() - own.size();
  if (v.isND()) {
    std::vector<size_t> tail(idx.begin() + static_cast<std::ptrdiff_t>(skip), idx.end());
    return v.ndAt(storageIndex(own, tail));
  }
  const size_t r = idx[skip], c = idx[skip + 1];
  if (v.isMatrix)
    return v.at(r, c);
  if (v.isArray)
    return v.at(c);
  return v;
}

// Every element of `v` in storage order of shapeOf(v) (column-major for a
// 2-D matrix).
inline std::vector<Value> storageCells(const Value &v) {
  std::vector<Value> cells;
  if (v.isND()) {
    const size_t n = v.ndCount();
    cells.reserve(n);
    for (size_t k = 0; k < n; k++)
      cells.push_back(v.ndAt(k));
    return cells;
  }
  const Shape s = shapeOf(v);
  cells.reserve(s[0] * s[1]);
  for (size_t c = 0; c < s[1]; c++)
    for (size_t r = 0; r < s[0]; r++)
      cells.push_back(elementAt(v, {r, c}));
  return cells;
}

// Every element of `v` in row-major order of shapeOf(v).
inline std::vector<Value> rowMajorCells(const Value &v) {
  const Shape s = shapeOf(v);
  std::vector<Value> cells;
  const size_t n = countOf(s);
  cells.reserve(n);
  if (n == 0)
    return cells;
  std::vector<size_t> idx(s.size(), 0);
  do {
    cells.push_back(elementAt(v, idx));
  } while (nextIndex(idx, s));
  return cells;
}

// A matrix of `shape` from `cells` in storage order: an ordinary 2-D matrix
// for rank 2, an N-D matrix for rank >= 3. A shape with a zero in it gives
// the empty 0x0 matrix. A rank-1 shape [n] is taken as the row [1, n].
inline Value build(Shape shape, std::vector<Value> cells) {
  if (shape.size() < 2)
    shape = withRank(shape, 2);
  if (countOf(shape) == 0)
    return Value(std::vector<std::vector<Value>>{});
  if (shape.size() >= 3)
    return Value::ndFromCells(std::move(shape), std::move(cells));
  const size_t R = shape[0], C = shape[1];
  std::vector<std::vector<Value>> grid(R, std::vector<Value>(C));
  for (size_t c = 0; c < C; c++)
    for (size_t r = 0; r < R; r++)
      grid[r][c] = std::move(cells[c * R + r]);
  return Value(std::move(grid));
}

// A matrix of `shape` from `cells` in row-major order.
inline Value buildRowMajor(const Shape &shape0, const std::vector<Value> &cells) {
  Shape shape = shape0.size() < 2 ? withRank(shape0, 2) : shape0;
  const size_t n = countOf(shape);
  if (n == 0)
    return Value(std::vector<std::vector<Value>>{});
  std::vector<Value> stored(n);
  std::vector<size_t> idx(shape.size(), 0);
  size_t t = 0;
  do {
    stored[storageIndex(shape, idx)] = cells[t++];
  } while (nextIndex(idx, shape));
  return build(std::move(shape), std::move(stored));
}

// Page `p` (0-based, in storage order) of an N-D matrix as a 2-D matrix.
inline Value page(const Value &v, size_t p) {
  const Shape &s = v.ndShape();
  const size_t R = s[s.size() - 2], C = s[s.size() - 1];
  std::vector<std::vector<Value>> grid(R, std::vector<Value>(C));
  for (size_t c = 0; c < C; c++)
    for (size_t r = 0; r < R; r++)
      grid[r][c] = v.ndAt(p * R * C + c * R + r);
  return Value(std::move(grid));
}

// The leading indices (all axes but the last two) of page `p`.
inline std::vector<size_t> pageIndex(const Shape &s, size_t p) {
  std::vector<size_t> lead(s.size() - 2, 0);
  for (size_t i = lead.size(); i-- > 0;) {
    lead[i] = p % s[i];
    p /= s[i];
  }
  return lead;
}

} // namespace nd
