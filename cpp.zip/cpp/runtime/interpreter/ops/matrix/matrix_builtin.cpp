#include "matrix_builtin.h"
#include "matrix.h"
#include "matrix_index.h"
#include "nd_array.h"
#include "../../builtins/builtins.h"

#include <algorithm>
#include <cctype>
#include <functional>
#include <iostream>
#include <unordered_map>

Value matrixBuiltin(const std::string &name, const std::vector<Value> &args) {

  using Fn = std::function<Value(const std::vector<Value> &)>;

  // Takes `a` explicitly rather than capturing the enclosing `args` by
  // reference: this lambda's caller-lambdas below all live inside a
  // `static const table` built once on the first call to this function and
  // reused (dangling references and all) on every later call - a [&]
  // capture here would silently read whatever used to be on the first
  // call's stack frame, not the current call's actual arguments.
  auto require_arity = [](const std::vector<Value> &a, const std::string &fn,
                           size_t needed) -> bool {
    if (a.size() != needed) {
      std::cerr << "Error: Function '" << fn << "' expects " << needed
                << " args, got " << a.size() << "\n";
      return false;
    }
    return true;
  };

  static const std::unordered_map<std::string, Fn> table = {

      /* ================= BASIC MATRIX OPS ================= */

      {"rank",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "rank", 1))
           return Value();
         return rank(a[0]);
       }},

      {"transpose",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "transpose", 1))
           return Value();
         return MatrixTranspose(a[0]);
       }},

      // Moore-Penrose pseudo-inverse, under its short and its long name.
      // The conjugate is conj(A) / conjugate(A) (ops/complex).
      {"pinv",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "pinv", 1))
           return Value();
         return pseudo_inverse(a[0]);
       }},

      {"pseudo_inverse",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "pseudo_inverse", 1))
           return Value();
         return pseudo_inverse(a[0]);
       }},

      {"det",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "det", 1))
           return Value();
         return det(a[0]);
       }},

      {"adj",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "adj", 1))
           return Value();
         return adj(a[0]);
       }},

      {"had_prod",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "had_prod", 2))
           return Value();
         return had_prod(a[0], a[1]);
       }},

      {"inv",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "inv", 1))
           return Value();
         return inv(a[0]);
       }},

      // matrix_norm(A) is the Frobenius norm; matrix_norm(A, ord) also
      // takes "fro", "nuc", 1, -1, 2, -2, inf, -inf (np.linalg.matrix_norm).
      {"matrix_norm",
       [](const std::vector<Value> &a) -> Value {
         if (a.size() == 1)
           return Norm(a[0]);
         if (a.size() == 2)
           return MatrixNormOrd(a[0], a[1]);
         std::cerr << "Error: Function 'matrix_norm' expects 1 or 2 args, got " << a.size()
                   << "\n";
         return Value();
       }},

      // "element_wise" removed 2026-10: the operator A*.B replaces it.
      {"trace",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "trace", 1))
           return Value();
         return Trace(a[0]);
       }},

      // Keys lowercased 2026-09-16 (was "onlyRows"/"onlyCols"): this
      // table is looked up with the exact, non-lowercased name the
      // caller typed (see the outer builtins.cpp table's normalization,
      // which only fixes ITS OWN lookup, not this one) - a mixed-case
      // key here meant "onlyrows"/"ONLYROWS"/etc. all failed to resolve.
      {"onlyrows",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "onlyrows", 1))
           return Value();
         return OnlyRows(a[0]);
       }},
      {"onlycols",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "onlycols", 1))
           return Value();
         return OnlyCols(a[0]);
       }},

      /* ================= SPECIAL MATRICES ================= */

      {"diag",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "diag", 1))
           return Value();
         return diag(a[0]);
       }},

      {"upper_triangular",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "upper_triangular", 1))
           return Value();
         return upper_triangular(a[0]);
       }},

      {"lower_triangular",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "lower_triangular", 1))
           return Value();
         return Lower_Triangular(a[0]);
       }},

      // zero_matrix(n): n x n; zero_matrix(m, n): m x n (it used to take
      // only one size); zero_matrix(A): the size of A.
      {"zero_matrix",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (a.size() == 2)
           return zeros(a);
         if (!require_arity(a, "zero_matrix", 1))
           return Value();
         return zero_matrix(a[0]);
       }},

      {"full_rank_matrix",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "full_rank_matrix", 1))
           return Value();
         return full_rank_matrix(a[0]);
       }},

      {"singular_matrix",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "singular_matrix", 1))
           return Value();
         return singular_matrix(a[0]);
       }},

      {"pd_matrix",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "pd_matrix", 1))
           return Value();
         return pd_matrix(a[0]);
       }},

      {"nd_matrix",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "nd_matrix", 1))
           return Value();
         return nd_matrix(a[0]);
       }},

      // zeros(m) / zeros([m,n]) and ones(m) / ones([m,n]) - see matrix.h.
      {"zeros", [](const std::vector<Value> &a) -> Value { return zeros(a); }},
      {"ones", [](const std::vector<Value> &a) -> Value { return ones(a); }},

      {"unit_matrix",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "unit_matrix", 1))
           return Value();
         return unit_matrix(a[0]);
       }},

      /* ================= SHAPE (N-D matrices too) ================= */

      // reshape(A, [d0, d1, ...]) - same elements, new shape, in row-major
      // order (last index fastest, as in NumPy); one size may be -1.
      {"reshape",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "reshape", 2))
           return Value();
         Value out;
         std::string err;
         if (!ndReshape(a[0], a[1], out, err)) {
           std::cerr << "Error: " << err << "\n";
           g_lastBuiltinFound = false; // stop the statement
           return Value(0);
         }
         return out;
       }},

      // shape(A) - the size of every axis as a row: [2,3,4]; a single
      // value is [1,1].
      {"shape",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "shape", 1))
           return Value();
         return ndShapeValue(a[0]);
       }},

      // ndims(A) - the number of axes: 2 for a matrix or a single value,
      // 3 or more for an N-D matrix.
      {"ndims",
       [require_arity](const std::vector<Value> &a) -> Value {
         if (!require_arity(a, "ndims", 1))
           return Value();
         return Value(static_cast<double>(nd::shapeOf(a[0]).size()));
       }},
  };

  // Lowercase before lookup (fixed 2026-09-16): this table used to be
  // looked up with the exact, non-lowercased name the caller typed - the
  // outer builtins.cpp table normalizes its OWN lookup, but that doesn't
  // help here, since it just calls matrixBuiltin(name, args) with the
  // original name once it's found which handler to dispatch to. Without
  // this, any casing other than a table key's exact spelling (e.g.
  // "onlyrows" when the key was "onlyRows") failed with "Unknown matrix
  // function", contradicting the documented case-insensitive dispatch.
  std::string key = name;
  std::transform(key.begin(), key.end(), key.begin(),
                 [](unsigned char c) { return std::tolower(c); });

  // The nexus random-matrix family (nexus, nexus_float, nexus_UTM_normal, ...,
  // nexus_seed) - one entry point that reads the kind and shape from the name.
  if (key.rfind("nexus", 0) == 0)
    return nexus(key, args);

  auto it = table.find(key);
  if (it == table.end()) {
    std::cerr << "Error: Unknown matrix function '" << name << "'\n";
    return Value();
  }

  return it->second(args);
}