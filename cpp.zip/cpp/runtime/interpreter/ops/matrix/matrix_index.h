#pragma once
// runtime/interpreter/ops/matrix/matrix_index.h
//
// The one implementation of matrix indexing, slicing, slice assignment and
// matrix-literal building. Shared by the tree-walker (parser_factor.cpp,
// parser_exec_stmt.cpp) and the JIT bridge (value_bridge.cpp), so both
// paths give identical results and identical error messages.
//
// Indexing rules (0-based, MATLAB-like shapes):
//   A[m,n]            one element
//   A[m,:]  A[m,]  A[m]   row m            (1 x cols matrix)
//   A[:,n]  A[,n]         column n         (rows x 1 matrix)
//   A[a:b, c:d]       rows a..b, columns c..d - the stop is INCLUDED
//   A[a:s:b]          start:step:stop, e.g. A[0:2:8]
//   A[5:, :3]         an open end runs to the first/last index
//   A[-1]             negative indices count from the end (-1 = last)
//   A[::]  A[:]  A[:,:]   the whole matrix (a copy)
//   For a vector (1 x N or N x 1), one index picks ELEMENTS: v[2], v[1:3].
//
// Assignment uses the same selections. The right-hand side may be a single
// value (written into every selected cell), a matrix of exactly the
// selection's size, or - for a selection that is one row or one column - any
// vector with the right number of elements. Writing past the end grows the
// matrix (new cells are 0), and assigning by index to an undefined name
// creates the matrix, as in MATLAB.

#include <string>
#include <vector>

#include "../../core/value.h"

struct MatIndexKey {
  enum Kind { All, Scalar, Range };
  Kind kind = All;
  double scalar = 0.0; // Scalar
  // Range: any of the three parts may be left out (open end / step 1).
  bool hasStart = false, hasStep = false, hasStop = false;
  double start = 0.0, step = 1.0, stop = 0.0;
};

// True for a 1 x N or N x 1 matrix (including 1 x 1).
bool matIsVectorShape(const Value &v);

// A[keys] on a matrix or an array. `name` is used only in error messages.
// False (with `err` filled, no "Error:" prefix) on any problem.
bool matIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                 Value &out, std::string &err);

// A[keys] = rhs. `target` is the variable's current value when `exists`,
// ignored otherwise (an undefined name becomes a new matrix). On success
// `target` holds the updated value.
bool matIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                 const Value &rhs, const std::string &name, std::string &err);

// Builds the value of a matrix literal from its rows of already-evaluated
// cells: [1,2;3,4]. A cell that is itself a matrix (or an array, taken as a
// row) concatenates - [A, B] side by side, [A; B] stacked; empty matrices
// are skipped, as in MATLAB.
bool matBuildFromCells(const std::vector<std::vector<Value>> &rows, Value &out, std::string &err);

// Matrix transpose of any value: a number stays itself, an array becomes a
// column, a matrix of any cell kind (numbers, complex, text) is flipped.
Value matTransposeValue(const Value &v);

// Elements of a vector-shaped matrix (or an array) as a flat array; any
// other value is returned unchanged.
Value matVectorAsArray(const Value &v);

// An array as a matrix: a 1 x N row, or N x 1 when `asColumn`.
Value matArrayAsMatrix(const Value &v, bool asColumn);

// "2x3" (or "2x3x4" for an N-D matrix) - for error messages.
std::string matShapeText(const Value &v);

/* ---- Type rules (see the comment above matUnifyCells() in matrix.cpp) ----
   A matrix holds one type of element. Converts `cells` - every element of
   one matrix - to their common type: any text makes all text (numbers in
   full round-trip precision), else complex, else float64, else the widest
   float8/16/32, else one integer type, else bool. False (with `err`) for a
   dict / object / function reference, or for numbers in different units. */
bool matUnifyCells(std::vector<Value> &cells, std::string &err);

/* ---- N-dimensional matrices ----
   Shape [d0, ..., rows, cols]; see core/value.h (Value::isND()) for the
   storage and ops/matrix/nd_array.h for the shape helpers.

   Literal syntax: ',' separates elements (last axis), ';' rows (axis -2),
   ';;' axis -3, ';;;' axis -4, and k semicolons axis -(k+1):
       [1,2;3,4 ;; 5,6;7,8]          2x2x2
       [1,2;3,4;;]                   1x2x2 (a trailing separator raises the rank)
   The same separators join matrices: [A ;; B] stacks A and B along axis -3. */

// Builds an N-D matrix literal. `rows[i]` holds the evaluated cells of
// row i; `levels[i]` is the separator written after row i (1 = ';',
// 2 = ';;', ...; 0 = none, the last row). Applies the type rules.
bool matBuildND(const std::vector<std::vector<Value>> &rows, const std::vector<int> &levels,
                Value &out, std::string &err);

// B[m] (one key: the slab m along the first axis, or several slabs for a
// range) and B[i,j,...,r,c] (one key per axis). A scalar key on a leading
// axis drops that axis from the result; rows and columns always stay, so
// B[0,:,:] of a 2x3x4 matrix is the 3x4 matrix.
bool ndIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                Value &out, std::string &err);

// B[keys] = rhs on an N-D matrix (no growth), or creating a new one with
// B[i,j,k] = v (shape (i+1)x(j+1)x(k+1), zeros of v's type). The right
// side is a single value or has the selection's shape (1s aside).
bool ndIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                const Value &rhs, const std::string &name, std::string &err);

// Element-wise arithmetic where at least one side is N-D: + - *. /. ^. %
// // between same-shape matrices or with a single value; '*' and '/' with a
// single value. The matrix product / power of N-D matrices is an error.
bool ndBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                std::string &err);

// -B for an N-D matrix.
bool ndNegate(const Value &a, Value &out, std::string &err);

// == != < > <= >= with an N-D side: against a single value, element by
// element (an N-D matrix of true/false); two same-size matrices give one
// true/false, as for 2-D matrices.
bool ndCompare(const std::string &op, const Value &a, const Value &b, Value &out,
               std::string &err);

// True for the builtins that understand N-D arguments (zeros, ones, the
// nexus family, reshape, shape, ndims, deal).
bool ndBuiltinAllowed(const std::string &name);

// False (with `err`) when an N-D argument is passed to a builtin that only
// understands 2-D matrices - called before every builtin call, so such a
// builtin can never misread an N-D matrix.
bool ndBuiltinGuard(const std::string &name, const std::vector<Value> &args, std::string &err);

// shape(A) - a row vector of A's sizes ([2,3,4]); a single value is [1,1].
Value ndShapeValue(const Value &v);

// reshape(A, [d0,...]) - same elements, new shape, in row-major order (the
// last index fastest, as in NumPy): reshape([1:6], [2,3]) is [1,2,3;4,5,6].
// One size may be -1 and is worked out.
bool ndReshape(const Value &v, const Value &shapeArg, Value &out, std::string &err);
