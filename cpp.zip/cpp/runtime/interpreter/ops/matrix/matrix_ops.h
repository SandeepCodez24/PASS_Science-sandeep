#pragma once
// runtime/interpreter/ops/matrix/matrix_ops.h
//
// The matrix-centred meaning of NC's arithmetic operators (2026-10):
//
//   A + B, A - B   same-size matrices, or a matrix and a single value
//   A * B          matrix product (columns of A = rows of B)
//   A / B          A * inv(B)  (B square and invertible)
//   A ^ n          matrix power: A square, n a whole number (A^-1 = inv(A));
//                  A^2.0 is accepted, A^2.3 is an error
//   A *. B         element-wise product
//   A /. B         element-wise quotient (2 /. A divides 2 by every element)
//   A ^. n         element-wise power (same as power(A, n))
//   s / A          an error - write s /. A (element-wise) or s * inv(A)
//
// matrixBinaryOp() is called by Parser::evaluateBinaryOpValues() (and so,
// through nc_bridge_binary_op_checked, by the JIT) whenever a matrix is one
// of the operands. It either computes the answer, reports an error, or
// validates the shapes and hands back to the existing arithmetic.cpp
// implementation (NotHandled) - so every shape mistake gets a clear message
// before any arithmetic runs.

#include <string>

#include "../../core/value.h"

enum class MatOpStatus { NotHandled, Ok, Error };

// `op` is the operator text: "+", "-", "*", "/", "^", "*.", "/.". ("^." is
// handled by the caller through power(A, n).) On Error, `err` holds the
// message without the "Error: " prefix.
MatOpStatus matrixBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                           std::string &err);

// True if every cell of a matrix is a number (real or complex) - text cells
// cannot take part in matrix arithmetic.
bool matrixIsNumeric(const Value &m);
