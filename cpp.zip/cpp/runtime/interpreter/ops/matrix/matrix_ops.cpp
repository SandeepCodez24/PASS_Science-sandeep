// runtime/interpreter/ops/matrix/matrix_ops.cpp - see matrix_ops.h.
#include "matrix_ops.h"

#include <Eigen/Dense>
#include <cmath>
#include <complex>
#include <cstdio>
#include <vector>

#include "../arithmetic/arithmetic.h"
#include "matrix.h"
#include "matrix_index.h"

using Eigen::MatrixXcd;
using Eigen::MatrixXd;

namespace {

std::string numText(double x) {
  char buf[40];
  std::snprintf(buf, sizeof buf, "%.15g", x);
  return buf;
}

// A single value that can take part in arithmetic with a matrix.
bool isScalarOperand(const Value &v) {
  return !v.isMatrix && !v.isArray && !v.isText && !v.isDict && !v.isObject && !v.isFunctionRef;
}

std::string kindText(const Value &v) {
  if (v.isMatrix || v.isArray)
    return "a " + matShapeText(v) + " matrix";
  if (v.isText)
    return "text";
  if (v.isDict)
    return "a dict";
  if (v.isObject)
    return "an object";
  if (v.isFunctionRef)
    return "a function reference";
  return "a number";
}

bool sameShape(const Value &a, const Value &b) {
  return a.rows() == b.rows() && (a.rows() == 0 || a.cols() == b.cols());
}

// Checks both operands of a matrix-with-something operation are numeric.
bool checkNumeric(const std::string &op, const Value &a, const Value &b, std::string &err) {
  for (const Value *v : {&a, &b}) {
    if (v->isMatrix) {
      if (!matrixIsNumeric(*v)) {
        err = "'" + op + "': a matrix containing text cannot be used in arithmetic";
        return false;
      }
    } else if (!isScalarOperand(*v)) {
      err = "'" + op + "' cannot combine " + kindText(a) + " with " + kindText(b);
      return false;
    }
  }
  return true;
}

/* ---- A ^ n --------------------------------------------------------------- */

MatOpStatus matrixPower(const Value &a, const Value &b, Value &out, std::string &err) {
  if (!a.isMatrix) {
    err = "'^': a number raised to a matrix is not supported - for element-wise powers write "
          "x^.A";
    return MatOpStatus::Error;
  }
  if (!isScalarOperand(b) || b.hasComplex()) {
    err = "'^': the exponent of a matrix power must be a single whole number, got " + kindText(b) +
          " - for element-wise powers write A^.B";
    return MatOpStatus::Error;
  }
  const double p = b.number;
  const double rounded = std::round(p);
  if (!std::isfinite(p) || std::fabs(p - rounded) > 1e-12 * std::max(1.0, std::fabs(p))) {
    err = "'^': A^" + numText(p) +
          " - a matrix can only be raised to a whole-number power (A^2, A^-1, A^2.0); "
          "for element-wise powers write A^." + numText(p);
    return MatOpStatus::Error;
  }
  if (std::fabs(rounded) > 1e9) {
    err = "'^': exponent " + numText(p) + " is too large for a matrix power";
    return MatOpStatus::Error;
  }
  const size_t R = a.rows(), C = R ? a.cols() : 0;
  if (R == 0 || R != C) {
    err = "'^': matrix power needs a square matrix, got " + matShapeText(a) +
          " - for element-wise powers write A^." + numText(p);
    return MatOpStatus::Error;
  }
  if (!matrixIsNumeric(a)) {
    err = "'^': a matrix containing text cannot be raised to a power";
    return MatOpStatus::Error;
  }

  long long n = static_cast<long long>(rounded);
  const bool negative = n < 0;
  if (negative)
    n = -n;

  if (a.hasComplex()) {
    MatrixXcd base = toEigenCMat(a);
    if (negative) {
      Eigen::FullPivLU<MatrixXcd> lu(base);
      if (!lu.isInvertible()) {
        err = "'^': the matrix is singular, so A^" + numText(p) + " (which needs inv(A)) does not exist";
        return MatOpStatus::Error;
      }
      base = lu.inverse();
    }
    MatrixXcd result = MatrixXcd::Identity(R, R);
    while (n > 0) {
      if (n & 1)
        result = result * base;
      n >>= 1;
      if (n > 0)
        base = base * base;
    }
    out = toValueC(result);
    return MatOpStatus::Ok;
  }

  MatrixXd base = toEigenMat(a);
  if (negative) {
    if (isEffectivelySingular(base)) {
      err = "'^': the matrix is singular, so A^" + numText(p) + " (which needs inv(A)) does not exist";
      return MatOpStatus::Error;
    }
    base = base.inverse().eval();
  }
  MatrixXd result = MatrixXd::Identity(R, R);
  while (n > 0) {
    if (n & 1)
      result = (result * base).eval();
    n >>= 1;
    if (n > 0)
      base = (base * base).eval();
  }
  out = toValue(result);
  return MatOpStatus::Ok;
}

/* ---- A *. B / A /. B ------------------------------------------------------ */

MatOpStatus elementwise(const std::string &op, const Value &a, const Value &b, Value &out,
                        std::string &err) {
  const bool multiply = (op == "*.");
  if (!checkNumeric(op, a, b, err))
    return MatOpStatus::Error;

  if (a.isMatrix && b.isMatrix) {
    if (!sameShape(a, b)) {
      err = "'" + op + "' needs two matrices of the same size, got " + matShapeText(a) + " and " +
            matShapeText(b);
      return MatOpStatus::Error;
    }
    if (a.rows() == 0) {
      out = a;
      return MatOpStatus::Ok;
    }
    if (a.hasComplex() || b.hasComplex()) {
      MatrixXcd x = toEigenCMat(a), y = toEigenCMat(b);
      MatrixXcd r = multiply ? MatrixXcd(x.array() * y.array()) : MatrixXcd(x.array() / y.array());
      out = toValueC(r);
      return MatOpStatus::Ok;
    }
    MatrixXd x = toEigenMat(a), y = toEigenMat(b);
    MatrixXd r = multiply ? MatrixXd(x.array() * y.array()) : MatrixXd(x.array() / y.array());
    out = toValue(r);
    return MatOpStatus::Ok;
  }

  // A matrix and a single value: every element with that value.
  if (multiply || a.isMatrix) {
    out = multiply ? mul(a, b) : div_op(a, b);
    return MatOpStatus::Ok;
  }

  // s /. A - the value divided by every element.
  if (b.rows() == 0) {
    out = b;
    return MatOpStatus::Ok;
  }
  if (a.hasComplex() || b.hasComplex()) {
    std::complex<double> s(a.number, 0.0);
    if (a.hasComplex()) {
      MatrixXcd one = toEigenCMat(matArrayAsMatrix(Value(std::vector<Value>{a}), false));
      s = one(0, 0);
    }
    MatrixXcd y = toEigenCMat(b);
    MatrixXcd r = (s / y.array()).matrix();
    out = toValueC(r);
    return MatOpStatus::Ok;
  }
  MatrixXd y = toEigenMat(b);
  MatrixXd r = (a.number / y.array()).matrix();
  out = toValue(r);
  return MatOpStatus::Ok;
}

} // namespace

bool matrixIsNumeric(const Value &m) {
  if (!m.isMatrix)
    return !m.isText;
  if (m.isPacked() || m.isPackedComplex())
    return true;
  for (size_t r = 0; r < m.rows(); r++)
    for (size_t c = 0; c < m.rowLength(r); c++) {
      Value cell = m.at(r, c);
      if (cell.isText || cell.isArray || cell.isMatrix || cell.isDict || cell.isObject ||
          cell.isFunctionRef)
        return false;
    }
  return true;
}

MatOpStatus matrixBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                           std::string &err) {
  if (!a.isMatrix && !b.isMatrix)
    return MatOpStatus::NotHandled;

  if (op == "^")
    return matrixPower(a, b, out, err);

  if (op == "*." || op == "/.")
    return elementwise(op, a, b, out, err);

  if (op == "+" || op == "-" || op == "*" || op == "/") {
    if (!checkNumeric(op, a, b, err))
      return MatOpStatus::Error;
  }

  if (op == "+" || op == "-") {
    if (a.isMatrix && b.isMatrix && !sameShape(a, b)) {
      err = "'" + op + "' needs two matrices of the same size, got " + matShapeText(a) + " and " +
            matShapeText(b);
      return MatOpStatus::Error;
    }
    return MatOpStatus::NotHandled;
  }

  if (op == "*") {
    if (a.isMatrix && b.isMatrix) {
      const size_t aC = a.rows() ? a.cols() : 0;
      if (aC != b.rows()) {
        err = "'*': inner matrix dimensions must agree - " + matShapeText(a) + " * " +
              matShapeText(b) + " needs the columns of the left (" + std::to_string(aC) +
              ") to equal the rows of the right (" + std::to_string(b.rows()) +
              "). For element-wise multiplication write A*.B";
        return MatOpStatus::Error;
      }
    }
    return MatOpStatus::NotHandled;
  }

  if (op == "/") {
    if (!a.isMatrix) {
      err = "'/': a number divided by a matrix is not defined - write x/.A to divide x by every "
            "element, or x*inv(A) for the inverse";
      return MatOpStatus::Error;
    }
    if (b.isMatrix) {
      const size_t bR = b.rows(), bC = bR ? b.cols() : 0;
      const size_t aC = a.rows() ? a.cols() : 0;
      if (bR == 0 || bR != bC) {
        err = "'/': A/B means A*inv(B), so B must be square - got " + matShapeText(b) +
              ". For element-wise division write A/.B";
        return MatOpStatus::Error;
      }
      if (aC != bR) {
        err = "'/': A/B means A*inv(B) - the columns of A (" + std::to_string(aC) +
              ") must equal the size of B (" + std::to_string(bR) + "). For element-wise division write A/.B";
        return MatOpStatus::Error;
      }
      if (!b.hasComplex() && isEffectivelySingular(toEigenMat(b))) {
        err = "'/': B is singular (not invertible), so A/B does not exist";
        return MatOpStatus::Error;
      }
    }
    return MatOpStatus::NotHandled;
  }

  return MatOpStatus::NotHandled; // %, // - element-wise in arithmetic.cpp
}
