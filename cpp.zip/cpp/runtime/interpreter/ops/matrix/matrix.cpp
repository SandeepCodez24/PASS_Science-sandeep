#include "matrix.h"
#include "matrix_arithmetic.h"
#include "matrix_index.h"
#include "nd_array.h"
#include "../arithmetic/arithmetic.h"
#include "../floating/floating.h"
#include "../integer/integer.h"
#include "../time/time.h"
#include "../../builtins/builtins.h"
#include <Eigen/Dense>
#include <algorithm>
#include <cmath>
#include <complex>
#include <iostream>
#include <limits>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <random>
#include <string>

using namespace Eigen;

/* ================= MATRIX VALIDATION ================= */

static bool invalidMatrix(const MatrixXd &m) {
  return (m.rows() == 0 || m.cols() == 0);
}

bool isEffectivelySingular(const MatrixXd &m) {
  if (m.rows() != m.cols())
    return true; // not even square - never invertible
  if (m.rows() == 0)
    return true;
  Eigen::JacobiSVD<MatrixXd> svd(m);
  const auto &sv = svd.singularValues();
  if (sv.size() == 0)
    return true;
  double maxSV = sv.maxCoeff();
  if (maxSV == 0.0)
    return true; // the all-zero matrix
  double tol = std::numeric_limits<double>::epsilon() * std::max(m.rows(), m.cols()) * maxSV;
  return sv.minCoeff() <= tol;
}

/* ================= VALUE → EIGEN ================= */

MatrixXd toEigenMat(Value v) {
  if (v.isMatrix) {
    int rows = v.rows();
    if (rows == 0)
      return MatrixXd(0, 0);

    int cols = v.cols();
    // All-numeric matrix: its buffer is already in Eigen's own layout.
    if (v.isPacked())
      return Eigen::Map<const MatrixXd>(v.packedData(), rows, cols);

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.numAt(i, j);

    return m;
  }

  if (v.length() != 0 && v.at(0).isArray) {
    int rows = v.length();
    int cols = v.at(0).length();

    MatrixXd m(rows, cols);

    for (int i = 0; i < rows; i++)
      for (int j = 0; j < cols; j++)
        m(i, j) = v.at(i).numAt(j);

    return m;
  }

  // Flat array: treat as a column vector (n x 1).
  int size = v.length();
  if (size == 0)
    return MatrixXd(0, 0);

  MatrixXd m(size, 1);
  for (int i = 0; i < size; i++)
    m(i, 0) = v.numAt(i);

  return m;
}

/* ================= EIGEN → VALUE ================= */

Value toValue(MatrixXd m) {
  if (m.rows() > 0 && m.cols() > 0)
    return Value::packedMatrix(m.data(), m.rows(), m.cols());

  std::vector<std::vector<Value>> mat;

  for (int i = 0; i < m.rows(); i++) {
    std::vector<Value> row;

    for (int j = 0; j < m.cols(); j++)
      row.push_back(Value(m(i, j)));

    mat.push_back(row);
  }

  return Value(mat);
}

/* ================= COMPLEX CONVERSIONS ================= */

MatrixXcd toEigenCMat(const Value &v) {
  if (!v.isMatrix || v.rows() == 0 || v.cols() == 0)
    return MatrixXcd(0, 0);

  int rows = v.rows(), cols = v.cols();
  if (v.isPackedComplex())
    return Eigen::Map<const MatrixXcd>(v.packedComplexData(), rows, cols);

  MatrixXcd m(rows, cols);
  for (int i = 0; i < rows; i++) {
    if ((int)v.rowLength(i) != cols)
      return MatrixXcd(0, 0);
    for (int j = 0; j < cols; j++)
      m(i, j) = v.cnumAt(i, j);
  }
  return m;
}

Value toValueC(const MatrixXcd &m) {
  if (m.rows() == 0 || m.cols() == 0)
    return Value(std::vector<std::vector<Value>>{});
  Value result = Value::packedComplexMatrix(m.data(), m.rows(), m.cols());
  result.narrowIfReal();
  return result;
}

// Elementwise product of two complex (or mixed) matrices, for had_prod()
// and ElementWise() below.
static Value complexHadamard(const char *fnName, const Value &a, const Value &b) {
  MatrixXcd m1 = toEigenCMat(a);
  MatrixXcd m2 = toEigenCMat(b);

  if (m1.size() == 0 || m2.size() == 0) {
    std::cerr << "Error: " << fnName << " requires two non-empty matrices\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: " << fnName << " requires same dimensions (" << m1.rows() << "x"
              << m1.cols() << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  MatrixXcd r = m1.array() * m2.array();
  return toValueC(r);
}

/* ================= OPERATIONS ================= */

Value MatrixTranspose(Value a) {
  // Plain transpose: a complex matrix is not conjugated (use conj(A)').
  if (a.hasComplex()) {
    MatrixXcd cm = toEigenCMat(a);
    if (cm.size() == 0) {
      std::cerr << "Error: transpose requires a non-empty matrix\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }
    MatrixXcd t = cm.transpose();
    return toValueC(t);
  }
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: transpose requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return toValue(m.transpose());
}

Value det(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    // Determinant is undefined for a non-square matrix - returning 0 used
    // to be silent, indistinguishable from "this square matrix genuinely
    // has determinant 0" (i.e. singular). Reporting it directly avoids
    // that ambiguity.
    std::cerr << "Error: det requires a non-empty square matrix (got "
              << m.rows() << "x" << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return Value(m.determinant());
}

Value rank(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: rank requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return Value(m.fullPivLu().rank());
}

Value inv(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: inv requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  if (isEffectivelySingular(m)) {
    std::cerr << "Error: matrix is singular (not invertible)\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  return toValue(m.inverse());
}

Value had_prod(Value a, Value b) {
  if (a.hasComplex() || b.hasComplex())
    return complexHadamard("had_prod", a, b);
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2)) {
    std::cerr << "Error: had_prod requires two non-empty matrices\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: had_prod requires same dimensions (" << m1.rows() << "x" << m1.cols()
              << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return toValue(m1.array() * m2.array());
}

Value pseudo_inverse(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: pinv requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // SVD-based Moore-Penrose pseudo-inverse.
  // pinv(A) = V * S^+ * U^T where A = U * S * V^T
  // Eigen 5: thin U/V are requested as a compile-time template option; the
  // old runtime form svd(m, ComputeThinU | ComputeThinV) is deprecated.
  Eigen::JacobiSVD<MatrixXd, Eigen::ComputeThinU | Eigen::ComputeThinV> svd(m);
  const auto &singular = svd.singularValues();

  // Tolerance for treating singular values as zero.
  // tol = eps * max(m,n) * maxSingular
  const double eps = std::numeric_limits<double>::epsilon();
  double maxSingular = 0.0;
  if (singular.size() > 0) {
    maxSingular = singular.maxCoeff();
  }
  const double tol = eps * std::max(m.rows(), m.cols()) * maxSingular;

  MatrixXd Splus = MatrixXd::Zero(singular.size(), singular.size());

  for (int i = 0; i < singular.size(); ++i) {
    if (singular(i) > tol) {
      Splus(i, i) = 1.0 / singular(i);
    }
  }

  MatrixXd pinv = svd.matrixV() * Splus * svd.matrixU().transpose();
  return toValue(pinv);
}

Value adj(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: adj requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  const int n = (int)m.rows();
  // Adjugate matrix: adj(A) = C^T where C_ij are cofactors.
  // We compute cofactors directly to avoid unstable determinant/inverse checks.
  MatrixXd adjMat(n, n);
  adjMat.setZero();

  if (n == 1) {
    adjMat(0, 0) = 1.0;
    return toValue(adjMat);
  }

  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      // Minor by removing row i and col j.
      MatrixXd minor(n - 1, n - 1);
      int r = 0;
      for (int rr = 0; rr < n; ++rr) {
        if (rr == i)
          continue;
        int c = 0;
        for (int cc = 0; cc < n; ++cc) {
          if (cc == j)
            continue;
          minor(r, c) = m(rr, cc);
          ++c;
        }
        ++r;
      }

      double detMinor = minor.determinant();
      double sign = ((i + j) % 2 == 0) ? 1.0 : -1.0;
      double cofactor = sign * detMinor;
      // adj(A) = C^T => adj(j,i) = C(i,j)
      adjMat(j, i) = cofactor;
    }
  }

  return toValue(adjMat);
}

Value Norm(Value a) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: matrix_norm requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  double sum = 0;
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < m.cols(); j++)
      sum += m(i, j) * m(i, j);

  return Value(std::sqrt(sum));
}

Value MatrixNormOrd(Value a, Value ord) {
  MatrixXcd m = a.hasComplex() ? toEigenCMat(a) : MatrixXcd(toEigenMat(a).cast<std::complex<double>>());
  if (m.size() == 0) {
    std::cerr << "Error: matrix_norm requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  MatrixXd mag = m.cwiseAbs();
  auto singular = [&]() {
    Eigen::JacobiSVD<MatrixXcd> svd(m);
    return Eigen::VectorXd(svd.singularValues());
  };
  if (ord.isText) {
    if (ord.text() == "fro")
      return Value(m.norm());
    if (ord.text() == "nuc")
      return Value(singular().sum());
    std::cerr << "Error: matrix_norm: ord must be \"fro\", \"nuc\", 1, -1, 2, -2, inf or -inf, "
                 "got \""
              << ord.text() << "\"\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  const double p = ord.number;
  if (p == 1)
    return Value(mag.colwise().sum().maxCoeff());
  if (p == -1)
    return Value(mag.colwise().sum().minCoeff());
  if (p == 2)
    return Value(singular().maxCoeff());
  if (p == -2)
    return Value(singular().minCoeff());
  if (std::isinf(p))
    return Value(p > 0 ? mag.rowwise().sum().maxCoeff() : mag.rowwise().sum().minCoeff());
  std::cerr << "Error: matrix_norm: ord must be \"fro\", \"nuc\", 1, -1, 2, -2, inf or -inf, got "
            << p << "\n";
  g_lastBuiltinFound = false; // stop the statement
  return Value(0);
}

Value diag(Value a) {
  // Diag(n) => n x n diagonal matrix filled with `n` on the diagonal.
  // If a is already a matrix, fall back to extracting its diagonal as a vector.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: diag requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }
    return toValue(MatrixXd::Identity(n, n) * a.number);
  }

  // A row or column vector ([1,2,3] or [1;2;3]) is a list of diagonal
  // entries, exactly like a 1-D array.
  if (a.isMatrix && a.rows() > 0 && (a.rows() == 1 || a.cols() == 1) &&
      a.rows() * a.cols() > 1) {
    std::vector<Value> entries;
    for (size_t r = 0; r < a.rows(); r++)
      for (size_t c = 0; c < a.cols(); c++)
        entries.push_back(a.at(r, c));
    return diag(Value(entries));
  }

  if (!a.isMatrix && a.isArray) {
    // Diag(vector) => diagonal matrix.
    MatrixXd m((int)a.length(), (int)a.length());
    m.setZero();
    for (int i = 0; i < (int)a.length(); i++)
      m(i, i) = a.numAt(i);
    return toValue(m);
  }

  // Only a.isMatrix can reach here (the two conditions above already cover
  // every other combination of isMatrix/isArray - a dead, exact-duplicate
  // third branch used to sit here re-testing the same "scalar" condition
  // the first branch already handles and returns from unconditionally;
  // removed as unreachable, not a behavior change).
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: diag requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // The diagonal of a matrix, as a column (MATLAB's diag(A)).
  int n = static_cast<int>(std::min(m.rows(), m.cols()));
  MatrixXd d(n, 1);
  for (int i = 0; i < n; i++)
    d(i, 0) = m(i, i);
  return toValue(d);
}

Value upper_triangular(Value a) {
  // upper_triangular(n) => generate an n x n upper-triangular matrix.
  // Documented expected form for n=3:
  // [[1,1,1],
  //  [0,1,1],
  //  [0,0,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: upper_triangular requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = i; j < n; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: upper_triangular requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // Mask below diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = 0; j < i; j++)
      m(i, j) = 0;

  return toValue(m);
}

Value zero_matrix(Value a) {
  // zero_matrix(n) => n x n all-zero matrix.
  // If a is already a matrix, return a same-sized zero matrix.
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: zero_matrix requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }
    return toValue(MatrixXd::Zero(n, n));
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: zero_matrix requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return toValue(MatrixXd::Zero(m.rows(), m.cols()));
}

Value Lower_Triangular(Value a) {
  // Lower_Triangular(n) => deterministic n x n lower-triangular matrix.
  // Documented expected form for n=3:
  // [[1,0,0],
  //  [1,1,0],
  //  [1,1,1]]
  if (!a.isMatrix && !a.isArray) {
    int n = (int)a.number;
    if (n <= 0) {
      std::cerr << "Error: lower_triangular requires a positive size, got " << n << "\n";
      g_lastBuiltinFound = false; // stop the statement
      return Value(0);
    }

    MatrixXd m = MatrixXd::Zero(n, n);
    for (int i = 0; i < n; ++i)
      for (int j = 0; j <= i; ++j)
        m(i, j) = 1.0;

    return toValue(m);
  }

  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: lower_triangular requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // Mask above diagonal.
  for (int i = 0; i < m.rows(); i++)
    for (int j = i + 1; j < m.cols(); j++)
      m(i, j) = 0;

  return toValue(m);
}
Value ElementWise(Value a, Value b) {
  if (a.hasComplex() || b.hasComplex())
    return complexHadamard("element_wise", a, b);
  MatrixXd m1 = toEigenMat(a);
  MatrixXd m2 = toEigenMat(b);

  if (invalidMatrix(m1) || invalidMatrix(m2)) {
    std::cerr << "Error: element_wise requires two non-empty matrices\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  if (m1.rows() != m2.rows() || m1.cols() != m2.cols()) {
    std::cerr << "Error: element_wise requires same dimensions (" << m1.rows() << "x"
              << m1.cols() << ") vs (" << m2.rows() << "x" << m2.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  // Element-wise multiplication (Hadamard product).
  MatrixXd r = m1.array() * m2.array();

  return toValue(r);
}

Value full_rank_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m)) {
    std::cerr << "Error: full_rank_matrix requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  int r = m.fullPivLu().rank();
  return Value(r == std::min(m.rows(), m.cols()));
}

Value singular_matrix(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: singular_matrix requires a non-empty square matrix (got " << m.rows()
              << "x" << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return Value(isEffectivelySingular(m));
}

// pd_matrix(A) / nd_matrix(A): is A positive / negative definite? Definiteness
// is a property of symmetric matrices, so a square matrix that is not symmetric
// answers false (as Julia's isposdef does) - it used to stop the script with an
// error, which made the function unusable as a test. The eigenvalue cutoff is
// relative to A's own size, so a small-valued matrix such as 1e-13*I still
// counts as definite.
static bool definiteTest(const Value &a, const char *fn, bool positive) {
  MatrixXd m = toEigenMat(a);

  if (invalidMatrix(m)) {
    std::cerr << "Error: " << fn << " requires a non-empty matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return false;
  }

  if (m.rows() != m.cols()) {
    std::cerr << "Error: " << fn << " requires a square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return false;
  }

  if (!m.isApprox(m.transpose()))
    return false;

  SelfAdjointEigenSolver<MatrixXd> es(m);
  const VectorXd &values = es.eigenvalues();
  const double tol = std::numeric_limits<double>::epsilon() * static_cast<double>(m.rows()) *
                     values.cwiseAbs().maxCoeff();

  return positive ? values.minCoeff() > tol : values.maxCoeff() < -tol;
}

Value pd_matrix(Value a) { return Value(definiteTest(a, "pd_matrix", true)); }

Value nd_matrix(Value a) { return Value(definiteTest(a, "nd_matrix", false)); }

Value unit_matrix(Value a) {
  int n = (int)a.number;
  if (n <= 0) {
    std::cerr << "Error: unit_matrix requires a positive size, got " << n << "\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return toValue(MatrixXd::Identity(n, n));
}

/* ---------- zeros / ones ---------- */

namespace {

// Size limits for building a matrix from a shape. Past kNoticeElements
// (2^27 elements = 1 GiB as float64) a one-line note says how much memory
// the matrix takes; past kMaxElements it is refused instead of letting the
// allocation fail and stop the interpreter.
constexpr size_t kNoticeElements = size_t(1) << 27;
constexpr size_t kMaxElements = size_t(1) << 34;

// Element count of `dims`, or false (with a message) when it is too large.
bool checkedCount(const char *fn, const std::vector<size_t> &dims, size_t &count) {
  count = 1;
  for (size_t d : dims) {
    if (d != 0 && count > kMaxElements / d) {
      std::cerr << "Error: " << fn << "(" << nd::shapeText(dims)
                << ") is too large - more than 2^34 elements\n";
      return false;
    }
    count *= d;
  }
  if (count > kMaxElements) {
    std::cerr << "Error: " << fn << "(" << nd::shapeText(dims)
              << ") is too large - more than 2^34 elements\n";
    return false;
  }
  if (count > kNoticeElements) {
    const double gib = static_cast<double>(count) * 8.0 / (1024.0 * 1024.0 * 1024.0);
    char buf[160];
    std::snprintf(buf, sizeof buf, "Note: %s is %.3g million elements - %.2f GiB as float64",
                  nd::shapeText(dims).c_str(), static_cast<double>(count) / 1e6, gib);
    std::cout << buf << std::endl;
  }
  return true;
}

// Reads one size: a whole number >= 0.
bool readSize(const char *fn, const Value &v, size_t &out) {
  if (v.isText || v.isArray || v.isMatrix || v.isDict || v.isObject || v.isFunctionRef ||
      v.hasComplex() || !std::isfinite(v.number) || v.number != std::floor(v.number) ||
      v.number < 0) {
    std::cerr << "Error: " << fn << ": a size must be a whole number >= 0 - use " << fn
              << "(m) or " << fn << "([m,n])\n";
    return false;
  }
  out = static_cast<size_t>(v.number);
  return true;
}

// The size argument shared by zeros / ones / nexus*: m (an m x m matrix),
// [m,n] (m x n), or [d0,d1,...,m,n] for an N-dimensional matrix - a vector
// (row, column or 1-D array) of whole numbers.
bool readDims(const char *fn, const Value &s, std::vector<size_t> &dims) {
  dims.clear();
  if (s.isMatrix || s.isArray) {
    if (s.isND() || (s.isMatrix && !matIsVectorShape(s) && s.rows() != 0)) {
      std::cerr << "Error: " << fn << ": the size must be a vector like [m,n] or [d0,m,n], got a "
                << matShapeText(s) << " matrix\n";
      return false;
    }
    const Value list = matVectorAsArray(s);
    const size_t count = list.isArray ? list.length() : 0;
    if (count < 2) {
      std::cerr << "Error: " << fn << ": the size needs at least 2 values ([m,n]), got " << count
                << " - write " << fn << "(m) for an m x m matrix\n";
      return false;
    }
    for (size_t i = 0; i < count; i++) {
      size_t d = 0;
      if (!readSize(fn, list.at(i), d))
        return false;
      dims.push_back(d);
    }
    return true;
  }
  size_t n = 0;
  if (!readSize(fn, s, n))
    return false;
  dims = {n, n};
  return true;
}

// fn(m) -> m x m, fn([m,n]) or fn(m, n) -> m x n, fn([d0,...,m,n]) or
// fn(d0, ..., m, n) -> an N-D matrix; every element `fill`.
Value filledMatrix(const char *fn, const std::vector<Value> &args, double fill) {
  std::vector<size_t> dims;
  bool ok = false;
  if (args.size() == 1) {
    ok = readDims(fn, args[0], dims);
  } else if (args.size() >= 2) {
    ok = true;
    for (const Value &a : args) {
      size_t d = 0;
      if (!readSize(fn, a, d)) {
        ok = false;
        break;
      }
      dims.push_back(d);
    }
  } else {
    std::cerr << "Error: " << fn << " expects a size - " << fn << "(m), " << fn << "([m,n]) or "
              << fn << "([d0,m,n])\n";
  }
  size_t count = 0;
  if (!ok || !checkedCount(fn, dims, count)) {
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }
  if (count == 0)
    return Value(std::vector<std::vector<Value>>{}); // empty matrix
  try {
    if (dims.size() >= 3)
      return Value::ndPacked(dims, std::vector<double>(count, fill), false);
    return toValue(MatrixXd::Constant(static_cast<Eigen::Index>(dims[0]),
                                      static_cast<Eigen::Index>(dims[1]), fill));
  } catch (const std::bad_alloc &) {
    std::cerr << "Error: " << fn << "(" << nd::shapeText(dims) << ") - not enough memory\n";
    g_lastBuiltinFound = false;
    return Value(0);
  }
}

} // namespace

Value zeros(const std::vector<Value> &args) { return filledMatrix("zeros", args, 0.0); }
Value ones(const std::vector<Value> &args) { return filledMatrix("ones", args, 1.0); }

/* ---------- random matrices: the nexus family ----------
   nexus<_shape><_kind>(size[, range])
     size   m (m x m) or [m,n] (m x n)
     range  [a, b] or range(a, b):
              integer / float / uniform  ->  [lower, upper]
              normal                     ->  [mean, SD]
     shape  (none) full,  _UTM upper triangle,  _LTM lower triangle
            (the diagonal is included; the rest is 0)
     kind   (none) whole numbers in [lower, upper], default [-100, 100]
            _float    real numbers in [lower, upper), default [-10, 10]
            _uniform  real numbers in [lower, upper), default [0, 1]
            _normal   normal distribution, default mean 1, SD 1
   nexus_seed(n) makes the following matrices repeatable. */

namespace {

std::mt19937_64 &nexusEngine() {
  static std::mt19937_64 engine{std::random_device{}()};
  return engine;
}

enum class NexusKind { Integer, Float, Uniform, Normal };
enum class NexusShape { Full, Upper, Lower };

// The optional range argument: exactly two real numbers.
bool readRange(const char *fn, const Value &r, double &a, double &b) {
  std::vector<Value> parts;
  if (r.isArray) {
    parts = r.elems();
  } else if (r.isMatrix) {
    for (size_t i = 0; i < r.rows(); i++)
      for (size_t j = 0; j < r.rowLength(i); j++)
        parts.push_back(r.at(i, j));
  }
  bool ok = parts.size() == 2;
  for (const Value &p : parts)
    ok = ok && !p.isText && !p.isArray && !p.isMatrix && !p.isDict && !p.isObject &&
         !p.isComplex && std::isfinite(p.number);
  if (!ok) {
    std::cerr << "Error: " << fn << ": the range must be two numbers, e.g. " << fn
              << "(5, range(50, 75)) or " << fn << "(5, [50, 75])\n";
    return false;
  }
  a = parts[0].number;
  b = parts[1].number;
  return true;
}

Value nexusMatrix(const char *fn, const std::vector<Value> &args, NexusKind kind,
                  NexusShape shape) {
  auto fail = [] {
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  };
  if (args.empty() || args.size() > 2) {
    std::cerr << "Error: " << fn << " expects " << fn << "(size) or " << fn
              << "(size, range) - got " << args.size() << " argument(s)\n";
    return fail();
  }
  std::vector<size_t> dims;
  size_t count = 0;
  if (!readDims(fn, args[0], dims) || !checkedCount(fn, dims, count))
    return fail();
  const size_t rows = dims[dims.size() - 2], cols = dims[dims.size() - 1];

  double a = 0, b = 0; // [lower, upper], or [mean, SD] for normal
  switch (kind) {
  case NexusKind::Integer: a = -100; b = 100; break;
  case NexusKind::Float: a = -10; b = 10; break;
  case NexusKind::Uniform: a = 0; b = 1; break;
  case NexusKind::Normal: a = 1; b = 1; break;
  }
  if (args.size() == 2 && !readRange(fn, args[1], a, b))
    return fail();

  if (kind == NexusKind::Normal) {
    if (b < 0) {
      std::cerr << "Error: " << fn << ": the standard deviation must not be negative, got " << b
                << " - the range is [mean, SD]\n";
      return fail();
    }
  } else if (a > b) {
    std::cerr << "Error: " << fn << ": the range [lower, upper] needs lower <= upper, got [" << a
              << ", " << b << "]\n";
    return fail();
  }
  if (kind == NexusKind::Integer) {
    a = std::ceil(a);
    b = std::floor(b);
    if (a > b) {
      std::cerr << "Error: " << fn << ": there is no whole number in the range\n";
      return fail();
    }
  }

  if (count == 0)
    return Value(std::vector<std::vector<Value>>{});

  std::mt19937_64 &rng = nexusEngine();
  std::uniform_int_distribution<long long> whole(static_cast<long long>(a),
                                                 static_cast<long long>(b));
  std::uniform_real_distribution<double> real(a, b);
  std::normal_distribution<double> normal(a, b);
  auto draw = [&]() -> double {
    switch (kind) {
    case NexusKind::Integer: return static_cast<double>(whole(rng));
    case NexusKind::Normal: return b == 0 ? a : normal(rng);
    default: return a == b ? a : real(rng);
    }
  };

  if (dims.size() >= 3) {
    // N-D: every rows x cols page is drawn like a 2-D nexus matrix (the
    // triangle shapes apply page by page), in storage order.
    std::vector<double> buf;
    try {
      buf.assign(count, 0.0);
    } catch (const std::bad_alloc &) {
      std::cerr << "Error: " << fn << "(" << nd::shapeText(dims) << ") - not enough memory\n";
      return fail();
    }
    const size_t pages = count / (rows * cols);
    for (size_t p = 0; p < pages; p++)
      for (size_t i = 0; i < rows; i++)
        for (size_t j = 0; j < cols; j++) {
          if ((shape == NexusShape::Upper && j < i) || (shape == NexusShape::Lower && j > i))
            continue;
          buf[p * rows * cols + j * rows + i] = draw();
        }
    return Value::ndPacked(dims, std::move(buf), false);
  }

  MatrixXd m = MatrixXd::Zero(static_cast<Eigen::Index>(rows), static_cast<Eigen::Index>(cols));
  for (Eigen::Index i = 0; i < m.rows(); i++)
    for (Eigen::Index j = 0; j < m.cols(); j++) {
      if ((shape == NexusShape::Upper && j < i) || (shape == NexusShape::Lower && j > i))
        continue; // outside the triangle: stays 0
      m(i, j) = draw();
    }
  return toValue(m);
}

} // namespace

std::mt19937_64 &ncRandomEngine() { return nexusEngine(); }

Value nexus(const std::string &name, const std::vector<Value> &args) {
  std::string key = name;
  for (char &ch : key)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

  if (key == "nexus_seed") {
    if (args.size() != 1 || args[0].isText || args[0].isArray || args[0].isMatrix ||
        !std::isfinite(args[0].number) || args[0].number != std::floor(args[0].number) ||
        args[0].number < 0) {
      std::cerr << "Error: nexus_seed expects one whole number >= 0, e.g. nexus_seed(42)\n";
      g_lastBuiltinFound = false;
      return Value(0);
    }
    nexusEngine().seed(static_cast<std::uint64_t>(args[0].number));
    return Value(args[0].number);
  }

  NexusShape shape = NexusShape::Full;
  NexusKind kind = NexusKind::Integer;
  std::string rest = key.substr(5); // after "nexus"
  if (rest.rfind("_utm", 0) == 0) {
    shape = NexusShape::Upper;
    rest = rest.substr(4);
  } else if (rest.rfind("_ltm", 0) == 0) {
    shape = NexusShape::Lower;
    rest = rest.substr(4);
  }
  if (rest == "_float")
    kind = NexusKind::Float;
  else if (rest == "_uniform")
    kind = NexusKind::Uniform;
  else if (rest == "_normal")
    kind = NexusKind::Normal;
  else if (!rest.empty()) {
    std::cerr << "Error: Unknown matrix function '" << name << "'\n";
    g_lastBuiltinFound = false;
    return Value(0);
  }
  return nexusMatrix(key.c_str(), args, kind, shape);
}

Value Trace(Value a) {
  MatrixXd m = toEigenMat(a);
  if (invalidMatrix(m) || m.rows() != m.cols()) {
    std::cerr << "Error: trace requires a non-empty square matrix (got " << m.rows() << "x"
              << m.cols() << ")\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value(0);
  }

  return Value(m.trace());
}

// onlyrows(A): the rows of A as a list, each a 1xN row vector - A[0,:],
// A[1,:], ... - for `for r in onlyrows(A):`. onlycols(A): the columns, each
// an Nx1 column vector - A[:,0], A[:,1], ... Until 2026-10 both returned
// plain arrays, so onlycols(A) printed exactly like A transposed
// ([[1,4],[2,5],[3,6]]) and the two were easy to confuse; a column now
// prints as one: [[1;4],[2;5],[3;6]].
Value OnlyRows(Value a) {
  if (!a.isMatrix) {
    if (a.isArray)
      return Value(std::vector<Value>{matArrayAsMatrix(a, false)});
    std::cerr << "Error: onlyrows expects a matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value();
  }
  std::vector<Value> rows;
  for (size_t r = 0; r < a.rows(); r++)
    rows.push_back(Value(std::vector<std::vector<Value>>{a.row(r)}));
  return Value(rows);
}

Value OnlyCols(Value a) {
  if (!a.isMatrix) {
    if (a.isArray) {
      std::vector<Value> cols;
      for (const auto &item : a.elems())
        cols.push_back(Value(std::vector<std::vector<Value>>{{item}}));
      return Value(cols);
    }
    std::cerr << "Error: onlycols expects a matrix\n";
    g_lastBuiltinFound = false; // stop the statement
    return Value();
  }
  if (a.rows() == 0) return Value(std::vector<Value>{});
  size_t colCount = a.cols();
  std::vector<Value> cols;
  for (size_t c = 0; c < colCount; ++c) {
    std::vector<std::vector<Value>> colVec;
    for (size_t r = 0; r < a.rows(); ++r) {
      if (c < a.rowLength(r))
        colVec.push_back({a.at(r, c)});
      else
        colVec.push_back({Value(0.0)});
    }
    cols.push_back(Value(std::move(colVec)));
  }
  return Value(cols);
}
/* =====================================================================
   INDEXING, SLICING, SLICE ASSIGNMENT, MATRIX LITERALS
   Declared in matrix_index.h (see there for every rule). Kept in this
   file so no build-file change is needed.
   ===================================================================== */


namespace {

using Grid = std::vector<std::vector<Value>>;

std::string numText(double x) {
  char buf[40];
  std::snprintf(buf, sizeof buf, "%.15g", x);
  return buf;
}

std::string quoted(const std::string &name) { return name.empty() ? "the value" : "'" + name + "'"; }

// A value that is neither a matrix nor an array.
bool isSingle(const Value &v) { return !v.isMatrix && !v.isArray; }

size_t rowsOf(const Value &v) {
  if (v.isMatrix)
    return v.rows();
  if (v.isArray)
    return v.length() ? 1 : 0;
  return 1;
}

size_t colsOf(const Value &v) {
  if (v.isMatrix)
    return v.rows() ? v.cols() : 0;
  if (v.isArray)
    return v.length();
  return 1;
}

// Element (r, c) of a matrix, an array (taken as one row) or a single value.
Value cellOf(const Value &v, size_t r, size_t c) {
  if (v.isMatrix)
    return v.at(r, c);
  if (v.isArray)
    return v.at(c);
  return v;
}

// t-th element of a vector-shaped matrix or an array.
Value linearOf(const Value &v, size_t t) {
  if (v.isArray)
    return v.at(t);
  if (v.rows() == 1)
    return v.at(0, t);
  return v.at(t, 0);
}

bool wholeIndex(double x, long long &out) {
  if (!std::isfinite(x) || x != std::floor(x))
    return false;
  out = static_cast<long long>(x);
  return true;
}

// Resolves one key against a dimension of length n into a list of
// 0-based positions. `grow` (assignment only) lets positive indices reach
// past the end. `what` is "row", "column" or "element".
// `axisLabel` (N-D matrices: "axis 0", "axis 1", ...) words the range in
// positions along that axis instead of rows / columns / elements.
bool resolveKey(const MatIndexKey &k, size_t n, bool grow, const char *what,
                const std::string &name, std::vector<size_t> &idx, std::string &err,
                const std::string &axisLabel = std::string()) {
  idx.clear();
  const long long len = static_cast<long long>(n);
  const std::string singular = axisLabel.empty() ? std::string(what) : "position along " + axisLabel;
  const std::string plural =
      axisLabel.empty() ? std::string(what) + "s" : "positions along " + axisLabel;

  auto rangeText = [&]() {
    if (n == 0)
      return quoted(name) + " has no " + plural;
    return quoted(name) + " has " + std::to_string(n) + " " + (n == 1 ? singular : plural) +
           ", indexed 0.." + std::to_string(n - 1) + " (or -1..-" + std::to_string(n) + " from the end)";
  };

  // Normalizes one written index: negative counts from the end.
  auto normalize = [&](double raw, long long &out) -> bool {
    long long i = 0;
    if (!wholeIndex(raw, i)) {
      err = std::string(what) + " index " + numText(raw) + " is not a whole number";
      return false;
    }
    if (i < 0) {
      i += len;
      if (i < 0) {
        err = std::string(what) + " index " + numText(raw) + " is out of range - " + rangeText();
        return false;
      }
    }
    out = i;
    return true;
  };

  auto checkUpper = [&](long long i, double raw) -> bool {
    if (i >= len && !grow) {
      err = std::string(what) + " index " + numText(raw) + " is out of range - " + rangeText();
      return false;
    }
    return true;
  };

  switch (k.kind) {
  case MatIndexKey::All:
    for (size_t i = 0; i < n; i++)
      idx.push_back(i);
    return true;

  case MatIndexKey::Scalar: {
    long long i = 0;
    if (!normalize(k.scalar, i) || !checkUpper(i, k.scalar))
      return false;
    idx.push_back(static_cast<size_t>(i));
    return true;
  }

  case MatIndexKey::Range: {
    long long step = 1;
    if (k.hasStep) {
      if (!wholeIndex(k.step, step)) {
        err = "slice step " + numText(k.step) + " is not a whole number";
        return false;
      }
      if (step == 0) {
        err = "slice step cannot be 0";
        return false;
      }
    }
    long long s = 0, e = 0;
    if (k.hasStart) {
      if (!normalize(k.start, s))
        return false;
    } else {
      s = step > 0 ? 0 : len - 1;
    }
    if (k.hasStop) {
      if (!normalize(k.stop, e))
        return false;
    } else {
      e = step > 0 ? len - 1 : 0;
    }
    const bool empty = step > 0 ? (s > e) : (s < e);
    if (empty)
      return true; // A[5:3] - an empty selection, like MATLAB
    long long hi = std::max(s, e);
    if (!checkUpper(hi, hi == s ? k.start : k.stop))
      return false;
    if (step > 0)
      for (long long i = s; i <= e; i += step)
        idx.push_back(static_cast<size_t>(i));
    else
      for (long long i = s; i >= e; i += step)
        idx.push_back(static_cast<size_t>(i));
    return true;
  }
  }
  return true;
}

Value fromGrid(Grid g) { return Value(std::move(g)); }

} // namespace

bool matIsVectorShape(const Value &v) {
  return v.isMatrix && v.rows() > 0 && (v.rows() == 1 || v.cols() == 1);
}

std::string matShapeText(const Value &v) {
  if (v.isND())
    return nd::shapeText(v.ndShape());
  if (v.isMatrix)
    return std::to_string(v.rows()) + "x" + std::to_string(v.rows() ? v.cols() : 0);
  if (v.isArray)
    return "1x" + std::to_string(v.length());
  return "1x1";
}

Value matVectorAsArray(const Value &v) {
  if (v.isArray || !matIsVectorShape(v))
    return v;
  std::vector<Value> out;
  const size_t n = v.rows() * v.cols();
  out.reserve(n);
  for (size_t t = 0; t < n; t++)
    out.push_back(linearOf(v, t));
  return Value(std::move(out));
}

Value matArrayAsMatrix(const Value &v, bool asColumn) {
  if (!v.isArray)
    return v;
  Grid g;
  if (asColumn) {
    for (size_t i = 0; i < v.length(); i++)
      g.push_back({v.at(i)});
  } else {
    g.push_back(v.elems());
  }
  return fromGrid(std::move(g));
}

Value matTransposeValue(const Value &v) {
  if (isSingle(v))
    return v;
  const size_t R = rowsOf(v), C = colsOf(v);
  if (R == 0 || C == 0)
    return v.isArray ? fromGrid(Grid{}) : v;
  Grid g(C, std::vector<Value>(R));
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < C; c++)
      g[c][r] = cellOf(v, r, c);
  return fromGrid(std::move(g));
}

/* ======================================================================
   Read
   ====================================================================== */

bool matIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                 Value &out, std::string &err) {
  if (v.isND())
    return ndIndexGet(v, keys, name, out, err);
  if (keys.empty() || keys.size() > 2) {
    err = quoted(name) + " takes one or two indices inside [ ], got " + std::to_string(keys.size());
    return false;
  }

  // Flat array (e.g. the result of space()): one index, element-wise.
  if (v.isArray) {
    if (keys.size() != 1) {
      err = quoted(name) + " is a 1-D array - use one index, e.g. " +
            (name.empty() ? std::string("x") : name) + "[2]";
      return false;
    }
    std::vector<size_t> idx;
    if (!resolveKey(keys[0], v.length(), false, "element", name, idx, err))
      return false;
    if (keys[0].kind == MatIndexKey::Scalar) {
      out = v.at(idx[0]);
      return true;
    }
    std::vector<Value> sel;
    sel.reserve(idx.size());
    for (size_t i : idx)
      sel.push_back(v.at(i));
    out = Value(std::move(sel));
    return true;
  }

  if (!v.isMatrix) {
    err = quoted(name) + " is not a matrix - only matrices, arrays and dicts can be indexed with [ ]";
    return false;
  }

  const size_t R = v.rows(), C = R ? v.cols() : 0;

  if (keys.size() == 1) {
    // A vector: one index picks elements, keeping the vector's orientation.
    if (matIsVectorShape(v)) {
      const size_t n = R * C;
      std::vector<size_t> idx;
      if (!resolveKey(keys[0], n, false, "element", name, idx, err))
        return false;
      if (keys[0].kind == MatIndexKey::Scalar) {
        out = linearOf(v, idx[0]);
        return true;
      }
      Grid g;
      if (R == 1) {
        g.emplace_back();
        for (size_t i : idx)
          g[0].push_back(v.at(0, i));
        if (idx.empty())
          g.clear();
      } else {
        for (size_t i : idx)
          g.push_back({v.at(i, 0)});
      }
      out = fromGrid(std::move(g));
      return true;
    }

    // A general matrix: one index selects whole rows.
    std::vector<size_t> rows;
    if (!resolveKey(keys[0], R, false, "row", name, rows, err))
      return false;
    Grid g;
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(C);
      for (size_t c = 0; c < C; c++)
        row.push_back(v.at(r, c));
      g.push_back(std::move(row));
    }
    out = fromGrid(std::move(g));
    return true;
  }

  std::vector<size_t> rows, cols;
  if (!resolveKey(keys[0], R, false, "row", name, rows, err) ||
      !resolveKey(keys[1], C, false, "column", name, cols, err))
    return false;

  if (keys[0].kind == MatIndexKey::Scalar && keys[1].kind == MatIndexKey::Scalar) {
    out = v.at(rows[0], cols[0]);
    return true;
  }

  Grid g;
  if (!cols.empty()) {
    for (size_t r : rows) {
      std::vector<Value> row;
      row.reserve(cols.size());
      for (size_t c : cols)
        row.push_back(v.at(r, c));
      g.push_back(std::move(row));
    }
  }
  out = fromGrid(std::move(g));
  return true;
}

/* ======================================================================
   Write
   ====================================================================== */

namespace {

// The 2-D assignment itself (matIndexSet() below checks the type rules
// around it). `growFill` is what new cells get when the matrix grows.
bool matIndexSet2D(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                   const Value &rhs, const std::string &name, std::string &err,
                   const Value &growFill) {

  const bool rhsSingle = isSingle(rhs);
  const size_t rhsR = rowsOf(rhs), rhsC = colsOf(rhs);
  const size_t rhsN = rhsR * rhsC;
  const bool rhsVector = rhsSingle || rhs.isArray || matIsVectorShape(rhs);

  // ---- flat array target: one index, no growth -------------------------
  if (exists && target.isArray) {
    if (keys.size() != 1) {
      err = quoted(name) + " is a 1-D array - use one index, e.g. " + name + "[2] = value";
      return false;
    }
    std::vector<size_t> idx;
    if (!resolveKey(keys[0], target.length(), false, "element", name, idx, err))
      return false;
    if (!rhsSingle && !(rhsVector && rhsN == idx.size())) {
      err = "cannot assign " + matShapeText(rhs) + " values to " + std::to_string(idx.size()) +
            " element(s) of " + quoted(name);
      return false;
    }
    for (size_t t = 0; t < idx.size(); t++)
      target.setAt(idx[t], rhsSingle ? rhs : linearOf(rhs, t));
    return true;
  }

  if (exists && !target.isMatrix && (target.isText || target.isDict || target.isObject ||
                                     target.isFunctionRef)) {
    err = quoted(name) + " is not a matrix - [ ] assignment with numeric indices needs a matrix";
    return false;
  }

  // A plain number counts as a 1x1 matrix (x = 5; x[0,2] = 7 grows it).
  const bool targetIsMatrix = exists && target.isMatrix;
  const size_t R = targetIsMatrix ? target.rows() : (exists ? 1 : 0);
  const size_t C = targetIsMatrix ? (R ? target.cols() : 0) : (exists ? 1 : 0);
  auto currentCell = [&](size_t r, size_t c) -> Value {
    return targetIsMatrix ? target.at(r, c) : target;
  };

  std::vector<size_t> rows, cols;
  bool linear = false; // one index on a vector (or an empty / new matrix)
  bool rowOrient = true;

  if (keys.size() == 1) {
    const bool vectorTarget = (R == 1 || C == 1) || (R == 0 && C == 0);
    if (vectorTarget) {
      linear = true;
      rowOrient = (R <= 1); // 1xN, 1x1 and empty grow to the right
      const size_t n = R * C;
      std::vector<size_t> idx;
      if (keys[0].kind == MatIndexKey::All && n == 0) {
        for (size_t t = 0; !rhsSingle && t < rhsN; t++)
          idx.push_back(t);
      } else if (!resolveKey(keys[0], n, true, "element", name, idx, err)) {
        return false;
      }
      if (rowOrient) {
        rows = {0};
        cols = idx;
      } else {
        rows = idx;
        cols = {0};
      }
    } else {
      if (!resolveKey(keys[0], R, true, "row", name, rows, err))
        return false;
      for (size_t c = 0; c < C; c++)
        cols.push_back(c);
    }
  } else {
    if (keys[0].kind == MatIndexKey::All && R == 0) {
      for (size_t r = 0; !rhsSingle && r < rhsR; r++)
        rows.push_back(r);
    } else if (!resolveKey(keys[0], R, true, "row", name, rows, err)) {
      return false;
    }
    if (keys[1].kind == MatIndexKey::All && C == 0) {
      for (size_t c = 0; !rhsSingle && c < rhsC; c++)
        cols.push_back(c);
    } else if (!resolveKey(keys[1], C, true, "column", name, cols, err)) {
      return false;
    }
  }

  const size_t selR = linear ? (rowOrient ? 1 : rows.size()) : rows.size();
  const size_t selC = linear ? (rowOrient ? cols.size() : 1) : cols.size();
  if (selR == 0 || selC == 0)
    return true; // empty selection - nothing to write

  // How the right-hand side fills the selection.
  enum class Fill { Broadcast, Exact, Linear } fill;
  if (rhsSingle)
    fill = Fill::Broadcast;
  else if (rhsR == selR && rhsC == selC)
    fill = Fill::Exact;
  else if ((selR == 1 || selC == 1) && rhsVector && rhsN == selR * selC)
    fill = Fill::Linear;
  else {
    err = "cannot assign a " + matShapeText(rhs) + " value to a " + std::to_string(selR) + "x" +
          std::to_string(selC) + " selection of " + quoted(name) +
          " - the sizes must match, or assign a single value";
    return false;
  }

  auto rhsFor = [&](size_t i, size_t j) -> Value {
    switch (fill) {
    case Fill::Broadcast:
      return rhs;
    case Fill::Exact:
      return cellOf(rhs, i, j);
    case Fill::Linear:
      return linearOf(rhs, selR == 1 ? j : i);
    }
    return rhs;
  };

  size_t newR = R, newC = C;
  for (size_t r : rows)
    newR = std::max(newR, r + 1);
  for (size_t c : cols)
    newC = std::max(newC, c + 1);

  const bool rebuild = !targetIsMatrix || newR != R || newC != C;

  if (!rebuild) {
    for (size_t i = 0; i < rows.size(); i++)
      for (size_t j = 0; j < cols.size(); j++)
        target.setAt(rows[i], cols[j], rhsFor(i, j));
    return true;
  }

  Grid g(newR, std::vector<Value>(newC, growFill));
  for (size_t r = 0; r < R; r++)
    for (size_t c = 0; c < C; c++)
      g[r][c] = currentCell(r, c);
  for (size_t i = 0; i < rows.size(); i++)
    for (size_t j = 0; j < cols.size(); j++)
      g[rows[i]][cols[j]] = rhsFor(i, j);
  target = fromGrid(std::move(g));
  return true;
}

// True when a matrix (or a single value) holds text.
bool holdsText(const Value &v) {
  if (v.isText)
    return true;
  if (v.isND()) {
    if (v.isPacked() || v.isPackedComplex())
      return false;
    return v.ndCount() > 0 && v.ndAt(0).isText;
  }
  if (v.isMatrix) {
    if (v.isPacked() || v.isPackedComplex())
      return false;
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        if (v.at(r, c).isText)
          return true;
    return false;
  }
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      if (v.at(i).isText)
        return true;
  }
  return false;
}

// The type-rule check for A[...] = rhs on an existing value: numbers can be
// written into a numeric matrix and text into a text matrix, never one into
// the other.
bool checkAssignKinds(const Value &target, bool exists, const Value &rhs, const std::string &name,
                      std::string &err) {
  if (!exists)
    return true;
  const bool targetEmpty = (target.isMatrix && !target.isND() && target.rows() == 0) ||
                           (target.isND() && target.ndCount() == 0);
  if (targetEmpty || target.isArray)
    return true;
  const bool tText = holdsText(target), rText = holdsText(rhs);
  if (tText == rText)
    return true;
  if (tText)
    err = quoted(name) + " is a text matrix - a number cannot be stored in it (write it as text, "
                         "e.g. \"5\")";
  else
    err = quoted(name) + " holds numbers - text cannot be stored in it (a matrix holds one type; "
                         "build a text matrix with text from the start)";
  return false;
}

bool sameUnit(const Value &a, const Value &b) {
  return a.dimL == b.dimL && a.dimT == b.dimT && a.dimM == b.dimM;
}

// "m/s", or "no unit" - for error messages.
std::string unitWords(const Value &v) {
  if (v.dimL == 0 && v.dimT == 0 && v.dimM == 0)
    return "no unit";
  std::string num, den;
  auto part = [&](const char *sym, int e) {
    if (e == 0)
      return;
    std::string &side = e > 0 ? num : den;
    if (!side.empty())
      side += "*";
    side += sym;
    if (std::abs(e) != 1)
      side += "^" + std::to_string(std::abs(e));
  };
  part("m", v.dimL);
  part("s", v.dimT);
  part("kg", v.dimM);
  return (num.empty() ? std::string("1") : num) + (den.empty() ? "" : "/" + den);
}

// Both values are single elements of exactly the same type (float64,
// float32, int8, bool, complex, text ...).
bool sameElementType(const Value &a, const Value &b) {
  if (a.isText || b.isText)
    return a.isText && b.isText;
  if (a.isComplex || b.isComplex)
    return a.isComplex && b.isComplex;
  if (a.isBool() || b.isBool())
    return a.isBool() && b.isBool();
  if (a.isInt() || b.isInt())
    return a.isInt() && b.isInt() && a.intType() == b.intType();
  return a.floatType() == b.floatType();
}

// The zero value of the element type `sample` has: what new cells get when
// a matrix grows by assignment.
Value zeroLike(const Value &sample) {
  if (sample.isText)
    return Value(std::string());
  if (sample.isBool())
    return Value::boolean(false);
  if (sample.isInt())
    return sample.intIsUnsigned() ? Value::integerUnsigned(sample.intType(), 0)
                                  : Value::integerSigned(sample.intType(), 0);
  if (!sample.isComplex && sample.floatType() != FloatType::Float64)
    return Value::floating(sample.floatType(), 0.0);
  return Value(0.0);
}

// The first element of any value (the value itself when it is single).
Value firstElement(const Value &v) {
  if (v.isND())
    return v.ndCount() ? v.ndAt(0) : Value(0.0);
  if (v.isMatrix)
    return v.rows() && v.rowLength(0) ? v.at(0, 0) : Value(0.0);
  if (v.isArray)
    return v.length() ? v.at(0) : Value(0.0);
  return v;
}

// After an assignment into a cell-form matrix: bring every element back to
// one common type (numeric widening - checkAssignKinds() already kept text
// and numbers apart). A packed matrix is plain float64 or complex already.
bool normalizeAfterAssign(Value &target, std::string &err) {
  if (!target.isMatrix || target.isPacked() || target.isPackedComplex())
    return true;
  const nd::Shape shape = nd::shapeOf(target);
  if (nd::countOf(shape) == 0)
    return true;
  std::vector<Value> cells = nd::storageCells(target);
  if (!matUnifyCells(cells, err))
    return false;
  target = nd::build(shape, std::move(cells));
  return true;
}

} // namespace

bool matIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                 const Value &rhs, const std::string &name, std::string &err) {
  if (rhs.isDict || rhs.isObject || rhs.isFunctionRef) {
    err = "only numbers, text and matrices can be stored in a matrix";
    return false;
  }
  if ((exists && target.isND()) || (!exists && keys.size() >= 3))
    return ndIndexSet(target, exists, keys, rhs, name, err);
  if (keys.empty() || keys.size() > 2) {
    err = quoted(name) + " is 2-D - it takes one or two indices inside [ ], got " +
          std::to_string(keys.size());
    return false;
  }
  if (rhs.isND()) {
    err = "cannot store a " + matShapeText(rhs) + " matrix in a selection of the 2-D matrix " +
          quoted(name);
    return false;
  }
  if (!checkAssignKinds(target, exists, rhs, name, err))
    return false;

  // New cells (growth) get the zero of the matrix's element type.
  const bool targetHasElements = exists && !(target.isMatrix && target.rows() == 0) && !target.isArray;
  const Value sample = targetHasElements ? firstElement(target) : firstElement(rhs);
  if (targetHasElements && !sameUnit(sample, firstElement(rhs)) && !sample.isText) {
    err = quoted(name) + " holds values in " + unitWords(sample) + " - a value in " +
          unitWords(firstElement(rhs)) + " cannot be stored in it (a matrix has one unit)";
    return false;
  }
  const Value fill = zeroLike(sample);

  if (!matIndexSet2D(target, exists, keys, rhs, name, err, fill))
    return false;
  // A single value of the matrix's own element type needs no conversion -
  // the common case (A[i,j] = x in a loop) stays a plain write.
  if (isSingle(rhs) && sameElementType(sample, rhs))
    return true;
  return normalizeAfterAssign(target, err);
}

/* ======================================================================
   Matrix literal
   ====================================================================== */

namespace {

// Applies the type rules (matUnifyCells) to every cell of a built grid.
bool unifyGrid(Grid &g, std::string &err) {
  std::vector<Value> cells;
  for (const auto &row : g)
    for (const auto &cell : row)
      cells.push_back(cell);
  if (!matUnifyCells(cells, err))
    return false;
  size_t t = 0;
  for (auto &row : g)
    for (auto &cell : row)
      cell = std::move(cells[t++]);
  return true;
}

} // namespace

bool matBuildFromCells(const std::vector<std::vector<Value>> &rows, Value &out, std::string &err) {
  bool anyContainer = false;
  bool anyND = false;
  for (const auto &row : rows)
    for (const auto &cell : row) {
      if (!isSingle(cell))
        anyContainer = true;
      if (cell.isND())
        anyND = true;
    }

  // An N-D matrix inside the brackets ([B, B] with B 2x2x2): the general
  // N-D builder joins along the right axis.
  if (anyND)
    return matBuildND(rows, std::vector<int>(rows.size(), 1), out, err);

  // Plain [1,2;3,4]: every cell one value.
  if (!anyContainer) {
    for (size_t r = 1; r < rows.size(); r++) {
      if (rows[r].size() != rows[0].size()) {
        err = "matrix literal: row " + std::to_string(r + 1) + " has " +
              std::to_string(rows[r].size()) + " value(s) but row 1 has " +
              std::to_string(rows[0].size()) + " - every row needs the same number of values";
        return false;
      }
    }
    Grid g = rows;
    if (!unifyGrid(g, err))
      return false;
    out = fromGrid(std::move(g));
    return true;
  }

  // Concatenation: [A, B] side by side, [A; B] stacked.
  Grid result;
  size_t width = 0;
  bool haveWidth = false;
  size_t widthRow = 0;
  for (size_t r = 0; r < rows.size(); r++) {
    size_t height = 0;
    bool haveHeight = false;
    Grid band;
    for (size_t k = 0; k < rows[r].size(); k++) {
      const Value &cell = rows[r][k];
      if (cell.isDict || cell.isObject || cell.isFunctionRef) {
        err = "matrix literal: row " + std::to_string(r + 1) + ", item " + std::to_string(k + 1) +
              " is not a number, text, array or matrix";
        return false;
      }
      const size_t h = rowsOf(cell), w = colsOf(cell);
      if (h == 0 || w == 0)
        continue; // [] items are skipped
      if (!haveHeight) {
        height = h;
        haveHeight = true;
        band.assign(height, {});
      } else if (h != height) {
        err = "matrix literal: row " + std::to_string(r + 1) + " joins items of different heights (" +
              std::to_string(height) + " and " + std::to_string(h) +
              " rows) - [A, B] needs A and B to have the same number of rows";
        return false;
      }
      for (size_t i = 0; i < h; i++)
        for (size_t j = 0; j < w; j++)
          band[i].push_back(cellOf(cell, i, j));
    }
    if (!haveHeight)
      continue;
    const size_t w = band[0].size();
    if (!haveWidth) {
      width = w;
      haveWidth = true;
      widthRow = r;
    } else if (w != width) {
      err = "matrix literal: row " + std::to_string(r + 1) + " is " + std::to_string(w) +
            " column(s) wide but row " + std::to_string(widthRow + 1) + " is " +
            std::to_string(width) + " - [A; B] needs A and B to have the same number of columns";
      return false;
    }
    for (auto &line : band)
      result.push_back(std::move(line));
  }
  if (!unifyGrid(result, err))
    return false;
  out = fromGrid(std::move(result));
  return true;
}

/* ======================================================================
   TYPE RULES - what one matrix holds
   ======================================================================

   A matrix holds ONE type of element: numbers (true/false, one integer
   type, one float type, or complex) or text. Never a dict, an object or a
   function reference.

   Building a matrix (a literal [..], joining [A, B] / [A; B] / [A ;; B])
   from mixed elements converts them all to the narrowest type that holds
   every one of them:

       bool  <  integer  <  float8/16/32  <  float64  <  complex  <  text

     * Any text: every element becomes text. A number is written with full
       round-trip precision (0.1 -> "0.1", 1/3 -> "0.3333333333333333"), so
       reading the text back gives exactly the same number; true/false
       become "true"/"false". Quoted values are always text - "1.2" stays
       the text "1.2", it is never read as a number.
     * Otherwise any complex number makes every element complex; otherwise
       any plain number (float64) makes every element float64.
     * Otherwise float8/16/32 elements give the widest of them - wide enough
       for any integers present too (int8 needs float16, int16 float32,
       anything wider float64).
     * Otherwise integers give one integer type that holds all of them
       (int8 with int16 -> int16, int8 with uint8 -> int16); true/false
       among them become 1/0. Only true/false stays bool.
     * Every number in a matrix has the same physical unit: 5*m next to 2*s
       is an error, as is a number with a unit next to text.

   Assigning into a matrix (A[i,j] = v) only ever WIDENS numbers: 2.5 into
   a bool matrix makes it float64, 3i makes a real matrix complex, true in a
   float64 matrix is stored as 1. Text into a numeric matrix, or a number
   into a text matrix, is an error - a matrix never silently turns into
   text after it has been built. See matIndexSet().
*/

namespace {

enum class CellKind { Bool, Int, Float, F64, Complex, Text, Other };

CellKind cellKind(const Value &c) {
  if (c.isText)
    return CellKind::Text;
  if (c.isDict || c.isObject || c.isFunctionRef || c.isArray || c.isMatrix)
    return CellKind::Other;
  if (c.isComplex)
    return CellKind::Complex;
  if (c.isBool())
    return CellKind::Bool;
  if (c.isInt())
    return CellKind::Int;
  if (c.floatType() != FloatType::Float64)
    return CellKind::Float;
  return CellKind::F64;
}

const char *otherKindText(const Value &c) {
  if (c.isDict)
    return "a dict";
  if (c.isObject)
    return "an object";
  if (c.isFunctionRef)
    return "a function reference";
  return "a nested matrix";
}

int intBitsOf(IntType t) {
  switch (t) {
  case IntType::Int8:
  case IntType::UInt8:
    return 8;
  case IntType::Int16:
  case IntType::UInt16:
    return 16;
  case IntType::Int32:
  case IntType::UInt32:
    return 32;
  default:
    return 64;
  }
}

bool intIsSignedType(IntType t) {
  return t == IntType::Int8 || t == IntType::Int16 || t == IntType::Int32 || t == IntType::Int64;
}

IntType intOfBits(int bits, bool isSigned) {
  if (bits <= 8)
    return isSigned ? IntType::Int8 : IntType::UInt8;
  if (bits <= 16)
    return isSigned ? IntType::Int16 : IntType::UInt16;
  if (bits <= 32)
    return isSigned ? IntType::Int32 : IntType::UInt32;
  return isSigned ? IntType::Int64 : IntType::UInt64;
}

// float8 = 1, float16 = 2, float32 = 3, float64 = 4.
int floatRankOf(FloatType t) {
  switch (t) {
  case FloatType::Float8:
    return 1;
  case FloatType::Float16:
    return 2;
  case FloatType::Float32:
    return 3;
  default:
    return 4;
  }
}

FloatType floatOfRank(int r) {
  switch (r) {
  case 1:
    return FloatType::Float8;
  case 2:
    return FloatType::Float16;
  case 3:
    return FloatType::Float32;
  default:
    return FloatType::Float64;
  }
}

// The plain float64 a numeric element stands for, keeping its unit.
Value plainNumber(const Value &c) {
  Value v(c.number);
  v.dimL = c.dimL;
  v.dimT = c.dimT;
  v.dimM = c.dimM;
  return v;
}

// A number as the shortest text that reads back as exactly the same number.
std::string roundTripText(double x) {
  if (std::isnan(x))
    return "nan";
  if (std::isinf(x))
    return x > 0 ? "inf" : "-inf";
  if (x == 0.0)
    return "0";
  char buf[40];
  if (x == std::floor(x) && std::fabs(x) < 1e15) {
    std::snprintf(buf, sizeof buf, "%.0f", x);
    return buf;
  }
  for (int precision = 1; precision <= 17; precision++) {
    std::snprintf(buf, sizeof buf, "%.*g", precision, x);
    if (std::strtod(buf, nullptr) == x)
      break;
  }
  return buf;
}

// A numeric element as text, for a matrix that holds text.
std::string elementText(const Value &c) {
  if (c.isBool())
    return c.number != 0.0 ? "true" : "false";
  if (c.isInt())
    return c.intText();
  if (c.isComplex)
    return roundTripText(c.number) + (std::signbit(c.imag) ? "-" : "+") +
           roundTripText(std::fabs(c.imag)) + "i";
  return roundTripText(c.number);
}

} // namespace

bool matUnifyCells(std::vector<Value> &cells, std::string &err) {
  // Timestamps / durations (ops/time/): a matrix of them holds only that
  // one type - never mixed with numbers, text or the other time type - and
  // its cells stay exactly as they are.
  for (const Value &c : cells) {
    if (!c.isTime())
      continue;
    for (const Value &o : cells) {
      if (o.isTimestamp() != c.isTimestamp() || !o.isTime()) {
        err = "time error: cannot concatenate " + nctime::typeName(c) + " with " +
              nctime::typeName(o);
        return false;
      }
    }
    return true;
  }

  bool anyText = false, anyComplex = false, anyF64 = false, anyFloat = false, anyInt = false;
  bool unitNumbers = false;
  int widestFloat = 0;
  int maxSigned = 0, maxUnsigned = 0;
  bool oneIntType = true;
  IntType firstInt = IntType::None;
  const Value *unitFrom = nullptr;

  for (const Value &c : cells) {
    const CellKind k = cellKind(c);
    if (k == CellKind::Other) {
      err = std::string("a matrix cannot hold ") + otherKindText(c) +
            " - its elements are numbers, true/false or text";
      return false;
    }
    if (k == CellKind::Text) {
      anyText = true;
      continue;
    }
    if (!unitFrom) {
      unitFrom = &c;
    } else if (!sameUnit(*unitFrom, c)) {
      err = "every element of a matrix has the same unit - found " + unitWords(*unitFrom) +
            " and " + unitWords(c) + " together";
      return false;
    }
    if (c.dimL != 0 || c.dimT != 0 || c.dimM != 0)
      unitNumbers = true;
    switch (k) {
    case CellKind::Complex:
      anyComplex = true;
      break;
    case CellKind::F64:
      anyF64 = true;
      break;
    case CellKind::Float:
      anyFloat = true;
      widestFloat = std::max(widestFloat, floatRankOf(c.floatType()));
      break;
    case CellKind::Int: {
      anyInt = true;
      const IntType t = c.intType();
      if (firstInt == IntType::None)
        firstInt = t;
      else if (t != firstInt)
        oneIntType = false;
      if (intIsSignedType(t))
        maxSigned = std::max(maxSigned, intBitsOf(t));
      else
        maxUnsigned = std::max(maxUnsigned, intBitsOf(t));
      break;
    }
    default:
      break; // bool
    }
  }

  if (anyText) {
    if (unitNumbers) {
      err = "a matrix of text cannot hold numbers with a unit";
      return false;
    }
    for (Value &c : cells)
      if (!c.isText)
        c = Value(elementText(c));
    return true;
  }

  if (anyComplex || anyF64) {
    for (Value &c : cells)
      if (!c.isComplex && cellKind(c) != CellKind::F64)
        c = plainNumber(c);
    return true;
  }

  if (anyFloat) {
    int need = widestFloat;
    if (anyInt) {
      const int bits = std::max(maxSigned, maxUnsigned);
      need = std::max(need, bits <= 8 ? 2 : bits <= 16 ? 3 : 4);
    }
    if (need >= 4) {
      for (Value &c : cells)
        c = plainNumber(c);
      return true;
    }
    const FloatType t = floatOfRank(need);
    for (Value &c : cells) {
      if (cellKind(c) == CellKind::Float && c.floatType() == t)
        continue;
      Value converted;
      if (!castToFloat(c, t, converted, err))
        return false;
      c = std::move(converted);
    }
    return true;
  }

  if (anyInt) {
    IntType target = firstInt;
    if (!oneIntType) {
      if (maxSigned == 0) {
        target = intOfBits(maxUnsigned, false);
      } else if (maxUnsigned == 0) {
        target = intOfBits(maxSigned, true);
      } else {
        const int bits = std::max(maxSigned, 2 * maxUnsigned);
        if (bits > 64) { // uint64 with a signed type: no integer type holds both
          for (Value &c : cells)
            c = plainNumber(c);
          return true;
        }
        target = intOfBits(bits, true);
      }
    }
    for (Value &c : cells) {
      if (c.isInt() && c.intType() == target)
        continue;
      Value converted;
      if (!castToInteger(c, target, converted, err))
        return false;
      c = std::move(converted);
    }
    return true;
  }

  return true; // only true/false (or nothing at all)
}

/* ======================================================================
   N-DIMENSIONAL MATRICES
   ====================================================================== */

namespace {

// The separator that joins blocks along axis -(fromEnd): "," ";" ";;" ...
std::string separatorText(size_t fromEnd) {
  return fromEnd <= 1 ? std::string(",") : std::string(fromEnd - 1, ';');
}

// Joins `parts` along axis -(fromEnd) (1 = the last axis) after giving each
// `rank` axes by putting 1s in front of its shape. Empty parts are skipped,
// as in MATLAB. Every other axis must match.
bool ndConcat(const std::vector<Value> &parts, size_t fromEnd, size_t rank, Value &out,
              std::string &err) {
  std::vector<const Value *> used;
  std::vector<nd::Shape> shapes;
  for (const Value &p : parts) {
    if (p.isDict || p.isObject || p.isFunctionRef) {
      err = std::string("matrix literal: a matrix cannot hold ") + otherKindText(p);
      return false;
    }
    nd::Shape s = nd::shapeOf(p);
    if (nd::countOf(s) == 0)
      continue;
    used.push_back(&p);
    shapes.push_back(nd::withRank(s, rank));
  }
  if (used.empty()) {
    out = Value(Grid{});
    return true;
  }
  const size_t axis = rank - fromEnd;
  nd::Shape result = shapes[0];
  for (size_t i = 1; i < shapes.size(); i++) {
    for (size_t d = 0; d < rank; d++) {
      if (d != axis && shapes[i][d] != shapes[0][d]) {
        err = "matrix literal: the blocks joined by '" + separatorText(fromEnd) +
              "' must have the same size in every other dimension - got " +
              nd::shapeText(shapes[0]) + " and " + nd::shapeText(shapes[i]);
        return false;
      }
    }
    result[axis] += shapes[i][axis];
  }
  if (used.size() == 1 && nd::shapeOf(*used[0]).size() == rank) {
    out = *used[0];
    return true;
  }
  std::vector<Value> cells(nd::countOf(result));
  size_t offset = 0;
  for (size_t i = 0; i < used.size(); i++) {
    std::vector<size_t> idx(rank, 0);
    do {
      std::vector<size_t> at = idx;
      at[axis] += offset;
      cells[nd::storageIndex(result, at)] = nd::elementAt(*used[i], idx);
    } while (nd::nextIndex(idx, shapes[i]));
    offset += shapes[i][axis];
  }
  out = nd::build(result, std::move(cells));
  return true;
}

// Rows [lo, hi) of an N-D literal, joined at separator level L.
bool buildLevel(const std::vector<std::vector<Value>> &rows, const std::vector<int> &levels,
                size_t lo, size_t hi, int L, Value &out, std::string &err) {
  std::vector<Value> parts;
  if (L == 0) {
    // One row: its cells, joined along the last axis (',').
    for (size_t r = lo; r < hi; r++)
      for (const Value &cell : rows[r])
        parts.push_back(cell);
  } else {
    size_t start = lo;
    for (size_t i = lo; i < hi; i++) {
      if (i + 1 == hi || levels[i] >= L) {
        Value part;
        if (!buildLevel(rows, levels, start, i + 1, L - 1, part, err))
          return false;
        parts.push_back(std::move(part));
        start = i + 1;
      }
    }
  }
  size_t rank = static_cast<size_t>(L) + 1;
  rank = std::max<size_t>(rank, 2);
  for (const Value &p : parts)
    rank = std::max(rank, nd::shapeOf(p).size());
  return ndConcat(parts, static_cast<size_t>(L) + 1, rank, out, err);
}

// Gives `v` at least `rank` axes (1s in front). Storage order is unchanged.
Value raiseRank(const Value &v, size_t rank) {
  const nd::Shape s = nd::shapeOf(v);
  if (s.size() >= rank || nd::countOf(s) == 0)
    return v;
  return nd::build(nd::withRank(s, rank), nd::storageCells(v));
}

} // namespace

bool matBuildND(const std::vector<std::vector<Value>> &rows, const std::vector<int> &levels,
                Value &out, std::string &err) {
  if (rows.empty()) {
    out = Value(Grid{});
    return true;
  }
  int top = 1;
  for (size_t i = 0; i < levels.size(); i++)
    top = std::max(top, levels[i]);
  Value built;
  if (!buildLevel(rows, levels, 0, rows.size(), top, built, err))
    return false;
  // A trailing separator raises the rank: [1,2;3,4;;] is 1x2x2.
  const int trailing = levels.empty() ? 0 : levels.back();
  built = raiseRank(built, static_cast<size_t>(trailing) + 1);

  const nd::Shape shape = nd::shapeOf(built);
  if (nd::countOf(shape) == 0) {
    out = built;
    return true;
  }
  std::vector<Value> cells = nd::storageCells(built);
  if (!matUnifyCells(cells, err)) {
    err = "matrix literal: " + err;
    return false;
  }
  out = nd::build(shape, std::move(cells));
  return true;
}

/* ---- indexing ---------------------------------------------------------- */

namespace {

std::string axisLabel(size_t i) { return "axis " + std::to_string(i); }

// Shared by get and set: resolves B[k] (one key: slabs along the first
// axis) or B[i,j,...,r,c] (one key per axis) against `shape`.
//   sel[d]      chosen positions along axis d
//   keepAxis[d] the axis stays in the result (a scalar key on a leading
//               axis drops it; rows and columns always stay)
bool ndSelect(const nd::Shape &shape, const std::vector<MatIndexKey> &keys, bool grow,
              const std::string &name, std::vector<std::vector<size_t>> &sel,
              std::vector<bool> &keepAxis, std::string &err) {
  const size_t n = shape.size();
  sel.assign(n, {});
  keepAxis.assign(n, true);
  if (keys.size() == 1) {
    if (!resolveKey(keys[0], shape[0], grow, "axis 0", name, sel[0], err, axisLabel(0)))
      return false;
    keepAxis[0] = keys[0].kind != MatIndexKey::Scalar;
    for (size_t d = 1; d < n; d++)
      for (size_t i = 0; i < shape[d]; i++)
        sel[d].push_back(i);
    return true;
  }
  if (keys.size() != n) {
    const std::string who = name.empty() ? std::string("B") : name;
    err = quoted(name) + " is " + std::to_string(n) + "-D (" + nd::shapeText(shape) +
          ") - index it with 1 key (" + who + "[m] is the slab m) or with " + std::to_string(n) +
          " keys, one per axis";
    return false;
  }
  for (size_t d = 0; d < n; d++) {
    const char *what = d == n - 2 ? "row" : d == n - 1 ? "column" : "axis";
    const std::string label = d + 2 < n ? axisLabel(d) : std::string();
    const std::string whatText = d + 2 < n ? axisLabel(d) : std::string(what);
    if (!resolveKey(keys[d], shape[d], grow, whatText.c_str(), name, sel[d], err, label))
      return false;
    if (d + 2 < n)
      keepAxis[d] = keys[d].kind != MatIndexKey::Scalar;
  }
  return true;
}

// Shape of the selection as a value (dropped axes removed).
nd::Shape selectionShape(const std::vector<std::vector<size_t>> &sel,
                         const std::vector<bool> &keepAxis) {
  nd::Shape s;
  for (size_t d = 0; d < sel.size(); d++)
    if (keepAxis[d])
      s.push_back(sel[d].size());
  return s;
}

nd::Shape withoutOnes(const nd::Shape &s) {
  nd::Shape out;
  for (size_t d : s)
    if (d != 1)
      out.push_back(d);
  return out;
}

} // namespace

bool ndIndexGet(const Value &v, const std::vector<MatIndexKey> &keys, const std::string &name,
                Value &out, std::string &err) {
  const nd::Shape &shape = v.ndShape();
  std::vector<std::vector<size_t>> sel;
  std::vector<bool> keep;
  if (!ndSelect(shape, keys, false, name, sel, keep, err))
    return false;

  bool allScalar = keys.size() == shape.size();
  for (const MatIndexKey &k : keys)
    allScalar = allScalar && k.kind == MatIndexKey::Scalar;
  if (allScalar) {
    std::vector<size_t> idx;
    for (const auto &s : sel)
      idx.push_back(s[0]);
    out = v.ndAt(nd::storageIndex(shape, idx));
    return true;
  }

  const nd::Shape result = selectionShape(sel, keep);
  const size_t count = nd::countOf(result);
  if (count == 0) {
    out = Value(Grid{});
    return true;
  }
  // Walk the selection in row-major order of the ORIGINAL axes, which is
  // the row-major order of the result too (dropped axes have one position).
  nd::Shape selShape;
  for (const auto &s : sel)
    selShape.push_back(s.size());
  std::vector<Value> rowMajor;
  rowMajor.reserve(count);
  std::vector<size_t> pos(shape.size(), 0), idx(shape.size());
  do {
    for (size_t d = 0; d < shape.size(); d++)
      idx[d] = sel[d][pos[d]];
    rowMajor.push_back(v.ndAt(nd::storageIndex(shape, idx)));
  } while (nd::nextIndex(pos, selShape));
  out = nd::buildRowMajor(result, rowMajor);
  return true;
}

bool ndIndexSet(Value &target, bool exists, const std::vector<MatIndexKey> &keys,
                const Value &rhs, const std::string &name, std::string &err) {
  if (rhs.isDict || rhs.isObject || rhs.isFunctionRef) {
    err = "only numbers, text and matrices can be stored in a matrix";
    return false;
  }

  if (!exists) {
    // A new name: B[i,j,k] = v creates the smallest matrix that holds the
    // position, filled with zeros of v's type.
    nd::Shape shape;
    for (const MatIndexKey &k : keys) {
      double top = 0;
      if (k.kind == MatIndexKey::Scalar)
        top = k.scalar;
      else if (k.kind == MatIndexKey::Range && k.hasStop)
        top = std::max(k.stop, k.hasStart ? k.start : 0.0);
      else {
        err = "cannot create " + quoted(name) +
              " from an open range or ':' - give every axis a position, e.g. " +
              (name.empty() ? std::string("B") : name) + "[1,2,3] = 0";
        return false;
      }
      if (!std::isfinite(top) || top < 0 || top != std::floor(top)) {
        err = "cannot create " + quoted(name) + " - positions must be whole numbers >= 0";
        return false;
      }
      shape.push_back(static_cast<size_t>(top) + 1);
    }
    size_t count = 1;
    for (size_t d : shape) {
      if (count > kMaxElements / d) {
        err = "the new matrix " + quoted(name) + " would be too large";
        return false;
      }
      count *= d;
    }
    target = Value::ndFromCells(shape, std::vector<Value>(count, zeroLike(firstElement(rhs))));
    exists = true;
  } else if (!checkAssignKinds(target, exists, rhs, name, err)) {
    return false;
  }

  const nd::Shape shape = target.ndShape();
  std::vector<std::vector<size_t>> sel;
  std::vector<bool> keep;
  if (!ndSelect(shape, keys, false, name, sel, keep, err)) {
    if (err.find("out of range") != std::string::npos)
      err += " - an N-D matrix does not grow by assignment";
    return false;
  }

  const Value sample = target.ndCount() ? target.ndAt(0) : Value(0.0);
  const Value rhsFirst = firstElement(rhs);
  if (!sample.isText && !rhsFirst.isText && !sameUnit(sample, rhsFirst)) {
    err = quoted(name) + " holds values in " + unitWords(sample) + " - a value in " +
          unitWords(rhsFirst) + " cannot be stored in it (a matrix has one unit)";
    return false;
  }

  const nd::Shape selShapeFull = [&] {
    nd::Shape s;
    for (const auto &x : sel)
      s.push_back(x.size());
    return s;
  }();
  const size_t selCount = nd::countOf(selShapeFull);
  if (selCount == 0)
    return true;

  const bool rhsSingle = isSingle(rhs) || nd::countOf(nd::shapeOf(rhs)) == 1;
  std::vector<Value> values; // row-major, one per selected position
  if (!rhsSingle) {
    const nd::Shape rhsShape = nd::shapeOf(rhs);
    if (withoutOnes(rhsShape) != withoutOnes(selectionShape(sel, keep))) {
      err = "cannot assign a " + nd::shapeText(rhsShape) + " value to a " +
            nd::shapeText(selectionShape(sel, keep)) + " selection of " + quoted(name) +
            " - the sizes must match, or assign a single value";
      return false;
    }
    values = nd::rowMajorCells(rhs);
  }
  const Value single = rhsSingle ? firstElement(rhs) : Value();

  std::vector<size_t> pos(shape.size(), 0), idx(shape.size());
  size_t t = 0;
  do {
    for (size_t d = 0; d < shape.size(); d++)
      idx[d] = sel[d][pos[d]];
    target.ndSetAt(nd::storageIndex(shape, idx), rhsSingle ? single : values[t]);
    t++;
  } while (nd::nextIndex(pos, selShapeFull));

  if (rhsSingle && sameElementType(sample, single))
    return true;
  // Bring every element back to one type (numeric widening).
  if (target.isPacked() || target.isPackedComplex())
    return true;
  std::vector<Value> cells = nd::storageCells(target);
  if (!matUnifyCells(cells, err))
    return false;
  target = nd::build(shape, std::move(cells));
  return true;
}

/* ---- element-wise arithmetic ------------------------------------------- */

namespace {

// Every element of `v` (storage order) as a complex number, or false when
// one of them is text.
bool numericCells(const Value &v, std::vector<std::complex<double>> &out, bool &anyComplex) {
  out.clear();
  if (v.isND() && (v.isPacked() || v.isPackedComplex())) {
    const size_t n = v.ndCount();
    out.reserve(n);
    for (size_t k = 0; k < n; k++)
      out.push_back(v.ndCnumAt(k));
    anyComplex = anyComplex || v.isPackedComplex();
    return true;
  }
  for (const Value &c : nd::storageCells(v)) {
    if (c.isText || c.isDict || c.isObject || c.isFunctionRef || c.isArray || c.isMatrix)
      return false;
    out.emplace_back(c.number, c.isComplex ? c.imag : 0.0);
    anyComplex = anyComplex || (c.isComplex && c.imag != 0.0);
  }
  return true;
}

bool isScalarLike(const Value &v) {
  return isSingle(v) || nd::countOf(nd::shapeOf(v)) == 1;
}

// Builds the N-D result of an element-wise operation.
Value ndResult(const nd::Shape &shape, const std::vector<std::complex<double>> &z, bool complex,
               int16_t l, int16_t t, int16_t m) {
  std::vector<double> buf;
  if (complex) {
    buf.resize(2 * z.size());
    for (size_t k = 0; k < z.size(); k++) {
      buf[2 * k] = z[k].real() + 0.0;
      buf[2 * k + 1] = z[k].imag();
    }
  } else {
    buf.resize(z.size());
    for (size_t k = 0; k < z.size(); k++)
      buf[k] = z[k].real() + 0.0;
  }
  Value v = Value::ndPacked(shape, std::move(buf), complex, l, t, m);
  v.narrowIfReal();
  return v;
}

} // namespace

bool ndBinaryOp(const std::string &op, const Value &a, const Value &b, Value &out,
                std::string &err) {
  const bool aScalar = isScalarLike(a), bScalar = isScalarLike(b);
  const nd::Shape shape = a.isND() ? a.ndShape() : b.ndShape();
  const std::string sa = nd::shapeText(nd::shapeOf(a)), sb = nd::shapeText(nd::shapeOf(b));

  std::string eop = op;
  if (op == "*" || op == "/") {
    if (!(op == "*" ? (aScalar || bScalar) : bScalar)) {
      err = "'" + op + "' is the matrix " + (op == "*" ? "product" : "division") +
            ", defined for 2-D matrices - got " + sa + " and " + sb + ". For element-wise use " +
            op + ". (A" + op + ".B), or apply '" + op + "' to 2-D slabs such as B[0]";
      return false;
    }
    eop = op + ".";
  } else if (op == "^") {
    err = "'^' is the matrix power, defined for square 2-D matrices - for element-wise powers "
          "write A^.n";
    return false;
  }
  if (eop != "+" && eop != "-" && eop != "*." && eop != "/." && eop != "^." && eop != "%" &&
      eop != "//") {
    err = "'" + op + "' is not supported for N-D matrices";
    return false;
  }

  if (!aScalar && !bScalar && nd::shapeOf(a) != nd::shapeOf(b)) {
    err = "'" + op + "' needs two matrices of the same size (or one single value), got " + sa +
          " and " + sb;
    return false;
  }

  bool anyComplex = false;
  std::vector<std::complex<double>> x, y;
  if (!numericCells(a, x, anyComplex) || !numericCells(b, y, anyComplex)) {
    err = "'" + op + "': a matrix containing text cannot be used in arithmetic";
    return false;
  }
  const Value ua = firstElement(a), ub = firstElement(b);
  int16_t l = 0, t = 0, m = 0;
  if (eop == "+" || eop == "-" || eop == "%" || eop == "//") {
    if (!sameUnit(ua, ub)) {
      err = "incompatible units in '" + op + "'";
      return false;
    }
    if (eop == "+" || eop == "-" || eop == "%") {
      l = ua.dimL;
      t = ua.dimT;
      m = ua.dimM;
    }
  } else if (eop == "*.") {
    l = ua.dimL + ub.dimL;
    t = ua.dimT + ub.dimT;
    m = ua.dimM + ub.dimM;
  } else if (eop == "/.") {
    l = ua.dimL - ub.dimL;
    t = ua.dimT - ub.dimT;
    m = ua.dimM - ub.dimM;
  } else { // ^.
    if (ub.dimL || ub.dimT || ub.dimM || ua.dimL || ua.dimT || ua.dimM) {
      err = "'^.' on an N-D matrix needs values without units";
      return false;
    }
  }

  const size_t n = nd::countOf(shape);
  std::vector<std::complex<double>> z(n);
  bool resultComplex = anyComplex;
  for (size_t k = 0; k < n; k++) {
    const std::complex<double> p = aScalar ? x[0] : x[k];
    const std::complex<double> q = bScalar ? y[0] : y[k];
    if (eop == "+")
      z[k] = p + q;
    else if (eop == "-")
      z[k] = p - q;
    else if (eop == "*.")
      z[k] = p * q;
    else if (eop == "/.")
      z[k] = anyComplex ? p / q : std::complex<double>(p.real() / q.real(), 0.0);
    else {
      // ^., % and // go through the scalar operators, so every element
      // gets exactly the answer the same scalar expression gives.
      const Value pv = p.imag() != 0.0 ? Value::complexNumber(p.real(), p.imag()) : Value(p.real());
      const Value qv = q.imag() != 0.0 ? Value::complexNumber(q.real(), q.imag()) : Value(q.real());
      Value r = eop == "^." ? power(pv, qv) : eop == "%" ? mod_op(pv, qv) : floor_div(pv, qv);
      z[k] = std::complex<double>(r.number, r.isComplex ? r.imag : 0.0);
      if (r.isComplex && r.imag != 0.0)
        resultComplex = true;
    }
  }
  out = ndResult(shape, z, resultComplex, l, t, m);
  return true;
}

bool ndNegate(const Value &a, Value &out, std::string &err) {
  bool anyComplex = false;
  std::vector<std::complex<double>> x;
  if (!numericCells(a, x, anyComplex)) {
    err = "'-': a matrix containing text cannot be negated";
    return false;
  }
  for (auto &z : x)
    z = -z;
  const Value u = firstElement(a);
  out = ndResult(a.ndShape(), x, anyComplex, u.dimL, u.dimT, u.dimM);
  return true;
}

bool ndCompare(const std::string &op, const Value &a, const Value &b, Value &out,
               std::string &err) {
  if (op != "==" && op != "!=" && op != "<" && op != ">" && op != "<=" && op != ">=") {
    err = "'" + op + "' is not supported for N-D matrices";
    return false;
  }
  const bool aScalar = isScalarLike(a), bScalar = isScalarLike(b);
  const nd::Shape sa = nd::shapeOf(a), sb = nd::shapeOf(b);
  const bool ordering = op != "==" && op != "!=";

  // Two matrices: one true/false (same as for 2-D matrices) - are they
  // equal, or does every element pair satisfy the comparison?
  const bool whole = !aScalar && !bScalar;
  if (whole && sa != sb) {
    if (ordering) {
      err = "'" + op + "' needs two matrices of the same size, got " + nd::shapeText(sa) +
            " and " + nd::shapeText(sb);
      return false;
    }
    out = Value::boolean(op == "!=");
    return true;
  }

  const std::vector<Value> x = nd::storageCells(a), y = nd::storageCells(b);
  const size_t n = whole ? x.size() : std::max(x.size(), y.size());
  std::vector<Value> results;
  results.reserve(n);
  bool all = true, any = false;
  for (size_t k = 0; k < n; k++) {
    const Value &p = aScalar ? x[0] : x[k];
    const Value &q = bScalar ? y[0] : y[k];
    bool r;
    if (p.isText || q.isText) {
      if (p.isText != q.isText) {
        if (ordering) {
          err = "cannot order-compare text with a number";
          return false;
        }
        r = op == "!=";
      } else {
        const int c = p.text().compare(q.text());
        r = op == "==" ? c == 0 : op == "!=" ? c != 0 : op == "<" ? c < 0 : op == ">" ? c > 0
            : op == "<=" ? c <= 0 : c >= 0;
      }
    } else {
      if (!sameUnit(p, q)) {
        err = "incompatible units in comparison";
        return false;
      }
      if (ordering && (p.isComplex || q.isComplex)) {
        err = "cannot order-compare complex numbers";
        return false;
      }
      const std::complex<double> u(p.number, p.isComplex ? p.imag : 0.0);
      const std::complex<double> v(q.number, q.isComplex ? q.imag : 0.0);
      r = op == "==" ? u == v : op == "!=" ? u != v : op == "<" ? u.real() < v.real()
          : op == ">" ? u.real() > v.real() : op == "<=" ? u.real() <= v.real()
                                                          : u.real() >= v.real();
    }
    all = all && r;
    any = any || r;
    results.push_back(Value::boolean(r));
  }
  if (whole) {
    // "!=" of two matrices: true when ANY pair differs; every other
    // comparison: true when EVERY pair satisfies it.
    out = Value::boolean(op == "!=" ? any : all);
    return true;
  }
  out = nd::build(aScalar ? sb : sa, std::move(results));
  return true;
}

/* ---- builtins ---------------------------------------------------------- */

bool ndBuiltinAllowed(const std::string &name) {
  std::string key = name;
  for (char &ch : key)
    ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
  // max/min (R3): max(A) and max(A, axis=k) work on N-D values; the
  // two-value max(A, B) refuses N-D itself (statistics_builtin.cpp).
  // tensorinv/tensorsolve (R5) are N-D by definition.
  // size/numel/length (collections_builtin.cpp) read only the shape.
  // concat ... hsplit (Numpy/combining_splitting/) join and cut along any
  // axis of an N-D matrix.
  // Data I/O (Numpy/importing_data/): every read_* / load_* / save_* / io_*
  // function and every loaded-object method ("NcImage.view") takes N-D data
  // - images (H,W,C), video (T,H,W,C), HDF5 / NetCDF tensors. (2026-10-28)
  if (key.rfind("save_", 0) == 0 || key.rfind("read_", 0) == 0 || key.rfind("load_", 0) == 0 ||
      key.rfind("io_", 0) == 0 || key.find('.') != std::string::npos)
    return true;
  static const char *const allowed[] = {
      "zeros",     "ones",         "reshape",     "shape",       "ndims",  "deal",
      "max",       "min",          "tensorinv",   "tensorsolve", "size",   "numel",
      "length",    "concat",       "stack",       "row_stack",   "vstack", "column_stack",
      "hstack",    "matrix_split", "vsplit",      "hsplit",
      // Numpy/adding_removing_elements/: any rank (trim_zeros is vectors only)
      "insert",    "repeat",       "pad",         "unique",      "put",    "replace_if",
      "fill_diagonal", "nan_to_num",
      // Numpy/copying_sorting_reshaping/
      "sort_asc",  "sort_desc",    "sort_complex", "flatten",    "flip",   "fliplr",
      "flipud",    "rot90",        "roll",
      // Numpy/creating_arrays/
      "check_finite", "zeros_like", "ones_like",  "shuffle",    "permutation", "rand_choice",
      // Numpy/indexing_slicing/
      "take",      "where",        "nonzero",     "choose",      "compress", "extract",
      // Numpy/inspecting_properties/
      "ndim",      "is_scalar",    "type",        "is_type",     "can_cast", "is_complex_each",
      "is_real_each",
      // Numpy/statistics/ (reductions along any axis)
      "average",   "prod",         "argmin",      "argmax",      "count_nonzero", "all",
      "any",       "cumsum",       "cumprod",     "cumulative_sum", "cumulative_prod",
      "nan_mean",  "nan_median",   "nan_sum",     "nan_prod",    "nan_min",  "nan_max",
      "nan_argmin", "nan_argmax",  "nan_var",     "nan_sd",      "nan_percentile",
      "nan_quantile", "nan_cumsum", "nan_cumprod", "gradient",   "trapz",
      // Numpy/working_with_data/ (element by element)
      "is_nan_each", "is_inf",     "is_finite",   "is_posinf",   "is_neginf", "unique_all",
      "fill_nan",  "str_concat",   "strip",       "find_str",    "count_str", "starts_with",
      "ends_with", "center",       "zfill",       "is_digit",    "str_len",   "join"};
  for (const char *a : allowed)
    if (key == a)
      return true;
  return key.rfind("nexus", 0) == 0;
}

bool ndBuiltinGuard(const std::string &name, const std::vector<Value> &args, std::string &err) {
  for (const Value &a : args) {
    if (a.isND() && !ndBuiltinAllowed(name)) {
      err = "'" + name + "' works on 2-D matrices, and this argument is " + matShapeText(a) +
            " - apply it to a 2-D slab such as B[0] (N-D support for more functions is coming)";
      return false;
    }
  }
  return true;
}

Value ndShapeValue(const Value &v) {
  std::vector<Value> dims;
  for (size_t d : nd::shapeOf(v))
    dims.push_back(Value(static_cast<double>(d)));
  return matArrayAsMatrix(Value(dims), false);
}

bool ndReshape(const Value &v, const Value &shapeArg, Value &out, std::string &err) {
  if (v.isText || v.isDict || v.isObject || v.isFunctionRef) {
    err = "reshape expects a matrix as its first argument";
    return false;
  }
  if (shapeArg.isND() || !(shapeArg.isMatrix || shapeArg.isArray)) {
    err = "reshape expects the new shape as a vector, e.g. reshape(A, [2,3,4])";
    return false;
  }
  const Value list = matVectorAsArray(shapeArg);
  const size_t total = nd::countOf(nd::shapeOf(v));
  nd::Shape shape;
  int inferAt = -1;
  size_t known = 1;
  for (size_t i = 0; list.isArray && i < list.length(); i++) {
    const Value d = list.at(i);
    if (d.isText || d.isComplex || !std::isfinite(d.number) || d.number != std::floor(d.number) ||
        d.number < -1) {
      err = "reshape: every size must be a whole number >= 0 (or -1 once, to be worked out)";
      return false;
    }
    if (d.number == -1) {
      if (inferAt >= 0) {
        err = "reshape: only one size can be -1";
        return false;
      }
      inferAt = static_cast<int>(i);
      shape.push_back(1);
      continue;
    }
    shape.push_back(static_cast<size_t>(d.number));
    known *= shape.back();
  }
  if (shape.empty()) {
    err = "reshape expects the new shape as a vector, e.g. reshape(A, [2,3,4])";
    return false;
  }
  if (inferAt >= 0) {
    if (known == 0 || total % known != 0) {
      err = "reshape: " + std::to_string(total) + " elements cannot be shaped as " +
            nd::shapeText(shape) + " with -1 filled in";
      return false;
    }
    shape[static_cast<size_t>(inferAt)] = total / known;
  }
  if (nd::countOf(shape) != total) {
    err = "reshape: a " + nd::shapeText(nd::shapeOf(v)) + " matrix has " + std::to_string(total) +
          " elements, but " + nd::shapeText(shape) + " needs " +
          std::to_string(nd::countOf(shape));
    return false;
  }
  // Elements are taken and placed in row-major order (the last index
  // fastest), so reshape([1:6], [2,3]) is [1,2,3;4,5,6].
  out = nd::buildRowMajor(shape, nd::rowMajorCells(v));
  return true;
}
