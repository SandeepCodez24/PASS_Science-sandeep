#pragma once

#include <string>
#include <vector>

#include "value.h"

// Print a Value to stdout. Implemented in output.cpp.
//
// With a name, the value is shown MATLAB "format loose" style:
//
//   (blank line)            <- only before the first block of a statement
//   name =
//   (blank line)
//       value / grid rows   <- indented 4 spaces
//   (blank line)
//
// Without a name, the bare value is printed on its own line.
void printValue(const std::string &name, const Value &v);

// A block of already-formatted text (each line indented by the caller),
// shown with the same spacing as a named printValue() block:
//   (blank line)   <- only before the first block of a statement
//   title =
//   (blank line)
//   text
//   (blank line)
// Used for ClassName.info's table.
void printDisplayBlock(const std::string &title, const std::string &text);

// Start a fresh display group: the next named printValue() opens with a
// blank line again. Called by the REPL before every statement and after any
// plain output (publish/print) so a block is always separated from text
// above it by exactly one blank line.
void resetDisplaySpacing();

// Renders a Value the same way printValue() would (number/array/matrix/dict
// formatting), but as a plain string with no trailing newline and no "name ="
// prefix. Text values are rendered unquoted (matches printValue's isText
// branch), not the quoted form print()/publish() uses for text arguments.
//
// A matrix renders as the MATLAB-style grid (one line per row, columns
// right-aligned, no brackets) at the top level, and in the compact
// declaration notation [1,2;3,4] when it sits inside an array, dict or
// object.
std::string valueToString(const Value &v);

// Same, but a matrix is always the one-line notation [1,2;3,4] - for str()
// and anywhere text must stay on one line.
std::string valueToCompactString(const Value &v);

// The two matrix forms on their own (v must be a matrix).
//
// matrixGrid() is the MATLAB-style grid. A matrix too wide for one line of
// the Command Window (see displayWidth()) is shown in groups of columns,
// each under a header, as MATLAB does:
//
//     Columns 0 through 12
//
//        1     0     0  ...
//
//     Columns 13 through 25
//     ...
//
// (0-based column numbers, the way NC indexes.) An N-D matrix is shown page
// by page, each 2-D page under "[0,:,:] =", "[1,:,:] =" ...
//
// matrixCompact() is the one-line declaration notation [1,2;3,4]; an N-D
// matrix uses its separators, [1,2;3,4 ;; 5,6;7,8] written without the
// spaces, so the text can be pasted back as code.
std::string matrixGrid(const Value &v);
std::string matrixCompact(const Value &v);

// The paged grid of an N-D matrix, each page labelled name[i,:,:].
std::string matrixGridND(const Value &v, const std::string &name);

// Characters per line of the Command Window, used to split wide matrices
// into column groups. Starts at the NC_DISPLAY_WIDTH environment variable
// (when the IDE sets it) or 80. The IDE should send its real width whenever
// the Command Window is resized - see setDisplayWidth().
size_t displayWidth();

// Sets the width (values below 20 count as 20; 0 goes back to the default).
void setDisplayWidth(size_t chars);

std::string formatNumber(double value);

// Decimals shown for a number that is not whole (default 6, range 0..15).
// Set by the precision(n) builtin; grids still show at most 4.
int displayDecimals();
void setDisplayDecimals(int decimals);
// A complex number as "3+4i" / "3-4i", each part formatted by formatNumber().
std::string formatComplex(double re, double im);
