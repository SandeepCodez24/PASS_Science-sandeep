#pragma once

#include <cctype>
#include <istream>
#include <string>

// Joins a raw source/input line with however many following lines are
// chained onto it via a trailing "~~" line-continuation marker. Leading
// whitespace on each continuation line is stripped before joining.
//
// `linesJoined` (optional) receives how many extra physical lines were
// merged in. A caller building a whole file from logical lines must add
// that many line breaks after the merged line (see SM_stage_02.cpp), or
// every line number after a '~~' split - error messages, the editor's
// error markers, Step's @STEPAT - shifts up by one per joined line.
//
// The marker works anywhere a line can be broken: a long expression, a
// function or class header (function y = f(a=1, ~~ / b=2):), a call's
// argument list, named values included (f(x1=10, ~~ / x2=15)), and a string
// ("a long ~~ / message"). A '~~' inside a comment is part of the comment
// and does NOT continue: `# note ~~` used to swallow the next line into the
// comment, so that line silently never ran (2026-10-28). The IDE strips
// comments before it runs a file, so this also makes running a file
// directly behave like running it from the IDE, and like the editor's
// checker reads it (SourceModel.java).
namespace nc_continuation {

// True when the end of `text` lies inside a comment: after a '#' or '\\' that
// is not in a string, or anywhere on a line that starts with '%' (the lexer's
// comment forms, lexer.cpp). Strings are tracked with the lexer's rules:
// "..." and '...', a backslash escaping the quote, and a ' right after a
// value (A', x') being the transpose operator rather than a string.
inline bool endsInComment(const std::string &text) {
  const size_t first = text.find_first_not_of(" \t");
  if (first != std::string::npos && text[first] == '%')
    return true;
  char quote = 0;
  for (size_t i = 0; i < text.size(); i++) {
    const char c = text[i];
    if (quote != 0) {
      if (c == '\\' && i + 1 < text.size()) {
        const char e = text[i + 1];
        if (e == '"' || e == '\'' || e == '\\' || e == 'n' || e == 't' || e == 'r')
          i++; // an escape: the next character is part of it
        continue;
      }
      if (c == quote)
        quote = 0;
      continue;
    }
    if (c == '#' || (c == '\\' && i + 1 < text.size() && text[i + 1] == '\\'))
      return true;
    if (c == '"') {
      quote = c;
    } else if (c == '\'') {
      const unsigned char prev = i > 0 ? static_cast<unsigned char>(text[i - 1]) : ' ';
      const bool afterValue = std::isalnum(prev) || prev == '_' || prev == ')' || prev == ']' ||
                              prev == '\'' || prev >= 0x80;
      if (!afterValue)
        quote = c; // otherwise: the transpose operator
    }
  }
  return false;
}

} // namespace nc_continuation

inline std::string readLogicalLine(std::istream &in, std::string firstLine,
                                   size_t *linesJoined = nullptr) {
  auto rtrim = [](const std::string &s) -> std::string {
    size_t e = s.find_last_not_of(" \t\r\n");
    return (e == std::string::npos) ? std::string() : s.substr(0, e + 1);
  };
  auto ltrim = [](const std::string &s) -> std::string {
    size_t b = s.find_first_not_of(" \t\r\n");
    return (b == std::string::npos) ? std::string() : s.substr(b);
  };

  std::string line = firstLine;
  std::string trimmed = rtrim(line);
  if (linesJoined)
    *linesJoined = 0;

  while (trimmed.size() >= 2 && trimmed.substr(trimmed.size() - 2) == "~~" &&
         !nc_continuation::endsInComment(trimmed)) {
    line = rtrim(trimmed.substr(0, trimmed.size() - 2));

    std::string nextLine;
    if (!std::getline(in, nextLine))
      break;

    line += " " + ltrim(nextLine);
    if (linesJoined)
      ++*linesJoined;
    trimmed = rtrim(line);
  }

  return line;
}
