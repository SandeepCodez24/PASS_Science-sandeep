#pragma once
// runtime/interpreter/core/arg_binding.h
//
// THE rule for matching a call's values to a function's inputs. One copy,
// used by both sides of the language:
//   - functions and classes written in NC   (compiler parser_args.cpp,
//                                             Parser::planBinding)
//   - built-in functions with named inputs  (builtins/builtins.cpp,
//                                             Numpy/numpy_main.cpp)
// so `F(A2=10, A4=15, 1, 2, 3)` and `allclose(A, B, atol=0.2)` follow
// exactly the same steps and report the same messages.
//
// A call gives values, each plain (`f(1, 2)`) or named (`f(b=2, 1)`):
//   1. every named value goes to the input of that name;
//   2. the plain values, in the order written, fill the inputs that are
//      still open, left to right - wherever in the call they appear;
//   3. an input still open then takes its default. A Required input left
//      open is an error; an Optional input (built-ins only) may simply be
//      left out.
// Errors: a name with no such input, the same input named twice, more plain
// values than open inputs, a Required input left open.
//
// Header-only and dependent on nothing but the standard library.

#include <cstddef>
#include <string>
#include <vector>

namespace ncargs {

enum class ParamKind {
  Required,  // must be given
  Defaulted, // has a default value, used when left open
  Optional,  // built-ins only: may be left out; the function then behaves
             // as it always has without it (e.g. gcd(A) vs gcd(A, B))
};

struct Param {
  std::string name;
  ParamKind kind = ParamKind::Required;
};

struct Binding {
  // Per input: the index of the call value it takes, or -1 when it was left
  // open (Defaulted: use the default; Optional: left out).
  std::vector<int> sourceOf;
  size_t defaultsUsed = 0; // Defaulted inputs left open (for overload choice)
};

inline std::string inputList(const std::vector<Param> &params) {
  std::string out;
  for (size_t i = 0; i < params.size(); i++) {
    if (i > 0)
      out += ", ";
    out += params[i].name;
  }
  return out;
}

inline std::string countOf(size_t n, const char *word) {
  return std::to_string(n) + " " + word + (n == 1 ? "" : "s");
}

// Matches `argCount` call values, named by `argNames` (empty = all plain;
// otherwise one entry per value, "" for a plain one), to `params`. False
// with `why` set (a sentence without "Error:") when the call does not fit.
inline bool bind(const std::vector<Param> &params, size_t argCount,
                 const std::vector<std::string> &argNames, Binding &out, std::string &why) {
  const size_t n = params.size();
  out.sourceOf.assign(n, -1);
  out.defaultsUsed = 0;
  std::vector<bool> filled(n, false);
  const bool named = !argNames.empty();

  // Pass 1: every named value goes to the input of that name.
  size_t plainCount = 0;
  for (size_t a = 0; a < argCount; a++) {
    const std::string &argName = named ? argNames[a] : std::string();
    if (argName.empty()) {
      plainCount++;
      continue;
    }
    size_t j = 0;
    while (j < n && params[j].name != argName)
      j++;
    if (j == n) {
      why = n == 0 ? "there is no input named '" + argName + "' - it takes no inputs"
                   : "there is no input named '" + argName + "' - its inputs are " +
                         inputList(params);
      return false;
    }
    if (filled[j]) {
      why = "input '" + argName + "' is given more than once";
      return false;
    }
    filled[j] = true;
    out.sourceOf[j] = static_cast<int>(a);
  }

  // Pass 2: the plain values, in the order written, fill the inputs that
  // are still open, left to right.
  size_t open = 0;
  for (size_t j = 0; j < n; j++)
    open += filled[j] ? 0 : 1;
  if (plainCount > open) {
    const size_t namedCount = argCount - plainCount;
    if (namedCount == 0)
      why = "it takes " + countOf(n, "input") + ", but " + std::to_string(argCount) +
            (argCount == 1 ? " value was" : " values were") + " given";
    else
      why = "it takes " + countOf(n, "input") + "; " + std::to_string(namedCount) +
            (namedCount == 1 ? " is" : " are") + " given by name, which leaves " +
            std::to_string(open) + " for " + std::to_string(plainCount) + " plain " +
            (plainCount == 1 ? "value" : "values");
    return false;
  }
  size_t j = 0;
  for (size_t a = 0; a < argCount; a++) {
    if (named && !argNames[a].empty())
      continue;
    while (filled[j])
      j++;
    filled[j] = true;
    out.sourceOf[j] = static_cast<int>(a);
  }

  // Pass 3: whatever is still open takes its default, or is left out.
  for (size_t k = 0; k < n; k++) {
    if (filled[k])
      continue;
    if (params[k].kind == ParamKind::Required) {
      why = "input '" + params[k].name + "' was not given and has no default value";
      return false;
    }
    if (params[k].kind == ParamKind::Defaulted)
      out.defaultsUsed++;
  }
  return true;
}

} // namespace ncargs
