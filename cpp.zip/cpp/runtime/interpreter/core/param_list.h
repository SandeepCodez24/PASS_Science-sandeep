#pragma once
// runtime/interpreter/core/param_list.h
//
// The inputs of a BUILT-IN function, written once as one line of text, e.g.
//
//     "A, B, atol=0.1, rtol=0"     allclose
//     "A, B?"                      gcd       (B may be left out)
//     "p, m=1"                     polyder
//
//   name          the input must be given
//   name=value    the input has a default; value is a number (inf, -inf,
//                 nan, pi allowed), true / false, or "text"
//   name?         the input may be left out; the function then behaves as
//                 it does without it (gcd(A) reduces A, gcd(A, B) pairs)
//   *name         any number of values (at least one), given in order -
//                 "*A, axis=0" for concat(A, B, C, axis=1). At most one per
//                 line; inputs before it are plain `name`s, inputs after it
//                 must have a default and can only be given by name. The
//                 function then gets the values of *name first, followed by
//                 the inputs after it (so axis is always last). (2026-10-28)
//
// From that one line come: which named values a call may use, the default
// filled in for an input left out, and the usage text shown in errors and
// in the IDE ("allclose(A, B, atol=0.1, rtol=0)"). Used by the NumPy
// registry (Numpy/numpy_registry.cpp) and by the core builtins
// (builtins/builtins.cpp). The matching rule is core/arg_binding.h - the
// same one NC's own functions use.

#include <cctype>
#include <cmath>
#include <cstdlib>
#include <string>
#include <vector>

#include "arg_binding.h"
#include "value.h"

namespace ncargs {

struct ParamSpec {
  std::string name;
  ParamKind kind = ParamKind::Required;
  Value defaultValue;      // Defaulted only
  std::string defaultText; // Defaulted only, as written: "0.1", "\"full\""
  bool variadic = false;   // written `*name`: takes every remaining plain value
};

// Index of the `*name` input, or -1.
inline int variadicIndex(const std::vector<ParamSpec> &params) {
  for (size_t i = 0; i < params.size(); i++)
    if (params[i].variadic)
      return static_cast<int>(i);
  return -1;
}

namespace detail {

inline std::string trim(const std::string &s) {
  const size_t b = s.find_first_not_of(" \t");
  if (b == std::string::npos)
    return "";
  const size_t e = s.find_last_not_of(" \t");
  return s.substr(b, e - b + 1);
}

inline bool isNameText(const std::string &s) {
  if (s.empty() || !(std::isalpha(static_cast<unsigned char>(s[0])) || s[0] == '_'))
    return false;
  for (char c : s)
    if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_'))
      return false;
  return true;
}

// A default as written in a parameter line -> its Value.
inline bool parseLiteral(const std::string &text, Value &out) {
  if (text.size() >= 2 && text.front() == '"' && text.back() == '"') {
    out = Value(text.substr(1, text.size() - 2));
    return true;
  }
  if (text == "true" || text == "false") {
    out = Value::boolean(text == "true");
    return true;
  }
  if (text == "pi" || text == "-pi") {
    out = Value(text == "pi" ? 3.14159265358979323846 : -3.14159265358979323846);
    return true;
  }
  if (text == "inf" || text == "-inf" || text == "nan") {
    out = Value(text == "nan" ? std::nan("") : (text == "inf" ? HUGE_VAL : -HUGE_VAL));
    return true;
  }
  char *end = nullptr;
  const double d = std::strtod(text.c_str(), &end);
  if (end == text.c_str() || *end != '\0')
    return false;
  out = Value(d);
  return true;
}

} // namespace detail

// Parses a parameter line. False with `err` set when it is malformed - a
// mistake in a registration table, reported at start-up.
inline bool parseParamList(const std::string &line, std::vector<ParamSpec> &out,
                           std::string &err) {
  out.clear();
  if (detail::trim(line).empty())
    return true;
  size_t start = 0;
  while (start <= line.size()) {
    size_t comma = line.find(',', start);
    // A comma inside a quoted default does not end the parameter.
    size_t q = line.find('"', start);
    if (q != std::string::npos && q < comma) {
      size_t q2 = line.find('"', q + 1);
      comma = line.find(',', q2 == std::string::npos ? line.size() : q2);
    }
    if (comma == std::string::npos)
      comma = line.size();
    const std::string part = detail::trim(line.substr(start, comma - start));
    ParamSpec p;
    const size_t eq = part.find('=');
    if (eq != std::string::npos) {
      p.name = detail::trim(part.substr(0, eq));
      p.defaultText = detail::trim(part.substr(eq + 1));
      p.kind = ParamKind::Defaulted;
      if (!detail::parseLiteral(p.defaultText, p.defaultValue)) {
        err = "default '" + p.defaultText + "' of input '" + p.name + "' is not a value";
        return false;
      }
    } else if (!part.empty() && part.back() == '?') {
      p.name = detail::trim(part.substr(0, part.size() - 1));
      p.kind = ParamKind::Optional;
    } else if (!part.empty() && part.front() == '*') {
      p.name = detail::trim(part.substr(1));
      p.variadic = true;
      if (variadicIndex(out) >= 0) {
        err = "only one *input is allowed";
        return false;
      }
      for (const ParamSpec &before : out)
        if (before.kind != ParamKind::Required) {
          err = "inputs before *" + p.name + " must be plain names";
          return false;
        }
    } else {
      p.name = part;
    }
    if (variadicIndex(out) >= 0 && p.kind != ParamKind::Defaulted) {
      err = "input '" + p.name + "' after the *input needs a default (it can only be named)";
      return false;
    }
    if (!detail::isNameText(p.name)) {
      err = "'" + part + "' is not an input name";
      return false;
    }
    for (const ParamSpec &seen : out)
      if (seen.name == p.name) {
        err = "input '" + p.name + "' is listed twice";
        return false;
      }
    out.push_back(std::move(p));
    start = comma + 1;
    if (comma == line.size())
      break;
  }
  return true;
}

// "allclose(A, B, atol=0.1, rtol=0)", "gcd(A[, B])".
inline std::string paramSignature(const std::string &name, const std::vector<ParamSpec> &params) {
  std::string out = name + "(";
  bool first = true;
  int openBrackets = 0;
  for (const ParamSpec &p : params) {
    if (p.kind == ParamKind::Optional) {
      out += first ? "[" : "[, ";
      openBrackets++;
    } else if (!first) {
      out += ", ";
    }
    if (p.variadic) { // "A1, A2, ..."
      out += p.name + "1, " + p.name + "2, ...";
      first = false;
      continue;
    }
    out += p.name;
    if (p.kind == ParamKind::Defaulted)
      out += "=" + p.defaultText;
    first = false;
  }
  out += std::string(static_cast<size_t>(openBrackets), ']');
  return out + ")";
}

// Matches a call to `params` (core/arg_binding.h) and rewrites it as the
// plain list of values the function's code reads by position:
//   - each input in declaration order;
//   - a Defaulted input left open gets its default;
//   - Optional inputs left open at the END are dropped, so the function sees
//     the shorter call it has always handled (gcd(A) stays one value).
// An Optional input left open BEFORE a given one cannot be dropped without
// shifting the others, so that is an error naming it.
// Plain-only calls go through here too, so a default is written in exactly
// one place: the parameter line.
// A line with a *name input: every plain value goes, in order, to the
// inputs before it and then to *name (at least one); the inputs after it
// are taken by name or get their default. Output: the plain values, then
// the inputs after *name in declaration order.
inline bool normalizeVariadicCall(const std::vector<ParamSpec> &params, int vIndex,
                                  const std::vector<Value> &args,
                                  const std::vector<std::string> &argNames,
                                  std::vector<Value> &out, std::string &why) {
  const size_t before = static_cast<size_t>(vIndex);
  std::vector<Value> plain;
  std::vector<int> fromName(params.size(), -1);
  bool sawNamed = false;
  for (size_t i = 0; i < args.size(); i++) {
    const std::string name = i < argNames.size() ? argNames[i] : "";
    if (name.empty()) {
      if (sawNamed) {
        why = "a value without a name cannot follow a named one";
        return false;
      }
      plain.push_back(args[i]);
      continue;
    }
    sawNamed = true;
    size_t k = before + 1;
    while (k < params.size() && params[k].name != name)
      k++;
    if (k == params.size()) {
      why = "there is no input named '" + name + "'";
      return false;
    }
    if (fromName[k] >= 0) {
      why = "input '" + name + "' is given twice";
      return false;
    }
    fromName[k] = static_cast<int>(i);
  }
  if (plain.size() < before + 1) {
    why = "at least " + std::to_string(before + 1) + " value(s) are needed";
    return false;
  }
  out = plain;
  for (size_t k = before + 1; k < params.size(); k++)
    out.push_back(fromName[k] >= 0 ? args[static_cast<size_t>(fromName[k])]
                                   : params[k].defaultValue);
  return true;
}

inline bool normalizeCall(const std::vector<ParamSpec> &params, const std::vector<Value> &args,
                          const std::vector<std::string> &argNames, std::vector<Value> &out,
                          std::string &why) {
  if (const int v = variadicIndex(params); v >= 0)
    return normalizeVariadicCall(params, v, args, argNames, out, why);
  std::vector<Param> plain;
  plain.reserve(params.size());
  for (const ParamSpec &p : params)
    plain.push_back({p.name, p.kind});
  Binding binding;
  if (!ncargs::bind(plain, args.size(), argNames, binding, why))
    return false;

  out.clear();
  std::vector<bool> present;
  for (size_t i = 0; i < params.size(); i++) {
    const int src = binding.sourceOf[i];
    if (src >= 0) {
      out.push_back(args[static_cast<size_t>(src)]);
      present.push_back(true);
    } else if (params[i].kind == ParamKind::Defaulted) {
      out.push_back(params[i].defaultValue);
      present.push_back(true);
    } else { // Optional, left out
      out.push_back(Value());
      present.push_back(false);
    }
  }
  while (!present.empty() && !present.back()) {
    present.pop_back();
    out.pop_back();
  }
  for (size_t i = 0; i < present.size(); i++) {
    if (!present[i]) {
      std::string later;
      for (size_t k = i + 1; k < present.size(); k++)
        if (present[k]) {
          later = params[k].name;
          break;
        }
      why = "input '" + params[i].name + "' must be given too when '" + later + "' is";
      return false;
    }
  }
  return true;
}

} // namespace ncargs
