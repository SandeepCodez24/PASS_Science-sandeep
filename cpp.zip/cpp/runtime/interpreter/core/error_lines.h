#pragma once

// Counts the error lines written to std::cerr.
//
// An error stops the script (Parser::errorAbort_), which needs to know that
// a statement failed. Most code says so through evaluationSucceeded_ or one
// of the per-domain flags (g_lastBuiltinFound, g_lastDcOk, ...), but some
// builtins only print their message and return 0 - and that 0 then flowed on
// into the rest of the script as if it were a real result. Every error
// message starts with "Error" or "✖" (a categorised "✖ Syntax Error ..."),
// so counting those lines catches every one of them: a statement or builtin
// call during which the count went up has failed, whatever flags it set.
//
// install() wraps std::cerr's buffer once, at start-up (main.cpp). Text still
// goes to the original buffer unchanged; only the count is added. Before
// install() is called, count() simply stays 0.

#include <iostream>
#include <streambuf>
#include <string>

namespace nc {
namespace errorlines {

class CountingBuf : public std::streambuf {
public:
  explicit CountingBuf(std::streambuf *dest) : dest_(dest) {}
  unsigned long count() const { return count_; }

protected:
  int overflow(int ch) override {
    if (ch == traits_type::eof())
      return traits_type::not_eof(ch);
    track(static_cast<char>(ch));
    return dest_->sputc(static_cast<char>(ch));
  }
  std::streamsize xsputn(const char *s, std::streamsize n) override {
    for (std::streamsize i = 0; i < n; i++)
      track(s[i]);
    return dest_->sputn(s, n);
  }
  int sync() override { return dest_->pubsync(); }

private:
  // Looks at the start of each line only: leading spaces skipped, then
  // "Error" or the UTF-8 bytes of "✖" (E2 9C 96).
  void track(char c) {
    if (c == '\n') {
      start_.clear();
      decided_ = false;
      return;
    }
    if (decided_)
      return;
    if (start_.empty() && (c == ' ' || c == '\t'))
      return;
    start_ += c;
    static const std::string kError = "Error";
    static const std::string kCross = "\xE2\x9C\x96";
    for (const std::string *word : {&kError, &kCross}) {
      if (start_.size() <= word->size() && word->compare(0, start_.size(), start_) == 0) {
        if (start_.size() == word->size()) {
          count_++;
          decided_ = true;
        }
        return; // still a possible match
      }
    }
    decided_ = true; // neither word: not an error line
  }

  std::streambuf *dest_;
  std::string start_;
  bool decided_ = false;
  unsigned long count_ = 0;
};

inline CountingBuf *&installed() {
  static CountingBuf *buf = nullptr;
  return buf;
}

// Wraps std::cerr (once; later calls do nothing).
inline void install() {
  if (installed())
    return;
  static CountingBuf buf(std::cerr.rdbuf());
  std::cerr.rdbuf(&buf);
  installed() = &buf;
}

// Error lines written so far (0 until install()).
inline unsigned long count() { return installed() ? installed()->count() : 0; }

} // namespace errorlines
} // namespace nc
