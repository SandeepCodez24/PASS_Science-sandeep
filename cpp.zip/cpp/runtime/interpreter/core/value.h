#pragma once
#include <complex>
#include <cstdint>
#include <limits>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

// Flat storage for an array or matrix whose elements are all plain numbers:
// one contiguous block of doubles instead of one whole Value per element.
// Column-major (first index varies fastest), the layout Eigen and LAPACK
// use, so a matrix can be handed to them without rearranging it.
//
// An N-dimensional matrix (rank 3 or more, shape [d0, ..., rows, cols]) is
// stored as a run of 2-D pages: each page is one rows x cols matrix in the
// same column-major layout, and the pages follow each other in row-major
// order of the leading indices (the last leading index varies fastest). So
// every page can still be handed to Eigen as it is, and A[m] - the slab
// along the first axis - is one contiguous block. See Value::isND().
struct NumTensor
{
    std::vector<double> buf;
    // {length} for an array, {rows, cols} for a matrix,
    // {d0, ..., d(n-3), rows, cols} for an N-dimensional matrix.
    std::vector<size_t> shape;

    // Complex tensor: each element takes two consecutive doubles in `buf`,
    // real part then imaginary part. That is the layout std::complex<double>
    // and Eigen's complex matrices use, so the buffer can be handed to them
    // as it is.
    bool complex = false;

    // Unit dimensions shared by every element (see Value::dimL/dimT/dimM).
    int16_t dimL = 0, dimT = 0, dimM = 0;
};

// Fixed-width integer types. float64 stays the language's default number;
// an integer only exists when the script asks for one (int(), int8(), ...).
// The numbering is internal to the interpreter - the .ndat format has its
// own type tags (runtime/data/DataSupport/NdatTypes.h).
enum class IntType : uint8_t
{
    None = 0,
    Int8,
    Int16,
    Int32,
    Int64,
    UInt8,
    UInt16,
    UInt32,
    UInt64
};

// Floating-point storage formats. float64 is the language's default number
// and needs no tag; the narrower formats are opt-in (float32(x), ...). Every
// value is still computed in double precision and then rounded to its
// format, so a tagged number always holds a value that format can represent
// exactly. float128 has a reserved .ndat tag but no runtime support yet.
enum class FloatType : uint8_t
{
    Float64 = 0, // the default - untagged
    Float8,      // OCP FP8 E4M3: 1 sign, 4 exponent, 3 mantissa bits; max 448, no infinity
    Float16,     // IEEE 754 binary16 (half)
    Float32      // IEEE 754 binary32 (single)
};

// Rounds `x` to the nearest value representable in format `t` (ties to
// even; overflow gives +/-Inf, or NaN for float8). Float64 returns `x`.
// Defined in ops/floating/floating.cpp.
double roundToFloatType(FloatType t, double x);

// One NC value. A plain number is just the 32 bytes below; everything else
// a value can be (text, an array or matrix, a dict, a class instance, a
// function reference) keeps its data in a separately allocated Box, so the
// common case of a number never pays for it.
struct Value
{
    // The value of a plain number. For an integer it is the nearest double
    // to the exact integer (exact up to 2^53), and for a bool it is 1 or 0,
    // so code that only understands doubles keeps reading a sensible
    // number from either.
    double number = 0;

    union
    {
        // Imaginary part, meaningful only while isComplex is set. A complex
        // value keeps its real part in `number`, so code that only
        // understands real numbers still reads the real part.
        double imag = 0;

        // Integer only: the exact value. Signed types keep it as int64,
        // unsigned types keep the uint64 bit pattern. Shares storage with
        // `imag` because a value is never both complex and an integer.
        int64_t i64_;
    };

  private:
    struct Box
    {
        std::string text;

        // An array/matrix lives in exactly one of two forms:
        //  - packed: `tensor` set, every element a plain number sharing one
        //    unit. This is the compact form, and copies of the Value share
        //    the buffer until one of them writes to it (ownTensor()).
        //  - cells: `array` / `matrix`, one whole Value per element. Used
        //    whenever the packed form can't represent the contents exactly
        //    (text, nested arrays, mixed units, rows of different lengths).
        // The constructors pick the packed form when it fits, and a write
        // that no longer fits switches that Value back to cells (unpack()).
        std::vector<Value> array;
        std::vector<std::vector<Value>> matrix;
        std::shared_ptr<NumTensor> tensor;

        // An N-dimensional matrix (rank >= 3) whose cells cannot be packed
        // (text, bools, integers, float32 ...): one Value per element, in
        // the same storage order as a packed N-D tensor (see NumTensor),
        // with its shape. Both empty for anything else.
        std::vector<Value> ndCells;
        std::vector<size_t> ndShape;

        // Dict entries, or a class instance's fields (an object's fields ARE
        // conceptually a name->Value map).
        std::unordered_map<std::string, Value> dict;

        // Class instance: which class this instance belongs to, so a method
        // call (obj.Method(...)) knows which class's method table to resolve
        // against. Object Values are only ever built internally by the
        // class-call machinery (parser_class.cpp), never as a
        // general-purpose public Value type the way dict/array/matrix are.
        std::string className;

        // First-class function reference (`@name` - see ast.h's FunctionRef
        // comment). Deliberately just a NAME, not a pointer/closure of any
        // kind: functions are already looked up by name in Parser::
        // functionTable_ at call time everywhere else in this codebase (the
        // same principle classes/methods use - see ClassDef's own comments),
        // so a reference only ever needs to remember which name to
        // re-resolve later, via feval(). This means a reference stays valid
        // even if the function it names is later redefined (feval()
        // re-resolves by name each call, not a captured snapshot) -
        // consistent with every other late-bound name lookup in this
        // language, and much simpler than a real closure (no captured
        // environment to manage, no lifetime issues if the referenced
        // function's defining scope has since exited).
        std::string funcRefName;

        // Traceability: an auto-maintained history of operations performed
        // on this instance — one entry appended on construction
        // ("init(...)") and one per instance method call
        // ("MethodName(args) -> result"), read via the reserved `.lineage()`
        // call (see parser_factor.cpp). Populated by callClassConstructor()/
        // callInstanceMethod() (parser_class.cpp), never by user code
        // directly.
        std::vector<std::string> lineage;

        // Reversibility (opt-in — `reversible class Name(...)`): one
        // field-state snapshot per lineage entry (same index
        // correspondence), only ever populated for instances of a class
        // marked reversible — a normal class's instances leave this
        // permanently empty, paying no snapshot cost. Read/restored via the
        // reserved `.rewind()` call (parser_factor.cpp), populated by
        // callClassConstructor()/callInstanceMethod() (parser_class.cpp)
        // right alongside `lineage`.
        std::vector<std::unordered_map<std::string, Value>> snapshots;

        // Temporal Determinism (opt-in via `@rate(...)` on the class — see
        // ClassDef::hasRate/rateHz): the simulated time this instance last
        // actually ran its step() method via `.tick(t)`. -1 means "never
        // ticked yet", so the first .tick() call always runs regardless of
        // the configured period.
        double lastTickTime = -1.0;

        // Nothing in here differs from a freshly made Box.
        bool isBlank() const
        {
            return text.empty() && array.empty() && matrix.empty() && !tensor && ndCells.empty() &&
                   ndShape.empty() && dict.empty() && className.empty() && funcRefName.empty() &&
                   lineage.empty() && snapshots.empty() && lastTickTime == -1.0;
        }
    };

    // Null until this Value needs something a plain number doesn't have.
    // Owned: copying a Value copies its Box.
    Box *box_ = nullptr;

  public:
    // One bit each, so that all of them plus the unit exponents below fit
    // in the 8 bytes left after number / imag / box_. Bit fields can't
    // carry a default here before C++20; the constructors clear them.
    bool isText : 1;
    bool isArray : 1;
    bool isMatrix : 1;
    bool isDict : 1;
    bool isObject : 1;      // class instance - see Box::className
    bool isFunctionRef : 1; // `@name` - see Box::funcRefName
    bool isComplex : 1;     // a complex number: number + imag*i

    // Raw scalar type tags - read them through isBool() / isInt(), which
    // also check that the tag still matches `number`. Older code that
    // copies a Value and then overwrites `.number` (unit-preserving math)
    // leaves the tag behind; the check makes such a value read back as the
    // plain float64 it has become instead of a stale bool/integer.
    bool boolTag_ : 1;
    uint8_t intTag_ : 4; // an IntType; 0 = not an integer
    uint8_t floatTag_ : 3; // a FloatType; 0 = plain float64

    // Dimensional Integrity: exponents over 3 base physical dimensions —
    // Length, Time, Mass (e.g. velocity is L^1 T^-1, force is L^1 M^1 T^-2).
    // All zero (the default) means unitless — every pre-existing numeric
    // Value in this codebase stays unitless and unaffected. Attached via
    // multiplying/dividing by a unit constant (m, s, kg, N, Pa — see
    // parser_factor.cpp's tryResolveUnitConstant()), not a dedicated
    // `<unit>` literal — that syntax from the design doc collides with the
    // existing `<`/`>` comparison tokens used throughout this whole
    // codebase, so it was deliberately not implemented as written; see the
    // memory notes for the full rationale.
    int16_t dimL = 0, dimT = 0, dimM = 0;

    /* copying / moving / destroying */

    // The imag/i64_ union is copied through i64_: its 8 bytes then travel
    // as an integer, so an integer's bit pattern is never pushed through a
    // floating-point register.
    Value(const Value &o)
        : number(o.number), i64_(o.i64_), box_(o.box_ ? new Box(*o.box_) : nullptr),
          isText(o.isText), isArray(o.isArray), isMatrix(o.isMatrix), isDict(o.isDict),
          isObject(o.isObject), isFunctionRef(o.isFunctionRef), isComplex(o.isComplex),
          boolTag_(o.boolTag_), intTag_(o.intTag_), floatTag_(o.floatTag_), dimL(o.dimL),
          dimT(o.dimT), dimM(o.dimM)
    {
    }

    Value(Value &&o) noexcept
        : number(o.number), i64_(o.i64_), box_(o.box_), isText(o.isText), isArray(o.isArray),
          isMatrix(o.isMatrix), isDict(o.isDict), isObject(o.isObject),
          isFunctionRef(o.isFunctionRef), isComplex(o.isComplex), boolTag_(o.boolTag_),
          intTag_(o.intTag_), floatTag_(o.floatTag_), dimL(o.dimL), dimT(o.dimT), dimM(o.dimM)
    {
        o.box_ = nullptr;
    }

    // Both assignments finish reading `o` before releasing this Value's old
    // Box: `o` may be an element living inside that Box (x = x.at(0)).
    Value &operator=(const Value &o)
    {
        if (this != &o) {
            Value copy(o);
            *this = std::move(copy);
        }
        return *this;
    }

    Value &operator=(Value &&o) noexcept
    {
        if (this != &o) {
            Box *old = box_;
            number = o.number;
            i64_ = o.i64_;
            isText = o.isText;
            isArray = o.isArray;
            isMatrix = o.isMatrix;
            isDict = o.isDict;
            isObject = o.isObject;
            isFunctionRef = o.isFunctionRef;
            isComplex = o.isComplex;
            boolTag_ = o.boolTag_;
            intTag_ = o.intTag_;
            floatTag_ = o.floatTag_;
            dimL = o.dimL;
            dimT = o.dimT;
            dimM = o.dimM;
            box_ = o.box_;
            o.box_ = nullptr;
            delete old;
        }
        return *this;
    }

    ~Value() { delete box_; }

    /* default */

    Value()
        : isText(false), isArray(false), isMatrix(false), isDict(false), isObject(false),
          isFunctionRef(false), isComplex(false), boolTag_(false), intTag_(0),
          floatTag_(0)
    {
    }

    /* number */

    Value(double n) : Value()
    {
        number = n;
        isText = false;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* complex number */

    static Value complexNumber(double re, double im)
    {
        Value v(re);
        v.imag = im;
        v.isComplex = true;
        return v;
    }

    /* bool */

    static Value boolean(bool b)
    {
        Value v(b ? 1.0 : 0.0);
        v.boolTag_ = true;
        return v;
    }

    /* fixed-width integers (the caller has range-checked the value) */

    static Value integerSigned(IntType t, int64_t n)
    {
        Value v(static_cast<double>(n));
        v.i64_ = n;
        v.intTag_ = static_cast<uint8_t>(t);
        return v;
    }

    static Value integerUnsigned(IntType t, uint64_t n)
    {
        Value v(static_cast<double>(n));
        v.i64_ = static_cast<int64_t>(n);
        v.intTag_ = static_cast<uint8_t>(t);
        return v;
    }

    /* narrower floating-point formats (the value must already be
       representable in `t` - see roundToFloatType()) */

    static Value floating(FloatType t, double n)
    {
        Value v(n);
        v.floatTag_ = static_cast<uint8_t>(t);
        return v;
    }

    /* date / time (ops/time/) - since 2026-10-28

       A timestamp is a point in time, a duration a length of time; both
       keep int64 nanoseconds in i64_ (a timestamp since 1970-01-01 00:00:00
       UTC). They borrow the integer tag field: tag values 9 and 10 are past
       every IntType, so no other code mistakes them for integers, and the
       Value stays 32 bytes. `number` is NaN, so any code that only reads
       doubles gets an obviously wrong result instead of a plausible one;
       callBuiltin() refuses time values for functions that do not know
       them. Like a bool or an integer, a time value never packs - a matrix
       of them uses the cell form. */

    static constexpr uint8_t kTimestampTag = 9;
    static constexpr uint8_t kDurationTag = 10;

    static Value timestamp(int64_t ns)
    {
        Value v(std::numeric_limits<double>::quiet_NaN());
        v.i64_ = ns;
        v.intTag_ = kTimestampTag;
        return v;
    }

    static Value duration(int64_t ns)
    {
        Value v(std::numeric_limits<double>::quiet_NaN());
        v.i64_ = ns;
        v.intTag_ = kDurationTag;
        return v;
    }

    // `number != number`: still NaN - code that copies a Value and then
    // overwrites `.number` leaves the tag behind (see isBool()), and such a
    // value reads back as the plain float64 it has become.
    bool isTimestamp() const { return intTag_ == kTimestampTag && isPlainScalar() && number != number; }
    bool isDuration() const { return intTag_ == kDurationTag && isPlainScalar() && number != number; }
    bool isTime() const { return isTimestamp() || isDuration(); }

    // Timestamp / duration only: the nanoseconds.
    int64_t timeNs() const { return i64_; }

    /* scalar type queries */

    // The storage format of a real number: Float64 (the default) unless the
    // value was made with float8/float16/float32 and still holds a value
    // that format represents exactly (see isBool() for why that is checked).
    FloatType floatType() const
    {
        if (floatTag_ == 0 || !isPlainScalar() || intTag_ != 0 || boolTag_)
            return FloatType::Float64;
        const FloatType t = static_cast<FloatType>(floatTag_);
        const double r = roundToFloatType(t, number);
        const bool same = (r == number) || (r != r && number != number); // NaN stays NaN
        return same ? t : FloatType::Float64;
    }

    // A real bool (true/false), not the float64 1/0.
    bool isBool() const
    {
        return boolTag_ && isPlainScalar() && (number == 0.0 || number == 1.0);
    }

    // A fixed-width integer (int8 ... uint64).
    bool isInt() const
    {
        if (intTag_ == 0 || intTag_ > static_cast<uint8_t>(IntType::UInt64) || !isPlainScalar())
            return false; // tags past UInt64 are the time types
        return intIsUnsigned() ? static_cast<double>(static_cast<uint64_t>(i64_)) == number
                               : static_cast<double>(i64_) == number;
    }

    // IntType::None unless isInt().
    IntType intType() const { return isInt() ? static_cast<IntType>(intTag_) : IntType::None; }

    // Integer only: whether intType() is one of the uint types.
    bool intIsUnsigned() const
    {
        return intTag_ >= static_cast<uint8_t>(IntType::UInt8) &&
               intTag_ <= static_cast<uint8_t>(IntType::UInt64);
    }

    // Integer only: the exact value (unsigned types: reinterpret as uint64).
    int64_t intBits() const { return i64_; }

    // Integer only: the exact value as decimal digits.
    std::string intText() const
    {
        return intIsUnsigned() ? std::to_string(static_cast<uint64_t>(i64_)) : std::to_string(i64_);
    }

    // Forget the bool / integer type, keeping `number`: the value becomes
    // the plain float64 it mirrors. Used before handing a value to code
    // that only computes in doubles.
    void dropScalarType()
    {
        boolTag_ = false;
        intTag_ = 0;
        floatTag_ = 0;
    }

    /* string */

    Value(const std::string &s) : Value()
    {
        if (!s.empty())
            wr().text = s;
        isText = true;
        isArray = false;
        isMatrix = false;
        isDict = false;
    }

    /* array */

    Value(const std::vector<Value> &a) : Value()
    {
        if (auto t = pack(a))
            wr().tensor = std::move(t);
        else if (!a.empty())
            wr().array = a;
        isArray = true;
        isText = false;
        isMatrix = false;
        isDict = false;
    }

    /* matrix */

    Value(const std::vector<std::vector<Value>> &m) : Value()
    {
        if (auto t = pack(m))
            wr().tensor = std::move(t);
        else if (!m.empty())
            wr().matrix = m;
        isMatrix = true;
        isArray = false;
        isText = false;
        isDict = false;
    }

    /* dict */

    Value(const std::unordered_map<std::string, Value> &d) : Value()
    {
        if (!d.empty())
            wr().dict = d;
        isDict = true;
        isText = false;
        isArray = false;
        isMatrix = false;
    }

    /* array / matrix (moving) - same as the copying constructors above,
       minus the full copy of a container the caller is done with. */

    Value(std::vector<Value> &&a) : Value()
    {
        if (auto t = pack(a))
            wr().tensor = std::move(t);
        else if (!a.empty())
            wr().array = std::move(a);
        isArray = true;
    }

    Value(std::vector<std::vector<Value>> &&m) : Value()
    {
        if (auto t = pack(m))
            wr().tensor = std::move(t);
        else if (!m.empty())
            wr().matrix = std::move(m);
        isMatrix = true;
    }

    /* ---- text / dict / object-state access ----

       Read with name(), change through nameMut(). Reading never allocates:
       a Value with no Box reads as empty. nameMut() gives the Value a Box
       if it doesn't have one yet. */

    const std::string &text() const { return rd().text; }
    std::string &textMut() { return wr().text; }

    const std::unordered_map<std::string, Value> &dict() const { return rd().dict; }
    std::unordered_map<std::string, Value> &dictMut() { return wr().dict; }

    const std::string &className() const { return rd().className; }
    std::string &classNameMut() { return wr().className; }

    const std::string &funcRefName() const { return rd().funcRefName; }
    std::string &funcRefNameMut() { return wr().funcRefName; }

    const std::vector<std::string> &lineage() const { return rd().lineage; }
    std::vector<std::string> &lineageMut() { return wr().lineage; }

    const std::vector<std::unordered_map<std::string, Value>> &snapshots() const
    {
        return rd().snapshots;
    }
    std::vector<std::unordered_map<std::string, Value>> &snapshotsMut()
    {
        return wr().snapshots;
    }

    double lastTickTime() const { return rd().lastTickTime; }
    double &lastTickTimeMut() { return wr().lastTickTime; }

    // True for a complex number, or an array/matrix holding at least one.
    bool hasComplex() const
    {
        if (isComplex)
            return true;
        if (!box_)
            return false;
        if (box_->tensor)
            return box_->tensor->complex;
        for (const Value &elem : box_->array)
            if (elem.hasComplex())
                return true;
        for (const auto &matRow : box_->matrix)
            for (const Value &cell : matRow)
                if (cell.hasComplex())
                    return true;
        for (const Value &cell : box_->ndCells)
            if (cell.hasComplex())
                return true;
        return false;
    }

    /* ---- array / matrix element access ----

       Every use of the `array` / `matrix` storage outside this struct goes
       through these, so the storage behind them can later become one flat
       numeric buffer without touching any caller. Elements are therefore
       passed BY VALUE, never by reference: a flat buffer of doubles has no
       `Value` object to hand out a reference to. Numeric loops should use
       numAt()/setNumAt(), which skip building a whole Value per element. */

    /* sizes

       rows() / cols() / at(r, c) and the rest of this section are the 2-D
       view. An N-dimensional matrix (isND()) answers 0 rows and 0 columns
       here, so code written for 2-D matrices sees it as empty and can never
       read a wrong element from it; N-D code uses the ndXxx() accessors
       further down. */

    size_t length() const { return packed1() ? rd().tensor->shape[0] : rd().array.size(); }
    size_t rows() const { return packed2() ? rd().tensor->shape[0] : rd().matrix.size(); }
    // Column count of the FIRST row (0 for an empty matrix). Rows are not
    // guaranteed equal-length in the cell form - use rowLength(r) where
    // that matters.
    size_t cols() const
    {
        if (packed2())
            return rd().tensor->shape[1];
        return rd().matrix.empty() ? 0 : rd().matrix[0].size();
    }
    size_t rowLength(size_t r) const { return packed2() ? rd().tensor->shape[1] : rd().matrix[r].size(); }

    /* element read */

    Value at(size_t i) const { return packed1() ? elemOf(i) : rd().array[i]; }
    Value at(size_t r, size_t c) const
    {
        return packed2() ? elemOf(offset(r, c)) : rd().matrix[r][c];
    }
    // The element's number; for a complex element, its real part.
    double numAt(size_t i) const
    {
        return packed1() ? rd().tensor->buf[i * stride()] : rd().array[i].number;
    }
    double numAt(size_t r, size_t c) const
    {
        return packed2() ? rd().tensor->buf[offset(r, c) * stride()] : rd().matrix[r][c].number;
    }
    // The element as a complex number (imaginary part 0 for a real one).
    std::complex<double> cnumAt(size_t i) const
    {
        return packed1() ? cplxOf(i) : cplxOf(rd().array[i]);
    }
    std::complex<double> cnumAt(size_t r, size_t c) const
    {
        return packed2() ? cplxOf(offset(r, c)) : cplxOf(rd().matrix[r][c]);
    }

    /* element write */

    void setAt(size_t i, const Value &v)
    {
        if (packed1()) {
            if (fits(v)) {
                store(i, v);
                return;
            }
            unpack();
        }
        wr().array[i] = v;
    }
    void setAt(size_t r, size_t c, const Value &v)
    {
        if (packed2()) {
            if (fits(v)) {
                store(offset(r, c), v);
                return;
            }
            unpack();
        }
        wr().matrix[r][c] = v;
    }
    // Overwrites only the element's number, leaving everything else about
    // it (unit dimensions, ...) as it was.
    void setNumAt(size_t i, double n)
    {
        if (packed1()) {
            ownTensor();
            rd().tensor->buf[i * stride()] = n;
        } else {
            wr().array[i].number = n;
        }
    }
    void setNumAt(size_t r, size_t c, double n)
    {
        if (packed2()) {
            ownTensor();
            rd().tensor->buf[offset(r, c) * stride()] = n;
        } else {
            wr().matrix[r][c].number = n;
        }
    }

    /* whole rows / whole containers (copies) */

    std::vector<Value> row(size_t r) const
    {
        if (!packed2())
            return rd().matrix[r];
        std::vector<Value> out;
        out.reserve(rd().tensor->shape[1]);
        for (size_t c = 0; c < rd().tensor->shape[1]; c++)
            out.push_back(elemOf(offset(r, c)));
        return out;
    }
    void setRow(size_t r, const std::vector<Value> &v)
    {
        if (packed2()) {
            bool allFit = v.size() == rd().tensor->shape[1];
            for (size_t c = 0; allFit && c < v.size(); c++)
                allFit = fits(v[c]);
            if (allFit) {
                for (size_t c = 0; c < v.size(); c++)
                    store(offset(r, c), v[c]);
                return;
            }
            unpack();
        }
        wr().matrix[r] = v;
    }
    std::vector<Value> elems() const
    {
        if (!packed1())
            return rd().array;
        std::vector<Value> out;
        out.reserve(rd().tensor->shape[0]);
        for (size_t i = 0; i < rd().tensor->shape[0]; i++)
            out.push_back(elemOf(i));
        return out;
    }
    std::vector<std::vector<Value>> rowsCopy() const
    {
        if (!packed2())
            return rd().matrix;
        std::vector<std::vector<Value>> out;
        out.reserve(rd().tensor->shape[0]);
        for (size_t r = 0; r < rd().tensor->shape[0]; r++)
            out.push_back(row(r));
        return out;
    }

    void append(const Value &v)
    {
        if (packed1()) {
            if (fits(v)) {
                ownTensor();
                rd().tensor->buf.resize(rd().tensor->buf.size() + stride());
                rd().tensor->shape[0]++;
                store(rd().tensor->shape[0] - 1, v);
                return;
            }
            unpack();
        }
        wr().array.push_back(v);
    }

    // Replaces each array element / matrix cell with fn(element). fn sees
    // and returns a whole Value, so anything it doesn't deliberately change
    // (unit dimensions, fraction text, a nested array) survives. Matrix
    // cells are visited row by row. General but slow on packed data (it
    // builds a Value per element) - numeric code should prefer mapPacked().
    template <typename Fn> void transformElems(Fn fn)
    {
        if (!box_)
            return; // nothing stored, so no elements
        bool wasPacked = static_cast<bool>(rd().tensor);
        unpack();
        for (auto &elem : wr().array)
            elem = fn(static_cast<const Value &>(elem));
        for (auto &matRow : wr().matrix)
            for (auto &cell : matRow)
                cell = fn(static_cast<const Value &>(cell));
        for (auto &cell : wr().ndCells)
            cell = fn(static_cast<const Value &>(cell));
        if (wasPacked)
            repack();
    }

    /* ---- N-dimensional matrices (rank >= 3) ----

       [1,2;3,4;;5,6;7,8] is a 2x2x2 matrix: isMatrix is set, as for every
       matrix, and isND() tells it apart from a 2-D one. Shape
       [d0, ..., d(n-3), rows, cols]; elements live in the order described
       at NumTensor (2-D column-major pages, pages in row-major order of the
       leading indices). The "storage index" k below counts elements in that
       order, 0 .. ndCount()-1. The helpers in ops/matrix/nd_array.h turn a
       multi-index into a storage index. */

    bool isND() const
    {
        if (!isMatrix || !box_)
            return false;
        return box_->tensor ? box_->tensor->shape.size() >= 3 : box_->ndShape.size() >= 3;
    }

    // N-D only: the shape.
    const std::vector<size_t> &ndShape() const
    {
        return rd().tensor ? rd().tensor->shape : rd().ndShape;
    }
    size_t ndRank() const { return ndShape().size(); }
    size_t ndCount() const
    {
        size_t n = 1;
        for (size_t d : ndShape())
            n *= d;
        return n;
    }

    // N-D only: element at storage index k.
    Value ndAt(size_t k) const { return rd().tensor ? elemOf(k) : rd().ndCells[k]; }
    double ndNumAt(size_t k) const
    {
        return rd().tensor ? rd().tensor->buf[k * stride()] : rd().ndCells[k].number;
    }
    std::complex<double> ndCnumAt(size_t k) const
    {
        return rd().tensor ? cplxOf(k) : cplxOf(rd().ndCells[k]);
    }

    // N-D only: overwrite the element at storage index k. A value the
    // packed buffer cannot hold switches the matrix to cells.
    void ndSetAt(size_t k, const Value &v)
    {
        if (rd().tensor) {
            if (fits(v)) {
                store(k, v);
                return;
            }
            unpack();
        }
        wr().ndCells[k] = v;
    }

    // An N-D matrix (shape.size() >= 3) holding `cells` in storage order
    // (cells.size() must equal the product of the shape). Packed when every
    // cell is a plain number sharing one unit, cells otherwise.
    static Value ndFromCells(std::vector<size_t> shape, std::vector<Value> cells)
    {
        Value v;
        v.isMatrix = true;
        if (auto t = pack(cells)) {
            t->shape = std::move(shape);
            v.wr().tensor = std::move(t);
        } else {
            v.wr().ndCells = std::move(cells);
            v.wr().ndShape = std::move(shape);
        }
        return v;
    }

    // An N-D matrix straight from a packed buffer in storage order (two
    // doubles per element, re then im, when `complex`). Every element
    // carries the unit l/t/m.
    static Value ndPacked(std::vector<size_t> shape, std::vector<double> buf, bool complex,
                          int16_t l = 0, int16_t t = 0, int16_t m = 0)
    {
        Value v;
        v.isMatrix = true;
        auto tensor = std::make_shared<NumTensor>();
        tensor->shape = std::move(shape);
        tensor->buf = std::move(buf);
        tensor->complex = complex;
        tensor->dimL = l;
        tensor->dimT = t;
        tensor->dimM = m;
        v.wr().tensor = std::move(tensor);
        return v;
    }

    /* ---- packed (flat numeric buffer) fast paths ---- */

    // True when the elements are held as one flat buffer of plain REAL
    // numbers. A packed complex tensor answers false here on purpose: every
    // caller of this takes the buffer to be one double per element.
    bool isPacked() const { return rd().tensor && !rd().tensor->complex; }

    // True when the elements are held as one flat buffer of complex numbers.
    bool isPackedComplex() const { return rd().tensor && rd().tensor->complex; }

    // Packed complex only: the buffer, `re, im` per element, column-major
    // for a matrix.
    const std::complex<double> *packedComplexData() const
    {
        return reinterpret_cast<const std::complex<double> *>(rd().tensor->buf.data());
    }

    // A unitless packed complex array / matrix copied from `n` (or
    // rows*cols, column-major) complex numbers. Sizes must be non-zero.
    static Value packedComplexArray(const std::complex<double> *data, size_t n)
    {
        Value v;
        v.isArray = true;
        v.wr().tensor = complexTensor(data, n);
        v.rd().tensor->shape = {n};
        return v;
    }
    static Value packedComplexMatrix(const std::complex<double> *colMajor, size_t nrows,
                                     size_t ncols)
    {
        Value v;
        v.isMatrix = true;
        v.wr().tensor = complexTensor(colMajor, nrows * ncols);
        v.rd().tensor->shape = {nrows, ncols};
        return v;
    }

    // If this is a packed complex array/matrix whose imaginary parts are all
    // exactly zero, turn it into the ordinary real packed form.
    void narrowIfReal()
    {
        if (!isPackedComplex())
            return;
        const std::vector<double> &src = rd().tensor->buf;
        for (size_t k = 1; k < src.size(); k += 2)
            if (src[k] != 0.0)
                return;
        auto t = std::make_shared<NumTensor>();
        t->shape = rd().tensor->shape;
        t->dimL = rd().tensor->dimL;
        t->dimT = rd().tensor->dimT;
        t->dimM = rd().tensor->dimM;
        t->buf.resize(src.size() / 2);
        for (size_t k = 0; k < t->buf.size(); k++)
            t->buf[k] = src[2 * k] + 0.0; // + 0.0: no negative zeros
        wr().tensor = std::move(t);
    }

    // Packed only: the buffer itself, column-major for a matrix.
    const double *packedData() const { return rd().tensor->buf.data(); }

    // A unitless packed array / matrix copied from `n` (or rows*cols,
    // column-major) doubles.
    static Value packedArray(const double *data, size_t n)
    {
        Value v;
        v.isArray = true;
        v.wr().tensor = std::make_shared<NumTensor>();
        v.rd().tensor->buf.assign(data, data + n);
        v.rd().tensor->shape = {n};
        return v;
    }
    static Value packedMatrix(const double *colMajor, size_t nrows, size_t ncols)
    {
        Value v;
        v.isMatrix = true;
        v.wr().tensor = std::make_shared<NumTensor>();
        v.rd().tensor->buf.assign(colMajor, colMajor + nrows * ncols);
        v.rd().tensor->shape = {nrows, ncols};
        return v;
    }

    // Packed only: a copy of this Value with every element replaced by the
    // unitless number fn(element) - what assigning `Value(fn(x))` to each
    // element does, without building those Values. Matrix cells are visited
    // row by row, the same order the cell form is walked in.
    template <typename Fn> Value mapPacked(Fn fn) const
    {
        Value result = *this;
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        out->buf.resize(rd().tensor->buf.size());
        forEachOffset([&](size_t k) { out->buf[k] = fn(rd().tensor->buf[k]); });
        result.wr().tensor = std::move(out);
        return result;
    }

    // Packed only, `other` packed with the same shape: like mapPacked(),
    // with fn(thisElement, otherElement).
    template <typename Fn> Value zipPacked(const Value &other, Fn fn) const
    {
        Value result = *this;
        auto out = std::make_shared<NumTensor>();
        out->shape = rd().tensor->shape;
        out->buf.resize(rd().tensor->buf.size());
        forEachOffset(
            [&](size_t k) { out->buf[k] = fn(rd().tensor->buf[k], other.rd().tensor->buf[k]); });
        result.wr().tensor = std::move(out);
        return result;
    }

    bool sameShapeAs(const Value &other) const
    {
        return isPacked() && other.isPacked() && rd().tensor->shape == other.rd().tensor->shape;
    }

  private:
    // The Box to read from: this Value's own, or a shared blank one.
    const Box &rd() const
    {
        static const Box blank;
        return box_ ? *box_ : blank;
    }
    // The Box to write to, created on first use.
    Box &wr()
    {
        if (!box_)
            box_ = new Box;
        return *box_;
    }

    bool packed1() const { return rd().tensor && rd().tensor->shape.size() == 1; }
    bool packed2() const { return rd().tensor && rd().tensor->shape.size() == 2; }
    // Element index (not buffer index) of a matrix cell.
    size_t offset(size_t r, size_t c) const { return c * rd().tensor->shape[0] + r; }
    // Doubles per element in the packed buffer.
    size_t stride() const { return rd().tensor->complex ? 2 : 1; }

    // Calls fn(bufferIndex) for every element: in order for an array, row by
    // row for a matrix.
    template <typename Fn> void forEachOffset(Fn fn) const
    {
        // A vector, or an N-D matrix (whose element order every caller of
        // this is indifferent to: they write element k of the result from
        // element k of the operands).
        if (packed1() || rd().tensor->shape.size() >= 3) {
            for (size_t k = 0; k < rd().tensor->buf.size(); k++)
                fn(k);
            return;
        }
        for (size_t r = 0; r < rd().tensor->shape[0]; r++)
            for (size_t c = 0; c < rd().tensor->shape[1]; c++)
                fn(offset(r, c));
    }

    // A plain number or a complex one: nothing about it beyond its value
    // and unit differs from a freshly built Value, so it can be stored as
    // bare doubles and rebuilt later with nothing lost.
    // Bools, integers and float8/16/32 numbers stay in the cell form: the
    // packed buffer is float64 only.
    static bool isPackable(const Value &v)
    {
        return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
               !v.isFunctionRef && !v.boolTag_ && v.intTag_ == 0 && v.floatTag_ == 0 &&
               (!v.box_ || v.box_->isBlank());
    }

    // No container, text, function reference or complex part: just a
    // number (possibly with a unit).
    bool isPlainScalar() const
    {
        return !isText && !isArray && !isMatrix && !isDict && !isObject && !isFunctionRef &&
               !isComplex;
    }

    // Can `v` be stored in this Value's packed buffer without losing anything?
    // A complex `v` fits a real buffer too: store() widens it first.
    bool fits(const Value &v) const
    {
        return isPackable(v) && v.dimL == rd().tensor->dimL && v.dimT == rd().tensor->dimT &&
               v.dimM == rd().tensor->dimM;
    }

    // Writes `v` (already checked with fits()) at element index `idx`.
    void store(size_t idx, const Value &v)
    {
        ownTensor();
        if (v.isComplex && !rd().tensor->complex)
            widen();
        NumTensor &t = *wr().tensor;
        if (t.complex) {
            t.buf[2 * idx] = v.number;
            t.buf[2 * idx + 1] = v.isComplex ? v.imag : 0.0;
        } else {
            t.buf[idx] = v.number;
        }
    }

    // Real packed buffer -> complex packed buffer, same values. Call after
    // ownTensor().
    void widen()
    {
        NumTensor &t = *wr().tensor;
        std::vector<double> wide(t.buf.size() * 2, 0.0);
        for (size_t k = 0; k < t.buf.size(); k++)
            wide[2 * k] = t.buf[k];
        t.buf = std::move(wide);
        t.complex = true;
    }

    // The element at element index `idx` of the packed buffer. An element
    // of a complex tensor whose imaginary part is exactly zero reads back as
    // a real number, the same narrowing arithmetic results get.
    Value elemOf(size_t idx) const
    {
        const NumTensor &t = *rd().tensor;
        Value v = (t.complex && t.buf[2 * idx + 1] != 0.0)
                      ? complexNumber(t.buf[2 * idx], t.buf[2 * idx + 1])
                      : Value(t.buf[idx * (t.complex ? 2 : 1)]);
        v.dimL = t.dimL;
        v.dimT = t.dimT;
        v.dimM = t.dimM;
        return v;
    }

    std::complex<double> cplxOf(size_t idx) const
    {
        const NumTensor &t = *rd().tensor;
        return t.complex ? std::complex<double>(t.buf[2 * idx], t.buf[2 * idx + 1])
                         : std::complex<double>(t.buf[idx], 0.0);
    }
    static std::complex<double> cplxOf(const Value &v)
    {
        return std::complex<double>(v.number, v.isComplex ? v.imag : 0.0);
    }

    static std::shared_ptr<NumTensor> complexTensor(const std::complex<double> *data, size_t n)
    {
        auto t = std::make_shared<NumTensor>();
        t->complex = true;
        t->buf.resize(2 * n);
        for (size_t k = 0; k < n; k++) {
            t->buf[2 * k] = data[k].real();
            t->buf[2 * k + 1] = data[k].imag();
        }
        return t;
    }

    // Packed form of `a`, or null when it has to stay as cells (empty, or
    // an element that isn't a plain number in the same unit as the rest).
    static std::shared_ptr<NumTensor> pack(const std::vector<Value> &a)
    {
        if (a.empty())
            return nullptr;
        bool anyComplex = false;
        for (const Value &v : a) {
            if (!isPackable(v) || v.dimL != a[0].dimL || v.dimT != a[0].dimT ||
                v.dimM != a[0].dimM)
                return nullptr;
            anyComplex = anyComplex || v.isComplex;
        }
        auto t = std::make_shared<NumTensor>();
        t->shape = {a.size()};
        t->dimL = a[0].dimL;
        t->dimT = a[0].dimT;
        t->dimM = a[0].dimM;
        t->complex = anyComplex;
        t->buf.reserve(a.size() * (anyComplex ? 2 : 1));
        for (const Value &v : a) {
            t->buf.push_back(v.number);
            if (anyComplex)
                t->buf.push_back(v.isComplex ? v.imag : 0.0);
        }
        return t;
    }

    // As above for a matrix, which additionally has to be rectangular.
    static std::shared_ptr<NumTensor> pack(const std::vector<std::vector<Value>> &m)
    {
        if (m.empty() || m[0].empty())
            return nullptr;
        const Value &first = m[0][0];
        bool anyComplex = false;
        for (const auto &matRow : m) {
            if (matRow.size() != m[0].size())
                return nullptr;
            for (const Value &v : matRow) {
                if (!isPackable(v) || v.dimL != first.dimL || v.dimT != first.dimT ||
                    v.dimM != first.dimM)
                    return nullptr;
                anyComplex = anyComplex || v.isComplex;
            }
        }
        auto t = std::make_shared<NumTensor>();
        t->shape = {m.size(), m[0].size()};
        t->dimL = first.dimL;
        t->dimT = first.dimT;
        t->dimM = first.dimM;
        t->complex = anyComplex;
        const size_t step = anyComplex ? 2 : 1;
        t->buf.resize(m.size() * m[0].size() * step);
        for (size_t r = 0; r < m.size(); r++)
            for (size_t c = 0; c < m[0].size(); c++) {
                const Value &v = m[r][c];
                t->buf[(c * m.size() + r) * step] = v.number;
                if (anyComplex)
                    t->buf[(c * m.size() + r) * step + 1] = v.isComplex ? v.imag : 0.0;
            }
        return t;
    }

    // Before writing to the packed buffer: stop sharing it with any copies.
    void ownTensor()
    {
        if (rd().tensor.use_count() > 1)
            wr().tensor = std::make_shared<NumTensor>(*rd().tensor);
    }

    // Packed -> cells, contents unchanged.
    void unpack()
    {
        if (!rd().tensor)
            return;
        if (packed1()) {
            wr().array = elems();
        } else if (packed2()) {
            wr().matrix = rowsCopy();
        } else {
            // N-D: keep every element, in the same storage order.
            const size_t n = ndCount();
            std::vector<Value> cells;
            cells.reserve(n);
            for (size_t k = 0; k < n; k++)
                cells.push_back(elemOf(k));
            wr().ndShape = rd().tensor->shape;
            wr().ndCells = std::move(cells);
        }
        wr().tensor.reset();
    }

    // Cells -> packed where the contents allow it.
    void repack()
    {
        if (!rd().ndCells.empty()) {
            if (auto t = pack(rd().ndCells)) {
                t->shape = rd().ndShape;
                wr().tensor = std::move(t);
                wr().ndCells.clear();
                wr().ndShape.clear();
            }
            return;
        }
        if (!rd().array.empty() && (wr().tensor = pack(rd().array)))
            wr().array.clear();
        else if (!rd().matrix.empty() && (wr().tensor = pack(rd().matrix)))
            wr().matrix.clear();
    }
};

static_assert(sizeof(Value) == 32, "Value is meant to stay a small handle - see Value::Box");

// Function references (`@name`) hold the name of the function they call.
// An anonymous function, @(x) x * 2, is registered under its own source text
// followed by kAnonymousSeparator and a number that keeps two identical
// texts apart (Parser, ExprKind::AnonymousFunction). Shown to the user, a
// reference reads as written: "@square", "@(x) x * 2".
constexpr char kAnonymousSeparator = '\x1f';

inline std::string functionRefText(const std::string &name)
{
    const size_t cut = name.find(kAnonymousSeparator);
    if (cut != std::string::npos)
        return name.substr(0, cut);
    return "@" + name;
}
