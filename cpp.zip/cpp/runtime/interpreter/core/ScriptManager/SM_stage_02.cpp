// Stage 2: line-by-line execution driver. Reads a resolved .nc file and
// drives the Lexer/Parser over it, including if/for/while block
// accumulation.
#include "SM_main.h"

#include <algorithm>
#include <fstream>
#include <iostream>

#include "lexer.h"
#include "parser.h"
#include "line_continuation.h"
#include "../../../execution/Interrupt.h"

#ifdef NC_HAS_JIT
#include "../../../../compiler/compiler_src/codegen/jit_engine.h"
#endif

bool ScriptManager::pathsReferToSameFile(const std::filesystem::path &a,
                                         const std::filesystem::path &b) const {
  std::error_code ec;
  if (std::filesystem::equivalent(a, b, ec))
    return true;

  return normalizePath(a) == normalizePath(b);
}

// Reads executionStack_ - see the header comment on this method for why
// SM_stage_01's resolveFilePath() also calls it.
std::filesystem::path ScriptManager::getCurrentExecutionDirectory() const {
  if (!executionStack_.empty())
    return executionStack_.back().directory;
  return std::filesystem::current_path();
}

void ScriptManager::executeFile(const std::string &absolutePath) {
  if (absolutePath.empty()) {
    std::cerr << "Error: empty path\n";
    return;
  }

  std::filesystem::path filePath =
      normalizePath(std::filesystem::path(absolutePath));
  if (!isRegularFile(filePath)) {
    std::cerr << "Error: file not found: " << absolutePath << "\n";
    return;
  }
  // the MAX_SCRIPT_DEPTH is 100, for now, it is hardcoded.
  if (executionStack_.size() >= MAX_SCRIPT_DEPTH) {
    std::cerr << "Maximum script execution depth exceeded\n";
    return;
  }

  if (std::any_of(executionStack_.begin(), executionStack_.end(),
                  [&](const ExecutionFrame &frame) {
                    return pathsReferToSameFile(frame.file, filePath);
                  })) {
    std::cerr << "Recursive execution detected\n";
    return;
  }

  std::ifstream file(filePath.string());
  if (!file.is_open()) {
    std::cerr << "Error: failed to open file: " << absolutePath << "\n";
    return;
  }

  // A fresh Parser per script (its functions/classes stay private to this
  // run), but working on the REPL's workspace: the variables are moved in
  // now and moved back when the script ends, however it ends.
  Parser parser;
  struct WorkspaceLoan {
    Parser *owner;
    Parser &script;
    WorkspaceLoan(Parser *o, Parser &s) : owner(o), script(s) {
      if (owner) {
        script.memory = std::move(owner->memory);
        script.insertionOrder = std::move(owner->insertionOrder);
      }
    }
    ~WorkspaceLoan() {
      if (owner) {
        owner->memory = std::move(script.memory);
        owner->insertionOrder = std::move(script.insertionOrder);
      }
    }
  } loan(workspaceParser_, parser);
  std::filesystem::path fileDir = normalizePath(filePath.parent_path());

  bool added = registerSearchPath(fileDir);
  if (added) {
    discoverNcFilesInDirectory(fileDir);
    saveCachedNcFileIndex();
    saveSearchPaths();
  }
  // pushing the execution frame to the stack
  executionStack_.push_back(ExecutionFrame{filePath, fileDir});
  auto popFrame = [&]() {
    if (!executionStack_.empty())
      executionStack_.pop_back();
  };

  try {
    // ---- Read the whole file as one logical-line-merged buffer ----
    // readLogicalLine's '~~' continuation-line merging still runs per
    // physical line, off the same `file` stream, exactly as before. Each
    // line merged in is replaced by an empty line after the merged one, so
    // the buffer keeps the file's line count: every token after a '~~'
    // split keeps its real line number (errors, the editor's markers and
    // Step's @STEPAT point at the right line). A statement split with '~~'
    // is reported at its first line.
    std::string wholeFile;
    {
      std::string rawLine;
      while (std::getline(file, rawLine)) {
        size_t joined = 0;
        wholeFile += readLogicalLine(file, rawLine, &joined);
        wholeFile.append(1 + joined, '\n');
      }
    }

    // ---- Lex once, parse into a full Program tree, then walk it ----
    // Replaces the old two-pass raw-line dispatch (a hand-rolled function/
    // class pre-scan, then a second pass re-lexing and dispatching each
    // remaining line individually, with separate if/for/while nesting-depth
    // counters to find each block's own boundary by keyword-matching).
    // parseProgram() builds the whole file's Stmt tree in one recursive-
    // descent pass (nesting "just works" - no depth counters anywhere, at
    // any depth, for any block type), and executeProgram() does the
    // function/class forward-reference registration pass over that
    // already-built tree before executing everything else in order. See
    // Testing_Files/run_golden_tests.sh (the regression corpus this cutover
    // was verified against) and docs/AST.txt.
    Lexer lexer(wholeFile);
    auto tokens = lexer.tokenize();
    Program program = parser.parseProgram(tokens);

    // A script with a syntax or layout error does not run at all - the way
    // Python refuses a file it cannot parse. It used to report the error
    // and run anyway, so a missing 'iend' or a misaligned closer could go
    // unnoticed while the body ran (or ran in the wrong place).
    // (Lexical errors - "unexpected character" - count too.)
    const int syntaxErrors = parser.syntaxErrorCount_ + lexer.errorCount();
    if (syntaxErrors > 0) {
      std::cerr << "✖ Syntax Error: the script was not run - fix the error"
                << (syntaxErrors > 1 ? "s" : "") << " above first\n";
      popFrame();
      return;
    }

#ifdef NC_HAS_JIT
    if (jitEnabled_ && jitEngine_) {
      // Same two passes executeProgram() always ran, just with Pass 2 now
      // JIT-aware: attempt jitEngine_->runStmt() per top-level statement
      // first, falling back to the tree-walker's executeStmt() exactly like
      // main.cpp's REPL loop does for every line it reads. FunctionDecl/
      // ClassDecl statements are NOT skipped here (unlike executeProgram()'s
      // own Pass 2) - letting JIT attempt to natively compile them too (same
      // as the REPL) means later calls in this file can get the fast native-
      // call path instead of always falling to nc_bridge_call_dynamic's
      // generic tier; Pass 1 below already guarantees they're registered
      // into functionTable_/classTable_ regardless of whether the native
      // compile succeeds, so forward-reference correctness and the "unknown
      // class/function" fallback (value_bridge.h's "Dynamic call dispatch")
      // are both intact either way. A statement executeStmt() itself would
      // re-register (FunctionDecl/ClassDecl, when JIT rejects them) is a
      // harmless no-op redo - registerOverload() replaces an existing
      // overload of the same arity in place.
      parser.registerTopLevelDecls(program); // Pass 1
      for (const auto &stmt : program.statements) {
        if (nc::Interrupt::poll())
          break; // Stop pressed - reported once by the REPL
        const unsigned long errorsBefore = nc::errorlines::count();
        bool jitRan = jitEngine_->runStmt(stmt.get(), parser);
        if (!jitRan)
          parser.executeStmt(stmt.get());
        parser.noteStatementResult(stmt->line, errorsBefore);
        if (parser.errorAbort_) {
          if (parser.errorLine_ > 0)
            std::cerr << "✖ Runtime Error (line " << parser.errorLine_
                      << "): the script stopped here because of the error above\n";
          parser.clearErrorAbort();
          parser.consumeTopLevelStopSignal();
          break;
        }
        if (parser.consumeTopLevelStopSignal())
          break;
      }
    } else {
      parser.executeProgram(program);
    }
#else
    parser.executeProgram(program);
#endif
  } catch (const std::exception &e) {
    std::cerr << "Runtime error in " << filePath.string() << ": " << e.what()
              << "\n";
  }

  popFrame();
}
