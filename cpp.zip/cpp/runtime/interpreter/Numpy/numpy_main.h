// Entry point of the NumPy-equivalent library. The rest of the interpreter
// talks to the Numpy folder ONLY through this header, from one place:
//
//   builtins/builtins.cpp  callBuiltin()  ->  nc::numpy::tryCall(...)
//
// Everything else (the 11 sections, the registry, helpers) stays private to
// the folder, so section developers never need to touch interpreter files.
#ifndef NC_NUMPY_MAIN_H
#define NC_NUMPY_MAIN_H

#include <string>
#include <vector>

#include "../core/value.h"

namespace nc {
namespace numpy {

// Registers all 11 sections. Safe to call more than once (runs once); tryCall()
// calls it on first use, so calling it explicitly is optional.
void initialize();

// If `name` is a NumPy function (or numpy_functions / numpy_status): checks
// the arguments, runs it, stores the result in `out`, sets `ok` (false = an
// error was printed and the statement must stop), and returns true.
// Otherwise returns false and touches nothing, so callBuiltin() carries on.
//
// `argNames`: the name written before each value (`atol` in
// allclose(A, B, atol=0.2)), "" for a plain one; empty when none is named.
// Named values work for every function whose section gives it a parameter
// line (see Registry::setParams); for any other one, naming a value is an
// error.
bool tryCall(const std::string &name, const std::vector<Value> &args, Value &out, bool &ok,
             const std::vector<std::string> &argNames = {});

bool isNumpyFunction(const std::string &name);

// Multi-output call, e.g. [U, S, V] = svd(A). If `name` is a NumPy function
// that can return `nout` values: runs it, fills `out`, sets `ok` and returns
// true. Returns false (touching nothing) if `name` is not such a function.
bool tryCallMulti(const std::string &name, const std::vector<Value> &args, size_t nout,
                  std::vector<Value> &out, bool &ok,
                  const std::vector<std::string> &argNames = {});

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_MAIN_H
