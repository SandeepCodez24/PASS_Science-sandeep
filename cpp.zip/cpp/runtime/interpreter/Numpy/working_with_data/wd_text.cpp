// Working with Data - text.
//
// Every function works on one text or element by element on a matrix of
// text (two inputs: the same size, or a single text against every element).
// Lengths and positions count CHARACTERS (UTF-8 aware): str_len("héllo") is
// 5, and positions are 0-based like everywhere in NC.
//
//   str_concat(a, b)            a and b joined: "ab"                   np.char.add
//   split_str(s, sep="", maxsplit=-1)                                  np.char.split
//                               the parts as a row of text; sep="" splits at
//                               runs of spaces / tabs / newlines and drops empty
//                               parts; maxsplit >= 0 limits the number of cuts.
//                               A matrix of text gives a list of rows.
//   join(sep, texts)            the texts (row by row) joined with sep  str.join
//   strip(T, chars="")          T without leading / trailing chars (""= white space)
//   find_str(T, sub)            first position of sub, -1 if absent    np.char.find
//   count_str(T, sub)           how often sub occurs (not overlapping) np.char.count
//   starts_with(T, prefix) / ends_with(T, suffix)                       np.char.startswith
//   center(T, width, fill=" ")  T centred in `width` characters        np.char.center
//   zfill(T, width)             zeros on the left up to `width`, after a sign
//   is_digit(T)                 true when T is not empty and all digits 0-9
//   str_len(T)                  number of characters                   np.char.str_len
// The existing upper(), lower(), replace() and substr() keep their names.
#include <algorithm>
#include <string>
#include <vector>

#include "wd_common.h"

namespace nc {
namespace numpy {
namespace wd {

namespace {

/* ---- UTF-8 <-> code points ---- */

std::u32string decode(const std::string &s) {
  std::u32string out;
  for (size_t i = 0; i < s.size();) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    char32_t cp = c;
    size_t len = 1;
    if (c >= 0xF0) {
      cp = c & 0x07;
      len = 4;
    } else if (c >= 0xE0) {
      cp = c & 0x0F;
      len = 3;
    } else if (c >= 0xC0) {
      cp = c & 0x1F;
      len = 2;
    }
    if (i + len > s.size())
      len = 1; // a broken sequence: keep the byte
    for (size_t k = 1; k < len; k++)
      cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3F);
    out.push_back(len == 1 ? static_cast<char32_t>(c) : cp);
    i += len;
  }
  return out;
}

std::string encode(const std::u32string &u) {
  std::string out;
  for (char32_t cp : u) {
    if (cp < 0x80) {
      out += static_cast<char>(cp);
    } else if (cp < 0x800) {
      out += static_cast<char>(0xC0 | (cp >> 6));
      out += static_cast<char>(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
      out += static_cast<char>(0xE0 | (cp >> 12));
      out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
      out += static_cast<char>(0x80 | (cp & 0x3F));
    } else {
      out += static_cast<char>(0xF0 | (cp >> 18));
      out += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
      out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
      out += static_cast<char>(0x80 | (cp & 0x3F));
    }
  }
  return out;
}

bool isSpace(char32_t c) { return c == U' ' || c == U'\t' || c == U'\n' || c == U'\r' || c == U'\f' || c == U'\v'; }

bool textArg(const Value &v, const char *what, CallContext &ctx) {
  if (!v.isText) {
    ctx.fail(std::string(what) + " must be text in quotes" +
             (isPlainNumber(v) ? " - turn a number into text with str(x)" : ""));
    return false;
  }
  return true;
}

// A text function of one text element plus fixed extra arguments.
using TextFn = std::function<bool(const std::u32string &, Value &, CallContext &)>;

Value eachText(const Value &t, const TextFn &fn, CallContext &ctx) {
  return mapElements(
      {t},
      [&](const std::vector<Value> &e, Value &r, CallContext &c) {
        if (!textArg(e[0], "every element", c))
          return false;
        return fn(decode(e[0].text()), r, c);
      },
      ctx);
}

// Two text inputs, element by element.
using PairFn =
    std::function<bool(const std::u32string &, const std::u32string &, Value &, CallContext &)>;

Value eachPair(const Value &a, const Value &b, const PairFn &fn, CallContext &ctx) {
  return mapElements(
      {a, b},
      [&](const std::vector<Value> &e, Value &r, CallContext &c) {
        if (!textArg(e[0], "the first argument", c) || !textArg(e[1], "the second argument", c))
          return false;
        return fn(decode(e[0].text()), decode(e[1].text()), r, c);
      },
      ctx);
}

size_t countOf(const std::u32string &s, const std::u32string &sub) {
  if (sub.empty())
    return s.size() + 1; // Python: one empty match between every two characters
  size_t n = 0;
  for (size_t p = s.find(sub); p != std::u32string::npos; p = s.find(sub, p + sub.size()))
    n++;
  return n;
}

std::vector<std::u32string> splitParts(const std::u32string &s, const std::u32string &sep,
                                       long long maxsplit) {
  std::vector<std::u32string> parts;
  if (sep.empty()) { // runs of white space; no empty parts
    size_t i = 0;
    while (i < s.size()) {
      while (i < s.size() && isSpace(s[i]))
        i++;
      if (i >= s.size())
        break;
      if (maxsplit >= 0 && static_cast<long long>(parts.size()) == maxsplit) {
        size_t end = s.size();
        while (end > i && isSpace(s[end - 1]))
          end--;
        parts.push_back(s.substr(i, end - i));
        break;
      }
      size_t j = i;
      while (j < s.size() && !isSpace(s[j]))
        j++;
      parts.push_back(s.substr(i, j - i));
      i = j;
    }
    return parts;
  }
  size_t start = 0;
  for (;;) {
    if (maxsplit >= 0 && static_cast<long long>(parts.size()) == maxsplit)
      break;
    const size_t p = s.find(sep, start);
    if (p == std::u32string::npos)
      break;
    parts.push_back(s.substr(start, p - start));
    start = p + sep.size();
  }
  parts.push_back(s.substr(start));
  return parts;
}

Value textRow(const std::vector<std::u32string> &parts) {
  std::vector<Value> cells;
  for (const auto &p : parts)
    cells.push_back(Value(encode(p)));
  return ndx::rowOf(cells);
}

/* ---- the functions ---- */

Value strConcat(const std::vector<Value> &args, CallContext &ctx) {
  return eachPair(
      args[0], args[1],
      [](const std::u32string &a, const std::u32string &b, Value &r, CallContext &) {
        r = Value(encode(a + b));
        return true;
      },
      ctx);
}

Value splitStr(const std::vector<Value> &args, CallContext &ctx) {
  std::string sep;
  long long maxsplit = -1;
  if (!argText(args, 1, ctx, sep) || !argInt(args, 2, ctx, maxsplit))
    return Value(0.0);
  const std::u32string usep = decode(sep);
  if (args[0].isText)
    return textRow(splitParts(decode(args[0].text()), usep, maxsplit));
  if (ndx::notMatrixData(args[0])) {
    ctx.fail("the first argument must be text or a matrix of text");
    return Value(0.0);
  }
  std::vector<Value> rows;
  for (const Value &c : ndx::gridOf(args[0]).cells) {
    if (!textArg(c, "every element", ctx))
      return Value(0.0);
    rows.push_back(textRow(splitParts(decode(c.text()), usep, maxsplit)));
  }
  return Value(std::move(rows)); // one row of parts per element
}

Value join(const std::vector<Value> &args, CallContext &ctx) {
  std::string sep;
  if (!argText(args, 0, ctx, sep))
    return Value(0.0);
  if (ndx::notMatrixData(args[1])) {
    ctx.fail("the texts must be text or a matrix of text");
    return Value(0.0);
  }
  std::string out;
  bool first = true;
  for (const Value &c : ndx::gridOf(args[1]).cells) {
    if (!textArg(c, "every element of texts", ctx))
      return Value(0.0);
    out += (first ? "" : sep) + c.text();
    first = false;
  }
  return Value(out);
}

Value strip(const std::vector<Value> &args, CallContext &ctx) {
  std::string chars;
  if (!argText(args, 1, ctx, chars))
    return Value(0.0);
  const std::u32string set = decode(chars);
  auto drop = [&](char32_t c) {
    return set.empty() ? isSpace(c) : set.find(c) != std::u32string::npos;
  };
  return eachText(
      args[0],
      [&](const std::u32string &s, Value &r, CallContext &) {
        size_t b = 0, e = s.size();
        while (b < e && drop(s[b]))
          b++;
        while (e > b && drop(s[e - 1]))
          e--;
        r = Value(encode(s.substr(b, e - b)));
        return true;
      },
      ctx);
}

Value findStr(const std::vector<Value> &args, CallContext &ctx) {
  return eachPair(
      args[0], args[1],
      [](const std::u32string &s, const std::u32string &sub, Value &r, CallContext &) {
        const size_t p = s.find(sub);
        r = Value(p == std::u32string::npos ? -1.0 : static_cast<double>(p));
        return true;
      },
      ctx);
}

Value countStr(const std::vector<Value> &args, CallContext &ctx) {
  return eachPair(
      args[0], args[1],
      [](const std::u32string &s, const std::u32string &sub, Value &r, CallContext &) {
        r = Value(static_cast<double>(countOf(s, sub)));
        return true;
      },
      ctx);
}

Impl affixImpl(bool start) {
  return [start](const std::vector<Value> &args, CallContext &ctx) -> Value {
    return eachPair(
        args[0], args[1],
        [start](const std::u32string &s, const std::u32string &a, Value &r, CallContext &) {
          const bool ok = a.size() <= s.size() &&
                          (start ? s.compare(0, a.size(), a) == 0
                                 : s.compare(s.size() - a.size(), a.size(), a) == 0);
          r = Value::boolean(ok);
          return true;
        },
        ctx);
  };
}

Value center(const std::vector<Value> &args, CallContext &ctx) {
  long long width = 0;
  std::string fill;
  if (!argInt(args, 1, ctx, width) || !argText(args, 2, ctx, fill))
    return Value(0.0);
  const std::u32string f = decode(fill);
  if (f.size() != 1) {
    ctx.fail("fill must be exactly one character, e.g. fill=\"*\"");
    return Value(0.0);
  }
  return eachText(
      args[0],
      [&](const std::u32string &s, Value &r, CallContext &) {
        const long long len = static_cast<long long>(s.size());
        if (width <= len) {
          r = Value(encode(s));
          return true;
        }
        const long long marg = width - len;
        const long long left = marg / 2 + (marg & width & 1); // Python's str.center
        r = Value(encode(std::u32string(static_cast<size_t>(left), f[0]) + s +
                         std::u32string(static_cast<size_t>(marg - left), f[0])));
        return true;
      },
      ctx);
}

Value zfill(const std::vector<Value> &args, CallContext &ctx) {
  long long width = 0;
  if (!argInt(args, 1, ctx, width))
    return Value(0.0);
  return eachText(
      args[0],
      [&](const std::u32string &s, Value &r, CallContext &) {
        const long long len = static_cast<long long>(s.size());
        if (width <= len) {
          r = Value(encode(s));
          return true;
        }
        const size_t sign = (!s.empty() && (s[0] == U'+' || s[0] == U'-')) ? 1 : 0;
        r = Value(encode(s.substr(0, sign) +
                         std::u32string(static_cast<size_t>(width - len), U'0') +
                         s.substr(sign)));
        return true;
      },
      ctx);
}

Value isDigit(const std::vector<Value> &args, CallContext &ctx) {
  return eachText(
      args[0],
      [](const std::u32string &s, Value &r, CallContext &) {
        bool ok = !s.empty();
        for (char32_t c : s)
          ok = ok && c >= U'0' && c <= U'9';
        r = Value::boolean(ok);
        return true;
      },
      ctx);
}

Value strLen(const std::vector<Value> &args, CallContext &ctx) {
  return eachText(
      args[0],
      [](const std::u32string &s, Value &r, CallContext &) {
        r = Value(static_cast<double>(s.size()));
        return true;
      },
      ctx);
}

} // namespace

void registerTextFunctions(Registry &reg) {
  add(reg, "str_concat", 2, 2, "two texts joined", "np.char.add", strConcat);
  add(reg, "split_str", 1, 3, "text cut into parts", "np.char.split", splitStr);
  add(reg, "join", 2, 2, "texts joined with a separator", "str.join", join);
  add(reg, "strip", 1, 2, "leading / trailing characters removed", "np.char.strip", strip);
  add(reg, "find_str", 2, 2, "first position of a text", "np.char.find", findStr);
  add(reg, "count_str", 2, 2, "how often a text occurs", "np.char.count", countStr);
  add(reg, "starts_with", 2, 2, "whether text starts with a prefix", "np.char.startswith",
      affixImpl(true));
  add(reg, "ends_with", 2, 2, "whether text ends with a suffix", "np.char.endswith",
      affixImpl(false));
  add(reg, "center", 2, 3, "text centred in a width", "np.char.center", center);
  add(reg, "zfill", 2, 2, "zeros on the left", "np.char.zfill", zfill);
  add(reg, "is_digit", 1, 1, "whether text is all digits", "np.char.isdigit", isDigit);
  add(reg, "str_len", 1, 1, "number of characters", "np.char.str_len", strLen);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"str_concat", "a, b"},
      {"split_str", "s, sep=\"\", maxsplit=-1"},
      {"join", "sep, texts"},
      {"strip", "T, chars=\"\""},
      {"find_str", "T, sub"},
      {"count_str", "T, sub"},
      {"starts_with", "T, prefix"},
      {"ends_with", "T, suffix"},
      {"center", "T, width, fill=\" \""},
      {"zfill", "T, width"},
      {"is_digit", "T"},
      {"str_len", "T"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace wd
} // namespace numpy
} // namespace nc
