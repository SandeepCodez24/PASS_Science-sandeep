// Section 11 of 11 - Working with Data (73 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_WORKING_WITH_DATA_MAIN_H
#define NC_NUMPY_WORKING_WITH_DATA_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Working with Data function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerWorkingWithData(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_WORKING_WITH_DATA_MAIN_H
