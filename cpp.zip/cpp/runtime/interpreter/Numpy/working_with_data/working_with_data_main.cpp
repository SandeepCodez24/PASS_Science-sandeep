// Section 11 of 11 - Working with Data
// Planned entries: 73  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   wd_values.cpp   is_nan_each is_inf is_finite is_posinf is_neginf unique_all
//                   fill_nan
//   wd_text.cpp     str_concat split_str join strip find_str count_str
//                   starts_with ends_with center zfill is_digit str_len
//   wd_common.h     element-by-element helper shared by both
//
// Names from the team's list that live elsewhere or are not here:
//   - upper, lower, replace, substr: existing NC builtins, kept
//   - date_range, is_busday, busday_count, busday_offset: the time module
//     (ops/time/time_calendar.cpp), on timestamps; date, date_add, date_str
//     are timestamp(), t + days(n) and format_time() there
//   - is_nat: an NC timestamp is never "not a time" (a wrong date is an error
//     when it is made), so it would always be false
//   - submatrix, filter_rows: dropped by the team (2026-10-28)
//
// How to add a function
//   1. Put it in the group file it belongs to (or a new wd_<group>.cpp with a
//      register<Group>(Registry&) declared in wd_common.h and called below).
//   2. Register it with add(...) (wd_common.h) and give it a parameter line.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("working_with_data")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "working_with_data_main.h"

#include "wd_common.h"

namespace nc {
namespace numpy {

void registerWorkingWithData(Registry &reg) {
  wd::registerValueFunctions(reg);
  wd::registerTextFunctions(reg);
}

} // namespace numpy
} // namespace nc
