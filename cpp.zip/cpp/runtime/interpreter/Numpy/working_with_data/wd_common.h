// Shared by the Working with Data group files (wd_values.cpp, wd_text.cpp).
// Private to the working_with_data folder.
#ifndef NC_NUMPY_WD_COMMON_H
#define NC_NUMPY_WD_COMMON_H

#include <functional>
#include <string>
#include <vector>

#include "../numpy_nd.h"

namespace nc {
namespace numpy {
namespace wd {

using ndx::Grid;

// fn(one element of each input) at every position: the inputs share one
// shape or are single values (repeated). The result has that shape - or is a
// single value when every input was one. Results go through the matrix type
// rules.
using CellsFn = std::function<bool(const std::vector<Value> &, Value &, CallContext &)>;

inline Value mapElements(const std::vector<Value> &inputs, const CellsFn &fn, CallContext &ctx) {
  std::vector<Grid> grids;
  nd::Shape shape{1, 1};
  bool anyMatrix = false;
  for (size_t i = 0; i < inputs.size(); i++) {
    if (ndx::notMatrixData(inputs[i])) {
      ctx.fail("the " + ordinal(i) + " argument must be text, a number or a matrix of them");
      return Value(0.0);
    }
    grids.push_back(ndx::gridOf(inputs[i]));
    const bool matrix = inputs[i].isArray || inputs[i].isMatrix || inputs[i].isND();
    if (!matrix)
      continue;
    if (!anyMatrix) {
      shape = grids.back().shape;
      anyMatrix = true;
    } else if (grids.back().shape != shape) {
      ctx.fail("the inputs must have the same size, or be single values (got " +
               nd::shapeText(shape) + " and " + nd::shapeText(grids.back().shape) + ")");
      return Value(0.0);
    }
  }
  const size_t n = nd::countOf(shape);
  std::vector<Value> out;
  out.reserve(n);
  std::vector<Value> elems(inputs.size());
  for (size_t k = 0; k < n; k++) {
    for (size_t i = 0; i < grids.size(); i++)
      elems[i] = grids[i].cells[grids[i].count() == 1 ? 0 : k];
    Value r;
    if (!fn(elems, r, ctx))
      return Value(0.0);
    out.push_back(std::move(r));
  }
  if (!anyMatrix)
    return out.empty() ? Value(0.0) : out[0];
  if (!ndx::unifyCells(out, ctx))
    return Value(0.0);
  return ndx::valueOf(Grid{shape, out});
}

inline void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
                const char *numpyName, Impl impl, bool acceptsComplex = false) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::WorkingWithData;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = acceptsComplex;
  reg.add(std::move(spec));
}

void registerValueFunctions(Registry &reg);
void registerTextFunctions(Registry &reg);

} // namespace wd
} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_WD_COMMON_H
