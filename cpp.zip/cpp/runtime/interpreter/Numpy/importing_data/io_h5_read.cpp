// HDF5 reader (see io_h5.h).
#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <functional>

#include "io_bytes.h"
#include "io_deflate.h"
#include "io_h5.h"

namespace nc {
namespace io {

namespace {

const char SIG[8] = {'\x89', 'H', 'D', 'F', '\r', '\n', '\x1a', '\n'};

int bytesFor(uint64_t n) { // minimal bytes to hold n
  int b = 1;
  while (b < 8 && (n >> (8 * b))) b++;
  return b;
}
int log2floor(uint64_t n) {
  int r = 0;
  while (n >>= 1) r++;
  return r;
}

} // namespace

size_t H5Value::count() const {
  size_t n = 1;
  for (size_t s : shape) n *= s;
  return n;
}

const H5Attr *H5Object::attr(const std::string &n) const {
  for (const auto &a : attrs) if (a.name == n) return &a;
  return nullptr;
}
const H5Object *H5Object::child(const std::string &n) const {
  for (const auto &k : kids) if (k.name == n) return &k;
  return nullptr;
}

std::string H5Type::name() const {
  switch (cls) {
  case Fixed: case Bitfield: case Time: return (sign && cls == Fixed ? "int" : "uint") + std::to_string(size * 8);
  case Float: return "float" + std::to_string(size * 8);
  case String: return "str";
  case VarLen: return vlenString ? "vlen_str" : "vlen";
  case Compound: return "compound";
  case Reference: return "ref";
  case Enum: return members.empty() ? "enum" : (memberNames.size() == 2 && members[0].size == 1 ? "bool" : "enum");
  case Array: return "array";
  case Opaque: return "opaque";
  }
  return "unknown";
}

uint64_t H5Reader::off(size_t p) const { return getLE(*b_, p, so_); }
uint64_t H5Reader::len(size_t p) const { return getLE(*b_, p, sl_); }
bool H5Reader::inRange(uint64_t addr, uint64_t n) const {
  return addr != H5_UNDEF && base_ + addr <= b_->size() && n <= b_->size() - (base_ + addr);
}

// ---- object headers ---------------------------------------------------------------------

bool H5Reader::messages(uint64_t addr, std::vector<Msg> &out, std::string &err) const {
  const std::string &b = *b_;
  if (!inRange(addr, 16)) { err = "object header address is outside the file"; return false; }
  size_t p = static_cast<size_t>(base_ + addr);
  std::vector<std::pair<size_t, size_t>> chunks; // absolute start, length
  bool v2 = b.compare(p, 4, "OHDR") == 0;
  int flags = 0;
  if (v2) {
    flags = static_cast<unsigned char>(b[p + 5]);
    size_t q = p + 6;
    if (flags & 0x20) q += 16;
    if (flags & 0x10) q += 4;
    int w = 1 << (flags & 3);
    uint64_t size0 = getLE(b, q, w);
    q += w;
    chunks.push_back({q, static_cast<size_t>(size0)});
  } else {
    if (b[p] != 1) { err = "unknown object header version " + std::to_string(static_cast<int>(b[p])); return false; }
    uint32_t size = static_cast<uint32_t>(getLE(b, p + 8, 4));
    chunks.push_back({p + 16, size});
  }
  for (size_t ci = 0; ci < chunks.size() && ci < 10000; ci++) {
    size_t q = chunks[ci].first, end = q + chunks[ci].second;
    if (end > b.size()) { err = "object header runs past the end of the file"; return false; }
    if (v2 && ci > 0) { q += 4; } // "OCHK"
    size_t stop = v2 && ci > 0 ? end - 4 : end; // chunk #0's size leaves out its checksum; OCHK lengths include it
    while (q < stop) {
      int type, mflags;
      size_t size;
      if (v2) {
        if (stop - q < 4) break;
        type = static_cast<unsigned char>(b[q]);
        size = u16le(b, q + 1);
        mflags = static_cast<unsigned char>(b[q + 3]);
        q += 4;
        if (flags & 0x04) q += 2;
      } else {
        if (stop - q < 8) break;
        type = u16le(b, q);
        size = u16le(b, q + 2);
        mflags = static_cast<unsigned char>(b[q + 4]);
        q += 8;
      }
      if (q + size > stop) break;
      std::string data = b.substr(q, size);
      q += size;
      if (type == 0x10) {
        uint64_t a = getLE(data, 0, so_), l = getLE(data, so_, sl_);
        if (inRange(a, l)) chunks.push_back({static_cast<size_t>(base_ + a), static_cast<size_t>(l)});
        continue;
      }
      if (mflags & 0x02) { // shared message: fetch it from the object header it points to
        int ver = static_cast<unsigned char>(data[0]);
        uint64_t a = ver == 1 ? getLE(data, 8, so_) : getLE(data, 2, so_);
        if ((ver == 3 && data[1] != 2) || !inRange(a, 1)) continue; // shared in the SOHM heap: not built in
        std::vector<Msg> other;
        if (!messages(a, other, err)) return false;
        for (auto &m : other) if (m.type == type) { out.push_back(m); break; }
        continue;
      }
      out.push_back({type, std::move(data)});
    }
  }
  return true;
}

// ---- datatypes, dataspaces, attributes ------------------------------------------------

bool H5Reader::parseType(const std::string &d, size_t &p, H5Type &t, std::string &err) const {
  if (p + 8 > d.size()) { err = "datatype message is cut short"; return false; }
  int cv = static_cast<unsigned char>(d[p]);
  t = H5Type();
  t.cls = cv & 0x0F;
  int ver = cv >> 4;
  uint32_t flags = static_cast<uint32_t>(getLE(d, p + 1, 3));
  t.size = static_cast<size_t>(getLE(d, p + 4, 4));
  p += 8;
  switch (t.cls) {
  case H5Type::Fixed: case H5Type::Bitfield:
    t.bigEndian = flags & 1;
    t.sign = t.cls == H5Type::Fixed && (flags & 8);
    p += 4;
    break;
  case H5Type::Float:
    t.bigEndian = flags & 1;
    p += 12;
    break;
  case H5Type::Time:
    t.bigEndian = flags & 1;
    t.sign = false;
    p += 2;
    break;
  case H5Type::String:
    t.strPad = flags & 0x0F;
    break;
  case H5Type::Opaque:
    p += (flags & 0xFF);
    break;
  case H5Type::Compound: {
    size_t n = flags & 0xFFFF;
    for (size_t k = 0; k < n; k++) {
      size_t e = d.find('\0', p);
      if (e == std::string::npos) { err = "compound member name is cut short"; return false; }
      std::string name = d.substr(p, e - p);
      p = ver < 3 ? p + ((e - p) / 8 + 1) * 8 : e + 1;
      size_t offset;
      if (ver < 3) { offset = static_cast<size_t>(getLE(d, p, 4)); p += 4; }
      else { int w = bytesFor(t.size); offset = static_cast<size_t>(getLE(d, p, w)); p += w; }
      std::vector<size_t> adims;
      if (ver == 1) {
        int nd = static_cast<unsigned char>(d[p]);
        p += 12;
        for (int i = 0; i < 4; i++) { if (i < nd) adims.push_back(static_cast<size_t>(getLE(d, p, 4))); p += 4; }
      }
      H5Type m;
      if (!parseType(d, p, m, err)) return false;
      if (!adims.empty()) { H5Type a; a.cls = H5Type::Array; a.arrayDims = adims; a.size = m.size; for (size_t x : adims) a.size *= x; a.members.push_back(m); m = a; }
      t.memberNames.push_back(name);
      t.memberOffsets.push_back(offset);
      t.members.push_back(m);
    }
    break;
  }
  case H5Type::Reference:
    if ((flags & 0x0F) != 0) t.cls = H5Type::Opaque; // region references are kept raw
    break;
  case H5Type::Enum: {
    size_t n = flags & 0xFFFF;
    H5Type base;
    if (!parseType(d, p, base, err)) return false;
    t.members.push_back(base);
    for (size_t k = 0; k < n; k++) {
      size_t e = d.find('\0', p);
      if (e == std::string::npos) { err = "enum name is cut short"; return false; }
      t.memberNames.push_back(d.substr(p, e - p));
      p = ver < 3 ? p + ((e - p) / 8 + 1) * 8 : e + 1;
    }
    for (size_t k = 0; k < n; k++) {
      H5Value v;
      if (!decode(base, d.data() + p, 1, v, err)) return false;
      t.enumValues.push_back(v.nums.empty() ? 0 : v.nums[0]);
      p += base.size;
    }
    break;
  }
  case H5Type::VarLen: {
    t.vlenString = (flags & 0x0F) == 1;
    H5Type base;
    if (!parseType(d, p, base, err)) return false;
    t.members.push_back(base);
    break;
  }
  case H5Type::Array: {
    int nd = static_cast<unsigned char>(d[p]);
    p += ver < 3 ? 4 : 1;
    for (int i = 0; i < nd; i++) { t.arrayDims.push_back(static_cast<size_t>(getLE(d, p, 4))); p += 4; }
    if (ver < 3) p += 4 * nd;
    H5Type base;
    if (!parseType(d, p, base, err)) return false;
    t.members.push_back(base);
    break;
  }
  default:
    err = "unknown datatype class " + std::to_string(t.cls);
    return false;
  }
  return true;
}

bool H5Reader::parseSpace(const std::string &d, size_t p, std::vector<uint64_t> &dims, std::vector<uint64_t> &maxDims,
                          bool &scalar) const {
  if (p + 4 > d.size()) return false;
  int ver = static_cast<unsigned char>(d[p]);
  int rank = static_cast<unsigned char>(d[p + 1]);
  int flags = static_cast<unsigned char>(d[p + 2]);
  dims.clear();
  maxDims.clear();
  size_t q;
  if (ver == 1) q = p + 8;
  else {
    q = p + 4;
    if (d[p + 3] == 2) { scalar = false; dims.push_back(0); return true; } // null dataspace
  }
  scalar = rank == 0;
  for (int i = 0; i < rank; i++) { dims.push_back(getLE(d, q, sl_)); q += sl_; }
  if (flags & 1) for (int i = 0; i < rank; i++) { maxDims.push_back(getLE(d, q, sl_)); q += sl_; }
  return true;
}

bool H5Reader::parseAttr(const std::string &d, H5Attr &a, std::string &err) const {
  int ver = static_cast<unsigned char>(d[0]);
  int flags = static_cast<unsigned char>(d[1]);
  size_t nameSize = u16le(d, 2), typeSize = u16le(d, 4), spaceSize = u16le(d, 6);
  size_t p = ver == 3 ? 9 : 8;
  auto pad = [&](size_t n) { return ver == 1 ? (n + 7) / 8 * 8 : n; };
  a.name = d.substr(p, nameSize ? nameSize - 1 : 0);
  p += pad(nameSize);
  size_t tp = p;
  if (flags & 1) { // shared (committed) datatype
    int sv = static_cast<unsigned char>(d[tp]);
    uint64_t addr = sv == 1 ? getLE(d, tp + 8, so_) : getLE(d, tp + 2, so_);
    std::vector<Msg> ms;
    if (!messages(addr, ms, err)) return false;
    bool found = false;
    for (const auto &m : ms) if (m.type == 3) { size_t q = 0; if (!parseType(m.data, q, a.type, err)) return false; found = true; break; }
    if (!found) { err = "attribute '" + a.name + "' uses a committed datatype that was not found"; return false; }
  } else if (!parseType(d, tp, a.type, err)) return false;
  p += pad(typeSize);
  std::vector<uint64_t> dims, maxDims;
  bool scalar = false;
  if (flags & 2) { scalar = true; }
  else if (!parseSpace(d, p, dims, maxDims, scalar)) { err = "attribute '" + a.name + "' has a bad dataspace"; return false; }
  p += pad(spaceSize);
  size_t n = 1;
  for (auto x : dims) n *= static_cast<size_t>(x);
  if (p + n * a.type.size > d.size()) n = a.type.size ? (d.size() - std::min(p, d.size())) / a.type.size : 0;
  if (!decode(a.type, d.data() + p, n, a.value, err)) return false;
  a.value.shape.clear();
  for (auto x : dims) a.value.shape.push_back(static_cast<size_t>(x));
  return true;
}

bool H5Reader::gheapObject(uint64_t coll, uint32_t index, std::string &out, std::string &err) const {
  auto it = gheaps_.find(coll);
  if (it == gheaps_.end()) {
    std::vector<std::pair<uint32_t, std::string>> objs;
    if (!inRange(coll, 16) || b_->compare(static_cast<size_t>(base_ + coll), 4, "GCOL") != 0) { err = "global heap collection not found"; return false; }
    size_t p = static_cast<size_t>(base_ + coll);
    uint64_t size = getLE(*b_, p + 8, sl_);
    size_t end = static_cast<size_t>(std::min<uint64_t>(p + size, b_->size()));
    size_t q = p + 8 + sl_;
    while (q + 8 + sl_ <= end) {
      uint32_t idx = u16le(*b_, q);
      uint64_t sz = getLE(*b_, q + 8, sl_);
      if (idx == 0) break;
      size_t dataAt = q + 8 + sl_;
      if (dataAt + sz > end) break;
      objs.push_back({idx, b_->substr(dataAt, static_cast<size_t>(sz))});
      q = dataAt + static_cast<size_t>((sz + 7) / 8 * 8);
    }
    it = gheaps_.emplace(coll, std::move(objs)).first;
  }
  for (const auto &o : it->second) if (o.first == index) { out = o.second; return true; }
  out.clear();
  return true; // missing object = empty
}

// n elements of type t at p -> out (flat)
bool H5Reader::decode(const H5Type &t, const char *p, size_t n, H5Value &out, std::string &err) const {
  out.shape = {n};
  auto intAt = [&](const char *q, size_t size, bool sign, bool be) {
    uint64_t v = 0;
    for (size_t k = 0; k < size && k < 8; k++) {
      size_t idx = be ? size - 1 - k : k;
      v |= static_cast<uint64_t>(static_cast<unsigned char>(q[idx])) << (8 * k);
    }
    if (sign && size < 8 && (v >> (8 * size - 1)) & 1) v |= ~0ull << (8 * size);
    return sign ? static_cast<double>(static_cast<int64_t>(v)) : static_cast<double>(v);
  };
  switch (t.cls) {
  case H5Type::Fixed: case H5Type::Bitfield: case H5Type::Time: case H5Type::Enum: {
    const H5Type &bt = t.cls == H5Type::Enum && !t.members.empty() ? t.members[0] : t;
    out.nums.resize(n);
    for (size_t i = 0; i < n; i++) out.nums[i] = intAt(p + i * t.size, bt.size, bt.sign, bt.bigEndian);
    return true;
  }
  case H5Type::Float: {
    out.nums.resize(n);
    for (size_t i = 0; i < n; i++) {
      const char *q = p + i * t.size;
      char tmp[8];
      for (size_t k = 0; k < t.size && k < 8; k++) tmp[k] = t.bigEndian ? q[t.size - 1 - k] : q[k];
      if (t.size == 8) { double d; std::memcpy(&d, tmp, 8); out.nums[i] = d; }
      else if (t.size == 4) { float f; std::memcpy(&f, tmp, 4); out.nums[i] = f; }
      else if (t.size == 2) {
        uint16_t h = static_cast<uint16_t>(static_cast<unsigned char>(tmp[0]) | (static_cast<unsigned char>(tmp[1]) << 8));
        int e = (h >> 10) & 31, m = h & 1023;
        double v = e == 0 ? std::ldexp(m, -24) : e == 31 ? (m ? std::nan("") : INFINITY) : std::ldexp(m + 1024, e - 25);
        out.nums[i] = (h & 0x8000) ? -v : v;
      } else out.nums[i] = std::nan("");
    }
    return true;
  }
  case H5Type::String: {
    out.isText = true;
    out.strs.resize(n);
    for (size_t i = 0; i < n; i++) {
      std::string s(p + i * t.size, t.size);
      size_t z = s.find('\0');
      if (z != std::string::npos) s.resize(z);
      if (t.strPad == 2) while (!s.empty() && s.back() == ' ') s.pop_back();
      out.strs[i] = s;
    }
    return true;
  }
  case H5Type::Reference: {
    out.isRef = true;
    out.nums.resize(n);
    for (size_t i = 0; i < n; i++) out.nums[i] = static_cast<double>(getLE(std::string(p + i * t.size, t.size), 0, std::min<int>(so_, static_cast<int>(t.size))));
    return true;
  }
  case H5Type::VarLen: {
    size_t es = 4 + so_ + 4;
    if (t.vlenString) { out.isText = true; out.strs.resize(n); }
    else { out.isVlen = true; out.items.resize(n); }
    for (size_t i = 0; i < n; i++) {
      std::string e(p + i * es, es);
      uint32_t cnt = static_cast<uint32_t>(getLE(e, 0, 4));
      uint64_t coll = getLE(e, 4, so_);
      uint32_t idx = static_cast<uint32_t>(getLE(e, 4 + so_, 4));
      std::string obj;
      if (cnt && coll && coll != H5_UNDEF && !gheapObject(coll, idx, obj, err)) return false;
      if (t.vlenString) {
        size_t z = obj.find('\0');
        out.strs[i] = obj.substr(0, std::min(z, static_cast<size_t>(cnt)));
      } else {
        const H5Type &base = t.members[0];
        size_t m = base.size ? std::min<size_t>(cnt, obj.size() / base.size) : 0;
        if (!decode(base, obj.data(), m, out.items[i], err)) return false;
      }
    }
    return true;
  }
  case H5Type::Compound: {
    out.isCompound = true;
    out.fieldNames = t.memberNames;
    out.fields.resize(t.members.size());
    for (size_t f = 0; f < t.members.size(); f++) {
      std::string col(n * t.members[f].size, '\0');
      for (size_t i = 0; i < n; i++) std::memcpy(&col[i * t.members[f].size], p + i * t.size + t.memberOffsets[f], t.members[f].size);
      if (!decode(t.members[f], col.data(), n, out.fields[f], err)) return false;
    }
    return true;
  }
  case H5Type::Array: {
    size_t per = 1;
    for (size_t d : t.arrayDims) per *= d;
    if (!decode(t.members[0], p, n * per, out, err)) return false;
    out.shape = {n};
    for (size_t d : t.arrayDims) out.shape.push_back(d);
    return true;
  }
  default: // opaque: NaN placeholders
    out.nums.assign(n, std::nan(""));
    return true;
  }
}

// ---- groups -------------------------------------------------------------------------------

bool H5Reader::symbolTable(uint64_t btree, uint64_t heap, H5Object &o, int depth, std::string &err) {
  const std::string &b = *b_;
  if (!inRange(heap, 8 + 2 * sl_ + so_) || b.compare(static_cast<size_t>(base_ + heap), 4, "HEAP") != 0) { err = "group name heap not found"; return false; }
  size_t hp = static_cast<size_t>(base_ + heap);
  uint64_t dataAddr = off(hp + 8 + 2 * sl_);
  if (!inRange(dataAddr, 0)) { err = "group name heap data is outside the file"; return false; }
  size_t names = static_cast<size_t>(base_ + dataAddr);
  std::function<bool(uint64_t, int)> node = [&](uint64_t addr, int guard) -> bool {
    if (guard > 64) { err = "group B-tree is too deep"; return false; }
    if (!inRange(addr, 24) ) { err = "group B-tree node is outside the file"; return false; }
    size_t p = static_cast<size_t>(base_ + addr);
    if (b.compare(p, 4, "TREE") == 0) {
      int level = static_cast<unsigned char>(b[p + 5]);
      size_t n = u16le(b, p + 6);
      size_t q = p + 8 + 2 * so_;
      for (size_t i = 0; i < n; i++) {
        q += sl_; // key
        uint64_t child = off(q);
        q += so_;
        if (level > 0 ? !node(child, guard + 1) : !node(child, guard + 1)) return false;
      }
      return true;
    }
    if (b.compare(p, 4, "SNOD") == 0) {
      size_t n = u16le(b, p + 6);
      size_t q = p + 8;
      for (size_t i = 0; i < n; i++) {
        H5Object kid;
        uint64_t nameOff = off(q);
        kid.addr = off(q + so_);
        uint32_t cache = static_cast<uint32_t>(getLE(b, q + 2 * so_, 4));
        size_t np = names + static_cast<size_t>(nameOff);
        if (np < b.size()) kid.name = std::string(b.c_str() + np);
        if (cache == 2) { // symbolic link
          uint32_t lo = static_cast<uint32_t>(getLE(b, q + 2 * so_ + 8, 4));
          if (names + lo < b.size()) kid.softTarget = std::string(b.c_str() + names + lo);
        }
        q += 2 * so_ + 8 + 16;
        o.kids.push_back(std::move(kid));
      }
      return true;
    }
    err = "unknown group B-tree node";
    return false;
  };
  if (!node(btree, 0)) return false;
  for (auto &k : o.kids) {
    k.path = (o.path == "/" ? "" : o.path) + "/" + k.name;
    if (k.softTarget.empty() && !loadObject(k, depth + 1, err)) return false;
  }
  return true;
}

bool H5Reader::parseLink(const std::string &d, size_t p, H5Object &kid) const {
  if (p + 2 > d.size()) return false;
  int flags = static_cast<unsigned char>(d[p + 1]);
  size_t q = p + 2;
  int type = 0;
  if (flags & 0x08) type = static_cast<unsigned char>(d[q++]);
  if (flags & 0x04) q += 8;
  if (flags & 0x10) q++;
  int w = 1 << (flags & 3);
  size_t nlen = static_cast<size_t>(getLE(d, q, w));
  q += w;
  if (q + nlen > d.size()) return false;
  kid.name = d.substr(q, nlen);
  q += nlen;
  if (type == 0) kid.addr = getLE(d, q, so_);
  else if (type == 1) { size_t l = u16le(d, q); kid.softTarget = d.substr(q + 2, l); }
  else { kid.softTarget = "(external link)"; }
  return true;
}

// Every object of a fractal heap reachable from a v2 B-tree name index.
bool H5Reader::heapObjects(uint64_t heapAddr, uint64_t btreeAddr, bool attrs, std::vector<std::string> &out,
                           std::string &err) const {
  const std::string &b = *b_;
  if (!inRange(heapAddr, 64) || b.compare(static_cast<size_t>(base_ + heapAddr), 4, "FRHP") != 0) { err = "fractal heap not found"; return false; }
  size_t h = static_cast<size_t>(base_ + heapAddr) + 5;
  size_t idLen = u16le(b, h);
  size_t filterLen = u16le(b, h + 2);
  h += 5; // id len, filter len, flags
  uint32_t maxManaged = static_cast<uint32_t>(getLE(b, h, 4));
  h += 4;
  h += sl_ + so_ + sl_ + so_ + sl_ * 8; // next huge id .. number tiny
  size_t width = u16le(b, h);
  h += 2;
  uint64_t startBlock = len(h); h += sl_;
  uint64_t maxDirect = len(h); h += sl_;
  int maxHeapBits = u16le(b, h); h += 2;
  h += 2; // starting rows
  uint64_t rootAddr = off(h); h += so_;
  size_t curRows = u16le(b, h);
  if (filterLen) { err = "filtered fractal heaps are not built in"; return false; }
  size_t offBytes = static_cast<size_t>((maxHeapBits + 7) / 8);
  size_t lenBytes = std::min<size_t>(static_cast<size_t>(bytesFor(maxDirect - 1)), static_cast<size_t>(bytesFor(maxManaged)));
  int maxDirectRows = log2floor(maxDirect) - log2floor(startBlock) + 2;
  auto rowSize = [&](size_t r) { return r < 2 ? startBlock : startBlock << (r - 1); };
  // heap offset -> file address
  std::function<uint64_t(uint64_t, uint64_t, size_t, uint64_t)> locate = [&](uint64_t blockAddr, uint64_t blockOff, size_t nrows, uint64_t target) -> uint64_t {
    if (!inRange(blockAddr, 5 + so_ + offBytes)) return H5_UNDEF;
    size_t p = static_cast<size_t>(base_ + blockAddr) + 5 + so_ + offBytes; // FHIB, version, header addr, block offset
    size_t directRows = std::min<size_t>(nrows, static_cast<size_t>(maxDirectRows));
    uint64_t start = blockOff;
    size_t entry = 0;
    for (size_t r = 0; r < nrows; r++) {
      for (size_t c = 0; c < width; c++, entry++) {
        uint64_t sz = rowSize(r);
        size_t ep = r < directRows ? p + entry * so_ : p + directRows * width * so_ + (entry - directRows * width) * so_;
        uint64_t child = off(ep);
        if (target >= start && target < start + sz) {
          if (child == H5_UNDEF) return H5_UNDEF;
          if (r < directRows) return child + (target - start);
          size_t childRows = static_cast<size_t>(log2floor(sz) - log2floor(startBlock * width) + 1);
          return locate(child, start, childRows, target);
        }
        start += sz;
      }
    }
    return H5_UNDEF;
  };
  auto object = [&](const std::string &id, std::string &obj) -> bool {
    int type = (static_cast<unsigned char>(id[0]) >> 4) & 3;
    if (type == 2) { size_t n = (static_cast<unsigned char>(id[0]) & 0x0F) + 1; obj = id.substr(1, n); return true; }
    if (type != 0) { err = "huge fractal heap objects are not built in"; return false; }
    uint64_t o = getLE(id, 1, static_cast<int>(offBytes));
    uint64_t l = getLE(id, 1 + offBytes, static_cast<int>(lenBytes));
    uint64_t a = curRows == 0 ? rootAddr + o : locate(rootAddr, 0, curRows, o);
    if (!inRange(a, l)) { err = "fractal heap object is outside the file"; return false; }
    obj = b.substr(static_cast<size_t>(base_ + a), static_cast<size_t>(l));
    return true;
  };
  // v2 B-tree
  if (!inRange(btreeAddr, 16) || b.compare(static_cast<size_t>(base_ + btreeAddr), 4, "BTHD") != 0) { err = "v2 B-tree not found"; return false; }
  size_t t = static_cast<size_t>(base_ + btreeAddr) + 6;
  uint32_t nodeSize = static_cast<uint32_t>(getLE(b, t, 4));
  size_t recSize = u16le(b, t + 4);
  int depth = u16le(b, t + 6);
  uint64_t root = off(t + 10);
  size_t rootN = u16le(b, t + 10 + so_);
  std::vector<uint64_t> maxN(depth + 1), cumMax(depth + 1);
  std::vector<int> cumSize(depth + 1);
  maxN[0] = (nodeSize - 10) / recSize;
  cumMax[0] = maxN[0];
  cumSize[0] = 0;
  int maxNrecSize = log2floor(maxN[0]) / 8 + 1;
  for (int u = 1; u <= depth; u++) {
    size_t ptr = so_ + maxNrecSize + (u > 1 ? cumSize[u - 1] : 0);
    maxN[u] = (nodeSize - 10 - ptr) / (recSize + ptr);
    cumMax[u] = (maxN[u] + 1) * cumMax[u - 1] + maxN[u];
    cumSize[u] = log2floor(cumMax[u]) / 8 + 1;
  }
  std::function<bool(uint64_t, size_t, int, int)> walk = [&](uint64_t addr, size_t n, int d, int guard) -> bool {
    if (guard > 64 || !inRange(addr, 6 + n * recSize)) { err = "v2 B-tree node is outside the file"; return false; }
    size_t p = static_cast<size_t>(base_ + addr) + 6;
    for (size_t i = 0; i < n; i++) {
      std::string rec = b.substr(p + i * recSize, recSize);
      std::string id = attrs ? rec.substr(0, idLen) : rec.substr(4, idLen);
      std::string obj;
      if (!object(id, obj)) return false;
      out.push_back(std::move(obj));
    }
    if (d == 0) return true;
    size_t q = p + n * recSize;
    for (size_t i = 0; i <= n; i++) {
      uint64_t child = off(q);
      q += so_;
      size_t cn = static_cast<size_t>(getLE(b, q, maxNrecSize));
      q += maxNrecSize;
      if (d > 1) q += cumSize[d - 1];
      if (!walk(child, cn, d - 1, guard + 1)) return false;
    }
    return true;
  };
  if (root == H5_UNDEF || rootN == 0) return true;
  return walk(root, rootN, depth, 0);
}

bool H5Reader::denseLinks(uint64_t heap, uint64_t btree, H5Object &o, std::string &err) {
  std::vector<std::string> objs;
  if (!heapObjects(heap, btree, false, objs, err)) return false;
  for (const auto &m : objs) {
    H5Object kid;
    if (parseLink(m, 0, kid)) o.kids.push_back(std::move(kid));
  }
  return true;
}

bool H5Reader::denseAttrs(uint64_t heap, uint64_t btree, H5Object &o, std::string &err) const {
  std::vector<std::string> objs;
  if (!heapObjects(heap, btree, true, objs, err)) return false;
  for (const auto &m : objs) {
    H5Attr a;
    if (!parseAttr(m, a, err)) return false;
    o.attrs.push_back(std::move(a));
  }
  return true;
}

bool H5Reader::loadObject(H5Object &o, int depth, std::string &err) {
  if (depth > 64) { err = "groups are nested too deeply (or a link loop)"; return false; }
  std::vector<Msg> ms;
  if (!messages(o.addr, ms, err)) return false;
  bool haveType = false;
  const std::string *cur = nullptr;
  auto dOff = [&](size_t p) { return getLE(*cur, p, so_); };
  auto dLen = [&](size_t p) { return getLE(*cur, p, sl_); };
  for (const auto &m : ms) {
    const std::string &d = m.data;
    cur = &d;
    switch (m.type) {
    case 0x01: parseSpace(d, 0, o.dims, o.maxDims, o.scalar); break;
    case 0x03: { size_t p = 0; if (!parseType(d, p, o.type, err)) return false; haveType = true; break; }
    case 0x04: if (o.fill.empty() && d.size() >= 4) o.fill = d.substr(4, static_cast<size_t>(getLE(d, 0, 4))); break;
    case 0x05: {
      int ver = static_cast<unsigned char>(d[0]);
      if (ver == 1 && d.size() >= 8) { uint32_t s = static_cast<uint32_t>(getLE(d, 4, 4)); if (s) o.fill = d.substr(8, s); }
      else if (ver == 2 && d.size() >= 4 && d[3]) { uint32_t s = static_cast<uint32_t>(getLE(d, 4, 4)); o.fill = d.substr(8, s); }
      else if (ver == 3 && d.size() >= 2 && (d[1] & 0x20)) { uint32_t s = static_cast<uint32_t>(getLE(d, 2, 4)); o.fill = d.substr(6, s); }
      break;
    }
    case 0x08: {
      int ver = static_cast<unsigned char>(d[0]);
      if (ver < 3) {
        int nd = static_cast<unsigned char>(d[1]);
        o.layout = static_cast<unsigned char>(d[2]);
        size_t p = 8;
        if (o.layout != 0) { o.dataAddr = dOff(p); p += so_; }
        o.chunk.clear();
        for (int i = 0; i < nd; i++) { o.chunk.push_back(getLE(d, p, 4)); p += 4; }
        if (o.layout == 2 && !o.chunk.empty()) o.chunk.pop_back();
        if (o.layout == 0) { uint32_t s = static_cast<uint32_t>(getLE(d, p, 4)); o.compact = d.substr(p + 4, s); }
        if (o.layout == 1) o.chunk.clear();
      } else {
        o.layout = static_cast<unsigned char>(d[1]);
        if (o.layout == 0) { size_t s = u16le(d, 2); o.compact = d.substr(4, s); }
        else if (o.layout == 1) { o.dataAddr = dOff(2); o.dataSize = dLen(2 + so_); }
        else if (o.layout == 2 && ver == 3) {
          int nd = static_cast<unsigned char>(d[2]);
          o.dataAddr = dOff(3);
          size_t p = 3 + so_;
          o.chunk.clear();
          for (int i = 0; i < nd - 1; i++) { o.chunk.push_back(getLE(d, p, 4)); p += 4; }
          o.chunkIndex = 0;
        } else if (o.layout == 2) {
          int flags = static_cast<unsigned char>(d[2]);
          int nd = static_cast<unsigned char>(d[3]);
          int w = static_cast<unsigned char>(d[4]);
          size_t p = 5;
          o.chunk.clear();
          for (int i = 0; i < nd - 1; i++) { o.chunk.push_back(getLE(d, p, w)); p += w; }
          p += w;
          o.chunkIndex = static_cast<unsigned char>(d[p++]);
          if (o.chunkIndex == 1 && (flags & 2)) { o.singleFiltered = dLen(p); p += sl_; o.singleMask = static_cast<uint32_t>(getLE(d, p, 4)); p += 4; }
          else if (o.chunkIndex == 3) p += 1;
          else if (o.chunkIndex == 4) p += 5;
          else if (o.chunkIndex == 5) p += 6;
          o.dataAddr = dOff(p);
        } else {
          err = "virtual datasets are not built in";
          return false;
        }
      }
      break;
    }
    case 0x0B: {
      int ver = static_cast<unsigned char>(d[0]);
      int n = static_cast<unsigned char>(d[1]);
      size_t p = ver == 1 ? 8 : 2;
      for (int i = 0; i < n && p + 6 <= d.size(); i++) {
        H5Filter f;
        f.id = u16le(d, p);
        p += 2;
        size_t nameLen = 0;
        if (ver == 1 || f.id >= 256) { nameLen = u16le(d, p); p += 2; }
        f.optional = u16le(d, p) & 1;
        size_t nv = u16le(d, p + 2);
        p += 4;
        p += ver == 1 ? (nameLen + 7) / 8 * 8 : nameLen;
        for (size_t k = 0; k < nv; k++) { f.values.push_back(static_cast<uint32_t>(getLE(d, p, 4))); p += 4; }
        if (ver == 1 && (nv & 1)) p += 4;
        o.filters.push_back(f);
      }
      break;
    }
    case 0x0C: { H5Attr a; if (!parseAttr(d, a, err)) return false; o.attrs.push_back(std::move(a)); break; }
    case 0x15: {
      int flags = static_cast<unsigned char>(d[1]);
      size_t p = 2 + ((flags & 1) ? 2 : 0);
      uint64_t heap = dOff(p), bt = dOff(p + so_);
      if (heap != H5_UNDEF && bt != H5_UNDEF && !denseAttrs(heap, bt, o, err)) return false;
      break;
    }
    case 0x11: o.group = true; if (!symbolTable(dOff(0), dOff(so_), o, depth, err)) return false; break;
    case 0x06: { o.group = true; H5Object kid; if (parseLink(d, 0, kid)) o.kids.push_back(std::move(kid)); break; }
    case 0x02: {
      o.group = true;
      int flags = static_cast<unsigned char>(d[1]);
      size_t p = 2 + ((flags & 1) ? 8 : 0);
      uint64_t heap = dOff(p), bt = dOff(p + so_);
      if (heap != H5_UNDEF && bt != H5_UNDEF && !denseLinks(heap, bt, o, err)) return false;
      break;
    }
    case 0x0A: o.group = true; break; // group info
    default: break;
    }
  }
  if (!haveType && !o.group) o.group = true; // a committed datatype / empty object: shown as a group
  if (o.group) {
    std::sort(o.kids.begin(), o.kids.end(), [](const H5Object &a, const H5Object &b) { return a.name < b.name; });
    for (auto &k : o.kids) {
      if (!k.path.empty()) continue; // loaded by symbolTable
      k.path = (o.path == "/" ? "" : o.path) + "/" + k.name;
      if (k.softTarget.empty() && !loadObject(k, depth + 1, err)) return false;
    }
  }
  return true;
}

void H5Reader::index(const H5Object &o) {
  byAddr_[o.addr] = &o;
  for (const auto &k : o.kids) index(k);
}

bool H5Reader::open(const std::string &bytes, std::string &err) {
  b_ = &bytes;
  size_t sp = std::string::npos;
  for (size_t at = 0; at + 8 <= bytes.size(); at = at ? at * 2 : 512) {
    if (std::memcmp(bytes.data() + at, SIG, 8) == 0) { sp = at; break; }
    if (at > (1u << 30)) break;
  }
  if (sp == std::string::npos) {
    if (bytes.size() >= 4 && static_cast<unsigned char>(bytes[0]) == 0x0E && bytes[1] == 0x03 && bytes[2] == 0x13 && bytes[3] == 0x01)
      err = "this is an HDF4 file - HDF4 is not built in (convert it with h4toh5, or save it as HDF5)";
    else
      err = "not an HDF5 file (no HDF5 signature found)";
    return false;
  }
  userblock = sp;
  superVersion = static_cast<unsigned char>(bytes[sp + 8]);
  uint64_t rootAddr;
  if (superVersion <= 1) {
    so_ = static_cast<unsigned char>(bytes[sp + 13]);
    sl_ = static_cast<unsigned char>(bytes[sp + 14]);
    size_t p = sp + (superVersion == 0 ? 24 : 28);
    uint64_t baseField = getLE(bytes, p, so_);
    base_ = baseField == sp ? sp : sp + baseField;
    p += 4 * so_; // base, free space, eof, driver
    rootAddr = getLE(bytes, p + so_, so_);
  } else if (superVersion <= 3) {
    so_ = static_cast<unsigned char>(bytes[sp + 9]);
    sl_ = static_cast<unsigned char>(bytes[sp + 10]);
    size_t p = sp + 12;
    uint64_t baseField = getLE(bytes, p, so_);
    base_ = baseField == sp ? sp : sp + baseField;
    rootAddr = getLE(bytes, p + 3 * so_, so_);
  } else {
    err = "HDF5 superblock version " + std::to_string(superVersion) + " is not built in";
    return false;
  }
  if ((so_ != 4 && so_ != 8) || (sl_ != 4 && sl_ != 8)) { err = "unsupported HDF5 offset size"; return false; }
  root = H5Object();
  root.name = "/";
  root.path = "/";
  root.addr = rootAddr;
  if (!loadObject(root, 0, err)) return false;
  root.group = true;
  byAddr_.clear();
  index(root);
  return true;
}

const H5Object *H5Reader::find(const std::string &path) const {
  const H5Object *o = &root;
  size_t p = 0;
  while (p < path.size()) {
    size_t e = path.find('/', p);
    if (e == std::string::npos) e = path.size();
    std::string part = path.substr(p, e - p);
    p = e + 1;
    if (part.empty() || part == ".") continue;
    o = o->child(part);
    if (!o) return nullptr;
    if (!o->softTarget.empty() && o->softTarget[0] == '/') { o = find(o->softTarget); if (!o) return nullptr; }
  }
  return o;
}

const H5Object *H5Reader::byAddr(uint64_t addr) const {
  auto it = byAddr_.find(addr);
  return it == byAddr_.end() ? nullptr : it->second;
}

void H5Reader::walk(const H5Object &o, std::vector<const H5Object *> &out) const {
  for (const auto &k : o.kids) {
    out.push_back(&k);
    if (k.group) walk(k, out);
  }
}

// ---- data -------------------------------------------------------------------------------

bool h5Unfilter(const std::vector<H5Filter> &f, uint32_t mask, size_t elemSize, std::string &data, std::string &err) {
  for (size_t i = f.size(); i-- > 0;) {
    if (mask & (1u << i)) continue;
    const H5Filter &x = f[i];
    if (x.id == 1) {
      std::string out;
      if (!zlibDecompress(data, out, err)) { err = "deflate chunk: " + err; return false; }
      data.swap(out);
    } else if (x.id == 2) {
      size_t es = x.values.empty() ? elemSize : x.values[0];
      if (es > 1) {
        size_t n = data.size() / es;
        std::string out(data.size(), '\0');
        for (size_t b = 0; b < es; b++)
          for (size_t k = 0; k < n; k++) out[k * es + b] = data[b * n + k];
        std::memcpy(&out[n * es], data.data() + n * es, data.size() - n * es);
        data.swap(out);
      }
    } else if (x.id == 3) {
      if (data.size() >= 4) data.resize(data.size() - 4);
    } else if (x.id == 32000) {
      size_t outSize = x.values.size() >= 3 ? x.values[2] : data.size() * 4;
      std::string out;
      if (!lzfDecompress(data, outSize, out)) { err = "LZF chunk is corrupt"; return false; }
      data.swap(out);
    } else {
      static const std::map<int, std::string> names = {{4, "szip"}, {5, "nbit"}, {6, "scaleoffset"}, {307, "bzip2"},
                                                      {32001, "blosc"}, {32004, "lz4"}, {32008, "bitshuffle"}, {32015, "zstd"}};
      auto it = names.find(x.id);
      err = "HDF5 filter " + (it == names.end() ? std::to_string(x.id) : "'" + it->second + "'") + " is not built in";
      return false;
    }
  }
  return true;
}

bool H5Reader::chunks(const H5Object &ds, std::vector<std::pair<std::vector<uint64_t>, std::pair<uint64_t, uint64_t>>> &out,
                      std::vector<uint32_t> &masks, std::string &err) const {
  const std::string &b = *b_;
  size_t rank = ds.dims.size();
  uint64_t full = ds.type.size;
  for (auto c : ds.chunk) full *= c;
  std::vector<uint64_t> grid(rank);
  for (size_t d = 0; d < rank; d++) grid[d] = ds.chunk[d] ? (ds.dims[d] + ds.chunk[d] - 1) / ds.chunk[d] : 0;
  auto offsetsOf = [&](uint64_t k) {
    std::vector<uint64_t> o(rank);
    for (size_t d = rank; d-- > 0;) { o[d] = (k % grid[d]) * ds.chunk[d]; k /= grid[d]; }
    return o;
  };
  uint64_t nchunks = 1;
  for (auto g : grid) nchunks *= g;
  if (ds.dataAddr == H5_UNDEF) return true;
  switch (ds.chunkIndex) {
  case 0: {
    std::function<bool(uint64_t, int)> node = [&](uint64_t addr, int guard) -> bool {
      if (guard > 64 || !inRange(addr, 24) || b.compare(static_cast<size_t>(base_ + addr), 4, "TREE") != 0) { err = "chunk B-tree node not found"; return false; }
      size_t p = static_cast<size_t>(base_ + addr);
      int level = static_cast<unsigned char>(b[p + 5]);
      size_t n = u16le(b, p + 6);
      size_t q = p + 8 + 2 * so_;
      size_t keySize = 8 + 8 * (rank + 1);
      for (size_t i = 0; i < n; i++) {
        uint32_t size = static_cast<uint32_t>(getLE(b, q, 4));
        uint32_t mask = static_cast<uint32_t>(getLE(b, q + 4, 4));
        std::vector<uint64_t> o(rank);
        for (size_t d = 0; d < rank; d++) o[d] = getLE(b, q + 8 + 8 * d, 8);
        uint64_t child = off(q + keySize);
        q += keySize + so_;
        if (level > 0) { if (!node(child, guard + 1)) return false; }
        else { out.push_back({o, {child, size}}); masks.push_back(mask); }
      }
      return true;
    };
    return node(ds.dataAddr, 0);
  }
  case 1:
    out.push_back({std::vector<uint64_t>(rank, 0), {ds.dataAddr, ds.singleFiltered ? ds.singleFiltered : full}});
    masks.push_back(ds.singleMask);
    return true;
  case 2:
    for (uint64_t k = 0; k < nchunks; k++) { out.push_back({offsetsOf(k), {ds.dataAddr + k * full, full}}); masks.push_back(0); }
    return true;
  case 3: {
    if (!inRange(ds.dataAddr, 12 + sl_ + so_) || b.compare(static_cast<size_t>(base_ + ds.dataAddr), 4, "FAHD") != 0) { err = "chunk fixed array not found"; return false; }
    size_t p = static_cast<size_t>(base_ + ds.dataAddr);
    int client = static_cast<unsigned char>(b[p + 5]);
    size_t esize = static_cast<unsigned char>(b[p + 6]);
    int pageBits = static_cast<unsigned char>(b[p + 7]);
    uint64_t n = len(p + 8);
    uint64_t db = off(p + 8 + sl_);
    if (!inRange(db, 6 + so_)) { err = "chunk fixed array data block not found"; return false; }
    size_t q = static_cast<size_t>(base_ + db) + 6 + so_;
    uint64_t perPage = 1ull << pageBits;
    bool paged = n > perPage;
    uint64_t npages = paged ? (n + perPage - 1) / perPage : 1;
    if (paged) q += static_cast<size_t>((npages + 7) / 8) + 4;
    for (uint64_t k = 0; k < n && k < nchunks; k++) {
      if (paged && k && k % perPage == 0) q += 4;
      uint64_t a = off(q);
      uint64_t size = full;
      uint32_t mask = 0;
      if (client == 1) { size_t sw = esize - so_ - 4; size = getLE(b, q + so_, static_cast<int>(sw)); mask = static_cast<uint32_t>(getLE(b, q + so_ + sw, 4)); }
      q += esize;
      if (a != H5_UNDEF) { out.push_back({offsetsOf(k), {a, size}}); masks.push_back(mask); }
    }
    return true;
  }
  default:
    err = std::string("chunk index '") + (ds.chunkIndex == 4 ? "extensible array" : "v2 B-tree") +
          "' (HDF5 1.10 \"latest\" format) is not built in - re-save the file with libver='earliest' or h5repack";
    return false;
  }
}

bool H5Reader::readData(const H5Object &ds, const std::vector<std::pair<size_t, size_t>> &rangesIn, H5Value &out,
                        std::string &err) const {
  if (ds.group) { err = "'" + ds.path + "' is a group, not a dataset"; return false; }
  size_t rank = ds.scalar ? 0 : ds.dims.size();
  size_t es = ds.type.size;
  std::vector<std::pair<size_t, size_t>> r = rangesIn;
  for (size_t d = r.size(); d < rank; d++) r.push_back({0, static_cast<size_t>(ds.dims[d])});
  r.resize(rank);
  std::vector<size_t> ns(rank);
  size_t total = 1;
  for (size_t d = 0; d < rank; d++) {
    if (r[d].second > ds.dims[d] || r[d].first > r[d].second) { err = "slice is outside the dataset (" + std::to_string(ds.dims[d]) + " along dim " + std::to_string(d + 1) + ")"; return false; }
    ns[d] = r[d].second - r[d].first;
    total *= ns[d];
  }
  if (total > 0 && es > (8ull << 30) / total) { err = "the selection is too large to read into memory"; return false; }
  std::string buf(total * es, '\0');
  if (!ds.fill.empty() && ds.fill.size() == es)
    for (size_t i = 0; i < total; i++) std::memcpy(&buf[i * es], ds.fill.data(), es);
  // copies the part of a block (origin `o`, extent `ext`, row-major bytes `src`) inside the selection
  auto place = [&](const std::vector<uint64_t> &o, const std::vector<uint64_t> &ext, const char *src, size_t srcSize) {
    std::vector<size_t> lo(rank), hi(rank);
    for (size_t d = 0; d < rank; d++) {
      uint64_t a = std::max<uint64_t>(o[d], r[d].first), z = std::min<uint64_t>(o[d] + ext[d], r[d].second);
      if (a >= z) return;
      lo[d] = static_cast<size_t>(a);
      hi[d] = static_cast<size_t>(z);
    }
    if (rank == 0) { std::memcpy(buf.data(), src, std::min(es, srcSize)); return; }
    std::vector<size_t> idx(lo);
    size_t run = hi[rank - 1] - lo[rank - 1];
    for (;;) {
      size_t s = 0, t = 0;
      for (size_t d = 0; d < rank; d++) {
        s = s * static_cast<size_t>(ext[d]) + (idx[d] - static_cast<size_t>(o[d]));
        t = t * ns[d] + (idx[d] - r[d].first);
      }
      if ((s + run) * es <= srcSize) std::memcpy(&buf[t * es], src + s * es, run * es);
      size_t d = rank - 1;
      for (;;) {
        if (d == 0) return;
        d--;
        if (++idx[d] < hi[d]) break;
        idx[d] = lo[d];
      }
    }
  };
  std::vector<uint64_t> zero(rank, 0);
  if (total > 0) {
    if (ds.layout == 0) place(zero, ds.dims, ds.compact.data(), ds.compact.size());
    else if (ds.layout == 1) {
      if (ds.dataAddr != H5_UNDEF) {
        uint64_t need = es;
        for (auto x : ds.dims) need *= x;
        if (!inRange(ds.dataAddr, need)) { err = "dataset data is outside the file (truncated file?)"; return false; }
        place(zero, ds.dims, b_->data() + base_ + ds.dataAddr, static_cast<size_t>(need));
      }
    } else {
      std::vector<std::pair<std::vector<uint64_t>, std::pair<uint64_t, uint64_t>>> list;
      std::vector<uint32_t> masks;
      if (!chunks(ds, list, masks, err)) return false;
      for (size_t i = 0; i < list.size(); i++) {
        const auto &c = list[i];
        bool hit = true;
        for (size_t d = 0; d < rank; d++)
          if (c.first[d] + ds.chunk[d] <= r[d].first || c.first[d] >= r[d].second) hit = false;
        if (!hit) continue;
        if (!inRange(c.second.first, c.second.second)) { err = "a chunk is outside the file (truncated file?)"; return false; }
        std::string data = b_->substr(static_cast<size_t>(base_ + c.second.first), static_cast<size_t>(c.second.second));
        if (!ds.filters.empty() && !h5Unfilter(ds.filters, masks[i], es, data, err)) return false;
        place(c.first, ds.chunk, data.data(), data.size());
        if (cancelRequested()) { err = "cancelled"; return false; }
      }
    }
  }
  if (!decode(ds.type, buf.data(), total, out, err)) return false;
  std::vector<size_t> shape(ns.begin(), ns.end());
  if (ds.type.cls == H5Type::Array) for (size_t d : ds.type.arrayDims) shape.push_back(d);
  out.shape = shape;
  return true;
}

// ---- LZF ----------------------------------------------------------------------------------

bool lzfDecompress(const std::string &in, size_t outSize, std::string &out) {
  out.clear();
  out.reserve(outSize);
  size_t i = 0;
  while (i < in.size()) {
    unsigned c = static_cast<unsigned char>(in[i++]);
    if (c < 32) {
      size_t n = c + 1;
      if (i + n > in.size()) return false;
      out.append(in, i, n);
      i += n;
    } else {
      size_t n = c >> 5;
      if (n == 7) { if (i >= in.size()) return false; n += static_cast<unsigned char>(in[i++]); }
      if (i >= in.size()) return false;
      size_t back = ((c & 0x1F) << 8) + static_cast<unsigned char>(in[i++]) + 1;
      if (back > out.size()) return false;
      size_t from = out.size() - back;
      for (size_t k = 0; k < n + 2; k++) out.push_back(out[from + k]);
    }
    if (out.size() > outSize) return false;
  }
  return true;
}

} // namespace io
} // namespace nc
