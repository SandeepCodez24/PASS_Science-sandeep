// MAT-file Level 5 reader / writer and value conversion - see io_mat.h.
#include "io_mat.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_deflate.h"

namespace nc {
namespace io {

size_t MatNode::count() const {
  size_t n = 1;
  for (size_t d : dims) n *= d;
  return n;
}

namespace {

enum MiType { miINT8 = 1, miUINT8 = 2, miINT16 = 3, miUINT16 = 4, miINT32 = 5, miUINT32 = 6, miSINGLE = 7, miDOUBLE = 9,
              miINT64 = 12, miUINT64 = 13, miMATRIX = 14, miCOMPRESSED = 15, miUTF8 = 16, miUTF16 = 17, miUTF32 = 18 };

struct Reader {
  const std::string &s;
  bool swap; // big-endian file
  Reader(const std::string &str, bool sw) : s(str), swap(sw) {}
  uint64_t g(size_t at, int n) const { return swap ? getBE(s, at, n) : getLE(s, at, n); }
  // reads one tagged element at p: type, bytes, data offset; advances p
  bool tag(size_t &p, uint32_t &type, uint32_t &bytes, size_t &data) const {
    if (p + 8 > s.size()) return false;
    uint32_t t = static_cast<uint32_t>(g(p, 4));
    if (t >> 16) { // small data element
      type = t & 0xFFFF;
      bytes = t >> 16;
      data = p + 4;
      p += 8;
      return true;
    }
    type = t;
    bytes = static_cast<uint32_t>(g(p + 4, 4));
    data = p + 8;
    p = data + bytes;
    if (type != miCOMPRESSED) p = data + ((bytes + 7) / 8) * 8;
    return true;
  }
  double num(uint32_t type, size_t at) const {
    switch (type) {
      case miINT8: return static_cast<int8_t>(s[at]);
      case miUINT8: case miUTF8: return static_cast<unsigned char>(s[at]);
      case miINT16: return static_cast<int16_t>(g(at, 2));
      case miUINT16: case miUTF16: return static_cast<double>(g(at, 2));
      case miINT32: return static_cast<int32_t>(g(at, 4));
      case miUINT32: case miUTF32: return static_cast<double>(g(at, 4));
      case miINT64: return static_cast<double>(static_cast<int64_t>(g(at, 8)));
      case miUINT64: return static_cast<double>(g(at, 8));
      case miSINGLE: { uint32_t u = static_cast<uint32_t>(g(at, 4)); float f; std::memcpy(&f, &u, 4); return f; }
      case miDOUBLE: { uint64_t u = g(at, 8); double d; std::memcpy(&d, &u, 8); return d; }
    }
    return 0;
  }
  static size_t size(uint32_t type) {
    switch (type) {
      case miINT8: case miUINT8: case miUTF8: return 1;
      case miINT16: case miUINT16: case miUTF16: return 2;
      case miINT32: case miUINT32: case miSINGLE: case miUTF32: return 4;
      default: return 8;
    }
  }
  std::vector<double> nums(size_t &p) const {
    uint32_t type, bytes;
    size_t d;
    std::vector<double> out;
    if (!tag(p, type, bytes, d)) return out;
    size_t sz = size(type);
    for (size_t k = 0; k + sz <= bytes; k += sz) out.push_back(num(type, d + k));
    return out;
  }
  std::string raw(size_t &p) const {
    uint32_t type, bytes;
    size_t d;
    if (!tag(p, type, bytes, d)) return "";
    return s.substr(d, bytes);
  }
  bool matrix(size_t start, size_t end, MatNode &n, bool named, std::string &err) const;
};

std::string utf16ToUtf8(const std::vector<double> &codes) {
  std::string out;
  for (double d : codes) {
    uint32_t c = static_cast<uint32_t>(d);
    if (c < 0x80) out.push_back(static_cast<char>(c));
    else if (c < 0x800) { out.push_back(static_cast<char>(0xC0 | (c >> 6))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    else { out.push_back(static_cast<char>(0xE0 | (c >> 12))); out.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
  }
  return out;
}

bool Reader::matrix(size_t p, size_t end, MatNode &n, bool named, std::string &err) const {
  if (p >= end) { n.cls = MatNode::Double; n.dims = {0, 0}; return true; } // empty element
  std::vector<double> flags = nums(p);
  if (flags.empty()) { err = "damaged MAT array flags"; return false; }
  uint32_t f = static_cast<uint32_t>(flags[0]);
  n.cls = static_cast<int>(f & 0xFF);
  n.complex = f & 0x800;
  n.global = f & 0x400;
  n.logical = f & 0x200;
  if (n.cls == MatNode::Opaque) { n.dims = {0, 0}; return true; }
  std::vector<double> dims = nums(p);
  n.dims.clear();
  for (double d : dims) n.dims.push_back(static_cast<size_t>(d));
  std::string name = raw(p);
  if (named) n.name = name;
  size_t count = n.count();
  if (n.cls == MatNode::Cell) {
    for (size_t k = 0; k < count && p < end; k++) {
      uint32_t type, bytes;
      size_t d;
      size_t q = p;
      if (!tag(q, type, bytes, d)) break;
      MatNode c;
      if (!matrix(d, d + bytes, c, false, err)) return false;
      n.cells.push_back(std::move(c));
      p = q;
    }
    return true;
  }
  if (n.cls == MatNode::Struct || n.cls == MatNode::Object) {
    if (n.cls == MatNode::Object) n.className = raw(p);
    std::vector<double> fl = nums(p);
    size_t flen = fl.empty() ? 32 : static_cast<size_t>(fl[0]);
    std::string names = raw(p);
    for (size_t k = 0; flen && k + flen <= names.size(); k += flen) {
      std::string nm = names.substr(k, flen);
      nm = nm.substr(0, nm.find('\0'));
      n.fieldNames.push_back(nm);
    }
    for (size_t e = 0; e < count; e++) {
      std::vector<MatNode> fields;
      for (size_t k = 0; k < n.fieldNames.size(); k++) {
        uint32_t type, bytes;
        size_t d, q = p;
        if (!tag(q, type, bytes, d)) break;
        MatNode c;
        if (!matrix(d, d + bytes, c, false, err)) return false;
        fields.push_back(std::move(c));
        p = q;
      }
      n.elems.push_back(std::move(fields));
    }
    return true;
  }
  if (n.cls == MatNode::Sparse) {
    std::vector<double> ir = nums(p), jc = nums(p), pr = nums(p), pi;
    if (n.complex) pi = nums(p);
    size_t rows = n.dims[0], cols = n.dims.size() > 1 ? n.dims[1] : 1;
    n.re.assign(rows * cols, 0);
    if (n.complex) n.im.assign(rows * cols, 0);
    for (size_t c = 0; c < cols && c + 1 < jc.size(); c++)
      for (size_t k = static_cast<size_t>(jc[c]); k < static_cast<size_t>(jc[c + 1]) && k < ir.size(); k++) {
        n.re[c * rows + static_cast<size_t>(ir[k])] = k < pr.size() ? pr[k] : 1;
        if (n.complex && k < pi.size()) n.im[c * rows + static_cast<size_t>(ir[k])] = pi[k];
      }
    n.cls = MatNode::Double;
    n.className = "sparse";
    return true;
  }
  if (n.cls == MatNode::Char) {
    std::vector<double> codes = nums(p);
    size_t rows = n.dims.empty() ? 0 : n.dims[0], cols = n.dims.size() > 1 ? n.dims[1] : 1;
    std::vector<std::string> lines(rows);
    for (size_t r = 0; r < rows; r++) {
      std::vector<double> row;
      for (size_t c = 0; c < cols; c++)
        if (c * rows + r < codes.size()) row.push_back(codes[c * rows + r]);
      lines[r] = utf16ToUtf8(row);
    }
    for (size_t r = 0; r < rows; r++) n.text += (r ? "\n" : "") + lines[r];
    return true;
  }
  n.re = nums(p);
  if (n.complex) n.im = nums(p);
  return true;
}

void parseElements(const Reader &r, size_t p, size_t end, MatFile &mf, std::string &err) {
  while (p + 8 <= end) {
    uint32_t type, bytes;
    size_t d;
    size_t q = p;
    if (!r.tag(q, type, bytes, d)) break;
    if (type == miCOMPRESSED) {
      std::string inflated;
      if (!zlibDecompress(r.s.substr(d, bytes), inflated, err)) return;
      Reader inner(inflated, r.swap);
      parseElements(inner, 0, inflated.size(), mf, err);
    } else if (type == miMATRIX) {
      MatNode n;
      if (!r.matrix(d, d + bytes, n, true, err)) return;
      mf.vars.push_back(std::move(n));
    }
    p = q;
  }
}

// ---- writer --------------------------------------------------------------------

void element(std::string &o, uint32_t type, const std::string &data) {
  if (data.size() <= 4 && type != miMATRIX && type != miCOMPRESSED) {
    putLE(o, (static_cast<uint32_t>(data.size()) << 16) | type, 4);
    std::string d = data;
    d.resize(4, '\0');
    o += d;
    return;
  }
  putLE(o, type, 4);
  putLE(o, data.size(), 4);
  o += data;
  while (o.size() % 8) o.push_back('\0');
}

std::string matrixBytes(const MatNode &n, bool named) {
  std::string body, tmp;
  uint32_t flags = static_cast<uint32_t>(n.cls) | (n.complex ? 0x800 : 0) | (n.logical ? 0x200 : 0);
  tmp.clear();
  putLE(tmp, flags, 4);
  putLE(tmp, 0, 4);
  element(body, miUINT32, tmp);
  tmp.clear();
  for (size_t dd : n.dims) putLE(tmp, dd, 4);
  element(body, miINT32, tmp);
  element(body, miINT8, named ? n.name : "");
  if (n.cls == MatNode::Cell) {
    for (const auto &c : n.cells) element(body, miMATRIX, matrixBytes(c, false));
  } else if (n.cls == MatNode::Struct) {
    size_t flen = 1;
    for (const auto &f : n.fieldNames) flen = std::max(flen, f.size() + 1);
    tmp.clear();
    putLE(tmp, flen, 4);
    element(body, miINT32, tmp);
    std::string names;
    for (const auto &f : n.fieldNames) { std::string x = f; x.resize(flen, '\0'); names += x; }
    element(body, miINT8, names);
    for (const auto &e : n.elems)
      for (const auto &f : e) element(body, miMATRIX, matrixBytes(f, false));
  } else if (n.cls == MatNode::Char) {
    // rows padded to the longest, stored column-major as UTF-16
    std::vector<std::vector<uint16_t>> rows;
    size_t start = 0;
    while (start <= n.text.size()) {
      size_t e = n.text.find('\n', start);
      if (e == std::string::npos) e = n.text.size();
      std::string line = n.text.substr(start, e - start);
      std::vector<uint16_t> w;
      for (size_t i = 0; i < line.size();) {
        unsigned char c = static_cast<unsigned char>(line[i]);
        uint32_t cp;
        if (c < 0x80) { cp = c; i++; }
        else if (c < 0xE0) { cp = ((c & 0x1F) << 6) | (line[i + 1] & 0x3F); i += 2; }
        else { cp = ((c & 0x0F) << 12) | ((line[i + 1] & 0x3F) << 6) | (line[i + 2] & 0x3F); i += 3; }
        w.push_back(static_cast<uint16_t>(cp));
      }
      rows.push_back(w);
      start = e + 1;
    }
    tmp.clear();
    size_t cols = 0;
    for (const auto &r : rows) cols = std::max(cols, r.size());
    for (size_t c = 0; c < cols; c++)
      for (const auto &r : rows) putLE(tmp, c < r.size() ? r[c] : ' ', 2);
    element(body, miUINT16, tmp);
  } else {
    tmp.clear();
    uint32_t mt = miDOUBLE;
    int sz = 8;
    switch (n.cls) {
      case MatNode::Single: mt = miSINGLE; sz = 4; break;
      case MatNode::Int8: mt = miINT8; sz = 1; break;
      case MatNode::UInt8: mt = miUINT8; sz = 1; break;
      case MatNode::Int16: mt = miINT16; sz = 2; break;
      case MatNode::UInt16: mt = miUINT16; sz = 2; break;
      case MatNode::Int32: mt = miINT32; sz = 4; break;
      case MatNode::UInt32: mt = miUINT32; sz = 4; break;
      case MatNode::Int64: mt = miINT64; sz = 8; break;
      case MatNode::UInt64: mt = miUINT64; sz = 8; break;
    }
    auto put = [&](const std::vector<double> &v) {
      tmp.clear();
      for (double x : v) {
        if (mt == miDOUBLE) putF64LE(tmp, x);
        else if (mt == miSINGLE) putF32LE(tmp, static_cast<float>(x));
        else putLE(tmp, static_cast<uint64_t>(static_cast<int64_t>(std::llround(x))), sz);
      }
      element(body, mt, tmp);
    };
    put(n.re);
    if (n.complex) put(n.im);
  }
  return body;
}

} // namespace

bool readMatV5(const std::string &b, MatFile &mf, std::string &err) {
  mf = MatFile();
  if (b.size() < 128) { err = "not a MAT-file (too short)"; return false; }
  if (b.compare(0, 10, "MATLAB 7.3") == 0 || (b.size() > 520 && b.compare(512, 8, "\x89HDF\r\n\x1a\n") == 0)) {
    mf.version = "v7.3";
    err = "v7.3";
    return false;
  }
  if (b.compare(0, 6, "MATLAB") != 0 && !(b[126] == 'I' || b[126] == 'M')) {
    err = "not a Level 5 MAT-file (v4 files are not built in)";
    return false;
  }
  mf.header = b.substr(0, 116);
  while (!mf.header.empty() && (mf.header.back() == ' ' || mf.header.back() == '\0')) mf.header.pop_back();
  bool swap = b[126] == 'M';
  Reader r(b, swap);
  parseElements(r, 128, b.size(), mf, err);
  if (!err.empty()) return false;
  bool compressed = false;
  for (size_t p = 128; p + 8 <= b.size();) {
    uint32_t t = static_cast<uint32_t>(r.g(p, 4)), l = static_cast<uint32_t>(r.g(p + 4, 4));
    if (t == miCOMPRESSED) compressed = true;
    if (t >> 16) { p += 8; continue; }
    p += 8 + (t == miCOMPRESSED ? l : (l + 7) / 8 * 8);
  }
  mf.version = compressed ? "v7" : "v5";
  return true;
}

std::string writeMatV5(const MatFile &mf, bool compress, int level) {
  std::string h = mf.header.empty() ? std::string("MATLAB 5.0 MAT-file, Platform: NC, Created by: NC save_mat") : mf.header;
  if (h.rfind("MATLAB 5.0 MAT-file", 0) != 0) h = "MATLAB 5.0 MAT-file, " + h;
  h.resize(116, ' ');
  std::string o = h;
  o.append(8, ' '); // no subsystem data
  putLE(o, 0x0100, 2);
  o += "IM";
  for (const auto &v : mf.vars) {
    std::string el;
    element(el, miMATRIX, matrixBytes(v, true));
    if (compress) {
      std::string z = zlibCompress(el, level);
      putLE(o, miCOMPRESSED, 4);
      putLE(o, z.size(), 4);
      o += z;
    } else {
      o += el;
    }
  }
  return o;
}

std::string matClassName(const MatNode &n) {
  if (n.logical) return "logical";
  switch (n.cls) {
    case MatNode::Cell: return "cell";
    case MatNode::Struct: return "struct";
    case MatNode::Object: return n.className.empty() ? "object" : n.className;
    case MatNode::Char: return "char";
    case MatNode::Double: return n.className == "sparse" ? "double (sparse)" : "double";
    case MatNode::Single: return "single";
    case MatNode::Int8: return "int8";
    case MatNode::UInt8: return "uint8";
    case MatNode::Int16: return "int16";
    case MatNode::UInt16: return "uint16";
    case MatNode::Int32: return "int32";
    case MatNode::UInt32: return "uint32";
    case MatNode::Int64: return "int64";
    case MatNode::UInt64: return "uint64";
    case MatNode::Opaque: return "opaque (MATLAB object)";
  }
  return "unknown";
}

// ---- conversions ------------------------------------------------------------------

namespace {
// column-major -> row-major for any rank
std::vector<double> rowMajor(const std::vector<double> &cm, const std::vector<size_t> &dims) {
  size_t n = cm.size();
  std::vector<double> out(n);
  std::vector<size_t> idx(dims.size(), 0);
  for (size_t k = 0; k < n; k++) {
    // idx for column-major position k
    size_t rem = k;
    for (size_t d = 0; d < dims.size(); d++) { idx[d] = rem % dims[d]; rem /= dims[d]; }
    size_t rm = 0;
    for (size_t d = 0; d < dims.size(); d++) rm = rm * dims[d] + idx[d];
    out[rm] = cm[k];
  }
  return out;
}
} // namespace

Value matToValue(const MatNode &n, bool squeeze, bool objects) {
  const size_t count = n.count();
  if (n.cls == MatNode::Char) {
    if (n.text.find('\n') == std::string::npos) return Value(n.text);
    std::vector<std::string> lines;
    size_t s = 0;
    while (s <= n.text.size()) { size_t e = n.text.find('\n', s); if (e == std::string::npos) e = n.text.size(); lines.push_back(n.text.substr(s, e - s)); s = e + 1; }
    return textList(lines);
  }
  if (n.cls == MatNode::Cell) {
    std::vector<Value> cells;
    for (const auto &c : n.cells) cells.push_back(matToValue(c, squeeze, objects));
    if (n.dims.size() == 2 && n.dims[0] > 1 && n.dims[1] > 1) {
      std::vector<std::vector<Value>> m(n.dims[0], std::vector<Value>(n.dims[1]));
      for (size_t c = 0; c < n.dims[1]; c++)
        for (size_t r = 0; r < n.dims[0]; r++)
          if (c * n.dims[0] + r < cells.size()) m[r][c] = cells[c * n.dims[0] + r];
      return Value(m);
    }
    return Value(cells);
  }
  if (n.cls == MatNode::Struct || n.cls == MatNode::Object) {
    std::vector<Value> elems;
    for (const auto &e : n.elems) {
      Fields f;
      for (size_t k = 0; k < n.fieldNames.size() && k < e.size(); k++) f[n.fieldNames[k]] = matToValue(e[k], squeeze, objects);
      if (n.cls == MatNode::Object) f["class_name"] = Value(n.className);
      elems.push_back(objects ? makeObject("NcMatStruct", f) : Value(f));
    }
    if (elems.size() == 1) return elems[0];
    return Value(elems);
  }
  if (n.cls == MatNode::Opaque) return Value(std::string("<MATLAB object: not readable outside MATLAB>"));
  std::vector<size_t> dims = n.dims;
  if (count == 1) {
    if (n.complex) return Value::complexNumber(n.re[0], n.im.empty() ? 0 : n.im[0]);
    if (n.logical) return Value::boolean(n.re[0] != 0);
    return Value(n.re.empty() ? 0.0 : n.re[0]);
  }
  if (count == 0) return numpy::makeMatrix(std::vector<std::vector<double>>{});
  if (n.complex || n.logical) {
    // cells keep complex / bool element types
    std::vector<Value> cells;
    std::vector<double> re = rowMajor(n.re, dims), im = n.complex ? rowMajor(n.im, dims) : std::vector<double>();
    for (size_t k = 0; k < re.size(); k++)
      cells.push_back(n.complex ? Value::complexNumber(re[k], im[k]) : Value::boolean(re[k] != 0));
    if (dims.size() == 2 && !(squeeze && (dims[0] == 1 || dims[1] == 1))) {
      std::vector<std::vector<Value>> m(dims[0], std::vector<Value>(dims[1]));
      for (size_t r = 0; r < dims[0]; r++) for (size_t c = 0; c < dims[1]; c++) m[r][c] = cells[r * dims[1] + c];
      return Value(m);
    }
    return Value(cells);
  }
  std::vector<double> rm = rowMajor(n.re, dims);
  if (squeeze) {
    std::vector<size_t> sq;
    for (size_t d : dims) if (d != 1) sq.push_back(d);
    if (sq.size() <= 1) return numpy::makeArray(rm);
    dims = sq;
  }
  return ndFromRowMajor(dims, rm);
}

bool validMatName(const std::string &n) {
  if (n.empty() || n.size() > 63 || !std::isalpha(static_cast<unsigned char>(n[0]))) return false;
  for (char c : n) if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_')) return false;
  return true;
}

bool valueToMat(const std::string &name, const Value &v, MatNode &n, std::string &err) {
  n = MatNode();
  n.name = name;
  if (v.isText) {
    n.cls = MatNode::Char;
    n.text = v.text();
    size_t w = 0;
    for (size_t i = 0; i < n.text.size();) { unsigned char c = static_cast<unsigned char>(n.text[i]); i += c < 0x80 ? 1 : c < 0xE0 ? 2 : 3; w++; }
    n.dims = {n.text.empty() ? 0u : 1u, w};
    return true;
  }
  if (v.isDict || v.isObject) {
    if (isObjectOf(v, "NcTable") || (field(v, "cols") && field(v, "data") && field(v, "rows"))) {
      Table t;
      if (!valueToTable(v, t, err)) return false;
      Fields f;
      for (size_t c = 0; c < t.cols.size(); c++) f[fieldName(t.cols[c]).empty() ? "Col_" + std::to_string(c + 1) : fieldName(t.cols[c])] = tableColumn(t, c);
      return valueToMat(name, Value(f), n, err);
    }
    n.cls = MatNode::Struct;
    n.dims = {1, 1};
    std::vector<std::string> keys;
    for (const auto &kv : v.dict()) if (kv.first != "key_order" && kv.first != "class_name") keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    std::vector<MatNode> fields;
    for (const auto &k : keys) {
      std::string fn = fieldName(k);
      if (!validMatName(fn)) fn = "f_" + fn;
      MatNode c;
      if (!valueToMat("", v.dict().at(k), c, err)) return false;
      n.fieldNames.push_back(fn.substr(0, 63));
      fields.push_back(std::move(c));
    }
    n.elems.push_back(std::move(fields));
    return true;
  }
  if (v.isArray || (v.isMatrix && !v.isPacked() && !v.isND())) {
    // numeric when every element is a plain number, else a cell
    std::vector<Value> items;
    size_t rows = 1, cols = 0;
    if (v.isArray) { for (size_t i = 0; i < v.length(); i++) items.push_back(v.at(i)); cols = items.size(); }
    else { rows = v.rows(); cols = v.cols(); for (size_t r = 0; r < rows; r++) for (size_t c = 0; c < cols; c++) items.push_back(c < v.rowLength(r) ? v.at(r, c) : Value(0.0)); }
    bool numeric = true, allBool = !items.empty(), anyComplex = false;
    for (const auto &x : items) {
      if (!numpy::isPlainNumber(x)) numeric = false;
      if (!x.isBool()) allBool = false;
      if (x.isComplex) anyComplex = true;
    }
    if (numeric) {
      n.cls = allBool ? MatNode::UInt8 : MatNode::Double;
      n.logical = allBool;
      n.complex = anyComplex;
      n.dims = {rows, cols};
      for (size_t c = 0; c < cols; c++)
        for (size_t r = 0; r < rows; r++) {
          const Value &x = items[r * cols + c];
          n.re.push_back(x.number);
          if (anyComplex) n.im.push_back(x.isComplex ? x.imag : 0);
        }
      return true;
    }
    n.cls = MatNode::Cell;
    n.dims = {rows, cols};
    for (size_t c = 0; c < cols; c++)
      for (size_t r = 0; r < rows; r++) {
        MatNode cell;
        if (!valueToMat("", items[r * cols + c], cell, err)) return false;
        n.cells.push_back(std::move(cell));
      }
    return true;
  }
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!ndToRowMajor(v, shape, vals)) {
    err = "this value cannot be stored in a MAT-file";
    return false;
  }
  if (shape.size() == 1) shape = {1, shape[0]};
  n.cls = v.isBool() ? MatNode::UInt8 : MatNode::Double;
  n.logical = v.isBool();
  if (v.isComplex && numpy::isPlainNumber(v)) { n.complex = true; n.im = {v.imag}; }
  n.dims = shape;
  // row-major -> column-major
  n.re.assign(vals.size(), 0);
  std::vector<size_t> idx(shape.size());
  for (size_t k = 0; k < vals.size(); k++) {
    size_t rem = k;
    for (size_t d = shape.size(); d-- > 0;) { idx[d] = rem % shape[d]; rem /= shape[d]; }
    size_t cm = 0;
    for (size_t d = shape.size(); d-- > 0;) cm = cm * shape[d] + idx[d];
    n.re[cm] = vals[k];
  }
  return true;
}

} // namespace io
} // namespace nc
