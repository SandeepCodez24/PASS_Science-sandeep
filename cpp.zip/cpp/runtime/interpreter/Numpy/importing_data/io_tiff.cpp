// TIFF 6.0 / BigTIFF decoder and encoder (also the base of GeoTIFF).
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>

#include "io_bytes.h"
#include "io_deflate.h"
#include "io_codecs.h"
#include "io_image.h"

namespace nc {
namespace io {

namespace {

struct Tag {
  uint16_t type = 0;
  uint64_t count = 0;
  std::vector<double> nums;
  std::string bytes; // raw value bytes (ASCII / UNDEFINED)
};

bool lzwDecode(const std::string &in, std::string &out, size_t expect) {
  out.clear();
  std::vector<std::string> dict;
  auto reset = [&]() {
    dict.assign(258, std::string());
    for (int k = 0; k < 256; k++) dict[k] = std::string(1, static_cast<char>(k));
  };
  reset();
  size_t bitPos = 0;
  int width = 9;
  std::string prev;
  bool havePrev = false;
  auto next = [&]() -> int {
    if ((bitPos + width) > in.size() * 8) return 257;
    int v = 0;
    for (int k = 0; k < width; k++) {
      size_t b = bitPos + k;
      v = (v << 1) | ((static_cast<unsigned char>(in[b / 8]) >> (7 - b % 8)) & 1);
    }
    bitPos += width;
    return v;
  };
  while (out.size() < expect) {
    int code = next();
    if (code == 257) break;
    if (code == 256) {
      reset();
      width = 9;
      havePrev = false;
      continue;
    }
    std::string entry;
    if (code < static_cast<int>(dict.size())) entry = dict[static_cast<size_t>(code)];
    else if (havePrev && code == static_cast<int>(dict.size())) entry = prev + prev[0];
    else return false;
    out += entry;
    if (havePrev) dict.push_back(prev + entry[0]);
    prev = entry;
    havePrev = true;
    size_t n = dict.size() + 1; // early change
    width = n >= 2048 ? 12 : n >= 1024 ? 11 : n >= 512 ? 10 : 9;
  }
  return true;
}

std::string lzwEncode(const std::string &in) {
  std::string out;
  uint32_t buf = 0;
  int cnt = 0;
  int width = 9;
  auto put = [&](int code) {
    for (int k = width - 1; k >= 0; k--) {
      buf = (buf << 1) | ((code >> k) & 1);
      if (++cnt == 8) { out.push_back(static_cast<char>(buf)); buf = 0; cnt = 0; }
    }
  };
  std::map<std::string, int> dict;
  auto reset = [&]() {
    dict.clear();
    for (int k = 0; k < 256; k++) dict[std::string(1, static_cast<char>(k))] = k;
  };
  reset();
  int nextCode = 258;
  put(256);
  std::string w;
  for (char c : in) {
    std::string wc = w + c;
    if (dict.count(wc)) { w = wc; continue; }
    put(dict[w]);
    dict[wc] = nextCode++;
    if (nextCode + 1 >= 512 && width == 9) width = 10;
    else if (nextCode + 1 >= 1024 && width == 10) width = 11;
    else if (nextCode + 1 >= 2048 && width == 11) width = 12;
    if (nextCode >= 4093) {
      put(256);
      reset();
      nextCode = 258;
      width = 9;
    }
    w = std::string(1, c);
  }
  if (!w.empty()) put(dict[w]);
  put(257);
  while (cnt) { buf <<= 1; if (++cnt == 8) { out.push_back(static_cast<char>(buf)); buf = 0; cnt = 0; } }
  return out;
}

std::string packbitsDecode(const std::string &in) {
  std::string out;
  size_t p = 0;
  while (p < in.size()) {
    int n = static_cast<int8_t>(in[p++]);
    if (n >= 0) { out.append(in, p, static_cast<size_t>(n + 1)); p += static_cast<size_t>(n + 1); }
    else if (n != -128 && p < in.size()) { out.append(static_cast<size_t>(1 - n), in[p]); p++; }
  }
  return out;
}

std::string packbitsEncode(const std::string &in) {
  std::string out;
  size_t p = 0;
  while (p < in.size()) {
    size_t run = 1;
    while (p + run < in.size() && run < 128 && in[p + run] == in[p]) run++;
    if (run >= 2) {
      out.push_back(static_cast<char>(1 - static_cast<int>(run)));
      out.push_back(in[p]);
      p += run;
      continue;
    }
    size_t lit = 1;
    while (p + lit < in.size() && lit < 128 && !(p + lit + 1 < in.size() && in[p + lit] == in[p + lit + 1])) lit++;
    out.push_back(static_cast<char>(lit - 1));
    out.append(in, p, lit);
    p += lit;
  }
  return out;
}

} // namespace

bool decodeTiff(const std::string &b, Image &first, std::string &err, bool allFrames) {
  first = Image();
  if (b.size() < 8 || !((b[0] == 'I' && b[1] == 'I') || (b[0] == 'M' && b[1] == 'M'))) {
    err = "not a TIFF file";
    return false;
  }
  const bool le = b[0] == 'I';
  auto g = [&](size_t at, int n) { return le ? getLE(b, at, n) : getBE(b, at, n); };
  uint16_t magic = static_cast<uint16_t>(g(2, 2));
  const bool big = magic == 43;
  if (magic != 42 && !big) {
    err = "not a TIFF file (bad magic number)";
    return false;
  }
  uint64_t ifd = big ? g(8, 8) : g(4, 4);
  std::vector<Image> pages;
  size_t guard = 0;
  while (ifd && ifd < b.size() && guard++ < 10000) {
    std::map<uint16_t, Tag> tags;
    uint64_t n = big ? g(ifd, 8) : g(ifd, 2);
    size_t entry = ifd + (big ? 8 : 2), esz = big ? 20 : 12;
    for (uint64_t k = 0; k < n; k++, entry += esz) {
      Tag t;
      uint16_t id = static_cast<uint16_t>(g(entry, 2));
      t.type = static_cast<uint16_t>(g(entry + 2, 2));
      t.count = big ? g(entry + 4, 8) : g(entry + 4, 4);
      static const int sz[] = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 4, 0, 0, 8, 8, 8};
      size_t unit = t.type < 19 ? static_cast<size_t>(sz[t.type]) : 1;
      size_t bytes = unit * static_cast<size_t>(t.count);
      size_t inl = big ? 8 : 4;
      size_t at = bytes <= inl ? entry + (big ? 12 : 8) : static_cast<size_t>(big ? g(entry + 12, 8) : g(entry + 8, 4));
      if (at + bytes > b.size()) continue;
      t.bytes = b.substr(at, bytes);
      if (t.type != 2 && t.type != 7 && t.count < 100000000)
        for (uint64_t i = 0; i < t.count; i++) {
          size_t a = at + i * unit;
          double v = 0;
          switch (t.type) {
            case 1: case 6: v = t.type == 6 ? static_cast<int8_t>(b[a]) : static_cast<unsigned char>(b[a]); break;
            case 3: v = static_cast<double>(g(a, 2)); break;
            case 8: v = static_cast<int16_t>(g(a, 2)); break;
            case 4: case 13: v = static_cast<double>(g(a, 4)); break;
            case 9: v = static_cast<int32_t>(g(a, 4)); break;
            case 5: { double d = static_cast<double>(g(a + 4, 4)); v = d ? g(a, 4) / d : 0; break; }
            case 10: { double d = static_cast<int32_t>(g(a + 4, 4)); v = d ? static_cast<int32_t>(g(a, 4)) / d : 0; break; }
            case 11: { uint32_t u = static_cast<uint32_t>(g(a, 4)); float f; std::memcpy(&f, &u, 4); v = f; break; }
            case 12: { uint64_t u = g(a, 8); double d; std::memcpy(&d, &u, 8); v = d; break; }
            case 16: case 18: v = static_cast<double>(g(a, 8)); break;
            case 17: v = static_cast<double>(static_cast<int64_t>(g(a, 8))); break;
          }
          t.nums.push_back(v);
        }
      tags[id] = std::move(t);
    }
    uint64_t nextIfd = big ? g(entry, 8) : g(entry, 4);
    auto num = [&](uint16_t id, double def) { auto it = tags.find(id); return it == tags.end() || it->second.nums.empty() ? def : it->second.nums[0]; };
    auto nums = [&](uint16_t id) { auto it = tags.find(id); return it == tags.end() ? std::vector<double>{} : it->second.nums; };
    auto text = [&](uint16_t id) {
      auto it = tags.find(id);
      if (it == tags.end()) return std::string();
      std::string s = it->second.bytes;
      while (!s.empty() && s.back() == '\0') s.pop_back();
      return s;
    };
    Image img;
    img.width = static_cast<size_t>(num(256, 0));
    img.height = static_cast<size_t>(num(257, 0));
    size_t spp = static_cast<size_t>(num(277, 1));
    int bps = static_cast<int>(num(258, 1));
    int comp = static_cast<int>(num(259, 1));
    int photo = static_cast<int>(num(262, 1));
    int planar = static_cast<int>(num(284, 1));
    int pred = static_cast<int>(num(317, 1));
    int fmt = static_cast<int>(num(339, 1));
    if (!img.width || !img.height) {
      err = "TIFF page without width/height";
      return false;
    }
    if (comp != 1 && comp != 5 && comp != 8 && comp != 32946 && comp != 32773 && comp != 50000) {
      err = "TIFF compression " + std::to_string(comp) + (comp == 7 ? " (JPEG-in-TIFF)" : "") + " is not built in (none, LZW, deflate, PackBits, ZSTD are)";
      return false;
    }
    std::vector<double> offs = nums(273), counts = nums(279);
    bool tiled = tags.count(322) > 0;
    size_t tw = tiled ? static_cast<size_t>(num(322, 0)) : img.width;
    size_t th = tiled ? static_cast<size_t>(num(323, 0)) : static_cast<size_t>(num(278, static_cast<double>(img.height)));
    if (th == 0 || th > img.height) th = img.height;
    if (tiled) { offs = nums(324); counts = nums(325); }
    const size_t bytesPer = static_cast<size_t>(std::max(1, bps / 8));
    const size_t planes = planar == 2 ? spp : 1, sppIn = planar == 2 ? 1 : spp;
    img.channels = spp;
    std::vector<double> colormap = nums(320);
    if (photo == 3) img.channels = 3;
    img.bitDepth = bps == 16 ? 16 : bps == 32 || bps == 64 ? 32 : 8;
    img.isFloat = fmt == 3;
    img.px.assign(img.width * img.height * img.channels, 0);
    size_t across = (img.width + tw - 1) / tw, down = (img.height + th - 1) / th;
    for (size_t pl = 0; pl < planes; pl++)
      for (size_t ty = 0; ty < down; ty++)
        for (size_t tx = 0; tx < across; tx++) {
          size_t idx = pl * across * down + ty * across + tx;
          if (idx >= offs.size()) continue;
          size_t o = static_cast<size_t>(offs[idx]), c = idx < counts.size() ? static_cast<size_t>(counts[idx]) : 0;
          if (o + c > b.size()) continue;
          std::string raw = b.substr(o, c), data;
          size_t rowsHere = tiled ? th : std::min(th, img.height - ty * th);
          size_t rowBytes = (tw * sppIn * static_cast<size_t>(bps) + 7) / 8;
          size_t expect = rowBytes * rowsHere;
          if (comp == 1) data = raw;
          else if (comp == 5) { if (!lzwDecode(raw, data, expect)) { err = "damaged LZW data in TIFF"; return false; } }
          else if (comp == 32773) data = packbitsDecode(raw);
          else if (comp == 50000) { if (!zstdDecompress(raw, data, err)) { err = "damaged ZSTD data in TIFF: " + err; return false; } }
          else if (!zlibDecompress(raw, data, err)) { err = "damaged deflate data in TIFF: " + err; return false; }
          if (data.size() < expect) data.resize(expect, '\0');
          // predictors
          if (pred == 2 && bps >= 8) {
            for (size_t r = 0; r < rowsHere; r++)
              for (size_t x = 1; x < tw; x++)
                for (size_t k = 0; k < sppIn; k++) {
                  size_t a = r * rowBytes + (x * sppIn + k) * bytesPer, bprev = r * rowBytes + ((x - 1) * sppIn + k) * bytesPer;
                  uint64_t cur = le ? getLE(data, a, static_cast<int>(bytesPer)) : getBE(data, a, static_cast<int>(bytesPer));
                  uint64_t prv = le ? getLE(data, bprev, static_cast<int>(bytesPer)) : getBE(data, bprev, static_cast<int>(bytesPer));
                  uint64_t sum = cur + prv;
                  if (le) setLE(data, a, sum, static_cast<int>(bytesPer)); else setBE(data, a, sum, static_cast<int>(bytesPer));
                }
          } else if (pred == 3) {
            size_t stride = tw * sppIn;
            for (size_t r = 0; r < rowsHere; r++) {
              // undo byte differencing then de-interleave byte planes
              std::string acc = data.substr(r * rowBytes, rowBytes);
              for (size_t k = sppIn; k < acc.size(); k++) acc[k] = static_cast<char>(acc[k] + acc[k - sppIn]);
              std::string outRow(rowBytes, '\0');
              for (size_t s = 0; s < stride; s++)
                for (size_t byte = 0; byte < bytesPer; byte++) {
                  // stored big-endian byte planes
                  size_t dst = s * bytesPer + (le ? bytesPer - 1 - byte : byte);
                  outRow[dst] = acc[byte * stride + s];
                }
              data.replace(r * rowBytes, rowBytes, outRow);
            }
          }
          for (size_t r = 0; r < rowsHere; r++) {
            size_t Y = ty * th + r;
            if (Y >= img.height) break;
            for (size_t x = 0; x < tw; x++) {
              size_t X = tx * tw + x;
              if (X >= img.width) break;
              for (size_t k = 0; k < sppIn; k++) {
                size_t s = x * sppIn + k;
                double v;
                if (bps < 8) {
                  size_t bit = r * rowBytes * 8 + s * static_cast<size_t>(bps);
                  v = (static_cast<unsigned char>(data[bit / 8]) >> (8 - bps - bit % 8)) & ((1 << bps) - 1);
                  if (photo <= 1) v = v * 255.0 / ((1 << bps) - 1);
                } else {
                  size_t a = r * rowBytes + s * bytesPer;
                  uint64_t u = le ? getLE(data, a, static_cast<int>(bytesPer)) : getBE(data, a, static_cast<int>(bytesPer));
                  if (fmt == 3 && bytesPer == 4) { uint32_t u32 = static_cast<uint32_t>(u); float f; std::memcpy(&f, &u32, 4); v = f; }
                  else if (fmt == 3 && bytesPer == 8) { double d; std::memcpy(&d, &u, 8); v = d; }
                  else if (fmt == 2) v = static_cast<double>(static_cast<int64_t>(u << (64 - 8 * bytesPer)) >> (64 - 8 * bytesPer));
                  else v = static_cast<double>(u);
                }
                size_t ch = planar == 2 ? pl : k;
                if (photo == 3) {
                  size_t i = static_cast<size_t>(v), nc = colormap.size() / 3;
                  for (int q = 0; q < 3; q++)
                    img.px[(Y * img.width + X) * 3 + static_cast<size_t>(q)] = i < nc ? std::round(colormap[static_cast<size_t>(q) * nc + i] / 257.0) : 0;
                } else {
                  if (photo == 0 && ch == 0) v = (img.isFloat ? 1.0 : img.maxValue()) - v;
                  img.px[(Y * img.width + X) * img.channels + ch] = v;
                }
              }
            }
          }
        }
    if (photo == 3) img.bitDepth = 8;
    if (bps < 8) img.bitDepth = 8;
    if (img.channels <= 2) img.colorSpace = "Grayscale";
    else if (photo == 5) img.colorSpace = "CMYK";
    double xr = num(282, 0), yr = num(283, 0);
    int unit = static_cast<int>(num(296, 2));
    if (xr > 0) { img.dpiX = unit == 3 ? xr * 2.54 : xr; img.dpiY = yr > 0 ? (unit == 3 ? yr * 2.54 : yr) : img.dpiX; }
    if (!text(270).empty()) img.text.push_back({"ImageDescription", text(270)});
    if (!text(305).empty()) img.exif["Software"] = Value(text(305));
    if (!text(306).empty()) img.exif["DateTime"] = Value(text(306));
    if (!text(315).empty()) img.exif["Artist"] = Value(text(315));
    if (tags.count(34675)) img.icc = tags[34675].bytes;
    img.extra["subfile_type"] = Value(num(254, 0));
    img.extra["compression"] = Value(static_cast<double>(comp));
    img.extra["tiled"] = Value::boolean(tiled);
    auto keep = [&](uint16_t id, const char *name) {
      if (tags.count(id)) img.extra[name] = numberList(tags[id].nums);
    };
    keep(33550, "geo_pixel_scale");
    keep(33922, "geo_tiepoint");
    keep(34264, "geo_transform");
    keep(34735, "geo_keys");
    keep(34736, "geo_doubles");
    if (!text(34737).empty()) img.extra["geo_ascii"] = Value(text(34737));
    if (!text(42112).empty()) img.extra["gdal_metadata"] = Value(text(42112));
    if (!text(42113).empty()) img.extra["gdal_nodata"] = Value(text(42113));
    if (!text(33432).empty()) img.text.push_back({"Copyright", text(33432)});
    pages.push_back(std::move(img));
    if (!allFrames) break;
    ifd = nextIfd;
  }
  if (pages.empty()) {
    err = "TIFF has no image";
    return false;
  }
  first = std::move(pages[0]);
  for (size_t k = 1; k < pages.size(); k++) first.frames.push_back(std::move(pages[k]));
  return true;
}

// ---- encoder --------------------------------------------------------------------

std::string encodeTiff(const std::vector<const Image *> &pagesIn, const TiffOptions &opt) {
  // pages to write (with overviews)
  std::vector<Image> pages;
  for (const Image *p : pagesIn) {
    pages.push_back(*p);
    if (opt.overviews) {
      Image cur = *p;
      const size_t limit = opt.tile ? opt.tile : 512; // COG: halve until one tile holds the level
      while (cur.width > limit || cur.height > limit) {
        cur = resizeImage(cur, std::max<size_t>(1, cur.width / 2), std::max<size_t>(1, cur.height / 2));
        cur.extra["subfile_type"] = Value(1.0);
        cur.text.clear();
        pages.push_back(cur);
      }
    }
  }
  const bool big = opt.bigtiff;
  const int off = big ? 8 : 4;
  std::string out = big ? std::string("II\x2B\0\x08\0\0\0", 8) : std::string("II*\0", 4);
  size_t firstIfdPos = out.size();
  putLE(out, 0, off);
  size_t prevNextPos = firstIfdPos;
  for (const Image &img : pages) {
    const int bps = img.isFloat ? 32 : img.bitDepth >= 32 ? 32 : img.bitDepth >= 16 ? 16 : 8;
    const size_t bytesPer = static_cast<size_t>(bps / 8), spp = img.channels;
    const bool tiled = opt.tile > 0;
    const size_t tw = tiled ? opt.tile : img.width;
    size_t rowBytes = tw * spp * bytesPer;
    const size_t th = tiled ? opt.tile : std::max<size_t>(1, std::min(img.height, (64 * 1024) / std::max<size_t>(1, rowBytes)));
    const size_t across = (img.width + tw - 1) / tw, down = (img.height + th - 1) / th;
    std::vector<uint64_t> offsets, counts;
    int comp = opt.codec == "lzw" ? 5 : opt.codec == "zstd" ? 50000 : opt.codec == "deflate" ? 8 : opt.codec == "packbits" ? 32773 : 1;
    for (size_t ty = 0; ty < down; ty++)
      for (size_t tx = 0; tx < across; tx++) {
        std::string raw;
        size_t rows = tiled ? th : std::min(th, img.height - ty * th);
        raw.reserve(rows * rowBytes);
        for (size_t r = 0; r < rows; r++)
          for (size_t x = 0; x < tw; x++)
            for (size_t k = 0; k < spp; k++) {
              size_t X = tx * tw + x, Y = ty * th + r;
              double v = (X < img.width && Y < img.height) ? img.at(X, Y, k) : 0;
              if (img.isFloat) { float f = static_cast<float>(v); uint32_t u; std::memcpy(&u, &f, 4); putLE(raw, u, 4); }
              else putLE(raw, static_cast<uint64_t>(std::clamp(std::round(v), 0.0, bps == 8 ? 255.0 : bps == 16 ? 65535.0 : 4294967295.0)), static_cast<int>(bytesPer));
            }
        std::string enc = comp == 5 ? lzwEncode(raw) : comp == 8 ? zlibCompress(raw, 6) : comp == 32773 ? packbitsEncode(raw) : comp == 50000 ? zstdCompress(raw, 9) : raw;
        if (out.size() % 2) out.push_back(0);
        offsets.push_back(out.size());
        counts.push_back(enc.size());
        out += enc;
      }
    // tags
    struct E { uint16_t id, type; std::vector<double> v; std::string bytes; };
    std::vector<E> es;
    auto add = [&](uint16_t id, uint16_t type, std::vector<double> v) { es.push_back({id, type, std::move(v), ""}); };
    auto addText = [&](uint16_t id, const std::string &s) { es.push_back({id, 2, {}, s + '\0'}); };
    double sub = 0;
    if (img.extra.count("subfile_type")) sub = img.extra.at("subfile_type").number;
    if (sub > 0) add(254, 4, {sub});
    add(256, 4, {static_cast<double>(img.width)});
    add(257, 4, {static_cast<double>(img.height)});
    add(258, 3, std::vector<double>(spp, bps));
    add(259, 3, {static_cast<double>(comp)});
    add(262, 3, {spp >= 3 && spp <= 4 ? 2.0 : 1.0});
    std::string desc;
    for (const auto &t : img.text) desc += (desc.empty() ? "" : "\n") + (t.first == "ImageDescription" ? "" : t.first + ": ") + t.second;
    if (!desc.empty()) addText(270, desc);
    std::vector<double> offD(offsets.begin(), offsets.end()), cntD(counts.begin(), counts.end());
    if (!tiled) add(273, big ? 16 : 4, offD);
    add(277, 3, {static_cast<double>(spp)});
    if (!tiled) { add(278, 4, {static_cast<double>(th)}); add(279, big ? 16 : 4, cntD); }
    if (img.dpiX > 0) {
      add(282, 5, {img.dpiX});
      add(283, 5, {img.dpiY > 0 ? img.dpiY : img.dpiX});
      add(296, 3, {2});
    }
    add(284, 3, {1});
    add(305, 2, {}); es.back().bytes = std::string("NC") + '\0';
    if (tiled) {
      add(322, 4, {static_cast<double>(tw)});
      add(323, 4, {static_cast<double>(th)});
      add(324, big ? 16 : 4, offD);
      add(325, big ? 16 : 4, cntD);
    }
    if (spp == 2 || spp == 4) add(338, 3, {2}); // unassociated alpha
    else if (spp > 4) add(338, 3, std::vector<double>(spp - 1, 0));
    add(339, 3, std::vector<double>(spp, img.isFloat ? 3 : 1));
    auto keepNums = [&](const char *name, uint16_t id, uint16_t type) {
      auto it = img.extra.find(name);
      if (it != img.extra.end()) add(id, type, optNumbers(it->second));
    };
    keepNums("geo_pixel_scale", 33550, 12);
    keepNums("geo_tiepoint", 33922, 12);
    keepNums("geo_transform", 34264, 12);
    keepNums("geo_keys", 34735, 3);
    keepNums("geo_doubles", 34736, 12);
    if (img.extra.count("geo_ascii")) addText(34737, img.extra.at("geo_ascii").text());
    if (img.extra.count("gdal_metadata")) addText(42112, img.extra.at("gdal_metadata").text());
    if (img.extra.count("gdal_nodata")) addText(42113, img.extra.at("gdal_nodata").text());
    std::sort(es.begin(), es.end(), [](const E &a, const E &b2) { return a.id < b2.id; });
    // out-of-line values first
    static const int sz[] = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8, 4, 0, 0, 8, 8, 8};
    std::vector<std::string> vals;
    for (auto &e : es) {
      std::string v;
      if (e.type == 2) v = e.bytes;
      else
        for (double d : e.v) {
          switch (e.type) {
            case 3: putLE(v, static_cast<uint64_t>(d), 2); break;
            case 4: putLE(v, static_cast<uint64_t>(d), 4); break;
            case 16: putLE(v, static_cast<uint64_t>(d), 8); break;
            case 5: putLE(v, static_cast<uint64_t>(std::llround(d * 10000)), 4); putLE(v, 10000, 4); break;
            case 12: putF64LE(v, d); break;
          }
        }
      vals.push_back(v);
    }
    std::vector<uint64_t> where(es.size(), 0);
    for (size_t k = 0; k < es.size(); k++)
      if (vals[k].size() > static_cast<size_t>(off)) {
        if (out.size() % 2) out.push_back(0);
        where[k] = out.size();
        out += vals[k];
      }
    if (out.size() % 2) out.push_back(0);
    uint64_t ifdPos = out.size();
    setLE(out, prevNextPos, ifdPos, off);
    putLE(out, es.size(), big ? 8 : 2);
    for (size_t k = 0; k < es.size(); k++) {
      putLE(out, es[k].id, 2);
      putLE(out, es[k].type, 2);
      size_t unit = static_cast<size_t>(sz[es[k].type]);
      putLE(out, vals[k].size() / std::max<size_t>(1, unit), big ? 8 : 4);
      if (vals[k].size() > static_cast<size_t>(off)) putLE(out, where[k], off);
      else {
        std::string inl = vals[k];
        inl.resize(static_cast<size_t>(off), '\0');
        out += inl;
      }
    }
    prevNextPos = out.size();
    putLE(out, 0, off);
  }
  return out;
}

} // namespace io
} // namespace nc
