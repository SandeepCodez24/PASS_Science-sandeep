// SQL subset - see io_sql.h.
#include "io_sql.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <memory>
#include <set>

#include "../numpy_common.h"

namespace nc {
namespace io {

std::string sqlQuote(const std::string &s) {
  std::string q = "'";
  for (char c : s) { q.push_back(c); if (c == '\'') q.push_back('\''); }
  return q + "'";
}

std::string sqlIdent(const std::string &s) {
  std::string q = "\"";
  for (char c : s) { q.push_back(c); if (c == '"') q.push_back('"'); }
  return q + "\"";
}

std::string sqlLiteral(const Value &v) {
  if (v.isText) return sqlQuote(v.text());
  if (v.isBool()) return v.number != 0 ? "1" : "0";
  if (numpy::isPlainNumber(v) && std::isnan(v.number)) return "NULL";
  if (numpy::isPlainNumber(v)) return numberText(v.number, "%.17g");
  return sqlQuote(cellText(v));
}

namespace {

struct Tok {
  enum K { Word, Num, Str, Ident, Op, Param, End } k;
  std::string s;
  double n = 0;
};

bool lex(const std::string &q, std::vector<Tok> &out, std::string &err) {
  size_t i = 0;
  while (i < q.size()) {
    char c = q[i];
    if (std::isspace(static_cast<unsigned char>(c))) { i++; continue; }
    if (c == '-' && i + 1 < q.size() && q[i + 1] == '-') { while (i < q.size() && q[i] != '\n') i++; continue; }
    if (c == '\'' ) {
      std::string s;
      i++;
      while (i < q.size()) {
        if (q[i] == '\'') { if (i + 1 < q.size() && q[i + 1] == '\'') { s.push_back('\''); i += 2; continue; } break; }
        s.push_back(q[i++]);
      }
      if (i >= q.size()) { err = "SQL: a 'text' is never closed"; return false; }
      i++;
      out.push_back({Tok::Str, s});
      continue;
    }
    if (c == '"' || c == '`' || c == '[') {
      char close = c == '[' ? ']' : c;
      size_t e = q.find(close, i + 1);
      if (e == std::string::npos) { err = "SQL: a quoted name is never closed"; return false; }
      out.push_back({Tok::Ident, q.substr(i + 1, e - i - 1)});
      i = e + 1;
      continue;
    }
    if (std::isdigit(static_cast<unsigned char>(c)) || (c == '.' && i + 1 < q.size() && std::isdigit(static_cast<unsigned char>(q[i + 1])))) {
      char *e = nullptr;
      double d = std::strtod(q.c_str() + i, &e);
      Tok t{Tok::Num, q.substr(i, static_cast<size_t>(e - q.c_str()) - i)};
      t.n = d;
      out.push_back(t);
      i = static_cast<size_t>(e - q.c_str());
      continue;
    }
    if (std::isalpha(static_cast<unsigned char>(c)) || c == '_') {
      size_t b = i;
      while (i < q.size() && (std::isalnum(static_cast<unsigned char>(q[i])) || q[i] == '_' || q[i] == '$')) i++;
      out.push_back({Tok::Word, q.substr(b, i - b)});
      continue;
    }
    if (c == '?' || c == '$' || c == ':') {
      i++;
      while (i < q.size() && std::isalnum(static_cast<unsigned char>(q[i]))) i++;
      out.push_back({Tok::Param, "?"});
      continue;
    }
    static const char *ops[] = {"||", "<=", ">=", "<>", "!=", "==", "=", "<", ">", "+", "-", "*", "/", "%", "(", ")", ",", ".", ";"};
    bool found = false;
    for (const char *op : ops) {
      size_t l = std::char_traits<char>::length(op);
      if (q.compare(i, l, op) == 0) { out.push_back({Tok::Op, op}); i += l; found = true; break; }
    }
    if (!found) { err = std::string("SQL: unexpected '") + c + "'"; return false; }
  }
  out.push_back({Tok::End, ""});
  return true;
}

std::string up(std::string s) { for (char &c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c))); return s; }

struct Expr;
using EP = std::shared_ptr<Expr>;
struct Expr {
  enum K { Lit, Col, Param, Unary, Binary, Func, IsNull, Like, In, Between, Star } k;
  std::string op, name;
  Value lit;
  size_t param = 0;
  bool negate = false, distinct = false;
  std::vector<EP> args;
};

bool isNull(const Value &v) { return numpy::isPlainNumber(v) && !v.isText && std::isnan(v.number) && !v.isTime(); }
bool truthy(const Value &v) { return !isNull(v) && (v.isText ? !v.text().empty() : v.number != 0); }
double numOf(const Value &v) { return v.isText ? std::strtod(v.text().c_str(), nullptr) : v.number; }
bool isAggregate(const std::string &f) { return f == "COUNT" || f == "SUM" || f == "AVG" || f == "MIN" || f == "MAX" || f == "TOTAL" || f == "GROUP_CONCAT"; }

int compare(const Value &a, const Value &b) {
  if (a.isText && b.isText) return a.text() < b.text() ? -1 : a.text() > b.text() ? 1 : 0;
  if (a.isText != b.isText) { // numbers sort before text, as in SQLite
    if (!a.isText) { char *e; std::string t = b.text(); double d = std::strtod(t.c_str(), &e); if (*e == '\0' && !t.empty()) return a.number < d ? -1 : a.number > d ? 1 : 0; return -1; }
    char *e; std::string t = a.text(); double d = std::strtod(t.c_str(), &e); if (*e == '\0' && !t.empty()) return d < b.number ? -1 : d > b.number ? 1 : 0; return 1;
  }
  return a.number < b.number ? -1 : a.number > b.number ? 1 : 0;
}

struct Parser {
  std::vector<Tok> t;
  size_t i = 0, params = 0;
  std::string err;
  const Tok &cur() const { return t[i]; }
  bool word(const char *w) { if (cur().k == Tok::Word && up(cur().s) == w) { i++; return true; } return false; }
  bool peekWord(const char *w) const { return cur().k == Tok::Word && up(cur().s) == w; }
  bool op(const char *o) { if (cur().k == Tok::Op && cur().s == o) { i++; return true; } return false; }
  EP fail(const std::string &m) { if (err.empty()) err = "SQL: " + m; return nullptr; }
  EP primary() {
    const Tok tk = cur();
    if (op("(")) { EP e = expr(); if (!op(")")) return fail("missing )"); return e; }
    if (tk.k == Tok::Num) { i++; auto e = std::make_shared<Expr>(); e->k = Expr::Lit; e->lit = Value(tk.n); return e; }
    if (tk.k == Tok::Str) { i++; auto e = std::make_shared<Expr>(); e->k = Expr::Lit; e->lit = Value(tk.s); return e; }
    if (tk.k == Tok::Param) { i++; auto e = std::make_shared<Expr>(); e->k = Expr::Param; e->param = params++; return e; }
    if (op("*")) { auto e = std::make_shared<Expr>(); e->k = Expr::Star; return e; }
    if (tk.k == Tok::Word || tk.k == Tok::Ident) {
      i++;
      std::string u = up(tk.s);
      if (tk.k == Tok::Word && (u == "NULL")) { auto e = std::make_shared<Expr>(); e->k = Expr::Lit; e->lit = Value(std::nan("")); return e; }
      if (tk.k == Tok::Word && (u == "TRUE" || u == "FALSE")) { auto e = std::make_shared<Expr>(); e->k = Expr::Lit; e->lit = Value(u == "TRUE" ? 1.0 : 0.0); return e; }
      if (tk.k == Tok::Word && op("(")) {
        auto e = std::make_shared<Expr>();
        e->k = Expr::Func;
        e->name = u;
        if (word("DISTINCT")) e->distinct = true;
        if (!op(")")) {
          do { EP a = expr(); if (!a) return nullptr; e->args.push_back(a); } while (op(","));
          if (!op(")")) return fail("missing ) after " + u + "(");
        }
        return e;
      }
      std::string name = tk.s;
      if (op(".")) { // table.col
        if (cur().k == Tok::Word || cur().k == Tok::Ident) { name = cur().s; i++; }
        else if (op("*")) { auto e = std::make_shared<Expr>(); e->k = Expr::Star; return e; }
      }
      auto e = std::make_shared<Expr>();
      e->k = Expr::Col;
      e->name = name;
      return e;
    }
    return fail("unexpected '" + tk.s + "'");
  }
  EP unary() {
    if (op("-")) { auto e = std::make_shared<Expr>(); e->k = Expr::Unary; e->op = "-"; EP a = unary(); if (!a) return nullptr; e->args = {a}; return e; }
    if (op("+")) return unary();
    return primary();
  }
  EP binary(int lvl) {
    static const std::vector<std::vector<std::string>> levels = {{"||"}, {"*", "/", "%"}, {"+", "-"}};
    if (lvl == 3) return unary();
    EP a = binary(lvl + 1);
    if (!a) return nullptr;
    // levels are listed tightest-first; evaluate in reverse for precedence
    for (;;) {
      bool matched = false;
      for (const auto &o : levels[2 - lvl])
        if (cur().k == Tok::Op && cur().s == o) {
          i++;
          EP b = binary(lvl + 1);
          if (!b) return nullptr;
          auto e = std::make_shared<Expr>();
          e->k = Expr::Binary;
          e->op = o;
          e->args = {a, b};
          a = e;
          matched = true;
          break;
        }
      if (!matched) return a;
    }
  }
  EP comparison() {
    EP a = binary(0);
    if (!a) return nullptr;
    for (const char *o : {"<=", ">=", "<>", "!=", "==", "=", "<", ">"})
      if (op(o)) {
        EP b = binary(0);
        if (!b) return nullptr;
        auto e = std::make_shared<Expr>();
        e->k = Expr::Binary;
        e->op = o;
        e->args = {a, b};
        return e;
      }
    if (word("IS")) {
      auto e = std::make_shared<Expr>();
      e->k = Expr::IsNull;
      e->negate = word("NOT");
      if (!word("NULL")) return fail("IS must be followed by NULL or NOT NULL");
      e->args = {a};
      return e;
    }
    bool neg = word("NOT");
    if (word("LIKE") || word("GLOB")) {
      auto e = std::make_shared<Expr>();
      e->k = Expr::Like;
      e->negate = neg;
      EP b = binary(0);
      if (!b) return nullptr;
      e->args = {a, b};
      return e;
    }
    if (word("IN")) {
      auto e = std::make_shared<Expr>();
      e->k = Expr::In;
      e->negate = neg;
      e->args = {a};
      if (!op("(")) return fail("IN needs (list)");
      do { EP b = expr(); if (!b) return nullptr; e->args.push_back(b); } while (op(","));
      if (!op(")")) return fail("missing ) after IN list");
      return e;
    }
    if (word("BETWEEN")) {
      auto e = std::make_shared<Expr>();
      e->k = Expr::Between;
      e->negate = neg;
      EP lo = binary(0);
      if (!word("AND")) return fail("BETWEEN needs AND");
      EP hi = binary(0);
      if (!lo || !hi) return nullptr;
      e->args = {a, lo, hi};
      return e;
    }
    if (neg) return fail("NOT here must be followed by LIKE, IN or BETWEEN");
    return a;
  }
  EP notExpr() {
    if (word("NOT")) { auto e = std::make_shared<Expr>(); e->k = Expr::Unary; e->op = "NOT"; EP a = notExpr(); if (!a) return nullptr; e->args = {a}; return e; }
    return comparison();
  }
  EP andExpr() {
    EP a = notExpr();
    while (a && word("AND")) { EP b = notExpr(); if (!b) return nullptr; auto e = std::make_shared<Expr>(); e->k = Expr::Binary; e->op = "AND"; e->args = {a, b}; a = e; }
    return a;
  }
  EP expr() {
    EP a = andExpr();
    while (a && word("OR")) { EP b = andExpr(); if (!b) return nullptr; auto e = std::make_shared<Expr>(); e->k = Expr::Binary; e->op = "OR"; e->args = {a, b}; a = e; }
    return a;
  }
};

bool likeMatch(const std::string &s, const std::string &p, size_t si = 0, size_t pi = 0) {
  while (pi < p.size()) {
    if (p[pi] == '%') {
      for (size_t k = si; k <= s.size(); k++) if (likeMatch(s, p, k, pi + 1)) return true;
      return false;
    }
    if (si >= s.size()) return false;
    if (p[pi] != '_' && std::tolower(static_cast<unsigned char>(p[pi])) != std::tolower(static_cast<unsigned char>(s[si]))) return false;
    si++;
    pi++;
  }
  return si == s.size();
}

struct Ctx {
  const std::vector<std::string> *cols;
  const std::vector<Value> *row;
  const std::vector<const std::vector<Value> *> *group; // aggregate rows
  const std::vector<Value> *params;
  std::string err;
};

Value eval(const Expr &e, Ctx &c);

Value colValue(const std::string &name, const std::vector<std::string> &cols, const std::vector<Value> &row, std::string &err) {
  for (size_t k = 0; k < cols.size(); k++) if (cols[k] == name) return row[k];
  for (size_t k = 0; k < cols.size(); k++) if (lower(cols[k]) == lower(name)) return row[k];
  if (err.empty()) {
    std::string list;
    for (size_t k = 0; k < cols.size() && k < 12; k++) list += (k ? ", " : "") + cols[k];
    err = "SQL: no column '" + name + "' (columns: " + list + ")";
  }
  return Value(std::nan(""));
}

Value aggregate(const Expr &e, Ctx &c) {
  std::vector<Value> vals;
  std::set<std::string> seen;
  bool star = e.args.empty() || e.args[0]->k == Expr::Star;
  for (const auto *r : *c.group) {
    if (star) { vals.push_back(Value(1.0)); continue; }
    Ctx inner{c.cols, r, nullptr, c.params, ""};
    Value v = eval(*e.args[0], inner);
    if (!inner.err.empty()) { c.err = inner.err; return Value(0.0); }
    if (isNull(v)) continue;
    if (e.distinct) { std::string key = cellText(v); if (seen.count(key)) continue; seen.insert(key); }
    vals.push_back(v);
  }
  if (e.name == "COUNT") return Value(static_cast<double>(vals.size()));
  if (e.name == "GROUP_CONCAT") { std::string s; for (size_t k = 0; k < vals.size(); k++) s += (k ? "," : "") + cellText(vals[k]); return Value(s); }
  if (vals.empty()) return e.name == "TOTAL" ? Value(0.0) : Value(std::nan(""));
  if (e.name == "SUM" || e.name == "TOTAL" || e.name == "AVG") {
    double s = 0;
    for (const auto &v : vals) s += numOf(v);
    return Value(e.name == "AVG" ? s / vals.size() : s);
  }
  Value best = vals[0];
  for (const auto &v : vals) if ((e.name == "MIN") ? compare(v, best) < 0 : compare(v, best) > 0) best = v;
  return best;
}

Value eval(const Expr &e, Ctx &c) {
  switch (e.k) {
    case Expr::Lit: return e.lit;
    case Expr::Param:
      if (e.param >= c.params->size()) { c.err = "SQL: the query has more ? than params given"; return Value(0.0); }
      return (*c.params)[e.param];
    case Expr::Col: return colValue(e.name, *c.cols, *c.row, c.err);
    case Expr::Star: return Value(1.0);
    case Expr::Unary: {
      Value a = eval(*e.args[0], c);
      if (e.op == "NOT") return isNull(a) ? a : Value(truthy(a) ? 0.0 : 1.0);
      return isNull(a) ? a : Value(-numOf(a));
    }
    case Expr::IsNull: { bool n = isNull(eval(*e.args[0], c)); return Value((n != e.negate) ? 1.0 : 0.0); }
    case Expr::Like: {
      Value a = eval(*e.args[0], c), p = eval(*e.args[1], c);
      if (isNull(a)) return a;
      return Value(likeMatch(cellText(a), cellText(p)) != e.negate ? 1.0 : 0.0);
    }
    case Expr::In: {
      Value a = eval(*e.args[0], c);
      if (isNull(a)) return a;
      bool found = false;
      for (size_t k = 1; k < e.args.size() && !found; k++) found = compare(a, eval(*e.args[k], c)) == 0;
      return Value(found != e.negate ? 1.0 : 0.0);
    }
    case Expr::Between: {
      Value a = eval(*e.args[0], c), lo = eval(*e.args[1], c), hi = eval(*e.args[2], c);
      if (isNull(a)) return a;
      bool in = compare(a, lo) >= 0 && compare(a, hi) <= 0;
      return Value(in != e.negate ? 1.0 : 0.0);
    }
    case Expr::Binary: {
      if (e.op == "AND") { Value a = eval(*e.args[0], c); if (!isNull(a) && !truthy(a)) return Value(0.0); Value b = eval(*e.args[1], c); if (!isNull(b) && !truthy(b)) return Value(0.0); return (isNull(a) || isNull(b)) ? Value(std::nan("")) : Value(1.0); }
      if (e.op == "OR") { Value a = eval(*e.args[0], c); if (truthy(a)) return Value(1.0); Value b = eval(*e.args[1], c); if (truthy(b)) return Value(1.0); return (isNull(a) || isNull(b)) ? Value(std::nan("")) : Value(0.0); }
      Value a = eval(*e.args[0], c), b = eval(*e.args[1], c);
      if (e.op == "||") return (isNull(a) || isNull(b)) ? Value(std::nan("")) : Value(cellText(a) + cellText(b));
      if (isNull(a) || isNull(b)) return Value(std::nan(""));
      if (e.op == "=" || e.op == "==") return Value(compare(a, b) == 0 ? 1.0 : 0.0);
      if (e.op == "!=" || e.op == "<>") return Value(compare(a, b) != 0 ? 1.0 : 0.0);
      if (e.op == "<") return Value(compare(a, b) < 0 ? 1.0 : 0.0);
      if (e.op == "<=") return Value(compare(a, b) <= 0 ? 1.0 : 0.0);
      if (e.op == ">") return Value(compare(a, b) > 0 ? 1.0 : 0.0);
      if (e.op == ">=") return Value(compare(a, b) >= 0 ? 1.0 : 0.0);
      double x = numOf(a), y = numOf(b);
      if (e.op == "+") return Value(x + y);
      if (e.op == "-") return Value(x - y);
      if (e.op == "*") return Value(x * y);
      if (e.op == "/") return y == 0 ? Value(std::nan("")) : Value(x / y);
      if (e.op == "%") return y == 0 ? Value(std::nan("")) : Value(std::fmod(x, y));
      return Value(0.0);
    }
    case Expr::Func: {
      if (isAggregate(e.name)) {
        if (!c.group) { c.err = "SQL: " + e.name + "() is only allowed in SELECT / HAVING"; return Value(0.0); }
        return aggregate(e, c);
      }
      std::vector<Value> a;
      for (const auto &x : e.args) a.push_back(eval(*x, c));
      auto arg = [&](size_t k) { return k < a.size() ? a[k] : Value(std::nan("")); };
      if (e.name == "ABS") return isNull(arg(0)) ? arg(0) : Value(std::fabs(numOf(arg(0))));
      if (e.name == "ROUND") { double p = std::pow(10.0, a.size() > 1 ? numOf(a[1]) : 0); return isNull(arg(0)) ? arg(0) : Value(std::round(numOf(arg(0)) * p) / p); }
      if (e.name == "LOWER") return Value(lower(cellText(arg(0))));
      if (e.name == "UPPER") { std::string s = cellText(arg(0)); for (char &ch : s) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch))); return Value(s); }
      if (e.name == "LENGTH") return isNull(arg(0)) ? arg(0) : Value(static_cast<double>(cellText(arg(0)).size()));
      if (e.name == "COALESCE" || e.name == "IFNULL") { for (const auto &v : a) if (!isNull(v)) return v; return Value(std::nan("")); }
      if (e.name == "SUBSTR" || e.name == "SUBSTRING") {
        std::string s = cellText(arg(0));
        long long st = static_cast<long long>(numOf(arg(1))), n = a.size() > 2 ? static_cast<long long>(numOf(a[2])) : static_cast<long long>(s.size());
        if (st < 1) st = 1;
        return Value(static_cast<size_t>(st - 1) < s.size() ? s.substr(static_cast<size_t>(st - 1), static_cast<size_t>(std::max(0LL, n))) : std::string());
      }
      if (e.name == "TYPEOF") { Value v = arg(0); return Value(std::string(isNull(v) ? "null" : v.isText ? "text" : v.number == std::floor(v.number) ? "integer" : "real")); }
      c.err = "SQL: function " + e.name + "() is not built in";
      return Value(0.0);
    }
  }
  return Value(0.0);
}

bool hasAggregate(const Expr &e) {
  if (e.k == Expr::Func && isAggregate(e.name)) return true;
  for (const auto &a : e.args) if (hasAggregate(*a)) return true;
  return false;
}

std::string exprName(const Expr &e) {
  switch (e.k) {
    case Expr::Col: return e.name;
    case Expr::Func: {
      std::string s = e.name + "(";
      for (size_t k = 0; k < e.args.size(); k++) s += (k ? "," : "") + exprName(*e.args[k]);
      return s + (e.args.empty() ? "*" : "") + ")";
    }
    case Expr::Star: return "*";
    case Expr::Lit: return cellText(e.lit);
    default: return "expr";
  }
}

} // namespace

bool sqlFilter(const Table &t, const std::string &where, const std::vector<Value> &params, std::vector<size_t> &keep, std::string &err) {
  Parser p;
  if (!lex(where, p.t, err)) return false;
  EP e = p.expr();
  if (!e || p.cur().k != Tok::End) { err = p.err.empty() ? "SQL: unexpected text after the condition" : p.err; return false; }
  keep.clear();
  for (size_t r = 0; r < t.rows.size(); r++) {
    Ctx c{&t.cols, &t.rows[r], nullptr, &params, ""};
    Value v = eval(*e, c);
    if (!c.err.empty()) { err = c.err; return false; }
    if (truthy(v)) keep.push_back(r);
  }
  return true;
}

bool sqlSelect(const std::string &sql, const std::vector<Value> &params,
               const std::function<bool(const std::string &, Table &, std::string &)> &lookup, Table &out, std::string &err) {
  Parser p;
  if (!lex(sql, p.t, err)) return false;
  if (!p.word("SELECT")) { err = "only SELECT queries are built in for file databases (use save_sqlite to change data)"; return false; }
  bool distinct = p.word("DISTINCT");
  struct Item { EP e; std::string alias; };
  std::vector<Item> items;
  do {
    EP e = p.expr();
    if (!e) { err = p.err; return false; }
    std::string alias;
    if (p.word("AS")) { alias = p.cur().s; p.i++; }
    else if (p.cur().k == Tok::Ident || (p.cur().k == Tok::Word && !p.peekWord("FROM"))) { alias = p.cur().s; p.i++; }
    items.push_back({e, alias});
  } while (p.op(","));
  Table src;
  if (p.word("FROM")) {
    std::string name = p.cur().s;
    p.i++;
    if (p.op(".")) { name = p.cur().s; p.i++; } // schema.table
    if (!lookup(name, src, err)) return false;
    if (p.word("AS") || (p.cur().k == Tok::Word && !p.peekWord("WHERE") && !p.peekWord("GROUP") && !p.peekWord("ORDER") && !p.peekWord("LIMIT"))) p.i++;
  } else {
    src.rows.push_back({});
  }
  EP where, having;
  std::vector<EP> groupBy;
  std::vector<std::pair<EP, bool>> orderBy;
  long long limit = -1, offset = 0;
  if (p.word("WHERE")) { where = p.expr(); if (!where) { err = p.err; return false; } }
  if (p.word("GROUP")) {
    if (!p.word("BY")) { err = "SQL: GROUP must be followed by BY"; return false; }
    do { EP g = p.expr(); if (!g) { err = p.err; return false; } groupBy.push_back(g); } while (p.op(","));
  }
  if (p.word("HAVING")) { having = p.expr(); if (!having) { err = p.err; return false; } }
  if (p.word("ORDER")) {
    if (!p.word("BY")) { err = "SQL: ORDER must be followed by BY"; return false; }
    do {
      EP o = p.expr();
      if (!o) { err = p.err; return false; }
      bool desc = p.word("DESC");
      if (!desc) p.word("ASC");
      orderBy.push_back({o, desc});
    } while (p.op(","));
  }
  if (p.word("LIMIT")) {
    Value l = Value(p.cur().n);
    if (p.cur().k == Tok::Param) l = p.params < params.size() ? params[p.params++] : Value(-1.0);
    limit = static_cast<long long>(l.number);
    p.i++;
    if (p.word("OFFSET") || p.op(",")) { offset = static_cast<long long>(p.cur().n); p.i++; }
  }
  p.op(";");
  if (p.cur().k != Tok::End) { err = "SQL: unexpected '" + p.cur().s + "'"; return false; }
  // filter
  std::vector<const std::vector<Value> *> rows;
  for (const auto &r : src.rows) {
    if (where) {
      Ctx c{&src.cols, &r, nullptr, &params, ""};
      Value v = eval(*where, c);
      if (!c.err.empty()) { err = c.err; return false; }
      if (!truthy(v)) continue;
    }
    rows.push_back(&r);
  }
  bool aggregateQuery = !groupBy.empty() || having;
  for (const auto &it : items) if (hasAggregate(*it.e)) aggregateQuery = true;
  // output columns
  for (const auto &it : items) {
    if (it.e->k == Expr::Star) { for (const auto &c : src.cols) out.cols.push_back(c); continue; }
    out.cols.push_back(!it.alias.empty() ? it.alias : exprName(*it.e));
  }
  struct OutRow { std::vector<Value> vals, keys; };
  std::vector<OutRow> result;
  auto project = [&](const std::vector<Value> &row, const std::vector<const std::vector<Value> *> *group, OutRow &o) -> bool {
    for (const auto &it : items) {
      if (it.e->k == Expr::Star) { for (const auto &v : row) o.vals.push_back(v); continue; }
      Ctx c{&src.cols, &row, group, &params, ""};
      o.vals.push_back(eval(*it.e, c));
      if (!c.err.empty()) { err = c.err; return false; }
    }
    for (const auto &ob : orderBy) {
      // ORDER BY may name an output alias
      Value key(std::nan(""));
      bool found = false;
      if (ob.first->k == Expr::Col)
        for (size_t k = 0; k < out.cols.size() && k < o.vals.size(); k++)
          if (lower(out.cols[k]) == lower(ob.first->name)) { key = o.vals[k]; found = true; break; }
      if (!found && ob.first->k == Expr::Lit && ob.first->lit.number >= 1 && static_cast<size_t>(ob.first->lit.number) <= o.vals.size()) {
        key = o.vals[static_cast<size_t>(ob.first->lit.number) - 1];
        found = true;
      }
      if (!found) {
        Ctx c{&src.cols, &row, group, &params, ""};
        key = eval(*ob.first, c);
        if (!c.err.empty()) { err = c.err; return false; }
      }
      o.keys.push_back(key);
    }
    return true;
  };
  static const std::vector<Value> emptyRow;
  if (aggregateQuery) {
    std::map<std::string, std::vector<const std::vector<Value> *>> groups;
    std::vector<std::string> order;
    for (const auto *r : rows) {
      std::string key;
      for (const auto &g : groupBy) {
        Ctx c{&src.cols, r, nullptr, &params, ""};
        key += cellText(eval(*g, c)) + "\x1F";
        if (!c.err.empty()) { err = c.err; return false; }
      }
      if (!groups.count(key)) order.push_back(key);
      groups[key].push_back(r);
    }
    if (groups.empty() && groupBy.empty()) { order.push_back(""); groups[""] = {}; }
    for (const auto &k : order) {
      auto &g = groups[k];
      const std::vector<Value> &first = g.empty() ? (src.cols.empty() ? emptyRow : std::vector<Value>(src.cols.size(), Value(std::nan("")))) : *g[0];
      std::vector<Value> firstCopy = first;
      if (having) {
        Ctx c{&src.cols, &firstCopy, &g, &params, ""};
        Value v = eval(*having, c);
        if (!c.err.empty()) { err = c.err; return false; }
        if (!truthy(v)) continue;
      }
      OutRow o;
      if (!project(firstCopy, &g, o)) return false;
      result.push_back(std::move(o));
    }
  } else {
    for (const auto *r : rows) {
      OutRow o;
      if (!project(*r, nullptr, o)) return false;
      result.push_back(std::move(o));
    }
  }
  if (distinct) {
    std::set<std::string> seen;
    std::vector<OutRow> uniq;
    for (auto &o : result) {
      std::string k;
      for (const auto &v : o.vals) k += cellText(v) + "\x1F";
      if (seen.insert(k).second) uniq.push_back(std::move(o));
    }
    result.swap(uniq);
  }
  if (!orderBy.empty())
    std::stable_sort(result.begin(), result.end(), [&](const OutRow &a, const OutRow &b) {
      for (size_t k = 0; k < orderBy.size(); k++) {
        bool an = isNull(a.keys[k]), bn = isNull(b.keys[k]);
        int c = an && bn ? 0 : an ? -1 : bn ? 1 : compare(a.keys[k], b.keys[k]);
        if (c) return orderBy[k].second ? c > 0 : c < 0;
      }
      return false;
    });
  size_t from = static_cast<size_t>(std::max(0LL, offset));
  for (size_t k = from; k < result.size() && (limit < 0 || static_cast<long long>(k - from) < limit); k++) out.rows.push_back(result[k].vals);
  normalizeTable(out);
  return true;
}

} // namespace io
} // namespace nc
