// Little/big-endian byte readers and writers shared by the binary formats
// (zip, OLE2, PNG, TIFF, WAV, MAT, FITS, SQLite, HDF5, Parquet ...).
#ifndef NC_IO_BYTES_H
#define NC_IO_BYTES_H

#include <cstdint>
#include <cstring>
#include <string>

namespace nc {
namespace io {

inline uint64_t getLE(const std::string &s, size_t at, int n) {
  uint64_t v = 0;
  for (int k = n - 1; k >= 0; k--)
    v = (v << 8) | (at + k < s.size() ? static_cast<unsigned char>(s[at + k]) : 0);
  return v;
}
inline uint64_t getBE(const std::string &s, size_t at, int n) {
  uint64_t v = 0;
  for (int k = 0; k < n; k++)
    v = (v << 8) | (at + k < s.size() ? static_cast<unsigned char>(s[at + k]) : 0);
  return v;
}
inline uint16_t u16le(const std::string &s, size_t at) { return static_cast<uint16_t>(getLE(s, at, 2)); }
inline uint32_t u32le(const std::string &s, size_t at) { return static_cast<uint32_t>(getLE(s, at, 4)); }
inline uint64_t u64le(const std::string &s, size_t at) { return getLE(s, at, 8); }
inline uint16_t u16be(const std::string &s, size_t at) { return static_cast<uint16_t>(getBE(s, at, 2)); }
inline uint32_t u32be(const std::string &s, size_t at) { return static_cast<uint32_t>(getBE(s, at, 4)); }
inline uint64_t u64be(const std::string &s, size_t at) { return getBE(s, at, 8); }
inline double f64le(const std::string &s, size_t at) {
  uint64_t u = u64le(s, at);
  double d;
  std::memcpy(&d, &u, 8);
  return d;
}
inline double f64be(const std::string &s, size_t at) {
  uint64_t u = u64be(s, at);
  double d;
  std::memcpy(&d, &u, 8);
  return d;
}
inline float f32le(const std::string &s, size_t at) {
  uint32_t u = u32le(s, at);
  float f;
  std::memcpy(&f, &u, 4);
  return f;
}
inline float f32be(const std::string &s, size_t at) {
  uint32_t u = u32be(s, at);
  float f;
  std::memcpy(&f, &u, 4);
  return f;
}

inline void putLE(std::string &s, uint64_t v, int n) {
  for (int k = 0; k < n; k++)
    s.push_back(static_cast<char>((v >> (8 * k)) & 0xFF));
}
inline void putBE(std::string &s, uint64_t v, int n) {
  for (int k = n - 1; k >= 0; k--)
    s.push_back(static_cast<char>((v >> (8 * k)) & 0xFF));
}
inline void setLE(std::string &s, size_t at, uint64_t v, int n) {
  for (int k = 0; k < n; k++)
    s[at + k] = static_cast<char>((v >> (8 * k)) & 0xFF);
}
inline void setBE(std::string &s, size_t at, uint64_t v, int n) {
  for (int k = 0; k < n; k++)
    s[at + k] = static_cast<char>((v >> (8 * (n - 1 - k))) & 0xFF);
}
inline void putF64LE(std::string &s, double d) {
  uint64_t u;
  std::memcpy(&u, &d, 8);
  putLE(s, u, 8);
}
inline void putF64BE(std::string &s, double d) {
  uint64_t u;
  std::memcpy(&u, &d, 8);
  putBE(s, u, 8);
}
inline void putF32LE(std::string &s, float f) {
  uint32_t u;
  std::memcpy(&u, &f, 4);
  putLE(s, u, 4);
}
inline void putF32BE(std::string &s, float f) {
  uint32_t u;
  std::memcpy(&u, &f, 4);
  putBE(s, u, 4);
}

} // namespace io
} // namespace nc

#endif // NC_IO_BYTES_H
