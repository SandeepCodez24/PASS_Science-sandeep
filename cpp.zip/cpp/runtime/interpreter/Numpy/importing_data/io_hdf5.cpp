// CATEGORY 10 - read_/load_/save_ h5, hdf, he5 (HDF5 and HDF-EOS5), and the
// MAT-file v7.3 hooks (MATLAB's HDF5 layout).
#include <algorithm>
#include <cmath>
#include <ctime>
#include <functional>
#include <iostream>
#include <map>

#include "../numpy_common.h"
#include "io_formats.h"
#include "io_h5.h"
#include "io_mat.h"

namespace nc {
namespace io {

// ---- shared helpers (io_h5.h) ---------------------------------------------------------------

bool h5ParseSlice(const std::string &spec, const std::vector<uint64_t> &dims, std::vector<std::pair<size_t, size_t>> &ranges,
                  std::string &err, std::vector<bool> *single) {
  ranges.clear();
  if (single) single->assign(dims.size(), false);
  std::vector<std::string> parts;
  size_t s = 0;
  while (s <= spec.size()) {
    size_t c = spec.find(',', s);
    if (c == std::string::npos) c = spec.size();
    parts.push_back(trim(spec.substr(s, c - s)));
    s = c + 1;
  }
  bool zeroBased = false;
  for (const auto &p : parts)
    if (!p.empty() && p[0] == '0') zeroBased = true;
  if (parts.size() > dims.size()) { err = "slice \"" + spec + "\" has " + std::to_string(parts.size()) + " parts, the data has " + std::to_string(dims.size()) + " dimension(s)"; return false; }
  for (size_t d = 0; d < dims.size(); d++) {
    size_t len = static_cast<size_t>(dims[d]);
    std::string p = d < parts.size() ? parts[d] : ":";
    if (p.empty() || p == ":") { ranges.push_back({0, len}); continue; }
    if (single && p.find(':') == std::string::npos) (*single)[d] = true;
    size_t colon = p.find(':');
    auto num = [&](const std::string &t, long long def) { std::string x = trim(t); if (x.empty()) return def; if (x == "end") return static_cast<long long>(len); return std::atoll(x.c_str()); };
    long long a, b;
    if (zeroBased) {
      a = num(p.substr(0, colon), 0);
      b = colon == std::string::npos ? a + 1 : num(p.substr(colon + 1), static_cast<long long>(len));
      if (a < 0 || b <= a || b > static_cast<long long>(len)) { err = "slice \"" + p + "\" is outside 0.." + std::to_string(len) + " (0-based)"; return false; }
    } else {
      a = num(p.substr(0, colon), 1);
      b = colon == std::string::npos ? a : num(p.substr(colon + 1), static_cast<long long>(len));
      if (a < 1 || b < a || b > static_cast<long long>(len)) { err = "slice \"" + p + "\" is outside 1.." + std::to_string(len); return false; }
      a -= 1;
    }
    ranges.push_back({static_cast<size_t>(a), static_cast<size_t>(b)});
  }
  return true;
}

Value h5AttrsDict(const H5Object &o, const H5Reader *r) {
  Fields f;
  for (const auto &a : o.attrs) {
    if (a.value.isRef && r) {
      std::vector<std::string> paths;
      for (double ad : a.value.nums) { const H5Object *t = r->byAddr(static_cast<uint64_t>(ad)); paths.push_back(t ? t->path : ""); }
      f[a.name] = paths.size() == 1 ? Value(paths[0]) : textList(paths);
    } else if (a.value.isVlen && r) { // DIMENSION_LIST style: lists of references
      std::vector<Value> items;
      for (const auto &it : a.value.items) {
        if (it.isRef) {
          std::vector<std::string> paths;
          for (double ad : it.nums) { const H5Object *t = r->byAddr(static_cast<uint64_t>(ad)); paths.push_back(t ? t->path : ""); }
          items.push_back(paths.size() == 1 ? Value(paths[0]) : textList(paths));
        } else items.push_back(h5ToValue(it));
      }
      f[a.name] = items.size() == 1 ? items[0] : Value(std::move(items));
    } else f[a.name] = h5ToValue(a.value);
  }
  return Value(f);
}

namespace {

bool openH5(const std::string &file, std::string &bytes, H5Reader &r, std::string &err) {
  if (!readSource(file, bytes, err)) return false;
  return r.open(bytes, err);
}

std::string compressionOf(const H5Object &o) {
  std::string s;
  for (const auto &f : o.filters) {
    std::string n = f.id == 1 ? "gzip" : f.id == 2 ? "shuffle" : f.id == 3 ? "fletcher32" : f.id == 32000 ? "lzf" : f.id == 32015 ? "zstd" : f.id == 4 ? "szip" : "filter " + std::to_string(f.id);
    if (n == "shuffle" || n == "fletcher32") continue;
    s += (s.empty() ? "" : "+") + n;
  }
  return s.empty() ? "none" : s;
}

size_t elementCount(const H5Object &o) {
  size_t n = 1;
  if (!o.scalar) for (auto d : o.dims) n *= static_cast<size_t>(d);
  return n;
}

// text attributes of the root (title, history, ...) + HDF-EOS structure metadata
std::vector<std::string> boxesOf(const H5Reader &r, std::string &err) {
  std::vector<std::string> out;
  for (const auto &a : r.root.attrs)
    if (a.value.isText) for (const auto &s : a.value.strs) out.push_back(a.name + ": " + s);
  if (const H5Object *info = r.find("/HDFEOS INFORMATION")) {
    for (const auto &a : info->attrs) if (a.value.isText && !a.value.strs.empty()) out.push_back(a.name + ": " + a.value.strs[0]);
    for (const auto &k : info->kids)
      if (!k.group && k.name.rfind("StructMetadata", 0) == 0) {
        H5Value v;
        if (r.readData(k, {}, v, err) && v.isText && !v.strs.empty()) out.push_back(k.name + ": " + v.strs[0]);
      }
  }
  err.clear();
  return out;
}

Value datasetValue(const H5Reader &r, const H5Object &o, const std::string &slice, std::string &err) {
  std::vector<std::pair<size_t, size_t>> ranges;
  std::vector<bool> single;
  if (!slice.empty() && !h5ParseSlice(slice, o.dims, ranges, err, &single)) return Value(0.0);
  H5Value v;
  if (!r.readData(o, ranges, v, err)) return Value(0.0);
  if (!single.empty()) { // one index along a dim drops that dim (NumPy)
    std::vector<size_t> s;
    for (size_t d = 0; d < v.shape.size(); d++) if (d >= single.size() || !single[d]) s.push_back(v.shape[d]);
    v.shape = s;
  }
  if (v.isRef) { // object references -> the paths they name
    std::vector<std::string> paths;
    for (double ad : v.nums) { const H5Object *t = r.byAddr(static_cast<uint64_t>(ad)); paths.push_back(t ? t->path : ""); }
    return paths.size() == 1 ? Value(paths[0]) : textList(paths);
  }
  return h5ToValue(v);
}

// group -> dict of child values (datasets read in full)
bool treeValue(const H5Reader &r, const H5Object &g, Value &out, std::string &err, int depth = 0) {
  Fields f;
  for (const auto &k : g.kids) {
    if (!k.softTarget.empty()) { f[k.name] = Value("-> " + k.softTarget); continue; }
    if (k.group) {
      Value sub;
      if (!treeValue(r, k, sub, err, depth + 1)) return false;
      f[k.name] = sub;
    } else {
      Value v = datasetValue(r, k, "", err);
      if (!err.empty()) { err = k.path + ": " + err; return false; }
      f[k.name] = v;
    }
  }
  out = Value(f);
  return true;
}

void allAttrs(const H5Reader &r, const H5Object &o, Fields &f) {
  if (!o.attrs.empty()) f[o.path] = h5AttrsDict(o, &r);
  for (const auto &k : o.kids) allAttrs(r, k, f);
}

// read_<fmt>(file, path, slice, attr, swath, box)
void readH5(const std::string &fn, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev(fn, file);
  H5Reader r;
  if (!openH5(file, bytes, r, err)) return ctx.fail(err);
  std::string path = optText(a[1]), slice = optText(a[2]), swath = optText(a[4]);
  const H5Object *target = nullptr;
  if (!swath.empty()) {
    target = r.find("/HDFEOS/SWATHS/" + swath);
    if (!target) {
      std::vector<std::string> names;
      if (const H5Object *s = r.find("/HDFEOS/SWATHS")) for (const auto &k : s->kids) names.push_back(k.name);
      return ctx.fail("no swath '" + swath + "'" + (names.empty() ? " (the file has no HDF-EOS swaths)" : " - swaths: " + [&] { std::string j; for (auto &n : names) j += (j.empty() ? "" : ", ") + n; return j; }()));
    }
    if (!path.empty()) {
      const H5Object *inner = r.find(target->path + "/" + path);
      if (!inner) inner = r.find(target->path + "/Data Fields/" + path);
      if (!inner) inner = r.find(target->path + "/Geolocation Fields/" + path);
      if (!inner) return ctx.fail("swath '" + swath + "' has no field '" + path + "'");
      target = inner;
    }
  } else if (!path.empty()) {
    target = r.find(path);
    if (!target) return ctx.fail("no dataset or group '" + path + "' in the file");
  } else {
    std::vector<const H5Object *> all;
    r.walk(r.root, all);
    const H5Object *only = nullptr;
    size_t n = 0;
    for (const auto *o : all) if (!o->group && o->softTarget.empty()) { only = o; n++; }
    target = n == 1 ? only : &r.root;
  }
  Value data;
  if (target->group) {
    if (!slice.empty()) return ctx.fail("slice= needs a dataset - '" + target->path + "' is a group (give path=)");
    Fields f;
    // HDF-EOS swath: flatten Data Fields + Geolocation Fields
    if (!swath.empty() && path.empty()) {
      for (const char *sub : {"Geolocation Fields", "Data Fields"})
        if (const H5Object *g = target->child(sub))
          for (const auto &k : g->kids) if (!k.group) { Value v = datasetValue(r, k, "", err); if (!err.empty()) return ctx.fail(err); f[k.name] = v; }
      data = Value(f);
    } else if (!treeValue(r, *target, data, err)) return ctx.fail(err);
  } else {
    data = datasetValue(r, *target, slice, err);
    if (!err.empty()) return ctx.fail(err);
  }
  out.push_back(data);
  if (nout > 1) {
    Fields info;
    info["path"] = Value(target->path);
    info["kind"] = Value(target->group ? "group" : "dataset");
    if (!target->group) {
      std::vector<double> shape;
      for (auto d : target->dims) shape.push_back(static_cast<double>(d));
      info["shape"] = numberList(shape);
      info["dtype"] = Value(target->type.name());
      info["compression"] = Value(compressionOf(*target));
    }
    if (optBool(a[3], true)) {
      info["attrs"] = h5AttrsDict(*target, &r);
      Fields every;
      allAttrs(r, r.root, every);
      info["all_attrs"] = Value(every);
    }
    info["boxes"] = optBool(a[5], true) ? textList(boxesOf(r, err)) : textList({});
    std::vector<const H5Object *> all;
    r.walk(r.root, all);
    std::vector<std::string> ds;
    for (const auto *o : all) if (!o->group) ds.push_back(o->path);
    info["datasets"] = textList(ds);
    out.push_back(makeObject("NcReadInfo", info));
  }
  ev.ok = true;
}

const std::vector<std::string> &reservedGroup() {
  static const std::vector<std::string> r = {"name", "path", "attrs", "groups", "datasets", "file", "boxes", "format", "swaths", "grids", "superblock"};
  return r;
}

const size_t LAZY_LIMIT = 1000000; // elements read eagerly by load_*; larger -> .read()

Value datasetObject(const H5Reader &r, const H5Object &o, const std::string &file, std::string &err) {
  Fields f;
  f["name"] = Value(o.name);
  f["path"] = Value(o.path);
  std::vector<double> shape, chunks;
  for (auto d : o.dims) shape.push_back(static_cast<double>(d));
  for (auto c : o.chunk) chunks.push_back(static_cast<double>(c));
  f["shape"] = numberList(shape);
  f["dtype"] = Value(o.type.name());
  f["chunks"] = numberList(chunks);
  f["compression"] = Value(compressionOf(o));
  f["attrs"] = h5AttrsDict(o, &r);
  f["size"] = Value(static_cast<double>(elementCount(o)));
  f["file"] = Value(file);
  bool small = elementCount(o) <= LAZY_LIMIT;
  f["loaded"] = Value::boolean(small);
  if (small) {
    Value v = datasetValue(r, o, "", err);
    if (!err.empty()) { f["data"] = Value("(not readable: " + err + ")"); err.clear(); }
    else f["data"] = v;
  }
  return makeObject("NcH5Dataset", f);
}

Value groupObject(const H5Reader &r, const H5Object &g, const std::string &file, std::string &err) {
  Fields f;
  f["name"] = Value(g.name);
  f["path"] = Value(g.path);
  f["attrs"] = h5AttrsDict(g, &r);
  f["file"] = Value(file);
  std::vector<std::string> groups, datasets;
  for (const auto &k : g.kids) {
    if (!k.softTarget.empty()) continue;
    (k.group ? groups : datasets).push_back(k.name);
    std::string fname = fieldName(k.name);
    if (fname.empty() || std::find(reservedGroup().begin(), reservedGroup().end(), fname) != reservedGroup().end() || f.count(fname)) continue;
    f[fname] = k.group ? groupObject(r, k, file, err) : datasetObject(r, k, file, err);
  }
  f["groups"] = textList(groups);
  f["datasets"] = textList(datasets);
  return makeObject("NcH5Group", f);
}

Value loadH5(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev(fn, file);
  H5Reader r;
  if (!openH5(file, bytes, r, err)) { ctx.fail(err); return Value(0.0); }
  Value g = groupObject(r, r.root, file, err);
  Fields f;
  for (const auto &kv : g.dict()) f[kv.first] = kv.second;
  std::vector<const H5Object *> all;
  r.walk(r.root, all);
  std::vector<std::string> groups, datasets;
  for (const auto *o : all) (o->group ? groups : datasets).push_back(o->path);
  f["groups"] = textList(groups);
  f["datasets"] = textList(datasets);
  f["boxes"] = textList(boxesOf(r, err));
  f["format"] = Value(std::string("HDF5 (superblock v") + std::to_string(r.superVersion) + ")");
  f["superblock"] = Value(static_cast<double>(r.superVersion));
  Fields swaths, grids;
  if (const H5Object *s = r.find("/HDFEOS/SWATHS")) for (const auto &k : s->kids) swaths[k.name] = groupObject(r, k, file, err);
  if (const H5Object *s = r.find("/HDFEOS/GRIDS")) for (const auto &k : s->kids) grids[k.name] = groupObject(r, k, file, err);
  f["swaths"] = Value(swaths);
  f["grids"] = Value(grids);
  ev.ok = true;
  return makeObject("NcH5File", f);
}

// D.read(path, slice) / D.sim.velocity.read(slice)
Value readMethod(const std::vector<Value> &a, CallContext &ctx, bool dataset) {
  const Value *file = field(a[0], "file");
  const Value *base = field(a[0], "path");
  if (!file || !base) { ctx.fail("this object has no file to read from"); return Value(0.0); }
  std::string path = base->text(), slice;
  if (dataset) slice = optText(a[1]);
  else {
    std::string p = optText(a[1]);
    path = p.empty() ? path : (p[0] == '/' ? p : (path == "/" ? "" : path) + "/" + p);
    slice = optText(a[2]);
  }
  std::string bytes, err;
  H5Reader r;
  if (!openH5(file->text(), bytes, r, err)) { ctx.fail(err); return Value(0.0); }
  const H5Object *o = r.find(path);
  if (!o) { ctx.fail("no dataset '" + path + "' in " + file->text()); return Value(0.0); }
  if (o->group) { Value t; if (!treeValue(r, *o, t, err)) { ctx.fail(err); return Value(0.0); } return t; }
  Value v = datasetValue(r, *o, slice, err);
  if (!err.empty()) { ctx.fail(err); return Value(0.0); }
  return v;
}

// ---- save -------------------------------------------------------------------------------------

struct SaveOpts {
  std::vector<uint64_t> chunks; // empty + autoChunk
  bool autoChunk = true, contiguous = false;
  std::string compress = "gzip";
  int level = 4;
  bool shuffle = true;
};

void applyOpts(H5WNode &n, const SaveOpts &o) {
  if (n.group) { for (auto &k : n.kids) applyOpts(k, o); return; }
  if (n.data.scalar || o.contiguous || n.data.type.cls == H5Type::VarLen || !n.data.refs.empty()) return;
  if (n.data.count() == 0) return;
  n.chunk = o.autoChunk ? h5AutoChunk(n.data.dims, n.data.type.size) : o.chunks;
  if (!o.autoChunk && n.chunk.size() != n.data.dims.size()) n.chunk = h5AutoChunk(n.data.dims, n.data.type.size);
  n.compress = o.compress;
  n.level = o.level;
  n.shuffle = o.shuffle;
}

// creates groups along `path` and returns the parent + leaf name
H5WNode *ensureGroup(H5WNode &root, const std::string &path, std::string &leaf, std::string &err) {
  std::vector<std::string> parts;
  size_t s = 0;
  while (s <= path.size()) {
    size_t e = path.find('/', s);
    if (e == std::string::npos) e = path.size();
    std::string p = path.substr(s, e - s);
    if (!p.empty()) parts.push_back(p);
    s = e + 1;
  }
  if (parts.empty()) { err = "path \"" + path + "\" names no dataset"; return nullptr; }
  leaf = parts.back();
  H5WNode *g = &root;
  for (size_t i = 0; i + 1 < parts.size(); i++) {
    H5WNode *k = g->find(parts[i]);
    if (!k) { H5WNode n; n.name = parts[i]; g->kids.push_back(n); k = &g->kids.back(); }
    if (!k->group) { err = "'" + parts[i] + "' is a dataset, so it cannot hold '" + leaf + "'"; return nullptr; }
    g = k;
  }
  return g;
}

bool valueToNode(const std::string &name, const Value &v, H5WNode &n, std::string &err) {
  n = H5WNode();
  n.name = name;
  if (v.isDict) {
    n.group = true;
    std::vector<std::string> keys;
    for (const auto &kv : v.dict()) keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      H5WNode c;
      if (!valueToNode(k, v.dict().at(k), c, err)) return false;
      n.kids.push_back(std::move(c));
    }
    return true;
  }
  if (v.isObject) {
    const Value *d = field(v, "data");
    if (d) return valueToNode(name, *d, n, err);
    err = "'" + name + "': a " + v.className() + " object cannot be saved - give its data";
    return false;
  }
  n.group = false;
  if (!valueToH5(v, n.data, err)) { err = "'" + name + "': " + err; return false; }
  return true;
}

void addAttrDict(std::vector<H5WAttr> &attrs, const Value &d, std::string &err) {
  if (!given(d)) return;
  if (!d.isDict) { err = "attrs must be a dict, e.g. attrs={\"units\": \"m/s\"}"; return; }
  std::vector<std::string> keys;
  for (const auto &kv : d.dict()) keys.push_back(kv.first);
  std::sort(keys.begin(), keys.end());
  for (const auto &k : keys) {
    H5WAttr at;
    at.name = k;
    if (!valueToH5(d.dict().at(k), at.data, err)) { err = "attribute '" + k + "': " + err; return; }
    attrs.erase(std::remove_if(attrs.begin(), attrs.end(), [&](const H5WAttr &x) { return x.name == k; }), attrs.end());
    attrs.push_back(std::move(at));
  }
}

// existing file -> writer tree (mode="a"); returns the paths that could not be carried over
bool copyTree(const H5Reader &r, const H5Object &o, H5WNode &n, std::vector<std::string> &dropped, std::string &err) {
  n.name = o.name;
  n.group = o.group;
  for (const auto &a : o.attrs) {
    H5WAttr at;
    at.name = a.name;
    if (a.value.isRef || a.value.isVlen || a.value.isCompound) { dropped.push_back(o.path + "@" + a.name); continue; }
    if (a.value.isText) at.data = a.value.shape.empty() && a.value.strs.size() == 1 ? h5ScalarText(a.value.strs[0]) : h5Texts(a.value.shape, a.value.strs);
    else {
      H5Type t = a.type.cls == H5Type::Float ? h5Float(a.type.size) : a.type.cls == H5Type::Enum ? h5Int(a.type.members.empty() ? 1 : a.type.members[0].size, a.type.members.empty() ? false : a.type.members[0].sign) : h5Int(a.type.size, a.type.sign);
      at.data = h5Numbers(a.value.shape, a.value.nums, t);
      if (a.value.shape.empty()) at.data.scalar = true;
    }
    n.attrs.push_back(std::move(at));
  }
  if (o.group) {
    for (const auto &k : o.kids) {
      if (!k.softTarget.empty()) { dropped.push_back(k.path); continue; }
      H5WNode c;
      if (!copyTree(r, k, c, dropped, err)) return false;
      if (!c.name.empty()) n.kids.push_back(std::move(c));
    }
    return true;
  }
  H5Value v;
  if (!r.readData(o, {}, v, err)) return false;
  if (v.isRef || v.isVlen || v.isCompound || o.type.cls == H5Type::Opaque || o.type.cls == H5Type::Array) { dropped.push_back(o.path + " (" + o.type.name() + ")"); n.name.clear(); return true; }
  std::vector<size_t> shape;
  for (auto d : o.dims) shape.push_back(static_cast<size_t>(d));
  if (v.isText) n.data = h5Texts(shape, v.strs);
  else {
    H5Type t = o.type.cls == H5Type::Float ? h5Float(o.type.size) : o.type.cls == H5Type::Enum ? h5Int(o.type.members[0].size, o.type.members[0].sign) : h5Int(o.type.size, o.type.sign);
    n.data = h5Numbers(shape, v.nums, t);
  }
  n.data.scalar = o.scalar;
  n.chunk = o.chunk;
  for (const auto &f : o.filters) {
    if (f.id == 1) { n.compress = "gzip"; n.level = f.values.empty() ? 4 : static_cast<int>(f.values[0]); }
    if (f.id == 32000) n.compress = "lzf";
    if (f.id == 2) n.shuffle = true;
  }
  if (n.compress == "none" && !o.filters.empty()) n.compress = "gzip";
  return true;
}

Value saveH5(const std::string &fn, const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev(fn, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  SaveOpts o;
  const Value &ch = a[3];
  if (ch.isText) {
    std::string c = lower(optText(ch, "auto"));
    if (c == "none" || c == "contiguous" || c == "false") { o.contiguous = true; o.autoChunk = false; }
    else if (c != "auto" && c != "true") return fail("chunks must be \"auto\", \"none\" or a list of sizes like [64, 64]");
  } else if (ch.isBool() && !ch.number) { o.contiguous = true; o.autoChunk = false; }
  else if (ch.isArray || ch.isMatrix) {
    o.autoChunk = false;
    for (double d : optNumbers(ch)) { if (d < 1) return fail("chunk sizes must be 1 or more"); o.chunks.push_back(static_cast<uint64_t>(d)); }
  }
  o.compress = lower(optText(a[4], "gzip"));
  if (o.compress == "zlib" || o.compress == "deflate" || o.compress == "yes") o.compress = "gzip";
  if (o.compress == "no" || o.compress == "") o.compress = "none";
  if (o.compress == "zstd") return fail("compress=\"zstd\" is not built in - use \"gzip\" or \"lzf\"");
  if (o.compress != "gzip" && o.compress != "lzf" && o.compress != "none") return fail("compress must be \"gzip\", \"lzf\", \"zstd\" or \"none\"");
  o.level = static_cast<int>(optInt(a[5], 4));
  if (o.level < 0 || o.level > 9) return fail("level must be 0..9");
  o.shuffle = optBool(a[6], true);
  std::string mode = lower(optText(a[9], "w"));
  if (mode != "w" && mode != "a") return fail("mode must be \"w\" or \"a\"");

  H5WNode root;
  root.name = "/";
  std::vector<std::string> dropped;
  if (mode == "a" && fileExists(file)) {
    std::string bytes;
    H5Reader r;
    if (!openH5(file, bytes, r, err)) return fail("mode=\"a\": " + err);
    if (!copyTree(r, r.root, root, dropped, err)) return fail("mode=\"a\": " + err);
    root.name = "/";
  }
  std::string path = optText(a[2]);
  const Value &data = a[1];
  bool eos = fmt == "he5";
  std::string prefix = eos && path.empty() ? "/HDFEOS/SWATHS/Swath1/Data Fields" : "";
  H5WNode *attrTarget = &root;
  if (data.isDict && path.empty()) {
    H5WNode tree;
    if (!valueToNode("/", data, tree, err)) return fail(err);
    H5WNode *parent = &root;
    if (!prefix.empty()) {
      std::string leaf;
      parent = ensureGroup(root, prefix + "/x", leaf, err);
      if (!parent) return fail(err);
    }
    for (auto &k : tree.kids) {
      if (H5WNode *old = parent->find(k.name)) *old = k;
      else parent->kids.push_back(k);
    }
    SaveOpts so = o;
    for (auto &k : parent->kids) applyOpts(k, so);
  } else {
    if (path.empty()) path = prefix.empty() ? "/data" : prefix + "/data";
    std::string leaf;
    H5WNode *parent = ensureGroup(root, path, leaf, err);
    if (!parent) return fail(err);
    H5WNode n;
    if (!valueToNode(leaf, data, n, err)) return fail(err);
    applyOpts(n, o);
    if (H5WNode *old = parent->find(leaf)) *old = n;
    else parent->kids.push_back(n);
    attrTarget = parent->find(leaf);
  }
  addAttrDict(attrTarget->attrs, a[7], err);
  if (!err.empty()) return fail(err);
  if (given(a[8])) {
    std::vector<std::string> boxes = a[8].isDict ? std::vector<std::string>{} : optTextList(a[8]);
    if (a[8].isDict) addAttrDict(root.attrs, a[8], err);
    for (size_t i = 0; i < boxes.size(); i++) {
      H5WAttr at;
      at.name = boxes.size() == 1 ? "comment" : "box_" + std::to_string(i + 1);
      at.data = h5ScalarText(boxes[i]);
      root.attrs.erase(std::remove_if(root.attrs.begin(), root.attrs.end(), [&](const H5WAttr &x) { return x.name == at.name; }), root.attrs.end());
      root.attrs.push_back(at);
    }
  }
  if (eos) { // HDF-EOS5 bookkeeping
    std::string leaf;
    H5WNode *info = ensureGroup(root, "/HDFEOS INFORMATION/StructMetadata.0", leaf, err);
    if (info) {
      std::string odl = "GROUP=SwathStructure\n";
      if (const H5WNode *hd = root.find("HDFEOS"))
        if (const H5WNode *sw = const_cast<H5WNode *>(hd)->find("SWATHS")) {
          int i = 1;
          for (const auto &s : sw->kids) {
            odl += "\tGROUP=SWATH_" + std::to_string(i) + "\n\t\tSwathName=\"" + s.name + "\"\n\t\tGROUP=DataField\n";
            if (const H5WNode *df = const_cast<H5WNode &>(s).find("Data Fields"))
              for (const auto &v : df->kids) odl += "\t\t\tOBJECT=DataField\n\t\t\t\tDataFieldName=\"" + v.name + "\"\n\t\t\tEND_OBJECT=DataField\n";
            odl += "\t\tEND_GROUP=DataField\n\tEND_GROUP=SWATH_" + std::to_string(i++) + "\n";
          }
        }
      odl += "END_GROUP=SwathStructure\nEND\n";
      H5WNode sm;
      sm.name = leaf;
      sm.group = false;
      sm.data = h5ScalarText(odl);
      if (H5WNode *old = info->find(leaf)) *old = sm; else info->kids.push_back(sm);
      info->attrs.erase(std::remove_if(info->attrs.begin(), info->attrs.end(), [](const H5WAttr &x) { return x.name == "HDFEOSVersion"; }), info->attrs.end());
      info->attrs.push_back({"HDFEOSVersion", h5ScalarText("HDFEOS_5.1.15")});
    }
  }
  std::string bytes = writeH5(root, 0, err);
  if (!err.empty()) return fail(err);
  if (!writeFile(file, bytes, false, err)) return fail(err);
  if (!dropped.empty()) {
    std::string j;
    for (const auto &d : dropped) j += (j.empty() ? "" : ", ") + d;
    std::cerr << "Warning: " << fn << " mode=\"a\": not carried over (type not built in for rewriting): " << j << "\n";
  }
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

// ---- MAT-file v7.3 --------------------------------------------------------------------------

std::string utf16ToUtf8(const std::vector<double> &codes) {
  std::string out;
  for (size_t i = 0; i < codes.size(); i++) {
    uint32_t c = static_cast<uint32_t>(codes[i]);
    if (c >= 0xD800 && c < 0xDC00 && i + 1 < codes.size()) { c = 0x10000 + ((c - 0xD800) << 10) + (static_cast<uint32_t>(codes[++i]) - 0xDC00); }
    if (c < 0x80) out.push_back(static_cast<char>(c));
    else if (c < 0x800) { out.push_back(static_cast<char>(0xC0 | (c >> 6))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    else if (c < 0x10000) { out.push_back(static_cast<char>(0xE0 | (c >> 12))); out.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    else { out.push_back(static_cast<char>(0xF0 | (c >> 18))); out.push_back(static_cast<char>(0x80 | ((c >> 12) & 0x3F))); out.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
  }
  return out;
}

std::vector<uint16_t> utf8ToUtf16(const std::string &s) {
  std::vector<uint16_t> w;
  for (size_t i = 0; i < s.size();) {
    unsigned char c = static_cast<unsigned char>(s[i]);
    uint32_t cp;
    if (c < 0x80) { cp = c; i++; }
    else if (c < 0xE0 && i + 1 < s.size()) { cp = ((c & 0x1F) << 6) | (s[i + 1] & 0x3F); i += 2; }
    else if (c < 0xF0 && i + 2 < s.size()) { cp = ((c & 0x0F) << 12) | ((s[i + 1] & 0x3F) << 6) | (s[i + 2] & 0x3F); i += 3; }
    else if (i + 3 < s.size()) { cp = ((c & 0x07) << 18) | ((s[i + 1] & 0x3F) << 12) | ((s[i + 2] & 0x3F) << 6) | (s[i + 3] & 0x3F); i += 4; }
    else { cp = '?'; i++; }
    if (cp >= 0x10000) { cp -= 0x10000; w.push_back(static_cast<uint16_t>(0xD800 + (cp >> 10))); w.push_back(static_cast<uint16_t>(0xDC00 + (cp & 0x3FF))); }
    else w.push_back(static_cast<uint16_t>(cp));
  }
  return w;
}

std::string attrText(const H5Object &o, const std::string &n) {
  const H5Attr *a = o.attr(n);
  return a && a->value.isText && !a->value.strs.empty() ? a->value.strs[0] : "";
}

int matClassOf(const std::string &c) {
  static const std::map<std::string, int> m = {{"double", MatNode::Double}, {"single", MatNode::Single}, {"int8", MatNode::Int8},
                                               {"uint8", MatNode::UInt8}, {"int16", MatNode::Int16}, {"uint16", MatNode::UInt16},
                                               {"int32", MatNode::Int32}, {"uint32", MatNode::UInt32}, {"int64", MatNode::Int64},
                                               {"uint64", MatNode::UInt64}, {"char", MatNode::Char}, {"cell", MatNode::Cell},
                                               {"struct", MatNode::Struct}, {"logical", MatNode::UInt8}};
  auto it = m.find(c);
  return it == m.end() ? -1 : it->second;
}

bool matFromH5(const H5Reader &r, const H5Object &o, MatNode &n, std::string &err, int depth = 0) {
  if (depth > 32) { err = "MAT v7.3: nesting too deep"; return false; }
  std::string cls = attrText(o, "MATLAB_class");
  if (o.group) {
    if (o.attr("MATLAB_sparse")) {
      const H5Attr *nr = o.attr("MATLAB_sparse");
      size_t rows = nr->value.nums.empty() ? 0 : static_cast<size_t>(nr->value.nums[0]);
      H5Value jc, ir, data;
      const H5Object *jo = o.child("jc"), *io = o.child("ir"), *dO = o.child("data");
      if (!jo || !r.readData(*jo, {}, jc, err)) return false;
      if (io) r.readData(*io, {}, ir, err);
      if (dO) r.readData(*dO, {}, data, err);
      size_t cols = jc.nums.empty() ? 0 : jc.nums.size() - 1;
      n.cls = MatNode::Double;
      n.className = "sparse";
      n.logical = cls == "logical";
      n.dims = {rows, cols};
      n.re.assign(rows * cols, 0);
      for (size_t c = 0; c < cols; c++)
        for (size_t k = static_cast<size_t>(jc.nums[c]); k < static_cast<size_t>(jc.nums[c + 1]) && k < ir.nums.size(); k++)
          n.re[c * rows + static_cast<size_t>(ir.nums[k])] = k < data.nums.size() ? data.nums[k] : (data.fields.empty() ? 1 : data.fields[0].nums[k]);
      return true;
    }
    if (!cls.empty() && cls != "struct") { // objects, function handles: not built in
      n.cls = MatNode::Char;
      n.text = "<" + cls + " object (not readable)>";
      n.dims = {1, n.text.size()};
      return true;
    }
    n.cls = MatNode::Struct;
    std::vector<std::string> order;
    if (const H5Attr *fa = o.attr("MATLAB_fields")) {
      for (const auto &it : fa->value.items) order.push_back(it.isText ? [&] { std::string s; for (const auto &c : it.strs) s += c; return s; }() : [&] { std::string s; for (double c : it.nums) s.push_back(static_cast<char>(c)); return s; }());
      for (const auto &s : fa->value.strs) order.push_back(s);
    }
    for (const auto &k : o.kids) if (std::find(order.begin(), order.end(), k.name) == order.end()) order.push_back(k.name);
    // struct array: fields are reference datasets that are not cells
    bool arr = false;
    for (const auto &k : o.kids) if (!k.group && k.type.cls == H5Type::Reference && attrText(k, "MATLAB_class") != "cell") arr = true;
    n.fieldNames = order;
    if (!arr) {
      n.dims = {1, 1};
      std::vector<MatNode> fields;
      for (const auto &name : order) {
        MatNode f;
        if (const H5Object *k = o.child(name)) { if (!matFromH5(r, *k, f, err, depth + 1)) return false; }
        else { f.dims = {0, 0}; }
        f.name.clear();
        fields.push_back(std::move(f));
      }
      n.elems.push_back(std::move(fields));
      return true;
    }
    size_t count = 0;
    std::vector<H5Value> refs(order.size());
    for (size_t i = 0; i < order.size(); i++) {
      const H5Object *k = o.child(order[i]);
      if (!k || !r.readData(*k, {}, refs[i], err)) return false;
      if (i == 0) { count = refs[i].nums.size(); n.dims.assign(k->dims.rbegin(), k->dims.rend()); }
    }
    for (size_t e = 0; e < count; e++) {
      std::vector<MatNode> fields;
      for (size_t i = 0; i < order.size(); i++) {
        MatNode f;
        const H5Object *t = e < refs[i].nums.size() ? r.byAddr(static_cast<uint64_t>(refs[i].nums[e])) : nullptr;
        if (t && !matFromH5(r, *t, f, err, depth + 1)) return false;
        fields.push_back(std::move(f));
      }
      n.elems.push_back(std::move(fields));
    }
    return true;
  }
  H5Value v;
  if (!r.readData(o, {}, v, err)) return false;
  n.dims.assign(o.dims.rbegin(), o.dims.rend());
  if (n.dims.empty()) n.dims = {1, 1};
  if (n.dims.size() == 1) n.dims.push_back(1);
  if (const H5Attr *em = o.attr("MATLAB_empty"); em && !em->value.nums.empty() && em->value.nums[0] != 0) {
    n.dims.clear();
    for (double d : v.nums) n.dims.push_back(static_cast<size_t>(d));
    if (n.dims.size() < 2) n.dims = {0, 0};
    int c = matClassOf(cls);
    n.cls = c < 0 ? MatNode::Double : c;
    return true;
  }
  int c = matClassOf(cls.empty() ? (v.isText ? "char" : "double") : cls);
  if (c < 0) { n.cls = MatNode::Char; n.text = "<" + cls + " (not readable)>"; n.dims = {1, n.text.size()}; return true; }
  n.cls = c;
  n.logical = cls == "logical";
  if (c == MatNode::Cell) {
    for (double ad : v.nums) {
      MatNode cell;
      const H5Object *t = r.byAddr(static_cast<uint64_t>(ad));
      if (t && !matFromH5(r, *t, cell, err, depth + 1)) return false;
      n.cells.push_back(std::move(cell));
    }
    return true;
  }
  if (c == MatNode::Char) {
    if (v.isText) { n.text = v.strs.empty() ? "" : v.strs[0]; return true; }
    size_t rows = n.dims[0], cols = n.dims.size() > 1 ? n.dims[1] : 1;
    for (size_t rr = 0; rr < rows; rr++) {
      std::vector<double> row;
      for (size_t cc = 0; cc < cols; cc++) if (cc * rows + rr < v.nums.size()) row.push_back(v.nums[cc * rows + rr]);
      n.text += (rr ? "\n" : "") + utf16ToUtf8(row);
    }
    return true;
  }
  if (v.isCompound && v.fields.size() >= 2) { n.complex = true; n.re = v.fields[0].nums; n.im = v.fields[1].nums; return true; }
  n.re = v.nums;
  return true;
}

struct Mat73Writer {
  H5WNode refs;
  int next = 0;
  std::string err;
  Mat73Writer() { refs.name = "#refs#"; }

  std::string refName() { // b, c, ..., z, ba, bb, ...
    int k = ++next;
    std::string s;
    do { s.insert(s.begin(), static_cast<char>('a' + k % 26)); k /= 26; } while (k);
    return s;
  }
  static H5WAttr text(const std::string &n, const std::string &v) {
    H5WAttr a;
    a.name = n;
    a.data = h5ScalarText(v);
    return a;
  }
  static H5WAttr num(const std::string &n, double v, const H5Type &t) {
    H5WAttr a;
    a.name = n;
    a.data = h5ScalarNumber(v, t);
    return a;
  }
  H5Type numType(const MatNode &n) {
    if (n.logical) return h5Int(1, false);
    switch (n.cls) {
    case MatNode::Single: return h5Float(4);
    case MatNode::Int8: return h5Int(1, true);
    case MatNode::UInt8: return h5Int(1, false);
    case MatNode::Int16: return h5Int(2, true);
    case MatNode::UInt16: return h5Int(2, false);
    case MatNode::Int32: return h5Int(4, true);
    case MatNode::UInt32: return h5Int(4, false);
    case MatNode::Int64: return h5Int(8, true);
    case MatNode::UInt64: return h5Int(8, false);
    default: return h5Float(8);
    }
  }
  std::vector<size_t> h5dims(const std::vector<size_t> &d) { return std::vector<size_t>(d.rbegin(), d.rend()); }

  // a reference to a new node in #refs#
  std::string stash(const MatNode &n) {
    H5WNode k;
    std::string name = refName();
    if (!node(name, n, k)) return "";
    refs.kids.push_back(std::move(k));
    return "/#refs#/" + name;
  }

  bool node(const std::string &name, const MatNode &n, H5WNode &out) {
    out = H5WNode();
    out.name = name;
    std::string cls = n.logical ? "logical" : matClassName(n);
    if (n.className == "sparse") cls = n.logical ? "logical" : "double";
    if (n.cls == MatNode::Struct || n.cls == MatNode::Object) {
      out.group = true;
      size_t count = n.elems.size();
      out.attrs.push_back(text("MATLAB_class", "struct"));
      H5WAttr fa;
      fa.name = "MATLAB_fields";
      fa.data.type = h5VarLen(h5String(1));
      fa.data.dims = {n.fieldNames.size()};
      for (const auto &f : n.fieldNames) { H5WData::Item it; it.raw = f; it.count = f.size(); fa.data.items.push_back(it); }
      out.attrs.push_back(fa);
      if (count == 1 && n.count() == 1) {
        for (size_t i = 0; i < n.fieldNames.size(); i++) {
          H5WNode f;
          if (!node(n.fieldNames[i], n.elems[0][i], f)) return false;
          out.kids.push_back(std::move(f));
        }
        return true;
      }
      for (size_t i = 0; i < n.fieldNames.size(); i++) {
        H5WNode f;
        f.name = n.fieldNames[i];
        f.group = false;
        f.data.type = h5Ref();
        for (auto d : h5dims(n.dims)) f.data.dims.push_back(d);
        for (size_t e = 0; e < count; e++) {
          std::string p = stash(n.elems[e][i]);
          if (p.empty()) return false;
          f.data.refs.push_back({f.data.raw.size(), p});
          f.data.raw.append(8, '\0');
        }
        out.kids.push_back(std::move(f));
      }
      return true;
    }
    out.group = false;
    if (n.cls == MatNode::Cell) {
      out.data.type = h5Ref();
      for (auto d : h5dims(n.dims)) out.data.dims.push_back(d);
      for (const auto &c : n.cells) {
        std::string p = stash(c);
        if (p.empty()) return false;
        out.data.refs.push_back({out.data.raw.size(), p});
        out.data.raw.append(8, '\0');
      }
      out.attrs.push_back(text("MATLAB_class", "cell"));
      if (n.cells.empty()) return empty(n, "cell", out);
      return true;
    }
    if (n.count() == 0 || (n.cls == MatNode::Char && n.text.empty())) return empty(n, cls, out);
    if (n.cls == MatNode::Char) {
      std::vector<std::vector<uint16_t>> rows;
      size_t s = 0, w = 0;
      while (s <= n.text.size()) {
        size_t e = n.text.find('\n', s);
        if (e == std::string::npos) e = n.text.size();
        rows.push_back(utf8ToUtf16(n.text.substr(s, e - s)));
        w = std::max(w, rows.back().size());
        s = e + 1;
      }
      std::vector<double> cm; // column-major
      for (size_t c = 0; c < w; c++) for (const auto &r : rows) cm.push_back(c < r.size() ? r[c] : ' ');
      out.data = h5Numbers({w, rows.size()}, cm, h5Int(2, false));
      out.attrs.push_back(text("MATLAB_class", "char"));
      out.attrs.push_back(num("MATLAB_int_decode", 2, h5Int(4, true)));
      return true;
    }
    H5Type t = numType(n);
    std::vector<size_t> dims = h5dims(n.dims);
    if (n.complex) {
      out.data.type = h5Compound({"real", "imag"}, {t, t});
      for (auto d : dims) out.data.dims.push_back(d);
      H5WData re = h5Numbers(dims, n.re, t), im = h5Numbers(dims, n.im, t);
      for (size_t i = 0; i < n.re.size(); i++) { out.data.raw.append(re.raw, i * t.size, t.size); out.data.raw.append(im.raw, i * t.size, t.size); }
    } else out.data = h5Numbers(dims, n.re, t);
    out.attrs.push_back(text("MATLAB_class", cls));
    if (n.logical) out.attrs.push_back(num("MATLAB_int_decode", 1, h5Int(4, true)));
    return true;
  }

  bool empty(const MatNode &n, const std::string &cls, H5WNode &out) {
    std::vector<double> d(n.dims.begin(), n.dims.end());
    if (n.cls == MatNode::Char && n.text.empty() && d.size() >= 2) d = {0, 0};
    out.group = false;
    out.data = h5Numbers({d.size()}, d, h5Int(8, false));
    out.attrs.clear();
    out.attrs.push_back(text("MATLAB_class", cls));
    out.attrs.push_back(num("MATLAB_empty", 1, h5Int(1, false)));
    return true;
  }
};

} // namespace

bool readMat73(const std::string &bytes, MatFile &mf, std::string &err) {
  H5Reader r;
  if (!r.open(bytes, err)) { err = "MAT-file v7.3: " + err; return false; }
  mf.version = "v7.3";
  mf.header = bytes.substr(0, std::min<size_t>(116, bytes.size()));
  while (!mf.header.empty() && (mf.header.back() == ' ' || mf.header.back() == '\0')) mf.header.pop_back();
  for (const auto &k : r.root.kids) {
    if (k.name.empty() || k.name[0] == '#') continue;
    MatNode n;
    if (!matFromH5(r, k, n, err)) { err = "MAT-file v7.3, variable '" + k.name + "': " + err; return false; }
    n.name = k.name;
    mf.vars.push_back(std::move(n));
  }
  return true;
}

std::string writeMat73(const MatFile &mf, std::string &err) {
  Mat73Writer w;
  H5WNode root;
  root.name = "/";
  for (const auto &v : mf.vars) {
    H5WNode n;
    if (!w.node(v.name, v, n)) { err = w.err.empty() ? "cannot write '" + v.name + "'" : w.err; return ""; }
    root.kids.push_back(std::move(n));
  }
  if (!w.refs.kids.empty()) {
    H5WNode a; // MATLAB's canonical empty in #refs#/a
    w.empty(MatNode(), "double", a);
    a.name = "a";
    a.data = h5Numbers({2}, {0, 0}, h5Int(8, false));
    w.refs.kids.push_back(a);
    root.kids.push_back(w.refs);
  }
  // compress the larger numeric datasets like MATLAB does
  std::function<void(H5WNode &)> chunkAll = [&](H5WNode &n) {
    if (n.group) { for (auto &k : n.kids) chunkAll(k); return; }
    if (n.data.refs.empty() && n.data.type.cls != H5Type::VarLen && !n.data.scalar && n.data.count() * n.data.type.size >= 4096) {
      n.chunk = h5AutoChunk(n.data.dims, n.data.type.size);
      n.compress = "gzip";
      n.level = 3;
    }
  };
  chunkAll(root);
  std::string bytes = writeH5(root, 512, err);
  if (bytes.empty()) return "";
  std::time_t t = std::time(nullptr);
  char when[64];
  std::tm tmv{};
  localtime_s(&tmv, &t);
  std::strftime(when, sizeof when, "%a %b %d %H:%M:%S %Y", &tmv);
  std::string head = std::string("MATLAB 7.3 MAT-file, Platform: PCWIN64, Created on: ") + when + " HDF5 schema 1.00 .";
  head.resize(116, ' ');
  head.append(8, ' ');               // subsystem data offset
  head += std::string("\x00\x02", 2); // version 0x0200
  head += "IM";
  std::copy(head.begin(), head.end(), bytes.begin());
  return bytes;
}

void registerHdf5(Registry &reg) {
  for (const char *ext : {"h5", "hdf", "he5"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, path=\"\", slice=\"\", attr=true, swath=\"\", box=true",
             "read a dataset (or the whole group tree) of a ." + e + " file; slice= reads only that part", "h5py.File[path][slice]", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readH5("read_" + e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file",
          "open a ." + e + " file as a group/dataset tree (D.groups, D.datasets, D.sim.velocity.shape, D.attrs" + (e == "he5" ? ", D.swaths" : "") + ")",
          "h5py.File", [e](const std::vector<Value> &a, CallContext &ctx) { return loadH5("load_" + e, a, ctx); });
    addFn(reg, "save_" + e,
          "file, data, path=\"\", chunks=\"auto\", compress=\"gzip\", level=4, shuffle=true, attrs=\"\", boxes=\"\", mode=\"w\"",
          "write a tensor (to /data or path=) or a dict of tensors (one dataset per key) as ." + e + " (mode=\"a\" adds to a file)",
          "h5py.File.create_dataset", [e](const std::vector<Value> &a, CallContext &ctx) { return saveH5("save_" + e, e, a, ctx); });
  }
  addFn(reg, "NcH5Dataset.read", "D, slice=\"\"", "read (part of) an HDF5 dataset from its file - for datasets too large to load", "h5py.Dataset.__getitem__",
        [](const std::vector<Value> &a, CallContext &ctx) { return readMethod(a, ctx, true); });
  addFn(reg, "NcH5Group.read", "G, path=\"\", slice=\"\"", "read a dataset below this HDF5 group", "h5py.Group.__getitem__",
        [](const std::vector<Value> &a, CallContext &ctx) { return readMethod(a, ctx, false); });
  addFn(reg, "NcH5File.read", "D, path=\"\", slice=\"\"", "read a dataset of the HDF5 file by path", "h5py.File.__getitem__",
        [](const std::vector<Value> &a, CallContext &ctx) { return readMethod(a, ctx, false); });
}

} // namespace io
} // namespace nc
