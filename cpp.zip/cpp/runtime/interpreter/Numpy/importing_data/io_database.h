// Database backends behind read_/load_/save_ sqlite, postgresql, mysql,
// oracle, sqlserver. SQLite files are handled in-process (io_sqlite);
// PostgreSQL and MySQL speak their wire protocols over TCP (io_dbnet).
#ifndef NC_IO_DATABASE_H
#define NC_IO_DATABASE_H

#include <memory>
#include <string>
#include <vector>

#include "io_common.h"
#include "io_sqlite.h"

namespace nc {
namespace io {

struct WriteRequest {
  std::string table, schema, mode; // mode: append replace upsert fail
  Table data;
  std::vector<std::string> pk, conflict, index;
  Fields dtype;                    // column -> SQL type
  std::string comment;
  size_t batch = 5000;
};

class DbBackend {
public:
  virtual ~DbBackend() = default;
  virtual std::string dialect() const = 0; // sqlite postgresql mysql
  virtual bool tables(const std::string &schema, std::vector<std::string> &tables, std::vector<std::string> &views,
                      std::string &err) = 0;
  virtual bool describe(const std::string &schema, const std::string &table, DbTable &out, std::string &err) = 0;
  virtual bool query(const std::string &sql, const std::vector<Value> &params, Table &out, std::string &err) = 0;
  virtual bool write(const WriteRequest &req, std::string &err) = 0;
  virtual double count(const std::string &schema, const std::string &table, std::string &err);
};

std::unique_ptr<DbBackend> openBackend(const std::string &format, const std::string &uri, std::string &err);
// network backends (io_dbnet.cpp)
std::unique_ptr<DbBackend> openPostgres(const std::string &uri, std::string &err);
std::unique_ptr<DbBackend> openMysql(const std::string &uri, std::string &err);
// `?` placeholders -> literals (client-side binding for the text protocols)
bool bindParams(const std::string &sql, const std::vector<Value> &params, std::string &out, std::string &err);
std::string sqlType(const std::string &dialect, const Table &t, size_t col);

} // namespace io
} // namespace nc

#endif // NC_IO_DATABASE_H
