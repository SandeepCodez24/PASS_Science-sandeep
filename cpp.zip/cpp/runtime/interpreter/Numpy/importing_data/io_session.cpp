// ImportSession, format detection, option schemas, previews and code
// generation - see io_session.h.
#include "io_session.h"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <map>
#include <sstream>

#include "../numpy_common.h"
#include "../numpy_main.h"
#include "io_deflate.h"
#include "io_formats.h"

namespace nc {
namespace io {

// ---- catalog ------------------------------------------------------------------

const std::vector<FormatInfo> &formatCatalog() {
  static const std::vector<FormatInfo> cat = {
      {"xlsx", "Spreadsheets", "Excel Open XML Workbook", ".xlsx", 2},
      {"xls", "Spreadsheets", "Legacy Excel 97-2003 Workbook", ".xls", 2},
      {"xlsm", "Spreadsheets", "Excel Macro-Enabled Workbook", ".xlsm", 2},
      {"xlsb", "Spreadsheets", "Excel Binary Workbook", ".xlsb", 2},
      {"csv", "Delimited text", "Comma-Separated Values", ".csv", 1},
      {"txt", "Delimited text", "Plain / Structured Text", ".txt", 1},
      {"dat", "Delimited text", "Generic Scientific/Tabular Data", ".dat", 1},
      {"tsv", "Delimited text", "Tab-Separated Values", ".tsv", 1},
      {"parquet", "Columnar", "Apache Parquet Columnar Storage", ".parquet", 3},
      {"feather", "Columnar", "Apache Arrow IPC / Feather v2", ".feather", 3},
      {"orc", "Columnar", "Apache Optimized Row Columnar", ".orc", 3},
      {"mat", "Scientific", "MATLAB Binary Workspace (v5 / v7 / v7.3)", ".mat", 2},
      {"fig", "Binary & database", "Interactive Graphical Figure & Scene Tree", ".fig", 2},
      {"json", "Structured text", "JavaScript Object Notation", ".json .ndjson .jsonl", 1},
      {"xml", "Structured text", "Extensible Markup Language", ".xml", 1},
      {"html", "Structured text", "HyperText Markup Language Document", ".html", 1},
      {"htm", "Structured text", "HyperText Markup Language File", ".htm", 1},
      {"yaml", "Structured text", "YAML Configuration Format", ".yaml", 1},
      {"yml", "Structured text", "YAML Configuration File", ".yml", 1},
      {"ini", "Structured text", "INI Sectioned Key-Value Config", ".ini .cfg .conf", 1},
      {"h5", "Scientific", "Hierarchical Data Format v5", ".h5 .hdf5", 3},
      {"hdf", "Scientific", "Hierarchical Data Format v4 / v5", ".hdf .h4", 3},
      {"he5", "Scientific", "HDF-EOS5 Earth Observing Swath/Grid", ".he5", 3},
      {"nc", "Scientific", "Network Common Data Form", ".nc", 3},
      {"cdf", "Scientific", "Common Data Format / NetCDF Scientific Array", ".cdf", 3},
      {"fits", "Scientific", "Flexible Image Transport System", ".fits", 2},
      {"fit", "Scientific", "Flexible Image Transport System File", ".fit", 2},
      {"bin", "Binary & database", "Raw Contiguous Binary Stream", ".bin .raw", 1},
      {"custom", "Binary & database", "User-Defined Structured Binary Layout", ".custom", 1},
      {"png", "Images & medical", "Portable Network Graphics", ".png", 2},
      {"jpg", "Images & medical", "JPEG Photographic Image", ".jpg", 2},
      {"jpeg", "Images & medical", "JPEG Compressed Raster Image", ".jpeg", 2},
      {"tiff", "Images & medical", "Tagged Image File Format", ".tiff", 2},
      {"bmp", "Images & medical", "Device-Independent Bitmap", ".bmp", 2},
      {"gif", "Images & medical", "Graphics Interchange Format", ".gif", 2},
      {"dicom", "Images & medical", "DICOM Medical Imaging", ".dicom .dcm", 2},
      {"wav", "Audio & video", "Waveform Audio File Format", ".wav", 2},
      {"flac", "Audio & video", "Free Lossless Audio Codec", ".flac", 2},
      {"ogg", "Audio & video", "Ogg Vorbis / Opus Audio Container", ".ogg", 2},
      {"mp3", "Audio & video", "MPEG-1/2 Audio Layer III", ".mp3", 2},
      {"mp4", "Audio & video", "MPEG-4 Part 14 Multimedia Container", ".mp4", 3},
      {"avi", "Audio & video", "Audio Video Interleave Container", ".avi", 3},
      {"m4v", "Audio & video", "Apple MPEG-4 Video Container", ".m4v", 3},
      {"mov", "Audio & video", "QuickTime Movie Multimedia Container", ".mov", 3},
      {"shp", "Geospatial", "Esri Shapefile Vector Geometry", ".shp", 3},
      {"shx", "Geospatial", "Esri Shapefile Positional Spatial Index", ".shx", 3},
      {"dbf", "Geospatial", "dBASE Feature Attribute Table", ".dbf", 3},
      {"tif", "Geospatial", "Georeferenced Tagged Image File", ".tif", 3},
      {"geotiff", "Geospatial", "GeoTIFF Earth Observation & Elevation Raster", ".tiff", 3},
      {"gpx", "Geospatial", "GPS Exchange Format", ".gpx", 3},
      {"kml", "Geospatial", "Keyhole Markup Language", ".kml .kmz", 3},
      {"postgresql", "Binary & database", "PostgreSQL Relational Database", "postgres://", 3},
      {"mysql", "Binary & database", "MySQL Relational Database Server", "mysql://", 3},
      {"sqlite", "Binary & database", "SQLite Serverless Embedded Database", ".sqlite .db", 2},
      {"oracle", "Binary & database", "Oracle Enterprise Relational Database", "oracle://", 3},
      {"sqlserver", "Binary & database", "Microsoft SQL Server Database", "mssql://", 3},
  };
  return cat;
}

const FormatInfo *findFormat(const std::string &id) {
  for (const auto &f : formatCatalog())
    if (f.id == id)
      return &f;
  return nullptr;
}

bool formatAvailable(const std::string &id) {
  numpy::initialize();
  return numpy::Registry::instance().contains("read_" + id);
}

// ---- detection ------------------------------------------------------------------

namespace {

bool startsWith(const std::string &s, const char *magic, size_t n, size_t at = 0) {
  return s.size() >= at + n && s.compare(at, n, magic, n) == 0;
}

std::string extToFormat(const std::string &ext) {
  static const std::map<std::string, std::string> m = {
      {"ndjson", "json"}, {"jsonl", "json"}, {"cfg", "ini"},   {"conf", "ini"},  {"hdf5", "h5"},
      {"h4", "hdf"},      {"dcm", "dicom"},  {"raw", "bin"},   {"db", "sqlite"}, {"sqlite3", "sqlite"},
      {"kmz", "kml"}};
  auto it = m.find(ext);
  if (it != m.end())
    return it->second;
  return findFormat(ext) ? ext : "";
}

Detection make(const std::string &fmt, double conf, const std::string &why) {
  Detection d;
  d.format = fmt;
  if (const FormatInfo *f = findFormat(fmt))
    d.category = f->category;
  d.confidence = conf;
  d.reason = why;
  return d;
}

Detection sniffText(const std::string &head, const std::string &ext) {
  std::string t;
  std::string err;
  decodeText(head, "utf-8", t, err);
  std::string s = trim(t);
  if (s.empty())
    return make(extToFormat(ext).empty() ? "txt" : extToFormat(ext), 0.3, "empty text");
  std::string l = lower(s.substr(0, 512));
  if (s[0] == '{' || s[0] == '[') {
    if (ext == "ini" && s[0] == '[')
      return make("ini", 0.8, "[section] header");
    // "[Database]" at the start of a line is an INI header, not JSON
    if (s[0] == '[' && s.find(']') != std::string::npos && s.find(']') < 64 &&
        s.find('=') != std::string::npos && s.find('"') == std::string::npos)
      return make("ini", 0.75, "[section] header with key = value lines");
    return make("json", 0.85, "starts with " + std::string(1, s[0]));
  }
  if (s[0] == '<') {
    if (l.find("<html") != std::string::npos || l.find("<!doctype html") != std::string::npos)
      return make(ext == "htm" ? "htm" : "html", 0.9, "<html> document");
    if (l.find("<gpx") != std::string::npos)
      return make("gpx", 0.95, "<gpx> root");
    if (l.find("<kml") != std::string::npos)
      return make("kml", 0.95, "<kml> root");
    return make("xml", 0.85, "markup document");
  }
  if (l.rfind("---", 0) == 0 || l.rfind("%yaml", 0) == 0)
    return make(ext == "yml" ? "yml" : "yaml", 0.85, "YAML document marker");
  // key: value lines -> YAML, key = value under [section] -> INI
  size_t colonLines = 0, eqLines = 0, sections = 0, lines = 0, commas = 0, tabs = 0;
  std::istringstream in(s.substr(0, 4096));
  std::string line;
  while (std::getline(in, line) && lines < 40) {
    std::string x = trim(line);
    if (x.empty() || x[0] == '#' || x[0] == ';')
      continue;
    lines++;
    if (x[0] == '[' && x.back() == ']')
      sections++;
    if (x.find(": ") != std::string::npos || (x.back() == ':' && x.find(',') == std::string::npos))
      colonLines++;
    if (x.find('=') != std::string::npos)
      eqLines++;
    if (x.find(',') != std::string::npos)
      commas++;
    if (x.find('\t') != std::string::npos)
      tabs++;
  }
  if (sections > 0 && eqLines > 0)
    return make("ini", 0.8, "[section] headers with key = value");
  if (colonLines * 2 > lines && commas * 2 < lines)
    return make(ext == "yml" ? "yml" : "yaml", 0.7, "key: value lines");
  if (tabs * 2 > lines)
    return make(ext == "tsv" ? "tsv" : ext == "txt" ? "txt" : "tsv", 0.75, "tab-separated lines");
  if (commas * 2 > lines)
    return make(ext == "txt" || ext == "dat" ? ext : "csv", 0.75, "comma-separated lines");
  std::string f = extToFormat(ext);
  if (f == "dat" || f == "txt")
    return make(f, 0.7, "plain text table");
  return make("txt", 0.6, "plain text");
}

} // namespace

Detection detectFormat(const std::string &path) {
  const std::string ext = extensionOf(path);
  if (isUrl(path)) {
    std::string l = lower(path);
    for (const char *db : {"postgres", "mysql", "oracle", "mssql"})
      if (l.rfind(db, 0) == 0)
        return make(std::string(db) == "postgres" ? "postgresql" : std::string(db) == "mssql" ? "sqlserver" : db,
                    0.95, "database URI");
    std::string f = extToFormat(ext);
    return make(f.empty() ? "html" : f, f.empty() ? 0.5 : 0.7, f.empty() ? "web address" : "extension ." + ext);
  }
  std::string lowerPath = lower(path);
  for (const char *db : {"postgres://", "mysql://", "oracle://", "mssql://"})
    if (lowerPath.rfind(db, 0) == 0) {
      std::string d = db;
      d = d.substr(0, d.size() - 3);
      return make(d == "postgres" ? "postgresql" : d == "mssql" ? "sqlserver" : d, 0.95, "database URI");
    }
  std::string bytes, err;
  if (!readFile(path, bytes, err)) {
    // Not readable (yet): the extension is all there is - code can still be
    // generated for a file that a script will create.
    std::string f = extToFormat(ext);
    return make(f, f.empty() ? 0 : 0.3, f.empty() ? err : "extension ." + ext + " (" + err + ")");
  }
  Detection d;
  bool gz = isGzip(bytes);
  std::string inner = ext;
  if (gz) {
    std::string out;
    if (!gzipDecompress(bytes, out, err))
      return make("", 0, "gzip data is damaged: " + err);
    bytes.swap(out);
    std::string stem = path.substr(0, path.size() - (ext.empty() ? 0 : ext.size() + 1));
    inner = ext == "gz" ? extensionOf(stem) : ext;
  }
  const std::string &b = bytes;
  auto done = [&](Detection x) {
    x.compressed = gz;
    if (gz)
      x.reason += " (gzip)";
    return x;
  };
  if (startsWith(b, "PK\x03\x04", 4)) {
    if (b.find("xl/vbaProject.bin") != std::string::npos) return done(make("xlsm", 0.95, "zip with Excel macros"));
    if (b.find("xl/workbook.bin") != std::string::npos) return done(make("xlsb", 0.95, "zip with binary workbook"));
    if (b.find("xl/") != std::string::npos) return done(make(inner == "xlsm" ? "xlsm" : "xlsx", 0.95, "zip with xl/ workbook"));
    if (b.find("doc.kml") != std::string::npos) return done(make("kml", 0.9, "KMZ archive"));
    return done(make(extToFormat(inner), 0.4, "zip archive"));
  }
  if (startsWith(b, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1", 8)) return done(make("xls", 0.85, "OLE2 compound file"));
  if (startsWith(b, "PAR1", 4)) return done(make("parquet", 0.98, "PAR1 signature"));
  if (startsWith(b, "ARROW1", 6)) return done(make("feather", 0.98, "ARROW1 signature"));
  if (startsWith(b, "ORC", 3)) return done(make("orc", 0.9, "ORC signature"));
  if (startsWith(b, "MATLAB 5.0", 10)) return done(make(inner == "fig" ? "fig" : "mat", 0.98, "MAT-file header"));
  if (startsWith(b, "\x89HDF\r\n\x1a\n", 8)) {
    if (inner == "mat") return done(make("mat", 0.95, "HDF5 MAT-file v7.3"));
    if (inner == "nc" || inner == "cdf") return done(make(inner, 0.95, "NetCDF-4 (HDF5)"));
    if (inner == "he5") return done(make("he5", 0.95, "HDF-EOS5"));
    return done(make(inner == "hdf" ? "hdf" : "h5", 0.95, "HDF5 signature"));
  }
  if (startsWith(b, "\x0e\x03\x13\x01", 4)) return done(make("hdf", 0.95, "HDF4 signature"));
  if (startsWith(b, "CDF\x01", 4) || startsWith(b, "CDF\x02", 4) || startsWith(b, "CDF\x05", 4))
    return done(make(inner == "cdf" ? "cdf" : "nc", 0.98, "classic NetCDF header"));
  if (startsWith(b, "SIMPLE  =", 9)) return done(make(inner == "fit" ? "fit" : "fits", 0.98, "FITS SIMPLE card"));
  if (startsWith(b, "\x89PNG\r\n\x1a\n", 8)) return done(make("png", 0.99, "PNG signature"));
  if (startsWith(b, "\xFF\xD8\xFF", 3)) return done(make(inner == "jpeg" ? "jpeg" : "jpg", 0.99, "JPEG signature"));
  if (startsWith(b, "GIF87a", 6) || startsWith(b, "GIF89a", 6)) return done(make("gif", 0.99, "GIF signature"));
  if (startsWith(b, "BM", 2) && b.size() > 26) return done(make("bmp", 0.8, "BMP signature"));
  if (startsWith(b, "II*\0", 4) || startsWith(b, "MM\0*", 4) || startsWith(b, "II+\0", 4) || startsWith(b, "MM\0+", 4)) {
    bool geo = b.find("\xAF\x87", 0) != std::string::npos || b.find("\x87\xAF", 0) != std::string::npos; // GeoKeyDirectoryTag 34735
    if (geo) return done(make(inner == "tiff" ? "geotiff" : "tif", 0.95, "TIFF with GeoKeys"));
    return done(make("tiff", 0.95, "TIFF signature"));
  }
  if (b.size() > 132 && b.compare(128, 4, "DICM") == 0) return done(make("dicom", 0.99, "DICM marker"));
  if (startsWith(b, "RIFF", 4) && b.size() > 12) {
    if (b.compare(8, 4, "WAVE") == 0) return done(make("wav", 0.99, "RIFF WAVE"));
    if (b.compare(8, 4, "AVI ") == 0) return done(make("avi", 0.99, "RIFF AVI"));
  }
  if (startsWith(b, "fLaC", 4)) return done(make("flac", 0.99, "fLaC signature"));
  if (startsWith(b, "OggS", 4)) return done(make("ogg", 0.99, "OggS signature"));
  if (startsWith(b, "ID3", 3) || (b.size() > 2 && static_cast<unsigned char>(b[0]) == 0xFF &&
                                  (static_cast<unsigned char>(b[1]) & 0xE0) == 0xE0 && inner == "mp3"))
    return done(make("mp3", 0.95, "MPEG audio"));
  if (b.size() > 12 && b.compare(4, 4, "ftyp") == 0) {
    std::string brand = b.substr(8, 4);
    if (brand == "qt  ") return done(make("mov", 0.95, "QuickTime brand"));
    if (brand.rfind("M4V", 0) == 0) return done(make("m4v", 0.95, "M4V brand"));
    return done(make(inner == "m4v" || inner == "mov" ? inner : "mp4", 0.95, "MP4 ftyp box"));
  }
  if (startsWith(b, "\x00\x00\x27\x0A", 4)) return done(make(inner == "shx" ? "shx" : "shp", 0.95, "shapefile code 9994"));
  if (startsWith(b, "SQLite format 3", 15)) return done(make("sqlite", 0.99, "SQLite header"));
  if (startsWith(b, "NCSCHEMA ", 9) || fileExists(path + ".schema.json")) return done(make("custom", 0.9, "NC binary schema"));
  if (inner == "dbf" && !b.empty() && (b[0] == 0x03 || b[0] == static_cast<char>(0x83) || b[0] == 0x30 || b[0] == static_cast<char>(0x8B)))
    return done(make("dbf", 0.9, "dBASE header"));
  // Text or binary? Count control bytes in the first 4 KB.
  size_t n = std::min<size_t>(b.size(), 4096), ctrl = 0;
  for (size_t i = 0; i < n; i++) {
    unsigned char c = static_cast<unsigned char>(b[i]);
    if (c == 0 || (c < 9) || (c > 13 && c < 32))
      ctrl++;
  }
  bool utf16 = b.size() >= 2 && ((static_cast<unsigned char>(b[0]) == 0xFF && static_cast<unsigned char>(b[1]) == 0xFE) ||
                                 (static_cast<unsigned char>(b[0]) == 0xFE && static_cast<unsigned char>(b[1]) == 0xFF));
  if (utf16 || ctrl * 20 < n + 1)
    return done(sniffText(b.substr(0, 8192), inner));
  std::string f = extToFormat(inner);
  if (!f.empty())
    return done(make(f, 0.5, "extension ." + inner));
  return done(make("bin", 0.4, "binary data"));
}

// ---- option schemas --------------------------------------------------------------

namespace {
const std::map<std::string, std::string> &helpTable() {
  static const std::map<std::string, std::string> h = {
      {"sheet", "sheet / section: name or 1-based number"},
      {"range", "cell block, e.g. \"A1:G100\""},
      {"cols", "columns to keep: names [\"ID\",\"Val\"] or positions [1:5]"},
      {"rows", "rows to keep (1-based, after the header): [2:500]"},
      {"hdr", "header row: -1 = detect, 0/false = none, n = row n of the table"},
      {"box", "also return the free text around the data (info boxes)"},
      {"dlm", "delimiter: \",\" \"\\t\" \";\" \"|\" \"\\s+\" (blanks) or \"auto\""},
      {"cmt", "comment prefix; such lines are kept apart with line numbers"},
      {"skip", "physical lines to skip at the top"},
      {"enc", "text encoding: utf-8, latin-1, cp1252, utf-16"},
      {"na", "texts that mean missing (NaN): \"NA\" or [\"NA\",\"-\"]"},
      {"sheets", "several tables at once: a dict name -> table"},
      {"sec_fmt", "marker line of a sheet in one text file, {name} is replaced"},
      {"boxes", "free text written around the data (info boxes)"},
      {"quote", "\"minimal\" quotes only when needed, \"all\" quotes every field"},
      {"float_fmt", "number format for decimals, e.g. \"%.6f\""},
      {"compress", "\"none\" or \"gz\""},
      {"level", "compression level 1..9 (-1 = default 6)"},
      {"max_size", "refuse output larger than this, e.g. \"48kb\", \"5mb\""},
      {"mode", "\"w\" writes a new file, \"a\" appends"},
      {"split", "with sheets: one file per sheet (file_S1.csv ...)"},
      {"path", "JSONPath ($.store.book[*]) or dot path (server.db)"},
      {"lines", "one JSON value per line (NDJSON)"},
      {"as_table", "turn a list of records into a table"},
      {"allow_cmt", "accept // comments and trailing commas (JSON5)"},
      {"indent", "spaces per level (0 = one line)"},
      {"minify", "write everything on one line"},
      {"sort_keys", "write keys in alphabetical order"},
      {"nan_mode", "NaN / Inf as \"null\" or as text \"str\""},
      {"xpath", "XPath selection, e.g. //record[@active='1']"},
      {"ns", "namespace prefixes used in xpath: dict([\"g\"], [\"http://...\"])"},
      {"attr_prefix", "prefix of attribute columns, e.g. \"@\""},
      {"validate_xsd", "XSD file to check the document against"},
      {"root", "root element name when saving a table"},
      {"row_tag", "element name of one table row"},
      {"cdata", "fields written as <![CDATA[...]]>"},
      {"table", "which <table>: number from 0, id or caption text"},
      {"css", "CSS selector, e.g. \"div.card > p\""},
      {"links", "return the page's links (href, text)"},
      {"title", "page title"},
      {"theme", "\"navy\", \"light\" or \"minimal\""},
      {"embed_img", "put local images into the page as data"},
      {"doc", "document number in a --- stream (from 0) or \"all\""},
      {"env", "replace ${VAR} with environment values"},
      {"flow", "write {a: 1} / [1, 2] flow style"},
      {"multi_doc", "data is a list of documents, written with ---"},
      {"sec", "INI section"},
      {"key", "INI key"},
      {"interp", "expand %(name)s references"},
      {"delim", "text between key and value, e.g. \" = \""},
      {"dtype", "element type: float64, int16, uint8 ... or records \"id:i4,val:f8,name:16s\""},
      {"shape", "reshape to dimensions, e.g. [1000, 4]"},
      {"offset", "bytes to skip at the start"},
      {"count", "number of items to read (-1 = all)"},
      {"endian", "\"little\" or \"big\" byte order"},
      {"stride", "bytes from one record to the next (0 = packed)"},
      {"box_bytes", "header bytes before the data, returned as an info box"},
      {"align", "record field alignment: 1 (packed), 2, 4 or 8"},
      {"pad_byte", "byte used for alignment padding"},
      {"data", "the value to save"},
  };
  return h;
}
} // namespace

std::vector<OptionSpec> optionsFor(const std::string &format, const std::string &op) {
  numpy::initialize();
  std::vector<OptionSpec> out;
  const numpy::FunctionSpec *spec = numpy::Registry::instance().find(op + "_" + format);
  if (!spec)
    return out;
  for (const auto &p : spec->params) {
    if (p.name == "file")
      continue;
    OptionSpec o;
    o.name = p.name;
    o.defaultText = p.defaultText;
    const Value &d = p.defaultValue;
    if (p.kind != ncargs::ParamKind::Defaulted)
      o.type = p.name == "data" ? "value" : "text";
    else if (d.isBool())
      o.type = "bool";
    else if (d.isText)
      o.type = d.text().empty() ? "list" : "text";
    else
      o.type = "number";
    auto h = helpTable().find(p.name);
    if (h != helpTable().end())
      o.help = h->second;
    if (p.name == "mode")
      o.choices = {"w", "a"};
    else if (p.name == "quote")
      o.choices = {"minimal", "all"};
    else if (p.name == "compress")
      o.choices = {"none", "gz"};
    else if (p.name == "endian")
      o.choices = {"little", "big"};
    else if (p.name == "theme")
      o.choices = {"navy", "light", "minimal"};
    else if (p.name == "nan_mode")
      o.choices = {"null", "str"};
    out.push_back(o);
  }
  return out;
}

// ---- literals / code ------------------------------------------------------------

bool parseLiteral(const std::string &textIn, Value &out, std::string &err) {
  std::string t = trim(textIn);
  if (t.empty()) {
    out = Value(std::string());
    return true;
  }
  if (t == "true" || t == "false") {
    out = Value::boolean(t == "true");
    return true;
  }
  if (t.size() >= 2 && t.front() == '"' && t.back() == '"') {
    out = Value(t.substr(1, t.size() - 2));
    return true;
  }
  if (t.front() == '[' && t.back() == ']') {
    std::string in = trim(t.substr(1, t.size() - 2));
    size_t colon = in.find(':');
    if (colon != std::string::npos && in.find('"') == std::string::npos && in.find(',') == std::string::npos) {
      double a = std::atof(in.substr(0, colon).c_str()), b = std::atof(in.substr(colon + 1).c_str());
      std::vector<double> v;
      for (double x = a; x <= b + 1e-9; x += 1)
        v.push_back(x);
      out = numpy::makeArray(v);
      return true;
    }
    std::vector<Value> items;
    size_t i = 0;
    while (i < in.size()) {
      size_t e = i;
      bool q = false;
      while (e < in.size() && (q || in[e] != ',')) {
        if (in[e] == '"')
          q = !q;
        e++;
      }
      Value item;
      if (!parseLiteral(in.substr(i, e - i), item, err))
        return false;
      items.push_back(item);
      i = e + 1;
    }
    out = Value(std::move(items));
    return true;
  }
  char *end = nullptr;
  double d = std::strtod(t.c_str(), &end);
  if (end && *end == '\0') {
    out = Value(d);
    return true;
  }
  // a bare word counts as text (sheet=ABC)
  out = Value(t);
  return true;
}

std::string generateCode(const std::string &op, const std::string &format, const std::string &pathIn,
                         const std::string &var, const std::vector<std::pair<std::string, std::string>> &options) {
  std::string path;
  for (char c : pathIn)
    path += c == '\\' ? std::string("/") : c == '"' ? std::string("\\\"") : std::string(1, c);
  std::string args = "\"" + path + "\"";
  if (op == "save")
    args += ", " + (var.empty() ? std::string("T") : var);
  for (const auto &kv : options) {
    std::string v = trim(kv.second);
    if (v.empty())
      continue;
    Value parsed;
    std::string err;
    bool bare = v.front() != '"' && v.front() != '[' && v != "true" && v != "false" &&
                (std::strtod(v.c_str(), nullptr) == 0 && v.find_first_not_of("0123456789.-+eE") != std::string::npos);
    args += ", " + kv.first + "=" + (bare ? "\"" + v + "\"" : v);
  }
  std::string fn = op + "_" + format;
  if (op == "save")
    return fn + "(" + args + ");";
  return (var.empty() ? (op == "load" ? "D" : "T") : var) + " = " + fn + "(" + args + ");";
}

// ---- calling the registry with stderr captured --------------------------------------

namespace {
bool callCaptured(const std::string &name, const std::vector<Value> &args, const std::vector<std::string> &names,
                  size_t nout, std::vector<Value> &out, std::string &err) {
  std::ostringstream captured;
  std::streambuf *old = std::cerr.rdbuf(captured.rdbuf());
  bool ok = false;
  bool found = nout > 1 ? numpy::tryCallMulti(name, args, nout, out, ok, names) : false;
  if (nout <= 1) {
    Value v;
    found = numpy::tryCall(name, args, v, ok, names);
    out = {v};
  }
  std::cerr.rdbuf(old);
  if (!found) {
    err = name + " is not available yet";
    return false;
  }
  if (!ok) {
    err = trim(captured.str());
    if (err.rfind("Error: ", 0) == 0)
      err = err.substr(7);
    return false;
  }
  return true;
}

bool buildArgs(const std::string &source, const std::vector<std::pair<std::string, std::string>> &options,
               std::vector<Value> &args, std::vector<std::string> &names, std::string &err) {
  args = {Value(source)};
  names = {""};
  for (const auto &kv : options) {
    Value v;
    if (!parseLiteral(kv.second, v, err))
      return false;
    args.push_back(v);
    names.push_back(kv.first);
  }
  return true;
}

void flattenTree(const std::string &prefix, const Value &v, std::vector<std::vector<std::string>> &rows,
                 size_t maxRows) {
  if (rows.size() >= maxRows)
    return;
  if (v.isDict || v.isObject) {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      if (kv.first != "key_order")
        keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys)
      flattenTree(prefix.empty() ? k : prefix + "." + k, v.dict().at(k), rows, maxRows);
    return;
  }
  if (v.isArray && v.length() > 0 && (v.at(0).isDict || v.at(0).isObject)) {
    for (size_t i = 0; i < v.length() && rows.size() < maxRows; i++)
      flattenTree(prefix + "[" + std::to_string(i) + "]", v.at(i), rows, maxRows);
    return;
  }
  std::string text;
  if (v.isArray || v.isMatrix) {
    std::vector<std::string> parts = optTextList(v);
    for (size_t i = 0; i < parts.size() && i < 8; i++)
      text += (i ? ", " : "") + parts[i];
    if (parts.size() > 8)
      text += ", ...";
    text = "[" + text + "]";
  } else {
    text = cellText(v);
  }
  rows.push_back({prefix, text});
}
} // namespace

// ---- session --------------------------------------------------------------------

void ImportSession::setSource(const std::string &pathOrUrl) {
  source_ = pathOrUrl;
  format_.clear();
  options_.clear();
}

Detection ImportSession::detect() {
  Detection d = detectFormat(source_);
  if (!d.format.empty())
    format_ = d.format;
  return d;
}

void ImportSession::setOption(const std::string &name, const std::string &literal) {
  for (auto &kv : options_)
    if (kv.first == name) {
      kv.second = literal;
      return;
    }
  options_.emplace_back(name, literal);
}

bool ImportSession::preview(size_t maxRows, Preview &out, std::string &err) {
  out = Preview();
  if (format_.empty())
    detect();
  if (format_.empty()) {
    err = "the format of " + source_ + " is not known";
    return false;
  }
  std::vector<Value> args, res;
  std::vector<std::string> names;
  if (!buildArgs(source_, options_, args, names, err) ||
      !callCaptured("read_" + format_, args, names, 2, res, err))
    return false;
  const Value &v = res[0];
  if (res.size() > 1)
    if (const Value *cols = field(res[1], "cols"))
      out.cols = optTextList(*cols);
  if (res.size() > 1)
    if (const Value *boxes = field(res[1], "boxes"))
      if (boxes->isArray || boxes->isMatrix)
        out.boxes = optTextList(*boxes);
  if (v.isMatrix && !v.isND()) {
    out.kind = "table";
    out.totalRows = v.rows();
    if (out.cols.empty())
      for (size_t c = 0; c < v.cols(); c++)
        out.cols.push_back("Col_" + std::to_string(c + 1));
    for (size_t r = 0; r < v.rows() && r < maxRows; r++) {
      std::vector<std::string> row;
      for (size_t c = 0; c < v.rowLength(r); c++)
        row.push_back(cellText(v.at(r, c), "%.6g"));
      out.rows.push_back(std::move(row));
    }
  } else if (v.isDict || v.isObject || (v.isArray && v.length() && (v.at(0).isDict || v.at(0).isObject))) {
    out.kind = "tree";
    out.cols = {"key", "value"};
    flattenTree("", v, out.rows, maxRows);
    out.totalRows = out.rows.size();
  } else if (v.isArray) {
    out.kind = "array";
    out.cols = {"value"};
    out.totalRows = v.length();
    for (size_t i = 0; i < v.length() && i < maxRows; i++)
      out.rows.push_back({cellText(v.at(i), "%.6g")});
  } else if (v.isND()) {
    out.kind = "array";
    std::string shape;
    for (size_t s : v.ndShape())
      shape += (shape.empty() ? "" : "x") + std::to_string(s);
    out.note = "N-dimensional " + shape;
  } else {
    out.kind = "text";
    out.cols = {"value"};
    out.rows.push_back({cellText(v)});
    out.totalRows = 1;
  }
  return true;
}

std::string ImportSession::code(const std::string &op, const std::string &var) const {
  return generateCode(op, format_, source_, var, options_);
}

bool ImportSession::run(const std::string &op, Value &out, std::string &err, IoListener listener) {
  if (format_.empty())
    detect();
  if (format_.empty()) {
    err = "the format of " + source_ + " is not known";
    return false;
  }
  if (listener)
    setIoListener(listener);
  std::vector<Value> args, res;
  std::vector<std::string> names;
  bool ok = buildArgs(source_, options_, args, names, err) &&
            callCaptured(op + "_" + format_, args, names, 1, res, err);
  if (listener)
    setIoListener({});
  if (ok)
    out = res[0];
  return ok;
}

// ---- NC functions -----------------------------------------------------------------

namespace {

Value formatsFn(const std::vector<Value> &a, CallContext &) {
  std::string cat = a.empty() ? "" : lower(optText(a[0], ""));
  std::vector<std::vector<Value>> m;
  for (const auto &f : formatCatalog()) {
    if (!cat.empty() && lower(f.category).find(cat) == std::string::npos && f.id != cat)
      continue;
    m.push_back({Value(f.id), Value(f.category), Value(f.extensions),
                 Value(std::string(formatAvailable(f.id) ? "available" : "phase " + std::to_string(f.phase)))});
  }
  if (m.empty())
    return Value(std::vector<Value>{});
  return Value(m);
}

Value detectFn(const std::vector<Value> &a, CallContext &ctx) {
  std::string file;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  Detection d = detectFormat(file);
  Fields f;
  f["format"] = Value(d.format);
  f["category"] = Value(d.category);
  f["confidence"] = Value(d.confidence);
  f["reason"] = Value(d.reason);
  f["compressed"] = Value::boolean(d.compressed);
  f["available"] = Value::boolean(!d.format.empty() && formatAvailable(d.format));
  f["read"] = Value(d.format.empty() ? "" : "read_" + d.format);
  f["load"] = Value(d.format.empty() ? "" : "load_" + d.format);
  f["save"] = Value(d.format.empty() ? "" : "save_" + d.format);
  return makeObject("NcDetection", std::move(f));
}

Value optionsFn(const std::vector<Value> &a, CallContext &ctx) {
  std::string fmt;
  if (!numpy::argText(a, 0, ctx, fmt))
    return Value(0.0);
  std::string op = lower(optText(a[1], "read"));
  if (op != "read" && op != "load" && op != "save") {
    ctx.fail("op must be \"read\", \"load\" or \"save\"");
    return Value(0.0);
  }
  auto opts = optionsFor(lower(fmt), op);
  const auto &names = registeredIoNames();
  if (opts.empty() && std::find(names.begin(), names.end(), op + "_" + lower(fmt)) == names.end()) {
    ctx.fail(op + "_" + fmt + " is not available");
    return Value(0.0);
  }
  // a function whose only input is the file (load_parquet) has no options: an empty list
  std::vector<std::vector<Value>> m;
  for (const auto &o : opts)
    m.push_back({Value(o.name), Value(o.defaultText), Value(o.type), Value(o.help)});
  return Value(m);
}

Value previewFn(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  ImportSession s;
  s.setSource(file);
  if (given(a[2]))
    s.setFormat(lower(optText(a[2])));
  else
    s.detect();
  Preview p;
  if (!s.preview(static_cast<size_t>(std::max(1LL, optInt(a[1], 20))), p, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  f["format"] = Value(s.format());
  f["kind"] = Value(p.kind);
  f["cols"] = textList(p.cols);
  std::vector<std::vector<Value>> rows;
  for (const auto &r : p.rows) {
    std::vector<Value> row;
    for (const auto &c : r)
      row.push_back(Value(c));
    rows.push_back(std::move(row));
  }
  f["rows"] = rows.empty() ? Value(std::vector<Value>{}) : Value(rows);
  f["total_rows"] = Value(static_cast<double>(p.totalRows));
  f["boxes"] = textList(p.boxes);
  f["note"] = Value(p.note);
  f["code"] = Value(s.code("read"));
  return makeObject("NcPreview", std::move(f));
}

Value codeFn(const std::vector<Value> &a, CallContext &ctx) {
  std::string file;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  std::string op = lower(optText(a[1], "read"));
  std::string fmt = given(a[3]) ? lower(optText(a[3])) : detectFormat(file).format;
  if (fmt.empty()) {
    ctx.fail("the format of " + file + " is not known - give format=\"csv\"");
    return Value(0.0);
  }
  return Value(generateCode(op, fmt, file, optText(a[2], ""), {}));
}

} // namespace

void registerSession(Registry &reg) {
  addFn(reg, "io_formats", "category=\"\"",
        "the data formats NC reads and writes: id, category, extensions, status", "-", formatsFn);
  addFn(reg, "io_detect", "file", "which format a file is, from its first bytes", "-", detectFn);
  addFn(reg, "io_options", "format, op=\"read\"",
        "the named options of read_/load_/save_<format>: name, default, type, help", "-", optionsFn);
  addFn(reg, "io_preview", "file, n=20, format=\"\"",
        "the first n rows of a file as the Import window shows them", "-", previewFn);
  addFn(reg, "io_code", "file, op=\"read\", var=\"\", format=\"\"",
        "the NC line that reads / loads / saves a file", "-", codeFn);
}

} // namespace io
} // namespace nc
