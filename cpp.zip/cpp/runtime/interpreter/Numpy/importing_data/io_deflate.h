// DEFLATE (RFC 1951), zlib (RFC 1950) and gzip (RFC 1952), hand-written.
//
// Used by the I/O functions for compress="gz" on text formats (phase 1), and
// by the zip/PNG based formats (xlsx, png - phase 2). No third-party code.
#ifndef NC_IO_DEFLATE_H
#define NC_IO_DEFLATE_H

#include <cstdint>
#include <string>

namespace nc {
namespace io {

uint32_t crc32(const void *data, size_t n, uint32_t crc = 0);
uint32_t adler32(const void *data, size_t n, uint32_t adler = 1);

// Raw DEFLATE stream. `level` 0 = stored, 1..9 = how hard the matcher looks.
std::string deflateRaw(const std::string &in, int level = 6);
// Raw DEFLATE stream -> bytes. False with `err` on a corrupt stream.
// `consumed` (optional) receives the number of input bytes used.
bool inflateRaw(const std::string &in, size_t start, std::string &out, std::string &err,
                size_t *consumed = nullptr);

std::string gzipCompress(const std::string &in, int level = 6);
bool gzipDecompress(const std::string &in, std::string &out, std::string &err);
bool isGzip(const std::string &bytes);

std::string zlibCompress(const std::string &in, int level = 6);
bool zlibDecompress(const std::string &in, std::string &out, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_DEFLATE_H
