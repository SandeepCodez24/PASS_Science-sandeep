// Section 1 of 11 - Importing Data (29 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_IMPORTING_DATA_MAIN_H
#define NC_NUMPY_IMPORTING_DATA_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Importing Data function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerImportingData(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_IMPORTING_DATA_MAIN_H
