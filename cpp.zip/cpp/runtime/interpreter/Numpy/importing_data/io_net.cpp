// Sockets, hashes, URI parsing - see io_net.h.
#include "io_net.h"

#include <cstring>
#include <random>
#include <vector>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace nc {
namespace io {

namespace {
uint32_t rol(uint32_t x, int n) { return (x << n) | (x >> (32 - n)); }
uint32_t ror(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

std::string padMessage(const std::string &s, bool bigEndianLength) {
  std::string m = s;
  uint64_t bits = static_cast<uint64_t>(s.size()) * 8;
  m.push_back(static_cast<char>(0x80));
  while (m.size() % 64 != 56) m.push_back('\0');
  for (int k = 0; k < 8; k++)
    m.push_back(static_cast<char>(bigEndianLength ? (bits >> (56 - 8 * k)) & 0xFF : (bits >> (8 * k)) & 0xFF));
  return m;
}
} // namespace

std::string md5(const std::string &s) {
  static const uint32_t K[64] = {
      0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee, 0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501, 0x698098d8, 0x8b44f7af, 0xffff5bb1,
      0x895cd7be, 0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821, 0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa, 0xd62f105d, 0x02441453,
      0xd8a1e681, 0xe7d3fbc8, 0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed, 0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a, 0xfffa3942,
      0x8771f681, 0x6d9d6122, 0xfde5380c, 0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70, 0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
      0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665, 0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039, 0x655b59c3, 0x8f0ccc92, 0xffeff47d,
      0x85845dd1, 0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1, 0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391};
  static const int R[64] = {7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9,  14, 20, 5, 9,  14, 20, 5, 9,  14, 20, 5, 9,  14, 20,
                            4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21};
  uint32_t h[4] = {0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476};
  std::string m = padMessage(s, false);
  for (size_t off = 0; off < m.size(); off += 64) {
    uint32_t w[16];
    for (int k = 0; k < 16; k++) {
      const unsigned char *p = reinterpret_cast<const unsigned char *>(m.data() + off + 4 * k);
      w[k] = p[0] | (p[1] << 8) | (p[2] << 16) | (static_cast<uint32_t>(p[3]) << 24);
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3];
    for (int i = 0; i < 64; i++) {
      uint32_t f;
      int g;
      if (i < 16) { f = (b & c) | (~b & d); g = i; }
      else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) % 16; }
      else if (i < 48) { f = b ^ c ^ d; g = (3 * i + 5) % 16; }
      else { f = c ^ (b | ~d); g = (7 * i) % 16; }
      uint32_t t = d;
      d = c;
      c = b;
      b = b + rol(a + f + K[i] + w[g], R[i]);
      a = t;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d;
  }
  std::string out;
  for (uint32_t v : h) for (int k = 0; k < 4; k++) out.push_back(static_cast<char>((v >> (8 * k)) & 0xFF));
  return out;
}

std::string sha1(const std::string &s) {
  uint32_t h[5] = {0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0};
  std::string m = padMessage(s, true);
  for (size_t off = 0; off < m.size(); off += 64) {
    uint32_t w[80];
    for (int k = 0; k < 16; k++) {
      const unsigned char *p = reinterpret_cast<const unsigned char *>(m.data() + off + 4 * k);
      w[k] = (static_cast<uint32_t>(p[0]) << 24) | (p[1] << 16) | (p[2] << 8) | p[3];
    }
    for (int k = 16; k < 80; k++) w[k] = rol(w[k - 3] ^ w[k - 8] ^ w[k - 14] ^ w[k - 16], 1);
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4];
    for (int i = 0; i < 80; i++) {
      uint32_t f, k;
      if (i < 20) { f = (b & c) | (~b & d); k = 0x5A827999; }
      else if (i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1; }
      else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
      else { f = b ^ c ^ d; k = 0xCA62C1D6; }
      uint32_t t = rol(a, 5) + f + e + k + w[i];
      e = d; d = c; c = rol(b, 30); b = a; a = t;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e;
  }
  std::string out;
  for (uint32_t v : h) for (int k = 3; k >= 0; k--) out.push_back(static_cast<char>((v >> (8 * k)) & 0xFF));
  return out;
}

std::string sha256(const std::string &s) {
  static const uint32_t K[64] = {
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be,
      0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa,
      0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85,
      0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
      0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
      0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};
  uint32_t h[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
  std::string m = padMessage(s, true);
  for (size_t off = 0; off < m.size(); off += 64) {
    uint32_t w[64];
    for (int k = 0; k < 16; k++) {
      const unsigned char *p = reinterpret_cast<const unsigned char *>(m.data() + off + 4 * k);
      w[k] = (static_cast<uint32_t>(p[0]) << 24) | (p[1] << 16) | (p[2] << 8) | p[3];
    }
    for (int k = 16; k < 64; k++) {
      uint32_t s0 = ror(w[k - 15], 7) ^ ror(w[k - 15], 18) ^ (w[k - 15] >> 3);
      uint32_t s1 = ror(w[k - 2], 17) ^ ror(w[k - 2], 19) ^ (w[k - 2] >> 10);
      w[k] = w[k - 16] + s0 + w[k - 7] + s1;
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int i = 0; i < 64; i++) {
      uint32_t S1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25), ch = (e & f) ^ (~e & g);
      uint32_t t1 = hh + S1 + ch + K[i] + w[i];
      uint32_t S0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22), mj = (a & b) ^ (a & c) ^ (b & c);
      uint32_t t2 = S0 + mj;
      hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
  }
  std::string out;
  for (uint32_t v : h) for (int k = 3; k >= 0; k--) out.push_back(static_cast<char>((v >> (8 * k)) & 0xFF));
  return out;
}

std::string hmacSha256(const std::string &keyIn, const std::string &msg) {
  std::string key = keyIn.size() > 64 ? sha256(keyIn) : keyIn;
  key.resize(64, '\0');
  std::string ipad(64, '\0'), opad(64, '\0');
  for (int k = 0; k < 64; k++) { ipad[k] = static_cast<char>(key[k] ^ 0x36); opad[k] = static_cast<char>(key[k] ^ 0x5c); }
  return sha256(opad + sha256(ipad + msg));
}

std::string pbkdf2Sha256(const std::string &password, const std::string &salt, int iterations) {
  std::string u = hmacSha256(password, salt + std::string("\0\0\0\1", 4)), out = u;
  for (int i = 1; i < iterations; i++) {
    u = hmacSha256(password, u);
    for (size_t k = 0; k < out.size(); k++) out[k] = static_cast<char>(out[k] ^ u[k]);
  }
  return out;
}

std::string hexOf(const std::string &raw) {
  static const char *d = "0123456789abcdef";
  std::string o;
  for (unsigned char c : raw) { o.push_back(d[c >> 4]); o.push_back(d[c & 15]); }
  return o;
}

std::string base64Encode(const std::string &in) {
  static const char *t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  std::string out;
  size_t i = 0;
  for (; i + 2 < in.size(); i += 3) {
    uint32_t v = (static_cast<unsigned char>(in[i]) << 16) | (static_cast<unsigned char>(in[i + 1]) << 8) | static_cast<unsigned char>(in[i + 2]);
    out += t[v >> 18]; out += t[(v >> 12) & 63]; out += t[(v >> 6) & 63]; out += t[v & 63];
  }
  if (i + 1 == in.size()) { uint32_t v = static_cast<unsigned char>(in[i]) << 16; out += t[v >> 18]; out += t[(v >> 12) & 63]; out += "=="; }
  else if (i + 2 == in.size()) { uint32_t v = (static_cast<unsigned char>(in[i]) << 16) | (static_cast<unsigned char>(in[i + 1]) << 8); out += t[v >> 18]; out += t[(v >> 12) & 63]; out += t[(v >> 6) & 63]; out += '='; }
  return out;
}

std::string base64Decode(const std::string &in) {
  std::string out;
  uint32_t buf = 0;
  int bits = 0;
  for (char c : in) {
    int v = c >= 'A' && c <= 'Z' ? c - 'A' : c >= 'a' && c <= 'z' ? c - 'a' + 26 : c >= '0' && c <= '9' ? c - '0' + 52 : c == '+' ? 62 : c == '/' ? 63 : -1;
    if (v < 0) continue;
    buf = (buf << 6) | static_cast<uint32_t>(v);
    bits += 6;
    if (bits >= 8) { bits -= 8; out.push_back(static_cast<char>((buf >> bits) & 0xFF)); }
  }
  return out;
}

std::string randomBytes(size_t n) {
  std::random_device rd;
  std::string out;
  for (size_t k = 0; k < n; k++) out.push_back(static_cast<char>(rd() & 0xFF));
  return out;
}

// ---- sockets ---------------------------------------------------------------------------

TcpConn::~TcpConn() { close(); }

bool TcpConn::connect(const std::string &host, int port, std::string &err, int timeoutMs) {
#ifdef _WIN32
  static bool started = false;
  if (!started) {
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { err = "network is not available (Winsock)"; return false; }
    started = true;
  }
#endif
  addrinfo hints{}, *res = nullptr;
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  if (getaddrinfo(host.c_str(), std::to_string(port).c_str(), &hints, &res) != 0 || !res) {
    err = "cannot resolve host '" + host + "'";
    return false;
  }
  for (addrinfo *a = res; a; a = a->ai_next) {
    auto s = ::socket(a->ai_family, a->ai_socktype, a->ai_protocol);
#ifdef _WIN32
    if (s == INVALID_SOCKET) continue;
    DWORD tv = static_cast<DWORD>(timeoutMs);
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
    setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, reinterpret_cast<const char *>(&tv), sizeof tv);
    if (::connect(s, a->ai_addr, static_cast<int>(a->ai_addrlen)) == 0) { sock_ = static_cast<intptr_t>(s); break; }
    closesocket(s);
#else
    if (s < 0) continue;
    if (::connect(s, a->ai_addr, a->ai_addrlen) == 0) { sock_ = s; break; }
    ::close(s);
#endif
  }
  freeaddrinfo(res);
  if (sock_ == -1) {
    err = "cannot connect to " + host + ":" + std::to_string(port) + " (server not running, wrong port, or a firewall)";
    return false;
  }
  return true;
}

bool TcpConn::send(const std::string &data, std::string &err) {
  size_t sent = 0;
  while (sent < data.size()) {
#ifdef _WIN32
    int n = ::send(static_cast<SOCKET>(sock_), data.data() + sent, static_cast<int>(data.size() - sent), 0);
#else
    ssize_t n = ::send(static_cast<int>(sock_), data.data() + sent, data.size() - sent, 0);
#endif
    if (n <= 0) { err = "the database connection was closed while sending"; return false; }
    sent += static_cast<size_t>(n);
  }
  return true;
}

bool TcpConn::recv(size_t n, std::string &out, std::string &err) {
  out.assign(n, '\0');
  size_t got = 0;
  while (got < n) {
#ifdef _WIN32
    int r = ::recv(static_cast<SOCKET>(sock_), out.data() + got, static_cast<int>(n - got), 0);
#else
    ssize_t r = ::recv(static_cast<int>(sock_), out.data() + got, n - got, 0);
#endif
    if (r <= 0) { err = "the database connection was closed (or timed out) while reading"; return false; }
    got += static_cast<size_t>(r);
  }
  return true;
}

void TcpConn::close() {
  if (sock_ == -1) return;
#ifdef _WIN32
  closesocket(static_cast<SOCKET>(sock_));
#else
  ::close(static_cast<int>(sock_));
#endif
  sock_ = -1;
}

bool DbUri::parse(const std::string &uri, std::string &err) {
  size_t s = uri.find("://");
  if (s == std::string::npos) { err = "a database address looks like scheme://user:pass@host:port/db"; return false; }
  scheme = uri.substr(0, s);
  std::string rest = uri.substr(s + 3);
  size_t at = rest.rfind('@');
  if (at != std::string::npos) {
    std::string cred = rest.substr(0, at);
    size_t c = cred.find(':');
    user = cred.substr(0, c);
    if (c != std::string::npos) password = cred.substr(c + 1);
    rest = rest.substr(at + 1);
  }
  size_t q = rest.find('?');
  if (q != std::string::npos) rest = rest.substr(0, q);
  size_t slash = rest.find('/');
  std::string hp = rest.substr(0, slash);
  if (slash != std::string::npos) database = rest.substr(slash + 1);
  size_t colon = hp.rfind(':');
  if (colon != std::string::npos && hp.find(']') == std::string::npos) { host = hp.substr(0, colon); port = std::atoi(hp.substr(colon + 1).c_str()); }
  else if (!hp.empty()) host = hp;
  // %-decoding of user / password
  auto dec = [](std::string v) {
    std::string o;
    for (size_t i = 0; i < v.size(); i++) {
      if (v[i] == '%' && i + 2 < v.size()) { o.push_back(static_cast<char>(std::strtol(v.substr(i + 1, 2).c_str(), nullptr, 16))); i += 2; }
      else o.push_back(v[i]);
    }
    return o;
  };
  user = dec(user);
  password = dec(password);
  return true;
}

} // namespace io
} // namespace nc
