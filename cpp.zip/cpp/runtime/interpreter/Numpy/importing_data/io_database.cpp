// CATEGORY 20 - SQL databases: read_/load_/save_ sqlite, postgresql, mysql,
// oracle, sqlserver.
#include "io_database.h"

#include <algorithm>
#include <cmath>
#include <map>

#include "../numpy_common.h"
#include "io_formats.h"
#include "io_sql.h"

namespace nc {
namespace io {

double DbBackend::count(const std::string &schema, const std::string &table, std::string &err) {
  Table t;
  std::string q = "SELECT COUNT(*) FROM " + (schema.empty() || dialect() == "sqlite" ? "" : sqlIdent(schema) + ".") + sqlIdent(table);
  if (dialect() == "mysql") q = "SELECT COUNT(*) FROM `" + table + "`";
  if (!query(q, {}, t, err) || t.rows.empty()) return -1;
  return numpy::isPlainNumber(t.rows[0][0]) ? t.rows[0][0].number : std::strtod(cellText(t.rows[0][0]).c_str(), nullptr);
}

bool bindParams(const std::string &sql, const std::vector<Value> &params, std::string &out, std::string &err) {
  out.clear();
  size_t k = 0;
  bool q = false;
  for (size_t i = 0; i < sql.size(); i++) {
    char c = sql[i];
    if (c == '\'') q = !q;
    if (!q && (c == '?' || (c == '$' && i + 1 < sql.size() && std::isdigit(static_cast<unsigned char>(sql[i + 1]))))) {
      size_t idx = k++;
      if (c == '$') {
        size_t e = i + 1;
        while (e < sql.size() && std::isdigit(static_cast<unsigned char>(sql[e]))) e++;
        idx = static_cast<size_t>(std::atoi(sql.substr(i + 1, e - i - 1).c_str())) - 1;
        i = e - 1;
      }
      if (idx >= params.size()) { err = "the query has more placeholders than params"; return false; }
      out += sqlLiteral(params[idx]);
      continue;
    }
    out.push_back(c);
  }
  return true;
}

std::string sqlType(const std::string &dialect, const Table &t, size_t c) {
  std::string ct = columnType(t, c);
  if (dialect == "postgresql") return ct == "int64" ? "BIGINT" : ct == "float64" ? "DOUBLE PRECISION" : ct == "bool" ? "BOOLEAN" : ct == "datetime" ? "TIMESTAMP" : "TEXT";
  if (dialect == "mysql") return ct == "int64" ? "BIGINT" : ct == "float64" ? "DOUBLE" : ct == "bool" ? "TINYINT(1)" : ct == "datetime" ? "DATETIME" : "TEXT";
  return ct == "int64" || ct == "bool" ? "INTEGER" : ct == "float64" ? "REAL" : "TEXT";
}

namespace {

// ---- SQLite file backend -------------------------------------------------------------

class SqliteBackend : public DbBackend {
public:
  std::string path;
  DbFile db;
  bool loaded = false;
  std::string dialect() const override { return "sqlite"; }
  bool open(const std::string &uri, std::string &err) {
    path = uri;
    for (const char *p : {"sqlite:///", "sqlite://", "file:"})
      if (path.rfind(p, 0) == 0) path = path.substr(std::char_traits<char>::length(p));
    if (!fileExists(path)) return true; // created by save_sqlite
    std::string bytes;
    if (!readFile(path, bytes, err) || !readSqlite(bytes, db, err)) return false;
    loaded = true;
    return true;
  }
  const DbTable *find(const std::string &name) const {
    for (const auto &t : db.tables) if (t.name == name) return &t;
    for (const auto &t : db.tables) if (lower(t.name) == lower(name)) return &t;
    return nullptr;
  }
  bool tables(const std::string &, std::vector<std::string> &t, std::vector<std::string> &v, std::string &) override {
    for (const auto &x : db.tables) t.push_back(x.name);
    for (const auto &x : db.views) v.push_back(x.first);
    return true;
  }
  bool describe(const std::string &, const std::string &table, DbTable &out, std::string &err) override {
    const DbTable *t = find(table);
    if (!t) { err = noTable(table); return false; }
    out = *t;
    out.rows.clear();
    return true;
  }
  std::string noTable(const std::string &table) const {
    std::string names;
    for (const auto &x : db.tables) names += (names.empty() ? "" : ", ") + x.name;
    return "no table '" + table + "' in " + path + " (tables: " + (names.empty() ? "none" : names) + ")";
  }
  bool lookup(const std::string &name, Table &out, std::string &err, int depth = 0) {
    if (const DbTable *t = find(name)) {
      out = Table();
      for (const auto &c : t->cols) out.cols.push_back(c.name);
      out.rows = t->rows;
      return true;
    }
    for (const auto &v : db.views)
      if (lower(v.first) == lower(name) && depth < 8) {
        size_t as = lower(v.second).find(" as ");
        if (as == std::string::npos) break;
        return sqlSelect(v.second.substr(as + 4), {}, [&](const std::string &n, Table &o, std::string &e) { return lookup(n, o, e, depth + 1); }, out, err);
      }
    err = noTable(name);
    return false;
  }
  bool query(const std::string &sql, const std::vector<Value> &params, Table &out, std::string &err) override {
    return sqlSelect(sql, params, [&](const std::string &n, Table &o, std::string &e) { return lookup(n, o, e); }, out, err);
  }
  double count(const std::string &, const std::string &table, std::string &) override {
    const DbTable *t = find(table);
    return t ? static_cast<double>(t->rows.size()) : -1;
  }
  bool write(const WriteRequest &req, std::string &err) override {
    DbTable *t = nullptr;
    for (auto &x : db.tables) if (lower(x.name) == lower(req.table)) t = &x;
    if (t && req.mode == "fail") { err = "table '" + req.table + "' already exists (mode=\"fail\")"; return false; }
    if (t && req.mode == "replace") {
      db.tables.erase(db.tables.begin() + (t - db.tables.data()));
      t = nullptr;
    }
    if (!t) {
      DbTable nt;
      nt.name = req.table;
      for (size_t c = 0; c < req.data.cols.size(); c++) {
        DbColumn col;
        col.name = req.data.cols[c];
        col.type = req.dtype.count(col.name) ? optText(req.dtype.at(col.name)) : sqlType("sqlite", req.data, c);
        col.pk = std::find(req.pk.begin(), req.pk.end(), col.name) != req.pk.end() && req.pk.size() == 1;
        col.rowidAlias = col.pk && lower(col.type) == "integer";
        nt.cols.push_back(col);
      }
      nt.comment = req.comment;
      db.tables.push_back(nt);
      t = &db.tables.back();
    } else if (!req.comment.empty()) {
      t->comment = req.comment;
      t->sql.clear();
    }
    // map incoming columns onto the table
    std::vector<int> map;
    for (const auto &c : req.data.cols) {
      int found = -1;
      for (size_t k = 0; k < t->cols.size(); k++) if (lower(t->cols[k].name) == lower(c)) found = static_cast<int>(k);
      if (found < 0) { err = "table '" + t->name + "' has no column '" + c + "'"; return false; }
      map.push_back(found);
    }
    std::vector<size_t> keyCols;
    for (const auto &kc : (req.conflict.empty() ? req.pk : req.conflict))
      for (size_t k = 0; k < t->cols.size(); k++) if (lower(t->cols[k].name) == lower(kc)) keyCols.push_back(k);
    if (req.mode == "upsert" && keyCols.empty()) { err = "mode=\"upsert\" needs pk= or conflict_cols="; return false; }
    int64_t nextId = 1;
    for (int64_t id : t->rowids) nextId = std::max(nextId, id + 1);
    for (const auto &r : req.data.rows) {
      std::vector<Value> row(t->cols.size(), Value(std::nan("")));
      for (size_t c = 0; c < map.size(); c++) row[static_cast<size_t>(map[c])] = r[c];
      bool replaced = false;
      if (req.mode == "upsert")
        for (size_t e = 0; e < t->rows.size() && !replaced; e++) {
          bool same = true;
          for (size_t k : keyCols) if (cellText(t->rows[e][k]) != cellText(row[k])) same = false;
          if (same) { t->rows[e] = row; replaced = true; }
        }
      if (!replaced) {
        int64_t id = nextId++;
        for (size_t k = 0; k < t->cols.size(); k++)
          if (t->cols[k].rowidAlias) {
            if (isNumberCell(row[k]) && !std::isnan(row[k].number)) id = static_cast<int64_t>(row[k].number), nextId = std::max(nextId, id + 1);
            else row[k] = Value(static_cast<double>(id));
          }
        t->rows.push_back(row);
        t->rowids.push_back(id);
      }
    }
    for (const auto &ix : req.index) {
      std::string name = "idx_" + t->name + "_" + ix;
      bool have = false;
      for (const auto &e : t->indexes) if (e.first == name) have = true;
      if (!have) t->indexes.push_back({name, {ix}});
    }
    if (t->sql.empty() || t->sql.find("--") == std::string::npos) t->sql = createTableSql(*t);
    std::string bytes = writeSqlite(db);
    if (bytes.empty()) { err = "the database schema is too large for NC's SQLite writer (more than one page)"; return false; }
    return writeFile(path, bytes, false, err);
  }
};


} // namespace

std::unique_ptr<DbBackend> openBackend(const std::string &format, const std::string &uri, std::string &err) {
  if (format == "sqlite") {
    auto b = std::make_unique<SqliteBackend>();
    if (!b->open(uri, err)) return nullptr;
    return b;
  }
  if (format == "postgresql") return openPostgres(uri, err);
  if (format == "mysql") return openMysql(uri, err);
  if (format == "oracle")
    err = "Oracle's network protocol (TNS) is proprietary and not built in - export the table (e.g. to .csv or .parquet) or reach it through a PostgreSQL foreign data wrapper";
  else
    err = "SQL Server's TDS protocol (with its required TLS login) is not built in - export the table (e.g. bcp to .csv) or use a linked PostgreSQL/MySQL server";
  return nullptr;
}

namespace {

std::string tableRef(const DbBackend &b, const std::string &schema, const std::string &table) {
  if (b.dialect() == "mysql") return "`" + table + "`";
  if (b.dialect() == "sqlite" || schema.empty()) return sqlIdent(table);
  return sqlIdent(schema) + "." + sqlIdent(table);
}

std::string colRef(const DbBackend &b, const std::string &c) { return b.dialect() == "mysql" ? "`" + c + "`" : sqlIdent(c); }

std::string defaultSchema(const std::string &fmt, const Value &v) {
  std::string s = optText(v, "");
  if (fmt == "postgresql") return s.empty() ? "public" : s;
  if (fmt == "sqlite" || fmt == "mysql") return s == "public" ? "" : s;
  return s;
}

bool firstTable(DbBackend &b, const std::string &schema, std::string &table, std::string &err) {
  std::vector<std::string> t, v;
  if (!b.tables(schema, t, v, err)) return false;
  if (t.empty()) { err = "the database has no tables"; return false; }
  table = t[0];
  return true;
}

// read_<db>(uri, table, schema, cols, where, limit, query, params, chunk, box)
void readDb(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string uri, err;
  if (!numpy::argText(a, 0, ctx, uri)) return;
  EventScope ev("read_" + fmt, fmt == "sqlite" ? uri : "(database)");
  auto b = openBackend(fmt, uri, err);
  if (!b) return ctx.fail(err);
  std::string schema = defaultSchema(fmt, a[2]);
  std::string sql = optText(a[6], "");
  std::vector<Value> params;
  if (given(a[7])) {
    if (a[7].isArray) for (size_t i = 0; i < a[7].length(); i++) params.push_back(a[7].at(i));
    else if (a[7].isMatrix) for (size_t c = 0; c < a[7].cols(); c++) params.push_back(a[7].at(0, c));
    else params.push_back(a[7]);
  }
  std::string table = optText(a[1], "");
  if (sql.empty()) {
    if (table.empty() && !firstTable(*b, schema, table, err)) return ctx.fail(err);
    std::string cols = "*";
    std::vector<std::string> cl = optTextList(a[3]);
    if (!cl.empty()) { cols.clear(); for (size_t k = 0; k < cl.size(); k++) cols += (k ? ", " : "") + colRef(*b, cl[k]); }
    sql = "SELECT " + cols + " FROM " + tableRef(*b, schema, table);
    if (given(a[4])) sql += " WHERE " + optText(a[4]);
    long long limit = optInt(a[5], -1);
    if (limit >= 0) sql += " LIMIT " + std::to_string(limit);
  }
  Table t;
  if (!b->query(sql, params, t, err)) return ctx.fail(err);
  long long chunk = optInt(a[8], -1);
  if (chunk > 0) {
    std::vector<Value> parts;
    for (size_t s = 0; s < t.rows.size(); s += static_cast<size_t>(chunk)) {
      Table p;
      p.cols = t.cols;
      p.rows.assign(t.rows.begin() + static_cast<long>(s), t.rows.begin() + static_cast<long>(std::min(t.rows.size(), s + static_cast<size_t>(chunk))));
      parts.push_back(tableObject(p));
    }
    out.push_back(Value(parts));
  } else {
    out.push_back(tableData(t));
  }
  if (nout > 1) {
    std::vector<std::string> boxes;
    if (!table.empty() && optBool(a[9], true)) {
      DbTable d;
      std::string e2;
      if (b->describe(schema, table, d, e2) && !d.comment.empty()) boxes.push_back(d.comment);
    }
    std::vector<std::string> tl, vl;
    std::string e3;
    b->tables(schema, tl, vl, e3);
    out.push_back(makeObject("NcReadInfo", {{"cols", textList(t.cols)}, {"schema", tableSchema(t)}, {"rows", Value(static_cast<double>(t.rows.size()))},
                                            {"sql", Value(sql)}, {"table", Value(table)}, {"tables", textList(tl)}, {"boxes", textList(boxes)}}));
  }
  ev.ok = true;
}

Value queryObject(const std::string &fmt, const std::string &uri, const std::string &sql, const Table &t) {
  return tableObject(t, {{"sql", Value(sql)}, {"uri", Value(uri)}, {"format", Value(fmt)}}, "NcDbQuery");
}

const size_t kEagerRows = 100000;

Value loadDb(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string uri, err;
  if (!numpy::argText(a, 0, ctx, uri)) return Value(0.0);
  EventScope ev("load_" + fmt, fmt == "sqlite" ? uri : "(database)");
  auto b = openBackend(fmt, uri, err);
  if (!b) { ctx.fail(err); return Value(0.0); }
  std::string schema = defaultSchema(fmt, a[1]);
  std::vector<std::string> tl, vl;
  if (!b->tables(schema, tl, vl, err)) { ctx.fail(err); return Value(0.0); }
  Fields f;
  std::vector<std::string> boxes;
  for (const auto &name : tl) {
    DbTable d;
    if (!b->describe(schema, name, d, err)) { ctx.fail(err); return Value(0.0); }
    Fields tf;
    Fields types, fks;
    std::vector<std::string> cols, pk;
    for (const auto &c : d.cols) {
      cols.push_back(c.name);
      types[c.name] = Value(c.type);
      if (c.pk) pk.push_back(c.name);
      if (!c.references.empty()) fks[c.name] = Value(c.references);
    }
    double n = b->count(schema, name, err);
    err.clear();
    if (n >= 0 && n <= kEagerRows) { // small tables: columns are fields (D.users.email)
      Table t;
      if (b->query("SELECT * FROM " + tableRef(*b, schema, name), {}, t, err))
        for (size_t c = 0; c < t.cols.size(); c++) { std::string fnm = fieldName(t.cols[c]); if (!fnm.empty() && !tf.count(fnm)) tf[fnm] = tableColumn(t, c); }
      err.clear();
    }
    tf["name"] = Value(name);
    tf["cols"] = textList(cols);
    tf["types"] = Value(types);
    tf["pk"] = textList(pk);
    tf["fk"] = Value(fks);
    tf["rows"] = Value(n);
    tf["comment"] = Value(d.comment);
    tf["uri"] = Value(uri);
    tf["format"] = Value(fmt);
    tf["schema_name"] = Value(schema);
    if (!d.comment.empty()) boxes.push_back(name + ": " + d.comment);
    std::string fname = fieldName(name);
    if (!fname.empty()) f[fname] = makeObject("NcDbTable", tf);
  }
  f["tables"] = textList(tl);
  f["views"] = textList(vl);
  f["schemas"] = textList({schema.empty() ? std::string("main") : schema});
  f["boxes"] = textList(boxes);
  f["uri"] = Value(uri);
  f["format"] = Value(fmt);
  f["schema_name"] = Value(schema);
  ev.ok = true;
  return makeObject("NcDatabase", std::move(f));
}

bool rerun(const Value &obj, const std::string &sql, const std::vector<Value> &params, Value &out, std::string &err) {
  const Value *uri = field(obj, "uri"), *fmt = field(obj, "format");
  if (!uri || !fmt) { err = "this object is not connected to a database"; return false; }
  auto b = openBackend(optText(*fmt), optText(*uri), err);
  if (!b) return false;
  Table t;
  if (!b->query(sql, params, t, err)) return false;
  out = queryObject(optText(*fmt), optText(*uri), sql, t);
  return true;
}

std::string baseSql(const Value &obj) {
  if (const Value *s = field(obj, "sql")) return optText(*s);
  const Value *n = field(obj, "name"), *fmt = field(obj, "format"), *sc = field(obj, "schema_name");
  std::string f = fmt ? optText(*fmt) : "sqlite", schema = sc ? optText(*sc) : "", table = n ? optText(*n) : "";
  if (f == "mysql") return "SELECT * FROM `" + table + "`";
  return "SELECT * FROM " + (schema.empty() || f == "sqlite" ? "" : sqlIdent(schema) + ".") + sqlIdent(table);
}

Value filterMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string where, err;
  if (!numpy::argText(a, 1, ctx, where)) return Value(0.0);
  std::string sql = baseSql(a[0]);
  // a LIMIT stays last
  std::string limitPart;
  size_t lim = lower(sql).rfind(" limit ");
  if (lim != std::string::npos) { limitPart = sql.substr(lim); sql = sql.substr(0, lim); }
  sql += lower(sql).find(" where ") == std::string::npos ? " WHERE " + where : " AND (" + where + ")";
  Value out;
  if (!rerun(a[0], sql + limitPart, {}, out, err)) { ctx.fail(err); return Value(0.0); }
  return out;
}

Value limitMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string err;
  long long n = optInt(a[1], -1);
  if (n < 0) { ctx.fail("limit(n) needs a count >= 0"); return Value(0.0); }
  std::string sql = baseSql(a[0]);
  size_t lim = lower(sql).rfind(" limit ");
  if (lim != std::string::npos) sql = sql.substr(0, lim);
  Value out;
  if (!rerun(a[0], sql + " LIMIT " + std::to_string(n), {}, out, err)) { ctx.fail(err); return Value(0.0); }
  return out;
}

Value queryMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string sql, err;
  if (!numpy::argText(a, 1, ctx, sql)) return Value(0.0);
  std::vector<Value> params;
  if (a.size() > 2 && given(a[2])) {
    if (a[2].isArray) for (size_t i = 0; i < a[2].length(); i++) params.push_back(a[2].at(i));
    else if (a[2].isMatrix) for (size_t c = 0; c < a[2].cols(); c++) params.push_back(a[2].at(0, c));
    else params.push_back(a[2]);
  }
  Value out;
  if (!rerun(a[0], sql, params, out, err)) { ctx.fail(err); return Value(0.0); }
  return out;
}

Value colMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string col, err;
  if (!numpy::argText(a, 1, ctx, col)) return Value(0.0);
  const Value *fmt = field(a[0], "format");
  std::string f = fmt ? optText(*fmt) : "sqlite";
  std::string sql = baseSql(a[0]);
  std::string q = f == "mysql" ? "`" + col + "`" : sqlIdent(col);
  size_t star = sql.find('*');
  if (star != std::string::npos) sql.replace(star, 1, q);
  Value out;
  if (!rerun(a[0], sql, {}, out, err)) { ctx.fail(err); return Value(0.0); }
  const Value *data = field(out, fieldName(col));
  return data ? *data : out;
}

// Mixed NC matrix literals keep numbers as text; a column whose every cell
// reads as a number is stored as numbers.
void numericColumns(Table &t) {
  for (size_t c = 0; c < t.cols.size(); c++) {
    bool any = false, all = true;
    for (const auto &r : t.rows) {
      if (!r[c].isText) continue;
      const std::string s = r[c].text();
      char *e = nullptr;
      std::strtod(s.c_str(), &e);
      if (s.empty() || !e || *e) { all = false; break; }
      any = true;
    }
    if (!any || !all) continue;
    for (auto &r : t.rows)
      if (r[c].isText) r[c] = Value(std::strtod(r[c].text().c_str(), nullptr));
  }
}

// save_<db>(uri, data, table, schema, mode, pk, conflict_cols, index, batch, dtype, boxes)
Value saveDb(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string uri, err;
  if (!numpy::argText(a, 0, ctx, uri)) return Value(0.0);
  EventScope ev("save_" + fmt, fmt == "sqlite" ? uri : "(database)");
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  WriteRequest req;
  if (!valueToTable(a[1], req.data, err, true)) return fail(err);
  if (req.data.rows.empty() && req.data.cols.empty()) return fail("nothing to save - data is empty");
  numericColumns(req.data);
  req.table = optText(a[2], "results");
  req.schema = defaultSchema(fmt, a[3]);
  req.mode = lower(optText(a[4], "append"));
  if (req.mode != "append" && req.mode != "replace" && req.mode != "upsert" && req.mode != "fail")
    return fail("mode must be \"append\", \"replace\", \"upsert\" or \"fail\"");
  req.pk = optTextList(a[5]);
  req.conflict = optTextList(a[6]);
  req.index = optTextList(a[7]);
  req.batch = static_cast<size_t>(std::max(1LL, optInt(a[8], 5000)));
  if (a[9].isDict) req.dtype = a[9].dict();
  req.comment = optText(a[10], "");
  auto b = openBackend(fmt, uri, err);
  if (!b) return fail(err);
  if (!b->write(req, err)) return fail(err);
  emitEvent({"saved", "save_" + fmt, fmt == "sqlite" ? uri : req.table, 1.0, std::to_string(req.data.rows.size()) + " rows"});
  ev.ok = true;
  return Value(static_cast<double>(req.data.rows.size()));
}

} // namespace

void registerDatabases(Registry &reg) {
  struct D { const char *fmt, *example; };
  const D dbs[] = {{"sqlite", "F1.sqlite"}, {"postgresql", "postgres://user:pass@localhost:5432/db"},
                   {"mysql", "mysql://user:pass@localhost:3306/db"}, {"oracle", "oracle://user:pass@localhost:1521/orcl"},
                   {"sqlserver", "mssql://user:pass@localhost:1433/db"}};
  for (const D &d : dbs) {
    const std::string f = d.fmt;
    addMulti(reg, "read_" + f,
             "uri, table=\"\", schema=\"\", cols=\"\", where=\"\", limit=-1, query=\"\", params=\"\", chunk=-1, box=true",
             "read rows from " + f + " (" + d.example + "): a table, or a query", "pandas.read_sql", 2,
             [f](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readDb(f, a, nout, out, ctx); });
    addFn(reg, "load_" + f, "uri, schema=\"\"",
          "connect to " + f + " as a catalog object (D.tables, D.users.cols, D.users.filter(\"age > 25\").limit(100), D.query(sql))",
          "sqlalchemy.inspect", [f](const std::vector<Value> &a, CallContext &ctx) { return loadDb(f, a, ctx); });
    addFn(reg, "save_" + f,
          "uri, data, table=\"results\", schema=\"\", mode=\"append\", pk=\"\", conflict_cols=\"\", index=\"\", batch=5000, dtype=\"\", boxes=\"\"",
          "write a table to " + f + " (creates the table; append / replace / upsert / fail)", "pandas.DataFrame.to_sql",
          [f](const std::vector<Value> &a, CallContext &ctx) { return saveDb(f, a, ctx); });
  }
  for (const char *cls : {"NcDbTable", "NcDbQuery"}) {
    const std::string c = cls;
    addFn(reg, c + ".filter", "T, where", "rows matching an SQL condition (chainable: .filter(...).limit(n))", "sqlalchemy Query.filter", filterMethod);
    addFn(reg, c + ".limit", "T, n", "at most n rows (chainable)", "sqlalchemy Query.limit", limitMethod);
    addFn(reg, c + ".col", "T, name", "one column of the table / query", "-", colMethod);
  }
  addFn(reg, "NcDatabase.query", "D, sql, params=\"\"", "run an SQL query on a loaded database", "Connection.execute", queryMethod);
}

} // namespace io
} // namespace nc
