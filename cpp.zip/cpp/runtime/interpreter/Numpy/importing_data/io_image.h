// Raster images shared by png, jpg/jpeg, tiff, bmp, gif, dicom (phase 2) and
// tif/geotiff, avi/mov MJPEG frames (phase 3).
#ifndef NC_IO_IMAGE_H
#define NC_IO_IMAGE_H

#include <array>
#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct Image {
  size_t width = 0, height = 0, channels = 1; // 1 gray, 2 gray+alpha, 3 RGB, 4 RGBA
  int bitDepth = 8;                            // 8, 16, 32
  bool isFloat = false;                        // samples are floating point
  std::vector<double> px;                      // row-major, channels interleaved
  double dpiX = 0, dpiY = 0;
  std::vector<std::pair<std::string, std::string>> text; // tEXt / COM / ImageDescription ...
  std::string colorSpace = "sRGB";
  std::string icc;
  Fields exif;
  Fields extra;               // format specific (DICOM tags, GeoTIFF keys ...)
  std::vector<Image> frames;  // further pages / frames (frame 0 is *this)
  double delay = 0;           // seconds per frame (gif)
  int orientation = 1;        // EXIF orientation (already applied when read)

  double maxValue() const { return isFloat ? 1.0 : (bitDepth >= 16 ? 65535.0 : 255.0); }
  double at(size_t x, size_t y, size_t c) const { return px[(y * width + x) * channels + c]; }
};

// Codecs (io_png.cpp, io_jpeg.cpp, io_tiff.cpp, io_bmpgif.cpp, io_dicom.cpp).
bool decodePng(const std::string &bytes, Image &img, std::string &err);
std::string encodePng(const Image &img, int level, bool palette, const std::vector<double> &transparent);
bool decodeJpeg(const std::string &bytes, Image &img, std::string &err);
std::string encodeJpeg(const Image &img, int quality, bool subsample420, bool progressive);
bool decodeTiff(const std::string &bytes, Image &img, std::string &err, bool allFrames);
struct TiffOptions {
  std::string codec = "lzw";    // none, lzw, deflate, packbits
  size_t tile = 0;              // 0 = strips
  bool overviews = false;       // reduced-resolution pages (COG style)
  bool bigtiff = false;
};
std::string encodeTiff(const std::vector<const Image *> &pages, const TiffOptions &opt);
bool decodeBmp(const std::string &bytes, Image &img, std::string &err);
std::string encodeBmp(const Image &img);
bool decodeGif(const std::string &bytes, Image &img, std::string &err);
std::string encodeGif(const std::vector<const Image *> &frames, double fps, int loop, size_t maxColors);
bool decodeDicom(const std::string &bytes, Image &img, std::string &err, bool hu);
std::string encodeDicom(const Image &img, const Fields &patient, bool anonymize);

// Conversions.
Value imageToValue(const Image &img, bool asFloat);    // (H,W) or (H,W,C)
bool valueToImage(const Value &v, Image &img, std::string &err);
Image convertChannels(const Image &img, const std::string &mode); // "gray", "rgb", "rgba"
Image cropImage(const Image &img, size_t x, size_t y, size_t w, size_t h);
Image resizeImage(const Image &img, size_t w, size_t h); // bilinear
Image to8bit(const Image &img);
void applyOrientation(Image &img);                   // EXIF 1..8 -> upright
// Median-cut palette (<= maxColors) for an 8-bit RGB(A) image: indices + palette.
void quantize(const Image &img8, size_t maxColors, std::vector<uint8_t> &indices,
              std::vector<std::array<uint8_t, 4>> &palette);

} // namespace io
} // namespace nc

#endif // NC_IO_IMAGE_H
