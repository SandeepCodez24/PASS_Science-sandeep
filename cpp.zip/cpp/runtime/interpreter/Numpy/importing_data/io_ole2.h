// Compound File Binary (OLE2, MS-CFB): the container of .xls workbooks and
// vbaProject.bin. Reading v3/v4 files; writing v3 files with streams in the
// root storage (enough for .xls).
#ifndef NC_IO_OLE2_H
#define NC_IO_OLE2_H

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace nc {
namespace io {

struct Ole2Reader {
  struct Entry {
    std::string name; // UTF-8
    int type = 0;     // 1 storage, 2 stream, 5 root
    uint32_t start = 0;
    uint64_t size = 0;
    int left = -1, right = -1, child = -1;
    int parent = -1;
  };
  std::vector<Entry> entries;
  bool open(const std::string &bytes, std::string &err);
  // Path with '/', e.g. "Workbook" or "VBA/dir". Case-insensitive.
  bool read(const std::string &path, std::string &out) const;
  std::vector<std::string> list(const std::string &storage) const; // names of the children

private:
  const std::string *data_ = nullptr;
  uint32_t sectorSize_ = 512, miniCutoff_ = 4096;
  std::vector<uint32_t> fat_, minifat_;
  std::string ministream_;
  std::string chain(uint32_t start, uint64_t size, bool mini) const;
  int find(const std::string &path) const;
};

// Streams written into the root storage of a new v3 compound file.
std::string writeOle2(const std::vector<std::pair<std::string, std::string>> &streams);

bool isOle2(const std::string &bytes);

} // namespace io
} // namespace nc

#endif // NC_IO_OLE2_H
