// MATLAB MAT-file Level 5 (v5 / v7 compressed) model, reader and writer.
// v7.3 files are HDF5 and go through io_hdf5 (phase 3). Also used by .fig.
#ifndef NC_IO_MAT_H
#define NC_IO_MAT_H

#include <string>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct MatNode {
  enum Cls { Cell = 1, Struct = 2, Object = 3, Char = 4, Sparse = 5, Double = 6, Single = 7, Int8 = 8, UInt8 = 9,
             Int16 = 10, UInt16 = 11, Int32 = 12, UInt32 = 13, Int64 = 14, UInt64 = 15, Opaque = 17 };
  std::string name;
  int cls = Double;
  std::vector<size_t> dims{0, 0};
  bool complex = false, logical = false, global = false;
  std::vector<double> re, im;           // column-major numbers
  std::string text;                     // Char: rows joined by '\n'
  std::vector<MatNode> cells;           // Cell: column-major
  std::vector<std::string> fieldNames;  // Struct / Object
  std::vector<std::vector<MatNode>> elems; // Struct: [element][field]
  std::string className;                // Object
  size_t count() const;
};

struct MatFile {
  std::string header; // 116-byte text
  std::string version = "v5";
  std::vector<MatNode> vars;
};

bool readMatV5(const std::string &bytes, MatFile &mf, std::string &err);
std::string writeMatV5(const MatFile &mf, bool compress, int level);

// MatNode <-> NC values. `objects`: structs become NcMatStruct objects (dot
// access) instead of dicts.
Value matToValue(const MatNode &n, bool squeeze, bool objects);
bool valueToMat(const std::string &name, const Value &v, MatNode &out, std::string &err);
std::string matClassName(const MatNode &n);

} // namespace io
} // namespace nc

#endif // NC_IO_MAT_H
