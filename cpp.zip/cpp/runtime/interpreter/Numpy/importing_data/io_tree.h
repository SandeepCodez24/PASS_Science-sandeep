// An ordered document tree shared by the JSON, YAML, INI and XML readers and
// writers: objects keep their key order (NC dicts do not), so a file read
// and saved again keeps its layout. Also: JSON text <-> tree, tree <-> NC
// values, and JSONPath queries.
#ifndef NC_IO_TREE_H
#define NC_IO_TREE_H

#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct TreeNode {
  enum Type { Null, Bool, Number, String, Array, Object };
  Type type = Null;
  bool b = false;
  double num = 0;
  std::string str;
  std::vector<TreeNode> items;                         // Array
  std::vector<std::pair<std::string, TreeNode>> keys;  // Object, in file order

  static TreeNode ofString(const std::string &s) {
    TreeNode n;
    n.type = String;
    n.str = s;
    return n;
  }
  static TreeNode ofNumber(double d) {
    TreeNode n;
    n.type = Number;
    n.num = d;
    return n;
  }
  static TreeNode ofBool(bool v) {
    TreeNode n;
    n.type = Bool;
    n.b = v;
    return n;
  }
  const TreeNode *find(const std::string &key) const;
  TreeNode *find(const std::string &key);
};

// JSON text -> tree. `lenient` adds JSON5: // and /* */ comments, trailing
// commas, 'single quotes', unquoted keys, NaN / Infinity, hex numbers.
bool parseJson(const std::string &text, bool lenient, TreeNode &out, std::string &err);
// One JSON value per line (NDJSON / JSON Lines) -> array.
bool parseJsonLines(const std::string &text, bool lenient, TreeNode &out, std::string &err);

struct JsonStyle {
  int indent = 2;         // 0 = one line
  bool sortKeys = false;
  std::string nanMode = "null"; // "null" or "str"
};
std::string writeJson(const TreeNode &n, const JsonStyle &style);

// Tree -> plain NC value (read_*): objects -> dicts, numeric arrays ->
// arrays/matrices, other arrays -> cell arrays, null -> NaN.
Value treeToValue(const TreeNode &n);
// Tree -> objects for dot access (load_*): every JSON object becomes an
// object of class `cls` whose fields are its keys (as identifiers) plus
// key_order (the original keys, in order).
Value treeToObject(const TreeNode &n, const std::string &cls);
// NC value -> tree (save_*). Objects with key_order keep that order;
// NcTable objects become arrays of records.
TreeNode valueToTree(const Value &v);

// JSONPath subset: $ . .. * [n] [-n] [a:b] [n,m] ['k'] [?(@.k op v)]
// (op: == != < <= > >=, or just @.k for "has k"; && joins tests).
bool jsonPath(const TreeNode &root, const std::string &path, std::vector<const TreeNode *> &out,
              bool &single, std::string &err);

// An array of objects -> table (columns in first-seen order).
bool treeToTable(const TreeNode &n, Table &t, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_TREE_H
