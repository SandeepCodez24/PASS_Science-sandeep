// CATEGORY 13 - binary files: read_/load_/save_ bin and custom.
//
// dtype strings
//   primitive   int8 uint8 int16 uint16 int32 uint32 int64 uint64 float16
//               float32 float64 complex64 complex128 bool char
//               (NumPy codes too: i1 u1 i2 u2 i4 u4 i8 u8 f2 f4 f8 c8 c16 ?
//               b B h H i I q Q e f d, and "16s" / "S16" for 16-byte text)
//   record      "i4,f8,16s" or with field names "id:i4,val:f8,name:16s"
//               (fields are f0, f1, ... when unnamed)
// .custom files carry their layout in a companion "<file>.schema.json" (or
// an embedded first line "NCSCHEMA {json}"), so read_custom(file) needs no
// arguments.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <limits>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_tree.h"

namespace nc {
namespace io {
namespace {

struct Field {
  std::string name;
  char kind = 'u'; // i u f c b s
  size_t size = 1; // bytes
  size_t offset = 0;
};

struct Layout {
  std::vector<Field> fields;
  size_t itemSize = 0;
  bool structured = false;
};

bool primitive(const std::string &codeIn, Field &f) {
  std::string c = trim(codeIn);
  std::string l = lower(c);
  struct P {
    const char *name;
    char kind;
    size_t size;
  };
  static const P table[] = {
      {"int8", 'i', 1},    {"i1", 'i', 1},      {"b", 'i', 1},      {"uint8", 'u', 1},  {"u1", 'u', 1},
      {"byte", 'u', 1},    {"int16", 'i', 2},   {"i2", 'i', 2},     {"h", 'i', 2},      {"uint16", 'u', 2},
      {"u2", 'u', 2},      {"int32", 'i', 4},   {"i4", 'i', 4},     {"i", 'i', 4},      {"uint32", 'u', 4},
      {"u4", 'u', 4},      {"int64", 'i', 8},   {"i8", 'i', 8},     {"q", 'i', 8},      {"uint64", 'u', 8},
      {"u8", 'u', 8},      {"float16", 'f', 2}, {"f2", 'f', 2},     {"e", 'f', 2},      {"float32", 'f', 4},
      {"f4", 'f', 4},      {"f", 'f', 4},       {"single", 'f', 4}, {"float64", 'f', 8}, {"f8", 'f', 8},
      {"d", 'f', 8},       {"double", 'f', 8},  {"complex64", 'c', 8}, {"c8", 'c', 8}, {"complex128", 'c', 16},
      {"c16", 'c', 16},    {"bool", 'b', 1},    {"?", 'b', 1},      {"char", 's', 1},   {"c", 's', 1}};
  // Case matters for the one-letter struct codes (B = uint8, b = int8 ...).
  static const P upper[] = {{"B", 'u', 1}, {"H", 'u', 2}, {"I", 'u', 4}, {"Q", 'u', 8}};
  for (const P &p : upper)
    if (c == p.name) {
      f.kind = p.kind;
      f.size = p.size;
      return true;
    }
  for (const P &p : table)
    if (l == p.name) {
      f.kind = p.kind;
      f.size = p.size;
      return true;
    }
  // 16s / S16 / a16 / U? (bytes text)
  if (l.size() > 1 && (l.back() == 's' || l[0] == 's' || l[0] == 'a')) {
    std::string digits = l.back() == 's' ? l.substr(0, l.size() - 1) : l.substr(1);
    if (!digits.empty() && std::all_of(digits.begin(), digits.end(), ::isdigit)) {
      f.kind = 's';
      f.size = static_cast<size_t>(std::atoll(digits.c_str()));
      return f.size > 0;
    }
  }
  return false;
}

bool parseLayout(const std::string &dtypeIn, size_t align, Layout &out, std::string &err,
                 std::string *endianOut = nullptr) {
  out = Layout();
  std::string dtype = trim(dtypeIn);
  if (!dtype.empty() && (dtype[0] == '<' || dtype[0] == '>' || dtype[0] == '=')) {
    if (endianOut)
      *endianOut = dtype[0] == '>' ? "big" : "little";
    dtype = dtype.substr(1);
  }
  size_t start = 0;
  size_t maxAlign = 1;
  while (start <= dtype.size()) {
    size_t comma = dtype.find(',', start);
    if (comma == std::string::npos)
      comma = dtype.size();
    std::string part = trim(dtype.substr(start, comma - start));
    start = comma + 1;
    if (part.empty())
      continue;
    Field f;
    size_t colon = part.find(':');
    std::string code = part;
    if (colon != std::string::npos) {
      f.name = trim(part.substr(0, colon));
      code = trim(part.substr(colon + 1));
    }
    if (!code.empty() && (code[0] == '<' || code[0] == '>')) {
      if (endianOut)
        *endianOut = code[0] == '>' ? "big" : "little";
      code = code.substr(1);
    }
    if (!primitive(code, f)) {
      err = "unknown dtype '" + code + "' (use e.g. float64, int16, uint8, \"i4,f8,16s\")";
      return false;
    }
    if (f.name.empty())
      f.name = "f" + std::to_string(out.fields.size());
    size_t natural = f.kind == 's' ? 1 : f.kind == 'c' ? f.size / 2 : f.size;
    size_t a = std::min(align, natural);
    if (a > 1)
      out.itemSize = (out.itemSize + a - 1) / a * a;
    maxAlign = std::max(maxAlign, a);
    f.offset = out.itemSize;
    out.itemSize += f.size;
    out.fields.push_back(f);
  }
  if (out.fields.empty()) {
    err = "empty dtype";
    return false;
  }
  if (maxAlign > 1)
    out.itemSize = (out.itemSize + maxAlign - 1) / maxAlign * maxAlign;
  out.structured = out.fields.size() > 1 || dtype.find(':') != std::string::npos;
  return true;
}

bool hostLittle() {
  uint16_t x = 1;
  unsigned char b;
  std::memcpy(&b, &x, 1);
  return b == 1;
}

double halfToDouble(uint16_t h) {
  int sign = (h >> 15) & 1, exp = (h >> 10) & 0x1F, man = h & 0x3FF;
  double v;
  if (exp == 0)
    v = std::ldexp(man, -24);
  else if (exp == 31)
    v = man ? std::nan("") : HUGE_VAL;
  else
    v = std::ldexp(man + 1024, exp - 25);
  return sign ? -v : v;
}

uint16_t doubleToHalf(double d) {
  float f = static_cast<float>(d);
  uint32_t x;
  std::memcpy(&x, &f, 4);
  uint32_t sign = (x >> 16) & 0x8000;
  int exp = static_cast<int>((x >> 23) & 0xFF) - 127 + 15;
  uint32_t man = x & 0x7FFFFF;
  if (std::isnan(d))
    return static_cast<uint16_t>(sign | 0x7E00);
  if (exp >= 31)
    return static_cast<uint16_t>(sign | 0x7C00);
  if (exp <= 0) {
    if (exp < -10)
      return static_cast<uint16_t>(sign);
    man |= 0x800000;
    return static_cast<uint16_t>(sign | (man >> (14 - exp)));
  }
  return static_cast<uint16_t>(sign | (exp << 10) | (man >> 13));
}

void ordered(const unsigned char *src, size_t n, bool big, unsigned char *dst) {
  bool swap = big == hostLittle();
  for (size_t k = 0; k < n; k++)
    dst[k] = swap ? src[n - 1 - k] : src[k];
}

Value decodeField(const unsigned char *p, const Field &f, bool big) {
  unsigned char b[16];
  if (f.kind == 's') {
    std::string s(reinterpret_cast<const char *>(p), f.size);
    size_t z = s.find('\0');
    if (z != std::string::npos)
      s.resize(z);
    return Value(s);
  }
  if (f.kind == 'c') {
    size_t h = f.size / 2;
    ordered(p, h, big, b);
    ordered(p + h, h, big, b + 8);
    double re, im;
    if (h == 4) {
      float a, c;
      std::memcpy(&a, b, 4);
      std::memcpy(&c, b + 8, 4);
      re = a;
      im = c;
    } else {
      std::memcpy(&re, b, 8);
      std::memcpy(&im, b + 8, 8);
    }
    return Value::complexNumber(re, im);
  }
  ordered(p, f.size, big, b);
  switch (f.kind) {
    case 'b': return Value::boolean(b[0] != 0);
    case 'i':
      if (f.size == 1) { int8_t v; std::memcpy(&v, b, 1); return Value(static_cast<double>(v)); }
      if (f.size == 2) { int16_t v; std::memcpy(&v, b, 2); return Value(static_cast<double>(v)); }
      if (f.size == 4) { int32_t v; std::memcpy(&v, b, 4); return Value(static_cast<double>(v)); }
      { int64_t v; std::memcpy(&v, b, 8); return Value(static_cast<double>(v)); }
    case 'u':
      if (f.size == 1) return Value(static_cast<double>(b[0]));
      if (f.size == 2) { uint16_t v; std::memcpy(&v, b, 2); return Value(static_cast<double>(v)); }
      if (f.size == 4) { uint32_t v; std::memcpy(&v, b, 4); return Value(static_cast<double>(v)); }
      { uint64_t v; std::memcpy(&v, b, 8); return Value(static_cast<double>(v)); }
    case 'f':
      if (f.size == 2) { uint16_t v; std::memcpy(&v, b, 2); return Value(halfToDouble(v)); }
      if (f.size == 4) { float v; std::memcpy(&v, b, 4); return Value(static_cast<double>(v)); }
      { double v; std::memcpy(&v, b, 8); return Value(v); }
  }
  return Value(0.0);
}

bool encodeField(const Value &v, const Field &f, bool big, unsigned char *out, std::string &err) {
  unsigned char b[16] = {0};
  if (f.kind == 's') {
    std::string s = cellText(v);
    if (s.size() > f.size) {
      err = "text '" + s + "' is longer than its " + std::to_string(f.size) + "-byte field " + f.name;
      return false;
    }
    std::memset(out, 0, f.size);
    std::memcpy(out, s.data(), s.size());
    return true;
  }
  double d = v.number;
  if (v.isText) {
    // A mixed NC literal ["id"; 1] keeps its numbers as text.
    Value parsed = parseCell(v.text(), {"NaN", "nan"});
    if (!numpy::isPlainNumber(parsed) || parsed.isText) {
      err = "field " + f.name + " is numeric but the value is text '" + v.text() + "'";
      return false;
    }
    d = parsed.number;
  }
  if (f.kind == 'c') {
    size_t h = f.size / 2;
    double re = d, im = v.isComplex ? v.imag : 0.0;
    if (h == 4) {
      float a = static_cast<float>(re), c = static_cast<float>(im);
      std::memcpy(b, &a, 4);
      std::memcpy(b + 8, &c, 4);
    } else {
      std::memcpy(b, &re, 8);
      std::memcpy(b + 8, &im, 8);
    }
    ordered(b, h, big, out);
    ordered(b + 8, h, big, out + h);
    return true;
  }
  if (f.kind == 'i' || f.kind == 'u' || f.kind == 'b') {
    if (std::isnan(d)) {
      err = "NaN cannot be stored in integer field " + f.name;
      return false;
    }
    double r = std::round(d);
    double lo = 0, hi = 0;
    if (f.kind == 'b') { lo = 0; hi = 1; }
    else if (f.kind == 'u') { lo = 0; hi = std::ldexp(1.0, static_cast<int>(8 * f.size)) - 1; }
    else { hi = std::ldexp(1.0, static_cast<int>(8 * f.size - 1)) - 1; lo = -hi - 1; }
    if (f.kind == 'b')
      r = d != 0 ? 1 : 0;
    if (r < lo || r > hi) {
      err = numberText(d) + " does not fit " + (f.kind == 'u' ? "uint" : "int") + std::to_string(8 * f.size) +
            " (range " + numberText(lo) + " .. " + numberText(hi) + ") - no silent overflow";
      return false;
    }
    if (f.kind == 'u' || f.kind == 'b') {
      uint64_t x = static_cast<uint64_t>(r);
      std::memcpy(b, &x, 8);
    } else {
      int64_t x = static_cast<int64_t>(r);
      std::memcpy(b, &x, 8);
    }
    if (!hostLittle()) {
      err = "big-endian hosts are not supported";
      return false;
    }
    ordered(b, f.size, big, out);
    return true;
  }
  if (f.size == 2) {
    uint16_t h = doubleToHalf(d);
    std::memcpy(b, &h, 2);
  } else if (f.size == 4) {
    if (std::isfinite(d) && std::fabs(d) > std::numeric_limits<float>::max()) {
      err = numberText(d) + " does not fit float32";
      return false;
    }
    float x = static_cast<float>(d);
    std::memcpy(b, &x, 4);
  } else {
    std::memcpy(b, &d, 8);
  }
  ordered(b, f.size, big, out);
  return true;
}

// Logical row-major values -> NC value of `shape` (array / matrix / N-D).
Value shaped(const std::vector<Value> &vals, const std::vector<size_t> &shape) {
  bool numeric = true;
  for (const auto &v : vals)
    if (!isNumberCell(v))
      numeric = false;
  if (shape.size() <= 1) {
    if (numeric) {
      std::vector<double> d;
      for (const auto &v : vals)
        d.push_back(v.number);
      return numpy::makeArray(d);
    }
    return Value(vals);
  }
  if (shape.size() == 2) {
    if (numeric) {
      std::vector<std::vector<double>> m(shape[0], std::vector<double>(shape[1]));
      for (size_t r = 0; r < shape[0]; r++)
        for (size_t c = 0; c < shape[1]; c++)
          m[r][c] = vals[r * shape[1] + c].number;
      return numpy::makeMatrix(m);
    }
    std::vector<std::vector<Value>> m(shape[0], std::vector<Value>(shape[1]));
    for (size_t r = 0; r < shape[0]; r++)
      for (size_t c = 0; c < shape[1]; c++)
        m[r][c] = vals[r * shape[1] + c];
    return Value(m);
  }
  // pages of column-major rows x cols, pages in row-major order
  const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1];
  std::vector<double> buf(vals.size());
  std::vector<Value> cells(vals.size());
  for (size_t k = 0; k < vals.size(); k++) {
    size_t page = k / (rows * cols), within = k % (rows * cols);
    size_t r = within / cols, c = within % cols;
    size_t flat = page * rows * cols + c * rows + r;
    if (numeric)
      buf[flat] = vals[k].number;
    else
      cells[flat] = vals[k];
  }
  return numeric ? Value::ndPacked(shape, buf, false) : Value::ndFromCells(shape, cells);
}

bool shapeOf(const Value &v, std::vector<size_t> &shape, std::string &err) {
  shape.clear();
  if (!given(v))
    return true;
  for (double d : optNumbers(v)) {
    if (d < 0 || d != std::floor(d)) {
      err = "shape must hold whole numbers, e.g. [1000, 4]";
      return false;
    }
    shape.push_back(static_cast<size_t>(d));
  }
  return true;
}

std::string printable(const std::string &bytes) {
  std::string out;
  for (unsigned char c : bytes) {
    if (c == 0)
      break;
    out.push_back((c >= 32 && c < 127) || c == '\n' || c == '\t' ? static_cast<char>(c) : '.');
  }
  return out;
}

Value byteArray(const std::string &bytes, size_t from = 0, size_t to = std::string::npos) {
  to = std::min(to, bytes.size());
  std::vector<double> v;
  v.reserve(to > from ? to - from : 0);
  for (size_t k = from; k < to; k++)
    v.push_back(static_cast<unsigned char>(bytes[k]));
  return numpy::makeArray(v);
}

// "MAGIC\x00\x01" text with \xNN escapes, or a byte array -> bytes.
std::string headerBytes(const Value &v) {
  if (!given(v))
    return "";
  if (v.isText) {
    const std::string &s = v.text();
    std::string out;
    for (size_t i = 0; i < s.size(); i++) {
      if (s[i] == '\\' && i + 3 < s.size() && s[i + 1] == 'x' && std::isxdigit(static_cast<unsigned char>(s[i + 2])) &&
          std::isxdigit(static_cast<unsigned char>(s[i + 3]))) {
        out.push_back(static_cast<char>(std::strtol(s.substr(i + 2, 2).c_str(), nullptr, 16)));
        i += 3;
      } else {
        out.push_back(s[i]);
      }
    }
    return out;
  }
  std::string out;
  for (double d : optNumbers(v))
    out.push_back(static_cast<char>(static_cast<int>(d) & 0xFF));
  return out;
}

struct Decoded {
  Layout layout;
  std::vector<std::vector<Value>> records; // one row per record
  std::string header;
  size_t dataStart = 0;
};

// Decodes `count` records (-1 = all) starting at offset + box_bytes.
bool decode(const std::string &bytes, const std::string &dtype, long long offset, long long count,
            const std::string &endian, long long stride, long long boxBytes, Decoded &d, std::string &err, size_t align,
            const std::string &fn, const std::string &file) {
  std::string en = lower(endian);
  if (!parseLayout(dtype, align, d.layout, err, &en))
    return false;
  if (en != "little" && en != "big" && en != "native") {
    err = "endian must be \"little\" or \"big\"";
    return false;
  }
  const bool big = en == "big" || (en == "native" && !hostLittle());
  if (offset < 0 || boxBytes < 0 || static_cast<size_t>(offset + boxBytes) > bytes.size()) {
    err = "offset + box_bytes (" + std::to_string(offset + boxBytes) + ") is past the end of the " +
          std::to_string(bytes.size()) + "-byte file";
    return false;
  }
  d.header = bytes.substr(static_cast<size_t>(offset), static_cast<size_t>(boxBytes));
  d.dataStart = static_cast<size_t>(offset + boxBytes);
  const size_t avail = bytes.size() - d.dataStart;
  const size_t rec = stride > 0 ? static_cast<size_t>(stride) : d.layout.itemSize;
  if (rec < d.layout.itemSize) {
    err = "stride " + std::to_string(rec) + " is smaller than one record (" + std::to_string(d.layout.itemSize) + " bytes)";
    return false;
  }
  size_t n;
  if (count < 0) {
    if (stride <= 0 && avail % rec != 0) {
      err = "the data part (" + std::to_string(avail) + " bytes after offset+box_bytes) is not a whole number of " +
            std::to_string(rec) + "-byte " + dtype + " items - check dtype, offset and box_bytes";
      return false;
    }
    n = avail < d.layout.itemSize ? 0 : (avail - d.layout.itemSize) / rec + 1;
    if (avail == 0)
      n = 0;
  } else {
    n = static_cast<size_t>(count);
    if (n > 0 && (n - 1) * rec + d.layout.itemSize > avail) {
      err = "count=" + std::to_string(n) + " needs " + std::to_string((n - 1) * rec + d.layout.itemSize) +
            " bytes but only " + std::to_string(avail) + " follow offset+box_bytes";
      return false;
    }
  }
  d.records.reserve(n);
  const unsigned char *base = reinterpret_cast<const unsigned char *>(bytes.data()) + d.dataStart;
  for (size_t k = 0; k < n; k++) {
    if ((k & 0xFFFFF) == 0xFFFFF && reportProgress(fn, file, static_cast<double>(k) / n)) {
      err = "cancelled";
      return false;
    }
    std::vector<Value> row;
    row.reserve(d.layout.fields.size());
    for (const Field &f : d.layout.fields)
      row.push_back(decodeField(base + k * rec + f.offset, f, big));
    d.records.push_back(std::move(row));
  }
  return true;
}

Value decodedValue(const Decoded &d, const std::vector<size_t> &shape, std::vector<std::string> &cols,
                   std::string &err) {
  if (d.layout.structured) {
    Table t;
    for (const auto &f : d.layout.fields)
      t.cols.push_back(f.name);
    t.rows = d.records;
    cols = t.cols;
    return tableData(t);
  }
  std::vector<Value> vals;
  vals.reserve(d.records.size());
  for (const auto &r : d.records)
    vals.push_back(r[0]);
  if (!shape.empty()) {
    size_t prod = 1;
    for (size_t s : shape)
      prod *= s;
    if (prod != vals.size()) {
      err = "shape needs " + std::to_string(prod) + " items but " + std::to_string(vals.size()) + " were read";
      return Value(0.0);
    }
    return shaped(vals, shape);
  }
  bool complex = false;
  for (const auto &v : vals)
    if (v.isComplex)
      complex = true;
  if (complex)
    return Value(vals);
  return shaped(vals, {vals.size()});
}

// ---- schema for .custom -----------------------------------------------------

struct Schema {
  std::string dtype, endian;
  long long boxBytes = -1;
  long long align = 1;
  std::vector<size_t> shape;
  size_t embeddedLen = 0; // bytes of an embedded NCSCHEMA line
  bool found = false;
};

bool readSchema(const std::string &file, const std::string &bytes, Schema &s) {
  std::string json;
  if (bytes.rfind("NCSCHEMA ", 0) == 0) {
    size_t nl = bytes.find('\n');
    if (nl != std::string::npos) {
      json = bytes.substr(9, nl - 9);
      s.embeddedLen = nl + 1;
    }
  }
  std::string err;
  if (json.empty()) {
    std::string companion;
    if (!readFile(file + ".schema.json", companion, err))
      return false;
    json = companion;
  }
  TreeNode root;
  if (!parseJson(json, true, root, err) || root.type != TreeNode::Object)
    return false;
  s.found = true;
  if (const TreeNode *d = root.find("dtype"))
    s.dtype = d->str;
  if (const TreeNode *names = root.find("names"); names && names->type == TreeNode::Array && !s.dtype.empty()) {
    // "names": ["id","val"] + "dtype": "i4,f8" -> "id:i4,val:f8"
    std::string named;
    size_t k = 0, start = 0;
    while (start <= s.dtype.size()) {
      size_t c = s.dtype.find(',', start);
      if (c == std::string::npos)
        c = s.dtype.size();
      std::string part = trim(s.dtype.substr(start, c - start));
      if (part.find(':') == std::string::npos && k < names->items.size())
        part = names->items[k].str + ":" + part;
      named += (named.empty() ? "" : ",") + part;
      k++;
      start = c + 1;
    }
    s.dtype = named;
  }
  if (const TreeNode *e = root.find("endian"))
    s.endian = e->str;
  if (const TreeNode *b = root.find("box_bytes"))
    s.boxBytes = static_cast<long long>(b->num);
  if (const TreeNode *al = root.find("align"))
    s.align = static_cast<long long>(al->num);
  if (const TreeNode *sh = root.find("shape"))
    for (const auto &x : sh->items)
      s.shape.push_back(static_cast<size_t>(x.num));
  return true;
}

// read_<fmt>(file, dtype, shape, offset, count, endian, stride, box_bytes, align)
void readBinary(const std::string &fn, bool custom, const std::vector<Value> &a, size_t nout,
                std::vector<Value> &out, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev(fn, file);
  if (!readFile(file, bytes, err))
    return ctx.fail(err);
  std::string dtype = optText(a[1], custom ? "" : "uint8");
  std::string endian = optText(a[5], "little");
  long long offset = optInt(a[3], 0), boxBytes = optInt(a[7], 0);
  std::vector<size_t> shape;
  if (!shapeOf(a[2], shape, err))
    return ctx.fail(err);
  Schema schema;
  if (custom && readSchema(file, bytes, schema)) {
    if (dtype.empty())
      dtype = schema.dtype;
    if (!given(a[5]) || optText(a[5]) == "little")
      endian = schema.endian.empty() ? endian : schema.endian;
    if (!given(a[7]) || boxBytes == 0)
      boxBytes = schema.boxBytes >= 0 ? schema.boxBytes : boxBytes;
    if (shape.empty())
      shape = schema.shape;
    offset += static_cast<long long>(schema.embeddedLen);
  }
  if (dtype.empty())
    dtype = "uint8";
  Decoded d;
  long long align = optInt(a[8], 1);
  if (custom && schema.found && align == 1)
    align = schema.align;
  if (!decode(bytes, dtype, offset, optInt(a[4], -1), endian, optInt(a[6], 0), boxBytes, d, err, static_cast<size_t>(std::max(1LL, align)), fn, file))
    return ctx.fail(err);
  std::vector<std::string> cols;
  Value v = decodedValue(d, shape, cols, err);
  if (!err.empty())
    return ctx.fail(err);
  out.push_back(v);
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(cols);
    info["header"] = byteArray(d.header);
    info["boxes"] = textList(d.header.empty() ? std::vector<std::string>{} : std::vector<std::string>{printable(d.header)});
    info["size"] = Value(static_cast<double>(bytes.size()));
    info["records"] = Value(static_cast<double>(d.records.size()));
    info["itemsize"] = Value(static_cast<double>(d.layout.itemSize));
    info["dtype"] = Value(dtype);
    info["endian"] = Value(lower(endian));
    info["schema"] = Value::boolean(schema.found);
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

const size_t kMaxByteView = 256u * 1024u * 1024u;

// load_<fmt>(file, dtype, endian, box_bytes, offset, align)
Value loadBinary(const std::string &fn, bool custom, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  if (!readFile(file, bytes, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (bytes.empty()) {
    ctx.fail("the file is empty");
    return Value(0.0);
  }
  if (bytes.size() > kMaxByteView) {
    ctx.fail("the file is " + formatBytes(bytes.size()) + "; load_" + std::string(custom ? "custom" : "bin") +
             " keeps a byte view of at most 256 MB - use read_bin(file, offset=..., count=...) to read part of it");
    return Value(0.0);
  }
  std::string dtype = optText(a[1], ""), endian = optText(a[2], "little");
  long long boxBytes = optInt(a[3], 0), offset = optInt(a[4], 0);
  Schema schema;
  if (custom && readSchema(file, bytes, schema)) {
    if (dtype.empty())
      dtype = schema.dtype;
    if (!schema.endian.empty())
      endian = schema.endian;
    if (boxBytes == 0 && schema.boxBytes > 0)
      boxBytes = schema.boxBytes;
    offset += static_cast<long long>(schema.embeddedLen);
  }
  Fields f;
  f["bytes"] = byteArray(bytes);
  f["size"] = Value(static_cast<double>(bytes.size()));
  f["endian"] = Value(lower(endian));
  f["file"] = Value(file);
  f["offset"] = Value(static_cast<double>(offset));
  f["box_bytes"] = Value(static_cast<double>(boxBytes));
  std::string header = bytes.substr(static_cast<size_t>(std::min<long long>(offset, static_cast<long long>(bytes.size()))),
                                    static_cast<size_t>(std::max(0LL, boxBytes)));
  f["header"] = byteArray(header);
  f["boxes"] = textList(header.empty() ? std::vector<std::string>{} : std::vector<std::string>{printable(header)});
  f["dtype"] = Value(dtype);
  if (!dtype.empty()) {
    Decoded d;
    long long align = optInt(a[5], 1);
    if (custom && schema.found && align == 1)
      align = schema.align;
    if (!decode(bytes, dtype, offset, -1, endian, 0, boxBytes, d, err, static_cast<size_t>(std::max(1LL, align)), fn, file)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (d.layout.structured) {
      Table t;
      for (const auto &fl : d.layout.fields)
        t.cols.push_back(fl.name);
      t.rows = d.records;
      for (size_t c = 0; c < t.cols.size(); c++) {
        std::string n = fieldName(t.cols[c]);
        if (!n.empty() && !f.count(n))
          f[n] = tableColumn(t, c);
      }
      f["records"] = tableObject(t);
    } else {
      std::vector<std::string> cols;
      f["records"] = decodedValue(d, schema.shape, cols, err);
      if (!err.empty()) {
        ctx.fail(err);
        return Value(0.0);
      }
    }
  }
  ev.ok = true;
  return makeObject(custom ? "NcCustom" : "NcBinary", std::move(f));
}

std::string bytesOf(const Value &obj) {
  const Value *b = field(obj, "bytes");
  std::string out;
  if (!b)
    return out;
  for (double d : optNumbers(*b))
    out.push_back(static_cast<char>(static_cast<int>(d)));
  return out;
}

// D.view(dtype, shape, offset, count)
Value viewMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string err;
  std::string bytes = bytesOf(a[0]);
  const Value *en = field(a[0], "endian");
  std::vector<size_t> shape;
  if (!shapeOf(a[2], shape, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  long long count = optInt(a[4], -1);
  if (count < 0 && !shape.empty()) {
    count = 1;
    for (size_t s : shape)
      count *= static_cast<long long>(s);
  }
  Decoded d;
  if (!decode(bytes, optText(a[1], "uint8"), optInt(a[3], 0), count, en ? optText(*en) : "little", 0, 0, d, err, 1,
              "view", "")) {
    ctx.fail(err);
    return Value(0.0);
  }
  std::vector<std::string> cols;
  Value v = decodedValue(d, shape, cols, err);
  if (!err.empty()) {
    ctx.fail(err);
    return Value(0.0);
  }
  return v;
}

// D.slice_bytes(start, end) - 0-based, end not included
Value sliceMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string bytes = bytesOf(a[0]);
  long long s = optInt(a[1], 0);
  long long e = a.size() > 2 ? optInt(a[2], static_cast<long long>(bytes.size())) : static_cast<long long>(bytes.size());
  if (s < 0)
    s += static_cast<long long>(bytes.size());
  if (e < 0)
    e += static_cast<long long>(bytes.size());
  if (s < 0 || e < s || e > static_cast<long long>(bytes.size())) {
    ctx.fail("byte range " + std::to_string(s) + ".." + std::to_string(e) + " is outside 0.." +
             std::to_string(bytes.size()));
    return Value(0.0);
  }
  return byteArray(bytes, static_cast<size_t>(s), static_cast<size_t>(e));
}

// save_<fmt>(file, data, dtype, endian, align, boxes, pad_byte, compress, level, mode)
Value saveBinary(const std::string &fn, bool custom, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  const std::string dtype = optText(a[2], "float64");
  std::string endian = lower(optText(a[3], "little"));
  const long long align = optInt(a[4], 1);
  if (align != 1 && align != 2 && align != 4 && align != 8) {
    ctx.fail("align must be 1 (packed), 2, 4 or 8");
    return Value(0.0);
  }
  Layout lay;
  if (!parseLayout(dtype, static_cast<size_t>(align), lay, err, &endian)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (endian != "little" && endian != "big" && endian != "native") {
    ctx.fail("endian must be \"little\" or \"big\"");
    return Value(0.0);
  }
  const bool big = endian == "big" || (endian == "native" && !hostLittle());
  const unsigned char pad = static_cast<unsigned char>(optInt(a[6], 0) & 0xFF);
  // records: one row per record, one column per field
  std::vector<std::vector<Value>> records;
  std::vector<size_t> shape;
  const Value &data = a[1];
  if (lay.structured) {
    Table t;
    if (!valueToTable(data, t, err, true)) {
      ctx.fail(err);
      return Value(0.0);
    }
    if (t.cols.size() != lay.fields.size()) {
      ctx.fail("dtype has " + std::to_string(lay.fields.size()) + " fields but the data has " +
               std::to_string(t.cols.size()) + " columns");
      return Value(0.0);
    }
    records = t.rows;
  } else if (data.isND()) {
    shape = data.ndShape();
    const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1];
    size_t n = data.ndCount();
    for (size_t k = 0; k < n; k++) { // row-major (C) order on disk
      size_t page = k / (rows * cols), within = k % (rows * cols);
      size_t flat = page * rows * cols + (within % cols) * rows + within / cols;
      records.push_back({data.ndAt(flat)});
    }
  } else if (data.isMatrix) {
    shape = {data.rows(), data.cols()};
    for (size_t r = 0; r < data.rows(); r++)
      for (size_t c = 0; c < data.rowLength(r); c++)
        records.push_back({data.at(r, c)});
  } else if (data.isArray) {
    shape = {data.length()};
    for (size_t i = 0; i < data.length(); i++)
      records.push_back({data.at(i)});
  } else if (data.isText && lay.fields[0].kind == 's') {
    records.push_back({data});
  } else if (numpy::isPlainNumber(data)) {
    shape = {1};
    records.push_back({data});
  } else {
    ctx.fail("data must be numbers (array / matrix) or a table for a record dtype");
    return Value(0.0);
  }
  std::string body(records.size() * lay.itemSize, static_cast<char>(pad));
  unsigned char *p = reinterpret_cast<unsigned char *>(body.data());
  for (size_t k = 0; k < records.size(); k++)
    for (size_t c = 0; c < lay.fields.size(); c++)
      if (!encodeField(records[k][c], lay.fields[c], big, p + k * lay.itemSize + lay.fields[c].offset, err)) {
        ctx.fail("record " + std::to_string(k + 1) + ": " + err);
        return Value(0.0);
      }
  const std::string mode = lower(optText(a[9], "w"));
  const bool append = mode == "a" && fileExists(file);
  std::string header = headerBytes(a[5]);
  std::string bytes = (append ? "" : header) + body;
  if (!applyCompression(optText(a[7], "none"), static_cast<int>(optInt(a[8], -1)), bytes, err) ||
      !writeFile(file, bytes, append, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (custom && !append) {
    TreeNode s;
    s.type = TreeNode::Object;
    TreeNode names;
    names.type = TreeNode::Array;
    for (const auto &f : lay.fields) {
      names.items.push_back(TreeNode::ofString(f.name));
    }
    s.keys.emplace_back("format", TreeNode::ofString("NC custom binary"));
    s.keys.emplace_back("dtype", TreeNode::ofString(dtype));
    if (lay.structured)
      s.keys.emplace_back("names", names);
    s.keys.emplace_back("endian", TreeNode::ofString(big ? "big" : "little"));
    s.keys.emplace_back("align", TreeNode::ofNumber(static_cast<double>(align)));
    s.keys.emplace_back("itemsize", TreeNode::ofNumber(static_cast<double>(lay.itemSize)));
    s.keys.emplace_back("box_bytes", TreeNode::ofNumber(static_cast<double>(header.size())));
    TreeNode sh;
    sh.type = TreeNode::Array;
    if (!lay.structured)
      for (size_t x : shape)
        sh.items.push_back(TreeNode::ofNumber(static_cast<double>(x)));
    s.keys.emplace_back("shape", sh);
    s.keys.emplace_back("records", TreeNode::ofNumber(static_cast<double>(records.size())));
    std::string json = writeJson(s, JsonStyle{2, false, "null"}) + "\n";
    if (!writeFile(file + ".schema.json", json, false, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
  }
  emitEvent({"saved", fn, file, 1.0, formatBytes(bytes.size())});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerBinary(Registry &reg) {
  for (const char *ext : {"bin", "custom"}) {
    const std::string e = ext;
    const bool custom = e == "custom";
    addMulti(reg, "read_" + e,
             std::string("file, dtype=\"") + (custom ? "" : "uint8") +
                 "\", shape=\"\", offset=0, count=-1, endian=\"little\", stride=0, box_bytes=0, align=1",
             custom ? "read a .custom binary file using its schema (or the dtype given)"
                    : "read raw binary as numbers of a dtype (or records of a struct dtype)",
             "numpy.fromfile", 2,
             [e, custom](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
               readBinary("read_" + e, custom, a, nout, out, ctx);
             });
    addFn(reg, "load_" + e, "file, dtype=\"\", endian=\"little\", box_bytes=0, offset=0, align=1",
          "load a binary file as a byte view object (D.bytes, D.header, D.records, D.view(...))",
          "numpy.memmap",
          [e, custom](const std::vector<Value> &a, CallContext &ctx) { return loadBinary("load_" + e, custom, a, ctx); });
    addFn(reg, "save_" + e,
          "file, data, dtype=\"float64\", endian=\"little\", align=1, boxes=\"\", pad_byte=0, "
          "compress=\"none\", level=-1, mode=\"w\"",
          custom ? "write binary records plus a companion .schema.json describing them"
                 : "write numbers (or records) as raw binary of a dtype",
          "numpy.ndarray.tofile",
          [e, custom](const std::vector<Value> &a, CallContext &ctx) { return saveBinary("save_" + e, custom, a, ctx); });
  }
  for (const char *cls : {"NcBinary", "NcCustom"}) {
    const std::string c = cls;
    addFn(reg, c + ".view", "D, dtype=\"uint8\", shape=\"\", offset=0, count=-1",
          "reinterpret the bytes of a loaded binary file as another dtype", "numpy.ndarray.view", viewMethod);
    addFn(reg, c + ".slice_bytes", "D, start, end?", "bytes start..end-1 (0-based) of a loaded binary file",
          "memoryview slice", sliceMethod);
  }
}

} // namespace io
} // namespace nc
