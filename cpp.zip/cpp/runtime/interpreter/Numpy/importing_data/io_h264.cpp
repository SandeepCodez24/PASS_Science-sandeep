// H.264 (ITU-T H.264 / ISO 14496-10) baseline streams made of I_PCM
// macroblocks: encoder, and a decoder for such streams (see io_video.h).
#include <algorithm>
#include <cmath>

#include "io_video.h"

namespace nc {
namespace io {
namespace {

struct BitW {
  std::string out;
  uint32_t acc = 0;
  int n = 0;
  void bit(int b) { acc = (acc << 1) | (b & 1); if (++n == 8) { out.push_back(static_cast<char>(acc)); acc = 0; n = 0; } }
  void u(uint32_t v, int bits) { for (int k = bits - 1; k >= 0; k--) bit((v >> k) & 1); }
  void ue(uint32_t v) { uint32_t x = v + 1; int len = 0; while ((x >> len) > 1) len++; u(0, len); u(x, len + 1); }
  void se(int32_t v) { ue(v <= 0 ? static_cast<uint32_t>(-2 * v) : static_cast<uint32_t>(2 * v - 1)); }
  bool aligned() const { return n == 0; }
  void alignZero() { while (n) bit(0); }
  void trailing() { bit(1); alignZero(); }
};

struct BitR {
  const std::string &b;
  size_t pos = 0; // bit position
  explicit BitR(const std::string &s) : b(s) {}
  bool more() const { return pos < b.size() * 8; }
  int bit() { if (pos >= b.size() * 8) { pos++; return 0; } int v = (static_cast<unsigned char>(b[pos >> 3]) >> (7 - (pos & 7))) & 1; pos++; return v; }
  uint32_t u(int n) { uint32_t v = 0; for (int k = 0; k < n; k++) v = (v << 1) | static_cast<uint32_t>(bit()); return v; }
  uint32_t ue() { int z = 0; while (bit() == 0 && z < 32) z++; return z ? ((1u << z) - 1) + u(z) : 0; }
  int32_t se() { uint32_t k = ue(); return (k & 1) ? static_cast<int32_t>((k + 1) / 2) : -static_cast<int32_t>(k / 2); }
  void align() { pos = (pos + 7) & ~static_cast<size_t>(7); }
};

std::string escape(const std::string &rbsp) { // emulation prevention
  std::string o;
  int zeros = 0;
  for (char c : rbsp) {
    unsigned char x = static_cast<unsigned char>(c);
    if (zeros >= 2 && x <= 3) { o.push_back(3); zeros = 0; }
    o.push_back(c);
    zeros = x == 0 ? zeros + 1 : 0;
  }
  return o;
}

std::string unescape(const std::string &nal) {
  std::string o;
  int zeros = 0;
  for (size_t i = 0; i < nal.size(); i++) {
    unsigned char x = static_cast<unsigned char>(nal[i]);
    if (zeros >= 2 && x == 3) { zeros = 0; continue; }
    o.push_back(nal[i]);
    zeros = x == 0 ? zeros + 1 : 0;
  }
  return o;
}

struct Sps { uint32_t mbW = 0, mbH = 0, cropL = 0, cropR = 0, cropT = 0, cropB = 0, log2MaxFrameNum = 4, pocType = 2, log2MaxPoc = 4; int profile = 66; bool frameMbsOnly = true; };
struct Pps { bool deblockCtl = false, redundant = false; uint32_t numRefL0 = 0; };

bool parseSps(const std::string &nal, Sps &s, std::string &err) {
  std::string r = unescape(nal.substr(1));
  BitR b(r);
  s.profile = static_cast<int>(b.u(8));
  b.u(8);
  b.u(8);
  b.ue();
  if (s.profile == 100 || s.profile == 110 || s.profile == 122 || s.profile == 244 || s.profile == 44 || s.profile == 83 || s.profile == 86 || s.profile == 118 || s.profile == 128) {
    uint32_t chroma = b.ue();
    if (chroma == 3) b.u(1);
    b.ue();
    b.ue();
    b.u(1);
    if (b.u(1)) { err = "H.264 scaling matrices are not built in"; return false; }
    if (chroma != 1) { err = "only 4:2:0 H.264 is built in"; return false; }
  }
  s.log2MaxFrameNum = b.ue() + 4;
  s.pocType = b.ue();
  if (s.pocType == 0) s.log2MaxPoc = b.ue() + 4;
  else if (s.pocType == 1) { b.u(1); b.se(); b.se(); uint32_t n = b.ue(); for (uint32_t k = 0; k < n; k++) b.se(); }
  b.ue();
  b.u(1);
  s.mbW = b.ue() + 1;
  s.mbH = b.ue() + 1;
  s.frameMbsOnly = b.u(1);
  if (!s.frameMbsOnly) { err = "interlaced H.264 is not built in"; return false; }
  b.u(1);
  if (b.u(1)) { s.cropL = b.ue(); s.cropR = b.ue(); s.cropT = b.ue(); s.cropB = b.ue(); }
  return true;
}

} // namespace

std::vector<std::string> h264SplitAnnexB(const std::string &b) {
  std::vector<std::string> out;
  size_t i = 0, start = std::string::npos;
  while (i + 3 <= b.size()) {
    if (b[i] == 0 && b[i + 1] == 0 && (b[i + 2] == 1 || (i + 4 <= b.size() && b[i + 2] == 0 && b[i + 3] == 1))) {
      size_t sc = b[i + 2] == 1 ? 3 : 4;
      if (start != std::string::npos) {
        size_t end = i;
        while (end > start && b[end - 1] == 0) end--;
        out.push_back(b.substr(start, end - start));
      }
      i += sc;
      start = i;
    } else i++;
  }
  if (start != std::string::npos && start < b.size()) out.push_back(b.substr(start));
  return out;
}

std::vector<std::string> h264SplitLengths(const std::string &b, int lengthSize) {
  std::vector<std::string> out;
  size_t p = 0;
  while (p + static_cast<size_t>(lengthSize) <= b.size()) {
    size_t n = 0;
    for (int k = 0; k < lengthSize; k++) n = (n << 8) | static_cast<unsigned char>(b[p + k]);
    p += static_cast<size_t>(lengthSize);
    if (p + n > b.size()) break;
    out.push_back(b.substr(p, n));
    p += n;
  }
  return out;
}

std::vector<std::string> h264EncodePcm(const Image &src, int idrId, H264Params &ps) {
  Image img = src.channels == 3 ? src : convertChannels(src, "rgb");
  size_t w = img.width, h = img.height;
  uint32_t mbW = static_cast<uint32_t>((w + 15) / 16), mbH = static_cast<uint32_t>((h + 15) / 16);
  // SPS: baseline, every picture an IDR, POC type 2, cropping to the real size
  BitW s;
  s.u(66, 8);
  s.u(0xC0, 8); // constraint_set0 + set1
  s.u(51, 8);   // level 5.1
  s.ue(0);
  s.ue(0);      // log2_max_frame_num - 4
  s.ue(2);      // pic_order_cnt_type
  s.ue(1);      // max_num_ref_frames
  s.u(0, 1);
  s.ue(mbW - 1);
  s.ue(mbH - 1);
  s.u(1, 1);    // frame_mbs_only
  s.u(1, 1);    // direct_8x8_inference
  uint32_t cr = static_cast<uint32_t>(mbW * 16 - w) / 2, cb = static_cast<uint32_t>(mbH * 16 - h) / 2;
  if (cr || cb) { s.u(1, 1); s.ue(0); s.ue(cr); s.ue(0); s.ue(cb); } else s.u(0, 1);
  s.u(0, 1);    // no VUI
  s.trailing();
  ps.sps = std::string(1, '\x67') + escape(s.out);
  BitW p;
  p.ue(0); p.ue(0); p.u(0, 1); p.u(0, 1); p.ue(0); p.ue(0); p.ue(0); p.u(0, 1); p.u(0, 2);
  p.se(0); p.se(0); p.se(0);
  p.u(1, 1);    // deblocking filter control present
  p.u(0, 1);
  p.u(0, 1);
  p.trailing();
  ps.pps = std::string(1, '\x68') + escape(p.out);
  // YUV 4:2:0, BT.601 limited range; edges replicate into the padding
  size_t W = mbW * 16, H = mbH * 16;
  std::vector<uint8_t> Y(W * H), U((W / 2) * (H / 2)), V((W / 2) * (H / 2));
  auto rgb = [&](size_t x, size_t y, double &r, double &g, double &b) {
    x = std::min(x, w - 1); y = std::min(y, h - 1);
    double scale = 255.0 / img.maxValue();
    r = img.at(x, y, 0) * scale; g = img.at(x, y, 1) * scale; b = img.at(x, y, 2) * scale;
  };
  auto clip = [](double v) { return static_cast<uint8_t>(std::clamp(std::lround(v), 1L, 254L)); };
  for (size_t y = 0; y < H; y++)
    for (size_t x = 0; x < W; x++) {
      double r, g, b;
      rgb(x, y, r, g, b);
      Y[y * W + x] = clip(16 + 0.256788 * r + 0.504129 * g + 0.097906 * b);
    }
  for (size_t y = 0; y < H / 2; y++)
    for (size_t x = 0; x < W / 2; x++) {
      double rs = 0, gs = 0, bs = 0;
      for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) { double r, g, b; rgb(2 * x + dx, 2 * y + dy, r, g, b); rs += r; gs += g; bs += b; }
      rs /= 4; gs /= 4; bs /= 4;
      U[y * (W / 2) + x] = clip(128 - 0.148223 * rs - 0.290993 * gs + 0.439216 * bs);
      V[y * (W / 2) + x] = clip(128 + 0.439216 * rs - 0.367788 * gs - 0.071427 * bs);
    }
  BitW sl;
  sl.ue(0);      // first_mb_in_slice
  sl.ue(7);      // I slice (all slices)
  sl.ue(0);      // pps id
  sl.u(0, 4);    // frame_num
  sl.ue(static_cast<uint32_t>(idrId & 1));
  sl.u(0, 1);    // no_output_of_prior_pics
  sl.u(0, 1);    // long_term_reference
  sl.se(0);      // slice_qp_delta
  sl.ue(1);      // deblocking off
  for (uint32_t my = 0; my < mbH; my++)
    for (uint32_t mx = 0; mx < mbW; mx++) {
      sl.ue(25);   // I_PCM
      sl.alignZero();
      for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) sl.out.push_back(static_cast<char>(Y[(my * 16 + y) * W + mx * 16 + x]));
      for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) sl.out.push_back(static_cast<char>(U[(my * 8 + y) * (W / 2) + mx * 8 + x]));
      for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) sl.out.push_back(static_cast<char>(V[(my * 8 + y) * (W / 2) + mx * 8 + x]));
    }
  sl.trailing();
  return {ps.sps, ps.pps, std::string(1, '\x65') + escape(sl.out)};
}

bool h264DecodePcm(const std::vector<std::string> &nals, H264Params &ps, Image &img, std::string &err) {
  Sps sps;
  bool haveSlice = false;
  for (const auto &n : nals) {
    if (n.empty()) continue;
    int type = n[0] & 0x1F;
    if (type == 7) ps.sps = n;
    else if (type == 8) ps.pps = n;
  }
  if (ps.sps.empty()) { err = "H.264: no sequence parameter set"; return false; }
  if (!parseSps(ps.sps, sps, err)) return false;
  Pps pps;
  {
    std::string r = unescape(ps.pps.substr(std::min<size_t>(1, ps.pps.size())));
    BitR b(r);
    b.ue(); b.ue();
    if (b.u(1)) { err = "this H.264 stream uses CABAC compression - decoding compressed H.264 is not built in (NC decodes MJPEG, raw and its own I_PCM H.264)"; return false; }
    b.u(1);
    if (b.ue() != 0) { err = "H.264 slice groups are not built in"; return false; }
    pps.numRefL0 = b.ue();
    b.ue(); b.u(1); b.u(2); b.se(); b.se(); b.se();
    pps.deblockCtl = b.u(1);
    b.u(1);
    pps.redundant = b.u(1);
  }
  size_t W = sps.mbW * 16, H = sps.mbH * 16;
  std::vector<uint8_t> Y(W * H, 16), U((W / 2) * (H / 2), 128), V((W / 2) * (H / 2), 128);
  for (const auto &n : nals) {
    if (n.empty()) continue;
    int type = n[0] & 0x1F;
    if (type != 1 && type != 5) continue;
    std::string r = unescape(n.substr(1));
    BitR b(r);
    uint32_t first = b.ue();
    uint32_t st = b.ue() % 5;
    if (st != 2 && st != 4) { err = "this H.264 stream has P/B frames - decoding compressed H.264 is not built in (NC decodes MJPEG, raw and its own I_PCM H.264)"; return false; }
    b.ue();
    b.u(static_cast<int>(sps.log2MaxFrameNum));
    if (type == 5) b.ue();
    if (sps.pocType == 0) b.u(static_cast<int>(sps.log2MaxPoc));
    if (pps.redundant) b.ue();
    if (n[0] & 0x60) { if (type == 5) { b.u(1); b.u(1); } else if (b.u(1)) { err = "H.264 memory management ops are not built in"; return false; } }
    b.se();
    if (pps.deblockCtl) { if (b.ue() != 1) { b.se(); b.se(); } }
    uint32_t mbs = sps.mbW * sps.mbH;
    for (uint32_t mb = first; mb < mbs; mb++) {
      if (!b.more()) break;
      uint32_t mt = b.ue();
      if (mt != 25) { err = "this H.264 stream has compressed macroblocks - decoding compressed H.264 is not built in (NC decodes MJPEG, raw and its own I_PCM H.264)"; return false; }
      b.align();
      size_t p = b.pos / 8;
      if (p + 384 > r.size()) { err = "H.264: I_PCM macroblock cut short"; return false; }
      size_t mx = mb % sps.mbW, my = mb / sps.mbW;
      for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) Y[(my * 16 + y) * W + mx * 16 + x] = static_cast<uint8_t>(r[p++]);
      for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) U[(my * 8 + y) * (W / 2) + mx * 8 + x] = static_cast<uint8_t>(r[p++]);
      for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) V[(my * 8 + y) * (W / 2) + mx * 8 + x] = static_cast<uint8_t>(r[p++]);
      b.pos = p * 8;
    }
    haveSlice = true;
  }
  if (!haveSlice) { err = "H.264: no picture in this sample"; return false; }
  size_t w = W - 2 * (sps.cropL + sps.cropR), h = H - 2 * (sps.cropT + sps.cropB);
  img = Image();
  img.width = w;
  img.height = h;
  img.channels = 3;
  img.px.resize(w * h * 3);
  for (size_t y = 0; y < h; y++)
    for (size_t x = 0; x < w; x++) {
      size_t sx = x + 2 * sps.cropL, sy = y + 2 * sps.cropT;
      double yy = 1.164383 * (Y[sy * W + sx] - 16.0), u = U[(sy / 2) * (W / 2) + sx / 2] - 128.0, v = V[(sy / 2) * (W / 2) + sx / 2] - 128.0;
      double rgb[3] = {yy + 1.596027 * v, yy - 0.391762 * u - 0.812968 * v, yy + 2.017232 * u};
      for (int c = 0; c < 3; c++) img.px[(y * w + x) * 3 + c] = std::clamp(std::round(rgb[c]), 0.0, 255.0);
    }
  return true;
}

} // namespace io
} // namespace nc
