// CATEGORY 14 - images: read_/load_/save_ png, jpg, jpeg, tiff, bmp, gif, dicom.
#include <algorithm>
#include <cmath>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_image.h"

namespace nc {
namespace io {
namespace {

bool decodeAny(const std::string &fmt, const std::string &bytes, Image &img, std::string &err, bool hu) {
  if (fmt == "png") return decodePng(bytes, img, err);
  if (fmt == "jpg" || fmt == "jpeg") return decodeJpeg(bytes, img, err);
  if (fmt == "tiff" || fmt == "tif" || fmt == "geotiff") return decodeTiff(bytes, img, err, true);
  if (fmt == "bmp") return decodeBmp(bytes, img, err);
  if (fmt == "gif") return decodeGif(bytes, img, err);
  return decodeDicom(bytes, img, err, hu);
}

bool loadImage(const std::string &fmt, const std::string &file, Image &img, std::string &err, bool hu = true) {
  std::string bytes;
  if (!readSource(file, bytes, err)) return false;
  if (!decodeAny(fmt, bytes, img, err, hu)) return false;
  if (img.orientation > 1) applyOrientation(img);
  return true;
}

Value boxesOf(const Image &img) {
  Fields f;
  for (const auto &t : img.text) f[t.first] = Value(t.second);
  return Value(f);
}

Value dpiOf(const Image &img) { return numberList({img.dpiX, img.dpiY > 0 ? img.dpiY : img.dpiX}); }

// roi, scale, channels applied in this order.
bool shapeImage(Image &img, const Value &roi, const Value &channels, const Value &scale, std::string &err) {
  if (given(roi)) {
    std::vector<double> r = optNumbers(roi);
    if (r.size() != 4 || r[0] < 0 || r[1] < 0 || r[2] < 1 || r[3] < 1 || r[0] + r[2] > img.width || r[1] + r[3] > img.height) {
      err = "roi must be [x, y, w, h] inside the " + std::to_string(img.width) + " x " + std::to_string(img.height) + " image";
      return false;
    }
    img = cropImage(img, static_cast<size_t>(r[0]), static_cast<size_t>(r[1]), static_cast<size_t>(r[2]), static_cast<size_t>(r[3]));
  }
  if (given(scale)) {
    std::vector<double> s = optNumbers(scale);
    if (s.size() != 2 || s[0] < 1 || s[1] < 1) {
      err = "scale must be [W, H] in pixels";
      return false;
    }
    img = resizeImage(img, static_cast<size_t>(s[0]), static_cast<size_t>(s[1]));
  }
  if (given(channels)) {
    std::string c = lower(optText(channels));
    if (c != "rgb" && c != "gray" && c != "rgba" && c != "grey") {
      err = "channels must be \"rgb\", \"gray\" or \"rgba\"";
      return false;
    }
    img = convertChannels(img, c == "grey" ? "gray" : c);
  }
  return true;
}

Value framesTensor(const Image &img, bool asFloat) {
  std::vector<double> all;
  size_t n = 1 + img.frames.size();
  for (size_t k = 0; k < n; k++) {
    const Image &f = k == 0 ? img : img.frames[k - 1];
    Value v = imageToValue(f, asFloat);
    std::vector<size_t> shape;
    std::vector<double> vals;
    ndToRowMajor(v, shape, vals);
    all.insert(all.end(), vals.begin(), vals.end());
  }
  if (img.channels == 1) return ndFromRowMajor({n, img.height, img.width}, all);
  return ndFromRowMajor({n, img.height, img.width, img.channels}, all);
}

// read_<fmt>(file, roi, channels, dtype, scale, [frame], [hu], box)
void readImage(const std::string &fmt, bool hasFrames, bool isDicom, const std::vector<Value> &a, size_t nout,
               std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  size_t k = 5;
  Value frameSel = hasFrames ? a[k++] : Value(0.0);
  bool hu = isDicom ? optBool(a[k++], true) : true;
  bool box = optBool(a[k], true);
  Image img;
  if (!loadImage(fmt, file, img, err, hu)) return ctx.fail(err);
  std::string dtype = lower(optText(a[3], "uint8"));
  if (dtype != "uint8" && dtype != "float32" && dtype != "float64" && dtype != "uint16") return ctx.fail("dtype must be \"uint8\" or \"float32\"");
  bool asFloat = dtype == "float32" || dtype == "float64";
  if (dtype == "uint8" && (img.bitDepth > 8 || img.isFloat) && !isDicom) img = to8bit(img);
  bool all = frameSel.isText && lower(frameSel.text()) == "all";
  if (!all) {
    long long f = optInt(frameSel, 0);
    if (f < 0 || f > static_cast<long long>(img.frames.size()))
      return ctx.fail("frame " + std::to_string(f) + " does not exist (the file has " + std::to_string(img.frames.size() + 1) + ", numbered from 0)");
    if (f > 0) {
      Image chosen = img.frames[static_cast<size_t>(f - 1)];
      chosen.dpiX = img.dpiX; chosen.dpiY = img.dpiY; chosen.text = img.text; chosen.exif = img.exif; chosen.extra = img.extra;
      img = chosen;
    }
    img.frames.clear();
  }
  if (!shapeImage(img, a[1], a[2], a[4], err)) return ctx.fail(err);
  for (auto &fr : img.frames)
    if (!shapeImage(fr, a[1], a[2], a[4], err)) return ctx.fail(err);
  out.push_back(all ? framesTensor(img, asFloat) : imageToValue(img, asFloat));
  if (nout > 1) {
    Fields info;
    info["width"] = Value(static_cast<double>(img.width));
    info["height"] = Value(static_cast<double>(img.height));
    info["channels"] = Value(static_cast<double>(img.channels));
    info["dpi"] = dpiOf(img);
    info["color_space"] = Value(img.colorSpace);
    info["boxes"] = box ? boxesOf(img) : Value(Fields{});
    info["exif"] = Value(img.exif);
    info["frames"] = Value(static_cast<double>(img.frames.size() + 1));
    info["bit_depth"] = Value(static_cast<double>(img.bitDepth));
    if (isDicom && img.extra.count("tags")) info["tags"] = img.extra.at("tags");
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

Value loadImageFn(const std::string &fmt, bool isDicom, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  Image img;
  if (!loadImage(fmt, file, img, err, isDicom ? optBool(a[1], true) : true)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  Value px = imageToValue(img, false);
  f["pixels"] = px;
  f["tensor"] = px;
  f["width"] = Value(static_cast<double>(img.width));
  f["height"] = Value(static_cast<double>(img.height));
  f["channels"] = Value(static_cast<double>(img.channels));
  f["shape"] = img.channels == 1 ? numberList({static_cast<double>(img.height), static_cast<double>(img.width)})
                                 : numberList({static_cast<double>(img.height), static_cast<double>(img.width), static_cast<double>(img.channels)});
  if (img.channels >= 3) {
    const char *names[] = {"R", "G", "B", "A"};
    for (size_t c = 0; c < img.channels && c < 4; c++) {
      std::vector<double> plane(img.width * img.height);
      for (size_t i = 0; i < plane.size(); i++) plane[i] = img.px[i * img.channels + c];
      f[names[c]] = ndFromRowMajor({img.height, img.width}, plane);
    }
  }
  f["dpi"] = dpiOf(img);
  f["color_space"] = Value(img.colorSpace);
  f["exif"] = Value(img.exif);
  std::vector<double> icc;
  for (unsigned char c : img.icc) icc.push_back(c);
  f["icc"] = numberList(icc);
  f["boxes"] = boxesOf(img);
  f["bit_depth"] = Value(static_cast<double>(img.bitDepth));
  std::vector<Value> frames{px};
  for (const auto &fr : img.frames) frames.push_back(imageToValue(fr, false));
  f["frames"] = Value(std::move(frames));
  f["delay"] = Value(img.delay);
  f["file"] = Value(file);
  f["format"] = Value(fmt);
  if (isDicom && img.extra.count("tags")) {
    const Value &tags = img.extra.at("tags");
    f["tags"] = tags;
    Fields patient, study;
    for (const char *k : {"PatientName", "PatientID", "PatientBirthDate", "PatientSex", "PatientAge"})
      if (tags.dict().count(k)) patient[std::string(k).substr(7)] = tags.dict().at(k);
    for (const char *k : {"StudyDate", "StudyTime", "StudyDescription", "SeriesDescription", "Modality", "SliceThickness",
                          "PixelSpacing", "KVP", "Manufacturer", "RescaleSlope", "RescaleIntercept"})
      if (tags.dict().count(k)) study[k] = tags.dict().at(k);
    f["patient"] = Value(patient);
    f["study"] = Value(study);
    f["modality"] = tags.dict().count("Modality") ? tags.dict().at("Modality") : Value(std::string());
  }
  ev.ok = true;
  return makeObject("NcImage", std::move(f));
}

bool framesOf(const Value &v, std::vector<Image> &frames, std::string &err) {
  frames.clear();
  if (v.isArray) { // cell array of frames
    for (size_t i = 0; i < v.length(); i++) {
      Image im;
      if (!valueToImage(v.at(i), im, err)) return false;
      frames.push_back(im);
    }
    return !frames.empty();
  }
  if (isObjectOf(v, "NcImage")) {
    const Value *fr = field(v, "frames");
    if (fr && fr->isArray && fr->length() > 1) return framesOf(*fr, frames, err);
  }
  if (v.isND() && v.ndShape().size() == 4) {
    std::vector<size_t> shape;
    std::vector<double> vals;
    ndToRowMajor(v, shape, vals);
    size_t per = shape[1] * shape[2] * shape[3];
    for (size_t k = 0; k < shape[0]; k++) {
      std::vector<double> part(vals.begin() + static_cast<long>(k * per), vals.begin() + static_cast<long>((k + 1) * per));
      Image im;
      if (!valueToImage(ndFromRowMajor({shape[1], shape[2], shape[3]}, part), im, err)) return false;
      frames.push_back(im);
    }
    return true;
  }
  Image im;
  if (!valueToImage(v, im, err)) return false;
  frames.push_back(im);
  return true;
}

// save_<fmt>(file, img, dpi, compress, max_size, <format options...>, scale, boxes)
Value saveImageFn(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  std::vector<Image> frames;
  if (!framesOf(a[1], frames, err)) return fail(err);
  const size_t n = a.size();
  const Value &scaleV = a[n - 2], &boxV = a[n - 1];
  double scale = optNumber(scaleV, 1.0);
  if (scale <= 0) return fail("scale must be > 0");
  double dpi = optNumber(a[2], 96);
  std::vector<double> dd = optNumbers(a[2]);
  for (auto &im : frames) {
    if (scale != 1.0) im = resizeImage(im, std::max<size_t>(1, static_cast<size_t>(std::lround(im.width * scale))), std::max<size_t>(1, static_cast<size_t>(std::lround(im.height * scale))));
    im.dpiX = dd.size() == 2 ? dd[0] : dpi;
    im.dpiY = dd.size() == 2 ? dd[1] : dpi;
    if (boxV.isDict) for (const auto &kv : boxV.dict()) im.text.push_back({kv.first, cellText(kv.second)});
    else for (const auto &t : optTextList(boxV)) im.text.push_back({"Comment", t});
  }
  const bool compress = optBool(a[3], true) && lower(optText(a[3], "yes")) != "no";
  uint64_t budget = 0;
  if (given(a[4]) && !parseByteSize(optText(a[4]), budget)) return fail("max_size \"" + optText(a[4]) + "\" is not a size (e.g. \"48kb\")");
  auto fits = [&](const std::string &bytes) { return !budget || bytes.size() <= budget; };
  std::string bytes;
  Image &img = frames[0];
  if (fmt == "png") {
    int level = compress ? static_cast<int>(optInt(a[5], 6)) : 0;
    long long depth = optInt(a[6], 8);
    if (depth != 8 && depth != 16) return fail("bit_depth must be 8 or 16");
    if (depth == 8) img = to8bit(img);
    else if (img.bitDepth < 16) { for (double &v : img.px) v *= 257; img.bitDepth = 16; }
    std::vector<double> tr = optNumbers(a[7]);
    bytes = encodePng(img, level, false, tr);
    if (!fits(bytes)) bytes = encodePng(img, 9, false, tr);
    if (!fits(bytes) && depth == 8) bytes = encodePng(img, 9, true, tr); // 256-colour palette
  } else if (fmt == "jpg" || fmt == "jpeg") {
    int quality = static_cast<int>(optInt(a[5], 92));
    std::string ss = optText(a[6], "4:2:0");
    if (ss != "4:2:0" && ss != "4:4:4") return fail("subsampling must be \"4:2:0\" or \"4:4:4\"");
    bool prog = optBool(a[7], false);
    bytes = encodeJpeg(img, quality, ss == "4:2:0", prog);
    if (!fits(bytes)) { // largest quality that fits
      int lo = 5, hi = quality - 1;
      std::string best;
      while (lo <= hi) {
        int mid = (lo + hi) / 2;
        std::string t = encodeJpeg(img, mid, true, prog);
        if (fits(t)) { best = t; lo = mid + 1; } else hi = mid - 1;
      }
      if (!best.empty()) bytes = best;
    }
  } else if (fmt == "tiff") {
    TiffOptions opt;
    opt.codec = compress ? lower(optText(a[5], "lzw")) : "none";
    if (opt.codec != "lzw" && opt.codec != "deflate" && opt.codec != "none" && opt.codec != "packbits")
      return fail("codec must be \"lzw\", \"deflate\", \"packbits\" or \"none\"");
    std::vector<Image> pages;
    if (optBool(a[6], false) && fileExists(file)) {
      Image old;
      std::string ob;
      if (!readFile(file, ob, err) || !decodeTiff(ob, old, err, true)) return fail("cannot append to " + file + ": " + err);
      std::vector<Image> olds{old};
      for (auto &f : old.frames) olds.push_back(f);
      olds[0].frames.clear();
      pages = olds;
    }
    for (auto &f : frames) pages.push_back(f);
    std::vector<const Image *> ptrs;
    for (auto &p : pages) ptrs.push_back(&p);
    bytes = encodeTiff(ptrs, opt);
    if (!fits(bytes) && opt.codec != "deflate") { opt.codec = "deflate"; bytes = encodeTiff(ptrs, opt); }
  } else if (fmt == "bmp") {
    bytes = encodeBmp(img);
  } else if (fmt == "gif") {
    double fps = optNumber(a[5], 15);
    int loop = static_cast<int>(optInt(a[6], 0));
    std::vector<const Image *> ptrs;
    for (auto &f : frames) ptrs.push_back(&f);
    size_t colors = 256;
    bytes = encodeGif(ptrs, fps, loop, colors);
    while (!fits(bytes) && colors > 4) {
      colors /= 2;
      bytes = encodeGif(ptrs, fps, loop, colors);
    }
  } else { // dicom
    Fields patient;
    if (a[5].isDict) patient = a[5].dict();
    bytes = encodeDicom(img, patient, optBool(a[6], true));
  }
  if (!fits(bytes))
    return fail("the smallest ." + fmt + " NC can make is " + std::to_string(bytes.size()) + " bytes, over max_size " + std::to_string(budget) + " bytes" +
                (fmt == "png" ? " - try save_jpg, or a smaller scale=" : " - try a smaller scale="));
  if (!writeFile(file, bytes, false, err)) return fail(err);
  emitEvent({"saved", "save_" + fmt, file, 1.0, formatBytes(bytes.size())});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerImages(Registry &reg) {
  struct F {
    const char *ext, *title, *saveOpts;
    bool frames, dicom;
  };
  const F fmts[] = {
      {"png", "Portable Network Graphics", "level=6, bit_depth=8, transparent=\"\"", false, false},
      {"jpg", "JPEG photographic image", "quality=92, subsampling=\"4:2:0\", progressive=false", false, false},
      {"jpeg", "JPEG compressed raster image", "quality=92, subsampling=\"4:2:0\", progressive=false", false, false},
      {"tiff", "Tagged Image File Format (multi-page)", "codec=\"lzw\", append_page=false", true, false},
      {"bmp", "device-independent bitmap", "", false, false},
      {"gif", "Graphics Interchange Format (animated)", "fps=15, loop=0", true, false},
      {"dicom", "DICOM medical image", "patient=\"\", anonymize=true", true, true},
  };
  for (const F &f : fmts) {
    const std::string e = f.ext;
    const bool frames = f.frames, dicom = f.dicom;
    std::string rp = "file, roi=\"\", channels=\"\", dtype=\"uint8\", scale=\"\"";
    if (frames) rp += ", frame=0";
    if (dicom) rp += ", hu=true";
    rp += ", box=true";
    addMulti(reg, "read_" + e, rp, std::string("read a .") + e + " image as an (H,W) or (H,W,C) matrix (" + f.title + ")",
             "imageio.imread", 2,
             [e, frames, dicom](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
               readImage(e, frames, dicom, a, nout, out, ctx);
             });
    addFn(reg, "load_" + e, dicom ? "file, hu=true" : "file",
          std::string("load a .") + e + " image object (D.pixels, D.width, D.R, D.dpi, D.exif, D.boxes" +
              (frames ? ", D.frames" : "") + (dicom ? ", D.patient, D.study, D.tags" : "") + ")",
          "PIL.Image.open",
          [e, dicom](const std::vector<Value> &a, CallContext &ctx) { return loadImageFn(e, dicom, a, ctx); });
    std::string sp = "file, img, dpi=96, compress=\"yes\", max_size=\"\"";
    if (*f.saveOpts) sp += std::string(", ") + f.saveOpts;
    sp += ", scale=1.0, boxes=\"\"";
    addFn(reg, "save_" + e, sp, std::string("write an image matrix as .") + e, "PIL.Image.save",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveImageFn(e, a, ctx); });
  }
}

} // namespace io
} // namespace nc
