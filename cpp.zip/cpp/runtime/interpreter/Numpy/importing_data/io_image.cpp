// Image conversions - see io_image.h.
#include <algorithm>
#include <array>
#include <cmath>
#include <map>

#include "../numpy_common.h"
#include "io_image.h"

namespace nc {
namespace io {

Value imageToValue(const Image &img, bool asFloat) {
  std::vector<double> v = img.px;
  if (asFloat && !img.isFloat) {
    double m = img.maxValue();
    for (double &x : v) x /= m;
  }
  if (img.channels == 1)
    return ndFromRowMajor({img.height, img.width}, v);
  return ndFromRowMajor({img.height, img.width, img.channels}, v);
}

bool valueToImage(const Value &v, Image &img, std::string &err) {
  img = Image();
  if (isObjectOf(v, "NcImage") || isObjectOf(v, "NcGeoRaster")) {
    const Value *p = field(v, "pixels");
    if (!p) p = field(v, "raster");
    if (!p) {
      err = "this object has no pixels";
      return false;
    }
    bool ok = valueToImage(*p, img, err);
    if (const Value *d = field(v, "dpi")) {
      std::vector<double> dd = optNumbers(*d);
      if (dd.size() == 2) { img.dpiX = dd[0]; img.dpiY = dd[1]; }
    }
    return ok;
  }
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!ndToRowMajor(v, shape, vals) || shape.size() < 2 || shape.size() > 3) {
    err = "an image must be a 2-D (H,W) or 3-D (H,W,C) matrix";
    return false;
  }
  img.height = shape[0];
  img.width = shape[1];
  img.channels = shape.size() == 3 ? shape[2] : 1;
  if (img.channels < 1 || img.channels > 4) {
    err = "an image needs 1, 2, 3 or 4 channels (got " + std::to_string(img.channels) + ")";
    return false;
  }
  bool frac = false;
  double mx = 0;
  for (double x : vals) {
    if (!std::isfinite(x)) {
      err = "the image holds NaN or Inf";
      return false;
    }
    if (x != std::floor(x)) frac = true;
    mx = std::max(mx, x);
  }
  if (frac && mx <= 1.0) { // floats in [0,1]
    for (double &x : vals) x = std::round(std::clamp(x, 0.0, 1.0) * 255.0);
    img.bitDepth = 8;
  } else if (frac) {
    for (double &x : vals) x = std::round(x);
    if (mx > 255) img.bitDepth = 16;
  } else if (mx > 255) {
    img.bitDepth = 16;
    for (double &x : vals) x = std::clamp(x, 0.0, 65535.0);
  }
  img.px = std::move(vals);
  return true;
}

Image to8bit(const Image &img) {
  if (img.bitDepth == 8 && !img.isFloat) return img;
  Image o = img;
  double m = img.maxValue();
  for (double &x : o.px) x = std::round(std::clamp(x / m, 0.0, 1.0) * 255.0);
  o.bitDepth = 8;
  o.isFloat = false;
  return o;
}

Image convertChannels(const Image &img, const std::string &mode) {
  size_t want = mode == "gray" ? 1 : mode == "rgb" ? 3 : mode == "rgba" ? 4 : img.channels;
  if (want == img.channels) return img;
  Image o = img;
  o.channels = want;
  o.px.assign(img.width * img.height * want, 0);
  double full = img.maxValue();
  for (size_t i = 0; i < img.width * img.height; i++) {
    const double *s = &img.px[i * img.channels];
    double r, g, b, a = full;
    if (img.channels <= 2) { r = g = b = s[0]; if (img.channels == 2) a = s[1]; }
    else { r = s[0]; g = s[1]; b = s[2]; if (img.channels == 4) a = s[3]; }
    double *d = &o.px[i * want];
    if (want == 1) d[0] = std::round(0.299 * r + 0.587 * g + 0.114 * b);
    else if (want == 2) { d[0] = std::round(0.299 * r + 0.587 * g + 0.114 * b); d[1] = a; }
    else { d[0] = r; d[1] = g; d[2] = b; if (want == 4) d[3] = a; }
  }
  o.colorSpace = want <= 2 ? "Grayscale" : "sRGB";
  return o;
}

Image cropImage(const Image &img, size_t x, size_t y, size_t w, size_t h) {
  Image o = img;
  o.frames.clear();
  o.width = w;
  o.height = h;
  o.px.assign(w * h * img.channels, 0);
  for (size_t r = 0; r < h; r++)
    for (size_t c = 0; c < w; c++)
      for (size_t k = 0; k < img.channels; k++)
        o.px[(r * w + c) * img.channels + k] = img.at(x + c, y + r, k);
  return o;
}

Image resizeImage(const Image &img, size_t w, size_t h) {
  Image o = img;
  o.frames.clear();
  o.width = w;
  o.height = h;
  o.px.assign(w * h * img.channels, 0);
  if (!img.width || !img.height) return o;
  for (size_t r = 0; r < h; r++) {
    double sy = (r + 0.5) * img.height / h - 0.5;
    long long y0 = static_cast<long long>(std::floor(sy));
    double fy = sy - y0;
    for (size_t c = 0; c < w; c++) {
      double sx = (c + 0.5) * img.width / w - 0.5;
      long long x0 = static_cast<long long>(std::floor(sx));
      double fx = sx - x0;
      auto px = [&](long long xx, long long yy, size_t k) {
        xx = std::clamp<long long>(xx, 0, static_cast<long long>(img.width) - 1);
        yy = std::clamp<long long>(yy, 0, static_cast<long long>(img.height) - 1);
        return img.at(static_cast<size_t>(xx), static_cast<size_t>(yy), k);
      };
      for (size_t k = 0; k < img.channels; k++) {
        double v = px(x0, y0, k) * (1 - fx) * (1 - fy) + px(x0 + 1, y0, k) * fx * (1 - fy) +
                   px(x0, y0 + 1, k) * (1 - fx) * fy + px(x0 + 1, y0 + 1, k) * fx * fy;
        o.px[(r * w + c) * img.channels + k] = img.isFloat ? v : std::round(v);
      }
    }
  }
  return o;
}

void applyOrientation(Image &img) {
  int o = img.orientation;
  if (o <= 1 || o > 8) return;
  bool swap = o >= 5;
  size_t W = img.width, H = img.height, C = img.channels;
  size_t nw = swap ? H : W, nh = swap ? W : H;
  std::vector<double> out(img.px.size());
  for (size_t y = 0; y < H; y++)
    for (size_t x = 0; x < W; x++) {
      size_t nx = x, ny = y;
      switch (o) {
        case 2: nx = W - 1 - x; break;
        case 3: nx = W - 1 - x; ny = H - 1 - y; break;
        case 4: ny = H - 1 - y; break;
        case 5: nx = y; ny = x; break;
        case 6: nx = H - 1 - y; ny = x; break;
        case 7: nx = H - 1 - y; ny = W - 1 - x; break;
        case 8: nx = y; ny = W - 1 - x; break;
      }
      for (size_t k = 0; k < C; k++) out[(ny * nw + nx) * C + k] = img.px[(y * W + x) * C + k];
    }
  img.px.swap(out);
  img.width = nw;
  img.height = nh;
  img.orientation = 1;
}

void quantize(const Image &src, size_t maxColors, std::vector<uint8_t> &indices,
              std::vector<std::array<uint8_t, 4>> &palette) {
  Image img = to8bit(convertChannels(src, src.channels == 2 || src.channels == 4 ? "rgba" : "rgb"));
  const size_t C = img.channels, n = img.width * img.height;
  indices.assign(n, 0);
  palette.clear();
  // exact palette when it fits
  std::map<uint32_t, uint8_t> exact;
  bool fits = true;
  for (size_t i = 0; i < n && fits; i++) {
    uint32_t key = 0;
    for (size_t k = 0; k < C; k++) key = (key << 8) | static_cast<uint32_t>(img.px[i * C + k]);
    if (C == 3) key = (key << 8) | 255;
    if (!exact.count(key)) {
      if (exact.size() >= maxColors) fits = false;
      else exact[key] = static_cast<uint8_t>(exact.size());
    }
  }
  if (fits) {
    palette.resize(exact.size());
    for (const auto &kv : exact)
      palette[kv.second] = {static_cast<uint8_t>(kv.first >> 24), static_cast<uint8_t>(kv.first >> 16),
                            static_cast<uint8_t>(kv.first >> 8), static_cast<uint8_t>(kv.first)};
    for (size_t i = 0; i < n; i++) {
      uint32_t key = 0;
      for (size_t k = 0; k < C; k++) key = (key << 8) | static_cast<uint32_t>(img.px[i * C + k]);
      if (C == 3) key = (key << 8) | 255;
      indices[i] = exact[key];
    }
    return;
  }
  // median cut on RGB (alpha: fully transparent pixels share one entry)
  std::vector<size_t> ids(n);
  for (size_t i = 0; i < n; i++) ids[i] = i;
  struct Box { size_t b, e; };
  std::vector<Box> boxes{{0, n}};
  auto channel = [&](size_t i, int k) { return img.px[i * C + static_cast<size_t>(k)]; };
  while (boxes.size() < maxColors) {
    size_t best = SIZE_MAX;
    double bestRange = 0;
    int bestK = 0;
    for (size_t bi = 0; bi < boxes.size(); bi++) {
      if (boxes[bi].e - boxes[bi].b < 2) continue;
      for (int k = 0; k < 3; k++) {
        double lo = 255, hi = 0;
        for (size_t j = boxes[bi].b; j < boxes[bi].e; j++) {
          double x = channel(ids[j], k);
          lo = std::min(lo, x);
          hi = std::max(hi, x);
        }
        if (hi - lo > bestRange) { bestRange = hi - lo; best = bi; bestK = k; }
      }
    }
    if (best == SIZE_MAX || bestRange == 0) break;
    Box bx = boxes[best];
    size_t mid = (bx.b + bx.e) / 2;
    std::nth_element(ids.begin() + static_cast<long>(bx.b), ids.begin() + static_cast<long>(mid), ids.begin() + static_cast<long>(bx.e),
                     [&](size_t a, size_t b) { return channel(a, bestK) < channel(b, bestK); });
    boxes[best] = {bx.b, mid};
    boxes.push_back({mid, bx.e});
  }
  for (size_t bi = 0; bi < boxes.size(); bi++) {
    double s[4] = {0, 0, 0, 0};
    size_t cnt = boxes[bi].e - boxes[bi].b;
    for (size_t j = boxes[bi].b; j < boxes[bi].e; j++)
      for (size_t k = 0; k < C; k++) s[k] += channel(ids[j], static_cast<int>(k));
    std::array<uint8_t, 4> p{};
    for (size_t k = 0; k < 4; k++)
      p[k] = static_cast<uint8_t>(k < C ? std::round(s[k] / std::max<size_t>(1, cnt)) : 255);
    palette.push_back(p);
    for (size_t j = boxes[bi].b; j < boxes[bi].e; j++) indices[ids[j]] = static_cast<uint8_t>(bi);
  }
}

} // namespace io
} // namespace nc
