// ZIP read / write - see io_zip.h.
#include "io_zip.h"

#include "io_bytes.h"
#include "io_deflate.h"

namespace nc {
namespace io {

bool ZipReader::open(const std::string &bytes, std::string &err) {
  data = &bytes;
  entries.clear();
  // End of central directory: last 22..65557 bytes.
  if (bytes.size() < 22) {
    err = "not a zip archive (too short)";
    return false;
  }
  size_t eocd = std::string::npos;
  size_t lo = bytes.size() > 65557 ? bytes.size() - 65557 : 0;
  for (size_t p = bytes.size() - 22 + 1; p-- > lo;)
    if (u32le(bytes, p) == 0x06054b50) {
      eocd = p;
      break;
    }
  if (eocd == std::string::npos) {
    err = "not a zip archive (no central directory)";
    return false;
  }
  size_t count = u16le(bytes, eocd + 10);
  size_t cd = u32le(bytes, eocd + 16);
  for (size_t k = 0; k < count; k++) {
    if (cd + 46 > bytes.size() || u32le(bytes, cd) != 0x02014b50) {
      err = "damaged zip central directory";
      return false;
    }
    Entry e;
    e.method = u16le(bytes, cd + 10);
    e.compSize = u32le(bytes, cd + 20);
    e.size = u32le(bytes, cd + 24);
    size_t nameLen = u16le(bytes, cd + 28), extra = u16le(bytes, cd + 30), comment = u16le(bytes, cd + 32);
    e.localOffset = u32le(bytes, cd + 42);
    e.name = bytes.substr(cd + 46, nameLen);
    entries.push_back(e);
    cd += 46 + nameLen + extra + comment;
  }
  return true;
}

bool ZipReader::has(const std::string &name) const {
  for (const auto &e : entries)
    if (e.name == name)
      return true;
  return false;
}

bool ZipReader::read(const std::string &name, std::string &out, std::string &err) const {
  for (const auto &e : entries) {
    if (e.name != name)
      continue;
    const std::string &b = *data;
    size_t p = e.localOffset;
    if (p + 30 > b.size() || u32le(b, p) != 0x04034b50) {
      err = "damaged zip entry " + name;
      return false;
    }
    size_t start = p + 30 + u16le(b, p + 26) + u16le(b, p + 28);
    if (start + e.compSize > b.size()) {
      err = "zip entry " + name + " runs past the end";
      return false;
    }
    if (e.method == 0) {
      out = b.substr(start, e.compSize);
      return true;
    }
    if (e.method == 8)
      return inflateRaw(b.substr(start, e.compSize), 0, out, err);
    err = "zip entry " + name + " uses compression method " + std::to_string(e.method) + " (only stored/deflate are built in)";
    return false;
  }
  err = "the archive has no entry " + name;
  return false;
}

std::string ZipWriter::finish(int level) const {
  std::string out, central;
  for (const auto &f : files) {
    std::string comp = deflateRaw(f.second, level);
    bool store = comp.size() >= f.second.size();
    const std::string &body = store ? f.second : comp;
    uint32_t crc = crc32(f.second.data(), f.second.size());
    size_t offset = out.size();
    putLE(out, 0x04034b50, 4);
    putLE(out, 20, 2);
    putLE(out, 0x0800, 2); // UTF-8 names
    putLE(out, store ? 0 : 8, 2);
    putLE(out, 0, 2);
    putLE(out, 0x5A21, 2); // 2025-01-01
    putLE(out, crc, 4);
    putLE(out, body.size(), 4);
    putLE(out, f.second.size(), 4);
    putLE(out, f.first.size(), 2);
    putLE(out, 0, 2);
    out += f.first + body;
    putLE(central, 0x02014b50, 4);
    putLE(central, 20, 2);
    putLE(central, 20, 2);
    putLE(central, 0x0800, 2);
    putLE(central, store ? 0 : 8, 2);
    putLE(central, 0, 2);
    putLE(central, 0x5A21, 2);
    putLE(central, crc, 4);
    putLE(central, body.size(), 4);
    putLE(central, f.second.size(), 4);
    putLE(central, f.first.size(), 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 2);
    putLE(central, 0, 4);
    putLE(central, offset, 4);
    central += f.first;
  }
  size_t cdOffset = out.size();
  out += central;
  putLE(out, 0x06054b50, 4);
  putLE(out, 0, 2);
  putLE(out, 0, 2);
  putLE(out, files.size(), 2);
  putLE(out, files.size(), 2);
  putLE(out, central.size(), 4);
  putLE(out, cdOffset, 4);
  putLE(out, 0, 2);
  return out;
}

} // namespace io
} // namespace nc
