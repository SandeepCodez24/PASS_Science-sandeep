// HDF5 writer (see io_h5.h): superblock v0, v1 object headers, symbol-table
// groups, contiguous or chunked (v1 B-tree) datasets, deflate / shuffle /
// LZF filters, attributes, object references and variable-length data in
// global heaps.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_deflate.h"
#include "io_h5.h"

namespace nc {
namespace io {

size_t H5WData::count() const {
  if (scalar) return 1;
  size_t n = 1;
  for (auto d : dims) n *= static_cast<size_t>(d);
  return n;
}

H5WNode *H5WNode::find(const std::string &n) {
  for (auto &k : kids) if (k.name == n) return &k;
  return nullptr;
}

H5Type h5Float(size_t size) { H5Type t; t.cls = H5Type::Float; t.size = size; return t; }
H5Type h5Int(size_t size, bool sign) { H5Type t; t.cls = H5Type::Fixed; t.size = size; t.sign = sign; return t; }
H5Type h5String(size_t size) { H5Type t; t.cls = H5Type::String; t.size = std::max<size_t>(1, size); return t; }
H5Type h5Ref() { H5Type t; t.cls = H5Type::Reference; t.size = 8; return t; }
H5Type h5VarLen(const H5Type &base) { H5Type t; t.cls = H5Type::VarLen; t.size = 16; t.members.push_back(base); return t; }
H5Type h5Compound(const std::vector<std::string> &names, const std::vector<H5Type> &types) {
  H5Type t;
  t.cls = H5Type::Compound;
  t.size = 0;
  for (size_t i = 0; i < names.size(); i++) {
    t.memberNames.push_back(names[i]);
    t.memberOffsets.push_back(t.size);
    t.members.push_back(types[i]);
    t.size += types[i].size;
  }
  return t;
}

namespace {

void putNum(std::string &out, double v, const H5Type &t) {
  if (t.cls == H5Type::Float) {
    if (t.size == 4) putF32LE(out, static_cast<float>(v));
    else putF64LE(out, v);
  } else {
    int64_t i = std::isnan(v) ? 0 : static_cast<int64_t>(std::llround(v));
    putLE(out, static_cast<uint64_t>(i), static_cast<int>(t.size));
  }
}

} // namespace

H5WData h5Numbers(const std::vector<size_t> &shape, const std::vector<double> &vals, const H5Type &t) {
  H5WData d;
  d.type = t;
  for (auto s : shape) d.dims.push_back(s);
  d.raw.reserve(vals.size() * t.size);
  for (double v : vals) putNum(d.raw, v, t);
  return d;
}

H5WData h5Texts(const std::vector<size_t> &shape, const std::vector<std::string> &vals) {
  size_t w = 1;
  for (const auto &s : vals) w = std::max(w, s.size());
  H5WData d;
  d.type = h5String(w);
  d.type.strPad = 1; // null padded, like h5py's fixed-length strings
  for (auto s : shape) d.dims.push_back(s);
  for (const auto &s : vals) { d.raw += s; d.raw.append(w - s.size(), '\0'); }
  return d;
}

H5WData h5ScalarText(const std::string &s) {
  H5WData d = h5Texts({}, {s});
  d.scalar = true;
  d.type.strPad = 0;
  if (s.empty()) d.type.size = 1;
  return d;
}

H5WData h5ScalarNumber(double v, const H5Type &t) {
  H5WData d = h5Numbers({}, {v}, t);
  d.scalar = true;
  return d;
}

std::vector<uint64_t> h5AutoChunk(const std::vector<uint64_t> &dims, size_t elemSize) {
  std::vector<uint64_t> c = dims;
  for (auto &x : c) if (x == 0 || x == H5_UNDEF) x = 1024;
  uint64_t total = elemSize;
  for (auto x : c) total *= x;
  // aim for 16 KiB .. 1 MiB, larger datasets get larger chunks (h5py's rule of thumb)
  double mb = static_cast<double>(total) / (1024.0 * 1024.0);
  uint64_t target = static_cast<uint64_t>(16 * 1024 * std::pow(2.0, std::log10(std::max(mb, 1.0))));
  target = std::min<uint64_t>(std::max<uint64_t>(target, 16 * 1024), 1024 * 1024);
  size_t k = 0;
  while (total > target && !c.empty()) {
    size_t d = k++ % c.size();
    if (c[d] > 1) {
      c[d] = (c[d] + 1) / 2;
      total = elemSize;
      for (auto x : c) total *= x;
    }
    bool allOne = std::all_of(c.begin(), c.end(), [](uint64_t x) { return x == 1; });
    if (allOne) break;
  }
  return c;
}

// ---- LZF compressor (liblzf format) -----------------------------------------------------

std::string lzfCompress(const std::string &in) {
  std::string out;
  const size_t n = in.size();
  std::vector<int64_t> table(1 << 14, -1);
  size_t i = 0, litStart = 0;
  auto flushLit = [&](size_t end) {
    while (litStart < end) {
      size_t run = std::min<size_t>(32, end - litStart);
      out.push_back(static_cast<char>(run - 1));
      out.append(in, litStart, run);
      litStart += run;
    }
  };
  while (i + 2 < n) {
    uint32_t h = (static_cast<unsigned char>(in[i]) << 16) | (static_cast<unsigned char>(in[i + 1]) << 8) | static_cast<unsigned char>(in[i + 2]);
    uint32_t slot = ((h * 2654435761u) >> 18) & ((1 << 14) - 1);
    int64_t ref = table[slot];
    table[slot] = static_cast<int64_t>(i);
    if (ref >= 0 && i - static_cast<size_t>(ref) <= 8192 && std::memcmp(in.data() + ref, in.data() + i, 3) == 0) {
      size_t len = 3, maxLen = std::min<size_t>(264, n - i);
      while (len < maxLen && in[ref + len] == in[i + len]) len++;
      flushLit(i);
      size_t back = i - static_cast<size_t>(ref) - 1;
      size_t l = len - 2;
      if (l < 7) out.push_back(static_cast<char>((l << 5) | (back >> 8)));
      else { out.push_back(static_cast<char>((7 << 5) | (back >> 8))); out.push_back(static_cast<char>(l - 7)); }
      out.push_back(static_cast<char>(back & 0xFF));
      i += len;
      litStart = i;
    } else i++;
  }
  flushLit(n);
  return out;
}

namespace {

// ---- encoders for header pieces -------------------------------------------------------------

std::string encodeType(const H5Type &t) {
  std::string s;
  auto head = [&](int cls, int ver, uint32_t flags, size_t size) {
    s.push_back(static_cast<char>((ver << 4) | cls));
    putLE(s, flags, 3);
    putLE(s, size, 4);
  };
  switch (t.cls) {
  case H5Type::Fixed: case H5Type::Bitfield:
    head(t.cls, 1, t.sign && t.cls == H5Type::Fixed ? 0x08 : 0, t.size);
    putLE(s, 0, 2);
    putLE(s, t.size * 8, 2);
    break;
  case H5Type::Float:
    if (t.size == 4) { head(1, 1, 0x20 | (31 << 8), 4); putLE(s, 0, 2); putLE(s, 32, 2); s += std::string("\x17\x08\x00\x17", 4); putLE(s, 127, 4); }
    else { head(1, 1, 0x20 | (63 << 8), 8); putLE(s, 0, 2); putLE(s, 64, 2); s += std::string("\x34\x0b\x00\x34", 4); putLE(s, 1023, 4); }
    break;
  case H5Type::String:
    head(3, 1, static_cast<uint32_t>(t.strPad) | (1 << 4), t.size); // UTF-8
    break;
  case H5Type::Reference:
    head(7, 1, 0, 8);
    break;
  case H5Type::Compound: {
    head(6, 1, static_cast<uint32_t>(t.members.size()), t.size);
    for (size_t i = 0; i < t.members.size(); i++) {
      std::string name = t.memberNames[i];
      s += name;
      s.append(8 - name.size() % 8, '\0');
      putLE(s, t.memberOffsets[i], 4);
      s.push_back(0);          // dimensionality
      s.append(3, '\0');
      putLE(s, 0, 4);          // permutation
      putLE(s, 0, 4);
      s.append(16, '\0');      // dims
      s += encodeType(t.members[i]);
    }
    break;
  }
  case H5Type::VarLen:
    head(9, 1, t.vlenString ? 1 | (1 << 8) : 0, 16);
    s += encodeType(t.members[0]);
    break;
  default:
    head(5, 1, 0, t.size); // opaque
    break;
  }
  return s;
}

std::string encodeSpace(const H5WData &d) {
  std::string s;
  bool hasMax = !d.maxDims.empty();
  s.push_back(1);
  s.push_back(d.scalar ? 0 : static_cast<char>(d.dims.size()));
  s.push_back(hasMax && !d.scalar ? 1 : 0);
  s.append(5, '\0');
  if (!d.scalar) {
    for (auto x : d.dims) putLE(s, x, 8);
    if (hasMax) for (auto x : d.maxDims) putLE(s, x, 8);
  }
  return s;
}

struct Writer {
  std::string out;
  size_t ub = 0;
  std::map<std::string, uint64_t> addrOf;
  std::vector<std::pair<size_t, std::string>> patches; // absolute position, path
  std::string err;
  static constexpr int LEAF_K = 4, GROUP_K = 16, CHUNK_K = 32;

  uint64_t here() const { return out.size() - ub; }
  void align8() { while (out.size() % 8) out.push_back('\0'); }

  struct Message {
    int type;
    std::string data;
    int flags = 0;
    std::vector<std::pair<size_t, std::string>> refs = {}; // offsets in data that receive an object address
  };

  uint64_t objectHeader(const std::vector<Message> &ms) {
    align8();
    uint64_t at = here();
    std::string body;
    size_t count = 0;
    std::vector<std::pair<size_t, std::string>> refs; // offsets in body
    for (const auto &m : ms) {
      std::string d = m.data;
      while (d.size() % 8) d.push_back('\0');
      putLE(body, m.type, 2);
      putLE(body, d.size(), 2);
      body.push_back(static_cast<char>(m.flags));
      body.append(3, '\0');
      for (const auto &r : m.refs) refs.push_back({body.size() + r.first, r.second});
      body += d;
      count++;
    }
    if (body.size() < 24) { // a NIL message keeps room, as libhdf5 does
      size_t pad = 24 - body.size() - 8;
      putLE(body, 0, 2); putLE(body, pad, 2); body.append(4, '\0'); body.append(pad, '\0');
      count++;
    }
    out.push_back(1);
    out.push_back(0);
    putLE(out, count, 2);
    putLE(out, 1, 4);
    putLE(out, body.size(), 4);
    out.append(4, '\0');
    size_t bodyAt = out.size();
    out += body;
    for (const auto &r : refs) patches.push_back({bodyAt + r.first, r.second});
    return at;
  }

  // the bytes of an attribute message; refs inside data are patched later
  std::string attrMessage(const H5WAttr &a, size_t &dataPos, std::vector<std::pair<size_t, std::string>> &localRefs) {
    std::string type = encodeType(a.data.type), space = encodeSpace(a.data);
    std::string m;
    m.push_back(1);
    m.push_back(0);
    putLE(m, a.name.size() + 1, 2);
    putLE(m, type.size(), 2);
    putLE(m, space.size(), 2);
    std::string name = a.name + '\0';
    while (name.size() % 8) name.push_back('\0');
    auto pad8 = [](std::string s) { while (s.size() % 8) s.push_back('\0'); return s; };
    m += name + pad8(type) + pad8(space);
    dataPos = m.size();
    m += dataBytes(a.data, localRefs);
    return m;
  }

  // element bytes; VarLen items go to a global heap written now
  std::string dataBytes(const H5WData &d, std::vector<std::pair<size_t, std::string>> &refs) {
    if (d.type.cls != H5Type::VarLen) { refs = d.refs; return d.raw; }
    // global heap collection holding every item
    align8();
    uint64_t coll = here();
    size_t start = out.size();
    out += "GCOL";
    out.push_back(1);
    out.append(3, '\0');
    size_t sizePos = out.size();
    putLE(out, 0, 8);
    std::string elems;
    for (size_t i = 0; i < d.items.size(); i++) {
      const auto &it = d.items[i];
      putLE(out, i + 1, 2);
      putLE(out, 1, 2);
      out.append(4, '\0');
      putLE(out, it.raw.size(), 8);
      size_t dataAt = out.size();
      out += it.raw;
      for (const auto &r : it.refs) patches.push_back({dataAt + r.first, r.second});
      align8();
      putLE(elems, it.count, 4);
      putLE(elems, coll, 8);
      putLE(elems, i + 1, 4);
    }
    size_t used = out.size() - start;
    size_t total = std::max<size_t>(4096, used + 16);
    putLE(out, 0, 2); // free space object
    putLE(out, 0, 2);
    out.append(4, '\0');
    putLE(out, total - used, 8);
    out.append(total - used - 16, '\0');
    setLE(out, sizePos, total, 8);
    refs.clear();
    return elems;
  }

  // generic v1 B-tree: level-0 entries (key bytes, child) + final key
  uint64_t btree(int type, std::vector<std::pair<std::string, uint64_t>> entries, std::string finalKey, size_t keySize, int k) {
    size_t cap = 2 * static_cast<size_t>(k);
    int level = 0;
    for (;;) {
      std::vector<std::pair<std::string, uint64_t>> parents;
      size_t nodes = std::max<size_t>(1, (entries.size() + cap - 1) / cap);
      for (size_t nd = 0; nd < nodes; nd++) {
        size_t from = nd * cap, to = std::min(entries.size(), from + cap);
        align8();
        uint64_t at = here();
        out += "TREE";
        out.push_back(static_cast<char>(type));
        out.push_back(static_cast<char>(level));
        putLE(out, to - from, 2);
        putLE(out, H5_UNDEF, 8);
        putLE(out, H5_UNDEF, 8);
        for (size_t i = from; i < to; i++) { out += entries[i].first; putLE(out, entries[i].second, 8); }
        out += to < entries.size() ? entries[to].first : finalKey;
        out.append((cap - (to - from)) * (keySize + 8), '\0');
        parents.push_back({from < entries.size() ? entries[from].first : finalKey, at});
      }
      if (parents.size() == 1) return parents[0].second;
      entries = parents;
      level++;
    }
  }

  uint64_t writeNode(const H5WNode &n, const std::string &path) {
    std::vector<Message> ms;
    if (n.group) {
      std::vector<std::pair<std::string, uint64_t>> kids; // name, header address
      std::vector<const H5WNode *> sorted;
      for (const auto &k : n.kids) sorted.push_back(&k);
      std::sort(sorted.begin(), sorted.end(), [](const H5WNode *a, const H5WNode *b) { return a->name < b->name; });
      for (size_t i = 1; i < sorted.size(); i++)
        if (sorted[i]->name == sorted[i - 1]->name) { err = "two members of '" + path + "' are both named '" + sorted[i]->name + "'"; return 0; }
      std::vector<uint64_t> kidAddr;
      std::vector<std::pair<uint64_t, uint64_t>> kidCache; // btree, heap of child groups
      for (const auto *k : sorted) {
        uint64_t a = writeNode(*k, (path == "/" ? "" : path) + "/" + k->name);
        if (!err.empty()) return 0;
        kidAddr.push_back(a);
        kidCache.push_back(groupCache_[a]);
      }
      // local heap of names
      std::string names(8, '\0');
      std::vector<uint64_t> nameOff;
      for (const auto *k : sorted) {
        nameOff.push_back(names.size());
        names += k->name;
        names.push_back('\0');
        while (names.size() % 8) names.push_back('\0');
      }
      align8();
      uint64_t heap = here();
      out += "HEAP";
      out.push_back(0);
      out.append(3, '\0');
      putLE(out, names.size(), 8);
      putLE(out, 1, 8);           // free list head: 1 = no free block (libhdf5's H5HL_FREE_NULL)
      putLE(out, here() + 8, 8);  // the data segment follows this field
      out += names;
      // symbol table nodes (2K entries each)
      std::vector<std::pair<std::string, uint64_t>> entries;
      size_t per = 2 * LEAF_K;
      for (size_t from = 0; from < sorted.size(); from += per) {
        size_t to = std::min(sorted.size(), from + per);
        align8();
        uint64_t at = here();
        out += "SNOD";
        out.push_back(1);
        out.push_back(0);
        putLE(out, to - from, 2);
        for (size_t i = from; i < to; i++) {
          putLE(out, nameOff[i], 8);
          putLE(out, kidAddr[i], 8);
          bool g = sorted[i]->group;
          putLE(out, g ? 1 : 0, 4);
          putLE(out, 0, 4);
          if (g) { putLE(out, kidCache[i].first, 8); putLE(out, kidCache[i].second, 8); }
          else out.append(16, '\0');
        }
        out.append((per - (to - from)) * 40, '\0');
        std::string key;
        putLE(key, nameOff[to - 1], 8);
        entries.push_back({key, at});
      }
      // keys: key[i] = last name of child i-1 (key[0] = "")
      std::vector<std::pair<std::string, uint64_t>> keyed;
      std::string prev;
      putLE(prev, 0, 8);
      for (const auto &e : entries) { keyed.push_back({prev, e.second}); prev = e.first; }
      uint64_t bt = btree(0, keyed, prev, 8, GROUP_K);
      std::string st;
      putLE(st, bt, 8);
      putLE(st, heap, 8);
      ms.push_back({0x11, st});
      addAttrs(n, ms);
      if (!err.empty()) return 0;
      uint64_t a = objectHeader(ms);
      groupCache_[a] = {bt, heap};
      addrOf[path] = a;
      return a;
    }
    // dataset
    const H5WData &d = n.data;
    size_t es = d.type.size;
    std::vector<std::pair<size_t, std::string>> refs;
    std::string raw = dataBytes(d, refs);
    if (n.allocate && !d.scalar && raw.size() != d.count() * es) { err = "'" + path + "': data size does not match its shape"; return 0; }
    std::string layout;
    std::vector<Message> filt;
    bool chunked = !n.chunk.empty() && !d.scalar && refs.empty() && d.type.cls != H5Type::VarLen;
    uint32_t fillTime = 2;
    if (!n.allocate && !chunked) {
      layout.push_back(3); layout.push_back(1);
      putLE(layout, H5_UNDEF, 8);
      putLE(layout, 0, 8);
      fillTime = 1;
    } else if (!chunked) {
      align8();
      uint64_t at = raw.empty() ? H5_UNDEF : here();
      size_t pos = out.size();
      out += raw;
      for (const auto &r : refs) patches.push_back({pos + r.first, r.second});
      layout.push_back(3); layout.push_back(1);
      putLE(layout, at, 8);
      putLE(layout, raw.size(), 8);
    } else {
      size_t rank = d.dims.size();
      std::vector<uint64_t> ch = n.chunk;
      ch.resize(rank, 1);
      for (size_t i = 0; i < rank; i++) if (ch[i] == 0) ch[i] = 1;
      for (size_t i = 0; i < rank; i++) // libhdf5: chunk <= max dim for fixed-size dims
        if ((d.maxDims.empty() || d.maxDims[i] != H5_UNDEF) && ch[i] > std::max<uint64_t>(1, d.dims[i])) ch[i] = std::max<uint64_t>(1, d.dims[i]);
      // filter pipeline
      std::vector<H5Filter> pipe;
      if (n.shuffle && es > 1 && n.compress != "none") pipe.push_back({2, false, {static_cast<uint32_t>(es)}});
      uint64_t chunkBytes = es;
      for (auto c : ch) chunkBytes *= c;
      if (n.compress == "gzip") pipe.push_back({1, false, {static_cast<uint32_t>(std::clamp(n.level, 0, 9))}});
      else if (n.compress == "lzf") pipe.push_back({32000, true, {4, 0x0105, static_cast<uint32_t>(chunkBytes)}});
      if (!pipe.empty()) {
        std::string f;
        f.push_back(1);
        f.push_back(static_cast<char>(pipe.size()));
        f.append(6, '\0');
        for (const auto &x : pipe) {
          std::string name = x.id == 1 ? "deflate" : x.id == 2 ? "shuffle" : "lzf";
          name.push_back('\0');
          while (name.size() % 8) name.push_back('\0');
          putLE(f, x.id, 2);
          putLE(f, name.size(), 2);
          putLE(f, x.optional ? 1 : 0, 2);
          putLE(f, x.values.size(), 2);
          f += name;
          for (auto v : x.values) putLE(f, v, 4);
          if (x.values.size() & 1) putLE(f, 0, 4);
        }
        filt.push_back({0x0B, f});
      }
      std::vector<uint64_t> grid(rank);
      uint64_t nch = 1;
      for (size_t i = 0; i < rank; i++) { grid[i] = (d.dims[i] + ch[i] - 1) / ch[i]; nch *= grid[i]; }
      std::vector<std::pair<std::string, uint64_t>> entries;
      std::vector<uint64_t> idx(rank, 0);
      for (uint64_t k = 0; k < nch && !d.dims.empty() && n.allocate; k++) {
        uint64_t rem = k;
        for (size_t i = rank; i-- > 0;) { idx[i] = rem % grid[i]; rem /= grid[i]; }
        // gather the chunk (edge chunks padded with zeros)
        std::string chunk(static_cast<size_t>(chunkBytes), '\0');
        std::vector<uint64_t> c(rank, 0);
        size_t run = static_cast<size_t>(std::min<uint64_t>(ch[rank - 1], d.dims[rank - 1] - idx[rank - 1] * ch[rank - 1]));
        for (;;) {
          bool inside = true;
          size_t src = 0, dst = 0;
          for (size_t i = 0; i < rank; i++) {
            uint64_t g = idx[i] * ch[i] + c[i];
            if (g >= d.dims[i]) inside = false;
            src = src * static_cast<size_t>(d.dims[i]) + static_cast<size_t>(g);
            dst = dst * static_cast<size_t>(ch[i]) + static_cast<size_t>(c[i]);
          }
          if (inside) std::memcpy(&chunk[dst * es], raw.data() + src * es, run * es);
          size_t i = rank - 1;
          bool done = false;
          for (;;) {
            if (i == 0) { done = true; break; }
            i--;
            if (++c[i] < ch[i]) break;
            c[i] = 0;
          }
          if (done) break;
        }
        uint32_t mask = 0;
        for (size_t f = 0; f < pipe.size(); f++) {
          const auto &x = pipe[f];
          if (x.id == 2) {
            size_t m = chunk.size() / es;
            std::string s(chunk.size(), '\0');
            for (size_t b = 0; b < es; b++) for (size_t j = 0; j < m; j++) s[b * m + j] = chunk[j * es + b];
            chunk.swap(s);
          } else if (x.id == 1) chunk = zlibCompress(chunk, static_cast<int>(x.values[0]));
          else if (x.id == 32000) {
            std::string z = lzfCompress(chunk);
            if (z.size() < chunk.size()) chunk.swap(z);
            else mask |= 1u << f;
          }
        }
        align8();
        uint64_t at = here();
        out += chunk;
        std::string key;
        putLE(key, chunk.size(), 4);
        putLE(key, mask, 4);
        for (size_t i = 0; i < rank; i++) putLE(key, idx[i] * ch[i], 8);
        putLE(key, 0, 8);
        entries.push_back({key, at});
      }
      std::string fin;
      putLE(fin, 0, 4);
      putLE(fin, 0, 4);
      for (size_t i = 0; i < rank; i++) putLE(fin, grid[i] * ch[i], 8);
      putLE(fin, 0, 8);
      uint64_t bt = btree(1, entries, fin, 8 + 8 * (rank + 1), CHUNK_K);
      layout.push_back(3); layout.push_back(2);
      layout.push_back(static_cast<char>(rank + 1));
      putLE(layout, bt, 8);
      for (auto c2 : ch) putLE(layout, c2, 4);
      putLE(layout, es, 4);
    }
    ms.push_back({0x01, encodeSpace(d)});
    ms.push_back({0x03, encodeType(d.type), 1});
    std::string fill;
    fill.push_back(2);
    fill.push_back(chunked ? 3 : 2);
    fill.push_back(static_cast<char>(fillTime));
    fill.push_back(0);
    ms.push_back({0x05, fill, 1});
    ms.push_back({0x08, layout});
    for (auto &f : filt) ms.push_back(f);
    addAttrs(n, ms);
    if (!err.empty()) return 0;
    uint64_t a = objectHeader(ms);
    addrOf[path] = a;
    return a;
  }

  void addAttrs(const H5WNode &n, std::vector<Message> &ms) {
    for (const auto &a : n.attrs) {
      std::vector<std::pair<size_t, std::string>> refs;
      size_t dataPos = 0;
      std::string m = attrMessage(a, dataPos, refs);
      if (m.size() > 65000) { err = "attribute '" + a.name + "' is larger than 64 KB - store it as a dataset"; return; }
      Message msg{0x0C, m};
      for (const auto &r : refs) msg.refs.push_back({dataPos + r.first, r.second});
      ms.push_back(std::move(msg));
    }
  }

  std::map<uint64_t, std::pair<uint64_t, uint64_t>> groupCache_;
};

} // namespace

std::string writeH5(const H5WNode &root, size_t userblock, std::string &err) {
  Writer w;
  w.ub = userblock;
  w.out.assign(userblock, '\0');
  w.out.append(96, '\0'); // superblock, filled at the end
  if (!root.group) { err = "the root of an HDF5 file is a group"; return ""; }
  uint64_t rootAddr = w.writeNode(root, "/");
  if (!w.err.empty()) { err = w.err; return ""; }
  for (const auto &pr : w.patches) {
    auto it = w.addrOf.find(pr.second);
    if (it == w.addrOf.end()) { err = "a reference points to '" + pr.second + "', which is not in the file"; return ""; }
    setLE(w.out, pr.first, it->second, 8);
  }
  // superblock v0
  std::string sb(reinterpret_cast<const char *>("\x89HDF\r\n\x1a\n"), 8);
  sb += std::string("\0\0\0\0\0\x08\x08\0", 8);
  putLE(sb, Writer::LEAF_K, 2);
  putLE(sb, Writer::GROUP_K, 2);
  putLE(sb, 0, 4);
  putLE(sb, 0, 8);                       // base address
  putLE(sb, H5_UNDEF, 8);                // free space
  putLE(sb, w.out.size() - userblock, 8); // end of file
  putLE(sb, H5_UNDEF, 8);                // driver info
  putLE(sb, 0, 8);                       // root: link name offset
  putLE(sb, rootAddr, 8);
  putLE(sb, 1, 4);
  putLE(sb, 0, 4);
  auto gc = w.groupCache_[rootAddr];
  putLE(sb, gc.first, 8);
  putLE(sb, gc.second, 8);
  std::memcpy(&w.out[userblock], sb.data(), sb.size());
  return w.out;
}

// ---- NC values ----------------------------------------------------------------------------

Value h5ToValue(const H5Value &v) {
  if (v.isCompound) {
    Fields f;
    for (size_t i = 0; i < v.fields.size(); i++) {
      H5Value c = v.fields[i];
      c.shape = v.shape;
      if (v.fields[i].shape.size() > 1) { c.shape.insert(c.shape.end(), v.fields[i].shape.begin() + 1, v.fields[i].shape.end()); }
      f[v.fieldNames[i]] = h5ToValue(c);
    }
    Value d(f);
    return d;
  }
  if (v.isVlen) {
    std::vector<Value> items;
    for (const auto &it : v.items) items.push_back(h5ToValue(it));
    if (items.size() == 1) return items[0];
    return Value(std::move(items));
  }
  if (v.isText) {
    if (v.strs.size() == 1 && v.shape.size() <= 1) return Value(v.strs[0]);
    std::vector<Value> cells;
    for (const auto &s : v.strs) cells.push_back(Value(s));
    if (v.shape.size() == 2) {
      std::vector<std::vector<Value>> rows(v.shape[0]);
      for (size_t r = 0; r < v.shape[0]; r++)
        for (size_t c = 0; c < v.shape[1]; c++) rows[r].push_back(cells[r * v.shape[1] + c]);
      return Value(rows);
    }
    return Value(std::move(cells));
  }
  std::vector<size_t> shape = v.shape;
  if (shape.empty() || (shape.size() == 1 && shape[0] == 1 && v.nums.size() == 1)) return Value(v.nums.empty() ? std::nan("") : v.nums[0]);
  return ndFromRowMajor(shape, v.nums);
}

bool valueToH5(const Value &v, H5WData &out, std::string &err) {
  if (v.isText && !v.isArray && !v.isMatrix) { out = h5ScalarText(v.text()); return true; }
  if (!v.isArray && !v.isMatrix && !v.isText && !v.isDict && !v.isObject) { out = h5ScalarNumber(v.number); return true; }
  if (v.isArray || v.isMatrix) {
    bool anyText = false;
    size_t rows = v.isMatrix ? v.rows() : 1;
    std::vector<std::string> strs;
    std::vector<size_t> shape;
    if (!v.isND()) {
      if (v.isMatrix) for (size_t r = 0; r < v.rows() && !anyText; r++) for (size_t c = 0; c < v.rowLength(r); c++) if (v.at(r, c).isText) { anyText = true; break; }
      if (v.isArray) for (size_t i = 0; i < v.length(); i++) if (v.at(i).isText) { anyText = true; break; }
    }
    if (anyText) {
      if (v.isMatrix) {
        size_t cols = v.rowLength(0);
        for (size_t r = 0; r < rows; r++) for (size_t c = 0; c < cols; c++) strs.push_back(c < v.rowLength(r) ? cellText(v.at(r, c)) : "");
        shape = {rows, cols};
      } else {
        for (size_t i = 0; i < v.length(); i++) strs.push_back(cellText(v.at(i)));
        shape = {v.length()};
      }
      out = h5Texts(shape, strs);
      return true;
    }
    std::vector<double> vals;
    if (!ndToRowMajor(v, shape, vals)) { err = "this value cannot be stored as an HDF5 dataset"; return false; }
    if (shape.size() == 2 && shape[0] == 1) shape = {shape[1]}; // a row vector is 1-D (as h5py / NumPy see it)
    out = h5Numbers(shape, vals);
    return true;
  }
  err = "a dict / object is a group, not a dataset";
  return false;
}

} // namespace io
} // namespace nc
