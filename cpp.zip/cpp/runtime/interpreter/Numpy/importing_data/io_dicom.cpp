// DICOM Part 10 reader / writer (PS3.5 / PS3.10).
// Transfer syntaxes read: implicit VR LE, explicit VR LE/BE, deflated,
// JPEG baseline (1.2.840.10008.1.2.4.50) and RLE lossless. Written: explicit
// VR little endian, Secondary Capture.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>

#include "io_bytes.h"
#include "io_deflate.h"
#include "io_image.h"

namespace nc {
namespace io {

namespace {

struct DTag {
  uint16_t group, elem;
  std::string vr;
  std::string data;
};

const std::map<uint32_t, const char *> &tagNames() {
  static const std::map<uint32_t, const char *> m = {
      {0x00080016, "SOPClassUID"},      {0x00080018, "SOPInstanceUID"},   {0x00080020, "StudyDate"},
      {0x00080030, "StudyTime"},        {0x00080060, "Modality"},         {0x00080070, "Manufacturer"},
      {0x00081030, "StudyDescription"}, {0x0008103E, "SeriesDescription"}, {0x00100010, "PatientName"},
      {0x00100020, "PatientID"},        {0x00100030, "PatientBirthDate"}, {0x00100040, "PatientSex"},
      {0x00101010, "PatientAge"},       {0x00180050, "SliceThickness"},   {0x00180060, "KVP"},
      {0x0020000D, "StudyInstanceUID"}, {0x0020000E, "SeriesInstanceUID"}, {0x00200013, "InstanceNumber"},
      {0x00200032, "ImagePositionPatient"}, {0x00200037, "ImageOrientationPatient"},
      {0x00280002, "SamplesPerPixel"},  {0x00280004, "PhotometricInterpretation"}, {0x00280008, "NumberOfFrames"},
      {0x00280010, "Rows"},             {0x00280011, "Columns"},          {0x00280030, "PixelSpacing"},
      {0x00280100, "BitsAllocated"},    {0x00280101, "BitsStored"},       {0x00280103, "PixelRepresentation"},
      {0x00281050, "WindowCenter"},     {0x00281051, "WindowWidth"},      {0x00281052, "RescaleIntercept"},
      {0x00281053, "RescaleSlope"},     {0x00204000, "ImageComments"},    {0x00020010, "TransferSyntaxUID"}};
  return m;
}

bool isLongVR(const std::string &vr) {
  return vr == "OB" || vr == "OW" || vr == "OF" || vr == "SQ" || vr == "UT" || vr == "UN" || vr == "OD" || vr == "OL" || vr == "UC" || vr == "UR";
}

std::string implicitVR(uint32_t tag) {
  switch (tag) {
    case 0x00280010: case 0x00280011: case 0x00280002: case 0x00280100: case 0x00280101: case 0x00280102: case 0x00280103: return "US";
    case 0x7FE00010: return "OW";
    default: return "";
  }
}

std::string valueText(const DTag &t, bool le) {
  const std::string &d = t.data;
  if (t.vr == "US") return d.size() >= 2 ? std::to_string(le ? u16le(d, 0) : u16be(d, 0)) : "";
  if (t.vr == "SS") return d.size() >= 2 ? std::to_string(static_cast<int16_t>(le ? u16le(d, 0) : u16be(d, 0))) : "";
  if (t.vr == "UL") return d.size() >= 4 ? std::to_string(le ? u32le(d, 0) : u32be(d, 0)) : "";
  if (t.vr == "SL") return d.size() >= 4 ? std::to_string(static_cast<int32_t>(le ? u32le(d, 0) : u32be(d, 0))) : "";
  if (t.vr == "FL") return d.size() >= 4 ? numberText(le ? f32le(d, 0) : f32be(d, 0)) : "";
  if (t.vr == "FD") return d.size() >= 8 ? numberText(le ? f64le(d, 0) : f64be(d, 0)) : "";
  if (isLongVR(t.vr) && t.vr != "UT" && t.vr != "UC" && t.vr != "UR") return "<" + std::to_string(d.size()) + " bytes>";
  std::string s = d;
  while (!s.empty() && (s.back() == ' ' || s.back() == '\0')) s.pop_back();
  return s;
}

bool parseElements(const std::string &b, size_t p, size_t end, bool explicitVR, bool le, std::vector<DTag> &out,
                   bool stopAfterMeta) {
  auto g16 = [&](size_t a) { return le ? u16le(b, a) : u16be(b, a); };
  auto g32 = [&](size_t a) { return le ? u32le(b, a) : u32be(b, a); };
  while (p + 8 <= end) {
    DTag t;
    t.group = g16(p);
    t.elem = g16(p + 2);
    if (stopAfterMeta && t.group != 0x0002) return true;
    uint32_t tag = (static_cast<uint32_t>(t.group) << 16) | t.elem;
    uint32_t len;
    size_t hdr;
    bool ex = explicitVR || t.group == 0x0002;
    if (t.group == 0xFFFE) { // item / delimiters at the top level: skip header
      len = g32(p + 4);
      p += 8;
      if (len != 0xFFFFFFFF && t.elem == 0xE000) p += len;
      continue;
    }
    if (ex) {
      t.vr = b.substr(p + 4, 2);
      if (isLongVR(t.vr)) { len = g32(p + 8); hdr = 12; }
      else { len = g16(p + 6); hdr = 8; }
    } else {
      t.vr = implicitVR(tag);
      len = g32(p + 4);
      hdr = 8;
    }
    p += hdr;
    if (len == 0xFFFFFFFF) {
      if (tag == 0x7FE00010) { // encapsulated pixel data: keep the fragments
        std::string frag;
        while (p + 8 <= end) {
          uint16_t gg = g16(p), ee = g16(p + 2);
          uint32_t l = g32(p + 4);
          p += 8;
          if (gg == 0xFFFE && ee == 0xE0DD) break;
          frag += std::string(1, '\x01') + std::string(reinterpret_cast<const char *>(&l), 4) + b.substr(p, l);
          p += l;
        }
        t.vr = "OB*";
        t.data = frag;
        out.push_back(t);
        continue;
      }
      // undefined-length sequence: skip to its delimiter
      int depth = 1;
      while (p + 8 <= end && depth > 0) {
        uint16_t gg = g16(p), ee = g16(p + 2);
        uint32_t l = g32(p + 4);
        if (gg == 0xFFFE && ee == 0xE0DD) { depth--; p += 8; continue; }
        if (gg == 0xFFFE) { p += 8; continue; }
        // a nested element
        std::string vr = ex ? b.substr(p + 4, 2) : implicitVR((static_cast<uint32_t>(gg) << 16) | ee);
        uint32_t nl;
        size_t h;
        if (ex) { if (isLongVR(vr)) { nl = g32(p + 8); h = 12; } else { nl = g16(p + 6); h = 8; } }
        else { nl = l; h = 8; }
        p += h;
        if (nl == 0xFFFFFFFF) depth++;
        else p += nl;
      }
      continue;
    }
    if (p + len > end) len = static_cast<uint32_t>(end - p);
    t.data = b.substr(p, len);
    p += len;
    out.push_back(t);
  }
  return true;
}

std::string rleDecodeFrame(const std::string &f, size_t expectPerSegment, int segments) {
  std::string out;
  uint32_t n = u32le(f, 0);
  for (uint32_t s = 0; s < n && s < static_cast<uint32_t>(segments); s++) {
    size_t a = u32le(f, 4 + 4 * s), e = s + 1 < n ? u32le(f, 8 + 4 * s) : f.size();
    std::string seg;
    size_t p = a;
    while (p < e && seg.size() < expectPerSegment) {
      int c = static_cast<int8_t>(f[p++]);
      if (c >= 0) { seg.append(f, p, static_cast<size_t>(c + 1)); p += static_cast<size_t>(c + 1); }
      else if (c != -128) { seg.append(static_cast<size_t>(1 - c), f[p++]); }
    }
    seg.resize(expectPerSegment, '\0');
    out += seg;
  }
  return out;
}

} // namespace

bool decodeDicom(const std::string &b, Image &img, std::string &err, bool hu) {
  img = Image();
  size_t start = 0;
  if (b.size() > 132 && b.compare(128, 4, "DICM") == 0) start = 132;
  std::vector<DTag> meta;
  parseElements(b, start, b.size(), true, true, meta, true);
  std::string ts = "1.2.840.10008.1.2";
  size_t dataStart = start;
  for (const auto &t : meta) {
    dataStart += (isLongVR(t.vr) ? 12 : 8) + t.data.size();
    if (t.group == 2 && t.elem == 0x10) ts = valueText(t, true);
  }
  std::string body = b;
  bool explicitVR = ts != "1.2.840.10008.1.2", le = ts != "1.2.840.10008.1.2.2";
  if (ts == "1.2.840.10008.1.2.1.99") { // deflated
    std::string inflated;
    if (!inflateRaw(b.substr(dataStart), 0, inflated, err)) return false;
    body = b.substr(0, dataStart) + inflated;
  }
  std::vector<DTag> tags;
  parseElements(body, dataStart, body.size(), explicitVR, le, tags, false);
  std::map<uint32_t, DTag> byTag;
  for (const auto &t : tags) byTag[(static_cast<uint32_t>(t.group) << 16) | t.elem] = t;
  auto text = [&](uint32_t tag) { auto it = byTag.find(tag); return it == byTag.end() ? std::string() : valueText(it->second, le); };
  auto num = [&](uint32_t tag, double def) {
    std::string s = text(tag);
    if (s.empty()) return def;
    return std::strtod(s.c_str(), nullptr);
  };
  Fields all;
  for (const auto &t : tags) {
    uint32_t tag = (static_cast<uint32_t>(t.group) << 16) | t.elem;
    if (tag == 0x7FE00010) continue;
    char key[16];
    std::snprintf(key, sizeof key, "(%04X,%04X)", t.group, t.elem);
    auto nm = tagNames().find(tag);
    all[nm != tagNames().end() ? nm->second : key] = Value(valueText(t, le));
  }
  img.extra["tags"] = Value(all);
  img.extra["transfer_syntax"] = Value(ts);
  if (!byTag.count(0x7FE00010)) {
    err = "the DICOM file has no pixel data";
    return false;
  }
  size_t rows = static_cast<size_t>(num(0x00280010, 0)), cols = static_cast<size_t>(num(0x00280011, 0));
  int bits = static_cast<int>(num(0x00280100, 16)), spp = static_cast<int>(num(0x00280002, 1));
  bool sign = num(0x00280103, 0) == 1;
  size_t frames = static_cast<size_t>(std::max(1.0, num(0x00280008, 1)));
  std::string photo = text(0x00280004);
  double slope = num(0x00281053, 1), intercept = num(0x00281052, 0);
  const DTag &pix = byTag[0x7FE00010];
  std::vector<std::string> frameData;
  if (pix.vr == "OB*") { // fragments: first is the offset table
    std::vector<std::string> frags;
    size_t p = 0;
    while (p + 5 <= pix.data.size()) {
      uint32_t l;
      std::memcpy(&l, pix.data.data() + p + 1, 4);
      frags.push_back(pix.data.substr(p + 5, l));
      p += 5 + l;
    }
    if (!frags.empty()) frags.erase(frags.begin());
    if (ts.rfind("1.2.840.10008.1.2.4.", 0) == 0) {
      if (ts != "1.2.840.10008.1.2.4.50" && ts != "1.2.840.10008.1.2.4.51") {
        err = "DICOM compression " + ts + " (JPEG lossless / JPEG 2000 / JPEG-LS) is not built in";
        return false;
      }
      std::string all1;
      for (const auto &f : frags) all1 += f;
      // one JPEG per frame: split on SOI markers
      size_t s = 0;
      while ((s = all1.find("\xFF\xD8\xFF", s)) != std::string::npos) {
        size_t e = all1.find("\xFF\xD8\xFF", s + 3);
        frameData.push_back(all1.substr(s, e == std::string::npos ? std::string::npos : e - s));
        s = e == std::string::npos ? all1.size() : e;
      }
      std::vector<Image> imgs;
      for (const auto &fd : frameData) {
        Image fi;
        if (!decodeJpeg(fd, fi, err)) return false;
        imgs.push_back(std::move(fi));
      }
      if (imgs.empty()) { err = "no JPEG frames in the DICOM pixel data"; return false; }
      img.width = imgs[0].width; img.height = imgs[0].height; img.channels = imgs[0].channels; img.px = imgs[0].px;
      for (size_t k = 1; k < imgs.size(); k++) img.frames.push_back(imgs[k]);
      return true;
    }
    if (ts == "1.2.840.10008.1.2.5") {
      for (const auto &f : frags) frameData.push_back(rleDecodeFrame(f, rows * cols, spp * (bits / 8)));
      // RLE stores most significant byte segments first: re-interleave to little endian
      for (auto &fd : frameData) {
        size_t n = rows * cols, bytes = static_cast<size_t>(bits / 8);
        std::string o(fd.size(), '\0');
        for (int s = 0; s < spp; s++)
          for (size_t i = 0; i < n; i++)
            for (size_t k = 0; k < bytes; k++)
              o[(i * static_cast<size_t>(spp) + static_cast<size_t>(s)) * bytes + k] = fd[(static_cast<size_t>(s) * bytes + (bytes - 1 - k)) * n + i];
        fd = o;
      }
      le = true;
    } else {
      err = "DICOM transfer syntax " + ts + " is not built in";
      return false;
    }
  } else {
    size_t per = rows * cols * static_cast<size_t>(spp) * static_cast<size_t>(bits / 8);
    for (size_t f = 0; f < frames; f++)
      frameData.push_back(per * (f + 1) <= pix.data.size() ? pix.data.substr(per * f, per) : std::string(per, '\0'));
  }
  std::vector<Image> imgs;
  for (const auto &fd : frameData) {
    Image fi;
    fi.width = cols;
    fi.height = rows;
    fi.channels = static_cast<size_t>(spp);
    fi.bitDepth = bits > 8 ? 16 : 8;
    fi.px.resize(rows * cols * static_cast<size_t>(spp));
    size_t bytes = static_cast<size_t>(bits / 8);
    bool rescale = hu && (slope != 1 || intercept != 0);
    for (size_t i = 0; i < fi.px.size(); i++) {
      uint64_t u = le ? getLE(fd, i * bytes, static_cast<int>(bytes)) : getBE(fd, i * bytes, static_cast<int>(bytes));
      double v = sign ? static_cast<double>(static_cast<int64_t>(u << (64 - 8 * bytes)) >> (64 - 8 * bytes)) : static_cast<double>(u);
      if (rescale) v = v * slope + intercept;
      if (photo == "MONOCHROME1" && !rescale) v = (bits > 8 ? 65535.0 : 255.0) - v;
      fi.px[i] = v;
    }
    if (rescale || sign) fi.isFloat = true; // values are not image levels any more
    if (rescale || sign) fi.bitDepth = 32;
    fi.colorSpace = spp == 1 ? "Grayscale" : "sRGB";
    imgs.push_back(std::move(fi));
  }
  img.width = imgs[0].width; img.height = imgs[0].height; img.channels = imgs[0].channels;
  img.bitDepth = imgs[0].bitDepth; img.isFloat = imgs[0].isFloat; img.px = imgs[0].px; img.colorSpace = imgs[0].colorSpace;
  for (size_t k = 1; k < imgs.size(); k++) img.frames.push_back(imgs[k]);
  std::string sp = text(0x00280030);
  size_t bs = sp.find('\\');
  if (bs != std::string::npos) {
    double rmm = std::strtod(sp.c_str(), nullptr), cmm = std::strtod(sp.c_str() + bs + 1, nullptr);
    if (cmm > 0) { img.dpiX = 25.4 / cmm; img.dpiY = rmm > 0 ? 25.4 / rmm : img.dpiX; }
  }
  if (!text(0x00204000).empty()) img.text.push_back({"ImageComments", text(0x00204000)});
  return true;
}

std::string encodeDicom(const Image &imgIn, const Fields &patient, bool anonymize) {
  Image img = imgIn;
  if (img.channels == 2) img = convertChannels(img, "gray");
  if (img.channels == 4) img = convertChannels(img, "rgb");
  bool sixteen = img.bitDepth >= 16 || img.isFloat;
  if (img.isFloat) { // [0,1] floats -> 16-bit
    for (double &v : img.px) v = std::round(std::clamp(v, 0.0, 1.0) * 65535.0);
  }
  std::string o(128, '\0');
  o += "DICM";
  auto el = [&](std::string &dst, uint16_t g, uint16_t e, const std::string &vr, std::string val) {
    if (vr != "OB" && vr != "OW" && val.size() % 2) val.push_back(vr == "UI" ? '\0' : ' ');
    if (val.size() % 2) val.push_back('\0');
    putLE(dst, g, 2);
    putLE(dst, e, 2);
    dst += vr;
    if (isLongVR(vr)) { putLE(dst, 0, 2); putLE(dst, val.size(), 4); }
    else putLE(dst, val.size(), 2);
    dst += val;
  };
  auto us = [](uint16_t v) { std::string s; putLE(s, v, 2); return s; };
  const std::string sopClass = "1.2.840.10008.5.1.4.1.1.7"; // Secondary Capture
  const std::string uidRoot = "2.25.";
  uint64_t h = 1469598103934665603ull;
  for (double v : img.px) { h ^= static_cast<uint64_t>(v); h *= 1099511628211ull; }
  std::string inst = uidRoot + std::to_string(h % 100000000000000000ull);
  std::string meta;
  el(meta, 2, 1, "OB", std::string("\0\1", 2));
  el(meta, 2, 2, "UI", sopClass);
  el(meta, 2, 3, "UI", inst);
  el(meta, 2, 0x10, "UI", "1.2.840.10008.1.2.1");
  el(meta, 2, 0x12, "UI", "1.2.826.0.1.3680043.10.1");
  std::string len;
  el(len, 2, 0, "UL", std::string("\0\0\0\0", 4));
  setLE(len, 8, meta.size(), 4);
  o += len + meta;
  auto pv = [&](const char *k, const std::string &def) {
    auto it = patient.find(k);
    if (it == patient.end()) { std::string kk = std::string("Patient") + k; it = patient.find(kk); }
    return it == patient.end() ? def : cellText(it->second);
  };
  std::string ds;
  el(ds, 8, 0x16, "UI", sopClass);
  el(ds, 8, 0x18, "UI", inst);
  el(ds, 8, 0x60, "CS", "OT");
  el(ds, 0x10, 0x10, "PN", anonymize ? "Anonymous" : pv("Name", "Anonymous"));
  el(ds, 0x10, 0x20, "LO", anonymize ? "ANON" : pv("ID", ""));
  el(ds, 0x10, 0x30, "DA", anonymize ? "" : pv("BirthDate", ""));
  el(ds, 0x10, 0x40, "CS", anonymize ? "" : pv("Sex", ""));
  std::string comment;
  for (const auto &t : img.text) comment += (comment.empty() ? "" : "; ") + (t.first == "ImageComments" ? "" : t.first + ": ") + t.second;
  if (!comment.empty()) el(ds, 0x20, 0x4000, "LT", comment);
  el(ds, 0x28, 0x02, "US", us(static_cast<uint16_t>(img.channels)));
  el(ds, 0x28, 0x04, "CS", img.channels == 1 ? "MONOCHROME2" : "RGB");
  if (img.channels == 3) el(ds, 0x28, 0x06, "US", us(0));
  el(ds, 0x28, 0x10, "US", us(static_cast<uint16_t>(img.height)));
  el(ds, 0x28, 0x11, "US", us(static_cast<uint16_t>(img.width)));
  if (img.dpiX > 0) {
    std::string mm = numberText(25.4 / (img.dpiY > 0 ? img.dpiY : img.dpiX)) + "\\" + numberText(25.4 / img.dpiX);
    el(ds, 0x28, 0x30, "DS", mm);
  }
  el(ds, 0x28, 0x100, "US", us(sixteen ? 16 : 8));
  el(ds, 0x28, 0x101, "US", us(sixteen ? 16 : 8));
  el(ds, 0x28, 0x102, "US", us(sixteen ? 15 : 7));
  el(ds, 0x28, 0x103, "US", us(0));
  std::string px;
  for (double v : img.px) putLE(px, static_cast<uint64_t>(std::clamp(std::round(v), 0.0, sixteen ? 65535.0 : 255.0)), sixteen ? 2 : 1);
  el(ds, 0x7FE0, 0x10, sixteen ? "OW" : "OB", px);
  return o + ds;
}

} // namespace io
} // namespace nc
