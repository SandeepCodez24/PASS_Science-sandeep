// CATEGORY 12 - FITS: read_/load_/save_ fits, fit (FITS 4.0: images, binary and
// ASCII tables, tile-compressed images RICE_1 / GZIP_1, linear and TAN WCS).
#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_common.h"
#include "io_deflate.h"
#include "io_formats.h"

namespace nc {
namespace io {

std::string upperAscii(std::string s);

namespace {

struct Card {
  std::string key, value, comment;
};

struct Hdu {
  std::vector<Card> cards;
  std::string type; // PRIMARY, IMAGE, BINTABLE, TABLE, COMPRESSED_IMAGE
  std::string name;
  size_t dataStart = 0, dataSize = 0, heapSize = 0;
  const Card *find(const std::string &k) const {
    for (const auto &c : cards) if (c.key == k) return &c;
    return nullptr;
  }
  std::string str(const std::string &k, const std::string &def = "") const {
    const Card *c = find(k);
    if (!c) return def;
    std::string v = trim(c->value);
    if (v.size() >= 2 && v[0] == '\'') {
      v = v.substr(1, v.rfind('\'') - 1);
      std::string o;
      for (size_t i = 0; i < v.size(); i++) { o.push_back(v[i]); if (v[i] == '\'' && i + 1 < v.size() && v[i + 1] == '\'') i++; }
      return trim(o);
    }
    return v;
  }
  double num(const std::string &k, double def) const {
    const Card *c = find(k);
    if (!c) return def;
    std::string v = trim(c->value);
    for (char &ch : v) if (ch == 'D') ch = 'E';
    char *e = nullptr;
    double d = std::strtod(v.c_str(), &e);
    return e == v.c_str() ? def : d;
  }
  bool flag(const std::string &k) const { const Card *c = find(k); return c && trim(c->value) == "T"; }
};

bool parseHdus(const std::string &b, std::vector<Hdu> &out, std::string &err) {
  size_t p = 0;
  while (p + 2880 <= b.size()) {
    Hdu h;
    bool end = false;
    while (!end && p + 80 <= b.size()) {
      std::string card = b.substr(p, 80);
      p += 80;
      Card c;
      c.key = trim(card.substr(0, 8));
      if (c.key == "END") { end = true; break; }
      if (card.size() > 9 && card[8] == '=' && card[9] == ' ') {
        std::string rest = card.substr(10);
        // value / comment, respecting quotes
        bool q = false;
        size_t slash = std::string::npos;
        for (size_t i = 0; i < rest.size(); i++) {
          if (rest[i] == '\'') q = !q;
          else if (rest[i] == '/' && !q) { slash = i; break; }
        }
        c.value = trim(rest.substr(0, slash));
        if (slash != std::string::npos) c.comment = trim(rest.substr(slash + 1));
      } else {
        c.value = trim(card.substr(8));
      }
      if (c.key == "HIERARCH") { // HIERARCH long.key = value
        size_t eq = c.value.find('=');
        if (eq != std::string::npos) { c.key = trim(c.value.substr(0, eq)); c.value = trim(c.value.substr(eq + 1)); }
      }
      if (!c.key.empty()) h.cards.push_back(c);
    }
    if (!end) break;
    p = (p + 2879) / 2880 * 2880;
    h.type = out.empty() ? "PRIMARY" : h.str("XTENSION", "IMAGE");
    if (h.flag("ZIMAGE")) h.type = "COMPRESSED_IMAGE";
    h.name = h.str("EXTNAME", out.empty() ? "PRIMARY" : "");
    size_t naxis = static_cast<size_t>(h.num("NAXIS", 0));
    size_t n = naxis ? 1 : 0;
    for (size_t k = 1; k <= naxis; k++) n *= static_cast<size_t>(h.num("NAXIS" + std::to_string(k), 0));
    size_t bytes = n * static_cast<size_t>(std::abs(h.num("BITPIX", 8))) / 8;
    bytes = (bytes + static_cast<size_t>(h.num("PCOUNT", 0))) * static_cast<size_t>(h.num("GCOUNT", 1));
    h.dataStart = p;
    h.dataSize = bytes;
    p += (bytes + 2879) / 2880 * 2880;
    out.push_back(std::move(h));
  }
  if (out.empty()) {
    err = "not a FITS file (no header ending in END)";
    return false;
  }
  return true;
}

double rawValue(const std::string &b, size_t at, int bitpix) {
  switch (bitpix) {
    case 8: return static_cast<unsigned char>(b[at]);
    case 16: return static_cast<int16_t>(u16be(b, at));
    case 32: return static_cast<int32_t>(u32be(b, at));
    case 64: return static_cast<double>(static_cast<int64_t>(u64be(b, at)));
    case -32: return f32be(b, at);
    case -64: return f64be(b, at);
  }
  return 0;
}

// ---- tile compression ---------------------------------------------------------------

bool riceDecode(const std::string &in, size_t n, int bytepix, int blocksize, std::vector<int64_t> &out) {
  int fsbits = bytepix == 1 ? 3 : bytepix == 2 ? 4 : 5, fsmax = bytepix == 1 ? 6 : bytepix == 2 ? 14 : 25, bbits = 8 * bytepix;
  size_t bit = 0;
  auto bits = [&](int k) {
    uint64_t v = 0;
    for (int i = 0; i < k; i++, bit++)
      v = (v << 1) | (bit / 8 < in.size() ? ((static_cast<unsigned char>(in[bit / 8]) >> (7 - bit % 8)) & 1) : 0);
    return v;
  };
  out.assign(n, 0);
  int64_t last = static_cast<int64_t>(bits(bbits));
  if (bytepix == 2) last = static_cast<int16_t>(last); else if (bytepix == 4) last = static_cast<int32_t>(last); else if (bytepix == 1) last = static_cast<int8_t>(last);
  for (size_t i = 0; i < n;) {
    int fs = static_cast<int>(bits(fsbits)) - 1;
    size_t end = std::min(n, i + static_cast<size_t>(blocksize));
    for (; i < end; i++) {
      uint64_t diff;
      if (fs < 0) diff = 0;
      else if (fs == fsmax) diff = bits(bbits);
      else {
        uint64_t z = 0;
        while (bit / 8 < in.size() && bits(1) == 0) z++;
        diff = (z << fs) | bits(fs);
      }
      int64_t d = (diff & 1) ? ~static_cast<int64_t>(diff >> 1) : static_cast<int64_t>(diff >> 1);
      last += d;
      if (bytepix == 2) last = static_cast<int16_t>(last); else if (bytepix == 4) last = static_cast<int32_t>(last);
      out[i] = last;
    }
  }
  return true;
}

std::string riceEncode(const std::vector<int64_t> &x, int bytepix, int blocksize) {
  int fsbits = bytepix == 1 ? 3 : bytepix == 2 ? 4 : 5, fsmax = bytepix == 1 ? 6 : bytepix == 2 ? 14 : 25, bbits = 8 * bytepix;
  std::string out;
  uint64_t buf = 0;
  int cnt = 0;
  auto put = [&](uint64_t v, int k) {
    for (int i = k - 1; i >= 0; i--) {
      buf = (buf << 1) | ((v >> i) & 1);
      if (++cnt == 8) { out.push_back(static_cast<char>(buf)); buf = 0; cnt = 0; }
    }
  };
  if (x.empty()) return out;
  int64_t last = x[0];
  put(static_cast<uint64_t>(last), bbits);
  for (size_t i = 0; i < x.size(); i += static_cast<size_t>(blocksize)) {
    size_t end = std::min(x.size(), i + static_cast<size_t>(blocksize));
    std::vector<uint64_t> d;
    double sum = 0;
    for (size_t k = i; k < end; k++) {
      int64_t diff = x[k] - last;
      if (bytepix == 2) diff = static_cast<int16_t>(diff); else if (bytepix == 4) diff = static_cast<int32_t>(diff);
      uint64_t z = diff < 0 ? ~(static_cast<uint64_t>(diff) << 1) : static_cast<uint64_t>(diff) << 1;
      if (bytepix == 2) z &= 0xFFFF; else if (bytepix == 4) z &= 0xFFFFFFFF;
      d.push_back(z);
      sum += static_cast<double>(z);
      last = x[k];
    }
    double mean = sum / d.size();
    if (sum == 0) { put(0, fsbits); continue; }
    int fs = 0;
    while (fs < fsmax && std::ldexp(1.0, fs + 1) <= mean) fs++;
    if (fs >= fsmax) {
      put(static_cast<uint64_t>(fsmax + 1), fsbits);
      for (uint64_t z : d) put(z, bbits);
      continue;
    }
    put(static_cast<uint64_t>(fs + 1), fsbits);
    for (uint64_t z : d) {
      uint64_t top = z >> fs;
      for (uint64_t k = 0; k < top; k++) put(0, 1);
      put(1, 1);
      if (fs) put(z & ((1ull << fs) - 1), fs);
    }
  }
  while (cnt) put(0, 1);
  return out;
}

double ditherRandom(size_t k) { // FITS standard random sequence (Park-Miller)
  static std::vector<double> table;
  if (table.empty()) {
    double a = 16807.0, m = 2147483647.0, seed = 1;
    for (int i = 0; i < 10000; i++) {
      double t = a * seed;
      seed = t - m * static_cast<long long>(t / m);
      table.push_back(seed / m);
    }
  }
  return table[k % 10000];
}

bool decompressImage(const std::string &b, const Hdu &h, std::vector<size_t> &shape, std::vector<double> &vals, std::string &err) {
  size_t znaxis = static_cast<size_t>(h.num("ZNAXIS", 0));
  std::vector<size_t> dims, tile;
  for (size_t k = 1; k <= znaxis; k++) {
    dims.push_back(static_cast<size_t>(h.num("ZNAXIS" + std::to_string(k), 0)));
    tile.push_back(static_cast<size_t>(h.num("ZTILE" + std::to_string(k), k == 1 ? dims.back() : 1)));
  }
  std::string cmp = h.str("ZCMPTYPE");
  int zbitpix = static_cast<int>(h.num("ZBITPIX", 16));
  int blocksize = 32, bytepix = std::abs(zbitpix) / 8;
  for (int k = 1; k <= 4; k++) {
    std::string name = h.str("ZNAME" + std::to_string(k));
    if (name == "BLOCKSIZE") blocksize = static_cast<int>(h.num("ZVAL" + std::to_string(k), 32));
    if (name == "BYTEPIX") bytepix = static_cast<int>(h.num("ZVAL" + std::to_string(k), bytepix));
  }
  size_t ncols = static_cast<size_t>(h.num("TFIELDS", 0)), rowBytes = static_cast<size_t>(h.num("NAXIS1", 0)), nrows = static_cast<size_t>(h.num("NAXIS2", 0));
  size_t heap = h.dataStart + static_cast<size_t>(h.num("THEAP", static_cast<double>(rowBytes * nrows)));
  std::map<std::string, std::pair<size_t, std::string>> cols; // name -> offset, form
  size_t off = 0;
  for (size_t c = 1; c <= ncols; c++) {
    std::string form = h.str("TFORM" + std::to_string(c)), name = h.str("TTYPE" + std::to_string(c));
    cols[name] = {off, form};
    size_t rep = 1, i = 0;
    while (i < form.size() && std::isdigit(static_cast<unsigned char>(form[i]))) i++;
    if (i) rep = static_cast<size_t>(std::atoll(form.substr(0, i).c_str()));
    char t = i < form.size() ? form[i] : 'J';
    size_t sz = t == 'P' ? 8 : t == 'Q' ? 16 : t == 'E' || t == 'J' ? 4 : t == 'D' || t == 'K' ? 8 : t == 'I' ? 2 : 1;
    off += rep * sz;
  }
  if (!cols.count("COMPRESSED_DATA")) { err = "compressed FITS HDU without COMPRESSED_DATA"; return false; }
  size_t total = 1;
  for (size_t d : dims) total *= d;
  shape.assign(dims.rbegin(), dims.rend());
  vals.assign(total, 0);
  std::vector<size_t> ntile(dims.size());
  for (size_t d = 0; d < dims.size(); d++) ntile[d] = (dims[d] + tile[d] - 1) / tile[d];
  for (size_t row = 0; row < nrows; row++) {
    size_t rb = h.dataStart + row * rowBytes;
    auto desc = cols["COMPRESSED_DATA"];
    bool q = desc.second.find('Q') != std::string::npos;
    size_t len = q ? static_cast<size_t>(u64be(b, rb + desc.first)) : u32be(b, rb + desc.first);
    size_t pos = q ? static_cast<size_t>(u64be(b, rb + desc.first + 8)) : u32be(b, rb + desc.first + 4);
    double zscale = 1, zzero = 0;
    bool quantized = cols.count("ZSCALE");
    if (quantized) { zscale = f64be(b, rb + cols["ZSCALE"].first); zzero = cols.count("ZZERO") ? f64be(b, rb + cols["ZZERO"].first) : 0; }
    // tile coordinates
    std::vector<size_t> t0(dims.size()), tn(dims.size());
    size_t rem = row, count = 1;
    for (size_t d = 0; d < dims.size(); d++) {
      size_t ti = rem % ntile[d];
      rem /= ntile[d];
      t0[d] = ti * tile[d];
      tn[d] = std::min(tile[d], dims[d] - t0[d]);
      count *= tn[d];
    }
    std::string data = b.substr(heap + pos, len);
    std::vector<double> tv(count, 0);
    if (cmp == "RICE_1" || cmp == "RICE_ONE") {
      std::vector<int64_t> iv;
      riceDecode(data, count, bytepix, blocksize, iv);
      for (size_t k = 0; k < count; k++) tv[k] = static_cast<double>(iv[k]);
    } else if (cmp == "GZIP_1" || cmp == "GZIP_2") {
      std::string raw;
      if (!gzipDecompress(data, raw, err) || raw.empty()) {
        if (!zlibDecompress(data, raw, err)) { err = "damaged GZIP tile: " + err; return false; }
      }
      int bp = quantized ? 32 : zbitpix;
      size_t sz = static_cast<size_t>(std::abs(bp) / 8);
      if (cmp == "GZIP_2") { // byte-shuffled
        std::string u(raw.size(), '\0');
        size_t m = raw.size() / sz;
        for (size_t k = 0; k < m; k++) for (size_t j = 0; j < sz; j++) u[k * sz + j] = raw[j * m + k];
        raw = u;
      }
      for (size_t k = 0; k < count && (k + 1) * sz <= raw.size(); k++) tv[k] = rawValue(raw, k * sz, bp);
    } else {
      err = "FITS tile compression " + cmp + " is not built in (RICE_1 and GZIP_1 are)";
      return false;
    }
    if (quantized) {
      std::string zq = h.str("ZQUANTIZ", "NO_DITHER");
      long long seed = static_cast<long long>(h.num("ZDITHER0", 1));
      size_t ir = static_cast<size_t>((seed - 1 + static_cast<long long>(row)) % 10000);
      size_t ic = static_cast<size_t>(ditherRandom(ir) * 500);
      for (size_t k = 0; k < count; k++) {
        if (zq.find("DITHER") != std::string::npos && zq != "NO_DITHER") {
          tv[k] = tv[k] == -2147483647.0 ? std::nan("") : (tv[k] - ditherRandom(ic) + 0.5) * zscale + zzero;
          ic++;
          if (ic >= 10000) { ir = (ir + 1) % 10000; ic = static_cast<size_t>(ditherRandom(ir) * 500); }
        } else {
          tv[k] = tv[k] * zscale + zzero;
        }
      }
    }
    // place tile (dims[0] fastest)
    std::vector<size_t> idx(dims.size(), 0);
    for (size_t k = 0; k < count; k++) {
      size_t r2 = k, flat = 0, mul = 1;
      for (size_t d = 0; d < dims.size(); d++) {
        size_t i = r2 % tn[d];
        r2 /= tn[d];
        flat += (t0[d] + i) * mul;
        mul *= dims[d];
      }
      vals[flat] = tv[k];
    }
  }
  double bscale = h.num("BSCALE", 1), bzero = h.num("BZERO", 0);
  if (bscale != 1 || bzero != 0) for (double &v : vals) v = v * bscale + bzero;
  return true;
}

// ---- HDU -> values -------------------------------------------------------------------

bool imageData(const std::string &b, const Hdu &h, bool scale, std::vector<size_t> &shape, std::vector<double> &vals, std::string &err) {
  if (h.type == "COMPRESSED_IMAGE") return decompressImage(b, h, shape, vals, err);
  int bitpix = static_cast<int>(h.num("BITPIX", 8));
  size_t naxis = static_cast<size_t>(h.num("NAXIS", 0));
  shape.clear();
  for (size_t k = naxis; k >= 1; k--) shape.push_back(static_cast<size_t>(h.num("NAXIS" + std::to_string(k), 0)));
  size_t n = 1;
  for (size_t d : shape) n *= d;
  if (!naxis) n = 0;
  size_t sz = static_cast<size_t>(std::abs(bitpix) / 8);
  if (h.dataStart + n * sz > b.size()) { err = "FITS data ends early"; return false; }
  double bscale = scale ? h.num("BSCALE", 1) : 1, bzero = scale ? h.num("BZERO", 0) : 0;
  const Card *blank = h.find("BLANK");
  double blankV = blank ? h.num("BLANK", 0) : 0;
  vals.resize(n);
  for (size_t k = 0; k < n; k++) {
    double v = rawValue(b, h.dataStart + k * sz, bitpix);
    vals[k] = (blank && bitpix > 0 && v == blankV) ? std::nan("") : v * bscale + bzero;
  }
  return true;
}

bool fitsTable(const std::string &b, const Hdu &h, bool scale, Table &t, std::string &err) {
  t = Table();
  size_t ncols = static_cast<size_t>(h.num("TFIELDS", 0)), rowBytes = static_cast<size_t>(h.num("NAXIS1", 0)), nrows = static_cast<size_t>(h.num("NAXIS2", 0));
  bool ascii = h.type == "TABLE";
  struct Col { std::string name, form; size_t off, rep; char type; double tscal, tzero; };
  std::vector<Col> cols;
  size_t off = 0;
  for (size_t c = 1; c <= ncols; c++) {
    Col col;
    std::string s = std::to_string(c);
    col.name = h.str("TTYPE" + s, "Col_" + s);
    col.form = h.str("TFORM" + s);
    col.tscal = scale ? h.num("TSCAL" + s, 1) : 1;
    col.tzero = scale ? h.num("TZERO" + s, 0) : 0;
    size_t i = 0;
    if (ascii) {
      col.off = static_cast<size_t>(h.num("TBCOL" + s, 1)) - 1;
      col.type = col.form.empty() ? 'A' : col.form[0];
      col.rep = static_cast<size_t>(std::atoll(col.form.substr(1).c_str()));
    } else {
      while (i < col.form.size() && std::isdigit(static_cast<unsigned char>(col.form[i]))) i++;
      col.rep = i ? static_cast<size_t>(std::atoll(col.form.substr(0, i).c_str())) : 1;
      col.type = i < col.form.size() ? col.form[i] : 'J';
      col.off = off;
      size_t sz = col.type == 'L' || col.type == 'B' || col.type == 'A' ? 1 : col.type == 'I' ? 2 : col.type == 'J' || col.type == 'E' ? 4
                  : col.type == 'K' || col.type == 'D' || col.type == 'C' || col.type == 'P' ? 8 : col.type == 'M' || col.type == 'Q' ? 16 : 1;
      if (col.type == 'X') sz = 0, off += (col.rep + 7) / 8;
      off += col.rep * sz;
    }
    cols.push_back(col);
    t.cols.push_back(col.name);
  }
  if (h.dataStart + rowBytes * nrows > b.size()) { err = "FITS table data ends early"; return false; }
  for (size_t r = 0; r < nrows; r++) {
    size_t rb = h.dataStart + r * rowBytes;
    std::vector<Value> row;
    for (const auto &c : cols) {
      if (ascii) {
        std::string txt = trim(b.substr(rb + c.off, c.rep));
        if (c.type == 'A') row.push_back(Value(txt));
        else {
          for (char &ch : txt) if (ch == 'D') ch = 'E';
          row.push_back(txt.empty() ? Value(std::nan("")) : Value(std::strtod(txt.c_str(), nullptr) * c.tscal + c.tzero));
        }
        continue;
      }
      if (c.type == 'A') {
        std::string s = b.substr(rb + c.off, c.rep);
        s = s.substr(0, s.find('\0'));
        row.push_back(Value(trim(s)));
        continue;
      }
      std::vector<Value> items;
      for (size_t k = 0; k < c.rep; k++) {
        size_t at = rb + c.off;
        Value v;
        switch (c.type) {
          case 'L': v = Value::boolean(b[at + k] == 'T'); break;
          case 'B': v = Value(static_cast<unsigned char>(b[at + k]) * c.tscal + c.tzero); break;
          case 'I': v = Value(static_cast<int16_t>(u16be(b, at + 2 * k)) * c.tscal + c.tzero); break;
          case 'J': v = Value(static_cast<int32_t>(u32be(b, at + 4 * k)) * c.tscal + c.tzero); break;
          case 'K': v = Value(static_cast<double>(static_cast<int64_t>(u64be(b, at + 8 * k))) * c.tscal + c.tzero); break;
          case 'E': v = Value(f32be(b, at + 4 * k) * c.tscal + c.tzero); break;
          case 'D': v = Value(f64be(b, at + 8 * k) * c.tscal + c.tzero); break;
          case 'C': v = Value::complexNumber(f32be(b, at + 8 * k), f32be(b, at + 8 * k + 4)); break;
          case 'M': v = Value::complexNumber(f64be(b, at + 16 * k), f64be(b, at + 16 * k + 8)); break;
          case 'X': v = Value::boolean((static_cast<unsigned char>(b[at + k / 8]) >> (7 - k % 8)) & 1); break;
          default: v = Value(std::string("<variable-length>"));
        }
        items.push_back(v);
      }
      if (c.rep == 0) row.push_back(Value(std::nan("")));
      else if (items.size() == 1) row.push_back(items[0]);
      else {
        bool num = std::all_of(items.begin(), items.end(), [](const Value &x) { return isNumberCell(x); });
        if (num) { std::vector<double> d; for (auto &x : items) d.push_back(x.number); row.push_back(numberList(d)); }
        else row.push_back(Value(items));
      }
    }
    t.rows.push_back(std::move(row));
  }
  normalizeTable(t);
  return true;
}

Value headerDict(const Hdu &h) {
  Fields f;
  for (const auto &c : h.cards) {
    if (c.key == "COMMENT" || c.key == "HISTORY" || c.key.empty()) continue;
    std::string v = c.value;
    if (!v.empty() && v[0] == '\'') f[c.key] = Value(h.str(c.key));
    else if (v == "T" || v == "F") f[c.key] = Value::boolean(v == "T");
    else f[c.key] = parseCell(v, {});
  }
  return Value(f);
}

std::vector<std::string> commentCards(const Hdu &h) {
  std::vector<std::string> out;
  for (const auto &c : h.cards) if (c.key == "COMMENT" || c.key == "HISTORY") out.push_back(c.key + " " + c.value);
  return out;
}

Value wcsOf(const Hdu &h) {
  Fields f;
  for (const char *k : {"CTYPE1", "CTYPE2", "CRPIX1", "CRPIX2", "CRVAL1", "CRVAL2", "CDELT1", "CDELT2", "CD1_1", "CD1_2", "CD2_1", "CD2_2", "CUNIT1", "CUNIT2", "RADESYS", "EQUINOX"})
    if (h.find(k)) f[k] = h.str(k).empty() ? Value(h.num(k, 0)) : (std::isdigit(static_cast<unsigned char>(h.str(k)[0])) || h.str(k)[0] == '-' ? Value(h.num(k, 0)) : Value(h.str(k)));
  return makeObject("NcWcs", f);
}


bool openFits(const std::string &file, std::string &bytes, std::vector<Hdu> &hdus, std::string &err) {
  if (!readSource(file, bytes, err) || !autoDecompress(bytes, err)) return false;
  if (bytes.compare(0, 9, "SIMPLE  =") != 0) { err = "not a FITS file (it must start with SIMPLE  = T)"; return false; }
  return parseHdus(bytes, hdus, err);
}

bool pickHdu(const std::vector<Hdu> &hdus, const Value &sel, long long ver, size_t &idx, std::string &err) {
  if (!given(sel) || (numpy::isPlainNumber(sel) && sel.number < 0)) { // first HDU with data
    idx = 0;
    for (size_t k = 0; k < hdus.size(); k++) if (hdus[k].dataSize > 0 || hdus[k].type == "COMPRESSED_IMAGE") { idx = k; break; }
    return true;
  }
  if (numpy::isPlainNumber(sel) && !sel.isText) {
    size_t k = static_cast<size_t>(sel.number);
    if (k >= hdus.size()) { err = "hdu " + std::to_string(k) + " does not exist (the file has " + std::to_string(hdus.size()) + ", numbered from 0)"; return false; }
    idx = k;
    return true;
  }
  std::string want = upperAscii(optText(sel));
  long long seen = 0;
  for (size_t k = 0; k < hdus.size(); k++)
    if (upperAscii(hdus[k].name) == want && ++seen >= std::max(1LL, ver)) { idx = k; return true; }
  err = "no HDU with EXTNAME '" + want + "'";
  return false;
}

Value hduValue(const std::string &b, const Hdu &h, bool scale, std::string &err, std::vector<std::string> *cols) {
  if (h.type == "BINTABLE" || h.type == "TABLE") {
    Table t;
    if (!fitsTable(b, h, scale, t, err)) return Value(0.0);
    if (cols) *cols = t.cols;
    return tableData(t);
  }
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!imageData(b, h, scale, shape, vals, err)) return Value(0.0);
  if (vals.empty()) return numpy::makeMatrix(std::vector<std::vector<double>>{});
  return ndFromRowMajor(shape, vals);
}

// read_<fmt>(file, hdu, ver, slice, cols, scale, box)
void readFits(const std::string &fn, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev(fn, file);
  std::vector<Hdu> hdus;
  if (!openFits(file, bytes, hdus, err)) return ctx.fail(err);
  size_t idx;
  if (!pickHdu(hdus, a[1], optInt(a[2], 1), idx, err)) return ctx.fail(err);
  const Hdu &h = hdus[idx];
  std::vector<std::string> cols;
  Value v = hduValue(bytes, h, optBool(a[5], true), err, &cols);
  if (!err.empty()) return ctx.fail(err);
  if (given(a[4]) && !cols.empty()) {
    Table t;
    fitsTable(bytes, h, optBool(a[5], true), t, err);
    if (!selectTable(t, a[4], Value(std::string()), err)) return ctx.fail(err);
    cols = t.cols;
    v = tableData(t);
  }
  if (given(a[3])) { // "100:500, 100:500" - 1-based inclusive over (row, col)
    std::vector<size_t> shape;
    std::vector<double> vals;
    ndToRowMajor(v, shape, vals);
    std::string spec = optText(a[3]);
    std::vector<std::pair<size_t, size_t>> r;
    size_t s0 = 0;
    while (s0 <= spec.size()) {
      size_t c = spec.find(',', s0);
      if (c == std::string::npos) c = spec.size();
      std::string part = trim(spec.substr(s0, c - s0));
      size_t len = r.size() < shape.size() ? shape[r.size()] : 1;
      if (part == ":" || part.empty()) r.push_back({0, len});
      else {
        size_t colon = part.find(':');
        long long lo = std::atoll(part.substr(0, colon).c_str()), hi = colon == std::string::npos ? lo : std::atoll(part.substr(colon + 1).c_str());
        if (lo < 1 || hi < lo || hi > static_cast<long long>(len)) return ctx.fail("slice \"" + part + "\" is outside 1.." + std::to_string(len));
        r.push_back({static_cast<size_t>(lo - 1), static_cast<size_t>(hi)});
      }
      s0 = c + 1;
    }
    while (r.size() < shape.size()) r.push_back({0, shape[r.size()]});
    std::vector<size_t> ns;
    std::vector<double> o;
    for (size_t d = 0; d < shape.size(); d++) ns.push_back(r[d].second - r[d].first);
    std::function<void(size_t, size_t)> walk = [&](size_t d, size_t off) {
      if (d == shape.size()) { o.push_back(vals[off]); return; }
      for (size_t i = r[d].first; i < r[d].second; i++) walk(d + 1, off * shape[d] + i);
    };
    walk(0, 0);
    v = ndFromRowMajor(ns, o);
  }
  out.push_back(v);
  if (nout > 1) {
    std::vector<std::string> names;
    for (const auto &x : hdus) names.push_back(x.name.empty() ? x.type : x.name);
    out.push_back(makeObject("NcReadInfo", {{"header", headerDict(h)}, {"hdu", Value(static_cast<double>(idx))}, {"hdus", textList(names)},
                                            {"type", Value(h.type)}, {"cols", textList(cols)},
                                            {"boxes", optBool(a[6], true) ? textList(commentCards(h)) : textList({})}}));
  }
  ev.ok = true;
}

Value loadFits(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev(fn, file);
  std::vector<Hdu> hdus;
  if (!openFits(file, bytes, hdus, err)) { ctx.fail(err); return Value(0.0); }
  Fields f;
  std::vector<Value> list;
  std::vector<std::string> names, boxes;
  for (size_t k = 0; k < hdus.size(); k++) {
    const Hdu &h = hdus[k];
    Fields hf;
    std::vector<std::string> cols;
    hf["data"] = hduValue(bytes, h, true, err, &cols);
    if (!err.empty()) { ctx.fail(err); return Value(0.0); }
    if (!cols.empty()) {
      Table t;
      fitsTable(bytes, h, true, t, err);
      for (size_t c = 0; c < t.cols.size(); c++) { std::string n = fieldName(t.cols[c]); if (!n.empty() && !hf.count(n)) hf[n] = tableColumn(t, c); }
    }
    hf["header"] = headerDict(h);
    hf["cols"] = textList(cols);
    hf["type"] = Value(h.type);
    hf["name"] = Value(h.name);
    hf["wcs"] = wcsOf(h);
    hf["boxes"] = textList(commentCards(h));
    for (const auto &c : commentCards(h)) boxes.push_back(c);
    Value hv = makeObject("NcFitsHdu", hf);
    list.push_back(hv);
    std::string nm = h.name.empty() ? "HDU" + std::to_string(k) : h.name;
    names.push_back(nm);
    std::string fname = fieldName(nm);
    if (!fname.empty() && !f.count(fname)) f[fname] = hv;
  }
  f["hdus"] = Value(list);
  f["hdu_names"] = textList(names);
  f["primary"] = list[0];
  f["boxes"] = textList(boxes);
  f["file"] = Value(file);
  ev.ok = true;
  return makeObject("NcFits", std::move(f));
}

// NcFitsHdu.pix2world(x, y): FITS 1-based pixel -> world (linear, or TAN gnomonic for RA---TAN)
Value pix2world(const std::vector<Value> &a, CallContext &ctx) {
  const Value *w = field(a[0], "wcs");
  if (!w || w->dict().empty()) { ctx.fail("this HDU has no WCS keywords"); return Value(0.0); }
  auto g = [&](const char *k, double def) { return w->dict().count(k) ? w->dict().at(k).number : def; };
  double x = optNumber(a[1], 1) - g("CRPIX1", 0), y = optNumber(a[2], 1) - g("CRPIX2", 0);
  double cd11 = g("CD1_1", g("CDELT1", 1)), cd12 = g("CD1_2", 0), cd21 = g("CD2_1", 0), cd22 = g("CD2_2", g("CDELT2", 1));
  double u = cd11 * x + cd12 * y, v = cd21 * x + cd22 * y;
  std::string ct = w->dict().count("CTYPE1") ? optText(w->dict().at("CTYPE1")) : "";
  if (ct.find("TAN") == std::string::npos) return numberList({g("CRVAL1", 0) + u, g("CRVAL2", 0) + v});
  const double d2r = 3.14159265358979323846 / 180;
  double xi = u * d2r, eta = v * d2r, ra0 = g("CRVAL1", 0) * d2r, dec0 = g("CRVAL2", 0) * d2r;
  double den = std::cos(dec0) - eta * std::sin(dec0);
  double ra = ra0 + std::atan2(xi, den);
  double dec = std::atan2(std::sin(dec0) + eta * std::cos(dec0), std::sqrt(xi * xi + den * den));
  double raDeg = std::fmod(ra / d2r + 360.0, 360.0);
  return numberList({raDeg, dec / d2r});
}

// ---- writer ------------------------------------------------------------------------

std::string card(const std::string &key, const std::string &value, const std::string &comment = "") {
  std::string c = key;
  c.resize(8, ' ');
  if (!value.empty() || key != "COMMENT") {
    if (key == "COMMENT" || key == "HISTORY") c += value;
    else {
      std::string v = value;
      if (v.size() < 20 && !(v.size() && v[0] == '\'')) v = std::string(20 - v.size(), ' ') + v;
      c += "= " + v;
      if (!comment.empty()) c += " / " + comment;
    }
  }
  c.resize(80, ' ');
  return c;
}

std::string quoteFits(const std::string &s) {
  std::string q = "'";
  for (char c : s) { q.push_back(c); if (c == '\'') q.push_back('\''); }
  while (q.size() < 9) q.push_back(' ');
  return q + "'";
}

std::string fitsValue(const Value &v) {
  if (v.isBool()) return v.number != 0 ? "T" : "F";
  if (v.isText) return quoteFits(v.text());
  char buf[40];
  if (v.number == std::floor(v.number) && std::fabs(v.number) < 1e15) std::snprintf(buf, sizeof buf, "%.0f", v.number);
  else std::snprintf(buf, sizeof buf, "%.15G", v.number);
  return buf;
}

std::string padBlock(std::string s, char fill) {
  s.resize((s.size() + 2879) / 2880 * 2880, fill);
  return s;
}

std::string headerBlock(std::vector<std::string> cards) {
  cards.push_back(card("END", ""));
  std::string s;
  for (auto &c : cards) { c.resize(80, ' '); s += c; }
  return padBlock(s, ' ');
}

void userCards(const Value &header, const Value &boxes, std::vector<std::string> &cards, std::string &err) {
  if (header.isDict) {
    std::vector<std::string> keys;
    for (const auto &kv : header.dict()) keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      std::string up = upperAscii(k);
      if (up == "SIMPLE" || up == "BITPIX" || up.rfind("NAXIS", 0) == 0 || up == "EXTEND" || up == "XTENSION" || up == "PCOUNT" || up == "GCOUNT") continue;
      if (up.size() > 8) cards.push_back(card("HIERARCH", up + " = " + fitsValue(header.dict().at(k))));
      else cards.push_back(card(up, fitsValue(header.dict().at(k))));
    }
  }
  for (const auto &bx : optTextList(boxes)) {
    std::string t = trim(bx);
    std::string key = "COMMENT";
    if (t.rfind("HISTORY", 0) == 0) { key = "HISTORY"; t = trim(t.substr(7)); }
    else if (t.rfind("COMMENT", 0) == 0) t = trim(t.substr(7));
    for (size_t p = 0; p < t.size() || p == 0; p += 72) { cards.push_back(card(key, t.substr(p, 72))); if (t.empty()) break; }
  }
  (void)err;
}

std::string encodeSamples(const std::vector<double> &vals, int bitpix) {
  std::string d;
  d.reserve(vals.size() * static_cast<size_t>(std::abs(bitpix) / 8));
  for (double v : vals) {
    switch (bitpix) {
      case 8: d.push_back(static_cast<char>(std::clamp(std::lround(v), 0L, 255L))); break;
      case 16: putBE(d, static_cast<uint64_t>(static_cast<int16_t>(std::clamp(std::llround(v), -32768LL, 32767LL))), 2); break;
      case 32: putBE(d, static_cast<uint64_t>(static_cast<int32_t>(std::clamp(std::llround(v), -2147483648LL, 2147483647LL))), 4); break;
      case 64: putBE(d, static_cast<uint64_t>(std::llround(v)), 8); break;
      case -32: putF32BE(d, static_cast<float>(v)); break;
      default: putF64BE(d, v);
    }
  }
  return d;
}

// save_<fmt>(file, data, hdu_name, header, bitpix, compress, boxes, mode)
Value saveFits(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev(fn, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  int bitpix = static_cast<int>(optInt(a[4], -32));
  if (bitpix != 8 && bitpix != 16 && bitpix != 32 && bitpix != 64 && bitpix != -32 && bitpix != -64)
    return fail("bitpix must be 8, 16, 32, 64, -32 (float32) or -64 (float64)");
  std::string comp = lower(optText(a[5], "none"));
  if (comp != "none" && comp != "rice" && comp != "gzip" && comp != "no") return fail("compress must be \"rice\", \"gzip\" or \"none\"");
  bool append = lower(optText(a[7], "w")) == "a" && fileExists(file);
  std::string name = upperAscii(optText(a[2], ""));
  const Value &data = a[1];
  std::string out;
  bool isTable = data.isObject || data.isDict || (data.isMatrix && !data.isPacked() && !data.isND());
  if (!append && (isTable || comp == "rice" || comp == "gzip")) { // empty primary HDU first
    out += headerBlock({card("SIMPLE", "T"), card("BITPIX", "8"), card("NAXIS", "0"), card("EXTEND", "T")});
  }
  std::vector<std::string> cards;
  if (isTable) {
    Table t;
    if (!valueToTable(data, t, err, true)) return fail(err);
    std::vector<std::string> forms;
    std::vector<size_t> widths;
    for (size_t c = 0; c < t.cols.size(); c++) {
      bool numeric = true, integer = true;
      size_t maxLen = 1;
      for (const auto &r : t.rows) {
        if (!isNumberCell(r[c])) numeric = false;
        else if (r[c].number != std::floor(r[c].number)) integer = false;
        maxLen = std::max(maxLen, cellText(r[c]).size());
      }
      if (numeric) { forms.push_back(integer ? "K" : "D"); widths.push_back(8); }
      else { forms.push_back(std::to_string(maxLen) + "A"); widths.push_back(maxLen); }
    }
    size_t rowBytes = 0;
    for (size_t w : widths) rowBytes += w;
    cards = {card("XTENSION", "'BINTABLE'"), card("BITPIX", "8"), card("NAXIS", "2"), card("NAXIS1", std::to_string(rowBytes)),
             card("NAXIS2", std::to_string(t.rows.size())), card("PCOUNT", "0"), card("GCOUNT", "1"), card("TFIELDS", std::to_string(t.cols.size()))};
    for (size_t c = 0; c < t.cols.size(); c++) {
      cards.push_back(card("TTYPE" + std::to_string(c + 1), quoteFits(t.cols[c])));
      cards.push_back(card("TFORM" + std::to_string(c + 1), quoteFits(forms[c])));
    }
    if (!name.empty()) cards.push_back(card("EXTNAME", quoteFits(name)));
    userCards(a[3], a[6], cards, err);
    std::string body;
    for (const auto &r : t.rows)
      for (size_t c = 0; c < t.cols.size(); c++) {
        if (forms[c] == "K") putBE(body, static_cast<uint64_t>(std::llround(r[c].number)), 8);
        else if (forms[c] == "D") putF64BE(body, r[c].number);
        else { std::string s = cellText(r[c]); s.resize(widths[c], ' '); body += s; }
      }
    out += headerBlock(cards) + padBlock(body, '\0');
  } else {
    std::vector<size_t> shape;
    std::vector<double> vals;
    if (!ndToRowMajor(data, shape, vals)) return fail("data must be a numeric N-D array or a table");
    if (comp == "rice" || comp == "gzip") {
      if (comp == "rice" && bitpix < 0) return fail("compress=\"rice\" needs an integer bitpix (8, 16, 32); use \"gzip\" for floats");
      size_t w = shape.back(), rows = vals.size() / std::max<size_t>(1, w);
      std::string heap, table;
      int bytepix = std::abs(bitpix) / 8;
      for (size_t r = 0; r < rows; r++) { // one tile per image row
        std::vector<double> rowv(vals.begin() + static_cast<long>(r * w), vals.begin() + static_cast<long>((r + 1) * w));
        std::string tile;
        if (comp == "rice") {
          std::vector<int64_t> iv;
          for (double v : rowv) iv.push_back(std::llround(v));
          tile = riceEncode(iv, bytepix, 32);
        } else {
          tile = gzipCompress(encodeSamples(rowv, bitpix), 6);
        }
        putBE(table, tile.size(), 4);
        putBE(table, heap.size(), 4);
        heap += tile;
      }
      cards = {card("XTENSION", "'BINTABLE'"), card("BITPIX", "8"), card("NAXIS", "2"), card("NAXIS1", "8"), card("NAXIS2", std::to_string(rows)),
               card("PCOUNT", std::to_string(heap.size())), card("GCOUNT", "1"), card("TFIELDS", "1"),
               card("TTYPE1", "'COMPRESSED_DATA'"), card("TFORM1", "'1PB(" + std::to_string(heap.size()) + ")'"),
               card("ZIMAGE", "T"), card("ZBITPIX", std::to_string(bitpix)), card("ZNAXIS", std::to_string(shape.size()))};
      for (size_t k = 0; k < shape.size(); k++) cards.push_back(card("ZNAXIS" + std::to_string(k + 1), std::to_string(shape[shape.size() - 1 - k])));
      cards.push_back(card("ZTILE1", std::to_string(w)));
      for (size_t k = 1; k < shape.size(); k++) cards.push_back(card("ZTILE" + std::to_string(k + 1), "1"));
      cards.push_back(card("ZCMPTYPE", comp == "rice" ? "'RICE_1'" : "'GZIP_1'"));
      if (comp == "rice") { cards.push_back(card("ZNAME1", "'BLOCKSIZE'")); cards.push_back(card("ZVAL1", "32")); cards.push_back(card("ZNAME2", "'BYTEPIX'")); cards.push_back(card("ZVAL2", std::to_string(bytepix))); }
      if (!name.empty()) cards.push_back(card("EXTNAME", quoteFits(name)));
      userCards(a[3], a[6], cards, err);
      out += headerBlock(cards) + padBlock(table + heap, '\0');
    } else {
      if (!append) cards = {card("SIMPLE", "T"), card("BITPIX", std::to_string(bitpix)), card("NAXIS", std::to_string(shape.size()))};
      else cards = {card("XTENSION", "'IMAGE'"), card("BITPIX", std::to_string(bitpix)), card("NAXIS", std::to_string(shape.size()))};
      for (size_t k = 0; k < shape.size(); k++) cards.push_back(card("NAXIS" + std::to_string(k + 1), std::to_string(shape[shape.size() - 1 - k])));
      if (!append) cards.push_back(card("EXTEND", "T"));
      else { cards.push_back(card("PCOUNT", "0")); cards.push_back(card("GCOUNT", "1")); }
      if (!name.empty()) cards.push_back(card("EXTNAME", quoteFits(name)));
      userCards(a[3], a[6], cards, err);
      out += headerBlock(cards) + padBlock(encodeSamples(vals, bitpix), '\0');
    }
  }
  if (!writeFile(file, out, append, err)) return fail(err);
  emitEvent({"saved", fn, file, 1.0, formatBytes(out.size())});
  ev.ok = true;
  return Value(static_cast<double>(out.size()));
}

} // namespace

std::string upperAscii(std::string s) {
  for (char &c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  return s;
}

void registerFits(Registry &reg) {
  for (const char *ext : {"fits", "fit"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, hdu=-1, ver=1, slice=\"\", cols=\"\", scale=true, box=true",
             "read an image or table HDU of a ." + e + " file (BZERO/BSCALE applied)", "astropy.io.fits.getdata", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readFits("read_" + e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file", "load all HDUs of a ." + e + " file (D.hdus, D.SCI.data, D.SCI.header, D.SCI.wcs)",
          "astropy.io.fits.open", [e](const std::vector<Value> &a, CallContext &ctx) { return loadFits("load_" + e, a, ctx); });
    addFn(reg, "save_" + e, "file, data, hdu_name=\"\", header=\"\", bitpix=-32, compress=\"none\", boxes=\"\", mode=\"w\"",
          "write an image or table as ." + e + " (mode=\"a\" appends an extension HDU)", "astropy.io.fits.writeto",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveFits("save_" + e, a, ctx); });
  }
  addFn(reg, "NcFitsHdu.pix2world", "H, x, y", "sky coordinates of FITS pixel (x, y), 1-based (linear or TAN WCS)", "astropy.wcs.WCS.pixel_to_world", pix2world);
}

} // namespace io
} // namespace nc
