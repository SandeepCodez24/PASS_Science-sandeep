// CATEGORY 9 - configuration files: read_/load_/save_ yaml, yml, ini.
//
// YAML: the YAML 1.2 subset configuration files use - block mappings and
// sequences, flow [..] {..}, plain / 'single' / "double" scalars, | and >
// block scalars, anchors &a, aliases *a, merge keys <<, several documents
// (---), comments, ${ENV} expansion. Tabs in indentation are refused.
// INI: [Section], key = value / key: value, ; and # comments, continuation
// lines, [DEFAULT] fallbacks, %(name)s interpolation.
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_tree.h"

namespace nc {
namespace io {
namespace {

// ---- shared -----------------------------------------------------------------

// An environment variable (false when it is not set).
bool envValue(const std::string &name, std::string &out) {
#ifdef _WIN32
  char *buf = nullptr;
  size_t len = 0;
  if (_dupenv_s(&buf, &len, name.c_str()) != 0 || !buf)
    return false;
  out = buf;
  free(buf);
  return true;
#else
  const char *v = std::getenv(name.c_str());
  if (!v)
    return false;
  out = v;
  return true;
#endif
}

std::string expandEnv(const std::string &s, std::vector<std::string> &used, bool expand) {
  std::string out;
  for (size_t i = 0; i < s.size(); i++) {
    if (s[i] == '$' && i + 1 < s.size() && s[i + 1] == '{') {
      size_t e = s.find('}', i + 2);
      if (e != std::string::npos) {
        std::string body = s.substr(i + 2, e - i - 2), def;
        size_t dflt = body.find(":-");
        std::string name = dflt == std::string::npos ? body : body.substr(0, dflt);
        if (dflt != std::string::npos)
          def = body.substr(dflt + 2);
        if (std::find(used.begin(), used.end(), name) == used.end())
          used.push_back(name);
        if (expand) {
          std::string v;
          out += envValue(name, v) ? v : def;
        } else {
          out += s.substr(i, e - i + 1);
        }
        i = e;
        continue;
      }
    }
    out.push_back(s[i]);
  }
  return out;
}

TreeNode plainScalar(const std::string &raw, std::vector<std::string> &envUsed, bool env) {
  std::string s = trim(raw);
  if (s.empty() || s == "~" || s == "null" || s == "Null" || s == "NULL")
    return TreeNode();
  if (s == "true" || s == "True" || s == "TRUE")
    return TreeNode::ofBool(true);
  if (s == "false" || s == "False" || s == "FALSE")
    return TreeNode::ofBool(false);
  if (s == ".inf" || s == ".Inf" || s == "+.inf")
    return TreeNode::ofNumber(HUGE_VAL);
  if (s == "-.inf" || s == "-.Inf")
    return TreeNode::ofNumber(-HUGE_VAL);
  if (s == ".nan" || s == ".NaN")
    return TreeNode::ofNumber(std::nan(""));
  char *end = nullptr;
  if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'o')) {
    long long v = std::strtoll(s.c_str() + 2, &end, s[1] == 'x' ? 16 : 8);
    if (*end == '\0')
      return TreeNode::ofNumber(static_cast<double>(v));
  }
  std::string digits;
  for (char c : s)
    if (c != '_')
      digits.push_back(c);
  double d = std::strtod(digits.c_str(), &end);
  if (end != digits.c_str() && *end == '\0' && (std::isdigit(static_cast<unsigned char>(digits.back())) || digits.back() == '.'))
    return TreeNode::ofNumber(d);
  return TreeNode::ofString(expandEnv(s, envUsed, env));
}

std::string unescapeDouble(const std::string &s) {
  std::string out;
  for (size_t i = 0; i < s.size(); i++) {
    if (s[i] != '\\' || i + 1 >= s.size()) {
      out.push_back(s[i]);
      continue;
    }
    char e = s[++i];
    switch (e) {
      case 'n': out.push_back('\n'); break;
      case 't': out.push_back('\t'); break;
      case 'r': out.push_back('\r'); break;
      case '0': out.push_back('\0'); break;
      case '"': out.push_back('"'); break;
      case '\\': out.push_back('\\'); break;
      case '/': out.push_back('/'); break;
      default: out.push_back('\\'); out.push_back(e);
    }
  }
  return out;
}

// ---- YAML reader -------------------------------------------------------------

struct YLine {
  size_t indent = 0;
  std::string text; // comment removed, right-trimmed
  size_t number = 0;
};

struct YamlDoc {
  TreeNode root;
  std::vector<std::pair<size_t, std::string>> comments;
  std::map<std::string, TreeNode> anchors;
  std::vector<std::string> envUsed;
};

struct YamlParser {
  std::vector<YLine> lines;
  size_t pos = 0;
  bool env = true;
  std::string err;
  YamlDoc *doc = nullptr;

  bool fail(const std::string &m, size_t line) {
    if (err.empty())
      err = m + " (line " + std::to_string(line) + ")";
    return false;
  }

  // Flow collection / quoted scalar parser over one string.
  struct Flow {
    const std::string &s;
    size_t i = 0;
    YamlParser &p;
    Flow(const std::string &t, YamlParser &parser) : s(t), p(parser) {}
    void ws() {
      while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i])))
        i++;
    }
    bool value(TreeNode &n, bool inFlow) {
      ws();
      if (i >= s.size()) {
        n = TreeNode();
        return true;
      }
      if (s[i] == '&') { // anchor
        size_t b = ++i;
        while (i < s.size() && !std::isspace(static_cast<unsigned char>(s[i])) && s[i] != ',' && s[i] != ']' && s[i] != '}')
          i++;
        std::string name = s.substr(b, i - b);
        if (!value(n, inFlow))
          return false;
        p.doc->anchors[name] = n;
        return true;
      }
      if (s[i] == '*') {
        size_t b = ++i;
        while (i < s.size() && !std::isspace(static_cast<unsigned char>(s[i])) && s[i] != ',' && s[i] != ']' && s[i] != '}')
          i++;
        std::string name = s.substr(b, i - b);
        auto it = p.doc->anchors.find(name);
        if (it == p.doc->anchors.end()) {
          p.err = "alias *" + name + " has no anchor &" + name;
          return false;
        }
        n = it->second;
        return true;
      }
      if (s.compare(i, 2, "!!") == 0) { // tag: !!str forces text
        size_t b = i;
        while (i < s.size() && !std::isspace(static_cast<unsigned char>(s[i])))
          i++;
        std::string tag = s.substr(b, i - b);
        if (!value(n, inFlow))
          return false;
        if (tag == "!!str" && n.type != TreeNode::String) {
          TreeNode t = TreeNode::ofString(n.type == TreeNode::Number ? numberText(n.num)
                                          : n.type == TreeNode::Bool ? (n.b ? "true" : "false") : "");
          n = t;
        }
        return true;
      }
      if (s[i] == '[') {
        i++;
        n = TreeNode();
        n.type = TreeNode::Array;
        for (;;) {
          ws();
          if (i < s.size() && s[i] == ']') {
            i++;
            return true;
          }
          TreeNode item;
          if (!value(item, true))
            return false;
          // [a: 1] - a one-pair mapping inside a sequence
          ws();
          if (i < s.size() && s[i] == ':') {
            i++;
            TreeNode v;
            if (!value(v, true))
              return false;
            TreeNode m;
            m.type = TreeNode::Object;
            m.keys.emplace_back(item.type == TreeNode::String ? item.str : numberText(item.num), v);
            item = m;
          }
          n.items.push_back(std::move(item));
          ws();
          if (i < s.size() && s[i] == ',') {
            i++;
            continue;
          }
          if (i < s.size() && s[i] == ']') {
            i++;
            return true;
          }
          p.err = "expected ',' or ']' in a flow sequence";
          return false;
        }
      }
      if (s[i] == '{') {
        i++;
        n = TreeNode();
        n.type = TreeNode::Object;
        for (;;) {
          ws();
          if (i < s.size() && s[i] == '}') {
            i++;
            return true;
          }
          TreeNode k;
          if (!value(k, true))
            return false;
          ws();
          TreeNode v;
          if (i < s.size() && s[i] == ':') {
            i++;
            if (!value(v, true))
              return false;
          }
          std::string key = k.type == TreeNode::String ? k.str : k.type == TreeNode::Number ? numberText(k.num)
                            : k.type == TreeNode::Bool ? (k.b ? "true" : "false") : "null";
          n.keys.emplace_back(key, std::move(v));
          ws();
          if (i < s.size() && s[i] == ',') {
            i++;
            continue;
          }
          if (i < s.size() && s[i] == '}') {
            i++;
            return true;
          }
          p.err = "expected ',' or '}' in a flow mapping";
          return false;
        }
      }
      if (s[i] == '"') {
        size_t b = ++i;
        while (i < s.size() && s[i] != '"') {
          if (s[i] == '\\')
            i++;
          i++;
        }
        if (i >= s.size()) {
          p.err = "a \"text\" is never closed";
          return false;
        }
        n = TreeNode::ofString(expandEnv(unescapeDouble(s.substr(b, i - b)), p.doc->envUsed, p.env));
        i++;
        return true;
      }
      if (s[i] == '\'') {
        std::string out;
        i++;
        while (i < s.size()) {
          if (s[i] == '\'') {
            if (i + 1 < s.size() && s[i + 1] == '\'') {
              out.push_back('\'');
              i += 2;
              continue;
            }
            break;
          }
          out.push_back(s[i++]);
        }
        if (i >= s.size()) {
          p.err = "a 'text' is never closed";
          return false;
        }
        i++;
        n = TreeNode::ofString(out);
        return true;
      }
      size_t b = i;
      while (i < s.size()) {
        if (inFlow && (s[i] == ',' || s[i] == ']' || s[i] == '}'))
          break;
        if (inFlow && s[i] == ':' && (i + 1 >= s.size() || std::isspace(static_cast<unsigned char>(s[i + 1])) ||
                                      s[i + 1] == ',' || s[i + 1] == '}' || s[i + 1] == ']'))
          break;
        i++;
      }
      n = plainScalar(s.substr(b, i - b), p.doc->envUsed, p.env);
      return true;
    }
  };

  // "key: rest" -> true with key/rest. Quoted keys allowed.
  static bool splitKey(const std::string &t, std::string &key, std::string &rest) {
    size_t i = 0;
    if (!t.empty() && (t[0] == '"' || t[0] == '\'')) {
      char q = t[0];
      size_t e = t.find(q, 1);
      while (e != std::string::npos && q == '\'' && e + 1 < t.size() && t[e + 1] == '\'')
        e = t.find(q, e + 2);
      if (e == std::string::npos)
        return false;
      key = q == '"' ? unescapeDouble(t.substr(1, e - 1)) : t.substr(1, e - 1);
      i = e + 1;
      while (i < t.size() && t[i] == ' ')
        i++;
      if (i >= t.size() || t[i] != ':')
        return false;
      rest = trim(t.substr(i + 1));
      return true;
    }
    if (!t.empty() && (t[0] == '[' || t[0] == '{' || (t[0] == '-' && (t.size() == 1 || t[1] == ' '))))
      return false;
    for (i = 0; i < t.size(); i++) {
      if (t[i] == ':' && (i + 1 == t.size() || t[i + 1] == ' ' || t[i + 1] == '\t')) {
        key = trim(t.substr(0, i));
        rest = trim(t.substr(i + 1));
        return !key.empty();
      }
    }
    return false;
  }

  bool scalarFromText(const std::string &text, size_t line, TreeNode &out) {
    Flow f(text, *this);
    if (!f.value(out, false))
      return fail(err.empty() ? "bad value" : err, line);
    f.ws();
    if (f.i < text.size() && out.type != TreeNode::String)
      return fail("unexpected text after a value: '" + text.substr(f.i) + "'", line);
    return true;
  }

  // | or > block scalar: the lines indented more than `parentIndent`.
  std::string blockScalar(const std::string &indicator, size_t parentIndent) {
    bool fold = indicator[0] == '>';
    bool keep = indicator.find('+') != std::string::npos, strip = indicator.find('-') != std::string::npos;
    std::vector<std::string> parts;
    size_t blockIndent = 0;
    while (pos < lines.size()) {
      const YLine &l = lines[pos];
      if (!l.text.empty() && l.indent <= parentIndent)
        break;
      if (!l.text.empty() && blockIndent == 0)
        blockIndent = l.indent;
      parts.push_back(l.text.empty() ? "" : std::string(l.indent > blockIndent ? l.indent - blockIndent : 0, ' ') + l.text);
      pos++;
    }
    std::string out;
    for (size_t k = 0; k < parts.size(); k++) {
      if (k) {
        if (fold && !parts[k].empty() && !parts[k - 1].empty() && parts[k][0] != ' ')
          out += " ";
        else
          out += "\n";
      }
      out += parts[k];
    }
    while (!keep && !out.empty() && out.back() == '\n')
      out.pop_back();
    if (!strip && !keep)
      out += "\n";
    else if (keep)
      out += "\n";
    return out;
  }

  // A flow value may continue on the next lines until its brackets close.
  std::string gatherFlow(std::string text) {
    auto balance = [](const std::string &t) {
      int d = 0;
      bool q = false;
      char qc = 0;
      for (char c : t) {
        if (q) {
          if (c == qc)
            q = false;
        } else if (c == '"' || c == '\'') {
          q = true;
          qc = c;
        } else if (c == '[' || c == '{') {
          d++;
        } else if (c == ']' || c == '}') {
          d--;
        }
      }
      return d;
    };
    while (balance(text) > 0 && pos < lines.size()) {
      text += " " + lines[pos].text;
      pos++;
    }
    return text;
  }

  bool valueAfter(const std::string &restIn, size_t ownIndent, size_t line, TreeNode &out) {
    std::string rest = restIn;
    std::string anchor;
    if (!rest.empty() && rest[0] == '&') {
      size_t sp = rest.find(' ');
      anchor = rest.substr(1, sp == std::string::npos ? std::string::npos : sp - 1);
      rest = sp == std::string::npos ? "" : trim(rest.substr(sp + 1));
    }
    if (rest.empty()) {
      // nested block (or nothing = null)
      if (pos < lines.size() && (lines[pos].indent > ownIndent ||
                                 (lines[pos].indent == ownIndent && (lines[pos].text == "-" || lines[pos].text.rfind("- ", 0) == 0)))) {
        if (!block(lines[pos].indent, out))
          return false;
      } else {
        out = TreeNode();
      }
    } else if (rest[0] == '|' || rest[0] == '>') {
      out = TreeNode::ofString(blockScalar(rest, ownIndent));
    } else {
      if (rest[0] == '[' || rest[0] == '{')
        rest = gatherFlow(rest);
      if (!scalarFromText(rest, line, out))
        return false;
    }
    if (!anchor.empty())
      doc->anchors[anchor] = out;
    return true;
  }

  bool block(size_t indent, TreeNode &out) {
    if (pos >= lines.size()) {
      out = TreeNode();
      return true;
    }
    const YLine &first = lines[pos];
    if (first.text == "-" || first.text.rfind("- ", 0) == 0) {
      out = TreeNode();
      out.type = TreeNode::Array;
      while (pos < lines.size() && lines[pos].indent == indent &&
             (lines[pos].text == "-" || lines[pos].text.rfind("- ", 0) == 0)) {
        YLine l = lines[pos];
        std::string rest = l.text.size() > 1 ? trim(l.text.substr(2)) : "";
        std::string key, krest;
        TreeNode item;
        if (!rest.empty() && splitKey(rest, key, krest)) {
          // "- key: v" starts a mapping indented at the text after "- ".
          size_t inner = indent + (l.text.size() - l.text.substr(1).find_first_not_of(' ') > 0
                                       ? 1 + l.text.substr(1).find_first_not_of(' ')
                                       : 2);
          lines[pos].indent = inner;
          lines[pos].text = rest;
          if (!block(inner, item))
            return false;
        } else {
          pos++;
          if (!valueAfter(rest, indent, l.number, item))
            return false;
        }
        out.items.push_back(std::move(item));
      }
      return true;
    }
    std::string key, rest;
    if (splitKey(first.text, key, rest)) {
      out = TreeNode();
      out.type = TreeNode::Object;
      while (pos < lines.size() && lines[pos].indent == indent) {
        const YLine l = lines[pos];
        if (!splitKey(l.text, key, rest))
          return fail("expected 'key: value' here", l.number);
        pos++;
        TreeNode v;
        if (!valueAfter(rest, indent, l.number, v))
          return false;
        if (key == "<<") { // merge key: copy keys that are not set yet
          std::vector<const TreeNode *> srcs;
          if (v.type == TreeNode::Object)
            srcs.push_back(&v);
          else if (v.type == TreeNode::Array)
            for (const auto &x : v.items)
              srcs.push_back(&x);
          for (auto *src : srcs)
            for (const auto &kv : src->keys)
              if (!out.find(kv.first))
                out.keys.push_back(kv);
          continue;
        }
        if (TreeNode *existing = out.find(key))
          *existing = std::move(v);
        else
          out.keys.emplace_back(key, std::move(v));
      }
      if (pos < lines.size() && lines[pos].indent > indent)
        return fail("indentation does not match the lines above", lines[pos].number);
      return true;
    }
    // a lone scalar (possibly over several lines)
    std::string text = first.text;
    size_t line = first.number;
    pos++;
    if (text[0] == '[' || text[0] == '{')
      text = gatherFlow(text);
    else
      while (pos < lines.size() && lines[pos].indent >= indent && lines[pos].indent > 0 &&
             !splitKey(lines[pos].text, key, rest)) {
        text += " " + lines[pos].text;
        pos++;
      }
    return scalarFromText(text, line, out);
  }
};

// Removes a trailing " # comment" outside quotes.
std::string stripComment(const std::string &s, std::string &comment) {
  bool sq = false, dq = false;
  for (size_t i = 0; i < s.size(); i++) {
    char c = s[i];
    if (c == '\'' && !dq)
      sq = !sq;
    else if (c == '"' && !sq)
      dq = !dq;
    else if (c == '#' && !sq && !dq && (i == 0 || s[i - 1] == ' ' || s[i - 1] == '\t')) {
      comment = s.substr(i);
      return s.substr(0, i);
    }
  }
  return s;
}

bool parseYaml(const std::string &text, bool env, std::vector<YamlDoc> &docs, std::string &err) {
  docs.clear();
  std::vector<std::vector<YLine>> chunks(1);
  std::vector<std::vector<std::pair<size_t, std::string>>> comments(1);
  size_t start = 0, number = 0;
  bool inBlockScalar = false;
  size_t blockParent = 0;
  while (start <= text.size()) {
    size_t e = text.find('\n', start);
    if (e == std::string::npos)
      e = text.size();
    std::string raw = text.substr(start, e - start);
    start = e + 1;
    number++;
    if (!raw.empty() && raw.back() == '\r')
      raw.pop_back();
    if (raw.rfind("---", 0) == 0 && (raw.size() == 3 || raw[3] == ' ')) {
      if (!chunks.back().empty() || number > 1) {
        chunks.emplace_back();
        comments.emplace_back();
      }
      inBlockScalar = false;
      std::string rest = trim(raw.substr(3));
      if (!rest.empty())
        chunks.back().push_back({0, rest, number});
      continue;
    }
    if (raw == "...")
      continue;
    size_t indent = 0;
    while (indent < raw.size() && raw[indent] == ' ')
      indent++;
    if (indent < raw.size() && raw[indent] == '\t' && trim(raw).size()) {
      if (!inBlockScalar) {
        err = "a tab is used for indentation (line " + std::to_string(number) + ") - YAML needs spaces";
        return false;
      }
    }
    if (inBlockScalar) {
      if (trim(raw).empty() || indent > blockParent) {
        chunks.back().push_back({trim(raw).empty() ? 0 : indent, trim(raw).empty() ? "" : raw.substr(indent), number});
        continue;
      }
      inBlockScalar = false;
    }
    std::string comment;
    std::string body = stripComment(raw, comment);
    if (!comment.empty())
      comments.back().push_back({number, trim(comment)});
    std::string t = trim(body);
    if (t.empty() || t[0] == '%')
      continue;
    chunks.back().push_back({indent, t, number});
    // Lines after "key: |" belong to the block scalar verbatim.
    if (t.back() == '|' || t.back() == '>' || (t.size() > 1 && (t[t.size() - 2] == '|' || t[t.size() - 2] == '>') &&
                                               (t.back() == '-' || t.back() == '+'))) {
      std::string key, rest;
      if (YamlParser::splitKey(t, key, rest) || t.rfind("- ", 0) == 0) {
        inBlockScalar = true;
        blockParent = indent;
      }
    }
  }
  for (size_t c = 0; c < chunks.size(); c++) {
    if (chunks[c].empty() && chunks.size() > 1 && comments[c].empty())
      continue;
    YamlDoc d;
    d.comments = comments[c];
    YamlParser p;
    p.lines = chunks[c];
    p.env = env;
    p.doc = &d;
    // the block scalar lines kept blank texts; drop blank lines elsewhere
    if (!p.lines.empty() && !p.block(p.lines[0].indent, d.root)) {
      err = p.err;
      return false;
    }
    if (p.pos < p.lines.size()) {
      err = "unexpected indentation (line " + std::to_string(p.lines[p.pos].number) + ")";
      return false;
    }
    docs.push_back(std::move(d));
  }
  if (docs.empty())
    docs.emplace_back();
  return true;
}

// ---- YAML writer -------------------------------------------------------------

std::string yamlScalar(const TreeNode &n) {
  switch (n.type) {
    case TreeNode::Null: return "null";
    case TreeNode::Bool: return n.b ? "true" : "false";
    case TreeNode::Number:
      if (std::isnan(n.num)) return ".nan";
      if (std::isinf(n.num)) return n.num > 0 ? ".inf" : "-.inf";
      return numberText(n.num);
    default: break;
  }
  const std::string &s = n.str;
  std::vector<std::string> none;
  TreeNode probe = plainScalar(s, none, false);
  bool needQuotes = s.empty() || probe.type != TreeNode::String || s != trim(s) ||
                    s.find(": ") != std::string::npos || s.find(" #") != std::string::npos ||
                    s.find('\n') != std::string::npos || std::string("-?:,[]{}#&*!|>'\"%@`").find(s[0]) != std::string::npos ||
                    s.back() == ':';
  if (!needQuotes)
    return s;
  std::string q = "\"";
  for (char c : s) {
    if (c == '"') q += "\\\"";
    else if (c == '\\') q += "\\\\";
    else if (c == '\n') q += "\\n";
    else if (c == '\t') q += "\\t";
    else q.push_back(c);
  }
  return q + "\"";
}

std::string yamlFlow(const TreeNode &n) {
  if (n.type == TreeNode::Array) {
    std::string s = "[";
    for (size_t k = 0; k < n.items.size(); k++)
      s += (k ? ", " : "") + yamlFlow(n.items[k]);
    return s + "]";
  }
  if (n.type == TreeNode::Object) {
    std::string s = "{";
    for (size_t k = 0; k < n.keys.size(); k++)
      s += (k ? ", " : "") + yamlScalar(TreeNode::ofString(n.keys[k].first)) + ": " + yamlFlow(n.keys[k].second);
    return s + "}";
  }
  return yamlScalar(n);
}

void yamlBlock(const TreeNode &n, int indent, int depth, bool sortKeys, std::string &out) {
  const std::string pad(static_cast<size_t>(indent * depth), ' ');
  auto isCollection = [](const TreeNode &x) {
    return (x.type == TreeNode::Array && !x.items.empty()) || (x.type == TreeNode::Object && !x.keys.empty());
  };
  if (n.type == TreeNode::Object) {
    std::vector<const std::pair<std::string, TreeNode> *> keys;
    for (const auto &kv : n.keys)
      keys.push_back(&kv);
    if (sortKeys)
      std::stable_sort(keys.begin(), keys.end(), [](auto *a, auto *b) { return a->first < b->first; });
    for (auto *kv : keys) {
      out += pad + yamlScalar(TreeNode::ofString(kv->first)) + ":";
      const TreeNode &v = kv->second;
      if (isCollection(v)) {
        // short lists of plain values stay on one line
        bool flatList = v.type == TreeNode::Array && v.items.size() <= 8;
        if (flatList)
          for (const auto &x : v.items)
            if (x.type == TreeNode::Array || x.type == TreeNode::Object)
              flatList = false;
        if (flatList) {
          out += " " + yamlFlow(v) + "\n";
        } else {
          out += "\n";
          yamlBlock(v, indent, depth + 1, sortKeys, out);
        }
      } else if (v.type == TreeNode::String && v.str.find('\n') != std::string::npos) {
        out += " |\n";
        std::string body = v.str;
        if (!body.empty() && body.back() == '\n')
          body.pop_back();
        size_t s0 = 0;
        while (s0 <= body.size()) {
          size_t e = body.find('\n', s0);
          if (e == std::string::npos)
            e = body.size();
          out += pad + std::string(static_cast<size_t>(indent), ' ') + body.substr(s0, e - s0) + "\n";
          s0 = e + 1;
        }
      } else {
        out += " " + yamlFlow(v) + "\n";
      }
    }
    return;
  }
  if (n.type == TreeNode::Array) {
    for (const auto &item : n.items) {
      if (item.type == TreeNode::Object && !item.keys.empty()) {
        // The item's keys line up with the first one, after "- ".
        std::string sub;
        yamlBlock(item, indent, 0, sortKeys, sub);
        size_t s0 = 0;
        bool firstLine = true;
        while (s0 < sub.size()) {
          size_t e = sub.find('\n', s0);
          if (e == std::string::npos)
            e = sub.size();
          out += pad + (firstLine ? "- " : "  ") + sub.substr(s0, e - s0) + "\n";
          firstLine = false;
          s0 = e + 1;
        }
      } else if (isCollection(item)) {
        out += pad + "- " + yamlFlow(item) + "\n";
      } else {
        out += pad + "- " + yamlFlow(item) + "\n";
      }
    }
    return;
  }
  out += pad + yamlFlow(n) + "\n";
}

std::string writeYaml(const TreeNode &n, int indent, bool flow, bool sortKeys) {
  if (flow)
    return yamlFlow(n) + "\n";
  if (n.type != TreeNode::Object && n.type != TreeNode::Array)
    return yamlScalar(n) + "\n";
  std::string out;
  yamlBlock(n, std::max(1, indent), 0, sortKeys, out);
  return out;
}

// ---- YAML functions -----------------------------------------------------------

bool loadYamlDocs(const std::string &file, bool env, std::vector<YamlDoc> &docs, std::string &err) {
  std::string raw, text;
  return readSource(file, raw, err) && autoDecompress(raw, err) && decodeText(raw, "utf-8", text, err) &&
         parseYaml(text, env, docs, err);
}

Value commentCells(const std::vector<std::pair<size_t, std::string>> &c) {
  std::vector<std::vector<Value>> m;
  for (const auto &kv : c)
    m.push_back({Value(static_cast<double>(kv.first)), Value(kv.second)});
  if (m.empty())
    return Value(std::vector<Value>{});
  return Value(m);
}

// Runs of consecutive full-line comments as text blocks.
std::vector<std::string> commentBlocks(const std::vector<std::pair<size_t, std::string>> &c) {
  std::vector<std::string> out;
  size_t last = 0;
  for (const auto &kv : c) {
    std::string t = kv.second;
    while (!t.empty() && (t[0] == '#' || t[0] == ';'))
      t.erase(0, 1);
    t = trim(t);
    if (!out.empty() && kv.first == last + 1)
      out.back() += "\n" + t;
    else
      out.push_back(t);
    last = kv.first;
  }
  return out;
}

Value anchorsValue(const std::map<std::string, TreeNode> &a) {
  Fields f;
  for (const auto &kv : a)
    f[kv.first] = treeToValue(kv.second);
  return Value(f);
}

// read_yaml(file, doc, path, env, box)
void readYaml(const std::string &fn, const std::vector<Value> &a, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev(fn, file);
  std::vector<YamlDoc> docs;
  if (!loadYamlDocs(file, optBool(a[3], true), docs, err))
    return ctx.fail(err);
  const std::string path = optText(a[2], "");
  auto select = [&](const TreeNode &root, Value &v) -> bool {
    if (path.empty()) {
      v = treeToValue(root);
      return true;
    }
    std::vector<const TreeNode *> hits;
    bool single = true;
    if (!jsonPath(root, path, hits, single, err))
      return false;
    if (hits.empty()) {
      err = "no '" + path + "' in the document";
      return false;
    }
    if (single && hits.size() == 1) {
      v = treeToValue(*hits[0]);
    } else {
      std::vector<Value> cells;
      for (auto *h : hits)
        cells.push_back(treeToValue(*h));
      v = Value(std::move(cells));
    }
    return true;
  };
  size_t pick = 0;
  bool all = a[1].isText && lower(a[1].text()) == "all";
  if (!all) {
    long long k = optInt(a[1], 0);
    if (k < 0 || k >= static_cast<long long>(docs.size()))
      return ctx.fail("doc=" + std::to_string(k) + " does not exist (the file has " + std::to_string(docs.size()) +
                      " document(s), numbered from 0)");
    pick = static_cast<size_t>(k);
  }
  Value result;
  if (all) {
    std::vector<Value> cells;
    for (const auto &d : docs) {
      Value v;
      if (!select(d.root, v))
        return ctx.fail(err);
      cells.push_back(v);
    }
    result = Value(std::move(cells));
  } else if (!select(docs[pick].root, result)) {
    return ctx.fail(err);
  }
  out.push_back(result);
  if (nout > 1) {
    std::vector<std::pair<size_t, std::string>> allComments;
    std::vector<std::string> env;
    std::map<std::string, TreeNode> anchors;
    for (const auto &d : docs) {
      allComments.insert(allComments.end(), d.comments.begin(), d.comments.end());
      env.insert(env.end(), d.envUsed.begin(), d.envUsed.end());
      anchors.insert(d.anchors.begin(), d.anchors.end());
    }
    Fields info;
    info["boxes"] = optBool(a[4], true) ? textList(commentBlocks(allComments)) : textList({});
    info["comments"] = commentCells(allComments);
    info["docs"] = Value(static_cast<double>(docs.size()));
    info["anchors"] = anchorsValue(anchors);
    info["env_vars"] = textList(env);
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

Value configObject(const TreeNode &root, Fields extra) {
  Fields f;
  std::vector<std::string> order;
  if (root.type == TreeNode::Object)
    for (const auto &kv : root.keys) {
      order.push_back(kv.first);
      std::string n = fieldName(kv.first);
      f[n.empty() ? "_" : n] = treeToObject(kv.second, "NcConfigSection");
    }
  f["default"] = treeToValue(root);
  f["sections"] = textList(order);
  f["key_order"] = textList(order);
  for (auto &kv : extra)
    f[kv.first] = std::move(kv.second);
  return makeObject("NcConfig", std::move(f));
}

Value loadYaml(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  std::vector<YamlDoc> docs;
  if (!loadYamlDocs(file, optBool(a[1], true), docs, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  std::vector<Value> docVals;
  std::vector<std::pair<size_t, std::string>> allComments;
  std::vector<std::string> env;
  std::map<std::string, TreeNode> anchors;
  for (const auto &d : docs) {
    docVals.push_back(treeToObject(d.root, "NcConfigSection"));
    allComments.insert(allComments.end(), d.comments.begin(), d.comments.end());
    env.insert(env.end(), d.envUsed.begin(), d.envUsed.end());
    anchors.insert(d.anchors.begin(), d.anchors.end());
  }
  Value obj = configObject(docs[0].root,
                           {{"docs", Value(std::move(docVals))},
                            {"anchors", anchorsValue(anchors)},
                            {"boxes", textList(commentBlocks(allComments))},
                            {"comments", commentCells(allComments)},
                            {"env_vars", textList(env)},
                            {"file", Value(file)}});
  ev.ok = true;
  return obj;
}

TreeNode configTree(const Value &v) {
  if (isObjectOf(v, "NcConfig")) {
    const Value *order = field(v, "key_order");
    if (order && given(*order))
      return valueToTree(v); // key_order lists the top-level keys
    const Value *def = field(v, "default");
    return def ? valueToTree(*def) : TreeNode();
  }
  return valueToTree(v);
}

// save_yaml(file, data, indent, flow, multi_doc, boxes, sort_keys, mode)
Value saveYaml(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  const int indent = static_cast<int>(optInt(a[2], 2));
  const bool flow = optBool(a[3], false), multi = optBool(a[4], false), sortKeys = optBool(a[6], false);
  const std::string mode = lower(optText(a[7], "w"));
  std::string text;
  for (const auto &bx : optTextList(a[5])) {
    size_t s0 = 0;
    while (s0 <= bx.size()) {
      size_t e = bx.find('\n', s0);
      if (e == std::string::npos)
        e = bx.size();
      std::string l = bx.substr(s0, e - s0);
      text += (l.rfind("#", 0) == 0 ? l : "# " + l) + "\n";
      s0 = e + 1;
    }
  }
  std::vector<TreeNode> docs;
  if (multi && (a[1].isArray || (a[1].isMatrix && a[1].rows() == 1))) {
    size_t n = a[1].isArray ? a[1].length() : a[1].rowLength(0);
    for (size_t i = 0; i < n; i++)
      docs.push_back(configTree(a[1].isArray ? a[1].at(i) : a[1].at(0, i)));
  } else {
    docs.push_back(configTree(a[1]));
  }
  for (size_t d = 0; d < docs.size(); d++) {
    if (d > 0 || multi)
      text += "---\n";
    text += writeYaml(docs[d], indent, flow, sortKeys);
  }
  bool append = mode == "a" && fileExists(file) && fileSize(file) > 0;
  if (append && text.rfind("---", 0) != 0)
    text = "---\n" + text;
  if (!writeFile(file, text, append, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  emitEvent({"saved", fn, file, 1.0, formatBytes(text.size())});
  ev.ok = true;
  return Value(static_cast<double>(text.size()));
}

// ---- INI ----------------------------------------------------------------------

struct IniFile {
  TreeNode root; // section -> {key -> value}; keys outside a section at top
  std::vector<std::pair<size_t, std::string>> comments;
  std::vector<std::string> envUsed;
};

TreeNode iniValue(const std::string &raw) {
  std::string s = trim(raw);
  std::string l = lower(s);
  if (l == "yes" || l == "on" || l == "true")
    return TreeNode::ofBool(true);
  if (l == "no" || l == "off" || l == "false")
    return TreeNode::ofBool(false);
  if (s.size() >= 2 && (s[0] == '"' || s[0] == '\'') && s.back() == s[0])
    return TreeNode::ofString(s.substr(1, s.size() - 2));
  Value v = parseCell(s, {});
  if (isNumberCell(v))
    return TreeNode::ofNumber(v.number);
  return TreeNode::ofString(s);
}

bool parseIni(const std::string &text, bool interp, IniFile &ini, std::string &err) {
  ini.root = TreeNode();
  ini.root.type = TreeNode::Object;
  std::map<std::string, std::vector<std::pair<std::string, std::string>>> rawSections;
  std::vector<std::string> order{""};
  std::string current;
  std::string *lastValue = nullptr;
  size_t lastIndent = 0;
  size_t start = 0, number = 0;
  while (start <= text.size()) {
    size_t e = text.find('\n', start);
    if (e == std::string::npos)
      e = text.size();
    std::string raw = text.substr(start, e - start);
    start = e + 1;
    number++;
    if (!raw.empty() && raw.back() == '\r')
      raw.pop_back();
    std::string t = trim(raw);
    size_t indent = raw.find_first_not_of(" \t");
    if (t.empty()) {
      lastValue = nullptr;
      continue;
    }
    if (t[0] == ';' || t[0] == '#') {
      ini.comments.push_back({number, t});
      continue;
    }
    if (t[0] == '[') {
      size_t close = t.find(']');
      if (close == std::string::npos) {
        err = "a [section] header is not closed (line " + std::to_string(number) + ")";
        return false;
      }
      current = trim(t.substr(1, close - 1));
      if (std::find(order.begin(), order.end(), current) == order.end())
        order.push_back(current);
      lastValue = nullptr;
      continue;
    }
    // continuation line
    if (lastValue && indent != std::string::npos && indent > lastIndent) {
      *lastValue += "\n" + t;
      continue;
    }
    size_t eq = t.find_first_of("=:");
    if (eq == std::string::npos) {
      err = "expected 'key = value' (line " + std::to_string(number) + "): " + t;
      return false;
    }
    std::string key = trim(t.substr(0, eq));
    std::string value = trim(t.substr(eq + 1));
    // inline comment: " ; ..." or " # ..." outside quotes
    bool q = false;
    for (size_t i = 0; i < value.size(); i++) {
      if (value[i] == '"')
        q = !q;
      if (!q && (value[i] == ';' || value[i] == '#') && i > 0 && (value[i - 1] == ' ' || value[i - 1] == '\t')) {
        ini.comments.push_back({number, trim(value.substr(i))});
        value = trim(value.substr(0, i));
        break;
      }
    }
    auto &sec = rawSections[current];
    bool replaced = false;
    for (auto &kv : sec)
      if (kv.first == key) {
        kv.second = value;
        lastValue = &kv.second;
        replaced = true;
      }
    if (!replaced) {
      sec.emplace_back(key, value);
      lastValue = &sec.back().second;
    }
    lastIndent = indent == std::string::npos ? 0 : indent;
  }
  auto lookup = [&](const std::string &sec, const std::string &key, std::string &out) {
    for (const std::string &s : {sec, std::string("DEFAULT"), std::string("")}) {
      auto it = rawSections.find(s);
      if (it == rawSections.end())
        continue;
      for (const auto &kv : it->second)
        if (kv.first == key) {
          out = kv.second;
          return true;
        }
    }
    return false;
  };
  std::function<std::string(const std::string &, const std::string &, int)> resolve =
      [&](const std::string &sec, const std::string &v, int depth) -> std::string {
    if (!interp || depth > 10)
      return v;
    std::string out;
    for (size_t i = 0; i < v.size(); i++) {
      if (v.compare(i, 2, "%(") == 0) {
        size_t close = v.find(")s", i);
        if (close != std::string::npos) {
          std::string ref, name = v.substr(i + 2, close - i - 2);
          if (lookup(sec, name, ref)) {
            out += resolve(sec, ref, depth + 1);
            i = close + 1;
            continue;
          }
        }
      }
      out.push_back(v[i]);
    }
    return expandEnv(out, ini.envUsed, true);
  };
  for (const auto &secName : order) {
    auto it = rawSections.find(secName);
    if (it == rawSections.end())
      continue;
    if (secName.empty()) {
      for (const auto &kv : it->second)
        ini.root.keys.emplace_back(kv.first, iniValue(resolve("", kv.second, 0)));
      continue;
    }
    TreeNode sec;
    sec.type = TreeNode::Object;
    for (const auto &kv : it->second)
      sec.keys.emplace_back(kv.first, iniValue(resolve(secName, kv.second, 0)));
    ini.root.keys.emplace_back(secName, std::move(sec));
  }
  return true;
}

bool loadIni(const std::string &file, bool interp, IniFile &ini, std::string &err) {
  std::string raw, text;
  return readSource(file, raw, err) && autoDecompress(raw, err) && decodeText(raw, "utf-8", text, err) &&
         parseIni(text, interp, ini, err);
}

// [DEFAULT] values also show in every section (as configparser does).
TreeNode withDefaults(const TreeNode &sec, const TreeNode *defaults) {
  TreeNode out = sec;
  if (defaults && sec.type == TreeNode::Object)
    for (const auto &kv : defaults->keys)
      if (!out.find(kv.first))
        out.keys.push_back(kv);
  return out;
}

// read_ini(file, sec, key, interp, box)
void readIni(const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev("read_ini", file);
  IniFile ini;
  if (!loadIni(file, optBool(a[3], true), ini, err))
    return ctx.fail(err);
  const TreeNode *defaults = ini.root.find("DEFAULT");
  const std::string sec = optText(a[1], ""), key = optText(a[2], "");
  TreeNode result;
  if (!sec.empty()) {
    const TreeNode *s = ini.root.find(sec);
    if (!s || s->type != TreeNode::Object) {
      std::string names;
      for (const auto &kv : ini.root.keys)
        if (kv.second.type == TreeNode::Object)
          names += (names.empty() ? "" : ", ") + kv.first;
      return ctx.fail("no section [" + sec + "] (sections: " + names + ")");
    }
    TreeNode full = withDefaults(*s, defaults);
    if (!key.empty()) {
      const TreeNode *v = full.find(key);
      if (!v)
        return ctx.fail("no key '" + key + "' in [" + sec + "]");
      result = *v;
    } else {
      result = full;
    }
  } else if (!key.empty()) {
    const TreeNode *v = ini.root.find(key);
    if (!v || v->type == TreeNode::Object)
      v = defaults ? defaults->find(key) : nullptr;
    for (const auto &kv : ini.root.keys)
      if (!v && kv.second.type == TreeNode::Object)
        v = kv.second.find(key);
    if (!v)
      return ctx.fail("no key '" + key + "' in any section");
    result = *v;
  } else {
    result = ini.root;
    for (auto &kv : result.keys)
      if (kv.second.type == TreeNode::Object && kv.first != "DEFAULT")
        kv.second = withDefaults(kv.second, defaults);
  }
  out.push_back(treeToValue(result));
  if (nout > 1) {
    Fields info;
    std::vector<std::string> sections;
    for (const auto &kv : ini.root.keys)
      if (kv.second.type == TreeNode::Object)
        sections.push_back(kv.first);
    info["sections"] = textList(sections);
    info["boxes"] = optBool(a[4], true) ? textList(commentBlocks(ini.comments)) : textList({});
    info["comments"] = commentCells(ini.comments);
    info["env_vars"] = textList(ini.envUsed);
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

Value loadIniFn(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev("load_ini", file);
  IniFile ini;
  if (!loadIni(file, optBool(a[1], true), ini, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  const TreeNode *defaults = ini.root.find("DEFAULT");
  TreeNode merged = ini.root;
  for (auto &kv : merged.keys)
    if (kv.second.type == TreeNode::Object && kv.first != "DEFAULT")
      kv.second = withDefaults(kv.second, defaults);
  Value obj = configObject(merged, {{"defaults", defaults ? treeToValue(*defaults) : Value(Fields{})},
                                    {"boxes", textList(commentBlocks(ini.comments))},
                                    {"comments", commentCells(ini.comments)},
                                    {"env_vars", textList(ini.envUsed)},
                                    {"file", Value(file)}});
  ev.ok = true;
  return obj;
}

std::string iniText(const TreeNode &v) {
  if (v.type == TreeNode::String) {
    // continuation lines for multi-line text
    std::string out;
    for (char c : v.str)
      out += c == '\n' ? std::string("\n    ") : std::string(1, c);
    return out;
  }
  return yamlScalar(v);
}

// save_ini(file, data, sec, delim, boxes, mode)
Value saveIni(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev("save_ini", file);
  const std::string defSec = optText(a[2], "General"), delim = a[3].isText ? a[3].text() : " = ";
  const std::string mode = lower(optText(a[5], "w"));
  TreeNode data = configTree(a[1]);
  if (data.type != TreeNode::Object) {
    ctx.fail("INI data must be a dict of sections (section -> key -> value)");
    return Value(0.0);
  }
  // scalars at the top go to [sec]
  TreeNode sections;
  sections.type = TreeNode::Object;
  TreeNode loose;
  loose.type = TreeNode::Object;
  for (const auto &kv : data.keys) {
    if (kv.second.type == TreeNode::Object) {
      for (const auto &inner : kv.second.keys)
        if (inner.second.type == TreeNode::Object || inner.second.type == TreeNode::Array) {
          ctx.fail("INI holds section -> key -> value only; [" + kv.first + "] " + inner.first + " is nested");
          return Value(0.0);
        }
      sections.keys.push_back(kv);
    } else if (kv.second.type == TreeNode::Array) {
      ctx.fail("INI values cannot be lists ('" + kv.first + "')");
      return Value(0.0);
    } else {
      loose.keys.push_back(kv);
    }
  }
  if (!loose.keys.empty()) {
    if (TreeNode *s = sections.find(defSec))
      for (const auto &kv : loose.keys)
        s->keys.push_back(kv);
    else
      sections.keys.insert(sections.keys.begin(), {defSec, loose});
  }
  // A loaded file shows [DEFAULT] values inside every section; keys that
  // only repeat [DEFAULT] are not written again.
  if (const TreeNode *defaults = sections.find("DEFAULT")) {
    const TreeNode defs = *defaults;
    const JsonStyle compact{0, false, "str"};
    for (auto &kv : sections.keys) {
      if (kv.first == "DEFAULT")
        continue;
      std::vector<std::pair<std::string, TreeNode>> keep;
      for (auto &inner : kv.second.keys) {
        const TreeNode *d = defs.find(inner.first);
        if (!d || writeJson(*d, compact) != writeJson(inner.second, compact))
          keep.push_back(std::move(inner));
      }
      kv.second.keys = std::move(keep);
    }
  }
  std::vector<std::pair<size_t, std::string>> keptComments;
  if (mode == "a" && fileExists(file)) {
    IniFile old;
    if (!loadIni(file, false, old, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    keptComments = old.comments;
    TreeNode merged = old.root;
    for (const auto &kv : sections.keys) {
      TreeNode *s = merged.find(kv.first);
      if (!s) {
        merged.keys.push_back(kv);
        continue;
      }
      for (const auto &inner : kv.second.keys) {
        if (TreeNode *x = s->find(inner.first))
          *x = inner.second;
        else
          s->keys.push_back(inner);
      }
    }
    sections = merged;
  }
  std::string text;
  for (const auto &bx : optTextList(a[4])) {
    std::string l = trim(bx);
    text += (l.rfind("#", 0) == 0 || l.rfind(";", 0) == 0 ? l : "# " + l) + "\n";
  }
  for (const auto &c : keptComments)
    if (c.first <= 3 && text.find(c.second) == std::string::npos)
      text += c.second + "\n";
  for (const auto &kv : sections.keys) {
    if (kv.second.type != TreeNode::Object) {
      text += kv.first + delim + iniText(kv.second) + "\n";
      continue;
    }
    if (!text.empty())
      text += "\n";
    text += "[" + kv.first + "]\n";
    for (const auto &inner : kv.second.keys)
      text += inner.first + delim + iniText(inner.second) + "\n";
  }
  if (!writeFile(file, text, false, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  emitEvent({"saved", "save_ini", file, 1.0, formatBytes(text.size())});
  ev.ok = true;
  return Value(static_cast<double>(text.size()));
}

} // namespace

void registerConfig(Registry &reg) {
  for (const char *ext : {"yaml", "yml"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, doc=0, path=\"\", env=true, box=true",
             "read a ." + e + " document (doc=\"all\" for every --- document; path=\"server.db\")",
             "yaml.safe_load", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
               readYaml("read_" + e, a, nout, out, ctx);
             });
    addFn(reg, "load_" + e, "file, env=true",
          "load a ." + e + " file as a config object (D.database.host, D.docs, D.anchors, D.comments)",
          "ruamel.yaml round-trip load",
          [e](const std::vector<Value> &a, CallContext &ctx) { return loadYaml("load_" + e, a, ctx); });
    addFn(reg, "save_" + e,
          "file, data, indent=2, flow=false, multi_doc=false, boxes=\"\", sort_keys=false, mode=\"w\"",
          "write a dict / config object as ." + e + " (mode=\"a\" appends a --- document)", "yaml.safe_dump",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveYaml("save_" + e, a, ctx); });
  }
  addMulti(reg, "read_ini", "file, sec=\"\", key=\"\", interp=true, box=true",
           "read a .ini file: all sections, one [sec], or one key", "configparser.read", 2, readIni);
  addFn(reg, "load_ini", "file, interp=true",
        "load a .ini file as a config object (D.Database.port, D.defaults, D.comments)", "configparser",
        loadIniFn);
  addFn(reg, "save_ini", "file, data, sec=\"General\", delim=\" = \", boxes=\"\", mode=\"w\"",
        "write section -> key -> value data as .ini (mode=\"a\" merges into the file)",
        "configparser.write", saveIni);
}

} // namespace io
} // namespace nc
