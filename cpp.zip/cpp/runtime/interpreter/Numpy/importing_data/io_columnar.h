// Shared model of the columnar formats (CATEGORY 3: parquet, feather / Arrow
// IPC, orc): what a reader returns and what a writer is asked to write.
// Nulls are NaN cells, as in every other NC table.
#ifndef NC_IO_COLUMNAR_H
#define NC_IO_COLUMNAR_H

#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct ColStats {
  bool hasMin = false, hasMax = false;
  Value min, max;
  double nulls = -1, distinct = -1; // -1 = not recorded
};

struct ColGroup { // a parquet row group / feather record batch / orc stripe
  size_t rows = 0;
  uint64_t bytes = 0;
  std::vector<ColStats> stats; // per column of ColFile::table
};

struct ColFile {
  Table table;
  std::vector<std::string> types;                 // per column: int64 float64 bool str date timestamp ...
  std::vector<ColGroup> groups;
  std::vector<std::pair<std::string, std::string>> kv; // footer key-value metadata
  std::vector<std::string> skipped;               // columns that could not be decoded (lists, maps ...)
  std::string format, codec, createdBy;
  size_t totalRows = 0;
};

// simple "col op number" predicate used to skip groups by their min/max
struct Pushdown {
  bool active = false;
  std::string col, op;
  double value = 0;
  bool mayMatch(const ColStats &s) const; // false only when the stats rule the group out
};
Pushdown parsePushdown(const std::string &where);

struct ColReadOptions {
  std::vector<std::string> cols;   // empty = all
  std::vector<size_t> groups;      // 0-based, empty = all
  Pushdown pushdown;
  bool metaOnly = false;           // schema + stats, no data
};

struct ColWriteOptions {
  std::string codec = "zstd";
  int level = 5;
  size_t groupRows = 0;            // 0 = automatic
  bool dictEnc = true;
  std::vector<std::pair<std::string, std::string>> kv;
};

// column kinds a writer uses: "int64" "float64" "bool" "str"
std::vector<std::string> writeKinds(const Table &t);

bool readParquet(const std::string &bytes, const ColReadOptions &o, ColFile &f, std::string &err);
std::string writeParquet(const Table &t, const ColWriteOptions &o, std::string &err);
bool readArrowIpc(const std::string &bytes, const ColReadOptions &o, ColFile &f, std::string &err);
std::string writeArrowIpc(const Table &t, const ColWriteOptions &o, std::string &err);
bool readOrc(const std::string &bytes, const ColReadOptions &o, ColFile &f, std::string &err);
std::string writeOrc(const Table &t, const ColWriteOptions &o, std::string &err);

// days since 1970-01-01 -> "YYYY-MM-DD"; seconds (fractional) -> "YYYY-MM-DD HH:MM:SS[.fff]"
std::string isoDate(int64_t days);
std::string isoTimestamp(double seconds, int digits);

} // namespace io
} // namespace nc

#endif // NC_IO_COLUMNAR_H
