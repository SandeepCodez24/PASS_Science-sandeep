// ZIP archives (PKWARE APPNOTE): reading stored/deflated entries and writing
// deflated archives. Used by xlsx / xlsm / xlsb and KMZ.
#ifndef NC_IO_ZIP_H
#define NC_IO_ZIP_H

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace nc {
namespace io {

struct ZipReader {
  struct Entry {
    std::string name;
    uint16_t method = 0;
    uint32_t compSize = 0, size = 0, localOffset = 0;
  };
  std::vector<Entry> entries;
  const std::string *data = nullptr;
  bool open(const std::string &bytes, std::string &err);
  bool has(const std::string &name) const;
  bool read(const std::string &name, std::string &out, std::string &err) const;
};

struct ZipWriter {
  std::vector<std::pair<std::string, std::string>> files; // name, content
  void add(const std::string &name, const std::string &content) { files.emplace_back(name, content); }
  std::string finish(int level = 6) const;
};

} // namespace io
} // namespace nc

#endif // NC_IO_ZIP_H
