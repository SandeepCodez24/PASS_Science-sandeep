// Shared I/O pieces - see io_common.h.
#include "io_common.h"

#include <algorithm>
#include <charconv>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <set>

#include "../numpy_common.h"
#include "../../../data/DataEngine.h"
#include "io_deflate.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")
#endif

namespace nc {
namespace io {

// ---- progress / events ----------------------------------------------------

namespace {
std::mutex g_listenerMutex;
IoListener g_listener;
std::atomic<bool> g_cancel{false};
} // namespace

void setIoListener(IoListener listener) {
  std::lock_guard<std::mutex> lock(g_listenerMutex);
  g_listener = std::move(listener);
}

void emitEvent(const IoEvent &e) {
  IoListener copy;
  {
    std::lock_guard<std::mutex> lock(g_listenerMutex);
    copy = g_listener;
  }
  if (copy)
    copy(e);
}

bool reportProgress(const std::string &function, const std::string &file, double fraction) {
  IoEvent e;
  e.kind = "progress";
  e.function = function;
  e.file = file;
  e.fraction = std::clamp(fraction, 0.0, 1.0);
  emitEvent(e);
  return g_cancel.load();
}

void requestCancel() { g_cancel.store(true); }
void clearCancel() { g_cancel.store(false); }
bool cancelRequested() { return g_cancel.load(); }

EventScope::EventScope(const std::string &fn, const std::string &f) : function(fn), file(f) {
  clearCancel();
  emitEvent({"open", function, file, 0, ""});
}

EventScope::~EventScope() {
  emitEvent({ok ? "done" : "error", function, file, ok ? 1.0 : 0.0, ""});
}

// ---- options --------------------------------------------------------------

std::string lower(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}

std::string trim(const std::string &s) {
  size_t b = 0, e = s.size();
  while (b < e && std::isspace(static_cast<unsigned char>(s[b])))
    b++;
  while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1])))
    e--;
  return s.substr(b, e - b);
}

bool given(const Value &v) {
  if (v.isText)
    return !v.text().empty();
  if (v.isArray)
    return v.length() > 0;
  if (v.isMatrix)
    return v.rows() > 0;
  return true;
}

std::string optText(const Value &v, const std::string &def) {
  if (v.isText)
    return v.text().empty() ? def : v.text();
  if (numpy::isPlainNumber(v))
    return numberText(v.number);
  return def;
}

bool optBool(const Value &v, bool def) {
  if (v.isText) {
    std::string t = lower(v.text());
    if (t == "true" || t == "yes" || t == "on" || t == "1")
      return true;
    if (t == "false" || t == "no" || t == "off" || t == "0")
      return false;
    return def;
  }
  if (numpy::isPlainNumber(v))
    return v.number != 0;
  return def;
}

long long optInt(const Value &v, long long def) {
  if (numpy::isPlainNumber(v) && std::isfinite(v.number))
    return static_cast<long long>(std::llround(v.number));
  if (v.isText && !v.text().empty()) {
    char *end = nullptr;
    long long n = std::strtoll(v.text().c_str(), &end, 10);
    if (end && *end == '\0')
      return n;
  }
  return def;
}

double optNumber(const Value &v, double def) {
  if (numpy::isPlainNumber(v))
    return v.number;
  if (v.isText && !v.text().empty()) {
    char *end = nullptr;
    double d = std::strtod(v.text().c_str(), &end);
    if (end && *end == '\0')
      return d;
  }
  return def;
}

namespace {
void flattenCells(const Value &v, std::vector<Value> &out) {
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      out.push_back(v.at(i));
  } else if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        out.push_back(v.at(r, c));
  } else {
    out.push_back(v);
  }
}
} // namespace

std::vector<std::string> optTextList(const Value &v) {
  std::vector<std::string> out;
  if (!given(v))
    return out;
  std::vector<Value> cells;
  flattenCells(v, cells);
  for (const Value &c : cells)
    out.push_back(c.isText ? c.text() : cellText(c));
  return out;
}

std::vector<double> optNumbers(const Value &v) {
  std::vector<double> out;
  if (!given(v))
    return out;
  std::vector<Value> cells;
  flattenCells(v, cells);
  for (const Value &c : cells)
    out.push_back(c.isText ? optNumber(c, std::nan("")) : c.number);
  return out;
}

bool parseSelector(const Value &v, Selector &out, std::string &err) {
  out = Selector();
  if (!given(v))
    return true;
  if (numpy::isPlainNumber(v) && v.number < 0 && !v.isText)
    return true; // -1 = all
  std::vector<Value> cells;
  flattenCells(v, cells);
  for (const Value &c : cells) {
    if (c.isText) {
      // "1:5" written as text works too.
      const std::string t = trim(c.text());
      size_t colon = t.find(':');
      char *e1 = nullptr;
      if (colon != std::string::npos) {
        long long a = std::strtoll(t.substr(0, colon).c_str(), &e1, 10);
        long long b = std::strtoll(t.substr(colon + 1).c_str(), nullptr, 10);
        if (b >= a && a >= 1) {
          for (long long k = a; k <= b; k++)
            out.positions.push_back(k);
          continue;
        }
      }
      out.names.push_back(c.text());
    } else if (numpy::isPlainNumber(c)) {
      if (c.number != std::floor(c.number)) {
        err = "a position must be a whole number, got " + numberText(c.number);
        return false;
      }
      out.positions.push_back(static_cast<long long>(c.number));
    } else {
      err = "a selection must be names or positions";
      return false;
    }
  }
  out.all = out.positions.empty() && out.names.empty();
  return true;
}

bool resolveSelector(const Selector &sel, const std::vector<std::string> &names, size_t count,
                     std::vector<size_t> &out, std::string &err) {
  out.clear();
  if (sel.all) {
    for (size_t i = 0; i < count; i++)
      out.push_back(i);
    return true;
  }
  for (long long p : sel.positions) {
    long long idx = p < 0 ? static_cast<long long>(count) + p : p - 1;
    if (idx < 0 || idx >= static_cast<long long>(count)) {
      err = "position " + std::to_string(p) + " is outside 1.." + std::to_string(count);
      return false;
    }
    out.push_back(static_cast<size_t>(idx));
  }
  for (const std::string &n : sel.names) {
    size_t found = names.size();
    for (size_t i = 0; i < names.size() && found == names.size(); i++)
      if (names[i] == n)
        found = i;
    for (size_t i = 0; i < names.size() && found == names.size(); i++)
      if (lower(names[i]) == lower(n) || fieldName(names[i]) == n)
        found = i;
    if (found == names.size()) {
      std::string list;
      for (size_t i = 0; i < names.size() && i < 12; i++)
        list += (i ? ", " : "") + names[i];
      err = "no column '" + n + "' (there are: " + list + (names.size() > 12 ? ", ..." : "") + ")";
      return false;
    }
    out.push_back(found);
  }
  return true;
}

bool parseByteSize(const std::string &text, uint64_t &bytes) {
  std::string t = lower(trim(text));
  if (t.empty())
    return false;
  size_t i = 0;
  while (i < t.size() && (std::isdigit(static_cast<unsigned char>(t[i])) || t[i] == '.'))
    i++;
  if (i == 0)
    return false;
  double n = std::strtod(t.substr(0, i).c_str(), nullptr);
  std::string unit = trim(t.substr(i));
  double mul = 1;
  if (unit.empty() || unit == "b" || unit == "bytes")
    mul = 1;
  else if (unit == "k" || unit == "kb" || unit == "kib")
    mul = 1024.0;
  else if (unit == "m" || unit == "mb" || unit == "mib")
    mul = 1024.0 * 1024;
  else if (unit == "g" || unit == "gb" || unit == "gib")
    mul = 1024.0 * 1024 * 1024;
  else
    return false;
  bytes = static_cast<uint64_t>(n * mul);
  return true;
}

std::string formatBytes(uint64_t n) {
  char buf[64];
  if (n >= 1024ull * 1024 * 1024)
    std::snprintf(buf, sizeof buf, "%.2f GB", n / (1024.0 * 1024 * 1024));
  else if (n >= 1024ull * 1024)
    std::snprintf(buf, sizeof buf, "%.2f MB", n / (1024.0 * 1024));
  else if (n >= 1024)
    std::snprintf(buf, sizeof buf, "%.1f KB", n / 1024.0);
  else
    std::snprintf(buf, sizeof buf, "%llu bytes", static_cast<unsigned long long>(n));
  return buf;
}

// ---- files ----------------------------------------------------------------

namespace {
std::filesystem::path toPath(const std::string &utf8) {
#ifdef _WIN32
  int n = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), nullptr, 0);
  std::wstring w(static_cast<size_t>(n), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), w.data(), n);
  return std::filesystem::path(w);
#else
  return std::filesystem::path(utf8);
#endif
}

} // namespace

std::filesystem::path resolvePath(const std::string &utf8) {
  std::filesystem::path path = toPath(utf8);
  if (path.is_relative() && !path.empty()) {
    const auto &currentFolder = ncdata::DataEngine::instance().currentFolder();
    if (!currentFolder.empty())
      path = currentFolder / path;
  }
  return path;
}

bool readFile(const std::string &path, std::string &bytes, std::string &err) {
  std::error_code ec;
  const auto p = resolvePath(path);
  if (!std::filesystem::exists(p, ec)) {
    err = "file not found: " + path;
    return false;
  }
  if (std::filesystem::is_directory(p, ec)) {
    err = "'" + path + "' is a folder, not a file";
    return false;
  }
  std::ifstream in(p, std::ios::binary);
  if (!in) {
    err = "cannot open '" + path + "' (locked or no read permission)";
    return false;
  }
  in.seekg(0, std::ios::end);
  std::streamoff size = in.tellg();
  in.seekg(0, std::ios::beg);
  bytes.assign(static_cast<size_t>(size < 0 ? 0 : size), '\0');
  if (size > 0)
    in.read(bytes.data(), size);
  return true;
}

bool writeFile(const std::string &path, const std::string &bytes, bool append, std::string &err) {
  const auto p = resolvePath(path);
  std::error_code ec;
  if (p.has_parent_path() && !std::filesystem::exists(p.parent_path(), ec)) {
    err = "folder does not exist: " + p.parent_path().u8string();
    return false;
  }
  std::ofstream out(p, std::ios::binary | (append ? std::ios::app : std::ios::trunc));
  if (!out) {
    err = "cannot write '" + path + "' (no permission, or the file is open elsewhere)";
    return false;
  }
  out.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
  if (!out) {
    err = "writing '" + path + "' failed (disk full?)";
    return false;
  }
  return true;
}

bool fileExists(const std::string &path) {
  std::error_code ec;
  return std::filesystem::exists(resolvePath(path), ec);
}

uint64_t fileSize(const std::string &path) {
  std::error_code ec;
  auto n = std::filesystem::file_size(resolvePath(path), ec);
  return ec ? 0 : static_cast<uint64_t>(n);
}

std::string extensionOf(const std::string &path) {
  size_t slash = path.find_last_of("/\\");
  size_t dot = path.find_last_of('.');
  if (dot == std::string::npos || (slash != std::string::npos && dot < slash))
    return "";
  return lower(path.substr(dot + 1));
}

bool isUrl(const std::string &s) {
  std::string l = lower(s.substr(0, 8));
  return l.rfind("http://", 0) == 0 || l.rfind("https://", 0) == 0;
}

bool fetchUrl(const std::string &url, std::string &bytes, std::string &err) {
#ifdef _WIN32
  int n = MultiByteToWideChar(CP_UTF8, 0, url.c_str(), -1, nullptr, 0);
  std::wstring wurl(static_cast<size_t>(n), L'\0');
  MultiByteToWideChar(CP_UTF8, 0, url.c_str(), -1, wurl.data(), n);
  URL_COMPONENTS uc{};
  uc.dwStructSize = sizeof uc;
  wchar_t host[256] = {0}, pathBuf[4096] = {0};
  uc.lpszHostName = host;
  uc.dwHostNameLength = 255;
  uc.lpszUrlPath = pathBuf;
  uc.dwUrlPathLength = 4095;
  wchar_t extra[4096] = {0};
  uc.lpszExtraInfo = extra;
  uc.dwExtraInfoLength = 4095;
  if (!WinHttpCrackUrl(wurl.c_str(), 0, 0, &uc)) {
    err = "not a valid URL: " + url;
    return false;
  }
  std::wstring object = std::wstring(pathBuf) + extra;
  HINTERNET session = WinHttpOpen(L"NC-IO/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                  WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
  if (!session)
    session = WinHttpOpen(L"NC-IO/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME,
                          WINHTTP_NO_PROXY_BYPASS, 0);
  if (!session) {
    err = "network is not available (WinHTTP)";
    return false;
  }
  WinHttpSetTimeouts(session, 10000, 10000, 20000, 30000);
  HINTERNET connect = WinHttpConnect(session, host, uc.nPort, 0);
  HINTERNET request =
      connect ? WinHttpOpenRequest(connect, L"GET", object.c_str(), nullptr, WINHTTP_NO_REFERER,
                                   WINHTTP_DEFAULT_ACCEPT_TYPES,
                                   uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0)
              : nullptr;
  bool ok = request && WinHttpSendRequest(request, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                                          WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
            WinHttpReceiveResponse(request, nullptr);
  DWORD status = 0, len = sizeof status;
  if (ok)
    WinHttpQueryHeaders(request, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                        WINHTTP_HEADER_NAME_BY_INDEX, &status, &len, WINHTTP_NO_HEADER_INDEX);
  bytes.clear();
  if (ok && status >= 200 && status < 300) {
    for (;;) {
      DWORD avail = 0;
      if (!WinHttpQueryDataAvailable(request, &avail) || avail == 0)
        break;
      std::string chunk(avail, '\0');
      DWORD got = 0;
      if (!WinHttpReadData(request, chunk.data(), avail, &got) || got == 0)
        break;
      bytes.append(chunk, 0, got);
    }
  }
  if (request) WinHttpCloseHandle(request);
  if (connect) WinHttpCloseHandle(connect);
  WinHttpCloseHandle(session);
  if (!ok) {
    err = "cannot download " + url + " (no network, or the host refused)";
    return false;
  }
  if (status < 200 || status >= 300) {
    err = "download of " + url + " failed with HTTP status " + std::to_string(status);
    return false;
  }
  return true;
#else
  (void)bytes;
  err = "downloading URLs is only built in on Windows; save " + url + " to a file first";
  return false;
#endif
}

bool readSource(const std::string &pathOrUrl, std::string &bytes, std::string &err) {
  return isUrl(pathOrUrl) ? fetchUrl(pathOrUrl, bytes, err) : readFile(pathOrUrl, bytes, err);
}

bool autoDecompress(std::string &bytes, std::string &err) {
  if (!isGzip(bytes))
    return true;
  std::string out;
  if (!gzipDecompress(bytes, out, err))
    return false;
  bytes.swap(out);
  return true;
}

bool applyCompression(const std::string &codec, int level, std::string &bytes, std::string &err) {
  const std::string c = lower(codec);
  if (c.empty() || c == "none" || c == "no" || c == "false")
    return true;
  if (level < 0)
    level = 6;
  level = std::clamp(level, 0, 9);
  if (c == "gz" || c == "gzip" || c == "yes" || c == "true" || c == "deflate") {
    bytes = gzipCompress(bytes, level);
    return true;
  }
  if (c == "zlib") {
    bytes = zlibCompress(bytes, level);
    return true;
  }
  err = "compress=\"" + codec + "\" is not built in; use \"gz\" (or \"none\")";
  return false;
}

bool checkMaxSize(const Value &maxSize, uint64_t bytes, std::string &err) {
  if (!given(maxSize))
    return true;
  uint64_t budget = 0;
  if (!parseByteSize(optText(maxSize), budget)) {
    err = "max_size \"" + optText(maxSize) + "\" is not a size (write e.g. \"48kb\", \"5mb\")";
    return false;
  }
  if (bytes > budget) {
    err = "the output is " + formatBytes(bytes) + ", over max_size " + formatBytes(budget) +
          " (try compress=\"gz\", fewer rows, or a larger max_size)";
    return false;
  }
  return true;
}

// ---- encodings ------------------------------------------------------------

namespace {
void putUtf8(std::string &out, uint32_t cp) {
  if (cp < 0x80) {
    out.push_back(static_cast<char>(cp));
  } else if (cp < 0x800) {
    out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else if (cp < 0x10000) {
    out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else {
    out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  }
}

// Next code point of UTF-8 text (invalid bytes come back as themselves).
uint32_t nextUtf8(const std::string &s, size_t &i) {
  unsigned char c = static_cast<unsigned char>(s[i++]);
  if (c < 0x80)
    return c;
  int extra = c >= 0xF0 ? 3 : c >= 0xE0 ? 2 : c >= 0xC0 ? 1 : 0;
  uint32_t cp = c & (0x3F >> extra);
  for (int k = 0; k < extra && i < s.size(); k++)
    cp = (cp << 6) | (static_cast<unsigned char>(s[i++]) & 0x3F);
  return cp;
}

const uint16_t kCp1252[32] = {0x20AC, 0x81,   0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021,
                              0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0x8D,   0x017D, 0x8F,
                              0x90,   0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014,
                              0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x9D,   0x017E, 0x0178};
} // namespace

bool decodeText(const std::string &raw, const std::string &encIn, std::string &utf8,
                std::string &err) {
  std::string enc = lower(encIn);
  enc.erase(std::remove(enc.begin(), enc.end(), '_'), enc.end());
  utf8.clear();
  const unsigned char *p = reinterpret_cast<const unsigned char *>(raw.data());
  bool le16 = raw.size() >= 2 && p[0] == 0xFF && p[1] == 0xFE;
  bool be16 = raw.size() >= 2 && p[0] == 0xFE && p[1] == 0xFF;
  if (le16 || be16 || enc.rfind("utf-16", 0) == 0 || enc.rfind("utf16", 0) == 0) {
    bool big = be16 || enc == "utf-16be" || enc == "utf16be";
    size_t i = (le16 || be16) ? 2 : 0;
    while (i + 1 < raw.size()) {
      uint32_t u = big ? (p[i] << 8 | p[i + 1]) : (p[i + 1] << 8 | p[i]);
      i += 2;
      if (u >= 0xD800 && u < 0xDC00 && i + 1 < raw.size()) {
        uint32_t lo = big ? (p[i] << 8 | p[i + 1]) : (p[i + 1] << 8 | p[i]);
        i += 2;
        u = 0x10000 + ((u - 0xD800) << 10) + (lo - 0xDC00);
      }
      putUtf8(utf8, u);
    }
    return true;
  }
  if (enc.empty() || enc == "utf-8" || enc == "utf8" || enc == "ascii" || enc == "us-ascii") {
    size_t start = (raw.size() >= 3 && p[0] == 0xEF && p[1] == 0xBB && p[2] == 0xBF) ? 3 : 0;
    utf8.assign(raw, start, std::string::npos);
    return true;
  }
  if (enc == "latin-1" || enc == "latin1" || enc == "iso-8859-1" || enc == "iso8859-1" ||
      enc == "cp1252" || enc == "windows-1252") {
    bool w = enc == "cp1252" || enc == "windows-1252";
    for (unsigned char c : raw)
      putUtf8(utf8, (w && c >= 0x80 && c < 0xA0) ? kCp1252[c - 0x80] : c);
    return true;
  }
  err = "unknown encoding \"" + encIn + "\" (built in: utf-8, latin-1, cp1252, utf-16)";
  return false;
}

bool encodeText(const std::string &utf8, const std::string &encIn, std::string &raw,
                std::string &err) {
  std::string enc = lower(encIn);
  raw.clear();
  if (enc.empty() || enc == "utf-8" || enc == "utf8" || enc == "ascii") {
    raw = utf8;
    return true;
  }
  if (enc == "utf-8-sig") {
    raw = "\xEF\xBB\xBF" + utf8;
    return true;
  }
  if (enc.rfind("utf-16", 0) == 0 || enc.rfind("utf16", 0) == 0) {
    bool big = enc.find("be") != std::string::npos;
    raw = big ? std::string("\xFE\xFF", 2) : std::string("\xFF\xFE", 2);
    auto put16 = [&](uint32_t u) {
      if (big) {
        raw.push_back(static_cast<char>(u >> 8));
        raw.push_back(static_cast<char>(u & 0xFF));
      } else {
        raw.push_back(static_cast<char>(u & 0xFF));
        raw.push_back(static_cast<char>(u >> 8));
      }
    };
    for (size_t i = 0; i < utf8.size();) {
      uint32_t cp = nextUtf8(utf8, i);
      if (cp >= 0x10000) {
        cp -= 0x10000;
        put16(0xD800 + (cp >> 10));
        put16(0xDC00 + (cp & 0x3FF));
      } else {
        put16(cp);
      }
    }
    return true;
  }
  if (enc == "latin-1" || enc == "latin1" || enc == "iso-8859-1" || enc == "cp1252" ||
      enc == "windows-1252") {
    for (size_t i = 0; i < utf8.size();) {
      uint32_t cp = nextUtf8(utf8, i);
      raw.push_back(cp < 256 ? static_cast<char>(cp) : '?');
    }
    return true;
  }
  err = "unknown encoding \"" + encIn + "\" (built in: utf-8, utf-8-sig, latin-1, utf-16)";
  return false;
}

// ---- values ---------------------------------------------------------------

Value makeObject(const std::string &className, Fields fields) {
  Value v(fields);
  v.isDict = false;
  v.isObject = true;
  v.classNameMut() = className;
  return v;
}

bool isObjectOf(const Value &v, const std::string &className) {
  return v.isObject && v.className() == className;
}

const Value *field(const Value &obj, const std::string &name) {
  if (!obj.isObject && !obj.isDict)
    return nullptr;
  auto it = obj.dict().find(name);
  return it == obj.dict().end() ? nullptr : &it->second;
}

Value textList(const std::vector<std::string> &items) {
  std::vector<Value> cells;
  cells.reserve(items.size());
  for (const auto &s : items)
    cells.push_back(Value(s));
  return Value(std::move(cells));
}

Value numberList(const std::vector<double> &items) { return numpy::makeArray(items); }

Value dictOf(const Fields &f) { return Value(f); }

Value parseCell(const std::string &raw, const std::vector<std::string> &na) {
  const std::string s = trim(raw);
  for (const auto &n : na)
    if (s == n)
      return Value(std::nan(""));
  if (s.empty())
    return Value(std::string());
  const std::string l = lower(s);
  if (l == "true")
    return Value::boolean(true);
  if (l == "false")
    return Value::boolean(false);
  const char *b = s.c_str();
  char *end = nullptr;
  double d = std::strtod(b, &end);
  if (end && *end == '\0' && end != b) {
    // strtod also takes "0x1A" and "infinity" - only plain decimal forms
    // and inf/nan count as numbers here.
    if (l.find("0x") == std::string::npos)
      return Value(d);
  }
  return Value(s);
}

bool isNumberCell(const Value &v) { return numpy::isPlainNumber(v) && !v.isBool() && !v.isTime(); }

std::string numberText(double d, const std::string &fmt) {
  if (std::isnan(d))
    return "NaN";
  if (std::isinf(d))
    return d > 0 ? "Inf" : "-Inf";
  char buf[64];
  if (!fmt.empty()) {
    std::snprintf(buf, sizeof buf, fmt.c_str(), d);
    return buf;
  }
  if (d == std::floor(d) && std::fabs(d) < 1e15) {
    std::snprintf(buf, sizeof buf, "%.0f", d);
    return std::strcmp(buf, "-0") == 0 ? "0" : buf;
  }
  auto res = std::to_chars(buf, buf + sizeof buf, d);
  return std::string(buf, res.ptr);
}

std::string cellText(const Value &v, const std::string &floatFmt) {
  if (v.isText)
    return v.text();
  if (v.isBool())
    return v.number != 0 ? "true" : "false";
  if (v.isInt())
    return v.intText();
  if (numpy::isPlainNumber(v))
    return numberText(v.number, (v.number == std::floor(v.number)) ? "" : floatFmt);
  return "";
}

std::string fieldName(const std::string &raw) {
  std::string out;
  bool underscore = false;
  for (unsigned char c : raw) {
    if (std::isalnum(c) || c >= 0x80 || (c == '_' && !underscore)) {
      out.push_back(static_cast<char>(c));
      underscore = false;
    } else if (!out.empty() && !underscore) {
      out.push_back('_');
      underscore = true;
    }
  }
  while (!out.empty() && out.back() == '_')
    out.pop_back();
  if (!out.empty() && std::isdigit(static_cast<unsigned char>(out[0])))
    out = "x" + out;
  return out;
}

std::vector<std::string> uniqueNames(const std::vector<std::string> &raw) {
  std::vector<std::string> out;
  std::map<std::string, int> seen;
  for (size_t i = 0; i < raw.size(); i++) {
    std::string n = trim(raw[i]);
    if (n.empty())
      n = "Col_" + std::to_string(i + 1);
    if (seen.count(n)) {
      int k = ++seen[n];
      std::string cand = n + "_" + std::to_string(k);
      while (seen.count(cand))
        cand = n + "_" + std::to_string(++k);
      seen[cand] = 1;
      out.push_back(cand);
    } else {
      seen[n] = 1;
      out.push_back(n);
    }
  }
  return out;
}

// ---- tables ---------------------------------------------------------------

void normalizeTable(Table &t) {
  size_t width = t.cols.size();
  for (const auto &r : t.rows)
    width = std::max(width, r.size());
  while (t.cols.size() < width)
    t.cols.push_back("");
  t.cols = uniqueNames(t.cols);
  for (auto &r : t.rows)
    while (r.size() < width)
      r.push_back(Value(std::nan("")));
}

Value tableData(const Table &t) {
  bool numeric = true;
  for (const auto &r : t.rows) {
    for (const auto &c : r)
      if (!isNumberCell(c)) {
        numeric = false;
        break;
      }
    if (!numeric)
      break;
  }
  if (numeric) {
    std::vector<std::vector<double>> m;
    m.reserve(t.rows.size());
    for (const auto &r : t.rows) {
      std::vector<double> row;
      row.reserve(r.size());
      for (const auto &c : r)
        row.push_back(c.number);
      m.push_back(std::move(row));
    }
    return numpy::makeMatrix(m);
  }
  return Value(t.rows);
}

Value tableColumn(const Table &t, size_t c) {
  bool numeric = true;
  for (const auto &r : t.rows)
    if (!isNumberCell(r[c])) {
      numeric = false;
      break;
    }
  if (numeric) {
    std::vector<double> v;
    v.reserve(t.rows.size());
    for (const auto &r : t.rows)
      v.push_back(r[c].number);
    return numpy::makeArray(v);
  }
  std::vector<Value> cells;
  cells.reserve(t.rows.size());
  for (const auto &r : t.rows)
    cells.push_back(r[c]);
  return Value(std::move(cells));
}

namespace {
bool looksLikeDate(const std::string &s) {
  // 2026-03-01, 2026-03-01T10:00:00, 2026/03/01 12:00
  if (s.size() < 10)
    return false;
  for (int i : {0, 1, 2, 3, 5, 6, 8, 9})
    if (!std::isdigit(static_cast<unsigned char>(s[i])))
      return false;
  return (s[4] == '-' && s[7] == '-') || (s[4] == '/' && s[7] == '/');
}
} // namespace

std::string columnType(const Table &t, size_t c) {
  bool any = false, allInt = true, allNum = true, allBool = true, allDate = true;
  for (const auto &r : t.rows) {
    const Value &v = r[c];
    if (v.isText && v.text().empty())
      continue;
    if (numpy::isPlainNumber(v) && std::isnan(v.number) && !v.isTime())
      continue;
    any = true;
    if (!v.isBool())
      allBool = false;
    if (isNumberCell(v)) {
      if (v.number != std::floor(v.number))
        allInt = false;
      allDate = false;
    } else {
      allNum = false;
      allInt = false;
      if (!(v.isText && looksLikeDate(v.text())))
        allDate = false;
    }
  }
  if (!any)
    return "empty";
  if (allBool)
    return "bool";
  if (allNum)
    return allInt ? "int64" : "float64";
  if (allDate)
    return "datetime";
  return "str";
}

Value tableSchema(const Table &t) {
  Fields f;
  for (size_t c = 0; c < t.cols.size(); c++)
    f[t.cols[c]] = Value(columnType(t, c));
  return Value(f);
}

Value tableObject(const Table &t, Fields extra, const std::string &cls) {
  Fields f;
  for (size_t c = 0; c < t.cols.size(); c++) {
    std::string n = fieldName(t.cols[c]);
    if (!n.empty())
      f[n] = tableColumn(t, c);
  }
  f["cols"] = textList(t.cols);
  f["rows"] = Value(static_cast<double>(t.rows.size()));
  f["data"] = tableData(t);
  f["schema"] = tableSchema(t);
  for (auto &kv : extra)
    f[kv.first] = std::move(kv.second);
  return makeObject(cls, std::move(f));
}

bool valueToTable(const Value &v, Table &t, std::string &err, bool firstRowHeader) {
  t = Table();
  if (v.isObject) {
    const Value *cols = field(v, "cols");
    const Value *data = field(v, "data");
    if (!cols || !data) {
      err = "this object (" + v.className() + ") is not a table";
      return false;
    }
    if (!valueToTable(*data, t, err, false))
      return false;
    std::vector<std::string> names = optTextList(*cols);
    for (size_t i = 0; i < names.size() && i < t.cols.size(); i++)
      t.cols[i] = names[i];
    normalizeTable(t);
    return true;
  }
  if (v.isDict) {
    std::vector<std::string> keys;
    for (const auto &kv : v.dict())
      keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    std::vector<std::vector<Value>> cols;
    size_t n = 0;
    for (const auto &k : keys) {
      std::vector<Value> cells;
      const Value &col = v.dict().at(k);
      if (col.isArray)
        for (size_t i = 0; i < col.length(); i++) cells.push_back(col.at(i));
      else if (col.isMatrix)
        for (size_t r = 0; r < col.rows(); r++)
          for (size_t c = 0; c < col.rowLength(r); c++) cells.push_back(col.at(r, c));
      else
        cells.push_back(col);
      n = std::max(n, cells.size());
      cols.push_back(std::move(cells));
    }
    t.cols = keys;
    t.rows.assign(n, std::vector<Value>(keys.size(), Value(std::nan(""))));
    for (size_t c = 0; c < cols.size(); c++)
      for (size_t r = 0; r < cols[c].size(); r++)
        t.rows[r][c] = cols[c][r];
    normalizeTable(t);
    return true;
  }
  if (v.isND()) {
    err = "an N-dimensional matrix cannot be written as a table - reshape it to 2-D first";
    return false;
  }
  if (v.isMatrix) {
    size_t start = 0;
    if (firstRowHeader && v.rows() > 0) {
      bool allText = v.rowLength(0) > 0;
      for (size_t c = 0; c < v.rowLength(0); c++)
        if (!v.at(0, c).isText)
          allText = false;
      if (allText) {
        for (size_t c = 0; c < v.rowLength(0); c++)
          t.cols.push_back(v.at(0, c).text());
        start = 1;
      }
    }
    for (size_t r = start; r < v.rows(); r++) {
      std::vector<Value> row;
      for (size_t c = 0; c < v.rowLength(r); c++)
        row.push_back(v.at(r, c));
      t.rows.push_back(std::move(row));
    }
    normalizeTable(t);
    return true;
  }
  if (v.isArray) {
    for (size_t i = 0; i < v.length(); i++)
      t.rows.push_back({v.at(i)});
    normalizeTable(t);
    return true;
  }
  if (v.isText || numpy::isPlainNumber(v)) {
    t.rows.push_back({v});
    normalizeTable(t);
    return true;
  }
  err = "this value cannot be written as a table";
  return false;
}

bool selectTable(Table &t, const Value &cols, const Value &rows, std::string &err) {
  Selector cs, rs;
  if (!parseSelector(cols, cs, err) || !parseSelector(rows, rs, err))
    return false;
  std::vector<size_t> ci, ri;
  if (!resolveSelector(cs, t.cols, t.cols.size(), ci, err))
    return false;
  if (!rs.names.empty()) {
    err = "rows are selected by position (rows=[2:500]), not by name";
    return false;
  }
  if (!rs.all) {
    // Rows past the end are simply not there (rows=[1:1000] on 20 rows).
    Selector clipped = rs;
    clipped.positions.clear();
    for (long long p : rs.positions)
      if (p >= 1 && p <= static_cast<long long>(t.rows.size()))
        clipped.positions.push_back(p);
    clipped.all = false;
    if (!resolveSelector(clipped, {}, t.rows.size(), ri, err))
      return false;
  } else if (!resolveSelector(rs, {}, t.rows.size(), ri, err)) {
    return false;
  }
  Table out;
  for (size_t c : ci)
    out.cols.push_back(t.cols[c]);
  for (size_t r : ri) {
    std::vector<Value> row;
    for (size_t c : ci)
      row.push_back(t.rows[r][c]);
    out.rows.push_back(std::move(row));
  }
  t = std::move(out);
  return true;
}

// ---- registration ---------------------------------------------------------

namespace {
std::vector<std::string> &ioNames() {
  static std::vector<std::string> names;
  return names;
}

bool countParams(const std::string &name, const std::string &params, int &minArgs, int &maxArgs) {
  std::vector<ncargs::ParamSpec> specs;
  std::string err;
  if (!ncargs::parseParamList(params, specs, err)) {
    std::cerr << "Error: importing_data: bad parameter line for " << name << ": " << err << "\n";
    return false;
  }
  minArgs = 0;
  for (const auto &s : specs)
    if (s.kind == ncargs::ParamKind::Required)
      minArgs++;
  maxArgs = static_cast<int>(specs.size());
  return true;
}
} // namespace

const std::vector<std::string> &registeredIoNames() { return ioNames(); }

void addFn(Registry &reg, const std::string &name, const std::string &params,
           const std::string &summary, const std::string &origin, SingleFn fn) {
  int mn = 0, mx = 0;
  if (!countParams(name, params, mn, mx))
    return;
  numpy::FunctionSpec spec;
  spec.name = name;
  spec.section = numpy::Section::ImportingData;
  spec.minArgs = mn;
  spec.maxArgs = mx;
  spec.signature = name + "(" + params + ")";
  spec.summary = summary;
  spec.numpyName = origin;
  spec.impl = std::move(fn);
  if (reg.add(std::move(spec))) {
    reg.setParams(name, params);
    ioNames().push_back(name);
  }
}

void addMulti(Registry &reg, const std::string &name, const std::string &params,
              const std::string &summary, const std::string &origin, int maxOutputs, MultiFn fn) {
  int mn = 0, mx = 0;
  if (!countParams(name, params, mn, mx))
    return;
  numpy::FunctionSpec spec;
  spec.name = name;
  spec.section = numpy::Section::ImportingData;
  spec.minArgs = mn;
  spec.maxArgs = mx;
  spec.signature = name + "(" + params + ")";
  spec.summary = summary;
  spec.numpyName = origin;
  spec.multiImpl = std::move(fn);
  spec.maxOutputs = maxOutputs;
  if (reg.add(std::move(spec))) {
    reg.setParams(name, params);
    ioNames().push_back(name);
  }
}

} // namespace io
} // namespace nc

namespace nc {
namespace io {

Value ndFromRowMajor(const std::vector<size_t> &shape, const std::vector<double> &vals) {
  if (shape.size() <= 1)
    return numpy::makeArray(vals);
  if (shape.size() == 2) {
    std::vector<std::vector<double>> m(shape[0], std::vector<double>(shape[1]));
    for (size_t r = 0; r < shape[0]; r++)
      for (size_t c = 0; c < shape[1]; c++)
        m[r][c] = vals[r * shape[1] + c];
    return numpy::makeMatrix(m);
  }
  const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1];
  std::vector<double> buf(vals.size());
  const size_t page = rows * cols;
  for (size_t k = 0; k < vals.size(); k++) {
    size_t p = k / page, within = k % page;
    buf[p * page + (within % cols) * rows + within / cols] = vals[k];
  }
  return Value::ndPacked(shape, buf, false);
}

bool ndToRowMajor(const Value &v, std::vector<size_t> &shape, std::vector<double> &vals) {
  vals.clear();
  if (v.isND()) {
    shape = v.ndShape();
    const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1], page = rows * cols;
    size_t n = v.ndCount();
    vals.resize(n);
    for (size_t k = 0; k < n; k++) {
      size_t p = k / page, within = k % page;
      vals[k] = v.ndAt(p * page + (within % cols) * rows + within / cols).number;
    }
    return true;
  }
  if (v.isMatrix) {
    shape = {v.rows(), v.cols()};
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.cols(); c++)
        vals.push_back(c < v.rowLength(r) ? v.numAt(r, c) : 0);
    return true;
  }
  if (v.isArray) {
    shape = {v.length()};
    for (size_t i = 0; i < v.length(); i++)
      vals.push_back(v.numAt(i));
    return true;
  }
  if (numpy::isPlainNumber(v)) {
    shape = {1};
    vals.push_back(v.number);
    return true;
  }
  return false;
}

} // namespace io
} // namespace nc
