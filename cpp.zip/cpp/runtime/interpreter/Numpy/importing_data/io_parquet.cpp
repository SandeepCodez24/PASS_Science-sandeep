// Apache Parquet reader / writer (Thrift compact protocol footer, data pages
// v1 / v2, PLAIN / dictionary / RLE-bit-packed / DELTA_* / BYTE_STREAM_SPLIT
// encodings, flat and nested-struct columns), hand-written.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>
#include <set>

#include "io_bytes.h"
#include "io_codecs.h"
#include "io_columnar.h"

namespace nc {
namespace io {

// ---- shared helpers (io_columnar.h) ---------------------------------------------------------

std::string isoDate(int64_t days) {
  // civil from days (Howard Hinnant)
  int64_t z = days + 719468, era = (z >= 0 ? z : z - 146096) / 146097;
  int64_t doe = z - era * 146097, yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  int64_t y = yoe + era * 400, doy = doe - (365 * yoe + yoe / 4 - yoe / 100), mp = (5 * doy + 2) / 153;
  int64_t d = doy - (153 * mp + 2) / 5 + 1, m = mp < 10 ? mp + 3 : mp - 9;
  char buf[32];
  std::snprintf(buf, sizeof buf, "%04lld-%02lld-%02lld", static_cast<long long>(y + (m <= 2)), static_cast<long long>(m), static_cast<long long>(d));
  return buf;
}

std::string isoTimestamp(double seconds, int digits) {
  double days = std::floor(seconds / 86400.0);
  double rem = seconds - days * 86400.0;
  int h = static_cast<int>(rem / 3600), mi = static_cast<int>(std::fmod(rem, 3600) / 60);
  double s = std::fmod(rem, 60);
  char buf[64];
  if (digits <= 0) std::snprintf(buf, sizeof buf, "%s %02d:%02d:%02d", isoDate(static_cast<int64_t>(days)).c_str(), h, mi, static_cast<int>(s + 1e-9));
  else std::snprintf(buf, sizeof buf, "%s %02d:%02d:%0*.*f", isoDate(static_cast<int64_t>(days)).c_str(), h, mi, digits + 3, digits, s);
  return buf;
}

std::vector<std::string> writeKinds(const Table &t) {
  std::vector<std::string> k;
  for (size_t c = 0; c < t.cols.size(); c++) {
    bool allNum = true, allBool = true, allInt = true, any = false;
    for (const auto &r : t.rows) {
      const Value &v = r[c];
      bool null = !v.isText && std::isnan(v.number);
      if (null) continue;
      any = true;
      if (v.isText) { allNum = allBool = allInt = false; break; }
      if (!v.isBool()) allBool = false;
      if (v.number != std::floor(v.number) || std::fabs(v.number) > 9007199254740992.0) allInt = false;
    }
    k.push_back(!any ? "float64" : !allNum ? "str" : allBool ? "bool" : allInt ? "int64" : "float64");
  }
  return k;
}

bool Pushdown::mayMatch(const ColStats &s) const {
  if (!active || !s.hasMin || !s.hasMax || s.min.isText || s.max.isText) return true;
  double lo = s.min.number, hi = s.max.number;
  if (op == ">") return hi > value;
  if (op == ">=") return hi >= value;
  if (op == "<") return lo < value;
  if (op == "<=") return lo <= value;
  if (op == "=" || op == "==") return value >= lo && value <= hi;
  return true;
}

Pushdown parsePushdown(const std::string &where) {
  Pushdown p;
  static const char *ops[] = {">=", "<=", "==", "!=", "<>", ">", "<", "="};
  for (const char *op : ops) {
    size_t at = where.find(op);
    if (at == std::string::npos) continue;
    std::string col = trim(where.substr(0, at)), rest = trim(where.substr(at + std::strlen(op)));
    if (col.empty() || col.find(' ') != std::string::npos || where.find(" and ") != std::string::npos || where.find(" or ") != std::string::npos ||
        lower(where).find(" and ") != std::string::npos || lower(where).find(" or ") != std::string::npos)
      return p;
    char *e = nullptr;
    double v = std::strtod(rest.c_str(), &e);
    if (!e || *e) return p;
    if (std::string(op) == "!=" || std::string(op) == "<>") return p;
    if (col.size() >= 2 && (col.front() == '"' || col.front() == '`')) col = col.substr(1, col.size() - 2);
    p.active = true;
    p.col = col;
    p.op = op;
    p.value = v;
    return p;
  }
  return p;
}

namespace {

// ---- Thrift compact protocol ----------------------------------------------------------------

struct TV { // a thrift value
  int type = 0; // compact type ids: 1/2 bool, 3 i8, 4 i16, 5 i32, 6 i64, 7 double, 8 binary, 9 list, 10 set, 11 map, 12 struct
  int64_t i = 0;
  double d = 0;
  std::string s;
  std::vector<TV> list;
  std::map<int, TV> f;
  const TV *get(int id) const { auto it = f.find(id); return it == f.end() ? nullptr : &it->second; }
  int64_t geti(int id, int64_t def = 0) const { const TV *v = get(id); return v ? v->i : def; }
  std::string gets(int id) const { const TV *v = get(id); return v ? v->s : ""; }
};

struct TReader {
  const std::string &b;
  size_t p;
  bool bad = false;
  TReader(const std::string &bytes, size_t start) : b(bytes), p(start) {}
  uint64_t varint() {
    uint64_t v = 0;
    for (int s = 0; s < 70; s += 7) {
      if (p >= b.size()) { bad = true; return 0; }
      unsigned char c = static_cast<unsigned char>(b[p++]);
      v |= static_cast<uint64_t>(c & 0x7F) << s;
      if (!(c & 0x80)) return v;
    }
    bad = true;
    return v;
  }
  int64_t zigzag() { uint64_t v = varint(); return static_cast<int64_t>(v >> 1) ^ -static_cast<int64_t>(v & 1); }
  bool value(int type, TV &out, int depth = 0) {
    if (depth > 64) { bad = true; return false; }
    out.type = type;
    switch (type) {
    case 1: out.i = 1; return true;
    case 2: out.i = 0; return true;
    case 3: if (p >= b.size()) { bad = true; return false; } out.i = static_cast<int8_t>(b[p++]); return true;
    case 4: case 5: case 6: out.i = zigzag(); return !bad;
    case 7: if (p + 8 > b.size()) { bad = true; return false; } out.d = f64le(b, p); p += 8; return true;
    case 8: { uint64_t n = varint(); if (bad || p + n > b.size()) { bad = true; return false; } out.s = b.substr(p, static_cast<size_t>(n)); p += static_cast<size_t>(n); return true; }
    case 9: case 10: {
      if (p >= b.size()) { bad = true; return false; }
      unsigned char h = static_cast<unsigned char>(b[p++]);
      uint64_t n = h >> 4;
      int et = h & 15;
      if (n == 15) n = varint();
      if (n > b.size()) { bad = true; return false; }
      for (uint64_t k = 0; k < n && !bad; k++) {
        TV e;
        if (et == 1 || et == 2) { if (p >= b.size()) { bad = true; return false; } e.type = 1; e.i = b[p++] == 1; }
        else value(et, e, depth + 1);
        out.list.push_back(std::move(e));
      }
      return !bad;
    }
    case 11: {
      uint64_t n = varint();
      if (n == 0) return !bad;
      if (p >= b.size()) { bad = true; return false; }
      unsigned char kt = static_cast<unsigned char>(b[p++]);
      for (uint64_t k = 0; k < n && !bad; k++) { TV key, val; value(kt >> 4, key, depth + 1); value(kt & 15, val, depth + 1); out.list.push_back(key); out.list.push_back(val); }
      return !bad;
    }
    case 12: {
      int last = 0;
      for (;;) {
        if (p >= b.size()) { bad = true; return false; }
        unsigned char h = static_cast<unsigned char>(b[p++]);
        if (h == 0) return true;
        int delta = h >> 4, t = h & 15;
        int id = delta ? last + delta : static_cast<int>(zigzag());
        last = id;
        TV v;
        if (!value(t, v, depth + 1)) return false;
        out.f[id] = std::move(v);
      }
    }
    }
    bad = true;
    return false;
  }
};

struct TWriter {
  std::string out;
  std::vector<int> lastId{0};
  void varint(uint64_t v) { do { unsigned char c = v & 0x7F; v >>= 7; out.push_back(static_cast<char>(c | (v ? 0x80 : 0))); } while (v); }
  void zigzag(int64_t v) { varint((static_cast<uint64_t>(v) << 1) ^ static_cast<uint64_t>(v >> 63)); }
  void field(int id, int type) {
    int delta = id - lastId.back();
    if (delta > 0 && delta <= 15) out.push_back(static_cast<char>((delta << 4) | type));
    else { out.push_back(static_cast<char>(type)); zigzag(id); }
    lastId.back() = id;
  }
  void i32(int id, int64_t v) { field(id, 5); zigzag(v); }
  void i64(int id, int64_t v) { field(id, 6); zigzag(v); }
  void bin(int id, const std::string &s) { field(id, 8); varint(s.size()); out += s; }
  void boolean(int id, bool v) { field(id, v ? 1 : 2); }
  void begin(int id) { field(id, 12); lastId.push_back(0); }
  void end() { out.push_back(0); lastId.pop_back(); }
  void listHead(int id, int et, size_t n) {
    field(id, 9);
    if (n < 15) out.push_back(static_cast<char>((n << 4) | et));
    else { out.push_back(static_cast<char>(0xF0 | et)); varint(n); }
  }
  void beginElem() { lastId.push_back(0); }   // a struct inside a list
  void endElem() { out.push_back(0); lastId.pop_back(); }
};

// ---- RLE / bit-packed hybrid --------------------------------------------------------------------

bool rleDecode(const std::string &b, size_t p, size_t end, int width, size_t count, std::vector<uint32_t> &out) {
  out.clear();
  out.reserve(count);
  size_t bytesPer = static_cast<size_t>((width + 7) / 8);
  while (out.size() < count && p < end) {
    uint64_t h = 0;
    for (int s = 0; p < end; s += 7) { unsigned char c = static_cast<unsigned char>(b[p++]); h |= static_cast<uint64_t>(c & 0x7F) << s; if (!(c & 0x80)) break; }
    if (h & 1) { // bit-packed groups of 8
      size_t n = static_cast<size_t>(h >> 1) * 8;
      size_t bits = n * width, nbytes = (bits + 7) / 8;
      if (p + nbytes > end) nbytes = end - p;
      uint64_t acc = 0;
      int have = 0;
      size_t q = p;
      for (size_t k = 0; k < n && out.size() < count; k++) {
        while (have < width && q < p + nbytes) { acc |= static_cast<uint64_t>(static_cast<unsigned char>(b[q++])) << have; have += 8; }
        out.push_back(static_cast<uint32_t>(width ? acc & ((1ull << width) - 1) : 0));
        acc >>= width;
        have -= width;
      }
      p += nbytes;
    } else {
      size_t n = static_cast<size_t>(h >> 1);
      uint32_t v = 0;
      for (size_t k = 0; k < bytesPer && p < end; k++) v |= static_cast<uint32_t>(static_cast<unsigned char>(b[p++])) << (8 * k);
      for (size_t k = 0; k < n && out.size() < count; k++) out.push_back(v);
    }
  }
  while (out.size() < count) out.push_back(0);
  return true;
}

void rleEncodeRuns(std::string &o, const std::vector<uint32_t> &v, int width) { // RLE runs only
  size_t bytesPer = static_cast<size_t>((width + 7) / 8);
  for (size_t i = 0; i < v.size();) {
    size_t j = i;
    while (j < v.size() && v[j] == v[i] && j - i < (1u << 30)) j++;
    uint64_t h = static_cast<uint64_t>(j - i) << 1;
    do { unsigned char c = h & 0x7F; h >>= 7; o.push_back(static_cast<char>(c | (h ? 0x80 : 0))); } while (h);
    for (size_t k = 0; k < bytesPer; k++) o.push_back(static_cast<char>((v[i] >> (8 * k)) & 0xFF));
    i = j;
  }
}

void bitPack(std::string &o, const std::vector<uint32_t> &v, int width) { // one bit-packed run
  size_t groups = (v.size() + 7) / 8;
  uint64_t h = (static_cast<uint64_t>(groups) << 1) | 1;
  do { unsigned char c = h & 0x7F; h >>= 7; o.push_back(static_cast<char>(c | (h ? 0x80 : 0))); } while (h);
  uint64_t acc = 0;
  int have = 0;
  for (size_t k = 0; k < groups * 8; k++) {
    acc |= static_cast<uint64_t>(k < v.size() ? v[k] : 0) << have;
    have += width;
    while (have >= 8) { o.push_back(static_cast<char>(acc & 0xFF)); acc >>= 8; have -= 8; }
  }
  if (have > 0) o.push_back(static_cast<char>(acc & 0xFF));
}

int bitWidth(uint64_t maxValue) { int w = 0; while (maxValue) { w++; maxValue >>= 1; } return w; }

// ---- DELTA_BINARY_PACKED ------------------------------------------------------------------------

bool deltaBinary(const std::string &b, size_t &p, size_t end, size_t count, std::vector<int64_t> &out) {
  TReader r(b, p);
  uint64_t block = r.varint(), mini = r.varint(), total = r.varint();
  int64_t first = r.zigzag();
  if (r.bad || mini == 0 || block % mini) return false;
  size_t perMini = static_cast<size_t>(block / mini);
  out.clear();
  if (total == 0) { p = r.p; return true; }
  out.push_back(first);
  int64_t last = first;
  while (out.size() < total && r.p < end) {
    int64_t minDelta = r.zigzag();
    std::vector<int> widths(static_cast<size_t>(mini));
    for (auto &w : widths) { if (r.p >= end) return false; w = static_cast<unsigned char>(b[r.p++]); }
    for (size_t m = 0; m < mini; m++) {
      if (out.size() >= total) break;
      int w = widths[m];
      size_t nbytes = (perMini * w + 7) / 8;
      uint64_t acc = 0;
      int have = 0;
      size_t q = r.p;
      for (size_t k = 0; k < perMini; k++) {
        while (have < w && q < r.p + nbytes && q < end) { acc |= static_cast<uint64_t>(static_cast<unsigned char>(b[q++])) << have; have += 8; }
        uint64_t d = w == 64 ? acc : (acc & ((1ull << w) - 1));
        if (w < 64) acc >>= w; else acc = 0;
        have -= w;
        if (out.size() < total) { last = last + minDelta + static_cast<int64_t>(d); out.push_back(last); }
      }
      r.p += nbytes;
    }
  }
  p = r.p;
  (void)count;
  return true;
}

// ---- schema ---------------------------------------------------------------------------------------

struct Leaf {
  std::string path;           // dotted
  std::vector<std::string> parts;
  int ptype = 0, typeLength = 0, maxDef = 0, maxRep = 0;
  int converted = -1, scale = 0, precision = 0;
  const TV *logical = nullptr;
};

void flattenSchema(const std::vector<TV> &els, size_t &i, std::vector<std::string> &prefix, int def, int rep, std::vector<Leaf> &out) {
  const TV &e = els[i++];
  int r = static_cast<int>(e.geti(3, 0)); // 0 required, 1 optional, 2 repeated
  int d = def + (r != 0 ? 1 : 0), rp = rep + (r == 2 ? 1 : 0);
  int children = static_cast<int>(e.geti(5, 0));
  std::string name = e.gets(4);
  if (children > 0) {
    prefix.push_back(name);
    for (int c = 0; c < children && i < els.size(); c++) flattenSchema(els, i, prefix, d, rp, out);
    prefix.pop_back();
    return;
  }
  Leaf l;
  l.parts = prefix;
  l.parts.push_back(name);
  for (size_t k = 0; k < l.parts.size(); k++) l.path += (k ? "." : "") + l.parts[k];
  l.ptype = static_cast<int>(e.geti(1, 6));
  l.typeLength = static_cast<int>(e.geti(2, 0));
  l.maxDef = d;
  l.maxRep = rp;
  l.converted = e.get(6) ? static_cast<int>(e.geti(6)) : -1;
  l.scale = static_cast<int>(e.geti(7, 0));
  l.precision = static_cast<int>(e.geti(8, 0));
  l.logical = e.get(10);
  out.push_back(l);
}

std::string leafType(const Leaf &l) {
  const TV *lt = l.logical;
  if (lt) {
    if (lt->get(1) || lt->get(4) || lt->get(11) || lt->get(12)) return "str"; // STRING ENUM JSON (BSON->str)
    if (lt->get(5)) return "decimal";
    if (lt->get(6)) return "date";
    if (lt->get(7)) return "time";
    if (lt->get(8)) return "timestamp";
    if (lt->get(10)) return "int64";
    if (lt->get(14)) return "uuid";
  }
  switch (l.converted) {
  case 0: case 3: case 4: case 19: return "str";
  case 5: return "decimal";
  case 6: return "date";
  case 7: case 8: return "time";
  case 9: case 10: return "timestamp";
  }
  switch (l.ptype) {
  case 0: return "bool";
  case 1: case 2: return "int64";
  case 3: return "timestamp";
  case 4: case 5: return "float64";
  default: return "str";
  }
}

// timestamp unit: 1 = millis, 2 = micros, 3 = nanos
int timeUnit(const Leaf &l) {
  if (l.logical) {
    const TV *t = l.logical->get(8) ? l.logical->get(8) : l.logical->get(7);
    if (t) { const TV *u = t->get(2); if (u) { if (u->get(1)) return 1; if (u->get(2)) return 2; if (u->get(3)) return 3; } }
  }
  if (l.converted == 9 || l.converted == 7) return 1;
  return 2;
}

int decimalScale(const Leaf &l) {
  if (l.logical && l.logical->get(5)) return static_cast<int>(l.logical->get(5)->geti(1, l.scale));
  return l.scale;
}

// physical value bytes -> NC value
Value plainValue(const Leaf &l, const std::string &type, const char *p, size_t n) {
  std::string s(p, n);
  auto signedBE = [&](const std::string &x) { int64_t v = 0; for (unsigned char c : x) v = (v << 8) | c; if (!x.empty() && (static_cast<unsigned char>(x[0]) & 0x80) && x.size() < 8) v -= (int64_t(1) << (8 * x.size())); return static_cast<double>(v); };
  switch (l.ptype) {
  case 0: return Value::boolean(n && s[0]);
  case 1: {
    int32_t v = static_cast<int32_t>(u32le(s, 0));
    if (type == "date") return Value(isoDate(v));
    if (type == "decimal") return Value(v / std::pow(10.0, decimalScale(l)));
    if (type == "time") return Value(v / 1000.0);
    if (l.converted == 11 || l.converted == 12 || l.converted == 13 || l.converted == 14 || (l.logical && l.logical->get(10) && l.logical->get(10)->geti(2, 1) == 0))
      return Value(static_cast<double>(static_cast<uint32_t>(v)));
    return Value(static_cast<double>(v));
  }
  case 2: {
    int64_t v = static_cast<int64_t>(u64le(s, 0));
    if (type == "timestamp") { int u = timeUnit(l); double div = u == 1 ? 1e3 : u == 2 ? 1e6 : 1e9; return Value(isoTimestamp(static_cast<double>(v) / div, u == 1 ? 3 : 6)); }
    if (type == "decimal") return Value(static_cast<double>(v) / std::pow(10.0, decimalScale(l)));
    if (type == "time") return Value(static_cast<double>(v) / (timeUnit(l) == 3 ? 1e9 : 1e6));
    if (l.logical && l.logical->get(10) && l.logical->get(10)->geti(2, 1) == 0) return Value(static_cast<double>(static_cast<uint64_t>(v)));
    return Value(static_cast<double>(v));
  }
  case 3: { // INT96: nanos of day (8) + julian day (4)
    int64_t nanos = static_cast<int64_t>(u64le(s, 0));
    int64_t jd = static_cast<int32_t>(u32le(s, 8));
    return Value(isoTimestamp(static_cast<double>(jd - 2440588) * 86400.0 + static_cast<double>(nanos) / 1e9, 6));
  }
  case 4: return Value(static_cast<double>(f32le(s, 0)));
  case 5: return Value(f64le(s, 0));
  default:
    if (type == "decimal") return Value(signedBE(s) / std::pow(10.0, decimalScale(l)));
    if (type == "uuid" && s.size() == 16) {
      static const char *hx = "0123456789abcdef";
      std::string u;
      for (size_t k = 0; k < 16; k++) { if (k == 4 || k == 6 || k == 8 || k == 10) u.push_back('-'); u.push_back(hx[static_cast<unsigned char>(s[k]) >> 4]); u.push_back(hx[s[k] & 15]); }
      return Value(u);
    }
    return Value(s);
  }
}

size_t fixedSize(const Leaf &l) {
  switch (l.ptype) { case 1: case 4: return 4; case 2: case 5: return 8; case 3: return 12; case 7: return static_cast<size_t>(l.typeLength); }
  return 0;
}

// PLAIN values -> raw element strings (booleans as one byte)
bool plainDecode(const Leaf &l, const std::string &b, size_t p, size_t end, size_t n, std::vector<std::string> &out) {
  out.clear();
  if (l.ptype == 0) {
    for (size_t k = 0; k < n; k++) { size_t byte = p + k / 8; if (byte >= end) return false; out.push_back(std::string(1, static_cast<char>((b[byte] >> (k % 8)) & 1))); }
    return true;
  }
  if (l.ptype == 6) {
    for (size_t k = 0; k < n; k++) {
      if (p + 4 > end) return false;
      uint32_t len = u32le(b, p);
      p += 4;
      if (p + len > end) return false;
      out.push_back(b.substr(p, len));
      p += len;
    }
    return true;
  }
  size_t sz = fixedSize(l);
  if (!sz || p + n * sz > end) return false;
  for (size_t k = 0; k < n; k++) out.push_back(b.substr(p + k * sz, sz));
  return true;
}

const char *CODECS[] = {"none", "snappy", "gzip", "lzo", "brotli", "lz4", "zstd", "lz4_raw"};

bool readColumnChunk(const std::string &file, const Leaf &l, const std::string &type, const TV &meta, size_t rows,
                     std::vector<Value> &out, std::string &err) {
  int codec = static_cast<int>(meta.geti(4, 0));
  std::string cname = codec >= 0 && codec < 8 ? CODECS[codec] : "codec " + std::to_string(codec);
  if (codec == 3 || codec == 4) { err = "column '" + l.path + "' uses " + cname + " compression, which is not built in"; return false; }
  int64_t start = meta.geti(9, 0);
  if (const TV *dp = meta.get(11)) if (dp->i > 0 && dp->i < start) start = dp->i;
  int64_t total = meta.geti(7, 0);
  if (start < 0 || static_cast<uint64_t>(start) + static_cast<uint64_t>(total) > file.size()) { err = "column '" + l.path + "' points outside the file"; return false; }
  size_t p = static_cast<size_t>(start), end = static_cast<size_t>(start + total);
  int64_t numValues = meta.geti(5, 0);
  std::vector<std::string> dict;
  std::vector<Value> dictVals;
  out.clear();
  out.reserve(rows);
  int64_t seen = 0;
  while (p < end && seen < numValues) {
    TReader r(file, p);
    TV ph;
    if (!r.value(12, ph) || r.bad) { err = "column '" + l.path + "': bad page header"; return false; }
    p = r.p;
    int ptype = static_cast<int>(ph.geti(1));
    size_t usize = static_cast<size_t>(ph.geti(2)), csize = static_cast<size_t>(ph.geti(3));
    if (p + csize > file.size()) { err = "column '" + l.path + "': page runs past the end of the file"; return false; }
    std::string raw = file.substr(p, csize);
    p += csize;
    if (ptype == 2) { // dictionary
      std::string page;
      if (!decompressWith(cname, raw, usize, page, err)) { err = l.path + ": " + err; return false; }
      const TV *dh = ph.get(7);
      size_t n = static_cast<size_t>(dh ? dh->geti(1) : 0);
      if (!plainDecode(l, page, 0, page.size(), n, dict)) { err = "column '" + l.path + "': bad dictionary page"; return false; }
      dictVals.clear();
      for (const auto &s : dict) dictVals.push_back(plainValue(l, type, s.data(), s.size()));
      continue;
    }
    if (ptype != 0 && ptype != 3) continue; // index pages etc.
    std::string page;
    size_t n, defLen = 0, repLen = 0;
    int enc;
    std::vector<uint32_t> defs, reps;
    size_t q;
    if (ptype == 0) {
      const TV *h = ph.get(5);
      if (!h) { err = "column '" + l.path + "': data page without header"; return false; }
      n = static_cast<size_t>(h->geti(1));
      enc = static_cast<int>(h->geti(2));
      if (!decompressWith(cname, raw, usize, page, err)) { err = l.path + ": " + err; return false; }
      q = 0;
      if (l.maxRep > 0) { repLen = u32le(page, q); q += 4 + repLen; }
      if (l.maxDef > 0) {
        if (q + 4 > page.size()) { err = "column '" + l.path + "': bad levels"; return false; }
        defLen = u32le(page, q);
        rleDecode(page, q + 4, q + 4 + defLen, bitWidth(static_cast<uint64_t>(l.maxDef)), n, defs);
        q += 4 + defLen;
      }
    } else {
      const TV *h = ph.get(8);
      if (!h) { err = "column '" + l.path + "': data page v2 without header"; return false; }
      n = static_cast<size_t>(h->geti(1));
      enc = static_cast<int>(h->geti(4));
      defLen = static_cast<size_t>(h->geti(5));
      repLen = static_cast<size_t>(h->geti(6));
      bool compressed = h->geti(7, 1) != 0;
      std::string levels = raw.substr(0, repLen + defLen), body = raw.substr(std::min(raw.size(), repLen + defLen));
      std::string vals;
      if (compressed && codec != 0) { if (!decompressWith(cname, body, usize - repLen - defLen, vals, err)) { err = l.path + ": " + err; return false; } }
      else vals = body;
      if (l.maxDef > 0) rleDecode(levels, repLen, repLen + defLen, bitWidth(static_cast<uint64_t>(l.maxDef)), n, defs);
      page = levels + vals;
      q = repLen + defLen;
    }
    size_t present = 0;
    if (l.maxDef > 0) for (auto d : defs) present += d == static_cast<uint32_t>(l.maxDef);
    else present = n;
    std::vector<Value> vals;
    vals.reserve(present);
    if (enc == 0) { // PLAIN
      std::vector<std::string> el;
      if (!plainDecode(l, page, q, page.size(), present, el)) { err = "column '" + l.path + "': PLAIN values cut short"; return false; }
      for (const auto &s : el) vals.push_back(plainValue(l, type, s.data(), s.size()));
    } else if (enc == 2 || enc == 8) { // dictionary indices
      if (q >= page.size() && present) { err = "column '" + l.path + "': dictionary indices missing"; return false; }
      int w = present ? static_cast<unsigned char>(page[q]) : 0;
      std::vector<uint32_t> idx;
      rleDecode(page, q + 1, page.size(), w, present, idx);
      for (auto i : idx) vals.push_back(i < dictVals.size() ? dictVals[i] : Value(std::nan("")));
    } else if (enc == 3 && l.ptype == 0) { // RLE booleans (4-byte length prefix)
      std::vector<uint32_t> bits;
      size_t len = q + 4 <= page.size() ? u32le(page, q) : 0;
      rleDecode(page, q + 4, std::min(page.size(), q + 4 + len), 1, present, bits);
      for (auto x : bits) vals.push_back(Value::boolean(x != 0));
    } else if (enc == 5) {
      std::vector<int64_t> iv;
      size_t qq = q;
      if (!deltaBinary(page, qq, page.size(), present, iv)) { err = "column '" + l.path + "': bad DELTA_BINARY_PACKED data"; return false; }
      for (auto x : iv) {
        std::string s;
        if (l.ptype == 1) putLE(s, static_cast<uint32_t>(x), 4); else putLE(s, static_cast<uint64_t>(x), 8);
        vals.push_back(plainValue(l, type, s.data(), s.size()));
      }
    } else if (enc == 6 || enc == 7) { // DELTA_LENGTH_BYTE_ARRAY / DELTA_BYTE_ARRAY
      size_t qq = q;
      std::vector<int64_t> prefix, lens;
      if (enc == 7 && !deltaBinary(page, qq, page.size(), present, prefix)) { err = "column '" + l.path + "': bad DELTA_BYTE_ARRAY data"; return false; }
      if (!deltaBinary(page, qq, page.size(), present, lens)) { err = "column '" + l.path + "': bad delta lengths"; return false; }
      std::string prev;
      for (size_t k = 0; k < lens.size(); k++) {
        size_t len = static_cast<size_t>(lens[k]);
        if (qq + len > page.size()) { err = "column '" + l.path + "': delta strings cut short"; return false; }
        std::string s = page.substr(qq, len);
        qq += len;
        if (enc == 7) s = prev.substr(0, static_cast<size_t>(prefix[k])) + s;
        prev = s;
        vals.push_back(plainValue(l, type, s.data(), s.size()));
      }
    } else if (enc == 9) { // BYTE_STREAM_SPLIT
      size_t sz = fixedSize(l);
      if (!sz || q + present * sz > page.size()) { err = "column '" + l.path + "': bad BYTE_STREAM_SPLIT data"; return false; }
      for (size_t k = 0; k < present; k++) {
        std::string s(sz, '\0');
        for (size_t bI = 0; bI < sz; bI++) s[bI] = page[q + bI * present + k];
        vals.push_back(plainValue(l, type, s.data(), s.size()));
      }
    } else { err = "column '" + l.path + "' uses encoding " + std::to_string(enc) + ", which is not built in"; return false; }
    size_t vi = 0;
    for (size_t k = 0; k < n; k++) {
      bool isNull = l.maxDef > 0 && (k >= defs.size() || defs[k] != static_cast<uint32_t>(l.maxDef));
      out.push_back(isNull || vi >= vals.size() ? Value(std::nan("")) : vals[vi++]);
    }
    seen += static_cast<int64_t>(n);
  }
  return true;
}

ColStats statsOf(const Leaf &l, const std::string &type, const TV *st) {
  ColStats s;
  if (!st) return s;
  const TV *mn = st->get(6) ? st->get(6) : st->get(2), *mx = st->get(5) ? st->get(5) : st->get(1);
  if (mn && !mn->s.empty()) { s.hasMin = true; s.min = plainValue(l, type, mn->s.data(), mn->s.size()); }
  if (mx && !mx->s.empty()) { s.hasMax = true; s.max = plainValue(l, type, mx->s.data(), mx->s.size()); }
  if (l.ptype == 6 && !(type == "decimal")) { if (mn) s.min = Value(mn->s); if (mx) s.max = Value(mx->s); }
  if (st->get(3)) s.nulls = static_cast<double>(st->geti(3));
  if (st->get(4)) s.distinct = static_cast<double>(st->geti(4));
  return s;
}

} // namespace

bool readParquet(const std::string &b, const ColReadOptions &o, ColFile &f, std::string &err) {
  if (b.size() < 12 || b.compare(0, 4, "PAR1") != 0 || b.compare(b.size() - 4, 4, "PAR1") != 0) {
    if (b.size() >= 4 && b.compare(b.size() - 4, 4, "PARE") == 0) err = "this parquet file is encrypted - not built in";
    else err = "not a parquet file (no PAR1 magic at both ends)";
    return false;
  }
  uint32_t flen = u32le(b, b.size() - 8);
  if (flen + 12 > b.size()) { err = "parquet footer length is wrong"; return false; }
  TReader r(b, b.size() - 8 - flen);
  TV meta;
  if (!r.value(12, meta) || r.bad) { err = "parquet footer is damaged"; return false; }
  f.format = "parquet";
  f.createdBy = meta.gets(6);
  f.totalRows = static_cast<size_t>(meta.geti(3));
  if (const TV *kv = meta.get(5)) for (const auto &e : kv->list) f.kv.push_back({e.gets(1), e.gets(2)});
  const TV *schema = meta.get(2);
  if (!schema || schema->list.empty()) { err = "parquet schema is missing"; return false; }
  std::vector<Leaf> leaves;
  size_t i = 1;
  std::vector<std::string> prefix;
  int rootChildren = static_cast<int>(schema->list[0].geti(5, 0));
  for (int c = 0; c < rootChildren && i < schema->list.size(); c++) flattenSchema(schema->list, i, prefix, 0, 0, leaves);
  // projection
  std::vector<size_t> use;
  for (size_t k = 0; k < leaves.size(); k++) {
    if (!o.cols.empty()) {
      bool want = false;
      for (const auto &c : o.cols) if (c == leaves[k].path || c == leaves[k].parts.back() || leaves[k].path.rfind(c + ".", 0) == 0) want = true;
      if (!want) continue;
    }
    if (leaves[k].maxRep > 0) { f.skipped.push_back(leaves[k].path + " (list)"); continue; }
    use.push_back(k);
  }
  for (const auto &c : o.cols) {
    bool found = false;
    for (const auto &l : leaves) if (c == l.path || c == l.parts.back() || l.path.rfind(c + ".", 0) == 0) found = true;
    if (!found) {
      std::string j;
      for (const auto &l : leaves) j += (j.empty() ? "" : ", ") + l.path;
      err = "no column '" + c + "' (columns: " + j + ")";
      return false;
    }
  }
  for (size_t k : use) { f.table.cols.push_back(leaves[k].path); f.types.push_back(leafType(leaves[k])); }
  const TV *rgs = meta.get(4);
  size_t ng = rgs ? rgs->list.size() : 0;
  int pdCol = -1;
  if (o.pushdown.active) for (size_t k = 0; k < use.size(); k++) if (leaves[use[k]].path == o.pushdown.col) pdCol = static_cast<int>(k);
  for (size_t g = 0; g < ng; g++) {
    const TV &rg = rgs->list[g];
    ColGroup cg;
    cg.rows = static_cast<size_t>(rg.geti(3));
    cg.bytes = static_cast<uint64_t>(rg.geti(2));
    const TV *cols = rg.get(1);
    std::vector<const TV *> metas(leaves.size(), nullptr);
    if (cols) for (size_t k = 0; k < cols->list.size() && k < leaves.size(); k++) metas[k] = cols->list[k].get(3);
    for (size_t k = 0; k < use.size(); k++) cg.stats.push_back(metas[use[k]] ? statsOf(leaves[use[k]], f.types[k], metas[use[k]]->get(12)) : ColStats());
    f.groups.push_back(cg);
    if (o.metaOnly) continue;
    if (!o.groups.empty() && std::find(o.groups.begin(), o.groups.end(), g) == o.groups.end()) continue;
    if (pdCol >= 0 && !o.pushdown.mayMatch(cg.stats[static_cast<size_t>(pdCol)])) continue;
    std::vector<std::vector<Value>> colVals(use.size());
    for (size_t k = 0; k < use.size(); k++) {
      const TV *m = metas[use[k]];
      if (!m) { colVals[k].assign(cg.rows, Value(std::nan(""))); continue; }
      if (!readColumnChunk(b, leaves[use[k]], f.types[k], *m, cg.rows, colVals[k], err)) return false;
      if (cancelRequested()) { err = "cancelled"; return false; }
    }
    for (size_t rI = 0; rI < cg.rows; rI++) {
      std::vector<Value> row;
      row.reserve(use.size());
      for (size_t k = 0; k < use.size(); k++) row.push_back(rI < colVals[k].size() ? colVals[k][rI] : Value(std::nan("")));
      f.table.rows.push_back(std::move(row));
    }
    reportProgress("read_parquet", "", static_cast<double>(g + 1) / static_cast<double>(ng));
  }
  if (const TV *rgList = meta.get(4)) if (!rgList->list.empty()) {
    const TV *c0 = rgList->list[0].get(1);
    if (c0 && !c0->list.empty() && c0->list[0].get(3)) { int cd = static_cast<int>(c0->list[0].get(3)->geti(4)); f.codec = cd >= 0 && cd < 8 ? CODECS[cd] : "?"; }
  }
  return true;
}

// ---- writer ----------------------------------------------------------------------------------------

namespace {

std::string plainOf(const std::string &kind, const Value &v) {
  std::string s;
  if (kind == "int64") putLE(s, static_cast<uint64_t>(static_cast<int64_t>(v.number)), 8);
  else if (kind == "float64") putF64LE(s, v.number);
  else if (kind == "bool") s.push_back(v.number != 0 ? 1 : 0);
  else s = cellText(v);
  return s;
}

void writeStats(TWriter &w, int id, const std::string &kind, const std::vector<const Value *> &present, size_t nulls) {
  w.begin(id);
  if (!present.empty() && kind != "bool") {
    const Value *mn = present[0], *mx = present[0];
    for (const Value *v : present) {
      if (kind == "str") { if (cellText(*v) < cellText(*mn)) mn = v; if (cellText(*v) > cellText(*mx)) mx = v; }
      else { if (v->number < mn->number) mn = v; if (v->number > mx->number) mx = v; }
    }
    w.i64(3, static_cast<int64_t>(nulls));
    w.bin(5, plainOf(kind, *mx));
    w.bin(6, plainOf(kind, *mn));
  } else w.i64(3, static_cast<int64_t>(nulls));
  w.end();
}

} // namespace

std::string writeParquet(const Table &t, const ColWriteOptions &o, std::string &err) {
  static const std::map<std::string, int> codecId = {{"none", 0}, {"snappy", 1}, {"gzip", 2}, {"lz4", 7}, {"lz4_raw", 7}, {"zstd", 6}};
  auto cit = codecId.find(o.codec);
  if (cit == codecId.end()) { err = "compress must be \"zstd\", \"snappy\", \"gzip\", \"lz4\" or \"none\""; return ""; }
  std::string codecName = o.codec == "lz4" ? "lz4_raw" : o.codec;
  std::vector<std::string> kinds = writeKinds(t);
  size_t nrows = t.rows.size(), ncols = t.cols.size();
  size_t groupRows = o.groupRows;
  if (groupRows == 0) groupRows = std::max<size_t>(1, (128ull << 20) / std::max<size_t>(1, ncols * 8));
  std::string out = "PAR1";
  struct ChunkMeta { int64_t dataOffset, dictOffset, total, uncompressed, numValues; bool dict; std::vector<const Value *> present; size_t nulls; };
  struct GroupMeta { size_t rows; int64_t offset, bytes, compressed; std::vector<ChunkMeta> cols; };
  std::vector<GroupMeta> groups;
  for (size_t from = 0; from < nrows || (nrows == 0 && groups.empty()); from += groupRows) {
    size_t to = std::min(nrows, from + groupRows);
    GroupMeta gm;
    gm.rows = to - from;
    gm.offset = static_cast<int64_t>(out.size());
    gm.bytes = 0;
    gm.compressed = 0;
    for (size_t c = 0; c < ncols; c++) {
      const std::string &k = kinds[c];
      ChunkMeta cm{};
      cm.numValues = static_cast<int64_t>(to - from);
      cm.nulls = 0;
      std::vector<uint32_t> defs;
      for (size_t r = from; r < to; r++) {
        const Value &v = t.rows[r][c];
        bool null = (!v.isText && std::isnan(v.number)) || (k != "str" && v.isText);
        defs.push_back(null ? 0 : 1);
        if (null) cm.nulls++; else cm.present.push_back(&v);
      }
      // dictionary for text columns
      std::vector<std::string> dict;
      std::map<std::string, uint32_t> index;
      bool useDict = false;
      if (o.dictEnc && k == "str" && !cm.present.empty()) {
        for (const Value *v : cm.present) { std::string s = cellText(*v); if (!index.count(s)) { index[s] = static_cast<uint32_t>(dict.size()); dict.push_back(s); } }
        useDict = dict.size() <= 65535 && dict.size() * 2 <= cm.present.size() + 16;
      }
      std::string body;
      std::string levels;
      rleEncodeRuns(levels, defs, 1);
      putLE(body, levels.size(), 4);
      body += levels;
      cm.dict = useDict;
      cm.dictOffset = -1;
      if (useDict) {
        std::string dp;
        for (const auto &s : dict) { putLE(dp, s.size(), 4); dp += s; }
        std::string comp;
        if (!compressWith(codecName, o.level, dp, comp, err)) return "";
        TWriter h;
        h.i32(1, 2);
        h.i32(2, static_cast<int64_t>(dp.size()));
        h.i32(3, static_cast<int64_t>(comp.size()));
        h.begin(7);
        h.i32(1, static_cast<int64_t>(dict.size()));
        h.i32(2, 0); // PLAIN
        h.end();
        h.out.push_back(0);
        cm.dictOffset = static_cast<int64_t>(out.size());
        out += h.out + comp;
        cm.uncompressed += static_cast<int64_t>(h.out.size() + dp.size());
        std::vector<uint32_t> idx;
        for (const Value *v : cm.present) idx.push_back(index[cellText(*v)]);
        int w = std::max(1, bitWidth(dict.size() - 1));
        body.push_back(static_cast<char>(w));
        bitPack(body, idx, w);
      } else if (k == "bool") {
        std::string bits((cm.present.size() + 7) / 8, '\0');
        for (size_t i = 0; i < cm.present.size(); i++) if (cm.present[i]->number != 0) bits[i / 8] |= static_cast<char>(1 << (i % 8));
        body += bits;
      } else {
        for (const Value *v : cm.present) {
          if (k == "str") { std::string s = cellText(*v); putLE(body, s.size(), 4); body += s; }
          else body += plainOf(k, *v);
        }
      }
      std::string comp;
      if (!compressWith(codecName, o.level, body, comp, err)) return "";
      TWriter h;
      h.i32(1, 0); // DATA_PAGE
      h.i32(2, static_cast<int64_t>(body.size()));
      h.i32(3, static_cast<int64_t>(comp.size()));
      h.begin(5);
      h.i32(1, static_cast<int64_t>(to - from));
      h.i32(2, useDict ? 8 : 0);
      h.i32(3, 3); // RLE levels
      h.i32(4, 3);
      h.end();
      h.out.push_back(0);
      cm.dataOffset = static_cast<int64_t>(out.size());
      out += h.out + comp;
      cm.uncompressed += static_cast<int64_t>(h.out.size() + body.size());
      int64_t start = cm.dictOffset >= 0 ? cm.dictOffset : cm.dataOffset;
      cm.total = static_cast<int64_t>(out.size()) - start;
      gm.bytes += cm.uncompressed;
      gm.compressed += cm.total;
      gm.cols.push_back(std::move(cm));
    }
    groups.push_back(std::move(gm));
    if (nrows == 0) break;
  }
  // footer
  TWriter w;
  w.i32(1, 1);
  w.listHead(2, 12, ncols + 1);
  w.beginElem();
  w.bin(4, "schema");
  w.i32(5, static_cast<int64_t>(ncols));
  w.endElem();
  for (size_t c = 0; c < ncols; c++) {
    const std::string &k = kinds[c];
    w.beginElem();
    w.i32(1, k == "int64" ? 2 : k == "float64" ? 5 : k == "bool" ? 0 : 6);
    w.i32(3, 1); // OPTIONAL
    w.bin(4, t.cols[c]);
    if (k == "str") {
      w.i32(6, 0); // UTF8
      w.begin(10); w.begin(1); w.end(); w.end(); // LogicalType STRING
    }
    w.endElem();
  }
  w.i64(3, static_cast<int64_t>(nrows));
  w.listHead(4, 12, groups.size());
  for (size_t g = 0; g < groups.size(); g++) {
    const auto &gm = groups[g];
    w.beginElem();
    w.listHead(1, 12, ncols);
    for (size_t c = 0; c < ncols; c++) {
      const auto &cm = gm.cols[c];
      const std::string &k = kinds[c];
      w.beginElem();
      w.i64(2, cm.dataOffset);
      w.begin(3);
      w.i32(1, k == "int64" ? 2 : k == "float64" ? 5 : k == "bool" ? 0 : 6);
      if (cm.dict) { w.listHead(2, 5, 3); w.zigzag(0); w.zigzag(3); w.zigzag(8); }
      else { w.listHead(2, 5, 2); w.zigzag(0); w.zigzag(3); }
      w.listHead(3, 8, 1); w.varint(t.cols[c].size()); w.out += t.cols[c];
      w.i32(4, cit->second);
      w.i64(5, cm.numValues);
      w.i64(6, cm.uncompressed);
      w.i64(7, cm.total);
      w.i64(9, cm.dataOffset);
      if (cm.dict) w.i64(11, cm.dictOffset);
      writeStats(w, 12, k, cm.present, cm.nulls);
      w.end();
      w.endElem();
    }
    w.i64(2, gm.bytes);
    w.i64(3, static_cast<int64_t>(gm.rows));
    w.i64(5, gm.offset);
    w.i64(6, gm.compressed);
    w.field(7, 4); w.zigzag(static_cast<int64_t>(g));
    w.endElem();
  }
  if (!o.kv.empty()) {
    w.listHead(5, 12, o.kv.size());
    for (const auto &kv : o.kv) { w.beginElem(); w.bin(1, kv.first); w.bin(2, kv.second); w.endElem(); }
  }
  w.bin(6, "NC parquet writer (Functions_Importing_Data)");
  w.listHead(7, 12, ncols);
  for (size_t c = 0; c < ncols; c++) { w.beginElem(); w.begin(1); w.end(); w.endElem(); }
  w.out.push_back(0);
  out += w.out;
  putLE(out, w.out.size(), 4);
  out += "PAR1";
  return out;
}

} // namespace io
} // namespace nc
