// Workbook model helpers - see io_sheet.h.
#include "io_sheet.h"

#include <algorithm>
#include <cmath>
#include <functional>
#include <set>

#include "../numpy_common.h"

namespace nc {
namespace io {

bool Sheet::usedRange(size_t &r0, size_t &c0, size_t &r1, size_t &c1) const {
  if (cells.empty())
    return false;
  r0 = c0 = SIZE_MAX;
  r1 = c1 = 0;
  for (const auto &kv : cells) {
    r0 = std::min(r0, kv.first.first);
    r1 = std::max(r1, kv.first.first);
    c0 = std::min(c0, kv.first.second);
    c1 = std::max(c1, kv.first.second);
  }
  return true;
}

std::string columnName(size_t col) {
  std::string s;
  size_t n = col + 1;
  while (n) {
    s.insert(s.begin(), static_cast<char>('A' + (n - 1) % 26));
    n = (n - 1) / 26;
  }
  return s;
}

std::string addressOf(size_t row, size_t col) { return columnName(col) + std::to_string(row + 1); }

bool parseAddress(const std::string &aIn, size_t &row, size_t &col) {
  std::string a;
  for (char c : aIn)
    if (c != '$')
      a.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(c))));
  size_t i = 0, c = 0;
  while (i < a.size() && a[i] >= 'A' && a[i] <= 'Z')
    c = c * 26 + static_cast<size_t>(a[i++] - 'A' + 1);
  if (i == 0 || i == a.size() || i > 3)
    return false;
  size_t r = 0;
  for (size_t k = i; k < a.size(); k++) {
    if (!std::isdigit(static_cast<unsigned char>(a[k])))
      return false;
    r = r * 10 + static_cast<size_t>(a[k] - '0');
  }
  if (r == 0)
    return false;
  row = r - 1;
  col = c - 1;
  return true;
}

bool parseRange(const std::string &r, size_t &r0, size_t &c0, size_t &r1, size_t &c1) {
  size_t colon = r.find(':');
  if (colon == std::string::npos) {
    if (!parseAddress(r, r0, c0))
      return false;
    r1 = r0;
    c1 = c0;
    return true;
  }
  if (!parseAddress(r.substr(0, colon), r0, c0) || !parseAddress(r.substr(colon + 1), r1, c1))
    return false;
  if (r1 < r0) std::swap(r0, r1);
  if (c1 < c0) std::swap(c0, c1);
  return true;
}

std::string excelDateText(double serial) {
  if (!std::isfinite(serial))
    return "";
  long long days = static_cast<long long>(std::floor(serial));
  double frac = serial - static_cast<double>(days);
  if (days >= 60)
    days -= 1; // Excel's 1900-02-29
  // day 1 = 1900-01-01
  long long z = days - 1 + 693901 - 693901; // days since 1900-01-01
  // civil from days (Howard Hinnant), epoch 1970-01-01 = 25567 days after 1900-01-01
  long long d1970 = z - 25567;
  long long zz = d1970 + 719468;
  long long era = (zz >= 0 ? zz : zz - 146096) / 146097;
  long long doe = zz - era * 146097;
  long long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  long long y = yoe + era * 400;
  long long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
  long long mp = (5 * doy + 2) / 153;
  long long d = doy - (153 * mp + 2) / 5 + 1;
  long long m = mp + (mp < 10 ? 3 : -9);
  y += m <= 2;
  char buf[40];
  long long secs = static_cast<long long>(std::llround(frac * 86400.0));
  if (secs == 0)
    std::snprintf(buf, sizeof buf, "%04lld-%02lld-%02lld", y, m, d);
  else
    std::snprintf(buf, sizeof buf, "%04lld-%02lld-%02lld %02lld:%02lld:%02lld", y, m, d, secs / 3600, secs / 60 % 60,
                  secs % 60);
  return buf;
}

bool isDateFormat(int id, const std::string &code) {
  if ((id >= 14 && id <= 22) || (id >= 45 && id <= 47))
    return true;
  if (code.empty())
    return false;
  bool inQuote = false;
  for (size_t i = 0; i < code.size(); i++) {
    char c = static_cast<char>(std::tolower(static_cast<unsigned char>(code[i])));
    if (code[i] == '"')
      inQuote = !inQuote;
    else if (code[i] == '[') {
      size_t e = code.find(']', i);
      i = e == std::string::npos ? code.size() : e;
    } else if (!inQuote && (c == 'y' || c == 'd' || c == 'h' || c == 's'))
      return true;
  }
  return false;
}

// ---- formula evaluation ---------------------------------------------------

namespace {

struct FVal {
  enum K { Num, Str, Bool, Err, Range } k = Num;
  double n = 0;
  std::string s;
  bool b = false;
  std::vector<FVal> items; // Range
};

struct FParser {
  const std::string &f;
  size_t i = 0;
  Sheet &sheet;
  std::set<std::pair<size_t, size_t>> &busy;
  bool ok = true;
  FParser(const std::string &text, Sheet &s, std::set<std::pair<size_t, size_t>> &b) : f(text), sheet(s), busy(b) {}

  void ws() {
    while (i < f.size() && f[i] == ' ')
      i++;
  }
  FVal err() {
    ok = false;
    FVal v;
    v.k = FVal::Err;
    return v;
  }
  static double num(const FVal &v, bool &ok) {
    if (v.k == FVal::Num) return v.n;
    if (v.k == FVal::Bool) return v.b ? 1 : 0;
    if (v.k == FVal::Str) {
      if (v.s.empty()) return 0;
      char *e = nullptr;
      double d = std::strtod(v.s.c_str(), &e);
      if (*e == '\0') return d;
    }
    ok = false;
    return 0;
  }
  FVal cellValue(size_t r, size_t c);
  FVal primary() {
    ws();
    if (i >= f.size())
      return err();
    char c = f[i];
    if (c == '(') {
      i++;
      FVal v = expr();
      ws();
      if (i < f.size() && f[i] == ')')
        i++;
      return v;
    }
    if (c == '-' || c == '+') {
      i++;
      FVal v = primary();
      double d = num(v, ok);
      FVal r;
      r.n = c == '-' ? -d : d;
      return r;
    }
    if (c == '"') {
      size_t e = f.find('"', i + 1);
      FVal v;
      v.k = FVal::Str;
      v.s = f.substr(i + 1, e - i - 1);
      i = e == std::string::npos ? f.size() : e + 1;
      return v;
    }
    if (std::isdigit(static_cast<unsigned char>(c)) || c == '.') {
      char *e = nullptr;
      FVal v;
      v.n = std::strtod(f.c_str() + i, &e);
      i = static_cast<size_t>(e - f.c_str());
      return v;
    }
    size_t b = i;
    while (i < f.size() && (std::isalnum(static_cast<unsigned char>(f[i])) || f[i] == '$' || f[i] == '_' || f[i] == '.'))
      i++;
    std::string word = f.substr(b, i - b);
    std::string up = word;
    for (char &ch : up)
      ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    ws();
    if (i < f.size() && f[i] == '(') { // function
      i++;
      std::vector<FVal> args;
      ws();
      if (i < f.size() && f[i] == ')') {
        i++;
      } else {
        for (;;) {
          args.push_back(expr());
          ws();
          if (i < f.size() && f[i] == ',') { i++; continue; }
          if (i < f.size() && f[i] == ')') { i++; break; }
          return err();
        }
      }
      return call(up, args);
    }
    if (up == "TRUE" || up == "FALSE") {
      FVal v;
      v.k = FVal::Bool;
      v.b = up == "TRUE";
      return v;
    }
    size_t r0, c0;
    if (!parseAddress(word, r0, c0))
      return err();
    if (i < f.size() && f[i] == ':') {
      i++;
      size_t b2 = i;
      while (i < f.size() && (std::isalnum(static_cast<unsigned char>(f[i])) || f[i] == '$'))
        i++;
      size_t r1, c1;
      if (!parseAddress(f.substr(b2, i - b2), r1, c1))
        return err();
      FVal range;
      range.k = FVal::Range;
      for (size_t r = std::min(r0, r1); r <= std::max(r0, r1); r++)
        for (size_t cc = std::min(c0, c1); cc <= std::max(c0, c1); cc++)
          range.items.push_back(cellValue(r, cc));
      return range;
    }
    return cellValue(r0, c0);
  }
  FVal call(const std::string &fn, const std::vector<FVal> &args) {
    std::vector<double> nums;
    std::vector<FVal> flat;
    for (const auto &a : args) {
      if (a.k == FVal::Range)
        for (const auto &x : a.items) flat.push_back(x);
      else
        flat.push_back(a);
    }
    for (const auto &x : flat)
      if (x.k == FVal::Num || (x.k == FVal::Bool && args.size() == 1 && args[0].k != FVal::Range))
        nums.push_back(x.k == FVal::Num ? x.n : (x.b ? 1 : 0));
    FVal r;
    if (fn == "SUM") { for (double d : nums) r.n += d; return r; }
    if (fn == "PRODUCT") { r.n = 1; for (double d : nums) r.n *= d; return r; }
    if (fn == "COUNT") { r.n = static_cast<double>(nums.size()); return r; }
    if (fn == "AVERAGE") { if (nums.empty()) return err(); for (double d : nums) r.n += d; r.n /= nums.size(); return r; }
    if (fn == "MIN" || fn == "MAX") {
      if (nums.empty()) return r;
      r.n = fn == "MIN" ? *std::min_element(nums.begin(), nums.end()) : *std::max_element(nums.begin(), nums.end());
      return r;
    }
    if (fn == "ABS" && args.size() == 1) { r.n = std::fabs(num(args[0], ok)); return r; }
    if (fn == "SQRT" && args.size() == 1) { r.n = std::sqrt(num(args[0], ok)); return r; }
    if (fn == "ROUND" && !args.empty()) {
      double p = std::pow(10.0, args.size() > 1 ? num(args[1], ok) : 0);
      r.n = std::round(num(args[0], ok) * p) / p;
      return r;
    }
    if (fn == "IF" && args.size() >= 2) {
      bool cond = num(args[0], ok) != 0;
      if (cond) return args[1];
      if (args.size() > 2) return args[2];
      FVal f0; f0.k = FVal::Bool; return f0;
    }
    if (fn == "CONCAT" || fn == "CONCATENATE") {
      FVal s; s.k = FVal::Str;
      for (const auto &x : flat) s.s += text(x);
      return s;
    }
    if (fn == "LEN" && args.size() == 1) { r.n = static_cast<double>(text(args[0]).size()); return r; }
    return err();
  }
  static std::string text(const FVal &v) {
    if (v.k == FVal::Str) return v.s;
    if (v.k == FVal::Bool) return v.b ? "TRUE" : "FALSE";
    return numberText(v.n);
  }
  FVal power() {
    FVal a = primary();
    ws();
    while (i < f.size() && f[i] == '^') {
      i++;
      FVal b = primary();
      FVal r;
      r.n = std::pow(num(a, ok), num(b, ok));
      a = r;
      ws();
    }
    return a;
  }
  FVal term() {
    FVal a = power();
    ws();
    while (i < f.size() && (f[i] == '*' || f[i] == '/')) {
      char op = f[i++];
      FVal b = power();
      FVal r;
      double x = num(a, ok), y = num(b, ok);
      if (op == '/' && y == 0) return err();
      r.n = op == '*' ? x * y : x / y;
      a = r;
      ws();
    }
    return a;
  }
  FVal additive() {
    FVal a = term();
    ws();
    while (i < f.size() && (f[i] == '+' || f[i] == '-')) {
      char op = f[i++];
      FVal b = term();
      FVal r;
      r.n = op == '+' ? num(a, ok) + num(b, ok) : num(a, ok) - num(b, ok);
      a = r;
      ws();
    }
    return a;
  }
  FVal concat() {
    FVal a = additive();
    ws();
    while (i < f.size() && f[i] == '&') {
      i++;
      FVal b = additive();
      FVal r;
      r.k = FVal::Str;
      r.s = text(a) + text(b);
      a = r;
      ws();
    }
    return a;
  }
  FVal expr() {
    FVal a = concat();
    ws();
    static const char *ops[] = {"<=", ">=", "<>", "=", "<", ">"};
    for (const char *op : ops) {
      size_t l = std::char_traits<char>::length(op);
      if (f.compare(i, l, op) == 0) {
        i += l;
        FVal b = concat();
        FVal r;
        r.k = FVal::Bool;
        std::string o = op;
        if (a.k == FVal::Str || b.k == FVal::Str) {
          std::string x = text(a), y = text(b);
          r.b = o == "=" ? x == y : o == "<>" ? x != y : o == "<" ? x < y : o == ">" ? x > y : o == "<=" ? x <= y : x >= y;
        } else {
          double x = num(a, ok), y = num(b, ok);
          r.b = o == "=" ? x == y : o == "<>" ? x != y : o == "<" ? x < y : o == ">" ? x > y : o == "<=" ? x <= y : x >= y;
        }
        return r;
      }
    }
    return a;
  }
};

FVal FParser::cellValue(size_t r, size_t c) {
  auto it = sheet.cells.find({r, c});
  FVal v;
  if (it == sheet.cells.end())
    return v; // empty = 0
  SheetCell &cell = it->second;
  if (!cell.hasValue && !cell.fml.empty()) {
    if (busy.count({r, c}))
      return err(); // circular
    busy.insert({r, c});
    FParser p(cell.fml, sheet, busy);
    FVal res = p.expr();
    busy.erase({r, c});
    if (!p.ok || res.k == FVal::Err || res.k == FVal::Range)
      return err();
    cell.v = res.k == FVal::Str ? Value(res.s) : res.k == FVal::Bool ? Value::boolean(res.b) : Value(res.n);
    cell.hasValue = true;
  }
  if (cell.v.isText) { v.k = FVal::Str; v.s = cell.v.text(); }
  else if (cell.v.isBool()) { v.k = FVal::Bool; v.b = cell.v.number != 0; }
  else v.n = cell.v.number;
  return v;
}

} // namespace

void evaluateFormulas(Sheet &s) {
  std::set<std::pair<size_t, size_t>> busy;
  for (auto &kv : s.cells) {
    if (kv.second.hasValue || kv.second.fml.empty())
      continue;
    FParser p(kv.second.fml, s, busy);
    p.cellValue(kv.first.first, kv.first.second);
  }
}

// ---- sheet <-> table --------------------------------------------------------

bool sheetToTable(const Sheet &sIn, const std::string &range, long long hdr, bool evalFml,
                  const std::vector<std::string> &na, SheetTable &out, std::string &err) {
  out = SheetTable();
  Sheet s = sIn;
  if (evalFml)
    evaluateFormulas(s);
  auto cellValue = [&](const SheetCell &c) -> Value {
    if (!evalFml && !c.fml.empty())
      return Value("=" + c.fml);
    if (!c.hasValue)
      return Value(std::nan(""));
    if (c.v.isText) {
      for (const auto &n : na)
        if (c.v.text() == n)
          return Value(std::nan(""));
    }
    return c.v;
  };
  size_t r0, c0, r1, c1;
  if (!range.empty()) {
    if (!parseRange(range, r0, c0, r1, c1)) {
      err = "range \"" + range + "\" is not like \"A1:G100\"";
      return false;
    }
  } else {
    if (!s.usedRange(r0, c0, r1, c1)) {
      for (const auto &b : s.boxes)
        out.boxes.push_back((b.pos.empty() ? "" : b.pos + ": ") + b.text);
      return true;
    }
    // The largest connected block of filled cells is the table.
    std::set<std::pair<size_t, size_t>> seen;
    size_t bestCount = 0;
    size_t br0 = 0, bc0 = 0, br1 = 0, bc1 = 0;
    for (const auto &kv : s.cells) {
      if (seen.count(kv.first))
        continue;
      std::vector<std::pair<size_t, size_t>> stack{kv.first};
      seen.insert(kv.first);
      size_t count = 0, a0 = SIZE_MAX, b0 = SIZE_MAX, a1 = 0, b1 = 0;
      while (!stack.empty()) {
        auto p = stack.back();
        stack.pop_back();
        count++;
        a0 = std::min(a0, p.first); a1 = std::max(a1, p.first);
        b0 = std::min(b0, p.second); b1 = std::max(b1, p.second);
        for (int dr = -1; dr <= 1; dr++)
          for (int dc = -1; dc <= 1; dc++) {
            if (!dr && !dc) continue;
            if ((dr < 0 && p.first == 0) || (dc < 0 && p.second == 0)) continue;
            std::pair<size_t, size_t> q{p.first + dr, p.second + dc};
            if (s.cells.count(q) && !seen.count(q)) {
              seen.insert(q);
              stack.push_back(q);
            }
          }
      }
      if (count > bestCount) {
        bestCount = count;
        br0 = a0; bc0 = b0; br1 = a1; bc1 = b1;
      }
    }
    r0 = br0; c0 = bc0; r1 = br1; c1 = bc1;
    for (const auto &kv : s.cells) {
      size_t r = kv.first.first, c = kv.first.second;
      if (r < r0 || r > r1 || c < c0 || c > c1) {
        Value v = cellValue(kv.second);
        out.boxes.push_back(addressOf(r, c) + ": " + cellText(v));
      }
    }
  }
  for (const auto &b : s.boxes)
    out.boxes.push_back((b.pos.empty() ? "" : b.pos + ": ") + b.text);
  std::vector<std::vector<Value>> grid;
  for (size_t r = r0; r <= r1; r++) {
    std::vector<Value> row;
    for (size_t c = c0; c <= c1; c++) {
      auto it = s.cells.find({r, c});
      row.push_back(it == s.cells.end() ? Value(std::nan("")) : cellValue(it->second));
    }
    grid.push_back(std::move(row));
  }
  out.originRow = r0;
  out.originCol = c0;
  size_t first = 0;
  auto allText = [&](const std::vector<Value> &row) {
    for (const auto &v : row)
      if (!v.isText || v.text().empty())
        return false;
    return !row.empty();
  };
  if (hdr > 0) {
    if (static_cast<size_t>(hdr) > grid.size()) {
      err = "hdr=" + std::to_string(hdr) + " but the table has only " + std::to_string(grid.size()) + " rows";
      return false;
    }
    for (long long k = 0; k < hdr - 1; k++)
      for (const auto &v : grid[static_cast<size_t>(k)])
        if (v.isText && !v.text().empty())
          out.boxes.push_back(v.text());
    for (const auto &v : grid[static_cast<size_t>(hdr - 1)])
      out.table.cols.push_back(cellText(v));
    first = static_cast<size_t>(hdr);
  } else if (hdr < 0 && grid.size() > 1 && allText(grid[0])) {
    bool numericLater = false;
    for (size_t r = 1; r < grid.size() && !numericLater; r++)
      for (const auto &v : grid[r])
        if (isNumberCell(v) && !std::isnan(v.number)) numericLater = true;
    if (numericLater || grid.size() > 1) {
      for (const auto &v : grid[0])
        out.table.cols.push_back(v.text());
      first = 1;
    }
  }
  out.headerRows = first;
  for (size_t r = first; r < grid.size(); r++)
    out.table.rows.push_back(grid[r]);
  normalizeTable(out.table);
  return true;
}

void tableToSheet(const Table &t, bool header, const std::string &start, Sheet &s) {
  size_t r0 = 0, c0 = 0;
  if (!start.empty())
    parseAddress(start, r0, c0);
  size_t r = r0;
  if (header) {
    for (size_t c = 0; c < t.cols.size(); c++) {
      SheetCell cell;
      cell.v = Value(t.cols[c]);
      cell.bold = true;
      s.cells[{r, c0 + c}] = cell;
    }
    r++;
  }
  for (const auto &row : t.rows) {
    for (size_t c = 0; c < row.size(); c++) {
      const Value &v = row[c];
      if (numpy::isPlainNumber(v) && std::isnan(v.number) && !v.isText)
        continue; // missing -> empty cell
      if (v.isText && v.text().empty())
        continue;
      SheetCell cell;
      cell.v = v;
      if (v.isText && v.text().size() > 1 && v.text()[0] == '=') {
        cell.fml = v.text().substr(1);
        cell.hasValue = false;
      }
      s.cells[{r, c0 + c}] = cell;
    }
    r++;
  }
}

} // namespace io
} // namespace nc
