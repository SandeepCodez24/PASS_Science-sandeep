// .xlsx / .xlsm (Office Open XML SpreadsheetML) reader and writer.
#include <algorithm>
#include <cmath>
#include <iostream>
#include <map>

#include "../numpy_common.h"
#include "io_markup.h"
#include "io_sheet.h"
#include "io_zip.h"

namespace nc {
namespace io {
namespace {

std::string localName(const std::string &n) {
  size_t c = n.find(':');
  return c == std::string::npos ? n : n.substr(c + 1);
}

const XNode *child(const XNode *e, const std::string &name) {
  if (!e)
    return nullptr;
  for (const auto &k : e->kids)
    if (k.kind == XNode::Element && localName(k.name) == name)
      return &k;
  return nullptr;
}

std::vector<const XNode *> children(const XNode *e, const std::string &name) {
  std::vector<const XNode *> out;
  if (e)
    for (const auto &k : e->kids)
      if (k.kind == XNode::Element && localName(k.name) == name)
        out.push_back(&k);
  return out;
}

void descend(const XNode &e, const std::string &name, std::vector<const XNode *> &out) {
  for (const auto &k : e.kids)
    if (k.kind == XNode::Element) {
      if (localName(k.name) == name)
        out.push_back(&k);
      descend(k, name, out);
    }
}

std::string attrOf(const XNode *e, const std::string &name) {
  if (!e)
    return "";
  for (const auto &a : e->attrs)
    if (a.first == name || localName(a.first) == name)
      return a.second;
  return "";
}

std::string textOf(const XNode *e) { return e ? e->innerText() : ""; }

bool xmlPart(const ZipReader &z, const std::string &name, XNode &doc, std::string &err) {
  std::string text;
  if (!z.read(name, text, err))
    return false;
  if (!parseXml(text, doc, err)) {
    err = name + ": " + err;
    return false;
  }
  return true;
}

std::string dirOf(const std::string &part) {
  size_t s = part.rfind('/');
  return s == std::string::npos ? "" : part.substr(0, s + 1);
}

// Relationship target -> part name.
std::string resolve(const std::string &base, const std::string &target) {
  if (!target.empty() && target[0] == '/')
    return target.substr(1);
  std::string dir = dirOf(base), t = target;
  while (t.rfind("../", 0) == 0) {
    t = t.substr(3);
    if (!dir.empty()) {
      dir.pop_back();
      size_t s = dir.rfind('/');
      dir = s == std::string::npos ? "" : dir.substr(0, s + 1);
    }
  }
  return dir + t;
}

std::map<std::string, std::pair<std::string, std::string>> rels(const ZipReader &z, const std::string &part) {
  std::map<std::string, std::pair<std::string, std::string>> out; // id -> (type, target part)
  std::string relsName = dirOf(part) + "_rels/" + part.substr(dirOf(part).size()) + ".rels";
  XNode doc;
  std::string err;
  if (!z.has(relsName) || !xmlPart(z, relsName, doc, err))
    return out;
  const XNode *root = rootElement(doc);
  for (const XNode *r : children(root, "Relationship")) {
    std::string type = attrOf(r, "Type");
    size_t s = type.rfind('/');
    out[attrOf(r, "Id")] = {s == std::string::npos ? type : type.substr(s + 1),
                            attrOf(r, "TargetMode") == "External" ? attrOf(r, "Target")
                                                                   : resolve(part, attrOf(r, "Target"))};
  }
  return out;
}

} // namespace

bool readXlsx(const std::string &bytes, Workbook &wb, std::string &err) {
  wb = Workbook();
  ZipReader z;
  if (!z.open(bytes, err))
    return false;
  std::string wbPart = "xl/workbook.xml";
  for (const auto &kv : rels(z, "")) // package rels: _rels/.rels
    if (kv.second.first == "officeDocument")
      wbPart = kv.second.second;
  {
    // package-level rels live at _rels/.rels
    XNode doc;
    std::string e2;
    if (z.has("_rels/.rels") && xmlPart(z, "_rels/.rels", doc, e2))
      for (const XNode *r : children(rootElement(doc), "Relationship"))
        if (attrOf(r, "Type").size() > 15 && attrOf(r, "Type").compare(attrOf(r, "Type").size() - 15, 15, "/officeDocument") == 0)
          wbPart = resolve("", attrOf(r, "Target"));
  }
  if (!z.has(wbPart)) {
    err = "this zip file is not an Excel workbook (no " + wbPart + ")";
    return false;
  }
  XNode wdoc;
  if (!xmlPart(z, wbPart, wdoc, err))
    return false;
  auto wrels = rels(z, wbPart);
  // shared strings
  std::vector<std::string> sst;
  for (const auto &kv : wrels)
    if (kv.second.first == "sharedStrings") {
      XNode sdoc;
      if (xmlPart(z, kv.second.second, sdoc, err))
        for (const XNode *si : children(rootElement(sdoc), "si")) {
          std::string s;
          std::vector<const XNode *> ts;
          descend(*si, "t", ts);
          for (const XNode *t : ts) {
            // skip phonetic runs
            s += t->innerText();
          }
          if (const XNode *rph = child(si, "rPh"))
            (void)rph;
          sst.push_back(s);
        }
    }
  // styles: xf -> (date?, bold)
  std::vector<std::pair<bool, bool>> xfs;
  for (const auto &kv : wrels)
    if (kv.second.first == "styles") {
      XNode st;
      if (!xmlPart(z, kv.second.second, st, err))
        break;
      const XNode *root = rootElement(st);
      std::map<int, std::string> fmts;
      for (const XNode *f : children(child(root, "numFmts"), "numFmt"))
        fmts[std::atoi(attrOf(f, "numFmtId").c_str())] = attrOf(f, "formatCode");
      std::vector<bool> boldFont;
      for (const XNode *f : children(child(root, "fonts"), "font"))
        boldFont.push_back(child(f, "b") != nullptr);
      for (const XNode *x : children(child(root, "cellXfs"), "xf")) {
        int id = std::atoi(attrOf(x, "numFmtId").c_str());
        size_t font = static_cast<size_t>(std::atoi(attrOf(x, "fontId").c_str()));
        xfs.push_back({isDateFormat(id, fmts.count(id) ? fmts[id] : ""), font < boldFont.size() && boldFont[font]});
      }
    }
  const XNode *wroot = rootElement(wdoc);
  if (const XNode *views = child(wroot, "bookViews"))
    if (const XNode *v = child(views, "workbookView"))
      wb.active = static_cast<size_t>(std::atoi(attrOf(v, "activeTab").c_str()));
  for (const XNode *sh : children(child(wroot, "sheets"), "sheet")) {
    Sheet s;
    s.name = attrOf(sh, "name");
    std::string rid = attrOf(sh, "id");
    auto it = wrels.find(rid);
    if (it == wrels.end()) {
      wb.sheets.push_back(s);
      continue;
    }
    std::string part = it->second.second;
    XNode sdoc;
    if (!xmlPart(z, part, sdoc, err))
      return false;
    const XNode *root = rootElement(sdoc);
    if (localName(root->name) != "worksheet") { // chartsheet etc.
      wb.sheets.push_back(s);
      continue;
    }
    const XNode *data = child(root, "sheetData");
    size_t autoRow = 0;
    for (const XNode *row : children(data, "row")) {
      std::string rr = attrOf(row, "r");
      size_t rowIdx = rr.empty() ? autoRow : static_cast<size_t>(std::atoll(rr.c_str()) - 1);
      autoRow = rowIdx + 1;
      size_t autoCol = 0;
      for (const XNode *c : children(row, "c")) {
        size_t r = rowIdx, col = autoCol;
        std::string ref = attrOf(c, "r");
        if (!ref.empty())
          parseAddress(ref, r, col);
        autoCol = col + 1;
        std::string t = attrOf(c, "t");
        size_t xf = static_cast<size_t>(std::atoi(attrOf(c, "s").c_str()));
        const XNode *v = child(c, "v");
        const XNode *f = child(c, "f");
        SheetCell cell;
        if (f)
          cell.fml = textOf(f);
        std::string vt = textOf(v);
        if (t == "s") {
          size_t k = static_cast<size_t>(std::atoll(vt.c_str()));
          cell.v = Value(k < sst.size() ? sst[k] : std::string());
        } else if (t == "inlineStr") {
          std::vector<const XNode *> ts;
          if (const XNode *is = child(c, "is"))
            descend(*is, "t", ts);
          std::string s2;
          for (auto *x : ts) s2 += x->innerText();
          cell.v = Value(s2);
        } else if (t == "str") {
          cell.v = Value(vt);
          cell.hasValue = v != nullptr;
        } else if (t == "b") {
          cell.v = Value::boolean(vt == "1");
        } else if (t == "e") {
          cell.v = Value(vt);
        } else {
          if (!v) {
            if (!f)
              continue; // styled empty cell
            cell.hasValue = false;
            cell.v = Value(std::nan(""));
          } else {
            double d = std::strtod(vt.c_str(), nullptr);
            if (xf < xfs.size() && xfs[xf].first)
              cell.v = Value(excelDateText(d));
            else
              cell.v = Value(d);
          }
        }
        if (xf < xfs.size())
          cell.bold = xfs[xf].second;
        s.cells[{r, col}] = cell;
      }
    }
    for (const XNode *m : children(child(root, "mergeCells"), "mergeCell"))
      s.merged.push_back(attrOf(m, "ref"));
    if (const XNode *views = child(root, "sheetViews"))
      if (const XNode *view = child(views, "sheetView"))
        if (const XNode *pane = child(view, "pane"))
          if (attrOf(pane, "state") == "frozen")
            s.freeze = attrOf(pane, "topLeftCell");
    for (const XNode *col : children(child(root, "cols"), "col")) {
      size_t a = static_cast<size_t>(std::atoi(attrOf(col, "min").c_str())), b = static_cast<size_t>(std::atoi(attrOf(col, "max").c_str()));
      double w = std::strtod(attrOf(col, "width").c_str(), nullptr);
      for (size_t k = a; k <= b && k <= 16384 && k >= 1; k++) {
        if (s.colWidths.size() < k) s.colWidths.resize(k, 0);
        s.colWidths[k - 1] = w;
      }
    }
    s.pivots = 0;
    for (const auto &kv : rels(z, part)) {
      if (kv.second.first == "comments") {
        XNode cdoc;
        if (xmlPart(z, kv.second.second, cdoc, err))
          for (const XNode *cm : children(child(rootElement(cdoc), "commentList"), "comment"))
            s.boxes.push_back({attrOf(cm, "ref"), trim(textOf(child(cm, "text"))), "comment"});
      } else if (kv.second.first == "drawing") {
        XNode ddoc;
        if (xmlPart(z, kv.second.second, ddoc, err)) {
          std::vector<const XNode *> anchors;
          for (const auto &k : rootElement(ddoc)->kids)
            if (k.kind == XNode::Element)
              anchors.push_back(&k);
          for (const XNode *an : anchors) {
            std::string pos;
            if (const XNode *from = child(an, "from")) {
              size_t col = static_cast<size_t>(std::atoi(textOf(child(from, "col")).c_str()));
              size_t row = static_cast<size_t>(std::atoi(textOf(child(from, "row")).c_str()));
              pos = addressOf(row, col);
            }
            std::vector<const XNode *> charts, txb;
            descend(*an, "chart", charts);
            descend(*an, "txBody", txb);
            if (!charts.empty())
              s.charts++;
            for (const XNode *tb : txb) {
              std::vector<const XNode *> ps;
              descend(*tb, "p", ps);
              std::string text;
              for (const XNode *p : ps) {
                std::string line = trim(p->innerText());
                if (!line.empty())
                  text += (text.empty() ? "" : "\n") + line;
              }
              if (!text.empty())
                s.boxes.push_back({pos, text, "textbox"});
            }
          }
        }
      } else if (kv.second.first == "pivotTable") {
        s.pivots++;
      }
    }
    wb.sheets.push_back(std::move(s));
  }
  // document properties
  XNode core;
  std::string e3;
  if (z.has("docProps/core.xml") && xmlPart(z, "docProps/core.xml", core, e3)) {
    for (const auto &k : rootElement(core)->kids)
      if (k.kind == XNode::Element) {
        std::string n = localName(k.name);
        if (n == "creator") n = "author";
        wb.meta[n] = Value(trim(k.innerText()));
      }
  }
  XNode app;
  if (z.has("docProps/app.xml") && xmlPart(z, "docProps/app.xml", app, e3))
    if (const XNode *a = child(rootElement(app), "Application"))
      wb.meta["application"] = Value(trim(a->innerText()));
  for (const auto &kv : wrels)
    if (kv.second.first == "vbaProject") {
      std::string bin;
      if (z.read(kv.second.second, bin, e3)) {
        wb.vbaProject = bin;
        readVbaModules(bin, wb.vbaModules);
      }
    }
  if (wb.active >= wb.sheets.size())
    wb.active = 0;
  return true;
}

// ---- writer -------------------------------------------------------------------

namespace {

std::string esc(const std::string &s) { return escapeXml(s, true); }

std::string sheetXml(const Sheet &s, std::map<std::string, size_t> &sstIndex, std::vector<std::string> &sst,
                     bool hasComments) {
  std::string x = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                  "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                  "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">";
  size_t r0, c0, r1, c1;
  bool any = s.usedRange(r0, c0, r1, c1);
  x += "<dimension ref=\"" + (any ? addressOf(r0, c0) + ":" + addressOf(r1, c1) : std::string("A1")) + "\"/>";
  x += "<sheetViews><sheetView workbookViewId=\"0\">";
  size_t fr = 0, fc = 0;
  if (!s.freeze.empty() && parseAddress(s.freeze, fr, fc) && (fr || fc)) {
    x += "<pane";
    if (fc) x += " xSplit=\"" + std::to_string(fc) + "\"";
    if (fr) x += " ySplit=\"" + std::to_string(fr) + "\"";
    x += " topLeftCell=\"" + s.freeze + "\" activePane=\"" +
         std::string(fr && fc ? "bottomRight" : fr ? "bottomLeft" : "topRight") + "\" state=\"frozen\"/>";
  }
  x += "</sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/>";
  bool widths = false;
  for (double w : s.colWidths)
    if (w > 0) widths = true;
  if (widths) {
    x += "<cols>";
    for (size_t c = 0; c < s.colWidths.size(); c++)
      if (s.colWidths[c] > 0) {
        char buf[32];
        std::snprintf(buf, sizeof buf, "%.2f", s.colWidths[c]);
        x += "<col min=\"" + std::to_string(c + 1) + "\" max=\"" + std::to_string(c + 1) + "\" width=\"" + buf +
             "\" customWidth=\"1\"/>";
      }
    x += "</cols>";
  }
  x += "<sheetData>";
  long long curRow = -1;
  for (const auto &kv : s.cells) {
    size_t r = kv.first.first, c = kv.first.second;
    if (static_cast<long long>(r) != curRow) {
      if (curRow >= 0) x += "</row>";
      x += "<row r=\"" + std::to_string(r + 1) + "\">";
      curRow = static_cast<long long>(r);
    }
    const SheetCell &cell = kv.second;
    std::string ref = addressOf(r, c);
    std::string style = cell.bold ? " s=\"1\"" : "";
    if (!cell.fml.empty()) {
      std::string f = "<f>" + esc(cell.fml) + "</f>";
      if (!cell.hasValue)
        x += "<c r=\"" + ref + "\"" + style + ">" + f + "</c>";
      else if (cell.v.isText)
        x += "<c r=\"" + ref + "\"" + style + " t=\"str\">" + f + "<v>" + esc(cell.v.text()) + "</v></c>";
      else if (cell.v.isBool())
        x += "<c r=\"" + ref + "\"" + style + " t=\"b\">" + f + "<v>" + (cell.v.number ? "1" : "0") + "</v></c>";
      else
        x += "<c r=\"" + ref + "\"" + style + ">" + f + "<v>" + numberText(cell.v.number) + "</v></c>";
      continue;
    }
    if (cell.v.isText) {
      auto it = sstIndex.find(cell.v.text());
      size_t k;
      if (it == sstIndex.end()) {
        k = sst.size();
        sstIndex[cell.v.text()] = k;
        sst.push_back(cell.v.text());
      } else {
        k = it->second;
      }
      x += "<c r=\"" + ref + "\"" + style + " t=\"s\"><v>" + std::to_string(k) + "</v></c>";
    } else if (cell.v.isBool()) {
      x += "<c r=\"" + ref + "\"" + style + " t=\"b\"><v>" + (cell.v.number ? "1" : "0") + "</v></c>";
    } else if (std::isfinite(cell.v.number)) {
      char buf[40];
      std::snprintf(buf, sizeof buf, "%.17g", cell.v.number);
      std::string shortest = numberText(cell.v.number);
      x += "<c r=\"" + ref + "\"" + style + "><v>" + (std::strtod(shortest.c_str(), nullptr) == cell.v.number ? shortest : buf) +
           "</v></c>";
    } else if (std::isinf(cell.v.number)) {
      x += "<c r=\"" + ref + "\"" + style + " t=\"e\"><v>#NUM!</v></c>";
    }
  }
  if (curRow >= 0)
    x += "</row>";
  x += "</sheetData>";
  if (!s.merged.empty()) {
    x += "<mergeCells count=\"" + std::to_string(s.merged.size()) + "\">";
    for (const auto &m : s.merged)
      x += "<mergeCell ref=\"" + m + "\"/>";
    x += "</mergeCells>";
  }
  x += "<pageMargins left=\"0.7\" right=\"0.7\" top=\"0.75\" bottom=\"0.75\" header=\"0.3\" footer=\"0.3\"/>";
  if (hasComments)
    x += "<legacyDrawing r:id=\"rIdVml\"/>";
  x += "</worksheet>";
  return x;
}

std::string commentsXml(const Sheet &s) {
  std::string x = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                  "<comments xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                  "<authors><author>NC</author></authors><commentList>";
  for (const auto &b : s.boxes)
    x += "<comment ref=\"" + (b.pos.empty() ? std::string("A1") : b.pos) + "\" authorId=\"0\"><text><t xml:space=\"preserve\">" +
         esc(b.text) + "</t></text></comment>";
  return x + "</commentList></comments>";
}

std::string vmlXml(const Sheet &s) {
  std::string x = "<xml xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" "
                  "xmlns:x=\"urn:schemas-microsoft-com:office:excel\">"
                  "<o:shapelayout v:ext=\"edit\"><o:idmap v:ext=\"edit\" data=\"1\"/></o:shapelayout>"
                  "<v:shapetype id=\"_x0000_t202\" coordsize=\"21600,21600\" o:spt=\"202\" path=\"m,l,21600r21600,l21600,xe\">"
                  "<v:stroke joinstyle=\"miter\"/><v:path gradientshapeok=\"t\" o:connecttype=\"rect\"/></v:shapetype>";
  int id = 1025;
  for (const auto &b : s.boxes) {
    size_t r = 0, c = 0;
    parseAddress(b.pos.empty() ? "A1" : b.pos, r, c);
    x += "<v:shape id=\"_x0000_s" + std::to_string(id++) + "\" type=\"#_x0000_t202\" "
         "style=\"position:absolute;margin-left:80pt;margin-top:2pt;width:120pt;height:60pt;z-index:1;visibility:visible\" "
         "fillcolor=\"#ffffe1\" o:insetmode=\"auto\"><v:fill color2=\"#ffffe1\"/><v:shadow on=\"t\" color=\"black\" obscured=\"t\"/>"
         "<v:path o:connecttype=\"none\"/><v:textbox style=\"mso-direction-alt:auto\"><div style=\"text-align:left\"></div></v:textbox>"
         "<x:ClientData ObjectType=\"Note\"><x:MoveWithCells/><x:SizeWithCells/><x:AutoFill>False</x:AutoFill>"
         "<x:Row>" + std::to_string(r) + "</x:Row><x:Column>" + std::to_string(c) + "</x:Column><x:Visible/></x:ClientData></v:shape>";
  }
  return x + "</xml>";
}

} // namespace

std::string writeXlsx(const Workbook &wbIn, bool macroEnabled, int level) {
  Workbook wb = wbIn;
  for (auto &s : wb.sheets)
    evaluateFormulas(s); // cached results so other readers see values
  ZipWriter z;
  std::map<std::string, size_t> sstIndex;
  std::vector<std::string> sst;
  std::vector<std::string> sheetParts;
  std::string ct = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                   "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                   "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                   "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                   "<Default Extension=\"vml\" ContentType=\"application/vnd.openxmlformats-officedocument.vmlDrawing\"/>";
  if (macroEnabled && !wb.vbaProject.empty())
    ct += "<Default Extension=\"bin\" ContentType=\"application/vnd.ms-office.vbaProject\"/>";
  ct += std::string("<Override PartName=\"/xl/workbook.xml\" ContentType=\"") +
        (macroEnabled ? "application/vnd.ms-excel.sheet.macroEnabled.main+xml"
                      : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml") +
        "\"/>";
  std::string wbRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                       "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">";
  std::string sheetsXml;
  for (size_t k = 0; k < wb.sheets.size(); k++) {
    const Sheet &s = wb.sheets[k];
    std::string n = std::to_string(k + 1);
    bool comments = !s.boxes.empty();
    z.add("xl/worksheets/sheet" + n + ".xml", sheetXml(s, sstIndex, sst, comments));
    ct += "<Override PartName=\"/xl/worksheets/sheet" + n +
          ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";
    wbRels += "<Relationship Id=\"rId" + n + "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet" + n + ".xml\"/>";
    sheetsXml += "<sheet name=\"" + esc(s.name) + "\" sheetId=\"" + n + "\" r:id=\"rId" + n + "\"/>";
    if (comments) {
      z.add("xl/comments" + n + ".xml", commentsXml(s));
      z.add("xl/drawings/vmlDrawing" + n + ".vml", vmlXml(s));
      ct += "<Override PartName=\"/xl/comments" + n +
            ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml\"/>";
      z.add("xl/worksheets/_rels/sheet" + n + ".xml.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            "<Relationship Id=\"rIdCm\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments\" Target=\"../comments" + n + ".xml\"/>"
            "<Relationship Id=\"rIdVml\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing\" Target=\"../drawings/vmlDrawing" + n + ".vml\"/>"
            "</Relationships>");
    }
  }
  size_t nextId = wb.sheets.size() + 1;
  wbRels += "<Relationship Id=\"rId" + std::to_string(nextId++) + "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>";
  wbRels += "<Relationship Id=\"rId" + std::to_string(nextId++) + "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" Target=\"sharedStrings.xml\"/>";
  if (macroEnabled && !wb.vbaProject.empty()) {
    wbRels += "<Relationship Id=\"rId" + std::to_string(nextId++) + "\" Type=\"http://schemas.microsoft.com/office/2006/relationships/vbaProject\" Target=\"vbaProject.bin\"/>";
    z.add("xl/vbaProject.bin", wb.vbaProject);
  }
  wbRels += "</Relationships>";
  ct += "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
        "<Override PartName=\"/xl/sharedStrings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml\"/>"
        "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
        "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>"
        "</Types>";
  z.add("[Content_Types].xml", ct);
  z.add("_rels/.rels",
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
        "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>"
        "</Relationships>");
  auto metaText = [&](const char *k, const std::string &def) {
    auto it = wb.meta.find(k);
    return it == wb.meta.end() ? def : cellText(it->second);
  };
  z.add("docProps/core.xml",
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" "
        "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" "
        "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
        "<dc:creator>" + esc(metaText("author", "NC")) + "</dc:creator>"
        "<dc:title>" + esc(metaText("title", "")) + "</dc:title>"
        "<dcterms:created xsi:type=\"dcterms:W3CDTF\">" + esc(metaText("created", "2026-01-01T00:00:00Z")) + "</dcterms:created>"
        "</cp:coreProperties>");
  z.add("docProps/app.xml",
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\"><Application>NC</Application></Properties>");
  z.add("xl/workbook.xml",
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
        "<bookViews><workbookView activeTab=\"" + std::to_string(wb.active) + "\"/></bookViews><sheets>" + sheetsXml +
        "</sheets></workbook>");
  z.add("xl/_rels/workbook.xml.rels", wbRels);
  z.add("xl/styles.xml",
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
        "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
        "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
        "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>"
        "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
        "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>"
        "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
  std::string sx = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
                   "<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"" +
                   std::to_string(sst.size()) + "\" uniqueCount=\"" + std::to_string(sst.size()) + "\">";
  for (const auto &s : sst)
    sx += "<si><t xml:space=\"preserve\">" + esc(s) + "</t></si>";
  z.add("xl/sharedStrings.xml", sx + "</sst>");
  return z.finish(level);
}

} // namespace io
} // namespace nc
