// Section 1 of 11 - Importing Data
// Planned entries: 29  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. Nothing outside this folder needs to change when you add one.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        importing_data/id_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerImportingData() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("importing_data")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "importing_data_main.h"

#include "../numpy_common.h"
#include "io_formats.h"

namespace nc {
namespace numpy {

void registerImportingData(Registry &reg) {
  // read_/load_/save_ per format (Functions_Importing_Data.pdf) - one file
  // per format group, io_<group>.cpp. Shared pieces: io_common.h.
  io::registerDelimited(reg);
  io::registerJson(reg);
  io::registerMarkup(reg);
  io::registerConfig(reg);
  io::registerBinary(reg);
  io::registerSpreadsheets(reg);
  io::registerImages(reg);
  io::registerAudio(reg);
  io::registerMat(reg);
  io::registerFits(reg);
  io::registerDatabases(reg);
  io::registerHdf5(reg);
  io::registerNetcdf(reg);
  io::registerColumnar(reg);
  io::registerVideo(reg);
  io::registerShapefile(reg);
  io::registerGeoTiff(reg);
  io::registerGps(reg);
  io::registerSession(reg);

  // ---- example (copy, rename, then delete this comment block) -------------
  //
  // reg.add({
  //     "example_fill",                     // NC name
  //     Section::ImportingData,
  //     2, 2,                               // min / max argument count
  //     "example_fill(n, value)",           // usage shown in errors
  //     "array of n copies of value",       // one-line summary
  //     "np.full",                          // NumPy original
  //     [](const std::vector<Value> &args, CallContext &ctx) -> Value {
  //       long long n = 0;
  //       double value = 0.0;
  //       if (!argNonNegativeInt(args, 0, ctx, n) || !argNumber(args, 1, ctx, value))
  //         return Value(0.0);
  //       return makeArray(std::vector<double>(static_cast<size_t>(n), value));
  //     },
  // });
}

} // namespace numpy
} // namespace nc
