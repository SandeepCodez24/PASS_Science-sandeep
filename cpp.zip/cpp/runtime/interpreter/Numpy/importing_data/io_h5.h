// HDF5 file format (superblock v0-v3, object headers v1/v2, old-style and
// new-style groups incl. dense links via fractal heaps / v2 B-trees,
// contiguous / compact / chunked layouts, deflate / shuffle / fletcher32 /
// LZF filters), hand-written. Used by read_/load_/save_ h5 hdf he5, by
// NetCDF-4 (.nc) and by MAT-file v7.3.
//
// The writer produces the HDF5 1.6 compatible format (superblock v0, v1
// object headers, symbol-table groups, v1 B-tree chunk indexes), which every
// HDF5 / h5py / netCDF / MATLAB release reads.
#ifndef NC_IO_H5_H
#define NC_IO_H5_H

#include <cstdint>
#include <map>
#include <string>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

constexpr uint64_t H5_UNDEF = ~0ull;

struct H5Type {
  enum Class { Fixed = 0, Float = 1, Time = 2, String = 3, Bitfield = 4, Opaque = 5, Compound = 6, Reference = 7,
               Enum = 8, VarLen = 9, Array = 10 };
  int cls = Float;
  size_t size = 8;
  bool sign = true, bigEndian = false;
  int strPad = 0;                       // String: 0 null-term, 1 null-pad, 2 space-pad
  bool vlenString = false;              // VarLen: a string, not a sequence
  std::vector<std::string> memberNames; // Compound / Enum names
  std::vector<size_t> memberOffsets;    // Compound
  std::vector<H5Type> members;          // Compound members; [0] = base of Enum / VarLen / Array
  std::vector<size_t> arrayDims;        // Array
  std::vector<double> enumValues;
  std::string name() const;             // float64 int32 uint8 str vlen_str compound ref enum ...
};

// Decoded data, row-major (C order) like HDF5 itself.
struct H5Value {
  std::vector<size_t> shape;
  bool isText = false, isRef = false, isCompound = false, isVlen = false;
  std::vector<double> nums;             // numbers / enum values / reference addresses
  std::vector<std::string> strs;        // text
  std::vector<std::string> fieldNames;  // compound
  std::vector<H5Value> fields;
  std::vector<H5Value> items;           // vlen sequences, one per element
  size_t count() const;
};

struct H5Attr {
  std::string name;
  H5Type type;
  H5Value value;
};

struct H5Filter {
  int id = 0;
  bool optional = false;
  std::vector<uint32_t> values;
};

struct H5Object {
  std::string name, path;
  bool group = false;
  uint64_t addr = 0;            // object header address (what references hold)
  std::vector<H5Attr> attrs;
  std::vector<H5Object> kids;   // group members, in name order
  std::string softTarget;       // soft link: target path
  // dataset
  H5Type type;
  bool scalar = false;
  std::vector<uint64_t> dims, maxDims, chunk; // chunk: element counts per dim
  int layout = 1;               // 0 compact, 1 contiguous, 2 chunked
  int chunkIndex = 0;           // 0 v1 B-tree, 1 single chunk, 2 implicit, 3 fixed array, 4 ext. array, 5 v2 B-tree
  uint64_t dataAddr = H5_UNDEF, dataSize = 0, singleFiltered = 0;
  uint32_t singleMask = 0;
  std::string compact, fill;
  std::vector<H5Filter> filters;
  const H5Attr *attr(const std::string &n) const;
  const H5Object *child(const std::string &n) const;
};

class H5Reader {
public:
  // `bytes` must outlive the reader. Finds the superblock at 0, 512, 1024...
  bool open(const std::string &bytes, std::string &err);
  H5Object root;
  uint64_t userblock = 0;
  int superVersion = 0;
  const H5Object *find(const std::string &path) const;  // "/a/b" or "a/b"
  const H5Object *byAddr(uint64_t addr) const;
  // ranges: per dim [lo, hi) (empty = everything)
  bool readData(const H5Object &ds, const std::vector<std::pair<size_t, size_t>> &ranges, H5Value &out,
                std::string &err) const;
  // Every dataset / group path under `o`.
  void walk(const H5Object &o, std::vector<const H5Object *> &out) const;

private:
  const std::string *b_ = nullptr;
  uint64_t base_ = 0;
  int so_ = 8, sl_ = 8;
  std::map<uint64_t, const H5Object *> byAddr_;
  mutable std::map<uint64_t, std::vector<std::pair<uint32_t, std::string>>> gheaps_;
  struct Msg { int type; std::string data; };
  bool messages(uint64_t addr, std::vector<Msg> &out, std::string &err) const;
  bool loadObject(H5Object &o, int depth, std::string &err);
  bool parseType(const std::string &d, size_t &p, H5Type &t, std::string &err) const;
  bool parseSpace(const std::string &d, size_t p, std::vector<uint64_t> &dims, std::vector<uint64_t> &maxDims,
                  bool &scalar) const;
  bool parseAttr(const std::string &d, H5Attr &a, std::string &err) const;
  bool decode(const H5Type &t, const char *p, size_t n, H5Value &out, std::string &err) const;
  bool gheapObject(uint64_t coll, uint32_t index, std::string &out, std::string &err) const;
  bool symbolTable(uint64_t btree, uint64_t heap, H5Object &o, int depth, std::string &err);
  bool denseLinks(uint64_t heap, uint64_t btree, H5Object &o, std::string &err);
  bool denseAttrs(uint64_t heap, uint64_t btree, H5Object &o, std::string &err) const;
  bool parseLink(const std::string &d, size_t p, H5Object &kid) const;
  bool heapObjects(uint64_t heapAddr, uint64_t btreeAddr, bool attrs, std::vector<std::string> &out,
                   std::string &err) const;
  bool chunks(const H5Object &ds, std::vector<std::pair<std::vector<uint64_t>, std::pair<uint64_t, uint64_t>>> &out,
              std::vector<uint32_t> &masks, std::string &err) const;
  uint64_t off(size_t p) const;
  uint64_t len(size_t p) const;
  bool inRange(uint64_t addr, uint64_t n) const;
  void index(const H5Object &o);
};

// Filters (shared with NetCDF-4): undo / apply a pipeline on one chunk.
bool h5Unfilter(const std::vector<H5Filter> &f, uint32_t mask, size_t elemSize, std::string &data, std::string &err);

// ---- writer -------------------------------------------------------------------------------

struct H5WData {
  H5Type type;
  bool scalar = false;
  std::vector<uint64_t> dims, maxDims;  // maxDims empty = dims; H5_UNDEF = unlimited
  std::string raw;                      // little-endian elements, row-major
  std::vector<std::pair<size_t, std::string>> refs; // raw offsets that receive the address of a path
  // VarLen data: one item per element (raw base elements + refs inside them)
  struct Item { std::string raw; size_t count = 0; std::vector<std::pair<size_t, std::string>> refs; };
  std::vector<Item> items;
  size_t count() const;
};

struct H5WAttr {
  std::string name;
  H5WData data;
};

struct H5WNode {
  std::string name;
  bool group = true;
  std::vector<H5WNode> kids;
  std::vector<H5WAttr> attrs;
  H5WData data;
  std::vector<uint64_t> chunk;          // empty = contiguous
  std::string compress = "none";        // none gzip lzf
  int level = 4;
  bool shuffle = false;
  bool allocate = true;                 // false: dataspace only (netCDF dimension without data)
  H5WNode *find(const std::string &n);
};

std::string writeH5(const H5WNode &root, size_t userblock, std::string &err);

H5Type h5Float(size_t size = 8);
H5Type h5Int(size_t size, bool sign);
H5Type h5String(size_t size);
H5Type h5Ref();
H5Type h5VarLen(const H5Type &base);
H5Type h5Compound(const std::vector<std::string> &names, const std::vector<H5Type> &types);
H5WData h5Numbers(const std::vector<size_t> &shape, const std::vector<double> &vals, const H5Type &t = h5Float());
H5WData h5Texts(const std::vector<size_t> &shape, const std::vector<std::string> &vals);
H5WData h5ScalarText(const std::string &s);
H5WData h5ScalarNumber(double d, const H5Type &t = h5Float());
// Chunk dims like h5py's guess: about 64 KiB..1 MiB per chunk.
std::vector<uint64_t> h5AutoChunk(const std::vector<uint64_t> &dims, size_t elemSize);

// LZF (liblzf format, as h5py's filter 32000 stores it)
std::string lzfCompress(const std::string &in);
bool lzfDecompress(const std::string &in, size_t outSize, std::string &out);

// "1:10, :, 5" (1-based, inclusive; NC style) or "0:10, :" (a 0 start reads the
// whole spec 0-based / end-exclusive, the Python style of the PDF examples).
bool h5ParseSlice(const std::string &spec, const std::vector<uint64_t> &dims,
                  std::vector<std::pair<size_t, size_t>> &ranges, std::string &err,
                  std::vector<bool> *single = nullptr); // single: dims given as one index (dropped)
// attributes -> dict (references become the paths they point to)
Value h5AttrsDict(const H5Object &o, const H5Reader *r = nullptr);

// H5Value <-> NC values
Value h5ToValue(const H5Value &v);
// numbers -> float64; text -> fixed strings; cell of text -> strings
bool valueToH5(const Value &v, H5WData &out, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_H5_H
