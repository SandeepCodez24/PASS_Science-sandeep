// CATEGORY 16 - read_/load_/save_ mp4, avi, m4v, mov (see io_video.h).
#include <algorithm>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_audio.h"
#include "io_bytes.h"
#include "io_formats.h"
#include "io_video.h"

namespace nc {
namespace io {
namespace {

struct Subtitle { double start = 0, end = 0; std::string text; };

struct Video {
  std::string container, codec, fourcc;
  size_t width = 0, height = 0;
  double fps = 0, duration = 0;
  std::vector<std::pair<uint64_t, uint64_t>> frames; // offset, size of every video sample
  std::vector<bool> keyframe;
  // decode state
  int nalLength = 0;               // avcC length size; 0 = Annex B
  H264Params h264;
  bool bottomUp = false;
  int bitCount = 24;
  // audio
  bool hasAudio = false;
  Audio audio;
  std::string audioCodec;
  std::vector<std::pair<uint64_t, uint64_t>> audioChunks;
  int audioBits = 16;
  bool audioBigEndian = false, audioFloat = false;
  std::vector<Subtitle> subs;
  std::vector<std::pair<double, std::string>> chapters;
  std::vector<std::pair<std::string, std::string>> meta;
};

std::string fourccName(const std::string &f) {
  static const std::map<std::string, std::string> m = {
      {"avc1", "h264"}, {"avc3", "h264"}, {"H264", "h264"}, {"h264", "h264"}, {"X264", "h264"}, {"x264", "h264"},
      {"hvc1", "hevc"}, {"hev1", "hevc"}, {"HEVC", "hevc"}, {"jpeg", "mjpeg"}, {"mjpa", "mjpeg"}, {"mjpb", "mjpeg"},
      {"MJPG", "mjpeg"}, {"mjpg", "mjpeg"}, {"AVDJ", "mjpeg"}, {"raw ", "raw"}, {"DIB ", "raw"}, {"png ", "png"}, {"MPNG", "png"},
      {"mp4v", "mpeg4"}, {"XVID", "mpeg4"}, {"DIVX", "mpeg4"}, {"FMP4", "mpeg4"}, {"ap4h", "prores"}, {"apch", "prores"},
      {"apcn", "prores"}, {"apcs", "prores"}, {"apco", "prores"}, {"av01", "av1"}, {"vp09", "vp9"}, {"VP90", "vp9"}, {"WMV3", "wmv"}};
  auto it = m.find(f);
  if (it != m.end()) return it->second;
  if (f == std::string(4, '\0')) return "raw";
  return f;
}

// ---- ISO base media (mp4 / m4v / mov) -------------------------------------------------------

struct Box { std::string type; size_t start, body, end; };

bool boxes(const std::string &b, size_t from, size_t to, std::vector<Box> &out) {
  size_t p = from;
  while (p + 8 <= to) {
    uint64_t size = u32be(b, p);
    std::string type = b.substr(p + 4, 4);
    size_t body = p + 8;
    if (size == 1) { if (p + 16 > to) return false; size = u64be(b, p + 8); body = p + 16; }
    else if (size == 0) size = to - p;
    if (size < 8 || p + size > to) { if (type == "mdat") size = to - p; else return !out.empty(); }
    out.push_back({type, p, body, static_cast<size_t>(p + size)});
    p += static_cast<size_t>(size);
  }
  return true;
}

std::vector<Box> children(const std::string &b, const Box &parent, size_t skip = 0) {
  std::vector<Box> v;
  boxes(b, parent.body + skip, parent.end, v);
  return v;
}

const Box *find(const std::vector<Box> &v, const std::string &type) {
  for (const auto &x : v) if (x.type == type) return &x;
  return nullptr;
}

bool parseMp4(const std::string &b, Video &v, std::string &err) {
  std::vector<Box> top;
  boxes(b, 0, b.size(), top);
  const Box *ftyp = find(top, "ftyp"), *moov = find(top, "moov");
  if (!moov) { err = top.empty() || (!ftyp && !find(top, "mdat")) ? "not an MP4 / MOV file (no ftyp / moov boxes)" : "the MP4 has no moov box (index) - the file is incomplete or fragmented"; return false; }
  std::string brand = ftyp ? b.substr(ftyp->body, 4) : "qt  ";
  v.container = brand == "qt  " ? "mov" : brand == "M4V " || brand == "M4VH" || brand == "M4VP" ? "m4v" : "mp4";
  std::vector<Box> mv = children(b, *moov);
  if (const Box *mvhd = find(mv, "mvhd")) {
    int ver = b[mvhd->body];
    uint32_t ts = ver == 1 ? u32be(b, mvhd->body + 20) : u32be(b, mvhd->body + 12);
    uint64_t dur = ver == 1 ? u64be(b, mvhd->body + 24) : u32be(b, mvhd->body + 16);
    if (ts) v.duration = static_cast<double>(dur) / ts;
  }
  if (const Box *udta = find(mv, "udta")) {
    for (const auto &u : children(b, *udta)) {
      if (u.type == "chpl") { // Nero chapters
        size_t p = u.body + 4 + 1 + 4;
        if (p > u.end) continue;
        size_t n = static_cast<unsigned char>(b[u.body + 8]);
        p = u.body + 9;
        for (size_t k = 0; k < n && p + 9 <= u.end; k++) {
          uint64_t t = u64be(b, p);
          size_t len = static_cast<unsigned char>(b[p + 8]);
          v.chapters.push_back({static_cast<double>(t) / 1e7, b.substr(p + 9, std::min(len, u.end - p - 9))});
          p += 9 + len;
        }
      } else if (static_cast<unsigned char>(u.type[0]) == 0xA9 && u.end - u.body > 4) { // QuickTime ©nam ...
        size_t len = u16be(b, u.body);
        v.meta.push_back({u.type.substr(1), b.substr(u.body + 4, std::min<size_t>(len, u.end - u.body - 4))});
      } else if (u.type == "meta") {
        for (const auto &m : children(b, u, 4)) if (m.type == "ilst")
          for (const auto &item : children(b, m)) for (const auto &d : children(b, item)) if (d.type == "data" && d.end > d.body + 8)
            v.meta.push_back({static_cast<unsigned char>(item.type[0]) == 0xA9 ? item.type.substr(1) : item.type, b.substr(d.body + 8, d.end - d.body - 8)});
      }
    }
  }
  bool haveVideo = false;
  for (const auto &trak : mv) {
    if (trak.type != "trak") continue;
    std::vector<Box> tk = children(b, trak);
    const Box *mdia = find(tk, "mdia");
    if (!mdia) continue;
    std::vector<Box> md = children(b, *mdia);
    const Box *mdhd = find(md, "mdhd"), *hdlr = find(md, "hdlr"), *minf = find(md, "minf");
    if (!mdhd || !hdlr || !minf) continue;
    int ver = b[mdhd->body];
    uint32_t ts = ver == 1 ? u32be(b, mdhd->body + 20) : u32be(b, mdhd->body + 12);
    uint64_t mdur = ver == 1 ? u64be(b, mdhd->body + 24) : u32be(b, mdhd->body + 16);
    std::string handler = b.substr(hdlr->body + 8, 4);
    std::vector<Box> mi = children(b, *minf);
    const Box *stbl = find(mi, "stbl");
    if (!stbl) continue;
    std::vector<Box> st = children(b, *stbl);
    const Box *stsd = find(st, "stsd"), *stts = find(st, "stts"), *stsc = find(st, "stsc"), *stsz = find(st, "stsz"),
              *stco = find(st, "stco"), *co64 = find(st, "co64"), *stss = find(st, "stss");
    if (!stsd || !stsc || !stsz || (!stco && !co64)) continue;
    std::vector<Box> entries;
    boxes(b, stsd->body + 8, stsd->end, entries);
    if (entries.empty()) continue;
    const Box &se = entries[0];
    // sample sizes and chunk offsets
    uint32_t constSize = u32be(b, stsz->body + 4), count = u32be(b, stsz->body + 8);
    std::vector<uint64_t> sizes(count, constSize);
    if (!constSize) for (uint32_t i = 0; i < count && stsz->body + 12 + 4 * i + 4 <= stsz->end; i++) sizes[i] = u32be(b, stsz->body + 12 + 4 * i);
    std::vector<uint64_t> chunkOff;
    const Box *co = stco ? stco : co64;
    uint32_t nc = u32be(b, co->body + 4);
    for (uint32_t i = 0; i < nc; i++) chunkOff.push_back(stco ? u32be(b, co->body + 8 + 4 * i) : u64be(b, co->body + 8 + 8 * i));
    uint32_t nsc = u32be(b, stsc->body + 4);
    std::vector<std::pair<std::pair<uint64_t, uint64_t>, uint32_t>> samples; // (offset, size), chunk
    size_t si = 0;
    for (uint32_t e = 0; e < nsc; e++) {
      uint32_t first = u32be(b, stsc->body + 8 + 12 * e), per = u32be(b, stsc->body + 12 + 12 * e);
      uint32_t last = e + 1 < nsc ? u32be(b, stsc->body + 8 + 12 * (e + 1)) : nc + 1;
      for (uint32_t c = first; c < last && c <= nc; c++) {
        uint64_t off = chunkOff[c - 1];
        for (uint32_t k = 0; k < per && si < sizes.size(); k++, si++) { samples.push_back({{off, sizes[si]}, c}); off += sizes[si]; }
      }
    }
    std::vector<double> times;
    if (stts) {
      uint32_t n = u32be(b, stts->body + 4);
      uint64_t t = 0;
      for (uint32_t e = 0; e < n; e++) {
        uint32_t cnt = u32be(b, stts->body + 8 + 8 * e), delta = u32be(b, stts->body + 12 + 8 * e);
        for (uint32_t k = 0; k < cnt; k++) { times.push_back(ts ? static_cast<double>(t) / ts : 0); t += delta; }
      }
    }
    if (handler == "vide" && !haveVideo) {
      haveVideo = true;
      v.fourcc = se.type;
      v.codec = fourccName(se.type);
      v.width = u16be(b, se.body + 24);
      v.height = u16be(b, se.body + 26);
      for (const auto &s : samples) v.frames.push_back(s.first);
      v.keyframe.assign(v.frames.size(), stss == nullptr);
      if (stss) { uint32_t n = u32be(b, stss->body + 4); for (uint32_t i = 0; i < n; i++) { uint32_t k = u32be(b, stss->body + 8 + 4 * i); if (k >= 1 && k <= v.keyframe.size()) v.keyframe[k - 1] = true; } }
      double d = ts ? static_cast<double>(mdur) / ts : v.duration;
      v.fps = d > 0 ? v.frames.size() / d : 0;
      if (v.duration <= 0) v.duration = d;
      for (const auto &x : children(b, se, 78)) if (x.type == "avcC" && x.end > x.body + 8) {
        v.nalLength = (static_cast<unsigned char>(b[x.body + 4]) & 3) + 1;
        size_t p = x.body + 5;
        size_t nsps = static_cast<unsigned char>(b[p++]) & 31;
        for (size_t k = 0; k < nsps && p + 2 <= x.end; k++) { size_t l = u16be(b, p); v.h264.sps = b.substr(p + 2, l); p += 2 + l; }
        size_t npps = p < x.end ? static_cast<unsigned char>(b[p++]) : 0;
        for (size_t k = 0; k < npps && p + 2 <= x.end; k++) { size_t l = u16be(b, p); v.h264.pps = b.substr(p + 2, l); p += 2 + l; }
      }
      v.bitCount = u16be(b, se.body + 74);
    } else if (handler == "soun" && !v.hasAudio) {
      v.hasAudio = true;
      v.audioCodec = se.type;
      int sver = u16be(b, se.body + 8);
      v.audio.channels = u16be(b, se.body + 16);
      v.audioBits = u16be(b, se.body + 18);
      v.audio.fs = u32be(b, se.body + 24) >> 16;
      if (sver == 2) { v.audio.fs = static_cast<size_t>(f64be(b, se.body + 32)); v.audio.channels = u32be(b, se.body + 40); v.audioBits = static_cast<int>(u32be(b, se.body + 48)); }
      v.audioBigEndian = se.type == "twos" || se.type == "in24" || se.type == "in32" || se.type == "fl32" || se.type == "fl64";
      v.audioFloat = se.type == "fl32" || se.type == "fl64";
      if (se.type == "in24") v.audioBits = 24;
      if (se.type == "in32" || se.type == "fl32") v.audioBits = 32;
      if (se.type == "fl64") v.audioBits = 64;
      v.audio.codec = se.type == "mp4a" ? "aac" : se.type == "sowt" || se.type == "twos" || se.type == "lpcm" || se.type == "ipcm" || se.type == "in24" || se.type == "in32" || se.type == "fl32" || se.type == "fl64" || se.type == "raw " ? "pcm" : se.type;
      for (const auto &s : samples) v.audioChunks.push_back(s.first);
      v.audio.frames = static_cast<size_t>(ts ? static_cast<double>(mdur) * v.audio.fs / ts : 0);
    } else if (handler == "text" || handler == "sbtl" || handler == "subt") {
      for (size_t k = 0; k < samples.size(); k++) {
        uint64_t off = samples[k].first.first, sz = samples[k].first.second;
        if (off + sz > b.size() || sz < 2) continue;
        std::string s;
        if (se.type == "tx3g" || se.type == "text") { size_t len = u16be(b, static_cast<size_t>(off)); s = b.substr(static_cast<size_t>(off + 2), std::min<size_t>(len, static_cast<size_t>(sz - 2))); }
        else s = b.substr(static_cast<size_t>(off), static_cast<size_t>(sz));
        double t0 = k < times.size() ? times[k] : 0, t1 = k + 1 < times.size() ? times[k + 1] : (ts ? static_cast<double>(mdur) / ts : t0);
        if (!s.empty()) v.subs.push_back({t0, t1, s});
      }
    }
  }
  if (!haveVideo) { err = "the file has no video track"; return false; }
  return true;
}

// ---- AVI ------------------------------------------------------------------------------------

bool parseAvi(const std::string &b, Video &v, std::string &err) {
  if (b.size() < 12 || b.compare(0, 4, "RIFF") != 0 || b.compare(8, 4, "AVI ") != 0) { err = "not an AVI file (no RIFF AVI header)"; return false; }
  v.container = "avi";
  int videoStream = -1, audioStream = -1, streamNo = -1;
  double usPerFrame = 0;
  uint32_t vscale = 0, vrate = 0;
  size_t moviStart = 0;
  std::vector<std::pair<size_t, size_t>> moviRanges;
  std::function<void(size_t, size_t, int)> walk = [&](size_t from, size_t to, int depth) {
    size_t p = from;
    while (p + 8 <= to && depth < 8) {
      std::string id = b.substr(p, 4);
      uint32_t sz = u32le(b, p + 4);
      size_t body = p + 8, end = std::min<size_t>(body + sz, to);
      if (id == "LIST" || id == "RIFF") {
        std::string kind = b.substr(body, 4);
        if (kind == "movi") { moviStart = body + 4; moviRanges.push_back({body + 4, end}); }
        else if (kind == "strl") { streamNo++; walk(body + 4, end, depth + 1); }
        else if (kind == "INFO") {
          size_t q = body + 4;
          while (q + 8 <= end) {
            std::string k = b.substr(q, 4);
            uint32_t l = u32le(b, q + 4);
            std::string val = b.substr(q + 8, std::min<size_t>(l, end - q - 8));
            while (!val.empty() && val.back() == '\0') val.pop_back();
            v.meta.push_back({k, val});
            q += 8 + l + (l & 1);
          }
        } else walk(body + 4, end, depth + 1);
      } else if (id == "avih" && sz >= 40) {
        usPerFrame = u32le(b, body);
        v.width = u32le(b, body + 32);
        v.height = u32le(b, body + 36);
      } else if (id == "strh" && sz >= 48) {
        std::string type = b.substr(body, 4);
        if (type == "vids" && videoStream < 0) { videoStream = streamNo; vscale = u32le(b, body + 20); vrate = u32le(b, body + 24); v.fourcc = b.substr(body + 4, 4); }
        if (type == "auds" && audioStream < 0) audioStream = streamNo;
        if (type == "txts") v.meta.push_back({"subtitle stream", "(text stream, not read)"});
      } else if (id == "strf") {
        if (streamNo == videoStream && sz >= 40) {
          int32_t h = static_cast<int32_t>(u32le(b, body + 8));
          v.width = u32le(b, body + 4);
          v.height = static_cast<size_t>(std::abs(h));
          v.bottomUp = h > 0;
          v.bitCount = u16le(b, body + 14);
          std::string comp = b.substr(body + 16, 4);
          if (comp != std::string(4, '\0') || v.fourcc.empty()) v.fourcc = comp == std::string(4, '\0') ? "DIB " : comp;
        } else if (streamNo == audioStream && sz >= 16) {
          v.hasAudio = true;
          int tag = u16le(b, body);
          v.audio.channels = u16le(b, body + 2);
          v.audio.fs = u32le(b, body + 4);
          v.audioBits = u16le(b, body + 14);
          v.audioFloat = tag == 3;
          v.audio.codec = tag == 1 || tag == 3 || tag == 0xFFFE ? "pcm" : tag == 0x55 ? "mp3" : tag == 0xFF || tag == 0x1610 ? "aac" : "audio tag " + std::to_string(tag);
          v.audioCodec = v.audio.codec;
        }
      }
      p = body + sz + (sz & 1);
    }
  };
  walk(12, b.size(), 0);
  // further RIFF AVIX parts (OpenDML)
  size_t next = 8 + u32le(b, 4);
  while (next + 12 <= b.size() && b.compare(next, 4, "RIFF") == 0) { uint32_t sz = u32le(b, next + 4); walk(next + 12, std::min<size_t>(next + 8 + sz, b.size()), 0); next += 8 + sz + (sz & 1); }
  if (videoStream < 0) { err = "the AVI has no video stream"; return false; }
  v.codec = fourccName(v.fourcc);
  v.fps = vscale ? static_cast<double>(vrate) / vscale : (usPerFrame ? 1e6 / usPerFrame : 0);
  char vid[3], aud[3];
  std::snprintf(vid, sizeof vid, "%02d", videoStream);
  std::snprintf(aud, sizeof aud, "%02d", audioStream >= 0 ? audioStream : 99);
  for (const auto &r : moviRanges) { // scan the movi lists (works without idx1)
    std::function<void(size_t, size_t)> scan = [&](size_t from, size_t to) {
      size_t p = from;
      while (p + 8 <= to) {
        std::string id = b.substr(p, 4);
        uint32_t sz = u32le(b, p + 4);
        if (id == "LIST") { scan(p + 12, std::min<size_t>(p + 8 + sz, to)); }
        else if (id.compare(0, 2, vid) == 0 && (id[2] == 'd')) { v.frames.push_back({p + 8, sz}); v.keyframe.push_back(true); }
        else if (id.compare(0, 2, aud) == 0 && id.compare(2, 2, "wb") == 0) v.audioChunks.push_back({p + 8, sz});
        p += 8 + sz + (sz & 1);
      }
    };
    scan(r.first, r.second);
  }
  (void)moviStart;
  v.duration = v.fps > 0 ? v.frames.size() / v.fps : 0;
  if (v.hasAudio && v.audio.codec == "pcm") {
    uint64_t total = 0;
    for (auto &c : v.audioChunks) total += c.second;
    v.audio.frames = static_cast<size_t>(total / std::max<size_t>(1, v.audio.channels * static_cast<size_t>(v.audioBits / 8)));
  }
  return true;
}

// ---- frames ----------------------------------------------------------------------------------

std::string defaultHuffman() { // JPEG Annex K tables, for MJPEG frames that leave them out
  static const unsigned char t[] = {
      0xFF, 0xC4, 0x01, 0xA2, 0x00, 0x00, 0x01, 0x05, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x01, 0x00, 0x03, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
      0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x10, 0x00, 0x02, 0x01,
      0x03, 0x03, 0x02, 0x04, 0x03, 0x05, 0x05, 0x04, 0x04, 0x00, 0x00, 0x01, 0x7D, 0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21,
      0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xA1, 0x08, 0x23, 0x42, 0xB1, 0xC1, 0x15, 0x52, 0xD1,
      0xF0, 0x24, 0x33, 0x62, 0x72, 0x82, 0x09, 0x0A, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x34, 0x35, 0x36,
      0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x63, 0x64,
      0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8A,
      0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA, 0xB2, 0xB3, 0xB4, 0xB5,
      0xB6, 0xB7, 0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7, 0xD8, 0xD9,
      0xDA, 0xE1, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0x11,
      0x00, 0x02, 0x01, 0x02, 0x04, 0x04, 0x03, 0x04, 0x07, 0x05, 0x04, 0x04, 0x00, 0x01, 0x02, 0x77, 0x00, 0x01, 0x02, 0x03, 0x11, 0x04,
      0x05, 0x21, 0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71, 0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91, 0xA1, 0xB1, 0xC1, 0x09,
      0x23, 0x33, 0x52, 0xF0, 0x15, 0x62, 0x72, 0xD1, 0x0A, 0x16, 0x24, 0x34, 0xE1, 0x25, 0xF1, 0x17, 0x18, 0x19, 0x1A, 0x26, 0x27, 0x28,
      0x29, 0x2A, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
      0x59, 0x5A, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x82, 0x83, 0x84, 0x85,
      0x86, 0x87, 0x88, 0x89, 0x8A, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9A, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9,
      0xAA, 0xB2, 0xB3, 0xB4, 0xB5, 0xB6, 0xB7, 0xB8, 0xB9, 0xBA, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9, 0xCA, 0xD2, 0xD3, 0xD4,
      0xD5, 0xD6, 0xD7, 0xD8, 0xD9, 0xDA, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7, 0xE8, 0xE9, 0xEA, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8,
      0xF9, 0xFA};
  return std::string(reinterpret_cast<const char *>(t), sizeof t);
}

bool decodeFrame(const std::string &b, Video &v, size_t i, Image &img, std::string &err) {
  if (i >= v.frames.size()) { err = "frame " + std::to_string(i) + " does not exist (the video has " + std::to_string(v.frames.size()) + ")"; return false; }
  uint64_t off = v.frames[i].first, sz = v.frames[i].second;
  if (off + sz > b.size()) { err = "frame " + std::to_string(i) + " is outside the file (truncated?)"; return false; }
  std::string data = b.substr(static_cast<size_t>(off), static_cast<size_t>(sz));
  if (v.codec == "mjpeg") {
    if (data.find("\xFF\xC4") == std::string::npos) { // AVI1 MJPEG: no Huffman tables
      size_t sos = data.find("\xFF\xDA");
      if (sos != std::string::npos) data.insert(sos, defaultHuffman());
    }
    return decodeJpeg(data, img, err);
  }
  if (v.codec == "png") return decodePng(data, img, err);
  if (v.codec == "raw") {
    size_t w = v.width, h = v.height, bpp = static_cast<size_t>(std::max(8, v.bitCount) / 8);
    size_t stride = v.container == "avi" ? (w * bpp + 3) & ~static_cast<size_t>(3) : w * bpp;
    if (bpp < 3 || stride * h > data.size()) { err = "uncompressed frames with " + std::to_string(v.bitCount) + " bits per pixel are not built in"; return false; }
    img = Image();
    img.width = w;
    img.height = h;
    img.channels = 3;
    img.px.resize(w * h * 3);
    bool bgr = v.container == "avi";
    for (size_t y = 0; y < h; y++) {
      size_t sy = v.bottomUp ? h - 1 - y : y;
      for (size_t x = 0; x < w; x++) {
        const unsigned char *p = reinterpret_cast<const unsigned char *>(data.data()) + sy * stride + x * bpp;
        if (!bgr && bpp == 4) p++; // QuickTime 32-bit: ARGB
        img.px[(y * w + x) * 3 + 0] = bgr ? p[2] : p[0];
        img.px[(y * w + x) * 3 + 1] = p[1];
        img.px[(y * w + x) * 3 + 2] = bgr ? p[0] : p[2];
      }
    }
    return true;
  }
  if (v.codec == "h264") {
    std::vector<std::string> nals = v.nalLength ? h264SplitLengths(data, v.nalLength) : h264SplitAnnexB(data);
    return h264DecodePcm(nals, v.h264, img, err);
  }
  err = "decoding " + v.codec + " video (" + v.fourcc + ") is not built in - NC decodes MJPEG, uncompressed, PNG and its own H.264 (I_PCM) frames; the container data (fps, size, duration, audio, subtitles) is in load_" + v.container + "(...)";
  return false;
}

bool readAudio(const std::string &b, Video &v, std::string &err) {
  if (!v.hasAudio) { err = "the video has no audio track"; return false; }
  if (v.audio.codec != "pcm") { err = "decoding " + v.audio.codec + " audio is not built in (PCM audio is)"; return false; }
  int bytes = std::max(1, v.audioBits / 8);
  v.audio.samples.clear();
  for (const auto &c : v.audioChunks) {
    if (c.first + c.second > b.size()) break;
    for (uint64_t p = c.first; p + bytes <= c.first + c.second; p += bytes) {
      std::string s = b.substr(static_cast<size_t>(p), static_cast<size_t>(bytes));
      if (v.audioBigEndian) std::reverse(s.begin(), s.end());
      double x;
      if (v.audioFloat) x = bytes == 4 ? f32le(s, 0) : f64le(s, 0);
      else if (bytes == 1) x = (static_cast<unsigned char>(s[0]) - 128) / 128.0;
      else { int64_t iv = static_cast<int64_t>(getLE(s, 0, bytes)); if (iv >> (8 * bytes - 1)) iv -= int64_t(1) << (8 * bytes); x = static_cast<double>(iv) / static_cast<double>(int64_t(1) << (8 * bytes - 1)); }
      v.audio.samples.push_back(x);
    }
  }
  v.audio.frames = v.audio.samples.size() / std::max<size_t>(1, v.audio.channels);
  v.audio.bits = v.audioBits;
  return true;
}

// sidecar subtitles: movie.srt / movie.vtt next to the file
void readSidecar(const std::string &file, Video &v) {
  if (isUrl(file)) return;
  std::filesystem::path p(file);
  for (const char *ext : {".srt", ".vtt"}) {
    std::filesystem::path s = p;
    s.replace_extension(ext);
    std::string text, err;
    if (!fileExists(s.string()) || !readFile(s.string(), text, err)) continue;
    auto stamp = [](const std::string &t) { // "hh:mm:ss,mmm" or "mm:ss.mmm"
      std::vector<double> parts{0};
      double frac = 0, scale = 0.1;
      bool inFrac = false;
      for (char c : t) {
        if (c >= '0' && c <= '9') { if (inFrac) { frac += (c - '0') * scale; scale /= 10; } else parts.back() = parts.back() * 10 + (c - '0'); }
        else if (c == ':') parts.push_back(0);
        else if (c == ',' || c == '.') inFrac = true;
      }
      double s = 0;
      for (double p : parts) s = s * 60 + p;
      return s + frac;
    };
    size_t pos = 0;
    while (pos < text.size()) {
      size_t arrow = text.find("-->", pos);
      if (arrow == std::string::npos) break;
      size_t ls = text.rfind('\n', arrow);
      ls = ls == std::string::npos ? 0 : ls + 1;
      size_t le = text.find('\n', arrow);
      if (le == std::string::npos) le = text.size();
      Subtitle sub;
      sub.start = stamp(trim(text.substr(ls, arrow - ls)));
      sub.end = stamp(trim(text.substr(arrow + 3, le - arrow - 3)));
      size_t blank = text.find("\n\n", le);
      size_t blank2 = text.find("\r\n\r\n", le);
      size_t endText = std::min(blank == std::string::npos ? text.size() : blank, blank2 == std::string::npos ? text.size() : blank2);
      sub.text = trim(text.substr(le + 1, endText > le ? endText - le - 1 : 0));
      v.subs.push_back(sub);
      pos = endText;
    }
  }
}

bool openVideo(const std::string &fmt, const std::string &file, std::string &bytes, Video &v, std::string &err) {
  if (!readSource(file, bytes, err)) return false;
  bool riff = bytes.size() >= 12 && bytes.compare(0, 4, "RIFF") == 0;
  if (riff ? !parseAvi(bytes, v, err) : !parseMp4(bytes, v, err)) return false;
  (void)fmt;
  readSidecar(file, v);
  return true;
}

// ---- NC values -------------------------------------------------------------------------------

Value subsValue(const Video &v) {
  std::vector<Value> out;
  for (const auto &s : v.subs) out.push_back(makeObject("NcBox", {{"start", Value(s.start)}, {"end", Value(s.end)}, {"text", Value(s.text)}}));
  return Value(std::move(out));
}

std::vector<std::string> boxesOf(const Video &v) {
  std::vector<std::string> out;
  for (const auto &m : v.meta) out.push_back(m.first + ": " + m.second);
  for (const auto &c : v.chapters) out.push_back("chapter " + numberText(c.first) + " s: " + c.second);
  for (const auto &s : v.subs) out.push_back(numberText(s.start) + "-" + numberText(s.end) + " s: " + s.text);
  return out;
}

// frames=, time=, stride= -> frame indices (0-based)
bool pickFrames(const Video &v, const Value &frames, const Value &time, long long stride, std::vector<size_t> &out, std::string &err) {
  out.clear();
  size_t n = v.frames.size();
  if (stride < 1) { err = "stride must be 1 or more"; return false; }
  if (given(frames)) {
    for (double d : optNumbers(frames)) {
      if (d < 0 || d != std::floor(d) || d >= static_cast<double>(n)) { err = "frame " + numberText(d) + " is outside 0.." + std::to_string(n ? n - 1 : 0) + " (frames are numbered from 0)"; return false; }
      out.push_back(static_cast<size_t>(d));
    }
  } else if (given(time)) {
    std::vector<double> t = optNumbers(time);
    double t0 = t.empty() ? 0 : t[0], t1 = t.size() > 1 ? t[1] : v.duration;
    if (v.fps <= 0) { err = "the video has no frame rate"; return false; }
    for (size_t k = 0; k < n; k++) { double tk = k / v.fps; if (tk + 1e-9 >= t0 && tk < t1 - 1e-9) out.push_back(k); }
    if (out.empty()) { err = "no frames between " + numberText(t0) + " and " + numberText(t1) + " s (the video is " + numberText(v.duration) + " s)"; return false; }
  } else for (size_t k = 0; k < n; k++) out.push_back(k);
  if (stride > 1) { std::vector<size_t> s; for (size_t k = 0; k < out.size(); k += static_cast<size_t>(stride)) s.push_back(out[k]); out = s; }
  return true;
}

bool framesValue(const std::string &b, Video &v, const std::vector<size_t> &idx, const Value &roi, const Value &scale, bool gray, Value &out, std::string &err) {
  std::vector<double> vals;
  size_t H = 0, W = 0, C = 0;
  const double LIMIT = 1.5e8;
  for (size_t k = 0; k < idx.size(); k++) {
    Image img;
    if (!decodeFrame(b, v, idx[k], img, err)) return false;
    img = to8bit(img);
    if (given(roi)) {
      std::vector<double> r = optNumbers(roi);
      if (r.size() != 4 || r[0] < 0 || r[1] < 0 || r[2] < 1 || r[3] < 1 || r[0] + r[2] > img.width || r[1] + r[3] > img.height) { err = "roi must be [x, y, w, h] inside the " + std::to_string(img.width) + " x " + std::to_string(img.height) + " frame"; return false; }
      img = cropImage(img, static_cast<size_t>(r[0]), static_cast<size_t>(r[1]), static_cast<size_t>(r[2]), static_cast<size_t>(r[3]));
    }
    if (given(scale)) {
      std::vector<double> s = optNumbers(scale);
      if (s.size() != 2 || s[0] < 1 || s[1] < 1) { err = "scale must be [W, H] in pixels"; return false; }
      img = resizeImage(img, static_cast<size_t>(s[0]), static_cast<size_t>(s[1]));
    }
    img = convertChannels(img, gray ? "gray" : "rgb");
    if (k == 0) {
      H = img.height; W = img.width; C = img.channels;
      if (static_cast<double>(idx.size()) * H * W * C > LIMIT) {
        err = "decoding " + std::to_string(idx.size()) + " frames of " + std::to_string(W) + " x " + std::to_string(H) + " needs more than 150 million values - pick fewer with frames= / time= / stride=, or shrink them with scale= / roi=";
        return false;
      }
      vals.reserve(idx.size() * H * W * C);
    }
    vals.insert(vals.end(), img.px.begin(), img.px.end());
    if (reportProgress("read_video", "", static_cast<double>(k + 1) / static_cast<double>(idx.size())) || cancelRequested()) { err = "cancelled"; return false; }
  }
  std::vector<size_t> shape = {idx.size(), H, W};
  if (C > 1) shape.push_back(C);
  out = ndFromRowMajor(shape, vals);
  return true;
}

Value infoFields(const Video &v, const std::string &file, Fields f) {
  f["fps"] = Value(v.fps);
  f["count"] = Value(static_cast<double>(v.frames.size()));
  f["width"] = Value(static_cast<double>(v.width));
  f["height"] = Value(static_cast<double>(v.height));
  f["duration"] = Value(v.duration);
  f["codec"] = Value(v.codec);
  f["fourcc"] = Value(v.fourcc);
  f["format"] = Value(v.container);
  f["subtitles"] = subsValue(v);
  std::vector<Value> ch;
  for (const auto &c : v.chapters) ch.push_back(makeObject("NcBox", {{"start", Value(c.first)}, {"text", Value(c.second)}}));
  f["chapters"] = Value(std::move(ch));
  f["boxes"] = textList(boxesOf(v));
  f["file"] = Value(file);
  f["has_audio"] = Value::boolean(v.hasAudio);
  f["audio_codec"] = Value(v.hasAudio ? v.audio.codec : std::string());
  return Value(f);
}

// read_<fmt>(file, frames, time, stride, roi, scale, gray, audio, box)
void readVideo(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  Video v;
  if (!openVideo(fmt, file, bytes, v, err)) return ctx.fail(err);
  std::vector<size_t> idx;
  if (!pickFrames(v, a[1], a[2], optInt(a[3], 1), idx, err)) return ctx.fail(err);
  Value frames;
  if (!framesValue(bytes, v, idx, a[4], a[5], optBool(a[6], false), frames, err)) return ctx.fail(err);
  out.push_back(frames);
  if (nout > 1) {
    Fields f;
    std::vector<double> ix(idx.begin(), idx.end());
    f["frame_index"] = numberList(ix);
    std::vector<double> t;
    for (size_t i : idx) t.push_back(v.fps > 0 ? i / v.fps : 0);
    f["time"] = numberList(t);
    if (optBool(a[7], false)) {
      if (!readAudio(bytes, v, err)) return ctx.fail(err);
      f["audio"] = audioObject(v.audio, file, "pcm");
    }
    Value info = infoFields(v, file, f);
    if (!optBool(a[8], true)) { Fields g(info.dict().begin(), info.dict().end()); g["boxes"] = textList({}); info = Value(g); }
    out.push_back(makeObject("NcReadInfo", Fields(info.dict().begin(), info.dict().end())));
  }
  ev.ok = true;
}

Value loadVideo(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err, bytes;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  Video v;
  if (!openVideo(fmt, file, bytes, v, err)) { ctx.fail(err); return Value(0.0); }
  Fields f;
  if (v.hasAudio) {
    if (readAudio(bytes, v, err)) f["audio"] = audioObject(v.audio, file, "pcm");
    else { Audio meta = v.audio; meta.samples.clear(); f["audio"] = audioObject(meta, file, v.audio.codec); }
    err.clear();
  } else f["audio"] = Value(std::nan(""));
  // small videos are decoded now; larger ones frame by frame with D.frame(i) / D.at_time(t) / D.read(...)
  double values = static_cast<double>(v.frames.size()) * v.width * v.height * 3;
  bool decodable = v.codec == "mjpeg" || v.codec == "raw" || v.codec == "png" || v.codec == "h264";
  if (v.codec == "h264" && !v.frames.empty()) { Image probe; std::string e2; decodable = decodeFrame(bytes, v, 0, probe, e2); } // only I_PCM streams decode
  f["loaded"] = Value::boolean(false);
  if (decodable && values <= 2.5e7 && !v.frames.empty()) {
    std::vector<size_t> all;
    for (size_t k = 0; k < v.frames.size(); k++) all.push_back(k);
    Value fr;
    if (framesValue(bytes, v, all, Value(std::string()), Value(std::string()), false, fr, err)) { f["frames"] = fr; f["loaded"] = Value::boolean(true); }
    err.clear();
  }
  f["decodable"] = Value::boolean(decodable);
  Value info = infoFields(v, file, f);
  ev.ok = true;
  return makeObject("NcVideo", Fields(info.dict().begin(), info.dict().end()));
}

Value frameMethod(const std::vector<Value> &a, CallContext &ctx, bool byTime) {
  const Value *file = field(a[0], "file");
  if (!file) { ctx.fail("this object has no file to read from"); return Value(0.0); }
  std::string bytes, err;
  Video v;
  if (!openVideo("", file->text(), bytes, v, err)) { ctx.fail(err); return Value(0.0); }
  double x = optNumber(a[1], 0);
  size_t i = byTime ? static_cast<size_t>(std::max(0.0, std::floor(x * v.fps + 1e-6))) : static_cast<size_t>(std::max(0.0, x));
  if (byTime && i >= v.frames.size()) { ctx.fail("time " + numberText(x) + " s is past the end (" + numberText(v.duration) + " s)"); return Value(0.0); }
  Value out;
  if (!framesValue(bytes, v, {i}, Value(std::string()), Value(std::string()), false, out, err)) { ctx.fail(err); return Value(0.0); }
  // (1, H, W, C) -> (H, W, C)
  std::vector<size_t> shape;
  std::vector<double> vals;
  ndToRowMajor(out, shape, vals);
  shape.erase(shape.begin());
  return ndFromRowMajor(shape, vals);
}

Value readMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *file = field(a[0], "file");
  if (!file) { ctx.fail("this object has no file to read from"); return Value(0.0); }
  std::string bytes, err;
  Video v;
  if (!openVideo("", file->text(), bytes, v, err)) { ctx.fail(err); return Value(0.0); }
  std::vector<size_t> idx;
  if (!pickFrames(v, a[1], a[2], optInt(a[3], 1), idx, err)) { ctx.fail(err); return Value(0.0); }
  Value out;
  if (!framesValue(bytes, v, idx, a[4], a[5], optBool(a[6], false), out, err)) { ctx.fail(err); return Value(0.0); }
  return out;
}

// ---- writing ---------------------------------------------------------------------------------

struct Box2 { // big-endian box builder
  std::string s;
  size_t open(const char *type) { size_t at = s.size(); putBE(s, 0, 4); s += type; return at; }
  void close(size_t at) { setBE(s, at, s.size() - at, 4); }
  void u8(uint64_t v) { s.push_back(static_cast<char>(v)); }
  void u16(uint64_t v) { putBE(s, v, 2); }
  void u32(uint64_t v) { putBE(s, v, 4); }
  void u64(uint64_t v) { putBE(s, v, 8); }
  void zeros(size_t n) { s.append(n, '\0'); }
  void str(const std::string &x) { s += x; }
};

void matrix(Box2 &b) { // unity transform
  for (uint32_t v : {0x00010000u, 0u, 0u, 0u, 0x00010000u, 0u, 0u, 0u, 0x40000000u}) b.u32(v);
}

struct Track { std::string kind; std::vector<uint64_t> offsets, sizes; uint32_t timescale = 0, delta = 0; uint64_t duration = 0; std::string entry; std::vector<uint32_t> deltas; };

std::string writeMp4(const std::string &container, const std::vector<std::string> &frames, double fps, const std::string &codec,
                     size_t w, size_t h, const H264Params &ps, const Audio *audio, const std::vector<Subtitle> &subs, double duration) {
  Box2 f;
  size_t ftyp = f.open("ftyp");
  if (container == "mov") { f.str("qt  "); f.u32(0x200); f.str("qt  "); }
  else { f.str(container == "m4v" ? "M4V " : "isom"); f.u32(0x200); f.str("isom"); f.str("iso2"); f.str(codec == "h264" ? "avc1" : "mp41"); f.str("mp41"); if (container == "m4v") f.str("M4V "); }
  f.close(ftyp);
  // mdat (64-bit size when needed)
  uint64_t payload = 0;
  for (const auto &x : frames) payload += x.size();
  std::string audioBytes;
  if (audio) {
    for (double x : audio->samples) { int64_t v = std::lround(std::clamp(x, -1.0, 1.0) * 32767.0); putLE(audioBytes, static_cast<uint64_t>(v), 2); }
    payload += audioBytes.size();
  }
  std::string subBytes;
  std::vector<uint64_t> subSizes;
  for (const auto &s : subs) { std::string one; putBE(one, s.text.size(), 2); one += s.text; subSizes.push_back(one.size()); subBytes += one; }
  payload += subBytes.size();
  bool big = payload + 16 > 0xFFFFFFFFull;
  uint64_t dataStart = f.s.size() + (big ? 16 : 8);
  if (big) { f.u32(1); f.str("mdat"); f.u64(payload + 16); } else { f.u32(payload + 8); f.str("mdat"); }
  std::vector<Track> tracks;
  Track vt;
  vt.kind = "vide";
  uint64_t at = dataStart;
  for (const auto &x : frames) { vt.offsets.push_back(at); vt.sizes.push_back(x.size()); at += x.size(); }
  vt.timescale = static_cast<uint32_t>(std::lround(fps * 1000));
  vt.delta = 1000;
  vt.duration = static_cast<uint64_t>(frames.size()) * 1000;
  tracks.push_back(vt);
  if (audio) {
    Track at2;
    at2.kind = "soun";
    at2.offsets = {at};
    at2.sizes = {audioBytes.size()};
    at2.timescale = static_cast<uint32_t>(audio->fs);
    at2.delta = 1;
    at2.duration = audio->frames;
    at += audioBytes.size();
    tracks.push_back(at2);
  }
  if (!subs.empty()) {
    Track st;
    st.kind = "text";
    st.timescale = 1000;
    uint64_t t = 0;
    for (size_t k = 0; k < subs.size(); k++) {
      st.offsets.push_back(at);
      st.sizes.push_back(subSizes[k]);
      at += subSizes[k];
      uint64_t start = static_cast<uint64_t>(std::llround(subs[k].start * 1000)), end = static_cast<uint64_t>(std::llround(subs[k].end * 1000));
      if (start > t) { st.offsets.insert(st.offsets.end() - 1, at - subSizes[k]); st.sizes.insert(st.sizes.end() - 1, 0); st.deltas.push_back(static_cast<uint32_t>(start - t)); t = start; }
      st.deltas.push_back(static_cast<uint32_t>(std::max<uint64_t>(1, end - t)));
      t = std::max(end, t + 1);
    }
    st.duration = t;
    tracks.push_back(st);
  }
  for (const auto &x : frames) f.str(x);
  f.str(audioBytes);
  f.str(subBytes);
  // moov
  size_t moov = f.open("moov");
  size_t mvhd = f.open("mvhd");
  f.u32(0); f.u32(0); f.u32(0); f.u32(1000);
  f.u32(static_cast<uint32_t>(std::llround(duration * 1000)));
  f.u32(0x00010000); f.u16(0x0100); f.zeros(10);
  matrix(f);
  f.zeros(24);
  f.u32(static_cast<uint32_t>(tracks.size() + 1));
  f.close(mvhd);
  for (size_t ti = 0; ti < tracks.size(); ti++) {
    const Track &t = tracks[ti];
    size_t trak = f.open("trak");
    size_t tkhd = f.open("tkhd");
    f.u32(t.kind == "text" ? 3 : 3); f.u32(0); f.u32(0);
    f.u32(static_cast<uint32_t>(ti + 1)); f.u32(0);
    f.u32(static_cast<uint32_t>(std::llround(duration * 1000)));
    f.zeros(8); f.u16(0); f.u16(t.kind == "soun" ? 1 : 0);
    f.u16(t.kind == "soun" ? 0x0100 : 0); f.u16(0);
    matrix(f);
    f.u32(t.kind == "soun" ? 0 : static_cast<uint32_t>(w) << 16);
    f.u32(t.kind == "soun" ? 0 : static_cast<uint32_t>(t.kind == "text" ? 60 : h) << 16);
    f.close(tkhd);
    size_t mdia = f.open("mdia");
    size_t mdhd = f.open("mdhd");
    f.u32(0); f.u32(0); f.u32(0); f.u32(t.timescale); f.u32(static_cast<uint32_t>(t.duration)); f.u16(0x55C4); f.u16(0);
    f.close(mdhd);
    size_t hdlr = f.open("hdlr");
    f.u32(0); f.u32(0); f.str(t.kind == "text" ? "sbtl" : t.kind); f.zeros(12);
    std::string hn = t.kind == "vide" ? "VideoHandler" : t.kind == "soun" ? "SoundHandler" : "SubtitleHandler";
    f.str(hn); f.u8(0);
    f.close(hdlr);
    size_t minf = f.open("minf");
    if (t.kind == "vide") { size_t vm = f.open("vmhd"); f.u32(1); f.zeros(8); f.close(vm); }
    else if (t.kind == "soun") { size_t sm = f.open("smhd"); f.u32(0); f.zeros(4); f.close(sm); }
    else { size_t nm = f.open("nmhd"); f.u32(0); f.close(nm); }
    size_t dinf = f.open("dinf");
    size_t dref = f.open("dref");
    f.u32(0); f.u32(1);
    size_t url = f.open("url "); f.u32(1); f.close(url);
    f.close(dref);
    f.close(dinf);
    size_t stbl = f.open("stbl");
    size_t stsd = f.open("stsd");
    f.u32(0); f.u32(1);
    if (t.kind == "vide") {
      size_t e = f.open(codec == "h264" ? "avc1" : "jpeg");
      f.zeros(6); f.u16(1); f.zeros(16);
      f.u16(static_cast<uint32_t>(w)); f.u16(static_cast<uint32_t>(h));
      f.u32(0x00480000); f.u32(0x00480000); f.u32(0); f.u16(1);
      std::string name = codec == "h264" ? "NC H.264 (I_PCM)" : "Photo - JPEG";
      f.u8(name.size()); f.str(name); f.zeros(31 - name.size());
      f.u16(24); f.u16(0xFFFF);
      if (codec == "h264") {
        size_t avcc = f.open("avcC");
        f.u8(1); f.u8(static_cast<unsigned char>(ps.sps[1])); f.u8(static_cast<unsigned char>(ps.sps[2])); f.u8(static_cast<unsigned char>(ps.sps[3]));
        f.u8(0xFF); f.u8(0xE1); f.u16(ps.sps.size()); f.str(ps.sps); f.u8(1); f.u16(ps.pps.size()); f.str(ps.pps);
        f.close(avcc);
      }
      f.close(e);
    } else if (t.kind == "soun") {
      size_t e = f.open("sowt");
      f.zeros(6); f.u16(1); f.u16(0); f.zeros(6);
      f.u16(audio->channels); f.u16(16); f.u16(0); f.u16(0); f.u32(static_cast<uint32_t>(audio->fs) << 16);
      f.close(e);
    } else {
      size_t e = f.open("tx3g");
      f.zeros(6); f.u16(1); f.u32(0); f.u8(1); f.u8(0xFF); f.u32(0xFFFFFFFFu); // flags, justification, bg colour
      f.u16(0); f.u16(0); f.u16(60); f.u16(static_cast<uint32_t>(w)); // default text box
      f.u16(0); f.u16(0); f.u16(1); f.u8(0); f.u8(18); f.u32(0xFFFFFFFFu); // style record
      size_t ftab = f.open("ftab"); f.u16(1); f.u16(1); f.u8(5); f.str("Serif"); f.close(ftab);
      f.close(e);
    }
    f.close(stsd);
    size_t stts = f.open("stts");
    f.u32(0);
    if (!t.deltas.empty()) { f.u32(static_cast<uint32_t>(t.deltas.size())); for (auto d : t.deltas) { f.u32(1); f.u32(d); } }
    else if (t.kind == "soun") { f.u32(1); f.u32(static_cast<uint32_t>(t.duration)); f.u32(1); }
    else { f.u32(1); f.u32(static_cast<uint32_t>(t.offsets.size())); f.u32(t.delta); }
    f.close(stts);
    size_t stsc = f.open("stsc");
    f.u32(0); f.u32(1); f.u32(1);
    f.u32(t.kind == "soun" ? static_cast<uint32_t>(t.duration) : 1);
    f.u32(1);
    f.close(stsc);
    size_t stsz = f.open("stsz");
    f.u32(0);
    if (t.kind == "soun") { f.u32(static_cast<uint32_t>(2 * audio->channels)); f.u32(static_cast<uint32_t>(t.duration)); }
    else { f.u32(0); f.u32(static_cast<uint32_t>(t.sizes.size())); for (auto s : t.sizes) f.u32(static_cast<uint32_t>(s)); }
    f.close(stsz);
    bool use64 = !t.offsets.empty() && t.offsets.back() > 0xFFFFFFFFull;
    size_t co = f.open(use64 ? "co64" : "stco");
    f.u32(0); f.u32(static_cast<uint32_t>(t.offsets.size()));
    for (auto o : t.offsets) { if (use64) f.u64(o); else f.u32(static_cast<uint32_t>(o)); }
    f.close(co);
    f.close(stbl);
    f.close(minf);
    f.close(mdia);
    f.close(trak);
  }
  f.close(moov);
  return f.s;
}

std::string writeAvi(const std::vector<std::string> &frames, double fps, const std::string &codec, size_t w, size_t h,
                     const Audio *audio, const std::vector<std::pair<std::string, std::string>> &info) {
  auto chunk = [](std::string &o, const std::string &id, const std::string &data) { o += id; putLE(o, data.size(), 4); o += data; if (data.size() & 1) o.push_back('\0'); };
  auto list = [](const std::string &kind, const std::string &body) { std::string o = "LIST"; putLE(o, body.size() + 4, 4); o += kind + body; return o; };
  std::string fcc = codec == "h264" ? "H264" : "MJPG";
  size_t maxFrame = 0;
  for (const auto &x : frames) maxFrame = std::max(maxFrame, x.size());
  std::string avih;
  putLE(avih, static_cast<uint32_t>(std::llround(1e6 / fps)), 4);
  putLE(avih, static_cast<uint32_t>(maxFrame * fps), 4);
  putLE(avih, 0, 4);
  putLE(avih, 0x10, 4); // AVIF_HASINDEX
  putLE(avih, frames.size(), 4);
  putLE(avih, 0, 4);
  putLE(avih, audio ? 2 : 1, 4);
  putLE(avih, maxFrame, 4);
  putLE(avih, w, 4);
  putLE(avih, h, 4);
  avih.append(16, '\0');
  std::string strh;
  strh += "vids" + fcc;
  putLE(strh, 0, 4); putLE(strh, 0, 4); putLE(strh, 0, 4);
  putLE(strh, 1000, 4);
  putLE(strh, static_cast<uint32_t>(std::llround(fps * 1000)), 4);
  putLE(strh, 0, 4);
  putLE(strh, frames.size(), 4);
  putLE(strh, maxFrame, 4);
  putLE(strh, 0xFFFFFFFFu, 4);
  putLE(strh, 0, 4);
  putLE(strh, 0, 2); putLE(strh, 0, 2); putLE(strh, w, 2); putLE(strh, h, 2);
  std::string strf;
  putLE(strf, 40, 4); putLE(strf, w, 4); putLE(strf, h, 4); putLE(strf, 1, 2); putLE(strf, 24, 2);
  strf += fcc;
  putLE(strf, w * h * 3, 4); putLE(strf, 0, 4); putLE(strf, 0, 4); putLE(strf, 0, 4); putLE(strf, 0, 4);
  std::string strl;
  chunk(strl, "strh", strh);
  chunk(strl, "strf", strf);
  std::string hdrl;
  chunk(hdrl, "avih", avih);
  hdrl += list("strl", strl);
  std::string audioPcm;
  if (audio) {
    for (double x : audio->samples) { int64_t v = std::lround(std::clamp(x, -1.0, 1.0) * 32767.0); putLE(audioPcm, static_cast<uint64_t>(v), 2); }
    std::string ah;
    ah += "auds";
    putLE(ah, 1, 4); putLE(ah, 0, 4); putLE(ah, 0, 4); putLE(ah, 0, 4);
    putLE(ah, 1, 4); putLE(ah, audio->fs, 4); putLE(ah, 0, 4); putLE(ah, audio->frames, 4);
    putLE(ah, audioPcm.size(), 4); putLE(ah, 0xFFFFFFFFu, 4); putLE(ah, 2 * audio->channels, 4);
    ah.append(8, '\0');
    std::string af;
    putLE(af, 1, 2); putLE(af, audio->channels, 2); putLE(af, audio->fs, 4); putLE(af, audio->fs * 2 * audio->channels, 4); putLE(af, 2 * audio->channels, 2); putLE(af, 16, 2);
    std::string sl;
    chunk(sl, "strh", ah);
    chunk(sl, "strf", af);
    hdrl += list("strl", sl);
  }
  std::string movi, idx;
  size_t moviPos = 4; // offsets in idx1 count from the 'movi' fourcc
  for (const auto &x : frames) {
    idx += "00dc";
    putLE(idx, 0x10, 4);
    putLE(idx, moviPos + movi.size(), 4);
    putLE(idx, x.size(), 4);
    chunk(movi, "00dc", x);
  }
  if (audio) {
    size_t per = std::max<size_t>(1, audio->fs) * 2 * audio->channels; // one second per chunk
    for (size_t p = 0; p < audioPcm.size(); p += per) {
      std::string part = audioPcm.substr(p, per);
      idx += "01wb";
      putLE(idx, 0x10, 4);
      putLE(idx, moviPos + movi.size(), 4);
      putLE(idx, part.size(), 4);
      chunk(movi, "01wb", part);
    }
  }
  std::string body = "AVI " + list("hdrl", hdrl);
  if (!info.empty()) {
    std::string inf;
    for (const auto &kv : info) chunk(inf, kv.first, kv.second + '\0');
    body += list("INFO", inf);
  }
  body += list("movi", movi);
  chunk(body, "idx1", idx);
  std::string out = "RIFF";
  putLE(out, body.size(), 4);
  return out + body;
}

// subtitles: list of texts (spread over the video), or rows [start, end, "text"]
bool subtitlesOf(const Value &v, double duration, std::vector<Subtitle> &out, std::string &err) {
  out.clear();
  if (!given(v)) return true;
  if (v.isMatrix && !v.isND() && v.rows() > 0 && v.rowLength(0) == 3) {
    for (size_t r = 0; r < v.rows(); r++) {
      Subtitle s;
      s.start = optNumber(v.at(r, 0), std::nan(""));
      s.end = optNumber(v.at(r, 1), std::nan(""));
      if (v.at(r, 0).isText) s.start = std::atof(v.at(r, 0).text().c_str());
      if (v.at(r, 1).isText) s.end = std::atof(v.at(r, 1).text().c_str());
      s.text = cellText(v.at(r, 2));
      if (!(s.end > s.start)) { err = "boxes row " + std::to_string(r + 1) + ": end must be after start"; return false; }
      out.push_back(s);
    }
    std::sort(out.begin(), out.end(), [](const Subtitle &a, const Subtitle &b) { return a.start < b.start; });
    return true;
  }
  std::vector<std::string> texts = optTextList(v);
  for (size_t k = 0; k < texts.size(); k++) out.push_back({duration * k / texts.size(), duration * (k + 1) / texts.size(), texts[k]});
  return true;
}

// save_<fmt>(file, frames, fps, codec, crf, bitrate, audio, boxes, max_size)
Value saveVideo(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  double fps = optNumber(a[2], 30);
  if (!(fps > 0) || fps > 1000) return fail("fps must be between 0 and 1000");
  std::string codec = lower(optText(a[3], "h264"));
  if (codec == "avc" || codec == "x264") codec = "h264";
  if (codec == "mjpg" || codec == "jpeg") codec = "mjpeg";
  if (codec == "hevc" || codec == "h265" || codec == "prores") return fail("codec=\"" + codec + "\" is not built in - use \"h264\" (exact YUV 4:2:0, large files) or \"mjpeg\" (compact)");
  if (codec != "h264" && codec != "mjpeg") return fail("codec must be \"h264\" or \"mjpeg\" (\"hevc\" / \"prores\" are not built in)");
  // frames: (T, H, W, C) / (T, H, W) gray
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!ndToRowMajor(a[1], shape, vals) || shape.size() < 3 || shape.size() > 4) return fail("frames must be a (T, H, W, C) or (T, H, W) tensor");
  size_t T = shape[0], H = shape[1], W = shape[2], C = shape.size() == 4 ? shape[3] : 1;
  if (T == 0 || H == 0 || W == 0) return fail("frames is empty");
  if (C != 1 && C != 3 && C != 4) return fail("frames must have 1, 3 or 4 channels (got " + std::to_string(C) + ")");
  if (codec == "h264" && (H % 2 || W % 2)) return fail("H.264 (yuv420p) needs an even height and width - the frames are " + std::to_string(W) + " x " + std::to_string(H));
  double mx = 0;
  for (double x : vals) if (std::isfinite(x)) mx = std::max(mx, x);
  double scale = mx <= 1.0 ? 255.0 : 1.0; // 0..1 floats -> 0..255
  auto frameImage = [&](size_t t) {
    Image img;
    img.width = W;
    img.height = H;
    img.channels = C;
    img.px.assign(vals.begin() + static_cast<long>(t * H * W * C), vals.begin() + static_cast<long>((t + 1) * H * W * C));
    for (double &x : img.px) x = std::clamp(std::isfinite(x) ? std::round(x * scale) : 0.0, 0.0, 255.0);
    if (C == 4) img = convertChannels(img, "rgb");
    return img;
  };
  double duration = T / fps;
  Audio au;
  const Audio *audio = nullptr;
  if (given(a[6])) {
    if (fmt == "mp4" || fmt == "m4v") return fail("audio in ." + fmt + " needs AAC, which is not built in - save as .mov or .avi (PCM audio), or save the audio separately with save_wav");
    if (!valueToAudio(a[6], -1, au, err)) return fail("audio: " + err);
    audio = &au;
  }
  std::vector<Subtitle> subs;
  if (!subtitlesOf(a[7], duration, subs, err)) return fail(err);
  uint64_t budget = 0;
  if (given(a[8]) && !parseByteSize(optText(a[8]), budget)) return fail("max_size must be a size like \"25mb\"");
  uint64_t bitrate = 0;
  if (given(a[5])) {
    std::string br = lower(optText(a[5]));
    double v = std::atof(br.c_str());
    if (br.find('k') != std::string::npos) v *= 1e3; else if (br.find('m') != std::string::npos) v *= 1e6; else if (br.find('g') != std::string::npos) v *= 1e9;
    if (!(v > 0)) return fail("bitrate must be like \"5M\" or \"800k\"");
    bitrate = static_cast<uint64_t>(v);
  }
  double crf = optNumber(a[4], 23);
  if (crf < 0 || crf > 51) return fail("crf must be 0..51");
  std::vector<std::string> encoded(T);
  H264Params ps;
  auto encodeAll = [&](int quality) {
    for (size_t t = 0; t < T; t++) {
      Image img = frameImage(t);
      if (codec == "mjpeg") encoded[t] = encodeJpeg(img, quality, true, false);
      else {
        std::vector<std::string> nals = h264EncodePcm(img, static_cast<int>(t & 1), ps);
        std::string s;
        if (fmt == "avi") for (const auto &n : nals) { s += std::string("\0\0\0\1", 4); s += n; }
        else { putBE(s, nals[2].size(), 4); s += nals[2]; }
        encoded[t] = s;
      }
      if (cancelRequested()) return false;
    }
    return true;
  };
  int quality = static_cast<int>(std::clamp(130.0 - 2.0 * crf, 5.0, 100.0));
  uint64_t target = 0; // bytes for all frames
  if (bitrate) target = static_cast<uint64_t>(bitrate / 8.0 * duration);
  if (budget) target = target ? std::min<uint64_t>(target, budget * 97 / 100) : budget * 97 / 100;
  if (codec == "mjpeg" && target) { // quality search on a sample of frames
    std::vector<size_t> sample = {0, T / 2, T - 1};
    int lo = 5, hi = quality, best = 5;
    while (lo <= hi) {
      int mid = (lo + hi) / 2;
      uint64_t bytes = 0;
      for (size_t t : sample) bytes += encodeJpeg(frameImage(t), mid, true, false).size();
      if (bytes * T / sample.size() <= target) { best = mid; lo = mid + 1; } else hi = mid - 1;
    }
    quality = best;
  }
  if (!encodeAll(quality)) return fail("cancelled");
  std::string bytes;
  std::vector<std::pair<std::string, std::string>> info = {{"ISFT", "NC save_" + fmt}};
  if (fmt == "avi") {
    uint64_t total = 0;
    for (const auto &e : encoded) total += e.size() + 24;
    if (total > (1ull << 30)) return fail("AVI files over 1 GB are not built in (OpenDML) - save as .mp4 / .mov, or use codec=\"mjpeg\"");
    bytes = writeAvi(encoded, fps, codec, W, H, audio, info);
    if (!subs.empty()) { // AVI has no standard subtitle track: a .srt next to it
      std::string srt;
      auto stamp = [](double s) { char b2[32]; int ms = static_cast<int>(std::lround(s * 1000)); std::snprintf(b2, sizeof b2, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000); return std::string(b2); };
      for (size_t k = 0; k < subs.size(); k++) srt += std::to_string(k + 1) + "\n" + stamp(subs[k].start) + " --> " + stamp(subs[k].end) + "\n" + subs[k].text + "\n\n";
      std::filesystem::path sp(file);
      sp.replace_extension(".srt");
      if (!writeFile(sp.string(), srt, false, err)) return fail(err);
    }
  } else bytes = writeMp4(fmt, encoded, fps, codec, W, H, ps, audio, subs, duration);
  if (budget && bytes.size() > budget) {
    return fail("the video is " + std::to_string(bytes.size()) + " bytes, over max_size (" + std::to_string(budget) + " bytes)" +
                (codec == "h264" ? " - H.264 here is stored as I_PCM (uncompressed); use codec=\"mjpeg\" for small files" : " even at the lowest quality - use fewer / smaller frames"));
  }
  if (!writeFile(file, bytes, false, err)) return fail(err);
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerVideo(Registry &reg) {
  for (const char *ext : {"mp4", "avi", "m4v", "mov"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, frames=\"\", time=\"\", stride=1, roi=\"\", scale=\"\", gray=false, audio=false, box=true",
             "decode frames of a ." + e + " into a (T, H, W, C) tensor (frames are numbered from 0; MJPEG / raw / PNG / NC H.264)", "imageio.v3.imread", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readVideo(e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file", "open a ." + e + " (D.fps, D.count, D.width, D.height, D.duration, D.codec, D.audio, D.subtitles, D.frame(i), D.at_time(t))",
          "cv2.VideoCapture", [e](const std::vector<Value> &a, CallContext &ctx) { return loadVideo(e, a, ctx); });
    addFn(reg, "save_" + e, "file, frames, fps=30, codec=\"h264\", crf=23, bitrate=\"\", audio=\"\", boxes=\"\", max_size=\"\"",
          "write a (T, H, W, C) tensor as ." + e + " (h264 = exact I_PCM, mjpeg = compact; audio as PCM in .mov / .avi; boxes = subtitles)",
          "imageio.v3.imwrite", [e](const std::vector<Value> &a, CallContext &ctx) { return saveVideo(e, a, ctx); });
  }
  addFn(reg, "NcVideo.frame", "V, i", "decode frame i (numbered from 0) as an (H, W, C) image", "cv2.VideoCapture.read",
        [](const std::vector<Value> &a, CallContext &ctx) { return frameMethod(a, ctx, false); });
  addFn(reg, "NcVideo.at_time", "V, sec", "decode the frame shown at time sec", "cv2.CAP_PROP_POS_MSEC",
        [](const std::vector<Value> &a, CallContext &ctx) { return frameMethod(a, ctx, true); });
  addFn(reg, "NcVideo.read", "V, frames=\"\", time=\"\", stride=1, roi=\"\", scale=\"\", gray=false", "decode a selection of frames as (T, H, W, C)",
        "imageio.v3.imread", readMethod);
}

} // namespace io
} // namespace nc
