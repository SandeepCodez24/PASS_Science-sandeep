// CATEGORY 2 - delimited text: read_/load_/save_ csv, tsv, txt, dat.
//
// One tokenizer serves all four (they differ only in the default delimiter):
//   - RFC 4180 quoting ("a,b" and "" inside quotes, fields over several lines)
//   - comment lines (cmt="#"), kept with their line numbers
//   - virtual sheets: a line "# [Sheet: ABC]" (sec_fmt) starts section ABC
//   - the table block of a section is the longest run of rows with the
//     usual field count; the lines before/after it are "boxes" (free text
//     such as "Project: Agni") returned beside the data
#include <algorithm>
#include <cmath>
#include <map>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"

namespace nc {
namespace io {
namespace {

struct Record {
  std::vector<std::string> fields;
  std::string raw;
  size_t line = 0;
};

struct Section {
  std::string name;
  std::vector<Record> records; // blank lines kept as records with no fields
};

struct Parsed {
  std::vector<Section> sections;
  std::vector<std::pair<size_t, std::string>> comments;
  std::vector<std::string> rawLines;
  std::string dlm; // the delimiter actually used ("ws" = runs of blanks)
};

const std::vector<std::string> kDefaultNa = {"", "NA", "N/A", "NULL", "null", "NaN", "nan"};

// "\s+", "\\s+", "whitespace" -> "ws"; "\t", "tab" -> "\t"; "auto" stays.
std::string normalizeDelimiter(const std::string &d) {
  std::string l = lower(d);
  if (l == "\\s+" || l == "\\\\s+" || l == "s+" || l == "whitespace" || l == "space" || l == "ws" ||
      l == " " || l == "\\s")
    return "ws";
  if (l == "\\t" || l == "\\\\t" || l == "tab" || l == "\t")
    return "\t";
  if (l == "auto" || l.empty())
    return "auto";
  return d;
}

// Splits one physical line (no quotes spanning lines) - used for sniffing.
size_t quickCount(const std::string &line, const std::string &dlm) {
  size_t n = 1;
  bool q = false;
  for (size_t i = 0; i < line.size(); i++) {
    if (line[i] == '"')
      q = !q;
    else if (!q && line.compare(i, dlm.size(), dlm) == 0)
      n++;
  }
  return n;
}

std::string sniffDelimiter(const std::string &text, const std::string &cmt) {
  std::vector<std::string> lines;
  size_t start = 0;
  while (start < text.size() && lines.size() < 40) {
    size_t e = text.find('\n', start);
    if (e == std::string::npos)
      e = text.size();
    std::string l = trim(text.substr(start, e - start));
    if (!l.empty() && (cmt.empty() || l.rfind(cmt, 0) != 0))
      lines.push_back(l);
    start = e + 1;
  }
  std::string best = "ws";
  size_t bestScore = 0;
  for (const char *cand : {",", "\t", ";", "|"}) {
    std::map<size_t, size_t> freq;
    for (const auto &l : lines)
      freq[quickCount(l, cand)]++;
    for (const auto &kv : freq)
      if (kv.first > 1 && kv.second * (kv.first > 1) > bestScore) {
        bestScore = kv.second;
        best = cand;
      }
  }
  return bestScore >= 1 ? best : "ws";
}

// Section marker from sec_fmt ("# [Sheet: {name}]") -> prefix/suffix.
bool matchMarker(const std::string &line, const std::string &secFmt, std::string &name) {
  size_t at = secFmt.find("{name}");
  if (at == std::string::npos)
    return false;
  const std::string pre = secFmt.substr(0, at), post = secFmt.substr(at + 6);
  const std::string l = trim(line);
  if (l.size() < pre.size() + post.size() || l.compare(0, pre.size(), pre) != 0 ||
      l.compare(l.size() - post.size(), post.size(), post) != 0)
    return false;
  name = trim(l.substr(pre.size(), l.size() - pre.size() - post.size()));
  return !name.empty();
}

void tokenize(const std::string &text, const std::string &dlmIn, const std::string &cmt,
              const std::string &secFmt, size_t skip, Parsed &p, const std::string &fn,
              const std::string &file) {
  std::string dlm = dlmIn == "auto" ? sniffDelimiter(text, cmt) : dlmIn;
  p.dlm = dlm;
  const bool ws = dlm == "ws";
  p.sections.push_back({"", {}});
  size_t i = 0, line = 1;
  // skip=N drops the first N physical lines.
  while (skip > 0 && i < text.size()) {
    size_t e = text.find('\n', i);
    p.rawLines.push_back(text.substr(i, (e == std::string::npos ? text.size() : e) - i));
    i = e == std::string::npos ? text.size() : e + 1;
    line++;
    skip--;
  }
  size_t nextReport = 1 << 20;
  while (i < text.size()) {
    if (i > nextReport) {
      reportProgress(fn, file, static_cast<double>(i) / text.size());
      nextReport += 1 << 20;
    }
    size_t lineEnd = text.find('\n', i);
    if (lineEnd == std::string::npos)
      lineEnd = text.size();
    std::string physical = text.substr(i, lineEnd - i);
    if (!physical.empty() && physical.back() == '\r')
      physical.pop_back();
    const std::string t = trim(physical);
    std::string marker;
    if (matchMarker(t, secFmt, marker)) {
      p.rawLines.push_back(physical);
      p.sections.push_back({marker, {}});
      i = lineEnd + 1;
      line++;
      continue;
    }
    if (!cmt.empty() && t.rfind(cmt, 0) == 0) {
      p.rawLines.push_back(physical);
      p.comments.push_back({line, physical});
      i = lineEnd + 1;
      line++;
      continue;
    }
    Record rec;
    rec.line = line;
    if (t.empty()) {
      rec.raw = physical;
      p.rawLines.push_back(physical);
      p.sections.back().records.push_back(rec);
      i = lineEnd + 1;
      line++;
      continue;
    }
    // One record - quoted fields may run over line ends.
    std::string fieldText;
    bool inField = false, quoted = false;
    size_t recStart = i;
    while (i < text.size()) {
      char c = text[i];
      if (quoted) {
        if (c == '"') {
          if (i + 1 < text.size() && text[i + 1] == '"') {
            fieldText.push_back('"');
            i += 2;
            continue;
          }
          quoted = false;
          i++;
          continue;
        }
        if (c == '\n')
          line++;
        fieldText.push_back(c);
        i++;
        continue;
      }
      if (c == '\n' || c == '\r') {
        break;
      }
      if (ws ? (c == ' ' || c == '\t') : text.compare(i, dlm.size(), dlm) == 0) {
        if (ws) {
          if (inField) {
            rec.fields.push_back(fieldText);
            fieldText.clear();
            inField = false;
          }
          i++;
          continue;
        }
        rec.fields.push_back(fieldText);
        fieldText.clear();
        inField = false;
        i += dlm.size();
        if (i >= text.size() || text[i] == '\n' || text[i] == '\r')
          rec.fields.push_back(""); // trailing delimiter = empty last field
        continue;
      }
      if (c == '"' && !inField && fieldText.empty()) {
        quoted = true;
        inField = true;
        i++;
        continue;
      }
      fieldText.push_back(c);
      inField = true;
      i++;
    }
    if (inField || !fieldText.empty())
      rec.fields.push_back(fieldText); // fields stay verbatim; cells are trimmed when parsed
    size_t end = text.find('\n', i);
    if (end == std::string::npos)
      end = text.size();
    rec.raw = text.substr(recStart, end - recStart);
    if (!rec.raw.empty() && rec.raw.back() == '\r')
      rec.raw.pop_back();
    p.rawLines.push_back(rec.raw);
    p.sections.back().records.push_back(std::move(rec));
    i = end + 1;
    line++;
  }
  // Content before the first marker is the "Main" section; drop it when it
  // holds nothing but blank lines.
  if (p.sections.size() > 1) {
    bool any = false;
    for (const auto &r : p.sections[0].records)
      if (!r.fields.empty())
        any = true;
    if (!any)
      p.sections.erase(p.sections.begin());
  }
  for (size_t s = 0; s < p.sections.size(); s++)
    if (p.sections[s].name.empty())
      p.sections[s].name = s == 0 ? "Main" : "Sheet" + std::to_string(s + 1);
}

struct Block {
  Table table;
  std::vector<std::string> boxes;
  size_t headerLine = 0; // 0 = no header
};

bool looksNumeric(const std::string &s, const std::vector<std::string> &na) {
  Value v = parseCell(s, na);
  return isNumberCell(v) && !std::isnan(v.number);
}

// The table block of one section, its header and the boxes around it.
bool buildBlock(const Section &sec, long long hdr, const std::vector<std::string> &na, bool ws,
                Block &b, std::string &err) {
  const auto &recs = sec.records;
  std::map<size_t, size_t> freq;
  for (const auto &r : recs)
    if (r.fields.size() >= 2)
      freq[r.fields.size()]++;
  size_t mode = 1;
  size_t best = 0;
  for (const auto &kv : freq)
    if (kv.second > best || (kv.second == best && kv.first > mode)) {
      best = kv.second;
      mode = kv.first;
    }
  auto belongs = [&](const Record &r, bool first) {
    if (r.fields.empty())
      return false;
    if (mode == 1)
      return true;
    if (r.fields.size() == mode)
      return true;
    // Short rows (missing trailing values) inside the table - not with
    // whitespace delimiters, where a sentence of words would match too.
    return !first && !ws && r.fields.size() >= 2 && r.fields.size() < mode;
  };
  size_t bestStart = 0, bestLen = 0;
  for (size_t s = 0; s < recs.size(); s++) {
    if (!belongs(recs[s], true))
      continue;
    size_t e = s + 1;
    while (e < recs.size() && belongs(recs[e], false))
      e++;
    // A blank line followed by more rows of the same width continues it.
    while (e + 1 < recs.size() && recs[e].fields.empty() && recs[e + 1].fields.size() == mode &&
           mode > 1) {
      e++;
      while (e < recs.size() && belongs(recs[e], false))
        e++;
    }
    if (e - s > bestLen) {
      bestStart = s;
      bestLen = e - s;
    }
    s = e - 1;
  }
  std::vector<const Record *> rows;
  for (size_t k = bestStart; k < bestStart + bestLen; k++)
    if (!recs[k].fields.empty())
      rows.push_back(&recs[k]);
  for (size_t k = 0; k < recs.size(); k++)
    if ((k < bestStart || k >= bestStart + bestLen) && !recs[k].fields.empty())
      b.boxes.push_back(trim(recs[k].raw));

  size_t first = 0;
  if (hdr > 0) {
    if (static_cast<size_t>(hdr) > rows.size()) {
      err = "hdr=" + std::to_string(hdr) + " but the table has only " + std::to_string(rows.size()) +
            " rows";
      return false;
    }
    for (long long k = 0; k < hdr - 1; k++)
      b.boxes.push_back(trim(rows[static_cast<size_t>(k)]->raw));
    b.table.cols = rows[static_cast<size_t>(hdr - 1)]->fields;
    b.headerLine = rows[static_cast<size_t>(hdr - 1)]->line;
    first = static_cast<size_t>(hdr);
  } else if (hdr < 0 && !rows.empty()) {
    bool allText = true, unique = true;
    std::vector<std::string> seen;
    for (const auto &f : rows[0]->fields) {
      std::string t = trim(f);
      if (t.empty() || looksNumeric(t, na))
        allText = false;
      if (std::find(seen.begin(), seen.end(), t) != seen.end())
        unique = false;
      seen.push_back(t);
    }
    bool numericLater = false;
    for (size_t k = 1; k < rows.size() && k < 50 && !numericLater; k++)
      for (const auto &f : rows[k]->fields)
        if (looksNumeric(f, na)) {
          numericLater = true;
          break;
        }
    if (allText && (numericLater || (unique && rows.size() > 1))) {
      b.table.cols = rows[0]->fields;
      b.headerLine = rows[0]->line;
      first = 1;
    }
  }
  for (auto &c : b.table.cols)
    c = trim(c);
  std::vector<std::string> raws;
  for (size_t k = first; k < rows.size(); k++) {
    std::vector<Value> row;
    row.reserve(rows[k]->fields.size());
    for (const auto &f : rows[k]->fields)
      row.push_back(parseCell(f, na));
    b.table.rows.push_back(std::move(row));
    raws.push_back(trim(rows[k]->raw));
  }
  // A first/last row that puts words into mostly-numeric columns is free
  // text that happens to have the table's width ("End of scan").
  auto &tr = b.table.rows;
  if (tr.size() >= 3) {
    size_t width = 0;
    for (const auto &r : tr)
      width = std::max(width, r.size());
    std::vector<size_t> numeric(width, 0);
    for (const auto &r : tr)
      for (size_t c = 0; c < r.size(); c++)
        if (isNumberCell(r[c]))
          numeric[c]++;
    auto stray = [&](const std::vector<Value> &r) {
      size_t numCols = 0, bad = 0;
      for (size_t c = 0; c < width; c++) {
        if (numeric[c] * 3 < tr.size() * 2)
          continue;
        numCols++;
        if (c >= r.size() || (!isNumberCell(r[c]) && !(r[c].isText && r[c].text().empty())))
          bad++;
      }
      return numCols > 0 && bad * 2 >= numCols && bad >= 1;
    };
    std::vector<std::string> tail;
    while (tr.size() > 2 && stray(tr.back())) {
      tail.insert(tail.begin(), raws.back());
      tr.pop_back();
      raws.pop_back();
    }
    while (tr.size() > 2 && stray(tr.front())) {
      b.boxes.insert(b.boxes.begin(), raws.front());
      tr.erase(tr.begin());
      raws.erase(raws.begin());
    }
    b.boxes.insert(b.boxes.end(), tail.begin(), tail.end());
  }
  normalizeTable(b.table);
  return true;
}

struct ReadOpts {
  std::string dlm, cmt = "#", enc = "utf-8", secFmt = "# [Sheet: {name}]";
  long long hdr = -1, skip = 0;
  std::vector<std::string> na = kDefaultNa;
};

bool parseFile(const std::string &file, const ReadOpts &o, Parsed &p, const std::string &fn,
               std::string &err) {
  std::string raw, text;
  if (!readSource(file, raw, err) || !autoDecompress(raw, err) || !decodeText(raw, o.enc, text, err))
    return false;
  tokenize(text, o.dlm, o.cmt, o.secFmt, static_cast<size_t>(std::max(0LL, o.skip)), p, fn, file);
  return true;
}

bool pickSection(const Parsed &p, const Value &sheet, size_t &idx, std::string &err) {
  idx = 0;
  if (!given(sheet) || (numpy::isPlainNumber(sheet) && sheet.number <= 0))
    return true;
  if (numpy::isPlainNumber(sheet)) {
    size_t k = static_cast<size_t>(sheet.number);
    if (k < 1 || k > p.sections.size()) {
      err = "sheet " + std::to_string(k) + " does not exist (the file has " +
            std::to_string(p.sections.size()) + ")";
      return false;
    }
    idx = k - 1;
    return true;
  }
  std::string want = optText(sheet);
  for (size_t s = 0; s < p.sections.size(); s++)
    if (p.sections[s].name == want || lower(p.sections[s].name) == lower(want)) {
      idx = s;
      return true;
    }
  std::string names;
  for (const auto &s : p.sections)
    names += (names.empty() ? "" : ", ") + s.name;
  err = "no sheet '" + want + "' (sheets: " + names + ")";
  return false;
}

Value commentsValue(const std::vector<std::pair<size_t, std::string>> &c) {
  std::vector<std::vector<Value>> m;
  for (const auto &kv : c)
    m.push_back({Value(static_cast<double>(kv.first)), Value(kv.second)});
  if (m.empty())
    return Value(std::vector<Value>{});
  return Value(m);
}

std::vector<std::string> sectionNames(const Parsed &p) {
  std::vector<std::string> n;
  for (const auto &s : p.sections)
    n.push_back(s.name);
  return n;
}

bool readOpts(const std::vector<Value> &a, size_t dlmAt, const std::string &defDlm, ReadOpts &o,
              std::string &err) {
  o.dlm = normalizeDelimiter(optText(a[dlmAt], defDlm));
  (void)err;
  return true;
}

std::string dlmText(const std::string &d) { return d == "ws" ? "\\s+" : d == "\t" ? "\\t" : d; }

// read_<fmt>(file, sheet, dlm, cols, rows, hdr, box, cmt, skip, enc, na, sec_fmt)
void readDelimited(const std::string &fn, const std::string &defDlm, const std::vector<Value> &a,
                   size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return;
  EventScope ev(fn, file);
  ReadOpts o;
  readOpts(a, 2, defDlm, o, err);
  o.hdr = a[5].isBool() ? (a[5].number != 0 ? 1 : 0) : optInt(a[5], -1);
  const bool box = optBool(a[6], true);
  o.cmt = a[7].isText ? a[7].text() : o.cmt;
  o.skip = optInt(a[8], 0);
  o.enc = optText(a[9], "utf-8");
  if (given(a[10]))
    o.na = optTextList(a[10]);
  o.secFmt = optText(a[11], o.secFmt);
  Parsed p;
  if (!parseFile(file, o, p, fn, err))
    return ctx.fail(err);
  size_t sec = 0;
  if (!pickSection(p, a[1], sec, err))
    return ctx.fail(err);
  Block b;
  if (!buildBlock(p.sections[sec], o.hdr, o.na, p.dlm == "ws", b, err))
    return ctx.fail(err);
  if (!selectTable(b.table, a[3], a[4], err))
    return ctx.fail(err);
  out.push_back(tableData(b.table));
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(b.table.cols);
    info["schema"] = tableSchema(b.table);
    info["boxes"] = box ? textList(b.boxes) : textList({});
    info["comments"] = commentsValue(p.comments);
    info["sheet"] = Value(p.sections[sec].name);
    info["sheets"] = textList(sectionNames(p));
    info["dlm"] = Value(dlmText(p.dlm));
    info["header_line"] = Value(static_cast<double>(b.headerLine));
    info["rows"] = Value(static_cast<double>(b.table.rows.size()));
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

// load_<fmt>(file, dlm, hdr, cmt, skip, enc, na, sec_fmt)
Value loadDelimited(const std::string &fn, const std::string &fmt, const std::string &defDlm,
                    const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  ReadOpts o;
  readOpts(a, 1, defDlm, o, err);
  o.hdr = a[2].isBool() ? (a[2].number != 0 ? 1 : 0) : optInt(a[2], -1);
  o.cmt = a[3].isText ? a[3].text() : o.cmt;
  o.skip = optInt(a[4], 0);
  o.enc = optText(a[5], "utf-8");
  if (given(a[6]))
    o.na = optTextList(a[6]);
  o.secFmt = optText(a[7], o.secFmt);
  Parsed p;
  if (!parseFile(file, o, p, fn, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  std::vector<std::string> allBoxes;
  Value def;
  Table defTable;
  for (size_t s = 0; s < p.sections.size(); s++) {
    Block b;
    if (!buildBlock(p.sections[s], o.hdr, o.na, p.dlm == "ws", b, err)) {
      ctx.fail(err);
      return Value(0.0);
    }
    for (const auto &bx : b.boxes)
      allBoxes.push_back(bx);
    Value tbl = tableObject(b.table, {{"boxes", textList(b.boxes)},
                                      {"name", Value(p.sections[s].name)}});
    if (s == 0) {
      def = tbl;
      defTable = b.table;
    }
    std::string fname = fieldName(p.sections[s].name);
    if (!fname.empty())
      f[fname] = tbl;
  }
  // The default table's columns are fields of D itself (D.Temp).
  for (size_t c = 0; c < defTable.cols.size(); c++) {
    std::string n = fieldName(defTable.cols[c]);
    if (!n.empty() && !f.count(n))
      f[n] = tableColumn(defTable, c);
  }
  f["default"] = def;
  f["sheets"] = textList(sectionNames(p));
  f["cols"] = textList(defTable.cols);
  f["rows"] = Value(static_cast<double>(defTable.rows.size()));
  f["data"] = tableData(defTable);
  f["schema"] = tableSchema(defTable);
  f["boxes"] = textList(allBoxes);
  f["comments"] = commentsValue(p.comments);
  f["raw_lines"] = textList(p.rawLines);
  f["file"] = Value(file);
  f["format"] = Value(fmt);
  f["dlm"] = Value(dlmText(p.dlm));
  ev.ok = true;
  return makeObject("NcDelimited", std::move(f));
}

std::string quoteField(const std::string &s, const std::string &dlm, bool all) {
  bool need = all || s.find('"') != std::string::npos || s.find('\n') != std::string::npos ||
              s.find('\r') != std::string::npos ||
              (dlm == "ws" ? (s.find(' ') != std::string::npos || s.find('\t') != std::string::npos ||
                              s.empty())
                           : s.find(dlm) != std::string::npos) ||
              (!s.empty() && (s.front() == ' ' || s.back() == ' '));
  if (!need)
    return s;
  std::string q = "\"";
  for (char c : s) {
    if (c == '"')
      q += "\"\"";
    else
      q.push_back(c);
  }
  return q + "\"";
}

bool generatedNames(const Table &t) {
  for (size_t i = 0; i < t.cols.size(); i++)
    if (t.cols[i] != "Col_" + std::to_string(i + 1))
      return false;
  return true;
}

void writeTable(const Table &t, const std::string &dlm, const std::string &hdrMode, bool quoteAll,
                const std::string &floatFmt, bool skipHeader, std::string &out) {
  bool header = !skipHeader && (hdrMode == "true" || hdrMode == "1" ||
                                (hdrMode == "auto" && !generatedNames(t)));
  std::vector<std::vector<std::string>> cells;
  std::vector<bool> numericCol(t.cols.size(), true);
  if (header)
    cells.push_back(t.cols);
  for (const auto &r : t.rows) {
    std::vector<std::string> row;
    for (size_t c = 0; c < r.size(); c++) {
      if (!isNumberCell(r[c]))
        numericCol[c] = false;
      row.push_back(cellText(r[c], floatFmt));
    }
    cells.push_back(std::move(row));
  }
  if (dlm == "ws") {
    // Aligned columns: numbers to the right, text to the left.
    std::vector<size_t> width(t.cols.size(), 0);
    for (auto &row : cells)
      for (size_t c = 0; c < row.size(); c++) {
        row[c] = quoteField(row[c], dlm, quoteAll);
        width[c] = std::max(width[c], row[c].size());
      }
    for (const auto &row : cells) {
      std::string line;
      for (size_t c = 0; c < row.size(); c++) {
        std::string pad(width[c] - row[c].size(), ' ');
        if (c)
          line += "  ";
        line += numericCol[c] ? pad + row[c] : (c + 1 < row.size() ? row[c] + pad : row[c]);
      }
      while (!line.empty() && line.back() == ' ')
        line.pop_back();
      out += line + "\n";
    }
    return;
  }
  for (const auto &row : cells) {
    for (size_t c = 0; c < row.size(); c++) {
      if (c)
        out += dlm;
      out += quoteField(row[c], dlm, quoteAll);
    }
    out += "\n";
  }
}

// Sheets to write: a dict name -> table, or an NcDelimited object.
bool collectSheets(const Value &v, std::vector<std::pair<std::string, Table>> &out,
                   std::string &err) {
  if (isObjectOf(v, "NcDelimited")) {
    const Value *names = field(v, "sheets");
    for (const auto &n : optTextList(names ? *names : Value(std::string()))) {
      const Value *t = field(v, fieldName(n));
      Table tb;
      if (!t || !valueToTable(*t, tb, err))
        return false;
      out.push_back({n, tb});
    }
    return true;
  }
  if (!v.isDict) {
    err = "sheets must be a dict of name -> table (d = dict(); d[\"S1\"] = T1;)";
    return false;
  }
  std::vector<std::string> keys;
  for (const auto &kv : v.dict())
    keys.push_back(kv.first);
  std::sort(keys.begin(), keys.end());
  for (const auto &k : keys) {
    Table tb;
    if (!valueToTable(v.dict().at(k), tb, err, true))
      return false;
    out.push_back({k, tb});
  }
  return true;
}

// save_<fmt>(file, data, sheets, sec_fmt, boxes, dlm, hdr, quote, float_fmt,
//            enc, compress, level, max_size, mode, split)
Value saveDelimited(const std::string &fn, const std::string &defDlm, const std::vector<Value> &a,
                    CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file))
    return Value(0.0);
  EventScope ev(fn, file);
  const std::string secFmt = optText(a[3], "# [Sheet: {name}]");
  std::vector<std::string> boxes = optTextList(a[4]);
  std::string dlm = normalizeDelimiter(optText(a[5], defDlm));
  if (dlm == "auto")
    dlm = "ws";
  std::string hdrMode = a[6].isBool() ? (a[6].number != 0 ? "true" : "false")
                                      : lower(optText(a[6], "auto"));
  const std::string quote = lower(optText(a[7], "minimal"));
  if (quote != "minimal" && quote != "all") {
    ctx.fail("quote must be \"minimal\" or \"all\"");
    return Value(0.0);
  }
  const std::string floatFmt = optText(a[8], "");
  const std::string enc = optText(a[9], "utf-8");
  const std::string compress = optText(a[10], "none");
  const int level = static_cast<int>(optInt(a[11], -1));
  const std::string mode = lower(optText(a[13], "w"));
  const bool split = optBool(a[14], false);
  if (mode != "w" && mode != "a") {
    ctx.fail("mode must be \"w\" (write) or \"a\" (append)");
    return Value(0.0);
  }
  std::vector<std::pair<std::string, Table>> sheets;
  if (given(a[2]) && !collectSheets(a[2], sheets, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  if (given(a[1])) {
    Table t;
    if (!valueToTable(a[1], t, err, true)) {
      ctx.fail(err);
      return Value(0.0);
    }
    sheets.insert(sheets.begin(), {"", t});
  }
  if (sheets.empty()) {
    ctx.fail("nothing to save - give data or sheets");
    return Value(0.0);
  }
  const bool append = mode == "a" && fileExists(file) && fileSize(file) > 0;
  auto render = [&](const std::vector<std::pair<std::string, Table>> &list, bool withBoxes,
                    std::string &text) {
    if (withBoxes)
      for (const auto &bx : boxes)
        text += quoteField(bx, dlm, false) + "\n";
    const bool marked = list.size() > 1 || !list[0].first.empty();
    for (size_t s = 0; s < list.size(); s++) {
      if (marked && !list[s].first.empty()) {
        std::string marker = secFmt;
        size_t at = marker.find("{name}");
        if (at != std::string::npos)
          marker.replace(at, 6, list[s].first);
        if (s > 0 || !text.empty())
          text += "\n";
        text += marker + "\n";
      }
      writeTable(list[s].second, dlm, hdrMode, quote == "all", floatFmt, append && s == 0 && !marked,
                 text);
    }
  };
  auto finish = [&](const std::string &path, std::string text, bool app) -> long long {
    std::string bytes;
    if (!encodeText(text, enc, bytes, err) || !applyCompression(compress, level, bytes, err) ||
        !checkMaxSize(a[12], bytes.size(), err) || !writeFile(path, bytes, app, err)) {
      ctx.fail(err);
      return -1;
    }
    emitEvent({"saved", fn, path, 1.0, formatBytes(bytes.size())});
    return static_cast<long long>(bytes.size());
  };
  long long total = 0;
  if (split && sheets.size() > 1) {
    std::string ext = extensionOf(file);
    for (const auto &s : sheets) {
      std::string text;
      render({s}, true, text);
      std::string name = s.first.empty() ? "Main" : s.first;
      long long n = finish(file + "_" + name + (ext.empty() ? "" : "." + ext), text, false);
      if (n < 0)
        return Value(0.0);
      total += n;
    }
  } else {
    std::string text;
    render(sheets, !append, text);
    long long n = finish(file, text, append);
    if (n < 0)
      return Value(0.0);
    total = n;
  }
  ev.ok = true;
  return Value(static_cast<double>(total));
}

Value sheetMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *names = field(a[0], "sheets");
  std::vector<std::string> list = optTextList(names ? *names : Value(std::string()));
  std::string want;
  if (numpy::isPlainNumber(a[1])) {
    size_t k = static_cast<size_t>(a[1].number);
    if (k < 1 || k > list.size()) {
      ctx.fail("sheet " + std::to_string(k) + " does not exist (there are " +
               std::to_string(list.size()) + ")");
      return Value(0.0);
    }
    want = list[k - 1];
  } else {
    want = optText(a[1]);
  }
  for (const auto &n : list)
    if (n == want || lower(n) == lower(want)) {
      const Value *t = field(a[0], fieldName(n));
      if (t)
        return *t;
    }
  ctx.fail("no sheet '" + want + "'");
  return Value(0.0);
}

} // namespace

void registerDelimited(Registry &reg) {
  struct Fmt {
    const char *ext, *dlm, *title;
  };
  const Fmt fmts[] = {{"csv", ",", "comma-separated values"},
                      {"tsv", "\\t", "tab-separated values"},
                      {"txt", "\\s+", "plain / structured text table"},
                      {"dat", "auto", "generic scientific/tabular data"}};
  for (const Fmt &f : fmts) {
    const std::string ext = f.ext, dlm = f.dlm;
    addMulti(reg, "read_" + ext,
             "file, sheet=\"\", dlm=\"" + dlm +
                 "\", cols=\"\", rows=\"\", hdr=-1, box=true, cmt=\"#\", skip=0, enc=\"utf-8\", na=\"\", sec_fmt=\"# [Sheet: {name}]\"",
             std::string("read the table of a .") + ext + " file (" + f.title + ")",
             "pandas.read_csv", 2,
             [ext, dlm](const std::vector<Value> &a, size_t nout, std::vector<Value> &out,
                        CallContext &ctx) { readDelimited("read_" + ext, dlm, a, nout, out, ctx); });
    addFn(reg, "load_" + ext,
          "file, dlm=\"" + dlm + "\", hdr=-1, cmt=\"#\", skip=0, enc=\"utf-8\", na=\"\", sec_fmt=\"# [Sheet: {name}]\"",
          std::string("load a .") + ext + " file as an object (sheets, columns, boxes, comments)",
          "pandas.read_csv",
          [ext, dlm](const std::vector<Value> &a, CallContext &ctx) {
            return loadDelimited("load_" + ext, ext, dlm, a, ctx);
          });
    addFn(reg, "save_" + ext,
          "file, data=\"\", sheets=\"\", sec_fmt=\"# [Sheet: {name}]\", boxes=\"\", dlm=\"" + dlm +
              "\", hdr=\"auto\", quote=\"minimal\", float_fmt=\"\", enc=\"utf-8\", compress=\"none\", "
              "level=-1, max_size=\"\", mode=\"w\", split=false",
          std::string("write a table (or several sheets) to a .") + ext + " file",
          "pandas.DataFrame.to_csv",
          [ext, dlm](const std::vector<Value> &a, CallContext &ctx) {
            return saveDelimited("save_" + ext, dlm, a, ctx);
          });
  }
  addFn(reg, "NcDelimited.sheet", "D, name", "one sheet (section) of a loaded delimited file",
        "-", sheetMethod);
}

} // namespace io
} // namespace nc
