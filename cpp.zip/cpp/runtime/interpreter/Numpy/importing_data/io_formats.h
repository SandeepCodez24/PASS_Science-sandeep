// One register function per format group of Functions_Importing_Data.pdf.
// Called from registerImportingData() (importing_data_main.cpp).
#ifndef NC_IO_FORMATS_H
#define NC_IO_FORMATS_H

#include "../numpy_registry.h"

namespace nc {
namespace io {

// Phase 1
void registerDelimited(numpy::Registry &reg); // csv tsv txt dat        (cat. 2)
void registerJson(numpy::Registry &reg);      // json                   (cat. 6)
void registerMarkup(numpy::Registry &reg);    // xml html htm           (cat. 7, 8)
void registerConfig(numpy::Registry &reg);    // yaml yml ini           (cat. 9)
void registerBinary(numpy::Registry &reg);    // bin custom             (cat. 13)
// Phase 2
void registerSpreadsheets(numpy::Registry &reg); // xlsx xls xlsm xlsb   (cat. 1)
void registerImages(numpy::Registry &reg);       // png jpg jpeg tiff bmp gif dicom (cat. 14)
void registerAudio(numpy::Registry &reg);        // wav flac ogg mp3     (cat. 15)
void registerMat(numpy::Registry &reg);          // mat fig              (cat. 4, 5)
void registerFits(numpy::Registry &reg);         // fits fit             (cat. 12)
void registerDatabases(numpy::Registry &reg);    // sqlite postgresql mysql oracle sqlserver (cat. 20)
void registerHdf5(numpy::Registry &reg);        // h5 hdf he5            (cat. 10)
void registerNetcdf(numpy::Registry &reg);      // nc cdf                (cat. 11)
void registerColumnar(numpy::Registry &reg);    // parquet feather orc   (cat. 3)
void registerVideo(numpy::Registry &reg);       // mp4 avi m4v mov       (cat. 16)
void registerShapefile(numpy::Registry &reg);   // shp shx dbf           (cat. 17)
void registerGeoTiff(numpy::Registry &reg);     // tif geotiff           (cat. 18)
void registerGps(numpy::Registry &reg);         // gpx kml               (cat. 19)

void registerSession(numpy::Registry &reg);   // io_formats io_detect io_options io_preview io_code

} // namespace io
} // namespace nc

#endif // NC_IO_FORMATS_H
