// Compound File Binary read / write - see io_ole2.h.
#include "io_ole2.h"

#include <algorithm>
#include <cctype>
#include <functional>

#include "io_bytes.h"

namespace nc {
namespace io {

namespace {
const uint32_t kFree = 0xFFFFFFFF, kEnd = 0xFFFFFFFE, kFatSect = 0xFFFFFFFD;

std::string utf16Name(const std::string &b, size_t at, size_t bytes) {
  std::string out;
  for (size_t k = 0; k + 1 < bytes; k += 2) {
    uint32_t c = u16le(b, at + k);
    if (c == 0)
      break;
    if (c < 0x80) out.push_back(static_cast<char>(c));
    else if (c < 0x800) { out.push_back(static_cast<char>(0xC0 | (c >> 6))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    else { out.push_back(static_cast<char>(0xE0 | (c >> 12))); out.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
  }
  return out;
}

std::string lowerAscii(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}
} // namespace

bool isOle2(const std::string &b) { return b.size() >= 512 && b.compare(0, 8, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1") == 0; }

bool Ole2Reader::open(const std::string &b, std::string &err) {
  data_ = &b;
  if (!isOle2(b)) {
    err = "not an OLE2 compound file";
    return false;
  }
  sectorSize_ = 1u << u16le(b, 30);
  if (sectorSize_ != 512 && sectorSize_ != 4096) {
    err = "unsupported OLE2 sector size";
    return false;
  }
  miniCutoff_ = u32le(b, 56);
  uint32_t dirStart = u32le(b, 48), miniFatStart = u32le(b, 60), difatStart = u32le(b, 68);
  uint32_t numDifat = u32le(b, 72);
  auto sector = [&](uint32_t s) { return static_cast<size_t>(s + 1) * sectorSize_; };
  std::vector<uint32_t> fatSectors;
  for (int k = 0; k < 109; k++) {
    uint32_t s = u32le(b, 76 + 4 * k);
    if (s < kFatSect) fatSectors.push_back(s);
  }
  uint32_t ds = difatStart;
  for (uint32_t n = 0; n < numDifat && ds < kFatSect; n++) {
    size_t p = sector(ds);
    for (uint32_t k = 0; k + 1 < sectorSize_ / 4; k++) {
      uint32_t s = u32le(b, p + 4 * k);
      if (s < kFatSect) fatSectors.push_back(s);
    }
    ds = u32le(b, p + sectorSize_ - 4);
  }
  for (uint32_t fs : fatSectors) {
    size_t p = sector(fs);
    if (p + sectorSize_ > b.size()) break;
    for (uint32_t k = 0; k < sectorSize_ / 4; k++)
      fat_.push_back(u32le(b, p + 4 * k));
  }
  std::string dir = chain(dirStart, UINT64_MAX, false);
  for (size_t p = 0; p + 128 <= dir.size(); p += 128) {
    Entry e;
    size_t nameLen = u16le(dir, p + 64);
    e.name = utf16Name(dir, p, std::min<size_t>(nameLen, 64));
    e.type = static_cast<unsigned char>(dir[p + 66]);
    e.left = static_cast<int>(u32le(dir, p + 68));
    e.right = static_cast<int>(u32le(dir, p + 72));
    e.child = static_cast<int>(u32le(dir, p + 76));
    e.start = u32le(dir, p + 116);
    e.size = sectorSize_ == 512 ? u32le(dir, p + 120) : u64le(dir, p + 120);
    entries.push_back(e);
  }
  if (entries.empty() || entries[0].type != 5) {
    err = "OLE2 file has no root entry";
    return false;
  }
  // parents
  std::function<void(int, int)> mark = [&](int idx, int parent) {
    if (idx < 0 || idx >= static_cast<int>(entries.size()) || entries[idx].parent != -1)
      return;
    entries[idx].parent = parent;
    mark(entries[idx].left, parent);
    mark(entries[idx].right, parent);
    if (entries[idx].type == 1 || entries[idx].type == 5)
      mark(entries[idx].child, idx);
  };
  entries[0].parent = -2;
  mark(entries[0].child, 0);
  std::string mf = chain(miniFatStart, UINT64_MAX, false);
  for (size_t p = 0; p + 4 <= mf.size(); p += 4)
    minifat_.push_back(u32le(mf, p));
  ministream_ = chain(entries[0].start, entries[0].size, false);
  return true;
}

std::string Ole2Reader::chain(uint32_t start, uint64_t size, bool mini) const {
  std::string out;
  const std::string &b = *data_;
  uint32_t s = start;
  size_t guard = 0;
  const size_t unit = mini ? 64 : sectorSize_;
  const std::vector<uint32_t> &table = mini ? minifat_ : fat_;
  while (s < kFatSect && out.size() < size && guard++ < 10000000) {
    if (mini) {
      size_t p = static_cast<size_t>(s) * 64;
      if (p + 64 > ministream_.size()) break;
      out.append(ministream_, p, 64);
    } else {
      size_t p = static_cast<size_t>(s + 1) * sectorSize_;
      if (p >= b.size()) break;
      out.append(b, p, std::min<size_t>(unit, b.size() - p));
    }
    if (s >= table.size()) break;
    s = table[s];
  }
  if (size != UINT64_MAX && out.size() > size)
    out.resize(static_cast<size_t>(size));
  return out;
}

int Ole2Reader::find(const std::string &path) const {
  int cur = 0;
  size_t start = 0;
  while (start <= path.size()) {
    size_t slash = path.find('/', start);
    std::string part = lowerAscii(path.substr(start, slash == std::string::npos ? std::string::npos : slash - start));
    int found = -1;
    for (size_t k = 0; k < entries.size(); k++)
      if (entries[k].parent == cur && lowerAscii(entries[k].name) == part) {
        found = static_cast<int>(k);
        break;
      }
    if (found < 0)
      return -1;
    cur = found;
    if (slash == std::string::npos)
      break;
    start = slash + 1;
  }
  return cur;
}

bool Ole2Reader::read(const std::string &path, std::string &out) const {
  int k = find(path);
  if (k < 0 || entries[k].type != 2)
    return false;
  const Entry &e = entries[k];
  out = chain(e.start, e.size, e.size < miniCutoff_);
  return true;
}

std::vector<std::string> Ole2Reader::list(const std::string &storage) const {
  int parent = storage.empty() ? 0 : find(storage);
  std::vector<std::string> out;
  for (const auto &e : entries)
    if (e.parent == parent)
      out.push_back(e.name);
  return out;
}

std::string writeOle2(const std::vector<std::pair<std::string, std::string>> &streamsIn) {
  // Every stream is padded to >= 4096 bytes so no mini stream is needed.
  std::vector<std::pair<std::string, std::string>> streams = streamsIn;
  const size_t S = 512;
  std::vector<uint32_t> starts;
  std::vector<size_t> sizes;
  std::string body; // sectors after the header, starting at sector 0
  auto sectorsOf = [&](size_t n) { return (n + S - 1) / S; };
  std::vector<uint32_t> fat;
  for (auto &s : streams) {
    sizes.push_back(s.second.size());
    if (s.second.size() < 4096)
      s.second.resize(4096, '\0');
    size_t n = sectorsOf(s.second.size());
    uint32_t first = static_cast<uint32_t>(fat.size());
    starts.push_back(first);
    for (size_t k = 0; k < n; k++)
      fat.push_back(k + 1 < n ? first + static_cast<uint32_t>(k) + 1 : kEnd);
    std::string padded = s.second;
    padded.resize(n * S, '\0');
    body += padded;
  }
  // directory: root + streams, 4 entries per sector
  size_t entriesCount = streams.size() + 1;
  size_t dirSectors = sectorsOf(entriesCount * 128);
  uint32_t dirStart = static_cast<uint32_t>(fat.size());
  for (size_t k = 0; k < dirSectors; k++)
    fat.push_back(k + 1 < dirSectors ? dirStart + static_cast<uint32_t>(k) + 1 : kEnd);
  // FAT sectors themselves
  size_t fatSectors = 1;
  while ((fat.size() + fatSectors) > fatSectors * (S / 4))
    fatSectors++;
  uint32_t fatStart = static_cast<uint32_t>(fat.size());
  for (size_t k = 0; k < fatSectors; k++)
    fat.push_back(kFatSect);
  while (fat.size() % (S / 4))
    fat.push_back(kFree);
  // directory entries: root's child = a balanced-enough chain via right links
  std::string dir;
  auto entry = [&](const std::string &name, int type, int left, int right, int child, uint32_t start, uint64_t size) {
    std::string e(128, '\0');
    size_t n = std::min<size_t>(name.size(), 31);
    for (size_t k = 0; k < n; k++)
      e[2 * k] = name[k];
    setLE(e, 64, (n + 1) * 2, 2);
    e[66] = static_cast<char>(type);
    e[67] = 1; // black
    setLE(e, 68, static_cast<uint32_t>(left), 4);
    setLE(e, 72, static_cast<uint32_t>(right), 4);
    setLE(e, 76, static_cast<uint32_t>(child), 4);
    setLE(e, 116, start, 4);
    setLE(e, 120, size, 4);
    dir += e;
  };
  // Siblings sorted by (length, uppercase name) as a right-leaning list.
  std::vector<size_t> order(streams.size());
  for (size_t k = 0; k < order.size(); k++) order[k] = k;
  auto key = [&](size_t k) {
    std::string u = streams[k].first;
    for (char &c : u) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    return std::make_pair(u.size(), u);
  };
  std::sort(order.begin(), order.end(), [&](size_t a, size_t b) { return key(a) < key(b); });
  entry("Root Entry", 5, -1, -1, streams.empty() ? -1 : static_cast<int>(order[0] + 1), kEnd, 0);
  std::vector<int> rightOf(streams.size(), -1);
  for (size_t k = 0; k + 1 < order.size(); k++)
    rightOf[order[k]] = static_cast<int>(order[k + 1] + 1);
  for (size_t k = 0; k < streams.size(); k++)
    entry(streams[k].first, 2, -1, rightOf[k], -1, starts[k], sizes[k] < 4096 ? 4096 : sizes[k]);
  // Note: stored sizes keep the padding (>= 4096) so readers never look
  // for a mini stream; formats inside (BIFF) end with their own EOF record.
  while (dir.size() % S) {
    std::string e(128, '\0');
    setLE(e, 68, kFree, 4);
    setLE(e, 72, kFree, 4);
    setLE(e, 76, kFree, 4);
    dir += e;
  }
  body += dir;
  std::string fatBytes;
  for (uint32_t v : fat)
    putLE(fatBytes, v, 4);
  body += fatBytes;
  std::string h(512, '\0');
  h.replace(0, 8, "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1", 8);
  setLE(h, 24, 0x003E, 2);
  setLE(h, 26, 3, 2);
  setLE(h, 28, 0xFFFE, 2);
  setLE(h, 30, 9, 2);
  setLE(h, 32, 6, 2);
  setLE(h, 44, fatSectors, 4);
  setLE(h, 48, dirStart, 4);
  setLE(h, 56, 4096, 4);
  setLE(h, 60, kEnd, 4);
  setLE(h, 64, 0, 4);
  setLE(h, 68, kEnd, 4);
  setLE(h, 72, 0, 4);
  for (int k = 0; k < 109; k++)
    setLE(h, 76 + 4 * k, k < static_cast<int>(fatSectors) ? fatStart + k : kFree, 4);
  return h + body;
}

} // namespace io
} // namespace nc
