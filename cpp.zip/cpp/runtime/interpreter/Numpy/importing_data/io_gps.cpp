// CATEGORY 19 - read_/load_/save_ gpx, kml (and .kmz): GPS Exchange 1.0 /
// 1.1 (waypoints, routes, tracks, sensor extensions) and KML 2.2
// (placemarks, paths, polygons, folders, gx:Track, LookAt / Camera).
#include <algorithm>
#include <cmath>
#include <map>

#include "../numpy_common.h"
#include "io_formats.h"
#include "io_markup.h"
#include "io_zip.h"

namespace nc {
namespace io {
namespace {

struct GPoint { double lat = 0, lon = 0, ele = std::nan(""); std::string time; std::map<std::string, double> ext; };

struct Feature {
  std::string layer, name, desc, folder, style, altitudeMode, kind; // kind: point line polygon
  std::vector<std::vector<GPoint>> parts;                           // segments / rings
  std::vector<std::pair<std::string, std::string>> data;
};

struct GpsDoc {
  std::string format;
  std::vector<Feature> features;
  std::vector<std::string> boxes;
  Fields camera;
  std::vector<std::string> folders;
};

std::string local(const std::string &n) { size_t c = n.find(':'); return c == std::string::npos ? n : n.substr(c + 1); }

const XNode *kid(const XNode &n, const std::string &name) {
  for (const auto &k : n.kids) if (k.kind == XNode::Element && local(k.name) == name) return &k;
  return nullptr;
}

std::string kidText(const XNode &n, const std::string &name) { const XNode *k = kid(n, name); return k ? trim(k->innerText()) : ""; }

double attrNum(const XNode &n, const char *a) { const std::string *v = n.attr(a); return v ? std::atof(v->c_str()) : std::nan(""); }

// ---- GPX ----------------------------------------------------------------------------------

GPoint gpxPoint(const XNode &n) {
  GPoint p;
  p.lat = attrNum(n, "lat");
  p.lon = attrNum(n, "lon");
  std::string e = kidText(n, "ele");
  if (!e.empty()) p.ele = std::atof(e.c_str());
  p.time = kidText(n, "time");
  if (const XNode *ex = kid(n, "extensions")) {
    std::function<void(const XNode &)> walk = [&](const XNode &x) {
      for (const auto &k : x.kids) {
        if (k.kind != XNode::Element) continue;
        if (k.elements().empty()) { std::string t = trim(k.innerText()); char *end = nullptr; double v = std::strtod(t.c_str(), &end); if (!t.empty() && end && *end == '\0') p.ext[local(k.name)] = v; }
        else walk(k);
      }
    };
    walk(*ex);
  }
  return p;
}

void parseGpx(const XNode &root, GpsDoc &d) {
  d.format = "gpx " + (root.attr("version") ? *root.attr("version") : std::string("1.1"));
  if (const XNode *m = kid(root, "metadata")) {
    for (const char *k : {"name", "desc", "time", "keywords"}) { std::string t = kidText(*m, k); if (!t.empty()) d.boxes.push_back(std::string(k) + ": " + t); }
    if (const XNode *a = kid(*m, "author")) d.boxes.push_back("author: " + trim(a->innerText()));
  }
  for (const char *k : {"name", "desc"}) { std::string t = kidText(root, k); if (!t.empty()) d.boxes.push_back(std::string(k) + ": " + t); } // GPX 1.0
  for (const auto &n : root.kids) {
    if (n.kind != XNode::Element) continue;
    std::string tag = local(n.name);
    Feature f;
    f.name = kidText(n, "name");
    f.desc = kidText(n, "desc");
    if (f.desc.empty()) f.desc = kidText(n, "cmt");
    if (tag == "wpt") { f.layer = "waypoints"; f.kind = "point"; f.parts.push_back({gpxPoint(n)}); f.style = kidText(n, "sym"); }
    else if (tag == "rte") { f.layer = "routes"; f.kind = "line"; std::vector<GPoint> v; for (const auto &k : n.kids) if (k.kind == XNode::Element && local(k.name) == "rtept") v.push_back(gpxPoint(k)); f.parts.push_back(v); }
    else if (tag == "trk") {
      f.layer = "tracks";
      f.kind = "line";
      for (const auto &s : n.kids) {
        if (s.kind != XNode::Element || local(s.name) != "trkseg") continue;
        std::vector<GPoint> v;
        for (const auto &k : s.kids) if (k.kind == XNode::Element && local(k.name) == "trkpt") v.push_back(gpxPoint(k));
        f.parts.push_back(v);
      }
    } else continue;
    if (!f.desc.empty()) d.boxes.push_back((f.name.empty() ? tag : f.name) + ": " + f.desc);
    d.features.push_back(std::move(f));
  }
}

// ---- KML ----------------------------------------------------------------------------------

std::vector<GPoint> kmlCoords(const std::string &text) {
  std::vector<GPoint> out;
  size_t p = 0;
  while (p < text.size()) {
    while (p < text.size() && std::isspace(static_cast<unsigned char>(text[p]))) p++;
    size_t e = p;
    while (e < text.size() && !std::isspace(static_cast<unsigned char>(text[e]))) e++;
    if (e > p) {
      std::string t = text.substr(p, e - p);
      GPoint g;
      double v[3] = {0, 0, std::nan("")};
      size_t s = 0;
      for (int k = 0; k < 3 && s <= t.size(); k++) { size_t c = t.find(',', s); if (c == std::string::npos) c = t.size(); if (c > s) v[k] = std::atof(t.substr(s, c - s).c_str()); s = c + 1; }
      g.lon = v[0]; g.lat = v[1]; g.ele = v[2];
      out.push_back(g);
    }
    p = e;
  }
  return out;
}

void kmlGeometry(const XNode &g, Feature &f) {
  std::string tag = local(g.name);
  if (tag == "Point") { f.kind = "point"; f.parts.push_back(kmlCoords(kidText(g, "coordinates"))); }
  else if (tag == "LineString" || tag == "LinearRing") { f.kind = f.kind.empty() ? "line" : f.kind; f.parts.push_back(kmlCoords(kidText(g, "coordinates"))); }
  else if (tag == "Polygon") {
    f.kind = "polygon";
    for (const char *b : {"outerBoundaryIs", "innerBoundaryIs"})
      for (const auto &k : g.kids) if (k.kind == XNode::Element && local(k.name) == b) if (const XNode *r = kid(k, "LinearRing")) f.parts.push_back(kmlCoords(kidText(*r, "coordinates")));
  } else if (tag == "MultiGeometry") { for (const auto &k : g.kids) if (k.kind == XNode::Element) kmlGeometry(k, f); }
  else if (tag == "Track") { // gx:Track: <when> and <gx:coord> pairs
    f.kind = "line";
    std::vector<std::string> whens;
    std::vector<GPoint> pts;
    for (const auto &k : g.kids) {
      if (k.kind != XNode::Element) continue;
      if (local(k.name) == "when") whens.push_back(trim(k.innerText()));
      if (local(k.name) == "coord") {
        std::string t = trim(k.innerText());
        GPoint p;
        double v[3] = {0, 0, std::nan("")};
        const char *c = t.c_str();
        for (int k = 0; k < 3 && *c; k++) { char *e2 = nullptr; double d = std::strtod(c, &e2); if (e2 == c) break; v[k] = d; c = e2; }
        p.lon = v[0]; p.lat = v[1]; p.ele = v[2];
        pts.push_back(p);
      }
    }
    for (size_t i = 0; i < pts.size() && i < whens.size(); i++) pts[i].time = whens[i];
    f.parts.push_back(pts);
  }
  if (f.altitudeMode.empty()) f.altitudeMode = kidText(g, "altitudeMode");
}

void parseKml(const XNode &node, GpsDoc &d, const std::string &folder) {
  for (const auto &n : node.kids) {
    if (n.kind != XNode::Element) continue;
    std::string tag = local(n.name);
    if (tag == "Document" || tag == "Folder") {
      std::string nm = kidText(n, "name");
      std::string path = folder.empty() ? nm : folder + "/" + nm;
      if (tag == "Folder") d.folders.push_back(path);
      std::string desc = kidText(n, "description");
      if (!desc.empty()) d.boxes.push_back((nm.empty() ? tag : nm) + ": " + desc);
      parseKml(n, d, tag == "Folder" ? path : folder);
    } else if (tag == "Placemark") {
      Feature f;
      f.name = kidText(n, "name");
      f.desc = kidText(n, "description");
      f.folder = folder;
      f.style = kidText(n, "styleUrl");
      for (const auto &k : n.kids) if (k.kind == XNode::Element) kmlGeometry(k, f);
      if (const XNode *ts = kid(n, "TimeStamp")) { std::string w = kidText(*ts, "when"); for (auto &p : f.parts) for (auto &q : p) if (q.time.empty()) q.time = w; }
      if (const XNode *ed = kid(n, "ExtendedData"))
        for (const auto &k : ed->kids) if (k.kind == XNode::Element && local(k.name) == "Data") f.data.push_back({k.attr("name") ? *k.attr("name") : "", kidText(k, "value")});
      f.layer = f.kind == "point" ? "placemarks" : f.kind == "polygon" ? "polygons" : "paths";
      if (!f.desc.empty()) d.boxes.push_back((f.name.empty() ? "placemark" : f.name) + ": " + f.desc);
      d.features.push_back(std::move(f));
    } else if ((tag == "LookAt" || tag == "Camera") && d.camera.empty()) {
      d.camera["kind"] = Value(tag);
      for (const char *k : {"longitude", "latitude", "altitude", "heading", "tilt", "range", "roll"}) { std::string t = kidText(n, k); if (!t.empty()) d.camera[k] = Value(std::atof(t.c_str())); }
      d.camera["altitude_mode"] = Value(kidText(n, "altitudeMode"));
    } else if (tag == "kml" || tag == "NetworkLinkControl") parseKml(n, d, folder);
  }
}

bool openGps(const std::string &file, GpsDoc &d, std::string &err) {
  std::string bytes;
  if (!readSource(file, bytes, err)) return false;
  if (bytes.size() > 4 && bytes.compare(0, 2, "PK") == 0) { // KMZ
    ZipReader z;
    if (!z.open(bytes, err)) return false;
    std::string name;
    for (const auto &e : z.entries) if (lower(extensionOf(e.name)) == "kml" && (name.empty() || e.name == "doc.kml")) name = e.name;
    if (name.empty()) { err = "the KMZ holds no .kml file"; return false; }
    std::string kml;
    if (!z.read(name, kml, err)) return false;
    bytes = kml;
  }
  std::string text;
  if (!decodeText(bytes, "utf-8", text, err)) return false;
  XNode doc;
  if (!parseXml(text, doc, err)) return false;
  const XNode *root = rootElement(doc);
  if (!root) { err = "the file has no XML root element"; return false; }
  std::string r = local(root->name);
  if (r == "gpx") parseGpx(*root, d);
  else if (r == "kml") { d.format = "kml"; parseKml(*root, d, ""); }
  else { err = "not a GPX / KML file (the root element is <" + root->name + ">)"; return false; }
  for (const auto &f : d.features)
    for (const auto &p : f.parts)
      for (const auto &q : p)
        if (!(q.lat >= -90 && q.lat <= 90 && q.lon >= -180 && q.lon <= 180)) { err = "a coordinate is outside WGS84 bounds (lat " + numberText(q.lat) + ", lon " + numberText(q.lon) + ")"; return false; }
  return true;
}

double haversineKm(const GPoint &a, const GPoint &b) {
  const double R = 6371.0088, rad = 3.14159265358979323846 / 180;
  double dl = (b.lat - a.lat) * rad, dn = (b.lon - a.lon) * rad;
  double h = std::sin(dl / 2) * std::sin(dl / 2) + std::cos(a.lat * rad) * std::cos(b.lat * rad) * std::sin(dn / 2) * std::sin(dn / 2);
  return 2 * R * std::asin(std::min(1.0, std::sqrt(h)));
}

// unified point table: lat lon ele time name desc layer feature segment (+ extension columns)
Table pointTable(const GpsDoc &d, const std::string &layer, const std::vector<double> &bbox, const std::vector<std::string> &trange) {
  Table t;
  t.cols = {"lat", "lon", "ele", "time", "name", "desc", "layer", "feature", "segment"};
  std::vector<std::string> extCols;
  for (const auto &f : d.features) for (const auto &p : f.parts) for (const auto &q : p) for (const auto &kv : q.ext) if (std::find(extCols.begin(), extCols.end(), kv.first) == extCols.end()) extCols.push_back(kv.first);
  for (const auto &e : extCols) t.cols.push_back(e);
  for (size_t fi = 0; fi < d.features.size(); fi++) {
    const Feature &f = d.features[fi];
    if (!layer.empty() && f.layer != layer && f.layer != layer + "s") continue;
    for (size_t si = 0; si < f.parts.size(); si++)
      for (const auto &q : f.parts[si]) {
        if (bbox.size() == 4 && (q.lon < std::min(bbox[0], bbox[2]) || q.lon > std::max(bbox[0], bbox[2]) || q.lat < std::min(bbox[1], bbox[3]) || q.lat > std::max(bbox[1], bbox[3]))) continue;
        if (trange.size() == 2 && (q.time.empty() || q.time < trange[0] || q.time > trange[1])) continue;
        std::vector<Value> row = {Value(q.lat), Value(q.lon), Value(q.ele), q.time.empty() ? Value(std::nan("")) : Value(q.time), Value(f.name), Value(f.desc),
                                  Value(f.layer), Value(static_cast<double>(fi)), Value(static_cast<double>(si))};
        for (const auto &e : extCols) { auto it = q.ext.find(e); row.push_back(Value(it == q.ext.end() ? std::nan("") : it->second)); }
        t.rows.push_back(std::move(row));
      }
  }
  return t;
}

bool layerOk(const std::string &fmt, std::string &layer, std::string &err) {
  layer = lower(layer);
  if (layer.empty()) return true;
  static const std::vector<std::string> gpx = {"tracks", "waypoints", "routes", "track", "waypoint", "route"}, kml = {"placemarks", "paths", "polygons", "placemark", "path", "polygon"};
  const auto &ok = fmt == "gpx" ? gpx : kml;
  if (std::find(ok.begin(), ok.end(), layer) == ok.end()) {
    err = fmt == "gpx" ? "layer must be \"tracks\", \"waypoints\" or \"routes\"" : "layer must be \"placemarks\", \"paths\" or \"polygons\"";
    return false;
  }
  if (layer.back() != 's') layer += "s";
  return true;
}

// read_<fmt>(file, layer, bbox, time_range, box)
void readGps(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  GpsDoc d;
  if (!openGps(file, d, err)) return ctx.fail(err);
  std::string layer = optText(a[1]);
  if (!layerOk(fmt, layer, err)) return ctx.fail(err);
  std::vector<double> bbox = optNumbers(a[2]);
  if (given(a[2]) && bbox.size() != 4) return ctx.fail("bbox must be [lon1, lat1, lon2, lat2]");
  std::vector<std::string> tr = optTextList(a[3]);
  if (given(a[3]) && tr.size() != 2) return ctx.fail("time_range must be [t1, t2] (ISO 8601 text, e.g. \"2026-05-01T06:00:00Z\")");
  Table t = pointTable(d, layer, bbox, tr);
  out.push_back(tableData(t));
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(t.cols);
    info["rows"] = Value(static_cast<double>(t.rows.size()));
    info["format"] = Value(d.format);
    info["boxes"] = optBool(a[4], true) ? textList(d.boxes) : textList({});
    info["camera"] = Value(d.camera);
    out.push_back(makeObject("NcReadInfo", info));
  }
  ev.ok = true;
}

Value featureObject(const Feature &f, const std::string &cls) {
  Fields o;
  std::vector<double> lat, lon, ele;
  std::vector<std::string> time;
  std::vector<Value> segs;
  std::vector<std::vector<double>> coords;
  double km = 0;
  for (const auto &p : f.parts) {
    std::vector<std::vector<double>> seg;
    for (size_t i = 0; i < p.size(); i++) {
      lat.push_back(p[i].lat); lon.push_back(p[i].lon); ele.push_back(p[i].ele); time.push_back(p[i].time);
      seg.push_back({p[i].lon, p[i].lat, p[i].ele});
      coords.push_back({p[i].lon, p[i].lat, p[i].ele});
      if (i) km += haversineKm(p[i - 1], p[i]);
    }
    segs.push_back(numpy::makeMatrix(seg));
  }
  o["name"] = Value(f.name);
  o["desc"] = Value(f.desc);
  o["lat"] = numberList(lat);
  o["lon"] = numberList(lon);
  o["ele"] = numberList(ele);
  o["time"] = textList(time);
  o["coords"] = numpy::makeMatrix(coords);
  o["segments"] = Value(std::move(segs));
  o["distance_km"] = Value(km);
  o["type"] = Value(f.kind);
  if (cls == "NcPlacemark") {
    o["folder"] = Value(f.folder);
    o["style"] = Value(f.style);
    o["altitude_mode"] = Value(f.altitudeMode.empty() ? "clampToGround" : f.altitudeMode);
    Fields data;
    for (const auto &kv : f.data) data[kv.first] = Value(kv.second);
    o["data"] = Value(data);
  }
  return makeObject(cls, o);
}

Value loadGps(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  GpsDoc d;
  if (!openGps(file, d, err)) { ctx.fail(err); return Value(0.0); }
  Fields f;
  Table all = pointTable(d, "", {}, {});
  f["table"] = tableObject(all);
  std::vector<Value> tracks, wpts, routes, marks;
  Fields folders;
  for (const auto &x : d.features) {
    if (x.layer == "tracks") tracks.push_back(featureObject(x, "NcTrack"));
    else if (x.layer == "routes") routes.push_back(featureObject(x, "NcTrack"));
    else if (x.layer == "waypoints") wpts.push_back(featureObject(x, "NcTrack"));
    else marks.push_back(featureObject(x, "NcPlacemark"));
  }
  for (const auto &path : d.folders) {
    std::vector<Value> inside;
    for (const auto &x : d.features) if (x.folder == path) inside.push_back(Value(x.name));
    folders[path] = makeObject("NcFolder", {{"name", Value(path)}, {"placemarks", Value(std::move(inside))}});
  }
  if (fmt == "gpx" || d.format.rfind("gpx", 0) == 0) {
    f["tracks"] = Value(std::move(tracks));
    f["routes"] = Value(std::move(routes));
    Table wt = pointTable(d, "waypoints", {}, {});
    f["waypoints"] = tableObject(wt);
    Fields ext;
    for (size_t c = 9; c < all.cols.size(); c++) ext[fieldName(all.cols[c])] = tableColumn(all, c);
    f["extensions"] = Value(ext);
  } else {
    f["placemarks"] = Value(std::move(marks));
    f["folders"] = Value(folders);
    f["camera"] = Value(d.camera);
  }
  f["boxes"] = textList(d.boxes);
  f["format"] = Value(d.format);
  f["file"] = Value(file);
  ev.ok = true;
  return makeObject(fmt == "gpx" ? "NcGpx" : "NcKml", f);
}

// ---- writing ---------------------------------------------------------------------------------

struct OutPts { std::vector<double> lat, lon, ele; std::vector<std::string> time, name, desc; };

bool gather(const std::vector<Value> &a, OutPts &o, std::string &err) {
  const Value &data = a[1];
  if (given(data)) {
    Table t;
    const Value *src = &data;
    if (isObjectOf(data, "NcGpx") || isObjectOf(data, "NcKml")) src = field(data, "table");
    if (!src || !valueToTable(*src, t, err, true)) return false;
    auto col = [&](std::initializer_list<const char *> names) -> int { for (const char *n : names) for (size_t c = 0; c < t.cols.size(); c++) if (lower(t.cols[c]) == n) return static_cast<int>(c); return -1; };
    int la = col({"lat", "latitude", "y"}), lo = col({"lon", "lng", "longitude", "x"}), el = col({"ele", "elevation", "alt", "altitude", "z"}), ti = col({"time", "timestamp", "when"}),
        nm = col({"name"}), de = col({"desc", "description"});
    if (la < 0 || lo < 0) { err = "the data needs lat and lon columns"; return false; }
    auto num = [](const Value &v) { return v.isText ? std::atof(v.text().c_str()) : v.number; };
    for (const auto &r : t.rows) {
      o.lat.push_back(num(r[static_cast<size_t>(la)]));
      o.lon.push_back(num(r[static_cast<size_t>(lo)]));
      o.ele.push_back(el >= 0 ? num(r[static_cast<size_t>(el)]) : std::nan(""));
      o.time.push_back(ti >= 0 && r[static_cast<size_t>(ti)].isText ? r[static_cast<size_t>(ti)].text() : "");
      o.name.push_back(nm >= 0 && r[static_cast<size_t>(nm)].isText ? r[static_cast<size_t>(nm)].text() : "");
      o.desc.push_back(de >= 0 && r[static_cast<size_t>(de)].isText ? r[static_cast<size_t>(de)].text() : "");
    }
  } else {
    o.lat = optNumbers(a[2]);
    o.lon = optNumbers(a[3]);
    o.ele = optNumbers(a[4]);
    if (o.lat.empty() || o.lon.empty()) { err = "give gps_data (a table with lat / lon columns) or lat= and lon= vectors"; return false; }
    if (o.ele.empty()) o.ele.assign(o.lat.size(), std::nan(""));
    o.time.assign(o.lat.size(), "");
    o.name.assign(o.lat.size(), "");
    o.desc.assign(o.lat.size(), "");
  }
  if (o.lat.size() != o.lon.size() || o.ele.size() != o.lat.size()) { err = "lat, lon and ele must have the same length (" + std::to_string(o.lat.size()) + ", " + std::to_string(o.lon.size()) + ", " + std::to_string(o.ele.size()) + ")"; return false; }
  for (size_t i = 0; i < o.lat.size(); i++)
    if (!(o.lat[i] >= -90 && o.lat[i] <= 90 && o.lon[i] >= -180 && o.lon[i] <= 180)) { err = "point " + std::to_string(i + 1) + " is outside WGS84 bounds (lat " + numberText(o.lat[i]) + ", lon " + numberText(o.lon[i]) + ")"; return false; }
  return true;
}

std::string x(const std::string &s) { return escapeXml(s, false); }
std::string nf(double v) { char b[32]; std::snprintf(b, sizeof b, "%.8f", v); std::string s = b; while (s.back() == '0') s.pop_back(); if (s.back() == '.') s.pop_back(); return s; }

// save_<fmt>(file, gps_data, lat, lon, ele, mode_type, name, color, boxes, kmz)
Value saveGps(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  OutPts o;
  if (!gather(a, o, err)) return fail(err);
  std::string mode = lower(optText(a[5], fmt == "gpx" ? "track" : "line"));
  std::string name = optText(a[6]), color = optText(a[7]);
  std::vector<std::string> boxes = optTextList(a[8]);
  bool kmz = optBool(a[9], false);
  std::string doc;
  if (fmt == "gpx") {
    if (kmz) return fail("kmz=true is for save_kml");
    if (mode != "track" && mode != "waypoint" && mode != "route") return fail("mode_type must be \"track\", \"waypoint\" or \"route\"");
    doc = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"NC save_gpx\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n";
    doc += "  <metadata>\n";
    if (!name.empty()) doc += "    <name>" + x(name) + "</name>\n";
    if (!boxes.empty()) { std::string j; for (auto &b : boxes) j += (j.empty() ? "" : "\n") + b; doc += "    <desc>" + x(j) + "</desc>\n"; }
    double mnla = 90, mxla = -90, mnlo = 180, mxlo = -180;
    for (size_t i = 0; i < o.lat.size(); i++) { mnla = std::min(mnla, o.lat[i]); mxla = std::max(mxla, o.lat[i]); mnlo = std::min(mnlo, o.lon[i]); mxlo = std::max(mxlo, o.lon[i]); }
    if (!o.lat.empty()) doc += "    <bounds minlat=\"" + nf(mnla) + "\" minlon=\"" + nf(mnlo) + "\" maxlat=\"" + nf(mxla) + "\" maxlon=\"" + nf(mxlo) + "\"/>\n";
    doc += "  </metadata>\n";
    auto pt = [&](const char *tag, size_t i, const std::string &ind) {
      std::string s = ind + "<" + tag + " lat=\"" + nf(o.lat[i]) + "\" lon=\"" + nf(o.lon[i]) + "\">";
      if (!std::isnan(o.ele[i])) s += "<ele>" + nf(o.ele[i]) + "</ele>";
      if (!o.time[i].empty()) s += "<time>" + x(o.time[i]) + "</time>";
      if (!o.name[i].empty()) s += "<name>" + x(o.name[i]) + "</name>";
      if (!o.desc[i].empty()) s += "<desc>" + x(o.desc[i]) + "</desc>";
      return s + "</" + tag + ">\n";
    };
    std::string ext = color.empty() ? "" : "    <extensions><color>" + x(color) + "</color></extensions>\n";
    if (mode == "waypoint") for (size_t i = 0; i < o.lat.size(); i++) doc += pt("wpt", i, "  ");
    else if (mode == "route") { doc += "  <rte>\n" + (name.empty() ? "" : "    <name>" + x(name) + "</name>\n") + ext; for (size_t i = 0; i < o.lat.size(); i++) doc += pt("rtept", i, "    "); doc += "  </rte>\n"; }
    else { doc += "  <trk>\n" + (name.empty() ? "" : "    <name>" + x(name) + "</name>\n") + ext + "    <trkseg>\n"; for (size_t i = 0; i < o.lat.size(); i++) doc += pt("trkpt", i, "      "); doc += "    </trkseg>\n  </trk>\n"; }
    doc += "</gpx>\n";
  } else {
    if (mode != "line" && mode != "point" && mode != "polygon") return fail("mode_type must be \"line\", \"point\" or \"polygon\"");
    std::string kcol = "ff336600";
    if (!color.empty()) {
      std::string c = color[0] == '#' ? color.substr(1) : color;
      if (c.size() != 6 && c.size() != 8) return fail("color must be \"#RRGGBB\" or \"#RRGGBBAA\"");
      std::string aa = c.size() == 8 ? c.substr(6, 2) : "ff";
      kcol = aa + c.substr(4, 2) + c.substr(2, 2) + c.substr(0, 2);
    }
    auto coord = [&](size_t i) { return nf(o.lon[i]) + "," + nf(o.lat[i]) + (std::isnan(o.ele[i]) ? "" : "," + nf(o.ele[i])); };
    bool has3d = std::any_of(o.ele.begin(), o.ele.end(), [](double v) { return !std::isnan(v); });
    std::string alt = has3d ? "<altitudeMode>absolute</altitudeMode>" : "";
    doc = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n<Document>\n";
    if (!name.empty()) doc += "  <name>" + x(name) + "</name>\n";
    if (!boxes.empty()) { std::string j; for (auto &b : boxes) j += (j.empty() ? "" : "<br/>") + x(b); doc += "  <description><![CDATA[" + j + "]]></description>\n"; }
    doc += "  <Style id=\"nc\"><LineStyle><color>" + kcol + "</color><width>3</width></LineStyle><PolyStyle><color>7f" + kcol.substr(2) + "</color></PolyStyle><IconStyle><color>" + kcol + "</color></IconStyle></Style>\n";
    if (mode == "point") {
      for (size_t i = 0; i < o.lat.size(); i++) {
        doc += "  <Placemark>";
        doc += "<name>" + x(o.name[i].empty() ? name + (name.empty() ? "" : " ") + std::to_string(i + 1) : o.name[i]) + "</name>";
        if (!o.desc[i].empty()) doc += "<description>" + x(o.desc[i]) + "</description>";
        if (!o.time[i].empty()) doc += "<TimeStamp><when>" + x(o.time[i]) + "</when></TimeStamp>";
        doc += "<styleUrl>#nc</styleUrl><Point>" + alt + "<coordinates>" + coord(i) + "</coordinates></Point></Placemark>\n";
      }
    } else {
      std::string cs;
      for (size_t i = 0; i < o.lat.size(); i++) cs += (i ? " " : "") + coord(i);
      if (mode == "polygon" && !o.lat.empty() && (o.lat.front() != o.lat.back() || o.lon.front() != o.lon.back())) cs += " " + coord(0);
      doc += "  <Placemark><name>" + x(name.empty() ? "path" : name) + "</name><styleUrl>#nc</styleUrl>";
      if (!o.time.empty() && !o.time.front().empty()) doc += "<TimeSpan><begin>" + x(o.time.front()) + "</begin><end>" + x(o.time.back()) + "</end></TimeSpan>";
      if (mode == "line") doc += "<LineString><tessellate>1</tessellate>" + alt + "<coordinates>" + cs + "</coordinates></LineString>";
      else doc += "<Polygon>" + alt + "<outerBoundaryIs><LinearRing><coordinates>" + cs + "</coordinates></LinearRing></outerBoundaryIs></Polygon>";
      doc += "</Placemark>\n";
    }
    doc += "</Document>\n</kml>\n";
    if (kmz) { ZipWriter z; z.add("doc.kml", doc); doc = z.finish(6); }
  }
  if (!writeFile(file, doc, false, err)) return fail(err);
  ev.ok = true;
  return Value(static_cast<double>(doc.size()));
}

} // namespace

void registerGps(Registry &reg) {
  for (const char *ext : {"gpx", "kml"}) {
    const std::string e = ext;
    std::string layers = e == "gpx" ? "tracks / waypoints / routes" : "placemarks / paths / polygons";
    addMulti(reg, "read_" + e, "file, layer=\"\", bbox=\"\", time_range=\"\", box=true",
             "read the points of a ." + e + (e == "kml" ? " / .kmz" : "") + " as a table (lat, lon, ele, time, name, desc, ...); layer = " + layers, "gpxpy.parse / fastkml", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readGps(e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file",
          e == "gpx" ? "load a GPX file (D.table, D.tracks, D.waypoints, D.routes, D.extensions, D.boxes)" : "load a KML / KMZ file (D.table, D.placemarks, D.folders, D.camera, D.boxes)",
          "gpxpy.parse / fastkml", [e](const std::vector<Value> &a, CallContext &ctx) { return loadGps(e, a, ctx); });
    addFn(reg, "save_" + e,
          std::string("file, gps_data=\"\", lat=\"\", lon=\"\", ele=\"\", mode_type=\"") + (e == "gpx" ? "track" : "line") + "\", name=\"\", color=\"\", boxes=\"\", kmz=false",
          e == "gpx" ? "write a GPX 1.1 track / route / waypoints (WGS84)" : "write a KML 2.2 line / points / polygon (kmz=true zips it)", "gpxpy / simplekml",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveGps(e, a, ctx); });
  }
}

} // namespace io
} // namespace nc
