// XML / HTML parsing, XPath subset, CSS selectors and the XML writer - see
// io_markup.h.
#include <algorithm>
#include <cstring>
#include <functional>
#include <unordered_map>

#include "io_markup.h"

namespace nc {
namespace io {

const std::string *XNode::attr(const std::string &n) const {
  for (const auto &a : attrs)
    if (a.first == n)
      return &a.second;
  return nullptr;
}

std::string XNode::innerText() const {
  if (kind == Text || kind == CData)
    return text;
  std::string out;
  for (const auto &k : kids)
    if (k.kind == Text || k.kind == CData || k.kind == Element)
      out += k.innerText();
  return out;
}

std::string XNode::ownText() const {
  std::string out;
  for (const auto &k : kids)
    if (k.kind == Text || k.kind == CData)
      out += k.text;
  return out;
}

std::vector<const XNode *> XNode::elements() const {
  std::vector<const XNode *> out;
  for (const auto &k : kids)
    if (k.kind == Element)
      out.push_back(&k);
  return out;
}

const XNode *rootElement(const XNode &doc) {
  for (const auto &k : doc.kids)
    if (k.kind == XNode::Element)
      return &k;
  return nullptr;
}

// ---- entities ---------------------------------------------------------------

namespace {

void putUtf8(std::string &out, uint32_t cp) {
  if (cp < 0x80) {
    out.push_back(static_cast<char>(cp));
  } else if (cp < 0x800) {
    out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else if (cp < 0x10000) {
    out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  } else {
    out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
    out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
  }
}

const std::unordered_map<std::string, uint32_t> &namedEntities() {
  static const std::unordered_map<std::string, uint32_t> m = {
      {"lt", '<'},       {"gt", '>'},       {"amp", '&'},      {"quot", '"'},     {"apos", '\''},
      {"nbsp", 0xA0},    {"copy", 0xA9},    {"reg", 0xAE},     {"deg", 0xB0},     {"plusmn", 0xB1},
      {"micro", 0xB5},   {"middot", 0xB7},  {"times", 0xD7},   {"divide", 0xF7},  {"ndash", 0x2013},
      {"mdash", 0x2014}, {"lsquo", 0x2018}, {"rsquo", 0x2019}, {"ldquo", 0x201C}, {"rdquo", 0x201D},
      {"hellip", 0x2026}, {"euro", 0x20AC}, {"pound", 0xA3},   {"yen", 0xA5},     {"cent", 0xA2},
      {"sect", 0xA7},    {"para", 0xB6},    {"laquo", 0xAB},   {"raquo", 0xBB},   {"bull", 0x2022},
      {"trade", 0x2122}, {"larr", 0x2190},  {"rarr", 0x2192},  {"uarr", 0x2191},  {"darr", 0x2193},
      {"le", 0x2264},    {"ge", 0x2265},    {"ne", 0x2260},    {"infin", 0x221E}, {"minus", 0x2212},
      {"sup2", 0xB2},    {"sup3", 0xB3},    {"frac12", 0xBD},  {"frac14", 0xBC},  {"alpha", 0x3B1},
      {"beta", 0x3B2},   {"gamma", 0x3B3},  {"delta", 0x3B4},  {"pi", 0x3C0},     {"sigma", 0x3C3},
      {"mu", 0x3BC},     {"omega", 0x3C9},  {"theta", 0x3B8},  {"lambda", 0x3BB}, {"Delta", 0x394},
      {"Omega", 0x3A9},  {"ensp", 0x2002},  {"emsp", 0x2003},  {"thinsp", 0x2009}, {"zwj", 0x200D}};
  return m;
}

std::string decodeEntities(const std::string &s) {
  if (s.find('&') == std::string::npos)
    return s;
  std::string out;
  out.reserve(s.size());
  for (size_t i = 0; i < s.size(); i++) {
    if (s[i] != '&') {
      out.push_back(s[i]);
      continue;
    }
    size_t semi = s.find(';', i + 1);
    if (semi == std::string::npos || semi - i > 12) {
      out.push_back('&');
      continue;
    }
    std::string name = s.substr(i + 1, semi - i - 1);
    if (!name.empty() && name[0] == '#') {
      uint32_t cp = (name.size() > 1 && (name[1] == 'x' || name[1] == 'X'))
                        ? static_cast<uint32_t>(std::strtoul(name.c_str() + 2, nullptr, 16))
                        : static_cast<uint32_t>(std::strtoul(name.c_str() + 1, nullptr, 10));
      putUtf8(out, cp);
      i = semi;
      continue;
    }
    auto it = namedEntities().find(name);
    if (it == namedEntities().end()) {
      out.push_back('&');
      continue;
    }
    putUtf8(out, it->second);
    i = semi;
  }
  return out;
}

bool isNameChar(char c) {
  return std::isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '-' || c == '.' || c == ':' ||
         static_cast<unsigned char>(c) >= 0x80;
}

size_t lineAt(const std::string &s, size_t i) {
  return 1 + static_cast<size_t>(std::count(s.begin(), s.begin() + std::min(i, s.size()), '\n'));
}

// <tag a="1" b='2' c=3 d> - the attribute list after the name. Returns the
// position after '>' (selfClose set for '/>'). HTML mode allows bare and
// unquoted attributes.
size_t parseAttrs(const std::string &s, size_t i, bool html,
                  std::vector<std::pair<std::string, std::string>> &attrs, bool &selfClose,
                  std::string &err) {
  selfClose = false;
  for (;;) {
    while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i])))
      i++;
    if (i >= s.size()) {
      err = "a tag is never closed";
      return std::string::npos;
    }
    if (s[i] == '>')
      return i + 1;
    if (s[i] == '/' && i + 1 < s.size() && s[i + 1] == '>') {
      selfClose = true;
      return i + 2;
    }
    size_t b = i;
    while (i < s.size() && !std::isspace(static_cast<unsigned char>(s[i])) && s[i] != '=' &&
           s[i] != '>' && !(s[i] == '/' && i + 1 < s.size() && s[i + 1] == '>'))
      i++;
    std::string name = s.substr(b, i - b);
    if (name.empty()) {
      if (html) {
        i++;
        continue;
      }
      err = "bad attribute (line " + std::to_string(lineAt(s, i)) + ")";
      return std::string::npos;
    }
    if (html)
      name = lower(name);
    while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i])))
      i++;
    std::string value;
    if (i < s.size() && s[i] == '=') {
      i++;
      while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i])))
        i++;
      if (i < s.size() && (s[i] == '"' || s[i] == '\'')) {
        char q = s[i];
        size_t e = s.find(q, i + 1);
        if (e == std::string::npos) {
          err = "an attribute value is never closed (line " + std::to_string(lineAt(s, i)) + ")";
          return std::string::npos;
        }
        value = s.substr(i + 1, e - i - 1);
        i = e + 1;
      } else if (html) {
        size_t vb = i;
        while (i < s.size() && !std::isspace(static_cast<unsigned char>(s[i])) && s[i] != '>')
          i++;
        value = s.substr(vb, i - vb);
      } else {
        err = "attribute '" + name + "' needs a quoted value (line " + std::to_string(lineAt(s, i)) + ")";
        return std::string::npos;
      }
    } else if (!html) {
      err = "attribute '" + name + "' has no value (line " + std::to_string(lineAt(s, i)) + ")";
      return std::string::npos;
    }
    attrs.emplace_back(name, decodeEntities(value));
  }
}

} // namespace

std::string escapeXml(const std::string &s, bool attr) {
  std::string out;
  out.reserve(s.size());
  for (char c : s) {
    switch (c) {
      case '<': out += "&lt;"; break;
      case '>': out += "&gt;"; break;
      case '&': out += "&amp;"; break;
      case '"': out += attr ? "&quot;" : "\""; break;
      default: out.push_back(c);
    }
  }
  return out;
}

// ---- XML parser -------------------------------------------------------------

bool parseXml(const std::string &s, XNode &doc, std::string &err) {
  doc = XNode();
  doc.kind = XNode::Document;
  std::vector<XNode *> stack{&doc};
  size_t i = (s.size() >= 3 && s.compare(0, 3, "\xEF\xBB\xBF") == 0) ? 3 : 0;
  int roots = 0;
  while (i < s.size()) {
    if (s[i] != '<') {
      size_t e = s.find('<', i);
      if (e == std::string::npos)
        e = s.size();
      std::string t = s.substr(i, e - i);
      if (stack.size() > 1) {
        if (trim(t).size()) {
          XNode n;
          n.kind = XNode::Text;
          n.text = decodeEntities(t);
          stack.back()->kids.push_back(std::move(n));
        }
      } else if (!trim(t).empty()) {
        err = "text outside the root element (line " + std::to_string(lineAt(s, i)) + ")";
        return false;
      }
      i = e;
      continue;
    }
    if (s.compare(i, 4, "<!--") == 0) {
      size_t e = s.find("-->", i + 4);
      if (e == std::string::npos) {
        err = "a comment is never closed (line " + std::to_string(lineAt(s, i)) + ")";
        return false;
      }
      XNode n;
      n.kind = XNode::Comment;
      n.text = s.substr(i + 4, e - i - 4);
      stack.back()->kids.push_back(std::move(n));
      i = e + 3;
      continue;
    }
    if (s.compare(i, 9, "<![CDATA[") == 0) {
      size_t e = s.find("]]>", i + 9);
      if (e == std::string::npos) {
        err = "a CDATA section is never closed";
        return false;
      }
      XNode n;
      n.kind = XNode::CData;
      n.text = s.substr(i + 9, e - i - 9);
      stack.back()->kids.push_back(std::move(n));
      i = e + 3;
      continue;
    }
    if (s.compare(i, 2, "<?") == 0) {
      size_t e = s.find("?>", i + 2);
      if (e == std::string::npos) {
        err = "a processing instruction is never closed";
        return false;
      }
      XNode n;
      n.kind = XNode::PI;
      std::string body = s.substr(i + 2, e - i - 2);
      size_t sp = body.find_first_of(" \t\r\n");
      n.name = body.substr(0, sp);
      n.text = sp == std::string::npos ? "" : trim(body.substr(sp));
      stack.back()->kids.push_back(std::move(n));
      i = e + 2;
      continue;
    }
    if (s.compare(i, 9, "<!DOCTYPE") == 0 || s.compare(i, 9, "<!doctype") == 0) {
      int depth = 0;
      size_t e = i;
      for (; e < s.size(); e++) {
        if (s[e] == '[') depth++;
        else if (s[e] == ']') depth--;
        else if (s[e] == '>' && depth <= 0) break;
      }
      XNode n;
      n.kind = XNode::Doctype;
      n.text = s.substr(i + 2, e - i - 2);
      doc.kids.push_back(std::move(n));
      i = e + 1;
      continue;
    }
    if (s.compare(i, 2, "</") == 0) {
      size_t e = s.find('>', i);
      if (e == std::string::npos) {
        err = "a closing tag is never finished";
        return false;
      }
      std::string name = trim(s.substr(i + 2, e - i - 2));
      if (stack.size() <= 1 || stack.back()->name != name) {
        err = "closing tag </" + name + "> does not match <" +
              (stack.size() > 1 ? stack.back()->name : std::string("(none)")) + "> (line " +
              std::to_string(lineAt(s, i)) + ")";
        return false;
      }
      stack.pop_back();
      i = e + 1;
      continue;
    }
    size_t b = i + 1;
    size_t j = b;
    while (j < s.size() && isNameChar(s[j]))
      j++;
    if (j == b) {
      err = "'<' that starts no tag (line " + std::to_string(lineAt(s, i)) + ") - write &lt;";
      return false;
    }
    XNode n;
    n.kind = XNode::Element;
    n.name = s.substr(b, j - b);
    bool selfClose = false;
    size_t after = parseAttrs(s, j, false, n.attrs, selfClose, err);
    if (after == std::string::npos)
      return false;
    if (stack.size() == 1 && ++roots > 1) {
      err = "more than one root element (<" + n.name + "> at line " + std::to_string(lineAt(s, i)) +
            ") - an XML file has exactly one";
      return false;
    }
    stack.back()->kids.push_back(std::move(n));
    if (!selfClose)
      stack.push_back(&stack.back()->kids.back());
    i = after;
  }
  if (stack.size() > 1) {
    err = "<" + stack.back()->name + "> is never closed";
    return false;
  }
  if (!roots) {
    err = "the document has no root element";
    return false;
  }
  return true;
}

// ---- HTML parser ------------------------------------------------------------

namespace {
bool isVoid(const std::string &t) {
  static const char *v[] = {"area", "base", "br",   "col",   "embed", "hr",    "img",
                            "input", "link", "meta", "param", "source", "track", "wbr"};
  for (const char *x : v)
    if (t == x)
      return true;
  return false;
}

// Opening `tag` implicitly closes these open elements first.
bool closesImplicitly(const std::string &open, const std::string &tag) {
  if (tag == "p" || tag == "div" || tag == "table" || tag == "ul" || tag == "ol" || tag == "h1" ||
      tag == "h2" || tag == "h3" || tag == "h4" || tag == "pre" || tag == "section" || tag == "aside")
    return open == "p";
  if (tag == "li")
    return open == "li";
  if (tag == "td" || tag == "th")
    return open == "td" || open == "th";
  if (tag == "tr")
    return open == "tr" || open == "td" || open == "th";
  if (tag == "thead" || tag == "tbody" || tag == "tfoot")
    return open == "thead" || open == "tbody" || open == "tfoot" || open == "tr" || open == "td" ||
           open == "th";
  if (tag == "option")
    return open == "option";
  if (tag == "dt" || tag == "dd")
    return open == "dt" || open == "dd";
  return false;
}
} // namespace

void parseHtml(const std::string &s, XNode &doc) {
  doc = XNode();
  doc.kind = XNode::Document;
  std::vector<XNode *> stack{&doc};
  size_t i = 0;
  auto addText = [&](const std::string &t) {
    if (t.empty())
      return;
    XNode n;
    n.kind = XNode::Text;
    n.text = decodeEntities(t);
    stack.back()->kids.push_back(std::move(n));
  };
  while (i < s.size()) {
    if (s[i] != '<') {
      size_t e = s.find('<', i);
      if (e == std::string::npos)
        e = s.size();
      addText(s.substr(i, e - i));
      i = e;
      continue;
    }
    if (s.compare(i, 4, "<!--") == 0) {
      size_t e = s.find("-->", i + 4);
      if (e == std::string::npos)
        e = s.size();
      XNode n;
      n.kind = XNode::Comment;
      n.text = s.substr(i + 4, e - i - 4);
      stack.back()->kids.push_back(std::move(n));
      i = std::min(s.size(), e + 3);
      continue;
    }
    if (s.compare(i, 2, "<!") == 0 || s.compare(i, 2, "<?") == 0) {
      size_t e = s.find('>', i);
      i = e == std::string::npos ? s.size() : e + 1;
      continue;
    }
    if (s.compare(i, 2, "</") == 0) {
      size_t e = s.find('>', i);
      if (e == std::string::npos)
        break;
      std::string name = lower(trim(s.substr(i + 2, e - i - 2)));
      i = e + 1;
      for (size_t k = stack.size(); k-- > 1;)
        if (stack[k]->name == name) {
          stack.resize(k);
          break;
        }
      continue;
    }
    size_t b = i + 1, j = b;
    while (j < s.size() && isNameChar(s[j]))
      j++;
    if (j == b) {
      addText("<");
      i++;
      continue;
    }
    XNode n;
    n.kind = XNode::Element;
    n.name = lower(s.substr(b, j - b));
    bool selfClose = false;
    std::string err;
    size_t after = parseAttrs(s, j, true, n.attrs, selfClose, err);
    if (after == std::string::npos) {
      i = s.size();
      break;
    }
    while (stack.size() > 1 && closesImplicitly(stack.back()->name, n.name))
      stack.pop_back();
    const std::string tag = n.name;
    stack.back()->kids.push_back(std::move(n));
    XNode *el = &stack.back()->kids.back();
    i = after;
    if (tag == "script" || tag == "style" || tag == "textarea" || tag == "title") {
      std::string close = "</" + tag;
      size_t e = i;
      for (;;) {
        e = s.find("</", e);
        if (e == std::string::npos || lower(s.substr(e, close.size())) == close)
          break;
        e += 2;
      }
      if (e == std::string::npos)
        e = s.size();
      XNode t;
      t.kind = XNode::Text;
      t.text = (tag == "script" || tag == "style") ? s.substr(i, e - i) : decodeEntities(s.substr(i, e - i));
      el->kids.push_back(std::move(t));
      size_t gt = s.find('>', e);
      i = gt == std::string::npos ? s.size() : gt + 1;
      continue;
    }
    if (!selfClose && !isVoid(tag))
      stack.push_back(el);
  }
}

// ---- XPath ------------------------------------------------------------------

namespace {

struct Ctx {
  std::unordered_map<const XNode *, const XNode *> parent;
  void index(const XNode &n) {
    for (const auto &k : n.kids) {
      parent[&k] = &n;
      index(k);
    }
  }
};

void descendants(const XNode *n, std::vector<const XNode *> &out) {
  for (const auto &k : n->kids)
    if (k.kind == XNode::Element) {
      out.push_back(&k);
      descendants(&k, out);
    }
}

std::string itemValue(const XNode *n, const std::string &what) {
  // what: "@a", "text()", "name", "."
  if (what.empty() || what == "." )
    return trim(n->innerText());
  if (what[0] == '@') {
    const std::string *a = n->attr(what.substr(1));
    return a ? *a : std::string();
  }
  if (what == "text()")
    return trim(n->ownText());
  for (const auto &k : n->kids)
    if (k.kind == XNode::Element && k.name == what)
      return trim(k.innerText());
  return "";
}

bool hasItem(const XNode *n, const std::string &what) {
  if (what[0] == '@')
    return n->attr(what.substr(1)) != nullptr;
  if (what == "text()")
    return !trim(n->ownText()).empty();
  for (const auto &k : n->kids)
    if (k.kind == XNode::Element && k.name == what)
      return true;
  return false;
}

std::string unquote(const std::string &s) {
  std::string t = trim(s);
  if (t.size() >= 2 && (t[0] == '\'' || t[0] == '"') && t.back() == t[0])
    return t.substr(1, t.size() - 2);
  return t;
}

bool predicate(const XNode *n, const std::string &predIn, size_t pos, size_t count) {
  std::string pred = trim(predIn);
  if (pred.empty())
    return true;
  if (pred == "last()")
    return pos == count;
  bool allDigits = std::all_of(pred.begin(), pred.end(), [](char c) { return std::isdigit(static_cast<unsigned char>(c)); });
  if (allDigits)
    return pos == static_cast<size_t>(std::atoll(pred.c_str()));
  if (pred.rfind("position()", 0) == 0) {
    std::string rest = trim(pred.substr(10));
    for (const char *op : {"<=", ">=", "!=", "<", ">", "="}) {
      size_t l = std::strlen(op);
      if (rest.compare(0, l, op) == 0) {
        double v = std::atof(rest.c_str() + l);
        double p = static_cast<double>(pos);
        std::string o = op;
        return o == "<=" ? p <= v : o == ">=" ? p >= v : o == "!=" ? p != v : o == "<" ? p < v : o == ">" ? p > v : p == v;
      }
    }
  }
  for (const char *fn : {"contains(", "starts-with("}) {
    size_t l = std::strlen(fn);
    if (pred.compare(0, l, fn) == 0 && pred.back() == ')') {
      std::string inner = pred.substr(l, pred.size() - l - 1);
      size_t comma = inner.find(',');
      if (comma == std::string::npos)
        return false;
      std::string hay = itemValue(n, trim(inner.substr(0, comma)));
      std::string needle = unquote(inner.substr(comma + 1));
      return std::string(fn) == "contains(" ? hay.find(needle) != std::string::npos : hay.rfind(needle, 0) == 0;
    }
  }
  for (const char *op : {"!=", "<=", ">=", "=", "<", ">"}) {
    size_t at = pred.find(op);
    if (at == std::string::npos)
      continue;
    std::string lhs = trim(pred.substr(0, at));
    std::string rhs = trim(pred.substr(at + std::strlen(op)));
    std::string v = itemValue(n, lhs);
    bool quoted = !rhs.empty() && (rhs[0] == '\'' || rhs[0] == '"');
    std::string o = op;
    if (quoted || o == "=" || o == "!=") {
      std::string r = unquote(rhs);
      if (!quoted) {
        char *e1 = nullptr, *e2 = nullptr;
        double a = std::strtod(v.c_str(), &e1), b = std::strtod(r.c_str(), &e2);
        if (*e1 == '\0' && *e2 == '\0' && !v.empty() && !r.empty())
          return o == "=" ? a == b : a != b;
      }
      return o == "=" ? v == r : o == "!=" ? v != r : o == "<" ? v < r : o == ">" ? v > r : o == "<=" ? v <= r : v >= r;
    }
    char *e1 = nullptr;
    double a = std::strtod(v.c_str(), &e1);
    double b = std::atof(rhs.c_str());
    if (v.empty() || *e1 != '\0')
      return false;
    return o == "<" ? a < b : o == ">" ? a > b : o == "<=" ? a <= b : a >= b;
  }
  return hasItem(n, pred);
}

} // namespace

bool xpath(const XNode &doc, const std::string &exprIn, std::vector<XItem> &out, std::string &err,
           const std::vector<std::pair<std::string, std::string>> &ns) {
  out.clear();
  std::string expr = trim(exprIn);
  if (expr.empty()) {
    err = "empty XPath";
    return false;
  }
  Ctx ctx;
  ctx.index(doc);
  // prefix in expression -> prefix in document, via the namespace URI.
  std::unordered_map<std::string, std::string> prefixMap;
  if (!ns.empty()) {
    std::vector<const XNode *> all;
    descendants(&doc, all);
    for (const auto &kv : ns)
      for (const XNode *e : all)
        for (const auto &a : e->attrs)
          if (a.second == kv.second && (a.first == "xmlns" || a.first.rfind("xmlns:", 0) == 0))
            prefixMap[kv.first] = a.first == "xmlns" ? "" : a.first.substr(6);
  }
  std::vector<const XNode *> cur{&doc};
  size_t i = 0;
  bool relative = expr[0] != '/';
  if (relative)
    cur = {&doc}; // relative paths start at the document too
  while (i < expr.size()) {
    bool deep = false;
    if (expr.compare(i, 2, "//") == 0) {
      deep = true;
      i += 2;
    } else if (expr[i] == '/') {
      i++;
    } else if (i > 0) {
      err = "XPath: unexpected '" + std::string(1, expr[i]) + "'";
      return false;
    }
    // the step: up to the next '/' outside brackets
    size_t e = i;
    int depth = 0;
    bool inQuote = false;
    char q = 0;
    for (; e < expr.size(); e++) {
      char c = expr[e];
      if (inQuote) {
        if (c == q)
          inQuote = false;
        continue;
      }
      if (c == '\'' || c == '"') {
        inQuote = true;
        q = c;
      } else if (c == '[') {
        depth++;
      } else if (c == ']') {
        depth--;
      } else if (c == '/' && depth == 0) {
        break;
      }
    }
    std::string step = expr.substr(i, e - i);
    i = e;
    std::vector<std::string> preds;
    std::string test = step;
    size_t lb = step.find('[');
    if (lb != std::string::npos) {
      test = step.substr(0, lb);
      size_t k = lb;
      while (k < step.size() && step[k] == '[') {
        int d = 0;
        size_t m = k;
        for (; m < step.size(); m++) {
          if (step[m] == '[') d++;
          else if (step[m] == ']' && --d == 0) break;
        }
        preds.push_back(step.substr(k + 1, m - k - 1));
        k = m + 1;
      }
    }
    test = trim(test);
    if (relative && cur.size() == 1 && cur[0] == &doc && !deep && test != "." && test != "..") {
      deep = true; // "book/title" from the document = any book element
      relative = false;
    }
    // attribute / text results end the path
    if (!test.empty() && (test[0] == '@' || test == "text()")) {
      std::vector<const XNode *> base = cur;
      if (deep) {
        base.clear();
        for (auto *n : cur) {
          base.push_back(n);
          descendants(n, base);
        }
      }
      for (auto *n : base) {
        if (test == "text()") {
          std::string t = trim(n->ownText());
          if (!t.empty())
            out.push_back({n, "", true, t});
        } else if (test == "@*") {
          for (const auto &a : n->attrs)
            out.push_back({n, a.first, false, a.second});
        } else if (const std::string *a = n->attr(test.substr(1))) {
          out.push_back({n, test.substr(1), false, *a});
        }
      }
      if (i < expr.size()) {
        err = "XPath: nothing can follow " + test;
        return false;
      }
      return true;
    }
    std::string name = test;
    size_t colon = name.find(':');
    if (colon != std::string::npos) {
      auto it = prefixMap.find(name.substr(0, colon));
      if (it != prefixMap.end())
        name = it->second.empty() ? name.substr(colon + 1) : it->second + ":" + name.substr(colon + 1);
    }
    std::vector<const XNode *> next;
    for (auto *n : cur) {
      std::vector<const XNode *> cand;
      if (name == ".") {
        cand.push_back(n);
      } else if (name == "..") {
        auto it = ctx.parent.find(n);
        if (it != ctx.parent.end())
          cand.push_back(it->second);
      } else if (deep) {
        std::vector<const XNode *> all;
        descendants(n, all);
        for (auto *d : all)
          if (name == "*" || name == "node()" || d->name == name)
            cand.push_back(d);
      } else {
        for (const auto &k : n->kids)
          if (k.kind == XNode::Element && (name == "*" || name == "node()" || k.name == name))
            cand.push_back(&k);
      }
      for (const auto &p : preds) {
        std::vector<const XNode *> kept;
        for (size_t k = 0; k < cand.size(); k++)
          if (predicate(cand[k], p, k + 1, cand.size()))
            kept.push_back(cand[k]);
        cand = std::move(kept);
      }
      for (auto *c : cand)
        if (std::find(next.begin(), next.end(), c) == next.end())
          next.push_back(c);
    }
    cur = std::move(next);
  }
  for (auto *n : cur)
    out.push_back({n, "", false, ""});
  return true;
}

// ---- CSS selectors ----------------------------------------------------------

namespace {
struct Simple {
  std::string tag, id;
  std::vector<std::string> classes;
  struct AttrTest {
    std::string name, op, value;
  };
  std::vector<AttrTest> attrs;
};

bool parseSimple(const std::string &s, Simple &out) {
  size_t i = 0;
  auto ident = [&]() {
    size_t b = i;
    while (i < s.size() && (std::isalnum(static_cast<unsigned char>(s[i])) || s[i] == '-' || s[i] == '_'))
      i++;
    return s.substr(b, i - b);
  };
  if (i < s.size() && (std::isalpha(static_cast<unsigned char>(s[i])) || s[i] == '*')) {
    if (s[i] == '*')
      i++;
    else
      out.tag = lower(ident());
  }
  while (i < s.size()) {
    if (s[i] == '.') {
      i++;
      out.classes.push_back(ident());
    } else if (s[i] == '#') {
      i++;
      out.id = ident();
    } else if (s[i] == '[') {
      size_t e = s.find(']', i);
      if (e == std::string::npos)
        return false;
      std::string in = s.substr(i + 1, e - i - 1);
      Simple::AttrTest t;
      size_t eq = in.find('=');
      if (eq == std::string::npos) {
        t.name = trim(in);
      } else {
        size_t opStart = eq;
        if (eq > 0 && std::strchr("*^$~|", in[eq - 1]))
          opStart = eq - 1;
        t.name = trim(in.substr(0, opStart));
        t.op = in.substr(opStart, eq - opStart + 1);
        t.value = unquote(in.substr(eq + 1));
      }
      out.attrs.push_back(t);
      i = e + 1;
    } else if (s[i] == ':') {
      // pseudo-classes are ignored
      i++;
      ident();
      if (i < s.size() && s[i] == '(') {
        size_t e = s.find(')', i);
        i = e == std::string::npos ? s.size() : e + 1;
      }
    } else {
      return false;
    }
  }
  return true;
}

bool matchSimple(const XNode *n, const Simple &s) {
  if (n->kind != XNode::Element)
    return false;
  if (!s.tag.empty() && n->name != s.tag)
    return false;
  if (!s.id.empty()) {
    const std::string *id = n->attr("id");
    if (!id || *id != s.id)
      return false;
  }
  if (!s.classes.empty()) {
    const std::string *cls = n->attr("class");
    std::string list = cls ? " " + *cls + " " : "";
    for (const auto &c : s.classes)
      if (list.find(" " + c + " ") == std::string::npos)
        return false;
  }
  for (const auto &t : s.attrs) {
    const std::string *v = n->attr(t.name);
    if (!v)
      return false;
    if (t.op == "=" && *v != t.value) return false;
    if (t.op == "*=" && v->find(t.value) == std::string::npos) return false;
    if (t.op == "^=" && v->rfind(t.value, 0) != 0) return false;
    if (t.op == "$=" && (v->size() < t.value.size() || v->compare(v->size() - t.value.size(), t.value.size(), t.value) != 0)) return false;
    if (t.op == "~=" && (" " + *v + " ").find(" " + t.value + " ") == std::string::npos) return false;
  }
  return true;
}
} // namespace

bool cssSelect(const XNode &doc, const std::string &selector, std::vector<const XNode *> &out,
               std::string &err) {
  out.clear();
  Ctx ctx;
  ctx.index(doc);
  std::vector<const XNode *> all;
  descendants(&doc, all);
  size_t start = 0;
  while (start <= selector.size()) {
    size_t comma = selector.find(',', start);
    if (comma == std::string::npos)
      comma = selector.size();
    std::string group = trim(selector.substr(start, comma - start));
    start = comma + 1;
    if (group.empty())
      continue;
    // tokens: simple selectors and combinators
    std::vector<Simple> parts;
    std::vector<char> combs; // combs[k] joins parts[k] and parts[k+1]: ' ' or '>'
    size_t i = 0;
    while (i < group.size()) {
      while (i < group.size() && group[i] == ' ')
        i++;
      if (i < group.size() && group[i] == '>') {
        if (!combs.empty())
          combs.back() = '>';
        i++;
        continue;
      }
      size_t b = i;
      int br = 0;
      while (i < group.size() && (br > 0 || (group[i] != ' ' && group[i] != '>'))) {
        if (group[i] == '[') br++;
        if (group[i] == ']') br--;
        i++;
      }
      Simple s;
      if (!parseSimple(group.substr(b, i - b), s)) {
        err = "CSS selector '" + group + "' is not understood";
        return false;
      }
      parts.push_back(s);
      combs.push_back(' ');
    }
    if (parts.empty())
      continue;
    combs.pop_back();
    for (const XNode *n : all) {
      if (!matchSimple(n, parts.back()))
        continue;
      // right to left
      std::function<bool(const XNode *, int)> up = [&](const XNode *node, int k) -> bool {
        if (k < 0)
          return true;
        char c = combs[static_cast<size_t>(k)];
        auto it = ctx.parent.find(node);
        const XNode *p = it == ctx.parent.end() ? nullptr : it->second;
        if (c == '>')
          return p && matchSimple(p, parts[static_cast<size_t>(k)]) && up(p, k - 1);
        while (p) {
          if (matchSimple(p, parts[static_cast<size_t>(k)]) && up(p, k - 1))
            return true;
          auto pit = ctx.parent.find(p);
          p = pit == ctx.parent.end() ? nullptr : pit->second;
        }
        return false;
      };
      if (up(n, static_cast<int>(parts.size()) - 2) && std::find(out.begin(), out.end(), n) == out.end())
        out.push_back(n);
    }
  }
  return true;
}

// ---- XML writer ---------------------------------------------------------------

namespace {
void writeNode(const XNode &n, int indent, int depth, const std::vector<std::string> &cdata,
               std::string &out) {
  const std::string pad = indent > 0 ? std::string(static_cast<size_t>(depth * indent), ' ') : "";
  const char *nl = indent > 0 ? "\n" : "";
  switch (n.kind) {
    case XNode::Document:
      for (const auto &k : n.kids)
        writeNode(k, indent, depth, cdata, out);
      return;
    case XNode::Comment: out += pad + "<!--" + n.text + "-->" + nl; return;
    case XNode::CData: out += pad + "<![CDATA[" + n.text + "]]>" + nl; return;
    case XNode::PI: out += pad + "<?" + n.name + (n.text.empty() ? "" : " " + n.text) + "?>" + nl; return;
    case XNode::Doctype: out += "<!" + n.text + ">" + nl; return;
    case XNode::Text: out += pad + escapeXml(n.text, false) + nl; return;
    case XNode::Element: break;
  }
  out += pad + "<" + n.name;
  for (const auto &a : n.attrs)
    out += " " + a.first + "=\"" + escapeXml(a.second, true) + "\"";
  if (n.kids.empty()) {
    out += "/>";
    out += nl;
    return;
  }
  // Only text inside: one line.
  bool textOnly = true;
  for (const auto &k : n.kids)
    if (k.kind != XNode::Text && k.kind != XNode::CData)
      textOnly = false;
  if (textOnly) {
    out += ">";
    bool asCdata = std::find(cdata.begin(), cdata.end(), n.name) != cdata.end();
    for (const auto &k : n.kids)
      out += (asCdata || k.kind == XNode::CData) ? "<![CDATA[" + k.text + "]]>" : escapeXml(k.text, false);
    out += "</" + n.name + ">" + nl;
    return;
  }
  out += ">";
  out += nl;
  for (const auto &k : n.kids)
    writeNode(k, indent, depth + 1, cdata, out);
  out += pad + "</" + n.name + ">" + nl;
}
} // namespace

std::string writeXml(const XNode &doc, int indent, const std::vector<std::string> &cdataFields,
                     const std::string &encoding) {
  std::string out = "<?xml version=\"1.0\" encoding=\"" + encoding + "\"?>";
  out += indent > 0 ? "\n" : "";
  if (doc.kind == XNode::Document) {
    for (const auto &k : doc.kids) {
      if (k.kind == XNode::PI && k.name == "xml")
        continue; // the prologue is written above
      writeNode(k, indent, 0, cdataFields, out);
    }
  } else {
    writeNode(doc, indent, 0, cdataFields, out);
  }
  return out;
}

} // namespace io
} // namespace nc
