// CATEGORY 11 - read_/load_/save_ nc, cdf: NetCDF classic (CDF-1), 64-bit
// offset (CDF-2), 64-bit data (CDF-5) and NetCDF-4 (HDF5 with dimension
// scales), hand-written. CF conventions: scale_factor / add_offset /
// _FillValue / missing_value are applied on read when scale=true.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_formats.h"
#include "io_h5.h"

namespace nc {
namespace io {
namespace {

struct NcDim {
  std::string name;
  uint64_t len = 0;
  bool unlimited = false;
};

struct NcVar {
  std::string name;
  std::vector<int> dims;
  std::string type;                                // byte char short int float double ubyte ushort uint int64 uint64 / h5 name
  std::vector<std::pair<std::string, Value>> attrs; // file order
  // classic
  int code = 6;
  uint64_t begin = 0, vsize = 0;
  bool record = false;
  // NetCDF-4
  const H5Object *obj = nullptr;
  const Value *attr(const std::string &n) const {
    for (const auto &a : attrs) if (a.first == n) return &a.second;
    return nullptr;
  }
};

struct NcModel {
  std::string format; // "classic" "64bit_offset" "64bit_data" "netcdf4"
  std::vector<NcDim> dims;
  std::vector<std::pair<std::string, Value>> gatts;
  std::vector<NcVar> vars;
  uint64_t numrecs = 0, recsize = 0;
  std::string bytes;
  H5Reader h5;

  const NcVar *var(const std::string &n) const {
    for (const auto &v : vars) if (v.name == n) return &v;
    return nullptr;
  }
  int dimIndex(const std::string &n) const {
    for (size_t i = 0; i < dims.size(); i++) if (dims[i].name == n) return static_cast<int>(i);
    return -1;
  }
  std::vector<uint64_t> shapeOf(const NcVar &v) const {
    std::vector<uint64_t> s;
    for (int d : v.dims) s.push_back(dims[d].unlimited && format != "netcdf4" ? numrecs : dims[d].len);
    if (v.obj) { s.clear(); for (auto x : v.obj->dims) s.push_back(x); }
    return s;
  }
};

const char *TYPE_NAMES[] = {"", "byte", "char", "short", "int", "float", "double", "ubyte", "ushort", "uint", "int64", "uint64"};
size_t typeSize(int code) {
  static const size_t s[] = {0, 1, 1, 2, 4, 4, 8, 1, 2, 4, 8, 8};
  return code >= 1 && code <= 11 ? s[code] : 0;
}

double beValue(const char *p, int code) {
  std::string b(p, typeSize(code));
  switch (code) {
  case 1: return static_cast<int8_t>(b[0]);
  case 2: case 7: return static_cast<unsigned char>(b[0]);
  case 3: return static_cast<int16_t>(u16be(b, 0));
  case 4: return static_cast<int32_t>(u32be(b, 0));
  case 5: return f32be(b, 0);
  case 6: return f64be(b, 0);
  case 8: return u16be(b, 0);
  case 9: return u32be(b, 0);
  case 10: return static_cast<double>(static_cast<int64_t>(u64be(b, 0)));
  case 11: return static_cast<double>(u64be(b, 0));
  }
  return std::nan("");
}

// ---- classic reader ---------------------------------------------------------------------------

struct ClassicParser {
  const std::string &b;
  size_t p = 4;
  bool v5;
  std::string err;
  ClassicParser(const std::string &bytes, bool five) : b(bytes), v5(five) {}
  bool need(size_t n) { if (p + n > b.size()) { err = "the NetCDF header is cut short"; return false; } return true; }
  uint64_t count() { if (!need(v5 ? 8 : 4)) return 0; uint64_t v = v5 ? u64be(b, p) : u32be(b, p); p += v5 ? 8 : 4; return v; }
  uint32_t u32() { if (!need(4)) return 0; uint32_t v = u32be(b, p); p += 4; return v; }
  std::string name() {
    uint64_t n = count();
    if (!need(static_cast<size_t>(n))) return "";
    std::string s = b.substr(p, static_cast<size_t>(n));
    p += static_cast<size_t>((n + 3) / 4 * 4);
    return s;
  }
  bool attrs(std::vector<std::pair<std::string, Value>> &out) {
    uint32_t tag = u32();
    uint64_t n = count();
    if (tag == 0 && n == 0) return true;
    if (tag != 0x0C) { err = "bad NetCDF attribute list"; return false; }
    for (uint64_t i = 0; i < n && err.empty(); i++) {
      std::string nm = name();
      int code = static_cast<int>(u32());
      uint64_t k = count();
      size_t sz = typeSize(code);
      if (!sz || !need(static_cast<size_t>(k * sz))) { if (err.empty()) err = "bad NetCDF attribute type"; return false; }
      if (code == 2) {
        std::string s = b.substr(p, static_cast<size_t>(k));
        while (!s.empty() && s.back() == '\0') s.pop_back();
        out.push_back({nm, Value(s)});
      } else {
        std::vector<double> v;
        for (uint64_t j = 0; j < k; j++) v.push_back(beValue(b.data() + p + j * sz, code));
        out.push_back({nm, v.size() == 1 ? Value(v[0]) : numberList(v)});
      }
      p += static_cast<size_t>((k * sz + 3) / 4 * 4);
    }
    return err.empty();
  }
};

bool openClassic(NcModel &m, std::string &err) {
  const std::string &b = m.bytes;
  int ver = b[3];
  ClassicParser c(b, ver == 5);
  m.format = ver == 1 ? "classic" : ver == 2 ? "64bit_offset" : "64bit_data";
  uint64_t nr = c.count();
  m.numrecs = nr == 0xFFFFFFFFull ? 0 : nr; // streaming
  uint32_t tag = c.u32();
  uint64_t n = c.count();
  if (tag == 0x0A) {
    for (uint64_t i = 0; i < n; i++) {
      NcDim d;
      d.name = c.name();
      d.len = c.count();
      d.unlimited = d.len == 0;
      m.dims.push_back(d);
    }
  } else if (tag != 0 || n != 0) { err = "bad NetCDF dimension list"; return false; }
  if (!c.attrs(m.gatts)) { err = c.err; return false; }
  tag = c.u32();
  n = c.count();
  if (tag != 0x0B && !(tag == 0 && n == 0)) { err = "bad NetCDF variable list"; return false; }
  for (uint64_t i = 0; i < n && c.err.empty(); i++) {
    NcVar v;
    v.name = c.name();
    uint64_t nd = c.count();
    for (uint64_t k = 0; k < nd; k++) {
      uint64_t id = c.count();
      if (id >= m.dims.size()) { err = "variable '" + v.name + "' uses an unknown dimension"; return false; }
      v.dims.push_back(static_cast<int>(id));
    }
    if (!c.attrs(v.attrs)) { err = c.err; return false; }
    v.code = static_cast<int>(c.u32());
    if (!typeSize(v.code)) { err = "variable '" + v.name + "' has an unknown type"; return false; }
    v.type = TYPE_NAMES[v.code];
    v.vsize = c.count();
    if (ver == 1) v.begin = c.u32();
    else { if (!c.need(8)) break; v.begin = u64be(b, c.p); c.p += 8; }
    v.record = !v.dims.empty() && m.dims[v.dims[0]].unlimited;
    m.vars.push_back(v);
  }
  if (!c.err.empty()) { err = c.err; return false; }
  size_t nrec = 0;
  for (const auto &v : m.vars) if (v.record) { m.recsize += v.vsize; nrec++; }
  if (nrec == 1) // a single record variable is not padded
    for (const auto &v : m.vars) if (v.record) { uint64_t s = typeSize(v.code); for (size_t k = 1; k < v.dims.size(); k++) s *= m.dims[v.dims[k]].len; m.recsize = s; }
  if (nr == 0xFFFFFFFFull && m.recsize) { // streaming: count the records that are there
    uint64_t start = UINT64_MAX;
    for (const auto &v : m.vars) if (v.record) start = std::min(start, v.begin);
    if (start != UINT64_MAX && start < b.size()) m.numrecs = (b.size() - start) / m.recsize;
  }
  return true;
}

// ---- NetCDF-4 (HDF5) ---------------------------------------------------------------------------

bool isHidden(const std::string &n) {
  return n == "CLASS" || n == "NAME" || n == "REFERENCE_LIST" || n == "DIMENSION_LIST" || n == "_Netcdf4Dimid" ||
         n == "_Netcdf4Coordinates" || n == "_NCProperties" || n == "_nc3_strict" || n == "_IsNetcdf4";
}

bool openNc4(NcModel &m, std::string &err) {
  if (!m.h5.open(m.bytes, err)) return false;
  m.format = "netcdf4";
  const H5Object &root = m.h5.root;
  for (const auto &a : root.attrs) if (!isHidden(a.name)) m.gatts.push_back({a.name, h5ToValue(a.value)});
  // dimensions = dimension scales
  std::map<uint64_t, int> scaleDim;
  for (const auto &k : root.kids) {
    if (k.group || !k.softTarget.empty()) continue;
    const H5Attr *cls = k.attr("CLASS");
    if (!cls || !cls->value.isText || cls->value.strs.empty() || cls->value.strs[0] != "DIMENSION_SCALE") continue;
    NcDim d;
    d.name = k.name;
    d.len = k.dims.empty() ? 0 : k.dims[0];
    d.unlimited = !k.maxDims.empty() && k.maxDims[0] == H5_UNDEF;
    scaleDim[k.addr] = static_cast<int>(m.dims.size());
    m.dims.push_back(d);
  }
  for (const auto &k : root.kids) {
    if (k.group || !k.softTarget.empty()) continue;
    const H5Attr *nm = k.attr("NAME");
    if (nm && nm->value.isText && !nm->value.strs.empty() && nm->value.strs[0].rfind("This is a netCDF dimension but not a netCDF variable", 0) == 0) continue;
    NcVar v;
    v.name = k.name;
    v.obj = &k;
    v.type = k.type.name();
    for (const auto &a : k.attrs) if (!isHidden(a.name)) v.attrs.push_back({a.name, h5ToValue(a.value)});
    const H5Attr *dl = k.attr("DIMENSION_LIST");
    for (size_t i = 0; i < k.dims.size(); i++) {
      int di = -1;
      if (dl && i < dl->value.items.size() && !dl->value.items[i].nums.empty()) {
        auto it = scaleDim.find(static_cast<uint64_t>(dl->value.items[i].nums[0]));
        if (it != scaleDim.end()) di = it->second;
      }
      if (di < 0 && scaleDim.count(k.addr) && i == 0) di = scaleDim[k.addr];
      if (di < 0) { // phony dimension, like netCDF does for plain HDF5
        std::string pn = "phony_dim_" + std::to_string(m.dims.size());
        NcDim d;
        d.name = pn;
        d.len = k.dims[i];
        di = static_cast<int>(m.dims.size());
        m.dims.push_back(d);
      }
      v.dims.push_back(di);
    }
    m.vars.push_back(v);
  }
  return true;
}

bool openNc(const std::string &file, NcModel &m, std::string &err) {
  if (!readSource(file, m.bytes, err)) return false;
  const std::string &b = m.bytes;
  if (b.size() >= 4 && b.compare(0, 3, "CDF") == 0 && (b[3] == 1 || b[3] == 2 || b[3] == 5)) return openClassic(m, err);
  if (b.size() >= 8 && (b.compare(0, 8, "\x89HDF\r\n\x1a\n") == 0 || b.find("\x89HDF\r\n\x1a\n") != std::string::npos)) return openNc4(m, err);
  if (b.size() >= 4 && static_cast<unsigned char>(b[0]) == 0xCD && static_cast<unsigned char>(b[1]) == 0xF3) {
    err = "this is a NASA CDF file (Common Data Format) - that format is not built in; read_cdf reads NetCDF files";
    return false;
  }
  err = "not a NetCDF file (no CDF\\x01 / CDF\\x02 / CDF\\x05 / HDF5 signature)";
  return false;
}

// ---- reading values ---------------------------------------------------------------------------

struct VarData {
  std::vector<size_t> shape;
  std::vector<double> nums;
  std::vector<std::string> strs;
  bool text = false;
};

bool readVar(const NcModel &m, const NcVar &v, std::vector<std::pair<size_t, size_t>> ranges, bool scale, VarData &out,
             std::string &err) {
  std::vector<uint64_t> shape = m.shapeOf(v);
  size_t rank = shape.size();
  ranges.resize(rank);
  for (size_t d = 0; d < rank; d++)
    if (ranges[d].second == 0 && ranges[d].first == 0) ranges[d] = {0, static_cast<size_t>(shape[d])};
  if (v.obj) {
    H5Value h;
    if (!m.h5.readData(*v.obj, ranges, h, err)) return false;
    out.shape = h.shape;
    if (h.isText) {
      out.text = true;
      out.strs = h.strs;
      if (v.obj->type.cls == H5Type::String && v.obj->type.size == 1 && !out.shape.empty()) { // NC_CHAR: join along the last dim
        size_t w = std::max<size_t>(1, out.shape.back());
        std::vector<std::string> joined;
        for (size_t i = 0; i < out.strs.size(); i += w) { std::string s; for (size_t k = i; k < i + w && k < out.strs.size(); k++) s += out.strs[k]; joined.push_back(s); }
        out.strs = joined;
        out.shape.pop_back();
      }
    } else out.nums = h.nums;
  } else {
    bool chars = v.code == 2;
    size_t es = typeSize(v.code);
    if (chars && rank > 0) ranges[rank - 1] = {0, static_cast<size_t>(shape[rank - 1])};
    std::vector<size_t> ns(rank);
    size_t total = 1;
    for (size_t d = 0; d < rank; d++) { ns[d] = ranges[d].second - ranges[d].first; total *= ns[d]; }
    // strides inside one record / the whole array
    std::vector<uint64_t> stride(rank, 1);
    for (size_t d = rank; d-- > 1;) stride[d - 1] = stride[d] * shape[d];
    std::vector<size_t> idx(rank);
    for (size_t d = 0; d < rank; d++) idx[d] = ranges[d].first;
    std::vector<double> vals;
    std::string chars_;
    vals.reserve(chars ? 0 : total);
    for (size_t k = 0; k < total; k++) {
      uint64_t off = v.begin;
      if (v.record) {
        off += idx[0] * m.recsize;
        for (size_t d = 1; d < rank; d++) off += idx[d] * stride[d] * es;
      } else
        for (size_t d = 0; d < rank; d++) off += idx[d] * stride[d] * es;
      if (off + es > m.bytes.size()) { err = "variable '" + v.name + "' runs past the end of the file (truncated?)"; return false; }
      if (chars) chars_.push_back(m.bytes[static_cast<size_t>(off)]);
      else vals.push_back(beValue(m.bytes.data() + off, v.code));
      for (size_t d = rank; d-- > 0;) {
        if (++idx[d] < ranges[d].second) break;
        idx[d] = ranges[d].first;
      }
    }
    out.shape = ns;
    if (chars) {
      out.text = true;
      size_t w = rank ? ns[rank - 1] : 1;
      for (size_t i = 0; i + w <= chars_.size() || (w == 0 && i == 0); i += std::max<size_t>(w, 1)) {
        std::string s = chars_.substr(i, w);
        s = s.substr(0, s.find('\0'));
        out.strs.push_back(s);
        if (w == 0) break;
      }
      if (rank) out.shape.pop_back();
    } else out.nums = std::move(vals);
  }
  if (scale && !out.text) {
    std::vector<double> fills;
    for (const char *f : {"_FillValue", "missing_value"})
      if (const Value *fv = v.attr(f)) for (double x : optNumbers(*fv)) fills.push_back(x);
    const Value *sf = v.attr("scale_factor"), *ao = v.attr("add_offset");
    double s = sf ? optNumber(*sf, 1) : 1, o = ao ? optNumber(*ao, 0) : 0;
    for (double &x : out.nums) {
      for (double f : fills) if (x == f || (std::isnan(f) && std::isnan(x))) { x = std::nan(""); break; }
      if (!std::isnan(x)) x = x * s + o;
    }
  }
  return true;
}

Value toValue(const VarData &d, const std::vector<bool> &drop) {
  std::vector<size_t> shape;
  for (size_t i = 0; i < d.shape.size(); i++) if (i >= drop.size() || !drop[i]) shape.push_back(d.shape[i]);
  if (d.text) {
    if (d.strs.size() == 1) return Value(d.strs[0]);
    return textList(d.strs);
  }
  if (shape.empty()) return Value(d.nums.empty() ? std::nan("") : d.nums[0]);
  return ndFromRowMajor(shape, d.nums);
}

// the main data variable: most dimensions, then most elements, not a coordinate
const NcVar *primaryVar(const NcModel &m) {
  const NcVar *best = nullptr;
  size_t bestRank = 0, bestN = 0;
  for (const auto &v : m.vars) {
    if (v.dims.size() == 1 && m.dims[v.dims[0]].name == v.name) continue;
    std::vector<uint64_t> s = m.shapeOf(v);
    size_t n = 1;
    for (auto x : s) n *= static_cast<size_t>(x);
    if (!best || s.size() > bestRank || (s.size() == bestRank && n > bestN)) { best = &v; bestRank = s.size(); bestN = n; }
  }
  return best;
}

bool coordValues(const NcModel &m, const std::string &dim, std::vector<double> &vals, std::string &err) {
  const NcVar *c = m.var(dim);
  if (!c || c->dims.size() != 1) return false;
  VarData d;
  if (!readVar(m, *c, {}, true, d, err)) return false;
  vals = d.nums;
  return true;
}

// coordinate-value selection on one dimension: number -> nearest index; [a, b] -> index range
bool coordRange(const NcModel &m, const std::string &dim, const Value &want, std::pair<size_t, size_t> &r, bool &single,
                std::string &err) {
  std::vector<double> c;
  if (!coordValues(m, dim, c, err)) { if (err.empty()) err = "dimension '" + dim + "' has no coordinate variable to select by value"; return false; }
  if (c.empty()) { err = "coordinate '" + dim + "' is empty"; return false; }
  std::vector<double> w = optNumbers(want);
  if (w.size() == 1) {
    size_t best = 0;
    for (size_t i = 1; i < c.size(); i++) if (std::fabs(c[i] - w[0]) < std::fabs(c[best] - w[0])) best = i;
    r = {best, best + 1};
    single = true;
    return true;
  }
  if (w.size() != 2) { err = "coords: '" + dim + "' takes one value (nearest) or [low, high]"; return false; }
  double lo = std::min(w[0], w[1]), hi = std::max(w[0], w[1]);
  size_t first = SIZE_MAX, last = 0;
  for (size_t i = 0; i < c.size(); i++) if (c[i] >= lo && c[i] <= hi) { first = std::min(first, i); last = std::max(last, i); }
  if (first == SIZE_MAX) {
    auto mm = std::minmax_element(c.begin(), c.end());
    err = "no " + dim + " between " + numberText(lo) + " and " + numberText(hi) + " (" + dim + " runs " + numberText(*mm.first) + " .. " + numberText(*mm.second) + ")";
    return false;
  }
  r = {first, last + 1};
  single = false;
  return true;
}

Value attrsDict(const std::vector<std::pair<std::string, Value>> &a) {
  Fields f;
  for (const auto &kv : a) f[kv.first] = kv.second;
  return Value(f);
}

std::vector<std::string> boxesOf(const NcModel &m) {
  std::vector<std::string> out;
  for (const auto &kv : m.gatts) if (kv.second.isText) out.push_back(kv.first + ": " + kv.second.text());
  return out;
}

std::vector<std::string> dimNames(const NcModel &m, const NcVar &v) {
  std::vector<std::string> n;
  for (int d : v.dims) n.push_back(m.dims[d].name);
  return n;
}

// selection from slice= and coords= (dict dim -> value / [lo, hi])
bool selection(const NcModel &m, const NcVar &v, const std::string &slice, const Value &coords,
               std::vector<std::pair<size_t, size_t>> &ranges, std::vector<bool> &drop, std::string &err) {
  std::vector<uint64_t> shape = m.shapeOf(v);
  if (!slice.empty()) { if (!h5ParseSlice(slice, shape, ranges, err, &drop)) return false; }
  else { ranges.clear(); for (auto s : shape) ranges.push_back({0, static_cast<size_t>(s)}); drop.assign(shape.size(), false); }
  if (given(coords)) {
    if (!coords.isDict) { err = "coords must be a dict, e.g. coords=dict([\"lat\", \"time\"], {[10, 20], 0})"; return false; }
    std::vector<std::string> names = dimNames(m, v);
    for (const auto &kv : coords.dict()) {
      auto it = std::find(names.begin(), names.end(), kv.first);
      if (it == names.end()) {
        std::string j;
        for (auto &n : names) j += (j.empty() ? "" : ", ") + n;
        err = "'" + v.name + "' has no dimension '" + kv.first + "' (it has: " + j + ")";
        return false;
      }
      size_t d = static_cast<size_t>(it - names.begin());
      bool single = false;
      if (!coordRange(m, kv.first, kv.second, ranges[d], single, err)) return false;
      drop[d] = single;
    }
  }
  return true;
}

// read_<fmt>(file, var, coords, slice, scale, box)
void readNc(const std::string &fn, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev(fn, file);
  NcModel m;
  if (!openNc(file, m, err)) return ctx.fail(err);
  std::string vn = optText(a[1]);
  const NcVar *v = vn.empty() ? primaryVar(m) : m.var(vn);
  if (!v) {
    if (vn.empty()) return ctx.fail("the file has no variables");
    std::string j;
    for (const auto &x : m.vars) j += (j.empty() ? "" : ", ") + x.name;
    return ctx.fail("no variable '" + vn + "' (variables: " + j + ")");
  }
  std::vector<std::pair<size_t, size_t>> ranges;
  std::vector<bool> drop;
  if (!selection(m, *v, optText(a[3]), a[2], ranges, drop, err)) return ctx.fail(err);
  VarData d;
  if (!readVar(m, *v, ranges, optBool(a[4], true), d, err)) return ctx.fail(err);
  out.push_back(toValue(d, drop));
  if (nout > 1) {
    Fields info;
    info["var"] = Value(v->name);
    info["dims"] = textList(dimNames(m, *v));
    std::vector<double> shape;
    for (auto s : d.shape) shape.push_back(static_cast<double>(s));
    info["shape"] = numberList(shape);
    info["attrs"] = attrsDict(v->attrs);
    const Value *u = v->attr("units");
    info["units"] = u ? *u : Value(std::string());
    Fields cf;
    std::vector<std::string> names = dimNames(m, *v);
    for (size_t k = 0; k < names.size(); k++) {
      std::vector<double> c;
      if (coordValues(m, names[k], c, err))
        cf[names[k]] = numberList(std::vector<double>(c.begin() + std::min(ranges[k].first, c.size()), c.begin() + std::min(ranges[k].second, c.size())));
      err.clear();
    }
    info["coords"] = Value(cf);
    info["format"] = Value(m.format);
    info["global_attrs"] = attrsDict(m.gatts);
    info["boxes"] = optBool(a[5], true) ? textList(boxesOf(m)) : textList({});
    std::vector<std::string> vars;
    for (const auto &x : m.vars) vars.push_back(x.name);
    info["vars"] = textList(vars);
    out.push_back(makeObject("NcReadInfo", info));
  }
  ev.ok = true;
}

const size_t LAZY_LIMIT = 1000000;

Value varObject(const NcModel &m, const NcVar &v, const std::string &file, std::string &err) {
  Fields f;
  f["name"] = Value(v.name);
  f["dims"] = textList(dimNames(m, v));
  std::vector<uint64_t> s = m.shapeOf(v);
  std::vector<double> shape(s.begin(), s.end());
  f["shape"] = numberList(shape);
  f["dtype"] = Value(v.type);
  f["attrs"] = attrsDict(v.attrs);
  for (const char *k : {"units", "long_name", "standard_name"}) { const Value *x = v.attr(k); f[k] = x ? *x : Value(std::string()); }
  const Value *fv = v.attr("_FillValue");
  if (!fv) fv = v.attr("missing_value");
  f["fill_val"] = fv ? *fv : Value(std::nan(""));
  f["file"] = Value(file);
  size_t n = 1;
  for (auto x : s) n *= static_cast<size_t>(x);
  f["size"] = Value(static_cast<double>(n));
  f["loaded"] = Value::boolean(n <= LAZY_LIMIT);
  if (n <= LAZY_LIMIT) {
    VarData d;
    if (readVar(m, v, {}, true, d, err)) f["data"] = toValue(d, {});
    else { f["data"] = Value("(not readable: " + err + ")"); err.clear(); }
  }
  return makeObject("NcNcVar", f);
}

Value loadNc(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev(fn, file);
  NcModel m;
  if (!openNc(file, m, err)) { ctx.fail(err); return Value(0.0); }
  Fields f;
  std::vector<std::string> vars, unlimited;
  Fields dims, coords;
  for (const auto &d : m.dims) {
    dims[d.name] = Value(static_cast<double>(d.unlimited && m.format != "netcdf4" ? m.numrecs : d.len));
    if (d.unlimited) unlimited.push_back(d.name);
    std::vector<double> c;
    if (coordValues(m, d.name, c, err)) coords[d.name] = numberList(c);
    err.clear();
  }
  static const std::vector<std::string> reserved = {"vars", "dims", "coords", "attrs", "boxes", "file", "format", "unlimited", "default"};
  const NcVar *primary = primaryVar(m);
  for (const auto &v : m.vars) {
    vars.push_back(v.name);
    std::string fname = fieldName(v.name);
    if (fname.empty() || std::find(reserved.begin(), reserved.end(), fname) != reserved.end() || f.count(fname)) continue;
    f[fname] = varObject(m, v, file, err);
    if (&v == primary) f["default"] = f[fname];
  }
  f["vars"] = textList(vars);
  f["dims"] = Value(dims);
  f["coords"] = Value(coords);
  f["attrs"] = attrsDict(m.gatts);
  f["boxes"] = textList(boxesOf(m));
  f["file"] = Value(file);
  f["format"] = Value(m.format);
  f["unlimited"] = textList(unlimited);
  ev.ok = true;
  return makeObject("NcNetCDF", f);
}

// V.sel(lat=13.08, lon=80.27, time=[0, 10], coords=dict(...))
Value selMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *file = field(a[0], "file"), *name = field(a[0], "name");
  if (!file || !name) { ctx.fail("sel() needs a variable of load_nc(...)"); return Value(0.0); }
  NcModel m;
  std::string err;
  if (!openNc(file->text(), m, err)) { ctx.fail(err); return Value(0.0); }
  const NcVar *v = m.var(name->text());
  if (!v) { ctx.fail("no variable '" + name->text() + "' in " + file->text()); return Value(0.0); }
  static const char *keys[] = {"lat", "lon", "time", "level", "depth", "x", "y", "z"};
  Fields want;
  for (size_t i = 0; i < 8; i++) if (given(a[i + 1])) want[keys[i]] = a[i + 1];
  if (given(a[9])) {
    if (!a[9].isDict) { ctx.fail("coords= must be a dict of dimension -> value"); return Value(0.0); }
    for (const auto &kv : a[9].dict()) want[kv.first] = kv.second;
  }
  // accept common spellings: lat/latitude, lon/longitude
  std::vector<std::string> names = dimNames(m, *v);
  Fields mapped;
  for (const auto &kv : want) {
    std::string k = kv.first;
    if (std::find(names.begin(), names.end(), k) == names.end()) {
      for (const auto &n : names) {
        std::string ln = lower(n);
        if ((k == "lat" && (ln == "latitude" || ln == "y")) || (k == "lon" && (ln == "longitude" || ln == "x")) || (k == "level" && (ln == "lev" || ln == "plev" || ln == "z")) || (k == "time" && ln == "t"))
          k = n;
      }
    }
    mapped[k] = kv.second;
  }
  std::vector<std::pair<size_t, size_t>> ranges;
  std::vector<bool> drop;
  if (!selection(m, *v, "", Value(mapped), ranges, drop, err)) { ctx.fail(err); return Value(0.0); }
  VarData d;
  if (!readVar(m, *v, ranges, true, d, err)) { ctx.fail(err); return Value(0.0); }
  return toValue(d, drop);
}

Value readVarMethod(const std::vector<Value> &a, CallContext &ctx, bool fromVar) {
  const Value *file = field(a[0], "file");
  if (!file) { ctx.fail("this object has no file to read from"); return Value(0.0); }
  NcModel m;
  std::string err, vn = fromVar ? (field(a[0], "name") ? field(a[0], "name")->text() : "") : optText(a[1]);
  if (!openNc(file->text(), m, err)) { ctx.fail(err); return Value(0.0); }
  const NcVar *v = vn.empty() ? primaryVar(m) : m.var(vn);
  if (!v) { ctx.fail("no variable '" + vn + "'"); return Value(0.0); }
  std::vector<std::pair<size_t, size_t>> ranges;
  std::vector<bool> drop;
  if (!selection(m, *v, optText(a[fromVar ? 1 : 2]), Value(std::string()), ranges, drop, err)) { ctx.fail(err); return Value(0.0); }
  VarData d;
  if (!readVar(m, *v, ranges, true, d, err)) { ctx.fail(err); return Value(0.0); }
  return toValue(d, drop);
}

// ---- writing ----------------------------------------------------------------------------------

struct OutVar {
  std::string name;
  std::vector<int> dims;
  std::vector<double> vals;           // row-major
  std::vector<std::pair<std::string, Value>> attrs;
  bool coord = false;
};

struct OutModel {
  std::vector<NcDim> dims;
  std::vector<OutVar> vars;
  std::vector<std::pair<std::string, Value>> gatts;
  int dim(const std::string &n) const {
    for (size_t i = 0; i < dims.size(); i++) if (dims[i].name == n) return static_cast<int>(i);
    return -1;
  }
};

void putName(std::string &o, const std::string &s) {
  putBE(o, s.size(), 4);
  o += s;
  while (o.size() % 4) o.push_back('\0');
}

void putAttrs(std::string &o, const std::vector<std::pair<std::string, Value>> &attrs) {
  if (attrs.empty()) { putBE(o, 0, 4); putBE(o, 0, 4); return; }
  putBE(o, 0x0C, 4);
  putBE(o, attrs.size(), 4);
  for (const auto &kv : attrs) {
    putName(o, kv.first);
    if (kv.second.isText && !kv.second.isArray && !kv.second.isMatrix) {
      putBE(o, 2, 4);
      putBE(o, kv.second.text().size(), 4);
      o += kv.second.text();
    } else {
      std::vector<double> v = optNumbers(kv.second);
      putBE(o, 6, 4);
      putBE(o, v.size(), 4);
      for (double d : v) putF64BE(o, d);
    }
    while (o.size() % 4) o.push_back('\0');
  }
}

std::string writeClassic(const OutModel &m, bool v2, std::string &err) {
  int rec = -1;
  for (size_t i = 0; i < m.dims.size(); i++) if (m.dims[i].unlimited) rec = static_cast<int>(i);
  uint64_t numrecs = rec >= 0 ? m.dims[rec].len : 0;
  auto header = [&](const std::vector<uint64_t> &begins) {
    std::string h = "CDF";
    h.push_back(v2 ? 2 : 1);
    putBE(h, numrecs, 4);
    if (m.dims.empty()) { putBE(h, 0, 4); putBE(h, 0, 4); }
    else {
      putBE(h, 0x0A, 4);
      putBE(h, m.dims.size(), 4);
      for (const auto &d : m.dims) { putName(h, d.name); putBE(h, d.unlimited ? 0 : d.len, 4); }
    }
    putAttrs(h, m.gatts);
    if (m.vars.empty()) { putBE(h, 0, 4); putBE(h, 0, 4); }
    else {
      putBE(h, 0x0B, 4);
      putBE(h, m.vars.size(), 4);
      for (size_t i = 0; i < m.vars.size(); i++) {
        const auto &v = m.vars[i];
        putName(h, v.name);
        putBE(h, v.dims.size(), 4);
        for (int d : v.dims) putBE(h, d, 4);
        putAttrs(h, v.attrs);
        putBE(h, 6, 4);
        uint64_t n = 8;
        for (size_t k = 0; k < v.dims.size(); k++) if (!m.dims[v.dims[k]].unlimited) n *= m.dims[v.dims[k]].len;
        putBE(h, n, 4);
        if (v2) putBE(h, begins.empty() ? 0 : begins[i], 8);
        else putBE(h, begins.empty() ? 0 : begins[i], 4);
      }
    }
    return h;
  };
  std::string h0 = header({});
  std::vector<uint64_t> begins(m.vars.size());
  uint64_t at = h0.size();
  std::vector<size_t> recVars;
  for (size_t i = 0; i < m.vars.size(); i++) {
    const auto &v = m.vars[i];
    bool isRec = !v.dims.empty() && m.dims[v.dims[0]].unlimited;
    if (isRec) { recVars.push_back(i); continue; }
    begins[i] = at;
    at += v.vals.size() * 8;
  }
  uint64_t recsize = 0;
  for (size_t i : recVars) { begins[i] = at + recsize; recsize += m.vars[i].vals.size() / std::max<uint64_t>(1, numrecs) * 8; }
  if (!v2 && at + recsize * numrecs > 0x7FFFFFFFull) { err = "the data is over 2 GB - use format=\"64bit\" or \"nc4\""; return ""; }
  std::string out = header(begins);
  for (size_t i = 0; i < m.vars.size(); i++) {
    if (std::find(recVars.begin(), recVars.end(), i) != recVars.end()) continue;
    for (double d : m.vars[i].vals) putF64BE(out, d);
  }
  for (uint64_t r = 0; r < numrecs; r++)
    for (size_t i : recVars) {
      size_t per = m.vars[i].vals.size() / static_cast<size_t>(numrecs);
      for (size_t k = 0; k < per; k++) putF64BE(out, m.vars[i].vals[static_cast<size_t>(r) * per + k]);
    }
  return out;
}

H5WAttr nulTermText(const std::string &name, const std::string &s) {
  H5WAttr a;
  a.name = name;
  a.data = h5ScalarText(s);
  a.data.type = h5String(s.size() + 1);
  a.data.type.strPad = 0;
  a.data.raw = s + '\0';
  return a;
}

H5WAttr valueAttr(const std::string &name, const Value &v) {
  H5WAttr a;
  a.name = name;
  if (v.isText && !v.isArray && !v.isMatrix) { a.data = h5ScalarText(v.text()); return a; }
  std::vector<double> n = optNumbers(v);
  a.data = n.size() == 1 ? h5ScalarNumber(n[0]) : h5Numbers({n.size()}, n);
  return a;
}

std::string writeNc4(const OutModel &m, const std::string &compress, int level, std::string &err) {
  H5WNode root;
  root.name = "/";
  for (const auto &kv : m.gatts) root.attrs.push_back(valueAttr(kv.first, kv.second));
  std::map<std::string, std::vector<std::pair<std::string, int>>> users; // dim -> (var path, axis)
  for (const auto &v : m.vars)
    for (size_t k = 0; k < v.dims.size(); k++) if (!v.coord) users[m.dims[v.dims[k]].name].push_back({"/" + v.name, static_cast<int>(k)});
  for (size_t di = 0; di < m.dims.size(); di++) {
    const NcDim &d = m.dims[di];
    H5WNode n;
    n.name = d.name;
    n.group = false;
    const OutVar *cv = nullptr;
    for (const auto &v : m.vars) if (v.coord && v.name == d.name) cv = &v;
    if (cv) {
      n.data = h5Numbers({static_cast<size_t>(d.len)}, cv->vals);
      for (const auto &kv : cv->attrs) n.attrs.push_back(valueAttr(kv.first, kv.second));
    } else {
      n.data.type = h5Float(4);
      n.data.dims = {d.len};
      n.allocate = false;
      char buf[96];
      std::snprintf(buf, sizeof buf, "This is a netCDF dimension but not a netCDF variable.%10llu", static_cast<unsigned long long>(d.len));
      n.attrs.push_back(nulTermText("NAME", buf));
    }
    if (d.unlimited) { n.data.maxDims = {H5_UNDEF}; n.chunk = {std::max<uint64_t>(1, std::min<uint64_t>(d.len, 1024))}; }
    if (cv) n.attrs.push_back(nulTermText("NAME", d.name));
    n.attrs.push_back(nulTermText("CLASS", "DIMENSION_SCALE"));
    H5WAttr id;
    id.name = "_Netcdf4Dimid";
    id.data = h5ScalarNumber(static_cast<double>(di), h5Int(4, true));
    n.attrs.push_back(id);
    const auto &u = users[d.name];
    if (!u.empty()) { // REFERENCE_LIST: {dataset ref, dimension index}
      H5WAttr rl;
      rl.name = "REFERENCE_LIST";
      rl.data.type = h5Compound({"dataset", "dimension"}, {h5Ref(), h5Int(4, true)});
      rl.data.dims = {u.size()};
      for (const auto &x : u) {
        rl.data.refs.push_back({rl.data.raw.size(), x.first});
        rl.data.raw.append(8, '\0');
        std::string i4;
        for (int b = 0; b < 4; b++) i4.push_back(static_cast<char>((x.second >> (8 * b)) & 0xFF));
        rl.data.raw += i4;
      }
      n.attrs.push_back(rl);
    }
    root.kids.push_back(std::move(n));
  }
  for (const auto &v : m.vars) {
    if (v.coord) continue;
    if (m.dim(v.name) >= 0) { err = "variable '" + v.name + "' has the name of a dimension but is not 1-D along it"; return ""; }
    H5WNode n;
    n.name = v.name;
    n.group = false;
    std::vector<size_t> shape;
    for (int d : v.dims) shape.push_back(static_cast<size_t>(m.dims[d].len));
    n.data = h5Numbers(shape, v.vals);
    if (v.dims.empty()) n.data.scalar = true;
    bool unl = false;
    for (int d : v.dims) if (m.dims[d].unlimited) unl = true;
    if (unl) { n.data.maxDims.clear(); for (int d : v.dims) n.data.maxDims.push_back(m.dims[d].unlimited ? H5_UNDEF : m.dims[d].len); }
    if (!v.dims.empty() && (compress != "none" || unl)) {
      n.chunk = h5AutoChunk(n.data.dims, 8);
      if (compress != "none") { n.compress = "gzip"; n.level = level; n.shuffle = true; }
    }
    for (const auto &kv : v.attrs) {
      if (kv.first == "_FillValue") { H5WAttr f; f.name = kv.first; f.data = h5ScalarNumber(optNumber(kv.second, 0)); n.attrs.push_back(f); }
      else n.attrs.push_back(valueAttr(kv.first, kv.second));
    }
    if (!v.dims.empty()) { // DIMENSION_LIST: one list of references per axis
      H5WAttr dl;
      dl.name = "DIMENSION_LIST";
      dl.data.type = h5VarLen(h5Ref());
      dl.data.dims = {v.dims.size()};
      for (int d : v.dims) {
        H5WData::Item it;
        it.raw.assign(8, '\0');
        it.count = 1;
        it.refs.push_back({0, "/" + m.dims[d].name});
        dl.data.items.push_back(it);
      }
      n.attrs.push_back(dl);
    }
    root.kids.push_back(std::move(n));
  }
  return writeH5(root, 0, err);
}

// save_<fmt>(file, data, var, dims, coords, units, fill_val, compress, level, unlimited, boxes, format)
Value saveNc(const std::string &fn, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev(fn, file);
  auto fail = [&](const std::string &msg) { ctx.fail(msg); return Value(0.0); };
  OutModel m;
  std::vector<std::string> dimSpec = optTextList(a[3]);
  std::string unlimited = optText(a[9]);
  std::string compress = lower(optText(a[7], "zlib"));
  if (compress == "gzip" || compress == "deflate" || compress == "yes" || compress == "zlib") compress = "zlib";
  else if (compress == "no" || compress == "none") compress = "none";
  else return fail("compress must be \"zlib\" or \"none\"");
  int level = static_cast<int>(optInt(a[8], 5));
  if (level < 0 || level > 9) return fail("level must be 0..9");
  std::string format = lower(optText(a[11], "nc4"));
  if (format != "nc4" && format != "netcdf4" && format != "classic" && format != "64bit") return fail("format must be \"nc4\", \"classic\" or \"64bit\"");
  bool nc4 = format == "nc4" || format == "netcdf4";
  // variables
  std::vector<std::pair<std::string, Value>> data;
  if (a[1].isDict) { std::vector<std::string> ks; for (const auto &kv : a[1].dict()) ks.push_back(kv.first); std::sort(ks.begin(), ks.end()); for (auto &k : ks) data.push_back({k, a[1].dict().at(k)}); }
  else data.push_back({optText(a[2], "data"), a[1]});
  auto addDim = [&](const std::string &name, uint64_t len) -> int {
    int i = m.dim(name);
    if (i >= 0) return m.dims[i].len == len ? i : -2;
    NcDim d;
    d.name = name;
    d.len = len;
    d.unlimited = name == unlimited;
    m.dims.push_back(d);
    return static_cast<int>(m.dims.size() - 1);
  };
  // coordinates first, so dims take their lengths
  if (given(a[4])) {
    if (!a[4].isDict) return fail("coords must be a dict of name -> vector");
    std::vector<std::string> ks;
    for (const auto &kv : a[4].dict()) ks.push_back(kv.first);
    std::sort(ks.begin(), ks.end());
    for (const auto &k : ks) {
      std::vector<double> c = optNumbers(a[4].dict().at(k));
      if (!dimSpec.empty() && std::find(dimSpec.begin(), dimSpec.end(), k) == dimSpec.end())
        return fail("coords '" + k + "' is not one of dims");
      OutVar cv;
      cv.name = k;
      cv.coord = true;
      cv.vals = c;
      cv.dims = {addDim(k, c.size())};
      m.vars.push_back(cv);
    }
  }
  for (const auto &kv : data) {
    std::vector<size_t> shape;
    std::vector<double> vals;
    if (!ndToRowMajor(kv.second, shape, vals)) {
      if (kv.second.isText) { // a text value becomes a global attribute
        m.gatts.push_back({kv.first, kv.second});
        continue;
      }
      return fail("'" + kv.first + "' is not numeric data");
    }
    if (shape.size() == 2 && shape[0] == 1 && dimSpec.size() != 2) shape = {shape[1]}; // row vector -> 1-D
    OutVar v;
    v.name = kv.first;
    v.vals = vals;
    std::vector<std::string> names = dimSpec.size() == shape.size() ? dimSpec : std::vector<std::string>{};
    if (!dimSpec.empty() && names.empty() && data.size() == 1)
      return fail("dims has " + std::to_string(dimSpec.size()) + " names but the data has " + std::to_string(shape.size()) + " dimension(s)");
    for (size_t k = 0; k < shape.size(); k++) {
      std::string dn = names.empty() ? (shape.size() == 1 ? kv.first + "_dim" : kv.first + "_dim" + std::to_string(k + 1)) : names[k];
      int di = addDim(dn, shape[k]);
      if (di == -2) {
        return fail("dimension '" + dn + "' is " + std::to_string(m.dims[m.dim(dn)].len) + " long (from its coordinate) but '" + kv.first + "' is " + std::to_string(shape[k]) + " along it");
      }
      v.dims.push_back(di);
    }
    if (given(a[5])) v.attrs.push_back({"units", Value(optText(a[5]))});
    if (given(a[6]) && !std::isnan(optNumber(a[6], std::nan("")))) {
      double fv = optNumber(a[6], 0);
      for (double &x : v.vals) if (std::isnan(x)) x = fv;
      v.attrs.push_back({"_FillValue", Value(fv)});
    }
    m.vars.push_back(v);
  }
  if (!unlimited.empty() && m.dim(unlimited) < 0) return fail("unlimited=\"" + unlimited + "\" is not one of the dimensions");
  if (!unlimited.empty() && !nc4) {
    int ui = m.dim(unlimited);
    for (const auto &v : m.vars) for (size_t k = 1; k < v.dims.size(); k++) if (v.dims[k] == ui) return fail("classic NetCDF needs the unlimited dimension first");
    // the unlimited dimension must come first in the dimension list order of every record variable; fine as is
  }
  // global attributes
  m.gatts.insert(m.gatts.begin(), {"Conventions", Value("CF-1.8")});
  m.gatts.push_back({"history", Value("written by NC " + fn)});
  if (given(a[10])) {
    if (a[10].isDict) {
      std::vector<std::string> ks;
      for (const auto &kv : a[10].dict()) ks.push_back(kv.first);
      std::sort(ks.begin(), ks.end());
      for (const auto &k : ks) m.gatts.push_back({k, a[10].dict().at(k)});
    } else {
      std::vector<std::string> bx = optTextList(a[10]);
      for (size_t i = 0; i < bx.size(); i++) m.gatts.push_back({bx.size() == 1 ? "comment" : "box_" + std::to_string(i + 1), Value(bx[i])});
    }
  }
  std::string bytes = nc4 ? writeNc4(m, compress, level, err) : writeClassic(m, format == "64bit", err);
  if (!err.empty()) return fail(err);
  if (!writeFile(file, bytes, false, err)) return fail(err);
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerNetcdf(Registry &reg) {
  for (const char *ext : {"nc", "cdf"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, var=\"\", coords=\"\", slice=\"\", scale=true, box=true",
             "read a NetCDF variable (the main one by default) with CF scale_factor / add_offset / _FillValue applied", "xarray.open_dataset(...)[var]", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readNc("read_" + e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file", "open a NetCDF file as a dataset (D.vars, D.dims, D.coords.lat, D.temp.units, D.temp.sel(lat=...))",
          "xarray.open_dataset", [e](const std::vector<Value> &a, CallContext &ctx) { return loadNc("load_" + e, a, ctx); });
    addFn(reg, "save_" + e,
          "file, data, var=\"\", dims=\"\", coords=\"\", units=\"\", fill_val=\"\", compress=\"zlib\", level=5, unlimited=\"\", boxes=\"\", format=\"nc4\"",
          "write NetCDF-4 (deflate) or classic NetCDF with named dimensions, coordinates and CF attributes", "xarray.Dataset.to_netcdf",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveNc("save_" + e, a, ctx); });
  }
  addFn(reg, "NcNcVar.sel", "V, lat=\"\", lon=\"\", time=\"\", level=\"\", depth=\"\", x=\"\", y=\"\", z=\"\", coords=\"\"",
        "values at the nearest coordinates (lat=13.08) or inside ranges (time=[0, 10])", "xarray.DataArray.sel", selMethod);
  addFn(reg, "NcNcVar.read", "V, slice=\"\"", "read (part of) a NetCDF variable from its file", "xarray.DataArray.isel",
        [](const std::vector<Value> &a, CallContext &ctx) { return readVarMethod(a, ctx, true); });
  addFn(reg, "NcNetCDF.read", "D, var=\"\", slice=\"\"", "read (part of) a NetCDF variable by name", "xarray.Dataset.__getitem__",
        [](const std::vector<Value> &a, CallContext &ctx) { return readVarMethod(a, ctx, false); });
}

} // namespace io
} // namespace nc
