// TCP sockets and the hashes the database protocols need (PostgreSQL MD5 /
// SCRAM-SHA-256, MySQL native / caching_sha2 passwords). Hand-written.
#ifndef NC_IO_NET_H
#define NC_IO_NET_H

#include <cstdint>
#include <string>

namespace nc {
namespace io {

std::string md5(const std::string &s);       // 16 raw bytes
std::string sha1(const std::string &s);      // 20 raw bytes
std::string sha256(const std::string &s);    // 32 raw bytes
std::string hmacSha256(const std::string &key, const std::string &msg);
std::string pbkdf2Sha256(const std::string &password, const std::string &salt, int iterations);
std::string hexOf(const std::string &raw);
std::string base64Encode(const std::string &s);
std::string base64Decode(const std::string &s);
std::string randomBytes(size_t n);

class TcpConn {
public:
  TcpConn() = default;
  ~TcpConn();
  TcpConn(const TcpConn &) = delete;
  TcpConn &operator=(const TcpConn &) = delete;
  bool connect(const std::string &host, int port, std::string &err, int timeoutMs = 10000);
  bool send(const std::string &data, std::string &err);
  bool recv(size_t n, std::string &out, std::string &err); // exactly n bytes
  void close();

private:
  intptr_t sock_ = -1;
};

// "scheme://user:pass@host:port/db?opt=v" parts.
struct DbUri {
  std::string scheme, user, password, host = "localhost", database;
  int port = 0;
  bool parse(const std::string &uri, std::string &err);
};

} // namespace io
} // namespace nc

#endif // NC_IO_NET_H
