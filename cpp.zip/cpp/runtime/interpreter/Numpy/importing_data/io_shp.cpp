// CATEGORY 17 - read_/load_/save_ shp, shx, dbf: Esri shapefiles (all 2-D,
// Z and M geometry types except MultiPatch), the .shx index, dBASE III
// attribute tables, .prj (CRS), .cpg (encoding) and .shp.xml (metadata).
#include <algorithm>
#include <array>
#include <cmath>
#include <filesystem>
#include <iostream>
#include <map>
#include <set>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_formats.h"
#include "io_geo.h"
#include "io_markup.h"
#include "io_sql.h"

namespace nc {
namespace io {

std::string upperAscii(std::string s); // io_fits.cpp

namespace {

using Pt = std::array<double, 4>; // x y z m

struct Geom {
  int type = 0; // shapefile type code
  std::vector<std::vector<Pt>> parts;
  bool hasZ() const { return type == 11 || type == 13 || type == 15 || type == 18; }
  int base() const { int t = type % 10; return t == 1 ? 1 : t == 3 ? 3 : t == 5 ? 5 : t == 8 ? 8 : 0; }
  std::array<double, 4> bbox() const {
    std::array<double, 4> b = {INFINITY, INFINITY, -INFINITY, -INFINITY};
    for (const auto &p : parts) for (const auto &q : p) { b[0] = std::min(b[0], q[0]); b[1] = std::min(b[1], q[1]); b[2] = std::max(b[2], q[0]); b[3] = std::max(b[3], q[1]); }
    return b;
  }
};

const char *typeName(int base) { return base == 1 ? "Point" : base == 3 ? "LineString" : base == 5 ? "Polygon" : base == 8 ? "MultiPoint" : "Null"; }

std::string stem(const std::string &file) {
  std::filesystem::path p(file);
  p.replace_extension("");
  return p.string();
}

// ---- geometry -------------------------------------------------------------------------------

double ringArea(const std::vector<Pt> &r) { // > 0 counter-clockwise
  double a = 0;
  for (size_t i = 0; i + 1 < r.size(); i++) a += r[i][0] * r[i + 1][1] - r[i + 1][0] * r[i][1];
  return a / 2;
}

bool inside(const std::vector<Pt> &ring, double x, double y) {
  bool in = false;
  for (size_t i = 0, j = ring.size() - 1; i < ring.size(); j = i++)
    if ((ring[i][1] > y) != (ring[j][1] > y) && x < (ring[j][0] - ring[i][0]) * (y - ring[i][1]) / (ring[j][1] - ring[i][1]) + ring[i][0]) in = !in;
  return in;
}

// polygon rings -> polygons [outer, holes...] (shapefile: outer clockwise)
std::vector<std::vector<std::vector<Pt>>> polygons(const Geom &g) {
  std::vector<std::vector<std::vector<Pt>>> polys;
  std::vector<const std::vector<Pt> *> holes;
  for (const auto &r : g.parts) { if (ringArea(r) <= 0) polys.push_back({r}); else holes.push_back(&r); }
  for (const auto *h : holes) {
    bool placed = false;
    for (auto &p : polys) if (!h->empty() && inside(p[0], (*h)[0][0], (*h)[0][1])) { p.push_back(*h); placed = true; break; }
    if (!placed) polys.push_back({*h}); // a lone counter-clockwise ring: treat as an outer ring
  }
  return polys;
}

std::string num(double v) { return numberText(v); }

std::string wkt(const Geom &g) {
  bool z = g.hasZ();
  auto pt = [&](const Pt &p) { return num(p[0]) + " " + num(p[1]) + (z ? " " + num(p[2]) : ""); };
  auto seq = [&](const std::vector<Pt> &v) { std::string s = "("; for (size_t i = 0; i < v.size(); i++) s += (i ? ", " : "") + pt(v[i]); return s + ")"; };
  std::string zs = z ? " Z" : "";
  switch (g.base()) {
  case 1: return g.parts.empty() || g.parts[0].empty() ? "POINT EMPTY" : "POINT" + zs + " (" + pt(g.parts[0][0]) + ")";
  case 8: { std::string s = "MULTIPOINT" + zs + " ("; size_t k = 0; for (const auto &p : g.parts[0]) s += (k++ ? ", " : "") + std::string("(") + pt(p) + ")"; return s + ")"; }
  case 3:
    if (g.parts.size() == 1) return "LINESTRING" + zs + " " + seq(g.parts[0]);
    else { std::string s = "MULTILINESTRING" + zs + " ("; for (size_t i = 0; i < g.parts.size(); i++) s += (i ? ", " : "") + seq(g.parts[i]); return s + ")"; }
  case 5: {
    auto polys = polygons(g);
    auto poly = [&](const std::vector<std::vector<Pt>> &p) { std::string s = "("; for (size_t i = 0; i < p.size(); i++) s += (i ? ", " : "") + seq(p[i]); return s + ")"; };
    if (polys.size() == 1) return "POLYGON" + zs + " " + poly(polys[0]);
    std::string s = "MULTIPOLYGON" + zs + " (";
    for (size_t i = 0; i < polys.size(); i++) s += (i ? ", " : "") + poly(polys[i]);
    return s + ")";
  }
  }
  return "GEOMETRYCOLLECTION EMPTY";
}

// WKT -> Geom (POINT, MULTIPOINT, LINESTRING, MULTILINESTRING, POLYGON, MULTIPOLYGON; Z optional)
bool parseWkt(const std::string &text, Geom &g, std::string &err) {
  std::string s = lower(trim(text));
  size_t p = 0;
  auto word = [&]() { while (p < s.size() && s[p] == ' ') p++; size_t b = p; while (p < s.size() && std::isalpha(static_cast<unsigned char>(s[p]))) p++; return s.substr(b, p - b); };
  std::string kind = word();
  std::string extra = word();
  bool z = extra == "z" || extra == "zm";
  if (extra == "empty") { g.type = kind == "point" ? 1 : kind.find("line") != std::string::npos ? 3 : kind.find("polygon") != std::string::npos ? 5 : 8; return true; }
  if (!extra.empty() && extra != "z" && extra != "m" && extra != "zm") { err = "bad WKT near '" + extra + "'"; return false; }
  std::function<bool(int, std::vector<std::vector<Pt>> &)> nest;
  auto skip = [&]() { while (p < s.size() && s[p] == ' ') p++; };
  auto point = [&](Pt &pt) {
    skip();
    pt = {0, 0, 0, 0};
    for (int k = 0; k < 4; k++) {
      skip();
      if (p >= s.size() || s[p] == ',' || s[p] == ')') break;
      char *e = nullptr;
      pt[k] = std::strtod(s.c_str() + p, &e);
      if (e == s.c_str() + p) return false;
      p = static_cast<size_t>(e - s.c_str());
    }
    return true;
  };
  auto expect = [&](char c) { skip(); if (p < s.size() && s[p] == c) { p++; return true; } return false; };
  auto ring = [&](std::vector<Pt> &out) {
    if (!expect('(')) return false;
    do { Pt pt; bool paren = expect('('); if (!point(pt)) return false; if (paren && !expect(')')) return false; out.push_back(pt); } while (expect(','));
    return expect(')');
  };
  g.parts.clear();
  if (kind == "point") { g.type = z ? 11 : 1; Pt pt; if (!expect('(') || !point(pt) || !expect(')')) { err = "bad POINT"; return false; } g.parts.push_back({pt}); return true; }
  if (kind == "multipoint") { g.type = z ? 18 : 8; std::vector<Pt> v; if (!ring(v)) { err = "bad MULTIPOINT"; return false; } g.parts.push_back(v); return true; }
  if (kind == "linestring") { g.type = z ? 13 : 3; std::vector<Pt> v; if (!ring(v)) { err = "bad LINESTRING"; return false; } g.parts.push_back(v); return true; }
  if (kind == "multilinestring" || kind == "polygon") {
    g.type = kind == "polygon" ? (z ? 15 : 5) : (z ? 13 : 3);
    if (!expect('(')) { err = "bad " + kind; return false; }
    do { std::vector<Pt> v; if (!ring(v)) { err = "bad " + kind; return false; } g.parts.push_back(v); } while (expect(','));
    if (!expect(')')) { err = "bad " + kind; return false; }
    return true;
  }
  if (kind == "multipolygon") {
    g.type = z ? 15 : 5;
    if (!expect('(')) { err = "bad MULTIPOLYGON"; return false; }
    do {
      if (!expect('(')) { err = "bad MULTIPOLYGON"; return false; }
      do { std::vector<Pt> v; if (!ring(v)) { err = "bad MULTIPOLYGON"; return false; } g.parts.push_back(v); } while (expect(','));
      if (!expect(')')) { err = "bad MULTIPOLYGON"; return false; }
    } while (expect(','));
    if (!expect(')')) { err = "bad MULTIPOLYGON"; return false; }
    return true;
  }
  err = "WKT type '" + kind + "' is not built in (POINT, MULTIPOINT, LINESTRING, MULTILINESTRING, POLYGON, MULTIPOLYGON are)";
  return false;
}

// ---- reading ---------------------------------------------------------------------------------

struct Shapefile {
  int type = 0;
  std::array<double, 4> bbox = {0, 0, 0, 0};
  std::vector<Geom> geoms;
  Table attrs;
  std::vector<std::pair<double, double>> index; // byte offset, length
  std::string prj, cpg, xml, encoding = "utf-8";
  int epsg = 0;
  bool haveShp = false, haveDbf = false, haveShx = false;
};

bool readShp(const std::string &b, Shapefile &s, std::string &err) {
  if (b.size() < 100 || u32be(b, 0) != 9994) { err = "not a shapefile (.shp / .shx file code is not 9994)"; return false; }
  s.type = static_cast<int>(u32le(b, 32));
  for (int k = 0; k < 4; k++) s.bbox[k] = f64le(b, 36 + 8 * k);
  size_t p = 100;
  size_t end = std::min<size_t>(b.size(), static_cast<size_t>(u32be(b, 24)) * 2);
  while (p + 12 <= end) {
    size_t len = static_cast<size_t>(u32be(b, p + 4)) * 2;
    size_t c = p + 8;
    if (c + len > b.size()) { err = "a .shp record runs past the end of the file"; return false; }
    Geom g;
    g.type = static_cast<int>(u32le(b, c));
    int base = g.base();
    bool hz = g.hasZ(), hm = g.type >= 11;
    if (g.type == 31) { err = "MultiPatch shapes are not built in"; return false; }
    if (base == 1) {
      Pt pt = {f64le(b, c + 4), f64le(b, c + 12), hz ? f64le(b, c + 20) : 0, hm ? f64le(b, c + (hz ? 28 : 20)) : 0};
      g.parts.push_back({pt});
    } else if (base == 8) {
      size_t n = u32le(b, c + 36), q = c + 40;
      std::vector<Pt> pts(n);
      for (size_t i = 0; i < n; i++) pts[i] = {f64le(b, q + 16 * i), f64le(b, q + 16 * i + 8), 0, 0};
      q += 16 * n;
      if (hz && q + 16 + 8 * n <= c + len) for (size_t i = 0; i < n; i++) pts[i][2] = f64le(b, q + 16 + 8 * i);
      g.parts.push_back(pts);
    } else if (base == 3 || base == 5) {
      size_t np = u32le(b, c + 36), n = u32le(b, c + 40), q = c + 44;
      std::vector<size_t> starts(np);
      for (size_t i = 0; i < np; i++) starts[i] = u32le(b, q + 4 * i);
      q += 4 * np;
      if (q + 16 * n > c + len) { err = "a .shp record is damaged"; return false; }
      std::vector<Pt> pts(n);
      for (size_t i = 0; i < n; i++) pts[i] = {f64le(b, q + 16 * i), f64le(b, q + 16 * i + 8), 0, 0};
      q += 16 * n;
      if (hz && q + 16 + 8 * n <= c + len) { for (size_t i = 0; i < n; i++) pts[i][2] = f64le(b, q + 16 + 8 * i); q += 16 + 8 * n; }
      if (hm && q + 16 + 8 * n <= c + len) for (size_t i = 0; i < n; i++) pts[i][3] = f64le(b, q + 16 + 8 * i);
      for (size_t i = 0; i < np; i++) {
        size_t from = starts[i], to = i + 1 < np ? starts[i + 1] : n;
        if (from > to || to > n) { err = "a .shp record has bad part offsets"; return false; }
        g.parts.push_back(std::vector<Pt>(pts.begin() + static_cast<long>(from), pts.begin() + static_cast<long>(to)));
      }
    }
    s.geoms.push_back(std::move(g));
    p = c + len;
  }
  s.haveShp = true;
  return true;
}

bool readShx(const std::string &b, Shapefile &s, std::string &err) {
  if (b.size() < 100 || u32be(b, 0) != 9994) { err = "not a shapefile index (.shx file code is not 9994)"; return false; }
  if (!s.haveShp) { s.type = static_cast<int>(u32le(b, 32)); for (int k = 0; k < 4; k++) s.bbox[k] = f64le(b, 36 + 8 * k); }
  for (size_t p = 100; p + 8 <= b.size(); p += 8) s.index.push_back({u32be(b, p) * 2.0, u32be(b, p + 4) * 2.0});
  s.haveShx = true;
  return true;
}

bool readDbf(const std::string &b, Shapefile &s, std::string &err) {
  if (b.size() < 33) { err = "not a dBASE file (too short)"; return false; }
  int ver = static_cast<unsigned char>(b[0]) & 7;
  if (ver != 3 && ver != 4 && ver != 5) { err = "not a dBASE III / IV file (version byte " + std::to_string(static_cast<unsigned char>(b[0])) + ")"; return false; }
  size_t n = u32le(b, 4), hlen = u16le(b, 8), rlen = u16le(b, 10);
  int ldid = static_cast<unsigned char>(b[29]);
  if (s.cpg.empty() && (ldid == 0x57 || ldid == 0x03)) s.encoding = "cp1252";
  struct F { std::string name; char type; size_t len, dec, off; };
  std::vector<F> fs;
  size_t off = 1;
  for (size_t p = 32; p + 32 <= hlen && b[p] != 0x0D; p += 32) {
    F f;
    f.name = b.substr(p, 11);
    f.name = f.name.substr(0, f.name.find('\0'));
    f.type = b[p + 11];
    f.len = static_cast<unsigned char>(b[p + 16]);
    f.dec = static_cast<unsigned char>(b[p + 17]);
    if (f.type == 'C') f.len += f.dec * 256; // long character fields
    f.off = off;
    off += f.len;
    fs.push_back(f);
  }
  for (auto &f : fs) { std::string u; decodeText(f.name, s.encoding, u, err); err.clear(); s.attrs.cols.push_back(u.empty() ? f.name : u); }
  for (size_t r = 0; r < n; r++) {
    size_t p = hlen + r * rlen;
    if (p + rlen > b.size()) break;
    std::vector<Value> row;
    bool deleted = b[p] == '*';
    for (const auto &f : fs) {
      std::string raw = b.substr(p + f.off, f.len);
      std::string t = trim(raw);
      if (f.type == 'N' || f.type == 'F') row.push_back(t.empty() || t[0] == '*' ? Value(std::nan("")) : Value(std::atof(t.c_str())));
      else if (f.type == 'L') row.push_back(t == "T" || t == "t" || t == "Y" || t == "y" ? Value::boolean(true) : t == "F" || t == "f" || t == "N" || t == "n" ? Value::boolean(false) : Value(std::nan("")));
      else if (f.type == 'D') row.push_back(t.size() == 8 ? Value(t.substr(0, 4) + "-" + t.substr(4, 2) + "-" + t.substr(6, 2)) : Value(std::nan("")));
      else {
        while (!raw.empty() && (raw.back() == ' ' || raw.back() == '\0')) raw.pop_back();
        std::string u;
        if (!decodeText(raw, s.encoding, u, err)) { u = raw; err.clear(); }
        row.push_back(Value(u));
      }
    }
    (void)deleted;
    s.attrs.rows.push_back(std::move(row));
  }
  normalizeTable(s.attrs);
  s.haveDbf = true;
  return true;
}

// any of .shp / .shx / .dbf: the companions next to it are read too
bool openShapefile(const std::string &file, const std::string &fmt, Shapefile &s, std::string &err) {
  std::string base = stem(file);
  auto side = [&](const std::string &ext, std::string &out) {
    for (const std::string &e : {ext, upperAscii(ext)}) if (fileExists(base + "." + e)) return readFile(base + "." + e, out, err);
    return false;
  };
  side("cpg", s.cpg);
  err.clear();
  if (!s.cpg.empty()) s.encoding = lower(trim(s.cpg)) == "utf-8" || lower(trim(s.cpg)) == "utf8" ? "utf-8" : lower(trim(s.cpg));
  std::string bytes;
  if (!readSource(file, bytes, err)) return false;
  if (fmt == "shp" && !readShp(bytes, s, err)) return false;
  if (fmt == "shx" && !readShx(bytes, s, err)) return false;
  if (fmt == "dbf" && !readDbf(bytes, s, err)) return false;
  if (fmt != "shp") { std::string b2; if (side("shp", b2) && !readShp(b2, s, err)) return false; err.clear(); }
  if (fmt != "shx") { std::string b2; if (side("shx", b2)) readShx(b2, s, err); err.clear(); }
  if (fmt != "dbf") { std::string b2; if (side("dbf", b2) && !readDbf(b2, s, err)) return false; err.clear(); }
  side("prj", s.prj);
  err.clear();
  if (!readFile(file + ".xml", s.xml, err)) s.xml.clear();
  err.clear();
  s.epsg = crsEpsg(s.prj);
  if (s.haveShp && s.haveDbf && !s.attrs.rows.empty() && s.attrs.rows.size() != s.geoms.size()) {
    err = "the .dbf has " + std::to_string(s.attrs.rows.size()) + " records but the .shp has " + std::to_string(s.geoms.size()) + " shapes";
    return false;
  }
  return true;
}

Value geomValue(const Geom &g) {
  Fields f;
  int base = g.base();
  std::string t = typeName(base);
  if (base == 3 && g.parts.size() > 1) t = "MultiLineString";
  if (base == 5 && polygons(g).size() > 1) t = "MultiPolygon";
  f["type"] = Value(t);
  std::vector<std::vector<double>> all;
  std::vector<double> xs, ys, zs;
  std::vector<Value> parts;
  for (const auto &p : g.parts) {
    std::vector<std::vector<double>> m;
    for (const auto &q : p) {
      std::vector<double> r = {q[0], q[1]};
      if (g.hasZ()) r.push_back(q[2]);
      m.push_back(r);
      all.push_back(r);
      xs.push_back(q[0]);
      ys.push_back(q[1]);
      zs.push_back(q[2]);
    }
    parts.push_back(numpy::makeMatrix(m));
  }
  f["coords"] = numpy::makeMatrix(all);
  f["x"] = numberList(xs);
  f["y"] = numberList(ys);
  if (g.hasZ()) f["z"] = numberList(zs);
  f[base == 5 ? "rings" : "parts"] = Value(parts);
  auto bb = g.bbox();
  f["bbox"] = numberList({bb[0], bb[1], bb[2], bb[3]});
  f["wkt"] = Value(wkt(g));
  return makeObject("NcGeom", f);
}

bool intersects(const std::array<double, 4> &a, const std::vector<double> &b) { return !(a[2] < b[0] || a[0] > b[2] || a[3] < b[1] || a[1] > b[3]); }

// selections shared by read_ and load_: bbox, crs reprojection
bool prepare(Shapefile &s, const Value &bbox, const Value &crs, std::vector<size_t> &keep, std::string &err) {
  keep.clear();
  size_t n = s.haveShp ? s.geoms.size() : s.attrs.rows.size();
  if (given(crs)) {
    int to = crsEpsg(optText(crs));
    if (!to) { err = "crs \"" + optText(crs) + "\" is not an EPSG code I recognise"; return false; }
    if (!s.epsg) { err = "the shapefile has no .prj, so it cannot be reprojected (its CRS is unknown)"; return false; }
    for (auto &g : s.geoms) for (auto &p : g.parts) for (auto &q : p) if (!crsTransform(s.epsg, to, q[0], q[1], err)) return false;
    s.epsg = to;
    s.prj = crsWkt(to);
  }
  std::vector<double> bb;
  if (given(bbox)) {
    bb = optNumbers(bbox);
    if (bb.size() != 4) { err = "bbox must be [xmin, ymin, xmax, ymax]"; return false; }
    if (bb[0] > bb[2]) std::swap(bb[0], bb[2]);
    if (bb[1] > bb[3]) std::swap(bb[1], bb[3]);
  }
  for (size_t i = 0; i < n; i++) if (bb.empty() || !s.haveShp || intersects(s.geoms[i].bbox(), bb)) keep.push_back(i);
  return true;
}

Table featureTable(const Shapefile &s, const std::vector<size_t> &keep, bool withGeom) {
  Table t;
  t.cols = s.attrs.cols;
  if (withGeom && s.haveShp) t.cols.push_back("geometry");
  for (size_t i : keep) {
    std::vector<Value> row = i < s.attrs.rows.size() ? s.attrs.rows[i] : std::vector<Value>(s.attrs.cols.size(), Value(std::nan("")));
    if (withGeom && s.haveShp) row.push_back(Value(wkt(s.geoms[i])));
    t.rows.push_back(std::move(row));
  }
  return t;
}

std::vector<std::string> boxesOf(const Shapefile &s) {
  std::vector<std::string> out;
  if (!s.xml.empty()) out.push_back("shp.xml: " + s.xml);
  if (!s.cpg.empty()) out.push_back("encoding: " + trim(s.cpg));
  if (!s.prj.empty()) out.push_back("prj: " + s.prj);
  return out;
}

// read_<fmt>(file, bbox, cols, rows, where, crs, box)
void readShape(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  Shapefile s;
  if (!openShapefile(file, fmt, s, err)) return ctx.fail(err);
  std::vector<size_t> keep;
  if (!prepare(s, a[1], a[5], keep, err)) return ctx.fail(err);
  Table t;
  if (fmt == "shx") {
    t.cols = {"offset", "length"};
    for (size_t i : keep) if (i < s.index.size()) t.rows.push_back({Value(s.index[i].first), Value(s.index[i].second)});
  } else t = featureTable(s, keep, fmt == "shp");
  std::string where = optText(a[4]);
  if (!where.empty()) {
    std::vector<size_t> rows;
    if (!sqlFilter(t, where, {}, rows, err)) return ctx.fail("where: " + err);
    Table f;
    f.cols = t.cols;
    for (size_t r : rows) f.rows.push_back(t.rows[r]);
    t = f;
  }
  Value cols = a[2];
  if (given(cols) && fmt == "shp") { // keep the geometry with the chosen columns
    std::vector<std::string> c = optTextList(cols);
    if (std::find(c.begin(), c.end(), "geometry") == c.end()) c.push_back("geometry");
    cols = textList(c);
  }
  if (!selectTable(t, cols, a[3], err)) return ctx.fail(err);
  out.push_back(tableData(t));
  if (nout > 1) {
    Fields info;
    info["cols"] = textList(t.cols);
    info["rows"] = Value(static_cast<double>(t.rows.size()));
    info["geom_type"] = Value(typeName(s.type % 10 == 1 ? 1 : s.type % 10 == 3 ? 3 : s.type % 10 == 5 ? 5 : s.type % 10 == 8 ? 8 : 0));
    info["bbox"] = numberList({s.bbox[0], s.bbox[1], s.bbox[2], s.bbox[3]});
    info["crs"] = Value(s.epsg ? "EPSG:" + std::to_string(s.epsg) : s.prj);
    info["prj"] = Value(s.prj);
    info["encoding"] = Value(s.encoding);
    info["boxes"] = optBool(a[6], true) ? textList(boxesOf(s)) : textList({});
    out.push_back(makeObject("NcReadInfo", info));
  }
  ev.ok = true;
}

Value loadShape(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  Shapefile s;
  if (!openShapefile(file, fmt, s, err)) { ctx.fail(err); return Value(0.0); }
  std::vector<size_t> all;
  for (size_t i = 0; i < std::max(s.geoms.size(), s.attrs.rows.size()); i++) all.push_back(i);
  Fields extra;
  std::vector<Value> features, geoms;
  for (size_t i : all) {
    Fields ff;
    Fields at;
    if (i < s.attrs.rows.size()) for (size_t c = 0; c < s.attrs.cols.size(); c++) at[s.attrs.cols[c]] = s.attrs.rows[i][c];
    ff["attrs"] = Value(at);
    ff["id"] = Value(static_cast<double>(i));
    if (i < s.geoms.size()) {
      Value g = geomValue(s.geoms[i]);
      ff["geom"] = g;
      ff["bbox"] = *field(g, "bbox");
      geoms.push_back(g);
    }
    features.push_back(makeObject("NcFeature", ff));
  }
  extra["features"] = Value(std::move(features));
  extra["geom"] = Value(std::move(geoms));
  extra["attrs"] = tableObject(s.attrs);
  extra["bbox"] = numberList({s.bbox[0], s.bbox[1], s.bbox[2], s.bbox[3]});
  extra["crs"] = Value(s.epsg ? "EPSG:" + std::to_string(s.epsg) : s.prj);
  extra["epsg"] = Value(static_cast<double>(s.epsg));
  extra["prj"] = Value(s.prj);
  std::vector<std::vector<double>> idx;
  for (const auto &p : s.index) idx.push_back({p.first, p.second});
  extra["index_offsets"] = numpy::makeMatrix(idx);
  extra["boxes"] = textList(boxesOf(s));
  extra["encoding"] = Value(s.encoding);
  extra["geom_type"] = Value(typeName(s.type % 10 == 1 ? 1 : s.type % 10 == 3 ? 3 : s.type % 10 == 5 ? 5 : s.type % 10 == 8 ? 8 : 0));
  extra["count"] = Value(static_cast<double>(all.size()));
  extra["file"] = Value(file);
  ev.ok = true;
  return tableObject(s.attrs, extra, "NcShapefile");
}

// ---- writing ---------------------------------------------------------------------------------

std::string shpHeader(int type, size_t lengthBytes, const std::array<double, 4> &bb, double zmin, double zmax) {
  std::string h;
  putBE(h, 9994, 4);
  h.append(20, '\0');
  putBE(h, lengthBytes / 2, 4);
  putLE(h, 1000, 4);
  putLE(h, static_cast<uint32_t>(type), 4);
  for (double v : bb) putF64LE(h, v);
  putF64LE(h, zmin); putF64LE(h, zmax); putF64LE(h, 0); putF64LE(h, 0);
  return h;
}

std::string shapeRecord(const Geom &g, int type) {
  std::string r;
  putLE(r, static_cast<uint32_t>(type), 4);
  int base = type % 10 == 1 ? 1 : type % 10 == 3 ? 3 : type % 10 == 5 ? 5 : 8;
  bool z = type == 11 || type == 13 || type == 15 || type == 18;
  std::vector<Pt> pts;
  for (const auto &p : g.parts) pts.insert(pts.end(), p.begin(), p.end());
  if (base == 1) { putF64LE(r, pts[0][0]); putF64LE(r, pts[0][1]); if (z) { putF64LE(r, pts[0][2]); putF64LE(r, 0); } return r; }
  auto bb = g.bbox();
  for (double v : bb) putF64LE(r, v);
  if (base != 8) putLE(r, g.parts.size(), 4);
  putLE(r, pts.size(), 4);
  if (base != 8) { size_t at = 0; for (const auto &p : g.parts) { putLE(r, at, 4); at += p.size(); } }
  for (const auto &p : pts) { putF64LE(r, p[0]); putF64LE(r, p[1]); }
  if (z) {
    double zmin = INFINITY, zmax = -INFINITY;
    for (const auto &p : pts) { zmin = std::min(zmin, p[2]); zmax = std::max(zmax, p[2]); }
    putF64LE(r, zmin); putF64LE(r, zmax);
    for (const auto &p : pts) putF64LE(r, p[2]);
    putF64LE(r, 0); putF64LE(r, 0);
    for (size_t i = 0; i < pts.size(); i++) putF64LE(r, 0);
  }
  return r;
}

// geo_data -> geometries + attribute table
bool collect(const Value &data, std::vector<Geom> &geoms, Table &attrs, int &epsgFromData, std::string &err) {
  if (isObjectOf(data, "NcShapefile")) {
    const Value *gs = field(data, "geom"), *at = field(data, "attrs"), *ep = field(data, "epsg");
    if (gs) for (size_t i = 0; i < gs->length(); i++) { Geom g; const Value *w = field(gs->at(i), "wkt"); if (!w || !parseWkt(w->text(), g, err)) return false; geoms.push_back(g); }
    if (at && !valueToTable(*at, attrs, err)) return false;
    if (ep) epsgFromData = static_cast<int>(ep->number);
    return true;
  }
  if (isObjectOf(data, "NcGeom")) { Geom g; if (!parseWkt(field(data, "wkt")->text(), g, err)) return false; geoms.push_back(g); return true; }
  if (data.isArray && data.length() > 0 && isObjectOf(data.at(0), "NcGeom")) {
    for (size_t i = 0; i < data.length(); i++) { Geom g; const Value *w = field(data.at(i), "wkt"); if (!w || !parseWkt(w->text(), g, err)) return false; geoms.push_back(g); }
    return true;
  }
  Table t;
  if (!valueToTable(data, t, err, true)) return false;
  auto col = [&](std::initializer_list<const char *> names) -> int {
    for (const char *n : names) for (size_t c = 0; c < t.cols.size(); c++) if (lower(t.cols[c]) == n) return static_cast<int>(c);
    return -1;
  };
  int gc = col({"geometry", "wkt", "geom", "the_geom"});
  int xc = col({"x", "lon", "lng", "longitude", "easting"}), yc = col({"y", "lat", "latitude", "northing"}), zc = col({"z", "ele", "elevation", "alt", "altitude"});
  if (gc < 0 && (xc < 0 || yc < 0)) { err = "the data needs a 'geometry' column of WKT text, or x / y (lon / lat) columns"; return false; }
  std::set<int> used = {gc, xc, yc, zc};
  if (gc >= 0) used = {gc};
  for (size_t c = 0; c < t.cols.size(); c++) if (!used.count(static_cast<int>(c))) attrs.cols.push_back(t.cols[c]);
  for (const auto &r : t.rows) {
    Geom g;
    if (gc >= 0) { if (!parseWkt(cellText(r[static_cast<size_t>(gc)]), g, err)) return false; }
    else {
      auto numAt = [&](int c) { const Value &v = r[static_cast<size_t>(c)]; return v.isText ? std::atof(v.text().c_str()) : v.number; };
      g.type = zc >= 0 ? 11 : 1;
      g.parts.push_back({{numAt(xc), numAt(yc), zc >= 0 ? numAt(zc) : 0, 0}});
    }
    geoms.push_back(g);
    std::vector<Value> row;
    for (size_t c = 0; c < t.cols.size(); c++) if (!used.count(static_cast<int>(c))) row.push_back(r[c]);
    attrs.rows.push_back(row);
  }
  return true;
}

std::string writeDbf(const Table &t, const std::string &enc, std::string &err) {
  struct F { std::string name; char type; size_t len, dec; };
  std::vector<F> fs;
  std::set<std::string> names;
  bool truncated = false;
  for (size_t c = 0; c < t.cols.size(); c++) {
    std::string n;
    for (char ch : t.cols[c]) if (static_cast<unsigned char>(ch) < 128 && (std::isalnum(static_cast<unsigned char>(ch)) || ch == '_')) n.push_back(ch);
    if (n.empty()) n = "FIELD" + std::to_string(c + 1);
    if (n.size() > 10 || n != t.cols[c]) truncated = true;
    n = n.substr(0, 10);
    std::string u = n;
    for (int k = 1; names.count(u); k++) u = n.substr(0, 10 - std::to_string(k).size()) + std::to_string(k);
    names.insert(u);
    bool allNum = true, allBool = true, any = false;
    size_t maxLen = 1, dec = 0;
    for (const auto &r : t.rows) {
      const Value &v = r[c];
      if (!v.isText && std::isnan(v.number)) continue;
      any = true;
      if (v.isText) { allNum = allBool = false; std::string s; encodeText(v.text(), enc, s, err); maxLen = std::max(maxLen, s.size()); continue; }
      if (!v.isBool()) allBool = false;
      std::string s = numberText(v.number);
      size_t dot = s.find('.');
      if (dot != std::string::npos) dec = std::max(dec, s.size() - dot - 1);
    }
    err.clear();
    if (!any) { allNum = true; allBool = false; }
    if (allBool) fs.push_back({u, 'L', 1, 0});
    else if (allNum) fs.push_back({u, 'N', 19, std::min<size_t>(dec, 11)});
    else fs.push_back({u, 'C', std::min<size_t>(maxLen, 254), 0});
  }
  if (truncated) std::cerr << "Warning: dBASE field names are at most 10 ASCII characters - some columns were renamed\n";
  size_t rlen = 1;
  for (const auto &f : fs) rlen += f.len;
  std::string o;
  o.push_back(3);
  o.push_back(126); o.push_back(10); o.push_back(28); // last update yy mm dd
  putLE(o, t.rows.size(), 4);
  putLE(o, 32 + 32 * fs.size() + 1, 2);
  putLE(o, rlen, 2);
  o.append(17, '\0');
  o.push_back(enc == "utf-8" ? 0 : 0x57);
  o.append(2, '\0');
  for (const auto &f : fs) {
    std::string n = f.name;
    n.resize(11, '\0');
    o += n;
    o.push_back(f.type);
    o.append(4, '\0');
    o.push_back(static_cast<char>(f.len));
    o.push_back(static_cast<char>(f.dec));
    o.append(14, '\0');
  }
  o.push_back(0x0D);
  for (const auto &r : t.rows) {
    o.push_back(' ');
    for (size_t c = 0; c < fs.size(); c++) {
      const Value &v = r[c];
      bool null = !v.isText && std::isnan(v.number);
      std::string s;
      if (null) s = fs[c].type == 'L' ? "?" : "";
      else if (fs[c].type == 'L') s = v.number != 0 ? "T" : "F";
      else if (fs[c].type == 'N') { char buf[64]; std::snprintf(buf, sizeof buf, "%.*f", static_cast<int>(fs[c].dec), v.number); s = buf; }
      else { encodeText(cellText(v), enc, s, err); err.clear(); }
      if (s.size() > fs[c].len) s = s.substr(0, fs[c].len);
      if (fs[c].type == 'C') { s.resize(fs[c].len, ' '); o += s; }
      else { o.append(fs[c].len - s.size(), ' '); o += s; }
    }
  }
  o.push_back(0x1A);
  return o;
}

// save_<fmt>(file, geo_data, geom_type, crs, enc, bundle, boxes)
Value saveShape(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  std::vector<Geom> geoms;
  Table attrs;
  int dataEpsg = 0;
  if (fmt == "dbf" && !isObjectOf(a[1], "NcShapefile")) { if (!valueToTable(a[1], attrs, err, true)) return fail(err); }
  else if (!collect(a[1], geoms, attrs, dataEpsg, err)) return fail(err);
  std::string want = lower(optText(a[2]));
  int type = 0;
  for (const auto &g : geoms) {
    int t = g.base();
    if (t == 0) continue;
    if (type && type % 10 != t) {
      if ((type % 10 == 1 && t == 8) || (type % 10 == 8 && t == 1)) { type = g.hasZ() ? 18 : 8; continue; }
      return fail("all shapes of one shapefile must share a type - found " + std::string(typeName(type % 10)) + " and " + typeName(t) + " (save them to separate files)");
    }
    type = g.hasZ() ? t + 10 : t;
  }
  if (!want.empty()) {
    int w = want == "point" ? 1 : want == "multipoint" ? 8 : want == "line" || want == "linestring" || want == "polyline" ? 3 : want == "polygon" ? 5 : -1;
    if (w < 0) return fail("geom_type must be \"point\", \"multipoint\", \"line\" or \"polygon\"");
    if (type && type % 10 != w && !(w == 8 && type % 10 == 1)) return fail("geom_type=\"" + want + "\" does not match the data, which holds " + typeName(type % 10) + " shapes");
    if (!type || (w == 8 && type % 10 == 1)) type = w + (type > 10 ? 10 : 0);
  }
  if (!type && !geoms.empty()) type = 1;
  // polygons: outer rings clockwise, holes counter-clockwise, rings closed
  if (type % 10 == 5) for (auto &g : geoms) {
    for (auto &r : g.parts) if (r.size() > 1 && (r.front()[0] != r.back()[0] || r.front()[1] != r.back()[1])) r.push_back(r.front());
    // a ring inside an earlier outer ring is a hole (counter-clockwise), any other is an outer ring (clockwise)
    std::vector<std::vector<Pt>> outers;
    for (auto &r : g.parts) {
      bool hole = false;
      for (const auto &o : outers) if (!r.empty() && inside(o, r[0][0], r[0][1])) hole = true;
      if (!hole) { if (ringArea(r) > 0) std::reverse(r.begin(), r.end()); outers.push_back(r); }
      else if (ringArea(r) < 0) std::reverse(r.begin(), r.end());
    }
  }
  int epsg = given(a[3]) ? crsEpsg(optText(a[3])) : (dataEpsg ? dataEpsg : 4326);
  std::string prj = crsWkt(epsg);
  if (prj.empty() && given(a[3]) && lower(optText(a[3])).find("projcs") != std::string::npos) prj = optText(a[3]);
  if (prj.empty() && given(a[3]) && lower(optText(a[3])).find("geogcs") != std::string::npos) prj = optText(a[3]);
  if (prj.empty()) return fail("crs \"" + optText(a[3]) + "\" is not built in for .prj files - give EPSG:4326, EPSG:3857, an EPSG:326xx / 327xx UTM zone, or the WKT text itself");
  std::string enc = lower(optText(a[4], "utf-8"));
  if (enc == "utf8") enc = "utf-8";
  bool bundle = optBool(a[5], true);
  if (!geoms.empty() && !attrs.rows.empty() && attrs.rows.size() != geoms.size()) return fail("the attribute table has " + std::to_string(attrs.rows.size()) + " rows but there are " + std::to_string(geoms.size()) + " shapes");
  if (attrs.cols.empty()) { attrs.cols = {"FID"}; attrs.rows.clear(); for (size_t i = 0; i < geoms.size(); i++) attrs.rows.push_back({Value(static_cast<double>(i))}); }
  // .shp / .shx
  std::string body, index;
  std::array<double, 4> bb = {INFINITY, INFINITY, -INFINITY, -INFINITY};
  double zmin = 0, zmax = 0;
  bool firstZ = true;
  for (size_t i = 0; i < geoms.size(); i++) {
    std::string rec = shapeRecord(geoms[i], type);
    std::string h;
    putBE(h, i + 1, 4);
    putBE(h, rec.size() / 2, 4);
    putBE(index, (100 + body.size()) / 2, 4);
    putBE(index, rec.size() / 2, 4);
    body += h + rec;
    auto gb = geoms[i].bbox();
    bb = {std::min(bb[0], gb[0]), std::min(bb[1], gb[1]), std::max(bb[2], gb[2]), std::max(bb[3], gb[3])};
    for (const auto &p : geoms[i].parts) for (const auto &q : p) { if (firstZ) { zmin = zmax = q[2]; firstZ = false; } zmin = std::min(zmin, q[2]); zmax = std::max(zmax, q[2]); }
  }
  if (geoms.empty()) bb = {0, 0, 0, 0};
  if (body.size() + 100 > 0x7FFFFFFEull) return fail("a shapefile is limited to 2 GB");
  std::string base = stem(file);
  uint64_t total = 0;
  auto put = [&](const std::string &ext, const std::string &bytes) -> bool {
    if (!writeFile(base + "." + ext, bytes, false, err)) return false;
    total += bytes.size();
    return true;
  };
  std::string dbf = writeDbf(attrs, enc, err);
  if (!err.empty()) return fail(err);
  bool ok = true;
  if (fmt == "shp" || bundle) ok = ok && (geoms.empty() && fmt == "dbf" ? true : put("shp", shpHeader(type, 100 + body.size(), bb, zmin, zmax) + body));
  if (fmt == "shx" || bundle) ok = ok && (geoms.empty() && fmt == "dbf" ? true : put("shx", shpHeader(type, 100 + index.size(), bb, zmin, zmax) + index));
  if (fmt == "dbf" || bundle) ok = ok && put("dbf", dbf);
  if (bundle) {
    ok = ok && put("prj", prj) && put("cpg", enc == "utf-8" ? "UTF-8" : upperAscii(enc));
    if (given(a[6])) {
      std::string x = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<metadata>\n";
      for (const auto &bx : optTextList(a[6])) x += "  <note>" + escapeXml(bx, false) + "</note>\n";
      x += "</metadata>\n";
      if (!writeFile(file + ".xml", x, false, err)) return fail(err);
      total += x.size();
    }
  }
  if (!ok) return fail(err);
  ev.ok = true;
  return Value(static_cast<double>(total));
}

} // namespace

void registerShapefile(Registry &reg) {
  for (const char *ext : {"shp", "shx", "dbf"}) {
    const std::string e = ext;
    std::string what = e == "shp" ? "features (attributes + WKT geometry)" : e == "shx" ? "the shape index (offset, length in bytes)" : "the dBASE attribute table";
    addMulti(reg, "read_" + e, "file, bbox=\"\", cols=\"\", rows=\"\", where=\"\", crs=\"\", box=true",
             "read " + what + " of a shapefile; bbox= keeps intersecting shapes, crs= reprojects", "geopandas.read_file", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readShape(e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file", "load a shapefile bundle (D.features, D.geom, D.attrs, D.<column>, D.bbox, D.crs, D.index_offsets)",
          "geopandas.read_file", [e](const std::vector<Value> &a, CallContext &ctx) { return loadShape(e, a, ctx); });
    addFn(reg, "save_" + e, "file, geo_data, geom_type=\"\", crs=\"EPSG:4326\", enc=\"utf-8\", bundle=true, boxes=\"\"",
          "write a shapefile bundle (.shp .shx .dbf .prj .cpg) from WKT / x-y tables or loaded shapes", "geopandas.GeoDataFrame.to_file",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveShape(e, a, ctx); });
  }
}

} // namespace io
} // namespace nc
