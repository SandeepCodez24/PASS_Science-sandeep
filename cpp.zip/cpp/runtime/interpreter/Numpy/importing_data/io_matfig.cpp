// CATEGORY 4 - MAT-files and CATEGORY 5 - figure files: read_/load_/save_ mat, fig.
#include <algorithm>
#include <cmath>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_mat.h"

namespace nc {
namespace io {

// v7.3 MAT-files are HDF5 (io_hdf5.cpp, phase 3).
bool readMat73(const std::string &bytes, MatFile &mf, std::string &err);
std::string writeMat73(const MatFile &mf, std::string &err);

namespace {

bool loadMatFile(const std::string &file, MatFile &mf, std::string &err) {
  std::string bytes;
  if (!readSource(file, bytes, err)) return false;
  if (readMatV5(bytes, mf, err)) return true;
  if (err == "v7.3") {
    err.clear();
    return readMat73(bytes, mf, err);
  }
  return false;
}

// "1:100, :" on a row-major value (MATLAB 1-based, inclusive).
bool sliceValue(Value &v, const std::string &spec, std::string &err) {
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!ndToRowMajor(v, shape, vals)) { err = "slice works on numeric arrays"; return false; }
  std::vector<std::pair<size_t, size_t>> ranges;
  size_t start = 0;
  while (start <= spec.size()) {
    size_t c = spec.find(',', start);
    if (c == std::string::npos) c = spec.size();
    std::string part = trim(spec.substr(start, c - start));
    size_t d = ranges.size();
    size_t len = d < shape.size() ? shape[d] : 1;
    if (part == ":" || part.empty()) ranges.push_back({0, len});
    else {
      size_t colon = part.find(':');
      long long a = std::atoll(part.substr(0, colon).c_str());
      long long b = colon == std::string::npos ? a : (trim(part.substr(colon + 1)) == "end" ? static_cast<long long>(len) : std::atoll(part.substr(colon + 1).c_str()));
      if (a < 1 || b < a || b > static_cast<long long>(len)) { err = "slice \"" + part + "\" is outside 1.." + std::to_string(len); return false; }
      ranges.push_back({static_cast<size_t>(a - 1), static_cast<size_t>(b)});
    }
    start = c + 1;
  }
  while (ranges.size() < shape.size()) ranges.push_back({0, shape[ranges.size()]});
  std::vector<size_t> ns;
  for (size_t d = 0; d < shape.size(); d++) ns.push_back(ranges[d].second - ranges[d].first);
  std::vector<double> out;
  std::vector<size_t> idx(shape.size(), 0);
  std::function<void(size_t, size_t)> walk = [&](size_t d, size_t off) {
    if (d == shape.size()) { out.push_back(vals[off]); return; }
    for (size_t i = ranges[d].first; i < ranges[d].second; i++) walk(d + 1, off * shape[d] + i);
  };
  walk(0, 0);
  v = ndFromRowMajor(ns, out);
  return true;
}

// read_mat(file, vars, slice, squeeze, struct_as)
void readMat(const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_mat", file);
  MatFile mf;
  if (!loadMatFile(file, mf, err)) return ctx.fail(err);
  std::vector<std::string> want = optTextList(a[1]);
  bool squeeze = optBool(a[3], true);
  std::string as = lower(optText(a[4], "dict"));
  if (as != "dict" && as != "object") return ctx.fail("struct_as must be \"dict\" or \"object\"");
  Fields vars;
  for (const auto &w : want) {
    bool found = false;
    for (const auto &v : mf.vars) if (v.name == w) found = true;
    if (!found) {
      std::string names;
      for (const auto &v : mf.vars) names += (names.empty() ? "" : ", ") + v.name;
      return ctx.fail("no variable '" + w + "' (variables: " + names + ")");
    }
  }
  for (const auto &v : mf.vars) {
    if (!want.empty() && std::find(want.begin(), want.end(), v.name) == want.end()) continue;
    Value val = matToValue(v, squeeze, as == "object");
    if (a[2].isDict && a[2].dict().count(v.name))
      if (!sliceValue(val, optText(a[2].dict().at(v.name)), err)) return ctx.fail(v.name + ": " + err);
    vars[v.name] = val;
  }
  out.push_back(vars.size() == 1 ? vars.begin()->second : Value(vars));
  if (nout > 1) {
    std::vector<std::string> names;
    for (const auto &v : mf.vars) names.push_back(v.name);
    out.push_back(makeObject("NcReadInfo", {{"vars", textList(names)}, {"version", Value(mf.version)},
                                            {"boxes", textList({mf.header})}}));
  }
  ev.ok = true;
}

Value infoOf(const MatNode &v) {
  std::vector<double> dims(v.dims.begin(), v.dims.end());
  double bytes = static_cast<double>(v.re.size() + v.im.size()) * (v.cls == MatNode::Double ? 8 : v.cls == MatNode::Single ? 4 : 1);
  return makeObject("NcMatInfo", {{"name", Value(v.name)}, {"shape", numberList(dims)}, {"dtype", Value(matClassName(v))},
                                  {"complex", Value::boolean(v.complex)}, {"sparse", Value::boolean(v.className == "sparse")},
                                  {"bytes", Value(bytes)}});
}

Value loadMat(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_mat", file);
  MatFile mf;
  if (!loadMatFile(file, mf, err)) { ctx.fail(err); return Value(0.0); }
  Fields f, infos;
  std::vector<std::string> names;
  size_t largest = 0, best = 0;
  for (const auto &v : mf.vars) {
    names.push_back(v.name);
    f[v.name] = matToValue(v, true, true);
    infos[v.name] = infoOf(v);
    if (v.count() >= largest) { largest = v.count(); best = names.size() - 1; }
  }
  f["default"] = names.empty() ? Value(0.0) : f[names[best]];
  f["vars"] = textList(names);
  f["header"] = Value(mf.header);
  f["boxes"] = textList({mf.header});
  f["version"] = Value(mf.version);
  f["var_info"] = Value(infos);
  f["file"] = Value(file);
  ev.ok = true;
  return makeObject("NcMat", std::move(f));
}

Value infoMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string name;
  if (!numpy::argText(a, 1, ctx, name)) return Value(0.0);
  const Value *infos = field(a[0], "var_info");
  if (!infos || !infos->dict().count(name)) { ctx.fail("no variable '" + name + "'"); return Value(0.0); }
  return infos->dict().at(name);
}

bool validName(const std::string &n) {
  if (n.empty() || n.size() > 63 || !std::isalpha(static_cast<unsigned char>(n[0]))) return false;
  for (char c : n) if (!(std::isalnum(static_cast<unsigned char>(c)) || c == '_')) return false;
  return true;
}

// save_mat(file, data, vars, ver, compress, level, boxes, mode)
Value saveMat(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_mat", file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  std::string ver = lower(optText(a[3], "v7"));
  if (ver != "v5" && ver != "v7" && ver != "v7.3") return fail("ver must be \"v5\", \"v7\" or \"v7.3\"");
  std::string mode = lower(optText(a[7], "w"));
  MatFile mf;
  if (mode == "a" && fileExists(file) && !loadMatFile(file, mf, err)) return fail("cannot append to " + file + ": " + err);
  auto put = [&](const std::string &name, const Value &v) -> bool {
    if (!validName(name)) { err = "variable name '" + name + "' is not allowed (letter first, then letters/digits/_, at most 63)"; return false; }
    MatNode n;
    if (!valueToMat(name, v, n, err)) { err = name + ": " + err; return false; }
    for (auto &old : mf.vars) if (old.name == name) { old = std::move(n); return true; }
    mf.vars.push_back(std::move(n));
    return true;
  };
  auto putAll = [&](const Value &d) -> bool {
    std::vector<std::string> keys;
    for (const auto &kv : d.dict()) if (kv.first != "key_order") keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) if (!put(k, d.dict().at(k))) return false;
    return true;
  };
  if (given(a[1])) {
    if (isObjectOf(a[1], "NcMat")) {
      const Value *names = field(a[1], "vars");
      for (const auto &nm : optTextList(names ? *names : Value(std::string())))
        if (const Value *v = field(a[1], nm)) if (!put(nm, *v)) return fail(err);
    } else if (a[1].isDict) {
      if (!putAll(a[1])) return fail(err);
    } else if (!put("data", a[1])) {
      return fail(err);
    }
  }
  if (given(a[2])) {
    if (!a[2].isDict) return fail("vars must be a dict of name -> value");
    if (!putAll(a[2])) return fail(err);
  }
  if (mf.vars.empty()) return fail("nothing to save - give data or vars");
  if (given(a[6])) mf.header = "MATLAB 5.0 MAT-file, " + optText(a[6]);
  size_t total = 0;
  for (const auto &v : mf.vars) total += (v.re.size() + v.im.size()) * 8;
  if (total > 2000000000ull && ver != "v7.3") ver = "v7.3";
  std::string bytes;
  if (ver == "v7.3") {
    bytes = writeMat73(mf, err);
    if (bytes.empty()) return fail(err);
  } else {
    bool comp = ver == "v7" && lower(optText(a[4], "yes")) != "no";
    bytes = writeMatV5(mf, comp, static_cast<int>(optInt(a[5], 6)));
  }
  if (!writeFile(file, bytes, false, err)) return fail(err);
  emitEvent({"saved", "save_mat", file, 1.0, formatBytes(bytes.size())});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

// ---- .fig ---------------------------------------------------------------------------

const MatNode *fieldOf(const MatNode &s, size_t elem, const std::string &name) {
  if (elem >= s.elems.size()) return nullptr;
  for (size_t k = 0; k < s.fieldNames.size() && k < s.elems[elem].size(); k++)
    if (s.fieldNames[k] == name) return &s.elems[elem][k];
  return nullptr;
}

std::string typeOf(const MatNode &s, size_t e) {
  const MatNode *t = fieldOf(s, e, "type");
  return t && t->cls == MatNode::Char ? t->text : "";
}

struct FigObj {
  std::string type;
  double handle = 0;
  const MatNode *props = nullptr;
  std::vector<FigObj> kids;
};

void collect(const MatNode &arr, std::vector<FigObj> &out) {
  for (size_t e = 0; e < arr.elems.size(); e++) {
    FigObj o;
    o.type = typeOf(arr, e);
    const MatNode *h = fieldOf(arr, e, "handle");
    o.handle = h && !h->re.empty() ? h->re[0] : 0;
    o.props = fieldOf(arr, e, "properties");
    if (const MatNode *k = fieldOf(arr, e, "children")) if (k->cls == MatNode::Struct) collect(*k, o.kids);
    out.push_back(std::move(o));
  }
}

Value prop(const FigObj &o, const std::string &name) {
  if (!o.props) return Value(std::string());
  const MatNode *p = fieldOf(*o.props, 0, name);
  return p ? matToValue(*p, true, false) : Value(std::string());
}

bool loadFigTree(const std::string &file, FigObj &fig, MatFile &mf, std::string &err) {
  if (!loadMatFile(file, mf, err)) return false;
  for (const auto &v : mf.vars)
    if (v.name.rfind("hgS_", 0) == 0 || v.name.rfind("hgM_", 0) == 0) {
      std::vector<FigObj> top;
      collect(v, top);
      if (!top.empty()) { fig = top[0]; return true; }
    }
  err = "this MAT-file holds no figure (no hgS_070000 variable)";
  return false;
}

Value axesObject(const FigObj &ax, std::vector<std::string> &boxes) {
  Fields f;
  std::vector<Value> lines, surfaces;
  std::map<double, std::string> texts;
  for (const auto &k : ax.kids) {
    if (k.type == "line" || k.type == "graph2d.lineseries" || k.type == "scatter") {
      lines.push_back(makeObject("NcLine", {{"x", prop(k, "XData")}, {"y", prop(k, "YData")}, {"z", prop(k, "ZData")},
                                            {"color", prop(k, "Color")}, {"label", prop(k, "DisplayName")},
                                            {"style", prop(k, "LineStyle")}, {"type", Value(k.type)}}));
    } else if (k.type == "surface" || k.type == "image" || k.type == "patch") {
      surfaces.push_back(makeObject("NcSurface", {{"x", prop(k, "XData")}, {"y", prop(k, "YData")}, {"z", prop(k, "ZData")},
                                                  {"cdata", prop(k, "CData")}, {"type", Value(k.type)}}));
    } else if (k.type == "text") {
      Value s = prop(k, "String");
      texts[k.handle] = s.isText ? s.text() : cellText(s);
    }
  }
  // MATLAB keeps the title / x / y / z label handles in the axes 'special' list;
  // the text children appear in that order when no handle matches.
  std::vector<std::string> ordered;
  for (const auto &t : texts) ordered.push_back(t.second);
  f["title"] = Value(ordered.size() > 0 ? ordered[0] : std::string());
  f["xlabel"] = Value(ordered.size() > 1 ? ordered[1] : std::string());
  f["ylabel"] = Value(ordered.size() > 2 ? ordered[2] : std::string());
  for (const auto &t : ordered) if (!t.empty()) boxes.push_back(t);
  f["xlim"] = prop(ax, "XLim");
  f["ylim"] = prop(ax, "YLim");
  f["tag"] = prop(ax, "Tag");
  f["lines"] = Value(lines);
  f["surfaces"] = Value(surfaces);
  return makeObject("NcAxes", std::move(f));
}

void figureParts(const FigObj &fig, std::vector<Value> &axes, std::vector<std::string> &boxes, Value &legend) {
  legend = Value(std::vector<Value>{});
  for (const auto &k : fig.kids) {
    if (k.type == "axes") {
      axes.push_back(axesObject(k, boxes));
    } else if (k.type.find("legend") != std::string::npos) {
      legend = prop(k, "String");
    } else if (k.type.find("scribe") != std::string::npos || k.type.find("annotation") != std::string::npos) {
      std::function<void(const FigObj &)> grab = [&](const FigObj &o) {
        Value s = prop(o, "String");
        std::string t = s.isText ? s.text() : cellText(s);
        if (!t.empty()) boxes.push_back(t);
        for (const auto &c : o.kids) grab(c);
      };
      grab(k);
    }
  }
}

// read_fig(file, axes, series, props, box, render)
void readFig(const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_fig", file);
  FigObj fig;
  MatFile mf;
  if (!loadFigTree(file, fig, mf, err)) return ctx.fail(err);
  std::vector<Value> axes;
  std::vector<std::string> boxes;
  Value legend;
  figureParts(fig, axes, boxes, legend);
  if (axes.empty()) return ctx.fail("the figure has no axes");
  size_t ai = 0;
  if (numpy::isPlainNumber(a[1]) && !a[1].isText) {
    long long k = optInt(a[1], 1);
    if (k < 1 || k > static_cast<long long>(axes.size())) return ctx.fail("axes " + std::to_string(k) + " does not exist (the figure has " + std::to_string(axes.size()) + ")");
    ai = static_cast<size_t>(k - 1);
  } else if (given(a[1])) {
    bool found = false;
    for (size_t k = 0; k < axes.size(); k++) if (optText(*field(axes[k], "tag")) == optText(a[1])) { ai = k; found = true; }
    if (!found) return ctx.fail("no axes with Tag '" + optText(a[1]) + "'");
  }
  const Value &ax = axes[ai];
  std::vector<Value> series;
  for (const char *kind : {"lines", "surfaces"}) {
    const Value *l = field(ax, kind);
    for (size_t k = 0; l && k < l->length(); k++) series.push_back(l->at(k));
  }
  std::vector<std::string> props = optTextList(a[3]);
  auto pick = [&](const Value &s) {
    Fields f;
    static const std::map<std::string, std::string> map = {{"XData", "x"}, {"YData", "y"}, {"ZData", "z"}, {"CData", "cdata"},
                                                          {"Color", "color"}, {"DisplayName", "label"}, {"LineStyle", "style"}};
    for (const auto &kv : map) {
      if (!props.empty() && std::find(props.begin(), props.end(), kv.first) == props.end()) continue;
      if (const Value *v = field(s, kv.second)) if (given(*v)) f[kv.first] = *v;
    }
    return Value(f);
  };
  if (numpy::isPlainNumber(a[2]) && !a[2].isText) {
    long long k = optInt(a[2], 1);
    if (k < 1 || k > static_cast<long long>(series.size())) return ctx.fail("series " + std::to_string(k) + " does not exist (the axes have " + std::to_string(series.size()) + ")");
    out.push_back(pick(series[static_cast<size_t>(k - 1)]));
  } else {
    Fields all;
    for (size_t k = 0; k < series.size(); k++) all["series" + std::to_string(k + 1)] = pick(series[k]);
    out.push_back(Value(all));
  }
  if (optBool(a[5], false)) emitEvent({"show_figure", "read_fig", file, 1.0, "render"});
  if (nout > 1)
    out.push_back(makeObject("NcReadInfo", {{"axes", Value(static_cast<double>(axes.size()))},
                                            {"series", Value(static_cast<double>(series.size()))},
                                            {"boxes", optBool(a[4], true) ? textList(boxes) : textList({})},
                                            {"legend", legend}}));
  ev.ok = true;
}

Value loadFig(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_fig", file);
  FigObj fig;
  MatFile mf;
  if (!loadFigTree(file, fig, mf, err)) { ctx.fail(err); return Value(0.0); }
  std::vector<Value> axes;
  std::vector<std::string> boxes;
  Value legend;
  figureParts(fig, axes, boxes, legend);
  Fields f;
  f["axes"] = Value(axes);
  f["default"] = axes.empty() ? Value(0.0) : axes[0];
  f["boxes"] = textList(boxes);
  f["legend"] = legend;
  f["colormap"] = prop(fig, "Colormap");
  f["name"] = prop(fig, "Name");
  f["file"] = Value(file);
  ev.ok = true;
  return makeObject("NcFigure", std::move(f));
}

Value showMethod(const std::vector<Value> &a, CallContext &) {
  const Value *file = field(a[0], "file");
  emitEvent({"show_figure", "NcFigure.show", file ? optText(*file) : "", 1.0, "render"});
  return Value::boolean(true);
}

// hgS_070000 tree builders
MatNode charNode(const std::string &s) { MatNode n; std::string e; valueToMat("", Value(s), n, e); return n; }
MatNode numNode(const Value &v) { MatNode n; std::string e; valueToMat("", v, n, e); return n; }
MatNode emptyNode() { MatNode n; n.cls = MatNode::Double; n.dims = {0, 0}; return n; }

MatNode structOf(const std::vector<std::pair<std::string, MatNode>> &fields) {
  MatNode n;
  n.cls = MatNode::Struct;
  n.dims = {1, 1};
  std::vector<MatNode> vals;
  for (const auto &kv : fields) { n.fieldNames.push_back(kv.first); vals.push_back(kv.second); }
  n.elems.push_back(vals);
  return n;
}

MatNode objArray(const std::vector<MatNode> &objs) { // Nx1 struct array of hg objects
  MatNode n;
  n.cls = MatNode::Struct;
  n.dims = {objs.size(), 1};
  n.fieldNames = {"type", "handle", "properties", "children", "special"};
  for (const auto &o : objs) n.elems.push_back(o.elems[0]);
  if (objs.empty()) n.dims = {0, 0};
  return n;
}

MatNode hgObj(const std::string &type, double handle, const MatNode &props, const std::vector<MatNode> &kids, const MatNode &special) {
  return structOf({{"type", charNode(type)}, {"handle", numNode(Value(handle))}, {"properties", props},
                   {"children", kids.empty() ? emptyNode() : objArray(kids)}, {"special", special}});
}

// save_fig(file, fig_obj, compact, compress, dpi, boxes, include_data, preview, max_size)
Value saveFig(const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_fig", file);
  struct L { Value x, y, z, color, label; };
  std::vector<L> lines;
  std::string title, xl, yl;
  Value xlim, ylim;
  const Value &f = a[1];
  bool data = optBool(a[6], true);
  if (isObjectOf(f, "NcFigure") || isObjectOf(f, "NcAxes")) {
    const Value *ax = isObjectOf(f, "NcFigure") ? field(f, "default") : &f;
    if (ax && ax->isObject) {
      if (const Value *t = field(*ax, "title")) title = optText(*t);
      if (const Value *t = field(*ax, "xlabel")) xl = optText(*t);
      if (const Value *t = field(*ax, "ylabel")) yl = optText(*t);
      if (const Value *t = field(*ax, "xlim")) xlim = *t;
      if (const Value *t = field(*ax, "ylim")) ylim = *t;
      if (const Value *ls = field(*ax, "lines"))
        for (size_t k = 0; k < ls->length(); k++) {
          Value l = ls->at(k);
          lines.push_back({*field(l, "x"), *field(l, "y"), *field(l, "z"), *field(l, "color"), *field(l, "label")});
        }
    }
  } else if (f.isDict) {
    auto get = [&](const char *k) { return f.dict().count(k) ? f.dict().at(k) : Value(std::string()); };
    Value y = get("y");
    Value x = get("x");
    if (!given(y)) { ctx.fail("a figure dict needs at least \"y\" (and optional \"x\", \"title\", \"xlabel\", \"ylabel\")"); return Value(0.0); }
    lines.push_back({x, y, Value(std::string()), Value(std::string()), get("label")});
    title = optText(get("title"));
    xl = optText(get("xlabel"));
    yl = optText(get("ylabel"));
  } else {
    std::vector<size_t> shape;
    std::vector<double> vals;
    if (!ndToRowMajor(f, shape, vals) || shape.size() > 2) { ctx.fail("fig_obj must be a loaded figure, a dict with x/y, or a matrix (one line per column)"); return Value(0.0); }
    size_t rows = shape[0], cols = shape.size() == 2 ? shape[1] : 1;
    if (shape.size() == 1) { rows = shape[0]; cols = 1; }
    for (size_t c = 0; c < cols; c++) {
      std::vector<double> y(rows), x(rows);
      for (size_t r = 0; r < rows; r++) { y[r] = vals[r * cols + c]; x[r] = static_cast<double>(r + 1); }
      lines.push_back({numberList(x), numberList(y), Value(std::string()), Value(std::string()), Value(std::string())});
    }
  }
  static const double palette[7][3] = {{0, 0.447, 0.741}, {0.85, 0.325, 0.098}, {0.929, 0.694, 0.125}, {0.494, 0.184, 0.556},
                                       {0.466, 0.674, 0.188}, {0.301, 0.745, 0.933}, {0.635, 0.078, 0.184}};
  double handle = 1.0001;
  std::vector<MatNode> axKids;
  for (size_t k = 0; k < lines.size(); k++) {
    const L &l = lines[k];
    std::vector<std::pair<std::string, MatNode>> p;
    p.push_back({"Color", given(l.color) ? numNode(l.color) : numNode(numberList({palette[k % 7][0], palette[k % 7][1], palette[k % 7][2]}))});
    if (data) {
      p.push_back({"XData", numNode(l.x)});
      p.push_back({"YData", numNode(l.y)});
      if (given(l.z)) p.push_back({"ZData", numNode(l.z)});
    }
    if (given(l.label)) p.push_back({"DisplayName", charNode(optText(l.label))});
    axKids.push_back(hgObj("line", handle += 1, structOf(p), {}, emptyNode()));
  }
  std::vector<double> special;
  for (const std::string *t : {&title, &xl, &yl}) {
    double h = handle += 1;
    special.push_back(h);
    axKids.push_back(hgObj("text", h, structOf({{"String", charNode(*t)}}), {}, emptyNode()));
  }
  std::vector<std::pair<std::string, MatNode>> axProps;
  if (given(xlim)) axProps.push_back({"XLim", numNode(xlim)});
  if (given(ylim)) axProps.push_back({"YLim", numNode(ylim)});
  axProps.push_back({"Position", numNode(numberList({0.13, 0.11, 0.775, 0.815}))});
  MatNode axes = hgObj("axes", handle += 1, structOf(axProps), axKids, numNode(numberList(special)));
  std::vector<MatNode> figKids{axes};
  for (const auto &bx : optTextList(a[5])) { // annotation text boxes
    MatNode tb = hgObj("scribe.textbox", handle += 1, structOf({{"String", charNode(bx)}}), {}, emptyNode());
    figKids.push_back(hgObj("scribe.scribeoverlay", handle += 1, structOf({}), {tb}, emptyNode()));
  }
  MatNode figure = hgObj("figure", 1, structOf({{"Name", charNode("NC figure")}}), figKids, emptyNode());
  figure.name = "hgS_070000";
  MatFile mf;
  mf.header = "MATLAB 5.0 MAT-file, Platform: NC, Created by: NC save_fig";
  mf.vars.push_back(figure);
  std::string bytes = writeMatV5(mf, lower(optText(a[3], "yes")) != "no", 6);
  if (!checkMaxSize(a[8], bytes.size(), err) || !writeFile(file, bytes, false, err)) { ctx.fail(err); return Value(0.0); }
  emitEvent({"saved", "save_fig", file, 1.0, formatBytes(bytes.size())});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerMat(Registry &reg) {
  addMulti(reg, "read_mat", "file, vars=\"\", slice=\"\", squeeze=true, struct_as=\"dict\"",
           "read the variables of a .mat file (one variable comes back directly)", "scipy.io.loadmat", 2, readMat);
  addFn(reg, "load_mat", "file", "load a .mat file as a namespace (D.vars, D.x, D.cfg.gain, D.info(\"x\"), D.version)",
        "matfile", loadMat);
  addFn(reg, "save_mat", "file, data=\"\", vars=\"\", ver=\"v7\", compress=\"yes\", level=6, boxes=\"\", mode=\"w\"",
        "write variables to a .mat file (v5, compressed v7, or HDF5-based v7.3)", "scipy.io.savemat", saveMat);
  addFn(reg, "NcMat.info", "D, name", "shape, dtype, bytes, complex and sparse flags of one variable", "whos", infoMethod);
  addMulti(reg, "read_fig", "file, axes=1, series=\"all\", props=\"\", box=true, render=false",
           "read the plotted data (XData, YData, ZData, CData) of a .fig file", "openfig + get", 2, readFig);
  addFn(reg, "load_fig", "file", "load a .fig scene (D.axes[0].lines[0].x, D.axes[0].title, D.boxes, D.show())", "openfig", loadFig);
  addFn(reg, "save_fig",
        "file, fig_obj, compact=true, compress=\"yes\", dpi=300, boxes=\"\", include_data=true, preview=\"\", max_size=\"\"",
        "write a figure (a loaded figure, a dict with x/y, or a matrix of lines) as .fig", "savefig", saveFig);
  addFn(reg, "NcFigure.show", "D", "ask the IDE to draw the figure (sends a show_figure event)", "figure", showMethod);
}

} // namespace io
} // namespace nc
