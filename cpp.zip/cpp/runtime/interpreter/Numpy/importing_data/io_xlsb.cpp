// .xlsb (Excel Binary Workbook, MS-XLSB) reader: zip of BIFF12 record parts.
// Values only (cached formula results); number formats are not decoded, so
// dates come back as Excel serial numbers.
#include <cstring>
#include <map>

#include "io_bytes.h"
#include "io_markup.h"
#include "io_sheet.h"
#include "io_zip.h"

namespace nc {
namespace io {
namespace {

struct BRec {
  uint32_t id;
  std::string data;
};

std::vector<BRec> brecs(const std::string &s) {
  std::vector<BRec> out;
  size_t p = 0;
  while (p < s.size()) {
    uint32_t id = static_cast<unsigned char>(s[p++]);
    if (id & 0x80) {
      if (p >= s.size()) break;
      id = (id & 0x7F) | (static_cast<uint32_t>(static_cast<unsigned char>(s[p++])) << 7);
    }
    uint32_t size = 0;
    for (int k = 0; k < 4 && p < s.size(); k++) {
      unsigned char b = static_cast<unsigned char>(s[p++]);
      size |= static_cast<uint32_t>(b & 0x7F) << (7 * k);
      if (!(b & 0x80)) break;
    }
    if (p + size > s.size()) break;
    out.push_back({id, s.substr(p, size)});
    p += size;
  }
  return out;
}

std::string wide(const std::string &d, size_t &at) {
  uint32_t n = u32le(d, at);
  at += 4;
  std::string out;
  for (uint32_t k = 0; k < n && at + 1 < d.size(); k++, at += 2) {
    uint32_t c = u16le(d, at);
    if (c < 0x80) out.push_back(static_cast<char>(c));
    else if (c < 0x800) { out.push_back(static_cast<char>(0xC0 | (c >> 6))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    else { out.push_back(static_cast<char>(0xE0 | (c >> 12))); out.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
  }
  return out;
}

double rk(uint32_t v) {
  double d;
  if (v & 2) d = static_cast<double>(static_cast<int32_t>(v) >> 2);
  else {
    uint64_t bits = static_cast<uint64_t>(v & 0xFFFFFFFC) << 32;
    std::memcpy(&d, &bits, 8);
  }
  return (v & 1) ? d / 100 : d;
}

std::map<std::string, std::string> relTargets(const ZipReader &z, const std::string &relsPart, const std::string &dir) {
  std::map<std::string, std::string> out;
  std::string text, err;
  XNode doc;
  if (!z.read(relsPart, text, err) || !parseXml(text, doc, err)) return out;
  for (const XNode *r : rootElement(doc)->elements()) {
    const std::string *id = r->attr("Id"), *t = r->attr("Target");
    if (id && t) out[*id] = (!t->empty() && (*t)[0] == '/') ? t->substr(1) : dir + *t;
  }
  return out;
}

} // namespace

bool readXlsb(const std::string &bytes, Workbook &wb, std::string &err) {
  wb = Workbook();
  ZipReader z;
  if (!z.open(bytes, err)) return false;
  std::string book;
  if (!z.read("xl/workbook.bin", book, err)) {
    err = "this zip file is not an Excel binary workbook (no xl/workbook.bin)";
    return false;
  }
  auto targets = relTargets(z, "xl/_rels/workbook.bin.rels", "xl/");
  std::vector<std::string> sst;
  std::string sstBin;
  for (const auto &kv : targets)
    if (kv.second.find("sharedStrings") != std::string::npos && z.read(kv.second, sstBin, err)) {
      auto recs = brecs(sstBin);
      wb.binBlocks.push_back({kv.second, recs.size()});
      for (const auto &r : recs)
        if (r.id == 0x13) { size_t at = 1; sst.push_back(wide(r.data, at)); }
    }
  auto bookRecs = brecs(book);
  wb.binBlocks.insert(wb.binBlocks.begin(), {"xl/workbook.bin", bookRecs.size()});
  for (const auto &r : bookRecs) {
    if (r.id != 0x9C) continue; // BrtBundleSh
    size_t at = 8;
    std::string rid = wide(r.data, at);
    Sheet s;
    s.name = wide(r.data, at);
    std::string part = targets.count(rid) ? targets[rid] : "";
    std::string bin;
    if (part.empty() || !z.read(part, bin, err)) {
      wb.sheets.push_back(s);
      continue;
    }
    auto recs = brecs(bin);
    wb.binBlocks.push_back({part, recs.size()});
    size_t row = 0;
    for (const auto &c : recs) {
      const std::string &d = c.data;
      if (c.id == 0x00) { row = u32le(d, 0); continue; }
      if (c.id >= 0x02 && c.id <= 0x0B && d.size() >= 8) {
        size_t col = u32le(d, 0);
        SheetCell cell;
        switch (c.id) {
          case 0x02: cell.v = Value(rk(u32le(d, 8))); break;
          case 0x03: case 0x0B: cell.v = Value(std::string("#ERR")); break;
          case 0x04: case 0x0A: cell.v = Value::boolean(d[8] != 0); break;
          case 0x05: case 0x09: cell.v = Value(f64le(d, 8)); break;
          case 0x06: case 0x08: { size_t at = 8; cell.v = Value(wide(d, at)); break; }
          case 0x07: { uint32_t k = u32le(d, 8); cell.v = Value(k < sst.size() ? sst[k] : std::string()); break; }
        }
        s.cells[{row, col}] = cell;
      } else if (c.id == 0xB0 && d.size() >= 16) { // BrtMergeCell
        s.merged.push_back(addressOf(u32le(d, 0), u32le(d, 8)) + ":" + addressOf(u32le(d, 4), u32le(d, 12)));
      }
    }
    wb.sheets.push_back(std::move(s));
  }
  wb.meta["application"] = Value(std::string("Excel binary workbook (BIFF12)"));
  return true;
}

} // namespace io
} // namespace nc
