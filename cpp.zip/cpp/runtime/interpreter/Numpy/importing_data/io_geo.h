// Coordinate reference systems shared by shapefiles, GeoTIFF and GPX / KML:
// EPSG codes from "EPSG:4326" / WKT / PROJ text, and transforms between
// WGS84 geographic (4326 and its look-alikes 4258 / 4269), Web Mercator
// (3857) and WGS84 UTM zones (326xx north, 327xx south). Hand-written.
#ifndef NC_IO_GEO_H
#define NC_IO_GEO_H

#include <string>

namespace nc {
namespace io {

// 0 when the text names no EPSG code we can recognise
int crsEpsg(const std::string &text);
bool crsSupported(int epsg);
bool crsGeographic(int epsg);
// x/y in `from` -> `to` (lon/lat order for geographic). False with err when unsupported.
bool crsTransform(int from, int to, double &x, double &y, std::string &err);
// ESRI-style WKT for a .prj file ("" when unknown)
std::string crsWkt(int epsg);
std::string crsName(int epsg);

} // namespace io
} // namespace nc

#endif // NC_IO_GEO_H
