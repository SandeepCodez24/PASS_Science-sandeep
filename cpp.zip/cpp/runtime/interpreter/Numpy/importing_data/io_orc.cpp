// Apache ORC reader / writer: protobuf footer and postscript, compression
// chunks (zlib / snappy / lz4 / zstd), byte and boolean RLE, integer RLE v1
// and v2 (SHORT_REPEAT, DIRECT, PATCHED_BASE, DELTA), direct and dictionary
// strings, dates, timestamps, decimals and struct columns. Hand-written.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>

#include "io_bytes.h"
#include "io_codecs.h"
#include "io_columnar.h"
#include "io_deflate.h"

namespace nc {
namespace io {
namespace {

// ---- protobuf ----------------------------------------------------------------------------

struct PB {
  std::multimap<int, std::pair<uint64_t, std::string>> f; // field -> (varint / fixed value, bytes)
  bool parse(const std::string &b) {
    size_t p = 0;
    while (p < b.size()) {
      uint64_t key;
      if (!varint(b, p, key)) return false;
      int field = static_cast<int>(key >> 3), wt = static_cast<int>(key & 7);
      uint64_t v = 0;
      std::string s;
      if (wt == 0) { if (!varint(b, p, v)) return false; }
      else if (wt == 1) { if (p + 8 > b.size()) return false; v = u64le(b, p); p += 8; }
      else if (wt == 5) { if (p + 4 > b.size()) return false; v = u32le(b, p); p += 4; }
      else if (wt == 2) { uint64_t n; if (!varint(b, p, n) || p + n > b.size()) return false; s = b.substr(p, static_cast<size_t>(n)); p += static_cast<size_t>(n); }
      else return false;
      f.insert({field, {v, s}});
    }
    return true;
  }
  static bool varint(const std::string &b, size_t &p, uint64_t &v) {
    v = 0;
    for (int s = 0; s < 70; s += 7) {
      if (p >= b.size()) return false;
      unsigned char c = static_cast<unsigned char>(b[p++]);
      v |= static_cast<uint64_t>(c & 0x7F) << s;
      if (!(c & 0x80)) return true;
    }
    return false;
  }
  uint64_t u(int id, uint64_t def = 0) const { auto it = f.find(id); return it == f.end() ? def : it->second.first; }
  int64_t s(int id) const { uint64_t v = u(id); return static_cast<int64_t>(v >> 1) ^ -static_cast<int64_t>(v & 1); }
  double d(int id) const { uint64_t v = u(id); double x; std::memcpy(&x, &v, 8); return x; }
  std::string bytes(int id) const { auto it = f.find(id); return it == f.end() ? "" : it->second.second; }
  bool has(int id) const { return f.count(id) > 0; }
  std::vector<PB> all(int id) const {
    std::vector<PB> out;
    auto r = f.equal_range(id);
    for (auto it = r.first; it != r.second; ++it) { PB m; m.parse(it->second.second); out.push_back(m); }
    return out;
  }
  std::vector<uint64_t> packed(int id) const { // packed or repeated varints
    std::vector<uint64_t> out;
    auto r = f.equal_range(id);
    for (auto it = r.first; it != r.second; ++it) {
      if (it->second.second.empty()) { out.push_back(it->second.first); continue; }
      size_t p = 0;
      uint64_t v;
      while (p < it->second.second.size() && varint(it->second.second, p, v)) out.push_back(v);
    }
    return out;
  }
  std::vector<std::string> strings(int id) const {
    std::vector<std::string> out;
    auto r = f.equal_range(id);
    for (auto it = r.first; it != r.second; ++it) out.push_back(it->second.second);
    return out;
  }
};

struct PW { // protobuf writer
  std::string o;
  void varint(uint64_t v) { do { unsigned char c = v & 0x7F; v >>= 7; o.push_back(static_cast<char>(c | (v ? 0x80 : 0))); } while (v); }
  void u(int id, uint64_t v) { varint(static_cast<uint64_t>(id) << 3); varint(v); }
  void s(int id, int64_t v) { u(id, (static_cast<uint64_t>(v) << 1) ^ static_cast<uint64_t>(v >> 63)); }
  void d(int id, double v) { varint((static_cast<uint64_t>(id) << 3) | 1); uint64_t x; std::memcpy(&x, &v, 8); putLE(o, x, 8); }
  void b(int id, const std::string &v) { varint((static_cast<uint64_t>(id) << 3) | 2); varint(v.size()); o += v; }
};

// ---- compression chunks --------------------------------------------------------------------

const char *KIND_CODEC[] = {"none", "zlib", "snappy", "lzo", "lz4", "zstd"};

bool unchunk(const std::string &in, int codec, std::string &out, std::string &err) {
  if (codec == 0) { out = in; return true; }
  out.clear();
  size_t p = 0;
  while (p + 3 <= in.size()) {
    uint32_t h = static_cast<uint32_t>(getLE(in, p, 3));
    p += 3;
    size_t len = h >> 1;
    if (p + len > in.size()) { err = "ORC compression chunk runs past the end"; return false; }
    std::string chunk = in.substr(p, len);
    p += len;
    if (h & 1) { out += chunk; continue; }
    std::string dec;
    bool ok;
    if (codec == 1) ok = inflateRaw(chunk, 0, dec, err);
    else if (codec == 2) ok = snappyDecompress(chunk, dec, err);
    else if (codec == 4) ok = lz4BlockDecompress(chunk.data(), chunk.size(), dec, 0, err);
    else if (codec == 5) ok = zstdDecompress(chunk, dec, err);
    else { err = "ORC compression '" + std::string(codec < 6 ? KIND_CODEC[codec] : "?") + "' is not built in"; return false; }
    if (!ok) return false;
    out += dec;
  }
  return true;
}

std::string chunkUp(const std::string &in, int codec, int level, size_t block) {
  if (codec == 0) return in;
  std::string out;
  for (size_t p = 0; p < in.size(); p += block) {
    std::string part = in.substr(p, block), comp, err;
    if (codec == 1) comp = deflateRaw(part, level < 0 ? 6 : std::min(level, 9));
    else if (codec == 2) comp = snappyCompress(part);
    else if (codec == 4) comp = lz4BlockCompress(part);
    else comp = zstdCompress(part, level);
    bool original = comp.size() >= part.size();
    const std::string &body = original ? part : comp;
    putLE(out, (body.size() << 1) | (original ? 1 : 0), 3);
    out += body;
  }
  return out;
}

// ---- run-length decoders ---------------------------------------------------------------------

bool byteRle(const std::string &b, size_t count, std::vector<uint8_t> &out) {
  out.clear();
  size_t p = 0;
  while (out.size() < count && p < b.size()) {
    int c = static_cast<int8_t>(b[p++]);
    if (c >= 0) { if (p >= b.size()) return false; for (int k = 0; k < c + 3; k++) out.push_back(static_cast<uint8_t>(b[p])); p++; }
    else { for (int k = 0; k < -c && p < b.size(); k++) out.push_back(static_cast<uint8_t>(b[p++])); }
  }
  return out.size() >= count;
}

bool boolRle(const std::string &b, size_t count, std::vector<bool> &out) {
  std::vector<uint8_t> bytes;
  byteRle(b, (count + 7) / 8, bytes);
  out.clear();
  for (size_t i = 0; i < count; i++) out.push_back(i / 8 < bytes.size() && ((bytes[i / 8] >> (7 - i % 8)) & 1));
  return true;
}

int64_t unzig(uint64_t v) { return static_cast<int64_t>(v >> 1) ^ -static_cast<int64_t>(v & 1); }

int widthOf(int code) {
  static const int w[32] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 26, 28, 30, 32, 40, 48, 56, 64};
  return w[code & 31];
}
int codeOf(int bits) { for (int c = 0; c < 32; c++) if (widthOf(c) >= bits) return c; return 31; }
int closestFixed(int bits) { return widthOf(codeOf(std::max(bits, 1))); }

struct BitReaderBE {
  const std::string &b;
  size_t p;
  int bit = 0; // bits used of b[p]
  BitReaderBE(const std::string &bytes, size_t start) : b(bytes), p(start) {}
  uint64_t read(int n) {
    uint64_t v = 0;
    for (int k = 0; k < n; k++) {
      if (p >= b.size()) return v << (n - k);
      v = (v << 1) | ((static_cast<unsigned char>(b[p]) >> (7 - bit)) & 1);
      if (++bit == 8) { bit = 0; p++; }
    }
    return v;
  }
  void align() { if (bit) { bit = 0; p++; } }
};

bool intRleV2(const std::string &b, size_t count, bool sign, std::vector<int64_t> &out) {
  out.clear();
  size_t p = 0;
  while (out.size() < count && p < b.size()) {
    unsigned h = static_cast<unsigned char>(b[p]);
    int enc = h >> 6;
    if (enc == 0) { // SHORT_REPEAT
      int w = ((h >> 3) & 7) + 1, n = (h & 7) + 3;
      p++;
      uint64_t v = 0;
      for (int k = 0; k < w && p < b.size(); k++) v = (v << 8) | static_cast<unsigned char>(b[p++]);
      int64_t x = sign ? unzig(v) : static_cast<int64_t>(v);
      for (int k = 0; k < n; k++) out.push_back(x);
    } else if (enc == 1) { // DIRECT
      if (p + 2 > b.size()) return false;
      int w = widthOf((h >> 1) & 31);
      size_t n = ((h & 1) << 8 | static_cast<unsigned char>(b[p + 1])) + 1;
      BitReaderBE r(b, p + 2);
      for (size_t k = 0; k < n; k++) { uint64_t v = r.read(w); out.push_back(sign ? unzig(v) : static_cast<int64_t>(v)); }
      r.align();
      p = r.p;
    } else if (enc == 2) { // PATCHED_BASE
      if (p + 4 > b.size()) return false;
      int w = widthOf((h >> 1) & 31);
      size_t n = ((h & 1) << 8 | static_cast<unsigned char>(b[p + 1])) + 1;
      unsigned b2 = static_cast<unsigned char>(b[p + 2]), b3 = static_cast<unsigned char>(b[p + 3]);
      int bw = ((b2 >> 5) & 7) + 1, pw = widthOf(b2 & 31), pgw = ((b3 >> 5) & 7) + 1, pll = b3 & 31;
      p += 4;
      uint64_t raw = 0;
      for (int k = 0; k < bw && p < b.size(); k++) raw = (raw << 8) | static_cast<unsigned char>(b[p++]);
      uint64_t msb = 1ull << (bw * 8 - 1);
      int64_t base = (raw & msb) ? -static_cast<int64_t>(raw & ~msb) : static_cast<int64_t>(raw);
      BitReaderBE r(b, p);
      std::vector<uint64_t> vals(n);
      for (size_t k = 0; k < n; k++) vals[k] = r.read(w);
      r.align();
      int cfb = closestFixed(pgw + pw);
      size_t idx = 0;
      for (int k = 0; k < pll; k++) {
        uint64_t e = r.read(cfb);
        uint64_t gap = e >> pw, patch = e & ((pw >= 64) ? ~0ull : ((1ull << pw) - 1));
        idx += static_cast<size_t>(gap);
        if (idx < n) vals[idx] |= patch << w;
      }
      r.align();
      p = r.p;
      for (auto v : vals) out.push_back(base + static_cast<int64_t>(v));
    } else { // DELTA
      if (p + 2 > b.size()) return false;
      int code = (h >> 1) & 31;
      int w = code == 0 ? 0 : widthOf(code);
      size_t n = ((h & 1) << 8 | static_cast<unsigned char>(b[p + 1])) + 1;
      p += 2;
      uint64_t bv;
      if (!PB::varint(b, p, bv)) return false;
      int64_t first = sign ? unzig(bv) : static_cast<int64_t>(bv);
      uint64_t dv;
      if (!PB::varint(b, p, dv)) return false;
      int64_t delta = unzig(dv);
      out.push_back(first);
      if (n > 1) out.push_back(first + delta);
      int64_t last = first + delta;
      if (w == 0) { for (size_t k = 2; k < n; k++) { last += delta; out.push_back(last); } }
      else {
        BitReaderBE r(b, p);
        for (size_t k = 2; k < n; k++) { int64_t d = static_cast<int64_t>(r.read(w)); last += delta < 0 ? -d : d; out.push_back(last); }
        r.align();
        p = r.p;
      }
    }
  }
  if (out.size() > count) out.resize(count);
  return out.size() == count;
}

bool intRleV1(const std::string &b, size_t count, bool sign, std::vector<int64_t> &out) {
  out.clear();
  size_t p = 0;
  while (out.size() < count && p < b.size()) {
    int c = static_cast<int8_t>(b[p++]);
    if (c >= 0) {
      if (p >= b.size()) return false;
      int delta = static_cast<int8_t>(b[p++]);
      uint64_t v;
      if (!PB::varint(b, p, v)) return false;
      int64_t base = sign ? unzig(v) : static_cast<int64_t>(v);
      for (int k = 0; k < c + 3; k++) out.push_back(base + k * delta);
    } else {
      for (int k = 0; k < -c; k++) { uint64_t v; if (!PB::varint(b, p, v)) return false; out.push_back(sign ? unzig(v) : static_cast<int64_t>(v)); }
    }
  }
  if (out.size() > count) out.resize(count);
  return out.size() == count;
}

bool ints(const std::string &b, size_t count, bool sign, int encoding, std::vector<int64_t> &out) {
  return encoding >= 2 ? intRleV2(b, count, sign, out) : intRleV1(b, count, sign, out);
}

// ---- reader ------------------------------------------------------------------------------------

struct OrcType {
  int kind = 0;
  std::vector<uint32_t> sub;
  std::vector<std::string> names;
  int precision = 0, scale = 0;
};

const char *KIND_NAMES[] = {"bool", "int8", "int16", "int32", "int64", "float32", "float64", "str", "binary", "timestamp", "list", "map", "struct", "union", "decimal", "date", "str", "str", "timestamp"};

ColStats orcStats(const PB &cs, int kind) {
  ColStats s;
  if (cs.has(10)) s.nulls = cs.u(10) ? -1 : 0;
  if (cs.has(2)) { PB i; i.parse(cs.bytes(2)); if (i.has(1)) { s.hasMin = true; s.min = Value(static_cast<double>(i.s(1))); } if (i.has(2)) { s.hasMax = true; s.max = Value(static_cast<double>(i.s(2))); } }
  if (cs.has(3)) { PB d; d.parse(cs.bytes(3)); if (d.has(1)) { s.hasMin = true; s.min = Value(d.d(1)); } if (d.has(2)) { s.hasMax = true; s.max = Value(d.d(2)); } }
  if (cs.has(4)) { PB t; t.parse(cs.bytes(4)); if (t.has(1)) { s.hasMin = true; s.min = Value(t.bytes(1)); } if (t.has(2)) { s.hasMax = true; s.max = Value(t.bytes(2)); } }
  if (cs.has(7)) { PB t; t.parse(cs.bytes(7)); if (t.has(1)) { s.hasMin = true; s.min = Value(isoDate(t.s(1))); } if (t.has(2)) { s.hasMax = true; s.max = Value(isoDate(t.s(2))); } }
  if (kind == 0 && cs.has(5)) { s.hasMin = s.hasMax = false; }
  return s;
}

} // namespace

bool readOrc(const std::string &b, const ColReadOptions &o, ColFile &f, std::string &err) {
  if (b.size() < 4 || b.compare(0, 3, "ORC") != 0) { err = "not an ORC file (no ORC magic)"; return false; }
  size_t psLen = static_cast<unsigned char>(b.back());
  if (psLen + 1 > b.size()) { err = "ORC postscript length is wrong"; return false; }
  PB ps;
  if (!ps.parse(b.substr(b.size() - 1 - psLen, psLen))) { err = "ORC postscript is damaged"; return false; }
  size_t footerLen = static_cast<size_t>(ps.u(1)), metaLen = static_cast<size_t>(ps.u(5));
  int codec = static_cast<int>(ps.u(2));
  if (footerLen + metaLen + psLen + 1 > b.size()) { err = "ORC footer length is wrong"; return false; }
  std::string footerRaw;
  if (!unchunk(b.substr(b.size() - 1 - psLen - footerLen, footerLen), codec, footerRaw, err)) return false;
  PB footer;
  if (!footer.parse(footerRaw)) { err = "ORC footer is damaged"; return false; }
  f.format = "orc";
  f.codec = codec < 6 ? KIND_CODEC[codec] : "?";
  f.totalRows = static_cast<size_t>(footer.u(6));
  for (const auto &m : footer.all(5)) f.kv.push_back({m.bytes(1), m.bytes(2)});
  std::vector<OrcType> types;
  for (const auto &t : footer.all(4)) {
    OrcType ot;
    ot.kind = static_cast<int>(t.u(1));
    for (auto x : t.packed(2)) ot.sub.push_back(static_cast<uint32_t>(x));
    ot.names = t.strings(3);
    ot.precision = static_cast<int>(t.u(5));
    ot.scale = static_cast<int>(t.u(6));
    types.push_back(ot);
  }
  if (types.empty() || types[0].kind != 12) { err = "ORC root type is not a struct"; return false; }
  // leaf columns (flatten structs)
  struct Leaf { uint32_t id; std::string name; std::vector<uint32_t> parents; };
  std::vector<Leaf> leaves;
  std::function<void(uint32_t, const std::string &, std::vector<uint32_t>)> walk = [&](uint32_t id, const std::string &prefix, std::vector<uint32_t> parents) {
    const OrcType &t = types[id];
    for (size_t k = 0; k < t.sub.size() && t.sub[k] < types.size(); k++) {
      std::string name = prefix + (k < t.names.size() ? t.names[k] : "_col" + std::to_string(k));
      uint32_t c = t.sub[k];
      int kind = types[c].kind;
      if (kind == 12) { auto p = parents; p.push_back(c); walk(c, name + ".", p); }
      else if (kind == 10 || kind == 11 || kind == 13 || kind == 8) { if (kind != 8) { f.skipped.push_back(name + (kind == 10 ? " (list)" : kind == 11 ? " (map)" : " (union)")); continue; } leaves.push_back({c, name, parents}); }
      else leaves.push_back({c, name, parents});
    }
  };
  walk(0, "", {});
  std::vector<size_t> use;
  for (size_t k = 0; k < leaves.size(); k++) {
    bool want = o.cols.empty();
    for (const auto &c : o.cols) if (c == leaves[k].name || leaves[k].name.rfind(c + ".", 0) == 0) want = true;
    if (want) use.push_back(k);
  }
  for (const auto &c : o.cols) {
    bool found = false;
    for (const auto &l : leaves) if (l.name == c || l.name.rfind(c + ".", 0) == 0) found = true;
    if (!found) { std::string j; for (auto &l : leaves) j += (j.empty() ? "" : ", ") + l.name; err = "no column '" + c + "' (columns: " + j + ")"; return false; }
  }
  for (size_t k : use) { f.table.cols.push_back(leaves[k].name); f.types.push_back(KIND_NAMES[std::min(types[leaves[k].id].kind, 18)]); }
  // stripe statistics
  std::vector<PB> stripeStats;
  if (metaLen) {
    std::string metaRaw;
    if (unchunk(b.substr(b.size() - 1 - psLen - footerLen - metaLen, metaLen), codec, metaRaw, err)) {
      PB meta;
      if (meta.parse(metaRaw)) stripeStats = meta.all(1);
    }
    err.clear();
  }
  std::vector<PB> stripes = footer.all(3);
  for (size_t si = 0; si < stripes.size(); si++) {
    const PB &st = stripes[si];
    ColGroup cg;
    cg.rows = static_cast<size_t>(st.u(5));
    cg.bytes = st.u(2) + st.u(3) + st.u(4);
    if (si < stripeStats.size()) {
      std::vector<PB> cs = stripeStats[si].all(1);
      for (size_t k : use) cg.stats.push_back(leaves[k].id < cs.size() ? orcStats(cs[leaves[k].id], types[leaves[k].id].kind) : ColStats());
    } else cg.stats.assign(use.size(), ColStats());
    f.groups.push_back(cg);
    if (o.metaOnly) continue;
    if (!o.groups.empty() && std::find(o.groups.begin(), o.groups.end(), si) == o.groups.end()) continue;
    int pdCol = -1;
    if (o.pushdown.active) for (size_t k = 0; k < use.size(); k++) if (leaves[use[k]].name == o.pushdown.col) pdCol = static_cast<int>(k);
    if (pdCol >= 0 && !o.pushdown.mayMatch(cg.stats[static_cast<size_t>(pdCol)])) continue;
    uint64_t off = st.u(1), il = st.u(2), dl = st.u(3), fl = st.u(4);
    if (off + il + dl + fl > b.size()) { err = "an ORC stripe runs past the end of the file"; return false; }
    std::string sfRaw;
    if (!unchunk(b.substr(static_cast<size_t>(off + il + dl), static_cast<size_t>(fl)), codec, sfRaw, err)) return false;
    PB sf;
    sf.parse(sfRaw);
    std::map<std::pair<uint32_t, int>, std::string> streams;
    uint64_t pos = off;
    for (const auto &s : sf.all(1)) {
      int kind = static_cast<int>(s.u(1));
      uint32_t col = static_cast<uint32_t>(s.u(2));
      uint64_t len = s.u(3);
      if (pos + len > b.size()) { err = "an ORC stream runs past the end of the file"; return false; }
      if (kind <= 5) {
        std::string data;
        if (!unchunk(b.substr(static_cast<size_t>(pos), static_cast<size_t>(len)), codec, data, err)) return false;
        streams[{col, kind}] = data;
      }
      pos += len;
    }
    std::vector<PB> encs = sf.all(2);
    auto encOf = [&](uint32_t c) { return c < encs.size() ? static_cast<int>(encs[c].u(1)) : 0; };
    auto stream = [&](uint32_t c, int k) -> const std::string & { static const std::string empty; auto it = streams.find({c, k}); return it == streams.end() ? empty : it->second; };
    size_t rows = cg.rows;
    // presence of a column, given its parents' presence
    auto presence = [&](uint32_t id, const std::vector<bool> &outer, std::vector<bool> &out) {
      size_t n = 0;
      for (bool x : outer) n += x;
      std::vector<bool> own;
      const std::string &ps2 = stream(id, 0);
      if (!ps2.empty()) boolRle(ps2, n, own); else own.assign(n, true);
      out.assign(outer.size(), false);
      size_t k = 0;
      for (size_t r = 0; r < outer.size(); r++) if (outer[r]) out[r] = k < own.size() && own[k++];
    };
    std::vector<std::vector<Value>> colVals;
    for (size_t k : use) {
      const Leaf &l = leaves[k];
      const OrcType &t = types[l.id];
      std::vector<bool> present(rows, true);
      for (uint32_t p : l.parents) { std::vector<bool> np; presence(p, present, np); present = np; }
      std::vector<bool> mine;
      presence(l.id, present, mine);
      size_t n = 0;
      for (bool x : mine) n += x;
      std::vector<Value> vals;
      vals.reserve(n);
      int enc = encOf(l.id);
      const std::string &data = stream(l.id, 1);
      switch (t.kind) {
      case 0: { std::vector<bool> bv; boolRle(data, n, bv); for (bool x : bv) vals.push_back(Value::boolean(x)); break; }
      case 1: { std::vector<uint8_t> bv; byteRle(data, n, bv); for (auto x : bv) vals.push_back(Value(static_cast<double>(static_cast<int8_t>(x)))); break; }
      case 2: case 3: case 4: case 15: {
        std::vector<int64_t> iv;
        if (!ints(data, n, true, enc, iv)) { err = "column '" + l.name + "': bad integer data"; return false; }
        for (auto x : iv) vals.push_back(t.kind == 15 ? Value(isoDate(x)) : Value(static_cast<double>(x)));
        break;
      }
      case 5: for (size_t i = 0; i < n && (i + 1) * 4 <= data.size(); i++) vals.push_back(Value(static_cast<double>(f32le(data, i * 4)))); break;
      case 6: for (size_t i = 0; i < n && (i + 1) * 8 <= data.size(); i++) vals.push_back(Value(f64le(data, i * 8))); break;
      case 7: case 8: case 16: case 17: {
        if (enc == 1 || enc == 3) { // dictionary
          size_t dsize = static_cast<size_t>(l.id < encs.size() ? encs[l.id].u(2) : 0);
          std::vector<int64_t> lens, idx;
          if (!ints(stream(l.id, 2), dsize, false, enc, lens) || !ints(data, n, false, enc, idx)) { err = "column '" + l.name + "': bad dictionary"; return false; }
          const std::string &dd = stream(l.id, 3);
          std::vector<std::string> dict;
          size_t q = 0;
          for (auto len : lens) { dict.push_back(dd.substr(q, static_cast<size_t>(len))); q += static_cast<size_t>(len); }
          for (auto i : idx) vals.push_back(i >= 0 && static_cast<size_t>(i) < dict.size() ? Value(dict[static_cast<size_t>(i)]) : Value(std::nan("")));
        } else {
          std::vector<int64_t> lens;
          if (!ints(stream(l.id, 2), n, false, enc, lens)) { err = "column '" + l.name + "': bad string lengths"; return false; }
          size_t q = 0;
          for (auto len : lens) { vals.push_back(Value(data.substr(q, static_cast<size_t>(len)))); q += static_cast<size_t>(len); }
        }
        if (t.kind == 17) for (auto &v : vals) { std::string s = v.text(); while (!s.empty() && s.back() == ' ') s.pop_back(); v = Value(s); }
        break;
      }
      case 9: case 18: {
        std::vector<int64_t> secs, nanos;
        if (!ints(data, n, true, enc, secs) || !ints(stream(l.id, 5), n, false, enc, nanos)) { err = "column '" + l.name + "': bad timestamps"; return false; }
        for (size_t i = 0; i < n; i++) {
          int64_t z = nanos[i] & 7, ns = nanos[i] >> 3;
          if (z) for (int64_t k2 = 0; k2 <= z; k2++) ns *= 10;
          int64_t unix = secs[i] + 1420070400; // ORC counts from 2015-01-01
          if (unix < 0 && ns > 999999) unix -= 1; // as the Apache ORC readers do for pre-1970 times
          double t2 = static_cast<double>(unix) + static_cast<double>(ns) / 1e9;
          vals.push_back(Value(isoTimestamp(t2, ns ? 6 : 0)));
        }
        break;
      }
      case 14: {
        std::vector<int64_t> scales;
        ints(stream(l.id, 5), n, true, enc, scales);
        size_t q = 0;
        for (size_t i = 0; i < n; i++) {
          uint64_t v;
          if (!PB::varint(data, q, v)) { vals.push_back(Value(std::nan(""))); continue; }
          int sc = i < scales.size() ? static_cast<int>(scales[i]) : t.scale;
          vals.push_back(Value(static_cast<double>(unzig(v)) / std::pow(10.0, sc)));
        }
        break;
      }
      default: break;
      }
      std::vector<Value> full;
      full.reserve(rows);
      size_t vi = 0;
      for (size_t r = 0; r < rows; r++) full.push_back(mine[r] && vi < vals.size() ? vals[vi++] : Value(std::nan("")));
      colVals.push_back(std::move(full));
    }
    for (size_t r = 0; r < rows; r++) {
      std::vector<Value> row;
      for (auto &c : colVals) row.push_back(c[r]);
      f.table.rows.push_back(std::move(row));
    }
  }
  return true;
}

// ---- writer --------------------------------------------------------------------------------------

namespace {

void byteRleWrite(std::string &o, const std::vector<uint8_t> &v) {
  for (size_t i = 0; i < v.size();) {
    size_t j = i;
    while (j < v.size() && v[j] == v[i] && j - i < 130) j++;
    if (j - i >= 3) { o.push_back(static_cast<char>(j - i - 3)); o.push_back(static_cast<char>(v[i])); i = j; continue; }
    size_t k = i;
    while (k < v.size() && k - i < 128) {
      if (k + 2 < v.size() && v[k] == v[k + 1] && v[k] == v[k + 2]) break;
      k++;
    }
    o.push_back(static_cast<char>(-static_cast<int>(k - i)));
    for (size_t x = i; x < k; x++) o.push_back(static_cast<char>(v[x]));
    i = k;
  }
}

void boolWrite(std::string &o, const std::vector<bool> &v) {
  std::vector<uint8_t> bytes((v.size() + 7) / 8, 0);
  for (size_t i = 0; i < v.size(); i++) if (v[i]) bytes[i / 8] |= static_cast<uint8_t>(0x80 >> (i % 8));
  byteRleWrite(o, bytes);
}

// RLE v2: SHORT_REPEAT for short runs of one value, otherwise DIRECT blocks of up to 512
void intWriteV2(std::string &o, const std::vector<int64_t> &v, bool sign) {
  auto zz = [&](int64_t x) { return sign ? (static_cast<uint64_t>(x) << 1) ^ static_cast<uint64_t>(x >> 63) : static_cast<uint64_t>(x); };
  for (size_t i = 0; i < v.size();) {
    size_t j = i;
    while (j < v.size() && v[j] == v[i] && j - i < 10) j++;
    if (j - i >= 3) {
      uint64_t z = zz(v[i]);
      int bytes = 1;
      while (bytes < 8 && (z >> (8 * bytes))) bytes++;
      o.push_back(static_cast<char>(((bytes - 1) << 3) | static_cast<int>(j - i - 3)));
      for (int k = bytes - 1; k >= 0; k--) o.push_back(static_cast<char>((z >> (8 * k)) & 0xFF));
      i = j;
      continue;
    }
    size_t n = std::min<size_t>(512, v.size() - i);
    uint64_t mx = 0;
    for (size_t k = i; k < i + n; k++) mx = std::max(mx, zz(v[k]));
    int bits = 1;
    while (bits < 64 && (mx >> bits)) bits++;
    int code = codeOf(bits), w = widthOf(code);
    o.push_back(static_cast<char>((1 << 6) | (code << 1) | static_cast<int>(((n - 1) >> 8) & 1)));
    o.push_back(static_cast<char>((n - 1) & 0xFF));
    uint64_t acc = 0;
    int have = 0;
    for (size_t k = i; k < i + n; k++) {
      uint64_t z = zz(v[k]);
      for (int bI = w - 1; bI >= 0; bI--) {
        acc = (acc << 1) | ((z >> bI) & 1);
        if (++have == 8) { o.push_back(static_cast<char>(acc)); acc = 0; have = 0; }
      }
    }
    if (have) o.push_back(static_cast<char>(acc << (8 - have)));
    i += n;
  }
}

void writeColStats(PW &w, int id, const std::string &kind, const std::vector<const Value *> &present, size_t nulls) {
  PW s;
  s.u(1, present.size());
  if (!present.empty()) {
    if (kind == "int64") {
      int64_t mn = static_cast<int64_t>(present[0]->number), mx = mn, sum = 0;
      for (auto *v : present) { int64_t x = static_cast<int64_t>(v->number); mn = std::min(mn, x); mx = std::max(mx, x); sum += x; }
      PW i; i.s(1, mn); i.s(2, mx); i.s(3, sum); s.b(2, i.o);
    } else if (kind == "float64") {
      double mn = present[0]->number, mx = mn, sum = 0;
      for (auto *v : present) { mn = std::min(mn, v->number); mx = std::max(mx, v->number); sum += v->number; }
      PW d; d.d(1, mn); d.d(2, mx); d.d(3, sum); s.b(3, d.o);
    } else if (kind == "str") {
      std::string mn = cellText(*present[0]), mx = mn;
      int64_t sum = 0;
      for (auto *v : present) { std::string t = cellText(*v); mn = std::min(mn, t); mx = std::max(mx, t); sum += static_cast<int64_t>(t.size()); }
      PW t; t.b(1, mn); t.b(2, mx); t.s(3, sum); s.b(4, t.o);
    } else if (kind == "bool") {
      uint64_t trues = 0;
      for (auto *v : present) trues += v->number != 0;
      PW bk; std::string packed; PW tmp; tmp.varint(trues); bk.b(1, tmp.o); s.b(5, bk.o);
    }
  }
  s.u(10, nulls ? 1 : 0);
  w.b(id, s.o);
}

} // namespace

std::string writeOrc(const Table &t, const ColWriteOptions &o, std::string &err) {
  int codec;
  if (o.codec == "none") codec = 0;
  else if (o.codec == "zlib" || o.codec == "gzip") codec = 1;
  else if (o.codec == "snappy") codec = 2;
  else if (o.codec == "lz4") codec = 4;
  else if (o.codec == "zstd") codec = 5;
  else { err = "orc supports compress=\"zstd\", \"snappy\", \"lz4\", \"zlib\" or \"none\""; return ""; }
  const size_t block = 256 * 1024;
  std::vector<std::string> kinds = writeKinds(t);
  size_t ncols = t.cols.size(), nrows = t.rows.size();
  size_t groupRows = o.groupRows ? o.groupRows : std::max<size_t>(1, std::min<size_t>(nrows, 1000000));
  std::string out = "ORC";
  std::vector<std::string> stripeInfo, stripeStat;
  std::vector<std::vector<const Value *>> allPresent(ncols);
  std::vector<size_t> allNulls(ncols, 0);
  for (size_t from = 0; from < nrows || (nrows == 0 && stripeInfo.empty()); from += groupRows) {
    size_t to = std::min(nrows, from + groupRows), n = to - from;
    uint64_t offset = out.size();
    std::string data;
    PW sfoot;
    PW statsMsg;
    { PW root; root.u(1, n); root.u(10, 0); statsMsg.b(1, root.o); }
    for (size_t c = 0; c < ncols; c++) {
      const std::string &k = kinds[c];
      uint32_t col = static_cast<uint32_t>(c + 1);
      std::vector<bool> present;
      std::vector<const Value *> vals;
      size_t nulls = 0;
      for (size_t r = from; r < to; r++) {
        const Value &v = t.rows[r][c];
        bool null = (!v.isText && std::isnan(v.number)) || (k != "str" && v.isText);
        present.push_back(!null);
        if (null) nulls++; else vals.push_back(&v);
      }
      for (auto *v : vals) allPresent[c].push_back(v);
      allNulls[c] += nulls;
      auto addStream = [&](int kind, const std::string &raw) {
        std::string s = chunkUp(raw, codec, o.level, block);
        PW st;
        st.u(1, static_cast<uint64_t>(kind));
        st.u(2, col);
        st.u(3, s.size());
        sfoot.b(1, st.o);
        data += s;
      };
      if (nulls) { std::string ps2; boolWrite(ps2, present); addStream(0, ps2); }
      if (k == "int64") {
        std::vector<int64_t> iv;
        for (auto *v : vals) iv.push_back(static_cast<int64_t>(v->number));
        std::string d;
        intWriteV2(d, iv, true);
        addStream(1, d);
      } else if (k == "float64") {
        std::string d;
        for (auto *v : vals) putF64LE(d, v->number);
        addStream(1, d);
      } else if (k == "bool") {
        std::vector<bool> bv;
        for (auto *v : vals) bv.push_back(v->number != 0);
        std::string d;
        boolWrite(d, bv);
        addStream(1, d);
      } else {
        std::string d, l;
        std::vector<int64_t> lens;
        for (auto *v : vals) { std::string s = cellText(*v); d += s; lens.push_back(static_cast<int64_t>(s.size())); }
        intWriteV2(l, lens, false);
        addStream(1, d);
        addStream(2, l);
      }
      writeColStats(statsMsg, 1, k, vals, nulls);
    }
    // column encodings: root DIRECT, then DIRECT_V2 for ints/strings, DIRECT otherwise
    { PW e; e.u(1, 0); sfoot.b(2, e.o); }
    for (size_t c = 0; c < ncols; c++) { PW e; e.u(1, kinds[c] == "int64" || kinds[c] == "str" ? 2 : 0); sfoot.b(2, e.o); }
    sfoot.b(3, "UTC");
    std::string sf = chunkUp(sfoot.o, codec, o.level, block);
    out += data + sf;
    PW si;
    si.u(1, offset);
    si.u(2, 0);
    si.u(3, data.size());
    si.u(4, sf.size());
    si.u(5, n);
    stripeInfo.push_back(si.o);
    stripeStat.push_back(statsMsg.o);
    if (nrows == 0) break;
  }
  uint64_t contentLength = out.size() - 3;
  PW meta;
  for (const auto &s : stripeStat) meta.b(1, s);
  std::string metaC = chunkUp(meta.o, codec, o.level, block);
  PW footer;
  footer.u(1, 3);
  footer.u(2, contentLength);
  for (const auto &s : stripeInfo) footer.b(3, s);
  { // types
    PW root;
    root.u(1, 12);
    PW subs;
    for (size_t c = 0; c < ncols; c++) subs.varint(c + 1);
    root.b(2, subs.o);
    for (const auto &n : t.cols) root.b(3, n);
    footer.b(4, root.o);
    for (size_t c = 0; c < ncols; c++) {
      PW ty;
      ty.u(1, kinds[c] == "int64" ? 4 : kinds[c] == "float64" ? 6 : kinds[c] == "bool" ? 0 : 7);
      footer.b(4, ty.o);
    }
  }
  for (const auto &kv : o.kv) { PW m; m.b(1, kv.first); m.b(2, kv.second); footer.b(5, m.o); }
  footer.u(6, nrows);
  { PW root; root.u(1, nrows); root.u(10, 0); footer.b(7, root.o); }
  for (size_t c = 0; c < ncols; c++) writeColStats(footer, 7, kinds[c], allPresent[c], allNulls[c]);
  footer.u(8, 0);
  std::string footerC = chunkUp(footer.o, codec, o.level, block);
  PW ps;
  ps.u(1, footerC.size());
  ps.u(2, static_cast<uint64_t>(codec));
  if (codec) ps.u(3, block);
  PW ver;
  ver.varint(0);
  ver.varint(12);
  ps.b(4, ver.o);
  ps.u(5, metaC.size());
  ps.u(6, 6);
  ps.b(8000, "ORC");
  out += metaC + footerC + ps.o;
  out.push_back(static_cast<char>(ps.o.size()));
  return out;
}

} // namespace io
} // namespace nc
