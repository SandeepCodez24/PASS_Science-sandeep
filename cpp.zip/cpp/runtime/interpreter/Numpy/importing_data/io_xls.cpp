// .xls (BIFF8 inside OLE2) reader / writer, and MS-OVBA module extraction
// for the vbaProject.bin of .xlsm files.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_ole2.h"
#include "io_sheet.h"

namespace nc {
namespace io {
namespace {

// ---- formula tokens (subset) --------------------------------------------------

struct FnInfo {
  int id;
  const char *name;
  int argc; // -1 = variable
};
const FnInfo kFns[] = {{0, "COUNT", -1},   {1, "IF", -1},     {4, "SUM", -1},       {5, "AVERAGE", -1},
                       {6, "MIN", -1},     {7, "MAX", -1},    {20, "SQRT", 1},      {24, "ABS", 1},
                       {27, "ROUND", 2},   {32, "LEN", 1},    {183, "PRODUCT", -1}, {336, "CONCATENATE", -1}};

const FnInfo *fnById(int id) {
  for (const auto &f : kFns)
    if (f.id == id) return &f;
  return nullptr;
}
const FnInfo *fnByName(const std::string &n) {
  for (const auto &f : kFns)
    if (n == f.name || (n == "CONCAT" && std::string(f.name) == "CONCATENATE")) return &f;
  return nullptr;
}

std::string refText(uint16_t row, uint16_t colField) {
  size_t col = colField & 0x00FF;
  std::string s;
  if (!(colField & 0x4000)) s += "$";
  s += columnName(col);
  if (!(colField & 0x8000)) s += "$";
  return s + std::to_string(row + 1);
}

// RPN -> infix text. False when a token is not in the subset.
bool decodeFormula(const std::string &rgce, std::string &out) {
  std::vector<std::string> st;
  size_t i = 0;
  auto pop = [&]() { std::string s = st.empty() ? "" : st.back(); if (!st.empty()) st.pop_back(); return s; };
  static const char *binops[] = {"+", "-", "*", "/", "^", "&", "<", "<=", "=", ">=", ">", "<>"};
  while (i < rgce.size()) {
    unsigned char t = static_cast<unsigned char>(rgce[i++]);
    unsigned char base = t & 0x1F;
    if (t >= 0x03 && t <= 0x0E) {
      std::string b = pop(), a = pop();
      st.push_back(a + binops[t - 0x03] + b);
    } else if (t == 0x12) st.back() = "+" + st.back();
    else if (t == 0x13) st.back() = "-" + st.back();
    else if (t == 0x14) st.back() += "%";
    else if (t == 0x15) st.back() = "(" + st.back() + ")";
    else if (t == 0x17) { // ptgStr
      size_t cch = static_cast<unsigned char>(rgce[i]);
      bool wide = rgce[i + 1] & 1;
      i += 2;
      std::string s;
      for (size_t k = 0; k < cch; k++) {
        s.push_back(wide ? static_cast<char>(rgce[i + 2 * k]) : rgce[i + k]);
      }
      i += wide ? 2 * cch : cch;
      st.push_back("\"" + s + "\"");
    } else if (t == 0x19) { // ptgAttr
      unsigned char grbit = static_cast<unsigned char>(rgce[i]);
      uint16_t w = u16le(rgce, i + 1);
      i += 3;
      if (grbit & 0x04) i += 2 * (w + 1); // choose jump table
      if (grbit & 0x10) st.back() = "SUM(" + st.back() + ")";
    } else if (t == 0x1C) { i++; st.push_back("#ERR"); }
    else if (t == 0x1D) { st.push_back(rgce[i++] ? "TRUE" : "FALSE"); }
    else if (t == 0x1E) { st.push_back(std::to_string(u16le(rgce, i))); i += 2; }
    else if (t == 0x1F) { st.push_back(numberText(f64le(rgce, i))); i += 8; }
    else if (base == 0x04) { st.push_back(refText(u16le(rgce, i), u16le(rgce, i + 2))); i += 4; }   // ptgRef
    else if (base == 0x05) {                                                                         // ptgArea
      st.push_back(refText(u16le(rgce, i), u16le(rgce, i + 4)) + ":" + refText(u16le(rgce, i + 2), u16le(rgce, i + 6)));
      i += 8;
    } else if (base == 0x01) { // ptgFunc
      const FnInfo *f = fnById(u16le(rgce, i));
      i += 2;
      if (!f || f->argc < 0) return false;
      std::vector<std::string> a(static_cast<size_t>(f->argc));
      for (int k = f->argc - 1; k >= 0; k--) a[static_cast<size_t>(k)] = pop();
      std::string s = std::string(f->name) + "(";
      for (size_t k = 0; k < a.size(); k++) s += (k ? "," : "") + a[k];
      st.push_back(s + ")");
    } else if (base == 0x02) { // ptgFuncVar
      int argc = static_cast<unsigned char>(rgce[i]) & 0x7F;
      const FnInfo *f = fnById(u16le(rgce, i + 1) & 0x7FFF);
      i += 3;
      if (!f) return false;
      std::vector<std::string> a(static_cast<size_t>(argc));
      for (int k = argc - 1; k >= 0; k--) a[static_cast<size_t>(k)] = pop();
      std::string s = std::string(f->name) + "(";
      for (size_t k = 0; k < a.size(); k++) s += (k ? "," : "") + a[k];
      st.push_back(s + ")");
    } else {
      return false;
    }
  }
  if (st.size() != 1) return false;
  out = st[0];
  return true;
}

// Infix -> RPN (same subset). False with err when not encodable.
struct FormulaEncoder {
  const std::string &f;
  size_t i = 0;
  std::string out, err;
  explicit FormulaEncoder(const std::string &s) : f(s) {}
  void ws() { while (i < f.size() && f[i] == ' ') i++; }
  bool ref(const std::string &w, uint16_t &row, uint16_t &col) {
    size_t r, c;
    if (!parseAddress(w, r, c) || r > 65535 || c > 255) return false;
    row = static_cast<uint16_t>(r);
    col = static_cast<uint16_t>(c);
    if (w.find('$') == std::string::npos) col |= 0xC000;
    else {
      size_t d1 = w.find('$');
      bool colAbs = d1 == 0;
      bool rowAbs = w.find('$', colAbs ? 1 : 0) != std::string::npos && (colAbs ? w.find('$', 1) != std::string::npos : true);
      if (!colAbs) col |= 0x4000;
      if (!rowAbs) col |= 0x8000;
    }
    return true;
  }
  bool primary() {
    ws();
    if (i >= f.size()) { err = "formula ends early"; return false; }
    char c = f[i];
    if (c == '(') { i++; if (!expr()) return false; ws(); if (i >= f.size() || f[i] != ')') { err = "missing )"; return false; } i++; out.push_back(0x15); return true; }
    if (c == '-' || c == '+') { i++; if (!primary()) return false; out.push_back(c == '-' ? 0x13 : 0x12); return true; }
    if (c == '"') {
      size_t e = f.find('"', i + 1);
      std::string s = f.substr(i + 1, e - i - 1);
      i = e == std::string::npos ? f.size() : e + 1;
      out.push_back(0x17); out.push_back(static_cast<char>(s.size())); out.push_back(0);
      out += s;
      return true;
    }
    if (std::isdigit(static_cast<unsigned char>(c)) || c == '.') {
      char *e = nullptr;
      double d = std::strtod(f.c_str() + i, &e);
      i = static_cast<size_t>(e - f.c_str());
      if (d == std::floor(d) && d >= 0 && d <= 65535) { out.push_back(0x1E); putLE(out, static_cast<uint64_t>(d), 2); }
      else { out.push_back(0x1F); putF64LE(out, d); }
      return true;
    }
    size_t b = i;
    while (i < f.size() && (std::isalnum(static_cast<unsigned char>(f[i])) || f[i] == '$' || f[i] == '_')) i++;
    std::string w = f.substr(b, i - b), up = w;
    for (char &ch : up) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    ws();
    if (i < f.size() && f[i] == '(') {
      const FnInfo *fn = fnByName(up);
      if (!fn) { err = "function " + up + " cannot be written to .xls (supported: SUM AVERAGE MIN MAX COUNT IF ABS ROUND SQRT LEN PRODUCT CONCATENATE)"; return false; }
      i++;
      int argc = 0;
      ws();
      if (i < f.size() && f[i] == ')') i++;
      else for (;;) {
        if (!expr()) return false;
        argc++;
        ws();
        if (i < f.size() && f[i] == ',') { i++; continue; }
        if (i < f.size() && f[i] == ')') { i++; break; }
        err = "bad argument list";
        return false;
      }
      if (fn->argc >= 0) { out.push_back(0x41); putLE(out, static_cast<uint64_t>(fn->id), 2); }
      else { out.push_back(0x42); out.push_back(static_cast<char>(argc)); putLE(out, static_cast<uint64_t>(fn->id), 2); }
      return true;
    }
    if (up == "TRUE" || up == "FALSE") { out.push_back(0x1D); out.push_back(up == "TRUE"); return true; }
    uint16_t r0, c0;
    if (!ref(w, r0, c0)) { err = "'" + w + "' is not a cell reference"; return false; }
    if (i < f.size() && f[i] == ':') {
      i++;
      size_t b2 = i;
      while (i < f.size() && (std::isalnum(static_cast<unsigned char>(f[i])) || f[i] == '$')) i++;
      uint16_t r1, c1;
      if (!ref(f.substr(b2, i - b2), r1, c1)) { err = "bad range"; return false; }
      out.push_back(0x25);
      putLE(out, r0, 2); putLE(out, r1, 2); putLE(out, c0, 2); putLE(out, c1, 2);
      return true;
    }
    out.push_back(0x24);
    putLE(out, r0, 2); putLE(out, c0, 2);
    return true;
  }
  bool level(int lv) {
    if (lv == 4) return primary();
    if (!level(lv + 1)) return false;
    for (;;) {
      ws();
      if (i >= f.size()) return true;
      int op = -1;
      size_t len = 1;
      if (lv == 0) {
        if (f.compare(i, 2, "<=") == 0) { op = 0x0A; len = 2; }
        else if (f.compare(i, 2, ">=") == 0) { op = 0x0C; len = 2; }
        else if (f.compare(i, 2, "<>") == 0) { op = 0x0E; len = 2; }
        else if (f[i] == '=') op = 0x0B;
        else if (f[i] == '<') op = 0x09;
        else if (f[i] == '>') op = 0x0D;
      } else if (lv == 1 && f[i] == '&') op = 0x08;
      else if (lv == 2 && (f[i] == '+' || f[i] == '-')) op = f[i] == '+' ? 0x03 : 0x04;
      else if (lv == 3 && (f[i] == '*' || f[i] == '/' || f[i] == '^')) op = f[i] == '*' ? 0x05 : f[i] == '/' ? 0x06 : 0x07;
      if (op < 0) return true;
      i += len;
      if (!level(lv + 1)) return false;
      out.push_back(static_cast<char>(op));
    }
  }
  bool expr() { return level(0); }
};

// ---- BIFF reading -------------------------------------------------------------

struct Rec {
  uint16_t id;
  std::string data;
  std::vector<std::string> cont; // following CONTINUE records
  size_t offset;
};

std::vector<Rec> records(const std::string &s, size_t from, bool stopAtEof) {
  std::vector<Rec> out;
  size_t p = from;
  int depth = 0;
  while (p + 4 <= s.size()) {
    uint16_t id = u16le(s, p), len = u16le(s, p + 2);
    if (p + 4 + len > s.size()) break;
    std::string d = s.substr(p + 4, len);
    if (id == 0x003C && !out.empty()) out.back().cont.push_back(d);
    else out.push_back({id, d, {}, p});
    p += 4 + len;
    if (id == 0x0809) depth++;
    if (id == 0x000A) {
      depth--;
      if (stopAtEof && depth <= 0) break;
    }
  }
  return out;
}

// Reads an XLUnicodeRichExtendedString across record pieces.
struct PieceReader {
  std::vector<const std::string *> pieces;
  size_t piece = 0, pos = 0;
  bool more() const { return piece < pieces.size() && (pos < pieces[piece]->size() || piece + 1 < pieces.size()); }
  void norm() { while (piece < pieces.size() && pos >= pieces[piece]->size() && piece + 1 < pieces.size()) { piece++; pos = 0; } }
  uint8_t byte() { norm(); if (piece >= pieces.size() || pos >= pieces[piece]->size()) return 0; return static_cast<uint8_t>((*pieces[piece])[pos++]); }
  uint16_t u16() { uint16_t a = byte(); return static_cast<uint16_t>(a | (byte() << 8)); }
  uint32_t u32() { uint32_t a = u16(); return a | (static_cast<uint32_t>(u16()) << 16); }
  void skip(size_t n) { while (n--) byte(); }
  std::string chars(size_t cch, bool wide) {
    std::string out;
    for (size_t k = 0; k < cch; k++) {
      // a CONTINUE boundary inside the characters restates the flag byte
      if (piece < pieces.size() && pos >= pieces[piece]->size() && piece + 1 < pieces.size()) {
        piece++;
        pos = 0;
        wide = byte() & 1;
      }
      uint32_t c = wide ? u16() : byte();
      if (c < 0x80) out.push_back(static_cast<char>(c));
      else if (c < 0x800) { out.push_back(static_cast<char>(0xC0 | (c >> 6))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
      else { out.push_back(static_cast<char>(0xE0 | (c >> 12))); out.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); out.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    }
    return out;
  }
  std::string richString() {
    uint16_t cch = u16();
    uint8_t flags = byte();
    uint16_t runs = (flags & 0x08) ? u16() : 0;
    uint32_t ext = (flags & 0x04) ? u32() : 0;
    std::string s = chars(cch, flags & 1);
    skip(4u * runs + ext);
    return s;
  }
};

std::string shortString(const std::string &d, size_t at, bool cch16 = false) {
  PieceReader pr;
  std::string tail = d.substr(at);
  pr.pieces = {&tail};
  size_t cch = cch16 ? pr.u16() : pr.byte();
  uint8_t flags = pr.byte();
  return pr.chars(cch, flags & 1);
}

double rkValue(uint32_t rk) {
  double d;
  if (rk & 2) d = static_cast<double>(static_cast<int32_t>(rk) >> 2);
  else {
    uint64_t bits = static_cast<uint64_t>(rk & 0xFFFFFFFC) << 32;
    std::memcpy(&d, &bits, 8);
  }
  return (rk & 1) ? d / 100 : d;
}

// ---- BIFF writing -------------------------------------------------------------

void rec(std::string &s, uint16_t id, const std::string &d) {
  // records longer than 8224 bytes continue in CONTINUE records
  size_t p = 0;
  bool first = true;
  do {
    size_t n = std::min<size_t>(8224, d.size() - p);
    putLE(s, first ? id : 0x003C, 2);
    putLE(s, n, 2);
    s.append(d, p, n);
    p += n;
    first = false;
  } while (p < d.size());
}

std::string u16str(const std::string &utf8, bool cch16) {
  std::vector<uint16_t> w;
  for (size_t i = 0; i < utf8.size();) {
    unsigned char c = static_cast<unsigned char>(utf8[i]);
    uint32_t cp;
    if (c < 0x80) { cp = c; i++; }
    else if (c < 0xE0) { cp = ((c & 0x1F) << 6) | (utf8[i + 1] & 0x3F); i += 2; }
    else if (c < 0xF0) { cp = ((c & 0x0F) << 12) | ((utf8[i + 1] & 0x3F) << 6) | (utf8[i + 2] & 0x3F); i += 3; }
    else { cp = '?'; i += 4; }
    w.push_back(static_cast<uint16_t>(cp));
  }
  std::string out;
  putLE(out, w.size(), cch16 ? 2 : 1);
  out.push_back(1);
  for (uint16_t c : w) putLE(out, c, 2);
  return out;
}

} // namespace

bool readXls(const std::string &bytes, Workbook &wb, std::string &err) {
  wb = Workbook();
  Ole2Reader ole;
  if (!ole.open(bytes, err))
    return false;
  std::string book;
  if (!ole.read("Workbook", book)) {
    if (ole.read("Book", book)) {
      err = "this is an Excel 5/95 (BIFF5) workbook; only Excel 97-2003 (BIFF8) .xls is built in";
      return false;
    }
    err = "the OLE2 file has no Workbook stream (not an Excel file?)";
    return false;
  }
  std::vector<Rec> globals = records(book, 0, true);
  std::vector<std::string> sst;
  std::vector<std::pair<std::string, uint32_t>> sheets; // name, offset
  std::map<int, std::string> formats;
  std::vector<std::pair<int, int>> xfs; // fmt, font
  std::vector<bool> fontBold;
  bool date1904 = false;
  for (const Rec &r : globals) {
    switch (r.id) {
      case 0x0085:
        if (r.data.size() >= 8 && static_cast<unsigned char>(r.data[5]) == 0)
          sheets.push_back({shortString(r.data, 6), u32le(r.data, 0)});
        break;
      case 0x00FC: {
        PieceReader pr;
        pr.pieces.push_back(&r.data);
        for (const auto &c : r.cont) pr.pieces.push_back(&c);
        pr.u32();
        uint32_t unique = pr.u32();
        for (uint32_t k = 0; k < unique && pr.more(); k++) sst.push_back(pr.richString());
        break;
      }
      case 0x041E: formats[u16le(r.data, 0)] = shortString(r.data, 2, true); break;
      case 0x00E0: xfs.push_back({u16le(r.data, 2), u16le(r.data, 0)}); break;
      case 0x0031:
        fontBold.push_back(u16le(r.data, 6) >= 700);
        if (fontBold.size() == 4) fontBold.push_back(false); // index 4 does not exist
        break;
      case 0x0022: date1904 = u16le(r.data, 0) != 0; break;
      case 0x003D: wb.active = u16le(r.data, 10); break;
      default: break;
    }
  }
  auto xfInfo = [&](size_t xf, bool &isDate, bool &bold) {
    isDate = bold = false;
    if (xf >= xfs.size()) return;
    int fmt = xfs[xf].first;
    isDate = isDateFormat(fmt, formats.count(fmt) ? formats[fmt] : "");
    size_t font = static_cast<size_t>(xfs[xf].second);
    bold = font < fontBold.size() && fontBold[font];
  };
  for (const auto &sh : sheets) {
    Sheet s;
    s.name = sh.first;
    std::vector<Rec> recs = records(book, sh.second, true);
    std::map<uint16_t, std::string> objText;
    uint16_t lastObj = 0;
    int depth = 0;
    std::pair<size_t, size_t> pendingString{SIZE_MAX, 0};
    for (const Rec &r : recs) {
      const std::string &d = r.data;
      if (r.id == 0x0809) {
        depth++;
        if (depth == 2 && u16le(d, 2) == 0x0020) s.charts++;
        continue;
      }
      if (r.id == 0x000A) { depth--; continue; }
      if (depth > 1) continue; // inside an embedded chart
      auto put = [&](size_t row, size_t col, size_t xf, Value v) {
        SheetCell c;
        bool isDate, bold;
        xfInfo(xf, isDate, bold);
        if (isDate && isNumberCell(v)) v = Value(excelDateText(v.number + (date1904 ? 1462 : 0)));
        c.v = v;
        c.bold = bold;
        s.cells[{row, col}] = c;
      };
      switch (r.id) {
        case 0x00FD: {
          uint32_t k = u32le(d, 6);
          put(u16le(d, 0), u16le(d, 2), u16le(d, 4), Value(k < sst.size() ? sst[k] : std::string()));
          break;
        }
        case 0x0203: put(u16le(d, 0), u16le(d, 2), u16le(d, 4), Value(f64le(d, 6))); break;
        case 0x027E: put(u16le(d, 0), u16le(d, 2), u16le(d, 4), Value(rkValue(u32le(d, 6)))); break;
        case 0x00BD: {
          size_t row = u16le(d, 0), col = u16le(d, 2);
          size_t n = (d.size() - 6) / 6;
          for (size_t k = 0; k < n; k++)
            put(row, col + k, u16le(d, 4 + 6 * k), Value(rkValue(u32le(d, 6 + 6 * k))));
          break;
        }
        case 0x0204: put(u16le(d, 0), u16le(d, 2), u16le(d, 4), Value(shortString(d, 6, true))); break;
        case 0x0205:
          if (d[7]) put(u16le(d, 0), u16le(d, 2), u16le(d, 4), Value(std::string("#ERR")));
          else put(u16le(d, 0), u16le(d, 2), u16le(d, 4), Value::boolean(d[6] != 0));
          break;
        case 0x0006: {
          size_t row = u16le(d, 0), col = u16le(d, 2), xf = u16le(d, 4);
          Value v;
          bool special = static_cast<unsigned char>(d[12]) == 0xFF && static_cast<unsigned char>(d[13]) == 0xFF;
          if (!special) v = Value(f64le(d, 6));
          else if (d[6] == 1) v = Value::boolean(d[8] != 0);
          else if (d[6] == 2) v = Value(std::string("#ERR"));
          else v = Value(std::string());
          put(row, col, xf, v);
          std::string text;
          size_t cce = u16le(d, 20);
          if (decodeFormula(d.substr(22, cce), text))
            s.cells[{row, col}].fml = text;
          if (special && d[6] == 0)
            pendingString = {row, col};
          break;
        }
        case 0x0207:
          if (pendingString.first != SIZE_MAX) {
            s.cells[pendingString].v = Value(shortString(d, 0, true));
            pendingString = {SIZE_MAX, 0};
          }
          break;
        case 0x00E5: {
          size_t n = u16le(d, 0);
          for (size_t k = 0; k < n; k++) {
            size_t p = 2 + 8 * k;
            s.merged.push_back(addressOf(u16le(d, p), u16le(d, p + 4)) + ":" + addressOf(u16le(d, p + 2), u16le(d, p + 6)));
          }
          break;
        }
        case 0x0041: {
          size_t x = u16le(d, 0), y = u16le(d, 2);
          if (x || y) s.freeze = addressOf(y, x);
          break;
        }
        case 0x007D: {
          size_t a = u16le(d, 0), b = u16le(d, 2);
          for (size_t k = a; k <= b && k < 256; k++) {
            if (s.colWidths.size() <= k) s.colWidths.resize(k + 1, 0);
            s.colWidths[k] = u16le(d, 4) / 256.0;
          }
          break;
        }
        case 0x005D: // OBJ: first subrecord ftCmo holds the id
          if (d.size() >= 8 && u16le(d, 0) == 0x15) lastObj = u16le(d, 6);
          break;
        case 0x01B6: { // TXO, text in the first CONTINUE
          if (!r.cont.empty()) {
            PieceReader pr;
            pr.pieces = {&r.cont[0]};
            uint8_t flags = pr.byte();
            objText[lastObj] = pr.chars(u16le(d, 10), flags & 1);
          }
          break;
        }
        case 0x001C: {
          uint16_t id = u16le(d, 6);
          auto it = objText.find(id);
          s.boxes.push_back({addressOf(u16le(d, 0), u16le(d, 2)), it == objText.end() ? "" : it->second, "comment"});
          if (it != objText.end()) objText.erase(it);
          break;
        }
        case 0x00B0: s.pivots++; break;
        default: break;
      }
    }
    for (const auto &kv : objText) // text boxes that are not notes
      if (!kv.second.empty()) s.boxes.push_back({"", kv.second, "textbox"});
    wb.sheets.push_back(std::move(s));
  }
  // summary information is optional - just record the format
  wb.meta["application"] = Value(std::string("Excel 97-2003 (BIFF8)"));
  if (wb.active >= wb.sheets.size()) wb.active = 0;
  return true;
}

bool writeXls(const Workbook &wbIn, std::string &out, std::string &err) {
  Workbook wb = wbIn;
  std::vector<std::string> sst;
  std::map<std::string, size_t> sstIndex;
  std::vector<std::string> sheetStreams;
  for (auto &s : wb.sheets) {
    evaluateFormulas(s);
    for (const auto &b : s.boxes) { // .xls notes need drawing objects: the text goes into the cell
      size_t r = 0, c = 0;
      if (!b.pos.empty() && parseAddress(b.pos, r, c) && !s.cells.count({r, c})) {
        SheetCell cell;
        cell.v = Value(b.text);
        s.cells[{r, c}] = cell;
      }
    }
    size_t r0 = 0, c0 = 0, r1 = 0, c1 = 0;
    bool any = s.usedRange(r0, c0, r1, c1);
    if (any && (r1 > 65535 || c1 > 255)) {
      err = "sheet '" + s.name + "' is larger than .xls allows (65,536 rows x 256 columns) - use .xlsx";
      return false;
    }
    std::string b;
    rec(b, 0x0809, std::string("\x00\x06\x10\x00\xBB\x0D\xCC\x07\x00\x00\x00\x00\x06\x00\x00\x00", 16));
    std::string dim;
    putLE(dim, any ? r0 : 0, 4); putLE(dim, any ? r1 + 1 : 0, 4); putLE(dim, any ? c0 : 0, 2); putLE(dim, any ? c1 + 1 : 0, 2); putLE(dim, 0, 2);
    rec(b, 0x0200, dim);
    for (size_t c = 0; c < s.colWidths.size() && c < 256; c++)
      if (s.colWidths[c] > 0) {
        std::string ci;
        putLE(ci, c, 2); putLE(ci, c, 2); putLE(ci, static_cast<uint64_t>(s.colWidths[c] * 256), 2); putLE(ci, 15, 2); putLE(ci, 0, 2); putLE(ci, 0, 2);
        rec(b, 0x007D, ci);
      }
    for (const auto &kv : s.cells) {
      size_t row = kv.first.first, col = kv.first.second;
      const SheetCell &c = kv.second;
      uint16_t xf = c.bold ? 16 : 15;
      std::string d;
      putLE(d, row, 2); putLE(d, col, 2); putLE(d, xf, 2);
      if (!c.fml.empty()) {
        FormulaEncoder enc(c.fml);
        if (!enc.expr() || enc.i < c.fml.size()) {
          err = "cell " + addressOf(row, col) + ": " + (enc.err.empty() ? "formula cannot be written to .xls" : enc.err);
          return false;
        }
        std::string res(8, '\0');
        bool str = c.v.isText;
        if (!c.hasValue) { res[6] = '\xFF'; res[7] = '\xFF'; res[0] = 3; }
        else if (str) { res[6] = '\xFF'; res[7] = '\xFF'; res[0] = 0; }
        else if (c.v.isBool()) { res[6] = '\xFF'; res[7] = '\xFF'; res[0] = 1; res[2] = c.v.number ? 1 : 0; }
        else { res.clear(); putF64LE(res, c.v.number); }
        d += res;
        putLE(d, 0x0002, 2); // fCalcOnLoad
        putLE(d, 0, 4);
        putLE(d, enc.out.size(), 2);
        d += enc.out;
        rec(b, 0x0006, d);
        if (c.hasValue && str) rec(b, 0x0207, u16str(c.v.text(), true));
      } else if (c.v.isText) {
        auto it = sstIndex.find(c.v.text());
        size_t k = it == sstIndex.end() ? sst.size() : it->second;
        if (it == sstIndex.end()) { sstIndex[c.v.text()] = k; sst.push_back(c.v.text()); }
        putLE(d, k, 4);
        rec(b, 0x00FD, d);
      } else if (c.v.isBool()) {
        d.push_back(c.v.number ? 1 : 0); d.push_back(0);
        rec(b, 0x0205, d);
      } else if (std::isfinite(c.v.number)) {
        putF64LE(d, c.v.number);
        rec(b, 0x0203, d);
      }
    }
    size_t fr = 0, fc = 0;
    bool frozen = !s.freeze.empty() && parseAddress(s.freeze, fr, fc) && (fr || fc);
    std::string w2;
    putLE(w2, frozen ? 0x06BE : 0x06B6, 2); putLE(w2, 0, 2); putLE(w2, 0, 2); putLE(w2, 64, 4); putLE(w2, 0, 2); putLE(w2, 0, 2); putLE(w2, 0, 4);
    rec(b, 0x023E, w2);
    if (frozen) {
      std::string pane;
      putLE(pane, fc, 2); putLE(pane, fr, 2); putLE(pane, fr, 2); putLE(pane, fc, 2); pane.push_back(fr && fc ? 0 : fr ? 2 : 1);
      rec(b, 0x0041, pane);
    }
    if (!s.merged.empty()) {
      std::string m;
      putLE(m, s.merged.size(), 2);
      for (const auto &ref : s.merged) {
        size_t a0, b0, a1, b1;
        if (!parseRange(ref, a0, b0, a1, b1)) continue;
        putLE(m, a0, 2); putLE(m, a1, 2); putLE(m, b0, 2); putLE(m, b1, 2);
      }
      rec(b, 0x00E5, m);
    }
    rec(b, 0x000A, "");
    sheetStreams.push_back(b);
  }
  // globals
  std::string g;
  rec(g, 0x0809, std::string("\x00\x06\x05\x00\xBB\x0D\xCC\x07\x00\x00\x00\x00\x06\x00\x00\x00", 16));
  rec(g, 0x0042, std::string("\xB0\x04", 2)); // CODEPAGE 1200
  std::string w1;
  putLE(w1, 0, 2); putLE(w1, 0, 2); putLE(w1, 0x4000, 2); putLE(w1, 0x2000, 2); putLE(w1, 0x0038, 2);
  putLE(w1, wb.active, 2); putLE(w1, 0, 2); putLE(w1, 1, 2); putLE(w1, 600, 2);
  rec(g, 0x003D, w1);
  rec(g, 0x0022, std::string("\x00\x00", 2));
  auto font = [&](bool bold) {
    std::string f;
    putLE(f, 200, 2); putLE(f, 0, 2); putLE(f, 0x7FFF, 2); putLE(f, bold ? 700 : 400, 2); putLE(f, 0, 2);
    f.push_back(0); f.push_back(0); f.push_back(0); f.push_back(0);
    f += u16str("Arial", false);
    rec(g, 0x0031, f);
  };
  for (int k = 0; k < 4; k++) font(false);
  font(true); // index 5
  auto xf = [&](uint16_t fontIdx, bool style) {
    std::string x;
    putLE(x, fontIdx, 2); putLE(x, 0, 2); putLE(x, style ? 0xFFF5 : 0x0001, 2);
    putLE(x, 0x20, 2); putLE(x, 0, 2); putLE(x, 0, 4); putLE(x, 0, 4); putLE(x, 0x20C0, 2);
    rec(g, 0x00E0, x);
  };
  for (int k = 0; k < 15; k++) xf(0, true);
  xf(0, false);  // 15: cells
  xf(5, false);  // 16: bold cells
  rec(g, 0x0293, std::string("\x00\x80\x00\xFF", 4));
  std::vector<size_t> bsPos;
  for (const auto &s : wb.sheets) {
    bsPos.push_back(g.size() + 4);
    std::string bs;
    putLE(bs, 0, 4); bs.push_back(0); bs.push_back(0);
    std::string name = s.name.substr(0, 31);
    std::string u = u16str(name, false);
    bs += u;
    rec(g, 0x0085, bs);
  }
  // SST with CONTINUE splitting
  {
    std::vector<std::string> recsOut;
    std::string cur;
    putLE(cur, sst.size(), 4);
    putLE(cur, sst.size(), 4);
    for (const auto &str : sst) {
      std::string enc = u16str(str, true); // cch(2) flag(1) chars
      std::string header = enc.substr(0, 3), chars = enc.substr(3);
      if (cur.size() + 3 + 2 > 8224) { recsOut.push_back(cur); cur.clear(); }
      cur += header;
      size_t p = 0;
      while (p < chars.size()) {
        size_t room = (8224 - cur.size()) & ~static_cast<size_t>(1);
        if (room == 0) { recsOut.push_back(cur); cur.assign(1, '\x01'); continue; }
        size_t n = std::min(room, chars.size() - p);
        cur.append(chars, p, n);
        p += n;
      }
    }
    recsOut.push_back(cur);
    for (size_t k = 0; k < recsOut.size(); k++) {
      putLE(g, k == 0 ? 0x00FC : 0x003C, 2);
      putLE(g, recsOut[k].size(), 2);
      g += recsOut[k];
    }
  }
  rec(g, 0x000A, "");
  // patch sheet offsets
  size_t off = g.size();
  for (size_t k = 0; k < sheetStreams.size(); k++) {
    setLE(g, bsPos[k], off, 4);
    off += sheetStreams[k].size();
  }
  std::string stream = g;
  for (const auto &s : sheetStreams) stream += s;
  if (stream.size() > 6800000) {
    err = "the workbook is too large for this .xls writer (about 6.5 MB) - use .xlsx";
    return false;
  }
  out = writeOle2({{"Workbook", stream}});
  return true;
}

// ---- MS-OVBA ------------------------------------------------------------------

namespace {
std::string ovbaDecompress(const std::string &in, size_t start) {
  std::string out;
  if (start >= in.size() || in[start] != 1) return out;
  size_t p = start + 1;
  while (p + 2 <= in.size()) {
    uint16_t header = u16le(in, p);
    size_t size = (header & 0x0FFF) + 3;
    bool compressed = header & 0x8000;
    size_t end = std::min(in.size(), p + size);
    p += 2;
    size_t chunkStart = out.size();
    if (!compressed) {
      out.append(in, p, std::min<size_t>(4096, end - p));
      p = end;
      continue;
    }
    while (p < end) {
      uint8_t flags = static_cast<uint8_t>(in[p++]);
      for (int bit = 0; bit < 8 && p < end; bit++) {
        if (!(flags & (1 << bit))) { out.push_back(in[p++]); continue; }
        if (p + 2 > end) { p = end; break; }
        uint16_t token = u16le(in, p);
        p += 2;
        size_t pos = out.size() - chunkStart;
        int bitCount = 4;
        while ((1u << bitCount) < pos) bitCount++;
        uint16_t lengthMask = static_cast<uint16_t>(0xFFFF >> bitCount);
        size_t offset = (token >> (16 - bitCount)) + 1;
        size_t length = (token & lengthMask) + 3;
        if (offset > out.size()) return out;
        size_t from = out.size() - offset;
        for (size_t k = 0; k < length; k++) out.push_back(out[from + k]);
      }
    }
  }
  return out;
}
} // namespace

void readVbaModules(const std::string &vba, std::vector<std::pair<std::string, std::string>> &out) {
  out.clear();
  Ole2Reader ole;
  std::string err, dirc;
  if (!ole.open(vba, err) || !ole.read("VBA/dir", dirc)) return;
  std::string dir = ovbaDecompress(dirc, 0);
  size_t p = 0;
  std::string name, stream;
  uint32_t offset = 0;
  auto flush = [&]() {
    if (name.empty()) return;
    std::string raw;
    std::string src;
    if (ole.read("VBA/" + (stream.empty() ? name : stream), raw)) src = ovbaDecompress(raw, offset);
    out.push_back({name, src});
    name.clear(); stream.clear(); offset = 0;
  };
  while (p + 6 <= dir.size()) {
    uint16_t id = u16le(dir, p);
    uint32_t size = u32le(dir, p + 2);
    if (id == 0x0009) size = 6; // PROJECTVERSION has a fixed size
    std::string d = dir.substr(p + 6, size);
    if (id == 0x0019) { flush(); name = d; }
    else if (id == 0x001A) stream = d;
    else if (id == 0x0031) offset = u32le(d, 0);
    else if (id == 0x002B) flush(); // module terminator
    p += 6 + size;
  }
  flush();
}

} // namespace io
} // namespace nc
