// CATEGORY 15 - audio: read_/load_/save_ wav, flac, ogg, mp3.
// WAV and FLAC are decoded and encoded here. OGG (Vorbis/Opus) and MP3:
// tags, format and duration are read; the audio codecs are not built in.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>

#include "../numpy_common.h"
#include "io_audio.h"
#include "io_bytes.h"
#include "io_common.h"
#include "io_formats.h"

namespace nc {
namespace io {
namespace {

// ---- WAV ------------------------------------------------------------------------

bool decodeWav(const std::string &b, Audio &a, std::string &err) {
  bool rifx = b.size() >= 12 && b.compare(0, 4, "RIFX") == 0;
  if (b.size() < 12 || (b.compare(0, 4, "RIFF") != 0 && !rifx) || b.compare(8, 4, "WAVE") != 0) {
    err = "not a WAV file (RIFF/WAVE header missing)";
    return false;
  }
  auto g = [&](size_t at, int n) { return rifx ? getBE(b, at, n) : getLE(b, at, n); };
  size_t p = 12;
  int fmtTag = 0;
  size_t blockAlign = 0;
  std::string data;
  bool haveFmt = false;
  while (p + 8 <= b.size()) {
    std::string id = b.substr(p, 4);
    size_t len = static_cast<size_t>(g(p + 4, 4));
    size_t body = p + 8;
    if (body + len > b.size()) len = b.size() - body;
    if (id == "fmt ") {
      fmtTag = static_cast<int>(g(body, 2));
      a.channels = static_cast<size_t>(g(body + 2, 2));
      a.fs = static_cast<size_t>(g(body + 4, 4));
      blockAlign = static_cast<size_t>(g(body + 12, 2));
      a.bits = static_cast<int>(g(body + 14, 2));
      if (fmtTag == 0xFFFE && len >= 40) fmtTag = static_cast<int>(g(body + 24, 2));
      haveFmt = true;
    } else if (id == "data") {
      data = b.substr(body, len);
    } else if (id == "LIST" && len >= 4 && b.compare(body, 4, "INFO") == 0) {
      static const std::map<std::string, std::string> names = {{"INAM", "title"}, {"IART", "artist"}, {"IPRD", "album"},
                                                               {"ICMT", "comment"}, {"ICRD", "date"}, {"IGNR", "genre"},
                                                               {"ISFT", "software"}, {"ITRK", "track"}, {"ICOP", "copyright"}};
      size_t q = body + 4;
      while (q + 8 <= body + len) {
        std::string k = b.substr(q, 4);
        size_t l = static_cast<size_t>(g(q + 4, 4));
        std::string v = b.substr(q + 8, l);
        while (!v.empty() && v.back() == '\0') v.pop_back();
        auto it = names.find(k);
        a.tags.push_back({it == names.end() ? k : it->second, v});
        q += 8 + l + (l & 1);
      }
    } else if (id == "cue ") {
      size_t n = static_cast<size_t>(g(body, 4));
      for (size_t k = 0; k < n && body + 4 + 24 * (k + 1) <= b.size(); k++)
        a.cues.push_back(static_cast<double>(g(body + 4 + 24 * k + 20, 4)));
    }
    p = body + len + (len & 1);
  }
  if (!haveFmt) {
    err = "WAV file has no fmt chunk";
    return false;
  }
  if (fmtTag != 1 && fmtTag != 3) {
    err = "WAV encoding " + std::to_string(fmtTag) + " is not built in (PCM and IEEE float are)";
    return false;
  }
  a.isFloat = fmtTag == 3;
  size_t bytes = static_cast<size_t>(a.bits + 7) / 8;
  if (!blockAlign) blockAlign = bytes * a.channels;
  a.frames = data.size() / blockAlign;
  a.samples.resize(a.frames * a.channels);
  for (size_t f = 0; f < a.frames; f++)
    for (size_t c = 0; c < a.channels; c++) {
      size_t at = f * blockAlign + c * bytes;
      uint64_t u = rifx ? getBE(data, at, static_cast<int>(bytes)) : getLE(data, at, static_cast<int>(bytes));
      double v;
      if (a.isFloat && bytes == 4) { uint32_t u32 = static_cast<uint32_t>(u); float fl; std::memcpy(&fl, &u32, 4); v = fl; }
      else if (a.isFloat && bytes == 8) { std::memcpy(&v, &u, 8); }
      else if (bytes == 1) v = (static_cast<double>(u) - 128) / 128.0;
      else {
        int64_t s = static_cast<int64_t>(u << (64 - 8 * bytes)) >> (64 - 8 * bytes);
        v = static_cast<double>(s) / std::ldexp(1.0, static_cast<int>(8 * bytes - 1));
      }
      a.samples[f * a.channels + c] = v;
    }
  for (double &c : a.cues) c /= static_cast<double>(a.fs);
  a.codec = a.isFloat ? "IEEE float" : "PCM";
  return true;
}

std::string encodeWav(const Audio &a) {
  bool fl = a.isFloat;
  int bits = fl ? 32 : a.bits;
  size_t bytes = static_cast<size_t>(bits / 8);
  std::string data;
  data.reserve(a.samples.size() * bytes);
  for (double v : a.samples) {
    v = std::clamp(v, -1.0, 1.0);
    if (fl) { float f = static_cast<float>(v); uint32_t u; std::memcpy(&u, &f, 4); putLE(data, u, 4); }
    else if (bytes == 1) data.push_back(static_cast<char>(static_cast<int>(std::lround(v * 127 + 128))));
    else {
      double m = std::ldexp(1.0, bits - 1) - 1;
      putLE(data, static_cast<uint64_t>(static_cast<int64_t>(std::llround(v * m))), static_cast<int>(bytes));
    }
  }
  std::string list;
  if (!a.tags.empty()) {
    static const std::map<std::string, std::string> ids = {{"title", "INAM"}, {"artist", "IART"}, {"album", "IPRD"},
                                                           {"comment", "ICMT"}, {"date", "ICRD"}, {"genre", "IGNR"},
                                                           {"software", "ISFT"}, {"track", "ITRK"}, {"copyright", "ICOP"}};
    list = "INFO";
    for (const auto &t : a.tags) {
      auto it = ids.find(lower(t.first));
      std::string id = it != ids.end() ? it->second : (t.first.size() == 4 ? t.first : std::string("ICMT"));
      std::string v = (it == ids.end() && t.first.size() != 4 ? t.first + ": " : "") + t.second + '\0';
      list += id;
      putLE(list, v.size(), 4);
      list += v;
      if (v.size() & 1) list.push_back('\0');
    }
  }
  std::string o = "RIFF";
  putLE(o, 4 + 8 + 16 + 8 + data.size() + (data.size() & 1) + (list.empty() ? 0 : 8 + list.size()), 4);
  o += "WAVEfmt ";
  putLE(o, 16, 4);
  putLE(o, fl ? 3 : 1, 2);
  putLE(o, a.channels, 2);
  putLE(o, a.fs, 4);
  putLE(o, a.fs * a.channels * bytes, 4);
  putLE(o, a.channels * bytes, 2);
  putLE(o, static_cast<uint64_t>(bits), 2);
  o += "data";
  putLE(o, data.size(), 4);
  o += data;
  if (data.size() & 1) o.push_back('\0');
  if (!list.empty()) {
    o += "LIST";
    putLE(o, list.size(), 4);
    o += list;
  }
  return o;
}

// ---- FLAC -----------------------------------------------------------------------

struct FlacBits {
  const std::string &s;
  size_t pos = 0; // bit position
  explicit FlacBits(const std::string &str, size_t bytePos) : s(str), pos(bytePos * 8) {}
  uint64_t bits(int n) {
    uint64_t v = 0;
    for (int k = 0; k < n; k++, pos++)
      v = (v << 1) | (pos / 8 < s.size() ? ((static_cast<unsigned char>(s[pos / 8]) >> (7 - pos % 8)) & 1) : 0);
    return v;
  }
  int64_t sbits(int n) {
    if (!n) return 0;
    uint64_t v = bits(n);
    return static_cast<int64_t>(v << (64 - n)) >> (64 - n);
  }
  uint64_t unary() {
    uint64_t n = 0;
    while (pos / 8 < s.size() && bits(1) == 0) n++;
    return n;
  }
  void align() { pos = (pos + 7) / 8 * 8; }
  uint64_t utf8() {
    uint64_t x = bits(8);
    int more = 0;
    if (x >= 0xFE) more = 6;
    else if (x >= 0xFC) { x &= 1; more = 5; }
    else if (x >= 0xF8) { x &= 3; more = 4; }
    else if (x >= 0xF0) { x &= 7; more = 3; }
    else if (x >= 0xE0) { x &= 15; more = 2; }
    else if (x >= 0xC0) { x &= 31; more = 1; }
    for (int k = 0; k < more; k++) x = (x << 6) | (bits(8) & 0x3F);
    return x;
  }
};

bool decodeFlac(const std::string &b, Audio &a, std::string &err) {
  size_t p = 0;
  if (b.compare(0, 3, "ID3") == 0 && b.size() > 10)
    p = 10 + ((b[6] & 0x7F) << 21 | (b[7] & 0x7F) << 14 | (b[8] & 0x7F) << 7 | (b[9] & 0x7F));
  if (b.compare(p, 4, "fLaC") != 0) {
    err = "not a FLAC file (fLaC marker missing)";
    return false;
  }
  p += 4;
  uint64_t total = 0;
  bool last = false;
  while (!last && p + 4 <= b.size()) {
    unsigned char h = static_cast<unsigned char>(b[p]);
    last = h & 0x80;
    int type = h & 0x7F;
    size_t len = static_cast<size_t>(getBE(b, p + 1, 3));
    std::string d = b.substr(p + 4, len);
    if (type == 0) {
      FlacBits bi(d, 10);
      a.fs = static_cast<size_t>(bi.bits(20));
      a.channels = static_cast<size_t>(bi.bits(3) + 1);
      a.bits = static_cast<int>(bi.bits(5) + 1);
      total = bi.bits(36);
    } else if (type == 4) {
      size_t q = 4 + u32le(d, 0);
      uint32_t n = u32le(d, q);
      q += 4;
      for (uint32_t k = 0; k < n && q + 4 <= d.size(); k++) {
        uint32_t l = u32le(d, q);
        std::string kv = d.substr(q + 4, l);
        size_t eq = kv.find('=');
        a.tags.push_back({lower(kv.substr(0, eq)), eq == std::string::npos ? "" : kv.substr(eq + 1)});
        q += 4 + l;
      }
    }
    p += 4 + len;
  }
  a.samples.clear();
  a.samples.reserve(static_cast<size_t>(total) * a.channels);
  std::vector<std::vector<int64_t>> ch;
  while (p + 2 <= b.size()) {
    if (!(static_cast<unsigned char>(b[p]) == 0xFF && (static_cast<unsigned char>(b[p + 1]) & 0xFE) == 0xF8)) { p++; continue; }
    FlacBits bi(b, p);
    bi.bits(15);
    bi.bits(1);
    int bsCode = static_cast<int>(bi.bits(4)), srCode = static_cast<int>(bi.bits(4));
    int chCode = static_cast<int>(bi.bits(4)), ssCode = static_cast<int>(bi.bits(3));
    bi.bits(1);
    bi.utf8();
    size_t bs;
    if (bsCode == 1) bs = 192;
    else if (bsCode <= 5) bs = 576u << (bsCode - 2);
    else if (bsCode == 6) bs = static_cast<size_t>(bi.bits(8) + 1);
    else if (bsCode == 7) bs = static_cast<size_t>(bi.bits(16) + 1);
    else bs = 256u << (bsCode - 8);
    if (srCode == 12) bi.bits(8);
    else if (srCode == 13 || srCode == 14) bi.bits(16);
    bi.bits(8); // CRC-8
    static const int ssTable[8] = {0, 8, 12, 0, 16, 20, 24, 32};
    int bps = ssCode ? ssTable[ssCode] : a.bits;
    size_t nch = chCode < 8 ? static_cast<size_t>(chCode + 1) : 2;
    ch.assign(nch, std::vector<int64_t>(bs, 0));
    for (size_t c = 0; c < nch; c++) {
      int sbps = bps + ((chCode == 8 && c == 1) || (chCode == 9 && c == 0) || (chCode == 10 && c == 1) ? 1 : 0);
      bi.bits(1);
      int type = static_cast<int>(bi.bits(6));
      int wasted = 0;
      if (bi.bits(1)) wasted = static_cast<int>(bi.unary() + 1);
      sbps -= wasted;
      std::vector<int64_t> &out = ch[c];
      if (type == 0) {
        int64_t v = bi.sbits(sbps);
        std::fill(out.begin(), out.end(), v);
      } else if (type == 1) {
        for (size_t i = 0; i < bs; i++) out[i] = bi.sbits(sbps);
      } else {
        int order;
        std::vector<int64_t> coefs;
        int shift = 0;
        bool lpc = type >= 32;
        if (type >= 8 && type <= 12) order = type - 8;
        else if (lpc) order = (type & 31) + 1;
        else { err = "damaged FLAC subframe"; return false; }
        for (int k = 0; k < order; k++) out[static_cast<size_t>(k)] = bi.sbits(sbps);
        if (lpc) {
          int prec = static_cast<int>(bi.bits(4) + 1);
          shift = static_cast<int>(bi.sbits(5));
          for (int k = 0; k < order; k++) coefs.push_back(bi.sbits(prec));
        }
        int method = static_cast<int>(bi.bits(2));
        int partOrder = static_cast<int>(bi.bits(4));
        size_t parts = 1u << partOrder;
        size_t i = static_cast<size_t>(order);
        for (size_t pt = 0; pt < parts; pt++) {
          int param = static_cast<int>(bi.bits(method ? 5 : 4));
          size_t n = pt == 0 ? bs / parts - static_cast<size_t>(order) : bs / parts;
          bool escape = param == (method ? 31 : 15);
          int raw = escape ? static_cast<int>(bi.bits(5)) : 0;
          for (size_t k = 0; k < n && i < bs; k++, i++) {
            if (escape) { out[i] = bi.sbits(raw); continue; }
            uint64_t q = bi.unary();
            uint64_t u = (q << param) | bi.bits(param);
            out[i] = static_cast<int64_t>(u >> 1) ^ -static_cast<int64_t>(u & 1);
          }
        }
        // prediction
        if (!lpc) {
          for (size_t k = static_cast<size_t>(order); k < bs; k++) {
            int64_t pred = 0;
            switch (order) {
              case 1: pred = out[k - 1]; break;
              case 2: pred = 2 * out[k - 1] - out[k - 2]; break;
              case 3: pred = 3 * out[k - 1] - 3 * out[k - 2] + out[k - 3]; break;
              case 4: pred = 4 * out[k - 1] - 6 * out[k - 2] + 4 * out[k - 3] - out[k - 4]; break;
            }
            out[k] += pred;
          }
        } else {
          for (size_t k = static_cast<size_t>(order); k < bs; k++) {
            int64_t sum = 0;
            for (int j = 0; j < order; j++) sum += coefs[static_cast<size_t>(j)] * out[k - 1 - static_cast<size_t>(j)];
            out[k] += sum >> shift;
          }
        }
      }
      if (wasted) for (auto &v : out) v <<= wasted;
    }
    if (chCode == 8) for (size_t i = 0; i < bs; i++) ch[1][i] = ch[0][i] - ch[1][i];
    else if (chCode == 9) for (size_t i = 0; i < bs; i++) ch[0][i] += ch[1][i];
    else if (chCode == 10)
      for (size_t i = 0; i < bs; i++) {
        int64_t mid = (ch[0][i] << 1) | (ch[1][i] & 1), side = ch[1][i];
        ch[0][i] = (mid + side) >> 1;
        ch[1][i] = (mid - side) >> 1;
      }
    double scale = std::ldexp(1.0, bps - 1);
    for (size_t i = 0; i < bs; i++)
      for (size_t c = 0; c < nch; c++) a.samples.push_back(static_cast<double>(ch[c][i]) / scale);
    bi.align();
    bi.bits(16); // CRC-16
    p = bi.pos / 8;
  }
  a.channels = std::max<size_t>(1, a.channels);
  a.frames = a.samples.size() / a.channels;
  a.codec = "FLAC";
  return true;
}

struct BitWriter {
  std::string out;
  uint64_t buf = 0;
  int cnt = 0;
  void put(uint64_t v, int n) {
    for (int k = n - 1; k >= 0; k--) {
      buf = (buf << 1) | ((v >> k) & 1);
      if (++cnt == 8) { out.push_back(static_cast<char>(buf)); buf = 0; cnt = 0; }
    }
  }
  void align() { while (cnt) put(0, 1); }
};

uint8_t crc8(const std::string &s, size_t a, size_t e) {
  uint8_t c = 0;
  for (size_t i = a; i < e; i++) {
    c ^= static_cast<uint8_t>(s[i]);
    for (int k = 0; k < 8; k++) c = static_cast<uint8_t>((c & 0x80) ? (c << 1) ^ 0x07 : c << 1);
  }
  return c;
}
uint16_t crc16(const std::string &s, size_t a, size_t e) {
  uint16_t c = 0;
  for (size_t i = a; i < e; i++) {
    c ^= static_cast<uint16_t>(static_cast<uint8_t>(s[i]) << 8);
    for (int k = 0; k < 8; k++) c = static_cast<uint16_t>((c & 0x8000) ? (c << 1) ^ 0x8005 : c << 1);
  }
  return c;
}

void writeSubframe(BitWriter &w, const std::vector<int64_t> &x, int bps) {
  // pick the fixed predictor order (0..4) with the smallest residual
  size_t n = x.size();
  int bestOrder = 0;
  uint64_t bestSum = UINT64_MAX;
  std::vector<int64_t> res[5];
  for (int o = 0; o <= 4 && static_cast<size_t>(o) < n; o++) {
    res[o].assign(n, 0);
    uint64_t sum = 0;
    for (size_t k = static_cast<size_t>(o); k < n; k++) {
      int64_t p = 0;
      switch (o) {
        case 1: p = x[k - 1]; break;
        case 2: p = 2 * x[k - 1] - x[k - 2]; break;
        case 3: p = 3 * x[k - 1] - 3 * x[k - 2] + x[k - 3]; break;
        case 4: p = 4 * x[k - 1] - 6 * x[k - 2] + 4 * x[k - 3] - x[k - 4]; break;
      }
      res[o][k] = x[k] - p;
      sum += static_cast<uint64_t>(std::llabs(res[o][k]));
    }
    if (sum < bestSum) { bestSum = sum; bestOrder = o; }
  }
  bool constant = std::all_of(x.begin(), x.end(), [&](int64_t v) { return v == x[0]; });
  w.put(0, 1);
  if (constant) {
    w.put(0, 6);
    w.put(0, 1);
    w.put(static_cast<uint64_t>(x[0]) & ((1ull << bps) - 1), bps);
    return;
  }
  w.put(8 + static_cast<uint64_t>(bestOrder), 6);
  w.put(0, 1);
  for (int k = 0; k < bestOrder; k++) w.put(static_cast<uint64_t>(x[static_cast<size_t>(k)]) & ((1ull << bps) - 1), bps);
  // residual: partition order 0, one Rice parameter (method 1 = 5-bit params)
  const std::vector<int64_t> &r = res[bestOrder];
  double mean = static_cast<double>(bestSum) / std::max<size_t>(1, n - static_cast<size_t>(bestOrder));
  int param = mean > 0 ? std::clamp(static_cast<int>(std::floor(std::log2(mean * 0.69 + 1))), 0, 30) : 0;
  w.put(1, 2);
  w.put(0, 4);
  w.put(static_cast<uint64_t>(param), 5);
  for (size_t k = static_cast<size_t>(bestOrder); k < n; k++) {
    uint64_t u = r[k] >= 0 ? static_cast<uint64_t>(r[k]) << 1 : (static_cast<uint64_t>(-r[k]) << 1) - 1;
    uint64_t q = u >> param;
    for (uint64_t z = 0; z < q; z++) w.put(0, 1);
    w.put(1, 1);
    if (param) w.put(u & ((1ull << param) - 1), param);
  }
}

std::string encodeFlac(const Audio &a) {
  const int bps = a.bits == 24 ? 24 : a.bits == 8 ? 8 : 16;
  const size_t bs = 4096, nch = a.channels;
  std::string o = "fLaC";
  // STREAMINFO
  BitWriter si;
  si.put(bs, 16); si.put(bs, 16); si.put(0, 24); si.put(0, 24);
  si.put(a.fs, 20); si.put(nch - 1, 3); si.put(static_cast<uint64_t>(bps - 1), 5); si.put(a.frames, 36);
  for (int k = 0; k < 16; k++) si.put(0, 8); // MD5 unknown
  std::string vc;
  std::string vendor = "NC FLAC";
  putLE(vc, vendor.size(), 4);
  vc += vendor;
  putLE(vc, a.tags.size(), 4);
  for (const auto &t : a.tags) {
    std::string kv = t.first + "=" + t.second;
    putLE(vc, kv.size(), 4);
    vc += kv;
  }
  o.push_back(0x00);
  putBE(o, si.out.size(), 3);
  o += si.out;
  o.push_back(static_cast<char>(0x84));
  putBE(o, vc.size(), 3);
  o += vc;
  const double scale = std::ldexp(1.0, bps - 1) - 1;
  uint64_t frameNo = 0;
  for (size_t start = 0; start < a.frames; start += bs, frameNo++) {
    size_t n = std::min(bs, a.frames - start);
    std::vector<std::vector<int64_t>> ch(nch, std::vector<int64_t>(n));
    for (size_t i = 0; i < n; i++)
      for (size_t c = 0; c < nch; c++)
        ch[c][i] = static_cast<int64_t>(std::llround(std::clamp(a.samples[(start + i) * nch + c], -1.0, 1.0) * scale));
    size_t fstart = o.size();
    BitWriter w;
    w.put(0x3FFE, 14); w.put(0, 1); w.put(0, 1);
    w.put(7, 4); // block size: 16-bit at end of header
    w.put(0, 4); // sample rate from STREAMINFO
    bool stereo = nch == 2;
    w.put(stereo ? 10 : nch - 1, 4); // mid/side for stereo
    w.put(bps == 8 ? 1 : bps == 16 ? 4 : 6, 3);
    w.put(0, 1);
    // frame number, UTF-8 coded
    if (frameNo < 0x80) w.put(frameNo, 8);
    else if (frameNo < 0x800) { w.put(0xC0 | (frameNo >> 6), 8); w.put(0x80 | (frameNo & 0x3F), 8); }
    else if (frameNo < 0x10000) { w.put(0xE0 | (frameNo >> 12), 8); w.put(0x80 | ((frameNo >> 6) & 0x3F), 8); w.put(0x80 | (frameNo & 0x3F), 8); }
    else { w.put(0xF0 | (frameNo >> 18), 8); w.put(0x80 | ((frameNo >> 12) & 0x3F), 8); w.put(0x80 | ((frameNo >> 6) & 0x3F), 8); w.put(0x80 | (frameNo & 0x3F), 8); }
    w.put(n - 1, 16);
    std::string head = w.out;
    w.put(crc8(head, 0, head.size()), 8);
    if (stereo) {
      std::vector<int64_t> mid(n), side(n);
      for (size_t i = 0; i < n; i++) { side[i] = ch[0][i] - ch[1][i]; mid[i] = (ch[0][i] + ch[1][i]) >> 1; }
      writeSubframe(w, mid, bps);
      writeSubframe(w, side, bps + 1);
    } else {
      for (size_t c = 0; c < nch; c++) writeSubframe(w, ch[c], bps);
    }
    w.align();
    o += w.out;
    putBE(o, crc16(o, fstart, o.size()), 2);
  }
  return o;
}

// ---- OGG / MP3 metadata -----------------------------------------------------------

bool probeOgg(const std::string &b, Audio &a, std::string &err) {
  if (b.compare(0, 4, "OggS") != 0) { err = "not an Ogg file (OggS missing)"; return false; }
  size_t p = 0;
  uint64_t lastGranule = 0;
  std::string packet;
  int packets = 0;
  double preSkip = 0;
  while (p + 27 <= b.size() && b.compare(p, 4, "OggS") == 0) {
    uint64_t granule = u64le(b, p + 6);
    size_t segs = static_cast<unsigned char>(b[p + 26]);
    size_t q = p + 27 + segs;
    for (size_t s = 0; s < segs; s++) {
      size_t l = static_cast<unsigned char>(b[p + 27 + s]);
      packet.append(b, q, l);
      q += l;
      if (l < 255) {
        if (packets < 2) {
          if (packet.compare(0, 7, "\x01vorbis") == 0) { a.channels = static_cast<unsigned char>(packet[11]); a.fs = u32le(packet, 12); a.codec = "Vorbis"; }
          else if (packet.compare(0, 8, "OpusHead") == 0) { a.channels = static_cast<unsigned char>(packet[9]); a.fs = 48000; preSkip = u16le(packet, 10); a.codec = "Opus"; }
          else if (packet.compare(0, 7, "\x03vorbis") == 0 || packet.compare(0, 8, "OpusTags") == 0) {
            size_t c = packet[0] == 3 ? 7 : 8;
            uint32_t vl = u32le(packet, c);
            c += 4 + vl;
            uint32_t n = u32le(packet, c);
            c += 4;
            for (uint32_t k = 0; k < n && c + 4 <= packet.size(); k++) {
              uint32_t l2 = u32le(packet, c);
              std::string kv = packet.substr(c + 4, l2);
              size_t eq = kv.find('=');
              a.tags.push_back({lower(kv.substr(0, eq)), eq == std::string::npos ? "" : kv.substr(eq + 1)});
              c += 4 + l2;
            }
          }
        }
        packets++;
        packet.clear();
      }
    }
    if (granule != UINT64_MAX) lastGranule = granule;
    p = q;
  }
  a.frames = static_cast<size_t>(lastGranule > preSkip ? lastGranule - static_cast<uint64_t>(preSkip) : lastGranule);
  return true;
}

bool probeMp3(const std::string &b, Audio &a, std::string &err) {
  size_t p = 0;
  if (b.compare(0, 3, "ID3") == 0 && b.size() > 10) {
    int ver = b[3];
    size_t size = static_cast<size_t>((b[6] & 0x7F) << 21 | (b[7] & 0x7F) << 14 | (b[8] & 0x7F) << 7 | (b[9] & 0x7F));
    size_t q = 10;
    static const std::map<std::string, std::string> names = {{"TIT2", "title"}, {"TPE1", "artist"}, {"TALB", "album"},
                                                             {"TYER", "year"},  {"TDRC", "year"},   {"TCON", "genre"},
                                                             {"TBPM", "bpm"},   {"TRCK", "track"},  {"COMM", "comment"}};
    while (q + 10 <= 10 + size && q + 10 <= b.size()) {
      std::string id = b.substr(q, 4);
      if (id[0] == '\0') break;
      size_t l = ver == 4 ? static_cast<size_t>((b[q + 4] & 0x7F) << 21 | (b[q + 5] & 0x7F) << 14 | (b[q + 6] & 0x7F) << 7 | (b[q + 7] & 0x7F))
                          : static_cast<size_t>(u32be(b, q + 4));
      std::string d = b.substr(q + 10, l);
      auto it = names.find(id);
      if (it != names.end() && !d.empty()) {
        int enc = d[0];
        std::string v = d.substr(id == "COMM" ? 4 : 1);
        if (id == "COMM") { size_t z = v.find('\0'); if (z != std::string::npos) v = v.substr(z + 1); }
        if (enc == 1 || enc == 2) { std::string o; for (size_t k = 0; k + 1 < v.size(); k += 2) { uint16_t c = enc == 1 ? u16le(v, k) : u16be(v, k); if (c == 0xFEFF || c == 0xFFFE) continue; if (c && c < 128) o.push_back(static_cast<char>(c)); } v = o; }
        while (!v.empty() && v.back() == '\0') v.pop_back();
        a.tags.push_back({it->second, v});
      }
      q += 10 + l;
    }
    p = 10 + size;
  }
  while (p + 4 <= b.size() && !(static_cast<unsigned char>(b[p]) == 0xFF && (static_cast<unsigned char>(b[p + 1]) & 0xE0) == 0xE0)) p++;
  if (p + 4 > b.size()) { err = "no MPEG audio frame found"; return false; }
  uint32_t h = u32be(b, p);
  int verBits = (h >> 19) & 3, layer = (h >> 17) & 3, brIdx = (h >> 12) & 15, srIdx = (h >> 10) & 3, mode = (h >> 6) & 3;
  static const int rates[3][3] = {{44100, 48000, 32000}, {22050, 24000, 16000}, {11025, 12000, 8000}};
  static const int br1[16] = {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0};
  static const int br2[16] = {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0};
  int vi = verBits == 3 ? 0 : verBits == 2 ? 1 : 2;
  if (srIdx == 3 || layer != 1) { err = "only MPEG layer III files are recognised"; return false; }
  a.fs = static_cast<size_t>(rates[vi][srIdx]);
  a.channels = mode == 3 ? 1 : 2;
  int kbps = vi == 0 ? br1[brIdx] : br2[brIdx];
  size_t samplesPerFrame = vi == 0 ? 1152 : 576;
  size_t side = vi == 0 ? (mode == 3 ? 17 : 32) : (mode == 3 ? 9 : 17);
  size_t xing = p + 4 + side;
  if (b.compare(xing, 4, "Xing") == 0 || b.compare(xing, 4, "Info") == 0) {
    uint32_t flags = u32be(b, xing + 4);
    if (flags & 1) a.frames = static_cast<size_t>(u32be(b, xing + 8)) * samplesPerFrame;
  }
  if (!a.frames && kbps) a.frames = static_cast<size_t>((b.size() - p) * 8.0 / (kbps * 1000.0) * a.fs);
  a.codec = "MP3 " + std::to_string(kbps) + " kbps" + (a.frames && b.compare(xing, 4, "Xing") == 0 ? " VBR" : "");
  return true;
}

// ---- shared read / load / save ------------------------------------------------------

bool loadAudio(const std::string &fmt, const std::string &file, Audio &a, std::string &err, bool needSamples) {
  std::string bytes;
  if (!readSource(file, bytes, err)) return false;
  if (fmt == "wav") return decodeWav(bytes, a, err);
  if (fmt == "flac") return decodeFlac(bytes, a, err);
  bool ok = fmt == "ogg" ? probeOgg(bytes, a, err) : probeMp3(bytes, a, err);
  if (ok && needSamples) {
    err = "decoding " + a.codec + " audio is not built in yet - load_" + fmt + "() gives its tags, sample rate and duration; convert the file to .wav or .flac to read the samples";
    return false;
  }
  return ok;
}

Value waveValue(const Audio &a, const std::vector<double> &s, size_t frames, size_t channels) {
  if (channels == 1) return numpy::makeArray(s);
  return ndFromRowMajor({frames, channels}, s);
}

Value tagsValue(const Audio &a) {
  Fields f;
  for (const auto &t : a.tags) f[t.first] = Value(t.second);
  return Value(f);
}

// start / dur / samples / mono / fs / dtype on decoded audio.
bool shapeAudio(Audio &a, double start, double dur, const Value &samples, bool mono, double fs, std::string &err) {
  size_t f0 = 0, f1 = a.frames;
  if (start > 0) {
    if (start >= a.duration()) { err = "start=" + numberText(start) + " s is past the end (" + numberText(a.duration()) + " s)"; return false; }
    f0 = static_cast<size_t>(start * a.fs);
  }
  if (dur >= 0) f1 = std::min(a.frames, f0 + static_cast<size_t>(dur * a.fs));
  if (given(samples)) {
    std::vector<double> sel = optNumbers(samples);
    if (!sel.empty()) {
      double lo = *std::min_element(sel.begin(), sel.end()), hi = *std::max_element(sel.begin(), sel.end());
      if (lo < 1 || hi > a.frames) { err = "samples must be within 1.." + std::to_string(a.frames); return false; }
      f0 = static_cast<size_t>(lo) - 1;
      f1 = static_cast<size_t>(hi);
    }
  }
  std::vector<double> s(a.samples.begin() + static_cast<long>(f0 * a.channels), a.samples.begin() + static_cast<long>(f1 * a.channels));
  a.samples = s;
  a.frames = f1 - f0;
  if (mono && a.channels > 1) {
    std::vector<double> m(a.frames);
    for (size_t i = 0; i < a.frames; i++) {
      double sum = 0;
      for (size_t c = 0; c < a.channels; c++) sum += a.samples[i * a.channels + c];
      m[i] = sum / a.channels;
    }
    a.samples = m;
    a.channels = 1;
  }
  if (fs > 0 && static_cast<size_t>(fs) != a.fs) { // linear resampling
    size_t n = static_cast<size_t>(std::llround(a.frames * fs / a.fs));
    std::vector<double> r(n * a.channels);
    for (size_t i = 0; i < n; i++) {
      double src = i * static_cast<double>(a.fs) / fs;
      size_t i0 = static_cast<size_t>(src);
      double t = src - i0;
      for (size_t c = 0; c < a.channels; c++) {
        double x0 = i0 < a.frames ? a.samples[i0 * a.channels + c] : 0, x1 = i0 + 1 < a.frames ? a.samples[(i0 + 1) * a.channels + c] : x0;
        r[i * a.channels + c] = x0 + (x1 - x0) * t;
      }
    }
    a.samples = r;
    a.frames = n;
    a.fs = static_cast<size_t>(fs);
  }
  return true;
}

// read_<fmt>(file, start, dur, samples, mono, fs, dtype, box) -> [y, fs, info]
void readAudio(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  Audio au;
  if (!loadAudio(fmt, file, au, err, true)) return ctx.fail(err);
  if (!shapeAudio(au, optNumber(a[1], 0), optNumber(a[2], -1), a[3], optBool(a[4], false), optNumber(a[5], -1), err)) return ctx.fail(err);
  std::string dtype = lower(optText(a[6], "float32"));
  if (dtype != "float32" && dtype != "float64" && dtype != "int16") return ctx.fail("dtype must be \"float32\" or \"int16\"");
  std::vector<double> s = au.samples;
  if (dtype == "int16") for (double &v : s) v = std::round(std::clamp(v, -1.0, 1.0) * 32767);
  out.push_back(waveValue(au, s, au.frames, au.channels));
  if (nout > 1) out.push_back(Value(static_cast<double>(au.fs)));
  if (nout > 2) {
    Fields info;
    info["fs"] = Value(static_cast<double>(au.fs));
    info["channels"] = Value(static_cast<double>(au.channels));
    info["duration"] = Value(au.duration());
    info["bits"] = Value(static_cast<double>(au.bits));
    info["codec"] = Value(au.codec);
    info["boxes"] = optBool(a[7], true) ? tagsValue(au) : Value(Fields{});
    info["cues"] = numberList(au.cues);
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

} // namespace

Value audioObject(const Audio &au, const std::string &file, const std::string &fmt) {
  Fields f;
  bool haveSamples = !au.samples.empty() || fmt == "wav" || fmt == "flac";
  Value wave = haveSamples ? waveValue(au, au.samples, au.frames, au.channels) : Value(std::vector<Value>{});
  f["wave"] = wave;
  f["y"] = wave;
  f["fs"] = Value(static_cast<double>(au.fs));
  f["duration"] = Value(au.duration());
  f["channels"] = Value(static_cast<double>(au.channels));
  f["frames"] = Value(static_cast<double>(au.frames));
  f["bits"] = Value(static_cast<double>(au.bits));
  f["codec"] = Value(au.codec);
  std::vector<Value> chans;
  for (size_t c = 0; c < au.channels && haveSamples; c++) {
    std::vector<double> v(au.frames);
    for (size_t i = 0; i < au.frames; i++) v[i] = au.samples[i * au.channels + c];
    chans.push_back(numpy::makeArray(v));
  }
  f["ch"] = Value(chans);
  if (!chans.empty()) {
    f["left"] = chans[0];
    f["right"] = chans.size() > 1 ? chans[1] : chans[0];
  }
  if (haveSamples) {
    std::vector<double> t(au.frames);
    for (size_t i = 0; i < au.frames; i++) t[i] = static_cast<double>(i) / au.fs;
    f["t"] = numpy::makeArray(t);
  }
  f["tags"] = tagsValue(au);
  f["boxes"] = tagsValue(au);
  f["cues"] = numberList(au.cues);
  f["file"] = Value(file);
  f["format"] = Value(fmt);
  return makeObject("NcAudio", std::move(f));
}

namespace {

Value loadAudioFn(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  Audio au;
  if (!loadAudio(fmt, file, au, err, false)) {
    ctx.fail(err);
    return Value(0.0);
  }
  ev.ok = true;
  return audioObject(au, file, fmt);
}

} // namespace

bool valueToAudio(const Value &v, double fs, Audio &au, std::string &err) {
  au = Audio();
  if (isObjectOf(v, "NcAudio")) {
    const Value *w = field(v, "wave"), *f = field(v, "fs");
    if (!w) { err = "this audio object has no samples"; return false; }
    return valueToAudio(*w, fs > 0 ? fs : (f ? f->number : 44100), au, err);
  }
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!ndToRowMajor(v, shape, vals) || shape.empty() || shape.size() > 2) {
    err = "a waveform must be a vector, or an (N_samples, N_channels) matrix";
    return false;
  }
  au.frames = shape[0];
  au.channels = shape.size() == 2 ? shape[1] : 1;
  if (shape.size() == 2 && shape[0] <= 8 && shape[1] > shape[0]) { // (channels, samples) -> transpose
    au.channels = shape[0];
    au.frames = shape[1];
    std::vector<double> t(vals.size());
    for (size_t c = 0; c < au.channels; c++)
      for (size_t i = 0; i < au.frames; i++) t[i * au.channels + c] = vals[c * au.frames + i];
    vals = t;
  }
  for (double x : vals)
    if (!std::isfinite(x)) { err = "the waveform holds NaN or Inf"; return false; }
  au.samples = vals;
  au.fs = static_cast<size_t>(fs > 0 ? fs : 44100);
  return true;
}

namespace {

// save_<fmt>(file, wave, fs, bits|bitrate, [vbr], norm, compress, max_size, boxes)
Value saveAudioFn(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  if (fmt == "ogg" || fmt == "mp3") {
    ctx.fail("encoding " + std::string(fmt == "ogg" ? "Ogg Vorbis/Opus" : "MP3") + " is not built in yet - use save_flac (lossless, small) or save_wav");
    return Value(0.0);
  }
  Audio au;
  double fs = optNumber(a[2], 44100);
  if (fs <= 0) { ctx.fail("fs must be a positive sample rate in Hz"); return Value(0.0); }
  if (!valueToAudio(a[1], fs, au, err)) { ctx.fail(err); return Value(0.0); }
  long long bits = optInt(a[3], 16);
  if (bits != 8 && bits != 16 && bits != 24 && bits != 32) { ctx.fail("bits must be 8, 16, 24 or 32"); return Value(0.0); }
  au.bits = static_cast<int>(bits);
  au.isFloat = bits == 32 && fmt == "wav";
  if (fmt == "flac" && bits == 32) au.bits = 24;
  if (optBool(a[4], false)) {
    double peak = 0;
    for (double x : au.samples) peak = std::max(peak, std::fabs(x));
    if (peak > 0) for (double &x : au.samples) x /= peak;
  }
  for (double &x : au.samples) x = std::clamp(x, -1.0, 1.0); // clipping protection
  const Value &boxes = a[7];
  if (boxes.isDict) for (const auto &kv : boxes.dict()) au.tags.push_back({kv.first, cellText(kv.second)});
  else for (const auto &t : optTextList(boxes)) au.tags.push_back({"comment", t});
  uint64_t budget = 0;
  if (given(a[6]) && !parseByteSize(optText(a[6]), budget)) { ctx.fail("max_size is not a size (e.g. \"2mb\")"); return Value(0.0); }
  auto encode = [&]() { return fmt == "wav" ? encodeWav(au) : encodeFlac(au); };
  std::string bytes = encode();
  std::string adjusted;
  // budget: fewer bits, then a lower sample rate (never below 8 kHz)
  while (budget && bytes.size() > budget) {
    if (au.isFloat) { au.isFloat = false; au.bits = 16; }
    else if (au.bits > 8) au.bits = au.bits == 24 ? 16 : 8;
    else if (au.fs > 8000) {
      Audio half = au;
      shapeAudio(half, 0, -1, Value(std::string()), false, std::max<double>(8000, au.fs / 2.0), err);
      au = half;
    } else break;
    bytes = encode();
    adjusted = std::to_string(au.bits) + "-bit, " + std::to_string(au.fs) + " Hz";
  }
  if (budget && bytes.size() > budget) {
    ctx.fail("even at 8-bit 8 kHz the ." + fmt + " is " + std::to_string(bytes.size()) + " bytes, over max_size " + std::to_string(budget) + " bytes - shorten the signal");
    return Value(0.0);
  }
  if (!writeFile(file, bytes, false, err)) { ctx.fail(err); return Value(0.0); }
  emitEvent({"saved", "save_" + fmt, file, 1.0, formatBytes(bytes.size()) + (adjusted.empty() ? "" : " (to fit max_size: " + adjusted + ")")});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

Value sliceMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string err;
  Audio au;
  const Value *fsV = field(a[0], "fs");
  if (!valueToAudio(a[0], fsV ? fsV->number : 44100, au, err)) { ctx.fail(err); return Value(0.0); }
  double t1 = optNumber(a[1], 0), t2 = optNumber(a[2], au.duration());
  if (t2 < t1) { ctx.fail("slice(t1, t2) needs t1 <= t2"); return Value(0.0); }
  if (!shapeAudio(au, t1, t2 - t1, Value(std::string()), false, -1, err)) { ctx.fail(err); return Value(0.0); }
  const Value *file = field(a[0], "file"), *fmt = field(a[0], "format");
  return audioObject(au, file ? optText(*file) : "", fmt ? optText(*fmt) : "wav");
}

} // namespace

void registerAudio(Registry &reg) {
  for (const char *ext : {"wav", "flac", "ogg", "mp3"}) {
    const std::string e = ext;
    const bool lossy = e == "ogg" || e == "mp3";
    addMulti(reg, "read_" + e, "file, start=0, dur=-1, samples=\"\", mono=false, fs=-1, dtype=\"float32\", box=true",
             "read the waveform of a ." + e + " file: [y, fs, info] = read_" + e + "(...)", "soundfile.read", 3,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readAudio(e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file",
          "load a ." + e + " file as an audio object (D.wave, D.fs, D.duration, D.left, D.t, D.tags, D.slice(t1, t2))",
          "soundfile.SoundFile", [e](const std::vector<Value> &a, CallContext &ctx) { return loadAudioFn(e, a, ctx); });
    std::string sp = lossy ? "file, wave, fs=44100, bitrate=\"192k\", vbr=true, norm=false, compress=\"yes\", max_size=\"\", boxes=\"\""
                           : "file, wave, fs=44100, bits=16, norm=false, compress=\"yes\", max_size=\"\", boxes=\"\"";
    addFn(reg, "save_" + e, sp, "write a waveform as ." + e, "soundfile.write",
          [e, lossy](const std::vector<Value> &a, CallContext &ctx) {
            if (lossy) { // keep one argument layout for the shared writer
              std::vector<Value> b{a[0], a[1], a[2], Value(16.0), a[5], a[6], a[7], a[8]};
              return saveAudioFn(e, b, ctx);
            }
            return saveAudioFn(e, a, ctx);
          });
  }
  addFn(reg, "NcAudio.slice", "D, t1, t2", "the part of a loaded audio object between t1 and t2 seconds", "-", sliceMethod);
}

} // namespace io
} // namespace nc
