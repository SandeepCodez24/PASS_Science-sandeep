// JPEG (ITU T.81) decoder: baseline + extended (8-bit) + progressive, with
// EXIF / JFIF / ICC; encoder: baseline or progressive (spectral selection).
#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>

#include "io_bytes.h"
#include "io_image.h"

namespace nc {
namespace io {

namespace {

const int kZigzag[64] = {0,  1,  8,  16, 9,  2,  3,  10, 17, 24, 32, 25, 18, 11, 4,  5,  12, 19, 26, 33, 40, 48,
                         41, 34, 27, 20, 13, 6,  7,  14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23,
                         30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63};

struct Huff {
  int maxcode[18];
  int valptr[17];
  int mincode[17];
  std::vector<uint8_t> vals;
  bool present = false;
  void build(const uint8_t counts[16], const std::vector<uint8_t> &v) {
    vals = v;
    int code = 0, k = 0;
    for (int l = 1; l <= 16; l++) {
      valptr[l] = k;
      mincode[l] = code;
      code += counts[l - 1];
      k += counts[l - 1];
      maxcode[l] = counts[l - 1] ? code - 1 : -1;
      code <<= 1;
    }
    maxcode[17] = 0x7FFFFFFF;
    present = true;
  }
};

struct BitIn {
  const std::string &s;
  size_t p;
  uint32_t buf = 0;
  int cnt = 0;
  bool marker = false;
  BitIn(const std::string &str, size_t pos) : s(str), p(pos) {}
  int bit() {
    if (cnt == 0) {
      if (marker || p >= s.size()) return 0;
      uint8_t b = static_cast<uint8_t>(s[p]);
      if (b == 0xFF) {
        uint8_t n = p + 1 < s.size() ? static_cast<uint8_t>(s[p + 1]) : 0;
        if (n == 0x00) p += 2;
        else { marker = true; return 0; }
      } else {
        p++;
      }
      buf = b;
      cnt = 8;
    }
    cnt--;
    return (buf >> cnt) & 1;
  }
  int bits(int n) {
    int v = 0;
    for (int k = 0; k < n; k++) v = (v << 1) | bit();
    return v;
  }
  int decode(const Huff &h) {
    int code = 0;
    for (int l = 1; l <= 16; l++) {
      code = (code << 1) | bit();
      if (h.maxcode[l] >= 0 && code <= h.maxcode[l]) {
        size_t idx = static_cast<size_t>(h.valptr[l] + code - h.mincode[l]);
        return idx < h.vals.size() ? h.vals[idx] : 0;
      }
    }
    return 0;
  }
  static int extend(int v, int t) { return (t && v < (1 << (t - 1))) ? v - (1 << t) + 1 : v; }
  int receive(int t) { return t ? extend(bits(t), t) : 0; }
  void reset() { cnt = 0; marker = false; }
};

struct Comp {
  int id, h, v, tq;
  int bw = 0, bh = 0; // blocks per line / column (padded to MCU)
  std::vector<int> coef;
  int pred = 0;
  int td = 0, ta = 0;
};

void idct8x8(const double in[64], double out[64]) {
  static double c[8][8];
  static bool ready = false;
  if (!ready) {
    for (int x = 0; x < 8; x++)
      for (int u = 0; u < 8; u++)
        c[x][u] = (u == 0 ? std::sqrt(0.125) : 0.5) * std::cos((2 * x + 1) * u * 3.14159265358979323846 / 16);
    ready = true;
  }
  double tmp[64];
  for (int y = 0; y < 8; y++)
    for (int x = 0; x < 8; x++) {
      double s = 0;
      for (int u = 0; u < 8; u++) s += c[x][u] * in[y * 8 + u];
      tmp[y * 8 + x] = s;
    }
  for (int x = 0; x < 8; x++)
    for (int y = 0; y < 8; y++) {
      double s = 0;
      for (int v = 0; v < 8; v++) s += c[y][v] * tmp[v * 8 + x];
      out[y * 8 + x] = s;
    }
}

void fdct8x8(const double in[64], double out[64]) {
  static double c[8][8];
  static bool ready = false;
  if (!ready) {
    for (int x = 0; x < 8; x++)
      for (int u = 0; u < 8; u++)
        c[u][x] = (u == 0 ? std::sqrt(0.125) : 0.5) * std::cos((2 * x + 1) * u * 3.14159265358979323846 / 16);
    ready = true;
  }
  double tmp[64];
  for (int y = 0; y < 8; y++)
    for (int u = 0; u < 8; u++) {
      double s = 0;
      for (int x = 0; x < 8; x++) s += c[u][x] * in[y * 8 + x];
      tmp[y * 8 + u] = s;
    }
  for (int u = 0; u < 8; u++)
    for (int v = 0; v < 8; v++) {
      double s = 0;
      for (int y = 0; y < 8; y++) s += c[v][y] * tmp[y * 8 + u];
      out[v * 8 + u] = s;
    }
}

// ---- EXIF -------------------------------------------------------------------

void parseExifBlock(const std::string &t, Fields &exif, int &orientation) {
  if (t.size() < 8) return;
  bool le = t[0] == 'I';
  auto g16 = [&](size_t a) { return le ? u16le(t, a) : u16be(t, a); };
  auto g32 = [&](size_t a) { return le ? u32le(t, a) : u32be(t, a); };
  auto rational = [&](size_t a, bool sign) {
    double n = sign ? static_cast<int32_t>(g32(a)) : g32(a), d = sign ? static_cast<int32_t>(g32(a + 4)) : g32(a + 4);
    return d ? n / d : 0.0;
  };
  std::function<void(size_t, int)> ifd = [&](size_t off, int kind) {
    if (off + 2 > t.size()) return;
    size_t n = g16(off);
    for (size_t k = 0; k < n; k++) {
      size_t e = off + 2 + 12 * k;
      if (e + 12 > t.size()) return;
      uint16_t tag = g16(e), type = g16(e + 2);
      uint32_t count = g32(e + 4);
      static const int sz[] = {0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8};
      size_t bytes = (type < 13 ? sz[type] : 1) * count;
      size_t at = bytes <= 4 ? e + 8 : g32(e + 8);
      if (at + bytes > t.size()) continue;
      auto str = [&]() { std::string s = t.substr(at, count); while (!s.empty() && s.back() == '\0') s.pop_back(); return s; };
      auto num = [&](size_t i) -> double {
        switch (type) {
          case 3: return g16(at + 2 * i);
          case 4: return g32(at + 4 * i);
          case 5: return rational(at + 8 * i, false);
          case 10: return rational(at + 8 * i, true);
          default: return static_cast<unsigned char>(t[at + i]);
        }
      };
      if (kind == 0) {
        if (tag == 0x010F) exif["Make"] = Value(str());
        else if (tag == 0x0110) exif["Model"] = Value(str());
        else if (tag == 0x0112) orientation = static_cast<int>(num(0));
        else if (tag == 0x0132) exif["DateTime"] = Value(str());
        else if (tag == 0x010E) exif["ImageDescription"] = Value(str());
        else if (tag == 0x0131) exif["Software"] = Value(str());
        else if (tag == 0x8769) ifd(g32(e + 8), 1);
        else if (tag == 0x8825) ifd(g32(e + 8), 2);
      } else if (kind == 1) {
        if (tag == 0x829A) exif["ExposureTime"] = Value(num(0));
        else if (tag == 0x829D) exif["FNumber"] = Value(num(0));
        else if (tag == 0x8827) exif["ISO"] = Value(num(0));
        else if (tag == 0x9003) exif["DateTimeOriginal"] = Value(str());
        else if (tag == 0x920A) exif["FocalLength"] = Value(num(0));
        else if (tag == 0x9286) exif["UserComment"] = Value(t.substr(at + 8, count > 8 ? count - 8 : 0));
      } else {
        if (tag == 1) exif["GPSLatitudeRef"] = Value(str());
        else if (tag == 2 && count == 3) exif["GPSLatitude"] = Value(num(0) + num(1) / 60 + num(2) / 3600);
        else if (tag == 3) exif["GPSLongitudeRef"] = Value(str());
        else if (tag == 4 && count == 3) exif["GPSLongitude"] = Value(num(0) + num(1) / 60 + num(2) / 3600);
        else if (tag == 6) exif["GPSAltitude"] = Value(num(0));
      }
    }
  };
  ifd(g32(4), 0);
  if (exif.count("GPSLatitudeRef") && exif["GPSLatitudeRef"].isText && exif["GPSLatitudeRef"].text() == "S" && exif.count("GPSLatitude"))
    exif["GPSLatitude"] = Value(-exif["GPSLatitude"].number);
  if (exif.count("GPSLongitudeRef") && exif["GPSLongitudeRef"].isText && exif["GPSLongitudeRef"].text() == "W" && exif.count("GPSLongitude"))
    exif["GPSLongitude"] = Value(-exif["GPSLongitude"].number);
}

// Standard tables (ITU T.81 Annex K).
const uint8_t kStdLumQ[64] = {16, 11, 10, 16, 24,  40,  51,  61,  12, 12, 14, 19, 26,  58,  60,  55,
                              14, 13, 16, 24, 40,  57,  69,  56,  14, 17, 22, 29, 51,  87,  80,  62,
                              18, 22, 37, 56, 68,  109, 103, 77,  24, 35, 55, 64, 81,  104, 113, 92,
                              49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99};
const uint8_t kStdChrQ[64] = {17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99, 24, 26, 56, 99, 99, 99,
                              99, 99, 47, 66, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99,
                              99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99};
const uint8_t kDcLumBits[16] = {0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0};
const uint8_t kDcChrBits[16] = {0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0};
const uint8_t kDcVals[12] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
const uint8_t kAcLumBits[16] = {0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d};
const uint8_t kAcLumVals[162] = {
    0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06, 0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14,
    0x32, 0x81, 0x91, 0xa1, 0x08, 0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0, 0x24, 0x33, 0x62, 0x72, 0x82, 0x09,
    0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a,
    0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64, 0x65,
    0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88,
    0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9,
    0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9, 0xca,
    0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea,
    0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa};
const uint8_t kAcChrBits[16] = {0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77};
const uint8_t kAcChrVals[162] = {
    0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41, 0x51, 0x07, 0x61, 0x71, 0x13, 0x22, 0x32,
    0x81, 0x08, 0x14, 0x42, 0x91, 0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0, 0x15, 0x62, 0x72, 0xd1, 0x0a, 0x16,
    0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39,
    0x3a, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x63, 0x64,
    0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86,
    0x87, 0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
    0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8,
    0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9,
    0xea, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa};

} // namespace

bool decodeJpeg(const std::string &b, Image &img, std::string &err) {
  img = Image();
  if (b.size() < 4 || static_cast<uint8_t>(b[0]) != 0xFF || static_cast<uint8_t>(b[1]) != 0xD8) {
    err = "not a JPEG file (SOI marker missing)";
    return false;
  }
  int qt[4][64];
  std::memset(qt, 0, sizeof qt);
  Huff dc[4], ac[4];
  std::vector<Comp> comps;
  int width = 0, height = 0, hmax = 1, vmax = 1, mcux = 0, mcuy = 0;
  bool progressive = false, adobe = false;
  int adobeTransform = -1, restart = 0;
  std::string icc;
  size_t p = 2;
  int eobrun = 0;
  while (p + 4 <= b.size()) {
    if (static_cast<uint8_t>(b[p]) != 0xFF) { p++; continue; }
    uint8_t m = static_cast<uint8_t>(b[p + 1]);
    if (m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7) || m == 0xFF) { p += (m == 0xFF ? 1 : 2); continue; }
    if (m == 0xD9) break;
    size_t len = u16be(b, p + 2);
    std::string d = b.substr(p + 4, len >= 2 ? len - 2 : 0);
    size_t next = p + 2 + len;
    switch (m) {
      case 0xDB: {
        size_t q = 0;
        while (q < d.size()) {
          int pq = static_cast<uint8_t>(d[q]) >> 4, tq = d[q] & 3;
          q++;
          for (int k = 0; k < 64; k++) {
            qt[tq][kZigzag[k]] = pq ? u16be(d, q) : static_cast<uint8_t>(d[q]);
            q += pq ? 2 : 1;
          }
        }
        break;
      }
      case 0xC4: {
        size_t q = 0;
        while (q + 17 <= d.size()) {
          int tc = static_cast<uint8_t>(d[q]) >> 4, th = d[q] & 3;
          uint8_t counts[16];
          int total = 0;
          for (int k = 0; k < 16; k++) { counts[k] = static_cast<uint8_t>(d[q + 1 + k]); total += counts[k]; }
          std::vector<uint8_t> vals(d.begin() + static_cast<long>(q) + 17, d.begin() + static_cast<long>(q) + 17 + total);
          (tc ? ac : dc)[th].build(counts, vals);
          q += 17 + static_cast<size_t>(total);
        }
        break;
      }
      case 0xC0: case 0xC1: case 0xC2: {
        if (static_cast<uint8_t>(d[0]) != 8) {
          err = "only 8-bit JPEG is built in (this one is " + std::to_string(static_cast<uint8_t>(d[0])) + "-bit)";
          return false;
        }
        progressive = m == 0xC2;
        height = u16be(d, 1);
        width = u16be(d, 3);
        int nc = static_cast<uint8_t>(d[5]);
        for (int k = 0; k < nc; k++) {
          Comp c;
          c.id = static_cast<uint8_t>(d[6 + 3 * k]);
          c.h = static_cast<uint8_t>(d[7 + 3 * k]) >> 4;
          c.v = d[7 + 3 * k] & 15;
          c.tq = d[8 + 3 * k] & 3;
          hmax = std::max(hmax, c.h);
          vmax = std::max(vmax, c.v);
          comps.push_back(c);
        }
        mcux = (width + 8 * hmax - 1) / (8 * hmax);
        mcuy = (height + 8 * vmax - 1) / (8 * vmax);
        for (auto &c : comps) {
          c.bw = mcux * c.h;
          c.bh = mcuy * c.v;
          c.coef.assign(static_cast<size_t>(c.bw * c.bh * 64), 0);
        }
        break;
      }
      case 0xC3: case 0xC5: case 0xC6: case 0xC7: case 0xC9: case 0xCA: case 0xCB: case 0xCD: case 0xCE: case 0xCF:
        err = "this JPEG uses lossless / hierarchical / arithmetic coding, which is not built in";
        return false;
      case 0xDD: restart = u16be(d, 0); break;
      case 0xE0:
        if (d.compare(0, 5, std::string("JFIF\0", 5)) == 0 && d.size() >= 12) {
          int units = static_cast<uint8_t>(d[7]);
          double dx = u16be(d, 8), dy = u16be(d, 10);
          if (units == 1) { img.dpiX = dx; img.dpiY = dy; }
          else if (units == 2) { img.dpiX = std::round(dx * 2.54); img.dpiY = std::round(dy * 2.54); }
        }
        break;
      case 0xE1:
        if (d.compare(0, 6, std::string("Exif\0\0", 6)) == 0) parseExifBlock(d.substr(6), img.exif, img.orientation);
        break;
      case 0xE2:
        if (d.compare(0, 12, "ICC_PROFILE\0", 12) == 0) icc += d.substr(14);
        break;
      case 0xEE:
        if (d.compare(0, 5, "Adobe") == 0 && d.size() >= 12) { adobe = true; adobeTransform = static_cast<uint8_t>(d[11]); }
        break;
      case 0xFE: img.text.push_back({"Comment", d}); break;
      case 0xDA: {
        int ns = static_cast<uint8_t>(d[0]);
        std::vector<Comp *> sc;
        for (int k = 0; k < ns; k++) {
          int cid = static_cast<uint8_t>(d[1 + 2 * k]);
          for (auto &c : comps)
            if (c.id == cid) {
              c.td = static_cast<uint8_t>(d[2 + 2 * k]) >> 4;
              c.ta = d[2 + 2 * k] & 15;
              sc.push_back(&c);
            }
        }
        size_t q = 1 + 2 * static_cast<size_t>(ns);
        int ss = static_cast<uint8_t>(d[q]), se = static_cast<uint8_t>(d[q + 1]);
        int ah = static_cast<uint8_t>(d[q + 2]) >> 4, al = d[q + 2] & 15;
        BitIn bi(b, next);
        for (auto *c : sc) c->pred = 0;
        eobrun = 0;
        auto decodeBlock = [&](Comp &c, int *blk) {
          if (!progressive) {
            int t = bi.decode(dc[c.td]);
            c.pred += bi.receive(t);
            blk[0] = c.pred;
            for (int k = 1; k < 64;) {
              int rs = bi.decode(ac[c.ta]);
              int r = rs >> 4, s = rs & 15;
              if (!s) { if (r != 15) break; k += 16; continue; }
              k += r;
              if (k > 63) break;
              blk[kZigzag[k]] = bi.receive(s);
              k++;
            }
            return;
          }
          if (ss == 0) { // DC scan
            if (ah == 0) {
              int t = bi.decode(dc[c.td]);
              c.pred += bi.receive(t);
              blk[0] = c.pred * (1 << al);
            } else if (bi.bit()) {
              blk[0] |= 1 << al;
            }
            return;
          }
          if (ah == 0) { // AC first
            if (eobrun > 0) { eobrun--; return; }
            for (int k = ss; k <= se;) {
              int rs = bi.decode(ac[c.ta]);
              int r = rs >> 4, s = rs & 15;
              if (!s) {
                if (r < 15) { eobrun = (1 << r) - 1; if (r) eobrun += bi.bits(r); break; }
                k += 16;
                continue;
              }
              k += r;
              if (k > 63) break;
              blk[kZigzag[k]] = bi.receive(s) * (1 << al);
              k++;
            }
            return;
          }
          // AC refinement
          int p1 = 1 << al, m1 = -1 * (1 << al);
          int k = ss;
          if (eobrun <= 0) {
            for (; k <= se;) {
              int rs = bi.decode(ac[c.ta]);
              int r = rs >> 4, s = rs & 15;
              int val = 0;
              if (!s) {
                if (r < 15) { eobrun = 1 << r; if (r) eobrun += bi.bits(r); break; }
              } else {
                val = bi.bit() ? p1 : m1;
              }
              while (k <= se) {
                int z = kZigzag[k];
                if (blk[z] != 0) {
                  if (bi.bit() && (blk[z] & p1) == 0) blk[z] += blk[z] >= 0 ? p1 : m1;
                } else {
                  if (r == 0) {
                    if (val) blk[z] = val;
                    k++;
                    break;
                  }
                  r--;
                }
                k++;
              }
            }
          }
          if (eobrun > 0) {
            for (; k <= se; k++) {
              int z = kZigzag[k];
              if (blk[z] != 0 && bi.bit() && (blk[z] & p1) == 0) blk[z] += blk[z] >= 0 ? p1 : m1;
            }
            eobrun--;
          }
        };
        int mcuCount = 0;
        auto restartCheck = [&]() {
          mcuCount++;
          if (restart && mcuCount % restart == 0) {
            // skip to the RST marker
            bi.reset();
            while (bi.p + 1 < b.size() && !(static_cast<uint8_t>(b[bi.p]) == 0xFF && static_cast<uint8_t>(b[bi.p + 1]) >= 0xD0 &&
                                              static_cast<uint8_t>(b[bi.p + 1]) <= 0xD7))
              bi.p++;
            bi.p += 2;
            for (auto *c : sc) c->pred = 0;
            eobrun = 0;
          }
        };
        if (sc.size() == 1) { // non-interleaved: the component's own block grid
          Comp &c = *sc[0];
          int cbw = (width * c.h / hmax + 7) / 8, cbh = (height * c.v / vmax + 7) / 8;
          for (int by = 0; by < cbh; by++)
            for (int bx = 0; bx < cbw; bx++) {
              decodeBlock(c, &c.coef[static_cast<size_t>((by * c.bw + bx) * 64)]);
              restartCheck();
            }
        } else {
          for (int my = 0; my < mcuy; my++)
            for (int mx = 0; mx < mcux; mx++) {
              for (auto *c : sc)
                for (int v = 0; v < c->v; v++)
                  for (int h = 0; h < c->h; h++)
                    decodeBlock(*c, &c->coef[static_cast<size_t>(((my * c->v + v) * c->bw + mx * c->h + h) * 64)]);
              restartCheck();
            }
        }
        // continue after the entropy-coded data
        next = bi.p;
        while (next + 1 < b.size() && !(static_cast<uint8_t>(b[next]) == 0xFF && static_cast<uint8_t>(b[next + 1]) != 0 &&
                                         !(static_cast<uint8_t>(b[next + 1]) >= 0xD0 && static_cast<uint8_t>(b[next + 1]) <= 0xD7)))
          next++;
        break;
      }
      default: break;
    }
    p = next;
  }
  if (!width || comps.empty()) {
    err = "JPEG has no frame header";
    return false;
  }
  // dequantize + IDCT into component planes
  std::vector<std::vector<double>> planes(comps.size());
  for (size_t ci = 0; ci < comps.size(); ci++) {
    Comp &c = comps[ci];
    int pw = c.bw * 8, ph = c.bh * 8;
    planes[ci].assign(static_cast<size_t>(pw * ph), 0);
    double in[64], out[64];
    for (int by = 0; by < c.bh; by++)
      for (int bx = 0; bx < c.bw; bx++) {
        const int *blk = &c.coef[static_cast<size_t>((by * c.bw + bx) * 64)];
        for (int k = 0; k < 64; k++) in[k] = blk[k] * qt[c.tq][k];
        idct8x8(in, out);
        for (int y = 0; y < 8; y++)
          for (int x = 0; x < 8; x++)
            planes[ci][static_cast<size_t>((by * 8 + y) * pw + bx * 8 + x)] = out[y * 8 + x] + 128;
      }
  }
  img.width = static_cast<size_t>(width);
  img.height = static_cast<size_t>(height);
  size_t nc = comps.size();
  img.channels = nc == 1 ? 1 : 3;
  img.colorSpace = nc == 1 ? "Grayscale" : nc == 4 ? "CMYK" : (adobe && adobeTransform == 0) ? "RGB" : "YCbCr";
  img.px.assign(img.width * img.height * img.channels, 0);
  for (size_t y = 0; y < img.height; y++)
    for (size_t x = 0; x < img.width; x++) {
      double s[4] = {0, 0, 0, 0};
      for (size_t ci = 0; ci < nc && ci < 4; ci++) {
        const Comp &c = comps[ci];
        size_t sx = x * static_cast<size_t>(c.h) / static_cast<size_t>(hmax), sy = y * static_cast<size_t>(c.v) / static_cast<size_t>(vmax);
        s[ci] = planes[ci][sy * static_cast<size_t>(c.bw * 8) + sx];
      }
      double *d = &img.px[(y * img.width + x) * img.channels];
      if (nc == 1) { d[0] = std::clamp(std::round(s[0]), 0.0, 255.0); continue; }
      double r, g, bl;
      bool ycc = !(adobe && adobeTransform == 0) || nc == 4;
      if (nc == 4 && adobeTransform != 2) ycc = false;
      if (ycc) {
        r = s[0] + 1.402 * (s[2] - 128);
        g = s[0] - 0.344136 * (s[1] - 128) - 0.714136 * (s[2] - 128);
        bl = s[0] + 1.772 * (s[1] - 128);
      } else {
        r = s[0]; g = s[1]; bl = s[2];
      }
      if (nc == 4) { // (inverted) CMYK -> RGB
        double k = s[3];
        if (adobe) { r = r * k / 255; g = g * k / 255; bl = bl * k / 255; }
        else { r = (255 - r) * (255 - k) / 255; g = (255 - g) * (255 - k) / 255; bl = (255 - bl) * (255 - k) / 255; }
      }
      d[0] = std::clamp(std::round(r), 0.0, 255.0);
      d[1] = std::clamp(std::round(g), 0.0, 255.0);
      d[2] = std::clamp(std::round(bl), 0.0, 255.0);
    }
  if (img.colorSpace != "Grayscale") img.colorSpace = nc == 4 ? "CMYK" : "YCbCr";
  img.icc = icc;
  img.extra["progressive"] = Value::boolean(progressive);
  return true;
}

// ---- encoder --------------------------------------------------------------------

namespace {

struct HuffCode {
  uint16_t code[256] = {0};
  uint8_t len[256] = {0};
  void build(const uint8_t bits[16], const uint8_t *vals) {
    int code = 0, k = 0;
    for (int l = 1; l <= 16; l++) {
      for (int i = 0; i < bits[l - 1]; i++) {
        this->code[vals[k]] = static_cast<uint16_t>(code);
        len[vals[k]] = static_cast<uint8_t>(l);
        code++;
        k++;
      }
      code <<= 1;
    }
  }
};

struct BitOut {
  std::string &out;
  uint32_t buf = 0;
  int cnt = 0;
  explicit BitOut(std::string &o) : out(o) {}
  void put(uint32_t v, int n) {
    for (int k = n - 1; k >= 0; k--) {
      buf = (buf << 1) | ((v >> k) & 1);
      if (++cnt == 8) {
        out.push_back(static_cast<char>(buf));
        if ((buf & 0xFF) == 0xFF) out.push_back(0);
        buf = 0;
        cnt = 0;
      }
    }
  }
  void flush() {
    while (cnt) put(1, 1);
  }
};

int category(int v) {
  int a = std::abs(v), n = 0;
  while (a) { n++; a >>= 1; }
  return n;
}
uint32_t bitsOf(int v, int n) { return static_cast<uint32_t>(v >= 0 ? v : v + (1 << n) - 1); }

void marker(std::string &o, uint8_t m, const std::string &d) {
  o.push_back('\xFF');
  o.push_back(static_cast<char>(m));
  putBE(o, d.size() + 2, 2);
  o += d;
}

} // namespace

std::string encodeJpeg(const Image &imgIn, int quality, bool sub420, bool progressive) {
  Image img = to8bit(imgIn);
  if (img.channels == 2) img = convertChannels(img, "gray");
  if (img.channels == 4) img = convertChannels(img, "rgb");
  const bool gray = img.channels == 1;
  quality = std::clamp(quality, 1, 100);
  int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
  int q[2][64];
  for (int k = 0; k < 64; k++) {
    q[0][k] = std::clamp((kStdLumQ[k] * scale + 50) / 100, 1, 255);
    q[1][k] = std::clamp((kStdChrQ[k] * scale + 50) / 100, 1, 255);
  }
  const int ncomp = gray ? 1 : 3;
  const int hs = (!gray && sub420) ? 2 : 1;
  const int W = static_cast<int>(img.width), H = static_cast<int>(img.height);
  const int mcuw = 8 * hs, mcux = (W + mcuw - 1) / mcuw, mcuy = (H + mcuw - 1) / mcuw;
  // planes
  std::vector<std::vector<double>> plane(static_cast<size_t>(ncomp), std::vector<double>(static_cast<size_t>(W * H)));
  for (int i = 0; i < W * H; i++) {
    const double *s = &img.px[static_cast<size_t>(i) * img.channels];
    if (gray) { plane[0][static_cast<size_t>(i)] = s[0]; continue; }
    plane[0][static_cast<size_t>(i)] = 0.299 * s[0] + 0.587 * s[1] + 0.114 * s[2];
    plane[1][static_cast<size_t>(i)] = -0.168736 * s[0] - 0.331264 * s[1] + 0.5 * s[2] + 128;
    plane[2][static_cast<size_t>(i)] = 0.5 * s[0] - 0.418688 * s[1] - 0.081312 * s[2] + 128;
  }
  auto sample = [&](int c, int x, int y) {
    x = std::min(x, W - 1);
    y = std::min(y, H - 1);
    return plane[static_cast<size_t>(c)][static_cast<size_t>(y * W + x)];
  };
  // quantized coefficients per component block grid
  struct CB { int bw, bh; std::vector<int> coef; };
  std::vector<CB> cb(static_cast<size_t>(ncomp));
  for (int c = 0; c < ncomp; c++) {
    int f = (c == 0) ? hs : 1;
    cb[static_cast<size_t>(c)].bw = mcux * f;
    cb[static_cast<size_t>(c)].bh = mcuy * f;
    cb[static_cast<size_t>(c)].coef.assign(static_cast<size_t>(mcux * f * mcuy * f * 64), 0);
    int sub = (c == 0) ? 1 : hs; // pixels per chroma sample
    double in[64], out[64];
    for (int by = 0; by < mcuy * f; by++)
      for (int bx = 0; bx < mcux * f; bx++) {
        for (int y = 0; y < 8; y++)
          for (int x = 0; x < 8; x++) {
            double v = 0;
            for (int dy = 0; dy < sub; dy++)
              for (int dx = 0; dx < sub; dx++) v += sample(c, (bx * 8 + x) * sub + dx, (by * 8 + y) * sub + dy);
            in[y * 8 + x] = v / (sub * sub) - 128;
          }
        fdct8x8(in, out);
        int *blk = &cb[static_cast<size_t>(c)].coef[static_cast<size_t>((by * mcux * f + bx) * 64)];
        for (int k = 0; k < 64; k++) blk[k] = static_cast<int>(std::lround(out[kZigzag[k]] / q[c ? 1 : 0][kZigzag[k]]));
      }
  }
  HuffCode dcL, dcC, acL, acC;
  dcL.build(kDcLumBits, kDcVals);
  dcC.build(kDcChrBits, kDcVals);
  acL.build(kAcLumBits, kAcLumVals);
  acC.build(kAcChrBits, kAcChrVals);
  std::string o("\xFF\xD8", 2);
  std::string jfif("JFIF\0\x01\x01", 7);
  jfif.push_back(img.dpiX > 0 ? 1 : 0);
  putBE(jfif, img.dpiX > 0 ? static_cast<uint64_t>(img.dpiX) : 1, 2);
  putBE(jfif, img.dpiY > 0 ? static_cast<uint64_t>(img.dpiY) : img.dpiX > 0 ? static_cast<uint64_t>(img.dpiX) : 1, 2);
  jfif += std::string("\0\0", 2);
  marker(o, 0xE0, jfif);
  for (const auto &t : img.text) marker(o, 0xFE, (t.first == "Comment" ? "" : t.first + ": ") + t.second);
  for (int t = 0; t < (gray ? 1 : 2); t++) {
    std::string d(1, static_cast<char>(t));
    for (int k = 0; k < 64; k++) d.push_back(static_cast<char>(q[t][kZigzag[k]]));
    marker(o, 0xDB, d);
  }
  std::string sof(1, 8);
  putBE(sof, static_cast<uint64_t>(H), 2);
  putBE(sof, static_cast<uint64_t>(W), 2);
  sof.push_back(static_cast<char>(ncomp));
  for (int c = 0; c < ncomp; c++) {
    sof.push_back(static_cast<char>(c + 1));
    sof.push_back(static_cast<char>(c == 0 ? (hs << 4 | hs) : 0x11));
    sof.push_back(static_cast<char>(c ? 1 : 0));
  }
  marker(o, progressive ? 0xC2 : 0xC0, sof);
  auto dht = [&](int cls, int id, const uint8_t bits[16], const uint8_t *vals, int nvals) {
    std::string d(1, static_cast<char>(cls << 4 | id));
    for (int k = 0; k < 16; k++) d.push_back(static_cast<char>(bits[k]));
    d.append(reinterpret_cast<const char *>(vals), static_cast<size_t>(nvals));
    marker(o, 0xC4, d);
  };
  dht(0, 0, kDcLumBits, kDcVals, 12);
  dht(1, 0, kAcLumBits, kAcLumVals, 162);
  if (!gray) {
    dht(0, 1, kDcChrBits, kDcVals, 12);
    dht(1, 1, kAcChrBits, kAcChrVals, 162);
  }
  auto encodeDc = [&](BitOut &bo, int diff, const HuffCode &h) {
    int n = category(diff);
    bo.put(h.code[n], h.len[n]);
    if (n) bo.put(bitsOf(diff, n), n);
  };
  auto encodeAc = [&](BitOut &bo, const int *blk, int ss, int se, const HuffCode &h) {
    int run = 0;
    for (int k = ss; k <= se; k++) {
      int v = blk[k];
      if (!v) { run++; continue; }
      while (run > 15) { bo.put(h.code[0xF0], h.len[0xF0]); run -= 16; }
      int n = category(v);
      int sym = run << 4 | n;
      bo.put(h.code[sym], h.len[sym]);
      bo.put(bitsOf(v, n), n);
      run = 0;
    }
    if (run) bo.put(h.code[0], h.len[0]);
  };
  auto sos = [&](const std::vector<int> &cs, int ss, int se) {
    std::string d(1, static_cast<char>(cs.size()));
    for (int c : cs) {
      d.push_back(static_cast<char>(c + 1));
      d.push_back(static_cast<char>(c ? 0x11 : 0x00));
    }
    d.push_back(static_cast<char>(ss));
    d.push_back(static_cast<char>(se));
    d.push_back(0);
    marker(o, 0xDA, d);
  };
  auto blockAt = [&](int c, int bx, int by) { return &cb[static_cast<size_t>(c)].coef[static_cast<size_t>((by * cb[static_cast<size_t>(c)].bw + bx) * 64)]; };
  if (!progressive) {
    std::vector<int> all;
    for (int c = 0; c < ncomp; c++) all.push_back(c);
    sos(all, 0, 63);
    BitOut bo(o);
    int pred[3] = {0, 0, 0};
    for (int my = 0; my < mcuy; my++)
      for (int mx = 0; mx < mcux; mx++)
        for (int c = 0; c < ncomp; c++) {
          int f = c == 0 ? hs : 1;
          for (int v = 0; v < f; v++)
            for (int h = 0; h < f; h++) {
              const int *blk = blockAt(c, mx * f + h, my * f + v);
              encodeDc(bo, blk[0] - pred[c], c ? dcC : dcL);
              pred[c] = blk[0];
              encodeAc(bo, blk, 1, 63, c ? acC : acL);
            }
        }
    bo.flush();
  } else {
    // DC scan (interleaved), then AC bands per component
    {
      std::vector<int> all;
      for (int c = 0; c < ncomp; c++) all.push_back(c);
      sos(all, 0, 0);
      BitOut bo(o);
      int pred[3] = {0, 0, 0};
      for (int my = 0; my < mcuy; my++)
        for (int mx = 0; mx < mcux; mx++)
          for (int c = 0; c < ncomp; c++) {
            int f = c == 0 ? hs : 1;
            for (int v = 0; v < f; v++)
              for (int h = 0; h < f; h++) {
                const int *blk = blockAt(c, mx * f + h, my * f + v);
                encodeDc(bo, blk[0] - pred[c], c ? dcC : dcL);
                pred[c] = blk[0];
              }
          }
      bo.flush();
    }
    const int bands[2][2] = {{1, 5}, {6, 63}};
    for (const auto &band : bands)
      for (int c = 0; c < ncomp; c++) {
        sos({c}, band[0], band[1]);
        BitOut bo(o);
        int f = c == 0 ? hs : 1;
        int compW = c == 0 ? W : (W + hs - 1) / hs, compH = c == 0 ? H : (H + hs - 1) / hs;
        (void)f;
        int cbw = (compW + 7) / 8, cbh = (compH + 7) / 8;
        for (int by = 0; by < cbh; by++)
          for (int bx = 0; bx < cbw; bx++) encodeAc(bo, blockAt(c, bx, by), band[0], band[1], c ? acC : acL);
        bo.flush();
      }
  }
  o += "\xFF\xD9";
  return o;
}

} // namespace io
} // namespace nc
