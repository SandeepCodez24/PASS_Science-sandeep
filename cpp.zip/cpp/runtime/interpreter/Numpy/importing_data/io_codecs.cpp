// Snappy, LZ4 and Zstandard (see io_codecs.h).
#include <algorithm>
#include <array>
#include <cstring>
#include <vector>

#include "io_bytes.h"
#include "io_codecs.h"
#include "io_deflate.h"

namespace nc {
namespace io {

// ---- xxHash32 -----------------------------------------------------------------------------

namespace {
constexpr uint32_t P1 = 2654435761u, P2 = 2246822519u, P3 = 3266489917u, P4 = 668265263u, P5 = 374761393u;
uint32_t rotl(uint32_t x, int r) { return (x << r) | (x >> (32 - r)); }
uint32_t rd32(const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | (static_cast<uint32_t>(p[3]) << 24); }
} // namespace

uint32_t xxh32(const void *data, size_t n, uint32_t seed) {
  const unsigned char *p = static_cast<const unsigned char *>(data), *end = p + n;
  uint32_t h;
  if (n >= 16) {
    uint32_t v1 = seed + P1 + P2, v2 = seed + P2, v3 = seed, v4 = seed - P1;
    const unsigned char *limit = end - 16;
    do {
      v1 = rotl(v1 + rd32(p) * P2, 13) * P1; p += 4;
      v2 = rotl(v2 + rd32(p) * P2, 13) * P1; p += 4;
      v3 = rotl(v3 + rd32(p) * P2, 13) * P1; p += 4;
      v4 = rotl(v4 + rd32(p) * P2, 13) * P1; p += 4;
    } while (p <= limit);
    h = rotl(v1, 1) + rotl(v2, 7) + rotl(v3, 12) + rotl(v4, 18);
  } else h = seed + P5;
  h += static_cast<uint32_t>(n);
  while (p + 4 <= end) { h = rotl(h + rd32(p) * P3, 17) * P4; p += 4; }
  while (p < end) { h = rotl(h + (*p) * P5, 11) * P1; p++; }
  h ^= h >> 15; h *= P2; h ^= h >> 13; h *= P3; h ^= h >> 16;
  return h;
}

// ---- Snappy -------------------------------------------------------------------------------

std::string snappyCompress(const std::string &in) {
  std::string out;
  uint64_t n = in.size();
  do { unsigned char b = n & 0x7F; n >>= 7; out.push_back(static_cast<char>(b | (n ? 0x80 : 0))); } while (n);
  const size_t len = in.size();
  std::vector<int64_t> table(1 << 14, -1);
  size_t i = 0, lit = 0;
  auto emitLiteral = [&](size_t from, size_t to) {
    while (from < to) {
      size_t l = std::min<size_t>(to - from, 65536);
      size_t m = l - 1;
      if (m < 60) out.push_back(static_cast<char>(m << 2));
      else if (m < 256) { out.push_back(static_cast<char>(60 << 2)); out.push_back(static_cast<char>(m)); }
      else { out.push_back(static_cast<char>(61 << 2)); out.push_back(static_cast<char>(m & 0xFF)); out.push_back(static_cast<char>(m >> 8)); }
      out.append(in, from, l);
      from += l;
    }
  };
  while (i + 4 <= len) {
    uint32_t v;
    std::memcpy(&v, in.data() + i, 4);
    uint32_t h = (v * 0x1e35a7bdu) >> 18;
    int64_t ref = table[h];
    table[h] = static_cast<int64_t>(i);
    if (ref >= 0 && i - static_cast<size_t>(ref) < 65536 && std::memcmp(in.data() + ref, in.data() + i, 4) == 0) {
      size_t m = 4;
      while (i + m < len && in[ref + m] == in[i + m]) m++;
      emitLiteral(lit, i);
      size_t off = i - static_cast<size_t>(ref), left = m;
      while (left > 0) {
        size_t l = std::min<size_t>(left, 64);
        if (left - l > 0 && left - l < 4) l = left - 4;
        out.push_back(static_cast<char>(((l - 1) << 2) | 2));
        out.push_back(static_cast<char>(off & 0xFF));
        out.push_back(static_cast<char>(off >> 8));
        left -= l;
      }
      i += m;
      lit = i;
    } else i++;
  }
  emitLiteral(lit, len);
  return out;
}

bool snappyDecompress(const std::string &in, std::string &out, std::string &err) {
  size_t p = 0;
  uint64_t n = 0;
  for (int s = 0; p < in.size(); s += 7) {
    unsigned char b = static_cast<unsigned char>(in[p++]);
    n |= static_cast<uint64_t>(b & 0x7F) << s;
    if (!(b & 0x80)) break;
    if (s > 56) { err = "snappy: bad length"; return false; }
  }
  out.clear();
  out.reserve(static_cast<size_t>(n));
  while (p < in.size()) {
    unsigned char tag = static_cast<unsigned char>(in[p++]);
    size_t len, off;
    switch (tag & 3) {
    case 0:
      len = (tag >> 2) + 1;
      if (len > 60) {
        size_t nb = len - 60;
        if (p + nb > in.size()) { err = "snappy: cut short"; return false; }
        len = static_cast<size_t>(getLE(in, p, static_cast<int>(nb))) + 1;
        p += nb;
      }
      if (p + len > in.size()) { err = "snappy: literal runs past the end"; return false; }
      out.append(in, p, len);
      p += len;
      continue;
    case 1:
      if (p >= in.size()) { err = "snappy: cut short"; return false; }
      len = ((tag >> 2) & 7) + 4;
      off = (static_cast<size_t>(tag >> 5) << 8) | static_cast<unsigned char>(in[p++]);
      break;
    case 2:
      if (p + 2 > in.size()) { err = "snappy: cut short"; return false; }
      len = (tag >> 2) + 1;
      off = u16le(in, p);
      p += 2;
      break;
    default:
      if (p + 4 > in.size()) { err = "snappy: cut short"; return false; }
      len = (tag >> 2) + 1;
      off = u32le(in, p);
      p += 4;
    }
    if (off == 0 || off > out.size()) { err = "snappy: bad copy offset"; return false; }
    size_t from = out.size() - off;
    for (size_t k = 0; k < len; k++) out.push_back(out[from + k]);
  }
  if (out.size() != n) { err = "snappy: length mismatch"; return false; }
  return true;
}

// ---- LZ4 ----------------------------------------------------------------------------------

std::string lz4BlockCompress(const std::string &in) {
  std::string out;
  const size_t n = in.size();
  std::vector<int64_t> table(1 << 16, -1);
  size_t i = 0, anchor = 0;
  auto putLen = [&](size_t v) { while (v >= 255) { out.push_back(static_cast<char>(255)); v -= 255; } out.push_back(static_cast<char>(v)); };
  const size_t mfLimit = n > 12 ? n - 12 : 0;
  while (i < mfLimit) {
    uint32_t v;
    std::memcpy(&v, in.data() + i, 4);
    uint32_t h = (v * 2654435761u) >> 16;
    int64_t ref = table[h];
    table[h] = static_cast<int64_t>(i);
    if (ref >= 0 && i - static_cast<size_t>(ref) <= 65535 && std::memcmp(in.data() + ref, in.data() + i, 4) == 0) {
      size_t m = 4;
      while (i + m < n - 5 && in[ref + m] == in[i + m]) m++;
      size_t litLen = i - anchor, ml = m - 4;
      out.push_back(static_cast<char>((std::min<size_t>(litLen, 15) << 4) | std::min<size_t>(ml, 15)));
      if (litLen >= 15) putLen(litLen - 15);
      out.append(in, anchor, litLen);
      size_t off = i - static_cast<size_t>(ref);
      out.push_back(static_cast<char>(off & 0xFF));
      out.push_back(static_cast<char>(off >> 8));
      if (ml >= 15) putLen(ml - 15);
      i += m;
      anchor = i;
    } else i++;
  }
  size_t litLen = n - anchor;
  out.push_back(static_cast<char>(std::min<size_t>(litLen, 15) << 4));
  if (litLen >= 15) putLen(litLen - 15);
  out.append(in, anchor, litLen);
  return out;
}

bool lz4BlockDecompress(const char *in, size_t n, std::string &out, size_t maxOut, std::string &err) {
  size_t p = 0, start = out.size();
  while (p < n) {
    unsigned token = static_cast<unsigned char>(in[p++]);
    size_t lit = token >> 4;
    if (lit == 15) { unsigned char b; do { if (p >= n) { err = "lz4: cut short"; return false; } b = static_cast<unsigned char>(in[p++]); lit += b; } while (b == 255); }
    if (p + lit > n) { err = "lz4: literal runs past the end"; return false; }
    out.append(in + p, lit);
    p += lit;
    if (p >= n) break; // last sequence
    if (p + 2 > n) { err = "lz4: cut short"; return false; }
    size_t off = static_cast<unsigned char>(in[p]) | (static_cast<unsigned char>(in[p + 1]) << 8);
    p += 2;
    size_t ml = (token & 15) + 4;
    if ((token & 15) == 15) { unsigned char b; do { if (p >= n) { err = "lz4: cut short"; return false; } b = static_cast<unsigned char>(in[p++]); ml += b; } while (b == 255); }
    if (off == 0 || off > out.size() - start + start) { err = "lz4: bad match offset"; return false; }
    size_t from = out.size() - off;
    for (size_t k = 0; k < ml; k++) out.push_back(out[from + k]);
    if (maxOut && out.size() - start > maxOut) { err = "lz4: output is larger than expected"; return false; }
  }
  return true;
}

std::string lz4FrameCompress(const std::string &in) {
  std::string out;
  putLE(out, 0x184D2204, 4);
  std::string desc;
  desc.push_back(static_cast<char>(0x40 | 0x20 | 0x08)); // version 01, independent blocks, content size
  desc.push_back(static_cast<char>(0x70));               // 4 MB blocks
  putLE(desc, in.size(), 8);
  out += desc;
  out.push_back(static_cast<char>((xxh32(desc.data(), desc.size()) >> 8) & 0xFF));
  const size_t block = 4 << 20;
  for (size_t p = 0; p < in.size(); p += block) {
    std::string chunk = in.substr(p, block);
    std::string c = lz4BlockCompress(chunk);
    if (c.size() >= chunk.size()) { putLE(out, chunk.size() | 0x80000000u, 4); out += chunk; }
    else { putLE(out, c.size(), 4); out += c; }
  }
  putLE(out, 0, 4);
  return out;
}

bool lz4FrameDecompress(const std::string &in, std::string &out, std::string &err) {
  size_t p = 0;
  out.clear();
  while (p + 4 <= in.size()) {
    uint32_t magic = u32le(in, p);
    if ((magic & 0xFFFFFFF0u) == 0x184D2A50u) { p += 8 + u32le(in, p + 4); continue; } // skippable
    if (magic != 0x184D2204u) { err = "lz4: not an LZ4 frame"; return false; }
    if (p + 7 > in.size()) { err = "lz4: frame header cut short"; return false; }
    unsigned flg = static_cast<unsigned char>(in[p + 4]);
    size_t q = p + 6;
    if (flg & 0x08) q += 8;
    if (flg & 0x01) q += 4;
    q += 1; // header checksum
    bool blockSum = flg & 0x10, contentSum = flg & 0x04;
    for (;;) {
      if (q + 4 > in.size()) { err = "lz4: frame cut short"; return false; }
      uint32_t sz = u32le(in, q);
      q += 4;
      if (sz == 0) break;
      bool raw = sz & 0x80000000u;
      sz &= 0x7FFFFFFFu;
      if (q + sz > in.size()) { err = "lz4: block runs past the end"; return false; }
      if (raw) out.append(in, q, sz);
      else if (!lz4BlockDecompress(in.data() + q, sz, out, 0, err)) return false;
      q += sz + (blockSum ? 4 : 0);
    }
    if (contentSum) q += 4;
    p = q;
  }
  return true;
}

bool lz4HadoopDecompress(const std::string &in, std::string &out, std::string &err) {
  size_t p = 0;
  out.clear();
  while (p + 8 <= in.size()) {
    uint32_t total = u32be(in, p);
    p += 4;
    size_t target = out.size() + total;
    while (out.size() < target) {
      if (p + 4 > in.size()) { err = "lz4 (hadoop): cut short"; return false; }
      uint32_t c = u32be(in, p);
      p += 4;
      if (p + c > in.size()) { err = "lz4 (hadoop): block runs past the end"; return false; }
      if (!lz4BlockDecompress(in.data() + p, c, out, total, err)) return false;
      p += c;
    }
    if (out.size() != target) { err = "lz4 (hadoop): size mismatch"; return false; }
  }
  return p == in.size();
}

// ---- Zstandard ----------------------------------------------------------------------------

namespace {

int highbit(uint32_t v) { int r = 0; while (v >>= 1) r++; return r; }

struct FseEntry { uint16_t symbol; uint8_t bits; uint16_t base; };
using FseTable = std::vector<FseEntry>;

bool buildFse(const std::vector<int> &norm, int al, FseTable &t) {
  size_t size = size_t(1) << al;
  t.assign(size, {0, 0, 0});
  std::vector<uint32_t> next(norm.size());
  size_t high = size - 1;
  for (size_t s = 0; s < norm.size(); s++)
    if (norm[s] == -1) { t[high--].symbol = static_cast<uint16_t>(s); next[s] = 1; }
    else next[s] = static_cast<uint32_t>(std::max(norm[s], 0));
  size_t step = (size >> 1) + (size >> 3) + 3, mask = size - 1, pos = 0;
  for (size_t s = 0; s < norm.size(); s++)
    for (int i = 0; i < norm[s]; i++) {
      t[pos].symbol = static_cast<uint16_t>(s);
      do pos = (pos + step) & mask; while (pos > high);
    }
  if (pos != 0) return false;
  for (size_t u = 0; u < size; u++) {
    uint32_t ns = next[t[u].symbol]++;
    int bits = al - highbit(ns);
    t[u].bits = static_cast<uint8_t>(bits);
    t[u].base = static_cast<uint16_t>((ns << bits) - size);
  }
  return true;
}

const std::vector<int> LL_DEFAULT = {4, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 1, 1, 1, 1, -1, -1, -1, -1};
const std::vector<int> ML_DEFAULT = {1, 4, 3, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                                     1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1};
const std::vector<int> OF_DEFAULT = {1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1};
const uint32_t LL_BASE[36] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20, 22, 24, 28, 32, 40, 48, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536};
const uint8_t LL_BITS[36] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 3, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
const uint32_t ML_BASE[53] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34,
                              35, 37, 39, 41, 43, 47, 51, 59, 67, 83, 99, 131, 259, 515, 1027, 2051, 4099, 8195, 16387, 32771, 65539};
const uint8_t ML_BITS[53] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             1, 1, 1, 1, 2, 2, 3, 3, 4, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};

// backward bit stream (reads from the end, most significant bits first)
struct BackBits {
  const unsigned char *d;
  int64_t pos; // bits left
  bool init(const char *data, size_t n) {
    d = reinterpret_cast<const unsigned char *>(data);
    if (n == 0 || d[n - 1] == 0) return false;
    pos = static_cast<int64_t>(n) * 8 - (8 - highbit(d[n - 1]));
    return true;
  }
  uint64_t read(int n) {
    if (n == 0) return 0;
    int64_t lo = pos - n;
    uint64_t v = 0;
    if (lo >= 0) {
      size_t byte = static_cast<size_t>(lo >> 3), shift = static_cast<size_t>(lo & 7);
      uint64_t w = 0;
      size_t avail = static_cast<size_t>((pos + 7) >> 3) - byte;
      for (size_t k = 0; k < avail && k < 8; k++) w |= static_cast<uint64_t>(d[byte + k]) << (8 * k);
      v = (w >> shift) & ((n == 64) ? ~0ull : ((1ull << n) - 1));
    } else {
      for (int64_t b = pos - 1; b >= lo; b--) v = (v << 1) | (b >= 0 ? (d[b >> 3] >> (b & 7)) & 1 : 0);
    }
    pos = lo;
    return v;
  }
};

// forward bit reader for FSE table descriptions
bool readFseTable(const char *src, size_t n, int maxAl, size_t maxSym, std::vector<int> &norm, int &al, size_t &used) {
  const unsigned char *d = reinterpret_cast<const unsigned char *>(src);
  size_t bit = 0;
  auto peek = [&](int k) -> uint32_t { uint32_t v = 0; for (int i = 0; i < k; i++) { size_t b = bit + i; if ((b >> 3) < n) v |= ((d[b >> 3] >> (b & 7)) & 1u) << i; } return v; };
  al = static_cast<int>(peek(4)) + 5;
  bit += 4;
  if (al > maxAl) return false;
  int remaining = (1 << al) + 1, threshold = 1 << al, nbBits = al + 1;
  norm.clear();
  bool prev0 = false;
  while (remaining > 1 && norm.size() <= maxSym) {
    if (prev0) {
      for (;;) {
        uint32_t r = peek(2);
        bit += 2;
        for (uint32_t k = 0; k < r; k++) norm.push_back(0);
        if (r != 3) break;
      }
      if (norm.size() > maxSym) return false;
    }
    int max = (2 * threshold - 1) - remaining;
    int count;
    uint32_t low = peek(nbBits - 1);
    if (static_cast<int>(low) < max) { count = static_cast<int>(low); bit += nbBits - 1; }
    else { count = static_cast<int>(peek(nbBits)); if (count >= threshold) count -= max; bit += nbBits; }
    count--;
    remaining -= count < 0 ? -count : count;
    norm.push_back(count);
    prev0 = count == 0;
    while (remaining < threshold) { nbBits--; threshold >>= 1; }
    if ((bit >> 3) > n) return false;
  }
  if (remaining != 1) return false;
  used = (bit + 7) >> 3;
  return true;
}

struct Huffman {
  int maxBits = 0;
  std::vector<std::pair<uint8_t, uint8_t>> table; // symbol, bits
};

bool readHuffman(const char *src, size_t n, Huffman &h, size_t &used, std::string &err) {
  if (n < 1) { err = "zstd: Huffman header missing"; return false; }
  unsigned head = static_cast<unsigned char>(src[0]);
  std::vector<int> w;
  if (head >= 128) {
    size_t count = head - 127;
    size_t bytes = (count + 1) / 2;
    if (1 + bytes > n) { err = "zstd: Huffman weights cut short"; return false; }
    for (size_t i = 0; i < count; i++) {
      unsigned b = static_cast<unsigned char>(src[1 + i / 2]);
      w.push_back(i % 2 == 0 ? b >> 4 : b & 15);
    }
    used = 1 + bytes;
  } else {
    size_t size = head;
    if (1 + size > n) { err = "zstd: Huffman weights cut short"; return false; }
    std::vector<int> norm;
    int al;
    size_t tused;
    if (!readFseTable(src + 1, size, 6, 255, norm, al, tused)) { err = "zstd: bad Huffman weight table"; return false; }
    FseTable t;
    if (!buildFse(norm, al, t)) { err = "zstd: bad Huffman weight table"; return false; }
    BackBits bb;
    if (!bb.init(src + 1 + tused, size - tused)) { err = "zstd: bad Huffman weight stream"; return false; }
    uint32_t s1 = static_cast<uint32_t>(bb.read(al)), s2 = static_cast<uint32_t>(bb.read(al));
    for (;;) { // two interleaved states until the stream runs out (RFC 8878 4.2.1.2)
      w.push_back(t[s1].symbol);
      s1 = t[s1].base + static_cast<uint32_t>(bb.read(t[s1].bits));
      if (bb.pos < 0) { w.push_back(t[s2].symbol); break; }
      w.push_back(t[s2].symbol);
      s2 = t[s2].base + static_cast<uint32_t>(bb.read(t[s2].bits));
      if (bb.pos < 0) { w.push_back(t[s1].symbol); break; }
      if (w.size() > 255) { err = "zstd: too many Huffman weights"; return false; }
    }
    used = 1 + size;
  }
  uint32_t total = 0;
  for (int x : w) if (x > 0) total += 1u << (x - 1);
  if (total == 0) { err = "zstd: empty Huffman table"; return false; }
  int maxBits = highbit(total) + 1;
  uint32_t rest = (1u << maxBits) - total;
  if (rest & (rest - 1)) { err = "zstd: bad Huffman weights"; return false; }
  w.push_back(highbit(rest) + 1);
  h.maxBits = maxBits;
  h.table.assign(size_t(1) << maxBits, {0, 0});
  std::vector<uint32_t> rankStart(maxBits + 2, 0);
  std::vector<uint32_t> cnt(maxBits + 2, 0);
  for (int x : w) if (x > 0) cnt[x]++;
  uint32_t next = 0;
  for (int k = 1; k <= maxBits; k++) { rankStart[k] = next; next += cnt[k] << (k - 1); }
  for (size_t s = 0; s < w.size(); s++) {
    int x = w[s];
    if (x <= 0) continue;
    uint32_t len = 1u << (x - 1);
    for (uint32_t i = 0; i < len; i++) h.table[rankStart[x] + i] = {static_cast<uint8_t>(s), static_cast<uint8_t>(maxBits + 1 - x)};
    rankStart[x] += len;
  }
  return true;
}

bool huffStream(const Huffman &h, const char *src, size_t n, size_t count, std::string &out, std::string &err) {
  BackBits bb;
  if (!bb.init(src, n)) { err = "zstd: bad Huffman stream"; return false; }
  for (size_t i = 0; i < count; i++) {
    int64_t save = bb.pos;
    uint32_t idx = static_cast<uint32_t>(bb.read(h.maxBits));
    const auto &e = h.table[idx];
    out.push_back(static_cast<char>(e.first));
    bb.pos = save - e.second;
  }
  if (bb.pos != 0) { err = "zstd: Huffman stream size mismatch"; return false; }
  return true;
}

struct ZState {
  Huffman huf;
  bool hufValid = false;
  FseTable ll, of, ml;
  bool tablesValid[3] = {false, false, false};
  uint32_t rep[3] = {1, 4, 8};
  int lastAl[3] = {6, 5, 6};
};

bool decodeBlock(const char *src, size_t n, std::string &out, size_t frameStart, ZState &st, std::string &err) {
  if (n < 1) { err = "zstd: empty block"; return false; }
  const unsigned char *d = reinterpret_cast<const unsigned char *>(src);
  // literals
  int ltype = d[0] & 3, sf = (d[0] >> 2) & 3;
  size_t regen = 0, comp = 0, hdr = 0;
  int streams = 1;
  if (ltype < 2) {
    if (sf == 0 || sf == 2) { regen = d[0] >> 3; hdr = 1; }
    else if (sf == 1) { if (n < 2) goto cut; regen = (d[0] >> 4) + (d[1] << 4); hdr = 2; }
    else { if (n < 3) goto cut; regen = (d[0] >> 4) + (d[1] << 4) + (d[2] << 12); hdr = 3; }
  } else {
    streams = sf == 0 ? 1 : 4;
    if (sf < 2) { if (n < 3) goto cut; uint32_t h = d[0] | (d[1] << 8) | (d[2] << 16); regen = (h >> 4) & 0x3FF; comp = (h >> 14) & 0x3FF; hdr = 3; }
    else if (sf == 2) { if (n < 4) goto cut; uint32_t h = rd32(d); regen = (h >> 4) & 0x3FFF; comp = (h >> 18) & 0x3FFF; hdr = 4; }
    else { if (n < 5) goto cut; uint64_t h = rd32(d) | (static_cast<uint64_t>(d[4]) << 32); regen = (h >> 4) & 0x3FFFF; comp = (h >> 22) & 0x3FFFF; hdr = 5; }
  }
  {
    std::string lits;
    size_t p = hdr;
    if (ltype == 0) { if (p + regen > n) goto cut; lits.assign(src + p, regen); p += regen; }
    else if (ltype == 1) { if (p + 1 > n) goto cut; lits.assign(regen, src[p]); p += 1; }
    else {
      if (p + comp > n) goto cut;
      size_t q = p;
      if (ltype == 2) {
        size_t used;
        if (!readHuffman(src + q, comp, st.huf, used, err)) return false;
        st.hufValid = true;
        q += used;
      } else if (!st.hufValid) { err = "zstd: treeless literals without a previous table"; return false; }
      size_t left = comp - (q - p);
      if (streams == 1) { if (!huffStream(st.huf, src + q, left, regen, lits, err)) return false; }
      else {
        if (left < 6) goto cut;
        size_t s1 = u16le(std::string(src + q, 6), 0), s2 = u16le(std::string(src + q, 6), 2), s3 = u16le(std::string(src + q, 6), 4);
        size_t s4 = left - 6 - s1 - s2 - s3;
        if (s1 + s2 + s3 + 6 > left) goto cut;
        size_t each = (regen + 3) / 4;
        const char *b = src + q + 6;
        if (!huffStream(st.huf, b, s1, each, lits, err) || !huffStream(st.huf, b + s1, s2, each, lits, err) ||
            !huffStream(st.huf, b + s1 + s2, s3, each, lits, err) || !huffStream(st.huf, b + s1 + s2 + s3, s4, regen - 3 * each, lits, err))
          return false;
      }
      p += comp;
    }
    // sequences
    if (p >= n) { out += lits; return true; }
    size_t nseq = d[p++];
    if (nseq >= 128) {
      if (nseq < 255) { if (p >= n) goto cut; nseq = ((nseq - 128) << 8) + d[p++]; }
      else { if (p + 2 > n) goto cut; nseq = d[p] + (d[p + 1] << 8) + 0x7F00; p += 2; }
    }
    if (nseq == 0) { out += lits; return true; }
    if (p >= n) goto cut;
    unsigned modes = d[p++];
    FseTable *tabs[3] = {&st.ll, &st.of, &st.ml};
    const std::vector<int> *defs[3] = {&LL_DEFAULT, &OF_DEFAULT, &ML_DEFAULT};
    const int defAl[3] = {6, 5, 6}, maxAl[3] = {9, 8, 9};
    const size_t maxSym[3] = {35, 31, 52};
    int als[3];
    for (int k = 0; k < 3; k++) {
      int mode = (modes >> (6 - 2 * k)) & 3;
      if (mode == 0) { buildFse(*defs[k], defAl[k], *tabs[k]); als[k] = defAl[k]; }
      else if (mode == 1) { if (p >= n) goto cut; tabs[k]->assign(1, {d[p++], 0, 0}); als[k] = 0; }
      else if (mode == 2) {
        std::vector<int> norm;
        size_t used;
        if (!readFseTable(src + p, n - p, maxAl[k], maxSym[k], norm, als[k], used) || !buildFse(norm, als[k], *tabs[k])) { err = "zstd: bad sequence table"; return false; }
        p += used;
      } else {
        if (!st.tablesValid[k]) { err = "zstd: repeat table without a previous one"; return false; }
        als[k] = st.lastAl[k];
      }
      st.tablesValid[k] = true;
      st.lastAl[k] = als[k];
    }
    BackBits bb;
    if (!bb.init(src + p, n - p)) { err = "zstd: bad sequence stream"; return false; }
    uint32_t sll = static_cast<uint32_t>(bb.read(als[0])), sof = static_cast<uint32_t>(bb.read(als[1])), sml = static_cast<uint32_t>(bb.read(als[2]));
    size_t litPos = 0;
    for (size_t i = 0; i < nseq; i++) {
      uint32_t llc = st.ll[sll].symbol, ofc = st.of[sof].symbol, mlc = st.ml[sml].symbol;
      if (llc > 35 || mlc > 52 || ofc > 31) { err = "zstd: bad sequence code"; return false; }
      uint32_t ov = (1u << ofc) + static_cast<uint32_t>(bb.read(static_cast<int>(ofc)));
      uint32_t ml = ML_BASE[mlc] + static_cast<uint32_t>(bb.read(ML_BITS[mlc]));
      uint32_t ll = LL_BASE[llc] + static_cast<uint32_t>(bb.read(LL_BITS[llc]));
      uint32_t off;
      if (ov > 3) { off = ov - 3; st.rep[2] = st.rep[1]; st.rep[1] = st.rep[0]; st.rep[0] = off; }
      else {
        // with ll == 0 the repeat codes shift by one: 1 -> rep1, 2 -> rep2, 3 -> rep0 - 1
        int idx = ll != 0 ? static_cast<int>(ov) - 1 : static_cast<int>(ov);
        if (idx == 0) off = st.rep[0];
        else if (idx == 1) { off = st.rep[1]; st.rep[1] = st.rep[0]; st.rep[0] = off; }
        else if (idx == 2) { off = st.rep[2]; st.rep[2] = st.rep[1]; st.rep[1] = st.rep[0]; st.rep[0] = off; }
        else { off = st.rep[0] - 1; st.rep[2] = st.rep[1]; st.rep[1] = st.rep[0]; st.rep[0] = off; }
      }
      if (litPos + ll > lits.size()) { err = "zstd: literals overrun"; return false; }
      out.append(lits, litPos, ll);
      litPos += ll;
      if (off == 0 || off > out.size() - frameStart) { err = "zstd: bad match offset"; return false; }
      size_t from = out.size() - off;
      for (uint32_t k = 0; k < ml; k++) out.push_back(out[from + k]);
      if (i + 1 < nseq) {
        sll = st.ll[sll].base + static_cast<uint32_t>(bb.read(st.ll[sll].bits));
        sml = st.ml[sml].base + static_cast<uint32_t>(bb.read(st.ml[sml].bits));
        sof = st.of[sof].base + static_cast<uint32_t>(bb.read(st.of[sof].bits));
      }
    }
    out.append(lits, litPos, std::string::npos);
    return true;
  }
cut:
  err = "zstd: block cut short";
  return false;
}

// ---- encoder ------------------------------------------------------------------------------

struct FseEnc {
  int al;
  std::vector<uint16_t> stateTable;
  struct TT { int32_t deltaFindState; uint32_t deltaNbBits; };
  std::vector<TT> tt;
  void build(const std::vector<int> &norm, int log) {
    al = log;
    size_t size = size_t(1) << al;
    std::vector<uint16_t> sym(size);
    std::vector<uint32_t> cumul(norm.size() + 1, 0);
    size_t high = size - 1;
    for (size_t s = 0; s < norm.size(); s++) {
      if (norm[s] == -1) { cumul[s + 1] = cumul[s] + 1; sym[high--] = static_cast<uint16_t>(s); }
      else cumul[s + 1] = cumul[s] + static_cast<uint32_t>(std::max(norm[s], 0));
    }
    size_t step = (size >> 1) + (size >> 3) + 3, mask = size - 1, pos = 0;
    for (size_t s = 0; s < norm.size(); s++)
      for (int i = 0; i < norm[s]; i++) { sym[pos] = static_cast<uint16_t>(s); do pos = (pos + step) & mask; while (pos > high); }
    stateTable.assign(size, 0);
    std::vector<uint32_t> c = cumul;
    for (size_t u = 0; u < size; u++) stateTable[c[sym[u]]++] = static_cast<uint16_t>(size + u);
    tt.assign(norm.size(), {0, 0});
    uint32_t total = 0;
    for (size_t s = 0; s < norm.size(); s++) {
      int n = norm[s];
      if (n == 0) { tt[s].deltaNbBits = ((al + 1) << 16) - (1u << al); continue; }
      if (n == -1 || n == 1) { tt[s].deltaNbBits = (al << 16) - (1u << al); tt[s].deltaFindState = static_cast<int32_t>(total) - 1; total++; }
      else {
        uint32_t maxBitsOut = al - highbit(static_cast<uint32_t>(n - 1));
        uint32_t minStatePlus = static_cast<uint32_t>(n) << maxBitsOut;
        tt[s].deltaNbBits = (maxBitsOut << 16) - minStatePlus;
        tt[s].deltaFindState = static_cast<int32_t>(total) - n;
        total += static_cast<uint32_t>(n);
      }
    }
  }
};

struct BitOut {
  std::string out;
  uint64_t acc = 0;
  int n = 0;
  void add(uint64_t v, int bits) {
    if (bits == 0) return;
    acc |= (v & ((bits == 64) ? ~0ull : ((1ull << bits) - 1))) << n;
    n += bits;
    while (n >= 8) { out.push_back(static_cast<char>(acc & 0xFF)); acc >>= 8; n -= 8; }
  }
  void close() { add(1, 1); if (n > 0) { out.push_back(static_cast<char>(acc & 0xFF)); acc = 0; n = 0; } }
};

struct EncState {
  uint32_t value;
  const FseEnc *t;
  void init(const FseEnc &e, uint32_t s) {
    t = &e;
    uint32_t nb = (e.tt[s].deltaNbBits + (1 << 15)) >> 16;
    value = (nb << 16) - e.tt[s].deltaNbBits;
    value = e.stateTable[(value >> nb) + e.tt[s].deltaFindState];
  }
  void encode(BitOut &b, uint32_t s) {
    uint32_t nb = (value + t->tt[s].deltaNbBits) >> 16;
    b.add(value, static_cast<int>(nb));
    value = t->stateTable[(value >> nb) + t->tt[s].deltaFindState];
  }
  void flush(BitOut &b) { b.add(value, t->al); }
};

uint32_t llCode(uint32_t ll) {
  static const uint8_t small[64] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21,
                                    22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24};
  return ll > 63 ? static_cast<uint32_t>(highbit(ll)) + 19 : small[ll];
}
uint32_t mlCode(uint32_t mlBase) { // mlBase = ml - 3
  static const uint8_t small[128] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
                                     32, 32, 33, 33, 34, 34, 35, 35, 36, 36, 36, 36, 37, 37, 37, 37, 38, 38, 38, 38, 38, 38, 38, 38, 39, 39, 39, 39, 39, 39, 39, 39,
                                     40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
                                     42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42};
  return mlBase > 127 ? static_cast<uint32_t>(highbit(mlBase)) + 36 : small[mlBase];
}

struct Seq { uint32_t ll, ml, ov; };

std::string encodeBlock(const std::string &in, size_t from, size_t to, const FseEnc &fll, const FseEnc &fof, const FseEnc &fml, int level) {
  // greedy LZ77 inside [from, to) with matches back into earlier data of the frame
  std::vector<Seq> seqs;
  std::string lits;
  static thread_local std::vector<int64_t> head;
  const int hbits = 16;
  if (head.size() != (size_t(1) << hbits)) head.assign(size_t(1) << hbits, -1);
  if (from == 0) std::fill(head.begin(), head.end(), -1);
  std::vector<int64_t> chain(to - from, -1);
  size_t i = from, anchor = from;
  const size_t window = size_t(1) << 22;
  int depth = level <= 1 ? 4 : level <= 5 ? 16 : 48;
  auto hashAt = [&](size_t p) { uint32_t v; std::memcpy(&v, in.data() + p, 4); return (v * 2654435761u) >> (32 - hbits); };
  while (i + 8 <= to) {
    uint32_t h = hashAt(i);
    int64_t cand = head[h];
    size_t bestLen = 0, bestOff = 0;
    for (int k = 0; k < depth && cand >= 0 && i - static_cast<size_t>(cand) <= window; k++) {
      size_t c = static_cast<size_t>(cand);
      if (std::memcmp(in.data() + c, in.data() + i, 4) == 0) {
        size_t m = 4;
        while (i + m < to && in[c + m] == in[i + m] && m < 65000) m++;
        if (m > bestLen) { bestLen = m; bestOff = i - c; }
      }
      cand = c >= from ? chain[c - from] : -1;
    }
    chain[i - from] = head[h];
    head[h] = static_cast<int64_t>(i);
    if (bestLen >= 4) {
      seqs.push_back({static_cast<uint32_t>(i - anchor), static_cast<uint32_t>(bestLen), static_cast<uint32_t>(bestOff + 3)});
      lits.append(in, anchor, i - anchor);
      for (size_t k = 1; k < bestLen && i + k + 4 <= to; k++) { uint32_t h2 = hashAt(i + k); chain[i + k - from] = head[h2]; head[h2] = static_cast<int64_t>(i + k); }
      i += bestLen;
      anchor = i;
    } else i++;
  }
  lits.append(in, anchor, to - anchor);
  std::string blk;
  // raw literals section, 20-bit size format
  size_t L = lits.size();
  blk.push_back(static_cast<char>(0 | (3 << 2) | ((L & 0xF) << 4)));
  blk.push_back(static_cast<char>((L >> 4) & 0xFF));
  blk.push_back(static_cast<char>((L >> 12) & 0xFF));
  blk += lits;
  size_t ns = seqs.size();
  if (ns < 128) blk.push_back(static_cast<char>(ns));
  else if (ns < 0x7F00) { blk.push_back(static_cast<char>((ns >> 8) + 128)); blk.push_back(static_cast<char>(ns & 0xFF)); }
  else { blk.push_back(static_cast<char>(255)); size_t v = ns - 0x7F00; blk.push_back(static_cast<char>(v & 0xFF)); blk.push_back(static_cast<char>(v >> 8)); }
  if (ns == 0) return blk;
  blk.push_back(0); // predefined tables for LL, OF, ML
  std::vector<uint32_t> lc(ns), oc(ns), mc(ns);
  for (size_t k = 0; k < ns; k++) { lc[k] = llCode(seqs[k].ll); mc[k] = mlCode(seqs[k].ml - 3); oc[k] = static_cast<uint32_t>(highbit(seqs[k].ov)); }
  BitOut bo;
  EncState sml, sof, sll;
  size_t last = ns - 1;
  sml.init(fml, mc[last]);
  sof.init(fof, oc[last]);
  sll.init(fll, lc[last]);
  bo.add(seqs[last].ll - LL_BASE[lc[last]], LL_BITS[lc[last]]);
  bo.add(seqs[last].ml - ML_BASE[mc[last]], ML_BITS[mc[last]]);
  bo.add(seqs[last].ov - (1u << oc[last]), static_cast<int>(oc[last]));
  for (size_t n = ns - 1; n-- > 0;) {
    sof.encode(bo, oc[n]);
    sml.encode(bo, mc[n]);
    sll.encode(bo, lc[n]);
    bo.add(seqs[n].ll - LL_BASE[lc[n]], LL_BITS[lc[n]]);
    bo.add(seqs[n].ml - ML_BASE[mc[n]], ML_BITS[mc[n]]);
    bo.add(seqs[n].ov - (1u << oc[n]), static_cast<int>(oc[n]));
  }
  sml.flush(bo);
  sof.flush(bo);
  sll.flush(bo);
  bo.close();
  blk += bo.out;
  return blk;
}

} // namespace

std::string zstdCompress(const std::string &in, int level) {
  static FseEnc fll, fof, fml;
  static bool ready = false;
  if (!ready) { fll.build(LL_DEFAULT, 6); fof.build(OF_DEFAULT, 5); fml.build(ML_DEFAULT, 6); ready = true; }
  std::string out;
  putLE(out, 0xFD2FB528u, 4);
  // single segment, 8-byte content size
  out.push_back(static_cast<char>((3 << 6) | (1 << 5)));
  putLE(out, in.size(), 8);
  const size_t B = 128 * 1024;
  if (in.empty()) { putLE(out, 1, 3); return out; } // last, raw, size 0
  for (size_t p = 0; p < in.size(); p += B) {
    size_t to = std::min(in.size(), p + B);
    bool last = to == in.size();
    std::string blk = encodeBlock(in, p, to, fll, fof, fml, level);
    if (blk.size() >= to - p) { // raw block
      putLE(out, (last ? 1 : 0) | (0 << 1) | ((to - p) << 3), 3);
      out.append(in, p, to - p);
    } else {
      putLE(out, (last ? 1 : 0) | (2 << 1) | (blk.size() << 3), 3);
      out += blk;
    }
  }
  return out;
}

bool zstdDecompress(const std::string &in, std::string &out, std::string &err) {
  out.clear();
  size_t p = 0;
  while (p + 4 <= in.size()) {
    uint32_t magic = u32le(in, p);
    if ((magic & 0xFFFFFFF0u) == 0x184D2A50u) { if (p + 8 > in.size()) break; p += 8 + u32le(in, p + 4); continue; }
    if (magic != 0xFD2FB528u) { err = "zstd: not a Zstandard frame"; return false; }
    p += 4;
    if (p >= in.size()) { err = "zstd: frame header cut short"; return false; }
    unsigned fhd = static_cast<unsigned char>(in[p++]);
    int fcsFlag = fhd >> 6;
    bool single = fhd & 0x20, checksum = fhd & 0x04;
    int didFlag = fhd & 3;
    if (!single) p++;
    p += didFlag == 0 ? 0 : didFlag == 1 ? 1 : didFlag == 2 ? 2 : 4;
    p += fcsFlag == 0 ? (single ? 1 : 0) : fcsFlag == 1 ? 2 : fcsFlag == 2 ? 4 : 8;
    if (didFlag) { err = "zstd: frames with a dictionary are not built in"; return false; }
    ZState st;
    size_t frameStart = out.size();
    for (;;) {
      if (p + 3 > in.size()) { err = "zstd: block header cut short"; return false; }
      uint32_t bh = static_cast<uint32_t>(getLE(in, p, 3));
      p += 3;
      bool last = bh & 1;
      int type = (bh >> 1) & 3;
      size_t size = bh >> 3;
      if (type == 0) { if (p + size > in.size()) { err = "zstd: raw block cut short"; return false; } out.append(in, p, size); p += size; }
      else if (type == 1) { if (p >= in.size()) { err = "zstd: RLE block cut short"; return false; } out.append(size, in[p]); p += 1; }
      else if (type == 2) {
        if (p + size > in.size()) { err = "zstd: block cut short"; return false; }
        if (!decodeBlock(in.data() + p, size, out, frameStart, st, err)) return false;
        p += size;
      } else { err = "zstd: reserved block type"; return false; }
      if (last) break;
    }
    if (checksum) p += 4;
  }
  return true;
}

// ---- by name --------------------------------------------------------------------------------

bool compressWith(const std::string &codec, int level, const std::string &in, std::string &out, std::string &err) {
  if (codec == "none" || codec == "uncompressed" || codec.empty()) { out = in; return true; }
  if (codec == "snappy") { out = snappyCompress(in); return true; }
  if (codec == "gzip") { out = gzipCompress(in, level < 0 ? 6 : std::min(level, 9)); return true; }
  if (codec == "zlib") { out = zlibCompress(in, level < 0 ? 6 : std::min(level, 9)); return true; }
  if (codec == "lz4") { out = lz4FrameCompress(in); return true; }
  if (codec == "lz4_raw") { out = lz4BlockCompress(in); return true; }
  if (codec == "zstd") { out = zstdCompress(in, level < 0 ? 3 : level); return true; }
  err = "codec '" + codec + "' is not built in (built in: none, snappy, gzip, lz4, zstd)";
  return false;
}

bool decompressWith(const std::string &codec, const std::string &in, size_t expected, std::string &out, std::string &err) {
  if (codec == "none" || codec == "uncompressed" || codec.empty()) { out = in; return true; }
  bool ok;
  if (codec == "snappy") ok = snappyDecompress(in, out, err);
  else if (codec == "gzip") ok = gzipDecompress(in, out, err);
  else if (codec == "zlib") ok = zlibDecompress(in, out, err);
  else if (codec == "lz4") {
    ok = lz4FrameDecompress(in, out, err);
    if (!ok) { std::string e2; ok = lz4HadoopDecompress(in, out, e2); }
    if (!ok) { out.clear(); std::string e3; ok = lz4BlockDecompress(in.data(), in.size(), out, expected, e3); }
  } else if (codec == "lz4_raw") { out.clear(); ok = lz4BlockDecompress(in.data(), in.size(), out, expected, err); }
  else if (codec == "zstd") ok = zstdDecompress(in, out, err);
  else { err = "codec '" + codec + "' is not built in (built in: snappy, gzip, lz4, zstd)"; return false; }
  if (ok && expected && out.size() != expected) { err = codec + ": expected " + std::to_string(expected) + " bytes, got " + std::to_string(out.size()); return false; }
  return ok;
}

} // namespace io
} // namespace nc
