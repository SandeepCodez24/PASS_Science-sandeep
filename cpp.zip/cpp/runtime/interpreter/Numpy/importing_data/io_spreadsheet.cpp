// CATEGORY 1 - Excel spreadsheets: read_/load_/save_ xlsx, xls, xlsm, xlsb.
#include <algorithm>
#include <cmath>

#include "../numpy_common.h"
#include "io_common.h"
#include "io_formats.h"
#include "io_ole2.h"
#include "io_sheet.h"

namespace nc {
namespace io {
namespace {

bool readWorkbook(const std::string &fmt, const std::string &file, const Value &pass, Workbook &wb, std::string &err) {
  if (given(pass)) {
    err = "password-protected workbooks (pass=) are not built in yet - save an unprotected copy";
    return false;
  }
  std::string bytes;
  if (!readSource(file, bytes, err))
    return false;
  if (isOle2(bytes) && fmt != "xls") {
    err = "this file is encrypted or an old .xls workbook (OLE2) - if it has a password, save an unprotected copy";
    return false;
  }
  if (fmt == "xls") return readXls(bytes, wb, err);
  if (fmt == "xlsb") return readXlsb(bytes, wb, err);
  return readXlsx(bytes, wb, err);
}

bool pickSheets(const Workbook &wb, const Value &sel, std::vector<size_t> &out, bool &many, std::string &err) {
  out.clear();
  many = false;
  if (!given(sel) || (numpy::isPlainNumber(sel) && sel.number <= 0)) {
    if (wb.sheets.empty()) {
      err = "the workbook has no sheets";
      return false;
    }
    out.push_back(wb.active);
    return true;
  }
  std::vector<Value> items;
  if (sel.isArray || sel.isMatrix) {
    many = true;
    if (sel.isArray) for (size_t i = 0; i < sel.length(); i++) items.push_back(sel.at(i));
    else for (size_t r = 0; r < sel.rows(); r++) for (size_t c = 0; c < sel.rowLength(r); c++) items.push_back(sel.at(r, c));
  } else {
    items.push_back(sel);
  }
  for (const Value &v : items) {
    if (numpy::isPlainNumber(v) && !v.isText) {
      size_t k = static_cast<size_t>(v.number);
      if (k < 1 || k > wb.sheets.size()) {
        err = "sheet " + std::to_string(k) + " does not exist (the workbook has " + std::to_string(wb.sheets.size()) + ")";
        return false;
      }
      out.push_back(k - 1);
      continue;
    }
    std::string want = optText(v);
    size_t found = SIZE_MAX;
    for (size_t k = 0; k < wb.sheets.size(); k++)
      if (wb.sheets[k].name == want || lower(wb.sheets[k].name) == lower(want)) found = k;
    if (found == SIZE_MAX) {
      std::string names;
      for (const auto &s : wb.sheets) names += (names.empty() ? "" : ", ") + s.name;
      err = "no sheet '" + want + "' (sheets: " + names + ")";
      return false;
    }
    out.push_back(found);
  }
  return true;
}

std::vector<std::string> sheetNames(const Workbook &wb) {
  std::vector<std::string> n;
  for (const auto &s : wb.sheets) n.push_back(s.name);
  return n;
}

// read_<fmt>(file, sheet, range, cols, rows, hdr, box, eval_fml, na, pass)
void readSheetFn(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out,
                 CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  const std::string fn = "read_" + fmt;
  EventScope ev(fn, file);
  Workbook wb;
  if (!readWorkbook(fmt, file, a[9], wb, err)) return ctx.fail(err);
  std::vector<size_t> picks;
  bool many = false;
  if (!pickSheets(wb, a[1], picks, many, err)) return ctx.fail(err);
  long long hdr = a[5].isBool() ? (a[5].number != 0 ? 1 : 0) : optInt(a[5], -1);
  std::vector<std::string> na = optTextList(a[8]);
  Fields byName;
  SheetTable first;
  for (size_t k = 0; k < picks.size(); k++) {
    SheetTable st;
    if (!sheetToTable(wb.sheets[picks[k]], optText(a[2], ""), hdr, optBool(a[7], true), na, st, err) ||
        !selectTable(st.table, a[3], a[4], err))
      return ctx.fail(err);
    if (k == 0) first = st;
    byName[wb.sheets[picks[k]].name] = tableData(st.table);
  }
  out.push_back(many ? Value(byName) : tableData(first.table));
  if (nout > 1) {
    Fields info;
    const Sheet &s = wb.sheets[picks[0]];
    info["cols"] = textList(first.table.cols);
    info["schema"] = tableSchema(first.table);
    info["boxes"] = optBool(a[6], true) ? textList(first.boxes) : textList({});
    info["sheet"] = Value(s.name);
    info["sheets"] = textList(sheetNames(wb));
    info["merged"] = textList(s.merged);
    info["origin"] = Value(addressOf(first.originRow, first.originCol));
    info["rows"] = Value(static_cast<double>(first.table.rows.size()));
    out.push_back(makeObject("NcReadInfo", std::move(info)));
  }
  ev.ok = true;
}

Value sheetObject(const Sheet &s, std::string &err) {
  SheetTable st;
  if (!sheetToTable(s, "", -1, true, {}, st, err)) return Value(0.0);
  // full grid of the used range, for D.ABC.cell("B4")
  Sheet ev = s;
  evaluateFormulas(ev);
  size_t r0 = 0, c0 = 0, r1 = 0, c1 = 0;
  std::vector<std::vector<Value>> grid;
  Fields formulas;
  std::vector<std::string> bold;
  if (ev.usedRange(r0, c0, r1, c1)) {
    for (size_t r = r0; r <= r1; r++) {
      std::vector<Value> row;
      for (size_t c = c0; c <= c1; c++) {
        auto it = ev.cells.find({r, c});
        row.push_back(it == ev.cells.end() || !it->second.hasValue ? Value(std::string()) : it->second.v);
      }
      grid.push_back(std::move(row));
    }
    for (const auto &kv : ev.cells) {
      if (!kv.second.fml.empty()) formulas[addressOf(kv.first.first, kv.first.second)] = Value("=" + kv.second.fml);
      if (kv.second.bold) bold.push_back(addressOf(kv.first.first, kv.first.second));
    }
  }
  std::vector<Value> boxes;
  for (const auto &b : s.boxes)
    boxes.push_back(makeObject("NcBox", {{"pos", Value(b.pos)}, {"text", Value(b.text)}, {"kind", Value(b.kind)}}));
  // cells outside the table block
  const size_t tr1 = st.originRow + st.headerRows + st.table.rows.size(); // one past the last row
  const size_t tc1 = st.originCol + st.table.cols.size();
  for (const auto &kv : ev.cells) {
    size_t r = kv.first.first, c = kv.first.second;
    if (r >= st.originRow && r < tr1 && c >= st.originCol && c < tc1) continue;
    boxes.push_back(makeObject("NcBox", {{"pos", Value(addressOf(r, c))},
                                         {"text", Value(cellText(kv.second.v))},
                                         {"kind", Value(std::string("cell"))}}));
  }
  return tableObject(st.table, {{"name", Value(s.name)},
                                {"boxes", Value(std::move(boxes))},
                                {"merged", textList(s.merged)},
                                {"charts", Value(static_cast<double>(s.charts))},
                                {"pivots", Value(static_cast<double>(s.pivots))},
                                {"freeze", Value(s.freeze)},
                                {"origin", Value(addressOf(st.originRow, st.originCol))},
                                {"grid", grid.empty() ? Value(std::vector<Value>{}) : Value(grid)},
                                {"grid_origin", Value(addressOf(r0, c0))},
                                {"formulas", Value(formulas)},
                                {"bold", textList(bold)}},
                     "NcSheet");
}

Value loadSheetFn(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  Workbook wb;
  if (!readWorkbook(fmt, file, a[1], wb, err)) {
    ctx.fail(err);
    return Value(0.0);
  }
  Fields f;
  for (size_t k = 0; k < wb.sheets.size(); k++) {
    Value so = sheetObject(wb.sheets[k], err);
    if (!err.empty()) {
      ctx.fail(err);
      return Value(0.0);
    }
    std::string n = fieldName(wb.sheets[k].name);
    if (!n.empty() && !f.count(n)) f[n] = so;
    if (k == wb.active) f["default"] = so;
    reportProgress("load_" + fmt, file, static_cast<double>(k + 1) / wb.sheets.size());
  }
  if (!f.count("default")) f["default"] = tableObject(Table(), {}, "NcSheet");
  f["sheets"] = textList(sheetNames(wb));
  f["meta"] = Value(wb.meta);
  f["file"] = Value(file);
  f["format"] = Value(fmt);
  if (fmt == "xlsm") {
    Fields mods;
    for (const auto &m : wb.vbaModules) mods[m.first] = Value(m.second);
    f["vba_macros"] = Value(mods);
    std::vector<std::string> names;
    for (const auto &m : wb.vbaModules) names.push_back(m.first);
    f["vba_modules"] = textList(names);
    std::vector<double> bytes;
    for (unsigned char c : wb.vbaProject) bytes.push_back(c);
    f["vba_project"] = numberList(bytes);
  }
  if (fmt == "xlsb") {
    std::vector<std::vector<Value>> m;
    for (const auto &b : wb.binBlocks) m.push_back({Value(b.first), Value(static_cast<double>(b.second))});
    f["bin_blocks"] = m.empty() ? Value(std::vector<Value>{}) : Value(m);
  }
  ev.ok = true;
  return makeObject("NcWorkbook", std::move(f));
}

Value sheetMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *names = field(a[0], "sheets");
  std::vector<std::string> list = names ? optTextList(*names) : std::vector<std::string>{};
  std::string want;
  if (numpy::isPlainNumber(a[1]) && !a[1].isText) {
    size_t k = static_cast<size_t>(a[1].number);
    if (k < 1 || k > list.size()) {
      ctx.fail("sheet " + std::to_string(k) + " does not exist (there are " + std::to_string(list.size()) + ")");
      return Value(0.0);
    }
    want = list[k - 1];
  } else {
    want = optText(a[1]);
  }
  for (const auto &n : list)
    if (n == want || lower(n) == lower(want))
      if (const Value *s = field(a[0], fieldName(n))) return *s;
  ctx.fail("no sheet '" + want + "'");
  return Value(0.0);
}

Value cellMethod(const std::vector<Value> &a, CallContext &ctx) {
  std::string addr;
  if (!numpy::argText(a, 1, ctx, addr)) return Value(0.0);
  size_t r, c, r0, c0;
  const Value *grid = field(a[0], "grid"), *origin = field(a[0], "grid_origin");
  if (!parseAddress(addr, r, c)) {
    ctx.fail("'" + addr + "' is not a cell address like \"B4\"");
    return Value(0.0);
  }
  Value val{std::string()};
  if (grid && origin && grid->isMatrix && parseAddress(optText(*origin), r0, c0) && r >= r0 && c >= c0 &&
      r - r0 < grid->rows() && c - c0 < grid->rowLength(r - r0))
    val = grid->at(r - r0, c - c0);
  std::string a1 = addressOf(r, c);
  Value fml{std::string()};
  if (const Value *fs = field(a[0], "formulas"))
    if (fs->isDict && fs->dict().count(a1)) fml = fs->dict().at(a1);
  bool bold = false;
  if (const Value *b = field(a[0], "bold"))
    for (const auto &x : optTextList(*b)) if (x == a1) bold = true;
  return makeObject("NcCell", {{"address", Value(a1)}, {"val", val}, {"fml", fml},
                               {"style", Value(Fields{{"bold", Value::boolean(bold)}})}});
}

bool validSheetName(const std::string &n, std::string &err) {
  if (n.empty() || n.size() > 31 || n.find_first_of("[]:*?/\\") != std::string::npos) {
    err = "sheet name '" + n + "' is not allowed (1-31 characters, none of [ ] : * ? / \\)";
    return false;
  }
  return true;
}

// Boxes: dict addr -> text, cell array of {pos, text} dicts, or a text list.
bool collectBoxes(const Value &v, Sheet &s, std::string &err) {
  if (!given(v)) return true;
  size_t r0 = 0, c0 = 0, r1 = 0, c1 = 0;
  bool any = s.usedRange(r0, c0, r1, c1);
  size_t freeRow = any ? r0 : 0, freeCol = any ? c1 + 2 : 0;
  auto add = [&](std::string pos, const std::string &text) {
    if (pos.empty()) pos = addressOf(freeRow++, freeCol);
    size_t r, c;
    if (!parseAddress(pos, r, c)) {
      err = "box position '" + pos + "' is not a cell address";
      return false;
    }
    s.boxes.push_back({addressOf(r, c), text, "comment"});
    return true;
  };
  if (v.isDict) {
    if (v.dict().count("pos") || v.dict().count("text"))
      return add(v.dict().count("pos") ? optText(v.dict().at("pos")) : "", v.dict().count("text") ? cellText(v.dict().at("text")) : "");
    for (const auto &kv : v.dict())
      if (!add(kv.first, cellText(kv.second))) return false;
    return true;
  }
  std::vector<Value> items;
  if (v.isArray) for (size_t i = 0; i < v.length(); i++) items.push_back(v.at(i));
  else if (v.isMatrix) for (size_t r = 0; r < v.rows(); r++) for (size_t c = 0; c < v.rowLength(r); c++) items.push_back(v.at(r, c));
  else items.push_back(v);
  for (const Value &it : items) {
    if (it.isDict || it.isObject) {
      const Value *p = field(it, "pos"), *t = field(it, "text");
      if (!add(p ? optText(*p) : "", t ? cellText(*t) : "")) return false;
    } else if (!add("", cellText(it))) {
      return false;
    }
  }
  return true;
}

void fitColumns(Sheet &s) {
  for (const auto &kv : s.cells) {
    size_t c = kv.first.second;
    size_t len = cellText(kv.second.v, "%.6g").size();
    if (s.colWidths.size() <= c) s.colWidths.resize(c + 1, 0);
    s.colWidths[c] = std::max(s.colWidths[c], std::min(60.0, std::max(8.43, len * 1.15 + 2)));
  }
}

bool tableSheet(const Value &v, const std::string &name, const std::string &start, Sheet &s, std::string &err) {
  if (!validSheetName(name, err)) return false;
  s = Sheet();
  s.name = name;
  if (isObjectOf(v, "NcSheet") || isObjectOf(v, "NcWorkbook")) {
    const Value *src = isObjectOf(v, "NcWorkbook") ? field(v, "default") : &v;
    Table t;
    if (!valueToTable(*src, t, err)) return false;
    tableToSheet(t, true, start, s);
    // keep formulas of a loaded sheet
    if (const Value *fs = field(*src, "formulas"))
      if (fs->isDict)
        for (const auto &kv : fs->dict()) {
          size_t r, c;
          if (parseAddress(kv.first, r, c)) {
            std::string f = optText(kv.second);
            s.cells[{r, c}].fml = f.rfind("=", 0) == 0 ? f.substr(1) : f;
            s.cells[{r, c}].hasValue = false;
          }
        }
    return true;
  }
  Table t;
  if (!valueToTable(v, t, err, true)) return false;
  bool generated = true;
  for (size_t i = 0; i < t.cols.size(); i++)
    if (t.cols[i] != "Col_" + std::to_string(i + 1)) generated = false;
  tableToSheet(t, !generated, start, s);
  return true;
}

// save_<fmt>(file, data, sheets, sheet, start, boxes, fml, freeze, fit_cols, compress, level, max_size, pass, mode[, macros])
Value saveSheetFn(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) {
    ctx.fail(m);
    return Value(0.0);
  };
  if (fmt == "xlsb")
    return fail("writing .xlsb is not built in - save as .xlsx (Excel opens both the same way)");
  if (given(a[12]))
    return fail("password protection (pass=) is not built in yet - the file would be saved unprotected");
  const std::string mode = lower(optText(a[13], "w"));
  if (mode != "w" && mode != "a") return fail("mode must be \"w\" (new file) or \"a\" (add sheets to the file)");
  Workbook wb;
  if (mode == "a" && fileExists(file)) {
    std::string bytes;
    if (!readFile(file, bytes, err) || !(fmt == "xls" ? readXls(bytes, wb, err) : readXlsx(bytes, wb, err)))
      return fail("cannot append to " + file + ": " + err);
  }
  auto putSheet = [&](Sheet s) {
    for (auto &old : wb.sheets)
      if (lower(old.name) == lower(s.name)) {
        old = std::move(s);
        return;
      }
    wb.sheets.push_back(std::move(s));
  };
  const std::string start = optText(a[4], "A1");
  size_t firstNew = wb.sheets.size();
  if (given(a[1])) {
    Sheet s;
    if (!tableSheet(a[1], optText(a[3], "Sheet1"), start, s, err)) return fail(err);
    putSheet(std::move(s));
  }
  if (given(a[2])) {
    if (!a[2].isDict) return fail("sheets must be a dict of name -> table (d = dict(); d[\"S1\"] = T1;)");
    std::vector<std::string> keys;
    for (const auto &kv : a[2].dict()) keys.push_back(kv.first);
    std::sort(keys.begin(), keys.end());
    for (const auto &k : keys) {
      Sheet s;
      if (!tableSheet(a[2].dict().at(k), k, start, s, err)) return fail(err);
      putSheet(std::move(s));
    }
  }
  if (wb.sheets.empty()) return fail("nothing to save - give data or sheets");
  Sheet &target = wb.sheets[std::min(firstNew, wb.sheets.size() - 1)];
  if (given(a[6])) {
    if (!a[6].isDict) return fail("fml must be a dict of cell -> formula, e.g. d[\"D2\"] = \"=B2*C2\"");
    for (const auto &kv : a[6].dict()) {
      size_t r, c;
      if (!parseAddress(kv.first, r, c)) return fail("fml: '" + kv.first + "' is not a cell address");
      std::string f = optText(kv.second);
      SheetCell cell;
      cell.fml = f.rfind("=", 0) == 0 ? f.substr(1) : f;
      cell.hasValue = false;
      target.cells[{r, c}] = cell;
    }
  }
  if (!collectBoxes(a[5], target, err)) return fail(err);
  if (given(a[7])) {
    size_t r, c;
    if (!parseAddress(optText(a[7]), r, c)) return fail("freeze must be a cell address like \"A2\"");
    target.freeze = optText(a[7]);
  }
  if (optBool(a[8], true))
    for (auto &s : wb.sheets) fitColumns(s);
  std::string bytes;
  if (fmt == "xls") {
    if (!writeXls(wb, bytes, err)) return fail(err);
  } else {
    if (fmt == "xlsm" && a.size() > 14 && given(a[14])) {
      const Value &m = a[14];
      if (isObjectOf(m, "NcWorkbook")) {
        const Value *vp = field(m, "vba_project");
        for (double d : optNumbers(vp ? *vp : Value(std::string()))) wb.vbaProject.push_back(static_cast<char>(static_cast<int>(d)));
      } else if (m.isText) {
        if (!readFile(m.text(), wb.vbaProject, err)) return fail("macros: " + err);
      } else {
        for (double d : optNumbers(m)) wb.vbaProject.push_back(static_cast<char>(static_cast<int>(d)));
      }
      if (!isOle2(wb.vbaProject)) return fail("macros must be a vbaProject.bin (OLE2): a file path, its bytes, or a loaded .xlsm");
    }
    std::string c = lower(optText(a[9], "yes"));
    int level = static_cast<int>(optInt(a[10], -1));
    if (c == "no" || c == "none" || c == "false") level = 0;
    else if (c != "yes" && c != "true" && c != "deflate" && c != "zip") return fail("compress must be \"yes\" or \"no\" for ." + fmt);
    bytes = writeXlsx(wb, fmt == "xlsm", level < 0 ? 6 : level);
  }
  if (!checkMaxSize(a[11], bytes.size(), err) || !writeFile(file, bytes, false, err)) return fail(err);
  emitEvent({"saved", "save_" + fmt, file, 1.0, formatBytes(bytes.size())});
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerSpreadsheets(Registry &reg) {
  for (const char *ext : {"xlsx", "xls", "xlsm", "xlsb"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e,
             "file, sheet=\"\", range=\"\", cols=\"\", rows=\"\", hdr=-1, box=true, eval_fml=true, na=\"\", pass=\"\"",
             "read a table from an Excel ." + e + " sheet (info boxes and comments returned beside it)",
             "pandas.read_excel", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
               readSheetFn(e, a, nout, out, ctx);
             });
    addFn(reg, "load_" + e, "file, pass=\"\"",
          "load an Excel ." + e + " workbook (D.sheets, D.ABC.cols, D.ABC.cell(\"B4\"), D.meta)", "openpyxl.load_workbook",
          [e](const std::vector<Value> &a, CallContext &ctx) { return loadSheetFn(e, a, ctx); });
    std::string params = "file, data=\"\", sheets=\"\", sheet=\"Sheet1\", start=\"A1\", boxes=\"\", fml=\"\", freeze=\"\", "
                         "fit_cols=true, compress=\"yes\", level=-1, max_size=\"\", pass=\"\", mode=\"w\"";
    if (e == "xlsm") params += ", macros=\"\"";
    addFn(reg, "save_" + e, params, "write tables (one or several sheets) to an Excel ." + e + " workbook",
          "pandas.DataFrame.to_excel",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveSheetFn(e, a, ctx); });
  }
  addFn(reg, "NcWorkbook.sheet", "D, name", "one sheet of a loaded workbook, by name or 1-based number",
        "openpyxl Workbook[name]", sheetMethod);
  addFn(reg, "NcSheet.cell", "S, address", "one cell (val, fml, style) of a loaded sheet, e.g. S.cell(\"B4\")",
        "openpyxl Worksheet[address]", cellMethod);
}

} // namespace io
} // namespace nc
