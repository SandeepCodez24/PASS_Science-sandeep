// PNG decoder / encoder (RFC 2083 / ISO 15948).
#include <algorithm>
#include <cmath>
#include <cstdlib>

#include "io_bytes.h"
#include "io_deflate.h"
#include "io_image.h"

namespace nc {
namespace io {

namespace {
int paeth(int a, int b, int c) {
  int p = a + b - c, pa = std::abs(p - a), pb = std::abs(p - b), pc = std::abs(p - c);
  return (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c);
}

void chunk(std::string &out, const char *type, const std::string &data) {
  putBE(out, data.size(), 4);
  std::string body = std::string(type, 4) + data;
  out += body;
  putBE(out, crc32(body.data(), body.size()), 4);
}
} // namespace

bool decodePng(const std::string &b, Image &img, std::string &err) {
  img = Image();
  if (b.size() < 8 || b.compare(0, 8, "\x89PNG\r\n\x1a\n") != 0) {
    err = "not a PNG file (signature missing)";
    return false;
  }
  size_t p = 8;
  int bitDepth = 0, colorType = 0, interlace = 0;
  std::string idat, palette, trns;
  while (p + 12 <= b.size()) {
    uint32_t len = u32be(b, p);
    std::string type = b.substr(p + 4, 4);
    if (p + 12 + len > b.size()) {
      err = "PNG chunk " + type + " runs past the end of the file";
      return false;
    }
    std::string d = b.substr(p + 8, len);
    if (type == "IHDR") {
      img.width = u32be(d, 0);
      img.height = u32be(d, 4);
      bitDepth = static_cast<unsigned char>(d[8]);
      colorType = static_cast<unsigned char>(d[9]);
      interlace = static_cast<unsigned char>(d[12]);
    } else if (type == "PLTE") palette = d;
    else if (type == "tRNS") trns = d;
    else if (type == "IDAT") idat += d;
    else if (type == "pHYs" && d.size() >= 9 && d[8] == 1) {
      img.dpiX = std::round(u32be(d, 0) * 0.0254);
      img.dpiY = std::round(u32be(d, 4) * 0.0254);
    } else if (type == "tEXt") {
      size_t z = d.find('\0');
      img.text.push_back({d.substr(0, z), z == std::string::npos ? "" : d.substr(z + 1)});
    } else if (type == "zTXt") {
      size_t z = d.find('\0');
      std::string txt, e2;
      if (z != std::string::npos && zlibDecompress(d.substr(z + 2), txt, e2)) img.text.push_back({d.substr(0, z), txt});
    } else if (type == "iTXt") {
      size_t z = d.find('\0');
      if (z != std::string::npos && z + 2 < d.size()) {
        bool comp = d[z + 1] != 0;
        size_t lang = d.find('\0', z + 3), tkey = lang == std::string::npos ? std::string::npos : d.find('\0', lang + 1);
        if (tkey != std::string::npos) {
          std::string txt = d.substr(tkey + 1), e2;
          if (comp) { std::string o; if (zlibDecompress(txt, o, e2)) txt = o; }
          img.text.push_back({d.substr(0, z), txt});
        }
      }
    } else if (type == "iCCP") {
      size_t z = d.find('\0');
      std::string prof, e2;
      if (z != std::string::npos && zlibDecompress(d.substr(z + 2), prof, e2)) img.icc = prof;
    } else if (type == "eXIf") {
      img.extra["exif_bytes"] = Value(static_cast<double>(d.size()));
    } else if (type == "IEND") break;
    p += 12 + len;
  }
  if (!img.width || !img.height || !bitDepth) {
    err = "PNG has no image header";
    return false;
  }
  std::string raw;
  if (!zlibDecompress(idat, raw, err)) {
    err = "PNG image data is damaged: " + err;
    return false;
  }
  int samples = colorType == 0 ? 1 : colorType == 2 ? 3 : colorType == 3 ? 1 : colorType == 4 ? 2 : 4;
  img.bitDepth = bitDepth == 16 ? 16 : 8;
  img.channels = colorType == 3 ? (trns.empty() ? 3 : 4) : static_cast<size_t>(samples);
  img.colorSpace = (colorType == 0 || colorType == 4) ? "Grayscale" : "sRGB";
  img.px.assign(img.width * img.height * img.channels, 0);
  const size_t bpp = std::max<size_t>(1, static_cast<size_t>(samples * bitDepth) / 8); // bytes per pixel for filtering
  size_t pos = 0;
  auto pass = [&](size_t x0, size_t y0, size_t dx, size_t dy) -> bool {
    if (x0 >= img.width || y0 >= img.height) return true;
    size_t pw = (img.width - x0 + dx - 1) / dx, ph = (img.height - y0 + dy - 1) / dy;
    size_t stride = (pw * samples * bitDepth + 7) / 8;
    std::vector<uint8_t> prev(stride, 0), cur(stride);
    for (size_t r = 0; r < ph; r++) {
      if (pos + 1 + stride > raw.size()) return false;
      int f = static_cast<unsigned char>(raw[pos++]);
      for (size_t k = 0; k < stride; k++) {
        int x = static_cast<unsigned char>(raw[pos + k]);
        int a = k >= bpp ? cur[k - bpp] : 0, up = prev[k], c = k >= bpp ? prev[k - bpp] : 0;
        switch (f) {
          case 1: x += a; break;
          case 2: x += up; break;
          case 3: x += (a + up) / 2; break;
          case 4: x += paeth(a, up, c); break;
        }
        cur[k] = static_cast<uint8_t>(x);
      }
      pos += stride;
      for (size_t c = 0; c < pw; c++) {
        size_t X = x0 + c * dx, Y = y0 + r * dy;
        double s[4] = {0, 0, 0, 0};
        for (int k = 0; k < samples; k++) {
          size_t bit = (c * samples + k) * bitDepth;
          if (bitDepth == 16) s[k] = (cur[bit / 8] << 8) | cur[bit / 8 + 1];
          else if (bitDepth == 8) s[k] = cur[bit / 8];
          else s[k] = (cur[bit / 8] >> (8 - bitDepth - bit % 8)) & ((1 << bitDepth) - 1);
        }
        double *d = &img.px[(Y * img.width + X) * img.channels];
        if (colorType == 3) {
          size_t i = static_cast<size_t>(s[0]);
          for (int k = 0; k < 3; k++) d[k] = 3 * i + k < palette.size() ? static_cast<unsigned char>(palette[3 * i + k]) : 0;
          if (img.channels == 4) d[3] = i < trns.size() ? static_cast<unsigned char>(trns[i]) : 255;
        } else {
          double scale = (bitDepth < 8) ? 255.0 / ((1 << bitDepth) - 1) : 1.0;
          for (int k = 0; k < samples; k++) d[k] = s[k] * scale;
        }
      }
      std::swap(prev, cur);
    }
    return true;
  };
  bool ok = true;
  if (interlace) {
    const size_t a7[7][4] = {{0, 0, 8, 8}, {4, 0, 8, 8}, {0, 4, 4, 8}, {2, 0, 4, 4}, {0, 2, 2, 4}, {1, 0, 2, 2}, {0, 1, 1, 2}};
    for (const auto &q : a7) ok = ok && pass(q[0], q[1], q[2], q[3]);
  } else {
    ok = pass(0, 0, 1, 1);
  }
  if (!ok) {
    err = "PNG image data ends early";
    return false;
  }
  // gray/RGB tRNS: one transparent colour -> add alpha
  if (!trns.empty() && (colorType == 0 || colorType == 2)) {
    Image o = img;
    o.channels = img.channels + 1;
    o.px.assign(img.width * img.height * o.channels, 0);
    double key[3] = {static_cast<double>(u16be(trns, 0)), colorType == 2 ? static_cast<double>(u16be(trns, 2)) : 0,
                     colorType == 2 ? static_cast<double>(u16be(trns, 4)) : 0};
    for (size_t i = 0; i < img.width * img.height; i++) {
      bool match = true;
      for (size_t k = 0; k < img.channels; k++) {
        o.px[i * o.channels + k] = img.px[i * img.channels + k];
        if (img.px[i * img.channels + k] != key[k]) match = false;
      }
      o.px[i * o.channels + img.channels] = match ? 0 : img.maxValue();
    }
    img = o;
  }
  return true;
}

std::string encodePng(const Image &imgIn, int level, bool usePalette, const std::vector<double> &transparent) {
  Image img = imgIn.isFloat ? to8bit(imgIn) : imgIn;
  const bool sixteen = img.bitDepth >= 16;
  std::string out("\x89PNG\r\n\x1a\n", 8);
  std::vector<uint8_t> indices;
  std::vector<std::array<uint8_t, 4>> pal;
  int colorType = img.channels == 1 ? 0 : img.channels == 2 ? 4 : img.channels == 3 ? 2 : 6;
  if (usePalette && !sixteen) {
    quantize(img, 256, indices, pal);
    colorType = 3;
  }
  std::string ihdr;
  putBE(ihdr, img.width, 4);
  putBE(ihdr, img.height, 4);
  ihdr.push_back(static_cast<char>(colorType == 3 ? 8 : sixteen ? 16 : 8));
  ihdr.push_back(static_cast<char>(colorType));
  ihdr += std::string("\0\0\0", 3);
  chunk(out, "IHDR", ihdr);
  if (img.dpiX > 0) {
    std::string phys;
    putBE(phys, static_cast<uint64_t>(std::llround(img.dpiX / 0.0254)), 4);
    putBE(phys, static_cast<uint64_t>(std::llround((img.dpiY > 0 ? img.dpiY : img.dpiX) / 0.0254)), 4);
    phys.push_back(1);
    chunk(out, "pHYs", phys);
  }
  for (const auto &t : img.text) {
    bool ascii = std::all_of(t.second.begin(), t.second.end(), [](char c) { return static_cast<unsigned char>(c) < 128; });
    if (ascii) chunk(out, "tEXt", t.first.substr(0, 79) + '\0' + t.second);
    else chunk(out, "iTXt", t.first.substr(0, 79) + std::string("\0\0\0\0\0", 5).substr(0, 5) + t.second);
  }
  if (colorType == 3) {
    std::string plte, trns;
    bool alpha = false;
    for (const auto &c : pal) {
      plte += static_cast<char>(c[0]);
      plte += static_cast<char>(c[1]);
      plte += static_cast<char>(c[2]);
      trns += static_cast<char>(c[3]);
      if (c[3] != 255) alpha = true;
    }
    if (transparent.size() >= 3)
      for (size_t k = 0; k < pal.size(); k++)
        if (pal[k][0] == transparent[0] && pal[k][1] == transparent[1] && pal[k][2] == transparent[2]) {
          trns[k] = 0;
          alpha = true;
        }
    chunk(out, "PLTE", plte);
    if (alpha) chunk(out, "tRNS", trns);
  } else if (transparent.size() >= 1 && (colorType == 0 || colorType == 2)) {
    std::string trns;
    for (size_t k = 0; k < (colorType == 0 ? 1u : 3u) && k < transparent.size(); k++) putBE(trns, static_cast<uint64_t>(transparent[k]), 2);
    chunk(out, "tRNS", trns);
  }
  const size_t samples = colorType == 3 ? 1 : img.channels;
  const size_t bps = colorType == 3 ? 1 : sixteen ? 2 : 1;
  const size_t stride = img.width * samples * bps, bpp = samples * bps;
  std::string raw;
  raw.reserve((stride + 1) * img.height);
  std::vector<uint8_t> prev(stride, 0), cur(stride), trial(stride), best(stride);
  for (size_t y = 0; y < img.height; y++) {
    for (size_t x = 0; x < img.width; x++) {
      if (colorType == 3) { cur[x] = indices[y * img.width + x]; continue; }
      for (size_t k = 0; k < samples; k++) {
        double v = std::clamp(std::round(img.px[(y * img.width + x) * img.channels + k]), 0.0, sixteen ? 65535.0 : 255.0);
        uint32_t u = static_cast<uint32_t>(v);
        size_t at = (x * samples + k) * bps;
        if (sixteen) { cur[at] = static_cast<uint8_t>(u >> 8); cur[at + 1] = static_cast<uint8_t>(u); }
        else cur[at] = static_cast<uint8_t>(u);
      }
    }
    // adaptive filter: smallest sum of |signed bytes|
    long bestSum = -1;
    int bestF = 0;
    for (int f = 0; f < 5; f++) {
      if (colorType == 3 && f != 0) break; // palette data: filter 0
      long sum = 0;
      for (size_t k = 0; k < stride; k++) {
        int a = k >= bpp ? cur[k - bpp] : 0, up = prev[k], c = k >= bpp ? prev[k - bpp] : 0, x = cur[k];
        int v = f == 0 ? x : f == 1 ? x - a : f == 2 ? x - up : f == 3 ? x - (a + up) / 2 : x - paeth(a, up, c);
        trial[k] = static_cast<uint8_t>(v);
        sum += std::abs(static_cast<int8_t>(trial[k]));
      }
      if (bestSum < 0 || sum < bestSum) { bestSum = sum; bestF = f; best = trial; }
    }
    raw.push_back(static_cast<char>(bestF));
    raw.append(reinterpret_cast<const char *>(best.data()), stride);
    prev = cur;
  }
  chunk(out, "IDAT", zlibCompress(raw, level));
  chunk(out, "IEND", "");
  return out;
}

} // namespace io
} // namespace nc
