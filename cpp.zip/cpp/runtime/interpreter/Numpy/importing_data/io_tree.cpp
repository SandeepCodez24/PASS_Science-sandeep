// Ordered document tree, JSON text, conversions and JSONPath - see io_tree.h.
#include "io_tree.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <functional>
#include <set>

#include "../numpy_common.h"

namespace nc {
namespace io {

const TreeNode *TreeNode::find(const std::string &key) const {
  for (const auto &kv : keys)
    if (kv.first == key)
      return &kv.second;
  return nullptr;
}

TreeNode *TreeNode::find(const std::string &key) {
  for (auto &kv : keys)
    if (kv.first == key)
      return &kv.second;
  return nullptr;
}

// ---- JSON parser ------------------------------------------------------------

namespace {

struct JsonParser {
  const std::string &s;
  size_t i = 0;
  bool lenient;
  std::string err;
  JsonParser(const std::string &text, bool len) : s(text), lenient(len) {}

  size_t lineOf(size_t at) const { return 1 + std::count(s.begin(), s.begin() + std::min(at, s.size()), '\n'); }
  bool fail(const std::string &m) {
    if (err.empty())
      err = m + " (line " + std::to_string(lineOf(i)) + ")";
    return false;
  }
  void skipWs() {
    for (;;) {
      while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i])))
        i++;
      if (lenient && i + 1 < s.size() && s[i] == '/' && s[i + 1] == '/') {
        while (i < s.size() && s[i] != '\n')
          i++;
        continue;
      }
      if (lenient && i + 1 < s.size() && s[i] == '/' && s[i + 1] == '*') {
        size_t e = s.find("*/", i + 2);
        i = e == std::string::npos ? s.size() : e + 2;
        continue;
      }
      if (lenient && i < s.size() && s[i] == '#') {
        while (i < s.size() && s[i] != '\n')
          i++;
        continue;
      }
      break;
    }
  }
  static void putUtf8(std::string &out, uint32_t cp) {
    if (cp < 0x80) {
      out.push_back(static_cast<char>(cp));
    } else if (cp < 0x800) {
      out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
      out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp < 0x10000) {
      out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
      out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
      out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
      out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
      out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
      out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
      out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
  }
  bool hex4(uint32_t &v) {
    if (i + 4 > s.size())
      return fail("bad \\u escape");
    v = 0;
    for (int k = 0; k < 4; k++) {
      char c = s[i++];
      v <<= 4;
      if (c >= '0' && c <= '9') v |= c - '0';
      else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10;
      else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10;
      else return fail("bad \\u escape");
    }
    return true;
  }
  bool string(std::string &out) {
    char q = s[i++];
    out.clear();
    while (i < s.size() && s[i] != q) {
      char c = s[i++];
      if (c != '\\') {
        out.push_back(c);
        continue;
      }
      if (i >= s.size())
        break;
      char e = s[i++];
      switch (e) {
        case 'n': out.push_back('\n'); break;
        case 't': out.push_back('\t'); break;
        case 'r': out.push_back('\r'); break;
        case 'b': out.push_back('\b'); break;
        case 'f': out.push_back('\f'); break;
        case '/': out.push_back('/'); break;
        case '\\': out.push_back('\\'); break;
        case '"': out.push_back('"'); break;
        case '\'': out.push_back('\''); break;
        case '\n': break; // JSON5 line continuation
        case 'u': {
          uint32_t cp = 0;
          if (!hex4(cp))
            return false;
          if (cp >= 0xD800 && cp < 0xDC00 && i + 1 < s.size() && s[i] == '\\' && s[i + 1] == 'u') {
            i += 2;
            uint32_t lo = 0;
            if (!hex4(lo))
              return false;
            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
          }
          putUtf8(out, cp);
          break;
        }
        default:
          if (!lenient)
            return fail(std::string("unknown escape \\") + e);
          out.push_back(e);
      }
    }
    if (i >= s.size())
      return fail("a text value is never closed");
    i++;
    return true;
  }
  bool value(TreeNode &n, int depth) {
    if (depth > 512)
      return fail("nesting is too deep");
    skipWs();
    if (i >= s.size())
      return fail("unexpected end of the document");
    char c = s[i];
    if (c == '{') {
      i++;
      n.type = TreeNode::Object;
      skipWs();
      if (i < s.size() && s[i] == '}') {
        i++;
        return true;
      }
      for (;;) {
        skipWs();
        std::string key;
        if (i < s.size() && (s[i] == '"' || (lenient && s[i] == '\''))) {
          if (!string(key))
            return false;
        } else if (lenient) {
          size_t b = i;
          while (i < s.size() && (std::isalnum(static_cast<unsigned char>(s[i])) || s[i] == '_' || s[i] == '$'))
            i++;
          if (i == b)
            return fail("expected a key");
          key = s.substr(b, i - b);
        } else {
          return fail("expected a \"key\"");
        }
        skipWs();
        if (i >= s.size() || s[i] != ':')
          return fail("expected ':' after key \"" + key + "\"");
        i++;
        TreeNode child;
        if (!value(child, depth + 1))
          return false;
        n.keys.emplace_back(key, std::move(child));
        skipWs();
        if (i < s.size() && s[i] == ',') {
          i++;
          skipWs();
          if (lenient && i < s.size() && s[i] == '}') {
            i++;
            return true;
          }
          continue;
        }
        if (i < s.size() && s[i] == '}') {
          i++;
          return true;
        }
        return fail("expected ',' or '}' in an object");
      }
    }
    if (c == '[') {
      i++;
      n.type = TreeNode::Array;
      skipWs();
      if (i < s.size() && s[i] == ']') {
        i++;
        return true;
      }
      for (;;) {
        TreeNode child;
        if (!value(child, depth + 1))
          return false;
        n.items.push_back(std::move(child));
        skipWs();
        if (i < s.size() && s[i] == ',') {
          i++;
          skipWs();
          if (lenient && i < s.size() && s[i] == ']') {
            i++;
            return true;
          }
          continue;
        }
        if (i < s.size() && s[i] == ']') {
          i++;
          return true;
        }
        return fail("expected ',' or ']' in an array");
      }
    }
    if (c == '"' || (lenient && c == '\'')) {
      n.type = TreeNode::String;
      return string(n.str);
    }
    auto word = [&](const char *w) {
      size_t len = std::char_traits<char>::length(w);
      if (s.compare(i, len, w) == 0) {
        i += len;
        return true;
      }
      return false;
    };
    if (word("true")) { n = TreeNode::ofBool(true); return true; }
    if (word("false")) { n = TreeNode::ofBool(false); return true; }
    if (word("null")) { n.type = TreeNode::Null; return true; }
    if (lenient) {
      if (word("NaN")) { n = TreeNode::ofNumber(std::nan("")); return true; }
      if (word("Infinity") || word("+Infinity")) { n = TreeNode::ofNumber(HUGE_VAL); return true; }
      if (word("-Infinity")) { n = TreeNode::ofNumber(-HUGE_VAL); return true; }
    }
    const char *b = s.c_str() + i;
    char *end = nullptr;
    double d;
    if (lenient && (s.compare(i, 2, "0x") == 0 || s.compare(i, 2, "0X") == 0))
      d = static_cast<double>(std::strtoll(b, &end, 16));
    else
      d = std::strtod(b, &end);
    if (end == b)
      return fail(std::string("unexpected '") + c + "'");
    i += static_cast<size_t>(end - b);
    n = TreeNode::ofNumber(d);
    return true;
  }
};

} // namespace

bool parseJson(const std::string &text, bool lenient, TreeNode &out, std::string &err) {
  JsonParser p(text, lenient);
  out = TreeNode();
  if (!p.value(out, 0)) {
    err = p.err;
    return false;
  }
  p.skipWs();
  if (p.i < text.size()) {
    p.fail("extra text after the JSON value");
    err = p.err;
    return false;
  }
  return true;
}

bool parseJsonLines(const std::string &text, bool lenient, TreeNode &out, std::string &err) {
  out = TreeNode();
  out.type = TreeNode::Array;
  size_t start = 0, line = 1;
  while (start <= text.size()) {
    size_t e = text.find('\n', start);
    if (e == std::string::npos)
      e = text.size();
    std::string l = trim(text.substr(start, e - start));
    if (!l.empty()) {
      TreeNode n;
      std::string e2;
      if (!parseJson(l, lenient, n, e2)) {
        err = "line " + std::to_string(line) + ": " + e2;
        return false;
      }
      out.items.push_back(std::move(n));
    }
    start = e + 1;
    line++;
  }
  return true;
}

// ---- JSON writer --------------------------------------------------------------

namespace {
void writeString(const std::string &s, std::string &out) {
  out.push_back('"');
  for (unsigned char c : s) {
    switch (c) {
      case '"': out += "\\\""; break;
      case '\\': out += "\\\\"; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      case '\b': out += "\\b"; break;
      case '\f': out += "\\f"; break;
      default:
        if (c < 0x20) {
          char buf[8];
          std::snprintf(buf, sizeof buf, "\\u%04x", c);
          out += buf;
        } else {
          out.push_back(static_cast<char>(c));
        }
    }
  }
  out.push_back('"');
}

void writeNode(const TreeNode &n, const JsonStyle &st, int depth, std::string &out) {
  const bool pretty = st.indent > 0;
  auto nl = [&](int d) {
    if (pretty) {
      out.push_back('\n');
      out.append(static_cast<size_t>(d * st.indent), ' ');
    }
  };
  switch (n.type) {
    case TreeNode::Null: out += "null"; break;
    case TreeNode::Bool: out += n.b ? "true" : "false"; break;
    case TreeNode::Number:
      if (!std::isfinite(n.num)) {
        if (st.nanMode == "str")
          writeString(numberText(n.num), out);
        else
          out += "null";
      } else {
        out += numberText(n.num);
      }
      break;
    case TreeNode::String: writeString(n.str, out); break;
    case TreeNode::Array: {
      if (n.items.empty()) {
        out += "[]";
        break;
      }
      // Short arrays of plain values stay on one line.
      bool flat = n.items.size() <= 16;
      for (const auto &c : n.items)
        if (c.type == TreeNode::Array || c.type == TreeNode::Object)
          flat = false;
      out.push_back('[');
      for (size_t k = 0; k < n.items.size(); k++) {
        if (k)
          out += pretty && flat ? ", " : ",";
        if (!flat)
          nl(depth + 1);
        writeNode(n.items[k], st, depth + 1, out);
      }
      if (!flat)
        nl(depth);
      out.push_back(']');
      break;
    }
    case TreeNode::Object: {
      if (n.keys.empty()) {
        out += "{}";
        break;
      }
      std::vector<const std::pair<std::string, TreeNode> *> order;
      for (const auto &kv : n.keys)
        order.push_back(&kv);
      if (st.sortKeys)
        std::stable_sort(order.begin(), order.end(),
                         [](auto *a, auto *b) { return a->first < b->first; });
      out.push_back('{');
      for (size_t k = 0; k < order.size(); k++) {
        if (k)
          out.push_back(',');
        nl(depth + 1);
        writeString(order[k]->first, out);
        out += pretty ? ": " : ":";
        writeNode(order[k]->second, st, depth + 1, out);
      }
      nl(depth);
      out.push_back('}');
      break;
    }
  }
}
} // namespace

std::string writeJson(const TreeNode &n, const JsonStyle &style) {
  std::string out;
  writeNode(n, style, 0, out);
  return out;
}

// ---- conversions --------------------------------------------------------------

namespace {
bool allNumbers(const TreeNode &n) {
  if (n.items.empty())
    return false;
  for (const auto &c : n.items)
    if (c.type != TreeNode::Number)
      return false;
  return true;
}

Value arrayToValue(const TreeNode &n, const std::string &cls, bool objects) {
  if (allNumbers(n)) {
    std::vector<double> v;
    for (const auto &c : n.items)
      v.push_back(c.num);
    return numpy::makeArray(v);
  }
  // [[1,2],[3,4]] -> matrix
  bool matrix = !n.items.empty();
  size_t width = 0;
  for (const auto &c : n.items) {
    if (c.type != TreeNode::Array || !allNumbers(c) || (width && c.items.size() != width)) {
      matrix = false;
      break;
    }
    width = c.items.size();
  }
  if (matrix) {
    std::vector<std::vector<double>> m;
    for (const auto &c : n.items) {
      std::vector<double> row;
      for (const auto &x : c.items)
        row.push_back(x.num);
      m.push_back(std::move(row));
    }
    return numpy::makeMatrix(m);
  }
  std::vector<Value> cells;
  for (const auto &c : n.items)
    cells.push_back(objects ? treeToObject(c, cls) : treeToValue(c));
  return Value(std::move(cells));
}
} // namespace

Value treeToValue(const TreeNode &n) {
  switch (n.type) {
    case TreeNode::Null: return Value(std::nan(""));
    case TreeNode::Bool: return Value::boolean(n.b);
    case TreeNode::Number: return Value(n.num);
    case TreeNode::String: return Value(n.str);
    case TreeNode::Array: return arrayToValue(n, "", false);
    case TreeNode::Object: {
      Fields f;
      for (const auto &kv : n.keys)
        f[kv.first] = treeToValue(kv.second);
      return Value(f);
    }
  }
  return Value(0.0);
}

Value treeToObject(const TreeNode &n, const std::string &cls) {
  if (n.type == TreeNode::Array)
    return arrayToValue(n, cls, true);
  if (n.type != TreeNode::Object)
    return treeToValue(n);
  Fields f;
  std::vector<std::string> order;
  for (const auto &kv : n.keys) {
    order.push_back(kv.first);
    std::string name = fieldName(kv.first);
    if (name.empty())
      name = "_";
    f[name] = treeToObject(kv.second, cls);
  }
  f["key_order"] = textList(order);
  return makeObject(cls, std::move(f));
}

TreeNode valueToTree(const Value &v) {
  TreeNode n;
  if (v.isObject) {
    if (field(v, "cols") && field(v, "data") && field(v, "rows")) {
      Table t;
      std::string err;
      if (valueToTable(v, t, err)) {
        n.type = TreeNode::Array;
        for (const auto &r : t.rows) {
          TreeNode rec;
          rec.type = TreeNode::Object;
          for (size_t c = 0; c < t.cols.size(); c++)
            rec.keys.emplace_back(t.cols[c], valueToTree(r[c]));
          n.items.push_back(std::move(rec));
        }
        return n;
      }
    }
    n.type = TreeNode::Object;
    const Value *order = field(v, "key_order");
    if (order) {
      for (const auto &raw : optTextList(*order)) {
        const Value *f = field(v, raw);
        if (!f)
          f = field(v, fieldName(raw).empty() ? "_" : fieldName(raw));
        if (f)
          n.keys.emplace_back(raw, valueToTree(*f));
      }
      return n;
    }
    std::vector<std::string> names;
    for (const auto &kv : v.dict())
      names.push_back(kv.first);
    std::sort(names.begin(), names.end());
    for (const auto &k : names)
      n.keys.emplace_back(k, valueToTree(v.dict().at(k)));
    return n;
  }
  if (v.isDict) {
    n.type = TreeNode::Object;
    std::vector<std::string> names;
    for (const auto &kv : v.dict())
      names.push_back(kv.first);
    std::sort(names.begin(), names.end());
    for (const auto &k : names)
      n.keys.emplace_back(k, valueToTree(v.dict().at(k)));
    return n;
  }
  if (v.isND()) {
    // Nested arrays, outermost dimension first. Storage is pages of
    // column-major rows x cols matrices, pages in row-major order of the
    // leading indices (value.h, NumTensor).
    const auto &shape = v.ndShape();
    const size_t rank = shape.size(), rows = shape[rank - 2], cols = shape[rank - 1];
    std::vector<size_t> idx(rank, 0);
    std::function<TreeNode(size_t)> build = [&](size_t dim) -> TreeNode {
      TreeNode a;
      a.type = TreeNode::Array;
      for (size_t k = 0; k < shape[dim]; k++) {
        idx[dim] = k;
        if (dim + 1 < rank) {
          a.items.push_back(build(dim + 1));
          continue;
        }
        size_t page = 0;
        for (size_t d = 0; d + 2 < rank; d++)
          page = page * shape[d] + idx[d];
        const size_t flat = page * rows * cols + idx[rank - 1] * rows + idx[rank - 2];
        a.items.push_back(valueToTree(v.ndAt(flat)));
      }
      return a;
    };
    return build(0);
  }
  if (v.isMatrix) {
    n.type = TreeNode::Array;
    if (v.rows() == 1) { // a 1xN matrix is a list
      for (size_t c = 0; c < v.rowLength(0); c++)
        n.items.push_back(valueToTree(v.at(0, c)));
      return n;
    }
    for (size_t r = 0; r < v.rows(); r++) {
      TreeNode row;
      row.type = TreeNode::Array;
      for (size_t c = 0; c < v.rowLength(r); c++)
        row.items.push_back(valueToTree(v.at(r, c)));
      n.items.push_back(std::move(row));
    }
    return n;
  }
  if (v.isArray) {
    n.type = TreeNode::Array;
    for (size_t i = 0; i < v.length(); i++)
      n.items.push_back(valueToTree(v.at(i)));
    return n;
  }
  if (v.isText)
    return TreeNode::ofString(v.text());
  if (v.isBool())
    return TreeNode::ofBool(v.number != 0);
  if (v.isTime())
    return TreeNode::ofString(cellText(v));
  return TreeNode::ofNumber(v.number);
}

bool treeToTable(const TreeNode &n, Table &t, std::string &err) {
  t = Table();
  if (n.type != TreeNode::Array) {
    err = "this is not a list of records";
    return false;
  }
  for (const auto &rec : n.items) {
    if (rec.type != TreeNode::Object) {
      err = "a table needs a list of objects ({\"a\": 1, ...})";
      return false;
    }
    for (const auto &kv : rec.keys)
      if (std::find(t.cols.begin(), t.cols.end(), kv.first) == t.cols.end())
        t.cols.push_back(kv.first);
  }
  for (const auto &rec : n.items) {
    std::vector<Value> row;
    for (const auto &c : t.cols) {
      const TreeNode *x = rec.find(c);
      if (!x || x->type == TreeNode::Null)
        row.push_back(Value(std::nan("")));
      else if (x->type == TreeNode::Array || x->type == TreeNode::Object)
        row.push_back(Value(writeJson(*x, JsonStyle{0, false, "null"})));
      else
        row.push_back(treeToValue(*x));
    }
    t.rows.push_back(std::move(row));
  }
  normalizeTable(t);
  return true;
}

// ---- JSONPath -----------------------------------------------------------------

namespace {

struct PathParser {
  const std::string &p;
  size_t i = 0;
  std::string err;
  explicit PathParser(const std::string &path) : p(path) {}
};

void collectRecursive(const TreeNode *n, std::vector<const TreeNode *> &out) {
  out.push_back(n);
  if (n->type == TreeNode::Array)
    for (const auto &c : n->items)
      collectRecursive(&c, out);
  else if (n->type == TreeNode::Object)
    for (const auto &kv : n->keys)
      collectRecursive(&kv.second, out);
}

void children(const TreeNode *n, std::vector<const TreeNode *> &out) {
  if (n->type == TreeNode::Array)
    for (const auto &c : n->items)
      out.push_back(&c);
  else if (n->type == TreeNode::Object)
    for (const auto &kv : n->keys)
      out.push_back(&kv.second);
}

// @.a.b relative to a node.
const TreeNode *relative(const TreeNode *n, const std::string &path) {
  std::string rest = path;
  if (rest.rfind("@", 0) == 0)
    rest = rest.substr(1);
  const TreeNode *cur = n;
  size_t k = 0;
  while (k < rest.size() && cur) {
    if (rest[k] == '.') {
      k++;
      size_t e = k;
      while (e < rest.size() && rest[e] != '.' && rest[e] != '[')
        e++;
      std::string key = rest.substr(k, e - k);
      cur = cur->type == TreeNode::Object ? cur->find(key) : nullptr;
      k = e;
    } else if (rest[k] == '[') {
      size_t e = rest.find(']', k);
      if (e == std::string::npos)
        return nullptr;
      std::string in = trim(rest.substr(k + 1, e - k - 1));
      if (!in.empty() && (in[0] == '\'' || in[0] == '"')) {
        cur = cur->type == TreeNode::Object ? cur->find(in.substr(1, in.size() - 2)) : nullptr;
      } else {
        long long idx = std::atoll(in.c_str());
        if (cur->type != TreeNode::Array)
          return nullptr;
        if (idx < 0)
          idx += static_cast<long long>(cur->items.size());
        cur = (idx >= 0 && idx < static_cast<long long>(cur->items.size())) ? &cur->items[static_cast<size_t>(idx)]
                                                                             : nullptr;
      }
      k = e + 1;
    } else {
      return nullptr;
    }
  }
  return cur;
}

bool compareNode(const TreeNode *x, const std::string &op, const std::string &litIn) {
  std::string lit = trim(litIn);
  if (!x)
    return false;
  if (!lit.empty() && (lit[0] == '\'' || lit[0] == '"')) {
    std::string s = lit.substr(1, lit.size() >= 2 ? lit.size() - 2 : 0);
    if (x->type != TreeNode::String)
      return op == "!=";
    if (op == "==") return x->str == s;
    if (op == "!=") return x->str != s;
    if (op == "<") return x->str < s;
    if (op == "<=") return x->str <= s;
    if (op == ">") return x->str > s;
    if (op == ">=") return x->str >= s;
    return false;
  }
  if (lit == "true" || lit == "false") {
    bool b = lit == "true";
    bool xv = x->type == TreeNode::Bool ? x->b : (x->type == TreeNode::Number && x->num != 0);
    return op == "==" ? xv == b : op == "!=" ? xv != b : false;
  }
  if (lit == "null")
    return op == "==" ? x->type == TreeNode::Null : x->type != TreeNode::Null;
  double d = std::strtod(lit.c_str(), nullptr);
  double xv = x->type == TreeNode::Number ? x->num : x->type == TreeNode::Bool ? (x->b ? 1 : 0) : std::nan("");
  if (std::isnan(xv))
    return op == "!=";
  if (op == "==") return xv == d;
  if (op == "!=") return xv != d;
  if (op == "<") return xv < d;
  if (op == "<=") return xv <= d;
  if (op == ">") return xv > d;
  if (op == ">=") return xv >= d;
  return false;
}

bool filterMatch(const TreeNode *n, const std::string &exprIn) {
  // a && b && c
  std::string expr = exprIn;
  size_t at;
  std::vector<std::string> parts;
  while ((at = expr.find("&&")) != std::string::npos) {
    parts.push_back(expr.substr(0, at));
    expr = expr.substr(at + 2);
  }
  parts.push_back(expr);
  for (const auto &partIn : parts) {
    std::string part = trim(partIn);
    static const char *ops[] = {"==", "!=", "<=", ">=", "<", ">"};
    bool done = false;
    for (const char *op : ops) {
      size_t o = part.find(op);
      if (o != std::string::npos) {
        if (!compareNode(relative(n, trim(part.substr(0, o))), op, part.substr(o + std::char_traits<char>::length(op))))
          return false;
        done = true;
        break;
      }
    }
    if (!done) {
      const TreeNode *x = relative(n, part);
      if (!x || x->type == TreeNode::Null || (x->type == TreeNode::Bool && !x->b))
        return false;
    }
  }
  return true;
}

} // namespace

bool jsonPath(const TreeNode &root, const std::string &pathIn, std::vector<const TreeNode *> &out,
              bool &single, std::string &err) {
  std::string path = trim(pathIn);
  out.clear();
  single = true;
  std::vector<const TreeNode *> cur{&root};
  size_t i = 0;
  if (!path.empty() && path[0] == '$')
    i = 1;
  else if (!path.empty() && path[0] != '.' && path[0] != '[')
    path = "." + path, i = 0; // "store.book" works like "$.store.book"
  while (i < path.size()) {
    std::vector<const TreeNode *> next;
    if (path.compare(i, 2, "..") == 0) {
      single = false;
      i += 2;
      std::vector<const TreeNode *> all;
      for (auto *n : cur)
        collectRecursive(n, all);
      // ..name / ..* / ..[...]
      cur = all;
      if (i < path.size() && path[i] == '[')
        continue;
      size_t e = i;
      while (e < path.size() && path[e] != '.' && path[e] != '[')
        e++;
      std::string key = path.substr(i, e - i);
      for (auto *n : cur) {
        if (key == "*")
          children(n, next);
        else if (n->type == TreeNode::Object)
          if (const TreeNode *c = n->find(key))
            next.push_back(c);
      }
      i = e;
    } else if (path[i] == '.') {
      i++;
      size_t e = i;
      while (e < path.size() && path[e] != '.' && path[e] != '[')
        e++;
      std::string key = path.substr(i, e - i);
      for (auto *n : cur) {
        if (key == "*") {
          single = false;
          children(n, next);
        } else if (n->type == TreeNode::Object) {
          if (const TreeNode *c = n->find(key))
            next.push_back(c);
        }
      }
      i = e;
    } else if (path[i] == '[') {
      // find the matching ']' (filters may hold brackets)
      int depth = 0;
      size_t e = i;
      for (; e < path.size(); e++) {
        if (path[e] == '[')
          depth++;
        else if (path[e] == ']' && --depth == 0)
          break;
      }
      if (e >= path.size()) {
        err = "JSONPath: '[' is never closed";
        return false;
      }
      std::string in = trim(path.substr(i + 1, e - i - 1));
      i = e + 1;
      if (in == "*") {
        single = false;
        for (auto *n : cur)
          children(n, next);
      } else if (in.rfind("?(", 0) == 0 && in.back() == ')') {
        single = false;
        std::string expr = in.substr(2, in.size() - 3);
        for (auto *n : cur) {
          std::vector<const TreeNode *> kids;
          children(n, kids);
          for (auto *k : kids)
            if (filterMatch(k, expr))
              next.push_back(k);
        }
      } else if (!in.empty() && (in[0] == '\'' || in[0] == '"')) {
        // ['a'] or ['a','b']
        size_t k = 0;
        std::vector<std::string> names;
        while (k < in.size()) {
          char q = in[k];
          size_t close = in.find(q, k + 1);
          if (close == std::string::npos)
            break;
          names.push_back(in.substr(k + 1, close - k - 1));
          k = in.find_first_of("'\"", close + 1);
          if (k == std::string::npos)
            break;
        }
        if (names.size() > 1)
          single = false;
        for (auto *n : cur)
          for (const auto &nm : names)
            if (n->type == TreeNode::Object)
              if (const TreeNode *c = n->find(nm))
                next.push_back(c);
      } else if (in.find(':') != std::string::npos) {
        single = false;
        size_t colon = in.find(':');
        std::string a = trim(in.substr(0, colon)), b = trim(in.substr(colon + 1));
        for (auto *n : cur) {
          if (n->type != TreeNode::Array)
            continue;
          long long sz = static_cast<long long>(n->items.size());
          long long s0 = a.empty() ? 0 : std::atoll(a.c_str());
          long long s1 = b.empty() ? sz : std::atoll(b.c_str());
          if (s0 < 0) s0 += sz;
          if (s1 < 0) s1 += sz;
          s0 = std::clamp(s0, 0LL, sz);
          s1 = std::clamp(s1, 0LL, sz);
          for (long long k = s0; k < s1; k++)
            next.push_back(&n->items[static_cast<size_t>(k)]);
        }
      } else {
        // [n] or [n,m]
        std::vector<long long> idx;
        size_t k = 0;
        while (k <= in.size()) {
          size_t c = in.find(',', k);
          if (c == std::string::npos)
            c = in.size();
          std::string part = trim(in.substr(k, c - k));
          if (!part.empty())
            idx.push_back(std::atoll(part.c_str()));
          k = c + 1;
        }
        if (idx.size() > 1)
          single = false;
        for (auto *n : cur) {
          if (n->type != TreeNode::Array)
            continue;
          for (long long x : idx) {
            long long j = x < 0 ? x + static_cast<long long>(n->items.size()) : x;
            if (j >= 0 && j < static_cast<long long>(n->items.size()))
              next.push_back(&n->items[static_cast<size_t>(j)]);
          }
        }
      }
    } else {
      err = "JSONPath: unexpected '" + std::string(1, path[i]) + "' at position " + std::to_string(i);
      return false;
    }
    cur = std::move(next);
  }
  out = std::move(cur);
  return true;
}

} // namespace io
} // namespace nc
