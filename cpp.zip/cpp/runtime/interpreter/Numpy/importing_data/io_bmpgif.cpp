// BMP (Windows bitmap) and GIF (87a/89a, animated) decoders / encoders.
#include <algorithm>
#include <cmath>
#include <map>

#include "io_bytes.h"
#include "io_image.h"

namespace nc {
namespace io {

// ---- BMP ----------------------------------------------------------------------

bool decodeBmp(const std::string &b, Image &img, std::string &err) {
  img = Image();
  if (b.size() < 54 || b[0] != 'B' || b[1] != 'M') {
    err = "not a BMP file";
    return false;
  }
  size_t dataOff = u32le(b, 10), hdr = u32le(b, 14);
  int32_t w, h;
  int bpp, comp = 0;
  if (hdr == 12) { w = u16le(b, 18); h = static_cast<int16_t>(u16le(b, 20)); bpp = u16le(b, 24); }
  else { w = static_cast<int32_t>(u32le(b, 18)); h = static_cast<int32_t>(u32le(b, 22)); bpp = u16le(b, 28); comp = static_cast<int>(u32le(b, 30)); }
  bool topDown = h < 0;
  img.width = static_cast<size_t>(std::abs(w));
  img.height = static_cast<size_t>(std::abs(h));
  if (hdr >= 40) {
    double ppm = u32le(b, 38);
    if (ppm > 0) { img.dpiX = std::round(ppm * 0.0254); img.dpiY = std::round(u32le(b, 42) * 0.0254); }
  }
  uint32_t masks[4] = {0x00FF0000, 0x0000FF00, 0x000000FF, 0};
  bool alpha = false;
  if (comp == 3 || comp == 6) {
    size_t mp = hdr >= 52 ? 54 : 14 + hdr;
    for (int k = 0; k < (comp == 6 || hdr >= 56 ? 4 : 3); k++) masks[k] = u32le(b, mp + 4 * static_cast<size_t>(k));
    alpha = masks[3] != 0;
  } else if (bpp == 16) {
    masks[0] = 0x7C00; masks[1] = 0x03E0; masks[2] = 0x001F;
  } else if (bpp == 32 && hdr >= 56) {
    alpha = true;
    masks[3] = 0xFF000000;
  }
  std::vector<std::array<uint8_t, 3>> pal;
  if (bpp <= 8) {
    size_t palOff = 14 + hdr, entry = hdr == 12 ? 3 : 4;
    size_t n = hdr >= 40 && u32le(b, 46) ? u32le(b, 46) : (1u << bpp);
    for (size_t k = 0; k < n && palOff + entry * k + 2 < b.size(); k++)
      pal.push_back({static_cast<uint8_t>(b[palOff + entry * k + 2]), static_cast<uint8_t>(b[palOff + entry * k + 1]),
                     static_cast<uint8_t>(b[palOff + entry * k])});
  }
  bool gray = !pal.empty() && std::all_of(pal.begin(), pal.end(), [](const std::array<uint8_t, 3> &c) { return c[0] == c[1] && c[1] == c[2]; });
  img.channels = gray ? 1 : alpha ? 4 : 3;
  img.colorSpace = gray ? "Grayscale" : "sRGB";
  img.px.assign(img.width * img.height * img.channels, 0);
  auto setPal = [&](size_t x, size_t y, size_t i) {
    if (x >= img.width || y >= img.height) return;
    size_t Y = topDown ? y : img.height - 1 - y;
    std::array<uint8_t, 3> c = i < pal.size() ? pal[i] : std::array<uint8_t, 3>{0, 0, 0};
    double *d = &img.px[(Y * img.width + x) * img.channels];
    if (gray) d[0] = c[0];
    else { d[0] = c[0]; d[1] = c[1]; d[2] = c[2]; if (alpha) d[3] = 255; }
  };
  if (comp == 1 || comp == 2) { // RLE8 / RLE4
    size_t p = dataOff, x = 0, y = 0;
    while (p + 1 < b.size() && y < img.height) {
      uint8_t n = static_cast<uint8_t>(b[p]), v = static_cast<uint8_t>(b[p + 1]);
      p += 2;
      if (n) {
        for (uint8_t k = 0; k < n; k++) setPal(x++, y, comp == 1 ? v : (k % 2 ? v & 15 : v >> 4));
      } else if (v == 0) { x = 0; y++; }
      else if (v == 1) break;
      else if (v == 2) { x += static_cast<uint8_t>(b[p]); y += static_cast<uint8_t>(b[p + 1]); p += 2; }
      else {
        for (uint8_t k = 0; k < v; k++) {
          uint8_t byte = static_cast<uint8_t>(b[p + (comp == 1 ? k : k / 2)]);
          setPal(x++, y, comp == 1 ? byte : (k % 2 ? byte & 15 : byte >> 4));
        }
        size_t used = comp == 1 ? v : (v + 1) / 2;
        p += used + (used % 2);
      }
    }
    return true;
  }
  size_t stride = ((img.width * static_cast<size_t>(bpp) + 31) / 32) * 4;
  for (size_t y = 0; y < img.height; y++) {
    size_t row = dataOff + y * stride;
    if (row + stride > b.size()) { err = "BMP pixel data ends early"; return false; }
    for (size_t x = 0; x < img.width; x++) {
      if (bpp <= 8) {
        size_t bit = x * static_cast<size_t>(bpp);
        size_t i = (static_cast<unsigned char>(b[row + bit / 8]) >> (8 - bpp - bit % 8)) & ((1 << bpp) - 1);
        setPal(x, y, i);
        continue;
      }
      size_t Y = topDown ? y : img.height - 1 - y;
      double *d = &img.px[(Y * img.width + x) * img.channels];
      if (bpp == 24) { d[0] = static_cast<uint8_t>(b[row + 3 * x + 2]); d[1] = static_cast<uint8_t>(b[row + 3 * x + 1]); d[2] = static_cast<uint8_t>(b[row + 3 * x]); continue; }
      uint32_t v = bpp == 16 ? u16le(b, row + 2 * x) : u32le(b, row + 4 * x);
      for (int k = 0; k < (alpha ? 4 : 3); k++) {
        uint32_t m = masks[k];
        if (!m) { d[k] = 255; continue; }
        int shift = 0;
        while (!((m >> shift) & 1)) shift++;
        uint32_t maxv = m >> shift;
        d[k] = std::round(((v & m) >> shift) * 255.0 / maxv);
      }
    }
  }
  return true;
}

std::string encodeBmp(const Image &imgIn) {
  Image img = to8bit(imgIn);
  if (img.channels == 2) img = convertChannels(img, "gray");
  const bool gray = img.channels == 1, alpha = img.channels == 4;
  const int bpp = gray ? 8 : alpha ? 32 : 24;
  const size_t stride = ((img.width * static_cast<size_t>(bpp) + 31) / 32) * 4;
  const size_t palSize = gray ? 1024 : 0, hdr = alpha ? 108 : 40;
  const size_t dataOff = 14 + hdr + palSize;
  std::string o = "BM";
  putLE(o, dataOff + stride * img.height, 4);
  putLE(o, 0, 4);
  putLE(o, dataOff, 4);
  putLE(o, hdr, 4);
  putLE(o, img.width, 4);
  putLE(o, img.height, 4);
  putLE(o, 1, 2);
  putLE(o, static_cast<uint64_t>(bpp), 2);
  putLE(o, alpha ? 3 : 0, 4);
  putLE(o, stride * img.height, 4);
  double dpi = img.dpiX > 0 ? img.dpiX : 96;
  putLE(o, static_cast<uint64_t>(std::llround(dpi / 0.0254)), 4);
  putLE(o, static_cast<uint64_t>(std::llround((img.dpiY > 0 ? img.dpiY : dpi) / 0.0254)), 4);
  putLE(o, gray ? 256 : 0, 4);
  putLE(o, 0, 4);
  if (alpha) {
    putLE(o, 0x00FF0000, 4); putLE(o, 0x0000FF00, 4); putLE(o, 0x000000FF, 4); putLE(o, 0xFF000000, 4);
    o += "BGRs";
    o.append(48, '\0');
  }
  if (gray)
    for (int k = 0; k < 256; k++) { o.push_back(static_cast<char>(k)); o.push_back(static_cast<char>(k)); o.push_back(static_cast<char>(k)); o.push_back(0); }
  for (size_t yy = 0; yy < img.height; yy++) {
    size_t y = img.height - 1 - yy;
    std::string row;
    for (size_t x = 0; x < img.width; x++) {
      if (gray) { row.push_back(static_cast<char>(img.at(x, y, 0))); continue; }
      row.push_back(static_cast<char>(img.at(x, y, 2)));
      row.push_back(static_cast<char>(img.at(x, y, 1)));
      row.push_back(static_cast<char>(img.at(x, y, 0)));
      if (alpha) row.push_back(static_cast<char>(img.at(x, y, 3)));
    }
    row.resize(stride, '\0');
    o += row;
  }
  return o;
}

// ---- GIF ----------------------------------------------------------------------

namespace {
bool gifLzwDecode(const std::string &data, int minCode, std::vector<uint8_t> &out, size_t expect) {
  int clear = 1 << minCode, eoi = clear + 1, width = minCode + 1;
  std::vector<std::vector<uint8_t>> dict;
  auto reset = [&]() {
    dict.assign(static_cast<size_t>(clear + 2), {});
    for (int k = 0; k < clear; k++) dict[static_cast<size_t>(k)] = {static_cast<uint8_t>(k)};
    width = minCode + 1;
  };
  reset();
  size_t bitPos = 0;
  std::vector<uint8_t> prev;
  bool havePrev = false;
  while (out.size() < expect) {
    if (bitPos + static_cast<size_t>(width) > data.size() * 8) break;
    int code = 0;
    for (int k = 0; k < width; k++, bitPos++) code |= ((static_cast<unsigned char>(data[bitPos / 8]) >> (bitPos % 8)) & 1) << k;
    if (code == clear) { reset(); havePrev = false; continue; }
    if (code == eoi) break;
    std::vector<uint8_t> entry;
    if (code < static_cast<int>(dict.size())) entry = dict[static_cast<size_t>(code)];
    else if (havePrev && code == static_cast<int>(dict.size())) { entry = prev; entry.push_back(prev[0]); }
    else return false;
    out.insert(out.end(), entry.begin(), entry.end());
    if (havePrev && dict.size() < 4096) {
      std::vector<uint8_t> ne = prev;
      ne.push_back(entry[0]);
      dict.push_back(ne);
      if (dict.size() == static_cast<size_t>(1 << width) && width < 12) width++;
    }
    prev = entry;
    havePrev = true;
  }
  return true;
}

std::string gifLzwEncode(const std::vector<uint8_t> &px, int minCode) {
  int clear = 1 << minCode, eoi = clear + 1;
  int width = minCode + 1, next = eoi + 1;
  std::string out;
  uint32_t buf = 0;
  int cnt = 0;
  auto put = [&](int code) {
    buf |= static_cast<uint32_t>(code) << cnt;
    cnt += width;
    while (cnt >= 8) { out.push_back(static_cast<char>(buf & 0xFF)); buf >>= 8; cnt -= 8; }
  };
  std::map<std::pair<int, uint8_t>, int> dict;
  put(clear);
  int w = -1;
  for (uint8_t c : px) {
    if (w < 0) { w = c; continue; }
    auto it = dict.find({w, c});
    if (it != dict.end()) { w = it->second; continue; }
    put(w);
    if (next < 4096) {
      dict[{w, c}] = next++;
      if (next > (1 << width) && width < 12) width++;
    } else {
      put(clear);
      dict.clear();
      next = eoi + 1;
      width = minCode + 1;
    }
    w = c;
  }
  if (w >= 0) put(w);
  put(eoi);
  if (cnt > 0) out.push_back(static_cast<char>(buf & 0xFF));
  return out;
}
} // namespace

bool decodeGif(const std::string &b, Image &img, std::string &err) {
  img = Image();
  if (b.size() < 13 || b.compare(0, 3, "GIF") != 0) {
    err = "not a GIF file";
    return false;
  }
  size_t W = u16le(b, 6), H = u16le(b, 8);
  uint8_t flags = static_cast<uint8_t>(b[10]);
  size_t p = 13;
  std::vector<std::array<uint8_t, 3>> gpal;
  if (flags & 0x80) {
    size_t n = 1u << ((flags & 7) + 1);
    for (size_t k = 0; k < n && p + 2 < b.size(); k++, p += 3)
      gpal.push_back({static_cast<uint8_t>(b[p]), static_cast<uint8_t>(b[p + 1]), static_cast<uint8_t>(b[p + 2])});
  }
  std::vector<double> canvas(W * H * 4, 0);
  std::vector<Image> frames;
  int transparent = -1, disposal = 0;
  double delay = 0;
  std::vector<std::pair<std::string, std::string>> text;
  while (p < b.size()) {
    uint8_t t = static_cast<uint8_t>(b[p++]);
    if (t == 0x3B) break;
    if (t == 0x21) {
      uint8_t label = static_cast<uint8_t>(b[p++]);
      std::string body;
      while (p < b.size()) {
        uint8_t n = static_cast<uint8_t>(b[p++]);
        if (!n) break;
        body.append(b, p, n);
        p += n;
      }
      if (label == 0xF9 && body.size() >= 4) {
        disposal = (static_cast<uint8_t>(body[0]) >> 2) & 7;
        delay = u16le(body, 1) / 100.0;
        transparent = (body[0] & 1) ? static_cast<uint8_t>(body[3]) : -1;
      } else if (label == 0xFE) {
        text.push_back({"Comment", body});
      }
      continue;
    }
    if (t != 0x2C) break;
    size_t x0 = u16le(b, p), y0 = u16le(b, p + 2), fw = u16le(b, p + 4), fh = u16le(b, p + 6);
    uint8_t lf = static_cast<uint8_t>(b[p + 8]);
    p += 9;
    std::vector<std::array<uint8_t, 3>> pal = gpal;
    if (lf & 0x80) {
      pal.clear();
      size_t n = 1u << ((lf & 7) + 1);
      for (size_t k = 0; k < n && p + 2 < b.size(); k++, p += 3)
        pal.push_back({static_cast<uint8_t>(b[p]), static_cast<uint8_t>(b[p + 1]), static_cast<uint8_t>(b[p + 2])});
    }
    int minCode = static_cast<uint8_t>(b[p++]);
    std::string data;
    while (p < b.size()) {
      uint8_t n = static_cast<uint8_t>(b[p++]);
      if (!n) break;
      data.append(b, p, n);
      p += n;
    }
    std::vector<uint8_t> idx;
    if (!gifLzwDecode(data, minCode, idx, fw * fh)) {
      err = "damaged GIF image data";
      return false;
    }
    idx.resize(fw * fh, 0);
    std::vector<double> before = canvas;
    bool interlaced = lf & 0x40;
    std::vector<size_t> rows;
    if (interlaced) {
      for (size_t r = 0; r < fh; r += 8) rows.push_back(r);
      for (size_t r = 4; r < fh; r += 8) rows.push_back(r);
      for (size_t r = 2; r < fh; r += 4) rows.push_back(r);
      for (size_t r = 1; r < fh; r += 2) rows.push_back(r);
    } else {
      for (size_t r = 0; r < fh; r++) rows.push_back(r);
    }
    for (size_t i = 0; i < fh; i++)
      for (size_t x = 0; x < fw; x++) {
        size_t X = x0 + x, Y = y0 + rows[i];
        if (X >= W || Y >= H) continue;
        int c = idx[i * fw + x];
        if (c == transparent) continue;
        double *d = &canvas[(Y * W + X) * 4];
        if (static_cast<size_t>(c) < pal.size()) { d[0] = pal[static_cast<size_t>(c)][0]; d[1] = pal[static_cast<size_t>(c)][1]; d[2] = pal[static_cast<size_t>(c)][2]; }
        d[3] = 255;
      }
    Image f;
    f.width = W;
    f.height = H;
    f.channels = 4;
    f.px = canvas;
    f.delay = delay;
    frames.push_back(std::move(f));
    if (disposal == 2)
      for (size_t y = y0; y < y0 + fh && y < H; y++)
        for (size_t x = x0; x < x0 + fw && x < W; x++)
          for (int k = 0; k < 4; k++) canvas[(y * W + x) * 4 + static_cast<size_t>(k)] = 0;
    else if (disposal == 3) canvas = before;
    transparent = -1;
    disposal = 0;
  }
  if (frames.empty()) {
    err = "GIF has no image";
    return false;
  }
  // no transparency anywhere -> RGB
  bool anyAlpha = false;
  for (const auto &f : frames)
    for (size_t i = 3; i < f.px.size(); i += 4) if (f.px[i] != 255) { anyAlpha = true; break; }
  for (auto &f : frames) if (!anyAlpha) f = convertChannels(f, "rgb");
  img = frames[0];
  img.text = text;
  img.delay = frames[0].delay;
  for (size_t k = 1; k < frames.size(); k++) img.frames.push_back(frames[k]);
  return true;
}

std::string encodeGif(const std::vector<const Image *> &frames, double fps, int loop, size_t maxColors) {
  if (frames.empty()) return "";
  const Image &f0 = *frames[0];
  std::string o = "GIF89a";
  putLE(o, f0.width, 2);
  putLE(o, f0.height, 2);
  o.push_back(0); // no global palette
  o.push_back(0);
  o.push_back(0);
  if (frames.size() > 1) {
    o += "\x21\xFF\x0BNETSCAPE2.0\x03\x01";
    putLE(o, static_cast<uint64_t>(loop), 2);
    o.push_back(0);
  }
  for (const auto &t : f0.text) {
    std::string c = (t.first == "Comment" ? "" : t.first + ": ") + t.second;
    o += "\x21\xFE";
    for (size_t p = 0; p < c.size(); p += 255) {
      size_t n = std::min<size_t>(255, c.size() - p);
      o.push_back(static_cast<char>(n));
      o.append(c, p, n);
    }
    o.push_back(0);
  }
  uint16_t delay = static_cast<uint16_t>(fps > 0 ? std::lround(100.0 / fps) : 0);
  for (const Image *fr : frames) {
    std::vector<uint8_t> idx;
    std::vector<std::array<uint8_t, 4>> pal;
    bool alpha = fr->channels == 2 || fr->channels == 4;
    quantize(*fr, alpha ? maxColors - 1 : maxColors, idx, pal);
    int trans = -1;
    if (alpha) {
      trans = static_cast<int>(pal.size());
      for (size_t i = 0; i < idx.size(); i++)
        if (pal[idx[i]][3] < 128) idx[i] = static_cast<uint8_t>(trans);
      pal.push_back({0, 0, 0, 0});
    }
    int bits = 1;
    while ((1u << bits) < pal.size()) bits++;
    o += "\x21\xF9\x04";
    o.push_back(static_cast<char>((trans >= 0 ? 1 : 0) | (frames.size() > 1 ? 0x08 : 0)));
    putLE(o, delay, 2);
    o.push_back(static_cast<char>(trans >= 0 ? trans : 0));
    o.push_back(0);
    o.push_back(',');
    putLE(o, 0, 2);
    putLE(o, 0, 2);
    putLE(o, fr->width, 2);
    putLE(o, fr->height, 2);
    o.push_back(static_cast<char>(0x80 | (bits - 1)));
    for (size_t k = 0; k < (1u << bits); k++) {
      std::array<uint8_t, 4> c = k < pal.size() ? pal[k] : std::array<uint8_t, 4>{0, 0, 0, 0};
      o.push_back(static_cast<char>(c[0]));
      o.push_back(static_cast<char>(c[1]));
      o.push_back(static_cast<char>(c[2]));
    }
    int minCode = std::max(2, bits);
    o.push_back(static_cast<char>(minCode));
    std::string data = gifLzwEncode(idx, minCode);
    for (size_t p = 0; p < data.size(); p += 255) {
      size_t n = std::min<size_t>(255, data.size() - p);
      o.push_back(static_cast<char>(n));
      o.append(data, p, n);
    }
    o.push_back(0);
  }
  o.push_back(';');
  return o;
}

} // namespace io
} // namespace nc
