// CATEGORY 18 - read_/load_/save_ tif, geotiff: georeferenced rasters on top
// of the TIFF codec (io_tiff.cpp): GeoKey directory, affine geotransform,
// GDAL NoData / metadata, bands / window / bbox / overview selection.
#include <algorithm>
#include <cmath>
#include <map>

#include "../numpy_common.h"
#include "io_formats.h"
#include "io_geo.h"
#include "io_image.h"

namespace nc {
namespace io {
namespace {

struct Geo {
  int epsg = 0, model = 0, raster = 1;
  double gt[6] = {0, 1, 0, 0, 0, 1}; // GDAL order: x0, dx, rx, y0, ry, dy
  bool hasGt = false, hasNodata = false;
  double nodata = 0;
  std::string citation, gdalMeta;
  Fields keys;
};

std::vector<double> nums(const Image &img, const char *key) {
  auto it = img.extra.find(key);
  return it == img.extra.end() ? std::vector<double>{} : optNumbers(it->second);
}

Geo geoOf(const Image &img) {
  Geo g;
  std::vector<double> scale = nums(img, "geo_pixel_scale"), tie = nums(img, "geo_tiepoint"), mt = nums(img, "geo_transform"), keys = nums(img, "geo_keys"),
                      dbl = nums(img, "geo_doubles");
  std::string ascii = img.extra.count("geo_ascii") ? img.extra.at("geo_ascii").text() : "";
  static const std::map<int, std::string> names = {{1024, "GTModelType"}, {1025, "GTRasterType"}, {1026, "GTCitation"}, {2048, "GeographicType"},
                                                  {2049, "GeogCitation"}, {2050, "GeogGeodeticDatum"}, {2054, "GeogAngularUnits"}, {3072, "ProjectedCSType"},
                                                  {3073, "PCSCitation"}, {3074, "Projection"}, {3075, "ProjCoordTrans"}, {3076, "ProjLinearUnits"}, {4096, "VerticalCSType"}};
  if (keys.size() >= 4) {
    size_t n = static_cast<size_t>(keys[3]);
    for (size_t k = 0; k < n && 4 + 4 * k + 3 < keys.size(); k++) {
      int id = static_cast<int>(keys[4 + 4 * k]), loc = static_cast<int>(keys[5 + 4 * k]), cnt = static_cast<int>(keys[6 + 4 * k]), val = static_cast<int>(keys[7 + 4 * k]);
      Value v;
      if (loc == 0) v = Value(static_cast<double>(val));
      else if (loc == 34736 && static_cast<size_t>(val + cnt) <= dbl.size()) v = cnt == 1 ? Value(dbl[val]) : numberList(std::vector<double>(dbl.begin() + val, dbl.begin() + val + cnt));
      else if (loc == 34737 && static_cast<size_t>(val) < ascii.size()) { std::string s = ascii.substr(val, cnt); while (!s.empty() && (s.back() == '|' || s.back() == '\0')) s.pop_back(); v = Value(s); }
      auto nm = names.find(id);
      g.keys[nm == names.end() ? "key_" + std::to_string(id) : nm->second] = v;
      if (id == 1024) g.model = val;
      if (id == 1025) g.raster = val;
      if ((id == 2048 || id == 3072) && loc == 0 && val > 0 && val < 32767) g.epsg = val;
      if (id == 1026 || id == 3073) g.citation = v.isText ? v.text() : "";
    }
  }
  if (mt.size() >= 16) { g.gt[0] = mt[3]; g.gt[1] = mt[0]; g.gt[2] = mt[1]; g.gt[3] = mt[7]; g.gt[4] = mt[4]; g.gt[5] = mt[5]; g.hasGt = true; }
  else if (scale.size() >= 2 && tie.size() >= 6) {
    g.gt[1] = scale[0]; g.gt[5] = -scale[1];
    g.gt[0] = tie[3] - tie[0] * scale[0];
    g.gt[3] = tie[4] + tie[1] * scale[1];
    g.hasGt = true;
  }
  if (g.hasGt && g.raster == 2) { g.gt[0] -= 0.5 * g.gt[1]; g.gt[3] -= 0.5 * g.gt[5]; } // PixelIsPoint, as GDAL reads it
  if (!g.epsg && !g.citation.empty()) g.epsg = crsEpsg(g.citation);
  if (img.extra.count("gdal_nodata")) {
    std::string t = trim(img.extra.at("gdal_nodata").text());
    g.hasNodata = !t.empty();
    g.nodata = lower(t) == "nan" ? std::nan("") : std::atof(t.c_str());
  }
  if (img.extra.count("gdal_metadata")) g.gdalMeta = img.extra.at("gdal_metadata").text();
  return g;
}

void pixelToWorld(const Geo &g, double col, double row, double &x, double &y) {
  x = g.gt[0] + col * g.gt[1] + row * g.gt[2];
  y = g.gt[3] + col * g.gt[4] + row * g.gt[5];
}

bool worldToPixel(const Geo &g, double x, double y, double &col, double &row) {
  double det = g.gt[1] * g.gt[5] - g.gt[2] * g.gt[4];
  if (det == 0) return false;
  double dx = x - g.gt[0], dy = y - g.gt[3];
  col = (g.gt[5] * dx - g.gt[2] * dy) / det;
  row = (-g.gt[4] * dx + g.gt[1] * dy) / det;
  return true;
}

// [w, s, e, n] in the raster CRS, and in lon / lat when it can be computed
void bounds(const Geo &g, const Image &img, std::vector<double> &native, std::vector<double> &geo) {
  double xs[4], ys[4];
  double cs[4][2] = {{0, 0}, {static_cast<double>(img.width), 0}, {0, static_cast<double>(img.height)}, {static_cast<double>(img.width), static_cast<double>(img.height)}};
  for (int k = 0; k < 4; k++) pixelToWorld(g, cs[k][0], cs[k][1], xs[k], ys[k]);
  native = {*std::min_element(xs, xs + 4), *std::min_element(ys, ys + 4), *std::max_element(xs, xs + 4), *std::max_element(ys, ys + 4)};
  geo = native;
  if (g.epsg && !crsGeographic(g.epsg)) {
    std::string err;
    double gx[4], gy[4];
    for (int k = 0; k < 4; k++) { gx[k] = xs[k]; gy[k] = ys[k]; if (!crsTransform(g.epsg, 4326, gx[k], gy[k], err)) { geo.clear(); return; } }
    geo = {*std::min_element(gx, gx + 4), *std::min_element(gy, gy + 4), *std::max_element(gx, gx + 4), *std::max_element(gy, gy + 4)};
  }
}

bool openRaster(const std::string &file, Image &img, Geo &g, std::string &err) {
  std::string bytes;
  if (!readSource(file, bytes, err)) return false;
  if (!decodeTiff(bytes, img, err, true)) return false;
  g = geoOf(img);
  return true;
}

// page `overview` (0 = full resolution) with its own scaled geotransform
bool pickOverview(const Image &img, const Geo &g, long long overview, Image &page, Geo &pg, std::string &err) {
  page = img;
  pg = g;
  if (overview <= 0) { page.frames.clear(); return true; }
  std::vector<const Image *> ovs;
  for (const auto &f : img.frames) { auto it = f.extra.find("subfile_type"); if (it != f.extra.end() && (static_cast<int>(it->second.number) & 1)) ovs.push_back(&f); }
  if (static_cast<size_t>(overview) > ovs.size()) { err = "overview " + std::to_string(overview) + " does not exist (the file has " + std::to_string(ovs.size()) + ")"; return false; }
  page = *ovs[static_cast<size_t>(overview - 1)];
  page.frames.clear();
  double fx = static_cast<double>(img.width) / page.width, fy = static_cast<double>(img.height) / page.height;
  pg.gt[1] *= fx; pg.gt[2] *= fy; pg.gt[4] *= fx; pg.gt[5] *= fy;
  return true;
}

// window [x, y, w, h] (0-based pixels) from window= or bbox=
bool windowOf(const Image &img, const Geo &g, const Value &window, const Value &bbox, size_t &x0, size_t &y0, size_t &w, size_t &h, std::string &err) {
  x0 = y0 = 0;
  w = img.width;
  h = img.height;
  if (given(window)) {
    std::vector<double> r = optNumbers(window);
    if (r.size() != 4 || r[0] < 0 || r[1] < 0 || r[2] < 1 || r[3] < 1 || r[0] + r[2] > img.width || r[1] + r[3] > img.height) {
      err = "window must be [x, y, w, h] inside the " + std::to_string(img.width) + " x " + std::to_string(img.height) + " raster";
      return false;
    }
    x0 = static_cast<size_t>(r[0]); y0 = static_cast<size_t>(r[1]); w = static_cast<size_t>(r[2]); h = static_cast<size_t>(r[3]);
  } else if (given(bbox)) {
    std::vector<double> b = optNumbers(bbox);
    if (b.size() != 4) { err = "bbox must be [west, south, east, north]"; return false; }
    if (!g.hasGt) { err = "the raster has no geotransform, so bbox= cannot be used (use window=)"; return false; }
    bool lonlat = std::fabs(b[0]) <= 180 && std::fabs(b[2]) <= 180 && std::fabs(b[1]) <= 90 && std::fabs(b[3]) <= 90;
    double xs[4] = {b[0], b[2], b[0], b[2]}, ys[4] = {b[1], b[1], b[3], b[3]};
    if (lonlat && g.epsg && !crsGeographic(g.epsg)) for (int k = 0; k < 4; k++) if (!crsTransform(4326, g.epsg, xs[k], ys[k], err)) return false;
    double c0 = INFINITY, c1 = -INFINITY, r0 = INFINITY, r1 = -INFINITY;
    for (int k = 0; k < 4; k++) { double c, r; worldToPixel(g, xs[k], ys[k], c, r); c0 = std::min(c0, c); c1 = std::max(c1, c); r0 = std::min(r0, r); r1 = std::max(r1, r); }
    long long a0 = std::max(0LL, static_cast<long long>(std::floor(c0))), a1 = std::min(static_cast<long long>(img.width), static_cast<long long>(std::ceil(c1)));
    long long b0 = std::max(0LL, static_cast<long long>(std::floor(r0))), b1 = std::min(static_cast<long long>(img.height), static_cast<long long>(std::ceil(r1)));
    if (a0 >= a1 || b0 >= b1) { err = "bbox does not overlap the raster"; return false; }
    x0 = static_cast<size_t>(a0); y0 = static_cast<size_t>(b0); w = static_cast<size_t>(a1 - a0); h = static_cast<size_t>(b1 - b0);
  }
  return true;
}

bool bandList(const Value &v, size_t count, std::vector<size_t> &out, std::string &err) {
  out.clear();
  if (!given(v)) { for (size_t b = 0; b < count; b++) out.push_back(b); return true; }
  for (double d : optNumbers(v)) {
    if (d < 1 || d > static_cast<double>(count) || d != std::floor(d)) { err = "band " + numberText(d) + " does not exist (bands are 1.." + std::to_string(count) + ")"; return false; }
    out.push_back(static_cast<size_t>(d) - 1);
  }
  return true;
}

Value rasterValue(const Image &img, const Geo &g, size_t x0, size_t y0, size_t w, size_t h, const std::vector<size_t> &bands, bool mask) {
  std::vector<double> vals;
  vals.reserve(w * h * bands.size());
  for (size_t y = y0; y < y0 + h; y++)
    for (size_t x = x0; x < x0 + w; x++)
      for (size_t b : bands) {
        double v = img.at(x, y, b);
        if (mask && g.hasNodata && (v == g.nodata || (std::isnan(g.nodata) && std::isnan(v)))) v = std::nan("");
        vals.push_back(v);
      }
  std::vector<size_t> shape = {h, w};
  if (bands.size() > 1) shape.push_back(bands.size());
  return ndFromRowMajor(shape, vals);
}

std::vector<std::string> boxesOf(const Geo &g) {
  std::vector<std::string> out;
  for (const auto &kv : g.keys) out.push_back(kv.first + ": " + cellText(kv.second));
  if (!g.gdalMeta.empty()) out.push_back("GDAL_METADATA: " + g.gdalMeta);
  return out;
}

Fields georef(const Image &img, const Geo &g) {
  Fields f;
  f["crs"] = Value(g.epsg ? "EPSG:" + std::to_string(g.epsg) : std::string());
  f["epsg"] = Value(static_cast<double>(g.epsg));
  f["crs_name"] = Value(crsName(g.epsg));
  f["wkt"] = Value(crsWkt(g.epsg));
  f["transform"] = numberList({g.gt[0], g.gt[1], g.gt[2], g.gt[3], g.gt[4], g.gt[5]});
  std::vector<double> nat, geo;
  bounds(g, img, nat, geo);
  f["bounds"] = numberList(geo.empty() ? nat : geo);
  f["bounds_native"] = numberList(nat);
  f["res"] = numberList({std::hypot(g.gt[1], g.gt[4]), std::hypot(g.gt[2], g.gt[5])});
  f["nodata"] = Value(g.hasNodata ? g.nodata : std::nan(""));
  f["width"] = Value(static_cast<double>(img.width));
  f["height"] = Value(static_cast<double>(img.height));
  f["count"] = Value(static_cast<double>(img.channels));
  f["dtype"] = Value(img.isFloat ? "float32" : img.bitDepth >= 32 ? "uint32" : img.bitDepth >= 16 ? "uint16" : "uint8");
  f["georeferenced"] = Value::boolean(g.hasGt);
  f["tags"] = Value(g.keys);
  f["boxes"] = textList(boxesOf(g));
  return f;
}

// read_<fmt>(file, bands, bbox, window, overview, mask_nodata, box)
void readGeo(const std::string &fmt, const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return;
  EventScope ev("read_" + fmt, file);
  Image img, page;
  Geo g, pg;
  if (!openRaster(file, img, g, err)) return ctx.fail(err);
  if (!pickOverview(img, g, optInt(a[4], 0), page, pg, err)) return ctx.fail(err);
  std::vector<size_t> bands;
  if (!bandList(a[1], page.channels, bands, err)) return ctx.fail(err);
  size_t x0, y0, w, h;
  if (!windowOf(page, pg, a[3], a[2], x0, y0, w, h, err)) return ctx.fail(err);
  out.push_back(rasterValue(page, pg, x0, y0, w, h, bands, optBool(a[5], true)));
  if (nout > 1) {
    Geo wg = pg; // geotransform of the window
    pixelToWorld(pg, static_cast<double>(x0), static_cast<double>(y0), wg.gt[0], wg.gt[3]);
    Image shape = page;
    shape.width = w;
    shape.height = h;
    Fields f = georef(shape, wg);
    f["window"] = numberList({static_cast<double>(x0), static_cast<double>(y0), static_cast<double>(w), static_cast<double>(h)});
    std::vector<double> b1;
    for (size_t b : bands) b1.push_back(static_cast<double>(b + 1));
    f["bands"] = numberList(b1);
    if (!optBool(a[6], true)) f["boxes"] = textList({});
    out.push_back(makeObject("NcReadInfo", f));
  }
  ev.ok = true;
}

Value loadGeo(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("load_" + fmt, file);
  Image img;
  Geo g;
  if (!openRaster(file, img, g, err)) { ctx.fail(err); return Value(0.0); }
  Fields f = georef(img, g);
  std::vector<size_t> all;
  for (size_t b = 0; b < img.channels; b++) all.push_back(b);
  f["raster"] = rasterValue(img, g, 0, 0, img.width, img.height, all, true);
  std::vector<Value> bands;
  for (size_t b = 0; b < img.channels; b++) bands.push_back(rasterValue(img, g, 0, 0, img.width, img.height, {b}, true));
  f["bands"] = Value(std::move(bands));
  std::vector<Value> ovs;
  for (const auto &fr : img.frames) {
    auto it = fr.extra.find("subfile_type");
    if (it != fr.extra.end() && (static_cast<int>(it->second.number) & 1)) ovs.push_back(numberList({static_cast<double>(fr.width), static_cast<double>(fr.height)}));
  }
  f["overviews"] = Value(std::move(ovs));
  f["file"] = Value(file);
  f["format"] = Value(fmt);
  ev.ok = true;
  return makeObject("NcGeoRaster", f);
}

// D.sample(lon, lat): band values at a geographic point (or in the raster CRS when it is not lon / lat)
Value sampleMethod(const std::vector<Value> &a, CallContext &ctx) {
  const Value *tf = field(a[0], "transform"), *ep = field(a[0], "epsg"), *ras = field(a[0], "raster"), *w = field(a[0], "width"), *h = field(a[0], "height");
  if (!tf || !ras || !w || !h) { ctx.fail("sample() needs a raster of load_tif(...)"); return Value(0.0); }
  Geo g;
  std::vector<double> t = optNumbers(*tf);
  for (int k = 0; k < 6 && k < static_cast<int>(t.size()); k++) g.gt[k] = t[static_cast<size_t>(k)];
  g.epsg = ep ? static_cast<int>(ep->number) : 0;
  double x = optNumber(a[1], 0), y = optNumber(a[2], 0);
  std::string err;
  bool lonlat = std::fabs(x) <= 180 && std::fabs(y) <= 90;
  if (lonlat && g.epsg && !crsGeographic(g.epsg) && !crsTransform(4326, g.epsg, x, y, err)) { ctx.fail(err); return Value(0.0); }
  double col, row;
  worldToPixel(g, x, y, col, row);
  long long c = static_cast<long long>(std::floor(col)), r = static_cast<long long>(std::floor(row));
  if (c < 0 || r < 0 || c >= static_cast<long long>(w->number) || r >= static_cast<long long>(h->number)) { ctx.fail("the point is outside the raster"); return Value(0.0); }
  std::vector<size_t> shape;
  std::vector<double> vals;
  ndToRowMajor(*ras, shape, vals);
  size_t bands = shape.size() == 3 ? shape[2] : 1;
  std::vector<double> out;
  for (size_t b = 0; b < bands; b++) out.push_back(vals[(static_cast<size_t>(r) * shape[1] + static_cast<size_t>(c)) * bands + b]);
  return out.size() == 1 ? Value(out[0]) : numberList(out);
}

// save_<fmt>(file, raster, crs, transform, bbox, nodata, cog, tile, compress, bigtiff, boxes)
Value saveGeo(const std::string &fmt, const std::vector<Value> &a, CallContext &ctx) {
  std::string file, err;
  if (!numpy::argText(a, 0, ctx, file)) return Value(0.0);
  EventScope ev("save_" + fmt, file);
  auto fail = [&](const std::string &m) { ctx.fail(m); return Value(0.0); };
  const Value *src = &a[1];
  if (isObjectOf(*src, "NcGeoRaster")) src = field(*src, "raster");
  std::vector<size_t> shape;
  std::vector<double> vals;
  if (!src || !ndToRowMajor(*src, shape, vals) || shape.size() < 2 || shape.size() > 3) return fail("raster must be an (H, W) or (H, W, bands) array");
  size_t H = shape[0], W = shape[1], B = shape.size() == 3 ? shape[2] : 1;
  // georeference
  double gt[6];
  bool have = false;
  if (given(a[3])) {
    std::vector<double> t = optNumbers(a[3]);
    if (t.size() != 6) return fail("transform must have 6 numbers [x0, dx, rx, y0, ry, dy] (GDAL order)");
    std::copy(t.begin(), t.end(), gt);
    have = true;
  } else if (given(a[4])) {
    std::vector<double> b = optNumbers(a[4]);
    if (b.size() != 4 || b[2] <= b[0] || b[3] <= b[1]) return fail("bbox must be [west, south, east, north] with east > west and north > south");
    gt[0] = b[0]; gt[1] = (b[2] - b[0]) / W; gt[2] = 0; gt[3] = b[3]; gt[4] = 0; gt[5] = -(b[3] - b[1]) / H;
    have = true;
  } else if (isObjectOf(a[1], "NcGeoRaster")) {
    std::vector<double> t = optNumbers(*field(a[1], "transform"));
    std::copy(t.begin(), t.end(), gt);
    have = true;
  }
  if (!have) return fail("give transform= or bbox= to place the raster on the map");
  std::string crsText = optText(a[2], "EPSG:4326");
  int epsg = crsEpsg(crsText);
  if (!epsg) return fail("crs \"" + crsText + "\" names no EPSG code - give e.g. \"EPSG:4326\" or \"EPSG:32644\"");
  bool geographic = crsGeographic(epsg) || (epsg >= 4000 && epsg < 5000);
  // data type
  bool hasNodata = given(a[5]) && !std::isnan(optNumber(a[5], std::nan("")));
  double nodata = optNumber(a[5], 0);
  bool ints = true, nonneg = true;
  double mx = 0;
  for (double v : vals) {
    if (std::isnan(v)) { if (!hasNodata) ints = false; continue; }
    if (v != std::floor(v)) ints = false;
    if (v < 0) nonneg = false;
    mx = std::max(mx, v);
  }
  if (hasNodata && (nodata < 0 || nodata != std::floor(nodata))) ints = false;
  if (hasNodata) mx = std::max(mx, nodata);
  Image img;
  img.width = W;
  img.height = H;
  img.channels = B;
  img.isFloat = !(ints && nonneg && mx <= 65535);
  img.bitDepth = img.isFloat ? 32 : mx <= 255 ? 8 : 16;
  img.px = vals;
  if (hasNodata) for (double &v : img.px) if (std::isnan(v)) v = nodata;
  bool rotated = gt[2] != 0 || gt[4] != 0;
  if (rotated) img.extra["geo_transform"] = numberList({gt[1], gt[2], 0, gt[0], gt[4], gt[5], 0, gt[3], 0, 0, 0, 0, 0, 0, 0, 1});
  else {
    img.extra["geo_pixel_scale"] = numberList({gt[1], -gt[5], 0});
    img.extra["geo_tiepoint"] = numberList({0, 0, 0, gt[0], gt[3], 0});
  }
  img.extra["geo_keys"] = numberList({1, 1, 0, 3, 1024, 0, 1, geographic ? 2.0 : 1.0, 1025, 0, 1, 1, geographic ? 2048.0 : 3072.0, 0, 1, static_cast<double>(epsg)});
  if (hasNodata) img.extra["gdal_nodata"] = Value(numberText(nodata));
  if (given(a[10])) {
    std::string x = "<GDALMetadata>\n";
    if (a[10].isDict) {
      std::vector<std::string> keys;
      for (const auto &kv : a[10].dict()) keys.push_back(kv.first);
      std::sort(keys.begin(), keys.end());
      for (const auto &k : keys) x += "  <Item name=\"" + k + "\">" + cellText(a[10].dict().at(k)) + "</Item>\n";
    } else for (const auto &bx : optTextList(a[10])) x += "  <Item name=\"note\">" + bx + "</Item>\n";
    img.extra["gdal_metadata"] = Value(x + "</GDALMetadata>");
  }
  TiffOptions opt;
  opt.codec = lower(optText(a[8], "deflate"));
  if (opt.codec == "zlib" || opt.codec == "gzip") opt.codec = "deflate";
  if (opt.codec != "deflate" && opt.codec != "lzw" && opt.codec != "zstd" && opt.codec != "none" && opt.codec != "packbits") return fail("compress must be \"deflate\", \"lzw\", \"zstd\" or \"none\"");
  std::vector<double> tile = optNumbers(a[7]);
  opt.tile = tile.empty() ? 256 : static_cast<size_t>(tile[0]); // square tiles: the first size is used
  if (opt.tile && opt.tile % 16) return fail("tile sizes must be multiples of 16");
  opt.overviews = optBool(a[6], false);
  if (opt.overviews && !opt.tile) opt.tile = 256;
  std::string big = lower(optText(a[9], "auto"));
  double estimate = static_cast<double>(W) * H * B * (img.bitDepth / 8.0);
  opt.bigtiff = big == "true" || big == "yes" || (big == "auto" && estimate > 3.9e9);
  std::string bytes = encodeTiff({&img}, opt);
  if (!writeFile(file, bytes, false, err)) return fail(err);
  ev.ok = true;
  return Value(static_cast<double>(bytes.size()));
}

} // namespace

void registerGeoTiff(Registry &reg) {
  for (const char *ext : {"tif", "geotiff"}) {
    const std::string e = ext;
    addMulti(reg, "read_" + e, "file, bands=\"\", bbox=\"\", window=\"\", overview=0, mask_nodata=true, box=true",
             "read a georeferenced raster (H, W, bands) with NoData as NaN; bands are 1-based, window = [x, y, w, h] pixels", "rasterio.open(...).read", 2,
             [e](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) { readGeo(e, a, nout, out, ctx); });
    addFn(reg, "load_" + e, "file", "load a GeoTIFF (D.raster, D.bands, D.crs, D.transform, D.bounds, D.res, D.nodata, D.sample(lon, lat))",
          "rasterio.open", [e](const std::vector<Value> &a, CallContext &ctx) { return loadGeo(e, a, ctx); });
    addFn(reg, "save_" + e,
          "file, raster, crs=\"EPSG:4326\", transform=\"\", bbox=\"\", nodata=\"\", cog=false, tile=\"\", compress=\"deflate\", bigtiff=\"auto\", boxes=\"\"",
          "write a tiled GeoTIFF (256 x 256 tiles unless tile= / tile=0 for strips; cog=true adds overviews) placed by transform= or bbox=", "rasterio.open(..., 'w').write",
          [e](const std::vector<Value> &a, CallContext &ctx) { return saveGeo(e, a, ctx); });
  }
  addFn(reg, "NcGeoRaster.sample", "D, lon, lat", "band values at a geographic point (lon, lat), or x / y in the raster CRS", "rasterio.DatasetReader.sample", sampleMethod);
}

} // namespace io
} // namespace nc
