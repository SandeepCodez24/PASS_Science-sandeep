// Markup documents (XML and HTML) as one node tree, with an XPath subset and
// CSS selectors. Used by io_markup.cpp (xml, html, htm) and, in phase 3, by
// the GPX / KML readers.
#ifndef NC_IO_MARKUP_H
#define NC_IO_MARKUP_H

#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct XNode {
  enum Kind { Document, Element, Text, Comment, CData, PI, Doctype };
  Kind kind = Element;
  std::string name; // element tag (HTML: lower case), PI target
  std::string text; // Text / Comment / CData / PI / Doctype content
  std::vector<std::pair<std::string, std::string>> attrs;
  std::vector<XNode> kids;

  const std::string *attr(const std::string &n) const;
  std::string innerText() const;      // all descendant text
  std::string ownText() const;        // direct text children only
  std::vector<const XNode *> elements() const; // element children
};

bool parseXml(const std::string &text, XNode &doc, std::string &err);
void parseHtml(const std::string &text, XNode &doc); // never fails
const XNode *rootElement(const XNode &doc);

struct XItem {
  const XNode *node = nullptr; // element (or the owner of an attribute)
  std::string attr;            // set for an attribute result
  bool isText = false;         // text() result
  std::string value;           // attribute value / text
};
// XPath subset: / // . .. * name prefix:name @a @* text() node(), and
// predicates [n] [last()] [@a] [@a='v'] [@a!='v'] [name='v'] [name>3]
// [contains(@a|text()|name,'v')] [starts-with(...)]. `ns` maps a prefix
// used in the expression to a namespace URI (resolved against the
// document's xmlns declarations).
bool xpath(const XNode &doc, const std::string &expr, std::vector<XItem> &out, std::string &err,
           const std::vector<std::pair<std::string, std::string>> &ns = {});
// CSS selector subset: tag .class #id [a] [a=v] [a*=v] [a^=v], descendant
// ' ' and child '>' combinators, ',' groups.
bool cssSelect(const XNode &doc, const std::string &selector, std::vector<const XNode *> &out,
               std::string &err);

std::string writeXml(const XNode &doc, int indent, const std::vector<std::string> &cdataFields,
                     const std::string &encoding);
std::string escapeXml(const std::string &s, bool attr);

} // namespace io
} // namespace nc

#endif // NC_IO_MARKUP_H
