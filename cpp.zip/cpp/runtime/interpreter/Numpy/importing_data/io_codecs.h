// Compression codecs used by the columnar formats (parquet, feather / Arrow
// IPC, orc), hand-written: Snappy, LZ4 (block, frame, Hadoop framing) with
// xxHash32, and Zstandard (RFC 8878: full decoder; the encoder emits real
// LZ77 sequences with zstd's predefined FSE tables and raw literals).
#ifndef NC_IO_CODECS_H
#define NC_IO_CODECS_H

#include <cstdint>
#include <string>

namespace nc {
namespace io {

uint32_t xxh32(const void *data, size_t n, uint32_t seed = 0);

std::string snappyCompress(const std::string &in);
bool snappyDecompress(const std::string &in, std::string &out, std::string &err);

std::string lz4BlockCompress(const std::string &in);
// `maxOut` bounds the output (0 = no bound)
bool lz4BlockDecompress(const char *in, size_t n, std::string &out, size_t maxOut, std::string &err);
std::string lz4FrameCompress(const std::string &in);
bool lz4FrameDecompress(const std::string &in, std::string &out, std::string &err);
// Hadoop's LZ4 framing ([BE uncompressed size][BE compressed size][block]...)
bool lz4HadoopDecompress(const std::string &in, std::string &out, std::string &err);

std::string zstdCompress(const std::string &in, int level = 3);
bool zstdDecompress(const std::string &in, std::string &out, std::string &err);

// codec by name: none snappy gzip zlib lz4 (frame) lz4_raw zstd
bool compressWith(const std::string &codec, int level, const std::string &in, std::string &out, std::string &err);
bool decompressWith(const std::string &codec, const std::string &in, size_t expected, std::string &out, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_CODECS_H
