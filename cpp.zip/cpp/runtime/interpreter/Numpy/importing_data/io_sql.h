// A small SQL engine over in-memory tables: SELECT queries for SQLite files,
// and `where=` row filters for Parquet / Feather / ORC / shapefiles.
//   SELECT [DISTINCT] * | expr [AS a], ... FROM t [WHERE e] [GROUP BY e,...]
//     [HAVING e] [ORDER BY e [ASC|DESC], ...] [LIMIT n [OFFSET m]]
// Expressions: literals, columns, ?, || * / % + -, = == != <> < <= > >=,
// IS [NOT] NULL, [NOT] LIKE, [NOT] IN (...), [NOT] BETWEEN, NOT AND OR,
// COUNT SUM AVG MIN MAX ABS ROUND LOWER UPPER LENGTH COALESCE SUBSTR IFNULL.
// NULL is NaN.
#ifndef NC_IO_SQL_H
#define NC_IO_SQL_H

#include <functional>
#include <string>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

// Rows of `t` for which `where` is true (0-based positions in t.rows).
bool sqlFilter(const Table &t, const std::string &where, const std::vector<Value> &params,
               std::vector<size_t> &keep, std::string &err);

// Runs a SELECT. `lookup` returns the table named in FROM (false = unknown).
bool sqlSelect(const std::string &sql, const std::vector<Value> &params,
               const std::function<bool(const std::string &, Table &, std::string &)> &lookup,
               Table &out, std::string &err);

std::string sqlQuote(const std::string &s);       // 'it''s'
std::string sqlIdent(const std::string &s);       // "my col"
std::string sqlLiteral(const Value &v);           // 3.5, 'text', NULL

} // namespace io
} // namespace nc

#endif // NC_IO_SQL_H
