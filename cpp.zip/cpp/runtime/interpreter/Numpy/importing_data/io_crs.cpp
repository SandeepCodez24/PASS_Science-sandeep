// CRS helpers (see io_geo.h).
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <regex>

#include "io_common.h"
#include "io_geo.h"

namespace nc {
namespace io {
namespace {

constexpr double PI = 3.14159265358979323846;
constexpr double A = 6378137.0, F = 1 / 298.257223563;

bool isUtm(int e) { return (e > 32600 && e <= 32660) || (e > 32700 && e <= 32760); }

// Transverse Mercator (Krueger series, as in GeographicLib's 6th order truncated to 4th)
void utmForward(int zone, bool south, double lon, double lat, double &x, double &y) {
  double k0 = 0.9996, n = F / (2 - F), a2 = A / (1 + n) * (1 + n * n / 4 + n * n * n * n / 64);
  double alpha[4] = {n / 2 - 2 * n * n / 3 + 5 * n * n * n / 16, 13 * n * n / 48 - 3 * n * n * n / 5, 61 * n * n * n / 240, 49561 * n * n * n * n / 161280};
  double lon0 = (zone - 1) * 6 - 180 + 3;
  double phi = lat * PI / 180, lam = (lon - lon0) * PI / 180;
  double e = std::sqrt(F * (2 - F));
  double t = std::sinh(std::atanh(std::sin(phi)) - e * std::atanh(e * std::sin(phi)));
  double xi = std::atan2(t, std::cos(lam)), eta = std::atanh(std::sin(lam) / std::sqrt(1 + t * t));
  double X = eta, Y = xi;
  for (int j = 1; j <= 4; j++) { X += alpha[j - 1] * std::cos(2 * j * xi) * std::sinh(2 * j * eta); Y += alpha[j - 1] * std::sin(2 * j * xi) * std::cosh(2 * j * eta); }
  x = 500000 + k0 * a2 * X;
  y = k0 * a2 * Y + (south ? 10000000 : 0);
}

void utmInverse(int zone, bool south, double x, double y, double &lon, double &lat) {
  double k0 = 0.9996, n = F / (2 - F), a2 = A / (1 + n) * (1 + n * n / 4 + n * n * n * n / 64);
  double beta[4] = {n / 2 - 2 * n * n / 3 + 37 * n * n * n / 96, n * n / 48 + n * n * n / 15, 17 * n * n * n / 480, 4397 * n * n * n * n / 161280};
  double xi = (y - (south ? 10000000 : 0)) / (k0 * a2), eta = (x - 500000) / (k0 * a2);
  double xp = xi, ep = eta;
  for (int j = 1; j <= 4; j++) { xp -= beta[j - 1] * std::sin(2 * j * xi) * std::cosh(2 * j * eta); ep -= beta[j - 1] * std::cos(2 * j * xi) * std::sinh(2 * j * eta); }
  double chi = std::asin(std::sin(xp) / std::cosh(ep));
  double e = std::sqrt(F * (2 - F));
  double phi = chi;
  for (int k = 0; k < 8; k++) phi = std::asin(std::tanh(std::atanh(std::sin(chi)) + e * std::atanh(e * std::sin(phi))));
  lat = phi * 180 / PI;
  lon = (zone - 1) * 6 - 180 + 3 + std::atan2(std::sinh(ep), std::cos(xp)) * 180 / PI;
}

} // namespace

bool crsGeographic(int e) { return e == 4326 || e == 4258 || e == 4269 || e == 4019 || e == 4030; }
bool crsSupported(int e) { return crsGeographic(e) || e == 3857 || e == 900913 || e == 3785 || isUtm(e); }

int crsEpsg(const std::string &text) {
  std::string t = trim(text), l = lower(t);
  if (t.empty()) return 0;
  char *end = nullptr;
  long v = std::strtol(t.c_str(), &end, 10);
  if (end && *end == '\0' && v > 0) return static_cast<int>(v);
  std::smatch m;
  if (std::regex_search(l, m, std::regex("^(epsg|esri)\\s*:\\s*(\\d+)$"))) return std::atoi(m[2].str().c_str());
  if (std::regex_search(l, m, std::regex("urn:ogc:def:crs:epsg:[0-9.]*:(\\d+)"))) return std::atoi(m[1].str().c_str());
  if (l.find("crs84") != std::string::npos) return 4326;
  if (l.find("+proj=") != std::string::npos) {
    if (l.find("+proj=longlat") != std::string::npos || l.find("+proj=latlong") != std::string::npos) return 4326;
    if (std::regex_search(l, m, std::regex("\\+proj=utm.*\\+zone=(\\d+)"))) return (l.find("+south") != std::string::npos ? 32700 : 32600) + std::atoi(m[1].str().c_str());
    if (l.find("+proj=merc") != std::string::npos && l.find("+a=6378137") != std::string::npos) return 3857;
    return 0;
  }
  // WKT: the last AUTHORITY["EPSG","n"] / ID["EPSG",n] belongs to the whole CRS
  std::regex auth("(authority|id)\\[\\s*\"epsg\"\\s*,\\s*\"?(\\d+)\"?\\s*\\]");
  int last = 0;
  for (auto it = std::sregex_iterator(l.begin(), l.end(), auth); it != std::sregex_iterator(); ++it) last = std::atoi((*it)[2].str().c_str());
  if (last) return last;
  if (std::regex_search(l, m, std::regex("utm[_ ]zone[_ ](\\d+)\\s*([ns])"))) return (m[2].str() == "s" ? 32700 : 32600) + std::atoi(m[1].str().c_str());
  if (l.find("web_mercator") != std::string::npos || l.find("pseudo-mercator") != std::string::npos || l.find("pseudo mercator") != std::string::npos) return 3857;
  if ((l.find("geogcs") != std::string::npos || l.find("geogcrs") != std::string::npos) && l.find("projcs") == std::string::npos &&
      (l.find("wgs_1984") != std::string::npos || l.find("wgs 84") != std::string::npos || l.find("wgs84") != std::string::npos))
    return 4326;
  if (l == "wgs84" || l == "wgs 84" || l == "wgs-84") return 4326;
  return 0;
}

std::string crsName(int e) {
  if (e == 4326) return "WGS 84";
  if (e == 3857) return "WGS 84 / Pseudo-Mercator";
  if (isUtm(e)) return "WGS 84 / UTM zone " + std::to_string(e % 100) + (e > 32700 ? "S" : "N");
  return e ? "EPSG:" + std::to_string(e) : "";
}

bool crsTransform(int from, int to, double &x, double &y, std::string &err) {
  if (from == to || (crsGeographic(from) && crsGeographic(to))) return true;
  if (!crsSupported(from) || !crsSupported(to)) {
    err = "reprojecting EPSG:" + std::to_string(from) + " -> EPSG:" + std::to_string(to) + " is not built in (WGS84 4326, Web Mercator 3857 and WGS84 UTM 326xx / 327xx are)";
    return false;
  }
  double lon = x, lat = y;
  if (from == 3857 || from == 900913 || from == 3785) { lon = x / A * 180 / PI; lat = (2 * std::atan(std::exp(y / A)) - PI / 2) * 180 / PI; }
  else if (isUtm(from)) utmInverse(from % 100, from > 32700, x, y, lon, lat);
  if (to == 3857 || to == 900913 || to == 3785) {
    double la = std::clamp(lat, -85.0511287798, 85.0511287798);
    x = A * lon * PI / 180;
    y = A * std::log(std::tan(PI / 4 + la * PI / 360));
  } else if (isUtm(to)) utmForward(to % 100, to > 32700, lon, lat, x, y);
  else { x = lon; y = lat; }
  return true;
}

std::string crsWkt(int e) {
  const std::string geog = "GEOGCS[\"GCS_WGS_1984\",DATUM[\"D_WGS_1984\",SPHEROID[\"WGS_1984\",6378137.0,298.257223563]],PRIMEM[\"Greenwich\",0.0],UNIT[\"Degree\",0.0174532925199433]]";
  if (crsGeographic(e)) return geog;
  if (e == 3857)
    return "PROJCS[\"WGS_1984_Web_Mercator_Auxiliary_Sphere\"," + geog +
           ",PROJECTION[\"Mercator_Auxiliary_Sphere\"],PARAMETER[\"False_Easting\",0.0],PARAMETER[\"False_Northing\",0.0],PARAMETER[\"Central_Meridian\",0.0],"
           "PARAMETER[\"Standard_Parallel_1\",0.0],PARAMETER[\"Auxiliary_Sphere_Type\",0.0],UNIT[\"Meter\",1.0]]";
  if (isUtm(e)) {
    int zone = e % 100;
    bool south = e > 32700;
    return "PROJCS[\"WGS_1984_UTM_Zone_" + std::to_string(zone) + (south ? "S" : "N") + "\"," + geog +
           ",PROJECTION[\"Transverse_Mercator\"],PARAMETER[\"False_Easting\",500000.0],PARAMETER[\"False_Northing\"," + (south ? "10000000.0" : "0.0") +
           "],PARAMETER[\"Central_Meridian\"," + std::to_string((zone - 1) * 6 - 180 + 3) + ".0],PARAMETER[\"Scale_Factor\",0.9996],PARAMETER[\"Latitude_Of_Origin\",0.0],UNIT[\"Meter\",1.0]]";
  }
  return "";
}

} // namespace io
} // namespace nc
