// ImportSession - the C++ side of the Import / Process / Export windows.
//
// The UI never parses files itself. It drives one ImportSession:
//
//   ImportSession s;
//   s.setSource("D:/data/sensor_log_march.xlsx");   // "Choose a file"
//   Detection d = s.detect();                         // Format: xlsx (0.98)
//   for (auto &o : s.options("read")) ...             // "Import as" panel
//   s.setOption("sheet", "\"ABC\"");                  // values as NC literals
//   Preview p; s.preview(20, p, err);                 // "Check the preview"
//   std::string code = s.code("read", "T");           // "NC code" bar
//   Value v; s.run("read", v, err, listener);         // "Importing" -> "Done"
//   s.cancel();                                       // from another thread
//
// Events (open / progress / done / error / saved) also reach a global
// listener (setIoListener in io_common.h), so a JNI bridge can forward them.
// The same features exist as NC functions for scripts and tests:
//   io_formats(category?), io_detect(file), io_options(format, op),
//   io_preview(file, n, format), io_code(file, op, var, format).
#ifndef NC_IO_SESSION_H
#define NC_IO_SESSION_H

#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct FormatInfo {
  std::string id;         // "csv" - the suffix of read_<id> / load_<id> / save_<id>
  std::string category;   // "Delimited text"
  std::string title;      // "Comma-Separated Values"
  std::string extensions; // ".csv"
  int phase = 1;          // delivery phase (1 = available now)
};
// All 56 formats of the specification, in its order.
const std::vector<FormatInfo> &formatCatalog();
const FormatInfo *findFormat(const std::string &id);
bool formatAvailable(const std::string &id); // its read_<id> is registered

struct Detection {
  std::string format;   // "" when unknown
  std::string category;
  double confidence = 0; // 0..1
  std::string reason;   // "PNG signature", "extension .csv", ...
  bool compressed = false; // gzip around it
};
// Looks at the first bytes (the extension only breaks ties), like the
// window says: "the extension does not need to be right".
Detection detectFormat(const std::string &path);

struct OptionSpec {
  std::string name;        // "sheet"
  std::string type;        // "text", "number", "bool", "list"
  std::string defaultText; // as written in the parameter line
  std::string help;        // one line for the tooltip
  std::vector<std::string> choices;
};
std::vector<OptionSpec> optionsFor(const std::string &format, const std::string &op);

struct Preview {
  std::string kind;  // "table", "tree", "array", "text", "object"
  std::vector<std::string> cols;
  std::vector<std::vector<std::string>> rows; // display text
  std::vector<std::string> boxes;              // info boxes found around the data
  size_t totalRows = 0;
  std::string note;
};

class ImportSession {
public:
  void setSource(const std::string &pathOrUrl);
  const std::string &source() const { return source_; }
  Detection detect();
  void setFormat(const std::string &format) { format_ = format; }
  const std::string &format() const { return format_; }
  // `literal` is NC syntax: 3, true, "ABC", ["A","B"], [2:500].
  void setOption(const std::string &name, const std::string &literal);
  void clearOptions() { options_.clear(); }
  const std::vector<std::pair<std::string, std::string>> &optionsSet() const { return options_; }
  std::vector<OptionSpec> options(const std::string &op) const { return optionsFor(format_, op); }
  bool preview(size_t maxRows, Preview &out, std::string &err);
  std::string code(const std::string &op = "read", const std::string &var = "") const;
  // Runs read_/load_<format>; `listener` receives this run's events.
  bool run(const std::string &op, Value &out, std::string &err, IoListener listener = {});
  void cancel() { requestCancel(); }

private:
  std::string source_, format_;
  std::vector<std::pair<std::string, std::string>> options_;
};

std::string generateCode(const std::string &op, const std::string &format, const std::string &path,
                         const std::string &var,
                         const std::vector<std::pair<std::string, std::string>> &options);
// An NC literal as typed in the UI -> Value (numbers, true/false, "text",
// [a, b, ...] and [a:b] ranges).
bool parseLiteral(const std::string &text, Value &out, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_SESSION_H
