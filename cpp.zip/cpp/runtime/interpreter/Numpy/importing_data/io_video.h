// CATEGORY 16 - video containers (MP4 / M4V / MOV = ISO base media file
// format, AVI = RIFF) and the frame codecs that are built in: MJPEG,
// uncompressed RGB, PNG frames, and H.264 written / read as I_PCM
// macroblocks (a valid H.264 stream every player decodes; it keeps the
// YUV 4:2:0 samples exactly, so files are large). Compressed H.264 / HEVC /
// ProRes frames are recognised, but not decoded.
#ifndef NC_IO_VIDEO_H
#define NC_IO_VIDEO_H

#include <string>
#include <vector>

#include "io_image.h"

namespace nc {
namespace io {

struct H264Params {
  std::string sps, pps; // NAL payloads without start codes
};

// RGB(A) / gray 8-bit image -> one IDR access unit of I_PCM macroblocks,
// as NAL units (no start codes / length prefixes). `idrId` alternates 0/1.
std::vector<std::string> h264EncodePcm(const Image &img, int idrId, H264Params &ps);
// NAL units of one access unit -> RGB image; only I_PCM macroblocks decode.
bool h264DecodePcm(const std::vector<std::string> &nals, H264Params &ps, Image &img, std::string &err);
// Annex B byte stream / length-prefixed sample -> NAL units
std::vector<std::string> h264SplitAnnexB(const std::string &b);
std::vector<std::string> h264SplitLengths(const std::string &b, int lengthSize);

} // namespace io
} // namespace nc

#endif // NC_IO_VIDEO_H
