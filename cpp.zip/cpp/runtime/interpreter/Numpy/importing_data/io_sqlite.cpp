// SQLite file format (https://www.sqlite.org/fileformat2.html) - see io_sqlite.h.
#include "io_sqlite.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <functional>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_sql.h"

namespace nc {
namespace io {

namespace {

uint64_t varint(const std::string &s, size_t &p) {
  uint64_t v = 0;
  for (int k = 0; k < 9 && p < s.size(); k++) {
    unsigned char c = static_cast<unsigned char>(s[p++]);
    if (k == 8) return (v << 8) | c;
    v = (v << 7) | (c & 0x7F);
    if (!(c & 0x80)) break;
  }
  return v;
}

void putVarint(std::string &o, uint64_t v) {
  if (v > 0x00FFFFFFFFFFFFFFull) {
    char buf[9];
    buf[8] = static_cast<char>(v & 0xFF);
    v >>= 8;
    for (int k = 7; k >= 0; k--) { buf[k] = static_cast<char>((v & 0x7F) | 0x80); v >>= 7; }
    o.append(buf, 9);
    return;
  }
  char buf[10];
  int n = 0;
  do { buf[n++] = static_cast<char>(v & 0x7F); v >>= 7; } while (v);
  for (int k = n - 1; k >= 0; k--) o.push_back(static_cast<char>(buf[k] | (k ? 0x80 : 0)));
}

struct Pager {
  const std::string &b;
  size_t pageSize, usable;
  int encoding = 1;
  Pager(const std::string &bytes, size_t ps, size_t reserved) : b(bytes), pageSize(ps), usable(ps - reserved) {}
  size_t off(uint32_t page) const { return static_cast<size_t>(page - 1) * pageSize; }
  // the cell payload with overflow pages followed
  std::string payload(size_t at, uint64_t total, bool table, size_t &after) const {
    size_t U = usable, X = table ? U - 35 : ((U - 12) * 64 / 255) - 23, M = ((U - 12) * 32 / 255) - 23;
    if (total <= X) { after = at + total; return b.substr(at, static_cast<size_t>(total)); }
    size_t K = M + (static_cast<size_t>(total) - M) % (U - 4);
    size_t local = K <= X ? K : M;
    std::string out = b.substr(at, local);
    uint32_t ov = u32be(b, at + local);
    after = at + local + 4;
    size_t guard = 0;
    while (ov && out.size() < total && guard++ < 10000000) {
      size_t p = off(ov);
      size_t n = std::min<size_t>(U - 4, static_cast<size_t>(total) - out.size());
      out.append(b, p + 4, n);
      ov = u32be(b, p);
    }
    return out;
  }
  std::string text(const std::string &s) const {
    if (encoding == 1) return s;
    std::string o;
    for (size_t k = 0; k + 1 < s.size(); k += 2) {
      uint32_t c = encoding == 2 ? u16le(s, k) : u16be(s, k);
      if (c < 0x80) o.push_back(static_cast<char>(c));
      else if (c < 0x800) { o.push_back(static_cast<char>(0xC0 | (c >> 6))); o.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
      else { o.push_back(static_cast<char>(0xE0 | (c >> 12))); o.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F))); o.push_back(static_cast<char>(0x80 | (c & 0x3F))); }
    }
    return o;
  }
  std::vector<Value> record(const std::string &r) const {
    std::vector<Value> out;
    size_t p = 0;
    uint64_t hsize = varint(r, p);
    std::vector<uint64_t> types;
    while (p < hsize && p < r.size()) types.push_back(varint(r, p));
    size_t d = static_cast<size_t>(hsize);
    for (uint64_t t : types) {
      switch (t) {
        case 0: out.push_back(Value(std::nan(""))); break;
        case 1: out.push_back(Value(static_cast<double>(static_cast<int8_t>(r[d])))); d += 1; break;
        case 2: out.push_back(Value(static_cast<double>(static_cast<int16_t>(u16be(r, d))))); d += 2; break;
        case 3: { int64_t v = static_cast<int64_t>(getBE(r, d, 3) << 40) >> 40; out.push_back(Value(static_cast<double>(v))); d += 3; break; }
        case 4: out.push_back(Value(static_cast<double>(static_cast<int32_t>(u32be(r, d))))); d += 4; break;
        case 5: { int64_t v = static_cast<int64_t>(getBE(r, d, 6) << 16) >> 16; out.push_back(Value(static_cast<double>(v))); d += 6; break; }
        case 6: out.push_back(Value(static_cast<double>(static_cast<int64_t>(u64be(r, d))))); d += 8; break;
        case 7: out.push_back(Value(f64be(r, d))); d += 8; break;
        case 8: out.push_back(Value(0.0)); break;
        case 9: out.push_back(Value(1.0)); break;
        default:
          if (t >= 12) {
            size_t n = static_cast<size_t>((t - (t % 2 ? 13 : 12)) / 2);
            std::string s = r.substr(d, n);
            out.push_back(t % 2 ? Value(text(s)) : Value("<blob " + std::to_string(n) + " bytes>"));
            d += n;
          }
      }
    }
    return out;
  }
  // every (rowid, record) of a table b-tree
  bool scan(uint32_t root, const std::function<void(int64_t, const std::string &)> &fn, std::string &err, int depth = 0) const {
    if (depth > 64 || root == 0 || off(root) + 8 > b.size()) { err = "damaged SQLite b-tree"; return false; }
    size_t base = off(root), h = root == 1 ? base + 100 : base;
    unsigned char type = static_cast<unsigned char>(b[h]);
    size_t n = u16be(b, h + 3);
    bool interior = type == 0x05;
    if (type != 0x05 && type != 0x0D) { err = "SQLite page " + std::to_string(root) + " is not a table b-tree page (WITHOUT ROWID tables are not built in)"; return false; }
    size_t ptrs = h + (interior ? 12 : 8);
    for (size_t k = 0; k < n; k++) {
      size_t c = base + u16be(b, ptrs + 2 * k);
      if (interior) {
        if (!scan(u32be(b, c), fn, err, depth + 1)) return false;
        continue;
      }
      size_t p = c;
      uint64_t total = varint(b, p);
      int64_t rowid = static_cast<int64_t>(varint(b, p));
      size_t after;
      fn(rowid, payload(p, total, true, after));
    }
    if (interior && !scan(u32be(b, h + 8), fn, err, depth + 1)) return false;
    return true;
  }
};

std::string stripQuotes(std::string s) {
  s = trim(s);
  if (s.size() >= 2 && (s[0] == '"' || s[0] == '`' || s[0] == '[' || s[0] == '\'')) return s.substr(1, s.size() - 2);
  return s;
}

std::string upperStr(std::string s) { for (char &c : s) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c))); return s; }

} // namespace

void parseCreateTable(const std::string &sql, DbTable &t) {
  // comments: "-- note" lines
  size_t cpos = 0;
  std::string clean;
  while (cpos < sql.size()) {
    if (sql.compare(cpos, 2, "--") == 0) {
      size_t e = sql.find('\n', cpos);
      std::string c = trim(sql.substr(cpos + 2, (e == std::string::npos ? sql.size() : e) - cpos - 2));
      if (!c.empty()) t.comment += (t.comment.empty() ? "" : "\n") + c;
      cpos = e == std::string::npos ? sql.size() : e;
      continue;
    }
    clean.push_back(sql[cpos++]);
  }
  size_t open = clean.find('('), close = clean.rfind(')');
  if (open == std::string::npos || close == std::string::npos) return;
  std::string body = clean.substr(open + 1, close - open - 1);
  std::vector<std::string> parts;
  int depth = 0;
  bool q = false;
  std::string cur;
  for (char c : body) {
    if (c == '\'' || c == '"') q = !q;
    if (!q && c == '(') depth++;
    if (!q && c == ')') depth--;
    if (!q && depth == 0 && c == ',') { parts.push_back(cur); cur.clear(); continue; }
    cur.push_back(c);
  }
  parts.push_back(cur);
  for (const auto &partIn : parts) {
    std::string part = trim(partIn);
    std::string u = upperStr(part);
    if (u.rfind("PRIMARY KEY", 0) == 0) {
      size_t a = part.find('('), e = part.find(')');
      if (a != std::string::npos && e != std::string::npos) {
        std::string list = part.substr(a + 1, e - a - 1);
        size_t s = 0;
        while (s <= list.size()) {
          size_t c = list.find(',', s);
          if (c == std::string::npos) c = list.size();
          std::string nm = stripQuotes(list.substr(s, c - s));
          for (auto &col : t.cols) if (col.name == nm) col.pk = true;
          s = c + 1;
        }
      }
      continue;
    }
    if (u.rfind("FOREIGN KEY", 0) == 0) {
      size_t a = part.find('('), e = part.find(')');
      size_t ref = u.find("REFERENCES");
      if (a != std::string::npos && ref != std::string::npos) {
        std::string nm = stripQuotes(part.substr(a + 1, e - a - 1));
        for (auto &col : t.cols) if (col.name == nm) col.references = trim(part.substr(ref + 10));
      }
      continue;
    }
    if (u.rfind("UNIQUE", 0) == 0 || u.rfind("CHECK", 0) == 0 || u.rfind("CONSTRAINT", 0) == 0) continue;
    DbColumn col;
    size_t i = 0;
    if (!part.empty() && (part[0] == '"' || part[0] == '`' || part[0] == '[')) {
      char close2 = part[0] == '[' ? ']' : part[0];
      size_t e = part.find(close2, 1);
      col.name = part.substr(1, e - 1);
      i = e + 1;
    } else {
      while (i < part.size() && !std::isspace(static_cast<unsigned char>(part[i]))) i++;
      col.name = part.substr(0, i);
    }
    std::string rest = trim(part.substr(i)), ur = upperStr(rest);
    static const char *stops[] = {" PRIMARY", " NOT", " NULL", " DEFAULT", " UNIQUE", " CHECK", " REFERENCES", " COLLATE", " CONSTRAINT", " GENERATED"};
    size_t cut = rest.size();
    for (const char *s : stops) { size_t at = (" " + ur).find(s); if (at != std::string::npos) cut = std::min(cut, at); }
    col.type = trim(rest.substr(0, cut));
    col.pk = ur.find("PRIMARY KEY") != std::string::npos;
    col.notNull = ur.find("NOT NULL") != std::string::npos;
    col.rowidAlias = col.pk && upperStr(col.type) == "INTEGER" && ur.find("DESC") == std::string::npos;
    size_t ref = ur.find("REFERENCES");
    if (ref != std::string::npos) col.references = trim(rest.substr(ref + 10));
    t.cols.push_back(col);
  }
}

std::string createTableSql(const DbTable &t) {
  std::string s = "CREATE TABLE " + sqlIdent(t.name) + " (";
  if (!t.comment.empty()) {
    size_t a = 0;
    while (a <= t.comment.size()) {
      size_t e = t.comment.find('\n', a);
      if (e == std::string::npos) e = t.comment.size();
      s += "\n  -- " + t.comment.substr(a, e - a);
      a = e + 1;
    }
  }
  for (size_t k = 0; k < t.cols.size(); k++) {
    const auto &c = t.cols[k];
    s += std::string(k ? "," : "") + "\n  " + sqlIdent(c.name) + (c.type.empty() ? "" : " " + c.type);
    if (c.pk) s += " PRIMARY KEY";
    if (c.notNull && !c.pk) s += " NOT NULL";
    if (!c.references.empty()) s += " REFERENCES " + c.references;
  }
  return s + "\n)";
}

bool readSqlite(const std::string &b, DbFile &db, std::string &err, bool loadRows) {
  db = DbFile();
  if (b.size() < 100 || b.compare(0, 16, std::string("SQLite format 3\0", 16)) != 0) { err = "not an SQLite 3 database"; return false; }
  size_t ps = u16be(b, 16);
  if (ps == 1) ps = 65536;
  Pager pg(b, ps, static_cast<unsigned char>(b[20]));
  pg.encoding = static_cast<int>(u32be(b, 56));
  if (!pg.encoding) pg.encoding = 1;
  struct Master { std::string type, name, tbl, sql; uint32_t root; };
  std::vector<Master> master;
  if (!pg.scan(1, [&](int64_t, const std::string &rec) {
        auto v = pg.record(rec);
        if (v.size() >= 5) master.push_back({cellText(v[0]), cellText(v[1]), cellText(v[2]), v[4].isText ? v[4].text() : "", static_cast<uint32_t>(v[3].number)});
      }, err))
    return false;
  for (const auto &m : master) {
    if (m.type == "table" && m.name.rfind("sqlite_", 0) != 0) {
      DbTable t;
      t.name = m.name;
      t.sql = m.sql;
      parseCreateTable(m.sql, t);
      if (upperStr(m.sql).find("WITHOUT ROWID") != std::string::npos) {
        t.comment += (t.comment.empty() ? "" : "\n") + std::string("(WITHOUT ROWID table: rows not readable)");
        db.tables.push_back(t);
        continue;
      }
      if (loadRows && !pg.scan(m.root, [&](int64_t rowid, const std::string &rec) {
            auto v = pg.record(rec);
            v.resize(t.cols.size(), Value(std::nan("")));
            for (size_t c = 0; c < t.cols.size(); c++) if (t.cols[c].rowidAlias) v[c] = Value(static_cast<double>(rowid));
            t.rows.push_back(std::move(v));
            t.rowids.push_back(rowid);
          }, err))
        return false;
      db.tables.push_back(std::move(t));
    }
  }
  for (const auto &m : master) {
    if (m.type == "view") db.views.push_back({m.name, m.sql});
    else if (m.type == "trigger") db.otherSql.push_back(m.sql);
    else if (m.type == "index" && !m.sql.empty()) {
      size_t a = m.sql.find('('), e = m.sql.rfind(')');
      std::vector<std::string> cols;
      if (a != std::string::npos && e != std::string::npos) {
        std::string list = m.sql.substr(a + 1, e - a - 1);
        size_t s = 0;
        while (s <= list.size()) {
          size_t c = list.find(',', s);
          if (c == std::string::npos) c = list.size();
          std::string nm = trim(list.substr(s, c - s));
          size_t sp = nm.find(' ');
          cols.push_back(stripQuotes(sp == std::string::npos ? nm : nm.substr(0, sp)));
          s = c + 1;
        }
      }
      for (auto &t : db.tables) if (t.name == m.tbl) t.indexes.push_back({m.name, cols});
    }
  }
  return true;
}

// ---- writer --------------------------------------------------------------------------

namespace {

std::string recordOf(const std::vector<Value> &vals, const std::vector<bool> &skip) {
  std::string header, body;
  for (size_t k = 0; k < vals.size(); k++) {
    const Value &v = vals[k];
    if ((k < skip.size() && skip[k]) || (numpy::isPlainNumber(v) && !v.isText && std::isnan(v.number))) { putVarint(header, 0); continue; }
    if (v.isText) {
      putVarint(header, 13 + 2 * v.text().size());
      body += v.text();
    } else if (v.number == std::floor(v.number) && std::fabs(v.number) < 9.2e18) {
      int64_t i = static_cast<int64_t>(v.number);
      if (i == 0) putVarint(header, 8);
      else if (i == 1) putVarint(header, 9);
      else if (i >= -128 && i <= 127) { putVarint(header, 1); body.push_back(static_cast<char>(i)); }
      else if (i >= -32768 && i <= 32767) { putVarint(header, 2); putBE(body, static_cast<uint64_t>(i), 2); }
      else if (i >= -2147483648LL && i <= 2147483647LL) { putVarint(header, 4); putBE(body, static_cast<uint64_t>(i), 4); }
      else { putVarint(header, 6); putBE(body, static_cast<uint64_t>(i), 8); }
    } else {
      putVarint(header, 7);
      putF64BE(body, v.number);
    }
  }
  std::string h;
  size_t hs = header.size() + 1;
  if (hs > 127) hs = header.size() + 2;
  putVarint(h, hs);
  return h + header + body;
}

struct Writer {
  const size_t P = 4096, U = 4096;
  std::vector<std::string> pages; // page k+1 = pages[k]
  uint32_t newPage() { pages.emplace_back(P, '\0'); return static_cast<uint32_t>(pages.size()); }
  // local part + overflow chain for a payload
  std::string cellPayload(const std::string &pl, bool table) {
    size_t X = table ? U - 35 : ((U - 12) * 64 / 255) - 23, M = ((U - 12) * 32 / 255) - 23;
    if (pl.size() <= X) return pl;
    size_t K = M + (pl.size() - M) % (U - 4);
    size_t local = K <= X ? K : M;
    std::string out = pl.substr(0, local);
    size_t pos = local;
    std::vector<uint32_t> chain;
    while (pos < pl.size()) {
      uint32_t pg = newPage();
      chain.push_back(pg);
      size_t n = std::min(U - 4, pl.size() - pos);
      pages[pg - 1].replace(4, n, pl, pos, n);
      pos += n;
    }
    for (size_t k = 0; k < chain.size(); k++) setBE(pages[chain[k] - 1], 0, k + 1 < chain.size() ? chain[k + 1] : 0, 4);
    putBE(out, chain[0], 4);
    return out;
  }
  // fills one b-tree page; returns false when the cell does not fit
  struct PageBuild { uint32_t no; std::vector<std::string> cells; size_t used; };
  void flush(PageBuild &pb, unsigned char type, uint32_t rightChild, size_t hdrOff) {
    std::string &pg = pages[pb.no - 1];
    bool interior = type == 0x05 || type == 0x02;
    size_t h = hdrOff, ptrs = h + (interior ? 12 : 8);
    size_t content = P;
    for (size_t k = 0; k < pb.cells.size(); k++) {
      content -= pb.cells[k].size();
      pg.replace(content, pb.cells[k].size(), pb.cells[k]);
      setBE(pg, ptrs + 2 * k, content, 2);
    }
    pg[h] = static_cast<char>(type);
    setBE(pg, h + 1, 0, 2);
    setBE(pg, h + 3, pb.cells.size(), 2);
    setBE(pg, h + 5, content == 65536 ? 0 : content, 2);
    pg[h + 7] = 0;
    if (interior) setBE(pg, h + 8, rightChild, 4);
  }
  size_t room(const PageBuild &pb, bool interior, size_t hdrOff) const {
    size_t fixed = hdrOff + (interior ? 12 : 8) + 2 * pb.cells.size();
    return P > fixed + pb.used ? P - fixed - pb.used : 0;
  }
  // table b-tree from (rowid, record) pairs; returns root page
  uint32_t tableTree(const std::vector<std::pair<int64_t, std::string>> &rows, uint32_t fixedRoot = 0, size_t rootHdr = 0) {
    struct Child { uint32_t page; int64_t maxKey; };
    std::vector<Child> level;
    PageBuild pb{fixedRoot ? fixedRoot : newPage(), {}, 0};
    size_t hdr = fixedRoot ? rootHdr : 0;
    int64_t lastKey = 0;
    for (const auto &r : rows) {
      std::string cell;
      putVarint(cell, r.second.size());
      putVarint(cell, static_cast<uint64_t>(r.first));
      cell += cellPayload(r.second, true);
      if (room(pb, false, hdr) < cell.size() + 2 && !pb.cells.empty()) {
        flush(pb, 0x0D, 0, hdr);
        level.push_back({pb.no, lastKey});
        pb = PageBuild{newPage(), {}, 0};
        hdr = 0;
      }
      pb.cells.push_back(cell);
      pb.used += cell.size();
      lastKey = r.first;
    }
    if (level.empty()) { flush(pb, 0x0D, 0, hdr); return pb.no; }
    flush(pb, 0x0D, 0, hdr);
    level.push_back({pb.no, lastKey});
    // interior levels
    while (level.size() > 1) {
      std::vector<Child> up;
      PageBuild ib{newPage(), {}, 0};
      size_t i = 0;
      while (i < level.size()) {
        std::string cell;
        putBE(cell, level[i].page, 4);
        putVarint(cell, static_cast<uint64_t>(level[i].maxKey));
        bool last = i + 1 == level.size();
        if (last || (room(ib, true, 0) < cell.size() + 2 && !ib.cells.empty())) {
          flush(ib, 0x05, level[i].page, 0);
          up.push_back({ib.no, level[i].maxKey});
          i++;
          if (!last) ib = PageBuild{newPage(), {}, 0};
          continue;
        }
        ib.cells.push_back(cell);
        ib.used += cell.size();
        i++;
      }
      level = up;
    }
    return level[0].page;
  }
  // index b-tree from sorted records (keys hold the rowid last)
  uint32_t indexTree(const std::vector<std::string> &keys) {
    // simple bulk load: leaves with separators promoted
    struct Node { uint32_t page; };
    std::vector<std::vector<std::string>> leaves;
    std::vector<std::string> seps;
    std::vector<std::string> cur;
    size_t used = 0;
    for (size_t k = 0; k < keys.size(); k++) {
      std::string cell;
      putVarint(cell, keys[k].size());
      cell += cellPayload(keys[k], false);
      if (used + cell.size() + 2 + 8 > P && !cur.empty() && k + 1 < keys.size()) {
        leaves.push_back(cur);
        cur.clear();
        used = 0;
        seps.push_back(keys[k]); // promoted separator
        continue;
      }
      cur.push_back(cell);
      used += cell.size() + 2;
    }
    leaves.push_back(cur);
    std::vector<uint32_t> pagesOf;
    for (auto &l : leaves) {
      PageBuild pb{newPage(), l, 0};
      flush(pb, 0x0A, 0, 0);
      pagesOf.push_back(pb.no);
    }
    if (pagesOf.size() == 1) return pagesOf[0];
    // one interior level (enough for the sizes NC writes; deeper trees split recursively)
    std::function<uint32_t(const std::vector<uint32_t> &, const std::vector<std::string> &)> build =
        [&](const std::vector<uint32_t> &kids, const std::vector<std::string> &sp) -> uint32_t {
      std::vector<std::string> cells;
      size_t total = 12;
      for (size_t k = 0; k < sp.size(); k++) {
        std::string cell;
        putBE(cell, kids[k], 4);
        putVarint(cell, sp[k].size());
        cell += cellPayload(sp[k], false);
        cells.push_back(cell);
        total += cell.size() + 2;
      }
      if (total <= P) {
        PageBuild pb{newPage(), cells, 0};
        flush(pb, 0x02, kids.back(), 0);
        return pb.no;
      }
      size_t half = sp.size() / 2;
      std::vector<uint32_t> k1(kids.begin(), kids.begin() + static_cast<long>(half) + 1), k2(kids.begin() + static_cast<long>(half) + 1, kids.end());
      std::vector<std::string> s1(sp.begin(), sp.begin() + static_cast<long>(half)), s2(sp.begin() + static_cast<long>(half) + 1, sp.end());
      uint32_t a = build(k1, s1), b2 = build(k2, s2);
      return build({a, b2}, {sp[half]});
    };
    return build(pagesOf, seps);
  }
};

int compareValues(const Value &a, const Value &b) {
  bool an = numpy::isPlainNumber(a) && !a.isText && std::isnan(a.number), bn = numpy::isPlainNumber(b) && !b.isText && std::isnan(b.number);
  if (an || bn) return an == bn ? 0 : an ? -1 : 1;
  if (a.isText != b.isText) return a.isText ? 1 : -1;
  if (a.isText) return a.text() < b.text() ? -1 : a.text() > b.text() ? 1 : 0;
  return a.number < b.number ? -1 : a.number > b.number ? 1 : 0;
}

} // namespace

std::string writeSqlite(const DbFile &db) {
  Writer w;
  w.newPage(); // page 1: sqlite_master root
  struct MasterRow { std::string type, name, tbl, sql; uint32_t root; };
  std::vector<MasterRow> master;
  for (const auto &t : db.tables) {
    std::vector<bool> skip;
    for (const auto &c : t.cols) skip.push_back(c.rowidAlias);
    std::vector<std::pair<int64_t, std::string>> rows;
    std::vector<int64_t> ids;
    for (size_t r = 0; r < t.rows.size(); r++) {
      int64_t id = r < t.rowids.size() ? t.rowids[r] : static_cast<int64_t>(r + 1);
      for (size_t c = 0; c < t.cols.size(); c++)
        if (t.cols[c].rowidAlias && isNumberCell(t.rows[r][c]) && !std::isnan(t.rows[r][c].number)) id = static_cast<int64_t>(t.rows[r][c].number);
      ids.push_back(id);
    }
    std::vector<size_t> order(t.rows.size());
    for (size_t k = 0; k < order.size(); k++) order[k] = k;
    std::stable_sort(order.begin(), order.end(), [&](size_t a, size_t b) { return ids[a] < ids[b]; });
    for (size_t k : order) rows.push_back({ids[k], recordOf(t.rows[k], skip)});
    uint32_t root = w.tableTree(rows);
    master.push_back({"table", t.name, t.name, t.sql.empty() ? createTableSql(t) : t.sql, root});
    for (const auto &ix : t.indexes) {
      std::vector<size_t> colIdx;
      for (const auto &cn : ix.second)
        for (size_t c = 0; c < t.cols.size(); c++) if (t.cols[c].name == cn) colIdx.push_back(c);
      std::vector<std::pair<std::vector<Value>, int64_t>> entries;
      for (size_t r = 0; r < t.rows.size(); r++) {
        std::vector<Value> key;
        for (size_t c : colIdx) key.push_back(t.cols[c].rowidAlias ? Value(static_cast<double>(ids[r])) : t.rows[r][c]);
        entries.push_back({key, ids[r]});
      }
      std::stable_sort(entries.begin(), entries.end(), [](const auto &a, const auto &b) {
        for (size_t k = 0; k < a.first.size(); k++) { int c = compareValues(a.first[k], b.first[k]); if (c) return c < 0; }
        return a.second < b.second;
      });
      std::vector<std::string> keys;
      for (const auto &e : entries) {
        std::vector<Value> rec = e.first;
        rec.push_back(Value(static_cast<double>(e.second)));
        keys.push_back(recordOf(rec, {}));
      }
      uint32_t iroot = w.indexTree(keys);
      std::string cols;
      for (size_t k = 0; k < ix.second.size(); k++) cols += (k ? ", " : "") + sqlIdent(ix.second[k]);
      master.push_back({"index", ix.first, t.name, "CREATE INDEX " + sqlIdent(ix.first) + " ON " + sqlIdent(t.name) + " (" + cols + ")", iroot});
    }
  }
  for (const auto &v : db.views) master.push_back({"view", v.first, v.first, v.second, 0});
  for (const auto &s : db.otherSql) {
    std::string nm = "trigger";
    master.push_back({"trigger", nm, "", s, 0});
  }
  std::vector<std::pair<int64_t, std::string>> mrows;
  for (size_t k = 0; k < master.size(); k++) {
    const auto &m = master[k];
    mrows.push_back({static_cast<int64_t>(k + 1), recordOf({Value(m.type), Value(m.name), Value(m.tbl), Value(static_cast<double>(m.root)), Value(m.sql)}, {})});
  }
  uint32_t mroot = w.tableTree(mrows, 1, 100);
  if (mroot != 1)
    return std::string(); // sqlite_master must be rooted at page 1: the schema did not fit (caller reports it)
  std::string &h = w.pages[0];
  h.replace(0, 16, std::string("SQLite format 3\0", 16));
  setBE(h, 16, 4096, 2);
  h[18] = 1;
  h[19] = 1;
  h[20] = 0;
  h[21] = 64;
  h[22] = 32;
  h[23] = 32;
  setBE(h, 24, 1, 4);
  setBE(h, 28, w.pages.size(), 4);
  setBE(h, 40, 1, 4);
  setBE(h, 44, 4, 4);
  setBE(h, 56, 1, 4);
  setBE(h, 92, 1, 4);
  setBE(h, 96, 3045000, 4);
  std::string out;
  for (const auto &p : w.pages) out += p;
  return out;
}

} // namespace io
} // namespace nc
