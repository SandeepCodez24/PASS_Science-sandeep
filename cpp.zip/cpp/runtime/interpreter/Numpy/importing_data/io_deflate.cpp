// DEFLATE / zlib / gzip - see io_deflate.h.
//
// Decoder: the full RFC 1951 format (stored, fixed and dynamic Huffman
// blocks). Encoder: LZ77 with a hash chain, emitted as one fixed-Huffman
// block per 64 KB of input - smaller than optimal dynamic Huffman, but always
// valid and readable by every inflater.
#include "io_deflate.h"

#include <array>
#include <cstring>
#include <vector>

namespace nc {
namespace io {

uint32_t crc32(const void *data, size_t n, uint32_t crc) {
  static uint32_t table[256];
  static bool ready = false;
  if (!ready) {
    for (uint32_t i = 0; i < 256; i++) {
      uint32_t c = i;
      for (int k = 0; k < 8; k++)
        c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
      table[i] = c;
    }
    ready = true;
  }
  const unsigned char *p = static_cast<const unsigned char *>(data);
  crc = ~crc;
  for (size_t i = 0; i < n; i++)
    crc = table[(crc ^ p[i]) & 0xFF] ^ (crc >> 8);
  return ~crc;
}

uint32_t adler32(const void *data, size_t n, uint32_t adler) {
  const unsigned char *p = static_cast<const unsigned char *>(data);
  uint32_t a = adler & 0xFFFF, b = adler >> 16;
  for (size_t i = 0; i < n; i++) {
    a = (a + p[i]) % 65521;
    b = (b + a) % 65521;
  }
  return (b << 16) | a;
}

namespace {

const uint16_t kLenBase[29] = {3,  4,  5,  6,  7,  8,  9,  10, 11,  13,  15,  17,  19,  23, 27,
                               31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
const uint8_t kLenExtra[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2,
                               2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
const uint16_t kDistBase[30] = {1,   2,   3,   4,   5,   7,    9,    13,   17,   25,
                                33,  49,  65,  97,  129, 193,  257,  385,  513,  769,
                                1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
const uint8_t kDistExtra[30] = {0, 0, 0, 0, 1, 1, 2, 2,  3,  3,  4,  4,  5,  5,  6,
                                6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

// ---- decoder --------------------------------------------------------------

struct BitReader {
  const std::string &s;
  size_t pos;
  uint32_t bitBuf = 0;
  int bitCount = 0;
  bool overrun = false;
  BitReader(const std::string &src, size_t start) : s(src), pos(start) {}
  int bit() {
    if (bitCount == 0) {
      if (pos >= s.size()) {
        overrun = true;
        return 0;
      }
      bitBuf = static_cast<unsigned char>(s[pos++]);
      bitCount = 8;
    }
    int b = bitBuf & 1;
    bitBuf >>= 1;
    bitCount--;
    return b;
  }
  uint32_t bits(int n) {
    uint32_t v = 0;
    for (int i = 0; i < n; i++)
      v |= static_cast<uint32_t>(bit()) << i;
    return v;
  }
  void alignByte() { bitCount = 0; }
};

// Canonical Huffman decoding table (counts per length + symbols by code).
struct Huffman {
  std::array<uint16_t, 16> count{};
  std::vector<uint16_t> symbol;
  bool build(const uint8_t *lengths, int n) {
    count.fill(0);
    for (int i = 0; i < n; i++)
      count[lengths[i]]++;
    count[0] = 0;
    int left = 1;
    for (int len = 1; len < 16; len++) {
      left <<= 1;
      left -= count[len];
      if (left < 0)
        return false; // over-subscribed
    }
    std::array<uint16_t, 16> offs{};
    for (int len = 1; len < 15; len++)
      offs[len + 1] = offs[len] + count[len];
    symbol.assign(n, 0);
    for (int i = 0; i < n; i++)
      if (lengths[i])
        symbol[offs[lengths[i]]++] = static_cast<uint16_t>(i);
    return true;
  }
  int decode(BitReader &br) const {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len < 16; len++) {
      code |= br.bit();
      int c = count[len];
      if (code - c < first)
        return symbol[index + (code - first)];
      index += c;
      first += c;
      first <<= 1;
      code <<= 1;
      if (br.overrun)
        return -1;
    }
    return -1;
  }
};

bool inflateBlock(BitReader &br, std::string &out, const Huffman &lit, const Huffman &dist,
                  std::string &err) {
  for (;;) {
    int sym = lit.decode(br);
    if (sym < 0 || br.overrun) {
      err = "corrupt deflate data (bad literal/length code)";
      return false;
    }
    if (sym < 256) {
      out.push_back(static_cast<char>(sym));
      continue;
    }
    if (sym == 256)
      return true;
    sym -= 257;
    if (sym >= 29) {
      err = "corrupt deflate data (bad length symbol)";
      return false;
    }
    size_t len = kLenBase[sym] + br.bits(kLenExtra[sym]);
    int ds = dist.decode(br);
    if (ds < 0 || ds >= 30) {
      err = "corrupt deflate data (bad distance code)";
      return false;
    }
    size_t d = kDistBase[ds] + br.bits(kDistExtra[ds]);
    if (d > out.size()) {
      err = "corrupt deflate data (distance too far back)";
      return false;
    }
    size_t from = out.size() - d;
    for (size_t i = 0; i < len; i++)
      out.push_back(out[from + i]);
  }
}

// ---- encoder --------------------------------------------------------------

struct BitWriter {
  std::string out;
  uint32_t buf = 0;
  int count = 0;
  void put(uint32_t value, int n) { // LSB first
    for (int i = 0; i < n; i++) {
      buf |= ((value >> i) & 1u) << count;
      if (++count == 8) {
        out.push_back(static_cast<char>(buf));
        buf = 0;
        count = 0;
      }
    }
  }
  void putHuff(uint32_t code, int n) { // Huffman codes go MSB first
    for (int i = n - 1; i >= 0; i--)
      put((code >> i) & 1u, 1);
  }
  void flush() {
    if (count) {
      out.push_back(static_cast<char>(buf));
      buf = 0;
      count = 0;
    }
  }
};

void fixedLit(BitWriter &bw, int sym) {
  if (sym < 144)
    bw.putHuff(0x30 + sym, 8);
  else if (sym < 256)
    bw.putHuff(0x190 + (sym - 144), 9);
  else if (sym < 280)
    bw.putHuff(sym - 256, 7);
  else
    bw.putHuff(0xC0 + (sym - 280), 8);
}

void putMatch(BitWriter &bw, int len, int dist) {
  int li = 28;
  for (int i = 0; i < 29; i++)
    if (kLenBase[i] > len) {
      li = i - 1;
      break;
    }
  fixedLit(bw, 257 + li);
  bw.put(len - kLenBase[li], kLenExtra[li]);
  int di = 29;
  for (int i = 0; i < 30; i++)
    if (kDistBase[i] > dist) {
      di = i - 1;
      break;
    }
  bw.putHuff(di, 5);
  bw.put(dist - kDistBase[di], kDistExtra[di]);
}

} // namespace

bool inflateRaw(const std::string &in, size_t start, std::string &out, std::string &err,
                size_t *consumed) {
  BitReader br(in, start);
  out.clear();
  for (;;) {
    int final = br.bit();
    int type = static_cast<int>(br.bits(2));
    if (br.overrun) {
      err = "deflate data ends early";
      return false;
    }
    if (type == 0) {
      br.alignByte();
      if (br.pos + 4 > in.size()) {
        err = "deflate data ends early";
        return false;
      }
      unsigned len = static_cast<unsigned char>(in[br.pos]) |
                     (static_cast<unsigned char>(in[br.pos + 1]) << 8);
      br.pos += 4;
      if (br.pos + len > in.size()) {
        err = "deflate stored block ends early";
        return false;
      }
      out.append(in, br.pos, len);
      br.pos += len;
    } else if (type == 1) {
      static Huffman lit, dist;
      static bool ready = false;
      if (!ready) {
        uint8_t l[288];
        for (int i = 0; i < 144; i++) l[i] = 8;
        for (int i = 144; i < 256; i++) l[i] = 9;
        for (int i = 256; i < 280; i++) l[i] = 7;
        for (int i = 280; i < 288; i++) l[i] = 8;
        lit.build(l, 288);
        uint8_t d[30];
        for (int i = 0; i < 30; i++) d[i] = 5;
        dist.build(d, 30);
        ready = true;
      }
      if (!inflateBlock(br, out, lit, dist, err))
        return false;
    } else if (type == 2) {
      int hlit = static_cast<int>(br.bits(5)) + 257;
      int hdist = static_cast<int>(br.bits(5)) + 1;
      int hclen = static_cast<int>(br.bits(4)) + 4;
      static const uint8_t order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
      uint8_t cl[19] = {0};
      for (int i = 0; i < hclen; i++)
        cl[order[i]] = static_cast<uint8_t>(br.bits(3));
      Huffman clh;
      if (!clh.build(cl, 19)) {
        err = "corrupt deflate data (code-length table)";
        return false;
      }
      uint8_t lens[320] = {0};
      int n = 0;
      while (n < hlit + hdist) {
        int sym = clh.decode(br);
        if (sym < 0 || br.overrun) {
          err = "corrupt deflate data (code lengths)";
          return false;
        }
        if (sym < 16) {
          lens[n++] = static_cast<uint8_t>(sym);
        } else {
          int rep = 0;
          uint8_t val = 0;
          if (sym == 16) {
            if (n == 0) {
              err = "corrupt deflate data (repeat with no previous length)";
              return false;
            }
            val = lens[n - 1];
            rep = 3 + static_cast<int>(br.bits(2));
          } else if (sym == 17) {
            rep = 3 + static_cast<int>(br.bits(3));
          } else {
            rep = 11 + static_cast<int>(br.bits(7));
          }
          if (n + rep > hlit + hdist) {
            err = "corrupt deflate data (too many code lengths)";
            return false;
          }
          while (rep--)
            lens[n++] = val;
        }
      }
      Huffman lit, dist;
      if (!lit.build(lens, hlit) || !dist.build(lens + hlit, hdist)) {
        err = "corrupt deflate data (Huffman tables)";
        return false;
      }
      if (!inflateBlock(br, out, lit, dist, err))
        return false;
    } else {
      err = "corrupt deflate data (reserved block type)";
      return false;
    }
    if (final)
      break;
  }
  if (consumed)
    *consumed = br.pos - start;
  return true;
}

std::string deflateRaw(const std::string &in, int level) {
  BitWriter bw;
  if (level <= 0 || in.empty()) {
    size_t pos = 0;
    do {
      size_t len = std::min<size_t>(65535, in.size() - pos);
      bool final = pos + len >= in.size();
      bw.put(final ? 1 : 0, 1);
      bw.put(0, 2);
      bw.flush();
      bw.out.push_back(static_cast<char>(len & 0xFF));
      bw.out.push_back(static_cast<char>(len >> 8));
      bw.out.push_back(static_cast<char>(~len & 0xFF));
      bw.out.push_back(static_cast<char>((~len >> 8) & 0xFF));
      bw.out.append(in, pos, len);
      pos += len;
    } while (pos < in.size());
    return bw.out;
  }
  const int kWindow = 32768, kHashBits = 15, kHashSize = 1 << kHashBits;
  const int maxChain = level >= 9 ? 256 : level >= 6 ? 64 : level >= 3 ? 16 : 4;
  std::vector<int> head(kHashSize, -1), prev(in.size(), -1);
  const unsigned char *p = reinterpret_cast<const unsigned char *>(in.data());
  const size_t n = in.size();
  auto hashAt = [&](size_t i) {
    return ((p[i] << 10) ^ (p[i + 1] << 5) ^ p[i + 2]) & (kHashSize - 1);
  };
  const size_t kBlock = 65536;
  size_t i = 0;
  while (i < n) {
    size_t blockEnd = std::min(n, i + kBlock);
    bw.put(blockEnd >= n ? 1 : 0, 1);
    bw.put(1, 2); // fixed Huffman
    while (i < blockEnd) {
      int bestLen = 0, bestDist = 0;
      if (i + 2 < n) {
        int h = hashAt(i);
        int cand = head[h];
        int chain = maxChain;
        const size_t maxLen = std::min<size_t>(258, n - i);
        while (cand >= 0 && chain-- > 0 && static_cast<int>(i) - cand <= kWindow) {
          size_t l = 0;
          while (l < maxLen && p[cand + l] == p[i + l])
            l++;
          if (static_cast<int>(l) > bestLen) {
            bestLen = static_cast<int>(l);
            bestDist = static_cast<int>(i) - cand;
            if (l == maxLen)
              break;
          }
          cand = prev[cand];
        }
        prev[i] = head[h];
        head[h] = static_cast<int>(i);
      }
      if (bestLen >= 3) {
        putMatch(bw, bestLen, bestDist);
        for (int k = 1; k < bestLen; k++) {
          size_t j = i + k;
          if (j + 2 < n) {
            int h = hashAt(j);
            prev[j] = head[h];
            head[h] = static_cast<int>(j);
          }
        }
        i += bestLen;
      } else {
        fixedLit(bw, p[i]);
        i++;
      }
    }
    fixedLit(bw, 256);
  }
  bw.flush();
  return bw.out;
}

bool isGzip(const std::string &bytes) {
  return bytes.size() >= 18 && static_cast<unsigned char>(bytes[0]) == 0x1F &&
         static_cast<unsigned char>(bytes[1]) == 0x8B;
}

std::string gzipCompress(const std::string &in, int level) {
  std::string out("\x1F\x8B\x08\x00\x00\x00\x00\x00\x00\xFF", 10);
  out += deflateRaw(in, level);
  uint32_t crc = crc32(in.data(), in.size());
  uint32_t size = static_cast<uint32_t>(in.size());
  for (int k = 0; k < 4; k++)
    out.push_back(static_cast<char>((crc >> (8 * k)) & 0xFF));
  for (int k = 0; k < 4; k++)
    out.push_back(static_cast<char>((size >> (8 * k)) & 0xFF));
  return out;
}

bool gzipDecompress(const std::string &in, std::string &out, std::string &err) {
  out.clear();
  size_t pos = 0;
  // A gzip file may hold several members back to back.
  while (pos + 18 <= in.size() && static_cast<unsigned char>(in[pos]) == 0x1F &&
         static_cast<unsigned char>(in[pos + 1]) == 0x8B) {
    if (in[pos + 2] != 8) {
      err = "gzip: unknown compression method";
      return false;
    }
    unsigned flags = static_cast<unsigned char>(in[pos + 3]);
    size_t p = pos + 10;
    if (flags & 4) { // FEXTRA
      if (p + 2 > in.size()) { err = "gzip header ends early"; return false; }
      size_t xlen = static_cast<unsigned char>(in[p]) | (static_cast<unsigned char>(in[p + 1]) << 8);
      p += 2 + xlen;
    }
    if (flags & 8) // FNAME
      while (p < in.size() && in[p++] != 0) {}
    if (flags & 16) // FCOMMENT
      while (p < in.size() && in[p++] != 0) {}
    if (flags & 2)
      p += 2;
    std::string member;
    size_t used = 0;
    if (!inflateRaw(in, p, member, err, &used))
      return false;
    p += used;
    if (p + 8 > in.size()) {
      err = "gzip trailer missing";
      return false;
    }
    uint32_t crc = 0;
    for (int k = 0; k < 4; k++)
      crc |= static_cast<uint32_t>(static_cast<unsigned char>(in[p + k])) << (8 * k);
    if (crc != crc32(member.data(), member.size())) {
      err = "gzip CRC mismatch (file is damaged)";
      return false;
    }
    out += member;
    pos = p + 8;
  }
  return true;
}

std::string zlibCompress(const std::string &in, int level) {
  std::string out("\x78\x9C", 2);
  out += deflateRaw(in, level);
  uint32_t a = adler32(in.data(), in.size());
  for (int k = 3; k >= 0; k--)
    out.push_back(static_cast<char>((a >> (8 * k)) & 0xFF));
  return out;
}

bool zlibDecompress(const std::string &in, std::string &out, std::string &err) {
  if (in.size() < 6 || (static_cast<unsigned char>(in[0]) & 0x0F) != 8) {
    err = "not a zlib stream";
    return false;
  }
  return inflateRaw(in, 2, out, err);
}

} // namespace io
} // namespace nc
