// Decoded audio shared by CATEGORY 15 (io_audio.cpp) and the video
// containers (io_video.cpp), which mux / demux PCM audio tracks.
#ifndef NC_IO_AUDIO_H
#define NC_IO_AUDIO_H

#include <string>
#include <utility>
#include <vector>

#include "io_common.h"

namespace nc {
namespace io {

struct Audio {
  size_t fs = 44100, channels = 1, frames = 0;
  int bits = 16;
  bool isFloat = false;
  std::vector<double> samples; // interleaved, normalized to [-1, 1]
  std::vector<std::pair<std::string, std::string>> tags;
  std::vector<double> cues;    // seconds
  std::string codec;
  double duration() const { return fs ? static_cast<double>(frames) / fs : 0; }
};

// The NcAudio object of load_wav(...).
Value audioObject(const Audio &au, const std::string &file, const std::string &fmt);
// waveform vector / (samples, channels) matrix / NcAudio -> Audio
bool valueToAudio(const Value &v, double fs, Audio &au, std::string &err);

} // namespace io
} // namespace nc

#endif // NC_IO_AUDIO_H
