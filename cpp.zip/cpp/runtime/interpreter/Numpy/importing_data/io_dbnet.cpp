// PostgreSQL (protocol 3.0) and MySQL (protocol 41) clients, hand-written.
// Plain TCP: servers that insist on TLS are reported clearly.
#include <algorithm>
#include <cmath>
#include <functional>
#include <map>

#include "../numpy_common.h"
#include "io_bytes.h"
#include "io_database.h"
#include "io_net.h"
#include "io_sql.h"

namespace nc {
namespace io {
namespace {

Value typedCell(const std::string &s, bool numeric, bool boolean) {
  if (boolean) return Value::boolean(s == "t" || s == "1" || s == "true");
  if (numeric) {
    char *e = nullptr;
    double d = std::strtod(s.c_str(), &e);
    if (e && *e == '\0') return Value(d);
  }
  return Value(s);
}

std::string insertSql(const std::string &dialect, const std::string &ref, const WriteRequest &req, size_t from, size_t to,
                      const std::vector<std::string> &keys) {
  auto col = [&](const std::string &c) { return dialect == "mysql" ? "`" + c + "`" : sqlIdent(c); };
  std::string s = "INSERT INTO " + ref + " (";
  for (size_t c = 0; c < req.data.cols.size(); c++) s += (c ? ", " : "") + col(req.data.cols[c]);
  s += ") VALUES ";
  for (size_t r = from; r < to; r++) {
    s += r > from ? ", (" : "(";
    for (size_t c = 0; c < req.data.cols.size(); c++) s += (c ? ", " : "") + sqlLiteral(req.data.rows[r][c]);
    s += ")";
  }
  if (req.mode == "upsert") {
    if (dialect == "postgresql") {
      s += " ON CONFLICT (";
      for (size_t k = 0; k < keys.size(); k++) s += (k ? ", " : "") + col(keys[k]);
      s += ") DO UPDATE SET ";
      bool first = true;
      for (const auto &c : req.data.cols)
        if (std::find(keys.begin(), keys.end(), c) == keys.end()) { s += (first ? "" : ", ") + col(c) + " = EXCLUDED." + col(c); first = false; }
      if (first) s.erase(s.rfind(" DO UPDATE SET ")), s += " DO NOTHING";
    } else {
      s += " ON DUPLICATE KEY UPDATE ";
      for (size_t c = 0; c < req.data.cols.size(); c++) s += (c ? ", " : "") + col(req.data.cols[c]) + " = VALUES(" + col(req.data.cols[c]) + ")";
    }
  }
  return s;
}

// shared write logic over an exec() function
bool writeVia(DbBackend &b, const std::function<bool(const std::string &, std::string &)> &exec, const WriteRequest &req,
              const std::string &ref, std::string &err) {
  const std::string d = b.dialect();
  auto col = [&](const std::string &c) { return d == "mysql" ? "`" + c + "`" : sqlIdent(c); };
  std::vector<std::string> tl, vl;
  if (!b.tables(req.schema, tl, vl, err)) return false;
  bool exists = false;
  for (const auto &t : tl) if (lower(t) == lower(req.table)) exists = true;
  if (exists && req.mode == "fail") { err = "table '" + req.table + "' already exists (mode=\"fail\")"; return false; }
  if (!exec("BEGIN", err)) return false;
  auto rollback = [&]() { std::string e2; exec("ROLLBACK", e2); return false; };
  if (exists && req.mode == "replace") { if (!exec("DROP TABLE " + ref, err)) return rollback(); exists = false; }
  std::vector<std::string> keys = req.conflict.empty() ? req.pk : req.conflict;
  if (req.mode == "upsert" && keys.empty()) { err = "mode=\"upsert\" needs pk= or conflict_cols="; return rollback(); }
  if (!exists) {
    std::string s = "CREATE TABLE " + ref + " (";
    for (size_t c = 0; c < req.data.cols.size(); c++) {
      const std::string &n = req.data.cols[c];
      std::string type = req.dtype.count(n) ? optText(req.dtype.at(n)) : sqlType(d, req.data, c);
      if (d == "mysql" && type == "TEXT" && std::find(keys.begin(), keys.end(), n) != keys.end()) type = "VARCHAR(255)";
      s += (c ? ", " : "") + col(n) + " " + type;
    }
    std::vector<std::string> pk = req.pk.empty() && req.mode == "upsert" ? keys : req.pk;
    if (!pk.empty()) {
      s += ", PRIMARY KEY (";
      for (size_t k = 0; k < pk.size(); k++) s += (k ? ", " : "") + col(pk[k]);
      s += ")";
    }
    s += ")";
    if (d == "mysql" && !req.comment.empty()) s += " COMMENT=" + sqlQuote(req.comment);
    if (!exec(s, err)) return rollback();
  }
  for (size_t from = 0; from < req.data.rows.size(); from += req.batch) {
    size_t to = std::min(req.data.rows.size(), from + req.batch);
    if (!exec(insertSql(d, ref, req, from, to, keys), err)) return rollback();
  }
  for (const auto &ix : req.index) {
    std::string name = "idx_" + req.table + "_" + ix;
    std::string s = d == "postgresql" ? "CREATE INDEX IF NOT EXISTS " + sqlIdent(name) + " ON " + ref + " (" + col(ix) + ")"
                                      : "CREATE INDEX " + col(name) + " ON " + ref + " (" + col(ix) + (d == "mysql" ? "(191)" : "") + ")";
    std::string e2;
    if (!exec(s, e2) && d == "postgresql") { err = e2; return rollback(); } // MySQL: index may exist already
  }
  if (!req.comment.empty()) {
    std::string s = d == "postgresql" ? "COMMENT ON TABLE " + ref + " IS " + sqlQuote(req.comment) : "ALTER TABLE " + ref + " COMMENT = " + sqlQuote(req.comment);
    if (!exec(s, err)) return rollback();
  }
  return exec("COMMIT", err);
}

// ---- PostgreSQL --------------------------------------------------------------------------

class PgBackend : public DbBackend {
public:
  TcpConn conn;
  std::string dialect() const override { return "postgresql"; }

  bool readMsg(char &type, std::string &body, std::string &err) {
    std::string h;
    if (!conn.recv(5, h, err)) return false;
    type = h[0];
    uint32_t len = u32be(h, 1);
    return conn.recv(len - 4, body, err);
  }
  static std::string errorText(const std::string &body) {
    std::string msg, detail, code;
    size_t p = 0;
    while (p < body.size() && body[p]) {
      char f = body[p++];
      size_t e = body.find('\0', p);
      std::string v = body.substr(p, e - p);
      if (f == 'M') msg = v; else if (f == 'D') detail = v; else if (f == 'C') code = v;
      p = e + 1;
    }
    return "PostgreSQL: " + msg + (detail.empty() ? "" : " (" + detail + ")") + (code.empty() ? "" : " [" + code + "]");
  }
  bool sendMsg(char type, const std::string &body, std::string &err) {
    std::string m(1, type);
    putBE(m, body.size() + 4, 4);
    return conn.send(m + body, err);
  }
  bool open(const std::string &uri, std::string &err) {
    DbUri u;
    if (!u.parse(uri, err)) return false;
    if (!u.port) u.port = 5432;
    if (u.database.empty()) u.database = u.user;
    if (!conn.connect(u.host, u.port, err)) return false;
    std::string body;
    putBE(body, 196608, 4);
    for (const auto &kv : std::vector<std::pair<std::string, std::string>>{{"user", u.user}, {"database", u.database}, {"client_encoding", "UTF8"}, {"application_name", "NC"}})
      body += kv.first + '\0' + kv.second + '\0';
    body.push_back('\0');
    std::string m;
    putBE(m, body.size() + 4, 4);
    if (!conn.send(m + body, err)) return false;
    std::string clientFirstBare, nonce, salted, authMsg;
    for (;;) {
      char t;
      std::string b;
      if (!readMsg(t, b, err)) return false;
      if (t == 'E') { err = errorText(b); return false; }
      if (t == 'Z') return true;
      if (t != 'R') continue;
      uint32_t code = u32be(b, 0);
      if (code == 0) continue;
      if (code == 3) { if (!sendMsg('p', u.password + '\0', err)) return false; continue; }
      if (code == 5) {
        std::string inner = hexOf(md5(u.password + u.user));
        if (!sendMsg('p', "md5" + hexOf(md5(inner + b.substr(4, 4))) + '\0', err)) return false;
        continue;
      }
      if (code == 10) {
        if (b.find("SCRAM-SHA-256") == std::string::npos) { err = "PostgreSQL asks for an authentication method NC does not have (only SCRAM-SHA-256 / md5 / password)"; return false; }
        nonce = base64Encode(randomBytes(18));
        clientFirstBare = "n=,r=" + nonce;
        std::string first = "n,," + clientFirstBare, msg = std::string("SCRAM-SHA-256") + '\0';
        putBE(msg, first.size(), 4);
        msg += first;
        if (!sendMsg('p', msg, err)) return false;
        continue;
      }
      if (code == 11) {
        std::string serverFirst = b.substr(4);
        std::string r, s;
        int iter = 4096;
        size_t p = 0;
        while (p < serverFirst.size()) {
          size_t e = serverFirst.find(',', p);
          if (e == std::string::npos) e = serverFirst.size();
          std::string kv = serverFirst.substr(p, e - p);
          if (kv.rfind("r=", 0) == 0) r = kv.substr(2);
          else if (kv.rfind("s=", 0) == 0) s = base64Decode(kv.substr(2));
          else if (kv.rfind("i=", 0) == 0) iter = std::atoi(kv.c_str() + 2);
          p = e + 1;
        }
        if (r.rfind(nonce, 0) != 0) { err = "PostgreSQL SCRAM: the server nonce does not match"; return false; }
        salted = pbkdf2Sha256(u.password, s, iter);
        std::string clientKey = hmacSha256(salted, "Client Key"), stored = sha256(clientKey);
        std::string finalNoProof = "c=biws,r=" + r;
        authMsg = clientFirstBare + "," + serverFirst + "," + finalNoProof;
        std::string sig = hmacSha256(stored, authMsg), proof = clientKey;
        for (size_t k = 0; k < proof.size(); k++) proof[k] = static_cast<char>(proof[k] ^ sig[k]);
        if (!sendMsg('p', finalNoProof + ",p=" + base64Encode(proof), err)) return false;
        continue;
      }
      if (code == 12) continue; // SASL final (server signature)
      err = "PostgreSQL asks for authentication type " + std::to_string(code) + ", which is not built in";
      return false;
    }
  }
  bool run(const std::string &sql, Table *out, std::string &err) {
    if (!sendMsg('Q', sql + '\0', err)) return false;
    std::vector<std::pair<bool, bool>> kinds; // numeric, bool
    std::string firstError;
    for (;;) {
      char t;
      std::string b;
      if (!readMsg(t, b, err)) return false;
      if (t == 'T' && out) {
        out->cols.clear();
        out->rows.clear();
        kinds.clear();
        size_t n = u16be(b, 0), p = 2;
        for (size_t k = 0; k < n; k++) {
          size_t e = b.find('\0', p);
          out->cols.push_back(b.substr(p, e - p));
          p = e + 1;
          uint32_t oid = u32be(b, p + 6);
          p += 18;
          bool num = oid == 20 || oid == 21 || oid == 23 || oid == 26 || oid == 700 || oid == 701 || oid == 1700;
          kinds.push_back({num, oid == 16});
        }
      } else if (t == 'D' && out) {
        size_t n = u16be(b, 0), p = 2;
        std::vector<Value> row;
        for (size_t k = 0; k < n; k++) {
          int32_t len = static_cast<int32_t>(u32be(b, p));
          p += 4;
          if (len < 0) { row.push_back(Value(std::nan(""))); continue; }
          std::string v = b.substr(p, static_cast<size_t>(len));
          p += static_cast<size_t>(len);
          row.push_back(k < kinds.size() ? typedCell(v, kinds[k].first, kinds[k].second) : Value(v));
        }
        out->rows.push_back(std::move(row));
      } else if (t == 'E') {
        if (firstError.empty()) firstError = errorText(b);
      } else if (t == 'Z') {
        if (!firstError.empty()) { err = firstError; return false; }
        if (out) normalizeTable(*out);
        return true;
      }
    }
  }
  bool tables(const std::string &schema, std::vector<std::string> &t, std::vector<std::string> &v, std::string &err) override {
    Table r;
    if (!run("SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = " + sqlQuote(schema.empty() ? "public" : schema) + " ORDER BY table_name", &r, err)) return false;
    for (const auto &row : r.rows) (cellText(row[1]) == "VIEW" ? v : t).push_back(cellText(row[0]));
    return true;
  }
  bool describe(const std::string &schema, const std::string &table, DbTable &out, std::string &err) override {
    std::string sc = schema.empty() ? "public" : schema;
    Table r;
    if (!run("SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_schema = " + sqlQuote(sc) +
                 " AND table_name = " + sqlQuote(table) + " ORDER BY ordinal_position", &r, err))
      return false;
    if (r.rows.empty()) { err = "no table '" + sc + "." + table + "'"; return false; }
    out = DbTable();
    out.name = table;
    for (const auto &row : r.rows) { DbColumn c; c.name = cellText(row[0]); c.type = cellText(row[1]); c.notNull = cellText(row[2]) == "NO"; out.cols.push_back(c); }
    Table k;
    if (run("SELECT kcu.column_name, tc.constraint_type, ccu.table_name, ccu.column_name FROM information_schema.table_constraints tc "
            "JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema "
            "LEFT JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name "
            "WHERE tc.table_schema = " + sqlQuote(sc) + " AND tc.table_name = " + sqlQuote(table), &k, err))
      for (const auto &row : k.rows)
        for (auto &c : out.cols)
          if (c.name == cellText(row[0])) {
            if (cellText(row[1]) == "PRIMARY KEY") c.pk = true;
            if (cellText(row[1]) == "FOREIGN KEY") c.references = cellText(row[2]) + "(" + cellText(row[3]) + ")";
          }
    Table cm;
    if (run("SELECT obj_description(" + sqlQuote(sc + "." + table) + "::regclass, 'pg_class')", &cm, err) && !cm.rows.empty() && cm.rows[0][0].isText)
      out.comment = cm.rows[0][0].text();
    err.clear();
    return true;
  }
  bool query(const std::string &sql, const std::vector<Value> &params, Table &out, std::string &err) override {
    std::string bound;
    if (!bindParams(sql, params, bound, err)) return false;
    return run(bound, &out, err);
  }
  bool write(const WriteRequest &req, std::string &err) override {
    std::string ref = (req.schema.empty() ? "" : sqlIdent(req.schema) + ".") + sqlIdent(req.table);
    return writeVia(*this, [&](const std::string &s, std::string &e) { return run(s, nullptr, e); }, req, ref, err);
  }
};

// ---- MySQL ---------------------------------------------------------------------------------

class MyBackend : public DbBackend {
public:
  TcpConn conn;
  uint8_t seq = 0;
  std::string dialect() const override { return "mysql"; }

  bool readPacket(std::string &p, std::string &err) {
    p.clear();
    for (;;) {
      std::string h, part;
      if (!conn.recv(4, h, err)) return false;
      size_t len = static_cast<size_t>(getLE(h, 0, 3));
      seq = static_cast<uint8_t>(static_cast<unsigned char>(h[3]) + 1);
      if (!conn.recv(len, part, err)) return false;
      p += part;
      if (len < 0xFFFFFF) return true;
    }
  }
  bool writePacket(const std::string &p, std::string &err) {
    std::string h;
    putLE(h, p.size(), 3);
    h.push_back(static_cast<char>(seq++));
    return conn.send(h + p, err);
  }
  static std::string errText(const std::string &p) {
    size_t m = p.size() > 3 && p[3] == '#' ? 9 : 3;
    return "MySQL: " + p.substr(m) + " [" + std::to_string(u16le(p, 1)) + "]";
  }
  static uint64_t lenenc(const std::string &p, size_t &i) {
    unsigned char c = static_cast<unsigned char>(p[i++]);
    if (c < 0xFB) return c;
    if (c == 0xFC) { uint64_t v = getLE(p, i, 2); i += 2; return v; }
    if (c == 0xFD) { uint64_t v = getLE(p, i, 3); i += 3; return v; }
    if (c == 0xFE) { uint64_t v = getLE(p, i, 8); i += 8; return v; }
    return 0;
  }
  static std::string lenstr(const std::string &p, size_t &i) {
    uint64_t n = lenenc(p, i);
    std::string s = p.substr(i, static_cast<size_t>(n));
    i += static_cast<size_t>(n);
    return s;
  }
  static std::string scramble(const std::string &plugin, const std::string &pw, const std::string &nonce) {
    if (pw.empty()) return "";
    if (plugin == "caching_sha2_password") {
      std::string a = sha256(pw), b = sha256(sha256(a) + nonce);
      for (size_t k = 0; k < a.size(); k++) a[k] = static_cast<char>(a[k] ^ b[k]);
      return a;
    }
    std::string a = sha1(pw), b = sha1(nonce + sha1(a));
    for (size_t k = 0; k < a.size(); k++) a[k] = static_cast<char>(a[k] ^ b[k]);
    return a;
  }
  bool open(const std::string &uri, std::string &err) {
    DbUri u;
    if (!u.parse(uri, err)) return false;
    if (!u.port) u.port = 3306;
    if (!conn.connect(u.host, u.port, err)) return false;
    std::string p;
    if (!readPacket(p, err)) return false;
    if (static_cast<unsigned char>(p[0]) == 0xFF) { err = errText(p); return false; }
    size_t i = 1;
    i = p.find('\0', i) + 1; // server version
    i += 4;
    std::string nonce = p.substr(i, 8);
    i += 9;
    // capability flags (low word) - NC asks for its own set
    i += 2;
    i += 3; // charset, status
    // capability flags (high word)
    i += 2;
    size_t authLen = static_cast<unsigned char>(p[i]);
    i += 11;
    size_t part2 = std::max<size_t>(13, authLen > 8 ? authLen - 8 : 0);
    nonce += p.substr(i, part2 - 1);
    i += part2;
    std::string plugin = i < p.size() ? p.substr(i, p.find('\0', i) - i) : "mysql_native_password";
    const uint32_t CLIENT_LONG_PASSWORD = 1, CLIENT_CONNECT_WITH_DB = 8, CLIENT_PROTOCOL_41 = 512, CLIENT_TRANSACTIONS = 8192,
                   CLIENT_SECURE_CONNECTION = 32768, CLIENT_MULTI_RESULTS = 1 << 17, CLIENT_PLUGIN_AUTH = 1 << 19;
    uint32_t mine = CLIENT_LONG_PASSWORD | CLIENT_PROTOCOL_41 | CLIENT_TRANSACTIONS | CLIENT_SECURE_CONNECTION | CLIENT_MULTI_RESULTS | CLIENT_PLUGIN_AUTH;
    if (!u.database.empty()) mine |= CLIENT_CONNECT_WITH_DB;
    std::string auth = scramble(plugin, u.password, nonce);
    std::string r;
    putLE(r, mine, 4);
    putLE(r, 16777216, 4);
    r.push_back(45); // utf8mb4
    r.append(23, '\0');
    r += u.user + '\0';
    r.push_back(static_cast<char>(auth.size()));
    r += auth;
    if (!u.database.empty()) r += u.database + '\0';
    r += plugin + '\0';
    if (!writePacket(r, err)) return false;
    for (;;) {
      if (!readPacket(p, err)) return false;
      unsigned char h = static_cast<unsigned char>(p[0]);
      if (h == 0x00) return true;
      if (h == 0xFF) { err = errText(p); return false; }
      if (h == 0xFE) { // auth switch
        size_t e = p.find('\0', 1);
        plugin = p.substr(1, e - 1);
        nonce = p.substr(e + 1);
        if (!nonce.empty() && nonce.back() == '\0') nonce.pop_back();
        if (!writePacket(scramble(plugin, u.password, nonce), err)) return false;
        continue;
      }
      if (h == 0x01 && p.size() >= 2) {
        if (p[1] == 3) continue; // fast auth ok, OK follows
        err = "MySQL needs full caching_sha2 authentication, which requires TLS - log in once with the mysql client (to fill the server's cache) or use mysql_native_password";
        return false;
      }
    }
  }
  bool run(const std::string &sql, Table *out, std::string &err) {
    seq = 0;
    if (!writePacket(std::string(1, '\x03') + sql, err)) return false;
    std::string p;
    if (!readPacket(p, err)) return false;
    unsigned char h = static_cast<unsigned char>(p[0]);
    if (h == 0xFF) { err = errText(p); return false; }
    if (h == 0x00) return true;
    size_t i = 0;
    uint64_t ncols = lenenc(p, i);
    std::vector<std::pair<bool, bool>> kinds;
    std::vector<std::string> names;
    for (uint64_t k = 0; k < ncols; k++) {
      if (!readPacket(p, err)) return false;
      size_t j = 0;
      for (int s = 0; s < 4; s++) lenstr(p, j); // catalog schema table org_table
      names.push_back(lenstr(p, j));
      lenstr(p, j);
      j += 1 + 2 + 4;
      unsigned char type = static_cast<unsigned char>(p[j]);
      bool num = type <= 5 || type == 8 || type == 9 || type == 13 || type == 246;
      kinds.push_back({num, false});
    }
    if (!readPacket(p, err)) return false; // EOF
    if (out) { out->cols = names; out->rows.clear(); }
    for (;;) {
      if (!readPacket(p, err)) return false;
      unsigned char c = static_cast<unsigned char>(p[0]);
      if (c == 0xFE && p.size() < 9) break;
      if (c == 0xFF) { err = errText(p); return false; }
      std::vector<Value> row;
      size_t j = 0;
      for (uint64_t k = 0; k < ncols; k++) {
        if (static_cast<unsigned char>(p[j]) == 0xFB) { j++; row.push_back(Value(std::nan(""))); continue; }
        row.push_back(typedCell(lenstr(p, j), kinds[k].first, false));
      }
      if (out) out->rows.push_back(std::move(row));
    }
    if (out) normalizeTable(*out);
    return true;
  }
  bool tables(const std::string &, std::vector<std::string> &t, std::vector<std::string> &v, std::string &err) override {
    Table r;
    if (!run("SELECT TABLE_NAME, TABLE_TYPE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME", &r, err)) return false;
    for (const auto &row : r.rows) (cellText(row[1]) == "VIEW" ? v : t).push_back(cellText(row[0]));
    return true;
  }
  bool describe(const std::string &, const std::string &table, DbTable &out, std::string &err) override {
    Table r;
    if (!run("SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_KEY FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " +
                 sqlQuote(table) + " ORDER BY ORDINAL_POSITION", &r, err))
      return false;
    if (r.rows.empty()) { err = "no table '" + table + "'"; return false; }
    out = DbTable();
    out.name = table;
    for (const auto &row : r.rows) { DbColumn c; c.name = cellText(row[0]); c.type = cellText(row[1]); c.notNull = cellText(row[2]) == "NO"; c.pk = cellText(row[3]) == "PRI"; out.cols.push_back(c); }
    Table fk;
    if (run("SELECT COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " +
                sqlQuote(table) + " AND REFERENCED_TABLE_NAME IS NOT NULL", &fk, err))
      for (const auto &row : fk.rows) for (auto &c : out.cols) if (c.name == cellText(row[0])) c.references = cellText(row[1]) + "(" + cellText(row[2]) + ")";
    Table cm;
    if (run("SELECT TABLE_COMMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " + sqlQuote(table), &cm, err) && !cm.rows.empty())
      out.comment = cellText(cm.rows[0][0]);
    err.clear();
    return true;
  }
  bool query(const std::string &sql, const std::vector<Value> &params, Table &out, std::string &err) override {
    std::string bound;
    if (!bindParams(sql, params, bound, err)) return false;
    return run(bound, &out, err);
  }
  bool write(const WriteRequest &req, std::string &err) override {
    return writeVia(*this, [&](const std::string &s, std::string &e) { return run(s == "BEGIN" ? "START TRANSACTION" : s, nullptr, e); }, req, "`" + req.table + "`", err);
  }
};

} // namespace

std::unique_ptr<DbBackend> openPostgres(const std::string &uri, std::string &err) {
  auto b = std::make_unique<PgBackend>();
  if (!b->open(uri, err)) return nullptr;
  return b;
}

std::unique_ptr<DbBackend> openMysql(const std::string &uri, std::string &err) {
  auto b = std::make_unique<MyBackend>();
  if (!b->open(uri, err)) return nullptr;
  return b;
}

} // namespace io
} // namespace nc
