// Shared pieces of the read_* / load_* / save_* functions (Functions_Importing
// _Data.pdf): option reading, files, text encodings, tables, loaded objects,
// progress events, and registration.
//
// Conventions every format follows
//   read_<fmt>(file, ...)   returns the data itself (matrix / cell matrix /
//                           dict / text). [T, info] = read_<fmt>(...) also
//                           returns a dict of what was found around the data
//                           (cols, boxes, comments, ...).
//   load_<fmt>(file, ...)   returns an object (class "Nc<Kind>") read with
//                           dots: D.cols, D.ABC.cols, D.sheet("ABC").
//   save_<fmt>(file, data, ...) writes; returns the number of bytes written.
// Every option is a named input with a default; "" (or -1) means "not
// given", so any subset can be named in any order.
#ifndef NC_IO_COMMON_H
#define NC_IO_COMMON_H

#include <atomic>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "../numpy_registry.h"

namespace nc {
namespace io {

using numpy::CallContext;
using numpy::Registry;
using Fields = std::unordered_map<std::string, Value>;

// ---- progress / events (the UI hooks - see io_session.h) -----------------

struct IoEvent {
  std::string kind;     // "open", "progress", "done", "error", "saved"
  std::string function; // "read_csv"
  std::string file;
  double fraction = 0;  // 0..1 for "progress"
  std::string message;
};
using IoListener = std::function<void(const IoEvent &)>;
void setIoListener(IoListener listener); // empty function = no listener
void emitEvent(const IoEvent &e);
// Readers call this inside long loops; true = the user cancelled.
bool reportProgress(const std::string &function, const std::string &file, double fraction);
void requestCancel();
void clearCancel();
bool cancelRequested();

// ---- options --------------------------------------------------------------

// False for the "not given" markers: "" text, an empty array/matrix.
bool given(const Value &v);
std::string optText(const Value &v, const std::string &def = "");
bool optBool(const Value &v, bool def);
long long optInt(const Value &v, long long def);
double optNumber(const Value &v, double def);
// "A" or ["A", "B"] or 1xN / Nx1 text matrix -> list of texts.
std::vector<std::string> optTextList(const Value &v);
// Numbers of a number / array / matrix / range, flattened.
std::vector<double> optNumbers(const Value &v);
std::string lower(std::string s);
std::string trim(const std::string &s);

// A column / row / sheet selection: 1-based positions, or names.
struct Selector {
  bool all = true;
  std::vector<long long> positions; // 1-based
  std::vector<std::string> names;
};
bool parseSelector(const Value &v, Selector &out, std::string &err);
// Applies a selector to `count` items with names `names` -> 0-based indices.
bool resolveSelector(const Selector &sel, const std::vector<std::string> &names, size_t count,
                     std::vector<size_t> &out, std::string &err);

// "48kb", "5mb", "2 GB", "1200" -> bytes. False when it is not a size.
bool parseByteSize(const std::string &text, uint64_t &bytes);
std::string formatBytes(uint64_t n);

// ---- files ----------------------------------------------------------------

std::filesystem::path resolvePath(const std::string &path);
bool readFile(const std::string &path, std::string &bytes, std::string &err);
bool writeFile(const std::string &path, const std::string &bytes, bool append, std::string &err);
bool fileExists(const std::string &path);
uint64_t fileSize(const std::string &path);
std::string extensionOf(const std::string &path); // lower case, no dot
bool isUrl(const std::string &s);
// http:// and https:// GET (WinHTTP on Windows). False with err otherwise.
bool fetchUrl(const std::string &url, std::string &bytes, std::string &err);
// A local file or a URL.
bool readSource(const std::string &pathOrUrl, std::string &bytes, std::string &err);

// Undoes gzip when the bytes start with the gzip magic (any text format may
// be read straight from a .gz written with compress="gz").
bool autoDecompress(std::string &bytes, std::string &err);
// compress = "", "none", "no" -> unchanged; "gz"/"gzip"/"yes"/"zlib"; others
// -> error naming what is built in. `level` 1..9 (-1 = 6).
bool applyCompression(const std::string &codec, int level, std::string &bytes, std::string &err);
// Checks the byte budget of max_size="48kb" ("" = no budget).
bool checkMaxSize(const Value &maxSize, uint64_t bytes, std::string &err);

// Text encodings: utf-8 (BOM dropped), latin-1 / iso-8859-1 / cp1252,
// utf-16 / utf-16le / utf-16be (BOM honoured), ascii.
bool decodeText(const std::string &raw, const std::string &enc, std::string &utf8,
                std::string &err);
bool encodeText(const std::string &utf8, const std::string &enc, std::string &raw,
                std::string &err);

// ---- values ---------------------------------------------------------------

Value makeObject(const std::string &className, Fields fields);
bool isObjectOf(const Value &v, const std::string &className);
const Value *field(const Value &obj, const std::string &name);
Value textList(const std::vector<std::string> &items);
Value numberList(const std::vector<double> &items);
Value dictOf(const Fields &f);
// A cell of text as read from a file -> number, bool or text. `na` texts
// become NaN.
Value parseCell(const std::string &s, const std::vector<std::string> &na);
bool isNumberCell(const Value &v);
// Shortest text that reads back to the same double ("%.6f" when fmt given).
std::string numberText(double d, const std::string &fmt = "");
std::string cellText(const Value &v, const std::string &floatFmt = "");
// An identifier usable after a dot: "Max Temp (C)" -> "Max_Temp_C".
std::string fieldName(const std::string &raw);
// Unique, non-empty column names: blanks -> Col_<n>, repeats -> Name_2.
std::vector<std::string> uniqueNames(const std::vector<std::string> &raw);

// ---- tables ---------------------------------------------------------------

struct Table {
  std::vector<std::string> cols;
  std::vector<std::vector<Value>> rows; // every row cols.size() long
};
// The data block: a packed numeric matrix when every cell is a number, a
// cell matrix otherwise. 0 rows -> empty matrix.
Value tableData(const Table &t);
// Column `c` as a vector (numeric array or cell array).
Value tableColumn(const Table &t, size_t c);
std::string columnType(const Table &t, size_t c); // int64 float64 bool str datetime empty
Value tableSchema(const Table &t);
// The NcTable object: cols, rows (count), data, schema and one field per
// column (D.Temp). Extra fields are added on top.
Value tableObject(const Table &t, Fields extra = {}, const std::string &cls = "NcTable");
// Any table-like value -> Table: NcTable object, matrix, cell matrix (a text
// first row is a header when `firstRowHeader`), array (one column), dict of
// equal-length columns.
bool valueToTable(const Value &v, Table &t, std::string &err, bool firstRowHeader = false);
// Rows / columns selection on a table (1-based selectors).
bool selectTable(Table &t, const Value &cols, const Value &rows, std::string &err);
// Returns a deduplicated list of columns padded to equal length.
void normalizeTable(Table &t);

// Row-major (C order) numbers -> NC array / matrix / N-D matrix of `shape`
// (NC keeps N-D data as column-major pages; this does the reordering).
Value ndFromRowMajor(const std::vector<size_t> &shape, const std::vector<double> &vals);
// NC array / matrix / N-D -> row-major numbers and shape.
bool ndToRowMajor(const Value &v, std::vector<size_t> &shape, std::vector<double> &vals);

// ---- registration ---------------------------------------------------------

using MultiFn = std::function<void(const std::vector<Value> &args, size_t nout,
                                   std::vector<Value> &out, CallContext &ctx)>;
using SingleFn = std::function<Value(const std::vector<Value> &args, CallContext &ctx)>;
// Registers `name` with its parameter line; min/max counts come from it.
void addFn(Registry &reg, const std::string &name, const std::string &params,
           const std::string &summary, const std::string &origin, SingleFn fn);
void addMulti(Registry &reg, const std::string &name, const std::string &params,
              const std::string &summary, const std::string &origin, int maxOutputs, MultiFn fn);
// Every function name registered through addFn/addMulti, for the session API.
const std::vector<std::string> &registeredIoNames();

// Wraps a reader with the open/done/error events.
struct EventScope {
  std::string function, file;
  bool ok = false;
  EventScope(const std::string &fn, const std::string &f);
  ~EventScope();
};

} // namespace io
} // namespace nc

#endif // NC_IO_COMMON_H
