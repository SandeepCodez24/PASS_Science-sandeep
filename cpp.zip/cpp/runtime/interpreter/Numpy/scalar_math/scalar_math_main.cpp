// Section 8 of 11 - Scalar Math
// Planned entries: 38  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. Nothing outside this folder needs to change when you add one.
//
// Implemented here (all names lowercase; every one works on a single value,
// an array or a matrix, element by element):
//
//   NC call                 NumPy               notes
//   floor_divide(A, n)      np.floor_divide     rounds DOWN (-7, 2 -> -4); `//` truncates
//   power(A, n)             np.power            always element-wise; A^n is matrix power
//                                               for whole n, element-wise otherwise
//   reciprocal(A)           np.reciprocal       1/x per element (1/A is matrix inverse)
//   clip(A, lo, hi)         np.clip             every element limited to [lo, hi]
//   bitwise_and(A, B)       np.bitwise_and      whole numbers / integer types / true-false
//   bitwise_or(A, B)        np.bitwise_or
//   bitwise_xor(A, B)       np.bitwise_xor
//   left_shift(A, n)        np.left_shift       overflow is an error, never wraps
//   right_shift(A, n)       np.right_shift      rounds down, like NumPy
//   bitwise_count(A)        np.bitwise_count    set bits of |x|
//   invert(A)               np.invert           true/false values only
//
// Done outside this folder (they are operators or constants, not calls):
//   A > 2, A >= 2, A < 2, A <= 2, A == 3, A != 3   conditional_opr/value_compare.cpp
//   nan, inf, -inf, euler_gamma                      builtins/constants_builtin.cpp
//                                                    (a script variable named
//                                                    euler_gamma wins over it)
//
// Shape rules for the two-argument functions (same as NC's +, -, ...):
// container with a single value, or two containers of the same kind and size.
// Anything else (3x3 with 2x2, a matrix with an array) is an error.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        scalar_math/sm_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerScalarMath() below.
//   2. Register it with reg.add({...}) - see registerScalarMath() at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("scalar_math")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Every function's inputs are listed once in kScalarMathParams (bottom of
//     this file) as a parameter line (core/param_list.h); that line decides
//     which values a call may name, e.g. clip(A, lo=0, hi=1). The code reads
//     its arguments by position.
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "scalar_math_main.h"

#include <cmath>
#include <complex>
#include <cstdint>
#include <cstdio>
#include <functional>
#include <string>
#include <vector>

#include "../numpy_common.h"
#include "../../core/elementwise.h"
#include "../../ops/arithmetic/arithmetic.h"
#include "../../ops/integer/integer.h"

namespace nc {
namespace numpy {

namespace {

/* ======================================================================
   Element-wise drivers
   ====================================================================== */

// Computes one result element; false (with `err`) rejects the call.
using ElemFn1 = std::function<bool(const Value &x, Value &out, std::string &err)>;
using ElemFn2 = std::function<bool(const Value &x, const Value &y, Value &out, std::string &err)>;

bool isContainer(const Value &v) { return v.isArray || v.isMatrix; }

std::string describe(const Value &v) {
  if (v.isMatrix)
    return "a " + std::to_string(v.rows()) + "x" + std::to_string(v.cols()) + " matrix";
  if (v.isArray)
    return "an array of length " + std::to_string(v.length());
  if (v.isText)
    return "text";
  if (v.isDict)
    return "a dict";
  if (v.isObject)
    return "an object";
  if (v.isFunctionRef)
    return "a function reference";
  if (v.isBool())
    return "true/false";
  if (v.isComplex)
    return "a complex number";
  return "a number";
}

bool isRectangular(const Value &m) {
  for (size_t r = 0; r < m.rows(); r++)
    if (m.rowLength(r) != m.cols())
      return false;
  return true;
}

// fn applied to every element (or to the single value). Result has the
// input's shape; plain-number results are stored in the compact packed form
// automatically by Value's constructors.
bool mapValues(const Value &a, const ElemFn1 &fn, CallContext &ctx, Value &out) {
  std::string err;
  if (a.isMatrix) {
    if (!isRectangular(a)) {
      ctx.fail("the matrix rows have different lengths");
      return false;
    }
    std::vector<std::vector<Value>> rows(a.rows());
    for (size_t r = 0; r < a.rows(); r++) {
      rows[r].resize(a.cols());
      for (size_t c = 0; c < a.cols(); c++)
        if (!fn(a.at(r, c), rows[r][c], err)) {
          ctx.fail(err);
          return false;
        }
    }
    out = Value(std::move(rows));
    return true;
  }
  if (a.isArray) {
    std::vector<Value> elems(a.length());
    for (size_t i = 0; i < a.length(); i++)
      if (!fn(a.at(i), elems[i], err)) {
        ctx.fail(err);
        return false;
      }
    out = Value(std::move(elems));
    return true;
  }
  if (!fn(a, out, err)) {
    ctx.fail(err);
    return false;
  }
  return true;
}

// fn applied to element pairs: container with a single value (broadcast), or
// two containers of the same kind and size.
bool zipValues(const Value &a, const Value &b, const ElemFn2 &fn, CallContext &ctx, Value &out) {
  const bool aC = isContainer(a), bC = isContainer(b);
  std::string err;

  if (!aC && !bC) {
    if (!fn(a, b, out, err)) {
      ctx.fail(err);
      return false;
    }
    return true;
  }

  if (aC && bC) {
    bool same = a.isMatrix == b.isMatrix;
    if (same && a.isMatrix) {
      if (!isRectangular(a) || !isRectangular(b)) {
        ctx.fail("the matrix rows have different lengths");
        return false;
      }
      same = a.rows() == b.rows() && a.cols() == b.cols();
    } else if (same) {
      same = a.length() == b.length();
    }
    if (!same) {
      ctx.fail("cannot combine " + describe(a) + " with " + describe(b) +
               " - both must have the same size, or one must be a single value");
      return false;
    }
  } else {
    const Value &single = aC ? b : a;
    if (single.isDict || single.isObject || single.isFunctionRef) {
      ctx.fail("cannot combine " + describe(a) + " with " + describe(b));
      return false;
    }
  }

  const Value &shape = aC ? a : b;
  if (shape.isMatrix) {
    if (!isRectangular(shape)) {
      ctx.fail("the matrix rows have different lengths");
      return false;
    }
    std::vector<std::vector<Value>> rows(shape.rows());
    for (size_t r = 0; r < shape.rows(); r++) {
      rows[r].resize(shape.cols());
      for (size_t c = 0; c < shape.cols(); c++)
        if (!fn(aC ? a.at(r, c) : a, bC ? b.at(r, c) : b, rows[r][c], err)) {
          ctx.fail(err);
          return false;
        }
    }
    out = Value(std::move(rows));
    return true;
  }

  std::vector<Value> elems(shape.length());
  for (size_t i = 0; i < shape.length(); i++)
    if (!fn(aC ? a.at(i) : a, bC ? b.at(i) : b, elems[i], err)) {
      ctx.fail(err);
      return false;
    }
  out = Value(std::move(elems));
  return true;
}

// A plain real number element: not text, a container, a dict/object/function
// reference, or complex. Bools and integer types qualify (their .number
// mirrors the value).
bool isRealNumber(const Value &v) {
  return !v.isText && !v.isArray && !v.isMatrix && !v.isDict && !v.isObject && !v.isFunctionRef &&
         !v.isComplex;
}

// An argument that is a number, array or matrix (what the element-wise
// arithmetic helpers accept).
bool checkNumericArg(const std::vector<Value> &args, size_t i, CallContext &ctx) {
  const Value &v = args[i];
  if (v.isText || v.isDict || v.isObject || v.isFunctionRef) {
    ctx.fail("the " + ordinal(i) + " argument must be a number, array or matrix, not " +
             describe(v));
    return false;
  }
  return true;
}

void copyUnit(const Value &from, Value &to) {
  to.dimL = from.dimL;
  to.dimT = from.dimT;
  to.dimM = from.dimM;
}

/* ======================================================================
   Whole numbers for the bitwise functions
   ====================================================================== */

// Largest magnitude a plain float64 holds exactly as a whole number.
constexpr double kExactLimit = 9007199254740992.0; // 2^53

struct Whole {
  enum Kind { Plain, Bool, Typed } kind = Plain;
  IntType type = IntType::None; // Typed only
  bool isUnsigned = false;      // Typed only
  int64_t s = 0;                // Plain, Bool, Typed signed
  uint64_t u = 0;               // Typed unsigned
};

bool signedRange(IntType t, int64_t &lo, int64_t &hi) {
  switch (t) {
  case IntType::Int8: lo = INT8_MIN; hi = INT8_MAX; return true;
  case IntType::Int16: lo = INT16_MIN; hi = INT16_MAX; return true;
  case IntType::Int32: lo = INT32_MIN; hi = INT32_MAX; return true;
  case IntType::Int64: lo = INT64_MIN; hi = INT64_MAX; return true;
  default: return false;
  }
}

uint64_t unsignedMax(IntType t) {
  switch (t) {
  case IntType::UInt8: return UINT8_MAX;
  case IntType::UInt16: return UINT16_MAX;
  case IntType::UInt32: return UINT32_MAX;
  default: return UINT64_MAX;
  }
}

std::string numberText(double x) {
  char buf[32];
  std::snprintf(buf, sizeof buf, "%.15g", x);
  return buf;
}

bool readWhole(const Value &v, Whole &w, std::string &err) {
  if (v.isBool()) {
    w.kind = Whole::Bool;
    w.s = v.number != 0.0 ? 1 : 0;
    return true;
  }
  if (v.isInt()) {
    w.kind = Whole::Typed;
    w.type = v.intType();
    w.isUnsigned = v.intIsUnsigned();
    if (w.isUnsigned)
      w.u = static_cast<uint64_t>(v.intBits());
    else
      w.s = v.intBits();
    return true;
  }
  if (!isRealNumber(v)) {
    err = "expected whole numbers, not " + describe(v);
    return false;
  }
  const double x = v.number;
  if (!std::isfinite(x) || x != std::floor(x)) {
    err = "expected whole numbers, got " + numberText(x);
    return false;
  }
  if (std::fabs(x) > kExactLimit) {
    err = numberText(x) +
          " is beyond 2^53, where plain numbers are no longer exact - convert with int64(x) first";
    return false;
  }
  w.kind = Whole::Plain;
  w.s = static_cast<int64_t>(x);
  return true;
}

// Plain/bool whole number -> integer type `t` (must fit).
bool toType(const Whole &w, IntType t, Whole &out, std::string &err) {
  out.kind = Whole::Typed;
  out.type = t;
  out.isUnsigned = static_cast<uint8_t>(t) >= static_cast<uint8_t>(IntType::UInt8);
  if (out.isUnsigned) {
    if (w.s < 0 || static_cast<uint64_t>(w.s) > unsignedMax(t)) {
      err = std::to_string(w.s) + " does not fit in " + intTypeName(t);
      return false;
    }
    out.u = static_cast<uint64_t>(w.s);
    return true;
  }
  int64_t lo = 0, hi = 0;
  signedRange(t, lo, hi);
  if (w.s < lo || w.s > hi) {
    err = std::to_string(w.s) + " does not fit in " + intTypeName(t);
    return false;
  }
  out.s = w.s;
  return true;
}

Value makeTyped(IntType t, bool isUnsigned, uint64_t bits) {
  return isUnsigned ? Value::integerUnsigned(t, bits)
                    : Value::integerSigned(t, static_cast<int64_t>(bits));
}

// Shared body of bitwise_and / bitwise_or / bitwise_xor.
ElemFn2 bitwiseOp(uint64_t (*op)(uint64_t, uint64_t)) {
  return [op](const Value &x, const Value &y, Value &out, std::string &err) {
    Whole a, b;
    if (!readWhole(x, a, err) || !readWhole(y, b, err))
      return false;

    // true/false with true/false stays true/false.
    if (a.kind == Whole::Bool && b.kind == Whole::Bool) {
      out = Value::boolean(op(static_cast<uint64_t>(a.s), static_cast<uint64_t>(b.s)) != 0);
      return true;
    }

    // An integer type wins: the other side is converted to it (it must fit).
    if (a.kind == Whole::Typed || b.kind == Whole::Typed) {
      if (a.kind == Whole::Typed && b.kind == Whole::Typed && a.type != b.type) {
        err = std::string("cannot combine ") + intTypeName(a.type) + " and " +
              intTypeName(b.type) + " - convert one side first, e.g. " +
              intTypeName(a.type) + "(x)";
        return false;
      }
      const IntType t = (a.kind == Whole::Typed) ? a.type : b.type;
      if (a.kind != Whole::Typed && !toType(a, t, a, err))
        return false;
      if (b.kind != Whole::Typed && !toType(b, t, b, err))
        return false;
      const uint64_t bitsA = a.isUnsigned ? a.u : static_cast<uint64_t>(a.s);
      const uint64_t bitsB = b.isUnsigned ? b.u : static_cast<uint64_t>(b.s);
      // Two in-range values of one type always give an in-range result
      // (two's complement for the signed types), so no range check here.
      out = makeTyped(t, a.isUnsigned, op(bitsA, bitsB));
      return true;
    }

    // Plain whole numbers: 64-bit two's complement, as NumPy's int64.
    const int64_t r = static_cast<int64_t>(op(static_cast<uint64_t>(a.s), static_cast<uint64_t>(b.s)));
    out = Value(static_cast<double>(r));
    return true;
  };
}

uint64_t opAnd(uint64_t x, uint64_t y) { return x & y; }
uint64_t opOr(uint64_t x, uint64_t y) { return x | y; }
uint64_t opXor(uint64_t x, uint64_t y) { return x ^ y; }

// Arithmetic right shift (rounds toward minus infinity, like NumPy), written
// without relying on the implementation-defined >> of a negative int64.
int64_t shiftRightFloor(int64_t s, int n) {
  if (s >= 0)
    return s >> n;
  return ~((~s) >> n);
}

ElemFn2 shiftOp(const std::string &fn, bool left) {
  return [fn, left](const Value &x, const Value &y, Value &out, std::string &err) {
    Whole a, amount;
    if (!readWhole(x, a, err) || !readWhole(y, amount, err))
      return false;
    int64_t n64 = (amount.kind == Whole::Typed && amount.isUnsigned)
                      ? (amount.u > 64 ? 64 : static_cast<int64_t>(amount.u))
                      : amount.s;
    if (n64 < 0) {
      err = "the shift amount must not be negative, got " + std::to_string(n64);
      return false;
    }
    if (n64 > 63) {
      err = "the shift amount must be 63 or less, got " + std::to_string(n64);
      return false;
    }
    const int n = static_cast<int>(n64);

    if (a.kind == Whole::Typed && a.isUnsigned) {
      const uint64_t max = unsignedMax(a.type);
      if (left) {
        if (a.u > (max >> n)) {
          err = std::string(intTypeName(a.type)) + " overflow: " + fn + "(" + std::to_string(a.u) +
                ", " + std::to_string(n) + ") is outside 0.." + std::to_string(max);
          return false;
        }
        out = Value::integerUnsigned(a.type, a.u << n);
      } else {
        out = Value::integerUnsigned(a.type, a.u >> n);
      }
      return true;
    }

    if (a.kind == Whole::Typed) {
      int64_t lo = 0, hi = 0;
      signedRange(a.type, lo, hi);
      if (left) {
        // s * 2^n stays in [lo, hi] exactly when s is in [lo >> n, hi >> n]
        // (lo is a negative power of two, so lo >> n is exact).
        if (a.s > (hi >> n) || a.s < shiftRightFloor(lo, n)) {
          err = std::string(intTypeName(a.type)) + " overflow: " + fn + "(" + std::to_string(a.s) +
                ", " + std::to_string(n) + ") is outside " + std::to_string(lo) + ".." +
                std::to_string(hi);
          return false;
        }
        out = Value::integerSigned(a.type, static_cast<int64_t>(static_cast<uint64_t>(a.s) << n));
      } else {
        out = Value::integerSigned(a.type, shiftRightFloor(a.s, n));
      }
      return true;
    }

    // Plain number (or true/false, taken as 1/0): the result must stay
    // within 2^53, where float64 is exact.
    if (left) {
      const int64_t limit = static_cast<int64_t>(kExactLimit);
      const int64_t mag = a.s < 0 ? -a.s : a.s;
      if (mag != 0 && (n > 53 || mag > (limit >> n))) {
        err = fn + "(" + std::to_string(a.s) + ", " + std::to_string(n) +
              ") would be beyond 2^53, where plain numbers are no longer exact - convert with int64(x) first";
        return false;
      }
      out = Value(static_cast<double>(a.s * (int64_t(1) << n)));
    } else {
      out = Value(static_cast<double>(shiftRightFloor(a.s, n)));
    }
    return true;
  };
}

int popcount64(uint64_t x) {
  int count = 0;
  while (x) {
    x &= x - 1;
    count++;
  }
  return count;
}

/* ======================================================================
   power(A, n) - element-wise
   ====================================================================== */

// Same value as the `e` constant (builtins/constants_builtin.cpp). e^y goes
// through exp(y), as NC's `^` does (arithmetic.cpp powScalar), so e.g.
// power(e, log(2)) is exactly 2.
constexpr double kEulerE = 2.718281828459045;

double powReal(double x, double y) { return x == kEulerE ? std::exp(y) : std::pow(x, y); }

bool powNeedsComplex(double x, double y) {
  return x < 0.0 && std::isfinite(y) && y != std::floor(y);
}

// Complex x^y, matching NC's `^` for numbers: real operands with a real
// answer get exactly the real result; whole-number exponents multiply, so
// results that should be exact are exact; otherwise the principal value.
// Principal square root from the parts directly - exact where the answer is
// (sqrt(-4) is exactly 2i); same routine NC's `^` uses (arithmetic.cpp).
Cplx sqrtComplex(Cplx z) {
  const double re = z.real(), im = z.imag();
  if (re == 0.0 && im == 0.0)
    return Cplx(0.0, 0.0);
  if (!std::isfinite(re) || !std::isfinite(im))
    return std::sqrt(z);
  const double t = std::sqrt((std::fabs(re) + std::hypot(re, im)) / 2.0);
  if (re >= 0.0)
    return Cplx(t, im / (2.0 * t));
  return Cplx(std::fabs(im) / (2.0 * t), std::copysign(t, im));
}

Cplx powComplex(Cplx x, Cplx y) {
  if (x.imag() == 0.0 && y.imag() == 0.0 && !powNeedsComplex(x.real(), y.real()))
    return Cplx(powReal(x.real(), y.real()), 0.0);
  if (y == Cplx(0.5, 0.0))
    return sqrtComplex(x);
  if (y.imag() == 0.0 && y.real() == std::floor(y.real()) && std::fabs(y.real()) <= 1024.0) {
    long n = static_cast<long>(std::fabs(y.real()));
    Cplx result(1.0, 0.0), base = x;
    while (n > 0) {
      if (n & 1)
        result *= base;
      base *= base;
      n >>= 1;
    }
    return y.real() < 0 ? Cplx(1.0, 0.0) / result : result;
  }
  if (x == Cplx(0.0, 0.0) && y.real() > 0.0)
    return Cplx(0.0, 0.0);
  return std::pow(x, y);
}

Value powerElementwise(const std::vector<Value> &args, CallContext &ctx) {
  if (!checkNumericArg(args, 0, ctx) || !checkNumericArg(args, 1, ctx))
    return Value(0.0);
  const Value &a = args[0], &b = args[1];

  // No matrix involved: NC's own `^` is already element-wise for arrays and
  // keeps units / gives complex results for numbers - use it unchanged, so
  // power(x, n) and x^n always agree there.
  if (!a.isMatrix && !b.isMatrix) {
    g_lastElementwiseOk = true;
    Value result = power(a, b);
    if (!g_lastElementwiseOk)
      ctx.markFailed(); // power() already printed why
    return result;
  }

  // A matrix: element by element (A^n would be the matrix power for a
  // whole-number n; for any other n, A^n is element-wise too).
  if (!a.hasComplex() && !b.hasComplex()) {
    bool needComplex = false;
    Value result = zipElementwise(a, b, [&needComplex](double x, double y) {
      if (powNeedsComplex(x, y))
        needComplex = true;
      return powReal(x, y);
    });
    if (!g_lastElementwiseOk) {
      ctx.markFailed(); // zipElementwise() already printed why
      return Value(0.0);
    }
    if (!needComplex)
      return result;
  }
  // A negative element with a fractional exponent, or complex input: the
  // whole result is computed in complex numbers (as NC's `^` does).
  Value result = zipElementwiseC(a, b, powComplex);
  if (!g_lastElementwiseOk)
    ctx.markFailed();
  return result;
}

} // namespace

/* ======================================================================
   Registration
   ====================================================================== */

void registerScalarMath(Registry &reg) {
  // ---- floor_divide(A, n): floor(a / b) per element ----------------------
  reg.add({
      "floor_divide", Section::ScalarMath, 2, 2, "floor_divide(A, n)",
      "a / b rounded down, per element", "np.floor_divide",
      [](const std::vector<Value> &args, CallContext &ctx) -> Value {
        Value out;
        zipValues(
            args[0], args[1],
            [](const Value &x, const Value &y, Value &r, std::string &err) {
              if (!isRealNumber(x) || !isRealNumber(y)) {
                err = "expected real numbers, not " +
                      describe(isRealNumber(x) ? y : x);
                return false;
              }
              if (x.isInt() && y.isInt()) {
                // Two integers of one type: exact integer floor division.
                if (x.intType() != y.intType()) {
                  err = std::string("cannot combine ") + intTypeName(x.intType()) + " and " +
                        intTypeName(y.intType()) +
                        " - convert one side first, e.g. " +
                        intTypeName(x.intType()) + "(x)";
                  return false;
                }
                const IntType t = x.intType();
                if (x.intIsUnsigned()) {
                  const uint64_t p = static_cast<uint64_t>(x.intBits());
                  const uint64_t q = static_cast<uint64_t>(y.intBits());
                  if (q == 0) {
                    err = "integer division by zero";
                    return false;
                  }
                  r = Value::integerUnsigned(t, p / q);
                  return true;
                }
                const int64_t p = x.intBits(), q = y.intBits();
                if (q == 0) {
                  err = "integer division by zero";
                  return false;
                }
                int64_t lo = 0, hi = 0;
                signedRange(t, lo, hi);
                if (p == INT64_MIN && q == -1) {
                  err = std::string(intTypeName(t)) + " overflow: floor_divide(" +
                        std::to_string(p) + ", -1) is outside " + std::to_string(lo) + ".." +
                        std::to_string(hi);
                  return false;
                }
                int64_t d = p / q;
                if ((p % q != 0) && ((p < 0) != (q < 0)))
                  d -= 1; // C++ truncates; NumPy floors
                if (d < lo || d > hi) {
                  err = std::string(intTypeName(t)) + " overflow: floor_divide(" +
                        std::to_string(p) + ", " + std::to_string(q) + ") is outside " +
                        std::to_string(lo) + ".." + std::to_string(hi);
                  return false;
                }
                r = Value::integerSigned(t, d);
                return true;
              }
              // Anything else is float64. + 0.0: no "-0" results.
              r = Value(std::floor(x.number / y.number) + 0.0);
              r.dimL = static_cast<int16_t>(x.dimL - y.dimL);
              r.dimT = static_cast<int16_t>(x.dimT - y.dimT);
              r.dimM = static_cast<int16_t>(x.dimM - y.dimM);
              return true;
            },
            ctx, out);
        return out;
      },
  });

  // ---- power(A, n): element-wise power ------------------------------------
  {
    FunctionSpec spec{"power", Section::ScalarMath, 2, 2, "power(A, n)",
                      "each element raised to n (element-wise, also for matrices)", "np.power",
                      [](const std::vector<Value> &args, CallContext &ctx) -> Value {
                        return powerElementwise(args, ctx);
                      }};
    spec.acceptsComplex = true;
    reg.add(std::move(spec));
  }

  // ---- reciprocal(A): 1/x per element ------------------------------------
  {
    FunctionSpec spec{"reciprocal", Section::ScalarMath, 1, 1, "reciprocal(A)",
                      "1/x for every element (not the matrix inverse)", "np.reciprocal",
                      [](const std::vector<Value> &args, CallContext &ctx) -> Value {
                        g_lastElementwiseOk = true;
                        Value result =
                            args[0].hasComplex()
                                ? mapElementwiseC(args[0],
                                                  [](Cplx z) { return Cplx(1.0, 0.0) / z; })
                                : mapElementwise(args[0], [](double x) { return 1.0 / x; });
                        if (!g_lastElementwiseOk)
                          ctx.markFailed(); // mapElementwise() already printed why
                        return result;
                      }};
    spec.acceptsComplex = true;
    reg.add(std::move(spec));
  }

  // ---- clip(A, lo, hi): every element limited to [lo, hi] ----------------
  reg.add({
      "clip", Section::ScalarMath, 3, 3, "clip(A, lo, hi)",
      "every element limited to the range [lo, hi]", "np.clip",
      [](const std::vector<Value> &args, CallContext &ctx) -> Value {
        // Two passes, as NumPy defines it: max(A, lo), then min(that, hi).
        // So lo > hi gives hi everywhere, and NaN elements stay NaN.
        auto bound = [](bool lower) {
          return [lower](const Value &x, const Value &lim, Value &r, std::string &err) {
            if (!isRealNumber(x) || !isRealNumber(lim)) {
              err = "expected real numbers, not " + describe(isRealNumber(x) ? lim : x);
              return false;
            }
            if (x.dimL != lim.dimL || x.dimT != lim.dimT || x.dimM != lim.dimM) {
              err = "incompatible units in clip";
              return false;
            }
            double v = x.number;
            if (!std::isnan(v))
              v = lower ? (v < lim.number ? lim.number : v) : (v > lim.number ? lim.number : v);
            r = Value(v);
            copyUnit(x, r);
            return true;
          };
        };
        Value lowered;
        if (!zipValues(args[0], args[1], bound(true), ctx, lowered))
          return Value(0.0);
        Value out;
        zipValues(lowered, args[2], bound(false), ctx, out);
        return out;
      },
  });

  // ---- bitwise_and / bitwise_or / bitwise_xor ----------------------------
  auto addBitwise = [&reg](const char *name, const char *numpyName, const char *summary,
                           uint64_t (*op)(uint64_t, uint64_t)) {
    const std::string fn = name;
    reg.add({name, Section::ScalarMath, 2, 2, fn + "(A, B)", summary, numpyName,
             [op](const std::vector<Value> &args, CallContext &ctx) -> Value {
               Value out;
               zipValues(args[0], args[1], bitwiseOp(op), ctx, out);
               return out;
             }});
  };
  addBitwise("bitwise_and", "np.bitwise_and", "bit-by-bit AND of whole numbers", opAnd);
  addBitwise("bitwise_or", "np.bitwise_or", "bit-by-bit OR of whole numbers", opOr);
  addBitwise("bitwise_xor", "np.bitwise_xor", "bit-by-bit XOR of whole numbers", opXor);

  // ---- left_shift / right_shift ------------------------------------------
  auto addShift = [&reg](const char *name, const char *numpyName, const char *summary,
                         bool left) {
    const std::string fn = name;
    reg.add({name, Section::ScalarMath, 2, 2, fn + "(A, n)", summary, numpyName,
             [fn, left](const std::vector<Value> &args, CallContext &ctx) -> Value {
               Value out;
               zipValues(args[0], args[1], shiftOp(fn, left), ctx, out);
               return out;
             }});
  };
  addShift("left_shift", "np.left_shift", "bits moved left by n (x * 2^n)", true);
  addShift("right_shift", "np.right_shift", "bits moved right by n (x / 2^n rounded down)",
           false);

  // ---- bitwise_count(A): set bits of |x| ---------------------------------
  reg.add({
      "bitwise_count", Section::ScalarMath, 1, 1, "bitwise_count(A)",
      "number of 1-bits in |x|, per element", "np.bitwise_count",
      [](const std::vector<Value> &args, CallContext &ctx) -> Value {
        Value out;
        mapValues(
            args[0],
            [](const Value &x, Value &r, std::string &err) {
              Whole w;
              if (!readWhole(x, w, err))
                return false;
              uint64_t mag;
              if (w.kind == Whole::Typed && w.isUnsigned)
                mag = w.u;
              else // magnitude without overflow, INT64_MIN included
                mag = w.s < 0 ? static_cast<uint64_t>(-(w.s + 1)) + 1u : static_cast<uint64_t>(w.s);
              r = Value(static_cast<double>(popcount64(mag)));
              return true;
            },
            ctx, out);
        return out;
      },
  });

  // ---- invert(A): logical NOT of true/false values (registered below) -----
  reg.add({
      "invert", Section::ScalarMath, 1, 1, "invert(A)",
      "true <-> false, per element (true/false values only)", "np.invert",
      [](const std::vector<Value> &args, CallContext &ctx) -> Value {
        Value out;
        mapValues(
            args[0],
            [](const Value &x, Value &r, std::string &err) {
              if (!x.isBool()) {
                err = "works only on true/false values, not " + describe(x);
                return false;
              }
              r = Value::boolean(x.number == 0.0);
              return true;
            },
            ctx, out);
        return out;
      },
  });

  // The inputs of every Scalar Math function, by name (core/param_list.h).
  static const struct {
    const char *name;
    const char *params;
  } kScalarMathParams[] = {
      {"floor_divide", "A, n"},  {"power", "A, n"},          {"reciprocal", "A"},
      {"clip", "A, lo, hi"},     {"bitwise_and", "A, B"},    {"bitwise_or", "A, B"},
      {"bitwise_xor", "A, B"},   {"left_shift", "A, n"},     {"right_shift", "A, n"},
      {"bitwise_count", "A"},    {"invert", "A"},
  };
  for (const auto &row : kScalarMathParams)
    reg.setParams(row.name, row.params);
}

} // namespace numpy
} // namespace nc
