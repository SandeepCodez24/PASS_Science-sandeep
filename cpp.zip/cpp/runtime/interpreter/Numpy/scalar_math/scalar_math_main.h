// Section 8 of 11 - Scalar Math (38 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_SCALAR_MATH_MAIN_H
#define NC_NUMPY_SCALAR_MATH_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Scalar Math function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerScalarMath(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_SCALAR_MATH_MAIN_H
