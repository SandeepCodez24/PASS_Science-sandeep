// Inspecting Properties - only inspecting_properties_main.cpp includes this
// header.
#ifndef NC_NUMPY_IP_FUNCTIONS_H
#define NC_NUMPY_IP_FUNCTIONS_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// ndim, is_scalar, is_complex_each, is_real_each, type, is_type, can_cast
// (with their parameter lines).
void registerInspectingFunctions(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_IP_FUNCTIONS_H
