// Section 3 of 11 - Inspecting Properties
// Planned entries: 42  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   ip_functions.cpp   ndim is_scalar is_complex_each is_real_each type is_type
//                      can_cast
//
// Names from the team's list that are existing NC builtins and keep the
// builtin: shape, numel, is_complex, is_real. Dropped by the team
// (2026-10-28): is_img_each.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        inspecting_properties/ip_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerInspectingProperties() below.
//   2. Register it with reg.add({...}) and give it a parameter line
//      (reg.setParams(name, "A, axis?") - core/param_list.h).
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("inspecting_properties")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "inspecting_properties_main.h"

#include "ip_functions.h"

namespace nc {
namespace numpy {

void registerInspectingProperties(Registry &reg) { registerInspectingFunctions(reg); }

} // namespace numpy
} // namespace nc
