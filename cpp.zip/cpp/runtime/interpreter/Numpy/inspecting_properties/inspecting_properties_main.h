// Section 3 of 11 - Inspecting Properties (42 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_INSPECTING_PROPERTIES_MAIN_H
#define NC_NUMPY_INSPECTING_PROPERTIES_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Inspecting Properties function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerInspectingProperties(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_INSPECTING_PROPERTIES_MAIN_H
