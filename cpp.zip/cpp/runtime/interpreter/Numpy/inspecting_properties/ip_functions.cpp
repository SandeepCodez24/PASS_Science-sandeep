// Inspecting Properties.
//
//   ndim(A)              number of dimensions: 0 a single value, 1 a 1-D array,
//                        2 a matrix (also [1, 2, 3]), N an N-D matrix     np.ndim
//   is_scalar(x)         true for one single value (number, bool, text, time) -
//                        false for any matrix, even a 1x1 one            np.isscalar
//   is_complex_each(A)   per element: true where the imaginary part is not 0
//                                                                         np.iscomplex
//   is_real_each(A)      per element: true where the imaginary part is 0  np.isreal
//   type(x)              the element type as text                         dtype
//   is_type(x, name)     type(x) is `name` - or belongs to a group:
//                        "integer", "float", "number", "complex", "time"
//   can_cast(from, to, casting="safe")                                     np.can_cast
//                        whether values of type `from` (a value, or a type name)
//                        can become type `to` without losing anything ("safe"),
//                        within their kind ("same_kind"), at all ("unsafe"), or
//                        only as the same type ("no")
//
// Type names: bool  int8 int16 int32 int64  uint8 uint16 uint32 uint64
//             float8 float16 float32 float64  complex128  text
//             timestamp duration  (and dict, object, function reference)
// A matrix reports the type of its elements; one whose elements differ
// (possible only for nested values) reports "mixed".
#include "ip_functions.h"

#include <algorithm>
#include <cctype>
#include <string>
#include <vector>

#include "../numpy_nd.h"
#include "../../ops/time/time.h"

namespace nc {
namespace numpy {

namespace {

using ndx::Grid;

std::string lower(std::string s) {
  for (char &c : s)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return s;
}

std::string typeOf(const Value &v) {
  if (v.isDict || v.isObject || v.isFunctionRef || (!v.isArray && !v.isMatrix && !v.isND()))
    return nctime::typeName(v);
  const Grid g = ndx::gridOf(v);
  if (g.count() == 0)
    return "float64"; // [] - NC's default number
  const std::string first = nctime::typeName(g.cells[0]);
  for (const Value &c : g.cells)
    if (nctime::typeName(c) != first)
      return "mixed";
  return first;
}

Value ndimFn(const std::vector<Value> &args, CallContext &) {
  const Value &v = args[0];
  if (v.isND())
    return Value(static_cast<double>(v.ndShape().size()));
  if (v.isMatrix)
    return Value(2.0);
  if (v.isArray)
    return Value(1.0);
  return Value(0.0);
}

Value isScalarFn(const std::vector<Value> &args, CallContext &) {
  const Value &v = args[0];
  return Value::boolean(!v.isArray && !v.isMatrix && !v.isDict && !v.isObject &&
                        !v.isFunctionRef);
}

Impl eachImpl(bool complexPart) {
  return [complexPart](const std::vector<Value> &args, CallContext &ctx) -> Value {
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    for (Value &c : a.cells) {
      if (!isPlainNumber(c) || c.isTime()) {
        ctx.fail("it works on numbers");
        return Value(0.0);
      }
      const bool imaginary = c.isComplex && c.imag != 0.0;
      c = Value::boolean(complexPart ? imaginary : !imaginary);
    }
    if (!args[0].isArray && !args[0].isMatrix && !args[0].isND())
      return a.cells[0];
    return ndx::valueOf(a);
  };
}

Value typeFn(const std::vector<Value> &args, CallContext &) { return Value(typeOf(args[0])); }

/* ---- type names and casting ---- */

enum class Kind { Bool, UInt, Int, Float, Complex, Text, Timestamp, Duration, Other };

struct TypeInfo {
  Kind kind = Kind::Other;
  int bits = 0;
};

const std::vector<std::string> &knownTypes() {
  static const std::vector<std::string> names = {
      "bool",    "int8",    "int16",   "int32",   "int64",      "uint8",     "uint16",
      "uint32",  "uint64",  "float8",  "float16", "float32",    "float64",   "complex128",
      "text",    "timestamp", "duration"};
  return names;
}

bool infoOf(const std::string &nameIn, TypeInfo &t) {
  const std::string name = lower(nameIn);
  auto bitsAfter = [&](size_t prefix) { return std::stoi(name.substr(prefix)); };
  if (name == "bool")
    t = {Kind::Bool, 1};
  else if (name == "text")
    t = {Kind::Text, 0};
  else if (name == "timestamp")
    t = {Kind::Timestamp, 64};
  else if (name == "duration")
    t = {Kind::Duration, 64};
  else if (name == "complex128")
    t = {Kind::Complex, 128};
  else if (name == "int8" || name == "int16" || name == "int32" || name == "int64")
    t = {Kind::Int, bitsAfter(3)};
  else if (name == "uint8" || name == "uint16" || name == "uint32" || name == "uint64")
    t = {Kind::UInt, bitsAfter(4)};
  else if (name == "float8" || name == "float16" || name == "float32" || name == "float64")
    t = {Kind::Float, bitsAfter(5)};
  else
    return false;
  return true;
}

// The narrowest float that holds every value of an integer of `bits` bits
// (NumPy's rule; 64-bit integers count as fitting float64).
int floatBitsFor(int bits) { return bits <= 8 ? 16 : bits <= 16 ? 32 : 64; }

bool safeCast(const TypeInfo &f, const TypeInfo &t) {
  if (f.kind == t.kind && f.bits == t.bits)
    return true;
  switch (f.kind) {
  case Kind::Bool:
    return t.kind == Kind::UInt || t.kind == Kind::Int || t.kind == Kind::Float ||
           t.kind == Kind::Complex;
  case Kind::UInt:
    return (t.kind == Kind::UInt && t.bits >= f.bits) || (t.kind == Kind::Int && t.bits > f.bits) ||
           (t.kind == Kind::Float && t.bits >= floatBitsFor(f.bits)) || t.kind == Kind::Complex;
  case Kind::Int:
    return (t.kind == Kind::Int && t.bits >= f.bits) ||
           (t.kind == Kind::Float && t.bits >= floatBitsFor(f.bits)) || t.kind == Kind::Complex;
  case Kind::Float:
    return (t.kind == Kind::Float && t.bits >= f.bits) || t.kind == Kind::Complex;
  default:
    return false;
  }
}

bool numeric(Kind k) {
  return k == Kind::Bool || k == Kind::UInt || k == Kind::Int || k == Kind::Float ||
         k == Kind::Complex;
}

// Kinds in the order a number may move up within "same_kind".
int kindRank(Kind k) {
  switch (k) {
  case Kind::Bool: return 0;
  case Kind::UInt:
  case Kind::Int: return 1;
  case Kind::Float: return 2;
  case Kind::Complex: return 3;
  default: return -1;
  }
}

Value canCastFn(const std::vector<Value> &args, CallContext &ctx) {
  // `from`: a type name in quotes, or any value (its element type).
  TypeInfo probe;
  const std::string fromName = args[0].isText && infoOf(args[0].text(), probe)
                                   ? lower(args[0].text())
                                   : typeOf(args[0]);
  std::string toName;
  std::string casting;
  if (!argText(args, 1, ctx, toName) || !argText(args, 2, ctx, casting))
    return Value(0.0);
  TypeInfo f, t;
  std::string list;
  for (const std::string &n : knownTypes())
    list += (list.empty() ? "" : ", ") + n;
  if (!infoOf(fromName, f)) {
    ctx.fail("cannot cast from \"" + fromName + "\" - known types: " + list);
    return Value(0.0);
  }
  if (!infoOf(toName, t)) {
    ctx.fail("unknown type \"" + toName + "\" - known types: " + list);
    return Value(0.0);
  }
  casting = lower(casting);
  bool ok = false;
  if (casting == "no" || casting == "equiv") {
    ok = f.kind == t.kind && f.bits == t.bits;
  } else if (casting == "safe") {
    ok = safeCast(f, t);
  } else if (casting == "same_kind") {
    ok = safeCast(f, t) ||
         (numeric(f.kind) && numeric(t.kind) && kindRank(f.kind) <= kindRank(t.kind));
  } else if (casting == "unsafe") {
    ok = safeCast(f, t) || (numeric(f.kind) && numeric(t.kind)) ||
         (numeric(f.kind) && t.kind == Kind::Text);
  } else {
    ctx.fail("casting must be \"no\", \"equiv\", \"safe\", \"same_kind\" or \"unsafe\"");
    return Value(0.0);
  }
  return Value::boolean(ok);
}

Value isTypeFn(const std::vector<Value> &args, CallContext &ctx) {
  std::string name;
  if (!argText(args, 1, ctx, name))
    return Value(0.0);
  name = lower(name);
  const std::string t = typeOf(args[0]);
  TypeInfo info;
  const bool known = infoOf(t, info);
  if (name == "integer")
    return Value::boolean(known && (info.kind == Kind::Int || info.kind == Kind::UInt));
  if (name == "float")
    return Value::boolean(known && info.kind == Kind::Float);
  if (name == "complex")
    return Value::boolean(known && info.kind == Kind::Complex);
  if (name == "number")
    return Value::boolean(known && (info.kind == Kind::Int || info.kind == Kind::UInt ||
                                    info.kind == Kind::Float || info.kind == Kind::Complex));
  if (name == "time")
    return Value::boolean(known && (info.kind == Kind::Timestamp || info.kind == Kind::Duration));
  TypeInfo probe;
  const bool nameKnown = infoOf(name, probe) || name == "dict" || name == "object" ||
                         name == "function reference" || name == "mixed";
  if (!nameKnown) {
    std::string list;
    for (const std::string &n : knownTypes())
      list += n + ", ";
    ctx.fail("unknown type \"" + name + "\" - use " + list +
             "or a group: integer, float, number, complex, time");
    return Value(0.0);
  }
  return Value::boolean(t == name);
}

void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
         const char *numpyName, Impl impl) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::InspectingProperties;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = true;
  reg.add(std::move(spec));
}

} // namespace

void registerInspectingFunctions(Registry &reg) {
  add(reg, "ndim", 1, 1, "number of dimensions", "np.ndim", ndimFn);
  add(reg, "is_scalar", 1, 1, "true for one single value", "np.isscalar", isScalarFn);
  add(reg, "is_complex_each", 1, 1, "per element: imaginary part not 0", "np.iscomplex",
      eachImpl(true));
  add(reg, "is_real_each", 1, 1, "per element: imaginary part 0", "np.isreal", eachImpl(false));
  add(reg, "type", 1, 1, "the element type as text", "ndarray.dtype", typeFn);
  add(reg, "is_type", 2, 2, "whether the type is (or belongs to) a name", "np.issubdtype",
      isTypeFn);
  add(reg, "can_cast", 2, 3, "whether one type converts to another", "np.can_cast", canCastFn);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"ndim", "A"},          {"is_scalar", "x"},  {"is_complex_each", "A"},
      {"is_real_each", "A"},  {"type", "x"},       {"is_type", "x, name"},
      {"can_cast", "from, to, casting=\"safe\""},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
