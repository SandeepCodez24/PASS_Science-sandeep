# Numpy — NumPy-equivalent functions for NC

721 functions in 11 sections, each section owned and developed independently.

```
runtime/interpreter/Numpy/
├── numpy_main.h / .cpp        entry point: initialize(), tryCall()  ← only thing builtins.cpp calls
├── numpy_registry.h / .cpp    name → FunctionSpec table, section table (planned counts), reserved names
├── numpy_common.h             shared argument / result helpers
├── numpy_sources.cmake        globs every .cpp in this tree for the build
├── importing_data/            importing_data_main.h/.cpp           168
├── creating_arrays/           creating_arrays_main.h/.cpp           71
├── inspecting_properties/     inspecting_properties_main.h/.cpp     42
├── copying_sorting_reshaping/ copying_sorting_reshaping_main.h/.cpp 47
├── adding_removing_elements/  adding_removing_elements_main.h/.cpp  20
├── combining_splitting/       combining_splitting_main.h/.cpp       17
├── indexing_slicing/          indexing_slicing_main.h/.cpp          54
├── scalar_math/               scalar_math_main.h/.cpp               38
├── vector_math/               vector_math_main.h/.cpp              136
├── statistics/                statistics_main.h/.cpp                55
└── working_with_data/         working_with_data_main.h/.cpp         73
```

## How a call reaches your code

```
NC source      y = outer_demo(a, b);
Lexer          IDENT LPAREN IDENT COMMA IDENT RPAREN        (no change needed)
Parser         ExprKind::Call "outer_demo" [a, b]           (no change needed)
Tree-walker    evaluateExpr → callBuiltin(name, args)
JIT            nc_bridge_call_dynamic → callBuiltin(name, args)
callBuiltin    1. builtinTable (ops/)      → existing builtins always win
               2. nc::numpy::tryCall()     → Registry → arg check → your lambda
               3. logbN family, then "Unknown function"
```

The mapping from NC name to C++ code is the `reg.add({...})` entry in your
section. That is the only mapping a section developer writes.

## Adding a function (section developer)

1. In `<section>/<section>_main.cpp`, copy the commented example.
2. Fill in: NC name, `Section::...`, min/max args, usage text, summary, NumPy original, lambda.
3. For a group of functions, add `<section>/<prefix>_<group>.h/.cpp` with a
   `register<Group>(Registry&)` and call it from your section's register function.
4. Rebuild — new `.cpp` files are picked up automatically. Then in NC:

```
numpy_functions("vector_math")   % names registered in one section
numpy_functions()                % all registered names
numpy_status()                   % done / skipped / planned for all 11 sections
```

You never edit files outside your section folder.

## Rules

| Rule | Why |
|---|---|
| Use the NC name from the team's agreed name list; matching is case-insensitive | same as every other builtin |
| A name already owned by an ops/ builtin (`sum`, `mean`, `sin`, `det`, `dot`, …) is skipped | team decision: the existing builtin stays. Printed at startup, counted by `numpy_status()` |
| NC keywords, parser-reserved calls (`feval`, `grad`, `parent`, …) and `logbN` names are skipped | they never reach `callBuiltin()` |
| Give every function a parameter line (`reg.setParams("allclose", "A, B, atol=0.1, rtol=0")`, see `core/param_list.h`) | that one line decides which values a call may name, the defaults, and the usage text shown in errors and in the IDE. The code still reads its arguments by position |
| Report bad input with `ctx.fail("...")`, then return any Value | prints one `Error: name: ...` line and stops the statement, like every NC error |
| Complex arguments are refused unless the spec sets `acceptsComplex = true` | same rule as the ops/ builtins |
| Don't throw on user mistakes, don't print errors yourself, don't modify `args` | one consistent error path for all 721 functions |
| Use the helpers in `numpy_common.h` (`argNumber`, `argInt`, `argNumbers`, `makeArray`, `makeMatrix`, …) | identical error wording everywhere |

Note: a user-defined NC `function` with the same name as a NumPy function wins,
because evaluateExpr() checks user functions before builtins.

## Conventions of the sections done on 2026-10-28

Sections 1-8 of the team list (adding/removing, combining/splitting,
copying/sorting/reshaping, creating, indexing, inspecting, statistics,
working with data) follow these rules - tests and explanations are in
`src/test/nc/numpy_0*_*.nc`:

- **Shared helpers** live in `numpy_nd.h`: a value as a `Grid` (shape + elements
  row by row), axis reading, slices along an axis, element ordering (NaN last,
  ints exact, text by bytes), several results (`[r, c] = nonzero(A)`; one name
  gets a list).
- **Axes** count from the first; -1 is the columns, -2 the rows. Matrix-centred
  functions (`row_stack`, `column_stack`, `fliplr`, `flipud`, `rot90`) always work
  on the rows / columns, also of an N-D matrix (on every page).
- **Reductions** (statistics) take `axis="all"` (default) or a number; along an
  axis the axis disappears, as in `max(A, axis=k)`.
- **Element types** of a built result go through `matUnifyCells()`, so they are
  what the matrix literal would hold.
- **Variadic functions** use a `*name` parameter: `"*A, axis=0"` (core/param_list.h).
- **N-D input**: every new function that accepts it is listed in
  `ndBuiltinAllowed()` (ops/matrix/matrix.cpp).
- **Random functions** share `ncRandomEngine()` with `nexus()`, so `nexus_seed(n)`
  repeats them.
- **Parameter-line pitfall**: an optional input (`x?`) written before one with a
  default makes every call that leaves it out fail ("must be given too"). Give it a
  default instead (`axis="all"`, `weights=1`, `N=0`, `left="end"`).

## Still open

- **N-D arrays** — NC has N-D matrices (`ops/matrix/nd_array.h`, same index order as NumPy).
  Most functions here still take 2-D values; a builtin that works on N-D must be listed in
  `ndBuiltinAllowed()` (ops/matrix/matrix.cpp) - done so far: max, min, tensorinv, tensorsolve.
- **Named arguments** — done (2026-10-27): `allclose(A, B, atol=0.2)`. A function without a
  parameter line refuses named values with "its values cannot be named yet".
- **poly1d** — a value (`Numpy/numpy_poly1d.h`): `P(x)`, `P[k]`, `P.coeffs`. Arithmetic between
  poly1d values (`P + Q`, `P * Q`) is not done yet.
