// runtime/interpreter/Numpy/numpy_poly1d.h
//
// poly1d - a polynomial VALUE, as np.poly1d (R6, 2026-10-27).
//
//   P = poly1d([2, 3, 1])       P is 2x^2 + 3x + 1
//   P(2)                        15        (the polynomial at x = 2)
//   P([0, 1, 2])                1  6  15  (every element)
//   P[2]                        2         (coefficient of x^2; 0 past the order)
//   P.coeffs  P.c  P.coef       [2, 3, 1] (highest power first)
//   P.order                     2
//   P.roots                     the roots, as roots(P.coeffs)
//   P.variable                  "x"       (the letter used when printed)
//   poly1d([1, 2], r=true)      the polynomial whose roots are 1 and 2
//   polyval(P, 2), roots(P) ... every NumPy function takes P as its
//                               coefficient row
//
// A poly1d is an object Value (isObject) of class "poly1d" whose fields are
// the ones above. It is built only here; the interpreter calls into this
// header from three places:
//   - parser_factor.cpp       P(x) and P[k] in the tree-walker
//   - value_bridge.cpp        the same two under the JIT
//   - core/output.cpp         printing it as "2x^2 + 3x + 1"
//   - Numpy/numpy_main.cpp    a poly1d given to any NumPy function becomes
//                             its coefficient row
// The code lives in Numpy/vector_math/vm_poly.cpp next to the other
// polynomial functions.
#ifndef NC_NUMPY_POLY1D_H
#define NC_NUMPY_POLY1D_H

#include <string>

#include "../core/value.h"

namespace nc {
namespace numpy {

// The class name a poly1d object carries.
inline const char *poly1dClassName() { return "poly1d"; }

inline bool isPoly1d(const Value &v) { return v.isObject && v.className() == poly1dClassName(); }

// The coefficient row (highest power first) - a number for a constant.
Value poly1dCoefficients(const Value &p);

// P(x): the polynomial at every element of x. False with `err` set (no
// "Error:" prefix) when x is not numeric.
bool poly1dCall(const Value &p, const Value &x, Value &out, std::string &err);

// P[k]: the coefficient of x^k; 0 when k is past the order or negative (as
// NumPy). False with `err` set when k is not a whole number.
bool poly1dCoefficientOf(const Value &p, const Value &k, Value &out, std::string &err);

// "2x^2 + 3x + 1" (with the polynomial's own variable letter).
std::string poly1dText(const Value &p);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_POLY1D_H
