// Combining & Splitting - joining matrices together and cutting them apart.
// Only combining_splitting_main.cpp includes this header.
#ifndef NC_NUMPY_CS_JOIN_SPLIT_H
#define NC_NUMPY_CS_JOIN_SPLIT_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// concat, stack, vstack, hstack, row_stack, column_stack, matrix_split,
// vsplit, hsplit (with their parameter lines).
void registerJoinSplit(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_CS_JOIN_SPLIT_H
