// Combining & Splitting - joining matrices together and cutting them apart.
//
// NC is matrix-centred: every value is a matrix of some shape (nd_array.h)
//   a single value  [1, 1]     a 1-D array  [1, n] (a row)     a matrix [rows, cols]
//   an N-D matrix   [d0, ..., rows, cols]
// and the axes are numbered from the first: axis 0 is the first axis, and a
// negative axis counts from the end (-1 = columns, -2 = rows), as in NumPy.
//
//   concat(A, B, ..., axis=0)   join along an EXISTING axis              np.concatenate
//   stack(A, B, ..., axis=0)    join along a NEW axis (rank + 1)         np.stack
//   row_stack(A, B, ...)        rows below rows      = [A; B]            np.vstack / np.row_stack
//   vstack(A, B, ...)           the same as row_stack
//   column_stack(A, B, ...)     columns beside columns = [A, B]          np.hstack / np.column_stack
//   hstack(A, B, ...)           the same as column_stack
//   matrix_split(A, n_or_positions, axis=0)                              np.split
//   vsplit(A, n_or_positions)   cut between rows    (axis -2)            np.vsplit
//   hsplit(A, n_or_positions)   cut between columns (axis -1)            np.hsplit
//
// Matrix-centred choices (for 1-D and 2-D inputs every result equals
// NumPy's with NC's [1, 2, 3] being the 1x3 matrix it is):
//   - row_stack / column_stack always join along the ROWS (axis -2) and the
//     COLUMNS (axis -1) - for an N-D matrix too, exactly like NC's own
//     [A; B] and [A, B]. (NumPy's vstack / hstack use axes 0 / 1 instead,
//     which for an N-D array are not its rows and columns.)
//   - inputs of lower rank get leading 1s first ([1, 2] next to a 2x2x2
//     matrix is taken as 1x1x2), the way the matrix literal does it;
//   - an empty input ([]) is left out, as in the literal;
//   - the element types are unified by the matrix type rules - the result
//     is exactly what the literal [A, B] would hold (matUnifyCells()).
// A split always gives matrices; one name receives them all as a list
// (P = matrix_split(A, 3); P[0]), several names one piece each
// ([L, R] = hsplit(A, 2)).
#include "cs_join_split.h"

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

#include "../numpy_common.h"
#include "../../ops/matrix/matrix_index.h"
#include "../../ops/matrix/nd_array.h"

namespace nc {
namespace numpy {

namespace {

struct Piece {
  nd::Shape shape;
  std::vector<Value> cells; // row-major
};

std::string axisWord(long long axis) { return "axis " + std::to_string(axis); }

// A whole number in [-n, n-1] (or [-(n+1), n] when `inserting`), as an index.
bool resolveAxis(const Value &a, size_t rank, bool inserting, size_t &out, long long &written,
                 CallContext &ctx) {
  if (!isPlainNumber(a) || !std::isfinite(a.number) || a.number != std::floor(a.number)) {
    ctx.fail("axis must be a whole number, e.g. axis=0 (rows of a matrix) or axis=-1 (columns)");
    return false;
  }
  const long long n = static_cast<long long>(rank) + (inserting ? 1 : 0);
  written = static_cast<long long>(a.number);
  if (written < -n || written >= n) {
    ctx.fail("axis " + std::to_string(written) + " does not exist for a " + std::to_string(rank) +
             "-D input - use 0 to " + std::to_string(n - 1) + " (or -1 to -" + std::to_string(n) +
             ")");
    return false;
  }
  out = static_cast<size_t>(written < 0 ? written + n : written);
  return true;
}

// The inputs as matrices of one common rank (leading 1s added); empty ones
// are left out when `skipEmpty`.
bool gather(const std::vector<Value> &values, bool skipEmpty, std::vector<Piece> &pieces,
            size_t &rank, CallContext &ctx) {
  pieces.clear();
  rank = 2;
  for (size_t i = 0; i < values.size(); i++) {
    const Value &v = values[i];
    if (v.isDict || v.isObject || v.isFunctionRef) {
      ctx.fail("input " + std::to_string(i + 1) + " is not a matrix, number or text");
      return false;
    }
    Piece p;
    p.shape = nd::shapeOf(v);
    if (skipEmpty && nd::countOf(p.shape) == 0)
      continue;
    p.cells = nd::rowMajorCells(v);
    rank = std::max(rank, p.shape.size());
    pieces.push_back(std::move(p));
  }
  for (Piece &p : pieces)
    p.shape = nd::withRank(p.shape, rank);
  return true;
}

// Joins `pieces` (one rank) along existing axis `axis`.
bool joinAlong(const std::vector<Piece> &pieces, size_t axis, long long axisWritten, Value &out,
               CallContext &ctx) {
  if (pieces.empty()) {
    out = Value(std::vector<std::vector<Value>>{}); // every input was []
    return true;
  }
  const nd::Shape &first = pieces[0].shape;
  nd::Shape result = first;
  result[axis] = 0;
  for (const Piece &p : pieces) {
    for (size_t d = 0; d < first.size(); d++)
      if (d != axis && p.shape[d] != first[d]) {
        ctx.fail("every input must have the same size except along " + axisWord(axisWritten) +
                 " - got " + nd::shapeText(first) + " and " + nd::shapeText(p.shape));
        return false;
      }
    result[axis] += p.shape[axis];
  }
  size_t outer = 1, inner = 1;
  for (size_t d = 0; d < axis; d++)
    outer *= first[d];
  for (size_t d = axis + 1; d < first.size(); d++)
    inner *= first[d];

  std::vector<Value> cells;
  cells.reserve(nd::countOf(result));
  for (size_t o = 0; o < outer; o++)
    for (const Piece &p : pieces) {
      const size_t block = p.shape[axis] * inner;
      cells.insert(cells.end(), p.cells.begin() + o * block, p.cells.begin() + (o + 1) * block);
    }
  // The literal's type rules: int + float -> float, any text -> text, a
  // timestamp never next to a number ...
  std::string err;
  if (!matUnifyCells(cells, err)) {
    ctx.fail(err);
    return false;
  }
  out = nd::buildRowMajor(result, cells);
  return true;
}

// concat / row_stack / column_stack: `axisArg` null = use `fixedAxis`
// (negative, counted from the end).
Value joinValues(const std::vector<Value> &arrays, const Value *axisArg, long long fixedAxis,
                 CallContext &ctx) {
  std::vector<Piece> pieces;
  size_t rank = 2;
  if (!gather(arrays, true, pieces, rank, ctx))
    return Value(0.0);
  size_t axis = 0;
  long long written = fixedAxis;
  if (axisArg) {
    if (!resolveAxis(*axisArg, rank, false, axis, written, ctx))
      return Value(0.0);
  } else {
    axis = static_cast<size_t>(static_cast<long long>(rank) + fixedAxis);
  }
  Value out;
  if (!joinAlong(pieces, axis, written, out, ctx))
    return Value(0.0);
  return out;
}

// stack(A, B, ..., axis): every input the same shape; a new axis of length
// (number of inputs) at `axis`.
Value stackValues(const std::vector<Value> &arrays, const Value &axisArg, CallContext &ctx) {
  std::vector<Piece> pieces;
  size_t rank = 2;
  if (!gather(arrays, false, pieces, rank, ctx))
    return Value(0.0);
  for (size_t i = 1; i < pieces.size(); i++)
    if (pieces[i].shape != pieces[0].shape) {
      ctx.fail("every input must have the same size - got " + nd::shapeText(pieces[0].shape) +
               " and " + nd::shapeText(pieces[i].shape) + " (to join along an existing axis use "
               "concat)");
      return Value(0.0);
    }
  size_t axis = 0;
  long long written = 0;
  if (!resolveAxis(axisArg, rank, true, axis, written, ctx))
    return Value(0.0);
  for (Piece &p : pieces)
    p.shape.insert(p.shape.begin() + static_cast<std::ptrdiff_t>(axis), 1);
  Value out;
  if (!joinAlong(pieces, axis, written, out, ctx))
    return Value(0.0);
  return out;
}

/* ---- splitting ---- */

// The pieces of A cut along `axis` (fixed, negative from the end, when
// `axisArg` is null) at `sections`: a whole number n (n equal parts) or a
// vector of cut positions ([2, 5] -> before 2, 2 up to 5, from 5 on).
bool splitValue(const Value &a, const Value &sections, const Value *axisArg, long long fixedAxis,
                std::vector<Value> &out, CallContext &ctx) {
  if (a.isDict || a.isObject || a.isFunctionRef || a.isText) {
    ctx.fail("the first argument must be a matrix");
    return false;
  }
  const nd::Shape shape = nd::shapeOf(a);
  const std::vector<Value> cells = nd::rowMajorCells(a);
  size_t axis = 0;
  long long written = fixedAxis;
  if (axisArg) {
    if (!resolveAxis(*axisArg, shape.size(), false, axis, written, ctx))
      return false;
  } else {
    axis = static_cast<size_t>(static_cast<long long>(shape.size()) + fixedAxis);
  }
  const size_t len = shape[axis];
  const std::string what = shape.size() == 2 && axis == 0   ? "rows"
                           : shape.size() == 2 && axis == 1 ? "columns"
                                                            : "positions along " + axisWord(written);

  // Cut positions, 0 = start, len = end.
  std::vector<size_t> cuts{0};
  if (isPlainNumber(sections)) {
    const double n = sections.number;
    if (!std::isfinite(n) || n != std::floor(n) || n < 1) {
      ctx.fail("the number of parts must be a whole number >= 1, or give the cut positions as a "
               "vector, e.g. [2, 5]");
      return false;
    }
    const size_t parts = static_cast<size_t>(n);
    if (len % parts != 0) {
      // Suggest cuts giving `parts` nearly equal pieces: every ceil(len/parts).
      const size_t step = (len + parts - 1) / parts;
      std::string hint;
      for (size_t k = 1; k < parts && k * step < len; k++)
        hint += (hint.empty() ? "" : ", ") + std::to_string(k * step);
      ctx.fail(std::to_string(len) + " " + what + " cannot be cut into " + std::to_string(parts) +
               " equal parts - give the cut positions instead, e.g. [" + hint + "]");
      return false;
    }
    for (size_t k = 1; k < parts; k++)
      cuts.push_back(k * (len / parts));
  } else {
    std::vector<double> pos;
    if (!flattenNumbers(sections, pos)) {
      ctx.fail("the second argument must be a number of parts or a vector of cut positions");
      return false;
    }
    for (double p : pos) {
      if (!std::isfinite(p) || p != std::floor(p) || p < 0) {
        ctx.fail("cut positions must be whole numbers >= 0 (0-based), e.g. [2, 5]");
        return false;
      }
      // Past the end is the end, and a position before the previous one
      // gives an empty piece - NumPy's slicing rules.
      cuts.push_back(std::min(static_cast<size_t>(p), len));
    }
  }
  cuts.push_back(len);

  size_t outer = 1, inner = 1;
  for (size_t d = 0; d < axis; d++)
    outer *= shape[d];
  for (size_t d = axis + 1; d < shape.size(); d++)
    inner *= shape[d];

  out.clear();
  for (size_t k = 0; k + 1 < cuts.size(); k++) {
    const size_t b = cuts[k], e = std::max(cuts[k], cuts[k + 1]);
    nd::Shape ps = shape;
    ps[axis] = e - b;
    std::vector<Value> pc;
    pc.reserve(nd::countOf(ps));
    for (size_t o = 0; o < outer; o++)
      for (size_t i = b; i < e; i++) {
        const size_t start = (o * len + i) * inner;
        pc.insert(pc.end(), cells.begin() + start, cells.begin() + start + inner);
      }
    out.push_back(nd::buildRowMajor(ps, pc));
  }
  return true;
}

// A split as a plain call (one name): every piece, in a list.
Impl splitImpl(bool hasAxis, long long fixedAxis) {
  return [hasAxis, fixedAxis](const std::vector<Value> &args, CallContext &ctx) -> Value {
    std::vector<Value> pieces;
    if (!splitValue(args[0], args[1], hasAxis ? &args[2] : nullptr, fixedAxis, pieces, ctx))
      return Value(0.0);
    return Value(std::move(pieces));
  };
}

// [A1, A2, ...] = split(...): one piece per name.
MultiImpl splitMulti(bool hasAxis, long long fixedAxis) {
  return [hasAxis, fixedAxis](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
                              CallContext &ctx) {
    std::vector<Value> pieces;
    if (!splitValue(args[0], args[1], hasAxis ? &args[2] : nullptr, fixedAxis, pieces, ctx))
      return;
    if (nout == 1) {
      out = {Value(std::move(pieces))};
      return;
    }
    if (nout != pieces.size()) {
      ctx.fail("the split gives " + std::to_string(pieces.size()) + " pieces, but " +
               std::to_string(nout) + " names were given");
      return;
    }
    out = std::move(pieces);
  };
}

void addJoin(Registry &reg, const char *name, const char *summary, const char *numpyName,
             Impl impl) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::CombiningSplitting;
  spec.minArgs = 1;
  spec.maxArgs = kVariadic;
  spec.signature = std::string(name) + "(A1, A2, ...)";
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = true; // only moves elements
  reg.add(std::move(spec));
}

void addSplit(Registry &reg, const char *name, bool hasAxis, long long fixedAxis,
              const char *summary, const char *numpyName) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::CombiningSplitting;
  spec.minArgs = 2;
  spec.maxArgs = hasAxis ? 3 : 2;
  spec.signature = std::string(name) + "(A, sections" + (hasAxis ? ", axis=0)" : ")");
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = splitImpl(hasAxis, fixedAxis);
  spec.multiImpl = splitMulti(hasAxis, fixedAxis);
  spec.maxOutputs = 1 << 20;
  spec.acceptsComplex = true;
  reg.add(std::move(spec));
}

} // namespace

void registerJoinSplit(Registry &reg) {
  // concat(A, B, ..., axis=0): the values arrive first, axis last.
  addJoin(reg, "concat", "join matrices along an existing axis", "np.concatenate",
          [](const std::vector<Value> &args, CallContext &ctx) -> Value {
            const std::vector<Value> arrays(args.begin(), args.end() - 1);
            return joinValues(arrays, &args.back(), 0, ctx);
          });
  addJoin(reg, "stack", "join same-size matrices along a new axis", "np.stack",
          [](const std::vector<Value> &args, CallContext &ctx) -> Value {
            const std::vector<Value> arrays(args.begin(), args.end() - 1);
            return stackValues(arrays, args.back(), ctx);
          });
  for (const char *name : {"row_stack", "vstack"})
    addJoin(reg, name, "rows below rows, like [A; B]", "np.vstack",
            [](const std::vector<Value> &args, CallContext &ctx) -> Value {
              return joinValues(args, nullptr, -2, ctx);
            });
  for (const char *name : {"column_stack", "hstack"})
    addJoin(reg, name, "columns beside columns, like [A, B]", "np.hstack",
            [](const std::vector<Value> &args, CallContext &ctx) -> Value {
              return joinValues(args, nullptr, -1, ctx);
            });

  addSplit(reg, "matrix_split", true, 0, "cut a matrix into pieces along an axis", "np.split");
  addSplit(reg, "vsplit", false, -2, "cut a matrix between rows", "np.vsplit");
  addSplit(reg, "hsplit", false, -1, "cut a matrix between columns", "np.hsplit");

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"concat", "*A, axis=0"},       {"stack", "*A, axis=0"},
      {"row_stack", "*A"},            {"vstack", "*A"},
      {"column_stack", "*A"},         {"hstack", "*A"},
      {"matrix_split", "A, sections, axis=0"}, {"vsplit", "A, sections"},
      {"hsplit", "A, sections"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
