// Section 6 of 11 - Combining & Splitting (17 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_COMBINING_SPLITTING_MAIN_H
#define NC_NUMPY_COMBINING_SPLITTING_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Combining & Splitting function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerCombiningSplitting(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_COMBINING_SPLITTING_MAIN_H
