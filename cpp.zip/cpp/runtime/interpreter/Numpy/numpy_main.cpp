// Wires the 11 section folders into one registry and dispatches calls.
//
// Adding a function never touches this file - it goes in its section's
// <section>_main.cpp. This file changes only if a whole new section is added.
#include "numpy_main.h"
#include "numpy_poly1d.h"

#include <exception>
#include <cctype>
#include <iomanip>
#include <iostream>
#include <mutex>

#include "numpy_registry.h"

#include "importing_data/importing_data_main.h"
#include "creating_arrays/creating_arrays_main.h"
#include "inspecting_properties/inspecting_properties_main.h"
#include "copying_sorting_reshaping/copying_sorting_reshaping_main.h"
#include "adding_removing_elements/adding_removing_elements_main.h"
#include "combining_splitting/combining_splitting_main.h"
#include "indexing_slicing/indexing_slicing_main.h"
#include "scalar_math/scalar_math_main.h"
#include "vector_math/vector_math_main.h"
#include "statistics/statistics_main.h"
#include "working_with_data/working_with_data_main.h"

namespace nc {
namespace numpy {

namespace {

// Two framework commands, not part of the 582: they let the team (and the
// IDE) see what is wired up.
//   numpy_functions()               -> array of every registered name
//   numpy_functions("vector_math")  -> names in one section
//   numpy_status()                  -> prints done / skipped / planned per section
const char *kListFn = "numpy_functions";
const char *kStatusFn = "numpy_status";

bool sectionByFolder(const std::string &folder, Section &out) {
  for (int i = 0; i < static_cast<int>(Section::Count); i++) {
    Section s = static_cast<Section>(i);
    if (folder == sectionInfo(s).folder) {
      out = s;
      return true;
    }
  }
  return false;
}

std::string argCountText(int minArgs, int maxArgs) {
  if (maxArgs == kVariadic)
    return "at least " + std::to_string(minArgs);
  if (minArgs == maxArgs)
    return std::to_string(minArgs);
  return std::to_string(minArgs) + " to " + std::to_string(maxArgs);
}

Value listFunctions(const std::vector<Value> &args, bool &ok) {
  const Registry &reg = Registry::instance();
  std::vector<std::string> names;
  if (args.empty()) {
    names = reg.names();
  } else if (args.size() == 1 && args[0].isText) {
    Section s;
    if (!sectionByFolder(args[0].text(), s)) {
      std::cerr << "Error: " << kListFn << ": unknown section '" << args[0].text()
                << "' - use a folder name such as \"vector_math\"\n";
      ok = false;
      return Value(0.0);
    }
    names = reg.names(s);
  } else {
    std::cerr << "Error: " << kListFn << " expects no arguments or one section name in quotes\n";
    ok = false;
    return Value(0.0);
  }
  std::vector<Value> out;
  out.reserve(names.size());
  for (const auto &n : names)
    out.push_back(Value(n));
  return Value(out);
}

Value printStatus(const std::vector<Value> &args, bool &ok) {
  if (!args.empty()) {
    std::cerr << "Error: " << kStatusFn << " takes no arguments\n";
    ok = false;
    return Value(0.0);
  }
  const Registry &reg = Registry::instance();
  size_t skippedTotal = 0;
  std::cout << std::left << std::setw(4) << "#" << std::setw(28) << "section" << std::right
            << std::setw(6) << "done" << std::setw(9) << "skipped" << std::setw(9) << "planned"
            << "\n";
  for (int i = 0; i < static_cast<int>(Section::Count); i++) {
    const SectionInfo &info = sectionInfo(static_cast<Section>(i));
    skippedTotal += reg.skippedIn(info.section);
    std::cout << std::left << std::setw(4) << (i + 1) << std::setw(28) << info.folder
              << std::right << std::setw(6) << reg.countIn(info.section) << std::setw(9)
              << reg.skippedIn(info.section) << std::setw(9) << info.plannedEntries << "\n";
  }
  std::cout << std::left << std::setw(32) << "    total" << std::right << std::setw(6)
            << reg.size() << std::setw(9) << skippedTotal << std::setw(9) << plannedTotal()
            << std::endl;
  return Value(static_cast<double>(reg.size()));
}

// Applies the function's parameter line to the call (core/param_list.h):
// named values are placed, defaults filled in, trailing left-out inputs
// dropped. A function without a parameter line takes values in order only.
// False (with the error printed) when the call does not fit.
bool prepareArgs(const FunctionSpec &spec, const std::vector<Value> &argsIn,
                 const std::vector<std::string> &argNames, std::vector<Value> &prepared) {
  // A poly1d value (numpy_poly1d.h) given to any NumPy function is its
  // coefficient row: polyval(P, 2), roots(P), polyder(P) ... (R6).
  std::vector<Value> args = argsIn;
  for (Value &a : args)
    if (isPoly1d(a))
      a = poly1dCoefficients(a);
  if (spec.params.empty()) {
    if (!argNames.empty()) {
      std::cerr << "Error: " << spec.name << ": its values cannot be named yet - give them in "
                << "order";
      if (!spec.signature.empty())
        std::cerr << " - usage: " << spec.signature;
      std::cerr << "\n";
      return false;
    }
    prepared = args;
    return true;
  }
  std::string why;
  if (!ncargs::normalizeCall(spec.params, args, argNames, prepared, why)) {
    std::cerr << "Error: " << spec.name << ": " << why << " (usage: " << spec.signature << ")\n";
    return false;
  }
  return true;
}

} // namespace

void initialize() {
  static std::once_flag once;
  std::call_once(once, [] {
    Registry &reg = Registry::instance();
    registerImportingData(reg);
    registerCreatingArrays(reg);
    registerInspectingProperties(reg);
    registerCopyingSortingReshaping(reg);
    registerAddingRemovingElements(reg);
    registerCombiningSplitting(reg);
    registerIndexingSlicing(reg);
    registerScalarMath(reg);
    registerVectorMath(reg);
    registerStatistics(reg);
    registerWorkingWithData(reg);
  });
}

// The expN / logaddexpN name families (exp2, exp10, logaddexp2, ...) are
// not registry entries - any digits are accepted - so they are matched here
// after the registry (vector_math/vm_ufuncs.cpp implements them).
bool isFamilyName(const std::string &name) {
  std::string low = name;
  for (char &c : low)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  for (const char *family : {"logaddexp", "exp"}) {
    const size_t n = std::char_traits<char>::length(family);
    if (low.size() > n && low.rfind(family, 0) == 0 &&
        low.find_first_not_of("0123456789", n) == std::string::npos)
      return true;
  }
  return false;
}

bool isNumpyFunction(const std::string &name) {
  initialize();
  return name == kListFn || name == kStatusFn || Registry::instance().contains(name) ||
         isFamilyName(name);
}

// Checks the (already prepared) arguments and runs the function.
static bool runSpec(const FunctionSpec &spec, const std::vector<Value> &args, Value &out, bool &ok);

bool tryCall(const std::string &name, const std::vector<Value> &argsIn, Value &out, bool &ok,
             const std::vector<std::string> &argNames) {
  initialize();
  const std::vector<Value> &args = argsIn; // as written; see `prepared` below

  if ((name == kListFn || name == kStatusFn) && !argNames.empty()) {
    std::cerr << "Error: " << name << ": its values cannot be named - give them in order\n";
    ok = false;
    return true;
  }
  if (name == kListFn) {
    ok = true;
    out = listFunctions(args, ok);
    return true;
  }
  if (name == kStatusFn) {
    ok = true;
    out = printStatus(args, ok);
    return true;
  }

  const FunctionSpec *spec = Registry::instance().find(name);
  if (!spec) {
    if (!isFamilyName(name))
      return false;
    if (!argNames.empty()) {
      std::cerr << "Error: " << name << ": its value cannot be named - give it in order\n";
      ok = false;
      return true;
    }
    ok = true;
    CallContext ctx(name);
    bool matched = false;
    try {
      out = callVectorMathFamily(name, args, ctx, matched);
    } catch (const std::exception &e) {
      ctx.fail(std::string("internal error: ") + e.what());
    }
    if (!matched)
      return false;
    ok = ctx.ok();
    if (!ok)
      out = Value(0.0);
    return true;
  }

  ok = true;
  out = Value(0.0);

  std::vector<Value> prepared;
  if (!prepareArgs(*spec, argsIn, argNames, prepared)) {
    ok = false;
    return true;
  }
  return runSpec(*spec, prepared, out, ok);
}

static bool runSpec(const FunctionSpec &specRef, const std::vector<Value> &args, Value &out,
                    bool &ok) {
  const FunctionSpec *spec = &specRef;
  int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kVariadic && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects "
              << argCountText(spec->minArgs, spec->maxArgs) << " argument(s), got " << argc;
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }

  if (!spec->acceptsComplex) {
    for (const Value &a : args) {
      if (a.hasComplex()) {
        std::cerr << "Error: '" << spec->name << "' does not support complex numbers yet\n";
        ok = false;
        return true;
      }
    }
  }

  CallContext ctx(spec->name);
  Value result;
  try {
    if (spec->impl) {
      result = spec->impl(args, ctx);
    } else {
      std::vector<Value> outs;
      spec->multiImpl(args, 1, outs, ctx);
      if (ctx.ok() && !outs.empty())
        result = outs[0];
    }
  } catch (const std::exception &e) {
    ctx.fail(std::string("internal error: ") + e.what());
  } catch (...) {
    ctx.fail("internal error");
  }

  if (!ctx.ok()) {
    ok = false;
    return true;
  }
  out = std::move(result);
  return true;
}

bool tryCallMulti(const std::string &name, const std::vector<Value> &argsIn, size_t nout,
                  std::vector<Value> &out, bool &ok, const std::vector<std::string> &argNames) {
  initialize();
  const FunctionSpec *spec = Registry::instance().find(name);
  if (!spec || !spec->multiImpl)
    return false;

  ok = true;
  out.clear();
  std::vector<Value> args;
  if (!prepareArgs(*spec, argsIn, argNames, args)) {
    ok = false;
    return true;
  }
  int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kVariadic && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects "
              << argCountText(spec->minArgs, spec->maxArgs) << " argument(s), got " << argc;
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }
  if (nout < 1 || nout > static_cast<size_t>(spec->maxOutputs)) {
    std::cerr << "Error: " << spec->name << " returns at most " << spec->maxOutputs
              << " value(s), but " << nout << " names were given";
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }
  if (!spec->acceptsComplex) {
    for (const Value &a : args) {
      if (a.hasComplex()) {
        std::cerr << "Error: '" << spec->name << "' does not support complex numbers yet\n";
        ok = false;
        return true;
      }
    }
  }

  CallContext ctx(spec->name);
  try {
    spec->multiImpl(args, nout, out, ctx);
  } catch (const std::exception &e) {
    ctx.fail(std::string("internal error: ") + e.what());
  } catch (...) {
    ctx.fail("internal error");
  }
  ok = ctx.ok() && out.size() == nout;
  if (ctx.ok() && out.size() != nout) {
    std::cerr << "Error: " << spec->name << ": internal error - produced " << out.size()
              << " value(s) for " << nout << " name(s)\n";
  }
  return true;
}

} // namespace numpy
} // namespace nc
