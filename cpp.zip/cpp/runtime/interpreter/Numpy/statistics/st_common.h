// Helpers shared by the Statistics group files (st_reduce.cpp, st_hist.cpp,
// st_calculus.cpp). Private to the statistics folder.
//
// Reductions take axis="all" (the default: every element, one result) or an
// axis number: one result per line along that axis, and the axis goes away
// - the same shape rule as max(A, axis=k): a matrix reduced along one axis
// gives a row.
#ifndef NC_NUMPY_ST_COMMON_H
#define NC_NUMPY_ST_COMMON_H

#include <cctype>
#include <cmath>
#include <functional>
#include <string>
#include <vector>

#include "../numpy_nd.h"

namespace nc {
namespace numpy {
namespace st {

using ndx::Grid;

// axis="all" (any letter case) or a whole number.
inline bool readAxis(const Value &a, size_t rank, CallContext &ctx, bool &all, size_t &axis) {
  if (a.isText) {
    std::string s = a.text();
    for (char &c : s)
      c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    if (s == "all") {
      all = true;
      return true;
    }
    ctx.fail("axis must be a whole number or \"all\" (every element)");
    return false;
  }
  all = false;
  return ndx::resolveAxis(a, rank, ctx, axis);
}

// Every element as a double; fails (with a message) for complex, text or
// time values.
inline bool realGrid(const Value &v, size_t argIndex, CallContext &ctx, Grid &g,
                     std::vector<double> &x) {
  if (ndx::notMatrixData(v)) {
    ctx.fail("the " + ordinal(argIndex) + " argument must be numbers");
    return false;
  }
  g = ndx::gridOf(v);
  if (!ndx::realCells(g, x)) {
    ctx.fail("it works on real numbers (not complex numbers, text or time values)");
    return false;
  }
  return true;
}

// fn(line, out) gives `width` numbers for one line of values.
using LineFn = std::function<bool(std::vector<double> &, std::vector<double> &, CallContext &)>;

// One result (or `width` results) per line: every element (`all`), or each
// line along `axis`. With `prependWidth` the width becomes a new first axis
// (percentile with several q); otherwise width must be 1.
inline bool reduceLines(const nd::Shape &shape, const std::vector<double> &x, bool all,
                        size_t axis, size_t width, bool prependWidth, const LineFn &fn,
                        CallContext &ctx, Value &out) {
  std::vector<double> res;
  if (all) {
    std::vector<double> line = x;
    if (!fn(line, res, ctx))
      return false;
    if (width == 1 && !prependWidth) {
      out = Value(res[0]);
      return true;
    }
    out = makeMatrix(std::vector<std::vector<double>>{res});
    return true;
  }
  const ndx::AxisView v = ndx::viewOf(shape, axis);
  nd::Shape rest;
  if (prependWidth)
    rest.push_back(width);
  for (size_t d = 0; d < shape.size(); d++)
    if (d != axis)
      rest.push_back(shape[d]);
  const size_t positions = v.outer * v.inner;
  std::vector<Value> cells(positions * width);
  std::vector<double> line(v.len);
  for (size_t o = 0; o < v.outer; o++)
    for (size_t i = 0; i < v.inner; i++) {
      for (size_t k = 0; k < v.len; k++)
        line[k] = x[(o * v.len + k) * v.inner + i];
      std::vector<double> l = line;
      if (!fn(l, res, ctx))
        return false;
      for (size_t w = 0; w < width; w++)
        cells[w * positions + o * v.inner + i] = Value(res[w]);
    }
  out = nd::buildRowMajor(rest, cells);
  return true;
}

// fn(line) changes a line in place (same length): cumulative sums ...
// `all`: the elements row by row, giving a row; else each line along axis,
// keeping the shape.
using MapLineFn = std::function<void(std::vector<double> &)>;

inline Value mapLines(const nd::Shape &shape, std::vector<double> x, bool all, size_t axis,
                      const MapLineFn &fn) {
  if (all) {
    fn(x);
    return makeMatrix(std::vector<std::vector<double>>{x});
  }
  const ndx::AxisView v = ndx::viewOf(shape, axis);
  std::vector<double> line(v.len);
  for (size_t o = 0; o < v.outer; o++)
    for (size_t i = 0; i < v.inner; i++) {
      for (size_t k = 0; k < v.len; k++)
        line[k] = x[(o * v.len + k) * v.inner + i];
      fn(line);
      for (size_t k = 0; k < v.len; k++)
        x[(o * v.len + k) * v.inner + i] = line[k];
    }
  std::vector<Value> cells;
  cells.reserve(x.size());
  for (double d : x)
    cells.push_back(Value(d));
  return nd::buildRowMajor(shape, cells);
}

inline std::vector<double> withoutNaN(const std::vector<double> &x) {
  std::vector<double> out;
  out.reserve(x.size());
  for (double d : x)
    if (!std::isnan(d))
      out.push_back(d);
  return out;
}

inline Value numberRow(const std::vector<double> &x) {
  return makeMatrix(std::vector<std::vector<double>>{x});
}

inline void addFn(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
                  const char *numpyName, Impl impl, bool acceptsComplex = false) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::Statistics;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = acceptsComplex;
  reg.add(std::move(spec));
}

inline void addResults(Registry &reg, const char *name, int minArgs, int maxArgs,
                       const char *summary, const char *numpyName, ndx::ResultsFn fn) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::Statistics;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = ndx::resultsAsList(fn);
  spec.multiImpl = ndx::resultsPerName(fn);
  spec.maxOutputs = 64;
  reg.add(std::move(spec));
}

// Group registration functions (one per .cpp).
void registerReductions(Registry &reg);
void registerHistograms(Registry &reg);
void registerCalculus(Registry &reg);

} // namespace st
} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_ST_COMMON_H
