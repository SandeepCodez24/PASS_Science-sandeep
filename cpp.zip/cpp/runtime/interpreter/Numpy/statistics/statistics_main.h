// Section 10 of 11 - Statistics (55 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_STATISTICS_MAIN_H
#define NC_NUMPY_STATISTICS_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Statistics function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerStatistics(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_STATISTICS_MAIN_H
