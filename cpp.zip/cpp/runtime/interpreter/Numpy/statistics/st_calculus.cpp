// Statistics - sequences: correlation, derivatives, integrals, interpolation.
//
//   correlate(a, v, mode="valid")   cross-correlation c[k] = sum a[n+k] * v[n]   np.correlate
//                                   "valid": only full overlaps, "same": as long as
//                                   the longer input, "full": every overlap
//   gradient(f, spacing=1, axis="all")                                         np.gradient
//                                   rate of change: central differences inside,
//                                   one-sided at the ends. spacing: the step (one
//                                   number) or the coordinates (one per point, for
//                                   one axis). A vector gives one gradient along
//                                   its length; a matrix [g_rows, g_cols]
//                                   (axis="all") or the gradient along one axis.
//   trapz(y, dx=1, axis=-1, x?)     area under y by the trapezoid rule          np.trapz
//                                   (x: the coordinates; a vector given second is
//                                   taken as x). A vector is integrated along its
//                                   length, a matrix row by row (axis=-1).
//   interp(x, xp, fp, left="end", right="end")  straight-line interpolation of the points
//                                   (xp, fp), xp increasing; outside: fp's end
//                                   values ("end"), or the numbers left / right  np.interp
#include <algorithm>
#include <cctype>
#include <cmath>
#include <string>
#include <vector>

#include "st_common.h"

namespace nc {
namespace numpy {
namespace st {

namespace {

Value correlate(const std::vector<Value> &args, CallContext &ctx) {
  Grid ga, gv;
  std::vector<double> a, v;
  if (!realGrid(args[0], 0, ctx, ga, a) || !realGrid(args[1], 1, ctx, gv, v))
    return Value(0.0);
  std::string mode;
  if (!argText(args, 2, ctx, mode))
    return Value(0.0);
  for (char &c : mode)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (mode != "valid" && mode != "same" && mode != "full") {
    ctx.fail("mode must be \"valid\", \"same\" or \"full\"");
    return Value(0.0);
  }
  if (a.empty() || v.empty()) {
    ctx.fail("both inputs need at least one value");
    return Value(0.0);
  }
  // Full correlation = convolution of a with v reversed.
  const size_t n = a.size(), m = v.size();
  std::vector<double> full(n + m - 1, 0.0);
  for (size_t i = 0; i < n; i++)
    for (size_t j = 0; j < m; j++)
      full[i + j] += a[i] * v[m - 1 - j];
  const size_t lo = std::min(n, m), hi = std::max(n, m);
  std::vector<double> out;
  if (mode == "full")
    out = full;
  else if (mode == "same")
    out.assign(full.begin() + static_cast<std::ptrdiff_t>((lo - 1) / 2),
               full.begin() + static_cast<std::ptrdiff_t>((lo - 1) / 2 + hi));
  else
    out.assign(full.begin() + static_cast<std::ptrdiff_t>(lo - 1),
               full.begin() + static_cast<std::ptrdiff_t>(hi));
  return numberRow(out);
}

// Gradient of one line: coordinates `x` (same length) - NumPy's second-order
// central formula for uneven steps, first-order at the ends.
std::vector<double> gradientLine(const std::vector<double> &f, const std::vector<double> &x) {
  const size_t n = f.size();
  std::vector<double> g(n);
  g[0] = (f[1] - f[0]) / (x[1] - x[0]);
  g[n - 1] = (f[n - 1] - f[n - 2]) / (x[n - 1] - x[n - 2]);
  for (size_t i = 1; i + 1 < n; i++) {
    const double hs = x[i] - x[i - 1], hd = x[i + 1] - x[i];
    g[i] = (hs * hs * f[i + 1] + (hd * hd - hs * hs) * f[i] - hd * hd * f[i - 1]) /
           (hs * hd * (hd + hs));
  }
  return g;
}

bool gradientResults(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  Grid g, sg;
  std::vector<double> f, sp;
  if (!realGrid(args[0], 0, ctx, g, f) || !realGrid(args[1], 1, ctx, sg, sp))
    return false;
  bool all = true;
  size_t axis = 0;
  if (!readAxis(args[2], g.shape.size(), ctx, all, axis))
    return false;
  std::vector<size_t> axes;
  const bool vector = g.shape.size() == 2 && (g.shape[0] == 1 || g.shape[1] == 1);
  if (!all)
    axes = {axis};
  else if (vector)
    axes = {g.shape[0] == 1 ? size_t{1} : size_t{0}}; // along its length
  else
    for (size_t d = 0; d < g.shape.size(); d++)
      axes.push_back(d);
  if (sp.size() != 1 && axes.size() != 1) {
    ctx.fail("coordinates as spacing work along one axis - give one step for all axes, or "
             "choose an axis");
    return false;
  }
  out.clear();
  for (size_t ax : axes) {
    const size_t len = g.shape[ax];
    if (len < 2) {
      ctx.fail("a gradient needs at least 2 points along axis " + std::to_string(ax));
      return false;
    }
    std::vector<double> x(len);
    if (sp.size() == 1) {
      if (!(sp[0] != 0) || !std::isfinite(sp[0])) {
        ctx.fail("spacing must be a non-zero number");
        return false;
      }
      for (size_t k = 0; k < len; k++)
        x[k] = sp[0] * static_cast<double>(k);
    } else if (sp.size() == len) {
      x = sp;
      for (size_t k = 1; k < len; k++)
        if (x[k] == x[k - 1]) {
          ctx.fail("the coordinates must all differ");
          return false;
        }
    } else {
      ctx.fail("spacing must be one number or one coordinate per point (" + std::to_string(len) +
               ")");
      return false;
    }
    out.push_back(mapLines(g.shape, f, false, ax,
                           [&](std::vector<double> &l) { l = gradientLine(l, x); }));
  }
  return true;
}

Value trapz(const std::vector<Value> &args, CallContext &ctx) {
  Grid g;
  std::vector<double> y;
  if (!realGrid(args[0], 0, ctx, g, y))
    return Value(0.0);
  // A vector in the dx place is the coordinates.
  const Value *xArg = args.size() > 3 ? &args[3] : nullptr;
  double dx = 1;
  if (args[1].isArray || args[1].isMatrix)
    xArg = &args[1];
  else if (!argNumber(args, 1, ctx, dx))
    return Value(0.0);
  size_t axis = 0;
  if (!ndx::resolveAxis(args[2], g.shape.size(), ctx, axis))
    return Value(0.0);
  // A column vector is integrated along its length.
  if (g.shape.size() == 2 && g.shape[1] == 1 && g.shape[0] > 1 && axis == 1)
    axis = 0;
  const size_t len = g.shape[axis];
  std::vector<double> x;
  if (xArg) {
    Grid xg;
    if (!realGrid(*xArg, 3, ctx, xg, x))
      return Value(0.0);
    if (x.size() != len) {
      ctx.fail("x needs one coordinate per point along the axis (" + std::to_string(len) +
               "), got " + std::to_string(x.size()));
      return Value(0.0);
    }
  }
  Value out;
  LineFn fn = [&](std::vector<double> &l, std::vector<double> &res, CallContext &) {
    double s = 0;
    for (size_t k = 1; k < l.size(); k++)
      s += (xArg ? x[k] - x[k - 1] : dx) * (l[k] + l[k - 1]) / 2.0;
    res = {s};
    return true;
  };
  if (!reduceLines(g.shape, y, false, axis, 1, false, fn, ctx, out))
    return Value(0.0);
  Grid r = ndx::gridOf(out);
  if (r.count() == 1)
    return r.cells[0]; // one line: one number
  return out;
}

Value interp(const std::vector<Value> &args, CallContext &ctx) {
  Grid gx, gxp, gfp;
  std::vector<double> x, xp, fp;
  if (!realGrid(args[0], 0, ctx, gx, x) || !realGrid(args[1], 1, ctx, gxp, xp) ||
      !realGrid(args[2], 2, ctx, gfp, fp))
    return Value(0.0);
  if (xp.empty() || xp.size() != fp.size()) {
    ctx.fail("xp and fp need the same number of values (at least one) - got " +
             std::to_string(xp.size()) + " and " + std::to_string(fp.size()));
    return Value(0.0);
  }
  for (size_t i = 1; i < xp.size(); i++)
    if (!(xp[i] > xp[i - 1])) {
      ctx.fail("xp must increase from left to right");
      return Value(0.0);
    }
  // left / right: "end" (fp's first / last value) or a number.
  double left = fp.front(), right = fp.back();
  for (size_t i = 3; i <= 4 && i < args.size(); i++) {
    if (args[i].isText) {
      std::string s = args[i].text();
      for (char &c : s)
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
      if (s != "end") {
        ctx.fail(std::string(i == 3 ? "left" : "right") + " must be a number or \"end\"");
        return Value(0.0);
      }
    } else if (!argNumber(args, i, ctx, i == 3 ? left : right)) {
      return Value(0.0);
    }
  }
  for (size_t k = 0; k < x.size(); k++) {
    const double v = x[k];
    double r = 0;
    if (std::isnan(v))
      r = v;
    else if (v < xp.front())
      r = left;
    else if (v > xp.back())
      r = right;
    else {
      size_t i = static_cast<size_t>(std::upper_bound(xp.begin(), xp.end(), v) - xp.begin());
      if (i >= xp.size())
        r = fp.back(); // v is the last point
      else {
        const double t = (v - xp[i - 1]) / (xp[i] - xp[i - 1]);
        r = fp[i - 1] + t * (fp[i] - fp[i - 1]);
      }
    }
    gx.cells[k] = Value(r);
  }
  if (!args[0].isArray && !args[0].isMatrix)
    return gx.cells[0];
  return ndx::valueOf(gx);
}

} // namespace

void registerCalculus(Registry &reg) {
  addFn(reg, "correlate", 2, 3, "cross-correlation of two sequences", "np.correlate", correlate);
  addResults(reg, "gradient", 1, 3, "rate of change along each axis", "np.gradient",
             gradientResults);
  addFn(reg, "trapz", 1, 4, "area under the curve (trapezoid rule)", "np.trapz", trapz);
  addFn(reg, "interp", 3, 5, "straight-line interpolation", "np.interp", interp);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"correlate", "a, v, mode=\"valid\""},
      {"gradient", "f, spacing=1, axis=\"all\""},
      {"trapz", "y, dx=1, axis=-1, x?"},
      {"interp", "x, xp, fp, left=\"end\", right=\"end\""},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace st
} // namespace numpy
} // namespace nc
