// Statistics - counting values into bins.
//
//   [counts, edges] = histogram(a, bins=10, density=false, range?)      np.histogram
//   bin_edges(a, bins=10, range?)                          np.histogram_bin_edges
//   [H, xedges, yedges] = histogram2d(x, y, bins=10, range?)            np.histogram2d
//   [H, edges] = histogramdd(sample, bins=10, range?)                   np.histogramdd
//   bincount(x, weights=1, minlength=0)                    np.bincount
//   digitize(x, bins, right=false)                         np.digitize
//
// bins: a number of equal-width bins, or (histogram, bin_edges) the edges
// themselves, increasing. range = [lo, hi] (histogram2d: [xlo, xhi; ylo, hi],
// histogramdd: one [lo, hi] row per dimension); without it the data's own
// smallest and largest values. Every bin holds lo <= x < hi, except the last,
// which also holds its right edge. Values outside the range are not counted.
// density=true divides each count by (total * bin width), so the bars have
// area 1. histogramdd: the rows of `sample` are the points, its columns the
// dimensions; H has one axis per dimension and `edges` is a list of edge rows.
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

#include "st_common.h"

namespace nc {
namespace numpy {
namespace st {

namespace {

// Edges for `data`: `binsArg` a count or the edges; `rangeArg` null or [lo, hi].
bool edgesFor(const std::vector<double> &data, const Value &binsArg, const Value *rangeArg,
              CallContext &ctx, std::vector<double> &edges) {
  Grid bg;
  std::vector<double> b;
  if (!realGrid(binsArg, 1, ctx, bg, b) || b.empty())
    return false;
  if (b.size() > 1) { // the edges themselves
    for (size_t i = 1; i < b.size(); i++)
      if (!(b[i] > b[i - 1])) {
        ctx.fail("bin edges must increase from left to right");
        return false;
      }
    edges = b;
    return true;
  }
  const double n = b[0];
  if (!std::isfinite(n) || n != std::floor(n) || n < 1) {
    ctx.fail("bins must be a whole number >= 1, or the bin edges");
    return false;
  }
  double lo = 0, hi = 1;
  if (rangeArg) {
    Grid rg;
    std::vector<double> r;
    if (!realGrid(*rangeArg, 2, ctx, rg, r))
      return false;
    if (r.size() != 2 || !(r[0] <= r[1]) || !std::isfinite(r[0]) || !std::isfinite(r[1])) {
      ctx.fail("range must be [lo, hi] with lo <= hi");
      return false;
    }
    lo = r[0];
    hi = r[1];
  } else if (!data.empty()) {
    for (double v : data)
      if (!std::isfinite(v)) {
        ctx.fail("the data holds NaN or infinity - give range=[lo, hi] or remove them first");
        return false;
      }
    lo = *std::min_element(data.begin(), data.end());
    hi = *std::max_element(data.begin(), data.end());
  }
  if (lo == hi) { // NumPy widens an empty range by 0.5 each way
    lo -= 0.5;
    hi += 0.5;
  }
  const size_t count = static_cast<size_t>(n);
  edges.resize(count + 1);
  for (size_t i = 0; i <= count; i++)
    edges[i] = lo + (hi - lo) * static_cast<double>(i) / static_cast<double>(count);
  edges[count] = hi;
  return true;
}

// Bin of x (-1 = outside); the last bin is closed on the right.
long long binOf(double x, const std::vector<double> &edges) {
  if (!(x >= edges.front() && x <= edges.back()))
    return -1;
  const size_t nb = edges.size() - 1;
  if (x == edges.back())
    return static_cast<long long>(nb - 1);
  const auto it = std::upper_bound(edges.begin(), edges.end(), x);
  return static_cast<long long>(it - edges.begin()) - 1;
}

bool histogramResults(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  Grid g;
  std::vector<double> a, edges;
  if (!realGrid(args[0], 0, ctx, g, a) ||
      !edgesFor(a, args[1], args.size() > 3 ? &args[3] : nullptr, ctx, edges))
    return false;
  if (!args[2].isBool()) {
    ctx.fail("density must be true or false");
    return false;
  }
  std::vector<double> counts(edges.size() - 1, 0.0);
  double total = 0;
  for (double v : a) {
    const long long b = binOf(v, edges);
    if (b >= 0) {
      counts[static_cast<size_t>(b)] += 1;
      total += 1;
    }
  }
  if (args[2].number != 0.0 && total > 0)
    for (size_t i = 0; i < counts.size(); i++)
      counts[i] /= total * (edges[i + 1] - edges[i]);
  out = {numberRow(counts), numberRow(edges)};
  return true;
}

Value binEdges(const std::vector<Value> &args, CallContext &ctx) {
  Grid g;
  std::vector<double> a, edges;
  if (!realGrid(args[0], 0, ctx, g, a) ||
      !edgesFor(a, args[1], args.size() > 2 ? &args[2] : nullptr, ctx, edges))
    return Value(0.0);
  return numberRow(edges);
}

// Counts of points (rows of `pts`, `dims` columns) in a grid of bins.
bool histogramND(const std::vector<double> &pts, size_t dims, const Value &binsArg,
                 const Value *rangeArg, CallContext &ctx, Value &H,
                 std::vector<std::vector<double>> &allEdges) {
  const size_t n = dims == 0 ? 0 : pts.size() / dims;
  Grid bg;
  std::vector<double> b;
  if (!realGrid(binsArg, 1, ctx, bg, b))
    return false;
  if (b.size() != 1 && b.size() != dims) {
    ctx.fail("bins must be one number, or one per dimension (" + std::to_string(dims) + ")");
    return false;
  }
  std::vector<double> ranges;
  if (rangeArg) {
    Grid rg;
    if (!realGrid(*rangeArg, 2, ctx, rg, ranges))
      return false;
    if (ranges.size() != 2 * dims) {
      ctx.fail("range needs one [lo, hi] row per dimension (" + std::to_string(dims) + " rows)");
      return false;
    }
  }
  allEdges.assign(dims, {});
  nd::Shape shape;
  for (size_t d = 0; d < dims; d++) {
    std::vector<double> col(n);
    for (size_t p = 0; p < n; p++)
      col[p] = pts[p * dims + d];
    const Value bins(b[b.size() == 1 ? 0 : d]);
    Value range;
    if (rangeArg)
      range = Value(std::vector<Value>{Value(ranges[2 * d]), Value(ranges[2 * d + 1])});
    if (!edgesFor(col, bins, rangeArg ? &range : nullptr, ctx, allEdges[d]))
      return false;
    shape.push_back(allEdges[d].size() - 1);
  }
  std::vector<double> counts(nd::countOf(shape), 0.0);
  for (size_t p = 0; p < n; p++) {
    size_t flat = 0;
    bool inside = true;
    for (size_t d = 0; d < dims && inside; d++) {
      const long long bi = binOf(pts[p * dims + d], allEdges[d]);
      inside = bi >= 0;
      flat = flat * shape[d] + static_cast<size_t>(std::max(0LL, bi));
    }
    if (inside)
      counts[flat] += 1;
  }
  std::vector<Value> cells;
  for (double c : counts)
    cells.push_back(Value(c));
  H = nd::buildRowMajor(shape, cells);
  return true;
}

bool histogram2dResults(const std::vector<Value> &args, std::vector<Value> &out,
                        CallContext &ctx) {
  Grid gx, gy;
  std::vector<double> x, y;
  if (!realGrid(args[0], 0, ctx, gx, x) || !realGrid(args[1], 1, ctx, gy, y))
    return false;
  if (x.size() != y.size()) {
    ctx.fail("x and y need the same number of values (" + std::to_string(x.size()) + " and " +
             std::to_string(y.size()) + ")");
    return false;
  }
  std::vector<double> pts;
  for (size_t i = 0; i < x.size(); i++) {
    pts.push_back(x[i]);
    pts.push_back(y[i]);
  }
  Value H;
  std::vector<std::vector<double>> edges;
  if (!histogramND(pts, 2, args[2], args.size() > 3 ? &args[3] : nullptr, ctx, H, edges))
    return false;
  out = {H, numberRow(edges[0]), numberRow(edges[1])};
  return true;
}

bool histogramddResults(const std::vector<Value> &args, std::vector<Value> &out,
                        CallContext &ctx) {
  Grid g;
  std::vector<double> s;
  if (!realGrid(args[0], 0, ctx, g, s))
    return false;
  if (g.shape.size() != 2) {
    ctx.fail("sample must be a matrix: one row per point, one column per dimension");
    return false;
  }
  const size_t dims = g.shape[1];
  Value H;
  std::vector<std::vector<double>> edges;
  if (!histogramND(s, dims, args[1], args.size() > 2 ? &args[2] : nullptr, ctx, H, edges))
    return false;
  std::vector<Value> edgeRows;
  for (const auto &e : edges)
    edgeRows.push_back(numberRow(e));
  out = {H, Value(std::move(edgeRows))};
  return true;
}

Value bincount(const std::vector<Value> &args, CallContext &ctx) {
  Grid g, wg;
  std::vector<double> x, w;
  if (!realGrid(args[0], 0, ctx, g, x) || !realGrid(args[1], 1, ctx, wg, w))
    return Value(0.0);
  long long minlength = 0;
  if (!argNonNegativeInt(args, 2, ctx, minlength))
    return Value(0.0);
  if (w.size() != 1 && w.size() != x.size()) {
    ctx.fail("weights must be one number or one per value of x (" + std::to_string(x.size()) +
             ")");
    return Value(0.0);
  }
  size_t len = static_cast<size_t>(minlength);
  for (double v : x) {
    if (!std::isfinite(v) || v != std::floor(v) || v < 0) {
      ctx.fail("x must hold whole numbers >= 0");
      return Value(0.0);
    }
    len = std::max(len, static_cast<size_t>(v) + 1);
  }
  std::vector<double> counts(len, 0.0);
  for (size_t i = 0; i < x.size(); i++)
    counts[static_cast<size_t>(x[i])] += w[w.size() == 1 ? 0 : i];
  if (counts.empty())
    return Value(std::vector<std::vector<Value>>{});
  return numberRow(counts);
}

Value digitize(const std::vector<Value> &args, CallContext &ctx) {
  Grid g, bg;
  std::vector<double> x, b;
  if (!realGrid(args[0], 0, ctx, g, x) || !realGrid(args[1], 1, ctx, bg, b))
    return Value(0.0);
  if (!args[2].isBool()) {
    ctx.fail("right must be true or false");
    return Value(0.0);
  }
  const bool right = args[2].number != 0.0;
  bool inc = true, dec = true;
  for (size_t i = 1; i < b.size(); i++) {
    inc = inc && b[i] >= b[i - 1];
    dec = dec && b[i] <= b[i - 1];
  }
  if (!inc && !dec) {
    ctx.fail("bins must be sorted, increasing or decreasing");
    return Value(0.0);
  }
  std::vector<double> rev(b.rbegin(), b.rend());
  for (Value &c : g.cells) {
    const double v = c.number;
    size_t i = 0;
    if (inc) // bins[i-1] <= x < bins[i]  (right: bins[i-1] < x <= bins[i])
      i = static_cast<size_t>((right ? std::lower_bound(b.begin(), b.end(), v)
                                     : std::upper_bound(b.begin(), b.end(), v)) -
                              b.begin());
    else // bins[i-1] > x >= bins[i]  (right: bins[i-1] >= x > bins[i])
      i = b.size() - static_cast<size_t>((right ? std::lower_bound(rev.begin(), rev.end(), v)
                                                : std::upper_bound(rev.begin(), rev.end(), v)) -
                                         rev.begin());
    c = Value(static_cast<double>(i));
  }
  if (!args[0].isArray && !args[0].isMatrix)
    return g.cells[0];
  return ndx::valueOf(g);
}

} // namespace

void registerHistograms(Registry &reg) {
  addResults(reg, "histogram", 1, 4, "counts per bin, and the bin edges", "np.histogram",
             histogramResults);
  addFn(reg, "bin_edges", 1, 3, "the bin edges a histogram would use", "np.histogram_bin_edges",
        binEdges);
  addResults(reg, "histogram2d", 2, 4, "counts per 2-D bin, and both edge rows",
             "np.histogram2d", histogram2dResults);
  addResults(reg, "histogramdd", 1, 3, "counts per N-D bin, and the edges", "np.histogramdd",
             histogramddResults);
  addFn(reg, "bincount", 1, 3, "how often each whole number occurs", "np.bincount", bincount);
  addFn(reg, "digitize", 2, 3, "which bin each value falls in", "np.digitize", digitize);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"histogram", "a, bins=10, density=false, range?"},
      {"bin_edges", "a, bins=10, range?"},
      {"histogram2d", "x, y, bins=10, range?"},
      {"histogramdd", "sample, bins=10, range?"},
      {"bincount", "x, weights=1, minlength=0"},
      {"digitize", "x, bins, right=false"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace st
} // namespace numpy
} // namespace nc
