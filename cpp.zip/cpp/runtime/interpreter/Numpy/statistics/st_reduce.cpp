// Statistics - reductions and cumulative functions.
//
//   average(A, axis="all", weights=1)   weighted mean (weights=1: the plain mean)
//   prod(A, axis="all")                  product
//   argmin / argmax(A, axis="all")       position of the smallest / largest element
//                                        (flat, row by row, for axis="all"); the
//                                        first one when several are equal; a NaN
//                                        wins (as in NumPy)
//   count_nonzero(A, axis="all")         how many elements are not 0 (text: not "")
//   all / any(A, axis="all")             whether every / some element is true (not 0)
//   cumsum / cumprod(A, axis="all")      running sum / product (axis="all": the
//                                        elements row by row, as one row)
//   cumulative_sum / cumulative_prod(A, axis="all", include_initial=false)
//                                        the same, optionally starting with 0 / 1
//   nan_mean nan_median nan_sum nan_prod nan_min nan_max  (A, axis="all")
//   nan_argmin nan_argmax                                  (A, axis="all")
//   nan_var nan_sd                       (A, axis="all", ddof=0)  population by default
//   nan_percentile(A, q, axis="all")     q in 0..100     linear interpolation, as
//   nan_quantile(A, q, axis="all")       q in 0..1       NC's percentile()
//   nan_cumsum nan_cumprod               (A, axis="all")
// The nan_ functions leave NaN out. A line with nothing but NaN gives NaN
// (nan_sum: 0, nan_prod: 1); for nan_argmin / nan_argmax it is an error.
#include <algorithm>
#include <cmath>
#include <limits>
#include <string>
#include <vector>

#include "st_common.h"

namespace nc {
namespace numpy {
namespace st {

namespace {

const double kNaN = std::numeric_limits<double>::quiet_NaN();

// A reduction taking (A, axis="all").
Impl reduceImpl(LineFn fn) {
  return [fn](const std::vector<Value> &args, CallContext &ctx) -> Value {
    Grid g;
    std::vector<double> x;
    if (!realGrid(args[0], 0, ctx, g, x))
      return Value(0.0);
    bool all = true;
    size_t axis = 0;
    if (!readAxis(args[1], g.shape.size(), ctx, all, axis))
      return Value(0.0);
    Value out;
    if (!reduceLines(g.shape, x, all, axis, 1, false, fn, ctx, out))
      return Value(0.0);
    return out;
  };
}

LineFn simple(double (*f)(const std::vector<double> &)) {
  return [f](std::vector<double> &l, std::vector<double> &out, CallContext &) {
    out = {f(l)};
    return true;
  };
}

double sumOf(const std::vector<double> &l) {
  double s = 0; // Kahan-compensated, so long sums stay exact to the last digit
  double c = 0;
  for (double v : l) {
    const double y = v - c;
    const double t = s + y;
    c = (t - s) - y;
    s = t;
  }
  return s;
}

double prodOf(const std::vector<double> &l) {
  double p = 1;
  for (double v : l)
    p *= v;
  return p;
}

double meanOf(const std::vector<double> &l) {
  return l.empty() ? kNaN : sumOf(l) / static_cast<double>(l.size());
}

// q-th fraction (0..1) of the sorted values, linear interpolation.
double quantileOf(std::vector<double> l, double q) {
  if (l.empty())
    return kNaN;
  std::sort(l.begin(), l.end());
  const double pos = q * static_cast<double>(l.size() - 1);
  const size_t lo = static_cast<size_t>(std::floor(pos));
  const size_t hi = std::min(lo + 1, l.size() - 1);
  return l[lo] + (l[hi] - l[lo]) * (pos - static_cast<double>(lo));
}

double varOf(const std::vector<double> &l, double ddof) {
  const double n = static_cast<double>(l.size());
  if (n - ddof <= 0)
    return kNaN;
  const double m = meanOf(l);
  double s = 0;
  for (double v : l)
    s += (v - m) * (v - m);
  return s / (n - ddof);
}

// Position of the first smallest (or largest) value; -1 for an empty line.
// With `skipNaN` NaN is left out, otherwise the first NaN wins.
long long argExtreme(const std::vector<double> &l, bool largest, bool skipNaN) {
  long long best = -1;
  for (size_t i = 0; i < l.size(); i++) {
    if (std::isnan(l[i])) {
      if (!skipNaN)
        return static_cast<long long>(i);
      continue;
    }
    if (best < 0 || (largest ? l[i] > l[static_cast<size_t>(best)]
                             : l[i] < l[static_cast<size_t>(best)]))
      best = static_cast<long long>(i);
  }
  return best;
}

LineFn argFn(bool largest, bool skipNaN) {
  return [largest, skipNaN](std::vector<double> &l, std::vector<double> &out, CallContext &ctx) {
    const long long i = argExtreme(l, largest, skipNaN);
    if (i < 0) {
      ctx.fail(l.empty() ? "there are no elements to choose from"
                         : "every element is NaN - there is no smallest or largest one");
      return false;
    }
    out = {static_cast<double>(i)};
    return true;
  };
}

LineFn nanFn(double (*f)(const std::vector<double> &), double whenEmpty) {
  return [f, whenEmpty](std::vector<double> &l, std::vector<double> &out, CallContext &) {
    const std::vector<double> kept = withoutNaN(l);
    out = {kept.empty() ? whenEmpty : f(kept)};
    return true;
  };
}

double minOf(const std::vector<double> &l) { return *std::min_element(l.begin(), l.end()); }
double maxOf(const std::vector<double> &l) { return *std::max_element(l.begin(), l.end()); }
double medianOf(const std::vector<double> &l) { return quantileOf(l, 0.5); }

/* ---- average ---- */

Value average(const std::vector<Value> &args, CallContext &ctx) {
  Grid g, wg;
  std::vector<double> x, w;
  if (!realGrid(args[0], 0, ctx, g, x) || !realGrid(args[2], 2, ctx, wg, w))
    return Value(0.0);
  bool all = true;
  size_t axis = 0;
  if (!readAxis(args[1], g.shape.size(), ctx, all, axis))
    return Value(0.0);
  // Weights: one value for all, one per element, or one per position along axis.
  std::vector<double> full(x.size());
  if (w.size() == 1) {
    std::fill(full.begin(), full.end(), w[0]);
  } else if (w.size() == x.size()) {
    full = w;
  } else if (!all && w.size() == g.shape[axis]) {
    const ndx::AxisView v = ndx::viewOf(g.shape, axis);
    for (size_t o = 0; o < v.outer; o++)
      for (size_t k = 0; k < v.len; k++)
        for (size_t i = 0; i < v.inner; i++)
          full[(o * v.len + k) * v.inner + i] = w[k];
  } else {
    ctx.fail("weights must be one number, one per element (" + std::to_string(x.size()) +
             ")" + (all ? "" : ", or one per position along the axis (" +
                                   std::to_string(g.shape[axis]) + ")"));
    return Value(0.0);
  }
  std::vector<double> wx(x.size());
  for (size_t k = 0; k < x.size(); k++)
    wx[k] = x[k] * full[k];
  Value num, den;
  if (!reduceLines(g.shape, wx, all, axis, 1, false, simple(sumOf), ctx, num) ||
      !reduceLines(g.shape, full, all, axis, 1, false, simple(sumOf), ctx, den))
    return Value(0.0);
  if (all) {
    if (den.number == 0) {
      ctx.fail("the weights add up to 0");
      return Value(0.0);
    }
    return Value(num.number / den.number);
  }
  Grid n = ndx::gridOf(num), d = ndx::gridOf(den);
  for (size_t k = 0; k < n.count(); k++) {
    if (d.cells[k].number == 0) {
      ctx.fail("the weights of a line add up to 0");
      return Value(0.0);
    }
    n.cells[k] = Value(n.cells[k].number / d.cells[k].number);
  }
  return ndx::valueOf(n);
}

/* ---- all / any / count_nonzero (any element kind) ---- */

Impl truthImpl(int mode) { // 0 all, 1 any, 2 count
  return [mode](const std::vector<Value> &args, CallContext &ctx) -> Value {
    if (ndx::notMatrixData(args[0])) {
      ctx.fail("the first argument must be a matrix, a number or text");
      return Value(0.0);
    }
    const Grid g = ndx::gridOf(args[0]);
    std::vector<double> t;
    t.reserve(g.count());
    for (const Value &c : g.cells) {
      if (c.isTime()) {
        ctx.fail("it works on numbers, true/false and text");
        return Value(0.0);
      }
      const bool on = c.isText ? !c.text().empty() : (c.number != 0.0 || (c.isComplex && c.imag != 0.0));
      t.push_back(on ? 1.0 : 0.0);
    }
    bool all = true;
    size_t axis = 0;
    if (!readAxis(args[1], g.shape.size(), ctx, all, axis))
      return Value(0.0);
    LineFn fn = [mode](std::vector<double> &l, std::vector<double> &out, CallContext &) {
      double r = mode == 0 ? 1.0 : 0.0;
      for (double v : l)
        r = mode == 0 ? std::min(r, v) : mode == 1 ? std::max(r, v) : r + v;
      out = {r};
      return true;
    };
    Value out;
    if (!reduceLines(g.shape, t, all, axis, 1, false, fn, ctx, out))
      return Value(0.0);
    if (mode == 2)
      return out;
    if (all)
      return Value::boolean(out.number != 0.0);
    Grid r = ndx::gridOf(out);
    for (Value &c : r.cells)
      c = Value::boolean(c.number != 0.0);
    return ndx::valueOf(r);
  };
}

/* ---- cumulative ---- */

Impl cumulativeImpl(bool product, bool skipNaN, bool hasInitial) {
  return [product, skipNaN, hasInitial](const std::vector<Value> &args,
                                        CallContext &ctx) -> Value {
    Grid g;
    std::vector<double> x;
    if (!realGrid(args[0], 0, ctx, g, x))
      return Value(0.0);
    bool all = true;
    size_t axis = 0;
    if (!readAxis(args[1], g.shape.size(), ctx, all, axis))
      return Value(0.0);
    bool initial = false;
    if (hasInitial) {
      if (!args[2].isBool()) {
        ctx.fail("include_initial must be true or false");
        return Value(0.0);
      }
      initial = args[2].number != 0.0;
    }
    const double start = product ? 1.0 : 0.0;
    Value out = mapLines(g.shape, x, all, axis, [&](std::vector<double> &l) {
      double run = start;
      for (double &v : l) {
        const double add = (skipNaN && std::isnan(v)) ? start : v;
        run = product ? run * add : run + add;
        v = run;
      }
    });
    if (!initial)
      return out;
    // include_initial: a first slice of 0 (sum) or 1 (product) along the axis.
    Grid r = ndx::gridOf(out);
    const size_t ax = all ? 1 : axis;
    std::vector<std::vector<Value>> slices = ndx::slicesOf(r, ax);
    const size_t sliceSize = r.count() / std::max<size_t>(1, r.shape[ax]);
    slices.insert(slices.begin(), std::vector<Value>(all ? 1 : sliceSize, Value(start)));
    return ndx::valueOf(ndx::fromSlices(r.shape, ax, slices));
  };
}

/* ---- percentile / quantile ---- */

Impl quantileImpl(double scale) { // 100 for percentiles, 1 for quantiles
  return [scale](const std::vector<Value> &args, CallContext &ctx) -> Value {
    Grid g, qg;
    std::vector<double> x, q;
    if (!realGrid(args[0], 0, ctx, g, x) || !realGrid(args[1], 1, ctx, qg, q))
      return Value(0.0);
    if (q.empty()) {
      ctx.fail("q must not be empty");
      return Value(0.0);
    }
    for (double v : q)
      if (!(v >= 0 && v <= scale)) {
        ctx.fail(scale == 100 ? "q must be between 0 and 100" : "q must be between 0 and 1");
        return Value(0.0);
      }
    bool all = true;
    size_t axis = 0;
    if (!readAxis(args[2], g.shape.size(), ctx, all, axis))
      return Value(0.0);
    const bool several = args[1].isArray || args[1].isMatrix;
    LineFn fn = [&](std::vector<double> &l, std::vector<double> &out, CallContext &) {
      const std::vector<double> kept = withoutNaN(l);
      out.clear();
      for (double v : q)
        out.push_back(quantileOf(kept, v / scale));
      return true;
    };
    Value out;
    if (!reduceLines(g.shape, x, all, axis, q.size(), several, fn, ctx, out))
      return Value(0.0);
    return out;
  };
}

Impl varImpl(bool sd) {
  return [sd](const std::vector<Value> &args, CallContext &ctx) -> Value {
    double ddof = 0;
    if (!argNumber(args, 2, ctx, ddof))
      return Value(0.0);
    return reduceImpl([sd, ddof](std::vector<double> &l, std::vector<double> &out,
                                 CallContext &) {
      const double v = varOf(withoutNaN(l), ddof);
      out = {sd ? std::sqrt(v) : v};
      return true;
    })(args, ctx);
  };
}

} // namespace

void registerReductions(Registry &reg) {
  addFn(reg, "average", 1, 3, "weighted mean", "np.average", average);
  addFn(reg, "prod", 1, 2, "product of the elements", "np.prod", reduceImpl(simple(prodOf)));
  addFn(reg, "argmin", 1, 2, "position of the smallest element", "np.argmin",
        reduceImpl(argFn(false, false)));
  addFn(reg, "argmax", 1, 2, "position of the largest element", "np.argmax",
        reduceImpl(argFn(true, false)));
  addFn(reg, "count_nonzero", 1, 2, "how many elements are not 0", "np.count_nonzero",
        truthImpl(2), true);
  addFn(reg, "all", 1, 2, "whether every element is true", "np.all", truthImpl(0), true);
  addFn(reg, "any", 1, 2, "whether some element is true", "np.any", truthImpl(1), true);
  addFn(reg, "cumsum", 1, 2, "running sum", "np.cumsum", cumulativeImpl(false, false, false));
  addFn(reg, "cumprod", 1, 2, "running product", "np.cumprod",
        cumulativeImpl(true, false, false));
  addFn(reg, "cumulative_sum", 1, 3, "running sum, optionally from 0", "np.cumulative_sum",
        cumulativeImpl(false, false, true));
  addFn(reg, "cumulative_prod", 1, 3, "running product, optionally from 1", "np.cumulative_prod",
        cumulativeImpl(true, false, true));

  addFn(reg, "nan_mean", 1, 2, "mean leaving NaN out", "np.nanmean",
        reduceImpl(nanFn(meanOf, kNaN)));
  addFn(reg, "nan_median", 1, 2, "median leaving NaN out", "np.nanmedian",
        reduceImpl(nanFn(medianOf, kNaN)));
  addFn(reg, "nan_sum", 1, 2, "sum leaving NaN out", "np.nansum", reduceImpl(nanFn(sumOf, 0.0)));
  addFn(reg, "nan_prod", 1, 2, "product leaving NaN out", "np.nanprod",
        reduceImpl(nanFn(prodOf, 1.0)));
  addFn(reg, "nan_min", 1, 2, "smallest leaving NaN out", "np.nanmin",
        reduceImpl(nanFn(minOf, kNaN)));
  addFn(reg, "nan_max", 1, 2, "largest leaving NaN out", "np.nanmax",
        reduceImpl(nanFn(maxOf, kNaN)));
  addFn(reg, "nan_argmin", 1, 2, "position of the smallest, NaN left out", "np.nanargmin",
        reduceImpl(argFn(false, true)));
  addFn(reg, "nan_argmax", 1, 2, "position of the largest, NaN left out", "np.nanargmax",
        reduceImpl(argFn(true, true)));
  addFn(reg, "nan_var", 1, 3, "variance leaving NaN out (population)", "np.nanvar",
        varImpl(false));
  addFn(reg, "nan_sd", 1, 3, "standard deviation leaving NaN out (population)", "np.nanstd",
        varImpl(true));
  addFn(reg, "nan_percentile", 2, 3, "percentiles leaving NaN out", "np.nanpercentile",
        quantileImpl(100));
  addFn(reg, "nan_quantile", 2, 3, "quantiles leaving NaN out", "np.nanquantile",
        quantileImpl(1));
  addFn(reg, "nan_cumsum", 1, 2, "running sum, NaN counted as 0", "np.nancumsum",
        cumulativeImpl(false, true, false));
  addFn(reg, "nan_cumprod", 1, 2, "running product, NaN counted as 1", "np.nancumprod",
        cumulativeImpl(true, true, false));

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"average", "A, axis=\"all\", weights=1"},
      {"prod", "A, axis=\"all\""},
      {"argmin", "A, axis=\"all\""},
      {"argmax", "A, axis=\"all\""},
      {"count_nonzero", "A, axis=\"all\""},
      {"all", "A, axis=\"all\""},
      {"any", "A, axis=\"all\""},
      {"cumsum", "A, axis=\"all\""},
      {"cumprod", "A, axis=\"all\""},
      {"cumulative_sum", "A, axis=\"all\", include_initial=false"},
      {"cumulative_prod", "A, axis=\"all\", include_initial=false"},
      {"nan_mean", "A, axis=\"all\""},
      {"nan_median", "A, axis=\"all\""},
      {"nan_sum", "A, axis=\"all\""},
      {"nan_prod", "A, axis=\"all\""},
      {"nan_min", "A, axis=\"all\""},
      {"nan_max", "A, axis=\"all\""},
      {"nan_argmin", "A, axis=\"all\""},
      {"nan_argmax", "A, axis=\"all\""},
      {"nan_var", "A, axis=\"all\", ddof=0"},
      {"nan_sd", "A, axis=\"all\", ddof=0"},
      {"nan_percentile", "A, q, axis=\"all\""},
      {"nan_quantile", "A, q, axis=\"all\""},
      {"nan_cumsum", "A, axis=\"all\""},
      {"nan_cumprod", "A, axis=\"all\""},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace st
} // namespace numpy
} // namespace nc
