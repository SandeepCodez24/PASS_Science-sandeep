// Adding & Removing Elements - only adding_removing_elements_main.cpp
// includes this header.
#ifndef NC_NUMPY_AR_FUNCTIONS_H
#define NC_NUMPY_AR_FUNCTIONS_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// insert, repeat, pad, trim_zeros, unique, put, replace_if, fill_diagonal,
// nan_to_num (with their parameter lines).
void registerAddRemoveFunctions(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_AR_FUNCTIONS_H
