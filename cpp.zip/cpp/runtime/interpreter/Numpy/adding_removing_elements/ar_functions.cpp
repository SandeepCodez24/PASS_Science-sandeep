// Adding & Removing Elements.
//
//   insert(A, index, values[, axis])    np.insert     values put in BEFORE index
//   repeat(A, repeats[, axis])          np.repeat     each element / slice repeated
//   pad(A, width, mode="constant", value=0)   np.pad  a border around A
//   trim_zeros(v, trim="fb")            np.trim_zeros zeros off the front / back of a vector
//   unique(A[, axis])                   np.unique     sorted distinct elements / rows / columns
//   put(A, indices, values)             np.put        a copy with flat positions replaced
//   replace_if(A, mask, value)          np.putmask    a copy with A where mask is true replaced
//   fill_diagonal(A, value, wrap=false) np.fill_diagonal  a copy with the diagonal set
//   nan_to_num(A, nan=0, posinf?, neginf?)  np.nan_to_num NaN / +-Inf replaced by numbers
//
// Every function returns a NEW value (A itself never changes). Without an
// axis, insert / repeat / unique work on the elements of A taken row by row
// (NumPy's flat order) and give a 1xN row; with an axis they work on whole
// slices (rows for axis=0, columns for axis=1, pages of an N-D matrix ...)
// and keep the other sizes. Flat positions (put) count row by row from 0,
// and a negative one counts from the end. Element types follow the matrix
// rules (an int matrix that receives 2.5 becomes float64, as [A, 2.5] would).
#include "ar_functions.h"

#include <algorithm>
#include <cctype>
#include <cfloat>
#include <cmath>
#include <string>
#include <vector>

#include "../numpy_nd.h"

namespace nc {
namespace numpy {

namespace {

using ndx::Grid;

// A whole number as a size_t-capable long long.
bool wholeNumber(const Value &v, long long &out) {
  if (!isPlainNumber(v) || v.isComplex || !std::isfinite(v.number) ||
      v.number != std::floor(v.number))
    return false;
  out = static_cast<long long>(v.number);
  return true;
}

// Whole numbers from a value (a single one or a vector / matrix of them).
bool wholeNumbers(const Value &v, std::vector<long long> &out) {
  if (ndx::notMatrixData(v) || v.isText)
    return false;
  out.clear();
  for (const Value &c : nd::rowMajorCells(v)) {
    long long n = 0;
    if (!wholeNumber(c, n))
      return false;
    out.push_back(n);
  }
  return true;
}

/* ---- insert ---- */

Value insertFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a, vals;
  if (!ndx::argGrid(args, 0, ctx, a) || !ndx::argGrid(args, 2, ctx, vals))
    return Value(0.0);
  std::vector<long long> idx;
  if (!wholeNumbers(args[1], idx) || idx.empty()) {
    ctx.fail("index must be a whole number (0-based) or a vector of them");
    return Value(0.0);
  }

  if (args.size() < 4) { // flat: A row by row, the result is a row
    const long long n = static_cast<long long>(a.count());
    for (long long &i : idx) {
      if (i < -n || i > n) {
        ctx.fail("index " + std::to_string(i) + " is outside 0.." + std::to_string(n) +
                 " (A has " + std::to_string(n) + " elements)");
        return Value(0.0);
      }
      if (i < 0)
        i += n;
    }
    // One index: every value goes in there. Several: one value each (or the
    // single value at every index).
    std::vector<std::pair<long long, Value>> adds;
    if (idx.size() == 1) {
      for (const Value &v : vals.cells)
        adds.push_back({idx[0], v});
    } else if (vals.count() == 1 || vals.count() == idx.size()) {
      for (size_t k = 0; k < idx.size(); k++)
        adds.push_back({idx[k], vals.cells[vals.count() == 1 ? 0 : k]});
    } else {
      ctx.fail("with " + std::to_string(idx.size()) + " indices give 1 value or " +
               std::to_string(idx.size()) + " values (got " + std::to_string(vals.count()) + ")");
      return Value(0.0);
    }
    std::stable_sort(adds.begin(), adds.end(),
                     [](const auto &x, const auto &y) { return x.first < y.first; });
    std::vector<Value> out;
    size_t next = 0;
    for (long long p = 0; p <= n; p++) {
      while (next < adds.size() && adds[next].first == p)
        out.push_back(adds[next++].second);
      if (p < n)
        out.push_back(a.cells[static_cast<size_t>(p)]);
    }
    if (!ndx::unifyCells(out, ctx))
      return Value(0.0);
    return ndx::rowOf(out);
  }

  // Along an axis: whole slices go in before slice `index`.
  size_t axis = 0;
  if (!ndx::resolveAxis(args[3], a.shape.size(), ctx, axis))
    return Value(0.0);
  if (a.count() == 0) {
    ctx.fail("cannot insert along an axis of an empty matrix - build it with ,= or ;= instead");
    return Value(0.0);
  }
  if (idx.size() != 1) {
    ctx.fail("with an axis, index must be one whole number");
    return Value(0.0);
  }
  const long long len = static_cast<long long>(a.shape[axis]);
  long long i = idx[0];
  if (i < -len || i > len) {
    ctx.fail("index " + std::to_string(i) + " is outside 0.." + std::to_string(len) +
             " along axis " + std::to_string(axis));
    return Value(0.0);
  }
  if (i < 0)
    i += len;
  nd::Shape sliceShape = a.shape;
  sliceShape[axis] = 1;
  const size_t sliceCount = nd::countOf(sliceShape);
  std::vector<std::vector<Value>> added;
  if (vals.count() == 1) {
    added.push_back(std::vector<Value>(sliceCount, vals.cells[0]));
  } else if (vals.count() == sliceCount) {
    added.push_back(vals.cells); // one slice, its elements row by row
  } else {
    // A block of k slices: every size but the axis must match A's.
    nd::Shape vs = nd::withRank(vals.shape, a.shape.size());
    bool fits = vs.size() == a.shape.size();
    for (size_t d = 0; fits && d < vs.size(); d++)
      fits = d == axis || vs[d] == a.shape[d];
    if (!fits) {
      ctx.fail("values must be a single value, one slice of " + std::to_string(sliceCount) +
               " values, or a block whose other sizes match A (A is " +
               nd::shapeText(a.shape) + ", values are " + nd::shapeText(vals.shape) +
               ", along axis " + std::to_string(axis) + ")");
      return Value(0.0);
    }
    Grid vg{vs, vals.cells};
    added = ndx::slicesOf(vg, axis);
  }
  std::vector<std::vector<Value>> slices = ndx::slicesOf(a, axis);
  slices.insert(slices.begin() + i, added.begin(), added.end());
  Grid out = ndx::fromSlices(a.shape, axis, slices);
  if (!ndx::unifyCells(out.cells, ctx))
    return Value(0.0);
  return ndx::valueOf(out);
}

/* ---- repeat ---- */

Value repeatFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  std::vector<long long> reps;
  if (!wholeNumbers(args[1], reps) || reps.empty()) {
    ctx.fail("repeats must be a whole number >= 0, or one per element / slice");
    return Value(0.0);
  }
  for (long long r : reps)
    if (r < 0) {
      ctx.fail("repeats must not be negative");
      return Value(0.0);
    }
  auto repsFor = [&](size_t n, const std::string &what, std::vector<long long> &out) {
    if (reps.size() == 1) {
      out.assign(n, reps[0]);
      return true;
    }
    if (reps.size() != n) {
      ctx.fail("give one repeat count, or one per " + what + " (" + std::to_string(n) +
               "), not " + std::to_string(reps.size()));
      return false;
    }
    out = reps;
    return true;
  };

  std::vector<long long> per;
  if (args.size() < 3) {
    if (!repsFor(a.count(), "element", per))
      return Value(0.0);
    std::vector<Value> out;
    for (size_t k = 0; k < a.count(); k++)
      for (long long r = 0; r < per[k]; r++)
        out.push_back(a.cells[k]);
    return ndx::rowOf(out);
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[2], a.shape.size(), ctx, axis))
    return Value(0.0);
  if (!repsFor(a.shape[axis], "slice along axis " + std::to_string(axis), per))
    return Value(0.0);
  std::vector<std::vector<Value>> slices = ndx::slicesOf(a, axis), out;
  for (size_t k = 0; k < slices.size(); k++)
    for (long long r = 0; r < per[k]; r++)
      out.push_back(slices[k]);
  return ndx::valueOf(ndx::fromSlices(a.shape, axis, out));
}

/* ---- pad ---- */

Value padFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  const size_t rank = a.shape.size();
  std::vector<long long> w;
  if (!wholeNumbers(args[1], w) || w.empty()) {
    ctx.fail("width must be whole numbers >= 0: n, [before, after], or one [before, after] row "
             "per axis, e.g. [0, 0; 2, 2] for a matrix");
    return Value(0.0);
  }
  for (long long x : w)
    if (x < 0) {
      ctx.fail("width must not be negative");
      return Value(0.0);
    }
  std::vector<long long> before(rank), after(rank);
  if (w.size() == 1 || w.size() == 2) {
    std::fill(before.begin(), before.end(), w[0]);
    std::fill(after.begin(), after.end(), w.size() == 2 ? w[1] : w[0]);
  } else if (w.size() == 2 * rank) {
    for (size_t d = 0; d < rank; d++) {
      before[d] = w[2 * d];
      after[d] = w[2 * d + 1];
    }
  } else {
    ctx.fail("width must be n, [before, after], or " + std::to_string(rank) +
             " rows of [before, after] (one per axis) - got " + std::to_string(w.size()) +
             " numbers");
    return Value(0.0);
  }
  std::string mode;
  if (!argText(args, 2, ctx, mode))
    return Value(0.0);
  for (char &c : mode)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (mode != "constant" && mode != "edge" && mode != "reflect" && mode != "symmetric" &&
      mode != "wrap") {
    ctx.fail("mode must be \"constant\", \"edge\", \"reflect\", \"symmetric\" or \"wrap\"");
    return Value(0.0);
  }
  const Value &fill = args[3];
  if (fill.isArray || fill.isMatrix || ndx::notMatrixData(fill)) {
    ctx.fail("value must be a single number (or text for a text matrix)");
    return Value(0.0);
  }
  if (mode != "constant")
    for (size_t d = 0; d < rank; d++)
      if (a.shape[d] == 0) {
        ctx.fail("mode \"" + mode + "\" needs a non-empty matrix");
        return Value(0.0);
      }

  nd::Shape outShape(rank);
  for (size_t d = 0; d < rank; d++)
    outShape[d] = a.shape[d] + static_cast<size_t>(before[d] + after[d]);
  std::vector<Value> cells;
  cells.reserve(nd::countOf(outShape));
  if (nd::countOf(outShape) > 0) {
    std::vector<size_t> idx(rank, 0), src(rank, 0);
    do {
      bool outside = false;
      for (size_t d = 0; d < rank; d++) {
        const long long len = static_cast<long long>(a.shape[d]);
        long long c = static_cast<long long>(idx[d]) - before[d];
        if (c < 0 || c >= len) {
          outside = true;
          if (mode == "edge") {
            c = c < 0 ? 0 : len - 1;
          } else if (mode == "wrap") {
            c = ((c % len) + len) % len;
          } else if (mode == "reflect") { // mirror without repeating the edge
            const long long p = 2 * (len - 1);
            if (p == 0) {
              c = 0;
            } else {
              c = ((c % p) + p) % p;
              if (c >= len)
                c = p - c;
            }
          } else if (mode == "symmetric") { // mirror repeating the edge
            const long long p = 2 * len;
            c = ((c % p) + p) % p;
            if (c >= len)
              c = p - 1 - c;
          }
        }
        src[d] = static_cast<size_t>(c < 0 ? 0 : c);
      }
      if (outside && mode == "constant") {
        cells.push_back(fill);
      } else {
        size_t flat = 0;
        for (size_t d = 0; d < rank; d++)
          flat = flat * a.shape[d] + src[d];
        cells.push_back(a.cells[flat]);
      }
    } while (nd::nextIndex(idx, outShape));
  }
  if (!ndx::unifyCells(cells, ctx))
    return Value(0.0);
  return ndx::valueOf(Grid{outShape, cells});
}

/* ---- trim_zeros ---- */

bool isZeroCell(const Value &c) {
  return isPlainNumber(c) && c.number == 0.0 && (!c.isComplex || c.imag == 0.0);
}

Value trimZerosFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  if (a.shape.size() != 2 || (a.shape[0] > 1 && a.shape[1] > 1)) {
    ctx.fail("it works on a vector (one row or one column), not a " +
             nd::shapeText(a.shape) + " matrix");
    return Value(0.0);
  }
  std::string trim;
  if (!argText(args, 1, ctx, trim))
    return Value(0.0);
  for (char &c : trim)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  if (trim.empty() || trim.find_first_not_of("fb") != std::string::npos) {
    ctx.fail("trim must be \"f\" (front), \"b\" (back) or \"fb\" (both)");
    return Value(0.0);
  }
  for (const Value &c : a.cells)
    if (!isPlainNumber(c)) {
      ctx.fail("it works on numbers, not text");
      return Value(0.0);
    }
  size_t first = 0, last = a.count();
  if (trim.find('f') != std::string::npos)
    while (first < last && isZeroCell(a.cells[first]))
      first++;
  if (trim.find('b') != std::string::npos)
    while (last > first && isZeroCell(a.cells[last - 1]))
      last--;
  std::vector<Value> kept(a.cells.begin() + first, a.cells.begin() + last);
  const bool column = a.shape[0] > 1;
  return ndx::valueOf(Grid{column ? nd::Shape{kept.size(), 1} : nd::Shape{1, kept.size()}, kept});
}

/* ---- unique ---- */

Value uniqueFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  if (args.size() < 2) {
    std::vector<Value> cells = a.cells;
    std::stable_sort(cells.begin(), cells.end(),
                     [](const Value &x, const Value &y) { return ndx::compareCells(x, y) < 0; });
    std::vector<Value> out;
    for (const Value &c : cells)
      if (out.empty() || ndx::compareCells(out.back(), c) != 0)
        out.push_back(c);
    return ndx::rowOf(out);
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[1], a.shape.size(), ctx, axis))
    return Value(0.0);
  std::vector<std::vector<Value>> slices = ndx::slicesOf(a, axis), out;
  std::stable_sort(slices.begin(), slices.end(), [](const auto &x, const auto &y) {
    return ndx::compareSlices(x, y) < 0;
  });
  for (const auto &s : slices)
    if (out.empty() || ndx::compareSlices(out.back(), s) != 0)
      out.push_back(s);
  return ndx::valueOf(ndx::fromSlices(a.shape, axis, out));
}

/* ---- put / replace_if / fill_diagonal ---- */

Value putFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a, vals;
  if (!ndx::argGrid(args, 0, ctx, a) || !ndx::argGrid(args, 2, ctx, vals))
    return Value(0.0);
  std::vector<long long> idx;
  if (!wholeNumbers(args[1], idx)) {
    ctx.fail("indices must be whole numbers (flat positions, row by row from 0)");
    return Value(0.0);
  }
  if (vals.count() == 0) {
    ctx.fail("values must not be empty");
    return Value(0.0);
  }
  const long long n = static_cast<long long>(a.count());
  for (size_t k = 0; k < idx.size(); k++) {
    long long i = idx[k];
    if (i < -n || i >= n) {
      ctx.fail("position " + std::to_string(i) + " is outside A (it has " + std::to_string(n) +
               " elements: 0.." + std::to_string(n - 1) + ")");
      return Value(0.0);
    }
    if (i < 0)
      i += n;
    a.cells[static_cast<size_t>(i)] = vals.cells[k % vals.count()]; // values repeat
  }
  if (!ndx::unifyCells(a.cells, ctx))
    return Value(0.0);
  return ndx::valueOf(a);
}

Value replaceIfFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a, mask, vals;
  if (!ndx::argGrid(args, 0, ctx, a) || !ndx::argGrid(args, 1, ctx, mask) ||
      !ndx::argGrid(args, 2, ctx, vals))
    return Value(0.0);
  if (mask.shape != a.shape) {
    ctx.fail("mask must have the same size as A (A is " + nd::shapeText(a.shape) +
             ", mask is " + nd::shapeText(mask.shape) + ")");
    return Value(0.0);
  }
  if (vals.count() != 1 && vals.shape != a.shape) {
    ctx.fail("value must be a single value or have the same size as A (A is " +
             nd::shapeText(a.shape) + ", value is " + nd::shapeText(vals.shape) + ")");
    return Value(0.0);
  }
  for (size_t k = 0; k < a.count(); k++) {
    const Value &m = mask.cells[k];
    if (!isPlainNumber(m) || m.isTime()) {
      ctx.fail("mask must hold true/false (or numbers, 0 = false)");
      return Value(0.0);
    }
    if (m.number != 0.0 || (m.isComplex && m.imag != 0.0))
      a.cells[k] = vals.cells[vals.count() == 1 ? 0 : k];
  }
  if (!ndx::unifyCells(a.cells, ctx))
    return Value(0.0);
  return ndx::valueOf(a);
}

Value fillDiagonalFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a, vals;
  if (!ndx::argGrid(args, 0, ctx, a) || !ndx::argGrid(args, 1, ctx, vals))
    return Value(0.0);
  if (!args[2].isBool()) {
    ctx.fail("wrap must be true or false");
    return Value(0.0);
  }
  if (vals.count() == 0) {
    ctx.fail("value must not be empty");
    return Value(0.0);
  }
  const size_t rank = a.shape.size();
  size_t step = 0, end = a.count();
  if (rank == 2) {
    step = a.shape[1] + 1;
    // Without wrap a tall matrix stops after its square top part (NumPy).
    if (args[2].number == 0.0)
      end = std::min(end, a.shape[1] * a.shape[1]);
  } else {
    for (size_t d = 1; d < rank; d++)
      if (a.shape[d] != a.shape[0]) {
        ctx.fail("an N-D matrix needs all sizes equal for a diagonal (got " +
                 nd::shapeText(a.shape) + ")");
        return Value(0.0);
      }
    size_t p = 1;
    step = 1;
    for (size_t d = 1; d < rank; d++) {
      p *= a.shape[0];
      step += p;
    }
  }
  size_t k = 0;
  for (size_t pos = 0; pos < end && step > 0; pos += step)
    a.cells[pos] = vals.cells[k++ % vals.count()];
  if (!ndx::unifyCells(a.cells, ctx))
    return Value(0.0);
  return ndx::valueOf(a);
}

/* ---- nan_to_num ---- */

Value nanToNumFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  double nanV = 0.0, posV = DBL_MAX, negV = -DBL_MAX;
  if (!argNumber(args, 1, ctx, nanV))
    return Value(0.0);
  if (args.size() > 2 && !argNumber(args, 2, ctx, posV))
    return Value(0.0);
  if (args.size() > 3 && !argNumber(args, 3, ctx, negV))
    return Value(0.0);
  auto fix = [&](double x) {
    if (std::isnan(x))
      return nanV;
    if (std::isinf(x))
      return x > 0 ? posV : negV;
    return x;
  };
  for (Value &c : a.cells) {
    if (!isPlainNumber(c) || c.isTime()) {
      ctx.fail("it works on numbers, not text or time values");
      return Value(0.0);
    }
    if (c.isBool() || c.isInt())
      continue; // never NaN or Inf
    if (c.isComplex) {
      c = Value::complexNumber(fix(c.number), fix(c.imag));
    } else if (std::isnan(c.number) || std::isinf(c.number)) {
      Value r(fix(c.number));
      r.dimL = c.dimL;
      r.dimT = c.dimT;
      r.dimM = c.dimM;
      c = r;
    }
  }
  if (!ndx::unifyCells(a.cells, ctx))
    return Value(0.0);
  return ndx::valueOf(a);
}

void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
         const char *numpyName, Impl impl, bool acceptsComplex = true) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::AddingRemovingElements;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = acceptsComplex;
  reg.add(std::move(spec));
}

} // namespace

void registerAddRemoveFunctions(Registry &reg) {
  add(reg, "insert", 3, 4, "values put in before an index", "np.insert", insertFn);
  add(reg, "repeat", 2, 3, "each element or slice repeated", "np.repeat", repeatFn);
  add(reg, "pad", 2, 4, "a border around a matrix", "np.pad", padFn);
  add(reg, "trim_zeros", 1, 2, "zeros off the front / back of a vector", "np.trim_zeros",
      trimZerosFn);
  add(reg, "unique", 1, 2, "sorted distinct elements, rows or columns", "np.unique", uniqueFn);
  add(reg, "put", 3, 3, "a copy with flat positions replaced", "np.put", putFn);
  add(reg, "replace_if", 3, 3, "a copy with the masked elements replaced", "np.putmask",
      replaceIfFn);
  add(reg, "fill_diagonal", 2, 3, "a copy with the diagonal set", "np.fill_diagonal",
      fillDiagonalFn);
  add(reg, "nan_to_num", 1, 4, "NaN and infinities replaced by numbers", "np.nan_to_num",
      nanToNumFn);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"insert", "A, index, values, axis?"},
      {"repeat", "A, repeats, axis?"},
      {"pad", "A, width, mode=\"constant\", value=0"},
      {"trim_zeros", "v, trim=\"fb\""},
      {"unique", "A, axis?"},
      {"put", "A, indices, values"},
      {"replace_if", "A, mask, value"},
      {"fill_diagonal", "A, value, wrap=false"},
      {"nan_to_num", "A, nan=0, posinf?, neginf?"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
