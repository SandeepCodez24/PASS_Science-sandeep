// Section 5 of 11 - Adding & Removing Elements (20 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_ADDING_REMOVING_ELEMENTS_MAIN_H
#define NC_NUMPY_ADDING_REMOVING_ELEMENTS_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Adding & Removing Elements function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerAddingRemovingElements(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_ADDING_REMOVING_ELEMENTS_MAIN_H
