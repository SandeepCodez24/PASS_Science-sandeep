// Creating Arrays - only creating_arrays_main.cpp includes this header.
#ifndef NC_NUMPY_CR_FUNCTIONS_H
#define NC_NUMPY_CR_FUNCTIONS_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// check_finite, zeros_like, ones_like, vander, meshgrid, indices, the random
// functions (rand_choice, shuffle, permutation, rand_binomial ...
// rand_mvnormal), with their parameter lines.
void registerCreatingFunctions(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_CR_FUNCTIONS_H
