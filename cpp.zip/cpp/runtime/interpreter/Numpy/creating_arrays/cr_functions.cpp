// Creating Arrays.
//
//   check_finite(A)               A itself, or an error if it holds NaN / Inf
//                                                              np.asarray_chkfinite
//   zeros_like(A) / ones_like(A)  same shape and element type, all 0 / all 1
//   vander(x, N=0, increasing=false)  Vandermonde matrix: columns x^(N-1) ... x^0
//                                 (N=0: one column per element of x)
//   [X, Y] = meshgrid(x, y, indexing="xy")   coordinate grids    np.meshgrid
//   [R, C] = indices([r, c])      row / column index grids      np.indices
//
// Random (one engine for all, the one nexus() uses: nexus_seed(n) makes every
// random result below repeatable):
//   rand_choice(a, size=1, replace=true, p?)   elements of a (or of 0..a-1)
//   shuffle(A[, axis])            a shuffled copy (a vector along its length,
//                                 a matrix by rows)
//   permutation(x)                0..x-1 in random order, or a shuffled copy of x
//   rand_binomial(n, p, size=1)          rand_poisson(lam, size=1)
//   rand_exponential(scale=1, size=1)    rand_beta(a, b, size=1)
//   rand_gamma(shape, scale=1, size=1)   rand_lognormal(mean=0, sigma=1, size=1)
//   rand_chisquare(df, size=1)           rand_triangular(left, mode, right, size=1)
//   rand_geometric(p, size=1)            (trials until the first success: 1, 2, ...)
//   rand_multinomial(n, pvals, size=1)   one row of counts per draw
//   rand_mvnormal(mean, cov, size=1)     one row (a point) per draw
//
// size: 1 gives a single value (the default), n a 1xn row, [r, c] an r x c
// matrix, [d0, r, c] an N-D matrix. Results are float64 numbers (counts too:
// float64 is NC's number).
#include "cr_functions.h"

#include <algorithm>
#include <cmath>
#include <numeric>
#include <random>
#include <string>
#include <vector>

#include "../numpy_nd.h"
#include "../../core/output.h"
#include "../../ops/matrix/matrix.h"

namespace nc {
namespace numpy {

namespace {

using ndx::Grid;

std::mt19937_64 &rng() { return ncRandomEngine(); }

/* ---- size ---- */

struct SizeSpec {
  bool single = true;
  nd::Shape shape{1, 1};
  size_t count() const { return single ? 1 : nd::countOf(shape); }
};

bool readSize(const Value &v, SizeSpec &out, CallContext &ctx) {
  std::vector<double> dims;
  if (!flattenNumbers(v, dims) || dims.empty()) {
    ctx.fail("size must be a whole number or a list of sizes, e.g. size=5 or size=[2, 3]");
    return false;
  }
  for (double d : dims)
    if (!std::isfinite(d) || d != std::floor(d) || d < 0 || d > 1e8) {
      ctx.fail("size must hold whole numbers >= 0, e.g. size=[2, 3]");
      return false;
    }
  out = SizeSpec{};
  if (dims.size() == 1) {
    if (dims[0] == 1)
      return true; // one value
    out.single = false;
    out.shape = {1, static_cast<size_t>(dims[0])};
    return true;
  }
  out.single = false;
  out.shape.clear();
  for (double d : dims)
    out.shape.push_back(static_cast<size_t>(d));
  if (nd::countOf(out.shape) > 100000000) {
    ctx.fail("size asks for more than 100,000,000 values");
    return false;
  }
  return true;
}

// `size` values from `draw`, shaped as the size says.
template <typename Draw> Value drawMany(const SizeSpec &size, Draw draw) {
  if (size.single)
    return Value(draw());
  std::vector<Value> cells;
  cells.reserve(size.count());
  for (size_t k = 0; k < size.count(); k++)
    cells.push_back(Value(draw()));
  return ndx::valueOf(Grid{size.shape, cells});
}

bool positive(double x, const char *name, CallContext &ctx) {
  if (!(x > 0) || !std::isfinite(x)) {
    ctx.fail(std::string(name) + " must be a positive number");
    return false;
  }
  return true;
}

bool probability(double p, const char *name, CallContext &ctx) {
  if (!(p >= 0 && p <= 1)) {
    ctx.fail(std::string(name) + " must be a probability between 0 and 1");
    return false;
  }
  return true;
}

/* ---- check_finite / zeros_like / ones_like ---- */

Value checkFinite(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  for (size_t k = 0; k < a.count(); k++) {
    const Value &c = a.cells[k];
    if (!isPlainNumber(c) || c.isTime()) {
      ctx.fail("it works on numbers");
      return Value(0.0);
    }
    const bool bad = !std::isfinite(c.number) || (c.isComplex && !std::isfinite(c.imag));
    if (bad) {
      ctx.fail("the element at flat position " + std::to_string(k) + " is " +
               (std::isnan(c.number) || (c.isComplex && std::isnan(c.imag)) ? "NaN" : "infinite") +
               " - only finite numbers are allowed");
      return Value(0.0);
    }
  }
  return args[0];
}

// `x` in the element type of `like` (int stays int, bool stays bool ...).
Value sameTypeNumber(const Value &like, double x) {
  if (like.isBool())
    return Value::boolean(x != 0.0);
  if (like.isInt())
    return like.intIsUnsigned()
               ? Value::integerUnsigned(like.intType(), static_cast<uint64_t>(x))
               : Value::integerSigned(like.intType(), static_cast<int64_t>(x));
  if (like.isComplex)
    return Value::complexNumber(x, 0.0);
  if (like.floatType() != FloatType::Float64)
    return Value::floating(like.floatType(), x);
  Value v(x);
  v.dimL = like.dimL;
  v.dimT = like.dimT;
  v.dimM = like.dimM;
  return v;
}

Impl filledLike(double x) {
  return [x](const std::vector<Value> &args, CallContext &ctx) -> Value {
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    for (Value &c : a.cells) {
      if (!isPlainNumber(c) || c.isTime()) {
        ctx.fail("it works on numbers");
        return Value(0.0);
      }
      c = sameTypeNumber(c, x);
    }
    if (!a.shape.empty() && nd::countOf(a.shape) == 1 && !args[0].isMatrix && !args[0].isArray)
      return a.cells[0]; // a single value stays a single value
    return ndx::valueOf(a);
  };
}

/* ---- vander / meshgrid / indices ---- */

Value vander(const std::vector<Value> &args, CallContext &ctx) {
  std::vector<double> x;
  if (!argNumbers(args, 0, ctx, x))
    return Value(0.0);
  long long n = 0;
  if (!argNonNegativeInt(args, 1, ctx, n))
    return Value(0.0);
  if (n == 0) // N=0 (the default): one column per element of x
    n = static_cast<long long>(x.size());
  if (args.size() < 3 || !args[2].isBool()) {
    ctx.fail("increasing must be true or false");
    return Value(0.0);
  }
  const bool increasing = args[2].number != 0.0;
  std::vector<std::vector<double>> rows(x.size(), std::vector<double>(static_cast<size_t>(n)));
  for (size_t i = 0; i < x.size(); i++)
    for (long long j = 0; j < n; j++) {
      const long long power = increasing ? j : n - 1 - j;
      rows[i][static_cast<size_t>(j)] = std::pow(x[i], static_cast<double>(power));
    }
  if (x.empty() || n == 0)
    return Value(std::vector<std::vector<Value>>{});
  return makeMatrix(rows);
}

// The grids of meshgrid as a list (one name) or one per name.
bool meshgridGrids(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  Grid gx, gy;
  if (!ndx::argGrid(args, 0, ctx, gx) || !ndx::argGrid(args, 1, ctx, gy))
    return false;
  std::string indexing;
  if (!argText(args, 2, ctx, indexing))
    return false;
  if (indexing != "xy" && indexing != "ij") {
    ctx.fail("indexing must be \"xy\" (x along the columns, the default) or \"ij\" (x along the "
             "rows)");
    return false;
  }
  const std::vector<Value> &x = gx.cells, &y = gy.cells;
  const bool xy = indexing == "xy";
  const size_t R = xy ? y.size() : x.size(), C = xy ? x.size() : y.size();
  std::vector<Value> X, Y;
  X.reserve(R * C);
  Y.reserve(R * C);
  for (size_t i = 0; i < R; i++)
    for (size_t j = 0; j < C; j++) {
      X.push_back(xy ? x[j] : x[i]);
      Y.push_back(xy ? y[i] : y[j]);
    }
  out = {ndx::valueOf(Grid{{R, C}, X}), ndx::valueOf(Grid{{R, C}, Y})};
  return true;
}

bool indexGrids(const std::vector<Value> &args, std::vector<Value> &out, CallContext &ctx) {
  std::vector<double> dims;
  if (!argNumbers(args, 0, ctx, dims) || dims.empty()) {
    ctx.fail("give the sizes as a list, e.g. indices([2, 3])");
    return false;
  }
  nd::Shape shape;
  for (double d : dims) {
    if (!std::isfinite(d) || d != std::floor(d) || d < 0) {
      ctx.fail("the sizes must be whole numbers >= 0");
      return false;
    }
    shape.push_back(static_cast<size_t>(d));
  }
  const nd::Shape built = shape.size() == 1 ? nd::Shape{1, shape[0]} : shape;
  out.clear();
  for (size_t axis = 0; axis < shape.size(); axis++) {
    std::vector<Value> cells;
    std::vector<size_t> idx(shape.size(), 0);
    if (nd::countOf(shape) > 0)
      do {
        cells.push_back(Value(static_cast<double>(idx[axis])));
      } while (nd::nextIndex(idx, shape));
    out.push_back(ndx::valueOf(Grid{built, cells}));
  }
  return true;
}

// A function giving several grids: one name gets them all as a list.
Impl listOf(bool (*fn)(const std::vector<Value> &, std::vector<Value> &, CallContext &)) {
  return [fn](const std::vector<Value> &args, CallContext &ctx) -> Value {
    std::vector<Value> out;
    if (!fn(args, out, ctx))
      return Value(0.0);
    return out.size() == 1 ? out[0] : Value(std::move(out));
  };
}

MultiImpl multiOf(bool (*fn)(const std::vector<Value> &, std::vector<Value> &, CallContext &)) {
  return [fn](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
    std::vector<Value> grids;
    if (!fn(args, grids, ctx))
      return;
    if (nout == 1) {
      out = {grids.size() == 1 ? grids[0] : Value(std::move(grids))};
      return;
    }
    if (nout != grids.size()) {
      ctx.fail("it gives " + std::to_string(grids.size()) + " grids, but " + std::to_string(nout) +
               " names were given");
      return;
    }
    out = std::move(grids);
  };
}

/* ---- choosing and shuffling ---- */

Value randChoice(const std::vector<Value> &args, CallContext &ctx) {
  // The pool: 0..a-1 for a whole number a, else the elements of a.
  std::vector<Value> pool;
  if (isPlainNumber(args[0]) && !args[0].isComplex) {
    long long n = 0;
    if (!argNonNegativeInt(args, 0, ctx, n))
      return Value(0.0);
    for (long long k = 0; k < n; k++)
      pool.push_back(Value(static_cast<double>(k)));
  } else {
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    pool = a.cells;
  }
  if (pool.empty()) {
    ctx.fail("there is nothing to choose from");
    return Value(0.0);
  }
  SizeSpec size;
  if (!readSize(args[1], size, ctx))
    return Value(0.0);
  if (!args[2].isBool()) {
    ctx.fail("replace must be true or false");
    return Value(0.0);
  }
  const bool replace = args[2].number != 0.0;
  std::vector<double> p;
  if (args.size() > 3) {
    if (!argNumbers(args, 3, ctx, p))
      return Value(0.0);
    if (p.size() != pool.size()) {
      ctx.fail("p needs one probability per element (" + std::to_string(pool.size()) + "), not " +
               std::to_string(p.size()));
      return Value(0.0);
    }
    double sum = 0;
    for (double q : p) {
      if (!(q >= 0)) {
        ctx.fail("p must not hold negative numbers");
        return Value(0.0);
      }
      sum += q;
    }
    if (std::fabs(sum - 1.0) > 1e-8) {
      ctx.fail("the probabilities p must add up to 1 (they add up to " + formatNumber(sum) + ")");
      return Value(0.0);
    }
  }
  const size_t count = size.count();
  if (!replace && count > pool.size()) {
    ctx.fail("cannot take " + std::to_string(count) + " different elements from " +
             std::to_string(pool.size()) + " without replace=true");
    return Value(0.0);
  }
  std::vector<double> weights = p.empty() ? std::vector<double>(pool.size(), 1.0) : p;
  std::vector<Value> picked;
  picked.reserve(count);
  for (size_t k = 0; k < count; k++) {
    std::discrete_distribution<size_t> pick(weights.begin(), weights.end());
    const size_t i = pick(rng());
    picked.push_back(pool[i]);
    if (!replace)
      weights[i] = 0.0; // each element at most once
    if (!replace && k + 1 < count &&
        std::accumulate(weights.begin(), weights.end(), 0.0) <= 0.0) {
      ctx.fail("not enough elements with a non-zero probability to choose " +
               std::to_string(count) + " different ones");
      return Value(0.0);
    }
  }
  if (size.single)
    return picked[0];
  if (!ndx::unifyCells(picked, ctx))
    return Value(0.0);
  return ndx::valueOf(Grid{size.shape, picked});
}

// The shuffle axis: named, else a vector's length, else the rows (axis 0).
Value shuffleGrid(Grid a, const Value *axisArg, CallContext &ctx) {
  size_t axis = 0;
  if (axisArg) {
    if (!ndx::resolveAxis(*axisArg, a.shape.size(), ctx, axis))
      return Value(0.0);
  } else if (a.shape.size() == 2 && a.shape[0] == 1) {
    axis = 1; // a row vector: along its length
  }
  std::vector<std::vector<Value>> slices = ndx::slicesOf(a, axis);
  std::shuffle(slices.begin(), slices.end(), rng());
  return ndx::valueOf(ndx::fromSlices(a.shape, axis, slices));
}

Value shuffleFn(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  return shuffleGrid(a, args.size() > 1 ? &args[1] : nullptr, ctx);
}

Value permutationFn(const std::vector<Value> &args, CallContext &ctx) {
  if (isPlainNumber(args[0]) && !args[0].isComplex) {
    long long n = 0;
    if (!argNonNegativeInt(args, 0, ctx, n))
      return Value(0.0);
    std::vector<Value> cells;
    for (long long k = 0; k < n; k++)
      cells.push_back(Value(static_cast<double>(k)));
    std::shuffle(cells.begin(), cells.end(), rng());
    return ndx::rowOf(cells);
  }
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  return shuffleGrid(a, nullptr, ctx);
}

/* ---- distributions ---- */

Value binomialFn(const std::vector<Value> &args, CallContext &ctx) {
  long long n = 0;
  double p = 0;
  SizeSpec size;
  if (!argNonNegativeInt(args, 0, ctx, n) || !argNumber(args, 1, ctx, p) ||
      !probability(p, "p", ctx) || !readSize(args[2], size, ctx))
    return Value(0.0);
  std::binomial_distribution<long long> d(n, p);
  return drawMany(size, [&] { return static_cast<double>(d(rng())); });
}

Value poissonFn(const std::vector<Value> &args, CallContext &ctx) {
  double lam = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, lam) || !readSize(args[1], size, ctx))
    return Value(0.0);
  if (!(lam >= 0) || !std::isfinite(lam)) {
    ctx.fail("lam must be a number >= 0");
    return Value(0.0);
  }
  if (lam == 0)
    return drawMany(size, [] { return 0.0; });
  std::poisson_distribution<long long> d(lam);
  return drawMany(size, [&] { return static_cast<double>(d(rng())); });
}

Value exponentialFn(const std::vector<Value> &args, CallContext &ctx) {
  double scale = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, scale) || !positive(scale, "scale", ctx) ||
      !readSize(args[1], size, ctx))
    return Value(0.0);
  std::exponential_distribution<double> d(1.0 / scale);
  return drawMany(size, [&] { return d(rng()); });
}

Value gammaFn(const std::vector<Value> &args, CallContext &ctx) {
  double shape = 0, scale = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, shape) || !positive(shape, "shape", ctx) ||
      !argNumber(args, 1, ctx, scale) || !positive(scale, "scale", ctx) ||
      !readSize(args[2], size, ctx))
    return Value(0.0);
  std::gamma_distribution<double> d(shape, scale);
  return drawMany(size, [&] { return d(rng()); });
}

Value betaFn(const std::vector<Value> &args, CallContext &ctx) {
  double a = 0, b = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, a) || !positive(a, "a", ctx) || !argNumber(args, 1, ctx, b) ||
      !positive(b, "b", ctx) || !readSize(args[2], size, ctx))
    return Value(0.0);
  // X / (X + Y) with X ~ Gamma(a), Y ~ Gamma(b).
  std::gamma_distribution<double> ga(a, 1.0), gb(b, 1.0);
  return drawMany(size, [&] {
    const double x = ga(rng()), y = gb(rng());
    return x + y > 0 ? x / (x + y) : (a >= b ? 1.0 : 0.0);
  });
}

Value lognormalFn(const std::vector<Value> &args, CallContext &ctx) {
  double mean = 0, sigma = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, mean) || !argNumber(args, 1, ctx, sigma) ||
      !readSize(args[2], size, ctx))
    return Value(0.0);
  if (!(sigma >= 0) || !std::isfinite(sigma)) {
    ctx.fail("sigma must be a number >= 0");
    return Value(0.0);
  }
  if (sigma == 0)
    return drawMany(size, [&] { return std::exp(mean); });
  std::lognormal_distribution<double> d(mean, sigma);
  return drawMany(size, [&] { return d(rng()); });
}

Value chisquareFn(const std::vector<Value> &args, CallContext &ctx) {
  double df = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, df) || !positive(df, "df", ctx) || !readSize(args[1], size, ctx))
    return Value(0.0);
  std::chi_squared_distribution<double> d(df);
  return drawMany(size, [&] { return d(rng()); });
}

Value triangularFn(const std::vector<Value> &args, CallContext &ctx) {
  double left = 0, mode = 0, right = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, left) || !argNumber(args, 1, ctx, mode) ||
      !argNumber(args, 2, ctx, right) || !readSize(args[3], size, ctx))
    return Value(0.0);
  if (!(left <= mode && mode <= right && left < right)) {
    ctx.fail("needs left <= mode <= right with left < right");
    return Value(0.0);
  }
  std::uniform_real_distribution<double> u(0.0, 1.0);
  const double fc = (mode - left) / (right - left);
  return drawMany(size, [&] { // inverse of the cumulative distribution
    const double v = u(rng());
    return v < fc ? left + std::sqrt(v * (right - left) * (mode - left))
                  : right - std::sqrt((1 - v) * (right - left) * (right - mode));
  });
}

Value geometricFn(const std::vector<Value> &args, CallContext &ctx) {
  double p = 0;
  SizeSpec size;
  if (!argNumber(args, 0, ctx, p) || !readSize(args[1], size, ctx))
    return Value(0.0);
  if (!(p > 0 && p <= 1)) {
    ctx.fail("p must be a probability greater than 0 and at most 1");
    return Value(0.0);
  }
  if (p == 1)
    return drawMany(size, [] { return 1.0; });
  std::geometric_distribution<long long> d(p); // failures before the first success
  return drawMany(size, [&] { return static_cast<double>(d(rng()) + 1); });
}

// One row of counts per draw; size gives the number of draws (and shape).
Value multinomialFn(const std::vector<Value> &args, CallContext &ctx) {
  long long n = 0;
  std::vector<double> p;
  SizeSpec size;
  if (!argNonNegativeInt(args, 0, ctx, n) || !argNumbers(args, 1, ctx, p) ||
      !readSize(args[2], size, ctx))
    return Value(0.0);
  if (p.empty()) {
    ctx.fail("pvals must hold at least one probability");
    return Value(0.0);
  }
  double sum = 0;
  for (double q : p) {
    if (!(q >= 0 && q <= 1)) {
      ctx.fail("every probability in pvals must be between 0 and 1");
      return Value(0.0);
    }
    sum += q;
  }
  if (sum > 1.0 + 1e-8) {
    ctx.fail("the probabilities in pvals add up to more than 1 (" + formatNumber(sum) + ")");
    return Value(0.0);
  }
  const size_t draws = size.count();
  std::vector<Value> cells;
  cells.reserve(draws * p.size());
  for (size_t d = 0; d < draws; d++) {
    long long left = n;
    double rest = 1.0;
    for (size_t i = 0; i < p.size(); i++) {
      long long c = 0;
      if (i + 1 == p.size()) {
        c = left; // the last category takes what is left (NumPy)
      } else if (left > 0 && rest > 0) {
        const double q = std::min(1.0, std::max(0.0, p[i] / rest));
        std::binomial_distribution<long long> b(left, q);
        c = b(rng());
      }
      cells.push_back(Value(static_cast<double>(c)));
      left -= c;
      rest -= p[i];
    }
  }
  nd::Shape shape = size.single ? nd::Shape{1, p.size()} : size.shape;
  if (!size.single) {
    if (shape.size() == 2 && shape[0] == 1)
      shape = {shape[1], p.size()}; // size=m: m rows of counts
    else
      shape.push_back(p.size());
  }
  return ndx::valueOf(Grid{shape, cells});
}

// One row (a point) per draw: mean + L z with cov = L L^T.
Value mvnormalFn(const std::vector<Value> &args, CallContext &ctx) {
  std::vector<double> mean;
  SizeSpec size;
  if (!argNumbers(args, 0, ctx, mean) || mean.empty())
    return Value(0.0);
  Grid cov;
  if (!ndx::argGrid(args, 1, ctx, cov))
    return Value(0.0);
  const size_t k = mean.size();
  std::vector<double> c;
  if (cov.shape != nd::Shape{k, k} || !ndx::realCells(cov, c)) {
    ctx.fail("cov must be a " + std::to_string(k) + "x" + std::to_string(k) +
             " matrix of numbers (one row and column per entry of mean)");
    return Value(0.0);
  }
  if (!readSize(args[2], size, ctx))
    return Value(0.0);
  Eigen::MatrixXd C(k, k);
  for (size_t i = 0; i < k; i++)
    for (size_t j = 0; j < k; j++)
      C(static_cast<Eigen::Index>(i), static_cast<Eigen::Index>(j)) = c[i * k + j];
  const double scale = std::max(1.0, C.cwiseAbs().maxCoeff());
  if ((C - C.transpose()).cwiseAbs().maxCoeff() > 1e-8 * scale) {
    ctx.fail("cov must be symmetric");
    return Value(0.0);
  }
  // Eigen-decomposition works for a singular (positive semi-definite) cov too.
  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eig(C);
  if (eig.eigenvalues().minCoeff() < -1e-8 * scale) {
    ctx.fail("cov must be positive semi-definite (it has a negative eigenvalue)");
    return Value(0.0);
  }
  const Eigen::MatrixXd L =
      eig.eigenvectors() * eig.eigenvalues().cwiseMax(0.0).cwiseSqrt().asDiagonal();
  std::normal_distribution<double> z(0.0, 1.0);
  const size_t draws = size.count();
  std::vector<Value> cells;
  cells.reserve(draws * k);
  Eigen::VectorXd zv(k);
  for (size_t d = 0; d < draws; d++) {
    for (size_t i = 0; i < k; i++)
      zv(static_cast<Eigen::Index>(i)) = z(rng());
    const Eigen::VectorXd x = L * zv;
    for (size_t i = 0; i < k; i++)
      cells.push_back(Value(mean[i] + x(static_cast<Eigen::Index>(i))));
  }
  nd::Shape shape{1, k};
  if (!size.single) {
    shape = size.shape;
    if (shape.size() == 2 && shape[0] == 1)
      shape = {shape[1], k};
    else
      shape.push_back(k);
  }
  return ndx::valueOf(Grid{shape, cells});
}

void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
         const char *numpyName, Impl impl, bool acceptsComplex = false) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::CreatingArrays;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = acceptsComplex;
  reg.add(std::move(spec));
}

void addGrids(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
              const char *numpyName,
              bool (*fn)(const std::vector<Value> &, std::vector<Value> &, CallContext &)) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::CreatingArrays;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = listOf(fn);
  spec.multiImpl = multiOf(fn);
  spec.maxOutputs = 32;
  spec.acceptsComplex = true;
  reg.add(std::move(spec));
}

} // namespace

void registerCreatingFunctions(Registry &reg) {
  add(reg, "check_finite", 1, 1, "A, or an error if it holds NaN / Inf", "np.asarray_chkfinite",
      checkFinite, true);
  add(reg, "zeros_like", 1, 1, "zeros of the same shape and type", "np.zeros_like",
      filledLike(0.0), true);
  add(reg, "ones_like", 1, 1, "ones of the same shape and type", "np.ones_like", filledLike(1.0),
      true);
  add(reg, "vander", 1, 3, "Vandermonde matrix", "np.vander", vander);
  addGrids(reg, "meshgrid", 2, 3, "coordinate grids", "np.meshgrid", meshgridGrids);
  addGrids(reg, "indices", 1, 1, "index grids", "np.indices", indexGrids);

  add(reg, "rand_choice", 1, 4, "random elements", "np.random.choice", randChoice, true);
  add(reg, "shuffle", 1, 2, "a shuffled copy", "np.random.shuffle", shuffleFn, true);
  add(reg, "permutation", 1, 1, "a random order", "np.random.permutation", permutationFn, true);
  add(reg, "rand_binomial", 2, 3, "binomial samples", "np.random.binomial", binomialFn);
  add(reg, "rand_poisson", 1, 2, "Poisson samples", "np.random.poisson", poissonFn);
  add(reg, "rand_exponential", 0, 2, "exponential samples", "np.random.exponential",
      exponentialFn);
  add(reg, "rand_beta", 2, 3, "beta samples", "np.random.beta", betaFn);
  add(reg, "rand_gamma", 1, 3, "gamma samples", "np.random.gamma", gammaFn);
  add(reg, "rand_lognormal", 0, 3, "log-normal samples", "np.random.lognormal", lognormalFn);
  add(reg, "rand_chisquare", 1, 2, "chi-square samples", "np.random.chisquare", chisquareFn);
  add(reg, "rand_triangular", 3, 4, "triangular samples", "np.random.triangular", triangularFn);
  add(reg, "rand_geometric", 1, 2, "geometric samples", "np.random.geometric", geometricFn);
  add(reg, "rand_multinomial", 2, 3, "multinomial counts", "np.random.multinomial",
      multinomialFn);
  add(reg, "rand_mvnormal", 2, 3, "multivariate normal points",
      "np.random.multivariate_normal", mvnormalFn);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"check_finite", "A"},
      {"zeros_like", "A"},
      {"ones_like", "A"},
      {"vander", "x, N=0, increasing=false"},
      {"meshgrid", "x, y, indexing=\"xy\""},
      {"indices", "dims"},
      {"rand_choice", "a, size=1, replace=true, p?"},
      {"shuffle", "A, axis?"},
      {"permutation", "x"},
      {"rand_binomial", "n, p, size=1"},
      {"rand_poisson", "lam, size=1"},
      {"rand_exponential", "scale=1, size=1"},
      {"rand_beta", "a, b, size=1"},
      {"rand_gamma", "shape, scale=1, size=1"},
      {"rand_lognormal", "mean=0, sigma=1, size=1"},
      {"rand_chisquare", "df, size=1"},
      {"rand_triangular", "left, mode, right, size=1"},
      {"rand_geometric", "p, size=1"},
      {"rand_multinomial", "n, pvals, size=1"},
      {"rand_mvnormal", "mean, cov, size=1"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
