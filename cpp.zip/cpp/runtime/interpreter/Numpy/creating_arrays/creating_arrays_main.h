// Section 2 of 11 - Creating Arrays (71 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_CREATING_ARRAYS_MAIN_H
#define NC_NUMPY_CREATING_ARRAYS_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Creating Arrays function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerCreatingArrays(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_CREATING_ARRAYS_MAIN_H
