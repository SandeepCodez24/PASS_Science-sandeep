// Indexing & Slicing - only indexing_slicing_main.cpp includes this header.
#ifndef NC_NUMPY_IX_FUNCTIONS_H
#define NC_NUMPY_IX_FUNCTIONS_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// take, where, nonzero, choose, compress, extract, diag_indices,
// tril_indices, triu_indices, mask_indices, ravel_index (with their
// parameter lines).
void registerIndexingFunctions(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_IX_FUNCTIONS_H
