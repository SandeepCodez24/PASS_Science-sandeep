// Section 7 of 11 - Indexing & Slicing (54 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_INDEXING_SLICING_MAIN_H
#define NC_NUMPY_INDEXING_SLICING_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Indexing & Slicing function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerIndexingSlicing(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_INDEXING_SLICING_MAIN_H
