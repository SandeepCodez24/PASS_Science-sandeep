// Section 7 of 11 - Indexing & Slicing
// Planned entries: 54  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   ix_functions.cpp   take where nonzero choose compress extract diag_indices
//                      tril_indices triu_indices mask_indices ravel_index
//
// Names from the team's list that are not here (dropped by the team,
// 2026-10-28): slice, reverse (A[::-1] does it), pick, find.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        indexing_slicing/ix_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerIndexingSlicing() below.
//   2. Register it with reg.add({...}) and give it a parameter line
//      (reg.setParams(name, "A, axis?") - core/param_list.h).
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("indexing_slicing")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "indexing_slicing_main.h"

#include "ix_functions.h"

namespace nc {
namespace numpy {

void registerIndexingSlicing(Registry &reg) { registerIndexingFunctions(reg); }

} // namespace numpy
} // namespace nc
