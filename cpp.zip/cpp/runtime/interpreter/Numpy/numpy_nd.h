// Shape-and-axis helpers shared by the NumPy sections that move, cut, sort
// or compare the elements of a matrix of any rank (adding/removing,
// copying/sorting/reshaping, indexing, working with data ...).
// Header-only, like numpy_common.h.
//
// A value is handled as a Grid: its shape as a matrix (ops/matrix/nd_array.h -
// a single value [1, 1], a 1-D array [1, n], a matrix [r, c], an N-D matrix
// [d0, ..., r, c]) and its elements in ROW-MAJOR order (the last index
// fastest - the order NumPy's flat indices and reshape use). Every element
// stays a whole Value, so ints, bools, text and complex numbers keep their
// type; a result whose cells were mixed goes through the matrix type rules
// (unifyCells) so it holds what the matrix literal would.
//
// Axes count from the first (axis 0) and a negative axis from the end
// (-1 = columns, -2 = rows), as in NumPy.
#ifndef NC_NUMPY_ND_H
#define NC_NUMPY_ND_H

#include <cmath>
#include <functional>
#include <string>
#include <vector>

#include "numpy_common.h"
#include "../ops/matrix/matrix_index.h"
#include "../ops/matrix/nd_array.h"

namespace nc {
namespace numpy {
namespace ndx {

struct Grid {
  nd::Shape shape;
  std::vector<Value> cells; // row-major
  size_t count() const { return cells.size(); }
};

inline Grid gridOf(const Value &v) { return Grid{nd::shapeOf(v), nd::rowMajorCells(v)}; }

// A Grid back as a value: a 2-D matrix for rank 2, N-D for more, [] when empty.
inline Value valueOf(const Grid &g) { return nd::buildRowMajor(g.shape, g.cells); }

// The cells as a 1xN row matrix (a flattened result).
inline Value rowOf(const std::vector<Value> &cells) {
  return nd::buildRowMajor({1, cells.size()}, cells);
}

// True for a dict, object or function reference - nothing a matrix holds.
inline bool notMatrixData(const Value &v) { return v.isDict || v.isObject || v.isFunctionRef; }

// args[i] as a Grid; fails for a dict / object / function reference.
inline bool argGrid(const std::vector<Value> &args, size_t i, CallContext &ctx, Grid &out) {
  if (i >= args.size() || notMatrixData(args[i])) {
    ctx.fail("the " + ordinal(i) + " argument must be a matrix, a number or text");
    return false;
  }
  out = gridOf(args[i]);
  return true;
}

// A whole number in [-rank, rank-1] (or [-(rank+1), rank] when `inserting`),
// as an axis index.
inline bool resolveAxis(const Value &a, size_t rank, CallContext &ctx, size_t &out,
                        bool inserting = false) {
  if (!isPlainNumber(a) || !std::isfinite(a.number) || a.number != std::floor(a.number)) {
    ctx.fail("axis must be a whole number, e.g. axis=0 (rows of a matrix) or axis=-1 (columns)");
    return false;
  }
  const long long n = static_cast<long long>(rank) + (inserting ? 1 : 0);
  const long long w = static_cast<long long>(a.number);
  if (w < -n || w >= n) {
    ctx.fail("axis " + std::to_string(w) + " does not exist for a " + std::to_string(rank) +
             "-D input - use 0 to " + std::to_string(n - 1) + " (or -1 to -" + std::to_string(n) +
             ")");
    return false;
  }
  out = static_cast<size_t>(w < 0 ? w + n : w);
  return true;
}

// How a row-major Grid walks along one axis: `outer` blocks, each holding
// `len` slices of `inner` consecutive cells.
struct AxisView {
  size_t outer = 1, len = 1, inner = 1;
};

inline AxisView viewOf(const nd::Shape &s, size_t axis) {
  AxisView v;
  v.len = s[axis];
  for (size_t d = 0; d < axis; d++)
    v.outer *= s[d];
  for (size_t d = axis + 1; d < s.size(); d++)
    v.inner *= s[d];
  return v;
}

// Slice k along `axis` (the cells with index k on that axis), row-major.
inline std::vector<Value> sliceCells(const Grid &g, size_t axis, size_t k) {
  const AxisView v = viewOf(g.shape, axis);
  std::vector<Value> out;
  out.reserve(v.outer * v.inner);
  for (size_t o = 0; o < v.outer; o++) {
    const size_t start = (o * v.len + k) * v.inner;
    out.insert(out.end(), g.cells.begin() + start, g.cells.begin() + start + v.inner);
  }
  return out;
}

// Every slice along `axis`.
inline std::vector<std::vector<Value>> slicesOf(const Grid &g, size_t axis) {
  std::vector<std::vector<Value>> out;
  for (size_t k = 0; k < g.shape[axis]; k++)
    out.push_back(sliceCells(g, axis, k));
  return out;
}

// The Grid made of `slices` laid along `axis`; `shape` is the shape of the
// whole (its `axis` entry is replaced by slices.size()).
inline Grid fromSlices(nd::Shape shape, size_t axis,
                       const std::vector<std::vector<Value>> &slices) {
  shape[axis] = slices.size();
  Grid g;
  g.shape = shape;
  const AxisView v = viewOf(shape, axis);
  g.cells.reserve(nd::countOf(shape));
  for (size_t o = 0; o < v.outer; o++)
    for (const auto &s : slices)
      g.cells.insert(g.cells.end(), s.begin() + o * v.inner, s.begin() + (o + 1) * v.inner);
  return g;
}

// The matrix type rules over mixed cells (matUnifyCells).
inline bool unifyCells(std::vector<Value> &cells, CallContext &ctx) {
  std::string err;
  if (!matUnifyCells(cells, err)) {
    ctx.fail(err);
    return false;
  }
  return true;
}

// Every element of a value, row-major, when they are all real numbers
// (plain, bool, int, float32 ...). Complex, text and time values fail.
inline bool realCells(const Grid &g, std::vector<double> &out) {
  out.clear();
  out.reserve(g.count());
  for (const Value &c : g.cells) {
    if (!isPlainNumber(c) || c.isComplex || c.isTime())
      return false;
    out.push_back(c.number);
  }
  return true;
}

/* ---- ordering (unique, sort, ...) ----
   Numbers ascending with every NaN last (NaN counts equal to NaN, as in
   NumPy's unique); integers compared exactly; complex numbers by real part,
   then imaginary part (NumPy's order); text by its bytes (dictionary order
   for ASCII). A matrix holds one kind of element, so mixed kinds only meet
   here by mistake - text then sorts after numbers. */

inline int compareCells(const Value &a, const Value &b) {
  if (a.isText || b.isText) {
    if (a.isText != b.isText)
      return a.isText ? 1 : -1;
    const int c = a.text().compare(b.text());
    return c < 0 ? -1 : (c > 0 ? 1 : 0);
  }
  if (a.isInt() && b.isInt() && a.intIsUnsigned() == b.intIsUnsigned()) {
    if (a.intIsUnsigned()) {
      const uint64_t x = static_cast<uint64_t>(a.intBits()), y = static_cast<uint64_t>(b.intBits());
      return x < y ? -1 : (x > y ? 1 : 0);
    }
    return a.intBits() < b.intBits() ? -1 : (a.intBits() > b.intBits() ? 1 : 0);
  }
  auto cmpReal = [](double x, double y) {
    const bool nx = std::isnan(x), ny = std::isnan(y);
    if (nx || ny)
      return nx == ny ? 0 : (nx ? 1 : -1);
    return x < y ? -1 : (x > y ? 1 : 0);
  };
  const int r = cmpReal(a.number, b.number);
  if (r != 0)
    return r;
  return cmpReal(a.isComplex ? a.imag : 0.0, b.isComplex ? b.imag : 0.0);
}

/* ---- functions with several results ----
   [r, c] = nonzero(A): one result per name. With one name the results come
   as a list (P = nonzero(A); P[0], P[1]) - a single result as itself. */

using ResultsFn =
    std::function<bool(const std::vector<Value> &, std::vector<Value> &, CallContext &)>;

inline Impl resultsAsList(ResultsFn fn) {
  return [fn](const std::vector<Value> &args, CallContext &ctx) -> Value {
    std::vector<Value> out;
    if (!fn(args, out, ctx))
      return Value(0.0);
    return out.size() == 1 ? out[0] : Value(std::move(out));
  };
}

inline MultiImpl resultsPerName(ResultsFn fn) {
  return [fn](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
    std::vector<Value> results;
    if (!fn(args, results, ctx))
      return;
    if (nout == 1) {
      out = {results.size() == 1 ? results[0] : Value(std::move(results))};
      return;
    }
    if (nout != results.size()) {
      ctx.fail("it gives " + std::to_string(results.size()) + " results, but " +
               std::to_string(nout) + " names were given");
      return;
    }
    out = std::move(results);
  };
}

// True / false of a mask element: a bool or number (0 = false).
inline bool maskCell(const Value &c, bool &out, CallContext &ctx) {
  if (!isPlainNumber(c) || c.isTime()) {
    ctx.fail("a condition must hold true/false (or numbers, 0 = false)");
    return false;
  }
  out = c.number != 0.0 || (c.isComplex && c.imag != 0.0);
  return true;
}

// Lexicographic order of two equally long cell lists (rows, slices).
inline int compareSlices(const std::vector<Value> &a, const std::vector<Value> &b) {
  for (size_t i = 0; i < a.size() && i < b.size(); i++)
    if (const int c = compareCells(a[i], b[i]))
      return c;
  return a.size() < b.size() ? -1 : (a.size() > b.size() ? 1 : 0);
}

} // namespace ndx
} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_ND_H
