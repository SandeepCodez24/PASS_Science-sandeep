// Copying, Sorting & Reshaping.
//
//   sort_asc(A[, axis])      ascending, along an axis            np.sort
//   sort_desc(A[, axis])     descending, along an axis           -np.sort(-A)
//   sort_complex(A[, axis])  ascending by real, then imaginary part, as complex
//                                                                np.sort_complex
//   flatten(A, order="C")    every element in one 1xN row        ndarray.flatten
//                            ("C" row by row, "F" column by column)
//   flip(A[, axis])          reversed along one axis, or every axis   np.flip
//   fliplr(A)                columns reversed (left <-> right)   np.fliplr
//   flipud(A)                rows reversed (up <-> down)         np.flipud
//   rot90(A, k=1)            turned 90 degrees counter-clockwise k times
//                            (k < 0: clockwise)                  np.rot90
//   roll(A, shift[, axis])   elements moved `shift` places, those falling off
//                            one end coming back at the other    np.roll
//
// Sorting order: numbers ascending with NaN always LAST (also in sort_desc),
// integers exactly, text in dictionary (byte) order, complex numbers by real
// then imaginary part. Equal elements keep their order (a stable sort).
//
// Which axis when none is given: a vector (one row or one column) is
// sorted along its length; any other matrix row by row (axis -1, NumPy's
// default). Name the axis to choose: axis=0 sorts every column.
//
// Matrix-centred choices: fliplr / flipud / rot90 always work on the COLUMNS
// and ROWS (axes -1 / -2), for an N-D matrix on every page - the same as
// NumPy for 2-D values. roll without an axis moves the elements in row-by-row
// order and keeps the shape (NumPy).
#include "csr_functions.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <string>
#include <vector>

#include "../numpy_nd.h"

namespace nc {
namespace numpy {

namespace {

using ndx::Grid;

bool isNaNCell(const Value &c) {
  return !c.isText && (std::isnan(c.number) || (c.isComplex && std::isnan(c.imag)));
}

// The axis to sort along: the named one, else a vector's length, else -1.
bool sortAxis(const std::vector<Value> &args, const Grid &a, CallContext &ctx, size_t &axis) {
  const size_t rank = a.shape.size();
  if (args.size() > 1)
    return ndx::resolveAxis(args[1], rank, ctx, axis);
  axis = rank - 1;
  if (rank == 2 && a.shape[1] == 1 && a.shape[0] > 1)
    axis = 0; // a column vector: along its length
  return true;
}

// Sorts every line of `g` along `axis` in place.
void sortLines(Grid &g, size_t axis, bool descending) {
  const ndx::AxisView v = ndx::viewOf(g.shape, axis);
  auto less = [descending](const Value &x, const Value &y) {
    const bool nx = isNaNCell(x), ny = isNaNCell(y);
    if (nx || ny)
      return !nx && ny; // NaN last, either way
    const int c = ndx::compareCells(x, y);
    return descending ? c > 0 : c < 0;
  };
  std::vector<Value> line(v.len);
  for (size_t o = 0; o < v.outer; o++)
    for (size_t i = 0; i < v.inner; i++) {
      for (size_t k = 0; k < v.len; k++)
        line[k] = g.cells[(o * v.len + k) * v.inner + i];
      std::stable_sort(line.begin(), line.end(), less);
      for (size_t k = 0; k < v.len; k++)
        g.cells[(o * v.len + k) * v.inner + i] = line[k];
    }
}

Impl sortImpl(bool descending, bool asComplex) {
  return [descending, asComplex](const std::vector<Value> &args, CallContext &ctx) -> Value {
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    size_t axis = 0;
    if (!sortAxis(args, a, ctx, axis))
      return Value(0.0);
    if (asComplex) {
      for (Value &c : a.cells) {
        if (!isPlainNumber(c) || c.isTime()) {
          ctx.fail("it works on numbers");
          return Value(0.0);
        }
        if (!c.isComplex)
          c = Value::complexNumber(c.number, 0.0);
      }
    }
    if (a.count() > 0)
      sortLines(a, axis, descending);
    return ndx::valueOf(a);
  };
}

// Reverses `g` along `axis`.
void reverseAlong(Grid &g, size_t axis) {
  std::vector<std::vector<Value>> slices = ndx::slicesOf(g, axis);
  std::reverse(slices.begin(), slices.end());
  g = ndx::fromSlices(g.shape, axis, slices);
}

Value flatten(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  std::string order;
  if (!argText(args, 1, ctx, order))
    return Value(0.0);
  for (char &c : order)
    c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  if (order == "C")
    return ndx::rowOf(a.cells);
  if (order != "F") {
    ctx.fail("order must be \"C\" (row by row) or \"F\" (column by column)");
    return Value(0.0);
  }
  // Column by column: the FIRST index fastest.
  std::vector<Value> out;
  out.reserve(a.count());
  const nd::Shape &s = a.shape;
  std::vector<size_t> idx(s.size(), 0);
  if (a.count() > 0) {
    for (;;) {
      size_t flat = 0;
      for (size_t d = 0; d < s.size(); d++)
        flat = flat * s[d] + idx[d];
      out.push_back(a.cells[flat]);
      size_t d = 0;
      while (d < s.size() && ++idx[d] == s[d])
        idx[d++] = 0;
      if (d == s.size())
        break;
    }
  }
  return ndx::rowOf(out);
}

Value flip(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  if (args.size() > 1) {
    size_t axis = 0;
    if (!ndx::resolveAxis(args[1], a.shape.size(), ctx, axis))
      return Value(0.0);
    reverseAlong(a, axis);
  } else {
    std::reverse(a.cells.begin(), a.cells.end()); // every axis at once
  }
  return ndx::valueOf(a);
}

Impl flipFixed(long long fromEnd) { // -1 columns, -2 rows
  return [fromEnd](const std::vector<Value> &args, CallContext &ctx) -> Value {
    Grid a;
    if (!ndx::argGrid(args, 0, ctx, a))
      return Value(0.0);
    reverseAlong(a, static_cast<size_t>(static_cast<long long>(a.shape.size()) + fromEnd));
    return ndx::valueOf(a);
  };
}

Value rot90(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  long long k = 0;
  if (!argInt(args, 1, ctx, k))
    return Value(0.0);
  k = ((k % 4) + 4) % 4;
  const size_t rank = a.shape.size();
  const size_t R = a.shape[rank - 2], C = a.shape[rank - 1];
  const size_t pages = R * C == 0 ? 0 : a.count() / (R * C);
  for (long long turn = 0; turn < k; turn++) {
    // One quarter turn counter-clockwise: B[i][j] = A[j][C-1-i], B is C x R.
    const size_t r = a.shape[rank - 2], c = a.shape[rank - 1];
    std::vector<Value> cells(a.count());
    for (size_t p = 0; p < pages; p++)
      for (size_t i = 0; i < c; i++)
        for (size_t j = 0; j < r; j++)
          cells[p * r * c + i * r + j] = a.cells[p * r * c + j * c + (c - 1 - i)];
    a.cells = std::move(cells);
    std::swap(a.shape[rank - 2], a.shape[rank - 1]);
  }
  return ndx::valueOf(a);
}

Value roll(const std::vector<Value> &args, CallContext &ctx) {
  Grid a;
  if (!ndx::argGrid(args, 0, ctx, a))
    return Value(0.0);
  long long shift = 0;
  if (!argInt(args, 1, ctx, shift))
    return Value(0.0);
  auto rotateBy = [shift](auto &seq) {
    const long long n = static_cast<long long>(seq.size());
    if (n == 0)
      return;
    const long long s = ((shift % n) + n) % n; // to the right by s
    std::rotate(seq.begin(), seq.begin() + (n - s) % n, seq.end());
  };
  if (args.size() < 3) {
    rotateBy(a.cells); // row by row, shape kept
    return ndx::valueOf(a);
  }
  size_t axis = 0;
  if (!ndx::resolveAxis(args[2], a.shape.size(), ctx, axis))
    return Value(0.0);
  std::vector<std::vector<Value>> slices = ndx::slicesOf(a, axis);
  rotateBy(slices);
  return ndx::valueOf(ndx::fromSlices(a.shape, axis, slices));
}

void add(Registry &reg, const char *name, int minArgs, int maxArgs, const char *summary,
         const char *numpyName, Impl impl) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::CopyingSortingReshaping;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = name;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = true; // they move elements; complex order is defined
  reg.add(std::move(spec));
}

} // namespace

void registerCopySortReshapeFunctions(Registry &reg) {
  add(reg, "sort_asc", 1, 2, "sorted ascending along an axis", "np.sort", sortImpl(false, false));
  add(reg, "sort_desc", 1, 2, "sorted descending along an axis", "-np.sort(-a)",
      sortImpl(true, false));
  add(reg, "sort_complex", 1, 2, "sorted by real then imaginary part", "np.sort_complex",
      sortImpl(false, true));
  add(reg, "flatten", 1, 2, "every element in one row", "ndarray.flatten", flatten);
  add(reg, "flip", 1, 2, "reversed along an axis (or all)", "np.flip", flip);
  add(reg, "fliplr", 1, 1, "columns reversed", "np.fliplr", flipFixed(-1));
  add(reg, "flipud", 1, 1, "rows reversed", "np.flipud", flipFixed(-2));
  add(reg, "rot90", 1, 2, "turned 90 degrees counter-clockwise", "np.rot90", rot90);
  add(reg, "roll", 2, 3, "elements moved around in a cycle", "np.roll", roll);

  struct Row {
    const char *name;
    const char *params;
  };
  const Row kParams[] = {
      {"sort_asc", "A, axis?"},   {"sort_desc", "A, axis?"},       {"sort_complex", "A, axis?"},
      {"flatten", "A, order=\"C\""}, {"flip", "A, axis?"},         {"fliplr", "A"},
      {"flipud", "A"},            {"rot90", "A, k=1"},             {"roll", "A, shift, axis?"},
  };
  for (const Row &r : kParams)
    reg.setParams(r.name, r.params);
}

} // namespace numpy
} // namespace nc
