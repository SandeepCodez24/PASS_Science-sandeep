// Copying, Sorting & Reshaping - only copying_sorting_reshaping_main.cpp
// includes this header.
#ifndef NC_NUMPY_CSR_FUNCTIONS_H
#define NC_NUMPY_CSR_FUNCTIONS_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// sort_asc, sort_desc, sort_complex, flatten, flip, fliplr, flipud, rot90,
// roll (with their parameter lines).
void registerCopySortReshapeFunctions(Registry &reg);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_CSR_FUNCTIONS_H
