// Section 4 of 11 - Copying, Sorting, & Reshaping
// Planned entries: 47  (check progress from NC with: numpy_status())
//
// This file is the ONE place where this section's functions are mapped to NC
// names. The functions live in group files:
//
//   csr_functions.cpp   sort_asc sort_desc sort_complex flatten flip fliplr
//                       flipud rot90 roll
//
// Names from the team's list that are existing NC builtins and keep the
// builtin: sort (vectors; sort_asc is the matrix-aware one), reshape.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        copying_sorting_reshaping/csr_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerCopyingSortingReshaping() below.
//   2. Register it with reg.add({...}) and give it a parameter line
//      (reg.setParams(name, "A, axis?") - core/param_list.h).
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Numpy/numpy_sources.cmake globs the whole Numpy tree).
//   4. Try it in NC:   numpy_functions("copying_sorting_reshaping")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 11 sections.
//   - A name that already exists as an NC builtin (sum, mean, sin, det, ...),
//     an NC keyword, or a parser-reserved call is skipped: the existing one
//     stays. The reason is printed at startup and numpy_status() counts it.
#include "copying_sorting_reshaping_main.h"

#include "csr_functions.h"

namespace nc {
namespace numpy {

void registerCopyingSortingReshaping(Registry &reg) { registerCopySortReshapeFunctions(reg); }

} // namespace numpy
} // namespace nc
