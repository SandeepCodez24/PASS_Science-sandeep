# Collects every .cpp under runtime/interpreter/Numpy/ into NC_NUMPY_SOURCES.
#
# Included from runtime/CMakeLists.txt before RUNTIME_SOURCES is built:
#
#   include(${CMAKE_CURRENT_SOURCE_DIR}/interpreter/Numpy/numpy_sources.cmake)
#   set(RUNTIME_SOURCES ... ${NC_NUMPY_SOURCES} PARENT_SCOPE)
#
# CONFIGURE_DEPENDS makes CMake re-check the folder on every build, so a
# developer who adds vector_math/vm_products.cpp only has to rebuild - no
# CMakeLists.txt edit, no merge conflicts between section owners.
file(GLOB_RECURSE NC_NUMPY_SOURCES CONFIGURE_DEPENDS
     "${CMAKE_CURRENT_LIST_DIR}/*.cpp")
