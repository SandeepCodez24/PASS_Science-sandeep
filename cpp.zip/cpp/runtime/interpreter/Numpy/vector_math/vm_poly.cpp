// Vector Math - convolution and polynomials.
//
// A polynomial is a row vector of coefficients, highest power first:
// [2, -3, 1] is 2x^2 - 3x + 1 (the NumPy / MATLAB convention).
#include "vm_common.h"

#include <cmath>
#include <iostream>
#include <sstream>

#include "../../core/elementwise.h"
#include "../../core/output.h"
#include "../../ops/matrix/nd_array.h"
#include "../numpy_poly1d.h"

namespace nc {
namespace numpy {
namespace vm {

namespace {

using Cplx = std::complex<double>;

// Leading zero coefficients removed (keeping at least one).
std::vector<double> trimLeading(const std::vector<double> &p) {
  size_t k = 0;
  while (k + 1 < p.size() && p[k] == 0.0)
    k++;
  return std::vector<double>(p.begin() + static_cast<std::ptrdiff_t>(k), p.end());
}

std::vector<double> convolveFull(const std::vector<double> &a, const std::vector<double> &b) {
  if (a.empty() || b.empty())
    return {};
  std::vector<double> r(a.size() + b.size() - 1, 0.0);
  for (size_t i = 0; i < a.size(); i++)
    for (size_t j = 0; j < b.size(); j++)
      r[i + j] += a[i] * b[j];
  return r;
}

// p1 + sign*p2, aligned at the constant term.
std::vector<double> addPoly(const std::vector<double> &p1, const std::vector<double> &p2,
                            double sign) {
  const size_t n = std::max(p1.size(), p2.size());
  std::vector<double> r(n, 0.0);
  for (size_t k = 0; k < p1.size(); k++)
    r[n - p1.size() + k] += p1[k];
  for (size_t k = 0; k < p2.size(); k++)
    r[n - p2.size() + k] += sign * p2[k];
  return trimLeading(r);
}

// "2x^2 - 3x + 1" - the readable form a poly1d prints.
std::string polyText(const std::vector<double> &p, const std::string &var = "x") {
  std::ostringstream ss;
  bool first = true;
  const size_t deg = p.empty() ? 0 : p.size() - 1;
  for (size_t k = 0; k < p.size(); k++) {
    const double c = p[k];
    const size_t power = deg - k;
    if (c == 0.0 && !(p.size() == 1))
      continue;
    const double mag = std::fabs(c);
    if (first)
      ss << (c < 0 ? "-" : "");
    else
      ss << (c < 0 ? " - " : " + ");
    first = false;
    if (mag != 1.0 || power == 0)
      ss << formatNumber(mag);
    if (power >= 1)
      ss << var;
    if (power >= 2)
      ss << "^" << power;
  }
  if (first)
    ss << "0";
  return ss.str();
}

Value rowOrNumber(const std::vector<double> &v) {
  if (v.size() == 1)
    return Value(v[0]);
  return rowVector(v);
}

// np.roots: the roots of p (highest power first), as a column - complex
// where needed; an empty matrix for a constant.
Value rootsColumn(std::vector<double> p) {
          p = trimLeading(p);
  // Trailing zero coefficients are roots at 0.
  size_t zeros = 0;
  while (p.size() > 1 && p.back() == 0.0) {
    p.pop_back();
    zeros++;
  }
  const size_t deg = p.empty() ? 0 : p.size() - 1;
  std::vector<Cplx> r;
  if (deg >= 1 && p[0] != 0.0) {
    MatrixXd companion = MatrixXd::Zero(static_cast<Eigen::Index>(deg),
                                        static_cast<Eigen::Index>(deg));
    for (size_t j = 0; j < deg; j++)
      companion(0, static_cast<Eigen::Index>(j)) = -p[j + 1] / p[0];
    for (size_t i = 1; i < deg; i++)
      companion(static_cast<Eigen::Index>(i), static_cast<Eigen::Index>(i - 1)) = 1.0;
    Eigen::EigenSolver<MatrixXd> es(companion, false);
    for (Eigen::Index k = 0; k < es.eigenvalues().size(); k++)
      r.push_back(es.eigenvalues()(k));
  }
  for (size_t k = 0; k < zeros; k++)
    r.push_back(Cplx(0.0, 0.0));
  if (r.empty())
    return Value(std::vector<std::vector<Value>>{});
  MatrixXcd col(static_cast<Eigen::Index>(r.size()), 1);
  for (size_t k = 0; k < r.size(); k++)
    col(static_cast<Eigen::Index>(k), 0) = r[k];
  return fromEigenC(col);
}

// np.poly on a list of roots: the monic polynomial with those roots. Real
// coefficients when the roots come in conjugate pairs.
Value polyFromRoots(const std::vector<Cplx> &rootsList) {
  std::vector<Cplx> c = {Cplx(1.0, 0.0)};
  for (const Cplx &z : rootsList) {
    std::vector<Cplx> next(c.size() + 1, Cplx(0.0, 0.0));
    for (size_t k = 0; k < c.size(); k++) {
      next[k] += c[k];
      next[k + 1] -= z * c[k];
    }
    c = next;
  }
  double maxImag = 0.0, maxAbs = 0.0;
  for (const Cplx &z : c) {
    maxImag = std::max(maxImag, std::fabs(z.imag()));
    maxAbs = std::max(maxAbs, std::abs(z));
  }
  if (maxImag <= 1e-10 * std::max(1.0, maxAbs)) {
    std::vector<double> real;
    for (const Cplx &z : c)
      real.push_back(z.real() + 0.0);
    return rowOrNumber(real);
  }
  std::vector<Value> row;
  for (const Cplx &z : c)
    row.push_back(complexScalar(z));
  return Value(std::vector<std::vector<Value>>{row});
}

// The real coefficient list of a coefficient Value (row, column or number).
std::vector<double> coeffList(const Value &c) {
  std::vector<double> out;
  if (c.isArray || c.isMatrix) {
    for (const Value &e : nd::rowMajorCells(c))
      out.push_back(e.number);
  } else {
    out.push_back(c.number);
  }
  return out;
}

// A poly1d object from real coefficients (leading zeros removed).
Value makePoly1d(const std::vector<double> &coeffsIn, const std::string &variable) {
  std::vector<double> c = trimLeading(coeffsIn);
  if (c.empty())
    c.push_back(0.0);
  Value p;
  p.isObject = true;
  p.classNameMut() = poly1dClassName();
  const Value row = rowOrNumber(c);
  auto &f = p.dictMut();
  f["coeffs"] = row; // NumPy's names: coeffs, c, coef, coefficients
  f["c"] = row;
  f["coef"] = row;
  f["coefficients"] = row;
  f["order"] = Value(static_cast<double>(c.size() - 1));
  f["roots"] = rootsColumn(c);
  f["r"] = f["roots"];
  f["variable"] = Value(variable);
  return p;
}

} // namespace

void registerPoly(Registry &reg) {
  addFn(reg, "convolve", 2, 3, "convolve(a, v[, mode])",
        "convolution of two vectors; mode \"full\" (default), \"same\" or \"valid\"",
        "np.convolve",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> a, v;
          std::string mode = "full";
          if (!argVector(args, 0, ctx, a) || !argVector(args, 1, ctx, v) ||
              (args.size() > 2 && !argText(args, 2, ctx, mode)))
            return Value(0.0);
          if (a.empty() || v.empty()) {
            ctx.fail("needs two non-empty vectors");
            return Value(0.0);
          }
          std::vector<double> full = convolveFull(a, v);
          const size_t n = a.size(), m = v.size();
          if (mode == "full")
            return rowOrNumber(full);
          if (mode == "same") {
            const size_t len = std::max(n, m);
            const size_t start = (std::min(n, m) - 1) / 2;
            return rowOrNumber(std::vector<double>(full.begin() + static_cast<std::ptrdiff_t>(start),
                                                   full.begin() + static_cast<std::ptrdiff_t>(start + len)));
          }
          if (mode == "valid") {
            const size_t len = std::max(n, m) - std::min(n, m) + 1;
            const size_t start = std::min(n, m) - 1;
            return rowOrNumber(std::vector<double>(full.begin() + static_cast<std::ptrdiff_t>(start),
                                                   full.begin() + static_cast<std::ptrdiff_t>(start + len)));
          }
          ctx.fail("mode must be \"full\", \"same\" or \"valid\", got \"" + mode + "\"");
          return Value(0.0);
        });

  addFn(reg, "polyfit", 3, 3, "polyfit(x, y, deg)",
        "least-squares polynomial of degree deg through the points (x, y), highest power first",
        "np.polyfit",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> x, y;
          long long deg = 0;
          if (!argVector(args, 0, ctx, x) || !argVector(args, 1, ctx, y) ||
              !argNonNegativeInt(args, 2, ctx, deg))
            return Value(0.0);
          if (x.size() != y.size() || x.empty()) {
            ctx.fail("x and y must be non-empty and the same length, got " +
                     std::to_string(x.size()) + " and " + std::to_string(y.size()));
            return Value(0.0);
          }
          const Eigen::Index n = static_cast<Eigen::Index>(x.size());
          const Eigen::Index cols = static_cast<Eigen::Index>(deg) + 1;
          MatrixXd V(n, cols);
          for (Eigen::Index i = 0; i < n; i++) {
            double pw = 1.0;
            for (Eigen::Index j = cols - 1; j >= 0; j--) {
              V(i, j) = pw;
              pw *= x[static_cast<size_t>(i)];
            }
          }
          Eigen::VectorXd yy = Eigen::Map<Eigen::VectorXd>(y.data(), n);
          Eigen::VectorXd c = V.completeOrthogonalDecomposition().solve(yy);
          return rowVector(std::vector<double>(c.data(), c.data() + c.size()));
        });

  addFn(reg, "polyval", 2, 2, "polyval(p, x)",
        "value of polynomial p at x - every element of x when x is a vector or matrix",
        "np.polyval",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> p;
          if (!argVector(args, 0, ctx, p))
            return Value(0.0);
          return map1(args, 1, ctx, [p](double x) {
            double acc = 0.0;
            for (double c : p)
              acc = acc * x + c;
            return acc;
          });
        });

  // poly1d: a polynomial value - see Numpy/numpy_poly1d.h (R6).
  addFn(reg, "poly1d", 1, 3, "poly1d(c[, r[, variable]])",
        "a polynomial value from coefficients c (highest power first), or from roots c when "
        "r=true; P(x) evaluates it, P[k] is the coefficient of x^k",
        "np.poly1d",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          if (isPoly1d(args[0]) && args.size() == 1)
            return args[0];
          std::vector<double> c;
          if (!argVector(args, 0, ctx, c))
            return Value(0.0);
          bool fromRoots = false;
          if (args.size() > 1) {
            if (!args[1].isBool()) {
              ctx.fail("r must be true or false, got " + describe(args[1]));
              return Value(0.0);
            }
            fromRoots = args[1].number != 0.0;
          }
          std::string variable = "x";
          if (args.size() > 2) {
            if (!argText(args, 2, ctx, variable))
              return Value(0.0);
            if (variable.empty()) {
              ctx.fail("variable must be a non-empty text, e.g. \"t\"");
              return Value(0.0);
            }
          }
          if (fromRoots) {
            std::vector<Cplx> r(c.begin(), c.end());
            const Value made = polyFromRoots(r);
            return makePoly1d(coeffList(made), variable);
          }
          if (c.empty()) {
            ctx.fail("needs at least one coefficient");
            return Value(0.0);
          }
          return makePoly1d(c, variable);
        });

  addFn(reg, "roots", 1, 1, "roots(p)",
        "roots of polynomial p (highest power first), as a column - complex where needed",
        "np.roots",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> p;
          if (!argVector(args, 0, ctx, p))
            return Value(0.0);
          return rootsColumn(p);
        });

  addFn(reg, "poly", 1, 1, "poly(r)",
        "polynomial with roots r (a vector), or the characteristic polynomial of a square matrix",
        "np.poly",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd m;
          if (!argMatrixC(args, 0, ctx, m))
            return Value(0.0);
          std::vector<Cplx> rootsList;
          if (m.rows() > 1 && m.cols() > 1) {
            if (m.rows() != m.cols()) {
              ctx.fail("needs a vector of roots or a square matrix, got " +
                       std::to_string(m.rows()) + "x" + std::to_string(m.cols()));
              return Value(0.0);
            }
            Eigen::ComplexEigenSolver<MatrixXcd> es(m, false);
            for (Eigen::Index k = 0; k < es.eigenvalues().size(); k++)
              rootsList.push_back(es.eigenvalues()(k));
          } else {
            for (Eigen::Index k = 0; k < m.size(); k++)
              rootsList.push_back(m(k));
          }
          return polyFromRoots(rootsList);
        },
        true);

  addFn(reg, "polyadd", 2, 2, "polyadd(p1, p2)", "sum of two polynomials", "np.polyadd",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> a, b;
          if (!argVector(args, 0, ctx, a) || !argVector(args, 1, ctx, b))
            return Value(0.0);
          return rowOrNumber(addPoly(a, b, 1.0));
        });
  addFn(reg, "polysub", 2, 2, "polysub(p1, p2)", "difference p1 - p2 of two polynomials",
        "np.polysub", [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> a, b;
          if (!argVector(args, 0, ctx, a) || !argVector(args, 1, ctx, b))
            return Value(0.0);
          return rowOrNumber(addPoly(a, b, -1.0));
        });
  addFn(reg, "polymul", 2, 2, "polymul(p1, p2)", "product of two polynomials", "np.polymul",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> a, b;
          if (!argVector(args, 0, ctx, a) || !argVector(args, 1, ctx, b))
            return Value(0.0);
          return rowOrNumber(trimLeading(convolveFull(a, b)));
        });
  addMulti(reg, "polydiv", 2, 2, 2, "[q, r] = polydiv(p1, p2)",
           "polynomial division p1 / p2: quotient q and remainder r; q = polydiv(p1, p2) gives q",
           "np.polydiv",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             std::vector<double> num, den;
             if (!argVector(args, 0, ctx, num) || !argVector(args, 1, ctx, den))
               return;
             num = trimLeading(num);
             den = trimLeading(den);
             if (den.empty() || den[0] == 0.0) {
               ctx.fail("cannot divide by the zero polynomial");
               return;
             }
             std::vector<double> rem = num, q;
             if (num.size() >= den.size()) {
               q.assign(num.size() - den.size() + 1, 0.0);
               for (size_t k = 0; k < q.size(); k++) {
                 const double coef = rem[k] / den[0];
                 q[k] = coef;
                 for (size_t j = 0; j < den.size(); j++)
                   rem[k + j] -= coef * den[j];
               }
               rem.erase(rem.begin(), rem.begin() + static_cast<std::ptrdiff_t>(q.size()));
               if (rem.empty())
                 rem.push_back(0.0);
             } else {
               q = {0.0};
             }
             out.push_back(rowOrNumber(q));
             if (nout > 1)
               out.push_back(rowOrNumber(trimLeading(rem)));
           });
  addFn(reg, "polyder", 1, 2, "polyder(p[, m])", "m-th derivative of polynomial p (m = 1 default)",
        "np.polyder", [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<double> p;
          long long m = 1;
          if (!argVector(args, 0, ctx, p) || (args.size() > 1 && !argNonNegativeInt(args, 1, ctx, m)))
            return Value(0.0);
          p = trimLeading(p);
          for (long long t = 0; t < m; t++) {
            if (p.size() <= 1) {
              p = {0.0};
              break;
            }
            std::vector<double> d(p.size() - 1);
            const size_t deg = p.size() - 1;
            for (size_t k = 0; k < d.size(); k++)
              d[k] = p[k] * static_cast<double>(deg - k);
            p = d;
          }
          return rowOrNumber(p);
        });
}

} // namespace vm

/* ---- poly1d values (numpy_poly1d.h) ---------------------------------------- */

Value poly1dCoefficients(const Value &p) {
  auto it = p.dict().find("coeffs");
  return it != p.dict().end() ? it->second : Value(0.0);
}

bool poly1dCall(const Value &p, const Value &x, Value &out, std::string &err) {
  if (isPoly1d(x)) {
    err = "a poly1d of a poly1d (composition) is not supported yet - give numbers";
    return false;
  }
  if (x.isText || x.isDict || x.isObject || x.isFunctionRef) {
    err = "a poly1d takes a number, vector or matrix, not " + vm::describe(x);
    return false;
  }
  const std::vector<double> c = vm::coeffList(poly1dCoefficients(p));
  g_lastElementwiseOk = true;
  if (x.hasComplex()) {
    out = mapElementwiseC(x, [c](Cplx z) {
      Cplx acc(0.0, 0.0);
      for (double k : c)
        acc = acc * z + k;
      return acc;
    });
  } else {
    out = mapElementwise(x, [c](double v) {
      double acc = 0.0;
      for (double k : c)
        acc = acc * v + k;
      return acc;
    });
  }
  if (!g_lastElementwiseOk) {
    err = "a poly1d takes a number, vector or matrix of numbers";
    return false;
  }
  return true;
}

bool poly1dCoefficientOf(const Value &p, const Value &k, Value &out, std::string &err) {
  if (k.isText || k.isArray || k.isMatrix || k.isDict || k.isObject || k.isFunctionRef ||
      k.isComplex || k.number != std::floor(k.number)) {
    const bool plain = !k.isText && !k.isArray && !k.isMatrix && !k.isDict && !k.isObject &&
                       !k.isFunctionRef && !k.isComplex;
    err = "P[k] takes one whole number k (the power of x), got " +
          (plain ? formatNumber(k.number) : vm::describe(k));
    return false;
  }
  const std::vector<double> c = vm::coeffList(poly1dCoefficients(p));
  const double kk = k.number;
  const double order = static_cast<double>(c.size() - 1);
  if (kk < 0 || kk > order) {
    out = Value(0.0);
    return true;
  }
  out = Value(c[static_cast<size_t>(order - kk)]);
  return true;
}

std::string poly1dText(const Value &p) {
  auto it = p.dict().find("variable");
  const std::string var = (it != p.dict().end() && it->second.isText) ? it->second.text() : "x";
  return vm::polyText(vm::coeffList(poly1dCoefficients(p)), var);
}
} // namespace numpy
} // namespace nc
