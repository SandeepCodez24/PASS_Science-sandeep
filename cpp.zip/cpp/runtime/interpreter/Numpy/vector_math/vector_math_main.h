// Section 9 of 11 - Vector Math (136 planned entries).
// Only numpy_main.cpp includes this header.
#ifndef NC_NUMPY_VECTOR_MATH_MAIN_H
#define NC_NUMPY_VECTOR_MATH_MAIN_H

#include "../numpy_registry.h"

namespace nc {
namespace numpy {

// Adds every Vector Math function to the registry. Called once by
// nc::numpy::initialize() (numpy_main.cpp).
void registerVectorMath(Registry &reg);

// The expN / logaddexpN families: exp2(x), exp10(x), logaddexp2(a, b), ...
// (any whole-number base). Sets `matched` when `name` belongs to one.
Value callVectorMathFamily(const std::string &name, const std::vector<Value> &args,
                           CallContext &ctx, bool &matched);

} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_VECTOR_MATH_MAIN_H
