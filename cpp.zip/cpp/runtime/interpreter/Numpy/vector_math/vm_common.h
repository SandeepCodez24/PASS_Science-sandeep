// Shared helpers for the Vector Math section (vector_math/vm_*.cpp).
//
// Conventions every function in this section follows:
//   - A single number, a 1-D array (from space(), ...) and a matrix are all
//     accepted wherever "a value" is expected. A 1-D array counts as a ROW
//     vector (1 x N).
//   - Element-wise functions return the shape they were given, and pair two
//     arguments of the same shape, or a single value with any shape.
//   - Vector results are 1 x N row matrices; matrix results are matrices.
//   - Problems are reported with ctx.fail("...") - one "Error: <name>: ..."
//     line - and the statement stops, like every NC runtime error.
#ifndef NC_NUMPY_VECTOR_MATH_VM_COMMON_H
#define NC_NUMPY_VECTOR_MATH_VM_COMMON_H

#include <Eigen/Dense>
#include <complex>
#include <functional>
#include <string>
#include <vector>

#include "../../core/elementwise.h"
#include "../../ops/matrix/matrix.h"
#include "../../ops/matrix/matrix_index.h"
#include "../numpy_common.h"

namespace nc {
namespace numpy {
namespace vm {

using Eigen::MatrixXcd;
using Eigen::MatrixXd;

// Full SVD (U and V computed). Eigen 5 takes the options as a template
// argument (the runtime form is deprecated there); Eigen 3.4 only has the
// runtime form. NC_FULL_SVD(MatrixType, name, matrix) declares `name`.
#if EIGEN_VERSION_AT_LEAST(3, 4, 90)
#define NC_FULL_SVD(MType, var, mat)                                                           \
  Eigen::JacobiSVD<MType, Eigen::ComputeFullU | Eigen::ComputeFullV> var(mat)
#else
#define NC_FULL_SVD(MType, var, mat)                                                           \
  Eigen::JacobiSVD<MType> var(mat, Eigen::ComputeFullU | Eigen::ComputeFullV)
#endif

/* ---- describing values (for error messages) ---- */

inline std::string describe(const Value &v) {
  if (v.isMatrix)
    return "a " + matShapeText(v) + " matrix";
  if (v.isArray)
    return "an array of length " + std::to_string(v.length());
  if (v.isText)
    return "text";
  if (v.isDict)
    return "a dict";
  if (v.isObject)
    return "an object";
  if (v.isFunctionRef)
    return "a function reference";
  if (v.isComplex)
    return "a complex number";
  return "a number";
}

inline std::string shapeText(const MatrixXd &m) {
  return std::to_string(m.rows()) + "x" + std::to_string(m.cols());
}

/* ---- reading arguments ---- */

// Number, array (as a row) or matrix of real numbers -> Eigen matrix.
inline bool argMatrix(const std::vector<Value> &args, size_t i, CallContext &ctx, MatrixXd &out) {
  if (i >= args.size()) {
    ctx.fail("the " + ordinal(i) + " argument is missing");
    return false;
  }
  const Value &v = args[i];
  if (v.hasComplex()) {
    ctx.fail("the " + ordinal(i) + " argument must be real, got complex values");
    return false;
  }
  if (isPlainNumber(v)) {
    out = MatrixXd::Constant(1, 1, v.number);
    return true;
  }
  if (v.isArray) {
    out.resize(1, static_cast<Eigen::Index>(v.length()));
    for (size_t k = 0; k < v.length(); k++) {
      Value e = v.at(k);
      if (!isPlainNumber(e)) {
        ctx.fail("the " + ordinal(i) + " argument must contain only numbers");
        return false;
      }
      out(0, static_cast<Eigen::Index>(k)) = e.number;
    }
    return true;
  }
  if (v.isMatrix) {
    for (size_t r = 0; r < v.rows(); r++)
      if (v.rowLength(r) != v.cols()) {
        ctx.fail("the " + ordinal(i) + " argument has rows of different lengths");
        return false;
      }
    if (!v.isPacked()) {
      for (size_t r = 0; r < v.rows(); r++)
        for (size_t c = 0; c < v.cols(); c++)
          if (!isPlainNumber(v.at(r, c))) {
            ctx.fail("the " + ordinal(i) + " argument must contain only numbers");
            return false;
          }
    }
    out = toEigenMat(v);
    if (v.rows() == 0)
      out.resize(0, 0);
    return true;
  }
  ctx.fail("the " + ordinal(i) + " argument must be a number, vector or matrix, not " +
           describe(v));
  return false;
}

// Real or complex number / array / matrix -> complex Eigen matrix.
inline bool argMatrixC(const std::vector<Value> &args, size_t i, CallContext &ctx,
                       MatrixXcd &out) {
  if (i >= args.size()) {
    ctx.fail("the " + ordinal(i) + " argument is missing");
    return false;
  }
  const Value &v = args[i];
  if (!v.hasComplex()) {
    MatrixXd m;
    if (!argMatrix(args, i, ctx, m))
      return false;
    out = m.cast<std::complex<double>>();
    return true;
  }
  if (!v.isArray && !v.isMatrix) {
    out = MatrixXcd::Constant(1, 1, std::complex<double>(v.number, v.imag));
    return true;
  }
  const Value asMatrix = v.isArray ? matArrayAsMatrix(v, false) : v;
  out = toEigenCMat(asMatrix);
  if (out.size() == 0 && asMatrix.rows() != 0) {
    ctx.fail("the " + ordinal(i) + " argument must be a rectangular matrix of numbers");
    return false;
  }
  return true;
}

inline bool argSquare(const std::vector<Value> &args, size_t i, CallContext &ctx, MatrixXd &out) {
  if (!argMatrix(args, i, ctx, out))
    return false;
  if (out.rows() == 0 || out.rows() != out.cols()) {
    ctx.fail("needs a square matrix, got " + shapeText(out));
    return false;
  }
  return true;
}

// A vector: a number, an array, or a 1 x N / N x 1 matrix -> its elements.
inline bool argVector(const std::vector<Value> &args, size_t i, CallContext &ctx,
                      std::vector<double> &out) {
  MatrixXd m;
  if (!argMatrix(args, i, ctx, m))
    return false;
  if (m.rows() > 1 && m.cols() > 1) {
    ctx.fail("the " + ordinal(i) + " argument must be a vector (1xN or Nx1), got a " +
             shapeText(m) + " matrix");
    return false;
  }
  out.assign(m.data(), m.data() + m.size());
  return true;
}

inline bool argWhole(const std::vector<Value> &args, size_t i, CallContext &ctx, long long &out) {
  return argInt(args, i, ctx, out);
}

/* ---- building results ---- */

inline Value fromEigen(const MatrixXd &m) {
  if (m.rows() == 0 || m.cols() == 0)
    return Value(std::vector<std::vector<Value>>{});
  return toValue(m);
}

inline Value fromEigenC(const MatrixXcd &m) {
  if (m.rows() == 0 || m.cols() == 0)
    return Value(std::vector<std::vector<Value>>{});
  return toValueC(m);
}

inline Value rowVector(const std::vector<double> &v) {
  if (v.empty())
    return Value(std::vector<std::vector<Value>>{});
  return Value::packedMatrix(v.data(), 1, v.size());
}

inline Value columnVector(const std::vector<double> &v) {
  if (v.empty())
    return Value(std::vector<std::vector<Value>>{});
  return Value::packedMatrix(v.data(), v.size(), 1);
}

inline Value complexScalar(std::complex<double> z) {
  return z.imag() == 0.0 ? Value(z.real() + 0.0) : Value::complexNumber(z.real() + 0.0, z.imag());
}

// A 1x1 result is returned as a plain number.
inline Value scalarIfSingle(const Value &v) {
  if (v.isMatrix && v.rows() == 1 && v.cols() == 1)
    return v.at(0, 0);
  return v;
}

/* ---- element-wise drivers ---- */

// Rejects text/dict/object arguments before an element-wise helper sees them.
inline bool checkNumeric(const std::vector<Value> &args, size_t i, CallContext &ctx) {
  const Value &v = args[i];
  if (v.isText || v.isDict || v.isObject || v.isFunctionRef) {
    ctx.fail("the " + ordinal(i) + " argument must be a number, vector or matrix, not " +
             describe(v));
    return false;
  }
  return true;
}

// fn on every element of args[i] (shape kept).
inline Value map1(const std::vector<Value> &args, size_t i, CallContext &ctx,
                  const std::function<double(double)> &fn) {
  if (!checkNumeric(args, i, ctx))
    return Value(0.0);
  if (args[i].hasComplex()) {
    ctx.fail("does not support complex numbers");
    return Value(0.0);
  }
  Value r = mapElementwise(args[i], fn);
  if (!g_lastElementwiseOk)
    ctx.markFailed();
  return r;
}

// fn on element pairs of args[i] and args[j]: same shape, or one single value.
// A 1-D array meeting a matrix takes part as a row (or column).
inline Value zip2(const std::vector<Value> &args, size_t i, size_t j, CallContext &ctx,
                  const std::function<double(double, double)> &fn) {
  if (!checkNumeric(args, i, ctx) || !checkNumeric(args, j, ctx))
    return Value(0.0);
  if (args[i].hasComplex() || args[j].hasComplex()) {
    ctx.fail("does not support complex numbers");
    return Value(0.0);
  }
  Value a = args[i], b = args[j];
  if (a.isArray && b.isMatrix)
    a = matArrayAsMatrix(a, b.rows() > 1 && b.cols() == 1);
  else if (b.isArray && a.isMatrix)
    b = matArrayAsMatrix(b, a.rows() > 1 && a.cols() == 1);
  if (a.isMatrix && b.isMatrix &&
      (a.rows() != b.rows() || (a.rows() != 0 && a.cols() != b.cols()))) {
    ctx.fail("cannot pair " + describe(a) + " with " + describe(b) +
             " element by element - both must have the same size, or one must be a single "
             "value");
    return Value(0.0);
  }
  Value r = zipElementwise(a, b, fn);
  if (!g_lastElementwiseOk)
    ctx.markFailed();
  return r;
}

/* ---- registration shorthands ---- */

inline void addFn(Registry &reg, const char *name, int minArgs, int maxArgs, const char *signature,
                  const char *summary, const char *numpyName, Impl impl,
                  bool acceptsComplex = false) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::VectorMath;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = signature;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.impl = std::move(impl);
  spec.acceptsComplex = acceptsComplex;
  reg.add(std::move(spec));
}

inline void addMulti(Registry &reg, const char *name, int minArgs, int maxArgs, int maxOutputs,
                     const char *signature, const char *summary, const char *numpyName,
                     MultiImpl impl, bool acceptsComplex = false) {
  FunctionSpec spec;
  spec.name = name;
  spec.section = Section::VectorMath;
  spec.minArgs = minArgs;
  spec.maxArgs = maxArgs;
  spec.signature = signature;
  spec.summary = summary;
  spec.numpyName = numpyName;
  spec.multiImpl = std::move(impl);
  spec.maxOutputs = maxOutputs;
  spec.acceptsComplex = acceptsComplex;
  reg.add(std::move(spec));
}

/* ---- the groups (one file each) ---- */

void registerUfuncs(Registry &reg);   // vm_ufuncs.cpp   element-wise math
void registerProducts(Registry &reg); // vm_products.cpp dot, cross, outer, einsum, kron, ...
void registerLinalg(Registry &reg);   // vm_linalg.cpp   norms, solve, eig, svd, qr, ...
void registerPoly(Registry &reg);     // vm_poly.cpp     convolve and polynomials

// vm_ufuncs.cpp: expN(x) and logaddexpN(a, b) for any whole-number base N.
Value expFamily(double base, const std::vector<Value> &args, CallContext &ctx);
Value logaddexpFamily(double base, const std::vector<Value> &args, CallContext &ctx);

} // namespace vm
} // namespace numpy
} // namespace nc

#endif // NC_NUMPY_VECTOR_MATH_VM_COMMON_H
