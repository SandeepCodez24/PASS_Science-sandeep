// Vector Math - element-wise functions (NumPy "ufuncs").
//
// Every function here works on a single number, a vector or a matrix and
// keeps the shape; two-argument ones pair elements of equal shapes, or a
// single value with every element.
#include "vm_common.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>

#include "../../builtins/builtins.h"
#include "../../ops/complex/complex_builtin.h"

namespace nc {
namespace numpy {
namespace vm {

namespace {

constexpr double kPi = 3.14159265358979323846;

/* ---- results of true/false per element ---- */

// fn(x) per element as true/false, keeping the shape of `v`.
Value mapToBool(const Value &v, const std::function<bool(double)> &fn) {
  if (v.isMatrix) {
    std::vector<std::vector<Value>> g(v.rows());
    for (size_t r = 0; r < v.rows(); r++)
      for (size_t c = 0; c < v.rowLength(r); c++)
        g[r].push_back(Value::boolean(fn(v.numAt(r, c))));
    return Value(std::move(g));
  }
  if (v.isArray) {
    std::vector<Value> out;
    for (size_t i = 0; i < v.length(); i++)
      out.push_back(Value::boolean(fn(v.numAt(i))));
    return Value(std::move(out));
  }
  return Value::boolean(fn(v.number));
}

// Two matrices brought to one shape: equal sizes, or a 1x1 against anything.
bool broadcastPair(MatrixXd &a, MatrixXd &b, CallContext &ctx) {
  if (a.rows() == b.rows() && a.cols() == b.cols())
    return true;
  if (a.size() == 1) {
    a = MatrixXd::Constant(b.rows(), b.cols(), a(0, 0));
    return true;
  }
  if (b.size() == 1) {
    b = MatrixXd::Constant(a.rows(), a.cols(), b(0, 0));
    return true;
  }
  ctx.fail("the two arguments must have the same size, or one must be a single value (got " +
           shapeText(a) + " and " + shapeText(b) + ")");
  return false;
}

// A matrix of true/false values; a single plain-number pair gives one bool.
Value boolResult(const Eigen::Matrix<bool, Eigen::Dynamic, Eigen::Dynamic> &m, bool scalarInputs) {
  if (scalarInputs && m.size() == 1)
    return Value::boolean(m(0, 0));
  std::vector<std::vector<Value>> g(static_cast<size_t>(m.rows()));
  for (Eigen::Index r = 0; r < m.rows(); r++)
    for (Eigen::Index c = 0; c < m.cols(); c++)
      g[static_cast<size_t>(r)].push_back(Value::boolean(m(r, c)));
  return Value(std::move(g));
}

/* ---- whole-number helpers (gcd / lcm) ---- */

bool wholeOf(double x, long long &out) {
  if (!std::isfinite(x) || x != std::floor(x) || std::fabs(x) > 9007199254740992.0)
    return false;
  out = static_cast<long long>(x);
  return true;
}

long long gcdLL(long long a, long long b) { return std::gcd(a < 0 ? -a : a, b < 0 ? -b : b); }

long long lcmLL(long long a, long long b) {
  if (a == 0 || b == 0)
    return 0;
  return std::lcm(a < 0 ? -a : a, b < 0 ? -b : b);
}

// gcd / lcm: one argument reduces over all its elements; two pair elements.
Value gcdLcm(const std::vector<Value> &args, CallContext &ctx, bool isGcd) {
  const char *what = isGcd ? "gcd" : "lcm";
  bool bad = false;
  auto pairFn = [&](double x, double y) {
    long long a = 0, b = 0;
    if (!wholeOf(x, a) || !wholeOf(y, b)) {
      bad = true;
      return 0.0;
    }
    return static_cast<double>(isGcd ? gcdLL(a, b) : lcmLL(a, b));
  };
  if (args.size() == 2) {
    Value r = zip2(args, 0, 1, ctx, pairFn);
    if (bad)
      ctx.fail(std::string(what) + " works on whole numbers only");
    return r;
  }
  std::vector<double> values;
  if (!argNumbers(args, 0, ctx, values))
    return Value(0.0);
  if (values.empty())
    return Value(isGcd ? 0.0 : 1.0);
  double acc = values[0];
  long long first = 0;
  if (!wholeOf(acc, first)) {
    ctx.fail(std::string(what) + " works on whole numbers only");
    return Value(0.0);
  }
  acc = std::fabs(acc);
  for (size_t k = 1; k < values.size(); k++)
    acc = pairFn(acc, values[k]);
  if (bad) {
    ctx.fail(std::string(what) + " works on whole numbers only");
    return Value(0.0);
  }
  return Value(acc);
}

/* ---- np.unwrap along each row (or down a column vector) ---- */

std::vector<double> unwrapLine(const std::vector<double> &p, double discont) {
  std::vector<double> out(p);
  double correction = 0.0;
  for (size_t k = 1; k < p.size(); k++) {
    const double d = p[k] - p[k - 1];
    double dd = std::fmod(d + kPi, 2.0 * kPi);
    if (dd < 0)
      dd += 2.0 * kPi;
    dd -= kPi;
    if (dd == -kPi && d > 0)
      dd = kPi;
    double phCorrect = dd - d;
    if (std::fabs(d) < discont)
      phCorrect = 0.0;
    correction += phCorrect;
    out[k] = p[k] + correction;
  }
  return out;
}

double logaddexpBase(double x, double y, double base) {
  // log_b(b^x + b^y), computed without overflow.
  if (x == y)
    return x + std::log(2.0) / std::log(base);
  const double m = std::max(x, y);
  if (std::isinf(m) && m < 0)
    return m; // both -inf
  return m + std::log1p(std::pow(base, -std::fabs(x - y))) / std::log(base);
}

} // namespace

/* ---- families: expN(x), logaddexpN(a, b) ---- */

Value expFamily(double base, const std::vector<Value> &args, CallContext &ctx) {
  if (args.size() != 1) {
    ctx.fail("expects 1 argument, got " + std::to_string(args.size()) + " - usage: exp" +
             std::to_string(static_cast<long long>(base)) + "(x)");
    return Value(0.0);
  }
  return map1(args, 0, ctx, [base](double x) { return std::pow(base, x); });
}

Value logaddexpFamily(double base, const std::vector<Value> &args, CallContext &ctx) {
  if (args.size() != 2) {
    ctx.fail("expects 2 arguments, got " + std::to_string(args.size()) + " - usage: logaddexp" +
             std::to_string(static_cast<long long>(base)) + "(a, b)");
    return Value(0.0);
  }
  if (base <= 1.0) {
    ctx.fail("the base must be 2 or more");
    return Value(0.0);
  }
  return zip2(args, 0, 1, ctx, [base](double x, double y) { return logaddexpBase(x, y, base); });
}

/* ---- registration ---- */

void registerUfuncs(Registry &reg) {
  // ---- maximum / minimum that skip NaN ----------------------------------
  addFn(reg, "fmax", 2, 2, "fmax(A, B)", "element-wise larger value, ignoring NaN", "np.fmax",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double x, double y) { return std::fmax(x, y); });
        });
  addFn(reg, "fmin", 2, 2, "fmin(A, B)", "element-wise smaller value, ignoring NaN", "np.fmin",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double x, double y) { return std::fmin(x, y); });
        });

  // ---- comparisons of whole values ----------------------------------------
  addFn(reg, "equal", 2, 2, "equal(A, B)", "true if A and B have the same size and elements",
        "np.array_equal",
        [](const std::vector<Value> &a, CallContext &ctx) -> Value {
          MatrixXcd x, y;
          if (!argMatrixC(a, 0, ctx, x) || !argMatrixC(a, 1, ctx, y))
            return Value(0.0);
          return Value::boolean(x.rows() == y.rows() && x.cols() == y.cols() && x == y);
        },
        true);
  addFn(reg, "equiv", 2, 2, "equiv(A, B)",
        "true if A and B are equal once a single value / row / column is repeated to match",
        "np.array_equiv",
        [](const std::vector<Value> &a, CallContext &ctx) -> Value {
          MatrixXd x, y;
          if (!argMatrix(a, 0, ctx, x) || !argMatrix(a, 1, ctx, y))
            return Value(0.0);
          auto fits = [](const MatrixXd &small, const MatrixXd &big) {
            return (small.rows() == big.rows() || small.rows() == 1) &&
                   (small.cols() == big.cols() || small.cols() == 1);
          };
          const MatrixXd &big = (x.size() >= y.size()) ? x : y;
          const MatrixXd &small = (x.size() >= y.size()) ? y : x;
          if (!fits(small, big))
            return Value::boolean(false);
          for (Eigen::Index r = 0; r < big.rows(); r++)
            for (Eigen::Index c = 0; c < big.cols(); c++)
              if (big(r, c) != small(small.rows() == 1 ? 0 : r, small.cols() == 1 ? 0 : c))
                return Value::boolean(false);
          return Value::boolean(true);
        });
  // isclose / allclose: |A - B| <= atol + rtol*|B| per element pair.
  // NC's defaults (team decision, 2026-10-27): atol = 0.1, rtol = 0, and the
  // third plain value is atol - isclose(A, B, 0.2) means "within 0.2".
  // (NumPy: rtol=1e-05, atol=1e-08, rtol third.) The defaults themselves are
  // filled in from the parameter line in vector_math_main.cpp, so args[2] /
  // args[3] are always present here.
  auto closeTest = [](double x, double y, double atol, double rtol) {
    return x == y || std::fabs(x - y) <= atol + rtol * std::fabs(y);
  };
  addFn(reg, "isclose", 2, 4, "isclose(A, B[, atol, rtol])",
        "element-wise true where |A-B| <= atol + rtol*|B| (atol 0.1, rtol 0 by default)",
        "np.isclose",
        [closeTest](const std::vector<Value> &a, CallContext &ctx) -> Value {
          MatrixXd x, y;
          double atol = 0.1, rtol = 0.0;
          if (!argMatrix(a, 0, ctx, x) || !argMatrix(a, 1, ctx, y) ||
              (a.size() > 2 && !argNumber(a, 2, ctx, atol)) ||
              (a.size() > 3 && !argNumber(a, 3, ctx, rtol)) || !broadcastPair(x, y, ctx))
            return Value(0.0);
          if (atol < 0 || rtol < 0) {
            ctx.fail("atol and rtol must not be negative");
            return Value(0.0);
          }
          Eigen::Matrix<bool, Eigen::Dynamic, Eigen::Dynamic> m(x.rows(), x.cols());
          for (Eigen::Index k = 0; k < x.size(); k++)
            m(k) = closeTest(x(k), y(k), atol, rtol);
          return boolResult(m, isPlainNumber(a[0]) && isPlainNumber(a[1]));
        });
  addFn(reg, "allclose", 2, 4, "allclose(A, B[, atol, rtol])",
        "true if every element pair is close: |A-B| <= atol + rtol*|B| (atol 0.1, rtol 0 by "
        "default)",
        "np.allclose",
        [closeTest](const std::vector<Value> &a, CallContext &ctx) -> Value {
          MatrixXd x, y;
          double atol = 0.1, rtol = 0.0;
          if (!argMatrix(a, 0, ctx, x) || !argMatrix(a, 1, ctx, y) ||
              (a.size() > 2 && !argNumber(a, 2, ctx, atol)) ||
              (a.size() > 3 && !argNumber(a, 3, ctx, rtol)) || !broadcastPair(x, y, ctx))
            return Value(0.0);
          if (atol < 0 || rtol < 0) {
            ctx.fail("atol and rtol must not be negative");
            return Value(0.0);
          }
          for (Eigen::Index k = 0; k < x.size(); k++)
            if (!closeTest(x(k), y(k), atol, rtol))
              return Value::boolean(false);
          return Value::boolean(true);
        });

  // ---- exponentials and logarithms ----------------------------------------
  // exp2(x), exp10(x), ... and logaddexp2(a, b), ... are the name families
  // handled by callVectorMathFamily() (vector_math_main.cpp).
  addFn(reg, "log1p", 1, 1, "log1p(x)", "log(1 + x), accurate for tiny x", "np.log1p",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::log1p(x); });
        });
  addFn(reg, "logaddexp", 2, 2, "logaddexp(A, B)", "log(exp(A) + exp(B)) without overflow",
        "np.logaddexp",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx,
                      [](double x, double y) { return logaddexpBase(x, y, std::exp(1.0)); });
        });

  // ---- trigonometric helpers ------------------------------------------------
  addFn(reg, "inv_tan2", 2, 2, "inv_tan2(Y, X)",
        "four-quadrant inverse tangent of Y/X in radians, element-wise", "np.arctan2",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double y, double x) { return std::atan2(y, x); });
        });
  addFn(reg, "hypot", 2, 2, "hypot(A, B)", "sqrt(A^2 + B^2) element-wise, without overflow",
        "np.hypot", [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double x, double y) { return std::hypot(x, y); });
        });
  addFn(reg, "anglewrap", 1, 2, "anglewrap(theta[, discont])",
        "removes 2*pi jumps from a sequence of angles (along each row)", "np.unwrap",
        [](const std::vector<Value> &a, CallContext &ctx) -> Value {
          MatrixXd m;
          double discont = kPi;
          if (!argMatrix(a, 0, ctx, m) || (a.size() > 1 && !argNumber(a, 1, ctx, discont)))
            return Value(0.0);
          if (isPlainNumber(a[0]))
            return a[0];
          discont = std::max(discont, kPi);
          if (m.cols() == 1 && m.rows() > 1) { // a column vector unwraps downwards
            std::vector<double> line(m.data(), m.data() + m.size());
            line = unwrapLine(line, discont);
            return columnVector(line);
          }
          for (Eigen::Index r = 0; r < m.rows(); r++) {
            std::vector<double> line(static_cast<size_t>(m.cols()));
            for (Eigen::Index c = 0; c < m.cols(); c++)
              line[static_cast<size_t>(c)] = m(r, c);
            line = unwrapLine(line, discont);
            for (Eigen::Index c = 0; c < m.cols(); c++)
              m(r, c) = line[static_cast<size_t>(c)];
          }
          return fromEigen(m);
        });
  addFn(reg, "sinc", 1, 1, "sinc(x)", "sin(pi*x)/(pi*x), with sinc(0) = 1", "np.sinc",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) {
            if (x == 0.0)
              return 1.0;
            const double t = kPi * x;
            return std::sin(t) / t;
          });
        });

  // ---- rounding and sign ----------------------------------------------------
  addFn(reg, "fabs", 1, 1, "fabs(x)", "absolute value of real numbers, element-wise", "np.fabs",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::fabs(x); });
        });
  addFn(reg, "sign", 1, 1, "sign(x)", "-1, 0 or 1 by the sign of each element", "np.sign",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) {
            if (std::isnan(x))
              return x;
            return x > 0 ? 1.0 : (x < 0 ? -1.0 : 0.0);
          });
        });
  addFn(reg, "ceil", 1, 1, "ceil(x)", "rounds each element up to a whole number", "np.ceil",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::ceil(x) + 0.0; });
        });
  addFn(reg, "floor", 1, 1, "floor(x)", "rounds each element down to a whole number",
        "np.floor", [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::floor(x) + 0.0; });
        });
  addFn(reg, "rint", 1, 1, "rint(x)", "rounds each element to the nearest whole number (ties to even)",
        "np.rint", [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::nearbyint(x) + 0.0; });
        });
  addFn(reg, "fix", 1, 1, "fix(x)", "rounds each element toward zero", "np.fix",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::trunc(x) + 0.0; });
        });
  addFn(reg, "trunc", 1, 1, "trunc(x)", "drops the fractional part of each element", "np.trunc",
        [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) { return std::trunc(x) + 0.0; });
        });

  // ---- whole numbers --------------------------------------------------------
  addFn(reg, "gcd", 1, 2, "gcd(A[, B])",
        "greatest common divisor: of all elements of A, or of element pairs of A and B", "np.gcd",
        [](const std::vector<Value> &a, CallContext &ctx) { return gcdLcm(a, ctx, true); });
  addFn(reg, "lcm", 1, 2, "lcm(A[, B])",
        "least common multiple: of all elements of A, or of element pairs of A and B", "np.lcm",
        [](const std::vector<Value> &a, CallContext &ctx) { return gcdLcm(a, ctx, false); });

  // ---- step and sign manipulation -------------------------------------------
  addFn(reg, "heaviside", 2, 2, "heaviside(x, h0)", "step function: 0 below 0, h0 at 0, 1 above",
        "np.heaviside", [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double x, double h0) {
            if (std::isnan(x))
              return x;
            return x < 0 ? 0.0 : (x > 0 ? 1.0 : h0);
          });
        });
  addFn(reg, "copysign", 2, 2, "copysign(x, s)", "magnitude of x with the sign of s, element-wise",
        "np.copysign", [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double x, double s) { return std::copysign(x, s); });
        });
  addFn(reg, "signbit", 1, 1, "signbit(x)", "true where the element's sign bit is set (x < 0, -0)",
        "np.signbit", [](const std::vector<Value> &a, CallContext &ctx) -> Value {
          if (!checkNumeric(a, 0, ctx))
            return Value(0.0);
          return mapToBool(a[0], [](double x) { return std::signbit(x); });
        });
  addFn(reg, "nextafter", 2, 2, "nextafter(x, y)", "the next representable number after x towards y",
        "np.nextafter", [](const std::vector<Value> &a, CallContext &ctx) {
          return zip2(a, 0, 1, ctx, [](double x, double y) { return std::nextafter(x, y); });
        });
  addFn(reg, "spacing", 1, 1, "spacing(x)", "distance from x to the next representable number",
        "np.spacing", [](const std::vector<Value> &a, CallContext &ctx) {
          return map1(a, 0, ctx, [](double x) {
            if (!std::isfinite(x))
              return std::numeric_limits<double>::quiet_NaN();
            return std::signbit(x)
                       ? std::nextafter(x, -std::numeric_limits<double>::infinity()) - x
                       : std::nextafter(x, std::numeric_limits<double>::infinity()) - x;
          });
        });

  // ---- floating-point decomposition -----------------------------------------
  addMulti(reg, "frexp", 1, 1, 2, "[m, e] = frexp(x)",
           "splits x into mantissa m (0.5 <= |m| < 1) and exponent e with x = m*2^e", "np.frexp",
           [](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
             Value m = map1(a, 0, ctx, [](double x) {
               int e = 0;
               return std::frexp(x, &e);
             });
             if (!ctx.ok())
               return;
             out.push_back(m);
             if (nout > 1)
               out.push_back(map1(a, 0, ctx, [](double x) {
                 int e = 0;
                 std::frexp(x, &e);
                 return static_cast<double>(e);
               }));
           });
  addFn(reg, "ldexp", 2, 2, "ldexp(m, e)", "m * 2^e, element-wise (e whole numbers)", "np.ldexp",
        [](const std::vector<Value> &a, CallContext &ctx) {
          bool bad = false;
          Value r = zip2(a, 0, 1, ctx, [&bad](double m, double e) {
            if (!std::isfinite(e) || e != std::floor(e)) {
              bad = true;
              return 0.0;
            }
            return std::ldexp(m, static_cast<int>(std::max(-100000.0, std::min(100000.0, e))));
          });
          if (bad)
            ctx.fail("the exponent must be whole numbers");
          return r;
        });
  addMulti(reg, "modf", 1, 1, 2, "[frac, whole] = modf(x)",
           "splits each element into its fractional and whole parts", "np.modf",
           [](const std::vector<Value> &a, size_t nout, std::vector<Value> &out, CallContext &ctx) {
             out.push_back(map1(a, 0, ctx, [](double x) {
               double whole = 0.0;
               return std::modf(x, &whole);
             }));
             if (ctx.ok() && nout > 1)
               out.push_back(map1(a, 0, ctx, [](double x) {
                 double whole = 0.0;
                 std::modf(x, &whole);
                 return whole;
               }));
           });

  // ---- complex parts --------------------------------------------------------
  // real(x), conj(x) and angle(x) are existing builtins (ops/complex); img is
  // the NC name for np.imag (imag(x) also stays).
  addFn(reg, "img", 1, 1, "img(z)", "imaginary part of each element", "np.imag",
        [](const std::vector<Value> &a, CallContext &ctx) {
          g_lastBuiltinFound = true;
          Value r = complexBuiltin("imag", a);
          if (!g_lastBuiltinFound) {
            g_lastBuiltinFound = true;
            ctx.markFailed();
          }
          return r;
        },
        true);
}

} // namespace vm
} // namespace numpy
} // namespace nc
