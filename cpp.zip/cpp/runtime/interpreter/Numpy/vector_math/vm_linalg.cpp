// Vector Math - linear algebra: norms, determinants, solving, eigenvalues,
// decompositions.
//
// Functions with several results are called as [Q, R] = qr(A) (or the older
// (Q, R) = qr(A)); a plain x = f(A) gets the result listed first in its
// signature unless the summary says otherwise.
#include "vm_common.h"

#include "../../core/output.h"
#include "../../ops/matrix/nd_array.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace nc {
namespace numpy {
namespace vm {

namespace {

using Cplx = std::complex<double>;

bool isSymmetric(const MatrixXd &m) {
  const double scale = std::max(1.0, m.cwiseAbs().maxCoeff());
  return (m - m.transpose()).cwiseAbs().maxCoeff() <= 1e-12 * scale;
}

bool isHermitian(const MatrixXcd &m) {
  const double scale = std::max(1.0, m.cwiseAbs().maxCoeff());
  return (m - m.adjoint()).cwiseAbs().maxCoeff() <= 1e-12 * scale;
}

bool argSquareC(const std::vector<Value> &args, size_t i, CallContext &ctx, MatrixXcd &out) {
  if (!argMatrixC(args, i, ctx, out))
    return false;
  if (out.rows() == 0 || out.rows() != out.cols()) {
    ctx.fail("needs a square matrix, got " + std::to_string(out.rows()) + "x" +
             std::to_string(out.cols()));
    return false;
  }
  return true;
}

double infinity() { return std::numeric_limits<double>::infinity(); }

/* ---- norms ---------------------------------------------------------------- */

// The `ord` argument: a number (inf/-inf allowed) or text ("fro", "nuc").
struct NormOrder {
  bool isText = false;
  std::string text;
  double p = 2.0;
};

bool argOrder(const std::vector<Value> &args, size_t i, CallContext &ctx, NormOrder &ord) {
  if (args[i].isText) {
    ord.isText = true;
    ord.text = args[i].text();
    return true;
  }
  return argNumber(args, i, ctx, ord.p);
}

Value vectorNorm(const std::vector<Value> &args, CallContext &ctx) {
  MatrixXcd m;
  NormOrder ord;
  if (!argMatrixC(args, 0, ctx, m) || (args.size() > 1 && !argOrder(args, 1, ctx, ord)))
    return Value(0.0);
  if (ord.isText) {
    ctx.fail("ord must be a number (1, 2, inf, ...) for vector_norm, got \"" + ord.text + "\"");
    return Value(0.0);
  }
  Eigen::ArrayXd mag = m.cwiseAbs().reshaped().array();
  const double p = ord.p;
  if (mag.size() == 0)
    return Value(0.0);
  if (std::isinf(p))
    return Value(p > 0 ? mag.maxCoeff() : mag.minCoeff());
  if (p == 0)
    return Value(static_cast<double>((mag != 0.0).count()));
  if (p == 1)
    return Value(mag.sum());
  if (p == 2)
    return Value(std::sqrt((mag * mag).sum()));
  return Value(std::pow(mag.pow(p).sum(), 1.0 / p));
}

/* ---- solving ---------------------------------------------------------------- */

// b as a matrix of right-hand-side columns; a 1xN row with N == n is turned
// into a column (and the answer turned back into a row).
bool argRhs(const std::vector<Value> &args, size_t i, CallContext &ctx, Eigen::Index n,
            MatrixXcd &b, bool &wasRow) {
  if (!argMatrixC(args, i, ctx, b))
    return false;
  wasRow = false;
  if (b.rows() == 1 && b.cols() == n && n > 1) {
    b.transposeInPlace();
    wasRow = true;
  }
  if (b.rows() != n) {
    ctx.fail("b must have " + std::to_string(n) + " rows to match A, got " +
             std::to_string(b.rows()) + "x" + std::to_string(b.cols()));
    return false;
  }
  return true;
}

Value solveImpl(const std::vector<Value> &args, CallContext &ctx) {
  MatrixXcd a, b;
  bool wasRow = false;
  if (!argSquareC(args, 0, ctx, a) || !argRhs(args, 1, ctx, a.rows(), b, wasRow))
    return Value(0.0);
  // Same "can this be inverted" rule as inv() for a real matrix.
  Eigen::FullPivLU<MatrixXcd> lu(a);
  const bool singular = args[0].hasComplex() ? !lu.isInvertible()
                                             : isEffectivelySingular(MatrixXd(a.real()));
  if (singular) {
    ctx.fail("A is singular (not invertible), so A x = b has no unique solution - try lstsq(A, b)");
    return Value(0.0);
  }
  MatrixXcd x = lu.solve(b);
  if (wasRow)
    x.transposeInPlace();
  return scalarIfSingle(fromEigenC(x));
}

/* ---- eigenvalues -------------------------------------------------------------- */

// Eigenvalues (as a column) and right eigenvectors (columns) of a square
// matrix. A real symmetric / complex Hermitian matrix gets real eigenvalues
// in ascending order.
bool eigDecompose(const std::vector<Value> &args, CallContext &ctx, MatrixXcd &values,
                  MatrixXcd &vectors) {
  MatrixXcd a;
  if (!argSquareC(args, 0, ctx, a))
    return false;
  const bool real = !args[0].hasComplex();
  if (real) {
    MatrixXd ar = a.real();
    if (isSymmetric(ar)) {
      Eigen::SelfAdjointEigenSolver<MatrixXd> es(ar);
      values = es.eigenvalues().cast<Cplx>();
      vectors = es.eigenvectors().cast<Cplx>();
      return true;
    }
    Eigen::EigenSolver<MatrixXd> es(ar);
    if (es.info() != Eigen::Success) {
      ctx.fail("the eigenvalue computation did not converge");
      return false;
    }
    values = es.eigenvalues();
    vectors = es.eigenvectors();
    return true;
  }
  if (isHermitian(a)) {
    Eigen::SelfAdjointEigenSolver<MatrixXcd> es(a);
    values = es.eigenvalues().cast<Cplx>();
    vectors = es.eigenvectors();
    return true;
  }
  Eigen::ComplexEigenSolver<MatrixXcd> es(a);
  if (es.info() != Eigen::Success) {
    ctx.fail("the eigenvalue computation did not converge");
    return false;
  }
  values = es.eigenvalues();
  vectors = es.eigenvectors();
  return true;
}

/* ---- SVD ---------------------------------------------------------------------- */

void svdImpl(const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
             CallContext &ctx) {
  MatrixXcd a;
  if (!argMatrixC(args, 0, ctx, a))
    return;
  if (a.size() == 0) {
    ctx.fail("needs a non-empty matrix");
    return;
  }
  if (!args[0].hasComplex()) {
    MatrixXd ar = a.real();
    NC_FULL_SVD(MatrixXd, svd, ar);
    Eigen::VectorXd s = svd.singularValues();
    if (nout == 1) {
      out.push_back(fromEigen(s));
      return;
    }
    MatrixXd S = MatrixXd::Zero(ar.rows(), ar.cols());
    for (Eigen::Index k = 0; k < s.size(); k++)
      S(k, k) = s(k);
    out.push_back(fromEigen(svd.matrixU()));
    out.push_back(fromEigen(S));
    if (nout > 2)
      out.push_back(fromEigen(svd.matrixV()));
    return;
  }
  NC_FULL_SVD(MatrixXcd, svd, a);
  Eigen::VectorXd s = svd.singularValues();
  if (nout == 1) {
    out.push_back(fromEigen(s));
    return;
  }
  MatrixXd S = MatrixXd::Zero(a.rows(), a.cols());
  for (Eigen::Index k = 0; k < s.size(); k++)
    S(k, k) = s(k);
  out.push_back(fromEigenC(svd.matrixU()));
  out.push_back(fromEigen(S));
  if (nout > 2)
    out.push_back(fromEigenC(svd.matrixV()));
}

double conditionNumber2(const MatrixXd &a) {
  Eigen::JacobiSVD<MatrixXd> svd(a);
  const Eigen::VectorXd s = svd.singularValues();
  if (s.size() == 0)
    return 0.0;
  const double smin = s(s.size() - 1);
  return smin == 0.0 ? infinity() : s(0) / smin;
}

/* ---- N-D helpers for tensorinv / tensorsolve ------------------------------ */
//
// NumPy works on these in C order (last index fastest). NC's N-D matrices
// use the same index order (ops/matrix/nd_array.h: A[i,j,k] is NumPy's
// a[i,j,k]), so nd::rowMajorCells / nd::buildRowMajor give exactly NumPy's
// flattening and reshaping.

// The elements of args[i] in row-major order, as complex numbers, and its
// shape.
bool ndArg(const std::vector<Value> &args, size_t i, CallContext &ctx, nd::Shape &shape,
           std::vector<Cplx> &cells) {
  const Value &v = args[i];
  if (v.isText || v.isDict || v.isObject || v.isFunctionRef) {
    ctx.fail("the " + ordinal(i) + " argument must be a number, vector or matrix, not " +
             describe(v));
    return false;
  }
  shape = nd::shapeOf(v);
  cells.clear();
  for (const Value &e : nd::rowMajorCells(v)) {
    if (e.isText || e.isArray || e.isMatrix || e.isDict || e.isObject || e.isFunctionRef) {
      ctx.fail("the " + ordinal(i) + " argument must contain only numbers");
      return false;
    }
    cells.push_back(Cplx(e.number, e.isComplex ? e.imag : 0.0));
  }
  return true;
}

// A matrix of `shape` from row-major complex cells; real when every
// imaginary part is zero. A rank-1 shape becomes a 1xN row.
Value ndResult(const nd::Shape &shape, const std::vector<Cplx> &cells) {
  std::vector<Value> vals;
  vals.reserve(cells.size());
  for (const Cplx &z : cells)
    vals.push_back(complexScalar(z));
  return scalarIfSingle(nd::buildRowMajor(shape, vals));
}

// "2x3x4"; "()" for no axes.
std::string shapeWords(const nd::Shape &s) { return s.empty() ? "()" : nd::shapeText(s); }

size_t productOf(const nd::Shape &s, size_t from, size_t to) {
  size_t p = 1;
  for (size_t i = from; i < to; i++)
    p *= s[i];
  return p;
}

// Square matrix from row-major cells, or false (singular) after reporting.
bool invertSquare(MatrixXcd &m, bool realInput, CallContext &ctx, const char *what) {
  Eigen::FullPivLU<MatrixXcd> lu(m);
  const bool singular = realInput ? isEffectivelySingular(MatrixXd(m.real())) : !lu.isInvertible();
  if (singular) {
    ctx.fail(std::string(what) + " is singular (not invertible)");
    return false;
  }
  m = lu.inverse();
  return true;
}

// np.linalg.tensorinv(a, ind): a reshaped to a square
// (prod(shape[ind:]) x prod(shape[:ind])) matrix, inverted, and reshaped to
// shape[ind:] + shape[:ind].
Value tensorinvImpl(const std::vector<Value> &args, CallContext &ctx) {
  nd::Shape shape;
  std::vector<Cplx> cells;
  long long ind = 2;
  if (!ndArg(args, 0, ctx, shape, cells) || !argInt(args, 1, ctx, ind))
    return Value(0.0);
  if (ind < 1) {
    ctx.fail("ind must be 1 or more, got " + std::to_string(ind));
    return Value(0.0);
  }
  const size_t k = std::min(static_cast<size_t>(ind), shape.size());
  const nd::Shape first(shape.begin(), shape.begin() + static_cast<std::ptrdiff_t>(k));
  const nd::Shape rest(shape.begin() + static_cast<std::ptrdiff_t>(k), shape.end());
  const size_t rows = productOf(shape, k, shape.size()); // NumPy: prod(shape[ind:])
  const size_t cols = cells.size() / std::max<size_t>(rows, 1);
  if (rows == 0 || rows != cols) {
    std::string hint;
    if (shape.size() == 2 && ind == 2)
      hint = " - for a square 2-D matrix use tensorinv(A, ind=1), the ordinary inverse";
    ctx.fail("A is " + shapeWords(shape) + ": its first " + std::to_string(ind) +
             " axes " + shapeWords(first) + " and its other axes " + shapeWords(rest) +
             " must hold the same number of elements" + hint);
    return Value(0.0);
  }
  MatrixXcd m(static_cast<Eigen::Index>(rows), static_cast<Eigen::Index>(cols));
  for (size_t r = 0; r < rows; r++)
    for (size_t c = 0; c < cols; c++)
      m(static_cast<Eigen::Index>(r), static_cast<Eigen::Index>(c)) = cells[r * cols + c];
  if (!invertSquare(m, !args[0].hasComplex(), ctx, "A, as a square matrix,"))
    return Value(0.0);
  std::vector<Cplx> out;
  out.reserve(cells.size());
  for (Eigen::Index r = 0; r < m.rows(); r++)
    for (Eigen::Index c = 0; c < m.cols(); c++)
      out.push_back(m(r, c));
  nd::Shape invShape = rest;
  invShape.insert(invShape.end(), first.begin(), first.end());
  return ndResult(invShape, out);
}

// np.linalg.tensorsolve(a, b, axes): x with tensordot(a, x, x.ndim) = b.
// NC rule for b's shape: a vector (row or column) counts as 1-D, as a NumPy
// 1-D array would; any other b keeps its shape, leading 1s dropped.
Value tensorsolveImpl(const std::vector<Value> &args, CallContext &ctx) {
  nd::Shape aShape, bShape;
  std::vector<Cplx> a, b;
  if (!ndArg(args, 0, ctx, aShape, a) || !ndArg(args, 1, ctx, bShape, b))
    return Value(0.0);
  const size_t an = aShape.size();

  // axes: these axes of A are moved to the end, in the order given.
  if (args.size() > 2) {
    std::vector<double> axesList;
    if (!argNumbers(args, 2, ctx, axesList))
      return Value(0.0);
    std::vector<size_t> order;
    for (size_t i = 0; i < an; i++)
      order.push_back(i);
    for (double d : axesList) {
      long long k = static_cast<long long>(d);
      if (d != std::floor(d) || k < -static_cast<long long>(an) || k >= static_cast<long long>(an)) {
        ctx.fail("axes must list axes of A (0 to " + std::to_string(an - 1) + "), got " +
                 std::to_string(d));
        return Value(0.0);
      }
      if (k < 0)
        k += static_cast<long long>(an);
      auto it = std::find(order.begin(), order.end(), static_cast<size_t>(k));
      if (it == order.end()) {
        ctx.fail("axis " + std::to_string(k) + " is listed twice in axes");
        return Value(0.0);
      }
      order.erase(it);
      order.push_back(static_cast<size_t>(k));
    }
    // Transpose: new axis i is old axis order[i].
    nd::Shape newShape;
    for (size_t i : order)
      newShape.push_back(aShape[i]);
    std::vector<size_t> oldStride(an, 1);
    for (size_t i = an - 1; i-- > 0;)
      oldStride[i] = oldStride[i + 1] * aShape[i + 1];
    std::vector<Cplx> moved;
    moved.reserve(a.size());
    std::vector<size_t> idx(an, 0);
    if (!a.empty()) {
      do {
        size_t off = 0;
        for (size_t i = 0; i < an; i++)
          off += idx[i] * oldStride[order[i]];
        moved.push_back(a[off]);
      } while (nd::nextIndex(idx, newShape));
    }
    a = std::move(moved);
    aShape = newShape;
  }

  // b's own axes (see the rule above).
  nd::Shape bAxes = bShape;
  if (bAxes.size() == 2 && (bAxes[0] == 1 || bAxes[1] == 1))
    bAxes = {bAxes[0] * bAxes[1]};
  while (bAxes.size() > 1 && bAxes[0] == 1)
    bAxes.erase(bAxes.begin());
  const size_t bn = bAxes.size();
  if (bn >= an) {
    ctx.fail("b (" + shapeWords(bAxes) + ") must have fewer axes than A (" +
             shapeWords(aShape) + ")");
    return Value(0.0);
  }
  const nd::Shape xShape(aShape.begin() + static_cast<std::ptrdiff_t>(bn), aShape.end());
  const size_t n = productOf(aShape, bn, an);
  if (productOf(aShape, 0, bn) != n || b.size() != n) {
    ctx.fail("A (" + shapeWords(aShape) + ") does not fit b (" + shapeWords(bAxes) +
             "): A's last " + std::to_string(an - bn) + " axes " + shapeWords(xShape) +
             " and its first " + std::to_string(bn) +
             " must each hold as many elements as b has");
    return Value(0.0);
  }
  // As NumPy, only the element counts are checked: A's leading axes are not
  // compared with b's shape one by one.
  MatrixXcd m(static_cast<Eigen::Index>(n), static_cast<Eigen::Index>(n));
  for (size_t r = 0; r < n; r++)
    for (size_t c = 0; c < n; c++)
      m(static_cast<Eigen::Index>(r), static_cast<Eigen::Index>(c)) = a[r * n + c];
  Eigen::VectorXcd rhs(static_cast<Eigen::Index>(n));
  for (size_t k = 0; k < n; k++)
    rhs(static_cast<Eigen::Index>(k)) = b[k];
  Eigen::FullPivLU<MatrixXcd> lu(m);
  const bool realInput = !args[0].hasComplex() && !args[1].hasComplex();
  if (realInput ? isEffectivelySingular(MatrixXd(m.real())) : !lu.isInvertible()) {
    ctx.fail("A, as a square " + std::to_string(n) + "x" + std::to_string(n) +
             " matrix, is singular, so there is no unique solution");
    return Value(0.0);
  }
  Eigen::VectorXcd x = lu.solve(rhs);
  return ndResult(xShape, std::vector<Cplx>(x.data(), x.data() + x.size()));
}

} // namespace

void registerLinalg(Registry &reg) {
  // ---- norms and determinants --------------------------------------------
  // matrix_norm(A[, ord]) and trace(A) are existing builtins (ops/matrix).
  addFn(reg, "vector_norm", 1, 2, "vector_norm(x[, ord])",
        "p-norm of all elements (ord 2 default; 1, inf, -inf, 0 or any p)", "np.linalg.vector_norm",
        vectorNorm, true);

  addMulti(reg, "slogdet", 1, 1, 2, "[sign, logdet] = slogdet(A)",
           "sign and log|det(A)|, safe from overflow; x = slogdet(A) gives [sign, logdet]",
           "np.linalg.slogdet",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXcd a;
             if (!argSquareC(args, 0, ctx, a))
               return;
             Eigen::PartialPivLU<MatrixXcd> lu(a);
             const MatrixXcd &lum = lu.matrixLU();
             Cplx sign = lu.permutationP().determinant() < 0 ? Cplx(-1, 0) : Cplx(1, 0);
             double logdet = 0.0;
             for (Eigen::Index k = 0; k < lum.rows(); k++) {
               const Cplx d = lum(k, k);
               const double mag = std::abs(d);
               if (mag == 0.0) {
                 sign = Cplx(0, 0);
                 logdet = -infinity();
                 break;
               }
               sign *= d / mag;
               logdet += std::log(mag);
             }
             if (!args[0].hasComplex())
               sign = Cplx(std::round(sign.real()), 0.0);
             if (nout == 1) {
               if (sign.imag() == 0.0)
                 out.push_back(rowVector({sign.real(), logdet}));
               else
                 out.push_back(Value(std::vector<std::vector<Value>>{
                     {complexScalar(sign), Value(logdet)}}));
               return;
             }
             out.push_back(complexScalar(sign));
             out.push_back(Value(logdet));
           },
           true);

  // ---- solving -------------------------------------------------------------
  // pinv(A) is an existing builtin (ops/matrix).
  addFn(reg, "solve", 2, 2, "solve(A, b)", "x with A*x = b (A square and invertible)",
        "np.linalg.solve", solveImpl, true);

  addMulti(reg, "lstsq", 2, 3, 4, "[x, residuals, rank, s] = lstsq(A, b[, rcond])",
           "least-squares (minimum-norm) x minimising |A*x - b|, plus residual sums, rank and "
           "singular values; singular values below rcond*max(s) count as zero",
           "np.linalg.lstsq",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXd a, b;
             if (!argMatrix(args, 0, ctx, a) || !argMatrix(args, 1, ctx, b))
               return;
             bool wasRow = false;
             if (b.rows() == 1 && b.cols() == a.rows() && a.rows() > 1) {
               b.transposeInPlace();
               wasRow = true;
             }
             if (a.size() == 0 || b.rows() != a.rows()) {
               ctx.fail("b must have as many rows as A (" + std::to_string(a.rows()) + "), got " +
                        shapeText(b));
               return;
             }
             // rcond: NumPy's default is machine epsilon * max(M, N) (R8).
             double rcond = std::numeric_limits<double>::epsilon() *
                            static_cast<double>(std::max(a.rows(), a.cols()));
             if (args.size() > 2) {
               if (!argNumber(args, 2, ctx, rcond))
                 return;
               if (!(rcond >= 0.0) && rcond != -1.0) {
                 ctx.fail("rcond must be 0 or more, got " + formatNumber(rcond));
                 return;
               }
               if (rcond == -1.0) // NumPy's old "machine precision" setting
                 rcond = std::numeric_limits<double>::epsilon();
             }
             // x = V * diag(1/s) * U' * b over the singular values kept.
             NC_FULL_SVD(MatrixXd, svd, a);
             const Eigen::VectorXd sv = svd.singularValues();
             const double cutoff = sv.size() > 0 ? rcond * sv(0) : 0.0;
             Eigen::Index rank = 0;
             MatrixXd x = MatrixXd::Zero(a.cols(), b.cols());
             for (Eigen::Index k = 0; k < sv.size(); k++) {
               if (!(sv(k) > cutoff))
                 continue;
               rank++;
               x += svd.matrixV().col(k) *
                    ((svd.matrixU().col(k).transpose() * b) / sv(k));
             }
             MatrixXd xOut = wasRow ? MatrixXd(x.transpose()) : x;
             out.push_back(scalarIfSingle(fromEigen(xOut)));
             if (nout > 1) {
               // Sum of squared residuals per column - only when the system
               // is overdetermined and of full rank (NumPy's rule).
               if (rank == a.cols() && a.rows() > a.cols()) {
                 MatrixXd res = (a * x - b).colwise().squaredNorm();
                 out.push_back(scalarIfSingle(fromEigen(res)));
               } else {
                 out.push_back(Value(std::vector<std::vector<Value>>{}));
               }
             }
             if (nout > 2)
               out.push_back(Value(static_cast<double>(rank)));
             if (nout > 3)
               out.push_back(fromEigen(sv));
           });

  // ---- eigenvalues -----------------------------------------------------------
  addMulti(reg, "eig", 1, 1, 2, "[V, D] = eig(A)",
           "eigenvalues of A as a column; [V, D] = eig(A) gives eigenvectors V and diagonal D "
           "with A*V = V*D",
           "np.linalg.eig",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXcd values, vectors;
             if (!eigDecompose(args, ctx, values, vectors))
               return;
             if (nout == 1) {
               out.push_back(fromEigenC(values));
               return;
             }
             out.push_back(fromEigenC(vectors));
             out.push_back(fromEigenC(MatrixXcd(values.asDiagonal())));
           },
           true);

  addFn(reg, "eigvr", 1, 1, "eigvr(A)",
        "right eigenvectors of A as columns (A*v = lambda*v), in the order of eig(A)",
        "np.linalg.eig / np.linalg.eigh",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd values, vectors;
          if (!eigDecompose(args, ctx, values, vectors))
            return Value(0.0);
          return fromEigenC(vectors);
        },
        true);

  addFn(reg, "eigvl", 1, 1, "eigvl(A)",
        "left eigenvectors of A as columns (w'*A = lambda*w'), in the order of eig(A)",
        "scipy.linalg.eig(left=True)",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd values, vectors;
          if (!eigDecompose(args, ctx, values, vectors))
            return Value(0.0);
          // The rows of inv(V) are the left eigenvectors (conjugated), in the
          // same order as the eigenvalues; each is scaled to unit length.
          Eigen::FullPivLU<MatrixXcd> lu(vectors);
          if (!lu.isInvertible()) {
            ctx.fail("A is not diagonalizable (its eigenvectors are not independent), so its "
                     "left eigenvectors are not defined this way");
            return Value(0.0);
          }
          MatrixXcd w = lu.inverse().adjoint();
          for (Eigen::Index j = 0; j < w.cols(); j++) {
            const double n = w.col(j).norm();
            if (n > 0)
              w.col(j) /= n;
          }
          return fromEigenC(w);
        },
        true);

  addFn(reg, "eig_ascend", 1, 1, "eig_ascend(A)",
        "eigenvalues of a symmetric (Hermitian) matrix, ascending, as a column",
        "np.linalg.eigvalsh",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a;
          if (!argSquareC(args, 0, ctx, a))
            return Value(0.0);
          if (!isHermitian(a)) {
            ctx.fail("needs a symmetric (Hermitian) matrix - use eig(A) for a general one");
            return Value(0.0);
          }
          Eigen::SelfAdjointEigenSolver<MatrixXcd> es(a, Eigen::EigenvaluesOnly);
          return fromEigen(es.eigenvalues());
        },
        true);

  // ---- decompositions ----------------------------------------------------------
  addMulti(reg, "svd", 1, 1, 3, "[U, S, V] = svd(A)",
           "singular values as a column; [U, S, V] = svd(A) gives A = U*S*V'", "np.linalg.svd",
           svdImpl, true);

  addFn(reg, "svdvals", 1, 1, "svdvals(A)", "singular values of A, largest first, as a column",
        "np.linalg.svdvals",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          std::vector<Value> out;
          svdImpl(args, 1, out, ctx);
          return out.empty() ? Value(0.0) : out[0];
        },
        true);

  addMulti(reg, "qr", 1, 1, 2, "[Q, R] = qr(A)",
           "QR decomposition A = Q*R (Q orthogonal, R upper triangular); R = qr(A) gives R",
           "np.linalg.qr",
           [](const std::vector<Value> &args, size_t nout, std::vector<Value> &out,
              CallContext &ctx) {
             MatrixXcd a;
             if (!argMatrixC(args, 0, ctx, a))
               return;
             if (a.size() == 0) {
               ctx.fail("needs a non-empty matrix");
               return;
             }
             Eigen::HouseholderQR<MatrixXcd> qr(a);
             MatrixXcd R = qr.matrixQR().triangularView<Eigen::Upper>();
             MatrixXcd Q = qr.householderQ() * MatrixXcd::Identity(a.rows(), a.rows());
             if (nout == 1) {
               out.push_back(fromEigenC(R));
               return;
             }
             out.push_back(fromEigenC(Q));
             out.push_back(fromEigenC(R));
           },
           true);

  addFn(reg, "cholesky", 1, 1, "cholesky(A)",
        "lower-triangular L with A = L*L' (A symmetric positive definite)", "np.linalg.cholesky",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a;
          if (!argSquareC(args, 0, ctx, a))
            return Value(0.0);
          if (!isHermitian(a)) {
            ctx.fail("needs a symmetric (Hermitian) matrix");
            return Value(0.0);
          }
          Eigen::LLT<MatrixXcd> llt(a);
          if (llt.info() != Eigen::Success) {
            ctx.fail("the matrix is not positive definite");
            return Value(0.0);
          }
          return fromEigenC(MatrixXcd(llt.matrixL()));
        },
        true);

  addFn(reg, "cond", 1, 2, "cond(A[, p])",
        "condition number of A: 2-norm by default, or p = 1, inf, \"fro\"", "np.linalg.cond",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXd a;
          NormOrder ord;
          if (!argMatrix(args, 0, ctx, a) || (args.size() > 1 && !argOrder(args, 1, ctx, ord)))
            return Value(0.0);
          if (a.size() == 0) {
            ctx.fail("needs a non-empty matrix");
            return Value(0.0);
          }
          if (!ord.isText && ord.p == 2)
            return Value(conditionNumber2(a));
          if (a.rows() != a.cols()) {
            ctx.fail("this norm needs a square matrix, got " + shapeText(a));
            return Value(0.0);
          }
          if (isEffectivelySingular(a))
            return Value(infinity());
          MatrixXd inv = a.inverse();
          auto norm = [&](const MatrixXd &m) -> double {
            if (ord.isText)
              return m.norm(); // "fro"
            if (ord.p == 1)
              return m.cwiseAbs().colwise().sum().maxCoeff();
            if (std::isinf(ord.p) && ord.p > 0)
              return m.cwiseAbs().rowwise().sum().maxCoeff();
            return -1.0;
          };
          if (ord.isText && ord.text != "fro") {
            ctx.fail("p must be 1, 2, inf or \"fro\", got \"" + ord.text + "\"");
            return Value(0.0);
          }
          const double n1 = norm(a);
          if (n1 < 0) {
            ctx.fail("p must be 1, 2, inf or \"fro\"");
            return Value(0.0);
          }
          return Value(n1 * norm(inv));
        });

  // ---- tensor forms (N-D, as NumPy - R5, 2026-10-27) ------------------------------
  addFn(reg, "tensorinv", 1, 2, "tensorinv(A[, ind])",
        "inverse of an N-D A with respect to its first ind axes (ind=2); result shape "
        "A.shape[ind:] + A.shape[:ind]",
        "np.linalg.tensorinv", tensorinvImpl, true);
  addFn(reg, "tensorsolve", 2, 3, "tensorsolve(A, b[, axes])",
        "x with tensordot(A, x, x.ndim) = b; axes moves those axes of A to the end first",
        "np.linalg.tensorsolve", tensorsolveImpl, true);

  addFn(reg, "diagonal", 1, 2, "diagonal(A[, k])",
        "the k-th diagonal of A as a row (k = 0 main, > 0 above, < 0 below)",
        "np.linalg.diagonal",
        [](const std::vector<Value> &args, CallContext &ctx) -> Value {
          MatrixXcd a;
          long long k = 0;
          if (!argMatrixC(args, 0, ctx, a) || (args.size() > 1 && !argInt(args, 1, ctx, k)))
            return Value(0.0);
          std::vector<Value> d;
          for (Eigen::Index r = 0; r < a.rows(); r++) {
            const Eigen::Index c = r + static_cast<Eigen::Index>(k);
            if (c >= 0 && c < a.cols())
              d.push_back(complexScalar(a(r, c)));
          }
          if (d.empty())
            return Value(std::vector<std::vector<Value>>{});
          return Value(std::vector<std::vector<Value>>{d});
        },
        true);
}

} // namespace vm
} // namespace numpy
} // namespace nc
