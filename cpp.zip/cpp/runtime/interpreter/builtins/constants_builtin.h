#pragma once

#include "../core/value.h"

#include <string>
#include <vector>

// Resolve a constant value by name.
// - Case-sensitive (`pi`, not `PI`; see constants_builtin.cpp)
// - Whitespace-insensitive
// - Alias-safe (alias resolved before lookup)
// Returns true and sets outValue on success.
bool tryResolveConstantValue(const std::string &name, double &outValue);

// Dispatcher for constants builtins (kept for compatibility with existing
// code).
Value constantsBuiltin(const std::string &name, const std::vector<Value> &args);
