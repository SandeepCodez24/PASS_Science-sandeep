#pragma once

#include "value.h"
#include <string>
#include <vector>

// Global flag: set by callBuiltin to indicate success (true) or unknown
// function (false)
extern bool g_lastBuiltinFound;

Value callBuiltin(const std::string &name, const std::vector<Value> &args);

// A builtin with several results, called as [U, S, V] = svd(A): if `name`
// is one that can return `nout` values, runs it, fills `out` (nout values),
// sets `ok` (false = an error was printed) and returns true. Returns false
// if `name` has no multi-output form.
// `argNames`: as for callBuiltinNamed() below.
bool callBuiltinMulti(const std::string &name, const std::vector<Value> &args, size_t nout,
                      std::vector<Value> &out, bool &ok,
                      const std::vector<std::string> &argNames = {});

// A call that names some of its values: allclose(A, B, atol=0.2),
// max(A, axis=0), round(X, decimals=2). `argNames` has one entry per value
// ("" for a plain one). Works for every builtin with a parameter line - the
// NumPy functions that have one (Numpy/<section>/..._main.cpp) and the core
// builtins in kCoreParams (builtins.cpp); naming a value of any other
// builtin is an error. Same result contract as callBuiltin().
Value callBuiltinNamed(const std::string &name, const std::vector<Value> &args,
                       const std::vector<std::string> &argNames);

// The usage line of a builtin that has a parameter line, e.g.
// "allclose(A, B, atol=0.1, rtol=0)"; empty when it has none. For error
// messages and for the IDE's suggestions.
std::string builtinSignature(const std::string &name);

// Returns true if the given identifier is registered as one of the built-in
// constants. (e.g. pi, e, g, gas_constant, ...)
bool isBuiltinConstant(const std::string &name);

// True if callBuiltin() knows `name` (used for @sqrt - a reference to a
// built-in function).
bool builtinExists(const std::string &name);
