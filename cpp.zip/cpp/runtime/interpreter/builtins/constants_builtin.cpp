#include "constants_builtin.h"

#include <algorithm>
#include <cctype>
#include <limits>
#include <string>
#include <unordered_map>

// Constant names are case-sensitive, like every other name in NC, and the
// only one-letter constant is e (with pi, the two everyone expects). Until
// 2026-10 the lookup ignored case and had g, r and h too, so an unassigned
// one-letter variable silently became a constant: `2*pi*r` with no r gave
// 52.24 (the gas constant), and `G` was gravity rather than the
// gravitational constant. The long names below still reach every value.
static std::string normalizeIdentifier(std::string s) {
  // Was passing a bare `char` straight into the global ::isspace(int) -
  // undefined behavior for any byte >= 128 when char is signed (true on
  // this platform), which is exactly what every continuation byte of a
  // multi-byte UTF-8 character is - including "π"/"σ", the very aliases
  // this file registers below.
  s.erase(std::remove_if(s.begin(), s.end(),
                          [](unsigned char c) { return std::isspace(c); }),
          s.end());
  return s;
}

static const std::unordered_map<std::string, double> constants = {
    {"pi", 3.14159265358979323846},
    {"e", 2.718281828459045},

    // gravity (standard acceleration of free fall)
    {"gravity", 9.80665},

    // gas constant
    {"gas_constant", 8.314462618},

    // avogadro
    {"avogadro", 6.02214076e23},

    // planck constant
    {"planck", 6.62607015e-34},

    // stefan boltzmann
    {"sigma", 5.670374419e-8},

    // coulomb constant
    {"k_e", 8.9875517923e9},

    // masses
    {"m_e", 9.1093837015e-31},
    {"m_p", 1.67262192369e-27},

    // charge
    {"e_charge", 1.602176634e-19},

    // gravitational constant
    {"grav_const", 6.67430e-11},

    // Euler-Mascheroni constant (NumPy np.euler_gamma) - R7. A variable the
    // script assigns with this name wins over it (readVariableOrConstant()
    // reads variables first).
    {"euler_gamma", 0.5772156649015329},

    // Universal constants, uc_<name> (2026-10-30). <name> is the token of the
    // editor's \con(\<name>) command (language/replace/Uniconstant.java), in SI
    // units, CODATA 2022 - the set in scipy.constants, which they were checked
    // against. Older names above (m_e, k_e, ...) keep their CODATA 2018 values.
    {"uc_pi", 3.14159265358979323846},
    {"uc_gravity", 9.80665},                     // m s^-2, standard, exact
    {"uc_gasconst", 8.31446261815324},           // J mol^-1 K^-1, exact
    {"uc_avogadro", 6.02214076e23},              // mol^-1, exact
    {"uc_planck", 6.62607015e-34},               // J s, h, exact
    {"uc_hbar", 1.0545718176461565e-34},         // J s, h / (2 pi), exact
    {"uc_gravitational", 6.67430e-11},           // m^3 kg^-1 s^-2, G
    {"uc_stefanboltzmann", 5.6703744191844314e-8}, // W m^-2 K^-4, exact
    {"uc_coulomb", 8.9875517862e9},              // N m^2 C^-2, 1 / (4 pi eps0)
    {"uc_electronmass", 9.1093837139e-31},       // kg
    {"uc_protonmass", 1.67262192595e-27},        // kg
    {"uc_neutronmass", 1.67492750056e-27},       // kg
    {"uc_molarmass", 1.00000000105e-3},          // kg mol^-1, molar mass constant
    {"uc_elementarycharge", 1.602176634e-19},    // C, exact
    {"uc_faraday", 96485.33212331001},           // C mol^-1, exact
    {"uc_speedoflight", 299792458.0},            // m s^-1, exact
    {"uc_boltzmann", 1.380649e-23},              // J K^-1, exact
    {"uc_vacuumpermittivity", 8.8541878188e-12}, // F m^-1
    {"uc_vacuumpermeability", 1.25663706127e-6}, // N A^-2
    {"uc_finestructure", 7.2973525643e-3},       // dimensionless
    {"uc_rydberg", 10973731.568157},             // m^-1
    {"uc_bohrradius", 5.29177210544e-11},        // m
    {"uc_hartreeenergy", 4.3597447222060e-18},   // J
    {"uc_magneticfluxquantum", 2.0678338484619295e-15}, // Wb, exact

    // IEEE-754 special values (NumPy np.nan / np.inf). `-inf` needs no entry
    // of its own: it is unary minus applied to `inf`.
    {"nan", std::numeric_limits<double>::quiet_NaN()},
    {"inf", std::numeric_limits<double>::infinity()}};

static const std::unordered_map<std::string, std::string> alias = {

    // pi
    {"π", "pi"},

    // planck
    {"planck_constant", "planck"},

    {"gravitational_constant", "grav_const"},

    // sigma
    {"σ", "sigma"},
    {"stefan_boltzmann", "sigma"},

    // coulomb
    {"ke", "k_e"},
    {"coulomb_const", "k_e"},

    // electron
    {"me", "m_e"},
    {"electron_mass", "m_e"},

    // proton
    {"mp", "m_p"},
    {"proton_mass", "m_p"},

    // charge
    {"echarge", "e_charge"},
    {"elementary_charge", "e_charge"},

    // gravity constant
    // {"grav_const", "grav_const"},
    // {"g_const", "grav_const"},

};

bool tryResolveConstantValue(const std::string &rawName, double &outValue) {
  std::string key = normalizeIdentifier(rawName);

  auto itAlias = alias.find(key);
  if (itAlias != alias.end())
    key = itAlias->second;

  auto it = constants.find(key);
  if (it == constants.end())
    return false;

  outValue = it->second;
  return true;
}

/* ================= BUILTIN HANDLER ================= */
// Kept for backward compatibility; constants MUST be resolved by parser
// directly. This handler never prints.
Value constantsBuiltin(const std::string &name, const std::vector<Value> &) {
  double v = 0.0;
  if (!tryResolveConstantValue(name, v))
    return Value();
  return Value(v);
}
