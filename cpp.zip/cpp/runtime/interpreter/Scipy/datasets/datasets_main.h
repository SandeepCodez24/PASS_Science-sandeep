// Section 3 of 25 - Datasets
// (scipy.datasets, 5 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_DATASETS_MAIN_H
#define NC_SCIPY_DATASETS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Datasets entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerDatasets(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_DATASETS_MAIN_H
