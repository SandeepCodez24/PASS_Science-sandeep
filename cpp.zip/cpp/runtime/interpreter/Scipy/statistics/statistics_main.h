// Section 21 of 25 - Statistics
// (scipy.stats, 200 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_STATISTICS_MAIN_H
#define NC_SCIPY_STATISTICS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Statistics entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerStatistics(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_STATISTICS_MAIN_H
