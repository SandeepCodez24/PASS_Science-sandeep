// Section 7 of 25 - Integration & ODEs
// (scipy.integrate, 33 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_INTEGRATION_ODES_MAIN_H
#define NC_SCIPY_INTEGRATION_ODES_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Integration & ODEs entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerIntegrationOdes(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_INTEGRATION_ODES_MAIN_H
