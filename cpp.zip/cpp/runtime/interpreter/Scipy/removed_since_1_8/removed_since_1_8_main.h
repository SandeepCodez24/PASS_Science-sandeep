// Section 24 of 25 - Removed Since SciPy 1.8 (with Replacements) - Appendix A
// ((various), 60 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_REMOVED_SINCE_1_8_MAIN_H
#define NC_SCIPY_REMOVED_SINCE_1_8_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Removed Since SciPy 1.8 (with Replacements) entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerRemovedSince18(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_REMOVED_SINCE_1_8_MAIN_H
