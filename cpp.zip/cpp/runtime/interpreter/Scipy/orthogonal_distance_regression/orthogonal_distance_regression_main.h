// Section 12 of 25 - Orthogonal Distance Regression
// (scipy.odr, 14 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_ORTHOGONAL_DISTANCE_REGRESSION_MAIN_H
#define NC_SCIPY_ORTHOGONAL_DISTANCE_REGRESSION_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Orthogonal Distance Regression entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerOrthogonalDistanceRegression(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_ORTHOGONAL_DISTANCE_REGRESSION_MAIN_H
