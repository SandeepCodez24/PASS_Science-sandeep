// Section 23 of 25 - Masked-Array Statistics
// (scipy.stats.mstats, 73 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_MASKED_ARRAY_STATISTICS_MAIN_H
#define NC_SCIPY_MASKED_ARRAY_STATISTICS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Masked-Array Statistics entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerMaskedArrayStatistics(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_MASKED_ARRAY_STATISTICS_MAIN_H
