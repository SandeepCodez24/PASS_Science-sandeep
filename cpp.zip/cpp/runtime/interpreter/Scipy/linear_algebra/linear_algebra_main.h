// Section 10 of 25 - Linear Algebra
// (scipy.linalg, 110 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_LINEAR_ALGEBRA_MAIN_H
#define NC_SCIPY_LINEAR_ALGEBRA_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Linear Algebra entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerLinearAlgebra(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_LINEAR_ALGEBRA_MAIN_H
