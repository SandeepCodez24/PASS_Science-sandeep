// Section 4 of 25 - Differentiation
// (scipy.differentiate, 3 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_DIFFERENTIATION_MAIN_H
#define NC_SCIPY_DIFFERENTIATION_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Differentiation entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerDifferentiation(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_DIFFERENTIATION_MAIN_H
