// Section 2 of 25 - Physical & Mathematical Constants
// (scipy.constants, 164 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_CONSTANTS_MAIN_H
#define NC_SCIPY_CONSTANTS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Physical & Mathematical Constants entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerConstants(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_CONSTANTS_MAIN_H
