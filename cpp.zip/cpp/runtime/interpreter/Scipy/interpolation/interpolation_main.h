// Section 8 of 25 - Interpolation
// (scipy.interpolate, 56 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_INTERPOLATION_MAIN_H
#define NC_SCIPY_INTERPOLATION_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Interpolation entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerInterpolation(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_INTERPOLATION_MAIN_H
