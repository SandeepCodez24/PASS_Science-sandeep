// Section 14 of 25 - Signal Processing
// (scipy.signal, 158 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_SIGNAL_PROCESSING_MAIN_H
#define NC_SCIPY_SIGNAL_PROCESSING_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Signal Processing entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerSignalProcessing(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SIGNAL_PROCESSING_MAIN_H
