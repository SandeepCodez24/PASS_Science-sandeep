// Section 6 of 25 - Legacy FFT
// (scipy.fftpack, 35 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_LEGACY_FFT_MAIN_H
#define NC_SCIPY_LEGACY_FFT_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Legacy FFT entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerLegacyFft(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_LEGACY_FFT_MAIN_H
