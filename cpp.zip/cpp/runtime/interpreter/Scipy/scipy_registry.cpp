#include "scipy_registry.h"

#include <algorithm>
#include <cctype>
#include <iostream>
#include <unordered_set>

#include "../Numpy/numpy_main.h"

// Defined in builtins/builtins.cpp: true if `name` is in its builtinTable
// (same case-insensitive matching callBuiltin() uses).
bool isCoreBuiltinName(const std::string &name);

namespace nc {
namespace scipy {

namespace {
const SectionInfo kSections[] = {
    {Section::Clustering, "clustering", "Clustering", "scipy.cluster", 39},
    {Section::Constants, "constants", "Physical & Mathematical Constants", "scipy.constants", 164},
    {Section::Datasets, "datasets", "Datasets", "scipy.datasets", 5},
    {Section::Differentiation, "differentiation", "Differentiation", "scipy.differentiate", 3},
    {Section::FourierTransforms, "fourier_transforms", "Fourier Transforms", "scipy.fft", 41},
    {Section::LegacyFft, "legacy_fft", "Legacy FFT", "scipy.fftpack", 35},
    {Section::IntegrationOdes, "integration_odes", "Integration & ODEs", "scipy.integrate", 33},
    {Section::Interpolation, "interpolation", "Interpolation", "scipy.interpolate", 56},
    {Section::InputOutput, "input_output", "Input / Output", "scipy.io", 34},
    {Section::LinearAlgebra, "linear_algebra", "Linear Algebra", "scipy.linalg", 110},
    {Section::ImageProcessing, "image_processing", "Image Processing", "scipy.ndimage", 75},
    {Section::OrthogonalDistanceRegression, "orthogonal_distance_regression", "Orthogonal Distance Regression", "scipy.odr", 14},
    {Section::OptimizationRootFinding, "optimization_root_finding", "Optimization & Root Finding", "scipy.optimize", 71},
    {Section::SignalProcessing, "signal_processing", "Signal Processing", "scipy.signal", 158},
    {Section::WindowFunctions, "window_functions", "Window Functions", "scipy.signal.windows", 26},
    {Section::SparseMatrices, "sparse_matrices", "Sparse Matrices", "scipy.sparse", 66},
    {Section::SparseLinearAlgebra, "sparse_linear_algebra", "Sparse Linear Algebra", "scipy.sparse.linalg", 38},
    {Section::GraphRoutines, "graph_routines", "Graph Routines", "scipy.sparse.csgraph", 26},
    {Section::SpatialAlgorithms, "spatial_algorithms", "Spatial Algorithms", "scipy.spatial", 52},
    {Section::SpecialFunctions, "special_functions", "Special Functions", "scipy.special", 359},
    {Section::Statistics, "statistics", "Statistics", "scipy.stats", 200},
    {Section::ProbabilityDistributions, "probability_distributions", "Probability Distributions", "scipy.stats", 131},
    {Section::MaskedArrayStatistics, "masked_array_statistics", "Masked-Array Statistics", "scipy.stats.mstats", 73},
    {Section::RemovedSince18, "removed_since_1_8", "Removed Since SciPy 1.8 (with Replacements) - Appendix A", "(various)", 60},
    {Section::BlasLapackWrappers, "blas_lapack_wrappers", "Low-level BLAS & LAPACK Wrappers - Appendix B", "scipy.linalg.blas / lapack", 774},
};
static_assert(sizeof(kSections) / sizeof(kSections[0]) == static_cast<size_t>(Section::Count),
              "kSections must have one row per Section");

std::string lowered(const std::string &s) {
  std::string out = s;
  for (char &c : out)
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  return out;
}

// Same list as Numpy/numpy_registry.cpp (lexer keywords, block terminators,
// parser-intercepted calls) plus the framework commands of both libraries.
const std::unordered_set<std::string> &languageReserved() {
  static const std::unordered_set<std::string> words = {
      // lexer keywords
      "true", "false", "print", "publish", "for", "in", "loop", "if", "else", "while",
      "elseif", "is_in", "is_not_in", "break", "continue", "function", "return", "class",
      "private", "protected", "abstract", "require", "ensure", "reversible",
      // block terminators / statement words
      "iend", "fend", "wend", "fnend", "csend", "new", "clear", "cls", "not",
      // calls handled by the parser before callBuiltin()
      "parent", "feval", "grad", "taylor_series", "green_integral", "save_workspace",
      "load_workspace",
      // framework commands
      "numpy_functions", "numpy_status", "scipy_functions", "scipy_constants",
      "scipy_status"};
  return words;
}
} // namespace

const SectionInfo &sectionInfo(Section s) { return kSections[static_cast<int>(s)]; }

int plannedTotal() {
  int total = 0;
  for (const auto &info : kSections)
    total += info.plannedEntries;
  return total;
}

std::string reservedReason(const std::string &name) {
  std::string low = lowered(name);
  if (languageReserved().count(low))
    return "is reserved by the NC language";
  if (low.size() > 4 && low.rfind("logb", 0) == 0 &&
      low.find_first_not_of("0123456789", 4) == std::string::npos)
    return "belongs to the logbN family (logb2, logb10, ...)";
  if (isCoreBuiltinName(name))
    return "already exists as an NC builtin (ops/) - the existing one is kept";
  if (nc::numpy::isNumpyFunction(name))
    return "already exists as a NumPy function (Numpy/) - the NumPy one is kept";
  return "";
}

void CallContext::fail(const std::string &message) {
  if (ok_)
    std::cerr << "Error: " << name_ << ": " << message << "\n";
  ok_ = false;
}

Registry &Registry::instance() {
  static Registry registry;
  return registry;
}

bool Registry::add(FunctionSpec spec) {
  const char *folder = sectionInfo(spec.section).folder;
  auto reject = [&](const std::string &why) {
    std::cerr << "scipy [" << folder << "]: '" << spec.name << "' " << why << " - skipped\n";
    skipped_[static_cast<int>(spec.section)]++;
    return false;
  };

  if (spec.name.empty() || !spec.impl)
    return reject("has no name or no implementation");

  std::string why = reservedReason(spec.name);
  if (!why.empty())
    return reject(why);

  if (const FunctionSpec *existing = find(spec.name))
    return reject(std::string("is already registered by ") + sectionInfo(existing->section).folder);

  std::string key = lowered(spec.name);
  functions_.emplace(std::move(key), std::move(spec));
  return true;
}

const FunctionSpec *Registry::find(const std::string &name) const {
  auto it = functions_.find(lowered(name));
  return it == functions_.end() ? nullptr : &it->second;
}

bool Registry::addConstant(ConstantSpec spec) {
  auto reject = [&](const std::string &why) {
    std::cerr << "scipy [constants]: '" << spec.name << "' " << why << " - skipped\n";
    skipped_[static_cast<int>(Section::Constants)]++;
    return false;
  };
  if (spec.name.empty())
    return reject("has no name");
  if (languageReserved().count(lowered(spec.name)))
    return reject("is reserved by the NC language");
  if (constants_.count(spec.name))
    return reject("is already registered");
  std::string key = spec.name;
  constants_.emplace(std::move(key), std::move(spec));
  return true;
}

const ConstantSpec *Registry::findConstant(const std::string &name) const {
  auto it = constants_.find(name);
  return it == constants_.end() ? nullptr : &it->second;
}

size_t Registry::countIn(Section s) const {
  size_t n = (s == Section::Constants) ? constants_.size() : 0;
  for (const auto &entry : functions_)
    if (entry.second.section == s)
      n++;
  return n;
}

size_t Registry::skippedIn(Section s) const {
  auto it = skipped_.find(static_cast<int>(s));
  return it == skipped_.end() ? 0 : it->second;
}

std::vector<std::string> Registry::names() const {
  std::vector<std::string> out;
  out.reserve(functions_.size());
  for (const auto &entry : functions_)
    out.push_back(entry.second.name);
  std::sort(out.begin(), out.end());
  return out;
}

std::vector<std::string> Registry::names(Section s) const {
  std::vector<std::string> out;
  for (const auto &entry : functions_)
    if (entry.second.section == s)
      out.push_back(entry.second.name);
  std::sort(out.begin(), out.end());
  return out;
}

std::vector<std::string> Registry::constantNames() const {
  std::vector<std::string> out;
  out.reserve(constants_.size());
  for (const auto &entry : constants_)
    out.push_back(entry.first);
  std::sort(out.begin(), out.end());
  return out;
}

} // namespace scipy
} // namespace nc
