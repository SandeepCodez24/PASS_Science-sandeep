// Section 18 of 25 - Graph Routines
// (scipy.sparse.csgraph, 26 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_GRAPH_ROUTINES_MAIN_H
#define NC_SCIPY_GRAPH_ROUTINES_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Graph Routines entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerGraphRoutines(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_GRAPH_ROUTINES_MAIN_H
