# Collects every .cpp under runtime/interpreter/Scipy/ into NC_SCIPY_SOURCES.
#
# Included from runtime/CMakeLists.txt before RUNTIME_SOURCES is built:
#
#   include(${CMAKE_CURRENT_SOURCE_DIR}/interpreter/Scipy/scipy_sources.cmake)
#   set(RUNTIME_SOURCES ... ${NC_SCIPY_SOURCES} PARENT_SCOPE)
#
# CONFIGURE_DEPENDS: a developer who adds signal_processing/sp_filters.cpp only
# has to rebuild - no CMakeLists.txt edit.
file(GLOB_RECURSE NC_SCIPY_SOURCES CONFIGURE_DEPENDS
     "${CMAKE_CURRENT_LIST_DIR}/*.cpp")
