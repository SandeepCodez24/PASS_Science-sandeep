// Section 17 of 25 - Sparse Linear Algebra
// (scipy.sparse.linalg, 38 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_SPARSE_LINEAR_ALGEBRA_MAIN_H
#define NC_SCIPY_SPARSE_LINEAR_ALGEBRA_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Sparse Linear Algebra entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerSparseLinearAlgebra(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SPARSE_LINEAR_ALGEBRA_MAIN_H
