// Wires the 25 section folders into one registry and dispatches calls.
//
// Adding a function never touches this file - it goes in its section's
// <section>_main.cpp. This file changes only if a whole new section is added.
#include "scipy_main.h"

#include <exception>
#include <iomanip>
#include <iostream>
#include <mutex>

#include "scipy_registry.h"

#include "clustering/clustering_main.h"
#include "constants/constants_main.h"
#include "datasets/datasets_main.h"
#include "differentiation/differentiation_main.h"
#include "fourier_transforms/fourier_transforms_main.h"
#include "legacy_fft/legacy_fft_main.h"
#include "integration_odes/integration_odes_main.h"
#include "interpolation/interpolation_main.h"
#include "input_output/input_output_main.h"
#include "linear_algebra/linear_algebra_main.h"
#include "image_processing/image_processing_main.h"
#include "orthogonal_distance_regression/orthogonal_distance_regression_main.h"
#include "optimization_root_finding/optimization_root_finding_main.h"
#include "signal_processing/signal_processing_main.h"
#include "window_functions/window_functions_main.h"
#include "sparse_matrices/sparse_matrices_main.h"
#include "sparse_linear_algebra/sparse_linear_algebra_main.h"
#include "graph_routines/graph_routines_main.h"
#include "spatial_algorithms/spatial_algorithms_main.h"
#include "special_functions/special_functions_main.h"
#include "statistics/statistics_main.h"
#include "probability_distributions/probability_distributions_main.h"
#include "masked_array_statistics/masked_array_statistics_main.h"
#include "removed_since_1_8/removed_since_1_8_main.h"
#include "blas_lapack_wrappers/blas_lapack_wrappers_main.h"

namespace nc {
namespace scipy {

namespace {

// Framework commands, not part of the 2643:
//   scipy_functions()                 -> array of every registered function name
//   scipy_functions("signal_processing") -> names in one section
//   scipy_constants()                 -> array of every registered constant name
//   scipy_status()                    -> prints done / skipped / planned per section
const char *kListFn = "scipy_functions";
const char *kConstFn = "scipy_constants";
const char *kStatusFn = "scipy_status";

bool sectionByFolder(const std::string &folder, Section &out) {
  for (int i = 0; i < static_cast<int>(Section::Count); i++) {
    Section s = static_cast<Section>(i);
    if (folder == sectionInfo(s).folder) {
      out = s;
      return true;
    }
  }
  return false;
}

std::string argCountText(int minArgs, int maxArgs) {
  if (maxArgs == kVariadic)
    return "at least " + std::to_string(minArgs);
  if (minArgs == maxArgs)
    return std::to_string(minArgs);
  return std::to_string(minArgs) + " to " + std::to_string(maxArgs);
}

Value namesToArray(const std::vector<std::string> &names) {
  std::vector<Value> out;
  out.reserve(names.size());
  for (const auto &n : names)
    out.push_back(Value(n));
  return Value(out);
}

Value listFunctions(const std::vector<Value> &args, bool &ok) {
  const Registry &reg = Registry::instance();
  if (args.empty())
    return namesToArray(reg.names());
  if (args.size() == 1 && args[0].isText) {
    Section s;
    if (sectionByFolder(args[0].text(), s))
      return namesToArray(reg.names(s));
    std::cerr << "Error: " << kListFn << ": unknown section '" << args[0].text()
              << "' - use a folder name such as \"signal_processing\"\n";
  } else {
    std::cerr << "Error: " << kListFn << " expects no arguments or one section name in quotes\n";
  }
  ok = false;
  return Value(0.0);
}

Value listConstants(const std::vector<Value> &args, bool &ok) {
  if (!args.empty()) {
    std::cerr << "Error: " << kConstFn << " takes no arguments\n";
    ok = false;
    return Value(0.0);
  }
  return namesToArray(Registry::instance().constantNames());
}

Value printStatus(const std::vector<Value> &args, bool &ok) {
  if (!args.empty()) {
    std::cerr << "Error: " << kStatusFn << " takes no arguments\n";
    ok = false;
    return Value(0.0);
  }
  const Registry &reg = Registry::instance();
  size_t done = 0, skipped = 0;
  std::cout << std::left << std::setw(4) << "#" << std::setw(34) << "section" << std::right
            << std::setw(6) << "done" << std::setw(9) << "skipped" << std::setw(9) << "planned"
            << "\n";
  for (int i = 0; i < static_cast<int>(Section::Count); i++) {
    const SectionInfo &info = sectionInfo(static_cast<Section>(i));
    done += reg.countIn(info.section);
    skipped += reg.skippedIn(info.section);
    std::cout << std::left << std::setw(4) << (i + 1) << std::setw(34) << info.folder
              << std::right << std::setw(6) << reg.countIn(info.section) << std::setw(9)
              << reg.skippedIn(info.section) << std::setw(9) << info.plannedEntries << "\n";
  }
  std::cout << std::left << std::setw(38) << "    total" << std::right << std::setw(6) << done
            << std::setw(9) << skipped << std::setw(9) << plannedTotal() << std::endl;
  return Value(static_cast<double>(done));
}

} // namespace

void initialize() {
  static std::once_flag once;
  std::call_once(once, [] {
    Registry &reg = Registry::instance();
    registerClustering(reg);
    registerConstants(reg);
    registerDatasets(reg);
    registerDifferentiation(reg);
    registerFourierTransforms(reg);
    registerLegacyFft(reg);
    registerIntegrationOdes(reg);
    registerInterpolation(reg);
    registerInputOutput(reg);
    registerLinearAlgebra(reg);
    registerImageProcessing(reg);
    registerOrthogonalDistanceRegression(reg);
    registerOptimizationRootFinding(reg);
    registerSignalProcessing(reg);
    registerWindowFunctions(reg);
    registerSparseMatrices(reg);
    registerSparseLinearAlgebra(reg);
    registerGraphRoutines(reg);
    registerSpatialAlgorithms(reg);
    registerSpecialFunctions(reg);
    registerStatistics(reg);
    registerProbabilityDistributions(reg);
    registerMaskedArrayStatistics(reg);
    registerRemovedSince18(reg);
    registerBlasLapackWrappers(reg);
  });
}

bool isScipyFunction(const std::string &name) {
  initialize();
  return name == kListFn || name == kConstFn || name == kStatusFn ||
         Registry::instance().contains(name);
}

bool tryConstant(const std::string &name, double &out) {
  initialize();
  const ConstantSpec *c = Registry::instance().findConstant(name);
  if (!c)
    return false;
  out = c->value;
  return true;
}

bool tryCall(const std::string &name, const std::vector<Value> &args, Value &out, bool &ok) {
  initialize();

  if (name == kListFn || name == kConstFn || name == kStatusFn) {
    ok = true;
    out = (name == kListFn)    ? listFunctions(args, ok)
          : (name == kConstFn) ? listConstants(args, ok)
                               : printStatus(args, ok);
    return true;
  }

  const FunctionSpec *spec = Registry::instance().find(name);
  if (!spec)
    return false;

  ok = true;
  out = Value(0.0);

  int argc = static_cast<int>(args.size());
  if (argc < spec->minArgs || (spec->maxArgs != kVariadic && argc > spec->maxArgs)) {
    std::cerr << "Error: " << spec->name << " expects "
              << argCountText(spec->minArgs, spec->maxArgs) << " argument(s), got " << argc;
    if (!spec->signature.empty())
      std::cerr << " - usage: " << spec->signature;
    std::cerr << "\n";
    ok = false;
    return true;
  }

  if (!spec->acceptsComplex) {
    for (const Value &a : args) {
      if (a.hasComplex()) {
        std::cerr << "Error: '" << spec->name << "' does not support complex numbers yet\n";
        ok = false;
        return true;
      }
    }
  }

  CallContext ctx(spec->name);
  Value result;
  try {
    result = spec->impl(args, ctx);
  } catch (const std::exception &e) {
    ctx.fail(std::string("internal error: ") + e.what());
  } catch (...) {
    ctx.fail("internal error");
  }

  if (!ctx.ok()) {
    ok = false;
    return true;
  }
  out = std::move(result);
  return true;
}

} // namespace scipy
} // namespace nc
