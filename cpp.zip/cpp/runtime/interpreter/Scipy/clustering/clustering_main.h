// Section 1 of 25 - Clustering
// (scipy.cluster, 39 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_CLUSTERING_MAIN_H
#define NC_SCIPY_CLUSTERING_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Clustering entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerClustering(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_CLUSTERING_MAIN_H
