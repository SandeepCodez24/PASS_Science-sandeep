// Section 1 of 25 - Clustering
// SciPy module: scipy.cluster
// Planned entries: 39  (check progress from NC with: scipy_status())
//
// This file is the ONE place where this section's entries are mapped to NC
// names. Nothing outside this folder needs to change when you add one.
//
// How to add a function
//   1. Write the code in this folder. Small functions can live right here;
//      for a group of related functions add a file pair, e.g.
//        clustering/c_<group>.h / .cpp  ->  void register<Group>(Registry &reg);
//      and call register<Group>(reg) from registerClustering() below.
//   2. Register it with reg.add({...}) - see the example at the bottom.
//   3. Rebuild. New .cpp files in this folder are picked up automatically
//      (Scipy/scipy_sources.cmake globs the whole Scipy tree).
//   4. Try it in NC:   scipy_functions("clustering")   lists what you added.
//
// Rules
//   - Use the NC name from the team's agreed name list (names are matched
//     case-insensitively, like every other builtin).
//   - Arguments are positional only (NC has no name=value arguments yet).
//   - Report bad input with ctx.fail("...") and return; never print errors
//     yourself and never throw on user mistakes.
//   - Never modify `args`; build and return a new Value.
//   - A name can be registered only once across all 25 sections.
//   - A name already used by an NC builtin (ops/), by a NumPy function
//     (Numpy/), by an NC keyword or a parser-reserved call is skipped: the
//     existing one stays. The reason is printed at startup and
//     scipy_status() counts it.
#include "clustering_main.h"

#include "../scipy_common.h"

namespace nc {
namespace scipy {

void registerClustering(Registry &reg) {
  (void)reg; // remove once the first entry is registered

  // ---- example (copy, rename, then delete this comment block) -------------
  //
  // reg.add({
  //     "example_scale",                    // NC name (from the team's name list)
  //     Section::Clustering,
  //     2, 2,                               // min / max argument count
  //     "example_scale(x, k)",              // usage shown in errors
  //     "multiply every element by k",      // one-line summary
  //     "scipy.cluster.<original>",              // SciPy original
  //     [](const std::vector<Value> &args, CallContext &ctx) -> Value {
  //       std::vector<double> x;
  //       double k = 0.0;
  //       if (!argNumbers(args, 0, ctx, x) || !argNumber(args, 1, ctx, k))
  //         return Value(0.0);
  //       for (double &v : x)
  //         v *= k;
  //       return makeArray(x);
  //     },
  // });
}

} // namespace scipy
} // namespace nc
