// Section 22 of 25 - Probability Distributions
// (scipy.stats, 131 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_PROBABILITY_DISTRIBUTIONS_MAIN_H
#define NC_SCIPY_PROBABILITY_DISTRIBUTIONS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Probability Distributions entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerProbabilityDistributions(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_PROBABILITY_DISTRIBUTIONS_MAIN_H
