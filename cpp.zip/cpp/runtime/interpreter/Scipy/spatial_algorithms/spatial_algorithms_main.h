// Section 19 of 25 - Spatial Algorithms
// (scipy.spatial, 52 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_SPATIAL_ALGORITHMS_MAIN_H
#define NC_SCIPY_SPATIAL_ALGORITHMS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Spatial Algorithms entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerSpatialAlgorithms(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SPATIAL_ALGORITHMS_MAIN_H
