// Section 11 of 25 - Image Processing
// (scipy.ndimage, 75 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_IMAGE_PROCESSING_MAIN_H
#define NC_SCIPY_IMAGE_PROCESSING_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Image Processing entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerImageProcessing(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_IMAGE_PROCESSING_MAIN_H
