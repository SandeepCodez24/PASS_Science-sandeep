// Section 9 of 25 - Input / Output
// (scipy.io, 34 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_INPUT_OUTPUT_MAIN_H
#define NC_SCIPY_INPUT_OUTPUT_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Input / Output entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerInputOutput(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_INPUT_OUTPUT_MAIN_H
