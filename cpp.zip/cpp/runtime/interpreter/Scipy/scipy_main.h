// Entry point of the SciPy-equivalent library. The rest of the interpreter
// talks to the Scipy folder ONLY through this header:
//
//   builtins/builtins.cpp   callBuiltin()  ->  tryCall()
//
// tryConstant() (scipy.constants) is not wired into the interpreter yet -
// the constants design is pending.
//
// Everything else (the 25 sections, the registry, helpers) stays private to
// the folder, so section developers never touch interpreter files.
#ifndef NC_SCIPY_MAIN_H
#define NC_SCIPY_MAIN_H

#include <string>
#include <vector>

#include "../core/value.h"

namespace nc {
namespace scipy {

// Registers all 25 sections. Runs once; tryCall()/tryConstant() call it on
// first use, so calling it explicitly is optional.
void initialize();

// If `name` is a SciPy function (or scipy_functions / scipy_constants /
// scipy_status): checks the arguments, runs it, stores the result in `out`,
// sets `ok` (false = an error was printed and the statement must stop), and
// returns true. Otherwise returns false and touches nothing.
bool tryCall(const std::string &name, const std::vector<Value> &args, Value &out, bool &ok);

// If `name` is a registered scipy.constants value, stores it in `out` and
// returns true.
bool tryConstant(const std::string &name, double &out);

bool isScipyFunction(const std::string &name);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_MAIN_H
