// Section 5 of 25 - Fourier Transforms
// (scipy.fft, 41 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_FOURIER_TRANSFORMS_MAIN_H
#define NC_SCIPY_FOURIER_TRANSFORMS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Fourier Transforms entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerFourierTransforms(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_FOURIER_TRANSFORMS_MAIN_H
