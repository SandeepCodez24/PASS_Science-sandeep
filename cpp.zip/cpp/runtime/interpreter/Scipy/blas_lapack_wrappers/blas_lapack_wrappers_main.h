// Section 25 of 25 - Low-level BLAS & LAPACK Wrappers - Appendix B
// (scipy.linalg.blas / lapack, 774 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_BLAS_LAPACK_WRAPPERS_MAIN_H
#define NC_SCIPY_BLAS_LAPACK_WRAPPERS_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Low-level BLAS & LAPACK Wrappers entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerBlasLapackWrappers(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_BLAS_LAPACK_WRAPPERS_MAIN_H
