// Section 16 of 25 - Sparse Matrices
// (scipy.sparse, 66 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_SPARSE_MATRICES_MAIN_H
#define NC_SCIPY_SPARSE_MATRICES_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Sparse Matrices entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerSparseMatrices(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_SPARSE_MATRICES_MAIN_H
