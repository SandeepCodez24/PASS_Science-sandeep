// Section 13 of 25 - Optimization & Root Finding
// (scipy.optimize, 71 planned entries). Only scipy_main.cpp includes this header.
#ifndef NC_SCIPY_OPTIMIZATION_ROOT_FINDING_MAIN_H
#define NC_SCIPY_OPTIMIZATION_ROOT_FINDING_MAIN_H

#include "../scipy_registry.h"

namespace nc {
namespace scipy {

// Adds every Optimization & Root Finding entry to the registry. Called once by
// nc::scipy::initialize() (scipy_main.cpp).
void registerOptimizationRootFinding(Registry &reg);

} // namespace scipy
} // namespace nc

#endif // NC_SCIPY_OPTIMIZATION_ROOT_FINDING_MAIN_H
