#pragma once

// Cooperative "Stop" for a running command.
//
// The IDE (Java) cannot send a real Ctrl+C to nc.exe on Windows - the
// process runs on pipes, not a console. Instead it creates an empty file,
// <session dir>/interrupt.flag. The interpreter looks for that file at safe
// points - before each statement (Parser::executeStmtList), between the
// top-level statements of a script, and on every iteration of a
// JIT-compiled loop (nc_bridge_poll_interrupt) - and, once it has seen it,
// unwinds the current command back to the prompt. Variables assigned
// before the stop are kept; the workspace stays exactly as the interrupted
// command left it.
//
// The request is sticky: once seen it stays set until the REPL clears it
// just before printing the next prompt (main.cpp), so every level of a
// nested call/loop stops in turn instead of only the innermost one.
//
// A builtin that runs for a long time without returning (a huge matrix
// inverse, say) cannot be interrupted this way; the IDE falls back to
// killing and restarting nc.exe if no prompt comes back in time, and the
// session autosave (DataEngine) restores the workspace.
//
// No threads are involved: checking is a cheap counter test, with a file
// check at most every few milliseconds of statement execution.

#include <string>

namespace nc {

class Interrupt {
public:
  // Where the IDE drops the flag file. An empty directory disables file
  // checks entirely (plain terminal use of nc.exe).
  static void configure(const std::string &sessionDirectory);

  // Safe-point check: true once a stop has been requested. Cheap enough to
  // call before every statement and every loop iteration.
  static bool poll();

  // Same as poll(), but always looks at the flag file now.
  static bool pollNow();

  // The sticky state, without looking at the file.
  static bool requested();

  // Forgets a request and deletes a leftover flag file. Called by the REPL
  // before each prompt.
  static void clear();

  // Raises the request directly (tests, or a future signal handler).
  static void request();
};

} // namespace nc
