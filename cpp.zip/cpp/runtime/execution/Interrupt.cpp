#include "Interrupt.h"

#include <chrono>
#include <filesystem>
#include <system_error>

namespace nc {

namespace {

bool g_requested = false;
bool g_enabled = false;
std::filesystem::path g_flagPath;

// Statements between two clock reads, and the minimum time between two
// file checks. A file check costs a system call; a clock read is cheap but
// not free, so it is also only done every kCallsPerClockRead calls.
constexpr unsigned kCallsPerClockRead = 16;
constexpr auto kFileCheckInterval = std::chrono::milliseconds(30);

unsigned g_calls = 0;
std::chrono::steady_clock::time_point g_lastFileCheck{};

bool checkFlagFile() {
  g_lastFileCheck = std::chrono::steady_clock::now();
  std::error_code ec;
  if (!std::filesystem::exists(g_flagPath, ec))
    return false;
  std::filesystem::remove(g_flagPath, ec);
  return true;
}

} // namespace

void Interrupt::configure(const std::string &sessionDirectory) {
  g_enabled = !sessionDirectory.empty();
  g_flagPath = g_enabled ? std::filesystem::path(sessionDirectory) / "interrupt.flag"
                         : std::filesystem::path();
}

bool Interrupt::poll() {
  if (g_requested || !g_enabled)
    return g_requested;
  if (++g_calls % kCallsPerClockRead != 0)
    return false;
  if (std::chrono::steady_clock::now() - g_lastFileCheck < kFileCheckInterval)
    return false;
  if (checkFlagFile())
    g_requested = true;
  return g_requested;
}

bool Interrupt::pollNow() {
  if (!g_requested && g_enabled && checkFlagFile())
    g_requested = true;
  return g_requested;
}

bool Interrupt::requested() { return g_requested; }

void Interrupt::clear() {
  g_requested = false;
  g_calls = 0;
  if (g_enabled) {
    std::error_code ec;
    std::filesystem::remove(g_flagPath, ec);
  }
}

void Interrupt::request() { g_requested = true; }

} // namespace nc
