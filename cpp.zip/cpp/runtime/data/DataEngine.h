#pragma once

// DataEngine - the interpreter's data layer.
//
// It owns the two ways the global workspace (Parser::globalMemory(), a
// std::unordered_map<std::string, Value> plus its insertion order) leaves
// the interpreter:
//
//  1. RUNTIME, to the IDE: a JSON channel on stdout (WS_PROTOCOL.md).
//     Before each prompt the REPL calls emitWorkspaceIfChanged(); when the
//     workspace differs from what the IDE last saw, one line
//         \x1E@WS {"v":1,"type":"ws","vars":[...]}
//     goes out with a summary of every variable. The full value of one
//     variable is sent on request (@cmd getvar <name>) as \x1E@VAR {...}.
//     The ASCII Record Separator in front keeps these lines apart from
//     anything a script prints.
//
//  2. PERSISTENT, on disk: the .ndat binary format (NDAT_FORMAT.md),
//     written by save_workspace([path]) and read by load_workspace([path]),
//     plus a session autosave the IDE uses to restore the workspace if it
//     ever has to restart nc.exe.
//
// Everything specific to bytes and text lives in DataSupport/; this class
// only decides what to send or store and when.
//
// Environment (set by the IDE when it launches nc.exe):
//   NC_SESSION_DIR  folder for this IDE session's files (autosave.ndat,
//                   interrupt.flag). Also switches the @WS channel on - a
//                   plain terminal user never sees protocol lines.
//   NC_RESTORE=1    load the session autosave at startup.

#include <cstdint>
#include <filesystem>
#include <string>
#include <unordered_map>
#include <vector>

#include "../interpreter/core/value.h"

namespace ncdata {

using Workspace = std::unordered_map<std::string, Value>;
using WorkspaceOrder = std::vector<std::string>;

// Outcome of save_workspace / load_workspace. `message` is the line to
// print: the success report, or the error text (without "Error: ").
struct WorkspaceIoResult {
  bool ok = false;
  std::string message;
  std::filesystem::path path;
  std::size_t count = 0;
};

class DataEngine {
public:
  static DataEngine &instance();

  // True for the NC call names DataEngine implements (save_workspace,
  // load_workspace).
  static bool isWorkspaceCommand(const std::string &name);

  /* ---- configuration ---- */

  // Reads NC_SESSION_DIR (and creates the folder). Call once at startup.
  void configureFromEnvironment();

  // True when the IDE launched this process (NC_SESSION_DIR set).
  bool ideMode() const { return !sessionDir_.empty(); }
  const std::filesystem::path &sessionDir() const { return sessionDir_; }

  // The folder relative file names are resolved against - the IDE's
  // current folder, updated by "@cmd setpwd".
  void setCurrentFolder(const std::filesystem::path &folder);
  const std::filesystem::path &currentFolder() const { return currentFolder_; }

  // "" -> <current folder>/workspace.ndat; a relative path is taken from
  // the current folder; ".ndat" is added when the name has no extension.
  std::filesystem::path resolveUserPath(const std::string &userPath) const;

  /* ---- persistent storage (.ndat) ---- */

  WorkspaceIoResult saveWorkspace(const Workspace &vars, const WorkspaceOrder &order,
                                  const std::string &userPath);

  // Merges the file's variables into `vars` (a variable already present is
  // replaced; new ones are added at the end of `order`).
  WorkspaceIoResult loadWorkspace(const std::string &userPath, Workspace &vars,
                                  WorkspaceOrder &order);

  // NC_RESTORE=1 at startup: loads the session autosave, if there is one.
  // Returns the number of variables restored.
  std::size_t restoreSessionIfRequested(Workspace &vars, WorkspaceOrder &order);

  /* ---- runtime channel to the IDE ---- */

  // Sends @WS when the workspace changed since the last one sent (or
  // always, with force), and refreshes the session autosave when the
  // workspace changed since it was last written. No-op outside IDE mode
  // unless forced.
  void emitWorkspaceIfChanged(const Workspace &vars, const WorkspaceOrder &order,
                              bool force = false);

  // Sends @VAR with the full value of one variable ("found": false when
  // there is no such variable).
  void emitVariable(const std::string &name, const Workspace &vars);

private:
  DataEngine();

  struct Entry {
    const std::string *name;
    const Value *value;
    uint64_t hash;
  };

  // The variables in display order: insertion order first, then any name
  // `order` is missing (sorted), skipping names no longer present.
  std::vector<Entry> snapshot(const Workspace &vars, const WorkspaceOrder &order) const;
  static uint64_t signatureOf(const std::vector<Entry> &entries);
  void writeAutosave(const std::vector<Entry> &entries);

  std::filesystem::path sessionDir_;
  std::filesystem::path currentFolder_;

  bool haveSentWorkspace_ = false;
  uint64_t lastSentSignature_ = 0;
  bool haveAutosaved_ = false;
  uint64_t lastAutosaveSignature_ = 0;
};

} // namespace ncdata
