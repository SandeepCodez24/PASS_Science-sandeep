#pragma once

// Decoding .ndat files back into runtime Values (see NDAT_FORMAT.md).
// A file is untrusted input: every length is checked against the bytes
// actually present, nesting depth is capped, and the CRC-32 footer is
// verified before anything is decoded.

#include <filesystem>
#include <string>
#include <utility>
#include <vector>

#include "../../interpreter/core/value.h"
#include "BinaryIO.h"

namespace ncdata {

// Variables in file order.
using NamedValues = std::vector<std::pair<std::string, Value>>;

// Reads a whole .ndat file. False with `err` set (corrupt file, a newer
// major version, a type this build cannot represent, I/O failure).
bool readNdatFile(const std::filesystem::path &path, NamedValues &out, std::string &err);

// Decodes a .ndat image already in memory (header, records and footer).
bool readNdatImage(const std::vector<uint8_t> &image, NamedValues &out, std::string &err);

// Decodes one value node at the reader's position.
bool readValueNode(ByteReader &in, Value &out, std::string &err, int depth = 0);

} // namespace ncdata
