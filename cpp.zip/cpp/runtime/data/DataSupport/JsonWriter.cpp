#include "JsonWriter.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace ncdata {

namespace {

// Length of the valid UTF-8 sequence starting at s[i], or 0 if the bytes
// there are not one (overlong forms, surrogates and values past U+10FFFF
// count as invalid, per RFC 3629).
std::size_t utf8SequenceLength(const std::string &s, std::size_t i) {
  const auto byte = [&](std::size_t k) { return static_cast<unsigned char>(s[k]); };
  const unsigned char b0 = byte(i);
  const std::size_t left = s.size() - i;
  auto cont = [&](std::size_t k) { return k < s.size() && (byte(k) & 0xC0) == 0x80; };
  if (b0 < 0x80)
    return 1;
  if (b0 >= 0xC2 && b0 <= 0xDF)
    return left >= 2 && cont(i + 1) ? 2 : 0;
  if (b0 >= 0xE0 && b0 <= 0xEF) {
    if (left < 3 || !cont(i + 1) || !cont(i + 2))
      return 0;
    const unsigned char b1 = byte(i + 1);
    if (b0 == 0xE0 && b1 < 0xA0)
      return 0; // overlong
    if (b0 == 0xED && b1 >= 0xA0)
      return 0; // UTF-16 surrogate
    return 3;
  }
  if (b0 >= 0xF0 && b0 <= 0xF4) {
    if (left < 4 || !cont(i + 1) || !cont(i + 2) || !cont(i + 3))
      return 0;
    const unsigned char b1 = byte(i + 1);
    if (b0 == 0xF0 && b1 < 0x90)
      return 0; // overlong
    if (b0 == 0xF4 && b1 >= 0x90)
      return 0; // past U+10FFFF
    return 4;
  }
  return 0;
}

} // namespace

void JsonWriter::appendQuoted(std::string &out, const std::string &s) {
  static const char *hex = "0123456789abcdef";
  out.push_back('"');
  std::size_t i = 0;
  while (i < s.size()) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    if (c < 0x80) {
      switch (c) {
      case '"':
        out += "\\\"";
        break;
      case '\\':
        out += "\\\\";
        break;
      case '\n':
        out += "\\n";
        break;
      case '\r':
        out += "\\r";
        break;
      case '\t':
        out += "\\t";
        break;
      case '\b':
        out += "\\b";
        break;
      case '\f':
        out += "\\f";
        break;
      default:
        if (c < 0x20 || c == 0x7F) {
          out += "\\u00";
          out.push_back(hex[c >> 4]);
          out.push_back(hex[c & 0xF]);
        } else {
          out.push_back(static_cast<char>(c));
        }
      }
      i++;
      continue;
    }
    const std::size_t len = utf8SequenceLength(s, i);
    if (len == 0) {
      out += "\xEF\xBF\xBD"; // U+FFFD for one bad byte
      i++;
    } else {
      out.append(s, i, len);
      i += len;
    }
  }
  out.push_back('"');
}

std::string JsonWriter::shortestDouble(double d) {
  if (d == 0.0)
    return std::signbit(d) ? "-0.0" : "0";
  char buf[40];
  for (int precision = 15; precision <= 17; precision++) {
    std::snprintf(buf, sizeof buf, "%.*g", precision, d);
    if (std::strtod(buf, nullptr) == d)
      break;
  }
  return buf;
}

void JsonWriter::separate() {
  if (afterKey_) {
    afterKey_ = false;
    return;
  }
  if (!nonEmpty_.empty()) {
    if (nonEmpty_.back())
      out_.push_back(',');
    nonEmpty_.back() = true;
  }
}

void JsonWriter::beginObject() {
  separate();
  out_.push_back('{');
  nonEmpty_.push_back(false);
}

void JsonWriter::endObject() {
  out_.push_back('}');
  nonEmpty_.pop_back();
}

void JsonWriter::beginArray() {
  separate();
  out_.push_back('[');
  nonEmpty_.push_back(false);
}

void JsonWriter::endArray() {
  out_.push_back(']');
  nonEmpty_.pop_back();
}

JsonWriter &JsonWriter::key(const std::string &k) {
  separate();
  appendQuoted(out_, k);
  out_.push_back(':');
  afterKey_ = true;
  return *this;
}

void JsonWriter::string(const std::string &s) {
  separate();
  appendQuoted(out_, s);
}

void JsonWriter::number(double d) {
  if (std::isnan(d)) {
    string("NaN");
    return;
  }
  if (std::isinf(d)) {
    string(d > 0 ? "Infinity" : "-Infinity");
    return;
  }
  separate();
  out_ += shortestDouble(d);
}

void JsonWriter::integer(int64_t i) {
  separate();
  out_ += std::to_string(i);
}

void JsonWriter::unsignedInteger(uint64_t u) {
  separate();
  out_ += std::to_string(u);
}

void JsonWriter::boolean(bool b) {
  separate();
  out_ += b ? "true" : "false";
}

void JsonWriter::null() {
  separate();
  out_ += "null";
}

} // namespace ncdata
