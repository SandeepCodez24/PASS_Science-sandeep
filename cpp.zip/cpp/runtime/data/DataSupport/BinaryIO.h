#pragma once

// Little-endian byte encoding shared by the .ndat writer and reader, plus
// the two checksums the data layer uses:
//   - CRC-32 (IEEE 802.3, the zlib/PNG one) - the .ndat file footer.
//   - FNV-1a 64 - per-variable change detection for the IDE channel.
//
// Everything is written byte by byte in little-endian order regardless of
// the machine, so a file written on one platform reads on any other. Bulk
// float64 data takes a memcpy fast path on little-endian hosts.

#include <cstdint>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

namespace ncdata {

/* ================= checksums ================= */

class Crc32 {
public:
  void update(const uint8_t *data, std::size_t n) {
    static const Table table;
    uint32_t c = state_;
    for (std::size_t i = 0; i < n; i++)
      c = table.entries[(c ^ data[i]) & 0xFFu] ^ (c >> 8);
    state_ = c;
  }
  uint32_t value() const { return state_ ^ 0xFFFFFFFFu; }

private:
  struct Table {
    uint32_t entries[256];
    Table() {
      for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++)
          c = (c & 1u) ? 0xEDB88320u ^ (c >> 1) : (c >> 1);
        entries[i] = c;
      }
    }
  };
  uint32_t state_ = 0xFFFFFFFFu;
};

class Fnv1a64 {
public:
  void update(const uint8_t *data, std::size_t n) {
    uint64_t h = state_;
    for (std::size_t i = 0; i < n; i++) {
      h ^= data[i];
      h *= 0x100000001B3ull;
    }
    state_ = h;
  }
  uint64_t value() const { return state_; }

private:
  uint64_t state_ = 0xCBF29CE484222325ull;
};

/* ================= output ================= */

// Where encoded bytes go. The writer encodes a value once and the sink
// decides what happens to the bytes: a file, a memory buffer, or only a
// running hash (change detection never builds the bytes at all).
class ByteSink {
public:
  virtual ~ByteSink() = default;
  virtual void write(const uint8_t *data, std::size_t n) = 0;

  void u8(uint8_t v) { write(&v, 1); }
  void u16(uint16_t v) {
    uint8_t b[2] = {static_cast<uint8_t>(v), static_cast<uint8_t>(v >> 8)};
    write(b, 2);
  }
  void u32(uint32_t v) {
    uint8_t b[4];
    for (int i = 0; i < 4; i++)
      b[i] = static_cast<uint8_t>(v >> (8 * i));
    write(b, 4);
  }
  void u64(uint64_t v) {
    uint8_t b[8];
    for (int i = 0; i < 8; i++)
      b[i] = static_cast<uint8_t>(v >> (8 * i));
    write(b, 8);
  }
  void i16(int16_t v) { u16(static_cast<uint16_t>(v)); }
  void f64(double v) {
    uint64_t bits;
    std::memcpy(&bits, &v, sizeof bits);
    u64(bits);
  }
  // `n` consecutive float64 values.
  void f64Array(const double *data, std::size_t n) {
    if (hostIsLittleEndian()) {
      write(reinterpret_cast<const uint8_t *>(data), n * sizeof(double));
      return;
    }
    for (std::size_t i = 0; i < n; i++)
      f64(data[i]);
  }
  void bytes(const std::string &s) {
    write(reinterpret_cast<const uint8_t *>(s.data()), s.size());
  }

  static bool hostIsLittleEndian() {
    const uint16_t probe = 1;
    uint8_t first;
    std::memcpy(&first, &probe, 1);
    return first == 1;
  }
};

class VectorSink : public ByteSink {
public:
  void write(const uint8_t *data, std::size_t n) override {
    buffer.insert(buffer.end(), data, data + n);
  }
  std::vector<uint8_t> buffer;
};

class HashSink : public ByteSink {
public:
  void write(const uint8_t *data, std::size_t n) override { hash.update(data, n); }
  Fnv1a64 hash;
};

// A file, with the CRC-32 of everything written so far kept alongside.
class FileSink : public ByteSink {
public:
  explicit FileSink(std::ofstream &out) : out_(out) {}
  void write(const uint8_t *data, std::size_t n) override {
    crc.update(data, n);
    out_.write(reinterpret_cast<const char *>(data), static_cast<std::streamsize>(n));
  }
  Crc32 crc;

private:
  std::ofstream &out_;
};

/* ================= input ================= */

// Bounds-checked little-endian reader over a byte buffer. A read past the
// end never touches memory outside the buffer: it marks the reader failed
// and returns zero, and the caller checks ok() at its own pace.
class ByteReader {
public:
  ByteReader(const uint8_t *data, std::size_t size) : data_(data), size_(size) {}

  bool ok() const { return ok_; }
  std::size_t offset() const { return pos_; }
  std::size_t remaining() const { return size_ - pos_; }

  // Marks the reader failed (a structural error found by the caller).
  void fail() { ok_ = false; }

  bool need(std::size_t n) {
    if (!ok_ || n > size_ - pos_) {
      ok_ = false;
      return false;
    }
    return true;
  }

  uint8_t u8() { return need(1) ? data_[pos_++] : 0; }
  uint16_t u16() {
    if (!need(2))
      return 0;
    uint16_t v = static_cast<uint16_t>(data_[pos_] | (data_[pos_ + 1] << 8));
    pos_ += 2;
    return v;
  }
  uint32_t u32() {
    if (!need(4))
      return 0;
    uint32_t v = 0;
    for (int i = 0; i < 4; i++)
      v |= static_cast<uint32_t>(data_[pos_ + i]) << (8 * i);
    pos_ += 4;
    return v;
  }
  uint64_t u64() {
    if (!need(8))
      return 0;
    uint64_t v = 0;
    for (int i = 0; i < 8; i++)
      v |= static_cast<uint64_t>(data_[pos_ + i]) << (8 * i);
    pos_ += 8;
    return v;
  }
  int16_t i16() { return static_cast<int16_t>(u16()); }
  double f64() {
    uint64_t bits = u64();
    double v;
    std::memcpy(&v, &bits, sizeof v);
    return v;
  }
  bool f64Array(double *out, std::size_t n) {
    if (n > remaining() / sizeof(double)) {
      ok_ = false;
      return false;
    }
    if (ByteSink::hostIsLittleEndian()) {
      std::memcpy(out, data_ + pos_, n * sizeof(double));
      pos_ += n * sizeof(double);
      return true;
    }
    for (std::size_t i = 0; i < n; i++)
      out[i] = f64();
    return ok_;
  }
  std::string bytes(std::size_t n) {
    if (!need(n))
      return std::string();
    std::string s(reinterpret_cast<const char *>(data_ + pos_), n);
    pos_ += n;
    return s;
  }
  bool skip(std::size_t n) {
    if (!need(n))
      return false;
    pos_ += n;
    return true;
  }

private:
  const uint8_t *data_;
  std::size_t size_;
  std::size_t pos_ = 0;
  bool ok_ = true;
};

} // namespace ncdata
