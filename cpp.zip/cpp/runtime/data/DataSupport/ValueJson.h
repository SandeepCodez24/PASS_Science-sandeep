#pragma once

// Runtime Values as JSON for the IDE (WS_PROTOCOL.md).
//
// Two shapes:
//   - a SUMMARY per variable (name, class, size, unit, short preview,
//     fingerprint) - small, sent for the whole workspace whenever it
//     changes, drives the Variable Explorer;
//   - the FULL value, sent for one variable on request (@cmd getvar) -
//     for viewers, plots and editors that need the actual data.

#include <cstddef>
#include <cstdint>
#include <string>

#include "../../interpreter/core/value.h"
#include "JsonWriter.h"

namespace ncdata {

struct VariableSummary {
  std::string name;
  std::string cls;     // "float64", "float32", "int64", "bool", "string", "complex", "cell", "dict", class name, ...
  std::string size;    // "1x1", "1x5", "3x4"
  std::string unit;    // "m/s", or empty
  std::string preview; // display text, length-capped
  uint64_t hash = 0;   // valueFingerprint()
};

VariableSummary summarizeVariable(const std::string &name, const Value &v, uint64_t hash);

void writeSummaryJson(JsonWriter &out, const VariableSummary &s);

// The full value. At most `elementBudget` numeric/cell elements are written
// in total; past that a container is written without its data and with
// "truncated": true. The budget is decremented as elements are written.
void writeValueJson(JsonWriter &out, const Value &v, std::size_t &elementBudget, int depth = 0);

// Pieces of the summary, exposed for tests and other callers.
std::string classOf(const Value &v);
std::string sizeOf(const Value &v);
std::string previewOf(const Value &v);

} // namespace ncdata
