#pragma once

// Constants of the .ndat on-disk format, version 1.0.
// The full layout is described in runtime/data/NDAT_FORMAT.md; this header
// is its single source of truth in code. Type tags are FORMAT constants:
// once a file has been written with a tag, that tag keeps its meaning
// forever. New types get new tags; existing tags are never renumbered.

#include <cstdint>

namespace ncdata {
namespace ndat {

/* ---- file framing ---- */

constexpr char kMagic[4] = {'N', 'D', 'A', 'T'};
constexpr char kEndMagic[4] = {'N', 'E', 'N', 'D'};
constexpr uint16_t kVersionMajor = 1; // a reader rejects any other major
// 1.1 (2026-10): N-dimensional matrices - TAG_NUM_TENSOR with rank >= 3 and
// TAG_CELL_ND. A 1.0 reader refuses such a file with a clear message.
// 1.2 (2026-10-28): timestamps and durations - TAG_TIMESTAMP / TAG_DURATION.
constexpr uint16_t kVersionMinor = 2; // a reader accepts any minor of its major
constexpr uint8_t kEndianLittle = 1;
constexpr std::size_t kHeaderSize = 32;
constexpr std::size_t kFooterSize = 8; // "NEND" + CRC-32

/* ---- value node type tags (u8) ---- */

enum Tag : uint8_t {
  TAG_BOOL = 0x01,

  // Signed integers. 128/256-bit are reserved: no runtime type yet.
  TAG_INT8 = 0x10,
  TAG_INT16 = 0x11,
  TAG_INT32 = 0x12,
  TAG_INT64 = 0x13,
  TAG_INT128 = 0x14,
  TAG_INT256 = 0x15,

  // Unsigned integers.
  TAG_UINT8 = 0x18,
  TAG_UINT16 = 0x19,
  TAG_UINT32 = 0x1A,
  TAG_UINT64 = 0x1B,
  TAG_UINT128 = 0x1C,
  TAG_UINT256 = 0x1D,

  // Floating point. Only FLOAT64 is written today; the rest are reserved.
  TAG_FLOAT8 = 0x20,
  TAG_FLOAT16 = 0x21,
  TAG_FLOAT32 = 0x22,
  TAG_FLOAT64 = 0x23,
  TAG_FLOAT128 = 0x24,
  TAG_FLOAT256 = 0x25,

  TAG_COMPLEX128 = 0x28, // two float64: real, imaginary

  TAG_UTF8 = 0x30, // text in any language

  TAG_NUM_TENSOR = 0x40,  // packed numeric vector / matrix / N-D matrix
  TAG_CELL_ARRAY = 0x41,  // vector of arbitrary values
  TAG_CELL_MATRIX = 0x42, // rows of arbitrary values (rows may differ in length)
  TAG_CELL_ND = 0x43,     // N-D matrix of non-numeric elements (text, bool, ints ...)

  TAG_DICT = 0x50,
  TAG_OBJECT = 0x51,   // class instance
  TAG_FUNC_REF = 0x52, // @name

  // Date and time (since 1.2), payload i64 nanoseconds (ops/time/time.h).
  TAG_TIMESTAMP = 0x60, // since 1970-01-01 00:00:00 UTC
  TAG_DURATION = 0x61,  // a length of time, may be negative
};

/* ---- value node flags (u8) ---- */

// The node carries physical-unit exponents: i16 L, i16 T, i16 M follow the
// flags byte.
constexpr uint8_t FLAG_HAS_UNITS = 0x01;

// Bits a version-1.0 reader understands; any other bit set is an error.
constexpr uint8_t kKnownFlags = FLAG_HAS_UNITS;

/* ---- safety limits for reading untrusted files ---- */

constexpr int kMaxNestingDepth = 256;
constexpr uint8_t kMaxRank = 32; // axes of an N-D matrix
constexpr uint32_t kMaxNameBytes = 64 * 1024;

} // namespace ndat
} // namespace ncdata
