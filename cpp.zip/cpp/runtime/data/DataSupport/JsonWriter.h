#pragma once

// A small streaming JSON writer for the IDE channel (WS_PROTOCOL.md).
//
// Output is always valid JSON on a single line:
//   - strings are escaped, and any invalid UTF-8 in them is replaced with
//     U+FFFD, so a stray byte in a variable's text can never break the
//     Java parser;
//   - non-finite numbers, which JSON cannot express, are written as the
//     strings "NaN", "Infinity" and "-Infinity";
//   - doubles use the shortest form that reads back to the same value.
//
// Commas are inserted automatically: call key() then a value inside an
// object, or just values inside an array.

#include <cstdint>
#include <string>
#include <vector>

namespace ncdata {

class JsonWriter {
public:
  void beginObject();
  void endObject();
  void beginArray();
  void endArray();

  // Inside an object: the next value's key.
  JsonWriter &key(const std::string &k);

  void string(const std::string &s);
  void number(double d);
  void integer(int64_t i);
  void unsignedInteger(uint64_t u);
  void boolean(bool b);
  void null();

  const std::string &str() const { return out_; }
  std::size_t size() const { return out_.size(); }

  // Appends `s` as a JSON string literal (quotes included).
  static void appendQuoted(std::string &out, const std::string &s);
  // The shortest decimal text that parses back to exactly `d` (finite).
  static std::string shortestDouble(double d);

private:
  void separate();

  std::string out_;
  // One entry per open container: true once it holds an element.
  std::vector<bool> nonEmpty_;
  bool afterKey_ = false;
};

} // namespace ncdata
