# ==========================================================================================
# 03  Ordinary differential equations  (Kreyszig, chapters 1 to 6)
#
#   ch. 1   direction_field  orthogonal_trajectories  picard_iteration
#   ch. 2-3 wronskian  variation_of_parameters  resonance_peak
#   ch. 4   phase_plane  find_critical_points  classify_critical_point
#           (the Jacobian at a point is the existing jacobian(fn, x))
#   ch. 5   power_series_coeffs  frobenius_roots  sturm_liouville_solve
#   ch. 6   laplace_transform  inv_laplace_transform  dirac_delta_approx
#           solve_volterra_eq
#
# The step-by-step integrators (ode_solve and the like) already exist; these functions
# are the textbook's qualitative, series and transform tools.
#
# Functions are passed as references (@f) or names ("f"). A system of two equations is
# one function returning [x1', x2'] or a list of two functions ["f1", "f2"].
#
# Every check publishs PASS or FAIL.
# Run:  nc.exe 03_ordinary_differential_equations.nc
# ==========================================================================================

function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend
function check_text(label, got, want):
   if got == want:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   got '" + got + "'");
   iend
fnend

# ---- functions used below ----------------------------------------------------------------
function s = slope(x, y):
   s = x - y;
fnend
function s = growth(t, y):
   s = y;
fnend
function y = y1c(x):
   y = cos(x);
fnend
function y = y2s(x):
   y = sin(x);
fnend
function r = secant(x):
   r = 1 / cos(x);
fnend
function d = center(x1, x2):
   d = [x2, -1 * x1];
fnend
function d = pendulum(x1, x2):
   d = [x2, -1 * sin(x1)];
fnend
function d = pendulum_v(v):
   d = [v[1], -1 * sin(v[0])];
fnend
function p = leg_p(x):
   p = -2 * x / (1 - x ^ 2);
fnend
function q = leg_q(x):
   q = 6 / (1 - x ^ 2);
fnend
function y = one(t):
   y = 1;
fnend
function y = e2t(t):
   y = exp(2 * t);
fnend
function y = sint(t):
   y = sin(t);
fnend
function F = lap_exp(s):
   F = 1 / (s + 1);
fnend
function F = lap_sin(s):
   F = 1 / (s ^ 2 + 1);
fnend
function k = sine_kernel(u):
   k = sin(u);
fnend
function f = ramp(t):
   f = t;
fnend

# ==========================================================================================
# direction_field(@f, x, y) - slope field of y' = f(x, y) on the grid of x and y:
#   dict {X, Y, U, V, slope}; [U, V] = (1, f)/sqrt(1 + f^2), unit arrows for a plot
# orthogonal_trajectories(@f, x, y) - the field of the orthogonal family y' = -1/f:
#   arrows (-f, 1)/sqrt(1 + f^2), slope -1/f (Kreyszig 1.1, 1.8)
# ==========================================================================================
publish("---- direction fields ----");
xg = space(-2, 2, 9);
yg = space(-1, 1, 5);
df = direction_field(@slope, xg, yg);
check("slope = x - y on the grid", df["slope"], df["X"] - df["Y"], 0);
check("arrows have unit length", df["U"] ^. 2 + df["V"] ^. 2, ones(5, 9), 1e-12);
ot = orthogonal_trajectories(@slope, xg, yg);
check("orthogonal arrows are perpendicular", df["U"] *. ot["U"] + df["V"] *. ot["V"], zeros(5, 9), 1e-12);

# ==========================================================================================
# picard_iteration(@f, y0, t, n) - Picard's approximations of y' = f(t, y), y(t0) = y0:
#   y_{k+1}(t) = y0 + integral from t0 to t of f(s, y_k(s)) ds; row k = y_k on t.
# Kreyszig 1.7: y' = y, y(0) = 1 gives the partial sums of e^t.
# ==========================================================================================
publish("---- picard_iteration ----");
t = space(0, 1, 101);
Pc = picard_iteration(@growth, 1, t, 4);
# the running integrals are third-order accurate in the t step (0.01 here)
check("y_4 = 1 + t + t^2/2 + t^3/6 + t^4/24", Pc[4, :], 1 + t + t ^. 2 / 2 + t ^. 3 / 6 + t ^. 4 / 24, 1e-7);

# ==========================================================================================
# wronskian(Y, t) or wronskian(["y1", "y2", ...], t) - W(t) = det of [y_k^(i)]:
#   from sampled solutions (rows of Y) or from functions. Nonzero: independent.
# Kreyszig 2.6: cos t and sin t have W = 1.
# ==========================================================================================
publish("---- wronskian ----");
check("W(cos, sin) from functions = 1", wronskian(["y1c", "y2s"], [0, 0.5, 1]), [1, 1, 1], 1e-8);
check("W from sampled solutions = 1", wronskian([cos(t); sin(t)], t), ones(1, 101), 1e-3);

# ==========================================================================================
# variation_of_parameters(y1, y2, r, x) - a particular solution of y'' + p y' + q y = r
#   from two independent solutions y1, y2 (functions or samples on x); yp(x0) = 0.
# Kreyszig 2.10, Example 1: y'' + y = sec x  ->  yp = cos x ln(cos x) + x sin x
# ==========================================================================================
publish("---- variation_of_parameters ----");
xv = space(0, 1.2, 241);
yp = variation_of_parameters(@y1c, @y2s, @secant, xv);
check("Kreyszig 2.10 example", yp, cos(xv) *. log(cos(xv)) + xv *. sin(xv), 1e-7);

# ==========================================================================================
# resonance_peak(m, c, k, omega_range[, F0]) - amplitude C(w) of m y'' + c y' + k y =
#   F0 cos(w t) and its maximum (Kreyszig 2.8): dict {omega_peak, amplitude_peak, omega0,
#   omega, amplitude, phase}. omega_range is [w_min, w_max] or a vector of frequencies.
#   With damping, w_max = sqrt(k/m - c^2/(2 m^2)), C_max = 2 m F0 / (c sqrt(4 m k - c^2)).
# ==========================================================================================
publish("---- resonance_peak ----");
rp = resonance_peak(1, 0.5, 4, [0, 4]);
check("peak frequency", rp["omega_peak"], sqrt(4 - 0.125), 1e-12);
check("peak amplitude", rp["amplitude_peak"], 2 / (0.5 * sqrt(16 - 0.25)), 1e-12);

# ==========================================================================================
# phase_plane(F, x1, x2) - the vector field [x1', x2'] of an autonomous system on a grid:
#   dict {X1, X2, U, V, speed}
# find_critical_points(F, [x1_min, x1_max, x2_min, x2_max][, starts]) - every point with
#   x1' = x2' = 0 in the box (Newton from a grid of starts), one per row
# classify_critical_point(J) - type and stability from the Jacobian at the point
#   (Kreyszig 4.4: p = trace, q = det, Delta = p^2 - 4q): dict {type, detail, stability,
#   p, q, delta, eigenvalues}
# ==========================================================================================
publish("---- phase plane ----");
pp = phase_plane(@center, space(-1, 1, 5), space(-1, 1, 5));
check("x1' = x2 on the grid", pp["U"], pp["X2"], 0);
cp = find_critical_points(@pendulum, [-4, 4, -1, 1]);
check("pendulum critical points (-pi, 0), (0, 0), (pi, 0)", cp, [-1 * pi, 0; 0, 0; pi, 0], 1e-10);
# the existing jacobian(fn, x) gives J at a critical point (fn takes one vector input)
Jd = jacobian("pendulum_v", [0, 0]);                 # dict {df, error, success}
J = Jd["df"];
check("Jacobian at (0, 0) = [0, 1; -1, 0]", J, [0, 1; -1, 0], 1e-8);
c0 = classify_critical_point(J);
check_text("undamped pendulum at (0, 0): center", c0["type"], "center");
check_text("... stable", c0["stability"], "stable");
c1 = classify_critical_point([0, 1; 1, 0]);
check_text("at (pi, 0): saddle", c1["type"], "saddle");
c2 = classify_critical_point([-1, 1; -1, -1]);
check_text("p < 0, Delta < 0: spiral", c2["type"], "spiral");
check_text("... stable and attractive", c2["stability"], "stable and attractive");
c3 = classify_critical_point([-1, 0; 0, -2]);
check_text("two negative eigenvalues: node", c3["detail"], "improper node");
check("eigenvalues -2, -1", c3["eigenvalues"], [-2, -1], 1e-12);

# ==========================================================================================
# power_series_coeffs(p, q, r, x0, N[, ic]) - the first N coefficients of the power
#   series solutions of y'' + p y' + q y = r around x0 (Kreyszig 5.1). p, q, r are
#   numbers, coefficient arrays, or functions (analytic within 0.5 of x0; they must
#   accept complex x). Returns {y1 (y(x0)=1, y'(x0)=0), y2 (0, 1), yp (particular),
#   y (with ic = [y(x0), y'(x0)])}.
# ==========================================================================================
publish("---- power_series_coeffs ----");
ps = power_series_coeffs(0, 1, 0, 0, 7);                       # y'' + y = 0
check("y1 = cos x", ps["y1"], [1, 0, -1/2, 0, 1/24, 0, -1/720], 1e-15);
check("y2 = sin x", ps["y2"], [0, 1, 0, -1/6, 0, 1/120, 0], 1e-15);
lg = power_series_coeffs(@leg_p, @leg_q, 0, 0, 8);             # Legendre, n = 2
check("Legendre n = 2: y1 = 1 - 3x^2 (2 P2 = 3x^2 - 1, up to scale)", lg["y1"], [1, 0, -3, 0, 0, 0, 0, 0], 1e-10);
nh = power_series_coeffs(0, -1, [0, 1], 0, 8, [0, 0]);          # y'' - y = x
check("y'' - y = x, y(0) = y'(0) = 0: sinh x - x", nh["y"], [0, 0, 0, 1/6, 0, 1/120, 0, 1/5040], 1e-15);

# ==========================================================================================
# frobenius_roots(b0, c0) - roots of the indicial equation r(r - 1) + b0 r + c0 = 0 of
#   x^2 y'' + x b(x) y' + c(x) y = 0 and the case of Frobenius's theorem (Kreyszig 5.3):
#   1 distinct (not differing by an integer), 2 double root, 3 differing by an integer
# ==========================================================================================
publish("---- frobenius_roots ----");
fb = frobenius_roots(1, -0.25);                                # Bessel, nu = 1/2
check("Bessel nu = 1/2: r = 1/2, -1/2", [fb["r1"], fb["r2"]], [0.5, -0.5], 1e-12);
check("... case 3", fb["case"], 3, 0);
ec = frobenius_roots(-3, 4);                                  # x^2 y'' - 3x y' + 4y = 0
check("Euler-Cauchy: double root r = 2", ec["r1"], 2, 1e-12);
check("... case 2", ec["case"], 2, 0);

# ==========================================================================================
# sturm_liouville_solve(p, q, r, bc_a, bc_b, N[, M]) - the first N eigenvalues and
#   eigenfunctions of [p y']' + [q + lambda r] y = 0 on [a, b] with k1 y(a) + k2 y'(a) = 0,
#   l1 y(b) + l2 y'(b) = 0; bc_a = [a, k1, k2], bc_b = [b, l1, l2] (Kreyszig 5.7).
#   Finite differences on M intervals (300 by default) with Richardson extrapolation.
#   Returns {eigenvalues, x, eigenfunctions (one per row, integral of r y^2 = 1)}.
# ==========================================================================================
publish("---- sturm_liouville_solve ----");
sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [pi, 1, 0], 4);   # y'' + lambda y = 0, y(0) = y(pi) = 0
check("Dirichlet: lambda = 1, 4, 9, 16", sl["eigenvalues"], [1, 4, 9, 16], 1e-5);
ef = sl["eigenfunctions"];
xs = sl["x"];
check("first mode = sqrt(2/pi) sin x", ef[0, :], sqrt(2 / pi) * sin(xs), 1e-4);
nm = sturm_liouville_solve(1, 0, 1, [0, 0, 1], [pi, 0, 1], 3);   # y'(0) = y'(pi) = 0
check("Neumann: lambda = 0, 1, 4", nm["eigenvalues"], [0, 1, 4], 1e-5);

# ==========================================================================================
# laplace_transform(@f, s) - F(s) = integral from 0 to inf of e^(-st) f(t) dt (s may be
#   complex). inv_laplace_transform(@F, t[, method][, M]) - f(t) back from F(s):
#   "talbot" (default; F must accept complex s) or "stehfest" (real s only).
# ==========================================================================================
publish("---- Laplace transforms ----");
s = [1, 2, 3];
check("L(1) = 1/s", laplace_transform(@one, s), 1 /. s, 1e-9);
check("L(e^2t) = 1/(s - 2)", laplace_transform(@e2t, [3, 4]), [1, 0.5], 1e-9);
check("L(sin t) = 1/(s^2 + 1)", laplace_transform(@sint, s), 1 /. (s ^. 2 + 1), 1e-9);
tt = [0.5, 1, 2, 5];
check("talbot: 1/(s+1) -> e^-t", inv_laplace_transform(@lap_exp, tt), exp(-1 * tt), 1e-9);
check("talbot: 1/(s^2+1) -> sin t", inv_laplace_transform(@lap_sin, tt), sin(tt), 1e-8);
# Stehfest with M = 14 terms gives about 4 to 5 correct digits in double precision
check("stehfest: 1/(s+1) -> e^-t", inv_laplace_transform(@lap_exp, tt, "stehfest"), exp(-1 * tt), 1e-4);

# ==========================================================================================
# dirac_delta_approx(t, t0, width[, shape]) - a unit impulse at t0 on the samples t:
#   "rect" (default, Kreyszig 6.4: 1/k on [t0, t0 + k)) or "gauss" (sd = width)
# ==========================================================================================
publish("---- dirac_delta_approx ----");
td = space(0, 2, 2001);
d1 = dirac_delta_approx(td, 1, 0.1);
check("rect impulse has area 1", sum(d1) * 0.001, 1, 2e-2);
d2 = dirac_delta_approx(td, 1, 0.05, "gauss");
check("gauss impulse has area 1", sum(d2) * 0.001, 1, 1e-6);

# ==========================================================================================
# solve_volterra_eq(k, f, t) - y(t) = f(t) + integral from t0 to t of k(t, tau) y(tau)
#   d tau (second kind), trapezoid rule; k(t - tau) when k takes one input.
# Kreyszig 6.5: y - integral of y(tau) sin(t - tau) d tau = t  ->  y = t + t^3/6
# ==========================================================================================
publish("---- solve_volterra_eq ----");
tv = space(0, 1, 201);
yv = solve_volterra_eq(@sine_kernel, @ramp, tv);
check("Kreyszig 6.5 example", yv, tv + tv ^. 3 / 6, 1e-5);
publish("done: 03_ordinary_differential_equations");
