# ==========================================================================================
# 02  Vector differential and integral calculus  (Kreyszig, chapters 9 and 10)
#
#     arc_length3  frenet_frames  directional_deriv  div  curl  integrate_line
#     is_conservative  potential_field  integrate_surface  integrate_volume
#     eval_gauss_divergence
#
# Green's and Stokes's theorems are green_integral and stokes_integral
# (01_calculus_operations.nc). Chapters 7-8 (linear algebra) need no new functions.
#
# Layouts used below
#   curve       a matrix with one point per row:  [x, y, z]  (or [x, y])
#   2-D grid    Z[i, j] = f(x_j, y_i)  - rows along y, columns along x (meshgrid)
#   3-D grid    an N-D matrix [nz, ny, nx]: G[k, i, j] = f(x_j, y_i, z_k)
#   surface     three grids X, Y, Z of one shape: the point r(u, v), u along the
#               columns and v along the rows; its normal is r_u x r_v
#
# Every check publishs PASS or FAIL.
# Run:  nc.exe 02_vector_calculus.nc
# ==========================================================================================

function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend

# ---- fields used below --------------------------------------------------------------------
function f = ellipsoid(x, y, z):
   f = 2 * x ^ 2 + 3 * y ^ 2 + z ^ 2;
fnend
function F = kreyszig_10_1(x, y):
   F = [-1 * y, -1 * x * y];
fnend
function F = helix_field(x, y, z):
   F = [z, x, y];
fnend
function F = grad_xy(x, y):
   F = [y, x];
fnend
function F = cylinder_field(x, y, z):
   F = [3 * z ^ 2, 6, 6 * x * z];
fnend

# ==========================================================================================
# arc_length3(curve) - cumulative arc length along the points (chord lengths), first 0
# frenet_frames(curve[, t]) - dict {T, N, B, kappa, tau}: unit tangent, normal and
#     binormal at every point (n x 3 matrices), curvature and torsion. t is the curve
#     parameter (0, 1, 2, ... when left out); derivatives are fourth-order differences.
# Example (Kreyszig 9.5): the helix r(t) = [cos t, sin t, t] has length 2 pi sqrt(2)
# over one turn, curvature 1/2 and torsion 1/2 everywhere.
# ==========================================================================================
publish("---- curves ----");
t = space(0, 2 * pi, 401);
C = transpose([cos(t); sin(t); t]);                # 401 x 3, one point per row
s = arc_length3(C);
check("helix length over one turn = 2 pi sqrt(2)", s[400], 2 * pi * sqrt(2), 1e-4);
fr = frenet_frames(C, t);
check("helix curvature = 1/2", fr["kappa"], 0.5 * ones(1, 401), 1e-6);
# torsion needs r''': least accurate at the two end points (one-sided differences)
check("helix torsion = 1/2", fr["tau"], 0.5 * ones(1, 401), 1e-3);
T = fr["T"];
check("unit tangent at t = 0 is [0, 1, 1]/sqrt(2)", T[0, 1], 1 / sqrt(2), 1e-8);

# ==========================================================================================
# directional_deriv - rate of change of a scalar field in the direction of a vector
#   directional_deriv(@f, point, a[, h])         grad f(point) . a/|a|
#   directional_deriv(F, a[, dx, dy, dz])        on a 2-D or 3-D grid
# Example (Kreyszig 9.7): f = 2x^2 + 3y^2 + z^2 at (2, 1, 3), a = [1, 0, -2]:
#   D_a f = -4/sqrt(5) = -1.789
# ==========================================================================================
publish("---- directional_deriv ----");
check("Kreyszig 9.7 example: -4/sqrt(5)", directional_deriv(@ellipsoid, [2, 1, 3], [1, 0, -2]), -4 / sqrt(5), 1e-8);
x = space(0, 1, 11);
[X, Y] = meshgrid(x, x);
P = X ^. 2 + Y ^. 2;
check("grid: f = x^2 + y^2 along [1, 1]", directional_deriv(P, [1, 1], 0.1, 0.1), (2 * X + 2 * Y) / sqrt(2), 1e-12);

# ==========================================================================================
# div / curl on 3-D grids (see 01 for the other forms)
#   div(U, V, W[, dx, dy, dz])  -> a grid;  curl(U, V, W[, dx, dy, dz]) -> dict {x, y, z}
# Here F = [x y, y z, z x] on [0, 1]^3:  div F = y + z + x,  curl F = [-y, -z, -x]
# ==========================================================================================
publish("---- div and curl on 3-D grids ----");
n = 6;
h = 1 / (n - 1);
U = zeros([n, n, n]);
V = zeros([n, n, n]);
W = zeros([n, n, n]);
S = zeros([n, n, n]);
for k = [0:n - 1]:
   for i = [0:n - 1]:
      for j = [0:n - 1]:
         U[k, i, j] = (j * h) * (i * h);
         V[k, i, j] = (i * h) * (k * h);
         W[k, i, j] = (k * h) * (j * h);
         S[k, i, j] = j * h + i * h + k * h;
      fend
   fend
fend
D = div(U, V, W, h, h, h);
check("div of [xy, yz, zx] = x + y + z (slab z_2)", D[2], S[2], 1e-12);
Cu = curl(U, V, W, h, h, h);
Cz = Cu["z"];
[XX, YY] = meshgrid(space(0, 1, n), space(0, 1, n));
check("curl z-component = -x (slab z_3)", Cz[3], -1 * XX, 1e-12);

# ==========================================================================================
# integrate_line(@F, path) - work integral of F . dr along a path of straight segments
#   (Simpson's rule on each segment: exact when F is at most cubic along it)
# Kreyszig 10.1, Example 1: F = [-y, -xy] on the quarter circle -> pi/4 - 1/3 = 0.4521
# Kreyszig 10.1, Example 2: F = [z, x, y] on the helix [cos t, sin t, 3t], 0..2 pi -> 7 pi
# On a straight path a gradient field gives the exact potential difference.
# ==========================================================================================
publish("---- integrate_line ----");
q = space(0, pi / 2, 801);
quarter = transpose([cos(q); sin(q)]);
check("Kreyszig 10.1 ex. 1 = pi/4 - 1/3", integrate_line(@kreyszig_10_1, quarter), pi / 4 - 1 / 3, 1e-6);
th = space(0, 2 * pi, 801);
hel = transpose([cos(th); sin(th); 3 * th]);
check("Kreyszig 10.1 ex. 2 = 7 pi", integrate_line(@helix_field, hel), 7 * pi, 1e-4);
check("grad of xy from (0,0) to (1,2) = 2", integrate_line(@grad_xy, [0, 0; 0.5, 1.5; 1, 2]), 2, 1e-12);

# ==========================================================================================
# is_conservative(U, V[, W][, tol, dx, dy, dz]) - path independence: curl F = 0 to
#   within tol (relative to the field's derivatives, default 1e-3).
#   Returns {conservative, max_curl, relative_curl}.
# potential_field(U, V[, W][, spacing]) - f with grad f = F, f = 0 at the first grid
#   point; spacing = [dx, dy(, dz)].
# ==========================================================================================
publish("---- is_conservative / potential_field ----");
c1 = is_conservative(2 * X, 2 * Y, 1e-6, 0.1, 0.1);                 # grad of x^2 + y^2
check("[2x, 2y] is conservative", c1["conservative"], 1, 0);
c2 = is_conservative(-1 * Y, X, 1e-6, 0.1, 0.1);                    # a rotation
check("[-y, x] is not conservative", c2["conservative"], 0, 0);
c3 = is_conservative(U, V, W, 1e-6, h, h, h);
check("[xy, yz, zx] is not conservative", c3["conservative"], 0, 0);
pf = potential_field(2 * X, 2 * Y, [0.1, 0.1]);
check("potential of [2x, 2y] = x^2 + y^2", pf, X ^. 2 + Y ^. 2, 1e-12);

# ==========================================================================================
# integrate_surface(F, X, Y, Z) - flux of F through a parametric surface; F is a
#   function of (x, y, z) or a dict {x, y, z} of its values on the surface grid.
# Kreyszig 10.6, Example 1: F = [3z^2, 6, 6xz] through y = x^2, 0 <= x <= 2,
#   0 <= z <= 3 (r(u, v) = [u, u^2, v]) -> 72
# ==========================================================================================
publish("---- integrate_surface ----");
uu = space(0, 2, 21);
vv = space(0, 3, 31);
[SU, SV] = meshgrid(uu, vv);          # u along the columns, v along the rows
flux = integrate_surface(@cylinder_field, SU, SU ^. 2, SV);
check("Kreyszig 10.6 ex. 1 = 72", flux, 72, 1e-9);
Fd = dict();
Fd["x"] = 3 * SV ^. 2;
Fd["y"] = 6 * ones(31, 21);
Fd["z"] = 6 * SU *. SV;
check("same flux from sampled values", integrate_surface(Fd, SU, SU ^. 2, SV), 72, 1e-9);

# ==========================================================================================
# integrate_volume(G[, dx, dy, dz]) - double (2-D grid) or triple (3-D grid) integral,
#   Simpson's rule in each direction
# ==========================================================================================
publish("---- integrate_volume ----");
check("integral of x^2 y over the unit square = 1/6", integrate_volume(X ^. 2 *. Y, 0.1, 0.1), 1 / 6, 1e-12);
XYZ = zeros([n, n, n]);
for k = [0:n - 1]:
   for i = [0:n - 1]:
      for j = [0:n - 1]:
         XYZ[k, i, j] = (j * h) * (i * h) * (k * h);
      fend
   fend
fend
check("integral of xyz over the unit cube = 1/8", integrate_volume(XYZ, h, h, h), 1 / 8, 1e-12);

# ==========================================================================================
# eval_gauss_divergence(U, V[, W][, dx, dy, dz]) - both sides of the divergence theorem
#   (Kreyszig 10.7) on the grid's box: {volume_integral: of div F,
#   surface_flux: outward flux through the boundary}. They agree to the grid's accuracy.
# ==========================================================================================
publish("---- eval_gauss_divergence ----");
g3 = eval_gauss_divergence(U, V, W, h, h, h);       # F = [xy, yz, zx], div = x + y + z
check("volume integral of div F = 3/2", g3["volume_integral"], 1.5, 1e-12);
check("outward flux through the cube = 3/2", g3["surface_flux"], 1.5, 1e-12);
g2 = eval_gauss_divergence(X ^. 2, X *. Y, 0.1, 0.1);  # 2-D: div [x^2, xy] = 3x
check("2-D: both sides = 3/2", [g2["volume_integral"], g2["surface_flux"]], [1.5, 1.5], 1e-12);
publish("done: 02_vector_calculus");
