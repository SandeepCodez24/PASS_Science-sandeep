# ==========================================================================================
# 01  Calculus operations
#
#     ddt  pddt  continuity  grad  curl  div  laplace  green_integral  stokes_integral
#     taylor_series  rad_of_con
#
# The calculus table of the IDE (Derivative, Partial Derivative, Continuity, Gradient,
# Curl, Laplacian, Green's Theorem, Stokes' Theorem, Taylor Series, Radius of
# Convergence). Every function works in three ways:
#
#   1. on SAMPLED DATA     ddt(Y, h)          a vector of samples spaced h apart
#                          pddt(Z, "x", h)    a grid Z[i, j] = f(x_j, y_i)
#   2. on an NC FUNCTION   ddt(@f, x0)        a function written with  function ... fnend
#   3. the OLD forms       ddt(f_plus, f_minus, h), laplace([fxx, fyy, fzz]), ...
#                          still give the same results as before.
#
# Grids: rows go along y, columns along x (the layout meshgrid(x, y) gives).
#        A 3-D grid is an N-D matrix [nz, ny, nx]: page k is the slab at z_k.
#
# Every check publishs PASS or FAIL. Reference: Kreyszig, Advanced Engineering
# Mathematics, chapters 9, 10 and 15.
#
# Run:  nc.exe 01_calculus_operations.nc
# ==========================================================================================

# check(label, got, want, tol): PASS when every element of got is within tol of want.
function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend

# ---- functions used by the examples ----------------------------------------------------
function y = cube(x):
   y = x ^ 3;
fnend
function z = bowl(x, y):
   z = x ^ 2 * y + 3 * y;
fnend
function y = step(x):
   if x < 0:
      y = 0;
   else:
      y = 1;
   iend
fnend
function F = swirl(x, y, z):
   F = [y * z, x * z, x * y];
fnend
function F = spin(x, y, z):
   F = [-y, x, 0];
fnend
function F = rot2(x, y):
   F = [-y, x];
fnend
function y = ex(x):
   y = exp(x);
fnend

# ==========================================================================================
# ddt - derivative
#   ddt(Y[, h])        samples Y spaced h apart (h = 1 when left out), or ddt(Y, x) at
#                      coordinates x: second-order differences, one value per sample
#   ddt(@f, x[, h])    f'(x) of an NC function at x (a number or a vector of points),
#                      fourth-order central difference
#   ddt(fp, fm, h)     old form: (fp - fm) / (2h)
# ==========================================================================================
publish("---- ddt ----");
t = space(0, 2, 21);              # 21 samples, h = 0.1
Y = t ^. 2;                       # y = t^2, so y' = 2t
check("ddt(Y, h) of t^2 is 2t", ddt(Y, 0.1), 2 * t, 1e-12);
check("ddt(Y, t) with coordinates", ddt(Y, t), 2 * t, 1e-12);
check("ddt(@cube, 2) = 12", ddt(@cube, 2), 12, 1e-8);
check("ddt(@cube, [0, 1, 3]) = 3x^2", ddt(@cube, [0, 1, 3]), [0, 3, 27], 1e-8);
check("old form ddt(f(x+h), f(x-h), h)", ddt(4.004001, 3.996001, 0.001), 4, 1e-9);

# ==========================================================================================
# pddt - partial derivative
#   pddt(Z, "x"|"y"|"z"[, h])     grid Z, along one axis (spacing h)
#   pddt(@f, point, var[, h])     df/dvar at point; var is "x", "y", "z" or 1, 2, 3
#   pddt(fp, fm, h)               old form, as ddt
# ==========================================================================================
publish("---- pddt ----");
x = space(0, 1, 11);
[X, Yg] = meshgrid(x, x);          # spacing 0.1 in both directions
Z = X ^. 2 *. Yg + 3 * Yg;         # f = x^2 y + 3y: f_x = 2xy, f_y = x^2 + 3
check("pddt(Z, \"x\", h) = 2xy", pddt(Z, "x", 0.1), 2 * X *. Yg, 1e-12);
check("pddt(Z, \"y\", h) = x^2 + 3", pddt(Z, "y", 0.1), X ^. 2 + 3, 1e-12);
check("pddt(@bowl, [1, 2], \"x\") = 4", pddt(@bowl, [1, 2], "x"), 4, 1e-8);
check("pddt(@bowl, [1, 2], 2) = 4 (variable 2 = y)", pddt(@bowl, [1, 2], 2), 4, 1e-8);
check("old form pddt(fp, fm, h)", pddt(4.004001, 3.996001, 0.001), 4, 1e-9);

# ==========================================================================================
# continuity
#   continuity(a)              1 when every value of a is finite, else 0 (old form)
#   continuity(@f, x0[, tol])  1 when f is continuous at x0: f(x0) finite and
#                              |f(x0 +- h) - f(x0)| shrinks to 0 as h does (both sides)
# ==========================================================================================
publish("---- continuity ----");
check("continuity(1/0) = 0", continuity(1 / 0), 0, 0);
check("continuity([1, 2, 3]) = 1", continuity([1, 2, 3]), 1, 0);
check("x^3 is continuous at 1", continuity(@cube, 1), 1, 0);
check("the step jumps at 0", continuity(@step, 0), 0, 0);
check("the step at [-1, 0, 1]", continuity(@step, [-1, 0, 1]), [1, 0, 1], 0);

# ==========================================================================================
# grad - gradient
#   grad(@f, point[, h])        the existing form: one partial derivative per coordinate
#   grad(Y[, h])                sampled line: same as ddt(Y, h)
#   grad(Z[, dx, dy])           2-D grid: dict {x: dZ/dx, y: dZ/dy}
#   grad(G[, dx, dy, dz])       3-D grid: dict {x, y, z}
# ==========================================================================================
publish("---- grad ----");
g = grad(@bowl, [1, 2]);
check("grad(@bowl, [1, 2]) = [4, 4]", g, [4, 4], 1e-6);
check("grad(Y, 0.1) = ddt(Y, 0.1)", grad(Y, 0.1), ddt(Y, 0.1), 0);
G = grad(Z, 0.1, 0.1);
check("grad(Z)[\"x\"] = 2xy", G["x"], 2 * X *. Yg, 1e-12);
check("grad(Z)[\"y\"] = x^2 + 3", G["y"], X ^. 2 + 3, 1e-12);
# a 3-D grid f = x + 2y + 3z on a 3 x 4 x 5 box, unit spacing
B = zeros([3, 4, 5]);
for k = [0:2]:
   for i = [0:3]:
      for j = [0:4]:
         B[k, i, j] = j + 2 * i + 3 * k;
      fend
   fend
fend
G3 = grad(B);
Gz = G3["z"];                      # an N-D [3, 4, 5] matrix; Gz[1] is its middle slab
check("3-D grad: df/dz = 3 (slab z_1)", Gz[1], 3 * ones(4, 5), 1e-12);
Gy = G3["y"];
check("3-D grad: df/dy = 2 (slab z_0)", Gy[0], 2 * ones(4, 5), 1e-12);

# ==========================================================================================
# curl (and curl_calc, the same function under the calculus name)
#   curl([Fx, Fy, Fz])            old form: cyclic difference of a 3-vector
#   curl(@F, point[, h])          F(x, y[, z]) returning [F1, F2(, F3)]: curl at a point
#                                 (a number in 2-D, a 3-vector in 3-D)
#   curl(U, V[, dx, dy])          2-D grids: dV/dx - dU/dy
#   curl(U, V, W[, dx, dy, dz])   3-D grids: dict {x, y, z}
# ==========================================================================================
publish("---- curl ----");
check("old form curl([1, 2, 3])", curl([1, 2, 3]), [-1, 2, -1], 0);
check("curl of [-y, x, 0] = [0, 0, 2]", curl(@spin, [1, 2, 3]), [0, 0, 2], 1e-8);
check("curl of grad is 0: [yz, xz, xy]", curl(@swirl, [1, 2, 3]), [0, 0, 0], 1e-8);
check("2-D curl of [-y, x] = 2", curl(@rot2, [0.5, 0.5]), 2, 1e-8);
check("curl(U, V, dx, dy) of [-y, x] = 2", curl(-1 * Yg, X, 0.1, 0.1), 2 * ones(11, 11), 1e-12);
check("curl_calc is curl", curl_calc([1, 2, 3]), curl([1, 2, 3]), 0);

# ==========================================================================================
# div - divergence
#   div(a)                        old form: sum of the components
#   div(@F, point[, h])           at a point
#   div(U, V[, dx, dy]) / div(U, V, W[, dx, dy, dz])   on grids
# ==========================================================================================
publish("---- div ----");
check("old form div([1, 2, 3]) = 6", div([1, 2, 3]), 6, 0);
check("div of [yz, xz, xy] = 0", div(@swirl, [1, 2, 3]), 0, 1e-8);
check("div(U, V) of [x^2, y^2] = 2x + 2y", div(X ^. 2, Yg ^. 2, 0.1, 0.1), 2 * X + 2 * Yg, 1e-12);

# ==========================================================================================
# laplace - Laplacian
#   laplace([fxx, fyy, fzz])      old form: the sum of the given second derivatives
#   laplace(Y, h)                 sampled line: d2Y/dx2
#   laplace(Z[, dx, dy])          grid: Z_xx + Z_yy (3-D: + Z_zz)
#   laplace(@f, point[, h])       at a point
# ==========================================================================================
publish("---- laplace ----");
check("old form laplace([2, 2, 2]) = 6", laplace([2, 2, 2]), 6, 0);
check("laplace(Y, h) of t^2 is 2", laplace(Y, 0.1), 2 * ones(1, 21), 1e-9);
check("laplace(Z) of x^2 y + 3y is 2y", laplace(Z, 0.1, 0.1), 2 * Yg, 1e-9);
check("laplace(@bowl, [1, 2]) = 2y = 4", laplace(@bowl, [1, 2]), 4, 1e-6);

# ==========================================================================================
# green_integral - Green's theorem in the plane (Kreyszig 10.4)
#   closed integral of P dx + Q dy  =  double integral of (dQ/dx - dP/dy) dx dy
#   green_integral(@P, @Q, x0, x1, y0, y1[, n])   the existing function form
#   green_integral(P, Q[, dx, dy])                sampled grids P, Q over a rectangle
# Example: P = -y, Q = x on the unit square: dQ/dx - dP/dy = 2, area 1 -> 2.
# ==========================================================================================
publish("---- green_integral ----");
check("grid form, [-y, x] on the unit square = 2", green_integral(-1 * Yg, X, 0.1, 0.1), 2, 1e-12);

# ==========================================================================================
# stokes_integral - Stokes's theorem (Kreyszig 10.9)
#   stokes_integral([Fx, Fy, Fz])        old form: the cyclic difference (as curl)
#   stokes_integral(@F, X, Y, Z[, h])    surface r(u, v) given by grids X, Y, Z
#       (u along the columns, v along the rows, normal r_u x r_v): returns
#       {surface_integral: flux of curl F, circulation: closed integral of F . dr}
# Example: F = [-y, x, 0] over the unit disk z = 0 (polar grid): both = 2 pi.
# ==========================================================================================
publish("---- stokes_integral ----");
check("old form stokes_integral([1, 2, 3])", stokes_integral([1, 2, 3]), [-1, 2, -1], 0);
r = space(0, 1, 21);
th = space(0, 2 * pi, 41);
[TH, R] = meshgrid(th, r);         # rows: r, columns: theta
SX = R *. cos(TH);
SY = R *. sin(TH);
SZ = zeros(21, 41);
# u = theta (columns), v = r (rows): r_theta x r_r points DOWN (-z), so use r as u:
S = stokes_integral(@spin, transpose(SX), transpose(SY), transpose(SZ));
# accuracy: fourth order in the grid steps (41 angles here)
check("Stokes: flux of curl F through the disk = 2 pi", S["surface_integral"], 2 * pi, 1e-3);
check("Stokes: circulation round the edge = 2 pi", S["circulation"], 2 * pi, 1e-3);

# ==========================================================================================
# taylor_series (existing): Taylor polynomial of f at x0 with n terms, evaluated at x
# ==========================================================================================
publish("---- taylor_series ----");
check("taylor_series(@cube, 0, 2, 4) = 8", taylor_series(@cube, 0, 2, 4), 8, 1e-6);

# ==========================================================================================
# rad_of_con - radius of convergence of sum a_n (z - z0)^n from its coefficients
#   Domb-Sykes fit of the coefficient ratios (Cauchy-Hadamard in the limit, Kreyszig 15.2):
#   exact for a_n = n^k / R^n; inf for an entire function such as e^x.
# ==========================================================================================
publish("---- rad_of_con ----");
check("a_n = n + 1 (1/(1-z)^2): R = 1", rad_of_con([1, 2, 3]), 1, 1e-12);
check("a_n = 2^n: R = 1/2", rad_of_con([1, 2, 4, 8, 16, 32]), 0.5, 1e-12);
check("a_n = (n + 1) 3^-n: R = 3", rad_of_con([1, 2/3, 3/9, 4/27, 5/81, 6/243]), 3, 1e-9);
check("a_n = n!: R = 0", rad_of_con([1, 1, 2, 6, 24, 120, 720, 5040]), 0, 0);
check("e^z: R = inf", rad_of_con(taylor_coeffs_cplx(@ex, 0, 20)) > 1e6, 1, 0);
publish("done: 01_calculus_operations");


