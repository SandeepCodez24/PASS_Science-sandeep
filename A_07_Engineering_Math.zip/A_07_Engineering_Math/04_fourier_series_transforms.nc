# ==========================================================================================
# 04  Fourier series, integrals and transforms  (Kreyszig, chapter 11)
#
#     fourier_coeffs_real  fourier_coeffs_complex  half_range_extension  parseval_error
#     forced_oscillation_fourier  fourier_transform_integral
#     fourier_sine_cosine_transform
#
# These work on a FUNCTION (by adaptive Gauss-Kronrod integration, one call of the
# function per node for all coefficients at once). The discrete transforms of sampled
# data (fft, ifft, ...) are the existing functions.
#
# Conventions (Kreyszig's):
#   period p = 2L on [-L, L]:   f ~ a0 + sum a_n cos(n pi x / L) + b_n sin(n pi x / L)
#   complex:                    f ~ sum c_n e^(i n pi x / L),  n = -N .. N
#   transform:                  f^(w) = 1/sqrt(2 pi) integral of f(x) e^(-i w x) dx
#   cosine / sine transform:    sqrt(2/pi) integral from 0 to inf of f(x) cos(w x) dx
#
# Every check publishs PASS or FAIL.
# Run:  nc.exe 04_fourier_series_transforms.nc
# ==========================================================================================

function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend

# ---- functions used below ----------------------------------------------------------------
function y = square(x):
   # Kreyszig 11.1, Example 1 (k = 1): -1 on (-pi, 0), 1 on (0, pi)
   if x < 0:
      y = -1;
   else:
      y = 1;
   iend
fnend
function y = parabola(x):
   y = x ^ 2;
fnend
function y = expx(x):
   y = exp(x);
fnend
function y = triangle(x):
   # Kreyszig 11.2, Example 6 with k = 1, L = 2: a triangle of height 1 at x = 1
   if x < 1:
      y = x;
   else:
      y = 2 - x;
   iend
fnend
function r = forcing(t):
   # Kreyszig 11.3: r(t) = t + pi/2 on (-pi, 0), -t + pi/2 on (0, pi)
   if t < 0:
      r = t + pi / 2;
   else:
      r = -1 * t + pi / 2;
   iend
fnend
function y = gauss(x):
   y = exp(-1 * x ^ 2 / 2);
fnend
function y = box(x):
   y = 1;
fnend
function y = decay(x):
   y = exp(-2 * x);
fnend

# ==========================================================================================
# fourier_coeffs_real(@f, p, N[, start]) - a0 and a_n, b_n (n = 1..N) of the Fourier series
#   of f with period p, over [start, start + p] (start = -p/2 by default)
# ==========================================================================================
publish("---- fourier_coeffs_real ----");
F = fourier_coeffs_real(@square, 2 * pi, 5);
check("square wave: b_n = 4/(n pi) for odd n", F["b"], [4 / pi, 0, 4 / (3 * pi), 0, 4 / (5 * pi)], 1e-10);
check("square wave: a0 = 0, a_n = 0", [F["a0"], F["a"]], zeros(1, 6), 1e-12);
P = fourier_coeffs_real(@parabola, 2, 4);              # x^2 on (-1, 1), period 2
n = [1, 2, 3, 4];
check("x^2: a0 = 1/3", P["a0"], 1 / 3, 1e-12);
check("x^2: a_n = 4 (-1)^n / (n pi)^2", P["a"], 4 * [-1, 1, -1, 1] /. (n *. pi) ^. 2, 1e-12);

# ==========================================================================================
# fourier_coeffs_complex(@f, p, N[, start]) - dict {n: -N..N, c: the coefficients c_n}
# Kreyszig 11.4, Example: f = e^x on (-pi, pi): c_n = (sinh pi / pi) (-1)^n (1 + i n)/(1 + n^2)
# ==========================================================================================
publish("---- fourier_coeffs_complex ----");
Cc = fourier_coeffs_complex(@expx, 2 * pi, 2);
nn = [-2, -1, 0, 1, 2];
want = (sinh(pi) / pi) * [1, -1, 1, -1, 1] *. (1 + 1i * nn) /. (1 + nn ^. 2);
check("e^x: c_n", Cc["c"], want, 1e-10);
check("n runs from -N to N", Cc["n"], nn, 0);

# ==========================================================================================
# half_range_extension(@f, L, N, "even"|"odd") - f given on (0, L) only, extended as an
#   even function (cosine series: dict {a0, a}) or an odd one (sine series: dict {b})
# Kreyszig 11.2, Example 6 (k = 1, L = 2):
#   even:  a0 = 1/2,  a_n = 4/(n pi)^2 (2 cos(n pi/2) - cos(n pi) - 1)
#   odd:   b_n = 8/(n pi)^2 sin(n pi/2)
# ==========================================================================================
publish("---- half_range_extension ----");
He = half_range_extension(@triangle, 2, 4, "even");
check("even: a0 = 1/2", He["a0"], 0.5, 1e-12);
check("even: a_n", He["a"], 4 /. (n *. pi) ^. 2 *. (2 * cos(n * pi / 2) - cos(n * pi) - 1), 1e-12);
Ho = half_range_extension(@triangle, 2, 4, "odd");
check("odd: b_n", Ho["b"], 8 /. (n *. pi) ^. 2 *. sin(n * pi / 2), 1e-12);

# ==========================================================================================
# parseval_error(@f, coeffs, p[, start]) - the minimum square error of the trigonometric
#   polynomial with these coefficients (Kreyszig 11.6):
#   E* = integral of f^2 - L (2 a0^2 + sum (a_n^2 + b_n^2)),  L = p/2
# Kreyszig 11.6, Example: the square wave with N = 1 has E* = 2 pi - 16/pi = 1.1902
# ==========================================================================================
publish("---- parseval_error ----");
check("square wave, N = 1: E* = 1.1902", parseval_error(@square, fourier_coeffs_real(@square, 2 * pi, 1), 2 * pi), 2 * pi - 16 / pi, 1e-9);
check("N = 5: E* = 2 pi - (16/pi)(1 + 1/9 + 1/25) = 0.4190", parseval_error(@square, F, 2 * pi), 2 * pi - 16 / pi * (1 + 1 / 9 + 1 / 25), 1e-9);

# ==========================================================================================
# forced_oscillation_fourier(coeffs, m, c, k, w) - steady state of m y'' + c y' + k y = r(t)
#   for a periodic r with Fourier coefficients {a0, a, b} (frequencies n w):
#   dict {A0, A, B, amplitude}: y = A0 + sum A_n cos(n w t) + B_n sin(n w t)
# Kreyszig 11.3, Example: y'' + 0.05 y' + 25 y = r(t); r has a_n = 4/(n^2 pi), n odd.
#   The 5th harmonic resonates: amplitude C_5 = 0.2037.
# ==========================================================================================
publish("---- forced_oscillation_fourier ----");
R = fourier_coeffs_real(@forcing, 2 * pi, 7);
check("forcing: a_n = 4/(n^2 pi) for odd n", R["a"], 4 / pi * [1, 0, 1/9, 0, 1/25, 0, 1/49], 1e-10);
Y = forced_oscillation_fourier(R, 1, 0.05, 25, 1);
amp = Y["amplitude"];
check("C_5 = 0.2037 (resonance with n = 5)", amp[4], 0.2037, 1e-4);
check("C_1 = 0.0531", amp[0], 0.0531, 1e-4);

# ==========================================================================================
# fourier_transform_integral(@f, w[, limits]) - the continuous Fourier transform at the
#   frequencies w (complex in general). limits = [a, b] when f is 0 outside them.
#   e^(-x^2/2)  ->  e^(-w^2/2)          (Kreyszig 11.9, Example)
#   1 on (-1, 1)  ->  sqrt(2/pi) sin(w)/w
# ==========================================================================================
publish("---- fourier_transform_integral ----");
w = [0.5, 1, 2];
check("Gaussian is its own transform", fourier_transform_integral(@gauss, w), exp(-1 * w ^. 2 / 2), 1e-9);
check("box on (-1, 1)", fourier_transform_integral(@box, w, [-1, 1]), sqrt(2 / pi) * sin(w) /. w, 1e-10);

# ==========================================================================================
# fourier_sine_cosine_transform(@f, w, "cos"|"sin"[, b]) - transforms of f on (0, inf)
#   (Kreyszig 11.8): e^(-a x) -> sqrt(2/pi) a/(a^2 + w^2) (cos), sqrt(2/pi) w/(a^2 + w^2) (sin)
# ==========================================================================================
publish("---- fourier_sine_cosine_transform ----");
check("cosine transform of e^(-2x)", fourier_sine_cosine_transform(@decay, w, "cos"), sqrt(2 / pi) * 2 /. (4 + w ^. 2), 1e-9);
check("sine transform of e^(-2x)", fourier_sine_cosine_transform(@decay, w, "sin"), sqrt(2 / pi) * w /. (4 + w ^. 2), 1e-9);
publish("done: 04_fourier_series_transforms");
