# ========================================================================================
# E2 - error tests: Vector calculus (02_vector_calculus.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error
# in a script, so this file stops at the first block; to see a later block, put # in
# front of the failing lines above it (or run the blocks one by one).
#   expected  - the line(s) nc.exe prints for this call
#   works     - the corrected call (or what must change)
# ========================================================================================

# ---- names used by the blocks ----
function y = f1(x):
   y = x ^ 2;
fnend
function z = f2(x, y):
   z = x * y;
fnend
function F = F2(x, y, z):
   F = [x, y];
fnend
function y = needs_name(x):
   y = undefined_name + x;
fnend
function d = sys2(x1, x2):
   d = [x2, -1 * x1];
fnend
Z = [1, 2; 3, 4];

# ---- 1 ----
# expected: Error: div: give the field components as grids of one shape: (U, V[, dx, dy]) or (U, V, W[, dx, dy, dz])
# works:    v = div(Z, Z);
v = div(Z, [1, 2, 3; 4, 5, 6]);

# ---- 2 ----
# expected: Error: curl: a 3-component field needs 3-D grids, N-D matrices of shape [nz, ny, nx]
# works:    (3 components need 3-D grids [nz, ny, nx])
v = curl(Z, Z, Z);

# ---- 3 ----
# expected: Error: curl: curl is defined for points in 2 or 3 dimensions
# works:    v = curl(@F, [1, 2, 3]);
v = curl(@F2, [1, 2, 3, 4]);

# ---- 4 ----
# expected: Error: div: the function 'F2' must return as many components as the point has (3)
# works:    (F must return 3 components for a 3-D point)
v = div(@F2, [1, 2, 3]);

# ---- 5 ----
# expected: Error: arc_length3: the curve must be a matrix with one point per row, [x, y] or [x, y, z]
# works:    a = arc_length3([0, 0, 0; 1, 1, 1]);
a = arc_length3([1, 2, 3, 4]);

# ---- 6 ----
# expected: Error: frenet_frames: the curve needs at least 5 points
# works:    (5 points or more)
fr = frenet_frames([0, 0, 0; 1, 1, 1; 2, 2, 2]);

# ---- 7 ----
# expected: Error: directional_deriv: the direction must not be the zero vector
# works:    dd = directional_deriv(Z, [1, 0]);
dd = directional_deriv(Z, [0, 0]);

# ---- 8 ----
# expected: Error: directional_deriv: a 2-D grid needs a direction of 2 components
# works:    dd = directional_deriv(Z, [1, 1]);
dd = directional_deriv(Z, [1, 1, 1]);

# ---- 9 ----
# expected: Error: integrate_line: the function 'F2' must return 3 components
# works:    (F returns as many components as a point has)
w = integrate_line(@F2, [0, 0, 0; 1, 1, 1]);

# ---- 10 ----
# expected: Error: integrate_line: the path must be a matrix with one point per row, [x, y] or [x, y, z], at least 2 points
# works:    w = integrate_line(@F, [0, 0; 1, 2]);
w = integrate_line(@f1, [1, 2, 3]);

# ---- 11 ----
# expected: Error: is_conservative expects 2 to 7 argument(s), got 1 - usage: is_conservative(U, V[, tol, dx, dy]) | is_conservative(U, V, W[, tol, dx, dy, dz])
# works:    ic = is_conservative(Z, Z);
ic = is_conservative(Z);

# ---- 12 ----
# expected: Error: potential_field: the spacing must be [dx, dy]
# works:    pf = potential_field(Z, Z, [1, 2]);
pf = potential_field(Z, Z, [1, 2, 3]);

# ---- 13 ----
# expected: Error: integrate_surface: X, Y and Z must be grids of the same shape, at least 2 x 2
# works:    fl = integrate_surface(@F, X, Y, Z);
fl = integrate_surface(@F2, Z, Z, [1, 2]);

# ---- 14 ----
# expected: Error: integrate_volume: the first argument must be a grid of real numbers, at least 2 points along each axis: a matrix (2-D) or an N-D matrix of shape [nz, ny, nx] (3-D)
# works:    iv = integrate_volume(Z);
iv = integrate_volume([1, 2, 3]);

# ---- 15 ----
# expected: Error: eval_gauss_divergence expects 2 to 6 argument(s), got 1 - usage: eval_gauss_divergence(U, V[, dx, dy]) | eval_gauss_divergence(U, V, W[, dx, dy, dz])
# works:    eg = eval_gauss_divergence(Z, Z);
eg = eval_gauss_divergence(Z);
