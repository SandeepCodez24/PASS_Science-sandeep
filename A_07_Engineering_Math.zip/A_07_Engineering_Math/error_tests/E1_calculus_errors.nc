# ========================================================================================
# E1 - error tests: Calculus operations (01_calculus_operations.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error
# in a script, so this file stops at the first block; to see a later block, put # in
# front of the failing lines above it (or run the blocks one by one).
#   expected  - the line(s) nc.exe prints for this call
#   works     - the corrected call (or what must change)
# ========================================================================================

# ---- names used by the blocks ----
function y = f1(x):
   y = x ^ 2;
fnend
function z = f2(x, y):
   z = x * y;
fnend
function F = F2(x, y, z):
   F = [x, y];
fnend
function y = needs_name(x):
   y = undefined_name + x;
fnend
function d = sys2(x1, x2):
   d = [x2, -1 * x1];
fnend
Z = [1, 2; 3, 4];

# ---- 1 ----
# expected: Error: ddt: ddt(@f, x[, h]) needs the point x
# works:    d = ddt(@f1, 2);
d = ddt(@f1);

# ---- 2 ----
# expected: Error: ddt: the second argument must be a positive number
# works:    d = ddt([1, 2, 3], 0.5);
d = ddt([1, 2, 3], 0);

# ---- 3 ----
# expected: Error: ddt: the coordinates must have as many values as the samples (3)
# works:    d = ddt([1, 2, 3], [0, 1, 3]);
d = ddt([1, 2, 3], [0, 1]);

# ---- 4 ----
# expected: Error: ddt: ddt differentiates one sampled line; for a grid use pddt(Z, "x") or grad(Z)
# works:    d = pddt([1, 2; 3, 4], "x");
d = ddt([1, 2; 3, 4]);

# ---- 5 ----
# expected: Error: ddt: the step h must not be 0
# works:    d = ddt([1, 2], [1, 2], 0.1);
d = ddt([1, 2], [1, 2], 0);

# ---- 6 ----
# expected: Error: Undefined variable 'undefined_name'
# expected: Error: ddt: the function 'needs_name' could not be evaluated (it must return a number for each input)
# works:    (the function itself must run)
d = ddt(@needs_name, 1);

# ---- 7 ----
# expected: Error: pddt: the second argument must name the variable: "x", "y" or its number 1 to 2
# works:    d = pddt(Z, "y");
d = pddt(Z, "w");

# ---- 8 ----
# expected: Error: pddt: the third argument must name the variable: "x", "y" or its number 1 to 2
# works:    d = pddt(@f2, [1, 2], 2);
d = pddt(@f2, [1, 2], 3);

# ---- 9 ----
# expected: Error: pddt: pddt(@f, point, var[, h]) needs the variable
# works:    d = pddt(@f2, [1, 2], "x");
d = pddt(@f2, [1, 2]);

# ---- 10 ----
# expected: Error: continuity: the argument must be a number, an array or a matrix of numbers
# works:    c = continuity([1, 2]);
c = continuity([1, "a"]);

# ---- 11 ----
# expected: Error: continuity: the third argument must be a positive number
# works:    c = continuity(@f1, 1, 1e-6);
c = continuity(@f1, 1, -1);

# ---- 12 ----
# expected: Error: grad: give the function as a reference: grad(@f, point)
# works:    g = grad(@f2, [1, 2]);
g = grad("f1", [1, 2]);

# ---- 13 ----
# expected: Error: grad: a 2-D grid takes 2 spacings at most
# works:    g = grad(Z, 1, 1);
g = grad(Z, 1, 1, 1);

# ---- 14 ----
# expected: Error: laplace: the second argument must be a positive number
# works:    l = laplace([1, 2, 3], 0.5);
l = laplace([1, 2, 3], 0);

# ---- 15 ----
# expected: Error: laplace: laplace(@f, point[, h]) needs the point
# works:    l = laplace(@f1, [1]);
l = laplace(@f1);

# ---- 16 ----
# expected: Error: green_integral: P and Q must be 2-D grids of the same shape (rows along y, columns along x)
# works:    gi = green_integral(Z, Z);
gi = green_integral(Z, [1, 2, 3; 4, 5, 6]);

# ---- 17 ----
# expected: Error: green_integral: give the functions as references: green_integral(@P, @Q, x0, x1, y0, y1)
# works:    gi = green_integral(@P, @Q, 0, 1, 0, 1);
gi = green_integral("P", "Q", 0, 1, 0, 1);

# ---- 18 ----
# expected: Error: stokes_integral: curl expects a 3-element vector (array of length 3)
# works:    s = stokes_integral([1, 2, 3]);
s = stokes_integral([1, 2]);

# ---- 19 ----
# expected: Error: stokes_integral: the function 'F2' must return 3 components [F1, F2, F3]
# works:    (F must return [F1, F2, F3])
s = stokes_integral(@F2, Z, Z, Z);

# ---- 20 ----
# expected: Error: stokes_integral: stokes_integral(@F, X, Y, Z) needs the surface grids
# works:    s = stokes_integral(@F, X, Y, Z);
s = stokes_integral(@F2, Z, Z);

# ---- 21 ----
# expected: Error: rad_of_con: at least two coefficients must be nonzero
# works:    r = rad_of_con([1, 1, 1]);
r = rad_of_con([1, 0, 0]);

# ---- 22 ----
# expected: Error: rad_of_con: the first argument must have at least 2 values
# works:    r = rad_of_con([1, 2, 3]);
r = rad_of_con(5);

# ---- 23 ----
# expected: Error: ddt expects 1 to 3 argument(s), got 0 - usage: ddt(Y[, h or x]) | ddt(@f, x[, h]) | ddt(f_plus, f_minus, h)
# works:    d = ddt([1, 4, 9]);
d = ddt();

# ---- 24 ----
# expected: Error: ddt: its values cannot be named yet - give them in order
# works:    d = ddt(@f1, 1, 0.1);
d = ddt(@f1, 1, h = 0.1);
