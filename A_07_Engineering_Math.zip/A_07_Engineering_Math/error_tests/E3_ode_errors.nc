# ========================================================================================
# E3 - error tests: Ordinary differential equations (03_ordinary_differential_equations.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error
# in a script, so this file stops at the first block; to see a later block, put # in
# front of the failing lines above it (or run the blocks one by one).
#   expected  - the line(s) nc.exe prints for this call
#   works     - the corrected call (or what must change)
# ========================================================================================

# ---- names used by the blocks ----
function y = f1(x):
   y = x ^ 2;
fnend
function z = f2(x, y):
   z = x * y;
fnend
function F = F2(x, y, z):
   F = [x, y];
fnend
function y = needs_name(x):
   y = undefined_name + x;
fnend
function d = sys2(x1, x2):
   d = [x2, -1 * x1];
fnend
Z = [1, 2; 3, 4];

# ---- 1 ----
# expected: Error: direction_field: the third argument must be an array of real numbers
# works:    df = direction_field(@f2, [1, 2], [0, 1]);
df = direction_field(@f2, [1, 2], "y");

# ---- 2 ----
# expected: Error: picard_iteration: t must increase
# works:    pc = picard_iteration(@f2, 1, [0, 0.5, 1], 3);
pc = picard_iteration(@f2, 1, [0, 1, 0.5], 3);

# ---- 3 ----
# expected: Error: picard_iteration: the fourth argument must be a whole number from 1 to 200
# works:    pc = picard_iteration(@f2, 1, [0, 1], 3);
pc = picard_iteration(@f2, 1, [0, 1], 0);

# ---- 4 ----
# expected: Error: wronskian: the Wronskian needs 2 to 6 solutions
# works:    w = wronskian(["y1", "y2"], [0, 1]);
w = wronskian(["f1"], [0, 1]);

# ---- 5 ----
# expected: Error: variation_of_parameters: the Wronskian of y1 and y2 is 0 at x = 0 - they must be independent solutions
# works:    (y1 and y2 must be independent)
vp = variation_of_parameters(@f1, @f1, @f1, [0, 1, 2]);

# ---- 6 ----
# expected: Error: variation_of_parameters: the first argument must be a function or have one value per x (3)
# works:    (one sample per x)
vp = variation_of_parameters([1, 2], @f1, @f1, [0, 1, 2]);

# ---- 7 ----
# expected: Error: resonance_peak: the damping c must not be negative
# works:    rp = resonance_peak(1, 1, 4, [0, 4]);
rp = resonance_peak(1, -1, 4, [0, 4]);

# ---- 8 ----
# expected: Error: resonance_peak: the first argument must be a positive number
# works:    rp = resonance_peak(1, 1, 4, [0, 4]);
rp = resonance_peak(0, 1, 4, [0, 4]);

# ---- 9 ----
# expected: Error: phase_plane: the system must be a function returning [f1, f2, ...] (e.g. @F), or a list of functions, one per equation (e.g. ["f1", "f2"])
# works:    pp = phase_plane(@sys2, [0, 1], [0, 1]);
pp = phase_plane(5, [0, 1], [0, 1]);

# ---- 10 ----
# expected: Error: find_critical_points: each upper bound must be larger than its lower bound
# works:    cp = find_critical_points(@sys2, [0, 1, 0, 1]);
cp = find_critical_points(@sys2, [1, 0, 0, 1]);

# ---- 11 ----
# expected: Error: find_critical_points: bounds must be [x1_min, x1_max, x2_min, x2_max] (or 6 values for 3 equations)
# works:    cp = find_critical_points(@sys2, [0, 1, 0, 1]);
cp = find_critical_points(@sys2, [0, 1, 0]);

# ---- 12 ----
# expected: Error: classify_critical_point: J must be the 2 x 2 Jacobian of a system of two equations at the point
# works:    cc = classify_critical_point([0, 1; -1, 0]);
cc = classify_critical_point([1, 2, 3; 4, 5, 6; 7, 8, 9]);

# ---- 13 ----
# expected: Error: power_series_coeffs: the fifth argument must be a whole number from 2 to 200
# works:    ps = power_series_coeffs(0, 1, 0, 0, 6);
ps = power_series_coeffs(0, 1, 0, 0, 1);

# ---- 14 ----
# expected: Error: power_series_coeffs: ic must be [y(x0), y'(x0)]
# works:    ps = power_series_coeffs(0, 1, 0, 0, 5, [1, 0]);
ps = power_series_coeffs(0, 1, 0, 0, 5, [1]);

# ---- 15 ----
# expected: Error: sturm_liouville_solve: the interval needs b > a
# works:    sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [pi, 1, 0], 3);
sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [0, 1, 0], 3);

# ---- 16 ----
# expected: Error: sturm_liouville_solve: each boundary condition needs k1, k2 (or l1, l2) not both 0
# works:    (k1 y(a) + k2 y'(a) = 0 needs k1 or k2)
sl = sturm_liouville_solve(1, 0, 1, [0, 0, 0], [3, 1, 0], 3);

# ---- 17 ----
# expected: Error: sturm_liouville_solve: a regular Sturm-Liouville problem needs p > 0 and r > 0 on [a, b]
# works:    (p > 0 and r > 0)
sl = sturm_liouville_solve(-1, 0, 1, [0, 1, 0], [3, 1, 0], 3);

# ---- 18 ----
# expected: Error: sturm_liouville_solve: M must be at least 4 * N grid intervals to resolve N modes
# works:    sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [3, 1, 0], 100, 400);
sl = sturm_liouville_solve(1, 0, 1, [0, 1, 0], [3, 1, 0], 100, 50);

# ---- 19 ----
# expected: Error: laplace_transform: the integral did not converge - e^(-s t) f(t) must decay (try a larger Re(s))
# works:    lt = laplace_transform(@f1, 1);
lt = laplace_transform(@f1, -1);

# ---- 20 ----
# expected: Error: inv_laplace_transform: every t must be positive
# works:    il = inv_laplace_transform(@f1, [0.5, 1]);
il = inv_laplace_transform(@f1, [0, 1]);

# ---- 21 ----
# expected: Error: inv_laplace_transform: method must be "talbot" (F takes complex s) or "stehfest" (real s only)
# works:    il = inv_laplace_transform(@f1, [1], "talbot");
il = inv_laplace_transform(@f1, [1], "euler");

# ---- 22 ----
# expected: Error: inv_laplace_transform: the Stehfest method needs an even M
# works:    il = inv_laplace_transform(@f1, [1], "stehfest", 14);
il = inv_laplace_transform(@f1, [1], "stehfest", 13);

# ---- 23 ----
# expected: Error: dirac_delta_approx: the third argument must be a positive number
# works:    dl = dirac_delta_approx([0, 1], 0, 0.1);
dl = dirac_delta_approx([0, 1], 0, 0);

# ---- 24 ----
# expected: Error: dirac_delta_approx: shape must be "rect" or "gauss"
# works:    dl = dirac_delta_approx([0, 1], 0, 1, "rect");
dl = dirac_delta_approx([0, 1], 0, 1, "box");

# ---- 25 ----
# expected: Error: solve_volterra_eq: t must increase
# works:    vo = solve_volterra_eq(@f2, @f1, [0, 1, 2]);
vo = solve_volterra_eq(@f2, @f1, [0, 2, 1]);

# ---- 26 ----
# expected: Error: solve_volterra_eq: f must be a function or have one value per t
# works:    vo = solve_volterra_eq(@f2, [1, 2, 3], [0, 1, 2]);
vo = solve_volterra_eq(@f2, [1, 2], [0, 1, 2]);
