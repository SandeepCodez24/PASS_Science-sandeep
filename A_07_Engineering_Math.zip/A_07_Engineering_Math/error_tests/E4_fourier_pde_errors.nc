# ========================================================================================
# E4 - error tests: Fourier series and PDEs (04_*.nc, 05_*.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error
# in a script, so this file stops at the first block; to see a later block, put # in
# front of the failing lines above it (or run the blocks one by one).
#   expected  - the line(s) nc.exe prints for this call
#   works     - the corrected call (or what must change)
# ========================================================================================

# ---- names used by the blocks ----
function y = f1(x):
   y = x ^ 2;
fnend
function z = f2(x, y):
   z = x * y;
fnend
function F = F2(x, y, z):
   F = [x, y];
fnend
function y = needs_name(x):
   y = undefined_name + x;
fnend
function d = sys2(x1, x2):
   d = [x2, -1 * x1];
fnend
Z = [1, 2; 3, 4];

# ---- 1 ----
# expected: Error: fourier_coeffs_real: the second argument must be a positive number
# works:    fc = fourier_coeffs_real(@f1, 2, 3);
fc = fourier_coeffs_real(@f1, 0, 3);

# ---- 2 ----
# expected: Error: fourier_coeffs_real: the third argument must be a whole number from 1 to 500
# works:    fc = fourier_coeffs_real(@f1, 2, 3);
fc = fourier_coeffs_real(@f1, 2, 0);

# ---- 3 ----
# expected: Error: fourier_coeffs_complex: the first argument must be a function, e.g. @f
# works:    fc = fourier_coeffs_complex(@f1, 2, 3);
fc = fourier_coeffs_complex(5, 2, 3);

# ---- 4 ----
# expected: Error: half_range_extension: the type must be "even" (cosine series) or "odd" (sine series)
# works:    hr = half_range_extension(@f1, 1, 3, "even");
hr = half_range_extension(@f1, 1, 3, "middle");

# ---- 5 ----
# expected: Error: parseval_error: the coefficients must be a dict {a0, a, b}, e.g. the result of fourier_coeffs_real
# works:    pe = parseval_error(@f1, fourier_coeffs_real(@f1, 2, 3), 2);
pe = parseval_error(@f1, [1, 2], 2);

# ---- 6 ----
# expected: Error: forced_oscillation_fourier: the coefficients must be a dict {a0, a, b}, e.g. the result of fourier_coeffs_real
# works:    fo = forced_oscillation_fourier(fourier_coeffs_real(@f1, 2, 3), 1, 0.1, 1, 1);
fo = forced_oscillation_fourier(dict(), 1, 0, 1, 1);

# ---- 7 ----
# expected: Error: fourier_transform_integral: the integral did not converge - f must decay at infinity (or give finite limits [a, b] when f is 0 outside them)
# works:    (f must decay at infinity, or give limits [a, b])
ft = fourier_transform_integral(@f1, [1]);

# ---- 8 ----
# expected: Error: fourier_transform_integral: the limits need b > a
# works:    ft = fourier_transform_integral(@f1, [1], [0, 1]);
ft = fourier_transform_integral(@f1, [1], [1, 0]);

# ---- 9 ----
# expected: Error: fourier_sine_cosine_transform: the type must be "cos" or "sin"
# works:    st = fourier_sine_cosine_transform(@f1, [1], "cos", 1);
st = fourier_sine_cosine_transform(@f1, [1], "tan");

# ---- 10 ----
# expected: Error: solve_wave_1d_fourier: the third argument must be a positive number
# works:    w1 = solve_wave_1d_fourier(@f1, 0, 1, 1, [0, 1], [0], 3);
w1 = solve_wave_1d_fourier(@f1, 0, 0, 1, [0, 1], [0], 3);

# ---- 11 ----
# expected: Error: solve_wave_1d_fourier: t must not be negative
# works:    w1 = solve_wave_1d_fourier(@f1, 0, 1, 1, [0, 1], [1], 3);
w1 = solve_wave_1d_fourier(@f1, 0, 1, 1, [0, 1], [-1], 3);

# ---- 12 ----
# expected: Error: solve_wave_1d_dalembert: the third argument must be a positive number
# works:    wd = solve_wave_1d_dalembert(@f1, 0, 1, [0], [0]);
wd = solve_wave_1d_dalembert(@f1, 0, -1, [0], [0]);

# ---- 13 ----
# expected: Error: solve_heat_1d_fourier: the sixth argument must be a whole number from 1 to 1000
# works:    h1 = solve_heat_1d_fourier(@f1, 1, 1, [0, 1], [0], 5);
h1 = solve_heat_1d_fourier(@f1, 1, 1, [0, 1], [0], 0);

# ---- 14 ----
# expected: Error: solve_wave_2d_rectangular: argument 9 must be a whole number from 1 to 200
# works:    w2 = solve_wave_2d_rectangular(@f2, 0, 1, 1, 1, [0, 1], [0, 1], [0], 2, 2);
w2 = solve_wave_2d_rectangular(@f2, 0, 1, 1, 1, [0, 1], [0, 1], [0], 0, 2);

# ---- 15 ----
# expected: Error: solve_wave_2d_circular_bessel: every r must be within the membrane, 0 <= r <= R
# works:    wb = solve_wave_2d_circular_bessel(@f1, 0, 1, 1, [0, 1], [0], 3);
wb = solve_wave_2d_circular_bessel(@f1, 0, 1, 1, [0, 2], [0], 3);

# ---- 16 ----
# expected: Error: solve_laplace_2d_polar: r must not be negative
# works:    lp = solve_laplace_2d_polar(@f1, 1, [1], [0], 3);
lp = solve_laplace_2d_polar(@f1, 1, [-1], [0], 3);

# ---- 17 ----
# expected: Error: solve_laplace_3d_spherical: the second argument must be a positive number
# works:    ls = solve_laplace_3d_spherical(@f1, 1, [0], [0], 3);
ls = solve_laplace_3d_spherical(@f1, 0, [0], [0], 3);

# ---- 18 ----
# expected: Error: pde_solve_laplace_transform: M (Stehfest terms) must be even
# works:    pl = pde_solve_laplace_transform(@f1, 0, 0, 1, [0, 1], [0.1], 14);
pl = pde_solve_laplace_transform(@f1, 0, 0, 1, [0, 1], [0.1], 7);

# ---- 19 ----
# expected: Error: pde_solve_laplace_transform: x must increase
# works:    pl = pde_solve_laplace_transform(@f1, 0, 0, 1, [0, 1], [0.1]);
pl = pde_solve_laplace_transform(@f1, 0, 0, 1, [1, 0], [0.1]);
