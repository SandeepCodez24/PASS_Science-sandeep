# ========================================================================================
# E6 - error tests: Probability and statistics (07_probability_statistics.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error
# in a script, so this file stops at the first block; to see a later block, put # in
# front of the failing lines above it (or run the blocks one by one).
#   expected  - the line(s) nc.exe prints for this call
#   works     - the corrected call (or what must change)
# ========================================================================================

# ---- names used by the blocks ----
function y = f1(x):
   y = x ^ 2;
fnend
function z = f2(x, y):
   z = x * y;
fnend
function F = F2(x, y, z):
   F = [x, y];
fnend
function y = needs_name(x):
   y = undefined_name + x;
fnend
function d = sys2(x1, x2):
   d = [x2, -1 * x1];
fnend
Z = [1, 2; 3, 4];

# ---- 1 ----
# expected: Error: generate_permutations: the elements must be a vector, e.g. [1, 2, 3] or ["a", "b", "c"]
# works:    gp = generate_permutations([1, 2, 3]);
gp = generate_permutations(Z);

# ---- 2 ----
# expected: Error: generate_permutations: the second argument must be a whole number from 1 to 3
# works:    gp = generate_permutations([1, 2, 3], 2);
gp = generate_permutations([1, 2, 3], 4);

# ---- 3 ----
# expected: Error: generate_permutations: that is 479001599 permutations - more than 2 000 000 rows
# works:    (at most 2 000 000 rows)
gp = generate_permutations(space(1, 12, 12));

# ---- 4 ----
# expected: Error: generate_combinations: the second argument must be a whole number from 1 to 2
# works:    gcb = generate_combinations([1, 2, 3], 2);
gcb = generate_combinations([1, 2], 3);

# ---- 5 ----
# expected: Error: conditional_distribution: the condition has probability 0, so the conditional distribution is not defined
# works:    cdd = conditional_distribution([0.5, 0.5; 0, 0], 0, 0);
cdd = conditional_distribution([0.5, 0.5; 0, 0], 1, 0);

# ---- 6 ----
# expected: Error: conditional_distribution: a joint distribution has no negative probabilities
# works:    (probabilities are not negative)
cdd = conditional_distribution([0.5, -0.5; 0, 0], 0, 0);

# ---- 7 ----
# expected: Error: conditional_distribution: the second argument must be a whole number from 0 to 1
# works:    (rows are numbered from 0)
cdd = conditional_distribution([0.5, 0.5; 0, 0], 2, 0);

# ---- 8 ----
# expected: Error: confidence_interval_mean: the first argument must have at least 2 values
# works:    cim = confidence_interval_mean([1, 2], 0.95);
cim = confidence_interval_mean([1], 0.95);

# ---- 9 ----
# expected: Error: confidence_interval_mean: the confidence level must be between 0 and 1 (e.g. 0.95) or a percentage (95)
# works:    cim = confidence_interval_mean([1, 2, 3], 95);
cim = confidence_interval_mean([1, 2, 3], 100);

# ---- 10 ----
# expected: Error: confidence_interval_mean: the third argument must be a positive number
# works:    cim = confidence_interval_mean([1, 2, 3], 0.95, 4);
cim = confidence_interval_mean([1, 2, 3], 0.95, 0);

# ---- 11 ----
# expected: Error: confidence_interval_var: the confidence level must be between 0 and 1 (e.g. 0.95) or a percentage (95)
# works:    civ = confidence_interval_var([1, 2, 3], 0.9);
civ = confidence_interval_var([1, 2, 3], 0);

# ---- 12 ----
# expected: Error: control_chart_limits: data must hold one sample per row: at least 2 samples of 2 to 100 values
# works:    ccl = control_chart_limits([1, 2, 3; 2, 3, 4]);
ccl = control_chart_limits([1, 2, 3]);

# ---- 13 ----
# expected: Error: control_chart_limits: type must be "x_bar", "r", "s" or "p"
# works:    ccl = control_chart_limits([1, 2; 3, 4], "r");
ccl = control_chart_limits([1, 2; 3, 4], "u");

# ---- 14 ----
# expected: Error: control_chart_limits: a p chart needs 0 (good) / 1 (defective) values, one sample per row
# works:    ccl = control_chart_limits([1, 0; 0, 0], "p");
ccl = control_chart_limits([1, 2; 3, 4], "p");

# ---- 15 ----
# expected: Error: operating_characteristic_curve: the lot size N must be a whole number >= n (or 0 / inf for a very large lot)
# works:    oc = operating_characteristic_curve(30, 5, 0, [0.1]);
oc = operating_characteristic_curve(3, 5, 0, [0.1]);

# ---- 16 ----
# expected: Error: operating_characteristic_curve: every defect fraction p must be in [0, 1]
# works:    oc = operating_characteristic_curve(20, 5, 0, [0.15]);
oc = operating_characteristic_curve(20, 5, 0, [1.5]);

# ---- 17 ----
# expected: Error: sign_test: the second argument must be the median (one number) or a paired sample of the same size
# works:    sg = sign_test([1, 2, 3], [1, 2, 2]);
sg = sign_test([1, 2, 3], [1, 2]);

# ---- 18 ----
# expected: Error: sign_test: every value equals the median - no signs to test
# works:    (no value differs from the median)
sg = sign_test([1, 1, 1], 1);

# ---- 19 ----
# expected: Error: sign_test: alternative must be "two-sided", "greater" or "less"
# works:    sg = sign_test([1, 2, 3], 1, "two-sided");
sg = sign_test([1, 2, 3], 1, "both");
