# ========================================================================================
# E5 - error tests: Complex analysis (06_complex_analysis.nc)
#
# Each block below makes ONE call that nc.exe refuses. nc.exe stops at the first error
# in a script, so this file stops at the first block; to see a later block, put # in
# front of the failing lines above it (or run the blocks one by one).
#   expected  - the line(s) nc.exe prints for this call
#   works     - the corrected call (or what must change)
# ========================================================================================

# ---- names used by the blocks ----
function y = f1(x):
   y = x ^ 2;
fnend
function z = f2(x, y):
   z = x * y;
fnend
function F = F2(x, y, z):
   F = [x, y];
fnend
function y = needs_name(x):
   y = undefined_name + x;
fnend
function d = sys2(x1, x2):
   d = [x2, -1 * x1];
fnend
Z = [1, 2; 3, 4];

# ---- 1 ----
# expected: Error: is_analytic: F must be a grid of at least 2 x 2 values, F[i, j] = f(x_j + i y_i)
# works:    ia = is_analytic(Z, 1, 1);
ia = is_analytic([1, 2, 3], 1, 1);

# ---- 2 ----
# expected: Error: complex_deriv: the second argument must be a number or a matrix of numbers
# works:    cd1 = complex_deriv(@f1, 1 + 1i);
cd1 = complex_deriv(@f1, "z");

# ---- 3 ----
# expected: Error: contour_integrate: the second argument must be a path: an array of 2 or more complex points (see generate_contour)
# works:    ci = contour_integrate(@f1, [0, 1 + 1i]);
ci = contour_integrate(@f1, [1]);

# ---- 4 ----
# expected: Error: cauchy_eval: the second argument must be a number (real or complex)
# works:    ce = cauchy_eval(@f1, 0.5, generate_contour("circle", [0, 1]));
ce = cauchy_eval(@f1, [1, 2], generate_contour("circle", [0, 1]));

# ---- 5 ----
# expected: Error: cauchy_deriv: the third argument must be a whole number from 0 to 30
# works:    cdv = cauchy_deriv(@f1, 0, 2, generate_contour("circle", [0, 1]));
cdv = cauchy_deriv(@f1, 0, 31, generate_contour("circle", [0, 1]));

# ---- 6 ----
# expected: Error: generate_contour: type must be "circle", "arc", "line", "polygon", "rectangle" or "semicircle"
# works:    gc = generate_contour("circle", [0, 1]);
gc = generate_contour("star", [1]);

# ---- 7 ----
# expected: Error: generate_contour: circle needs [center, radius(, n)] with radius > 0
# works:    gc = generate_contour("circle", [0, 1]);
gc = generate_contour("circle", [0, -1]);

# ---- 8 ----
# expected: Error: generate_contour: rectangle needs x1 > x0 and y1 > y0
# works:    gc = generate_contour("rectangle", [0, 0, 1, 1]);
gc = generate_contour("rectangle", [1, 1, 0, 0]);

# ---- 9 ----
# expected: Error: generate_contour: polygon needs at least 3 vertices
# works:    gc = generate_contour("polygon", [0, 1, 1i]);
gc = generate_contour("polygon", [0, 1]);

# ---- 10 ----
# expected: Error: taylor_coeffs_cplx: the third argument must be a whole number from 1 to 500
# works:    tc = taylor_coeffs_cplx(@f1, 0, 4);
tc = taylor_coeffs_cplx(@f1, 0, 0);

# ---- 11 ----
# expected: Error: laurent_coeffs: the third argument must be a positive number
# works:    lc = laurent_coeffs(@f1, 0, 1, 3);
lc = laurent_coeffs(@f1, 0, -1, 3);

# ---- 12 ----
# expected: Error: find_poles: the domain must be a grid of complex points or [x_min, x_max, y_min, y_max]
# works:    fp = find_poles(@f1, [0, 1, 0, 1]);
fp = find_poles(@f1, [1, 0, 0, 1]);

# ---- 13 ----
# expected: Error: complex_residue expects 2 to 3 argument(s), got 1 - usage: complex_residue(@f, z0[, r])
# works:    rr = complex_residue(@f1, 0);
rr = complex_residue(@f1);

# ---- 14 ----
# expected: Error: complex_residue: the first argument must be a function, e.g. @f
# works:    rr = residue([1], [1, 3, 2]);
rr = complex_residue([1], [1, 3, 2]);

# ---- 15 ----
# expected: Error: real_improper_integral: the first argument must be a function, e.g. @f
# works:    ri = real_improper_integral(@f);
ri = real_improper_integral(5);

# ---- 16 ----
# expected: Error: Undefined variable 'undefined_name'
# expected: Error: real_trig_integral: the function 'needs_name' could not be evaluated (it must return a number for each input)
# works:    (the function itself must run)
rt = real_trig_integral(@needs_name);

# ---- 17 ----
# expected: Error: mobius_transform: ad - bc must not be 0 (the map would be constant)
# works:    mt = mobius_transform(1, 1, 2, 3, 4);
mt = mobius_transform(1, 1, 2, 2, 4);

# ---- 18 ----
# expected: Error: mobius_from_points: the 3 points (and the 3 images) must be distinct
# works:    mp = mobius_from_points([1, 2, 3], [1, 2, 4]);
mp = mobius_from_points([1, 2, 3], [1, 1, 2]);

# ---- 19 ----
# expected: Error: mobius_from_points: give 3 points z = [z1, z2, z3] and their images w = [w1, w2, w3]
# works:    mp = mobius_from_points([1, 2, 3], [1, 2, 4]);
mp = mobius_from_points([1, 2], [1, 2]);

# ---- 20 ----
# expected: Error: cross_ratio: the four inputs must be numbers or arrays of one size
# works:    cr = cross_ratio(2, 1i, -2, 0.5);
cr = cross_ratio([1, 2], [1, 2, 3], 1, 1);

# ---- 21 ----
# expected: Error: harmonic_conjugate: the first argument must be a grid of real numbers, at least 2 points along each axis: a matrix (2-D) or an N-D matrix of shape [nz, ny, nx] (3-D)
# works:    hc = harmonic_conjugate(Z, 1, 1);
hc = harmonic_conjugate([1, 2, 3], 1, 1);

# ---- 22 ----
# expected: Error: poisson_integral_disk: every r must be in [0, R]
# works:    pi1 = poisson_integral_disk(@f1, [0.5], [0]);
pi1 = poisson_integral_disk(@f1, [2], [0]);

# ---- 23 ----
# expected: Error: complex_potential: Z must be a grid of at least 2 x 2 complex points (rows along y, columns along x)
# works:    cpo = complex_potential(Z, Z + 1i);
cpo = complex_potential([1, 2; 3, 4], [1, 2, 3]);

# ---- 24 ----
# expected: Error: joukowski_map: the second argument must be a number (real or complex)
# works:    jm = joukowski_map(1, 2);
jm = joukowski_map(1, [1, 2]);
