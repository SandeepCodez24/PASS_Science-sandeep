# ==========================================================================================
# 07  Probability and mathematical statistics  (Kreyszig, chapters 24 and 25)
#
#   ch. 24  generate_permutations  generate_combinations  conditional_distribution
#   ch. 25  confidence_interval_mean  confidence_interval_var  control_chart_limits
#           operating_characteristic_curve  sign_test
#
# Already in NC, so not added again:
#   empirical CDF at points           ecdf(data, x)
#   marginals of a joint table        margins(P)
#   Kolmogorov-Smirnov test           ks_test / ks_1samp / ks_2samp
#   Wilcoxon rank-sum test            rank_sums (and mann_whitney)
#   mean, var, sd, null_hypo, p_val_cal, chi_test, lsm and the distributions
#
# Every check publishs PASS or FAIL.
# Run:  nc.exe 07_probability_statistics.nc
# ==========================================================================================

function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend

# ==========================================================================================
# generate_permutations(elements[, r]) - every ordered selection of r elements (all n
#   when r is left out), one per row, in lexicographic order: n!/(n - r)! rows
# generate_combinations(elements, r)  - every unordered selection: C(n, r) rows
#   (Kreyszig 24.4). The elements may be numbers or text.
# ==========================================================================================
publish("---- permutations and combinations ----");
P = generate_permutations([1, 2, 3], 2);
check("3P2: the 6 ordered pairs", P, [1, 2; 1, 3; 2, 1; 2, 3; 3, 1; 3, 2], 0);
check("4! = 24 permutations of 4 elements", shape(generate_permutations([1, 2, 3, 4])), [24, 4], 0);
C = generate_combinations([1, 2, 3, 4], 2);
check("4C2: the 6 pairs", C, [1, 2; 1, 3; 1, 4; 2, 3; 2, 4; 3, 4], 0);
T = generate_combinations(["a", "b", "c"], 2);
publish("text elements:", T);
# exact probability by counting: 2 cards from {1, 2, 3, 4, 5}; P(sum is even)
H = generate_combinations([1, 2, 3, 4, 5], 2);
even = 0;
for k = [0:9]:
   if (H[k, 0] + H[k, 1]) % 2 == 0:
      even = even + 1;
   iend
fend
check("P(even sum) = 4/10 by counting the sample space", even / 10, 0.4, 1e-15);

# ==========================================================================================
# conditional_distribution(P, k, axis) - from a joint distribution P[i, j] =
#   P(X = x_i, Y = y_j)  (Kreyszig 24.9):
#   axis 0: given X = x_k (row k)     -> P(Y = y_j | X = x_k), a row
#   axis 1: given Y = y_k (column k)  -> P(X = x_i | Y = y_k), a column
#   (marginal distributions: margins(P))
# ==========================================================================================
publish("---- conditional_distribution ----");
J = [0.1, 0.2; 0.3, 0.4];
check("P(Y | X = x_0) = [1/3, 2/3]", conditional_distribution(J, 0, 0), [1 / 3, 2 / 3], 1e-15);
check("P(X | Y = y_1) = [1/3; 2/3]", conditional_distribution(J, 1, 1), [0.2 / 0.6; 0.4 / 0.6], 1e-15);

# ==========================================================================================
# confidence_interval_mean(data, level[, known_variance]) - dict {lower, upper, mean,
#   half_width, c, method}: x_bar -+ c sigma/sqrt(n) with sigma known ("normal"), else
#   x_bar -+ c s/sqrt(n) with Student's t, n - 1 degrees of freedom ("t")  (Kreyszig 25.3)
#   level: 0.95 or 95
# confidence_interval_var(data, level) - (n - 1) s^2 / c2 <= sigma^2 <= (n - 1) s^2 / c1
#   with chi-square quantiles c1, c2  (Kreyszig 25.3)
# ==========================================================================================
publish("---- confidence intervals ----");
# Kreyszig 25.3, Example 1: sigma^2 = 9, n = 100, x_bar = 5, 95 %  ->  [4.412, 5.588]
ci = confidence_interval_mean(5 * ones(1, 100), 0.95, 9);
check("known variance: CONF{4.412 <= mu <= 5.588}", [ci["lower"], ci["upper"]], [4.412, 5.588], 1e-3);
x = [1, 2, 3, 4, 5];                   # mean 3, s^2 = 2.5
ct = confidence_interval_mean(x, 95);
check("t interval: c = 2.776 (4 degrees of freedom)", ct["c"], 2.7764451051977987, 1e-12);
check("t interval: 3 -+ 1.963", [ct["lower"], ct["upper"]], [3 - 1.9632432, 3 + 1.9632432], 1e-6);
cv = confidence_interval_var(x, 0.95);
check("variance: [0.8974, 20.643]", [cv["lower"], cv["upper"]], [0.89740, 20.64323], 1e-4);

# ==========================================================================================
# control_chart_limits(data[, type][, k]) - Shewhart control chart, one sample per ROW
#   (Kreyszig 25.5). type "x_bar" (mean), "r" (range), "s" (standard deviation) or "p"
#   (fraction defective, 0/1 data); k-sigma limits (3 by default).
#   Returns {cl, ucl, lcl, values (one per sample), out_of_control (sample indices)}.
#   The constants d2, d3 and c4 are computed for any sample size (no table).
# ==========================================================================================
publish("---- control_chart_limits ----");
D = [10.1, 9.8, 10.0, 10.3; 9.9, 10.2, 10.1, 9.7; 10.0, 10.4, 9.9, 10.1; 9.6, 10.0, 10.2, 10.0; 10.2, 9.9, 10.1, 10.0];
xb = control_chart_limits(D, "x_bar");
rb = control_chart_limits(D, "r");
Rbar = rb["cl"];
# n = 4: A2 = 3/(d2 sqrt(n)) = 0.7285, D4 = 2.282, D3 = 0 (the usual table values)
check("x_bar chart: UCL = x_bar_bar + 0.7285 R_bar", xb["ucl"] - xb["cl"], 0.7285 * Rbar, 1e-3 * Rbar);
check("R chart: UCL = 2.282 R_bar", rb["ucl"], 2.282 * Rbar, 1e-3 * Rbar);
check("R chart: LCL = 0", rb["lcl"], 0, 0);
sb = control_chart_limits(D, "s");
check("s chart: UCL = 2.266 s_bar", sb["ucl"], 2.266 * sb["cl"], 1e-3 * sb["cl"]);
publish("x_bar chart:", xb);

# ==========================================================================================
# operating_characteristic_curve(N, n, c, p) - P(accept the lot) when a sample of n
#   from a lot of N with defect fraction p may hold at most c defectives
#   (Kreyszig 25.6): hypergeometric; N = 0 (or inf) for a very large lot: binomial
# Kreyszig 25.6, Example: N = 20, n = 5, c = 0, p = 0.1 -> C(18, 5)/C(20, 5) = 0.553
# ==========================================================================================
publish("---- operating_characteristic_curve ----");
check("Kreyszig 25.6 example", operating_characteristic_curve(20, 5, 0, [0, 0.1]), [1, 8568 / 15504], 1e-12);
check("large lot: binomial (1 - p)^5", operating_characteristic_curve(0, 5, 0, [0.1, 0.2]), [0.9 ^ 5, 0.8 ^ 5], 1e-12);

# ==========================================================================================
# sign_test(data, median0[, alternative]) or sign_test(x, y[, alternative]) - the sign
#   test for the median (Kreyszig 25.8): the number of values above median0 (or of
#   positive differences x - y) is Binomial(n, 1/2) under the hypothesis; values equal
#   to the median are dropped. alternative: "two-sided" (default), "greater", "less".
#   Returns {positives, negatives, n, p_value, alternative}.
# ==========================================================================================
publish("---- sign_test ----");
s = sign_test([5.6, 6.1, 5.9, 6.4, 5.7, 6.0, 6.3, 5.8, 6.2, 4.9], 5.5);   # 9 above, 1 below
check("9 of 10 above: two-sided p = 2 * 11/1024", s["p_value"], 22 / 1024, 1e-15);
g = sign_test([5.6, 6.1, 5.9, 6.4, 5.7, 6.0, 6.3, 5.8, 6.2, 4.9], 5.5, "greater");
check("one-sided (greater): p = 11/1024", g["p_value"], 11 / 1024, 1e-15);
pd = sign_test([3, 5, 4, 6, 5], [2, 5, 3, 4, 6]);                       # paired: +, 0, +, +, -
check("paired samples: 3 positive, 1 negative, 1 tie dropped", [pd["positives"], pd["negatives"], pd["n"]], [3, 1, 4], 0);
publish("done: 07_probability_statistics");
