# ==========================================================================================
# 06  Complex analysis  (Kreyszig, chapters 13 to 18)
#
#   ch. 13  is_analytic  complex_deriv  branch_cut_unwrap
#   ch. 14  generate_contour  contour_integrate  cauchy_eval  cauchy_deriv
#           ml_bound_estimate
#   ch. 15  taylor_coeffs_cplx   (radius: rad_of_con; Pade: the existing pade)
#   ch. 16  laurent_coeffs  find_poles  complex_residue  real_improper_integral
#           real_trig_integral
#   ch. 17  conformal_map  mobius_transform  mobius_from_points  cross_ratio
#   ch. 18  harmonic_conjugate  poisson_integral_disk  complex_potential
#           complex_velocity  joukowski_map
#
# Complex numbers are written 1 + 2i. A complex grid is a matrix Z = X + 1i * Y from
# meshgrid (rows along y, columns along x). A contour (path) is a row of complex points
# joined by straight segments - generate_contour makes the usual ones (closed: the last
# point is the first).
#
# The NC functions given to these must accept complex inputs (ordinary arithmetic,
# exp, sin, cos, sqrt and log all do).
#
# Every check publishs PASS or FAIL.
# Run:  nc.exe 06_complex_analysis.nc
# ==========================================================================================

function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend

# ---- functions used below ----------------------------------------------------------------
function w = sq(z):
   w = z ^ 2;
fnend
function w = cube(z):
   w = z ^ 3;
fnend
function w = recip(z):
   w = 1 / z;
fnend
function w = zbar(z):
   w = conj(z);
fnend
function w = ez(z):
   w = exp(z);
fnend
function w = cz(z):
   w = cos(z);
fnend
function w = geometric(z):
   w = 1 / (1 - z);
fnend
function w = laurent_ex(z):
   w = 1 / (z ^ 3 - z ^ 4);
fnend
function w = two_poles(z):
   w = 1 / ((z - 1) * (z + 2i) ^ 2);
fnend
function w = res_ex(z):
   w = (9 * z + 1i) / (z * (z ^ 2 + 1));
fnend
function y = quartic(x):
   y = 1 / (1 + x ^ 4);
fnend
function y = trig_ex(theta):
   y = 1 / (sqrt(2) - cos(theta));
fnend
function u = boundary_cos(phi):
   u = cos(phi);
fnend
function u = boundary_step(phi):
   if phi > 0:
      u = 1;
   else:
      u = -1;
   iend
fnend
function V = corner_velocity(z):
   V = conj(2 * z);
fnend
function F = cylinder_flow(z):
   F = z + 1 / z;
fnend

# ==========================================================================================
# ch. 13
# is_analytic(F, dx, dy[, tol]) - Cauchy-Riemann check on a sampled grid F[i, j] =
#   f(x_j + i y_i): dict {analytic, max_residual, relative_residual, derivative (u_x + i v_x)}
# complex_deriv(@f, z[, h]) - f'(z) at each z (fourth-order central difference)
# branch_cut_unwrap(Z) - arg z followed continuously across the negative real axis:
#   dict {phase, log (ln|z| + i phase), sqrt (continuous square root)}
# ==========================================================================================
publish("---- ch. 13 ----");
g = space(-1, 1, 21);
[X, Y] = meshgrid(g, g);
Z = X + 1i * Y;
A = is_analytic(Z ^. 2, 0.1, 0.1);
check("z^2 satisfies Cauchy-Riemann", A["analytic"], 1, 0);
check("... and its derivative is 2z", A["derivative"], 2 * Z, 1e-12);
B = is_analytic(conj(Z), 0.1, 0.1);
check("conj(z) does not", B["analytic"], 0, 0);
check("complex_deriv of z^3 at 1 + i = 6i", complex_deriv(@cube, 1 + 1i), 6i, 1e-9);
th = space(0, 3 * pi, 31);              # one and a half turns
U = branch_cut_unwrap(exp(1i * th));
check("phase grows continuously to 3 pi", U["phase"], th, 1e-12);
check("continuous log = i theta", U["log"], 1i * th, 1e-12);

# ==========================================================================================
# ch. 14
# generate_contour(type, params):
#   "circle"     [center, radius(, n)]          counter-clockwise, closed
#   "arc"        [center, radius, t1, t2(, n)]
#   "line"       [z1, z2(, n)]
#   "polygon"    [z1, z2, ...]                  closed
#   "rectangle"  [x0, y0, x1, y1]               closed, counter-clockwise
#   "semicircle" [R(, n)]                       -R..R, then back over the upper arc
# contour_integrate(@f, path)           - integral of f(z) dz (adaptive Gauss-Kronrod per segment)
# cauchy_eval(@f, z0, path)             - 1/(2 pi i) closed integral of f / (z - z0)
# cauchy_deriv(@f, z0, n, path)         - n!/(2 pi i) closed integral of f / (z - z0)^(n+1)
# ml_bound_estimate(@f, path)           - dict {M, L, bound = M L, max_at}
# ==========================================================================================
publish("---- ch. 14 ----");
circ = generate_contour("circle", [0, 1]);
check("closed integral of 1/z around 0 = 2 pi i", contour_integrate(@recip, circ), 2i * pi, 1e-10);
check("closed integral of z^2 = 0 (Cauchy)", contour_integrate(@sq, circ), 0, 1e-12);
# conj(z) is not analytic, so the integral depends on the path: the 256-gon of "circle"
# differs from the circle by O(1/n^2); 1024 points give the circle's value to 4e-5.
fine = generate_contour("circle", [0, 1, 1024]);
check("Kreyszig 14.2: closed integral of conj(z) = 2 pi i", contour_integrate(@zbar, fine), 2i * pi, 1e-4);
seg = generate_contour("line", [0, 1 + 1i]);
check("z^2 from 0 to 1 + i = (1 + i)^3 / 3", contour_integrate(@sq, seg), (1 + 1i) ^ 3 / 3, 1e-14);
big = generate_contour("circle", [0, 3]);
check("Cauchy's formula: e^z at 2 (Kreyszig 14.3)", cauchy_eval(@ez, 2, big), exp(2), 1e-10);
check("Cauchy's formula, n = 2: (cos)'' at 0 = -1", cauchy_deriv(@cz, 0, 2, big), -1, 1e-10);
sq_box = generate_contour("rectangle", [-1, -1, 1, 1]);
check("... also on a square contour", cauchy_eval(@ez, 0.5, sq_box), exp(0.5), 1e-10);
ml = ml_bound_estimate(@sq, seg);
check("ML bound for z^2 on [0, 1 + i]: M = 2, L = sqrt 2", [ml["M"], ml["L"], ml["bound"]], [2, sqrt(2), 2 * sqrt(2)], 1e-12);

# ==========================================================================================
# ch. 15
# taylor_coeffs_cplx(@f, z0, N[, r]) - a_0 .. a_(N-1) of the Taylor series at z0 from
#   Cauchy integrals on the circle |z - z0| = r (0.5 by default; keep r inside the
#   radius of convergence)
# ==========================================================================================
publish("---- ch. 15 ----");
check("1/(1 - z) = 1 + z + z^2 + ...", taylor_coeffs_cplx(@geometric, 0, 8), ones(1, 8), 1e-12);
check("e^z: a_n = 1/n!", taylor_coeffs_cplx(@ez, 0, 5), [1, 1, 1/2, 1/6, 1/24], 1e-13);
check("radius of 1/(1 - z) = 1", rad_of_con(taylor_coeffs_cplx(@geometric, 0, 16)), 1, 1e-6);

# ==========================================================================================
# ch. 16
# laurent_coeffs(@f, z0, r, N)  - c_(-N) .. c_N on the circle |z - z0| = r (inside the
#                                 annulus where the series holds): dict {n, c}
# find_poles(@f, domain[, n])   - poles in [x_min, x_max, y_min, y_max] (or among the
#                                 points of a complex grid): dict {poles, orders}
# complex_residue(@f, z0[, r])  - Res f at z0 (c_(-1)) by a small circle integral
#                                 (residue(b, a) is the signal-processing function: the
#                                 partial fractions of a rational b(s)/a(s))
# real_improper_integral(@f[, R, n]) - integral over the real line by residues in the
#                                 upper half-plane: dict {value, poles, residues, numeric}
# real_trig_integral(@F)        - integral of F(theta) from 0 to 2 pi on the unit circle
# ==========================================================================================
publish("---- ch. 16 ----");
L = laurent_coeffs(@laurent_ex, 0, 0.5, 4);       # Kreyszig 16.1: 1/(z^3 - z^4)
check("1/(z^3 - z^4) = z^-3 + z^-2 + z^-1 + 1 + z + ...", L["c"], [0, 1, 1, 1, 1, 1, 1, 1, 1], 1e-10);
P = find_poles(@two_poles, [-3, 3, -3, 3]);
check("poles at -2i (order 2) and 1 (order 1)", P["poles"], [-2i, 1], 1e-8);
check("... orders", P["orders"], [2, 1], 0);
check("Kreyszig 16.3: Res at i = -5i", complex_residue(@res_ex, 1i), -5i, 1e-10);
check("Kreyszig 16.3: Res at 0 = i", complex_residue(@res_ex, 0), 1i, 1e-10);
# the same two residues from the partial fractions of (9s + i) / (s^3 + s), signal residue(b, a):
rs = residue([9, 1i], [1, 0, 1, 0]);              # poles p = [0, i, -i], residues r
own = [complex_residue(@res_ex, 0), complex_residue(@res_ex, 1i), complex_residue(@res_ex, -1i)];
check("complex_residue agrees with residue(b, a) at all three poles", own, rs["r"], 1e-9);
I = real_improper_integral(@quartic);
check("Kreyszig 16.4: integral of 1/(1 + x^4) = pi/sqrt(2)", I["value"], pi / sqrt(2), 1e-10);
check("... agrees with direct quadrature", I["numeric"], pi / sqrt(2), 1e-8);
check("Kreyszig 16.4: integral of 1/(sqrt 2 - cos t) = 2 pi", real_trig_integral(@trig_ex), 2 * pi, 1e-12);

# ==========================================================================================
# ch. 17
# conformal_map(@f, Z)                 - w = f(z) for every point of a grid (for plots)
# mobius_transform(z, a, b, c, d)      - w = (a z + b) / (c z + d); the pole goes to inf
# mobius_from_points(z, w)             - [a, b; c, d] (ad - bc = 1) mapping 3 points to 3
# cross_ratio(z1, z2, z3, z4)          - (z1 - z3)(z2 - z4) / ((z1 - z4)(z2 - z3))
# ==========================================================================================
publish("---- ch. 17 ----");
check("conformal_map(z^2)", conformal_map(@sq, Z), Z ^. 2, 1e-12);
check("(z - i)/(z + i): i -> 0, 0 -> -1, 1 -> -i", mobius_transform([1i, 0, 1], 1, -1i, 1, 1i), [0, -1, -1i], 1e-14);
zp = [-1, 0, 1];
wp = [-1i, -1, 1i];                               # Kreyszig 17.3, Example 1
M = mobius_from_points(zp, wp);
check("the map takes the three points to their images", mobius_transform(zp, M[0, 0], M[0, 1], M[1, 0], M[1, 1]), wp, 1e-12);
check("ad - bc = 1", M[0, 0] * M[1, 1] - M[0, 1] * M[1, 0], 1, 1e-12);
z4 = [2, 1i, -2, 0.5 + 0.5i];                    # (z = -3 is the pole of this map)
w4 = mobius_transform(z4, 2, 1, 1, 3);
check("cross ratio is kept by a Moebius map", cross_ratio(w4[0], w4[1], w4[2], w4[3]), cross_ratio(z4[0], z4[1], z4[2], z4[3]), 1e-12);

# ==========================================================================================
# ch. 18
# harmonic_conjugate(u, dx, dy)          - v with u + i v analytic, v = 0 at the first point
# poisson_integral_disk(@f, r, theta[, R]) - Poisson's integral formula: the harmonic u in
#                                          the disk with boundary values f; U[i, j] = u(r_i, theta_j)
# complex_potential(V, Z)                - F with F' = conj(V): dict {F, potential, stream}
#                                          (V a function of z or its values on Z)
# complex_velocity(@F, z)                - V = conj(F'(z)): dict {V, speed, angle}
# joukowski_map(z, c)                    - w = z + c^2 / z
# ==========================================================================================
publish("---- ch. 18 ----");
q = space(0, 1, 11);
[QX, QY] = meshgrid(q, q);
check("conjugate of x^2 - y^2 is 2xy", harmonic_conjugate(QX ^. 2 - QY ^. 2, 0.1, 0.1), 2 * QX *. QY, 1e-12);
rp = [0, 0.3, 0.6];
tp = space(-3, 3, 7);
[TP, RP] = meshgrid(tp, rp);
check("Poisson: boundary cos(phi) -> r cos(theta)", poisson_integral_disk(@boundary_cos, rp, tp), RP *. cos(TP), 1e-10);
check("Poisson = Fourier series for a jump on the boundary", poisson_integral_disk(@boundary_step, rp, tp), solve_laplace_2d_polar(@boundary_step, 1, rp, tp, 80), 1e-8);
Zq = QX + 1i * QY;
cp = complex_potential(@corner_velocity, Zq);     # Kreyszig 18.4: flow around a corner, F = z^2
check("potential x^2 - y^2", cp["potential"], QX ^. 2 - QY ^. 2, 1e-12);
check("stream function 2xy", cp["stream"], 2 * QX *. QY, 1e-12);
cv = complex_velocity(@cylinder_flow, 2);         # F = z + 1/z, V = conj(1 - 1/z^2)
check("flow round a cylinder at z = 2: V = 3/4", cv["V"], 0.75, 1e-9);
ring = exp(1i * space(0, 2 * pi, 9));
check("Joukowski maps |z| = 1 onto [-2, 2]", joukowski_map(ring, 1), 2 * cos(space(0, 2 * pi, 9)), 1e-12);
publish("done: 06_complex_analysis");
