# ==========================================================================================
# 05  Partial differential equations  (Kreyszig, chapter 12)
#
#   1-D   solve_wave_1d_fourier  solve_wave_1d_dalembert  solve_heat_1d_fourier
#         solve_heat_1d_fourier_integral  pde_solve_laplace_transform
#   2-D   solve_wave_2d_rectangular  solve_wave_2d_circular_bessel
#   Laplace's equation   solve_laplace_2d_polar  solve_laplace_3d_spherical
#
# Initial and boundary data are NC functions (@f), or plain numbers for constants
# (g = 0: the string starts at rest).
#
# Results on a space-time grid: U[i, j] = u(x_j, t_i) - one ROW per time, one COLUMN per
# position (r or theta for the disk / sphere). The rectangular membrane gives an N-D
# matrix [nt, ny, nx] (a plain matrix for a single time).
#
# Each check compares with the exact solution of the same problem.
# Run:  nc.exe 05_partial_differential_equations.nc
# ==========================================================================================

function check(label, got, want, tol):
   e = max(abs(got - want));
   if e <= tol:
      publish("PASS  " + label);
   else:
      publish("FAIL  " + label + "   largest difference " + str(e));
   iend
fnend

# ---- data used below ----------------------------------------------------------------------
function u = mode1(x):
   u = sin(pi * x);
fnend
function v = mode2(x):
   v = sin(2 * pi * x);
fnend
function u = bump(x):
   u = exp(-1 * x ^ 2);
fnend
function v = ident(x):
   v = x;
fnend
function u = plate(x, y):
   u = sin(pi * x) * sin(pi * y);
fnend
function u = drum(r):
   u = jv(0, 2.404825557695773 * r);
fnend
function u = ring(theta):
   u = cos(theta) + sin(2 * theta);
fnend
function u = cap(phi):
   u = cos(phi) ^ 2;
fnend

# ==========================================================================================
# solve_wave_1d_fourier(f, g, L, c, x, t, N) - vibrating string u_tt = c^2 u_xx, ends fixed
#   (u(0) = u(L) = 0), deflection f and velocity g at t = 0: the first N terms of
#   u = sum (B_n cos(l_n t) + B*_n sin(l_n t)) sin(n pi x / L), l_n = c n pi / L  (12.3)
# Exact here: f = sin(pi x), g = sin(2 pi x), L = 1:
#   u = sin(pi x) cos(c pi t) + sin(2 pi x) sin(2 c pi t) / (2 c pi)
# ==========================================================================================
publish("---- solve_wave_1d_fourier ----");
x = space(0, 1, 11);
t = [0, 0.1, 0.25];
c = 2;
[XX, TT] = meshgrid(x, t);
U = solve_wave_1d_fourier(@mode1, @mode2, 1, c, x, t, 4);
exact = sin(pi * XX) *. cos(c * pi * TT) + sin(2 * pi * XX) *. sin(2 * c * pi * TT) / (2 * c * pi);
check("string from sine data", U, exact, 1e-12);

# ==========================================================================================
# solve_wave_1d_dalembert(f, g, c, x, t) - D'Alembert's solution on the whole line (12.4):
#   u = [f(x + ct) + f(x - ct)] / 2 + (1/2c) integral from x - ct to x + ct of g
# Here f = e^(-x^2), g = x: the integral term is x t.
# ==========================================================================================
publish("---- solve_wave_1d_dalembert ----");
xd = space(-2, 2, 9);
[XD, TD] = meshgrid(xd, t);
D = solve_wave_1d_dalembert(@bump, @ident, 1, xd, t);
check("D'Alembert", D, (exp(-1 * (XD + TD) ^. 2) + exp(-1 * (XD - TD) ^. 2)) / 2 + XD *. TD, 1e-10);
check("at rest (g = 0)", solve_wave_1d_dalembert(@bump, 0, 1, [0], [0, 1]), [1; exp(-1)], 1e-12);

# ==========================================================================================
# solve_heat_1d_fourier(f, L, c, x, t, N) - heat flow u_t = c^2 u_xx in a bar with ends
#   kept at 0, initial temperature f: sum B_n sin(n pi x / L) e^(-l_n^2 t)  (12.6)
# solve_heat_1d_fourier_integral(f, c, x, t) - the infinite bar (12.7):
#   u = 1/(2c sqrt(pi t)) integral of f(v) exp(-(x - v)^2 / (4 c^2 t)) dv
# Exact: sin(pi x) e^(-pi^2 t);  e^(-x^2) -> e^(-x^2/(1 + 4 c^2 t)) / sqrt(1 + 4 c^2 t)
# ==========================================================================================
publish("---- heat equation ----");
th = [0, 0.05, 0.2];
[XH, TH] = meshgrid(x, th);
H = solve_heat_1d_fourier(@mode1, 1, 1, x, th, 3);
check("finite bar", H, sin(pi * XH) *. exp(-1 * pi ^ 2 * TH), 1e-12);
xi = space(-3, 3, 7);
[XI, TI] = meshgrid(xi, th);
I = solve_heat_1d_fourier_integral(@bump, 0.5, xi, th);
s = 1 + 4 * 0.25 * TI;
check("infinite bar", I, exp(-1 * XI ^. 2 /. s) /. sqrt(s), 1e-9);

# ==========================================================================================
# pde_solve_laplace_transform(f, g0, gL, c, x, t[, M]) - the heat equation on the bar
#   [x_first, x_last] with u(x, 0) = f, u(x0, t) = g0(t), u(xL, t) = gL(t), solved in the
#   Laplace domain (c^2 U'' - s U = -f, exactly) and inverted numerically (Gaver-Stehfest,
#   M = 14 terms: about 4 to 5 correct digits)  (12.12)
# ==========================================================================================
publish("---- pde_solve_laplace_transform ----");
tl = [0.05, 0.1, 0.2];
[XL, TL] = meshgrid(x, tl);
Lp = pde_solve_laplace_transform(@mode1, 0, 0, 1, x, tl);
check("same bar as above", Lp, sin(pi * XL) *. exp(-1 * pi ^ 2 * TL), 1e-4);
# ends held at 1, bar at 0: compare with the Fourier series of the same problem
Lb = pde_solve_laplace_transform(0, 1, 1, 1, x, tl);
Fs = zeros(3, 11);
for k = [0:200]:
   m = 2 * k + 1;
   Fs = Fs + 4 / (m * pi) * sin(m * pi * XL) *. exp(-1 * (m * pi) ^ 2 * TL);
fend
check("ends at temperature 1", Lb, 1 - Fs, 2e-3);

# ==========================================================================================
# solve_wave_2d_rectangular(f, g, a, b, c, x, y, t, N, M) - rectangular membrane
#   u_tt = c^2 (u_xx + u_yy) on [0, a] x [0, b], edges fixed: double Fourier series with
#   modes m = 1..N (x) and n = 1..M (y)  (12.9). Result [nt, ny, nx].
# Exact: f = sin(pi x) sin(pi y), g = 0 on the unit square: u = f cos(c pi sqrt(2) t)
# ==========================================================================================
publish("---- solve_wave_2d_rectangular ----");
xm = space(0, 1, 6);
[XM, YM] = meshgrid(xm, xm);
W = solve_wave_2d_rectangular(@plate, 0, 1, 1, 1, xm, xm, [0, 0.3], 3, 3);
check("membrane at t = 0.3", W[1], sin(pi * XM) *. sin(pi * YM) * cos(pi * sqrt(2) * 0.3), 1e-10);

# ==========================================================================================
# solve_wave_2d_circular_bessel(f, g, R, c, r, t, N) - drum head of radius R, vibrations
#   that do not depend on the angle: sum (A_m cos(l_m t) + B_m sin(l_m t)) J0(al_m r/R),
#   al_m the zeros of J0  (12.10)
# Exact: f = J0(al_1 r), g = 0, R = 1: u = J0(al_1 r) cos(c al_1 t)
# ==========================================================================================
publish("---- solve_wave_2d_circular_bessel ----");
rr = space(0, 1, 6);
tc = [0, 0.5];
[RR, TC] = meshgrid(rr, tc);
Dr = solve_wave_2d_circular_bessel(@drum, 0, 1, 1, rr, tc, 5);
check("first drum mode", Dr, jv(0, 2.404825557695773 * RR) *. cos(2.404825557695773 * TC), 1e-9);

# ==========================================================================================
# solve_laplace_2d_polar(f, R, r, theta, N) - Laplace's equation in a disk with boundary
#   values f(theta): u = a0 + sum (r/R)^n (a_n cos n theta + b_n sin n theta); outside the
#   disk (r > R) the bounded solution with (R/r)^n. U[i, j] = u(r_i, theta_j).
# solve_laplace_3d_spherical(f, R, r, phi, N) - inside a sphere, boundary values f(phi)
#   not depending on the longitude: u = sum A_n (r/R)^n P_n(cos phi), n = 0..N;
#   outside: (R/r)^(n+1)  (12.11)
# ==========================================================================================
publish("---- Laplace's equation ----");
ra = [0, 0.5, 1, 2];
ta = space(0, 2 * pi, 9);
[TA, RA] = meshgrid(ta, ra);
Lu = solve_laplace_2d_polar(@ring, 1, ra, ta, 4);
inside = RA *. cos(TA) + RA ^. 2 *. sin(2 * TA);
outside = cos(TA) /. RA + sin(2 * TA) /. RA ^. 2;
check("disk, r <= R", Lu[0:2, :], inside[0:2, :], 1e-12);
check("outside, r = 2", Lu[3, :], outside[3, :], 1e-12);
ph = space(0, pi, 7);
[PH, RS] = meshgrid(ph, [0.5, 1]);
Sp = solve_laplace_3d_spherical(@cap, 1, [0.5, 1], ph, 4);
P2 = (3 * cos(PH) ^. 2 - 1) / 2;
check("sphere: cos^2 phi = 1/3 + (2/3) P2", Sp, 1 / 3 + 2 / 3 * RS ^. 2 *. P2, 1e-12);
publish("done: 05_partial_differential_equations");
