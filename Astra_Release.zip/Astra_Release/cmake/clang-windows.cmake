# =============================================================================
#  clang-windows.cmake  -  toolchain file for building nc.exe with the
#  in-house LLVM 23.1.0 toolchain (clang++ / lld-link / llvm-ar / ninja).
#
#  Usage (from the repository root, inside a VS 2022 Developer PowerShell):
#     cmake -S src/main/cpp -B build/nc-build -G Ninja --toolchain "$PWD\cmake\clang-windows.cmake" -DCMAKE_BUILD_TYPE=Release
#
#  NC_TOOLCHAIN_ROOT may be passed with -DNC_TOOLCHAIN_ROOT=... or come from
#  the environment variable of the same name. It must point at the folder
#  that contains bin\ and lib\ (normally <REPO>\build\toolchain).
#
#  This file only selects the compiler, linker and tools. Libraries (Eigen,
#  OpenMP, ...) and build profiles live in src/main/cpp/CMakeLists.txt.
# =============================================================================

# --- Locate the toolchain root ----------------------------------------------
if(NOT NC_TOOLCHAIN_ROOT)
    if(DEFINED ENV{NC_TOOLCHAIN_ROOT})
        set(NC_TOOLCHAIN_ROOT "$ENV{NC_TOOLCHAIN_ROOT}")
    else()
        message(FATAL_ERROR
            "NC_TOOLCHAIN_ROOT is not set. Pass -DNC_TOOLCHAIN_ROOT=<toolchain folder> "
            "or set the NC_TOOLCHAIN_ROOT environment variable.")
    endif()
endif()

file(TO_CMAKE_PATH "${NC_TOOLCHAIN_ROOT}" NC_TOOLCHAIN_ROOT)
set(NC_TOOLCHAIN_ROOT "${NC_TOOLCHAIN_ROOT}" CACHE PATH "Root of the custom LLVM toolchain" FORCE)

# Expected LLVM major version. The resource directory lib/clang/<major> must
# match it. Change this one line when the toolchain is upgraded.
set(NC_LLVM_MAJOR 23 CACHE STRING "Expected LLVM major version of the toolchain")

# Toolchain files are re-read inside try_compile() projects; forward these.
list(APPEND CMAKE_TRY_COMPILE_PLATFORM_VARIABLES NC_TOOLCHAIN_ROOT NC_LLVM_MAJOR)

set(_nc_bin "${NC_TOOLCHAIN_ROOT}/bin")

foreach(_tool clang.exe clang++.exe lld-link.exe llvm-ar.exe ninja.exe)
    if(NOT EXISTS "${_nc_bin}/${_tool}")
        message(FATAL_ERROR "Toolchain tool not found: ${_nc_bin}/${_tool}")
    endif()
endforeach()

# Guards against an old (LLVM 21) or incomplete toolchain folder.
if(NOT EXISTS "${NC_TOOLCHAIN_ROOT}/lib/clang/${NC_LLVM_MAJOR}/include/stddef.h")
    message(FATAL_ERROR
        "Resource directory not found: ${NC_TOOLCHAIN_ROOT}/lib/clang/${NC_LLVM_MAJOR}/include\n"
        "The toolchain is not LLVM ${NC_LLVM_MAJOR}, or lib\\clang\\${NC_LLVM_MAJOR} was not copied.")
endif()

# --- Compilers ----------------------------------------------------------------
# Native Windows build: CMAKE_SYSTEM_NAME is deliberately NOT set, so CMake
# does not switch into cross-compiling mode.
set(CMAKE_C_COMPILER   "${_nc_bin}/clang.exe")
set(CMAKE_CXX_COMPILER "${_nc_bin}/clang++.exe")
set(CMAKE_C_COMPILER_TARGET   x86_64-pc-windows-msvc)
set(CMAKE_CXX_COMPILER_TARGET x86_64-pc-windows-msvc)

# --- Binutils / build tool -------------------------------------------------------
set(CMAKE_AR           "${_nc_bin}/llvm-ar.exe"  CACHE FILEPATH "Archiver"   FORCE)
set(CMAKE_LINKER       "${_nc_bin}/lld-link.exe" CACHE FILEPATH "Linker"     FORCE)
set(CMAKE_MAKE_PROGRAM "${_nc_bin}/ninja.exe"    CACHE FILEPATH "Build tool" FORCE)

# clang++ drives the link step; -fuse-ld=lld makes it call lld-link.exe
# (found next to clang++.exe) instead of Microsoft's link.exe.
#
# -no-canonical-prefixes: by default clang resolves its own location to the
# physical path behind the D: alias (C:\D-Drive\D\...) and launches lld-link
# from there, which Windows refuses ("lld-link: permission denied"). With this
# flag clang keeps the path it was started from (D:\...), so lld-link is
# launched from the same place it runs fine. It must be on the link line too,
# and CMake puts the compile flags on the link line for this compiler.
set(CMAKE_C_FLAGS_INIT   "-no-canonical-prefixes")
set(CMAKE_CXX_FLAGS_INIT "-no-canonical-prefixes")
set(CMAKE_EXE_LINKER_FLAGS_INIT    "-no-canonical-prefixes -fuse-ld=lld")
set(CMAKE_SHARED_LINKER_FLAGS_INIT "-no-canonical-prefixes -fuse-ld=lld")
set(CMAKE_MODULE_LINKER_FLAGS_INIT "-no-canonical-prefixes -fuse-ld=lld")

# NOTE: never put paths (they contain spaces) into the *_FLAGS_INIT strings
# above. Paths belong in CMakeLists.txt, where CMake quotes them correctly.

# Handy for IDEs/clangd and for checking which compiler was actually used.
set(CMAKE_EXPORT_COMPILE_COMMANDS ON CACHE BOOL "Write compile_commands.json" FORCE)
