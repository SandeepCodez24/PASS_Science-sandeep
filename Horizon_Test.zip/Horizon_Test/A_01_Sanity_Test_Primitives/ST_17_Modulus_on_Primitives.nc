#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2.023;C=3;D=4;E=5.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = |B|+|B|;
A2 = |B|-|B|;
A3 = |B|*|B|;
A4 = |B|/|B|;
A5 = sqrt(|B|);
A6 = cbrt(|B|);
A7 = sqr(|B|);
A8 = cube(|B|);
A9 = D^|B|;
A10 = |B|!;
A11 = |B|//|B|; 
A12 = |B|%|B|; ## cpp error
A13 = log(|B|); 
A14 = e^|B|; 
A15 = logb4(|B|); 
A16 = |-|-B||;
#########################################################
#########################################################
publish("Addition                     :", |B|+|B|==A1);
publish("Subtraction                  :", |B|-|B|==A2);
publish("Multiplication               :", |B|*|B|==A3);
publish("Division                     :", (|B|/|B|)==A4);
publish("Square Root                  :", sqrt(|B|)==A5);
publish("Cube Root                    :", cbrt(|B|)==A6);
publish("Square                       :", sqr(|B|)==A7);
publish("Cube                         :", cube(|B|)==A8);
publish("Power                        :", D^|B|==A9);    
publish("Factorial                    :",(|B|!)==A10); ## cpp error
publish("Quotient                     :", |B|//|B|==A11);
publish("Remainder                    :", |B|%|B|==A12);
publish("Natural Logarithm            :", log(|B|)==A13);
publish("Exponential                  :", e^|B|==A14);      
publish("Logarithm Base 4             :", logb4(|B|)==A15);
publish("Fraction to Decimal          :", |-|-B||==A16);
#######################################################
#######################################################