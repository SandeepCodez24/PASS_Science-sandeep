#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = cbrt(B)+cbrt(D);
A2 = cbrt(S)-cbrt(D);
A3 = cbrt(S)*cbrt(D);
A4 = cbrt(S)/cbrt(D);
A5 = sqrt(cbrt(S));
A6 = cbrt(cbrt(S));
A7 = sqr(cbrt(A));
A8 = cube(cbrt(A));
A9 = A^cbrt(B);
A10 = cbrt(Q)!;
A11 = cbrt(R)//cbrt(P);
A12 = cbrt(R)%cbrt(P); 
A13 = log(cbrt(D)); 
A14 = e^cbrt(A); 
A15 = logb4(cbrt(A)); 
A16 = |cbrt(R)|;
#########################################################
#########################################################
publish("Addition              :", cbrt(B)+cbrt(D)==A1);
publish("Subtraction           :", cbrt(S)-cbrt(D)==A2);
publish("Multiplication        :", cbrt(S)*cbrt(D)==A3);
publish("Division              :", cbrt(S)/cbrt(D)==A4);
publish("Square Root           :", sqrt(cbrt(S))==A5);
publish("Cube Root             :", cbrt(cbrt(S))==A6);
publish("Square                :", sqr(cbrt(A))==A7);
publish("Cube                  :", cube(cbrt(A))==A8);
publish("Power                 :",  A^cbrt(B)==A9);   
publish("Factorial             :", cbrt(Q)!==A10);
publish("Quotient              :", cbrt(R)//cbrt(P)==A11);
publish("Remainder             :", cbrt(R)%cbrt(P)==A12);
publish("Natural Logarithm     :", log(cbrt(D))==A13);
publish("Exponential           :", e^cbrt(A)==A14);     
publish("Logarithm Base        :", logb4(cbrt(A))==A15);
publish("Modulus               :", |cbrt(R)|==A16);
#######################################################
#######################################################