###############################################################
###### While-Not Header Operator Test : 6 + 8 + 6 = 20 ########
###############################################################
# Each operator sits in the 'while not' header. The condition is
# FALSE on entry (header TRUE via 'not'); the body changes a
# variable so the condition becomes TRUE -> the loop exits after
# exactly one pass, with one publish.
# A missing 'passed' line in the output = that operator failed.
###############################################################

passcount = 0;

###############################################################
#### Binary operators  [==, !=, <, <=, >, >=]
###############################################################
A=2;B=2;C=3;D=0;

# A == 1 is FALSE (A = 2) -> body sets A = 1
while not (A == 1):
   A = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '==' ");
wend

# A != B is FALSE (2 == 2) -> body sets A = 1
A = 2;
while not (A != B):
   A = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!=' ");
wend

# A < C is FALSE (5 < 3) -> body sets A = 1
A = 5;
while not (A < C):
   A = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '<' ");
wend

# C <= (A+B) is FALSE (10 <= 3) -> body sets C = 3 (equality boundary)
A = 1; B = 2; C = 10;
while not (C <= (A+B)):
   C = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '<=' ");
wend

# D > C is FALSE (0 > 3) -> body sets D = 4
D = 0;
while not (D > C):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '>' ");
wend

# C >= (A+B) is FALSE (0 >= 3) -> body sets C = 3 (equality boundary)
C = 0;
while not (C >= (A+B)):
   C = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '>=' ");
wend

###############################################################
#### Logical operators  [&&, ||, !&, !|, is_in, is_not_in, is_empty, is_nan]
###############################################################
A=1;B=2;C=3;D=4;E=5;

# FALSE && TRUE = FALSE -> body makes the left side TRUE
A = 2;
while not ((A==1) && (C==A+B)):
   A = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '&&' ");
wend

# FALSE || FALSE = FALSE -> body makes the right side TRUE
C = 0;
while not ((A==D) || (C==A+B)):
   C = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '||' ");
wend

# NAND: TRUE !& TRUE = FALSE -> body makes both sides FALSE
D = 1; E = 3;
while not ((A==D) !& (E==A+B)):
   D = 4;
   E = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!&' ");
wend

# NOR: TRUE !| FALSE = FALSE -> body makes both sides FALSE
D = 1;
while not ((A==D) !| (D==A+B)):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!|' ");
wend

D = 50;
while not (D is_in [1:10]):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'is_in' ");
wend

D = 15;
while not (D is_not_in [11:20]):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'is_not_in' ");
wend

L = [1:3];
while not (is_empty(L)):
   L = [];
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'is_empty' ");
wend

N = 5;
while not (is_nan(N)):
   N = 0/0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'is_nan' ");
wend

###############################################################
#### Data conversion operators  [int, float, str, round, dec2rad, rad2dec]
###############################################################

# int(9.2) = 9 -> body sets 4.2 so int(D) = 4 (truncate or round)
D = 9.2;
while not (int(D) == 4):
   D = 4.2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'int' ");
wend

D = 9;
while not (float(D) == 4.0):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'float' ");
wend

# compared against a stored string, so "4" vs "4.0" formatting does not matter
S1 = str(4);
D = 9;
while not (str(D) == S1):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'str' ");
wend

D = 2.71828;
while not (round(D,2) == 3.14):
   D = 3.14159;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'round' ");
wend

# 90 degrees = 1.5708 rad -> body sets 180 degrees = 3.14159 rad
D = 90;
while not (dec2rad(D) > 3):
   D = 180;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'dec2rad' ");
wend

# 1 rad = 57.30 degrees -> body sets 4 rad = 229.18 degrees
D = 1;
while not (rad2dec(D) > 180):
   D = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'rad2dec' ");
wend

###############################################################
publish("While-Not Header Operator Test : total passed out of 20 :", passcount);
###############################################################
