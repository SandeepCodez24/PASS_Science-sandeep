###############################################################
######## While-Header Operator Test : 6 + 8 + 6 = 20 ##########
###############################################################
# Each operator sits in the 'while' header. The header is TRUE on
# entry; the body changes a variable so the header is FALSE on the
# second check -> exactly one pass per loop, with one publish.
# A missing 'passed' line in the output = that operator failed.
###############################################################

passcount = 0;

###############################################################
#### Binary operators  [==, !=, <, <=, >, >=]
###############################################################
A=1;B=2;C=3;D=4;

while A == 1:
   A = 2;
   passcount = passcount + 1;
   publish("test is passed on '==' ");
wend

A = 1;
while A != B:
   A = 2;
   passcount = passcount + 1;
   publish("test is passed on '!=' ");
wend

A = 1;
while A < C:
   A = 5;
   passcount = passcount + 1;
   publish("test is passed on '<' ");
wend

A = 1;
while C <= (A+B):
   C = 10;
   passcount = passcount + 1;
   publish("test is passed on '<=' ");
wend

C = 3;
while D > C:
   D = 0;
   passcount = passcount + 1;
   publish("test is passed on '>' ");
wend

D = 4;
while C >= (A+B):
   C = 0;
   passcount = passcount + 1;
   publish("test is passed on '>=' ");
wend

###############################################################
#### Logical operators  [&&, ||, !&, !|, is_in, is_not_in, is_empty, is_nan]
###############################################################
A=1;B=2;C=3;D=4;E=5;

# TRUE && TRUE -> body makes the left side FALSE
while (A==1) && (C==A+B):
   A = 2;
   passcount = passcount + 1;
   publish("test is passed on '&&' ");
wend

# FALSE || TRUE -> body makes the right side FALSE as well
A = 1;
while (A==D) || (C==A+B):
   C = 0;
   passcount = passcount + 1;
   publish("test is passed on '||' ");
wend

# NAND: FALSE !& FALSE = TRUE -> body makes both sides TRUE
C = 3;
while (A==D) !& (E==A+B):
   D = 1;
   E = 3;
   passcount = passcount + 1;
   publish("test is passed on '!&' ");
wend

# NOR: FALSE !| FALSE = TRUE -> body makes the left side TRUE
D = 4; E = 5;
while (A==D) !| (D==A+B):
   D = 1;
   passcount = passcount + 1;
   publish("test is passed on '!|' ");
wend

D = 4;
while D is_in [1:10]:
   D = 50;
   passcount = passcount + 1;
   publish("test is passed on 'is_in' ");
wend

D = 4;
while D is_not_in [11:20]:
   D = 15;
   passcount = passcount + 1;
   publish("test is passed on 'is_not_in' ");
wend

L = [];
while is_empty(L):
   L = [1:3];
   passcount = passcount + 1;
   publish("test is passed on 'is_empty' ");
wend

N = 0/0;
while is_nan(N):
   N = 5;
   passcount = passcount + 1;
   publish("test is passed on 'is_nan' ");
wend

###############################################################
#### Data conversion operators  [int, float, str, round, dec2rad, rad2dec]
###############################################################

# int(4.2) = 4 whether int truncates or rounds
D = 4.2;
while int(D) == 4:
   D = 9.2;
   passcount = passcount + 1;
   publish("test is passed on 'int' ");
wend

D = 4;
while float(D) == 4.0:
   D = 9;
   passcount = passcount + 1;
   publish("test is passed on 'float' ");
wend

# compared against a stored string, so "4" vs "4.0" formatting does not matter
D = 4;
S1 = str(D);
while str(D) == S1:
   D = 9;
   passcount = passcount + 1;
   publish("test is passed on 'str' ");
wend

D = 3.14159;
while round(D,2) == 3.14:
   D = 2.71828;
   passcount = passcount + 1;
   publish("test is passed on 'round' ");
wend

# 180 degrees = 3.14159 rad -> body sets 90 degrees = 1.5708 rad
D = 180;
while dec2rad(D) > 3:
   D = 90;
   passcount = passcount + 1;
   publish("test is passed on 'dec2rad' ");
wend

# 4 rad = 229.18 degrees -> body sets 1 rad = 57.30 degrees
D = 4;
while rad2dec(D) > 180:
   D = 1;
   passcount = passcount + 1;
   publish("test is passed on 'rad2dec' ");
wend

###############################################################
publish("While-Header Operator Test : total passed out of 20 :", passcount);
###############################################################
