A = 1.1; B=1.2;C=1.3;D=1.4;E=1.5;
P=4.0;Q=9.0;R=16.0;S=25.0;T=36;
########################################

P1 = 0;
if A == A:
   if not A !=A:
      for i = [1:5]:
         while P1<i:
            while not P1>=i:
               P1 = P1 +1;
            wend
         wend
      fend
   iend
iend

P2 = 0;
if A == A:
   if not A !=A:
      for i = [1:5]:
         while not P2>=i:
            while P2<i:
               P2 = P2 +1;
            wend
         wend
      fend
   iend
iend

P3 = 0;
if A == A:
   if not A !=A:
      while P3<5:
         for i = [1:5]:
            while not P3>=i:
               P3 = P3 +1;
            wend
         fend
      wend
   iend
iend

P4 = 0;
if A == A:
   if not A !=A:
      while P4<5:
         while not P4>=5:
            for i = [1:5]:
               P4 = P4 +1;
            fend
         wend
      wend
   iend
iend

P5 = 0;
if A == A:
   if not A !=A:
      while not P5>=5:
         for i = [1:5]:
            while P5<i:
               P5 = P5 +1;
            wend
         fend
      wend
   iend
iend

P6 = 0;
if A == A:
   if not A !=A:
      while not P6>=5:
         while P6<5:
            for i = [1:5]:
               P6 = P6 +1;
            fend
         wend
      wend
   iend
iend

P7 = 0;
if A == A:
   for i = [1:5]:
      if not A !=A:
         while P7<i:
            while not P7>=i:
               P7 = P7 +1;
            wend
         wend
      iend
   fend
iend

P8 = 0;
if A == A:
   for i = [1:5]:
      if not A !=A:
         while not P8>=i:
            while P8<i:
               P8 = P8 +1;
            wend
         wend
      iend
   fend
iend

P9 = 0;
if A == A:
   for i = [1:5]:
      while P9<i:
         if not A !=A:
            while not P9>=i:
               P9 = P9 +1;
            wend
         iend
      wend
   fend
iend

P10 = 0;
if A == A:
   for i = [1:5]:
      while P10<i:
         while not P10>=i:
            if not A !=A:
               P10 = P10 +1;
            iend
         wend
      wend
   fend
iend

publish("Pass Cases [P1,P2,P3,P4,P5,P6,P7,P8,P9,P10]:", [P1,P2,P3,P4,P5,P6,P7,P8,P9,P10])

P11 = 0;
if A == A:
   for i = [1:5]:
      while not P11>=i:
         if not A !=A:
            while P11<i:
               P11 = P11 +1;
            wend
         iend
      wend
   fend
iend

P12 = 0;
if A == A:
   for i = [1:5]:
      while not P12>=i:
         while P12<i:
            if not A !=A:
               P12 = P12 +1;
            iend
         wend
      wend
   fend
iend

P13 = 0;
if A == A:
   while P13<5:
      if not A !=A:
         for i = [1:5]:
            while not P13>=i:
               P13 = P13 +1;
            wend
         fend
      iend
   wend
iend

P14 = 0;
if A == A:
   while P14<5:
      if not A !=A:
         while not P14>=5:
            for i = [1:5]:
               P14 = P14 +1;
            fend
         wend
      iend
   wend
iend

P15 = 0;
if A == A:
   while P15<5:
      for i = [1:5]:
         if not A !=A:
            while not P15>=i:
               P15 = P15 +1;
            wend
         iend
      fend
   wend
iend

P16 = 0;
if A == A:
   while P16<5:
      for i = [1:5]:
         while not P16>=i:
            if not A !=A:
               P16 = P16 +1;
            iend
         wend
      fend
   wend
iend

P17 = 0;
if A == A:
   while P17<5:
      while not P17>=5:
         if not A !=A:
            for i = [1:5]:
               P17 = P17 +1;
            fend
         iend
      wend
   wend
iend

P18 = 0;
if A == A:
   while P18<5:
      while not P18>=5:
         for i = [1:5]:
            if not A !=A:
               P18 = P18 +1;
            iend
         fend
      wend
   wend
iend

P19 = 0;
if A == A:
   while not P19>=5:
      if not A !=A:
         for i = [1:5]:
            while P19<i:
               P19 = P19 +1;
            wend
         fend
      iend
   wend
iend

P20 = 0;
if A == A:
   while not P20>=5:
      if not A !=A:
         while P20<5:
            for i = [1:5]:
               P20 = P20 +1;
            fend
         wend
      iend
   wend
iend

publish("Pass Cases [P11,P12,P13,P14,P15,P16,P17,P18,P19,P20]:", [P11,P12,P13,P14,P15,P16,P17,P18,P19,P20])

P21 = 0;
if A == A:
   while not P21>=5:
      for i = [1:5]:
         if not A !=A:
            while P21<i:
               P21 = P21 +1;
            wend
         iend
      fend
   wend
iend

P22 = 0;
if A == A:
   while not P22>=5:
      for i = [1:5]:
         while P22<i:
            if not A !=A:
               P22 = P22 +1;
            iend
         wend
      fend
   wend
iend

P23 = 0;
if A == A:
   while not P23>=5:
      while P23<5:
         if not A !=A:
            for i = [1:5]:
               P23 = P23 +1;
            fend
         iend
      wend
   wend
iend

P24 = 0;
if A == A:
   while not P24>=5:
      while P24<5:
         for i = [1:5]:
            if not A !=A:
               P24 = P24 +1;
            iend
         fend
      wend
   wend
iend

P25 = 0;
if not A !=A:
   if A == A:
      for i = [1:5]:
         while P25<i:
            while not P25>=i:
               P25 = P25 +1;
            wend
         wend
      fend
   iend
iend

P26 = 0;
if not A !=A:
   if A == A:
      for i = [1:5]:
         while not P26>=i:
            while P26<i:
               P26 = P26 +1;
            wend
         wend
      fend
   iend
iend

P27 = 0;
if not A !=A:
   if A == A:
      while P27<5:
         for i = [1:5]:
            while not P27>=i:
               P27 = P27 +1;
            wend
         fend
      wend
   iend
iend

P28 = 0;
if not A !=A:
   if A == A:
      while P28<5:
         while not P28>=5:
            for i = [1:5]:
               P28 = P28 +1;
            fend
         wend
      wend
   iend
iend

P29 = 0;
if not A !=A:
   if A == A:
      while not P29>=5:
         for i = [1:5]:
            while P29<i:
               P29 = P29 +1;
            wend
         fend
      wend
   iend
iend

P30 = 0;
if not A !=A:
   if A == A:
      while not P30>=5:
         while P30<5:
            for i = [1:5]:
               P30 = P30 +1;
            fend
         wend
      wend
   iend
iend

publish("Pass Cases [P21,P22,P23,P24,P25,P26,P27,P28,P29,P30]:", [P21,P22,P23,P24,P25,P26,P27,P28,P29,P30])

P31 = 0;
if not A !=A:
   for i = [1:5]:
      if A == A:
         while P31<i:
            while not P31>=i:
               P31 = P31 +1;
            wend
         wend
      iend
   fend
iend

P32 = 0;
if not A !=A:
   for i = [1:5]:
      if A == A:
         while not P32>=i:
            while P32<i:
               P32 = P32 +1;
            wend
         wend
      iend
   fend
iend

P33 = 0;
if not A !=A:
   for i = [1:5]:
      while P33<i:
         if A == A:
            while not P33>=i:
               P33 = P33 +1;
            wend
         iend
      wend
   fend
iend

P34 = 0;
if not A !=A:
   for i = [1:5]:
      while P34<i:
         while not P34>=i:
            if A == A:
               P34 = P34 +1;
            iend
         wend
      wend
   fend
iend

P35 = 0;
if not A !=A:
   for i = [1:5]:
      while not P35>=i:
         if A == A:
            while P35<i:
               P35 = P35 +1;
            wend
         iend
      wend
   fend
iend

P36 = 0;
if not A !=A:
   for i = [1:5]:
      while not P36>=i:
         while P36<i:
            if A == A:
               P36 = P36 +1;
            iend
         wend
      wend
   fend
iend

P37 = 0;
if not A !=A:
   while P37<5:
      if A == A:
         for i = [1:5]:
            while not P37>=i:
               P37 = P37 +1;
            wend
         fend
      iend
   wend
iend

P38 = 0;
if not A !=A:
   while P38<5:
      if A == A:
         while not P38>=5:
            for i = [1:5]:
               P38 = P38 +1;
            fend
         wend
      iend
   wend
iend

P39 = 0;
if not A !=A:
   while P39<5:
      for i = [1:5]:
         if A == A:
            while not P39>=i:
               P39 = P39 +1;
            wend
         iend
      fend
   wend
iend

P40 = 0;
if not A !=A:
   while P40<5:
      for i = [1:5]:
         while not P40>=i:
            if A == A:
               P40 = P40 +1;
            iend
         wend
      fend
   wend
iend

publish("Pass Cases [P31,P32,P33,P34,P35,P36,P37,P38,P39,P40]:", [P31,P32,P33,P34,P35,P36,P37,P38,P39,P40])

P41 = 0;
if not A !=A:
   while P41<5:
      while not P41>=5:
         if A == A:
            for i = [1:5]:
               P41 = P41 +1;
            fend
         iend
      wend
   wend
iend

P42 = 0;
if not A !=A:
   while P42<5:
      while not P42>=5:
         for i = [1:5]:
            if A == A:
               P42 = P42 +1;
            iend
         fend
      wend
   wend
iend

P43 = 0;
if not A !=A:
   while not P43>=5:
      if A == A:
         for i = [1:5]:
            while P43<i:
               P43 = P43 +1;
            wend
         fend
      iend
   wend
iend

P44 = 0;
if not A !=A:
   while not P44>=5:
      if A == A:
         while P44<5:
            for i = [1:5]:
               P44 = P44 +1;
            fend
         wend
      iend
   wend
iend

P45 = 0;
if not A !=A:
   while not P45>=5:
      for i = [1:5]:
         if A == A:
            while P45<i:
               P45 = P45 +1;
            wend
         iend
      fend
   wend
iend

P46 = 0;
if not A !=A:
   while not P46>=5:
      for i = [1:5]:
         while P46<i:
            if A == A:
               P46 = P46 +1;
            iend
         wend
      fend
   wend
iend

P47 = 0;
if not A !=A:
   while not P47>=5:
      while P47<5:
         if A == A:
            for i = [1:5]:
               P47 = P47 +1;
            fend
         iend
      wend
   wend
iend

P48 = 0;
if not A !=A:
   while not P48>=5:
      while P48<5:
         for i = [1:5]:
            if A == A:
               P48 = P48 +1;
            iend
         fend
      wend
   wend
iend

P49 = 0;
for i = [1:5]:
   if A == A:
      if not A !=A:
         while P49<i:
            while not P49>=i:
               P49 = P49 +1;
            wend
         wend
      iend
   iend
fend

P50 = 0;
for i = [1:5]:
   if A == A:
      if not A !=A:
         while not P50>=i:
            while P50<i:
               P50 = P50 +1;
            wend
         wend
      iend
   iend
fend

publish("Pass Cases [P41,P42,P43,P44,P45,P46,P47,P48,P49,P50]:", [P41,P42,P43,P44,P45,P46,P47,P48,P49,P50])

P51 = 0;
for i = [1:5]:
   if A == A:
      while P51<i:
         if not A !=A:
            while not P51>=i:
               P51 = P51 +1;
            wend
         iend
      wend
   iend
fend

P52 = 0;
for i = [1:5]:
   if A == A:
      while P52<i:
         while not P52>=i:
            if not A !=A:
               P52 = P52 +1;
            iend
         wend
      wend
   iend
fend

P53 = 0;
for i = [1:5]:
   if A == A:
      while not P53>=i:
         if not A !=A:
            while P53<i:
               P53 = P53 +1;
            wend
         iend
      wend
   iend
fend

P54 = 0;
for i = [1:5]:
   if A == A:
      while not P54>=i:
         while P54<i:
            if not A !=A:
               P54 = P54 +1;
            iend
         wend
      wend
   iend
fend

P55 = 0;
for i = [1:5]:
   if not A !=A:
      if A == A:
         while P55<i:
            while not P55>=i:
               P55 = P55 +1;
            wend
         wend
      iend
   iend
fend

P56 = 0;
for i = [1:5]:
   if not A !=A:
      if A == A:
         while not P56>=i:
            while P56<i:
               P56 = P56 +1;
            wend
         wend
      iend
   iend
fend

P57 = 0;
for i = [1:5]:
   if not A !=A:
      while P57<i:
         if A == A:
            while not P57>=i:
               P57 = P57 +1;
            wend
         iend
      wend
   iend
fend

P58 = 0;
for i = [1:5]:
   if not A !=A:
      while P58<i:
         while not P58>=i:
            if A == A:
               P58 = P58 +1;
            iend
         wend
      wend
   iend
fend

P59 = 0;
for i = [1:5]:
   if not A !=A:
      while not P59>=i:
         if A == A:
            while P59<i:
               P59 = P59 +1;
            wend
         iend
      wend
   iend
fend

P60 = 0;
for i = [1:5]:
   if not A !=A:
      while not P60>=i:
         while P60<i:
            if A == A:
               P60 = P60 +1;
            iend
         wend
      wend
   iend
fend

publish("Pass Cases [P51,P52,P53,P54,P55,P56,P57,P58,P59,P60]:", [P51,P52,P53,P54,P55,P56,P57,P58,P59,P60])

P61 = 0;
for i = [1:5]:
   while P61<i:
      if A == A:
         if not A !=A:
            while not P61>=i:
               P61 = P61 +1;
            wend
         iend
      iend
   wend
fend

P62 = 0;
for i = [1:5]:
   while P62<i:
      if A == A:
         while not P62>=i:
            if not A !=A:
               P62 = P62 +1;
            iend
         wend
      iend
   wend
fend

P63 = 0;
for i = [1:5]:
   while P63<i:
      if not A !=A:
         if A == A:
            while not P63>=i:
               P63 = P63 +1;
            wend
         iend
      iend
   wend
fend

P64 = 0;
for i = [1:5]:
   while P64<i:
      if not A !=A:
         while not P64>=i:
            if A == A:
               P64 = P64 +1;
            iend
         wend
      iend
   wend
fend

P65 = 0;
for i = [1:5]:
   while P65<i:
      while not P65>=i:
         if A == A:
            if not A !=A:
               P65 = P65 +1;
            iend
         iend
      wend
   wend
fend

P66 = 0;
for i = [1:5]:
   while P66<i:
      while not P66>=i:
         if not A !=A:
            if A == A:
               P66 = P66 +1;
            iend
         iend
      wend
   wend
fend

P67 = 0;
for i = [1:5]:
   while not P67>=i:
      if A == A:
         if not A !=A:
            while P67<i:
               P67 = P67 +1;
            wend
         iend
      iend
   wend
fend

P68 = 0;
for i = [1:5]:
   while not P68>=i:
      if A == A:
         while P68<i:
            if not A !=A:
               P68 = P68 +1;
            iend
         wend
      iend
   wend
fend

P69 = 0;
for i = [1:5]:
   while not P69>=i:
      if not A !=A:
         if A == A:
            while P69<i:
               P69 = P69 +1;
            wend
         iend
      iend
   wend
fend

P70 = 0;
for i = [1:5]:
   while not P70>=i:
      if not A !=A:
         while P70<i:
            if A == A:
               P70 = P70 +1;
            iend
         wend
      iend
   wend
fend

publish("Pass Cases [P61,P62,P63,P64,P65,P66,P67,P68,P69,P70]:", [P61,P62,P63,P64,P65,P66,P67,P68,P69,P70])

P71 = 0;
for i = [1:5]:
   while not P71>=i:
      while P71<i:
         if A == A:
            if not A !=A:
               P71 = P71 +1;
            iend
         iend
      wend
   wend
fend

P72 = 0;
for i = [1:5]:
   while not P72>=i:
      while P72<i:
         if not A !=A:
            if A == A:
               P72 = P72 +1;
            iend
         iend
      wend
   wend
fend

P73 = 0;
while P73<5:
   if A == A:
      if not A !=A:
         for i = [1:5]:
            while not P73>=i:
               P73 = P73 +1;
            wend
         fend
      iend
   iend
wend

P74 = 0;
while P74<5:
   if A == A:
      if not A !=A:
         while not P74>=5:
            for i = [1:5]:
               P74 = P74 +1;
            fend
         wend
      iend
   iend
wend

P75 = 0;
while P75<5:
   if A == A:
      for i = [1:5]:
         if not A !=A:
            while not P75>=i:
               P75 = P75 +1;
            wend
         iend
      fend
   iend
wend

P76 = 0;
while P76<5:
   if A == A:
      for i = [1:5]:
         while not P76>=i:
            if not A !=A:
               P76 = P76 +1;
            iend
         wend
      fend
   iend
wend

P77 = 0;
while P77<5:
   if A == A:
      while not P77>=5:
         if not A !=A:
            for i = [1:5]:
               P77 = P77 +1;
            fend
         iend
      wend
   iend
wend

P78 = 0;
while P78<5:
   if A == A:
      while not P78>=5:
         for i = [1:5]:
            if not A !=A:
               P78 = P78 +1;
            iend
         fend
      wend
   iend
wend

P79 = 0;
while P79<5:
   if not A !=A:
      if A == A:
         for i = [1:5]:
            while not P79>=i:
               P79 = P79 +1;
            wend
         fend
      iend
   iend
wend

P80 = 0;
while P80<5:
   if not A !=A:
      if A == A:
         while not P80>=5:
            for i = [1:5]:
               P80 = P80 +1;
            fend
         wend
      iend
   iend
wend

publish("Pass Cases [P71,P72,P73,P74,P75,P76,P77,P78,P79,P80]:", [P71,P72,P73,P74,P75,P76,P77,P78,P79,P80])

P81 = 0;
while P81<5:
   if not A !=A:
      for i = [1:5]:
         if A == A:
            while not P81>=i:
               P81 = P81 +1;
            wend
         iend
      fend
   iend
wend

P82 = 0;
while P82<5:
   if not A !=A:
      for i = [1:5]:
         while not P82>=i:
            if A == A:
               P82 = P82 +1;
            iend
         wend
      fend
   iend
wend

P83 = 0;
while P83<5:
   if not A !=A:
      while not P83>=5:
         if A == A:
            for i = [1:5]:
               P83 = P83 +1;
            fend
         iend
      wend
   iend
wend

P84 = 0;
while P84<5:
   if not A !=A:
      while not P84>=5:
         for i = [1:5]:
            if A == A:
               P84 = P84 +1;
            iend
         fend
      wend
   iend
wend

P85 = 0;
while P85<5:
   for i = [1:5]:
      if A == A:
         if not A !=A:
            while not P85>=i:
               P85 = P85 +1;
            wend
         iend
      iend
   fend
wend

P86 = 0;
while P86<5:
   for i = [1:5]:
      if A == A:
         while not P86>=i:
            if not A !=A:
               P86 = P86 +1;
            iend
         wend
      iend
   fend
wend

P87 = 0;
while P87<5:
   for i = [1:5]:
      if not A !=A:
         if A == A:
            while not P87>=i:
               P87 = P87 +1;
            wend
         iend
      iend
   fend
wend

P88 = 0;
while P88<5:
   for i = [1:5]:
      if not A !=A:
         while not P88>=i:
            if A == A:
               P88 = P88 +1;
            iend
         wend
      iend
   fend
wend

P89 = 0;
while P89<5:
   for i = [1:5]:
      while not P89>=i:
         if A == A:
            if not A !=A:
               P89 = P89 +1;
            iend
         iend
      wend
   fend
wend

P90 = 0;
while P90<5:
   for i = [1:5]:
      while not P90>=i:
         if not A !=A:
            if A == A:
               P90 = P90 +1;
            iend
         iend
      wend
   fend
wend

publish("Pass Cases [P81,P82,P83,P84,P85,P86,P87,P88,P89,P90]:", [P81,P82,P83,P84,P85,P86,P87,P88,P89,P90])

P91 = 0;
while P91<5:
   while not P91>=5:
      if A == A:
         if not A !=A:
            for i = [1:5]:
               P91 = P91 +1;
            fend
         iend
      iend
   wend
wend

P92 = 0;
while P92<5:
   while not P92>=5:
      if A == A:
         for i = [1:5]:
            if not A !=A:
               P92 = P92 +1;
            iend
         fend
      iend
   wend
wend

P93 = 0;
while P93<5:
   while not P93>=5:
      if not A !=A:
         if A == A:
            for i = [1:5]:
               P93 = P93 +1;
            fend
         iend
      iend
   wend
wend

P94 = 0;
while P94<5:
   while not P94>=5:
      if not A !=A:
         for i = [1:5]:
            if A == A:
               P94 = P94 +1;
            iend
         fend
      iend
   wend
wend

P95 = 0;
while P95<5:
   while not P95>=5:
      for i = [1:5]:
         if A == A:
            if not A !=A:
               P95 = P95 +1;
            iend
         iend
      fend
   wend
wend

P96 = 0;
while P96<5:
   while not P96>=5:
      for i = [1:5]:
         if not A !=A:
            if A == A:
               P96 = P96 +1;
            iend
         iend
      fend
   wend
wend

P97 = 0;
while not P97>=5:
   if A == A:
      if not A !=A:
         for i = [1:5]:
            while P97<i:
               P97 = P97 +1;
            wend
         fend
      iend
   iend
wend

P98 = 0;
while not P98>=5:
   if A == A:
      if not A !=A:
         while P98<5:
            for i = [1:5]:
               P98 = P98 +1;
            fend
         wend
      iend
   iend
wend

P99 = 0;
while not P99>=5:
   if A == A:
      for i = [1:5]:
         if not A !=A:
            while P99<i:
               P99 = P99 +1;
            wend
         iend
      fend
   iend
wend

P100 = 0;
while not P100>=5:
   if A == A:
      for i = [1:5]:
         while P100<i:
            if not A !=A:
               P100 = P100 +1;
            iend
         wend
      fend
   iend
wend

publish("Pass Cases [P91,P92,P93,P94,P95,P96,P97,P98,P99,P100]:", [P91,P92,P93,P94,P95,P96,P97,P98,P99,P100])

P101 = 0;
while not P101>=5:
   if A == A:
      while P101<5:
         if not A !=A:
            for i = [1:5]:
               P101 = P101 +1;
            fend
         iend
      wend
   iend
wend

P102 = 0;
while not P102>=5:
   if A == A:
      while P102<5:
         for i = [1:5]:
            if not A !=A:
               P102 = P102 +1;
            iend
         fend
      wend
   iend
wend

P103 = 0;
while not P103>=5:
   if not A !=A:
      if A == A:
         for i = [1:5]:
            while P103<i:
               P103 = P103 +1;
            wend
         fend
      iend
   iend
wend

P104 = 0;
while not P104>=5:
   if not A !=A:
      if A == A:
         while P104<5:
            for i = [1:5]:
               P104 = P104 +1;
            fend
         wend
      iend
   iend
wend

P105 = 0;
while not P105>=5:
   if not A !=A:
      for i = [1:5]:
         if A == A:
            while P105<i:
               P105 = P105 +1;
            wend
         iend
      fend
   iend
wend

P106 = 0;
while not P106>=5:
   if not A !=A:
      for i = [1:5]:
         while P106<i:
            if A == A:
               P106 = P106 +1;
            iend
         wend
      fend
   iend
wend

P107 = 0;
while not P107>=5:
   if not A !=A:
      while P107<5:
         if A == A:
            for i = [1:5]:
               P107 = P107 +1;
            fend
         iend
      wend
   iend
wend

P108 = 0;
while not P108>=5:
   if not A !=A:
      while P108<5:
         for i = [1:5]:
            if A == A:
               P108 = P108 +1;
            iend
         fend
      wend
   iend
wend

P109 = 0;
while not P109>=5:
   for i = [1:5]:
      if A == A:
         if not A !=A:
            while P109<i:
               P109 = P109 +1;
            wend
         iend
      iend
   fend
wend

P110 = 0;
while not P110>=5:
   for i = [1:5]:
      if A == A:
         while P110<i:
            if not A !=A:
               P110 = P110 +1;
            iend
         wend
      iend
   fend
wend

publish("Pass Cases [P101,P102,P103,P104,P105,P106,P107,P108,P109,P110]:", [P101,P102,P103,P104,P105,P106,P107,P108,P109,P110])

P111 = 0;
while not P111>=5:
   for i = [1:5]:
      if not A !=A:
         if A == A:
            while P111<i:
               P111 = P111 +1;
            wend
         iend
      iend
   fend
wend

P112 = 0;
while not P112>=5:
   for i = [1:5]:
      if not A !=A:
         while P112<i:
            if A == A:
               P112 = P112 +1;
            iend
         wend
      iend
   fend
wend

P113 = 0;
while not P113>=5:
   for i = [1:5]:
      while P113<i:
         if A == A:
            if not A !=A:
               P113 = P113 +1;
            iend
         iend
      wend
   fend
wend

P114 = 0;
while not P114>=5:
   for i = [1:5]:
      while P114<i:
         if not A !=A:
            if A == A:
               P114 = P114 +1;
            iend
         iend
      wend
   fend
wend

P115 = 0;
while not P115>=5:
   while P115<5:
      if A == A:
         if not A !=A:
            for i = [1:5]:
               P115 = P115 +1;
            fend
         iend
      iend
   wend
wend

P116 = 0;
while not P116>=5:
   while P116<5:
      if A == A:
         for i = [1:5]:
            if not A !=A:
               P116 = P116 +1;
            iend
         fend
      iend
   wend
wend

P117 = 0;
while not P117>=5:
   while P117<5:
      if not A !=A:
         if A == A:
            for i = [1:5]:
               P117 = P117 +1;
            fend
         iend
      iend
   wend
wend

P118 = 0;
while not P118>=5:
   while P118<5:
      if not A !=A:
         for i = [1:5]:
            if A == A:
               P118 = P118 +1;
            iend
         fend
      iend
   wend
wend

P119 = 0;
while not P119>=5:
   while P119<5:
      for i = [1:5]:
         if A == A:
            if not A !=A:
               P119 = P119 +1;
            iend
         iend
      fend
   wend
wend

P120 = 0;
while not P120>=5:
   while P120<5:
      for i = [1:5]:
         if not A !=A:
            if A == A:
               P120 = P120 +1;
            iend
         iend
      fend
   wend
wend

publish("Pass Cases [P111,P112,P113,P114,P115,P116,P117,P118,P119,P120]:", [P111,P112,P113,P114,P115,P116,P117,P118,P119,P120])

