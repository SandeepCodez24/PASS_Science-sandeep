#############################################################
#############################################################
A=1;B=2;C=3;D=4;E=5;F=6;G=7;H=8;I=9;J=10;
P=4;Q=9;R=16;S=25;T=36;U=49;V=64;W=81;X=100;Y=121;Z=144;
#############################################################
#############################################################
count = 0;
if A==1:
   count = count +1;
   if B == 2:
      count = count +1;
      if C==3:
         count = count +1;
         if D==4:
            count = count +1;
            if E==5:
               count = count +1;
               if F==6:
                  count = count +1;
                  if G==7:
                     count = count +1;
                     if H==8:
                        count = count +1;
                        if I == 9:
                           count = count +1;
                           if J==10:
                              count = count +1;
                              if A ==1:
                                 count = count +1;
                                 if B ==2:
                                    count = count +1;
                                    if C==3:
                                       count = count +1;
                                       if D==4:
                                          count = count +1;
                                          if E ==5:
                                             count = count +1;
                                             if F == 6:
                                                count = count +1;
                                             iend
                                          iend
                                       iend
                                    iend
                                 iend
                              iend
                           iend
                        iend
                     iend
                  iend
               iend
            iend
         iend
      iend   
   iend
iend

publish("Horizon Test : simple 'if' for 16 steps :", count)