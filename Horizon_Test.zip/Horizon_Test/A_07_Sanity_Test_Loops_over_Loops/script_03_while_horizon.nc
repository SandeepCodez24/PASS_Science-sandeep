fcount = 0;

while fcount < (2^16):
   while fcount < (2^15):
      while fcount < (2^14):
         while fcount < (2^13):
            while fcount < (2^12):
               while fcount < (2^11):
                  while fcount < (2^10):
                     while fcount < (2^9):
                        while fcount < (2^8):
                           while fcount < (2^7):
                              while fcount < (2^6):
                                 while fcount < (2^5):
                                    while fcount < (2^4):
                                       while fcount < (2^3):
                                          while fcount < (2^2):
                                             while fcount < (2^1):
                                                fcount = fcount +1;     
                                             wend
                                             fcount = fcount +1; 
                                          wend
                                          fcount = fcount +1; 
                                       wend
                                       fcount = fcount +1; 
                                    wend
                                    fcount = fcount +1; 
                                 wend
                                 fcount = fcount +1; 
                              wend
                              fcount = fcount +1; 
                           wend
                           fcount = fcount +1; 
                        wend
                        fcount = fcount +1; 
                     wend
                     fcount = fcount +1; 
                  wend
                  fcount = fcount +1; 
               wend
               fcount = fcount +1; 
            wend
            fcount = fcount +1; 
         wend
         fcount = fcount +1; 
      wend
      fcount = fcount +1; 
   wend
   fcount = fcount +1; 
wend



publish("Horizon Test : simple 'while' for 16 steps (2^16 = 65536) :", fcount)