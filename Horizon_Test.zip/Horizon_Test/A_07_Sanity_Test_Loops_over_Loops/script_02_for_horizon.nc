fcount = 0;

for i1=[1:2]:
   for i2 = [1:2]:
      for i3 = [1:2]:
         for i4 = [1:2]:
            for i5 = [1:2]:
               for i6 = [1:2]:
                  for i7 = [1:2]:
                     for i8 = [1:2]:
                        for i9 = [1:2]:
                           for i10 = [1:2]:
                              for i11 = [1:2]:
                                 for i12 = [1:2]:
                                    for i13 = [1:2]:
                                       for i14 = [1:2]:
                                          for i15 = [1:2]:
                                             for i16 = [1:2]:
                                                fcount = fcount +1;     
                                             fend     
                                          fend      
                                       fend     
                                    fend      
                                 fend      
                              fend      
                           fend
                        fend      
                     fend      
                  fend  
               fend
            fend
         fend
      fend
   fend
fend



publish("Horizon Test : simple 'for' for 16 steps (2^16 = 65536) :", fcount)