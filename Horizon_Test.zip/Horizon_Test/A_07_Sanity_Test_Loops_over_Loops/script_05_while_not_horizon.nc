fcount = 0;

while not (fcount >= (2^16)):
   while not (fcount >= (2^15)):
      while not (fcount >= (2^14)):
         while not (fcount >= (2^13)):
            while not (fcount >= (2^12)):
               while not (fcount >= (2^11)):
                  while not (fcount >= (2^10)):
                     while not (fcount >= (2^9)):
                        while not (fcount >= (2^8)):
                           while not (fcount >= (2^7)):
                              while not (fcount >= (2^6)):
                                 while not (fcount >= (2^5)):
                                    while not (fcount >= (2^4)):
                                       while not (fcount >= (2^3)):
                                          while not (fcount >= (2^2)):
                                             while not (fcount >= (2^1)):
                                                fcount = fcount +1;     
                                             wend
                                             fcount = fcount +1; 
                                          wend
                                          fcount = fcount +1; 
                                       wend
                                       fcount = fcount +1; 
                                    wend
                                    fcount = fcount +1; 
                                 wend
                                 fcount = fcount +1; 
                              wend
                              fcount = fcount +1; 
                           wend
                           fcount = fcount +1; 
                        wend
                        fcount = fcount +1; 
                     wend
                     fcount = fcount +1; 
                  wend
                  fcount = fcount +1; 
               wend
               fcount = fcount +1; 
            wend
            fcount = fcount +1; 
         wend
         fcount = fcount +1; 
      wend
      fcount = fcount +1; 
   wend
   fcount = fcount +1; 
wend

publish("Horizon Test : simple 'while not' for 16 steps (2^16 = 65536) :", fcount)