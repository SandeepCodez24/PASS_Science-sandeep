#######################################################
####### While-Not Primitive Header Test : 16 x 6 = 96 #######
#######################################################
# Each block: the primitive and comparison sit in the 'while not' header.
# K is set so the condition is FALSE on entry (header TRUE via 'not');
# the body makes the condition TRUE -> loop exits after one pass.
# All operand values give exact results (no floating-point drift).
# A missing 'passed' line in the output = that combination failed.
#######################################################

passcount = 0;

#######################################################
# Primitive  1 : '+'   ->   (A+B) = 5
#######################################################
A = 2; B = 3;

K = 4;
while not ((A+B) < K):
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '+' and '<' ");
wend

K = 4;
while not ((A+B) <= K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '+' and '<=' ");
wend

K = 6;
while not ((A+B) > K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '+' and '>' ");
wend

K = 6;
while not ((A+B) >= K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '+' and '>=' ");
wend

K = 6;
while not ((A+B) == K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '+' and '==' ");
wend

K = 5;
while not ((A+B) != K):
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '+' and '!=' ");
wend

#######################################################
# Primitive  2 : '-'   ->   (A-B) = 4
#######################################################
A = 7; B = 3;

K = 3;
while not ((A-B) < K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '-' and '<' ");
wend

K = 3;
while not ((A-B) <= K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '-' and '<=' ");
wend

K = 5;
while not ((A-B) > K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '-' and '>' ");
wend

K = 5;
while not ((A-B) >= K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '-' and '>=' ");
wend

K = 5;
while not ((A-B) == K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '-' and '==' ");
wend

K = 4;
while not ((A-B) != K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '-' and '!=' ");
wend

#######################################################
# Primitive  3 : '*'   ->   (A*B) = 20
#######################################################
A = 4; B = 5;

K = 19;
while not ((A*B) < K):
   K = 21;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '*' and '<' ");
wend

K = 19;
while not ((A*B) <= K):
   K = 20;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '*' and '<=' ");
wend

K = 21;
while not ((A*B) > K):
   K = 19;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '*' and '>' ");
wend

K = 21;
while not ((A*B) >= K):
   K = 20;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '*' and '>=' ");
wend

K = 21;
while not ((A*B) == K):
   K = 20;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '*' and '==' ");
wend

K = 20;
while not ((A*B) != K):
   K = 21;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '*' and '!=' ");
wend

#######################################################
# Primitive  4 : '/'   ->   (A/B) = 5
#######################################################
A = 20; B = 4;

K = 4;
while not ((A/B) < K):
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '/' and '<' ");
wend

K = 4;
while not ((A/B) <= K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '/' and '<=' ");
wend

K = 6;
while not ((A/B) > K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '/' and '>' ");
wend

K = 6;
while not ((A/B) >= K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '/' and '>=' ");
wend

K = 6;
while not ((A/B) == K):
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '/' and '==' ");
wend

K = 5;
while not ((A/B) != K):
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '/' and '!=' ");
wend

#######################################################
# Primitive  5 : 'sqr'   ->   (sqr(E)) = 9
#######################################################
E = 3;

K = 8;
while not ((sqr(E)) < K):
   K = 10;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqr' and '<' ");
wend

K = 8;
while not ((sqr(E)) <= K):
   K = 9;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqr' and '<=' ");
wend

K = 10;
while not ((sqr(E)) > K):
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqr' and '>' ");
wend

K = 10;
while not ((sqr(E)) >= K):
   K = 9;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqr' and '>=' ");
wend

K = 10;
while not ((sqr(E)) == K):
   K = 9;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqr' and '==' ");
wend

K = 9;
while not ((sqr(E)) != K):
   K = 10;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqr' and '!=' ");
wend

#######################################################
# Primitive  6 : 'sqrt'   ->   (sqrt(R)) = 12
#######################################################
R = 144;

K = 11;
while not ((sqrt(R)) < K):
   K = 13;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqrt' and '<' ");
wend

K = 11;
while not ((sqrt(R)) <= K):
   K = 12;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqrt' and '<=' ");
wend

K = 13;
while not ((sqrt(R)) > K):
   K = 11;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqrt' and '>' ");
wend

K = 13;
while not ((sqrt(R)) >= K):
   K = 12;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqrt' and '>=' ");
wend

K = 13;
while not ((sqrt(R)) == K):
   K = 12;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqrt' and '==' ");
wend

K = 12;
while not ((sqrt(R)) != K):
   K = 13;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'sqrt' and '!=' ");
wend

#######################################################
# Primitive  7 : 'cube'   ->   (cube(Q)) = 27
#######################################################
Q = 3;

K = 26;
while not ((cube(Q)) < K):
   K = 28;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cube' and '<' ");
wend

K = 26;
while not ((cube(Q)) <= K):
   K = 27;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cube' and '<=' ");
wend

K = 28;
while not ((cube(Q)) > K):
   K = 26;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cube' and '>' ");
wend

K = 28;
while not ((cube(Q)) >= K):
   K = 27;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cube' and '>=' ");
wend

K = 28;
while not ((cube(Q)) == K):
   K = 27;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cube' and '==' ");
wend

K = 27;
while not ((cube(Q)) != K):
   K = 28;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cube' and '!=' ");
wend

#######################################################
# Primitive  8 : 'cbrt'   ->   (cbrt(S)) = 2
#######################################################
S = 8;

K = 1;
while not ((cbrt(S)) < K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cbrt' and '<' ");
wend

K = 1;
while not ((cbrt(S)) <= K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cbrt' and '<=' ");
wend

K = 3;
while not ((cbrt(S)) > K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cbrt' and '>' ");
wend

K = 3;
while not ((cbrt(S)) >= K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cbrt' and '>=' ");
wend

K = 3;
while not ((cbrt(S)) == K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cbrt' and '==' ");
wend

K = 2;
while not ((cbrt(S)) != K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'cbrt' and '!=' ");
wend

#######################################################
# Primitive  9 : '^'   ->   (E^5) = 32
#######################################################
E = 2;

K = 31;
while not ((E^5) < K):
   K = 33;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '^' and '<' ");
wend

K = 31;
while not ((E^5) <= K):
   K = 32;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '^' and '<=' ");
wend

K = 33;
while not ((E^5) > K):
   K = 31;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '^' and '>' ");
wend

K = 33;
while not ((E^5) >= K):
   K = 32;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '^' and '>=' ");
wend

K = 33;
while not ((E^5) == K):
   K = 32;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '^' and '==' ");
wend

K = 32;
while not ((E^5) != K):
   K = 33;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '^' and '!=' ");
wend

#######################################################
# Primitive 10 : '!'   ->   (P!) = 24
#######################################################
P = 4;

K = 23;
while not ((P!) < K):
   K = 25;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!' and '<' ");
wend

K = 23;
while not ((P!) <= K):
   K = 24;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!' and '<=' ");
wend

K = 25;
while not ((P!) > K):
   K = 23;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!' and '>' ");
wend

K = 25;
while not ((P!) >= K):
   K = 24;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!' and '>=' ");
wend

K = 25;
while not ((P!) == K):
   K = 24;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!' and '==' ");
wend

K = 24;
while not ((P!) != K):
   K = 25;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '!' and '!=' ");
wend

#######################################################
# Primitive 11 : '//'   ->   (P//D) = 3
#######################################################
P = 17; D = 5;

K = 2;
while not ((P//D) < K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '//' and '<' ");
wend

K = 2;
while not ((P//D) <= K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '//' and '<=' ");
wend

K = 4;
while not ((P//D) > K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '//' and '>' ");
wend

K = 4;
while not ((P//D) >= K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '//' and '>=' ");
wend

K = 4;
while not ((P//D) == K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '//' and '==' ");
wend

K = 3;
while not ((P//D) != K):
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '//' and '!=' ");
wend

#######################################################
# Primitive 12 : '%'   ->   (P%D) = 2
#######################################################
P = 17; D = 5;

K = 1;
while not ((P%D) < K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '%' and '<' ");
wend

K = 1;
while not ((P%D) <= K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '%' and '<=' ");
wend

K = 3;
while not ((P%D) > K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '%' and '>' ");
wend

K = 3;
while not ((P%D) >= K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '%' and '>=' ");
wend

K = 3;
while not ((P%D) == K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '%' and '==' ");
wend

K = 2;
while not ((P%D) != K):
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '%' and '!=' ");
wend

#######################################################
# Primitive 13 : 'log'   ->   (log(P)) = 0
#######################################################
P = 1;

K = -1;
while not ((log(P)) < K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'log' and '<' ");
wend

K = -1;
while not ((log(P)) <= K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'log' and '<=' ");
wend

K = 1;
while not ((log(P)) > K):
   K = -1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'log' and '>' ");
wend

K = 1;
while not ((log(P)) >= K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'log' and '>=' ");
wend

K = 1;
while not ((log(P)) == K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'log' and '==' ");
wend

K = 0;
while not ((log(P)) != K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'log' and '!=' ");
wend

#######################################################
# Primitive 14 : 'logb3'   ->   (logb3(Q)) = 0
#######################################################
Q = 1;

K = -1;
while not ((logb3(Q)) < K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'logb3' and '<' ");
wend

K = -1;
while not ((logb3(Q)) <= K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'logb3' and '<=' ");
wend

K = 1;
while not ((logb3(Q)) > K):
   K = -1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'logb3' and '>' ");
wend

K = 1;
while not ((logb3(Q)) >= K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'logb3' and '>=' ");
wend

K = 1;
while not ((logb3(Q)) == K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'logb3' and '==' ");
wend

K = 0;
while not ((logb3(Q)) != K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'logb3' and '!=' ");
wend

#######################################################
# Primitive 15 : 'e^'   ->   (e^(P)) = 1
#######################################################
P = 0;

K = 0;
while not ((e^(P)) < K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'e^' and '<' ");
wend

K = 0;
while not ((e^(P)) <= K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'e^' and '<=' ");
wend

K = 2;
while not ((e^(P)) > K):
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'e^' and '>' ");
wend

K = 2;
while not ((e^(P)) >= K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'e^' and '>=' ");
wend

K = 2;
while not ((e^(P)) == K):
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'e^' and '==' ");
wend

K = 1;
while not ((e^(P)) != K):
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with 'e^' and '!=' ");
wend

#######################################################
# Primitive 16 : '| |'   ->   (|U|) = 7
#######################################################
U = -7;

K = 6;
while not ((|U|) < K):
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '| |' and '<' ");
wend

K = 6;
while not ((|U|) <= K):
   K = 7;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '| |' and '<=' ");
wend

K = 8;
while not ((|U|) > K):
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '| |' and '>' ");
wend

K = 8;
while not ((|U|) >= K):
   K = 7;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '| |' and '>=' ");
wend

K = 8;
while not ((|U|) == K):
   K = 7;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '| |' and '==' ");
wend

K = 7;
while not ((|U|) != K):
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on 'while not' with '| |' and '!=' ");
wend

#######################################################
publish("While-Not Primitive Header Test : total passed out of 96 :", passcount);
