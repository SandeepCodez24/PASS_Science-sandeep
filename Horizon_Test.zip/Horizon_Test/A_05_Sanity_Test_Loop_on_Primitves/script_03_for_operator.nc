#######################################################
################ variable Declaration #################
#######################################################
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
V = 1.1; W = 1.2; X=1.3; Y = 1.4; Z = 1.5; U = -6.9;
#######################################################
p1count = 0;
p2count = 0;
p3count = 0;
p4count = 0;
p5count = 0;
p6count = 0;
p7count = 0;
p8count = 0;
p9count = 0;
p10count = 0;
p11count = 0;
p12count = 0;
p13count = 0;
p14count = 0;
p15count = 0;
p16count = 0;

for i=[1:128]:
   p1count  = p1count  + (A+B == B+A);
   p2count  = p2count  + (A-B == A-B);
   p3count  = p3count  + (A*B == B*A);
   p4count  = p4count  + (A/B == A/B);
   p5count  = p5count  + (sqr(E) == sqr(E));
   p6count  = p6count  + (sqrt(R) == sqrt(R));
   p7count  = p7count  + (cube(Q) == cube(Q));
   p8count  = p8count  + (cbrt(S) == cbrt(S));
   p9count  = p9count  + (E^5 == E^5);
   p10count = p10count + (P! == P!);
   p11count = p11count + (P//D == P//D);
   p12count = p12count + (P%D == P%D);
   p13count = p13count + (log(P) == log(P));
   p14count = p14count + (logb3(Q) == logb3(Q));
   p15count = p15count + (e^(P) ==e^(P));  
   p16count = p16count + (|U| == |U|);
fend

publish("Loop-Primitiv Test : 'for' on all : 128 tests:",p1count, p2count, p3count,p4count,~~
        p5count,p6count, p7count, p8count, p9count, p10count, p11count, p12count, p13count, p14count, p15count, p16count);
#######################################################
#######################################################
μ = 12; 