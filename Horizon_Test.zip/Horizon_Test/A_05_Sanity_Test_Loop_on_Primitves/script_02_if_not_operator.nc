#######################################################
################ variable Declaration #################
#######################################################
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
V = 1.1; W = 1.2; X=1.3; Y = 1.4; Z = 1.5; U = -6.9;
#######################################################
count = 0;
if not A+B == B+A + 1:
   count = count +1;
iend

if not A-B == A-B + 1:
   count = count +1;
iend

if not A*B == B*A + 1:
   count = count +1;
iend

if not A/B == A/B + 1:
   count = count +1;
iend
#######################################################
######### square, square root, cube root, cube ########
#######################################################
if not sqr(E) == sqr(E) + 1:
   count = count +1;
iend

if not sqrt(R) == sqrt(R) + 1:
   count = count +1;
iend
if not cube(Q) == cube(Q) + 1:
   count = count +1;
iend
if not cbrt(S) == cbrt(S) + 1:
   count = count +1;
iend
#######################################################
######### power, factorial, quotient, reminder ########
#######################################################
if not E^5 == E^5 + 1:
   count = count +1;
iend
if not P! == P! + 1:
   count = count +1;
iend
if not P//D == P//D + 1:
   count = count +1;
iend
if not P%D == P%D + 1:
   count = count +1;
iend
#######################################################
############## log, exp, log with base  ###############
#######################################################
if not log(P) == log(P) + 1:
   count = count +1;
iend
if not logb3(Q) == logb3(Q) + 1:
   count = count +1;
iend
if not e^(P) == e^(P) + 1:
   count = count +1;
iend
if not |U| == |U| + 1:  
   count = count +1;
iend

publish("Loop-Primitiv Test : 'if not' on all : 16 tests:", count)
#######################################################
#######################################################