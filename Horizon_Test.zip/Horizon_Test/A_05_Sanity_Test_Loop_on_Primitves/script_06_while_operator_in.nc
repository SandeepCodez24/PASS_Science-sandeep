#######################################################
######## Loop-Primitive Header Test : 16 x 6 = 96 ########
#######################################################
# Each block: the primitive and comparison sit in the 'while' header.
# K is set so the header is TRUE on entry; the body resets K so the
# header is FALSE on the second check -> exactly one pass per loop.
# All operand values give exact results (no floating-point drift).
# A missing 'passed' line in the output = that combination failed.
#######################################################

passcount = 0;

#######################################################
# Primitive  1 : '+'   ->   (A+B) = 5
#######################################################
A = 2; B = 3;

K = 6;
while (A+B) < K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '+' and '<' ");
wend

K = 5;
while (A+B) <= K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '+' and '<=' ");
wend

K = 4;
while (A+B) > K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '+' and '>' ");
wend

K = 5;
while (A+B) >= K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '+' and '>=' ");
wend

K = 5;
while (A+B) == K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '+' and '==' ");
wend

K = 6;
while (A+B) != K:
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on '+' and '!=' ");
wend

#######################################################
# Primitive  2 : '-'   ->   (A-B) = 4
#######################################################
A = 7; B = 3;

K = 5;
while (A-B) < K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on '-' and '<' ");
wend

K = 4;
while (A-B) <= K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on '-' and '<=' ");
wend

K = 3;
while (A-B) > K:
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on '-' and '>' ");
wend

K = 4;
while (A-B) >= K:
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on '-' and '>=' ");
wend

K = 4;
while (A-B) == K:
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on '-' and '==' ");
wend

K = 5;
while (A-B) != K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '-' and '!=' ");
wend

#######################################################
# Primitive  3 : '*'   ->   (A*B) = 20
#######################################################
A = 4; B = 5;

K = 21;
while (A*B) < K:
   K = 19;
   passcount = passcount + 1;
   publish("test is passed on '*' and '<' ");
wend

K = 20;
while (A*B) <= K:
   K = 19;
   passcount = passcount + 1;
   publish("test is passed on '*' and '<=' ");
wend

K = 19;
while (A*B) > K:
   K = 21;
   passcount = passcount + 1;
   publish("test is passed on '*' and '>' ");
wend

K = 20;
while (A*B) >= K:
   K = 21;
   passcount = passcount + 1;
   publish("test is passed on '*' and '>=' ");
wend

K = 20;
while (A*B) == K:
   K = 21;
   passcount = passcount + 1;
   publish("test is passed on '*' and '==' ");
wend

K = 21;
while (A*B) != K:
   K = 20;
   passcount = passcount + 1;
   publish("test is passed on '*' and '!=' ");
wend

#######################################################
# Primitive  4 : '/'   ->   (A/B) = 5
#######################################################
A = 20; B = 4;

K = 6;
while (A/B) < K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '/' and '<' ");
wend

K = 5;
while (A/B) <= K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '/' and '<=' ");
wend

K = 4;
while (A/B) > K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '/' and '>' ");
wend

K = 5;
while (A/B) >= K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '/' and '>=' ");
wend

K = 5;
while (A/B) == K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '/' and '==' ");
wend

K = 6;
while (A/B) != K:
   K = 5;
   passcount = passcount + 1;
   publish("test is passed on '/' and '!=' ");
wend

#######################################################
# Primitive  5 : 'sqr'   ->   (sqr(E)) = 9
#######################################################
E = 3;

K = 10;
while (sqr(E)) < K:
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on 'sqr' and '<' ");
wend

K = 9;
while (sqr(E)) <= K:
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on 'sqr' and '<=' ");
wend

K = 8;
while (sqr(E)) > K:
   K = 10;
   passcount = passcount + 1;
   publish("test is passed on 'sqr' and '>' ");
wend

K = 9;
while (sqr(E)) >= K:
   K = 10;
   passcount = passcount + 1;
   publish("test is passed on 'sqr' and '>=' ");
wend

K = 9;
while (sqr(E)) == K:
   K = 10;
   passcount = passcount + 1;
   publish("test is passed on 'sqr' and '==' ");
wend

K = 10;
while (sqr(E)) != K:
   K = 9;
   passcount = passcount + 1;
   publish("test is passed on 'sqr' and '!=' ");
wend

#######################################################
# Primitive  6 : 'sqrt'   ->   (sqrt(R)) = 12
#######################################################
R = 144;

K = 13;
while (sqrt(R)) < K:
   K = 11;
   passcount = passcount + 1;
   publish("test is passed on 'sqrt' and '<' ");
wend

K = 12;
while (sqrt(R)) <= K:
   K = 11;
   passcount = passcount + 1;
   publish("test is passed on 'sqrt' and '<=' ");
wend

K = 11;
while (sqrt(R)) > K:
   K = 13;
   passcount = passcount + 1;
   publish("test is passed on 'sqrt' and '>' ");
wend

K = 12;
while (sqrt(R)) >= K:
   K = 13;
   passcount = passcount + 1;
   publish("test is passed on 'sqrt' and '>=' ");
wend

K = 12;
while (sqrt(R)) == K:
   K = 13;
   passcount = passcount + 1;
   publish("test is passed on 'sqrt' and '==' ");
wend

K = 13;
while (sqrt(R)) != K:
   K = 12;
   passcount = passcount + 1;
   publish("test is passed on 'sqrt' and '!=' ");
wend

#######################################################
# Primitive  7 : 'cube'   ->   (cube(Q)) = 27
#######################################################
Q = 3;

K = 28;
while (cube(Q)) < K:
   K = 26;
   passcount = passcount + 1;
   publish("test is passed on 'cube' and '<' ");
wend

K = 27;
while (cube(Q)) <= K:
   K = 26;
   passcount = passcount + 1;
   publish("test is passed on 'cube' and '<=' ");
wend

K = 26;
while (cube(Q)) > K:
   K = 28;
   passcount = passcount + 1;
   publish("test is passed on 'cube' and '>' ");
wend

K = 27;
while (cube(Q)) >= K:
   K = 28;
   passcount = passcount + 1;
   publish("test is passed on 'cube' and '>=' ");
wend

K = 27;
while (cube(Q)) == K:
   K = 28;
   passcount = passcount + 1;
   publish("test is passed on 'cube' and '==' ");
wend

K = 28;
while (cube(Q)) != K:
   K = 27;
   passcount = passcount + 1;
   publish("test is passed on 'cube' and '!=' ");
wend

#######################################################
# Primitive  8 : 'cbrt'   ->   (cbrt(S)) = 2
#######################################################
S = 8;

K = 3;
while (cbrt(S)) < K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'cbrt' and '<' ");
wend

K = 2;
while (cbrt(S)) <= K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'cbrt' and '<=' ");
wend

K = 1;
while (cbrt(S)) > K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'cbrt' and '>' ");
wend

K = 2;
while (cbrt(S)) >= K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'cbrt' and '>=' ");
wend

K = 2;
while (cbrt(S)) == K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on 'cbrt' and '==' ");
wend

K = 3;
while (cbrt(S)) != K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'cbrt' and '!=' ");
wend

#######################################################
# Primitive  9 : '^'   ->   (E^5) = 32
#######################################################
E = 2;

K = 33;
while (E^5) < K:
   K = 31;
   passcount = passcount + 1;
   publish("test is passed on '^' and '<' ");
wend

K = 32;
while (E^5) <= K:
   K = 31;
   passcount = passcount + 1;
   publish("test is passed on '^' and '<=' ");
wend

K = 31;
while (E^5) > K:
   K = 33;
   passcount = passcount + 1;
   publish("test is passed on '^' and '>' ");
wend

K = 32;
while (E^5) >= K:
   K = 33;
   passcount = passcount + 1;
   publish("test is passed on '^' and '>=' ");
wend

K = 32;
while (E^5) == K:
   K = 33;
   passcount = passcount + 1;
   publish("test is passed on '^' and '==' ");
wend

K = 33;
while (E^5) != K:
   K = 32;
   passcount = passcount + 1;
   publish("test is passed on '^' and '!=' ");
wend

#######################################################
# Primitive 10 : '!'   ->   (P!) = 24
#######################################################
P = 4;

K = 25;
while (P!) < K:
   K = 23;
   passcount = passcount + 1;
   publish("test is passed on '!' and '<' ");
wend

K = 24;
while (P!) <= K:
   K = 23;
   passcount = passcount + 1;
   publish("test is passed on '!' and '<=' ");
wend

K = 23;
while (P!) > K:
   K = 25;
   passcount = passcount + 1;
   publish("test is passed on '!' and '>' ");
wend

K = 24;
while (P!) >= K:
   K = 25;
   passcount = passcount + 1;
   publish("test is passed on '!' and '>=' ");
wend

K = 24;
while (P!) == K:
   K = 25;
   passcount = passcount + 1;
   publish("test is passed on '!' and '==' ");
wend

K = 25;
while (P!) != K:
   K = 24;
   passcount = passcount + 1;
   publish("test is passed on '!' and '!=' ");
wend

#######################################################
# Primitive 11 : '//'   ->   (P//D) = 3
#######################################################
P = 17; D = 5;

K = 4;
while (P//D) < K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on '//' and '<' ");
wend

K = 3;
while (P//D) <= K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on '//' and '<=' ");
wend

K = 2;
while (P//D) > K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '//' and '>' ");
wend

K = 3;
while (P//D) >= K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '//' and '>=' ");
wend

K = 3;
while (P//D) == K:
   K = 4;
   passcount = passcount + 1;
   publish("test is passed on '//' and '==' ");
wend

K = 4;
while (P//D) != K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on '//' and '!=' ");
wend

#######################################################
# Primitive 12 : '%'   ->   (P%D) = 2
#######################################################
P = 17; D = 5;

K = 3;
while (P%D) < K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on '%' and '<' ");
wend

K = 2;
while (P%D) <= K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on '%' and '<=' ");
wend

K = 1;
while (P%D) > K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on '%' and '>' ");
wend

K = 2;
while (P%D) >= K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on '%' and '>=' ");
wend

K = 2;
while (P%D) == K:
   K = 3;
   passcount = passcount + 1;
   publish("test is passed on '%' and '==' ");
wend

K = 3;
while (P%D) != K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on '%' and '!=' ");
wend

#######################################################
# Primitive 13 : 'log'   ->   (log(P)) = 0
#######################################################
P = 1;

K = 1;
while (log(P)) < K:
   K = -1;
   passcount = passcount + 1;
   publish("test is passed on 'log' and '<' ");
wend

K = 0;
while (log(P)) <= K:
   K = -1;
   passcount = passcount + 1;
   publish("test is passed on 'log' and '<=' ");
wend

K = -1;
while (log(P)) > K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'log' and '>' ");
wend

K = 0;
while (log(P)) >= K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'log' and '>=' ");
wend

K = 0;
while (log(P)) == K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'log' and '==' ");
wend

K = 1;
while (log(P)) != K:
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'log' and '!=' ");
wend

#######################################################
# Primitive 14 : 'logb3'   ->   (logb3(Q)) = 0
#######################################################
Q = 1;

K = 1;
while (logb3(Q)) < K:
   K = -1;
   passcount = passcount + 1;
   publish("test is passed on 'logb3' and '<' ");
wend

K = 0;
while (logb3(Q)) <= K:
   K = -1;
   passcount = passcount + 1;
   publish("test is passed on 'logb3' and '<=' ");
wend

K = -1;
while (logb3(Q)) > K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'logb3' and '>' ");
wend

K = 0;
while (logb3(Q)) >= K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'logb3' and '>=' ");
wend

K = 0;
while (logb3(Q)) == K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'logb3' and '==' ");
wend

K = 1;
while (logb3(Q)) != K:
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'logb3' and '!=' ");
wend

#######################################################
# Primitive 15 : 'e^'   ->   (e^(P)) = 1
#######################################################
P = 0;

K = 2;
while (e^(P)) < K:
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'e^' and '<' ");
wend

K = 1;
while (e^(P)) <= K:
   K = 0;
   passcount = passcount + 1;
   publish("test is passed on 'e^' and '<=' ");
wend

K = 0;
while (e^(P)) > K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'e^' and '>' ");
wend

K = 1;
while (e^(P)) >= K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'e^' and '>=' ");
wend

K = 1;
while (e^(P)) == K:
   K = 2;
   passcount = passcount + 1;
   publish("test is passed on 'e^' and '==' ");
wend

K = 2;
while (e^(P)) != K:
   K = 1;
   passcount = passcount + 1;
   publish("test is passed on 'e^' and '!=' ");
wend

#######################################################
# Primitive 16 : '| |'   ->   (|U|) = 7
#######################################################
U = -7;

K = 8;
while (|U|) < K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '| |' and '<' ");
wend

K = 7;
while (|U|) <= K:
   K = 6;
   passcount = passcount + 1;
   publish("test is passed on '| |' and '<=' ");
wend

K = 6;
while (|U|) > K:
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on '| |' and '>' ");
wend

K = 7;
while (|U|) >= K:
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on '| |' and '>=' ");
wend

K = 7;
while (|U|) == K:
   K = 8;
   passcount = passcount + 1;
   publish("test is passed on '| |' and '==' ");
wend

K = 8;
while (|U|) != K:
   K = 7;
   passcount = passcount + 1;
   publish("test is passed on '| |' and '!=' ");
wend

#######################################################
publish("Loop-Primitive Header Test : total passed out of 96 :", passcount);
######################################################################################
######################################################################################