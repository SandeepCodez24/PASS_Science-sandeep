#######################################################
################ variable Declaration #################
#######################################################
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
V = 1.1; W = 1.2; X=1.3; Y = 1.4; Z = 1.5; U = -6.9;
#######################################################
count = 0;
if A+B == B+A:
   count = count +1;
iend

if A-B == A-B:
   count = count +1;
iend

if A*B == B*A:
   count = count +1;
iend

if A/B == A/B:
   count = count +1;
iend
#######################################################
######### square, square root, cube root, cube ########
#######################################################
if sqr(E) == sqr(E):
   count = count +1;
iend

if sqrt(R) == sqrt(R):
   count = count +1;
iend
if cube(Q) == cube(Q):
   count = count +1;
iend
if cbrt(S) == cbrt(S):
   count = count +1;
iend
#######################################################
######### power, factorial, quotient, reminder ########
#######################################################
if E^5 == E^5:
   count = count +1;
iend
if P! == P!:
   count = count +1;
iend
if P//D == P//D:
   count = count +1;
iend
if P%D == P%D:
   count = count +1;
iend
#######################################################
############## log, exp, log with base  ###############
#######################################################
if log(P) == log(P):
   count = count +1;
iend
if logb3(Q) == logb3(Q):
   count = count +1;
iend
if e^(P) ==e^(P):
   count = count +1;
iend
if |U| == |U|:
   count = count +1;
iend

publish("Loop-Primitiv Test : 'if' on all : 16 tests:", count)
#######################################################
#######################################################

if |A-B| == |B-A|:
   count = count +1;
iend 