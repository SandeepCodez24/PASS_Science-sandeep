#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = (A-B)+(C-D);
A2 = (A-B)-(C-D);
A3 = (A-B)*(C-D);
A4 = (A-B)/(C-D);
A5 = sqrt(E-A);
A6 = cbrt(A-D);
A7 = sqr(A-B);
A8 = cube(A-B);
A9 = (A-B)^(C-D);
\\ A10 = (P-Q)!;   ## cpp error
A11 = (A-R)//(A-P); 
A12 = (A-R)%(A-P); 
A13 = log(P-A);
A14 = e^(A-B);
A15 = logb4(P-A); 
A16 = frac2deci(A-P/(A-R));
A17 = deci2frac(0.019825 - 0.4); 
#########################################################
#########################################################
publish("Addition             :", (A-B)+(C-D)==A1);
publish("Subtraction          :", (A-B)-(C-D)==A2);
publish("Multiplication       :", (A-B)*(C-D)==A3);
publish("Division             :", (A-B)/(C-D)==A4);
publish("Square Root          :", sqrt(E-A)==A5);
publish("Cube Root            :", cbrt(A-D)==A6);
publish("Square               :", sqr(A-B)==A7);
publish("Cube                 :", cube(A-B)==A8);
\\ publish("Power :", (A-B)^D==A9);   ## UI Error --> A^B is not working, needs to fixing this. working for numerical onyl (in power values)
\\ publish("Factorial :", (P-Q)!==A8); ## back end error 
publish("Quotient Division    :", (A-R)//(A-P)==A11);
publish("Remainder            :", (A-R)%(A-P)==A12);
publish("Natural Logarithm    :", log(P-A)==A13);
\\publish("Exponential :", e^(A-B)==A14);    ## UI Error --> A^B is not working, needs to fixing this. working for numerical onyl (in power values)
publish("Logarithm Base       :", logb4(P-A)==A15);
publish("Fraction to Decimal  :", frac2deci(A-P/(A-R))==A16);
publish("Decimal to Fraction  :", deci2frac(0.019825 - 0.4)==A17);  
#######################################################
#######################################################
