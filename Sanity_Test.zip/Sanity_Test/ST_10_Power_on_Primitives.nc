#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2;C=3;D=4;E=5; F = 36;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = B^(B+D);
A2 = D^(D-A);
A3 = B^(B*D);
A4 = B^(B/D);
A5 = B^sqrt(F);
A6 = B^cbrt(F);
A7 = B^sqr(F);
A8 = B^cube(F);
A9 = D^(B^2);
\\ A10 = B^((P/Q)!);
A11 = B^(F//B); 
A12 = B^(F%B); 
A13 = B^(log(B));
A14 = B^(e^C);
A15 = B^(logb4(A)); 
A16 = B^frac2deci(P/R);
A17 = B^deci2frac(0.019825 / 0.4);    ## cpp error
#########################################################
#########################################################
publish("Addition             :", B^(B+D)==A1);
publish("Subtraction          :", D^(D-A)==A2);
publish("Multiplication       :", B^(B*D)==A3);
publish("Division             :", B^(B/D)==A4);
publish("Square Root          :", B^sqrt(F)==A5);
publish("Cube Root            :", B^cbrt(F)==A6);
publish("Square               :", B^sqr(F)==A7);
publish("Cube                 :", B^cube(F)==A8);
publish("Power                :", D^(B^2)==A9);    
\\ publish("Factorial :", B^((P/Q)!)==A10); ## back end error 
publish("Quotient             :", B^(F//B)==A11);
publish("Remainder            :", B^(F%B)==A12);
publish("Natural Logarithm    :", B^(log(B))==A13);
publish("Exponential          :", B^(e^C)==A14);     
publish("Logarithm Base       :", B^(logb4(A))==A15);
publish("Fraction to Decimal  :", B^frac2deci(P/R)==A16);
publish("Decimal to Fraction  :", B^deci2frac(0.019825 / 0.4)==A17);  ## cpp error
#######################################################
#######################################################