#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2;C=3;D=4;E=5; F = 36;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = B!+D!;  ## cpp error
A2 = D!-A!;  ## cpp error
A3 = B!*D!;  ## cpp error
A4 = D!/B!;  ## cpp error
A5 = sqrt(F!);  ## cpp error
A6 = cbrt(F!);  ## cpp error
A7 = sqr(C!);   ## cpp error
A8 = cube(B!);  ## cpp error
A9 = B^(B!);    ## cpp error
\\ A10 = (P!)!;   ## cpp error
A11 = (F!)//(B!);  ## cpp error
A12 = (F!)%(B!);   ## cpp error
A13 = log(D!); ## error
A14 = e^(C!);   ## cpp error
A15 = logb4(F!);   ## cpp error
A16 = frac2deci(P/R)!;   ## cpp error
A17 = deci2frac(0.019825 / 0.4)!;    ## cpp error
#########################################################
#########################################################
publish("Addition             :", B!+D!==A1);
publish("Subtraction          :", D!-A!==A2);
publish("Multiplication       :", B!*D!==A3);
publish("Division             :", D!/B!==A4);
publish("Square Root          :", sqrt(F!)==A5);
publish("Cube Root            :", cbrt(F!)==A6);
publish("Square               :", sqr(C!)==A7);
publish("Cube                 :", cube(B!)==A8);
publish("Power                :",  B^(B!)==A9);    
\\ publish("Factorial :", (P!)!==A10); ## back end error 
publish("Quotient             :", (F!)//(B!)==A11);
publish("Remainder            :", (F!)%(B!)==A12);
publish("Natural Logarithm    :", log(D!)==A13);
publish("Exponential          :", e^(C!)==A14);     
publish("Logarithm Base       :", logb4(F!)==A15);
publish("Fraction to Decimal  :", frac2deci(P/R)!==A16);
publish("Decimal to Fraction  :", deci2frac(0.019825 / 0.4)!==A17);  ## cpp error
#########################################################
#########################################################