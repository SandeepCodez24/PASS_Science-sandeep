#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = sqrt(B)+sqrt(D);
A2 = sqrt(S)-sqrt(D);
A3 = sqrt(S)*sqrt(D);
A4 = sqrt(S)/sqrt(D);
A5 = sqrt(sqrt(S));
A6 = cbrt(sqrt(S));
A7 = sqr(sqrt(A));
A8 = cube(sqrt(A));
A9 = sqrt(A)^sqrt(B);
\\ A10 = (sqrt(P)/sqrt(Q))!;
A11 = sqrt(R)//sqrt(P);
A12 = sqrt(R)%sqrt(P); 
A13 = log(sqrt(D)); 
A14 = e^sqrt(A); 
A15 = logb4(sqrt(A)); 
A16 = frac2deci(sqrt(P)/sqrt(R));
A17 = deci2frac(sqrt(0.019825) / sqrt(0.4));    ## cpp error
#########################################################
#########################################################
publish("Addition            :", sqrt(B)+sqrt(D)==A1);
publish("Subtraction         :", sqrt(S)-sqrt(D)==A2);
publish("Multiplication      :", sqrt(S)*sqrt(D)==A3);
publish("Division            :", sqrt(S)/sqrt(D)==A4);
publish("Sqrt                :", sqrt(sqrt(S))==A5);
publish("Cbrt                :", cbrt(sqrt(S))==A6);
publish("Square              :", sqr(sqrt(A))==A7);
publish("Cube                :", cube(sqrt(A))==A8);
publish("Power               :", sqrt(A)^sqrt(B)==A9);  
\\ publish("Factorial         :", (sqrt(P)/sqrt(Q))!==A10); ## back end error 
publish("Quotient            :", sqrt(R)//sqrt(P)==A11);
publish("Remainder           :", sqrt(R)%sqrt(P)==A12);
publish("Natural Logarithm   :", log(sqrt(D))==A13);
publish("Exponential         :", e^sqrt(A)==A14);   
publish("Logarithm Base      :", logb4(sqrt(A))==A15);
publish("Fraction to Decimal :", frac2deci(sqrt(P)/sqrt(R))==A16);
publish("Decimal to Fraction :", deci2frac(sqrt(0.019825) / sqrt(0.4))==A17);  ## cpp error
#######################################################
#######################################################