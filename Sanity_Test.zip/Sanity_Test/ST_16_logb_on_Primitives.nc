#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
V = 1.1; W = 1.2; X=1.3; Y = 1.4; Z = 1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = logb4(B)+logb4(D);
A2 = logb4(S)-logb4(D);
A3 = logb4(S)*logb4(D);
A4 = logb4(S)/logb4(D);
A5 = sqrt(logb4(S));
A6 = cbrt(logb4(S));
A7 = sqr(logb4(A));
A8 = cube(logb4(A));
A9 = B^logb4(B);
\\A10 = logb4(P)!;
A11 = logb4(R)//logb4(P); 
A12 = logb4(R)%logb4(P); 
A13 = log(logb4(D)); 
A14 = e^logb4(A); 
A15 = logb4(logb4(A)); 
A16 = frac2deci(logb4(P)/logb4(R));
A17 = deci2frac(logb4(0.019825) / logb4(0.4));
#########################################################
#########################################################
publish("Addition               :", logb4(B)+logb4(D)==A1);
publish("Subtraction            :", logb4(S)-logb4(D)==A2);
publish("Multiplication         :", logb4(S)*logb4(D)==A3);
publish("Division               :", logb4(S)/logb4(D)==A4);
publish("Square Root            :", sqrt(logb4(S))==A5);
publish("Cube Root              :", cbrt(logb4(S))==A6);
publish("Square                 :", sqr(logb4(A))==A7);
publish("Cube                   :", cube(logb4(A))==A8);
publish("Power                  :", B^logb4(B)==A9);     
\\ publish("Factorial            :", logb4(P)!==A10); ## back end error 
publish("Quotient               :", logb4(R)//logb4(P)==A11);
publish("Remainder              :", logb4(R)%logb4(P)==A12);
publish("Natural Logarithm      :", log(logb4(D))==A13);
publish("Exponential            :", e^logb4(A)==A14);      
publish("Logarithm Base         :", logb4(logb4(A))==A15);
publish("Fraction to Decimal    :", frac2deci(logb4(P)/logb4(R))==A16);
publish("Decimal to Fraction    :", deci2frac(logb4(0.019825)/logb4(0.4))==A17);  ## cpp error
#######################################################
#######################################################