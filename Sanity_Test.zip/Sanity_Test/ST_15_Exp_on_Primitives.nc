#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = e^(B)+e^(D);
A2 = e^(B)-e^(D);
A3 = e^(B)*e^(D);
A4 = e^(B)/e^(D);
A5 = sqrt(e^(S));
A6 = cbrt(e^(S));
A7 = sqr(e^(A));
A8 = cube(e^(A));
A9 = A^e^(B);
\\ A10 = (e^(Q))!;
A11 = e^(R)//e^(R); 
A12 = e^(R)%e^(R); 
A13 = log(e^(D)); 
A14 = e^(e^A); 
A15 = logb4(e^(A)); 
A16 = frac2deci(e^(P)/e^(R));
A17 = deci2frac(e^(0.019825) / e^(0.4));    ## cpp error
#########################################################
#########################################################
publish("Addition               :", e^(B)+e^(D)==A1);
publish("Subtraction            :", e^(B)-e^(D)==A2);
publish("Multiplication         :", e^(B)*e^(D)==A3);
publish("Division               :", e^(B)/e^(D)==A4);
publish("Square Root            :", sqrt(e^(S))==A5);
publish("Cube Root              :", cbrt(e^(S))==A6);
publish("Square                 :", sqr(e^(A))==A7);
publish("Cube                   :", cube(e^(A))==A8);
publish("Power                  :", A^e^(B)==A9);    
\\ publish("Factorial :", (e^(Q))!==A10); ## back end error 
publish("Quotient               :", e^(R)//e^(R)==A11);
publish("Remainder              :", e^(R)%e^(R)==A12);
publish("Natural Logarithm      :", log(e^(D))==A13);
publish("Exponential            :", e^(e^A)==A14);      
publish("Logarithm Base         :", logb4(e^(A))==A15);
publish("Fraction to Decimal    :", frac2deci(e^(P)/e^(R))==A16);
publish("Decimal to Fraction    :", deci2frac(e^(0.019825) / e^(0.4))==A17);  ## cpp error
#######################################################
#######################################################