#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = sqr(B)+sqr(D);
A2 = sqr(S)-sqr(D);
A3 = sqr(S)*sqr(D);
A4 = sqr(S)/sqr(D);
A5 = sqrt(sqr(S));
A6 = cbrt(sqr(S));
A7 = sqr(sqr(A));
A8 = cube(sqr(A));
A9 = A^sqr(B);
\\ A10 = sqr(P)/sqr(Q))!;
A11 = sqr(R)//sqr(P); 
A12 = sqr(R)%sqr(P); 
A13 = log(sqr(D)); 
A14 = e^sqr(A); 
A15 = logb4(sqr(A)); 
A16 = frac2deci(sqr(P/R));
A17 = deci2frac(sqr(0.019825 / 0.4));    ## cpp error
#########################################################
#########################################################
publish("Addition                 :", sqr(B)+sqr(D)==A1);
publish("Subtraction              :", sqr(S)-sqr(D)==A2);
publish("Multiplication           :", sqr(S)*sqr(D)==A3);
publish("Division                 :", sqr(S)/sqr(D)==A4);
publish("Square Root              :", sqrt(sqr(S))==A5);
publish("Cube Root                :", cbrt(sqr(S))==A6);
publish("Square                   :",  sqr(sqr(A))==A7);
publish("Cube                     :", cube(sqr(A))==A8);
publish("Power                    :", A^sqr(B)==A9);     
\\publish("Factorial                :", (sqr(P)/sqr(Q))!)==A10); ## back end error 
publish("Quotient                 :",sqr(R)//sqr(P)==A11);
publish("Remainder                :", sqr(R)%sqr(P)==A12);
publish("Natural Logarithm        :", log(sqr(D))==A13);
publish("Exponential              :",  e^sqr(A)==A14);     
publish("Logarithm Base           :", logb4(sqr(A))==A15);
publish("Fraction to Decimal      :",  frac2deci(sqr(P/R))==A16);
publish("Decimal to Fraction      :", deci2frac(sqr(0.019825 / 0.4))==A17);  ## cpp error
#######################################################
#######################################################