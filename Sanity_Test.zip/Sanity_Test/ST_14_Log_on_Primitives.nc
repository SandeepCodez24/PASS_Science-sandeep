#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
V = 1.1; W = 1.2; X=1.3; Y = 1.4; Z = 1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = log(B)+log(D);
A2 = log(S)-log(D);
A3 = log(S)*log(D);
A4 = log(S)/log(D);
A5 = sqrt(log(S));
A6 = cbrt(log(S));
A7 = sqr(log(A));
A8 = cube(log(A));
A9 = B^log(B);
\\A10 = (log(P))!;
A11 = log(R)//log(P); 
A12 = log(R)%log(P); 
A13 = log(log(D)); 
A14 = e^log(A); 
A15 = logb4(log(A)); 
A16 = frac2deci(log(P)/log(R));
A17 = deci2frac(log(0.019825) / log(0.4));
#########################################################
#########################################################
publish("Addition              :", log(B)+log(D)==A1);
publish("Subtraction           :", log(S)-log(D)==A2);
publish("Multiplication        :", log(S)*log(D)==A3);
publish("Division              :", log(S)/log(D)==A4);
publish("Square Root           :", sqrt(log(S))==A5);
publish("Cube Root             :", cbrt(log(S))==A6);
publish("Square                :", sqr(log(A))==A7);
publish("Cube                  :", cube(log(A))==A8);
publish("Power                 :", B^log(B)==A9);    
\\publish("Factorial           :", log(P)!==A10); ## back end error 
publish("Quotient              :", log(R)//log(P)==A11);
publish("Remainder             :", log(R)%log(P)==A12);
publish("Natural Logarithm     :", log(log(D))==A13);
publish("Exponential           :", e^log(A)==A14);      
publish("Logarithm Base        :", logb4(log(A))==A15);
publish("Fraction to Decimal   :", frac2deci(log(P)/log(R))==A16);
publish("Decimal to Fraction   :", deci2frac(log(0.019825) / log(0.4))==A17);  ## cpp error
#######################################################
#######################################################