#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2.023;C=3;D=4;E=5.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = deci2frac(B/E)+deci2frac(B/D);
A2 = deci2frac(B/E)-deci2frac(B/D);
A3 = deci2frac(B/E)*deci2frac(B/D);
A4 = deci2frac(B/E)/deci2frac(B/D);
A5 = sqrt(deci2frac(B/E));
A6 = cbrt(deci2frac(B/E));
A7 = sqr(deci2frac(B/E));
A8 = cube(deci2frac(B/E));
A9 = D^deci2frac(B/E);
\\A10 = deci2frac(B/E)!;
A11 = deci2frac(B/E)//deci2frac(B/E); 
A12 = deci2frac(B/E)%deci2frac(B/E); 
A13 = log(deci2frac(B/E)); 
A14 = e^deci2frac(B/E); 
A15 = logb4(deci2frac(B/E)); 
A16 = deci2frac(deci2frac(B/E));
A17 = deci2frac(deci2frac(B/E));
#########################################################
#########################################################
publish("Addition                   :", deci2frac(B/E)+deci2frac(B/E)==A1);
publish("Subtraction                :", deci2frac(B/E)-deci2frac(B/E)==A2);
publish("Multiplication             :", deci2frac(B/E)*deci2frac(B/E)==A3);
publish("Division                   :", deci2frac(B/E)/deci2frac(B/E)==A4);
publish("Square Root                :", sqrt(deci2frac(B/E))==A5);
publish("Cube Root                  :", cbrt(deci2frac(B/E))==A6);
publish("Square                     :", sqr(deci2frac(B/E))==A7);
publish("Cube                       :", cube(deci2frac(B/E))==A8);
publish("Power                      :", D^deci2frac(B/E)==A9);    
\\publish("Factorial                :",deci2frac(B/E)!==A10); ## back end error 
publish("Quotient                   :", deci2frac(B/E)//deci2frac(B/E)==A11);
publish("Remainder                  :", deci2frac(B/E)%deci2frac(B/E)==A12);
publish("Natural Logarithm          :", log(deci2frac(B/E))==A13);
publish("Exponential                :", e^deci2frac(B/E)==A14);      ## UI Error 
publish("Logarithm Base 4           :", logb4(deci2frac(B/E))==A15);
publish("Fraction to Decimal        :", frac2deci(deci2frac(B/E))==A16);
publish("Decimal to Fraction        :", deci2frac(deci2frac(B/E))==A17);  ## cpp error
#######################################################
#######################################################