#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2;C=3;D=4;E=5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = (D%B)+(E%B);
A2 = (T%B)-(R%B);
A3 = (T%B)*(R%B);
A4 = (T%B)/(R%B);
A5 = sqrt(S%P);
A6 = cbrt(S%P);
A7 = sqr(S%P);
A8 = cube(S%P);
A9 = B^(S%P);
\\ A10 = (S%P)!;
A11 = (R%B)//(P%C);
A12 = (R%B)%(P%C); 
A13 = log(R%B); 
A14 = e^(R%B); 
A15 = logb4(R%B); 
A16 = frac2deci((R%B)/(R%Q));
A17 = deci2frac((R%B)/(R%B));     ## cpp error
#########################################################
#########################################################
publish("Addition            :", (D%B)+(E%B)==A1);
publish("Subtraction         :", (T%B)-(R%B)==A2);
publish("Multiplication      :", (T%B)*(R%B)==A3);
publish("Division            :", (T%B)/(R%B)==A4);
publish("Square Root         :", sqrt(S%P)==A5);
publish("Cube Root           :", cbrt(S%P)==A6);
publish("Square              :", sqr(S%P)==A7);
publish("Cube                :", cube(S%P)==A8);
publish("Power               :", B^(S%P)==A9);    
\\publish("Factorial         :", (S%P)!==A10); ## back end error 
publish("Quotient            :", (R%B)//(P%C)==A11);
publish("Remainder           :", (R%B)%(P%C)==A12);
publish("Natural Logarithm   :",  log(R%B)==A13);
publish("Exponential         :", e^(R%B)==A14);    
publish("Logarithm Base      :", logb4(R%B)==A15);
publish("Fraction to Decimal :", frac2deci((R%B)/(R%Q))==A16);
publish("Decimal to Fraction :", deci2frac((R%B)/(R%B))==A17);  ## cpp error
#######################################################
#######################################################