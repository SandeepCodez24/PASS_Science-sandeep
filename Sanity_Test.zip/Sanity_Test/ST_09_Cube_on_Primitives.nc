#########################################################
#########################################################
publish("The test is for primitives on Primitives")
publish("########################################")
A=1.1;B=1.2;C=1.3;D=1.45;E=1.5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = cube(B)+cube(D);
A2 = cube(S)-cube(D);
A3 = cube(S)*cube(D);
A4 = cube(S)/cube(D);
A5 = sqrt(cube(S));
A6 = cbrt(cube(S));
A7 = sqr(cube(A));
A8 = cube(cube(A));
A9 = A^cube(B);
\\ A10 = (cube(P)/cube(Q))!);
A11 = cube(R)//cube(P); 
A12 = cube(R)%cube(P); 
A13 = log(cube(D)); 
A14 = e^cube(A); 
A15 = logb4(cube(A)); 
A16 = frac2deci(cube(P)/cube(R));
A17 = deci2frac(cube(0.019825) / cube(0.4));    ## cpp error
#########################################################
#########################################################
publish("Addition              :", cube(B)+cube(D)==A1);
publish("Subtraction           :", cube(S)-cube(D)==A2);
publish("Multiplication        :", cube(S)*cube(D)==A3);
publish("Division              :", cube(S)/cube(D)==A4);
publish("Square Root           :", sqrt(cube(S))==A5);
publish("Cube Root             :", cbrt(cube(S))==A6);
publish("Square                :", sqr(cube(A))==A7);
publish("Cube                  :", cube(cube(A))==A8);
publish("Power                 :",  A^cube(B)==A9);    
\\ publish("Factorial           :", (cube(P)/cube(Q))!)==A10); ## back end error 
publish("Quotient              :", cube(R)//cube(P)==A11);
publish("Remainder             :", cube(R)%cube(P)==A12);
publish("Natural Logarithm     :", log(cube(D))==A13);
publish("Exponential           :", e^cube(A)==A14);      
publish("Logarithm Base        :", logb4(cube(A))==A15);
publish("Fraction to Decimal   :", frac2deci(cube(P)/cube(R))==A16);
publish("Decimal to Fraction   :", deci2frac(cube(0.019825) / cube(0.4))==A17);  ## cpp error
#######################################################
#######################################################