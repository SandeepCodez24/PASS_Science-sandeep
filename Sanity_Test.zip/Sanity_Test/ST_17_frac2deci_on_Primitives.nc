#########################################################
#########################################################
publish("########################################")
publish("The test is for primitives on Primitives")
publish("########################################")
A=1;B=2;C=3;D=4;E=5;
P = 4.4; Q = 9.9; R = 144.144; S = 343.343; T = 516.516;
#########################################################
#########################################################
A1 = frac2deci(B/E)+frac2deci(B/D);
A2 = frac2deci(B/E)-frac2deci(B/D);
A3 = frac2deci(B/E)*frac2deci(B/D);
A4 = frac2deci(B/E)/frac2deci(B/D);
A5 = sqrt(frac2deci(B/E));
A6 = cbrt(frac2deci(B/E));
A7 = sqr(frac2deci(B/E));
A8 = cube(frac2deci(B/E));
A9 = B^frac2deci(B/E);
\\A10 = frac2deci(B/E)!;
A11 = frac2deci(B/E)//frac2deci(B/E); 
A12 = frac2deci(B/E)%frac2deci(B/E); 
A13 = log(frac2deci(B/E)); 
A14 = e^frac2deci(B/E); 
A15 = logb4(frac2deci(B/E)); 
A16 = frac2deci(frac2deci(B/E)/frac2deci(B/D));
A17 = deci2frac(frac2deci(B/E));
#########################################################
#########################################################
publish("Addition                :", frac2deci(B/E)+frac2deci(B/D)==A1);
publish("Subtraction             :", frac2deci(B/E)-frac2deci(B/D)==A2);
publish("Multiplication          :", frac2deci(B/E)*frac2deci(B/D)==A3);
publish("Division                :", frac2deci(B/E)/frac2deci(B/D)==A4);
publish("Square Root             :", sqrt(frac2deci(B/E))==A5);
publish("Cube Root               :", cbrt(frac2deci(B/E))==A6);
publish("Square                  :", sqr(frac2deci(B/E))==A7);
publish("Cube                    :", cube(frac2deci(B/E))==A8);
publish("Power                   :", B^frac2deci(B/E)==A9);  
\\ publish("Factorial               :",frac2deci(B/E)!==A10); ## back end error 
publish("Quotient                :", frac2deci(B/E)//frac2deci(B/E)==A11);
publish("Remainder               :", frac2deci(B/E)%frac2deci(B/E)==A12);
publish("Natural Logarithm       :", log(frac2deci(B/E))==A13);
publish("Exponential             :", e^frac2deci(B/E)==A14);      
publish("Logarithm Base          :", logb4(frac2deci(B/E))==A15);
publish("Fraction to Decimal     :", frac2deci(frac2deci(B/E)/frac2deci(B/D))==A16);
publish("Decimal to Fraction     :", deci2frac(frac2deci(B/E))==A17);  ## cpp error
#######################################################
#######################################################