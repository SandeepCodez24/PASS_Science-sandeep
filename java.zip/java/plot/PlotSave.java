package plot;

import java.io.File;
import java.util.function.Consumer;

import javax.swing.filechooser.FileSystemView;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * Embedded Save configuration panel (HORIZONTAL UI).
 */
public class PlotSave {

    private final Stage owner;
    private final String defaultFormat;
    private final int defaultDpi;

    public PlotSave(Stage owner) {
        this(owner, "jpeg", 300);
    }

    public PlotSave(Stage owner, String defaultFormat, int defaultDpi) {
        this.owner = owner;
        this.defaultFormat = defaultFormat;
        this.defaultDpi = defaultDpi;
    }

    public static class SaveParams {

        public final String format;
        public final int dpi;
        public final File targetFile;

        public SaveParams(String format, int dpi, File targetFile) {
            String safeFormat = format;
            if (safeFormat == null || safeFormat.isBlank()) {
                safeFormat = "jpg";
            } else {
                safeFormat = safeFormat.toLowerCase().trim();
            }
            this.format = safeFormat;
            this.dpi = dpi > 0 ? dpi : 300;
            this.targetFile = targetFile;
        }
    }

    public VBox build(Consumer<SaveParams> callback, Runnable onDismiss) {
        final String panelStyle = """
                -fx-background-color:#0aa6a6;
                -fx-background-radius:14;
                -fx-border-radius:14;
                -fx-border-color:#088b8b;
                -fx-border-width:1;
                """;

        final String headingStyle = """
                -fx-font-size:18px;
                -fx-font-weight:bold;
                -fx-text-fill:white;
                """;

        final String labelStyle = "-fx-text-fill:white; -fx-font-size:13px;";
        final String fieldStyle = "-fx-background-color:#f2f2f2; -fx-background-radius:4; -fx-border-radius:4;";
        final String actionStyle = "-fx-background-color:#efefef; -fx-background-radius:4; -fx-border-radius:4;";

        Label title = new Label("Save Configuration");
        title.setStyle(headingStyle);

        Label formatLabel = new Label("Format:");
        formatLabel.setStyle(labelStyle);
        ComboBox<String> format = new ComboBox<>();
        format.getItems().addAll("jpg", "jpeg", "png", "tiff", "gif");
        format.setValue(defaultFormat);
        format.setPrefWidth(145);
        format.setStyle(fieldStyle);
        VBox formatBox = new VBox(4, formatLabel, format);

        Label dpiLabel = new Label("DPI:");
        dpiLabel.setStyle(labelStyle);
        ComboBox<Integer> dpi = new ComboBox<>();
        dpi.getItems().addAll(72, 150, 300, 600);
        dpi.setValue(defaultDpi);
        dpi.setPrefWidth(110);
        dpi.setStyle(fieldStyle);
        VBox dpiBox = new VBox(4, dpiLabel, dpi);

        Label dirLabel = new Label("Location:");
        dirLabel.setStyle(labelStyle);
        File defaultFile = getDefaultSaveFile(defaultFormat);
        TextField dirField = new TextField(defaultFile.getAbsolutePath());
        dirField.setPromptText(defaultFile.getAbsolutePath());
        dirField.setEditable(true);
        dirField.setPrefWidth(270);
        dirField.setMaxWidth(Double.MAX_VALUE);
        dirField.setStyle(fieldStyle);

        format.valueProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue != null && !newValue.isBlank()) {
                updatePathExtension(dirField, newValue);
            }
        });

        Button browseBtn = new Button("Browse");
        browseBtn.setStyle(actionStyle);
        browseBtn.setPrefWidth(64);
        browseBtn.setOnAction(e -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Select save location");
            File initialDirectory = defaultFile.getParentFile();
            if (initialDirectory != null && initialDirectory.exists()) {
                chooser.setInitialDirectory(initialDirectory);
            }
            chooser.setInitialFileName(defaultFile.getName());
            File chosen = chooser.showSaveDialog(owner);
            if (chosen != null) {
                dirField.setText(ensureExtension(chosen, format.getValue()).getAbsolutePath());
            }
        });

        HBox dirControl = new HBox(8, dirField, browseBtn);
        dirControl.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(dirField, Priority.ALWAYS);
        VBox dirBox = new VBox(4, dirLabel, dirControl);

        HBox rowContainer = new HBox(18);
        rowContainer.setAlignment(Pos.CENTER_LEFT);
        rowContainer.setFillHeight(true);
        rowContainer.setMaxWidth(Double.MAX_VALUE);
        rowContainer.getChildren().addAll(formatBox, dpiBox, dirBox);
        HBox.setHgrow(dirBox, Priority.ALWAYS);

        Button saveBtn = new Button("Save");
        Button cancelBtn = new Button("Cancel");
        saveBtn.setPrefWidth(80);
        cancelBtn.setPrefWidth(80);
        saveBtn.setStyle(actionStyle);
        cancelBtn.setStyle(actionStyle);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox buttons = new HBox(10, spacer, saveBtn, cancelBtn);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox content = new VBox(15);
        content.setPadding(new Insets(18, 18, 16, 18));
        content.setMaxWidth(Double.MAX_VALUE);
        content.setStyle(panelStyle);
        content.getChildren().addAll(title, rowContainer, buttons);

        saveBtn.setOnAction(e -> {
            String fmt = format.getValue();
            Integer dpiVal = dpi.getValue();

            File targetFile = null;
            if (dirField.getText() != null && !dirField.getText().isBlank()) {
                targetFile = ensureExtension(new File(dirField.getText()), fmt);
            }

            if (callback != null && fmt != null && dpiVal != null) {
                callback.accept(new SaveParams(fmt, dpiVal, targetFile));
            }

            if (onDismiss != null) {
                onDismiss.run();
            }
        });

        cancelBtn.setOnAction(e -> {
            if (onDismiss != null) {
                onDismiss.run();
            }
        });

        return content;
    }

    private File getDefaultSaveFile(String format) {
        File folder = getDefaultDirectory();
        String safeFormat = format == null || format.isBlank() ? "jpeg" : format.toLowerCase();
        return new File(folder, "untitled-01." + safeFormat);
    }

    private File getDefaultDirectory() {
        String userHome = System.getProperty("user.home");
        File desktop = new File(userHome, "Desktop");
        if (desktop.exists() && desktop.isDirectory()) {
            return desktop;
        }

        File swingHome = FileSystemView.getFileSystemView().getHomeDirectory();
        if (swingHome != null && swingHome.exists() && swingHome.isDirectory()) {
            return swingHome;
        }

        File userHomeDir = userHome != null ? new File(userHome) : new File(".");
        return (userHomeDir.exists() && userHomeDir.isDirectory()) ? userHomeDir : new File(".");
    }

    private void updatePathExtension(TextField field, String format) {
        String current = field.getText();
        if (current == null || current.isBlank()) {
            field.setText(getDefaultSaveFile(format).getAbsolutePath());
            return;
        }

        String safeFormat = format == null || format.isBlank() ? "jpg" : format.toLowerCase().trim();
        
        File file = new File(current);
        if (file.exists() && file.isDirectory()) {
            field.setText(new File(file, "untitled-01." + safeFormat).getAbsolutePath());
            return;
        }

        String name = file.getName();
        String parent = file.getParent();
        String baseName;
        if (name.contains(".")) {
            baseName = name.substring(0, name.lastIndexOf('.'));
        } else {
            baseName = name;
        }
        File updated = parent == null
            ? new File(baseName + "." + safeFormat)
            : new File(parent, baseName + "." + safeFormat);
        field.setText(updated.getAbsolutePath());
    }

    private File ensureExtension(File file, String format) {
        String safeFormat = format == null || format.isBlank() ? "jpg" : format.toLowerCase().trim();
        if (file.exists() && file.isDirectory()) {
            return new File(file, "untitled-01." + safeFormat);
        }
        String name = file.getName();
        String parent = file.getParent();
        if (!name.contains(".")) {
            return parent == null ? new File(name + "." + safeFormat) : new File(parent, name + "." + safeFormat);
        }
        String baseName = name.substring(0, name.lastIndexOf('.'));
        return parent == null ? new File(baseName + "." + safeFormat) : new File(parent, baseName + "." + safeFormat);
    }
}
