package plot;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import ui.UI_Main;
import ui.settings.connector_cpp.UPIPoint;
import ui.settings.connector_cpp.UPIVariable;

/**
 * Handles chart operations: drawing plots, applying colors, saving images.
 */
public class PlotChartOperations {

    private static final Color BRIGHT_BAR_COLOR = Color.web("#0aa6a6");

    /** {@code plot(x, y)} -- two variable names. */
    private static final Pattern PLOT_TWO_ARGS = Pattern.compile(
            "plot\\s*\\(\\s*([a-zA-Z_][a-zA-Z0-9_]*)\\s*,\\s*([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\)");

    /** {@code plot(y)} -- one variable name. */
    private static final Pattern PLOT_ONE_ARG = Pattern.compile(
            "plot\\s*\\(\\s*([a-zA-Z_][a-zA-Z0-9_]*)\\s*\\)");

    private final UI_Main controller;
    private final StackPane centerPane;
    private final Runnable liveBarHatchRefresh;
    private LineChart<Number, Number> chart;
    private NumberAxis xAxis;
    private NumberAxis yAxis;
    private File lastFolder;
    private int lastPreviewPointCount = 0;

    public PlotChartOperations(UI_Main controller, StackPane centerPane,
            LineChart<Number, Number> chart, NumberAxis xAxis,
            NumberAxis yAxis, File currentFolder,
            Runnable liveBarHatchRefresh) {
        this.controller = controller;
        this.centerPane = centerPane;
        this.liveBarHatchRefresh = liveBarHatchRefresh;
        this.chart = chart;
        this.xAxis = xAxis;
        this.yAxis = yAxis;
        this.lastFolder = currentFolder;
    }

    /**
     * Draws a single-variable plot.
     */
    public void drawVariablePlot(String name) {
        List<Double> values = controller.getVariableValues(name);
        if (values == null || values.isEmpty())
            return;

        chart.getData().clear();
        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName(name);

        for (int i = 0; i < values.size(); i++) {
            series.getData().add(new XYChart.Data<>(i, values.get(i)));
        }

        chart.getData().add(series);
        chart.setCreateSymbols(false);
        setCenterContent(chart);
    }

    /**
     * Draws a two-variable plot.
     */
    public void drawVariablePlot(String xName, String yName) {
        List<Double> xValues = controller.getVariableValues(xName);
        List<Double> yValues = controller.getVariableValues(yName);

        if (yValues == null || yValues.isEmpty())
            return;

        chart.getData().clear();
        XYChart.Series<Number, Number> series = new XYChart.Series<>();
        series.setName(yName);

        int size = yValues.size();
        if (xValues != null && !xValues.isEmpty()) {
            size = Math.min(size, xValues.size());
        }

        for (int i = 0; i < size; i++) {
            Double xRaw = (xValues != null && i < xValues.size()) ? xValues.get(i) : null;
            Double yRaw = yValues.get(i);
            double x = (xRaw != null) ? xRaw : i;
            double y = (yRaw != null) ? yRaw : 0.0;
            series.getData().add(new XYChart.Data<>(x, y));
        }

        chart.getData().add(series);
        chart.setCreateSymbols(false);
        setCenterContent(chart);
    }

    /**
     * Draws live points received from a UPI script with dynamic axis labels from code.
     */
    public void drawLivePoints(List<UPIPoint> points, String editorCode) {
        if (points == null || points.isEmpty()) {
            return;
        }

        chart.getData().clear();

        // Extract dynamic labels from plot() function call in editor code
        String[] plotVars = extractPlotVariablesFromCode(editorCode);
        if (plotVars != null && plotVars.length >= 1) {
            xAxis.setLabel(plotVars[0]);
            if (plotVars.length >= 2) {
                yAxis.setLabel(plotVars[1]);
            } else {
                yAxis.setLabel("Value");
            }
        } else {
            // Fallback to default labels if no plot() call found
            xAxis.setLabel("X");
            yAxis.setLabel("Y");
        }

        // Ensure axes are set to auto-range
        xAxis.setAutoRanging(true);
        yAxis.setAutoRanging(true);

        XYChart.Series<Number, Number> liveSeries = new XYChart.Series<>();
        liveSeries.setName("UPI Live Plot");

        for (UPIPoint point : points) {
            liveSeries.getData().add(new XYChart.Data<>(point.x(), point.y()));
        }

        chart.getData().add(liveSeries);
        chart.setCreateSymbols(false);
        setCenterContent(chart);

        chart.applyCss();
        chart.layout();

        // Style the line after layout, but defer to ensure node is ready
        javafx.application.Platform.runLater(() -> {
            if (liveSeries.getNode() != null) {
                javafx.scene.Node line = liveSeries.getNode().lookup(".chart-series-line");
                if (line != null) {
                    line.setStyle("-fx-stroke: #0aa6a6; -fx-stroke-width: 2.5;");
                }

                for (javafx.scene.Node symbol : liveSeries.getNode().lookupAll(".chart-line-symbol")) {
                    // keep small consistent symbol styling (use plot color directly here)
                    symbol.setStyle(
                            "-fx-background-color: #0aa6a6, white; -fx-background-insets: 0, 2; -fx-background-radius: 3px; -fx-padding: 2px;");
                }
            }
        });
    }

    /**
     * Draws live points received from a UPI script (fallback with default labels).
     */
    public void drawLivePoints(List<UPIPoint> points) {
        if (points == null || points.isEmpty()) {
            return;
        }

        chart.getData().clear();
        xAxis.setLabel("X");
        yAxis.setLabel("Y");

        // Ensure axes are set to auto-range
        xAxis.setAutoRanging(true);
        yAxis.setAutoRanging(true);

        XYChart.Series<Number, Number> liveSeries = new XYChart.Series<>();
        liveSeries.setName("UPI Live Plot");

        for (UPIPoint point : points) {
            liveSeries.getData().add(new XYChart.Data<>(point.x(), point.y()));
        }

        chart.getData().add(liveSeries);
        chart.setCreateSymbols(false);
        setCenterContent(chart);

        chart.applyCss();
        chart.layout();

        // Style the line after layout, but defer to ensure node is ready
        javafx.application.Platform.runLater(() -> {
            if (liveSeries.getNode() != null) {
                javafx.scene.Node line = liveSeries.getNode().lookup(".chart-series-line");
                if (line != null) {
                    line.setStyle("-fx-stroke: #0aa6a6; -fx-stroke-width: 2.5;");
                }

                for (javafx.scene.Node symbol : liveSeries.getNode().lookupAll(".chart-line-symbol")) {
                    // keep small consistent symbol styling (use plot color directly here)
                    symbol.setStyle(
                            "-fx-background-color: #0aa6a6, white; -fx-background-insets: 0, 2; -fx-background-radius: 3px; -fx-padding: 2px;");
                }
            }
        });
    }

    public void drawBarPoints(List<UPIPoint> points, List<UPIVariable> vars) {

        if (points == null || points.isEmpty())
            return;

        chart.getData().clear();

        CategoryAxis x = new CategoryAxis();
        NumberAxis y = new NumberAxis();

        BarChart<String, Number> barChart = new BarChart<>(x, y);
        barChart.setLegendVisible(false);
        barChart.setAnimated(false);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("UPI Bar Plot");

        for (UPIPoint p : points) {
            series.getData().add(
                    new XYChart.Data<>(
                            String.valueOf(p.x()),
                            p.y()));
        }

        barChart.getData().add(series);

        setCenterContent(barChart);

        Platform.runLater(() -> {
            applyBrightBarFill(barChart, BRIGHT_BAR_COLOR);
        });
    }

    /**
     * Draws a preview plot for a given plot type.
     */
    public void drawPreviewPlot(String type, String displayName) {
        // Special-case: render an AreaChart preview for 'area' types so the fill looks
        // correct
        if ("area".equals(type)) {
            NumberAxis aX = new NumberAxis();
            NumberAxis aY = new NumberAxis();
            aX.setLabel("Index");
            aY.setLabel("Value");

            AreaChart<Number, Number> area = new AreaChart<>(aX, aY);
            area.setLegendVisible(false);
            area.setAnimated(false);
            area.setCreateSymbols(false);
            area.setTitle(displayName + " Preview");
            area.setStyle("-fx-background-color: transparent;");

            XYChart.Series<Number, Number> preview = new XYChart.Series<>();
            for (int i = 0; i < 24; i++) {
                double y = previewValueForType(type, i);
                preview.getData().add(new XYChart.Data<>(i, y));
            }

            area.getData().add(preview);
            setCenterContent(area);

            // Style fill and outline after CSS/layout
            area.applyCss();
            area.layout();

            javafx.scene.Node fill = area.lookup(".chart-series-area-fill");
            if (fill != null) {
                fill.setStyle("-fx-fill: linear-gradient(to bottom, #12c8c8 0%, #0aa6a6 70%); -fx-opacity:0.95;");
            }

            javafx.scene.Node line = area.lookup(".chart-series-line");
            if (line != null) {
                line.setStyle("-fx-stroke: white; -fx-stroke-width: 2px;");
            }

            // ensure surrounding chart area is transparent so only the plot shows
            for (javafx.scene.Node plotBg : area.lookupAll(".chart-plot-background")) {
                plotBg.setStyle("-fx-background-color: transparent;");
            }

            return;
        }
        // Fallback: render preview into the main LineChart for non-area types
        if (chart != null) {
            chart.getData().clear();
            xAxis.setLabel("Index");
            yAxis.setLabel("Value");

            XYChart.Series<Number, Number> preview = new XYChart.Series<>();
            preview.setName(displayName + " Preview");
            for (int i = 0; i < 24; i++) {
                double y = previewValueForType(type, i);
                preview.getData().add(new XYChart.Data<>(i, y));
            }

            chart.getData().add(preview);
            chart.setCreateSymbols(false);
            setCenterContent(chart);
        }
    }

    /**
     * Generates preview value for a plot type at a given index.
     */
    private double previewValueForType(String type, int i) {
        return switch (type) {
            case "bar", "2dbar", "histogram", "errorbar" -> (i % 6) + 1;
            case "3dbar" -> (i % 6) + 2 + ((i % 3) * 0.6);
            case "scatter", "bubble", "violin", "boxplot" -> (Math.random() * 8) + 1;
            case "stairs", "stem" -> (i / 3) + 1;
            case "fill", "area", "stackplot" -> Math.abs(5 * Math.sin(i * 0.35)) + 1;
            case "innovationplot", "heatmap", "contour", "vectorfield" -> 4 + 3 * Math.sin(i * 0.45);
            default -> 4 + 3 * Math.sin(i * 0.3);
        };
    }

    /**
     * Changes the current chart type.
     */
    public void changeChartType(String type) {
        if ("bar".equals(type) || "2dbar".equals(type)) {
            showBarChartFromCurrentData();
            return;
        }
        if ("histogram".equals(type)) {
            showHistogramFromCurrentData();
            return;
        }
        // 3D bar currently falls back to 2D bar rendering in preview and chart area
        if ("3dbar".equals(type)) {
            showBarChartFromCurrentData();
            return;
        }
        if ("area".equals(type)) {
            showAreaChartFromCurrentData();
            return;
        }
        if ("scatter".equals(type)) {
            showScatterFromCurrentData();
            return;
        }

        if ("piechart".equals(type)) {
            showPieChartFromCurrentData();
            return;
        }

        setCenterContent(chart);
        chart.getData().forEach(series -> {
            if (series.getNode() != null) {
                series.getNode().setStyle(PlotUtilities.getPlotStyle(type));
                javafx.scene.Node line = series.getNode().lookup(".chart-series-line");
                if (line != null) {
                    line.setStyle(PlotUtilities.getPlotStyle(type));
                }
            }
        });
    }

    /**
     * Converts current chart data to an AreaChart and applies gradient fill
     * styling.
     */
    private void showAreaChartFromCurrentData() {
        NumberAxis areaX = new NumberAxis();
        NumberAxis areaY = new NumberAxis();
        areaX.setLabel(xAxis.getLabel() == null ? "Index" : xAxis.getLabel());
        areaY.setLabel(yAxis.getLabel() == null ? "Value" : yAxis.getLabel());

        AreaChart<Number, Number> areaChart = new AreaChart<>(areaX, areaY);
        areaChart.setAnimated(false);
        areaChart.setLegendVisible(false);
        areaChart.setCreateSymbols(false);

        for (XYChart.Series<Number, Number> series : chart.getData()) {
            XYChart.Series<Number, Number> aSeries = new XYChart.Series<>();
            aSeries.setName(series.getName());
            for (XYChart.Data<Number, Number> data : series.getData()) {
                aSeries.getData().add(new XYChart.Data<>(data.getXValue(), data.getYValue()));
            }
            areaChart.getData().add(aSeries);
        }

        // Make surrounding backgrounds transparent
        areaChart.setStyle("-fx-background-color: transparent;");
        setCenterContent(areaChart);

        // Apply gradient fill and white outline after CSS/layout
        areaChart.applyCss();
        areaChart.layout();

        for (javafx.scene.Node fill : areaChart.lookupAll(".chart-series-area-fill")) {
            fill.setStyle("-fx-fill: linear-gradient(to bottom, #12c8c8 0%, #0aa6a6 70%); -fx-opacity:0.95;");
        }

        for (javafx.scene.Node line : areaChart.lookupAll(".chart-series-line")) {
            line.setStyle("-fx-stroke: white; -fx-stroke-width: 2px;");
        }

        for (javafx.scene.Node plotBg : areaChart.lookupAll(".chart-plot-background")) {
            plotBg.setStyle("-fx-background-color: transparent;");
        }
    }

    /**
     * Converts current chart data to bar chart.
     */
    private void showBarChartFromCurrentData() {
        CategoryAxis barXAxis = new CategoryAxis();
        NumberAxis barYAxis = new NumberAxis();
        barXAxis.setLabel(xAxis.getLabel() == null ? "Index" : xAxis.getLabel());
        barYAxis.setLabel(yAxis.getLabel() == null ? "Value" : yAxis.getLabel());

        BarChart<String, Number> barChart = new BarChart<>(barXAxis, barYAxis);
        barChart.setAnimated(false);
        barChart.setLegendVisible(false);
        barChart.setCategoryGap(4);
        barChart.setBarGap(2);

        boolean hasData = chart != null && chart.getData() != null && !chart.getData().isEmpty();
        if (hasData) {
            for (XYChart.Series<Number, Number> series : chart.getData()) {
                XYChart.Series<String, Number> barSeries = new XYChart.Series<>();
                barSeries.setName(series.getName());

                for (XYChart.Data<Number, Number> data : series.getData()) {
                    barSeries.getData().add(new XYChart.Data<>(String.valueOf(data.getXValue()), data.getYValue()));
                }

                barChart.getData().add(barSeries);
            }
        } else {
            XYChart.Series<String, Number> demo = new XYChart.Series<>();
            demo.setName("2D Bar Preview");
            for (int i = 0; i < 12; i++) {
                double value = 2.0 + Math.abs(4.5 * Math.sin(i * 0.5));
                demo.getData().add(new XYChart.Data<>(String.valueOf(i + 1), value));
            }
            barChart.getData().add(demo);
        }

        setCenterContent(barChart);
        Platform.runLater(() -> {
            try {
                barChart.applyCss();
                barChart.layout();
                applyBrightBarFill(barChart, BRIGHT_BAR_COLOR);
                if (liveBarHatchRefresh != null) {
                    liveBarHatchRefresh.run();
                }
                // Ensure any bar nodes created by the skin get the teal fill (covers cases
                // where
                // data.getNode() may be null or styles override the default).
                try {
                    String rgb = PlotUtilities.toRgb(BRIGHT_BAR_COLOR);
                    java.util.Set<javafx.scene.Node> found = barChart.lookupAll(".chart-bar");
                    if (found.isEmpty()) {
                        // Fallback: some skins may not create .chart-bar nodes immediately.
                        // Create simple Region nodes for each data point so bars are visible.
                        try {
                            for (XYChart.Series<?, ?> series : barChart.getData()) {
                                for (XYChart.Data<?, ?> data : series.getData()) {
                                    if (data.getNode() == null) {
                                        javafx.scene.layout.Region r = new javafx.scene.layout.Region();
                                        r.getStyleClass().add("chart-bar");
                                        r.setStyle("-fx-background-color: " + rgb + ";");
                                        r.setMinWidth(6);
                                        data.setNode(r);
                                    } else {
                                        data.getNode().setStyle("-fx-bar-fill:" + rgb + ";");
                                    }
                                }
                            }
                        } catch (Exception ignore) {
                        }
                    } else {
                        for (javafx.scene.Node n : found) {
                            if (n != null)
                                n.setStyle("-fx-bar-fill:" + rgb + ";");
                        }
                    }
                } catch (Exception ignore) {
                }
            } catch (Exception ignore) {
            }
        });
    }

    /**
     * Builds a histogram from current chart data (or demo values) and displays it
     * as a BarChart
     */
    private void showHistogramFromCurrentData() {
        // collect all numeric values (use y-values from series)
        List<Double> all = new java.util.ArrayList<>();
        if (chart != null && chart.getData() != null && !chart.getData().isEmpty()) {
            for (XYChart.Series<Number, Number> s : chart.getData()) {
                for (XYChart.Data<Number, Number> d : s.getData()) {
                    try {
                        all.add(d.getYValue().doubleValue());
                    } catch (Exception ignored) {
                    }
                }
            }
        }

        if (all.isEmpty()) {
            // create demo values if none
            for (int i = 0; i < 120; i++) {
                double v = Math.abs(6.0 * Math.sin(i * 0.12) + (Math.random() - 0.5) * 2.2);
                all.add(v);
            }
        }

        // compute bins
        int bins = 12;
        double min = all.stream().mapToDouble(Double::doubleValue).min().orElse(0.0);
        double max = all.stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        if (min == max) {
            max = min + 1;
        }
        double width = (max - min) / bins;

        // category labels
        java.util.List<String> categories = new java.util.ArrayList<>();
        double[] edges = new double[bins + 1];
        for (int i = 0; i <= bins; i++)
            edges[i] = min + i * width;
        for (int i = 0; i < bins; i++) {
            String label = String.format("%.2f-%.2f", edges[i], edges[i + 1]);
            categories.add(label);
        }

        int[] counts = new int[bins];
        for (double v : all) {
            int idx = (int) Math.floor((v - min) / width);
            if (idx < 0)
                idx = 0;
            if (idx >= bins)
                idx = bins - 1;
            counts[idx]++;
        }

        CategoryAxis catX = new CategoryAxis();
        catX.setCategories(javafx.collections.FXCollections.observableArrayList(categories));
        NumberAxis y = new NumberAxis();
        y.setLabel("Frequency");

        BarChart<String, Number> hist = new BarChart<>(catX, y);
        hist.setAnimated(false);
        hist.setLegendVisible(false);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Histogram Preview");
        for (int i = 0; i < bins; i++) {
            series.getData().add(new XYChart.Data<>(categories.get(i), counts[i]));
        }

        hist.getData().add(series);
        hist.setCategoryGap(2);
        hist.setBarGap(0);

        // styling
        setCenterContent(hist);
        Platform.runLater(() -> {
            applyBrightBarFill(hist, BRIGHT_BAR_COLOR);
            if (liveBarHatchRefresh != null) {
                liveBarHatchRefresh.run();
            }
        });
    }

    /**
     * Converts current chart data to a ScatterChart for point plots.
     */
    private void showScatterFromCurrentData() {
        NumberAxis sX = new NumberAxis();
        NumberAxis sY = new NumberAxis();
        sX.setLabel(xAxis.getLabel() == null ? "Index" : xAxis.getLabel());
        sY.setLabel(yAxis.getLabel() == null ? "Value" : yAxis.getLabel());

        ScatterChart<Number, Number> scatter = new ScatterChart<>(sX, sY);
        scatter.setLegendVisible(false);
        scatter.setAnimated(false);

        // If there is data in the main chart, convert it; otherwise create a dummy
        // scatter
        if (chart != null && chart.getData() != null && !chart.getData().isEmpty()) {
            for (XYChart.Series<Number, Number> series : chart.getData()) {
                XYChart.Series<Number, Number> sSeries = new XYChart.Series<>();
                sSeries.setName(series.getName());
                for (XYChart.Data<Number, Number> d : series.getData()) {
                    sSeries.getData().add(new XYChart.Data<>(d.getXValue(), d.getYValue()));
                }
                scatter.getData().add(sSeries);
            }
            // count points
            lastPreviewPointCount = 0;
            for (XYChart.Series<Number, Number> s : scatter.getData())
                lastPreviewPointCount += s.getData().size();
        } else {
            // create a dummy dataset of random-ish points for demo
            XYChart.Series<Number, Number> demo = new XYChart.Series<>();
            demo.setName("demo");
            for (int i = 0; i < 30; i++) {
                double x = i;
                double y = 1.0 + Math.abs(4.0 * Math.sin(i * 0.25) + (Math.random() - 0.5) * 1.8);
                demo.getData().add(new XYChart.Data<>(x, y));
            }
            scatter.getData().add(demo);
            lastPreviewPointCount = demo.getData().size();
        }

        setCenterContent(scatter);

        // After layout, set explicit Circle nodes for each data point so symbols are
        // visible
        scatter.applyCss();
        scatter.layout();

        double radius = 3.0; // smaller marker
        for (XYChart.Series<Number, Number> series : scatter.getData()) {
            for (XYChart.Data<Number, Number> d : series.getData()) {
                Circle c = new Circle(radius);
                c.setFill(Color.web("#0aa6a6"));
                c.setStroke(Color.WHITE);
                c.setStrokeWidth(1.2);
                d.setNode(c);
            }
        }

        // ensure the counter is set even if no series
        if (lastPreviewPointCount == 0) {
            lastPreviewPointCount = scatter.getData().stream().mapToInt(s -> s.getData().size()).sum();
        }
    }

    public int getLastPreviewPointCount() {
        return lastPreviewPointCount;
    }

    /**
     * Converts current chart data to pie chart.
     */
    private void showPieChartFromCurrentData() {
        PieChart pieChart = new PieChart();
        pieChart.setLegendVisible(true);
        pieChart.setLabelsVisible(true);

        int added = 0;
        for (XYChart.Series<Number, Number> series : chart.getData()) {
            for (XYChart.Data<Number, Number> data : series.getData()) {
                String label = "x=" + data.getXValue();
                double value = Math.max(0, data.getYValue().doubleValue());
                pieChart.getData().add(new PieChart.Data(label, value));
                added++;

                if (added >= 12)
                    break;
            }
            if (added >= 12)
                break;
        }

        if (pieChart.getData().isEmpty()) {
            pieChart.getData().add(new PieChart.Data("No Data", 1));
        }

        setCenterContent(pieChart);
    }

    /**
     * Applies a color to the visible plot.
     */
    public void applyColorToVisiblePlot(Color color) {
        if (color == null || centerPane == null || centerPane.getChildren().isEmpty()) {
            return;
        }

        javafx.scene.Node visibleNode = centerPane.getChildren().get(0);
        String rgb = PlotUtilities.toRgb(color);

        if (visibleNode instanceof LineChart<?, ?> lineChart) {
            lineChart.applyCss();
            lineChart.layout();

            for (XYChart.Series<?, ?> series : lineChart.getData()) {
                applyColorToSeriesNode(series, rgb);
            }
            return;
        }

        if (visibleNode instanceof AreaChart<?, ?> areaChart) {
            areaChart.applyCss();
            areaChart.layout();

            String rgbFill = PlotUtilities.toRgb(color);
            for (javafx.scene.Node n : areaChart.lookupAll(".chart-series-area-fill")) {
                n.setStyle("-fx-fill:" + rgbFill + ";");
            }
            for (javafx.scene.Node n : areaChart.lookupAll(".chart-series-line")) {
                n.setStyle("-fx-stroke: white; -fx-stroke-width: 2px;");
            }
            return;
        }

        if (visibleNode instanceof BarChart<?, ?> barChart) {
            barChart.applyCss();
            barChart.layout();

            String barRgb = PlotUtilities.toRgb(color.brighter());

            for (XYChart.Series<?, ?> series : barChart.getData()) {
                for (XYChart.Data<?, ?> data : series.getData()) {
                    if (data.getNode() != null) {
                        String existingStyle = data.getNode().getStyle();
                        data.getNode().setStyle(buildBarStyleWithPreservedHatch(existingStyle, barRgb));
                    }
                }
            }
            for (javafx.scene.Node n : barChart.lookupAll(".chart-bar")) {
                if (n != null) {
                    String existingStyle = n.getStyle();
                    n.setStyle(buildBarStyleWithPreservedHatch(existingStyle, barRgb));
                }
            }
            return;
        }

        if (visibleNode instanceof PieChart pieChart) {
            pieChart.applyCss();
            pieChart.layout();

            for (PieChart.Data data : pieChart.getData()) {
                if (data.getNode() != null) {
                    data.getNode().setStyle("-fx-pie-color:" + rgb + ";");
                }
            }
        }
    }

    /**
     * Applies a background color to the plot area currently shown in the center
     * pane.
     */
    public void applyBackgroundColor(Color color) {
        if (color == null || centerPane == null) {
            return;
        }
        String rgb = PlotUtilities.toRgb(color);

        // Outside the plot (the surrounding center pane) should be white
        centerPane.setStyle("-fx-background-color: white;");

        // If we have a chart, make the chart's outer background transparent
        // and apply the selected color only to the plot background area
        // (.chart-plot-background)
        if (chart != null) {
            chart.setStyle("-fx-background-color: transparent;");
            chart.applyCss();
            chart.layout();

            for (javafx.scene.Node plotBackground : chart.lookupAll(".chart-plot-background")) {
                plotBackground.setStyle("-fx-background-color:" + rgb + ";");
            }
        }

        if (centerPane.getChildren().isEmpty()) {
            return;
        }

        javafx.scene.Node visibleNode = centerPane.getChildren().get(0);
        // Keep the chart node's outer style transparent so only the plot grid shows the
        // color
        if (visibleNode instanceof BarChart<?, ?> barChart) {
            barChart.setStyle("-fx-background-color: transparent;");
            barChart.applyCss();
            barChart.layout();
            for (javafx.scene.Node plotBackground : barChart.lookupAll(".chart-plot-background")) {
                plotBackground.setStyle("-fx-background-color:" + rgb + ";");
            }
        } else if (visibleNode instanceof PieChart pieChart) {
            // Pie charts don't have a plot grid — apply the color to chart background area
            // only
            pieChart.setStyle("-fx-background-color: transparent;");
            pieChart.applyCss();
            pieChart.layout();
        } else if (visibleNode instanceof LineChart<?, ?> lineChart) {
            lineChart.setStyle("-fx-background-color: transparent;");
            lineChart.applyCss();
            lineChart.layout();
            for (javafx.scene.Node plotBackground : lineChart.lookupAll(".chart-plot-background")) {
                plotBackground.setStyle("-fx-background-color:" + rgb + ";");
            }
        }
    }

    private void applyBrightBarFill(BarChart<?, ?> barChart, Color barColor) {
        if (barChart == null) {
            return;
        }

        Color effectiveColor = barColor == null ? BRIGHT_BAR_COLOR : barColor;
        String rgb = PlotUtilities.toRgb(effectiveColor);

        barChart.applyCss();
        barChart.layout();

        for (XYChart.Series<?, ?> series : barChart.getData()) {
            for (XYChart.Data<?, ?> data : series.getData()) {
                if (data.getNode() != null) {
                    String existingStyle = data.getNode().getStyle();
                    data.getNode().setStyle(buildBarStyleWithPreservedHatch(existingStyle, rgb));
                }
            }
        }
        // Also ensure any existing .chart-bar nodes get explicit background set
        try {
            for (javafx.scene.Node n : barChart.lookupAll(".chart-bar")) {
                if (n != null) {
                    String existingStyle = n.getStyle();
                    n.setStyle(buildBarStyleWithPreservedHatch(existingStyle, rgb));
                }
            }
        } catch (Exception ignore) {
        }
    }

    public void applyBarDistributionStyle(String distributionType) {
        if (distributionType == null || centerPane == null || centerPane.getChildren().isEmpty()) {
            return;
        }

        javafx.scene.Node visibleNode = centerPane.getChildren().get(0);
        if (!(visibleNode instanceof BarChart<?, ?> barChart)) {
            return;
        }
        applyBarDistributionStyle(distributionType, barChart);
    }

    public void applyBarDistributionStyle(String distributionType, javafx.scene.chart.BarChart<?, ?> barChart) {
        if (distributionType == null || barChart == null) {
            return;
        }

        barChart.applyCss();
        barChart.layout();

        String normalized = distributionType.trim().toLowerCase();
        if ("mixed".equals(normalized)) {
            Color[] mixedColors = new Color[] {
                    Color.web("#0aa6a6"),
                    Color.web("#d88b3a"),
                    Color.web("#8c40aa"),
                    Color.web("#86b32e"),
                    Color.web("#2f81d3"),
                    Color.web("#d33d55")
            };

            int idx = 0;
            for (XYChart.Series<?, ?> series : barChart.getData()) {
                for (XYChart.Data<?, ?> data : series.getData()) {
                    Color color = mixedColors[idx % mixedColors.length];
                    String rgb = PlotUtilities.toRgb(color);
                    if (data.getNode() != null) {
                        data.getNode().setStyle(buildBarStyleWithPreservedHatch(data.getNode().getStyle(), rgb));
                    }
                    idx++;
                }
            }
            int nodeIdx = 0;
            for (javafx.scene.Node n : barChart.lookupAll(".chart-bar")) {
                if (n != null) {
                    Color color = mixedColors[nodeIdx % mixedColors.length];
                    String rgb = PlotUtilities.toRgb(color);
                    n.setStyle(buildBarStyleWithPreservedHatch(n.getStyle(), rgb));
                    nodeIdx++;
                }
            }
            return;
        }

        // Normal and Uniform both render uniform bars using the default bright fill.
        applyBrightBarFill(barChart, BRIGHT_BAR_COLOR);
    }

    /**
     * Applies color to a specific series.
     */
    private void applyColorToSeriesNode(XYChart.Series<?, ?> series, String rgb) {
        if (series.getNode() == null)
            return;

        series.getNode().setStyle("-fx-stroke:" + rgb + ";");

        Object lineNode = series.getNode().lookup(".chart-series-line");
        if (lineNode instanceof javafx.scene.Node node) {
            node.setStyle("-fx-stroke:" + rgb + ";");
        }

        for (javafx.scene.Node symbol : series.getNode().lookupAll(".chart-line-symbol")) {
            symbol.setStyle("-fx-background-color:" + rgb + ", white; -fx-border-color:" + rgb
                    + "; -fx-background-radius: 3px; -fx-padding: 2px;");
        }
    }

    private String buildBarStyleWithPreservedHatch(String existingStyle, String barRgb) {
        String style = "-fx-bar-fill:" + barRgb + "; -fx-background-color:" + barRgb + "; -fx-opacity: 1; ";
        if (existingStyle == null || existingStyle.isBlank()) {
            return style;
        }

        style += extractStyleProperty(existingStyle, "-fx-background-image");
        style += extractStyleProperty(existingStyle, "-fx-background-repeat");
        style += extractStyleProperty(existingStyle, "-fx-background-position");
        style += extractStyleProperty(existingStyle, "-fx-background-size");
        style += extractStyleProperty(existingStyle, "-fx-background-insets");
        style += extractStyleProperty(existingStyle, "-fx-border-style");
        style += extractStyleProperty(existingStyle, "-fx-border-color");
        style += extractStyleProperty(existingStyle, "-fx-border-width");
        style += extractStyleProperty(existingStyle, "-fx-border-insets");
        return style.trim();
    }

    private String extractStyleProperty(String css, String propertyName) {
        if (css == null || css.isBlank() || propertyName == null || propertyName.isBlank()) {
            return "";
        }
        int start = css.indexOf(propertyName);
        if (start < 0) {
            return "";
        }
        int end = css.indexOf(';', start);
        if (end < 0) {
            end = css.length();
            return css.substring(start, end) + " ";
        }
        return css.substring(start, end + 1) + " ";
    }

    /**
     * Applies color to a series by name.
     */
    public void applySeriesColor(String variable, Color color) {
        if (chart == null || chart.getData() == null)
            return;

        chart.applyCss();
        chart.layout();

        String targetName = resolveSeriesName(variable);
        boolean matchAll = targetName == null || targetName.isBlank();
        boolean updated = false;
        String rgb = PlotUtilities.toRgb(color);

        for (XYChart.Series<Number, Number> series : chart.getData()) {
            if (!matchAll && !java.util.Objects.equals(targetName, series.getName())) {
                continue;
            }

            applyColorToSeriesNode(series, rgb);
            updated = true;
        }

        if (!updated && !chart.getData().isEmpty()) {
            XYChart.Series<Number, Number> series = chart.getData().get(0);
            applyColorToSeriesNode(series, rgb);
        }
    }

    /**
     * Resolves the series name from variable name.
     */
    private String resolveSeriesName(String variable) {
        if (variable == null || variable.isBlank() || chart == null || chart.getData() == null
                || chart.getData().isEmpty()) {
            return variable;
        }

        for (XYChart.Series<Number, Number> series : chart.getData()) {
            if (variable.equals(series.getName())) {
                return variable;
            }
        }

        for (XYChart.Series<Number, Number> series : chart.getData()) {
            if (series.getName() != null && series.getName().equalsIgnoreCase(variable)) {
                return series.getName();
            }
        }

        return chart.getData().get(0).getName();
    }

    /**
     * Sets the center content of the plot window.
     *
     * Preserve overlay children (such as annotation overlays) so they remain
     * visible
     * when the visible chart node is replaced.
     */
    public void setCenterContent(javafx.scene.Node node) {
        if (centerPane == null) {
            return;
        }
        javafx.collections.ObservableList<javafx.scene.Node> existing = centerPane.getChildren();
        if (existing == null || existing.isEmpty()) {
            centerPane.getChildren().setAll(node);
            return;
        }

        // Preserve any overlay nodes that are rendered above the main plot node.
        java.util.List<javafx.scene.Node> overlays = new java.util.ArrayList<>();
        for (int i = 1; i < existing.size(); i++) {
            overlays.add(existing.get(i));
        }

        centerPane.getChildren().setAll(node);
        if (!overlays.isEmpty()) {
            centerPane.getChildren().addAll(overlays);
        }
    }

    /**
     * Saves the current plot to an image file.
     */
    public void save(Stage stage, String format, StackPane root) {
        WritableImage image = root.snapshot(new javafx.scene.SnapshotParameters(), null);
        chooseFileAndWrite(stage, format, image);
    }

    /**
     * Saves a custom-sized plot image.
     */
    public void saveCustom(int width, int height, String format, Stage stage, StackPane root) {
        WritableImage image = new WritableImage(width, height);
        root.snapshot(new javafx.scene.SnapshotParameters(), image);
        chooseFileAndWrite(stage, format, image);
    }

    /**
     * Shared tail of {@link #save} and {@link #saveCustom}: asks for a target
     * file (pre-filled with a timestamped name in the last-used folder), makes
     * sure it carries the right extension, writes the image, and reports the
     * outcome to the user either way.
     */
    private void chooseFileAndWrite(Stage stage, String format, WritableImage image) {
        String safeFormat = (format == null || format.isBlank()) ? "png" : format.toLowerCase().trim();

        FileChooser chooser = new FileChooser();
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter(safeFormat.toUpperCase(), "*." + safeFormat));
        chooser.setInitialDirectory(lastFolder != null && lastFolder.isDirectory()
                ? lastFolder
                : new File(System.getProperty("user.home")));
        chooser.setInitialFileName(buildDefaultFileName(safeFormat));

        File chosen = chooser.showSaveDialog(stage);
        if (chosen == null) {
            return;
        }
        File file = ensureExtension(chosen, safeFormat);

        try {
            String writerFormat = getWriteFormat(safeFormat);
            BufferedImage buffered = prepareImageForWrite(SwingFXUtils.fromFXImage(image, null), writerFormat);
            if (!ImageIO.write(buffered, writerFormat, file)) {
                throw new IOException("No writer found for format: " + writerFormat);
            }
            lastFolder = file.getParentFile();
            showSaveConfirmation(stage, file);
        } catch (IOException ex) {
            showSaveError(stage, "Failed to save image: " + ex.getMessage());
        }
    }

    /**
     * Saves the current plot using the settings collected from the save panel.
     */
    public void saveWithSettings(int dpi, String format, File targetFile, Stage stage, StackPane root) {
        // Validate and clean format
        if (format == null || format.isBlank()) {
            format = "jpg";
        } else {
            format = format.toLowerCase().trim();
        }

        int baseWidth = (int) Math.max(1, Math.round(root.getWidth() > 0 ? root.getWidth() : 1200));
        int baseHeight = (int) Math.max(1, Math.round(root.getHeight() > 0 ? root.getHeight() : 800));

        // DPI does not affect image dimensions - all saved images have the same pixel
        // size
        // regardless of DPI setting (DPI is just metadata for printing)
        int width = baseWidth;
        int height = baseHeight;

        if (targetFile == null) {
            saveCustom(width, height, format, stage, root);
            return;
        }

        targetFile = ensureExtension(targetFile, format);
        File directory = targetFile.getParentFile();
        if (directory == null) {
            showSaveError(stage, "Invalid save path: " + targetFile.getAbsolutePath());
            return;
        }
        if (!directory.exists() && !directory.mkdirs()) {
            showSaveError(stage, "Could not create save directory: " + directory.getAbsolutePath());
            return;
        }
        if (!directory.isDirectory()) {
            showSaveError(stage, "Save location is not a directory: " + directory.getAbsolutePath());
            return;
        }

        WritableImage image = new WritableImage(width, height);
        root.snapshot(new javafx.scene.SnapshotParameters(), image);

        try {
            String writerFormat = getWriteFormat(format);
            BufferedImage buffered = prepareImageForWrite(SwingFXUtils.fromFXImage(image, null), writerFormat);
            if (!ImageIO.write(buffered, writerFormat, targetFile)) {
                throw new IOException("No writer found for format: " + writerFormat);
            }
            lastFolder = targetFile.getParentFile();
            showSaveConfirmation(stage, targetFile);
        } catch (IOException ex) {
            showSaveError(stage, "Failed to save image: " + ex.getMessage());
            System.err.println("Failed to save image: " + ex.getMessage());
        }
    }

    private String getWriteFormat(String format) {
        if (format == null || format.isBlank())
            return "png";
        String fmt = format.toLowerCase().trim();
        switch (fmt) {
            case "jpeg", "jpg":
                return "jpg";
            case "tiff":
                return "tif";
            case "png":
                return "png";
            case "bmp":
                return "bmp";
            case "gif":
                return "gif";
            default:
                return fmt.isEmpty() ? "png" : fmt;
        }
    }

    private BufferedImage prepareImageForWrite(BufferedImage image, String writerFormat) {
        if (image == null) {
            return null;
        }
        if (writerFormat == null) {
            return image;
        }
        String fmt = writerFormat.toLowerCase().trim();
        if (fmt.equals("jpg") || fmt.equals("jpeg")) {
            BufferedImage rgbImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = rgbImage.createGraphics();
            g2d.setColor(java.awt.Color.WHITE);
            g2d.fillRect(0, 0, image.getWidth(), image.getHeight());
            g2d.drawImage(image, 0, 0, null);
            g2d.dispose();
            return rgbImage;
        }
        return image;
    }

    private void showSaveConfirmation(Stage stage, File file) {
        if (file == null)
            return;
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(stage);
        alert.setTitle("Save Successful");
        alert.setHeaderText("Plot saved successfully");
        alert.setContentText("Saved to: " + file.getAbsolutePath());
        alert.showAndWait();
    }

    private void showSaveError(Stage stage, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(stage);
        alert.setTitle("Save Failed");
        alert.setHeaderText("Unable to save the plot");
        alert.setContentText(message);
        alert.showAndWait();
    }

    private File ensureExtension(File file, String format) {
        String safeFormat = format == null || format.isBlank() ? "jpeg" : format.toLowerCase().trim();
        if (file.exists() && file.isDirectory()) {
            return new File(file, "untitled-01." + safeFormat);
        }
        String name = file.getName();
        String parent = file.getParent();
        if (!name.contains(".")) {
            return parent == null ? new File(name + "." + safeFormat) : new File(parent, name + "." + safeFormat);
        }
        String baseName = name.substring(0, name.lastIndexOf('.'));
        return parent == null ? new File(baseName + "." + safeFormat) : new File(parent, baseName + "." + safeFormat);
    }

    private String buildDefaultFileName(String format) {
        String safeFormat = format == null || format.isBlank() ? "png" : format.toLowerCase();
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        return "plot_" + timestamp + "." + safeFormat;
    }

    /**
     * Parses user code to extract dynamic plot() function call arguments.
     * For example: plot(a, b) extracts ["a", "b"] to use as axis labels.
     *
     * @param code the user's code containing plot() calls
     * @return an array with [xVarName, yVarName] or null if no plot() call found
     */
    public static String[] extractPlotVariablesFromCode(String code) {
        if (code == null || code.isBlank()) {
            return null;
        }

        Matcher matcher = PLOT_TWO_ARGS.matcher(code);
        if (matcher.find()) {
            return new String[] { matcher.group(1), matcher.group(2) };
        }

        Matcher singleMatcher = PLOT_ONE_ARG.matcher(code);
        if (singleMatcher.find()) {
            return new String[] { singleMatcher.group(1) };
        }

        return null;
    }
}
