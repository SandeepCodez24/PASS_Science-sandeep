package plot;

import java.util.function.Consumer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Embedded Grid configuration panel.
 */
public class PlotGrid {

        private final double axisMin;
        private final double axisMax;

        public PlotGrid(double axisMin, double axisMax) {
                this.axisMin = axisMin;
                this.axisMax = axisMax;
        }

        public VBox build(Consumer<GridSettings> callback) {

                // =========================================================
                // TITLE
                // =========================================================
                Label title = new Label("Grid Configuration");
                title.setStyle("""
                                -fx-font-size:14px;
                                -fx-font-weight:bold;
                                -fx-text-fill:white;
                                """);

                // =========================================================
                // ENABLE GRID
                // =========================================================
                Label gridLabel = new Label("Grid:");
                gridLabel.setStyle("-fx-text-fill:white;");

                CheckBox gridToggle = new CheckBox("Enable Grid");
                gridToggle.setSelected(true);
                gridToggle.setStyle("-fx-text-fill:white;");

                VBox enableBox = new VBox(4, gridLabel, gridToggle);

                // =========================================================
                // LINE STYLE
                // =========================================================
                Label styleLabel = new Label("Line Style:");
                styleLabel.setStyle("-fx-text-fill:white;");

                ComboBox<String> lineStyle = new ComboBox<>();
                lineStyle.getItems().addAll("Solid", "Dashed", "Dotted", "Dash-dot", "None");
                lineStyle.setValue("Solid");
                lineStyle.setPrefWidth(160);

                VBox styleBox = new VBox(4, styleLabel, lineStyle);

                // =========================================================
                // SPACING
                // =========================================================
                Label spacingLabel = new Label("Line Space:");
                spacingLabel.setStyle("-fx-text-fill:white;");

                double maxSpacing = 1000; // just UI limit, not logical limit

                Slider spacingSlider = new Slider(0.1, maxSpacing, 1.0);
                spacingSlider.setPrefWidth(120);

                TextField spacingField = new TextField();
                spacingField.setPrefWidth(60);

                // initialize both with same value
                spacingField.setText(String.format("%.2f", spacingSlider.getValue()));

                // =========================================================
                // SLIDER → TEXT (live sync)
                // =========================================================
                spacingSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
                        spacingField.setText(String.format("%.2f", newVal.doubleValue()));
                });

                // =========================================================
                // TEXT → SLIDER (when user types)
                // =========================================================
                spacingField.setOnAction(e -> {
                        try {
                                double val = Double.parseDouble(spacingField.getText());

                                if (val > 0) {
                                        spacingSlider.setValue(val);
                                }

                        } catch (NumberFormatException ex) {
                                spacingField.setText(String.format("%.2f", spacingSlider.getValue()));
                        }
                });

                // OPTIONAL: live update while typing (better UX)
                spacingField.focusedProperty().addListener((obs, wasFocused, isFocused) -> {
                        if (!isFocused) {
                                try {
                                        double val = Double.parseDouble(spacingField.getText());

                                        if (val > 0) {
                                                spacingSlider.setValue(val);
                                        }

                                } catch (Exception ex) {
                                        spacingField.setText(String.format("%.2f", spacingSlider.getValue()));
                                }
                        }
                });

                HBox spacingControl = new HBox(8, spacingSlider, spacingField);
                spacingControl.setAlignment(Pos.CENTER_LEFT);

                VBox spacingBox = new VBox(4, spacingLabel, spacingControl);

                // =========================================================
                // RANGE
                // =========================================================
                Label rangeLabel = new Label("Range:");
                rangeLabel.setStyle("-fx-text-fill:white;");

                TextField minField = new TextField(String.format("%.2f", axisMin));
                TextField maxField = new TextField(String.format("%.2f", axisMax));

                minField.setPrefWidth(70);
                maxField.setPrefWidth(70);

                Label minLabel = new Label("Min");
                Label maxLabel = new Label("Max");

                minLabel.setStyle("-fx-text-fill:white;");
                maxLabel.setStyle("-fx-text-fill:white;");

                minLabel.setPrefWidth(35);
                maxLabel.setPrefWidth(35);

                HBox rangeInputs = new HBox(8, minLabel, minField, maxLabel, maxField);
                rangeInputs.setAlignment(Pos.CENTER_LEFT);

                VBox rangeBox = new VBox(4, rangeLabel, rangeInputs);

                // =========================================================
                // DISTRIBUTION TYPE
                // =========================================================
                Label distTypeLabel = new Label("Distribution:");
                distTypeLabel.setStyle("-fx-text-fill:white;");

                ComboBox<String> distType = new ComboBox<>();
                distType.getItems().addAll("Normal", "Skew Right", "Skew Left");
                distType.setValue("Normal");
                distType.setPrefWidth(160);

                VBox distTypeBox = new VBox(4, distTypeLabel, distType);

                // =========================================================
                // GRID LAYOUT (FIXED ALIGNMENT)
                // =========================================================
                GridPane rowContainer = new GridPane();
                rowContainer.setHgap(25);
                rowContainer.setVgap(10);

                ColumnConstraints col = new ColumnConstraints();
                col.setPrefWidth(180);
                rowContainer.getColumnConstraints().addAll(col, col, col, col, col);

                rowContainer.add(enableBox, 0, 0);
                rowContainer.add(styleBox, 1, 0);
                rowContainer.add(spacingBox, 2, 0);
                rowContainer.add(rangeBox, 3, 0);
                rowContainer.add(distTypeBox, 4, 0);

                // =========================================================
                // BUTTONS
                // =========================================================
                Button applyBtn = new Button("Apply");
                Button cancelBtn = new Button("Cancel");

                applyBtn.setPrefWidth(80);
                cancelBtn.setPrefWidth(80);

                HBox buttons = new HBox(10, applyBtn, cancelBtn);
                buttons.setAlignment(Pos.CENTER_RIGHT);

                // =========================================================
                // MAIN CONTAINER
                // =========================================================
                VBox content = new VBox(12, title, rowContainer, buttons);
                content.setPadding(new Insets(14));
                content.setStyle("""
                                -fx-background-color:#0aa6a6;
                                -fx-background-radius:8;
                                -fx-border-radius:8;
                                """);

                // =========================================================
                // APPLY ACTION
                // =========================================================
                applyBtn.setOnAction(e -> {
                        GridSettings settings = new GridSettings();

                        settings.setEnabled(gridToggle.isSelected());
                        settings.setLineStyle(lineStyle.getValue());
                        settings.setSpacing(spacingSlider.getValue());
                        settings.setDistributionType(distType.getValue());

                        settings.setMin(PlotUtilities.parseDoubleOr(minField.getText(), axisMin));
                        settings.setMax(PlotUtilities.parseDoubleOr(maxField.getText(), axisMax));

                        if (callback != null)
                                callback.accept(settings);
                });

                // =========================================================
                // CANCEL ACTION
                // =========================================================
                cancelBtn.setOnAction(e -> {
                        content.setVisible(false);
                        content.setManaged(false);
                });

                return content;
        }
}