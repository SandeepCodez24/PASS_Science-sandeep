package plot;

/**
 * Configuration data class for grid visualization settings.
 */
public class GridSettings {

    private boolean enabled;
    private String lineStyle;
    private double spacing;
    private String distribution;
    private String distributionType;
    private double min;
    private double max;

    /**
     * Default constructor.
     */
    public GridSettings() {

        this.enabled = true;
        this.lineStyle = "Solid";
        this.spacing = 1.0;
        this.distribution = "Distribution";
        this.distributionType = "Normal";
        this.min = 0.0;
        this.max = 100.0;
    }

    // =========================================================
    // GETTERS & SETTERS
    // =========================================================

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getLineStyle() {
        return lineStyle;
    }

    public void setLineStyle(String lineStyle) {
        if (lineStyle == null || lineStyle.isBlank()) {
            this.lineStyle = "Solid";
            return;
        }

        String normalized = lineStyle.trim();
        if (normalized.equalsIgnoreCase("solid")) {
            this.lineStyle = "Solid";
        } else if (normalized.equalsIgnoreCase("dashed")) {
            this.lineStyle = "Dashed";
        } else if (normalized.equalsIgnoreCase("dotted")) {
            this.lineStyle = "Dotted";
        } else if (normalized.equalsIgnoreCase("dash-dot")) {
            this.lineStyle = "Dash-dot";
        } else if (normalized.equalsIgnoreCase("none")) {
            this.lineStyle = "None";
        } else {
            this.lineStyle = normalized;
        }
    }

    public double getSpacing() {
        return spacing;
    }

    public void setSpacing(double spacing) {
        this.spacing = spacing;
    }

    public String getDistribution() {
        return distribution;
    }

    public void setDistribution(String distribution) {
        this.distribution = distribution;
    }

    public String getDistributionType() {
        return distributionType;
    }

    public void setDistributionType(String distributionType) {
        this.distributionType = distributionType;
    }

    public double getMin() {
        return min;
    }

    public void setMin(double min) {
        this.min = min;
    }

    public double getMax() {
        return max;
    }

    public void setMax(double max) {
        this.max = max;
    }

    // =========================================================
    // UTILITY METHODS
    // =========================================================

    public boolean isValid() {
        return spacing > 0 && min < max;
    }

    public GridSettings copy() {

        GridSettings copy = new GridSettings();

        copy.enabled = this.enabled;
        copy.lineStyle = this.lineStyle;
        copy.spacing = this.spacing;
        copy.distribution = this.distribution;
        copy.distributionType = this.distributionType;
        copy.min = this.min;
        copy.max = this.max;

        return copy;
    }

    public void resetToDefaults() {

        enabled = true;
        lineStyle = "Solid";
        spacing = 1.0;
        distribution = "Distribution";
        distributionType = "Normal";
        min = 0.0;
        max = 100.0;
    }

    public boolean isLogarithmicRange() {

        if (min <= 0) {
            return false;
        }

        return Math.abs(max / min) > 1000;
    }

    public double getRangeSpan() {
        return Math.abs(max - min);
    }

    public double getRangeCenter() {
        return (min + max) / 2.0;
    }

    public double getMajorTickInterval() {
        return spacing;
    }

    /**
     * Gets CSS line style string for drawing grid lines.
     *
     * @return CSS compatible stroke-dasharray value
     */
    public String getCSSLineStyle() {

        if (lineStyle == null) {
            return "";
        }

        switch (lineStyle.trim().toLowerCase()) {

            case "dashed":
                return "8 4";

            case "dotted":
                return "2 2";

            case "dash-dot":
                return "8 4 2 4";

            case "none":
                return "0 0";

            case "solid":
            default:
                return "";
        }
    }

    @Override
    public String toString() {

        return String.format(
                "GridSettings[enabled=%s, lineStyle=%s, spacing=%.2f, distribution=%s, distType=%s, range=%.2f-%.2f]",
                enabled,
                lineStyle,
                spacing,
                distribution,
                distributionType,
                min,
                max);
    }

    @Override
    public boolean equals(Object obj) {

        if (!(obj instanceof GridSettings other)) {
            return false;
        }

        return enabled == other.enabled
                && lineStyle.equals(other.lineStyle)
                && Math.abs(spacing - other.spacing) < 0.0001
                && distribution.equals(other.distribution)
                && distributionType.equals(other.distributionType)
                && Math.abs(min - other.min) < 0.0001
                && Math.abs(max - other.max) < 0.0001;
    }

    @Override
    public int hashCode() {

        return (Boolean.toString(enabled)
                + lineStyle
                + spacing
                + distribution
                + distributionType
                + min
                + max).hashCode();
    }
}