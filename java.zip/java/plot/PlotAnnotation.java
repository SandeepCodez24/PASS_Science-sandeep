package plot;

import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.Axis;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 * Manages annotation settings dialog and overlay.
 */
public class PlotAnnotation {

    private static final double DEFAULT_ANNOTATION_X = 60;
    private static final double DEFAULT_ANNOTATION_Y = 45;

    private boolean annotationEnabled = false;
    private String annotationText = "";
    private Color annotationWordColor = Color.web("#2f3a44");
    private boolean annotationCustomLocation = false;
    private double annotationX = DEFAULT_ANNOTATION_X;
    private double annotationY = DEFAULT_ANNOTATION_Y;
    private Label annotationOverlay;
    private StackPane centerPane;
    private LineChart<Number, Number> chart;
    private NumberAxis xAxis;
    private NumberAxis yAxis;
    private VBox annotationStrip;

    public PlotAnnotation(StackPane centerPane, LineChart<Number, Number> chart, NumberAxis xAxis, NumberAxis yAxis) {
        this.centerPane = centerPane;
        this.chart = chart;
        this.xAxis = xAxis;
        this.yAxis = yAxis;
        this.annotationOverlay = new Label();
        this.annotationOverlay.getStyleClass().add("plot-annotation-overlay");
        this.annotationOverlay.setMouseTransparent(true);
        this.annotationOverlay.setVisible(false);
        this.annotationOverlay.setManaged(false);
    }

    /**
     * Show a coordinate annotation at the given data (x,y).
     * Formats the label as "(x, y)" and positions the overlay.
     */
    public void showCoordinateAnnotation(double x, double y) {
        this.annotationEnabled = true;
        this.annotationCustomLocation = true;
        this.annotationX = x;
        this.annotationY = y;
        this.annotationText = String.format("(%s, %s)", formatNumber(x), formatNumber(y));
        refreshAnnotationOverlay();
    }

    /**
     * Hides the currently displayed coordinate annotation.
     */
    public void hideCoordinateAnnotation() {
        this.annotationEnabled = false;
        this.annotationText = "";
        refreshAnnotationOverlay();
    }

    private String formatNumber(double v) {
        // Always show one decimal place (e.g. 3.0)
        return String.format("%.1f", v);
    }

    /**
     * Builds an Annotation toolbar button that toggles the settings strip.
     */
    public Button buildAnnotationButton(Consumer<Void> onToggle) {
        Button annotationButton = new Button("Annotation");
        annotationButton.setOnAction(e -> onToggle.accept(null));
        return annotationButton;
    }

    /**
     * Builds the annotation settings strip shown under the toolbar.
     */
    public VBox buildAnnotationStrip() {
        TextField textField = new TextField(annotationText == null ? "" : annotationText);
        textField.setPrefWidth(400);
        textField.setPromptText("Enter annotation text...");

        ColorPicker wordColor = new ColorPicker(annotationWordColor);

        HBox textRow = new HBox(8, new Label("Text"), textField);
        textRow.setAlignment(Pos.CENTER_LEFT);

        HBox colorRow = new HBox(8, new Label("Word color"), wordColor);
        colorRow.setAlignment(Pos.CENTER_LEFT);

        CheckBox customLocation = new CheckBox("Customize");
        TextField xField = new TextField(Double.toString(annotationX));
        xField.setPrefWidth(60);
        TextField yField = new TextField(Double.toString(annotationY));
        yField.setPrefWidth(60);

        HBox coordsRow = new HBox(8, new Label("X"), xField, new Label("Y"), yField);
        coordsRow.setAlignment(Pos.CENTER_LEFT);
        coordsRow.setVisible(annotationCustomLocation);
        coordsRow.setManaged(annotationCustomLocation);

        HBox locationRow = new HBox(15, customLocation, coordsRow);
        locationRow.setAlignment(Pos.CENTER_LEFT);

        VBox settingsBox = new VBox(10, textRow, colorRow, locationRow);
        settingsBox.setAlignment(Pos.CENTER_LEFT);

        annotationStrip = new VBox(settingsBox);
        annotationStrip.setPadding(new Insets(10, 12, 10, 12));
        annotationStrip.getStyleClass().add("plot-annotation-box");
        annotationStrip.setVisible(false);
        annotationStrip.setManaged(false);

        Runnable applyLiveChanges = () -> {
            annotationEnabled = true;
            annotationText = textField.getText() == null ? "" : textField.getText().trim();
            annotationWordColor = wordColor.getValue() == null ? Color.web("#2f3a44") : wordColor.getValue();
            annotationCustomLocation = customLocation.isSelected();

            if (annotationCustomLocation) {
                annotationX = parseCoordinate(xField.getText(), DEFAULT_ANNOTATION_X);
                annotationY = parseCoordinate(yField.getText(), DEFAULT_ANNOTATION_Y);
            } else {
                annotationX = DEFAULT_ANNOTATION_X;
                annotationY = DEFAULT_ANNOTATION_Y;
            }

            refreshAnnotationOverlay();
        };

        textField.textProperty().addListener((obs, oldVal, newVal) -> applyLiveChanges.run());
        textField.setOnAction(e -> applyLiveChanges.run());
        textField.addEventHandler(KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == KeyCode.ENTER) {
                e.consume();
                applyLiveChanges.run();
            }
        });
        textField.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal) {
                applyLiveChanges.run();
            }
        });
        wordColor.valueProperty().addListener((obs, oldVal, newVal) -> applyLiveChanges.run());

        customLocation.selectedProperty().addListener((obs, oldVal, newVal) -> {
            coordsRow.setVisible(newVal);
            coordsRow.setManaged(newVal);
            applyLiveChanges.run();
        });
        xField.textProperty().addListener((obs, oldVal, newVal) -> applyLiveChanges.run());
        yField.textProperty().addListener((obs, oldVal, newVal) -> applyLiveChanges.run());

        applyLiveChanges.run();

        return annotationStrip;
    }

    /**
     * Shows the annotation strip.
     */
    public void showAnnotationStrip() {
        if (annotationStrip == null)
            return;
        annotationStrip.setVisible(true);
        annotationStrip.setManaged(true);
    }

    /**
     * Hides annotation strip.
     */
    public void hideAnnotationStrip() {
        if (annotationStrip == null)
            return;
        annotationStrip.setVisible(false);
        annotationStrip.setManaged(false);
    }

    /**
     * Toggles annotation strip visibility.
     */
    public void toggleAnnotationStrip() {
        if (annotationStrip == null)
            return;
        if (annotationStrip.isVisible()) {
            hideAnnotationStrip();
        } else {
            showAnnotationStrip();
        }
    }

    private XYChart<?, ?> getVisibleChart() {
        if (centerPane == null) {
            return null;
        }
        for (Node child : centerPane.getChildren()) {
            if (child instanceof XYChart<?, ?> xyChart) {
                return xyChart;
            }
        }
        return null;
    }

    /**
     * Updates the annotation overlay position and visibility based on settings.
     */
    public void refreshAnnotationOverlay() {
        if (centerPane == null || annotationOverlay == null) {
            return;
        }

        boolean show = annotationEnabled && annotationText != null && !annotationText.isBlank();

        if (!show) {
            annotationOverlay.setVisible(false);
            annotationOverlay.setManaged(false);
            return;
        }

        // Set text and color
        annotationOverlay.setText(annotationText == null ? "" : annotationText);

        // Apply transparent background box styling with proper text color
        String hexColor = PlotUtilities.colorToHex(annotationWordColor);
        annotationOverlay.setStyle(
                "-fx-background-color: rgba(255, 255, 255, 0.85); "
                        + "-fx-border-color: rgba(50, 50, 50, 0.4); "
                        + "-fx-border-width: 1; "
                        + "-fx-padding: 8 12 8 12; "
                        + "-fx-border-radius: 5; "
                        + "-fx-text-fill: " + hexColor + "; "
                        + "-fx-font-size: 13; "
                        + "-fx-font-weight: bold;");

        // Ensure overlay is properly configured
        annotationOverlay.setManaged(true);
        annotationOverlay.setMouseTransparent(true);
        annotationOverlay.setWrapText(false);

        // Position at top-left and optionally move using custom plot coordinates
        StackPane.setAlignment(annotationOverlay, Pos.TOP_LEFT);
        if (annotationCustomLocation) {
            annotationOverlay.applyCss();
            annotationOverlay.layout();
            if (!centerPane.getChildren().contains(annotationOverlay)) {
                centerPane.getChildren().add(annotationOverlay);
            }

            XYChart<?, ?> visibleChart = getVisibleChart();
            boolean positioned = false;

            if (visibleChart instanceof BarChart<?, ?> barChart) {
                try {
                    barChart.applyCss();
                    barChart.layout();
                    String targetX = String.valueOf((int) Math.round(annotationX));
                    NumberAxis barYAxis = barChart.getYAxis() instanceof NumberAxis ny ? ny : null;
                    @SuppressWarnings("unchecked")
                    Axis<String> categoryAxis = barChart.getXAxis() instanceof Axis<?> axis ? (Axis<String>) axis
                            : null;
                    Point2D plotOrigin = null;
                    Node plotBackground = barChart.lookup(".chart-plot-background");
                    if (plotBackground != null) {
                        Bounds plotBoundsScene = plotBackground.localToScene(plotBackground.getBoundsInLocal());
                        if (plotBoundsScene.getWidth() > 0 && plotBoundsScene.getHeight() > 0) {
                            plotOrigin = centerPane.sceneToLocal(plotBoundsScene.getMinX(), plotBoundsScene.getMinY());
                        }
                    }

                    if (plotOrigin != null && categoryAxis != null && barYAxis != null) {
                        double xPlot = categoryAxis.getDisplayPosition(targetX);
                        double yPlot = barYAxis.getDisplayPosition(annotationY);
                        double width = annotationOverlay.getWidth();
                        double height = annotationOverlay.getHeight();
                        annotationOverlay.setTranslateX(plotOrigin.getX() + xPlot - width / 2.0);
                        annotationOverlay.setTranslateY(plotOrigin.getY() + yPlot - height);
                        positioned = true;
                    }
                } catch (Exception ignore) {
                }
            }

            if (!positioned && visibleChart instanceof XYChart<?, ?> && xAxis != null && yAxis != null) {
                double xPlot = annotationX;
                double yPlot = annotationY;
                try {
                    xPlot = xAxis.getDisplayPosition(annotationX);
                    yPlot = yAxis.getDisplayPosition(annotationY);
                } catch (Exception ignore) {
                }

                Point2D plotOrigin = null;
                try {
                    var plotBackground = visibleChart.lookup(".chart-plot-background");
                    if (plotBackground != null) {
                        Bounds plotBoundsScene = plotBackground.localToScene(plotBackground.getBoundsInLocal());
                        if (plotBoundsScene.getWidth() > 0 && plotBoundsScene.getHeight() > 0) {
                            plotOrigin = centerPane.sceneToLocal(plotBoundsScene.getMinX(), plotBoundsScene.getMinY());
                        }
                    }
                } catch (Exception ignore) {
                }

                if (plotOrigin == null) {
                    Platform.runLater(this::refreshAnnotationOverlay);
                } else {
                    double width = annotationOverlay.getWidth();
                    double height = annotationOverlay.getHeight();
                    annotationOverlay.setTranslateX(plotOrigin.getX() + xPlot - width / 2.0);
                    annotationOverlay.setTranslateY(plotOrigin.getY() + yPlot - height - 8.0);
                    positioned = true;
                }
            }

            if (!positioned) {
                annotationOverlay.setTranslateX(DEFAULT_ANNOTATION_X);
                annotationOverlay.setTranslateY(DEFAULT_ANNOTATION_Y);
            }
        } else {
            annotationOverlay.setTranslateX(DEFAULT_ANNOTATION_X);
            annotationOverlay.setTranslateY(DEFAULT_ANNOTATION_Y);
        }

        // Add to centerPane if not already there
        if (!centerPane.getChildren().contains(annotationOverlay)) {
            centerPane.getChildren().add(annotationOverlay);
        }

        // Ensure it's on top and visible
        annotationOverlay.setVisible(true);
        annotationOverlay.toFront();
    }

    private double parseCoordinate(String text, double fallback) {
        if (text == null || text.isBlank()) {
            return fallback;
        }
        try {
            return Double.parseDouble(text.trim());
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    // Getters and setters for annotation state
    public Label getAnnotationOverlay() {
        return annotationOverlay;
    }

    public String getAnnotationText() {
        return annotationText;
    }

    public Color getAnnotationWordColor() {
        return annotationWordColor;
    }

    public boolean isAnnotationEnabled() {
        return annotationEnabled;
    }

    public boolean isAnnotationCustomLocation() {
        return annotationCustomLocation;
    }

    public double getAnnotationX() {
        return annotationX;
    }

    public double getAnnotationY() {
        return annotationY;
    }
}
