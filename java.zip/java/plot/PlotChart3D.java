package plot;

import java.util.function.Consumer;

import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;

/**
 * Manages 3D scene creation and visualization.
 */
public class PlotChart3D {

    /**
     * Creates and displays a 3D scene with rotating spheres.
     */
    public SubScene create3DScene(Consumer<SubScene> onSceneCreated) {
        return create3DScene("trisurface", "solid", onSceneCreated);
    }

    /**
     * Creates a 3D SubScene for the requested demo plot type.
     */
    public SubScene create3DScene(String type, String style, Consumer<SubScene> onSceneCreated) {
        Group root = new Group();

        // Add simple lighting
        javafx.scene.AmbientLight ambient = new javafx.scene.AmbientLight(Color.color(0.6, 0.6, 0.6));
        javafx.scene.PointLight light = new javafx.scene.PointLight(Color.WHITE);
        light.setTranslateX(400);
        light.setTranslateY(-200);
        light.setTranslateZ(-400);
        root.getChildren().addAll(ambient, light);

        String t = type == null ? "" : type.toLowerCase();

        switch (t) {
            case "line3d", "line_3d" -> buildDemo3DLine(root);
            case "scatter3d", "scatter_3d" -> buildDemo3DScatter(root);
            case "trisurface", "surface", "mesh" -> buildDemoSurface(root);
            case "bar3d", "voxel" -> buildDemoVoxels(root);
            case "stem3d", "stem" -> buildDemoStem(root);
            default -> buildDemo3DScatter(root);
        }

        SubScene subScene = new SubScene(root, 900, 600, true, SceneAntialiasing.BALANCED);

        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setTranslateZ(-800);
        camera.setNearClip(0.1);
        camera.setFarClip(5000.0);
        subScene.setCamera(camera);

        // Basic drag rotation (around Y)
        final double[] anchor = new double[2];
        subScene.setOnMousePressed(e -> {
            anchor[0] = e.getSceneX();
            anchor[1] = e.getSceneY();
        });
        subScene.setOnMouseDragged(e -> {
            double dx = e.getSceneX() - anchor[0];
            double dy = e.getSceneY() - anchor[1];
            root.setRotate(root.getRotate() + dx * 0.4);
            anchor[0] = e.getSceneX();
            anchor[1] = e.getSceneY();
        });

        if (onSceneCreated != null) onSceneCreated.accept(subScene);
        return subScene;
    }

    private void buildDemo3DLine(Group root) {
        for (int i = 0; i < 24; i++) {
            Sphere s = new Sphere(6);
            s.setMaterial(new PhongMaterial(Color.ORANGE));
            s.setTranslateX(i * 30 - 300);
            s.setTranslateY(Math.sin(i * 0.3) * 80);
            s.setTranslateZ(Math.cos(i * 0.2) * 60);
            root.getChildren().add(s);
        }
    }

    private void buildDemo3DScatter(Group root) {
        for (int i = 0; i < 80; i++) {
            Sphere s = new Sphere(6);
            s.setMaterial(new PhongMaterial(Color.CORAL));
            s.setTranslateX((Math.random() - 0.5) * 600);
            s.setTranslateY((Math.random() - 0.5) * 300);
            s.setTranslateZ((Math.random() - 0.5) * 400);
            root.getChildren().add(s);
        }
    }

    private void buildDemoSurface(Group root) {
        int w = 40;
        int h = 40;
        float scale = 12f;
        javafx.scene.shape.MeshView mv = createHeightMesh(w, h, scale);
        mv.setTranslateX(-w * scale / 2.0);
        mv.setTranslateZ(-h * scale / 2.0);
        mv.setTranslateY(0);
        mv.setMaterial(new PhongMaterial(Color.LIGHTBLUE));
        root.getChildren().add(mv);
    }

    private void buildDemoVoxels(Group root) {
        for (int x = -3; x <= 3; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    javafx.scene.shape.Box b = new javafx.scene.shape.Box(20, 20, 20);
                    b.setTranslateX(x * 40);
                    b.setTranslateY(y * 40);
                    b.setTranslateZ(z * 40);
                    b.setMaterial(new PhongMaterial(Color.hsb((x+4)*30, 0.6, 0.9, 0.8)));
                    root.getChildren().add(b);
                }
            }
        }
    }

    private void buildDemoStem(Group root) {
        for (int i = -10; i <= 10; i++) {
            javafx.scene.shape.Box stem = new javafx.scene.shape.Box(4, Math.abs(i)*8+8, 4);
            stem.setTranslateX(i * 28);
            stem.setTranslateY(100 - (Math.abs(i)*4));
            stem.setTranslateZ(0);
            stem.setMaterial(new PhongMaterial(Color.DARKCYAN));
            root.getChildren().add(stem);
        }
    }

    private javafx.scene.shape.MeshView createHeightMesh(int w, int h, float scale) {
        javafx.scene.shape.TriangleMesh mesh = new javafx.scene.shape.TriangleMesh();
        for (int y = 0; y <= h; y++) {
            for (int x = 0; x <= w; x++) {
                float vx = x * scale;
                float vz = y * scale;
                float vy = (float)(Math.sin(x*0.3) * Math.cos(y*0.2) * 20);
                mesh.getPoints().addAll(vx, vy, vz);
            }
        }
        mesh.getTexCoords().addAll(0,0);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int p0 = y * (w+1) + x;
                int p1 = p0 + 1;
                int p2 = p0 + (w+1);
                int p3 = p2 + 1;
                mesh.getFaces().addAll(p0,0,p2,0,p1,0);
                mesh.getFaces().addAll(p1,0,p2,0,p3,0);
            }
        }
        javafx.scene.shape.MeshView mv = new javafx.scene.shape.MeshView(mesh);
        return mv;
    }
}
