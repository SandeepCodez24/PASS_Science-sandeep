package plot;

import java.util.function.Consumer;

import javafx.scene.AmbientLight;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.PointLight;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.shape.MeshView;
import javafx.scene.shape.Sphere;
import javafx.scene.shape.TriangleMesh;
import javafx.scene.transform.Rotate;

/**
 * Manages 3D scene creation and visualization.
 */
public class PlotChart3D {

    /** Degrees of rotation per pixel of mouse drag. */
    private static final double DRAG_SENSITIVITY = 0.4;

    /** Tilt limit, so the view can look straight down or up but never flip over. */
    private static final double MAX_TILT = 90.0;

    /**
     * Creates the default 3D demo scene (a solid surface).
     *
     * @param onSceneCreated optional callback receiving the new SubScene
     * @return the SubScene
     */
    public SubScene create3DScene(Consumer<SubScene> onSceneCreated) {
        return create3DScene("trisurface", "solid", onSceneCreated);
    }

    /**
     * Creates a 3D SubScene for the requested demo plot type.
     *
     * <p>
     * Dragging with the mouse orbits the view: horizontal drag turns it around
     * the vertical (Y) axis, vertical drag tilts it around the horizontal (X)
     * axis.
     * </p>
     *
     * @param type           plot type, e.g. {@code "line3d"}, {@code "surface"}
     * @param style          render style (reserved; not used by the demos yet)
     * @param onSceneCreated optional callback receiving the new SubScene
     * @return the SubScene
     */
    public SubScene create3DScene(String type, String style, Consumer<SubScene> onSceneCreated) {
        Group root = new Group();

        // Simple lighting
        AmbientLight ambient = new AmbientLight(Color.color(0.6, 0.6, 0.6));
        PointLight light = new PointLight(Color.WHITE);
        light.setTranslateX(400);
        light.setTranslateY(-200);
        light.setTranslateZ(-400);

        // The plotted content sits in its own group so the orbit rotation turns
        // the data while the lights stay fixed relative to the camera.
        Group content = new Group();
        Rotate tilt = new Rotate(0, Rotate.X_AXIS);
        Rotate turn = new Rotate(0, Rotate.Y_AXIS);
        content.getTransforms().addAll(tilt, turn);

        root.getChildren().addAll(ambient, light, content);

        String t = type == null ? "" : type.toLowerCase();

        switch (t) {
            case "line3d", "line_3d" -> buildDemo3DLine(content);
            case "scatter3d", "scatter_3d" -> buildDemo3DScatter(content);
            case "trisurface", "surface", "mesh" -> buildDemoSurface(content);
            case "bar3d", "voxel" -> buildDemoVoxels(content);
            case "stem3d", "stem" -> buildDemoStem(content);
            default -> buildDemo3DScatter(content);
        }

        SubScene subScene = new SubScene(root, 900, 600, true, SceneAntialiasing.BALANCED);

        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setTranslateZ(-800);
        camera.setNearClip(0.1);
        camera.setFarClip(5000.0);
        subScene.setCamera(camera);

        // Orbit on drag. The old handler computed dy but never used it, and
        // called root.setRotate(), which spins around the Z axis (in the screen
        // plane) rather than around Y as its comment intended.
        final double[] anchor = new double[2];
        subScene.setOnMousePressed(e -> {
            anchor[0] = e.getSceneX();
            anchor[1] = e.getSceneY();
        });
        subScene.setOnMouseDragged(e -> {
            double dx = e.getSceneX() - anchor[0];
            double dy = e.getSceneY() - anchor[1];
            turn.setAngle(turn.getAngle() + dx * DRAG_SENSITIVITY);
            double newTilt = tilt.getAngle() - dy * DRAG_SENSITIVITY;
            tilt.setAngle(Math.max(-MAX_TILT, Math.min(MAX_TILT, newTilt)));
            anchor[0] = e.getSceneX();
            anchor[1] = e.getSceneY();
        });

        if (onSceneCreated != null) {
            onSceneCreated.accept(subScene);
        }
        return subScene;
    }

    private void buildDemo3DLine(Group root) {
        for (int i = 0; i < 24; i++) {
            Sphere s = new Sphere(6);
            s.setMaterial(new PhongMaterial(Color.ORANGE));
            s.setTranslateX(i * 30 - 300);
            s.setTranslateY(Math.sin(i * 0.3) * 80);
            s.setTranslateZ(Math.cos(i * 0.2) * 60);
            root.getChildren().add(s);
        }
    }

    private void buildDemo3DScatter(Group root) {
        for (int i = 0; i < 80; i++) {
            Sphere s = new Sphere(6);
            s.setMaterial(new PhongMaterial(Color.CORAL));
            s.setTranslateX((Math.random() - 0.5) * 600);
            s.setTranslateY((Math.random() - 0.5) * 300);
            s.setTranslateZ((Math.random() - 0.5) * 400);
            root.getChildren().add(s);
        }
    }

    private void buildDemoSurface(Group root) {
        int w = 40;
        int h = 40;
        float scale = 12f;
        MeshView mv = createHeightMesh(w, h, scale);
        mv.setTranslateX(-w * scale / 2.0);
        mv.setTranslateZ(-h * scale / 2.0);
        mv.setTranslateY(0);
        mv.setMaterial(new PhongMaterial(Color.LIGHTBLUE));
        root.getChildren().add(mv);
    }

    private void buildDemoVoxels(Group root) {
        for (int x = -3; x <= 3; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    Box b = new Box(20, 20, 20);
                    b.setTranslateX(x * 40);
                    b.setTranslateY(y * 40);
                    b.setTranslateZ(z * 40);
                    b.setMaterial(new PhongMaterial(Color.hsb((x + 4) * 30, 0.6, 0.9, 0.8)));
                    root.getChildren().add(b);
                }
            }
        }
    }

    private void buildDemoStem(Group root) {
        for (int i = -10; i <= 10; i++) {
            Box stem = new Box(4, Math.abs(i) * 8 + 8, 4);
            stem.setTranslateX(i * 28);
            stem.setTranslateY(100 - (Math.abs(i) * 4));
            stem.setTranslateZ(0);
            stem.setMaterial(new PhongMaterial(Color.DARKCYAN));
            root.getChildren().add(stem);
        }
    }

    private MeshView createHeightMesh(int w, int h, float scale) {
        TriangleMesh mesh = new TriangleMesh();
        for (int y = 0; y <= h; y++) {
            for (int x = 0; x <= w; x++) {
                float vx = x * scale;
                float vz = y * scale;
                float vy = (float) (Math.sin(x * 0.3) * Math.cos(y * 0.2) * 20);
                mesh.getPoints().addAll(vx, vy, vz);
            }
        }
        mesh.getTexCoords().addAll(0, 0);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int p0 = y * (w + 1) + x;
                int p1 = p0 + 1;
                int p2 = p0 + (w + 1);
                int p3 = p2 + 1;
                mesh.getFaces().addAll(p0, 0, p2, 0, p1, 0);
                mesh.getFaces().addAll(p1, 0, p2, 0, p3, 0);
            }
        }
        return new MeshView(mesh);
    }
}
