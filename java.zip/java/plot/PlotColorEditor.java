package plot;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ui.managers.ThemeManager;

/**
 * Handles color selection dialogs and tabbed HSB/RGB/Web color editors.
 */
public class PlotColorEditor {

    private final Stage dialogOwner;

    public PlotColorEditor(Stage dialogOwner) {
        this.dialogOwner = dialogOwner;
    }

    /**
     * Shows the color chooser dialog with tabbed HSB/RGB/Web editor and palette selection.
     */
    public Color showColorChooserDialog(String variable, String initialMode) {
        Color[] selectedColor = {Color.CORNFLOWERBLUE};
        Rectangle newPreview = new Rectangle(68, 34, selectedColor[0]);
        newPreview.setArcWidth(10);
        newPreview.setArcHeight(10);
        newPreview.getStyleClass().add("color-preview-rect");

        Rectangle currentPreview = new Rectangle(68, 34, selectedColor[0]);
        currentPreview.setArcWidth(10);
        currentPreview.setArcHeight(10);
        currentPreview.getStyleClass().add("color-preview-rect");

        Label selectedLabel = new Label(PlotUtilities.colorToHex(selectedColor[0]));

        VBox standardPanel = buildStandardColorPanel(selectedColor, newPreview, currentPreview, selectedLabel);
        VBox customPanel = buildCustomColorPanel(selectedColor, newPreview, currentPreview, selectedLabel);
        VBox upiPanel = buildInnovationColorPanel(selectedColor, newPreview, currentPreview, selectedLabel);

        VBox palettePane;
        String mode = initialMode == null ? "standard" : initialMode.trim().toLowerCase();
        if ("custom".equals(mode)) {
            palettePane = customPanel;
        } else if ("upi".equals(mode)) {
            palettePane = upiPanel;
        } else {
            palettePane = standardPanel;
        }

        ScrollPane paletteScroll = new ScrollPane(palettePane);
        paletteScroll.setFitToWidth(true);
        paletteScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        paletteScroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        paletteScroll.setPrefViewportHeight(190);
        paletteScroll.getStyleClass().add("color-palette-scroll");

        VBox currentBox = new VBox(4, new Label("Current"), currentPreview);
        currentBox.setAlignment(Pos.CENTER);
        
        VBox newBox = new VBox(4, new Label("Background"), newPreview);
        newBox.setAlignment(Pos.CENTER);
        
        HBox previewBox = new HBox(10, currentBox, newBox);
        previewBox.setAlignment(Pos.CENTER);
        
        VBox previewAndLabel = new VBox(4, previewBox, selectedLabel);
        previewAndLabel.setAlignment(Pos.CENTER);

        Button ok = new Button("OK");
        Button cancel = new Button("Cancel");

        HBox actions = new HBox(8, ok, cancel);
        actions.setAlignment(Pos.CENTER_RIGHT);

        VBox box = new VBox(8, paletteScroll, previewAndLabel, actions);
        box.setPadding(new Insets(10));
        box.getStyleClass().add("color-dialog-box");

        Stage colorDialog = new Stage();
        colorDialog.setTitle("Colors");
        colorDialog.initModality(Modality.APPLICATION_MODAL);
        colorDialog.initOwner(dialogOwner);
        Scene scene = new Scene(box, 360, 280);
        ThemeManager.registerScene(scene);
        colorDialog.setScene(scene);

        ok.setOnAction(e -> colorDialog.close());
        cancel.setOnAction(e -> colorDialog.close());

        colorDialog.showAndWait();
        return selectedColor[0];
    }

    private VBox buildStandardColorPanel(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel) {
        // Palette swatches first
        FlowPane swatches = new FlowPane(8, 8);
        swatches.setPrefWrapLength(260);
        swatches.setPadding(new Insets(10));

        Color[] palette = {
                Color.web("#1f77b4"), Color.web("#2ca02c"), Color.web("#d62728"), Color.web("#ff7f0e"),
                Color.web("#9467bd"), Color.web("#17becf"), Color.web("#8c564b"), Color.web("#7f7f7f"),
                Color.web("#bcbd22"), Color.web("#e377c2"), Color.web("#0aa6a6"), Color.web("#264653"),
                Color.web("#FF6B6B"), Color.web("#F06595"), Color.web("#CC5DE8"), Color.web("#845EF7"),
                Color.web("#5C7CFA"), Color.web("#339AF0"), Color.web("#22B8CF"), Color.web("#20C997"),
                Color.web("#51CF66"), Color.web("#94D82D"), Color.web("#FCC419"), Color.web("#FF922B"),
                Color.web("#E8590C"), Color.web("#CED4DA"), Color.web("#ADB5BD"), Color.web("#868E96"),
                Color.web("#495057"), Color.web("#343A40"), Color.web("#212529"), Color.web("#000000"),
                Color.web("#ffffff")
        };

        for (Color color : palette) {
            swatches.getChildren().add(buildPaletteSwatch(color, selectedColor, newPreview, currentPreview, selectedLabel));
        }

        Label standardLabel = new Label("Standard palette");
        var standardIcon = PlotUtilities.loadIcon("/icons/standard.png");
        if (standardIcon != null) {
            ImageView icon = new ImageView(standardIcon);
            icon.setFitWidth(16);
            icon.setFitHeight(16);
            standardLabel.setGraphic(icon);
        }
        
        // HSB/RGB/Web tab interface below
        VBox hsbPanel = buildHsbOpacityPanel(selectedColor, newPreview, currentPreview, selectedLabel, "Standard");
        
        VBox leftPanel = new VBox(8,
                standardLabel,
                swatches,
                hsbPanel);

        StackPane layout = new StackPane(leftPanel);
        StackPane.setAlignment(leftPanel, Pos.TOP_LEFT);

        VBox content = new VBox(layout);
        content.setPadding(new Insets(8));
        content.getStyleClass().add("color-panel-content");

        return content;
    }

    private VBox buildCustomColorPanel(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel) {
        Label customLabel = new Label("Custom color");
        var customIcon = PlotUtilities.loadIcon("/icons/custom.png");
        if (customIcon != null) {
            ImageView icon = new ImageView(customIcon);
            icon.setFitWidth(16);
            icon.setFitHeight(16);
            customLabel.setGraphic(icon);
        }
        
        ColorPicker picker = new ColorPicker(selectedColor[0]);

        Rectangle customPreview = new Rectangle(68, 34, selectedColor[0]);
        customPreview.setArcWidth(10);
        customPreview.setArcHeight(10);
        customPreview.getStyleClass().add("color-preview-rect");

        picker.setOnAction(e -> {
            updateSelectedColor(selectedColor, newPreview, selectedLabel, picker.getValue());
            customPreview.setFill(picker.getValue());
        });

        Button useColor = new Button("Use this color");
        useColor.setOnAction(e -> {
            updateSelectedColor(selectedColor, newPreview, selectedLabel, picker.getValue());
            customPreview.setFill(picker.getValue());
        });

        // HSB/RGB/Web tab interface below
        VBox hsbPanel = buildHsbOpacityPanel(selectedColor, newPreview, currentPreview, selectedLabel, "Custom");
        
        VBox leftPanel = new VBox(8,
                customLabel,
                picker,
                new HBox(10, new Label("Preview"), customPreview),
                useColor,
                hsbPanel);

        StackPane layout = new StackPane(leftPanel);
        StackPane.setAlignment(leftPanel, Pos.TOP_LEFT);

        VBox content = new VBox(layout);
        content.setPadding(new Insets(8));
        content.getStyleClass().add("color-panel-content");

        return content;
    }

    private VBox buildInnovationColorPanel(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel) {
        Label upiLabel = new Label("UPI palette");
        var upiIcon = PlotUtilities.loadIcon("/icons/upi.png");
        if (upiIcon != null) {
            ImageView icon = new ImageView(upiIcon);
            icon.setFitWidth(16);
            icon.setFitHeight(16);
            upiLabel.setGraphic(icon);
        }
        
        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(8);
        grid.setPadding(new Insets(10));

        Color[] innovationPalette = {
                Color.web("#0b1f3a"), Color.web("#164a8a"), Color.web("#2a9d8f"), Color.web("#6c63ff"),
                Color.web("#f4a261"), Color.web("#e76f51"), Color.web("#06d6a0"), Color.web("#118ab2"),
                Color.web("#8338ec"), Color.web("#ff006e"), Color.web("#ffd166"), Color.web("#073b4c"),
                Color.web("#1d3557"), Color.web("#457b9d"), Color.web("#a8dadc"), Color.web("#2b2d42"),
                Color.web("#ef476f"), Color.web("#f78c6b"), Color.web("#06b6d4"), Color.web("#3a86ff"),
                Color.web("#00a896"), Color.web("#38b000"), Color.web("#ffbe0b"), Color.web("#fb5607"),
                Color.web("#ffffff")
        };

        int col = 0;
        int row = 0;
        for (Color color : innovationPalette) {
            grid.add(buildPaletteSwatch(color, selectedColor, newPreview, currentPreview, selectedLabel), col, row);
            col++;
            if (col == 4) {
                col = 0;
                row++;
            }
        }
        
        // HSB/RGB/Web tab interface below
        VBox hsbPanel = buildHsbOpacityPanel(selectedColor, newPreview, currentPreview, selectedLabel, "UPI");
        
        VBox leftPanel = new VBox(6,
                upiLabel,
                grid,
                new Label("Creative colors picked for the app's own visual style."),
                hsbPanel);

        StackPane layout = new StackPane(leftPanel);
        StackPane.setAlignment(leftPanel, Pos.TOP_LEFT);

        VBox content = new VBox(layout);
        content.setPadding(new Insets(8));
        content.getStyleClass().add("color-panel-content");

        return content;
    }

    private VBox buildHsbOpacityPanel(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel, String modeName) {
        Color base = selectedColor[0] == null ? Color.CORNFLOWERBLUE : selectedColor[0];

        if (currentPreview != null) currentPreview.setFill(base);

        VBox hsbPanel = buildHsbTabContent(selectedColor, newPreview, currentPreview, selectedLabel, modeName, base);
        VBox rgbPanel = buildRgbTabContent(selectedColor, newPreview, currentPreview, selectedLabel, modeName, base);
        VBox webPanel = buildWebTabContent(selectedColor, newPreview, currentPreview, selectedLabel, modeName, base);

        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabs.getTabs().addAll(
                new Tab("HSB", hsbPanel),
                new Tab("RGB", rgbPanel),
                new Tab("Web", webPanel));
        tabs.setMaxWidth(300);
        tabs.setMinHeight(175);
        tabs.setStyle("-fx-font-size:12;");

        VBox panel = new VBox(4, tabs);
        panel.setPadding(new Insets(4));
        panel.setMaxWidth(300);
        panel.getStyleClass().add("color-hsb-panel");
        return panel;
    }

    private VBox buildHsbTabContent(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel, String modeName, Color base) {
        Label title = new Label(modeName + " HSB");

        Slider hue = new Slider(0, 360, base.getHue());
        Slider saturation = new Slider(0, 100, base.getSaturation() * 100);
        Slider brightness = new Slider(0, 100, base.getBrightness() * 100);
        Slider opacity = new Slider(0, 100, base.getOpacity() * 100);

        TextField hueValue = new TextField(String.valueOf((int) Math.round(hue.getValue())));
        TextField saturationValue = new TextField(String.valueOf((int) Math.round(saturation.getValue())));
        TextField brightnessValue = new TextField(String.valueOf((int) Math.round(brightness.getValue())));
        TextField opacityValue = new TextField(String.valueOf((int) Math.round(opacity.getValue())));

        Runnable updateColor = () -> {
            Color updated = Color.hsb(
                hue.getValue(),
                saturation.getValue() / 100.0,
                brightness.getValue() / 100.0,
                opacity.getValue() / 100.0);
            updateSelectedColor(selectedColor, newPreview, selectedLabel, updated);
        };

        bindSliderAndField(hue, hueValue, 0, 360, updateColor);
        bindSliderAndField(saturation, saturationValue, 0, 100, updateColor);
        bindSliderAndField(brightness, brightnessValue, 0, 100, updateColor);
        bindSliderAndField(opacity, opacityValue, 0, 100, updateColor);

        VBox content = new VBox(3,
                title,
                buildSliderRow("Hue", hue, hueValue, "deg"),
                buildSliderRow("Saturation", saturation, saturationValue, "%"),
                buildSliderRow("Brightness", brightness, brightnessValue, "%"),
                buildSliderRow("Opacity", opacity, opacityValue, "%"));
        content.setStyle("-fx-font-size:11;");
        return content;
    }

    private VBox buildRgbTabContent(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel, String modeName, Color base) {
        Label title = new Label(modeName + " RGB");

        Slider red = new Slider(0, 255, Math.round(base.getRed() * 255));
        Slider green = new Slider(0, 255, Math.round(base.getGreen() * 255));
        Slider blue = new Slider(0, 255, Math.round(base.getBlue() * 255));
        Slider opacity = new Slider(0, 100, Math.round(base.getOpacity() * 100));

        TextField redValue = new TextField(String.valueOf((int) Math.round(red.getValue())));
        TextField greenValue = new TextField(String.valueOf((int) Math.round(green.getValue())));
        TextField blueValue = new TextField(String.valueOf((int) Math.round(blue.getValue())));
        TextField opacityValue = new TextField(String.valueOf((int) Math.round(opacity.getValue())));

        Runnable updateColor = () -> {
            Color updated = Color.rgb(
                    (int) Math.round(red.getValue()),
                    (int) Math.round(green.getValue()),
                    (int) Math.round(blue.getValue()),
                    opacity.getValue() / 100.0);
            updateSelectedColor(selectedColor, newPreview, selectedLabel, updated);
        };

        bindSliderAndField(red, redValue, 0, 255, updateColor);
        bindSliderAndField(green, greenValue, 0, 255, updateColor);
        bindSliderAndField(blue, blueValue, 0, 255, updateColor);
        bindSliderAndField(opacity, opacityValue, 0, 100, updateColor);

        VBox content = new VBox(3,
                title,
                buildSliderRow("Red", red, redValue, ""),
                buildSliderRow("Green", green, greenValue, ""),
                buildSliderRow("Blue", blue, blueValue, ""),
                buildSliderRow("Opacity", opacity, opacityValue, "%"));
        content.setStyle("-fx-font-size:11;");
        return content;
    }

    private VBox buildWebTabContent(Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel, String modeName, Color base) {
        Label title = new Label(modeName + " Web");

        TextField hexField = new TextField(PlotUtilities.colorToHex(base));
        TextField opacityField = new TextField(String.valueOf((int) Math.round(base.getOpacity() * 100)));
        Label helper = new Label("Use #RRGGBB and opacity 0-100.");
        helper.getStyleClass().add("color-helper");

        Runnable applyWeb = () -> {
            try {
                String web = hexField.getText() == null ? "" : hexField.getText().trim();
                if (!web.startsWith("#")) {
                    web = "#" + web;
                }

                double opacity = Double.parseDouble(opacityField.getText().trim());
                double opacityClamped = Math.max(0, Math.min(100, opacity));
                Color parsed = Color.web(web, opacityClamped / 100.0);
                opacityField.setText(String.valueOf((int) Math.round(opacityClamped)));
                updateSelectedColor(selectedColor, newPreview, selectedLabel, parsed);
            } catch (RuntimeException ex) {
                hexField.setText(PlotUtilities.colorToHex(selectedColor[0] == null ? Color.CORNFLOWERBLUE : selectedColor[0]));
                opacityField.setText(String.valueOf((int) Math.round((selectedColor[0] == null ? 1.0 : selectedColor[0].getOpacity()) * 100)));
            }
        };

        Button apply = new Button("Apply Web Color");
        apply.setOnAction(e -> applyWeb.run());
        hexField.setOnAction(e -> applyWeb.run());
        opacityField.setOnAction(e -> applyWeb.run());

        HBox webRow = new HBox(8, new Label("Web:"), hexField);
        webRow.setAlignment(Pos.CENTER_LEFT);
        HBox opacityRow = new HBox(8, new Label("Opacity %:"), opacityField);
        opacityRow.setAlignment(Pos.CENTER_LEFT);

        hexField.setPrefWidth(104);
        opacityField.setPrefWidth(56);

        VBox content = new VBox(4, title, webRow, opacityRow, apply, helper);
        content.setStyle("-fx-font-size:11;");
        return content;
    }

    private HBox buildSliderRow(String labelText, Slider slider, TextField valueField, String suffix) {
        Label label = new Label(labelText + ":");
        label.setMinWidth(46);

        slider.setPrefWidth(94);
        valueField.setPrefWidth(32);
        valueField.setMaxWidth(32);
        slider.setMinWidth(94);

        Label unit = new Label(suffix);
        unit.setMinWidth(18);

        HBox row = new HBox(5, label, slider, valueField, unit);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private void bindSliderAndField(Slider slider, TextField field, double min, double max, Runnable onChange) {
        slider.valueProperty().addListener((obs, oldVal, newVal) -> {
            field.setText(String.valueOf((int) Math.round(newVal.doubleValue())));
            onChange.run();
        });

        field.setOnAction(e -> applyFieldToSlider(field, slider, min, max));
        field.focusedProperty().addListener((obs, hadFocus, hasFocus) -> {
            if (!hasFocus) {
                applyFieldToSlider(field, slider, min, max);
            }
        });
    }

    private void applyFieldToSlider(TextField field, Slider slider, double min, double max) {
        try {
            double parsed = Double.parseDouble(field.getText().trim());
            double clamped = Math.max(min, Math.min(max, parsed));
            slider.setValue(clamped);
        } catch (NumberFormatException ex) {
            field.setText(String.valueOf((int) Math.round(slider.getValue())));
        }
    }

    private Button buildPaletteSwatch(Color color, Color[] selectedColor, Rectangle newPreview, Rectangle currentPreview, Label selectedLabel) {
        Button swatch = new Button();
        swatch.setPrefSize(20, 20);
        swatch.setMinSize(20, 20);
        swatch.setMaxSize(20, 20);
        swatch.setStyle("-fx-background-color: " + PlotUtilities.colorToHex(color) + "; -fx-background-radius: 6; -fx-border-radius: 6;");
        swatch.getStyleClass().add("palette-swatch");
        swatch.setOnAction(e -> updateSelectedColor(selectedColor, newPreview, selectedLabel, color));
        return swatch;
    }

    private void updateSelectedColor(Color[] selectedColor, Rectangle newPreview, Label selectedLabel, Color color) {
        selectedColor[0] = color;
        if (newPreview != null) newPreview.setFill(color);
        selectedLabel.setText(PlotUtilities.colorToHex(color));
    }
}
