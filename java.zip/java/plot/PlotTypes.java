package plot;

import java.util.List;
import java.util.function.Consumer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;

/**
 * Vibrant color palette for plot type glyphs.
 */
/* package */
final class PlotPalette {
    static final String[] COLORS = new String[]{
            "#E53935", // red
            "#FB8C00", // orange
            "#FDD835", // yellow
            "#43A047", // green
            "#00ACC1", // teal
            "#1E88E5", // blue
            "#5E35B1", // indigo/purple
            "#D81B60", // magenta
            "#EC407A", // pink
            "#8BC34A", // light green
            "#00BCD4", // cyan
            "#FF7043"  // deep orange
    };
}

/**
 * Manages plot type selection strip and buttons.
 */
public class PlotTypes {

    private ScrollPane typesStrip;

    /**
     * Builds the scrollable plot types strip with all available plot type buttons.
     */
    public ScrollPane buildTypesStrip(Consumer<String> onTypeSelected) {
        HBox row = new HBox(8);
        row.setPadding(new Insets(6, 8, 6, 8));
        row.setAlignment(Pos.CENTER_LEFT);

        List<String> plotNames = List.of(
            "Plot", "Area", "Fill", "Stack Plot", "Bar Chart", "Histogram", "Errorbar",
            "Scatter", "Bubble", "Violin", "Box Plot", "Contour", "Heatmap", "Polar",
            "Pie Chart", "Vector Field", "Innovation Plot", "Surf", "Mesh", "Quiver",
            "Stem", "Stairs", "Semilog X", "Semilog Y", "Log Log");

        for (int i = 0; i < plotNames.size(); i++) {
            String name = plotNames.get(i);
            row.getChildren().add(buildPlotTypeButton(name, onTypeSelected, i));
        }

        row.getChildren().add(buildCustomPlotButton(onTypeSelected));

        typesStrip = new ScrollPane(row);
        typesStrip.setFitToHeight(true);
        typesStrip.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        typesStrip.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        typesStrip.getStyleClass().add("plot-types-strip");
        typesStrip.setVisible(false);
        typesStrip.setManaged(false);
        return typesStrip;
    }

    /**
     * Creates a single plot type button with glyph and text.
     */
    private Button buildPlotTypeButton(String displayName, Consumer<String> onTypeSelected, int index) {
        String type = PlotUtilities.normalizePlotType(displayName);
        // Prefer the original glyph look (colored symbol). If a real image icon exists
        // (not the placeholder returned by the loader), use it instead.
        Label glyph = new Label(PlotUtilities.getPlotGlyph(type));
        String color = PlotPalette.COLORS[index % PlotPalette.COLORS.length];
        glyph.getStyleClass().add("plot-type-glyph");
        glyph.setStyle("-fx-text-fill: " + color + "; -fx-font-size:18;");

        Button button = new Button(displayName, glyph);
        button.setContentDisplay(ContentDisplay.TOP);
        button.setAlignment(Pos.CENTER);
        button.setWrapText(true);
        button.setPrefSize(82, 72);
        button.getStyleClass().add("plot-type-button");
        // ensure clicked type stays visually selected
        button.setOnAction(e -> {
            try {
                if (button.getParent() instanceof HBox) {
                    HBox parent = (HBox) button.getParent();
                    for (javafx.scene.Node n : parent.getChildren()) {
                        if (n instanceof Button) {
                            ((Button) n).getStyleClass().remove("type-selected");
                        }
                    }
                }
            } catch (Exception ex) {
                // ignore
            }
            if (!button.getStyleClass().contains("type-selected")) button.getStyleClass().add("type-selected");
            onTypeSelected.accept(type);
        });
        return button;
    }

    private Button buildCustomPlotButton(Consumer<String> onTypeSelected) {
        Circle backdrop = new Circle(16);
        backdrop.setFill(javafx.scene.paint.Color.web("#D9D9D9"));

        Label glyph = new Label("+");
        glyph.getStyleClass().add("plot-type-glyph");
        glyph.setStyle("-fx-text-fill: black; -fx-font-size:22; -fx-font-weight:bold;");

        StackPane icon = new StackPane(backdrop, glyph);
        icon.setMinSize(34, 34);
        icon.setPrefSize(34, 34);
        icon.setMaxSize(34, 34);

        Button button = new Button("", icon);
        button.setContentDisplay(ContentDisplay.TOP);
        button.setAlignment(Pos.CENTER);
        button.setWrapText(false);
        button.setPrefSize(82, 72);
        button.getStyleClass().add("plot-type-button");
        button.setOnAction(e -> {
            try {
                if (button.getParent() instanceof HBox) {
                    HBox parent = (HBox) button.getParent();
                    for (javafx.scene.Node n : parent.getChildren()) {
                        if (n instanceof Button) {
                            ((Button) n).getStyleClass().remove("type-selected");
                        }
                    }
                }
            } catch (Exception ex) {
                // ignore
            }
            if (!button.getStyleClass().contains("type-selected")) button.getStyleClass().add("type-selected");
            onTypeSelected.accept("custom");
        });
        return button;
    }

    /**
     * Toggles visibility of the types strip.
     */
    public void toggleTypesStrip() {
        if (typesStrip == null) return;
        boolean show = !typesStrip.isVisible();
        typesStrip.setVisible(show);
        typesStrip.setManaged(show);
    }

    /**
     * Shows the types strip.
     */
    public void showTypesStrip() {
        if (typesStrip == null) return;
        typesStrip.setVisible(true);
        typesStrip.setManaged(true);
    }

    /**
     * Hides the types strip.
     */
    public void hideTypesStrip() {
        if (typesStrip == null) return;
        typesStrip.setVisible(false);
        typesStrip.setManaged(false);
        try {
            if (typesStrip.getContent() instanceof HBox) {
                HBox row = (HBox) typesStrip.getContent();
                for (javafx.scene.Node n : row.getChildren()) {
                    if (n instanceof Button) {
                        ((Button) n).getStyleClass().remove("type-selected");
                    }
                }
            }
        } catch (Exception ex) {
            // ignore
        }
    }
}
