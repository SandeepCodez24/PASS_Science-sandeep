package plot;

import java.util.function.Consumer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

/**
 * Manages the color mode selection strip (Standard, Custom, UPI, Colors).
 */
public class PlotColorStrip {

    private HBox colorStrip;

    /**
     * Builds the color mode selection strip with toggle buttons.
     */
    public HBox buildColorStrip(Consumer<String> onModeSelected) {
        ToggleGroup colorGroup = new ToggleGroup();

        ToggleButton standard = buildColorTab("Standard", "/icons/standard.png", colorGroup,
                () -> onModeSelected.accept("Standard"));

        ToggleButton custom = buildColorTab("Custom", "/icons/custom.png", colorGroup,
                () -> onModeSelected.accept("Custom"));

        ToggleButton upi = buildColorTab("UPI", "/icons/upi.png", colorGroup, () -> onModeSelected.accept("UPI"));

        // Display 'Background' near the UPI button, but keep mode string 'Colors'
        ToggleButton colors = buildColorTab("Background", "/icons/background.png", colorGroup,
                () -> onModeSelected.accept("Colors"));

        // Ensure the selected toggle has a visible boxed style class
        colorGroup.selectedToggleProperty().addListener((obs, oldT, newT) -> {
            try {
                for (var t : new ToggleButton[] { standard, custom, upi, colors }) {
                    t.getStyleClass().remove("color-selected");
                    t.getStyleClass().remove("nav-selected");
                    t.getStyleClass().remove("debug-visible");
                }
                if (newT instanceof ToggleButton) {
                    ToggleButton tb = (ToggleButton) newT;
                    if (!tb.getStyleClass().contains("color-selected"))
                        tb.getStyleClass().add("color-selected");
                    if (!tb.getStyleClass().contains("nav-selected"))
                        tb.getStyleClass().add("nav-selected");
                    if (!tb.getStyleClass().contains("debug-visible"))
                        tb.getStyleClass().add("debug-visible");
                }
            } catch (Exception ex) {
                // ignore
            }
        });

        colorStrip = new HBox(6, standard, custom, upi, colors);
        colorStrip.setPadding(new Insets(6, 8, 6, 8));
        colorStrip.setAlignment(Pos.CENTER_LEFT);
        // Let CSS handle the background so it can match the annotation/toolbar box
        colorStrip.getStyleClass().add("plot-color-strip");
        colorStrip.getStyleClass().add("plot-annotation-box");
        colorStrip.setVisible(false);
        colorStrip.setManaged(false);
        return colorStrip;
    }

    /**
     * Programmatically select a color mode so the corresponding toggle appears
     * boxed.
     * Accepts "Standard", "Custom", "UPI", or "Colors" (Background).
     */
    public void selectMode(String mode) {
        if (colorStrip == null || mode == null)
            return;
        String m = mode.trim().toLowerCase();
        for (javafx.scene.Node n : colorStrip.getChildren()) {
            if (n instanceof ToggleButton tb) {
                String txt = tb.getText() == null ? "" : tb.getText().trim().toLowerCase();
                boolean match = txt.equals(m) || (m.equals("colors") && txt.equals("background"));
                if (match) {
                    tb.setSelected(true);
                    if (!tb.getStyleClass().contains("color-selected"))
                        tb.getStyleClass().add("color-selected");
                    if (!tb.getStyleClass().contains("nav-selected"))
                        tb.getStyleClass().add("nav-selected");
                    if (!tb.getStyleClass().contains("debug-visible"))
                        tb.getStyleClass().add("debug-visible");
                } else {
                    tb.setSelected(false);
                    tb.getStyleClass().remove("color-selected");
                    tb.getStyleClass().remove("nav-selected");
                    tb.getStyleClass().remove("debug-visible");
                }
            }
        }
    }

    /**
     * Creates a single color mode toggle button with icon.
     */
    private ToggleButton buildColorTab(String text, String iconPath, ToggleGroup group, Runnable action) {
        ToggleButton tab = new ToggleButton(text);

        // Load and set icon if available
        if (iconPath != null) {
            try {
                var iconImage = PlotUtilities.loadIcon(iconPath);
                if (iconImage != null) {
                    ImageView icon = new ImageView(iconImage);
                    icon.setFitWidth(16);
                    icon.setFitHeight(16);
                    tab.setGraphic(icon);
                }
            } catch (Exception ex) {
                // Icon failed to load, continue without it
            }
        }

        tab.setToggleGroup(group);
        tab.setFocusTraversable(false);
        tab.setPrefHeight(30);
        tab.setMinHeight(30);
        // Use the existing toolbar style so color toggles match Axis buttons.
        tab.getStyleClass().add("toolbar-compact-button");
        tab.setOnAction(e -> {
            try {
                // clear selection class from siblings
                for (javafx.scene.Node n : tab.getToggleGroup().getToggles().stream().map(t -> (javafx.scene.Node) t)
                        .toList()) {
                    if (n instanceof ToggleButton tb)
                        tb.getStyleClass().remove("color-selected");
                }
            } catch (Exception ex) {
                // fallback: iterate container children later
            }
            if (!tab.getStyleClass().contains("color-selected"))
                tab.getStyleClass().add("color-selected");
            if (!tab.getStyleClass().contains("nav-selected"))
                tab.getStyleClass().add("nav-selected");
            // force debug-visible class so the debug CSS rules apply clearly
            if (!tab.getStyleClass().contains("debug-visible"))
                tab.getStyleClass().add("debug-visible");
            action.run();
        });
        return tab;
    }

    /**
     * Shows the color strip.
     */
    public void showColorStrip() {
        if (colorStrip == null)
            return;
        colorStrip.setVisible(true);
        colorStrip.setManaged(true);
    }

    /**
     * Toggles visibility of the color strip.
     */
    public void toggleColorStrip() {
        if (colorStrip == null)
            return;
        if (colorStrip.isVisible()) {
            hideColorStrip();
        } else {
            showColorStrip();
        }
    }

    public void hideColorStrip() {
        if (colorStrip == null)
            return;
        colorStrip.setVisible(false);
        colorStrip.setManaged(false);
    }

    // (hideColorStrip already defined above)

}
