package plot;

import java.util.function.Consumer;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Labeled;
import javafx.scene.control.ToolBar;

/**
 * Manages toolbar creation and styling for the plot window.
 */
public class PlotToolbar {

    private Button typesButton;
    private Button colorsButton;

    /**
     * Builds the main plot window toolbar with all menu buttons and toggles.
     */
    public ToolBar buildToolbar(Button axisButton, Button menu2D, Button menu3D,
            Button gridMenu, Button annotationButton, Button saveMenu,
            Consumer<Void> onTypesClick, Consumer<Void> onColorsClick,
            Consumer<Void> onMenuShow) {

        typesButton = buildTypesButton(onTypesClick);
        colorsButton = buildColorButton(onColorsClick);
        Button colorButton = colorsButton;

        Labeled[] controls = new Labeled[] {
                typesButton,
                colorsButton,

                axisButton,
                menu2D,
                menu3D,
                gridMenu,
                annotationButton,
                saveMenu
        };

        // Hide strips when menus open
        menu2D.addEventHandler(ActionEvent.ACTION, e -> {
            selectToolbarControl(menu2D, controls);
            onMenuShow.accept(null);
        });
        menu3D.addEventHandler(ActionEvent.ACTION, e -> {
            selectToolbarControl(menu3D, controls);
            onMenuShow.accept(null);
        });
        gridMenu.addEventHandler(ActionEvent.ACTION, e -> {
            selectToolbarControl(gridMenu, controls);
            onMenuShow.accept(null);
        });
        saveMenu.addEventHandler(ActionEvent.ACTION, e -> {
            selectToolbarControl(saveMenu, controls);
        });

        typesButton.addEventHandler(ActionEvent.ACTION, e -> selectToolbarControl(typesButton, controls));
        colorButton.addEventHandler(ActionEvent.ACTION, e -> selectToolbarControl(colorButton, controls));
        axisButton.addEventHandler(ActionEvent.ACTION, e -> selectToolbarControl(axisButton, controls));
        annotationButton.addEventHandler(ActionEvent.ACTION, e -> selectToolbarControl(annotationButton, controls));

        ToolBar tb = new ToolBar(
                typesButton,
                colorsButton,

                axisButton,
                menu2D,
                menu3D,
                gridMenu,
                annotationButton,
                saveMenu);

        tb.setStyle("-fx-background-color:#0aa6a6;");
        styleFlatToolbarControl(typesButton);
        styleFlatToolbarControl(colorButton);
        styleFlatToolbarControl(axisButton);
        styleFlatToolbarControl(menu2D);
        styleFlatToolbarControl(menu3D);
        styleFlatToolbarControl(gridMenu);
        styleFlatToolbarControl(annotationButton);
        styleFlatToolbarControl(saveMenu);
        return tb;
    }

    public Button getTypesButton() {
        return typesButton;
    }

    public Button getColorsButton() {
        return colorsButton;
    }

    public void selectToolbarControlForButton(Button selected) {
        // reselect using the same internal style logic; only one should be active
        if (selected == null)
            return;
        // Build the list from the 2 known buttons + others are styled by the existing
        // handler
        // Types/Cos are the ones PlotWindowLayoutCore currently needs.
        if (typesButton != null) {
            if (typesButton == selected)
                styleSelectedToolbarControl(typesButton);
            else
                styleFlatToolbarControl(typesButton);
        }
        if (colorsButton != null) {
            if (colorsButton == selected)
                styleSelectedToolbarControl(colorsButton);
            else
                styleFlatToolbarControl(colorsButton);
        }
    }

    private static void selectToolbarControl(Labeled selected, Labeled[] controls) {
        for (Labeled control : controls) {
            if (control == null) {
                continue;
            }

            if (control == selected) {
                styleSelectedToolbarControl(control);
            } else {
                styleFlatToolbarControl(control);
            }
        }
    }

    private static String accentFor(Labeled control) {
        String text = control == null || control.getText() == null ? "" : control.getText().trim().toLowerCase();
        return switch (text) {
            case "axis" -> "rgba(255, 209, 102, 0.34)";
            case "types" -> "rgba(46, 196, 182, 0.34)";
            case "colors" -> "rgba(239, 71, 111, 0.34)";
            case "2d" -> "rgba(142, 202, 230, 0.34)";
            case "3d" -> "rgba(255, 183, 3, 0.34)";
            case "grid" -> "rgba(168, 218, 220, 0.34)";
            case "annotation" -> "rgba(203, 180, 227, 0.34)";
            case "save" -> "rgba(144, 190, 109, 0.34)";
            default -> "rgba(255, 255, 255, 0.22)";
        };
    }

    /**
     * Creates the Types toggle button.
     */
    private Button buildTypesButton(Consumer<Void> onAction) {
        Button typesButton = new Button("Types");
        typesButton.setOnAction(e -> onAction.accept(null));
        return typesButton;
    }

    /**
     * Creates the Colors toggle button.
     */
    private Button buildColorButton(Consumer<Void> onAction) {
        Button colorButton = new Button("Colors");
        colorButton.setOnAction(e -> onAction.accept(null));
        return colorButton;
    }

    /**
     * Applies flat, borderless toolbar styling to a control.
     */
    public static void styleFlatToolbarControl(Labeled control) {
        control.setStyle("""
                -fx-background-color: transparent;
                -fx-border-color: transparent;
                -fx-border-width: 0;
                -fx-background-radius: 0;
                -fx-border-radius: 0;
                -fx-text-fill: black;
                -fx-font-weight: bold;
                """);
    }

    private static void styleSelectedToolbarControl(Labeled control) {
        control.setStyle("""
                -fx-background-color: %s;
                -fx-background-radius: 6;
                -fx-border-color: rgba(255, 255, 255, 0.40);
                -fx-border-radius: 6;
                -fx-border-width: 1;
                -fx-text-fill: black;
                -fx-font-weight: bold;
                """.formatted(accentFor(control)));
    }
}