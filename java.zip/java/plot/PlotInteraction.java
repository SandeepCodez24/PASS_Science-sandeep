package plot;

import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

/**
 * Manages zoom and pan interactions for the plot chart.
 */
public class PlotInteraction {

    private final XYChart<Number, Number> chart;
    private final NumberAxis xAxis;
    private final NumberAxis yAxis;

    public PlotInteraction(XYChart<Number, Number> chart, NumberAxis xAxis, NumberAxis yAxis) {
        this.chart = chart;
        this.xAxis = xAxis;
        this.yAxis = yAxis;
    }

    /**
     * Enables scroll wheel zoom functionality on the chart.
     */
    public void enableZoom() {
        chart.setOnScroll(event -> {
            double zoomFactor = (event.getDeltaY() > 0) ? 0.9 : 1.1;

            double xRange = xAxis.getUpperBound() - xAxis.getLowerBound();
            double yRange = yAxis.getUpperBound() - yAxis.getLowerBound();

            double xCenter = (xAxis.getUpperBound() + xAxis.getLowerBound()) / 2;
            double yCenter = (yAxis.getUpperBound() + yAxis.getLowerBound()) / 2;

            double newXRange = xRange * zoomFactor;
            double newYRange = yRange * zoomFactor;

            if (newXRange < 1 || newYRange < 1)
                return;

            xAxis.setLowerBound(xCenter - newXRange / 2);
            xAxis.setUpperBound(xCenter + newXRange / 2);

            yAxis.setLowerBound(yCenter - newYRange / 2);
            yAxis.setUpperBound(yCenter + newYRange / 2);
        });
    }

    /**
     * Enables mouse drag panning functionality on the chart.
     */
    public void enablePan() {
        final double[] anchor = new double[2];

        chart.setOnMousePressed(e -> {
            anchor[0] = e.getX();
            anchor[1] = e.getY();
        });

        chart.setOnMouseDragged(e -> {
            double deltaX = e.getX() - anchor[0];
            double deltaY = e.getY() - anchor[1];

            xAxis.setLowerBound(xAxis.getLowerBound() - deltaX);
            xAxis.setUpperBound(xAxis.getUpperBound() - deltaX);

            yAxis.setLowerBound(yAxis.getLowerBound() + deltaY);
            yAxis.setUpperBound(yAxis.getUpperBound() + deltaY);

            anchor[0] = e.getX();
            anchor[1] = e.getY();
        });
    }

    /**
     * Enable clicking on the chart to show the data coordinates via the annotation overlay.
     */
    public void enableClickToShowCoordinates(PlotAnnotation annotation) {
        if (annotation == null) return;

        chart.setOnMouseClicked(e -> {
            try {
                Node plotBackground = chart.lookup(".chart-plot-background");
                if (plotBackground == null) return;

                Bounds bounds = plotBackground.localToScene(plotBackground.getBoundsInLocal());
                double px = e.getSceneX() - bounds.getMinX();
                double py = e.getSceneY() - bounds.getMinY();

                    if (px < 0 || py < 0 || px > bounds.getWidth() || py > bounds.getHeight()) {
                    Platform.runLater(() -> annotation.hideCoordinateAnnotation());
                    return;
                }

                double xData = xAxis.getLowerBound() + (px / bounds.getWidth()) * (xAxis.getUpperBound() - xAxis.getLowerBound());
                double yData = yAxis.getLowerBound() + ((bounds.getHeight() - py) / bounds.getHeight()) * (yAxis.getUpperBound() - yAxis.getLowerBound());

                Platform.runLater(() -> annotation.showCoordinateAnnotation(xData, yData));
            } catch (Exception ignore) {
            }
        });
    }
}
