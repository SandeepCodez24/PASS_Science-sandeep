package plot;

import javafx.scene.canvas.GraphicsContext;

public class GridRenderer {

    public static void drawGrid(GraphicsContext gc,
            GridSettings settings,
            double width,
            double height) {

        if (!settings.isEnabled())
            return;

        // APPLY LINE STYLE
        String style = settings.getLineStyle();

        switch (style) {
            case "Dashed":
                gc.setLineDashes(8, 4);
                break;

            case "Dotted":
                gc.setLineDashes(2, 2);
                break;

            case "Dash-dot":
                gc.setLineDashes(8, 4, 2, 4);
                break;

            case "None":
                return;

            default:
                gc.setLineDashes(null);
        }

        double spacing = settings.getSpacing();

        // vertical lines
        for (double x = settings.getMin(); x <= settings.getMax(); x += spacing) {
            double px = x; // replace with your mapping
            gc.strokeLine(px, 0, px, height);
        }

        // horizontal lines
        for (double y = settings.getMin(); y <= settings.getMax(); y += spacing) {
            double py = y; // replace with your mapping
            gc.strokeLine(0, py, width, py);
        }
    }
}