package plot;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import ui.UI_Main;
import ui.ui_functions.tools.ToolbarIcons;

/**
 * Utility methods for plot color conversion, parsing, and dialog management.
 */
public class PlotUtilities {

    /**
     * Converts a Color to hex string format.
     */
    public static String colorToHex(Color color) {
        if (color == null)
            return "#2f3a44";

        return String.format("#%02X%02X%02X",
                (int) Math.round(color.getRed() * 255),
                (int) Math.round(color.getGreen() * 255),
                (int) Math.round(color.getBlue() * 255));
    }

    /**
     * Converts a Color to CSS rgb() string format.
     */
    public static String toRgb(Color c) {
        if (c == null)
            return "rgb(0,0,0)";
        return String.format("rgb(%d,%d,%d)",
                (int) (c.getRed() * 255),
                (int) (c.getGreen() * 255),
                (int) (c.getBlue() * 255));
    }

    /**
     * Parses a string as double, returning fallback if parsing fails.
     */
    public static double parseDoubleOr(String value, double fallback) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException | NullPointerException ex) {
            return fallback;
        }
    }

    /**
     * Normalizes plot type name (e.g., "Scatter Plot" -> "scatterplot").
     */
    public static String normalizePlotType(String name) {
        if (name == null)
            return "";
        return name.toLowerCase().replace(" ", "");
    }

    /**
     * Returns the appropriate glyph character for a plot type.
     */
    public static String getPlotGlyph(String type) {
        if (type == null)
            return "•";
        return switch (type) {
            case "plot", "semilogx", "semilogy", "loglog" -> "~";
            case "area", "fill", "stackplot" -> "▁▃▅";
            case "bar", "2dbar", "3dbar", "histogram", "errorbar" -> "▁▅▇";
            case "scatter", "bubble", "violin", "boxplot" -> "◌";
            case "piechart", "polar" -> "◔";
            case "contour", "heatmap", "vectorfield", "innovationplot" -> "◎";
            case "surf", "mesh", "quiver" -> "◈";
            case "stem", "stairs" -> "└┐";
            default -> "•";
        };
    }

    /**
     * Returns CSS style string for a specific plot type.
     */
    public static String getPlotStyle(String type) {
        if (type == null)
            return "-fx-stroke-width: 2;";
        return switch (type) {
            case "scatter" -> "-fx-stroke-width: 0; -fx-padding: 5;";
            case "bar", "2dbar" -> "-fx-bar-gap: 0; -fx-category-gap: 0;";
            case "stem" -> "-fx-stroke-dash-array: 5 5;";
            case "fill" -> "-fx-fill: rgba(74, 159, 181, 0.3);";
            case "stack" -> "-fx-fill: rgba(74, 159, 181, 0.5);";
            case "stairs" -> "-fx-stroke-line-cap: square;";
            default -> "-fx-stroke-width: 2;";
        };
    }

    /**
     * Determines dialog owner: returns plotStage if valid, otherwise IDE stage.
     */
    public static Stage getDialogOwner(Stage plotStage, UI_Main controller) {
        if (plotStage != null && plotStage.isShowing()) {
            return plotStage;
        }
        return controller != null ? controller.stage : null;
    }

    /**
     * Loads an icon image from the resources folder.
     */
    public static Image loadIcon(String resourcePath) {
        try {
            return ToolbarIcons.loadIconPublic(resourcePath);
        } catch (Exception ex) {
            return null;
        }
    }

    public static String extractStyleProperty(String css, String propertyName) {
        if (css == null || css.isBlank() || propertyName == null || propertyName.isBlank()) {
            return "";
        }
        int start = css.indexOf(propertyName);
        if (start < 0) {
            return "";
        }
        int end = css.indexOf(';', start);
        if (end < 0) {
            end = css.length();
        }
        return css.substring(start, end + (end < css.length() && css.charAt(end) == ';' ? 1 : 0)) + " ";
    }
}
