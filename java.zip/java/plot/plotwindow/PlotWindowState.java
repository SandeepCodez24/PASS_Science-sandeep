package plot.plotwindow;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import plot.GridSettings;
import plot.Plot2D;
import plot.Plot3D;
import plot.PlotAnnotation;
import plot.PlotChart3D;
import plot.PlotChartOperations;
import plot.PlotColorEditor;
import plot.PlotColorStrip;
import plot.PlotMenus;
import plot.PlotSave;
import plot.PlotToolbar;
import plot.PlotTypes;
import ui.UI_Main;
import ui.ui_functions.Variable;

public class PlotWindowState {
    public final UI_Main controller;
    public final File currentFolder;

    public Stage plotStage;
    public LineChart<Number, Number> chart;
    public NumberAxis xAxis;
    public NumberAxis yAxis;
    public StackPane centerPane;
    public BorderPane root;
    public Label selectedPlotLabel;

    public PlotColorEditor colorEditor;
    public PlotColorStrip colorStrip;
    public PlotTypes plotTypes;
    public PlotToolbar plotToolbar;
    public PlotAnnotation annotation;
    public plot.PlotInteraction interaction;
    public PlotChartOperations chartOps;
    public PlotMenus menus;
    public PlotChart3D chart3D;
    public Plot2D plot2D;
    public Plot3D plot3D;
    public PlotSave plotSave;
    public GridSettings gridSettings;
    public Color gridLineColor;
    public String current2DStyle = "solid";
    public String current2DHatch = "None";
    public String current2DWeight = "1 pt";

    public boolean initialized;
    public final Map<String, Image> hatchCache = new HashMap<>();

    public ScrollPane typesStrip;
    public HBox colorStripBox;
    public VBox axisStripBox;
    public VBox annotationStripBox;
    public VBox saveStripBox;
    public VBox threeDStripBox;
    public VBox twoDStripBox;
    public VBox gridStripBox;
    public HBox chartCornerBox;
    public Button saveMenuButton;
    public Button gridActionButton;
    public boolean plotGridVisible = true;
    public TableView<Variable> variableTable;
    public CheckBox gridEnabledCheckBox;
    public ComboBox<String> gridLineStyleCombo;
    public TextField gridDistributionField;
    public ComboBox<String> gridDistributionTypeCombo;
    public ColorPicker gridColorPicker;
    public ToolBar toolbar;
    public final List<String> plotNames = List.of(
            "Plot", "Area", "Bar Chart", "Scatter", "Pie Chart",
            "Histogram", "Contour", "Bubble", "Heatmap", "Violin", "Box Plot",
            "Polar", "Quiver");

    public PlotWindowState(UI_Main controller, File currentFolder) {
        this.controller = controller;
        this.currentFolder = currentFolder;
    }
}
