package plot.plotwindow;

import javafx.scene.Node;
import javafx.scene.control.Button;

public class PlotWindowLayoutSupport {
    private final PlotWindowLayoutCore layoutCore;
    private final PlotWindowLayoutControls controls;

    public PlotWindowLayoutSupport(PlotWindowState state, PlotWindowSelectionSupport selectionSupport,
            PlotWindowDialogsSupport dialogsSupport, PlotWindowGridSupport gridSupport,
            PlotWindowInteractionSupport interactionSupport) {
        this.controls = new PlotWindowLayoutControls(state, dialogsSupport, interactionSupport);
        this.layoutCore = new PlotWindowLayoutCore(state, selectionSupport, dialogsSupport, gridSupport, controls);
    }

    public void buildStrips() {
        layoutCore.buildStrips();
    }

    public void buildMainLayout() {
        layoutCore.buildMainLayout();
    }

    public void createChartCornerActions() {
        controls.createChartCornerActions();
    }

    public void updateChartCornerVisibility() {
        controls.updateChartCornerVisibility();
    }

    public void attachChartCornerToPlot(Node visibleChart) {
        controls.attachChartCornerToPlot(visibleChart);
    }

    public void detachChartCornerFromPlot() {
        controls.detachChartCornerFromPlot();
    }

    public Button buildCornerActionButton(String text, Runnable action) {
        return controls.buildCornerActionButton(text, action);
    }

    public Button buildGridIconButton(String iconPath, String symbol, String tooltip, Runnable action) {
        return controls.buildGridIconButton(iconPath, symbol, tooltip, action);
    }

    public void updateCornerButtonState(Button button, boolean active) {
        controls.updateCornerButtonState(button, active);
    }

    public void hide3DStrip() {
        controls.hide3DStrip();
    }

    public void hideSaveStrip() {
        controls.hideSaveStrip();
    }

    public void hideGridStrip() {
        controls.hideGridStrip();
    }

    public void hideTwoDStrip() {
        controls.hideTwoDStrip();
    }

    public void toggleSaveStrip() {
        controls.toggleSaveStrip();
    }

    public void toggle3DStrip() {
        controls.toggle3DStrip();
    }

    public void toggleGridStrip() {
        controls.toggleGridStrip();
    }

    public void toggleTwoDStrip() {
        controls.toggleTwoDStrip();
    }

}
