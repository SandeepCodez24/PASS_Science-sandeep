package plot.plotwindow;

import java.util.Collections;

import javafx.scene.Node;
import javafx.scene.chart.Axis;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

public class PlotWindowInteractionSupport {
    private final PlotWindowState state;
    private final PlotWindowDialogsSupport dialogsSupport;

    public PlotWindowInteractionSupport(PlotWindowState state, PlotWindowDialogsSupport dialogsSupport) {
        this.state = state;
        this.dialogsSupport = dialogsSupport;
    }

    private void logDebug(String message) {
    }

    public XYChart<?, ?> getVisibleXYChart() {
        if (state.centerPane == null || state.centerPane.getChildren().isEmpty()) {
            return null;
        }
        for (Node child : state.centerPane.getChildren()) {
            if (child instanceof XYChart<?, ?> xyChart) {
                return xyChart;
            }
        }
        return null;
    }

    public void goToMainWindow() {
        if (state.plotStage != null) {
            state.plotStage.hide();
        }
        if (state.controller != null && state.controller.stage != null) {
            state.controller.stage.show();
            state.controller.stage.toFront();
            state.controller.stage.requestFocus();
            logDebug("Returned to main IDE window from plot home icon.");
        }
    }

    public void resetView() {
        if (state.chart != null && state.xAxis != null && state.yAxis != null) {
            state.xAxis.setAutoRanging(true);
            state.yAxis.setAutoRanging(true);
        }
        XYChart<?, ?> visibleChart = getVisibleXYChart();
        if (visibleChart != null) {
            visibleChart.setScaleX(1.0);
            visibleChart.setScaleY(1.0);
            visibleChart.layout();
        }
    }

    public void shiftChartRight() {
        XYChart<?, ?> visibleChart = getVisibleXYChart();
        if (visibleChart == null) {
            return;
        }

        Axis<?> xAxis = visibleChart.getXAxis();
        if (xAxis instanceof NumberAxis numberXAxis) {
            double range = numberXAxis.getUpperBound() - numberXAxis.getLowerBound();
            double shift = range * 0.15;
            numberXAxis.setLowerBound(numberXAxis.getLowerBound() + shift);
            numberXAxis.setUpperBound(numberXAxis.getUpperBound() + shift);
        } else if (xAxis instanceof CategoryAxis categoryAxis) {

            if (categoryAxis.getCategories() == null ||
                    categoryAxis.getCategories().size() <= 1) {
                return;
            }

            javafx.collections.ObservableList<String> rotated = javafx.collections.FXCollections.observableArrayList(
                    categoryAxis.getCategories());

            Collections.rotate(rotated, -1);

            categoryAxis.setCategories(rotated);
        }
    }

    public void enterPalmView() {
        XYChart<?, ?> visibleChart = getVisibleXYChart();
        if (visibleChart == null) {
            return;
        }

        if (visibleChart.getXAxis() instanceof NumberAxis && visibleChart.getYAxis() instanceof NumberAxis) {
            attachPanHandlers(visibleChart);
            dialogsSupport.showPanelDialog("Palm View", dialogsSupport.buildInfoPanel(
                    "Palm view",
                    "Drag the chart area to pan the current numeric plot."));
        } else {
            dialogsSupport.showPanelDialog("Palm View", dialogsSupport.buildInfoPanel(
                    "Palm view",
                    "Pan mode is only supported for numeric X/Y charts. Use the zoom buttons for category charts."));
        }
    }

    public void attachPanHandlers(XYChart<?, ?> visibleChart) {
        if (visibleChart == null) {
            return;
        }

        final double[] anchor = new double[2];
        visibleChart.setOnMousePressed(e -> {
            anchor[0] = e.getX();
            anchor[1] = e.getY();
        });
        visibleChart.setOnMouseDragged(e -> {
            Axis<?> xAxis = visibleChart.getXAxis();
            Axis<?> yAxis = visibleChart.getYAxis();
            if (!(xAxis instanceof NumberAxis numberXAxis) || !(yAxis instanceof NumberAxis numberYAxis)) {
                return;
            }
            double deltaX = e.getX() - anchor[0];
            double deltaY = e.getY() - anchor[1];
            double xRange = numberXAxis.getUpperBound() - numberXAxis.getLowerBound();
            double yRange = numberYAxis.getUpperBound() - numberYAxis.getLowerBound();
            double xShift = -deltaX / Math.max(1, visibleChart.getWidth()) * xRange;
            double yShift = deltaY / Math.max(1, visibleChart.getHeight()) * yRange;
            numberXAxis.setLowerBound(numberXAxis.getLowerBound() + xShift);
            numberXAxis.setUpperBound(numberXAxis.getUpperBound() + xShift);
            numberYAxis.setLowerBound(numberYAxis.getLowerBound() + yShift);
            numberYAxis.setUpperBound(numberYAxis.getUpperBound() + yShift);
            anchor[0] = e.getX();
            anchor[1] = e.getY();
        });
    }

    public void zoomChart(double multiplier) {
        XYChart<?, ?> visibleChart = getVisibleXYChart();
        if (visibleChart == null) {
            return;
        }

        Axis<?> visibleXAxis = visibleChart.getXAxis();
        Axis<?> visibleYAxis = visibleChart.getYAxis();

        if (visibleXAxis instanceof NumberAxis numberXAxis && visibleYAxis instanceof NumberAxis numberYAxis) {
            if (numberXAxis.isAutoRanging() || numberYAxis.isAutoRanging()) {
                numberXAxis.setAutoRanging(true);
                numberYAxis.setAutoRanging(true);
                visibleChart.applyCss();
                visibleChart.layout();
            }

            double xLower = numberXAxis.getLowerBound();
            double xUpper = numberXAxis.getUpperBound();
            double yLower = numberYAxis.getLowerBound();
            double yUpper = numberYAxis.getUpperBound();

            if (xUpper <= xLower || yUpper <= yLower) {
                if (!visibleChart.getData().isEmpty()) {
                    double dataXMin = Double.MAX_VALUE;
                    double dataXMax = -Double.MAX_VALUE;
                    double dataYMin = Double.MAX_VALUE;
                    double dataYMax = -Double.MAX_VALUE;

                    for (var series : visibleChart.getData()) {
                        for (var data : series.getData()) {
                            if (data.getXValue() instanceof Number xValue) {
                                dataXMin = Math.min(dataXMin, xValue.doubleValue());
                                dataXMax = Math.max(dataXMax, xValue.doubleValue());
                            }
                            if (data.getYValue() instanceof Number yValue) {
                                dataYMin = Math.min(dataYMin, yValue.doubleValue());
                                dataYMax = Math.max(dataYMax, yValue.doubleValue());
                            }
                        }
                    }

                    if (dataXMax > dataXMin) {
                        xLower = dataXMin;
                        xUpper = dataXMax;
                    }
                    if (dataYMax > dataYMin) {
                        yLower = dataYMin;
                        yUpper = dataYMax;
                    }
                }
            }

            if (xUpper <= xLower || yUpper <= yLower) {
                return;
            }

            numberXAxis.setAutoRanging(false);
            numberYAxis.setAutoRanging(false);

            double xCenter = (xLower + xUpper) / 2;
            double yCenter = (yLower + yUpper) / 2;
            double newXRange = Math.max(0.1, (xUpper - xLower) * multiplier);
            double newYRange = Math.max(0.1, (yUpper - yLower) * multiplier);

            numberXAxis.setLowerBound(xCenter - newXRange / 2);
            numberXAxis.setUpperBound(xCenter + newXRange / 2);
            numberYAxis.setLowerBound(yCenter - newYRange / 2);
            numberYAxis.setUpperBound(yCenter + newYRange / 2);

            visibleChart.applyCss();
            visibleChart.layout();
            return;
        }

        Node chartNode = visibleChart;
        double minScale = 0.5;
        double maxScale = 4.0;
        double nextScaleX = Math.max(minScale, Math.min(maxScale, chartNode.getScaleX() / multiplier));
        double nextScaleY = Math.max(minScale, Math.min(maxScale, chartNode.getScaleY() / multiplier));
        chartNode.setScaleX(nextScaleX);
        chartNode.setScaleY(nextScaleY);
        chartNode.applyCss();
        if (chartNode instanceof javafx.scene.Parent parent) {
            parent.layout();
        }
    }
}
