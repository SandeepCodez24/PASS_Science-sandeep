package plot.plotwindow;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import plot.PlotToolbar;

class PlotWindowLayoutControls {

    enum StripKind {
        AXIS,
        TYPES,
        COLORS,
        GRID,
        TWO_D,
        THREE_D,
        ANNOTATION,
        SAVE
    }

    private final PlotWindowState state;
    private final PlotWindowDialogsSupport dialogsSupport;
    private final PlotWindowInteractionSupport interactionSupport;

    PlotWindowLayoutControls(PlotWindowState state, PlotWindowDialogsSupport dialogsSupport,
            PlotWindowInteractionSupport interactionSupport) {
        this.state = state;
        this.dialogsSupport = dialogsSupport;
        this.interactionSupport = interactionSupport;
    }

    void createChartCornerActions() {
        if (state.chartCornerBox != null) {
            return;
        }
        Button dataCleaningButton = buildGridIconButton("/icons/view/data-cleaning.png", null, "Data cleaning", () -> {
            dialogsSupport.showPanelDialog("Data Cleaning", dialogsSupport.buildInfoPanel(
                    "Data Cleaning",
                    "Remove invalid points, smooth chart series, or inspect data quality."));
        });
        Button docsButton = buildGridIconButton("/icons/view/docs.png", null, "Documentation", () -> {
            dialogsSupport.showPanelDialog("Documentation", dialogsSupport.buildInfoPanel(
                    "Plot Documentation",
                    dialogsSupport.getPlotDocumentationText()));
        });
        Button restoreButton = buildGridIconButton("/icons/view/home.png", null, "Main window",
                interactionSupport::goToMainWindow);
        Button forwardButton = buildGridIconButton("/icons/view/forward.png", null, "Next view",
                interactionSupport::shiftChartRight);
        Button zoomInButton = buildGridIconButton("/icons/view/zoom in.png", null, "Zoom in",
                () -> interactionSupport.zoomChart(0.8));
        Button zoomOutButton = buildGridIconButton("/icons/view/zoom out.png", null, "Zoom out",
                () -> interactionSupport.zoomChart(1.25));
        Button palmButton = buildGridIconButton("/icons/view/palm.png", null, "Palm view",
                interactionSupport::enterPalmView);

        state.chartCornerBox = new HBox(2, dataCleaningButton, docsButton, restoreButton, forwardButton, zoomInButton,
                zoomOutButton, palmButton);
        state.chartCornerBox.setAlignment(Pos.TOP_RIGHT);
    }

    void updateChartCornerVisibility() {
        if (state.chartCornerBox == null) {
            return;
        }
        Node visible = state.centerPane == null || state.centerPane.getChildren().isEmpty() ? null
                : state.centerPane.getChildren().get(0);
        boolean show = (visible instanceof javafx.scene.chart.LineChart)
                || (visible instanceof javafx.scene.chart.BarChart);
        state.chartCornerBox.setVisible(show);
        state.chartCornerBox.setManaged(show);
        if (show) {
            attachChartCornerToPlot(visible);
        } else {
            detachChartCornerFromPlot();
        }
    }

    void attachChartCornerToPlot(Node visibleChart) {
        if (state.chartCornerBox == null || visibleChart == null) {
            return;
        }
        javafx.application.Platform.runLater(() -> {
            try {
                Node plotNode = visibleChart.lookup(".chart-plot-background");
                if (!(plotNode instanceof Pane)) {
                    plotNode = visibleChart.lookup(".chart-plot");
                }
                Pane plotPane = plotNode instanceof Pane ? (Pane) plotNode : null;
                if (plotPane == null && visibleChart instanceof javafx.scene.chart.XYChart) {
                    Node content = visibleChart.lookup(".chart-content");
                    if (content instanceof Pane) {
                        plotPane = (Pane) content;
                    }
                }

                if (plotPane != null) {
                    Parent old = state.chartCornerBox.getParent();
                    if (old instanceof Pane && old != plotPane) {
                        ((Pane) old).getChildren().remove(state.chartCornerBox);
                    }

                    if (!plotPane.getChildren().contains(state.chartCornerBox)) {
                        plotPane.getChildren().add(state.chartCornerBox);
                    }

                    state.chartCornerBox.setManaged(false);
                    try {
                        state.chartCornerBox.layoutXProperty().unbind();
                    } catch (Exception ignore) {
                    }
                    try {
                        state.chartCornerBox.layoutYProperty().unbind();
                    } catch (Exception ignore) {
                    }

                    state.chartCornerBox.layoutXProperty()
                            .bind(plotPane.widthProperty().subtract(state.chartCornerBox.widthProperty()).subtract(6));
                    state.chartCornerBox.setLayoutY(6);
                } else {
                    Parent old = state.chartCornerBox.getParent();
                    if (old instanceof Pane && old != state.centerPane) {
                        ((Pane) old).getChildren().remove(state.chartCornerBox);
                    }
                    if (!state.centerPane.getChildren().contains(state.chartCornerBox)) {
                        state.centerPane.getChildren().add(state.chartCornerBox);
                    }
                    StackPane.setAlignment(state.chartCornerBox, Pos.TOP_RIGHT);
                }
            } catch (Exception ignore) {
            }
        });
    }

    void detachChartCornerFromPlot() {
        if (state.chartCornerBox == null) {
            return;
        }
        javafx.application.Platform.runLater(() -> {
            try {
                Parent old = state.chartCornerBox.getParent();
                if (old instanceof Pane && old != state.centerPane) {
                    ((Pane) old).getChildren().remove(state.chartCornerBox);
                    state.chartCornerBox.layoutXProperty().unbind();
                    state.chartCornerBox.layoutYProperty().unbind();
                }
                if (!state.centerPane.getChildren().contains(state.chartCornerBox)) {
                    state.centerPane.getChildren().add(state.chartCornerBox);
                }
                StackPane.setAlignment(state.chartCornerBox, Pos.TOP_RIGHT);
                state.chartCornerBox.setManaged(true);
            } catch (Exception ignore) {
            }
        });
    }

    Button buildCornerActionButton(String text, Runnable action) {
        Button button = new Button(text);
        button.setOnAction(e -> action.run());
        button.setStyle(
                "-fx-background-color: transparent; -fx-border-color: rgba(255,255,255,0.45); -fx-border-width: 1; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 4 8; -fx-background-radius: 6; -fx-border-radius: 6;");
        return button;
    }

    Button buildGridIconButton(String iconPath, String symbol, String tooltip, Runnable action) {
        Button button = new Button();
        if (iconPath != null && !iconPath.isBlank()) {
            Image icon = plot.PlotUtilities.loadIcon(iconPath);
            if (icon != null) {
                ImageView iconView = new ImageView(icon);
                iconView.setFitWidth(14);
                iconView.setFitHeight(14);
                button.setGraphic(iconView);
            } else if (symbol != null) {
                button.setText(symbol);
            }
        } else if (symbol != null) {
            button.setText(symbol);
        }
        if (tooltip != null) {
            button.setTooltip(new Tooltip(tooltip));
        }
        button.setPickOnBounds(true);
        button.setFocusTraversable(false);
        button.setOnAction(e -> action.run());
        button.setMinSize(22, 22);
        button.setPrefSize(22, 22);
        button.setStyle(
                "-fx-background-color: rgba(255,255,255,0.14); -fx-border-color: rgba(255,255,255,0.55); -fx-border-width: 1; -fx-background-radius: 8; -fx-border-radius: 8; -fx-text-fill: white; -fx-font-weight: bold;");
        return button;
    }

    void updateCornerButtonState(Button button, boolean active) {
        if (button == null) {
            return;
        }
        if (active) {
            button.setStyle(
                    "-fx-background-color: rgba(255,255,255,0.28); -fx-border-color: rgba(255,255,255,0.75); -fx-border-width: 1; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 4 8; -fx-background-radius: 6; -fx-border-radius: 6;");
        } else {
            button.setStyle(
                    "-fx-background-color: transparent; -fx-border-color: rgba(255,255,255,0.45); -fx-border-width: 1; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 4 8; -fx-background-radius: 6; -fx-border-radius: 6;");
        }
    }

    void hide3DStrip() {
        if (state.threeDStripBox == null) {
            return;
        }
        state.threeDStripBox.setVisible(false);
        state.threeDStripBox.setManaged(false);
    }

    void hideSaveStrip() {
        if (state.saveStripBox == null) {
            return;
        }

        state.saveStripBox.setVisible(false);
        state.saveStripBox.setManaged(false);
        if (state.saveMenuButton != null) {
            PlotToolbar.styleFlatToolbarControl(state.saveMenuButton);
        }
    }

    void hideGridStrip() {
        if (state.gridStripBox == null) {
            return;
        }
        state.gridStripBox.setVisible(false);
        state.gridStripBox.setManaged(false);
    }

    void hideTwoDStrip() {
        if (state.twoDStripBox == null) {
            return;
        }
        state.twoDStripBox.setVisible(false);
        state.twoDStripBox.setManaged(false);
    }

    void toggleSaveStrip() {
        if (state.saveStripBox == null) {
            return;
        }

        boolean show = !state.saveStripBox.isVisible();
        if (show) {
            hideAllStrips();
            state.saveStripBox.setVisible(true);
            state.saveStripBox.setManaged(true);
        } else {
            hideSaveStrip();
        }
    }

    void toggle3DStrip() {
        if (state.threeDStripBox == null) {
            return;
        }

        boolean show = !state.threeDStripBox.isVisible();
        if (show) {
            hideAllStrips();
            state.threeDStripBox.setVisible(true);
            state.threeDStripBox.setManaged(true);
        } else {
            hide3DStrip();
        }
    }

    void toggleGridStrip() {
        if (state.gridStripBox == null) {
            return;
        }

        boolean show = !state.gridStripBox.isVisible();
        if (show) {
            hideAllStrips();
            state.gridStripBox.setVisible(true);
            state.gridStripBox.setManaged(true);
        } else {
            hideGridStrip();
        }
    }

    void toggleTwoDStrip() {
        if (state.twoDStripBox == null) {
            return;
        }

        boolean show = !state.twoDStripBox.isVisible();
        if (show) {
            hideAllStrips();
            state.twoDStripBox.setVisible(true);
            state.twoDStripBox.setManaged(true);
        } else {
            hideTwoDStrip();
        }

    }

    void hideAllStrips() {

        // Axis strip (built in PlotMenus)
        if (state.menus != null) {
            state.menus.hideAxisStrip();
        }

        // Types strip
        if (state.plotTypes != null) {
            state.plotTypes.hideTypesStrip();
        }

        // Colors strip
        if (state.colorStrip != null) {
            state.colorStrip.hideColorStrip();
        }

        // Grid strip
        if (state.gridStripBox != null) {
            state.gridStripBox.setVisible(false);
            state.gridStripBox.setManaged(false);
        }

        // 2D strip
        if (state.twoDStripBox != null) {
            state.twoDStripBox.setVisible(false);
            state.twoDStripBox.setManaged(false);
        }

        // 3D strip
        if (state.threeDStripBox != null) {
            state.threeDStripBox.setVisible(false);
            state.threeDStripBox.setManaged(false);
        }

        // Annotation strip
        if (state.annotation != null) {
            state.annotation.hideAnnotationStrip();
        }

        // Save strip
        if (state.saveStripBox != null) {
            state.saveStripBox.setVisible(false);
            state.saveStripBox.setManaged(false);
        }
    }

    void showTypesStrip() {
        if (state.plotTypes == null) {
            return;
        }
        // Types strip is a ScrollPane Node; use explicit visible/managed semantics.
        state.plotTypes.showTypesStrip();
    }

    void showColorsStrip() {
        if (state.colorStrip == null) {
            return;
        }
        state.colorStrip.showColorStrip();
    }

    void showGridStrip() {
        if (state.gridStripBox == null) {
            return;
        }
        state.gridStripBox.setVisible(true);
        state.gridStripBox.setManaged(true);
    }

    void show2DStrip() {
        if (state.twoDStripBox == null) {
            return;
        }
        state.twoDStripBox.setVisible(true);
        state.twoDStripBox.setManaged(true);
    }

    void show3DStrip() {
        if (state.threeDStripBox == null) {
            return;
        }
        state.threeDStripBox.setVisible(true);
        state.threeDStripBox.setManaged(true);
    }

    void showAnnotationStrip() {
        if (state.annotation == null) {
            return;
        }
        state.annotation.showAnnotationStrip();
    }

    void showSaveStrip() {
        if (state.saveStripBox == null) {
            return;
        }
        state.saveStripBox.setVisible(true);
        state.saveStripBox.setManaged(true);
    }

    /**
     * Centralized strip dispatcher: guarantees the single-active-strip rule.
     */
    void showRequestedStrip(StripKind kind) {
        hideAllStrips();
        if (kind == null) {
            return;
        }
        switch (kind) {
            case TYPES -> showTypesStrip();
            case COLORS -> {
                // Colors strip visibility must be deterministic (no toggle)
                showColorsStrip();
            }
            case GRID -> showGridStrip();
            case TWO_D -> show2DStrip();
            case THREE_D -> show3DStrip();
            case ANNOTATION -> showAnnotationStrip();
            case SAVE -> showSaveStrip();
            case AXIS -> {
                // Axis strip is managed by PlotMenus, which only provides toggle/hide.
                if (state.menus != null) {
                    // ensure hidden first
                    state.menus.hideAxisStrip();
                    // then show via toggle (strip is currently hidden)
                    state.menus.toggleAxisStrip();
                }
            }
        }
    }

}
