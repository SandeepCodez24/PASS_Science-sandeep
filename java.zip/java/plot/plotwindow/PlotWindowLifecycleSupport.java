package plot.plotwindow;

import java.util.List;

import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import ui.editor.EditorTextOperations;
import ui.managers.ThemeManager;
import ui.settings.connector_cpp.UPIPoint;
import ui.settings.connector_cpp.UPIVariable;

public class PlotWindowLifecycleSupport {
    private final PlotWindowState state;
    private final PlotWindowLayoutSupport layoutSupport;
    private final PlotWindowGridSupport gridSupport;
    private final PlotWindowSelectionSupport selectionSupport;

    public PlotWindowLifecycleSupport(PlotWindowState state, PlotWindowLayoutSupport layoutSupport,
            PlotWindowGridSupport gridSupport, PlotWindowSelectionSupport selectionSupport) {
        this.state = state;
        this.layoutSupport = layoutSupport;
        this.gridSupport = gridSupport;
        this.selectionSupport = selectionSupport;
    }

    private void logDebug(String message) {
    }

    public void show() {
        Runnable showAction = () -> {
            try {
                if (state.initialized && state.plotStage != null) {
                    state.plotStage.show();
                    state.plotStage.toFront();
                    state.plotStage.requestFocus();
                    logDebug("PlotWindow.reopen called, stage showing=" + state.plotStage.isShowing());
                    return;
                }

                state.plotStage = new Stage();
                if (state.controller != null && state.controller.stage != null) {
                    state.plotStage.initOwner(state.controller.stage);
                }
                state.plotStage.setTitle("Advanced Plot Window");

                state.xAxis = new NumberAxis();
                state.yAxis = new NumberAxis();
                state.chart = new LineChart<>(state.xAxis, state.yAxis);
                state.chart.setAnimated(false);
                state.chart.setCreateSymbols(false);
                try {
                    var gridCss = plot.PlotWindow.class.getResource("plot/Grid.css");
                    if (gridCss != null && !state.chart.getStylesheets().contains(gridCss.toExternalForm())) {
                        state.chart.getStylesheets().add(gridCss.toExternalForm());
                    }
                } catch (Exception ignore) {
                }

                state.centerPane = new StackPane(state.chart);

                state.annotation = new plot.PlotAnnotation(state.centerPane, state.chart, state.xAxis,
                        state.yAxis);
                state.colorEditor = new plot.PlotColorEditor(state.plotStage);
                state.colorStrip = new plot.PlotColorStrip();
                state.plotTypes = new plot.PlotTypes();
                state.plotToolbar = new plot.PlotToolbar();
                state.menus = new plot.PlotMenus(state.controller, state.xAxis, state.yAxis, state.plotStage);
                state.interaction = new plot.PlotInteraction(state.chart, state.xAxis, state.yAxis);
                state.chartOps = new plot.PlotChartOperations(state.controller, state.centerPane, state.chart,
                        state.xAxis, state.yAxis, state.currentFolder,
                        () -> gridSupport.apply2DHatch(state.current2DHatch));
                state.chart3D = new plot.PlotChart3D();
                state.plot2D = new plot.Plot2D();
                state.plot3D = new plot.Plot3D();
                state.plotSave = new plot.PlotSave(state.plotStage);
                state.gridSettings = new plot.GridSettings();
                state.gridLineColor = javafx.scene.paint.Color.web("#b0b0b0");

                layoutSupport.buildStrips();
                layoutSupport.buildMainLayout();

                Scene scene = new Scene(state.root, 1000, 650);
                ThemeManager.registerScene(scene);
                state.interaction.enableZoom();
                state.interaction.enablePan();
                try {
                    state.interaction.enableClickToShowCoordinates(state.annotation);
                } catch (Throwable ignore) {
                }

                gridSupport.applyGridColor(null);

                state.plotStage.setScene(scene);
                state.plotStage.centerOnScreen();
                state.plotStage.show();
                state.plotStage.toFront();
                state.plotStage.requestFocus();
                logDebug("PlotWindow.show complete, stage showing=" + state.plotStage.isShowing());

                state.initialized = true;

                // Load variables from the live editor code
                selectionSupport.updateVariableSidebarFromEditorCode();
            } catch (Exception ex) {
                logDebug("PlotWindow.show failed: " + ex.getClass().getSimpleName() + ": " + ex.getMessage());
                ex.printStackTrace();
            }
        };

        if (Platform.isFxApplicationThread()) {
            showAction.run();
        } else {
            Platform.runLater(showAction);
        }
    }

    public void showLivePoints(List<UPIPoint> points) {
        Runnable showAndDraw = () -> {
            show();
            if (points == null || points.isEmpty()) {
                return;
            }

            // Get editor code for dynamic axis labels
            String editorCode = null;
            try {
                javafx.scene.control.Tab currentTab = state.controller.editorTabs.getSelectionModel().getSelectedItem();
                if (currentTab != null) {
                    editorCode = EditorTextOperations.getEditorText(currentTab);
                }
            } catch (Exception ignore) {
            }

            // Draw with dynamic labels from plot() function if code is available
            if (editorCode != null && !editorCode.isBlank()) {
                state.chartOps.drawLivePoints(points, editorCode);
            } else {
                state.chartOps.drawLivePoints(points);
            }

            if (state.selectedPlotLabel != null) {
                state.selectedPlotLabel.setText("UPI live plot");
            }
        };

        if (Platform.isFxApplicationThread()) {
            showAndDraw.run();
        } else {
            Platform.runLater(showAndDraw);
        }
    }

    public void showLivePoints(List<UPIPoint> points, List<UPIVariable> variables) {
        Runnable showAndDraw = () -> {
            show();
            try {
                // If variables are provided from UPI, use those
                if (variables != null && !variables.isEmpty()) {
                    selectionSupport.updateVariableSidebar(variables);
                } else {
                    // Otherwise, extract variables from the live editor code
                    selectionSupport.updateVariableSidebarFromEditorCode();
                }
            } catch (Exception ignore) {
            }

            if (points == null || points.isEmpty()) {
                return;
            }

            boolean isBarPlot = false;
            if (variables != null) {
                for (UPIVariable v : variables) {
                    if (v != null
                            && "PLOT_TYPE".equalsIgnoreCase(v.name())
                            && v.value() != null
                            && "bar".equalsIgnoreCase(v.value().trim())) {
                        isBarPlot = true;
                        break;
                    }
                }
            }

            // Get editor code for dynamic axis labels
            String editorCode = null;
            try {
                javafx.scene.control.Tab currentTab = state.controller.editorTabs.getSelectionModel().getSelectedItem();
                if (currentTab != null) {
                    editorCode = EditorTextOperations.getEditorText(currentTab);
                }
            } catch (Exception ignore) {
            }

            if (isBarPlot) {
                state.chartOps.drawBarPoints(points, variables);
            } else {
                // Draw with dynamic labels from plot() function if code is available
                if (editorCode != null && !editorCode.isBlank()) {
                    state.chartOps.drawLivePoints(points, editorCode);
                } else {
                    state.chartOps.drawLivePoints(points);
                }
            }

            // Re-attach chart-corner UI after the visible chart node is replaced.
            // This is required for bar plots because drawBarPoints() replaces the chart
            // content
            // via PlotChartOperations.setCenterContent(...).
            try {
                layoutSupport.updateChartCornerVisibility();
            } catch (Exception ignore) {
            }

            if (state.selectedPlotLabel != null) {
                state.selectedPlotLabel.setText("UPI live plot");
            }

        };

        if (Platform.isFxApplicationThread()) {
            showAndDraw.run();
        } else {
            Platform.runLater(showAndDraw);
        }
    }
}
