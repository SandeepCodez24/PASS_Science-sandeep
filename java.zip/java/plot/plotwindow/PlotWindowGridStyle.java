package plot.plotwindow;

import java.util.List;

import javafx.scene.Node;
import javafx.scene.chart.XYChart;
import javafx.scene.paint.Color;
import javafx.scene.shape.Shape;

class PlotWindowGridStyle {
    void applyGridStyleClass(XYChart<?, ?> currentChart, String lineStyle) {
        if (currentChart == null) {
            return;
        }

        currentChart.getStyleClass().removeIf(style -> style != null && style.startsWith("grid-"));

        String normalized = lineStyle == null ? "solid" : lineStyle.trim().toLowerCase();
        String styleClass = switch (normalized) {
            case "dashed" -> "grid-dashed";
            case "dotted" -> "grid-dotted";
            case "dash-dot" -> "grid-dashdot";
            case "none" -> "grid-none";
            default -> "grid-solid";
        };

        if (!currentChart.getStyleClass().contains(styleClass)) {
            currentChart.getStyleClass().add(styleClass);
        }
    }

    void applyGridLineStyle(Shape shape, Color color, List<Double> dashPattern, boolean hideLines) {
        if (shape == null) {
            return;
        }

        if (color == null) {
            color = Color.BLACK;
        }

        String rgb = plot.PlotUtilities.toRgb(color);
        shape.setStroke(color);
        shape.getStrokeDashArray().clear();
        if (!hideLines && dashPattern != null && !dashPattern.isEmpty()) {
            shape.getStrokeDashArray().addAll(dashPattern);
        }

        StringBuilder style = new StringBuilder("-fx-stroke: ").append(rgb).append(";");
        if (!hideLines && dashPattern != null && !dashPattern.isEmpty()) {
            style.append(" -fx-stroke-dash-array: ");
            for (int i = 0; i < dashPattern.size(); i++) {
                if (i > 0) {
                    style.append(' ');
                }
                style.append(dashPattern.get(i));
            }
            style.append(';');
        }
        shape.setStyle(style.toString());
    }

    void styleExistingGridLines(XYChart<?, ?> currentChart, String rgb,
            List<Double> dashPattern, boolean hideLines) {
        if (currentChart == null) {
            return;
        }

        List<Node> lines = new java.util.ArrayList<>();
        lines.addAll(currentChart.lookupAll(".chart-vertical-grid-lines .chart-grid-line"));
        lines.addAll(currentChart.lookupAll(".chart-horizontal-grid-lines .chart-grid-line"));
        lines.addAll(currentChart.lookupAll(".chart-grid-line"));

        for (Node line : lines) {
            if (line instanceof Shape shape) {
                applyGridLineStyle(shape, Color.web(rgb), dashPattern, hideLines);
                shape.setVisible(!hideLines);
            }
        }
    }

    List<Double> getLineDashPattern(String lineStyle) {
        if (lineStyle == null) {
            return List.of();
        }
        return switch (lineStyle.trim().toLowerCase()) {
            case "dashed" -> List.of(8.0, 4.0);
            case "dotted" -> List.of(2.0, 2.0);
            case "dash-dot" -> List.of(8.0, 4.0, 2.0, 4.0);
            default -> List.of();
        };
    }
}
