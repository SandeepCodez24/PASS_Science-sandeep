package plot.plotwindow;

import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ui.editor.EditorTextOperations;
import ui.managers.ThemeManager;
import ui.settings.connector_cpp.UPIVariable;
import ui.ui_functions.IDEVariableService;
import ui.ui_functions.Variable;

public class PlotWindowSelectionSupport {
    private final PlotWindowState state;
    private final PlotWindowDialogsSupport dialogsSupport;
    private final PlotWindowGridSupport gridSupport;

    public PlotWindowSelectionSupport(PlotWindowState state, PlotWindowDialogsSupport dialogsSupport,
            PlotWindowGridSupport gridSupport) {
        this.state = state;
        this.dialogsSupport = dialogsSupport;
        this.gridSupport = gridSupport;
    }

    public VBox buildVariableSidebar() {
        Label title = new Label("Workspace Variables");
        title.setStyle("-fx-background-color:#0aa6a6; -fx-text-fill:white; -fx-padding:6 10; -fx-font-weight:bold;");
        title.setMaxWidth(Double.MAX_VALUE);

        state.variableTable = new TableView<>();
        state.variableTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableColumn<Variable, String> nameCol = new TableColumn<>("Name");
        TableColumn<Variable, String> valueCol = new TableColumn<>("Value");
        TableColumn<Variable, String> sizeCol = new TableColumn<>("Size");
        TableColumn<Variable, String> typeCol = new TableColumn<>("Class");

        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        valueCol.setCellValueFactory(new PropertyValueFactory<>("value"));
        sizeCol.setCellValueFactory(new PropertyValueFactory<>("size"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("datatype"));

        state.variableTable.getColumns().add(nameCol);
        state.variableTable.getColumns().add(valueCol);
        state.variableTable.getColumns().add(sizeCol);
        state.variableTable.getColumns().add(typeCol);
        state.variableTable.setPrefWidth(260);
        state.variableTable.setMaxWidth(Double.MAX_VALUE);

        VBox sidebar = new VBox(title, state.variableTable);
        sidebar.setStyle("-fx-background-color:#f6f7fb;");
        sidebar.setPrefWidth(280);
        VBox.setVgrow(state.variableTable, javafx.scene.layout.Priority.ALWAYS);
        return sidebar;
    }

    public void updateVariableSidebar(List<UPIVariable> variables) {
        // This method now delegates to the more explicit UPI-specific method
        updateVariableSidebarFromUPIVariables(variables);
    }

    public void handlePlotTypeSelection(String type) {
        if ("custom".equals(type)) {
            showCustomPlotDialog();
            return;
        }

        String t = type == null ? "" : type.trim().toLowerCase();
        if ("2dbar".equals(t) || "2d bar".equals(t) || "bar".equals(t) || "barchart".equals(t) || "bar chart".equals(t)
                || "bar-chart".equals(t) || "3dbar".equals(t) || "3d bar".equals(t)) {
            type = "2dbar";
        }

        if ("plot".equals(type)) {
            state.chartOps.setCenterContent(state.chart);
            state.chartOps.drawPreviewPlot(type, getDisplayName(type));
            state.chartOps.changeChartType(type);
            if (state.selectedPlotLabel != null) {
                state.selectedPlotLabel.setText(formatPlotTypeLabel(type));
            }
            return;
        }

        state.chartOps.setCenterContent(state.chart);

        List<String> vars = state.controller.getVariableNames();
        if (vars.isEmpty()) {
            state.chartOps.drawPreviewPlot(type, getDisplayName(type));
        } else {
            String xName = null;
            String yName = null;

            if (!vars.isEmpty()) {
                xName = vars.get(0);
                yName = vars.get(0);
            }

            if (xName != null && yName != null) {
                state.xAxis.setLabel(xName);
                state.yAxis.setLabel(yName);
                state.chartOps.drawVariablePlot(xName, yName);
            } else if (state.chart.getData().isEmpty()) {
                state.chartOps.drawPreviewPlot(type, getDisplayName(type));
            }
        }

        try {
            state.chartOps.changeChartType(type);
        } catch (Exception ex) {
            try {
                if (state.controller != null && state.controller.console != null) {
                    state.controller.console
                            .appendText("ERROR: changeChartType failed for type='" + type + "' -> " + ex + "\n");
                }
            } catch (Exception ignore) {
            }
        }

        gridSupport.applyGridSettings();
        dialogsSupport.apply2DStyle(state.current2DStyle);
        dialogsSupport.apply2DWeight(state.current2DWeight);
        if ("bar".equals(type) || "2dbar".equals(type) || "histogram".equals(type)) {
            gridSupport.apply2DHatch(state.current2DHatch);
        }
        if ("bar".equals(type) || "2dbar".equals(type) || "histogram".equals(type)) {
            javafx.application.Platform.runLater(gridSupport::applyGridSettings);
        }
        if ("scatter".equals(type)) {
            int pts = state.chartOps.getLastPreviewPointCount();
            if (state.selectedPlotLabel != null)
                state.selectedPlotLabel.setText("Scatter preview loaded (" + pts + " points)");
        } else {
            if (state.selectedPlotLabel != null)
                state.selectedPlotLabel.setText(formatPlotTypeLabel(type));
        }
        if (state.interaction != null) {
            // no-op placeholder to keep the same sequencing
        }
    }

    public void showCustomPlotDialog() {
        Label title = new Label("Custom Plot");
        title.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: white;");

        TextField nameField = new TextField();
        nameField.setPromptText("Custom plot name");

        Button createBtn = new Button("Create");
        Button closeBtn = new Button("Close");

        HBox buttons = new HBox(10, createBtn, closeBtn);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        VBox content = new VBox(10, title, nameField, buttons);
        content.setPadding(new Insets(12));
        content.setStyle(
                "-fx-background-color:#0aa6a6; -fx-background-radius: 8; -fx-border-radius: 8; -fx-padding: 12;");

        Stage dialog = new Stage();
        dialog.setTitle("Custom Plot");
        dialog.initModality(Modality.APPLICATION_MODAL);

        Stage owner = plot.PlotUtilities.getDialogOwner(state.plotStage, state.controller);
        if (owner != null) {
            dialog.initOwner(owner);
        }

        Scene scene = new Scene(content);
        ThemeManager.registerScene(scene);
        dialog.setScene(scene);

        createBtn.setOnAction(e -> {
            String value = nameField.getText() == null ? "" : nameField.getText().trim();
            if (state.selectedPlotLabel != null) {
                state.selectedPlotLabel.setText((value.isEmpty() ? "Custom plot" : value) + " selected");
            }
            dialog.close();
        });

        closeBtn.setOnAction(e -> dialog.close());
        dialog.show();
    }

    public void showColorDialog(String mode) {
        plot.PlotColorEditor editor = state.colorEditor != null
                ? state.colorEditor
                : new plot.PlotColorEditor(
                        plot.PlotUtilities.getDialogOwner(state.plotStage, state.controller));
        try {
            if (state.colorStrip != null)
                state.colorStrip.selectMode(mode);
        } catch (Exception ex) {
        }
        javafx.scene.paint.Color selectedColor = editor.showColorChooserDialog("variable", mode);
        if (selectedColor != null) {
            if ("Colors".equalsIgnoreCase(mode)) {
                state.chartOps.applyBackgroundColor(selectedColor);
            } else {
                state.chartOps.applyColorToVisiblePlot(selectedColor);
                state.chartOps.applySeriesColor("variable", selectedColor);
            }
        }
    }

    public String getDisplayName(String type) {
        for (String name : state.plotNames) {
            if (plot.PlotUtilities.normalizePlotType(name).equals(type)) {
                return name;
            }
        }
        return type;
    }

    public String formatPlotTypeLabel(String type) {
        String displayName = getDisplayName(type);
        String normalized = displayName == null ? "" : plot.PlotUtilities.normalizePlotType(displayName);
        return "plot type=" + (normalized.isEmpty() ? type : normalized);
    }

    /**
     * Extract variables from the live editor code and update the variable sidebar.
     * This uses the same extraction logic as the variable explorer to show the
     * exact variables present in the editor.
     */
    public void updateVariableSidebarFromEditorCode() {
        if (state.variableTable == null || state.controller == null) {
            return;
        }

        try {
            // Get the current editor tab
            Tab currentTab = state.controller.editorTabs.getSelectionModel().getSelectedItem();
            if (currentTab == null) {
                state.variableTable.getItems().clear();
                return;
            }

            // Extract the code from the editor
            String editorCode = EditorTextOperations.getEditorText(currentTab);
            if (editorCode == null || editorCode.isBlank()) {
                state.variableTable.getItems().clear();
                return;
            }

            // Parse variables using the same logic as the variable explorer
            List<Variable> extractedVariables = IDEVariableService.parseConsoleVariables(editorCode);

            // Extract dynamic plot() function call arguments for axis labels
            String[] plotVars = plot.PlotChartOperations.extractPlotVariablesFromCode(editorCode);
            
            // Determine which variables to display
            List<Variable> variablesToDisplay = extractedVariables;
            
            if (plotVars != null && plotVars.length >= 1) {
                // Set dynamic x-axis label from first plot argument
                if (state.xAxis != null) {
                    state.xAxis.setLabel(plotVars[0]);
                }
                // Set dynamic y-axis label from second plot argument (if present)
                if (plotVars.length >= 2 && state.yAxis != null) {
                    state.yAxis.setLabel(plotVars[1]);
                } else if (state.yAxis != null) {
                    state.yAxis.setLabel("Value");
                }

                // Build list of variables to display based on plot() call
                List<Variable> plotVariables = new ArrayList<>();
                
                // Try to match plot variables with extracted variables
                for (String plotVar : plotVars) {
                    Variable matchedVar = null;
                    
                    // Look for variable with matching name (case-insensitive)
                    for (Variable var : extractedVariables) {
                        if (var.getName().equalsIgnoreCase(plotVar)) {
                            matchedVar = var;
                            break;
                        }
                    }
                    
                    // If found, rename to exact plot() name; if not found, create placeholder
                    if (matchedVar != null) {
                        plotVariables.add(new Variable(plotVar, matchedVar.getValue(), matchedVar.getSize(), matchedVar.getDatatype()));
                    } else {
                        // Create placeholder for plot variable not found in extraction
                        plotVariables.add(new Variable(plotVar, "N/A", "0", "unknown"));
                    }
                }
                
                // Use plot variables as display list
                if (!plotVariables.isEmpty()) {
                    variablesToDisplay = plotVariables;
                }
            }

            // Update the variable table
            state.variableTable.getItems().setAll(variablesToDisplay);

            // Update the menus with the variable names
            try {
                List<String> names = new ArrayList<>();
                for (Variable variable : variablesToDisplay) {
                    names.add(variable.getName());
                }
                if (state.menus != null) {
                    state.menus.setVariableList(names);
                }
            } catch (Exception ex) {
                // Log but don't fail
            }
        } catch (Exception ex) {
            // Gracefully handle any errors in extraction
            state.variableTable.getItems().clear();
        }
    }

    /**
     * Extracts plot() function arguments from user code and sets dynamic axis labels.
     * For example: plot(a, b) sets x-axis label to "a" and y-axis label to "b"
     * 
     * @param code the user's code containing plot() function call
     */
    public void updateAxisLabelsFromPlotCode(String code) {
        if (code == null || code.isBlank() || state.xAxis == null || state.yAxis == null) {
            return;
        }

        try {
            // Extract plot() function arguments (e.g., plot(a, b) → ["a", "b"])
            String[] plotVars = plot.PlotChartOperations.extractPlotVariablesFromCode(code);
            
            if (plotVars != null && plotVars.length >= 1) {
                // Set x-axis label from first argument
                state.xAxis.setLabel(plotVars[0]);
                
                // Set y-axis label from second argument (if present)
                if (plotVars.length >= 2) {
                    state.yAxis.setLabel(plotVars[1]);
                } else {
                    // Single argument: default y-axis label
                    state.yAxis.setLabel("Value");
                }
            }
        } catch (Exception ex) {
            // Silently ignore parsing errors
        }
    }

    /**
     * Converts UPIVariable objects to Variable objects and updates the sidebar.
     * This is called when variables come from the interpreter/UPI execution.
     * Filters to show only variables used in plot() call if one exists.
     */
    public void updateVariableSidebarFromUPIVariables(List<UPIVariable> variables) {
        if (state.variableTable == null) {
            return;
        }

        if (variables == null || variables.isEmpty()) {
            state.variableTable.getItems().clear();
            return;
        }

        // Convert UPI variables to Variable objects
        List<Variable> rows = new ArrayList<>();
        for (UPIVariable variable : variables) {
            rows.add(new Variable(variable.name(), variable.value(), variable.size(), variable.datatype()));
        }

        // Try to get editor code and extract plot() variables
        String editorCode = null;
        try {
            Tab currentTab = state.controller.editorTabs.getSelectionModel().getSelectedItem();
            if (currentTab != null) {
                editorCode = EditorTextOperations.getEditorText(currentTab);
            }
        } catch (Exception ignore) {
        }

        // Extract plot() function call arguments
        List<Variable> displayVariables = rows;
        if (editorCode != null && !editorCode.isBlank()) {
            String[] plotVars = plot.PlotChartOperations.extractPlotVariablesFromCode(editorCode);
            
            if (plotVars != null && plotVars.length >= 1) {
                // Filter to show only variables used in plot() call
                List<Variable> filteredVars = new ArrayList<>();
                
                // Map plot() arguments to UPI variables by POSITION
                // The UPI interpreter may return different internal names (x, y)
                // but we want to display them with the exact names from plot() call
                for (int i = 0; i < plotVars.length && i < rows.size(); i++) {
                    String plotVar = plotVars[i].trim();
                    Variable upiVar = rows.get(i);
                    
                    // Use the UPI variable's data, but rename to match plot() call
                    filteredVars.add(new Variable(plotVar, upiVar.getValue(), 
                        upiVar.getSize(), upiVar.getDatatype()));
                }
                
                // Use filtered variables if we found any
                if (!filteredVars.isEmpty()) {
                    displayVariables = filteredVars;
                }
            }
        }

        // Update the variable table
        state.variableTable.getItems().setAll(displayVariables);

        try {
            List<String> names = new ArrayList<>();
            for (Variable variable : displayVariables) {
                names.add(variable.getName());
            }
            if (state.menus != null) {
                state.menus.setVariableList(names);
            }
        } catch (Exception ex) {
        }
    }
}
