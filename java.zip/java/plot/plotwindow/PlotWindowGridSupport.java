package plot.plotwindow;

import javafx.scene.paint.Color;

public class PlotWindowGridSupport {
    private final PlotWindowGridCore gridCore;
    private final PlotWindowGridHatch gridHatch;

    public PlotWindowGridSupport(PlotWindowState state) {
        PlotWindowGridStyle gridStyle = new PlotWindowGridStyle();
        this.gridCore = new PlotWindowGridCore(state, gridStyle);
        this.gridHatch = new PlotWindowGridHatch(state);
    }

    public void applyGridColor(Color color) {
        gridCore.applyGridColor(color);
    }

    public void applyGridSettings() {
        gridCore.applyGridSettings();
    }

    public void apply2DHatch(String hatch) {
        gridHatch.apply2DHatch(hatch);
    }
}
