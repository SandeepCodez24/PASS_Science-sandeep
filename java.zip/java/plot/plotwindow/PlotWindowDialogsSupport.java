package plot.plotwindow;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.ScatterChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import ui.managers.ThemeManager;

public class PlotWindowDialogsSupport {
    private final PlotWindowState state;
    private final PlotWindowGridSupport gridSupport;

    public PlotWindowDialogsSupport(PlotWindowState state, PlotWindowGridSupport gridSupport) {
        this.state = state;
        this.gridSupport = gridSupport;
    }

    public void showPanelDialog(String title, VBox content) {
        if (content == null) {
            return;
        }

        Stage dialog = new Stage();
        dialog.setTitle(title);
        dialog.initModality(Modality.APPLICATION_MODAL);

        Stage owner = plot.PlotUtilities.getDialogOwner(state.plotStage, state.controller);
        if (owner != null) {
            dialog.initOwner(owner);
        }

        Scene scene = new Scene(content, 420, 220);
        ThemeManager.registerScene(scene);
        dialog.setScene(scene);
        dialog.show();
    }

    public VBox buildInfoPanel(String heading, String body) {
        Label title = new Label(heading);
        title.setStyle("-fx-font-size: 14; -fx-font-weight: bold; -fx-padding: 0 0 10 0;");

        Label description = new Label(body);
        description.setWrapText(true);
        description.setStyle("-fx-font-size: 12; -fx-padding: 0 0 10 0;");

        Button close = new Button("Close");
        close.setOnAction(e -> {
            Stage stage = (Stage) close.getScene().getWindow();
            if (stage != null) {
                stage.close();
            }
        });

        HBox footer = new HBox(close);
        footer.setAlignment(Pos.CENTER_RIGHT);
        footer.setPadding(new Insets(10, 0, 0, 0));

        VBox content = new VBox(10, title, description, footer);
        content.setPadding(new Insets(16));
        content.setStyle("-fx-background-color: white; -fx-border-color: #d0d0d0; -fx-border-width: 1;");
        return content;
    }

    public String getPlotDocumentationText() {
        String typeDescription = "Current chart type: Unknown.";
        try {
            if (state.centerPane != null && !state.centerPane.getChildren().isEmpty()) {
                Node visible = state.centerPane.getChildren().get(0);
                if (visible instanceof BarChart) {
                    typeDescription = "Current chart type: Bar Chart. Use bar chart view to compare values as vertical bars.";
                } else if (visible instanceof LineChart) {
                    typeDescription = "Current chart type: Line Chart. Use line chart view to connect points and see trends over the X axis.";
                } else if (visible instanceof AreaChart) {
                    typeDescription = "Current chart type: Area Chart. Use area chart view to emphasize volume beneath the line.";
                } else if (visible instanceof ScatterChart) {
                    typeDescription = "Current chart type: Scatter Chart. Use scatter view to inspect point distributions.";
                } else if (visible instanceof PieChart) {
                    typeDescription = "Current chart type: Pie Chart. Use pie chart view to compare category shares.";
                }
            }
        } catch (Exception ignore) {
        }

        return typeDescription + "\n\nUse zoom in/out, home, and palm view to explore the chart. " +
                "The main window button returns focus to the IDE. Use the plot type controls to switch between line, bar, area, and other views.";
    }

    public void show2DSettingsDialog() {
        if (state.twoDStripBox != null) {
            state.twoDStripBox.setVisible(!state.twoDStripBox.isVisible());
            state.twoDStripBox.setManaged(state.twoDStripBox.isVisible());
        }
    }

    public void show3DSettingsDialog() {
        if (state.threeDStripBox != null) {
            state.threeDStripBox.setVisible(!state.threeDStripBox.isVisible());
            state.threeDStripBox.setManaged(state.threeDStripBox.isVisible());
        }
    }

    public void showGridSettingsDialog() {
        if (state.gridStripBox != null) {
            state.gridStripBox.setVisible(!state.gridStripBox.isVisible());
            state.gridStripBox.setManaged(state.gridStripBox.isVisible());
        }
    }

    public void showSaveSettingsDialog() {
        if (state.saveStripBox != null) {
            state.saveStripBox.setVisible(!state.saveStripBox.isVisible());
            state.saveStripBox.setManaged(state.saveStripBox.isVisible());
        }
    }

    public void apply2DStyle(String style) {
        if (state.chart == null || style == null || style.isBlank()) {
            return;
        }

        state.chart.applyCss();
        state.chart.layout();

        for (javafx.scene.chart.XYChart.Series<Number, Number> series : state.chart.getData()) {
            if (series.getNode() != null) {
                Node line = series.getNode().lookup(".chart-series-line");
                if (line instanceof javafx.scene.shape.Shape shape) {
                    shape.getStrokeDashArray().clear();
                    switch (style.toLowerCase()) {
                        case "dashed" -> {
                            shape.getStrokeDashArray().addAll(10.0, 6.0);
                            shape.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.BUTT);
                        }
                        case "dotted" -> {
                            shape.getStrokeDashArray().addAll(1.0, 7.0);
                            shape.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
                        }
                        case "dash-dot" -> {
                            shape.getStrokeDashArray().addAll(10.0, 5.0, 1.0, 5.0);
                            shape.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
                        }
                        default -> {
                        }
                    }
                }

                for (Node symbolNode : series.getNode().lookupAll(".chart-line-symbol")) {
                    if (symbolNode instanceof javafx.scene.shape.Shape symbolShape) {
                        symbolShape.setVisible(false);
                        symbolShape.setManaged(false);
                    }
                }
            }
        }

        try {
            if (state.centerPane != null && !state.centerPane.getChildren().isEmpty()) {
                Node node = state.centerPane.getChildren().get(0);
                if (node instanceof javafx.scene.chart.BarChart) {
                    javafx.scene.chart.BarChart<?, ?> barChart = (javafx.scene.chart.BarChart<?, ?>) node;
                    barChart.applyCss();
                    barChart.layout();

                    for (Node bar : barChart.lookupAll(".chart-bar")) {
                        String borderStyle;
                        switch (style.toLowerCase()) {
                            case "dashed" -> borderStyle = "dashed";
                            case "dotted" -> borderStyle = "dotted";
                            case "dash-dot" -> borderStyle = "dashed";
                            default -> borderStyle = "solid";
                        }

                        String existing = bar.getStyle();
                        String bg = null;
                        String barFill = null;
                        if (existing != null) {
                            if (existing.contains("-fx-background-color")) {
                                int i = existing.indexOf("-fx-background-color");
                                int sc = existing.indexOf(';', i);
                                if (sc > i)
                                    bg = existing.substring(i, sc + 1);
                            }
                            if (existing.contains("-fx-bar-fill")) {
                                int i = existing.indexOf("-fx-bar-fill");
                                int sc = existing.indexOf(';', i);
                                if (sc > i)
                                    barFill = existing.substring(i, sc + 1);
                            }
                        }
                        if (barFill == null) {
                            barFill = "-fx-bar-fill: #0aa6a6; ";
                        }
                        String combined = barFill + (bg == null ? "" : bg)
                                + "-fx-border-style: " + borderStyle + ";"
                                + " -fx-border-color: white;"
                                + " -fx-border-width: 1px;"
                                + " -fx-border-insets: 0;";
                        bar.setStyle(combined);
                    }
                }
            }
        } catch (Exception ignore) {
        }
    }

    public void apply2DWeight(String weight) {
        if (state.chart == null || weight == null || weight.isBlank())
            return;

        double stroke = switch (weight.trim()) {
            case "1/4 pt" -> 0.5;
            case "1/2 pt" -> 1.0;
            case "3/4 pt" -> 1.5;
            case "1 pt" -> 2.0;
            case "1 1/2 pt" -> 3.0;
            case "2 1/4 pt" -> 4.0;
            case "3 pt" -> 5.0;
            case "4 1/2 pt" -> 7.0;
            case "6 pt" -> 9.0;
            default -> 2.0;
        };

        state.chart.applyCss();
        state.chart.layout();

        for (javafx.scene.chart.XYChart.Series<Number, Number> series : state.chart.getData()) {
            if (series.getNode() != null) {
                Node line = series.getNode().lookup(".chart-series-line");
                if (line instanceof javafx.scene.shape.Shape shape) {
                    shape.setStrokeWidth(stroke);
                }
            }
        }

        try {
            if (state.centerPane != null && !state.centerPane.getChildren().isEmpty()) {
                Node node = state.centerPane.getChildren().get(0);
                if (node instanceof javafx.scene.chart.BarChart) {
                    javafx.scene.chart.BarChart<?, ?> barChart = (javafx.scene.chart.BarChart<?, ?>) node;
                    barChart.applyCss();
                    barChart.layout();

                    for (Node bar : barChart.lookupAll(".chart-bar")) {
                        double borderPx = stroke;

                        String existing = bar.getStyle();
                        String bg = null;
                        String barFill = null;
                        if (existing != null) {
                            if (existing.contains("-fx-background-color")) {
                                int i = existing.indexOf("-fx-background-color");
                                int sc = existing.indexOf(';', i);
                                if (sc > i)
                                    bg = existing.substring(i, sc + 1);
                            }
                            if (existing.contains("-fx-bar-fill")) {
                                int i = existing.indexOf("-fx-bar-fill");
                                int sc = existing.indexOf(';', i);
                                if (sc > i)
                                    barFill = existing.substring(i, sc + 1);
                            }
                        }
                        if (barFill == null) {
                            barFill = "-fx-bar-fill: #0aa6a6; ";
                        }
                        String combined = barFill + (bg == null ? "" : bg) + "-fx-border-width: " + borderPx
                                + "px; -fx-border-color: white;";
                        bar.setStyle(combined);
                    }
                }
            }
        } catch (Exception ignore) {
        }
    }
}
