package plot.plotwindow;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Shape;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.Modality;
import javafx.stage.Stage;
import plot.PlotUtilities;
import ui.managers.ThemeManager;

/**
 * Dialogs, settings strips and line/bar styling for the plot window.
 */
public class PlotWindowDialogsSupport {

    /** Bar fill used when a bar carries no fill of its own yet. */
    private static final String DEFAULT_BAR_FILL = "-fx-bar-fill: #0aa6a6; ";

    private final PlotWindowState state;

    public PlotWindowDialogsSupport(PlotWindowState state) {
        this.state = state;
    }

    public void showPanelDialog(String title, VBox content) {
        if (content == null) {
            return;
        }

        Stage dialog = new Stage();
        dialog.setTitle(title);
        dialog.initModality(Modality.APPLICATION_MODAL);

        Stage owner = PlotUtilities.getDialogOwner(state.plotStage, state.controller);
        if (owner != null) {
            dialog.initOwner(owner);
        }

        Scene scene = new Scene(content, 420, 220);
        ThemeManager.registerScene(scene);
        dialog.setScene(scene);
        dialog.show();
    }

    public VBox buildInfoPanel(String heading, String body) {
        Label title = new Label(heading);
        title.setStyle("-fx-font-size: 14; -fx-font-weight: bold; -fx-padding: 0 0 10 0;");

        Label description = new Label(body);
        description.setWrapText(true);
        description.setStyle("-fx-font-size: 12; -fx-padding: 0 0 10 0;");

        Button close = new Button("Close");
        close.setOnAction(e -> {
            if (close.getScene() != null && close.getScene().getWindow() instanceof Stage stage) {
                stage.close();
            }
        });

        HBox footer = new HBox(close);
        footer.setAlignment(Pos.CENTER_RIGHT);
        footer.setPadding(new Insets(10, 0, 0, 0));

        VBox content = new VBox(10, title, description, footer);
        content.setPadding(new Insets(16));
        content.setStyle("-fx-background-color: white; -fx-border-color: #d0d0d0; -fx-border-width: 1;");
        return content;
    }

    public String getPlotDocumentationText() {
        String typeDescription = "Current chart type: Unknown.";
        Node visible = firstCenterChild();
        if (visible instanceof BarChart) {
            typeDescription = "Current chart type: Bar Chart. Use bar chart view to compare values as vertical bars.";
        } else if (visible instanceof LineChart) {
            typeDescription = "Current chart type: Line Chart. Use line chart view to connect points and see trends over the X axis.";
        } else if (visible instanceof AreaChart) {
            typeDescription = "Current chart type: Area Chart. Use area chart view to emphasize volume beneath the line.";
        } else if (visible instanceof ScatterChart) {
            typeDescription = "Current chart type: Scatter Chart. Use scatter view to inspect point distributions.";
        } else if (visible instanceof PieChart) {
            typeDescription = "Current chart type: Pie Chart. Use pie chart view to compare category shares.";
        }

        return typeDescription + "\n\nUse zoom in/out, home, and palm view to explore the chart. "
                + "The main window button returns focus to the IDE. Use the plot type controls to switch "
                + "between line, bar, area, and other views.";
    }

    public void show2DSettingsDialog() {
        toggleStrip(state.twoDStripBox);
    }

    public void show3DSettingsDialog() {
        toggleStrip(state.threeDStripBox);
    }

    public void showGridSettingsDialog() {
        toggleStrip(state.gridStripBox);
    }

    public void showSaveSettingsDialog() {
        toggleStrip(state.saveStripBox);
    }

    /**
     * Applies a dash pattern to every line series and a matching border style
     * to every bar of a bar chart.
     *
     * @param style "solid", "dashed", "dotted" or "dash-dot"
     */
    public void apply2DStyle(String style) {
        if (state.chart == null || style == null || style.isBlank()) {
            return;
        }
        String key = style.toLowerCase();

        state.chart.applyCss();
        state.chart.layout();

        for (XYChart.Series<Number, Number> series : state.chart.getData()) {
            if (series.getNode() == null) {
                continue;
            }
            if (series.getNode().lookup(".chart-series-line") instanceof Shape shape) {
                shape.getStrokeDashArray().clear();
                switch (key) {
                    case "dashed" -> {
                        shape.getStrokeDashArray().addAll(10.0, 6.0);
                        shape.setStrokeLineCap(StrokeLineCap.BUTT);
                    }
                    case "dotted" -> {
                        shape.getStrokeDashArray().addAll(1.0, 7.0);
                        shape.setStrokeLineCap(StrokeLineCap.ROUND);
                    }
                    case "dash-dot" -> {
                        shape.getStrokeDashArray().addAll(10.0, 5.0, 1.0, 5.0);
                        shape.setStrokeLineCap(StrokeLineCap.ROUND);
                    }
                    default -> {
                        // solid: an empty dash array is a continuous line
                    }
                }
            }

            for (Node symbolNode : series.getNode().lookupAll(".chart-line-symbol")) {
                if (symbolNode instanceof Shape symbolShape) {
                    symbolShape.setVisible(false);
                    symbolShape.setManaged(false);
                }
            }
        }

        String borderStyle = switch (key) {
            case "dashed", "dash-dot" -> "dashed";
            case "dotted" -> "dotted";
            default -> "solid";
        };
        restyleBars("-fx-border-style: " + borderStyle + ";"
                + " -fx-border-color: white;"
                + " -fx-border-width: 1px;"
                + " -fx-border-insets: 0;");
    }

    /**
     * Applies a line weight to every line series and a matching border width
     * to every bar of a bar chart.
     *
     * @param weight one of the point sizes offered in the 2-D strip, e.g. "1 pt"
     */
    public void apply2DWeight(String weight) {
        if (state.chart == null || weight == null || weight.isBlank()) {
            return;
        }

        double stroke = switch (weight.trim()) {
            case "1/4 pt" -> 0.5;
            case "1/2 pt" -> 1.0;
            case "3/4 pt" -> 1.5;
            case "1 pt" -> 2.0;
            case "1 1/2 pt" -> 3.0;
            case "2 1/4 pt" -> 4.0;
            case "3 pt" -> 5.0;
            case "4 1/2 pt" -> 7.0;
            case "6 pt" -> 9.0;
            default -> 2.0;
        };

        state.chart.applyCss();
        state.chart.layout();

        for (XYChart.Series<Number, Number> series : state.chart.getData()) {
            if (series.getNode() != null
                    && series.getNode().lookup(".chart-series-line") instanceof Shape shape) {
                shape.setStrokeWidth(stroke);
            }
        }

        restyleBars("-fx-border-width: " + stroke + "px; -fx-border-color: white;");
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private static void toggleStrip(Node strip) {
        if (strip != null) {
            strip.setVisible(!strip.isVisible());
            strip.setManaged(strip.isVisible());
        }
    }

    private Node firstCenterChild() {
        if (state.centerPane == null || state.centerPane.getChildren().isEmpty()) {
            return null;
        }
        return state.centerPane.getChildren().get(0);
    }

    /**
     * Rewrites every bar's inline style as: its existing fill (or the default
     * fill), its existing background colour if any, then {@code borderRules}.
     * Does nothing when the chart on screen is not a bar chart.
     */
    private void restyleBars(String borderRules) {
        if (!(firstCenterChild() instanceof BarChart<?, ?> barChart)) {
            return;
        }
        barChart.applyCss();
        barChart.layout();

        for (Node bar : barChart.lookupAll(".chart-bar")) {
            String existing = bar.getStyle();
            String barFill = declaration(existing, "-fx-bar-fill");
            String background = declaration(existing, "-fx-background-color");
            bar.setStyle((barFill == null ? DEFAULT_BAR_FILL : barFill)
                    + (background == null ? "" : background)
                    + borderRules);
        }
    }

    /**
     * Extracts one {@code property: value;} declaration from an inline style.
     *
     * @return the declaration including its trailing semicolon, or null if absent
     */
    private static String declaration(String style, String property) {
        if (style == null) {
            return null;
        }
        int start = style.indexOf(property);
        if (start < 0) {
            return null;
        }
        int semicolon = style.indexOf(';', start);
        return semicolon > start ? style.substring(start, semicolon + 1) : null;
    }
}
