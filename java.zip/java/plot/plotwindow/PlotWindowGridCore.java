package plot.plotwindow;

import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;

class PlotWindowGridCore {
    private final PlotWindowState state;
    private final PlotWindowGridStyle styleSupport;

    PlotWindowGridCore(PlotWindowState state, PlotWindowGridStyle styleSupport) {
        this.state = state;
        this.styleSupport = styleSupport;
    }

    void applyGridColor(Color color) {
        state.gridLineColor = color;
        applyGridSettings();
    }

    void applyGridSettings() {
        if (state.gridSettings == null || state.centerPane == null) {
            return;
        }

        List<XYChart<?, ?>> charts = collectAllXYCharts(state.centerPane);
        if (charts.isEmpty()) {
            return;
        }

        for (XYChart<?, ?> currentChart : charts) {
            applyGridSettingsToChart(currentChart);
        }
    }

    private List<XYChart<?, ?>> collectAllXYCharts(Node root) {
        List<XYChart<?, ?>> charts = new ArrayList<>();
        if (root == null) {
            return charts;
        }
        if (root instanceof XYChart<?, ?> chart) {
            charts.add(chart);
        }
        if (root instanceof Parent parent) {
            for (Node child : parent.getChildrenUnmodifiable()) {
                charts.addAll(collectAllXYCharts(child));
            }
        }
        return charts;
    }

    private void applyGridSettingsToChart(XYChart<?, ?> currentChart) {
        if (currentChart == null || state.gridSettings == null) {
            return;
        }

        styleSupport.applyGridStyleClass(currentChart, state.gridSettings.getLineStyle());

        boolean enabled = state.gridSettings.isEnabled();
        currentChart.setHorizontalGridLinesVisible(enabled);
        currentChart.setVerticalGridLinesVisible(enabled);

        double spacing = state.gridSettings.getSpacing() > 0 ? state.gridSettings.getSpacing() : 1.0;
        boolean sparseGridChart = isSparseGridChart(currentChart);
        if (currentChart.getXAxis() instanceof NumberAxis visibleX) {
            visibleX.setTickUnit(resolveTickUnit(visibleX, spacing, sparseGridChart));
            visibleX.setMinorTickCount(0);
            visibleX.setMinorTickVisible(false);
        }
        if (currentChart.getYAxis() instanceof NumberAxis visibleY) {
            visibleY.setTickUnit(resolveTickUnit(visibleY, spacing, sparseGridChart));
            visibleY.setMinorTickCount(0);
            visibleY.setMinorTickVisible(false);
        }

        if (enabled) {
            currentChart.setHorizontalGridLinesVisible(false);
            currentChart.setVerticalGridLinesVisible(false);
            currentChart.applyCss();
            currentChart.layout();
            currentChart.setHorizontalGridLinesVisible(true);
            currentChart.setVerticalGridLinesVisible(true);
        }

        currentChart.applyCss();
        currentChart.layout();

        String rgb = state.gridLineColor == null ? "rgb(0,0,0)"
                : plot.PlotUtilities.toRgb(state.gridLineColor);
        boolean hideLines = enabled && "None".equalsIgnoreCase(state.gridSettings.getLineStyle());
        List<Double> overlayDash = styleSupport.getLineDashPattern(state.gridSettings.getLineStyle());

        styleSupport.styleExistingGridLines(currentChart, rgb, overlayDash, hideLines);
        try {
            Object marker = currentChart.getProperties().get("gridStyleSkinListenerAdded");
            if (!(marker instanceof Boolean)) {
                currentChart.getProperties().put("gridStyleSkinListenerAdded", true);
                currentChart.sceneProperty().addListener((obsScene, oldScene, newScene) -> {
                    Platform.runLater(() -> {
                        try {
                            styleSupport.styleExistingGridLines(currentChart, rgb, overlayDash, hideLines);
                        } catch (Exception ignore) {
                        }
                    });
                });
            }
        } catch (Exception ignore) {
        }

        try {
            Platform.runLater(() -> {
                try {
                    currentChart.applyCss();
                    currentChart.layout();
                    styleSupport.styleExistingGridLines(currentChart, rgb, overlayDash, hideLines);
                } catch (Exception ignore) {
                }
            });
        } catch (Exception ignore) {
        }

        currentChart.applyCss();
        currentChart.layout();

        String distType = state.gridSettings.getDistributionType();
        try {
            Platform.runLater(() -> {
                try {
                    Node plotNode = currentChart.lookup(".chart-plot");
                    Pane plotPane = null;
                    if (plotNode instanceof Pane) {
                        plotPane = (Pane) plotNode;
                    }
                    if (plotPane == null) {
                        Node content = currentChart.lookup(".chart-content");
                        if (content instanceof Pane) {
                            plotPane = (Pane) content;
                        }
                    }
                    if (plotPane == null) {
                        Node bg = currentChart.lookup(".chart-plot-background");
                        if (bg instanceof Pane) {
                            plotPane = (Pane) bg;
                        }
                    }
                    if (plotPane == null && plotNode != null && plotNode.getParent() instanceof Pane) {
                        plotPane = (Pane) plotNode.getParent();
                    }

                    if (plotPane != null) {
                        List<Node> toRemove = new ArrayList<>();
                        for (Node n : plotPane.getChildren()) {
                            if (n.getStyleClass().contains("custom-minor-grid-line")) {
                                toRemove.add(n);
                            }
                            if (n.getStyleClass().contains("custom-uniform-band")) {
                                toRemove.add(n);
                            }
                        }
                        plotPane.getChildren().removeAll(toRemove);
                    }

                    final Pane plotPaneFinal = plotPane;

                    if (distType != null && plotPane != null
                            && currentChart.getXAxis() instanceof NumberAxis visibleX
                            && currentChart.getYAxis() instanceof NumberAxis visibleY) {

                        double lowerX = visibleX.getLowerBound();
                        double upperX = visibleX.getUpperBound();
                        double majorStepX = visibleX.getTickUnit();
                        if (majorStepX <= 0) {
                            majorStepX = state.gridSettings.getMajorTickInterval();
                        }
                        double lowerY = visibleY.getLowerBound();
                        double upperY = visibleY.getUpperBound();
                        double majorStepY = visibleY.getTickUnit();
                        if (majorStepY <= 0) {
                            majorStepY = state.gridSettings.getMajorTickInterval();
                        }

                        int safeMajorsX = majorStepX > 0 ? (int) Math.ceil(Math.abs((upperX - lowerX) / majorStepX))
                                : 0;
                        int safeMajorsY = majorStepY > 0 ? (int) Math.ceil(Math.abs((upperY - lowerY) / majorStepY))
                                : 0;

                        final int MAX_MAJORS = 250;
                        if (safeMajorsX > MAX_MAJORS || safeMajorsY > MAX_MAJORS) {
                            try {
                                visibleX.setMinorTickCount(0);
                            } catch (Exception ignore) {
                            }
                            try {
                                visibleY.setMinorTickCount(0);
                            } catch (Exception ignore) {
                            }
                            return;
                        }

                        Color base = state.gridLineColor == null ? Color.BLACK : state.gridLineColor;
                        if ("uniform".equalsIgnoreCase(distType)) {
                            int minorCount = sparseGridChart ? 0 : 4;
                            visibleX.setMinorTickCount(minorCount);
                            visibleY.setMinorTickCount(minorCount);
                            try {
                                visibleX.setMinorTickVisible(minorCount > 0);
                            } catch (Exception ignore) {
                            }
                            try {
                                visibleY.setMinorTickVisible(minorCount > 0);
                            } catch (Exception ignore) {
                            }

                            double paneHeight = plotPane.getHeight();
                            double paneWidth = plotPane.getWidth();

                            if (paneWidth <= 8 || paneHeight <= 8) {
                                plotPane.requestLayout();
                                Platform.runLater(this::applyGridSettings);
                                return;
                            }

                            Node bgNode = currentChart.lookup(".chart-plot-background");
                            if (bgNode instanceof Region bgRegion) {
                                int r = (int) Math.round(base.getRed() * 255);
                                int g = (int) Math.round(base.getGreen() * 255);
                                int b = (int) Math.round(base.getBlue() * 255);
                                double alpha = 0.02;
                                String rgba = String.format("rgba(%d,%d,%d,%.3f)", r, g, b, alpha);
                                bgRegion.setStyle("-fx-background-color: " + rgba + ";");
                            }

                        } else if ("mixed".equalsIgnoreCase(distType)) {
                            int minorCount = sparseGridChart ? 0 : 2;
                            visibleX.setMinorTickCount(minorCount);
                            visibleY.setMinorTickCount(minorCount);
                            try {
                                visibleX.setMinorTickVisible(minorCount > 0);
                            } catch (Exception ignore) {
                            }
                            try {
                                visibleY.setMinorTickVisible(minorCount > 0);
                            } catch (Exception ignore) {
                            }

                            double paneHeight = plotPane.getHeight();
                            double paneWidth = plotPane.getWidth();

                            if (paneWidth <= 8 || paneHeight <= 8) {
                                plotPane.requestLayout();
                                Platform.runLater(this::applyGridSettings);
                                return;
                            }

                            Node bgNode = currentChart.lookup(".chart-plot-background");
                            if (bgNode instanceof Region bgRegion) {
                                int r = (int) Math.round(base.getRed() * 255);
                                int g = (int) Math.round(base.getGreen() * 255);
                                int b = (int) Math.round(base.getBlue() * 255);
                                double alpha = 0.04;
                                String rgba = String.format("rgba(%d,%d,%d,%.3f)", r, g, b, alpha);
                                bgRegion.setStyle("-fx-background-color: " + rgba + ";");
                            }

                        } else {
                            try {
                                visibleX.setMinorTickCount(0);
                            } catch (Exception ignore) {
                            }
                            try {
                                visibleY.setMinorTickCount(0);
                            } catch (Exception ignore) {
                            }
                        }

                        if (hideLines) {
                            try {
                                visibleX.setMinorTickCount(0);
                            } catch (Exception ignore) {
                            }
                            try {
                                visibleY.setMinorTickCount(0);
                            } catch (Exception ignore) {
                            }
                            return;
                        }

                        try {
                            if (plotPaneFinal != null) {
                                Object marker = plotPaneFinal.getProperties().get("gridOverlayResizeListenerAdded");
                                if (!(marker instanceof Boolean)) {
                                    plotPaneFinal.getProperties().put("gridOverlayResizeListenerAdded", true);
                                    plotPaneFinal.widthProperty().addListener((obsW, oldW, newW) -> {
                                        Platform.runLater(() -> {
                                            try {
                                                applyGridSettings();
                                            } catch (Exception ignore) {
                                            }
                                        });
                                    });
                                    plotPaneFinal.heightProperty().addListener((obsH, oldH, newH) -> {
                                        Platform.runLater(() -> {
                                            try {
                                                applyGridSettings();
                                            } catch (Exception ignore) {
                                            }
                                        });
                                    });
                                }
                            }
                        } catch (Exception ignore) {
                        }

                    } else {
                        if (currentChart.getXAxis() instanceof NumberAxis vx) {
                            vx.setMinorTickCount(0);
                        }
                        if (currentChart.getYAxis() instanceof NumberAxis vy) {
                            vy.setMinorTickCount(0);
                        }
                    }
                } catch (Exception ignore) {
                }
            });
        } catch (Exception ignore) {
        }
    }

    private boolean isSparseGridChart(XYChart<?, ?> currentChart) {
        return currentChart instanceof LineChart<?, ?>
                || currentChart instanceof AreaChart<?, ?>
                || currentChart instanceof ScatterChart<?, ?>;
    }

    private double resolveTickUnit(NumberAxis axis, double baseSpacing, boolean sparseGridChart) {
        double spacing = baseSpacing > 0 ? baseSpacing : 1.0;
        if (!sparseGridChart || axis == null) {
            return spacing;
        }

        double lower = axis.getLowerBound();
        double upper = axis.getUpperBound();
        double range = Math.abs(upper - lower);
        if (!(range > 0) || Double.isNaN(range) || Double.isInfinite(range)) {
            return spacing;
        }

        double targetTicks = 6.0;
        double candidate = niceTickUnit(range / targetTicks);
        return Math.max(spacing, candidate);
    }

    private double niceTickUnit(double value) {
        if (!(value > 0) || Double.isNaN(value) || Double.isInfinite(value)) {
            return 1.0;
        }

        double exponent = Math.floor(Math.log10(value));
        double scale = Math.pow(10.0, exponent);
        double normalized = value / scale;
        double nice;
        if (normalized <= 1.0) {
            nice = 1.0;
        } else if (normalized <= 2.0) {
            nice = 2.0;
        } else if (normalized <= 5.0) {
            nice = 5.0;
        } else {
            nice = 10.0;
        }
        return nice * scale;
    }
}
