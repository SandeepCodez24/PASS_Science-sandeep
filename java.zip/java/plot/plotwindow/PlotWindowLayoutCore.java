package plot.plotwindow;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import plot.PlotToolbar;

class PlotWindowLayoutCore {

    private final PlotWindowState state;

    private final PlotWindowSelectionSupport selectionSupport;
    private final PlotWindowDialogsSupport dialogsSupport;
    private final PlotWindowGridSupport gridSupport;
    private final PlotWindowLayoutControls controls;

    PlotWindowLayoutCore(PlotWindowState state, PlotWindowSelectionSupport selectionSupport,
            PlotWindowDialogsSupport dialogsSupport, PlotWindowGridSupport gridSupport,
            PlotWindowLayoutControls controls) {
        this.state = state;
        this.selectionSupport = selectionSupport;
        this.dialogsSupport = dialogsSupport;
        this.gridSupport = gridSupport;
        this.controls = controls;
    }

    void buildStrips() {
        state.axisStripBox = state.menus.buildAxisStrip((xName, yName) -> {
            if (xName == null || yName == null) {
                return;
            }

            state.xAxis.setLabel(xName);
            state.yAxis.setLabel(yName);
            state.chartOps.drawVariablePlot(xName, yName);
        });

        state.typesStrip = state.plotTypes.buildTypesStrip(type -> {
            selectionSupport.handlePlotTypeSelection(type);
            state.colorStrip.hideColorStrip();
            state.menus.hideAxisStrip();
        });

        state.colorStripBox = state.colorStrip.buildColorStrip(mode -> {
            selectionSupport.showColorDialog(mode);
            state.colorStrip.hideColorStrip();
            state.menus.hideAxisStrip();
        });

        state.annotationStripBox = state.annotation.buildAnnotationStrip();

        state.twoDStripBox = state.plot2D.build((type, style) -> {
            state.current2DStyle = style == null ? "solid" : style;
            dialogsSupport.apply2DStyle(state.current2DStyle);
        }, weight -> {
            state.current2DWeight = weight == null ? "1 pt" : weight;
            dialogsSupport.apply2DWeight(state.current2DWeight);
        }, hatch -> {
            state.current2DHatch = hatch == null ? "None" : hatch;
            gridSupport.apply2DHatch(state.current2DHatch);
        }, controls::hideTwoDStrip);
        state.twoDStripBox.setVisible(false);
        state.twoDStripBox.setManaged(false);

        CheckBox enabled = new CheckBox("Enable grid");
        enabled.setSelected(state.gridSettings.isEnabled());

        ComboBox<String> lineStyle = new ComboBox<>();
        lineStyle.getItems().addAll("Solid", "Dashed", "Dotted", "Dash-dot", "None");
        lineStyle.setValue(state.gridSettings.getLineStyle());
        lineStyle.valueProperty().addListener((obs, oldValue, newValue) -> {
            state.gridSettings.setLineStyle(newValue);
            gridSupport.applyGridSettings();
            javafx.application.Platform.runLater(gridSupport::applyGridSettings);
        });
        lineStyle.setOnAction(e -> {
            state.gridSettings.setLineStyle(lineStyle.getValue());
            gridSupport.applyGridSettings();
            javafx.application.Platform.runLater(gridSupport::applyGridSettings);
        });

        TextField distribution = new TextField(state.gridSettings.getDistribution());
        ComboBox<String> distributionType = new ComboBox<>();
        distributionType.getItems().addAll("Normal", "Uniform", "Mixed");
        distributionType.setValue(state.gridSettings.getDistributionType());

        distribution.setPrefWidth(160);
        distributionType.setPrefWidth(120);

        HBox enabledRow = new HBox(10, enabled);
        HBox styleRow = new HBox(8, new Label("Line style"), lineStyle);
        HBox distributionRow = new HBox(8, new Label("Distribution"), distribution, new Label("Type"),
                distributionType);

        enabledRow.setAlignment(Pos.CENTER_LEFT);
        styleRow.setAlignment(Pos.CENTER_LEFT);
        distributionRow.setAlignment(Pos.CENTER_LEFT);

        ColorPicker colorPicker = new ColorPicker(state.gridLineColor == null ? Color.BLACK : state.gridLineColor);
        HBox colorRow = new HBox(8, new Label("Line color"), colorPicker);
        colorRow.setAlignment(Pos.CENTER_LEFT);

        Label gridTitle = new Label("Grid Settings");
        HBox gridHeader = new HBox(10, gridTitle, new Region());
        HBox.setHgrow(gridHeader.getChildren().get(1), Priority.ALWAYS);
        gridHeader.setAlignment(Pos.CENTER_LEFT);

        VBox gridContent = new VBox(10,
                gridHeader,
                enabledRow,
                styleRow,
                distributionRow,
                colorRow);
        gridContent.setPadding(new Insets(14));
        state.gridStripBox = gridContent;
        state.gridStripBox.setVisible(false);
        state.gridStripBox.setManaged(false);

        state.gridEnabledCheckBox = enabled;
        state.gridLineStyleCombo = lineStyle;
        state.gridDistributionField = distribution;
        state.gridDistributionTypeCombo = distributionType;
        state.gridColorPicker = colorPicker;

        enabled.selectedProperty().addListener((obs, oldVal, newVal) -> {
            state.gridSettings.setEnabled(newVal);
            gridSupport.applyGridSettings();
        });

        distribution.textProperty().addListener((obs, oldVal, newVal) -> {
            state.gridSettings.setDistribution(newVal);
            gridSupport.applyGridSettings();
        });

        distributionType.setOnAction(e -> {
            state.gridSettings.setDistributionType(distributionType.getValue());
            gridSupport.applyGridSettings();
        });

        colorPicker.setOnAction(e -> {
            try {
                gridSupport.applyGridColor(colorPicker.getValue());
            } catch (Exception ignore) {
            }
        });

        state.threeDStripBox = state.plot3D.build((type, style) -> {
            javafx.scene.SubScene scene3D = state.chart3D.create3DScene(type, style,
                    subScene -> state.chartOps.setCenterContent(subScene));
            state.chartOps.setCenterContent(scene3D);
            try {
                scene3D.widthProperty().bind(state.centerPane.widthProperty());
                scene3D.heightProperty().bind(state.centerPane.heightProperty());
            } catch (Exception ignore) {
            }
            try {
                if (scene3D.getCamera() instanceof javafx.scene.PerspectiveCamera cam) {
                    cam.setNearClip(0.1);
                    cam.setFarClip(5000.0);
                    if (cam.getTranslateZ() < -200) {
                        cam.setTranslateZ(-400);
                    }
                }
            } catch (Exception ignore) {
            }
            if (state.selectedPlotLabel != null) {
                state.selectedPlotLabel.setText("3D " + type + " selected");
            }
        }, controls::hide3DStrip);
        state.threeDStripBox.setVisible(false);
        state.threeDStripBox.setManaged(false);

        state.saveStripBox = state.plotSave.build(params -> state.chartOps.saveWithSettings(
                params.dpi,
                params.format,
                params.targetFile,
                state.plotStage,
                state.centerPane), controls::hideSaveStrip);
        state.saveStripBox.setVisible(false);
        state.saveStripBox.setManaged(false);
    }

    void buildMainLayout() {
        state.selectedPlotLabel = new Label("Select plot to display below");
        state.selectedPlotLabel.getStyleClass().add("plot-type-label");
        state.selectedPlotLabel.setStyle("-fx-padding:4 10 6 10; -fx-font-size:11; -fx-text-fill:#2f3a44;");
        state.selectedPlotLabel.setMaxWidth(Double.MAX_VALUE);
        state.selectedPlotLabel.setAlignment(Pos.CENTER_RIGHT);
        state.selectedPlotLabel.setOnMouseClicked(e -> {
            if (state.selectedPlotLabel.getStyleClass().contains("plot-type-label-clicked")) {
                state.selectedPlotLabel.getStyleClass().remove("plot-type-label-clicked");
            } else {
                state.selectedPlotLabel.getStyleClass().add("plot-type-label-clicked");
            }
        });

        state.root = new BorderPane();

        Button axisButton = state.menus.buildAxisButton(v -> {
        });

        axisButton.setOnAction(e -> {
            controls.hideAllStrips();
            controls.showRequestedStrip(
                    PlotWindowLayoutControls.StripKind.AXIS);

            state.plotToolbar.selectToolbarControlForButton(axisButton);
        });
        Button menu2D = new Button("2D");
        menu2D.setOnAction(e -> {
            controls.hideAllStrips();
            controls.showRequestedStrip(plot.plotwindow.PlotWindowLayoutControls.StripKind.TWO_D);

            state.plotToolbar.selectToolbarControlForButton(menu2D);
        });

        menu2D.setVisible(true);
        menu2D.setManaged(true);
        Button menu3D = new Button("3D");
        menu3D.setOnAction(e -> {
            controls.hideAllStrips();
            controls.showRequestedStrip(plot.plotwindow.PlotWindowLayoutControls.StripKind.THREE_D);

            state.plotToolbar.selectToolbarControlForButton(menu3D);
        });

        Button gridMenu = new Button("Grid");
        gridMenu.setOnAction(e -> {
            controls.hideAllStrips();
            controls.showRequestedStrip(plot.plotwindow.PlotWindowLayoutControls.StripKind.GRID);

            state.plotToolbar.selectToolbarControlForButton(gridMenu);
        });

        Button annotationButton = state.annotation.buildAnnotationButton(v -> {
        });

        annotationButton.setOnAction(e -> {
            controls.hideAllStrips();
            controls.showRequestedStrip(
                    PlotWindowLayoutControls.StripKind.ANNOTATION);

            state.plotToolbar.selectToolbarControlForButton(annotationButton);
        });
        state.saveMenuButton = new Button("Save");
        state.saveMenuButton.setOnAction(e -> {
            controls.hideAllStrips();
            controls.showRequestedStrip(plot.plotwindow.PlotWindowLayoutControls.StripKind.SAVE);

            state.plotToolbar.selectToolbarControlForButton(state.saveMenuButton);
        });

        ToolBar toolbar = state.plotToolbar.buildToolbar(axisButton, menu2D, menu3D, gridMenu, annotationButton,
                state.saveMenuButton,
                v -> {
                    controls.hideAllStrips();
                    controls.showRequestedStrip(plot.plotwindow.PlotWindowLayoutControls.StripKind.TYPES);

                    state.plotToolbar.selectToolbarControlForButton(state.plotToolbar.getTypesButton());
                },
                v -> {
                    controls.hideAllStrips();
                    controls.showRequestedStrip(plot.plotwindow.PlotWindowLayoutControls.StripKind.COLORS);

                    state.plotToolbar.selectToolbarControlForButton(state.plotToolbar.getColorsButton());
                },
                v -> {
                });

        state.toolbar = toolbar;
        // Startup: no strip visible and no toolbar button selected.
        // (Strips are initialized hidden in buildStrips; remove any selection styling.)
        // Ensure no strip selected at startup.

        for (javafx.scene.Node n : toolbar.getItems()) {
            if (n instanceof Button b) {
                PlotToolbar.styleFlatToolbarControl(b);
            }
        }

        BorderPane topHeader = new BorderPane();

        topHeader.setLeft(toolbar);
        topHeader.setRight(state.selectedPlotLabel);
        topHeader.setStyle("-fx-background-color:#0aa6a6;");

        VBox topArea = new VBox(topHeader, state.axisStripBox, state.typesStrip, state.colorStripBox,
                state.annotationStripBox, state.gridStripBox,
                state.twoDStripBox, state.threeDStripBox, state.saveStripBox);
        state.root.setTop(topArea);
        state.root.setLeft(selectionSupport.buildVariableSidebar());
        controls.createChartCornerActions();
        if (state.chartCornerBox != null) {
            try {
                StackPane.setAlignment(state.chartCornerBox, Pos.TOP_RIGHT);
            } catch (Exception ignore) {
            }
            state.chartCornerBox.setPadding(new Insets(2));
            state.centerPane.getChildren().add(state.chartCornerBox);
        }
        state.root.setCenter(state.centerPane);
        controls.updateChartCornerVisibility();
    }
}
