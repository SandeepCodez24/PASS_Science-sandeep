package plot.plotwindow;

import java.util.Set;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.layout.Region;

class PlotWindowGridHatch {
    private final PlotWindowState state;

    PlotWindowGridHatch(PlotWindowState state) {
        this.state = state;
    }

    void apply2DHatch(String hatch) {
        final String selectedHatch = hatch == null ? "None" : hatch;
        try {
            if (state.centerPane == null || state.centerPane.getChildren().isEmpty()) {
                return;
            }
            Node node = state.centerPane.getChildren().get(0);
            if (!(node instanceof javafx.scene.chart.BarChart<?, ?>)) {
                return;
            }

            javafx.scene.chart.BarChart<?, ?> barChart = (javafx.scene.chart.BarChart<?, ?>) node;
            barChart.applyCss();
            barChart.layout();

            Set<Node> bars = barChart.lookupAll(".chart-bar");
            if (bars.isEmpty() && !"None".equalsIgnoreCase(selectedHatch)) {
                Platform.runLater(() -> apply2DHatch(selectedHatch));
                return;
            }

            for (Node bar : bars) {
                String style = "-fx-bar-fill: #0aa6a6; -fx-background-color: #0aa6a6; -fx-opacity: 1;";
                String existing = bar.getStyle();
                if (existing != null && !existing.isBlank()) {
                    String borderStyle = plot.PlotUtilities.extractStyleProperty(existing, "-fx-border-style");
                    String borderColor = plot.PlotUtilities.extractStyleProperty(existing, "-fx-border-color");
                    String borderWidth = plot.PlotUtilities.extractStyleProperty(existing, "-fx-border-width");
                    String borderInsets = plot.PlotUtilities.extractStyleProperty(existing,
                            "-fx-border-insets");
                    if (!borderStyle.isBlank()) {
                        style += borderStyle;
                    }
                    if (!borderColor.isBlank()) {
                        style += borderColor;
                    }
                    if (!borderWidth.isBlank()) {
                        style += borderWidth;
                    }
                    if (!borderInsets.isBlank()) {
                        style += borderInsets;
                    }
                }

                if (!"None".equalsIgnoreCase(selectedHatch)) {
                    try {
                        String patternUrl = generateHatchPattern(selectedHatch, "#ffffff");
                        if (patternUrl != null) {
                            style += " -fx-background-image: url('" + patternUrl + "');";
                            style += " -fx-background-repeat: repeat;";
                            style += " -fx-background-position: 0 0;";
                            style += " -fx-background-size: 12 12;";
                            style += " -fx-background-insets: 0;";
                        }
                    } catch (Exception ignore) {
                    }
                }

                if (bar instanceof Region r) {
                    r.setBackground(null);
                    r.setStyle(style);
                } else {
                    bar.setStyle(style);
                }
            }

            if (!"None".equalsIgnoreCase(selectedHatch)) {
                Platform.runLater(() -> {
                    try {
                        Node refreshed = state.centerPane.getChildren().isEmpty() ? null
                                : state.centerPane.getChildren().get(0);
                        if (refreshed instanceof javafx.scene.chart.BarChart<?, ?> refreshedBarChart) {
                            refreshedBarChart.applyCss();
                            refreshedBarChart.layout();
                        }
                    } catch (Exception ignore) {
                    }
                });
            }
        } catch (Exception ex) {
        }
    }

    private String generateHatchPattern(String hatch, String lineHex) {
        try {
            int size = 12;
            java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(size, size,
                    java.awt.image.BufferedImage.TYPE_INT_ARGB);
            java.awt.Graphics2D g = img.createGraphics();
            g.setComposite(java.awt.AlphaComposite.Src);
            g.setColor(new java.awt.Color(0, 0, 0, 0));
            g.fillRect(0, 0, size, size);

            java.awt.Color lineColor = java.awt.Color.decode(lineHex);
            g.setColor(new java.awt.Color(lineColor.getRed(), lineColor.getGreen(), lineColor.getBlue(), 160));
            g.setStroke(new java.awt.BasicStroke(2));

            switch (hatch) {
                case "Hatching", "Diagonal" -> {
                    for (int x = -size; x < size * 2; x += 6) {
                        g.drawLine(x, size, x + size, 0);
                    }
                }
                case "Cross", "Cross-hatching" -> {
                    for (int x = -size; x < size * 2; x += 6) {
                        g.drawLine(x, size, x + size, 0);
                        g.drawLine(x, 0, x + size, size);
                    }
                }
                case "Dots" -> {
                    for (int y = 0; y < size; y += 4) {
                        for (int x = 0; x < size; x += 4) {
                            g.fillOval(x, y, 2, 2);
                        }
                    }
                }
                case "Stippling" -> {
                    for (int y = 0; y < size; y += 3) {
                        for (int x = 0; x < size; x += 3) {
                            g.fillOval(x, y, 1, 1);
                        }
                    }
                }
                case "Short Dashes" -> {
                    for (int y = 0; y < size; y += 6) {
                        for (int x = 0; x < size; x += 8) {
                            g.drawLine(x, y, x + 3, y);
                        }
                    }
                }
                case "Zig Zags" -> {
                    for (int y = 0; y < size; y += 8) {
                        for (int x = 0; x < size; x += 8) {
                            g.drawLine(x, y, x + 4, y + 4);
                            g.drawLine(x + 4, y + 4, x + 8, y);
                        }
                    }
                }
                case "3s" -> {
                    for (int y = 0; y < size; y += 6) {
                        for (int x = 0; x < size; x += 9) {
                            g.drawLine(x, y, x + 3, y);
                            g.drawLine(x + 3, y, x + 4, y + 2);
                            g.drawLine(x + 4, y + 2, x + 6, y + 2);
                        }
                    }
                }
                case "Circularism" -> {
                    for (int r = 1; r < size; r += 4) {
                        g.drawOval((size - r) / 2, (size - r) / 2, r, r);
                    }
                }
                case "Contouring" -> {
                    for (int y = 0; y < size; y += 4) {
                        int offset = (y % 8 == 0) ? 0 : 2;
                        g.drawArc(-4 + offset, y - 2, size + 8, 8, 0, 180);
                    }
                }
                case "Scribbles" -> {
                    for (int i = 0; i < 16; i++) {
                        int x1 = (i * 3) % size;
                        int y1 = (i * 5) % size;
                        int x2 = (x1 + 4) % size;
                        int y2 = (y1 + 2) % size;
                        g.drawLine(x1, y1, x2, y2);
                    }
                }
                case "Blending" -> {
                    for (int y = 0; y < size; y++) {
                        for (int x = 0; x < size; x++) {
                            if ((x + y) % 3 == 0) {
                                g.fillOval(x, y, 1, 1);
                            }
                        }
                    }
                }
                case "Horizontal" -> {
                    for (int y = 0; y < size; y += 6) {
                        g.drawLine(0, y, size, y);
                    }
                }
                default -> {
                    for (int y = 0; y < size; y += 8) {
                        g.drawLine(0, y, size, y);
                    }
                }
            }

            g.dispose();
            java.io.File tmp = java.io.File.createTempFile("hatch_", ".png");
            javax.imageio.ImageIO.write(img, "PNG", tmp);
            tmp.deleteOnExit();
            return tmp.toURI().toString();
        } catch (Exception ex) {
            return null;
        }
    }
}
